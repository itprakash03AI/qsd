"""
Query execution endpoints and background workers.

Endpoints:
- POST /api/execute          — submit query for background execution
- POST /api/execute/estimate — lightweight row/file count estimation

Background workers:
- execute_query_background          — S3/local parquet execution
- execute_sql_connector_background  — SQL connector (Trino/Snowflake/...) execution
- execute_cross_query_background    — cross-connection (multi-source) execution

Extracted from main.py (Round 4 A3).
"""
from __future__ import annotations

import asyncio
from core.business_calendar_tokens import CalendarTokenRefused
from core.table_prefix import prefix_matches
import functools
import json
import logging
import os
import threading
import time as _time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException, Request

from api.data_grid_api import _enforce_execution_ownership
from api.deps import (get_current_user, require_execute_access,
                      require_execution_read_access, assert_execution_visible_to_token)
from api.models.query_models import (
    CancelQueuedRequest, ExecuteQueryRequest, EstimateRequest, QueryConfigModel,
    QueryConfigRequestModel,
)
from core.db_async import adb
from core.query_converter import convert_query_config_to_engine
from core.duckdb_views import (
    execute_registered_table_query,
    execute_registered_table_copy_to,
    s3_full_copy,
    join_inflight_query,
    run_base_data_local_query,
    setup_registered_views,
    typed_empty_view_ddl,
    _apply_mor_view,
    MorDeletesUnresolvableError,
)
from core.iceberg_mor import MorDeleteCollectionError
from core.s3_utilities import (
    list_s3_parquet_files,
    list_s3_parquet_files_cached,
    s3_urls_to_presigned,
    make_s3_client_for_conn,
    get_s3_access_mode,
    filter_iceberg_files_by_partitions,
    extract_partition_filters_from_query,
)
from core.error_detection import is_connection_error, classify_duckdb_error
from core.s3_storage import build_s3_config, TokenExpiredError
from core.config import cache as _cache_cfg
# 2026-09-05 round 2 -- ``native_from_ref`` is the ONE answer to "what may
# this builder-mode config put in its FROM clause on THAT engine", shared
# with /api/execute/preview-sql, the published-view runner, the scheduler
# and the report runner.  Three doors in THIS module used ``files[0]``
# verbatim, with no check at all.
from core.parquet_engine_v2 import (
    ParquetQueryEngine, QueryConfig,
    native_from_ref as _native_from_ref,
    QueryNotExpressible as _QueryNotExpressible,
)
from core.connection_manager import _normalize_path
from core.connectors import get_connector, SQL_CONNECTOR_TYPES
from core.json_utils import sanitize_for_json as _sanitize_for_json
from core.sql_filter_wrapper import dialect_for_connection_type

logger = logging.getLogger(__name__)

#: the pre-validation's budget: past it the query PROCEEDS unvalidated (BF-276)
#: and the answer says pre_validate_status=timed_out.  A named constant so a
#: test can give a loaded machine room (2026-10-18); production keeps 5 s.
PRE_VALIDATE_BUDGET_SECONDS = 5.0


router = APIRouter()

# ── Module-level singletons — populated by set_execute_dependencies() ─────
_db_manager = None
_ws_manager = None
_engine = None           # default ParquetQueryEngine instance
_paths = None            # config paths
_qe_cfg = None           # query_engine config section
_limits_cfg = None       # limits config section
_s3_config = None        # global S3Config (may be None)
_query_executor = None   # ThreadPoolExecutor for heavy queries
_get_light_executor_fn = None  # callable returning streaming executor

# ── Shared execution state ─────────────────────────────────────────────────
_inflight_queries: dict = {}     # cache_key → (exec_id, asyncio.Event)

# BF-592 (2026-05-30): the per-user queue + slot accounting + cancel
# registry + bg-task tracking + orphan-owner registry are now all
# encapsulated in ``core.query_queue.QueueManager``.  The module-level
# names below are BACK-COMPAT ALIASES bound to the singleton's
# instance attributes — they are the SAME dict objects, so existing
# test fixtures that mutate ``execute_api._user_query_counts["alice"] = 1``
# affect the same underlying state the QueueManager methods see.
#
# Apply rule for NEW code: import ``get_queue_manager`` and call methods
# on it — do NOT add new module-level aliases here.
from core.query_queue import get_queue_manager as _get_queue_manager  # noqa: E402
from core.download_retention import (
    download_expires_at as _download_expires_at)
_queue_mgr = _get_queue_manager()

# Wire the WS broadcast callback once the WS manager is set up via init().
# Default is no-op (safe for tests + startup before WS).  The init()
# function at the bottom of this module overrides via mgr.set_broadcast_fn.

# Module-level aliases — identical dict/lock/set objects.
_user_query_counts: dict = _queue_mgr._user_query_counts
_user_query_lock = _queue_mgr._lock
_user_queue_counts: dict = _queue_mgr._user_queue_counts
_user_queue_events: dict = _queue_mgr._user_queue_events
_queued_execution_cancels: dict = _queue_mgr._queued_execution_cancels
_bg_broadcast_tasks: set = _queue_mgr._bg_tasks


def _track_bg_task(coro):
    """BF-588/592: create_task with strong-ref tracking — delegates
    to the QueueManager singleton."""
    return _queue_mgr.track_bg_task(coro)


def cancel_queued_execution(execution_id: str) -> bool:
    """BF-585/588/589/592: signal a queued execution to abort its wait.

    Lock-protected (BF-588 race fix): the registry is shared between
    the API thread (cancel call) and the queue waiter (set/pop).

    BF-589: emits an audit log entry on signal so admins can trace
    queue-cancellations in the operational record.

    Returns True when the execution was queued and signalled,
    False when it wasn't in the queue."""
    return _queue_mgr.cancel_queued(execution_id)


async def _broadcast_queue_event(username: str, execution_id: str,
                                  position: int, message: str = "", *,
                                  queue_length: int = 0,
                                  client_request_id: str = ""):
    """BF-584: emit ``execution_queued`` WS event so the frontend can
    render "Queued — N ahead of you" instead of a frozen spinner.

    H1 (2026-10-07): the query builders learn ``execution_id`` only when
    their POST returns -- and the POST is what waits -- so the event also
    carries the ``client_request_id`` the client sent with that POST (the
    one handle it can match) and ``queue_length`` ("position N of M").
    ``user_only`` makes the WS layer deliver it to ``username``'s sockets
    ONLY -- never the broadcast-to-everyone fallback, on this pod or a peer.

    Fail-safe: if the WS manager isn't wired (early startup, tests,
    or already torn down), this is a no-op."""
    if not _ws_manager:
        return
    try:
        await _ws_manager.broadcast_to_user(username, {
            "type": "execution_queued",
            "execution_id": execution_id,
            "client_request_id": client_request_id or None,
            "user_only": True,
            "data": {
                "queue_position": position,
                "queue_length": max(int(queue_length or 0), int(position or 0)),
                "message": message or (
                    "Starting..." if position == 0
                    else f"Queued — {position} ahead of you"
                ),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
    except Exception:
        # WS errors must never block the queue logic.
        pass


async def _acquire_user_slot(username: str, max_per_user: int,
                             max_queue: int, wait_timeout: float,
                             execution_id: str = "", max_global: int = 0,
                             global_wait_timeout: float = 0.0,
                             client_request_id: Optional[str] = None):
    """BF-584/592: try to acquire a per-user concurrent-query slot.

    Returns ``(acquired, reason, queue_position)``.  See
    ``core.query_queue.QueueManager.acquire_slot`` for full semantics.

    2026-09-28: ``max_global`` is the pod's global cap, decided INSIDE the
    grant's critical section (``(False, "load_shed", active)`` when at
    cap).  A submit site passes ``_global_cap()`` and answers a refusal
    with ``_raise_if_load_shed`` -- there is no separate pre-check any
    more (that check-then-act is how the rig reached 11/8).

    2026-10-07: ``global_wait_timeout`` (the interactive lanes pass
    :func:`_interactive_global_wait`) makes "at the global cap" a bounded,
    FAIR wait in the pod-wide queue instead of an immediate 503; a refusal
    after it is the same ``load_shed`` answer.

    H1 (2026-10-07): ``client_request_id`` -- the correlation id the client
    sent with its POST -- rides every ``execution_queued`` event of this
    wait and is the handle ``POST /api/execute/queued/cancel`` ends it by.

    BF-592: thin delegating shim — the real implementation lives in
    the QueueManager singleton.
    """
    return await _queue_mgr.acquire_slot(
        username, max_per_user, max_queue, wait_timeout, execution_id,
        max_global=max_global, global_wait_timeout=global_wait_timeout,
        client_request_id=client_request_id or "",
    )


def _interactive_global_wait() -> float:
    """How long an INTERACTIVE submit waits in the pod-wide fair queue when
    the pod is at ``query_engine.max_concurrent_global`` (2026-10-07): the
    same ``queue_wait_timeout_seconds`` its per-user queue waits (0 = refuse
    at once, the pre-2026-10-07 answer)."""
    try:
        return float(_qe_cfg.queue_wait_timeout_seconds) if _qe_cfg else 0.0
    except Exception:
        return 0.0


def _global_cap() -> int:
    """``query_engine.max_concurrent_global`` as the slot grant reads it;
    0 (no cap) when unconfigured or unreadable -- the value the deleted
    ``_check_load_shed`` used, unchanged."""
    try:
        return int(_qe_cfg.max_concurrent_global) if _qe_cfg else 0
    except Exception:
        return 0


def _raise_if_load_shed(reason: str, active) -> None:
    """A ``load_shed`` slot refusal as the 503 + Retry-After every submit
    site answered before -- text and header from ONE place
    (``core.executors.concurrency.AdmissionRefusal``)."""
    if reason == "load_shed":
        from core.executors.concurrency import AdmissionRefusal
        raise AdmissionRefusal(int(active or 0), _global_cap()).as_http()


def _cancelled_while_queued(execution_id: str) -> dict:
    """The answer of a submit whose slot wait was cancelled (BF-585; H1 made
    every interactive lane give it -- two of them answered "Server busy
    (cancelled)" 503).  No execution row exists: the run never started."""
    return {
        "execution_id": execution_id,
        "status": "cancelled",
        "message": "Cancelled while waiting in queue.",
    }


# BF-592: aliases to QueueManager's state dicts.  Tests + legacy code
# that reach into these by name see the same underlying objects.
_user_queue_events_by_loop: dict = _queue_mgr._user_queue_events_by_loop
_live_loops_by_id = _queue_mgr._live_loops_by_id


def _get_loop_local_event(username: str):
    """BF-588/592: thin delegating shim."""
    return _queue_mgr.get_loop_local_event(username)


def _release_user_slot(username: str):
    """BF-584/588/590/591/592: thin delegating shim."""
    _queue_mgr.release_slot(username)

# BF-576 (2026-05-29): cold-metadata short-circuit.  Maps
# connection_id -> Unix timestamp.  Until that time, pre-validate is
# skipped for queries on this connection because the previous
# pre-validate just timed out at 5s on a cold Iceberg manifest.
# Without this, every query in a cold-cache window pays the 5s
# wait_for budget BEFORE the actual execute starts, which the user
# experienced as "query execution become slow".
_preval_timeout_until: dict = {}

# BF-575/591/592: see core/query_queue.py for the full lifecycle
# rationale.  This is the SAME dict object the QueueManager holds, so
# tests that mutate ``execute_api._pending_owner_by_req[k] = v`` are
# observed by the QueueManager's methods.
_pending_owner_by_req: dict = _queue_mgr._pending_owner_by_req


# Phase 139 honest-fix #3 refactor note:
# The helpers below have canonical extracted versions in:
#   core/executors/concurrency.py    — refusal_at / global_refusal, AdmissionRefusal
#   core/executors/spark_dispatch.py — should_use_spark_connect, get_spark_breaker
# NEW code SHOULD import from there. The wrappers here remain for back-compat with
# in-flight execute_api functions; they share state via core.execution_state.
def _global_active_query_count() -> int:
    """Sum of active queries across all users — single lock acquisition.
    BF-592: delegates to the QueueManager singleton (``inflight_total``)."""
    return _queue_mgr.inflight_total


def _spawn_duckdb_interrupt_watchdog(con, cancel_event: threading.Event,
                                      execution_id: str = "") -> threading.Event:
    """BF-262: cancel a running DuckDB query mid-execute via ``con.interrupt()``.

    Phase 131 deep-dive #13: implementation moved to ``core.duckdb_cancel``
    so the federation engine + reports RLS-rewrite path can reuse the same
    watchdog.  This shim preserves the existing call signature in
    execute_api.py (4 call sites) and the existing test fixture imports.
    """
    from core.duckdb_cancel import spawn_interrupt_watchdog as _shared
    return _shared(con, cancel_event, execution_id)


class _CrossSourceConnectorEngine:
    """BF-XSRC-CONN: a SQL-connector SIDE of a cross-source query.

    ``execute_cross_query_background`` runs each side through
    ``_exec_side_to_parquet``, which expects an engine-shaped object.  A
    connector side is not an engine: it is a connection plus the FINAL,
    SECURED statement to run on it, built by the route handler from raw_sql
    or a QueryConfig in that engine's dialect.

    2026-10-04 -- the side no longer streams through a private loop here.
    ``_exec_side_to_parquet`` hands it to THE cross-source side runner
    (``core.executors.cross_source_combine.run_side_to_parquet``: pooled
    connector -> ``connector_to_parquet``, bounded memory), the same runner
    the SQL page, federation views and reports use.  And it is now used for
    the PRIMARY too: a SQL-connector primary used to take the single-source
    branch and RETURN before the cross-source path, so its secondary was
    dropped and the answer came back 200 with the primary's rows only.
    """

    def __init__(self, connection: Dict[str, Any], sql: str,
                 chunk_size: int = 50000):
        self.connection = dict(connection or {})
        self.sql = sql
        self.chunk_size = chunk_size
        self._cancel_event = None
        # Mark so the cross-source code can detect it
        self._is_sql_connector_engine = True

    @property
    def connection_type(self) -> str:
        return str(self.connection.get("connection_type") or "").lower()

    def with_sql(self, sql: str) -> "_CrossSourceConnectorEngine":
        """The same side running a different statement (semi-join pushdown)."""
        return _CrossSourceConnectorEngine(self.connection, sql,
                                           chunk_size=self.chunk_size)

    def set_cancel_event(self, ev):
        self._cancel_event = ev

    def _needs_duckdb(self, _config):
        return False


async def _await_with_heartbeat(future, *, execution_id: str, executed_by: str,
                                 ws_manager, interval_seconds: float = 15.0,
                                 raw_sql_for_estimate: Optional[str] = None,
                                 connection_id_for_estimate: Optional[int] = None):
    """Await ``future`` while emitting a periodic WS+log heartbeat.

    BF-250: For engines that block in DuckDB without yielding chunks
    (``COUNT(DISTINCT)``, large ``GROUP BY`` / ``ORDER BY``, full table
    scans), no progress callback fires for the entire execution.  This
    helper keeps the user informed: every ``interval_seconds`` it logs the
    elapsed time and broadcasts an ``execution_progress`` WS message with
    ``data.status='running'`` and ``data.elapsed_seconds``.

    The heartbeat task is cancelled cleanly when the future completes
    (success, failure, or cancellation).  Exceptions inside the broadcast
    are swallowed so a transient WS error never affects query execution.
    """
    _hb_t0 = _time.monotonic()
    _hb_stop = asyncio.Event()

    # BF-290: hard query budget — auto-cancel queries that exceed the
    # configured ceiling so users don't sit watching "elapsed=1516s".
    # Reads from config.json: limits.hard_query_budget_seconds (declared
    # 0 = disabled -- see the _DEFAULTS comment; set e.g. 14400 for a 4 h
    # deployment-wide ceiling).  When the budget is hit:
    #   1. Set the cancel_event passed in by the caller (interrupts
    #      DuckDB via BF-262 watchdog).
    #   2. Broadcast a structured 'execution_budget_exceeded' WS message
    #      so the UI can show an actionable error with suggestions.
    #   3. The engine call returns with an InterruptedError; the caller
    #      handles the failure path normally.
    try:
        from core.config import get as _hb_cfg_get
        _hb_budget = int(_hb_cfg_get("limits", "hard_query_budget_seconds", 0) or 0)
    except Exception:
        _hb_budget = 1800

    # The budget watchdog needs the cancel_event for THIS execution.
    # It's stashed in the worker_pool record; look it up via execution_id.
    def _budget_cancel_event():
        try:
            from core.worker_pool import get_pool
            _wp = get_pool()
            if _wp:
                _rec = _wp.get_active(execution_id) if hasattr(_wp, "get_active") else None
                if _rec and getattr(_rec, "cancel_event", None) is not None:
                    return _rec.cancel_event
        except Exception:
            pass
        return None

    # BF-295: hard cap so the heartbeat self-terminates after cancel.
    # Symptom: user sees "Query still running…" broadcasts forever even
    # though they cancelled, because DuckDB / boto3 didn't reach a
    # cancel checkpoint.  After cancel_event is set, give the engine a
    # grace window; if the future hasn't completed by then, broadcast a
    # final "stalled" message and stop the loop so we don't spam.
    _CANCEL_GRACE_SECONDS = 30.0
    _cancel_observed_at: list = []  # closed-over mutable for the inner fn

    # 2026-07-15 "Why N files?" — fingerprint of the last brain_diagnostics
    # blob broadcast, so the heartbeat only carries it on CHANGE (usually
    # once per table, right after the pruning walk finishes).  This keeps
    # the per-tick payload small — see the NOTE below about why generic
    # stage extras were removed from the heartbeat.
    _last_brain_fp: list = [""]

    async def _heartbeat_loop():
        count = 0
        while not _hb_stop.is_set():
            try:
                await asyncio.wait_for(_hb_stop.wait(), timeout=interval_seconds)
                return  # stopped — engine finished
            except asyncio.TimeoutError:
                pass
            count += 1
            elapsed = _time.monotonic() - _hb_t0
            # BF-295: detect stuck-after-cancel and stop the heartbeat so
            # we don't broadcast forever for an unresponsive engine.
            try:
                _ce = _budget_cancel_event()
            except Exception:
                _ce = None
            if _ce is not None and _ce.is_set():
                if not _cancel_observed_at:
                    _cancel_observed_at.append(_time.monotonic())
                _since_cancel = _time.monotonic() - _cancel_observed_at[0]
                if _since_cancel >= _CANCEL_GRACE_SECONDS:
                    logger.warning(
                        "[execution %s] cancel_event set %.0fs ago but engine "
                        "hasn't returned — stopping heartbeat (engine is stalled)",
                        execution_id, _since_cancel,
                    )
                    try:
                        await ws_manager.broadcast_to_user(executed_by, {
                            "type":         "execution_progress",
                            "execution_id": execution_id,
                            "data": {
                                "status":          "stalled",
                                "elapsed_seconds": round(elapsed, 1),
                                "log": (
                                    f"Cancel sent {int(_since_cancel)}s ago but "
                                    "engine hasn't responded.  The query may be "
                                    "blocked in a non-cancellable section "
                                    "(boto3 download / DuckDB scan).  Server "
                                    "restart will free it."
                                ),
                            },
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        })
                    except Exception:
                        pass
                    return
            # BF-290: budget check fires every heartbeat tick (15s default
            # interval, so worst-case overshoot is interval_seconds).
            if _hb_budget > 0 and elapsed >= _hb_budget:
                _ce = _budget_cancel_event()
                if _ce is not None and not _ce.is_set():
                    logger.warning(
                        "[execution %s] hard query budget exceeded (%ds >= %ds) "
                        "— firing cancel_event", execution_id, int(elapsed), _hb_budget,
                    )
                    _ce.set()
                try:
                    await ws_manager.broadcast_to_user(executed_by, {
                        "type":         "execution_budget_exceeded",
                        "execution_id": execution_id,
                        "data": {
                            "elapsed_seconds": round(elapsed, 1),
                            "budget_seconds":  _hb_budget,
                            "log": (
                                f"Query exceeded the {_hb_budget}s budget — "
                                "cancelling.  See suggestions below."
                            ),
                            "suggestions": [
                                "Add a more selective WHERE filter "
                                "(partition columns or sort columns)",
                                "Enable s3_local_cache (Admin → Iceberg & S3 Cache) "
                                "so future runs serve from NFS cache",
                                "Compact the source tables — many small files = slow scan",
                                "Consider Spark Connect for queries that genuinely "
                                "need to scan thousands of files",
                                "Pre-compute as a materialised view if this query "
                                "runs on a schedule",
                            ],
                        },
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                except Exception:
                    pass
                # Don't return here — let the next heartbeat fire so the
                # cancel actually completes before the loop exits via
                # _hb_stop.set() in the finally below.
            # BF-289: read the per-stage tracker so the heartbeat tells
            # the user WHICH stage is consuming time, not just the total
            # elapsed seconds.  Without this they have no way to tell
            # "still downloading 3000 files via proxy" vs "GROUP BY hash
            # building" — both look identical at "1516s elapsed".
            try:
                from core.execution_stage import get_snapshot, humanise_stage
                snap = get_snapshot(execution_id) or {}
            except Exception:
                snap = {}
            _stage_label = humanise_stage(snap.get("stage", "")) if snap else "Running"
            _files_done = int(snap.get("files_done", 0))
            _files_total = int(snap.get("files_total", 0))
            _bytes_done = int(snap.get("bytes_done", 0))
            _stage_elapsed = float(snap.get("stage_elapsed_seconds", 0))
            _throughput = int(snap.get("throughput_bytes_per_sec", 0))

            # Compose a friendly progress line for the UI.
            _detail_parts = []
            if _files_total:
                _detail_parts.append(f"{_files_done:,} / {_files_total:,} files")
            elif _files_done:
                _detail_parts.append(f"{_files_done:,} files")
            if _bytes_done:
                _mb = _bytes_done / (1024 * 1024)
                _detail_parts.append(f"{_mb:.0f} MB")
            if _throughput and _bytes_done:
                _tp_mb = _throughput / (1024 * 1024)
                _detail_parts.append(f"{_tp_mb:.1f} MB/s")
            if _stage_elapsed:
                _detail_parts.append(f"{int(_stage_elapsed)}s in stage")
            _detail = " · ".join(_detail_parts) if _detail_parts else ""
            _msg = snap.get("message") or ""
            _log_line = f"{_stage_label}" + (f" — {_detail}" if _detail else "") + (f" — {_msg}" if _msg else "")

            logger.info(
                "[execution %s] heartbeat #%d — elapsed=%.1fs stage=%s %s",
                execution_id, count, elapsed,
                snap.get("stage", "?"), _detail or "(no progress yet)",
            )

            # Phase 141 honest-fix: stamp engine-progress so the smart
            # stale-cancel loop knows the engine is alive.  This is what
            # protects a 16-minute query from being killed when the
            # corporate-proxy drops the client WebSocket mid-query.  As
            # long as this heartbeat loop is running, the engine is
            # making progress and the execution must not be cancelled.
            try:
                from core.execution_state import record_engine_progress
                record_engine_progress(execution_id)
            except Exception as _ep_exc:
                logger.debug("[heartbeat %s] record_engine_progress failed: %s",
                              execution_id, _ep_exc)

            # Phase 141: emit JOIN-side size shape on the FIRST heartbeat so
            # users (and the engine router) can see whether their JOIN is
            # broadcast-shape, big×big, or balanced.  Computed once per
            # execution — the cached value is reused on subsequent ticks.
            if count == 1 and raw_sql_for_estimate:
                try:
                    from core.join_estimator import estimate_join_sides, format_for_log
                    _join_est = estimate_join_sides(
                        sql=raw_sql_for_estimate,
                        connection_id=connection_id_for_estimate,
                        db_manager=_db_manager,
                    )
                    if _join_est.get("is_join"):
                        _join_line = format_for_log(_join_est)
                        logger.info("[execution %s] %s", execution_id, _join_line)
                        try:
                            await ws_manager.broadcast_to_user(executed_by, {
                                "type":         "join_shape",
                                "execution_id": execution_id,
                                "data":         _join_est,
                                "log":          _join_line,
                                "timestamp":    datetime.now(timezone.utc).isoformat(),
                            })
                        except Exception as _ws_exc:
                            logger.debug("[join_shape] WS broadcast failed: %s", _ws_exc)
                except Exception as _je_exc:
                    logger.debug("[join-estimate] non-fatal: %s", _je_exc)
            # NOTE: do NOT include stage extras (pruning summary, config
            # dump, per-table timer) in the heartbeat WS payload — adding
            # them here grew the per-tick JSON serialisation and broadcast
            # work, and the user reported UI block + WS close after.  The
            # extras are still persisted in stage tracker and visible in
            # the per-query log file + post-execution chip; they just
            # don't ride the live heartbeat any more.
            #
            # 2026-07-15 "Why N files?" EXCEPTION — brain_diagnostics__* is
            # a deliberately COMPACT, capped summary (core/brain_diagnostics
            # caps columns + reason strings) and it is CHANGE-GATED: it only
            # rides a tick when the blob differs from the last one sent
            # (typically once per table after its pruning walk).  Steady-state
            # heartbeats stay exactly as small as before.
            _brain_payload = None
            try:
                from core.brain_diagnostics import extract_brain_diagnostics
                _brain_diag = extract_brain_diagnostics(snap.get("extras"))
                if _brain_diag:
                    try:
                        _brain_fp = json.dumps(_brain_diag, sort_keys=True,
                                               default=str)
                    except Exception:
                        _brain_fp = str(_brain_diag)
                    if _brain_fp != _last_brain_fp[0]:
                        _last_brain_fp[0] = _brain_fp
                        _brain_payload = _brain_diag
            except Exception as _bd_hb_exc:
                logger.debug("heartbeat brain_diagnostics skipped: %s",
                             _bd_hb_exc)
            try:
                await ws_manager.broadcast_to_user(executed_by, {
                    "type":         "execution_progress",
                    "execution_id": execution_id,
                    "data": {
                        "status":           "running",
                        "elapsed_seconds":  round(elapsed, 1),
                        # BF-289: structured stage info for the UI
                        "stage":            snap.get("stage") or "running",
                        "stage_label":      _stage_label,
                        "stage_elapsed_seconds": _stage_elapsed,
                        "files_done":       _files_done,
                        "files_total":      _files_total,
                        "bytes_done":       _bytes_done,
                        "throughput_bytes_per_sec": _throughput,
                        # Backwards-compatible plain-text log
                        "log":              _log_line or f"Query still running… {int(elapsed)}s elapsed",
                        "heartbeat":        count,
                        # 2026-07-15 "Why N files?" — compact per-table brain
                        # diagnostics, present ONLY on the tick where they
                        # changed (see change-gate above).  Additive field;
                        # older frontends ignore it.
                        **({"brain_diagnostics": _brain_payload}
                           if _brain_payload else {}),
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            except Exception as _hb_err:
                logger.debug("heartbeat broadcast failed: %s", _hb_err)

    _hb_task = asyncio.create_task(_heartbeat_loop())
    try:
        return await asyncio.wrap_future(future)
    finally:
        _hb_stop.set()
        if not _hb_task.done():
            _hb_task.cancel()
            try:
                await _hb_task
            except (asyncio.CancelledError, Exception):
                pass


_MO_DECLINE = object()   # sentinel: iceberg metadata-only path declines → fall through


def _iceberg_metadata_only_compute(iceberg_bucket, iceberg_table_prefix,
                                   iceberg_s3_cfg, kind, col):
    """SYNC — the iceberg metadata-only COUNT/MIN/MAX fast path: metadata.json +
    manifest-list + all manifests + avro decode + the merge-on-read delete-blind
    fail-closed guards.  Run via asyncio.to_thread (Fable GAP 2) so these
    SEQUENTIAL S3 GETs never freeze the single event loop.  Logic is
    byte-identical to the former inline block — only the decline signal differs
    (return False → return _MO_DECLINE).  Returns the computed value or
    _MO_DECLINE."""
    try:
        from core.iceberg_reader import (
            _read_s3_json_cached, _latest_metadata_key, _build_schema_index,
            _read_avro, _read_s3_bytes,
        )
        from core.metadata_only_optimizer import (
            iceberg_count_star, iceberg_min_max_from_stats,
        )
        if not iceberg_bucket or not iceberg_table_prefix:
            return _MO_DECLINE
        from core.s3_utilities import make_s3_client_for_config
        _s3 = make_s3_client_for_config(iceberg_s3_cfg)
        _meta_prefix = iceberg_table_prefix.rstrip("/") + "/metadata/"
        _meta_key = _latest_metadata_key(_s3, iceberg_bucket, _meta_prefix)
        _meta = _read_s3_json_cached(_s3, iceberg_bucket, _meta_key)
        _snap_id = _meta.get("current-snapshot-id")
        _snaps = {s.get("snapshot-id"): s for s in _meta.get("snapshots", [])}
        _snap = _snaps.get(_snap_id)
        if not _snap:
            return _MO_DECLINE
        _ml_path = _snap.get("manifest-list", "")
        _ml_key = _ml_path.split("s3://", 1)[1].split("/", 1)[1] if _ml_path.startswith("s3://") else _ml_path
        _ml_data = _read_s3_bytes(_s3, iceberg_bucket, _ml_key)
        _manifests = _read_avro(_ml_data)
        # F2-class fail-CLOSED: a corrupt/truncated manifest-list that decodes to
        # 0 entries would make the delete-check see "no deletes" and proceed
        # DELETE-BLIND (overcount) — decline instead.
        if _ml_data and not _manifests:
            logger.warning(
                "[metadata_only] manifest-list for %s decoded to 0 entries "
                "from %d bytes — declining fast path (fail-closed; avoids a "
                "delete-blind / overcounted COUNT).",
                iceberg_table_prefix, len(_ml_data),
            )
            return _MO_DECLINE
        # Iceberg V2 merge-on-read guard (fail-CLOSED): a manifest with
        # content != 0 carries DELETE files; data-file record_count/bounds know
        # nothing about them, so any COUNT/MIN/MAX here would include deleted
        # rows.  Decline entirely — the caller's normal path is MoR-correct.
        if any((m or {}).get("content", 0) != 0 for m in _manifests):
            logger.info(
                "[metadata_only] delete manifest(s) present for %s "
                "(V2 merge-on-read) — declining metadata-only fast "
                "path, falling through to normal execution",
                iceberg_table_prefix,
            )
            return _MO_DECLINE
        _manifests = [m for m in _manifests if m.get("content", 0) == 0]
        _all_entries = []
        for _m in _manifests:
            _mp = _m.get("manifest_path", "")
            _mk = _mp.split("s3://", 1)[1].split("/", 1)[1] if _mp.startswith("s3://") else _mp
            try:
                _md = _read_s3_bytes(_s3, iceberg_bucket, _mk)
                _all_entries.extend(_read_avro(_md))
            except Exception:
                return _MO_DECLINE  # bail — fall through to normal path

        result_value = None
        if kind == "count_star":
            result_value = iceberg_count_star(_meta, _snap, _all_entries)
            # Phase 139 honest-fix safety check — abort if count is dubious
            from core.metadata_only_optimizer import sanity_check_count
            _n_data = sum(
                1 for e in _all_entries
                if e.get("status") != 2 and (e.get("data_file") or {}).get("content", 0) == 0
            )
            if not sanity_check_count(result_value, _n_data):
                logger.warning(
                    "[metadata_only] count safety check failed (count=%s, n_files=%d) "
                    "for %s — falling through to normal execution",
                    result_value, _n_data, iceberg_table_prefix,
                )
                return _MO_DECLINE
        elif kind in ("min", "max") and col:
            _fid_to_type, _name_to_fid = _build_schema_index(_meta)
            result_value = iceberg_min_max_from_stats(
                col, kind, _all_entries, _fid_to_type, _name_to_fid,
            )
        if result_value is None:
            return _MO_DECLINE
        return result_value
    except Exception as _ice_err:
        logger.debug("metadata-only iceberg path failed (%s) — fall through", _ice_err)
        return _MO_DECLINE


async def _try_metadata_only_fast_path(
    *,
    execution_id: str,
    query_config,
    match: dict,
    executed_by: str,
    run_engine,
    output_file,
    query_id,
) -> bool:
    """Phase 139 audit-fix Gap 13 — answer COUNT(*)/MIN/MAX without data scan.

    Returns True if the fast path successfully answered the query (and the
    caller should return). False means the optimization didn't apply — caller
    falls through to normal execution.

    Resolves the single file ref to its underlying storage:
      * Iceberg table prefix → walk manifests, sum/min/max from data_file stats
      * Parquet path / glob → use pyarrow.read_metadata footer stats

    Writes a 1-row parquet output, updates DB status, broadcasts completion.
    """
    try:
        import pyarrow as _pa
        import pyarrow.parquet as _pq
    except Exception:
        return False

    try:
        # Resolve the file ref to an actual storage path. Phase 139 honest-fix:
        # the ref may be __registered__:tablename, __local__:tablename,
        # __materialized__:viewname, or a direct path/glob.
        f = query_config.files[0]
        path = f if isinstance(f, str) else getattr(f, "path", None)
        if not path:
            return False

        kind = match.get("kind")  # "count_star" | "min" | "max"
        col = match.get("col")
        col_name = "cnt" if kind == "count_star" else f"{kind}_{col or 'col'}"
        result_value = None
        is_iceberg = False

        # Resolve indirect refs to concrete file lists or table prefix
        local_paths: list = []
        iceberg_table_prefix = None
        iceberg_bucket = None
        iceberg_s3_cfg = None

        if path.startswith("__local__:"):
            # Local table → glob the storage dir for parquet files
            try:
                from core.config import local_tables as _lt_cfg
                _lt_storage = getattr(_lt_cfg, "storage_dir", None)
                if not _lt_storage:
                    return False
                _lt_name = path.replace("__local__:", "")
                # BF-598: was sync.
                _lt_rec = await adb(_db_manager.get_local_table_by_name, _lt_name)
                if not _lt_rec:
                    return False
                import glob as _g
                import os as _os
                local_paths = _g.glob(_os.path.join(_lt_storage, str(_lt_rec["id"]), "*.parquet"))
            except Exception:
                return False
        elif path.startswith("__materialized__:"):
            try:
                from core.config import materialized_views as _mv_cfg
                _mv_storage = getattr(_mv_cfg, "storage_dir", None)
                if not _mv_storage:
                    return False
                _mv_name = path.replace("__materialized__:", "")
                # BF-598: was sync.
                _mv_rec = await adb(_db_manager.get_materialized_view_by_name, _mv_name)
                if not _mv_rec:
                    return False
                import glob as _g
                import os as _os
                local_paths = _g.glob(_os.path.join(_mv_storage, str(_mv_rec["id"]), "*.parquet"))
            except Exception:
                return False
        elif path.startswith("__registered__:"):
            # Registered S3 table — could be Iceberg or parquet. Resolve via
            # connection_manager's registered-table list to get the s3_prefix +
            # format (iceberg or parquet).
            try:
                _reg_name = path.replace("__registered__:", "")
                _conn_id = getattr(run_engine, "_s3_conn_id", None)
                if not _conn_id:
                    return False
                from core.connection_manager import ConnectionManager as _CM
                _cm = _CM(_db_manager)
                _reg_tables = _cm.list_registered_tables(_conn_id) or []
                _tbl = next((t for t in _reg_tables if t.get("name") == _reg_name), None)
                if not _tbl:
                    return False
                _fmt = (_tbl.get("format") or "parquet").lower()
                _prefix = _tbl.get("s3_prefix", "").rstrip("/") + "/"
                iceberg_s3_cfg = getattr(run_engine, "_s3_conn_config", {}) or {}
                iceberg_bucket = iceberg_s3_cfg.get("bucket") or iceberg_s3_cfg.get("bucket_name", "")
                if not iceberg_bucket:
                    return False
                if _fmt == "iceberg":
                    is_iceberg = True
                    iceberg_table_prefix = _prefix
                else:
                    # Parquet — list files via boto3 (works on AWS + on-prem)
                    # 2026-09-01 -- neither name existed: the module has
                    # ``make_s3_client_for_conn`` and ``list_s3_parquet_files``
                    # (no leading underscore).  The ImportError declined this
                    # metadata-only COUNT every time, so it always fell back
                    # to reading the data -- correct, and far slower.
                    from core.s3_utilities import (
                        make_s3_client_for_config, list_s3_parquet_files)
                    _s3 = make_s3_client_for_config(iceberg_s3_cfg)
                    _files = list_s3_parquet_files(_s3, iceberg_bucket, _prefix.strip("/"))
                    if getattr(_files, "truncated", False):
                        # 2026-08-20 — the listing hit its file cap: a
                        # metadata-only COUNT over the subset would return
                        # a silently WRONG total with a success status.
                        # Decline the fast path; the full query path runs.
                        logger.warning(
                            "metadata-only fast path declined for '%s': "
                            "parquet listing truncated at %d files (subset)",
                            path, len(_files))
                        return False
                    local_paths = [
                        f"s3://{iceberg_bucket}/{x['key']}" if isinstance(x, dict) else x
                        for x in _files
                    ]
            except Exception:
                return False
        else:
            # Direct path — could be local glob, parquet file, or iceberg dir
            is_iceberg = "/metadata/" in path or path.rstrip("/").endswith("metadata")
            if not is_iceberg:
                import glob as _g
                from pathlib import Path as _P
                if "*" in path:
                    local_paths = _g.glob(path, recursive=True)
                elif _P(path).is_dir():
                    local_paths = _g.glob(str(_P(path) / "**" / "*.parquet"), recursive=True)
                else:
                    local_paths = [path] if _P(path).is_file() else []
            else:
                iceberg_s3_cfg = getattr(run_engine, "_s3_conn_config", {}) or {}
                iceberg_bucket = iceberg_s3_cfg.get("bucket") or iceberg_s3_cfg.get("bucket_name", "")
                iceberg_table_prefix = path.rstrip("/").replace("/metadata", "") + "/"

        if is_iceberg:
            # GAP 2 (2026-07-22): the metadata-only COUNT/MIN/MAX manifest walk
            # (sequential S3 GETs + avro decode) used to run inline on the
            # asyncio loop and froze it for a large table.  Offloaded to a
            # thread; the merge-on-read delete-blind fail-closed guards are
            # unchanged inside _iceberg_metadata_only_compute.
            _mo = await asyncio.to_thread(
                _iceberg_metadata_only_compute,
                iceberg_bucket, iceberg_table_prefix, iceberg_s3_cfg, kind, col,
            )
            if _mo is _MO_DECLINE:
                return False
            result_value = _mo

        else:
            # Parquet path — count_star via footer; min/max via row-group stats.
            # local_paths is already resolved (LT/MV/registered/glob/file).
            # If S3 paths (s3://) — fetch metadata via boto3 footer-stats helper
            # so on-prem S3 works the same as AWS (no DuckDB httpfs dependency).
            try:
                paths = local_paths or []
                if not paths:
                    return False

                # Helper to read metadata for either local OR s3:// path.
                # For s3://: use the existing s3_footer_stats helper which goes
                # through boto3 (works on AWS + on-prem MinIO/Ceph).
                def _read_md_any(p):
                    if isinstance(p, str) and p.startswith("s3://"):
                        if iceberg_s3_cfg is None:
                            return None
                        from core.s3_utilities import make_s3_client_for_config
                        _ss = make_s3_client_for_config(iceberg_s3_cfg)
                        # Tail-read of parquet footer via boto3 ranged GET.
                        # 256 KiB tail covers most schemas.
                        _b = p.split("s3://", 1)[1].split("/", 1)
                        _bk = _b[0]
                        _ky = _b[1] if len(_b) > 1 else ""
                        try:
                            head = _ss.head_object(Bucket=_bk, Key=_ky)
                            size = int(head.get("ContentLength", 0))
                            tail = min(size, 256 * 1024)
                            obj = _ss.get_object(
                                Bucket=_bk, Key=_ky,
                                Range=f"bytes={size - tail}-{size - 1}",
                            )
                            tail_bytes = obj["Body"].read()
                            import pyarrow as _pa2
                            buf = _pa2.py_buffer(tail_bytes)
                            return _pq.read_metadata(_pa2.BufferReader(buf))
                        except Exception:
                            return None
                    try:
                        return _pq.read_metadata(p)
                    except Exception:
                        return None

                # BF-410: the per-file boto3 head_object + get_object loops
                # below were running ON the asyncio event loop.  For a 50-file
                # table that's 100 sync HTTP round-trips × ~100ms each =
                # 10s of pure event-loop block.  Wrap the whole loop in
                # to_thread so other endpoints stay responsive.
                if kind == "count_star":
                    def _count_all():
                        total = 0
                        for p in paths:
                            md = _read_md_any(p)
                            if md is None:
                                return None
                            total += md.num_rows
                        return total
                    total = await asyncio.to_thread(_count_all)
                    if total is None:
                        return False
                    result_value = total
                elif kind in ("min", "max") and col:
                    op = min if kind == "min" else max
                    def _scan_min_max():
                        cands = []
                        for p in paths:
                            md = _read_md_any(p)
                            if md is None:
                                return None
                            for rg_idx in range(md.num_row_groups):
                                rg = md.row_group(rg_idx)
                                for c_idx in range(rg.num_columns):
                                    c = rg.column(c_idx)
                                    if c.path_in_schema != col:
                                        continue
                                    s = c.statistics
                                    if s is None or not s.has_min_max:
                                        continue
                                    cands.append(s.min if kind == "min" else s.max)
                        return cands
                    cands = await asyncio.to_thread(_scan_min_max)
                    if cands is None or not cands:
                        return False
                    result_value = op(cands)
            except Exception as _pq_err:
                logger.debug("metadata-only parquet path failed (%s) — fall through", _pq_err)
                return False

        if result_value is None:
            return False

        # Build a 1-row parquet output so /results works
        import pandas as _pd
        df = _pd.DataFrame({col_name: [result_value]})
        try:
            tbl = _pa.Table.from_pandas(df, preserve_index=False)
        except Exception:
            tbl = _pa.table({col_name: [result_value]})
        output_file.parent.mkdir(parents=True, exist_ok=True)
        _pq.write_table(tbl, output_file, compression="zstd")
        file_size = output_file.stat().st_size

        # Update DB + broadcast.  BF-591: was sync; metadata-only fast-path
        # is on the event loop.
        await adb(_db_manager.update_execution,
            execution_id, status="completed",
            total_rows=1, chunks_processed=1,
            output_file=str(output_file),
            file_size_bytes=file_size,
        )
        from core.metrics import qs_files_skipped_total, record_time_to_first_row
        from core.safe_exec import silent_log
        with silent_log("metadata_only.prometheus_record"):
            qs_files_skipped_total.labels(source="iceberg" if is_iceberg else "parquet",
                                           reason="metadata_only_answered").inc(1)
            record_time_to_first_row("metadata_only", 0.05)
        await _ws_manager.broadcast_to_user(executed_by, {
            "type":         "execution_completed",
            "execution_id": execution_id,
            "total_rows":   1,
            "stats":        {"total_rows": 1, "file_size_bytes": file_size,
                             "metadata_only": True},
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
        if query_id:
            with silent_log("metadata_only.increment_execution_count"):
                # BF-591: was sync.
                await adb(_db_manager.increment_execution_count, query_id)
        logger.info(
            "[metadata_only] answered '%s' on %s without data scan → %s",
            kind, path, result_value,
        )
        return True

    except Exception as exc:
        logger.debug("metadata-only fast path inner failure (%s)", exc)
        return False


# 2026-09-28: ``_check_load_shed`` (the inline check-then-act copy of the
# global load-shed) is GONE.  The global cap is decided inside
# ``QueueManager.acquire_slot`` under the lock that grants the slot -- see
# ``core/executors/concurrency.py`` for the rule and the defect it closes.

# ── Spark Connect (Phase SC) ────────────────────────────────────────────────
# Circuit breaker for the Spark Connect server.  Opened after N consecutive
# failures; closed automatically after the cooldown period.
class _SparkBreaker:
    """Minimal circuit breaker for the Spark Connect server."""
    import time as _t
    import threading as _th

    def __init__(self, threshold: int = 3, cooldown: int = 120):
        import threading
        self._threshold = threshold
        self._cooldown  = cooldown
        self._failures  = 0
        self._opened_at = 0.0
        self._state     = "closed"
        self._lock      = threading.Lock()

    @property
    def is_open(self) -> bool:
        import time
        with self._lock:
            if self._state == "open":
                if time.time() - self._opened_at > self._cooldown:
                    self._state = "half_open"
                    return False
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._state = "closed"

    def record_failure(self) -> None:
        import time
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._state = "open"
                self._opened_at = time.time()
                logger.warning(
                    "[spark_connect] Circuit breaker OPEN after %d failures",
                    self._failures,
                )

    def reset(self) -> None:
        with self._lock:
            self._failures = 0
            self._state = "closed"
            self._opened_at = 0.0


_spark_breaker: Optional[_SparkBreaker] = None  # created lazily on first check

# 2026-09-27 -- WHICH ENGINE ANSWERED.  One vocabulary
# (core/engine_attribution.py), stamped on the query_executions row AND on
# the execution_completed event at the same site, so the Executions page,
# the grid chip and the toast can never disagree.  Imported by name here so
# every completion site below spells the call the same way.
from core.engine_attribution import (                       # noqa: E402
    engine_for_connector as _engine_for_connector,
    with_engine as _with_engine,
)


def _engine_key_for_completion(stats: Optional[dict]) -> str:
    """The engine key for the DuckDB lane's completion, from the stats the
    engine returned: a stamped ``engine_meta.engine`` wins (the engine said
    so itself), else parallel / cache / single-worker as the ``__engine_meta__``
    block above has always decided them.  Never ``None`` on this lane -- the
    query ran HERE, so "not recorded" would be false."""
    s = stats or {}
    meta = s.get("engine_meta") if isinstance(s.get("engine_meta"), dict) else {}
    key = str((meta or {}).get("engine") or "").strip()
    if key:
        return key
    if s.get("from_multi_worker"):
        return "multi_worker"
    if s.get("from_cache"):
        return "result_cache"
    return "duckdb"


# Messages broadcast to the user when the query falls back to DuckDB.
# The user sees WHY the engine switched — not just a silent downgrade.
_SPARK_FALLBACK_MESSAGES: dict = {
    # 2026-09-27 -- silent: a deployment that never enabled Spark Connect is
    # not an event, and this went to the user on EVERY S3 query (rig WS check).
    "disabled":            None,
    "not_s3":              "Spark Connect supports S3 connections only — using DuckDB.",
    "cross_connection":    (
        "Cross-connection queries use DuckDB — "
        "Spark Connect supports single-connection S3 only."
    ),
    "circuit_breaker_open": (
        "Spark Connect server is temporarily unavailable — using DuckDB. "
        "Query may be slower for large datasets."
    ),
    "below_threshold":     None,   # silent — normal DuckDB range
    "user_override":       None,   # user asked for DuckDB explicitly
    "iceberg_format":      (
        "Iceberg tables run on DuckDB — the Spark path reads Iceberg data "
        "as plain parquet (snapshots and delete files are not applied), "
        "which would return incorrect results."
    ),
}


def _query_references_iceberg_table(
    query_config_dict: Optional[dict],
    registered_tables: Optional[list],
) -> bool:
    """Iceberg-format safety floor for Spark routing (2026-07-15).

    The Spark Connect executor and the Airflow feed DAG read S3 data via
    ``session.read.parquet(prefix)`` — a plain-parquet scan that is both
    snapshot-blind (reads every historical file under the prefix) and
    delete-blind (Iceberg V2 merge-on-read delete files are never applied).
    Routing an Iceberg table to Spark therefore silently over-counts.
    Until the Spark executors read through a real Iceberg catalog, any
    query referencing a registered iceberg-format table must stay on the
    native/DuckDB path (MoR-correct via the iceberg_reader view chokepoint).

    Narrow by design: only returns True when a referenced registered table
    is KNOWN to be format == "iceberg".  Plain-parquet / connector routing
    is unchanged.  Returns False on any resolution error so unexpected
    shapes preserve existing routing behaviour.
    """
    try:
        iceberg_names = set()
        for t in (registered_tables or []):
            try:
                if str(t.get("format") or "parquet").lower() == "iceberg":
                    n = str(t.get("name") or "").strip().lower()
                    if n:
                        iceberg_names.add(n)
            except AttributeError:
                continue
        if not iceberg_names:
            return False
        qcd = query_config_dict or {}

        def _reg_name(ref) -> Optional[str]:
            p = ref if isinstance(ref, str) else (
                ref.get("path") if isinstance(ref, dict)
                else getattr(ref, "path", None)
            )
            if isinstance(p, str) and p.startswith("__registered__:"):
                return p[len("__registered__:"):].strip().lower()
            return None

        for f in (qcd.get("files") or []):
            r = _reg_name(f)
            if r and r in iceberg_names:
                return True
        for j in (qcd.get("joins") or []):
            rf = j.get("right_file") if isinstance(j, dict) else getattr(j, "right_file", None)
            r = _reg_name(rf)
            if r and r in iceberg_names:
                return True
        # BQB raw SQL references registered tables by bare/quoted name with
        # no structured files entry — scan the SQL against the iceberg set.
        raw = qcd.get("raw_sql") or qcd.get("custom_sql") or ""
        if raw:
            try:
                from core.query_hints import extract_referenced_tables
                for r in (extract_referenced_tables(registered_tables, raw) or []):
                    if str(r).strip().lower() in iceberg_names:
                        return True
            except Exception as _sql_ref_exc:
                logger.debug(
                    "[spark_connect] iceberg floor raw-SQL scan failed "
                    "(floor skipped for SQL refs): %s", _sql_ref_exc,
                )
        return False
    except Exception:
        return False


def _get_spark_breaker() -> _SparkBreaker:
    """Return (creating lazily) the module-level Spark circuit breaker."""
    global _spark_breaker
    if _spark_breaker is None:
        try:
            from core.config import spark_connect as _sc
            _spark_breaker = _SparkBreaker(
                threshold=_sc.circuit_breaker_failure_threshold,
                cooldown=_sc.circuit_breaker_cooldown_seconds,
            )
        except Exception:
            _spark_breaker = _SparkBreaker()
    return _spark_breaker


def _should_use_spark_connect(
    engine_override: Optional[str],
    conn_config: dict,
    estimated_rows: int,
    query_config_dict: Optional[dict],
    registered_tables: Optional[list] = None,
) -> tuple:
    """Return ``(use_spark: bool, reason: str)`` for the routing decision.

    Gates evaluated in order — first decisive answer wins:
      1. ``engine_override`` from API body (operator-direct)
      2. SQL hint ``/*+ spark */`` or ``-- @engine=spark``
      3. ``spark_connect.routing_rules`` config (per-table / per-pattern)
      4. ``spark_connect.enabled = false`` → off (safety floor)
      5. Connection type ≠ s3 (safety floor)
      6. Cross-connection query (safety floor)
      7. Iceberg-format table referenced (safety floor — Spark reads
         Iceberg as plain parquet: snapshot- and delete-blind → wrong
         results; applies even to explicit ``engine_override='spark'``)
      8. Circuit breaker open (safety floor)
      9. ``estimated_rows <= row_threshold`` (default fallback gate)
      10. (implicit) all gates passed → use Spark

    Routing rules (step 3) can force Spark above the row_threshold gate
    BUT can never bypass safety floors (4-8).  This keeps operator
    control while protecting against misconfig.

    The ``reason`` string is either empty (use Spark) or a short code
    used by ``_SPARK_FALLBACK_MESSAGES`` (use DuckDB).
    """
    try:
        from core.config import spark_connect as _sc
    except Exception:
        return False, "disabled"

    if engine_override == "duckdb":
        return False, "user_override"

    # 2026-07-15 iceberg-format safety floor — resolve the registered-table
    # list once.  The caller passes run_engine._registered_tables; when not
    # supplied (admin simulator / older callers) fall back to the list on
    # the connection config itself.
    _reg_tables_for_floor = (
        registered_tables if registered_tables is not None
        else (conn_config or {}).get("registered_tables")
    )

    if engine_override == "spark":
        # Explicit user override forces Spark Connect even when ``enabled=false``
        # is the global default — admins can still gate it via SSRF + circuit
        # breaker.  We still need a non-empty conn_config for the executor to
        # resolve s3a:// paths.
        if not (conn_config or {}):
            return False, "not_s3"
        # Iceberg floor beats even the explicit override — the Spark
        # executor reads Iceberg prefixes as plain parquet (snapshot- and
        # delete-blind), so honouring the override would silently return
        # wrong data.  Fail-CLOSED: route to DuckDB, which is MoR-correct.
        if _query_references_iceberg_table(query_config_dict, _reg_tables_for_floor):
            return False, "iceberg_format"
        return True, ""

    # ── New Phase 151 follow-up — config-driven routing rules ──────
    # SQL hint + routing_rules evaluated BEFORE the threshold gate so
    # a rule like {"match_table_name": "fact_table", "engine": "spark"}
    # can override a low row estimate (e.g. forced for known-bad layout
    # even when DuckDB *could* handle the rows).
    _routing_engine_hint: Optional[str] = None
    _routing_reason: str = ""
    try:
        from core.spark_routing_rules import decide_engine as _decide
        _raw_sql_for_rules = (
            (query_config_dict or {}).get("raw_sql")
            or (query_config_dict or {}).get("custom_sql")
            or ""
        )
        _file_count = len(
            ((query_config_dict or {}).get("files") or [])
        )
        _routing = _decide(
            sql=_raw_sql_for_rules,
            file_count=_file_count,
            row_estimate=int(estimated_rows or 0),
        )
        if _routing.engine in ("spark", "duckdb"):
            _routing_engine_hint = _routing.engine
            _routing_reason = (
                f"{_routing.source}: {_routing.reason}"
            )[:200]
    except Exception as _rr_exc:
        logger.debug(
            "[spark_connect] routing rules eval failed (fall through): %s",
            _rr_exc,
        )

    if _routing_engine_hint == "duckdb":
        return False, f"routing_rule:{_routing_reason}"

    # Safety floors — apply regardless of routing rule decision.
    # spark_connect.enabled=false is the MASTER kill switch: no rule
    # can bypass it.  Audit fix 2026-06-10 — earlier version let a
    # rule with engine='spark' override the disabled flag, which made
    # "disable Spark globally during incident" not actually disable
    # Spark for tables with rules.  That was a footgun; the master
    # flag now wins unconditionally.
    if not _sc.enabled:
        return False, "disabled"
    _is_s3 = bool((conn_config or {}).get("bucket")) or bool((conn_config or {}).get("bucket_name"))
    if not _is_s3:
        return False, "not_s3"
    if (query_config_dict or {}).get("cross_connection_id"):
        return False, "cross_connection"
    # Safety floor (2026-07-15): queries referencing a registered
    # iceberg-format table never route to Spark — the Spark Connect
    # executor does session.read.parquet(prefix), which is snapshot- and
    # delete-blind (Iceberg V2 MoR delete files ignored → silent
    # overcount).  Routing rules cannot bypass this, same as the other
    # floors.  Narrow: plain-parquet / connector routing is unchanged.
    # This floor can be lifted once the Spark executors read through a
    # real Iceberg catalog.
    if _query_references_iceberg_table(query_config_dict, _reg_tables_for_floor):
        return False, "iceberg_format"
    if _get_spark_breaker().is_open:
        return False, "circuit_breaker_open"

    if _routing_engine_hint == "spark":
        # Rule forced Spark and all safety floors passed.
        return True, ""

    # Default fallback gate.
    if estimated_rows < 0 or estimated_rows <= _sc.row_threshold:
        return False, "below_threshold"

    return True, ""


async def _execute_via_spark_connect(
    execution_id: str,
    query_config,
    conn_config: dict,
    output_file: Path,
    executed_by: str,
    raw_sql: Optional[str],
    progress_callback,
) -> dict:
    """Dispatch to spark_connect_executor.execute_query() and return result stats.

    On success: records circuit breaker success, returns metrics dict.
    On failure: records circuit breaker failure, re-raises (caller falls back to DuckDB).
    """
    from core.spark_connect_executor import execute_query as _sc_execute

    # ── SQL dialect translation: foreign dialect → Spark SQL ─────────────────
    # The upstream ``execute_query_background`` already translated raw_sql
    # for the DuckDB path.  When we route to Spark Connect we need Spark SQL
    # — re-translate the ORIGINAL user SQL so we don't double-translate.  In
    # practice, since we've already replaced raw_sql with the DuckDB-translated
    # form, we translate from "auto" again (sqlglot is reasonably idempotent
    # for common functions; DuckDB-specific syntax that doesn't exist in
    # Spark falls back to the original on error).
    if raw_sql:
        try:
            from core.sql_dialect_translator import translate_to_spark as _to_spark
            _spark_sql, _detected = _to_spark(raw_sql)
            if _detected:
                logger.info("[spark_connect] SQL dialect '%s' translated → spark", _detected)
            raw_sql = _spark_sql
        except Exception as _ts_err:
            logger.debug("[spark_connect] dialect translation skipped (fail-open): %s", _ts_err)

    cancel_event = asyncio.Event()

    async def _on_progress(data: dict) -> None:
        # Multi-pod prep PR1: publish to event bus.  In single-pod mode
        # the bus subscriber forwards to the local ws_manager (same end
        # result).  In multi-pod future, the WebSocket pod subscribes
        # directly via PG LISTEN.  Dual-write keeps backward compat
        # during the transition.
        from core.event_bus import publish as _eb_publish
        _eb_publish("execution_progress", {
            "execution_id": execution_id,
            "data":         {**data, "engine": "spark_connect"},
        }, username=executed_by)
        # Keep direct in-process call too — eliminated in PR4 once
        # WebSocket pod is the only WS terminator.
        await _ws_manager.broadcast_to_user(executed_by, {
            "type":         "execution_progress",
            "execution_id": execution_id,
            "data":         {**data, "engine": "spark_connect"},
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })

    try:
        # Retrieve agent orchestrator if agents are enabled (fail-open)
        _agent_orch = None
        try:
            from core.agents.orchestrator import get_orchestrator
            _agent_orch = get_orchestrator()
        except Exception:
            pass

        metrics = await _sc_execute(
            username=executed_by,
            query_config=query_config,
            conn_config=conn_config,
            output_path=str(output_file),
            on_progress=_on_progress,
            cancel_event=cancel_event,
            raw_sql=raw_sql,
            agent_orchestrator=_agent_orch,
        )
        _get_spark_breaker().record_success()
        return metrics

    except Exception:
        _get_spark_breaker().record_failure()
        raise

# Phase 102-C — per-user daily quota cache (value, cached_at_epoch, date_key).
# TTL-bounded so quota enforcement never adds a DB hit per execute request.
_daily_quota_cache: dict = {}
_daily_quota_cache_lock = threading.Lock()


def _get_cached_daily_count(username: str) -> int:
    """Return today's execution count for a user, cached for N seconds.

    TTL comes from ``admin_governance.daily_quota_cache_ttl_seconds`` (default 60s).
    Cache entry is invalidated automatically when the UTC date rolls over.
    Returns 0 if the DB manager is not ready (fail-open — never blocks queries).
    """
    if _db_manager is None:
        return 0
    try:
        from core.config import admin_governance as _gov
        ttl = _gov.daily_quota_cache_ttl_seconds
    except Exception:
        ttl = 60
    now = _time.time()
    today_key = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    with _daily_quota_cache_lock:
        entry = _daily_quota_cache.get(username)
        if entry is not None:
            value, cached_at, date_key = entry
            if date_key == today_key and (now - cached_at) < ttl:
                return value
        try:
            value = _db_manager.count_executions_today(username=username)
        except Exception:
            return 0
        _daily_quota_cache[username] = (value, now, today_key)
        return value


def _bump_daily_quota_cache(username: str) -> None:
    """Optimistically increment the cached daily count after a successful submit.

    Keeps the fast-path counter up-to-date between DB refreshes so that a user
    cannot burst past their quota within the TTL window.
    """
    today_key = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    now = _time.time()
    with _daily_quota_cache_lock:
        entry = _daily_quota_cache.get(username)
        if entry is None or entry[2] != today_key:
            _daily_quota_cache[username] = (1, now, today_key)
        else:
            _daily_quota_cache[username] = (entry[0] + 1, entry[1], today_key)


def set_execute_dependencies(db_manager, ws_manager, engine, paths, qe_cfg,
                             limits_cfg, s3_config, query_executor,
                             get_light_executor_fn):
    """Call once from main.py _startup() after all components are initialised."""
    global _db_manager, _ws_manager, _engine, _paths, _qe_cfg
    global _limits_cfg, _s3_config, _query_executor, _get_light_executor_fn
    _db_manager = db_manager
    _ws_manager = ws_manager
    _engine = engine
    _paths = paths
    _qe_cfg = qe_cfg
    _limits_cfg = limits_cfg
    _s3_config = s3_config
    _query_executor = query_executor
    _get_light_executor_fn = get_light_executor_fn
    # BF-592: wire the QueueManager's broadcast callback now that the
    # WS manager is initialised.  Before this point broadcasts are
    # silent no-ops (safe for startup + tests that don't init WS).
    _queue_mgr.set_broadcast_fn(_broadcast_queue_event)

    # BF-599 (2026-05-30): wire the multi-worker state-change callback
    # so worker progress flows to the user's WebSocket WITHOUT requiring
    # admin auth on /api/admin/multi-worker/active.  Each state change
    # (starting → setup → running → completed/failed) becomes a
    # ``multi_worker_progress`` WS event scoped to the execution's
    # owner.  The BQB / CQB ExecutionPerformanceChip consumes these.
    try:
        from core.multi_worker_executor import set_state_change_callback as _set_mw_cb
        _set_mw_cb(_broadcast_multi_worker_state)
    except Exception as _mw_wire_exc:
        logger.warning("BF-599: multi-worker WS broadcast wire failed: %s",
                       _mw_wire_exc)

    # SCAN-STRATEGY (2026-06-01): wire dispatcher's scan-plan-decided
    # callback.  Mirrors the BF-599 pattern above — fires once per
    # query when the ScanStrategist commits to a profile, then the
    # frontend renders a "BULK_SCAN: 16 workers, largest-first" chip
    # alongside the engine chip so users can see *why* they got the
    # execution shape they did.
    try:
        from core.multi_worker_dispatcher import set_scan_plan_callback as _set_sp_cb
        _set_sp_cb(_broadcast_scan_plan_decision)
    except Exception as _sp_wire_exc:
        logger.warning("[scan-strategy] WS broadcast wire failed: %s",
                       _sp_wire_exc)

    # SCAN-STRATEGY round 9 — wire prewarm-stage callback so frontend
    # can render a DISTINCT prewarm chip instead of lumping the 30s-
    # 250s of HEAD storms under "executing".  Events fire on prewarm
    # start, prewarm done, and prewarm-skipped-recent (when the recent-
    # prewarm cache short-circuits).
    try:
        from core.multi_worker_dispatcher import (
            set_prewarm_progress_callback as _set_pw_cb,
        )
        _set_pw_cb(_broadcast_prewarm_progress)
    except Exception as _pw_wire_exc:
        logger.warning("[scan-strategy] prewarm WS broadcast wire failed: %s",
                       _pw_wire_exc)


def _broadcast_multi_worker_state(state: dict) -> None:
    """BF-599: callback invoked from multi-worker thread whenever
    `_set_worker_state` is called.  Pushes the snapshot to the user
    owning the execution via the BF-589 capped broadcast_to_user_sync
    (so a stuck event loop can't be DoS'd by N workers × per-statement
    state changes).

    Runs in a WORKER THREAD — must be thread-safe.  Lookup uses the
    correlation_id (= execution_id) to find the owner; we cache the
    owner on first lookup to avoid hammering the DB.
    """
    if _ws_manager is None:
        return
    correlation_id = state.get("correlation_id") or ""
    if not correlation_id:
        return
    # BF-599g (2026-05-31): _MW_OWNER_CACHE access is now lock-protected.
    # Round-1 deep-dive flagged a TOCTOU race: thread A read len()>=MAX,
    # thread B popped, thread A's `next(iter())` then raced an
    # empty dict.  GIL alone doesn't bridge the read→write window.
    with _MW_OWNER_CACHE_LOCK:
        owner = _MW_OWNER_CACHE.get(correlation_id)
    if owner is None:
        # Lookup once + cache.  Don't block the worker thread — if the
        # owner isn't known yet (race with execution insert), skip.
        try:
            if _db_manager is None:
                return
            _exec_row = _db_manager.get_execution(correlation_id)
            owner = (_exec_row or {}).get("executed_by", "") or ""
            if owner:
                # BF-599e/g: FIFO eviction under lock so the check-then-pop
                # sequence is atomic.  Python 3.7+ dicts preserve insertion
                # order; pop(next(iter())) trims the oldest entry.
                with _MW_OWNER_CACHE_LOCK:
                    while len(_MW_OWNER_CACHE) >= _MW_OWNER_CACHE_MAX:
                        try:
                            _oldest = next(iter(_MW_OWNER_CACHE))
                            _MW_OWNER_CACHE.pop(_oldest, None)
                        except StopIteration:
                            # Race-safe: another thread emptied the dict
                            # between our len() and iter() — fine, the
                            # while-loop condition handles it on next pass.
                            break
                    _MW_OWNER_CACHE[correlation_id] = owner
        except Exception as _lookup_exc:
            # BF-599g: log the lookup failure so silent first-100ms event
            # loss doesn't go unnoticed.  Was previously a bare `return`
            # which hid DB connection / pool exhaustion.
            logger.debug(
                "BF-599g: _MW_OWNER_CACHE lookup raised for execution %s: %s",
                correlation_id, _lookup_exc,
            )
            return
    if not owner:
        return
    try:
        # BF-599g (2026-05-31): sanitize free-form text fields before
        # broadcast.  running_detail comes from sampling a Python stack
        # frame — even though _summarise_stack_frame skips internal
        # frames, a frame deep inside boto3 / urllib3 / requests could
        # expose AWS keys or proxy creds visible in the frame's locals
        # via repr().  error comes from worker exceptions which (per
        # phase 119 audit) may contain proxy URLs with embedded creds.
        # Reuses the existing sanitizer from core.error_sanitizer.
        try:
            from core.error_sanitizer import sanitize_error as _sanitize
        except Exception:
            _sanitize = lambda s: s   # fail-open: prefer event delivery over redaction
        _detail = state.get("running_detail")
        _err    = state.get("error")
        _setup_cur = state.get("setup_current")
        _ws_manager.broadcast_to_user_sync(owner, {
            "type":         "multi_worker_progress",
            "execution_id": correlation_id,
            "worker": {
                "chunk_index":    state.get("chunk_index"),
                "state":          state.get("state"),
                "files_count":    state.get("files_count"),
                "setup_step":     state.get("setup_step"),
                "setup_total":    state.get("setup_total"),
                "setup_current":  _sanitize(_setup_cur) if isinstance(_setup_cur, str) else _setup_cur,
                # BF-599d: heartbeat-sampled stack frame + how long
                # the SAME frame has been on top.  Lets the UI show
                # "currently in: iceberg_reader.py:412 — stuck 95s"
                # instead of opaque "running".
                # BF-599g: sanitised — see comment above.
                "running_detail": _sanitize(_detail) if isinstance(_detail, str) else _detail,
                "stuck_s":        state.get("stuck_s"),
                "rows":           state.get("rows"),
                "error":          _sanitize(_err) if isinstance(_err, str) else _err,
                "elapsed_s":      round(
                    (state.get("updated_at", 0)
                     - state.get("started_at", 0)) or 0, 2,
                ),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
    except Exception as _bx:
        logger.debug("BF-599: broadcast multi_worker_progress failed: %s", _bx)


def _broadcast_scan_plan_decision(plan: dict) -> None:
    """SCAN-STRATEGY (2026-06-01): broadcast the dispatcher's per-query
    plan-decision to the execution's owner.

    Reuses the ``_MW_OWNER_CACHE`` lookup chain so plan events ride the
    same owner-resolution path as worker-state events — no duplicate
    DB hammering.  Best-effort: any failure is swallowed at DEBUG so a
    broken WS layer can never block query execution.
    """
    if _ws_manager is None:
        return
    execution_id = plan.get("execution_id") or ""
    if not execution_id:
        return
    with _MW_OWNER_CACHE_LOCK:
        owner = _MW_OWNER_CACHE.get(execution_id)
    if owner is None:
        try:
            if _db_manager is None:
                return
            _exec_row = _db_manager.get_execution(execution_id)
            owner = (_exec_row or {}).get("executed_by", "") or ""
            if owner:
                with _MW_OWNER_CACHE_LOCK:
                    while len(_MW_OWNER_CACHE) >= _MW_OWNER_CACHE_MAX:
                        try:
                            _oldest = next(iter(_MW_OWNER_CACHE))
                            _MW_OWNER_CACHE.pop(_oldest, None)
                        except StopIteration:
                            break
                    _MW_OWNER_CACHE[execution_id] = owner
        except Exception as _lookup_exc:
            logger.debug(
                "[scan-strategy] owner lookup raised for execution %s: %s",
                execution_id, _lookup_exc,
            )
            return
    if not owner:
        return
    try:
        plan_payload = {
            "caller":              plan.get("caller"),
            "file_count":          plan.get("file_count"),
            "profile":             plan.get("profile"),
            "file_order":          plan.get("file_order"),
            "max_workers":         plan.get("max_workers"),
            "prewarm_footers":     plan.get("prewarm_footers"),
            "prewarm_concurrency": plan.get("prewarm_concurrency"),
            "duckdb_threads":      plan.get("duckdb_threads"),
            "boto3_max_pool_connections": plan.get("boto3_max_pool_connections"),
            "rationale":           plan.get("rationale"),
        }
        # 2026-06-04 — forward per-table breakdown for multi-view JOIN
        # queries so the BQB chip can render "table_A: 3000 · table_B:
        # 5".  Field is absent on the single-table path.
        _ptc = plan.get("per_table_file_counts")
        if _ptc:
            plan_payload["per_table_file_counts"] = _ptc
        _ws_manager.broadcast_to_user_sync(owner, {
            "type":         "scan_plan_decided",
            "execution_id": execution_id,
            "plan":         plan_payload,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
    except Exception as _bx:
        logger.debug("[scan-strategy] broadcast scan_plan_decided failed: %s", _bx)


def _broadcast_prewarm_progress(evt: dict) -> None:
    """Round 9 — broadcast prewarm stage events.  Reuses the
    ``_MW_OWNER_CACHE`` lookup chain from _broadcast_scan_plan_decision.
    Frontend renders a distinct prewarm chip from this so the 30s-250s
    of HEAD storms doesn't get lumped under "executing"."""
    if _ws_manager is None:
        return
    execution_id = evt.get("execution_id") or ""
    if not execution_id:
        return
    with _MW_OWNER_CACHE_LOCK:
        owner = _MW_OWNER_CACHE.get(execution_id)
    if owner is None:
        try:
            if _db_manager is None:
                return
            _exec_row = _db_manager.get_execution(execution_id)
            owner = (_exec_row or {}).get("executed_by", "") or ""
            if owner:
                with _MW_OWNER_CACHE_LOCK:
                    while len(_MW_OWNER_CACHE) >= _MW_OWNER_CACHE_MAX:
                        try:
                            _oldest = next(iter(_MW_OWNER_CACHE))
                            _MW_OWNER_CACHE.pop(_oldest, None)
                        except StopIteration:
                            break
                    _MW_OWNER_CACHE[execution_id] = owner
        except Exception as _lookup_exc:
            logger.debug("[prewarm] owner lookup raised for %s: %s",
                         execution_id, _lookup_exc)
            return
    if not owner:
        return
    try:
        _ws_manager.broadcast_to_user_sync(owner, {
            "type":         "prewarm_stage",
            "execution_id": execution_id,
            "stage":        evt.get("stage"),
            "files_total":  evt.get("files_total"),
            "concurrency":  evt.get("concurrency"),
            "warmed":       evt.get("warmed"),
            "errors":       evt.get("errors"),
            "timed_out":    evt.get("timed_out"),
            "elapsed_s":    evt.get("elapsed_s"),
            "from_recent_cache": evt.get("from_recent_cache"),
            "message":      evt.get("message"),
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
    except Exception as _bx:
        logger.debug("[prewarm] broadcast failed: %s", _bx)


# BF-599: bounded LRU-ish cache of execution_id → owner_username.
# Worker threads invoke `_broadcast_multi_worker_state` per state change
# (~5-10 events per worker over a query lifetime), so caching the
# DB-lookup avoids hammering Postgres / SQLite.  Grows by N executions
# per minute under load; bounded by `_MW_OWNER_CACHE_MAX` with FIFO eviction.
# BF-599g (2026-05-31): _MW_OWNER_CACHE_LOCK added to make the
# check-then-pop sequence atomic.  N=400 concurrent worker broadcasts
# (100 users × 4 workers) raced the unlocked TOCTOU window.
import threading as _threading_mw_owner  # noqa: E402
_MW_OWNER_CACHE: dict = {}
_MW_OWNER_CACHE_MAX = 1000
_MW_OWNER_CACHE_LOCK = _threading_mw_owner.Lock()


# ── Helpers ────────────────────────────────────────────────────────────────

# BF-593/594 (2026-05-30): dedicated thread pool for fire-and-forget
# audit and notification logging.  The default anyio pool (~40 threads)
# is shared with EVERY ``await adb(...)`` DB call — under load the
# bookkeeping writes would queue behind real DB work, and if DB
# slowed down the pool exhausted → blocked all DB calls.  Dedicated
# pool keeps bookkeeping bounded and isolated from primary I/O.
#
# BF-594: bumped 2→8 workers (BF-593's 2 silently serialised bulk
# admin ops that fire 100+ audits in one burst — 100 × 25ms / 2
# threads ≈ 1.25s of latent audit-log ordering lag).  8 workers
# balance burst-handling against starvation isolation; still well
# bounded vs the default 40.
#
# BF-594: registered atexit shutdown so test teardown + uvicorn
# reload don't leak threads.  cancel_futures=True bails on queued
# (not-yet-running) bookkeeping; in-flight writes are allowed to
# finish via wait=False so we don't block process exit on a stuck
# DB call.
import atexit as _atexit_audit  # noqa: E402
import concurrent.futures as _cf_audit  # noqa: E402
_audit_pool = _cf_audit.ThreadPoolExecutor(
    max_workers=8, thread_name_prefix="qs-audit",
)


def _shutdown_audit_pool() -> None:
    """BF-594: atexit hook — non-blocking shutdown of the audit pool."""
    try:
        _audit_pool.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass


_atexit_audit.register(_shutdown_audit_pool)


def _unset_mw_broadcast_callback() -> None:
    """BF-599g (2026-05-31): atexit hook — clear the multi-worker
    state-change callback registered at startup.

    Without this, the module-level ``_STATE_CHANGE_CALLBACK`` in
    ``core.multi_worker_executor`` holds a reference to a closure that
    captures ``_ws_manager`` / ``_db_manager`` references from the
    PREVIOUS process state.  On uvicorn reload, the new process loads
    fresh module state but the callback still points at dead refs from
    the prior module instance — first N multi_worker_progress events
    after reload silently fail.

    Idempotent: import-failure or callback-not-yet-set both fail open.
    """
    try:
        from core.multi_worker_executor import set_state_change_callback
        set_state_change_callback(None)
    except Exception as _unset_exc:
        # Best-effort — if multi_worker_executor isn't importable at exit
        # (e.g. interpreter teardown), nothing to clean up.
        logger.debug("BF-599g: mw callback unset at shutdown failed: %s",
                      _unset_exc)


_atexit_audit.register(_unset_mw_broadcast_callback)


def flush_audit_pool(timeout: float = 5.0) -> None:
    """BF-594: test helper — wait briefly for in-flight audit writes.

    Tests that assert on audit-log row counts should call this before
    inspecting the DB.  Mirrors core.row_security.api.flush_audit_pool.
    """
    try:
        _audit_pool.shutdown(wait=True, cancel_futures=False)
    except Exception:
        pass


async def _record_failure_suggestion(execution_id: str,
                                     suggestion: Optional[Dict[str, Any]]) -> None:
    """Keep a failed run's agent suggestion ON the run (2026-10-07).

    The WebSocket ``execution_failed`` carries it; the status route is the
    road a client takes when that message was missed (BF-381 poll fallback),
    and it reported the error with no suggestion.  Resolved once at failure
    -- ``core.agents.inline_suggestion`` over the RAW error, before any
    friendly rewording -- and stored in ``files_metadata.agent_suggestion``;
    the status route serves what is stored and never re-classifies.  The
    failure roads' ``finally`` blocks read-merge-write files_metadata, so the
    key survives them.  Fail-soft: a lost suggestion must not fail the run's
    failure path.
    """
    if not suggestion:
        return
    try:
        _ex = await adb(_db_manager.get_execution, execution_id)
        _fm = (_ex or {}).get("files_metadata") or {}
        if isinstance(_fm, str):
            import json as _json_fs
            try:
                _fm = _json_fs.loads(_fm)
            except Exception:
                _fm = {}
        if not isinstance(_fm, dict):
            _fm = {}
        _fm["agent_suggestion"] = suggestion
        await adb(_db_manager.update_execution, execution_id, files_metadata=_fm)
    except Exception as _rs_exc:
        logger.debug("could not store the agent suggestion on %s: %s",
                     execution_id, _rs_exc)


def _log_ws_notification(event_type: str, recipient: str, title: str,
                         message: str = "", execution_id: str = None,
                         schedule_id: int = None, payload: dict = None):
    """Persist a WebSocket notification to DB for history / bell icon.

    BF-591: when called from an async context, dispatch the DB write to a
    worker thread so we don't freeze the event loop on the round-trip.
    BF-593: dispatch to a SMALL dedicated pool (2 workers) so the
    audit writes can never saturate the default executor that real
    DB calls use.  Falls back to direct sync when no event loop is
    running (sync scheduler ticks).  Caller never awaits.
    """
    def _do_log():
        try:
            _db_manager.log_notification(
                event_type=event_type,
                channel="websocket",
                recipient=recipient,
                status="sent",
                title=title,
                message=message,
                payload=payload,
                execution_id=execution_id,
                schedule_id=schedule_id,
            )
        except Exception as exc:
            logger.debug("Failed to log notification: %s", exc)
    try:
        _loop = asyncio.get_running_loop()
        _loop.run_in_executor(_audit_pool, _do_log)
    except RuntimeError:
        _do_log()


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises.

    BF-591: dispatch the DB write off-loop when called from an async
    context (most callers are async endpoints).
    """
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        def _do_audit():
            try:
                _db_manager.audit(
                    username, action, resource_type=resource_type,
                    resource_id=resource_id, ip_address=ip,
                    user_agent=ua[:500] if ua else None, details=details,
                )
            except Exception as _aud_exc:
                logger.debug("Audit DB write failed: %s", _aud_exc)
        try:
            _loop = asyncio.get_running_loop()
            # BF-593: same dedicated pool as _log_ws_notification.
            _loop.run_in_executor(_audit_pool, _do_audit)
        except RuntimeError:
            _do_audit()
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


# ── Phase 125: Agent auto-retry helpers ───────────────────────────────────

_AUTO_RETRY_STRATEGIES = frozenset({
    "refresh_credentials", "reduce_memory", "reinstall_extension",
    "retry_with_backoff", "refresh_schema",
    # BF-280: when DuckDB raises "Ambiguous reference to column X",
    # the agent classifies it as qualify_ambiguous_columns.  Auto-retry
    # is OK because the fix is fully deterministic — no S3 work, no
    # cost — and the modified raw_sql has the column qualified.
    "qualify_ambiguous_columns",
    # BF-283: same pattern for add_group_by — sql_auto_fix already
    # rewrites SQL with the right GROUP BY clause deterministically.
    # Was NOTIFY-only before; user had to click "Apply fix" manually.
    "add_group_by",
})


async def _apply_agent_fix(strategy: str, retry_params: dict,
                           query_config_dict: dict, query_config,
                           retry_count: int,
                           user_ctx: Optional[Dict[str, Any]] = None) -> dict:
    """Apply agent fix strategy to query_config and return modified dict.

    Modifies query_config object in-place for strategies that change execution
    params (e.g. reduce_memory).  Returns updated query_config_dict with
    _agent_retry_count for the retry dispatch.
    """
    modified = {**(query_config_dict or {}), "_agent_retry_count": retry_count}

    if strategy == "refresh_credentials":
        # Invalidate presigned URL cache so fresh URLs are generated on retry
        try:
            from core.s3_utilities import list_s3_parquet_files_cached
            list_s3_parquet_files_cached.cache_clear()
        except Exception as _cred_exc:
            logger.debug("Agent fix refresh_credentials cache_clear failed: %s", _cred_exc)

    elif strategy == "reduce_memory":
        new_limit = retry_params.get("new_row_limit", 10000)
        modified["row_limit"] = new_limit
        if query_config and hasattr(query_config, "limit"):
            query_config.limit = new_limit

    elif strategy == "reinstall_extension":
        pass  # Fresh DuckDB connection triggers extension reload

    elif strategy == "retry_with_backoff":
        backoff = retry_params.get("backoff_seconds", 5)
        await asyncio.sleep(min(backoff, 30))  # Cap at 30s

    elif strategy == "refresh_schema":
        # BF-414 — previous code called ``get_cache()`` (no argument) which
        # raises ``TypeError: get_cache() missing 1 required positional
        # argument: 'name'``.  The except swallowed it, so the schema was
        # never refreshed and the retry hit the same stale schema, looping
        # until ``max_retries``.  Schema cache is registered as ``"schema"``
        # (api.connections_api:54) and uses composite keys
        # ``schema:{conn_id}:{table_path}`` — invalidate by walking and
        # matching the prefix.
        try:
            from core.cache_layer import get_cache
            _cache = get_cache("schema")
            _conn_id = modified.get("connection_id")
            if _cache is not None and _conn_id:
                _prefix = f"schema:{_conn_id}:"
                # Snapshot keys (cache lock is internal); delete matching ones.
                with _cache._lock:
                    _to_delete = [k for k in list(_cache._data.keys())
                                  if isinstance(k, str) and k.startswith(_prefix)]
                for _k in _to_delete:
                    _cache.delete(_k)
                # Also clear the bare connection-level key if older code
                # used a different key shape.
                _cache.delete(f"schema:{_conn_id}")
        except Exception as _schema_exc:
            logger.debug("Agent fix refresh_schema cache delete failed: %s", _schema_exc)

    elif strategy in ("qualify_ambiguous_columns", "add_group_by"):
        # BF-280: actually rewrite the SQL.  Old behaviour was to retry
        # the same broken SQL after a schema-cache refresh — useless
        # for ambiguous-column errors which are pure SQL bugs, not
        # schema staleness.
        # BF-283: same path now also handles add_group_by — sql_auto_fix
        # rewrites both kinds of errors deterministically.  Both feed
        # through the same rewrite-and-retry mechanism.
        _raw = modified.get("raw_sql") or (query_config_dict or {}).get("raw_sql")
        _conn_id = modified.get("connection_id") or (query_config_dict or {}).get("connection_id")
        # BF-283: add_group_by doesn't strictly need a connection_id (the
        # GROUP BY rewrite uses pure sqlglot AST analysis with no schema
        # lookups), so we can attempt it even without conn_id.
        if _raw and (_conn_id or strategy == "add_group_by"):
            try:
                # Build a minimal SqlAutoFixRequest and call the same
                # qualify+rewrite logic the user clicks "Apply fix" for.
                _ambiguous_req = SqlAutoFixRequest(
                    raw_sql=_raw,
                    connection_id=int(_conn_id) if _conn_id else None,
                )
                # 2026-10-06 -- the EXECUTING user, not an empty dict (which
                # sql_auto_fix's entitlement gate reads as fully entitled).
                # The SQL-connector road carries no user context; there the
                # connection is the one this very request was admitted to at
                # submit, so the agent reads nothing the user could not.
                _ambiguous_result = await sql_auto_fix(
                    _ambiguous_req, _user=user_ctx if user_ctx is not None else {})
                if _ambiguous_result and _ambiguous_result.get("fixed"):
                    _fixed_sql = _ambiguous_result.get("fixed_sql")
                    if _fixed_sql:
                        modified["raw_sql"] = _fixed_sql
                        # Mirror to query_config so downstream codepaths
                        # that read .raw_sql see the fix.
                        if query_config and hasattr(query_config, "raw_sql"):
                            query_config.raw_sql = _fixed_sql
                        logger.info(
                            "Agent fix %s: rewrote SQL — %s",
                            strategy,
                            _ambiguous_result.get("explanation", "auto-fixed"),
                        )
                    else:
                        logger.warning(
                            "Agent fix %s: auto-fix returned fixed=true but "
                            "no fixed_sql — retry will run unmodified SQL "
                            "(will likely fail again)", strategy,
                        )
                else:
                    logger.warning(
                        "Agent fix %s: auto-fix could not rewrite SQL — %s",
                        strategy,
                        (_ambiguous_result or {}).get("explanation", "no fix applicable"),
                    )
            except Exception as _amb_exc:
                logger.warning("Agent fix %s failed: %s", strategy, _amb_exc)

    return modified


def _should_agent_auto_retry(agent_result: dict) -> bool:
    """Check if agent result qualifies for automatic retry."""
    if not agent_result or not agent_result.get("retrying"):
        return False
    strategy = agent_result.get("strategy", "")
    retry_count = agent_result.get("retry_count", 1)
    from core.config import get as _cfg_get
    _qr_cfg = _cfg_get("agents", "query_resilience") or {}
    if not _qr_cfg.get("auto_retry_enabled", True):
        return False
    max_retries = _qr_cfg.get("max_retries", 2)
    allowed = set(_qr_cfg.get("auto_retry_strategies", _AUTO_RETRY_STRATEGIES))
    return strategy in allowed and retry_count <= max_retries


# ── Background workers ────────────────────────────────────────────────────

# Phase 156 deep-dive (2026-06-26) -- the completion hooks helper has
# moved to ``core.brain_completion_hooks`` so feed_engine + future
# core-layer callers can use it without violating layering.  Local
# alias preserves backward compat for the existing call sites in
# this module + the source-grep contract tests.
from core.brain_completion_hooks import (  # noqa: E402
    phase156_completion_hooks as _phase156_completion_hooks,
)


def _widen_decimal_columns(table):
    """Every DECIMAL column as ``decimal128(38, scale)``.

    2026-09-25, found live on the Docker rig (Python 3.11 / pandas 2.1.3, the
    production versions): chunks reach the writer as pandas DataFrames, and
    pandas 2.x holds DECIMAL values as Python ``Decimal`` objects, so
    ``Table.from_pandas`` INFERS the precision per chunk from the values it
    happens to hold -- decimal(7,1) for the first chunk, decimal(8,1) once the
    numbers gain a digit.  The narrowing cast to the writer's schema then
    fails and the query dies with "Table schema does not match schema used to
    create file" after serving its first page.  Any finance amount can cross
    a digit boundary between chunks.  Widening to the maximum precision (same
    scale) is lossless and makes every chunk agree."""
    import pyarrow as pa
    fields = list(table.schema)
    narrow = [pa.types.is_decimal128(f.type) and f.type.precision < 38
              for f in fields]
    if not any(narrow):
        return table
    target = pa.schema(
        [f.with_type(pa.decimal128(38, f.type.scale)) if n else f
         for f, n in zip(fields, narrow)],
        metadata=table.schema.metadata)
    return table.cast(target)


#: ``cache_key_scope`` not given: the caller did not say which row-security scope
#: its pre-built ``cache_key`` carries (None is a real scope: the shared slot)
_SCOPE_UNSET = object()


def _key_may_be_shared(cache_key, cache_key_scope, scope_now) -> bool:
    """Is the result-cache key this write uses the UNSCOPED one (or unknown)?

    2026-10-16 -- a per-principal key is always safe to write (only that
    principal reads it).  The SHARED key is not: when it was chosen before
    the query (the SQL / cross-source / dedup paths pass ``cache_key``), a
    row policy the query's own rewrite applied may postdate the choice, and a
    FILTERED result would be published to every principal -- the leak the
    clean release check found on published views.  ``scope_now`` is called
    only when the key is built here."""
    if cache_key:
        return cache_key_scope is _SCOPE_UNSET or cache_key_scope is None
    return scope_now() is None


async def _shared_store_confirmed(execution_id: str) -> bool:
    """A FRESH read of the policy store (off the event loop): may a result be
    written into the shared slot?  False skips the store, never fails the run."""
    from core.row_security.cache_scope import confirm_shared_slot
    ok = await asyncio.to_thread(confirm_shared_slot)
    if not ok:
        logger.warning("[cache] execution=%s: not storing -- the key is the SHARED one and a "
                       "row-security policy exists now (decided before the query ran)", execution_id)
    return ok


async def execute_query_background(execution_id: str, query_config: QueryConfig,
                                  query_id: Optional[int] = None,
                                  active_engine=None,
                                  executed_by: str = "guest",
                                  raw_sql: Optional[str] = None,
                                  cache_strategy: str = "auto",
                                  cache_key: Optional[str] = None,
                                  query_config_dict: Optional[dict] = None,
                                  fallback_output_file: Optional[str] = None,
                                  work_type=None,
                                  user_ctx: Optional[Dict[str, Any]] = None,
                                  rls_connection_id: Optional[int] = None,
                                  row_bound: Optional[int] = None,
                                  reraise_refusals: bool = False,
                                  cache_key_scope: Any = _SCOPE_UNSET):
    """Background task for query execution.

    ``reraise_refusals`` (2026-10-02) -- for a caller that AWAITS this
    function and answers the HTTP request itself (the published-view and
    federation-view handlers).  A scan refusal (``api.connector_errors.
    scan_refusal_in``: the presigned pre-download's file cap, the scan
    budget, a truncated listing) is recorded as a failed run exactly as
    before AND then re-raised, so the caller can answer 422 with its remedy
    instead of finding "no result" and answering 500.  ``False`` (every
    background caller) changes nothing.

    Phase 131 deep-dive #13 (round 4): ``user_ctx`` + ``rls_connection_id``
    let the background path apply row-security to SQL it generates from
    structured QueryConfig — previously only the ``/api/execute`` endpoint
    called secure_sql, leaving Published-View structured queries as an
    RLS bypass.

    ``row_bound`` (2026-09-15) — the caller DECLARES that at most this many
    rows must be materialised (a published-view page scan).  ``None`` = every
    row, exactly as before, for every caller that does not declare one.  It
    is deliberately NOT derived from ``query_config.limit``: BQB saves
    ``limit`` alongside SQL whose text carries its own LIMIT, and a report
    over an edited statement expects every row -- turning that field into a
    silent truncation is the 70M-feed-shipped-1M-rows class.  Applied on
    every materialisation shape of this function: the raw-SQL generators
    (which run the statement verbatim, so ``query_config.limit`` never
    bounded them), the structured generators, and the COPY-TO subprocess
    paths (which strip the SQL's own LIMIT).  It is also folded into the
    engine result-cache key, so a bounded result is never served as the
    complete answer to the same SQL.
    """
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    # 2026-10-07: submitted to the checkpoint lane -- a DB write inline here
    # stalled the event loop for every request on the pod (core/checkpoint.py).
    from core.checkpoint import mark_started_nowait as _cp_started
    from core.proxy_utils import sanitize_proxy_error as _sanitize
    _cp_started(execution_id)
    # Phase 156.3 (2026-06-25) -- stamp wall-clock start for the route
    # outcome history hook at completion.  monotonic() is the right
    # choice (immune to system-clock drift during long queries).
    _phase156_query_t0 = _time.monotonic()
    # Phase I (2026-06-08) -- stamp execution_id ContextVar before any
    # iceberg_reader / pruner code runs so record_pruning fires for this
    # query.  Pre-Phase-I, set_current_execution_id was ONLY called at
    # the END (with None) to clear -- never to the actual id.  Result:
    # get_current_execution_id() always returned None and the pruning
    # recorder silently no-op'd for every BQB/PV/cross-conn query since
    # 2026-06-04 (explains user-reported empty pruning-history rows).
    try:
        from core.query_diagnostic_store import set_current_execution_id
        set_current_execution_id(execution_id)
    except Exception as _qds_exc:                                     # pragma: no cover
        # 2026-07-02 -- debug-log so a systemic query_diagnostic_store
        # wiring failure is greppable.  Fail-open by design; this
        # only feeds the pruning-history admin view.
        logger.debug(
            "execute_api: set_current_execution_id suppressed %s: %s",
            type(_qds_exc).__name__, _qds_exc,
        )
    # Smart brain (2026-06-23) — begin per-query brain decision log.
    # Propagates across asyncio.to_thread via ContextVar so the sync
    # DuckDB / iceberg_reader code can append entries; we collect at
    # query completion and persist into files_metadata.brain_trace
    # so the admin / "why was this slow" UI can render it.
    try:
        from core.brain_trace import begin as _brain_begin
        _brain_begin()
    except Exception as _bt_exc:                                      # pragma: no cover
        # 2026-07-02 -- debug-log so a brain_trace wiring failure is
        # greppable.  Fail-open by design (brain must never break
        # query execution).
        logger.debug(
            "execute_api: brain_trace.begin() suppressed %s: %s",
            type(_bt_exc).__name__, _bt_exc,
        )
    # Phase 160 (2026-07-01) — begin per-query latency breakdown.
    # Same ContextVar-scoped pattern as brain_trace: lower layers
    # (iceberg_reader, iceberg_manifest_prune, duckdb_subprocess)
    # call record_stage / stage_ctx without threading the object.
    # Emitted at query completion into files_metadata.latency_breakdown
    # + Prometheus histograms.
    try:
        from core.brain_latency_breakdown import begin_breakdown as _lb_begin
        _lb_begin()
    except Exception as _lb_exc:                                      # pragma: no cover
        # 2026-07-02 -- debug-log so a systemic latency-breakdown
        # wiring failure is greppable.  Fail-open by design;
        # sibling of emit_breakdown at line ~5423.
        logger.debug(
            "execute_api: begin_breakdown suppressed %s: %s",
            type(_lb_exc).__name__, _lb_exc,
        )
    _pool = get_pool()
    _work_type = work_type if work_type is not None else WorkType.INTERACTIVE
    run_engine = active_engine or _engine

    # Phase 131 deep-dive #13 (round 4): RLS rewrite for the structured
    # case.  When raw_sql is provided the caller (api/execute, PV path)
    # has already run secure_sql.  When it's None, we synthesize SQL
    # from query_config and rewrite — but ONLY when RLS is enabled and
    # we have a user_ctx (otherwise it's a no-op and we let the engine
    # take its native path).  Failure is fail-closed: structured queries
    # that can't be securely rewritten do not run.
    if raw_sql is None and user_ctx is not None:
        try:
            from core.row_security.api import _is_enabled as _rs_is_enabled
            if _rs_is_enabled():
                from core.duckdb_views import build_query_sql as _build_sql
                from core.row_security import secure_sql as _rs_secure
                from core.virtual_ref_rewriter import rewrite_virtual_refs as _rv
                _synth = await asyncio.to_thread(
                    _build_sql, query_config_dict or query_config)
                # Round 10: rewrite virtual prefixes so the secured SQL
                # references the same view names setup_registered_views
                # actually creates downstream.
                _synth = _rv(_synth)
                if _synth:
                    _secured = await asyncio.to_thread(
                        _rs_secure, _synth, dialect="duckdb",
                        user_ctx=user_ctx, connection_id=rls_connection_id,
                        request_id=execution_id,
                    )
                    if _secured and _secured.strip() != _synth.strip():
                        raw_sql = _secured  # engine will execute the secured form
        except Exception as _rs_exc:
            logger.error("execute_query_background: RLS rewrite failed for %s: %s",
                          execution_id, _rs_exc)
            try:
                await adb(_db_manager.update_execution, execution_id,
                          status="failed",
                          error_message=f"Row-security enforcement failed: {_rs_exc}")
            except Exception:
                pass
            raise

    try:
        # BF-289: register this execution in the per-stage tracker so
        # the heartbeat broadcasts WHICH stage is consuming time.
        try:
            from core.execution_stage import begin_execution as _stg_begin, set_stage as _stg_set
            _stg_begin(execution_id)
            _stg_set(execution_id, "init", message="Pre-execution checks")
        except Exception:
            pass

        # BF-PRUNE-PERF-LOG: dump active proxy/S3/DuckDB config at query start
        # so the per-query log file shows exactly what's loaded.  Helps the
        # user verify whether proxy is bypassed, what S3 access mode is used,
        # whether VPC endpoint config is active, etc.  Fail-open.
        try:
            from core.config import (
                proxy_cfg as _pr_cfg, s3 as _s3_cfg,
                duckdb_cfg as _dd_cfg,
            )
            from core.s3_utilities import get_s3_access_mode as _gsm
            _conn_cfg_active = getattr(active_engine, "_s3_conn_config", None) or {}
            _s3_mode = _gsm(_conn_cfg_active) if _conn_cfg_active else "n/a"
            _cfg_summary = (
                f"proxy.enabled={getattr(_pr_cfg, 'enabled', False)} "
                f"proxy.apply_to_duckdb={getattr(_pr_cfg, 'apply_to_duckdb', False)} "
                f"proxy.apply_to_boto3={getattr(_pr_cfg, 'apply_to_boto3', False)} "
                f"s3.access_mode={_s3_mode} "
                f"s3.scan_quotas_enabled={getattr(_s3_cfg, 'scan_quotas_enabled', False)} "
                f"duckdb.threads_per_query={getattr(_dd_cfg, 'threads_per_query', '?')} "
                f"duckdb.parallel_download_workers={getattr(_dd_cfg, 'parallel_download_workers', '?')} "
                f"duckdb.circuit_breaker_enabled={getattr(_dd_cfg, 'circuit_breaker_enabled', '?')}"
            )
            logger.info("[execute_query_background %s] active config: %s",
                        execution_id, _cfg_summary)
            try:
                from core.execution_stage import add_extras as _stg_extras
                _stg_extras(execution_id,
                            proxy_enabled=str(getattr(_pr_cfg, 'enabled', False)),
                            proxy_apply_to_duckdb=str(getattr(_pr_cfg, 'apply_to_duckdb', False)),
                            proxy_apply_to_boto3=str(getattr(_pr_cfg, 'apply_to_boto3', False)),
                            s3_access_mode=_s3_mode)
            except Exception:
                pass
        except Exception as _cfg_dump_err:
            logger.debug("Config dump skipped: %s", _cfg_dump_err)

        # BF-LOG-BUFFER: bind execution_id to the current async context so the
        # ExecutionLogHandler captures only logs emitted during THIS query's
        # work (not server-wide background noise).  Installed lazily — first
        # call attaches the handler to the root logger; subsequent calls are
        # cheap idempotent no-ops.  Drained in the finally block below and
        # persisted into files_metadata['log_lines'] for UI replay.
        try:
            from core.execution_log_buffer import install as _elb_install, with_execution_id as _elb_bind
            _elb_install()
            _log_ctx = _elb_bind(execution_id)
            _log_ctx.__enter__()
        except Exception:
            _log_ctx = None

        # ── Phase 134: Pre-execution scan quota check ─────────────────────
        try:
            from core.config import s3 as _sq_pre_cfg
            if _sq_pre_cfg.scan_quotas_enabled:
                from core.s3_scan_quota import scan_quota_tracker
                _user_role_pre = "admin"
                try:
                    _user_rec_pre = await adb(_db_manager.get_user_by_username, executed_by)
                    if _user_rec_pre:
                        _user_role_pre = _user_rec_pre.get("role", "analyst")
                except Exception:
                    pass
                _quota_result = scan_quota_tracker.check_quota(executed_by, _user_role_pre, 0)
                if not _quota_result.allowed:
                    await adb(_db_manager.update_execution, execution_id, status="failed",
                        error_message=f"Scan quota exceeded: {_quota_result.message}")
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "execution_failed", "execution_id": execution_id,
                        "error": _quota_result.message,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    })
                    return
        except Exception:
            pass  # fail-open — never block due to quota check errors

        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        loop = asyncio.get_running_loop()

        async def progress_callback(progress_data):
            await _ws_manager.broadcast_to_user(executed_by, {
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": progress_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

            if progress_data.get("status") in ["completed", "failed"]:
                await adb(_db_manager.update_execution, 
                    execution_id,
                    status=progress_data["status"],
                    total_rows=progress_data.get("total_rows", 0),
                    chunks_processed=progress_data.get("chunks_processed", 0),
                    output_file=str(output_file) if progress_data.get("status") == "completed" else None,
                    file_size_bytes=progress_data.get("file_size_bytes", 0),
                    error_message=progress_data.get("error")
                )

        # Throttled sync callback — called from worker thread, max 1 broadcast/sec.
        # Terminal events (completed/failed) are NEVER throttled — they must reach
        # progress_callback so the DB status update happens.  BF-414 — engine
        # signals also bypass throttle so the BQB chip lights up immediately
        # on first dispatch decision instead of waiting up to a second.
        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            is_terminal = data.get("status") in ("completed", "failed")
            is_engine_signal = bool(data.get("engine"))
            if is_terminal or is_engine_signal or now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(progress_callback(data), loop)

        # ── Phase 139 audit-fix Gap 13: metadata-only fast path ──────────────
        # SELECT COUNT(*) / MIN(col) / MAX(col) on a single Iceberg or parquet
        # table with no WHERE/JOIN/GROUP BY → answer from manifests/footers
        # instead of scanning data. Fail-OPEN: any error falls through.
        try:
            if raw_sql:
                from core.metadata_only_optimizer import detect_metadata_only_query
                _md_match = detect_metadata_only_query(raw_sql)
                if (_md_match
                        and len(query_config.files or []) == 1
                        and not query_config.joins
                        and not query_config.aggregations
                        and not query_config.group_by
                        and not query_config.filters):
                    _md_done = await _try_metadata_only_fast_path(
                        execution_id=execution_id,
                        query_config=query_config,
                        match=_md_match,
                        executed_by=executed_by,
                        run_engine=run_engine,
                        output_file=output_file,
                        query_id=query_id,
                    )
                    if _md_done:
                        return  # answer already broadcast — short-circuit
        except Exception as _md_err:
            logger.debug("metadata-only fast path skipped (%s) — falling through", _md_err)

        # ── BF-382 — Result Cache fast path ───────────────────────────────
        # Look up cached parquet for (sql + params + post-pruning file
        # fingerprint).  On hit: copy parquet → output_file, broadcast
        # complete, return.  On miss / disabled / non-deterministic SQL /
        # any error: fall through (fail-open).
        # BF-420 — gate by cache_strategy.  Without this check, the BQB
        # "Run fresh" button (which sets cache_strategy='bypass') would
        # still hit the result cache and return the stale parquet
        # (negating BF-418 fix #5 entirely).  The store side at lines
        # ~3516, 4177, 4976 already has this gate; the serve side here
        # was missing it.  Now both sides honour bypass.
        #
        # 2026-10-07 -- the key's file list now carries the SNAPSHOT of every
        # registered Iceberg table (``iceberg_snapshot_tokens``): the virtual
        # ``__registered__:<name>`` entry never changed on a commit, so an
        # ``auto`` query was served its pre-commit result for the cache TTL.
        # The same list keys the write-through below, so a stored result is
        # filed under the snapshot resolved BEFORE the run.  ``None`` (a
        # snapshot that cannot be read) = no serve and no store this run.
        # ``refresh`` asks for the newest data like ``bypass`` does.
        # ``_pre_ice_snaps`` is ALSO the fingerprint the query cache below
        # files its entry under when the run's own file stats carry none.
        _rc_key_files: Optional[list] = None
        _pre_ice_snaps: Optional[Dict[str, str]] = {}
        try:
            from core.query_cache_integration import (
                iceberg_snapshot_ids as _rc_snap_ids,
                referenced_iceberg_tables as _rc_ice_refs,
                snapshot_tokens_from_ids as _rc_snap_tokens)
            _rc_files0 = list(query_config.files or [])
            _pre_ice_tables = _rc_ice_refs(run_engine, raw_sql, _rc_files0)
            if _pre_ice_tables:
                _pre_ice_snaps = await asyncio.to_thread(
                    _rc_snap_ids, run_engine, _pre_ice_tables)
            if _pre_ice_snaps is None:
                logger.info(
                    "[result-cache] execution=%s: an Iceberg table's "
                    "snapshot could not be resolved -- result caches "
                    "neither served nor written for this run",
                    execution_id)
            elif raw_sql and _rc_files0:
                _rc_key_files = _rc_files0 + _rc_snap_tokens(_pre_ice_snaps)
        except Exception as _rc_tok_err:
            _rc_key_files = None
            _pre_ice_snaps = None
            logger.warning("[result-cache] snapshot key failed (cache not "
                           "used for this run): %s", _rc_tok_err)
        # 2026-10-08 -- the brain's sql-hash RESULT cache keys on the SAME
        # snapshots, decided once here.  This road hands the view setup the
        # Pydantic model, so the ``_iceberg_snapshot_id`` it stamps on a
        # DICT never reached ``query_config_dict``: the dispatcher looked
        # the cache up with ``snapshot=?`` and the completion hook stored
        # under it -- a "hit" with no snapshot, routed to SINGLE and never
        # served.  ``agg_cache.brain_snapshot_from_query_config`` is the one
        # reader on both sides; an unresolvable snapshot leaves no key, so
        # the brain cache is neither read nor written for this run.
        try:
            if isinstance(query_config_dict, dict):
                from core.agg_cache import brain_snapshot_key_from_ids as _bsk
                _bsk_val = (_bsk(_pre_ice_snaps)
                            if isinstance(_pre_ice_snaps, dict) else "")
                if _bsk_val:
                    query_config_dict["_brain_snapshot_key"] = _bsk_val
                else:
                    query_config_dict.pop("_brain_snapshot_key", None)
        except Exception as _bsk_exc:
            logger.debug("[brain-cache] snapshot key not set: %s", _bsk_exc)
        try:
            from core.query_cache_integration import maybe_serve_from_cache as _rc_lookup
            from core.config import get_section as _cfg_section
            from core.iceberg_freshness_bound import (
                wants_newest_snapshot as _rc_wants_newest)
            _rc_section = _cfg_section("result_cache") or {}
            _rc_skip = list(_rc_section.get("skip_patterns") or [])
            _rc_files = list(_rc_key_files or [])
            _rc_params = dict(getattr(query_config, "params", {}) or {})
            if (raw_sql and _rc_files
                    and not _rc_wants_newest(cache_strategy)):
                # BF-401: maybe_serve_from_cache does shutil.copyfile() which
                # is SYNCHRONOUS — for a large cached parquet (100s of MB) it
                # blocks the asyncio event loop for the entire copy duration.
                # During that time, NO HTTP endpoints respond → backend
                # appears unavailable.  Wrap in asyncio.to_thread so the loop
                # stays responsive.
                _rc_meta = await asyncio.to_thread(
                    _rc_lookup,
                    raw_sql, _rc_params, _rc_files, str(output_file),
                    skip_patterns=_rc_skip,
                    username=executed_by,
                    row_limit=row_bound,
                    # Phase 150 — Output Gateway routing.  Caller passes
                    # the post-prune file count + db_manager so the
                    # gateway can decide whether to serve from S3.
                    files_after_prune=len(query_config.files or []),
                    db_manager=_db_manager,
                )
                if _rc_meta is not None:
                    _rc_rows = int(_rc_meta.get("row_count", 0) or 0)
                    _rc_cols = int(_rc_meta.get("column_count", 0) or 0)
                    _rc_size = int(_rc_meta.get("size_bytes", 0) or 0)
                    logger.info(
                        "[result-cache] HIT execution=%s rows=%d cols=%d "
                        "(key=%s ttl_remaining=%s hits=%d) — short-circuit",
                        execution_id, _rc_rows, _rc_cols,
                        str(_rc_meta.get("cache_key", ""))[:16],
                        _rc_meta.get("ttl_remaining"),
                        int(_rc_meta.get("hit_count", 0) or 0),
                    )
                    # 2026-10-08 -- a result-cache HIT is still a query: it
                    # read ZERO source files, and its pruning-history row
                    # says so (source='result_cache', files_after_prune=0,
                    # files_before_prune NULL).  The reader is never entered
                    # on this road, so nothing else records this execution
                    # and the admin route / Docker proof would find no row.
                    try:
                        from core.query_diagnostic_store import (
                            record_result_cache_hit as _rc_record_hit)
                        _rc_record_hit(execution_id, _pre_ice_tables,
                                       snapshots=_pre_ice_snaps or {})
                    except Exception as _rc_obs_exc:                 # noqa: BLE001
                        logger.warning("[result-cache] pruning-history row "
                                       "for execution %s not recorded: %s",
                                       execution_id, _rc_obs_exc)
                    # BF-399: persist engine_meta into files_metadata so the
                    # polling-fallback badge UI shows ⚡ Result Cache HIT
                    # even when the WS message below got dropped.
                    _cache_engine_meta = {
                        "engine":      "result_cache",
                        "from_cache":  True,
                        "cache_key":   str(_rc_meta.get("cache_key", ""))[:16],
                        "hit_count":   int(_rc_meta.get("hit_count", 0) or 0),
                    }
                    await adb(
                        _db_manager.update_execution, execution_id,
                        status="completed",
                        engine="result_cache",
                        total_rows=_rc_rows,
                        chunks_processed=0,
                        output_file=str(output_file),
                        file_size_bytes=_rc_size,
                        files_metadata=json.dumps({"__engine_meta__": _cache_engine_meta}),
                        error_message=None,
                    )
                    # Broadcast BOTH progress (for chip) AND execution_completed
                    # (for spinner flip).  Previously only progress was sent
                    # → frontend showed chip but spinner never stopped.
                    _ts_iso = datetime.now(timezone.utc).isoformat()
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type":             "execution_progress",
                        "execution_id":     execution_id,
                        "data": {
                            "status":           "completed",
                            "total_rows":       _rc_rows,
                            "chunks_processed": 0,
                            "file_size_bytes":  _rc_size,
                            "from_cache":       True,
                            "cache_key":        str(_rc_meta.get("cache_key", ""))[:16],
                        },
                        "timestamp":        _ts_iso,
                    })
                    await _ws_manager.broadcast_to_user(executed_by, _with_engine({
                        "type":             "execution_completed",
                        "execution_id":     execution_id,
                        "from_cache":       True,
                        "stats": {
                            "total_rows":      _rc_rows,
                            "file_size_bytes": _rc_size,
                            "from_cache":      True,
                        },
                        "timestamp":        _ts_iso,
                    }, "result_cache"))
                    return  # cache hit — done
        except Exception as _rc_err:
            logger.warning(
                "[result-cache] hook failed (fail-open, falling through): %s",
                _rc_err, exc_info=True,
            )

        # Phase 139 (Tier 2.1) — incremental row streaming via WebSocket.
        # While the DuckDB execute path materialises the FULL result to disk,
        # also emit the first STREAM_ROW_CAP rows over WS as chunks arrive so
        # the frontend grid can render rows in <1s instead of waiting for the
        # full query. Broadcasts stop once the cap is hit; remainder arrives
        # via the existing /results polling path (no behaviour change there).
        STREAM_ROW_CAP = 1000
        _stream_state = {"sent_rows": 0, "first_chunk_ts": None, "schema": None}
        _stream_t0 = _time.time()

        # Phase 139 (Tier 2.1) — non-deterministic-order detection. Streaming
        # without ORDER BY means the early-rendered preview rows may be a
        # different subset than what the user finally sees in the grid. Surface
        # this so the user knows the preview is approximate.
        # Use a regex to avoid false positives from string literals like
        # ``WHERE x = 'order by name'``: require ORDER BY to appear OUTSIDE
        # quoted strings. The cheap check below strips single-quoted literals
        # before testing.
        _has_order_by = False
        try:
            if raw_sql:
                import re as _re_ob
                # Strip single-quoted string literals (matches escaped quotes too)
                _stripped = _re_ob.sub(r"'(?:[^'\\]|\\.)*'", "''", str(raw_sql))
                if _re_ob.search(r"\border\s+by\b", _stripped, _re_ob.IGNORECASE):
                    _has_order_by = True
            if not _has_order_by and getattr(query_config, "order_by", None):
                _has_order_by = True
        except Exception:
            _has_order_by = False
        _order_warning = None if _has_order_by else (
            "Stream preview rows are NOT in a guaranteed order. Add ORDER BY "
            "for deterministic early rows."
        )

        async def _broadcast_chunk(rows_payload: list, cols_payload: list,
                                   total_so_far: int) -> None:
            msg = {
                "type":           "execution_chunk",
                "execution_id":   execution_id,
                "rows":           rows_payload,
                "columns":        cols_payload,
                "total_so_far":   total_so_far,
                "timestamp":      datetime.now(timezone.utc).isoformat(),
            }
            if _order_warning:
                msg["order_warning"] = _order_warning
            await _ws_manager.broadcast_to_user(executed_by, msg)

        def _emit_stream_chunk(arrow_table) -> None:
            """Worker-thread helper: pull rows from arrow table, ship via WS.

            Capped at STREAM_ROW_CAP total across all chunks. Fail-OPEN — any
            serialisation error skips broadcast; query continues.
            """
            try:
                if _stream_state["sent_rows"] >= STREAM_ROW_CAP:
                    return
                remaining = STREAM_ROW_CAP - _stream_state["sent_rows"]
                if remaining <= 0:
                    return
                # Slice arrow table to remaining rows
                slice_n = min(remaining, len(arrow_table))
                if slice_n == 0:
                    return
                tbl = arrow_table.slice(0, slice_n)
                # Cache schema on first emit + record TTFR
                if _stream_state["schema"] is None:
                    _stream_state["schema"] = [
                        {"name": f.name, "type": str(f.type)} for f in tbl.schema
                    ]
                    _stream_state["first_chunk_ts"] = _time.time()
                    try:
                        from core.metrics import record_time_to_first_row
                        record_time_to_first_row(
                            "duckdb", _stream_state["first_chunk_ts"] - _stream_t0,
                        )
                    except Exception:
                        pass
                # Convert to list-of-dicts; use Python-native types
                rows_payload = tbl.to_pylist()
                # Sanitize NaN / Infinity (BF-100)
                try:
                    from core.json_utils import sanitize_for_json
                    rows_payload = sanitize_for_json(rows_payload)
                except Exception:
                    pass
                _stream_state["sent_rows"] += slice_n
                # Schedule broadcast on the event loop
                asyncio.run_coroutine_threadsafe(
                    _broadcast_chunk(
                        rows_payload, _stream_state["schema"],
                        _stream_state["sent_rows"],
                    ),
                    loop,
                )
            except Exception:
                pass  # streaming is best-effort; query continues

        # ── SQL Dialect Translation ───────────────────────────────────────────
        # Auto-translate cross-platform SQL (Starburst/Snowflake/Trino/MySQL/…)
        # to DuckDB syntax so users can paste the same query into CQB and BQB.
        # Fail-open: any error leaves raw_sql unchanged.
        # BF-571: also capture format-string auto-corrections so the
        # response can tell the user what the agent fixed (rather
        # than silently rewriting).
        _format_fixes: list = []
        if raw_sql:
            try:
                from core.sql_dialect_translator import (
                    translate_to_duckdb_with_fixes as _translate_sql_v2,
                )
                raw_sql, _dt_dialect, _format_fixes = _translate_sql_v2(raw_sql)
                if _dt_dialect:
                    logger.info("execute_api: SQL dialect '%s' translated → duckdb", _dt_dialect)
                if _format_fixes:
                    logger.info(
                        "execute_api: BF-571 auto-corrected %d format "
                        "specifier(s) in user SQL: %s",
                        len(_format_fixes),
                        "; ".join(f.describe() for f in _format_fixes),
                    )
            except Exception as _dt_err:
                logger.debug("execute_api: SQL translation skipped (fail-open): %s", _dt_err)

        # ── Spark Connect routing gate ─────────────────────────────────────────
        # If spark_connect.enabled and the query is above the row threshold,
        # route to Spark Connect instead of DuckDB.  Spark reads s3a:// paths
        # directly — no files are pre-downloaded to this pod.
        #
        # Gate checks (in order):
        #   1. engine query param override  2. feature flag  3. S3-only  4. no cross-conn
        #   5. circuit breaker closed       6. row count ≥ threshold
        #
        # Fail-open: any Spark failure falls back to DuckDB with a WS notification.
        _engine_override = (query_config_dict or {}).get("engine_override")
        _conn_cfg_for_spark = getattr(run_engine, "_s3_conn_config", None) or {}
        _estimated_rows = (query_config_dict or {}).get("estimated_rows", 0) or 0
        # If the frontend didn't supply a row hint AND Spark Connect is enabled
        # AND override == "spark", trust the override.  Otherwise without a hint
        # we have no way to know the query size and fall through to DuckDB.
        _use_spark, _spark_fallback_reason = _should_use_spark_connect(
            _engine_override, _conn_cfg_for_spark, _estimated_rows, query_config_dict,
            # 2026-07-15 iceberg floor — the engine's registered-table list
            # (name + format) is authoritative in this scope; falls back to
            # conn_config["registered_tables"] inside when None.
            registered_tables=getattr(run_engine, "_registered_tables", None),
        )

        # Phase 139 (Tier 1.3): Prometheus routing decision telemetry
        try:
            from core.metrics import record_spark_routing
            record_spark_routing(_spark_fallback_reason or "used")
        except Exception:
            pass

        if _use_spark:
            try:
                _sc_metrics = await _execute_via_spark_connect(
                    execution_id=execution_id,
                    query_config=query_config,
                    conn_config=_conn_cfg_for_spark,
                    output_file=output_file,
                    executed_by=executed_by,
                    raw_sql=raw_sql,
                    progress_callback=progress_callback,
                )
                # Spark succeeded — persist completion and return
                await adb(_db_manager.update_execution, 
                    execution_id,
                    status="completed",
                    total_rows=_sc_metrics.get("total_rows", 0),
                    output_file=str(output_file),
                    # 2026-09-27 -- was ``execution_backend=``, a column
                    # QueryExecution never had; update_execution's hasattr
                    # guard dropped it in silence and no Spark run was ever
                    # recorded as one.  ``engine`` is the column.
                    engine="spark_connect",
                )
                await _ws_manager.broadcast_to_user(executed_by, _with_engine({
                    "type":            "execution_completed",
                    "execution_id":    execution_id,
                    "total_rows":      _sc_metrics.get("total_rows", 0),
                    "elapsed_seconds": _sc_metrics.get("elapsed_seconds"),
                    "timestamp":       datetime.now(timezone.utc).isoformat(),
                }, "spark_connect"))
                return
            except Exception as _sc_err:
                logger.warning(
                    "[spark_connect] Execution failed for %s (%s) — falling back to DuckDB",
                    executed_by, _sc_err,
                )
                try:
                    from core.metrics import record_spark_routing
                    record_spark_routing("fallback")
                except Exception:
                    pass
                # Notify user that Spark failed and DuckDB is taking over
                try:
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type":         "execution_engine_fallback",
                        "execution_id": execution_id,
                        "reason":       "spark_failed",
                        "message":      (
                            "Spark Connect query failed — retrying with DuckDB. "
                            "Query may be slower for large datasets."
                        ),
                        "timestamp":    datetime.now(timezone.utc).isoformat(),
                    })
                except Exception:
                    pass
                # Fall through to DuckDB path below

        elif _spark_fallback_reason and _spark_fallback_reason in _SPARK_FALLBACK_MESSAGES:
            _fallback_msg = _SPARK_FALLBACK_MESSAGES[_spark_fallback_reason]
            if _fallback_msg:
                try:
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type":         "execution_engine_fallback",
                        "execution_id": execution_id,
                        "reason":       _spark_fallback_reason,
                        "message":      _fallback_msg,
                        "timestamp":    datetime.now(timezone.utc).isoformat(),
                    })
                except Exception:
                    pass

        # Run the blocking CPU/IO-bound call in the thread pool so the event loop
        # stays free to handle other requests concurrently
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        def _exec_to_parquet(cancel_event=None):
            # BF-421 — wrap the worker body in try/finally that calls
            # cleanup_temp_downloads.  Without this, every BQB query
            # registers a temp_dir via _s3_to_local_via_boto3 (BF-419)
            # but no one ever cleans it on this thread.
            # ``execute_stream_api`` calls cleanup at 5 finally blocks,
            # but the BQB main path goes through _pool.submit on a
            # worker thread — its _thread_local.temp_dirs and the
            # global registry leak indefinitely until pod restart →
            # disk-fill regression once the predownload disk-guard
            # eventually trips.  Run cleanup on the SAME thread that
            # registered (worker thread = the thread executing this
            # function), AFTER the body completes (success or failure).
            from core.duckdb_views import cleanup_temp_downloads as _ctd
            # 2026-10-07 -- the freshness intent rides the worker thread too
            # (a ContextVar does not cross ``_pool.submit``): every Iceberg
            # pointer this body resolves without an explicit force_fresh --
            # a snapshot probe, a partition-spec pre-read -- is then held to
            # a staleness bound of 0 for a bypass/refresh request.
            from core.iceberg_freshness_bound import (
                newest_snapshot_required as _newest_required,
                wants_newest_snapshot as _wants_newest_w)
            try:
                with _newest_required(_wants_newest_w(cache_strategy)):
                    return _exec_to_parquet_body(cancel_event)
            finally:
                try:
                    _ctd()
                except Exception as _ctd_exc:
                    logger.debug("[bf421] cleanup_temp_downloads raised: %s", _ctd_exc)

        def _exec_to_parquet_body(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)
            total_rows = 0
            chunks_processed = 0

            # Registered table path: resolve __registered__: → DuckDB views
            def _any_virtual(flist, prefixes=("__registered__:", "__materialized__:", "__local__:", "__federation__:")):
                return any(
                    (f if isinstance(f, str) else f.path).startswith(prefixes)
                    for f in (flist or [])
                )
            _join_right = [j.right_file for j in (query_config.joins or [])] if query_config.joins else []
            _has_reg = _any_virtual(query_config.files) or _any_virtual(_join_right)
            # COPY TO fast path only for S3 registered tables (not local or MV)
            _has_s3_reg = _any_virtual(query_config.files, ("__registered__:",)) or _any_virtual(_join_right, ("__registered__:",))

            # Smart brain (2026-06-22): retired the blanket
            # ``executed_by in (published_view:*, schedule:*)`` →
            # force_fresh=True rule.  That rule pre-dated BF-299 / BF-511 /
            # the trust-watcher window — back then "Published API serves
            # cached April pointer when May data has landed" was a real
            # bug.  With BF-299 watcher + trust-window, the cache layers
            # now self-verify when the watcher hasn't ticked recently,
            # so Published API + scheduled reports are correct AND fast.
            # Caller explicit opt-out (``cache_strategy="bypass"``)
            # remains the only force-fresh path — preserves the escape
            # hatch for callers who really want a live re-scan.
            # 2026-10-07: ``refresh`` asks for the newest data too -- ONE
            # spelling (core.iceberg_freshness_bound.wants_newest_snapshot).
            from core.iceberg_freshness_bound import (
                wants_newest_snapshot as _wants_newest)
            _force_fresh = _wants_newest(cache_strategy)

            # ── COPY TO fast path — bypass Python/pandas entirely ──────────
            # DuckDB streams from S3 directly to local Parquet (3-10x faster).
            # Skip for UNC paths (DuckDB can't handle \\server\share\...).
            # Skip for local/MV tables — they are already local files.
            if _has_s3_reg and not str(output_file).startswith("\\\\") and not raw_sql:
                try:
                    stats = execute_registered_table_copy_to(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        str(output_file),
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        cancel_event=cancel_event,
                        force_fresh_iceberg=_force_fresh,
                        db_manager=_db_manager,    # BF-368: enables col-stats supplement
                        execution_id=execution_id,  # arms progressive COPY delivery
                        row_bound=row_bound,        # 2026-09-15: declared page bound
                    )
                    _sync_progress({"status": "completed",
                                    "total_rows": stats["total_rows"],
                                    "file_size_bytes": stats["file_size_bytes"]})
                    return stats
                except Exception as _copy_err:
                    # Don't fall back to in-process DuckDB — same crash risk.
                    # Let the error propagate so the execution fails cleanly.
                    raise RuntimeError(f"S3 query failed: {_copy_err}") from _copy_err

            # ── Streaming path (fallback for registered tables, default for others)
            pq_writer = None
            # Progressive delivery (2026-07-31, flag OFF by default) —
            # initialised BEFORE the try so the finally below can always
            # reference it (early-return branches inside the try never
            # create a tee; it stays None for them).
            _prog_tee = None
            # Open via Python's built-in open() so UNC paths (\\server\share\...)
            # are resolved correctly on Windows — PyArrow's C++ LocalFileSystem
            # does NOT handle UNC paths and crashes silently at large row counts.
            fh = open(str(output_file), "wb")
            try:
                # Phase T (2026-06-08) — branch-identifier: log + persist
                # to scan_plan registry so the admin UI's Query Diagnostic
                # page shows WHICH code path the query took.  No more
                # log grepping to find out why brain didn't engage.
                _t_branch = (
                    "1_bqb_raw_sql" if _has_reg and raw_sql
                    else "2_structured_no_raw_sql" if _has_reg
                    else "3_subprocess_raw_sql" if raw_sql
                    else "0_other"
                )
                logger.info(
                    "[brain-routing] execution_id=%s _has_reg=%s raw_sql=%s "
                    "_has_s3_reg=%s files=%s -> BRANCH=%s",
                    execution_id, bool(_has_reg), bool(raw_sql),
                    bool(_has_s3_reg),
                    (query_config.files or [])[:5],
                    _t_branch,
                )
                try:
                    from core.brain.scan_plan import record_execution_path as _rep
                    _rep(
                        execution_id=execution_id,
                        branch=_t_branch,
                        has_reg=bool(_has_reg),
                        raw_sql=bool(raw_sql),
                        has_s3_reg=bool(_has_s3_reg),
                        files=query_config.files,
                    )
                except Exception:
                    pass
                if _has_reg and raw_sql:
                    # ── Registered/local tables + raw SQL (Business Query Builder) ──
                    # Detect whether we have S3 registered tables or only local/MV.
                    _has_s3_tables = _any_virtual(query_config.files, ("__registered__:",))
                    import pyarrow as _pa_raw

                    logger.info("BQB raw_sql path: _has_s3=%s, s3_config=%s, reg_tables=%d, files=%s, raw_sql_start=%s",
                                _has_s3_tables, bool(run_engine._s3_conn_config),
                                len(run_engine._registered_tables) if run_engine._registered_tables else 0,
                                query_config.files, (raw_sql or "")[:120])
                    if _has_s3_tables and run_engine._s3_conn_config:
                        # ── Extract partition filters from raw SQL WHERE clause ──────────
                        # BQB queries embed filters in SQL (not query_config.filters), so
                        # setup_registered_views gets no partition context without this.
                        # BF-PRUNE-PERF: hoist sql-refs extraction up so we can SKIP
                        # the per-table _latest_metadata_key scan for tables NOT in
                        # the SQL.  Was the actual bottleneck — fact_table has 15k+
                        # metadata files, scanning 55 S3 pages per table × 5 registered
                        # tables = minutes in pre-execution.
                        _bqb_sql_refs: set = set()
                        try:
                            import sqlglot as _sg_bqb
                            _p_bqb = _sg_bqb.parse_one(raw_sql, dialect="duckdb",
                                                       error_level=_sg_bqb.ErrorLevel.IGNORE)
                            if _p_bqb:
                                for _t_bqb in _p_bqb.find_all(_sg_bqb.exp.Table):
                                    if _t_bqb.name:
                                        _bqb_sql_refs.add(_t_bqb.name.lower())
                        except Exception:
                            pass
                        # BF-PRUNE-PERF: stage signal so heartbeats / per-execution
                        # log show DISTINCT stages (set_stage only emits a new line
                        # when the stage NAME changes, so reusing "init" was a no-op).
                        try:
                            from core.execution_stage import (
                                set_stage as _stg_pc,
                                STAGE_PARTITION_DETECT as _S_PD,
                            )
                            _stg_pc(execution_id, _S_PD,
                                     message=f"Detecting partition columns ({len(_bqb_sql_refs) or '?'} "
                                             f"of {len(run_engine._registered_tables or [])} registered tables)")
                        except Exception:
                            pass
                        _bqb_raw_pf = None
                        _bqb_or_groups = None  # BF-568
                        try:
                            # Note: partition map is built first, then the call to
                            # extract_combined_filters_for_iceberg below at line 1626
                            # does the actual extraction (partition + non-partition).
                            _bqb_pc_map = {}
                            _bqb_res_s3 = None
                            for _brt in (run_engine._registered_tables or []):
                                # BF-PRUNE-PERF: skip tables not in the SQL
                                if _bqb_sql_refs and _brt.get("name", "").lower() not in _bqb_sql_refs:
                                    continue
                                # 2026-07 STRATEGIC: the ONE 5-tier partition
                                # resolver (admin → fresh-DB → cache → metadata
                                # spec → HIVE-PATH) is the primary source.  On a
                                # hit we skip the inline per-path detection below
                                # (kept only as a fallback the reader control
                                # backstops).  T4 hive-path recovers the columns
                                # even when the metadata spec parse comes up empty
                                # on a heavily schema-evolved table.
                                try:
                                    from core.iceberg_partition_resolver import (
                                        resolve_with_diagnostics as _rwd_bqb)
                                    if _bqb_res_s3 is None and not _brt.get("partition_columns"):
                                        try:
                                            _bqb_res_s3 = make_s3_client_for_conn({
                                                "id": getattr(run_engine, '_s3_conn_id', None),
                                                "config": run_engine._s3_conn_config})
                                        except Exception:
                                            _bqb_res_s3 = None
                                    _brt_res = _rwd_bqb(
                                        registered_table=_brt,
                                        db_manager=_db_manager,
                                        connection_id=getattr(run_engine, '_s3_conn_id', None),
                                        table_name=_brt.get("name"),
                                        s3_client=_bqb_res_s3,
                                        bucket=getattr(run_engine, '_s3_bucket', None),
                                        table_prefix=_brt.get("s3_prefix"))
                                    if _brt_res.cols:
                                        _bqb_pc_map[_brt["name"]] = list(_brt_res.cols)
                                        _brt["partition_columns"] = list(_brt_res.cols)
                                        continue
                                    if _brt_res.is_partitioned:
                                        logger.warning(
                                            "BQB: table %r IS partitioned but the resolver "
                                            "found NO columns — reader control will police "
                                            "the scan. Diagnostics: %s",
                                            _brt.get("name"), _brt_res.diagnostics)
                                except Exception as _rwd_bqb_exc:
                                    logger.debug("BQB: unified resolver failed (%s) — "
                                                 "inline detection fallback", _rwd_bqb_exc)
                                _brt_pc = _brt.get("partition_columns") or []
                                # Phase U (2026-06-08) — bypass S3 re-detection
                                # when the FRESH connection config in DB has
                                # partition_columns.  Pre-Phase-U:
                                #   * run_engine._registered_tables is the
                                #     in-memory snapshot loaded at engine init
                                #   * background daemon at line 3114 persists
                                #     detected cols to DB but doesn't refresh
                                #     the in-memory snapshot
                                #   * every query saw empty partition_columns
                                #     in _brt -> re-scanned S3 -> 250s
                                # Fix: when _brt is empty, fetch fresh from DB
                                # (one query, microseconds), use that to skip
                                # the S3 detection loop entirely.
                                # _exec_to_parquet_body runs in a thread pool
                                # (see _exec_to_parquet wrapper at line 2414),
                                # so a sync _db_manager call here does NOT
                                # block the event loop — call directly.
                                if not _brt_pc and _db_manager is not None:
                                    try:
                                        _pc_s3_conn_id = getattr(
                                            run_engine, '_s3_conn_id', None)
                                        if _pc_s3_conn_id:
                                            _fresh_conn = _db_manager.get_connection_raw(
                                                int(_pc_s3_conn_id))
                                            if _fresh_conn:
                                                _fresh_tables = (
                                                    _fresh_conn.get("config", {})
                                                              .get("registered_tables") or []
                                                )
                                                _fresh_match = next(
                                                    (t for t in _fresh_tables
                                                     if t.get("name") == _brt["name"]),
                                                    None,
                                                )
                                                if _fresh_match:
                                                    _fresh_pc = _fresh_match.get(
                                                        "partition_columns") or []
                                                    if _fresh_pc:
                                                        _brt_pc = _fresh_pc
                                                        # Update the in-memory dict
                                                        # so subsequent uses in THIS
                                                        # query see the data too.
                                                        _brt["partition_columns"] = _fresh_pc
                                                        logger.info(
                                                            "Partition cols loaded FROM DB for "
                                                            "'%s' (skipped %ds S3 re-detection): %s",
                                                            _brt["name"], 0, _fresh_pc,
                                                        )
                                    except Exception as _db_chk_exc:
                                        logger.debug(
                                            "DB partition_columns check failed for '%s' "
                                            "(falling through to S3 detect): %s",
                                            _brt.get("name"), _db_chk_exc,
                                        )
                                if not _brt_pc:
                                    _brt_fmt = _brt.get("format", "parquet")
                                    if _brt_fmt == "iceberg":
                                        # BF-181: Iceberg partition spec is in metadata.json —
                                        # no hive paths to scan, no admin config needed.
                                        try:
                                            from core.iceberg_reader import (
                                                _latest_metadata_key, _read_s3_json, _extract_partition_spec,
                                            )
                                            _bqb_ice_s3 = make_s3_client_for_conn({
                                                "id": getattr(run_engine, '_s3_conn_id', None),
                                                "config": run_engine._s3_conn_config,
                                            })
                                            _bqb_ice_pfx = _brt["s3_prefix"].rstrip("/") + "/metadata/"
                                            _bqb_ice_mkey = _latest_metadata_key(
                                                _bqb_ice_s3, run_engine._s3_bucket, _bqb_ice_pfx
                                            )
                                            _bqb_ice_meta = _read_s3_json(
                                                _bqb_ice_s3, run_engine._s3_bucket, _bqb_ice_mkey
                                            )
                                            _bqb_ice_spec = _extract_partition_spec(_bqb_ice_meta)
                                            if _bqb_ice_spec:
                                                _brt_pc = list(_bqb_ice_spec.keys())
                                                logger.info(
                                                    "BQB: Iceberg partition cols from metadata for '%s': %s",
                                                    _brt.get("name"), _brt_pc,
                                                )
                                        except Exception as _bqb_ice_err:
                                            # BF-270: bumped DEBUG → WARNING.  When this fails
                                            # silently, downstream pruning no-ops and the user
                                            # gets a 20-min full-table-scan with no clue why.
                                            logger.warning(
                                                "BQB: Iceberg metadata partition spec failed for '%s' (full scan will run): %s",
                                                _brt.get("name"), _bqb_ice_err,
                                            )
                                    else:
                                        # Parquet/other: auto-detect from hive path structure (BF-177)
                                        try:
                                            _auto_s3 = make_s3_client_for_conn({
                                                "id": getattr(run_engine, '_s3_conn_id', None),
                                                "config": run_engine._s3_conn_config,
                                            })
                                            _brt_pfx = (_brt.get("s3_prefix") or _brt.get("name", "")).rstrip("/")
                                            _auto_sample = list_s3_parquet_files(
                                                _auto_s3, run_engine._s3_bucket, _brt_pfx, max_files=3
                                            )
                                            _detected: list = []
                                            for _sp in _auto_sample:
                                                for _seg in _sp.replace("\\", "/").split("/"):
                                                    if "=" in _seg and not _seg.startswith("="):
                                                        _col = _seg.split("=")[0]
                                                        if _col and _col not in _detected:
                                                            _detected.append(_col)
                                            if _detected:
                                                _brt_pc = _detected
                                                logger.info(
                                                    "BQB: auto-detected partition cols for '%s': %s",
                                                    _brt.get("name"), _detected,
                                                )
                                        except Exception as _ad_err:
                                            # BF-270: bumped DEBUG → WARNING (see Iceberg branch above).
                                            logger.warning(
                                                "BQB: partition col auto-detect failed for '%s' (full scan will run): %s",
                                                _brt.get("name"), _ad_err,
                                            )
                                if _brt_pc:
                                    _bqb_pc_map[_brt["name"]] = _brt_pc
                                    # BF-PRUNE-PERF (2026-07-12): persist S3-detected
                                    # partition cols so the NEXT BQB query loads them
                                    # from DB (Phase-U branch above) instead of
                                    # re-walking S3 every time.  The raw-SQL path
                                    # already did this (see ~line 3277); the BQB path
                                    # did NOT — so every BQB run re-detected, showing up
                                    # as a repeated multi-minute "Detecting partition
                                    # columns" stage.  Only persist when config was
                                    # originally empty (these came from the S3 detect
                                    # above — the DB-load branch already set
                                    # _brt["partition_columns"], so it's excluded).
                                    if not _brt.get("partition_columns"):
                                        try:
                                            _bqb_persist_cid = getattr(run_engine, '_s3_conn_id', None)
                                            if _bqb_persist_cid:
                                                # Refresh the in-memory snapshot so even
                                                # a re-run on THIS engine skips S3.
                                                _brt["partition_columns"] = list(_brt_pc)
                                                _bqb_persist_args = (
                                                    _bqb_persist_cid, _brt["name"], list(_brt_pc),
                                                )
                                                def _bqb_bg_persist(args):
                                                    try:
                                                        from core.connection_manager import ConnectionManager as _CM_bqb
                                                        _CM_bqb(_db_manager).update_registered_table_partition_columns(*args)
                                                        logger.info(
                                                            "BQB: persisted auto-detected partition cols for '%s': %s",
                                                            args[1], args[2],
                                                        )
                                                    except Exception as _pe:
                                                        logger.debug("BQB BG persist partition cols failed for '%s': %s", args[1], _pe)
                                                threading.Thread(
                                                    target=_bqb_bg_persist,
                                                    args=(_bqb_persist_args,),
                                                    daemon=True,
                                                    name=f"persist-part-bqb-{_brt['name'][:16]}",
                                                ).start()
                                        except Exception as _bqb_persist_err:
                                            logger.debug("BQB: failed to persist partition cols for '%s': %s", _brt.get("name"), _bqb_persist_err)
                            # 2026-07 P0-A MONEY FIX — extract WHERE filters UNCONDITIONALLY.
                            # Previously gated on ``if _bqb_pc_map:``; when partition-column
                            # detection came up empty (e.g. the metadata partition-spec parse
                            # fails under heavy schema evolution) NO filters were forwarded — not
                            # even non-partition ones — so the reader received partition_filters=
                            # None and did ZERO pruning (skipped 0 by partition / min-max /
                            # supplement / bloom → full ocean scan).  But the extractor returns the
                            # WHERE filters fine with an EMPTY partition map, AND
                            # get_iceberg_data_files resolves its OWN partition spec from
                            # metadata.json — so forwarding the filters lets the reader's manifest
                            # partition pruning engage regardless of caller-side detection.  The
                            # partition-column map is now best-effort (drives JOIN-key propagation
                            # + the partition-vs-non-partition split in the log), never a gate.
                            from core.sql_partition_extractor import (
                                extract_combined_filters_and_or_groups_for_iceberg,
                            )
                            try:
                                from core.execution_stage import (
                                    set_stage as _stg_fe,
                                    STAGE_FILTER_EXTRACT as _S_FE,
                                )
                                _stg_fe(execution_id, _S_FE,
                                         message=f"sqlglot parse + WHERE-clause extraction over {len(_bqb_pc_map or {})} table(s)")
                            except Exception:
                                pass
                            _bqb_combined, _bqb_or_groups = (
                                extract_combined_filters_and_or_groups_for_iceberg(
                                    raw_sql, _bqb_pc_map or {}, dialect="duckdb"
                                )
                            )
                            if _bqb_combined:
                                _bqb_raw_pf = _bqb_combined
                                _bqb_pc_set = {c.lower() for cols in (_bqb_pc_map or {}).values() for c in cols}
                                _bqb_part_n = sum(1 for f in _bqb_raw_pf if f.get("col", "").lower() in _bqb_pc_set)
                                _bqb_nonpart_n = len(_bqb_raw_pf) - _bqb_part_n
                                logger.info(
                                    "BQB raw SQL filter extraction: %d partition + %d non-partition "
                                    "filter(s) from WHERE (partition-col map had %d table(s); the "
                                    "reader resolves its own partition spec from metadata)",
                                    _bqb_part_n, _bqb_nonpart_n, len(_bqb_pc_map or {}),
                                )
                            else:
                                # No extractable WHERE filters at all → genuine full scan.
                                logger.info(
                                    "BQB raw SQL: WHERE clause has no extractable filters → full "
                                    "table scan (no pruning possible for this query)",
                                )
                        except Exception as _bqb_pf_err:
                            # BF-270: bumped DEBUG → WARNING.
                            logger.warning(
                                "BQB raw SQL partition extraction failed (fail-open, full scan will run): %s",
                                _bqb_pf_err,
                            )
                        # S3 registered tables present — use full setup_registered_views
                        # Phase 139 honest-fix: pull time-travel params from query_config_dict
                        # if the caller (e.g. PV API) set them.
                        _qcd_for_tt = query_config_dict or {}
                        _tt_snap = _qcd_for_tt.get("_iceberg_snapshot_id")
                        _tt_asof = _qcd_for_tt.get("_iceberg_as_of_ms")
                        # BF-PRUNE-PERF: parse the raw SQL ONCE here to learn
                        # which tables are referenced, so setup_registered_views
                        # can skip every other registered table.  Was the actual
                        # cause of the 4-minute "stage=init" gap users reported
                        # (5+ tables × per-table iceberg metadata fetch).
                        # The detection loop below at line ~1894 also computes
                        # this — same logic, hoisted earlier.
                        _sql_refs_early: set = set()
                        try:
                            import sqlglot as _sg_early
                            _parsed_early = _sg_early.parse_one(
                                raw_sql, dialect="duckdb",
                                error_level=_sg_early.ErrorLevel.IGNORE,
                            )
                            if _parsed_early:
                                for _tn in _parsed_early.find_all(_sg_early.exp.Table):
                                    if _tn.name:
                                        _sql_refs_early.add(_tn.name.lower())
                        except Exception:
                            pass
                        # BF-289: thread execution_id into the boto3 download
                        # context so per-file progress lands on this exec's
                        # stage tracker.  Also mark the stage upfront so
                        # heartbeats during metadata read show "Reading
                        # Iceberg metadata" not just "running".
                        try:
                            from core.execution_stage import set_stage as _stg_set
                            from core.duckdb_views import set_dl_execution_id as _stg_dl_id
                            _stg_set(execution_id, "metadata_read",
                                      message="Reading Iceberg metadata")
                            _stg_dl_ctx = _stg_dl_id(execution_id)
                        except Exception:
                            _stg_dl_ctx = None
                        if _stg_dl_ctx is not None:
                            _stg_dl_ctx.__enter__()
                        # 2026-06-04 audit fix — stamp the thread-local
                        # file_order BEFORE setup_registered_views runs
                        # so the iceberg_reader call inside it picks up
                        # the right ScanPlan ordering.  Pre-fix the
                        # dispatcher set the local AFTER setup already
                        # ran, making the wiring a silent no-op.  Caller
                        # tag is derived inline (same logic as line 3623
                        # below) so this works on every entry path.
                        try:
                            from core.scan_strategy import (
                                ScanStrategist, WorkloadContext,
                                set_current_file_order,
                            )
                            _early_caller = (
                                "published_api" if executed_by.startswith("published_view:")
                                else "report"   if executed_by.startswith("schedule:")
                                else "bqb"
                            )
                            _early_wc = WorkloadContext(
                                caller=_early_caller,
                                file_count=0,  # unknown at this point — strategist falls back to profile defaults
                                has_limit=bool(getattr(query_config, "limit", None)),
                            )
                            _early_plan = ScanStrategist().plan(workload=_early_wc)
                            set_current_file_order(_early_plan.file_order)
                        except Exception as _ssl_exc:
                            logger.debug(
                                "[scan-strategy] early thread-local "
                                "stamp failed (degrading to admin default): %s",
                                _ssl_exc,
                            )
                        try:
                            con_raw, _sql_gen, _auto_part_raw, _all_empty_raw, _file_stats_raw = setup_registered_views(
                                run_engine, query_config,
                                run_engine._s3_conn_config,
                                run_engine._registered_tables,
                                run_engine._s3_bucket,
                                getattr(run_engine, '_s3_conn_id', None),
                                progress_fn=_sync_progress,
                                force_fresh_iceberg=_force_fresh,
                                partition_filters=_bqb_raw_pf,  # from raw SQL WHERE clause
                                or_groups=_bqb_or_groups,  # BF-568: top-level OR-branch UNION pruning
                                snapshot_id=_tt_snap,
                                as_of_timestamp_ms=_tt_asof,
                                # BF-PRUNE-PERF: pass the SQL-parsed table refs
                                # so setup_registered_views only processes the
                                # tables actually referenced (~3-5x speedup
                                # when only 2 of 10 registered tables are used).
                                referenced_tables=_sql_refs_early if _sql_refs_early else None,
                                # BF-368: column-stats supplement file-level pruning
                                # only fires when db_manager is threaded through.
                                # Without this, scanned column stats are silently
                                # ignored at query time.
                                db_manager=_db_manager,
                                # Phase J (2026-06-08): thread the raw SQL so
                                # JoinPruner.plan_probes_from_raw_joins can
                                # extract JOIN ON column equalities and emit
                                # bidirectional probes for unqualified-filter
                                # raw-SQL queries (the BQB SQL Console default).
                                raw_sql=raw_sql,
                                # Phase V (2026-06-08): pass execution_id
                                # explicitly so the recorder fires reliably
                                # regardless of ContextVar propagation.
                                execution_id=execution_id,
                            )
                        finally:
                            if _stg_dl_ctx is not None:
                                try:
                                    _stg_dl_ctx.__exit__(None, None, None)
                                except Exception:
                                    pass
                        # BF-289: setup done — switch stage to "executing".
                        # BF-376: include file count from pruning stats so the UI
                        # shows "Executing SQL against 2607 files" instead of a
                        # blank "Executing SQL" with no progress context.
                        try:
                            from core.execution_stage import set_stage as _stg_set2
                            _exec_files_total = 0
                            try:
                                if _file_stats_raw:
                                    for _ts in _file_stats_raw.values():
                                        _exec_files_total += int(_ts.get("after_pruning", 0) or 0)
                            except Exception:
                                _exec_files_total = 0
                            _stg_set2(execution_id, "duckdb_execute",
                                       files_total=_exec_files_total or None,
                                       message=(f"Executing SQL against {_exec_files_total:,} files"
                                                if _exec_files_total else "Executing SQL"))
                        except Exception:
                            pass
                        if _auto_part_raw:
                            query_config._auto_partition = _auto_part_raw
                        if _file_stats_raw:
                            query_config._file_stats = _file_stats_raw
                        if _all_empty_raw:
                            logger.info("All primary tables empty — returning 0 rows for raw SQL")
                            con_raw.close()
                            _query_gen = iter([])
                        else:
                            def _raw_sql_gen_s3():
                                try:
                                    # Debug: list views available on this connection
                                    try:
                                        _views = con_raw.execute("SELECT table_name FROM information_schema.tables WHERE table_type='VIEW'").fetchall()
                                        logger.info("BQB: DuckDB views available: %s", [v[0] for v in _views])
                                    except Exception:
                                        logger.info("BQB: Could not list views")
                                    # Phase 134-M audit follow-up — log
                                    # the FULL raw SQL so operators can
                                    # diagnose what hit S3.  Was
                                    # truncated to 500 chars which clipped
                                    # most wrap-around-raw-SQL forms
                                    # mid-WHERE.  4000 char cap covers
                                    # virtually every production PV.
                                    logger.info(
                                        "BQB: Executing raw SQL "
                                        "(execution_id=%s):\n%s",
                                        execution_id, (raw_sql or "")[:4000],
                                    )
                                    _sync_progress({"status": "processing", "log": "Executing raw SQL on S3 views..."})
                                    _t0r = _time.monotonic()
                                    # BF-262: install the DuckDB interrupt
                                    # watchdog so cancel signals can abort the
                                    # blocking execute() call mid-query, not
                                    # only between chunks.
                                    _wd_stop = _spawn_duckdb_interrupt_watchdog(
                                        con_raw, cancel_event, execution_id,
                                    )
                                    try:
                                        res_r = con_raw.execute(raw_sql)
                                        rdr = res_r.to_arrow_reader(batch_size=run_engine.chunk_size)
                                        tot = 0
                                        for b in rdr:
                                            if len(b) == 0:
                                                continue
                                            tot += len(b)
                                            _sync_progress({"status": "processing",
                                                            "log": f"Streaming: {tot:,} rows [{_time.monotonic()-_t0r:.1f}s]"})
                                            yield _pa_raw.Table.from_batches([b])
                                        _sync_progress({"status": "processing",
                                                        "log": f"Query returned {tot:,} rows [{_time.monotonic()-_t0r:.1f}s]"})
                                    finally:
                                        _wd_stop.set()
                                finally:
                                    con_raw.close()
                            _query_gen = _raw_sql_gen_s3()
                    else:
                        # Local/MV tables only — should NOT have S3 registered tables here
                        if _has_s3_tables:
                            logger.error("BQB BUG: S3 registered tables present but s3_conn_config is falsy! "
                                         "s3_conn_config=%s, registered_tables=%d",
                                         run_engine._s3_conn_config,
                                         len(run_engine._registered_tables) if run_engine._registered_tables else 0)
                        import duckdb as _ddb_local
                        # 2026-08-19 -- core.config has NO get_config().  This
                        # import raised ImportError on every BQB raw-SQL query
                        # that reached the local/MV-tables branch, and the
                        # nearest handler is the top-level query handler, so
                        # the QUERY FAILED.  The accessor is the module
                        # attribute `local_tables`.
                        from core.config import local_tables as _lt_cfg_local
                        _lt_storage = getattr(_lt_cfg_local, 'storage_dir', None)

                        con_raw = _ddb_local.connect()
                        try:
                            # Register local table views.  Sync DB call is
                            # fine — we're already on a thread-pool worker
                            # (see _exec_to_parquet wrapper at line 2414).
                            if _lt_storage and _db_manager:
                                import glob as _glob_lt_raw
                                _lt_rows = _db_manager.list_local_tables()
                                for _lt in _lt_rows:
                                    if _lt["status"] != "ready" or not _lt.get("is_active", True):
                                        continue
                                    _lt_dir = os.path.join(_lt_storage, str(_lt["id"]))
                                    _lt_pq = _glob_lt_raw.glob(os.path.join(_lt_dir, "*.parquet"))
                                    if _lt_pq:
                                        from core.path_utils import to_duckdb_path as _to_ddb_lt
                                        _lt_paths = ", ".join(f"'{_to_ddb_lt(p)}'" for p in _lt_pq)
                                        _lt_vname = f"__lt__{_lt['name']}".replace('"', '""')
                                        con_raw.execute(f'CREATE OR REPLACE VIEW "{_lt_vname}" AS SELECT * FROM read_parquet([{_lt_paths}], hive_partitioning=true)')
                                        logger.info("Local table view '%s' registered for raw SQL", _lt_vname)
                        except Exception as _lt_setup_err:
                            logger.warning("Failed to register local table views: %s", _lt_setup_err, exc_info=True)

                        def _raw_sql_gen_local():
                            try:
                                _sync_progress({"status": "processing", "log": "Executing raw SQL on local tables..."})
                                _t0r = _time.monotonic()
                                # BF-262: same interrupt watchdog as the S3
                                # path so cancellation aborts the blocking
                                # execute() rather than waiting for the next
                                # chunk boundary.
                                _wd_stop = _spawn_duckdb_interrupt_watchdog(
                                    con_raw, cancel_event, execution_id,
                                )
                                try:
                                    res_r = con_raw.execute(raw_sql)
                                    rdr = res_r.to_arrow_reader(batch_size=run_engine.chunk_size)
                                    tot = 0
                                    for b in rdr:
                                        if len(b) == 0:
                                            continue
                                        tot += len(b)
                                        _sync_progress({"status": "processing",
                                                        "log": f"Streaming: {tot:,} rows [{_time.monotonic()-_t0r:.1f}s]"})
                                        yield _pa_raw.Table.from_batches([b])
                                    _sync_progress({"status": "processing",
                                                    "log": f"Query returned {tot:,} rows [{_time.monotonic()-_t0r:.1f}s]"})
                                finally:
                                    _wd_stop.set()
                            finally:
                                con_raw.close()
                        _query_gen = _raw_sql_gen_local()
                elif _has_reg:
                    _query_gen = execute_registered_table_query(
                        run_engine, query_config,
                        run_engine._s3_conn_config,
                        run_engine._registered_tables,
                        run_engine._s3_bucket,
                        getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        force_fresh_iceberg=_force_fresh,
                        db_manager=_db_manager,    # BF-368: enables col-stats supplement
                        execution_id=execution_id,  # the pruning record's key
                    )
                elif raw_sql:
                    if run_engine._s3_conn_config:
                        # ── Raw SQL + S3: subprocess-isolated COPY TO ──
                        # BF-PRUNE-PERF-LOG: the heartbeat shows "stage=init" for
                        # 10+ minutes here because this branch never advances the
                        # stage tracker.  Emit signals at every checkpoint so the
                        # user sees WHICH step is hanging.
                        try:
                            from core.execution_stage import (
                                set_stage as _stg_rs,
                                STAGE_PARTITION_DETECT as _S_RS_PD,
                            )
                            _stg_rs(execution_id, _S_RS_PD,
                                    message="Detecting partition columns per registered table (raw-SQL S3 path)")
                        except Exception:
                            pass
                        fh.close()  # close file handle — subprocess writes directly
                        _setup_stmts = []
                        _esc = lambda v: v.replace("'", "''")
                        _rt_bucket = run_engine._s3_bucket or ""
                        _rt_s3 = None  # lazily created when needed
                        # BF-279: log "(N referenced of M registered)" so the
                        # message reflects what S3 work actually fires (we
                        # skip unreferenced tables a few lines below — the
                        # old "M registered table(s)" sounded like all M
                        # were being scanned).
                        _total_regs = (
                            len(run_engine._registered_tables)
                            if run_engine._registered_tables else 0
                        )
                        _refs_for_log: set = set()
                        try:
                            import sqlglot as _sg_for_log
                            _parsed_for_log = _sg_for_log.parse_one(
                                raw_sql, dialect="duckdb",
                                error_level=_sg_for_log.ErrorLevel.IGNORE,
                            )
                            if _parsed_for_log:
                                for _tn_for_log in _parsed_for_log.find_all(_sg_for_log.exp.Table):
                                    if _tn_for_log.name:
                                        _refs_for_log.add(_tn_for_log.name.lower())
                        except Exception:
                            pass
                        _ref_count = (
                            len({t.get("name", "").lower()
                                  for t in (run_engine._registered_tables or [])
                                  if (t.get("name", "").lower()) in _refs_for_log})
                            if _refs_for_log and run_engine._registered_tables
                            else _total_regs
                        )
                        logger.info(
                            "Raw SQL: executing against S3 (%d of %d registered table(s) referenced). SQL:\n%s",
                            _ref_count, _total_regs,
                            (raw_sql or "")[:800],
                        )
                        # 2026-10-02 -- the view names the registered-table
                        # loop below BINDS (pruned on the statement's own
                        # WHERE).  The raw-file loop after it reads this set:
                        # a ``files`` entry naming one of them is that same
                        # table, never a second, unpruned raw S3 prefix.
                        _bound_view_names: set = set()
                        if run_engine._registered_tables:

                            # BF-190: Extract SQL table references FIRST so we can skip
                            # unreferenced registered tables in both detection and file-listing.
                            # Previously _sql_refs was extracted AFTER the detection loop —
                            # all 4 registered tables got S3-sampled even if the SQL only used 2.
                            _sql_refs: set = set()
                            try:
                                import sqlglot as _sg_ref
                                _parsed_ref = _sg_ref.parse_one(raw_sql, dialect="duckdb", error_level=_sg_ref.ErrorLevel.IGNORE)
                                if _parsed_ref:
                                    for _tbl_node in _parsed_ref.find_all(_sg_ref.exp.Table):
                                        if _tbl_node.name:
                                            _sql_refs.add(_tbl_node.name.lower())
                                if _sql_refs:
                                    logger.info("Raw SQL table references: %s", sorted(_sql_refs))
                                else:
                                    logger.debug("Raw SQL: no table refs extracted (fail-open — will process all registered tables)")
                            except Exception as _ref_err:
                                logger.debug("Raw SQL table reference extraction failed (fail-open): %s", _ref_err)

                            # Phase 122B: Extract partition filters from SQL WHERE for pruning
                            _sql_pf = None
                            _sql_og = None   # 2026-10-08: the WHERE's OR-of-AND-groups (branches)
                            _rt_part_cols = {}  # populated from admin config + auto-detect; init here so warning check at end is always valid
                            try:
                                from core.sql_partition_extractor import (
                                    extract_partition_values_from_sql,
                                    partition_filters_to_pruning_format,
                                )
                                _rt_part_cols = {}
                                _ice_ref_names: list = []   # iceberg tables the SQL references
                                for _rtp in run_engine._registered_tables:
                                    # BF-190: Skip unreferenced tables in detection loop too.
                                    # 2026-07 name-match robustness: the SQL may reference a table
                                    # by its BARE name (FROM fact_table) while it's registered
                                    # schema-qualified (claudestore.fins.fact_table) or vice-versa.
                                    # Match the bare last dot/slash-segment BOTH ways so a
                                    # qualified/bare mismatch never silently SKIPS the table
                                    # (which drops its partition_columns → full-table ocean scan).
                                    if _sql_refs:
                                        _rtp_nm = _rtp["name"].lower()
                                        _rtp_bare = _rtp_nm.rsplit(".", 1)[-1].rsplit("/", 1)[-1]
                                        _refs_bare = {str(r).rsplit(".", 1)[-1].rsplit("/", 1)[-1]
                                                      for r in _sql_refs}
                                        if (_rtp_nm not in _sql_refs
                                                and _rtp_bare not in _sql_refs
                                                and _rtp_bare not in _refs_bare):
                                            logger.debug("Raw SQL: skipping partition detection for unreferenced table '%s'", _rtp["name"])
                                            continue
                                    if str(_rtp.get("format", "")).lower() == "iceberg":
                                        _ice_ref_names.append(_rtp["name"])
                                    # 2026-07 STRATEGIC: the ONE 5-tier resolver
                                    # (admin → fresh-DB → cache → metadata spec →
                                    # HIVE-PATH) is primary; a hit skips the inline
                                    # detection below (kept as a fallback the
                                    # reader control backstops).
                                    try:
                                        from core.iceberg_partition_resolver import (
                                            resolve_with_diagnostics as _rwd_rtp)
                                        if _rt_s3 is None and not _rtp.get("partition_columns"):
                                            try:
                                                _rt_s3 = make_s3_client_for_conn({
                                                    "id": getattr(run_engine, '_s3_conn_id', None),
                                                    "config": run_engine._s3_conn_config})
                                            except Exception:
                                                _rt_s3 = None
                                        _rtp_res = _rwd_rtp(
                                            registered_table=_rtp,
                                            db_manager=_db_manager,
                                            connection_id=getattr(run_engine, '_s3_conn_id', None),
                                            table_name=_rtp.get("name"),
                                            s3_client=_rt_s3,
                                            bucket=_rt_bucket,
                                            table_prefix=_rtp.get("s3_prefix"))
                                        if _rtp_res.cols:
                                            _rt_part_cols[_rtp["name"]] = list(_rtp_res.cols)
                                            _rtp["partition_columns"] = list(_rtp_res.cols)
                                            continue
                                        if _rtp_res.is_partitioned:
                                            logger.warning(
                                                "Raw SQL: table %r IS partitioned but the resolver "
                                                "found NO columns — reader control will police the "
                                                "scan. Diagnostics: %s",
                                                _rtp.get("name"), _rtp_res.diagnostics)
                                    except Exception as _rwd_rtp_exc:
                                        logger.debug("Raw SQL: unified resolver failed (%s) — "
                                                     "inline detection fallback", _rwd_rtp_exc)
                                    _rtp_pc = _rtp.get("partition_columns") or []
                                    # Phase U (2026-06-08) — same fix as the
                                    # streaming path above: load fresh from
                                    # DB before re-scanning S3 (the in-memory
                                    # _registered_tables snapshot is stale
                                    # because the background persist daemon
                                    # writes to DB without refreshing the
                                    # engine's cache).
                                    # Sync DB call is fine here — same
                                    # thread-pool worker context as the BQB
                                    # path above.
                                    if not _rtp_pc and _db_manager is not None:
                                        try:
                                            _rtp_conn_id = getattr(
                                                run_engine, '_s3_conn_id', None)
                                            if _rtp_conn_id:
                                                _rtp_fresh_conn = _db_manager.get_connection_raw(
                                                    int(_rtp_conn_id))
                                                if _rtp_fresh_conn:
                                                    _rtp_fresh_tables = (
                                                        _rtp_fresh_conn.get("config", {})
                                                                       .get("registered_tables") or []
                                                    )
                                                    _rtp_fresh_match = next(
                                                        (t for t in _rtp_fresh_tables
                                                         if t.get("name") == _rtp["name"]),
                                                        None,
                                                    )
                                                    if _rtp_fresh_match:
                                                        _rtp_fresh_pc = _rtp_fresh_match.get(
                                                            "partition_columns") or []
                                                        if _rtp_fresh_pc:
                                                            _rtp_pc = _rtp_fresh_pc
                                                            _rtp["partition_columns"] = _rtp_fresh_pc
                                                            logger.info(
                                                                "Raw SQL: partition cols loaded "
                                                                "FROM DB for '%s' (skipped S3 "
                                                                "re-detection): %s",
                                                                _rtp["name"], _rtp_fresh_pc,
                                                            )
                                        except Exception as _rtp_db_exc:
                                            logger.debug(
                                                "Raw SQL: DB partition_columns check "
                                                "failed for '%s': %s",
                                                _rtp.get("name"), _rtp_db_exc,
                                            )
                                    if not _rtp_pc:
                                        _rtp_fmt = _rtp.get("format", "parquet")
                                        if _rtp_fmt == "iceberg":
                                            # BF-181: Iceberg partition spec is in metadata.json
                                            # (no hive paths; metadata is source of truth)
                                            try:
                                                from core.iceberg_reader import (
                                                    _latest_metadata_key, _read_s3_json_cached, _extract_partition_spec,
                                                )
                                                if _rt_s3 is None:
                                                    _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                                _rtp_meta_pfx = _rtp["s3_prefix"].rstrip("/") + "/metadata/"
                                                _rtp_mkey = _latest_metadata_key(_rt_s3, _rt_bucket, _rtp_meta_pfx)
                                                _rtp_meta = _read_s3_json_cached(_rt_s3, _rt_bucket, _rtp_mkey)
                                                _rtp_spec = _extract_partition_spec(_rtp_meta)
                                                if _rtp_spec:
                                                    _rtp_pc = list(_rtp_spec.keys())
                                                    logger.info("Raw SQL: Iceberg partition cols from metadata for '%s': %s", _rtp["name"], _rtp_pc)
                                            except Exception as _rtp_ice_err:
                                                logger.debug("Raw SQL: Iceberg partition spec failed for '%s': %s", _rtp["name"], _rtp_ice_err)
                                            # 2026-07 HIVE-PATH FALLBACK for iceberg — the metadata
                                            # partition-spec parse can come back EMPTY under heavy
                                            # schema evolution (field-id→name drift across 90+
                                            # schemas) or a transform-renamed field, even though the
                                            # table IS partitioned.  The partition is ALWAYS in the
                                            # data-file hive path (col=value/), so sample a file and
                                            # read the segment names — spec-evolution-proof, exactly
                                            # like the parquet branch below.  This is what stops the
                                            # "no partition columns → full ocean scan" on iceberg.
                                            if not _rtp_pc:
                                                try:
                                                    if _rt_s3 is None:
                                                        _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                                    _ice_pfx = (_rtp.get("s3_prefix") or _rtp.get("name", "")).rstrip("/")
                                                    _ice_sample = list_s3_parquet_files(_rt_s3, _rt_bucket, _ice_pfx, max_files=5)
                                                    _ice_detected: list = []
                                                    for _sp in _ice_sample:
                                                        for _seg in _sp.replace("\\", "/").split("/"):
                                                            if "=" in _seg and not _seg.startswith("="):
                                                                _col = _seg.split("=")[0]
                                                                if _col and _col not in _ice_detected:
                                                                    _ice_detected.append(_col)
                                                    if _ice_detected:
                                                        _rtp_pc = _ice_detected
                                                        logger.info(
                                                            "Raw SQL: Iceberg partition cols from HIVE-PATH "
                                                            "FALLBACK (metadata spec empty) for '%s': %s",
                                                            _rtp["name"], _ice_detected)
                                                except Exception as _ice_hp_err:
                                                    logger.debug("Raw SQL: Iceberg hive-path fallback failed for '%s': %s", _rtp["name"], _ice_hp_err)
                                        else:
                                            # BF-180: Parquet/other — auto-detect from hive S3 paths
                                            try:
                                                if _rt_s3 is None:
                                                    _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                                _rtp_pfx = (_rtp.get("s3_prefix") or _rtp.get("name", "")).rstrip("/")
                                                _auto_sample = list_s3_parquet_files(_rt_s3, _rt_bucket, _rtp_pfx, max_files=3)
                                                _detected: list = []
                                                for _sp in _auto_sample:
                                                    for _seg in _sp.replace("\\", "/").split("/"):
                                                        if "=" in _seg and not _seg.startswith("="):
                                                            _col = _seg.split("=")[0]
                                                            if _col and _col not in _detected:
                                                                _detected.append(_col)
                                                if _detected:
                                                    _rtp_pc = _detected
                                                    logger.info("Raw SQL: auto-detected partition cols for '%s': %s", _rtp["name"], _detected)
                                            except Exception as _ad_err:
                                                logger.debug("Raw SQL: partition col auto-detect failed for '%s': %s", _rtp["name"], _ad_err)
                                    if _rtp_pc:
                                        _rt_part_cols[_rtp["name"]] = _rtp_pc
                                        # BF-189 + Phase 139 audit-fix Gap 5:
                                        # Auto-persist detected partition columns so they don't need
                                        # re-detection on every query and appear in the admin UI.
                                        # Only saves when no partition_columns were configured before
                                        # (i.e., the detection just happened above, not from admin config).
                                        # Phase 139 audit-fix: was inline DB write — now fire-and-forget
                                        # via a daemon thread so concurrent queries don't all race the
                                        # same write and the user's query doesn't block on a DB call.
                                        if not _rtp.get("partition_columns"):
                                            try:
                                                _s3_conn_id = getattr(run_engine, '_s3_conn_id', None)
                                                if _s3_conn_id:
                                                    _persist_args = (
                                                        _s3_conn_id, _rtp["name"], list(_rtp_pc),
                                                    )
                                                    def _bg_persist_partition_cols(args):
                                                        try:
                                                            from core.connection_manager import ConnectionManager as _CM_bg
                                                            _CM_bg(_db_manager).update_registered_table_partition_columns(*args)
                                                            logger.info(
                                                                "Raw SQL: persisted auto-detected partition cols for '%s': %s",
                                                                args[1], args[2],
                                                            )
                                                        except Exception as _pe:
                                                            logger.debug("BG persist partition cols failed for '%s': %s", args[1], _pe)
                                                    threading.Thread(
                                                        target=_bg_persist_partition_cols,
                                                        args=(_persist_args,),
                                                        daemon=True,
                                                        name=f"persist-part-{_rtp['name'][:20]}",
                                                    ).start()
                                            except Exception as _persist_err:
                                                logger.debug("Raw SQL: failed to persist partition cols for '%s': %s", _rtp["name"], _persist_err)
                                # 2026-10-08 -- the WHERE's top-level OR of AND-groups
                                # (P13 on real AWS: read all 2,688 files, Trino 92).
                                # This road never asked the extractor for them; the
                                # Iceberg reader and the hive-path pruner union per
                                # branch under core.filter_ops.disjunction_decision.
                                try:
                                    from core.sql_partition_extractor import (
                                        extract_combined_filters_and_or_groups_for_iceberg as _ecog,
                                    )
                                    _sql_og = _ecog(raw_sql, {}, dialect="duckdb")[1] or None
                                    if _sql_og:
                                        logger.info(
                                            "Raw SQL disjunction: %d OR branch(es) extracted from "
                                            "WHERE: %s", len(_sql_og),
                                            [[(f.get("col"), f.get("op"), f.get("val")) for f in b]
                                             for b in _sql_og])
                                except Exception as _og_err:
                                    logger.debug("Raw SQL OR-group extraction failed (fail-open): %s", _og_err)
                                    _sql_og = None
                                if _rt_part_cols:
                                    _extracted = extract_partition_values_from_sql(
                                        raw_sql, _rt_part_cols, dialect="duckdb")
                                    if _extracted:
                                        _sql_pf = partition_filters_to_pruning_format(_extracted)
                                        logger.info(
                                            "Raw SQL partition pruning: extracted %d filter(s) from WHERE clause: %s",
                                            len(_sql_pf),
                                            [(f["col"], f["op"], f["val"]) for f in _sql_pf],
                                        )
                                    else:
                                        logger.info(
                                            "Raw SQL partition pruning: partition cols known %s but WHERE clause "
                                            "has no matching values — full scan. Add partition filters to WHERE "
                                            "clause (e.g. WHERE business_close_date = '2025-09-30') to enable pruning.",
                                            list(_rt_part_cols.keys()),
                                        )
                                # Phase Z.6 (2026-06-09) — ALSO extract NON-
                                # partition WHERE filters and append to _sql_pf.
                                # Pre-Phase-Z.6: only partition cols were
                                # extracted; non-partition filters (e.g. WHERE
                                # system_id = 'XYZ') were silently dropped at
                                # this SQL→pf layer.  iceberg_reader's
                                # column-stats / supplement pruning paths
                                # NEVER got a chance to apply them — so a
                                # user's selective filter on a non-partition
                                # column with supplement bounds couldn't
                                # prune any files.  ``extract_all_filters_
                                # from_sql`` already existed in the codebase
                                # (sql_partition_extractor.py:379); just
                                # wasn't wired into the BQB raw-SQL path.
                                try:
                                    from core.sql_partition_extractor import (
                                        extract_all_filters_from_sql as _eafs,
                                    )
                                    _all_extracted = _eafs(raw_sql, dialect="duckdb")
                                    if _all_extracted:
                                        _all_pf = partition_filters_to_pruning_format(
                                            _all_extracted)
                                        # Dedupe against the partition-only set
                                        _seen = {
                                            (f.get("col", "").lower(),
                                             (f.get("op") or "").lower(),
                                             str(f.get("val")))
                                            for f in (_sql_pf or [])
                                        }
                                        _added = 0
                                        for _f in _all_pf:
                                            _k = (_f.get("col", "").lower(),
                                                  (_f.get("op") or "").lower(),
                                                  str(_f.get("val")))
                                            if _k in _seen:
                                                continue
                                            _seen.add(_k)
                                            if _sql_pf is None:
                                                _sql_pf = []
                                            _sql_pf.append(_f)
                                            _added += 1
                                        if _added:
                                            logger.info(
                                                "Raw SQL non-partition pruning: extracted %d "
                                                "additional filter(s) from WHERE clause "
                                                "(beyond partition cols): %s",
                                                _added,
                                                [(f["col"], f["op"], f["val"])
                                                 for f in _all_pf
                                                 if (f.get("col", "").lower(),
                                                     (f.get("op") or "").lower(),
                                                     str(f.get("val"))) in _seen][-_added:],
                                            )
                                except Exception as _all_pf_err:
                                    logger.debug(
                                        "Raw SQL all-filter extraction failed "
                                        "(fail-open): %s", _all_pf_err,
                                    )
                            except Exception as _pf_err:
                                logger.debug("Raw SQL partition extraction failed (fail-open): %s", _pf_err)

                            # _sql_refs already extracted above (BF-190) — no duplicate parse needed.

                            if not _sql_pf:
                                # BF-186: Check _rt_part_cols (populated from admin config + S3 auto-detect),
                                # NOT _registered_tables[].partition_columns (admin config only).
                                # Auto-detection may have succeeded even if admin config is empty.
                                if not _rt_part_cols:
                                    logger.warning(
                                        "Raw SQL: no partition columns found via admin config or S3 auto-detect — "
                                        "partition pruning disabled. Configure partition_columns in connection admin, "
                                        "or ensure table S3 paths use hive-style partitioning (col=value/)."
                                    )
                                else:
                                    # Partition cols exist but WHERE clause has no matching filters — full scan
                                    logger.debug(
                                        "Raw SQL: partition columns available %s but WHERE clause has no matching "
                                        "partition filters — full table scan (no pruning applied).",
                                        list(_rt_part_cols.keys()),
                                    )

                            # Create S3 client once, reuse for all tables (may already be set by auto-detect above)
                            if _rt_s3 is None:
                                _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})

                            # ── Phase S (2026-06-08): wire JoinPruner brain INTO the
                            # subprocess raw-SQL path so it gets the SAME pruning as
                            # the BQB streaming path.  Pre-Phase-S, this branch
                            # bypassed JoinPruner entirely → raw-SQL JOIN queries
                            # over-scanned the joined-side table (user-reported
                            # "ext_table 1239 files" symptom).
                            #
                            # Algorithm (mirrors duckdb_views.setup_registered_views):
                            #   1. plan_probes_from_raw_joins(raw_sql, _sql_pf)
                            #   2. For each anchor table, get_iceberg_data_files with
                            #      join_key_columns to capture min/max bounds
                            #   3. Synthesize BETWEEN filter for the target side
                            #   4. Inject synth filters into _sql_pf so the
                            #      per-table loop below uses them
                            _subprocess_synth_filters_by_table: Dict[str, List[Dict[str, Any]]] = {}
                            # Phase S R2 fix (2026-06-08): cache anchor pre-fetch
                            # results to AVOID double-reading the anchor table in
                            # _process_one_table_impl below.  Map keyed on table
                            # name (lower); value is (rt_files_list, out_meta).
                            _subprocess_anchor_prefetch: Dict[str, tuple] = {}
                            try:
                                from core.join_pruner import JoinPruner as _JP_sub
                                _jp_sub = _JP_sub()
                                _rj_probes = _jp_sub.plan_probes_from_raw_joins(
                                    raw_sql, _sql_pf,
                                )
                                if _rj_probes:
                                    logger.info(
                                        "Phase S (subprocess path): %d raw-SQL JOIN ON "
                                        "probe(s) -- engaging brain on table-by-table "
                                        "iceberg reads", len(_rj_probes),
                                    )
                                    # Build bounds per anchor table
                                    from core.iceberg_reader import (
                                        get_iceberg_data_files as _gidf_sub,
                                    )
                                    _anchor_bounds_map: Dict[str, Dict[str, Any]] = {}
                                    # 2026-06-08 — group probes by anchor_table and
                                    # collect ALL anchor_cols for that table.  One
                                    # iceberg read per table returns bounds for
                                    # EVERY join key at once.  Previous dedup-by-
                                    # table-only stopped trying alternative join
                                    # columns as soon as the FIRST one came back
                                    # empty — losing all pruning when the first
                                    # column happened to be a partition column
                                    # (manifest column-stats don't cover those).
                                    _cols_per_anchor: Dict[str, List[str]] = {}
                                    for _probe in _rj_probes:
                                        _cols_per_anchor.setdefault(
                                            _probe.anchor_table, []
                                        )
                                        if _probe.anchor_col not in _cols_per_anchor[_probe.anchor_table]:
                                            _cols_per_anchor[_probe.anchor_table].append(_probe.anchor_col)
                                    for _anchor_table, _anchor_cols in _cols_per_anchor.items():
                                        _anchor_tbl_meta = next(
                                            (_rt for _rt in run_engine._registered_tables
                                             if (_rt.get("name") or "").lower() == _anchor_table),
                                            None,
                                        )
                                        if not _anchor_tbl_meta:
                                            continue
                                        _anchor_filters = list(_sql_pf or [])
                                        _anchor_om: Dict[str, Any] = {}
                                        if execution_id:
                                            _anchor_om["execution_id"] = execution_id
                                        try:
                                            _anchor_files = _gidf_sub(
                                                _rt_s3, _rt_bucket,
                                                _anchor_tbl_meta["s3_prefix"].rstrip("/"),
                                                partition_filters=_anchor_filters,
                                                keys_only=True,
                                                join_key_columns=list(_anchor_cols),
                                                _out_meta=_anchor_om,
                                                db_manager=_db_manager,
                                                table_name=_anchor_tbl_meta.get("name"),
                                                connection_id=getattr(run_engine, '_s3_conn_id', None),
                                            )
                                            _subprocess_anchor_prefetch[
                                                _anchor_table] = (
                                                _anchor_files, _anchor_om,
                                            )
                                            _jkb_all = _anchor_om.get("join_key_bounds") or {}
                                            _captured: Dict[str, tuple] = {}
                                            _empty_cols: List[str] = []
                                            for _ac in _anchor_cols:
                                                _bnd = _jkb_all.get(_ac.lower())
                                                if _bnd:
                                                    _lo, _hi = _bnd
                                                    if _lo is not None and _hi is not None:
                                                        _captured[_ac.lower()] = (_lo, _hi)
                                                        continue
                                                _empty_cols.append(_ac)
                                            if _captured:
                                                _anchor_bounds_map[_anchor_table] = _captured
                                                logger.info(
                                                    "Phase S: anchor '%s' bounds captured "
                                                    "for cols=%s (%d files); empty for cols=%s",
                                                    _anchor_table,
                                                    {c: (str(v[0])[:40], str(v[1])[:40])
                                                     for c, v in _captured.items()},
                                                    len(_anchor_files or []),
                                                    _empty_cols,
                                                )
                                            else:
                                                logger.warning(
                                                    "Phase S: anchor '%s' returned NO "
                                                    "join_key_bounds for any of cols=%s -- "
                                                    "target won't be pruned via JOIN. "
                                                    "Likely cause: manifest column-stats "
                                                    "don't cover these (often because they "
                                                    "are partition columns — partition "
                                                    "values live in data_file.partition, "
                                                    "not lower_bounds).  Run column-stats "
                                                    "scan if needed.",
                                                    _anchor_table, _anchor_cols,
                                                )
                                        except Exception as _abe:
                                            logger.warning(
                                                "Phase S: anchor bounds aggregation "
                                                "FAILED for %s (type=%s): %s",
                                                _anchor_table,
                                                type(_abe).__name__, _abe,
                                                exc_info=True,
                                            )
                                    # Synthesize IN-list (preferred — strictly
                                    # more selective) or BETWEEN filter for
                                    # targets.  IN-list source is the per-anchor
                                    # ``join_key_distinct_values`` populated when
                                    # every surviving file had a single value for
                                    # the col (partition-col case + some sort-
                                    # ordered columns).  Falls back to BETWEEN
                                    # when distinct-set is missing OR too large
                                    # to safely inline.  Cap matches Trino's
                                    # default (200 elements) so the generated
                                    # WHERE doesn't blow up the parser.
                                    _IN_LIST_MAX = 200
                                    _anchor_distinct_map: Dict[str, Dict[str, list]] = {}
                                    for _at, (_, _om) in _subprocess_anchor_prefetch.items():
                                        _dv = _om.get("join_key_distinct_values") or {}
                                        if _dv:
                                            _anchor_distinct_map[_at] = _dv
                                    for _probe in _rj_probes:
                                        # 2026-07-14 — PREFER the complete IN-list
                                        # (equality set) FIRST, independent of
                                        # whether a BETWEEN bound survived.  The
                                        # anchor refuses a BETWEEN for an
                                        # ordering-ambiguous numeric-string RANGE
                                        # (the data-loss guard) but still emits the
                                        # IN-list — which is the SAFE, collation-
                                        # independent pushdown for exactly that
                                        # numeric-string partition key.  The old
                                        # `if not bounds: continue` gate dropped the
                                        # IN-list in that case, leaving the joined
                                        # table unpruned.
                                        _dvs = (_anchor_distinct_map
                                                .get(_probe.anchor_table, {})
                                                .get(_probe.anchor_col.lower()))
                                        _bnds = _anchor_bounds_map.get(
                                            _probe.anchor_table) or {}
                                        _bnd = _bnds.get(_probe.anchor_col.lower())
                                        if _dvs and 0 < len(_dvs) <= _IN_LIST_MAX:
                                            _synth_f = {
                                                "col": _probe.target_col,
                                                "op": "in",
                                                "val": [str(v) for v in _dvs],
                                            }
                                        elif _bnd:
                                            _lo_p, _hi_p = _bnd
                                            _synth_f = {
                                                "col": _probe.target_col,
                                                "op": "between",
                                                "val": [str(_lo_p), str(_hi_p)],
                                            }
                                        else:
                                            # Neither a safe IN-list nor a
                                            # non-ambiguous BETWEEN → no pushdown
                                            # (fail-open: joined table not pruned
                                            # on this key).
                                            continue
                                        _subprocess_synth_filters_by_table.setdefault(
                                            _probe.target_table, []).append(_synth_f)
                                    if _subprocess_synth_filters_by_table:
                                        logger.info(
                                            "Phase S: injected synth filters into "
                                            "%d target table(s): %s",
                                            len(_subprocess_synth_filters_by_table),
                                            {k: [(f["col"], f["op"],
                                                  f"vals={len(f['val'])}"
                                                  if f["op"] == "in" else
                                                  f"range={f['val']}")
                                                 for f in v]
                                             for k, v in _subprocess_synth_filters_by_table.items()},
                                        )
                            except Exception as _ps_exc:
                                logger.debug(
                                    "Phase S subprocess brain wiring failed "
                                    "(fail-open, no brain pruning): %s", _ps_exc,
                                )

                            # BF-PRUNE-PERF-LOG: per-table Iceberg metadata + manifest
                            # pruning starts here.  Was the silent 10-minute gap.
                            try:
                                from core.execution_stage import (
                                    set_stage as _stg_rs2,
                                    STAGE_METADATA_READ as _S_RS_MR,
                                )
                                _refs_n = len(_sql_refs) if _sql_refs else (
                                    len(run_engine._registered_tables or []))
                                _stg_rs2(execution_id, _S_RS_MR,
                                          message=f"Reading Iceberg metadata + pruning manifests for {_refs_n} table(s)")
                            except Exception:
                                pass

                            # BF-PRUNE-PERF-LOG: accumulate the post-prune file
                            # count across all tables so the UI can show
                            # "X of N files scanned" during duckdb_execute.
                            _files_to_scan_total = 0
                            _files_listed_total = 0      # 2026-10-08: the pruner's count
                            _files_per_table: dict = {}
                            # Track per-query temp dirs for boto3 pre-download
                            # cleanup (only used when cache_act() is False but
                            # proxy_act() triggered pre-download).
                            _bqb_predownload_tmp_dirs: list = []

                            # BF-PARALLEL-TABLES: parallelise per-table iceberg
                            # metadata read + manifest pruning across registered
                            # tables.  Was sequential — for 2 tables × ~50s each,
                            # cut metadata_read time roughly in half.  ThreadPoolExecutor
                            # is safe here: each iteration only touches its own table,
                            # boto3 client is thread-safe, and we collect results
                            # then merge into the shared lists in this thread.
                            from concurrent.futures import ThreadPoolExecutor as _PT_TPE, as_completed as _PT_AC
                            import time as _ts_time

                            _tables_to_process = [
                                _rt for _rt in run_engine._registered_tables
                                if not (_sql_refs and _rt["name"].lower() not in _sql_refs)
                            ]
                            for _rt_skip in run_engine._registered_tables:
                                if _sql_refs and _rt_skip["name"].lower() not in _sql_refs:
                                    logger.info("Raw SQL: skipping unreferenced registered table '%s'", _rt_skip["name"])

                            def _process_one_table(_rt):
                                """Per-table worker — returns dict with setup_stmt, name,
                                files, tmp_dir, or None on hard failure.

                                BF-423 — wraps body in try/finally that unregisters
                                tmp_dir from registries ON THE META_RD THREAD.  This
                                MUST run on the same thread that registered (via
                                _pre_dl → predownload → register_temp_dir) because
                                ``unregister_temp_dir`` only walks the CURRENT
                                thread's _thread_local.temp_dirs.  The earlier
                                BF-422 attempt called unregister from the OUTER
                                pool worker thread — only cleaned _global_temp_dirs,
                                left the meta_rd thread's local growing unbounded
                                across the pod's lifetime (executor pool reuses
                                threads pinned to "meta_rd" name).  Plus: any
                                exception AFTER _pre_dl registered a tmp_dir but
                                BEFORE _result_tmp_dir got assigned would have
                                leaked even with BF-422 — now the finally closes
                                that gap too.
                                """
                                # cleanup_temp_downloads cleans EVERYTHING in this
                                # meta_rd thread's _thread_local.temp_dirs that
                                # was registered during this _process_one_table
                                # invocation, AND removes from _global_temp_dirs.
                                # The aggregator at line ~3140 still rmtrees
                                # _bqb_predownload_tmp_dirs by direct path —
                                # that's independent of registry state and
                                # remains the source of truth for disk cleanup.
                                # Note: cleanup_temp_downloads CALLS rmtree on
                                # each registered dir, but the aggregator path
                                # collects _r["tmp_dir"] BEFORE we get here.
                                # The dirs are still on disk because _pre_dl
                                # was called BEFORE this finally would fire?
                                # No — finally runs after `return`, so the
                                # caller has already consumed _result_tmp_dir.
                                # We need to UNregister-only here, not rmtree,
                                # so the dirs survive for the aggregator to
                                # rmtree later.
                                _captured_tmp_dir = None
                                try:
                                    _result = _process_one_table_impl(_rt)
                                    if _result and _result.get("tmp_dir"):
                                        _captured_tmp_dir = _result["tmp_dir"]
                                    return _result
                                finally:
                                    # Unregister whatever this meta_rd thread
                                    # accumulated in _thread_local.temp_dirs.
                                    # If _process_one_table_impl raised AFTER
                                    # register but BEFORE we captured the path,
                                    # ``cleanup_temp_downloads`` would rmtree
                                    # AND unregister — but that would also
                                    # blow away the partial download's files
                                    # which we want for diagnostics.  Use
                                    # unregister-only on _captured_tmp_dir;
                                    # for any other entries left in the
                                    # thread-local (the failed-mid-register
                                    # case), do a full cleanup since those
                                    # files are unreachable anyway.
                                    try:
                                        from core.duckdb_views import (
                                            unregister_temp_dir as _unreg_pt,
                                            _thread_local as _tl_pt,
                                            cleanup_temp_downloads as _ctd_pt,
                                        )
                                        if _captured_tmp_dir:
                                            # Successful path: dir owned by aggregator now,
                                            # just unregister so registries stay clean.
                                            _unreg_pt(_captured_tmp_dir)
                                        # Anything STILL in this thread's
                                        # _thread_local.temp_dirs is leaked
                                        # state from a failed mid-register —
                                        # rmtree + unregister those.
                                        _leftover = list(getattr(_tl_pt, "temp_dirs", []) or [])
                                        if _leftover:
                                            _ctd_pt()  # cleans this thread's locals
                                    except Exception as _pt_clean_exc:
                                        logger.debug(
                                            "[bf423] meta_rd cleanup raised: %s",
                                            _pt_clean_exc,
                                        )

                            def _process_one_table_impl(_rt):
                                _rt_name = _rt["name"].replace('"', '""')
                                _rt_fmt = _rt.get("format", "parquet")
                                _rt_prefix = _rt["s3_prefix"].rstrip("/")
                                _rt_t0 = _ts_time.monotonic()
                                _result_setup_stmt = None
                                _result_files = 0
                                # 2026-10-08 -- the PRUNER's count beside what the
                                # view reads: the LIMIT-only early stop trims after
                                # pruning, and "post-prune scan total" says both.
                                _result_files_listed = 0
                                _result_tmp_dir = None
                                try:
                                    from core.execution_stage import update_progress as _stg_upd_rt
                                    _stg_upd_rt(execution_id,
                                                message=f"Reading metadata + pruning manifests for '{_rt['name']}'…")
                                except Exception:
                                    pass
                                if _rt_fmt == "iceberg":
                                    try:
                                        from core.iceberg_reader import (
                                            get_iceberg_data_files,
                                            _latest_metadata_key,
                                            _read_s3_json,
                                            _extract_partition_spec,
                                            detect_iceberg_schema_evolution,
                                        )
                                        # BF-181: Read partition spec from Iceberg metadata — no admin config needed.
                                        # Iceberg metadata.json has the partition spec; use it to extract
                                        # WHERE clause filter values and pass to get_iceberg_data_files()
                                        # for Avro manifest-level pruning (correct, fast, zero config).
                                        # filter_iceberg_files_by_partitions was hive-path-based (wrong for Iceberg).
                                        _ice_metadata = None
                                        _ice_pf = _sql_pf  # fallback to sql_pf if metadata read fails
                                        _ice_og = _sql_og  # 2026-10-08: the WHERE's OR branches
                                        try:
                                            _ice_meta_pfx = _rt["s3_prefix"].rstrip("/") + "/metadata/"
                                            # 2026-10-07 -- this pre-read IS the pointer
                                            # the table is read at (the metadata is
                                            # handed to get_iceberg_data_files below,
                                            # which then skips its own resolve).  It
                                            # ignored force_fresh, so on this road
                                            # ``cache_strategy: bypass`` served the
                                            # cached pointer (real AWS: a Trino insert
                                            # invisible for 47 s).
                                            _ice_meta_key = _latest_metadata_key(
                                                _rt_s3, _rt_bucket, _ice_meta_pfx,
                                                force_fresh=_force_fresh)
                                            _ice_metadata = _read_s3_json(_rt_s3, _rt_bucket, _ice_meta_key)
                                            _ice_part_spec = _extract_partition_spec(_ice_metadata)
                                            if _ice_part_spec and raw_sql:
                                                # BF-NON-PARTITION-PRUNE: extract BOTH partition AND
                                                # non-partition filters so column-stats pruning
                                                # (_file_matches_column_stats in iceberg_reader)
                                                # actually receives the WHERE-clause predicates it
                                                # was designed to use.  Was: only partition cols
                                                # extracted; non-partition filters silently dropped
                                                # at extraction → 1241 files read on a query that
                                                # could prune to 5-50 if its bounds were used.
                                                from core.sql_partition_extractor import (
                                                    extract_combined_filters_and_or_groups_for_iceberg,
                                                )
                                                _ice_col_map = {_rt["name"]: list(_ice_part_spec.keys())}
                                                # 2026-10-08: ask for the OR branches too (the
                                                # AND-only call dropped them on this road).
                                                _ice_pf_combined, _ice_og_combined = (
                                                    extract_combined_filters_and_or_groups_for_iceberg(
                                                        raw_sql, _ice_col_map, dialect="duckdb"
                                                    )
                                                )
                                                _ice_og = _ice_og_combined or None
                                                if _ice_pf_combined:
                                                    _ice_pf = _ice_pf_combined
                                                    _ice_part_cols = {c.lower() for c in _ice_part_spec.keys()}
                                                    _part_count = sum(1 for f in _ice_pf if f.get("col", "").lower() in _ice_part_cols)
                                                    _nonpart_count = len(_ice_pf) - _part_count
                                                    logger.info(
                                                        "Raw SQL Iceberg '%s': spec=%s → %d partition + %d non-partition filter(s) from WHERE clause",
                                                        _rt["name"], list(_ice_part_spec.keys()), _part_count, _nonpart_count,
                                                    )
                                        except Exception as _ice_spec_err:
                                            logger.debug(
                                                "Raw SQL Iceberg '%s': metadata partition spec read failed (fail-open): %s",
                                                _rt["name"], _ice_spec_err,
                                            )
                                        # Phase S (2026-06-08) -- inject any
                                        # JoinPruner-synthesized filters for this
                                        # table that were computed earlier (when
                                        # this table is a TARGET of a join probe).
                                        _ice_pf_with_synth = list(_ice_pf or [])
                                        _rt_name_lower = (_rt.get("name") or "").lower()
                                        _synth_for_this = _subprocess_synth_filters_by_table.get(
                                            _rt_name_lower)
                                        if _synth_for_this:
                                            _ice_pf_with_synth.extend(_synth_for_this)
                                            logger.info(
                                                "Phase S: '%s' is a JOIN target -- "
                                                "adding %d synth filter(s): %s",
                                                _rt.get("name"),
                                                len(_synth_for_this),
                                                [(f["col"], f["op"]) for f in _synth_for_this],
                                            )
                                        # Phase S R2 fix: if THIS table is an anchor
                                        # we already pre-fetched, REUSE the result
                                        # instead of reading the same iceberg table
                                        # twice.  Skip when synth filters were added
                                        # (target case wants a NEW read with synth
                                        # filter), or when pf doesn't match the
                                        # pre-fetch's filter set.
                                        _cached_anchor = _subprocess_anchor_prefetch.get(
                                            _rt_name_lower)
                                        if _cached_anchor and not _synth_for_this:
                                            _rt_files, _rt_out_meta = _cached_anchor
                                            logger.info(
                                                "Phase S R2: reusing pre-fetched anchor "
                                                "read for '%s' (%d files) -- avoids "
                                                "duplicate iceberg read",
                                                _rt.get("name"),
                                                len(_rt_files or []),
                                            )
                                        else:
                                            # Phase N -- pass _out_meta so the shadow-write
                                            # block at the END of get_iceberg_data_files
                                            # populates the PruneContext / scan_plan DB row.
                                            _rt_out_meta: Dict[str, Any] = {}
                                            # Phase V: stamp execution_id so
                                            # recorder fires regardless of
                                            # ContextVar propagation.
                                            if execution_id:
                                                _rt_out_meta["execution_id"] = execution_id
                                            # Phase 156 memo key (2026-07-22): the
                                            # reader memoises the SURVIVING FILE
                                            # LIST keyed on (sql_hash, bucket,
                                            # table_prefix, snapshot).  Survivors
                                            # are a PURE FUNCTION of those + the
                                            # effective filters, so we hash the
                                            # EFFECTIVE filters (WHERE + any synth
                                            # join filters) — NOT the raw SQL —
                                            # because synth join-key VALUES come
                                            # from the other table and vary
                                            # run-to-run.  Identical filters ⟺
                                            # identical hash ⟹ correct reuse;
                                            # different synth values ⟹ different
                                            # hash ⟹ re-prune (never a stale/other
                                            # survivor set).  force_fresh and
                                            # MoR-delete snapshots are guarded
                                            # inside the reader's memo gate.
                                            # Fold in table_name: the reader's B3
                                            # scope guard DROPS filters qualified
                                            # to a non-target table, so the
                                            # effective survivor set is a function
                                            # of table_name too.  On the fallback
                                            # path (_sql_pf — unpartitioned / spec
                                            # read failure / empty extraction) the
                                            # filter list is multi-table and NOT
                                            # pre-scoped, so two names pointing at
                                            # the SAME physical prefix could share
                                            # a key while B3 gives them different
                                            # effective filters.  Hashing the name
                                            # (what B3 keys on) closes that hole on
                                            # every path, at zero hit-rate cost for
                                            # single-registration tables.
                                            _phase156_sql_hash = None
                                            try:
                                                import hashlib as _hl156
                                                import json as _js156
                                                _pf_sig = _js156.dumps(
                                                    {"t": (_rt.get("name") or ""),
                                                     "f": _ice_pf_with_synth or [],
                                                     # 2026-10-08: the OR branches are part
                                                     # of the survivor set's identity too.
                                                     "or": _ice_og or []},
                                                    sort_keys=True, default=str)
                                                # usedforsecurity=False (2026-09-13
                                                # triage, S324): content-addressing --
                                                # a pruning-memo key over a table name
                                                # plus its partition filters.  It picks
                                                # a SCAN PLAN; row visibility is
                                                # enforced in the emitted SQL, so this
                                                # gates nothing.  Digest unchanged.
                                                _phase156_sql_hash = "pf:" + _hl156.sha1(
                                                    _pf_sig.encode("utf-8"),
                                                    usedforsecurity=False).hexdigest()
                                            except Exception:
                                                _phase156_sql_hash = None
                                            _rt_files = get_iceberg_data_files(
                                                _rt_s3, _rt_bucket, _rt["s3_prefix"],
                                                partition_filters=_ice_pf_with_synth or None,
                                                keys_only=True,
                                                force_fresh=_force_fresh,
                                                metadata=_ice_metadata,
                                                db_manager=_db_manager,
                                                _out_meta=_rt_out_meta,
                                                table_name=_rt.get("name"),
                                                connection_id=getattr(run_engine, '_s3_conn_id', None),
                                                sql_hash=_phase156_sql_hash,
                                                or_groups=_ice_og,  # 2026-10-08: union per branch
                                            )
                                        # 2026-07-14 DATA-LOSS SAFETY NET (hardened) —
                                        # the synth join-key IN/BETWEEN filters are a
                                        # semi-join OPTIMIZATION; they must never be
                                        # the reason the target is empty.  When they
                                        # pruned the target to 0, re-read using ONLY
                                        # the target's own WHERE filters (i.e. WITHOUT
                                        # the synth filters) and let the re-read decide:
                                        #   * re-read is ALSO 0  → the target really is
                                        #     empty for this WHERE → keep empty (the
                                        #     empty-view path below returns 0 rows).
                                        #   * re-read has N > 0  → the synth filter's
                                        #     cross-table value encoding didn't line up
                                        #     (drift the reconciliation didn't bridge)
                                        #     → use the N files so the JOIN can't
                                        #     silently drop rows.
                                        # MUST be fully fault-tolerant: bypass the
                                        # max_files cap (this is a correctness recovery,
                                        # not a normal scan) and swallow ANY error so a
                                        # failed re-read can NEVER propagate into the
                                        # outer handler and drop this table's CREATE
                                        # VIEW (which would crash the COPY with
                                        # "table does not exist").
                                        if (not _rt_files and _synth_for_this
                                                and _ice_pf_with_synth != (_ice_pf or [])):
                                            logger.warning(
                                                "Phase S SAFETY NET: synth join filter(s) %s "
                                                "pruned target '%s' to 0 files — re-reading "
                                                "WITHOUT synth (WHERE filters only) to rule "
                                                "out a cross-table value-encoding mismatch.",
                                                [(f.get('col'), f.get('op')) for f in _synth_for_this],
                                                _rt.get("name"),
                                            )
                                            try:
                                                # B2 (deep-dive round 5): bypass the
                                                # max_files cap ONLY when the target
                                                # has its OWN WHERE filters to bound
                                                # the re-read.  With NO own filters,
                                                # re-reading uncapped = a full-table
                                                # scan / OOM (and this fires even on a
                                                # legitimately-empty inner join) — so
                                                # keep the cap on; if it trips, the
                                                # except below yields a 0-row view.
                                                _sn_cap_off = bool(_ice_pf)
                                                _rt_files = get_iceberg_data_files(
                                                    _rt_s3, _rt_bucket, _rt["s3_prefix"],
                                                    partition_filters=_ice_pf or None,
                                                    keys_only=True,
                                                    force_fresh=_force_fresh,
                                                    metadata=_ice_metadata,
                                                    db_manager=_db_manager,
                                                    _out_meta={},  # B5: fresh — no dup scan_plan write
                                                    table_name=_rt.get("name"),
                                                    connection_id=getattr(run_engine, '_s3_conn_id', None),
                                                    enforce_max_files_cap=(not _sn_cap_off),
                                                    or_groups=_ice_og,
                                                ) or []
                                            except Exception as _sn_exc:
                                                logger.warning(
                                                    "Phase S SAFETY NET: re-read for '%s' failed "
                                                    "(%s) — leaving target empty (0-row view); "
                                                    "no crash.", _rt.get("name"), _sn_exc,
                                                )
                                                _rt_files = []
                                            if _rt_files:
                                                logger.warning(
                                                    "Phase S SAFETY NET: '%s' has %d files "
                                                    "without synth pruning — using those "
                                                    "(correctness over selectivity).",
                                                    _rt.get("name"), len(_rt_files),
                                                )
                                            else:
                                                logger.info(
                                                    "Phase S SAFETY NET: '%s' is genuinely "
                                                    "empty under its WHERE filters — 0-row "
                                                    "view (correct 0 rows).", _rt.get("name"),
                                                )
                                        # BF-507 (2026-05-28) — 0-files case must STILL
                                        # emit a CREATE VIEW so the downstream COPY
                                        # doesn't crash with ``CatalogException: Table
                                        # does not exist``.  My earlier BF-504 fix
                                        # covered ``setup_registered_views`` in
                                        # duckdb_views.py — but THIS code path is a
                                        # separate raw-SQL S3 view builder
                                        # (_process_one_table_impl) that builds its
                                        # own CREATE VIEW inline.  Without an
                                        # else-branch the view is silently skipped.
                                        # User report (2026-05-28 14:19 logs):
                                        # CatalogException for ``claudetrialbalance``
                                        # when WHERE businessdate='2026-02-28' AND
                                        # receiveddate='2026-03-05' AND flex_sap_
                                        # company_code IN [...] pruned to 0 files.
                                        # 2026-10-07 LIMIT-ONLY EARLY STOP
                                        # (core/limit_early_stop.py): a statement
                                        # any n rows of this table answer reads
                                        # only the first files whose manifest
                                        # record counts reach n.  Declines (and
                                        # logs why) on every other shape.
                                        _result_files_listed = len(_rt_files or [])
                                        if _rt_files and raw_sql:
                                            try:
                                                from core.limit_early_stop import (
                                                    plan_limit_early_stop as _les_plan)
                                                _les_kept = _les_plan(
                                                    raw_sql, _rt.get("name") or "", _rt_files,
                                                    [f.get("record_count") if isinstance(f, dict) else None
                                                     for f in _rt_files],
                                                    _rt_out_meta, road="raw_sql_subprocess",
                                                    bucket=_rt_bucket, table_prefix=_rt["s3_prefix"],
                                                    execution_id=execution_id)
                                            except Exception as _les_exc:  # noqa: BLE001
                                                logger.debug("[limit-early-stop] skipped for %r: %s",
                                                             _rt.get("name"), _les_exc)
                                                _les_kept = None
                                            if _les_kept is not None:
                                                _rt_files = _les_kept
                                        if not _rt_files:
                                            _result_files = 0
                                            # 2026-07-14 CRASH FIX: prefer the
                                            # ICEBERG METADATA schema (all columns
                                            # incl PARTITION source columns, no S3)
                                            # for the 0-row view.  A read_parquet
                                            # sample can PHYSICALLY omit partition
                                            # columns (projection / non-identity
                                            # transform) → the JOIN `ON
                                            # ext.business_close_date = ...` still
                                            # fails to bind.  Metadata is
                                            # transform-independent + already in
                                            # hand, so it always binds.
                                            _empty_ddl = typed_empty_view_ddl(
                                                _rt_name,
                                                getattr(run_engine, '_s3_conn_id', None),
                                                _db_manager,
                                                iceberg_metadata=_ice_metadata)
                                            if _empty_ddl:
                                                _result_setup_stmt = _empty_ddl
                                                logger.info(
                                                    "BF-507: raw-SQL iceberg '%s' pruned to "
                                                    "0 files — empty view from iceberg schema "
                                                    "(JOIN-safe, partition cols included)",
                                                    _rt_name,
                                                )
                                            else:
                                                # No cached/metadata schema — last
                                                # resort: read_parquet sample, then
                                                # a bare dummy view.
                                                try:
                                                    _schema_sample = get_iceberg_data_files(
                                                        _rt_s3, _rt_bucket, _rt["s3_prefix"],
                                                        keys_only=True, max_files=1,
                                                        force_fresh=False,
                                                    )
                                                    if _schema_sample:
                                                        _sf_raw = f"s3://{_rt_bucket}/{_schema_sample[0]['key']}"
                                                        _sf_presigned = s3_urls_to_presigned(
                                                            _rt_s3, [_sf_raw],
                                                            run_engine._s3_conn_config,
                                                        )[0]
                                                        _result_setup_stmt = (
                                                            f'CREATE VIEW "{_rt_name}" AS '
                                                            f'SELECT * FROM read_parquet('
                                                            f"'{_esc(_sf_presigned)}', "
                                                            f"hive_partitioning=true) "
                                                            f"WHERE FALSE"
                                                        )
                                                    else:
                                                        _result_setup_stmt = (
                                                            f'CREATE VIEW "{_rt_name}" AS '
                                                            f"SELECT 1 AS dummy WHERE FALSE")
                                                    logger.info(
                                                        "BF-507: raw-SQL iceberg '%s' pruned "
                                                        "to 0 files — emitting empty view "
                                                        "(no cached schema; used sample/dummy)",
                                                        _rt_name,
                                                    )
                                                except Exception as _bf507_exc:
                                                    logger.warning(
                                                        "BF-507: empty-view schema-sample "
                                                        "fetch failed for '%s' (%s) — bare "
                                                        "dummy view", _rt_name, _bf507_exc,
                                                    )
                                                    _result_setup_stmt = (
                                                        f'CREATE VIEW "{_rt_name}" AS '
                                                        f"SELECT 1 AS dummy WHERE FALSE")
                                        if _rt_files:
                                            _rt_urls = [f"s3://{_rt_bucket}/{f['key']}" for f in _rt_files]
                                            _result_files = len(_rt_urls)
                                            # F1 (2026-07-15): keep the ORIGINAL writer s3:// uris
                                            # (parallel to the read paths) + the read-path LIST so the
                                            # raw-SQL builder can apply Iceberg MoR deletes via the
                                            # shared _apply_mor_view chokepoint (else deletes are never
                                            # applied here -> +726 overcount).
                                            _rt_orig_urls = list(_rt_urls)
                                            _rt_read_list = None
                                            # BF-PRUNE-PERF: optional boto3 pre-download
                                            _used_predownload = False
                                            try:
                                                from core.duckdb_views import (
                                                    _is_proxy_active_for_duckdb as _proxy_act,
                                                    _is_s3_cache_active as _cache_act,
                                                    _s3_to_local_via_boto3 as _pre_dl,
                                                    set_dl_execution_id as _dl_set_eid,
                                                )
                                                if _proxy_act() or _cache_act():
                                                    with _dl_set_eid(execution_id):
                                                        _local_paths, _tmp_dir = _pre_dl(
                                                            _rt_s3, _rt_urls,
                                                        )
                                                    if _local_paths:
                                                        # Round 19: use to_duckdb_path so the
                                                        # Windows \\?\ long-path prefix is preserved
                                                        # correctly.  Blanket .replace('\\','/')
                                                        # was turning \\?\C:\... into //?/C:/...
                                                        # — DuckDB rejects that.  Symptom on
                                                        # user's box: "No files found that match
                                                        # the pattern //?/C:/...".
                                                        from core.s3_predownload import to_duckdb_path as _to_ddb
                                                        _rt_read_list = [_to_ddb(p) for p in _local_paths]
                                                        _rt_paths = ", ".join(
                                                            f"'{_esc(p)}'"
                                                            for p in _rt_read_list
                                                        )
                                                        _used_predownload = True
                                                        if _tmp_dir:
                                                            _result_tmp_dir = _tmp_dir
                                                        logger.info(
                                                            "Iceberg '%s': pre-downloaded %d files via boto3 (cache=%s, proxy=%s) → CREATE VIEW points at local paths",
                                                            _rt_name, len(_local_paths),
                                                            _cache_act(), _proxy_act(),
                                                        )
                                            except Exception as _pre_dl_err:
                                                logger.warning(
                                                    "Iceberg '%s': boto3 pre-download failed (fail-open to direct httpfs): %s",
                                                    _rt_name, _pre_dl_err,
                                                )
                                            if not _used_predownload:
                                                _rt_urls = s3_urls_to_presigned(_rt_s3, _rt_urls, run_engine._s3_conn_config)
                                                _rt_read_list = list(_rt_urls)
                                                _rt_paths = ", ".join(f"'{_esc(u)}'" for u in _rt_urls)
                                            # Deep-dive fix: previously this only used the
                                            # schema-evolution auto-detector, ignoring the user's
                                            # ``s3.duckdb_union_by_name_iceberg`` config flag.
                                            # The flag is the admin's explicit "I know my writer
                                            # produces uniform schemas, don't pay the per-file
                                            # footer read cost" — auto-detector overriding it
                                            # made the flag useless on this code path.
                                            #
                                            # New semantics:
                                            #   config flag TRUE  → always union_by_name=true (admin force-on)
                                            #   config flag FALSE → trust admin: NO union_by_name even if
                                            #                       detector says evolution (admin opted out)
                                            #   detector then ALSO consulted for safety logging only.
                                            try:
                                                from core.config import s3 as _s3_ub_cfg
                                                _ubn_flag = bool(_s3_ub_cfg.duckdb_union_by_name_iceberg)
                                                _ubn_max_ub = int(getattr(
                                                    _s3_ub_cfg,
                                                    "union_by_name_max_files",
                                                    200))
                                            except Exception:
                                                _ubn_flag = False
                                                _ubn_max_ub = 200
                                            try:
                                                _ub_detected = detect_iceberg_schema_evolution(_ice_metadata or {})
                                            except Exception:
                                                _ub_detected = True
                                            # 2026-06-24 threshold-gated auto
                                            # enable -- mirrors duckdb_views
                                            # REG-VIEW path.  Evolution +
                                            # small file set => union_by_name
                                            # (correctness); evolution +
                                            # large file set => admin flag
                                            # wins (avoids 200-350s footer
                                            # scan).  Opt out via env
                                            # QS_FORCE_FAST_ICEBERG=1.
                                            import os as _os_ub
                                            _force_fast_ub = _os_ub.environ.get(
                                                "QS_FORCE_FAST_ICEBERG", "").strip() in (
                                                "1", "true", "TRUE", "yes")
                                            _fc_ub = len(_rt_files) if _rt_files else 0
                                            _evo_ub_in_threshold = (
                                                _ub_detected
                                                and not _force_fast_ub
                                                and _fc_ub <= _ubn_max_ub
                                            )
                                            _ub_name = (
                                                True if _evo_ub_in_threshold
                                                else _ubn_flag
                                            )
                                            _ub_kw = ", union_by_name=true" if _ub_name else ""
                                            if _evo_ub_in_threshold and not _ubn_flag:
                                                logger.info(
                                                    "Iceberg '%s' schema evolution + "
                                                    "file count %d <= threshold %d -- "
                                                    "auto-enabling union_by_name=true "
                                                    "(correctness).",
                                                    _rt_name, _fc_ub, _ubn_max_ub,
                                                )
                                            elif _ub_detected and not _ubn_flag and _fc_ub > _ubn_max_ub:
                                                logger.warning(
                                                    "Iceberg '%s' schema evolution BUT "
                                                    "file count %d > threshold %d -- "
                                                    "using fast path to avoid 200-350s "
                                                    "penalty.  Add partition filters or "
                                                    "raise s3.union_by_name_max_files.",
                                                    _rt_name, _fc_ub, _ubn_max_ub,
                                                )
                                            elif _ub_name:
                                                logger.info(
                                                    "Iceberg '%s' CREATE VIEW with union_by_name=true "
                                                    "(admin config s3.duckdb_union_by_name_iceberg=true)",
                                                    _rt_name,
                                                )
                                            else:
                                                logger.info(
                                                    "Iceberg '%s' uniform schema → CREATE VIEW WITHOUT union_by_name (fast path)",
                                                    _rt_name,
                                                )
                                            # F1 (2026-07-15): apply Iceberg MoR deletes on the raw-SQL
                                            # direct-S3 path too — via the SHARED _apply_mor_view
                                            # chokepoint (con=None -> returns the CREATE VIEW SQL).
                                            # Without this, a V2 merge-on-read table read as raw SQL
                                            # built a delete-blind view -> +726 overcount.  fail_loud=
                                            # True: if delete files EXIST but provably can't be applied,
                                            # refuse (MorDeletesUnresolvableError) rather than overcount.
                                            _mor_sql_raw = None
                                            if _rt_read_list and (
                                                (_rt_out_meta or {}).get("pos_delete_files")
                                                or (_rt_out_meta or {}).get("eq_delete_files")
                                            ):
                                                _mor_sql_raw = _apply_mor_view(
                                                    None, _rt_name, _rt_name.replace('"', '""'),
                                                    _rt_read_list, _rt_orig_urls, _rt_out_meta,
                                                    _rt_bucket, run_engine._s3_conn_config, _rt_s3,
                                                    _rt["s3_prefix"],
                                                    log_prefix="REG-VIEW-RAWSQL", fail_loud=True,
                                                )
                                            if _mor_sql_raw:
                                                _result_setup_stmt = _mor_sql_raw
                                            else:
                                                # 2026-09-25 -- THE read decision (partition values
                                                # from the data files vs the hive path; current-schema
                                                # projection) comes from core.iceberg_read_plan, the
                                                # same chokepoint the batch / streaming / MoR builders
                                                # use.  This statement is DEFERRED (executed in the
                                                # subprocess), so there is no binder-error fallback
                                                # here: the plan only projects a column the manifest
                                                # proves every file stores, or NULL for one no file
                                                # stores.
                                                from core.iceberg_read_plan import (
                                                    plan_iceberg_read as _plan_ice_raw,
                                                    iceberg_view_select_sql as _ice_sel_raw,
                                                )
                                                _rt_plan = _plan_ice_raw(
                                                    list(_rt_read_list or []), meta=_rt_out_meta,
                                                    union_by_name=bool(_ub_name),
                                                    table_name=_rt_name, log_prefix="REG-VIEW-RAWSQL",
                                                )
                                                _result_setup_stmt = (
                                                    f'CREATE VIEW "{_rt_name}" AS {_ice_sel_raw(_rt_plan)}'
                                                )
                                    except (MorDeletesUnresolvableError, MorDeleteCollectionError):
                                        # DATA-COMPLETENESS refusal: delete files exist but can't be
                                        # applied -> fail LOUD, never serve a delete-blind overcount.
                                        raise
                                    except ValueError as _rte_ve:
                                        # Step 4a raises ValueError when the table has DELETE manifests
                                        # and iceberg_mor is disabled (merge-on-read).  That is a
                                        # correctness fail-loud too -> propagate, don't swallow.
                                        _m = str(_rte_ve).lower()
                                        if "delete" in _m or "merge-on-read" in _m:
                                            raise
                                        logger.warning("Could not register Iceberg view '%s' for raw SQL: %s", _rt_name, _rte_ve, exc_info=True)
                                    except Exception as _rte:
                                        logger.warning("Could not register Iceberg view '%s' for raw SQL: %s", _rt_name, _rte, exc_info=True)
                                elif _rt_fmt == "parquet":
                                    try:
                                        _rt_conn_id = getattr(run_engine, '_s3_conn_id', None) or 0
                                        _rt_pq_files = list_s3_parquet_files_cached(_rt_conn_id, _rt_s3, _rt_bucket, _rt_prefix)
                                        # 2026-08-20 — surface the listing's
                                        # truncated=True verdict (was dropped
                                        # here: >cap tables silently queried a
                                        # subset).  Certificate goes INCOMPLETE.
                                        try:
                                            from core.scan_truncation import surface_truncated_listing as _stl_rt
                                            _stl_rt(_rt_pq_files, table=_rt_name,
                                                    bucket=_rt_bucket, prefix=_rt_prefix)
                                        except Exception as _stl_rt_exc:
                                            logger.warning("listing-truncation surface failed for '%s': %s",
                                                           _rt_name, _stl_rt_exc)
                                        _rt_pq_listed = len(_rt_pq_files or [])
                                        if _rt_pq_files and (_sql_pf or _sql_og):
                                            from core.s3_utilities import filter_iceberg_files_by_partitions as _filt_pq
                                            # 2026-10-08: the OR branches reach the hive-path
                                            # pruner too (union per branch under the one decision).
                                            _rt_pq_files = _filt_pq(_rt_pq_files, _sql_pf, or_groups=_sql_og)
                                        _result_files_listed = len(_rt_pq_files or [])
                                        # 2026-10-07 LIMIT-ONLY EARLY STOP, plain parquet (core/limit_early_stop.py):
                                        # a statement any n rows of this table answer reads only the LEADING
                                        # files whose footers' row counts reach n (probed in batches).  Declines
                                        # (and logs why) on every other shape.  BEFORE the scan budget: a bare
                                        # LIMIT trimmed to a handful of files is not a whole-table scan.
                                        if _rt_pq_files and raw_sql:
                                            try:
                                                from core.limit_early_stop import plan_hive_limit_early_stop as _les_hive
                                                _les_hive_kept = _les_hive(raw_sql, _rt.get("name") or "", _rt_pq_files, _rt_s3, _rt_bucket,
                                                                           road="raw_sql_subprocess", table_prefix=_rt_prefix,
                                                                           execution_id=execution_id)
                                            except Exception as _les_hive_exc:  # noqa: BLE001 -- never break the read
                                                logger.debug("[limit-early-stop] skipped for %r: %s", _rt.get("name") or "", _les_hive_exc)
                                                _les_hive_kept = None
                                            if _les_hive_kept is not None:
                                                _rt_pq_files = _les_hive_kept
                                        # 2026-10-08 -- this road never left a query_pruning_history
                                        # row (the duckdb_views parquet roads have since Phase 151),
                                        # so a plain-parquet typed-SQL query had no "files read of
                                        # listed" at all.  Same hook, same shape; the PRUNER's count
                                        # is files_after_prune -- the trim above records files_read.
                                        try:
                                            from core.plain_parquet_brain_hooks import (
                                                brain_enabled as _pp_brain_on_raw,
                                                record_pruning_history_for_parquet as _rec_pp_raw,
                                            )
                                            if _pp_brain_on_raw() and _rt_pq_listed > 0:
                                                _rec_pp_raw(
                                                    bucket=_rt_bucket, table_prefix=_rt_prefix,
                                                    files_before_prune=_rt_pq_listed,
                                                    files_after_prune=_result_files_listed,
                                                    stage_drops={"partition": max(0, _rt_pq_listed - _result_files_listed)},
                                                    filter_breakdown=list(_sql_pf or []),
                                                    source="execute_api.parquet.raw_sql",
                                                    file_keys=list(_rt_pq_files or []),
                                                )
                                        except Exception as _pp_raw_exc:  # noqa: BLE001 -- never break the read
                                            logger.warning("plain_parquet pruning_history NOT recorded for '%s': %s",
                                                           _rt.get("name") or "", _pp_raw_exc)
                                        if _rt_pq_files:
                                            _result_files = len(_rt_pq_files)
                                            _rt_pq_files = s3_urls_to_presigned(_rt_s3, _rt_pq_files, run_engine._s3_conn_config)
                                            _rt_pq_paths = ", ".join(f"'{_esc(f)}'" for f in _rt_pq_files)
                                            # 2026-10-06 -- partition keys typed as DECLARED
                                            # (the recorded schema), never guessed per read.
                                            from core.hive_partition_types import (
                                                declared_partition_types as _decl_pt,
                                                hive_types_clause_for_paths as _ht_paths,
                                            )
                                            _rt_ht = _ht_paths(_rt_pq_files, _decl_pt(_rt_conn_id, _rt["name"], _db_manager,
                                                                                      paths=_rt_pq_files))
                                            _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet([{_rt_pq_paths}], hive_partitioning=true{_rt_ht})'
                                        else:
                                            _is_onprem_raw = get_s3_access_mode(run_engine._s3_conn_config) == "presigned"
                                            if _is_onprem_raw:
                                                raise RuntimeError(f"No parquet files found for '{_rt['name']}' on on-prem S3. Check S3 prefix and credentials.")
                                            _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true, hive_types_autocast=false)'
                                    except Exception as _rt_pq_err:
                                        _is_onprem_raw2 = get_s3_access_mode(run_engine._s3_conn_config) == "presigned"
                                        if _is_onprem_raw2:
                                            raise RuntimeError(f"Failed to register on-prem S3 table '{_rt['name']}': {_rt_pq_err}") from _rt_pq_err
                                        _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_parquet(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.parquet\', hive_partitioning=true, hive_types_autocast=false)'
                                elif _rt_fmt == "csv":
                                    _is_onprem_csv = get_s3_access_mode(run_engine._s3_conn_config) == "presigned"
                                    if _is_onprem_csv:
                                        from core.s3_utilities import list_s3_csv_files as _csv_list_raw
                                        _csv_files_raw = _csv_list_raw(_rt_s3, _rt_bucket, _rt_prefix)
                                        if _csv_files_raw:
                                            _csv_files_raw = s3_urls_to_presigned(_rt_s3, _csv_files_raw, run_engine._s3_conn_config)
                                            _csv_paths_raw = ", ".join(f"'{_esc(f)}'" for f in _csv_files_raw)
                                            _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_csv_auto([{_csv_paths_raw}])'
                                        else:
                                            logger.warning("No CSV files found for '%s' (presigned mode)", _rt_name)
                                            _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT 1 WHERE FALSE'
                                    else:
                                        _result_setup_stmt = f'CREATE VIEW "{_rt_name}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(_rt_bucket)}/{_esc(_rt_prefix)}/**/*.csv\')'
                                # Per-table elapsed log
                                _rt_dt = _ts_time.monotonic() - _rt_t0
                                logger.info(
                                    "[metadata_read] table='%s' format=%s elapsed=%.2fs files_after_prune=%d files_read=%d",
                                    _rt['name'], _rt_fmt, _rt_dt, _result_files_listed, _result_files,
                                )
                                try:
                                    from core.execution_stage import add_extras as _stg_extras_rt
                                    _stg_extras_rt(execution_id, **{
                                        f"metadata_read_seconds__{_rt['name']}": round(_rt_dt, 3),
                                    })
                                except Exception:
                                    pass
                                return {
                                    "name": _rt['name'],
                                    "setup_stmt": _result_setup_stmt,
                                    "files": _result_files,
                                    "files_listed": max(_result_files_listed, _result_files),
                                    "tmp_dir": _result_tmp_dir,
                                }

                            # Dispatch all tables in parallel.  max_workers capped
                            # so we don't open too many concurrent S3 sessions.
                            _max_par = min(len(_tables_to_process), 8) or 1
                            _results_in_order = [None] * len(_tables_to_process)
                            # 2026-10-08 -- each worker runs under a COPY of this
                            # thread's context so the execution-id ContextVar
                            # (query_diagnostic_store) reaches it: the per-table
                            # work records query_pruning_history rows (the plain
                            # parquet hook, the LIMIT-only early stop's files_read)
                            # and a bare pool thread attributed them to NOBODY --
                            # counted as skipped_no_execution_id, never written.
                            import contextvars as _ctxv_pt
                            with _PT_TPE(max_workers=_max_par,
                                         thread_name_prefix="meta_rd") as _ex_pt:
                                _fut_idx = {}
                                for _idx, _rt_p in enumerate(_tables_to_process):
                                    _fut_idx[_ex_pt.submit(_ctxv_pt.copy_context().run,
                                                           _process_one_table, _rt_p)] = _idx
                                for _fut in _PT_AC(_fut_idx):
                                    _idx_done = _fut_idx[_fut]
                                    try:
                                        _results_in_order[_idx_done] = _fut.result()
                                    except Exception as _proc_err:
                                        logger.warning(
                                            "Per-table parallel worker failed for table idx=%d: %s",
                                            _idx_done, _proc_err, exc_info=True,
                                        )
                                        _results_in_order[_idx_done] = None

                            # Merge results into shared lists in deterministic order
                            # BF-507 — empty-view setup_stmts (0 files) are still
                            # appended so the user's COPY query has a view to
                            # reference.  Without this, 0-file tables crash COPY
                            # with CatalogException.
                            for _idx_r, _r in enumerate(_results_in_order):
                                # B1/B4 (deep-dive round 5): GUARANTEE every
                                # expected table has a view.  A worker that threw
                                # (_r is None) or an iceberg body that threw before
                                # building its DDL (setup_stmt None) would leave the
                                # table with NO view → the COPY crashes with
                                # "CatalogException: Table does not exist" — the very
                                # failure BF-507's empty view exists to prevent, but
                                # it lives inside the per-table try so an earlier
                                # throw bypasses it.  Inject a real-schema 0-row
                                # fallback view so the JOIN binds and returns 0 rows.
                                # 2026-07-14 (round 5 self-audit fix): a fallback
                                # 0-row view is ONLY correct when the table has NO
                                # data.  If a worker DIED (_r is None) or resolved
                                # files>0 but built no view, we CANNOT know the
                                # result is empty — substituting a WHERE-FALSE view
                                # would SILENTLY drop that table's rows.  Fail LOUD
                                # in those cases (a clear error, not a wrong answer).
                                # 2026-07-14 impact-analysis fix: only fail LOUD for a
                                # table we KNOW the query references.  When the SQL
                                # parse failed, `_sql_refs` fail-opens to empty and
                                # ALL registered tables get processed — so an
                                # UNREFERENCED table's build failure must NOT abort a
                                # query that doesn't even use it (pre-change it just
                                # contributed no view and the query succeeded).  When
                                # `_sql_refs` is non-empty, `_tables_to_process` was
                                # filtered to referenced tables only, so the raise is
                                # correct.  If refs are unknown, skip the table — a
                                # downstream CatalogException still surfaces loudly iff
                                # it turns out to be referenced.
                                _refs_known = bool(_sql_refs)
                                if _r is None:
                                    _dead = ((_tables_to_process[_idx_r] or {}).get("name")
                                             if _idx_r < len(_tables_to_process) else "?")
                                    if _refs_known:
                                        raise RuntimeError(
                                            f"Per-table metadata worker failed for table "
                                            f"'{_dead}' — aborting the query rather than "
                                            f"returning results that could silently drop "
                                            f"its rows.")
                                    logger.warning(
                                        "aggregator: worker for '%s' failed and query "
                                        "table-refs are unknown (SQL parse failed) — "
                                        "skipping it; the COPY errors loudly iff this "
                                        "table is actually referenced.", _dead)
                                    continue
                                if not _r.get("setup_stmt"):
                                    if _r.get("files"):
                                        if _refs_known:
                                            raise RuntimeError(
                                                f"Table '{_r.get('name')}' resolved "
                                                f"{_r.get('files')} data file(s) but produced "
                                                f"no view (registration failed) — aborting "
                                                f"rather than returning silent 0 rows.")
                                        logger.warning(
                                            "aggregator: table '%s' resolved %s file(s) but "
                                            "built no view and query table-refs are unknown "
                                            "(SQL parse failed) — skipping (no silent 0-row "
                                            "substitution).", _r.get("name"), _r.get("files"))
                                        continue
                                    # Genuinely 0 files AND the empty-view builder threw
                                    # before emitting → inject a real-schema 0-row
                                    # fallback (correct 0 rows, JOIN binds).
                                    _miss = _r.get("name")
                                    if _miss:
                                        try:
                                            from core.duckdb_views import typed_empty_view_ddl as _tevd
                                            _fb_ddl = _tevd(
                                                _miss,
                                                getattr(run_engine, '_s3_conn_id', None),
                                                _db_manager)
                                        except Exception:
                                            _fb_ddl = None
                                        _mesc = str(_miss).replace('"', '""')
                                        _setup_stmts.append(
                                            _fb_ddl or f'CREATE OR REPLACE VIEW "{_mesc}" AS SELECT 1 AS dummy WHERE FALSE')
                                        _bound_view_names.add(str(_miss).lower())
                                        _files_per_table.setdefault(_miss, 0)
                                        logger.warning(
                                            "BF-507 GUARANTEE: table '%s' has 0 files and "
                                            "its empty-view builder threw — injected a "
                                            "fallback 0-row view so the COPY binds.", _miss)
                                if _r.get("setup_stmt"):
                                    _setup_stmts.append(_r["setup_stmt"])
                                    _bound_view_names.add(str(_r.get("name") or "").lower())
                                _r_files = _r.get("files", 0)
                                _files_listed_total += int(_r.get("files_listed", _r_files) or 0)
                                if _r_files > 0:
                                    _files_per_table[_r["name"]] = _r_files
                                    _files_to_scan_total += _r_files
                                else:
                                    # BF-507 — track 0-file tables in the summary
                                    # too so the operator sees them in logs.
                                    _files_per_table[_r["name"]] = 0
                                if _r.get("tmp_dir"):
                                    _bqb_predownload_tmp_dirs.append(_r["tmp_dir"])

                            # BF-423 — registry unregister now happens INSIDE
                            # _process_one_table's finally (on the meta_rd
                            # thread that registered).  The earlier BF-422
                            # attempt to unregister from the OUTER thread
                            # here only cleaned _global_temp_dirs and left
                            # the meta_rd thread's _thread_local.temp_dirs
                            # leaking unbounded.  See _process_one_table's
                            # docstring above for the full rationale.
                        # ── Create views for raw S3 file paths (not registered) ──
                        # BQB may reference raw S3 files from listConnectionFiles
                        # whose paths are bare S3 keys without __registered__: prefix.
                        for _raw_f in (query_config.files or []):
                            _raw_path = str(_raw_f)
                            if _raw_path.startswith("__"):
                                continue  # Already handled via registered tables
                            # 2026-10-02 -- a BARE registered name is not a raw
                            # S3 prefix.  A saved raw-SQL query stores the tables
                            # it reads as ``files: ["trades"]``; published as an
                            # API, that entry reached this loop, which listed the
                            # prefix ``trades`` WHOLE (no partition filter --
                            # 7,308 files on the rig, the statement's ``dt =``
                            # never consulted), presigned every object and
                            # appended a SECOND ``CREATE VIEW "trades"`` after the
                            # pruned one above.  The query could never answer:
                            # over the presigned cap the pre-download refused,
                            # under it the duplicate view was a CatalogException.
                            # The registered loop already bound this name,
                            # pruned through the same extractor /api/execute's
                            # raw SQL uses; that view IS the table.
                            _raw_view_name = os.path.basename(_raw_path.rstrip("/"))
                            if _raw_view_name.lower() in _bound_view_names:
                                _bound_files = next(
                                    (v for k, v in _files_per_table.items()
                                     if str(k).lower() == _raw_view_name.lower()), "?")
                                logger.info(
                                    "[raw-sql-files] files entry '%s' names registered "
                                    "table '%s', already bound (%s file(s) after "
                                    "pruning) -- not re-listed as a raw S3 prefix",
                                    _raw_path, _raw_view_name, _bound_files,
                                )
                                continue
                            try:
                                _raw_basename = os.path.basename(_raw_path).replace('"', '""')
                                _raw_s3_key = _raw_path.rstrip("/")
                                if not _rt_s3:
                                    _rt_s3 = make_s3_client_for_conn({"id": getattr(run_engine, '_s3_conn_id', None), "config": run_engine._s3_conn_config})
                                if _raw_path.lower().endswith(".parquet"):
                                    # Single file
                                    _raw_urls = [f"s3://{_rt_bucket}/{_raw_s3_key}"]
                                    _raw_urls = s3_urls_to_presigned(_rt_s3, _raw_urls, run_engine._s3_conn_config)
                                else:
                                    # Prefix/directory — list parquet files inside
                                    _raw_pq = list_s3_parquet_files_cached(
                                        getattr(run_engine, '_s3_conn_id', None) or 0,
                                        _rt_s3, _rt_bucket, _raw_s3_key)
                                    # 2026-08-20 — surface truncated=True
                                    # before presign drops the flag.
                                    try:
                                        from core.scan_truncation import surface_truncated_listing as _stl_raw
                                        _stl_raw(_raw_pq, table=_raw_basename,
                                                 bucket=_rt_bucket, prefix=_raw_s3_key)
                                    except Exception as _stl_raw_exc:
                                        logger.warning("listing-truncation surface failed for raw '%s': %s",
                                                       _raw_basename, _stl_raw_exc)
                                    _raw_urls = s3_urls_to_presigned(_rt_s3, _raw_pq, run_engine._s3_conn_config) if _raw_pq else []
                                if _raw_urls:
                                    _raw_paths_str = ", ".join(f"'{_esc(u)}'" for u in _raw_urls)
                                    # BF-PRUNE-PERF: raw S3 files outside registered
                                    # tables are typically uniform (single file or
                                    # one directory of same-schema parquet).  Drop
                                    # union_by_name to avoid per-file footer reads.
                                    _setup_stmts.append(f'CREATE VIEW "{_raw_basename}" AS SELECT * FROM read_parquet([{_raw_paths_str}], hive_partitioning=true)')
                                    logger.info("Raw S3 file view '%s' created for BQB raw SQL (%d file(s), no union_by_name)",
                                                _raw_basename, len(_raw_urls))
                            except Exception as _raw_err:
                                logger.warning("Failed to create view for raw S3 file '%s': %s", _raw_path, _raw_err, exc_info=True)

                        # ── Two-phase: preview + full download ──
                        # BF-PRUNE-PERF-LOG: signal stage transition BEFORE the
                        # subprocess call.  Inside run_duckdb_copy_to (subprocess
                        # COPY TO), the parent process is blocked on
                        # proc.communicate() — emit a stage so the heartbeat
                        # tells the user "still in DuckDB COPY TO, waiting
                        # on subprocess result" instead of "stage=init".
                        try:
                            from core.execution_stage import (
                                set_stage as _stg_rs3,
                                STAGE_DUCKDB_EXECUTE as _S_RS_EX,
                                add_extras as _stg_extras_3,
                            )
                            _per_table_summary = ", ".join(
                                f"{k}={v}" for k, v in _files_per_table.items()
                            ) or "n/a"
                            _stg_rs3(execution_id, _S_RS_EX,
                                      files_total=_files_to_scan_total,
                                      message=f"DuckDB subprocess COPY TO ({_files_to_scan_total} files post-prune: {_per_table_summary})")
                            try:
                                _stg_extras_3(execution_id,
                                              files_to_scan=_files_to_scan_total,
                                              files_per_table=_per_table_summary)
                            except Exception:
                                pass
                            # 2026-10-08 -- "read N of M": M is what the pruner kept,
                            # N what the views read after the LIMIT-only early stop.
                            logger.info(
                                "[execute_query_background %s] post-prune scan total: read %d of %d file(s) across %d table(s) [%s]",
                                execution_id, _files_to_scan_total, _files_listed_total,
                                len(_files_per_table), _per_table_summary,
                            )
                        except Exception:
                            pass
                        # ── BF-383 — Multi-worker dispatch (Option F) ──────
                        # Fan out across N parallel DuckDB workers when the
                        # query is splittable + file count >= threshold +
                        # multi_worker.enabled.  Returns None if not eligible
                        # → falls through to the single-worker s3_full_copy
                        # path unchanged.  Fully fail-open.
                        # Wrapped in the SAME try/finally as s3_full_copy so
                        # ``_bqb_predownload_tmp_dirs`` cleanup runs whether
                        # multi-worker or single-worker takes the path.
                        try:
                            try:
                                from core.multi_worker_dispatcher import maybe_dispatch_multi_worker
                                _mw_setup = ";\n".join(_setup_stmts)

                                def _mw_progress(done, total, msg):
                                    # BF-414 — include engine/worker_count from
                                    # the FIRST tick so the BQB chip lights up
                                    # immediately ("Multi-worker (4 workers)")
                                    # instead of only after completion.
                                    _sync_progress({
                                        "status":             "running",
                                        "stage":              "multi_worker",
                                        "message":            f"workers {done}/{total} — {msg}",
                                        "chunks_processed":   done,
                                        "total_chunks":       total,
                                        "engine":             "multi_worker",
                                        "worker_count":       int(total) if total else None,
                                        "from_multi_worker":  True,
                                    })

                                # BF-586 (2026-05-29): the dispatch runs
                                # inside ``_exec_to_parquet_body`` which
                                # is already executed in a thread-pool
                                # worker via ``_pool.submit`` (line ~3782)
                                # — so the asyncio event loop is NOT
                                # blocked here.  The hang risk is INSIDE
                                # the executor's ``as_completed`` loop
                                # which can wait forever if all workers
                                # are stuck on httpfs/boto3 socket reads.
                                # That's fixed via the outer-timeout
                                # patch in multi_worker_executor.py.
                                # SCAN-STRATEGY (2026-06-01 deep-dive fix):
                                # caller is derived from executed_by so the
                                # ScanStrategist picks the right profile:
                                #   * published_view:* → published_api
                                #     → LOW_LATENCY (cache-first, no prewarm)
                                #   * schedule:*      → report (scheduled batch)
                                #     → BULK_SCAN-friendly heuristic
                                #   * everything else → bqb (BQB/CQB inter-
                                #     active) → INTERACTIVE for LIMIT queries,
                                #     BULK_SCAN for 200+ file no-LIMIT scans.
                                # Pre-fix this was hardcoded to "bqb" — every
                                # published-API query silently got INTERACTIVE
                                # instead of LOW_LATENCY, defeating the whole
                                # point of having distinct profiles.
                                _caller_tag = (
                                    "published_api" if executed_by.startswith("published_view:")
                                    else "report"        if executed_by.startswith("schedule:")
                                    else "bqb"
                                )
                                # 2026-06-03 — API/feed/report queries must
                                # run to completion regardless of duration.
                                # Interactive BQB/CQB queries remain
                                # cancellable so the user "Cancel" button +
                                # heartbeat budget still apply.
                                _cancellable = _caller_tag not in (
                                    "published_api", "report", "feed_gen",
                                )
                                try:
                                    # Phase 156 -- thread the resolved
                                    # iceberg snapshot id into the brain
                                    # consultation so the memo + route
                                    # history sensors can key on it.
                                    # 2026-10-08 -- the ONE reader the
                                    # completion hook also uses, so the
                                    # snapshot looked up is the snapshot
                                    # stored under.
                                    _mw_brain_snap = ""
                                    try:
                                        from core.agg_cache import (
                                            brain_snapshot_from_query_config as _bsq,
                                        )
                                        _mw_brain_snap = _bsq(query_config_dict)
                                    except Exception:
                                        pass
                                    _mw_out = maybe_dispatch_multi_worker(
                                        raw_sql,
                                        _mw_setup,
                                        str(output_file),
                                        cancel_event=cancel_event,
                                        progress_cb=_mw_progress,
                                        httpfs_required=True,
                                        conn_config=getattr(run_engine, "_s3_conn_config", None),
                                        execution_id=execution_id,
                                        caller=_caller_tag,
                                        cancellable=_cancellable,
                                        iceberg_snapshot_id=_mw_brain_snap,
                                    )
                                finally:
                                    # 2026-06-03 — release the memory_guard
                                    # reservation registered inside
                                    # maybe_dispatch_multi_worker so the
                                    # next admission check sees the
                                    # accurate inflight total.  Idempotent
                                    # on execution_ids that never got
                                    # registered.
                                    try:
                                        from core.memory_guard import release_query
                                        release_query(execution_id)
                                    except Exception:
                                        pass
                                    # Clear the thread-local exec_id that
                                    # the dispatcher stamped at entry —
                                    # without this, the next call on the
                                    # same thread mis-attributes its
                                    # iceberg pruning emit to this stale
                                    # execution_id.
                                    try:
                                        from core.query_diagnostic_store import set_current_execution_id
                                        set_current_execution_id(None)
                                    except Exception:
                                        pass
                                    # Same for the thread-local scan plan
                                    # file_order so the next call on this
                                    # thread doesn't inherit this query's
                                    # ordering preference.
                                    try:
                                        from core.scan_strategy import set_current_file_order
                                        set_current_file_order(None)
                                    except Exception:
                                        pass
                                if _mw_out is not None and _mw_out.get("from_brain_cache"):
                                    # 2026-10-08 -- the dispatcher SERVED the
                                    # brain-cache hit it routed on: the parquet
                                    # is already at output_file, no data file
                                    # was read.  Attributed to the cache (the
                                    # ``result_cache`` engine key the UI
                                    # already renders as "Cache"), never to
                                    # multi-worker or single.
                                    total_rows = int(_mw_out.get("total_rows") or 0)
                                    file_size = int(_mw_out.get("file_size_bytes") or 0)
                                    logger.info(
                                        "[execute_query_background %s] brain-cache "
                                        "SERVED: %d rows, 0 data files read, "
                                        "snapshot=%s age=%.1fs",
                                        execution_id, total_rows,
                                        _mw_out.get("snapshot_id"),
                                        float(_mw_out.get("cache_age_seconds") or 0.0),
                                    )
                                    _sync_progress({
                                        "status":          "completed",
                                        "total_rows":      total_rows,
                                        "file_size_bytes": file_size,
                                        "from_cache":      True,
                                        "engine":          "result_cache",
                                        "cache":           "brain_sql_hash",
                                    })
                                    return {
                                        "total_rows":       total_rows,
                                        "file_size_bytes":  file_size,
                                        "status":           "completed",
                                        "from_cache":       True,
                                        "from_brain_cache": True,
                                        "engine_meta": {
                                            "engine":            "result_cache",
                                            "from_cache":        True,
                                            "cache":             "brain_sql_hash",
                                            "cache_age_seconds": _mw_out.get("cache_age_seconds"),
                                            "snapshot_id":       _mw_out.get("snapshot_id"),
                                            "elapsed_s":         _mw_out.get("elapsed_s"),
                                        },
                                    }
                                if _mw_out is not None:
                                    total_rows = _mw_out["total_rows"]
                                    file_size = _mw_out["file_size_bytes"]
                                    logger.info(
                                        "[execute_query_background %s] multi-worker "
                                        "success: %d rows, %d workers, %.1fs, merge=%s",
                                        execution_id, total_rows,
                                        _mw_out.get("worker_count", 0),
                                        _mw_out.get("elapsed_s", 0),
                                        _mw_out.get("merge_strategy", "?"),
                                    )
                                    _sync_progress({
                                        "status":            "completed",
                                        "total_rows":        total_rows,
                                        "file_size_bytes":   file_size,
                                        "from_multi_worker": True,
                                        "worker_count":      _mw_out.get("worker_count"),
                                        # 2026-07-16: surface files scanned so
                                        # the UI shows "N files across K workers"
                                        # (previously only workers were shown).
                                        "files_total":       _mw_out.get("files_total"),
                                        "merge_strategy":    _mw_out.get("merge_strategy"),
                                    })
                                    return {
                                        "total_rows":        total_rows,
                                        "file_size_bytes":   file_size,
                                        "status":            "completed",
                                        "from_multi_worker": True,
                                        # Surface in stats so the outer DB
                                        # update can persist engine info →
                                        # status endpoint → polling → badge
                                        "engine_meta": {
                                            "engine":        "multi_worker",
                                            "worker_count":  _mw_out.get("worker_count"),
                                            "files_total":   _mw_out.get("files_total"),
                                            "merge_strategy": _mw_out.get("merge_strategy"),
                                            "elapsed_s":     _mw_out.get("elapsed_s"),
                                        },
                                    }
                            except Exception as _mw_err:
                                logger.warning(
                                    "[execute_query_background %s] multi-worker hook "
                                    "raised (%s) — falling back to single-worker",
                                    execution_id, _mw_err, exc_info=True,
                                )

                            # BF-417 (Phase 143-A) — big × big JOIN auto-fallback to Spark Connect.
                            # When the multi-worker dispatcher refused with reason "multiple big
                            # tables" (or similar big × big JOIN signal) AND Spark Connect is
                            # enabled, route the query to Spark INSTEAD of falling to slow
                            # single-worker DuckDB.  This is the case where 2000+ file JOIN
                            # queries would otherwise serial-scan via httpfs for 500s+.
                            #
                            # Read the last engine-router decision to see if broadcast-JOIN
                            # refused because of "big × big".  Defensive: if anything goes wrong
                            # in this detection, fall through to single-worker as before.
                            _spark_fallback_taken = False
                            try:
                                from core.engine_router import get_decision_history
                                # BF-417 (extended + deep-dive hardened) — auto-fallback
                                # to Spark Connect when the in-pod dispatcher gave up on a
                                # JOIN query owned by THIS execution.  Three cases trigger
                                # when Spark is enabled + reachable + it's an S3 connection:
                                #
                                #   (a) broadcast-JOIN refused big × big
                                #   (b) JOIN query but broadcast-JOIN disabled / not attempted
                                #   (c) partition-aligned refused (data not co-partitioned)
                                #
                                # Deep-dive fix: filter history entries to THIS execution_id
                                # so concurrent queries don't see each other's skip events
                                # and incorrectly route themselves to Spark.
                                # Also: skip the fallback for cross-source queries —
                                # _execute_via_spark_connect can't handle them.
                                _is_cross_source = bool(
                                    (query_config_dict or {}).get("cross_connection_id")
                                )
                                # Deep-dive round 3: under heavy concurrent
                                # load, our skip could be displaced past the
                                # first 20 entries.  Engine router deque
                                # has maxlen=200, so 100 is a safe upper
                                # bound that still scans in microseconds.
                                _recent = get_decision_history(limit=100)
                                _should_route_to_spark = False
                                _route_reason = ""
                                _has_join = bool(raw_sql and __import__("re").search(
                                    r"\bJOIN\b", raw_sql or "", __import__("re").IGNORECASE,
                                ))
                                if _is_cross_source:
                                    pass  # cross-source can't go through _execute_via_spark_connect
                                else:
                                    for _r in _recent or []:
                                        # Filter to THIS execution to avoid cross-query pollution
                                        if (_r.get("execution_id") or "") != execution_id:
                                            continue
                                        _rule = (_r.get("rule") or "").lower()
                                        _reason = (_r.get("reason") or "").lower()
                                        # Case (a): broadcast-JOIN big × big
                                        if "broadcast_join" in _rule and "skip" in _rule:
                                            if "multiple big" in _reason or (
                                                "big" in _reason and ("multiple" in _reason or "more than one" in _reason)
                                            ):
                                                _should_route_to_spark = True
                                                _route_reason = "broadcast-JOIN refused big × big"
                                                break
                                        # Case (b): JOIN query, dispatcher refused for any reason
                                        if _has_join and "dispatcher_skip" in _rule and (
                                            "join" in _reason or "create view" in _reason or "splittable" in _reason
                                        ):
                                            _should_route_to_spark = True
                                            _route_reason = f"dispatcher refused JOIN query: {_r.get('reason','')[:140]}"
                                            break
                                        # Case (c): partition-aligned refused
                                        if "partition_aligned_skip" in _rule and _has_join:
                                            _should_route_to_spark = True
                                            _route_reason = f"partition-aligned refused: {_r.get('reason','')[:140]}"
                                            break
                                if _should_route_to_spark:
                                    from core.config import spark_connect as _sc_cfg
                                    if _sc_cfg.enabled:
                                        _conn_cfg = getattr(run_engine, "_s3_conn_config", None) or {}
                                        _is_s3 = bool(_conn_cfg.get("bucket") or _conn_cfg.get("bucket_name"))
                                        _breaker_open = False
                                        try:
                                            _breaker_open = _get_spark_breaker().is_open
                                        except Exception as _bk_err:
                                            logger.debug("[BF-417] spark breaker probe failed: %s", _bk_err)
                                            _breaker_open = False
                                        if _is_s3 and not _breaker_open:
                                            logger.info(
                                                "[execute_query_background %s] BF-417 JOIN "
                                                "auto-fallback to Spark Connect — %s",
                                                execution_id, _route_reason,
                                            )
                                            try:
                                                _sync_progress({
                                                    "status":       "running",
                                                    "stage":        "spark_connect_auto_fallback",
                                                    "engine":       "spark_connect",
                                                    "fallback_reason": "big_x_big_join",
                                                })
                                            except Exception as _pg_err:
                                                logger.debug("[BF-417] progress ping failed: %s", _pg_err)
                                            # Record router decision so admin UI shows the fallback.
                                            try:
                                                from core.engine_router import EngineDecision, record_decision
                                                record_decision(EngineDecision(
                                                    engine="spark_connect",
                                                    reason=f"BF-417 auto-fallback: {_route_reason}",
                                                    rule="join_spark_fallback",
                                                ), execution_id=execution_id)
                                            except Exception as _rec_err:
                                                logger.debug("[BF-417] record_decision failed: %s", _rec_err)
                                            try:
                                                # _exec_to_parquet runs in a threadpool; bridge to
                                                # the async Spark executor via run_coroutine_threadsafe.
                                                _sc_fut = asyncio.run_coroutine_threadsafe(
                                                    _execute_via_spark_connect(
                                                        execution_id=execution_id,
                                                        query_config=query_config,
                                                        conn_config=_conn_cfg,
                                                        output_file=output_file,
                                                        executed_by=executed_by,
                                                        raw_sql=raw_sql,
                                                        progress_callback=progress_callback,
                                                    ),
                                                    loop,
                                                )
                                                _sc_metrics = _sc_fut.result()
                                                _spark_fallback_taken = True
                                                total_rows = _sc_metrics.get("total_rows", 0)
                                                file_size = _sc_metrics.get("file_size_bytes", 0) or 0
                                                _sync_progress({
                                                    "status":      "completed",
                                                    "total_rows":  total_rows,
                                                    "file_size_bytes": file_size,
                                                    "engine":      "spark_connect",
                                                    "from_spark_connect": True,
                                                })
                                                return {
                                                    "total_rows":  total_rows,
                                                    "file_size_bytes": file_size,
                                                    "status":      "completed",
                                                    "from_spark_connect": True,
                                                    "engine_meta": {
                                                        "engine":       "spark_connect",
                                                        "via":          "bigxbig_auto_fallback",
                                                        "elapsed_s":    _sc_metrics.get("elapsed_seconds"),
                                                    },
                                                }
                                            except Exception as _spark_fb_err:
                                                logger.warning(
                                                    "[execute_query_background %s] BF-417 Spark "
                                                    "auto-fallback failed (%s) — continuing to single-worker",
                                                    execution_id, _spark_fb_err, exc_info=True,
                                                )
                                                try:
                                                    _get_spark_breaker().record_failure()
                                                except Exception as _br_err:
                                                    logger.debug("[BF-417] breaker.record_failure failed: %s", _br_err)
                            except Exception as _detect_err:
                                logger.debug(
                                    "[execute_query_background] BF-417 big-big detection failed (non-fatal): %s",
                                    _detect_err,
                                )

                            # BF-414 — emit engine='single' so the BQB chip
                            # renders "🔂 Single worker" immediately on the
                            # fallback path (was previously silent until end).
                            try:
                                _sync_progress({
                                    "status":       "running",
                                    "stage":        "single_worker",
                                    "engine":       "single",
                                    "worker_count": 1,
                                })
                            except Exception:
                                logger.debug("[execute_query_background] single-worker engine ping failed", exc_info=True)

                            _tp_result = s3_full_copy(
                                inner_sql=raw_sql,
                                output_path=str(output_file),
                                row_bound=row_bound,
                                # 2026-10-06 -- the statement as WRITTEN: its
                                # ORDER BY / LIMIT / OFFSET are its answer.
                                # (Stripping them here returned a 201,600-row
                                # island for `... limit 3 offset 150000`.)
                                generated_sql=False,
                                conn_config=run_engine._s3_conn_config,
                                registered_tables=run_engine._registered_tables or [],
                                bucket=run_engine._s3_bucket or "",
                                setup_sql=";\n".join(_setup_stmts),
                                connection_id=getattr(run_engine, '_s3_conn_id', None),
                                progress_fn=_sync_progress,
                                timeout=_qe_cfg.query_timeout_seconds if _qe_cfg else 1800,
                                execution_id=execution_id,
                                cancel_event=cancel_event,
                            )
                            total_rows = _tp_result["total_rows"]
                            file_size = _tp_result["file_size_bytes"]
                            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                            return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                        finally:
                            # Cleanup per-query temp dirs from boto3 pre-download
                            # (cache mode returns _tmp_dir=None; nothing to clean
                            # for those — handled by the cache eviction job).
                            # Runs whether multi-worker or single-worker took
                            # the path (BF-383 deep-dive fix).
                            if _bqb_predownload_tmp_dirs:
                                import shutil as _sh
                                for _tdp in _bqb_predownload_tmp_dirs:
                                    try:
                                        _sh.rmtree(_tdp, ignore_errors=True)
                                    except Exception as _cleanup_err:
                                        logger.debug("temp dir cleanup failed: %s", _cleanup_err)
                    else:
                        # ── Raw SQL + local connection: create views for file paths ──
                        import duckdb as _ddb_raw_local
                        _raw_local_con = _ddb_raw_local.connect()
                        try:
                            _bp = str(run_engine.base_path)
                            # Register local table views (uploaded parquet)
                            if _db_manager:
                                _lt_storage_dir = None
                                try:
                                    # 2026-08-19 -- same nonexistent
                                    # get_config(); swallowed here, so the
                                    # storage dir silently stayed None and
                                    # local-table views were NEVER registered
                                    # on the raw-duckdb path.
                                    from core.config import local_tables as _lt_cfg_rl
                                    _lt_storage_dir = getattr(_lt_cfg_rl, 'storage_dir', None)
                                except Exception:
                                    pass
                                if _lt_storage_dir:
                                    import glob as _glob_rl
                                    # Sync DB call — already on thread-pool worker.
                                    _lt_rows_rl = _db_manager.list_local_tables()
                                    for _lt in _lt_rows_rl:
                                        if _lt["status"] != "ready" or not _lt.get("is_active", True):
                                            continue
                                        _lt_dir = os.path.join(_lt_storage_dir, str(_lt["id"]))
                                        _lt_pqs = _glob_rl.glob(os.path.join(_lt_dir, "*.parquet"))
                                        if _lt_pqs:
                                            from core.path_utils import to_duckdb_path as _to_ddb_lt
                                            _lt_ps = ", ".join(f"'{_to_ddb_lt(p)}'" for p in _lt_pqs)
                                            _lt_vn = f"__lt__{_lt['name']}".replace('"', '""')
                                            _raw_local_con.execute(f'CREATE OR REPLACE VIEW "{_lt_vn}" AS SELECT * FROM read_parquet([{_lt_ps}], hive_partitioning=true)')
                            # Register views for raw file paths from query_config.files
                            _registered_view_names: set = set()
                            for _raw_f in (query_config.files or []):
                                _raw_path = str(_raw_f)
                                if _raw_path.startswith("__"):
                                    continue
                                _raw_bn = os.path.basename(_raw_path).replace('"', '""')
                                _full_path = os.path.join(_bp, _raw_path).replace("\\", "/")
                                if os.path.isfile(_full_path):
                                    _raw_local_con.execute(f'CREATE OR REPLACE VIEW "{_raw_bn}" AS SELECT * FROM read_parquet(\'{_full_path}\', hive_partitioning=true)')
                                    _registered_view_names.add(_raw_bn.lower())
                                    logger.info("Local file view '%s' created for BQB raw SQL (path: %s)", _raw_bn, _full_path)
                                elif os.path.isdir(_full_path):
                                    _raw_local_con.execute(f'CREATE OR REPLACE VIEW "{_raw_bn}" AS SELECT * FROM read_parquet(\'{_full_path}/**/*.parquet\', hive_partitioning=true)')
                                    _registered_view_names.add(_raw_bn.lower())
                                    logger.info("Local dir view '%s' created for BQB raw SQL (path: %s)", _raw_bn, _full_path)
                                else:
                                    # Try as absolute path
                                    _abs = _raw_path.replace("\\", "/")
                                    if os.path.exists(_abs):
                                        _raw_local_con.execute(f'CREATE OR REPLACE VIEW "{_raw_bn}" AS SELECT * FROM read_parquet(\'{_abs}\', hive_partitioning=true)')
                                        _registered_view_names.add(_raw_bn.lower())
                                        logger.info("Local file view '%s' created from absolute path for BQB raw SQL", _raw_bn)

                            # BF-244: Auto-discover file references in raw_sql when
                            # query_config.files is empty (CQB user pastes raw SQL
                            # without selecting tables in sidebar).  Parse the SQL,
                            # find FROM-clause table-like names, scan the local
                            # parquet dir for matching files, register views.
                            if raw_sql:
                                try:
                                    import sqlglot as _sqlglot_disc
                                    from sqlglot import exp as _sqlglot_exp
                                    _parsed_disc = _sqlglot_disc.parse_one(raw_sql, read="duckdb")
                                    _candidate_names: set = set()
                                    for _t in _parsed_disc.find_all(_sqlglot_exp.Table):
                                        _name = (_t.name or "").strip('"')
                                        if _name and _name.lower() not in _registered_view_names:
                                            _candidate_names.add(_name)
                                    for _cn in _candidate_names:
                                        _safe_cn = _cn.replace('"', '""')
                                        # Try the bare name first, then with .parquet appended
                                        for _candidate_path in (
                                            os.path.join(_bp, _cn),
                                            os.path.join(_bp, _cn + ".parquet") if not _cn.endswith(".parquet") else None,
                                        ):
                                            if _candidate_path and os.path.isfile(_candidate_path):
                                                _full_path_disc = _candidate_path.replace("\\", "/")
                                                _raw_local_con.execute(
                                                    f'CREATE OR REPLACE VIEW "{_safe_cn}" AS '
                                                    f'SELECT * FROM read_parquet(\'{_full_path_disc}\', hive_partitioning=true)'
                                                )
                                                logger.info("Auto-discovered local view '%s' for raw SQL (path: %s)",
                                                            _safe_cn, _full_path_disc)
                                                _registered_view_names.add(_cn.lower())
                                                break
                                except Exception as _disc_exc:
                                    logger.debug("Raw SQL auto-discovery skipped (fail-open): %s", _disc_exc)

                            import pyarrow as _pa_raw_local
                            def _raw_sql_gen_local_files():
                                try:
                                    _sync_progress({"status": "processing", "log": "Executing raw SQL on local files..."})
                                    _t0 = _time.monotonic()
                                    res = _raw_local_con.execute(raw_sql)
                                    rdr = res.to_arrow_reader(batch_size=run_engine.chunk_size)
                                    tot = 0
                                    for b in rdr:
                                        if len(b) == 0:
                                            continue
                                        tot += len(b)
                                        _sync_progress({"status": "processing",
                                                        "log": f"Streaming: {tot:,} rows [{_time.monotonic()-_t0:.1f}s]"})
                                        yield _pa_raw_local.Table.from_batches([b])
                                    _sync_progress({"status": "processing",
                                                    "log": f"Query returned {tot:,} rows [{_time.monotonic()-_t0:.1f}s]"})
                                finally:
                                    _raw_local_con.close()
                            _query_gen = _raw_sql_gen_local_files()
                        except Exception:
                            _raw_local_con.close()
                            raise
                elif run_engine._s3_conn_config:
                    # ── S3 non-registered files: two-phase (preview + full) ──
                    fh.close()  # close file handle — subprocess writes directly
                    _s3_sql = run_engine.get_duckdb_sql(query_config)
                    # 2026-09-26 (F2) -- raw ``s3://`` files read the
                    # CONNECTION'S endpoint.  Until now this branch shipped
                    # ``read_parquet('s3://…')`` inside copy_sql with an empty
                    # setup_sql.  On a path-style (MinIO) connection the
                    # access mode is PRESIGNED, so the child takes the
                    # LOCAL_FILES plan -- no endpoint, no credentials, on the
                    # promise that the parent presigned every URL -- and the
                    # unsigned s3:// went to DuckDB's DEFAULT host: real AWS,
                    # 403 after 30 s, and the connection's breaker tripped for
                    # everyone.  The registered and raw-SQL branches never
                    # had the bug because they emit VIEWS in setup_sql, the
                    # one text every child fallback rewrites.  Same shape
                    # now: the ONE resolver (core.s3_access) decides presign
                    # vs native, a prefix is listed through the product's own
                    # listing (its refusal passes through), and the reads
                    # become views.  An AWS connection is unchanged: native
                    # mode keeps the s3:// URLs and the child SETs the endpoint.
                    _s3_setup_sql = ""
                    _s3_raw_urls = []
                    for _f in list(query_config.files or []) + [
                            j.right_file for j in (query_config.joins or [])]:
                        for _one in (_f if isinstance(_f, list) else [_f]):
                            _p = run_engine._resolve_to_posix(_one)
                            if isinstance(_p, str) and _p.lower().startswith("s3://") \
                                    and _p not in _s3_raw_urls:
                                _s3_raw_urls.append(_p)
                    if _s3_raw_urls:
                        from core.s3_access import (
                            resolve_s3_access, prepare_s3_reads, s3_reads_as_views,
                        )
                        _s3_cid = getattr(run_engine, '_s3_conn_id', None)
                        _s3_access = resolve_s3_access(
                            run_engine._s3_conn_config, connection_id=_s3_cid,
                            proxy=False)
                        _s3_client = make_s3_client_for_conn(
                            {"id": _s3_cid, "config": run_engine._s3_conn_config})
                        _s3_prepared = prepare_s3_reads(
                            _s3_access, _s3_client, _s3_raw_urls,
                            lister=lambda _b, _k: list_s3_parquet_files_cached(
                                _s3_cid or 0, _s3_client, _b, _k),
                            conn_config=run_engine._s3_conn_config)
                        _s3_sql, _s3_views = s3_reads_as_views(_s3_sql, _s3_prepared)
                        _s3_setup_sql = ";\n".join(_s3_views)
                        logger.info(
                            "[s3-access] generic branch: %d raw s3:// ref(s) -> "
                            "%d view(s) (%s)", len(_s3_raw_urls), len(_s3_views),
                            _s3_access.reason)
                    _tp_result = s3_full_copy(
                        inner_sql=_s3_sql,
                        output_path=str(output_file),
                        row_bound=row_bound,
                        # 2026-10-06 -- get_duckdb_sql(query_config): SQL the
                        # product GENERATED, so its trailing LIMIT is the query
                        # builder's cap (stripped, owner's decision; OFFSET
                        # kept).  The raw-SQL call above passes a statement a
                        # person wrote and keeps the default: copied verbatim.
                        generated_sql=True,
                        conn_config=run_engine._s3_conn_config,
                        registered_tables=[],
                        bucket=getattr(run_engine, '_s3_bucket', "") or "",
                        setup_sql=_s3_setup_sql,
                        connection_id=getattr(run_engine, '_s3_conn_id', None),
                        progress_fn=_sync_progress,
                        timeout=_qe_cfg.query_timeout_seconds if _qe_cfg else 1800,
                        # Progressive COPY delivery arms ONLY when the
                        # execution_id reaches plan_copy_rewrite (it keys the
                        # spool dir on `<execution_id>__segments`).  Without
                        # this the raw-SQL path (above) streamed early pages
                        # while this structured path silently could not.
                        execution_id=execution_id,
                        # 2026-08-03 (defect fix) — cancel_event was missing
                        # here (the raw-SQL sibling call above passes it), so
                        # Cancel could not kill the subprocess on this
                        # structured S3 path — the query kept burning CPU and
                        # memory after the user cancelled.
                        cancel_event=cancel_event,
                    )
                    total_rows = _tp_result["total_rows"]
                    file_size = _tp_result["file_size_bytes"]
                    _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
                    return {"total_rows": total_rows, "file_size_bytes": file_size, "status": "completed"}
                elif run_engine._needs_duckdb(query_config):
                    _query_gen = run_engine.execute_duckdb_query(query_config)
                else:
                    _query_gen = run_engine.execute_query(query_config)
                # Detect wide-table auto-projection: when engine projected a
                # subset of columns, store the full list so the grid can offer
                # "Showing 50 of 937 columns — choose columns" UX.
                _all_source_cols = None
                if (not query_config.columns
                        and not query_config.aggregations
                        and query_config.files):
                    try:
                        _first = query_config.files[0]
                        _fp = _first if isinstance(_first, str) else _first.path
                        if not _fp.startswith("__registered__:") and hasattr(run_engine, 'get_file_schema'):
                            _sch = run_engine.get_file_schema(_fp)
                            _src_cols = [c["name"] for c in _sch.get("columns", [])]
                            if len(_src_cols) > 50:
                                _all_source_cols = _src_cols
                    except Exception as exc:
                        logger.warning("Recoverable error: %s", exc, exc_info=True)

                # Progressive delivery (2026-07-31): flag-gated segmented
                # spool tee — sealed parquet segments + manifest alongside
                # the (unchanged) canonical single-file writer so
                # /api/executions/{id}/results can serve pages while the
                # query is still running.  Flag OFF (the default) → one
                # config read, _prog_tee stays None, zero behaviour change.
                # See core/progressive_results.py for the full design.
                try:
                    from core.progressive_results import maybe_create_tee as _prog_mk
                    # Pass the plan shape and result width so the tee can
                    # be SMART rather than unconditional: skip the duplicate
                    # write entirely for a blocking plan (ORDER BY / GROUP BY
                    # cannot emit before completion), and size segment #1 by
                    # BYTES so a wide result is not the slowest to show page 1.
                    _prog_sql = None
                    _prog_ncols = None
                    try:
                        _prog_sql = getattr(query_config, "sql", None) or getattr(
                            query_config, "query", None)
                        _pc = getattr(query_config, "columns", None)
                        if _pc:
                            _prog_ncols = len(_pc)
                    except Exception as _prog_shape_exc:
                        logger.debug(
                            "progressive: plan-shape lookup failed, tee stays "
                            "unconditional: %s", _prog_shape_exc)
                    _prog_tee = _prog_mk(execution_id, output_file,
                                         sql=_prog_sql, n_columns=_prog_ncols)
                except Exception:
                    _prog_tee = None

                _bound_reached = False
                for chunk in _query_gen:
                    if cancel_event.is_set():
                        raise InterruptedError("Execution cancelled by user")
                    # Accept both pa.Table (from DuckDB streaming) and pd.DataFrame
                    if isinstance(chunk, _pa.Table):
                        table = chunk
                    else:
                        table = _pa.Table.from_pandas(chunk, preserve_index=False)
                    table = _widen_decimal_columns(table)
                    # 2026-09-15 -- the caller's DECLARED row bound.  The
                    # raw-SQL generators stream the statement verbatim, so
                    # this is the only place their output is bounded; the
                    # structured generators already carry LIMIT and pass
                    # through untouched.  Trim the chunk that crosses the
                    # bound, stop pulling after it (the DuckDB reader is
                    # closed below, which ends the scan).
                    if row_bound is not None and int(row_bound) > 0:
                        _room = int(row_bound) - total_rows
                        if _room <= 0:
                            _bound_reached = True
                            break
                        if len(table) > _room:
                            table = table.slice(0, _room)
                    if pq_writer is None:
                        _sync_progress({"status": "processing", "log": f"Writing results ({len(table)} rows)..."})
                        # Embed all_columns metadata in Parquet file so the
                        # paginator can return it without extra lookups.
                        _pq_meta = table.schema.metadata or {}
                        if _all_source_cols is not None:
                            _pq_meta[b"all_columns"] = json.dumps(_all_source_cols).encode()
                        # Embed auto-partition info so frontend can show indicator
                        _auto_part = getattr(query_config, '_auto_partition', None)
                        if _auto_part:
                            _pq_meta[b"auto_partition"] = json.dumps(_auto_part).encode()
                        # Use replace_schema_metadata on the table itself so
                        # writer schema and table schema are identical.
                        table = table.replace_schema_metadata(_pq_meta)
                        _writer_schema = table.schema
                        # BF-274: micro-partition writer — explicit row-group +
                        # page sizes + dictionary so the footer carries fine-
                        # grained min/max stats for skip-on-read.
                        from core.parquet_write_opts import default_writer as _pw_default
                        pq_writer = _pw_default(fh, _writer_schema)
                    else:
                        # Subsequent chunks may have a different schema (e.g.
                        # multi-file streaming with schema evolution).  Cast
                        # to the writer's schema so the write doesn't fail.
                        if table.schema != _writer_schema:
                            try:
                                table = table.cast(_writer_schema)
                            except Exception:
                                # If cast fails, unify: add missing cols as null,
                                # drop extra cols, reorder to match writer.
                                for field in _writer_schema:
                                    if field.name not in table.column_names:
                                        table = table.append_column(
                                            field, _pa.nulls(len(table), type=field.type))
                                table = table.select([f.name for f in _writer_schema])
                    # BF-274: per-write row_group_size — pyarrow takes this on
                    # write_table(), not on the writer constructor.  Picks up
                    # parquet_writer.target_rows_per_row_group from config.
                    from core.parquet_write_opts import get_target_rows as _pw_rows
                    _rg = _pw_rows()
                    if _rg and _rg > 0:
                        pq_writer.write_table(table, row_group_size=_rg)
                    else:
                        pq_writer.write_table(table)
                    total_rows += len(table)
                    chunks_processed += 1
                    # Progressive delivery: tee the SAME cast table the
                    # canonical writer just wrote.  write() is fail-open —
                    # a tee error disarms it and never touches this loop.
                    if _prog_tee is not None:
                        _prog_tee.write(table)
                    # Phase 139 (Tier 2.1): incremental row streaming via WS
                    _emit_stream_chunk(table)
                    if (row_bound is not None and int(row_bound) > 0
                            and total_rows >= int(row_bound)):
                        _bound_reached = True
                        break
                if _bound_reached:
                    # Close the generator NOW so its finally-blocks run (the
                    # DuckDB connection / interrupt watchdog) instead of at
                    # garbage collection -- ``break`` alone leaves a live
                    # cursor holding the scan open.
                    _gen_close = getattr(_query_gen, "close", None)
                    if callable(_gen_close):
                        _gen_close()
            finally:
                # Progressive delivery: the spool is transient — on ANY exit
                # (completed / failed / cancelled) remove it.  Completed
                # executions serve the canonical parquet; failed/cancelled
                # ones serve the BF-238 sentinel, so 6 sealed segments of a
                # query that died at segment 7 can never present as a
                # complete result.  Never raises.
                if _prog_tee is not None:
                    _prog_tee.close_and_cleanup()
                if pq_writer is not None:
                    pq_writer.close()
                fh.close()
                # 78H: Write valid empty parquet for 0-row results (touch() produces
                # an unreadable 0-byte file that breaks downstream parquet readers).
                if total_rows == 0 and not output_file.exists():
                    _empty_schema = _writer_schema if '_writer_schema' in dir() and _writer_schema is not None else _pa.schema([])
                    _pq.write_table(
                        _pa.table({f.name: _pa.array([], type=f.type) for f in _empty_schema}, schema=_empty_schema),
                        output_file, compression="zstd"
                    )
            file_size = output_file.stat().st_size
            _sync_progress({"status": "completed", "total_rows": total_rows, "file_size_bytes": file_size})
            # Collect file_stats from query_config (set by setup_registered_views)
            # or from COPY TO result (returned by execute_registered_table_copy_to)
            _fs = getattr(query_config, '_file_stats', None)
            return {"total_rows": total_rows, "chunks_processed": chunks_processed,
                    "file_size_bytes": file_size, "status": "completed",
                    "file_stats": _fs}

        try:
            _wp_record = await _pool.submit(
                _work_type, _exec_to_parquet,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            await adb(_db_manager.update_execution, execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast_to_user(executed_by, {
                "type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            return

        await adb(_db_manager.update_execution, execution_id, status="processing")
        await _ws_manager.broadcast_to_user(executed_by, {
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        # BF-250: heartbeat broadcasts elapsed time every 15 s during the
        # blocking engine call so silent COUNT(DISTINCT) / large scans don't
        # leave the user staring at an unchanging spinner.
        stats = await _await_with_heartbeat(
            _wp_record.future,
            execution_id=execution_id,
            executed_by=executed_by,
            ws_manager=_ws_manager,
        )

        _file_stats_data = stats.get("file_stats")
        # BF-100: Sanitize stats before JSON serialization — DuckDB can return
        # NaN/Infinity floats which are not JSON-compliant and cause ValueError.
        stats = _sanitize_for_json(stats)
        _file_stats_data = _sanitize_for_json(_file_stats_data)

        # BF-389: persist multi-worker / cache engine info into
        # files_metadata so the polling-fallback status endpoint can surface
        # it.  Without this, the chip only shows when WS delivered the
        # original execution_progress event — drops on WS pruning, etc.
        _engine_meta = stats.get("engine_meta")
        if _engine_meta or stats.get("from_multi_worker") or stats.get("from_cache"):
            _fm_dict: dict
            if isinstance(_file_stats_data, dict):
                _fm_dict = dict(_file_stats_data)
            else:
                _fm_dict = {}
            _fm_dict["__engine_meta__"] = _engine_meta or {
                "engine":           "multi_worker" if stats.get("from_multi_worker") else (
                                     "result_cache" if stats.get("from_cache") else "single"),
                "from_multi_worker": bool(stats.get("from_multi_worker")),
                "from_cache":        bool(stats.get("from_cache")),
            }
            _file_stats_data = _fm_dict

        # 2026-09-27 -- WHICH ENGINE ANSWERED, persisted and broadcast
        # together (core/engine_attribution.py).  The key was already
        # decided for __engine_meta__ above; this is the same decision,
        # read once and written to the row so the Executions page and the
        # grid chip agree with the toast.
        _engine_key = _engine_key_for_completion(stats)
        await adb(_db_manager.update_execution,
            execution_id,
            status="completed",
            engine=_engine_key,
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
            # BF-396: sanitise NaN/Inf/datetime/Decimal before json.dumps so
            # the column stats can't poison the row that the frontend later
            # reads back via /api/executions/{id} (browser JSON.parse() rejects
            # bare NaN literals).
            files_metadata=json.dumps(_sanitize_for_json(_file_stats_data)) if _file_stats_data else None,
        )

        # ── BF-382 — Result Cache write-through ────────────────────────────
        # Best-effort: cache the successful parquet result keyed by
        # (sql + params + file fingerprint).  Skips when:
        #   * result_cache.enabled = false
        #   * SQL contains NOW()/RANDOM/etc (non-deterministic)
        #   * Result size > result_cache.max_result_mb
        try:
            # Symmetry with the lookup hook above — skip writing when
            # query_config.files is empty.  Without an explicit file list,
            # the snapshot fingerprint collapses across data states and a
            # later lookup couldn't safely return the stored entry.
            # 2026-10-07 -- the SAME snapshot-carrying list the lookup used.
            _rc_files_w = list(_rc_key_files or [])
            if raw_sql and _rc_files_w and output_file.exists():
                from core.query_cache_integration import maybe_store_in_cache as _rc_store
                from core.config import get_section as _cfg_section_w
                _rc_section_w = _cfg_section_w("result_cache") or {}
                # Column count: read from the actual output parquet — the
                # per-table _file_stats_data is keyed by table NAME, not a
                # global column count.  pq.read_metadata is cheap (footer only).
                _rc_col_count = 0
                try:
                    import pyarrow.parquet as _pq_meta
                    _rc_col_count = int(_pq_meta.read_metadata(str(output_file)).num_columns)
                except Exception as _meta_err:
                    logger.debug("[result-cache] column count probe failed: %s", _meta_err)
                # BF-401: rc.put() does shutil.copyfile — wrap in to_thread
                # so the loop doesn't block on large result writes.
                await asyncio.to_thread(
                    _rc_store,
                    raw_sql,
                    dict(getattr(query_config, "params", {}) or {}),
                    _rc_files_w,
                    str(output_file),
                    int(stats.get("total_rows", 0) or 0),
                    _rc_col_count,
                    skip_patterns=list(_rc_section_w.get("skip_patterns") or []),
                    username=executed_by,
                    row_limit=row_bound,
                    # Phase 150 — Output Gateway: when post-prune file
                    # count exceeds the threshold, the consolidated
                    # parquet is uploaded to S3 instead of being copied
                    # into per-pod local L2.
                    files_after_prune=len(query_config.files or []),
                    db_manager=_db_manager,
                )
        except Exception as _rc_w_err:
            logger.debug("[result-cache] write hook skipped: %s", _rc_w_err)

        # ── Phase 155/156 brain completion hooks (shared chokepoint) ──
        # Hooks 3 + 4 + 7 via the module-level helper so every execute
        # background path (regular / SQL-connector / cross-source)
        # routes through the same fail-OPEN code.  Hook 6 (memo populate)
        # is already iceberg_reader-owned at the prune-output site.
        _phase156_completion_hooks(
            raw_sql=raw_sql,
            query_config_dict=query_config_dict,
            output_file_path=str(output_file) if output_file.exists() else None,
            stats=stats,
            query_t0_monotonic=_phase156_query_t0,
            db_manager=_db_manager,
            # 2026-08-20 -- principal scope for the brain result cache.
            username=executed_by,
        )

        file_id = str(uuid.uuid4())
        await adb(_db_manager.create_download_file,
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=_download_expires_at()
        )

        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, _s3_config)
            if _s3_info:
                await adb(_db_manager.update_execution, execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc, exc_info=True)

        if query_id:
            await adb(_db_manager.increment_execution_count, query_id)

        # ── Phase 52: capture lineage snapshot after successful execution ──
        try:
            from core.sql_lineage_parser import capture_execution_lineage_snapshot
            _qt = query_config.query_type if hasattr(query_config, "query_type") else "parquet_query"
            _conn_id = getattr(query_config, "connection_id", None)
            capture_execution_lineage_snapshot(
                db_manager=_db_manager,
                execution_id=execution_id,
                query_type=_qt,
                query_id=query_id or 0,
                connection_id=_conn_id,
            )
        except Exception as _snap_exc:
            logger.debug("Lineage snapshot capture skipped: %s", _snap_exc)

        # ── Phase 134: Performance audit logging ──────────────────────────
        try:
            from core.config import s3 as _s3_perf
            if _s3_perf.perf_audit_enabled and _file_stats_data:
                _total_listed = sum(v.get("total", 0) for v in _file_stats_data.values())
                _total_after_part = sum(v.get("after_pruning", 0) for v in _file_stats_data.values())
                _total_after_footer = sum(v.get("after_footer_pruning", v.get("after_pruning", 0)) for v in _file_stats_data.values())
                _conn_id_perf = getattr(query_config, "connection_id", None)
                _perf_log = {
                    "execution_id": execution_id,
                    "username": executed_by,
                    "connection_id": _conn_id_perf,
                    "tables": list(_file_stats_data.keys()),
                    "duration_ms": int(stats.get("duration_ms", 0)) if stats.get("duration_ms") else None,
                    "files_listed": _total_listed,
                    "files_after_partition_pruning": _total_after_part,
                    "files_after_footer_pruning": _total_after_footer,
                    "files_downloaded": _total_after_footer,
                    "rows_returned": stats.get("total_rows", 0),
                    "source": "execute_api",
                }
                await adb(_db_manager.add_query_performance_log, _perf_log)
        except Exception as _perf_exc:
            logger.debug("Perf audit log failed (non-fatal): %s", _perf_exc)

        # ── Phase 134: Scan quota tracking ────────────────────────────────
        try:
            from core.config import s3 as _sq_cfg
            if _sq_cfg.scan_quotas_enabled and _file_stats_data:
                from core.s3_scan_quota import scan_quota_tracker
                _total_scanned = sum(v.get("after_pruning", 0) for v in _file_stats_data.values())
                if _total_scanned > 0:
                    _user_role = "admin"  # default
                    try:
                        _user_rec = await adb(_db_manager.get_user_by_username, executed_by)
                        if _user_rec:
                            _user_role = _user_rec.get("role", "analyst")
                    except Exception:
                        pass
                    scan_quota_tracker.record_scan(executed_by, _user_role, _total_scanned)
        except Exception:
            pass

        # Store in query result cache — skipped when cache_strategy == "bypass"
        # TTL = 7 days so results persist for the full download-file lifetime.
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key, store_result, make_base_data_key, rls_user_scope as _rls_us_store
                _qc_dict = query_config_dict or (query_config.__dict__ if hasattr(query_config, '__dict__') else {})
                # BF-235: include raw_sql in the cache key so user-edited SQL
                # doesn't collide with the auto-generated SQL stored under the
                # same query_config.
                # Round 5: derive user_scope from the user_ctx passed in
                # (None for non-RLS callers so legacy keys are preserved).
                _ck = cache_key or make_cache_key(
                    _qc_dict, raw_sql=raw_sql, user_scope=_rls_us_store(user_ctx))
                # Phase 104: build source fingerprint from _file_stats
                _src_fp, _src_tables = None, None
                try:
                    if _file_stats_data and _cache_cfg.partition_aware_invalidation:
                        from core.snapshot_fingerprint import compute_source_fingerprint
                        _conn_id_for_fp = getattr(query_config, "connection_id", None)
                        _src_tables = [
                            {
                                "conn_id": _conn_id_for_fp,
                                "table_name": _tname,
                                "format": _tstat.get("format", "parquet"),
                                "snapshot_id": _tstat.get("snapshot_id"),
                                "file_list_hash": _tstat.get("file_list_hash"),
                                "file_count": _tstat.get("file_count"),
                            }
                            for _tname, _tstat in _file_stats_data.items()
                        ]
                        _src_fp = compute_source_fingerprint(_src_tables)
                except Exception as _fp_exc:
                    logger.debug("[cache] fingerprint build failed: %s", _fp_exc)
                # 2026-10-07 -- an Iceberg read must be filed under the
                # SNAPSHOT it read.  A raw-SQL query over a registered
                # Iceberg table carried no file stats and no connection id,
                # so its entry had NO fingerprint and the serve side (which
                # checks only fingerprinted entries) answered the
                # pre-commit result for cache.ttl_seconds (1 h).  Proven on
                # a pyiceberg table: count 20 -> commit -> ``auto`` still 20.
                _store_ok = True
                if _pre_ice_snaps is None:
                    _store_ok = False          # a snapshot nobody could read
                elif _pre_ice_snaps:
                    from core.snapshot_fingerprint import (
                        compute_source_fingerprint as _csf_ice)
                    _ice_conn = (getattr(query_config, "connection_id", None)
                                 or getattr(run_engine, "_s3_conn_id", None))
                    _by_name = {str((t or {}).get("table_name") or "").lower(): t
                                for t in (_src_tables or [])}
                    for _iname, _isid in _pre_ice_snaps.items():
                        _row = _by_name.get(_iname)
                        if _row is None:
                            _row = {"table_name": _iname, "file_list_hash": None,
                                    "file_count": None}
                            _by_name[_iname] = _row
                        _row["format"] = "iceberg"
                        _row["conn_id"] = _row.get("conn_id") or _ice_conn
                        _row["snapshot_id"] = _row.get("snapshot_id") or _isid
                    _src_tables = list(_by_name.values())
                    if any(not t.get("conn_id") for t in _src_tables):
                        _store_ok = False
                    else:
                        _src_fp = _csf_ice(_src_tables)
                if not _store_ok:
                    logger.info("[cache] execution=%s: not storing -- an "
                                "Iceberg snapshot it read cannot be "
                                "fingerprinted", execution_id)
                # 2026-10-16 -- the row-security scope at WRITE time must be the
                # scope the key was built with.  A key chosen before the query
                # (the SQL / cross-source / dedup paths pass ``cache_key``) can
                # predate a policy the query's own rewrite applied: the result
                # is FILTERED, the key SHARED, and every principal would read it
                # (the leak the clean release check found on published views).
                if _store_ok and _key_may_be_shared(cache_key, cache_key_scope,
                                                     lambda: _rls_us_store(user_ctx)):
                    _store_ok = await _shared_store_confirmed(execution_id)
                if _store_ok and output_file.exists():
                    store_result(_ck, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                 # 2026-08-20 -- WRONG KNOB.  download_ttl_seconds is 604800 (7 DAYS) and
                                 # its own declaration calls it "download file retention".
                                 # Using a RETENTION budget as a FRESHNESS TTL meant a SQL
                                 # connector result (Trino/Snowflake/Oracle) could be served
                                 # a WEEK stale with no indication -- and unlike the parquet
                                 # paths these have no file fingerprint, so TTL is the ONLY
                                 # invalidation there is.  cache.ttl_seconds (3600) is the
                                 # freshness knob and already exists.
                                 ttl_seconds=_cache_cfg.ttl_seconds,
                                 connection_id=getattr(query_config, "connection_id", None),
                                 source_fingerprint=_src_fp, source_tables_json=_src_tables)
                    # Also store a base-data cache entry so future queries with
                    # different SELECT/aggregations on the same FROM/WHERE/JOIN
                    # can reuse this downloaded parquet instead of re-fetching S3.
                    # ONLY store when the result is truly raw (no aggregations,
                    # no column restriction) — aggregated results don't represent
                    # the raw data and would serve stale columns on reuse.
                    _has_aggs = bool((_qc_dict.get("aggregations") or []))
                    _has_cols = bool((_qc_dict.get("columns") or []))
                    # 2026-10-16 -- the base-data key carries NO principal; its
                    # READ is skipped whenever row security is on (fail closed,
                    # 2026-07-06), so the WRITE is too: a filtered result filed
                    # here would be read as raw data the day row security is off.
                    try:
                        from core.row_security.api import _is_enabled as _rs_on_bk
                        _rls_on_bk = bool(_rs_on_bk())
                    except Exception:
                        _rls_on_bk = True
                    if not _has_aggs and not _has_cols and not _rls_on_bk:
                        try:
                            _bk = make_base_data_key(_qc_dict)
                            store_result(_bk, output_file, _qc_dict, row_count=stats.get("total_rows", 0), copy=False,
                                         ttl_seconds=_cache_cfg.ttl_seconds,
                                         connection_id=getattr(query_config, "connection_id", None),
                                         source_fingerprint=_src_fp, source_tables_json=_src_tables)
                        except Exception as _bk_exc:
                            logger.warning("Base-data cache key store failed: %s", _bk_exc, exc_info=True)
                    else:
                        logger.debug("[cache] Skipping base-data key store: query has %s",
                                     "aggregations" if _has_aggs else "column restrictions")
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        await _ws_manager.broadcast_to_user(executed_by, _with_engine({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "file_stats": _file_stats_data,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }, _engine_key))
        _log_ws_notification(
            "execution_completed", executed_by or "guest",
            "Query Completed",
            f"{stats.get('total_rows', 0):,} rows",
            execution_id=execution_id,
        )

        logger.info(f"Query execution completed: {execution_id}")

    except (asyncio.CancelledError, InterruptedError) as e:
        # Execution was cancelled — DB status already set by cancel_execution endpoint.
        # Only update if it somehow wasn't marked yet (race condition guard).
        logger.info(f"Query execution cancelled: {execution_id}")
        current_exec = await adb(_db_manager.get_execution, execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            await adb(_db_manager.update_execution, execution_id, status="cancelled",
                                        error_message="Cancelled by user")
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast_to_user(executed_by, {
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise   # must re-raise so asyncio cleans up the task properly

    except Exception as e:
        # Deep-dive fix: classify user-cancellations distinctly from genuine
        # failures.  A cancel is intentional — log at INFO, set status=
        # 'cancelled' (not 'failed'), skip agent suggestions (waste of
        # cycles), skip stale-result fallback (user wanted to STOP).
        _err_text = str(e).lower()
        _is_user_cancel = (
            isinstance(e, InterruptedError)
            or "cancelled by user" in _err_text
            or "cancel_event set" in _err_text
            or "cancelled before" in _err_text
            or "cancelled at" in _err_text
        )
        if _is_user_cancel:
            logger.info(
                "Query %s cancelled by user (%s)", execution_id, e,
            )
            try:
                await adb(_db_manager.update_execution,
                          execution_id,
                          status="cancelled",
                          error_message=str(e)[:_limits_cfg.error_message_max_length])
            except Exception as _upd_err:
                logger.debug(
                    "Could not update execution %s to cancelled: %s",
                    execution_id, _upd_err,
                )
            try:
                await _ws_manager.broadcast_to_user(executed_by, {
                    "type":         "execution_cancelled",
                    "execution_id": execution_id,
                    "message":      "Query cancelled by user.",
                    "timestamp":    datetime.now(timezone.utc).isoformat(),
                })
            except Exception as _ws_err:
                logger.debug("[execute_api] cancel WS broadcast failed: %s", _ws_err)
            # Clean up the half-written output file so it doesn't linger.
            try:
                output_file.unlink(missing_ok=True)
            except OSError:
                pass
            return

        logger.error(f"Error executing query {execution_id}: {e}", exc_info=True)

        # ── Stale-result fallback ─────────────────────────────────────────────
        # If this is a connectivity / auth failure AND we have a previous result
        # file on disk, serve that instead of failing outright.  The frontend
        # will receive execution_completed with stale=True and show a banner.
        # Wrapped in its own try/except so any failure here falls through to the
        # normal failure path below — we never silently swallow the original error.
        _served_stale = False
        if fallback_output_file and is_connection_error(e):
            try:
                _fb = Path(fallback_output_file)
                if _fb.exists():
                    try:
                        import pyarrow.parquet as _pq_fb
                        _fb_rows = _pq_fb.ParquetFile(str(_fb)).metadata.num_rows
                    except Exception:
                        _fb_rows = 0
                    _fb_size = _fb.stat().st_size
                    await adb(_db_manager.update_execution,
                        execution_id,
                        status="completed",
                        engine="result_cache",      # a stale cached result served
                        output_file=str(_fb),
                        total_rows=_fb_rows,
                        file_size_bytes=_fb_size,
                        error_message=None,
                    )
                    _fb_file_id = str(uuid.uuid4())
                    await adb(_db_manager.create_download_file, 
                        file_id=_fb_file_id,
                        execution_id=execution_id,
                        filename=f"stale_result_{execution_id}.parquet",
                        file_path=str(_fb),
                        file_size_bytes=_fb_size,
                        expires_at=_download_expires_at(transient=True),
                    )
                    _stale_reason = _sanitize(str(e))[:_limits_cfg.error_message_max_length]
                    await _ws_manager.broadcast_to_user(executed_by, _with_engine({
                        "type": "execution_completed",
                        "execution_id": execution_id,
                        "file_id": _fb_file_id,
                        "stats": {"total_rows": _fb_rows, "file_size_bytes": _fb_size},
                        "stale": True,
                        "stale_warning": (
                            "Connection unavailable — showing last cached result. "
                            f"Reconnect and re-run to refresh. ({_stale_reason})"
                        ),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }, "result_cache"))
                    _log_ws_notification(
                        "execution_completed", executed_by or "guest",
                        "Stale Result Served",
                        f"Connection failed — last result ({_fb_rows:,} rows) served from cache.",
                        execution_id=execution_id,
                    )
                    logger.warning(
                        "Stale fallback served for %s — connection error: %s", execution_id, e
                    )
                    # Clean up orphaned new output file (the real run never completed)
                    try:
                        output_file.unlink(missing_ok=True)
                    except OSError:
                        pass
                    _served_stale = True
            except Exception as _fb_exc:
                logger.warning("Stale fallback failed for %s: %s", execution_id, _fb_exc, exc_info=True)
        if _served_stale:
            return  # don't mark as failed
        # ─────────────────────────────────────────────────────────────────────

        # ── Phase 120/125: Self-Healing Agent — query failure hook + auto-retry ─
        # _agent_inline_suggestion: optional dict embedded in the
        # execution_failed broadcast so the UI can render a "Try fix" button
        # inline next to the error message, rather than relying solely on the
        # separate agent_suggestion toast.
        _agent_inline_suggestion = None
        try:
            from core.agents import get_orchestrator as _get_orch
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _agent_result = _orch.handle_event("query_failed", {
                    "execution_id": execution_id,
                    "error_message": _sanitize(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": getattr(query_config, "connection_id", None),
                    "query_config": query_config_dict or {},
                    "raw_sql": raw_sql or "",
                    "retry_count": (query_config_dict or {}).get("_agent_retry_count", 0),
                    "tables": [f.path for f in getattr(query_config, "files", [])] if hasattr(query_config, "files") else [],
                })
                if _should_agent_auto_retry(_agent_result):
                    # Phase 125: Auto-retry — apply fix and re-dispatch execution
                    _strategy = _agent_result.get("strategy", "")
                    _retry_count = _agent_result.get("retry_count", 1)
                    logger.info("Agent auto-retrying %s (strategy=%s, attempt=%d)",
                                execution_id, _strategy, _retry_count)
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "agent_retrying",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strategy,
                        "reason": _agent_result.get("reason"),
                        "retry_count": _retry_count,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    await adb(_db_manager.update_execution, execution_id, status="retrying",
                                                 error_message=f"Agent retry: {_strategy}")
                    _modified = await _apply_agent_fix(
                        _strategy, _agent_result.get("retry_params") or {},
                        query_config_dict or {}, query_config, _retry_count,
                        user_ctx=user_ctx,
                    )
                    # BF-280: when the agent fix rewrote the SQL (e.g.
                    # qualify_ambiguous_columns added table-alias prefixes),
                    # use the rewritten raw_sql for the retry — not the
                    # original which would just hit the same error again.
                    _retry_raw_sql = _modified.get("raw_sql") or raw_sql
                    # BF-591: replace deprecated asyncio.get_event_loop().create_task
                    # with strong-ref tracked asyncio.create_task.  Reacquire the
                    # slot for the retry so the inner finally's _release_user_slot
                    # is matched 1:1 with an acquire.
                    try:
                        _r_slot_ok, _r_slot_reason, _ = await _acquire_user_slot(
                            executed_by,
                            _qe_cfg.max_concurrent_per_user if _qe_cfg else 50,
                            _qe_cfg.max_queue_size if _qe_cfg else 100,
                            _qe_cfg.queue_wait_timeout_seconds if _qe_cfg else 60.0,
                            execution_id=execution_id,
                        )
                    except Exception:
                        _r_slot_ok = False
                    if _r_slot_ok:
                        _track_bg_task(
                            execute_query_background(
                                execution_id, query_config, query_id, active_engine,
                                executed_by, _retry_raw_sql, cache_strategy, cache_key,
                                _modified, fallback_output_file, work_type,
                            )
                        )
                        return  # Skip failure path — retry dispatched
                    # BF-593: retry COULDN'T acquire a slot (queue saturated).
                    # Surface an actionable hint so the user doesn't see a
                    # raw DuckDB error with no agent context.
                    try:
                        await _ws_manager.broadcast_to_user(executed_by, {
                            "type": "agent_suggestion",
                            "execution_id": execution_id,
                            "agent": "query_resilience",
                            "strategy": _strategy,
                            "reason": ("Auto-retry queued but server is at "
                                       "concurrency cap — retry manually."),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "username": executed_by,
                        })
                    except Exception:
                        pass
                elif _agent_result and (_agent_result.get("retrying") or _agent_result.get("action") == "notify"):
                    # BF-242: orchestrator returns two shapes depending on AgentAction:
                    #   * RETRY_WITH_FIX → {"retrying": True, "strategy": "...", ...}
                    #   * NOTIFY_USER    → {"action": "notify", "metadata": {strategy, ...}}
                    # The old elif only matched the first shape, so non-retryable
                    # strategies like add_group_by never broadcast — user saw the
                    # raw error with no auto-fix button.  Now we accept both.
                    _strategy = (
                        _agent_result.get("strategy")
                        or (_agent_result.get("metadata") or {}).get("strategy")
                    )
                    _reason = (
                        _agent_result.get("reason")
                        or (_agent_result.get("metadata") or {}).get("description")
                    )
                    logger.info("Agent suggestion for %s: %s", execution_id, _strategy)
                    _agent_broadcast = {
                        "type": "agent_suggestion",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strategy,
                        "reason": _reason,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "username": executed_by,
                    }
                    _cte = (
                        (_agent_result.get("retry_params") or {}).get("cte_analysis")
                        or _agent_result.get("cte_analysis")
                        or (_agent_result.get("metadata") or {}).get("cte_analysis")
                    )
                    if _cte:
                        _agent_broadcast["cte_analysis"] = _cte
                    await _ws_manager.broadcast_to_user(executed_by, _agent_broadcast)

                    # Also keep a slim copy for the inline error UI — strategy +
                    # reason are enough for a "Try fix" button.  The full payload
                    # remains in the agent_suggestion broadcast.
                    _agent_inline_suggestion = {
                        "agent":    "query_resilience",
                        "strategy": _strategy,
                        "reason":   _reason,
                    }
                    if _cte:
                        _agent_inline_suggestion["cte_analysis"] = _cte
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        # 2026-10-07: the orchestrator is OFF by default (agents.enabled),
        # and then nothing above ran -- the rules engine still answers
        # "which fix is this", the same answer the pre-validation refusal
        # gives.  The UI renders it; it decides nothing.
        if _agent_inline_suggestion is None:
            from core.agents.inline_suggestion import suggestion_for_failure as _sugg_for
            _agent_inline_suggestion = await asyncio.to_thread(
                _sugg_for, _sanitize(str(e)), type(e).__name__,
                db_manager=_db_manager)
        # ─────────────────────────────────────────────────────────────────────

        # BF-49: Detect expired tokens from both TokenExpiredError AND
        # DuckDB subprocess errors that contain ExpiredToken in stderr
        _err_msg_lower = str(e).lower()
        _is_token_expired = isinstance(e, TokenExpiredError) or \
            'expiredtoken' in _err_msg_lower or 'token has expired' in _err_msg_lower
        _err_code = "TOKEN_EXPIRED" if _is_token_expired else None
        # 2026-10-07 (F9): the SQL (to name an unknown column's table) and,
        # for an unknown table only, the connection's registered tables.
        _err_conn_id = getattr(query_config, "connection_id", None) or rls_connection_id
        _err_conn = None
        if _err_conn_id:
            from core.error_detection import is_unknown_table_error as _is_unk_tbl
            if _is_unk_tbl(str(e)):
                _err_conn = await adb(_connection_for_error_words, _err_conn_id)
        _user_msg = classify_duckdb_error(
            e, sql=raw_sql, connection_id=_err_conn_id, connection=_err_conn)
        await adb(_db_manager.update_execution, 
            execution_id,
            status="failed",
            error_message=_user_msg,
        )
        # Clean up orphaned output file
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass

        ws_msg = {
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": _user_msg,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if _err_code:
            ws_msg["error_code"] = _err_code
        if _agent_inline_suggestion:
            ws_msg["agent_suggestion"] = _agent_inline_suggestion
            await _record_failure_suggestion(execution_id, _agent_inline_suggestion)
        await _ws_manager.broadcast_to_user(executed_by, ws_msg)
        _log_ws_notification(
            "execution_failed", executed_by or "guest",
            "Query Failed",
            _sanitize(str(e))[:_limits_cfg.error_message_max_length],
            execution_id=execution_id,
        )
        # 2026-10-02 -- the run is recorded as failed above; a caller that
        # answers the request itself gets the REFUSAL too (see the
        # ``reraise_refusals`` docstring), never only "no result".
        if reraise_refusals:
            from api.connector_errors import scan_refusal_in as _scan_refusal_in
            if _scan_refusal_in(e) is not None:
                raise

    finally:
        # BF-584: release slot + wake any queued waiter.
        _release_user_slot(executed_by)
        # BF-289: drop the stage-tracker entry so the registry doesn't
        # leak entries for completed/failed/cancelled executions.
        # BF-297: BEFORE dropping, snapshot the stage history and persist
        # it onto query_executions.files_metadata so the execution detail
        # UI can show the per-step timing breakdown.
        try:
            from core.execution_stage import (
                end_execution as _stg_end,
                finalise_history as _stg_final,
            )
            _hist = _stg_final(execution_id)
            # BF-LOG-BUFFER: drain captured query-only log lines so they can
            # be persisted alongside the stage history for UI replay.
            try:
                from core.execution_log_buffer import drain as _elb_drain
                _log_lines = _elb_drain(execution_id)
            except Exception:
                _log_lines = []
            # Smart brain (2026-06-23) — collect the brain decision trace
            # accumulated during this query.  Surfaces in
            # files_metadata.brain_trace + brain_trace_summary so the
            # admin "why was this query slow" view can render the
            # cache hits / misses / VPC routes / snapshot advances.
            _brain_trace_entries: list = []
            _brain_summary: dict = {}
            try:
                from core.brain_trace import end as _brain_end, summary as _brain_sum
                _brain_trace_entries = _brain_end()
                if _brain_trace_entries:
                    _brain_summary = _brain_sum(_brain_trace_entries)
            except Exception:
                pass
            # Phase 160 (2026-07-01) — finalize + emit per-query
            # latency breakdown to Prometheus histograms + fold into
            # brain_trace.  Total = actual wall-clock since the
            # execute_query_background start stamp (_phase156_query_t0
            # is monotonic()) so residual attribution to `other` is
            # meaningful.
            _latency_breakdown: dict = {}
            try:
                from core.brain_latency_breakdown import (
                    emit_breakdown as _lb_emit,
                )
                _elapsed = max(0.0, _time.monotonic() - _phase156_query_t0)
                _latency_breakdown = _lb_emit(total_seconds=_elapsed)
            except Exception as _lb_exc:                              # pragma: no cover
                # 2026-07-02 -- debug-log so a systematic emit_breakdown
                # failure is greppable.  Fail-open by design.
                logger.debug(
                    "execute_api: emit_breakdown suppressed %s: %s",
                    type(_lb_exc).__name__, _lb_exc,
                )
            if (_hist and _hist.get("stages")) or _log_lines or _brain_trace_entries or _latency_breakdown:
                try:
                    _ex = await adb(_db_manager.get_execution, execution_id)
                    _fm = (_ex or {}).get("files_metadata") or {}
                    if isinstance(_fm, str):
                        import json as _json_fm
                        try:
                            _fm = _json_fm.loads(_fm)
                        except Exception:
                            _fm = {}
                    if _hist and _hist.get("stages"):
                        _fm["stage_history"] = _hist
                    if _log_lines:
                        # Strip internal monotonic-time field before persisting
                        # to keep the JSON payload small and stable.
                        _fm["log_lines"] = [
                            {k: v for k, v in r.items() if k != "_mt"}
                            for r in _log_lines
                        ]
                    if _brain_trace_entries:
                        _fm["brain_trace"] = _brain_trace_entries
                        _fm["brain_trace_summary"] = _brain_summary
                    if _latency_breakdown:
                        _fm["latency_breakdown"] = _latency_breakdown
                    await adb(_db_manager.update_execution, execution_id, files_metadata=_fm)
                except Exception as _persist_exc:
                    logger.debug("Stage history / log buffer persist failed: %s",
                                 _persist_exc)
            _stg_end(execution_id)
        except Exception:
            pass

        # Unbind the log-buffer context so any further logs in cleanup paths
        # don't accidentally land in this execution's buffer.
        try:
            if _log_ctx is not None:
                _log_ctx.__exit__(None, None, None)
        except Exception:
            pass


async def execute_sql_connector_background(
    execution_id: str,
    connector,          # SqlConnector instance (already constructed)
    sql: str,           # complete SQL built by engine.build_query_sql()
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
    row_limit: Optional[int] = None,
    reraise_failure: bool = False,
    cache_key_scope: Any = _SCOPE_UNSET,
):
    """Execute a query against a SQL connector (Trino/Starburst/Snowflake/Databricks/Oracle).
    Mirrors the structure of execute_query_background so the frontend receives
    the same WebSocket messages and can download results the same way.

    ``row_limit`` is handed to the connector, NOT spliced into ``sql`` here.
    Every SQL connector already routes its limit through
    ``connectors.base._apply_limit``, which knows the trailing-window spellings
    and which Oracle overrides for its own grammar; appending "LIMIT n" at this
    layer would produce a parse error on Oracle and a double window on
    ANSI-FETCH SQL.  0 / None mean UNLIMITED, as everywhere else.

    ``reraise_failure`` (2026-10-05) -- for a caller that AWAITS this and
    answers the request itself (the published-view saved-query handler).
    The failure is recorded exactly as before (failed run, WebSocket
    notice) and then RE-RAISED, so the caller can ask
    ``api.connector_errors`` what it is: the source's verdict on the
    statement (Trino TYPE_MISMATCH, ORA-00942) is a 400 carrying the
    source's sentence, not "Execution produced no result" -> 500.
    ``False`` (every background caller) changes nothing.
    """
    from core.proxy_utils import sanitize_proxy_error as _sanitize
    import pyarrow as _pa
    import pyarrow.parquet as _pq
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    # 2026-10-07: off the event loop (core/checkpoint.py, the checkpoint lane).
    from core.checkpoint import mark_started_nowait as _cp_started
    _cp_started(execution_id)
    # Phase 156 -- wall-clock start for the route outcome history hook.
    _phase156_query_t0 = _time.monotonic()
    _pool = get_pool()

    # BF-SQL-CONN-STAGES: emit per-execution stage signals + per-query log
    # file like the S3 path does, so admins can grep
    # backend/data/logs/queries/<exec_id>.log for what each Starburst /
    # Trino / Snowflake / Databricks / Oracle / Athena query did.
    try:
        from core.execution_stage import (
            begin_execution as _stg_begin,
            set_stage as _stg_set,
        )
        _stg_begin(execution_id)
        _stg_set(execution_id, "init",
                 message=f"Submitting query to {type(connector).__name__.replace('Connector', '').lower()}")
    except Exception:
        pass

    # BF-TRINO-STATUS: bind execution_id on the connector so its
    # streaming method can push source-DB live state (Trino cursor.stats:
    # state/splits/rows/bytes) into the QueryStudio stage tracker for
    # heartbeat broadcast.  Other connectors inherit a no-op setter.
    try:
        if hasattr(connector, "set_execution_id"):
            connector.set_execution_id(execution_id)
    except Exception:
        pass

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"

        # Phase 139 (Tier 2.1): capture event loop so worker thread can schedule
        # WebSocket broadcasts of streaming chunks back on the main loop.
        _conn_loop = asyncio.get_running_loop()

        def _exec_sql(cancel_event=None):
            # BF-421 — same temp_dir leak fix as _exec_to_parquet.  SQL
            # connector path can also trigger predownload via federation
            # views or cross-source helpers that internally use the
            # boto3 pre-download path.
            from core.duckdb_views import cleanup_temp_downloads as _ctd
            try:
                return _exec_sql_body(cancel_event)
            finally:
                try:
                    _ctd()
                except Exception as _ctd_exc:
                    logger.debug("[bf421] cleanup_temp_downloads raised: %s", _ctd_exc)

        def _exec_sql_body(cancel_event=None):
            try:
                logger.info(f"SQL connector query [{execution_id}]:\n{sql}")
                _ttfr_start = _time.time()
                # Stage: now actually executing on the source DB
                try:
                    from core.execution_stage import set_stage as _stg_set_inner
                    _stg_set_inner(execution_id, "duckdb_execute",
                                    message="Streaming results from source DB")
                except Exception:
                    pass

                # Phase 139 (Tier 2.1) — REAL cursor-based streaming. Use the
                # streaming method on the connector (default fallback yields
                # one big chunk; Snowflake/Trino/Databricks/Oracle override to
                # do true fetchmany). First chunk broadcast as soon as the
                # source DB returns the first rows — TTFR is now the time to
                # the FIRST batch, not the full result.
                #
                # 2026-06-24 -- BOUNDED-MEMORY streaming write.  Mirrors the
                # ETL pattern from ``ETL/steps/file/starburst_file_base.
                # ChunkWriter``: cursor batches -> bounded Queue ->
                # background thread -> pyarrow.parquet.ParquetWriter.
                # Memory bound = (batch_size * row_size * queue_maxsize),
                # not (total_rows * row_size).  Previously _all_rows.extend
                # + pd.DataFrame buffered the ENTIRE result -- 170M Trino
                # rows OOM'd the pod at ~50-100M.  Now memory stays bounded
                # independent of the row count -- measured 2026-09-26 (F6):
                # +222 MB for 6M Trino lineitem rows (248 MB parquet), +35 MB
                # for 6M Oracle rows; the writer's row groups and the arrow
                # allocator, not rows held back.  Record: PENDING.md
                # critical #2.
                _streaming_cap = 1000
                _ttfr_recorded = False
                # 2026-08-25 — the REAL time to first row.  The value shipped
                # as "time_to_first_row_seconds" was computed after the whole
                # drain and the parquet finalise, so it reported TOTAL time
                # under a name that says first row: the one field an operator
                # reaches for to tell "the source was slow" from "we were slow"
                # answered neither.  Same shape as the s3_gets counter that
                # could not see LIST calls — an instrument that reads plausibly
                # and measures the wrong thing is worse than no instrument.
                # None when the result was empty: no first row, no honest
                # number to report.
                _ttfr_first_row_seconds: Optional[float] = None
                col_defs: list = []
                col_names: list = []
                _streamed_so_far = 0
                # Sample of the first WS-shipped rows; kept ONLY so the empty-
                # result path can detect "we never saw column metadata" and
                # write a typed-empty parquet.  Capped at _streaming_cap; the
                # parquet write goes through the streaming writer + does NOT
                # consume this buffer.
                _preview_rows: list = []

                from core.json_utils import sanitize_for_json as _ship_sanitize
                from core.parquet_stream_writer import ParquetStreamWriter

                def _broadcast_chunk_async(rows_payload, columns_payload, total_so_far):
                    async def _ship():
                        await _ws_manager.broadcast_to_user(executed_by, {
                            "type":         "execution_chunk",
                            "execution_id": execution_id,
                            "rows":         rows_payload,
                            "columns":      columns_payload,
                            "total_so_far": total_so_far,
                            "timestamp":    datetime.now(timezone.utc).isoformat(),
                        })
                    try:
                        asyncio.run_coroutine_threadsafe(_ship(), _conn_loop)
                    except Exception:
                        pass

                output_file.parent.mkdir(parents=True, exist_ok=True)
                _pstream: Optional[ParquetStreamWriter] = None
                total_rows = 0

                try:
                    # BF-262 follow-up: pass cancel_event so the connector's
                    # cursor.cancel() / connection.cancel() fires when the
                    # user clicks Cancel mid-fetch.
                    for chunk_cols, chunk_rows in connector.execute_query_streaming(
                        sql, cancel_event=cancel_event,
                        limit=(int(row_limit) if row_limit and int(row_limit) > 0
                               else None),
                    ):
                        if not col_defs and chunk_cols:
                            col_defs = chunk_cols
                            col_names = [c["name"] for c in col_defs]
                        if cancel_event is not None and cancel_event.is_set():
                            if _pstream is not None:
                                _pstream.cancel()
                            raise InterruptedError("Cancelled by user")
                        if not chunk_rows:
                            continue
                        # Push to bounded-queue parquet writer.  Init lazily
                        # on the first non-empty batch so col_defs is known.
                        if _pstream is None and col_defs:
                            _pstream = ParquetStreamWriter(
                                output_path=str(output_file),
                                columns=col_defs,
                                queue_maxsize=4,
                                compression="zstd",
                            )
                            _pstream.start()
                        if _pstream is not None:
                            _pstream.put_batch(chunk_rows, timeout=300)
                        total_rows += len(chunk_rows)
                        # Stream first STREAM_CAP rows to the WS as they arrive
                        if _streamed_so_far < _streaming_cap and chunk_rows:
                            remaining = _streaming_cap - _streamed_so_far
                            ship = chunk_rows[:remaining]
                            try:
                                ship_sanitized = _ship_sanitize(ship)
                            except Exception:
                                ship_sanitized = ship
                            _preview_rows.extend(ship)
                            _streamed_so_far += len(ship)
                            _broadcast_chunk_async(ship_sanitized, col_defs, _streamed_so_far)
                            if not _ttfr_recorded:
                                # Capture BEFORE the try: a failing metrics
                                # import must not lose the measurement. The
                                # old code computed it only as an argument to
                                # record_time_to_first_row, so the value lived
                                # and died inside a swallowing except.
                                _ttfr_first_row_seconds = _time.time() - _ttfr_start
                                try:
                                    from core.metrics import record_time_to_first_row
                                    record_time_to_first_row(
                                        "sql_connector", _ttfr_first_row_seconds,
                                    )
                                except Exception:
                                    pass
                                _ttfr_recorded = True
                except InterruptedError:
                    raise                      # user cancel — already handled
                except NotImplementedError:
                    # Some connector lacks streaming — fall back to blocking
                    # call.  Same memory-bounded write applies: feed the
                    # full result through the writer in one batch (still
                    # bounded by the connector's own memory).
                    result = connector.execute_query(sql)
                    col_defs = result.get("columns", [])
                    col_names = [c["name"] for c in col_defs]
                    _fallback_rows = result.get("rows", []) or []
                    total_rows = len(_fallback_rows)
                    if total_rows > 0 and col_defs:
                        _pstream = ParquetStreamWriter(
                            output_path=str(output_file),
                            columns=col_defs,
                            queue_maxsize=4,
                            compression="zstd",
                        )
                        _pstream.start()
                        _pstream.put_batch(_fallback_rows, timeout=300)
                except Exception as _stream_exc:
                    # 2026-08-21 — KILL THE QUERY AT THE SOURCE.
                    #
                    # Operator: "if UI throws error then query should be killed
                    # in starburst rather than keep running" — and they were
                    # watching two count queries still burning coordinator time
                    # after the UI had already failed.
                    #
                    # Cancellation is driven ONLY by the cancel_event watchdog
                    # inside execute_query_streaming, which calls cur.cancel()
                    # (a real query-cancel to the Trino coordinator).  Nothing
                    # set that event when WE failed, so abandoning the generator
                    # left the source executing until it finished on its own —
                    # a write-side bug that burns someone else's cluster.
                    #
                    # The ORIGINAL exception is re-raised unchanged, so the
                    # execution still fails with the real cause; the event is
                    # only used to stop the source.
                    if cancel_event is not None:
                        try:
                            cancel_event.set()
                            logger.warning(
                                "SQL connector query %s failed locally (%s) — "
                                "signalling cancel so the source stops "
                                "executing it",
                                execution_id, type(_stream_exc).__name__,
                            )
                        except Exception:
                            logger.debug("source-cancel signal failed",
                                         exc_info=True)
                    raise

                # Drain + close the streaming writer.
                if _pstream is not None:
                    try:
                        _pstream.signal_end()
                        _written = _pstream.finalise(timeout=1800)
                        # finalise returns rows written by the writer; trust
                        # it over the producer-side counter (handles any
                        # short-write edge case).
                        if _written:
                            total_rows = _written
                    finally:
                        _pstream.close()

                if not _ttfr_recorded:
                    # Empty-result path or fallback — record TTFR now
                    try:
                        from core.metrics import record_time_to_first_row
                        record_time_to_first_row("sql_connector", _time.time() - _ttfr_start)
                    except Exception:
                        pass

                # Empty-result fallback: write a valid typed-empty parquet so
                # downstream readers (DataGridViewer, mirror engine) don't
                # 404 on a missing file.  Streaming writer never opened a
                # file in this case (no batches pushed).
                if total_rows == 0:
                    _col_names = [c["name"] for c in col_defs] if col_defs else []
                    _empty_schema = _pa.schema([_pa.field(n, _pa.string()) for n in _col_names])
                    _pq.write_table(
                        _pa.table({n: _pa.array([], type=_pa.string()) for n in _col_names}, schema=_empty_schema),
                        output_file, compression="zstd"
                    )
                file_size = output_file.stat().st_size
                # Total time to drain the source and finalise the parquet.
                # Named for what it is — this was previously shipped as
                # "time_to_first_row_seconds".
                _drain_seconds = _time.time() - _ttfr_start

                # Phase 139 (Tier 1.2): connector pushdown telemetry — fail-OPEN
                try:
                    from core.metrics import record_connector_response, classify_pushdown
                    _conn_name = type(connector).__name__.replace("Connector", "").lower()
                    _qc = query_config_dict or {}
                    _has_filters = bool(_qc.get("filters") or _qc.get("where_clauses"))
                    _has_limit = bool(_qc.get("limit") and int(_qc.get("limit") or 0) > 0)
                    _pushdown = classify_pushdown(sql, _has_filters, _has_limit)
                    record_connector_response(
                        connector=_conn_name,
                        pushdown=_pushdown,
                        bytes_returned=file_size,
                        rows_returned=total_rows,
                    )
                except Exception:
                    pass

                return {"total_rows": total_rows, "file_size_bytes": file_size,
                        # First row vs. whole drain, reported separately.
                        # Together they say WHERE the time went: a small TTFR
                        # with a large drain is transport/volume (the source
                        # answered fast, we spent the time pulling rows); a
                        # large TTFR is the source itself.
                        "time_to_first_row_seconds": _ttfr_first_row_seconds,
                        "drain_seconds": _drain_seconds,
                        "status": "completed"}
            finally:
                try:
                    connector.close()
                except Exception as exc:
                    logger.warning("Recoverable error: %s", exc, exc_info=True)

        try:
            _wp_record = await _pool.submit(
                WorkType.INTERACTIVE, _exec_sql,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            # BF-589: was sync — freezes event loop.
            await adb(_db_manager.update_execution, execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast_to_user(executed_by, {"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        await adb(_db_manager.update_execution, execution_id, status="processing")  # BF-589
        await _ws_manager.broadcast_to_user(executed_by, {
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        # BF-250: heartbeat broadcasts elapsed time every 15 s during the
        # blocking engine call so silent COUNT(DISTINCT) / large scans don't
        # leave the user staring at an unchanging spinner.
        stats = await _await_with_heartbeat(
            _wp_record.future,
            execution_id=execution_id,
            executed_by=executed_by,
            ws_manager=_ws_manager,
        )
        stats = _sanitize_for_json(stats)  # BF-100: NaN/Infinity → None

        # 2026-09-27 -- the SOURCE is the engine here (Trino / Oracle / ...),
        # read off the connector the factory stamped.
        _sqlc_engine_key = _engine_for_connector(connector)
        # BF-589: was sync — freezes event loop.
        await adb(_db_manager.update_execution,
            execution_id,
            status="completed",
            engine=_sqlc_engine_key,
            total_rows=stats.get("total_rows", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )

        # Phase 155/156 -- brain completion hooks for the SQL-connector
        # path (Trino / Starburst / Snowflake / Databricks / Oracle /
        # Athena).  Same hooks 3 + 4 + 7 as the regular path.
        _phase156_completion_hooks(
            raw_sql=sql,
            query_config_dict=query_config_dict,
            output_file_path=str(output_file) if output_file.exists() else None,
            stats=stats,
            query_t0_monotonic=_phase156_query_t0,
            db_manager=_db_manager,
            # 2026-08-20 -- principal scope for the brain result cache.
            username=executed_by,
        )

        # ── S3 result upload (Phase 19F) ──
        try:
            from core.s3_storage import maybe_upload_result_to_s3
            _s3_info = maybe_upload_result_to_s3(output_file, execution_id, _s3_config)
            if _s3_info:
                # BF-589: was sync.
                await adb(_db_manager.update_execution, execution_id, output_file=_s3_info.get("s3_uri", str(output_file)))
        except Exception as _s3_exc:
            logger.warning("S3 result upload hook failed for %s: %s", execution_id, _s3_exc, exc_info=True)

        file_id = str(uuid.uuid4())
        # BF-589: was sync.
        await adb(_db_manager.create_download_file,
            file_id=file_id,
            execution_id=execution_id,
            filename=f"query_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=_download_expires_at()
        )
        if query_id:
            await adb(_db_manager.increment_execution_count, query_id)  # BF-589

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import store_result as _store_res
                # BF-235 / Round 5: the cache key is built by the CALLER
                # (execute_api's SQL-connector dispatch), which owns the
                # raw_sql + RLS user scope that go into it.  This function
                # has neither in scope, so it must NOT fabricate a key —
                # a locally-invented key can never be read back and would
                # only grow the cache directory.
                # 2026-08-09: the fallback that used to sit here referenced
                # `raw_sql` / `user_ctx` (copy-paste from
                # execute_query_background, where both ARE parameters).
                # Both are undefined here, so the fallback raised NameError
                # into the enclosing `except Exception` on every caller that
                # omits cache_key (published views).  Skipping the store
                # when no key was supplied is what actually happened at
                # runtime — now it happens without the exception + warning.
                _ck = cache_key
                if (_ck and output_file.exists()
                        and (not _key_may_be_shared(_ck, cache_key_scope, lambda: None)
                             or await _shared_store_confirmed(execution_id))):
                    _store_res(_ck, output_file, query_config_dict or {},
                               row_count=stats.get("total_rows", 0), copy=False,
                               ttl_seconds=_cache_cfg.ttl_seconds)
            except Exception as exc:
                logger.warning("Recoverable error caching SQL connector result: %s", exc, exc_info=True)

        await _ws_manager.broadcast_to_user(executed_by, _with_engine({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }, _sqlc_engine_key))
        logger.info(f"SQL connector query completed: {execution_id} ({stats.get('total_rows',0)} rows)")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"SQL connector query cancelled: {execution_id}")
        # BF-589: was sync — freezes event loop.
        current_exec = await adb(_db_manager.get_execution, execution_id)
        if current_exec and current_exec.get("status") not in ("cancelled",):
            await adb(_db_manager.update_execution, execution_id, status="cancelled", error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast_to_user(executed_by, {"type": "execution_cancelled", "execution_id": execution_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat()})
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        # 2026-10-10 -- THE failure text (core.connectors.base
        # .describe_source_failure): the source's sentence for a refused
        # certificate / login / right / statement, never the transport's
        # pool text or the driver's repr.  Same words as the SQL editor
        # lane, the feed's run error and the sync routes' detail.
        from core.connectors.base import describe_source_failure as _describe_failure
        from core.engine_attribution import engine_for_connector as _efc
        _safe_e = _sanitize(_describe_failure(e, _efc(connector) or "sql"))
        logger.error(f"SQL connector query failed {execution_id}: {_safe_e}", exc_info=True)
        # Phase 120/125: Self-Healing Agent — SQL connector failure hook + auto-retry
        _agent_result_sql = None
        try:
            from core.agents import get_orchestrator as _get_orch_sql
            _orch_sql = _get_orch_sql()
            if _orch_sql and _orch_sql.enabled:
                _agent_result_sql = _orch_sql.handle_event("query_failed", {
                    "execution_id": execution_id,
                    "error_message": _safe_e,
                    "error_type": type(e).__name__,
                    "connection_id": (query_config_dict or {}).get("connection_id"),
                    "query_config": query_config_dict or {},
                    "retry_count": (query_config_dict or {}).get("_agent_retry_count", 0),
                })
                if _should_agent_auto_retry(_agent_result_sql):
                    _strategy_sql = _agent_result_sql.get("strategy", "")
                    _retry_count_sql = _agent_result_sql.get("retry_count", 1)
                    logger.info("Agent auto-retrying SQL connector %s (strategy=%s, attempt=%d)",
                                execution_id, _strategy_sql, _retry_count_sql)
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "agent_retrying",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strategy_sql,
                        "reason": _agent_result_sql.get("reason"),
                        "retry_count": _retry_count_sql,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    # BF-589: was sync.
                    await adb(_db_manager.update_execution, execution_id, status="retrying",
                                                 error_message=f"Agent retry: {_strategy_sql}")
                    _modified_sql = await _apply_agent_fix(
                        _strategy_sql, _agent_result_sql.get("retry_params") or {},
                        query_config_dict or {}, None, _retry_count_sql,
                    )
                    # BF-589: use asyncio.create_task on the CURRENT
                    # loop, not get_event_loop() (deprecated in 3.12+).
                    # BF-591: strong-ref track + reacquire slot so the
                    # retry's inner finally matches an acquire 1:1.
                    try:
                        _r_sql_ok, _r_sql_reason, _ = await _acquire_user_slot(
                            executed_by,
                            _qe_cfg.max_concurrent_per_user if _qe_cfg else 50,
                            _qe_cfg.max_queue_size if _qe_cfg else 100,
                            _qe_cfg.queue_wait_timeout_seconds if _qe_cfg else 60.0,
                            execution_id=execution_id,
                        )
                    except Exception:
                        _r_sql_ok = False
                    if _r_sql_ok:
                        _track_bg_task(
                            execute_sql_connector_background(
                                execution_id, connector, sql, query_id,
                                executed_by, cache_key, cache_strategy, _modified_sql,
                                # 2026-08-22 — the retry re-dispatched
                                # WITHOUT the cap, so a published view that
                                # failed once then materialised its whole
                                # 70M rows on the retry: the cap added in
                                # 9082f1f4 was undone by the sibling call.
                                row_limit=row_limit,
                            )
                        )
                        return  # Skip failure path — retry dispatched
                    # BF-593: same actionable-hint surface as the main path.
                    try:
                        await _ws_manager.broadcast_to_user(executed_by, {
                            "type": "agent_suggestion",
                            "execution_id": execution_id,
                            "agent": "query_resilience",
                            "strategy": _strategy_sql,
                            "reason": ("Auto-retry queued but server is at "
                                       "concurrency cap — retry manually."),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "username": executed_by,
                        })
                    except Exception:
                        pass
                elif _agent_result_sql and (_agent_result_sql.get("retrying") or _agent_result_sql.get("action") == "notify"):
                    # BF-242: also accept NOTIFY_USER shape (see main path above)
                    _strat_sql = _agent_result_sql.get("strategy") or (_agent_result_sql.get("metadata") or {}).get("strategy")
                    _rsn_sql = _agent_result_sql.get("reason") or (_agent_result_sql.get("metadata") or {}).get("description")
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "agent_suggestion",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strat_sql,
                        "reason": _rsn_sql,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "username": executed_by,
                    })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        # 2026-10-07: this road never put the suggestion on execution_failed
        # (only on a separate agent_suggestion toast, and only with the
        # orchestrator ON), so a Trino EXPRESSION_NOT_AGGREGATE reached the
        # query builder with no "Add GROUP BY clause".  THE one answer:
        from core.agents.inline_suggestion import suggestion_for_failure as _sugg_for_sql
        _inline_sugg_sql = await asyncio.to_thread(
            _sugg_for_sql, _safe_e, type(e).__name__,
            db_manager=_db_manager, agent_result=_agent_result_sql)
        # BF-589: was sync.
        await adb(_db_manager.update_execution, execution_id, status="failed", error_message=_safe_e)
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        _failed_msg_sql = {"type": "execution_failed", "execution_id": execution_id,
                           "error": _safe_e, "timestamp": datetime.now(timezone.utc).isoformat()}
        if _inline_sugg_sql:
            _failed_msg_sql["agent_suggestion"] = _inline_sugg_sql
            await _record_failure_suggestion(execution_id, _inline_sugg_sql)
        await _ws_manager.broadcast_to_user(executed_by, _failed_msg_sql)
        if reraise_failure:
            raise
    finally:
        # Clear checkpoint — execution finished (Phase 41)
        # 2026-10-07: submitted, not awaited -- an await here would be a
        # cancellation point that skips the slot release below.
        from core.checkpoint import mark_completed_nowait as _cp_done_sql
        _cp_done_sql(execution_id)
        # BF-584: release slot + wake queued waiter.
        _release_user_slot(executed_by)
        # BF-SQL-CONN-STAGES: persist stage history + close out the per-query
        # log file so the post-execution chip + admin "View log" UI work for
        # SQL connector executions like they do for S3.
        try:
            from core.execution_stage import (
                end_execution as _stg_end_sc2,
                finalise_history as _stg_final_sc2,
            )
            _hist_sc = _stg_final_sc2(execution_id)
            if _hist_sc and _hist_sc.get("stages"):
                try:
                    # BF-589: was sync.
                    _ex_sc = await adb(_db_manager.get_execution, execution_id)
                    _fm_sc = (_ex_sc or {}).get("files_metadata") or {}
                    if isinstance(_fm_sc, str):
                        import json as _json_fm_sc
                        try:
                            _fm_sc = _json_fm_sc.loads(_fm_sc)
                        except Exception:
                            _fm_sc = {}
                    _fm_sc["stage_history"] = _hist_sc
                    # BF-589: was sync.
                    await adb(_db_manager.update_execution, execution_id, files_metadata=_fm_sc)
                except Exception as _persist_exc_sc:
                    logger.debug("SQL connector stage history persist failed: %s",
                                 _persist_exc_sc)
            _stg_end_sc2(execution_id)
        except Exception:
            pass


def storage_side_reads_its_sql(raw_sql, conn_type, files) -> bool:
    """THE answer to "does this side of a cross-source run name its tables
    in its SQL rather than in ``files``?" -- for the PRIMARY and the
    SECONDARY alike (2026-10-06).

    A raw-SQL S3 side binds its registered-table views from the statement
    (``_raw_sql_with_views`` -> ``setup_registered_views``), so an empty
    ``files`` list is its normal shape, not "no data".  The secondary was
    taught this on 2026-10-04; the primary kept its own copy of the decision
    and refused every raw-SQL S3 primary with a secondary ("Primary query
    produced no files after resolution") -- found live on real AWS.
    """
    return bool(raw_sql and str(raw_sql).strip()) and conn_type == "s3" and not files


async def execute_cross_query_background(
    execution_id: str,
    primary_engine,
    primary_config: QueryConfig,
    secondary_engine,
    secondary_config: QueryConfig,
    combine_mode: str,
    join_config: Optional[dict],
    query_id: Optional[int] = None,
    executed_by: str = "guest",
    cache_key: Optional[str] = None,
    cache_strategy: str = "auto",
    query_config_dict: Optional[dict] = None,
    work_type=None,
    primary_raw_sql: Optional[str] = None,
    secondary_raw_sql: Optional[str] = None,
    # BF-106: Connection IDs for proxy pre-download fallback
    primary_connection_id: Optional[int] = None,
    secondary_connection_id: Optional[int] = None,
    # Phase 131 deep-dive #13 (round 4): RLS on structured cross-source PVs.
    user_ctx: Optional[Dict[str, Any]] = None,
    cache_key_scope: Any = _SCOPE_UNSET,
):
    """Background task for cross-connection (multi-source) query execution.

    Phase 131 deep-dive #13 (round 4): ``user_ctx`` enables row-security
    rewrite on both legs when ``primary_raw_sql`` / ``secondary_raw_sql``
    aren't pre-rewritten (structured cross-source PVs).
    """
    import pandas as _pd
    from core.worker_pool import get_pool, WorkType, QueueFullError as _QueueFull
    # 2026-10-07: off the event loop (core/checkpoint.py, the checkpoint lane).
    from core.checkpoint import mark_started_nowait as _cp_started
    from core.proxy_utils import sanitize_proxy_error as _sanitize
    _cp_started(execution_id)
    # Phase 156 -- wall-clock start for the route outcome history hook.
    _phase156_query_t0 = _time.monotonic()
    # Phase I (2026-06-08) -- mirror execute_query_background fix.
    # Stamp execution_id ContextVar so record_pruning fires for the
    # iceberg reads run from both primary + secondary legs.
    try:
        from core.query_diagnostic_store import set_current_execution_id
        set_current_execution_id(execution_id)
    except Exception as _qds_exc:                                     # pragma: no cover
        # 2026-07-02 -- debug-log so a systemic query_diagnostic_store
        # wiring failure is greppable.  Fail-open by design; this
        # only feeds the pruning-history admin view.
        logger.debug(
            "execute_api: set_current_execution_id suppressed %s: %s",
            type(_qds_exc).__name__, _qds_exc,
        )
    # Phase Y (2026-06-09) -- record execution_path so /diagnose/{id}
    # shows the cross-source branch instead of the canned "no
    # execution_path recorded" alert.  Previously only single-source
    # queries set this; cross-source queries silently no-op'd.
    try:
        from core.brain.scan_plan import record_execution_path as _rep_cross
        _rep_cross(
            execution_id=execution_id,
            branch="4_cross_source",
            has_reg=bool(getattr(primary_engine, "_registered_tables", None)
                          or getattr(secondary_engine, "_registered_tables", None)),
            raw_sql=bool(primary_raw_sql or secondary_raw_sql),
            has_s3_reg=bool(getattr(primary_engine, "_s3_conn_config", None)
                             or getattr(secondary_engine, "_s3_conn_config", None)),
            files=list(primary_config.files or []) + list(secondary_config.files or []),
            notes=f"combine_mode={combine_mode} · primary_conn={primary_connection_id} · secondary_conn={secondary_connection_id}",
        )
    except Exception:
        pass
    _pool = get_pool()
    _work_type = work_type if work_type is not None else WorkType.INTERACTIVE

    # Phase 131 deep-dive #13 (round 4): RLS rewrite on each leg when the
    # caller didn't already provide a rewritten raw_sql.  No-op when RLS
    # is disabled or no user_ctx is given.  Fail-closed on rewrite errors.
    if user_ctx is not None:
        try:
            from core.row_security.api import _is_enabled as _rs_is_enabled
            if _rs_is_enabled():
                from core.duckdb_views import build_query_sql as _build_sql
                from core.row_security import secure_sql as _rs_secure
                from core.virtual_ref_rewriter import rewrite_virtual_refs as _rv
                # A SQL-connector side's statement was secured by the route
                # in its own dialect (2026-10-04); synthesising a DuckDB
                # twin of it here would secure SQL that never runs.
                if primary_raw_sql is None and not getattr(
                        primary_engine, "_is_sql_connector_engine", False):
                    _psy = await asyncio.to_thread(_build_sql, primary_config)
                    _psy = _rv(_psy)  # Round 10: virtual prefix → view name
                    if _psy:
                        _ps = await asyncio.to_thread(
                            _rs_secure, _psy, dialect="duckdb",
                            user_ctx=user_ctx, connection_id=primary_connection_id,
                            request_id=execution_id,
                        )
                        if _ps and _ps.strip() != _psy.strip():
                            primary_raw_sql = _ps
                if (secondary_raw_sql is None and secondary_config is not None
                        and not getattr(secondary_engine,
                                        "_is_sql_connector_engine", False)):
                    _ssy = await asyncio.to_thread(_build_sql, secondary_config)
                    _ssy = _rv(_ssy)  # Round 10
                    if _ssy:
                        _ss = await asyncio.to_thread(
                            _rs_secure, _ssy, dialect="duckdb",
                            user_ctx=user_ctx, connection_id=secondary_connection_id,
                            request_id=execution_id,
                        )
                        if _ss and _ss.strip() != _ssy.strip():
                            secondary_raw_sql = _ss
        except Exception as _rs_exc:
            logger.error("execute_cross_query_background: RLS rewrite failed for %s: %s",
                          execution_id, _rs_exc)
            try:
                await adb(_db_manager.update_execution, execution_id,
                          status="failed",
                          error_message=f"Row-security enforcement failed: {_rs_exc}")
            except Exception:
                pass
            raise

    try:
        output_dir = _paths.downloads_dir
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = output_dir / f"{execution_id}.parquet"
        loop = asyncio.get_running_loop()

        async def _progress(data):
            await _ws_manager.broadcast_to_user(executed_by, {
                "type": "execution_progress",
                "execution_id": execution_id,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            if data.get("status") in ("completed", "failed"):
                await adb(_db_manager.update_execution, 
                    execution_id,
                    status=data["status"],
                    total_rows=data.get("total_rows", 0),
                    chunks_processed=data.get("chunks_processed", 0),
                    output_file=str(output_file) if data.get("status") == "completed" else None,
                    file_size_bytes=data.get("file_size_bytes", 0),
                    error_message=data.get("error"),
                )

        _last_ts = [0.0]
        def _sync_progress(data: dict):
            now = _time.monotonic()
            # BF-54: Do NOT send completed/failed via fire-and-forget — the outer
            # async code handles those deterministically to avoid a race where the
            # frontend fetches results before the DB is updated.
            if data.get("status") in ("completed", "failed"):
                return
            if now - _last_ts[0] >= 1.0:
                _last_ts[0] = now
                asyncio.run_coroutine_threadsafe(_progress(data), loop)

        import pyarrow as _pa
        import pyarrow.parquet as _pq

        # Phase 139 (Tier 2.1): cross-conn TTFR start (captured in outer scope
        # so the inner closure can compute time-to-first-row at end of execute).
        _ttfr_start_xc = _time.time()

        def _exec_cross(cancel_event=None):
            # BF-421 — see _exec_to_parquet for the rationale.  This is
            # the cross-source orchestrator running on a pool worker
            # thread; the per-side _run_side handlers ALSO get cleanup
            # in their own finally — both layers are needed because the
            # orchestrator may register temp_dirs of its own (combine
            # parquet downloads, etc.).
            from core.duckdb_views import cleanup_temp_downloads as _ctd
            try:
                return _exec_cross_body(cancel_event)
            finally:
                try:
                    _ctd()
                except Exception as _ctd_exc:
                    logger.debug("[bf421] cleanup_temp_downloads raised in _exec_cross: %s", _ctd_exc)

        def _exec_cross_body(cancel_event=None):
            output_file.parent.mkdir(parents=True, exist_ok=True)

            # ── Phase 124-A: Stream each side to temp parquet, combine via DuckDB ──
            # Old approach loaded both sides fully into pandas DataFrames (peak
            # memory = 3-4x data).  New approach streams chunks to disk, then
            # DuckDB reads both parquet files and UNION/JOIN with disk spill.
            import tempfile
            import shutil
            _tmp_dir = Path(tempfile.mkdtemp(prefix="cross_"))

            try:
                return _exec_cross_duckdb(cancel_event, _tmp_dir)
            finally:
                try:
                    shutil.rmtree(_tmp_dir, ignore_errors=True)
                except Exception:
                    pass

        def _exec_cross_duckdb(cancel_event, tmp_dir):
            """DuckDB-based cross-source combine — memory-efficient."""
            import threading as _threading
            _cross_cancel = _threading.Event()  # first failure cancels peer

            # ── BF-106: Proxy pre-download fallback ─────────────────────
            # If corporate proxy blocks DuckDB httpfs (HeadBucket 503/400),
            # pre-download S3 files via boto3 and point DuckDB at local copies.
            _proxy_temp_dirs = []
            try:
                from core.duckdb_views import _is_proxy_active_for_duckdb, _s3_to_local_via_boto3
                if _is_proxy_active_for_duckdb():
                    _sides = [
                        ("primary", primary_config, primary_connection_id),
                        ("secondary", secondary_config, secondary_connection_id),
                    ]
                    for _px_label, _px_config, _px_conn_id in _sides:
                        if not _px_conn_id:
                            continue
                        _s3_files = [
                            f for f in (_px_config.files or [])
                            if isinstance(f, str) and f.startswith("s3://")
                        ]
                        if not _s3_files:
                            continue
                        # Look up connection record for boto3 client
                        _px_conn = _db_manager.get_connection(_px_conn_id)
                        if not _px_conn:
                            logger.warning("BF-106: connection %d not found for %s proxy pre-download",
                                           _px_conn_id, _px_label)
                            continue
                        _px_conn_type = _px_conn.get("connection_type", "")
                        if _px_conn_type not in ("s3",):
                            continue  # Only S3 connections need proxy fallback
                        _px_s3c = make_s3_client_for_conn(
                            {"id": _px_conn_id, "config": _px_conn.get("config", {})}
                        )
                        logger.info("BF-106: Proxy pre-download for %s: %d S3 files",
                                    _px_label, len(_s3_files))
                        # BF-428K — try router-first; fall through to legacy
                        # boto3 predownload when master switch off OR router
                        # can't serve (preserves BF-106 cross-conn behaviour).
                        _px_local = None
                        _px_td = None
                        try:
                            from core.s3_readers.integration import (
                                read_via_router as _rvr,
                                router_result_usable as _rr_usable,
                            )
                            _px_bucket = ""
                            for _u in _s3_files:
                                if isinstance(_u, str) and _u.startswith("s3://"):
                                    _px_bucket = _u[len("s3://"):].split("/", 1)[0]
                                    break
                            _rr = _rvr(
                                s3_client=_px_s3c, bucket=_px_bucket,
                                s3_keys=list(_s3_files),
                                tag=f"execute_api;cross_conn={_px_label}",
                            )
                            # 2026-08-20 — was the ONE bridge without the
                            # silent-truncation guard its two duckdb_views
                            # siblings have had since 2026-08-03: a
                            # row_cap_hit / cancelled result (SUCCESS shape,
                            # files_failed=0, TRUNCATED data) was accepted
                            # and rows went silently missing.  The shared
                            # predicate rejects it → legacy boto3
                            # predownload below serves the COMPLETE files.
                            if _rr_usable(_rr):
                                _px_local = _rr.read_targets
                            elif _rr is not None:
                                logger.warning(
                                    "BF-428K: routed cross-conn result for "
                                    "%s rejected (kind=%s failed=%s "
                                    "row_cap_hit=%s cancelled=%s) — using "
                                    "legacy predownload for a complete read",
                                    _px_label, _rr.output_kind,
                                    _rr.files_failed,
                                    (_rr.extra or {}).get("row_cap_hit"),
                                    (_rr.extra or {}).get("cancelled"))
                                _px_partial_td = (_rr.extra or {}).get("temp_dir")
                                if _px_partial_td:
                                    try:
                                        import shutil as _px_sh
                                        _px_sh.rmtree(_px_partial_td,
                                                      ignore_errors=True)
                                    except Exception:
                                        pass
                        except Exception as _rrexc:
                            logger.debug("BF-428K: router cross-conn bridge "
                                         "skipped (%s) — using legacy", _rrexc)
                        if _px_local is None:
                            _px_local, _px_td = _s3_to_local_via_boto3(_px_s3c, _s3_files)
                        if _px_td:
                            _proxy_temp_dirs.append(_px_td)
                        if _px_local:
                            # Replace S3 paths with local paths in config
                            _px_path_map = dict(zip(_s3_files, _px_local))
                            _px_config.files = [
                                _px_path_map.get(f, f) if isinstance(f, str) else f
                                for f in _px_config.files
                            ]
                            logger.info("BF-106: %s: %d S3 files rewritten to local paths",
                                        _px_label, len(_s3_files))
            except ImportError:
                logger.debug("BF-106: duckdb_views proxy helpers not available")
            except Exception as _proxy_exc:
                logger.warning("BF-106: Proxy pre-download failed (will try direct): %s",
                               _proxy_exc, exc_info=True)

            try:
                return _exec_cross_duckdb_inner(cancel_event, tmp_dir, _cross_cancel)
            finally:
                # Clean up proxy pre-download temp dirs
                for _px_td in _proxy_temp_dirs:
                    try:
                        import shutil as _px_shutil
                        _px_shutil.rmtree(_px_td, ignore_errors=True)
                    except Exception:
                        pass

        def _exec_cross_duckdb_inner(cancel_event, tmp_dir, _cross_cancel):
            """Inner DuckDB cross-source combine — after optional proxy pre-download."""

            # 2026-08-09 — UnboundLocalError fix (ruff F823, confirmed against
            # CPython's own symtable: both names were `local`, not `free`).
            # The semi-join-pushdown block further down REBINDS
            # ``primary_raw_sql`` (raw-SQL wrap) and ``primary_config``
            # (filter injection).  Any assignment anywhere in a function makes
            # the name local for the WHOLE function, so the reads ~100 lines
            # ABOVE those assignments — `bool(primary_raw_sql)` and
            # `getattr(primary_config, ...)` in the pushdown gate — raised
            # UnboundLocalError on EVERY call into this path, unconditionally
            # (nothing between here and there is guarded, and the only caller
            # wraps it in try/finally, not try/except).
            #
            # Shadow into inner names so the reads resolve through the closure
            # and the rebinds stay LOCAL.  `nonlocal` would be wrong: the
            # enclosing scope reuses ``primary_raw_sql``/``primary_config``
            # afterwards for the result-cache key ("the authoritative SQL
            # identity") and for the retry re-dispatch — leaking the
            # IN-list-wrapped SQL there would make the cache key run-specific
            # and double-wrap the SQL on retry.
            _p_raw_sql = primary_raw_sql
            _p_config = primary_config
            # 2026-10-04 -- a SQL-connector PRIMARY is an engine object that
            # carries its own statement; semi-join pushdown swaps in a
            # filtered copy (``with_sql``) rather than wrapping raw_sql.
            _p_engine = primary_engine
            _p_is_connector = bool(getattr(primary_engine,
                                           "_is_sql_connector_engine", False))
            _p_pushed_on_connector = False

            # ── Helper: execute raw SQL with registered views (S3 or local) ──
            def _raw_sql_with_views(engine, config, raw_sql, label):
                """Execute raw SQL after setting up registered views."""
                _has_s3_reg = (hasattr(engine, '_s3_conn_config') and engine._s3_conn_config
                               and hasattr(engine, '_registered_tables') and engine._registered_tables)
                if _has_s3_reg:
                    # Extract partition + non-partition filters from raw SQL WHERE clause
                    # (BF-NON-PARTITION-PRUNE: include col-stats filters too).
                    _xconn_pf = None
                    try:
                        from core.sql_partition_extractor import (
                            extract_combined_filters_for_iceberg,
                        )
                        _xpc_map = {}
                        for _xrt in (engine._registered_tables or []):
                            _xpc = _xrt.get("partition_columns") or []
                            if _xpc:
                                _xpc_map[_xrt["name"]] = _xpc
                        # Empty pc_map is fine — combined helper still extracts non-partition
                        # filters; they'll drive column-stats pruning inside iceberg_reader.
                        _xc_combined = extract_combined_filters_for_iceberg(
                            raw_sql, _xpc_map, dialect="duckdb"
                        )
                        if _xc_combined:
                            _xconn_pf = _xc_combined
                    except Exception as _xpf_err:
                        logger.debug("Cross-conn %s: filter extraction failed (fail-open): %s", label, _xpf_err)

                    con = None
                    try:
                        con, _sql, _, _all_empty, _fstats = setup_registered_views(
                            engine, config,
                            engine._s3_conn_config,
                            engine._registered_tables,
                            getattr(engine, '_s3_bucket', ''),
                            getattr(engine, '_s3_conn_id', None),
                            partition_filters=_xconn_pf,
                            db_manager=_db_manager,    # BF-368
                            raw_sql=raw_sql,           # Phase J: enable raw-SQL JOIN probes
                            execution_id=execution_id, # Phase V: explicit exec_id
                        )
                        if _all_empty:
                            logger.info("Cross-conn %s: all tables empty after pruning", label)
                            return  # 0 rows
                        # BF-262: cross-source watchdog so cancel can abort
                        # mid-execute on either side.
                        _wd_stop = _spawn_duckdb_interrupt_watchdog(
                            con, cancel_event, execution_id,
                        )
                        try:
                            result = con.execute(raw_sql)
                            reader = result.to_arrow_reader(batch_size=engine.chunk_size)
                            for batch in reader:
                                if len(batch) > 0:
                                    yield _pa.Table.from_batches([batch])
                        finally:
                            _wd_stop.set()
                    finally:
                        if con is not None:
                            try:
                                con.close()
                            except Exception:
                                pass
                else:
                    # Local or non-S3 — create views for local files
                    from core.duckdb_factory import duckdb_connection
                    with duckdb_connection() as con:
                        _bp = getattr(engine, 'base_path', '') or ''
                        for f in (config.files or []):
                            name = str(f)
                            for pfx in ('__registered__:', '__local__:', '__materialized__:',
                                        '__federation__:', '__iceberg__:'):
                                if name.startswith(pfx):
                                    name = name[len(pfx):]
                                    break
                            fpath = os.path.join(_bp, name) if _bp and not os.path.isabs(name) else name
                            stem = os.path.splitext(os.path.basename(name))[0]
                            _fesc = fpath.replace('\\', '/')
                            con.execute(f'CREATE OR REPLACE VIEW "{stem}" AS '
                                        f"SELECT * FROM read_parquet('{_fesc}', hive_partitioning=true)")
                            logger.debug("Cross-conn %s: local view '%s' → '%s'", label, stem, _fesc)
                        # Also register __lt__ local tables
                        try:
                            _lts = _db_manager.list_local_tables() if _db_manager else []
                            for _lt in _lts:
                                _lt_dir = _lt.get("storage_path", "")
                                if _lt_dir:
                                    import glob as _g
                                    _lt_pq = _g.glob(os.path.join(_lt_dir, "*.parquet"))
                                    if _lt_pq:
                                        from core.path_utils import to_duckdb_path as _to_ddb_lt
                                        _lt_paths = ", ".join(f"'{_to_ddb_lt(p)}'" for p in _lt_pq)
                                        _lt_vname = f"__lt__{_lt['name']}"
                                        con.execute(f'CREATE OR REPLACE VIEW "{_lt_vname}" AS '
                                                    f"SELECT * FROM read_parquet([{_lt_paths}], "
                                                    f"hive_partitioning=true, union_by_name=true)")
                        except Exception as _lt_exc:
                            logger.debug("Cross-conn %s: local table registration: %s", label, _lt_exc)
                        # BF-262: same interrupt watchdog
                        _wd_stop = _spawn_duckdb_interrupt_watchdog(
                            con, cancel_event, execution_id,
                        )
                        try:
                            result = con.execute(raw_sql)
                            reader = result.to_arrow_reader(batch_size=engine.chunk_size)
                            for batch in reader:
                                if len(batch) > 0:
                                    yield _pa.Table.from_batches([batch])
                        finally:
                            _wd_stop.set()

            # ── Stream side to temp parquet via ParquetWriter ────────────
            def _exec_side_to_parquet(engine, config, label, temp_path, raw_sql=None):
                # BF-XSRC-CONN: SQL-connector wrapper engine — bypass all the
                # parquet/DuckDB routing and stream directly from the connector.
                if getattr(engine, "_is_sql_connector_engine", False):
                    # 2026-10-04 -- THE cross-source side runner (pooled
                    # connector -> connector_to_parquet, bounded memory), the
                    # same one every other surface uses.  The caller's cancel
                    # AND the peer side's failure both reach the connector's
                    # cursor.cancel(), not just a chunk boundary.
                    from core.executors.cross_source_combine import (
                        AnyEvent as _XAny, SideSpec as _XSide,
                        run_side_to_parquet as _x_run_side)
                    logger.info("Cross-conn %s: %s connector side via the "
                                "cross-source side runner", label,
                                engine.connection_type)
                    _x_out = _x_run_side(
                        _XSide(label, connection=engine.connection,
                               sql=engine.sql),
                        str(temp_path),
                        cancel_event=_XAny(cancel_event, _cross_cancel),
                        db_manager=_db_manager, execution_id=execution_id)
                    return _x_out.rows
                elif (raw_sql and getattr(engine, "_s3_conn_config", None)
                        and getattr(engine, "_registered_tables", None)
                        and getattr(engine, "_s3_conn_id", None) is not None):
                    # 2026-10-25 -- an S3 RAW-SQL side runs through THE
                    # cross-source side runner too (the storage road a
                    # custom-SQL dataset over that connection runs:
                    # ``FederationEngine._registered_table_views_for_sql`` binds
                    # ONLY the tables the statement names, the statement's own
                    # WHERE prunes their files, and the result is streamed into
                    # the side parquet in record batches).  The road it
                    # replaces, ``_raw_sql_with_views`` -> ``setup_registered_views``,
                    # handed the connection's WHOLE registered-table list and no
                    # ``referenced_tables``: every table of the connection was
                    # listed, bound and ``count(*)``-ed (every footer opened)
                    # for a statement reading one of them.  Measured at the
                    # wire (tests/test_cross_source_s3_side_bounded_road_2026_10_25.py,
                    # 1 hot table of 3 files + 5 cold tables of 20): 115 round
                    # trips touching 109 objects -> 8 round trips touching 4;
                    # on the owner's connection (fact_tetb 2,688 files +
                    # fact_tetb_wide 2,016 x 1,000 columns ...) this was the
                    # 6.5-minute / 2.9 GB published-API call of 2026-10-24.
                    # The same answer the connector side above gets; the
                    # ``_s3_conn_config`` already carries the resolved
                    # credentials; ``registered_tables`` is what THIS side
                    # exposed (the engine's list, not the stored row's).
                    from core.executors.cross_source_combine import (
                        AnyEvent as _XAny, SideSpec as _XSide,
                        run_side_to_parquet as _x_run_side)
                    _x_conn = {
                        "id": int(engine._s3_conn_id),
                        "connection_type": "s3",
                        "name": str((engine._s3_conn_config or {}).get("name") or ""),
                        "config": {**dict(engine._s3_conn_config or {}),
                                   "registered_tables": list(engine._registered_tables or [])},
                    }
                    logger.info("Cross-conn %s: S3 raw-SQL side via the cross-source "
                                "side runner (connection %s)", label, _x_conn["id"])
                    _x_out = _x_run_side(
                        _XSide(label, connection=_x_conn, sql=raw_sql),
                        str(temp_path),
                        cancel_event=_XAny(cancel_event, _cross_cancel),
                        db_manager=_db_manager, execution_id=execution_id)
                    return _x_out.rows
                elif raw_sql:
                    # BF-120: Use view-aware execution when engine has registered tables
                    _has_reg = ((hasattr(engine, '_registered_tables') and engine._registered_tables)
                                or (hasattr(engine, 'base_path') and engine.base_path))
                    if _has_reg:
                        _gen = _raw_sql_with_views(engine, config, raw_sql, label)
                        logger.info("Cross-conn %s: raw SQL with views", label)
                    else:
                        _gen = engine.execute_raw_duckdb_sql(raw_sql)
                        logger.info("Cross-conn %s: raw SQL bare DuckDB", label)
                else:
                    _use_duckdb = hasattr(engine, '_needs_duckdb') and engine._needs_duckdb(config)
                    _gen = engine.execute_duckdb_query(config) if _use_duckdb else engine.execute_query(config)
                    if _use_duckdb:
                        logger.info("Cross-conn %s: routing through DuckDB (advanced features detected)", label)

                pq_writer = None
                fh = None
                total_rows = 0
                try:
                    fh = open(str(temp_path), "wb")
                    for chunk in _gen:
                        if (cancel_event and cancel_event.is_set()) or _cross_cancel.is_set():
                            raise InterruptedError("Execution cancelled")
                        if isinstance(chunk, _pd.DataFrame):
                            table = _pa.Table.from_pandas(chunk, preserve_index=False)
                        elif isinstance(chunk, _pa.Table):
                            table = chunk
                        else:
                            table = _pa.Table.from_pandas(chunk.to_pandas(), preserve_index=False)

                        if pq_writer is None:
                            pq_writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                        else:
                            try:
                                table = table.cast(pq_writer.schema)
                            except Exception as _cast_exc:
                                logger.warning("Cross-source %s: schema cast failed for chunk "
                                               "(writer schema=%s, chunk schema=%s): %s — "
                                               "closing writer and starting new file",
                                               label, pq_writer.schema, table.schema, _cast_exc)
                                # BF-121: Close current writer and start fresh with new schema
                                pq_writer.close()
                                pq_writer = _pq.ParquetWriter(fh, table.schema, compression="zstd")
                        pq_writer.write_table(table)
                        total_rows += len(table)
                finally:
                    # BF-121: Close generator to release DuckDB connections
                    if hasattr(_gen, 'close'):
                        try:
                            _gen.close()
                        except Exception:
                            pass
                    if pq_writer is not None:
                        pq_writer.close()
                    if fh is not None:
                        fh.close()

                # Ensure valid parquet for 0-row case — use the writer's schema
                # to produce a typed 0-row file (avoids __empty__ column pollution
                # in UNION ALL BY NAME).  If no writer was created (zero chunks),
                # write a single-column placeholder that the combine step will
                # detect and skip.
                if total_rows == 0:
                    if pq_writer is not None:
                        # Writer was opened then closed with 0 rows — rewrite
                        # using the established schema
                        _pq.write_table(
                            _pa.table({f.name: _pa.array([], type=f.type)
                                       for f in pq_writer.schema},
                                      schema=pq_writer.schema),
                            temp_path, compression="zstd"
                        )
                    else:
                        # No chunks at all — write minimal placeholder
                        _pq.write_table(
                            _pa.table({"__empty__": _pa.array([], type=_pa.int32())}),
                            temp_path, compression="zstd"
                        )
                return total_rows

            # ── Execute both sources in parallel ──────────────────────────
            primary_tmp = tmp_dir / "primary.parquet"
            secondary_tmp = tmp_dir / "secondary.parquet"
            _sync_progress({"status": "processing", "step": "executing",
                            "message": "Executing both source queries in parallel"})

            def _run_side(engine, config, label, path, raw_sql=None):
                # BF-421 — cross-source path: each side runs in its own
                # pool worker thread.  Each may register temp_dirs via
                # the boto3 pre-download path (different connection per
                # side).  Without per-thread cleanup_temp_downloads,
                # the registries leak.
                from core.duckdb_views import cleanup_temp_downloads as _ctd
                try:
                    return _exec_side_to_parquet(engine, config, label, path, raw_sql=raw_sql)
                except InterruptedError:
                    # Peer-cancel signal — propagate without re-wrapping
                    # (cross_cancel was set by the side that actually failed).
                    _cross_cancel.set()
                    raise
                except Exception as _side_exc:
                    # BF-521 (2026-05-28): attribute the failure to the
                    # specific side so the user-facing error tells them
                    # which connection is broken.  Without this, the outer
                    # handler emits a generic "Internal Server Error" and
                    # the user can't tell whether to retry, fix their
                    # credentials, or contact admin.  ``from`` preserves
                    # the original exception in the traceback chain.
                    _cross_cancel.set()
                    raise RuntimeError(
                        f"Cross-source {label} side failed "
                        f"({type(_side_exc).__name__}): {_side_exc}.  "
                        f"Verify the {label} connection's credentials "
                        f"and network reachability, then retry."
                    ) from _side_exc
                finally:
                    try:
                        _ctd()
                    except Exception as _ctd_exc:
                        logger.debug("[bf421] cleanup_temp_downloads raised in _run_side(%s): %s", label, _ctd_exc)

            # Phase 139 audit-fix Gap 7 — dynamic JOIN filtering (semi-join pushdown).
            # When the combine is a JOIN and BOTH sides are visual-builder QueryConfigs
            # (no raw SQL), we can:
            #   1. Run the SECONDARY side first into temp parquet
            #   2. Read distinct values of the join key
            #   3. If the count is small (< _SEMI_JOIN_MAX), inject WHERE in (...)
            #      filter into the PRIMARY config so it scans fewer files
            #   4. Run primary with the augmented filter
            # Falls through to parallel execution when:
            #   - combine_mode != "join"
            #   - PRIMARY uses raw_sql (we'd need a SQL rewriter to splice the
            #     IN-filter into the existing WHERE clause — deferred)
            #   - secondary distinct count exceeds threshold
            #   - left_on / right_on missing
            #
            # BF-400: SECONDARY using raw_sql is FINE.  The secondary always
            # runs to a temp parquet first (line ~4710), and we extract
            # DISTINCT keys from that parquet — doesn't matter whether the
            # secondary was built visually or written as raw SQL.  Previously
            # we skipped this case unnecessarily, which made every PV
            # cross-source view (sql_file source) miss the optimization.
            _SEMI_JOIN_MAX_DISTINCT = 10_000
            _used_semi_join = False
            # BF-536 (2026-05-28): allow semi-join pushdown even when the
            # PRIMARY side uses raw_sql.  The previous guard (`and not
            # primary_raw_sql`) was over-cautious — primary raw_sql still
            # flows through DuckDB's parser, and DuckDB happily ANDs an
            # injected `WHERE col IN (...)` onto a raw query as long as
            # we wrap it as a subquery.  Without this fix every PV
            # cross-source view backed by a SQL file (the common case)
            # missed the optimisation and dragged the full primary table
            # across S3 even when the secondary had 10 rows.
            #
            # For raw_sql primary we wrap as ``SELECT * FROM (raw_sql) _p
            # WHERE col IN (...)`` — the IN clauses go on the OUTER scan
            # so primary's existing WHERE / GROUP BY structure is
            # preserved.  The wrap is applied later in the IN-filter
            # injection path; the gate here just lets us GET there.
            _used_raw_sql_primary_path = bool(_p_raw_sql)
            # STRATEGIC REDESIGN 2026-08-04 — correctness gate stated ONCE in
            # core.executors.cross_source_combine.semi_join_pushdown_allowed.
            # The old gate excluded only CROSS, so LEFT/FULL OUTER joins had
            # their unmatched primary rows destroyed by the pushdown
            # (verified: 3 rows → 1), and an OR-logic primary config was
            # WIDENED by the appended IN filter instead of narrowed.
            from core.executors.cross_source_combine import semi_join_pushdown_allowed
            _sj_allowed, _sj_reason = semi_join_pushdown_allowed(
                join_config,
                primary_filter_logic=getattr(_p_config, "filter_logic", "AND"),
                primary_has_filters=bool(getattr(_p_config, "filters", None)),
                primary_is_raw_sql=bool(_p_raw_sql) or _p_is_connector,
            )
            if combine_mode == "join" and join_config and not _sj_allowed:
                logger.info("[semi-join-pushdown] skipped (%s) — running both sides in parallel",
                            _sj_reason)
            if (combine_mode == "join" and join_config and _sj_allowed):
                _left_on = join_config.get("left_on")
                _right_on = join_config.get("right_on")
                if isinstance(_left_on, str):
                    _left_on = [_left_on]
                if isinstance(_right_on, str):
                    _right_on = [_right_on]
                # Multi-key joins via per-column IN filters (one per key).
                # For 2-key join on (region, year), inject
                # WHERE region IN (...) AND year IN (...) on the primary
                # side. Over-approximation but a strict superset of the
                # join result, so the final DuckDB JOIN trims correctly.
                # BF-536: cap raised from 4 → 8 keys to cover composite-key
                # tables (year+month+region+product is common in financial
                # warehouses).
                if (_left_on and _right_on and len(_left_on) == len(_right_on)
                        and len(_left_on) <= 8):
                    try:
                        _sync_progress({"status": "processing", "step": "executing",
                                        "message": f"Cross-source: running secondary first to derive {len(_left_on)}-key JOIN filter"})
                        _s_rows = _run_side(secondary_engine, secondary_config,
                                             "secondary", secondary_tmp,
                                             raw_sql=secondary_raw_sql)
                        from core.duckdb_factory import duckdb_connection as _ddb_sj
                        _s_path_esc = str(secondary_tmp).replace("'", "''")
                        # Read distinct values for each right_on column separately
                        _augmented_filters: list = []
                        _ok = True
                        with _ddb_sj() as _sj_con:
                            for _idx, (_lk, _rk) in enumerate(zip(_left_on, _right_on)):
                                _r_col_esc = _rk.replace('"', '""')
                                try:
                                    _distinct_rows = _sj_con.execute(
                                        f'SELECT DISTINCT "{_r_col_esc}" FROM read_parquet(\'{_s_path_esc}\') '
                                        f'WHERE "{_r_col_esc}" IS NOT NULL '
                                        f'LIMIT {_SEMI_JOIN_MAX_DISTINCT + 1}'
                                    ).fetchall()
                                except Exception as _col_err:
                                    logger.debug("[semi-join-pushdown] distinct fetch failed for col %s: %s",
                                                 _rk, _col_err)
                                    _ok = False
                                    break
                                if not (0 < len(_distinct_rows) <= _SEMI_JOIN_MAX_DISTINCT):
                                    logger.info(
                                        "[semi-join-pushdown] col %s has %d distincts (cap=%d) — abort multi-key push",
                                        _rk, len(_distinct_rows), _SEMI_JOIN_MAX_DISTINCT,
                                    )
                                    _ok = False
                                    break
                                _distinct_vals = [r[0] for r in _distinct_rows]
                                _augmented_filters.append({
                                    "col":      _lk,
                                    "op":       "in",
                                    "val":      _distinct_vals,
                                    "operator": "in",
                                    "value":    _distinct_vals,
                                    "_semi_join_pushdown": True,
                                })
                        if _ok and _augmented_filters:
                            try:
                                if _p_is_connector:
                                    # The primary's own engine and grammar:
                                    # its identifier quoting, a letter-first
                                    # alias Oracle accepts, and only literals
                                    # every engine reads the same way (ints,
                                    # plain strings) -- else no pushdown.
                                    from core.executors.cross_source_combine import (
                                        semi_join_wrap_sql as _x_sj_wrap)
                                    _x_wrapped = _x_sj_wrap(
                                        primary_engine.sql,
                                        primary_engine.connection_type,
                                        [(f["col"], f.get("val") or [])
                                         for f in _augmented_filters])
                                    if _x_wrapped:
                                        _p_engine = primary_engine.with_sql(_x_wrapped)
                                        _used_semi_join = True
                                        _p_pushed_on_connector = True
                                        logger.info(
                                            "[semi-join-pushdown] %s primary "
                                            "filtered to %d-key secondary "
                                            "key set", primary_engine.connection_type,
                                            len(_augmented_filters))
                                elif _used_raw_sql_primary_path:
                                    # BF-536: wrap raw_sql so the IN clauses
                                    # land on the outer scan without
                                    # disturbing primary's existing
                                    # WHERE/GROUP BY/ORDER BY structure.
                                    def _esc_val(v):
                                        if v is None:
                                            return "NULL"
                                        if isinstance(v, (int, float)):
                                            return str(v)
                                        # Default: quote as SQL string with
                                        # single-quote doubling.
                                        return "'" + str(v).replace("'", "''") + "'"
                                    _where_parts = []
                                    for f in _augmented_filters:
                                        c = f["col"].replace('"', '""')
                                        vals = f.get("val") or []
                                        if not vals:
                                            continue
                                        _in_list = ", ".join(_esc_val(v) for v in vals)
                                        _where_parts.append(
                                            f'"{c}" IN ({_in_list})'
                                        )
                                    if _where_parts:
                                        _p_raw_sql = (
                                            f"SELECT * FROM (\n{_p_raw_sql}\n) _qs_p\n"
                                            f"WHERE " + " AND ".join(_where_parts)
                                        )
                                        _used_semi_join = True
                                        logger.info(
                                            "[semi-join-pushdown] BF-536 raw_sql primary wrapped with "
                                            "%d-key IN filter (%s)",
                                            len(_where_parts),
                                            ", ".join(f["col"] for f in _augmented_filters),
                                        )
                                else:
                                    _existing_filters = list(getattr(_p_config, "filters", None) or [])
                                    _existing_filters.extend(_augmented_filters)
                                    if hasattr(_p_config, "model_copy"):
                                        _p_config = _p_config.model_copy(update={"filters": _existing_filters})
                                    else:
                                        _p_config.filters = _existing_filters  # type: ignore[attr-defined]
                                    _used_semi_join = True
                                    logger.info(
                                        "[semi-join-pushdown] Injected %d-key IN filter (%s) — primary should scan fewer files",
                                        len(_augmented_filters),
                                        ", ".join(f["col"] for f in _augmented_filters),
                                    )
                                if _used_semi_join:
                                    _sync_progress({"status": "processing", "step": "executing",
                                                    "message": f"Cross-source: pushing {len(_augmented_filters)}-key semi-join filter to primary"})
                            except Exception as _aug_err:
                                logger.debug("[semi-join-pushdown] filter injection failed: %s", _aug_err)
                    except Exception as _sj_err:
                        logger.warning(
                            "[semi-join-pushdown] failed (%s) — falling back to parallel scan",
                            _sj_err,
                        )

            from concurrent.futures import ThreadPoolExecutor, wait, FIRST_EXCEPTION
            if _used_semi_join:
                # Secondary already ran — only need primary
                try:
                    _p_rows = _run_side(_p_engine, _p_config, "primary",
                                        primary_tmp, raw_sql=_p_raw_sql)
                except InterruptedError:
                    raise
                except Exception as _sj_run_exc:
                    if not _p_pushed_on_connector or (
                            cancel_event and cancel_event.is_set()):
                        raise
                    # The pushdown is an OPTIMISATION: a primary engine that
                    # rejects the filtered statement runs it unfiltered.
                    logger.warning(
                        "[semi-join-pushdown] primary engine rejected the "
                        "filtered statement (%s) -- running it unfiltered",
                        _sj_run_exc)
                    _cross_cancel.clear()
                    _p_rows = _run_side(primary_engine, _p_config, "primary",
                                        primary_tmp, raw_sql=_p_raw_sql)
            else:
                # BF-594: same hang-class fix as BF-590 dispatcher/for_each.
                # Previously `with ThreadPoolExecutor(...) as _pool:` would
                # block ``__exit__`` on shutdown(wait=True), pinning the
                # entire cross-source execution on a stuck side even after
                # cross_cancel was set.  Manage pool lifetime explicitly
                # so the error path can shutdown with cancel_futures=True.
                _pool = ThreadPoolExecutor(max_workers=2)
                _hung_on_error = False
                try:
                    _fut_p = _pool.submit(_run_side, primary_engine, _p_config, "primary", primary_tmp, raw_sql=_p_raw_sql)
                    _fut_s = _pool.submit(_run_side, secondary_engine, secondary_config, "secondary", secondary_tmp, raw_sql=secondary_raw_sql)
                    _done, _not_done = wait([_fut_p, _fut_s], return_when=FIRST_EXCEPTION)
                    # Surface the real root-cause error (not InterruptedError from peer)
                    for _f in _done:
                        exc = _f.exception()
                        if exc is not None and not isinstance(exc, InterruptedError):
                            _hung_on_error = True
                            # Wait for peer to finish (cross_cancel already set).
                            # Bounded by 30s — past that the pool shutdown's
                            # cancel_futures will drop the still-pending tasks.
                            for _nd in _not_done:
                                try:
                                    _nd.result(timeout=30)
                                except Exception:
                                    pass
                            raise exc
                    _p_rows = _fut_p.result()
                    _s_rows = _fut_s.result()
                finally:
                    try:
                        # Cancel-and-bail on error; normal completion drains.
                        if _hung_on_error:
                            _pool.shutdown(wait=False, cancel_futures=True)
                        else:
                            _pool.shutdown(wait=True)
                    except Exception:
                        pass
            logger.info("Cross-source %s: primary=%d, secondary=%d rows",
                        "semi-join-pushdown" if _used_semi_join else "parallel",
                        _p_rows, _s_rows)
            try:
                from core.metrics import qs_files_skipped_total
                qs_files_skipped_total.labels(source="cross_conn",
                                               reason="semi_join_pushdown" if _used_semi_join else "parallel").inc(0)
            except Exception:
                pass

            # ── Combine — THE cross-source combine (2026-10-04) ──────────
            # core.executors.cross_source_combine.combine_sides: the ONE
            # combine every surface uses (DuckDB, spilling), the ONE join
            # vocabulary ("outer" == "full", which this path used to
            # refuse), key-type harmonisation disclosed rather than a binder
            # error, and the BF-517 join-health verdict computed there.
            _sync_progress({"status": "processing", "step": "combining",
                            "message": f"Combining via {combine_mode.upper()}"})
            from core.executors.cross_source_combine import (
                combine_sides as _x_combine, combine_spec as _x_spec)
            _x_outcome = _x_combine(
                str(primary_tmp), str(secondary_tmp), str(output_file),
                _x_spec(combine_mode, join_config or {}),
                # unaliased expressions are named by their own text, per side
                side_sql=(primary_raw_sql, secondary_raw_sql))
            if _x_outcome.expression_tags:
                logger.info("[cross-source] columns named by their expression: %s",
                            "; ".join(_x_outcome.expression_tags))
            if _x_outcome.type_mismatches:
                logger.warning(
                    "[union-type-coercion] Cross-connection UNION has type "
                    "mismatches (DuckDB will auto-promote): %s",
                    ", ".join(_x_outcome.type_mismatches))
            _x_outcome.primary_rows, _x_outcome.secondary_rows = _p_rows, _s_rows
            if _used_semi_join:
                _x_outcome.semi_join_pushdown = "applied"
            total_rows = _x_outcome.total_rows
            file_size = output_file.stat().st_size
            join_health = _x_outcome.join_health
            join_health_detail = _x_outcome.join_health_detail
            if join_health != "ok":
                logger.warning("[bf-517 join-health] %s (join_config=%s)",
                               join_health_detail, join_config)

            # Phase 139 (Tier 2.1): cross-conn streaming — broadcast first 1000
            # rows immediately so the frontend grid renders BEFORE the user
            # waits on the full /results poll.  Fail-OPEN.
            try:
                _stream_cap = 1000
                _preview_pf = _pq.ParquetFile(str(output_file))
                _preview_table = _preview_pf.read_row_group(0) if _preview_pf.num_row_groups else None
                if _preview_table is not None and len(_preview_table):
                    _slice = _preview_table.slice(0, min(_stream_cap, len(_preview_table)))
                    _cols_payload = [
                        {"name": f.name, "type": str(f.type)} for f in _slice.schema
                    ]
                    _rows_payload = _slice.to_pylist()
                    try:
                        from core.json_utils import sanitize_for_json as _xsani
                        _rows_payload = _xsani(_rows_payload)
                    except Exception:
                        pass

                    async def _ship_xchunk():
                        await _ws_manager.broadcast_to_user(executed_by, {
                            "type":         "execution_chunk",
                            "execution_id": execution_id,
                            "rows":         _rows_payload,
                            "columns":      _cols_payload,
                            "total_so_far": len(_rows_payload),
                            "timestamp":    datetime.now(timezone.utc).isoformat(),
                        })
                    try:
                        asyncio.run_coroutine_threadsafe(_ship_xchunk(), loop)
                    except Exception:
                        pass
                    # TTFR for cross-conn ≈ end-to-end (combine completed)
                    try:
                        from core.metrics import record_time_to_first_row
                        record_time_to_first_row("cross_conn", _time.time() - _ttfr_start_xc)
                    except Exception:
                        pass
            except Exception as _xstream_exc:
                logger.debug("Cross-conn stream broadcast skipped: %s", _xstream_exc)

            return {"total_rows": total_rows, "chunks_processed": 2,
                    "file_size_bytes": file_size, "status": "completed",
                    # 2026-10-04 -- what the combine did, in the one
                    # disclosure vocabulary (rows per side, key casts, type
                    # promotions, pushdown) -- so a dropped or empty side
                    # can never read as a whole answer.
                    "cross_source": _x_outcome.disclosure(),
                    # BF-517 — surfaces broken-join-predicate suspicion to
                    # operators / future UI badge.  "ok" on the happy path;
                    # "suspicious_empty" + detail message when both inputs
                    # had rows but the join collapsed to 0.
                    "join_health": join_health,
                    "join_health_detail": join_health_detail}

        try:
            _wp_record = await _pool.submit(
                _work_type, _exec_cross,
                execution_id=execution_id, username=executed_by,
            )
        except _QueueFull:
            # BF-589: was sync — freezes event loop.
            await adb(_db_manager.update_execution, execution_id, status="failed",
                error_message="Server queue full — too many concurrent queries. Try again shortly.")
            await _ws_manager.broadcast_to_user(executed_by, {"type": "execution_failed", "execution_id": execution_id,
                "error": "Server queue full", "timestamp": datetime.now(timezone.utc).isoformat()})
            return

        await adb(_db_manager.update_execution, execution_id, status="processing")  # BF-589
        await _ws_manager.broadcast_to_user(executed_by, {
            "type": "execution_started",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        # BF-250: heartbeat broadcasts elapsed time every 15 s during the
        # blocking engine call so silent COUNT(DISTINCT) / large scans don't
        # leave the user staring at an unchanging spinner.
        stats = await _await_with_heartbeat(
            _wp_record.future,
            execution_id=execution_id,
            executed_by=executed_by,
            ws_manager=_ws_manager,
        )
        stats = _sanitize_for_json(stats)  # BF-100: NaN/Infinity → None

        # BF-517 follow-up (2026-05-28): stash the join-health diagnostic
        # in files_metadata so the UI (which polls the execution record)
        # can render the "suspicious_empty" badge.  Without this, the
        # signal computed inside _exec_cross dies at the worker boundary
        # and the user can't see why their JOIN returned 0 rows.
        _xs_files_meta: Dict[str, Any] = {}
        if stats.get("cross_source"):
            _xs_files_meta["cross_source"] = stats["cross_source"]
        _xs_jh = stats.get("join_health")
        if _xs_jh and _xs_jh != "ok":
            _xs_files_meta["join_health"] = _xs_jh
            _xs_jh_detail = stats.get("join_health_detail")
            if _xs_jh_detail:
                _xs_files_meta["join_health_detail"] = _xs_jh_detail

        _update_kwargs = dict(
            status="completed",
            # 2026-09-27 -- two sources combined in-process (core/engine_attribution.py)
            engine="cross_source",
            total_rows=stats.get("total_rows", 0),
            chunks_processed=stats.get("chunks_processed", 0),
            output_file=str(output_file),
            file_size_bytes=stats.get("file_size_bytes", 0),
        )
        if _xs_files_meta:
            _update_kwargs["files_metadata"] = _xs_files_meta
        # BF-591: cross-source path was making sync DB calls on the event loop.
        # Mirror of BF-589's SQL-connector fix.  Each sync call here froze the
        # loop ~5-50ms; the completion + create_download_file + increment_count
        # chain compounded to ~200ms blocked time per completion event.
        await adb(_db_manager.update_execution, execution_id, **_update_kwargs)

        # Phase 155/156 -- brain completion hooks for the cross-source
        # path.  ``primary_raw_sql`` is the authoritative SQL identity
        # for the primary leg; pass it to seed hash + route history.
        _phase156_completion_hooks(
            raw_sql=primary_raw_sql,
            query_config_dict=query_config_dict,
            output_file_path=str(output_file) if output_file.exists() else None,
            stats=stats,
            query_t0_monotonic=_phase156_query_t0,
            db_manager=_db_manager,
            # 2026-08-20 -- principal scope for the brain result cache.
            username=executed_by,
        )

        file_id = str(uuid.uuid4())
        await adb(
            _db_manager.create_download_file,
            file_id=file_id,
            execution_id=execution_id,
            filename=f"cross_result_{execution_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=stats["file_size_bytes"],
            expires_at=_download_expires_at(),
        )
        if query_id:
            await adb(_db_manager.increment_execution_count, query_id)

        # Store in query result cache — skipped when cache_strategy == "bypass"
        if cache_strategy != "bypass":
            try:
                from core.query_cache import make_cache_key as _mk_ck_x, store_result as _store_res_x, rls_user_scope as _rls_us_x
                # BF-235: include both raw_sql values when building fallback key
                # Round 5: user_scope for cross-source result cache too.
                _raw_x = (primary_raw_sql or "") + "||" + (secondary_raw_sql or "")
                _ck_x = cache_key or _mk_ck_x(
                    query_config_dict or {},
                    raw_sql=_raw_x if _raw_x.strip("|") else None,
                    user_scope=_rls_us_x(user_ctx),
                )
                if (_ck_x and output_file.exists()
                        and (not _key_may_be_shared(cache_key, cache_key_scope,
                                                    lambda: _rls_us_x(user_ctx))
                             or await _shared_store_confirmed(execution_id))):
                    _store_res_x(_ck_x, output_file, query_config_dict or {},
                                 row_count=stats.get("total_rows", 0), copy=False,
                                 ttl_seconds=_cache_cfg.ttl_seconds)
            except Exception as exc:
                logger.warning("Recoverable error caching cross-query result: %s", exc, exc_info=True)

        await _ws_manager.broadcast_to_user(executed_by, _with_engine({
            "type": "execution_completed",
            "execution_id": execution_id,
            "file_id": file_id,
            "stats": stats,
            "combine_mode": combine_mode,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }, "cross_source"))
        logger.info(f"Cross-connection query completed: {execution_id} ({combine_mode})")

    except (asyncio.CancelledError, InterruptedError) as e:
        logger.info(f"Cross-connection query cancelled: {execution_id}")
        # BF-591: async DB on cancel path.
        cur = await adb(_db_manager.get_execution, execution_id)
        if cur and cur.get("status") not in ("cancelled",):
            await adb(_db_manager.update_execution, execution_id,
                      status="cancelled",
                      error_message="Cancelled by user")
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        await _ws_manager.broadcast_to_user(executed_by, {
            "type": "execution_cancelled",
            "execution_id": execution_id,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        if isinstance(e, asyncio.CancelledError):
            raise

    except Exception as e:
        # 2026-10-10: the same one renderer as the single-connector lane.
        from core.connectors.base import describe_source_failure as _describe_failure
        _safe_e = _sanitize(_describe_failure(e, "sql"))
        logger.error(f"Error in cross-connection query {execution_id}: {_safe_e}", exc_info=True)
        # Phase 120/125: Self-Healing Agent — cross-query failure hook + auto-retry
        _agent_result_xq = None
        try:
            from core.agents import get_orchestrator as _get_orch_xq
            _orch_xq = _get_orch_xq()
            if _orch_xq and _orch_xq.enabled:
                _agent_result_xq = _orch_xq.handle_event("query_failed", {
                    "execution_id": execution_id,
                    "error_message": _safe_e,
                    "error_type": type(e).__name__,
                    "connection_id": (query_config_dict or {}).get("connection_id"),
                    "query_config": query_config_dict or {},
                    "retry_count": (query_config_dict or {}).get("_agent_retry_count", 0),
                })
                if _should_agent_auto_retry(_agent_result_xq):
                    _strategy_xq = _agent_result_xq.get("strategy", "")
                    _retry_count_xq = _agent_result_xq.get("retry_count", 1)
                    logger.info("Agent auto-retrying cross-query %s (strategy=%s, attempt=%d)",
                                execution_id, _strategy_xq, _retry_count_xq)
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "agent_retrying",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strategy_xq,
                        "reason": _agent_result_xq.get("reason"),
                        "retry_count": _retry_count_xq,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    })
                    await adb(_db_manager.update_execution, execution_id,
                              status="retrying",
                              error_message=f"Agent retry: {_strategy_xq}")
                    _modified_xq = await _apply_agent_fix(
                        _strategy_xq, _agent_result_xq.get("retry_params") or {},
                        query_config_dict or {}, primary_config, _retry_count_xq,
                        user_ctx=user_ctx,
                    )
                    # BF-591: replace deprecated asyncio.get_event_loop().create_task
                    # with asyncio.create_task; track strongly so Python issue
                    # #88831 cannot GC the in-flight retry mid-await.  Also
                    # re-acquire a slot before the retry so the inner finally's
                    # _release_user_slot does not under-count the user.  We
                    # use the existing slot path with execution_id so cancel
                    # is wired through.
                    try:
                        _xq_slot_ok, _xq_slot_reason, _ = await _acquire_user_slot(
                            executed_by,
                            _qe_cfg.max_concurrent_per_user if _qe_cfg else 50,
                            _qe_cfg.max_queue_size if _qe_cfg else 100,
                            _qe_cfg.queue_wait_timeout_seconds if _qe_cfg else 60.0,
                            execution_id=execution_id,
                        )
                    except Exception:
                        _xq_slot_ok = False
                    if _xq_slot_ok:
                        _track_bg_task(
                            execute_cross_query_background(
                                execution_id, primary_engine, primary_config,
                                secondary_engine, secondary_config, combine_mode,
                                join_config, query_id, executed_by, cache_key,
                                cache_strategy, _modified_xq, work_type,
                                primary_raw_sql, secondary_raw_sql,
                                primary_connection_id=primary_connection_id,
                                secondary_connection_id=secondary_connection_id,
                            )
                        )
                        return  # Skip failure path — retry dispatched
                    # BF-593: same actionable-hint surface as single-source/SQL.
                    try:
                        await _ws_manager.broadcast_to_user(executed_by, {
                            "type": "agent_suggestion",
                            "execution_id": execution_id,
                            "agent": "query_resilience",
                            "strategy": _strategy_xq,
                            "reason": ("Auto-retry queued but server is at "
                                       "concurrency cap — retry manually."),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "username": executed_by,
                        })
                    except Exception:
                        pass
                elif _agent_result_xq and (_agent_result_xq.get("retrying") or _agent_result_xq.get("action") == "notify"):
                    # BF-242: also accept NOTIFY_USER shape
                    _strat_xq = _agent_result_xq.get("strategy") or (_agent_result_xq.get("metadata") or {}).get("strategy")
                    _rsn_xq = _agent_result_xq.get("reason") or (_agent_result_xq.get("metadata") or {}).get("description")
                    await _ws_manager.broadcast_to_user(executed_by, {
                        "type": "agent_suggestion",
                        "execution_id": execution_id,
                        "agent": "query_resilience",
                        "strategy": _strat_xq,
                        "reason": _rsn_xq,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "username": executed_by,
                    })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        # 2026-10-07: same one answer as every other failure road.
        from core.agents.inline_suggestion import suggestion_for_failure as _sugg_for_xq
        _inline_sugg_xq = await asyncio.to_thread(
            _sugg_for_xq, _safe_e, type(e).__name__,
            db_manager=_db_manager, agent_result=_agent_result_xq)
        # BF-591: async DB on failure path.
        await adb(_db_manager.update_execution, execution_id,
                  status="failed", error_message=_safe_e)
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        _failed_msg_xq = {
            "type": "execution_failed",
            "execution_id": execution_id,
            "error": _safe_e,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if _inline_sugg_xq:
            _failed_msg_xq["agent_suggestion"] = _inline_sugg_xq
            await _record_failure_suggestion(execution_id, _inline_sugg_xq)
        await _ws_manager.broadcast_to_user(executed_by, _failed_msg_xq)

    finally:
        # Clear checkpoint — execution finished (Phase 41)
        # 2026-10-07: submitted to the checkpoint lane, never inline on the loop.
        from core.checkpoint import mark_completed_nowait as _cp_done_cross
        _cp_done_cross(execution_id)
        # BF-584: release slot + wake queued waiter.
        _release_user_slot(executed_by)


async def _run_query_and_signal(execution_id: str, query_config, query_id,
                                 active_engine, executed_by: str, raw_sql,
                                 cache_strategy: str, cache_key: Optional[str],
                                 query_config_dict: Optional[dict] = None,
                                 fallback_output_file: Optional[str] = None,
                                 user_ctx: Optional[Dict[str, Any]] = None,
                                 rls_connection_id: Optional[int] = None,
                                 cache_key_scope: Any = _SCOPE_UNSET) -> None:
    """Wrapper around execute_query_background that signals _inflight_queries on completion.

    Phase 131 deep-dive #13 (round 4 follow-up): plumbs user_ctx +
    rls_connection_id so structured single-query path applies RLS
    (raw_sql=None case — engine builds SQL internally; without these
    parameters, secure_sql is never called).
    """
    try:
        await execute_query_background(
            execution_id, query_config, query_id, active_engine,
            executed_by=executed_by, raw_sql=raw_sql, cache_strategy=cache_strategy,
            cache_key=cache_key, query_config_dict=query_config_dict,
            fallback_output_file=fallback_output_file,
            user_ctx=user_ctx, rls_connection_id=rls_connection_id,
            cache_key_scope=cache_key_scope,
        )
    finally:
        # Clear checkpoint — execution finished regardless of outcome (Phase 41)
        # 2026-10-07: submitted to the checkpoint lane, never inline on the loop.
        from core.checkpoint import mark_completed_nowait as _cp_done
        _cp_done(execution_id)
        if cache_key and cache_key in _inflight_queries:
            _, event = _inflight_queries.pop(cache_key, (None, None))
            if event:
                event.set()


# ── Endpoints ──────────────────────────────────────────────────────────────


@router.get("/api/executions/active")
async def list_active_executions(_user: dict = Depends(get_current_user)):
    """BF-392: list the current user's in-flight executions so the UI can
    re-attach after backend restarts, network blips, or any state loss.

    Returns a list of executions in ``processing`` / ``pending`` /
    ``running`` state owned by this user, newest first.  The frontend
    uses this as a fallback when its localStorage executionId is stale.
    """
    username = (_user or {}).get("username", "guest")
    try:
        # list_executions takes a SINGLE status — query each active status,
        # then merge.  Cap each call at 20 so worst case = 60 rows.
        all_rows = []
        for st in ("processing", "pending", "running"):
            try:
                rows = await adb(_db_manager.list_executions,
                                  limit=20, executed_by=username, status=st)
                all_rows.extend(rows or [])
            except Exception as inner:
                logger.debug("list_executions(status=%s) failed: %s", st, inner)
    except Exception as exc:
        logger.warning("list_active_executions failed: %s", exc)
        return {"executions": []}

    # Sort newest-first across the merged set
    def _ts(r):
        sa = r.get("started_at")
        if hasattr(sa, "timestamp"):
            try:
                return sa.timestamp()
            except Exception:
                return 0
        return 0
    all_rows.sort(key=_ts, reverse=True)

    out = []
    for r in all_rows[:20]:
        sa = r.get("started_at")
        out.append({
            "execution_id": r.get("execution_id") or r.get("id"),
            "status":       r.get("status"),
            "started_at":   sa.isoformat() if hasattr(sa, "isoformat") else str(sa or ""),
            "query_id":     r.get("query_id"),
        })
    return {"executions": out}


def _iso_or_none(value):
    """A timestamp as ISO text whether the store gave a datetime or a string."""
    if not value:
        return None
    return value.isoformat() if hasattr(value, "isoformat") else str(value)


async def _status_before_row_exists(execution_id: str, user: dict) -> dict:
    """Status for an id with no execution row.

    A finished download may already carry it; its OWN ``created_by`` decides
    who sees the file handle (the execution row that would normally decide
    is exactly what is missing).  Anything else is 404: the submit routes
    write the row BEFORE they answer, so a missing row is not "pending" --
    answering "pending" left a mistyped id polling forever.
    """
    downloads = await adb(_db_manager.list_download_files, status="available",
                          limit=500, offset=0)
    match = next((d for d in downloads or [] if d.get("execution_id") == execution_id), None)
    if match:
        from core.roles import is_read_like as _is_read_like_dl
        _owner = match.get("created_by") or ""
        _caller = (user or {}).get("username") or ""
        if _is_read_like_dl(user) or _owner == _caller:
            return {"execution_id": execution_id, "status": "completed",
                    "file_id": match["file_id"], "filename": match["filename"],
                    "total_rows": None}
    raise HTTPException(status_code=404, detail="Execution not found")


@router.get("/api/executions/{execution_id}/status")
async def get_execution_status(execution_id: str,
                               _user: dict = Depends(require_execution_read_access)):
    """BF-381: WS-drop recovery — return current execution state so the
    frontend can re-attach when its WebSocket disconnects mid-query.

    Returns: {execution_id, status, total_rows, error_message,
              started_at, completed_at, stage, files_total, files_done,
              message, log_tail, output_file, stage_history}

    Frontend usage:
      - On WS disconnect, poll this every 2s with the in-flight
        execution_id.
      - When status ∈ ('completed', 'failed', 'cancelled'), stop polling
        and rebuild result UI from the response (use existing
        /results endpoint to fetch the data).
      - When status == 'processing', show the latest stage/message so
        the user knows the query is still alive.
    """
    # 2026-09-24: this path was registered TWICE (here and queries_api).  The
    # other copy won, so this payload -- stage_history, brain_diagnostics,
    # engine_meta, live stage -- never reached the UI panels built on it, and
    # the two copies disagreed on ownership.  One route now, carrying the
    # other copy's two behaviours: a share/embed viewer may poll the
    # execution IT launched, and a row not yet persisted reads "pending".
    execution = await adb(_db_manager.get_execution, execution_id)
    if not execution:
        return await _status_before_row_exists(execution_id, _user)
    assert_execution_visible_to_token(_user, execution)
    # SECURITY 2026-08-22: this route bound ``_user`` and never read it, so it
    # returned another user's output_file / error_message / stage_history /
    # brain_diagnostics for any guessed execution_id.  Its immediate siblings
    # /file-info, /workers and /column-stats all enforce the SAME per-user
    # ownership rule; this one was the odd one out.  Apply it here too.
    # 2026-09-24: THE execution-read rule (data_grid_api), not a local copy.
    # The copies here passed an execution with NO owner to every signed-in
    # user, while the canonical rule refuses it -- one question, two answers.
    # Refused as 404, the contract this route has served: an id someone else
    # owns reads exactly like one that does not exist.
    try:
        _enforce_execution_ownership(execution_id, _user, record=execution)
    except HTTPException as _own_exc:
        if _own_exc.status_code == 403:
            raise HTTPException(status_code=404, detail="Execution not found")
        raise
    # Pull live stage info from execution_stage registry — survives WS
    # disconnect; no broadcast needed.
    stage_info: Dict[str, Any] = {}
    try:
        from core.execution_stage import get_snapshot as _stg_get
        stage_info = _stg_get(execution_id) or {}
    except Exception:
        stage_info = {}
    # 2026-07-15 live-timeline resume — additive field: full per-stage
    # history (completed stages + in-flight pseudo-record) so the frontend
    # ExecutionLiveTimeline can seed/reconcile its "completed steps" list
    # after a remount or a WS drop instead of starting memoryless.
    stage_history: list = []
    try:
        from core.execution_stage import get_stage_history as _stg_hist
        stage_history = _stg_hist(execution_id) or []
    except Exception:
        stage_history = []
    # 2026-07-15 "Why N files?" — per-table brain diagnostics.  Live source
    # is the stage-tracker extras (get_snapshot copies them); once the
    # execution finishes the registry entry is dropped, so fall back to the
    # PERSISTED stage_history.extras in files_metadata below.  Fail-soft:
    # missing → None and the panel simply doesn't render.
    brain_diagnostics: Dict[str, Any] = {}
    try:
        from core.brain_diagnostics import extract_brain_diagnostics as _bd_x
        brain_diagnostics = _bd_x(stage_info.get("extras"))
    except Exception:
        brain_diagnostics = {}
    # BF-389: extract engine metadata (multi-worker/cache info) from
    # files_metadata so the polling fallback can drive the badge UI even
    # when the original WS event got dropped.
    engine_meta = None
    # 2026-10-07: the failed run's stored agent suggestion (see
    # _record_failure_suggestion) -- served as stored, never re-classified.
    agent_suggestion = None
    try:
        fm = execution.get("files_metadata")
        if isinstance(fm, str):
            import json as _json_em
            try:
                fm = _json_em.loads(fm)
            except Exception:
                fm = None
        if isinstance(fm, dict):
            engine_meta = fm.get("__engine_meta__")
            if execution.get("status") == "failed" \
                    and isinstance(fm.get("agent_suggestion"), dict):
                agent_suggestion = fm["agent_suggestion"]
            # Live registry entry is dropped once the execution finishes
            # (end_execution) — fall back to the PERSISTED stage history in
            # files_metadata so terminal responses still carry the breakdown.
            _persisted_sh = fm.get("stage_history")
            if not stage_history:
                if isinstance(_persisted_sh, dict) \
                        and isinstance(_persisted_sh.get("stages"), list):
                    stage_history = _persisted_sh["stages"]
            # 2026-07-15 "Why N files?" — terminal fallback for the brain
            # diagnostics (same persisted extras the perf chip reads).
            if not brain_diagnostics and isinstance(_persisted_sh, dict):
                try:
                    from core.brain_diagnostics import (
                        extract_brain_diagnostics as _bd_x2,
                    )
                    brain_diagnostics = _bd_x2(_persisted_sh.get("extras"))
                except Exception:
                    pass
    except Exception as _em_err:
        logger.debug("status endpoint: engine_meta extract failed: %s", _em_err)

    # 2026-07-16 STAGE TIMING — surface the per-query latency breakdown
    # (startup / S3 read / compute / planning) into the SAME brain
    # diagnostics blob the "Why N files?" panel already renders, so every
    # completed query self-reports where its milliseconds went.  Source is
    # the LatencyBreakdown that execute_query_background already emitted +
    # persisted at completion (files_metadata['latency_breakdown']) — PURE
    # READ, no new instrumentation.  Rides a reserved ``__timing__`` key so
    # the existing parents forward it to the panel untouched.  Fail-soft:
    # a missing / pre-completion breakdown simply adds no key.
    try:
        from core.brain_diagnostics import (
            build_timing_summary as _bd_timing,
            TIMING_MAP_KEY as _bd_timing_key,
        )
        _fm_t = execution.get("files_metadata")
        if isinstance(_fm_t, str):
            import json as _json_t
            try:
                _fm_t = _json_t.loads(_fm_t)
            except Exception:
                _fm_t = None
        if isinstance(_fm_t, dict):
            _timing = _bd_timing(_fm_t.get("latency_breakdown"))
            if _timing:
                if not isinstance(brain_diagnostics, dict):
                    brain_diagnostics = {}
                brain_diagnostics[_bd_timing_key] = _timing
    except Exception as _bd_t_exc:
        logger.debug("status endpoint: stage-timing surface failed: %s",
                     _bd_t_exc)

    _err = execution.get("error_message")
    if _err:
        from core.roles import is_admin_like as _is_adm_err
        if not _is_adm_err(_user):
            from core.error_sanitizer import sanitize_error as _sanitize_err
            _err = _sanitize_err(_err)
    return {
        "execution_id":   execution_id,
        "status":         execution.get("status"),
        "total_rows":     execution.get("total_rows"),
        "error_message":  _err,
        # 2026-09-24: get_execution returns datetimes on one backend and ISO
        # strings on another; .isoformat() on a string was a 500.
        "started_at":     _iso_or_none(execution.get("started_at")),
        "completed_at":   _iso_or_none(execution.get("completed_at")),
        "output_file":    execution.get("output_file"),
        # Live progress from stage tracker — exists even if WS dropped
        "stage":            stage_info.get("stage"),
        "files_total":      stage_info.get("files_total"),
        "files_done":       stage_info.get("files_done"),
        "message":          stage_info.get("message"),
        "stage_elapsed_seconds": stage_info.get("stage_elapsed_seconds"),
        "bytes_done":       stage_info.get("bytes_done"),
        "rows_done":        stage_info.get("rows_done"),
        # 2026-07-15 live-timeline resume — additive: completed stages so
        # far (+ in-flight pseudo-record with ``in_flight: true``).  Lets
        # the frontend rebuild its timeline after remount / WS drop.
        "stage_history":    stage_history,
        # BF-389: surface execution engine info so polling can populate the
        # ⚡/🔀 badge UI even when WS dropped before the completion event
        "engine_meta":      engine_meta,
        # 2026-07-15 "Why N files?" — additive: per-table pruning-brain
        # diagnostics (scan ledger, prunability, bloom routing, stats
        # coverage, freshness).  None when the brain didn't emit any.
        "brain_diagnostics": brain_diagnostics or None,
        # 2026-10-07: the poll fallback's copy of execution_failed's
        # agent_suggestion -- a client that missed the WebSocket message
        # still gets "Add GROUP BY clause".  None unless the run failed.
        "agent_suggestion": agent_suggestion,
    }


@router.get("/api/executions/{execution_id}/file-info")
async def get_execution_file_info(execution_id: str, _user: dict = Depends(get_current_user)):
    """Return file scan metadata for a completed execution (files scanned, total possible rows)."""
    execution = await adb(_db_manager.get_execution, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    # BF-414 — per-user ownership check (mirrors /column-stats just below).
    # Without this, any authenticated user could read another user's
    # ``files_metadata`` (S3 paths, full file list, total scanned bytes —
    # reconnaissance of other users' data sources).
    # 2026-09-24: THE execution-read rule (data_grid_api), not a local copy.
    # The copies here passed an execution with NO owner to every signed-in
    # user, while the canonical rule refuses it -- one question, two answers.
    _enforce_execution_ownership(execution_id, _user, record=execution)
    fm = execution.get("files_metadata")
    if not fm:
        return {"available": False}
    return {
        "available": True,
        "tables": fm,
        "total_result_rows": execution.get("total_rows", 0),
    }


@router.get("/api/executions/{execution_id}/workers")
async def get_execution_workers(
    execution_id: str,
    _user: dict = Depends(get_current_user),
):
    """BF-599 (2026-05-30): per-execution live multi-worker state.

    Returns the same data as the admin /api/admin/multi-worker/active
    endpoint, filtered to ONLY the workers handling THIS execution.
    User-scoped (no admin required) — the user owning the execution
    needs to see their own query's per-worker progress without
    pestering an admin.

    Response shape:
        {
          "execution_id": "...",
          "workers": [
            {
              "chunk_index":   0,
              "state":         "setup",          # starting / setup / running / completed / failed / cancelled
              "started_at":    1717000000.0,
              "updated_at":    1717000123.4,
              "elapsed_s":     123.4,
              "files_count":   758,
              "setup_step":    3,                # BF-599: per-statement progress
              "setup_total":   5,
              "setup_current": "CREATE OR REPLACE VIEW v AS...",
              "rows":          0,
            },
            ...
          ],
          "summary": { "total": 4, "setup": 3, "running": 1, ... }
        }

    Frontend polls this every 1-2s while a query is in flight; the
    BQB/CQB ExecutionPerformanceChip renders the per-worker grid.
    The same data is ALSO pushed via WebSocket (``multi_worker_progress``
    event) so the UI updates without polling — this endpoint is the
    poll-fallback + initial snapshot.
    """
    # Per-user ownership check (same pattern as /column-stats + /file-info).
    execution = await adb(_db_manager.get_execution, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    # 2026-09-24: THE execution-read rule (data_grid_api), not a local copy.
    # The copies here passed an execution with NO owner to every signed-in
    # user, while the canonical rule refuses it -- one question, two answers.
    _enforce_execution_ownership(execution_id, _user, record=execution)

    try:
        from core.multi_worker_executor import get_active_workers
        all_workers = get_active_workers()
    except ImportError:
        all_workers = []

    # Filter to this execution.  correlation_id is set to the execution_id
    # by the dispatcher (execute_api passes it through).
    mine = [w for w in all_workers if w.get("correlation_id") == execution_id]

    # Summary by state for the UI badge.
    summary = {"total": len(mine)}
    for w in mine:
        st = w.get("state", "unknown")
        summary[st] = summary.get(st, 0) + 1

    return {
        "execution_id": execution_id,
        "workers":      mine,
        "summary":      summary,
    }


# In-process column-stats cache: execution_id → stats dict.  Built once per
# execution, reused across UI refreshes / sidebar opens.  Cleared automatically
# when an execution is removed via the existing cleanup paths.
_column_stats_cache: dict = {}


def _compute_execution_column_stats(output_file: str, max_top_values: int) -> dict:
    """SYNC per-column DuckDB profile over a result parquet.  Runs in a worker
    thread (asyncio.to_thread) so the NFS stat + DuckDB scans NEVER block the
    single asyncio event loop — on a large / full-scan-inflated result these
    scans take minutes and would freeze the loop, starving the liveness probe
    and restarting the pod (P1-D)."""
    from core.duckdb_factory import duckdb_connection
    from pathlib import Path as _Path

    parquet_path = _Path(output_file)
    if not parquet_path.exists():
        return {"available": False, "reason": "output file missing"}

    max_top_values = max(1, min(int(max_top_values or 10), 50))
    columns_out: list = []
    row_count = 0
    try:
        with duckdb_connection() as con:
            esc_path = str(parquet_path).replace("'", "''")
            view_sql = f"CREATE OR REPLACE TEMP VIEW _result AS SELECT * FROM read_parquet('{esc_path}')"
            con.execute(view_sql)

            row_count = con.execute("SELECT COUNT(*) FROM _result").fetchone()[0] or 0

            schema_rows = con.execute("DESCRIBE _result").fetchall()
            for srow in schema_rows:
                col_name = srow[0]
                col_type = (srow[1] or "").upper()
                qcol = '"' + str(col_name).replace('"', '""') + '"'

                base = con.execute(
                    f"SELECT COUNT(*), COUNT(*) - COUNT({qcol}), "
                    f"  APPROX_COUNT_DISTINCT({qcol}) FROM _result"
                ).fetchone()
                total, null_count, distinct_count = (base or (0, 0, 0))

                stat: dict = {
                    "name":           col_name,
                    "type":           col_type,
                    "null_count":     int(null_count or 0),
                    "distinct_count": int(distinct_count or 0),
                    "total":          int(total or 0),
                }

                is_numeric = any(t in col_type for t in (
                    "INT", "DECIMAL", "DOUBLE", "FLOAT", "REAL", "NUMERIC", "BIGINT",
                    "SMALLINT", "TINYINT", "HUGEINT", "UBIGINT", "USMALLINT", "UINTEGER",
                    "UTINYINT",
                ))
                is_temporal = any(t in col_type for t in ("DATE", "TIMESTAMP", "TIME"))
                is_bool = "BOOL" in col_type

                if is_numeric:
                    try:
                        agg = con.execute(
                            f"SELECT MIN({qcol}), MAX({qcol}), AVG({qcol}), "
                            f"  QUANTILE_CONT({qcol}, 0.5), STDDEV({qcol}) FROM _result"
                        ).fetchone()
                        if agg:
                            mn, mx, mean, median, stdev = agg
                            if mn is not None:
                                stat["min"] = float(mn)
                            if mx is not None:
                                stat["max"] = float(mx)
                            if mean is not None:
                                stat["mean"] = round(float(mean), 4)
                            if median is not None:
                                stat["median"] = round(float(median), 4)
                            if stdev is not None:
                                stat["stdev"] = round(float(stdev), 4)

                        if stat.get("min") is not None and stat.get("max") is not None and stat["min"] != stat["max"]:
                            mn_v = stat["min"]
                            mx_v = stat["max"]
                            bins_sql = (
                                f"SELECT FLOOR(((CAST({qcol} AS DOUBLE) - {mn_v}) / "
                                f"  ({mx_v - mn_v} + 1e-9)) * 10)::INT AS bucket, COUNT(*) AS c "
                                f"FROM _result WHERE {qcol} IS NOT NULL "
                                f"GROUP BY bucket ORDER BY bucket"
                            )
                            try:
                                hist_rows = con.execute(bins_sql).fetchall()
                                width = (mx_v - mn_v) / 10.0
                                hist = []
                                for b, c in hist_rows:
                                    if b is None:
                                        continue
                                    b = max(0, min(9, int(b)))
                                    lo = mn_v + b * width
                                    hi = mn_v + (b + 1) * width
                                    hist.append({
                                        "bucket": f"{round(lo, 2)}–{round(hi, 2)}",
                                        "count":  int(c or 0),
                                    })
                                if hist:
                                    stat["histogram"] = hist
                            except Exception as he:
                                logger.debug("column-stats histogram skipped for %s: %s", col_name, he)
                    except Exception as ne:
                        logger.debug("column-stats numeric agg skipped for %s: %s", col_name, ne)
                elif is_temporal:
                    try:
                        agg = con.execute(
                            f"SELECT MIN(CAST({qcol} AS VARCHAR)), MAX(CAST({qcol} AS VARCHAR)) FROM _result"
                        ).fetchone()
                        if agg:
                            stat["min"] = agg[0]
                            stat["max"] = agg[1]
                    except Exception as te:
                        logger.debug("column-stats temporal agg skipped for %s: %s", col_name, te)
                elif is_bool:
                    try:
                        agg = con.execute(
                            f"SELECT SUM(CASE WHEN {qcol} THEN 1 ELSE 0 END), "
                            f"  SUM(CASE WHEN NOT {qcol} THEN 1 ELSE 0 END) FROM _result"
                        ).fetchone()
                        if agg:
                            stat["true_count"]  = int(agg[0] or 0)
                            stat["false_count"] = int(agg[1] or 0)
                    except Exception as be:
                        logger.debug("column-stats bool agg skipped for %s: %s", col_name, be)

                if not is_bool:
                    try:
                        top_rows = con.execute(
                            f"SELECT CAST({qcol} AS VARCHAR) AS v, COUNT(*) AS c "
                            f"FROM _result WHERE {qcol} IS NOT NULL "
                            f"GROUP BY v ORDER BY c DESC LIMIT {max_top_values}"
                        ).fetchall()
                        stat["top_values"] = [
                            {"value": r[0], "count": int(r[1] or 0)} for r in top_rows
                        ]
                    except Exception as tve:
                        logger.debug("column-stats top_values skipped for %s: %s", col_name, tve)

                columns_out.append(stat)
    except Exception as exc:
        logger.warning("column-stats compute failed for %s: %s", output_file, exc)
        return {"available": False, "reason": f"stats computation failed: {exc.__class__.__name__}"}

    return {"available": True, "row_count": int(row_count), "columns": columns_out}


@router.get("/api/executions/{execution_id}/column-stats")
async def get_execution_column_stats(
    execution_id: str,
    max_top_values: int = 10,
    _user: dict = Depends(get_current_user),
):
    """Per-column profile (distinct/null/min/max/histogram/top values) for the
    result parquet of a completed execution.

    Powers the result-grid sidebar — Snowsight-style "click a column header,
    see its histogram" UX.  Cached in-process so re-opening the sidebar is free.

    Response shape:
        {
          "execution_id": "...",
          "row_count": 50_000,
          "columns": [
            {
              "name": "amount", "type": "DOUBLE",
              "null_count": 12, "distinct_count": 4_500,
              "min": 1.50, "max": 9_999.0,
              "mean": 245.67, "median": 200.0,
              "histogram": [{"bucket": "0–1000", "count": 300}, ...],   # numeric
              "top_values": [{"value": "X", "count": 12}, ...]          # categorical
            },
            ...
          ]
        }
    """
    # Per-user ownership check (matches the rest of execute_api.py)
    # BF-598: was sync — freezes event loop on every column-stats sidebar open.
    execution = await adb(_db_manager.get_execution, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    # 2026-09-24: THE execution-read rule (data_grid_api), not a local copy.
    # The copies here passed an execution with NO owner to every signed-in
    # user, while the canonical rule refuses it -- one question, two answers.
    _enforce_execution_ownership(execution_id, _user, record=execution)

    if execution.get("status") != "completed":
        return {"available": False, "reason": f"execution status: {execution.get('status')}"}

    output_file = execution.get("output_file")
    if not output_file:
        return {"available": False, "reason": "no output file"}

    # Cache hit
    cached = _column_stats_cache.get(execution_id)
    if cached:
        return cached

    # Compute OFF the event loop — the NFS stat + DuckDB scans would otherwise
    # freeze the single asyncio loop for the whole scan (minutes on a large /
    # full-scan-inflated result) → liveness probe starved → pod restart.
    response = await asyncio.to_thread(
        _compute_execution_column_stats, output_file, max_top_values)
    if not response.get("available"):
        return response

    response["execution_id"] = execution_id
    _column_stats_cache[execution_id] = response

    # Bound the cache to the most recent N executions (drop oldest)
    if len(_column_stats_cache) > 256:
        try:
            oldest_key = next(iter(_column_stats_cache))
            _column_stats_cache.pop(oldest_key, None)
        except StopIteration:
            pass

    return response


from pydantic import BaseModel as _ExplainBase  # local import to avoid header churn  # noqa: E402

class ExplainRequest(_ExplainBase):
    """POST /api/execute/explain — payload schema."""
    raw_sql: Optional[str] = None
    query_config: Optional[QueryConfigRequestModel] = None
    connection_id: Optional[int] = None
    analyze: bool = False  # true → EXPLAIN ANALYZE (executes & measures); false → plan only


class SqlAutoFixRequest(_ExplainBase):
    """POST /api/sql/auto-fix — payload schema."""
    raw_sql: str
    # BF-277: connection_id lets us look up cached schemas for ambiguous-
    # column resolution.  Optional — without it, we still attempt the
    # GROUP BY fix from BF-237 (works without schema info).
    connection_id: Optional[int] = None


def _qualify_ambiguous_columns(node, schema) -> int:
    """BF-277: qualify every unqualified column of the root SELECT that 2+
    of its FROM/JOIN tables have, with the first table (in FROM/JOIN order)
    that has it -- the "primary table wins" convention, the fix DuckDB's
    and Trino's own errors suggest.  Mutates ``node``; returns the count.

    ``schema`` is the statement's resolved
    ``core.sql_autofix_schema.StatementSchema`` (``None`` = no connection,
    nothing to decide with).  Until 2026-10-06 this read the LEGACY
    ``schema_cache`` by BARE table name, which has no row for a Trino table
    written ``catalog.schema.table`` -- an ambiguous column Trino refuses
    was answered "Nothing to fix".  The logic lives in
    ``core.sql_autofix_schema.qualify_ambiguous_columns``.
    """
    if schema is None:
        return 0
    from core.sql_autofix_schema import qualify_ambiguous_columns
    return qualify_ambiguous_columns(node, schema)


def _validate_column_existence(node, schema) -> List[Dict[str, Any]]:
    """Round 14 (2026-06-02): schema-aware column-existence validator.

    Returns ``not_in_table`` / ``unknown_column`` issues, each with up to
    three ``suggestions``, from the statement's resolved
    ``core.sql_autofix_schema.StatementSchema`` (``None`` = no connection
    -> no issues).  An unqualified column is only called unknown when EVERY
    table's columns are known (``core.sql_autofix_schema.
    column_existence_issues``); a table that could not be read is reported
    by the route as ``schema_unknown``, never as "no issues".
    """
    if schema is None:
        return []
    from core.sql_autofix_schema import column_existence_issues
    try:
        return column_existence_issues(node, schema)
    except Exception as exc:  # noqa: BLE001 -- the route still answers; say why here
        logger.warning("[validate-columns] AST walk raised: %s", exc)
        return []


@router.post("/api/sql/auto-fix")
async def sql_auto_fix(request: SqlAutoFixRequest, _user: dict = Depends(get_current_user)):
    """Best-effort SQL auto-fixer.

    Fixes (1) unqualified column references that 2+ joined tables have
    (BF-277) and (2) an aggregate mixed with non-aggregated columns and no
    GROUP BY (BF-237), and reports column names the tables do not have
    (``column_issues``).

    Response::
        {
          "fixed": true,
          "fixed_sql": "...",
          "applied_fixes": ["qualified_2_ambiguous_columns", "added_group_by"],
          "explanation": "...",
          "column_issues": [...],          # optional
          "schema_unknown": ["cat.sch.t"], # optional: tables whose columns
                                           # could not be read (the
                                           # explanation says why)
        }

    Or when nothing is fixed::
        { "fixed": false, "applied_fixes": [], "explanation": "..." }

    2026-10-06 -- the CONNECTION decides two things, found live on real
    AWS + Trino: the columns of each table (``core.sql_autofix_schema``:
    the column catalog keyed by the address the product uses on that
    connection, then one bounded read of the source) and the GRAMMAR the
    statement is parsed and written in (``autofix_dialect``; every
    rewrite used to be DuckDB's).  A connector with no known grammar, or a
    rewrite that does not parse in the connection's grammar, is refused
    (``fixed: false``, ``refused: true``, the reason) -- never SQL for a
    different engine.  Fail-open on unparsable input: ``fixed: false`` with
    the reason.
    """
    sql = (request.raw_sql or "").strip()
    if not sql:
        return {"fixed": False, "applied_fixes": [], "explanation": "Empty SQL"}

    # SECURITY 2026-08-23 (Phase 2A): the schema-enrichment steps below
    # (ambiguous-column qualification, column-existence validation) read the
    # connection's schema by id.  A caller not entitled to the connection
    # must not learn its column names, so drop an unentitled connection_id
    # to None — the structural GROUP BY / ambiguous-alias fixes still run,
    # they just do so without another user's schema.
    if request.connection_id:
        _afx_denied = await asyncio.to_thread(
            _conn_entitlement_denied, _user, [request.connection_id])
        if _afx_denied:
            request.connection_id = None

    try:
        import sqlglot
        from sqlglot import exp
    except Exception:
        return {"fixed": False, "applied_fixes": [], "explanation": "sqlglot unavailable"}

    from core.sql_autofix_schema import (
        autofix_dialect, resolve_statement_schema, unknown_schema_sentence,
    )

    # The connection the statement was written for decides its grammar.
    _afx_conn = None
    if request.connection_id and _db_manager is not None:
        _afx_conn = await asyncio.to_thread(
            _db_manager.get_connection_raw, int(request.connection_id))
        if not _afx_conn:
            return {
                "fixed": False, "applied_fixes": [], "refused": True,
                "explanation": (
                    f"Connection {request.connection_id} was not found, so the "
                    f"SQL could not be checked against it."),
            }
    _afx_type = str((_afx_conn or {}).get("connection_type") or "")
    dialect = autofix_dialect(_afx_type)
    if dialect is None:
        return {
            "fixed": False, "applied_fixes": [], "refused": True,
            "explanation": (
                f"Auto-fix has no SQL grammar for a '{_afx_type}' connection, "
                f"so it will not rewrite this statement -- the result would be "
                f"written for a different engine."),
        }

    try:
        parsed = sqlglot.parse_one(sql, read=dialect)
    except Exception as exc:
        return {"fixed": False, "applied_fixes": [],
                "explanation": f"parse error ({dialect}): {exc.__class__.__name__}"}

    if not isinstance(parsed, exp.Select):
        return {"fixed": False, "applied_fixes": [], "explanation": "Not a SELECT statement"}

    # Resolve every table's columns ONCE; both rewrites read this answer.
    schema = None
    if _afx_conn:
        schema = await resolve_statement_schema(
            _db_manager, int(request.connection_id), parsed,
            conn_raw=_afx_conn,
            username=str((_user or {}).get("username") or ""))

    def _respond(resp: Dict[str, Any]) -> Dict[str, Any]:
        # The rewrite must be SQL for the connection it was written for.
        if resp.get("fixed") and resp.get("fixed_sql"):
            try:
                sqlglot.parse_one(resp["fixed_sql"], read=dialect)
            except Exception as _reparse_exc:
                return {
                    "fixed": False, "applied_fixes": [], "refused": True,
                    "explanation": (
                        f"The rewritten statement does not parse as {dialect} "
                        f"SQL ({_reparse_exc.__class__.__name__}), so it is not "
                        f"returned."),
                }
        # Unknown is not "nothing to fix": name what was not checked.
        if schema is not None and schema.unknown:
            resp["schema_unknown"] = list(schema.unknown)
            sentence = unknown_schema_sentence(schema)
            if resp.get("fixed") or resp.get("column_issues"):
                resp["explanation"] = f"{resp['explanation'].rstrip('.')}. {sentence}"
            else:
                resp["explanation"] = sentence
        return resp

    # ── BF-277: Detect + fix ambiguous unqualified column references ─────────
    # When a query joins 2+ tables that share column names (e.g. fact_table
    # + fact_table_ext both have ``sap_company_id``), an unqualified
    # reference is refused by the engine (DuckDB Binder Error, Trino
    # AMBIGUOUS_NAME).  Auto-fix: prefix the first table that has it.
    applied_amb_fixes: List[str] = []
    fixed_node_amb = parsed.copy()
    amb_count = 0
    try:
        # BF-NONBLOCK-AUDIT-8: sqlglot rewrite, CPU-bound on large statements.
        amb_count = await asyncio.to_thread(
            _qualify_ambiguous_columns, fixed_node_amb, schema)
        if amb_count > 0:
            applied_amb_fixes.append(f"qualified_{amb_count}_ambiguous_columns")
    except Exception as _amb_exc:
        logger.warning("[auto-fix] ambiguous-column resolution failed: %s", _amb_exc)
    if applied_amb_fixes:
        # If the GROUP BY fix path doesn't fire, this is the only fix; return now.
        # If it does fire, we want to combine — re-parse from the qualified SQL
        # so the GROUP BY logic operates on already-qualified columns.
        amb_fixed_sql = fixed_node_amb.sql(dialect=dialect, pretty=True)
        try:
            parsed = sqlglot.parse_one(amb_fixed_sql, read=dialect)
        except Exception:
            return _respond({
                "fixed": True,
                "fixed_sql": amb_fixed_sql,
                "applied_fixes": applied_amb_fixes,
                "explanation": (
                    f"Qualified {amb_count} ambiguous column reference"
                    f"{'s' if amb_count > 1 else ''} with the first table's alias."
                ),
            })
        if not isinstance(parsed, exp.Select):
            return _respond({
                "fixed": True,
                "fixed_sql": amb_fixed_sql,
                "applied_fixes": applied_amb_fixes,
                "explanation": "Qualified ambiguous columns.",
            })

    # ── Detect mixed aggregate / non-aggregate without GROUP BY ──────────────

    select_exprs = parsed.expressions or []
    has_group_by = parsed.args.get("group") is not None

    aggregate_classes = (exp.Sum, exp.Avg, exp.Count, exp.Min, exp.Max)
    non_aggregated: list = []
    has_aggregate = False
    for e in select_exprs:
        # The column-side of `<expr> AS alias` lives under e.this; otherwise e itself
        body = e.this if isinstance(e, exp.Alias) else e
        # Has any aggregate function anywhere in this SELECT expression?
        # NOTE: list() forces the generator — a bare generator is always truthy.
        body_has_agg = any(list(body.find_all(cls)) for cls in aggregate_classes)
        if body_has_agg:
            has_aggregate = True
        else:
            non_aggregated.append(body)

    if not has_aggregate or not non_aggregated or has_group_by:
        # Round 14: column-existence validation runs even when nothing
        # else needed fixing — the user clicked Validate & Fix to find
        # ALL issues, not just GROUP-BY / ambiguous ones.
        _col_issues_nofix = _validate_column_existence(parsed, schema)
        # BF-277: if we already qualified ambiguous columns, that IS a fix
        # even if there's no GROUP BY work to do.
        if applied_amb_fixes:
            _resp_amb: Dict[str, Any] = {
                "fixed": True,
                "fixed_sql": parsed.sql(dialect=dialect, pretty=True),
                "applied_fixes": applied_amb_fixes,
                "explanation": (
                    f"Qualified ambiguous column reference"
                    f"{'s' if amb_count > 1 else ''}."
                ),
            }
            if _col_issues_nofix:
                _resp_amb["column_issues"] = _col_issues_nofix
            return _respond(_resp_amb)
        # Round 14: when no auto-fixes apply but column_issues exist,
        # surface them so the user sees "did you mean X?" suggestions.
        _resp_nofix: Dict[str, Any] = {
            "fixed": False, "applied_fixes": [],
            "explanation": (
                "Nothing to auto-fix, but column issues found"
                if _col_issues_nofix
                else ("Nothing to fix" if has_aggregate or has_group_by else "No aggregates")
            ),
        }
        if _col_issues_nofix:
            _resp_nofix["column_issues"] = _col_issues_nofix
        return _respond(_resp_nofix)

    # ── Build GROUP BY for every non-aggregated SELECT expression ────────────
    group_exprs = [e.copy() for e in non_aggregated]
    fixed_node = parsed.copy()
    fixed_node.set("group", exp.Group(expressions=group_exprs))
    fixed_sql = fixed_node.sql(dialect=dialect, pretty=True)

    # BF-277: combine GROUP BY + ambiguous-column fixes when both apply.
    combined_fixes = applied_amb_fixes + ["added_group_by"]
    explanation_parts = []
    if applied_amb_fixes:
        explanation_parts.append(
            f"Qualified {amb_count} ambiguous column reference"
            f"{'s' if amb_count > 1 else ''} with the first table's alias"
        )
    explanation_parts.append(
        f"Added GROUP BY for {len(non_aggregated)} non-aggregated "
        f"column{'s' if len(non_aggregated) > 1 else ''}"
    )

    # Round 14: column-existence validation on the FIXED node.
    _col_issues = _validate_column_existence(fixed_node, schema)
    _response: Dict[str, Any] = {
        "fixed": True,
        "fixed_sql": fixed_sql,
        "applied_fixes": combined_fixes,
        "explanation": ". ".join(explanation_parts) + ".",
    }
    if _col_issues:
        _response["column_issues"] = _col_issues
    return _respond(_response)


async def _build_explain_setup_sql(
    sql: str, connection_id: Optional[int],
) -> tuple[str, dict]:
    """Build CREATE-VIEW DDL for any registered tables / local files that
    the EXPLAIN SQL references, so DuckDB's planner can resolve table names.

    Returns ``(setup_sql, duckdb_settings)`` — both empty when we can't
    or shouldn't try setup (no referenced tables found, etc.).

    Handles three cases:
      1. S3-registered tables on a connection → CREATE VIEW with read_parquet glob
      2. Local parquet files in ``paths.parquet_dir`` → CREATE VIEW with absolute path
      3. Mix of both (returns combined setup)

    Fail-open: any introspection error returns ``("", {})`` so the caller
    falls back to the bare EXPLAIN attempt.
    """
    if not sql:
        return "", {}

    # 1. Extract bare table references from the SQL via sqlglot
    referenced: set = set()
    try:
        import sqlglot
        from sqlglot import exp
        parsed = sqlglot.parse_one(sql, read="duckdb",
                                     error_level=sqlglot.ErrorLevel.IGNORE)
        if parsed:
            for tbl in parsed.find_all(exp.Table):
                if tbl.name:
                    referenced.add(tbl.name.lower())
    except Exception as parse_err:
        logger.debug("EXPLAIN setup: SQL parse failed (%s) — no setup", parse_err)
        return "", {}

    if not referenced:
        return "", {}

    # ── First: try resolving any referenced names against the local
    # parquet base path (BQB raw SQL like SELECT * FROM "foo.parquet").
    # No connection_id needed for this.
    local_views: list = []
    try:
        if _paths is not None:
            base_path = str(getattr(_paths, "parquet_dir", "") or "")
            if base_path and os.path.isdir(base_path):
                for ref_name in list(referenced):
                    # Try exact filename match (with or without .parquet extension)
                    candidates = [
                        os.path.join(base_path, ref_name),
                        os.path.join(base_path, f"{ref_name}.parquet"),
                    ]
                    for cand in candidates:
                        full = cand.replace("\\", "/")
                        if os.path.isfile(full):
                            view_name = os.path.basename(full).replace('"', '""')
                            local_views.append(
                                f'CREATE VIEW "{view_name}" AS '
                                f"SELECT * FROM read_parquet('{full}', hive_partitioning=true)"
                            )
                            referenced.discard(ref_name)  # don't also try S3
                            logger.debug("EXPLAIN: resolved local file %s", view_name)
                            break
    except Exception as local_err:
        logger.debug("EXPLAIN setup: local file resolution failed: %s", local_err)

    # If we resolved everything locally, return just those views (no S3
    # creds needed)
    if local_views and not referenced:
        return ";\n".join(local_views), {}

    # If no connection_id, we can't try S3 — return whatever we found locally
    if not connection_id:
        if local_views:
            return ";\n".join(local_views), {}
        return "", {}

    # 2. Find a run_engine for this connection.  Re-use the same factory
    #    the main execute path uses so EXPLAIN sees identical views.
    try:
        from core.connection_manager import _normalize_path  # noqa: F401  (test for import OK)
        from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig  # noqa: F401
        # Build an engine instance scoped to this connection
        if _db_manager is None:
            return "", {}
        conn = await adb(_db_manager.get_connection_by_id, connection_id)
        if not conn:
            return "", {}
        # Only handle S3 connections here — local connections don't need
        # EXPLAIN setup (DuckDB sees local files via direct path).
        conn_type = (conn.get("connection_type") or "").lower()
        if conn_type != "s3":
            return "", {}
        conn_config = conn.get("config") or {}
    except Exception as engine_err:
        logger.debug("EXPLAIN setup: engine resolution failed: %s", engine_err)
        return "", {}

    # 3. Pull registered tables from the connection's config and filter
    #    to those referenced in the SQL.
    registered = conn_config.get("registered_tables") or []
    if not isinstance(registered, list):
        return "", {}
    matched = [
        rt for rt in registered
        if isinstance(rt, dict) and str(rt.get("name", "")).lower() in referenced
    ]
    if not matched:
        return "", {}

    # 4. Build setup SQL — minimal CREATE VIEW per matched table.  For
    #    EXPLAIN we don't need the full file list; passing a wildcard glob
    #    is enough for the planner to resolve schema + partition info.
    bucket = conn_config.get("bucket") or conn_config.get("bucket_name") or ""
    # BF-599f (2026-05-31): honour QS_AUTOINSTALL_EXTENSIONS=false on
    # OpenShift NFS-prestaged deploys — emit LOAD-only to skip the
    # extensions.duckdb.org lookup that blocks for the proxy connect
    # timeout.
    from core.multi_worker_dispatcher import _httpfs_load_prefix as _hlp
    setup_stmts: list = [s for s in _hlp().split(";") if s.strip()]
    for rt in matched:
        name = str(rt.get("name", "")).replace('"', '""')
        prefix = str(rt.get("prefix") or rt.get("path") or "").strip("/")
        fmt = (rt.get("format") or "parquet").lower()
        if not name or not bucket:
            continue
        if fmt == "iceberg":
            # For Iceberg, EXPLAIN against a single sample parquet is enough
            # for the planner.  Skipped for now — Iceberg setup needs more
            # plumbing (manifest reads) than EXPLAIN warrants.
            continue
        # Parquet glob — DuckDB can plan against this without listing
        glob_url = f"s3://{bucket}/{prefix}/**/*.parquet" if prefix else f"s3://{bucket}/**/*.parquet"
        setup_stmts.append(
            f'CREATE VIEW "{name}" AS '
            f"SELECT * FROM read_parquet('{glob_url}', hive_partitioning=true)"
        )

    if len(setup_stmts) <= 2:   # only INSTALL+LOAD, no S3 views
        # Maybe we still have local views from earlier — include those
        if local_views:
            return ";\n".join(local_views), {}
        return "", {}

    # Combine local file views (if any) with S3 views
    setup_stmts = local_views + setup_stmts

    # 5. Build the S3 settings the EXPLAIN connection needs to read s3:// URLs.
    # 2026-06-23 -- pass setup SQL so the dispatcher's planner-aware
    # helper can omit s3_endpoint + credentials when setup_stmts embed
    # presigned URLs (smart-VPC fast path) -- otherwise the EXPLAIN's
    # connection would double-sign when probed.
    _setup_combined = ";\n".join(setup_stmts)
    try:
        from core.multi_worker_dispatcher import _duckdb_settings_from_conn_config
        settings = _duckdb_settings_from_conn_config(
            conn_config, setup_sql=_setup_combined,
        )
    except Exception:
        settings = {}

    return _setup_combined, settings


#: The EXPLAIN spelling each SQL engine answers with a plan (no data rows).
#: Oracle's is a two-statement EXPLAIN PLAN FOR + DBMS_XPLAN, not offered.
_SOURCE_EXPLAIN = {"snowflake": "EXPLAIN USING TEXT", "trino": "EXPLAIN",
                   "starburst": "EXPLAIN", "databricks": "EXPLAIN", "athena": "EXPLAIN"}


async def _explain_on_connection_engine(request, user, sql: str):
    """The plan from the connection's own engine for a SQL connection, or
    None when the request is for the local engine (no connection, storage)."""
    if not request.connection_id:
        return None
    await asyncio.to_thread(_require_conn_entitlement_exec, user, [request.connection_id])
    rec = await adb(_db_manager.get_connection_raw, int(request.connection_id))
    ctype = str((rec or {}).get("connection_type") or "").lower()
    if ctype not in SQL_CONNECTOR_TYPES:
        return None
    if not (request.raw_sql or "").strip():
        return {"available": False, "engine": ctype,
                "reason": "A plan from the source needs the statement's SQL text."}
    keyword = _SOURCE_EXPLAIN.get(ctype)
    if keyword is None or (request.analyze and ctype not in ("trino", "starburst")):
        return {"available": False, "engine": ctype,
                "reason": f"EXPLAIN{' ANALYZE' if request.analyze else ''} is not offered for {ctype} here."}
    if request.analyze:
        keyword = "EXPLAIN ANALYZE"
    stmt = f"{keyword} {sql.rstrip().rstrip(';')}"
    # 2026-10-07: off the loop -- a system-account connection reads its row (and Vault) here.
    connector = await asyncio.to_thread(
        get_connector, ctype, (rec or {}).get("config") or {}, int(request.connection_id),
        (rec or {}).get("name", ""))
    try:
        result = await asyncio.get_running_loop().run_in_executor(
            None, lambda: connector.execute_query(stmt, limit=None))
    except Exception as exc:  # noqa: BLE001 -- the source's verdict, shown
        from core.error_sanitizer import explain_failure
        return {"available": False, "engine": ctype,
                "reason": explain_failure(exc, subject=f"The {ctype} plan")[:800]}
    finally:
        try:
            connector.close()
        except Exception:  # noqa: BLE001
            pass
    lines = []
    for row in (result or {}).get("rows") or []:
        cells = list(row.values()) if isinstance(row, dict) else list(row)
        lines.append(" | ".join("" if c is None else str(c) for c in cells))
    return {"available": True, "engine": ctype, "plan_text": "\n".join(lines),
            "operators": [], "analyzed": bool(request.analyze)}


@router.post("/api/execute/explain")
async def explain_query(request: ExplainRequest, _user: dict = Depends(get_current_user)):
    """Return DuckDB's query plan (EXPLAIN) or analyse output (EXPLAIN ANALYZE).

    Powers the visual-EXPLAIN feature in CQB/BQB — users can see the operator
    tree, filter pushdown decisions, and (with analyze=true) actual row
    counts per node before committing to a long-running query.

    Response::
        {
          "available": true,
          "plan_text": "...full DuckDB EXPLAIN output...",
          "operators": [{"name": "...", "rows_estimate": 1000, "indent": 0}, ...],
          "analyzed": false
        }

    Fail-open — any DuckDB / parsing error returns ``{available: false,
    reason: "..."}`` without raising HTTP 500.
    """
    sql = (request.raw_sql or "").strip()
    if not sql and not request.query_config:
        raise HTTPException(status_code=422, detail="raw_sql or query_config is required")

    # If only query_config is given, build SQL via the engine the same way
    # estimate_query does (no connection-specific resolution needed for EXPLAIN).
    if not sql and request.query_config:
        try:
            estimate_model = request.query_config.model_copy()
            engine_config = convert_query_config_to_engine(estimate_model)
            from_clause = _engine._build_duckdb_from_clause(engine_config)
            sql = _engine.build_query_sql(engine_config, from_clause)
        except Exception as exc:
            logger.warning("explain: build SQL from query_config failed: %s", exc)
            return {"available": False, "reason": f"sql_build_failed: {exc.__class__.__name__}"}

    # 2026-10-03 -- EXPLAIN runs on the connection's OWN engine.  This route
    # always asked the local DuckDB, so EXPLAIN on a Snowflake / Trino query
    # could only fail or describe a plan the source never runs (found on a
    # real Snowflake account, where the button even said "DuckDB").  The
    # same entitlement gate as a run: a plan names tables and filters.
    _explain_on_source = await _explain_on_connection_engine(request, _user, sql)
    if _explain_on_source is not None:
        return _explain_on_source

    # Strip a trailing semicolon — EXPLAIN doesn't accept multi-statement input
    sql = sql.rstrip().rstrip(";")
    keyword = "EXPLAIN ANALYZE" if request.analyze else "EXPLAIN"
    explain_sql = f"{keyword} {sql}"

    # BF-386: EXPLAIN against registered S3 tables requires the same view
    # setup as actual execution.  Without it, the fresh DuckDB connection
    # raises "Catalog Error: Table 'X' does not exist".  Build setup SQL
    # for any referenced registered tables, run it before EXPLAIN.
    #
    # Fail-open: if setup fails (missing creds, no run_engine, etc.) we
    # still try the bare EXPLAIN and surface its error.
    setup_sql, setup_settings = await _build_explain_setup_sql(
        sql, request.connection_id,
    )

    try:
        from core.duckdb_factory import duckdb_connection
        from core.multi_worker_executor import _quote_setting_value
        # BF-WS-NOBLOCK: EXPLAIN can take seconds on complex SQL — wrap so
        # the asyncio loop isn't starved while DuckDB plans the query.
        def _run_explain():
            with duckdb_connection() as _con:
                # Apply S3 settings if we have them (for s3:// URL resolution)
                for k, v in (setup_settings or {}).items():
                    try:
                        _con.execute(f"SET {k}={_quote_setting_value(v)};")
                    except Exception as _set_err:
                        logger.debug("EXPLAIN: ignored SET %s: %s", k, _set_err)
                # Load httpfs + register table views so the planner can
                # resolve table names.
                if setup_sql:
                    for stmt in setup_sql.split(";\n"):
                        stmt = stmt.strip()
                        if stmt:
                            _con.execute(stmt)
                return _con.execute(explain_sql).fetchall()
        rows = await asyncio.to_thread(_run_explain)
    except Exception as exc:
        # Tag the error with whether setup was attempted so users get a
        # clearer message — "table X not found" vs "S3 credential missing"
        # are different operator concerns.
        err_msg = str(exc)[:300]
        if "does not exist" in err_msg.lower() and not setup_sql:
            err_msg += (
                " — EXPLAIN couldn't resolve table references.  "
                "Either pass `connection_id` in the request body, or the "
                "referenced table isn't registered on that connection."
            )
        logger.info("EXPLAIN failed for query (%d chars): %s", len(sql), exc)
        return {"available": False, "reason": err_msg}

    # DuckDB's EXPLAIN returns rows of (key, value) where value is the rendered
    # plan text.  We concatenate everything and also parse a lightweight
    # operator list for the UI tree.
    plan_lines: list = []
    for row in rows:
        if not row:
            continue
        text = row[-1] if isinstance(row, (list, tuple)) else str(row)
        plan_lines.append(str(text or ""))
    plan_text = "\n".join(plan_lines)

    # ── Tree-style operator extraction ──────────────────────────────────────
    # DuckDB's plan uses ASCII boxes:
    #   ┌───────────────────────────┐
    #   │       PROJECTION          │
    #   │   ~1000000 rows           │
    #   └─────────────┬─────────────┘
    # We pull the operator names + row estimates to a flat list with indent
    # depth so the frontend can render a simple indented list.
    import re
    operators: list = []
    cur_op: Optional[dict] = None
    indent = 0
    for ln in plan_lines:
        # Indentation = number of leading spaces / 2 (DuckDB indents by 2 per nest)
        if ln.lstrip().startswith("│") and not ln.lstrip().startswith("│ ─"):
            inner = ln.strip().strip("│").strip()
            if not inner:
                continue
            # operator name lines tend to be uppercase-ish
            if re.match(r"^[A-Z][A-Z_ ]+$", inner):
                if cur_op:
                    operators.append(cur_op)
                cur_op = {"name": inner, "rows_estimate": None, "indent": indent}
            elif "row" in inner.lower() and cur_op is not None:
                m = re.search(r"~?([\d,]+)\s*rows?", inner, re.IGNORECASE)
                if m:
                    try:
                        cur_op["rows_estimate"] = int(m.group(1).replace(",", ""))
                    except ValueError:
                        pass
        elif ln.startswith("└") or ln.startswith("┘"):
            if cur_op:
                operators.append(cur_op)
                cur_op = None
            # decrease indent — heuristic
            indent = max(0, indent - 1)
        elif ln.startswith("┌"):
            indent += 1

    if cur_op:
        operators.append(cur_op)

    return {
        "available": True,
        "plan_text": plan_text,
        "operators": operators,
        "analyzed": request.analyze,
    }


# BF-248: Estimate-result cache.  The estimate endpoint runs a real
# ``SELECT COUNT(*)`` against S3 / a SQL connector — for a partitioned 100M
# row table that is 5–30 s of round-trip every call.  Most users tweak
# columns/limits without touching filters, so the same estimate gets re-run
# repeatedly.  Cache by (connection_id, files, filters) for 5 minutes; in
# memory only — restart drops it, multi-pod each pod warms its own.
_ESTIMATE_CACHE: Dict[str, Tuple[float, dict]] = {}
_ESTIMATE_CACHE_LOCK = threading.Lock()
_ESTIMATE_CACHE_TTL_SECONDS = 300.0
_ESTIMATE_CACHE_MAX_ENTRIES = 1000


def _estimate_cache_key(connection_id, query_config_model, username: str = "") -> str:
    """Stable hash of (user, conn, files, filters) — drops fields that don't
    change the row count (columns, aggregations, group_by, order_by, limit,
    offset).

    BF-414 — ``username`` was previously absent from the key.  With Phase 141
    row-level security the executed SQL is rewritten per user, so two users
    asking for "the same" estimate get different actual row counts.  Without
    user scoping, user A's count (after RLS restriction) was being served to
    user B from cache — a row-security bypass plus a confidentiality leak.
    """
    import hashlib
    import json as _json
    files = []
    for f in (query_config_model.files or []):
        if isinstance(f, str):
            files.append(f)
        elif hasattr(f, 'path'):
            files.append(getattr(f, 'path', ''))
        elif isinstance(f, dict):
            files.append(f.get('path', ''))
    filters = []
    for f in (query_config_model.filters or []):
        if hasattr(f, 'model_dump'):
            d = f.model_dump()
        elif isinstance(f, dict):
            d = dict(f)
        else:
            d = {}
        # Only the fields that change the row count
        filters.append({
            "column": d.get("column"),
            "operator": d.get("operator"),
            "value": d.get("value"),
            "value2": d.get("value2"),
            "values": d.get("values"),
        })
    payload = {
        "user": username or "",
        "conn": connection_id,
        "files": sorted(files),
        "filters": filters,
    }
    return hashlib.sha256(_json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


def _estimate_cache_get(key: str) -> Optional[dict]:
    with _ESTIMATE_CACHE_LOCK:
        entry = _ESTIMATE_CACHE.get(key)
        if not entry:
            return None
        ts, value = entry
        if _time.monotonic() - ts > _ESTIMATE_CACHE_TTL_SECONDS:
            _ESTIMATE_CACHE.pop(key, None)
            return None
        return value


def _estimate_cache_set(key: str, value: dict) -> None:
    with _ESTIMATE_CACHE_LOCK:
        if len(_ESTIMATE_CACHE) >= _ESTIMATE_CACHE_MAX_ENTRIES:
            now = _time.monotonic()
            expired = [k for k, (ts, _) in _ESTIMATE_CACHE.items()
                       if now - ts > _ESTIMATE_CACHE_TTL_SECONDS]
            for k in expired:
                _ESTIMATE_CACHE.pop(k, None)
            if len(_ESTIMATE_CACHE) >= _ESTIMATE_CACHE_MAX_ENTRIES:
                # Drop oldest entry to make room
                oldest = min(_ESTIMATE_CACHE, key=lambda k: _ESTIMATE_CACHE[k][0])
                _ESTIMATE_CACHE.pop(oldest, None)
        _ESTIMATE_CACHE[key] = (_time.monotonic(), value)


def _clear_estimate_cache() -> None:
    """Test hook + admin manual-invalidation path."""
    with _ESTIMATE_CACHE_LOCK:
        _ESTIMATE_CACHE.clear()


# ── Phase 142: SQL-first estimate (BQB) ──────────────────────────────────────
from pydantic import BaseModel as _BqbEstimateBase  # local import — keeps top-of-file imports lean  # noqa: E402

class _EstimateSqlRequest(_BqbEstimateBase):
    """Request for /api/execute/estimate-sql — accepts raw SQL instead of a
    visual query_config.  Used by Business Query Builder which is SQL-first.
    """
    raw_sql:       str
    connection_id: Optional[int] = None


# 2026-09-05 -- ``_DIALECT_BY_CONN_TYPE`` was declared here: a sixth copy of
# the connection-type -> sqlglot dialect vocabulary.  The estimate route both
# PARSES and EMITS in this dialect, so on a postgres / mysql / sqlserver /
# redshift / bigquery connection (none of which it knew) the user's SQL was
# parsed by DuckDB's grammar and the COUNT(*) re-emitted in it — either an
# estimate of -1 or a number produced by a statement subtly unlike the one
# that will run.  It also matched the connection type case-SENSITIVELY, so a
# stored "Trino" missed every entry.  Both are fixed by asking the one
# resolver, which lower-cases and answers for every type this product has.


def _build_count_sql_from_raw(raw_sql: str,
                              refusal: Optional[dict] = None,
                               emit_dialect: str = "duckdb",
                               parse_dialect: str = "") -> Optional[str]:
    """Use sqlglot to wrap the user's SQL in a COUNT(*) estimator.

    Strategy: parse the SELECT statement, swap the projection for COUNT(*),
    strip ORDER BY + LIMIT (irrelevant when counting).  Re-emits in the
    target dialect so the COUNT is valid SQL on the actual connector.

    Note on CTEs: sqlglot parses ``WITH cte AS (...) SELECT ...`` as a
    Select with ``with_=...`` attached — so the isinstance check passes
    and the rewrite preserves the CTE definitions correctly.

    Returns the COUNT SQL string or None if rewriting would be unsafe
    (non-SELECT statement, parse error, etc).
    """
    try:
        import sqlglot
        from sqlglot import exp
        # Parse with permissive dialect so we accept whatever the user typed.
        # 2026-08-19: parse in the dialect the SQL was WRITTEN in.  This was
        # pinned to duckdb while emit_dialect was already the target's, so
        # Trino/Snowflake/Oracle SQL was parsed by the wrong grammar and then
        # re-emitted -- either failing to parse (estimate silently -1) or
        # parsing into something subtly different from what will run.
        parsed = sqlglot.parse_one(
            raw_sql, dialect=(parse_dialect or emit_dialect or "duckdb"))
        if not isinstance(parsed, exp.Select):
            # A UNION/EXCEPT/INTERSECT parses to the SET OP, not a Select, so
            # it lands here — name it rather than falling through to the
            # generic "could not parse", which reads as "your SQL is broken".
            if refusal is not None and isinstance(
                    parsed, (exp.Union, exp.Except, exp.Intersect)):
                refusal["reason"] = "UNION/EXCEPT/INTERSECT"
            return None  # only count plain SELECTs — INSERT/CREATE etc. unsupported

        # ── 2026-08-21 — SHAPES WHERE A PROJECTION SWAP IS NOT THE ROW COUNT ──
        # Swapping the projection for COUNT(*) keeps the rest of the statement,
        # so a GROUP BY survives and the "count" comes back as ONE ROW PER
        # GROUP.  The caller reads rows[0] — i.e. the size of one arbitrary
        # group — and shows it as the estimated row count.  The operator's
        # query GROUPs on ~19 columns, so the chip was reporting one group's
        # size as the total, AND paying a full Starburst query to get it.
        #
        # This is exactly the skip-list the ETL arrived at the hard way
        # (memory: count_wrapper_removal_regression / etl_oracle_count_
        # completeness).  There, `_derive_count_sql` SKIPS these shapes and
        # returns the -1 "count unavailable" sentinel rather than a number
        # that is wrong.  A wrong estimate is worse than no estimate: it is
        # indistinguishable from a right one.
        #
        # Deliberate difference from the ETL: we still DROP `limit`, because
        # the ETL asks "how many rows did I load" (LIMIT matters) while a cost
        # chip asks "how much will this scan" (it does not).  ORDER BY and
        # OFFSET likewise cannot change a count.
        for _bad in ("group", "having", "qualify", "distinct"):
            if parsed.args.get(_bad):
                logger.debug(
                    "estimate-sql: refusing to count a %s query — a projection "
                    "swap keeps the clause and returns one row per group, not "
                    "the row count.", _bad.upper())
                if refusal is not None:
                    refusal["reason"] = {
                        "group": "GROUP BY", "having": "HAVING",
                        "qualify": "QUALIFY", "distinct": "DISTINCT",
                    }[_bad]
                return None
        # A UNION/EXCEPT/INTERSECT arm is a set operation, not this SELECT's
        # row count; `parse_one` hands back the set op, but guard the nested
        # form too.
        if parsed.find(exp.Union, exp.Except, exp.Intersect) is not None:
            logger.debug("estimate-sql: refusing to count a set-operation query")
            if refusal is not None:
                refusal["reason"] = "UNION/EXCEPT/INTERSECT"
            return None

        # Swap projection: SELECT * / cols → SELECT COUNT(*)
        count_select = parsed.copy()
        count_select.set("expressions", [exp.alias_(exp.Count(this=exp.Star()), "cnt")])
        # Drop irrelevant clauses (counts don't care about ordering/pagination)
        for clause in ("order", "limit", "offset"):
            count_select.set(clause, None)
        return count_select.sql(dialect=emit_dialect)
    except Exception as exc:
        logger.debug("estimate-sql: sqlglot rewrite failed: %s", exc)
        return None


def _extract_first_table(raw_sql: str) -> Optional[str]:
    """Pull the first FROM table out of the SQL — used for file-count
    estimation when the table is registered in QueryStudio."""
    try:
        import sqlglot
        from sqlglot import exp
        parsed = sqlglot.parse_one(raw_sql, dialect="duckdb")
        if parsed is None:
            return None
        for table in parsed.find_all(exp.Table):
            return table.name
    except Exception:
        pass
    return None


# BF-417 — pre-execution cache visibility.  Returns cache metadata
# (cached?, age, hit_count, ttl_remaining) WITHOUT serving the cached
# parquet, so the BQB can render a "⚡ Cached 2h 34m ago — Use cached /
# Run fresh" banner before the user commits.  The matching invalidate
# endpoint below drops the cache key when the user picks "Run fresh".
class _CacheStatusRequest(_BqbEstimateBase):
    """Request shape for /api/execute/cache-status — same fields the
    execute endpoint uses to compute the cache key."""
    raw_sql:       str
    files:         List[Any] = []
    params:        Optional[dict] = None
    connection_id: Optional[int] = None


@router.post("/api/execute/cache-status")
async def get_query_cache_status(
    request: _CacheStatusRequest,
    _user: dict = Depends(get_current_user),
):
    """BF-417 — peek the result_cache for the given query without
    executing or copying anything.

    Returns:
      {cached: false}  — no cached entry (or cache disabled, or
                          non-cacheable SQL)
      {cached: true, age_seconds, ttl_remaining, row_count, hit_count, ...}

    Used by the BQB to decide whether to show the "Cached / Use cached
    / Run fresh" banner.  Result_cache only — the file cache
    (s3_local_cache) is not exposed here because Iceberg files are
    immutable and a fresh execution still reads byte-identical content
    from local cache (which is correct).
    """
    raw_sql = (request.raw_sql or "").strip()
    if not raw_sql or not request.files:
        return {"cached": False, "reason": "no sql or no files"}

    try:
        from core.query_cache_integration import peek_cache_status
        from core.config import get_section as _cfg_section
    except Exception as _exc:
        logger.debug("[cache-status] import failed: %s", _exc)
        return {"cached": False, "reason": "module unavailable"}

    _rc_section = _cfg_section("result_cache") or {}
    _rc_skip = list(_rc_section.get("skip_patterns") or [])
    _username = (_user or {}).get("username", "")

    _files = list(request.files)
    # 2026-10-07 -- the execute road keys a registered Iceberg table's result
    # on its SNAPSHOT; peek with the same key or the banner never matches.
    from core.query_cache_integration import (
        iceberg_snapshot_tokens_for_connection as _peek_tokens)
    _peek_toks = await asyncio.to_thread(
        _peek_tokens, _db_manager, request.connection_id, _files, raw_sql)
    if _peek_toks is None:
        return {"cached": False,
                "reason": "an Iceberg table's current snapshot could not "
                          "be resolved"}
    _files = _files + list(_peek_toks)
    meta = await asyncio.to_thread(
        peek_cache_status,
        raw_sql, request.params or {}, _files,
        skip_patterns=_rc_skip, username=_username,
        # Phase 150 — Output Gateway: large-scan queries peek the
        # gateway instead of the local cache.
        files_after_prune=len(request.files),
        db_manager=_db_manager,
    )
    if meta is None:
        return {"cached": False}

    # Derive a human-friendly age string for the UI (saves the frontend
    # from re-implementing the same arithmetic).
    age_s = int(meta.get("age_seconds") or 0)
    if age_s < 60:
        age_human = f"{age_s}s ago"
    elif age_s < 3600:
        age_human = f"{age_s // 60}m {age_s % 60}s ago"
    elif age_s < 86400:
        age_human = f"{age_s // 3600}h {(age_s % 3600) // 60}m ago"
    else:
        age_human = f"{age_s // 86400}d {(age_s % 86400) // 3600}h ago"

    return {
        "cached":         True,
        "age_seconds":    age_s,
        "age_human":      age_human,
        "row_count":      meta.get("row_count"),
        "column_count":   meta.get("column_count"),
        "size_bytes":     meta.get("size_bytes"),
        "hit_count":      meta.get("hit_count"),
        "ttl_remaining":  meta.get("ttl_remaining"),
        "cache_key":      str(meta.get("cache_key", ""))[:16],  # for ops
        # Phase 150 — surfaces in the BQB "Cached / Use cached / Run
        # fresh" banner so the user can tell the response came from
        # the shared S3 gateway vs the per-pod local L2.
        "served_from":    meta.get("served_from"),
        "s3_uri":         meta.get("s3_uri"),
    }


@router.post("/api/execute/cache-status/invalidate")
async def invalidate_query_cache(
    request: _CacheStatusRequest,
    _user: dict = Depends(get_current_user),
):
    """BF-417 — drop the result_cache entry for this query.

    Wired to the BQB "Run fresh" button.  After invalidation the next
    /api/execute call re-populates the cache with the fresh result
    automatically (existing maybe_store_in_cache hook in the engine).
    Returns whether an entry was actually removed.
    """
    raw_sql = (request.raw_sql or "").strip()
    if not raw_sql or not request.files:
        return {"invalidated": False, "reason": "no sql or no files"}

    try:
        from core.query_cache_integration import invalidate_cache_for_query
    except Exception as _exc:
        logger.debug("[cache-status] invalidate import failed: %s", _exc)
        return {"invalidated": False, "reason": "module unavailable"}

    _username = (_user or {}).get("username", "")
    _files = list(request.files)
    # 2026-10-07 -- same snapshot-carrying key the execute road stores under.
    from core.query_cache_integration import (
        iceberg_snapshot_tokens_for_connection as _inv_tokens)
    _inv_toks = await asyncio.to_thread(
        _inv_tokens, _db_manager, request.connection_id, _files, raw_sql)
    if _inv_toks:
        _files = _files + list(_inv_toks)
    removed = await asyncio.to_thread(
        invalidate_cache_for_query,
        raw_sql, request.params or {}, _files,
        username=_username,
        # Phase 150 — large-scan queries also invalidate the S3
        # gateway entry so "Run fresh" re-populates from source.
        files_after_prune=len(request.files),
        db_manager=_db_manager,
    )
    if removed:
        logger.info(
            "[cache-status] invalidated by user=%s sql_len=%d files=%d",
            _username, len(raw_sql), len(request.files),
        )
    return {"invalidated": bool(removed)}


# ─── Phase 147.1 — pruning-hostile filter classifier endpoint ──────────


@router.post("/api/queries/classify-filters")
async def classify_filters_endpoint(
    body: Dict[str, Any],
    _user: dict = Depends(get_current_user),
):
    """Phase 147.1 — pre-flight pruning-hostile filter classifier.

    Same classifier feeds the post-execution filter_breakdown in
    iceberg_reader, so the verdict shown at submit-time matches the
    verdict in Query Diagnostics post-run.

    Body: {
        connection_id: int,             # S3 iceberg connection
        table_name:    str,             # registered table name (optional —
                                        # falls back to plain operator-only
                                        # classification when missing)
        filters: List[{col, op, val}],  # WHERE-clause filters to classify
    }

    Response: {
        results: List[ClassificationResult.to_dict()],
        verdict: {
            total, by_level, worst, rewrites_available,
        },
        spec: {
            partition_columns, bucket_transforms, time_projections,
            supplement_columns,
        },
    }

    Returns empty results when ``query_guardrails.warn_pruning_hostile_filters``
    is false — frontend treats that as "warnings disabled, render nothing".
    Honours ``query_guardrails.enabled`` master toggle.
    """
    # Master + per-feature kill switches.
    try:
        from core.config import get as _cfg_get
        if not bool(_cfg_get("query_guardrails", "enabled", True)):
            return {"results": [], "verdict": None, "spec": None,
                    "skipped_reason": "query_guardrails.enabled=false"}
        if not bool(_cfg_get(
                "query_guardrails", "warn_pruning_hostile_filters", True)):
            return {"results": [], "verdict": None, "spec": None,
                    "skipped_reason":
                        "query_guardrails.warn_pruning_hostile_filters=false"}
    except Exception:
        pass

    filters = body.get("filters") or []
    raw_sql = (body.get("raw_sql") or "").strip()
    sql_dialect = body.get("sql_dialect")  # optional sqlglot dialect hint
    extracted_from_sql: List[Dict[str, Any]] = []

    # Phase 147 follow-up — raw-SQL path for CQB / API explorer.  When
    # ``filters`` is missing but ``raw_sql`` is provided, we parse
    # the SQL via sqlglot, extract leaf predicates, and feed them to
    # the same classifier.  Parse failures + unsupported AST shapes are
    # silently skipped (caller still sees an empty results array rather
    # than a 4xx — same fail-OPEN posture as the rest of the brain).
    if (not isinstance(filters, list) or not filters) and raw_sql:
        try:
            from core.pruning_support import extract_filters_from_sql
            extracted_from_sql = extract_filters_from_sql(
                raw_sql, dialect=sql_dialect,
            )
            filters = extracted_from_sql
        except Exception as _ex_exc:
            logger.debug(
                "[classify-filters] raw-SQL extraction failed: %s",
                _ex_exc,
            )

    if not isinstance(filters, list) or not filters:
        # 2026-06-10 brain coverage — emit a structured full-scan
        # verdict instead of an empty result so the editor can warn
        # the user "this query has NO filters; it will scan everything".
        # Previously the empty body was rendered as silent green = "no
        # warnings", encouraging accidental table-wide scans.
        full_scan_verdict = {
            "worst":               "full_scan",
            "by_level":            {"full_scan": 1},
            "total":               1,
            "rewrites_available":  0,
            "message": (
                "No WHERE filters were supplied — this query will scan "
                "every file in the table.  Add at least one filter on "
                "a partition or bucket column to enable pruning."
            ),
        }
        return {
            "results":              [],
            "verdict":              full_scan_verdict,
            "spec":                 None,
            "extracted_filters":    extracted_from_sql,
            "auto_apply_enabled":   False,
            "full_scan_warning":    True,
        }

    cid = body.get("connection_id")
    tbl = body.get("table_name") or ""

    def _do():
        from core.pruning_support import (
            PruneSupportClassifier,
            build_table_spec_from_iceberg_metadata,
            TableSpec,
        )
        spec: Optional[TableSpec] = None
        spec_summary: Dict[str, Any] = {}

        # Best-effort spec resolution — when connection_id + table_name
        # are valid iceberg, classifier becomes column-aware.  Failure
        # falls through to operator-only verdicts (still useful).
        if cid and tbl:
            try:
                from core.s3_utilities import make_s3_client_for_conn
                from core.iceberg_reader import (
                    _latest_metadata_key, _read_s3_json_cached,
                )
                conn = _db_manager.get_connection_raw(cid)
                if conn and conn.get("connection_type") == "s3":
                    cfg = conn.get("config", {}) or {}
                    bucket = cfg.get("bucket_name") or ""
                    rt = next(
                        (t for t in cfg.get("registered_tables", []) or []
                         if t.get("name") == tbl),
                        None,
                    )
                    if bucket and rt and rt.get("format") == "iceberg":
                        s3 = make_s3_client_for_conn(conn)
                        prefix = (rt.get("s3_prefix") or "").rstrip("/")
                        meta_prefix = prefix + "/metadata/"
                        meta_key = _latest_metadata_key(
                            s3, bucket, meta_prefix, force_fresh=False,
                        )
                        meta = _read_s3_json_cached(s3, bucket, meta_key)
                        # Supplement columns (cheap aggregate)
                        sup_cols: set = set()
                        try:
                            from core.db.models import (
                                IcebergColumnStatsSupplement,
                            )
                            with _db_manager.get_session(read_only=True) as session:
                                rows = (
                                    session.query(IcebergColumnStatsSupplement.column_name)
                                    .filter(
                                        IcebergColumnStatsSupplement.bucket == bucket,
                                        prefix_matches(IcebergColumnStatsSupplement.table_prefix, prefix),
                                    )
                                    .distinct()
                                    .all()
                                )
                                for (c,) in rows:
                                    if c:
                                        sup_cols.add(str(c).lower())
                        except Exception:
                            pass
                        spec = build_table_spec_from_iceberg_metadata(
                            meta, supplement_columns=sup_cols,
                        )
                        spec_summary = {
                            "partition_columns":  sorted(spec.partition_columns),
                            "bucket_transforms":  dict(spec.bucket_transforms),
                            "truncate_transforms": dict(spec.truncate_transforms),
                            "time_projections":   dict(spec.time_projections),
                            "supplement_columns": sorted(spec.supplement_columns),
                            "format":             "iceberg",
                        }
                    # Phase 151.B — plain-parquet spec path.  Same
                    # classifier, different spec producer.  Plain parquet
                    # has no partition / bucket transforms — but it
                    # DOES have supplement coverage once the parquet
                    # sync daemon runs.  Operator verdicts still apply
                    # (LIKE → unsupported, IS NULL → varies, etc.).
                    elif bucket and rt and rt.get("format") == "parquet":
                        prefix = (rt.get("s3_prefix") or "").rstrip("/")
                        sup_cols = set()
                        try:
                            from core.db.models import (
                                IcebergColumnStatsSupplement,
                            )
                            with _db_manager.get_session(read_only=True) as session:
                                rows = (
                                    session.query(IcebergColumnStatsSupplement.column_name)
                                    .filter(
                                        IcebergColumnStatsSupplement.bucket == bucket,
                                        prefix_matches(IcebergColumnStatsSupplement.table_prefix, prefix),
                                        # Honour the new format discriminator —
                                        # don't accidentally pick up iceberg
                                        # rows for the same prefix.
                                        IcebergColumnStatsSupplement.format == "parquet",
                                    )
                                    .distinct()
                                    .all()
                                )
                                for (c,) in rows:
                                    if c:
                                        sup_cols.add(str(c).lower())
                        except Exception:
                            pass
                        from core.pruning_support import (
                            build_table_spec_for_plain_parquet,
                        )
                        spec = build_table_spec_for_plain_parquet(
                            supplement_columns=sup_cols,
                        )
                        spec_summary = {
                            "partition_columns":  [],
                            "bucket_transforms":  {},
                            "truncate_transforms": {},
                            "time_projections":   {},
                            "supplement_columns": sorted(spec.supplement_columns),
                            "format":             "parquet",
                        }
            except Exception as exc:
                logger.debug(
                    "[classify-filters] spec resolution failed (falling "
                    "back to operator-only): %s", exc,
                )

        classifier = PruneSupportClassifier.get_default()
        results = classifier.classify_filters(filters, spec)
        verdict = classifier.roll_up(results)

        # Phase 147.D — surface the auto-apply flag so the editor can
        # silently apply confidence==1.0 rewrites when ops opt in.  The
        # flag stays OFF by default; flipped in config.json only after
        # Phase C acceptance metrics show ≥95% accept rate.
        try:
            from core.config import get as _cfg_get
            auto_apply_enabled = bool(_cfg_get(
                "query_guardrails",
                "auto_rewrite_pruning_hostile_ops",
                # 2026-09-15: aligned to the declared default (True).
                True,
            ))
        except Exception:
            auto_apply_enabled = False

        return {
            "results": [r.to_dict() for r in results],
            "verdict": verdict,
            "spec":    spec_summary or None,
            "auto_apply_enabled": auto_apply_enabled,
            # Echo back filters extracted from raw_sql so the caller can
            # show the user "we read these filters from your SQL" — gives
            # transparency when sqlglot couldn't extract some shapes.
            "extracted_filters": extracted_from_sql,
        }

    return await asyncio.to_thread(_do)


# ─── Phase 147.C — rewrite-applied audit log ──────────────────────────


@router.post("/api/queries/rewrite-applied")
async def rewrite_applied_endpoint(
    body: Dict[str, Any],
    request: Request,
    _user: dict = Depends(get_current_user),
):
    """Phase 147.C — fire-and-forget audit log for accepted rewrites.

    Body: {
        connection_id?: int,
        table_name?:    str,
        before: {column, operator, value},
        after:  {column, operator, value},
        confidence: float (0..1),
        reason?: str,           # classifier's explanation
        explanation?: str,      # what changes if applied
    }

    Writes one audit_log row per call so operators can see acceptance
    rate + which rewrites are popular.  Used to decide if Phase 147.D
    auto-apply is safe to flip on.  Never raises — fire-and-forget.
    """
    try:
        before = body.get("before") or {}
        after  = body.get("after")  or {}
        details = {
            "connection_id": body.get("connection_id"),
            "table_name":    body.get("table_name"),
            "before":        before,
            "after":         after,
            "confidence":    body.get("confidence"),
            "reason":        body.get("reason"),
            "explanation":   body.get("explanation"),
        }
        from core.audit import audit_event
        audit_event(
            _db_manager, _user, request,
            action="pruning_rewrite_applied",
            resource_type="filter",
            resource_id=str(before.get("column") or ""),
            details=details,
        )
    except Exception as exc:
        logger.warning("rewrite-applied audit failed (non-fatal): %s", exc)
    return {"ok": True}


def _known_table_file_count(connection_id: int, table_name: str) -> int:
    """How many files a registered table HAS, from its recorded schema -- or
    0 when that is not known (no recorded schema, a capped listing, a read
    error).  2026-10-07 (G1): 0 means "not counted", never "one file"."""
    try:
        if _db_manager is None:
            return 0
        sc = _db_manager.get_schema_cache(int(connection_id), table_name) or {}
        data = sc.get("schema_data", sc) if isinstance(sc, dict) else {}
        if not isinstance(data, dict):
            return 0
        if str(data.get("format") or "").lower() == "iceberg":
            return max(0, int(data.get("data_file_count") or data.get("num_files") or 0))
        if data.get("num_files_is_capped"):
            return 0
        return max(0, int(data.get("num_files") or 0))
    except Exception as exc:  # noqa: BLE001 -- unknown, never a guess
        logger.debug("estimate-sql: file count for %s unknown: %s", table_name, exc)
        return 0


@router.post("/api/execute/estimate-sql")
async def estimate_query_sql(request: _EstimateSqlRequest,
                              _user: dict = Depends(get_current_user)):
    """Pre-flight estimate for raw SQL — Business Query Builder uses this
    because it's SQL-first (no visual query_config to send).

    Returns the same shape as POST /api/execute/estimate:
        {estimated_rows: int, estimated_files: int, pushdown_warning?: ...}

    estimated_rows = -1 when the count can't be derived (parse error,
    unsupported SQL shape, or registered tables that don't have row counts
    until materialized).

    Caching: uses an in-memory LRU keyed on (connection_id, sql).  Same
    semantics as /estimate — cached for 5 min, dropped on schema change.
    """
    raw_sql = (request.raw_sql or "").strip()
    if not raw_sql:
        return {"estimated_rows": 0, "estimated_files": 0}

    # SECURITY 2026-08-23 (Phase 2A): this endpoint runs a COUNT(*) against
    # the actual connector with the connection's stored credentials.  Gate
    # it on the SAME entitlement decision as /api/execute so a non-owner can
    # neither drive an outbound query on another analyst's private warehouse
    # nor read its (even RLS-filtered) cardinality by id.
    await asyncio.to_thread(
        _require_conn_entitlement_exec, _user, [request.connection_id])

    # ── Cache lookup ────────────────────────────────────────────────────
    # SHA256 of (kind, user, conn, sql) — same hashing scheme as the visual-
    # builder estimate cache so they share the same TTL/eviction semantics.
    # BF-414 — username included so Phase 141 RLS-rewritten counts stay
    # scoped to the user that issued them.
    import hashlib as _h
    _username_for_cache = (_user or {}).get("username", "")
    _cache_key = _h.sha256(
        f"sql|{_username_for_cache}|{request.connection_id}|{raw_sql}".encode("utf-8"),
    ).hexdigest()
    _cached = _estimate_cache_get(_cache_key)
    if _cached is not None:
        return {**_cached, "from_cache": True}

    # ── Resolve connection FIRST so we know which dialect to emit ──────
    conn_record = None
    _conn_type = None
    _cfg = {}
    if request.connection_id:
        conn_record = await adb(_db_manager.get_connection_raw, request.connection_id)
        if conn_record:
            _conn_type = conn_record.get("connection_type")
            _cfg = conn_record.get("config") or {}

    # ── Build COUNT(*) variant in the target connector's dialect ───────
    emit_dialect = dialect_for_connection_type(_conn_type)

    # 2026-08-19 -- COUNT WHAT THE CALLER CAN SEE.  The estimate was built
    # from the RAW SQL with no row-security rewrite, so on a policy-governed
    # table it reported the UNFILTERED cardinality: a number the user is not
    # entitled to, and one that disagrees with the result they then get.
    _count_src = raw_sql
    try:
        from core.row_security import secure_sql as _rs_est
        _count_src = await asyncio.to_thread(
            _rs_est, raw_sql, dialect=emit_dialect, user_ctx=_user,
            connection_id=request.connection_id,
        ) or raw_sql
    except Exception as _rs_est_exc:
        # No estimate beats an unfiltered one: this number would otherwise
        # disclose the cardinality of rows the policy hides.
        logger.warning(
            "estimate-sql: row-security rewrite failed (%s) -- returning no "
            "estimate rather than an unfiltered count", _rs_est_exc)
        return {"estimated_rows": -1, "estimated_files": 0,
                "note": "Row-security enforcement unavailable for estimation"}

    _est_refusal: dict = {}
    count_sql = _build_count_sql_from_raw(
        _count_src, emit_dialect=emit_dialect, parse_dialect=emit_dialect,
        refusal=_est_refusal)
    if not count_sql:
        # 2026-08-21 — say WHICH, so "no estimate" is not confused with
        # "your SQL is broken".  A refusal is a deliberate answer: for these
        # shapes a projection-swap count is not the row count, and the only
        # correct alternative (wrapping the query) is the pattern that OOM'd
        # Trino workers.
        _why = _est_refusal.get("reason")
        return {
            "estimated_rows": -1,
            "estimated_files": 0,
            "note": (
                f"Row estimate not available for {_why} queries — counting "
                f"them needs a wrapped sub-query, which re-scans every column "
                f"on the source. Run the query to get exact rows."
                if _why else "Could not parse SQL for row estimation"
            ),
        }

    # File count: the first registered table's KNOWN file count, else 0
    # ("not counted" -- the chip and the pruning hint then print no number).
    # 2026-10-07 (G1, Docker proof on real AWS): this was a constant 1 for
    # any registered table -- a placeholder that the pruning hint printed as
    # "this query reads every file (~1 files)" for a 2,688-file table.  A
    # number we do not know is never printed: it comes from the RECORDED
    # schema (Iceberg: the snapshot's total-data-files; plain parquet: the
    # listing count unless that listing was capped), never from a guess.
    estimated_files = 0
    first_table = _extract_first_table(raw_sql)
    if first_table and _cfg and request.connection_id:
        for rt in (_cfg.get("registered_tables") or []):
            if rt.get("name") == first_table:
                estimated_files = await asyncio.to_thread(
                    _known_table_file_count, request.connection_id, first_table)
                break

    # ── Execute COUNT(*) ────────────────────────────────────────────────
    estimated_rows = -1
    try:
        if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
            # SQL connector path — runs on the actual database
            # 2026-10-07: off the loop -- a system-account connection reads its row (and Vault) here.
            sql_connector = await asyncio.to_thread(
                get_connector,
                _conn_type, _cfg, request.connection_id,
                conn_record.get("name", "") if conn_record else "",
            )
            # BF-593: get_event_loop() is deprecated on Py 3.12+ when no
            # loop is running; use get_running_loop() in async contexts.
            result = await asyncio.get_running_loop().run_in_executor(
                None, lambda: sql_connector.execute_query(count_sql, limit=None),
            )
            # 2026-08-19 -- SqlConnector.execute_query returns the ENVELOPE
            # {"columns": [...], "rows": [...], "total_rows": n}, not a row
            # list.  The old code took list(envelope.values())[0], i.e. the
            # COLUMNS list, and int() on it raised TypeError into the broad
            # except below -- so this estimate was ALWAYS -1 on every SQL
            # connector, silently, at debug level.  Unwrap the envelope first,
            # then handle both dict-row and tuple-row shapes.
            rows = result
            if isinstance(result, dict):
                rows = result.get("rows")
            if rows:
                row = rows[0] if isinstance(rows, (list, tuple)) else rows
                if isinstance(row, dict):
                    vals = list(row.values())
                    estimated_rows = int(vals[0] or 0) if vals else 0
                elif isinstance(row, (list, tuple)):
                    estimated_rows = int(row[0] or 0) if row else 0
                else:
                    estimated_rows = int(row or 0)
        else:
            # DuckDB path (s3 / local) — wrap the sync execute in to_thread
            # so a slow query doesn't block the asyncio loop.  Without this,
            # the 800ms debounce becomes 800ms+(query_time) of starved loop.
            from api.data_grid_api import _duckdb_con_with_s3
            from core.duckdb_factory import duckdb_connection

            def _run_count_local():
                if _conn_type == "s3":
                    _con = _duckdb_con_with_s3(_cfg, connection_id=request.connection_id)
                    try:
                        r = _con.execute(count_sql).fetchone()
                        return int(r[0] or 0) if r else 0
                    finally:
                        try:
                            _con.close()
                        except Exception:
                            pass
                else:
                    with duckdb_connection() as _con:
                        r = _con.execute(count_sql).fetchone()
                        return int(r[0] or 0) if r else 0
            estimated_rows = await asyncio.to_thread(_run_count_local)
    except Exception as exc:
        # Estimation failures should NEVER block the user from running the
        # actual query — log + return -1 so the UI just doesn't show a chip.
        logger.debug("estimate-sql execute failed: %s", exc)
        estimated_rows = -1

    # ── Pushdown warning: simple heuristics on the raw SQL ──────────────
    pushdown_warning = None
    upper_sql = raw_sql.upper()
    has_where = " WHERE " in upper_sql or "\nWHERE " in upper_sql
    has_limit = " LIMIT " in upper_sql or "\nLIMIT " in upper_sql
    if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
        if not has_where and not has_limit:
            pushdown_warning = {
                "warn":   True,
                "level":  "high",
                "reason": "no_where_no_limit_on_connector",
                "hint":   "No WHERE / LIMIT — connector will pull every row.",
            }

    result = {
        "estimated_rows":  estimated_rows,
        "estimated_files": estimated_files,
    }
    if pushdown_warning:
        result["pushdown_warning"] = pushdown_warning
    if estimated_rows >= 0:
        _estimate_cache_set(_cache_key, result)
    return result


@router.post("/api/execute/estimate")
async def estimate_query(request: EstimateRequest, _user: dict = Depends(get_current_user)):
    """Return estimated row count and file count without executing the full query."""
    # SECURITY 2026-08-23 (Phase 2A): the S3/SQL-connector branch below opens
    # a real DuckDB/connector COUNT with stored credentials.  Same entitlement
    # gate as /api/execute -- a caller not entitled to the connection gets no
    # estimate (and drives no outbound query).  ABOVE the try on purpose: the
    # broad except below must not downgrade a 404 authz decision to a 200.
    _effective_conn_id = request.connection_id or request.query_config.connection_id
    await asyncio.to_thread(
        _require_conn_entitlement_exec, _user, [_effective_conn_id])
    try:
        query_config_model = request.query_config

        # BF-248: cache lookup BEFORE doing any work.  Skip cache for the
        # registered-tables and MV/local-tables fast paths because those
        # already return in <10 ms — caching adds no value there.
        # BF-414: scope the key by username so RLS-rewritten counts don't
        # leak across users.
        _cache_key = _estimate_cache_key(
            _effective_conn_id, query_config_model,
            username=(_user or {}).get("username", ""),
        )
        _cached = _estimate_cache_get(_cache_key)
        if _cached is not None:
            return {**_cached, "from_cache": True}

        if not query_config_model.files:
            return {"estimated_rows": 0, "estimated_files": 0}

        # 2026-06-24 -- JOIN queries skip the pre-execution COUNT.  Operator
        # reported: "CQB, trying joining two table n selected partion th 3
        # partition on both side ... query is taking forever ... pre-execution
        # check 500s ... not smart ... failed".
        #
        # The pre-exec COUNT for a JOIN with 2x partition-filtered tables
        # re-opens DuckDB, registers views for BOTH file lists, runs a full
        # SELECT COUNT(*) FROM t1 JOIN t2.  Even with the file lists already
        # partition-pruned, DuckDB still reads each file's footer to compute
        # the count -- O(files) network round trips.  For a 4000-file
        # partition-pruned join that's 500s of pre-exec work for a single
        # number the user usually ignores.
        #
        # Strategic call: SKIP the estimate for joins.  Return -1 with a
        # human-readable note (same shape as the registered-tables path).
        # The actual Run still does its own pruning + execution at full
        # speed -- no functionality lost, ~500s saved per CQB join click.
        # Operators who need a row count run the query for real.
        if query_config_model.joins:
            return {
                "estimated_rows": -1,
                "estimated_files": len(query_config_model.files),
                "note": (
                    "Row estimation skipped for JOIN queries -- the "
                    "pre-execution COUNT(*) over a join re-opens every "
                    "file's footer.  Hit Run to execute; the brain "
                    "applies partition + bloom pruning then."
                ),
            }

        # ── Registered tables — return file count only (can't COUNT without views) ──
        _file_paths = [
            (f if isinstance(f, str) else (f.path if hasattr(f, 'path') else ''))
            for f in query_config_model.files
        ]
        _has_registered = any(p.startswith("__registered__:") for p in _file_paths)
        if _has_registered:
            return {
                "estimated_rows": -1,
                "estimated_files": len(query_config_model.files),
                "note": "Row estimation not available for registered tables",
            }

        # MV / local table — return stored row count directly (instant, no S3 needed)
        _has_mv = any(p.startswith("__materialized__:") for p in _file_paths)
        _has_lt = any(p.startswith("__local__:") for p in _file_paths)
        if _has_mv or _has_lt:
            total_rows = 0
            for p in _file_paths:
                if p.startswith("__materialized__:"):
                    mv_name = p.replace("__materialized__:", "")
                    mv_rec = await adb(_db_manager.get_materialized_view_by_name, mv_name)
                    if mv_rec:
                        total_rows += mv_rec.get("row_count", 0)
                elif p.startswith("__local__:"):
                    lt_name = p.replace("__local__:", "")
                    lt_rec = await adb(_db_manager.get_local_table_by_name, lt_name)
                    if lt_rec:
                        total_rows += lt_rec.get("row_count", 0)
            return {
                "estimated_rows": total_rows,
                "estimated_files": len(query_config_model.files),
            }

        # Resolve connection
        conn_record = None
        _conn_type = None
        _cfg = {}
        if _effective_conn_id:
            conn_record = await adb(_db_manager.get_connection_raw, _effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})

        # ── SQL connector path (Trino, Snowflake, Databricks, Oracle) ──
        if _conn_type and _conn_type in SQL_CONNECTOR_TYPES:
            # 2026-09-05 round 2 -- the SAME chokepoint the run path uses.
            # This door does not merely BUILD the SQL, it EXECUTES a
            # COUNT(*) over it on the remote engine, so a de-qualified
            # ``__registered__:sales`` reported the row count OF A
            # DIFFERENT TABLE, as a number, to the user.
            #
            # DELIBERATELY NOT A 400: an estimate is advisory and already
            # has a vocabulary for "cannot tell" (``estimated_rows: -1``).
            # Turning a pre-flight into a hard error would be a new
            # outage on a surface whose answer is a hint.  What it must
            # not do -- and now does not -- is answer a confident WRONG
            # number.  ``note`` carries the reason so the caller can tell
            # "could not estimate, and here is why" from "no rows".
            try:
                table_ref = _native_from_ref(
                    query_config_model.files,
                    getattr(query_config_model, "joins", None), _conn_type)
            except _QueryNotExpressible as _qne_est:
                logger.info("[estimate] not expressible on %s: %s",
                            _conn_type, _qne_est)
                return {"estimated_rows": -1,
                        "estimated_files": len(query_config_model.files or []),
                        "note": str(_qne_est)}
            if table_ref is None:
                table_ref = (query_config_model.files[0]
                             if query_config_model.files else None)
            if not table_ref:
                return {"estimated_rows": -1, "estimated_files": 0}

            # Build filter-only query, then wrap with COUNT(*)
            estimate_model = query_config_model.model_copy(update={
                "limit": None, "offset": 0, "aggregations": None,
                "group_by": None, "order_by": None, "columns": None,
            })
            try:
                from core.date_resolver import CalendarTokenRefused, resolve_filter_dates
                if estimate_model.filters:
                    resolved = resolve_filter_dates(estimate_model.filters)
                    estimate_model = estimate_model.model_copy(update={"filters": resolved})
            except CalendarTokenRefused:
                raise          # a filter that cannot be rendered refuses (400)
            except Exception as _dr_exc:
                logger.warning("Failed to resolve filter dates for SQL estimate: %s", _dr_exc, exc_info=True)

            engine_config = convert_query_config_to_engine(estimate_model)
            full_sql = _engine.build_query_sql(
                engine_config, table_ref, dialect=_conn_type)

            # Replace SELECT ... FROM with SELECT COUNT(*) FROM
            from_idx = full_sql.upper().find("\nFROM ")
            if from_idx == -1:
                from_idx = full_sql.upper().find(" FROM ")
            if from_idx == -1:
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:]

            # Execute via connector (runs on the actual database)
            try:
                # 2026-09-16 — THIS CONNECTOR WAS NEVER CLOSED.  The only
                # close() in this 300-line function belongs to a DuckDB
                # connection further down, so every row-count estimate
                # against a Starburst / Snowflake / Oracle dataset opened a
                # source session and abandoned it: sessions accumulated on
                # the source cluster until its own idle timeout reaped them.
                #
                # Closed with a try/finally rather than borrowed from the
                # pool ON PURPOSE.  Pooling here means calling
                # get_pooled_connector, which resolves the factory through
                # core.connectors -- and three tests in
                # test_one_chokepoint_preview_and_run_2026_09_05.py patch
                # ``execute_api.get_connector`` by object.  Routing around
                # that seam made a unit test open a real Trino socket.  The
                # LEAK is the defect; pooling this site is a separate change
                # that has to move the patch target with it.
                # 2026-10-07: off the loop -- a system-account connection reads its row (and Vault) here.
                sql_connector = await asyncio.to_thread(
                    get_connector, _conn_type, _cfg, _effective_conn_id,
                    conn_record.get("name", "") if conn_record else "")
                try:
                    # BF-593: get_event_loop() deprecated on Py 3.12+.
                    result = await asyncio.get_running_loop().run_in_executor(
                        None, lambda: sql_connector.execute_query(count_sql, limit=None)
                    )
                finally:
                    try:
                        sql_connector.close()
                    except Exception:
                        logger.debug("estimate connector close failed",
                                     exc_info=True)
                rows = result.get("rows", [])
                if rows:
                    # Column name may be 'cnt', 'CNT', etc. depending on DB dialect
                    row = {k.lower(): v for k, v in rows[0].items()}
                    estimated_rows = row.get("cnt", 0)
                else:
                    estimated_rows = 0
            except Exception as exc:
                logger.warning("SQL connector estimate failed (%s): %s", _conn_type, exc, exc_info=True)
                return {"estimated_rows": -1, "estimated_files": len(query_config_model.files)}

            # Phase 139 (Tier 1.2): SELECT-* / unfiltered warning chip
            _pushdown_warning = None
            try:
                _has_filters = bool(query_config_model.filters)
                _has_limit = bool(query_config_model.limit and int(query_config_model.limit) > 0)
                _has_aggs = bool(query_config_model.aggregations)
                _has_cols = bool(query_config_model.columns)
                _is_big = isinstance(estimated_rows, (int, float)) and estimated_rows > 100_000
                # Warn only when the query is broad: no filters AND no LIMIT AND
                # not narrowed by an aggregation. Bonus weight if the table is large.
                if not _has_filters and not _has_limit and not _has_aggs:
                    _pushdown_warning = {
                        "warn":   True,
                        "level":  "high" if _is_big else "low",
                        "reason": "select_all_unfiltered",
                        "hint":   (
                            "Add a WHERE filter or LIMIT — this query will fetch "
                            "every row from the source database, which is slow and "
                            "expensive on warehouse credits."
                        ),
                    }
                elif not _has_cols and not _has_filters and not _has_limit:
                    _pushdown_warning = {
                        "warn":   True,
                        "level":  "low",
                        "reason": "select_star_no_projection",
                        "hint":   "Pick the columns you need so the connector can prune projection.",
                    }
            except Exception:
                _pushdown_warning = None

            _resp = {
                "estimated_rows": estimated_rows,
                "estimated_files": len(query_config_model.files),
            }
            if _pushdown_warning:
                _resp["pushdown_warning"] = _pushdown_warning
            # BF-248: cache the SQL-connector estimate too
            if isinstance(estimated_rows, (int, float)) and estimated_rows >= 0:
                _estimate_cache_set(_cache_key, _resp)
            return _resp

        # ── Parquet path (local / S3) ──
        active_engine = _engine
        if _conn_type == 'local':
            local_path = str(_normalize_path(_cfg.get('base_path', '/usr/local/querystudioapi/nfs/data/parquet')))
            active_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
        elif _conn_type == 's3':
            # OFF the loop: boto3 client build inside __init__ blocks (see execute).
            _est_s3_config = build_s3_config(_cfg)
            active_engine = await asyncio.to_thread(
                ParquetQueryEngine,
                base_path=str(_paths.parquet_dir), chunk_size=_qe_cfg.chunk_size,
                s3_config=_est_s3_config,
            )

        # Build filter-only query
        estimate_model = query_config_model.model_copy(update={
            "limit": None, "offset": 0, "aggregations": None,
            "group_by": None, "order_by": None, "columns": None,
        })
        try:
            from core.date_resolver import CalendarTokenRefused, resolve_filter_dates
            if estimate_model.filters:
                resolved = resolve_filter_dates(estimate_model.filters)
                estimate_model = estimate_model.model_copy(update={"filters": resolved})
        except CalendarTokenRefused:
            raise          # a filter that cannot be rendered refuses (400)
        except Exception as _dr_pq_exc:
            logger.warning("Failed to resolve filter dates for parquet estimate: %s", _dr_pq_exc, exc_info=True)

        engine_config = convert_query_config_to_engine(estimate_model)
        from_clause = active_engine._build_duckdb_from_clause(engine_config)
        full_sql = active_engine.build_query_sql(engine_config, from_clause)

        from_idx = full_sql.upper().find("\nFROM ")
        if from_idx == -1:
            from_idx = full_sql.upper().find(" FROM ")
        count_sql = "SELECT COUNT(*) AS cnt" + full_sql[from_idx:] if from_idx != -1 else None

        estimated_rows = 0
        if count_sql:
            from api.data_grid_api import _duckdb_con_with_s3
            from core.duckdb_factory import duckdb_connection

            def _run_count_visual():
                if _conn_type == 's3':
                    _con = _duckdb_con_with_s3(_cfg, connection_id=_effective_conn_id)
                    try:
                        r = _con.execute(count_sql).fetchone()
                        return r[0] if r else 0
                    finally:
                        try:
                            _con.close()
                        except Exception:
                            pass
                else:
                    with duckdb_connection() as _con:
                        r = _con.execute(count_sql).fetchone()
                        return r[0] if r else 0
            # BF-WS-NOBLOCK: wrap sync DuckDB execute so the asyncio loop
            # isn't blocked while the COUNT runs.
            estimated_rows = await asyncio.to_thread(_run_count_visual)

        _result = {
            "estimated_rows": estimated_rows,
            "estimated_files": len(query_config_model.files),
        }
        # BF-248: store in cache for future identical estimates.  Skip caching
        # error sentinels (-1) so transient failures don't poison the cache.
        if estimated_rows >= 0:
            _estimate_cache_set(_cache_key, _result)
        return _result
    except Exception as e:
        # NOTE: the entitlement gate runs ABOVE this try (so its 404 is never
        # reachable here) precisely so this broad handler cannot downgrade an
        # authz decision to a 200 estimated_rows:-1.
        logger.error("Estimate error: %s", e, exc_info=True)
        return {"estimated_rows": -1, "estimated_files": len(request.query_config.files or []),
                "error": str(e)}


_STUB_NESTED_PREFIXES = ("STRUCT", "MAP", "LIST", "ARRAY", "UNION")


def _stub_column_type(raw_type: Any) -> str:
    """The DuckDB type a pre-validation stub column is declared with.

    Nested types collapse to VARCHAR (the binder still gets the NAME for
    ambiguity checks).  2026-10-06: "nested" is decided by the type's OWN
    head -- ``STRUCT(...)``, ``MAP(...)``, ``LIST``/``ARRAY``, ``list<...>``
    (``INTEGER[]`` is CAST-able and kept) -- never by a substring: ``"ARRAY" in "FIXED_LEN_BYTE_ARRAY"``
    made every parquet DECIMAL (stored as FIXED_LEN_BYTE_ARRAY) and every
    string (BYTE_ARRAY) a VARCHAR stub, and pre-validation then REFUSED a
    valid ``sum(gbp_currency_amount)`` with "No function matches
    'sum(VARCHAR)'".  Anything else passes through; a type DuckDB cannot CAST
    to makes the stub fail and the table is skipped (fail-open), never
    guessed."""
    ctype = str(raw_type or "VARCHAR").strip().upper() or "VARCHAR"
    head = ctype.split("(", 1)[0].split("<", 1)[0].strip()
    if head in _STUB_NESTED_PREFIXES:
        return "VARCHAR"
    return ctype


def _referenced_in_sql(sql: Optional[str], name: str) -> bool:
    """Cheap, conservative: does the statement text mention this table name
    as a word?  Used only to bound the Iceberg currency checks below."""
    if not sql or not name:
        return False
    import re as _re_ref
    return _re_ref.search(r'(?<![\w$])' + _re_ref.escape(name.lower()) + r'(?![\w$])',
                          sql.lower()) is not None


def _stale_iceberg_stub(connection_id: int, conn_record: dict, tdef: dict,
                        cached: dict) -> bool:
    """2026-10-06 -- a cached ICEBERG schema read before an ``ALTER TABLE``
    lacks the new column, so a stub built from it REFUSES a valid query that
    names it ("column not found", a false 400).  Stale -> rebuild from the
    live current schema (the backfill below)."""
    if str((tdef or {}).get("format") or "").lower() != "iceberg":
        return False
    try:
        from api.connections_api import _make_s3_client_for_conn
        from core.schema_reader import iceberg_schema_staleness
        cfg = (conn_record or {}).get("config") or {}
        reason = iceberg_schema_staleness(
            (cached or {}).get("schema_data"), _make_s3_client_for_conn(conn_record),
            cfg.get("bucket_name") or cfg.get("bucket") or "",
            str(tdef.get("s3_prefix") or "").rstrip("/"))
    except Exception as exc:  # noqa: BLE001 -- unknown is not stale
        logger.debug("[pre-validate] iceberg currency check failed for %s: %s",
                     tdef.get("name"), exc)
        return False
    if reason:
        logger.info("[pre-validate] cached schema for '%s' is stale (%s) -- "
                    "rebuilding its stub from the current schema",
                    tdef.get("name"), reason)
        return True
    return False


def _build_stub_views_from_schema_cache(
    con,
    connection_id: Optional[int],
    sql: Optional[str] = None,
) -> int:
    """BF-276: register empty stub views for the connection's registered
    tables using the cached schema (SchemaCache DB table).

    For each registered table on this connection that has a cached schema,
    create a 0-row view with the same columns + types.  DuckDB's EXPLAIN
    can then bind columns against these stubs — catching ambiguous
    references (column exists in 2+ FROM tables), missing columns,
    typos, etc., WITHOUT touching S3.

    Reuses the L2 cache populated by ``connections_api.py:1182`` when the
    user clicks a table in CQB / BQB.  No S3 fetch happens here — pure DB
    lookup + DuckDB CREATE VIEW.

    Returns the number of stub views created (caller uses this to decide
    whether table-not-found errors should fail-OPEN or fail-CLOSED).

    ``sql`` (2026-10-06): the statement being validated.  An ICEBERG table it
    names is checked for schema currency before its cached schema is trusted.
    """
    if not connection_id or not _db_manager:
        return 0
    try:
        # Pull the registered_tables list from the connection's config.
        conn_record = _db_manager.get_connection_raw(int(connection_id))
        if not conn_record:
            return 0
        cfg = conn_record.get("config") or {}
        regs = cfg.get("registered_tables") or []
        if not regs:
            return 0
    except Exception as exc:
        logger.debug("[pre-validate] failed to list registered tables: %s", exc)
        return 0

    created = 0
    missed_tables: List[str] = []
    for tbl in regs:
        tname = (tbl or {}).get("name") or ""
        if not tname:
            continue
        try:
            cached = _db_manager.get_schema_cache(int(connection_id), tname)
            if not cached:
                # BF-279: cache miss — record for best-effort backfill below
                missed_tables.append(tname)
                continue
            if _referenced_in_sql(sql, tname) and _stale_iceberg_stub(
                    int(connection_id), conn_record, tbl, cached):
                missed_tables.append(tname)
                continue
            sd = cached.get("schema_data") or {}
            cols = sd.get("columns") or []
            if not cols:
                continue
            # Each column is {"name": str, "type": str, ...}.  Map type
            # strings to DuckDB-acceptable types; fall back to VARCHAR if
            # the cached type is unrecognised (binder still gets a usable
            # column name for ambiguity checks).
            col_decls = []
            for c in cols:
                cname = c.get("name") or c.get("column_name") or ""
                if not cname:
                    continue
                # DuckDB-compatible coercion — keep simple types as-is,
                # collapse complex nested types to VARCHAR for the stub.
                ctype = _stub_column_type(c.get("type") or c.get("data_type"))
                col_decls.append(f'"{cname.replace(chr(34), chr(34)*2)}" {ctype}')
            if not col_decls:
                continue
            tname_esc = tname.replace('"', '""')
            # Create a 0-row VIEW with the right schema.  Using SELECT ... LIMIT 0
            # over a typed VALUES is the cheapest way to get a DuckDB binder-
            # compatible relation that costs nothing at runtime.
            ddl = (
                f'CREATE OR REPLACE TEMP VIEW "{tname_esc}" AS '
                f'SELECT * FROM (VALUES (NULL)) AS t({col_decls[0].split(chr(32))[0]}) '
                f'WHERE 1=0'
            )
            # Simpler + correct: build a schema-only query
            select_parts = [f'CAST(NULL AS {dt}) AS {nm}'
                            for nm, dt in (d.split(' ', 1) for d in col_decls)]
            ddl = (
                f'CREATE OR REPLACE TEMP VIEW "{tname_esc}" AS '
                f'SELECT {", ".join(select_parts)} WHERE 1=0'
            )
            con.execute(ddl)
            created += 1
        except Exception as exc:
            logger.debug("[pre-validate] stub view '%s' failed (non-fatal): %s",
                         tname, exc)
            continue

    # BF-279: cache miss backfill — for tables referenced in the query that
    # have NEVER been opened in CQB/BQB sidebar, fetch+cache schema inline
    # so the user gets pre-validation on FIRST submit, not after they've
    # already discovered the column-listing in another flow.  Best-effort:
    # any failure (S3 down, permission denied, etc.) just falls back to
    # the existing fail-OPEN behaviour.
    if missed_tables:
        try:
            from api.connections_api import _fetch_schema_from_s3
            conn_record = _db_manager.get_connection_raw(int(connection_id))
            cfg = (conn_record or {}).get("config") or {}
            bucket = cfg.get("bucket_name") or cfg.get("bucket") or ""
            for tname in missed_tables[:10]:  # cap to 10 to avoid runaway
                tdef = next((t for t in regs if t.get("name") == tname), None)
                if not tdef:
                    continue
                fmt = tdef.get("format", "iceberg")
                prefix = tdef.get("s3_prefix") or ""
                try:
                    schema = _fetch_schema_from_s3(
                        int(connection_id), conn_record, cfg, tdef,
                        tname, bucket, fmt, prefix,
                    )
                    if schema:
                        # 2026-10-06 -- through THE write chokepoint (catalog
                        # row + legacy row), not the legacy row alone: a
                        # second writer left the column catalog holding the
                        # pre-rule copy (``dt`` VARCHAR) beside a healed
                        # legacy row, and the catalog then trusted it.
                        try:
                            from core.schema_catalog import ColumnCatalog as _CC
                            _CC(_db_manager).record_columns(
                                int(connection_id), tname, schema.get("columns"),
                                source="backfill", table_format=fmt,
                                legacy_payload=schema)
                        except ValueError:
                            _db_manager.set_schema_cache(int(connection_id), tname,
                                                         fmt, schema)
                        # Now build the stub view from the just-cached schema
                        sd = schema or {}
                        cols = sd.get("columns") or []
                        if cols:
                            col_decls = []
                            for c in cols:
                                cname = c.get("name") or ""
                                if not cname:
                                    continue
                                ctype = _stub_column_type(c.get("type"))
                                col_decls.append(f'"{cname.replace(chr(34), chr(34)*2)}" {ctype}')
                            if col_decls:
                                tname_esc2 = tname.replace('"', '""')
                                select_parts2 = [f'CAST(NULL AS {dt}) AS {nm}'
                                                  for nm, dt in (d.split(' ', 1) for d in col_decls)]
                                ddl2 = (f'CREATE OR REPLACE TEMP VIEW "{tname_esc2}" AS '
                                         f'SELECT {", ".join(select_parts2)} WHERE 1=0')
                                con.execute(ddl2)
                                created += 1
                                logger.info(
                                    "[pre-validate] backfilled schema cache for "
                                    "table '%s' inline (%d cols)", tname, len(cols),
                                )
                except Exception as _bf_exc:
                    logger.debug("[pre-validate] inline backfill for '%s' failed (non-fatal): %s",
                                 tname, _bf_exc)
                    continue
        except Exception as _outer_exc:
            logger.debug("[pre-validate] backfill setup failed (non-fatal): %s", _outer_exc)
    return created


def _pre_validate_raw_sql(sql: str, connection_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """BF-239 / BF-276: Cheap pre-validation of user-typed SQL via DuckDB EXPLAIN.

    Catches **SQL-correctness** errors (parser, binder, ambiguous columns,
    GROUP BY mismatch, type errors, …) BEFORE we queue a worker.  User
    gets the error inline within ~50ms instead of after a 30-second
    polling storm — or worse, after 22 minutes of S3 file pre-download.

    BF-276: when ``connection_id`` is provided, we register empty stub
    views for the connection's registered tables using cached schemas
    (SchemaCache DB table, populated when CQB/BQB fetches columns).
    This catches "Ambiguous reference to column X" without touching S3.
    Without the stubs, the bare DuckDB context says "table not found"
    and we have to fail-OPEN — losing the chance to validate.

    Returns None when SQL is valid OR when the error is non-blocking.
    Returns an error dict (`error`, `error_type`, `agent_suggestion`)
    only for genuine SQL-correctness failures.
    """
    if not sql or not sql.strip():
        return None
    # BF-246: Skip pre-validation when the SQL references a remote URL
    # directly — DuckDB's EXPLAIN tries to read parquet/CSV metadata over
    # the network in a bare context (no httpfs/proxy/creds set up).
    # BF-276: SQL that references registered tables by name (no s3:// in
    # the SQL itself) goes through the stub-views path instead.
    sql_lower = sql.lower()
    if any(marker in sql_lower for marker in ("s3://", "http://", "https://", "azure://", "gs://", "r2://")):
        return None
    try:
        from core.duckdb_factory import duckdb_connection
    except Exception:
        return None  # fail-open — DuckDB unavailable in this context

    explain_sql = f"EXPLAIN {sql.rstrip().rstrip(';')}"
    try:
        with duckdb_connection() as con:
            # BF-276: register stub views from cached schema BEFORE EXPLAIN.
            # If we have stubs, table-not-found errors become real signals
            # (the user typed a table name that doesn't exist) — but only
            # for tables we have cached schemas for.
            stub_count = 0
            try:
                stub_count = _build_stub_views_from_schema_cache(con, connection_id, sql=sql)
                if stub_count:
                    logger.debug(
                        "[pre-validate] registered %d stub views from SchemaCache for conn=%s",
                        stub_count, connection_id,
                    )
            except Exception as exc:
                logger.debug("[pre-validate] stub setup failed (non-fatal): %s", exc)

            con.execute(explain_sql).fetchall()
    except Exception as exc:
        msg = str(exc)
        msg_lower = msg.lower()
        # ── Fail-OPEN whitelist: "errors" that aren't SQL-correctness ────────
        # These are runtime / context errors (file paths, S3, views).  The
        # actual executor sets up file views, S3 creds, etc. before running
        # the SQL — pre-validation has none of that, so these errors are
        # NOT signs of bad SQL.
        runtime_error_markers = (
            "io error",                 # IOException — file not found, S3 issues
            "no files found",
            "could not open",
            "table does not exist",     # CatalogException — view not yet registered
            "table not found",
            "catalog error",            # CatalogException — schema/view lookup
            "does not exist!",
            "http error",               # network errors — only the real run can fix
            "permission denied",
            "extension.*not found",     # extension load happens at runtime
        )
        for marker in runtime_error_markers:
            if marker in msg_lower:
                return None  # fail-open — not a SQL-correctness issue

        # ── Genuine SQL-correctness errors → reject + classify ──────────────
        # BF-352 audit: db_manager so admin-edited rules from the agent_rules
        # table take effect here too.  2026-10-07: through THE one function
        # every failure road asks (core.agents.inline_suggestion).
        from core.agents.inline_suggestion import suggestion_for_failure
        agent_hint: Optional[Dict[str, Any]] = suggestion_for_failure(
            msg, type(exc).__name__, db_manager=_db_manager)
        # 2026-10-07 (F9): ``EXPLAIN `` is OURS -- DuckDB echoed it back in
        # "LINE 1: EXPLAIN select ..." and the user never typed it.  An
        # unknown column LEADS with the sentence every road gives
        # (core.error_detection.unknown_column_message); the engine's text
        # stays, second, and whole in ``engine_error``.
        from core.error_detection import (
            strip_internal_explain, unknown_column_message)
        engine_msg = strip_internal_explain(msg)
        user_msg = unknown_column_message(engine_msg, sql=sql) or engine_msg
        return {
            "error":            user_msg[:1500],
            "engine_error":     engine_msg[:1500],
            "error_type":       type(exc).__name__,
            "agent_suggestion": agent_hint,
        }
    return None


def _connection_for_error_words(connection_id: Optional[int]) -> Optional[Dict[str, Any]]:
    """The connection's ``name`` + registered table names, for an error sentence.

    2026-10-07 (F9): an unknown table names the connection and lists what it
    DOES have.  Read MASKED (no secret is decrypted to word an error); None
    when it cannot be read -- the sentence then says so rather than
    claiming the connection has no tables.
    """
    if not connection_id or not _db_manager:
        return None
    try:
        conn = _db_manager.get_connection(int(connection_id))
    except Exception as exc:
        logger.warning("error words: connection %s could not be read (%s: %s)",
                       connection_id, type(exc).__name__, exc)
        return None
    if not conn:
        return None
    cfg = conn.get("config") if isinstance(conn.get("config"), dict) else None
    regs = (cfg or {}).get("registered_tables") if cfg is not None else None
    return {"name": conn.get("name"),
            "config": None if cfg is None else {"registered_tables": regs or []}}


@router.get("/api/execute/passport/{execution_id}")
async def get_query_passport(execution_id: str, _user: dict = Depends(require_execute_access)):
    """Industrialization Phase 9 — pre-run cost signal.

    Returns the Phase-3 Query Passport issued for this execution (files /
    bytes / rows / partitions / confidence) as soon as planning pins the
    snapshot — poll this right after submitting a query to see "N files /
    M bytes" while it runs, the EXPLAIN-grade cost Trino/Starburst
    surface pre-execution (docs/industrialization_plan_2026_07_23.md
    §Phase 9).  Pure read of the bounded in-process passport registry —
    no S3, no extra query work.

    Returns ``{"available": False}`` (never a 404/500) when no passport
    was issued for this execution_id — ``industrialization.passport_enabled``
    is OFF, the passport already aged out of the bounded FIFO, or the
    scan path never reached the passport chokepoint.  This is the common
    case today (flag OFF) and callers should treat it as "no cost preview
    available", not an error.
    """
    try:
        from core.roles import is_admin_like
        if not is_admin_like(_user):
            username = (_user or {}).get("username", "")
            try:
                exec_row = await asyncio.to_thread(_db_manager.get_execution, execution_id)
            except Exception:
                exec_row = None
            if exec_row and exec_row.get("executed_by") and exec_row["executed_by"] != username:
                raise HTTPException(
                    status_code=403,
                    detail="cannot view the passport for another user's execution",
                )
            # L1-S1 (2026-07-25 red-team): when the execution row is ABSENT
            # (registry is in-process, keyed only by execution_id — the row
            # can lag or live on another pod's DB view) or carries no owner,
            # ownership is NOT positively confirmed — deny (available:False)
            # instead of serving another user's cost passport (file counts,
            # bytes, partition shape = reconnaissance).
            if not (exec_row and exec_row.get("executed_by") == username):
                return {"available": False, "execution_id": execution_id}
        from core.industrialization import passport_registry as _preg
        pp = _preg.peek(execution_id)
        if not isinstance(pp, dict):
            return {"available": False, "execution_id": execution_id}
        return {"available": True, "execution_id": execution_id, "passport": pp}
    except HTTPException:
        raise
    except Exception as exc:
        logger.debug("[execute] passport peek failed for %s: %s", execution_id, exc)
        return {"available": False, "execution_id": execution_id}


@router.post("/api/execute/heartbeat/{execution_id}")
async def http_heartbeat(execution_id: str, _user: dict = Depends(require_execute_access)):
    """Phase 141 — HTTP fallback heartbeat.

    The frontend WebSocket is the preferred heartbeat channel, but it
    gets dropped by corporate proxies during long queries.  When that
    happens the frontend POSTs here every 10s as a fallback so the
    smart-cancel loop sees the user is still watching.

    Owner check: bug-fix to prevent user A from sending heartbeats for
    user B's execution_id (would let A indefinitely keep B's query alive,
    wasting resources).  Cheap DB lookup — runs once every 10s per
    in-flight execution per user.  Admins bypass the check so they can
    manually keep a stuck query alive while debugging.
    """
    from core.execution_state import record_heartbeat
    # 2026-09-24: THE execution rule, write form (no service-execution grant).
    # The local copy passed an OWNERLESS execution to anyone.
    await asyncio.to_thread(_enforce_execution_ownership, execution_id, _user,
                            allow_service=False)
    record_heartbeat(execution_id)
    return {"ok": True, "execution_id": execution_id}


@router.post("/api/execute/queued/cancel")
async def cancel_queued_by_client_request(body: CancelQueuedRequest,
                                          _user: dict = Depends(require_execute_access)):
    """H1 (2026-10-07): end the caller's OWN slot wait by the
    ``client_request_id`` its execute POST carried.

    While that POST waits for a slot (the per-user queue or the pod-wide
    fair queue) the client has no execution id -- it is in the POST's answer
    -- and no execution row exists, so ``/api/executions/{id}/cancel`` (which
    reads the row first) cannot reach the wait.  This can: the wait ends and
    the waiting POST answers ``{"status": "cancelled"}``.

    Scoped to the caller's username (the queue's own key), so one user can
    never reach another's request -- an unknown or foreign id is simply
    "not waiting".  ``cancelled: false`` = not waiting now; the cancel is
    remembered briefly, so a request that has not reached the queue yet is
    refused when it does.

    ANY process (H1 item 4): a wait lives in the process holding its POST,
    and this request is answered by whichever process receives it.  When
    the wait is not HERE, the cancel is written to the metadata database
    (``core/queued_wait_cancels.py``, keyed by this caller's username and
    the id) and the process holding the wait ends it on its next wait tick
    -- ``status: "requested"``.  ``"not_waiting"`` only when that channel
    could not be written (the client still cancels the execution id its
    POST answers with)."""
    username = (_user or {}).get("username") or "guest"
    crid = body.client_request_id
    cancelled = _queue_mgr.cancel_client_request(username, crid)
    status = "cancelled" if cancelled else "not_waiting"
    if not cancelled:
        try:
            from core import queued_wait_cancels as _qwc
            await asyncio.to_thread(_qwc.record, username, crid)
            status = "requested"
        except Exception as exc:
            logger.warning("[queue-cancel] could not record the cross-process "
                           "cancel of %s for %s: %s", crid, username, exc)
    if status != "not_waiting":
        _audit(_user, "cancel_queued_wait", None, "execution", None,
               {"client_request_id": crid, "status": status})
    return {"client_request_id": crid, "cancelled": bool(cancelled), "status": status}


def _conn_entitlement_denied(user, connection_ids) -> list:
    """Return the connection ids the caller is NOT entitled to (empty == all
    entitled).  The pure-decision sibling of ``_require_conn_entitlement_exec``
    for callers that degrade instead of 404 (auto-fix drops the id).  Token
    principals are treated as fully entitled — their scope is enforced by
    ``enforce_token_execute_scope`` elsewhere."""
    from api.deps import is_token_principal
    if not user or is_token_principal(user):
        return []
    ids = [c for c in (connection_ids or []) if c]
    if not ids:
        return []
    from core.entitlements import denied_connection_ids
    return denied_connection_ids(user, ids, db=_db_manager)


def _require_conn_entitlement_exec(user, connection_ids) -> None:
    """Refuse execution on connections the caller is not entitled to.

    THE leak-gate decision lives in ``core.entitlements.denied_connection_ids``
    -- this wrapper only maps a denial onto this router's HTTP contract.
    Token-scoped principals (share/embed) skip it: the object owner
    authorized the share and ``enforce_token_execute_scope`` pins them to
    exactly that object.
    """
    denied = _conn_entitlement_denied(user, connection_ids)
    if denied:
        raise HTTPException(status_code=404,
                            detail=f"Connection {denied[0]} not found")


@router.post("/api/execute")
async def execute_query(request: ExecuteQueryRequest, _user: dict = Depends(require_execute_access)):
    """Execute a query (saved or ad-hoc).

    BF-407: ENTERPRISE-GRADE TIME BUDGET — the handler is wrapped in
    asyncio.wait_for so a sync-blocking regression surfaces as HTTP 504
    instead of a silent backend-unavailable hang.

    Budget = max(inner-timeouts) + 5s headroom for the cheap prep steps.

    Inner timeouts inside ``_execute_query_impl``:
      - BF-406 portal credential resolution : 20s (slow corporate proxy)
      - BF-PRE-VALIDATE-TIMEOUT             :  5s (cold Iceberg schema)
      - everything else                     : sub-second
    Worst-case sequential = 25s → outer budget set to **30s**.

    BF-PORTAL-BUDGET-FIX (2026-05-18): the original 10s budget pre-dated
    BF-406's 20s portal timeout.  When the portal was cold, the 10s
    handler budget tripped BEFORE the inner 20s timeout had a chance to
    succeed → user saw HTTP 504 instead of completed credential resolution.
    Bumping the outer budget to 30s lets cold-portal calls complete (the
    inner 20s gates it).  Sync-blocking regressions still surface — they
    just have a 30s detection window now, not 10s.

    On 504: the partial work already done (DB execution record creation)
    is preserved.  The background task may still complete the query —
    user can find it via GET /api/executions/active or the localStorage
    in-flight recovery flow.
    """
    # SECURITY AUDIT 2026-08-03 (S5): share/embed-token principals are
    # scoped to the object their token was minted for — enforce BEFORE the
    # queue-mode branch so both the inline and queued paths see the
    # restricted (rewritten) request.  No-op for real authenticated users.
    from api.deps import enforce_token_execute_scope as _ets
    _ets(_user, request)
    # -- SECURITY 2026-08-23 (Phase 2A): connection ENTITLEMENT --------------
    # This route runs arbitrary SQL with the connection's stored credentials,
    # yet nothing between here and the engine ever asked whether the caller
    # may USE that connection: any analyst could execute against any other
    # analyst's PRIVATE connection by id.  Same decision as datasets / Data
    # Quality / /api/sql/execute: core.entitlements.denied_connection_ids
    # (own / shared / legacy-unowned / ACL-granted; fail-closed).  Placed
    # BEFORE the queue-mode branch so the queued and inline paths see the
    # same refusal.  Token principals are exempt -- their access is the
    # token's object scope, enforced by enforce_token_execute_scope above.
    # 404, not 403, so the route is not an existence oracle.
    await asyncio.to_thread(
        _require_conn_entitlement_exec, _user,
        [request.connection_id, request.secondary_connection_id])
    # BF-593: replace _req_key with a unique UUID per request so the
    # outer 30s budget handler cannot pop the WRONG user's entry due to
    # id() reuse — when the previous Request is GC'd and a new one
    # lands at the same memory address, id() collides.  UUID is unique
    # per process-lifetime; collision impossible.
    _req_key = uuid.uuid4().hex
    # ── Industrialization Phase 2: flag-gated queue-mode branch ──────────
    # OFF (default): maybe_queue_execute returns None after one flag read
    # and the inline path below runs byte-for-byte as today.  ON: the
    # request is enqueued (identity captured as data), the executor's
    # submit response is relayed with parity, and ANY queue failure fails
    # OPEN back to inline (a query is never silently dropped).
    _queued_resp = None
    try:
        from core.jobqueue.execute_bridge import maybe_queue_execute as _mqe
        _queued_resp = await _mqe(request, _user)
    except HTTPException:
        raise  # parity error relay (what inline submission would have raised)
    except Exception as _qm_err:
        logger.error("[jobqueue] queue-mode branch failed — fail-open to "
                     "inline execution: %s", _qm_err, exc_info=True)
        _queued_resp = None
    if _queued_resp is not None:
        return _queued_resp
    # 2026-07-22: the outer submission budget is OFF by default (was a hard 30 s
    # wall-clock cap).  It was only a sync-blocking-regression DETECTOR, but on
    # a slow portal / cold metadata / large cross-source walk it false-tripped
    # LEGITIMATE submissions into a 504 ("Query submission exceeded 30-second
    # budget").  The INNER per-operation timeouts (portal 20 s, pre-validate
    # 5 s, …) still bound each slow step, so there is no arbitrary outer cap on
    # a genuinely slow-but-valid submission.  Set query.submission_budget_seconds
    # to a positive number to re-enable the detector.
    try:
        from core.config import get as _cfg_get_q
        _budget = float(_cfg_get_q("query", "submission_budget_seconds", 0) or 0)
    except Exception:
        _budget = 0.0
    if not (_budget > 0):
        return await _execute_query_impl(request, _user, _req_key)
    try:
        return await asyncio.wait_for(
            _execute_query_impl(request, _user, _req_key),
            timeout=_budget,
        )
    except asyncio.TimeoutError:
        # BF-575 / BF-591: the inner impl was cancelled mid-flight.
        # If it had already incremented _user_query_counts but hadn't
        # yet transferred ownership to the background task, the counter
        # would leak forever and the user would hit "Too many concurrent
        # queries" on every subsequent submission.  The shared dict
        # tells us exactly which username (if any) needs cleanup — no
        # risk of double-decrement because pop returns None if the
        # inner already cleaned up.
        _orphaned_user = _pending_owner_by_req.pop(_req_key, None)
        if _orphaned_user:
            try:
                # BF-584: use the queue-aware release so a queued
                # waiter wakes up to claim the freed slot.
                _release_user_slot(_orphaned_user)
                logger.warning(
                    "[execute_query] BF-575/591: cleaned up leaked "
                    "per-user counter for %s after %ss budget timeout",
                    _orphaned_user, _budget,
                )
            except Exception:
                logger.exception(
                    "[execute_query] BF-575/591 cleanup failed for %s "
                    "(harmless, but counter leak may persist)",
                    _orphaned_user,
                )
        logger.error(
            "[execute_query] handler exceeded the configured %ss submission "
            "budget (query.submission_budget_seconds) — likely portal "
            "credential resolution beyond its own 20s timeout OR a "
            "sync-blocking regression.  Returning 504 to client.", _budget,
        )
        raise HTTPException(
            status_code=504,
            detail={
                "type":    "execute_handler_timeout",
                "message": (
                    f"Query submission exceeded the configured {_budget}s budget. "
                    "The query may still be running in the background. Check "
                    "Admin → Active Queries to find it, or raise/disable "
                    "query.submission_budget_seconds."
                ),
                "hint":    "Common causes: AWS portal unreachable through proxy "
                           "(>20s), database fully unresponsive, schema cache "
                           "rebuild stuck.  Retry usually succeeds once caches "
                           "warm.  This will NOT log you out.",
            },
        )


async def _execute_query_impl(request: ExecuteQueryRequest, _user: dict, _req_key: Optional[str] = None):
    """The original execute_query body.  Renamed so the new POST shim can
    wrap it in a strict time budget (BF-407).

    BF-593: _req_key is a UUID generated by the outer ``execute_query``
    handler — used to key the orphan-tracker dict so id() reuse cannot
    cause cross-user pollution.  Falls back to a fresh UUID when called
    directly (legacy / test paths).
    """
    if _req_key is None:
        _req_key = uuid.uuid4().hex
    # Set portal user context so _make_s3_client_for_conn auto-injects creds
    try:
        from core.aws_portal_auth import _current_portal_user
        _current_portal_user.set(_user.get("username", ""))
    except Exception:
        pass

    # ── ${user.*} principal variables in editor SQL (2026-08-29) ──────────
    # Reports render ${user.username|role|groups|is_admin|<attr>} in their
    # SQL at execution time (core.reports.user_sql_vars — the ONE renderer;
    # do not add a second).  The ad-hoc editor did not, so the same saved
    # SQL ran as a report and was a raw syntax error here — an author could
    # not test report SQL before saving it.
    #
    # Rendered HERE, at the top of the impl, NOT next to secure_sql, for two
    # load-bearing reasons:
    #   * BF-239 pre-validation below EXPLAINs request.raw_sql through
    #     DuckDB, and `${` is a parse error — rendering later would 400
    #     every tokenized query before the renderer ever saw it;
    #   * the BF-235 result/dedup/cross cache keys hash request.raw_sql.
    #     With RLS off their user_scope is None, so two users' identical
    #     token TEXT would share one cache entry while their RENDERED SQL
    #     differs — a cross-principal serve.  Keying on the rendered text
    #     (values inlined) gives each principal its own entry by
    #     construction.
    # Mutating the request is deliberate: every downstream consumer
    # (pre-validate, caches, dedup, the secure_sql sites, the engines) must
    # see ONE spelling of the SQL, and this function is their sole entry.
    #
    # Rendered against the VERIFIED session user (_user) ONLY — NEVER
    # request.executed_by, which is client-supplied attribution (a
    # body-supplied principal reaching SQL was a P0 here, 2026-08-20).
    # Byte-identical no-op when the SQL has no `${`.  ValueError = unknown
    # token = authoring error → 400 with the message intact (it names the
    # bad variable and the available vocabulary).
    if (request.raw_sql and "${" in request.raw_sql) or (
            request.secondary_raw_sql and "${" in request.secondary_raw_sql):
        from core.reports.user_sql_vars import resolve_user_sql_vars
        try:
            if request.raw_sql:
                request.raw_sql = resolve_user_sql_vars(
                    request.raw_sql, _user,
                    label="editor SQL (/api/execute primary)")
            if request.secondary_raw_sql:
                request.secondary_raw_sql = resolve_user_sql_vars(
                    request.secondary_raw_sql, _user,
                    label="editor SQL (/api/execute secondary)")
        except ValueError as _uv_err:
            raise HTTPException(status_code=400, detail=str(_uv_err))

    # BF-239: Pre-validate user-typed raw_sql via DuckDB EXPLAIN BEFORE
    # queueing a worker.  Saves the user from a 30-second polling storm when
    # their SQL has a binder error — they see the error + agent hint inline
    # within ~50ms.  Skipped for query_config-only queries (those build SQL
    # from the validated visual builder) and for cross-source queries (which
    # need both engines plumbed in).
    #
    # BF-PRE-VALIDATE-TIMEOUT (Phase 141): skip when client opts out, AND
    # bound the validation at 5 seconds via asyncio.to_thread+wait_for so
    # a slow schema backfill (e.g. cold Iceberg metadata scan against an
    # un-cached table with overdue expire_snapshots) cannot block the API
    # worker thread.  On timeout we log and proceed: the query still runs;
    # any binder errors surface during execution (~30s) instead of inline
    # (~50ms).  That's the pre-fix behaviour, so the worst case is just
    # losing the bonus inline-error UX, not breaking anything.
    # BF-SQL-CONN-PREVAL: skip DuckDB-EXPLAIN pre-validation when the
    # connection is a SQL connector (Trino/Starburst/Snowflake/Databricks/
    # Oracle/Athena).  Those use their own SQL dialects (catalog.schema.table
    # syntax, try_cast, UNNEST WITH ORDINALITY, etc.) that DuckDB doesn't
    # understand — the EXPLAIN throws "Catalog 'hive' does not exist" or
    # "Function 'try_cast' not found" which the runtime_error_markers
    # whitelist doesn't catch, then the query is rejected with HTTP 400
    # before it ever reaches the right connector.
    _skip_preval_for_connector = False
    if request.connection_id:
        try:
            _conn_for_preval = await adb(_db_manager.get_connection_raw, request.connection_id)
            if _conn_for_preval and _conn_for_preval.get("connection_type") in SQL_CONNECTOR_TYPES:
                _skip_preval_for_connector = True
        except Exception:
            pass
    # BF-576 (2026-05-29): cold-metadata short-circuit.  When pre-validate
    # has recently TIMED OUT on this connection (cold Iceberg manifest
    # not yet cached), skip it for the next 60 seconds.  Without this,
    # every query in that window pays a 5s wait_for timeout BEFORE the
    # actual execute starts — which the user surfaced as "query
    # execution become slow".  After 60s the cache should have warmed
    # via background metadata refresh; if not we retry pre-validate
    # next time anyway.  Memory-only ephemeral state — clears on
    # restart, which is correct (a restart drains the cache too).
    _skip_preval_recent_timeout = False
    if request.connection_id and not _skip_preval_for_connector:
        _ts = _preval_timeout_until.get(int(request.connection_id), 0.0)
        if _ts > _time.time():
            _skip_preval_recent_timeout = True
            _pre_validate_status = "skipped_recent_timeout"
    # BF-522 (2026-05-28): track whether pre-validate ran cleanly.  When
    # the 5s budget is exceeded the query STILL proceeds (BF-276 design
    # decision: don't block the user on a cold metadata scan), but the
    # user has no idea that schema validation was skipped — they retry
    # the same broken query thinking nothing happened.  Capture the
    # state here and surface it in the execution_started WS broadcast +
    # the execution record so the UI can render a clear notice.
    if not _skip_preval_recent_timeout:
        _pre_validate_status = "skipped"  # default for paths that bypass it
    if (not request.skip_pre_validate
            and not _skip_preval_for_connector
            and not _skip_preval_recent_timeout  # BF-576
            and request.raw_sql and request.raw_sql.strip()
            and not (request.secondary_connection_id and (request.secondary_query_config or request.secondary_raw_sql))):
        # BF-276: pass connection_id so stub views from SchemaCache get
        # registered into the validation DuckDB.  This catches ambiguous
        # column references against registered tables (the case that took
        # 22 min to fail in production: "Ambiguous reference to column
        # name 'sap_company_id'" from a query joining fact_table +
        # fact_table_ext where both have that column).
        try:
            _pre = await asyncio.wait_for(
                asyncio.to_thread(
                    _pre_validate_raw_sql,
                    request.raw_sql,
                    connection_id=request.connection_id,
                ),
                timeout=PRE_VALIDATE_BUDGET_SECONDS,
            )
            _pre_validate_status = "ok"
        except asyncio.TimeoutError:
            logger.warning(
                "Pre-validation exceeded 5s budget — skipping (query will run; "
                "binder errors will surface during execution).  Likely cause: "
                "cold Iceberg metadata scan for an un-cached table; persistent "
                "metadata-key cache should warm on next request."
            )
            _pre = None
            # BF-522: explicit signal so the frontend can render a
            # warning badge "Schema validation skipped (timed out) —
            # binder errors will appear during execution.  Retry once
            # the table's metadata is cached."
            _pre_validate_status = "timed_out"
            # BF-576: short-circuit the next 60s of queries on this
            # connection — paying a 5s timeout per query while
            # metadata warms makes execution feel slow.  After 60s
            # the background metadata refresh should have populated
            # SchemaCache; if not, the next attempt re-tries.
            if request.connection_id:
                _preval_timeout_until[int(request.connection_id)] = _time.time() + 60.0
                logger.info(
                    "BF-576: pre-validate short-circuited for connection_id=%s "
                    "until %s (next ~60s of queries skip pre-validate)",
                    request.connection_id,
                    _time.strftime("%H:%M:%S", _time.localtime(
                        _preval_timeout_until[int(request.connection_id)]
                    )),
                )
        if _pre is not None:
            # Return 400 with structured error + agent hint so the frontend
            # can render the inline AgentSuggestionInline immediately.
            raise HTTPException(status_code=400, detail={
                "type": "sql_pre_validation_failed",
                **_pre,
            })
    try:
        if request.query_config:
            # Client passes an explicit (possibly parameterised) query config — use it.
            # query_id may also be set for audit/tracking purposes; that is fine.
            query_config_model = request.query_config
        elif request.query_id:
            saved_query = await adb(_db_manager.get_query, request.query_id)
            if not saved_query:
                raise HTTPException(status_code=404, detail="Query not found")
            query_config_dict = saved_query["query_config"]
            query_config_model = QueryConfigModel(**query_config_dict)
            # A preview cap (``limit`` on the request): narrows the stored
            # limit, never widens it; 0 / absent adds no cap.
            if request.limit:
                _stored = query_config_model.limit
                query_config_model.limit = (request.limit if not _stored
                                            else min(_stored, request.limit))
        elif request.raw_sql:
            # SQL editor mode — no visual query config needed
            query_config_model = QueryConfigModel(files=[])
        else:
            raise HTTPException(
                status_code=400,
                detail="Either query_id, query_config, or raw_sql must be provided"
            )

        # 2026-09-26: the 2026-09-25 stop-gap that refused a raw ``s3://``
        # file on a connection with its own endpoint is gone -- the generic
        # branch now resolves the endpoint through core.s3_access (F2).

        # 2026-09-24: a visual config's {param} placeholders are filled from
        # ``params`` (the same field raw SQL uses); any still standing are
        # REFUSED by name.  Run unfilled, the filter compared a column to the
        # literal "{p_status}" and "completed" with 0 rows -- a dashboard
        # widget over a report's saved query showed "No data loaded" with no
        # reason.  Checked before the cache, which had stored that empty run.
        if query_config_model.filters:
            from core.parameters import (
                substitute_filter_params as _sub_fp,
                unresolved_filter_params as _unres_fp,
            )
            if request.params:
                _filled = _sub_fp(
                    [f.model_dump() if hasattr(f, "model_dump") else dict(f)
                     for f in query_config_model.filters],
                    request.params)
                query_config_model = query_config_model.model_copy(
                    update={"filters": [type(query_config_model.filters[0])(**f) for f in _filled]}
                    if _filled else {"filters": []})
            _missing = _unres_fp(query_config_model.filters)
            if _missing:
                raise HTTPException(
                    status_code=400,
                    detail=("This query has parameters that were not given values: "
                            + ", ".join(_missing)
                            + ". Supply them (params), or run it from a report that does."))

        # ── Phase 86: Apply {{param}} substitution to raw_sql before execution ──
        _effective_raw_sql = request.raw_sql
        _effective_secondary_raw_sql = request.secondary_raw_sql
        if _effective_raw_sql and request.params:
            try:
                from api.queries_api import _substitute_query_params
                _effective_raw_sql = _substitute_query_params(_effective_raw_sql, request.params)
            except ValueError as _param_err:
                raise HTTPException(status_code=400, detail=str(_param_err))
        # Phase 131 deep-dive #13 (round 4 follow-up): substitute params in
        # secondary raw SQL too — was a parity gap (only primary substituted).
        if _effective_secondary_raw_sql and request.params:
            try:
                from api.queries_api import _substitute_query_params
                _effective_secondary_raw_sql = _substitute_query_params(
                    _effective_secondary_raw_sql, request.params)
            except ValueError as _param_err:
                raise HTTPException(status_code=400, detail=str(_param_err))

        # ── Ensure connection_id is in query_config (critical for cache key isolation)
        # connection_id may be on the request level but not inside query_config — propagate it
        # so cache keys always include the connection, preventing cross-connection collisions.
        _effective_conn_id_exec = request.connection_id or query_config_model.connection_id
        if _effective_conn_id_exec and not query_config_model.connection_id:
            query_config_model = query_config_model.model_copy(
                update={"connection_id": _effective_conn_id_exec}
            )

        # ── BF-577 (2026-05-29): Starburst → DuckDB compatibility cleanup ─────
        # Two cleanups that benefit copy-pasted Starburst SQL:
        #   (a) JSON-escape leakage (queries saved as JSON in .txt files
        #       come back with ``\"colname\"``) — strip stray backslashes.
        #   (b) ``catalog.schema.table`` → ``table`` when the bare name is
        #       a registered table on this connection.  Starburst SQL
        #       uses 3-part names; QueryStudio registers bare names.
        # Fixes get reported through the same ``agent_format_fixes``
        # response channel as BF-571/572/573.
        #
        # 2026-08-19 -- BOTH cleanups here rewrite the user's SQL INTO DuckDB
        # dialect.  Correct when DuckDB will run it; wrong when the SQL is
        # about to be shipped to the very engine it was written for.
        # `_conn_type` was not resolved until ~400 lines below, so these ran
        # blind: a Starburst query using `date_parse()` reached Starburst as
        # `STRPTIME()` (not a Trino function), and `catalog.schema.table` was
        # stripped to the bare registered name, which on Trino resolves
        # against the session catalog/schema -- a DIFFERENT table, read
        # without error.  Resolve the target engine ONCE, here, and gate.
        _tgt_conn_rec = None
        if _effective_conn_id_exec and _db_manager:
            try:
                _tgt_conn_rec = await adb(
                    _db_manager.get_connection_raw,
                    int(_effective_conn_id_exec),
                )
            except Exception:
                pass  # unknown target: treated as DuckDB, i.e. prior behaviour
        _target_conn_type = str(
            (_tgt_conn_rec or {}).get("connection_type") or "").lower()
        # A remote SQL engine runs the user's SQL verbatim; only a
        # DuckDB-backed target needs (or tolerates) dialect rewriting.
        _target_is_remote_sql = _target_conn_type in set(SQL_CONNECTOR_TYPES)

        _starburst_fixes: list = []
        if _effective_raw_sql and _target_is_remote_sql:
            # 2026-08-19 (correction) -- BF-577 bundles TWO cleanups and only
            # ONE of them is DuckDB-specific.  `clean_json_escapes` repairs
            # `\"colname\"` leakage from queries round-tripped through JSON;
            # that damage is in the SQL TEXT and is just as broken on
            # Starburst, so gating it off with the rest meant a JSON-mangled
            # saved query that ran yesterday now reaches Trino unrepaired.
            # Table de-qualification stays gated -- on Trino a bare name
            # resolves against the session catalog, i.e. a DIFFERENT table.
            try:
                from core.sql_starburst_compat import clean_json_escapes
                _effective_raw_sql, _starburst_fixes = clean_json_escapes(
                    _effective_raw_sql)
                if _starburst_fixes:
                    logger.info(
                        "BF-577: repaired %d JSON-escape artefact(s) in SQL "
                        "bound for %s", len(_starburst_fixes),
                        _target_conn_type)
            except Exception as _sb_json_err:
                logger.debug(
                    "BF-577: JSON-escape repair skipped (fail-open): %s",
                    _sb_json_err)
        elif _effective_raw_sql:
            try:
                from core.sql_starburst_compat import normalise_starburst
                # Pull registered table names for the active connection.
                _registered_names: list = []
                if _tgt_conn_rec:
                    try:
                        _cfg_for_reg = (_tgt_conn_rec.get("config") or {})
                        _registered_names = [
                            (t or {}).get("name", "")
                            for t in (_cfg_for_reg.get("registered_tables") or [])
                            if (t or {}).get("name")
                        ]
                    except Exception:
                        pass  # leave registered_names empty → only JSON cleanup runs
                _effective_raw_sql, _starburst_fixes = normalise_starburst(
                    _effective_raw_sql, registered_names=_registered_names,
                )
                if _starburst_fixes:
                    logger.info(
                        "BF-577: Starburst-compat cleanup applied %d fix(es) "
                        "to user SQL: %s",
                        len(_starburst_fixes),
                        "; ".join(f.describe() for f in _starburst_fixes),
                    )
            except Exception as _sb_err:
                logger.debug(
                    "BF-577: Starburst-compat cleanup skipped (fail-open): %s",
                    _sb_err,
                )

        # 2026-10-03 -- a typed statement's bare table names take the catalog /
        # schema the author BROWSED to, in the TEXT, HERE: before the row-
        # security rewrite below reads it.  Qualified any later, a policy on
        # QS_DEMO.FIN.TRADES does not match a bare TRADES and the statement
        # runs UNFILTERED -- caught live on the first placement (EMEA-only
        # analyst read all four regions).  The cache key reads it after too.
        if _effective_raw_sql and request.default_schema:
            from core.sql_connector_dialect import qualify_unqualified_tables
            _effective_raw_sql = qualify_unqualified_tables(
                _effective_raw_sql, _target_conn_type,
                request.default_catalog, request.default_schema)

        # ── Phase 141: Row & column security rewrite ──────────────────────────
        # secure_sql is a no-op when row_security.enabled=false, when the user
        # is an admin, or when no policy matches any table in the query.  When
        # policies DO apply, the SQL is rewritten to inject WHERE filters and
        # column projections.  Audit rows are recorded inside secure_sql.
        # Parse errors are now handled inside secure_sql (the original SQL is
        # returned and downstream DuckDB emits a normal parse error) so the
        # broad except below only fires on real policy-resolution failures.
        if _effective_raw_sql:
            try:
                from core.row_security import secure_sql as _rs_secure
                from core.row_security.api import PolicyResolutionError as _RsResErr
                from core.sql_filter_wrapper import (
                    dialect_for_connection_type as _dial_rs)
                _effective_raw_sql = await asyncio.to_thread(
                    _rs_secure,
                    _effective_raw_sql,
                    # 2026-08-19: was hardcoded "duckdb".  When the query is
                    # bound for Trino/Snowflake/Oracle, parsing and re-emitting
                    # it through the wrong grammar can alter the SQL the
                    # remote engine finally runs.  `_target_conn_type` is
                    # resolved just above.
                    dialect=_dial_rs(_target_conn_type),
                    user_ctx=_user,
                    connection_id=_effective_conn_id_exec,
                    request_id=getattr(request, "execution_id", None),
                )
            except _RsResErr as _rs_exc:
                # Fail-closed when the rewriter itself fails (NOT for plain
                # bad SQL, which secure_sql now passes through).
                logger.error("Row-security rewrite failed: %s", _rs_exc)
                raise HTTPException(
                    status_code=403,
                    detail=f"Row-security policy enforcement failed: {_rs_exc}",
                )
            except HTTPException:
                raise
            except Exception as _rs_exc:
                # Defensive — unexpected error in the security module.  Log
                # loudly so admins notice, but do NOT block legitimate
                # queries: degraded availability vs unavailable.  Audit
                # rows from secure_sql still fired (or were attempted).
                logger.exception("Row-security unexpected error (fail-open for availability): %s", _rs_exc)

        # ── BF-571 / BF-572: cross-dialect datetime format auto-repair ────────
        # Run the format normaliser HERE (in _execute_query_impl) so the
        # agent_format_fixes list is in scope when we build the response
        # dict below.  execute_query_background runs it again later for
        # the actual execute path — the normaliser is idempotent so this
        # is safe and cheap.  Fail-open: any error leaves SQL unchanged
        # and an empty fix list (frontend banner stays dark).
        _format_fixes: list = []
        # Gated on the target engine for the same reason as BF-577 above:
        # translating INTO DuckDB is only right when DuckDB will run it.
        if _effective_raw_sql and not _target_is_remote_sql:
            try:
                from core.sql_dialect_translator import (
                    translate_to_duckdb_with_fixes as _translate_sql_v2,
                )
                _effective_raw_sql, _dt_dialect, _format_fixes = _translate_sql_v2(_effective_raw_sql)
                if _format_fixes:
                    logger.info(
                        "_execute_query_impl: BF-571/572 auto-corrected %d "
                        "format specifier(s) in user SQL: %s",
                        len(_format_fixes),
                        "; ".join(f.describe() for f in _format_fixes),
                    )
            except Exception as _dt_err:
                logger.debug(
                    "_execute_query_impl: format normaliser skipped "
                    "(fail-open): %s", _dt_err,
                )

        # Phase 131 deep-dive #13 (round 4 follow-up): rewrite the secondary
        # raw SQL too.  Was a real bypass — cross-source primary was secured
        # above, secondary fell through untouched and reached the engine raw.
        if _effective_secondary_raw_sql:
            try:
                from core.row_security import secure_sql as _rs_secure
                from core.row_security.api import PolicyResolutionError as _RsResErr
                _sec_conn_for_rls = request.secondary_connection_id or _effective_conn_id_exec
                # 2026-10-04 -- the SECONDARY's own grammar.  This was
                # hardcoded "duckdb" while the primary was fixed on
                # 2026-08-19: a Snowflake / Oracle / Trino secondary had its
                # row-security predicate rewritten in DuckDB grammar and was
                # then shipped to its own engine.
                from core.sql_filter_wrapper import (
                    dialect_for_connection_type as _dial_rs_sec)
                _sec_rec_for_rls = None
                if _sec_conn_for_rls and _db_manager is not None:
                    try:
                        _sec_rec_for_rls = await adb(
                            _db_manager.get_connection_raw,
                            int(_sec_conn_for_rls))
                    except Exception:
                        _sec_rec_for_rls = None   # unknown -> duckdb, as before
                _effective_secondary_raw_sql = await asyncio.to_thread(
                    _rs_secure,
                    _effective_secondary_raw_sql,
                    dialect=_dial_rs_sec(
                        (_sec_rec_for_rls or {}).get("connection_type")),
                    user_ctx=_user,
                    connection_id=_sec_conn_for_rls,
                    request_id=getattr(request, "execution_id", None),
                )
            except _RsResErr as _rs_exc:
                logger.error("Row-security rewrite failed (secondary): %s", _rs_exc)
                raise HTTPException(
                    status_code=403,
                    detail=f"Row-security policy enforcement failed: {_rs_exc}",
                )
            except HTTPException:
                raise
            except Exception as _rs_exc:
                logger.exception("Row-security unexpected error on secondary (fail-open for availability): %s", _rs_exc)

        # Resolve dynamic date expressions in filter values (${today}, ${today-7d} …)
        # so saved queries and schedules always run against the correct date window.
        try:
            from core.date_resolver import CalendarTokenRefused, resolve_filter_dates
            if query_config_model.filters:
                resolved_filters = resolve_filter_dates(query_config_model.filters)
                query_config_model = query_config_model.model_copy(
                    update={"filters": resolved_filters}
                )
        except CalendarTokenRefused:
            raise          # a filter that cannot be rendered refuses (400)
        except Exception as e:
            logger.debug("Failed to resolve filter dates, proceeding with original filters: %s", e)

        # ── Phase 47: Pre-execution query analysis ────────────────────────────
        _query_warnings = []
        try:
            from core.query_analyzer import analyze_query as _analyze_q, warnings_to_dicts as _wtd
            _sql_to_analyze = request.raw_sql or ""
            _pre_conn_type = "duckdb"
            _pre_conn_id = request.connection_id or query_config_model.connection_id
            if _pre_conn_id:
                _pre_conn = await adb(_db_manager.get_connection_raw, _pre_conn_id)
                if _pre_conn:
                    _pre_conn_type = _pre_conn.get('connection_type', 'duckdb')
                    # Fetch partition columns for the first queried table
                    _pre_table = (query_config_model.files or [''])[0]
                    _pre_partitions = []
                    try:
                        _pre_partitions = [
                            p.get('column', '') for p in
                            await adb(_db_manager.get_connection_partitions, _pre_conn_id, _pre_table)
                            if p.get('column')
                        ]
                    except Exception as _part_exc:
                        logger.warning("Failed to fetch partition columns for query analysis: %s", _part_exc, exc_info=True)
            if _sql_to_analyze:
                _query_warnings = _wtd(_analyze_q(_sql_to_analyze, _pre_conn_type, _pre_partitions))
        except Exception:
            pass  # non-fatal

        # ── Phase 46+94: Record table/column/join/agg usage for auto-suggest ──
        try:
            _usage_conn_id = request.connection_id or query_config_model.connection_id
            _primary_tname = None
            for _f in (query_config_model.files or []):
                _fname = str(_f)
                if not _fname.startswith('__'):
                    import os as _os
                    _tname = _os.path.splitext(_os.path.basename(_fname))[0]
                    await adb(_db_manager.record_usage, "table", _tname, connection_id=_usage_conn_id)
                    if _primary_tname is None:
                        _primary_tname = _tname
                else:
                    # Registered table: strip __registered__: prefix
                    _tname = _fname.replace("__registered__:", "").replace("__materialized__:", "").replace("__local__:", "").replace("__federation__:", "")
                    if _primary_tname is None:
                        _primary_tname = _tname
            # Column usage
            for _col in (query_config_model.columns or []):
                _bare = str(_col).rsplit(".", 1)[-1] if "." in str(_col) else str(_col)
                await adb(_db_manager.record_usage, "column", _bare, connection_id=_usage_conn_id,
                                         table_name=_primary_tname)
            # Join pair usage
            import json as _json
            for _jc in (query_config_model.joins or []):
                _lf = str(getattr(_jc, 'left_file', '') or '').replace("__registered__:", "").replace("__materialized__:", "").replace("__local__:", "").replace("__federation__:", "")
                _rf = str(getattr(_jc, 'right_file', '') or '').replace("__registered__:", "").replace("__materialized__:", "").replace("__local__:", "").replace("__federation__:", "")
                _pair_key = "||".join(sorted([_lf.lower(), _rf.lower()]))
                _join_data = _json.dumps({
                    "left_on": getattr(_jc, 'left_on', []) or [],
                    "right_on": getattr(_jc, 'right_on', []) or [],
                })
                await adb(_db_manager.record_usage, "join_pair", _pair_key,
                                         connection_id=_usage_conn_id, table_name=_join_data)
            # Aggregation combo usage
            for _ag in (query_config_model.aggregations or []):
                _afn = getattr(_ag, 'function', 'SUM') or 'SUM'
                _acol = getattr(_ag, 'column', '') or ''
                if _acol:
                    await adb(_db_manager.record_usage, "agg_combo", f"{_afn.upper()}({_acol})",
                                             connection_id=_usage_conn_id,
                                             table_name=_primary_tname)
        except Exception:
            pass  # non-fatal

        # ── Phase 96 + 107: Query guardrails — file count + S3 full-scan detection ──
        try:
            from core.config import query_guardrails as _qg_cfg
            from core.query_guardrails import check_s3_full_scan, has_any_partition_filter
            if _qg_cfg.enabled:
                _file_count = len(query_config_model.files or [])
                # Hard block: too many files (Phase 96)
                if _qg_cfg.max_files_block and _file_count > _qg_cfg.max_files_block:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Query selects {_file_count} files which exceeds the maximum of "
                               f"{_qg_cfg.max_files_block}. Please narrow your selection.",
                    )
                # Require partition filter: block if any table has partitions but none selected
                _has_partition_filter = has_any_partition_filter(query_config_model.filters)
                # BF-FULL-SCAN-WHERE (2026-05-18): the structured-filters check
                # above MISSES partition filters expressed in raw SQL WHERE
                # clauses (the common BQB raw-mode case).  Fall back to the
                # same sqlglot-based extractor BQB uses internally during
                # execution so the guardrail and the execution path agree on
                # what counts as a partition filter.
                #
                # Symptom this prevents: user writes a perfectly valid query
                # like ``SELECT * FROM "fact" WHERE business_date='2026-05-18'``
                # and the guardrail incorrectly flags it as a full scan
                # (potentially blocking) even though business_date IS a
                # registered partition column.
                if (not _has_partition_filter
                        and (_effective_raw_sql or "").strip()
                        and (request.connection_id or query_config_model.connection_id)):
                    try:
                        from core.iceberg_partition_resolver import resolve_partition_columns
                        _qg_conn_id = request.connection_id or query_config_model.connection_id
                        _qg_conn_raw = await adb(_db_manager.get_connection_raw, _qg_conn_id)
                        _qg_reg = ((_qg_conn_raw or {}).get("config") or {}).get("registered_tables") or []
                        # 2026-07-22: resolve ONLY the tables the SQL actually
                        # references — not EVERY registered table on the
                        # connection.  Each resolve can do a cold-metadata S3
                        # walk; doing it for all N registered tables sequentially
                        # made this WHERE-clause partition detection take minutes
                        # on connections with many tables (the fresh-run 120s
                        # "simple query" hang).  A table not named in the SQL
                        # can't carry a WHERE filter anyway, so this misses
                        # nothing.  Over-inclusion (name is a substring) is safe.
                        _qg_sql_lc = (_effective_raw_sql or "").lower()

                        def _qg_referenced(_nm) -> bool:
                            # Match the registered name AS THE SQL WRITES IT: the
                            # full (possibly schema-qualified) name OR its bare
                            # last dot-segment.  sqlglot strips schemas and users
                            # often reference a ``schema.table`` registration by
                            # the bare ``table`` token (and vice-versa); matching
                            # only the full name would MISS it → partition WHERE
                            # not detected → a bogus full-scan block when
                            # require_partition_filter/action=block is configured.
                            # Over-inclusion is safe (an unreferenced table just
                            # gets resolved once); a MISS is the harmful direction.
                            _nl = str(_nm).lower()
                            return _nl in _qg_sql_lc or _nl.rsplit(".", 1)[-1] in _qg_sql_lc

                        _qg_reg = [
                            _t for _t in _qg_reg
                            if isinstance(_t, dict) and _t.get("name")
                            and _qg_referenced(_t["name"])
                        ]
                        _qg_bucket = (_qg_conn_raw or {}).get("config", {}).get("bucket_name", "")
                        _qg_s3 = None  # built lazily — only if tier 1+2 miss
                        _qg_pc_map = {}
                        for _qg_t in _qg_reg:
                            if not isinstance(_qg_t, dict) or not _qg_t.get("name"):
                                continue
                            _qg_tname = _qg_t["name"]
                            # Build s3 client lazily for tier-3 (iceberg metadata)
                            if (_qg_t.get("format") == "iceberg"
                                    and _qg_bucket and _qg_t.get("s3_prefix")
                                    and _qg_s3 is None):
                                try:
                                    from core.s3_utilities import make_s3_client_for_conn
                                    _qg_s3 = await asyncio.to_thread(
                                        make_s3_client_for_conn,
                                        {"id": _qg_conn_id, "config": _qg_conn_raw.get("config", {})},
                                    )
                                except Exception:
                                    _qg_s3 = None
                            _qg_pcols = await asyncio.to_thread(
                                resolve_partition_columns,
                                registered_table=_qg_t,
                                db_manager=_db_manager,
                                connection_id=_qg_conn_id,
                                table_name=_qg_tname,
                                s3_client=_qg_s3,
                                bucket=_qg_bucket,
                                table_prefix=_qg_t.get("s3_prefix"),
                            )
                            if _qg_pcols:
                                _qg_pc_map[_qg_tname] = _qg_pcols
                        if _qg_pc_map:
                            from core.sql_partition_extractor import (
                                extract_combined_filters_for_iceberg,
                            )
                            _qg_ext = extract_combined_filters_for_iceberg(
                                _effective_raw_sql, _qg_pc_map, dialect="duckdb",
                            )
                            _qg_part_cols = {
                                c.lower()
                                for cols in _qg_pc_map.values()
                                for c in cols
                            }
                            if any(
                                (f.get("col") or "").lower().rsplit(".", 1)[-1] in _qg_part_cols
                                for f in (_qg_ext or [])
                            ):
                                _has_partition_filter = True
                                logger.info(
                                    "[guardrail] partition filter detected in raw SQL WHERE — "
                                    "skipping full-scan flag",
                                )
                    except Exception as _qg_where_exc:
                        logger.debug(
                            "[guardrail] WHERE-clause partition detection failed (non-fatal): %s",
                            _qg_where_exc,
                        )
                if _qg_cfg.require_partition_filter and _file_count > 0 and not _has_partition_filter:
                    _gr_conn_id = request.connection_id or query_config_model.connection_id
                    if _gr_conn_id and _db_manager:
                        for _tbl in (query_config_model.files or []):
                            try:
                                _parts = await adb(_db_manager.get_connection_partitions, _gr_conn_id, str(_tbl))
                                if _parts:
                                    raise HTTPException(
                                        status_code=400,
                                        detail=f"Table '{_tbl}' has partitions defined. Please select "
                                               "at least one partition filter before running the query.",
                                    )
                            except HTTPException:
                                raise
                            except Exception as e:
                                logger.warning("Partition validation check failed: %s", e)
                # Phase 107-C: S3 detection-first guardrail (default action="log")
                _gr_conn_id2 = request.connection_id or query_config_model.connection_id
                _gr_user = (_user or {}).get("username") if isinstance(_user, dict) else None
                # OFF the loop (2026-07-22): sync DB reads (get_connection_raw +
                # get_connection_partitions per table); on a slow/locked DB they
                # froze the async loop.
                _gr_result = await asyncio.to_thread(
                    check_s3_full_scan,
                    db=_db_manager,
                    connection_id=_gr_conn_id2,
                    tables=[str(f) for f in (query_config_model.files or [])],
                    has_partition_filter=_has_partition_filter,
                    source="execute_query",
                    user=_gr_user,
                )
                if _gr_result.is_full_scan and _gr_result.action == "block":
                    raise HTTPException(status_code=400, detail=_gr_result.message)
        except HTTPException:
            raise
        except Exception as e:
            logger.warning("Query guardrail evaluation failed, proceeding without guardrails: %s", e)

        # ── Resolve username early (needed by cache-hit WS broadcasts) ──
        _username = _user.get("username", "guest") if _user else "guest"

        # Resolve engine based on connection type
        # Explicit request.connection_id takes priority; fall back to connection_id stored in saved query
        _effective_conn_id = request.connection_id or query_config_model.connection_id
        active_engine = _engine
        _uses_registered = False
        # True when the PRIMARY is a SQL connector feeding the cross-source
        # path (see "Cross-source with a SQL-connector PRIMARY" below).
        _primary_is_connector = False
        _conn_type = None
        if _effective_conn_id:
            conn_record = await adb(_db_manager.get_connection_raw, _effective_conn_id)
            if conn_record:
                _conn_type = conn_record.get('connection_type')
                _cfg = conn_record.get('config', {})
                if _conn_type == 'local':
                    local_path = str(_normalize_path(_cfg.get('base_path', '/usr/local/querystudioapi/nfs/data/parquet')))
                    active_engine = ParquetQueryEngine(
                        base_path=local_path,
                        chunk_size=_qe_cfg.chunk_size,
                    )
                elif _conn_type == 's3':
                    # Unified credential resolution (portal, keys, assume_role, etc.)
                    from core.credential_resolver import resolve_s3_credentials as _resolve_pri
                    # BF-286: propagate the connection's is_shared flag into
                    # the config dict so the credential manager can pick the
                    # right path (system account vs. user vault) without
                    # the admin needing to set credential_source explicitly.
                    _cfg_for_resolve = dict(_cfg)
                    _cfg_for_resolve["is_shared"] = bool(conn_record.get("is_shared", False))
                    try:
                        # BF-406: _resolve_pri makes HTTP calls to the AWS
                        # portal (through corporate proxy if configured).
                        # Through slow proxies this can take 5-30s.
                        # Previously called synchronously inside an async
                        # handler → blocked the asyncio event loop for the
                        # entire portal RTT → ALL other HTTP requests + WS
                        # broadcasts froze ("backend unavailable" symptom).
                        # Wrap in to_thread so the loop stays responsive.
                        # Cap at 20s — beyond that something is genuinely
                        # broken with the portal, fail fast with clear error.
                        # BF-461: preflight refresh for the primary execution.
                        # BQB / CQB raw_sql + streaming + cross-conn primary
                        # all flow through this code.  Long-running scans
                        # would otherwise die mid-flight on near-expiry creds.
                        from core.config import aws_portal as _ap_pri_cfg
                        _pri_cfg_injected = await asyncio.wait_for(
                            asyncio.to_thread(
                                _resolve_pri,
                                _cfg_for_resolve,
                                # SECURITY 2026-08-23 (F-047): credentials are
                                # resolved for the SESSION principal, never for
                                # a name supplied in the request body.  The
                                # connection entitlement above is checked
                                # against the caller, so honouring body
                                # `executed_by` here let a non-admin POST
                                # {"executed_by": "alice"} and scan S3 under
                                # ALICE's STS identity.  graphql_api and
                                # reports_api already resolve from the session;
                                # this path was the odd one out.
                                _username,
                                False,  # force_refresh
                                _ap_pri_cfg.preflight_min_lifetime_seconds,
                            ),
                            timeout=20.0,
                        )
                    except asyncio.TimeoutError:
                        raise HTTPException(
                            status_code=504,
                            detail="Credential resolution from AWS portal exceeded 20s "
                                   "— portal may be slow or unreachable through the proxy.  "
                                   "Check Admin → AWS Portal → Test Connection.",
                        ) from None
                    except Exception as _cred_exc:
                        # BF-286: PersonalPasswordRequired → 401 with the
                        # structured detail the BF-285 frontend modal listens
                        # for.  Other CredentialResolutionError → 500 with
                        # a clear admin-facing message.
                        # BF-PORTAL-CONN-OVERRIDES: include connection_id so the
                        # frontend modal can echo it back to
                        # /api/aws-portal/authenticate — that path now reads
                        # connection-level portal_base_url/proxy_url/role_name
                        # overrides so the JWT call matches what Connection
                        # Manager uses for the same connection.
                        from core.credential_manager import PersonalPasswordRequired
                        if isinstance(_cred_exc, PersonalPasswordRequired):
                            raise HTTPException(status_code=401, detail={
                                "type":    "portal_password_required",
                                "message": str(_cred_exc),
                                "username": (request.executed_by or _username or ""),
                                "connection_id": _effective_conn_id,
                            })
                        raise
                    # OFF the event loop (2026-07-22): ParquetQueryEngine.__init__
                    # builds an S3StorageHandler → boto3 session.client('s3'),
                    # whose botocore service-model load blocks synchronously.  On
                    # the loop this froze the entire event loop (watchdog:
                    # MainThread stuck in botocore list_available_services for
                    # 46s+, starving every request + the health probe).  Offload.
                    _pri_s3_config = build_s3_config(_pri_cfg_injected)
                    active_engine = await asyncio.to_thread(
                        ParquetQueryEngine,
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=_pri_s3_config,
                    )
                    # Check if query uses registered/materialized/local tables (virtual path prefix)
                    def _has_virtual_prefix(paths):
                        return any(
                            f.startswith("__registered__:") or f.startswith("__materialized__:") or f.startswith("__local__:") or f.startswith("__federation__:")
                            for f in (paths or [])
                        )
                    _join_files = [
                        j.right_file if isinstance(j.right_file, str) else j.right_file
                        for j in (query_config_model.joins or [])
                    ] if query_config_model.joins else []
                    _uses_registered = (
                        _has_virtual_prefix(query_config_model.files or [])
                        or _has_virtual_prefix(_join_files)
                    )
                    # Always set S3 config on the engine for S3 connections.
                    # raw_sql (BQB) needs _s3_conn_config to create views via
                    # setup_registered_views; without it, raw SQL falls through
                    # to execute_raw_duckdb_sql() which has no S3 views.
                    # CRITICAL: pass injected config (not raw _cfg) so duckdb_views
                    # gets resolved credentials for portal/assume_role connections
                    active_engine._s3_conn_config = _pri_cfg_injected
                    active_engine._s3_bucket = _cfg.get("bucket_name", "")
                    active_engine._s3_conn_id = _effective_conn_id
                    _has_s3_registered = any(
                        str(f).startswith("__registered__:") or str(f).startswith("__federation__:")
                        for f in list(query_config_model.files or []) + _join_files
                    )
                    if _uses_registered and _has_s3_registered:
                        active_engine._registered_tables = _cfg.get("registered_tables", [])
                    elif _uses_registered:
                        # Local/MV tables under an S3 connection — don't need registered table list
                        active_engine._registered_tables = []
                    else:
                        # No virtual prefixes but still S3 — raw_sql may reference
                        # registered tables, so expose them for view creation.
                        active_engine._registered_tables = _cfg.get("registered_tables", [])
                elif _conn_type in SQL_CONNECTOR_TYPES:
                    # ── SQL connector execution path ──────────────────────────
                    # Build SQL from the query config and dispatch to the connector.
                    # Bypass parquet validation — there are no local files to check.
                    # 2026-10-07: off the loop -- a system-account connection reads its row (and Vault) here.
                    sql_connector = await asyncio.to_thread(
                        get_connector, _conn_type, _cfg, _effective_conn_id,
                        conn_record.get("name", ""))
                    # BF-SQL-CONN-CQB: when CQB hands us raw SQL, table_ref
                    # never gets assigned in the else-branch, but it's still
                    # referenced in the audit log + status message below
                    # → UnboundLocalError at runtime ("cannot access local
                    # variable 'table_ref'").  Initialise to a parsed FROM
                    # clause when raw_sql is given (best-effort), else to
                    # None.  The audit/log lines treat None gracefully.
                    table_ref: Optional[str] = None
                    if _effective_raw_sql:
                        sql_str = _effective_raw_sql
                        try:
                            import sqlglot as _sg_tref
                            _parsed_tref = _sg_tref.parse_one(
                                _effective_raw_sql,
                                error_level=_sg_tref.ErrorLevel.IGNORE,
                            )
                            if _parsed_tref:
                                _first_t = next(iter(_parsed_tref.find_all(_sg_tref.exp.Table)), None)
                                if _first_t and _first_t.name:
                                    table_ref = _first_t.name
                        except Exception:
                            pass  # leave table_ref = None
                    else:
                        engine_config = convert_query_config_to_engine(query_config_model)
                        # 2026-09-05 round 2 -- ONE CHOKEPOINT FOR PREVIEW
                        # AND RUN.  This line was ``files[0]`` verbatim, with
                        # no check at all, so ``files=["__registered__:sales"]``
                        # on a Trino connection shipped
                        # ``SELECT "amount" FROM sales AS __registered__``
                        # (sqlglot reads the ``:`` as an ALIAS separator) --
                        # a bare unqualified name Trino resolves against the
                        # session's default catalog, the DIFFERENT-TABLE-READ-
                        # WITH-NO-ERROR defect, arriving by the door nobody
                        # had looked at.  And a 2-file union ran only
                        # ``files[0]``: half the rows, HTTP 200.  Meanwhile
                        # /api/execute/preview-sql, routed through the same
                        # decision earlier that day, REFUSED both -- so the
                        # preview refused what the run executed, with the run
                        # side on the wrong-answer half, under a docstring
                        # claiming preview == run.
                        try:
                            table_ref = _native_from_ref(
                                engine_config.files, engine_config.joins,
                                _conn_type)
                        except _QueryNotExpressible as _qne_exec:
                            logger.info(
                                "[execute] config cannot be expressed on %s "
                                "(connection %s): %s", _conn_type,
                                _effective_conn_id, _qne_exec)
                            raise HTTPException(status_code=400, detail={
                                "error": "query_not_expressible",
                                "engine": _conn_type,
                                "connection_id": _effective_conn_id,
                                "message": str(_qne_exec),
                                "sql": "",
                            })
                        if table_ref is None:
                            # Not an engine this builder renders natively
                            # (``rest_api``: routed to a connector, no
                            # dialect mapping).  Cannot-tell is not a
                            # refusal -- unchanged, byte for byte.
                            table_ref = (query_config_model.files[0]
                                         if query_config_model.files else None)
                        if not table_ref:
                            raise HTTPException(status_code=400, detail="No table specified in query config")
                        # 2026-08-19 -- TYPE the filter literals.  Without a
                        # declared type every value reached the engine as a
                        # quoted string, so a DATE column failed outright
                        # ("Cannot apply operator: date = varchar(10)") and a
                        # numeric one could silently match nothing.  The UI may
                        # now send data_type per filter; when it does not, ask
                        # the catalog.  Fail-open and cached -- an unavailable
                        # DESCRIBE just leaves the values untyped, exactly as
                        # before.
                        try:
                            from core.column_types import (
                                annotate_filter_types, resolve_column_types)
                            _col_types = await asyncio.to_thread(
                                resolve_column_types, sql_connector, table_ref,
                                _cfg, _effective_conn_id)
                            annotate_filter_types(engine_config.filters,
                                                  _col_types)
                        except Exception as _ct_exc:
                            logger.debug("filter type annotation skipped: %s",
                                         _ct_exc)

                        # Dialect-aware: OFFSET/LIMIT order and Oracle's
                        # FETCH syntax differ per engine (2026-08-19).
                        sql_str = _engine.build_query_sql(
                            engine_config, table_ref, dialect=_conn_type)

                        # 2026-08-19 -- ROW SECURITY ON THE STRUCTURED PATH.
                        # The raw-SQL branch above was secured ~400 lines up
                        # (on _effective_raw_sql) and the DuckDB structured
                        # path secures a synthesized query in
                        # execute_query_background -- but SQL built HERE went
                        # straight to execute_sql_connector_background, which
                        # contains no row-security code at all.  Net effect:
                        # the SAME visual query was FILTERED against
                        # S3/parquet and UNFILTERED against Trino, Snowflake,
                        # Databricks, Oracle and Athena.  Not a degradation --
                        # rows the policy excludes were returned as success.
                        try:
                            from core.row_security import secure_sql as _rs_sec2
                            from core.row_security.api import (
                                PolicyResolutionError as _RsErr2)
                            from core.sql_filter_wrapper import (
                                dialect_for_connection_type as _dial2)
                            _secured_str = await asyncio.to_thread(
                                _rs_sec2,
                                sql_str,
                                # The TARGET's grammar, not duckdb: parsing
                                # Trino SQL as duckdb can mangle syntax the
                                # rewriter then re-emits.
                                dialect=_dial2(_conn_type),
                                user_ctx=_user,
                                connection_id=_effective_conn_id,
                                request_id=getattr(
                                    request, "execution_id", None),
                            )
                            if _secured_str:
                                sql_str = _secured_str
                        except _RsErr2 as _rs_e2:
                            # Fail-closed: if policy resolution itself broke,
                            # running unfiltered is the one outcome we cannot
                            # allow.
                            logger.error(
                                "Row-security rewrite failed on the %s "
                                "structured path: %s", _conn_type, _rs_e2)
                            raise HTTPException(
                                status_code=403,
                                detail=("Row-security policy enforcement "
                                        f"failed: {_rs_e2}"),
                            )

                    # ── Cross-source with a SQL-connector PRIMARY (2026-10-04) ──
                    # Measured live (X1/X2): this branch RETURNED below even
                    # when a secondary was requested, so a Snowflake or Trino
                    # primary came back 200 with ONLY its own rows -- the
                    # secondary silently dropped.  The primary's FINAL,
                    # SECURED statement now becomes a connector side and the
                    # request falls through to the cross-source path, which
                    # runs any side type through the one side runner.
                    _x_cross_requested = bool(
                        request.secondary_connection_id
                        and (request.secondary_query_config
                             or request.secondary_raw_sql))
                    if _x_cross_requested:
                        try:
                            sql_connector.close()
                        except Exception:
                            pass
                        active_engine = _CrossSourceConnectorEngine(
                            connection={**conn_record,
                                        "id": _effective_conn_id},
                            sql=sql_str,
                            chunk_size=_qe_cfg.chunk_size,
                        )
                        _primary_is_connector = True
                    if not _x_cross_requested:
                        # ── SQL connector cache check ─────────────────────────────
                        _sql_qc_dict = query_config_model.model_dump()
                        # Include raw_sql in key so manually typed SQL is keyed separately
                        if _effective_raw_sql:
                            _sql_qc_dict["_raw_sql"] = _effective_raw_sql
                        _sql_qc_dict["_conn_type"] = _conn_type
                        from core.query_cache import make_cache_key as _mk_sql_ck, get_cached_result as _get_sql_cached, rls_user_scope as _rls_us_sql
                        # Round 5: per-user scope when RLS is enabled.
                        _sql_scope = _rls_us_sql(_user)
                        _sql_cache_key = _mk_sql_ck(_sql_qc_dict, user_scope=_sql_scope)
                        if request.cache_strategy == "auto":
                            _sql_cached_path = _get_sql_cached(_sql_cache_key)
                            if _sql_cached_path:
                                try:
                                    _sql_cached_size = _sql_cached_path.stat().st_size
                                except FileNotFoundError:
                                    from core.query_cache import invalidate as _sql_cache_inv
                                    _sql_cache_inv(_sql_cache_key)
                                    _sql_cached_path = None
                            if _sql_cached_path:
                                _c_file_size = _sql_cached_path.stat().st_size
                                _c_stats = {}
                                try:
                                    import pyarrow.parquet as _pq_c
                                    _c_pf = _pq_c.ParquetFile(str(_sql_cached_path))
                                    _c_stats = {"total_rows": _c_pf.metadata.num_rows,
                                                "total_columns": _c_pf.metadata.num_columns}
                                except Exception as _pq_stat_exc:
                                    # BF-CACHE-CORRUPT: same fix as the S3 cache path —
                                    # on unreadable cached parquet, evict and fall
                                    # through to fresh execution.
                                    logger.warning(
                                        "[sql_connector_cache] Cached parquet unreadable — evicting + re-executing: %s (path=%s)",
                                        _pq_stat_exc, _sql_cached_path,
                                    )
                                    try:
                                        from core.query_cache import invalidate as _sql_cache_inv2
                                        _sql_cache_inv2(_sql_cache_key)
                                    except Exception:
                                        pass
                                    _sql_cached_path = None
                            if _sql_cached_path:
                                _c_exec_id = str(uuid.uuid4())
                                _c_file_id = str(uuid.uuid4())
                                await adb(_db_manager.create_execution, 
                                    execution_id=_c_exec_id,
                                    query_id=request.query_id,
                                    query_config=_sql_qc_dict,
                                    executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                                )
                                await adb(_db_manager.update_execution, _c_exec_id, status="completed",
                                                            engine="result_cache",
                                                            output_file=str(_sql_cached_path),
                                                            total_rows=_c_stats.get("total_rows", 0),
                                                            file_size_bytes=_c_file_size)
                                await adb(_db_manager.create_download_file, 
                                    file_id=_c_file_id, execution_id=_c_exec_id,
                                    filename=f"cached_result_{_c_exec_id}.parquet",
                                    file_path=str(_sql_cached_path),
                                    file_size_bytes=_c_file_size,
                                    expires_at=_download_expires_at(transient=True),
                                )
                                await _ws_manager.broadcast_to_user(_username, _with_engine({
                                    "type": "execution_completed", "execution_id": _c_exec_id,
                                    "file_id": _c_file_id, "cache_hit": True,
                                    "stats": _c_stats,
                                    "timestamp": datetime.now(timezone.utc).isoformat(),
                                }, "result_cache"))
                                return {
                                    "execution_id": _c_exec_id, "status": "completed",
                                    "cache_hit": True, "file_id": _c_file_id,
                                    "message": "Served from cache",
                                }

                        # 2026-09-28: the global cap (load shed, 503) is decided
                        # INSIDE the slot grant below, atomically with the
                        # increment -- global before per-user, as before.
                        # BF-591: pre-generate execution_id BEFORE the acquire
                        # so cancel_queued_execution(execution_id) can find the
                        # cancel registry entry while we're queued.  Previously
                        # the execution_id was generated AFTER acquire, leaving
                        # any queued cancel as a permanent no-op for SQL
                        # connector requests.
                        execution_id = str(uuid.uuid4())
                        # BF-584: queue-aware slot acquire.
                        _slot_ok, _slot_reason, _slot_wait = await _acquire_user_slot(
                            _username,
                            _qe_cfg.max_concurrent_per_user,
                            _qe_cfg.max_queue_size,
                            _qe_cfg.queue_wait_timeout_seconds,
                            execution_id=execution_id,
                            max_global=_global_cap(),
                            global_wait_timeout=_interactive_global_wait(),
                            client_request_id=request.client_request_id,
                        )
                        if not _slot_ok:
                            _raise_if_load_shed(_slot_reason, _slot_wait)
                            if _slot_reason == "cancelled":
                                # H1: cancelled while it waited -- an answer,
                                # not "Server busy (cancelled)"; no row exists.
                                return _cancelled_while_queued(execution_id)
                            raise HTTPException(
                                status_code=503,
                                detail=(
                                    f"Server busy ({_slot_reason}): no slot freed "
                                    f"within {_qe_cfg.queue_wait_timeout_seconds}s."
                                ),
                                headers={"Retry-After": "30"},
                            )
                        # BF-591: orphan tracker on this acquire path too.
                        _pending_owner_by_req[_req_key] = _username
                        try:
                            # Record checkpoint intent (Phase 41)
                            # 2026-10-07: awaited on the checkpoint lane, not inline on the loop.
                            from core.checkpoint import arecord_intent as _record_intent_sql
                            await _record_intent_sql(execution_id, query_config_model.model_dump(),
                                                     executed_by=request.executed_by or _username,
                                                     query_id=request.query_id)
                            execution = await adb(_db_manager.create_execution,
                                execution_id=execution_id,
                                query_id=request.query_id,
                                query_config=query_config_model.model_dump(),
                                executed_by=request.executed_by or _username
                            )
                            # BF-591: strong-ref track so Python issue #88831
                            # cannot GC the in-flight task mid-await.
                            _track_bg_task(
                                execute_sql_connector_background(
                                    execution_id, sql_connector, sql_str,
                                    query_id=request.query_id, executed_by=_username,
                                    cache_key=_sql_cache_key,
                                    cache_key_scope=_sql_scope,
                                    cache_strategy=request.cache_strategy or "auto",
                                    query_config_dict=_sql_qc_dict,
                                )
                            )
                            _pending_owner_by_req.pop(_req_key, None)
                        except BaseException:  # incl. CancelledError -- a cancel here must not leak the slot
                            # BF-584: release slot + wake queued waiter on
                            # task-creation failure.
                            _release_user_slot(_username)
                            _pending_owner_by_req.pop(_req_key, None)
                            raise
                        _audit(_user, "execute_sql_connector_query", None, "execution", execution_id,
                               {"conn_type": _conn_type, "table": table_ref, "query_id": request.query_id})
                        logger.info(f"SQL connector query started: {execution_id} ({_conn_type}:{table_ref})")
                        return {
                            "execution_id": execution_id,
                            "status": "pending",
                            "started_at": execution["started_at"],
                            "message": f"SQL connector query started ({_conn_type})"
                        }

        # Also treat MV/local table refs as "registered" (skip file validation, use _setup_registered_views)
        if not _uses_registered:
            _all_file_paths = list(query_config_model.files or [])
            if any(str(f).startswith("__materialized__:") or str(f).startswith("__local__:") for f in _all_file_paths):
                _uses_registered = True
                # Ensure engine has the required attributes for _execute_registered_table_*
                if not hasattr(active_engine, '_registered_tables') or not active_engine._registered_tables:
                    active_engine._registered_tables = []
                if not hasattr(active_engine, '_s3_conn_config') or not active_engine._s3_conn_config:
                    active_engine._s3_conn_config = {}
                if not hasattr(active_engine, '_s3_bucket'):
                    active_engine._s3_bucket = ""
                if not hasattr(active_engine, '_s3_conn_id'):
                    active_engine._s3_conn_id = _effective_conn_id

        engine_config = convert_query_config_to_engine(query_config_model)

        # ── Cross-connection join / union path ────────────────────────────────
        if request.secondary_connection_id and (request.secondary_query_config or request.secondary_raw_sql):
            # Validate secondary connection exists
            sec_conn_record = await adb(_db_manager.get_connection_raw, request.secondary_connection_id)
            if not sec_conn_record:
                raise HTTPException(
                    status_code=404,
                    detail=f"Secondary connection {request.secondary_connection_id} not found"
                )

            # Build secondary query config — from explicit config or from raw SQL
            if request.secondary_query_config:
                try:
                    # the client's dict, so the boundary rule applies
                    sec_qc_model = QueryConfigRequestModel(**request.secondary_query_config)
                except Exception as _pve:
                    raise HTTPException(status_code=400,
                                        detail=f"Invalid secondary_query_config: {_pve}")
            else:
                # SQL mode: raw SQL flows via secondary_raw_sql param, not QueryConfigModel
                sec_qc_model = QueryConfigModel(files=[])

            # Ensure secondary connection_id is in query config (cache key isolation)
            if request.secondary_connection_id and not sec_qc_model.connection_id:
                sec_qc_model = sec_qc_model.model_copy(
                    update={"connection_id": request.secondary_connection_id}
                )

            # ── Partition enforcement for secondary side (BF-120 deep-dive) ──
            try:
                from core.config import query_guardrails as _qg_cfg
                from core.query_guardrails import has_any_partition_filter
                if _qg_cfg.enabled and _qg_cfg.require_partition_filter:
                    _sec_files = sec_qc_model.files or []
                    _sec_has_pf = has_any_partition_filter(sec_qc_model.filters)
                    if _sec_files and not _sec_has_pf and _db_manager:
                        for _stbl in _sec_files:
                            try:
                                _sp = await adb(_db_manager.get_connection_partitions, 
                                    request.secondary_connection_id, str(_stbl))
                                if _sp:
                                    raise HTTPException(
                                        status_code=400,
                                        detail=f"Secondary table '{_stbl}' has partitions defined. "
                                               "Please select at least one partition filter before "
                                               "running the cross-connection query.",
                                    )
                            except HTTPException:
                                raise
                            except Exception as _spe:
                                logger.warning("Secondary partition check failed: %s", _spe)
            except HTTPException:
                raise
            except Exception as _sec_gr_exc:
                logger.warning("Secondary guardrail evaluation failed: %s", _sec_gr_exc)

            # 2026-10-04 -- THE combine vocabulary and THE side-type gate,
            # before either side does any work.  ``outer`` is ``full`` here
            # as everywhere; a join without keys, an unknown join type, and a
            # side this product cannot read are each a 400 that names the
            # problem -- never a secondary silently replaced by the default
            # engine (an unrecognised secondary type used to fall through to
            # ``_engine`` and run against the local parquet directory).
            from core.executors.cross_source_combine import (
                CrossSourceRefusal as _XRefusal, combine_spec as _x_spec_r,
                refuse_unsupported_side as _x_refuse_side)
            _sc_type = sec_conn_record.get('connection_type')
            _sc_cfg = sec_conn_record.get('config', {})
            try:
                _x_spec_r(request.combine_mode, request.join_config or {})
                if _conn_type:      # no connection = the default local engine
                    _x_refuse_side(_conn_type, "primary")
                _x_refuse_side(_sc_type, "secondary")
            except _XRefusal as _x_ref:
                raise HTTPException(status_code=400, detail=str(_x_ref))

            # Resolve secondary engine
            secondary_engine = _engine

            # BF-38: Inject portal credentials BEFORE engine creation so the
            # S3StorageHandler gets the correct per-user creds (not stale
            # connection-level ones).  Same injected config is reused later
            # for the file-listing boto3 client.
            _sc_cfg_injected = _sc_cfg
            if _sc_type == 's3':
                from core.credential_resolver import resolve_s3_credentials as _resolve_sec
                # BF-406: same loop-blocking fix as primary — credential
                # resolution makes HTTP calls to the AWS portal through
                # the corporate proxy.  Wrap in to_thread + 20s cap.
                try:
                    # BF-461: preflight refresh for cross-conn secondary side.
                    from core.config import aws_portal as _ap_sec_cfg
                    _sc_cfg_injected = await asyncio.wait_for(
                        asyncio.to_thread(
                            _resolve_sec, dict(_sc_cfg),
                            # SECURITY 2026-08-23 (F-047) — see the primary
                            # connection's note above: session principal only.
                            _username,
                            False,  # force_refresh
                            _ap_sec_cfg.preflight_min_lifetime_seconds,
                        ),
                        timeout=20.0,
                    )
                except asyncio.TimeoutError:
                    raise HTTPException(
                        status_code=504,
                        detail="Secondary connection credential resolution exceeded "
                               "20s — check secondary AWS portal reachability.",
                    ) from None

            # BF-XSRC-CONN: cross-source connector wrapper.  When secondary
            # is a SQL connector (Starburst/Trino/Snowflake/Databricks/Oracle/
            # Athena), build an in-memory wrapper engine whose .execute_query
            # / .execute_raw_duckdb_sql methods dispatch to the connector
            # so the existing _exec_side_to_parquet pipeline writes the
            # connector's result rows into the temp parquet for combine.
            _sec_sql_connector = None
            _sec_sql_str = None
            if _sc_type == 'local':
                _sc_path = str(_normalize_path(_sc_cfg.get('base_path', '/usr/local/querystudioapi/nfs/data/parquet')))
                secondary_engine = ParquetQueryEngine(
                    base_path=_sc_path,
                    chunk_size=_qe_cfg.chunk_size,
                )
            elif _sc_type == 's3':
                # OFF the loop (2026-07-22): boto3 client build blocks — see the
                # primary engine offload above.
                _sec_s3_config = build_s3_config(_sc_cfg_injected)
                secondary_engine = await asyncio.to_thread(
                    ParquetQueryEngine,
                    base_path=str(_paths.parquet_dir),
                    chunk_size=_qe_cfg.chunk_size,
                    s3_config=_sec_s3_config,
                )
                secondary_engine._registered_tables = _sc_cfg.get("registered_tables", [])
                secondary_engine._s3_conn_config = _sc_cfg_injected
                secondary_engine._s3_bucket = _sc_cfg.get("bucket_name", "")
                secondary_engine._s3_conn_id = request.secondary_connection_id
            elif _sc_type in SQL_CONNECTOR_TYPES:
                # Build the SQL string that will run on the connector.
                # 2026-10-07: off the loop -- a system-account connection reads its row (and Vault) here.
                _sec_sql_connector = await asyncio.to_thread(
                    get_connector,
                    _sc_type, _sc_cfg, request.secondary_connection_id,
                    sec_conn_record.get("name", ""),
                )
                if request.secondary_raw_sql:
                    # 2026-08-19 -- use the EFFECTIVE secondary SQL, not the
                    # raw request field.  _effective_secondary_raw_sql is the
                    # one that had params substituted AND the row-security
                    # rewrite applied ~800 lines above; reading
                    # request.secondary_raw_sql threw both away, so the
                    # secondary leg of a cross-source query ran UNSECURED
                    # and unsubstituted.
                    _sec_sql_str = (_effective_secondary_raw_sql
                                    or request.secondary_raw_sql)
                else:
                    _sec_qc_engine = convert_query_config_to_engine(sec_qc_model)
                    # 2026-09-05 round 2 -- same chokepoint as the primary
                    # leg.  A cross-source query whose SECONDARY side is a
                    # virtual ref de-qualified exactly as the primary did,
                    # and the joined answer looked entirely normal.
                    try:
                        _sec_table_ref = _native_from_ref(
                            _sec_qc_engine.files, _sec_qc_engine.joins,
                            _sc_type)
                    except _QueryNotExpressible as _qne_sec:
                        raise HTTPException(status_code=400, detail={
                            "error": "query_not_expressible",
                            "engine": _sc_type,
                            "connection_id": request.secondary_connection_id,
                            "message": str(_qne_sec),
                            "sql": "",
                        })
                    if _sec_table_ref is None:
                        _sec_table_ref = (sec_qc_model.files[0]
                                          if sec_qc_model.files else None)
                    if not _sec_table_ref:
                        raise HTTPException(
                            status_code=400,
                            detail=f"Secondary {_sc_type} connection requires raw_sql or files[0] (table name).",
                        )
                    # Type the filters and secure the result -- the
                    # structured secondary leg had neither.
                    from core.column_types import (
                        annotate_from_connector as _annot_sec)
                    _annot_sec(_sec_qc_engine.filters, _sec_sql_connector,
                               _sec_table_ref, _sc_cfg,
                               request.secondary_connection_id)
                    _sec_sql_str = _engine.build_query_sql(
                        _sec_qc_engine, _sec_table_ref, dialect=_sc_type)
                    try:
                        from core.row_security import secure_sql as _rs_sec3
                        from core.row_security.api import (
                            PolicyResolutionError as _RsErr3)
                        from core.sql_filter_wrapper import (
                            dialect_for_connection_type as _dial3)
                        _sec_secured = await asyncio.to_thread(
                            _rs_sec3, _sec_sql_str, dialect=_dial3(_sc_type),
                            user_ctx=_user,
                            connection_id=request.secondary_connection_id,
                            request_id=getattr(request, "execution_id", None),
                        )
                        if _sec_secured:
                            _sec_sql_str = _sec_secured
                    except _RsErr3 as _rs_e3:
                        raise HTTPException(
                            status_code=403,
                            detail=("Row-security policy enforcement failed "
                                    f"on the secondary connection: {_rs_e3}"),
                        )
                try:
                    _sec_sql_connector.close()   # it only typed the filters
                except Exception:
                    pass
                secondary_engine = _CrossSourceConnectorEngine(
                    connection={**sec_conn_record,
                                "id": request.secondary_connection_id},
                    sql=_sec_sql_str,
                    chunk_size=_qe_cfg.chunk_size,
                )

            secondary_config = convert_query_config_to_engine(sec_qc_model)

            # ── Resolve virtual prefixes in PRIMARY config ──────────────────
            # __registered__:, __local__:, __materialized__: work in DuckDB
            # subprocess but NOT in ParquetQueryEngine.  Resolve to actual
            # S3 paths or local parquet file paths before passing to engine.
            # BF-120: Skip resolution when raw_sql is present — setup_registered_views()
            # handles the resolution internally with partition pruning + presigned URLs.
            if (engine_config.files and not _effective_raw_sql
                    and not _primary_is_connector):
                _resolved_primary = []
                _pri_registered = _cfg.get("registered_tables", []) or [] if _cfg else []
                _pri_bucket = (_cfg.get("bucket_name") or "").strip() if _cfg else ""
                _lt_storage = str(_paths.local_tables_dir) if hasattr(_paths, 'local_tables_dir') else str(_paths.data_dir / "local_tables")
                _mv_storage = str(_paths.mv_dir) if hasattr(_paths, 'mv_dir') else str(_paths.data_dir / "materialized_views")
                for _pf in engine_config.files:
                    _pf_str = _pf if isinstance(_pf, str) else str(_pf)
                    if _pf_str.startswith("__registered__:"):
                        # BF-47: Resolve __registered__: for PRIMARY in cross-conn
                        _pri_tbl_name = _pf_str.replace("__registered__:", "")
                        _pri_found = next((t for t in _pri_registered if t.get("name") == _pri_tbl_name), None)
                        if _pri_found:
                            _pri_s3_prefix = _pri_found.get("s3_prefix", "").rstrip("/")
                            _resolved_primary.append(f"s3://{_pri_bucket}/{_pri_s3_prefix}")
                            logger.info("Cross-conn primary: resolved __registered__:%s → s3://%s/%s",
                                        _pri_tbl_name, _pri_bucket, _pri_s3_prefix)
                        else:
                            # BF-53: Do NOT keep the __registered__: prefix — it creates
                            # invalid local paths on Windows (colon is illegal in paths).
                            logger.warning("Cross-conn primary: registered table '%s' not found in connection config", _pri_tbl_name)
                    elif _pf_str.startswith("__local__:"):
                        _lt_name = _pf_str.replace("__local__:", "")
                        _lt_rec = await adb(_db_manager.get_local_table_by_name, _lt_name)
                        if _lt_rec and _lt_rec.get("storage_path"):
                            import glob as _glob_lt
                            _lt_dir = _lt_rec["storage_path"]
                            _lt_pq = _glob_lt.glob(os.path.join(_lt_dir, "*.parquet"))
                            if _lt_pq:
                                _resolved_primary.extend(_lt_pq)
                                logger.info("Cross-conn primary: resolved __local__:%s → %d parquet file(s)", _lt_name, len(_lt_pq))
                            else:
                                logger.warning("Cross-conn primary: __local__:%s has no parquet files in %s", _lt_name, _lt_dir)
                        else:
                            logger.warning("Cross-conn primary: local table '%s' not found in DB", _lt_name)
                    elif _pf_str.startswith("__materialized__:"):
                        _mv_name = _pf_str.replace("__materialized__:", "")
                        _mv_rec = await adb(_db_manager.get_materialized_view_by_name, _mv_name)
                        if _mv_rec and _mv_rec.get("storage_path"):
                            import glob as _glob_mv
                            _mv_dir = _mv_rec["storage_path"]
                            _mv_pq = _glob_mv.glob(os.path.join(_mv_dir, "*.parquet"))
                            if _mv_pq:
                                _resolved_primary.extend(_mv_pq)
                                logger.info("Cross-conn primary: resolved __materialized__:%s → %d parquet file(s)", _mv_name, len(_mv_pq))
                            else:
                                logger.warning("Cross-conn primary: __materialized__:%s has no parquet files", _mv_name)
                        else:
                            logger.warning("Cross-conn primary: materialized view '%s' not found", _mv_name)
                    else:
                        _resolved_primary.append(_pf_str)
                if _resolved_primary != list(engine_config.files):
                    engine_config = engine_config._replace(files=_resolved_primary) if hasattr(engine_config, '_replace') else engine_config
                    if not hasattr(engine_config, '_replace'):
                        engine_config.files = _resolved_primary
                    logger.info("Cross-conn primary: resolved to %d file(s)", len(_resolved_primary))

            # BF-52: Validate primary files after virtual prefix resolution —
            # reject any remaining __registered__:/__local__:/__materialized__:
            # paths that would create invalid OS paths.
            # BF-120: Skip when raw_sql present (prefixes resolved by setup_registered_views).
            # A SQL-connector primary reads no files: its statement IS the
            # side (2026-10-04), so none of the file checks below apply.
            _pri_files_check = list(engine_config.files or [])
            if not _effective_raw_sql and not _primary_is_connector:
                _unresolved_pri = [f for f in _pri_files_check
                                   if any(str(f).startswith(p) for p in
                                          ("__registered__:", "__local__:", "__materialized__:", "__federation__:"))]
                if _unresolved_pri:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Primary table(s) could not be resolved: "
                               f"{[str(f).split(':',1)[-1] for f in _unresolved_pri]}. "
                               f"Check that they exist in the primary connection."
                    )
            if (not _pri_files_check and not _primary_is_connector
                    and not storage_side_reads_its_sql(
                        _effective_raw_sql, _conn_type, _pri_files_check)):
                raise HTTPException(
                    status_code=400,
                    detail="Primary query produced no files after resolution. "
                           "No data exists for the selected primary table."
                )

            # ── BF-47: Expand primary s3:// prefixes to individual files ──────
            # After __registered__: resolution, primary files may contain
            # s3://bucket/prefix entries that are directories, not individual
            # parquet files.  ParquetQueryEngine needs individual file paths.
            # BF-120: Skip when raw_sql present (setup_registered_views expands internally).
            if _conn_type == 's3' and engine_config.files and not _effective_raw_sql:
                _pri_expanded = []
                _any_pri_expanded = False
                _pri_s3_client = make_s3_client_for_conn(
                    {"id": _effective_conn_id, "config": _cfg}
                )
                for _ppf in list(engine_config.files):
                    _ppf_str = _ppf if isinstance(_ppf, str) else str(_ppf)
                    if not _ppf_str.startswith("s3://"):
                        _pri_expanded.append(_ppf_str)
                        continue
                    # Direct file path — skip expansion
                    if _ppf_str.lower().endswith(('.parquet', '.csv', '.json', '.csv.gz', '.parquet.snappy')):
                        _pri_expanded.append(_ppf_str)
                        _any_pri_expanded = True
                        continue
                    # Expand prefix to individual parquet files
                    _pp_parts = _ppf_str[5:].split("/", 1)
                    _pp_bkt = _pp_parts[0]
                    _pp_key = _pp_parts[1].rstrip("/") if len(_pp_parts) > 1 else ""
                    _pp_files = list_s3_parquet_files_cached(_effective_conn_id, _pri_s3_client, _pp_bkt, _pp_key)
                    # 2026-08-20 — surface the listing's truncated=True
                    # verdict (previously dropped: a >cap primary prefix
                    # silently queried a subset).  Certificate INCOMPLETE.
                    try:
                        from core.scan_truncation import surface_truncated_listing as _stl_pp
                        _stl_pp(_pp_files, table=_ppf_str,
                                bucket=_pp_bkt, prefix=_pp_key)
                    except Exception as _stl_pp_exc:
                        logger.warning("listing-truncation surface failed for primary '%s': %s",
                                       _ppf_str, _stl_pp_exc)
                    if _pp_files:
                        # BF-55: Apply PARTITION-ONLY pruning on primary files.
                        # Build proper partition filter dicts ({col, op, val})
                        # using the same operator mapping as secondary.  The
                        # filter_iceberg_files_by_partitions function automatically
                        # detects hive partition columns from paths and ignores
                        # any filter whose column is NOT a path segment — so
                        # data-level filters like "amount > 100" are harmlessly
                        # skipped, and only true partition filters (year, month,
                        # etc.) are used for pruning.
                        # STRATEGIC REDESIGN 2026-08-04: partition filters are
                        # extracted by THE chokepoint
                        # (core.s3_utilities.extract_partition_filters_from_query)
                        # instead of a hand-rolled per-call-site map.  The old
                        # inline map ignored ``filter_logic="OR"`` (the pruner
                        # then AND-ed the disjuncts and deleted files the SQL's
                        # OR would have matched → 0 rows) and mis-mapped
                        # ``not_in`` → ``not_equals`` with a list value.  The
                        # chokepoint emits a sound OR-group (or fails open)
                        # and carries the full operator vocabulary.
                        from types import SimpleNamespace as _SNS_pf
                        _pri_pf, _pri_pf_warns = extract_partition_filters_from_query(
                            _SNS_pf(
                                filters=query_config_model.filters,
                                filter_logic=getattr(query_config_model, "filter_logic", "AND"),
                            )
                        )
                        for _w in (_pri_pf_warns or []):
                            logger.info("Cross-conn primary partition-filter warning: %s",
                                        _w.get("message", _w))
                        _total_pri = len(_pp_files)
                        logger.info("Cross-conn primary pruning: %d filters → %d partition filters; "
                                    "sample file: %s",
                                    len(query_config_model.filters or []),
                                    len(_pri_pf) if _pri_pf else 0,
                                    _pp_files[0] if _pp_files else "NONE")
                        if _pri_pf:
                            logger.info("Cross-conn primary partition filters: %s", _pri_pf)
                            _pp_files = filter_iceberg_files_by_partitions(
                                _pp_files, _pri_pf
                            )
                        else:
                            logger.warning("Cross-conn primary: NO partition filters built — "
                                           "all %d files will be read (full scan)", _total_pri)
                        logger.info("Cross-conn primary: %d/%d files under '%s' after pruning",
                                    len(_pp_files), _total_pri, _pp_key)
                        _pri_expanded.extend(_pp_files)
                        _any_pri_expanded = True
                    else:
                        logger.warning("Cross-conn primary: no parquet files under '%s'", _pp_key)
                # Always apply expanded list (even if empty — caught below)
                engine_config = engine_config._replace(files=_pri_expanded) if hasattr(engine_config, '_replace') else engine_config
                if not hasattr(engine_config, '_replace'):
                    engine_config.files = _pri_expanded
                if _pri_expanded:
                    logger.info("Cross-conn primary: expanded to %d file(s)", len(_pri_expanded))
                else:
                    logger.warning("Cross-conn primary: expansion produced 0 files")

            # ── Resolve __registered__: in PRIMARY join right_files ──────────────
            # engine_config.joins[*].right_file may contain __registered__:tableName
            # which parquet_engine_v2._perform_join cannot resolve (it only handles
            # s3:// or local paths).  Expand to a list of actual S3 file paths here.
            if _conn_type == 's3' and engine_config.joins:
                _jrf_registered = _cfg.get("registered_tables", []) or [] if _cfg else []
                _jrf_bucket = (_cfg.get("bucket_name") or "").strip() if _cfg else ""
                # Reuse s3 client created during primary file expansion (or create one)
                try:
                    _jrf_s3_client = _pri_s3_client  # noqa: F821 — defined above if files existed
                except NameError:
                    _jrf_s3_client = make_s3_client_for_conn(
                        {"id": _effective_conn_id, "config": _cfg}
                    )
                _resolved_joins_list = []
                _any_jrf_resolved = False
                for _jc in engine_config.joins:
                    _jrf = _jc.right_file
                    _jrf_str = _jrf if isinstance(_jrf, str) else str(_jrf)
                    if _jrf_str.startswith("__registered__:"):
                        _jrf_tbl = _jrf_str.replace("__registered__:", "")
                        _jrf_found = next(
                            (t for t in _jrf_registered if t.get("name") == _jrf_tbl), None
                        )
                        if _jrf_found:
                            _jrf_prefix = _jrf_found.get("s3_prefix", "").rstrip("/")
                            _jrf_files = list_s3_parquet_files_cached(
                                _effective_conn_id, _jrf_s3_client, _jrf_bucket, _jrf_prefix
                            )
                            # 2026-08-20 — surface truncated=True (join side
                            # built from a subset drops join rows silently).
                            try:
                                from core.scan_truncation import surface_truncated_listing as _stl_jrf
                                _stl_jrf(_jrf_files, table=_jrf_tbl,
                                         bucket=_jrf_bucket, prefix=_jrf_prefix)
                            except Exception as _stl_jrf_exc:
                                logger.warning("listing-truncation surface failed for join '%s': %s",
                                               _jrf_tbl, _stl_jrf_exc)
                            if _jrf_files:
                                from dataclasses import replace as _dc_replace_jrf
                                _jc = _dc_replace_jrf(_jc, right_file=_jrf_files)
                                _any_jrf_resolved = True
                                logger.info(
                                    "Cross-conn join: resolved __registered__:%s → %d file(s) in right_file",
                                    _jrf_tbl, len(_jrf_files),
                                )
                            else:
                                logger.warning(
                                    "Cross-conn join: __registered__:%s found but has no parquet "
                                    "files under prefix '%s'", _jrf_tbl, _jrf_prefix,
                                )
                        else:
                            logger.warning(
                                "Cross-conn join: registered table '%s' not found in connection config",
                                _jrf_tbl,
                            )
                    _resolved_joins_list.append(_jc)
                if _any_jrf_resolved:
                    engine_config.joins = _resolved_joins_list

            # Final validation: after s3:// expansion + partition pruning
            _pri_final = list(engine_config.files or [])
            _FILE_EXTS_PRI = ('.parquet', '.csv', '.json', '.csv.gz', '.parquet.snappy')
            _unexpanded_pri = [f for f in _pri_final
                               if str(f).startswith("s3://") and
                               not str(f).lower().endswith(_FILE_EXTS_PRI)]
            if _unexpanded_pri:
                raise HTTPException(
                    status_code=500,
                    detail="Primary S3 path(s) could not be expanded to individual files. "
                           "File listing may have failed — check S3 credentials and bucket access."
                )
            if (not _pri_final and not _primary_is_connector
                    and not storage_side_reads_its_sql(
                        _effective_raw_sql, _conn_type, _pri_final)):
                raise HTTPException(
                    status_code=400,
                    detail="Primary source has no files after expansion and partition filtering. "
                           "Check that parquet files exist under the selected table prefix "
                           "and that your partition filters aren't too restrictive."
                )

            # Also resolve __local__: / __materialized__: in SECONDARY config
            if secondary_config.files:
                _resolved_secondary_virt = []
                for _sf_v in secondary_config.files:
                    _sf_v_str = _sf_v if isinstance(_sf_v, str) else str(_sf_v)
                    if _sf_v_str.startswith("__local__:"):
                        _lt_name_s = _sf_v_str.replace("__local__:", "")
                        _lt_rec_s = await adb(_db_manager.get_local_table_by_name, _lt_name_s)
                        if _lt_rec_s and _lt_rec_s.get("storage_path"):
                            import glob as _glob_lt_s
                            _lt_pq_s = _glob_lt_s.glob(os.path.join(_lt_rec_s["storage_path"], "*.parquet"))
                            if _lt_pq_s:
                                _resolved_secondary_virt.extend(_lt_pq_s)
                            else:
                                _resolved_secondary_virt.append(_sf_v_str)
                        else:
                            _resolved_secondary_virt.append(_sf_v_str)
                    elif _sf_v_str.startswith("__materialized__:"):
                        _mv_name_s = _sf_v_str.replace("__materialized__:", "")
                        _mv_rec_s = await adb(_db_manager.get_materialized_view_by_name, _mv_name_s)
                        if _mv_rec_s and _mv_rec_s.get("storage_path"):
                            import glob as _glob_mv_s
                            _mv_pq_s = _glob_mv_s.glob(os.path.join(_mv_rec_s["storage_path"], "*.parquet"))
                            if _mv_pq_s:
                                _resolved_secondary_virt.extend(_mv_pq_s)
                            else:
                                _resolved_secondary_virt.append(_sf_v_str)
                        else:
                            _resolved_secondary_virt.append(_sf_v_str)
                    else:
                        _resolved_secondary_virt.append(_sf_v_str)
                if _resolved_secondary_virt != list(secondary_config.files):
                    secondary_config = secondary_config._replace(files=_resolved_secondary_virt) if hasattr(secondary_config, '_replace') else secondary_config
                    if not hasattr(secondary_config, '_replace'):
                        secondary_config.files = _resolved_secondary_virt

            # ── Resolve __registered__: paths to actual S3 file lists ─────────
            # Cross-source joins use registered table names (e.g. __registered__:sales).
            # The secondary ParquetQueryEngine needs actual S3 file paths.
            if _sc_type == 's3' and secondary_config.files:
                _resolved_files = []
                # BF-42: registered_tables lives in connection config, not DatabaseManager
                _sec_registered = _sc_cfg.get("registered_tables", []) or []
                _sec_bucket = (_sc_cfg_injected.get("bucket_name") or "").strip()
                for _sf in secondary_config.files:
                    _sf_str = _sf if isinstance(_sf, str) else str(_sf)
                    if _sf_str.startswith("__registered__:"):
                        _tbl_name = _sf_str.replace("__registered__:", "")
                        _found = next((t for t in _sec_registered if t.get("name") == _tbl_name), None)
                        if _found:
                            _s3_prefix = _found.get("s3_prefix", "").rstrip("/")
                            _resolved_files.append(f"s3://{_sec_bucket}/{_s3_prefix}")
                        else:
                            # BF-53: Do NOT keep unresolved __registered__: path —
                            # it would create invalid file paths (colon is illegal on Windows).
                            logger.warning("Cross-source: registered table '%s' not found in connection %s",
                                           _tbl_name, request.secondary_connection_id)
                    else:
                        _resolved_files.append(_sf_str)
                secondary_config = secondary_config._replace(files=_resolved_files) if hasattr(secondary_config, '_replace') else secondary_config
                if not hasattr(secondary_config, '_replace'):
                    secondary_config.files = _resolved_files

            # ── Phase 93 / Part A: Resolve __registered__: in SECONDARY join right_files ─
            # Mirror of primary join resolution (BF-58 fix at lines 1879-1928).
            # secondary_config.joins[*].right_file may contain __registered__:tableName
            # which ParquetQueryEngine._perform_join cannot handle.
            if _sc_type == 's3' and secondary_config.joins:
                _sjrf_registered = _sec_registered if '_sec_registered' in dir() else (
                    _sc_cfg.get("registered_tables", []) or []
                )
                _sjrf_bucket = (_sc_cfg_injected.get("bucket_name") or "").strip() if _sc_cfg_injected else (
                    (_sc_cfg.get("bucket_name") or "").strip() if _sc_cfg else ""
                )
                _sjrf_s3_client = make_s3_client_for_conn(
                    {"id": request.secondary_connection_id, "config": _sc_cfg_injected or _sc_cfg}
                )
                _sjrf_resolved_joins = []
                _sjrf_any_resolved = False
                for _sjc in secondary_config.joins:
                    _sjrf = _sjc.right_file
                    _sjrf_str = _sjrf if isinstance(_sjrf, str) else str(_sjrf)
                    if _sjrf_str.startswith("__registered__:"):
                        _sjrf_tbl = _sjrf_str.replace("__registered__:", "")
                        _sjrf_found = next(
                            (t for t in _sjrf_registered if t.get("name") == _sjrf_tbl), None
                        )
                        if _sjrf_found:
                            _sjrf_prefix = _sjrf_found.get("s3_prefix", "").rstrip("/")
                            _sjrf_files = list_s3_parquet_files_cached(
                                request.secondary_connection_id, _sjrf_s3_client, _sjrf_bucket, _sjrf_prefix
                            )
                            # 2026-08-20 — surface truncated=True.
                            try:
                                from core.scan_truncation import surface_truncated_listing as _stl_sjrf
                                _stl_sjrf(_sjrf_files, table=_sjrf_tbl,
                                          bucket=_sjrf_bucket, prefix=_sjrf_prefix)
                            except Exception as _stl_sjrf_exc:
                                logger.warning("listing-truncation surface failed for secondary join '%s': %s",
                                               _sjrf_tbl, _stl_sjrf_exc)
                            if _sjrf_files:
                                from dataclasses import replace as _dc_replace_sjrf
                                _sjc = _dc_replace_sjrf(_sjc, right_file=_sjrf_files)
                                _sjrf_any_resolved = True
                                logger.info(
                                    "Cross-conn secondary join: resolved __registered__:%s → %d file(s)",
                                    _sjrf_tbl, len(_sjrf_files),
                                )
                            else:
                                logger.warning(
                                    "Cross-conn secondary join: __registered__:%s has no parquet "
                                    "files under prefix '%s'", _sjrf_tbl, _sjrf_prefix,
                                )
                        else:
                            logger.warning(
                                "Cross-conn secondary join: registered table '%s' not found "
                                "in secondary connection config", _sjrf_tbl,
                            )
                    _sjrf_resolved_joins.append(_sjc)
                if _sjrf_any_resolved:
                    secondary_config = secondary_config._replace(joins=_sjrf_resolved_joins) if hasattr(secondary_config, '_replace') else secondary_config
                    if not hasattr(secondary_config, '_replace'):
                        secondary_config.joins = _sjrf_resolved_joins

            # ── BF-32+33: Secondary file expansion + partition pruning ─────────
            # Resolve s3://bucket/prefix entries to individual file paths and
            # prune by partition filters (same approach as primary tables).
            # Without this, ParquetQueryEngine tries to download a prefix as a
            # single file — which fails for hive-partitioned tables.
            from core.iceberg_freshness_bound import (
                wants_newest_snapshot as _wants_newest_sec)
            _force_fresh_sec = (
                (request.executed_by or "").startswith("published_view:")
                or (request.executed_by or "").startswith("schedule:")
                or _wants_newest_sec(request.cache_strategy)
            )
            if _sc_type == 's3' and secondary_config.files:
                # BF-38: Reuse portal-injected config (injected once above,
                # before engine creation) for both the listing client and
                # the engine's S3StorageHandler.
                _sec_cfg_for_s3 = dict(_sc_cfg_injected)

                try:
                    from core.s3_utilities import (
                        filter_iceberg_files_by_partitions as _filter_sec_files,
                        list_s3_csv_files as _list_sec_csv,
                    )
                    _sec_s3_client = make_s3_client_for_conn(
                        {"id": request.secondary_connection_id, "config": _sec_cfg_for_s3}
                    )
                    # Build lookup map for registered table metadata (format, prefix)
                    _sec_reg_by_prefix = {}
                    for _rt in (_sec_registered or []):
                        _rt_pfx = _rt.get("s3_prefix", "").rstrip("/")
                        if _rt_pfx:
                            _sec_reg_by_prefix[_rt_pfx] = _rt

                    # ── Build partition filters ────────────────────────────────
                    # Filter precedence for partition pruning:
                    # - If secondary has its own filters → use them (don't override)
                    # - If secondary has NO filters AND mode=UNION → inherit primary's
                    #   filters (same schema assumed for UNION)
                    # - JOIN mode never propagates (different schemas possible)
                    _sec_filter_source = sec_qc_model.filters
                    if not _sec_filter_source and request.combine_mode == "union":
                        _sec_filter_source = query_config_model.filters
                        if _sec_filter_source:
                            logger.info("Cross-source UNION: propagating %d primary filters "
                                        "to secondary for partition pruning",
                                        len(_sec_filter_source))

                    # STRATEGIC REDESIGN 2026-08-04: same chokepoint as the
                    # primary side — extract_partition_filters_from_query owns
                    # the operator map, the value validation AND the
                    # filter_logic="OR" soundness rule (OR-group or fail-open).
                    # The old inline map here AND-ed OR disjuncts (deleting
                    # files the SQL's OR matched → 0 rows) and mis-mapped
                    # ``not_in`` → ``not_equals`` with a list value.
                    # filter_logic follows the filters' ORIGIN: the secondary's
                    # own logic for its own filters, the primary's logic when
                    # UNION-mode inherits the primary's filters.
                    _sec_pf = None
                    if _sec_filter_source:
                        from types import SimpleNamespace as _SNS_sec
                        _sec_pf_logic = (
                            getattr(sec_qc_model, "filter_logic", "AND")
                            if _sec_filter_source is sec_qc_model.filters
                            else getattr(query_config_model, "filter_logic", "AND")
                        )
                        _sec_pf, _sec_pf_warns = extract_partition_filters_from_query(
                            _SNS_sec(filters=_sec_filter_source,
                                     filter_logic=_sec_pf_logic)
                        )
                        for _w in (_sec_pf_warns or []):
                            logger.info("Cross-conn secondary partition-filter warning: %s",
                                        _w.get("message", _w))

                    # Also propagate filters into secondary_config for data-level
                    # filtering (ParquetQueryEngine._apply_filters) in union mode
                    if request.combine_mode == "union" and not secondary_config.filters:
                        if query_config_model.filters:
                            _prop_filters = [
                                {"column": (_flt["column"] if isinstance(_flt, dict) else _flt.column),
                                 "operator": (_flt["operator"] if isinstance(_flt, dict) else _flt.operator),
                                 "value": (_flt["value"] if isinstance(_flt, dict) else _flt.value)}
                                for _flt in query_config_model.filters
                            ]
                            # 2026-08-04: propagate filter_logic WITH the
                            # filters — inheriting OR-combined filters while
                            # the secondary defaults to AND silently
                            # under-counted the secondary side of the UNION.
                            _prop_logic = getattr(query_config_model, "filter_logic", "AND")
                            secondary_config = secondary_config._replace(filters=_prop_filters) \
                                if hasattr(secondary_config, '_replace') else secondary_config
                            if not hasattr(secondary_config, '_replace'):
                                secondary_config.filters = _prop_filters
                                secondary_config.filter_logic = _prop_logic
                            logger.info("Cross-source UNION: propagated %d primary filters "
                                        "(logic=%s) for data-level filtering on secondary",
                                        len(_prop_filters), _prop_logic)

                    # ── Expand prefixes to individual file paths ───────────────
                    _sec_expanded_files = []
                    _any_sec_expanded = False
                    for _sf in list(secondary_config.files):
                        _sf_str = _sf if isinstance(_sf, str) else str(_sf)
                        if not _sf_str.startswith("s3://"):
                            _sec_expanded_files.append(_sf_str)
                            continue

                        # Direct file path (not a prefix) — skip expansion
                        _sf_lower = _sf_str.lower()
                        if _sf_lower.endswith(('.parquet', '.csv', '.json', '.csv.gz', '.parquet.snappy')):
                            _sec_expanded_files.append(_sf_str)
                            _any_sec_expanded = True
                            continue

                        _sec_parts_url = _sf_str[5:].split("/", 1)
                        _sec_bkt = _sec_parts_url[0]
                        _sec_key = _sec_parts_url[1].rstrip("/") if len(_sec_parts_url) > 1 else ""

                        # Determine format via registered table lookup (O(1))
                        _sec_rt = _sec_reg_by_prefix.get(_sec_key)
                        _sec_fmt = _sec_rt.get("format", "parquet") if _sec_rt else "parquet"

                        if _sec_fmt == "iceberg":
                            try:
                                from core.iceberg_reader import get_iceberg_data_files as _get_ice_sec
                                # OFF THE EVENT LOOP (2026-07-22): this is the full
                                # secondary manifest walk; run inline it froze the
                                # single loop AND ate the 30s submission budget
                                # ("query submission exceeded 30s").  The PRIMARY
                                # side is already offloaded — this restores parity.
                                # 2026-08-02 partition-predicate sweep: forward
                                # the secondary's structured filters + the
                                # registered table name so manifest/entry
                                # pruning engages INSIDE the reader.  Pre-fix
                                # this call enumerated every data file and
                                # relied solely on the post-hoc hive-path
                                # _filter_sec_files below — which can't prune
                                # non-hive layouts at all.  _filter_sec_files
                                # still runs afterwards (keep-side only).
                                # 2026-10-25 -- the reader's meta: this side
                                # becomes a bare file list for the structured
                                # engine, which applies no delete file, so a
                                # V2 table with row-level deletes is REFUSED
                                # here (never the deleted rows as data).
                                _ice_sec_meta: Dict[str, Any] = {}
                                _ice_raw = await asyncio.to_thread(
                                    functools.partial(
                                        _get_ice_sec,
                                        _sec_s3_client, _sec_bkt, _sec_key,
                                        partition_filters=_sec_pf or None,
                                        keys_only=True,
                                        force_fresh=_force_fresh_sec,
                                        table_name=(_sec_rt or {}).get("name"),
                                        db_manager=_db_manager,  # BF-368
                                        _out_meta=_ice_sec_meta))
                                from core.iceberg_mor import (
                                    allow_stale_reads as _sec_stale_ok,
                                    collected_deletes as _sec_collected,
                                    uncollected_deletes_reason as _sec_uncollected,
                                )
                                _sec_pos, _sec_eq = _sec_collected(_ice_sec_meta)
                                _sec_unc = _sec_uncollected(_ice_sec_meta)
                                if _sec_pos or _sec_eq or _sec_unc:
                                    _sec_why = (_sec_unc or
                                                f"{len(_sec_pos)} position + {len(_sec_eq)} "
                                                f"equality delete file(s) apply")
                                    if _sec_stale_ok():
                                        logger.warning(
                                            "Cross-source secondary iceberg '%s': %s -- "
                                            "the structured secondary road applies no "
                                            "delete file; serving data-only "
                                            "(iceberg_mor.allow_stale_reads=true)",
                                            _sec_key, _sec_why)
                                    else:
                                        raise MorDeletesUnresolvableError(
                                            f"Iceberg MoR: secondary table '{_sec_key}' "
                                            f"is merge-on-read ({_sec_why}) and the "
                                            f"cross-source secondary road reads data "
                                            f"files only -- refusing to serve a "
                                            f"delete-blind (overcounted) side.  Query "
                                            f"it as the PRIMARY (raw SQL over the "
                                            f"registered table), or set "
                                            f"iceberg_mor.allow_stale_reads=true to "
                                            f"accept data-only reads.")
                                _ice_urls = [
                                    f"s3://{_sec_bkt}/{f['key']}" if isinstance(f, dict) else f
                                    for f in _ice_raw
                                ]
                                _total_ice = len(_ice_urls)
                                if _sec_pf and _ice_urls:
                                    _ice_urls = _filter_sec_files(_ice_urls, _sec_pf)
                                logger.info("Cross-source secondary iceberg '%s': %d/%d files after pruning",
                                            _sec_key, len(_ice_urls), _total_ice)
                                _sec_expanded_files.extend(_ice_urls)
                                _any_sec_expanded = True
                            except (MorDeletesUnresolvableError, MorDeleteCollectionError):
                                # A correctness refusal is not a listing
                                # failure: falling back to the bare prefix
                                # would read every file under it.
                                raise
                            except Exception as _ice_sec_err:
                                logger.warning("Secondary iceberg listing failed for '%s': %s",
                                               _sec_key, _ice_sec_err, exc_info=True)
                                _sec_expanded_files.append(_sf_str)
                        elif _sec_fmt == "csv":
                            try:
                                _csv_files = _list_sec_csv(_sec_s3_client, _sec_bkt, _sec_key)
                                if _csv_files:
                                    _total_csv_sec = len(_csv_files)
                                    if _sec_pf:
                                        _csv_files = _filter_sec_files(_csv_files, _sec_pf)
                                    logger.info("Cross-source secondary csv '%s': %d/%d files after pruning",
                                                _sec_key, len(_csv_files), _total_csv_sec)
                                    _sec_expanded_files.extend(_csv_files)
                                    _any_sec_expanded = True
                                else:
                                    logger.warning("Cross-source secondary: no CSV files under '%s'",
                                                   _sec_key)
                            except Exception as _csv_sec_err:
                                logger.warning("Secondary CSV listing failed for '%s': %s",
                                               _sec_key, _csv_sec_err, exc_info=True)
                                _sec_expanded_files.append(_sf_str)  # fallback: keep original prefix
                        else:
                            # Parquet: list individual files via boto3
                            _pq_sec_files = list_s3_parquet_files_cached(
                                request.secondary_connection_id, _sec_s3_client, _sec_bkt, _sec_key
                            )
                            # 2026-08-20 — surface truncated=True before the
                            # partition filter below drops the flag.
                            try:
                                from core.scan_truncation import surface_truncated_listing as _stl_sec
                                _stl_sec(_pq_sec_files, table=_sf_str,
                                         bucket=_sec_bkt, prefix=_sec_key)
                            except Exception as _stl_sec_exc:
                                logger.warning("listing-truncation surface failed for secondary '%s': %s",
                                               _sf_str, _stl_sec_exc)
                            if _pq_sec_files:
                                _total_pq_sec = len(_pq_sec_files)
                                if _sec_pf:
                                    _pq_sec_files = _filter_sec_files(
                                        _pq_sec_files, _sec_pf
                                    )
                                logger.info(
                                    "Cross-source secondary parquet '%s': %d/%d files after pruning",
                                    _sec_key, len(_pq_sec_files), _total_pq_sec,
                                )
                                _sec_expanded_files.extend(_pq_sec_files)
                                _any_sec_expanded = True
                            else:
                                logger.warning(
                                    "Cross-source secondary: no parquet files under '%s'",
                                    _sec_key,
                                )

                    # Always apply expanded file list (even if empty — validation below catches it)
                    secondary_config = secondary_config._replace(files=_sec_expanded_files) \
                        if hasattr(secondary_config, '_replace') else secondary_config
                    if not hasattr(secondary_config, '_replace'):
                        secondary_config.files = _sec_expanded_files
                    if _sec_expanded_files:
                        logger.info("Cross-source secondary: expanded+pruned to %d files",
                                    len(_sec_expanded_files))
                    else:
                        logger.warning("Cross-source secondary: expansion produced 0 files")
                except (MorDeletesUnresolvableError, MorDeleteCollectionError) as _sec_mor_exc:
                    # 2026-10-25 -- the merge-on-read refusal reaches the
                    # caller as the 422 every scan refusal answers with, with
                    # its sentence (api.connector_errors.SCAN_REFUSAL_STATUS).
                    from api.connector_errors import SCAN_REFUSAL_STATUS as _mor_status
                    logger.error("Cross-source secondary refused: %s", _sec_mor_exc)
                    raise HTTPException(status_code=_mor_status, detail=str(_sec_mor_exc))
                except Exception as _sec_prune_exc:
                    # BF-55: Don't silently continue with unresolved s3:// prefixes —
                    # ParquetQueryEngine can't read a directory prefix as a file.
                    logger.error(
                        "Secondary file expansion failed: %s",
                        _sec_prune_exc, exc_info=True,
                    )
                    raise HTTPException(
                        status_code=500,
                        detail=f"Failed to list files in secondary S3 source: {_sec_prune_exc}. "
                               f"Check secondary connection credentials and bucket access."
                    )

            # ── Validate secondary files are usable ────────────────────────────
            # After resolution + pruning, ensure we have actual files to read.
            # ParquetQueryEngine.execute_query() raises ValueError on empty list.
            _sec_files = secondary_config.files if secondary_config.files else []
            # A SQL-connector secondary reads no files (2026-10-04): its
            # statement is the side.  Its ``files`` are the builder's table
            # picks, already rendered into that statement.
            if _sec_sql_connector is not None:
                _sec_files = ["<connector side>"]
            # A RAW-SQL storage secondary names its tables in its SQL, not in
            # ``files``: the registered-table views are bound from the
            # statement (``_raw_sql_with_views`` -> setup_registered_views),
            # exactly as for a raw-SQL primary.  It used to be refused here
            # with "produced no files" whenever no query config rode along.
            elif storage_side_reads_its_sql(_effective_secondary_raw_sql, _sc_type, _sec_files):
                _sec_files = ["<raw-sql storage side>"]
            if any("__registered__:" in str(f) for f in _sec_files):
                _unresolved = [f for f in _sec_files if "__registered__:" in str(f)]
                raise HTTPException(
                    status_code=400,
                    detail=f"Secondary registered table(s) could not be resolved: "
                           f"{[str(f).replace('__registered__:', '') for f in _unresolved]}. "
                           f"Check that they exist in connection {request.secondary_connection_id}."
                )
            # Reject s3:// prefixes that weren't expanded to individual files
            _FILE_EXTS = ('.parquet', '.csv', '.json', '.csv.gz', '.parquet.snappy')
            _unexpanded = [f for f in _sec_files
                           if str(f).startswith("s3://") and
                           not str(f).lower().endswith(_FILE_EXTS)]
            if _unexpanded:
                raise HTTPException(
                    status_code=500,
                    detail=f"Secondary S3 path(s) could not be expanded to individual files: "
                           f"{[str(f).split('/')[-1] for f in _unexpanded[:3]]}. "
                           f"File listing may have failed — check S3 credentials and bucket access."
                )
            if not _sec_files:
                raise HTTPException(
                    status_code=400,
                    detail="Secondary query produced no files after partition filtering. "
                           "No data exists in the secondary source for the given filter criteria."
                )

            # ── Cross-query cache check ───────────────────────────────────────
            _cross_qc_dict = {
                "primary": query_config_model.model_dump(),
                "secondary": sec_qc_model.model_dump(),
                "combine_mode": request.combine_mode,
                "join_config": request.join_config,
            }
            from core.query_cache import make_cache_key as _mk_cx_ck, get_cached_result as _get_cx_cached, rls_user_scope as _rls_us_cx
            # BF-235: include both primary + secondary raw_sql in cache key
            _cross_raw = (request.raw_sql or "") + "||" + (request.secondary_raw_sql or "")
            # Round 5: per-user scope when RLS is enabled — cross-source
            # has the same cross-user leak risk as single-query.
            _cross_scope = _rls_us_cx(_user)
            _cross_cache_key = _mk_cx_ck(
                _cross_qc_dict,
                raw_sql=_cross_raw if _cross_raw.strip("|") else None,
                user_scope=_cross_scope,
            )
            if request.cache_strategy == "auto":
                _cx_cached_path = _get_cx_cached(_cross_cache_key)
                if _cx_cached_path:
                    try:
                        _cx_cached_size = _cx_cached_path.stat().st_size
                    except FileNotFoundError:
                        from core.query_cache import invalidate as _cx_inv
                        _cx_inv(_cross_cache_key)
                        _cx_cached_path = None
                if _cx_cached_path:
                    _cx_file_size = _cx_cached_path.stat().st_size
                    _cx_stats = {}
                    try:
                        import pyarrow.parquet as _pq_cx
                        _cx_pf = _pq_cx.ParquetFile(str(_cx_cached_path))
                        _cx_stats = {"total_rows": _cx_pf.metadata.num_rows,
                                     "total_columns": _cx_pf.metadata.num_columns}
                    except Exception as _pq_cx_exc:
                        # BF-CACHE-CORRUPT: same fix as the other two cache hit
                        # paths.  Evict + fall through to fresh cross-source
                        # execution.
                        logger.warning(
                            "[cross_query_cache] Cached parquet unreadable — evicting + re-executing: %s (path=%s)",
                            _pq_cx_exc, _cx_cached_path,
                        )
                        try:
                            from core.query_cache import invalidate as _cx_inv2
                            _cx_inv2(_cross_cache_key)
                        except Exception:
                            pass
                        _cx_cached_path = None
                if _cx_cached_path:
                    _cx_exec_id = str(uuid.uuid4())
                    _cx_file_id = str(uuid.uuid4())
                    await adb(_db_manager.create_execution, 
                        execution_id=_cx_exec_id,
                        query_id=request.query_id,
                        query_config=query_config_model.model_dump(),
                        executed_by=(request.executed_by or (_user.get("username","guest") if _user else "guest")),
                    )
                    await adb(_db_manager.update_execution, _cx_exec_id, status="completed",
                                                    engine="result_cache",
                                                    output_file=str(_cx_cached_path),
                                                    total_rows=_cx_stats.get("total_rows", 0),
                                                    file_size_bytes=_cx_file_size)
                    await adb(_db_manager.create_download_file, 
                        file_id=_cx_file_id, execution_id=_cx_exec_id,
                        filename=f"cached_result_{_cx_exec_id}.parquet",
                        file_path=str(_cx_cached_path),
                        file_size_bytes=_cx_file_size,
                        expires_at=_download_expires_at(transient=True),
                    )
                    await _ws_manager.broadcast_to_user(_username, _with_engine({
                        "type": "execution_completed", "execution_id": _cx_exec_id,
                        "file_id": _cx_file_id, "cache_hit": True,
                        "stats": _cx_stats, "combine_mode": request.combine_mode,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }, "result_cache"))
                    return {
                        "execution_id": _cx_exec_id, "status": "completed",
                        "cache_hit": True, "file_id": _cx_file_id,
                        "message": "Served from cache",
                    }

            # 2026-09-28: the global cap (load shed, 503) is decided INSIDE
            # the slot grant below, atomically with the increment.
            # BF-591: pre-generate execution_id BEFORE acquire so cancel
            # while queued works on cross-source too (same fix as SQL
            # connector path).
            execution_id = str(uuid.uuid4())
            # BF-584: queue-aware slot acquire (cross-source path).
            _cx_slot_ok, _cx_slot_reason, _cx_slot_wait = await _acquire_user_slot(
                _username,
                _qe_cfg.max_concurrent_per_user,
                _qe_cfg.max_queue_size,
                _qe_cfg.queue_wait_timeout_seconds,
                execution_id=execution_id,
                max_global=_global_cap(),
                global_wait_timeout=_interactive_global_wait(),
                client_request_id=request.client_request_id,
            )
            if not _cx_slot_ok:
                _raise_if_load_shed(_cx_slot_reason, _cx_slot_wait)
                if _cx_slot_reason == "cancelled":
                    return _cancelled_while_queued(execution_id)
                raise HTTPException(
                    status_code=503,
                    detail=(
                        f"Server busy ({_cx_slot_reason}): no slot freed "
                        f"within {_qe_cfg.queue_wait_timeout_seconds}s."
                    ),
                    headers={"Retry-After": "30"},
                )

            # BF-591: orphan tracker for cross-source acquire path.
            _pending_owner_by_req[_req_key] = _username
            # Guard: decrement counter if task setup fails after increment
            try:
                # Record checkpoint intent (Phase 41)
                # 2026-10-07: awaited on the checkpoint lane, not inline on the loop.
                from core.checkpoint import arecord_intent as _record_intent_cross
                await _record_intent_cross(execution_id, query_config_model.model_dump(),
                                           executed_by=request.executed_by or _username,
                                           query_id=request.query_id)
                execution = await adb(_db_manager.create_execution,
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by or _username
                )
                # BF-591: strong-ref track.
                _track_bg_task(
                    execute_cross_query_background(
                        execution_id,
                        active_engine,
                        engine_config,
                        secondary_engine,
                        secondary_config,
                        combine_mode=request.combine_mode,
                        join_config=request.join_config,
                        query_id=request.query_id,
                        executed_by=_username,
                        cache_key=_cross_cache_key,
                        cache_key_scope=_cross_scope,
                        cache_strategy=request.cache_strategy or "auto",
                        query_config_dict=_cross_qc_dict,
                        primary_raw_sql=_effective_raw_sql,
                        secondary_raw_sql=_effective_secondary_raw_sql,
                        # BF-106: Pass connection IDs for proxy pre-download fallback
                        primary_connection_id=request.connection_id,
                        secondary_connection_id=request.secondary_connection_id,
                        # Phase 131 deep-dive #13 (round 4): both legs are
                        # already RLS-rewritten upstream when their raw_sql
                        # was set.  user_ctx is still passed so the structured
                        # case (raw_sql=None) gets synthesised + rewritten in
                        # execute_cross_query_background.
                        user_ctx=_user,
                    )
                )
                _pending_owner_by_req.pop(_req_key, None)
            except BaseException:  # incl. CancelledError -- a cancel here must not leak the slot
                # BF-584: release slot + wake queued waiter on
                # task-creation failure.
                _release_user_slot(_username)
                _pending_owner_by_req.pop(_req_key, None)
                raise

            _audit(_user, "execute_cross_query", None, "execution", execution_id,
                   {"query_id": request.query_id,
                    "primary_connection_id": request.connection_id,
                    "secondary_connection_id": request.secondary_connection_id,
                    "combine_mode": request.combine_mode})
            logger.info(f"Cross-connection query started: {execution_id} ({request.combine_mode})")

            return {
                "execution_id": execution_id,
                "status": "pending",
                "started_at": execution["started_at"],
                "is_cross_connection": True,
                "combine_mode": request.combine_mode,
                "message": f"Cross-connection {request.combine_mode.upper()} query started"
            }

        # ── Single-source path (original) ─────────────────────────────────────
        # Skip file-level validation for registered tables — they use virtual
        # paths (__registered__:name) that don't exist on disk / S3.
        if not _uses_registered:
            # Run validate_query off the event loop — it reads file schemas from disk
            # and can take 100 ms – 2 s per file, which would stall all other requests.
            _loop = asyncio.get_running_loop()
            validation = await _loop.run_in_executor(
                _get_light_executor_fn(), active_engine.validate_query, engine_config
            )
            if not validation["valid"]:
                raise HTTPException(
                    status_code=400,
                    detail={"message": "Invalid query configuration", "errors": validation["errors"]}
                )

        # ── Query result cache check ──────────────────────────────────────────
        # Check cache for ALL query types (including S3/connection queries).
        # Skipped when cache_strategy is 'bypass' or 'refresh'.
        if request.cache_strategy == "auto":
            from core.query_cache import make_cache_key, get_cached_result, invalidate as _cache_invalidate, rls_user_scope as _rls_us
            # BF-235: raw_sql is part of the cache identity — without it,
            # editing the SQL editor (e.g. switching from auto-generated
            # SELECT to "SELECT count(*)") would return the previous result.
            # Round 5: per-user scope when RLS is enabled (else None → key
            # is identical to legacy form, existing cache stays valid).
            _cache_key = make_cache_key(
                query_config_model.model_dump(),
                raw_sql=request.raw_sql,
                user_scope=_rls_us(_user),
            )
            _cached_path = get_cached_result(_cache_key)
            if _cached_path:
                try:
                    _cached_size = _cached_path.stat().st_size   # Guard: file may vanish between lookup and here
                except FileNotFoundError:
                    # File deleted externally between cache lookup and now — evict stale record, fall through
                    logger.warning("[query_cache] Cached file gone before serve: %s", _cached_path)
                    _cache_invalidate(_cache_key)
                    _cached_path = None

            # 2026-10-07 -- an entry for a query that reads a registered
            # ICEBERG table must carry the snapshot it was computed from, or
            # nothing below can tell it from the current snapshot: such an
            # entry (every raw-SQL Iceberg result stored before this fix)
            # answered the pre-commit rows for the cache TTL.  Not served.
            if _cached_path:
                try:
                    from core.query_cache_integration import (
                        referenced_iceberg_tables as _qc_ice_refs)
                    _qc_ice = _qc_ice_refs(
                        active_engine, request.raw_sql,
                        list(getattr(query_config_model, "files", None) or []))
                    if _qc_ice:
                        _qc_entry = await adb(_db_manager.get_cache_entry, _cache_key)
                        if not (_qc_entry or {}).get("source_fingerprint"):
                            logger.info(
                                "[cache-invalidate] key=%s reads Iceberg table(s) "
                                "%s but carries no snapshot fingerprint -- "
                                "evicted, not served", _cache_key[:16],
                                [t.get("name") for t in _qc_ice])
                            _cache_invalidate(_cache_key)
                            _cached_path = None
                except Exception as _qc_ice_exc:
                    logger.warning("[cache] Iceberg fingerprint gate failed -- "
                                   "not serving the cached result: %s", _qc_ice_exc)
                    _cached_path = None

            # Phase 104: partition-aware staleness check (fail-open)
            if _cached_path and _cache_cfg.partition_aware_invalidation:
                try:
                    _fp_entry = await adb(_db_manager.get_cache_entry, _cache_key)
                    if _fp_entry and _fp_entry.get("source_fingerprint"):
                        from core.snapshot_fingerprint import (
                            check_cache_entry_staleness_multi,
                            make_registered_table_s3_resolver,
                        )

                        # 2026-09-07 — was an inline copy of a lookup that
                        # five call sites had each written out.  One factory
                        # now, beside the function that consumes it.
                        _fp_get_s3_client = make_registered_table_s3_resolver(
                            _db_manager)

                        # 2026-07-22 (R8-revised): OFF the event loop + bounded.
                        # This runs sync boto3 S3 (cold metadata → up to ~100
                        # sequential LIST pages) + a portal-credential HTTP inside
                        # _fp_get_s3_client; inline it FROZE the single asyncio
                        # loop (the 120s cache-hit re-run hang).  Offload to a
                        # thread and cap it — but ON TIMEOUT we CANNOT prove the
                        # cached result is still current, so FAIL-CLOSED for
                        # correctness: evict + recompute rather than silently
                        # serve a possibly-stale result (a re-run after new data
                        # landed must never return the old rows).  When S3 is
                        # genuinely slow the recompute pays the same latency the
                        # check would have — no worse — but the answer is
                        # guaranteed fresh.  15s (was 5s) gives the check a fair
                        # chance now that the real loop-stall sources are fixed.
                        try:
                            _is_stale, _stale_reason = await asyncio.wait_for(
                                asyncio.to_thread(
                                    check_cache_entry_staleness_multi,
                                    _fp_entry, _fp_get_s3_client),
                                timeout=15.0,
                            )
                        except asyncio.TimeoutError:
                            _is_stale, _stale_reason = True, "staleness-check-timeout-evict"
                        if _is_stale:
                            logger.info("[cache-invalidate] Stale result evicted: key=%s reason=%s",
                                        _cache_key[:16], _stale_reason)
                            _cache_invalidate(_cache_key)
                            _cached_path = None
                except Exception as _fp_exc:
                    logger.debug("[cache] staleness check error — fail-open: %s", _fp_exc)

            if _cached_path:
                # Read stats first so we can persist total_rows in the execution record
                _cache_stats = {}
                try:
                    import pyarrow.parquet as _pq_s
                    _pf = _pq_s.ParquetFile(str(_cached_path))
                    _cache_stats = {"total_rows": _pf.metadata.num_rows, "total_columns": _pf.metadata.num_columns}
                except Exception as _pq_cache_exc:
                    # BF-CACHE-CORRUPT: cached file is unreadable (truncated,
                    # zero-byte, mid-write).  Was: logged warning then served
                    # the broken file with total_rows=0 → user got an empty
                    # cache hit.  Now: evict the entry + fall through to
                    # fresh execution.
                    logger.warning(
                        "[query_cache] Cached parquet unreadable — evicting + re-executing: %s (path=%s)",
                        _pq_cache_exc, _cached_path,
                    )
                    try:
                        _cache_invalidate(_cache_key)
                    except Exception:
                        pass
                    _cached_path = None
                    _cache_stats = None
            if _cached_path:
                execution_id = str(uuid.uuid4())
                file_id = str(uuid.uuid4())
                await adb(_db_manager.create_execution, 
                    execution_id=execution_id,
                    query_id=request.query_id,
                    query_config=query_config_model.model_dump(),
                    executed_by=request.executed_by,
                )
                await adb(_db_manager.update_execution, execution_id, status="completed",
                                            engine="result_cache",
                                            output_file=str(_cached_path),
                                            total_rows=_cache_stats.get("total_rows", 0),
                                            file_size_bytes=_cached_size)
                await adb(_db_manager.create_download_file, 
                    file_id=file_id, execution_id=execution_id,
                    filename=f"cached_result_{execution_id}.parquet",
                    file_path=str(_cached_path),
                    file_size_bytes=_cached_size,
                    expires_at=_download_expires_at(transient=True),
                )
                await _ws_manager.broadcast_to_user(_username, _with_engine({
                    "type": "execution_completed", "execution_id": execution_id,
                    "file_id": file_id, "cache_hit": True,
                    "stats": _cache_stats,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }, "result_cache"))
                return {
                    "execution_id": execution_id, "status": "completed",
                    "cache_hit": True, "file_id": file_id,
                    "message": "Served from cache",
                }

        # ── Base-data reuse: query local parquet instead of re-downloading ────
        # If the exact cache missed but the same base data (FROM/WHERE/JOIN) is
        # already on disk from a previous S3 download, run the new SELECT /
        # aggregation / ORDER BY locally via DuckDB — zero network round-trip.
        #
        # BF-236: SKIP this branch entirely when raw_sql is set.  Base-data
        # reuse runs the auto-generated SQL from query_config against the
        # cached parquet — it ignores raw_sql.  When the user is editing the
        # SQL editor, that means we'd silently run their PREVIOUS auto-gen
        # SQL instead of what they typed, returning wrong results.
        # RLS SAFETY (2026-07-06): the base-data fast-path runs auto-generated
        # SQL against cached parquet locally WITHOUT secure_sql -- a row-security
        # bypass (the user could get all rows / unmasked columns on a cache
        # hit).  When row-security is enabled, SKIP the fast-path so the query
        # flows through the RLS-enforced normal path (execute_query_background).
        # Fail-CLOSED: if we can't determine RLS state, don't use the unsecured
        # fast-path.
        _rls_active = True
        try:
            from core.row_security.api import _is_enabled as _rs_is_enabled
            _rls_active = bool(_rs_is_enabled())
        except Exception:
            _rls_active = True
        if request.cache_strategy in ("auto", "refresh") and not request.raw_sql and not _rls_active:
            try:
                from core.query_cache import make_base_data_key, get_cached_result as _get_base
                _qcd_base = query_config_model.model_dump()
                _base_key = make_base_data_key(_qcd_base)
                _base_path = _get_base(_base_key)
                if _base_path and _base_path.exists():
                    # Defense-in-depth: verify cached parquet is truly raw base
                    # data (SELECT *), not an aggregated/column-restricted result
                    # stored before the store-side fix.
                    _base_ok = True

                    # Check 1: verify the STORED query had no aggs/cols
                    # (i.e., was a genuine SELECT * result)
                    try:
                        _stored_entry = await adb(_db_manager.get_cache_entry, _base_key)
                        _stored_qc = (_stored_entry or {}).get("query_config") or {}
                        if isinstance(_stored_qc, str):
                            import json as _json_check
                            _stored_qc = _json_check.loads(_stored_qc)
                        if bool((_stored_qc.get("aggregations") or [])) or bool((_stored_qc.get("columns") or [])):
                            logger.info("[base_data_reuse] Base-data cache SKIP — stored entry was "
                                        "aggregated/column-restricted, not raw base data")
                            _base_ok = False
                    except Exception as _entry_exc:
                        logger.debug("[base_data_reuse] Stored entry check failed: %s", _entry_exc)

                    # Check 2: verify cached parquet has the columns the
                    # new query needs (explicit columns/aggs only)
                    _req_cols = _qcd_base.get("columns") or []
                    _req_aggs = _qcd_base.get("aggregations") or []
                    if _base_ok and (_req_cols or _req_aggs):
                        try:
                            import pyarrow.parquet as _pq_check
                            _cached_schema = _pq_check.read_schema(str(_base_path))
                            _cached_col_names = set(_cached_schema.names)
                            _needed = set()
                            for _rc in _req_cols:
                                _bare = _rc.rsplit(".", 1)[-1] if "." in _rc else _rc
                                _needed.add(_bare)
                            for _ra in _req_aggs:
                                _ac = _ra.get("column", "")
                                _bare_a = _ac.rsplit(".", 1)[-1] if "." in _ac else _ac
                                _needed.add(_bare_a)
                            _missing = _needed - _cached_col_names
                            if _missing:
                                logger.info("[base_data_reuse] Base-data cache SKIP — cached parquet "
                                            "missing columns: %s (has: %s)",
                                            sorted(_missing)[:5], sorted(_cached_col_names)[:10])
                                _base_ok = False
                        except Exception as _schema_exc:
                            logger.debug("[base_data_reuse] Schema check failed: %s", _schema_exc)
                            _base_ok = False
                if _base_path and _base_path.exists() and _base_ok:
                    logger.info("[base_data_reuse] Base-data cache HIT — serving from local parquet "
                                "(skipped S3 download), base_key=%s, file=%s", _base_key[:16], _base_path.name)
                    _bd_exec_id = str(uuid.uuid4())
                    _bd_output = _paths.downloads_dir / f"{_bd_exec_id}.parquet"
                    _loop_bd = asyncio.get_running_loop()
                    import time as _bd_time
                    _bd_t0 = _bd_time.monotonic()
                    _bd_result = await _loop_bd.run_in_executor(
                        _query_executor,
                        run_base_data_local_query,
                        _base_path, _qcd_base, _bd_output,
                    )
                    _bd_elapsed_ms = (_bd_time.monotonic() - _bd_t0) * 1000
                    if _bd_result and _bd_output.exists():
                        logger.info("[base_data_reuse] Local query completed in %.0fms "
                                    "(rows=%s, cols=%s)",
                                    _bd_elapsed_ms,
                                    _bd_result.get("total_rows"),
                                    _bd_result.get("total_columns"))
                        _bd_file_id = str(uuid.uuid4())
                        await adb(_db_manager.create_execution, 
                            execution_id=_bd_exec_id,
                            query_id=request.query_id,
                            query_config=_qcd_base,
                            executed_by=request.executed_by,
                        )
                        await adb(_db_manager.update_execution,
                            _bd_exec_id, status="completed",
                            # re-queried locally over a cached base -- DuckDB ran
                            engine="duckdb",
                            output_file=str(_bd_output),
                            total_rows=_bd_result["total_rows"],
                            file_size_bytes=_bd_result["file_size_bytes"],
                        )
                        await adb(_db_manager.create_download_file, 
                            file_id=_bd_file_id, execution_id=_bd_exec_id,
                            filename=f"query_result_{_bd_exec_id}.parquet",
                            file_path=str(_bd_output),
                            file_size_bytes=_bd_result["file_size_bytes"],
                            expires_at=_download_expires_at(),
                        )
                        # Store exact cache entry so next identical query is an instant hit
                        try:
                            from core.query_cache import make_cache_key as _mkck_bd, store_result as _store_exact
                            _exact_key = _mkck_bd(_qcd_base)
                            _store_exact(_exact_key, _bd_output, _qcd_base,
                                         row_count=_bd_result["total_rows"], copy=False)
                        except Exception as _exact_cache_exc:
                            logger.warning("Failed to store exact cache entry after base-data reuse: %s", _exact_cache_exc, exc_info=True)
                        await _ws_manager.broadcast_to_user(_username, _with_engine({
                            "type": "execution_completed", "execution_id": _bd_exec_id,
                            "file_id": _bd_file_id, "cache_hit": True, "base_data_reuse": True,
                            "stats": {
                                "total_rows": _bd_result.get("total_rows"),
                                "total_columns": _bd_result.get("total_columns"),
                                "duration_seconds": _bd_result.get("duration_seconds"),
                            },
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }, "duckdb"))
                        return {
                            "execution_id": _bd_exec_id, "status": "completed",
                            "cache_hit": True, "base_data_reuse": True,
                            "file_id": _bd_file_id,
                            "message": "Served from local base-data cache (no S3 download)",
                        }
            except Exception as _bd_exc:
                logger.debug("[base_data_reuse] Check failed, falling through: %s", _bd_exc)

        # ── In-flight deduplication ──────────────────────────────────────────────
        # If an identical query (same cache_key) is already running, create a
        # shadow execution that waits for the primary instead of starting a
        # duplicate transfer.  Each user gets their own execution record;
        # only one network transfer / query happens.
        # asyncio is single-threaded between awaits so the check+register is atomic.
        _dedup_cache_key: Optional[str] = None
        _query_config_dict = query_config_model.model_dump()
        from core.query_cache import make_cache_key as _mkck_dedup, rls_user_scope as _rls_us_dedup
        # BF-235: raw_sql participates in dedup too — same query_config but
        # different SQL must NOT join an in-flight execution.
        # Round 5: user_scope for RLS-enabled deployments — without it,
        # two users hitting the same query concurrently would share one
        # execution and the second user would see the first user's
        # RLS-scoped result.
        _dedup_scope = _rls_us_dedup(_user)
        _dedup_cache_key = _mkck_dedup(
            _query_config_dict, raw_sql=request.raw_sql,
            user_scope=_dedup_scope,
        )

        if _dedup_cache_key in _inflight_queries:
            _primary_id, _inflight_event = _inflight_queries[_dedup_cache_key]
            _username_dedup = _user.get("username", "guest") if _user else "guest"
            shadow_id = str(uuid.uuid4())
            await adb(_db_manager.create_execution, 
                execution_id=shadow_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username_dedup,
            )
            # BF-591: strong-ref via _track_bg_task — was Python issue #88831 hazard.
            _track_bg_task(
                join_inflight_query(shadow_id, _dedup_cache_key, _inflight_event, _primary_id)
            )
            logger.info("[dedup] %s joined in-flight %s (key=%s...)",
                        shadow_id[:8], _primary_id[:8], _dedup_cache_key[:8])
            return {
                "execution_id": shadow_id,
                "status": "pending",
                "message": "Query already running — result will be shared",
            }

        # Per-user rate limit (cross-process via Redis when available) — 22B
        # Phase 102-B: per-role limits driven by admin_governance config.
        _user_role = (_user or {}).get("role", "viewer") if _user else "viewer"
        _role_limit = 0
        try:
            from core.rate_limiter import check_rate_limit, RateLimitExceededError as _RLE
            from core.config import admin_governance as _gov
            # FB-48 (2026-09-20): admin_governance.rate_limit_enabled had NO
            # reader -- an admin switching limiting off got limiting anyway.
            # It failed to RELEASE, which is the direction someone reaches
            # mid-incident.  Note this is NOT ``_gov.enabled``: turning the
            # whole governance section off must not be the only way to lift a
            # rate limit, because it takes the daily quotas and the per-user
            # caps with it.
            if _gov.rate_limit_enabled:
                _role_limit = _gov.rate_limit_for_role(_user_role) if _gov.enabled else 60
                check_rate_limit("execute", _username, limit=_role_limit, window_seconds=60)
        except _RLE as _rle:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: max {_role_limit} query submissions per minute "
                       f"for role '{_user_role}'. Retry after {_rle.retry_after}s.",
                headers={"Retry-After": str(_rle.retry_after)},
            )
        except HTTPException:
            raise
        except Exception as _rl_exc:
            logger.warning("Rate limiter failed (fail-open): %s", _rl_exc, exc_info=True)

        # Phase 102-C: per-role daily query quota (cached, fail-open)
        try:
            from core.config import admin_governance as _gov
            if _gov.enabled:
                _role_quota = _gov.daily_quota_for_role(_user_role)
                if _role_quota > 0:  # 0 = unlimited
                    # BF-NONBLOCK-AUDIT-8: cache-miss path hits DB
                    # (count_executions_today).  TTL caches most calls
                    # but the miss is sync.
                    _daily_count = await asyncio.to_thread(
                        _get_cached_daily_count, _username)
                    if _daily_count >= _role_quota:
                        raise HTTPException(
                            status_code=429,
                            detail=f"Daily query quota exceeded: {_daily_count}/{_role_quota} "
                                   f"queries used today (role '{_user_role}'). "
                                   f"Quota resets at 00:00 UTC.",
                        )
                    _bump_daily_quota_cache(_username)
        except HTTPException:
            raise
        except Exception as _quota_exc:
            logger.warning("Daily quota check failed (fail-open): %s", _quota_exc, exc_info=True)

        # 2026-09-28: the global cap (load shed, 503) is decided INSIDE the
        # slot grant below, atomically with the increment -- global before
        # per-user, as before.
        # BF-584 (2026-05-29): per-user concurrent-query slot acquired
        # via queue helper.  Bursts above ``max_concurrent_per_user``
        # WAIT in a per-user queue for up to ``queue_wait_timeout_seconds``
        # instead of 429-ing immediately.  Frontend gets an
        # ``execution_queued`` WS event with the position as soon as
        # the slot wait begins.
        #
        # Pre-generate execution_id BEFORE the slot acquire so the WS
        # event has a stable identifier the frontend can correlate
        # with the eventual execution_started / completed events.
        execution_id = str(uuid.uuid4())
        _max_per_user = _qe_cfg.max_concurrent_per_user
        _max_queue    = _qe_cfg.max_queue_size
        _wait_timeout = _qe_cfg.queue_wait_timeout_seconds
        _slot_acquired, _slot_reason, _wait_seconds = await _acquire_user_slot(
            _username, _max_per_user, _max_queue, _wait_timeout,
            execution_id=execution_id, max_global=_global_cap(),
            global_wait_timeout=_interactive_global_wait(),
            client_request_id=request.client_request_id,
        )
        if not _slot_acquired:
            _raise_if_load_shed(_slot_reason, _wait_seconds)
            if _slot_reason == "queue_full":
                raise HTTPException(
                    status_code=503,
                    detail=(
                        f"Server busy: your queue is full ({_wait_seconds} "
                        f"queries waiting).  Try again in a few seconds."
                    ),
                    headers={"Retry-After": "30"},
                )
            if _slot_reason == "cancelled":
                # BF-585: user cancelled while waiting in queue.  No
                # DB record was created yet — return 200 with the
                # cancelled status so the frontend can finalize the chip.
                return _cancelled_while_queued(execution_id)
            # wait_timeout OR no_queue
            raise HTTPException(
                status_code=503,
                detail=(
                    f"Query wait timeout: no slot freed within "
                    f"{_wait_timeout}s.  Server is busy — retry shortly."
                ),
                headers={"Retry-After": "30"},
            )
        if _slot_reason == "ok_after_wait":
            logger.info(
                "[execute_query] %s acquired slot after %ds wait (queue)",
                _username, _wait_seconds,
            )
        # BF-575/591: register orphan-tracker BEFORE any await that could
        # be cancelled.  The outer 30s budget handler reads this on
        # TimeoutError and decrements if we still own the count (i.e.
        # ownership never transferred to the background task).
        # BF-591: ContextVar was invisible to the outer wait_for handler
        # — use a module-level dict keyed by _req_key (UUID, BF-593) so the outer
        # can see the inner's writes.
        _pending_owner_by_req[_req_key] = _username

        # ── Idempotency check ─────────────────────────────────────────────
        # BF-593 (2026-05-30): the idempotency early-return previously
        # leaked the slot AND the orphan-tracker entry — every duplicate
        # request silently consumed a per-user slot until the process
        # restarted.  Release both before returning.
        if request.idempotency_key:
            from core.execution_state import check_idempotency, register_idempotency
            # SECURITY 2026-08-20: scope the lookup to the CALLER — the key
            # value is client-supplied, so an unscoped lookup handed user B
            # user A's execution (status + result handle) whenever the two
            # submitted the same key string.
            _existing_exec_id = check_idempotency(request.idempotency_key,
                                                  username=_username)
            if _existing_exec_id:
                _existing = await adb(_db_manager.get_execution, _existing_exec_id)
                if _existing:
                    _release_user_slot(_username)
                    _pending_owner_by_req.pop(_req_key, None)
                    return {
                        "execution_id": _existing_exec_id,
                        "status": _existing.get("status", "pending"),
                        "started_at": _existing.get("started_at"),
                        "message": "Duplicate request — returning existing execution",
                        "idempotent": True,
                    }

        # Guard: decrement counter if task setup fails after increment
        try:
            # BF-584: execution_id was pre-generated upstream of slot
            # acquire so queue WS notifications carry the same id the
            # frontend will use for subsequent execution_started /
            # execution_completed events.
            if request.idempotency_key:
                from core.execution_state import register_idempotency
                register_idempotency(request.idempotency_key, execution_id,
                                     username=_username)

            # Record checkpoint intent BEFORE execution starts (Phase 41)
            # 2026-10-07: awaited on the checkpoint lane, not inline on the loop.
            from core.checkpoint import arecord_intent as _record_intent
            await _record_intent(execution_id, query_config_model.model_dump(),
                                 executed_by=request.executed_by or _username,
                                 query_id=request.query_id)

            execution = await adb(_db_manager.create_execution, 
                execution_id=execution_id,
                query_id=request.query_id,
                query_config=query_config_model.model_dump(),
                executed_by=request.executed_by or _username
            )

            # ── External executor mode: enqueue and return immediately ─────
            from core.config import executor as _exec_cfg
            # 2026-10-13 -- RAW SQL on the S3 / parquet engine stays on THIS
            # path: it runs through setup_registered_views (the registered
            # Iceberg / parquet tables the SQL names become DuckDB views) in
            # execute_query_background, which the external executor's
            # ``parquet_query`` task does not have -- it runs query_config
            # only, so every raw-SQL query on an S3 connection failed four
            # times with "At least one file must be specified" (found reading
            # the owner's fact_tetb directly from AWS S3).  Structured queries
            # still go to the executor.
            _raw_on_s3_engine = bool((_effective_raw_sql or "").strip()) and not _target_is_remote_sql
            if _exec_cfg.mode == "external" and not _raw_on_s3_engine:
                from core.queue_backend import get_task_queue
                get_task_queue().enqueue_task(
                    task_id=str(uuid.uuid4()),
                    task_type="parquet_query",
                    payload={
                        "execution_id": execution_id,
                        "query_config": query_config_model.model_dump(),
                        "connection_id": _effective_conn_id,
                        "executed_by": _username,
                        "raw_sql": _effective_raw_sql,
                        "cache_strategy": request.cache_strategy,
                        "callback_url": request.callback_url or "",
                    },
                    execution_id=execution_id,
                    created_by=_username,
                    priority=0,
                )
                # BF-584: enqueue path delegates execution to the worker
                # pool — release the API-level slot + wake queued
                # waiter so other API requests can proceed.
                _release_user_slot(_username)
                # BF-591: AFTER release, clear the orphan tracker so the
                # outer 30s budget handler's TimeoutError path can't
                # double-decrement if it fires during the wait-mode
                # polling loop below.
                _pending_owner_by_req.pop(_req_key, None)

                # ── Wait mode: poll until done or timeout ─────────────────
                if request.wait:
                    # BF-591: get_event_loop() is deprecated on Py 3.12+;
                    # prefer get_running_loop() in async code.
                    _deadline = asyncio.get_running_loop().time() + request.wait_timeout
                    while asyncio.get_running_loop().time() < _deadline:
                        await asyncio.sleep(0.5)
                        _exec_rec = await adb(_db_manager.get_execution, execution_id)
                        if _exec_rec and _exec_rec.get("status") not in ("pending", "processing"):
                            return _exec_rec
                    # Timed out — return current state
                    _exec_rec = await adb(_db_manager.get_execution, execution_id)
                    return _exec_rec or {
                        "execution_id": execution_id,
                        "status": "pending",
                        "message": f"Still processing after {request.wait_timeout}s timeout",
                    }

                return {
                    "execution_id": execution_id,
                    "status": "pending",
                    "started_at": execution["started_at"],
                    "message": "Query enqueued for external execution",
                }

            # ── Stale-result fallback file ──────────────────────────────────
            # Resolved BEFORE launching the task so execute_query_background
            # can serve the last known-good result on connection/auth failure.
            _fallback_output_file: Optional[str] = None
            # 1) Stale cache: entry expired but physical file still on disk
            if _dedup_cache_key:
                try:
                    from core.query_cache import get_stale_cached_result as _get_stale
                    _sc = _get_stale(_dedup_cache_key)
                    if _sc:
                        _fallback_output_file = str(_sc)
                except Exception as _stale_exc:
                    logger.warning("Stale cache lookup failed for fallback: %s", _stale_exc, exc_info=True)
            # 2) Last successful execution for this saved query
            if not _fallback_output_file and request.query_id:
                try:
                    _lx = await adb(_db_manager.get_last_successful_output_file, request.query_id)
                    if _lx:
                        _fallback_output_file = _lx["output_file"]
                except Exception as _last_out_exc:
                    logger.warning("Last successful output file lookup failed: %s", _last_out_exc, exc_info=True)
            # ────────────────────────────────────────────────────────────────

            # Register as primary in-flight BEFORE starting the task (no await between)
            if _dedup_cache_key:
                _inflight_queries[_dedup_cache_key] = (execution_id, asyncio.Event())

            # Use _run_query_and_signal so _inflight_queries is cleaned up on completion.
            # BF-591: strong-ref via _track_bg_task so Python issue #88831
            # cannot GC the in-flight task mid-await.  Replaces the
            # bare `_task = asyncio.create_task(...)` that relied on the
            # event loop's WeakSet to keep the task alive.
            _track_bg_task(
                _run_query_and_signal(
                    execution_id,
                    engine_config,
                    request.query_id,
                    active_engine,
                    executed_by=_username,
                    raw_sql=_effective_raw_sql,
                    cache_strategy=request.cache_strategy,
                    cache_key=_dedup_cache_key,
                    cache_key_scope=_dedup_scope,
                    query_config_dict=_query_config_dict,
                    fallback_output_file=_fallback_output_file,
                    # Phase 131 deep-dive #13 (round 4 follow-up): structured
                    # case (raw_sql=None) gets RLS rewrite in the background.
                    # When raw_sql is set, it's already rewritten upstream;
                    # background's "raw_sql is None" gate skips double-rewrite.
                    user_ctx=_user,
                    rls_connection_id=_effective_conn_id_exec,
                )
            )
            # BF-575/591: background task now owns the counter decrement
            # via its `finally` block.  Clear the orphan tracker so
            # the outer 30s budget handler doesn't double-decrement.
            _pending_owner_by_req.pop(_req_key, None)
        except BaseException:
            # BF-575: switched from `Exception` to `BaseException` so
            # asyncio.CancelledError (BaseException in Py3.8+) is also
            # caught and triggers cleanup.  Without this, a
            # cancellation between the increment above and the orphan-
            # tracker pop above would leak the per-user counter forever.
            if _dedup_cache_key:
                _inflight_queries.pop(_dedup_cache_key, None)
            # BF-584: release slot + wake queued waiter.  Replaces the
            # legacy inline decrement.
            _release_user_slot(_username)
            _pending_owner_by_req.pop(_req_key, None)
            raise

        _audit(_user, "execute_query", None, "execution", execution_id,
               {"query_id": request.query_id, "files": getattr(engine_config, "files", [])})
        logger.info(f"Query execution started: {execution_id}")

        return {
            "execution_id": execution_id,
            "status": "pending",
            "started_at": execution["started_at"],
            "message": "Query execution started",
            "query_warnings": _query_warnings,
            # BF-522 (2026-05-28): when pre-validate timed out, surface
            # an explicit signal so the frontend can render a banner
            # like "Schema validation skipped (timed out) — binder
            # errors will appear during execution."  Avoids the silent
            # behaviour where the user retries the same broken SQL
            # thinking nothing was checked.  Values: "ok" | "timed_out"
            # | "skipped" (skipped covers the connector-specific skip
            # branch + the client opt-out branch).
            "pre_validate_status": _pre_validate_status,
            # BF-571 (2026-05-29): agent auto-corrections applied to the
            # user's SQL.  Surface every format-string repair so the
            # frontend can render a "we auto-fixed your query" banner.
            # Empty list when no repair was needed.  Each entry is a
            # dict with ``function``, ``original_format``,
            # ``repaired_format``, ``specifiers_fixed`` (list of bad
            # specifiers) and ``function_rewritten`` (DATE_FORMAT was
            # transpiled to STRFTIME) — sufficient for the UI to
            # show before/after diffs.
            "agent_format_fixes": (
                [
                    {
                        "function": _f.function,
                        "original_format": _f.original_format,
                        "repaired_format": _f.repaired_format,
                        "specifiers_fixed": _f.specifiers_fixed,
                        "function_rewritten": _f.function_rewritten,
                        "description": _f.describe(),
                    }
                    for _f in _format_fixes
                ] if _format_fixes else []
            ) + (
                # BF-577 (2026-05-29): Starburst-compat fixes ride on the
                # same response channel as the BF-571 format fixes so the
                # existing BQB / CQB / SqlQueryPage banner renders both
                # families with one consumer.
                [
                    {
                        "function": _sf.kind.upper(),
                        "original_format": _sf.before or _sf.detail,
                        "repaired_format": _sf.after or "",
                        "specifiers_fixed": [_sf.kind],
                        "function_rewritten": True,
                        "description": _sf.describe(),
                    }
                    for _sf in _starburst_fixes
                ] if _starburst_fixes else []
            ),
        }

    except HTTPException:
        raise
    except TokenExpiredError as e:
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED"})
    except CalendarTokenRefused as e:
        # 2026-09-28 -- a date token that cannot be rendered is the CALLER's
        # problem: 400 with the reason.  This catch-all turned it into a 500
        # before main.py's class handler could see it (found live on Docker).
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        # FB-41: a connector failure the classifier recognises (source
        # unreachable -> 503 + Retry-After; the driver's verdict -> 400 with
        # its sentence; missing driver -> 501) answers as itself; only the
        # residue stays this route's 500.
        from api.connector_errors import raise_if_source_error as _rise
        _rise(e, "", context="Error executing query")
        from core.proxy_utils import sanitize_proxy_error as _sanitize
        logger.error(f"Error executing query: {_sanitize(str(e))}", exc_info=True)
        raise HTTPException(status_code=500, detail=_sanitize(str(e)))
