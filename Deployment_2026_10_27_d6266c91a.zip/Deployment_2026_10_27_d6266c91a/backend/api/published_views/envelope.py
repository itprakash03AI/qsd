"""
Published Views — Result Envelope (2026-08 strategic redesign).

ONE owner of "what is true about a result".  Every Published-API response —
every format (json / csv / excel / parquet) and every source type
(saved_query / raw-SQL / federation / business_report) — is rendered FROM the
structures in this module instead of each call site assembling its own
metadata.  The design rules:

1.  DATASET vs PAGE.  A *dataset* is the materialized result of executing the
    view for a given (filters, params, snapshot, engine, user-scope) identity —
    a parquet file plus a ``DatasetManifest`` sidecar that records the TRUTH:
    true total rows, whether the materialization was capped (``TotalMode``),
    which snapshot produced it, and whether a 0-row result is verified-empty.
    A *page* (limit / offset / sort / columns) is a pure READ over that stable
    dataset.  Pagination is therefore a stable scan — N pages read the same
    file — never N independent, nondeterministically-truncated executions.

2.  UNKNOWN = UNSAFE, structurally.  ``TotalMode`` has no default; producers
    must state ``exact`` / ``at_least``.  A missing manifest (legacy cache
    entry, crashed writer) renders as ``total_mode: "unknown"`` — the envelope
    can degrade honestly but can never silently claim exactness.

3.  TYPE FIDELITY IS STRUCTURAL.  Wire serialisation never routes through
    pandas.  Pages are Arrow tables; JSON/CSV/Excel rows come from
    ``Table.to_pylist()`` which keeps int64 exact (nulls stay ``None``,
    ``9007199254740993`` stays ``9007199254740993``), Decimals stay Decimal
    (``sanitize_for_json`` stringifies >15-digit decimals), temporals ISO.
    pandas' nullable-int64→float64 coercion is impossible by construction
    because there is no pandas frame on the wire path.

4.  REJECT, never ignore.  ``read_page`` is the single chokepoint that knows
    the dataset schema; unknown ``?columns`` / ``?sort`` raise 400 there —
    both cache-HIT and MISS flow through it, so the behaviour cannot drift
    between paths.  (Filter rejection lives in ``helpers._parse_filters`` —
    the parse-side chokepoint.)

5.  PLUGIN SEAMS.  Formats render via ``rows_from_table`` /
    ``col_meta_from_schema`` / ``excel_cell``; a new output format touches one
    renderer + one dispatch entry in ``helpers._send_response``.  A new source
    type only has to produce a parquet + ``DatasetManifest``; paging, totals,
    rendering, caching and warmup come for free.

Sequenced plan (what this phase builds vs defers) lives in the module-level
notes at the bottom of ``published_views_api.py``'s redesign comment block and
in the phase tests ``tests/test_published_views_envelope_redesign.py``.
"""
from __future__ import annotations

import json
import logging
import time as _time
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from fastapi import HTTPException

from core.json_utils import sanitize_for_json

logger = logging.getLogger(__name__)

__all__ = [
    "TotalMode", "DatasetManifest", "PageSpec",
    "read_page", "rows_from_table", "iter_row_batches",
    "col_meta_from_schema", "excel_cell",
    "dataset_row_cap", "dataset_row_cap_override", "manifest_sidecar_path",
    "PageIntent", "page_intent", "current_page_intent", "page_scan_bound",
    # 2026-09-29 -- where the paged API's rows END, and where the rest is.
    "PagedCeiling", "paged_ceiling", "refuse_past_ceiling", "bulk_path_for",
    "page_continuation", "PAGED_CEILING_CONFIG_KEY",
]


# ── Truth: how much do we KNOW about the total? ──────────────────────────────

class TotalMode(str, Enum):
    """Provenance of ``total_rows``.  No default — producers must choose.

    EXACT     — total_rows is the true cardinality of the dataset.
    AT_LEAST  — materialization hit a cap; the dataset has AT LEAST this many
                rows.  The envelope surfaces ``truncated: true`` so consumers
                know to narrow filters or use the parquet export.
    UNKNOWN   — provenance lost (legacy cache entry with no manifest).  The
                envelope must say so rather than imply exactness.
    """
    EXACT = "exact"
    AT_LEAST = "at_least"
    UNKNOWN = "unknown"


# ── Dataset row cap (materialization bound) ──────────────────────────────────

# Per-request materialization-cap override (bulk export).  A ContextVar
# rather than a new parameter because ``dataset_row_cap()`` is consulted deep
# inside the source-type handlers, which share a fixed 6-caller contract —
# threading a kwarg through would churn every handler and the plugin
# registry's uniform signature.  ContextVar is async-task-scoped, so a bulk
# request's unbounded cap cannot leak into a concurrent paged request.
_ROW_CAP_OVERRIDE: ContextVar[Optional[int]] = ContextVar(
    "pv_dataset_row_cap_override", default=None
)


@contextmanager
def dataset_row_cap_override(cap: Optional[int]):
    """Scope a materialization cap to the current async task (``None`` = no-op).

    Used by the bulk export path to request an UNBOUNDED materialization
    without changing the default for the paged ``/data`` contract.
    """
    if cap is None:
        yield
        return
    token = _ROW_CAP_OVERRIDE.set(max(0, int(cap)))
    try:
        yield
    finally:
        _ROW_CAP_OVERRIDE.reset(token)


def dataset_row_cap() -> int:
    """Max rows a PV dataset materialization may hold (0 = unbounded).

    Replaces the defective ``limit + offset`` truncation: the executed query
    used to be truncated at the requested page boundary, then the truncated
    file's footer count was reported as ``total_rows`` — page 1 said
    ``total_rows=100, has_more=false`` for a million-row view.  Now the
    dataset is materialized up to this cap (cap+1 requested so overflow is
    detectable), pages are read from the stable file, and a hit cap is
    reported honestly as ``total_mode: "at_least"``.

    An active ``dataset_row_cap_override`` (bulk export) wins over config.
    """
    _ov = _ROW_CAP_OVERRIDE.get()
    if _ov is not None:
        return max(0, int(_ov))
    try:
        from core.config import get as _cfg_get
        return max(0, int(_cfg_get("published_views", "dataset_row_cap", 1_000_000)))
    except Exception:
        return 1_000_000


# ── Page intent: what the PAGED endpoint needs from a materialisation ────────
#
# 2026-09-15.  On a cache MISS the paged ``/data`` route materialised the
# WHOLE dataset (``dataset_row_cap + 1`` rows, 1,000,001 by default) before
# answering ``?limit=10`` -- the consumer sat idle for the full download and
# then received ten rows.  The materialisation is still the stable artifact
# every page reads from, but the ROUTE now says how much of it this request
# actually needs, and the saved-query handler bounds the engine to that.
#
# Same ContextVar shape as ``dataset_row_cap_override`` and for the same
# reason: the source-type handlers share a fixed uniform signature, and the
# intent is async-task-scoped so a bounded page request can never leak its
# bound into a concurrent bulk build, warm-up or business-report execution --
# those callers never set an intent and keep full materialisation.
#
# The bound is NOT a cap that lies: a materialisation the bound truncated is
# recorded on its ``DatasetManifest`` as ``total_mode=at_least`` with
# ``scan_bound`` set, so the envelope discloses a lower bound and the cache
# reader (``DatasetManifest.covers_page``) refuses to answer a wider page from
# it.  A measured count is reported, never an invented one.

@dataclass(frozen=True)
class PageIntent:
    """The paged route's intent for ONE request.

    ``scan_floor``   None  -> full materialisation (legacy; every non-paged
                              caller).  An int -> bound the scan to what the
                              page needs, but never below this many rows (a
                              too-short cache entry is regrown geometrically
                              so a sequential pager does not re-execute per
                              page).
    ``engine_cache`` "auto" | "bypass" -- forwarded to the engine's own result
                     cache.  The route's ``?cache=bypass|refresh`` and a
                     ``live`` view must reach the ENGINE, or the header says
                     BYPASS while the rows come from a 3600s engine cache.
    """
    scan_floor: Optional[int] = None
    engine_cache: str = "auto"


_PAGE_INTENT: ContextVar[Optional[PageIntent]] = ContextVar(
    "pv_page_intent", default=None
)

_DEFAULT_INTENT = PageIntent()


@contextmanager
def page_intent(*, scan_floor: Optional[int] = None, engine_cache: str = "auto"):
    """Scope a ``PageIntent`` to the current async task."""
    token = _PAGE_INTENT.set(PageIntent(
        scan_floor=(None if scan_floor is None else max(0, int(scan_floor))),
        engine_cache=("bypass" if engine_cache == "bypass" else "auto"),
    ))
    try:
        yield
    finally:
        _PAGE_INTENT.reset(token)


def current_page_intent() -> PageIntent:
    return _PAGE_INTENT.get() or _DEFAULT_INTENT


def page_scan_bound(*, limit: int, offset: int, sort_column: Optional[str],
                    cap: int) -> Optional[int]:
    """Rows the engine must materialise for THIS page, or ``None`` for the
    full (cap-bounded) dataset.

    ``None`` whenever a bound would be wrong or pointless:
      * no intent set (a non-paged caller);
      * ``?sort`` -- a global sort cannot be evaluated from a prefix;
      * an unlimited page (``PV_UNLIMITED_ROWS``);
      * the bound would reach the dataset cap anyway (cap + 1 is the legacy
        full materialisation, whose overflow sentinel keeps working).

    Otherwise ``offset + limit + 1``: the page plus ONE row so ``has_more``
    is measured, not guessed -- raised to the intent's floor.
    """
    intent = _PAGE_INTENT.get()
    if intent is None or intent.scan_floor is None:
        return None
    if sort_column:
        return None
    from api.published_views.helpers import PV_UNLIMITED_ROWS
    limit = max(0, int(limit))
    if limit >= PV_UNLIMITED_ROWS:
        return None
    need = max(0, int(offset)) + limit + 1
    want = max(need, int(intent.scan_floor))
    if cap > 0 and want >= cap + 1:
        return None
    return want


# ── The paged ceiling: where the paged API's rows END, and where the rest is ─
#
# 2026-09-29, found live on Docker.  A published view over a federation view
# that UNIONs two 3,000,000-row sides (its own /preview said 6,000,000 rows)
# answered ``/data?limit=5`` with ``total_rows: 1000000, total_mode:
# at_least, has_more: true`` -- and ``/data?limit=5&offset=2999998`` with a
# 200, zero rows, ``has_more: false``, ``next_offset: null``.  The dataset
# had been materialised up to ``published_views.dataset_row_cap`` (the
# 1,000,000 ceiling every paged materialisation stops at) and the page reader
# then read past the end of THAT file.  A client paging by has_more /
# next_offset stopped at the millionth row believing it held everything, a
# page past the ceiling read as "end of data", and nothing in the paged
# response said the other five million rows are one URL away at /bulk.
# Rows lost behind a 200: a cap must throttle, a correctness gate must fail.
#
# ONE rule, decided here and read everywhere (the JSON envelope, the csv /
# parquet / excel headers, the /data route's three exits, the GraphQL bridge):
#
#   * A result whose ``total_mode`` is ``at_least`` and whose materialisation
#     is NOT a page-bounded prefix (``scan_bound`` unset -- a prefix serves a
#     wider page by re-materialising, see ``DatasetManifest.covers_page``) has
#     a CEILING: its ``total_rows`` is the last row the paged API can serve.
#   * A page whose offset is AT OR PAST the ceiling is REFUSED -- 416 Range
#     Not Satisfiable (the same answer ``api/jobs_api.py`` gives a result
#     range past EOF), naming the ceiling, the key that sets it, and the
#     full-result path -- never an empty 200.
#   * The pages INSIDE the ceiling say so: ``pagination.truncated_at`` /
#     ``truncated_by`` / ``continue_with`` on JSON, ``X-QS-Truncated-At`` /
#     ``X-QS-Continue-With`` on every format.  ``has_more`` keeps its
#     meaning ("another page THROUGH THIS ENDPOINT") and stays false on the
#     ceiling's last page -- a client that follows has_more alone still
#     terminates, and one that reads the new fields knows why and where.

PAGED_CEILING_CONFIG_KEY = "published_views.dataset_row_cap"
BULK_FORMATS = ("csv", "arrow", "jsonl")


def bulk_path_for(slug: str) -> str:
    """The full-result path for a view: the bulk lane re-materialises an
    ``at_least`` dataset unbounded (``bulk_dataset_row_cap`` = 0) and streams
    it whole -- ``.csv`` / ``.arrow`` / ``.jsonl`` suffixes pick the format."""
    return f"/api/v1/views/{slug}/bulk"


@dataclass(frozen=True)
class PagedCeiling:
    """Where a paged result's rows end (``rows``), what put the ceiling there
    (``set_by``) and where the whole result is (``continue_with``)."""
    rows: int
    set_by: str
    continue_with: str

    def past(self, offset: int) -> bool:
        """Is a page starting at ``offset`` beyond every row the paged API
        can serve?  At the ceiling (``offset == rows``) there is nothing to
        serve either -- that page is refused, not answered empty."""
        return max(0, int(offset)) >= self.rows

    def sentence(self) -> str:
        return (
            f"this view has at least {self.rows:,} rows; the paged API serves "
            f"the first {self.rows:,} ({self.set_by}); read the whole result at "
            f"{self.continue_with} (.{' / .'.join(BULK_FORMATS)})"
        )

    def refusal_detail(self, offset: int) -> dict:
        """The 416 body: machine-readable fields plus the sentence."""
        return {
            "error": "past_ceiling",
            "message": (
                f"Offset {int(offset):,} is at or past the rows the paged API "
                f"can serve: {self.sentence()}."
            ),
            "ceiling": self.rows,
            "set_by": self.set_by,
            "offset": int(offset),
            "continue_with": self.continue_with,
            "continue_with_formats": [f"{self.continue_with}.{f}" for f in BULK_FORMATS],
        }


def paged_ceiling(result: dict, *, slug: str) -> Optional[PagedCeiling]:
    """The ceiling THIS result stops at, or ``None`` when the paged API can
    serve every row of the dataset (``exact``), when nothing is known
    (``unknown`` is disclosed as unknown, not invented into a ceiling), or
    when the materialisation is a page-bounded PREFIX (``scan_bound`` set:
    wider pages are answered by re-materialising, so nothing ends here)."""
    if str(result.get("total_mode") or "").lower() != TotalMode.AT_LEAST.value:
        return None
    if result.get("scan_bound") is not None:
        return None
    try:
        rows = int(result.get("total_rows"))
    except (TypeError, ValueError):
        return None
    if rows < 0:
        return None
    return PagedCeiling(rows=rows, set_by=PAGED_CEILING_CONFIG_KEY,
                        continue_with=bulk_path_for(slug))


def page_continuation(result: dict, *, slug: str
                      ) -> Tuple[bool, Optional[int], Optional[PagedCeiling]]:
    """``(has_more, next_offset, ceiling)`` for a page -- THE decision, read
    by the REST envelope and the GraphQL bridge alike.

    ``has_more`` is ``offset + returned < total_rows`` -- except on a
    ceiling's LAST in-ceiling page, where it is forced TRUE with
    ``next_offset`` = the ceiling (2026-09-29, decided after the first cut):
    a client that follows only has_more / next_offset must not stop
    silently at the ceiling believing it holds everything.  Its next
    request lands on the ceiling and is refused with the 416 that names
    the bulk path (``refuse_past_ceiling``) -- it fails LOUDLY, once, with
    the way out in the body, and the loop terminates there.  A page inside
    the ceiling that is not the last, and every page of an exact dataset,
    are unchanged (an exact dataset's last page keeps ``has_more: false``).
    """
    try:
        total = int(result.get("total_rows") or 0)
        offset = max(0, int(result.get("offset") or 0))
        returned = max(0, int(result.get("returned_rows") or 0))
    except (TypeError, ValueError):
        total, offset, returned = 0, 0, 0
    has_more = (offset + returned) < total
    next_offset: Optional[int] = (offset + returned) if has_more else None
    ceiling = paged_ceiling(result, slug=slug)
    if ceiling is not None and not has_more:
        has_more = True
        next_offset = ceiling.rows
    return has_more, next_offset, ceiling


def refuse_past_ceiling(result: dict, *, slug: str,
                        offset: Optional[int] = None) -> Optional[PagedCeiling]:
    """Refuse (416) a page at or past the result's ceiling; otherwise return
    the ceiling (``None`` when there is none) for the caller to disclose.

    ``offset`` defaults to the result's own ``offset`` -- the REQUESTED one
    (the handlers clamp the READ offset to the cap and keep the request's on
    the result).  ``Content-Range: rows */<ceiling>`` is the RFC 9110 shape
    for "the range you asked for is outside what exists".
    """
    ceiling = paged_ceiling(result, slug=slug)
    if ceiling is None:
        return None
    _off = result.get("offset", 0) if offset is None else offset
    try:
        _off = int(_off or 0)
    except (TypeError, ValueError):
        _off = 0
    if ceiling.past(_off):
        raise HTTPException(
            status_code=416,
            detail=ceiling.refusal_detail(_off),
            headers={"Content-Range": f"rows */{ceiling.rows}"},
        )
    return ceiling


# ── Manifest: the truth sidecar for a materialized dataset ───────────────────

_MANIFEST_SCHEMA = "querystudio_pv_manifest_v1"


def manifest_sidecar_path(parquet_path: Path | str) -> Path:
    return Path(str(parquet_path) + ".manifest.json")


@dataclass
class DatasetManifest:
    """What is TRUE about a materialized dataset.  Written atomically next to
    the cache parquet; read back on every cache HIT so truth survives the
    cache round-trip instead of being re-derived from a footer of unknown
    provenance."""
    total_rows: int
    total_mode: TotalMode                      # REQUIRED — no default (unknown=unsafe)
    source_type: str
    produced_at: float = field(default_factory=_time.time)
    snapshot_id: Optional[int] = None
    as_of_timestamp_ms: Optional[int] = None
    engine_connection_id: Optional[int] = None
    execution_id: Optional[str] = None
    # "ok" — rows present.  "empty" — verified 0 rows (e.g. exact COUNT said 0).
    # "empty_unverified" — engine wrote a 0-row file but 0-rows-as-success
    # cannot be distinguished from a swallowed upstream failure (BF-271 cases).
    data_status: str = "ok"
    empty_causes: List[str] = field(default_factory=list)
    # ── F3 (2026-08-08): which parquet does this manifest DESCRIBE? ──────────
    # A dataset and its truth manifest are two files published in two steps.
    # Between those steps a reader can bind the NEW parquet to the OLD
    # manifest and then advertise the OLD total as ``X-QS-Total-Rows`` — a
    # TRUNCATED stream whose consumer-side reconcile PASSES, because the
    # number it checks against is the truncated one.  That is the one failure
    # class this API cannot afford, and no downstream check can catch it.
    #
    # Stamping the described file's identity INTO the manifest makes the pair
    # self-verifying: a manifest that does not match the file it sits next to
    # is not truth about that file, and ``read_bound`` refuses it.  Both
    # ``None`` = a legacy sidecar written before this field existed; those
    # cannot be verified, so ``read_bound`` reports them as UNVERIFIED and the
    # caller decides (bulk re-materializes, /data degrades to unknown).
    parquet_size_bytes: Optional[int] = None
    parquet_rows: Optional[int] = None
    # ── 2026-09-15: a PAGE-bounded materialisation ───────────────────────────
    # Set (to the bound that truncated the scan) ONLY when the paged route
    # bounded the engine below the dataset cap and the engine hit that bound:
    # the parquet is then a PREFIX of the dataset, ``total_mode`` is
    # ``at_least`` and ``total_rows`` is the measured prefix length.  ``None``
    # = a full materialisation (exact, or truncated at the dataset cap, where
    # nothing wider exists to serve).  ``covers_page`` is the one reader.
    scan_bound: Optional[int] = None
    # ── 2026-10-24: what the dataset's ONE row-security resolution decided
    # about data entitlement (core/row_security/disclosure.py::summarise --
    # identity-free: state / reason / dimensions, never the principal).
    # Stamped by ``_execute_view`` when the dataset is produced, read back
    # on every cache HIT so the page says what the materialisation it came
    # from was filtered by.  ``None`` = a sidecar written before this field
    # existed: the exit answers ``unknown``, never "not filtered".
    entitlement: Optional[dict] = None

    def covers_page(self, *, offset: int, limit: int,
                    sort_column: Optional[str], file_rows: int) -> bool:
        """Can THIS materialisation answer the page honestly?

        A full materialisation covers every page.  A prefix covers a page
        only when it is unsorted (a global sort needs the whole dataset) and
        ``offset + limit + 1 <= file_rows`` -- the page AND the row after it,
        so ``has_more`` is decided from rows that exist, never from the edge
        of the prefix.  A page the prefix cannot cover is a cache MISS that
        re-materialises wider; it is never answered short.
        """
        if self.scan_bound is None:
            return True
        if sort_column:
            return False
        return (max(0, int(offset)) + max(0, int(limit)) + 1) <= int(file_rows)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["total_mode"] = self.total_mode.value
        d["_schema"] = _MANIFEST_SCHEMA
        return d

    def binds_to(self, *, size: Optional[int], rows: Optional[int]) -> Optional[bool]:
        """Does this manifest describe a file of exactly (``size``, ``rows``)?

        ``True``  — verified match.
        ``False`` — verified MISMATCH: the manifest describes a different
                    materialization than the file the caller has open.
        ``None``  — cannot be verified (legacy sidecar, or the caller could
                    not obtain the file's identity).  UNKNOWN, not OK.
        """
        if self.parquet_size_bytes is None and self.parquet_rows is None:
            return None
        if size is None or rows is None:
            return None
        # 2026-10-24 -- ``int(x or -1)`` folded a stamped ``parquet_rows`` of
        # 0 into -1, so the manifest of every EMPTY dataset "described a
        # DIFFERENT file" (509 bytes / 0 rows vs 509 bytes / 0 rows, refused)
        # and each HIT on an empty answer degraded to total_mode unknown.  0
        # is a value; None is "not stamped".
        _m_size = -1 if self.parquet_size_bytes is None else int(self.parquet_size_bytes)
        _m_rows = -1 if self.parquet_rows is None else int(self.parquet_rows)
        return _m_size == int(size) and _m_rows == int(rows)

    def bind_to_file(self, parquet_path: Path | str) -> bool:
        """Stamp the identity of the parquet this manifest describes.

        Call it on the file whose BYTES this manifest is true about — for a
        cache publish that is the ``.tmp`` staging copy, BEFORE it is renamed
        into place, never the destination afterwards.  Binding to the
        destination after the rename would happily stamp a competing writer's
        file: two publishers interleaving would each produce a manifest that
        "verifies" against bytes it does not describe, which is precisely the
        mis-binding the stamp exists to catch.
        """
        try:
            _st = Path(str(parquet_path)).stat()
            import pyarrow.parquet as _pq
            self.parquet_rows = int(_pq.ParquetFile(str(parquet_path)).metadata.num_rows)
            self.parquet_size_bytes = int(_st.st_size)
            return True
        except Exception as exc:
            # Never fail a publish because the binding could not be read; an
            # unbound manifest degrades to UNVERIFIED, which is safe.
            logger.warning("[pv-manifest] could not bind manifest to %s: %s",
                           parquet_path, exc)
            self.parquet_size_bytes = None
            self.parquet_rows = None
            return False

    def write_sidecar(self, parquet_path: Path | str, *, bind: bool = True) -> None:
        """Atomic write (tmp + replace) so readers never see a torn manifest.

        ``bind=True`` (default) stamps the identity of the parquet this
        manifest describes, read from the file itself at write time — so the
        pair can be verified by any later reader.  Callers publishing a
        dataset MUST write the sidecar AFTER the parquet is in place, which is
        what makes the stamped identity the published one.
        """
        if bind:
            self.bind_to_file(parquet_path)
        sp = manifest_sidecar_path(parquet_path)
        tmp = sp.with_suffix(sp.suffix + ".tmp")
        tmp.write_text(json.dumps(self.to_dict(), sort_keys=True), encoding="utf-8")
        tmp.replace(sp)

    @classmethod
    def read_sidecar(cls, parquet_path: Path | str) -> Optional["DatasetManifest"]:
        """Return the manifest for a cached dataset, or None when absent /
        unreadable.  Callers must treat None as ``TotalMode.UNKNOWN`` — never
        as exact."""
        sp = manifest_sidecar_path(parquet_path)
        try:
            if not sp.exists():
                return None
            raw = json.loads(sp.read_text(encoding="utf-8"))
            if raw.get("_schema") != _MANIFEST_SCHEMA:
                return None
            return cls(
                total_rows=int(raw["total_rows"]),
                total_mode=TotalMode(raw["total_mode"]),
                source_type=str(raw.get("source_type") or "saved_query"),
                produced_at=float(raw.get("produced_at") or 0.0),
                snapshot_id=raw.get("snapshot_id"),
                as_of_timestamp_ms=raw.get("as_of_timestamp_ms"),
                engine_connection_id=raw.get("engine_connection_id"),
                execution_id=raw.get("execution_id"),
                data_status=str(raw.get("data_status") or "ok"),
                empty_causes=list(raw.get("empty_causes") or []),
                parquet_size_bytes=(int(raw["parquet_size_bytes"])
                                    if raw.get("parquet_size_bytes") is not None else None),
                parquet_rows=(int(raw["parquet_rows"])
                              if raw.get("parquet_rows") is not None else None),
                scan_bound=(int(raw["scan_bound"])
                            if raw.get("scan_bound") is not None else None),
                entitlement=(dict(raw["entitlement"])
                             if isinstance(raw.get("entitlement"), dict) else None),
            )
        except Exception as exc:
            logger.warning("[pv-manifest] unreadable sidecar %s: %s — treating as UNKNOWN", sp, exc)
            return None

    @classmethod
    def read_bound(cls, parquet_path: Path | str, *,
                   size: Optional[int] = None, rows: Optional[int] = None):
        """Read the sidecar AND check it describes THIS parquet.

        Returns ``(manifest_or_None, verified)`` where ``verified`` is:

          True  — the sidecar exists and provably describes this file.
          False — no sidecar, an unreadable one, or one that describes a
                  DIFFERENT materialization (the F3 torn-publish window).
                  ``manifest`` is None in every False case except the legacy
                  unbound sidecar, where the manifest is returned so callers
                  that can tolerate unverified truth still see it.

        The single chokepoint for "is this manifest true about this file?" —
        every reader (bulk's ``describe_dataset``, the paged cache-HIT reader)
        goes through it, so the two cannot drift.
        """
        m = cls.read_sidecar(parquet_path)
        if m is None:
            return None, False
        bound = m.binds_to(size=size, rows=rows)
        if bound is True:
            return m, True
        if bound is False:
            # The dataset was republished between the parquet rename and the
            # sidecar rename (or two writers interleaved).  Trusting this
            # manifest is exactly the silent-truncation bug — refuse it.
            logger.warning(
                "[pv-manifest] sidecar for %s describes a DIFFERENT file "
                "(manifest: %s bytes / %s rows; open file: %s bytes / %s rows) — "
                "refusing it as UNVERIFIED rather than binding stale truth to "
                "fresh data",
                parquet_path, m.parquet_size_bytes, m.parquet_rows, size, rows,
            )
            return None, False
        # bound is None — legacy sidecar with no binding, or the caller could
        # not supply the file identity.  Unverifiable: hand it back but say so.
        return m, False

    def apply_to_result(self, result: dict) -> dict:
        """Stamp manifest truth onto a result dict (the envelope input)."""
        result["total_mode"] = self.total_mode.value
        result["data_status"] = self.data_status
        if self.entitlement is not None:
            # the disclosure of the materialisation this page came from
            result["_entitlement"] = dict(self.entitlement)
        if self.empty_causes:
            result["empty_causes"] = list(self.empty_causes)
        if self.snapshot_id is not None:
            result["snapshot_id"] = self.snapshot_id
        if self.as_of_timestamp_ms is not None:
            result["as_of_timestamp_ms"] = self.as_of_timestamp_ms
        # 2026-09-29 -- a page-bounded PREFIX is ``at_least`` too, and it is
        # NOT a ceiling (a wider page re-materialises).  ``paged_ceiling``
        # tells the two apart by this key, on a MISS and on a cache HIT alike.
        if self.scan_bound is not None:
            result["scan_bound"] = int(self.scan_bound)
        return result


# ── PageSpec: validated presentation parameters ──────────────────────────────

_VALID_SORT_DIRS = ("asc", "desc")


@dataclass
class PageSpec:
    limit: int
    offset: int = 0
    sort_column: Optional[str] = None
    sort_dir: str = "asc"
    columns: Optional[List[str]] = None

    @staticmethod
    def parse_sort(sort: Optional[str]) -> Tuple[Optional[str], str]:
        """Parse ``?sort=col[:dir]``.  An invalid direction is REJECTED (400)
        instead of silently degrading to ``asc`` — same contract as unknown
        columns: unsupported input never silently does something else."""
        if not sort:
            return None, "asc"
        parts = sort.split(":", 1)
        col = parts[0].strip()
        if not col:
            raise HTTPException(400, "Invalid sort specification — expected 'column' or 'column:asc|desc'")
        direction = "asc"
        if len(parts) > 1:
            direction = parts[1].strip().lower()
            if direction not in _VALID_SORT_DIRS:
                raise HTTPException(
                    400,
                    f"Invalid sort direction '{parts[1]}' — must be 'asc' or 'desc'",
                )
        return col, direction


# ── The single pager: Arrow-native, strict by default ────────────────────────

def sorted_page_rows(pf, *, sort_column: str, order: str,
                     columns: Optional[List[str]], offset: int, limit: int):
    """Rows ``[offset, offset + limit)`` of the dataset in ``sort_column``
    order, decoding only what the page needs.  Returns a ``pa.Table``.

    2026-10-04 -- this was ``pq.read_table(path, columns).sort_by(...)
    .slice(...)``: the whole (projected) dataset in one Arrow table to hand
    back one page -- a capped dataset is up to 1,000,001 rows, so a sorted
    ``/data`` page cost hundreds of MiB per request, which the allocator
    then kept.  Now:

      1. the ORDER comes from the sort column alone (one column, read once)
         through ``pc.sort_indices`` -- the same stable sort, the same
         null placement (at end) that ``Table.sort_by`` uses, so ties and
         nulls land exactly where they did;
      2. only the page's row numbers survive (``limit`` of them);
      3. each row group holding one of them is decoded ONCE, one at a time,
         projected, and the page's rows taken from it;
      4. the taken rows are put back in sorted order.

    Peak = one column + one row group + the page, never the dataset.  Rows
    returned are identical to the old read (proven by value in
    ``tests/test_pv_worker_memory_2026_10_04.py``)."""
    import bisect

    import pyarrow as pa
    import pyarrow.compute as pc

    schema = pf.schema_arrow
    if columns:
        schema = pa.schema([schema.field(c) for c in columns])
    if limit <= 0:
        return schema.empty_table()
    # use_threads=False: decoded on the request's own thread, so the pages
    # it used are ones the give-back can reach (see bulk.iter_dataset_batches).
    key = pf.read(columns=[sort_column], use_threads=False).column(0)
    order_idx = pc.sort_indices(pa.table({"k": key}), sort_keys=[("k", order)])
    del key
    want = order_idx.slice(offset, limit).to_pylist()
    del order_idx
    if not want:
        return schema.empty_table()

    md = pf.metadata
    starts: List[int] = []
    acc = 0
    for g in range(md.num_row_groups):
        starts.append(acc)
        acc += md.row_group(g).num_rows
    by_group: Dict[int, List[Tuple[int, int]]] = {}
    for pos, row in enumerate(want):
        g = bisect.bisect_right(starts, row) - 1
        by_group.setdefault(g, []).append((pos, row - starts[g]))

    pieces = []
    placed: List[int] = []
    for g in sorted(by_group):
        hits = by_group[g]
        rg = pf.read_row_group(g, columns=columns, use_threads=False)
        pieces.append(rg.take(pa.array([local for _, local in hits],
                                       type=pa.int64())))
        placed.extend(pos for pos, _ in hits)
        del rg
    page = pa.concat_tables(pieces) if len(pieces) > 1 else pieces[0]
    back = [0] * len(placed)
    for i, pos in enumerate(placed):
        back[pos] = i
    return page.take(pa.array(back, type=pa.int64()))


def _resolve_column_name(name: Optional[str], available: List[str]) -> Optional[str]:
    """``name`` as the dataset spells it: exact, else the ONE column equal to
    it ignoring case; anything else is returned unchanged (and refused)."""
    if not name or name in available:
        return name
    hits = [a for a in available if a.lower() == name.lower()]
    return hits[0] if len(hits) == 1 else name


def read_page(
    path: str | Path,
    *,
    columns: Optional[List[str]] = None,
    limit: int = 100,
    offset: int = 0,
    sort_column: Optional[str] = None,
    sort_dir: str = "asc",
    strict: bool = True,
):
    """Read ONE page from a dataset parquet.  Returns ``(pa.Table, total_rows)``.

    The ONE place that knows the dataset schema at request time, so it is the
    validation chokepoint for ``?columns`` and ``?sort``:

      strict=True  (external contract) — unknown column / sort → HTTP 400.
      strict=False (legacy internal callers, e.g. data-grid) — unknown
                   projections are dropped, unknown sort is a no-op.

    Bounded memory as before: footer-only total, column projection pushed into
    the reader, offset/limit via ``iter_batches`` with early stop.  The sort
    path (2026-10-04, ``sorted_page_rows``) orders by the sort column ALONE
    and decodes only the row groups holding the page's rows -- a global sort
    still needs every value of that one column, never the whole projected
    dataset -- and stays IN ARROW: no pandas, so int64 columns with nulls
    keep exact values.

    2026-09-15 — the unsorted path SEEKS, it does not scan.  It used to
    iterate ``iter_batches`` from row 0 and discard batches until ``offset``:
    O(offset) decode per page, so page 1000 of a 1M-row dataset decoded a
    million rows to hand back a hundred.  The footer already says how many
    rows each row group holds, so the first row group containing ``offset``
    is located by arithmetic and only the groups from there on are decoded —
    the same technique ``bulk.iter_dataset_batches`` has used since 2026-08.
    Rows returned are identical to the scan's, including on a row-group edge
    and for the final partial page.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq

    pf = pq.ParquetFile(str(path))
    total_rows = pf.metadata.num_rows
    available = list(pf.schema_arrow.names)
    # A name in ?sort / ?columns is matched exactly, else case-insensitively
    # when exactly ONE column matches (2026-10-24, rig): the same report
    # published on AWS S3 names its columns sap_company_id and on Starburst
    # SAP_COMPANY_ID, the ?SAP_COMPANY_ID= FILTER matched on both, and
    # ?sort=SAP_COMPANY_ID was a 400 on one.  Two spellings that differ only
    # in case are still refused as ambiguous (they stay unknown).
    sort_column = _resolve_column_name(sort_column, available)
    if columns:
        columns = [_resolve_column_name(c, available) for c in columns]

    if strict:
        if columns:
            unknown = [c for c in columns if c not in available]
            if unknown:
                raise HTTPException(
                    400,
                    f"Unknown column(s) in ?columns: {', '.join(unknown)}. "
                    f"Available: {', '.join(available)}",
                )
        if sort_column and sort_column not in available:
            raise HTTPException(
                400,
                f"Unknown sort column '{sort_column}'. Available: {', '.join(available)}",
            )

    read_cols: Optional[List[str]] = None
    if columns:
        valid = [c for c in columns if c in available]
        if valid:
            read_cols = valid
            if sort_column and sort_column in available and sort_column not in read_cols:
                read_cols = read_cols + [sort_column]

    limit = max(0, int(limit))
    offset = max(0, int(offset))

    # ── Sort path: the SORT COLUMN alone decides the order; only the row
    # groups holding the page's rows are decoded (sorted_page_rows) ──
    if sort_column and sort_column in available:
        order = "ascending" if (sort_dir or "asc").lower() != "desc" else "descending"
        tbl = sorted_page_rows(pf, sort_column=sort_column, order=order,
                               columns=read_cols, offset=offset, limit=limit)
        if columns and read_cols and sort_column not in (columns or []):
            keep = [c for c in read_cols if c != sort_column]
            if keep:
                tbl = tbl.select(keep)
        return tbl, total_rows

    # ── Unsorted path: SEEK to the row group holding ``offset`` (footer
    # arithmetic, zero row reads), then stream batches from there and stop
    # as soon as the page is full.
    want_end = offset + limit
    collected = []
    md = pf.metadata
    n_groups = md.num_row_groups
    start_group = 0
    seen = 0                      # rows that precede ``start_group``
    while start_group < n_groups:
        rg_rows = md.row_group(start_group).num_rows
        if seen + rg_rows <= offset:
            seen += rg_rows
            start_group += 1
        else:
            break
    if want_end > 0 and start_group < n_groups:
        for batch in pf.iter_batches(batch_size=8192, columns=read_cols,
                                     row_groups=list(range(start_group, n_groups)),
                                     use_threads=False):     # 2026-10-04, see above
            n = batch.num_rows
            if seen + n <= offset:
                seen += n
                continue
            start = max(0, offset - seen)
            take = min(n - start, want_end - max(seen, offset))
            if take > 0:
                collected.append(batch.slice(start, take))
            seen += n
            if seen >= want_end:
                break

    if collected:
        tbl = pa.Table.from_batches(collected)
    else:
        # Empty page (offset past EOF, limit 0) — schema-only, zero row reads.
        schema = pf.schema_arrow
        if read_cols:
            schema = pa.schema([schema.field(c) for c in read_cols if c in schema.names])
        tbl = schema.empty_table()
    return tbl, total_rows


# ── Arrow-native renderers ───────────────────────────────────────────────────

def rows_from_table(table) -> List[dict]:
    """Arrow table → JSON-safe records.  ``to_pylist`` preserves int64 exactly
    (nulls → None, NO float64 coercion); ``sanitize_for_json`` handles
    temporals (ISO), Decimals (str when >15 significant digits), bytes, NaN."""
    return sanitize_for_json(table.to_pylist())


def iter_row_batches(table, batch_rows: int) -> Iterable[List[dict]]:
    """Yield JSON-safe record batches from an Arrow table — the streaming
    equivalent of ``rows_from_table`` with bounded peak memory."""
    n = table.num_rows
    step = max(1, int(batch_rows))
    for start in range(0, n, step):
        yield sanitize_for_json(table.slice(start, step).to_pylist())


def col_meta_from_schema(schema) -> List[Dict[str, str]]:
    """Column metadata from an Arrow schema (parity with the legacy pandas
    ``_build_col_meta`` type names: integer/float/datetime/boolean/string)."""
    import pyarrow.types as pt
    meta = []
    for f in schema:
        t = f.type
        if pt.is_boolean(t):
            col_type = "boolean"
        elif pt.is_integer(t):
            col_type = "integer"
        elif pt.is_floating(t) or pt.is_decimal(t):
            col_type = "float"
        elif pt.is_timestamp(t) or pt.is_date(t) or pt.is_time(t):
            col_type = "datetime"
        else:
            col_type = "string"
        meta.append({"name": f.name, "type": col_type})
    return meta


_EXCEL_NATIVE_TYPES = (int, float, str, bool)

# XLSX's numeric model is IEEE-754 binary64: Excel itself (and every reader)
# treats numeric cells as doubles, so integers beyond 2^53 CANNOT survive as
# numbers in the format — the corruption would happen inside Excel no matter
# what we write.  The honest rendering for a financial API is a TEXT cell:
# the consumer sees the exact digits.
_EXCEL_INT_EXACT_MAX = 2 ** 53


def excel_cell(value: Any):
    """Coerce a sanitized record value to something openpyxl accepts WITHOUT
    losing precision.  ints beyond Excel's exact-double range are written as
    text cells (exact digits) — see _EXCEL_INT_EXACT_MAX."""
    import decimal
    import datetime as _dt
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, int):
        return value if abs(value) <= _EXCEL_INT_EXACT_MAX else str(value)
    if isinstance(value, (float, str)):
        return value
    if isinstance(value, (decimal.Decimal, _dt.datetime, _dt.date, _dt.time)):
        return value
    return str(value)
