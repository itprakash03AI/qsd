"""Dataset-file work on the published-API path runs OFF the event loop -- ONE
rule, one place (2026-10-10).

WHAT WAS MEASURED.  ``scripts/docker_proof/multiuser_load.py --levels 25,50,100``
inside the Docker network: at 50 concurrent workers three published-API
requests died with ``Connection reset by peer`` / ``RemoteDisconnected`` and
the published-api container's log showed uvicorn's supervisor reaping a
worker (``Child process [164] died``) and starting a new one -- every request
in flight on that worker lost.  Re-measured in-process (the harness in
``tests/test_published_api_off_the_loop_2026_10_10.py``: the REAL route, a
200,000-row report-backed view, 32 concurrent cached ``/data?limit=50``
calls, a 5 ms loop heartbeat sampled every 2 ms): the event loop was blocked
**4.6 s of a 6 s window** (39 stalls, the longest 0.30 s) and a cached
50-row page answered in p50 0.76 s.  619 of ~800 stall samples sat in
``envelope.read_page`` -- the Arrow decode of the row group holding the page
(DuckDB writes 122,880-row groups; a page at offset 100,000 decodes 100,000
rows to hand back 50) -- run INLINE in the ``async def`` route; the rest in
the rate limiter's shared-store upsert (a metadata-DB write per API-key
call), the manifest sidecar read, the parquet footer probe
(``_paged_entry_covers``) and the ``stat`` calls around them.  A plain
thread's heartbeat saw no stall: the GIL was released, the LOOP was held.

THE RULE.  Reading a dataset file -- its footer, its manifest sidecar, a
page of its rows, the rows' conversion to JSON-safe records -- and the
rate-limit store's round trip are blocking work that belongs on a thread,
and the thread is a DEDICATED lane (``core/interactive_lanes.py``: never
asyncio's default executor, which every ``adb()`` call on the pod queues
on).  Two lanes:

  ``pv_page``     file I/O + Arrow decode for ONE page (bounded by one row
                  group + the page; releases the GIL, so the lane's threads
                  decode in parallel).  8 threads: wider than the DB lanes
                  because a decode is CPU, not a round trip, and a 2-CPU pod
                  running 2 processes is CPU-bound long before 8 x 2 are busy.
  ``rate_limit``  the shared-window upsert of ``core.rate_limiter`` (one
                  statement; the refused-window memo answers a 429 storm
                  with no round trip at all).

Everything that reads a dataset file on the published-API path goes through
``off_loop`` (or the bundles below, which do a whole HIT's file work in ONE
hop): the ``/data`` cache HIT and its flight-follower read, the three source
handlers' page read after a materialisation, and the GraphQL bridge's cached
read.  A new reader of a cache entry or a result parquet calls one of these;
calling ``envelope.read_page`` from an ``async def`` is the defect this
module exists to prevent (``tests/test_published_api_off_the_loop_2026_10_10.py``
holds every site to it by thread identity and by a loop sampler under load).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, List, Optional, TypeVar

from core.interactive_lanes import run_in_lane

T = TypeVar("T")

#: The lane dataset-file work runs on (declared in core.interactive_lanes.LANES).
PAGE_LANE = "pv_page"
#: The lane the rate-limit store round trip runs on.
RATE_LIMIT_LANE = "rate_limit"


async def off_loop(fn: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run blocking dataset-file work ``fn(*args, **kwargs)`` on the page
    lane and await it.  THE one door; see the module docstring."""
    return await run_in_lane(PAGE_LANE, fn, *args, **kwargs)


async def rate_limit_off_loop(check: Callable[..., None], api_user: dict,
                              pv_cfg=None) -> None:
    """Run the rate-limit ``check`` (``helpers._enforce_api_key_rate_limit``,
    or a caller's own binding of it) on the rate-limit lane and await it.

    The shared limiter (``core.rate_limiter._check_shared``) is one INSERT
    ... ON CONFLICT per API-key call against the metadata database -- a round
    trip that used to run inline in every ``async def`` route of the
    published API, every request on the pod waiting for it.  The HTTP 429
    (an ``HTTPException``) raised inside the lane propagates unchanged.

    The REST routes pass THEIR module's name for the check
    (``published_views_api._enforce_api_key_rate_limit``) so a test that
    patches it there still intercepts; the GraphQL bridge calls
    ``enforce_api_key_rate_limit`` below, which resolves the helpers' name
    at call time for the same reason."""
    await run_in_lane(RATE_LIMIT_LANE, check, api_user, pv_cfg)


async def enforce_api_key_rate_limit(api_user: dict, pv_cfg=None) -> None:
    """``helpers._enforce_api_key_rate_limit`` off the loop (see above)."""
    from api.published_views.helpers import _enforce_api_key_rate_limit
    await rate_limit_off_loop(_enforce_api_key_rate_limit, api_user, pv_cfg)


# ── A cache HIT's file work, in ONE hop ─────────────────────────────────────

@dataclass
class CachedEntryProbe:
    """What the cache slot holds for THIS request, read in one thread hop.

    ``exists`` -- the parquet is there; ``mtime`` / ``age`` -- its version
    and how old it is (``fresh`` = younger than the view's TTL);
    ``sortable`` -- a ``?sort`` read may materialise it
    (``_paged_entry_safe_to_sort``, True when no sort was asked);
    ``covers`` -- the entry answers this page (``_paged_entry_covers``);
    ``entry_rows`` -- the rows it holds (the floor a regrow starts from).
    A missing file is ``exists=False`` with every other field at its "no
    entry" value, so callers test ``serves`` and nothing else."""
    exists: bool
    mtime: float = 0.0
    age: float = 0.0
    fresh: bool = False
    sortable: bool = True
    covers: bool = True
    entry_rows: int = 0

    @property
    def serves(self) -> bool:
        """The entry is present, fresh, safe to sort and covers the page."""
        return self.exists and self.fresh and self.sortable and self.covers


def probe_cached_entry(cached_path: Optional[Path], *, offset: int, limit: int,
                       sort_column: Optional[str], slug: str,
                       cache_ttl: float) -> CachedEntryProbe:
    """Every file read a cache HIT decides on -- ``stat``, the parquet footer,
    the manifest sidecar -- as one blocking call (run it through ``off_loop``).
    Byte-for-byte the decisions the route used to make inline, in the same
    order: existence, the sort-safety footer check, the coverage probe, the
    age against the TTL."""
    if not cached_path:
        return CachedEntryProbe(exists=False)
    try:
        st = cached_path.stat()
    except OSError:
        return CachedEntryProbe(exists=False)
    from api.published_views_api import _paged_entry_covers, _paged_entry_safe_to_sort
    sortable = True
    if sort_column:
        sortable = _paged_entry_safe_to_sort(cached_path, slug)
    covers, entry_rows = _paged_entry_covers(cached_path, offset, limit, sort_column)
    age = time.time() - st.st_mtime
    return CachedEntryProbe(exists=True, mtime=st.st_mtime, age=age,
                            fresh=age < float(cache_ttl), sortable=sortable,
                            covers=covers, entry_rows=entry_rows)


def dataset_version_of(path) -> Optional[str]:
    """The identity of ONE materialization of a paged dataset (2026-10-14):
    a refresh or an expiry writes a NEW file (atomic replace), so the version
    changes.  None when there is no file."""
    import hashlib
    try:
        st = Path(path).stat()
    except OSError:
        return None
    raw = f"{st.st_mtime_ns}:{st.st_size}:{getattr(st, 'st_ino', 0)}"
    # a BYPASS run (keep_bypass_run) says so in its version: its next page
    # is read with cache=bypass (2026-10-24)
    kind = "pvb1-" if ".bypass-" in Path(path).name else "pv1-"
    return kind + hashlib.sha256(raw.encode()).hexdigest()[:20]


def read_cached_page(cached_path: Path, columns: Optional[List[str]], offset: int,
                     limit: int, sort_column: Optional[str], sort_dir: str,
                     *, stream: bool) -> dict:
    """The HIT read: the page (``_read_cached_result`` -> ``envelope.read_page``)
    with the dataset's manifest truth applied (``_apply_cached_manifest``) --
    one blocking call for ``off_loop``.  The page carries the version of the
    materialization it was read from; a file replaced DURING the read is read
    again, so a page never mixes two."""
    from api.published_views.helpers import _read_cached_result
    from api.published_views_api import _apply_cached_manifest
    before = None
    result: dict = {}
    for _attempt in range(2):
        before = dataset_version_of(cached_path)
        result = _read_cached_result(cached_path, columns, offset, limit, sort_column,
                                     sort_dir, stream=stream)
        result = _apply_cached_manifest(result, cached_path)
        if stream or dataset_version_of(cached_path) == before:
            break
    result["_dataset_version"] = before
    return result


# ── A BYPASS run is pinned to ITSELF (2026-10-24) ──────────────────────────
# ``?cache=bypass`` (and every page of a ``cache_strategy: live`` view) runs
# the query fresh and used to write NOTHING -- so its page named no
# materialization, and page 2 was a NEW run: on a source with no ORDER BY
# (Starburst) the pages of two runs splice (the 2026-10-14 defect, on the
# bypass road).  A bypass run now keeps its result as a PRIVATE file beside
# the dataset's slot (same key = same filters, parameters and row-security
# scope; never the shared slot, which bypass must not change), named by a
# token, and its page carries that file's version: the next page sent with
# ``cache=bypass&dataset_version=<it>`` is read from THAT run, and a version
# that is gone is a 409.  The cache sweeper (retention_daemons pv_cleanup:
# every ``*.parquet`` past its age) and the prune below bound the files.

#: how long a bypass run answers its later pages (seconds) at the least
BYPASS_PIN_MIN_SECONDS = 900
#: the newest runs kept per dataset key: a consumer hammering cache=bypass
#: cannot fill the disk (a run removed early is an honest 409 for its pager);
#: the cache directory's own LRU budget sees these files too (v*.parquet)
BYPASS_RUNS_PER_KEY = 2


def bypass_pin_seconds(cache_ttl: Any) -> float:
    try:
        ttl = float(cache_ttl or 0)
    except (TypeError, ValueError):
        ttl = 0.0
    return min(max(ttl, float(BYPASS_PIN_MIN_SECONDS)), 86400.0)


def _bypass_runs(cached_path: Path) -> List[Path]:
    return sorted(cached_path.parent.glob(f"{cached_path.stem}.bypass-*.parquet"))


def find_bypass_run(cached_path: Optional[Path], version: str, max_age: float) -> Optional[Path]:
    """The bypass run of THIS dataset key whose version is ``version`` and is
    still within its pin; None when there is none (-> 409)."""
    if not cached_path or not version:
        return None
    now = time.time()
    for p in _bypass_runs(cached_path):
        try:
            if now - p.stat().st_mtime > max_age:
                continue
        except OSError:
            continue
        if dataset_version_of(p) == version:
            return p
    return None


def keep_bypass_run(result: dict, cached_path: Optional[Path], *, slug: str, shared_slot: Optional[bool],
                    max_age: float) -> Optional[str]:
    """Keep this bypass run's result as a private file; returns its version
    (None when it could not be kept -- the page then names no version, as
    before).  Older runs of the same key past their pin are removed."""
    if not cached_path:
        return None
    import uuid
    from api.published_views_api import _persist_result_to_cache
    now = time.time()
    for p in _bypass_runs(cached_path):
        try:
            if now - p.stat().st_mtime > max_age:
                p.unlink(missing_ok=True)
                from api.published_views.envelope import manifest_sidecar_path
                manifest_sidecar_path(p).unlink(missing_ok=True)
        except OSError:
            pass
    run = cached_path.with_name(f"{cached_path.stem}.bypass-{uuid.uuid4().hex[:12]}.parquet")
    if not _persist_result_to_cache(result, run, slug=slug, shared_slot=shared_slot):
        return None
    version = dataset_version_of(run)
    _keep_newest(cached_path, BYPASS_RUNS_PER_KEY)
    return version


def _keep_newest(cached_path: Path, n: int) -> None:
    from api.published_views.envelope import manifest_sidecar_path
    runs = []
    for p in _bypass_runs(cached_path):
        try:
            runs.append((p.stat().st_mtime_ns, p))
        except OSError:
            pass
    for _, p in sorted(runs, reverse=True)[n:]:
        try:
            p.unlink(missing_ok=True)
            manifest_sidecar_path(p).unlink(missing_ok=True)
        except OSError:
            pass


# ── A pinned page past a PREFIX regrows the whole dataset ONCE (2026-10-24) ─
# The bounded page scan (2026-09-15) materialises only what a page needs
# (offset + limit + 1) and regrows a short entry; the pin (2026-10-14) refuses
# a page from any other file.  Together they refused EVERY page 2 of a client
# that followed next_page_url as documented: page 2 regrew the prefix, the
# file's version changed, 409 (found on the rig paging the owner's fact_tetb).
# A pinned page that the entry does not cover now regrows the FULL dataset
# (cap-bounded -- a doubling would make an unordered source 409 forever), and
# the new file CONTINUES the pin only when its first rows are the pinned
# file's rows, value for value (``extends``); a source that reordered is an
# honest 409, and the restart's pages are all HITs on the full file.

def extends(new_parquet: Any, old_parquet: Any) -> bool:
    """Do ``new_parquet``'s first rows equal ALL of ``old_parquet``'s, in
    order?  False when either cannot be read (unknown is not "the same")."""
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
        old = pq.read_table(str(old_parquet))
        n = old.num_rows
        if n == 0:
            return True
        got, batches = 0, []
        for b in pq.ParquetFile(str(new_parquet)).iter_batches(batch_size=65536, columns=old.column_names):
            batches.append(b.slice(0, n - got))
            got += batches[-1].num_rows
            if got >= n:
                break
        if got < n:
            return False
        new = pa.Table.from_batches(batches).select(old.column_names)
        return new.equals(old.cast(new.schema) if new.schema != old.schema else old)
    except Exception:                                         # noqa: BLE001
        return False
