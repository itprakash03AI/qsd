"""Operator dependency controls + run steps (BRD §7, §13) — 2026-09-02.

Four endpoints, one theme: the gate has always been able to READ a human
assertion (``action='SKIP'`` → MET with ``asserted=True``, the mark riding
to the completeness verdict, FR-CMP-09) and nothing in QueryStudio could
ever WRITE one.  These are the producers, plus the two read views that make
acting on a blocked morning possible:

* ``POST /api/feed-runs/{run_id}/skip-dependencies`` — "this run goes
  anyway", per run;
* ``POST /api/feed-dependencies/{key}/skip`` — the 04:30 case: one late
  upstream, 34 feeds waiting; ONE action, not 34;
* ``GET  /api/feed-dependencies/blocking`` — the reverse index: what is
  APAC_POSITIONS blocking?
* ``GET  /api/feed-runs/{run_id}/steps`` — where a run is / where it broke,
  derived from the engine's own stage records, never invented.

Authorisation on the two writes matches ``_can_rerun_feed`` in feed_api —
skipping is at least as privileged as re-running — and the principal is
ALWAYS ``Depends(get_current_user)``, never the request body: this codebase
has shipped IDORs by trusting a body-supplied principal.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import date, datetime, timezone
from typing import Any, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from api.deps import get_current_user, require_admin

logger = logging.getLogger(__name__)
router = APIRouter(tags=["feed-ops"])

# Module-level dependencies (same wiring pattern as api/feed_api.py /
# api/run_surface_api.py — main.py calls the setter at startup).
_db_manager: Any = None
_auth_cfg: Any = None


def set_feed_ops_dependencies(db_manager: Any, auth_cfg: Any = None) -> None:
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


def _db() -> Any:
    if _db_manager is None:               # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="feed ops API not wired to a database")
    return _db_manager


async def _require_run_view(db: Any, run_id: int, user: dict) -> dict:
    """The run, if THIS principal may view its feed -- 404 for no run, the
    feed rule's own 404 / 403 otherwise (2026-10-24, security review: the
    run-read routes answered any signed-in user, while a run's SQL, its
    parameter values and its partition evidence belong to the feed's
    viewers).  ONE rule: ``core.feed.permissions.may_access_feed`` (what
    ``api.feed_api._require_feed`` asks) --
    open when login is off, an unclaimed feed org-shared, admin / support /
    owner / group member otherwise."""
    run = await asyncio.to_thread(db.get_feed_run, int(run_id))
    if not run:
        raise HTTPException(status_code=404, detail=f"feed_run {run_id} not found")
    from core.feed.permissions import auth_is_on, may_access_feed
    feed = await asyncio.to_thread(db.get_feed_config, int(run["feed_config_id"]))
    if not feed:
        raise HTTPException(status_code=404, detail=f"Feed config {run['feed_config_id']} not found")
    if not await asyncio.to_thread(may_access_feed, feed, user, db, write=False, auth_on=auth_is_on()):
        raise HTTPException(status_code=403, detail="You do not have permission to view this feed.")
    return run


def _can_skip(feed: dict, user: dict) -> bool:
    """Same gate as feed_api._can_rerun_feed: owner / read-write group
    member / admin.  Skipping ships a feed without an input confirmed, so
    it is at LEAST as privileged as re-running."""
    from core.feed.permissions import can_act_on_feed
    return can_act_on_feed(feed, user, _db_manager)


def _clean_reason(reason: Optional[str], reason_category: Optional[str] = None):
    """A VALID reason -- a category from the vocabulary plus non-trivial
    free text (``core.feed.dependency_skip.validate_skip_reason``, the ONE
    validator every skip route and the Run Now override share) -- or a 422
    that names what is missing.  An unexplained override is unauditable,
    and this is the one control that lets a feed ship without an input
    confirmed.  Returns the :class:`SkipReason`."""
    from core.feed.dependency_skip import SkipReasonRefused, validate_skip_reason
    try:
        return validate_skip_reason(reason_category, reason)
    except SkipReasonRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))


def _delivery_override_reason(reason: Optional[str]) -> str:
    """The reason a BACKFILL turns delivery on (FR-OPS-08): non-blank free
    text, audited.  Not a dependency skip, so it is not held to the skip
    CATEGORY vocabulary ("upstream holiday" does not describe a re-delivery)
    -- 2026-09-27: routing it through ``_clean_reason`` made every delivering
    backfill a 422, because the backfill dialog sends no category."""
    cleaned = str(reason or "").strip()
    if not cleaned:
        raise HTTPException(
            status_code=422,
            detail="reason is required when deliver=true: a backfill that "
                   "re-sends files to the counterparty is an audited "
                   "override.  Say who signed it off and why (e.g. "
                   "'re-delivery signed off by ops lead J. Doe').")
    return cleaned


def _parse_bd(raw: Optional[str], *, where: str) -> date:
    """A refusal, never a silent fallback — an operator who typed a date
    and got today's answer would read it as that date's answer."""
    try:
        return date.fromisoformat(str(raw or "")[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"{where} {raw!r} is not an ISO date (YYYY-MM-DD).")


def _gate(db: Any, etl_id: int, business_date: date):
    from core.feed.etl_dependency import evaluate_gate_verdicts
    return evaluate_gate_verdicts(db, int(etl_id), business_date)


# ══════════════════════════════════════════════════════════════════════
#  1. Run-level skip
# ══════════════════════════════════════════════════════════════════════

class RunSkipBody(BaseModel):
    reason: str
    #: 2026-09-27 -- one of core.feed.dependency_skip.SKIP_REASON_CATEGORIES
    #: (``GET /api/feed-dependencies/skip-reasons``).  Refused when absent.
    reason_category: Optional[str] = None
    #: None = every dependency currently blocking this run.
    dependencies: Optional[List[str]] = None


@router.post("/api/feed-runs/{run_id}/skip-dependencies")
async def skip_run_dependencies(run_id: int, body: RunSkipBody,
                                user: dict = Depends(get_current_user)):
    """Assert SKIP on the dependencies blocking ONE run.

    Writes ``action='SKIP'`` on the same tracking rows the external
    consumer writes — the existing gate path picks it up unchanged — and
    appends one audit event per skipped dependency.  Refuses (4xx, with
    what to do instead) an empty reason, a run that is not waiting, and a
    named dependency that is not in the blocking set.
    """
    db = _db()
    skip_reason = _clean_reason(body.reason, body.reason_category)
    reason = skip_reason.as_text()

    run = db.get_feed_run(int(run_id))
    if not run:
        raise HTTPException(status_code=404,
                            detail=f"feed_run {run_id} not found")
    feed = db.get_feed_config(int(run["feed_config_id"]))
    if not feed:
        raise HTTPException(
            status_code=404,
            detail=f"feed_config {run['feed_config_id']} not found")
    if not _can_skip(feed, user):
        raise HTTPException(
            status_code=403,
            detail="Only the feed owner, a read-write group member or an "
                   "admin can skip this run's dependencies — ask one of "
                   "them (skipping is at least as privileged as rerunning).")

    status = str(run.get("status") or "")
    if status != "pending":
        raise HTTPException(
            status_code=409,
            detail=f"feed_run {run_id} is {status!r}, not waiting on "
                   f"dependencies — there is nothing to skip.  To execute "
                   f"a finished run again use POST /api/feed-runs/"
                   f"{run_id}/rerun.")

    business_date = _parse_bd(run.get("business_date"),
                              where="run business_date")
    # 2026-09-27 — the feed's EFFECTIVE etl_id (explicit, else its own
    # id): the key its mappings were authored under.  A NULL etl_id used
    # to answer "not blocked by any dependency" for a run the poller had
    # held on exactly those mappings.
    from core.feed.etl_dependency import effective_etl_id
    etl_id = effective_etl_id(feed)
    verdicts = _gate(db, int(etl_id), business_date)
    blocking = {v.dependency_name: v for v in verdicts.blocking} \
        if verdicts is not None else {}
    if not blocking:
        raise HTTPException(
            status_code=409,
            detail=f"feed_run {run_id} is not blocked by any dependency "
                   f"for {business_date.isoformat()} — there is nothing to "
                   f"skip, so no assertion was written.  If the run is "
                   f"stuck for another reason, check GET /api/run-surface.")

    if body.dependencies is None:
        names = sorted(blocking)
    else:
        names = [str(n).strip() for n in body.dependencies if str(n).strip()]
        if not names:
            raise HTTPException(
                status_code=422,
                detail="dependencies was an empty list, which would skip "
                       "nothing — pass null to skip everything currently "
                       "blocking, or name the dependencies to skip.")
        unknown = [n for n in names if n not in blocking]
        if unknown:
            raise HTTPException(
                status_code=422,
                detail=f"not in this run's blocking set: {unknown}.  "
                       f"Currently blocking: {sorted(blocking)}.  Check "
                       f"the spelling — a typo must not silently skip "
                       f"nothing and report success.")

    from core.feed.dependency_skip import (
        SkipAuditUnrecordable, assert_skip, type_ids_for_key,
    )
    asserted_at = datetime.now(timezone.utc)
    actor = str(user.get("username") or "unknown")
    for name in names:
        type_ids = type_ids_for_key(db, int(etl_id), business_date, name)
        if not type_ids:
            # The gate said it blocks, so a mapping exists; not finding a
            # type is a read inconsistency, not a user error.
            raise HTTPException(
                status_code=500,
                detail=f"could not resolve the dependency type for "
                       f"{name!r} — nothing was skipped for it; retry, "
                       f"and if it persists check the mapping rows.")
        try:
            for type_id in type_ids:
                assert_skip(
                    db, dependency_type_id=type_id, dependency_key=name,
                    business_date=business_date, reason=reason, actor=actor,
                    affected_runs=[run], asserted_at=asserted_at,
                    source="run_skip_api",
                    reason_category=skip_reason.category)
        except SkipAuditUnrecordable as exc:
            raise HTTPException(status_code=500, detail=str(exc))

    after = _gate(db, int(etl_id), business_date)
    gate_now = {
        "admitted": bool(after.admitted) if after is not None else False,
        "blocking": [v.to_dict() for v in after.blocking]
        if after is not None else [],
        "asserted": bool(after.asserted) if after is not None else False,
    }
    if gate_now["admitted"]:
        # The poller would flip this within its cadence; flip it now so
        # "go anyway" means NOW, not "within a minute".  Fail-soft: the
        # assertion is already durable and the poller converges.
        try:
            from core.feed.dependency_skip import release_admitted_run
            release_admitted_run(db, int(run_id),
                                 f"dependencies skipped by {actor}: {reason}",
                                 etl_id=int(etl_id), source="run_skip")
        except Exception as exc:
            logger.error("[feed_ops] run %s admitted but could not flip "
                         "action_decision (%s) — the dep poller will",
                         run_id, exc)
    return {
        "run_id": int(run_id),
        "skipped": names,
        "reason": reason,
        "reason_category": skip_reason.category,
        "asserted_by": actor,
        "asserted_at": asserted_at.isoformat(),
        "gate_now": gate_now,
    }


@router.get("/api/feed-dependencies/skip-reasons")
async def skip_reason_vocabulary_route(user: dict = Depends(get_current_user)):
    """The reason vocabulary every skip (and the Run Now override) is
    validated against -- categories, labels, help, and the minimum free
    text (2026-09-27).  The UI offers exactly this; nothing else is
    accepted."""
    from core.feed.dependency_skip import skip_reason_vocabulary
    return skip_reason_vocabulary()


# ══════════════════════════════════════════════════════════════════════
#  2. Dependency-level skip — one action, not 34
# ══════════════════════════════════════════════════════════════════════

class DependencySkipBody(BaseModel):
    business_date: str
    reason: str
    reason_category: Optional[str] = None
    #: None = every feed waiting on this dependency that date.
    etl_ids: Optional[List[int]] = None


@router.post("/api/feed-dependencies/{dependency_key}/skip")
async def skip_dependency(dependency_key: str, body: DependencySkipBody,
                          user: dict = Depends(get_current_user)):
    """Assert SKIP on one dependency for every feed waiting on it.

    The tracking row is keyed (type, key, business_date) — GLOBAL, not
    per-feed — so one write releases every waiting feed with that mapping.
    That is the point (one action at 04:30), and also why authorisation is
    checked against EVERY feed the write would release, including feeds
    outside a requested ``etl_ids`` subset that share the same tracking
    row: a subset request cannot be honoured row-by-row by this mechanism,
    and pretending otherwise would release feeds the caller never named.
    """
    db = _db()
    skip_reason = _clean_reason(body.reason, body.reason_category)
    reason = skip_reason.as_text()
    business_date = _parse_bd(body.business_date, where="business_date")

    from core.feed.dependency_index import build_blocking_index
    index = build_blocking_index(db, business_date=business_date)
    entry = index["by_dependency"].get(dependency_key)
    if not entry or not entry["runs"]:
        raise HTTPException(
            status_code=409,
            detail=f"nothing is waiting on {dependency_key!r} for "
                   f"{business_date.isoformat()} — no assertion was "
                   f"written.  GET /api/feed-dependencies/blocking?"
                   f"business_date={business_date.isoformat()} lists what "
                   f"IS blocking right now.")

    waiting = list(entry["runs"])
    waiting_etl_ids = {int(r["etl_id"]) for r in waiting if r.get("etl_id")}
    if body.etl_ids is None:
        selected = waiting
    else:
        wanted = [int(e) for e in body.etl_ids]
        missing = sorted(set(wanted) - waiting_etl_ids)
        if missing:
            raise HTTPException(
                status_code=422,
                detail=f"etl_ids {missing} are not waiting on "
                       f"{dependency_key!r} for "
                       f"{business_date.isoformat()} — refusing so a typo "
                       f"cannot silently skip nothing.  Waiting etl_ids: "
                       f"{sorted(waiting_etl_ids)}.")
        selected = [r for r in waiting if int(r.get("etl_id") or 0)
                    in set(wanted)]

    # Which tracking rows the selection implies, and who ELSE those rows
    # release.  A run outside the selection sharing a written (type, key)
    # pair is released too — the row is global.
    from core.feed.dependency_skip import (
        SkipAuditUnrecordable, assert_skip, type_ids_for_key,
    )
    written_types: set = set()
    for r in selected:
        written_types.update(type_ids_for_key(
            db, int(r["etl_id"]), business_date, dependency_key))
    if not written_types:
        raise HTTPException(
            status_code=500,
            detail=f"could not resolve the dependency type for "
                   f"{dependency_key!r} — nothing was skipped.")
    selected_run_ids = {int(r["id"]) for r in selected}
    released = list(selected)
    for r in waiting:
        if int(r["id"]) in selected_run_ids:
            continue
        types = set(type_ids_for_key(db, int(r["etl_id"]), business_date,
                                     dependency_key))
        if types & written_types:
            released.append(r)

    # Authorisation over EVERYTHING the write releases.
    denied = []
    feed_cache: dict = {}
    for r in released:
        fid = int(r["feed_config_id"])
        if fid not in feed_cache:
            feed_cache[fid] = db.get_feed_config(fid)
        feed = feed_cache[fid]
        if not feed or not _can_skip(feed, user):
            denied.append((feed or {}).get("name") or f"feed_config {fid}")
    if denied:
        raise HTTPException(
            status_code=403,
            detail=f"skipping {dependency_key!r} would release feeds you "
                   f"cannot act on: {sorted(set(denied))}.  The tracking "
                   f"row is shared, so an admin (or someone entitled to "
                   f"all of them) must do this; to release only your own "
                   f"feed, that feed must not share the dependency row — "
                   f"use POST /api/feed-runs/{{run_id}}/skip-dependencies "
                   f"and it will still release every sharer, refused the "
                   f"same way.  Skipping is at least as privileged as "
                   f"rerunning.")

    asserted_at = datetime.now(timezone.utc)
    actor = str(user.get("username") or "unknown")
    try:
        for type_id in sorted(written_types):
            assert_skip(
                db, dependency_type_id=type_id,
                dependency_key=dependency_key,
                business_date=business_date, reason=reason, actor=actor,
                affected_runs=released, asserted_at=asserted_at,
                source="dependency_skip_api",
                reason_category=skip_reason.category)
    except SkipAuditUnrecordable as exc:
        raise HTTPException(status_code=500, detail=str(exc))

    # Flip every now-admitted run so "go anyway" means now.  Fail-soft per
    # run: the assertion is durable and the dep poller converges.
    for r in released:
        try:
            after = _gate(db, int(r["etl_id"]), business_date)
            if after is not None and after.admitted:
                from core.feed.dependency_skip import release_admitted_run
                release_admitted_run(
                    db, int(r["id"]),
                    f"dependency {dependency_key} skipped by {actor}: {reason}",
                    etl_id=int(r["etl_id"]), source="dependency_skip")
        except Exception as exc:
            logger.error("[feed_ops] could not flip run %s after skip "
                         "(%s) — the dep poller will", r.get("id"), exc)

    affected = [{"feed_run_id": int(r["id"]),
                 "feed_config_id": int(r["feed_config_id"]),
                 "feed_name": r.get("feed_name")} for r in released]
    return {
        "dependency_key": dependency_key,
        "business_date": business_date.isoformat(),
        "reason": reason,
        "reason_category": skip_reason.category,
        "asserted_by": actor,
        "asserted_at": asserted_at.isoformat(),
        "affected_runs": affected,
        "affected_count": len(affected),
    }


# ══════════════════════════════════════════════════════════════════════
#  3. The reverse index — what is APAC_POSITIONS blocking?
# ══════════════════════════════════════════════════════════════════════

@router.get("/api/feed-dependencies/blocking")
async def blocking_dependencies(
        business_date: Optional[str] = Query(default=None),
        user: dict = Depends(get_current_user)):
    """Every dependency currently blocking at least one feed, with the
    feeds it blocks.  Sections degrade independently and the gaps are
    NAMED — at 04:50 an honest gap beats a 500 (run_surface pattern)."""
    db = _db()
    if business_date is None:
        bd = datetime.now(timezone.utc).date()
    else:
        bd = _parse_bd(business_date, where="business_date")

    unavailable: List[str] = []
    deps: List[dict] = []
    try:
        from core.feed.dependency_index import (
            build_blocking_index, last_arrival_at,
        )
        index = build_blocking_index(db, business_date=bd)
    except Exception as exc:
        logger.error("[feed_ops] blocking index unreadable: %s", exc)
        return {"business_date": bd.isoformat(), "dependencies": [],
                "unavailable_sections":
                    [f"blocking_index: {type(exc).__name__}: {exc}"]}
    if index.get("errors"):
        unavailable.append(
            f"gate_reads: {index['errors']} run(s) could not be evaluated "
            f"— their blocked feeds may be missing from this answer")

    # 2026-09-28 -- the three clocks per dependency (usual arrival by its
    # own history, decision deadline, SLA) from the SAME function the SLA
    # watcher alerts on and the Support Desk shows, over the index already
    # built above.  Its own section: a failure names itself and costs the
    # clocks, never the blocking list.
    now = datetime.now(timezone.utc)
    clocks_by_dep: dict = {}
    try:
        from core.feed.acting_time import (
            blocked_row, clocks_for_blocked, failed_row,
        )
        result = clocks_for_blocked(db, bd, now, index=index)
        for item in result.blocked:
            clocks_by_dep[item.dependency_name] = blocked_row(
                item, business_date=bd, now=now)
        for entry in result.failed:
            clocks_by_dep[entry["dependency_name"]] = failed_row(entry)
    except Exception as exc:                        # noqa: BLE001
        logger.error("[feed_ops] acting-time clocks unreadable: %s", exc)
        unavailable.append(f"clocks: {type(exc).__name__}: {exc}")

    for name, entry in index["by_dependency"].items():
        runs = entry["runs"]
        type_name = None
        try:
            rows = db.list_etl_dependency_mappings_with_tracking(
                int(runs[0]["etl_id"]), bd) or []
            for row in rows:
                if str(row.get("dependency_key") or "") == name:
                    type_name = row.get("type_name")
                    break
        except Exception as exc:
            logger.debug("[feed_ops] type_name for %r unreadable: %s",
                         name, exc)
            unavailable.append(f"type_name:{name}")
        try:
            last_seen = last_arrival_at(db, name)
        except Exception:              # pragma: no cover - helper is soft
            last_seen = None
        first_waiting = min((str(r.get("created_at") or "") for r in runs
                             if r.get("created_at")), default=None)
        # 2026-09-27 — the gate's own words: which verdict, why, and per
        # declared source.  The index carries one verdict per blocked run;
        # they are the same dependency on the same date, so the first is
        # the answer (a second run cannot see different evidence).
        verdict = (entry.get("verdicts") or [None])[0]
        sources = []
        if verdict is not None:
            for s in (getattr(verdict, "sources", None) or []):
                # 2026-10-07 -- the evidence too: a file source says WHAT
                # it waits for (the rendered location) and, once met,
                # which files landed (keys, sizes, LastModified).
                sources.append({"kind": s.get("kind"),
                                "verdict": s.get("verdict"),
                                "reason": s.get("reason"),
                                "evidence": s.get("evidence")})
        deps.append({
            "dependency_key": name,
            "type_name": type_name,
            "verdict": verdict.verdict if verdict is not None else None,
            "reason": verdict.reason if verdict is not None else None,
            "sources": sources,
            "blocked_feeds": [{
                "feed_config_id": r.get("feed_config_id"),
                "feed_name": r.get("feed_name"),
                "feed_run_id": r.get("id"),
                "sla_to": r.get("sla_to"),
            } for r in runs],
            "blocked_count": len(runs),
            "first_waiting_since": first_waiting,
            "last_arrival_at": last_seen,
            # None = the clocks section is unavailable (named above); a
            # row with ``clocks_unavailable`` set = THIS dependency's
            # clocks could not be computed.  Both differ from "not late".
            "clocks": clocks_by_dep.get(name),
        })
    deps.sort(key=lambda d: (-d["blocked_count"], d["dependency_key"]))
    # 2026-09-27 -- the DECISIONS taken for this date (skips, Run Now
    # overrides, escalations), so a dependency that was skipped an hour
    # ago is visible on the panel that no longer lists it as blocking.
    # Its own section, degrading independently and NAMED when it does.
    skips: List[dict] = []
    try:
        from core.feed.dependency_skip import DECISION_EVENT_TYPES, decision_rows
        events = db.list_run_events_for_date(bd, DECISION_EVENT_TYPES)
        skips = decision_rows(events)
        feed_names: dict = {}
        for s in skips:
            fid = s.get("feed_config_id")
            if fid is not None and fid not in feed_names:
                try:
                    feed_names[fid] = (db.get_feed_config(int(fid)) or {}).get("name")
                except Exception:
                    feed_names[fid] = None
            s["feed_name"] = feed_names.get(fid)
    except Exception as exc:
        logger.error("[feed_ops] decisions for %s unreadable: %s", bd, exc)
        unavailable.append(f"decisions: {type(exc).__name__}: {exc}")
    return {"business_date": bd.isoformat(), "dependencies": deps,
            "skips": skips,
            "unavailable_sections": unavailable}


# ══════════════════════════════════════════════════════════════════════
#  4. Per-step view of one run
# ══════════════════════════════════════════════════════════════════════

def _execution_for_run(db: Any, run: dict) -> Optional[dict]:
    """The execution row this run's steps live on.

    feed_executions has no feed_run_id column, so the link is derived:
    newest execution for the feed whose build_id and business_date do not
    CONTRADICT the run's (either side lacking the field matches — most
    deployed rows predate Foundation P's stamps).  Same weak link
    run_surface.failures already uses; a contradicting row is never
    served as this run's steps.
    """
    # The recorder's own link first (2026-09-14): the latest attempt's
    # execution id on the run's step rows names THE execution.  The weak
    # link below is only for runs that predate the step model.
    try:
        from core.feed.step_model.store import execution_id_for_run
        eid = execution_id_for_run(db, int(run["id"]))
        if eid:
            linked = db.get_feed_execution_by_exec_id(eid)
            if linked:
                return linked
    except Exception as exc:                       # noqa: BLE001
        logger.debug("[feed_ops] recorded execution link unreadable for "
                     "run %s: %s", run.get("id"), exc)
    try:
        execs = db.list_feed_executions(int(run["feed_config_id"]),
                                        limit=50) or []
    except Exception as exc:
        logger.debug("[feed_ops] executions unreadable for run %s: %s",
                     run.get("id"), exc)
        return None
    run_bd = str(run.get("business_date") or "")[:10]
    run_build = run.get("build_id")
    for e in execs:
        if run_build and e.get("build_id") and e.get("build_id") != run_build:
            continue
        ebd = str(e.get("business_date") or "")[:10]
        if ebd and run_bd and ebd != run_bd:
            continue
        return e
    return None


@router.get("/api/feed-runs/{run_id}/steps")
async def feed_run_steps(run_id: int,
                         user: dict = Depends(get_current_user)):
    """The step timeline of one run.

    Answers from ``feed_run_steps`` when the run has rows — a row per
    step with real start/end times, a record count, the pod that ran it,
    the error and the step's own parameters.  Falls back to the timing
    PROJECTION for runs that executed before the step model shipped.

    ``source`` says which one you got: ``recorded`` (the rows),
    ``derived`` (the projection — ``started_at`` is null for every step
    because durations have no boundaries), or ``unavailable`` (the rows
    could not be READ, which is not the same as a run having none).
    Where the run failed, the failing step is named."""
    db = _db()
    run = await _require_run_view(db, int(run_id), user)
    execution = _execution_for_run(db, run)
    return _steps_payload(db, run, execution, run_id=int(run_id))


@router.get("/api/feed-runs/{run_id}/sql")
async def feed_run_sql(run_id: int,
                       user: dict = Depends(get_current_user)):
    """The SQL this run produced, per side, AS RENDERED -- every parameter and
    ``{TOKEN}`` resolved -- with the values it was rendered from (2026-10-24,
    the owner: "feed run status ... should show what has been executed by
    resolving parameters").  Recorded by the render chokepoints themselves
    (``core/feed/executed_sql.py``), never re-rendered here.

    ``statements`` = the latest text per (side, field); ``history`` = every
    render in order (a re-run's earlier attempt stays); ``unavailable`` set =
    the rows could not be READ, which is not the same as none.  A run that
    never reached rendering (held on a dependency) has no statements and
    says so in ``note``."""
    from core.feed.executed_sql import for_run
    db = _db()
    run = await _require_run_view(db, int(run_id), user)
    out = await asyncio.to_thread(for_run, db, int(run_id))
    status = run.get("status") if isinstance(run, dict) else getattr(run, "status", None)
    out["status"] = status
    if not out["statements"] and not out["unavailable"]:
        # 2026-10-25 (the owner: "sql as executed doesn't show what query was
        # executing or executed"): a run that has not sent its SQL yet shows
        # what it WILL send, filled in for its date, said in plain words
        st = str(status or "").lower()
        if st in ("pending", "waiting", "held", "queued", ""):
            out["note"] = ("This run has not started yet, so nothing has been sent. "
                           "When it starts, it will send the query below.")
        elif st == "running":
            out["note"] = "This run is starting. It will send the query below."
        else:
            out["note"] = ("This run did not keep the query it sent (it ran before 2026-10-24). "
                           "Below is the query the feed sends today for this date.")
        out["planned"] = await asyncio.to_thread(_planned_for_run, db, run)
    return out


def _planned_for_run(db, run) -> list:
    """The query a run will send (core/feed/test_as_feed.py::planned_sql)."""
    from datetime import date as _date
    from core.feed.test_as_feed import planned_sql
    r = run if isinstance(run, dict) else getattr(run, "__dict__", {})
    try:
        feed = db.get_feed_config(int(r.get("feed_config_id")))
        bd = r.get("business_date")
        bd = _date.fromisoformat(str(bd)[:10]) if bd else None
        rd = r.get("run_date")
        rd = _date.fromisoformat(str(rd)[:10]) if rd else None
    except Exception as exc:                            # noqa: BLE001 -- said, never raised
        return [{"side": "primary", "sql": None, "params": {}, "error": f"the feed could not be read: {exc}"}]
    if not feed or bd is None:
        return [{"side": "primary", "sql": None, "params": {},
                 "error": "the feed or the run's business date is missing"}]
    return planned_sql(db, feed, bd, rd)


#: Test seams (2026-09-14).  The cluster is reached through these two so
#: the routes are provable with a fake API and a declared availability.
_kube_api_factory = None          # () -> object with read_pod_log / get_spark_application
_spark_availability_fn = None     # () -> core.spark_k8s.availability.Availability


def _kube_api():
    if _kube_api_factory is not None:
        return _kube_api_factory()
    from core.spark_k8s.client import make_kube_api
    return make_kube_api()


def _spark_availability():
    if _spark_availability_fn is not None:
        return _spark_availability_fn()
    from core.spark_k8s import availability as _av
    return _av.current()


def _driver_pod_name(external_job_id: str, mode: str) -> str:
    """The pod that ran the driver -- THE rule lives in
    ``core/spark_k8s/completion.py::driver_pod_name_for`` (2026-10-11: the
    reconciler reads the job's report from the same pod)."""
    from core.spark_k8s.completion import driver_pod_name_for
    return driver_pod_name_for(external_job_id, mode)


def _recorded_delivery_chain(execution: dict) -> dict:
    """``stage_timings.delivery_chain`` as recorded, or {} -- read, never
    derived (delivery_hops.chain_verdict and the webhooks write it)."""
    st = execution.get("stage_timings")
    chain = st.get("delivery_chain") if isinstance(st, dict) else None
    return chain if isinstance(chain, dict) else {}


def _execution_summary(db: Any, execution: dict) -> dict:
    """The facts an operator validates a run by, from the execution row
    -- plus, for the Spark lane, the workload's live state on the
    cluster when that is cheaply and honestly knowable (one GET through
    the same client the reconciler polls with).  Nothing here is
    invented: a state that could not be checked says so and why."""
    fm = execution.get("files_metadata") or {}
    _chain = _recorded_delivery_chain(execution)
    out = {
        "id": execution.get("id"),
        "execution_id": execution.get("execution_id"),
        "status": execution.get("status"),
        "execution_backend": execution.get("execution_backend"),
        "external_job_id": execution.get("external_job_id"),
        "total_rows": execution.get("total_rows"),
        "file_size_bytes": execution.get("file_size_bytes"),
        "destination_path": execution.get("destination_path"),
        # 2026-10-07 -- where the produced file IS (kept whether or not it
        # was delivered) and whether it WENT: a completed run that
        # delivered nothing (backfill without delivery, dry run) must not
        # read as delivered.
        "artifact_path": execution.get("artifact_path"),
        "delivery_verdict": _chain.get("verdict"),
        "delivery_reason": _chain.get("reason"),
        "artifact_unavailable_reason": execution.get(
            "artifact_unavailable_reason"),
        "started_at": execution.get("started_at"),
        "completed_at": execution.get("completed_at"),
        "duration_seconds": execution.get("duration_seconds"),
        "trigger_type": execution.get("trigger_type"),
        "triggered_by": execution.get("triggered_by"),
        "error_message": execution.get("error_message"),
        # 2026-10-26 -- who stopped the run and when, and what the stop
        # REACHED at each source (the engine's record, core/cancel_scope.py)
        "cancelled_by": execution.get("cancelled_by"),
        "cancelled_at": execution.get("cancelled_at"),
        "cancel": fm.get("cancel") if isinstance(fm.get("cancel"), dict) else None,
        "backend_choice": fm.get("backend_choice"),
        "webhook_verification": fm.get("webhook_verification"),
        # 2026-10-14 -- WHERE the run is (phase, Spark's task counters, an
        # estimate, "no progress for N min"): core/feed/run_progress.py.
        "progress": _progress_view(execution),
        "completeness": ((fm.get("completeness_certificate") or {}).get("verdict")
                         if isinstance(fm.get("completeness_certificate"), dict)
                         else None),
    }
    backend = str(execution.get("execution_backend") or "").lower()
    job = execution.get("external_job_id")
    if backend == "spark_k8s" and job:
        from core.spark_k8s.manifest import settings_from_config
        from core.spark_k8s.runner import stored_submit_mode
        ns = settings_from_config().namespace
        mode = stored_submit_mode(execution)
        pod = _driver_pod_name(str(job), mode)
        spark = {
            "workload": job,
            # The shape the run was SUBMITTED as (stored on the row);
            # ``auto`` resolves to one of the two at submit.
            "submit_mode": mode,
            "submit_mode_declared": str(settings_from_config().submit_mode),
            "driver_pod": pod,
            "namespace": ns,
            "kubectl": f"kubectl get pod {pod} -n {ns}",
            "cluster_state": None,       # filled below when checkable
            "checked": False,
            "reason": None,
        }
        try:
            av = _spark_availability()
            if not getattr(av, "available", False):
                spark["reason"] = f"not checked: {av.describe()}"
            else:
                from core.spark_k8s.runner import SparkK8sRunner
                st = SparkK8sRunner(db, api=_kube_api(),
                                    availability_fn=lambda: av).read_status(
                    str(job), mode=mode)
                spark["checked"] = True
                if st.found:
                    spark["cluster_state"] = st.state or "(no state yet)"
                else:
                    spark["cluster_state"] = "not on the cluster"
                    spark["reason"] = ("reaped after completed_cr_ttl_seconds, "
                                       "or never created")
        except Exception as exc:                   # noqa: BLE001
            spark["reason"] = f"not checked: {type(exc).__name__}: {exc}"[:300]
        out["spark"] = spark
    return out


def _progress_view(execution: dict) -> Optional[dict]:
    from core.feed.run_progress import progress_view, stale_after_seconds
    return progress_view(execution, stale_after_seconds=stale_after_seconds())


def _steps_payload(db: Any, run: dict, execution: Optional[dict], *,
                   run_id: Optional[int]) -> dict:
    """THE answer to "what are this run's steps" -- shared by the
    run-keyed and the execution-keyed routes (2026-09-14) so the two can
    never disagree about which source they served.

    ``run_id`` None means there is no feed_run at all (a manual "Run
    Now" execution): only the projection exists, and the payload says
    why, because the dialog's standing explanation ("this run predates
    the step model") would be false for it."""
    from core.feed.steps_view import (
        TERMINAL_RUN_STATES, derive_steps, steps_from_rows,
    )

    # -- The REAL rows first (2026-09-05) ------------------------------
    # A run executed since the step model shipped has a row per step in
    # feed_run_steps: wall-clock boundaries, a record count, the pod, the
    # error, and the step's own resolved parameters.  This is the ONE
    # answer to "what are this run's steps", so it prefers them and
    # falls back only where there is nothing to prefer.
    rows: Optional[list] = []
    if run_id is not None:
        try:
            from core.feed.step_model.store import latest_attempts
            rows = latest_attempts(db, int(run_id))
        except Exception as exc:                   # noqa: BLE001
            # Could-not-read is NOT has-none.  Fall back to the
            # projection, but say so, so a caller is never told a run
            # had no steps because a query failed.
            logger.error("[feed_ops] step rows unreadable for run %s: %s",
                         run_id, exc, exc_info=True)
            rows = None
    summary = _execution_summary(db, execution) if execution else None
    decisions = _run_decisions(db, run, run_id)
    # 2026-10-03 -- ON COMPLETION OF: what STARTED this run (its upstream's
    # completion) and what this run's completion STARTED (or why not).
    on_completion = {"trigger": run_trigger(run),
                     "downstream": _downstream_record(db, run, execution)}
    if rows:
        view = steps_from_rows(run, execution, rows,
                               feed_name=run.get("feed_name"))
        return {"run_id": int(run_id), "execution": summary,
                "decisions": decisions, **on_completion, **view}

    snapshot = None
    if execution and str(run.get("status") or "") not in TERMINAL_RUN_STATES:
        try:
            from core.execution_stage import get_snapshot
            snapshot = get_snapshot(str(execution.get("execution_id") or ""))
        except Exception as exc:
            logger.debug("[feed_ops] live snapshot unavailable: %s", exc)
    view = derive_steps(run, execution, live_snapshot=snapshot,
                        feed_name=run.get("feed_name"))
    # The timing PROJECTION, and the response says so.  started_at is
    # null for every step here because durations have no boundaries; a
    # caller that cannot tell this from a recorded timeline will read a
    # projection as fact.
    view["source"] = "unavailable" if rows is None else "derived"
    if run_id is None:
        view["source_reason"] = (
            "this execution has no feed_run row (a manual Run Now runs "
            "without one), so no step rows were recorded for it; this is "
            "the stage-duration projection")
    view.setdefault("failed_step", None)
    return {"run_id": run_id, "execution": summary, "decisions": decisions,
            **on_completion, **view}


def run_trigger(run: Optional[dict]) -> Optional[dict]:
    """``{"kind": "upstream_completion", "upstream_feed_name",
    "upstream_execution_id", "upstream_feed_run_id", "text"}`` for a run
    its UPSTREAM's completion started (core/feed/upstream_completion.py),
    else None.  The sentence is built HERE, once, for every screen."""
    from core.db.models import FEED_RUN_UPSTREAM_TRIGGER
    if not run or str(run.get("triggered_by") or "") != FEED_RUN_UPSTREAM_TRIGGER:
        return None
    up = run.get("upstream_feed_name") or "its upstream feed"
    ex = run.get("upstream_execution_id")
    return {"kind": FEED_RUN_UPSTREAM_TRIGGER,
            "upstream_feed_name": run.get("upstream_feed_name"),
            "upstream_execution_id": ex,
            "upstream_feed_run_id": run.get("upstream_feed_run_id"),
            "text": (f"Started because {up} completed"
                     + (f" (execution {ex})" if ex else ""))}


def _downstream_record(db: Any, run: Optional[dict],
                       execution: Optional[dict]) -> Optional[list]:
    """The ``downstream_triggered`` / ``downstream_not_triggered`` ledger
    rows THIS run's execution produced -- ``[]`` when none (no feed is
    declared on its completion, or it has not finished), ``None`` when the
    ledger could not be read (unknown is not "none")."""
    if not run or run.get("feed_config_id") is None or not execution:
        return []
    from core.feed.upstream_completion import (
        EVENT_NOT_TRIGGERED, EVENT_TRIGGERED,
    )
    try:
        bd = _parse_bd(run.get("business_date"), where="run business_date")
        events = db.list_run_events(int(run["feed_config_id"]), business_date=bd)
    except Exception as exc:                       # noqa: BLE001
        logger.error("[feed_ops] on-completion record unreadable for run %s: %s",
                     run.get("id"), exc)
        return None
    me = str(execution.get("execution_id") or "")
    out = []
    for e in events or []:
        p = e.get("payload")
        if (e.get("event_type") in (EVENT_TRIGGERED, EVENT_NOT_TRIGGERED)
                and isinstance(p, dict)
                and str(p.get("upstream_execution_id") or "") == me):
            out.append({"event_type": e.get("event_type"),
                        "at": e.get("created_at"),
                        "reason": p.get("reason"),
                        "downstream": p.get("downstream") or [],
                        "queue_consumer": p.get("queue_consumer")})
    return out


def _run_decisions(db: Any, run: Optional[dict],
                   run_id: Optional[int]) -> Optional[list]:
    """The operator DECISIONS about this run's dependencies (2026-09-27):
    skips, a Run Now override, the WAIT escalation -- from the append-only
    ledger, stamped for this run.  ``None`` means the ledger could not be
    read (not "no decisions"); the dialog says so."""
    if not run or run.get("feed_config_id") is None:
        return []
    try:
        from core.feed.dependency_skip import decision_rows
        bd = _parse_bd(run.get("business_date"), where="run business_date")
        events = db.list_run_events(int(run["feed_config_id"]), business_date=bd)
        return decision_rows(events, feed_run_id=run_id)
    except Exception as exc:                       # noqa: BLE001
        logger.error("[feed_ops] decisions unreadable for run %s: %s",
                     run_id, exc)
        return None


#: A log line that ASSIGNS one of these a value, or carries key material, is
#: withheld from the API answer.  The job never prints its config, and the
#: manifest redacts the CLI copy; this is the belt to that brace.
_LOG_WITHHOLD = ("password", "secret_access_key", "session_token",
                 "private_key", "client_secret", "api_key")
#: 2026-09-24: this matched the WORD anywhere, so the job's own auth line --
#: ``[sftp] host authenticating: method=publickey ... source=dest_config.
#: private_key`` -- was withheld: the one line an operator reads to verify how
#: a Spark-lane SFTP delivery signed in (``kubectl logs`` showed it; the app
#: did not).  A NAME used as a label is not a secret; a name followed by a
#: VALUE is, and key material is, whatever it is labelled.
_LOG_WITHHOLD_RE = re.compile(
    r"(?:%s)[\"']?\s*[:=]" % "|".join(_LOG_WITHHOLD), re.IGNORECASE)
_LOG_KEY_MATERIAL_RE = re.compile(r"-----BEGIN|PRIVATE KEY", re.IGNORECASE)


def _withhold_log_line(line: str) -> bool:
    """True when a driver-log line could carry a credential VALUE."""
    return bool(_LOG_WITHHOLD_RE.search(line) or _LOG_KEY_MATERIAL_RE.search(line))


@router.get("/api/feed-executions/{exec_db_id}/driver-log")
async def feed_execution_driver_log(exec_db_id: int, tail: int = 400,
                                    user: dict = Depends(get_current_user)):
    """The Spark driver pod's log for one execution (2026-09-14) -- the
    story the operator otherwise reads with ``kubectl logs``.

    One ``pods/log`` GET through the same client the reconciler uses;
    the answer says when it could NOT be read (lane not spark_k8s, the
    cluster unavailable, the pod reaped) instead of an empty list."""
    db = _db()
    execution = db.get_feed_execution(int(exec_db_id))
    if not execution:
        raise HTTPException(status_code=404,
                            detail=f"feed_execution {exec_db_id} not found")
    backend = str(execution.get("execution_backend") or "").lower()
    job = execution.get("external_job_id")
    if backend != "spark_k8s" or not job:
        raise HTTPException(
            status_code=409,
            detail=f"execution ran on {backend or 'unknown'} -- there is "
                   f"no driver pod log for it")
    from core.spark_k8s.errors import SparkK8sApiError
    from core.spark_k8s.manifest import settings_from_config
    from core.spark_k8s.runner import stored_submit_mode
    ns = settings_from_config().namespace
    pod = _driver_pod_name(str(job), stored_submit_mode(execution))
    av = _spark_availability()
    if not getattr(av, "available", False):
        raise HTTPException(status_code=503,
                            detail=f"cluster not reachable from this pod: "
                                   f"{av.describe()}")
    n = max(1, min(int(tail or 400), 5000))
    try:
        text = await asyncio.to_thread(_kube_api().read_pod_log, ns, pod, n)
    except SparkK8sApiError as exc:
        if exc.status == 404:
            return {"pod": pod, "namespace": ns, "available": False,
                    "reason": "pod is not on the cluster (reaped after "
                              "completed_cr_ttl_seconds, or never created)",
                    "lines": []}
        raise HTTPException(status_code=502,
                            detail=f"cluster said no: HTTP {exc.status} {exc.reason}")
    lines = []
    for line in str(text or "").splitlines():
        if _withhold_log_line(line):
            lines.append("[line withheld: it may carry a credential value]")
        else:
            lines.append(line)
    return {"pod": pod, "namespace": ns, "available": True, "tail": n,
            "lines": lines, "kubectl": f"kubectl logs {pod} -n {ns}"}


@router.get("/api/feed-executions/{exec_db_id}/steps")
async def feed_execution_steps(exec_db_id: int,
                               user: dict = Depends(get_current_user)):
    """The step timeline of one EXECUTION (2026-09-14).

    The Feeds page lists executions, not runs, and until this route
    existed it had no way to open a step timeline: ``feed_executions``
    carries no ``feed_run_id``.  The link is the one the recorder
    stamps -- every ``feed_run_steps`` row carries its execution id --
    so an execution that ran under a feed_run gets the RECORDED rows
    (same payload as the run route, ``run_id`` filled), and one that ran
    without a feed_run (a manual Run Now) gets the projection with
    ``run_id: null`` and a ``source_reason`` saying exactly that."""
    db = _db()
    execution = db.get_feed_execution(int(exec_db_id))
    if not execution:
        raise HTTPException(status_code=404,
                            detail=f"feed_execution {exec_db_id} not found")
    run = None
    run_id: Optional[int] = None
    link_unreadable = False
    try:
        from core.feed.step_model.store import run_id_for_execution
        run_id = run_id_for_execution(
            db, str(execution.get("execution_id") or ""))
    except Exception as exc:                       # noqa: BLE001
        # Not "no run": the link could not be READ.  Serve the projection
        # and say so through source=unavailable below, never a silent
        # "derived".
        logger.error("[feed_ops] run link unreadable for execution %s: %s",
                     exec_db_id, exc, exc_info=True)
        link_unreadable = True
    if run_id is not None:
        run = db.get_feed_run(int(run_id))
        if not run:
            run_id = None                          # rows outlived their run
    if run_id is None:
        # No run: the execution row is the whole record.  Project the
        # fields derive_steps/_qualify read from a run, honestly absent
        # where the execution has nothing (a missing build renders "-").
        run = {
            "id": None,
            "feed_config_id": execution.get("feed_config_id"),
            "business_date": execution.get("business_date"),
            "build_id": execution.get("build_id"),
            "status": execution.get("status"),
            "error": execution.get("error_message"),
            "feed_name": None,
        }
    payload = _steps_payload(db, run, execution, run_id=run_id)
    if link_unreadable:
        payload["source"] = "unavailable"
        payload["source_reason"] = (
            "the execution's link to its feed_run could not be read; this "
            "is the stage-duration projection, not proof the run had no "
            "recorded steps")
    return payload


# ══════════════════════════════════════════════════════════════════════
#  5. Delivery operations (FR-DEL-02, FR-DEL-13) — 2026-09-02
#
#  core/feed/delivery_hops.py has carried retry_hop / mark_attempt_lost /
#  record_acknowledgment since Foundation M, fully tested — and NOTHING
#  in production called them.  After an SFTP outage the failed attempt
#  row sat beside a certified manifest with no way to re-send short of
#  regenerating (which mints a NEW manifest version — a different
#  delivery).  These routes are the missing producers.  The refusal
#  logic stays in the runner; the routes add identity, authority and
#  the HTTP shape.
# ══════════════════════════════════════════════════════════════════════


def _audit(action: str, user: dict, details: Optional[dict] = None) -> None:
    """Fire-and-forget durable audit row — same pattern as feed_api._audit
    (core.audit.audit_event).  The delivery attempt rows are themselves
    durable evidence (created_by / updated_by / error_message carry the
    actor and reason); this adds the searchable audit-trail entry."""
    try:
        from core.audit import audit_event
        audit_event(_db_manager, user or {}, action=action, details=details)
    except Exception:                     # pragma: no cover - audit is soft
        pass


def _require_attempt_and_feed(db: Any, attempt_id: int,
                              user: dict, *, verb: str) -> tuple:
    """The attempt row, its feed, and the authority check — shared by all
    three delivery routes.  The principal is ALWAYS the session user."""
    attempt = db.get_delivery_attempt(int(attempt_id))
    if not attempt:
        raise HTTPException(status_code=404,
                            detail=f"delivery attempt {attempt_id} not found")
    feed = db.get_feed_config(int(attempt["feed_config_id"]))
    if not feed:
        raise HTTPException(
            status_code=404,
            detail=f"feed_config {attempt['feed_config_id']} not found")
    if not _can_skip(feed, user):
        raise HTTPException(
            status_code=403,
            detail=f"Only the feed owner, a read-write group member or an "
                   f"admin can {verb} — ask one of them (acting on a "
                   f"delivery is at least as privileged as rerunning the "
                   f"feed).")
    return attempt, feed


def _attempt_business_date(attempt: dict):
    """The attempt row's business_date as a date object — a re-insert into
    the Date column must not depend on how to_dict serialised it."""
    raw = attempt.get("business_date")
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    if raw:
        try:
            return date.fromisoformat(str(raw)[:10])
        except ValueError:
            pass
    return None


def _reconstruct_manifest(db: Any, attempt: dict):
    """Rebuild the EXACT certified manifest this attempt's rows recorded.

    The manifest version is a pure function of (build_id, sql_sha256,
    part name/rows/bytes) — so it is reconstructible from the execution
    row that produced the artifact, and VERIFIABLE against the recorded
    ``manifest_version``.  The verification is load-bearing: retry_hop's
    non-idempotent guard reads history BY VERSION, so sending under a
    freshly-minted version would silently bypass it.  A mismatch means
    the artifact identity changed since the delivery was recorded (a
    regeneration) — refused, with both versions named.

    Returns (manifest, execution).
    """
    from core.feed.parts_manifest import PartInfo, PartsManifest

    build_id = str(attempt.get("build_id") or "")
    execution = (db.get_feed_execution_by_exec_id(build_id)
                 if build_id else None)
    if not execution:
        raise HTTPException(
            status_code=409,
            detail=f"delivery attempt {attempt['id']} cannot be re-sent: "
                   f"its build_id {build_id!r} resolves to no execution "
                   f"row, so the artifact it sent cannot be identified.  "
                   f"Re-run the feed instead — a regeneration mints a NEW "
                   f"manifest version and delivers that.")

    rows = int(execution.get("total_rows") or 0)
    size = int(execution.get("file_size_bytes") or 0)
    dest_path = str(execution.get("destination_path") or "")
    candidates: List[str] = []
    art_path = str(execution.get("artifact_path") or "")
    for name in (execution.get("output_filename"),
                 os.path.basename(art_path) if art_path else None,
                 os.path.basename(dest_path) if dest_path else None):
        if name and name not in candidates:
            candidates.append(str(name))
    tried: List[str] = []
    for name in candidates:
        manifest = PartsManifest(
            parts=[PartInfo(index=0, name=name, rows=rows, bytes=size,
                            location="local")],
            total_rows=rows, total_bytes=size, status="complete",
            build_id=build_id,
            sql_sha256=f"feed:{attempt['feed_config_id']}",
            completed_at=datetime.now(timezone.utc).timestamp(),
            source={"rung": "delivery_ops_reconstruction",
                    "feed_config_id": attempt["feed_config_id"]})
        version = manifest.version()
        if version == str(attempt.get("manifest_version") or ""):
            return manifest, execution
        tried.append(version)
    raise HTTPException(
        status_code=409,
        detail=f"the artifact on record no longer reproduces manifest "
               f"version {attempt.get('manifest_version')!r} (reconstructed "
               f"{tried or ['nothing']}) — the execution row's file "
               f"identity has changed since this delivery was recorded, "
               f"which is what a regeneration looks like.  A regeneration "
               f"mints a NEW manifest version: re-run the feed and deliver "
               f"that version; old bytes are never force-resent under a "
               f"changed identity.")


class DeliveryRetryBody(BaseModel):
    #: REQUIRED (non-blank) when the target is non-idempotent — re-sending
    #: a regulatory file must be an explicit, audited, reasoned act.
    reason: Optional[str] = None


@router.post("/api/delivery-attempts/{attempt_id}/retry")
async def retry_delivery_hop(attempt_id: int, body: DeliveryRetryBody,
                             user: dict = Depends(get_current_user)):
    """Re-run ONE hop of a delivery over the SAME certified manifest
    (FR-DEL-02).  Nothing is regenerated and no other hop is touched.

    The runner's own contract governs: a non-idempotent hop whose last
    attempt succeeded, or is still 'running' (outcome indeterminate), is
    REFUSED — recorded as a REFUSED attempt row, surfaced as 409 with
    what to do instead (mark-lost for indeterminacy; a re-run, which
    mints a new manifest version, for a deliberate re-send of new bytes).
    There is deliberately no force flag.
    """
    db = _db()
    attempt, feed = _require_attempt_and_feed(
        db, attempt_id, user, verb="retry this delivery hop")

    from core.feed.delivery_hops import (
        DeliveryHopRunner, DeliveryRefused, HopPlanError,
        UnknownDeliveryTarget, build_hop_plan, traits_for,
    )
    try:
        traits = traits_for(attempt.get("target_type"))
    except UnknownDeliveryTarget as exc:
        raise HTTPException(
            status_code=422,
            detail=f"{exc}.  Nothing was sent: an undeclared target's "
                   f"idempotency cannot be known, and assuming it is how a "
                   f"second regulatory file reaches a counterparty (§19 "
                   f"H1).  Declare the target's traits in "
                   f"DEFAULT_TARGET_TRAITS (core/feed/delivery_hops.py) "
                   f"before any retry.")

    reason = str(body.reason or "").strip()
    if not traits.idempotent and not reason:
        raise HTTPException(
            status_code=422,
            detail=f"target {attempt.get('target_type')!r} is NOT "
                   f"idempotent: a duplicate send is a second regulatory "
                   f"submission, so re-sending it must be an explicit, "
                   f"audited, reasoned act.  Pass a non-blank reason "
                   f"saying why a re-send is safe (e.g. 'counterparty "
                   f"confirmed nothing landed; attempt 2 marked lost "
                   f"after out-of-band check by J. Doe').")

    manifest, execution = _reconstruct_manifest(db, attempt)

    try:
        plan = build_hop_plan({**feed, "destination_config":
                               dict(feed.get("destination_config") or {})})
    except (UnknownDeliveryTarget, HopPlanError) as exc:
        raise HTTPException(
            status_code=422,
            detail=f"the feed's current delivery chain cannot be planned: "
                   f"{exc}")
    hop = next((h for h in plan if h.label == attempt.get("target")), None)
    if hop is None:
        raise HTTPException(
            status_code=409,
            detail=f"the feed's CURRENT delivery chain has no hop labelled "
                   f"{attempt.get('target')!r} (chain edited since this "
                   f"attempt?) — current hops: "
                   f"{[h.label for h in plan]}.  Nothing was sent; restore "
                   f"the hop in the feed's delivery chain or deliver via a "
                   f"fresh run.")

    from core import feed_engine as _fe
    actor = str(user.get("username") or "unknown")
    # The bytes to send are the ones the run PRODUCED (artifact_path,
    # 2026-10-07).  destination_path is where a PREVIOUS send put them --
    # empty for a suppressed backfill (the case FR-OPS-08 says is sent
    # later through exactly this route) and a remote URI for an S3/SFTP
    # hop, neither of which is a local file to send.  Legacy rows without
    # an artifact_path keep the old reading.
    output_path = str(execution.get("artifact_path")
                      or execution.get("destination_path") or "")
    filename = manifest.parts[0].name
    control_file_path = (execution.get("files_metadata")
                         or {}).get("control_file_path")
    receipt: dict = {}

    def _transport(h, _m):
        uri = _fe._deliver_data_then_control(
            output_path, filename, control_file_path,
            h.target_type, dict(h.config), 0,
            getattr(_fe._cfg, "retry_delay_seconds", 60)
            if _fe._cfg is not None else 60,
            attempt["feed_config_id"],
            str(execution.get("execution_id") or ""), _receipt=receipt)
        out = {"uri": uri,
               "verification": receipt.get("verification"),
               "verification_detail": receipt.get("verification_detail")}
        if output_path and os.path.exists(output_path):
            out["sent_path"] = output_path
        return out

    runner = DeliveryHopRunner(
        db, {hop.target_type: _transport},
        environment=_fe._deploy_environment(), actor=actor,
        suppression_policy=getattr(_fe._cfg, "delivery_suppression", None)
        if _fe._cfg is not None else None)
    try:
        outcome = await asyncio.to_thread(
            runner.retry_hop, hop, manifest,
            feed_config_id=int(attempt["feed_config_id"]),
            business_date=_attempt_business_date(attempt),
            initiated_by=actor, feed_key=feed.get("name"))
    except DeliveryRefused as exc:
        # The runner has already recorded a REFUSED attempt row where its
        # contract says to — the refusal is durable, not just an HTTP 409.
        _audit("delivery_hop_retry_refused", user, {
            "attempt_id": int(attempt_id), "target": attempt.get("target"),
            "manifest_version": attempt.get("manifest_version"),
            "reason": reason or None, "refusal": str(exc)})
        raise HTTPException(status_code=409, detail=str(exc))

    _audit("delivery_hop_retry", user, {
        "attempt_id": int(attempt_id), "new_attempt_id": outcome.attempt_id,
        "target": outcome.label, "status": outcome.status,
        "manifest_version": outcome.manifest_version,
        "reason": reason or None})
    return {
        "attempt_id": outcome.attempt_id,
        "retried_from_attempt_id": int(attempt_id),
        "label": outcome.label,
        "target_type": outcome.target_type,
        "idempotent": traits.idempotent,
        "status": outcome.status,
        "attempt": outcome.attempt,
        "manifest_version": outcome.manifest_version,
        "uri": outcome.uri,
        "error": outcome.error,
        "checksum": outcome.checksum,
        "acknowledgment": outcome.acknowledgment,
        "retried_by": actor,
        "reason": reason or None,
    }


class MarkLostBody(BaseModel):
    reason: str


@router.post("/api/delivery-attempts/{attempt_id}/mark-lost")
async def mark_delivery_attempt_lost(attempt_id: int, body: MarkLostBody,
                                     user: dict = Depends(get_current_user)):
    """A human verified OUT-OF-BAND that an in-doubt ('running') attempt
    never landed, and records that verdict with their name on it — the
    ONLY path that makes a manual retry of a non-idempotent hop possible.
    Anything not in 'running' is refused: this resolves indeterminacy,
    it does not rewrite history."""
    db = _db()
    attempt, _feed = _require_attempt_and_feed(
        db, attempt_id, user, verb="mark this delivery attempt lost")
    reason = str(body.reason or "").strip()
    if not reason:
        raise HTTPException(
            status_code=422,
            detail="reason is required and must not be blank: 'marked "
                   "lost' with no evidence is how a double delivery gets "
                   "waved through.  Say what was verified and how (e.g. "
                   "'counterparty inbox listing 09:14 shows no file; "
                   "confirmed by their ops desk').")

    from core.feed.delivery_hops import (
        DeliveryHopError, DeliveryHopRunner, DeliveryRefused,
    )
    actor = str(user.get("username") or "unknown")
    runner = DeliveryHopRunner(db, {}, environment="ops", actor=actor)
    try:
        updated = runner.mark_attempt_lost(int(attempt_id), actor=actor,
                                           reason=reason)
    except DeliveryRefused as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except DeliveryHopError as exc:      # belt: row vanished / bad input
        raise HTTPException(status_code=422, detail=str(exc))

    _audit("delivery_attempt_marked_lost", user, {
        "attempt_id": int(attempt_id), "target": attempt.get("target"),
        "manifest_version": attempt.get("manifest_version"),
        "reason": reason})
    return {
        "attempt_id": int(attempt_id),
        "status": updated.get("status"),
        "error_message": updated.get("error_message"),
        "marked_by": actor,
        "next": f"POST /api/delivery-attempts/{attempt_id}/retry (with a "
                f"reason) is now possible for this hop.",
    }


class AcknowledgmentBody(BaseModel):
    #: 'received' or 'rejected' — the states a COUNTERPARTY can assert.
    #: 'expected'/'not_required' are declarations the delivery itself makes.
    state: str
    #: who said so / the evidence — e.g. "rejected by BNP ops, malformed
    #: header, ticket INC0041".  Stored on the attempt row.
    detail: Optional[str] = None


@router.post("/api/delivery-attempts/{attempt_id}/acknowledgment")
async def record_delivery_acknowledgment(
        attempt_id: int, body: AcknowledgmentBody,
        user: dict = Depends(get_current_user)):
    """Record the counterparty's verdict (FR-DEL-13) on the LATEST
    successful delivery of this attempt's (manifest_version, target).
    The runner enforces the state machine: expected→received,
    expected→rejected, received→rejected; 'rejected' is terminal."""
    db = _db()
    attempt, _feed = _require_attempt_and_feed(
        db, attempt_id, user, verb="record an acknowledgment")

    from core.feed.delivery_hops import (
        DeliveryHopError, DeliveryHopRunner, DeliveryRefused,
    )
    actor = str(user.get("username") or "unknown")
    runner = DeliveryHopRunner(db, {}, environment="ops", actor=actor)
    try:
        updated = runner.record_acknowledgment(
            str(attempt.get("manifest_version") or ""),
            str(attempt.get("target") or ""),
            str(body.state or "").strip().lower(),
            actor=actor, detail=body.detail)
    except DeliveryRefused as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except DeliveryHopError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    _audit("delivery_acknowledgment_recorded", user, {
        "acknowledged_attempt_id": updated.get("id"),
        "via_attempt_id": int(attempt_id),
        "target": attempt.get("target"),
        "manifest_version": attempt.get("manifest_version"),
        "state": updated.get("acknowledgment"),
        "detail": body.detail})
    return {
        "acknowledged_attempt_id": updated.get("id"),
        "requested_via_attempt_id": int(attempt_id),
        "target": attempt.get("target"),
        "manifest_version": attempt.get("manifest_version"),
        "acknowledgment": updated.get("acknowledgment"),
        "acknowledged_at": str(updated.get("acknowledged_at") or ""),
        "detail": updated.get("acknowledgment_detail"),
        "recorded_by": actor,
    }


@router.get("/api/feeds/{feed_id}/delivery-attempts")
async def list_feed_delivery_attempts(
        feed_id: int,
        business_date: Optional[str] = Query(default=None),
        limit: int = Query(default=200, ge=1, le=1000),
        user: dict = Depends(get_current_user)):
    """Operator view of a feed's delivery attempts, newest first — the
    addressing surface for the three write routes above."""
    db = _db()
    feed = db.get_feed_config(int(feed_id))
    if not feed:
        raise HTTPException(status_code=404,
                            detail=f"feed_config {feed_id} not found")
    bd = (_parse_bd(business_date, where="business_date")
          if business_date is not None else None)
    rows = db.list_delivery_attempts_for_feed(int(feed_id), bd,
                                              limit=int(limit)) or []
    return {"feed_id": int(feed_id),
            "business_date": bd.isoformat() if bd else None,
            "attempts": rows, "count": len(rows)}


# ══════════════════════════════════════════════════════════════════════
#  6. Child file-runs — "re-run file 738" (FR-RUN-02) — 2026-09-02
#
#  feed_file_runs is keyed (feed_run_id, partition_key) and the DAO has
#  had reset_feed_file_run_to_pending since Foundation P with ZERO
#  production callers — a 1,000-file feed with one failed child forced
#  the operator to re-run the whole feed.  execute_children picks ONLY
#  status='pending' children, so the reset is exactly the missing piece:
#  reset → POST /api/feed-runs/{id}/rerun → only those partitions re-run.
#  The parent's status is DERIVED (fanout.recompute_parent) and is never
#  written here.
# ══════════════════════════════════════════════════════════════════════


@router.get("/api/feed-runs/{run_id}/files")
async def list_feed_run_files(run_id: int,
                              status: Optional[str] = Query(default=None),
                              user: dict = Depends(get_current_user)):
    """A run's children with their per-partition verdicts and evidence."""
    db = _db()
    run = await _require_run_view(db, int(run_id), user)
    children = db.list_feed_file_runs(int(run_id), status=status) or []
    counts = db.feed_file_run_status_counts(int(run_id)) or {}
    return {"run_id": int(run_id), "parent_status": run.get("status"),
            "children": children, "count": len(children),
            "status_counts": counts}


class FileRunResetBody(BaseModel):
    #: None = every FAILED child.  To reset a completed/cancelled child
    #: (re-produce a part that already exists) it must be NAMED — a
    #: blanket reset must never silently redo finished work.
    partition_keys: Optional[List[str]] = None
    reason: Optional[str] = None


@router.post("/api/feed-runs/{run_id}/files/reset")
async def reset_feed_run_files(run_id: int, body: FileRunResetBody,
                               user: dict = Depends(get_current_user)):
    """Reset chosen children to 'pending' so the parent re-run repairs
    exactly them.  Per-item outcomes, never one aggregate verdict: a
    response that said 'done' while one child was racing a worker would
    hide exactly what the operator needed to see."""
    db = _db()
    run = db.get_feed_run(int(run_id))
    if not run:
        raise HTTPException(status_code=404,
                            detail=f"feed_run {run_id} not found")
    feed = db.get_feed_config(int(run["feed_config_id"]))
    if not feed:
        raise HTTPException(
            status_code=404,
            detail=f"feed_config {run['feed_config_id']} not found")
    if not _can_skip(feed, user):
        raise HTTPException(
            status_code=403,
            detail="Only the feed owner, a read-write group member or an "
                   "admin can reset this run's children — ask one of them "
                   "(a reset re-executes work, so it is at least as "
                   "privileged as rerunning).")

    children = db.list_feed_file_runs(int(run_id)) or []
    if not children:
        raise HTTPException(
            status_code=409,
            detail=f"feed_run {run_id} has no per-file children — it is "
                   f"not a fan-out run (or its partition declaration was "
                   f"never recorded).  To execute the run again use POST "
                   f"/api/feed-runs/{run_id}/rerun.")
    by_key = {str(c.get("partition_key")): c for c in children}

    if body.partition_keys is None:
        keys = [k for k, c in by_key.items()
                if str(c.get("status")) == "failed"]
        if not keys:
            raise HTTPException(
                status_code=409,
                detail=f"feed_run {run_id} has no FAILED children — "
                       f"nothing was reset.  To re-produce a completed or "
                       f"cancelled partition, name it explicitly in "
                       f"partition_keys; a blanket reset never silently "
                       f"redoes finished work.")
    else:
        keys = [str(k).strip() for k in body.partition_keys
                if str(k).strip()]
        if not keys:
            raise HTTPException(
                status_code=422,
                detail="partition_keys was an empty list, which would "
                       "reset nothing — pass null to reset every failed "
                       "child, or name the partitions to reset.")
        unknown = [k for k in keys if k not in by_key]
        if unknown:
            sample = sorted(by_key)[:20]
            raise HTTPException(
                status_code=422,
                detail=f"not children of feed_run {run_id}: {unknown}.  "
                       f"Known partition_keys (first {len(sample)} of "
                       f"{len(by_key)}): {sample}.  Check the spelling — "
                       f"a typo must not silently reset nothing and "
                       f"report success.")

    from core.db.models import FEED_FILE_RUN_TERMINAL_STATUSES
    actor = str(user.get("username") or "unknown")
    reason = str(body.reason or "").strip() or None
    outcomes: List[dict] = []
    for key in keys:
        child = by_key[key]
        status = str(child.get("status"))
        if status not in FEED_FILE_RUN_TERMINAL_STATUSES:
            outcomes.append({
                "partition_key": key, "outcome": "refused_not_terminal",
                "status": status,
                "detail": f"child is {status!r} — already on its way; "
                          f"resetting it would race the worker that owns "
                          f"it.  Wait for it to finish (or for the orphan "
                          f"reaper to reclaim it), then reset."})
            continue
        ok = db.reset_feed_file_run_to_pending(int(run_id), key,
                                               requested_by=actor)
        if ok:
            outcomes.append({"partition_key": key, "outcome": "reset",
                             "previous_status": status})
        else:
            outcomes.append({
                "partition_key": key, "outcome": "lost_race",
                "status": status,
                "detail": "the row left its terminal state between read "
                          "and reset (a worker or the reaper acted) — "
                          "nothing was changed for this partition; re-read "
                          f"GET /api/feed-runs/{run_id}/files."})

    reset_count = sum(1 for o in outcomes if o["outcome"] == "reset")
    _audit("feed_file_runs_reset", user, {
        "feed_run_id": int(run_id), "feed_config_id": feed.get("id"),
        "requested": keys, "reset_count": reset_count,
        "outcomes": outcomes, "reason": reason})
    return {
        "run_id": int(run_id),
        "outcomes": outcomes,
        "reset_count": reset_count,
        "refused_count": len(outcomes) - reset_count,
        "requested_by": actor,
        "reason": reason,
        "parent_status": run.get("status"),
        "next": f"POST /api/feed-runs/{run_id}/rerun — the re-run "
                f"executes ONLY status='pending' children, so exactly the "
                f"reset partitions run again; the parent's status stays "
                f"DERIVED from its children (never written here).",
    }


# ══════════════════════════════════════════════════════════════════════
#  7. Connection concurrency budgets (FR-OPS-11) — 2026-09-02
#
#  upsert_connection_concurrency_budget had only test callers, so no
#  budget row could exist in production: every connection was unbounded
#  and the reserved-slot mechanism unreachable.  The BRD names "raise a
#  connection budget without a deployment" as an operator control —
#  these are its routes.  Semantics are the DAO's, restated to the
#  operator: no row = UNBOUNDED; max_concurrent_runs=0 = PAUSED (zero
#  slots), NEVER unlimited.
# ══════════════════════════════════════════════════════════════════════


def _require_connection(db: Any, connection_id: int) -> dict:
    conn = db.get_connection(int(connection_id))
    if not conn:
        raise HTTPException(
            status_code=404,
            detail=f"connection {connection_id} not found")
    return conn


@router.get("/api/connections/{connection_id}/concurrency-budget")
async def get_connection_budget(connection_id: int,
                                user: dict = Depends(require_admin)):
    db = _db()
    conn = _require_connection(db, connection_id)
    budget = db.get_connection_concurrency_budget(int(connection_id))
    return {
        "connection_id": int(connection_id),
        "connection_name": conn.get("name"),
        "budget": budget,
        "unbounded": budget is None,
        "paused": bool(budget
                       and int(budget.get("max_concurrent_runs") or 0) == 0),
        "semantics": "no budget row = unbounded; max_concurrent_runs=0 = "
                     "PAUSED (zero slots), never unlimited; "
                     "reserved_critical_slots are usable only by critical "
                     "runs (FR-OPS-11).",
    }


@router.get("/api/feeds/legacy-fallback-security-audit")
async def get_legacy_fallback_security_audit(
        user: dict = Depends(require_admin)):
    """Which feeds would ship a side the backend cannot secure.

    2026-09-05.  The Airflow lane now REFUSES a feed whose legacy conf
    ships a side as a source REFERENCE rather than SQL text -- the
    detached job resolves and executes it itself, so no rewrite of ours
    can reach it.  Refusing is right, and a refusal an operator first
    meets at 3am on a scheduled run is not.

    ``audit_legacy_fallback_security`` answers it BEFORE that happens,
    and both refusal messages name this route by its METHOD AND PATH
    (``core.feed.airflow_plan.AUDIT_ROUTE``, the one declaration they
    and this docstring share).  A tool an operator is told to use has to
    be reachable: a function callable only from a Python REPL is not an
    answer, it is a footnote -- and until 2026-09-05 the sentence that
    named it told the operator to call ``db.get_feed_configs()``, a
    method that does not exist.

    TWO REASONS, NAMED APART.  ``_execute_airflow`` refuses on a plan
    crash in two places and they need different fixes, so every row
    carries ``refuse_because``: ``cross_source`` (the feed has a
    ``secondary_connection_id``, so the crash refuses unconditionally --
    adding SQL text will NOT help) or ``unsecurable_sides`` (a side
    ships as a source reference with no SQL text -- an explicit
    ``query_params.sql`` will).  Reporting only the second, as this did
    when it shipped, under-reported the population the route exists to
    predict.

    UNKNOWN IS NOT NONE.  An audit that cannot be computed says so; it
    never returns an empty list, which would read as "no feed is
    affected" -- the opposite conclusion, from the same 200.
    """
    from core.feed.airflow_plan import (
        AUDIT_ROUTE, REFUSE_CROSS_SOURCE, REFUSE_UNSECURABLE_SIDES,
        audit_legacy_fallback_security,
    )
    db = _db()
    try:
        feeds = db.list_feed_configs()
    except Exception as exc:                    # noqa: BLE001
        raise HTTPException(
            status_code=503,
            detail=f"Could not read the feed configs to audit them "
                   f"({exc}). This is NOT 'no feed is affected'.")
    rows = audit_legacy_fallback_security(feeds)
    by_reason = {REFUSE_CROSS_SOURCE: 0, REFUSE_UNSECURABLE_SIDES: 0}
    for r in rows:
        by_reason[r["refuse_because"]] = by_reason.get(
            r["refuse_because"], 0) + 1
    return {
        "affected": rows,
        "count": len(rows),
        "counts_by_reason": by_reason,
        "route": AUDIT_ROUTE,
        "scope": "feeds that can reach the Airflow lane "
                 "(execution_backend airflow / auto / unset)",
        "semantics": "each row names the feed, WHY it would refuse "
                     "(refuse_because: 'cross_source' = it has a "
                     "secondary_connection_id and refuses regardless of "
                     "SQL text; 'unsecurable_sides' = a side ships as a "
                     "source reference with no SQL text) and WHICH sides "
                     "the classifier could not secure. On a cross_source "
                     "row an EMPTY unsecured_sides does not mean the feed "
                     "is fine -- it means the classifier had no complaint "
                     "and the feed refuses anyway. An empty affected list "
                     "means the audit ran and found none -- a failure to "
                     "run answers 503.",
    }


class ConnectionBudgetBody(BaseModel):
    max_concurrent_runs: int
    reserved_critical_slots: int = 0


@router.put("/api/connections/{connection_id}/concurrency-budget")
async def set_connection_budget(connection_id: int,
                                body: ConnectionBudgetBody,
                                user: dict = Depends(require_admin)):
    """Declare (or change) a connection's concurrency allowance — the
    operator control the reserved-slot machinery has waited on.  The
    DAO refuses impossible shapes (negative, reservation > budget) with
    the numbers; the DB CHECK constraint behind it surfaces as the same
    clean 422, never a 500."""
    db = _db()
    _require_connection(db, connection_id)
    actor = str(user.get("username") or "unknown")
    try:
        row = db.upsert_connection_concurrency_budget(
            int(connection_id),
            max_concurrent_runs=int(body.max_concurrent_runs),
            reserved_critical_slots=int(body.reserved_critical_slots),
            updated_by=actor)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        # The DB CHECK constraints (ck_ccb_*) are the backstop behind the
        # DAO's pre-checks; if one fires anyway (schema drift, race), the
        # operator gets the numbers, not a 500.
        try:
            from sqlalchemy.exc import IntegrityError
        except ImportError:              # pragma: no cover
            raise
        if isinstance(exc, IntegrityError):
            raise HTTPException(
                status_code=422,
                detail=f"the database refused this budget "
                       f"(max_concurrent_runs="
                       f"{body.max_concurrent_runs}, "
                       f"reserved_critical_slots="
                       f"{body.reserved_critical_slots}): {exc.orig}.  "
                       f"Slots must be >= 0 and the reservation must not "
                       f"exceed the budget.")
        raise

    _audit("connection_budget_set", user, {
        "connection_id": int(connection_id),
        "max_concurrent_runs": int(body.max_concurrent_runs),
        "reserved_critical_slots": int(body.reserved_critical_slots)})
    return {
        "connection_id": int(connection_id),
        "budget": row,
        "paused": int(row.get("max_concurrent_runs") or 0) == 0,
        "set_by": actor,
    }
# ══════════════════════════════════════════════════════════════════════
#  8. Backfill (FR-OPS-06..09, 2026-09-02)
# ══════════════════════════════════════════════════════════════════════
#
# "Re-run last month" was ~20 hand-fired re-runs, each of which
# DELIVERED.  These two endpoints replace that: a calendar-aware,
# ordered, concurrency-classed batch whose delivery is OFF by default
# (turning it on is an explicit, audited choice — FR-OPS-08 calls
# re-delivering a month of files the serious incident this prevents).
# The planner/launcher live in core/feed/sod_generator.py (the same
# per-date machinery SOD uses); the priority vocabulary comes from
# core/feed/claims.py (backfills enter at the least important level and
# can never become critical).


class BackfillBody(BaseModel):
    start_date: str                       # ISO YYYY-MM-DD, inclusive
    end_date: str                         # ISO YYYY-MM-DD, inclusive
    #: 'oldest_first' (default) or 'newest_first' — the EXECUTION order.
    order: str = "oldest_first"
    #: FR-OPS-08 — delivery is OFF by default.  True requires a reason
    #: and writes a dedicated audit event.
    deliver: bool = False
    #: Required when deliver=True; recorded in the audit trail.
    reason: Optional[str] = None
    #: Optional priority 1-9 (1 = highest).  Whatever is typed is
    #: clamped so a backfill can never be critical; omitted = the
    #: backfill default (9, the least important level).
    priority: Optional[int] = None


def _backfill_generator(db: Any):
    from core.feed.sod_generator import SodTaskGenerator
    return SodTaskGenerator(db)


def _backfill_guards(db: Any, feed_id: int, body: BackfillBody,
                     user: dict) -> tuple:
    """Shared preview/launch validation.  Returns (feed, start, end)."""
    feed = db.get_feed_config(int(feed_id))
    if not feed:
        raise HTTPException(status_code=404,
                            detail=f"feed {feed_id} not found")
    if not _can_skip(feed, user):
        raise HTTPException(
            status_code=403,
            detail="backfilling re-runs this feed — it needs the same "
                   "owner / read-write group / admin permission as a "
                   "re-run.")
    # 2026-09-25 (Docker E2E audit): an INACTIVE feed was backfilled with a
    # 200 -- three pending runs created, and the queue worker failed every
    # one with "Feed config N is inactive".  Run Now already refuses an
    # inactive feed; the backfill says so BEFORE it creates anything (the
    # preview too, so the dialog shows it before Launch is offered).
    if not feed.get("is_active", True):
        raise HTTPException(
            status_code=409,
            detail=(f"Feed '{feed.get('name') or feed_id}' is inactive, so every "
                    "backfilled run would fail. Activate it first (a new or "
                    "cloned feed goes live through Lifecycle: PII declaration, "
                    "acceptance run, sign-off)."))
    start = _parse_bd(body.start_date, where="start_date")
    end = _parse_bd(body.end_date, where="end_date")
    if body.deliver:
        # The audited override: producing AND delivering a backfill is
        # the choice FR-OPS-08 exists to make explicit — an unexplained
        # one is unauditable a year on.
        _delivery_override_reason(body.reason)
    if body.priority is not None:
        from core.feed.claims import validate_priority
        try:
            validate_priority(body.priority, where="priority")
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
    return feed, start, end


@router.post("/api/feeds/{feed_id}/backfill/preview")
async def preview_feed_backfill(feed_id: int, body: BackfillBody,
                                user: dict = Depends(get_current_user)):
    """FR-OPS-09 — say exactly which dates WILL run before running them:
    per-date verdicts (will_run / non_business_day / condition_skip /
    outside_validity_window / already_active) in the declared execution
    order.  Writes nothing."""
    db = _db()
    _feed, start, end = _backfill_guards(db, feed_id, body, user)
    try:
        plan = _backfill_generator(db).plan_backfill(
            int(feed_id), start, end, order=body.order)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    plan["deliver"] = bool(body.deliver)
    plan["suppress_delivery"] = not body.deliver
    return plan


@router.post("/api/feeds/{feed_id}/backfill")
async def launch_feed_backfill(feed_id: int, body: BackfillBody,
                               override_deployment_window: bool = Query(
                                   default=False),
                               user: dict = Depends(get_current_user)):
    """FR-OPS-06/07/08 — launch the backfill the preview described.

    The launch re-computes the SAME plan (launch = preview + row
    creation, so the two cannot drift) and reports PER-ITEM outcomes —
    never one aggregate "done".  Every created run:
      * is run_type='backfill' with a shared batch id;
      * has suppress_delivery set unless deliver=true was explicitly
        (and auditedly) requested — the file is produced, the delivery
        hop rows are written as SUPPRESSED, and an operator hop retry
        is the deliberate path to sending one later;
      * enters at the backfill concurrency class (least important
        priority, clamped so it can NEVER take a reserved critical
        slot or outrank scheduled work of equal age).
    """
    db = _db()
    _feed, start, end = _backfill_guards(db, feed_id, body, user)
    actor = str(user.get("username") or "unknown")
    # FR-OPS-04 — a backfill STARTS runs, so an active deployment window
    # refuses it like every other start path.  The PREVIEW stays open (it
    # writes nothing).  Admin override is audited.
    from core.feed.deployment_window import (
        blocking_window_for_feed, record_refusal, refusal_detail,
    )
    try:
        _win = await asyncio.to_thread(blocking_window_for_feed, db, _feed)
    except Exception as _exc:
        # Fail OPEN, loudly — same posture as feed_api's gate: an
        # unreadable settings row must not stop the estate; a genuine
        # window still blocks below.
        logger.error(
            "[feed_ops] deployment windows could not be read before "
            "backfilling feed %s (%s) — window NOT ENFORCED for this "
            "launch (fail-open)", feed_id, _exc)
        _audit("deployment_window_unenforced", user, {
            "feed_id": int(feed_id), "action": "backfill",
            "error": str(_exc),
        })
        _win = None
    if _win is not None:
        from core.roles import is_admin_like
        if override_deployment_window and is_admin_like(user):
            _audit("deployment_window_overridden", user, {
                "window_id": _win.get("id"), "feed_id": int(feed_id),
                "action": "backfill",
            })
        else:
            await asyncio.to_thread(
                record_refusal, db, _win.get("id"),
                feed_id=int(feed_id), actor=actor, action="backfill")
            if override_deployment_window:
                raise HTTPException(
                    status_code=403,
                    detail="Only an admin may override a deployment "
                           "window.  " + refusal_detail(_win, feed=_feed))
            raise HTTPException(status_code=409,
                                detail=refusal_detail(_win, feed=_feed))
    try:
        result = _backfill_generator(db).run_backfill(
            int(feed_id), start, end, order=body.order,
            deliver=bool(body.deliver), priority=body.priority,
            requested_by=actor)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    # 2026-09-15 — a backfill is a PRODUCER.  It inserts pending
    # feed_runs rows and the only thing that executes one is a queue
    # worker, which ships OFF (feed_generation.queue_worker_enabled
    # defaults to false).  The route used to answer 200 {"created": 20}
    # and write an audit entry with no hint that twenty rows had just
    # been parked where nothing would ever pick them up.  It now says
    # so, in the response, in the log and in the audit trail.  It does
    # NOT refuse: creating the rows is still the right thing (enable a
    # worker and they run), and refusing would break the deployment
    # that starts its feed_worker pod after queueing the work.
    created = int((result.get("summary") or {}).get("created") or 0)
    consumer = None
    if created > 0:
        try:
            from core.feed.health import probe_queue_consumer
            presence = await asyncio.to_thread(probe_queue_consumer, None, db=db)
            consumer = presence.to_dict()
            if presence.determined and not presence.present:
                logger.warning(
                    "[feed_ops] backfill of feed %s created %d pending run(s) "
                    "but NOTHING WILL EXECUTE THEM — %s",
                    feed_id, created, presence.reason)
            elif not presence.determined:
                logger.warning(
                    "[feed_ops] backfill of feed %s created %d pending run(s); "
                    "could not confirm a consumer exists — %s",
                    feed_id, created, presence.reason)
        except Exception as _cexc:   # never fail a launch on a probe
            logger.warning("[feed_ops] consumer probe failed after backfill "
                           "of feed %s: %s", feed_id, _cexc)
            consumer = None
    if consumer is not None:
        result["consumer"] = consumer
        if not consumer.get("present"):
            result["warning"] = consumer.get("reason")
    _audit("feed_backfill_launched", user, {
        "feed_id": int(feed_id),
        "batch_id": result.get("batch_id"),
        "start_date": start.isoformat(),
        "end_date": end.isoformat(),
        "order": body.order,
        "deliver": bool(body.deliver),
        "created": (result.get("summary") or {}).get("created"),
        "errors": (result.get("summary") or {}).get("errors"),
        # "who backfilled twenty days into a deployment with no worker"
        # must be one query against the audit trail, not an inference.
        "consumer_present": (consumer or {}).get("present"),
        "consumer_reason": (consumer or {}).get("reason"),
    })
    if body.deliver:
        # The override gets its OWN audit event — "who turned delivery
        # on for a backfill, when, and why" must be one query, not an
        # inference from launch parameters.
        _audit("feed_backfill_delivery_enabled", user, {
            "feed_id": int(feed_id),
            "batch_id": result.get("batch_id"),
            "start_date": start.isoformat(),
            "end_date": end.isoformat(),
            "reason": _delivery_override_reason(body.reason),
        })
    return result


# ══════════════════════════════════════════════════════════════════════
#  Deployment windows (FR-OPS-04) — "do not START runs during the
#  change window".  Semantics live in core/feed/deployment_window.py:
#  a window blocks STARTS only, never touches a run in flight (H1).
# ══════════════════════════════════════════════════════════════════════

class DeploymentWindowBody(BaseModel):
    scope: str                            # global | group | feed
    scope_id: Optional[int] = None        # required for group/feed
    starts_at: str                        # ISO datetime (naive = UTC)
    ends_at: str
    reason: str


@router.get("/api/deployment-windows")
async def list_deployment_windows(user: dict = Depends(get_current_user)):
    """Every stored window — readable by ANY authenticated user, because
    the operator whose run was refused needs to see why without asking
    an admin first."""
    from core.feed.deployment_window import list_windows, surface_rows
    db = _db()
    return {
        "windows": await asyncio.to_thread(list_windows, db),
        "active_or_upcoming": await asyncio.to_thread(surface_rows, db),
    }


@router.post("/api/admin/deployment-windows", status_code=201)
async def create_deployment_window(body: DeploymentWindowBody,
                                   user: dict = Depends(require_admin)):
    """Declare a change window.  422 with the fix named on any bad
    shape (scope without scope_id, end before start, window already
    past, blank reason)."""
    from core.feed.deployment_window import create_window
    db = _db()
    # A group/feed-scoped window must point at something that EXISTS —
    # a typo'd id would store a window that matches nothing and the
    # operator would believe the change window is in force.
    if body.scope == "feed" and body.scope_id is not None:
        if not await asyncio.to_thread(db.get_feed_config,
                                       int(body.scope_id)):
            raise HTTPException(
                status_code=422,
                detail=f"scope=feed but feed {body.scope_id} does not "
                       f"exist — the window would match nothing while "
                       f"reading as if the change window were in force")
    if body.scope == "group" and body.scope_id is not None:
        if not await asyncio.to_thread(db.get_feed_group,
                                       int(body.scope_id)):
            raise HTTPException(
                status_code=422,
                detail=f"scope=group but feed group {body.scope_id} "
                       f"does not exist — the window would match "
                       f"nothing while reading as if the change window "
                       f"were in force")
    try:
        win = await asyncio.to_thread(
            create_window, db, scope=body.scope, scope_id=body.scope_id,
            starts_at=body.starts_at, ends_at=body.ends_at,
            reason=body.reason,
            created_by=str(user.get("username") or "unknown"))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    _audit("deployment_window_created", user, {
        "window_id": win["id"], "scope": win["scope"],
        "scope_id": win["scope_id"], "starts_at": win["starts_at"],
        "ends_at": win["ends_at"], "reason": win["reason"],
    })
    return win


@router.delete("/api/admin/deployment-windows/{window_id}")
async def delete_deployment_window(window_id: str,
                                   user: dict = Depends(require_admin)):
    from core.feed.deployment_window import delete_window
    db = _db()
    ok = await asyncio.to_thread(
        delete_window, db, window_id,
        str(user.get("username") or "unknown"))
    if not ok:
        raise HTTPException(
            status_code=404,
            detail=f"deployment window {window_id!r} not found — "
                   f"GET /api/deployment-windows lists the stored ones")
    _audit("deployment_window_deleted", user, {"window_id": window_id})
    return {"detail": "Deployment window deleted", "window_id": window_id}


# ══════════════════════════════════════════════════════════════════════
#  Service review (FR-OPS-17) — read-only; core/feed/service_review.py
# ══════════════════════════════════════════════════════════════════════

@router.get("/api/service-review")
async def get_service_review(
    days: int = Query(default=28, ge=1, le=366),
    user: dict = Depends(get_current_user),
):
    """The monthly service-review surface: success rate by feed group,
    trending-slower feeds, chronically-late dependencies, skip counts.

    Admin or support only (same posture as require_admin_read): it
    aggregates across the WHOLE estate, including feeds the caller
    could not view individually.  Sections degrade independently and
    the response NAMES the unavailable ones — an empty section because
    a query failed must never read as "nothing to report".
    """
    from api.deps import require_admin_read
    # Reuse the canonical admin-or-support gate rather than a second
    # spelling of it (it already handles auth-disabled correctly).
    require_admin_read(user)
    from core.feed.service_review import build_review
    db = _db()
    review = await asyncio.to_thread(build_review, db, days=int(days))
    if review.get("unavailable_sections"):
        logger.warning(
            "[service_review] served with %d unavailable section(s): %s",
            len(review["unavailable_sections"]),
            ", ".join(review["unavailable_sections"]))
    return review


# ── FR-DEP-10/18/20 — regeneration decisions (routes wired 2026-09-03) ──────
#
# ``on_replay_detected`` has OPENED these decisions since the ledger was
# built.  Nothing could list them and nothing could close them:
# ``resolve_decision`` and ``enumerate_downstream_feeds`` had no callers
# anywhere, so a late-arriving replay raised a decision that sat in the
# table forever, invisible to the operator it was raised FOR.
#
# An open loop is worse than no loop: the system recorded that a human
# judgement was required, told nobody, and carried on.


class RegenerationResolutionBody(BaseModel):
    """Closing a decision needs the two things audit asks for a year
    later: WHAT was decided and WHY.  ``resolve_decision`` refuses a
    blank actor or reason — an unexplained resolution is an unanswerable
    audit row."""

    resolution: str
    reason: str


@router.get("/api/feed-regeneration-decisions")
async def list_regeneration_decisions(
    feed_config_id: Optional[int] = None,
    business_date: Optional[str] = None,
    status: Optional[str] = "open",
    dependency_name: Optional[str] = None,
    limit: int = Query(200, ge=1, le=1000),
    user=Depends(get_current_user),
):
    """Decisions awaiting a human, newest first.

    ``status`` defaults to ``open`` because that is the operator's
    question — "what is waiting on me?".  Pass ``status=`` (empty) for
    every decision including the closed ones, which is the auditor's
    question.
    """
    from api.deps import require_admin_read
    require_admin_read(user)
    db = _db()
    rows = await asyncio.to_thread(
        db.list_regeneration_decisions,
        feed_config_id=feed_config_id,
        business_date=business_date or None,
        status=(status or None),
        dependency_name=dependency_name or None,
        limit=int(limit))
    return {"decisions": rows, "count": len(rows),
            "status_filter": status or "all"}


@router.get("/api/feed-regeneration-decisions/{decision_id}")
async def get_regeneration_decision(decision_id: int,
                                    user=Depends(get_current_user)):
    from api.deps import require_admin_read
    require_admin_read(user)
    row = await asyncio.to_thread(_db().get_regeneration_decision,
                                  int(decision_id))
    if not row:
        raise HTTPException(status_code=404,
                            detail=f"regeneration decision {decision_id} "
                                   f"not found")
    return row


@router.post("/api/feed-regeneration-decisions/{decision_id}/resolve")
async def resolve_regeneration_decision(
    decision_id: int,
    body: RegenerationResolutionBody,
    user=Depends(get_current_user),
):
    """Close one decision, naming the person and the reason.

    Deliberately does NOT re-run the feed.  ``regeneration.py`` says so
    in its own module docstring — resolving with ``regenerate`` RECORDS
    the judgement; executing it is the trigger paths' job, which read
    this record.  Doing both here would make one click both an audit
    entry and an estate action, and an operator correcting a mistyped
    resolution would ship a file.

    A decision is decided ONCE: the DAO only flips rows still ``open``,
    so a second resolver gets a 409 and must read the first answer
    rather than overwrite it.
    """
    from core.feed.regeneration import resolve_decision
    db = _db()
    existing = await asyncio.to_thread(db.get_regeneration_decision,
                                       int(decision_id))
    if not existing:
        raise HTTPException(status_code=404,
                            detail=f"regeneration decision {decision_id} "
                                   f"not found")
    feed = db.get_feed_config(int(existing["feed_config_id"])) \
        if existing.get("feed_config_id") else None
    # Same gate as a skip: deciding NOT to regenerate leaves a
    # counterparty holding data known to be superseded, which is at
    # least as privileged as re-running.
    if feed is not None and not _can_skip(feed, user):
        raise HTTPException(
            status_code=403,
            detail="Only the feed owner, a read-write group member or an "
                   "admin can resolve a regeneration decision for this feed")
    try:
        row = await asyncio.to_thread(
            resolve_decision, db, int(decision_id),
            resolution=str(body.resolution),
            actor=str(user.get("username") or ""),
            reason=str(body.reason or ""))
    except ValueError as exc:
        # Every refusal from the module is a 4xx: an unknown resolution,
        # a blank actor or reason, or a decision already closed.
        detail = str(exc)
        code = 409 if "already resolved" in detail.lower() else 422
        raise HTTPException(status_code=code, detail=detail)
    logger.info("[feed_ops] regeneration decision %s resolved %r by %s",
                decision_id, body.resolution, user.get("username"))
    return row


@router.get("/api/feeds/{feed_name}/downstream")
async def list_downstream_feeds(feed_name: str,
                                user=Depends(get_current_user)):
    """FR-DEP-18 — what a regeneration of this feed would cascade to.

    The question an operator has to answer BEFORE resolving a decision
    with ``regenerate``: re-running this feed makes new data that every
    ``on_completion_of`` dependant consumed the old version of.  It was
    computable all along (``enumerate_downstream_feeds``, transitive and
    cycle-guarded) and reachable from nothing.

    Advisory by construction: enumeration failure returns an EMPTY
    cascade with the failure stated, never a 500 — but an empty list and
    an unreadable one must not look alike to the caller, hence the
    explicit ``enumerated`` flag.
    """
    from api.deps import require_admin_read
    require_admin_read(user)
    from core.feed.regeneration import enumerate_downstream_feeds
    try:
        rows = await asyncio.to_thread(enumerate_downstream_feeds,
                                       _db(), str(feed_name))
        return {"feed": feed_name, "downstream": rows,
                "count": len(rows), "enumerated": True}
    except Exception as exc:      # pragma: no cover — the module logs too
        logger.error("[feed_ops] downstream enumeration failed for %r: %s",
                     feed_name, exc)
        return {"feed": feed_name, "downstream": [], "count": 0,
                "enumerated": False,
                "note": f"the cascade could not be read: {exc}"}
