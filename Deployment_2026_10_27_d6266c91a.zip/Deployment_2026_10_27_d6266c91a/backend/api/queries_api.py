"""
Query management, file operations, downloads, executions, and sharing endpoints.
Extracted from main.py (Phase 29 enterprise refactoring).
"""

from __future__ import annotations

import asyncio
import os
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any, Union
from fastapi import APIRouter, HTTPException, Depends, Request, File, UploadFile
from fastapi import Query as FastQuery
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, model_validator
from api.deps import (get_current_user, require_role, is_owner_or_shared,
                      get_workspace_id, require_execution_read_access)
from core.audit import audit_event
from core.error_sanitizer import sanitize_error
from core.json_utils import sanitize_for_json
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter(tags=["queries"])


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# ── Module-level singletons — populated by set_query_dependencies() at startup ──
_db_manager  = None
_engine      = None
_conn_manager = None
_paths       = None
_auth_cfg    = None
_qe_cfg      = None
_limits_cfg  = None
_features_cfg = None
_ws_manager  = None

_MAX_UPLOAD_SIZE = None
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}


def set_query_dependencies(db_manager, engine, conn_manager, paths, auth_cfg,
                           qe_cfg, limits_cfg, features_cfg, ws_manager=None):
    """Called once from main.py startup after all components are created."""
    global _db_manager, _engine, _conn_manager, _paths, _auth_cfg
    global _qe_cfg, _limits_cfg, _features_cfg, _ws_manager, _MAX_UPLOAD_SIZE
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _paths        = paths
    _auth_cfg     = auth_cfg
    _qe_cfg       = qe_cfg
    _limits_cfg   = limits_cfg
    _features_cfg = features_cfg
    _ws_manager   = ws_manager
    _MAX_UPLOAD_SIZE = limits_cfg.max_upload_size_bytes


# ── Pydantic models ────────────────────────────────────────────────────────────

_ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle|athena|rest_api)$"


class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")
    value: Any = None  # None for is_null / is_not_null


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


# 2026-08-23 — TWIN KILLED.  This module carried its OWN QueryConfigModel,
# so every schema fix made to the canonical ``api/models/query_models.py``
# silently DID NOT APPLY to the main save route: POST /api/queries and
# PUT /api/queries/{id} validated through THIS twin, and Pydantic dropped
# every undeclared field on ``model_dump()``.  Concretely lost at save:
#   * ``raw_sql`` — the user's SQL-mode text (BQB buildQueryConfig writes
#     it; consumers such as feed_sql_resolver, published views and
#     datasets-from-saved-query PREFER it) — silently rebuilt from the
#     visual state instead;
#   * the Phase 154 cross-connection fields (secondary_connection_id /
#     secondary_query_config / secondary_raw_sql / combine_mode /
#     join_config) — the Phase 154 commit declared them on the CANONICAL
#     model and this twin kept stripping them here anyway;
#   * ``FilterModel.data_type`` (2026-08-19 typed-literal fix) — saved
#     filters lost their declared type, so Starburst date filters compared
#     date = varchar again after a save/load round-trip.
# ONE model, imported.  Never a second definition.
from api.models.query_models import QueryConfigModel, QueryConfigRequestModel  # noqa: E402


def _fold_connection_into_config(connection_id, query_config):
    """ONE rule for where a saved query's connection lives (2026-10-25).

    A saved query has NO connection column: ``query_config.connection_id`` is
    the one store every road that reads the STORED row consults -- run by id
    (``/api/execute`` ``query_id``), publish as an API, a feed or a dataset
    over the saved query.  The save routes used to take a TOP-LEVEL
    ``connection_id`` in silence (undeclared, so Pydantic dropped it: the
    F-009 class) and the query then ran on the DEFAULT local engine on every
    one of those roads -- ``/api/execute`` by id refused "File not found:
    live.parquet" and the published API answered 500, while the SAME query
    run with the connection on the request worked.  Now the top-level
    spelling is folded into the config; two DIFFERENT answers are refused.
    """
    if connection_id is None or query_config is None:
        return query_config
    stored = getattr(query_config, "connection_id", None)
    if stored is None:
        return query_config.model_copy(update={"connection_id": int(connection_id)})
    if int(stored) != int(connection_id):
        raise ValueError(
            f"connection_id {connection_id} at the top level disagrees with "
            f"query_config.connection_id {stored}; a saved query has ONE connection -- "
            f"send it once (query_config.connection_id).")
    return query_config


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigRequestModel
    created_by: Optional[str] = None
    folder: Optional[str] = None
    tags: Optional[List[str]] = None
    param_definitions: Optional[List[dict]] = None   # Phase 86: parameter definitions
    # 2026-10-25 -- the connection named at the TOP level (the BQB sends it in
    # BOTH places; an API client often only here).  Folded into
    # ``query_config.connection_id`` by ``_fold_connection_into_config``.
    connection_id: Optional[int] = None

    @model_validator(mode="after")
    def _one_connection(self):
        self.query_config = _fold_connection_into_config(self.connection_id, self.query_config)
        return self


class ExecuteQueryRequest(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigRequestModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # Cache strategy: auto = use cache if available; bypass = skip cache (no store);
    #                 refresh = skip cache lookup but store fresh result
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None
    # Async control fields
    wait: bool = False                     # Block until complete (external executor mode only)
    wait_timeout: int = Field(default=30, ge=1, le=300)  # Max seconds to wait
    callback_url: Optional[str] = None    # Webhook POST on completion/failure
    # Phase 86: runtime parameter substitution — {{param_name}} → value
    params: Optional[Dict[str, Any]] = None


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigRequestModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"


class UpdateQueryRequest(BaseModel):
    name:              Optional[str] = None
    description:       Optional[str] = None
    query_config:      Optional[QueryConfigRequestModel] = None
    change_note:       Optional[str] = None
    folder:            Optional[str] = None
    tags:              Optional[List[str]] = None
    param_definitions: Optional[List[dict]] = None   # Phase 86: parameter definitions
    # 2026-08-23 -- the SavedQueries "Share" toggle PUTs {is_shared: bool}
    # (SavedQueries.tsx handleToggleShared -> api.patchQuery -> PUT).  This
    # model did NOT declare the field, so Pydantic dropped it on the way in:
    # the toggle round-tripped to a no-op, the success notification claimed the
    # query was (un)shared, and a reload showed it never changed -- the same
    # undeclared-field defect class as the QueryConfigModel twin (F-009).
    # ``is_shared`` on a saved query is the READ grant ``is_owner_or_shared``
    # consults, so the dead toggle silently kept every "shared" query private.
    is_shared:         Optional[bool] = None
    # 2026-10-25 -- see _fold_connection_into_config: folded into the config
    # sent beside it; a connection sent with NO config has nowhere to live.
    connection_id:     Optional[int] = None

    @model_validator(mode="after")
    def _one_connection(self):
        if self.connection_id is not None and self.query_config is None:
            raise ValueError(
                "connection_id was sent without a query_config; a saved query's "
                "connection lives in query_config.connection_id -- send the config "
                "with it.")
        self.query_config = _fold_connection_into_config(self.connection_id, self.query_config)
        return self


class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


# ── Phase 86: Parameter helpers ───────────────────────────────────────────────

import re as _re  # noqa: E402
# Same {{name}} placeholder syntax as published_views.helpers._TEMPLATE_RE.
# Different SEMANTICS — this one raises on missing parameters and does not
# SQL-escape, because it runs against saved-query SQL where missing params
# are a programming error and the caller is trusted.  If you change the
# placeholder syntax, change it in helpers.py too.
_PARAM_TEMPLATE_RE = _re.compile(r"\{\{(\w+)\}\}")


def _substitute_query_params(sql: str, params: dict) -> str:
    """Replace {{param_name}} placeholders in SQL with provided values.
    Raises ValueError for any placeholder not present in params.
    """
    def _replace(m):
        key = m.group(1)
        if key not in params:
            raise ValueError(f"Parameter '{key}' used in SQL but not provided")
        return str(params[key])
    return _PARAM_TEMPLATE_RE.sub(_replace, sql)


class ExtractParamsRequest(BaseModel):
    sql: str


# ── Helper functions ───────────────────────────────────────────────────────────

# 2026-09-26 (F3 field-divergence sweep) -- this module carried a TWIN of
# ``core.query_converter.convert_query_config_to_engine``: a hundred lines
# copied before the converter was extracted, which never learned
# ``reader_override`` and would silently miss the next field too.  The
# datasets skill already records the earlier twin ``QueryConfigModel``
# this file held (it dropped ``raw_sql`` on every BQB save).  One
# converter, imported.
from core.query_converter import convert_query_config_to_engine  # noqa: E402


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — never raises."""
    try:
        ip = req.client.host if req and req.client else None
        ua = req.headers.get("user-agent", "") if req else ""
        username = (user or {}).get("username", "guest")
        _db_manager.audit(username, action, resource_type=resource_type,
                          resource_id=resource_id, ip_address=ip,
                          user_agent=ua[:500] if ua else None, details=details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


def _conn_upload_dir(connection_id: int) -> Path:
    """Get the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── File Endpoints ─────────────────────────────────────────────────────────────

@router.get("/api/files")
async def list_files(storage_type: Optional[str] = None, s3_folder: str = "", _user: dict = Depends(get_current_user)):
    """List all available parquet files from local and/or S3"""
    try:
        files = _engine.list_files(storage_type, s3_folder)
        return files
    except Exception as e:
        logger.error(f"Error listing files: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/files/{file_path:path}/schema")
async def get_file_schema(file_path: str, _user: dict = Depends(get_current_user)):
    """Get schema information for a specific file"""
    if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
        raise HTTPException(status_code=400, detail="Use /api/connections/{id}/tables/{name}/schema for registered tables")
    try:
        schema = _engine.get_file_schema(file_path)
        return schema
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="File not found")
    except Exception as e:
        logger.error("Error getting file schema: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/files/upload")
async def upload_parquet_file(file: UploadFile = File(...), _user: dict = Depends(get_current_user)):
    """Upload a parquet file to local storage"""
    try:
        if not file.filename.endswith('.parquet'):
            raise HTTPException(status_code=400, detail="Only .parquet files are allowed")

        file_path = Path(_engine.base_path) / file.filename

        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)

        logger.info(f"File uploaded: {file.filename}")

        return {
            "filename": file.filename,
            "size_bytes": file_path.stat().st_size,
            "storage_type": "local",
            "message": "File uploaded successfully"
        }
    except Exception as e:
        logger.error(f"Error uploading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))



# ── Query Management Endpoints ─────────────────────────────────────────────────
# NOTE: Connection file upload endpoints live in api/connections_api.py

def _with_output_columns(qc: dict) -> dict:
    """Record a SQL query's OUTPUT COLUMNS at save time.

    2026-09-01 — a report runs on a QUERY, not on one table, so the query is
    the only thing that knows its own output shape.  It knows it offline, and
    it knew it at the moment the author saved it.  Storing it there means
    every consumer downstream — dataset creation, the wizard's preview, column
    detection — can answer "what columns does this return?" without a source
    round-trip.

    That matters most for connections that cannot run SQL at all.  An S3
    connection is object storage: the preview endpoint could not execute a
    statement against it, so dataset creation from S3 had no way to learn a
    query's columns and failed at every step.  The columns were derivable the
    whole time.

    Visual-mode queries already carry their selections, so this only fills in
    RAW SQL, and never overwrites what the author chose.  A statement whose
    shape cannot be read from the text (``SELECT *``) is left alone rather
    than half-filled — a partial column list looks complete and is worse
    than none.
    """
    try:
        if not isinstance(qc, dict):
            return qc
        if qc.get("columns"):
            return qc                      # the author's own selection wins
        raw = (qc.get("raw_sql") or qc.get("custom_sql") or "").strip()
        if not raw:
            return qc
        from core.sql_output_columns import derive_columns_from_sql_text
        cols = [c["physical_name"] for c in derive_columns_from_sql_text(raw)]
        if cols:
            qc = dict(qc)
            qc["columns"] = cols
            logger.info("Saved query: recorded %d output column(s) from its "
                        "SQL (%s)", len(cols), ", ".join(cols[:6]))
    except Exception as exc:
        # Advisory: never block a save because the shape could not be read.
        logger.debug("output-column extraction skipped: %s", exc)
    return qc


@router.post("/api/queries")
async def create_query(req: Request, request: SaveQueryRequest, _user: dict = Depends(require_role("admin", "analyst"))):
    """Save a new query"""
    # FB-48 (2026-09-20) -- admin_governance.max_saved_queries_per_user was
    # declared, admin-settable and read by NOTHING.  Enforced here, through
    # the same chokepoint that already caps connections / schedules /
    # published views, so there is one answer to "what is a per-user cap"
    # rather than a second one for queries.  A CAP: it throttles with a 409
    # naming the number, and 0 (the shipped default) is unlimited.
    from api.deps import enforce_user_resource_quota
    enforce_user_resource_quota(_user, "saved_queries")
    try:
        # Do NOT validate file existence here — files may be on S3 or remote paths
        # that aren't accessible from the server at save time. Validation runs at
        # execution time when the engine actually needs the files.
        query = await _adb(_db_manager.create_query,
            name=request.name,
            description=request.description,
            query_config=_with_output_columns(request.query_config.model_dump()),
            # SECURITY 2026-08-22: owner is the AUTHENTICATED principal only.
            # The body's request.created_by used to be a fallback here -- a
            # client could pre-stamp another user's name as owner.  It is
            # ignored now; the only fallback is the auth-disabled dev guest.
            created_by=(_user or {}).get("username") or "guest",
            workspace_id=get_workspace_id(req),
            folder=request.folder,
            tags=request.tags,
            param_definitions=request.param_definitions,
        )
        _audit(_user, "save_query", req, "query", query["id"], {"name": request.name})
        logger.info(f"Query saved: {query['id']}")
        return query

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error saving query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/queries")
async def list_queries(active_only: bool = True, limit: int = 100, offset: int = 0,
                       request: Request = None):
    """List saved queries — filtered by owner/shared and workspace when auth is enabled."""
    try:
        workspace_id = get_workspace_id(request) if request else None
        queries = await _adb(_db_manager.list_queries, active_only=active_only, limit=limit, offset=offset,
                                           workspace_id=workspace_id)
        # Row-level security: non-admin users only see own + shared queries
        if _auth_cfg.type != "none" and request:
            user = get_current_user(request)
            queries = [q for q in queries if is_owner_or_shared(q, user)]
        return queries
    except Exception as e:
        logger.error(f"Error listing queries: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Join Preview ───────────────────────────────────────────────────────────────

@router.post("/api/joins/preview")
async def join_preview(request: JoinPreviewRequest, _user: dict = Depends(get_current_user)):
    """Return match statistics for a proposed join: row counts + sample rows.
    Runs lightweight DuckDB COUNT(*) queries — no execution record created."""
    import duckdb as _ddb

    # SECURITY 2026-08-23 (Phase 2A): this endpoint resolves the connection's
    # DECRYPTED S3 credentials, drives an outbound DuckDB read with them, and
    # RETURNS SAMPLE ROWS from the joined files.  It never checked whether the
    # caller may use the connection — a non-owner could preview (and read
    # rows out of) another analyst's private-connection files by id.  Gate on
    # the shared entitlement decision, 404 like the other execution doors.
    if request.connection_id:
        from core.entitlements import denied_connection_ids as _dci
        _jp_denied = await _adb(_dci, _user, [request.connection_id], db=_db_manager)
        if _jp_denied:
            raise HTTPException(status_code=404, detail="Connection not found")

    def _make_read_fn(file_path: str, conn=None) -> str:
        """Return a DuckDB read expression for the given file path."""
        if file_path.startswith("__registered__:") or file_path.startswith("__iceberg__:"):
            raise ValueError(f"Registered/Iceberg tables cannot be used in join preview: {file_path}")
        if file_path.startswith("s3://"):
            return f"read_parquet('{file_path}')"
        from core.file_formats import get_format_adapter, is_supported_extension, parse_sheet_from_path
        clean_path, _sheet = parse_sheet_from_path(file_path)
        _ext = os.path.splitext(clean_path)[1].lower()
        if _ext and is_supported_extension(_ext):
            return get_format_adapter(_ext).duckdb_read_expr(clean_path, sheet=_sheet)
        return f"read_parquet('{clean_path}')"

    try:
        # Resolve S3 credentials if needed
        _join_conn_config: dict = {}
        if request.connection_id:
            try:
                conn_cfg = await _adb(_db_manager.get_connection_raw, request.connection_id)
                if conn_cfg:
                    _join_conn_config = conn_cfg.get("config", {})
            except Exception as exc:
                logger.warning("Recoverable error: %s", exc, exc_info=True)

        from api.data_grid_api import _duckdb_con_with_s3 as _s3_con_fn2
        # Offload the whole DuckDB block (connection + COUNT/sample queries)
        # off the event loop — it reads S3/parquet and can take seconds, which
        # would otherwise freeze the single loop and stall health probes.  The
        # connection is created AND used AND closed inside the SAME worker
        # thread (DuckDB connections are not safe to share across threads).
        # See backend/docs/event_loop_blocking_audit.md (Tier-1 queries_api:502).
        def _run_join_preview():
            con = _s3_con_fn2(_join_conn_config, request.connection_id) if _join_conn_config else _ddb.connect()
            try:
                left_read  = _make_read_fn(request.left_file)
                right_read = _make_read_fn(request.right_file)
                on_clause = " AND ".join(
                    f't0."{_lk}" = t1."{r}"'
                    for _lk, r in zip(request.left_on, request.right_on)
                )
                join_type = request.how.upper()
                if join_type not in ("INNER", "LEFT", "RIGHT"):
                    join_type = "FULL OUTER"
                _lc  = con.execute(f"SELECT COUNT(*) FROM {left_read} AS t0").fetchone()[0]
                _rc = con.execute(f"SELECT COUNT(*) FROM {right_read} AS t1").fetchone()[0]
                _mc = con.execute(
                    f"SELECT COUNT(*) FROM {left_read} AS t0"
                    f" INNER JOIN {right_read} AS t1 ON {on_clause}"
                ).fetchone()[0]
                # Sample rows from the configured join type
                _sdf = con.execute(
                    f"SELECT * FROM {left_read} AS t0"
                    f" {join_type} JOIN {right_read} AS t1 ON {on_clause} LIMIT 5"
                ).fetchdf()
                _cols = list(_sdf.columns)
                _rows = sanitize_for_json(_sdf.to_dict(orient="records"))
                return _lc, _rc, _mc, _cols, _rows
            finally:
                con.close()

        left_count, right_count, matched_count, columns, sample_rows = (
            await asyncio.to_thread(_run_join_preview)
        )

        match_rate = round(matched_count / left_count, 4) if left_count > 0 else 0.0
        return {
            "left_count": left_count,
            "right_count": right_count,
            "matched_count": matched_count,
            "match_rate": match_rate,
            "columns": columns,
            "sample_rows": sample_rows,
        }
    except Exception as exc:
        logger.error("join_preview error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail=str(exc))


# ── Preview SQL Endpoint ───────────────────────────────────────────────────────

@router.post("/api/execute/preview-sql")
async def preview_sql(request: PreviewSqlRequest, _user: dict = Depends(get_current_user)):
    """Generate the actual SQL that would be executed for a given query config.

    Returns SQL with **bare registered-view identifiers** (e.g. ``FROM "fact_table"``)
    rather than source-specific bake-ins (e.g. ``read_parquet('__registered__:fact_table')``
    or ``__registered__:fact_table``).  This makes CQB-saved queries source-agnostic
    and portable across:
      - DuckDB execution (via ``setup_registered_views`` view names)
      - SQL connectors (Trino / Snowflake / Databricks / Oracle — native table names)
      - Feed generation (same rewrite pipeline as execution)
      - Iceberg manifests

    The same rewriter runs at execute time too, so output here matches what the
    engine actually runs.  Mirrors BQB's ``sqlTableName(path)`` client-side helper
    which has emitted portable form since launch.
    """
    try:
        from core.parquet_engine_v2 import ParquetQueryEngine
        from core.s3_storage import build_s3_config
        from core.connectors import SQL_CONNECTOR_TYPES
        from core.connection_manager import _normalize_path
        from core.virtual_ref_rewriter import rewrite_virtual_refs

        engine_config = convert_query_config_to_engine(request.query_config)
        if request.connection_id:
            conn = await _adb(_db_manager.get_connection_raw, request.connection_id)
            if conn:
                conn_type = conn.get('connection_type')
                cfg = conn.get('config', {})
                if conn_type in SQL_CONNECTOR_TYPES:
                    # 2026-08-19 -- this endpoint RETURNS {"dialect":
                    # conn_type} while building without it, so the SQL
                    # previewed was not the SQL that runs.  preview == run is
                    # the invariant this module exists to hold.
                    #
                    # 2026-09-05 -- AND SO IS THE REFUSAL.  This branch used
                    # to carry its OWN ``_native_table_ref``, a third copy of
                    # the virtual-prefix vocabulary that STRIPPED the prefix
                    # (and mapped ``__local__:x`` to the DuckDB view name
                    # ``__lt__x``) and handed the bare name to a REMOTE
                    # engine.  All five prefixes in
                    # ``core.query_compiler._VIRTUAL_PREFIXES`` name something
                    # LOCAL TO THIS POD, so neither answer was right here:
                    # ``fact`` and ``__lt__upload`` are both unqualified names
                    # Trino/Snowflake resolve against the SESSION'S DEFAULT
                    # CATALOG -- A DIFFERENT TABLE READ WITH NO ERROR (the
                    # 2026-08-19 de-qualification defect).  One builder now
                    # answers both questions:
                    # ``build_query_sql_for_connection`` picks the FROM clause
                    # and the dialect for the engine actually addressed, and
                    # it also catches the empty-files and union-by-name shapes
                    # this branch used to render as ``FROM `` / silently as
                    # one file.
                    #
                    # 2026-09-05 ROUND 2 -- this comment used to claim the
                    # engine "was fixed the same day to REFUSE that ref for a
                    # remote target".  IT WAS NOT, other than here: the
                    # refusal lived inside
                    # ``build_query_sql_for_connection``, whose only callers
                    # were the three preview/feed doors, while SIX EXECUTION
                    # doors called the lower-level ``build_query_sql(cfg,
                    # files[0], dialect=...)`` with no check at all -- so this
                    # endpoint refused queries the run path executed, and the
                    # run path executed queries this endpoint refused, with
                    # the run side on the wrong-answer half.  The decision now
                    # lives in ``parquet_engine_v2.native_from_ref`` and ALL
                    # NINE doors ask it, so ``preview == run`` is a shared
                    # call rather than a claim in a comment.
                    #
                    # The DuckDB direction is untouched: ``__local__:x`` is a
                    # legitimate ref there, and the local/s3 branches below
                    # still render it through ``rewrite_virtual_refs``, which
                    # owns the ``__lt__``/``__mv__``/``__fv__`` view-name
                    # mapping.  That mapping was never this endpoint's to make.
                    from core.parquet_engine_v2 import QueryNotExpressible
                    from core.sql_connector_dialect import dialect_is_known
                    try:
                        sql = _engine.build_query_sql_for_connection(
                            engine_config, conn_type)
                    except QueryNotExpressible as refusal:
                        # A REFUSAL, NOT AN ABSENCE.  The adjacent precedent
                        # (core/feed_sql_resolver.py, same day) swallowed this
                        # into ``sql=""`` and the caller reported "has no SQL
                        # content" -- "could not build this for Trino, and
                        # here is why" and "this query has no SQL" lead to
                        # opposite investigations.  Say which engine refused,
                        # and why, in a shape a caller can tell apart from a
                        # builder crash.
                        logger.info(
                            "[preview-sql] config cannot be expressed on "
                            "%s (connection %s): %s",
                            conn_type, request.connection_id, refusal)
                        raise HTTPException(status_code=400, detail={
                            "error": "query_not_expressible",
                            "engine": conn_type,
                            "connection_id": request.connection_id,
                            "message": str(refusal),
                            "sql": "",
                        })
                    # The builder's documented contract: a target with no
                    # known dialect mapping (``rest_api``) renders
                    # byte-identically to DuckDB.  Report the dialect that was
                    # actually used rather than the connection type, so the
                    # label cannot claim a grammar the SQL is not in.
                    #
                    # 2026-09-05 round 2 -- AND REWRITE IT, like every other
                    # duckdb-labelled return in this handler.  This branch
                    # returned ``build_query_sql_for_connection`` VERBATIM,
                    # and for a target with no dialect that is
                    # ``get_duckdb_sql`` output --
                    # ``FROM read_parquet('__registered__:sales')``, which is
                    # not a path DuckDB can open.  The local/s3 branches
                    # below, and the no-connection fallback, have always
                    # wrapped their answer in ``rewrite_virtual_refs``; this
                    # one was added without it, so the pre-fix ``FROM
                    # "sales"`` became an unopenable file reader for every
                    # rest_api preview.  The condition is the LABEL, not the
                    # connection type: whatever we say the dialect is, the
                    # SQL must be in it.
                    _preview_dialect = (conn_type if dialect_is_known(conn_type)
                                        else "duckdb")
                    if _preview_dialect == "duckdb":
                        sql = rewrite_virtual_refs(sql)
                    return {"sql": sql, "dialect": _preview_dialect}
                elif conn_type == 'local':
                    local_path = str(_normalize_path(cfg.get('base_path', './data/parquet')))
                    local_engine = ParquetQueryEngine(base_path=local_path, chunk_size=_qe_cfg.chunk_size)
                    sql = rewrite_virtual_refs(local_engine.get_duckdb_sql(engine_config))
                    return {"sql": sql, "dialect": "duckdb"}
                elif conn_type == 's3':
                    s3_engine = ParquetQueryEngine(
                        base_path=str(_paths.parquet_dir),
                        chunk_size=_qe_cfg.chunk_size,
                        s3_config=build_s3_config(cfg),
                    )
                    sql = rewrite_virtual_refs(s3_engine.get_duckdb_sql(engine_config))
                    return {"sql": sql, "dialect": "duckdb"}
        sql = rewrite_virtual_refs(_engine.get_duckdb_sql(engine_config))
        return {"sql": sql, "dialect": "duckdb"}
    except HTTPException:
        # 2026-09-05 -- the REFUSAL MUST SURVIVE THIS HANDLER.  The blanket
        # ``except Exception`` below re-wraps whatever it catches into
        # ``detail=str(e)``, and an HTTPException IS an Exception: without
        # this arm the structured query_not_expressible payload raised above
        # was flattened into the repr of an HTTPException object, losing the
        # engine, the connection and the reason.  A fix an outer handler
        # downgrades is not a fix.
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ── Downloads Endpoints ────────────────────────────────────────────────────────

# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def list_downloads(status: str = "available", limit: int = 100, offset: int = 0, _user: dict = Depends(get_current_user)):
    """List available downloads — scoped to the caller (admin/support see all)."""
    try:
        # 2026-08-30 — page until enough VISIBLE rows are found.  This
        # used to fetch one page and filter it afterwards, so a user
        # whose files sat behind other people's newest 10 saw an EMPTY
        # Download Centre (measured: 0 of her 5 at limit=10).
        from core.download_listing import visible_page
        from api.data_grid_api import _enforce_download_ownership
        _share_memo: dict = {}

        from core.download_retention import download_refusal

        def _visible(row) -> bool:
            # 2026-09-26 (viewer click-crawl on the Docker rig) -- the
            # "available" listing showed rows whose retention had LAPSED
            # (status still 'available' between cleanup sweeps), and every
            # Preview / download on them answered 410.  ONE lifecycle rule
            # for the list and the routes that serve the bytes.
            if status == "available" and download_refusal(row):
                return False
            if _auth_cfg.type == "none":
                return True
            try:
                _enforce_download_ownership(row, _user, allow_service=False,
                                            share_memo=_share_memo)
                return True
            except HTTPException:
                return False

        downloads = await _adb(
            lambda: visible_page(
                lambda lim, off: _db_manager.list_download_files(
                    status=status, limit=lim, offset=off),
                _visible, limit=limit, offset=offset,
                label="api/downloads"))
        # SECURITY 2026-08-22: this list once returned every user's file_id
        # and filename globally -- the exact enumeration source an IDOR
        # needs.  The guarantee now lives in ``_visible`` above, applied
        # WHILE paging rather than to one page afterwards, and it is the
        # same _enforce_download_ownership the by-id route uses.
        #
        # allow_service=False: the Download Centre is not the token
        # boundary.  With the default allowance this showed every
        # authenticated user every published_view:/embed:/shared:/system/
        # scheduled result file -- rows materialised under another
        # principal's row-security scope.
        #
        # ONE memo across the whole request: a share resolves a scope
        # signature, and each is a full scan of the three policy tables
        # (measured: 100 report loads + 100 policy scans per 100-row page
        # unmemoised).  Request-scoped, so a policy edit is never served
        # from a stale entry.
        return downloads
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing downloads: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def download_file(file_id: str, _user: dict = Depends(get_current_user)):
    """Download a file"""
    try:
        download_info = await _adb(_db_manager.get_download_file, file_id)

        if not download_info:
            raise HTTPException(status_code=404, detail="File not found")

        # SECURITY 2026-08-17: `_user` was bound here and then never referenced
        # again in the whole body -- this route served the FileResponse for ANY
        # file id to any authenticated caller.  The three sibling routes under
        # the same /api/downloads/{file_id}/* prefix in data_grid_api already
        # enforce ownership (wiz-scan #1, 2026-07-14, CWE-639); this one was
        # missed.  Reuse that exact helper rather than restate the rule.
        from api.data_grid_api import _enforce_download_ownership
        # allow_service=False — see list_downloads above.  The by-id
        # route must not serve what the list refuses to show, or the
        # filtering is cosmetic and the file_id is still guessable.
        _enforce_download_ownership(download_info, _user,
                                    allow_service=False)

        # Status AND retention, through the one chokepoint the sibling
        # route now shares (2026-08-30).  expires_at used to be acted on
        # only by the scheduler sweep, so a lapsed download stayed
        # downloadable wherever no scheduler runs.
        from core.download_retention import download_refusal
        _refusal = download_refusal(download_info)
        if _refusal:
            raise HTTPException(status_code=410, detail=_refusal)

        file_path = Path(download_info["file_path"])

        if not file_path.exists():
            # File deleted from disk — purge the stale record so it stops showing in history
            await _adb(_db_manager.update_download_file, file_id, status="deleted")
            raise HTTPException(status_code=410, detail="File has been deleted")

        await _adb(_db_manager.increment_download_count, file_id)

        logger.info(f"File downloaded: {file_id}")

        _media_map = {
            ".csv":   "text/csv",
            ".xlsx":  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".json":  "application/json",
            ".parquet": "application/octet-stream",
        }
        _media_type = _media_map.get(file_path.suffix.lower(), "application/octet-stream")
        return FileResponse(
            path=file_path,
            filename=download_info["filename"],
            media_type=_media_type,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading file: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


class DownloadRetentionUpdate(BaseModel):
    """How long the requester wants to keep a download."""
    retain_days: int = Field(..., ge=1)


# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def update_download_retention(
        file_id: str, body: DownloadRetentionUpdate,
        _user: dict = Depends(get_current_user)):
    """Change how long this download is kept (Download Centre).

    2026-08-30 — the export routes already accepted ``?retain_days=`` and
    clamped it to the operator maximum, but nothing in the product ever
    sent it: the retention a user could choose was reachable only by
    hand-editing a URL.  This is the half that was missing, placed where
    a user actually looks for their files.

    Authorization is the DELETE rule, not the read rule: an entitlement
    SHARE lets someone read another principal's artifact, and letting a
    reader extend or shorten the owner's retention would be a
    write through a read grant.  Owner or admin only.

    The clamp itself is not restated here — it is
    ``core.download_retention.expires_at_for``, the same rule the export
    routes use.  One rule, two callers.
    """
    from core.download_retention import (
        RetentionRefused, download_refusal, expires_at_for)
    try:
        download = await _adb(_db_manager.get_download_file, file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")
        # Refuse to extend something already gone — otherwise a lapsed or
        # deleted row could be resurrected past the policy that retired it.
        _refusal = download_refusal(download)
        if _refusal:
            raise HTTPException(status_code=410, detail=_refusal)
        if _auth_cfg.type != "none" and not is_admin_like(_user):
            if download.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403,
                                    detail="Permission denied")
        try:
            new_expiry = expires_at_for(body.retain_days)
        except RetentionRefused as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        updated = await _adb(_db_manager.update_download_file, file_id,
                             expires_at=new_expiry)
        if not updated:
            raise HTTPException(status_code=404, detail="File not found")
        audit_event(_db_manager, _user, None, "set_download_retention",
                    "download", file_id)
        return {"file_id": file_id,
                "retain_days": body.retain_days,
                "expires_at": updated.get("expires_at")}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error setting retention for %s: %s", file_id, e,
                     exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def delete_download(file_id: str, _user: dict = Depends(get_current_user)):
    """Mark a download as deleted and remove from disk"""
    try:
        download = await _adb(_db_manager.get_download_file, file_id)
        if not download:
            raise HTTPException(status_code=404, detail="File not found")
        # RLS: non-admins can only delete their own downloads
        if _auth_cfg.type != "none" and not is_admin_like(_user):
            if download.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")

        # Remove file from disk if it exists.  2026-09-25: a row with NO
        # path (a feed run whose delivery was suppressed) made Path("")
        # == "." -- it "exists", and unlink() on the working directory
        # answered 500, so the row could never be removed.  Only a FILE
        # is ever unlinked here.
        _raw_path = str(download.get("file_path") or "").strip()
        file_path = Path(_raw_path) if _raw_path else None
        if file_path is not None and file_path.is_file():
            file_path.unlink()
            logger.info(f"Deleted file from disk: {file_path}")

        # Mark as deleted in DB using existing update_download_file method
        await _adb(_db_manager.update_download_file, file_id, status="deleted")
        audit_event(_db_manager, _user, None, "delete_download", "download", file_id)

        return {"message": f"File {file_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting download {file_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Query CRUD Endpoints ───────────────────────────────────────────────────────

def _require_query_view(q: dict, _user: dict) -> None:
    """Owner / shared / admin -- the same rule ``list_queries`` filters by.

    SECURITY 2026-08-17: the by-id routes below reached a saved query without
    ever applying it, so the list-level RLS could be bypassed by guessing an id.
    404 (not 403) so these are not existence oracles.
    """
    if _auth_cfg.type == "none":
        return
    if not is_owner_or_shared(q, _user):
        raise HTTPException(status_code=404, detail="Query not found")


def _require_query_own(q: dict, _user: dict) -> None:
    """Owner or admin.  ``is_shared`` grants READ, never control.

    Sharing a query must not hand over the right to rewrite its history or to
    mint/revoke public share links for it.
    """
    if _auth_cfg.type == "none" or is_admin_like(_user):
        return
    if q.get("created_by") != (_user or {}).get("username"):
        raise HTTPException(status_code=403, detail="Permission denied")


@router.get("/api/queries/{query_id}")
async def get_query(query_id: int, _user: dict = Depends(get_current_user)):
    """Get a single saved query by ID

    SECURITY 2026-08-17: took NO auth dependency -- any saved query, including
    its ``query_config`` (file paths / SQL), was readable anonymously by id.
    The sibling DELETE three lines below already showed the correct rule.
    """
    try:
        query = await _adb(_db_manager.get_query, query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        _require_query_view(query, _user)
        return query
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/api/queries/{query_id}")
async def delete_query(query_id: int, req: Request, acknowledge_dependents: bool = False,
                       _user: dict = Depends(get_current_user)):
    """Soft-delete a saved query (sets is_active=False).

    2026-10-17 -- refused (409) while a PUBLISHED API serves this query
    (core/published_api/impact.py); ``acknowledge_dependents=true`` deletes
    anyway and audits the APIs."""
    try:
        query = await _adb(_db_manager.get_query, query_id)
        if not query:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only delete their own queries
        if _auth_cfg.type != "none" and not is_admin_like(_user):
            if query.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        from api.published_api_api import refuse_if_apis_depend_async
        await refuse_if_apis_depend_async(_db_manager, "saved_query", query_id,
                                          acknowledged=acknowledge_dependents, actor=_user)
        await _adb(_db_manager.delete_query, query_id, soft_delete=True)
        _audit(_user, "delete_query", req, "query", query_id, {"name": query.get("name")})
        return {"message": f"Query {query_id} deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/queries/folders")
def list_query_folders(_user: dict = Depends(get_current_user)):
    """List all distinct folder names used by saved queries.
    2026-06-03 — converted async→sync: zero awaits in body; FastAPI
    auto-dispatches sync endpoints to the threadpool so the
    session.query().all() doesn't block the loop."""
    try:
        from core.database import SavedQuery
        with _db_manager.get_session() as session:
            rows = session.query(SavedQuery.folder).filter(
                SavedQuery.is_active,
                SavedQuery.folder.isnot(None),
                SavedQuery.folder != "",
            ).distinct().all()
        return sorted(set(r[0] for r in rows if r[0]))
    except Exception as e:
        logger.error("Error listing query folders: %s", e)
        return []


@router.get("/api/queries/tags")
def list_query_tags(_user: dict = Depends(get_current_user)):
    """List all distinct tags used across saved queries.  2026-06-03 sync."""
    try:
        from core.database import SavedQuery
        with _db_manager.get_session() as session:
            rows = session.query(SavedQuery.tags).filter(
                SavedQuery.is_active,
                SavedQuery.tags.isnot(None),
            ).all()
        all_tags = set()
        for r in rows:
            tags = r[0]
            if isinstance(tags, list):
                all_tags.update(tags)
            elif isinstance(tags, str):
                import json as _json
                try:
                    parsed = _json.loads(tags)
                    if isinstance(parsed, list):
                        all_tags.update(parsed)
                except Exception:
                    pass
        return sorted(all_tags)
    except Exception as e:
        logger.error("Error listing query tags: %s", e)
        return []


@router.post("/api/queries/extract-params")
async def extract_query_params(body: ExtractParamsRequest, _user: dict = Depends(get_current_user)):
    r"""Extract parameter placeholders and return the detected parameters.

    2026-09-17 (FB-13) -- THE EXTRACTOR AND THE SUBSTITUTER USED DIFFERENT
    SYNTAXES, in the feature operators use most.

        api/queries_api.py  extract-params  r"\{\{(\w+)\}\}"      {{name}}
        core/parameters.py  PARAM_RE        r"\{([a-zA-Z_]\w*)\}"  {name}

    Proven by calling substitute_sql_params directly with
    {'p_region': 'EMEA'}:

        {p_region}    -> WHERE region = 'EMEA'   CORRECT, quoted, injection-safe
        {{p_region}}  -> WHERE region = {'EMEA'} stray braces -> parse error
        ${p_region}   -> WHERE region = $'EMEA'  stray $      -> parse error

    ...while extract-params on the same three returned [], [p_region], [].
    So the syntax that WORKS discovered nothing, and the syntax the extractor
    ADVERTISED produced SQL that will not parse.  A decision made twice.

    The substituter wins, because it is the half that runs: this now uses its
    regex, imported rather than re-spelled, so the two cannot drift again.
    A ``{{name}}`` in the SQL is still reported -- the inner ``{name}`` is a
    real placeholder and will be substituted -- but it is flagged, because
    the surrounding braces survive substitution and break the statement.
    """
    from core.parameters import PARAM_RE

    sql = body.sql or ""
    names = list(dict.fromkeys(PARAM_RE.findall(sql)))
    warnings = []
    doubled = [n for n in names if ("{{" + n + "}}") in sql]
    if doubled:
        warnings.append(
            f"{sorted(doubled)} are written as {{{{name}}}}. The placeholder "
            f"syntax is {{name}} -- with double braces the outer pair "
            f"survives substitution and the statement will not parse "
            f"(WHERE region = {{'EMEA'}}). Remove the extra braces."
        )
    return {
        "params": [
            {"name": n, "type": "string", "required": True, "default": None, "description": ""}
            for n in names
        ],
        "warnings": warnings,
    }


@router.post("/api/queries/{query_id}/favorite")
async def toggle_query_favorite(query_id: int, req: Request, _user: dict = Depends(get_current_user)):
    """Toggle the is_favorite flag on a saved query."""
    try:
        _q = await _adb(_db_manager.get_query, query_id)
        if not _q:
            raise HTTPException(status_code=404, detail="Query not found")
        _require_query_view(_q, _user)  # SECURITY 2026-08-17
        result = await _adb(_db_manager.toggle_favorite, query_id)
        if not result:
            raise HTTPException(status_code=404, detail="Query not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error toggling favorite for query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/api/queries/{query_id}")
async def update_query(query_id: int, request: UpdateQueryRequest,
                       _user: dict = Depends(get_current_user)):
    """Update a saved query — auto-saves a version snapshot before changes."""
    try:
        existing = await _adb(_db_manager.get_query, query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # RLS: non-admins can only update their own queries
        if _auth_cfg.type != "none" and not is_admin_like(_user):
            if existing.get("created_by") != _user.get("username"):
                raise HTTPException(status_code=403, detail="Permission denied")
        updates = {}
        if request.name is not None:
            updates["name"] = request.name
        if request.description is not None:
            updates["description"] = request.description
        if request.query_config is not None:
            updates["query_config"] = request.query_config.model_dump()
        if request.folder is not None:
            updates["folder"] = request.folder
        if request.tags is not None:
            updates["tags"] = request.tags
        if request.param_definitions is not None:
            updates["param_definitions"] = request.param_definitions
        if request.is_shared is not None:
            updates["is_shared"] = request.is_shared
        # Snapshot before change -- but ONLY when a CONTENT field
        # (name/description/query_config) actually changes.  A version is the
        # query's editable body; a metadata-only PUT (is_shared toggle, a
        # folder move, a tag edit) is not an edit of that body, and snapshotting
        # it duplicated the config into version history on every share-toggle
        # click.  Version history stays a record of real content edits.
        if any(k in updates for k in ("name", "description", "query_config")):
            await _adb(_db_manager.create_query_version,
                query_id=query_id,
                name=existing["name"], description=existing.get("description"),
                query_config=existing["query_config"],
                changed_by=_user.get("username"), change_note=request.change_note,
            )
        result = await _adb(_db_manager.update_query, query_id, **updates)
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating query {query_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Version History Endpoints ──────────────────────────────────────────────────

@router.get("/api/queries/{query_id}/versions")
async def list_query_versions(query_id: int, _user: dict = Depends(get_current_user)):
    try:
        _q = await _adb(_db_manager.get_query, query_id)
        if not _q:
            raise HTTPException(status_code=404, detail="Query not found")
        _require_query_view(_q, _user)  # SECURITY 2026-08-17
        return await _adb(_db_manager.list_query_versions, query_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/queries/{query_id}/versions/{version_id}/restore")
async def restore_query_version(query_id: int, version_id: int,
                                _user: dict = Depends(get_current_user)):
    try:
        v = await _adb(_db_manager.get_query_version, version_id)
        if not v or v["query_id"] != query_id:
            raise HTTPException(status_code=404, detail="Version not found")
        existing = await _adb(_db_manager.get_query, query_id)
        if not existing:
            raise HTTPException(status_code=404, detail="Query not found")
        # SECURITY 2026-08-22: this route reached get_query_version +
        # update_query with NO ownership gate -- any authenticated analyst
        # could rewrite ANY query's content from its own history (a cross-user
        # IDOR write).  Restoring history is a control operation, so it takes
        # the same owner-or-admin rule as share/rewrite, not the view rule.
        _require_query_own(existing, _user)
        # Save current state as a version before restoring
        await _adb(_db_manager.create_query_version, 
            query_id=query_id, name=existing["name"], description=existing.get("description"),
            query_config=existing["query_config"], changed_by=_user.get("username"),
            change_note=f"Auto-saved before restore to v{v['version_number']}",
        )
        await _adb(_db_manager.update_query, query_id, name=v["name"], description=v["description"],
                                 query_config=v["query_config"])
        return {"message": f"Restored to version {v['version_number']}"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Query Sharing Endpoints ────────────────────────────────────────────────────

@router.post("/api/queries/{query_id}/share")
async def share_query(query_id: int, request: ShareQueryRequest,
                      _user: dict = Depends(get_current_user)):
    q = await _adb(_db_manager.get_query, query_id)
    if not q:
        raise HTTPException(status_code=404, detail="Query not found")
    _require_query_own(q, _user)  # SECURITY 2026-08-17 -- mints a public link
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = await _adb(_db_manager.create_share, query_id, _user.get("username"), expires_at)
    return share


@router.get("/api/queries/{query_id}/shares")
async def list_query_shares(query_id: int, _user: dict = Depends(get_current_user)):
    _q = await _adb(_db_manager.get_query, query_id)
    if not _q:
        raise HTTPException(status_code=404, detail="Query not found")
    _require_query_own(_q, _user)  # SECURITY -- tokens are bearer credentials
    return await _adb(_db_manager.list_shares, query_id)


@router.delete("/api/queries/{query_id}/shares/{token}")
async def revoke_share(query_id: int, token: str, _user: dict = Depends(get_current_user)):
    _q = await _adb(_db_manager.get_query, query_id)
    if not _q:
        raise HTTPException(status_code=404, detail="Query not found")
    _require_query_own(_q, _user)  # SECURITY 2026-08-17
    await _adb(_db_manager.deactivate_share, token)
    audit_event(_db_manager, _user, None, "revoke_share", "share", token)
    return {"message": "Share revoked"}


# ── The ONLY fields an anonymous shared-query page may see (2026-09-15) ──
#
# ``GET /api/shared/{token}`` used to return the FULL saved-query row and the
# FULL share row: ``created_by``, ``workspace_id``, ``query_config`` with its
# ``connection_id`` and RAW SQL, execution counters.  The business-report
# sibling was whitelisted for exactly this reason (F-P3A-01,
# ``_token_report_projection``); this sibling never was.  That helper is
# report-shaped (layout / sections / parameters), so a saved query needs its
# own field list — the DISCIPLINE is the same: an anonymous consumer gets
# what it takes to render, never the author's identity, the connection id or
# the SQL.  The page executes through ``POST /api/execute`` with
# ``X-Share-Token``, where ``enforce_token_execute_scope`` REPLACES any
# submitted ``query_config`` with the stored saved-query id — so the config
# was never needed on this wire, only leaked on it.
_SHARED_QUERY_FIELDS = ("id", "name", "description")
_SHARED_QUERY_SHARE_FIELDS = ("token", "created_at", "expires_at",
                              "access_count", "is_active")


def _shared_query_projection(query: dict, share: dict) -> dict:
    """The wire shape of the anonymous shared-query page — nothing else."""
    return {
        "query": {f: (query or {}).get(f) for f in _SHARED_QUERY_FIELDS},
        "share": {f: (share or {}).get(f) for f in _SHARED_QUERY_SHARE_FIELDS},
    }


# PUBLIC endpoint — NO auth (accessible by anyone with the link)
@router.get("/api/shared/{token}")
async def get_shared_query(token: str):
    share = await _adb(_db_manager.get_share_by_token, token)
    if not share or not share.get("is_active"):
        raise HTTPException(status_code=404, detail="Share link not found")
    if share.get("expires_at"):
        try:
            exp = datetime.fromisoformat(share["expires_at"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                raise HTTPException(status_code=410, detail="Share link has expired")
        except HTTPException:
            raise
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)
    await _adb(_db_manager.increment_share_access, token)
    q = await _adb(_db_manager.get_query, share["query_id"])
    if not q:
        raise HTTPException(status_code=404, detail="Query no longer exists")
    return _shared_query_projection(q, share)


# ── Dashboard Sharing Endpoints ────────────────────────────────────────────────

@router.post("/api/dashboards/{dashboard_id}/share")
async def share_dashboard(dashboard_id: int, request: ShareDashboardRequest,
                          _user: dict = Depends(get_current_user)):
    d = await _adb(_db_manager.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    # SECURITY 2026-08-17: this mints a PUBLIC, anonymously-readable link
    # (GET /api/shared-dashboard/{token}) -- only the owner may do that.
    _require_query_own(d, _user)
    expires_at = None
    if request.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=request.expires_hours)
    share = await _adb(_db_manager.create_dashboard_share, dashboard_id, _user.get("username"), expires_at)
    return share


@router.get("/api/dashboards/{dashboard_id}/shares")
async def list_dashboard_shares(dashboard_id: int, _user: dict = Depends(get_current_user)):
    """List a dashboard's share tokens (owner or admin).

    2026-08-23: dashboard shares could be MINTED but never listed or revoked --
    a leaked public link was permanent.  Tokens are bearer credentials, so this
    is owner/admin-only, mirroring the query-share ``/shares`` route.
    """
    d = await _adb(_db_manager.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _require_query_own(d, _user)
    from core import dashboard_shares as _dash_shares
    return await _adb(_dash_shares.list_dashboard_shares, _db_manager, dashboard_id)


@router.delete("/api/dashboards/{dashboard_id}/shares/{token}")
async def revoke_dashboard_share(dashboard_id: int, token: str,
                                 _user: dict = Depends(get_current_user)):
    """Revoke a dashboard share token (owner or admin).

    2026-08-23: there was NO way to kill a public dashboard link.  An admin can
    revoke ANY dashboard's shares here -- the concrete control for when the user
    who minted a share leaves.  The token is bound to ``dashboard_id`` first
    (404, not 403, on a foreign token) so this is not a cross-dashboard revoke
    oracle, matching the widget-IDOR fix shape.
    """
    d = await _adb(_db_manager.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _require_query_own(d, _user)
    share = await _adb(_db_manager.get_dashboard_share_by_token, token)
    if not share or share.get("dashboard_id") != dashboard_id:
        raise HTTPException(status_code=404, detail="Share link not found")
    from core import dashboard_shares as _dash_shares
    await _adb(_dash_shares.deactivate_dashboard_share, _db_manager, token)
    audit_event(_db_manager, _user, None, "revoke_dashboard_share", "dashboard_share", token)
    return {"message": "Share revoked"}


@router.get("/api/shared-dashboard/{token}")
async def get_shared_dashboard(token: str):
    """Public endpoint — no auth required.

    2026-10-26: the link's validity is ONE rule
    (``core.dashboard_shares.validate_dashboard_share_token``), shared with
    the finance-report tile routes a dashboard link may run
    (``api/business_reports_api.py``, "A finance report on a SHARED
    DASHBOARD").
    """
    from core.dashboard_shares import validate_dashboard_share_token
    share = await _adb(validate_dashboard_share_token, _db_manager, token)
    await _adb(_db_manager.increment_dashboard_share_access, token)
    d = await _adb(_db_manager.get_dashboard, share["dashboard_id"])
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard no longer exists")
    widgets = await _adb(_db_manager.list_widgets, share["dashboard_id"])
    return {"dashboard": d, "widgets": widgets, "share": share}


# ── Executions Endpoints ───────────────────────────────────────────────────────

@router.get("/api/executions")
async def list_executions(
    limit: int = FastQuery(default=50, ge=1, le=500),
    offset: int = FastQuery(default=0, ge=0),
    status: Optional[str] = None,
    q: Optional[str] = None,
    include_total: bool = False,
    _user: dict = Depends(get_current_user),
):
    """List recent query executions.

    Admins/super-admins see all executions.
    Normal users see only their own (matched by executed_by).

    FB-49 (2026-09-20).  ``q`` is a free-text filter over the execution id,
    who ran it, and the error text -- the three columns a search here can
    honestly reach (``query_config`` is JSON and not portably searchable);
    the UI names them so nobody reads an empty result as "no such query".

    ``include_total=true`` answers with an ENVELOPE --
    ``{items, total, limit, offset}`` -- instead of a bare list.  The
    default stays the bare list deliberately: this is a documented REST
    route that external consumers hold, and changing its shape under them
    to fix a UI pager would be the wrong trade.  The total comes from the
    SAME predicate as the page (``DatabaseManager._executions_filtered``),
    so the pager can never say "51-100 of 40".
    """
    try:
        executed_by_filter = None
        if not is_admin_like(_user):
            executed_by_filter = _user.get("user_id") or _user.get("username") or ""
        executions = await _adb(_db_manager.list_executions, 
            limit=limit,
            offset=offset,
            status=status if status else None,
            executed_by=executed_by_filter,
            q=q or None,
        )
        if not include_total:
            return executions
        total = await _adb(_db_manager.count_executions,
            status=status if status else None,
            executed_by=executed_by_filter,
            q=q or None,
        )
        return {"items": executions, "total": total,
                "limit": limit, "offset": offset}
    except Exception as e:
        logger.error(f"Error listing executions: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: ``GET /api/executions/active`` lives in execute_api.py:8061 and was
# shadowed by the parametrised route below — this router is included nine
# routers earlier (main.py:1286 vs :1295) and Starlette returns on the FIRST
# match, so the request resolved execution_id="active" and 404'd permanently.
# No shim is needed: main.py orders the assembled route table so literal paths
# are matched before parametrised ones. Adding one here would be a SECOND
# mechanism for the same fact, and the pair would drift.
@router.get("/api/executions/{execution_id}")
async def get_execution_record(execution_id: str, _user: dict = Depends(get_current_user)):
    """Get a single execution record by ID.

    Admins see any execution. Normal users can only access their own.
    """
    try:
        execution = await _adb(_db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        # Non-admin users can only see their own executions
        if not is_admin_like(_user):
            user_id = _user.get("user_id") or _user.get("username") or ""
            if execution.get("executed_by") != user_id:
                raise HTTPException(status_code=404, detail="Execution not found")
        return execution
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# 2026-09-24: GET /api/executions/{execution_id}/status lived here AND in
# execute_api.py.  This copy won the route table, so the richer one never
# answered and the two disagreed on who may read an execution.  It lives in
# execute_api.py only; tests/test_one_route_per_path_2026_09_24.py fails the
# build if any method+path is registered twice again.

@router.post("/api/executions/{execution_id}/cancel")
async def cancel_execution(execution_id: str, _user: dict = Depends(get_current_user)):
    """
    Cancel a running execution.
    Works by:
      1. Setting the threading.Event — stops the worker thread after the current chunk.
      2. Cancelling the asyncio.Task — stops the coroutine waiting on run_in_executor.
      3. Marking the DB record as cancelled immediately.
    """
    try:
        execution = await _adb(_db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        # Non-admin users can only cancel their own executions
        if not is_admin_like(_user):
            user_id = _user.get("user_id") or _user.get("username") or ""
            if execution.get("executed_by") != user_id:
                raise HTTPException(status_code=404, detail="Execution not found")

        status = execution.get("status", "")
        if status not in ("pending", "processing"):
            return {
                "execution_id": execution_id,
                "message": f"Cannot cancel — execution is already {status}"
            }

        # 0. BF-585 (2026-05-29): cancel a queue-waiting execution first.
        # If the query is sitting in the BF-584 per-user queue, it has
        # no worker_pool task and no cancel_event yet — only the queue
        # cancel event can abort the wait.  Returns True when the
        # execution was queued; False when it wasn't (falls through to
        # the normal cancel paths below).
        _queued_hit = False
        try:
            from api.execute_api import cancel_queued_execution as _cancel_queued
            _queued_hit = bool(_cancel_queued(execution_id))
        except Exception:
            pass  # Fail-open — never block normal cancel on this.

        # 1. Signal cancellation — route depends on executor mode
        # 2026-08-02 multi-pod correctness: track whether the cancel was
        # actually EFFECTED on this pod.  With >1 replica the running task
        # usually lives on another pod — claiming success without either a
        # local hit or a durable record made the DB lie ("cancelled" while
        # the query kept running elsewhere).
        from core.config import executor as _exec_cfg
        _local_hit = _queued_hit
        _external_mode = _exec_cfg.mode == "external"
        if _external_mode:
            # External executor: the task queue is a durable SHARED cancel
            # channel — the claiming executor polls it (unchanged).
            from core.queue_backend import get_task_queue
            get_task_queue().request_task_cancel(execution_id)
        else:
            # Embedded mode: signal every local handle (worker pool +
            # legacy registries) via the single router chokepoint.
            from core.cancel_router import signal_local_cancel
            if signal_local_cancel(execution_id):
                _local_hit = True

        # 2. Mark as cancelled in DB immediately (don't wait for thread/executor to stop).
        # When NOTHING local was found in embedded mode (multi-pod: the task
        # runs on another pod), the SAME write durably records the cancel
        # request — every pod's cancel watcher polls the flag and the OWNING
        # pod signals its local task; the flag also makes 'cancelled' sticky
        # against a late 'completed' overwrite (see update_execution).
        # N=1 local-hit path: kwargs identical to before this change.
        _upd_kwargs = {"status": "cancelled",
                       "error_message": "Cancelled by user"}
        if not _local_hit and not _external_mode:
            _upd_kwargs["cancel_requested"] = True
        await _adb(_db_manager.update_execution,
            execution_id,
            **_upd_kwargs
        )

        if _ws_manager:
            _exec_user = execution.get("executed_by", "")
            await _ws_manager.broadcast_to_user(_exec_user, {
                "type": "execution_cancelled",
                "execution_id": execution_id,
                "username": _exec_user,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

        await _adb(_db_manager.audit, "system", "cancel_query", resource_type="execution",
                          resource_id=execution_id)
        return {"execution_id": execution_id, "message": "Execution cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling execution {execution_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: /api/exports lives in api/admin_api.py
