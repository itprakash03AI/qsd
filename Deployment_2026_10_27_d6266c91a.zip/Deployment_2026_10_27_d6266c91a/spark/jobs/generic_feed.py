"""
Generic Feed Spark Job — Phase 128 + Phase 130 hotfix-13.

Pluggable source → transform → destination pipeline with optional
cross-source combine (UNION ALL BY NAME or JOIN).

Sources (extensible):
  s3_parquet  -> Read parquet from S3
  s3_csv      -> Read CSV from S3
  jdbc        -> Read from any JDBC database (Oracle, PostgreSQL, MySQL, etc.)
  raw_sql     -> Run inline SQL against a JDBC source
  sql_file    -> Run a stored .sql file's contents against a JDBC source
                 (content pre-resolved into query_params by the DAG factory)
  auto        -> Auto-detect format from file extension

Destinations (extensible):
  s3          -> Write to S3 (parquet/csv)
  oracle      -> Write to Oracle via JDBC
  sftp        -> Write to SFTP server
  local       -> Write to pod-local / NFS path

Transform rules: WHERE → SELECT → CAST → DEDUP → custom_sql (same as ETL).

Serialized source plan (2026-08-04 — PREFERRED):
  When the conf carries ``source_plan`` (produced by
  backend/core/feed/airflow_plan.py from the SAME core.feed.source_plan
  chokepoint the native + Spark Connect backends consume), this job
  EXECUTES the plan verbatim — per-side SQL, connections, combine mode —
  and never re-resolves sources.  This job is a renderer, not a second
  brain; the version gate refuses a plan major it doesn't support.

Cross-source combine (Phase 130 hotfix-13 — LEGACY confs only):
  When the feed config carries ``secondary_connection_id`` and no
  ``source_plan``, this job reads BOTH sides (primary + secondary) and
  combines them in PySpark before transform / output.  Mirrors the native
  DuckDB combine in core.executors.cross_source_combine — same UNION ALL
  BY NAME and JOIN semantics, same overlap-column suffix disambiguation,
  same right-key drop.  KEPT IN SYNC BY DISCIPLINE — which is why new
  confs ship a resolved plan instead.

Usage:
    spark-submit generic_feed.py \
        --feed-config '{"source_type": "s3_parquet", ...}' \
        --execution-id feed-abc123 \
        --callback-url http://querystudio-api:8000/api/webhooks/feed-complete
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import logging
import os
import sys
import time
from typing import Optional

# THE Oracle destination identifier rule (FB-59, 2026-09-21).  This module
# is a BYTE-IDENTICAL MIRROR of backend/core/feed/oracle_identifiers.py:
# this job runs in its own image and cannot import backend/core, so the
# rule is copied and a backend guard fails the suite the moment the two
# copies differ.  Imported at module scope, and deliberately NOT guarded
# by a try/except: a pod that cannot find the rule must die at start, not
# fall back to a second answer about what a column is called.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from qs_oracle_identifiers import (  # noqa: E402
    canonical_oracle_columns, resolve_oracle_columns,
)
# THE missing-table rule and the all-or-nothing rule for an Oracle
# destination (2026-10-07) -- same arrangement: a byte-identical mirror of
# backend/core/feed/oracle_destination_table.py, imported unguarded.
from qs_oracle_destination_table import (  # noqa: E402
    ensure_oracle_table, max_error_percent, refuse_time_columns,
    stage_column_types, staging_table_name, time_columns_in_jdbc,
    write_through_stage,
)
# THE SFTP auth rule (AQD-10/11, 2026-09-23) -- same arrangement: a
# byte-identical mirror of backend/core/feed/sftp_auth.py.  A configured key
# that cannot be loaded REFUSES; it never falls back to a password.
from qs_sftp_auth import resolve_sftp_auth  # noqa: E402
# THE output rules of a feed file and THE delivery protocol (2026-10-07,
# the feed lane contract, K1/K4/K5) -- byte-identical mirrors of
# backend/core/feed/lane_output.py and backend/core/feed/delivery_protocol.py,
# the modules the native renderers and transports call.  This job renders
# CSV / JSON lines on the DRIVER with the native writer and sends them with
# the native protocol, so a counterparty's bytes no longer depend on which
# lane the size router picked.
from qs_lane_output import (  # noqa: E402
    LANE_OUTPUT_VERSION, csv_physical_rows, lines_physical_rows,
    render_rows, spark_output_casts, time_refused_for,
)
from qs_lane_output import streamable_reason  # noqa: E402
from qs_delivery_protocol import sftp_publish_parts  # noqa: E402
from qs_delivery_protocol import (  # noqa: E402
    local_target, publish_local, receipt as delivery_receipt,
    resolve_local_destination, s3_object_key, sftp_publish, verify_size,
)
# 2026-10-10 -- THE merge of two sides by column name (the native lane's
# core/feed/merge_by_name.py, mirrored): case-insensitive match, the
# primary's order and spelling, typed NULLs for a side's missing column,
# a REFUSAL on an incompatible same-named column.
from qs_merge_by_name import (  # noqa: E402
    cross_source_record as _cross_source_record,
    plan_merge as _plan_merge,
)
# 2026-10-11 -- THE per-side reported-rows certification (the native lane's
# core/feed/reported_rows_certification.py, mirrored): each side's rows vs
# the upstream message's ROW_COUNT, judged BEFORE anything is written.
from qs_reported_rows_certification import (  # noqa: E402
    failure_sentence as _rr_failure_sentence,
    judge as _rr_judge,
)

# ── The driver log is the operator's story of one run (2026-09-14) ─────
#
# Every QueryStudio line carries the SAME tag and the execution id, so
# ``kubectl logs <driver> | grep '[feed '`` is the whole narrative of one
# run and nothing else; Spark's own JVM logging is set to WARN by the
# image's /opt/spark/conf/log4j2.properties (see spark/Dockerfile), so
# the narrative is no longer buried in the executor-allocation firehose.
# The stage words are stable (START, SOURCE, READ, TRANSFORM, WRITE,
# MANIFEST, CALLBACK, DONE) -- a reader greps for them, a dashboard can
# parse them.  Nothing here ever prints the config or a credential: the
# JDBC url the driver prints carries host/port/service only, and the
# credentials arrive through the mounted Secret, never on a line.


class _RunTag(logging.Filter):
    """Stamps ``feed_exec`` on every record so the format can carry it."""
    exec_id = "-"

    def filter(self, record):
        record.feed_exec = self.exec_id
        return True


_RUN_TAG = _RunTag()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [feed %(feed_exec)s] %(levelname)s %(message)s",
    stream=sys.stderr,
)
for _h in logging.getLogger().handlers:
    _h.addFilter(_RUN_TAG)
# py4j's python side chatters at INFO about every gateway callback.
logging.getLogger("py4j").setLevel(logging.WARNING)
logger = logging.getLogger("generic_feed")


class _LineCollector(logging.Handler):
    """The job's own lines (this logger only -- never Spark's JVM chatter,
    never a credential: nothing here logs one), kept for the next progress
    report so the run-log dialog shows them live (2026-10-14)."""
    MAX = 5000

    def __init__(self):
        super().__init__(level=logging.INFO)
        import collections
        import threading
        self._lines = collections.deque(maxlen=self.MAX)
        self._lock = threading.Lock()
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))

    def emit(self, record):
        try:
            line = self.format(record)
        except Exception:                                     # noqa: BLE001
            return
        with self._lock:
            self._lines.append(line)

    def drain(self) -> list:
        with self._lock:
            out = list(self._lines)
            self._lines.clear()
        return out


_LINES = _LineCollector()
logger.addHandler(_LINES)
# the job's own story is INFO, whatever the root logger says
logger.setLevel(logging.INFO)


def _pod_identity() -> tuple:
    """(pod name, attempt) from the environment Kubernetes gives the
    driver: HOSTNAME is the pod name, and the workload name carries the
    attempt as ``-r{n}`` (core/spark_k8s/manifest.py::cr_name_for)."""
    import re as _re
    pod = os.environ.get("HOSTNAME") or ""
    m = _re.search(r"-r(\d+)(?:-driver)?$", pod)
    return pod, (int(m.group(1)) if m else 0)


#: The env var the submitter sets to where the conf file is mounted
#: (core/spark_k8s/manifest.py::FEED_CONFIG_FILE_ENV).
FEED_CONFIG_FILE_ENV = "FEED_CONFIG_FILE"
#: Legacy: the whole conf as ONE env string (a submitter before 2026-10-11).
FEED_CONFIG_ENV = "FEED_CONFIG_JSON"


def load_feed_config(feed_config_arg: str) -> dict:
    """The conf this job runs -- from the ONE transport the submitter uses
    (2026-10-11): the per-run Secret's conf key MOUNTED as a file, named by
    the ``--feed-config`` argument, which is now a small REFERENCE
    ``{"feed_config_file", "sha256", "bytes", ...}`` rather than the conf
    itself.  The owner's real plan (two 460-column SQLs + token bindings)
    blew spark-submit's argv ("argument list too long"); one env string
    is capped the same way (131072 bytes) and would have been next.

    The file is TRUSTED only when its sha256 matches the reference: a
    stale or foreign mount is refused, never run.  Older submitters are
    still understood -- ``FEED_CONFIG_JSON`` in the env, or the full conf
    on argv -- so one image serves either side of the rollout.
    """
    import hashlib
    parsed = json.loads(feed_config_arg) if feed_config_arg else {}
    if isinstance(parsed, dict) and parsed.get("feed_config_file"):
        path = os.environ.get(FEED_CONFIG_FILE_ENV) or str(parsed["feed_config_file"])
        try:
            with open(path, "rb") as fh:
                raw = fh.read()
        except OSError as exc:
            raise ValueError(
                f"the feed conf file {path!r} named by --feed-config is not "
                f"readable ({exc}); the per-run Secret must be mounted there") from exc
        digest = hashlib.sha256(raw).hexdigest()
        expected = str(parsed.get("sha256") or "")
        if expected and digest != expected:
            raise ValueError(
                f"the feed conf file {path!r} does not match the reference on "
                f"argv (sha256 {digest[:16]}... != {expected[:16]}...); refusing "
                f"to run a conf this submission did not name")
        config = json.loads(raw.decode("utf-8"))
        logger.info("Loaded feed config from %s (%d bytes, sha256 %s)",
                    path, len(raw), digest[:16])
        return config
    _env_cfg = os.environ.get(FEED_CONFIG_ENV)
    if _env_cfg:
        try:
            config = json.loads(_env_cfg)
            logger.info("Loaded feed config from FEED_CONFIG_JSON env (legacy submitter)")
            return config
        except Exception as exc:
            logger.warning(
                "FEED_CONFIG_JSON present but unparseable (%s) — "
                "falling back to --feed-config arg", exc,
            )
    logger.info("Loaded feed config from the --feed-config argument (legacy submitter)")
    return parsed


def parse_args():
    parser = argparse.ArgumentParser(description="QueryStudio Generic Feed Spark Job")
    parser.add_argument("--feed-config", required=True, help="JSON feed config")
    parser.add_argument("--execution-id", required=True, help="Execution ID for tracking")
    parser.add_argument("--callback-url", default="", help="Webhook URL for completion callback")
    return parser.parse_args()


# ── Source Router (pluggable) ────────────────────────────────────────────

_PARAM_TEMPLATE_RE = __import__("re").compile(r"\{\{(\w+)\}\}")


def _substitute_feed_params(sql: str, config: dict) -> str:
    """Phase 130 hotfix-13 audit fix #5: substitute `{{business_date}}`
    etc. in feed SQL before sending to JDBC / Spark.

    The DAG factory injects calendar-resolved tokens into
    ``config["feed_params"]`` at DAG-build time.  We substitute here
    so the Spark job + JDBC reader see fully-resolved SQL.  Mirrors
    the native path's ``core.feed.param_resolver.apply_to_raw_sql``.

    Tokens left unmatched are preserved (no exception) so a misspelled
    token surfaces in the JDBC error rather than crashing here.
    """
    if not sql or "{{" not in sql:
        return sql
    params = (config or {}).get("feed_params") or {}
    if not params:
        return sql

    def _sql_escape(val: str) -> str:
        return val.replace("'", "''")

    def _repl(m):
        key = m.group(1)
        if key not in params:
            return m.group(0)
        return _sql_escape(str(params[key]))

    return _PARAM_TEMPLATE_RE.sub(_repl, sql)


def _cache_df(df):
    """E-H2: cache/persist a DataFrame so repeated actions (count() +
    write()) don't re-issue the source SQL / re-scan S3.  Fail-safe: if
    the runtime doesn't support .cache() (or the mock in unit tests), the
    original DataFrame is returned unchanged.
    """
    try:
        return df.cache()
    except Exception as exc:  # pragma: no cover — defensive
        logger.debug("cache() unavailable, continuing uncached: %s", exc)
        return df


def _actions_over_the_read(config: dict) -> list:
    """Every action this job will run over the DataFrame it read, by name
    (2026-10-14).  Caching pays only when MORE THAN ONE reads it: the cache
    is materialised by the first action and every later one reads it instead
    of the source.  With ONE reader it is pure cost -- found on the rig's
    pods: a 40M x 460-column run spent 115 minutes materialising a cache
    nothing else read, then its executors were OOM-killed reading the cached
    blocks back beside the CSV renderer.  Mirrors the readers in ``main`` /
    ``apply_transform`` / ``write_output``."""
    acts = ["write"]
    if config.get("reported_side_rows") and not config.get("_cross_source"):
        acts.append("certify reported rows (count)")
    qp = config.get("query_params") or {}
    transform = (config.get("transform_rules") if "transform_rules" in config
                 else qp.get("transform_rules"))
    if transform or (qp.get("jdbc_config") or {}).get("expected_rows") is not None:
        acts.append("transform / reconcile (count)")
    dest = str(config.get("destination_type") or "").lower()
    delivers = job_delivers(config) and not suppressed_run(config)
    if dest == "oracle" and delivers:
        acts.append("oracle string widths (collect)")
    if not dest or not delivers:                   # _write_s3 / _write_local
        written = "parquet" if (dest and not delivers) else str(config.get("output_format") or "csv").lower()
        if written != "parquet":                   # a parquet part dir is counted from its footers
            acts.append("count after write")
    return acts


def _output_compression(config: dict):
    """E-L2: resolve the output compression codec for Spark CSV/JSON writes.

    Reads ``output_options.compression`` (e.g. "gzip", "bzip2", "deflate").
    Returns ``None`` when unset so uncompressed output remains the default
    (no filename / downstream surprises) — the codec is opt-in per feed.
    """
    opts = config.get("output_options") or {}
    codec = opts.get("compression")
    if codec and str(codec).lower() not in ("none", "no", "false", ""):
        return str(codec)
    return None


#: The output-contract keys this lane understands, mapped onto Spark's CSV
#: writer option names.  Kept as data so the parity test can assert the mapping
#: itself rather than the behaviour of one call site.
CSV_OPTION_MAP = {
    "delimiter": "sep",
    "header":    "header",
    "na_rep":    "nullValue",
}


def _contract(config: dict) -> dict:
    """The RESOLVED execution contract QueryStudio shipped, or {}.

    Read in ONE place so "does this job derive a decision?" has a single
    answer.  {} means an older submitter that sent none, and every caller
    below then falls back to its own derivation -- losing a working
    fallback by changing the payload shape would be a worse regression
    than the drift this exists to end.
    """
    c = config.get("execution_contract")
    return c if isinstance(c, dict) and c.get("version") else {}

def _csv_write_options(config: dict) -> dict:
    """The Spark CSV writer options for this feed.

    2026-09-03.  These are RESOLVED BY QUERYSTUDIO and shipped in
    ``--feed-config.csv_dialect.writer_options``; this function applies
    them.  It does not derive anything, and that is the point.

    It used to derive them, from a three-key map, while the native
    renderer derived the same contract separately.  The 2026-09-02
    comment here recorded the previous instance of the resulting drift
    (delimiter honoured on one lane, ignored on the other) and noted
    that encoding, quoting and line terminator were "not reachable on
    EITHER lane yet".  On 2026-09-03 they became reachable natively --
    and this function silently kept emitting the old shape.  Same feed,
    same definition, two different files, no error on either.

    The BRD's rule for this defect class: a capability the author can
    DECLARE must be honoured or REFUSED by every execution lane, never
    quietly downgraded.  Terms Spark's writer cannot express
    (QUOTE_NONNUMERIC, QUOTE_NONE, trailing_delimiter) are refused at
    SUBMIT by core.feed.csv_dialect, so they can never arrive here.

    FALLBACK: an older submitter sends no ``csv_dialect``.  The legacy
    three-key derivation is kept for exactly that case -- a job that
    ignored the delimiter because the payload shape changed would be a
    worse regression than the one being fixed.
    """
    csv_contract = (_contract(config).get("csv") or {})
    if csv_contract.get("writer_options"):
        opts = dict(csv_contract["writer_options"])
        # Spark requires strings; QueryStudio already sends strings, but
        # a payload that crossed JSON keeps ints as ints.
        return {k: (str(v).lower() if isinstance(v, bool) else str(v))
                for k, v in opts.items()}

    # ── legacy path: no dialect in the payload ───────────────────────
    opts = config.get("output_options") or {}
    out = {}
    for key, spark_key in CSV_OPTION_MAP.items():
        if key not in opts or opts[key] is None:
            continue
        value = opts[key]
        out[spark_key] = ("true" if value else "false") \
            if isinstance(value, bool) else str(value)
    out.setdefault("header", "true")
    return out


def _csv_python_options(config: dict) -> tuple:
    """The same contract for the driver-side ``csv`` writer used by the
    SFTP staging path.  Returns ``(delimiter, include_header, na_rep)``.

    Reads the SHIPPED dialect first, for the same reason as the Spark
    writer above: two writers in one job deriving one contract twice is
    the same drift at a smaller scale, and this one produces the file a
    counterparty actually receives over SFTP.
    """
    csv_contract = (_contract(config).get("csv") or {})
    if csv_contract:
        return (str(csv_contract.get("delimiter") or ","),
                bool(csv_contract.get("header", True)),
                str(csv_contract.get("na_rep") or ""))
    opts = config.get("output_options") or {}
    delimiter = opts.get("delimiter") or ","
    include_header = opts.get("header", True)
    na_rep = opts.get("na_rep")
    return str(delimiter), bool(include_header), ("" if na_rep is None else str(na_rep))


def read_source(spark, config: dict):
    """Read source data based on source_type. Returns DataFrame.

    Extensible: add new source types by adding elif branches.
    """
    source_type = config.get("source_type", "s3_parquet")
    query_params = config.get("query_params") or {}

    if source_type == "saved_query" or source_type == "published_view":
        # For saved queries / published views, the source data should be
        # provided as an S3 path by the DAG factory (pre-extracted)
        source_path = query_params.get("source_path", "")
        if not source_path:
            raise ValueError(f"source_type={source_type} requires query_params.source_path")
        return _read_s3_auto(spark, source_path)

    elif source_type == "raw_sql":
        # Raw SQL against a JDBC source
        jdbc_config = query_params.get("jdbc_config") or {}
        sql = query_params.get("sql", "")
        if not sql:
            raise ValueError("raw_sql source requires 'sql' in query_params")
        # Phase 130 hotfix-13 audit fix #5: substitute {{}} tokens
        # (business_date, prev_business_day, etc.) before sending the
        # SQL to the JDBC driver.  feed_params are computed by the DAG
        # factory using the native param resolver.
        sql = _substitute_feed_params(sql, config)
        return _read_jdbc(spark, jdbc_config, sql,
                          destination_type=_time_destination(config))

    elif source_type == "sql_file":
        # A SqlFile source is a STORED .sql file whose CONTENTS are the query.
        # In the PRIMARY (native / Spark Connect) path the server loads the
        # file content from the SqlFile DB record + NFS storage dir and treats
        # it as raw_sql (see core.feed_engine._execute_spark_connect,
        # source_type=="sql_file": "load content, treat as raw_sql").  This
        # DETACHED Spark-batch fallback cannot reach the QueryStudio DB / NFS
        # storage dir, so the DAG factory must PRE-RESOLVE the .sql content
        # into the feed config's query_params — exactly the way it already
        # injects jdbc_config for raw_sql/jdbc sources.  Execution here is
        # IDENTICAL to the raw_sql branch: {{token}} substitution → JDBC
        # sub-query via _read_jdbc.
        jdbc_config = query_params.get("jdbc_config") or {}
        # Accept the resolved SQL under the same key raw_sql uses ('sql'),
        # plus a couple of explicit aliases the factory might populate.
        sql = (
            query_params.get("sql")
            or query_params.get("sql_text")
            or query_params.get("sql_content")
            or query_params.get("query")
            or ""
        )
        if not (sql and sql.strip()):
            # Convenience: if the factory passed a driver-readable path to the
            # .sql file (e.g. a shared NFS mount visible to the driver) instead
            # of inlining the content, read it here.
            sql_path = query_params.get("sql_file_path") or query_params.get("source_path")
            if sql_path and os.path.isfile(sql_path):
                logger.info("sql_file source: reading SQL from driver-local path %s", sql_path)
                with open(sql_path, "r", encoding="utf-8") as _sf:
                    sql = _sf.read()
        if not (sql and sql.strip()):
            # Fail LOUD — never silently produce empty output.  Name exactly
            # what the detached job needs so the operator can fix the factory.
            raise ValueError(
                "sql_file source requires the resolved SQL text in query_params "
                "(one of 'sql' / 'sql_text' / 'sql_content' / 'query') or a "
                "driver-readable 'sql_file_path'.  The detached Spark-batch "
                "fallback cannot load the SqlFile record from the QueryStudio "
                "DB / NFS storage — the DAG factory must pre-resolve the .sql "
                "file content into the feed config before submitting the job."
            )
        sql = _substitute_feed_params(sql, config)
        return _read_jdbc(spark, jdbc_config, sql,
                          destination_type=_time_destination(config))

    elif source_type == "s3_parquet":
        source_path = query_params.get("source_path", "")
        if not source_path:
            raise ValueError("s3_parquet source requires query_params.source_path")
        logger.info("Reading parquet from: %s", source_path)
        return spark.read.parquet(source_path)

    elif source_type == "s3_csv":
        source_path = query_params.get("source_path", "")
        if not source_path:
            raise ValueError("s3_csv source requires query_params.source_path")
        csv_opts = query_params.get("csv_options") or {}
        header = csv_opts.get("header", True)
        delimiter = csv_opts.get("delimiter", ",")
        infer_schema = csv_opts.get("infer_schema", True)
        logger.info("Reading CSV from: %s (header=%s, delim=%s)", source_path, header, delimiter)
        return spark.read.csv(
            source_path, header=header, inferSchema=infer_schema, sep=delimiter,
        )

    elif source_type == "jdbc":
        jdbc_config = query_params.get("jdbc_config") or {}
        table = query_params.get("table", "")
        if not table and not query_params.get("sql"):
            raise ValueError("jdbc source requires query_params.table or query_params.sql")
        sql = query_params.get("sql")
        return _read_jdbc(spark, jdbc_config, sql, table,
                          destination_type=_time_destination(config))

    elif source_type == "iceberg":
        # FR-SRC-03 (2026-09-02) — catalog-based Iceberg read.  The old
        # answer here was "scan the prefix as parquet", which is
        # snapshot-blind and DELETE-BLIND: a merge-on-read table's
        # positional/equality deletes were never applied, silently
        # overcounting.  The catalog read does not have that defect.
        return _read_iceberg(spark, config)

    elif source_type == "auto":
        source_path = query_params.get("source_path", "")
        if not source_path:
            raise ValueError("auto source requires query_params.source_path")
        return _read_s3_auto(spark, source_path)

    else:
        raise ValueError(f"Unsupported source_type: {source_type}")


# ── Iceberg source (FR-SRC-02..04, 2026-09-02) ──────────────────────────
#
# PORT of the proven in-house production configuration in
# ETL/steps/s3/s3_base_step.py::_configure_iceberg_catalog (REST / Glue /
# Hive), not greenfield.  The runtime jars are baked into the pinned image
# (spark/Dockerfile) and the SparkApplication CR carries the same conf
# keys (core/spark_k8s/iceberg.py::iceberg_spark_conf) so the session is
# BORN with the extensions; the _configure calls below are defence in
# depth for catalogs (which Spark registers lazily) so a hand-submitted
# job without the CR conf still reads correctly or fails loudly.

ICEBERG_CATALOG_TYPES = ("rest", "glue", "hive")


def _iceberg_session_conf(ice: dict) -> dict:
    """The catalog conf keys for one resolved Iceberg read config —
    byte-for-byte the grammar of s3_base_step._configure_iceberg_catalog,
    flattened from builder calls to conf key/value pairs."""
    name = ice.get("catalog_name") or "iceberg_catalog"
    ctype = ice.get("catalog_type")
    conf = {
        f"spark.sql.catalog.{name}": "org.apache.iceberg.spark.SparkCatalog",
    }
    if ctype == "rest":
        conf[f"spark.sql.catalog.{name}.type"] = "rest"
        conf[f"spark.sql.catalog.{name}.uri"] = ice.get("catalog_uri", "")
    elif ctype == "glue":
        conf[f"spark.sql.catalog.{name}.catalog-impl"] = \
            "org.apache.iceberg.aws.glue.GlueCatalog"
    elif ctype == "hive":
        conf[f"spark.sql.catalog.{name}.type"] = "hive"
        conf[f"spark.sql.catalog.{name}.uri"] = ice.get("catalog_uri", "")
    else:
        raise ValueError(
            f"iceberg source: unknown catalog_type {ctype!r} "
            f"(supported: {', '.join(ICEBERG_CATALOG_TYPES)})")
    warehouse = ice.get("warehouse", "")
    if warehouse:
        conf[f"spark.sql.catalog.{name}.warehouse"] = warehouse
    return conf


def _iceberg_pin_option(spark) -> str:
    """The reader option that pins an Iceberg snapshot ON THIS SPARK.

    2026-10-19, measured on Docker: Spark 4.2 + Iceberg 1.13 REFUSES
    ``snapshot-id`` ("Time travel option `snapshot-id` is no longer supported,
    use Spark built-in `versionAsOf` instead"), while Spark 3.5 + Iceberg 1.6.1
    accepts ``versionAsOf`` on a DataFrameReader and IGNORES it -- the read
    returned the CURRENT snapshot (18,000 rows) instead of the pinned one
    (20,000).  So the option is chosen by version, never one spelling for both:
    a silently ignored pin reads data the plan did not pick."""
    try:
        major, minor = (int(x) for x in str(spark.version).split(".")[:2])
    except Exception:                                      # noqa: BLE001
        return "snapshot-id"
    return "versionAsOf" if (major, minor) >= (4, 2) else "snapshot-id"


def _read_iceberg(spark, config: dict):
    """Read one Iceberg table AT ITS PINNED SNAPSHOT.

    Refusals are LOUD and per-field (the shape the proven
    ETL/s3_config_loader validator uses) — a missing catalog URI or
    warehouse must fail HERE with a checklist, never surface later as a
    Spark ClassNotFound / connection error that reads as infrastructure
    breakage.

    FR-SRC-04: ``snapshot_id`` is MANDATORY.  It is pinned by the backend
    at PLAN time (core/spark_k8s/iceberg.py::pin_snapshot_id) so this run
    reads the snapshot it was ADMITTED against.  A config without one is
    refused — running would read whatever HEAD is at executor start,
    silently including data that arrived mid-flight.
    """
    query_params = config.get("query_params") or {}
    ice = query_params.get("iceberg") or {}
    if not ice:
        raise ValueError(
            "iceberg source requires query_params.iceberg (built by "
            "core/spark_k8s/feed_conf.py from the connection record + "
            "spark_k8s.iceberg config) — refusing to guess a catalog.")

    ctype = str(ice.get("catalog_type") or "").lower()
    missing = []
    if ctype not in ICEBERG_CATALOG_TYPES:
        missing.append(
            f"catalog_type={ctype!r} not recognised (use: "
            f"{' | '.join(ICEBERG_CATALOG_TYPES)})")
    if not ice.get("table"):
        missing.append("table  (the '<namespace>.<table>' identifier)")
    if ctype in ("rest", "hive") and not ice.get("catalog_uri"):
        missing.append(f"catalog_uri  (required for a {ctype} catalog)")
    if not ice.get("warehouse"):
        missing.append("warehouse  (e.g. s3a://bucket/warehouse)")
    if ice.get("snapshot_id") in (None, ""):
        missing.append(
            "snapshot_id  (FR-SRC-04: pinned at plan time — a run must "
            "read the snapshot it was ADMITTED against, never whatever "
            "HEAD is at executor start.  Refusing to run unpinned.)")
    if missing:
        bullets = "\n".join(f"  * {m}" for m in missing)
        raise ValueError(
            f"iceberg source: missing/invalid required field(s) in "
            f"query_params.iceberg:\n{bullets}")

    catalog_name = ice.get("catalog_name") or "iceberg_catalog"
    for key, value in _iceberg_session_conf(ice).items():
        # Defence in depth: catalogs are registered lazily, so setting
        # their conf on the live session works when the CR carried
        # nothing.  spark.sql.extensions can NOT be set post-creation —
        # that one only the CR/spark-submit conf provides (it is needed
        # for DDL/procedures, not for reads).
        spark.conf.set(key, value)

    snapshot_id = str(ice["snapshot_id"])
    identifier = f"{catalog_name}.{ice['table']}"
    logger.info("Reading Iceberg table %s at PINNED snapshot %s (%s catalog)",
                identifier, snapshot_id, ctype)
    return (
        spark.read.format("iceberg")
        .option(_iceberg_pin_option(spark), snapshot_id)
        .load(identifier)
    )


# ── Serialized source plan execution (2026-08-04) ────────────────────────
#
# The backend resolves the feed's source shape ONCE (through
# core.feed.source_plan — the same chokepoint the native + Spark Connect
# paths consume) and serializes the result into the conf as
# ``source_plan`` (see backend/core/feed/airflow_plan.py for the format).
# When a plan is present, THIS job executes it verbatim — it does not
# re-resolve sources, does not re-derive the secondary side, and does not
# guess which section of a .sql file to run.  The legacy read_source /
# maybe_combine_sources path below remains for confs WITHOUT a plan
# (old backend images, hand-authored s3_parquet/jdbc configs) and is
# byte-identical to before.
#
# Version contract: ``plan_version`` is "major.minor".  A major this job
# doesn't support → LOUD refusal (an old job must never silently misread
# a newer plan; an operator sees "upgrade the Spark job image", not a
# half-wrong feed).  Higher minors are additive and accepted.

SUPPORTED_PLAN_MAJOR = 1


def _require_supported_plan(plan: dict) -> None:
    """Refuse loudly on a plan this job image cannot faithfully execute."""
    version = str(plan.get("plan_version") or "")
    parts = version.split(".")
    try:
        major = int(parts[0])
    except (ValueError, IndexError):
        raise ValueError(
            f"source_plan.plan_version {version!r} is not 'major.minor' — "
            f"refusing to guess.  The conf producer and this Spark job image "
            f"disagree on the plan format; align the images."
        )
    if major != SUPPORTED_PLAN_MAJOR:
        raise ValueError(
            f"source_plan.plan_version {version!r} has major {major}, but "
            f"this generic_feed.py image supports major "
            f"{SUPPORTED_PLAN_MAJOR}.  Refusing to execute rather than "
            f"misinterpret the plan (a misread here can silently emit "
            f"partial or wrong data and certify it COMPLETE).  Fix: deploy "
            f"the Spark job image matching the QueryStudio backend version."
        )


#: Hive partition types (the backend's decision) -> Spark SQL types
_PARTITION_SPARK_TYPES = {"VARCHAR": "string", "DATE": "date", "BIGINT": "bigint",
                          "INTEGER": "int", "DOUBLE": "double", "TIMESTAMP": "timestamp",
                          "BOOLEAN": "boolean"}


#: Every scheme a writer records for an S3 object.  Trino / Starburst write
#: ``s3://`` into Iceberg metadata, Spark ``s3a://``, older Hadoop ``s3n://``;
#: the backend's reader accepts all three (core/duckdb_views.py
#: ``_iceberg_file_read_url``), so this job reads all three through ONE
#: filesystem -- S3A, with the per-bucket credentials ``_apply_bucket_s3a``
#: set (S3A keys them by bucket, whatever the scheme).
_S3_SCHEMES = ("s3", "s3a", "s3n")


def _read_parquet_with_the_reference_reader(spark) -> None:
    """Parquet files OTHER engines wrote are read by the REFERENCE row reader
    (parquet-mr), never Spark's vectorized one (2026-10-14, the rig's pods):
    Trino's Hive writer (parquet-mr-trino) stores strings as
    DELTA_LENGTH_BYTE_ARRAY, and Spark 3.5's vectorized reader returned them
    CUT AND SHIFTED ('3b1p6' for '3b1p6827') -- 14,282 rows where the truth
    is 12,600, no error raised.  A wrong file certified is worse than a
    slower one.  Set for the whole job session (every parquet read of it);
    the backend's Spark Connect sessions set the same
    (core/spark_connect_session_manager.py)."""
    spark.conf.set("spark.sql.parquet.enableVectorizedReader", "false")


def _s3_schemes_through_s3a(spark) -> None:
    hconf = spark._jsc.hadoopConfiguration()
    for scheme in _S3_SCHEMES:
        hconf.set(f"fs.{scheme}.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        hconf.set(f"fs.AbstractFileSystem.{scheme}.impl", "org.apache.hadoop.fs.s3a.S3A")


def _read_tables_side(spark, plan_side: dict, which: str):
    """A ``tables`` side (plan 1.1, backend ``core/feed/read_plan.py``): the
    backend decided what each table reads; this job registers each as a view
    and runs the side's Spark SQL over them.  It decides nothing itself:

    * iceberg -- Iceberg's own reader on the planned METADATA FILE at the
      planned SNAPSHOT (deletes applied, schema by field id; no catalog);
    * parquet -- the table's base folder (Spark's reader applies the same
      hidden-file rule as the backend's planner), partition values read as
      text and cast to the backend's decided types; Spark's input-file count
      must equal the planned count, else the side FAILS."""
    _s3_schemes_through_s3a(spark)
    for bucket, ident in (plan_side.get("storage") or {}).items():
        _apply_bucket_s3a(spark, bucket, ident or {}, f"{which} source")
    spark.conf.set("spark.sql.sources.partitionColumnTypeInference.enabled", "false")
    _read_parquet_with_the_reference_reader(spark)
    for t in plan_side.get("tables") or []:
        name, layout = t.get("name"), t.get("layout")
        if layout == "iceberg":
            # Iceberg's VECTORIZED reader (1.6) decodes a subset of Parquet's
            # encodings; Trino / Starburst write Parquet v2 strings as
            # DELTA_LENGTH_BYTE_ARRAY and that reader refuses them mid-scan
            # ("Cannot support vectorized reads").  The failure is lazy (at
            # the first action), so no fallback can be decided here; the row
            # reader decodes every encoding, whoever wrote the file.
            df = (spark.read.format("iceberg")
                  .option(_iceberg_pin_option(spark), str(t["snapshot_id"]))
                  .option("vectorization-enabled", "false")
                  .load(t["metadata_location"]))
            logger.info("TABLE %s: iceberg %s at snapshot %s (planned %s data / %s delete files)",
                        name, t["metadata_location"], t["snapshot_id"],
                        t.get("planned_data_files"), t.get("delete_files"))
        elif layout == "parquet":
            df = spark.read.option("basePath", t["base_path"]).parquet(t["base_path"])
            for col, typ in (t.get("partition_types") or {}).items():
                spark_type = _PARTITION_SPARK_TYPES.get(str(typ).upper(), "string")
                if col in df.columns:
                    df = df.withColumn(col, df[col].cast(spark_type))
            got = len(df.inputFiles())
            want = int(t.get("planned_files") or 0)
            if got != want:
                raise ValueError(
                    f"table {name}: Spark found {got} data files under {t['base_path']}, the "
                    f"plan counted {want} -- the two readers disagree on what the table is; "
                    f"refusing rather than reading a different set")
            logger.info("TABLE %s: parquet %s, %d files (= planned), partitions %s",
                        name, t["base_path"], got, t.get("partition_types"))
        else:
            raise ValueError(f"source_plan {which} side: table {name!r} has layout "
                             f"{layout!r}; this job reads iceberg and parquet")
        df.createOrReplaceTempView(str(name))
    sql = plan_side.get("sql") or ""
    if not sql.strip():
        raise ValueError(f"source_plan {which} side carries empty SQL")
    logger.info("source_plan: running the %s side's SQL over %d table(s) (read as %s, run as spark)",
                which, len(plan_side.get("tables") or []),
                (plan_side.get("sql_translation") or {}).get("from"))
    return spark.sql(sql)


def _order_spec_items(spec) -> list:
    """The planner's ``order_within`` ("A, T.B DESC NULLS FIRST" or a list) as
    ``[(column, descending, nulls_first)]`` with the SOURCE engine's null
    ordering: Trino / Starburst sort NULLs LAST unless told otherwise, while
    Spark's ``asc()`` puts them first -- without it the same bucket would
    come out in a different order on the two lanes."""
    items = spec if isinstance(spec, (list, tuple)) else str(spec or "").split(",")
    out = []
    for item in items:
        words = str(item).split()
        if not words:
            continue
        rest = " ".join(w.upper() for w in words[1:])
        out.append((words[0].split(".")[-1].strip('"`'), "DESC" in rest.split(),
                    "NULLS FIRST" in rest))
    return out


def _order_columns(spec) -> list:
    """:func:`_order_spec_items` as Spark sort columns (needs a session)."""
    from pyspark.sql import functions as F
    cols = []
    for name, desc, nulls_first in _order_spec_items(spec):
        c = F.col(name)
        cols.append((c.desc_nulls_first() if nulls_first else c.desc_nulls_last()) if desc
                    else (c.asc_nulls_first() if nulls_first else c.asc_nulls_last()))
    return cols


def _read_plan_side(spark, config: dict, plan_side: dict, which: str):
    """Execute ONE resolved side of the plan.  ``which`` selects where the
    side's JDBC credentials live in the conf (query_params /
    secondary_query_params — injected by the DAG factory / K8s secret)."""
    kind = (plan_side or {}).get("kind")
    if kind == "tables":
        if plan_side.get("partitions"):
            config.setdefault("_partitioned_read", {})[which] = dict(plan_side["partitions"])
        return _read_tables_side(spark, plan_side, which)
    if kind != "sql":
        raise ValueError(
            f"source_plan {which} side has kind={kind!r}; this job image "
            f"executes kind='sql' or 'tables' only.  Refusing rather than guessing."
        )
    sql = plan_side.get("sql") or ""
    if not sql.strip():
        raise ValueError(f"source_plan {which} side carries empty SQL")
    if which == "primary":
        qp = config.get("query_params") or {}
    else:
        qp = config.get("secondary_query_params") or {}
    jdbc_config = qp.get("jdbc_config") or {}
    # Same {{token}} substitution the legacy raw_sql branch performs —
    # calendar tokens (business_date, …) resolve at RUN time from
    # config.feed_params, not at plan-serialization time, so backfills
    # stamp the logical date.
    sql = _substitute_feed_params(sql, config)
    parts = plan_side.get("partitions") or {}
    config.setdefault("_partitioned_read", {})
    if parts:
        config["_partitioned_read"][which] = {k: v for k, v in parts.items() if k != "buckets"}
    buckets = parts.get("buckets") or []
    if buckets:
        # 2026-10-14 -- the partition key the backend planned (the planner
        # QueryStudio's engine uses): one JDBC partition per bucket query,
        # read several at a time across the executors, UNIONED IN BUCKET
        # ORDER -- the parts are written in that order, so the file comes
        # out in sorted key-value order, as on the native lane.  Each bucket
        # is one connection; a numeric partition column does not apply.
        from functools import reduce
        one = {k: v for k, v in jdbc_config.items()
               if k not in ("partition_column", "lower_bound", "upper_bound",
                            "num_partitions", "expected_rows")}
        logger.info("source_plan: reading %s side (%s) via JDBC in %d bucket(s) on %s, "
                    "value order", which, plan_side.get("source_label"), len(buckets),
                    parts.get("partition_column") or parts.get("column"))
        dfs = [_read_jdbc(spark, one, _substitute_feed_params(b["sql"], config),
                          destination_type=_time_destination(config))
               for b in sorted(buckets, key=lambda b: int(b.get("index") or 0))]
        # The order INSIDE a bucket (order_within) is applied HERE: Spark's
        # JDBC reader wraps every query as SELECT * FROM (<query>) SPARK_GEN_
        # SUBQ, and an engine may drop an ORDER BY inside a subquery -- Trino
        # does (found live 2026-10-14: same rows, same buckets, a different
        # order inside each).  One bucket = one partition, so sorting within
        # partitions IS the native lane's order; the union keeps bucket order.
        within = _order_columns(parts.get("order_within"))
        if within:
            dfs = [d.sortWithinPartitions(*within) for d in dfs]
        return reduce(lambda a, b: a.union(b), dfs)
    logger.info(
        "source_plan: reading %s side (%s) via JDBC",
        which, plan_side.get("source_label"),
    )
    return _read_jdbc(spark, jdbc_config, sql,
                      destination_type=_time_destination(config))


def read_from_plan(spark, config: dict, plan: dict):
    """Execute a serialized source plan: primary side, optional secondary
    side, combine — all driven by the plan, never re-derived from the
    legacy conf keys."""
    _require_supported_plan(plan)
    df = _read_plan_side(spark, config, plan.get("primary") or {}, "primary")
    if plan.get("is_cross"):
        plan_secondary = plan.get("secondary")
        if not plan_secondary:
            raise ValueError(
                "source_plan says is_cross=true but carries no secondary "
                "side — refusing to run single-source (that would emit "
                "half the data and certify it COMPLETE)."
            )
        df2 = _read_plan_side(spark, config, plan_secondary, "secondary")
        combine_mode = (plan.get("combine_mode") or "union").lower()
        logger.info("source_plan: combining via %s",
                    "JOIN" if combine_mode == "join" else "UNION ALL BY NAME")
        df = _combine_cross_source(config, df, df2, combine_mode,
                                   plan.get("join_config") or {})
    return df


# ── Cross-source combine (Phase 130 hotfix-13) ──────────────────────────


VALID_JOIN_TYPES = {"INNER", "LEFT", "RIGHT", "FULL", "CROSS"}
_SUFFIX_PATTERN = __import__("re").compile(r"[A-Za-z0-9_]+")


def _normalise_join_config(join_config: dict):
    """Validate + normalise a JOIN config dict.  Mirrors
    core.executors.cross_source_combine.normalise_join_config.

    Returns (how, left_on, right_on, suffixes).  Raises ValueError on
    invalid type / missing keys / mismatched length.
    """
    if not join_config:
        raise ValueError("join_config required for join mode")

    how = (join_config.get("how", "inner") or "inner").upper()
    if how not in VALID_JOIN_TYPES:
        raise ValueError(
            f"Invalid join type {how!r} — must be one of {VALID_JOIN_TYPES}"
        )

    left_on = join_config.get("left_on")
    right_on = join_config.get("right_on")
    if isinstance(left_on, str): left_on = [left_on]
    if isinstance(right_on, str): right_on = [right_on]
    left_on = list(left_on or [])
    right_on = list(right_on or [])

    if how != "CROSS":
        if not left_on or not right_on:
            raise ValueError("join_config must specify left_on and right_on")
        if len(left_on) != len(right_on):
            raise ValueError(
                f"left_on ({len(left_on)}) and right_on ({len(right_on)}) "
                f"must have same length"
            )

    raw_suffixes = join_config.get("suffixes", ["_primary", "_secondary"])
    suffixes = [
        s for s in (raw_suffixes or [])[:2]
        if isinstance(s, str) and _SUFFIX_PATTERN.fullmatch(s)
    ]
    if len(suffixes) < 2:
        suffixes = ["_primary", "_secondary"]
    return how, left_on, right_on, suffixes


def _union_projection(df, specs):
    """Project one side onto the plan's output columns: a column the side
    has is renamed to the output spelling, a column it lacks is a NULL
    cast to the other side's type.  ``specs`` is
    ``MergePlan.side_specs(side)``; the decision of what each output column
    IS was made there, this only renders it as a DataFrame select."""
    # selectExpr, not pyspark.sql.functions: the same SQL spelling the native
    # lane renders (CAST(NULL AS T) AS out / src AS out), and a DataFrame
    # method only -- no Column objects, so no SparkContext is touched before
    # the frame itself is.
    def _bt(name):
        return "`" + str(name).replace("`", "``") + "`"
    exprs = []
    for src, out, fill in specs:
        if src is None:
            exprs.append(f"CAST(NULL AS {fill or 'string'}) AS {_bt(out)}")
        else:
            exprs.append(f"{_bt(src)} AS {_bt(out)}")
    return df.selectExpr(*exprs)


def _combine_union(df1, df2, plan=None):
    """UNION ALL aligned BY COLUMN NAME -- THE merge plan (qs_merge_by_name,
    the mirror of core/feed/merge_by_name.py), 2026-10-10.  ``plan`` is
    the MergePlan already made for these two sides (``_combine_cross_source``
    discloses it); made here when not given.

    Before this the job called ``unionByName(allowMissingColumns=True)``,
    which matched names by Spark's own case rule, kept Spark's type
    coercion (a decimal under a string became a string, silently) and
    could disagree with the native lane's DuckDB combine.  Now both lanes
    read one plan: the primary's order and spelling, a side's missing
    column a typed NULL, and an incompatible same-named column REFUSES
    (``MergeRefused``, a ValueError) so nothing is delivered.
    """
    if plan is None:
        plan = _plan_merge(list(df1.dtypes), list(df2.dtypes))
    if plan.promotions or plan.renames or plan.secondary_only or plan.primary_only:
        logger.info("merge by name: %s", json.dumps(plan.disclosure(), default=str))
    left = _union_projection(df1, plan.side_specs("primary"))
    right = _union_projection(df2, plan.side_specs("secondary"))
    # Positions now agree by construction; unionByName keeps the check
    # that they do (a drift here is a bug in the plan, and must be loud).
    return left.unionByName(right)


def _combine_join(df1, df2, join_config: dict):
    """JOIN with overlap-column suffix disambiguation + right-key drop.

    Mirrors core.executors.cross_source_combine.build_join_combine_sql.
    """
    how, left_on, right_on, suffixes = _normalise_join_config(join_config)

    # PySpark uses lowercase JOIN identifiers
    spark_how = how.lower()
    if spark_how == "cross":
        joined = df1.crossJoin(df2)
        return joined

    # Build the ON-clause column-pairs.  When both sides share key names
    # we can use the list-of-strings form; otherwise we build explicit
    # Column expressions and rename right_on keys to drop them.
    from pyspark.sql import functions as F

    # Rename overlapping non-key columns on each side BEFORE the join
    # so the result keeps both copies distinguishable.  Right_on keys
    # are renamed too then dropped after the join.
    left_keys_set  = set(left_on)
    right_keys_set = set(right_on)
    left_cols  = list(df1.columns)
    right_cols = list(df2.columns)
    overlap = (set(left_cols) & set(right_cols)) - right_keys_set

    # Apply suffix renames to non-key overlapping columns.
    df1_renamed = df1
    for c in overlap:
        df1_renamed = df1_renamed.withColumnRenamed(c, f"{c}{suffixes[0]}")
    df2_renamed = df2
    for c in overlap:
        df2_renamed = df2_renamed.withColumnRenamed(c, f"{c}{suffixes[1]}")
    # Right-on keys also get a temp rename so we can refer to them
    # without ambiguity in the ON clause, then drop after the join.
    right_key_temp = {rk: f"__rk_tmp__{i}" for i, rk in enumerate(right_on)}
    for rk, tmp in right_key_temp.items():
        df2_renamed = df2_renamed.withColumnRenamed(rk, tmp)

    on_expr = None
    for lk, rk in zip(left_on, right_on):
        tmp = right_key_temp[rk]
        pair = df1_renamed[lk] == df2_renamed[tmp]
        on_expr = pair if on_expr is None else on_expr & pair

    joined = df1_renamed.join(df2_renamed, on=on_expr, how=spark_how)
    # Drop the temp right-key columns (they're equal to left_on by join)
    for tmp in right_key_temp.values():
        if tmp in joined.columns:
            joined = joined.drop(tmp)
    return joined


#: The storage level each SIDE of a merge is kept at while it is counted
#: and combined: serialized on the executors' local disk -- the Spark
#: analogue of the native lane's per-side parquet files.
_SIDE_STORAGE_LEVEL = "DISK_ONLY"


def _persist_side(df):
    from pyspark import StorageLevel
    return df.persist(getattr(StorageLevel, _SIDE_STORAGE_LEVEL))


def _combine_cross_source(config: dict, primary_df, secondary_df,
                          combine_mode: str, join_config: dict = None):
    """Combine the two sides AND record what went in (2026-10-10).

    The native lane materialises each side to parquet, reads the per-side
    row count from the file metadata and writes ``files_metadata.
    cross_source`` (primary_rows / secondary_rows / expected_rows / the
    merge plan's disclosure) -- how an auditor sees ``primary + secondary
    == delivered``.  This job reported nothing: the owner's Kafka-gated
    merge feeds ran correct files through ``--backend spark_k8s`` with
    ``cross_source: {}`` on every execution.

    Here each side is PERSISTED (``_SIDE_STORAGE_LEVEL``: the executors'
    disk, as native's side files are the API pod's disk) and counted --
    ONE read of each source; the combine then reads the persisted sides,
    so ``main`` skips its own cache of the union (two copies for nothing).
    The record is THE shape (``qs_merge_by_name.cross_source_record``, the
    mirror of the module native builds it with), stashed on the conf under
    ``_cross_source`` exactly as the engine stashes it on the feed config;
    ``main`` adds ``combined_rows`` from what the write wrote and ships it
    in the completion callback for the webhook to store.
    """
    mode = str(combine_mode or "union").strip().lower() or "union"
    primary = _persist_side(primary_df)
    secondary = _persist_side(secondary_df)
    p_rows = int(primary.count())
    s_rows = int(secondary.count())
    logger.info("READ sides primary=%d secondary=%d combine=%s", p_rows, s_rows, mode)
    merge = None
    if mode == "join":
        df = _combine_join(primary, secondary, join_config or {})
        combine = "spark_join"
    else:
        plan = _plan_merge(list(primary.dtypes), list(secondary.dtypes))
        merge = plan.disclosure()
        df = _combine_union(primary, secondary, plan)
        combine = "spark_union_by_name"
    config["_cross_source"] = _cross_source_record(
        mode, p_rows, s_rows, merge=merge, combine=combine, lane="spark_k8s")
    return df


def _certify_reported_rows(config: dict, df):
    """The job's count of each side, judged by THE rule (the mirror of
    core/feed/reported_rows_certification.py).  None when the conf declares
    no side (``reported_side_rows`` empty or absent -- an older backend);
    a cross-source run's sides are the counts ``_combine_cross_source`` took,
    a single-source run's ONE count of the read (the df is cached by the
    caller, so the write does not read the source twice).  Raises
    RuntimeError with the numbers on a mismatch -- before any write."""
    expected = config.get("reported_side_rows")
    if not expected:
        return None
    xs = config.get("_cross_source") or {}
    if xs:
        actual = {"primary": xs.get("primary_rows"), "secondary": xs.get("secondary_rows")}
    else:
        try:
            actual = {"primary": int(df.count()), "secondary": None}
        except Exception as exc:  # noqa: BLE001 -- an uncountable side is judged unknown
            logger.warning("CERTIFY the read could not be counted (%s)", exc)
            actual = {"primary": None, "secondary": None}
    record = _rr_judge(expected, actual)
    record["lane"] = "spark_k8s"
    logger.info("CERTIFY reported-rows %s %s", record.get("verdict"),
                json.dumps(record.get("sides"), default=str))
    sentence = _rr_failure_sentence(record)
    if sentence:
        config["_reported_rows_certification"] = record
        raise RuntimeError(sentence)
    return record


def maybe_combine_sources(spark, primary_df, primary_config: dict):
    """If the feed config has a secondary connection, read the secondary
    side and combine via UNION ALL BY NAME or JOIN.  Returns the
    combined DataFrame (or the primary unchanged if no secondary).
    """
    secondary_conn_id = primary_config.get("secondary_connection_id")
    if not secondary_conn_id:
        return primary_df

    # Build a secondary config by overlaying the secondary fields onto
    # a copy of the primary, then dropping the secondary_* keys so the
    # recursive read_source() call sees a normal single-source config.
    secondary_config = dict(primary_config)
    secondary_config["connection_id"]  = secondary_conn_id
    secondary_config["source_type"]    = primary_config.get("secondary_source_type") or primary_config.get("source_type")
    secondary_config["source_id"]      = primary_config.get("secondary_source_id")
    secondary_config["query_params"]   = primary_config.get("secondary_query_params") or {}
    for k in ("secondary_connection_id", "secondary_source_type",
               "secondary_source_id", "secondary_query_params",
               "combine_mode", "join_config"):
        secondary_config.pop(k, None)

    logger.info("Cross-source feed: reading secondary side (conn=%s, type=%s)",
                 secondary_conn_id, secondary_config.get("source_type"))
    secondary_df = read_source(spark, secondary_config)

    combine_mode = (primary_config.get("combine_mode") or "union").lower()
    join_config = primary_config.get("join_config") or {}
    logger.info("Combining sources via %s",
                f"JOIN: {join_config.get('how', 'inner')}" if combine_mode == "join"
                else "UNION ALL BY NAME")
    return _combine_cross_source(primary_config, primary_df, secondary_df,
                                 combine_mode, join_config)


def _read_s3_auto(spark, source_path: str):
    """Auto-detect format from file extension."""
    path_lower = source_path.lower()
    if path_lower.endswith(".csv") or path_lower.endswith(".csv.gz"):
        logger.info("Auto-detected CSV: %s", source_path)
        return spark.read.csv(source_path, header=True, inferSchema=True)
    elif path_lower.endswith(".json") or path_lower.endswith(".jsonl"):
        logger.info("Auto-detected JSON: %s", source_path)
        return spark.read.json(source_path)
    else:
        # Default to parquet
        logger.info("Auto-detected parquet: %s", source_path)
        return spark.read.parquet(source_path)


#: The alias the JDBC sub-query is wrapped with.  Declared once, imported
#: by the backend guard (tests/test_spark_jdbc_subquery_alias_2026_09_13.py)
#: which refuses a spelling Oracle would reject.
JDBC_SUBQUERY_ALIAS = "qs_subq"


def _time_destination(config: dict) -> str:
    """The destination a SQL TIME column is judged against (K4: text in a
    file, refused for Oracle).  The feed's real destination -- even when
    this job only writes artifacts for QueryStudio to deliver."""
    return str((config or {}).get("destination_type") or "")


#: Inline CA files this driver has written AND shipped, by file name: a
#: CA shared by both sides of a merge is written and added once.
_INLINE_CA_SHIPPED: dict = {}


def inline_ca_file_name(pem: str) -> str:
    """The trust-store file's name -- RELATIVE and content-addressed: the
    same CA on two sides names one file, two CAs name two, and the name
    resolves against each JVM's own working directory."""
    digest = hashlib.sha256(pem.strip().encode("utf-8")).hexdigest()[:16]
    return f"qs-inline-ca-{digest}.pem"


def _with_inline_ca_trust_store(spark, url: str, jdbc_config: dict) -> str:
    """2026-10-08 -- a Trino/Starburst connection's pasted CA
    (``ca_cert_pem``) becomes the JDBC driver's trust store HERE, in the
    pod: the backend has no file to point the driver at.  The Trino
    driver reads a PEM trust store by content
    (``io.trino.client.OkHttpUtil.loadTrustStore`` tries ``PemReader``
    first) and is told where by ``SSLTrustStorePath`` in the URL.

    2026-10-10, found live (starburst_like_proof S1, spark_k8s): the file
    was a ``mkstemp`` path under the DRIVER's /tmp, and the URL is ONE
    string every JDBC connection in the job opens with -- the driver's
    schema probe AND every executor task.  An executor pod has no such
    file: ``java.sql.SQLException: Error setting up SSL:
    /tmp/qs-inline-ca-f2gy2...`` on executor 2, four task attempts, the
    stage aborted.  So the PEM is now (1) written into the driver's
    WORKING DIRECTORY under a content-addressed name, (2) shipped with
    ``SparkContext.addFile`` -- Spark fetches an added file into each
    executor's working directory before its first task
    (``Executor.updateDependencies`` -> ``SparkFiles.getRootDirectory()``,
    which is ``"."`` on an executor) -- and (3) named in the URL by that
    RELATIVE name, which every JVM resolves against its own working
    directory: the driver finds the copy it wrote, each executor the copy
    Spark fetched.  Nothing is written, and the URL is untouched, when the
    config carries no CA; a working directory this process cannot write
    REFUSES the read -- never ``SSLVerification=NONE``.
    """
    pem = str((jdbc_config or {}).get("ca_cert_pem") or "").strip()
    if not pem:
        return url
    name = inline_ca_file_name(pem)
    if name not in _INLINE_CA_SHIPPED:
        cwd = os.getcwd()
        path = os.path.join(cwd, name)
        try:
            tmp = path + ".writing"
            with open(tmp, "w", encoding="utf-8") as fh:
                fh.write(pem + "\n")
            os.replace(tmp, path)
        except OSError as exc:
            raise ValueError(
                f"the connection's inline CA (ca_cert_pem) could not be written "
                f"into the Spark driver's working directory {cwd!r} ({exc}); the "
                f"trust store must be a file every executor receives, so the "
                f"read is refused rather than run unverified") from exc
        spark.sparkContext.addFile(path)
        _INLINE_CA_SHIPPED[name] = path
        logger.info("SOURCE jdbc: inline CA written as %s and shipped to the "
                    "executors (SparkContext.addFile); the URL names it by "
                    "that relative path", path)
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}SSLTrustStorePath={name}"


def _read_jdbc(spark, jdbc_config: dict, sql: str = None, table: str = None,
               *, destination_type: str = ""):
    """Read from JDBC source (Oracle, PostgreSQL, MySQL, etc.).

    The result is put in the FILE SCHEMA the native lane writes for the
    same SQL result (2026-10-07, qs_lane_output.spark_output_casts): ints
    as bigint, decimals at precision 38, naive timestamps, and a SQL TIME
    as its text -- or REFUSED, before the read, when the destination is
    Oracle (qs_oracle_destination_table.refuse_time_columns)."""
    url = jdbc_config.get("url", "")
    user = jdbc_config.get("username", "")
    password = jdbc_config.get("password", "")
    driver = jdbc_config.get("driver", "")

    if not url:
        raise ValueError("JDBC source requires jdbc_config.url")

    url = _with_inline_ca_trust_store(spark, url, jdbc_config)

    reader = spark.read.format("jdbc") \
        .option("url", url) \
        .option("user", user) \
        .option("password", password)

    if driver:
        reader = reader.option("driver", driver)

    # E-H2: always set a batch fetchsize.  Oracle/Postgres default to a tiny
    # per-round-trip fetch (Oracle=10, Postgres=0/all-at-once), so a large
    # extract either does millions of round-trips or buffers everything.
    # Configurable via jdbc_config.fetchsize; defaults to 10000.
    try:
        fetchsize = int(jdbc_config.get("fetchsize") or 10000)
    except (TypeError, ValueError):
        fetchsize = 10000
    if fetchsize > 0:
        reader = reader.option("fetchsize", str(fetchsize))

    # E-H2: parallelise the JDBC read across numPartitions when the caller
    # supplies a numeric/date bound column (partition_column + lower_bound +
    # upper_bound + num_partitions).  Fail-safe: when no partition column is
    # known we keep today's single-partition (single-threaded) read — but
    # still with the fetchsize above.
    part_col = jdbc_config.get("partition_column")
    lower_b = jdbc_config.get("lower_bound")
    upper_b = jdbc_config.get("upper_bound")
    num_part = jdbc_config.get("num_partitions")
    partitioned = False
    if part_col:
        # 2026-09-20 -- a declared partition column with a missing or bad
        # bound is REFUSED, never degraded to one connection: a partitioned
        # read that quietly becomes unpartitioned looks exactly like success.
        # (The backend resolves the bounds from the source and validates the
        # set before submit; this is the job's own floor.)
        missing = [k for k, v in (("lower_bound", lower_b), ("upper_bound", upper_b),
                                  ("num_partitions", num_part)) if v is None]
        if missing:
            raise ValueError(
                f"jdbc_config.partition_column={part_col!r} declared but "
                f"{missing} missing -- refusing a partitioned read that would "
                f"silently run on a single connection")
        try:
            n = int(num_part)
            lo_s, hi_s = str(int(lower_b)), str(int(upper_b))
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"jdbc_config partition bounds are not integers "
                f"(lower_bound={lower_b!r} upper_bound={upper_b!r} "
                f"num_partitions={num_part!r}): {exc}") from exc
        if n < 1:
            raise ValueError(f"jdbc_config.num_partitions={n} must be >= 1")
        reader = (
            reader
            .option("partitionColumn", str(part_col))
            .option("lowerBound", lo_s)
            .option("upperBound", hi_s)
            .option("numPartitions", str(n))
        )
        partitioned = n > 1
        logger.info(
            "JDBC parallel read: partitionColumn=%s bounds=[%s,%s] numPartitions=%d",
            part_col, lo_s, hi_s, n,
        )

    if sql:
        # Wrap SQL in parentheses for JDBC sub-query.  The alias MUST start
        # with a letter: Oracle rejects an identifier beginning with "_"
        # (ORA-00911 "invalid character"), so the former ``_subq`` killed
        # every raw_sql / sql_file Oracle feed on the spark_k8s and airflow
        # lanes at the first read -- found 2026-09-13 on a real driver pod
        # (feed-feed-0c17cbc6b57842b2).  ``qs_subq`` is legal on Oracle,
        # PostgreSQL, MySQL, Snowflake and Trino; no ``AS`` because Oracle
        # does not accept it on a table alias.
        relation = f"({sql}) {JDBC_SUBQUERY_ALIAS}"
        reader = reader.option("dbtable", relation)
    elif table:
        relation = table
        reader = reader.option("dbtable", table)
    else:
        relation = None

    # 2026-10-07 -- A SQL TIME column (K4).  Spark's JDBC reader maps
    # java.sql.Types.TIME to TimestampType, so 09:30:00 was delivered as
    # 1970-01-01 09:30:00 -- to any destination, with nothing to say it was
    # wrong.  load() erases the difference (a TIME and a TIMESTAMP are both
    # TimestampType afterwards), so the source's own metadata is asked
    # first, with the statement Spark's reader itself issues.  A FILE
    # carries the TIME as text (the casts below); ORACLE refuses it, with
    # the native lane's message, before anything is read.
    time_columns = []
    if relation:
        time_columns = _jdbc_time_columns(spark, url, user, password, driver,
                                          relation)
        if time_columns and time_refused_for(destination_type):
            refuse_time_columns(time_columns)

    _plan = (f"partitions={num_part} on {part_col} [{lower_b}..{upper_b}]"
             if part_col
             else "partitions=1 (single JDBC connection; no partition_column declared)")
    logger.info("SOURCE jdbc url=%s user=%s driver=%s fetchsize=%d %s",
                url, user or "-", driver or "-", fetchsize, _plan)
    df = reader.load()
    if partitioned:
        _log_partition_evidence(df, jdbc_config)
    casts = spark_output_casts(df.dtypes, time_columns)
    if casts:
        logger.info("SOURCE casts to the native file schema: %s", casts)
        df = df.selectExpr(*casts)
    return df


def _jdbc_time_columns(spark, url: str, user: str, password: str,
                       driver: str, relation: str) -> list:
    """Ask the SOURCE which of ``relation``'s columns are SQL TIME, through
    the driver JVM and the same driver Spark's reader uses.  Reads no rows:
    the statement is Spark's own schema query, ``SELECT * ... WHERE 1=0``.
    A probe that cannot run is a failure, not a pass -- Spark's own load()
    issues the same statement and would fail the same way."""
    jvm = spark._jvm
    props = jvm.java.util.Properties()
    props.setProperty("user", user or "")
    props.setProperty("password", password or "")
    if driver:
        driver_class = jvm
        for part in driver.split("."):
            driver_class = getattr(driver_class, part)
        conn = driver_class().connect(url, props)
    else:
        conn = jvm.java.sql.DriverManager.getConnection(url, props)
    if conn is None:
        raise RuntimeError(f"The JDBC driver did not accept the URL {url}")
    try:
        stmt = conn.createStatement()
        try:
            md = stmt.executeQuery(f"SELECT * FROM {relation} WHERE 1=0") \
                .getMetaData()
            width = int(md.getColumnCount())
            names = [str(md.getColumnLabel(i)) for i in range(1, width + 1)]
            codes = [int(md.getColumnType(i)) for i in range(1, width + 1)]
        finally:
            stmt.close()
    finally:
        conn.close()
    return time_columns_in_jdbc(names, codes)


def _log_partition_evidence(df, jdbc_config: dict) -> None:
    """PARTITIONS evidence in the driver log (2026-09-20).

    ``declared`` costs nothing (the RDD's partition count).  ``stripes`` --
    rows per stripe and the executor host that read each -- is a separate
    pass over the source and is opt-in (``jdbc_config.partition_evidence``),
    because doubling every partitioned feed's read to prove parallelism
    every night is not a price a production feed should pay; a proof run
    sets it once.  "Spark ran" and "Spark helped" are different claims;
    this is how the second one is shown rather than assumed.
    """
    try:
        declared = df.rdd.getNumPartitions()
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("PARTITIONS could not be counted: %s", exc)
        return
    logger.info("PARTITIONS declared=%d", declared)
    if not jdbc_config.get("partition_evidence"):
        return
    try:
        import socket

        def _stripe(idx, it):
            n = 0
            for _ in it:
                n += 1
            yield (idx, n, socket.gethostname())

        stripes = sorted(df.rdd.mapPartitionsWithIndex(_stripe).collect())
        hosts = sorted({h for _, _, h in stripes})
        logger.info("PARTITIONS stripes=%d rows_per_stripe=%s executors=%d hosts=%s",
                    len(stripes), [n for _, n, _ in stripes], len(hosts), hosts)
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("PARTITIONS stripe evidence failed: %s", exc)


def _reconcile_partitioned_read(config: dict, input_count: int) -> None:
    """A partitioned read must return exactly the rows the source counted
    when its bounds were resolved (``jdbc_config.expected_rows``, stamped by
    the backend at submit).  A range-partitioned JDBC read is where a stripe
    goes missing or doubles; the right COUNT is necessary evidence, and a
    wrong one FAILS the run rather than certifying COMPLETE (2026-09-20).
    Absent ``expected_rows`` (unpartitioned read, older backend) -> no-op.
    """
    jc = (config.get("query_params") or {}).get("jdbc_config") or {}
    expected = jc.get("expected_rows")
    if expected is None:
        return
    try:
        expected = int(expected)
    except (TypeError, ValueError):
        logger.warning("RECONCILE expected_rows=%r is not an integer -- skipped", expected)
        return
    if int(input_count) != expected:
        raise ValueError(
            f"partitioned read RECONCILIATION FAILED: read {input_count} rows, the "
            f"source counted {expected} when the partition bounds were resolved "
            f"(column={jc.get('partition_column')!r} bounds=[{jc.get('lower_bound')}, "
            f"{jc.get('upper_bound')}] partitions={jc.get('num_partitions')}). A "
            f"stripe was lost or doubled; refusing to deliver.")
    logger.info("RECONCILE read=%d expected=%d ok", input_count, expected)


# ── Transform (same pattern as generic_etl.py) ──────────────────────────

def apply_transform(spark, df, config: dict):
    """Apply transform rules: WHERE → SELECT → CAST → DEDUP → custom_sql.

    Returns transformed DataFrame and input row count.
    """
    transform = config.get("transform_rules") if "transform_rules" in config else {}
    if not transform:
        # Check output_options or query_params for transform rules
        transform = (config.get("query_params") or {}).get("transform_rules") or {}

    # E-H2: single source count.  The caller caches ``df`` before invoking
    # apply_transform so this count doesn't re-issue the source SQL, and the
    # intermediate progress logs below no longer trigger extra full counts
    # (each df.count() was a separate Spark job re-scanning the source).
    #
    # 2026-10-07 (C4): ONLY when something needs it -- a transform (rows in
    # and rows out differ) or a partitioned read to reconcile.  Otherwise
    # rows in ARE rows out, and the count comes from what the write wrote
    # (``main`` fills input_row_count from it): an action over a cache the
    # executors evicted re-runs the whole source query.
    _jc = (config.get("query_params") or {}).get("jdbc_config") or {}
    if not transform and _jc.get("expected_rows") is None:
        logger.info("TRANSFORM none declared -- rows pass through unchanged "
                    "(READ rows = rows written)")
        return df, None
    input_count = df.count()
    logger.info("READ rows=%d", input_count)
    _reconcile_partitioned_read(config, input_count)

    if not transform:
        logger.info("TRANSFORM none declared -- rows pass through unchanged")
        return df, input_count

    # WHERE filter
    where_clause = transform.get("where")
    if where_clause:
        df = df.filter(where_clause)
        logger.info("Applied WHERE filter")

    # SELECT columns
    select_cols = transform.get("select")
    if select_cols:
        # Handle aliased columns: "COL AS alias"
        from pyspark.sql import functions as F
        import re as _re_alias
        exprs = []
        for col_expr in select_cols:
            # BF-136: Case-insensitive split on " AS " (handles "As", "aS", etc.)
            alias_match = _re_alias.split(r'\s+[Aa][Ss]\s+', col_expr, maxsplit=1)
            if len(alias_match) == 2:
                exprs.append(F.col(alias_match[0].strip()).alias(alias_match[1].strip()))
            else:
                exprs.append(F.col(col_expr.strip()))
        df = df.select(*exprs)

    # CAST columns
    cast_map = transform.get("cast") or {}
    for col_name, dtype in cast_map.items():
        if col_name in df.columns:
            df = df.withColumn(col_name, df[col_name].cast(dtype))

    # DEDUP
    dedup = transform.get("dedup")
    if dedup:
        from pyspark.sql.window import Window
        from pyspark.sql import functions as F

        dedup_cols = dedup.get("columns", [])
        order_by = dedup.get("order_by", "")

        if dedup_cols:
            order_parts = order_by.split()
            order_col = order_parts[0] if order_parts else dedup_cols[0]
            descending = len(order_parts) > 1 and order_parts[1].upper() == "DESC"

            window = Window.partitionBy(*dedup_cols).orderBy(
                F.col(order_col).desc() if descending else F.col(order_col).asc()
            )
            df = df.withColumn("_rn", F.row_number().over(window))
            df = df.filter(F.col("_rn") == 1).drop("_rn")
            logger.info("Applied dedup on columns=%s", dedup_cols)

    # CUSTOM SQL — overrides everything above
    custom_sql = transform.get("custom_sql")
    if custom_sql:
        # Phase 130 hotfix-13 audit fix #5: also resolve {{}} tokens
        # in custom transform SQL (e.g. WHERE clause with business_date).
        custom_sql = _substitute_feed_params(custom_sql, config)
        df.createOrReplaceTempView("_source_data")
        df = spark.sql(custom_sql)
        logger.info("Custom SQL applied")

    return df, input_count


# ── Destination Router (pluggable) ───────────────────────────────────────

#: Destinations whose write is a NON-IDEMPOTENT act visible outside this
#: system: an SFTP put lands a file at a counterparty, an Oracle insert adds
#: rows.  s3/local are ``mode("overwrite")`` and repeat harmlessly.
POD_SIDE_NON_IDEMPOTENT = frozenset({"sftp", "oracle"})


def job_delivers(config: dict) -> bool:
    """Does THIS JOB deliver, or does QueryStudio deliver from the webhook?

    H1 (2026-09-02).  While the job delivers, the retry unit — the whole pod —
    CONTAINS the non-idempotent act: a job that put a file over SFTP and then
    died before its webhook landed presents as FAILED, and the resubmit
    delivers it again.  No failure classification can prevent that, so the
    only structural fix is for delivery to leave the pod.

    ``deliver_in_job`` is resolved at SUBMIT and carried in the payload, so a
    config change mid-flight cannot make the pod and the webhook disagree
    about who sends the file.  ABSENT means an older submitter that predates
    the flag: assume TRUE — today's behaviour — because the alternative
    failure direction is a job that delivers nothing while reporting success,
    which is silent total data loss.
    """
    # 2026-10-07 -- a run that must NOT deliver (a backfill launched
    # without delivery) never delivers from the pod, whatever else says.
    if suppressed_run(config):
        return False
    value = config.get("deliver_in_job")
    return True if value is None else bool(value)


def suppressed_run(config: dict) -> bool:
    """Did QueryStudio decide this run must NOT deliver?  Resolved ONCE at
    submit from the execution's stored decision (``suppress_delivery`` in
    the payload).  Honoured only when the payload names a destination (the
    spark_k8s conf): the legacy Airflow conf has none -- its job writes
    QueryStudio's staging output and the ENGINE delivers (or suppresses)
    after the DAG."""
    return bool(config.get("suppress_delivery")) and bool(
        config.get("destination_type"))


#: Refused, never degraded (K2): the router floors Excel feeds to native
#: (backend_router output_capability_floor); a conf that reaches the job
#: anyway is refused rather than answered with a parquet file.
EXCEL_REFUSAL = (
    "output_format=excel cannot be produced by the Spark job (the job "
    "image has no xlsx writer).  The router sends Excel feeds to the native "
    "backend (output_capability_floor); this conf bypassed it.  Refusing "
    "rather than writing a different format under the feed's name.")


def _check_partitioned_rows(config: dict, rows) -> None:
    """A partitioned read must return the rows its discovery counted
    (2026-10-14; the native lane's ``fail_on_bucket_mismatch``): when the
    backend's plan says the counts ARE output rows, the rows written must
    equal their sum -- a bucket lost or doubled FAILS the run, never
    certifies.  Single-source runs only (a merged run's rows are both
    sides).  No expectation (distinct-mode discovery) = nothing to check."""
    if config.get("_cross_source") or rows is None:
        return
    rec = (config.get("_partitioned_read") or {}).get("primary") or {}
    expected = rec.get("sum_bucket_expected")
    if rec.get("mode") != "partition_values" or not rec.get("counts_are_output_rows") \
            or expected is None:
        return
    if int(rows) != int(expected):
        raise ValueError(
            f"partitioned read RECONCILIATION FAILED: {int(rows)} rows written, the "
            f"discovery counted {int(expected)} over {rec.get('bucket_count')} bucket(s) of "
            f"{rec.get('partition_column')!r}. A bucket was lost or doubled; refusing to "
            f"deliver.")
    logger.info("RECONCILE partitioned read: %d rows == discovery's %d", int(rows), int(expected))


def write_output(df, config: dict) -> dict:
    """Write DataFrame to destination. Returns output metrics.

    2026-10-07 (the feed lane contract, K1/K5): a FILE the job delivers is
    rendered ONCE, on the driver, with the native writer
    (qs_lane_output), named by the contract's filename, and sent with the
    native protocol (qs_delivery_protocol) -- one object / one file, never
    a Spark part directory.  What the job cannot render with those rules
    QueryStudio renders from the job's artifacts (``deliver_in_job:
    false``, resolved at submit by core.spark_k8s.feed_conf.
    resolve_delivery_owner).
    """
    dest_type = config.get("destination_type")

    # H1 — when QueryStudio owns delivery, the counterparty is NOT written
    # here.  The artifacts land in QueryStudio's own store and the callback
    # reports ``delivered=False`` so the webhook sends them.  The decision
    # is made in ONE place: a new destination inherits it.
    if suppressed_run(config):
        # 2026-10-07 -- ANY destination, s3/local included.
        logger.info(
            "delivery SUPPRESSED for this run (backfill without delivery) -- "
            "destination_type=%s is NOT written; artifacts only", dest_type)
        return _write_artifacts_only(df, config)

    if dest_type and not job_delivers(config):
        # 2026-10-07 -- EVERY destination, not only the non-idempotent
        # ones: with a delivery chain declared on an s3/local feed the job
        # wrote the counterparty's bucket itself AND QueryStudio delivered
        # the chain from the webhook -- the same file twice.
        logger.info(
            "destination_type=%s but deliver_in_job=false (%s) — writing "
            "artifacts only; QueryStudio delivers from the completion "
            "webhook", dest_type,
            config.get("delivery_owner_reason") or "resolved at submit")
        return _write_artifacts_only(df, config)

    if str(config.get("output_format") or "").lower() == "excel":
        raise ValueError(EXCEL_REFUSAL)

    if not dest_type:
        # The legacy Airflow conf names no destination: the job writes
        # QueryStudio's staging output and the ENGINE delivers after the DAG.
        return _write_s3(df, config)
    if dest_type == "oracle":
        return _write_oracle(df, config)
    if dest_type == "sftp":
        return _write_sftp(df, config)
    if dest_type == "s3":
        return _deliver_s3(df, config)
    if dest_type == "local":
        return _deliver_local(df, config)
    raise ValueError(f"Unsupported destination_type: {dest_type}")


def _write_artifacts_only(df, config: dict) -> dict:
    """Materialise the output where QueryStudio can reach it, and stop.

    Uses the artifact store the deployment already has: S3 when the job was
    given one, else the local/NFS path.  Never the counterparty destination —
    that is precisely what this path exists to avoid touching.
    """
    artifact = dict(config)
    store = (config.get("artifact_store")
             or ("s3" if (config.get("artifact_config")
                          or {}).get("bucket") else "local"))
    artifact["destination_type"] = store
    # NEVER the feed's destination_config: that is the counterparty (an
    # s3 destination's bucket, a local destination's directory).  The
    # backend always sends artifact_config with deliver_in_job=false
    # (2026-10-07); an older submitter that sent none gets an explicit
    # pod-local directory, not the destination.
    artifact["destination_config"] = dict(
        config.get("artifact_config") or {"path": "/tmp/qs-spark-artifacts"})

    # PARQUET, whatever the feed output_format.  QueryStudio renders the
    # deliverable from these parts with core.feed.renderers -- the native
    # renderer, every format, parquet included (one file from N parts) --
    # so the job holds no second implementation of any format decision.
    # The parts already carry the native FILE SCHEMA (the casts in
    # _read_jdbc).  Spark keeps what only Spark can do: the distributed
    # READ and TRANSFORM.
    #
    # compression is dropped here deliberately: the codec belongs to the
    # DELIVERED artifact, and the backend applies it in the fixed chain
    # (package -> compress -> encrypt -> checksum).
    artifact["output_format"] = "parquet"
    artifact["output_options"] = {
        k: v for k, v in (config.get("output_options") or {}).items()
        if k != "compression"
    }
    if store == "s3":
        _apply_artifact_store_s3a(df.sparkSession, artifact["destination_config"])
    out = _write_s3(df, artifact) if store == "s3" else _write_local(df, artifact)
    out["delivered"] = False
    out["artifact_store"] = store
    out["parts_format"] = "parquet"
    return out


def _write_s3(df, config: dict) -> dict:
    """A part DIRECTORY on S3 through Spark's distributed writer: the
    ARTIFACT store (parquet parts QueryStudio renders from), and the legacy
    Airflow staging output.  Never a counterparty's destination -- that is
    :func:`_deliver_s3` (one object named by the template)."""
    dest_config = config.get("destination_config") or {}
    bucket = dest_config.get("bucket", "")
    prefix = dest_config.get("prefix", "").rstrip("/")
    output_format = config.get("output_format", "parquet")

    execution_id = config.get("execution_id", "unknown")
    output_path = f"s3a://{bucket}/{prefix}/{execution_id}" if prefix else f"s3a://{bucket}/{execution_id}"

    spark_mode = "overwrite"
    compression = _output_compression(config)
    logger.info("Writing %s to S3: %s (mode=%s, compression=%s)",
                output_format, output_path, spark_mode, compression or "none")

    if output_format == "csv":
        # D2 (2026-09-02): honour the feed's declared output contract instead
        # of Spark's defaults -- see _csv_write_options.
        writer = df.write.mode(spark_mode).options(**_csv_write_options(config))
        if compression:  # E-L2: compress CSV output when configured
            writer = writer.option("compression", compression)
        writer.csv(output_path)
    elif output_format == "json":
        writer = df.write.mode(spark_mode)
        if compression:  # E-L2: compress JSON output when configured
            writer = writer.option("compression", compression)
        writer.json(output_path)
    elif output_format == "excel":
        raise ValueError(EXCEL_REFUSAL)
    else:
        df.write.mode(spark_mode).parquet(output_path)

    # the rows WRITTEN: a parquet part directory is counted from its footers
    # (no second read of the source); text formats still count the frame
    output_count = (df.sparkSession.read.parquet(output_path).count()
                    if output_format == "parquet" else df.count())
    return {
        "output_row_count": output_count,
        "output_path": output_path,
    }


def _write_oracle(df, config: dict) -> dict:
    """Write to Oracle via JDBC."""
    dest_config = config.get("destination_config") or {}
    oracle_jdbc = config.get("oracle_jdbc_config") or {}

    host = oracle_jdbc.get("host") or dest_config.get("host", "")
    port = int(oracle_jdbc.get("port") or dest_config.get("port", 1521))
    service_name = oracle_jdbc.get("service_name") or dest_config.get("service_name", "")
    username = oracle_jdbc.get("username") or dest_config.get("username", "")
    password = oracle_jdbc.get("password") or dest_config.get("password", "")
    table = dest_config.get("table", "")
    mode = dest_config.get("mode", "append")
    batch_size = int(dest_config.get("batch_size", 5000))

    if not table:
        raise ValueError("Oracle destination requires 'table' in destination_config")

    jdbc_url = f"jdbc:oracle:thin:@//{host}:{port}/{service_name}"

    # ── THE IDENTIFIER RULE (FB-59, 2026-09-21) ────────────────────────
    #
    # Spark's Oracle dialect QUOTES every column name it is given, both in
    # the CREATE TABLE it issues for a table that does not exist yet and in
    # the INSERT.  Handing it the DataFrame's own names therefore created
    # tables with lower-case QUOTED identifiers -- "id", "region" -- which
    # in Oracle is PERMANENT: SELECT REGION raises ORA-00904 against them
    # forever, for every report, feed and hand-written statement, while the
    # same feed delivered by the native lane (which adopts an existing
    # table's spelling) is readable normally.  Whether a given feed's table
    # was readable came down to whether it happened to exist before the
    # feed first ran -- proved on the Docker rig with a PINNED spark_k8s
    # feed into a fresh table, so the router was never the variable.
    #
    # Fold to the identifier ORACLE ITSELF would create.  The rule and its
    # reasoning live in qs_oracle_identifiers (a byte-identical mirror of
    # backend/core/feed/oracle_identifiers.py, which is what the native
    # lane calls).  An illegal or colliding name REFUSES here, before a
    # single row moves -- a name cannot be mangled into something that
    # writes the wrong column.
    #
    # An EXISTING table of any casing keeps its own spelling: once the table
    # has been probed, rule 1 of the shared module (adopt the table's
    # spelling on a case-only difference) renames the frame again below,
    # in _write_oracle_atomically.
    source_columns = list(df.columns)
    target_columns = resolve_oracle_columns(source_columns)
    if target_columns != source_columns:
        df = df.toDF(*target_columns)
        logger.info("WRITE oracle identifiers folded to Oracle casing %s -> %s",
                    source_columns, target_columns)
    else:
        logger.info("WRITE oracle identifiers already canonical %s",
                    target_columns)

    output_path = f"oracle://{host}:{port}/{service_name}/{table}"
    logger.info("WRITE oracle table=%s mode=%s url=%s user=%s batchsize=%d",
                table, mode, jdbc_url, username or "-", batch_size)

    # ── THE TABLE AND THE TRANSACTION (2026-10-07) ─────────────────────
    #
    # Both rules live in qs_oracle_destination_table, a byte-identical
    # mirror of backend/core/feed/oracle_destination_table.py -- the
    # module the native lane calls -- and both used to be Spark's own:
    #
    # * A MISSING table was created by Spark's Oracle dialect (DOUBLE ->
    #   NUMBER(19, 4), rounding every value to 4 places; STRING ->
    #   VARCHAR2(255)) while native refused it, so the same feed passed or
    #   failed by the size router's choice.  The rule now creates it here,
    #   through the driver JVM, before Spark writes anything -- Spark only
    #   ever finds an existing table.
    # * Spark commits EACH PARTITION separately, so a killed driver left
    #   partial rows in the counterparty's table (and the retry duplicated
    #   them), and truncate=true TRUNCATEd (DDL, self-committing) first.
    #   Spark now writes a per-run STAGING table; one JDBC transaction then
    #   publishes it (DELETE for truncate_insert + INSERT ... SELECT) and
    #   the stage is dropped.  Until that commit the target is untouched.
    #
    # The row counts are the database's own: rows staged (the result),
    # rows that reached the target, rows the target rejected under the
    # destination's max_error_percent -- the SAME tolerance the native lane
    # applies (2026-10-07, second pass; this lane used to fail the whole
    # write on the first rejected row).  ``df.count()`` here re-executed the
    # whole source query.
    counts = _write_oracle_atomically(
        df, table=table, mode=mode, source_columns=source_columns,
        jdbc_opts={"url": jdbc_url, "user": username, "password": password,
                   "driver": "oracle.jdbc.OracleDriver",
                   "batchsize": str(batch_size)},
        execution_id=config.get("execution_id") or "unknown",
        max_percent=max_error_percent(dest_config))
    logger.info("WRITE complete rows=%d delivered=%d rejected=%d dest=%s",
                counts["staged_rows"], counts["delivered_rows"],
                counts["dropped_rows"], output_path)

    # delivered_rows / dropped_rows travel to the completion webhook, which
    # certifies against the DESTINATION's count exactly as the native
    # lane's receipt does: rows rejected under the tolerance make the run
    # INCOMPLETE, never silently short.
    return {
        "output_row_count": counts["staged_rows"],
        "delivered_rows": counts["delivered_rows"],
        "dropped_rows": counts["dropped_rows"],
        "output_path": output_path,
    }


def _write_oracle_atomically(df, *, table: str, mode: str, source_columns,
                             jdbc_opts: dict, execution_id: str,
                             max_percent: float) -> dict:
    """Rules A and B of qs_oracle_destination_table for one DataFrame whose
    columns are already folded to Oracle casing.  Returns the database's
    ``{"staged_rows", "delivered_rows", "dropped_rows"}`` (all 0 when rule
    6 wrote nothing)."""
    session = _OracleJdbcSession(_oracle_jdbc_connection(
        df, jdbc_opts["url"], jdbc_opts["user"], jdbc_opts["password"]))
    try:
        table_columns, created = ensure_oracle_table(
            table, source_columns, [t for _, t in df.dtypes], "spark",
            session.probe, session.execute,
            result_is_empty=lambda: len(df.head(1)) == 0,
            canonical_names=canonical_oracle_columns)
        if table_columns is None:
            # Rule 6: an empty result never creates a table (the native
            # lane cannot know an empty result's types).  Spark's writer
            # would create one, so it is not called at all.
            logger.info("WRITE oracle 0 rows and %s does not exist -- an "
                        "empty result does not create a table; nothing "
                        "written", table)
            return {"staged_rows": 0, "delivered_rows": 0, "dropped_rows": 0}
        if created:
            logger.info("WRITE oracle created %s from the result schema",
                        table)
        # Rule 1: an existing table's own spelling, and a source column
        # with no home in it REFUSES before a row moves.
        resolved = resolve_oracle_columns(list(df.columns), table_columns,
                                          table)
        staged_df = df.toDF(*resolved)

        def _write_stage(stage_name):
            writer = staged_df.write.format("jdbc").mode("append")
            for k, v in dict(jdbc_opts, dbtable=stage_name).items():
                writer = writer.option(k, v)
            writer.save()

        # The stage takes the RULE's wide types, so it accepts every row the
        # result can hold; the target's own types decide at the publish,
        # where a rejected row is logged and counted instead of fatal.
        target_types = dict(session.describe(table))
        stage_types = stage_column_types(
            [t for _, t in staged_df.dtypes],
            [target_types.get(c) for c in resolved], resolved,
            max_string_bytes=_max_string_bytes(staged_df))
        stage = staging_table_name(execution_id)
        logger.info("WRITE oracle staging into %s, then ONE transaction "
                    "into %s (max_error_percent=%s)", stage, table,
                    max_percent)
        return write_through_stage(
            table=table, stage=stage, columns=resolved,
            stage_types=stage_types, mode=mode, max_percent=max_percent,
            execute=session.execute, query=session.query,
            transaction=session.transaction, write_stage=_write_stage)
    finally:
        session.close()


def _max_string_bytes(df) -> list:
    """The longest value, in UTF-8 bytes, of every STRING column (None for
    any other type) -- one aggregate over the cached result.  The stage
    rule (stage_column_types) stages a column CLOB when its longest value
    cannot fit a VARCHAR2, so a too-long value is ONE rejected row at the
    publish instead of a failed stage write (K4, inventory A5)."""
    strings = [c for c, t in df.dtypes if str(t).lower() == "string"]
    if not strings:
        return [None] * len(df.columns)
    row = df.selectExpr(*[f"max(octet_length(`{c}`)) AS `{c}`"
                          for c in strings]).collect()[0]
    found = dict(zip(strings, row))
    return [None if found.get(c) is None else int(found[c])
            for c in df.columns]


def _oracle_jdbc_connection(df, jdbc_url: str, username: str, password: str):
    """A ``java.sql.Connection`` from the driver JVM, through the SAME
    driver class Spark's writer is handed (``oracle.jdbc.OracleDriver``,
    ojdbc11 in the image's jars).  No Python Oracle client is installed in
    this image and none is needed."""
    jvm = df.sparkSession._jvm
    props = jvm.java.util.Properties()
    props.setProperty("user", username or "")
    props.setProperty("password", password or "")
    conn = jvm.oracle.jdbc.OracleDriver().connect(jdbc_url, props)
    if conn is None:
        raise RuntimeError(
            f"The Oracle JDBC driver did not accept the URL {jdbc_url}")
    return conn


class _OracleJdbcSession:
    """The four verbs qs_oracle_destination_table asks a lane for, over one
    JDBC connection.  ``transaction`` is the only place auto-commit is off,
    and it always ends in exactly one commit or one rollback."""

    def __init__(self, conn):
        self._conn = conn

    def probe(self, sql: str):
        stmt = self._conn.createStatement()
        try:
            md = stmt.executeQuery(sql).getMetaData()
            return [md.getColumnName(i)
                    for i in range(1, md.getColumnCount() + 1)]
        finally:
            stmt.close()

    def describe(self, table: str):
        """``[(column, Oracle type name)]`` of an existing table."""
        stmt = self._conn.createStatement()
        try:
            md = stmt.executeQuery(f"SELECT * FROM {table} WHERE 1=0") \
                .getMetaData()
            return [(md.getColumnName(i), md.getColumnTypeName(i))
                    for i in range(1, md.getColumnCount() + 1)]
        finally:
            stmt.close()

    def execute(self, sql: str):
        stmt = self._conn.createStatement()
        try:
            stmt.execute(sql)
        finally:
            stmt.close()

    def query(self, sql: str):
        stmt = self._conn.createStatement()
        try:
            rs = stmt.executeQuery(sql)
            width = rs.getMetaData().getColumnCount()
            rows = []
            while rs.next():
                rows.append(tuple(rs.getString(i) for i in range(1, width + 1)))
            return rows
        finally:
            stmt.close()

    def transaction(self, statements, decide=None):
        """Run ``statements`` in ONE transaction; ``decide(counts)`` runs
        inside it before the commit and rolls everything back by raising."""
        self._conn.setAutoCommit(False)
        try:
            stmt = self._conn.createStatement()
            try:
                counts = [int(stmt.executeUpdate(sql)) for sql in statements]
            finally:
                stmt.close()
            if decide is not None:
                decide(counts)
            self._conn.commit()
            return counts
        except BaseException:
            try:
                self._conn.rollback()
            except Exception as exc:
                logger.warning("Oracle rollback failed: %s", exc)
            raise
        finally:
            try:
                self._conn.setAutoCommit(True)
            except Exception:
                pass

    def close(self):
        try:
            self._conn.close()
        except Exception as exc:
            logger.warning("Oracle JDBC connection close failed: %s", exc)


def _write_local(df, config: dict) -> dict:
    """A part DIRECTORY on the local filesystem through Spark's writer --
    the pod-local ARTIFACT store when no bucket is configured (which
    QueryStudio cannot read; the webhook records that).  A counterparty's
    local destination is :func:`_deliver_local`."""
    dest_config = config.get("destination_config") or {}
    output_dir = dest_config.get("path", "/tmp/feed_output")
    output_format = config.get("output_format", "parquet")
    execution_id = config.get("execution_id", "unknown")
    output_path = f"{output_dir}/{execution_id}"

    compression = _output_compression(config)
    logger.info("WRITE local format=%s path=%s compression=%s",
                output_format, output_path, compression or "none")

    if output_format == "csv":
        # D2 (2026-09-02): same output contract as the S3 writer and the
        # native lane -- see _csv_write_options.
        writer = df.write.mode("overwrite").options(**_csv_write_options(config))
        if compression:  # E-L2: compress CSV output when configured
            writer = writer.option("compression", compression)
        writer.csv(output_path)
    elif output_format == "json":
        writer = df.write.mode("overwrite")
        if compression:  # E-L2: compress JSON output when configured
            writer = writer.option("compression", compression)
        writer.json(output_path)
    elif output_format == "excel":
        # K2 (2026-10-07): refused, never degraded to parquet.
        raise ValueError(EXCEL_REFUSAL)
    else:
        df.write.mode("overwrite").parquet(output_path)

    output_count = (df.sparkSession.read.parquet(output_path).count()
                    if output_format == "parquet" else df.count())
    return {
        "output_row_count": output_count,
        "output_path": output_path,
    }


# ── Rendering a deliverable on the driver (2026-10-07, K1) ──────────────
#
# One file, named by the contract, written by the NATIVE writer
# (qs_lane_output) from the rows Spark streams to the driver one partition
# at a time (toLocalIterator: memory bounded by the largest partition, not
# the result).  A single-file counterparty deliverable is single-process by
# nature; Spark's distributed writer produced a part DIRECTORY with Spark's
# own value text (``true``, ``...T09:30:00.000Z``, ``\"``), which is what
# made the bytes depend on routing.

def _csv_dialect(config: dict) -> dict:
    """The CSV dialect by NAME: the execution contract's csv block (the
    backend resolved it with core.feed.csv_dialect), else -- an older
    submitter -- the feed's output_options, whose keys are the same
    names."""
    c = (_contract(config).get("csv") or {})
    if c:
        return dict(c)
    return dict(config.get("output_options") or {})


def _render_on_driver(df, config: dict, staging_dir: str) -> dict:
    """``{"path", "filename", "rows", "physical_rows"}`` of the deliverable
    rendered into ``staging_dir``.  CSV and JSON lines only (parquet is
    Spark's writer -- the image has no pyarrow)."""
    fmt = str(config.get("output_format") or "csv").strip().lower()
    if fmt not in ("csv", "json"):
        raise ValueError(
            f"the Spark job renders csv / json on the driver, not {fmt!r}; "
            f"QueryStudio renders that format from the job's artifacts "
            f"(deliver_in_job=false)")
    filename = _build_delivery_filename(config)
    path = os.path.join(staging_dir, filename)
    dialect = _csv_dialect(config)
    columns = list(df.columns)
    rows = render_rows(path, fmt, columns,
                       (tuple(r) for r in df.toLocalIterator()), dialect)
    if fmt == "csv":
        physical = csv_physical_rows(path, bool(dialect.get("header", True)))
    elif (config.get("output_options") or {}).get("lines"):
        physical = lines_physical_rows(path)
    else:
        physical = None       # the native recount's rule for json (C4/D1)
    logger.info("WRITE rendered %s on the driver: %s rows=%d bytes=%d",
                fmt, filename, rows, os.path.getsize(path))
    return {"path": path, "filename": filename, "rows": rows,
            "physical_rows": physical}


def _hadoop_fs(spark, uri: str):
    """``(fs, Path)`` -- the live session's Hadoop filesystem for ``uri``
    (same credentials and endpoint as Spark's own S3A writes)."""
    jvm = spark._jvm
    hpath = jvm.org.apache.hadoop.fs.Path
    fs = hpath(uri).getFileSystem(spark._jsc.hadoopConfiguration())
    return fs, hpath


def _deliver_s3(df, config: dict) -> dict:
    """ONE object, ``<prefix>/<contract filename>``
    (qs_delivery_protocol.s3_object_key), size-checked after the upload.
    It used to be a part DIRECTORY ``<prefix>/<execution id>/part-*``."""
    import shutil
    import tempfile
    dest = config.get("destination_config") or {}
    bucket = str(dest.get("bucket") or "")
    if not bucket:
        raise ValueError("S3 destination requires destination_config.bucket")
    fmt = str(config.get("output_format") or "csv").strip().lower()
    filename = _build_delivery_filename(config)
    key = s3_object_key(dest.get("prefix", ""), filename)
    final_uri = f"s3a://{bucket}/{key}"
    spark = df.sparkSession
    fs, HPath = _hadoop_fs(spark, final_uri)
    if fmt in ("csv", "json"):
        staging = tempfile.mkdtemp(prefix="feed_s3_")
        try:
            r = _render_on_driver(df, config, staging)
            fs.copyFromLocalFile(False, True, HPath("file://" + r["path"]),
                                 HPath(final_uri))
            remote = int(fs.getFileStatus(HPath(final_uri)).getLen())
            verify_size(os.path.getsize(r["path"]), remote, final_uri)
            rec = delivery_receipt(
                final_uri, verification="verified",
                detail=f"getFileStatus size={remote} (S3A, same session)",
                written_rows=r["rows"], physical_rows=r["physical_rows"])
            logger.info("WRITE s3 object %s rows=%d", final_uri, r["rows"])
            return {"output_row_count": r["rows"], "output_path": final_uri,
                    "output_size_bytes": remote, "delivery_receipt": rec}
        finally:
            shutil.rmtree(staging, ignore_errors=True)
    if fmt == "parquet":
        # Spark's writer (the image has no pyarrow), ONE part, then renamed
        # to the contract's name: the counterparty sees one object.
        prefix = str(dest.get("prefix") or "").strip().strip("/")
        stage_uri = (f"s3a://{bucket}/{prefix + '/' if prefix else ''}"
                     f"_qs_staging_{config.get('execution_id') or 'run'}")
        df.coalesce(1).write.mode("overwrite").parquet(stage_uri)
        parts = [st for st in fs.listStatus(HPath(stage_uri))
                 if st.isFile() and st.getPath().getName().endswith(".parquet")]
        if len(parts) != 1:
            raise RuntimeError(
                f"expected ONE parquet part under {stage_uri}, found "
                f"{len(parts)} -- refusing to guess which is the file")
        part_len = int(parts[0].getLen())
        if fs.exists(HPath(final_uri)):
            fs.delete(HPath(final_uri), False)
        fs.rename(parts[0].getPath(), HPath(final_uri))
        fs.delete(HPath(stage_uri), True)
        remote = int(fs.getFileStatus(HPath(final_uri)).getLen())
        verify_size(part_len, remote, final_uri)
        # The rows IN THE FILE: a footer read of what was written, not a
        # recount of the DataFrame (which re-runs the source on eviction).
        rows = int(spark.read.parquet(final_uri).count())
        rec = delivery_receipt(
            final_uri, verification="verified",
            detail=f"getFileStatus size={remote} (S3A, same session)",
            written_rows=rows, physical_rows=rows)
        logger.info("WRITE s3 object %s rows=%d (parquet)", final_uri, rows)
        return {"output_row_count": rows, "output_path": final_uri,
                "output_size_bytes": remote, "delivery_receipt": rec}
    raise ValueError(f"the Spark job does not deliver {fmt!r} to S3 itself")


def _deliver_local(df, config: dict) -> dict:
    """A counterparty's LOCAL destination, by the native allowed-roots rule
    (qs_delivery_protocol.resolve_local_destination) with the roots the
    backend shipped (``local_delivery``).  The backend never hands the job
    a local destination to deliver itself (Spark pods mount no shared
    volume -- resolve_delivery_owner sends it through QueryStudio); this is
    the floor for a conf that does."""
    import shutil
    import tempfile
    ld = config.get("local_delivery") or {}
    out_dir = ld.get("output_dir")
    if not out_dir:
        raise ValueError(
            "Local destination refused: the conf carries no allowed roots "
            "(local_delivery) -- a Spark pod delivers a local destination "
            "only through QueryStudio")
    roots = list(ld.get("allowed_roots") or [])
    dest = config.get("destination_config") or {}
    dest_dir = resolve_local_destination(dest.get("path") or out_dir,
                                         out_dir, roots)
    staging = tempfile.mkdtemp(prefix="feed_local_")
    try:
        r = _render_on_driver(df, config, staging)
        target = local_target(dest_dir, r["filename"], out_dir, roots)
        pub = publish_local(r["path"], target)
        rec = delivery_receipt(target, verification=pub["verification"],
                               detail=pub["detail"], written_rows=r["rows"],
                               physical_rows=r["physical_rows"])
        return {"output_row_count": r["rows"], "output_path": target,
                "output_size_bytes": os.path.getsize(target), "delivery_receipt": rec}
    finally:
        shutil.rmtree(staging, ignore_errors=True)


# ── SFTP destination (Spark-batch fallback) ──────────────────────────────
#
# The native feed delivery (core.feed_engine._sftp_connect / _sftp_put_one)
# owns the canonical SFTP path.  This detached Spark-batch fallback mirrors
# that SAME dest_config shape + host-key verification so a UI-authored feed
# with destination_type=sftp doesn't hit "Unsupported" here.  Shape reused:
#   host, port, username, password, key_path,
#   host_key_b64 | known_hosts_path | allow_unknown_host_key (host-key pin),
#   remote_dir, connect_timeout_seconds.
# Credentials arrive via the injected config (FEED_CONFIG_JSON secret env,
# already loaded into ``config`` by main()) with an env fallback; they are
# NEVER written to the logs.

def _build_delivery_filename(config: dict) -> str:
    """Render the delivered filename for driver-staged destinations (SFTP).

    Mirrors core.feed_engine._legacy_build_filename token expansion
    (``{name}``/``{date}``/``{ext}``/``{timestamp}``/``{uuid}``).  The
    enterprise ``${FUNC()}`` renderer lives server-side and isn't importable
    from the Spark driver, so the batch fallback supports the legacy tokens
    only and falls back to a safe default on any unknown token.
    """
    import uuid as _uuid
    from datetime import datetime as _dt, timezone as _tz

    # The counterparty filename, RESOLVED by QueryStudio.  The
    # enterprise ${FUNC()} renderer, the business calendar and the
    # gapless sequence allocator all live server-side and none is
    # reachable from a Spark driver -- which is exactly why the ANSWER
    # travels and not the logic.  Deriving it here meant a feed
    # templated ${COB_PREV_EOM(YYYYMMDD)} or ${SEQ(6)} was delivered
    # under one name natively and a "safe default" here, silently.
    resolved = _contract(config).get("filename")
    if isinstance(resolved, str) and resolved.strip():
        return resolved.strip()
    template = config.get("output_filename_template") or "{name}_{date}.{ext}"
    feed_name = config.get("feed_name") or "feed"
    fmt = (config.get("output_format") or "csv").lower()
    ext_map = {"csv": "csv", "parquet": "parquet", "json": "jsonl", "excel": "xlsx"}
    ext = ext_map.get(fmt, fmt)
    safe_name = "".join(c if c.isalnum() or c in ("_", "-") else "_" for c in feed_name)
    now = _dt.now(_tz.utc)
    # 2026-10-07 -- {date} is the run's BUSINESS date, as on every other
    # lane (core.feed.filename_renderer.legacy_token_values): the backend
    # ships it in feed_params.  The wall clock only for a run without one.
    _bd = str((config.get("feed_params") or {}).get("business_date_yyyymmdd")
              or "").strip()
    _day = _bd if (len(_bd) == 8 and _bd.isdigit()) else now.strftime("%Y%m%d")
    try:
        return template.format(
            name=safe_name,
            date=_day,
            ext=ext,
            timestamp=now.strftime("%Y%m%d_%H%M%S"),
            uuid=_uuid.uuid4().hex[:8],
        )
    except (KeyError, IndexError, ValueError):
        # Unknown token in the template — never crash the delivery over a
        # filename; deliver under a safe default name instead.
        logger.warning(
            "output_filename_template %r has an unknown token — using default "
            "name instead.", template,
        )
        return f"{safe_name}_{_day}.{ext}"


def _stage_output_to_local(df, config: dict, staging_dir: str) -> dict:
    """Render the deliverable for SFTP into ``staging_dir`` -- the native
    writer on the driver (:func:`_render_on_driver`).

    2026-10-07: this used to be a second CSV writer of its own (a Python
    ``csv.writer`` with three of the dialect's terms, the rest dropped), and
    ``toPandas().to_parquet`` for parquet / Excel -- which can never have
    worked: the job image installs neither pandas nor pyarrow.  Parquet over
    SFTP is now rendered by QueryStudio from the job's artifacts
    (resolve_delivery_owner), and Excel never reaches this lane (K2).
    """
    return _render_on_driver(df, config, staging_dir)


def _sftp_connect_spark(dest_config: dict):
    """Open an authenticated SFTP connection with host-key verification.

    Faithfully mirrors core.feed_engine._sftp_connect: same dest_config keys,
    same host-key resolution order (pinned host_key_b64 → known_hosts_path →
    ~/.ssh/known_hosts) and the same REFUSE-unknown-host default (opt in via
    ``allow_unknown_host_key``).  Never uses AutoAddPolicy.  Credentials come
    from dest_config with an env fallback (SFTP_USERNAME / SFTP_PASSWORD) and
    are never logged.  Returns ``(transport, sftp, host, port)``; the caller
    owns closing both.
    """
    try:
        import paramiko
    except ImportError:
        raise RuntimeError(
            "paramiko is required for SFTP delivery. Install with: pip install paramiko>=3.0.0"
        )

    host = dest_config.get("host", "")
    if not host:
        raise ValueError("SFTP destination requires destination_config.host")
    port = int(dest_config.get("port", 22))
    connect_timeout = int(dest_config.get("connect_timeout_seconds", 30))

    # Host-key verification (mirrors feed_engine BF-415).  Resolve a pinned
    # key via (1) host_key_b64, (2) known_hosts_path / ~/.ssh/known_hosts.
    pinned_host_key = None
    host_key_b64 = (dest_config.get("host_key_b64") or "").strip()
    if host_key_b64:
        import base64 as _b64
        from paramiko import PKey as _PKey
        try:
            _key_blob = _b64.b64decode(host_key_b64)
        except Exception as _hk_exc:
            raise ValueError(f"host_key_b64 is not valid base64: {_hk_exc}")
        for _algo in (
            "ssh-ed25519",
            "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521",
            "rsa-sha2-512", "rsa-sha2-256", "ssh-rsa",
        ):
            try:
                pinned_host_key = _PKey.from_type_string(_algo, _key_blob)
                break
            except Exception:
                continue
        if pinned_host_key is None:
            raise ValueError(
                "host_key_b64 could not be parsed as Ed25519 / ECDSA / RSA "
                "(supplied blob did not match any supported algorithm)"
            )

    if pinned_host_key is None:
        kh_path = dest_config.get("known_hosts_path") or os.path.expanduser("~/.ssh/known_hosts")
        try:
            if os.path.exists(kh_path):
                _hk = paramiko.HostKeys()
                _hk.load(kh_path)
                _entries = _hk.lookup(host) or _hk.lookup(f"[{host}]:{port}")
                if _entries:
                    for _algo in ("ssh-ed25519", "ecdsa-sha2-nistp256",
                                   "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521",
                                   "ssh-rsa"):
                        if _algo in _entries:
                            pinned_host_key = _entries[_algo]
                            break
                    if pinned_host_key is None:
                        pinned_host_key = next(iter(_entries.values()), None)
        except Exception as _kh_exc:
            logger.warning("[sftp] failed to read known_hosts at %s: %s", kh_path, _kh_exc)

    if pinned_host_key is None:
        if dest_config.get("allow_unknown_host_key"):
            logger.warning(
                "[sftp] allow_unknown_host_key=true — connecting to %s:%d WITHOUT "
                "host-key verification (MITM risk).", host, port,
            )
        else:
            raise RuntimeError(
                f"SFTP host {host!r} has no known host key.  Provide one of "
                f"destination_config.host_key_b64 (pinned, recommended), "
                f"destination_config.known_hosts_path, or set "
                f"destination_config.allow_unknown_host_key=true to connect "
                f"without verification (NOT recommended in production)."
            )

    # E-cred: literal config value (from the FEED_CONFIG_JSON secret env)
    # wins; fall back to a plain env var.  NEVER logged.  The backend
    # resolves a system account into the conf before the pod starts
    # (core.spark_k8s.feed_conf.sftp_dest_config_for_pod), so the env vars
    # are only the last resort they always were.
    env_account = {
        "id": "env", "via": "pod env",
        "username": os.environ.get("SFTP_USERNAME", ""),
        "password": os.environ.get("SFTP_PASSWORD", ""),
        "private_key": os.environ.get("SFTP_PRIVATE_KEY", ""),
        "private_key_passphrase": os.environ.get("SFTP_PRIVATE_KEY_PASSPHRASE", ""),
    }
    auth = resolve_sftp_auth(dest_config, env_account)
    logger.info("[sftp] %s:%d authenticating: method=%s user=%s source=%s key_type=%s",
                host, port, auth.method, auth.username, auth.source, auth.key_type)
    import socket as _sock
    _sock_obj = _sock.create_connection((host, port), timeout=connect_timeout)
    transport = paramiko.Transport(_sock_obj)
    try:
        if pinned_host_key is not None:
            # Bias KEX to the pinned key's algorithm so the server doesn't
            # negotiate a different host-key algorithm (spurious mismatch).
            try:
                _algo_name = pinned_host_key.get_name()
                if _algo_name == "ssh-rsa":
                    transport._preferred_keys = ("rsa-sha2-512", "rsa-sha2-256", "ssh-rsa")
                else:
                    transport._preferred_keys = (_algo_name,)
            except Exception:
                pass
            transport.start_client(timeout=connect_timeout)
            _server_key = transport.get_remote_server_key()
            if _server_key is None or (
                _server_key.get_name() != pinned_host_key.get_name()
                or _server_key.asbytes() != pinned_host_key.asbytes()
            ):
                raise RuntimeError(
                    f"SFTP host key mismatch for {host}:{port} — server presented "
                    f"{_server_key.get_name() if _server_key else 'no key'}, "
                    f"expected pinned key.  Refusing to connect (possible MITM)."
                )

        if auth.method == "publickey":
            if pinned_host_key is not None:
                transport.auth_publickey(username=auth.username, key=auth.pkey)
            else:
                transport.connect(username=auth.username, pkey=auth.pkey)
        else:
            if pinned_host_key is not None:
                transport.auth_password(username=auth.username, password=auth.password)
            else:
                transport.connect(username=auth.username, password=auth.password)

        transport.set_keepalive(30)
        sftp = paramiko.SFTPClient.from_transport(transport)
    except Exception:
        try:
            transport.close()
        except Exception:
            pass
        raise
    return transport, sftp, host, port


def _sftp_put_one_spark(sftp, dest_config: dict, filename: str, local_path: str,
                        host: str, port: int) -> dict:
    """Send one file over an open SFTP connection with THE protocol
    (qs_delivery_protocol.sftp_publish -- the native lane's): ``.part``,
    rename into place, remote size check over the same connection, the
    ``remote_dir`` rules.  Returns ``{"uri", "verification", "detail"}``.

    2026-10-07 (K5, inventory C3): this put straight under the FINAL name
    -- a counterparty polling its inbox could ingest a half-written file,
    and a dropped transfer left the fragment under the expected name.
    """
    out = sftp_publish(sftp, dest_config.get("remote_dir", "/"), filename,
                       local_path, log=logger)
    return {"uri": f"sftp://{host}:{port}{out['remote_path']}",
            "verification": out["verification"], "detail": out["detail"]}


def _sftp_upload_spark(local_path: str, dest_config: dict, filename: str) -> dict:
    """Open a connection, send one file, close."""
    transport, sftp, host, port = _sftp_connect_spark(dest_config)
    try:
        return _sftp_put_one_spark(sftp, dest_config, filename, local_path, host, port)
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            transport.close()
        except Exception:
            pass


# ── a large CSV rendered IN PARTS on the executors (2026-10-13) ─────────
#
# The owner: "40 million in 2 h 51 min ... 2 hours won't be accepted".  All
# of that time was ONE process writing 18.4 billion cells of CSV text (the
# driver here, a worker pod on the native lane).  Each executor now renders
# ITS partition with the native writer (qs_lane_output.render_block -- the
# same bytes one process writes), Spark's text writer puts the parts in
# QueryStudio's artifact store in parallel, and the driver sends them IN
# ORDER as one file (qs_delivery_protocol.sftp_publish_parts: .part,
# rename, size check), holding one part on disk at a time.

#: rows rendered per block on an executor (one block = one text element)
PARTS_BLOCK_ROWS = 5000


def _csv_parts_reason(config: dict) -> Optional[str]:
    """None when this run's CSV can be rendered in parts; else why not
    (the driver then renders it, as before)."""
    if str(config.get("output_format") or "csv").strip().lower() != "csv":
        return "not a CSV"
    art = config.get("artifact_config") or {}
    if config.get("artifact_store") != "s3" or not art.get("bucket"):
        return "no artifact store was given to this job"
    return streamable_reason(_csv_dialect(config))


def _parts_uri(config: dict) -> str:
    """Where this run's CSV parts go: under QueryStudio's artifact store,
    the execution's own folder."""
    art = config.get("artifact_config") or {}
    prefix = str(art.get("prefix") or "").strip("/")
    execution_id = str(config.get("execution_id") or "unknown")
    return f"s3a://{art['bucket']}/{prefix + '/' if prefix else ''}{execution_id}/csv-parts"


def _render_csv_parts(df, config: dict) -> dict:
    """Render the CSV's ROWS on the EXECUTORS into ordered text parts in the
    artifact store.  ``{"uri", "rows", "head"}``: the parts' directory, the
    rows written (an accumulator updated inside the write action's own
    tasks) and the file's HEAD -- the header line and a UTF-8 BOM, rendered
    once here on the driver (a result with no partitions has no executor to
    write it)."""
    spark = df.sparkSession
    _apply_artifact_store_s3a(spark, config.get("artifact_config") or {})
    uri = _parts_uri(config)
    dialect = _csv_dialect(config)
    columns = [str(c) for c in df.columns]
    from qs_lane_output import render_block
    head, _ = render_block([], dialect, columns if dialect.get("header", True) else None,
                           str(dialect.get("encoding") or "").strip().lower() == "utf-8-sig")
    jobs_dir = os.path.dirname(os.path.abspath(__file__))
    block = PARTS_BLOCK_ROWS
    written = spark.sparkContext.accumulator(0)
    _PROGRESS.phase("render")
    _PROGRESS.rows_counter = written

    def _render(idx, rows):
        # runs on an EXECUTOR: the job's modules from the image's job dir,
        # and no module-level names (this function travels by value)
        import sys as _sys
        if jobs_dir not in _sys.path:
            _sys.path.insert(0, jobs_dir)
        from qs_lane_output import render_block as _block
        batch = []
        for r in rows:
            batch.append(tuple(r))
            if len(batch) >= block:
                text, n = _block(batch, dialect)
                written.add(n)
                batch = []
                yield text[:-1]          # the text writer adds the final newline back
        if batch:
            text, n = _block(batch, dialect)
            written.add(n)
            yield text[:-1]

    df.rdd.mapPartitionsWithIndex(_render).saveAsTextFile(uri)
    logger.info("WRITE rendered CSV in parts on the executors: %s rows=%d", uri, written.value)
    return {"uri": uri, "rows": int(written.value), "head": head}


def _parts_in_order(spark, uri: str, head: str = "", encoding: str = "utf-8"):
    """The file's HEAD (header line / BOM, when any) as a first local piece,
    then each part of ``uri`` copied to a local temporary file, in part
    order, removed when the next is asked for -- the driver holds one part."""
    import tempfile
    fs, HPath = _hadoop_fs(spark, uri)
    names = sorted(str(st.getPath().getName()) for st in fs.listStatus(HPath(uri))
                   if str(st.getPath().getName()).startswith("part-"))
    _PROGRESS.phase("deliver")
    _PROGRESS.parts_total, _PROGRESS.parts_done = len(names), 0
    tmpdir = tempfile.mkdtemp(prefix="feed_parts_")
    try:
        if head:
            local = os.path.join(tmpdir, "head")
            with open(local, "w", encoding="utf-8", newline="") as fh:
                fh.write(head)          # a BOM is already the first character of ``head``
            yield local
            os.remove(local)
        for name in names:
            local = os.path.join(tmpdir, name)
            fs.copyToLocalFile(False, HPath(f"{uri}/{name}"), HPath("file://" + local), True)
            try:
                yield local
                _PROGRESS.parts_done = (_PROGRESS.parts_done or 0) + 1
            finally:
                try:
                    os.remove(local)
                except OSError:
                    pass
    finally:
        import shutil
        shutil.rmtree(tmpdir, ignore_errors=True)


def _write_sftp_parts(df, config: dict) -> dict:
    """SFTP delivery of a CSV rendered in parts (see above)."""
    dest_config = config.get("destination_config") or {}
    filename = _build_delivery_filename(config)
    r = _render_csv_parts(df, config)
    _check_partitioned_rows(config, r["rows"])        # before anything is published
    header = 1 if _csv_dialect(config).get("header", True) else 0
    transport, sftp, host, port = _sftp_connect_spark(dest_config)
    try:
        out = sftp_publish_parts(sftp, dest_config.get("remote_dir", "/"), filename,
                                 _parts_in_order(df.sparkSession, r["uri"], r["head"]), log=logger)
    finally:
        for c in (sftp, transport):
            try:
                c.close()
            except Exception:
                pass
    try:                                   # the parts are scratch: the delivered file is the record
        fs, HPath = _hadoop_fs(df.sparkSession, r["uri"])
        fs.delete(HPath(r["uri"]), True)
    except Exception as exc:               # noqa: BLE001 -- a leftover, said
        logger.warning("could not remove the rendered parts %s: %s", r["uri"], exc)
    uri = f"sftp://{host}:{port}{out['remote_path']}"
    logger.info("SFTP delivery complete from %d parts: %s bytes=%d sha256=%s (%s)",
                out["parts"], uri, out["bytes"], out["sha256"], out["verification"])
    return {
        "output_row_count": r["rows"],
        "output_path": uri,
        "output_size_bytes": int(out["bytes"]),
        "rendered_in_parts": {"parts": out["parts"], "bytes": out["bytes"], "sha256": out["sha256"]},
        "delivery_receipt": delivery_receipt(
            uri, verification=out["verification"], detail=out["detail"],
            written_rows=r["rows"], physical_rows=max(0, out["lines"] - header)),
    }


def _write_sftp(df, config: dict) -> dict:
    """Deliver the feed over SFTP from the driver.

    Renders the deliverable with the native writer (:func:`_stage_output_to_
    local`), sends it with the native protocol (:func:`_sftp_put_one_spark`)
    over the SAME dest_config shape + host-key verification the native SFTP
    delivery uses, then ALWAYS removes the staging directory -- even on
    failure -- so the (potentially sensitive) feed data never lingers on
    driver disk.  The row count is the rows the renderer WROTE (C4): the
    ``df.count()`` here was a second action over the DataFrame.
    """
    import shutil
    import tempfile

    why_not_parts = _csv_parts_reason(config)
    if why_not_parts is None:
        return _write_sftp_parts(df, config)
    logger.info("CSV rendered on the driver (%s)", why_not_parts)
    dest_config = config.get("destination_config") or {}
    staging_dir = tempfile.mkdtemp(prefix="feed_sftp_")
    try:
        r = _stage_output_to_local(df, config, staging_dir)
        logger.info("Staged feed output for SFTP: %s (format=%s)",
                    r["filename"], config.get("output_format"))
        sent = _sftp_upload_spark(r["path"], dest_config, r["filename"])
        logger.info("SFTP delivery complete: %s (%s)", sent["uri"],
                    sent["verification"])
        return {
            "output_row_count": r["rows"],
            "output_path": sent["uri"],
            # the staged file IS what was sent: the upload's .part->rename->size
            # check proved the remote equals it (2026-10-18: no size was ever
            # reported, so execution.file_size_bytes read 0 for every Spark run)
            "output_size_bytes": os.path.getsize(r["path"]),
            "delivery_receipt": delivery_receipt(
                sent["uri"], verification=sent["verification"],
                detail=sent["detail"], written_rows=r["rows"],
                physical_rows=r["physical_rows"]),
        }
    finally:
        # Clean up the staging dir on every path (success + failure) so feed
        # data + any temp files never linger on the driver.
        try:
            shutil.rmtree(staging_dir, ignore_errors=True)
        except Exception as exc:  # pragma: no cover — defensive
            logger.warning("Failed to clean up SFTP staging dir %s: %s", staging_dir, exc)


# ── Job-side parts manifest (BRD §10.4, 2026-09-02) ──────────────────────
#
# The heavy lane's artifact chain starts HERE: the job writes a
# ``manifest.json`` (PartsManifest schema v1 — the SAME shape
# backend/core/feed/parts_manifest.py loads; a test proves the round-trip)
# next to its part files, naming every part with its rows and bytes.
# QueryStudio then CERTIFIES it against an independent listing
# (core/spark_k8s/artifact_chain.py) and runs
# package -> compress -> encrypt -> checksum + the control file over it.
# This job cannot import backend code (different image, no DB), which is
# why the manifest — not a shared import — is the seam, exactly like the
# serialized source plan.
#
# The per-part row counts come from a distributed RE-READ of the written
# files (groupBy input_file_name): one extra pass, but it counts WHAT WAS
# ACTUALLY WRITTEN, and its total is reconciled against the DataFrame
# count — a count that does not reconcile fails the run rather than
# certifying a torn write.

MANIFEST_NAME = "manifest.json"

#: destination pseudo-URIs that are NOT part-file stores — a run that
#: delivered inside the pod (legacy mode) has nothing to manifest.
_NON_STORE_PREFIXES = ("oracle://", "sftp://")


def _manifest_applicable(output_metrics: dict) -> bool:
    """A parts manifest describes a part DIRECTORY (the artifact store, the
    legacy staging output).  A file the job delivered itself is ONE file
    with a delivery receipt (2026-10-07) -- there are no parts."""
    m = output_metrics or {}
    path = str(m.get("output_path") or "")
    return (bool(path) and not path.startswith(_NON_STORE_PREFIXES)
            and not m.get("delivery_receipt"))


def _list_part_files(spark, output_path: str) -> dict:
    """``{name: bytes}`` of the DATA files at ``output_path``.

    s3a:// paths go through the Hadoop FS API of the live session (same
    credentials, same endpoint as the write itself — no boto3 on this
    image); anything else is a local/NFS directory.  Spark bookkeeping
    files (``_SUCCESS``, dotfiles, ``.crc``) are excluded.
    """
    def _is_data(name: str) -> bool:
        return (bool(name) and not name.startswith((".", "_"))
                and name != MANIFEST_NAME and not name.endswith(".crc"))

    out = {}
    if output_path.startswith(("s3a://", "s3://")):
        jvm = spark._jvm
        hconf = spark._jsc.hadoopConfiguration()
        hpath = jvm.org.apache.hadoop.fs.Path(output_path)
        fs = hpath.getFileSystem(hconf)
        for status in fs.listStatus(hpath):
            if status.isFile():
                name = status.getPath().getName()
                if _is_data(name):
                    out[name] = int(status.getLen())
    else:
        for name in os.listdir(output_path):
            full = os.path.join(output_path, name)
            if os.path.isfile(full) and _is_data(name):
                out[name] = os.path.getsize(full)
    return out


def _count_rows_per_file(spark, config: dict, output_path: str,
                         fmt: str = None) -> dict:
    """``{file_name: data_rows}`` by re-reading what was written.

    Uses ``selectExpr("input_file_name()")`` rather than the pyspark
    functions module so no pyspark import is needed (the module must stay
    importable on a no-JVM image).  A file that contributes no rows (an
    empty part) produces no group — callers default it to 0.

    ``fmt`` is the format the parts were WRITTEN in -- parquet for the
    artifact store whatever the feed's output_format (2026-10-07: reading
    artifacts-only parquet parts back "as CSV" counted lines of binary, so
    every artifacts-only CSV run failed its own reconciliation).
    """
    fmt = (fmt or config.get("output_format") or "parquet").lower()
    if fmt == "csv":
        reader = spark.read.format("csv")
        wopts = _csv_write_options(config)
        reader = reader.option("header", wopts.get("header", "true"))
        if wopts.get("sep"):
            reader = reader.option("sep", wopts["sep"])
    elif fmt == "json":
        reader = spark.read.format("json")
    else:
        # parquet, and the excel->parquet fallback the writers apply
        reader = spark.read.format("parquet")
    df = reader.load(output_path)
    grouped = (
        df.selectExpr("input_file_name() as _qs_file")
        .groupBy("_qs_file").count().collect()
    )
    counts = {}
    for row in grouped:
        uri = str(row["_qs_file"])
        counts[uri.rstrip("/").rsplit("/", 1)[-1]] = int(row["count"])
    return counts


def _write_text_to_store(spark, output_path: str, name: str, text: str) -> str:
    """Write a small text file next to the parts (Hadoop FS for s3a,
    plain file for local).  Returns the full path written."""
    target = output_path.rstrip("/") + "/" + name
    data = text.encode("utf-8")
    if output_path.startswith(("s3a://", "s3://")):
        jvm = spark._jvm
        hconf = spark._jsc.hadoopConfiguration()
        hpath = jvm.org.apache.hadoop.fs.Path(target)
        fs = hpath.getFileSystem(hconf)
        stream = fs.create(hpath, True)
        try:
            stream.write(bytearray(data))
        finally:
            stream.close()
    else:
        with open(target, "wb") as fh:
            fh.write(data)
    return target


def write_job_manifest(spark, config: dict, output_metrics: dict) -> str:
    """Build + write the parts manifest for this run's output.

    The manifest is written ``status="building"`` — certification is
    QueryStudio's act, performed against an INDEPENDENT listing; a job
    that certified its own output would be grading its own homework.

    RECONCILIATION IS A GATE, not a log line: when the re-read per-part
    rows do not sum to the DataFrame count the run FAILS here.  A torn
    or partial write reporting success is the exact defect class the
    heavy lane must never ship (§10.4).
    """
    output_path = str(output_metrics.get("output_path") or "")
    reported = int(output_metrics.get("output_row_count") or 0)

    listing = _list_part_files(spark, output_path)
    counts = (_count_rows_per_file(spark, config, output_path,
                                   output_metrics.get("parts_format"))
              if listing else {})

    parts = []
    total_rows = 0
    total_bytes = 0
    for i, name in enumerate(sorted(listing)):
        rows = int(counts.get(name, 0))
        size = int(listing[name])
        total_rows += rows
        total_bytes += size
        part = {
            "index": i, "name": name, "rows": rows, "bytes": size,
            "location": "s3" if output_path.startswith(("s3a://", "s3://"))
                        else "local",
            "uri": (output_path.rstrip("/") + "/" + name)
                   if output_path.startswith(("s3a://", "s3://")) else None,
            "columns": None, "checksum": None,
        }
        parts.append(part)

    if total_rows != reported:
        raise RuntimeError(
            f"manifest reconciliation FAILED: the written part files "
            f"re-read as {total_rows} rows across {len(parts)} part(s) "
            f"but the job counted {reported} rows — a count that does "
            f"not reconcile is not a count.  Refusing to report this "
            f"run as a success over a torn or partial write.")

    sql_text = ((config.get("query_params") or {}).get("sql") or "")
    ice = (config.get("query_params") or {}).get("iceberg") or {}
    manifest = {
        "_schema_version": 1,
        "parts": parts,
        "schema_b64": "",
        "total_rows": total_rows,
        "total_bytes": total_bytes,
        "status": "building",
        "sql_sha256": (hashlib.sha256(sql_text.encode("utf-8")).hexdigest()
                       if sql_text else ""),
        "build_id": str(config.get("execution_id") or ""),
        "created_at": time.time(),
        "completed_at": None,
        "source": {
            "backend": "spark_k8s",
            "execution_id": config.get("execution_id"),
            "feed_config_id": config.get("feed_config_id"),
            "source_type": config.get("source_type"),
            "output_format": config.get("output_format"),
            # FR-SRC-04 provenance: which snapshot this run was admitted
            # against (Iceberg feeds only).
            "snapshot_id": ice.get("snapshot_id"),
            "delivery_filename": _build_delivery_filename(config),
        },
    }
    target = _write_text_to_store(
        spark, output_path, MANIFEST_NAME,
        json.dumps(manifest, indent=1, default=str))
    logger.info("MANIFEST written path=%s parts=%d rows=%d bytes=%d",
                target, len(parts), total_rows, total_bytes)
    return target


def maybe_write_job_manifest(spark, config: dict, output_metrics: dict) -> None:
    """Manifest policy — fail-closed exactly where the manifest is the
    deliverable:

    * ``delivered=False`` (H1 artifacts-only mode): the manifest IS what
      QueryStudio certifies and delivers from — a failure here FAILS THE
      RUN.  Reporting success without it would strand artifacts nothing
      can certify (an empty file delivered and certified complete is
      this codebase's oldest scar).
    * job-delivered s3/local runs: the manifest is enrichment for the
      later control-file/registration steps — best-effort, loud on
      failure, never fatal (legacy behaviour preserved).
    * oracle/sftp pod-side deliveries: no part-file store exists —
      nothing to manifest, nothing written.
    """
    if not _manifest_applicable(output_metrics):
        logger.info("No artifact store output (%s) — no parts manifest.",
                    output_metrics.get("output_path"))
        return
    try:
        output_metrics["manifest_path"] = write_job_manifest(
            spark, config, output_metrics)
    except Exception:
        if output_metrics.get("delivered") is False:
            raise
        logger.warning(
            "Parts manifest could not be written for a job-delivered run "
            "— continuing (the delivery already happened in this pod).",
            exc_info=True)


# ── Callback ─────────────────────────────────────────────────────────────

def _apply_artifact_store_s3a(spark, artifact_config: dict) -> None:
    """Point s3a at QueryStudio's ARTIFACT STORE -- for that bucket only.

    K6 (2026-10-07).  The backend resolves the store's identity
    (``spark_k8s.artifact_connection_id``) into ``artifact_config.s3a``,
    which reaches this pod in the per-run Secret (FEED_CONFIG_JSON), never
    on the command line.  Set as PER-BUCKET keys
    (``fs.s3a.bucket.<bucket>.*``) on the live Hadoop configuration before
    the first write to that bucket: the executors' write, the manifest
    listing and the manifest write all read them, and a global
    ``fs.s3a.access.key`` would re-credential the feed's OWN s3 source
    reads.  No ``s3a`` block = the pod's ambient identity (IRSA, an
    instance profile, s3a keys in spark_k8s.spark_conf)."""
    _apply_bucket_s3a(spark, str((artifact_config or {}).get("bucket") or ""),
                      (artifact_config or {}).get("s3a") or {}, "ARTIFACT store")


def _apply_bucket_s3a(spark, bucket: str, s3a: dict, label: str) -> None:
    """Credential ONE bucket for s3a (``fs.s3a.bucket.<bucket>.*``) from a
    block the backend resolved through its credential chokepoint and shipped
    in the run's Secret.  Per bucket, so the artifact store, a cloud (AWS)
    source bucket and an on-prem (MinIO) source bucket coexist in one session.
    No block = the pod's ambient identity."""
    if not s3a or not bucket:
        return
    hconf = spark._jsc.hadoopConfiguration()
    p = f"fs.s3a.bucket.{bucket}."
    endpoint = str(s3a.get("endpoint") or "")
    if endpoint:
        hconf.set(p + "endpoint", endpoint)
        if endpoint.startswith("http://"):
            hconf.set(p + "connection.ssl.enabled", "false")
    if s3a.get("region"):
        hconf.set(p + "endpoint.region", str(s3a["region"]))
    hconf.set(p + "path.style.access",
              "true" if s3a.get("path_style") else "false")
    key = str(s3a.get("access_key_id") or "")
    secret = str(s3a.get("secret_access_key") or "")
    token = str(s3a.get("session_token") or "")
    if key and secret:
        hconf.set(p + "access.key", key)
        hconf.set(p + "secret.key", secret)
        if token:
            hconf.set(p + "session.token", token)
            hconf.set(p + "aws.credentials.provider",
                      "org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider")
        else:
            hconf.set(p + "aws.credentials.provider",
                      "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider")
    logger.info("%s s3a://%s endpoint=%s path_style=%s creds=%s", label,
                bucket, endpoint or "(aws)", bool(s3a.get("path_style")),
                "declared" if key else "ambient")


def _resolve_webhook_secret() -> str:
    """Resolve the HMAC secret the QueryStudio feed webhook requires.

    Audit gap #6 — the feed webhook (``api/feed_api.py`` →
    ``/api/webhooks/feed-complete``) REQUIRES ``X-Webhook-Signature``: it
    returns 503 when ``feed_generation.webhook_secret`` is unset and 401
    when the header is missing/invalid.  This Spark job therefore MUST sign
    its callback with the SAME secret the server verifies against.

    The secret is delivered to the driver as an env var — ``FEED_WEBHOOK_SECRET``
    (preferred) with ``WEBHOOK_SECRET`` as a fallback — sourced from the same
    K8s secret that carries ``feed_generation.webhook_secret``.  Empty string
    when neither is set (the caller then logs a loud warning and the server
    will reject with 503/401 — never a silent unauthenticated accept).
    """
    return (
        os.environ.get("FEED_WEBHOOK_SECRET")
        or os.environ.get("WEBHOOK_SECRET")
        or ""
    )


def _sign_webhook_payload(secret: str, payload: dict):
    """Serialise ``payload`` to the EXACT bytes that will be POSTed and, when a
    secret is present, compute the ``X-Webhook-Signature`` header.

    This mirrors the server verification in ``api/feed_api.py`` byte-for-byte
    (see ``webhook_feed_complete``, ~lines 1011-1013):

        raw_body = await request.body()
        expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
        hmac.compare_digest(f"sha256={expected}", sig_header)

    The signature is computed over the SAME ``body`` bytes we hand to
    ``requests`` via ``data=`` (NOT ``json=``) — signing the exact wire bytes
    is what makes the server's ``request.body()`` hash match.  Returns
    ``(body_bytes, headers)``.
    """
    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if secret:
        digest = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
        headers["X-Webhook-Signature"] = f"sha256={digest}"
    return body, headers


#: Where Kubernetes reads a container's termination message from
#: (``terminationMessagePath`` default); the kubelet keeps the LAST 4096
#: bytes and surfaces them as ``containerStatuses[].state.terminated.message``
#: -- a channel that survives the driver and that the reconciler reads
#: (core/spark_k8s/completion.py).  Overridable for a test.
TERMINATION_LOG_ENV = "QS_TERMINATION_LOG"
TERMINATION_LOG_DEFAULT = "/dev/termination-log"
#: Under the kubelet's 4096 so the HEAD (execution_id, state) survives.
TERMINATION_MAX_BYTES = 4000


def _compact_report(payload: dict, limit: int = TERMINATION_MAX_BYTES) -> bytes:
    """The report as compact JSON within ``limit`` bytes.  Trimmed by
    PRIORITY, never cut mid-document: the receipt's prose first, then the
    merge record's column lists (the counts stay), then the error text, then
    the receipt itself.  The counts, the verdict flag and the merge record's
    per-side rows are what an auditor needs; they are the last to go."""
    def _dump(p):
        return json.dumps(p, separators=(",", ":"), default=str).encode("utf-8")
    p = json.loads(json.dumps(payload, default=str))
    out = _dump(p)
    if len(out) <= limit:
        return out
    rc = p.get("delivery_receipt")
    if isinstance(rc, dict):
        rc.pop("verification_detail", None)
        out = _dump(p)
        if len(out) <= limit:
            return out
    xs = p.get("cross_source")
    if isinstance(xs, dict) and isinstance(xs.get("merge"), dict):
        xs["merge"] = {k: v for k, v in xs["merge"].items()
                       if not isinstance(v, list)}
        xs["merge"]["trimmed"] = "column lists dropped to fit the termination message"
        out = _dump(p)
        if len(out) <= limit:
            return out
    if isinstance(p.get("error"), str):
        p["error"] = p["error"][:600]
        out = _dump(p)
        if len(out) <= limit:
            return out
    p.pop("delivery_receipt", None)
    out = _dump(p)
    if len(out) <= limit:
        return out
    # last resort: the head alone -- still a report
    keep = {k: p.get(k) for k in ("execution_id", "state", "output_path",
                                   "output_row_count", "delivered",
                                   "lane_output_version")}
    return _dump(keep)


def write_termination_report(payload: dict, path: str = None) -> Optional[str]:
    """Write the completion report where Kubernetes will keep it after the
    driver exits (2026-10-11).  The callback can be lost -- the API under
    load answered past the 30 s timeout and 1 of 10 owner-case runs was
    closed by the reconciler with no row count and no merge record -- so
    the SAME payload the callback carries is written here FIRST, and the
    reconciler reads it from the pod.  Never fails the job: a pod with no
    termination file (a local run) logs and moves on."""
    target = path or os.environ.get(TERMINATION_LOG_ENV) or TERMINATION_LOG_DEFAULT
    try:
        body = _compact_report(payload)
        with open(target, "wb") as fh:
            fh.write(body)
        logger.info("REPORT written to %s (%d bytes) state=%s", target, len(body),
                    payload.get("state"))
        return target
    except OSError as exc:
        logger.warning("REPORT could not be written to %s (%s) -- only the "
                       "callback carries this run's report", target, exc)
        return None


#: The callback's budget: each attempt's read timeout, how many, and the
#: pauses between them (2026-10-11).  Worst case ~2.5 minutes of driver
#: time -- the report is already on disk, the reconciler is the floor.
CALLBACK_TIMEOUT_SECONDS = 30
CALLBACK_ATTEMPTS = 3
CALLBACK_BACKOFF_SECONDS = (5, 15)


def _callback_sleep(seconds: float) -> None:
    """A seam: the retry's pause (a test runs it at zero)."""
    time.sleep(seconds)


class _JobProgress:
    """WHERE THIS RUN IS, told to QueryStudio while it runs (2026-10-14,
    backend core/feed/run_progress.py, route /api/webhooks/feed-progress).

    Every ``progress.interval_seconds`` (the conf's ``progress`` block, set
    by the runner) a daemon thread reports: the phase the job is in (set at
    each step by :meth:`phase`), Spark's OWN task counters for the stages
    running now (``statusTracker`` -- never an estimate), the parts sent
    while delivering, the rows the render has written, and the job's log
    lines since the last report.  It also logs ``PROGRESS ...`` so the
    driver log alone says where the run is.  Signed like the completion
    callback.  A report that cannot be sent is logged and dropped -- the
    run never waits on, or fails because of, its progress."""

    def __init__(self):
        self.phase_name = "start"
        self.phase_started = time.time()
        self.started = time.time()
        self.parts_done = None
        self.parts_total = None
        self.rows_counter = None
        self._spark = None
        self._thread = None
        self._stop = None
        self._url = ""
        self._interval = 0
        self._execution_id = ""
        self._secret = ""

    def phase(self, name: str) -> None:
        self.phase_name = name
        self.phase_started = time.time()
        self.parts_done = self.parts_total = None
        logger.info("PHASE %s", name)

    def start(self, spark, config: dict, execution_id: str) -> None:
        import threading
        conf = config.get("progress") or {}
        self._url = str(conf.get("url") or "")
        try:
            self._interval = int(conf.get("interval_seconds") or 0)
        except (TypeError, ValueError):
            self._interval = 0
        self._spark, self._execution_id = spark, execution_id
        self._secret = _resolve_webhook_secret()
        if not self._url or self._interval <= 0:
            logger.info("PROGRESS reports off (no progress url / interval in the conf)")
            return
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="qs-progress", daemon=True)
        self._thread.start()
        logger.info("PROGRESS reported every %ds to %s", self._interval, self._url)

    def _loop(self):
        while not self._stop.wait(self._interval):
            self.report()

    def executors_lost(self) -> list:
        """Every executor Spark removed, with Spark's own reason (``exited
        with exit code 137 ... OOMKilled``) -- from the driver's status
        store, so a run that is losing executors SAYS so while it runs and
        when it fails.  [] when it cannot be read."""
        out = []
        try:
            seq = self._spark.sparkContext._jsc.sc().statusStore().executorList(False)
            for i in range(seq.size()):
                ex = seq.apply(i)
                if ex.isActive() or str(ex.id()) == "driver":
                    continue
                reason = ex.removeReason()
                out.append({"id": str(ex.id()),
                            "reason": str(reason.get()) if reason.isDefined() else ""})
        except Exception:                                      # noqa: BLE001
            return []
        return out

    def records_read(self):
        """Rows the ACTIVE stages have read so far, from the driver's status
        store -- the one counter that moves INSIDE a long task (2026-10-26).
        A 600-column Starburst side with no partition key is ONE JDBC
        partition, so its render is ONE task: ``rows_written`` (an
        accumulator, visible when a task ends) and the task counters stayed
        at 0 for the whole hour it took, and the engine's stall rule reads
        the counters.  None when it cannot be read."""
        try:
            seq = self._spark.sparkContext._jsc.sc().statusStore().activeStages()
            total = 0
            for i in range(seq.size()):
                total += int(seq.apply(i).inputRecords())
            return total
        except Exception:                                      # noqa: BLE001
            return None

    def _counters(self) -> dict:
        out = {"tasks_done": None, "tasks_total": None, "tasks_active": None,
               "tasks_failed": None, "stages_active": 0, "stage": ""}
        if self.parts_total is not None:              # delivering: parts are the unit
            out.update(tasks_done=self.parts_done or 0, tasks_total=self.parts_total,
                       stage="parts sent")
            return out
        try:
            st = self._spark.sparkContext.statusTracker()
            infos = [i for i in (st.getStageInfo(s) for s in st.getActiveStageIds()) if i]
        except Exception:                                      # noqa: BLE001
            return out
        if infos:
            out.update(tasks_done=sum(i.numCompletedTasks for i in infos),
                       tasks_total=sum(i.numTasks for i in infos),
                       tasks_active=sum(i.numActiveTasks for i in infos),
                       tasks_failed=sum(i.numFailedTasks for i in infos),
                       stages_active=len(infos),
                       stage="; ".join(str(i.name)[:80] for i in infos))
        return out

    def report(self) -> None:
        now = time.time()
        payload = {"execution_id": self._execution_id, "phase": self.phase_name,
                   "elapsed_seconds": round(now - self.started, 1),
                   "phase_elapsed_seconds": round(now - self.phase_started, 1)}
        payload.update(self._counters())
        lost = self.executors_lost()
        if lost:
            payload["executors_lost"] = len(lost)
            payload["executor_loss_reason"] = " ".join(lost[-1]["reason"].split())[:300]
        try:
            if self.rows_counter is not None:
                payload["rows_written"] = int(self.rows_counter.value)
        except Exception:                                      # noqa: BLE001
            pass
        read = self.records_read()
        if read is not None:
            payload["records_read"] = read
        logger.info("PROGRESS phase=%s tasks=%s/%s active=%s failed=%s rows_written=%s "
                    "records_read=%s executors_lost=%s stage=%s",
                    payload["phase"], payload.get("tasks_done"), payload.get("tasks_total"),
                    payload.get("tasks_active"), payload.get("tasks_failed"),
                    payload.get("rows_written"), payload.get("records_read", "-"),
                    payload.get("executors_lost", 0), payload.get("stage") or "-")
        payload["log_lines"] = _LINES.drain()
        if not self._url:
            return
        try:
            import requests
            body, headers = _sign_webhook_payload(self._secret, payload)
            resp = requests.post(self._url, data=body, headers=headers, timeout=10)
            if resp.status_code >= 400:
                logger.debug("PROGRESS report refused http=%d", resp.status_code)
        except Exception as exc:                               # noqa: BLE001
            logger.debug("PROGRESS report not sent: %s", exc)

    def stop(self) -> None:
        """The last report (the final phase and lines), BEFORE the completion
        callback, so the progress record never lands on a closed row."""
        if self._stop is not None:
            self._stop.set()
            self._thread.join(timeout=15)
            self.report()


_PROGRESS = _JobProgress()


def send_callback(callback_url: str, execution_id: str, state: str,
                   output_path: str = None, error: str = None,
                   metrics: dict = None):
    """POST completion callback to QueryStudio webhook endpoint.

    Audit gap #6 fix: sign the request with HMAC-SHA256 so the (mandatory)
    server-side signature check accepts it.  Without this the Spark fallback
    path always got 401/503 and the execution never left ``running``.
    """
    import requests

    payload = {
        "execution_id": execution_id,
        "state": state,
        "output_path": output_path,
        "error": error,
    }
    if metrics:
        payload.update(metrics)

    # The durable copy FIRST: whichever finaliser wins -- this callback or
    # the reconciler reading the pod -- closes the row from the same report.
    write_termination_report(payload)

    if not callback_url:
        logger.info("CALLBACK skipped -- no callback URL was given")
        return

    secret = _resolve_webhook_secret()
    if not secret:
        # Loud, not silent: the server requires a signature, so an unsigned
        # callback will be rejected (503/401).  Surface the misconfiguration.
        logger.warning(
            "No FEED_WEBHOOK_SECRET / WEBHOOK_SECRET in the Spark driver env — "
            "the feed webhook will reject this callback (it requires a valid "
            "X-Webhook-Signature).  Wire the secret into the SparkApplication "
            "driver env (see querystudio_feed_factory + k8s/airflow docs)."
        )

    body, headers = _sign_webhook_payload(secret, payload)

    # 2026-10-11 -- RETRIED, with backoff.  Found live: under 29 overlapping
    # runs the API finalised inside the request and passed this call's 30 s
    # read timeout; the one attempt logged "CALLBACK failed ... Read timed
    # out" and the SUCCESS report was lost to the webhook.  Retrying is safe
    # because the server ACKs by CLAIMING the report (spark_job_reports,
    # UNIQUE per execution) and finalises off the request, first writer
    # wins: a second delivery of the same report is answered "already
    # received" (200) or "already terminal" (409) and changes nothing.
    # A 4xx other than 409 is a verdict on this request (bad signature,
    # unknown execution) -- not retried.
    for attempt in range(1, CALLBACK_ATTEMPTS + 1):
        try:
            # data=body (not json=payload) so the bytes we SIGN are the exact
            # bytes the server hashes in request.body() — otherwise requests
            # re-encodes and the HMAC never matches.
            resp = requests.post(callback_url, data=body, headers=headers,
                                 timeout=CALLBACK_TIMEOUT_SECONDS)
            if resp.status_code == 409:
                logger.info("CALLBACK not needed state=%s http=409: the run is "
                            "already terminal (another finaliser closed it)", state)
                return
            if 400 <= resp.status_code < 500:
                logger.error("CALLBACK refused state=%s http=%d url=%s -- not retried",
                             state, resp.status_code, callback_url)
                return
            resp.raise_for_status()
            logger.info("CALLBACK sent state=%s http=%d signed=%s attempt=%d url=%s",
                        state, resp.status_code, bool(secret), attempt, callback_url)
            return
        except Exception as exc:
            if attempt >= CALLBACK_ATTEMPTS:
                logger.error("CALLBACK failed state=%s url=%s after %d attempts: %s "
                             "(the termination report stands; the reconciler will "
                             "finalise from it)", state, callback_url, attempt, exc)
                return
            delay = CALLBACK_BACKOFF_SECONDS[min(attempt - 1, len(CALLBACK_BACKOFF_SECONDS) - 1)]
            logger.warning("CALLBACK attempt %d/%d failed (%s) -- retrying in %ss",
                           attempt, CALLBACK_ATTEMPTS, exc, delay)
            _callback_sleep(delay)


# ── Main ─────────────────────────────────────────────────────────────────

def main():
    args = parse_args()
    # Tag every line from here on -- including the config-load line.
    _RunTag.exec_id = str(args.execution_id or "-")

    config = load_feed_config(args.feed_config)
    execution_id = args.execution_id
    callback_url = args.callback_url

    # Inject execution_id into config for downstream use
    config["execution_id"] = execution_id
    _RunTag.exec_id = str(execution_id or "-")

    _pod, _attempt = _pod_identity()
    _fp = config.get("feed_params") or {}
    logger.info(
        "START feed=%s id=%s business_date=%s backend=spark_k8s pod=%s "
        "attempt=%d source=%s dest=%s deliver_in_job=%s",
        config.get("feed_name"), config.get("feed_config_id"),
        _fp.get("business_date") or "-", _pod or "-", _attempt,
        config.get("source_type"), config.get("destination_type"),
        job_delivers(config))

    start_time = time.time()

    try:
        from pyspark.sql import SparkSession

        spark = SparkSession.builder \
            .appName(f"QueryStudio Feed - {config.get('feed_name', 'unknown')}") \
            .getOrCreate()

        logger.info("SPARK session up version=%s app=%s", spark.version,
                    spark.sparkContext.applicationId)
        _read_parquet_with_the_reference_reader(spark)
        _PROGRESS.start(spark, config, execution_id)

        # 1. Read source(s)
        #    2026-08-04: when the conf carries a backend-resolved
        #    ``source_plan``, EXECUTE it (primary + secondary + combine,
        #    all pre-resolved by core.feed.source_plan on the backend) —
        #    this job is a renderer, not a second resolver.  Confs without
        #    a plan take the legacy path unchanged: read_source +
        #    maybe_combine_sources (Phase 130 hotfix-13 semantics).
        _PROGRESS.phase("read")
        source_plan = config.get("source_plan")
        if source_plan:
            df = read_from_plan(spark, config, source_plan)
        else:
            df = read_source(spark, config)
            df = maybe_combine_sources(spark, df, config)
        # E-H2: cache the source once so the source SQL / S3 scan is issued a
        # SINGLE time — apply_transform's input count + every downstream
        # action then read from the cache instead of re-running the source.
        # A cross-source run's SIDES are already persisted
        # (_combine_cross_source): the union of two persisted sides reads
        # no source again, and a second copy would double the executors'
        # storage for nothing.
        _acts = _actions_over_the_read(config)
        if not config.get("_cross_source") and len(_acts) > 1:
            logger.info("CACHE the read: %d actions read it (%s)", len(_acts), ", ".join(_acts))
            df = _cache_df(df)
        elif not config.get("_cross_source"):
            logger.info("NOT CACHED: one action reads the result (%s) -- a cache would "
                        "materialise every row for nothing", _acts[0])

        # 1b. Per-side REPORTED-ROWS certification (2026-10-11), before any
        #     write: the sides the dependencies vouch for must count what the
        #     upstream's message said.  The expected counts came in the conf
        #     (``reported_side_rows``, resolved once by the backend); a
        #     mismatch fails the job here with the numbers.
        _PROGRESS.phase("certify")
        rr_record = _certify_reported_rows(config, df)

        # 2. Transform
        _pre_transform = df
        _PROGRESS.phase("transform")
        df, input_count = apply_transform(spark, df, config)
        # E-H2: cache the transformed result so write_output's post-write
        # count doesn't recompute the whole transform lineage a second time.
        # 2026-10-13 -- NOT when nothing was transformed: the frame is then
        # the one above (already cached, or the union of two persisted
        # sides), and caching a cross-source union here put the whole result
        # IN MEMORY beside the render -- the owner's 1M x 460 month end died
        # OutOfMemoryError in every 3g executor while pickling rows to the
        # CSV renderer.
        if df is not _pre_transform:
            df = _cache_df(df)

        # 3. Write to destination
        _PROGRESS.phase("write")
        output_metrics = write_output(df, config)
        _check_partitioned_rows(config, output_metrics.get("output_row_count"))
        # No transform and no reconciliation: rows in ARE rows written
        # (apply_transform skipped the extra action, C4).
        output_metrics["input_row_count"] = (
            input_count if input_count is not None
            else output_metrics.get("output_row_count"))
        # Which output rules rendered this run's bytes (qs_lane_output):
        # the webhook names an image that predates the lane contract.
        output_metrics["lane_output_version"] = LANE_OUTPUT_VERSION
        # 2026-10-10 -- the MERGE record of a cross-source run
        # (qs_merge_by_name.cross_source_record, THE shape the native lane
        # writes): what went in per side, what came out.  The completion
        # webhook stores it under files_metadata.cross_source.
        if config.get("_cross_source"):
            output_metrics["cross_source"] = dict(
                config["_cross_source"],
                combined_rows=output_metrics.get("output_row_count"))
            logger.info("MERGE record %s",
                        json.dumps(output_metrics["cross_source"], default=str))
        if rr_record is not None:
            # the webhook stores it under stage_timings.reported_rows_certification
            output_metrics["reported_rows_certification"] = rr_record
        if config.get("_partitioned_read"):
            # how each side was split (or why not) -- files_metadata.partitioned_read,
            # the slot the native lane writes
            output_metrics["partitioned_read"] = config["_partitioned_read"]

        # 3b. Parts manifest (§10.4) — the artifact chain's first link.
        #     Fail-closed in artifacts-only mode (the manifest IS the
        #     deliverable there); best-effort for job-delivered runs.
        maybe_write_job_manifest(spark, config, output_metrics)

        duration = time.time() - start_time
        logger.info(
            "DONE status=success rows_in=%s rows_out=%s dest=%s duration=%.1fs",
            input_count, output_metrics.get("output_row_count"),
            output_metrics.get("output_path") or "-", duration)

        # 4. Callback -- the last progress report first (never on a closed row)
        _PROGRESS.phase("done")
        _PROGRESS.stop()
        send_callback(
            callback_url, execution_id, "success",
            output_path=output_metrics.get("output_path"),
            metrics=output_metrics,
        )

        spark.stop()
        sys.exit(0)

    except Exception as exc:
        duration = time.time() - start_time
        logger.error("DONE status=failed duration=%.1fs error=%s",
                     duration, exc, exc_info=True)

        # The whole report, cause chain included (the webhook keeps it as
        # the run's stage detail and stores ONE sentence as the headline --
        # core/spark_k8s/failure_text.py).
        # 2026-10-11 -- a REFUSED reported-rows certification travels with the
        # failure (it was stashed and dropped): the record is the audit of WHY
        # the run refused, and names the stage, like the native lane.
        _PROGRESS.phase("failed")
        _PROGRESS.stop()
        _fail_metrics = {}
        # what Spark itself removed, with its reasons: the headline leads with
        # it (core/spark_k8s/failure_text.py) -- "Job 1 cancelled because
        # SparkContext was shut down" alone hid four OOM-killed executors
        _lost = _PROGRESS.executors_lost()
        if _lost:
            _fail_metrics["executors_lost"] = _lost[:50]
        _rr = (locals().get("config") or {}).get("_reported_rows_certification")
        if isinstance(_rr, dict) and _rr:
            _fail_metrics["reported_rows_certification"] = _rr
            _fail_metrics["failed_stage"] = "certify_reported_rows"
        send_callback(
            callback_url, execution_id, "failed",
            error=str(exc)[:6000],
            metrics=_fail_metrics or None,
        )

        sys.exit(1)


if __name__ == "__main__":
    main()
