# QueryStudio — Multi-Component Helm Layout

One Helm chart per QueryStudio component. Each chart is **completely
self-contained** — its `templates/` folder carries every Kubernetes object
it needs (Deployment, Service, ConfigMap, ServiceAccount, RBAC, PVC, Secret,
HPA, PDB). No shared chart, no umbrella, no cross-chart references.

```
k8s/querystudioapi-helm/
├── api/                FastAPI coordinator (stateless, HPA)
├── ui/                 React/Vite frontend (nginx)
├── published-api/      Dedicated /api/v1/* consumer-facing pod
├── worker/             Multi-pod query worker pool (BF-384 / Option G) -- disabled, W4
├── feed-worker/        Feed run queue worker pool (feed_worker.py; claims feed_runs)
├── scheduler/          Singleton scheduler (cron, queue dispatch)
├── spark-connect/      Spark Connect gRPC server (zero-download S3 path)
├── etl-polling/        ETL polling service (Oracle queue → workflow runners)
├── env/                Per-environment values overlays (dev/uat/prod)
├── .gitlab-ci.yml      Per-component build + helm-deploy pipeline
├── deploy.sh           Local install wrapper
└── README.md
```

No Redis. `cache.backend=memory`, `queue.backend=database` (Postgres
`FOR UPDATE SKIP LOCKED`).

## Self-contained charts

Each chart owns its own:

| Object              | Per-component file                          |
|---------------------|---------------------------------------------|
| Deployment          | `<chart>/templates/deployment.yaml`         |
| Service             | `<chart>/templates/service.yaml`            |
| ConfigMap           | `<chart>/templates/configmap.yaml`          |
| ServiceAccount      | `<chart>/templates/serviceaccount.yaml`     |
| RBAC (where needed) | `<chart>/templates/rbac.yaml`               |
| Secret (where needed)| `<chart>/templates/secret.yaml`            |
| PVC (where needed)  | `<chart>/templates/pvc.yaml`                |
| HPA                 | `<chart>/templates/hpa.yaml`                |
| PDB                 | `<chart>/templates/pdb.yaml`                |
| Route (api/ui/reports/downloads) / Cert (every chart that mounts one: api/ui/reports/downloads/published-api) | `<chart>/templates/{route,cert}.yaml` |

ServiceAccount names are **unique per chart** (e.g. `querystudio-api-sa`,
`querystudio-worker-sa`) so two charts can never own the same SA.

## Shared resources — who creates them?

The shared NFS PVC + app-secret + worker-auth-secret are created by the
`api` chart **by default** (it's deployed first). Other charts reference
them by name via `existingClaim` / `existingSecret`.

To move ownership elsewhere — flip the `create:` flag:

```yaml
# api/values.yaml — to stop api creating shared resources:
persistence:
  create: false
secrets:
  appSecret:
    create: false
  workerAuthSecret:
    create: false

# worker/values.yaml — to let worker create them instead:
persistence:
  create: true
```

Or pre-create them out-of-band (cluster operator, External Secrets, Vault)
and set every chart's `create: false`.

## Shared Docker image strategy

QueryStudio builds **3 Docker images** (root `.gitlab-ci.yml` owns the build):

| Image                       | Built from                  | Consumed by (charts)                                                |
|-----------------------------|-----------------------------|---------------------------------------------------------------------|
| `querystudio-api`           | `Dockerfile.api`            | **api, published-api, worker, feed-worker, scheduler**              |
| `querystudio-ui`            | `Dockerfile.ui`             | ui                                                                  |
| `querystudio-etl-polling`   | `ETL/Dockerfile.polling-service` | etl-polling (has oracledb deps not in querystudio-api)         |
| _(upstream)_ `apache/spark` | n/a                         | spark-connect                                                       |

**5 backend pods share the same `querystudio-api` image** — the role is
selected at runtime, not at build time. The discriminator pattern:

| Chart           | Container command            | Role discriminator (in `runtime.env`)                          |
|-----------------|------------------------------|-----------------------------------------------------------------|
| api             | `python -m main`             | _(default)_                                                     |
| worker          | `python -m querystudio webserver` | `QS_NODE_ROLE=worker` (DISABLED by default -- W4, see `worker/values.yaml`) |
| feed-worker     | `python -m querystudio feed-worker` | none needed -- the exec line IS the role (`backend/feed_worker.py`); `QUERYSTUDIO_FEED_SHARD` optional |
| scheduler       | `python -m querystudio scheduler`   | `QS_POD_ROLE=worker`; `QUERYSTUDIO_SCHEDULER_MODE=external` (the only spellings the code knows are `embedded`/`external`) |
| published-api   | `python -m main`             | `QS_PUBLISHED_API_MODE=true` — main.py mounts only `/api/v1/*` routers |

Because the image is shared, **one CI build serves five charts**. The image
tag flows through every chart's `image.tag` value at deploy time:

```bash
# Root CI builds and pushes one image
docker build -f Dockerfile.api -t ${REGISTRY}/${NS}/querystudio-api:${SHA} .
docker push ${REGISTRY}/${NS}/querystudio-api:${SHA}

# Each chart's deploy job sets --set image.tag=${SHA}
helm upgrade --install qs-api          ./api          --set image.tag=${SHA} ...
helm upgrade --install qs-worker       ./worker       --set image.tag=${SHA} ...
helm upgrade --install qs-feed-worker  ./feed-worker  --set image.tag=${SHA} ...
helm upgrade --install qs-scheduler    ./scheduler    --set image.tag=${SHA} ...
helm upgrade --install qs-published-api ./published-api --set image.tag=${SHA} ...
```

All 5 pods then pull the SAME `querystudio-api:${SHA}` and boot into their
distinct roles via the ConfigMap-mounted `runtime.env`.

### Why not separate images?

Earlier drafts gave published-api its own `querystudio-published-api` image.
That was double work: identical Python deps, identical wheels cached, twice
the CI time. The single-image-multi-command pattern is how Airflow (one
image, role=scheduler/webserver/worker via `args`) and most Python services
ship.

### When to break out a separate image

- **Different OS / interpreter deps** — e.g., etl-polling needs `oracledb`,
  which adds ~150 MB of Oracle Instant Client; not worth bundling into the
  shared image used by 5x more replicas.
- **Different security profile** — e.g., consumer-facing pods need a
  hardened image without dev tooling.
- **Different release cadence** — e.g., a pod whose code releases
  independently of the main monorepo.

None of those apply to the 5 backend charts above; `etl-polling` is the only
exception today.

## Pod classes + scaling

| Pod class       | Replicas (prod) | Scaling signal                |
|-----------------|-----------------|-------------------------------|
| api             | 3 → 10          | HPA on CPU + memory           |
| ui              | 2 → 4           | HPA on CPU                    |
| published-api   | 2 → 8           | HPA on CPU                    |
| worker          | 0 (disabled)    | see worker/values.yaml (W4)   |
| feed-worker     | 2 → 10          | HPA on CPU + memory (queue depth would be the honest signal; no custom metric yet) |
| scheduler       | 1 (always)      | Singleton — PDB minAvailable=1|
| spark-connect   | 1 driver, N executors | Spark dynamicAllocation  |
| etl-polling     | 1 (always)      | Singleton — PDB minAvailable=1|

`api` is the only pod that talks to **everything else** (workers,
spark-connect, postgres, published-api). Worker pods are stateless and
discovered via the headless service `querystudio-worker.<ns>.svc.cluster.local`.

The metadata Postgres lives outside this chart (operator-managed
StatefulSet at `postgresqlnew-server-<env>-svc`).

## Spark connectivity

Two paths:

1. **Spark Connect (default for big queries)** — `api`/`worker` pods open
   a gRPC session to `sc://spark-connect-server:15002`. Spark reads
   `s3a://` directly inside the cluster; only Arrow result batches travel
   back. Tuned via `sparkConnect.rowThreshold` in `api/values.yaml`.
2. **DuckDB local fall-back** — anything below `rowThreshold` runs locally
   in the API/worker pod against parquet on the NFS PVC.

See `spark-connect/` for the gRPC server chart and `spark-connect/values.yaml`
for executor sizing, S3A defaults, dynamic-allocation knobs.

## ETL polling

`etl-polling/` is a singleton service that:

1. Polls Oracle's `polling_query_sb_to_file` table on `pollIntervalSeconds`.
2. Claims new RUN_ID rows via DBMS_LOCK (so multiple pollers won't race).
3. Dispatches workflow runners (file-flow standalone / s3 query / SAP OData)
   either in-process (lightweight mode) or as K8s Jobs (when RBAC
   `jobLaunching: true`).
4. Exposes `/health` on `:9000` for liveness/readiness.

Per-environment Oracle host + Starburst host overrides go in `env/*.yaml`.

## Deploy order

CI runs them sequentially because later charts have implicit dependencies
on earlier ones (Secret + PVC names that api creates by default).

What `deploy.sh` installs, in order (2026-10-25: the list names only charts
that exist in this directory; `spark-connect` is the plain manifests under
`k8s/spark-connect/`, not a chart here, and there is no `etl-polling` chart):

1. `api/`              — always (creates shared PVC + secrets unless overridden)
2. `worker/`           — DISABLED (W4): commented out in `deploy.sh`, renders replicas=0
3. `feed-worker/`      — runs `feed-worker`; set the scheduler chart's `querystudioRole.feed_generation.worker_pod_only=true` to move all claiming here.  With `sparkK8s.enabled` it also submits Spark jobs (its own `rbac-spark-k8s.yaml`), like the api and scheduler charts
4. `scheduler/`        — the one daemon host (APScheduler lock holder)
5. `published-api/`    — the published-API surface pod
6. `reports/`          — opt-in surface pod: receives traffic only with `route.enabled` + the ui chart's `config.reportApiUrl`
7. `downloads/`        — opt-in surface pod: `route.enabled` + the ui chart's `config.downloadApiUrl`
8. `ui/`               — always

## Local install

```bash
./deploy.sh dev    # uses env/dev.yaml
./deploy.sh uat    # uses env/uat.yaml
./deploy.sh prod   # uses env/prod.yaml
```

Or per-component:

```bash
helm upgrade --install qs-api          ./api          -f env/dev.yaml -n querystudio-dev
helm upgrade --install qs-etl-polling  ./etl-polling  -f env/dev.yaml -n querystudio-dev
```

## ConfigMap design (2026-09-27)

Every backend chart's ConfigMap carries two files, mounted read-only at
`/etc/querystudio`:

* `config.json` — THE backend config file. `core/config.py::_load_file`
  reads it through the container env `QUERYSTUDIO_CONFIG` (set in every
  `templates/deployment.yaml`). It is rendered by the byte-identical helper
  `"qs.configJson"` (`templates/_helpers.tpl`) from **`querystudio:`** in
  `env/<env>.yaml` — the ENVIRONMENT's partial overlay, in `core/config.py`'s
  own `section.key` spelling — deep-merged with the chart's
  **`querystudioRole:`** (`values.yaml`; static role config keys; role wins).
* `runtime.env` — PROCESS env only (POSTGRES_* for the exec block, DUCKDB_*,
  HTTP_PROXY, TLS paths, mode literals like `QUERYSTUDIO_REPORTS_MODE`) and
  facts templated from the pod's own values (ports, DNS names). A config
  KEY lives in one overlay, never here as well.

Until 2026-09-27 the ConfigMap rendered an `application.yaml` that no
backend file read (W11, `docs/PROD_CONFIG_DEPLOYMENT_PLAN_2026_09_27.html`
section 6). Values marked `__SET_PER_ENV__` in `env/<env>.yaml` are the
environment's own data (AD server/groups, auth type) supplied by a gitignored
`env/<env>.site.yaml` that `deploy.sh` applies after the reviewed file
(`env/example.site.yaml` shows the shape); the render fails, naming every
placeholder, until they are supplied — as does the checker
(`scripts/verify_prod_config.py`) and the loader itself.
`scripts/render_charts_proof.py` renders every chart for every environment
and asserts all of this; run it before a deploy.

Credentials still come only from the Secret (`env:` → `secretKeyRef`), and
pod identity from the downwardAPI.
