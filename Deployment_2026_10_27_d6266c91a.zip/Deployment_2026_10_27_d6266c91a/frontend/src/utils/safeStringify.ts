/**
 * BF-426 / BF-427 — Shared safe-serialization utility.
 *
 * Native JSON.stringify throws "Converting circular structure to JSON" when
 * state accidentally captures a DOM/Window/SyntheticEvent reference (e.g., a
 * setter called with `e` instead of `e.target.value`).  In an enterprise
 * product where dozens of forms, modals and persistence layers feed into
 * sessionStorage / localStorage / API request bodies, a single misrouted
 * setter can crash the page AND corrupt the saved state for the next load.
 *
 * `safeStringify` is a drop-in replacement that:
 *   - replaces window/Node/Event/SyntheticEvent values with readable sentinel
 *     strings (`[Window]`, `[DOM]`, `[Event]`, `[SyntheticEvent]`) so the
 *     serializer never throws AND the bug remains greppable in saved storage
 *   - breaks circular cycles via a WeakSet (`[Circular]`)
 *   - drops function values (matches native JSON.stringify behavior)
 *
 * Use this everywhere a payload might come from loosely-typed state:
 *   - storage writes (localStorage / sessionStorage / IndexedDB)
 *   - error message formatting (`setError(safeStringify(err))`)
 *   - autosave / draft systems
 *   - request body serialization at the API layer
 *
 * Centralized at `src/utils/safeStringify.ts` so a single hardening pass
 * protects the whole product.  Re-exported from `business-query/utils` for
 * back-compat with BF-426 callers.
 */
export const safeStringify = (v: unknown, space?: number): string => {
  // 2026-10-23 -- ONLY a true cycle is "[Circular]": an object that contains
  // ITSELF somewhere up its own chain.  The WeakSet this used marked ANY object
  // seen a second time, so a value merely SHARED by two fields was written as
  // the string "[Circular]" -- the query builder's cross-source run sent the
  // same `filters` array on both sides and the server refused
  // "secondary_query_config.filters: Input should be a valid list,
  // input_value='[Circular]'" (found by clicks on the Docker rig).  The
  // ancestor chain is the replacer's `this` stack (MDN's cycle pattern).
  const ancestors: object[] = [];
  return JSON.stringify(v, function (this: unknown, _key, val) {
    if (val === null || val === undefined) return val;
    const t = typeof val;
    if (t === 'function') return undefined;        // drop functions
    if (t !== 'object') return val;                 // primitives pass through
    // Browser-only checks — guarded so this runs in Node / jsdom too.
    if (typeof window !== 'undefined' && val === window) return '[Window]';
    if (typeof Node !== 'undefined' && val instanceof Node) return '[DOM]';
    if (typeof Event !== 'undefined' && val instanceof Event) return '[Event]';
    // React SyntheticEvent — has nativeEvent + preventDefault
    const obj = val as Record<string, unknown>;
    if (obj.nativeEvent && typeof obj.preventDefault === 'function') {
      return '[SyntheticEvent]';
    }
    // `this` is the object holding `_key`: unwind the chain to it.
    while (ancestors.length > 0 && ancestors[ancestors.length - 1] !== this) ancestors.pop();
    if (ancestors.includes(val as object)) return '[Circular]';
    ancestors.push(val as object);
    return val;
  }, space);
};
