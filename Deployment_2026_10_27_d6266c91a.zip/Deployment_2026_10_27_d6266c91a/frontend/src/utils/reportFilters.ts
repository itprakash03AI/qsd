/**
 * Is a filter row filled in?  -- the client mirror of
 * backend/core/federation_engine.py::is_unfilled_filter (2026-10-03).
 *
 * The owner's report saved an untouched "Add Filter" row as
 * {operator: 'eq', value: ''} and the run said `REGION = ''`: 0 rows behind a
 * 200 while the dataset returned 4.  An unfilled row is not a filter.  The
 * server refuses to save one (422 naming the column) and refuses to run one;
 * the builder must not SUBMIT one, and says which row is unfinished.
 */

export interface FilterRow {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
  /** 2026-10-25 (the owner: "why will I add a value while creating reports ...
   *  it should run with any values") -- the person RUNNING the report picks
   *  the value; saved as a report parameter on this column, never a filter */
  ask_at_run?: boolean;
}

/** The operators a run-time question can stand for: one value, a list, a range. */
export const ASKABLE_OPERATORS = ['eq', 'in', 'between'];

/** The parameter an "ask when the report runs" row becomes. */
export function askedParameter(f: FilterRow,
                               col: { id: number; friendly_name?: string; physical_name?: string; data_type?: string } | undefined):
    { name: string; label: string; parameter_type: string; lov_column_id: number } {
  const phys = String(col?.physical_name || `column_${f.column_id}`);
  const isDate = String(col?.data_type || '').toLowerCase() === 'date';
  const op = f.operator || 'eq';
  const parameter_type = op === 'in' ? 'multi_select'
    : op === 'between' ? (isDate ? 'date_range' : 'text')
    : isDate ? 'date' : 'dropdown';
  return { name: phys.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '') || `p${f.column_id}`,
           label: col?.friendly_name || phys, parameter_type, lov_column_id: f.column_id };
}

export const NO_VALUE_OPERATORS = ['is_null', 'is_not_null'];
export const LIST_OPERATORS = ['in', 'not_in'];
/** Text-pattern operators: the operand is a pattern the author types. */
export const PATTERN_OPERATORS = ['like', 'not_like', 'starts_with', 'ends_with',
                                  'contains', 'not_contains'];

const blank = (v: any) => v === null || v === undefined || v === '';

/** Same rule as the server's `_coerce_in_list`: a comma string is a list. */
export function inListItems(value: any): any[] {
  if (blank(value)) return [];
  if (Array.isArray(value)) return value.filter(v => !blank(v));
  if (typeof value === 'string') {
    return value.split(',').map(s => s.trim()).filter(s => s !== '');
  }
  return [value];
}

export function isUnfilledFilter(f: FilterRow): boolean {
  if (f.ask_at_run) return false;          // its value is asked when the report runs
  const op = f.operator || 'eq';
  if (NO_VALUE_OPERATORS.includes(op)) return false;
  if (LIST_OPERATORS.includes(op)) return inListItems(f.value).length === 0;
  if (op === 'between') {
    let lo = f.value; let hi = f.value2;
    if (blank(hi) && Array.isArray(lo) && lo.length === 2) [lo, hi] = lo;
    return blank(lo) || blank(hi);
  }
  return blank(f.value) || Array.isArray(f.value);
}

/** One sentence per unfinished row, naming its column. */
export function unfilledFilterProblems(
  filters: FilterRow[],
  columns: Array<{ id: number; friendly_name?: string; physical_name?: string }>,
): string[] {
  return filters.flatMap((f, i) => {
    if (!isUnfilledFilter(f)) return [];
    const c = columns.find(x => x.id === f.column_id);
    const name = c ? (c.friendly_name || c.physical_name) : `column ${f.column_id}`;
    return [`Filter ${i + 1} (${name}) has no value -- pick one or remove the row.`];
  });
}

/** The wire form: an IN list travels as a list. */
export function filterForSave(f: FilterRow): FilterRow {
  if (LIST_OPERATORS.includes(f.operator)) return { ...f, value: inListItems(f.value) };
  return f;
}
