/**
 * Reports UX (2026-08-09) — pure message/state helpers for the Business
 * Report viewer.  Kept out of the component so every user-visible state
 * (instance provenance, staleness, truncation, empty results, error
 * guidance) is unit-testable without mounting the viewer.
 *
 * Wording principles (industry research doc §5):
 *  - stored data is ALWAYS labelled as stored ("Data as of …"), never
 *    passed off as live;
 *  - unknown freshness is DISCLOSED as unknown, never rendered as fresh;
 *  - staleness is a CAP: the data still shows, with a refresh path;
 *  - truncation says the true thing plainly, including when WHICH rows
 *    were kept is not stable;
 *  - every error names a next step the user can actually take.
 */

// ── Instance provenance ──────────────────────────────────────────────────────

export interface InstanceInfo {
  /** ISO timestamp the served instance was produced at. */
  asOf: string | null;
  /** "verified" = source snapshot version was derivable at build time;
   *  "unknown" = it was not (most non-iceberg sources).  Never coerced. */
  freshness: 'verified' | 'unknown' | null;
  /** Past its freshness window — still served (CAP), with disclosure. */
  stale: boolean;
  /** Backend queued a background live re-run for a stale instance. */
  refreshQueued: boolean;
  /** Produced by a scheduled run (the BO 6am-instance model). */
  isScheduled: boolean;
  createdBy?: string | null;
  /** The served instance's own id (2026-09-28) — what the sign-off header
   *  names; a live run has none here and is found by its execution id. */
  instanceId?: number | null;
}

/** Extract instance metadata from an execute / execute-async response.
 *  Returns null when the response was NOT served from an instance. */
export function parseInstanceInfo(resp: any): InstanceInfo | null {
  if (!resp || resp.served_from_instance !== true) return null;
  const inst = resp.instance || {};
  const freshness = resp.freshness === 'verified' ? 'verified'
    : resp.freshness === 'unknown' ? 'unknown' : null;
  return {
    asOf: resp.as_of ?? inst.created_at ?? null,
    freshness,
    stale: resp.stale === true,
    refreshQueued: resp.refresh_queued === true,
    isScheduled: Boolean(inst.is_scheduled),
    createdBy: inst.created_by ?? null,
    instanceId: typeof inst.id === 'number' ? inst.id : null,
  };
}

/** Provisional instance info from a PROBE response (the raw ReportInstance
 *  row from GET /instances/latest) — enough to render "Data as of <time>"
 *  BEFORE the auto-open execute completes.  The execute's authoritative
 *  serve metadata replaces it (including clearing it if the serve missed).
 *  Returns null when the row is unusable — the auto-open still proceeds,
 *  there is just no provisional banner. */
export function parseInstanceProbe(row: any): InstanceInfo | null {
  if (!row || typeof row !== 'object' || !row.created_at) return null;
  return {
    asOf: row.created_at,
    // Same rule as the serve path: verified only with a source version.
    freshness: row.source_version ? 'verified' : 'unknown',
    stale: row.status === 'stale',
    refreshQueued: false,
    isScheduled: Boolean(row.is_scheduled),
    createdBy: row.created_by ?? null,
    instanceId: typeof row.id === 'number' ? row.id : null,
  };
}

/** Human-readable "as of" time.  Falls back honestly when unparseable. */
export function formatAsOf(iso: string | null | undefined): string {
  if (!iso) return 'an unknown time';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return 'an unknown time';
  return d.toLocaleString();
}

/** The sentence body of the "Data as of" banner (after the bolded time). */
export function instanceBannerText(info: InstanceInfo): string {
  let s = info.isScheduled
    ? ' — saved result from a scheduled run, not a live query.'
    : ' — saved result from an earlier run, not a live query.';
  if (info.freshness === 'unknown') {
    s += ' Whether the source has changed since then cannot be verified.';
  }
  if (info.stale) {
    s += ' This result is past its freshness window.';
  }
  if (info.refreshQueued) {
    s += ' A background refresh has been queued — or press Refresh to run live now.';
  }
  return s;
}

// ── Truncation ───────────────────────────────────────────────────────────────

export function truncationMessage(opts: {
  rowLimit: number | null;
  unstable: boolean | null;
  hasDrill: boolean;
}): string {
  const { rowLimit, unstable, hasDrill } = opts;
  // 2026-10-25 (the owner: "why can't we show it paginated?"): say WHAT is
  // set and WHERE to change it -- with "All rows" the report pages through
  // every row
  let s = rowLimit
    ? `This report is set to show at most ${rowLimit.toLocaleString()} rows, and the data has more.`
    : "This report's row limit cut the result -- you are not seeing all rows.";
  if (unstable === true) {
    s += ' Because the cut ran without a sort order, WHICH rows were kept is not stable — the same report can return a different set next run. Add a sort order in the builder to make the cut repeatable.';
  }
  if (hasDrill) {
    s += ' Drill results, totals and subtotals at every level are computed from this incomplete cut.';
  }
  s += ' To page through every row, edit the report and set Rows to "All rows" -- or narrow it with parameters or filters.';
  return s;
}

/** Short chip label for a truncated result. */
export function truncationChipLabel(rowLimit: number | null): string {
  return rowLimit
    ? `Showing ${rowLimit.toLocaleString()} rows — result cut`
    : 'Result cut at the row limit';
}

// ── Empty results ────────────────────────────────────────────────────────────

export interface EmptyResultInfo {
  message: string;
  /** Offer a one-click "Clear slicers" action. */
  showClearSlicers: boolean;
  /** Offer a one-click "Back to top level" action. */
  showDrillUp: boolean;
}

export function emptyResultInfo(opts: {
  hasActiveSlicers: boolean;
  hasDrillFilters: boolean;
  /** Rows that existed BEFORE client-side slicer filtering (0 = unknown). */
  totalRowsBeforeFilters: number;
}): EmptyResultInfo {
  const { hasActiveSlicers, hasDrillFilters, totalRowsBeforeFilters } = opts;
  if (hasActiveSlicers) {
    return {
      message: totalRowsBeforeFilters > 0
        ? `Your slicer selections hide all ${totalRowsBeforeFilters.toLocaleString()} rows of this result. Clear the slicers to see the data.`
        : 'No rows match your current slicer selections. Clear the slicers to see the data.',
      showClearSlicers: true,
      showDrillUp: false,
    };
  }
  if (hasDrillFilters) {
    return {
      message: 'No rows at this drill level — the value you drilled into has no data here. Go back up a level to keep exploring.',
      showClearSlicers: false,
      showDrillUp: true,
    };
  }
  return {
    message: 'The report ran successfully but returned no rows. Adjust the parameters above or broaden the report’s filters, then run it again.',
    showClearSlicers: false,
    showDrillUp: false,
  };
}

// ── Error guidance ───────────────────────────────────────────────────────────

/** Map a raw execution error to a sentence naming a next step.  Only the
 *  well-known cases are rewritten — unknown errors pass through verbatim
 *  (never mask a real message). */
export function describeExecutionError(err: any): string {
  const raw = typeof err === 'string'
    ? err
    : String(
        (err && typeof err.detail === 'string' && err.detail) ||
        (err && err.message) || '');
  const lower = raw.toLowerCase();
  const status = err && typeof err === 'object' ? (err as any).status : undefined;

  if (status === 403 || lower.includes('access denied')) {
    return 'You do not have permission to run this report. Ask the report owner to publish it to you or your group, then try again.';
  }
  if (lower.includes('not found or expired')
      || lower.includes('no longer available')) {
    return 'That execution has expired on the server, so its results cannot be shown any more. Run the report again to get fresh data.';
  }
  if (status === 404 || lower.includes('not found')) {
    return 'The report or its execution could not be found. It may have been deleted — go back to the reports list and reopen it.';
  }
  if (!raw) {
    return 'The report failed to run. Try again, and contact an administrator if it keeps failing.';
  }
  return raw;
}

/**
 * A report's row limit in a person's words (2026-10-24, the owner: "why
 * does a report have row limits?").  ``null`` = no limit of its own (the
 * server's ceiling applies); ``0`` = every row; N = at most N.  ``ceiling``
 * is the deployment's ``default_row_limit`` when known.
 */
export function rowLimitWords(rowLimit: number | null | undefined, ceiling?: number | null): string {
  if (rowLimit === null || rowLimit === undefined) {
    return ceiling ? `All rows (this server shows at most ${ceiling.toLocaleString()}; CSV export gives every row)`
                   : 'All rows (CSV export gives every row)';
  }
  if (rowLimit === 0) return 'Every row, no limit';
  return `At most ${rowLimit.toLocaleString()} rows`;
}
