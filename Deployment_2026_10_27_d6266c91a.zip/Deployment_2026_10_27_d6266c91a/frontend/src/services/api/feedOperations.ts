/**
 * API — Feed operator controls (2026-09-03).
 *
 * Shapes read from the backend IMPLEMENTATIONS, not guessed:
 *   backend/api/feed_ops_api.py     — backfill, delivery ops, child
 *                                     file-runs, connection budgets,
 *                                     deployment windows, service review
 *   backend/api/feed_api.py         — clone, retire/unretire, lifecycle,
 *                                     pii-declaration, legal-hold,
 *                                     acceptance sign-off
 *   backend/core/feed/sod_generator.py — the backfill plan/launch shape
 *   backend/core/feed/service_review.py — the review sections
 *
 * Contract notes the UI must honour (each has a consumer test):
 *   * Backfill delivery is OFF by default; deliver=true REQUIRES a
 *     non-blank reason (422 otherwise) — FR-OPS-08.
 *   * Delivery-hop retry on a NON-idempotent target REQUIRES a
 *     non-blank reason and there is NO force flag anywhere (409
 *     refusals are final until a human marks the attempt lost).
 *   * Child-run reset returns PER-ITEM outcomes
 *     (reset | refused_not_terminal | lost_race), never one verdict.
 *   * max_concurrent_runs=0 on a connection budget means PAUSED
 *     (zero slots), NEVER unlimited; "no budget row" = unbounded.
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

// ── Backfill (POST /api/feeds/{id}/backfill[/preview]) ──────────────────

export type BackfillVerdict =
  | 'will_run' | 'non_business_day' | 'condition_skip'
  | 'outside_validity_window' | 'already_active' | 'error';

export interface BackfillPlanItem {
  business_date: string;
  verdict: BackfillVerdict;
  reason: string | null;
  prior_runs: number;
  active_run_id: number | null;
  /** Launch only — 'created' | 'error' | (a skip verdict echoed). */
  outcome?: string;
  run_id?: number | null;
}

export interface BackfillPlan {
  feed_id: number;
  feed_name: string | null;
  calendar_name: string | null;
  start_date: string;
  end_date: string;
  order: 'oldest_first' | 'newest_first' | string;
  items: BackfillPlanItem[];
  summary: {
    total_dates: number;
    will_run: number;
    skipped: number;
    /** Launch only. */
    created?: number;
    errors?: number;
  };
  deliver: boolean;
  suppress_delivery: boolean;
  /** Launch only. */
  batch_id?: string;
  priority?: number;
  requested_by?: string | null;
}

export interface BackfillRequestBody {
  start_date: string;
  end_date: string;
  order?: 'oldest_first' | 'newest_first';
  /** OFF by default — enabling requires a typed reason (FR-OPS-08). */
  deliver?: boolean;
  reason?: string;
}

// ── Delivery attempts (api/feed_ops_api.py §delivery ops) ───────────────

export type DeliveryAttemptStatus =
  | 'running' | 'succeeded' | 'failed' | 'refused' | 'suppressed'
  | 'skipped';

export interface DeliveryAttemptRow {
  id: number;
  feed_config_id: number;
  business_date: string;
  build_id: string | null;
  manifest_version: string;
  target: string;
  target_type: string;
  attempt: number;
  status: DeliveryAttemptStatus | string;
  /** false = a duplicate send is a second regulatory submission. */
  idempotent: boolean;
  destination_uri: string | null;
  bytes_sent: number | null;
  files_sent: number | null;
  checksum: string | null;
  verification: string | null;
  verification_detail: string | null;
  error_message: string | null;
  acknowledgment: 'expected' | 'received' | 'rejected' | 'not_required' | string;
  acknowledged_at: string | null;
  acknowledgment_detail: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string | null;
}

export interface DeliveryAttemptsResponse {
  feed_id: number;
  business_date: string | null;
  attempts: DeliveryAttemptRow[];
  count: number;
}

export interface DeliveryRetryResponse {
  attempt_id: number | null;
  retried_from_attempt_id: number;
  label: string;
  target_type: string;
  idempotent: boolean;
  status: string;
  attempt: number;
  manifest_version: string;
  uri: string | null;
  error: string | null;
  checksum: string | null;
  acknowledgment: string | null;
  retried_by: string;
  reason: string | null;
}

// ── Child file-runs (GET/POST /api/feed-runs/{id}/files[/reset]) ────────

export interface FeedFileRunRow {
  id: number;
  feed_run_id: number;
  partition_key: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled' | string;
  attempt_count: number;
  claimed_by: string | null;
  started_at: string | null;
  completed_at: string | null;
  part_path: string | null;
  row_count: number | null;
  error: string | null;
}

export interface FeedRunFilesResponse {
  run_id: number;
  parent_status: string | null;
  children: FeedFileRunRow[];
  count: number;
  status_counts: Record<string, number>;
}

export interface FileResetOutcome {
  partition_key: string;
  outcome: 'reset' | 'refused_not_terminal' | 'lost_race';
  previous_status?: string;
  status?: string;
  detail?: string;
}

export interface FeedRunFilesResetResponse {
  run_id: number;
  outcomes: FileResetOutcome[];
  reset_count: number;
  refused_count: number;
  requested_by: string;
  reason: string | null;
  parent_status: string | null;
  next: string;
}

// ── Deployment windows (FR-OPS-04) ──────────────────────────────────────

export interface DeploymentWindowRow {
  id: string;
  scope: 'global' | 'group' | 'feed' | string;
  scope_id: number | null;
  starts_at: string;
  ends_at: string;
  reason: string;
  created_by: string | null;
  /** surface rows only. */
  status?: 'active' | 'upcoming' | 'malformed';
  recent_refusals?: any[];
}

export interface DeploymentWindowsResponse {
  windows: DeploymentWindowRow[];
  active_or_upcoming: DeploymentWindowRow[];
}

// ── Service review (GET /api/service-review) ────────────────────────────

export interface ServiceReviewSection {
  name: string;
  count: number;
  rows: any[];
  /** NOT the same as empty: the section could not be read. */
  unavailable: string | null;
}

export interface ServiceReviewResponse {
  /** 2026-10-26: which section belongs to which area of QueryStudio
   *  (feeds, reports, published_apis, platform); absent on an older server. */
  areas?: Record<string, string[]>;
  period_days: number;
  since: string;
  generated_at: string;
  sections: {
    success_rate_by_group?: ServiceReviewSection;
    trending_slower?: ServiceReviewSection;
    dependency_late_most_often?: ServiceReviewSection;
    /** NOTE: the backend names this section 'skips', not 'skip_counts'. */
    skips?: ServiceReviewSection;
    [name: string]: ServiceReviewSection | undefined;
  };
  unavailable_sections: string[];
}

// ── Lifecycle (feed_api.py) ─────────────────────────────────────────────

export interface FeedLifecycleState {
  retirement?: {
    reason?: string; requested_by?: string; requested_at?: string;
    quarantine_until?: string; quarantine_remaining_days?: number | null;
  } | null;
  acceptance?: {
    required?: boolean; accepted_by?: string; accepted_at?: string;
    contract_confirmed?: boolean; notes?: string | null;
    ticket?: string | null;
  } | null;
  pii?: {
    contains_pii?: boolean; categories?: string[] | null;
    notes?: string | null; declared_by?: string; declared_at?: string;
  } | null;
  legal_hold?: {
    active?: boolean; reason?: string; reference?: string | null;
    placed_by?: string; placed_at?: string;
    released_by?: string; released_at?: string;
  } | null;
  [k: string]: any;
}

// ── Connection concurrency budgets (FR-OPS-11) ──────────────────────────

export interface ConnectionBudgetResponse {
  connection_id: number;
  connection_name?: string;
  budget: {
    max_concurrent_runs: number;
    reserved_critical_slots: number;
    updated_by?: string | null;
    updated_at?: string | null;
  } | null;
  unbounded: boolean;
  /** max_concurrent_runs=0 — PAUSED (zero slots), NEVER unlimited. */
  paused: boolean;
  semantics?: string;
}

import type { DependencyClocks } from './feedDependencies';
import type { ReportSloRow } from './reportReadiness';

// ── The run surface (api/run_surface_api.py, BRD §13.1) ─────────────────
//
// 2026-09-27: read by the Support Desk page.  Sections are independent;
// ``unavailable`` on a section means "could not be read", which is the
// OPPOSITE finding from an empty ``rows`` -- the page renders them apart.
export interface RunSurfaceSection<T = Record<string, any>> {
  name: string;
  count: number;
  rows: T[];
  unavailable: string | null;
}

export interface RunSurfaceRunningRow {
  run_kind: string | null;
  run_id: number | null;
  pod_id: string | null;
  feed_config_id: number | null;
  claimed_at: string | null;
  heartbeat_at: string | null;
  connection_ids: (number | null)[];
}

export interface RunSurfaceBlockedRow {
  feed_run_id: number;
  feed_config_id: number;
  business_date: string;
  blocking: { dependency: string; verdict: string; reason: string | null }[];
}

export interface RunSurfaceFailureRow {
  feed_run_id: number;
  feed_config_id: number;
  error: string | null;
  failed_stage: string | null;
  execution_id: string | null;
  completeness: Record<string, any> | null;
}

export interface RunSurfaceResponse {
  business_date: string;
  generated_at: string;
  sections: {
    /** 2026-09-28 -- what is late by its OWN history, worst first; the
     *  server puts it first and the desk shows it first. */
    late_by_history?: RunSurfaceSection<DependencyClocks>;
    running_now?: RunSurfaceSection<RunSurfaceRunningRow>;
    blocked?: RunSurfaceSection<RunSurfaceBlockedRow>;
    failures?: RunSurfaceSection<RunSurfaceFailureRow>;
    /** 2026-09-28 -- every report PROMISE for the date the reader may see,
     *  worst first (breached with its cause, at risk, could not evaluate,
     *  served late, ready, met); scoped by the report view rule. */
    report_slos?: RunSurfaceSection<ReportSloRow>;
    deployment_windows?: RunSurfaceSection;
    delivery?: RunSurfaceSection;
    decisions?: RunSurfaceSection;
    children?: RunSurfaceSection;
  };
  unavailable_sections: string[];
}

const feedOperations = {
  /** The operator run surface, scoped to the feeds the caller may view. */
  getRunSurface: (params?: {
    business_date?: string; feed_config_id?: number; feed_run_id?: number;
  }): Promise<RunSurfaceResponse> => {
    const qs = new URLSearchParams();
    if (params?.business_date) qs.set('business_date', params.business_date);
    if (params?.feed_config_id != null) qs.set('feed_config_id', String(params.feed_config_id));
    if (params?.feed_run_id != null) qs.set('feed_run_id', String(params.feed_run_id));
    const q = qs.toString();
    return safeFetch(`/api/run-surface${q ? '?' + q : ''}`);
  },

  // ── Backfill ─────────────────────────────────────────────────────────
  previewFeedBackfill: (feedId: number, body: BackfillRequestBody):
      Promise<BackfillPlan> =>
    safeFetch(`/api/feeds/${feedId}/backfill/preview`, {
      method: 'POST', body: safeStringify(body),
    }),

  launchFeedBackfill: (feedId: number, body: BackfillRequestBody):
      Promise<BackfillPlan> =>
    safeFetch(`/api/feeds/${feedId}/backfill`, {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Clone ────────────────────────────────────────────────────────────
  cloneFeed: (feedId: number, body: {
    name: string; display_name?: string; feed_group_id?: number | null;
    /** the clone's own file name (a clone delivering to the same place needs one) */
    output_filename_template?: string;
  }) =>
    safeFetch(`/api/feeds/${feedId}/clone`, {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Delivery ops ─────────────────────────────────────────────────────
  listFeedDeliveryAttempts: (feedId: number, params?: {
    business_date?: string; limit?: number;
  }): Promise<DeliveryAttemptsResponse> => {
    const qs = new URLSearchParams();
    if (params?.business_date) qs.set('business_date', params.business_date);
    if (params?.limit != null) qs.set('limit', String(params.limit));
    const q = qs.toString();
    return safeFetch(`/api/feeds/${feedId}/delivery-attempts${q ? '?' + q : ''}`);
  },

  /** Reason is REQUIRED (non-blank) by the backend when the target is
   *  non-idempotent; there is deliberately NO force flag. */
  retryDeliveryAttempt: (attemptId: number, reason?: string):
      Promise<DeliveryRetryResponse> =>
    safeFetch(`/api/delivery-attempts/${attemptId}/retry`, {
      method: 'POST', body: safeStringify({ reason: reason ?? null }),
    }),

  markDeliveryAttemptLost: (attemptId: number, reason: string) =>
    safeFetch(`/api/delivery-attempts/${attemptId}/mark-lost`, {
      method: 'POST', body: safeStringify({ reason }),
    }),

  recordDeliveryAcknowledgment: (attemptId: number, body: {
    state: 'received' | 'rejected'; detail?: string;
  }) =>
    safeFetch(`/api/delivery-attempts/${attemptId}/acknowledgment`, {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Child file-runs ──────────────────────────────────────────────────
  listFeedRunFiles: (runId: number, status?: string):
      Promise<FeedRunFilesResponse> => {
    const q = status ? `?status=${encodeURIComponent(status)}` : '';
    return safeFetch(`/api/feed-runs/${runId}/files${q}`);
  },

  /** partition_keys: null resets EVERY failed child; naming keys can
   *  also re-produce completed/cancelled ones (backend refuses a
   *  blanket reset of finished work). */
  resetFeedRunFiles: (runId: number, body: {
    partition_keys: string[] | null; reason?: string;
  }): Promise<FeedRunFilesResetResponse> =>
    safeFetch(`/api/feed-runs/${runId}/files/reset`, {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Deployment windows ───────────────────────────────────────────────
  listDeploymentWindows: (): Promise<DeploymentWindowsResponse> =>
    safeFetch('/api/deployment-windows'),

  createDeploymentWindow: (body: {
    scope: 'global' | 'group' | 'feed'; scope_id?: number | null;
    starts_at: string; ends_at: string; reason: string;
  }): Promise<DeploymentWindowRow> =>
    safeFetch('/api/admin/deployment-windows', {
      method: 'POST', body: safeStringify(body),
    }),

  deleteDeploymentWindow: (windowId: string) =>
    safeFetch(`/api/admin/deployment-windows/${encodeURIComponent(windowId)}`,
      { method: 'DELETE' }),

  // ── Service review ───────────────────────────────────────────────────
  getServiceReview: (days = 28): Promise<ServiceReviewResponse> =>
    safeFetch(`/api/service-review?days=${days}`),

  // ── Lifecycle ────────────────────────────────────────────────────────
  getFeedLifecycle: (feedId: number):
      Promise<{ feed_id: number; lifecycle: FeedLifecycleState }> =>
    safeFetch(`/api/feeds/${feedId}/lifecycle`),

  retireFeed: (feedId: number, body: {
    reason: string; quarantine_days?: number;
    acknowledge_dependents?: boolean;
  }) =>
    safeFetch(`/api/feeds/${feedId}/retire`, {
      method: 'POST', body: safeStringify(body),
    }),

  unretireFeed: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/unretire`, { method: 'POST' }),

  setFeedPiiDeclaration: (feedId: number, body: {
    contains_pii: boolean; categories?: string[]; notes?: string;
  }) =>
    safeFetch(`/api/feeds/${feedId}/pii-declaration`, {
      method: 'PUT', body: safeStringify(body),
    }),

  setFeedLegalHold: (feedId: number, body: {
    active: boolean; reason?: string; reference?: string;
  }) =>
    safeFetch(`/api/feeds/${feedId}/legal-hold`, {
      method: 'PUT', body: safeStringify(body),
    }),

  signOffFeedAcceptance: (feedId: number, body: {
    contract_confirmed: boolean; notes?: string; ticket?: string;
  }) =>
    safeFetch(`/api/feeds/${feedId}/acceptance/sign-off`, {
      method: 'POST', body: safeStringify(body),
    }),

  // ── Connection concurrency budgets ───────────────────────────────────
  getConnectionConcurrencyBudget: (connectionId: number):
      Promise<ConnectionBudgetResponse> =>
    safeFetch(`/api/connections/${connectionId}/concurrency-budget`),

  setConnectionConcurrencyBudget: (connectionId: number, body: {
    max_concurrent_runs: number; reserved_critical_slots?: number;
  }) =>
    safeFetch(`/api/connections/${connectionId}/concurrency-budget`, {
      method: 'PUT', body: safeStringify(body),
    }),
};

export default feedOperations;
