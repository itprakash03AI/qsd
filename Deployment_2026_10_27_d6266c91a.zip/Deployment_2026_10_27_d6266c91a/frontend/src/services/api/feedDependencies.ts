/**
 * API — Feed dependency gate operations (2026-09-02).
 *
 * Four endpoints, shapes FIXED by the backend contract (being built in
 * parallel — do not adapt these shapes client-side; if the server sends
 * something else, that is a backend bug to report, not to absorb):
 *
 *   POST /api/feed-runs/{run_id}/skip-dependencies
 *   POST /api/feed-dependencies/{dependency_key}/skip
 *   GET  /api/feed-dependencies/blocking?business_date=YYYY-MM-DD
 *   GET  /api/feed-runs/{run_id}/steps
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

// ── Response shapes (contract-fixed) ────────────────────────────────────

/** Gate verdict returned after a per-run skip. */
export interface FeedRunGateNow {
  admitted: boolean;
  blocking: string[];
  asserted: boolean;
}

export interface SkipRunDependenciesResponse {
  run_id: number;
  skipped: string[];
  reason: string;
  reason_category?: string;
  asserted_by: string;
  asserted_at: string;
  gate_now: FeedRunGateNow;
}

// ── The skip REASON vocabulary (2026-09-27) ─────────────────────────────
// A skip (and a Run Now override) needs a CATEGORY from the server's
// vocabulary plus free text of at least `min_chars` / `min_words`.  The
// UI offers exactly what GET /api/feed-dependencies/skip-reasons returns;
// the same validator refuses on the server (422 naming what is missing).

export interface SkipReasonCategory {
  value: string;
  label: string;
  help: string;
}

export interface SkipReasonVocabulary {
  categories: SkipReasonCategory[];
  min_chars: number;
  min_words: number;
  max_chars: number;
}

/** The body fields every skip route takes for the reason. */
export interface SkipReasonBody {
  reason_category: string;
  reason: string;
}

/** An operator DECISION about a run's dependencies, from the append-only
 *  ledger: a skip, a Run Now override, or the WAIT escalation.  Shown on
 *  the run's timeline and on the dependency panel. */
export interface SkipDecision {
  event_type: 'dependency_skipped' | 'dependencies_overridden' | 'dependency_wait_escalated' | string;
  dependency_key: string | null;
  actor: string | null;
  at: string | null;
  reason: string | null;
  reason_category: string | null;
  feed_run_id: number | null;
  feed_config_id?: number | null;
  feed_name?: string | null;
  business_date?: string | null;
  source?: string | null;
  not_met?: string[] | null;
}

export interface SkipDependencyAffectedRun {
  feed_run_id: number;
  feed_config_id: number;
  feed_name: string;
}

export interface SkipDependencyResponse {
  dependency_key: string;
  business_date: string;
  reason: string;
  reason_category?: string;
  asserted_by: string;
  asserted_at: string;
  affected_runs: SkipDependencyAffectedRun[];
  affected_count: number;
}

export interface BlockedFeedRef {
  feed_config_id: number;
  feed_name: string;
  feed_run_id: number;
  sla_to: string | null;
}

/** One declared source's answer, in the gate's own words (2026-09-27). */
export interface SourceVerdict {
  kind: string;
  /** 'met' | 'not_met' | 'could_not_tell' | 'not_expected' (an open string:
   *  a newer backend may add a word and the panel must still render it). */
  verdict: string;
  reason: string | null;
  /** 2026-10-07 -- what the source saw.  A `file` source carries
   *  `waiting_for` (the RENDERED location, pattern, control file) while
   *  it waits, and `location` / `files` / `control` once met. */
  evidence?: SourceEvidence | null;
}

/** One object a file source listed. */
export interface ListedObject {
  key: string;
  size: number;
  last_modified: string | null;
}

/** The parts of a source's evidence the panel renders (an open shape). */
export interface SourceEvidence {
  waiting_for?: { location: string; pattern: string; control_file: string | null; min_files: number } | null;
  observed_at?: string | null;
  status?: string | null;
  location?: string | null;
  file_count?: number | null;
  files?: ListedObject[];
  control?: ListedObject[];
  last_arrived_at?: string | null;
  /** 2026-10-07 -- the health of the source's PRODUCER (who writes its
   *  evidence).  `down` means the source cannot be satisfied by waiting. */
  producer?: ProducerHealth | null;
  [key: string]: unknown;
}

/** core/feed/arrival_sources.py::producer_health. */
export interface ProducerHealth {
  producer: string | null;
  mechanism: string | null;
  /** 'up' | 'down' | 'unknown' */
  state: string;
  reason: string;
}

export interface BlockingDependency {
  dependency_key: string;
  type_name: string;
  blocked_feeds: BlockedFeedRef[];
  blocked_count: number;
  first_waiting_since: string | null;
  last_arrival_at: string | null;
  /** 2026-09-27 — the gate's verdict and reason for this dependency, and
   *  the per-source answers when it DECLARED its arrival sources.  Older
   *  backends send none of these. */
  verdict?: string | null;
  reason?: string | null;
  sources?: SourceVerdict[];
  /** 2026-09-28 — the three acting-time clocks for this dependency, from
   *  the SAME function the SLA watcher alerts on.  Absent on an older
   *  backend; null when the clocks section could not be read (named in
   *  `unavailable_sections`); a row with `clocks_unavailable` set when THIS
   *  dependency's clocks could not be computed. */
  clocks?: DependencyClocks | null;
}

// ── Acting time (2026-09-28) ─────────────────────────────────────────────
// core/feed/acting_time.py::blocked_row -- one row per blocking dependency,
// served identically by GET /api/run-surface (section `late_by_history`)
// and by GET /api/feed-dependencies/blocking (`clocks`).  Three states the
// renderer must keep apart: `usual_by` set (a minted clock; `minutes_late`
// is 0 or more), `usual_by` null with `observations` a number (no usable
// history yet -- the clock is NOT invented; `minutes_late` is null because
// unknown is not zero), and `profile_unavailable` / `clocks_unavailable`
// set (could not tell).
export interface DependencyClocks {
  dependency: string;
  /** The ladder's own word: overdue | decision_due | deadline_passed | breached; null = no rung is live. */
  stage: string | null;
  severity: number | null;
  /** The sentence the SLA watcher sends to Netcool for this rung. */
  summary: string | null;
  stage_unavailable: string | null;
  /** "HH:MM" UTC, the p95 of a high-confidence arrival profile. */
  usual_by: string | null;
  usual_by_at: string | null;
  observations: number | null;
  confidence: string;
  segmented: boolean | null;
  profile_unavailable: string | null;
  minutes_late: number | null;
  decision_deadline: string | null;
  warn_at: string | null;
  sla_at: string | null;
  sla_feed: string | null;
  /** Set when the tightest-SLA feed is outside the reader's view (its name is withheld). */
  sla_feed_redacted?: boolean;
  expected_runtime_seconds: number | null;
  runtime_source: string;
  blocked_feed_ids: number[];
  blocked_feeds: { feed_config_id: number; feed_run_id: number | null; feed_name: string | null }[];
  blocked_count: number;
  clocks_unavailable: string | null;
}

// ── Arrival sources (2026-09-27) ────────────────────────────────────────
// The DECLARED vocabulary of where a dependency's evidence comes from
// (core/feed/arrival_sources.py).  A dependency may name several and say
// whether ALL (default) or ANY must be met.

export interface ArrivalSourceKind {
  kind: string;
  label: string;
  description: string;
  ledger_source: string | null;
  /** `required` is absent on an older backend (every param required). */
  params: { name: string; type: string; required?: boolean }[];
  /** 2026-10-07 -- who writes this kind's evidence, and whether it can now. */
  producer?: { name: string; mechanism: string; daemons: string[] } | null;
  producer_health?: ProducerHealth | null;
  /** oracle_table: the (connection, table) pairs the watcher reads -- the
   *  only ones a source can name and ever be met (2026-10-12) */
  watched?: { connection_id: number; connection_name: string; table: string }[];
}

export interface ArrivalSourcesVocabulary {
  kinds: ArrivalSourceKind[];
  require_modes: string[];
  default_require_mode: string;
}

/** A declaration as stored on the dependency.  `iceberg_commit` carries
 *  the table it watches; `file` (2026-10-07) the connection and the path
 *  template the watcher lists, with an optional name pattern, control
 *  file and minimum count; the other kinds carry only their kind. */
export interface DeclaredArrivalSource {
  kind: string;
  connection_id?: number;
  table?: string;
  date_column?: string;
  path?: string;
  pattern?: string;
  control_file?: string;
  min_files?: number;
  /** 2026-10-08 -- a `kafka` source's topic (optional): one dependency can
   *  wait for two messages on two topics (ALL) or either (ANY). */
  topic?: string;
  /** 2026-10-11 -- an `iceberg_commit` source's partition (optional): the
   *  commit must be OF this partition, `{column: value | '{TOKEN}'}` rendered
   *  from the feed's query_params; without it any commit containing the
   *  business date counts.  API / template authored; the form shows it
   *  through describeArrivalSource only. */
  partition_values?: Record<string, string>;
}

export interface BlockingDependenciesResponse {
  business_date: string;
  dependencies: BlockingDependency[];
  /** 2026-09-27 — the decisions taken for this date (skips, Run Now
   *  overrides, escalations), so a dependency skipped an hour ago is
   *  visible on the panel that no longer lists it as blocking.  Absent
   *  on an older backend; `unavailable_sections` names 'decisions' when
   *  the ledger could not be read. */
  skips?: SkipDecision[];
  unavailable_sections: string[];
}

// 'refused' is carried THROUGH from the backend rather than folded into
// 'failed': a correctness verdict a step reached deliberately and a crash
// lead to opposite investigations, and the projection is exactly where
// they would be conflated.
export type FeedRunStepState =
  | 'pending' | 'running' | 'completed' | 'failed' | 'refused'
  | 'skipped' | 'cancelled';

export interface FeedRunStep {
  name: string;
  state: FeedRunStepState;
  started_at: string | null;
  ended_at: string | null;
  seconds: number | null;
  detail: string | null;
  // ── Present only when `source === 'recorded'` (2026-09-05) ─────────
  // The timing projection cannot carry any of these, which is why they
  // are optional rather than nullable: absent and null mean different
  // things here.
  seq?: number;
  /** Steps sharing a level had no declared dependency between them —
   *  they may have run at the same time. */
  level?: number;
  depends_on?: string[];
  attempt?: number;
  max_attempts?: number;
  rows_in?: number | null;
  rows_out?: number | null;
  worker_node?: string | null;
  executor?: 'engine' | 'runner';
  params?: Record<string, unknown>;
  outputs?: Record<string, unknown>;
}

/** What the operator validates a run by, from feed_executions -- and, on
 *  the Spark lane, the workload name and its live cluster state when the
 *  server could check it (never invented: `checked` says whether it did). */
export interface FeedExecutionSummary {
  id: number;
  execution_id: string;
  status: string | null;
  execution_backend: string | null;
  external_job_id: string | null;
  total_rows: number | null;
  file_size_bytes?: number | null;
  destination_path: string | null;
  /** 2026-10-07 -- the produced file, kept whether or not it was
   *  delivered; and the recorded delivery verdict + its reason. */
  artifact_path?: string | null;
  delivery_verdict?: string | null;
  delivery_reason?: string | null;
  /** Why there is no downloadable file, when the run recorded it. */
  artifact_unavailable_reason?: string | null;
  started_at: string | null;
  completed_at: string | null;
  duration_seconds?: number | null;
  trigger_type?: string | null;
  triggered_by?: string | null;
  error_message?: string | null;
  /** 2026-10-26 -- who stopped the run and when; `cancel` = what the stop
   *  REACHED at each source (core/cancel_scope.py): the words are in
   *  `error_message`. */
  cancelled_by?: string | null;
  cancelled_at?: string | null;
  cancel?: { requested_by?: string | null; requested_at?: string | null; all_reached?: boolean | null;
             sources?: { source: string; reached: boolean | null; detail?: string; statement?: string | null }[] } | null;
  backend_choice?: { backend?: string; reason?: string; failed_over?: boolean } | null;
  webhook_verification?: Record<string, any> | null;
  completeness?: string | null;
  /** 2026-10-14 -- WHERE the run is (core/feed/run_progress.py); null = it never reported */
  progress?: import('../../components/feeds/RunProgressBar').RunProgress | null;
  spark?: {
    workload: string;
    /** The shape the run was SUBMITTED as (`spark_application` = a CR
     *  the operator turned into pods; `driver_pod` = a plain Pod
     *  QueryStudio posted).  Stored on the row at submit; with
     *  `submit_mode_declared` = 'auto' it was resolved by probing. */
    submit_mode?: string;
    submit_mode_declared?: string;
    driver_pod: string;
    namespace: string;
    kubectl: string;
    cluster_state: string | null;
    checked: boolean;
    reason: string | null;
  } | null;
}

export interface FeedDriverLogResponse {
  pod: string;
  namespace: string;
  available: boolean;
  reason?: string;
  tail?: number;
  lines: string[];
  kubectl?: string;
}

/** One rendered statement of a run (core/feed/executed_sql.py). */
export interface FeedRunSqlStatement {
  id: number; side: string; field: string; lane: string; sql: string;
  params: Record<string, string | number | boolean | null>; rendered_at: string | null;
}
export interface FeedRunSqlResponse {
  run_id: number;
  /** the latest text per (side, field) -- what the current attempt ran */
  statements: FeedRunSqlStatement[];
  /** every render, oldest first */
  history: FeedRunSqlStatement[];
  /** set = the rows could not be READ (not the same as none) */
  unavailable: string | null;
  note?: string;
  status?: string | null;
  /** 2026-10-25 -- a run that has not sent its SQL yet: what it WILL send,
   *  per side, every value filled in for its date (nothing executed) */
  planned?: { side: string; sql: string | null; template?: string | null;
              params: Record<string, unknown>; error: string | null }[];
}

export interface FeedRunStepsResponse {
  /** The execution the steps belong to (null when the run never reached
   *  the engine). */
  execution?: FeedExecutionSummary | null;
  /** null when the execution ran with NO feed_run (a manual Run Now) —
   *  then there are no recorded rows and nothing can be re-run. */
  run_id: number | null;
  execution_id: number | string | null;
  steps: FeedRunStep[];
  current: string | null;
  terminal: boolean;
  /** Which answer this is.  'recorded' = real per-step rows, with real
   *  boundaries.  'derived' = the timing projection, where `started_at`
   *  is null for every step because durations have no boundaries.
   *  'unavailable' = the rows could not be READ, which is NOT the same
   *  as a run having none.  Older backends send none of these. */
  source?: 'recorded' | 'derived' | 'unavailable';
  /** The step that failed or refused, when one did. */
  failed_step?: string | null;
  error?: string | null;
  /** 2026-09-27 — the operator decisions stamped for this run (skips, a
   *  Run Now override, the WAIT escalation).  `null` = the ledger could
   *  not be read (not "none"); absent on an older backend. */
  decisions?: SkipDecision[] | null;
  /** Why the answer is a projection, when the server knows a reason
   *  more specific than "predates the step model" (e.g. a manual Run
   *  Now that ran with no feed_run row). */
  source_reason?: string | null;
  /** 2026-10-03 — ON COMPLETION OF: what STARTED this run (null unless
   *  its upstream's completion did).  `text` is the server's sentence. */
  trigger?: RunTrigger | null;
  /** What THIS run's completion started in the feeds declared
   *  on_completion_of it, or why nothing.  `[]` = none recorded, `null` =
   *  the ledger could not be read. */
  downstream?: DownstreamRecord[] | null;
}

export interface RunTrigger {
  kind: 'upstream_completion';
  upstream_feed_name: string | null;
  upstream_execution_id: string | null;
  upstream_feed_run_id: number | null;
  text: string;
}

export interface DownstreamOutcome {
  feed_id: number | null;
  feed_name: string | null;
  /** created | already_exists | not_triggered | inactive |
   *  outside_validity_window | beyond_calendar_horizon | error */
  outcome: string;
  run_id?: number | null;
  status?: string | null;
  action_decision?: string | null;
  reason?: string | null;
}

export interface DownstreamRecord {
  event_type: 'downstream_triggered' | 'downstream_not_triggered';
  at: string | null;
  reason: string | null;
  downstream: DownstreamOutcome[];
  queue_consumer?: { present: boolean; detail: string | null } | null;
}

// ── Calls ───────────────────────────────────────────────────────────────

const feedDependencies = {
  /**
   * Let ONE run proceed without some (or all) of its unconfirmed inputs.
   * `dependencies: null` = skip ALL currently-blocking dependencies.
   * The server refuses an empty reason with a 4xx — the UI must also
   * refuse to send one (confirm stays disabled until a reason is typed).
   */
  skipFeedRunDependencies: (
    runId: number,
    data: SkipReasonBody & { dependencies: string[] | null },
  ): Promise<SkipRunDependenciesResponse> =>
    safeFetch(`/api/feed-runs/${runId}/skip-dependencies`, {
      method: 'POST',
      body: safeStringify(data),
    }),

  /**
   * Waive one dependency for EVERY run waiting on it for a business
   * date — "let everything waiting on this proceed".  `etl_ids: null`
   * = all ETL ids under the key.
   */
  skipFeedDependency: (
    dependencyKey: string,
    data: SkipReasonBody & { business_date: string; etl_ids: number[] | null },
  ): Promise<SkipDependencyResponse> =>
    safeFetch(`/api/feed-dependencies/${encodeURIComponent(dependencyKey)}/skip`, {
      method: 'POST',
      body: safeStringify(data),
    }),

  /**
   * Reverse index: which dependencies are holding feeds up right now,
   * and which feeds each one is holding.
   */
  getBlockingFeedDependencies: (
    businessDate: string,
  ): Promise<BlockingDependenciesResponse> =>
    safeFetch(`/api/feed-dependencies/blocking?business_date=${encodeURIComponent(businessDate)}`),

  /** The declared arrival-source vocabulary (2026-09-27) -- what a
   *  dependency may name as where its evidence comes from. */
  getFeedArrivalSources: (): Promise<ArrivalSourcesVocabulary> =>
    safeFetch('/api/feed-arrival-sources'),

  /** The skip-reason vocabulary (2026-09-27) -- the categories a skip or
   *  a Run Now override must name, and the minimum free text. */
  getFeedSkipReasons: (): Promise<SkipReasonVocabulary> =>
    safeFetch('/api/feed-dependencies/skip-reasons'),

  /** Per-run step timeline (name, state, timing, detail). */
  getFeedRunSteps: (runId: number): Promise<FeedRunStepsResponse> =>
    safeFetch(`/api/feed-runs/${runId}/steps`),

  /** The SQL the run produced per side, every parameter resolved, as the
   *  render chokepoint recorded it (2026-10-24). */
  getFeedRunSql: (runId: number): Promise<FeedRunSqlResponse> =>
    safeFetch(`/api/feed-runs/${runId}/sql`),

  /** The same timeline keyed by EXECUTION (the Feeds page lists
   *  executions).  `run_id` in the answer is the feed_run the rows were
   *  recorded under, or null for a manual Run Now (no run, projection). */
  getFeedExecutionSteps: (execDbId: number): Promise<FeedRunStepsResponse> =>
    safeFetch(`/api/feed-executions/${execDbId}/steps`),

  /** The Spark driver pod's log tail for an execution (spark_k8s only).
   *  409 = not a Spark execution; 503 = cluster unreachable from the API;
   *  `available:false` = the pod is no longer on the cluster. */
  getFeedExecutionDriverLog: (execDbId: number, tail = 400): Promise<FeedDriverLogResponse> =>
    safeFetch(`/api/feed-executions/${execDbId}/driver-log?tail=${tail}`),
};

export default feedDependencies;
