/**
 * Excel add-in (2026-09-28) — the API client of the task pane.
 *
 * Every call rides `rawFetch` from services/api/core.ts, so the add-in
 * resolves the SAME base URLs as the SPA (apiUrl, and reportApiUrl for the
 * report routes when a deployment has a reports pod) and carries the SAME
 * `Authorization: Bearer <session>` header (`authState.setAuthHeader`,
 * set by session.ts).  No API key is ever sent.
 *
 * The routes are the ones the viewers use — nothing is added for Excel:
 *   GET  /auth/config, /auth/me
 *   GET  /api/business-reports?limit=..&cursor=..     (the visibility rule is the server's)
 *   GET  /api/business-reports/{id}                   (parameters, version, certification)
 *   POST /api/business-reports/{id}/parameter-values  (cascading lookups)
 *   GET  /api/business-reports/{id}/instances/latest  (404 = "run live", the contract)
 *   POST /api/business-reports/{id}/execute
 *   GET  /api/business-reports/{id}/results/{exec}?page=&page_size=
 *   GET  /api/date-tokens, /api/date-tokens/preview
 *   GET  /api/v1/views, /api/v1/views/{slug}, /api/v1/views/{slug}/data   (Bearer session, since P6 D8)
 *   GET  /api/me/entitlements                         (the person's data entitlement, 2026-10-24)
 */
import { rawFetch } from '../services/api/core';
import type { MyEntitlements } from '../components/common/EntitlementChip';
import type { EntitlementDisclosure } from './entitlement';

export class SessionExpired extends Error {
  readonly status = 401;
  constructor(message = 'Your QueryStudio session has expired. Sign in again.') {
    super(message);
    this.name = 'SessionExpired';
  }
}

export class ApiRefusal extends Error {
  status: number;
  detail: unknown;
  constructor(status: number, message: string, detail?: unknown) {
    super(message);
    this.name = 'ApiRefusal';
    this.status = status;
    this.detail = detail;
  }
}

export type Fetcher = (url: string, init?: RequestInit) => Promise<Response>;

async function parseRefusal(resp: Response): Promise<ApiRefusal> {
  let detail: unknown = null;
  let message = `HTTP ${resp.status}`;
  try {
    const body = await resp.json();
    detail = body?.detail ?? body;
    if (typeof body?.detail === 'string') message = body.detail;
    else if (typeof body?.detail?.message === 'string') message = body.detail.message;
    else if (Array.isArray(body?.detail)) message = body.detail.map((d: any) => d?.msg || JSON.stringify(d)).join('; ');
    else if (typeof body?.message === 'string') message = body.message;
  } catch { /* not JSON */ }
  return new ApiRefusal(resp.status, message, detail);
}

export interface ReportSummary {
  id: number; slug: string; name: string; description?: string;
  is_published?: boolean; is_certified?: boolean; lifecycle_status?: string;
  report_type?: string; data_source_type?: string;
}

export interface ReportParameter {
  id: number; name: string; label: string; parameter_type: string;
  lov_column_id?: number | null; static_values?: string[] | null;
  depends_on_param_id?: number | null; cascade_filter_column_id?: number | null;
  default_value?: string | null; description?: string | null; is_required?: boolean;
  sort_order?: number;
}

export interface ReportDetail extends ReportSummary {
  parameters: ReportParameter[];
  certified_by?: string | null; certified_at?: string | null;
  current_version?: { version_no?: number | null } | null;
  readiness?: any;
}

export interface ViewSummary {
  slug: string; name: string; description?: string; version?: number;
  source_type?: string; max_limit?: number; default_limit?: number;
  param_definitions?: Array<{ name: string; type?: string; required?: boolean; default?: unknown; label?: string }>;
}

export interface ViewDataPage {
  total_rows: number; offset: number; limit: number;
  columns: Array<{ name: string; type?: string }>;
  data: Array<Record<string, unknown>>;
  /** The envelope's meta; `meta.entitlement` is the server's disclosure of
   *  what this answer was filtered by (2026-10-24, src/addin/entitlement.ts). */
  meta?: { entitlement?: EntitlementDisclosure } & Record<string, unknown>;
}

export class QsClient {
  constructor(private readonly fetcher: Fetcher = rawFetch) {}

  private async json<T>(url: string, init?: RequestInit): Promise<T> {
    const resp = await this.fetcher(url, init);
    if (resp.status === 401) throw new SessionExpired();
    if (!resp.ok) throw await parseRefusal(resp);
    const ct = (resp.headers.get('content-type') || '').toLowerCase();
    if (ct && !ct.includes('json')) {
      throw new ApiRefusal(resp.status, `${url} answered ${ct}, not JSON (is apiUrl pointing at the API?)`);
    }
    return resp.json() as Promise<T>;
  }

  private post<T>(url: string, body: unknown): Promise<T> {
    return this.json<T>(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
  }

  // ── identity ────────────────────────────────────────────────────────────
  me(): Promise<{ username: string; display_name?: string; role?: string; groups?: string[]; is_admin?: boolean }> {
    return this.json('/auth/me');
  }

  logout(): Promise<unknown> {
    return this.json('/auth/logout', { method: 'POST' }).catch(() => null);
  }

  /** What the signed-in person holds per data-entitlement dimension (the
   *  web chip's endpoint).  A failure propagates: the pane says "could not
   *  be read", never "not filtered". */
  myEntitlements(): Promise<MyEntitlements> {
    return this.json('/api/me/entitlements');
  }

  // ── reports the person may open ─────────────────────────────────────────
  async listReports(): Promise<ReportSummary[]> {
    const out: ReportSummary[] = [];
    let cursor: string | null = null;
    for (let page = 0; page < 50; page++) {
      const qs = new URLSearchParams({ limit: '200' });
      if (cursor) qs.set('cursor', cursor);
      const env = await this.json<{ items?: ReportSummary[]; next_cursor?: string | null; has_more?: boolean }>(
        `/api/business-reports?${qs}`);
      const items = Array.isArray(env) ? (env as ReportSummary[]) : (env.items || []);
      out.push(...items);
      if (Array.isArray(env) || !env.has_more || !env.next_cursor) break;
      cursor = env.next_cursor;
    }
    return out;
  }

  getReport(id: number): Promise<ReportDetail> {
    return this.json(`/api/business-reports/${id}`);
  }

  parameterValues(reportId: number, parameterId: number, parentValues: Record<string, unknown>): Promise<{ values?: unknown[]; error?: string }> {
    return this.post(`/api/business-reports/${reportId}/parameter-values`, { parameter_id: parameterId, parent_values: parentValues });
  }

  /** 200 = the instance the serve path WOULD answer from (opening is free);
   *  null = the contract's 404 ("run live").  Anything else is an error. */
  async probeLatestInstance(reportId: number, params: Record<string, unknown>): Promise<Record<string, any> | null> {
    const qs = Object.keys(params).length ? `?params=${encodeURIComponent(JSON.stringify(params))}` : '';
    const resp = await this.fetcher(`/api/business-reports/${reportId}/instances/latest${qs}`);
    if (resp.status === 404) return null;
    if (resp.status === 401) throw new SessionExpired();
    if (!resp.ok) throw await parseRefusal(resp);
    return resp.json();
  }

  execute(reportId: number, body: { parameter_values: Record<string, unknown>; force_refresh?: boolean }): Promise<Record<string, any>> {
    return this.post(`/api/business-reports/${reportId}/execute`, body);
  }

  pagedResults(reportId: number, executionId: string, page: number, pageSize: number): Promise<{ rows?: any[]; columns?: string[]; total_rows?: number; total_pages?: number }> {
    const qs = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    return this.json(`/api/business-reports/${reportId}/results/${encodeURIComponent(executionId)}?${qs}`);
  }

  // ── date tokens ─────────────────────────────────────────────────────────
  listDateTokens(): Promise<any> { return this.json('/api/date-tokens'); }

  previewDateToken(value: string): Promise<{ resolved: string | null; refused?: string | null; explanation?: string | null; kind?: string }> {
    return this.json(`/api/date-tokens/preview?value=${encodeURIComponent(value)}`);
  }

  // ── published views (session-authenticated) ─────────────────────────────
  listViews(): Promise<ViewSummary[]> { return this.json('/api/v1/views'); }

  getView(slug: string): Promise<ViewSummary & { columns?: any[] }> {
    return this.json(`/api/v1/views/${encodeURIComponent(slug)}`);
  }

  viewData(slug: string, opts: { limit: number; offset?: number; params?: Record<string, unknown> }): Promise<ViewDataPage> {
    const qs = new URLSearchParams({ limit: String(opts.limit), offset: String(opts.offset ?? 0) });
    for (const [k, v] of Object.entries(opts.params || {})) {
      if (v == null || v === '') continue;
      qs.set(k, Array.isArray(v) ? v.join(',') : String(v));
    }
    return this.json(`/api/v1/views/${encodeURIComponent(slug)}/data?${qs}`);
  }
}
