/**
 * Excel add-in (2026-09-28) — one run, the viewer's way.
 *
 *   1. date tokens: a business-calendar token is resolved by the SERVER
 *      (GET /api/date-tokens/preview) and a refusal stops the run with the
 *      server's reason — the client never guesses a calendar; a plain
 *      @TODAY macro resolves on the client, as the viewers do
 *      (utils/parameterUtils.ts);
 *   2. instances first: GET .../instances/latest with the run's parameters
 *      (404 = "not free, run live" — the contract, not a fault);
 *   3. POST .../execute (the serve path answers from the instance itself
 *      when one matches; `force_refresh` is the viewer's Refresh);
 *   4. the row bound is checked BEFORE any row is fetched when the total
 *      is known, and after every page when it is not — a result past the
 *      bound is REFUSED with guidance, never cut;
 *   5. rows come inline when the envelope materialised them, else through
 *      the paged results route the viewer pages with;
 *   6. the stamp is built from the envelope, the report and the session.
 */
import type { QsClient, ReportDetail, ReportParameter, ViewSummary } from './client';
import { checkRowBound, type RowRefusal } from './bounds';
import { buildReportStamp, buildViewStamp, type SessionUser } from './stamp';
import type { MyEntitlements } from '../components/common/EntitlementChip';
import type { StampLine } from './ports';
import { excelSheetName, tableNameFor } from './tableName';
import { isServerResolvedDateMacro, resolveClientDateMacro } from '../utils/parameterUtils';

export type CellScalar = string | number | boolean | null;

export interface RunOk {
  ok: true;
  kind: 'report' | 'view';
  columns: string[];
  rows: CellScalar[][];
  stamp: StampLine[];
  tableName: string;
  sheetName: string;
  totalRows: number | null;
  envelope: Record<string, any>;
  /** The instance probe's answer (report runs): the instance, or null = "run live". */
  probe: Record<string, any> | null;
  parameters: Record<string, unknown>;
}

export interface RunRefused {
  ok: false;
  refusal: RowRefusal;
  parameters: Record<string, unknown>;
}

export type RunOutcome = RunOk | RunRefused;

export interface RunOptions {
  bound: number;
  user: SessionUser;
  forceRefresh?: boolean;
  pageSize?: number;
  now?: () => string;
  /** The person's data entitlement the pane read (/api/me/entitlements);
   *  a report's stamp names it.  null = could not be read. */
  entitlement?: MyEntitlements | null;
}

/** The stamp's height is fixed per kind, so the bound can be checked before a write. */
export const STAMP_ROWS_REPORT = 15;   // + the Entitlement line (2026-10-24)
export const STAMP_ROWS_VIEW = 9;

export class DateTokenRefused extends Error {
  constructor(public readonly parameter: string, public readonly reason: string) {
    super(`${parameter}: ${reason}`);
    this.name = 'DateTokenRefused';
  }
}

/**
 * Resolve every date parameter's token to the date the server (or, for a
 * plain macro, the client) says it means today.  A refused token refuses
 * the run: running on a guessed date would be a wrong answer under a green
 * status.
 */
export async function resolveDateTokens(
  params: Pick<ReportParameter, 'name' | 'parameter_type'>[],
  values: Record<string, unknown>,
  preview: QsClient['previewDateToken'],
): Promise<Record<string, unknown>> {
  const out: Record<string, unknown> = { ...values };
  const one = async (name: string, v: unknown): Promise<unknown> => {
    if (typeof v !== 'string' || !v.trim().startsWith('@')) return v;
    if (isServerResolvedDateMacro(v)) {
      const r = await preview(v.trim());
      if (r.refused) throw new DateTokenRefused(name, r.refused);
      if (!r.resolved) throw new DateTokenRefused(name, `the server could not resolve ${v}`);
      return r.resolved;
    }
    return resolveClientDateMacro(v.trim());
  };
  for (const p of params) {
    if (p.parameter_type !== 'date' && p.parameter_type !== 'date_range') continue;
    const v = out[p.name];
    if (v == null || v === '') continue;
    if (p.parameter_type === 'date_range' && v && typeof v === 'object' && !Array.isArray(v)) {
      const rng = v as { from?: unknown; to?: unknown };
      out[p.name] = { from: await one(p.name, rng.from), to: await one(p.name, rng.to) };
    } else {
      out[p.name] = await one(p.name, v);
    }
  }
  return out;
}

export function normaliseColumns(cols: unknown, firstRecord?: Record<string, unknown>): string[] {
  if (Array.isArray(cols) && cols.length) {
    return cols.map((c: any) => (typeof c === 'string' ? c : String(c?.name ?? c?.column_name ?? c?.label ?? ''))).filter(Boolean);
  }
  return firstRecord ? Object.keys(firstRecord) : [];
}

export function toCell(v: unknown): CellScalar {
  if (v == null) return null;
  if (typeof v === 'number' || typeof v === 'boolean' || typeof v === 'string') return v;
  if (v instanceof Date) return v.toISOString();
  try { return JSON.stringify(v); } catch { return String(v); }
}

export function recordsToRows(records: unknown[], columns: string[]): CellScalar[][] {
  return records.map((r: any) => {
    if (Array.isArray(r)) return columns.map((_, i) => toCell(r[i]));
    return columns.map(c => toCell(r?.[c]));
  });
}

export async function runReport(
  client: QsClient, report: ReportDetail, values: Record<string, unknown>, opts: RunOptions,
): Promise<RunOutcome> {
  const now = opts.now ?? (() => new Date().toISOString());
  const parameters = await resolveDateTokens(report.parameters || [], values, client.previewDateToken.bind(client));
  const ctx = { stampRows: STAMP_ROWS_REPORT, kind: 'report' as const, name: report.name, slug: report.slug || String(report.id) };

  const probe = await client.probeLatestInstance(report.id, parameters);
  const envelope = await client.execute(report.id, {
    parameter_values: parameters, force_refresh: !!opts.forceRefresh,
  });

  const total: number | null = envelope.total_rows == null ? null : Number(envelope.total_rows);
  if (total != null) {
    const refusal = checkRowBound(total, opts.bound, ctx);
    if (refusal) return { ok: false, refusal, parameters };
  }

  const inline: unknown[] | null = Array.isArray(envelope.data) ? envelope.data
    : (Array.isArray(envelope.rows) ? envelope.rows : null);
  let records: unknown[];
  let columns = normaliseColumns(envelope.columns, inline?.[0] as any);
  if (inline && (total == null || inline.length >= total)) {
    records = inline;
  } else {
    if (!envelope.execution_id) throw new Error('The run returned neither rows nor an execution id to page.');
    const pageSize = opts.pageSize ?? 5000;
    records = [];
    for (let page = 1; page <= 100_000; page++) {
      const p = await client.pagedResults(report.id, String(envelope.execution_id), page, pageSize);
      const rows = Array.isArray(p.rows) ? p.rows : [];
      if (!columns.length) columns = normaliseColumns(p.columns, rows[0] as any);
      records.push(...rows);
      // The bound is a correctness gate: a total the envelope did not know
      // is learned here, and the refusal happens BEFORE a shorter table
      // could be written.
      const refusal = checkRowBound(records.length, opts.bound, ctx);
      if (refusal) return { ok: false, refusal: { ...refusal, rows: total ?? Number(p.total_rows ?? records.length) }, parameters };
      const known = total ?? (p.total_rows == null ? null : Number(p.total_rows));
      if (known != null && records.length >= known) break;
      if (rows.length < pageSize) break;
    }
  }
  const refusal = checkRowBound(records.length, opts.bound, ctx);
  if (refusal) return { ok: false, refusal, parameters };
  if (!columns.length && records.length) columns = normaliseColumns(null, records[0] as any);

  const rows = recordsToRows(records, columns);
  const retrievedAt = now();
  const stamp = buildReportStamp({
    report, envelope, user: opts.user, parameters, retrievedAt, rowsWritten: rows.length,
    entitlement: opts.entitlement,
  });
  return {
    ok: true, kind: 'report', columns, rows, stamp, envelope, probe, parameters,
    tableName: tableNameFor({ kind: 'report', id: report.id, slug: report.slug }),
    sheetName: excelSheetName(report.name, 'report'),
    totalRows: total ?? rows.length,
  };
}

export async function runView(
  client: QsClient, view: ViewSummary, values: Record<string, unknown>, opts: RunOptions,
): Promise<RunOutcome> {
  const now = opts.now ?? (() => new Date().toISOString());
  const ctx = { stampRows: STAMP_ROWS_VIEW, kind: 'view' as const, name: view.name, slug: view.slug };
  const maxLimit = Number(view.max_limit ?? 0);
  const limit = maxLimit > 0 ? Math.min(maxLimit, opts.bound) : opts.bound;
  const page = await client.viewData(view.slug, { limit, offset: 0, params: values });
  const total = page.total_rows == null ? null : Number(page.total_rows);
  const data = Array.isArray(page.data) ? page.data : [];
  const claimed = total ?? data.length;
  // Past the bound, or past what one page could hold: refuse, never a
  // shorter table under a stamp that says otherwise.
  let refusal = checkRowBound(claimed, opts.bound, ctx);
  if (!refusal && claimed > data.length) {
    refusal = {
      refused: true, reason: 'above_addin_bound', rows: claimed, bound: data.length,
      message: `${view.name} has ${claimed.toLocaleString()} rows and the view serves at most ${data.length.toLocaleString()} per read (its max_limit). Nothing was written.`,
      guidance: `Use the published view's bulk endpoint (/api/v1/views/${view.slug}/bulk) or the Download Centre for the full result.`,
    };
  }
  if (refusal) return { ok: false, refusal, parameters: values };
  const columns = normaliseColumns(page.columns, data[0]);
  const rows = recordsToRows(data, columns);
  const retrievedAt = now();
  const stamp = buildViewStamp({
    view, totalRows: total, user: opts.user, parameters: values, retrievedAt, rowsWritten: rows.length,
    // the server's disclosure for THIS answer -- never the person's list
    entitlement: page.meta?.entitlement,
  });
  return {
    ok: true, kind: 'view', columns, rows, stamp, envelope: page as any, probe: null, parameters: values,
    tableName: tableNameFor({ kind: 'view', slug: view.slug }),
    sheetName: excelSheetName(view.name, 'view'),
    totalRows: total ?? rows.length,
  };
}
