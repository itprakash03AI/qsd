/**
 * Excel add-in (2026-09-28) — the task pane.
 *
 * Sign in (the SPA's session flow, in an Office dialog or inline) → the
 * reports and published views the signed-in person may open (the server's
 * visibility rule; nothing is filtered here) → the chosen report's
 * parameters, each typeable or bound to a cell → Run (instances first,
 * then execute) → a named table on its own sheet with the STAMP above it
 * → Refresh re-reads the bound cells and runs again.
 *
 * Everything that touches Excel goes through `workbook` (WorkbookPort) and
 * `host` (HostPort), so this component renders unchanged in the browser
 * harness over a FakeWorkbook — which is how it is tested.
 */
import React from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, Divider, FormControl, FormControlLabel, InputLabel, MenuItem,
  Select, Stack, Tooltip, Typography,
} from '@mui/material';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import { QsClient, SessionExpired, type ReportDetail, type ReportSummary, type ViewSummary } from './client';
import type { MyEntitlements } from '../components/common/EntitlementChip';
import { chipWords } from './entitlement';
import type { AddinState, HostPort, ParamBinding, StampLine, WorkbookPort } from './ports';
import {
  type AddinSession, type AuthConfig, activateSession, fetchAuthConfig, restoreSession,
} from './session';
import { bindingsForState, resolveParameterValues } from './bindings';
import { configuredRowBound } from './bounds';
import { runReport, runView, type RunOutcome } from './run';
import { tableNameFor } from './tableName';
import { resolveParamDefaults } from '../utils/parameterUtils';
import LoginForm from './LoginForm';
import ParameterPanel from './ParameterPanel';

export interface AddinPaneProps {
  client: QsClient;
  workbook: WorkbookPort;
  host: HostPort;
  /** The same-origin sign-in page the Office dialog opens. */
  loginUrl: string;
  fetchImpl?: typeof fetch;
  /** Override for tests; default = window.APP_CONFIG.addinMaxRows or 50,000. */
  rowBound?: number;
  now?: () => string;
}

type Selection = { kind: 'report'; id: number } | { kind: 'view'; slug: string } | null;

const AddinPane: React.FC<AddinPaneProps> = ({ client, workbook, host, loginUrl, fetchImpl, rowBound, now }) => {
  const [authConfig, setAuthConfig] = React.useState<AuthConfig | null>(null);
  const [session, setSession] = React.useState<AddinSession | null>(null);
  const [booting, setBooting] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [reports, setReports] = React.useState<ReportSummary[]>([]);
  const [views, setViews] = React.useState<ViewSummary[]>([]);
  const [viewsError, setViewsError] = React.useState<string | null>(null);
  const [selection, setSelection] = React.useState<Selection>(null);
  // 2026-10-04: the list was read ONCE at sign-in, so a report published
  // while the pane was open never appeared until a sign-out.  Opening the
  // picker re-reads it.
  const [listTick, setListTick] = React.useState(0);
  const [report, setReport] = React.useState<ReportDetail | null>(null);
  const [view, setView] = React.useState<ViewSummary | null>(null);
  const [bindings, setBindings] = React.useState<Record<string, ParamBinding>>({});
  const [forceLive, setForceLive] = React.useState(false);
  const [running, setRunning] = React.useState(false);
  const [outcome, setOutcome] = React.useState<{ run: RunOutcome; written?: { tableName: string; sheetName: string; address: string; rowsWritten: number } } | null>(null);
  const [remembered, setRemembered] = React.useState<AddinState | null>(null);
  // 2026-10-24: the signed-in person's data entitlement (the web chip's
  // endpoint).  undefined = not read yet; null = could not be read (said so,
  // never shown as "not filtered"); an object = what they hold.
  const [myEnt, setMyEnt] = React.useState<MyEntitlements | null | undefined>(undefined);
  const bound = rowBound ?? configuredRowBound();

  const fail = (e: unknown) => {
    if (e instanceof SessionExpired) {
      activateSession(null);
      setSession(null);
      setError(e.message);
      return;
    }
    setError((e as any)?.message || String(e));
  };

  // Boot: auth config, a session this runtime remembers, the workbook's state.
  React.useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const cfg = await fetchAuthConfig(fetchImpl);
        if (!alive) return;
        setAuthConfig(cfg);
        // The workbook's memory FIRST: the listing effect preselects from it
        // the moment a session exists, so it must be in place before one is.
        const st = await workbook.loadState();
        if (alive) setRemembered(st);
        const saved = restoreSession();
        if (saved) {
          activateSession(saved);
          try {
            const me = await client.me();
            if (alive) setSession({ ...saved, username: me.username, role: me.role, display_name: me.display_name, groups: me.groups });
          } catch {
            activateSession(null);
          }
        }
      } catch (e) {
        if (alive) setError((e as any)?.message || String(e));
      } finally {
        if (alive) setBooting(false);
      }
    })();
    const expired = () => { activateSession(null); setSession(null); setError('Your QueryStudio session has expired. Sign in again.'); };
    window.addEventListener('qs:auth-expired', expired);
    return () => { alive = false; window.removeEventListener('qs:auth-expired', expired); };
  }, [client, workbook, fetchImpl]);

  // Signed in: what narrows this person's rows (one read per session).
  React.useEffect(() => {
    if (!session) { setMyEnt(undefined); return; }
    let alive = true;
    client.myEntitlements()
      .then(e => { if (alive) setMyEnt(e); })
      .catch(e => { if (!alive) return; if (e instanceof SessionExpired) fail(e); else setMyEnt(null); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, client]);

  // Signed in: list what this person may open.
  React.useEffect(() => {
    if (!session) { setReports([]); setViews([]); return; }
    let alive = true;
    (async () => {
      try {
        // Unknown is not empty: a view listing that FAILED is said so, not
        // shown as "no views".  (A deployment with the Published Views API
        // off answers 503 there while reports work.)
        const [r, v] = await Promise.all([
          client.listReports(),
          client.listViews().then(list => ({ list, error: null as string | null }))
            .catch((e: any) => ({ list: [] as ViewSummary[], error: e?.message || String(e) })),
        ]);
        if (!alive) return;
        setReports(r);
        setViews(v.list);
        setViewsError(v.error);
        if (remembered && !selection) {
          if (remembered.kind === 'report' && r.some(x => x.id === Number(remembered.id))) {
            setSelection({ kind: 'report', id: Number(remembered.id) });
          } else if (remembered.kind === 'view' && v.list.some(x => x.slug === remembered.slug)) {
            setSelection({ kind: 'view', slug: remembered.slug });
          }
        }
      } catch (e) { if (alive) fail(e); }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, client, listTick]);

  // A chosen report: its parameters, defaults the viewer's way, remembered bindings.
  React.useEffect(() => {
    if (!selection || !session) { setReport(null); setView(null); return; }
    let alive = true;
    (async () => {
      try {
        setOutcome(null);
        if (selection.kind === 'report') {
          const r = await client.getReport(selection.id);
          if (!alive) return;
          setView(null);
          setReport(r);
          const defaults = await resolveParamDefaults(r.parameters || [], client.previewDateToken.bind(client));
          const next: Record<string, ParamBinding> = {};
          for (const p of r.parameters || []) {
            const kept = remembered?.kind === 'report' && Number(remembered.id) === r.id ? remembered.bindings?.[p.name] : undefined;
            next[p.name] = kept ?? { mode: 'value', value: defaults[p.name] ?? (p.parameter_type === 'multi_select' ? [] : '') };
          }
          if (alive) setBindings(next);
        } else {
          const v = views.find(x => x.slug === selection.slug) || await client.getView(selection.slug);
          if (!alive) return;
          setReport(null);
          setView(v);
          const next: Record<string, ParamBinding> = {};
          for (const d of v.param_definitions || []) {
            const kept = remembered?.kind === 'view' && remembered.slug === v.slug ? remembered.bindings?.[d.name] : undefined;
            next[d.name] = kept ?? { mode: 'value', value: d.default ?? '' };
          }
          if (alive) setBindings(next);
        }
      } catch (e) { if (alive) fail(e); }
    })();
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selection, session, client]);

  const onSignedIn = (s: AddinSession) => {
    activateSession(s);
    setSession(s);
    setError(null);
  };

  const signInViaHost = async () => {
    setError(null);
    try {
      const posted = await host.openLoginDialog?.(loginUrl);
      if (posted && typeof posted === 'object') onSignedIn(posted as AddinSession);
    } catch (e) { fail(e); }
  };

  const signOut = async () => {
    await client.logout();
    activateSession(null);
    setSession(null);
    setSelection(null);
    setOutcome(null);
  };

  const run = async () => {
    if (!session) return;
    setRunning(true); setError(null); setOutcome(null);
    try {
      const params = report
        ? (report.parameters || [])
        : (view?.param_definitions || []).map((d, i) => ({ id: i, name: d.name, label: d.label || d.name, parameter_type: d.type || 'text', is_required: !!d.required }));
      const resolved = await resolveParameterValues(params, bindings, workbook);
      if (resolved.missing.length) {
        setError(`Required parameter${resolved.missing.length > 1 ? 's' : ''} without a value: ${resolved.missing.join(', ')}`);
        return;
      }
      const user = { username: session.username, display_name: session.display_name, role: session.role, groups: session.groups };
      const opts = { bound, user, forceRefresh: forceLive, now, entitlement: myEnt };
      const out = report
        ? await runReport(client, report, resolved.values, opts)
        : await runView(client, view!, resolved.values, opts);
      if (!out.ok) { setOutcome({ run: out }); return; }
      const written = await workbook.writeTable({
        sheetName: out.sheetName, tableName: out.tableName, columns: out.columns, rows: out.rows, stamp: out.stamp,
      });
      const state: AddinState = {
        kind: out.kind,
        id: report ? report.id : view!.slug,
        slug: report ? (report.slug || String(report.id)) : view!.slug,
        name: report ? report.name : view!.name,
        bindings: bindingsForState(bindings),
        lastStamp: out.stamp,
        lastTableName: out.tableName,
      };
      await workbook.saveState(state);
      setRemembered(state);
      setOutcome({ run: out, written });
    } catch (e) { fail(e); }
    finally { setRunning(false); }
  };

  const chosenLabel = report ? report.name : view ? view.name : '';
  const entChip = chipWords(myEnt);
  const canRun = !!session && (!!report || !!view) && !running;
  const lastRun = outcome?.run ?? null;
  const refusal = lastRun && lastRun.ok === false ? lastRun.refusal : null;

  return (
    <Box sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5, maxWidth: 420 }} data-testid="addin-pane">
      <Stack direction="row" alignItems="center" justifyContent="space-between">
        <Typography variant="h6">QueryStudio for Excel</Typography>
        {session && (
          <Button size="small" onClick={signOut} aria-label="Sign out">Sign out</Button>
        )}
      </Stack>
      {session && (
        <Typography variant="caption" data-testid="addin-signed-in">
          Signed in as <b>{session.username}</b>{session.role ? ` (${session.role})` : ''} — the rows you fetch are yours.
        </Typography>
      )}
      {session && entChip && (
        <Tooltip title={<>{entChip.detail.map(t => <div key={t}>{t}</div>)}
          <div style={{ marginTop: 4, opacity: 0.8 }}>
            {entChip.state === 'applied'
              ? 'Rows on any table carrying these columns are limited to these values; a published view says what each answer was filtered by in its stamp.'
              : entChip.state === 'unknown'
                ? 'The answer could not be read; your rows may still be filtered.'
                : 'Each such read is audited.'}
          </div></>}>
          <Chip size="small" variant="outlined" icon={<FilterAltIcon />} label={entChip.label}
                color={entChip.state === 'unknown' ? 'warning' : 'default'}
                data-testid="addin-entitlement-chip" data-state={entChip.state} sx={{ alignSelf: 'flex-start' }} />
        </Tooltip>
      )}
      {error && <Alert severity="error" data-testid="addin-error" onClose={() => setError(null)}>{error}</Alert>}
      {booting && <Typography variant="body2">Connecting…</Typography>}

      {!booting && !session && (
        host.kind === 'browser'
          ? <LoginForm onSignedIn={onSignedIn} authConfig={authConfig} fetchImpl={fetchImpl} />
          : (
            <Stack spacing={1}>
              <Typography variant="body2">Sign in with your QueryStudio account. A dialog opens on the QueryStudio site; your password is never typed into Excel's credential store.</Typography>
              <Button variant="contained" onClick={signInViaHost}>Sign in to QueryStudio</Button>
            </Stack>
          )
      )}

      {session && (
        <>
          <FormControl size="small" fullWidth>
            <InputLabel id="addin-object-label">Report or published view</InputLabel>
            <Select labelId="addin-object-label" id="addin-object" label="Report or published view"
                    onOpen={() => setListTick(t => t + 1)}
                    value={selection ? (selection.kind === 'report' ? `report:${selection.id}` : `view:${selection.slug}`) : ''}
                    onChange={e => {
                      const v = String(e.target.value);
                      if (!v) { setSelection(null); return; }
                      const [kind, key] = [v.slice(0, v.indexOf(':')), v.slice(v.indexOf(':') + 1)];
                      setSelection(kind === 'report' ? { kind: 'report', id: Number(key) } : { kind: 'view', slug: key });
                    }}>
              <MenuItem value="">(choose)</MenuItem>
              {reports.map(r => (
                <MenuItem key={`r${r.id}`} value={`report:${r.id}`}>
                  {r.name}{r.is_certified ? ' ✓' : ''}{r.lifecycle_status && r.lifecycle_status !== 'published' ? ` (${r.lifecycle_status})` : ''}
                </MenuItem>
              ))}
              {views.length > 0 && <Divider />}
              {views.map(v => <MenuItem key={`v${v.slug}`} value={`view:${v.slug}`}>view: {v.name}</MenuItem>)}
            </Select>
          </FormControl>
          {reports.length === 0 && views.length === 0 && !viewsError && (
            <Typography variant="body2" color="text.secondary">No reports or published views are visible to you.</Typography>
          )}
          {viewsError && (
            <Typography variant="caption" color="error" data-testid="addin-views-error">
              Published views could not be listed: {viewsError}
            </Typography>
          )}

          {report && (
            <ParameterPanel client={client} reportId={report.id} params={report.parameters || []}
                            bindings={bindings} onChange={setBindings} />
          )}
          {view && (view.param_definitions || []).length > 0 && (
            <ParameterPanel client={client} reportId={0}
                            params={(view.param_definitions || []).map((d, i) => ({
                              id: i, name: d.name, label: d.label || d.name, parameter_type: d.type || 'text', is_required: !!d.required,
                            }))}
                            bindings={bindings} onChange={setBindings} />
          )}

          {(report || view) && (
            <Stack spacing={1}>
              {report && (
                <FormControlLabel
                  control={<Checkbox size="small" checked={forceLive} onChange={e => setForceLive(e.target.checked)}
                                     inputProps={{ 'aria-label': 'Force a live run' }} />}
                  label={<Typography variant="caption">Force a live run (skip the stored instance)</Typography>} />
              )}
              <Stack direction="row" spacing={1}>
                <Button variant="contained" onClick={run} disabled={!canRun} aria-label={`Run ${chosenLabel}`}>
                  {running ? 'Running…' : 'Run'}
                </Button>
                <Button variant="outlined" onClick={run} disabled={!canRun || !remembered}
                        aria-label={`Refresh ${chosenLabel}`}>Refresh</Button>
              </Stack>
              <Typography variant="caption" color="text.secondary">
                Run writes table <code data-testid="addin-table-hint">{report ? tableNameFor({ kind: 'report', id: report.id, slug: report.slug }) : view ? tableNameFor({ kind: 'view', slug: view.slug }) : ''}</code> on its own sheet.
                Refresh re-reads every bound cell and runs again. Up to {bound.toLocaleString()} rows; more is refused, never cut.
              </Typography>
            </Stack>
          )}

          {refusal && (
            <Alert severity="warning" data-testid="addin-refusal">
              <b>{refusal.message}</b><br />{refusal.guidance}
            </Alert>
          )}
          {outcome && outcome.run.ok && outcome.written && (
            <Box data-testid="addin-result">
              <Alert severity="success">
                Wrote <b>{outcome.written.rowsWritten.toLocaleString()}</b> rows to table <b>{outcome.written.tableName}</b> on sheet <b>{outcome.written.sheetName}</b> ({outcome.written.address}).
                {' '}<Chip size="small" label={outcome.run.probe ? 'served from a stored instance' : 'run live'} />
              </Alert>
              <StampList stamp={outcome.run.stamp} />
            </Box>
          )}
        </>
      )}
    </Box>
  );
};

const StampList: React.FC<{ stamp: StampLine[] }> = ({ stamp }) => (
  <Box component="dl" sx={{ m: 0, mt: 1, display: 'grid', gridTemplateColumns: 'auto 1fr', columnGap: 1, rowGap: 0.25, fontSize: 12 }}
       data-testid="addin-stamp">
    {stamp.map(l => (
      <React.Fragment key={l.label}>
        <Box component="dt" sx={{ fontWeight: 600 }}>{l.label}</Box>
        <Box component="dd" sx={{ m: 0, wordBreak: 'break-word' }} data-stamp={l.label}>{l.value}</Box>
      </React.Fragment>
    ))}
  </Box>
);

export default AddinPane;
