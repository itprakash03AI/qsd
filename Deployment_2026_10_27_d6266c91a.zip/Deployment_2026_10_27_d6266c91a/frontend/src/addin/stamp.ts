/**
 * Excel add-in (2026-09-28) — the STAMP beside the table.
 *
 * What no CSV carries: which report and which published version, the
 * instance or execution the rows came from, the as-of time, the engine
 * that answered, the row count, whose rows these are (the row-security
 * principal — the signed-in session, by construction of the routes the
 * add-in calls), certification, and readiness when the report exposes it.
 * Every line is a fact the API returned; nothing here is computed from
 * what the pane happened to download.  A missing fact is stated as
 * missing ("not recorded"), never invented.
 */
import type { StampLine } from './ports';
import type { MyEntitlements } from '../components/common/EntitlementChip';
import { disclosureStampValue, myEntitlementStampValue, type EntitlementDisclosure } from './entitlement';

export interface SessionUser {
  username: string;
  display_name?: string;
  role?: string;
  groups?: string[];
}

export interface ReportForStamp {
  id: number;
  slug?: string;
  name: string;
  is_certified?: boolean;
  certified_by?: string | null;
  certified_at?: string | null;
  current_version?: { version_no?: number | null } | null;
  /** R1#2 (a parallel build): when the report exposes a readiness verdict
   *  the stamp shows it; absent = not shown, never "unknown". */
  readiness?: { verdict?: string; state?: string; status?: string; as_of?: string; reason?: string } | null;
}

/** The execute envelope's keys the stamp reads (core/reports/contract.py +
 *  core/reports/instances.py + engine_attribution).  All optional: an older
 *  backend, or a route that does not stamp one, leaves it out. */
export interface EnvelopeForStamp {
  execution_id?: string;
  total_rows?: number | null;
  truncated?: boolean | null;
  row_limit?: number | null;
  served_from_instance?: boolean;
  instance?: {
    id?: number | string; execution_id?: string; created_at?: string | null;
    created_by?: string | null; is_scheduled?: boolean; status?: string | null;
  } | null;
  as_of?: string | null;
  freshness?: string | null;
  stale?: boolean;
  served_version?: { version_no?: number | null; published_at?: string | null } | null;
  execution_engine?: string | null;
  execution_engine_label?: string | null;
  data_status?: string | null;
}

export interface StampInput {
  report: ReportForStamp;
  envelope: EnvelopeForStamp;
  /** The signed-in session — THE row-security principal on /execute. */
  user: SessionUser;
  /** The values the run was made with (already resolved). */
  parameters: Record<string, unknown>;
  /** When the pane received the rows (ISO). */
  retrievedAt: string;
  /** Rows actually written (must equal total_rows or the write was refused). */
  rowsWritten: number;
  /** The signed-in person's data entitlement (/api/me/entitlements): what a
   *  report run is filtered by.  `null` = could not be read; `undefined` =
   *  not read (an older pane) -- both said, never "not filtered". */
  entitlement?: MyEntitlements | null;
}

function fmtWhen(iso: string | null | undefined): string {
  if (!iso) return '';
  return String(iso);
}

/** "filtered for <user>" — the principal the rows were filtered for. */
export function principalLine(user: SessionUser): StampLine {
  const who = user.username || '';
  const role = user.role ? ` (${user.role})` : '';
  return { label: 'Filtered for', value: `${who}${role}` };
}

export function buildReportStamp(input: StampInput): StampLine[] {
  const { report, envelope: env, user, parameters, retrievedAt, rowsWritten } = input;
  const lines: StampLine[] = [];
  lines.push({ label: 'QueryStudio report', value: `${report.name} (#${report.id}${report.slug ? `, ${report.slug}` : ''})` });

  const versionNo = env.served_version?.version_no ?? report.current_version?.version_no ?? null;
  lines.push({
    label: 'Version',
    value: versionNo != null ? `v${versionNo}` : 'draft (no published version)',
  });

  if (env.served_from_instance && env.instance) {
    const inst = env.instance;
    const by = inst.created_by ? ` by ${inst.created_by}` : '';
    const sched = inst.is_scheduled ? ', scheduled' : '';
    lines.push({
      label: 'Source',
      value: `stored instance #${inst.id ?? '?'} (built ${fmtWhen(inst.created_at)}${by}${sched})${env.stale ? ' — STALE, refresh queued' : ''}`,
    });
    lines.push({ label: 'Execution', value: String(inst.execution_id || env.execution_id || 'not recorded') });
    lines.push({ label: 'As of', value: fmtWhen(env.as_of || inst.created_at) || 'not recorded' });
  } else {
    lines.push({ label: 'Source', value: 'live run' });
    lines.push({ label: 'Execution', value: String(env.execution_id || 'not recorded') });
    lines.push({ label: 'As of', value: retrievedAt });
  }

  const engine = env.execution_engine_label || env.execution_engine || 'not recorded';
  lines.push({ label: 'Engine', value: engine });

  const total = env.total_rows;
  lines.push({
    label: 'Rows',
    value: total != null ? String(total) : `${rowsWritten} (total not recorded)`,
  });
  if (env.truncated === true) {
    lines.push({ label: 'Truncated', value: `yes — the report's row limit (${env.row_limit ?? '?'}) was reached` });
  }

  lines.push(principalLine(user));
  // 2026-10-24 -- what narrowed the person's rows (the chip's words)
  lines.push({ label: 'Entitlement', value: myEntitlementStampValue(input.entitlement) });

  if (report.is_certified) {
    const when = report.certified_at ? ` at ${report.certified_at}` : '';
    lines.push({ label: 'Certification', value: `certified by ${report.certified_by || 'unknown'}${when}` });
  } else {
    lines.push({ label: 'Certification', value: 'not certified' });
  }

  const readiness = report.readiness;
  if (readiness && typeof readiness === 'object') {
    const verdict = readiness.verdict || readiness.state || readiness.status;
    if (verdict) {
      const asOf = readiness.as_of ? ` (as of ${readiness.as_of})` : '';
      const why = readiness.reason ? ` — ${readiness.reason}` : '';
      lines.push({ label: 'Readiness', value: `${verdict}${asOf}${why}` });
    }
  }

  if (env.data_status) lines.push({ label: 'Data status', value: String(env.data_status) });

  const keys = Object.keys(parameters || {});
  lines.push({
    label: 'Parameters',
    value: keys.length ? keys.map(k => `${k}=${JSON.stringify(parameters[k])}`).join('; ') : 'none',
  });
  lines.push({ label: 'Retrieved at', value: retrievedAt });
  return lines;
}

export interface ViewForStamp {
  slug: string;
  name: string;
  version?: number | null;
  source_type?: string;
}

export function buildViewStamp(input: {
  view: ViewForStamp;
  totalRows: number | null;
  user: SessionUser;
  parameters: Record<string, unknown>;
  retrievedAt: string;
  rowsWritten: number;
  /** The answer's own `meta.entitlement` (the server's disclosure of what
   *  THIS read was filtered by); absent on an older backend = "not recorded". */
  entitlement?: EntitlementDisclosure | null;
}): StampLine[] {
  const { view, totalRows, user, parameters, retrievedAt, rowsWritten } = input;
  const keys = Object.keys(parameters || {});
  return [
    { label: 'QueryStudio published view', value: `${view.name} (${view.slug})` },
    { label: 'Version', value: view.version != null ? `v${view.version}` : 'not recorded' },
    { label: 'Source', value: `live read (${view.source_type || 'published view'})` },
    { label: 'As of', value: retrievedAt },
    { label: 'Rows', value: totalRows != null ? String(totalRows) : `${rowsWritten} (total not recorded)` },
    principalLine(user),
    // 2026-10-24 -- the server's disclosure for THIS answer (meta.entitlement)
    { label: 'Entitlement', value: disclosureStampValue(input.entitlement) },
    { label: 'Parameters', value: keys.length ? keys.map(k => `${k}=${JSON.stringify(parameters[k])}`).join('; ') : 'none' },
    { label: 'Retrieved at', value: retrievedAt },
  ];
}
