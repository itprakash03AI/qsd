/**
 * Excel add-in (2026-10-24) — the entitlement CHIP and the stamp's
 * "Entitlement" line (docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html §4; the
 * web screens carry `components/common/EntitlementChip`).
 *
 * Two sources, the same three states, never conflated:
 *   * the signed-in PERSON's own entitlement (GET /api/me/entitlements — what
 *     they hold per dimension): the chip in the pane and a REPORT's stamp
 *     line, because a report run is filtered for the session;
 *   * a published VIEW's answer carries `meta.entitlement` — the server's
 *     disclosure of what THAT materialisation was filtered by (the one
 *     resolution the query used), so a view's stamp line says exactly that.
 * "Could not be read" / "could not be determined" are said as such; they are
 * never shown as "not filtered".  Pure functions: the pane renders the words.
 */
import { entitlementWords, type MyEntitlements } from '../components/common/EntitlementChip';

/** `meta.entitlement` of a published-view answer (core/row_security/disclosure.py). */
export interface EntitlementDisclosure {
  state: 'applied' | 'not_applied' | 'unknown' | string;
  applied: boolean | null;
  reason: string | null;
  mode?: string;
  principal?: { type: string; id: string | null };
  // the dimension's NAME and the caller's access only -- never the tables or
  // the physical columns behind the API (security review 2026-10-24)
  dimensions: Array<{
    name: string;
    access: 'values' | 'all' | 'none' | 'everything_by_rule' | string;
    values: string[]; value_count: number; values_listed?: boolean;
  }>;
  note?: string;
}

const REASON_WORDS: Record<string, string> = {
  admin_bypass: 'administrator — not filtered, audited',
  row_security_off: 'row security is off in this deployment',
  entitlement_disabled: 'data entitlement is switched off',
  data_policies_off: "this API's data-policy switch is off (no row policy, no dimension)",
  mode_off: "this feed's entitlement switch is off",
  no_active_dimension: 'no dimension is active',
  no_entitled_column: 'no table read carries an entitled column',
  not_observed: 'the server recorded no decision for this result',
};

function dimensionWords(d: EntitlementDisclosure['dimensions'][number]): string {
  let what: string;
  if (d.access === 'all') what = 'every value';
  else if (d.access === 'everything_by_rule') what = 'every value (no value held; the dimension\'s rule)';
  else if (d.access === 'none') what = 'no value held — no rows';
  else if (d.values_listed === false || !(d.values || []).length) what = `${d.value_count} values`;
  else what = `in (${d.values.join(', ')})`;
  return `${d.name}: ${what}`;
}

/** The person's own dimensions, named by DIMENSION only (the web chip also
 *  names the columns; an add-in stamp travels in a workbook, so it carries
 *  no physical column names -- security review 2026-10-24). */
function personDetail(e: MyEntitlements): string[] {
  return (e.dimensions || []).map(d => {
    let what: string;
    if (d.values === 'all') what = 'every value';
    else if (d.values.length) what = d.values.join(', ');
    else what = d.you_see.startsWith('everything') ? 'every value (no value set)' : 'no value -- no rows';
    return `${d.dimension}: ${what}`;
  });
}

/** The "Entitlement" stamp line of a VIEW run, from the answer's own disclosure. */
export function disclosureStampValue(block: EntitlementDisclosure | null | undefined): string {
  if (!block || typeof block !== 'object' || !block.state) return 'not recorded (the server did not say)';
  if (block.state === 'applied') {
    const dims = (block.dimensions || []).map(dimensionWords);
    return `filtered — ${dims.length ? dims.join('; ') : 'by data entitlement'}`;
  }
  const why = REASON_WORDS[String(block.reason)] || String(block.reason || '');
  if (block.state === 'not_applied') return `not applied — ${why}`;
  return `could not be determined — ${why}`;
}

/** The "Entitlement" stamp line of a REPORT run: the signed-in person's own
 *  entitlement (/api/me/entitlements), the chip's words. */
export function myEntitlementStampValue(e: MyEntitlements | null | undefined): string {
  if (e === undefined) return 'not read';
  const words = entitlementWords(e);
  if (words === null) return 'not applied — no dimension is defined';
  if (e === null) return 'could not be read';
  if (e.is_admin) return 'not applied — administrator (audited)';
  return `filtered — ${personDetail(e).join('; ')}`;
}

/** The pane's chip: label + tooltip lines, or null when there is nothing to say. */
export function chipWords(e: MyEntitlements | null | undefined): { label: string; detail: string[]; state: 'applied' | 'not_applied' | 'unknown' } | null {
  if (e === undefined) return null;
  const words = entitlementWords(e);
  if (!words) return null;
  if (e === null) return { ...words, state: 'unknown' };
  if (e.is_admin) return { ...words, state: 'not_applied' };
  return { label: words.label, detail: personDetail(e), state: 'applied' };
}
