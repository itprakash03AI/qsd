/**
 * Value Lists (2026-10-24) -- NAMED lists of choices synced into QueryStudio's
 * own database (backend core/value_lists.py).
 *
 * The owner: "create a table and get possible parameter values saved in our
 * db ... a sync-up option rather than calling at run time ... key value
 * json"; "prod can get from prod queries".  A list is a query on a
 * connection naming a KEY column (what a choice filters by) and a LABEL
 * column (what a person reads) -- or a static list typed here.  "Sync now"
 * (or the daily sync) stores its values; any report parameter can offer it.
 * A release carries the definition; each environment syncs its own values.
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, MenuItem,
  Paper, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField,
  Tooltip, Typography,
} from '@mui/material';
import { Add as AddIcon, Sync as SyncIcon } from '@mui/icons-material';
import { safeFetch } from '../services/api/core';
import ConnectionPicker from './common/ConnectionPicker';

interface ValueList {
  id: number; name: string; description?: string | null; source_type: 'query' | 'static';
  connection_id?: number | null; source_sql?: string | null; key_column?: string | null;
  label_column?: string | null; sync_mode: 'manual' | 'daily'; sync_every_hours?: number | null;
  last_synced_at?: string | null; last_status: string; last_error?: string | null;
  last_sync_summary?: any; value_count: number; created_by?: string | null;
}

interface ListForm {
  id: number; name: string; description: string; source_type: 'query' | 'static';
  connection_id: number | null; source_sql: string; key_column: string; label_column: string;
  sync_mode: 'manual' | 'daily'; sync_every_hours: number; items_text: string;
}

const EMPTY: ListForm = { id: 0, name: '', description: '', source_type: 'query', connection_id: null,
                          source_sql: '', key_column: '', label_column: '', sync_mode: 'manual',
                          sync_every_hours: 24, items_text: '' };

/** "synced 2 h ago -- 4,213 values (+12, 3 gone)" in words. */
export function syncWords(vl: Pick<ValueList, 'last_status' | 'last_synced_at' | 'value_count' | 'last_sync_summary' | 'last_error'>,
                          now: number = Date.now()): string {
  if (vl.last_status === 'never') return 'Not synced yet';
  const ago = vl.last_synced_at ? Math.max(0, Math.round((now - Date.parse(vl.last_synced_at)) / 60000)) : null;
  const when = ago === null ? '' : ago < 60 ? `${ago} min ago` : ago < 1440 ? `${Math.round(ago / 60)} h ago`
    : `${Math.round(ago / 1440)} d ago`;
  const s = vl.last_sync_summary || {};
  const delta = s.added || s.removed || s.changed
    ? ` (+${s.added || 0} new, ${s.changed || 0} changed, ${s.removed || 0} gone)` : '';
  const base = `${vl.value_count.toLocaleString()} values${when ? `, synced ${when}` : ''}${delta}`;
  return vl.last_status === 'failed'
    ? `Last sync FAILED -- still serving the previous ${vl.value_count.toLocaleString()} values: ${vl.last_error || ''}`
    : base;
}

/** "KEY | label" lines -> items (a static list typed by a person). */
export function itemsFromText(text: string): { key: string; label: string | null }[] {
  return text.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
    const [k, ...rest] = l.split('|');
    return { key: k.trim(), label: rest.join('|').trim() || null };
  }).filter(i => i.key);
}

export default function ValueListsPage() {
  const [lists, setLists] = useState<ValueList[]>([]);
  const [loadError, setLoadError] = useState('');
  const [form, setForm] = useState<ListForm | null>(null);
  const [preview, setPreview] = useState<any>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await safeFetch('/api/value-lists');
      setLists(r?.items || []);
      setLoadError('');
    } catch (e: any) {
      setLoadError(e?.message || String(e));      // unknown is not "none yet"
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const openEdit = async (vl?: ValueList) => {
    setError(''); setPreview(null);
    if (!vl) { setForm({ ...EMPTY }); return; }
    let items_text = '';
    if (vl.source_type === 'static') {
      const r = await safeFetch(`/api/value-lists/${vl.id}/items?limit=5000`).catch(() => null);
      items_text = (r?.values || []).map((v: any) => (v.label ? `${v.key} | ${v.label}` : v.key)).join('\n');
    }
    setForm({ id: vl.id, name: vl.name, description: vl.description || '', source_type: vl.source_type,
              connection_id: vl.connection_id ?? null, source_sql: vl.source_sql || '',
              key_column: vl.key_column || '', label_column: vl.label_column || '',
              sync_mode: vl.sync_mode, sync_every_hours: vl.sync_every_hours || 24, items_text });
  };

  const runPreview = async () => {
    if (!form) return;
    setError(''); setPreview(null);
    try {
      setPreview(await safeFetch('/api/value-lists/preview', { method: 'POST', body: JSON.stringify({
        connection_id: form.connection_id, source_sql: form.source_sql,
        key_column: form.key_column || null, label_column: form.label_column || null }) }));
    } catch (e: any) { setError(e?.message || String(e)); }
  };

  const save = async (andSync: boolean) => {
    if (!form) return;
    setError('');
    const body: any = { name: form.name, description: form.description || null, source_type: form.source_type,
                        sync_mode: form.source_type === 'query' ? form.sync_mode : 'manual',
                        sync_every_hours: form.sync_mode === 'daily' ? Number(form.sync_every_hours) || 24 : null };
    if (form.source_type === 'query') {
      Object.assign(body, { connection_id: form.connection_id, source_sql: form.source_sql,
                            key_column: form.key_column, label_column: form.label_column || null });
    }
    try {
      const saved = form.id
        ? await safeFetch(`/api/value-lists/${form.id}`, { method: 'PUT', body: JSON.stringify(body) })
        : await safeFetch('/api/value-lists', { method: 'POST', body: JSON.stringify(body) });
      if (form.source_type === 'static') {
        await safeFetch(`/api/value-lists/${saved.id}/items`, { method: 'PUT',
          body: JSON.stringify({ items: itemsFromText(form.items_text) }) });
      } else if (andSync) {
        await safeFetch(`/api/value-lists/${saved.id}/sync`, { method: 'POST' });
      }
      setForm(null);
      load();
    } catch (e: any) { setError(e?.message || String(e)); }
  };

  const syncNow = async (vl: ValueList) => {
    setBusy(vl.id);
    try { await safeFetch(`/api/value-lists/${vl.id}/sync`, { method: 'POST' }); }
    catch (e: any) { setLoadError(e?.message || String(e)); }
    finally { setBusy(null); load(); }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="h5" sx={{ flex: 1 }}>Value Lists</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => openEdit()}>New value list</Button>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        A list of choices -- for example every SAP company with its name -- read from a query and saved here, so a
        report parameter offers it instantly. Sync it when the source changes (or daily). Each viewer only sees the
        values they are entitled to.
      </Typography>
      {loadError && <Alert severity="error" sx={{ mb: 2 }}>Could not read the value lists: {loadError}</Alert>}
      <TableContainer component={Paper}>
        <Table size="small" aria-label="Value lists">
          <TableHead><TableRow>
            <TableCell>Name</TableCell><TableCell>From</TableCell><TableCell>Values</TableCell>
            <TableCell>Sync</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {lists.map(vl => (
              <TableRow key={vl.id} data-testid={`value-list-${vl.name}`}>
                <TableCell>{vl.name}</TableCell>
                <TableCell>{vl.source_type === 'static' ? 'Typed list'
                  : `${vl.key_column}${vl.label_column ? ` + ${vl.label_column}` : ''}`}</TableCell>
                <TableCell>
                  <Chip size="small" color={vl.last_status === 'failed' ? 'error' : vl.last_status === 'never' ? 'default' : 'success'}
                        variant="outlined" label={syncWords(vl)} data-testid={`value-list-status-${vl.name}`} />
                </TableCell>
                <TableCell>{vl.source_type === 'static' ? '—'
                  : vl.sync_mode === 'daily' ? `Every ${vl.sync_every_hours || 24} h` : 'When you sync'}</TableCell>
                <TableCell align="right">
                  {vl.source_type === 'query' && (
                    <Tooltip title="Read the values again now">
                      <span><Button size="small" startIcon={<SyncIcon />} disabled={busy === vl.id}
                                    onClick={() => syncNow(vl)}>{busy === vl.id ? 'Syncing…' : 'Sync now'}</Button></span>
                    </Tooltip>
                  )}
                  <Button size="small" onClick={() => openEdit(vl)}>Edit</Button>
                </TableCell>
              </TableRow>
            ))}
            {!lists.length && !loadError && (
              <TableRow><TableCell colSpan={5}>No value list yet.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={!!form} onClose={() => setForm(null)} maxWidth="md" fullWidth>
        <DialogTitle>{form?.id ? 'Edit value list' : 'New value list'}</DialogTitle>
        {form && (
          <DialogContent>
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
              <TextField select label="Values come from" value={form.source_type} disabled={!!form.id}
                         helperText={form.id ? "A list's source does not change -- make a new list for another" : undefined}
                         onChange={e => setForm({ ...form, source_type: e.target.value as any })}>
                <MenuItem value="query">A query (synced into QueryStudio)</MenuItem>
                <MenuItem value="static">A list I type</MenuItem>
              </TextField>
              {form.source_type === 'query' ? (
                <>
                  <ConnectionPicker label="Connection" value={form.connection_id ? String(form.connection_id) : ''}
                    onChange={id => setForm({ ...form, connection_id: id ? Number(id) : null })} />
                  <TextField label="Query" multiline minRows={3} value={form.source_sql}
                    placeholder="SELECT DISTINCT sap_company_id, company_name FROM ref.dim_company"
                    onChange={e => setForm({ ...form, source_sql: e.target.value })} />
                  <Stack direction="row" spacing={1}>
                    <TextField select={!!preview?.columns} label="Key column (what a choice filters by)" fullWidth
                      value={form.key_column} onChange={e => setForm({ ...form, key_column: e.target.value })}>
                      {(preview?.columns || []).map((c: string) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                    </TextField>
                    <TextField select={!!preview?.columns} label="Label column (what a person reads)" fullWidth
                      value={form.label_column} onChange={e => setForm({ ...form, label_column: e.target.value })}>
                      <MenuItem value="">(none)</MenuItem>
                      {(preview?.columns || []).map((c: string) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                    </TextField>
                  </Stack>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <TextField select label="Sync" value={form.sync_mode} sx={{ minWidth: 220 }}
                      onChange={e => setForm({ ...form, sync_mode: e.target.value as any })}>
                      <MenuItem value="manual">When I press Sync now</MenuItem>
                      <MenuItem value="daily">Automatically, every N hours</MenuItem>
                    </TextField>
                    {form.sync_mode === 'daily' && (
                      <TextField type="number" label="Every (hours)" sx={{ width: 140 }} value={form.sync_every_hours}
                        slotProps={{ htmlInput: { min: 1 } }} onChange={e => setForm({ ...form, sync_every_hours: Number(e.target.value) })} />
                    )}
                    <Box sx={{ flex: 1 }} />
                    <Button onClick={runPreview} disabled={!form.connection_id || !form.source_sql.trim()}>Preview</Button>
                  </Stack>
                  {preview && (
                    <Alert severity={preview.problem ? 'warning' : 'info'} data-testid="value-list-preview">
                      {preview.problem || `${preview.row_count.toLocaleString()} row(s)`
                        + (preview.distinct_keys !== undefined ? `, ${preview.distinct_keys.toLocaleString()} distinct keys` : '')
                        + ` -- columns: ${preview.columns.join(', ')}`}
                    </Alert>
                  )}
                </>
              ) : (
                <TextField label="Values, one per line: KEY | label" multiline minRows={6} value={form.items_text}
                  placeholder={'GB01 | UK Ltd\nDE02 | Deutschland GmbH'}
                  onChange={e => setForm({ ...form, items_text: e.target.value })} />
              )}
              {error && <Alert severity="error">{error}</Alert>}
            </Stack>
          </DialogContent>
        )}
        <DialogActions>
          <Button onClick={() => setForm(null)}>Cancel</Button>
          {form?.source_type === 'query' && (
            <Button onClick={() => save(true)} variant="contained">Save and sync</Button>
          )}
          <Button onClick={() => save(false)} variant={form?.source_type === 'query' ? 'outlined' : 'contained'}>Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
