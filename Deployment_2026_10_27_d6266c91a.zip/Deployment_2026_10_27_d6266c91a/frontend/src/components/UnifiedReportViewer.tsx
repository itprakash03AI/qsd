/**
 * Phase 111-H: Unified Report Viewer — auto-detects report type and delegates.
 *
 * Loads the business report by ID, checks data_source_type and layout_config,
 * then renders the appropriate viewer:
 *   - pivot (layout_config.report_type === 'pivot') → PivotReportViewer
 *   - raw_sql → inline viewer with parameter form + DataGridViewer
 *   - default (tabular) → BusinessReportViewer
 */
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { useExportRetention } from './reports/useExportRetention';
import { useParams, useNavigate } from 'react-router-dom';
import { ReportIdentityContext, reportPath } from '../utils/reportUrls';
import { useAuth } from '../context/AuthContext';
import { canEditReport } from '../utils/reportLifecycle';
import {
  Box, Paper, Typography, Button, Alert, Chip, Skeleton,
  TextField, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TablePagination, TableSortLabel, Menu, MenuItem, ListItemIcon, ListItemText,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import EditIcon from '@mui/icons-material/Edit';
import GetAppIcon from '@mui/icons-material/GetApp';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import TableViewIcon from '@mui/icons-material/TableView';
import api from '../services/api';
import { REPORTS_PATH, reportEditPath } from '../utils/reportUrls';
import EngineChip from './common/EngineChip';
import ScanDisclosureChip from './common/ScanDisclosureChip';
import EntitlementChip from './common/EntitlementChip';
import ReportBookmarks from './reports/ReportBookmarks';
// 2026-09-28 -- readiness of the business date + the report's promise
import ReadinessChip from './reports/ReadinessChip';
import { draftFromReport, evaluateRuleStyle, cutoffsFromRows } from './reports/reportAuthoringModel';
import ReportSloChip from './reports/ReportSloChip';
import ReportReadinessSloDialog from './reports/ReportReadinessSloDialog';
import FactCheckIcon from '@mui/icons-material/FactCheck';

const BusinessReportViewer = lazy(() => import('./BusinessReportViewer'));
const PivotReportViewer = lazy(() => import('./PivotReportViewer'));

const fallback = (
  <Box sx={{ p: 3 }}>
    <Skeleton variant="text" width={300} height={40} sx={{ mb: 2 }} />
    <Skeleton variant="rectangular" height={100} sx={{ mb: 2, borderRadius: 1 }} />
    <Skeleton variant="rectangular" height={300} sx={{ borderRadius: 1 }} />
  </Box>
);

const UnifiedReportViewer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    // 2026-09-20 -- ":id" carries the SLUG; resolved ONE way (by-slug).  A
    // numeric token (a legacy row with no slug, or a hand-typed id) is
    // resolved by the same route and the URL canonicalised to the slug.
    api.getBusinessReportBySlug(id)
      .then((data: any) => {
        setReport(data);
        if (data?.slug && data.slug !== id) navigate(reportPath(data), { replace: true });
      })
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [id, navigate]);

  if (loading) return fallback;
  if (error) return <Alert severity="error" sx={{ m: 3 }}>{error}</Alert>;
  if (!report) return <Alert severity="warning" sx={{ m: 3 }}>Report not found</Alert>;

  const dst = report.data_source_type || 'saved_query';
  const lc = report.layout_config || {};

  const identity = { id: Number(report.id), slug: report.slug ?? null };

  // Pivot report → PivotReportViewer
  if (lc.report_type === 'pivot') {
    return (
      <ReportIdentityContext.Provider value={identity}>
      <Suspense fallback={fallback}>
        <PivotReportViewer />
      </Suspense>
      </ReportIdentityContext.Provider>
    );
  }

  // Raw SQL report → inline viewer
  if (dst === 'raw_sql') {
    return <RawSqlReportViewer report={report} />;
  }

  // Default: tabular → BusinessReportViewer
  return (
    <ReportIdentityContext.Provider value={identity}>
    <Suspense fallback={fallback}>
      <BusinessReportViewer />
    </Suspense>
    </ReportIdentityContext.Provider>
  );
};

// ── Inline Raw SQL Report Viewer ────────────────────────────────────────────

interface RawSqlViewerProps {
  report: any;
}

const RawSqlReportViewer: React.FC<RawSqlViewerProps> = ({ report }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [executing, setExecuting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');
  const [resultData, setResultData] = useState<{ columns: string[]; rows: any[]; format_cutoffs?: Record<string, number> } | null>(null);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  // One retention control, shared by every export menu (2026-08-30).
  const { retainDays, retentionControl } = useExportRetention();
  const handleExecuteRef = React.useRef<() => void>(() => {});
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [totalRows, setTotalRows] = useState(0);
  // F-P3A-12: when server-side paging is unavailable, the execute
  // envelope's inline rows render instead (paged locally).  The old
  // behaviour was a summary card claiming N rows above NO table, NO
  // message, Export disabled — a silent dead end.
  const [clientPaged, setClientPaged] = useState(false);
  // 2026-10-24 -- the author's conditional formats, applied ON SCREEN with
  // the evaluator the preview and the exports use.
  const formatRules = React.useMemo(() => draftFromReport(report || {}).rules, [report]);
  const cellCutoffs = React.useMemo(() => (clientPaged && resultData
    ? cutoffsFromRows(formatRules, resultData.rows) : (resultData?.format_cutoffs || {})),
  [formatRules, resultData, clientPaged]);
  const [pageNotice, setPageNotice] = useState('');
  // 2026-09-28 -- the Readiness & SLO declaration (editors only)
  const [readinessOpen, setReadinessOpen] = useState(false);
  const [sloRefresh, setSloRefresh] = useState(0);

  const params = report.raw_parameters_schema || [];

  // Initialize default values + auto-execute if no required params
  const autoExecuted = React.useRef(false);
  useEffect(() => {
    const defaults: Record<string, string> = {};
    for (const p of params) {
      if (p.default_value) defaults[p.name] = p.default_value;
    }
    setParamValues(defaults);
    autoExecuted.current = false;
  }, [report.id]);

  // Auto-execute on first load if there are no required params without defaults
  useEffect(() => {
    if (autoExecuted.current) return;
    const hasRequiredMissing = params.some(
      (p: any) => p.required && !p.default_value
    );
    if (!hasRequiredMissing) {
      autoExecuted.current = true;
      handleExecuteRef.current();
    }
  }, [paramValues]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadPage = React.useCallback(async (execId: string, pg: number, ps: number, sc?: string | null, sd?: string): Promise<boolean> => {
    try {
      const pageData = await api.getBusinessReportPagedResults(
        report.id, execId, pg + 1, ps, sc, sd
      );
      if (pageData?.columns && pageData?.rows) {
        setClientPaged(false);
        setPageNotice('');
        setResultData(pageData);
        setTotalRows(pageData.total_rows ?? pageData.rows.length);
        return true;
      }
    } catch {
      // fall through — the caller decides the fallback
    }
    return false;
  }, [report.id]);

  const handleExecute = React.useCallback(async () => {
    setExecuting(true);
    setError('');
    setResult(null);
    setResultData(null);
    setPageNotice('');
    setClientPaged(false);
    setPage(0);
    try {
      const res = await api.executeBusinessReport(report.id, {
        parameter_values: paramValues,
      });
      setResult(res);
      setTotalRows(res?.total_rows ?? 0);

      let paged = false;
      if (res?.execution_id) {
        paged = await loadPage(res.execution_id, 0, rowsPerPage, sortCol, sortDir);
      }
      if (!paged) {
        // F-P3A-12: fall back to the rows the execute already returned —
        // never discard data in hand, and never dead-end without a reason.
        const inline = Array.isArray(res?.data) && Array.isArray(res?.columns)
          ? { columns: res.columns as string[], rows: res.data as any[] }
          : null;
        if (inline) {
          setClientPaged(true);
          setResultData(inline);
          setTotalRows(inline.rows.length);
          if (res?.truncated && (res?.total_rows ?? 0) > inline.rows.length) {
            setPageNotice(
              `Showing the first ${inline.rows.length.toLocaleString()} of ` +
              `${Number(res.total_rows).toLocaleString()} rows (row limit reached).`);
          }
        } else if (res?.execution_id) {
          setPageNotice(
            'The report ran, but its result rows could not be retrieved — ' +
            `execution ${String(res.execution_id).slice(0, 8)}. Try Execute again ` +
            'or check the execution history.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Execution failed');
    } finally {
      setExecuting(false);
    }
  }, [report.id, paramValues, rowsPerPage, sortCol, sortDir, loadPage]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep ref in sync for auto-execute
  handleExecuteRef.current = handleExecute;


  // 2026-10-24 -- ONE pager, above the table and below it (the owner: the
  // bottom-only pager is hard to find on a long page).
  const resultPager = (where: 'top' | 'bottom') => (
    <TablePagination
      component="div"
      data-testid={`report-pager-${where}`}
      count={totalRows}
      page={page}
      onPageChange={(_, newPage) => {
        setPage(newPage);
        if (!clientPaged && result?.execution_id) {
          loadPage(result.execution_id, newPage, rowsPerPage, sortCol, sortDir);
        }
      }}
      rowsPerPage={rowsPerPage}
      onRowsPerPageChange={(e) => {
        const newRpp = parseInt(e.target.value, 10);
        setRowsPerPage(newRpp);
        setPage(0);
        if (!clientPaged && result?.execution_id) {
          loadPage(result.execution_id, 0, newRpp, sortCol, sortDir);
        }
      }}
      rowsPerPageOptions={[25, 50, 100, 200]}
    />
  );

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate(REPORTS_PATH)}>
          Back
        </Button>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>{report.name}</Typography>
        <Chip label="Raw SQL" size="small" color="info" />
        {/* 2026-08-17: was ungated -- a consumer opening a published raw-SQL
            report saw an Edit button into the authoring surface.  Same gate
            the other two viewers use (owner / admin / own draft). */}
        {canEditReport(report, user) && (
          <Button size="small" startIcon={<EditIcon />}
            onClick={() => navigate(reportEditPath(report))}>
            Edit
          </Button>
        )}
        {canEditReport(report, user) && (
          <Button size="small" startIcon={<FactCheckIcon />}
            onClick={() => setReadinessOpen(true)} aria-label="readiness and SLO">
            Readiness &amp; SLO
          </Button>
        )}
        {canEditReport(report, user) && readinessOpen && (
          <ReportReadinessSloDialog open={readinessOpen} reportId={report.id}
            reportName={report.name} onClose={() => setReadinessOpen(false)}
            onSaved={() => setSloRefresh(n => n + 1)} />
        )}
        <Button variant="contained" startIcon={<PlayArrowIcon />}
          onClick={handleExecute} disabled={executing}>
          {executing ? 'Running...' : 'Execute'}
        </Button>
        <Button variant="outlined" size="small" startIcon={<GetAppIcon />}
          onClick={(e) => setExportAnchor(e.currentTarget)}
          disabled={!resultData}>Export</Button>
        <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
          onClose={() => setExportAnchor(null)}>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportExcel(report.id, paramValues, retainDays); } catch (e: any) { setError(e?.message || 'Excel export failed'); } }}>
            <ListItemIcon><TableViewIcon fontSize="small" /></ListItemIcon>
            <ListItemText>Excel (formatted)</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportPDF(report.id, paramValues, retainDays); } catch (e: any) { setError(e?.message || 'PDF export failed'); } }}>
            <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
            <ListItemText>PDF</ListItemText>
          </MenuItem>
          <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadBusinessReportCSV(report.id, paramValues, retainDays); } catch (e: any) { setError(e?.message || 'CSV export failed'); } }}>
            <ListItemIcon><GetAppIcon fontSize="small" /></ListItemIcon>
            <ListItemText>CSV (raw data)</ListItemText>
          </MenuItem>
          {retentionControl}
        </Menu>
      </Box>

      {report.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {report.description}
        </Typography>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {/* F-P3A-12: a run whose rows cannot be paged/retrieved explains
          itself instead of dead-ending under a rows-count summary card. */}
      {pageNotice && (
        <Alert severity={resultData ? 'info' : 'warning'} sx={{ mb: 2 }}
          onClose={() => setPageNotice('')}>{pageNotice}</Alert>
      )}

      {/* Parameter form */}
      {params.length > 0 && (
        <Paper sx={{ p: 2, mb: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>Parameters</Typography>
            {/* 2026-09-27 -- the person's own parameter bookmarks */}
            <ReportBookmarks reportId={report.id} paramValues={paramValues}
              onApply={vals => setParamValues(prev => ({ ...prev, ...vals }))} />
          </Box>
          <Grid container spacing={2}>
            {params.map((p: any) => (
              <Grid key={p.name} size={{ xs: 12, sm: 6, md: 4 }}>
                <TextField
                  label={p.label || p.name}
                  size="small"
                  fullWidth
                  type={p.type === 'number' ? 'number' : p.type === 'date' ? 'date' : 'text'}
                  value={paramValues[p.name] || ''}
                  onChange={e => setParamValues(prev => ({ ...prev, [p.name]: e.target.value }))}
                  required={p.required}
                  InputLabelProps={p.type === 'date' ? { shrink: true } : undefined}
                  helperText={p.description}
                />
              </Grid>
            ))}
          </Grid>
        </Paper>
      )}

      {/* Result summary */}
      {result && (
        <Paper sx={{ p: 2, mb: 2 }}>
          <Typography variant="subtitle2">Result</Typography>
          <Box sx={{ display: 'flex', gap: 3, mt: 1 }}>
            <Typography variant="body2">Rows: <strong>{result.total_rows ?? '-'}</strong></Typography>
            {/* 2026-09-26 -- a result served from a stored run has no duration
                (it printed "Duration: -s"); say where it came from instead. */}
            {result.served_from_instance ? (
              <Typography variant="body2">
                From the run at <strong>{result.as_of ? new Date(result.as_of).toLocaleString() : 'an earlier time'}</strong>
              </Typography>
            ) : typeof result.duration_seconds === 'number' ? (
              <Typography variant="body2">Duration: <strong>{result.duration_seconds}s</strong></Typography>
            ) : null}
            {result.execution_id && (
              <Typography variant="body2">Execution: <code>{result.execution_id.slice(0, 8)}</code></Typography>
            )}
            {/* 2026-09-27 -- which engine answered, and the scan disclosure */}
            <EngineChip engine={result.execution_engine} label={result.execution_engine_label} />
            <ScanDisclosureChip reportId={report.id} executionId={result.execution_id || null}
              envelope={result} />
            <EntitlementChip />
            {/* 2026-09-28 -- readiness of the business date, and the promise */}
            <ReadinessChip readiness={result.readiness} showUndeclared={canEditReport(report, user)} />
            <ReportSloChip reportId={report.id} businessDate={result.readiness?.business_date || null}
              refreshKey={`${result.execution_id || ''}:${sloRefresh}`} />
          </Box>
        </Paper>
      )}

      {/* Result data table with pagination */}
      {resultData && resultData.columns.length > 0 && (
        <Paper>
          {/* 2026-10-24 -- the same pager above the table as below it */}
          {resultPager('top')}
          <TableContainer sx={{ maxHeight: 500 }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  {resultData.columns.map(col => (
                    <TableCell key={col} sx={{ fontWeight: 'bold', whiteSpace: 'nowrap' }}>
                      <TableSortLabel
                        active={sortCol === col}
                        direction={sortCol === col ? sortDir : 'asc'}
                        onClick={() => {
                          const newDir = sortCol === col && sortDir === 'asc' ? 'desc' : 'asc';
                          setSortCol(col);
                          setSortDir(newDir);
                          if (clientPaged) {
                            // F-P3A-12: no server paging — sort what we hold.
                            setResultData(prev => prev ? {
                              ...prev,
                              rows: [...prev.rows].sort((a: any, b: any) => {
                                const av = a?.[col]; const bv = b?.[col];
                                if (av == null && bv == null) return 0;
                                if (av == null) return 1;
                                if (bv == null) return -1;
                                const cmp = typeof av === 'number' && typeof bv === 'number'
                                  ? av - bv
                                  : String(av).localeCompare(String(bv));
                                return newDir === 'asc' ? cmp : -cmp;
                              }),
                            } : prev);
                            setPage(0);
                          } else if (result?.execution_id) {
                            loadPage(result.execution_id, page, rowsPerPage, col, newDir);
                          }
                        }}
                      >
                        {col}
                      </TableSortLabel>
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {(clientPaged
                  ? resultData.rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  : resultData.rows
                ).map((row: any, ri: number) => (
                  <TableRow key={ri} hover>
                    {resultData.columns.map(col => {
                      const rs = formatRules.length ? evaluateRuleStyle(row[col], col, formatRules, cellCutoffs) : null;
                      return (
                        <TableCell key={col} data-rule-styled={rs?.matchedIndex !== undefined ? 'true' : undefined}
                          sx={{ whiteSpace: 'nowrap',
                                ...(rs?.backgroundColor ? { backgroundColor: rs.backgroundColor } : {}),
                                ...(rs?.color ? { color: rs.color } : {}),
                                ...(rs?.fontWeight ? { fontWeight: rs.fontWeight } : {}) }}>
                          {row[col] ?? ''}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          {resultPager('bottom')}
        </Paper>
      )}
    </Box>
  );
};

export default UnifiedReportViewer;
