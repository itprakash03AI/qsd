/**
 * Phase 56+111 — Unified Reports List Page
 *
 * Lists ALL report types (Tabular, Pivot, Saved Query) in one place.
 * Phase 111: consolidated from separate report pages.
 * Example cards with mini data preview — clicking opens the REAL seeded report
 * (auto-seeds if not yet created). No static preview dialogs.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Tooltip, CircularProgress,
  Alert, TextField, InputAdornment, Dialog, DialogTitle, DialogContent,
  DialogActions, Grid, Card, CardContent, CardActions, Divider, Skeleton, Stack,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  ContentCopy as DuplicateIcon,
  Search as SearchIcon,
  TableChart as TabularIcon,
  PivotTableChart as PivotIcon,
  Storage as QueryIcon,
  OpenInNew as OpenIcon,
  Assessment as AssessmentIcon,
  TrendingUp as TrendingUpIcon,
  Receipt as ReceiptIcon,
  AccountBalance as AccountBalanceIcon,
  AutoFixHigh as SeedIcon,
  PlayArrow as PlayArrowIcon,
  CheckCircle as CertifiedIcon,
  CloudUpload as PublishIcon,
  CloudOff as UnpublishIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  DriveFileRenameOutline as RenameIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { canAuthorReports, isAdminLike } from '../utils/reportLifecycle';
import { getLifecycleState, isEndpointMissing } from '../utils/reportLifecycle';
import { NEW_REPORT_PATH, reportEditPath, reportPath } from '../utils/reportUrls';
import RowActions, { RowAction } from './common/RowActions';

/* ── Example report showcase — uses real column names from project data ── */

const EXAMPLE_REPORTS = [
  {
    name: 'P&L by Trading Book',
    type: 'tabular' as const,
    description: 'Profit & Loss summary by Book_id and Master_book_id — USD and functional currency amounts with trade counts per desk.',
    icon: TrendingUpIcon,
    color: '#1976d2',
    preview: {
      headers: ['Book_id', 'Master_book_id', 'USD_CURRENCY_AMOUNT', 'GBP_AMOUNT', 'Trades'],
      rows: [
        ['EQ-DESK-01', 'MASTER-EQ', '$12,450,800', '\u00a38,920,100', '1,342'],
        ['FI-DESK-03', 'MASTER-FI', '$8,910,200', '\u00a36,380,500', '876'],
        ['FX-DESK-07', 'MASTER-FX', '-$2,340,500', '-\u00a31,675,200', '2,105'],
      ],
    },
  },
  {
    name: 'FX Exposure by Currency & Book',
    type: 'pivot' as const,
    description: 'Cross-tab of transactional_currency_id vs Book_id — shows USD_CURRENCY_AMOUNT exposure and FX rate impact across desks.',
    icon: AssessmentIcon,
    color: '#9c27b0',
    preview: {
      headers: ['Currency', 'EQ-DESK-01', 'FI-DESK-03', 'FX-DESK-07'],
      rows: [
        ['EUR', '$4.2M', '$2.8M', '-$1.1M'],
        ['GBP', '$3.1M', '$1.9M', '-$0.8M'],
        ['JPY', '$1.8M', '$0.6M', '$2.4M'],
      ],
    },
  },
  {
    name: 'GL Account Hierarchy Summary',
    type: 'tabular' as const,
    description: 'SAP account drill-down from sap_acc_level1 to sap_account with USD and FUNCTIONAL_CURRENCY_AMOUNT — cost centre and profit centre view.',
    icon: AccountBalanceIcon,
    color: '#1976d2',
    preview: {
      headers: ['sap_acc_level1', 'sap_acc_level2', 'sap_account', 'USD_AMT', 'Cost Centre'],
      rows: [
        ['Assets', 'Securities', '40010100', '$24.5M', 'CC-100'],
        ['Assets', 'Derivatives', '40020300', '$18.2M', 'CC-200'],
        ['Liabilities', 'Repo', '50010100', '-$12.8M', 'CC-100'],
      ],
    },
  },
  {
    name: 'Position by Instrument & SEDOL',
    type: 'pivot' as const,
    description: 'Investment positions grouped by sedol and instrument — pivot by system_entity showing USD_CURRENCY_AMOUNT and trade_id counts.',
    icon: AssessmentIcon,
    color: '#9c27b0',
    preview: {
      headers: ['sedol', 'instrument', 'Entity-UK', 'Entity-US'],
      rows: [
        ['B0WNLY7', 'HSBC Holdings', '$8.4M', '$12.1M'],
        ['B4T3BW2', 'Barclays PLC', '$5.2M', '$3.8M'],
        ['BH4HKS3', 'Shell PLC', '$14.6M', '$9.2M'],
      ],
    },
  },
  {
    name: 'Trade Reconciliation',
    type: 'saved_query' as const,
    description: 'Filter by trade_id, sedol, or Book_id to reconcile positions — shows sap_account, currency amounts, and FX rates.',
    icon: ReceiptIcon,
    color: '#0288d1',
    preview: {
      headers: ['trade_id', 'sedol', 'sap_account', 'USD_AMT', 'FX_Rate'],
      rows: [
        ['TRD-10042', 'B0WNLY7', '40010100', '$245,000', '1.2650'],
        ['TRD-10043', 'B4T3BW2', '40020300', '$890,500', '0.7890'],
        ['TRD-10044', 'BH4HKS3', '50010100', '$1,120,000', '1.0000'],
      ],
    },
  },
  {
    name: 'Desk P&L by Cost Centre',
    type: 'saved_query' as const,
    description: 'Parameterized P&L — filter by su (desk), MU (cost centre), and sap_acc_level1 to view USD and GBP amounts per profit centre.',
    icon: AccountBalanceIcon,
    color: '#0288d1',
    preview: {
      headers: ['su', 'MU', 'sap_acc_level1', 'USD_AMT', 'GBP_AMT'],
      rows: [
        ['Rates Desk', 'CC-Fixed Income', 'Trading P&L', '$4.2M', '\u00a33.0M'],
        ['Credit Desk', 'CC-Credit', 'Trading P&L', '-$1.8M', '-\u00a31.3M'],
        ['Equities', 'CC-Equities', 'Revaluation', '$6.5M', '\u00a34.6M'],
      ],
    },
  },
];

const TYPE_CONFIG = {
  tabular: { label: 'Tabular', color: 'primary' as const, icon: TabularIcon },
  pivot: { label: 'Pivot', color: 'secondary' as const, icon: PivotIcon },
  saved_query: { label: 'Saved Query', color: 'info' as const, icon: QueryIcon },
};

const SEED_KEY = 'qs-sample-reports-seeded';

/* ── Mini Data Preview ──────────────────────────────────────────────────── */

const MiniPreview: React.FC<{ preview: typeof EXAMPLE_REPORTS[0]['preview'] }> = ({ preview }) => (
  <Box sx={{
    mt: 1.5, borderRadius: 1, overflow: 'hidden', border: '1px solid',
    borderColor: 'divider', fontSize: '0.65rem', fontFamily: 'monospace',
  }}>
    <Box sx={{
      display: 'grid', gridTemplateColumns: `repeat(${preview.headers.length}, 1fr)`,
      bgcolor: 'grey.100', borderBottom: '1px solid', borderColor: 'divider',
    }}>
      {preview.headers.map(h => (
        <Box key={h} sx={{ px: 0.75, py: 0.5, fontWeight: 700, color: 'text.secondary', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {h}
        </Box>
      ))}
    </Box>
    {preview.rows.map((row, ri) => (
      <Box key={ri} sx={{
        display: 'grid', gridTemplateColumns: `repeat(${preview.headers.length}, 1fr)`,
        borderBottom: ri < preview.rows.length - 1 ? '1px solid' : 'none', borderColor: 'divider',
        '&:hover': { bgcolor: 'action.hover' },
      }}>
        {row.map((cell, ci) => (
          <Box key={ci} sx={{
            px: 0.75, py: 0.4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            color: cell === 'pending' ? 'warning.main' : (cell.startsWith('$') ? 'text.primary' : 'text.primary'),
            fontWeight: cell.startsWith('$') || cell.endsWith('%') ? 600 : 400,
          }}>
            {cell}
          </Box>
        ))}
      </Box>
    ))}
  </Box>
);


/* ── Main Component ─────────────────────────────────────────────────────── */

/**
 * Server page size (metadata-scale audit finding 3, 2026-08-09).  The page
 * used to fetch EVERY report and filter/render client-side — >800k DOM
 * nodes at 100k reports.  Now: server-side keyset pagination + debounced
 * server-side search (same 300 ms pattern as ReportCatalogPage) + a
 * virtualized table body (@tanstack/react-virtual, same padding-row spacer
 * pattern as DataGridViewer).
 */
const PAGE_SIZE = 100;

/** Accept both response shapes: the paginated envelope, and the legacy
 *  full array (older servers / test mocks). */
const normalizeListResponse = (data: any) => Array.isArray(data)
  ? { items: data, next_cursor: null as string | null, has_more: false }
  : {
      items: Array.isArray(data?.items) ? data.items : [],
      next_cursor: (data?.next_cursor ?? null) as string | null,
      has_more: !!data?.has_more,
    };

const ReportsListPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [seeding, setSeeding] = useState(false);
  const [seedMsg, setSeedMsg] = useState('');
  const [openingCard, setOpeningCard] = useState<string | null>(null);
  const tableContainerRef = useRef<HTMLDivElement | null>(null);
  // Monotonic request sequence — a slow first-page response must never
  // clobber the results of a newer search.
  const reqSeqRef = useRef(0);

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  // 2026-09-24: New Report and Duplicate CREATE a report -- an analyst/admin
  // act the API now enforces.  A viewer is not offered a button that 403s.
  const canAuthor = canAuthorReports(user);
  const username = user?.username || '';

  // 2026-09-18 — sample/demo reports are hidden by default (the server
  // does the filtering, inside the paginated query) so they cannot bury the
  // real ones.  The preference is per-browser; it is a view choice, not data.
  const [showSamples, setShowSamples] = useState<boolean>(() => {
    try { return localStorage.getItem('qs.reports.showSamples') === 'true'; }
    catch { return false; }
  });
  const toggleSamples = useCallback((next: boolean) => {
    setShowSamples(next);
    try { localStorage.setItem('qs.reports.showSamples', String(next)); }
    catch { /* private window — the toggle still works for this session */ }
  }, []);

  const loadReports = useCallback((q: string) => {
    const seq = ++reqSeqRef.current;
    setLoading(true);
    api.listBusinessReports({ limit: PAGE_SIZE, q: q || undefined,
                              include_samples: showSamples })
      .then((data: any) => {
        if (seq !== reqSeqRef.current) return;   // stale response
        const n = normalizeListResponse(data);
        setReports(n.items);
        setNextCursor(n.next_cursor);
        setHasMore(n.has_more);
      })
      .catch(() => { if (seq === reqSeqRef.current) setError('Failed to load reports'); })
      .finally(() => { if (seq === reqSeqRef.current) setLoading(false); });
  }, [showSamples]);

  // Debounced server-side search — 300 ms, the ReportCatalogPage precedent.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  // Initial load (debouncedSearch starts '') + reload on each search change.
  useEffect(() => { loadReports(debouncedSearch); }, [debouncedSearch, loadReports]);

  const loadMore = useCallback(() => {
    if (!nextCursor || loadingMore) return;
    const seq = reqSeqRef.current;   // page-walk belongs to the current query
    setLoadingMore(true);
    api.listBusinessReports({
      limit: PAGE_SIZE, cursor: nextCursor,
      q: debouncedSearch || undefined,
      include_samples: showSamples,
    })
      .then((data: any) => {
        if (seq !== reqSeqRef.current) return;   // query changed mid-flight
        const n = normalizeListResponse(data);
        setReports(prev => [...prev, ...n.items]);
        setNextCursor(n.next_cursor);
        setHasMore(n.has_more);
      })
      .catch(() => { if (seq === reqSeqRef.current) setError('Failed to load more reports'); })
      .finally(() => setLoadingMore(false));
  }, [nextCursor, loadingMore, debouncedSearch, showSamples]);

  // ── Virtualized table body — render only the visible window ──────────
  const rowVirtualizer = useVirtualizer({
    count: reports.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 53,   // MUI Table size="small", two-line name cell
    overscan: 20,
  });
  const virtualRows = rowVirtualizer.getVirtualItems();
  const totalVirtualHeight = rowVirtualizer.getTotalSize();
  // Unmeasurable viewport (container measures 0 — SSR, hidden-tab mount,
  // happy-dom tests): virtual-core sets its range to null and yields NO
  // rows, which would blank the table.  Fall back to rendering the loaded
  // rows directly, bounded so the DOM stays small either way.
  const unmeasured = virtualRows.length === 0 && reports.length > 0;
  const renderRows: Array<{ index: number }> = unmeasured
    ? reports.slice(0, 200).map((_r, i) => ({ index: i }))
    : virtualRows;
  const vPaddingTop = !unmeasured && virtualRows.length > 0 ? (virtualRows[0]?.start ?? 0) : 0;
  const vPaddingBottom = !unmeasured && virtualRows.length > 0
    ? totalVirtualHeight - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0;

  // Infinite scroll: when the window nears the end of loaded rows, fetch
  // the next page (the Load More button below stays as explicit fallback).
  useEffect(() => {
    const last = renderRows[renderRows.length - 1];
    if (last && hasMore && !loadingMore && last.index >= reports.length - 15) {
      loadMore();
    }
  }, [renderRows, hasMore, loadingMore, reports.length, loadMore]);

  // 2026-09-27 -- a report served by live published views is refused with a
  // 409 naming them; the dialog shows that and offers Delete anyway.  Any
  // other failure is shown with the server's reason, never a bare "failed".
  const [deleteBlocked, setDeleteBlocked] = useState<string | null>(null);
  const closeDelete = () => { setDeleteId(null); setDeleteBlocked(null); };
  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.deleteBusinessReport(deleteId, deleteBlocked !== null);
      setReports(prev => prev.filter(r => r.id !== deleteId));
    } catch (e: any) {
      if (e?.status === 409 && deleteBlocked === null) {
        setDeleteBlocked(String(e?.message || 'Published views serve this report.'));
        return;
      }
      setError(`Failed to delete report: ${e?.message || 'unknown error'}`);
    }
    closeDelete();
  };

  // 2026-10-23 -- the owner: "Report name edit not available".  The name was
  // editable only on step 6 of 6 of Edit; Rename is now one action on the row.
  const [renameTarget, setRenameTarget] = useState<any | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);
  const [renaming, setRenaming] = useState(false);
  const openRename = (r: any) => { setRenameTarget(r); setRenameValue(r.name || ''); setRenameError(null); };
  const closeRename = () => { if (!renaming) { setRenameTarget(null); setRenameError(null); } };
  const renameTrimmed = renameValue.trim();
  const handleRename = async () => {
    if (!renameTarget || !renameTrimmed || renameTrimmed === renameTarget.name) return;
    setRenaming(true);
    setRenameError(null);
    try {
      const saved = await api.updateBusinessReport(renameTarget.id, { name: renameTrimmed });
      const name = saved?.name ?? renameTrimmed;
      setReports(prev => prev.map(x => (x.id === renameTarget.id ? { ...x, name } : x)));
      setRenameTarget(null);
    } catch (e: any) {
      setRenameError(e?.message || 'The report could not be renamed.');
    } finally {
      setRenaming(false);
    }
  };

  const handleDuplicate = async (id: number) => {
    try {
      const dup = await api.duplicateBusinessReport(id);
      if (dup?.id) navigate(reportEditPath(dup));
    } catch { setError('Failed to duplicate report'); }
  };

  // ── Publish / unpublish from the list (2026-08-17) ───────────────────────
  // First reachable publish affordance in the product.  Unpublish prefers the
  // lifecycle endpoint and falls back to the legacy POST /publish TOGGLE when
  // the backend predates it (safe: only offered while currently published).
  const [lifecycleBusyId, setLifecycleBusyId] = useState<number | null>(null);
  const handleTogglePublish = async (r: any) => {
    setLifecycleBusyId(r.id);
    try {
      if (r.is_published) {
        try {
          await api.unpublishBusinessReport(r.id);
        } catch (e: any) {
          if (isEndpointMissing(e)) await api.publishBusinessReport(r.id, 'unpublish');
          else throw e;
        }
      } else {
        await api.publishBusinessReport(r.id);
      }
      // Re-fetch the single row — publish may have minted a version / state
      // the slim list projection doesn't carry.
      const fresh = await api.getBusinessReport(r.id);
      setReports(prev => prev.map(x => (x.id === r.id ? { ...x, ...fresh } : x)));
    } catch (e: any) {
      setError(e?.message || 'Failed to update publish state');
    } finally {
      setLifecycleBusyId(null);
    }
  };

  /* ── Seed actual sample reports via backend ──────────────────────────── */
  const handleSeedSamples = async () => {
    setSeeding(true);
    setSeedMsg('');
    try {
      const result = await api.seedSampleReports();
      if (result?.status === 'already_exists') {
        setSeedMsg(`Sample reports already exist (${result.reports?.length || 0} reports). Open them from the table above.`);
      } else if (result?.status === 'created') {
        localStorage.setItem(SEED_KEY, 'true');
        setSeedMsg(`Created ${result.reports?.length || 0} IB P&L sample reports with ${result.columns_created || 0} columns! Open any report to execute, export, or chart.`);
      } else {
        setSeedMsg('Sample reports created successfully!');
        localStorage.setItem(SEED_KEY, 'true');
      }
      loadReports(debouncedSearch);
    } catch {
      setSeedMsg('Failed to create sample reports. Please try again.');
    } finally {
      setSeeding(false);
    }
  };

  /* ── Open example card → find or seed real report, then navigate ────── */
  const handleOpenExample = async (exampleName: string) => {
    // Check if the real report already exists in loaded reports
    const match = reports.find(r => r.name === exampleName);
    if (match) {
      navigate(reportPath(match));
      return;
    }
    setOpeningCard(exampleName);
    // 2026-09-25 (Docker E2E crawl, as an analyst): the loaded list HIDES
    // samples unless "Show samples" is on, so an installed sample was "not
    // found" and the card fell through to SEEDING -- an admin endpoint -- and
    // an analyst got "Failed to create sample reports" for a report that
    // existed.  Ask the server, samples included, before seeding anything.
    try {
      const found: any = await api.listBusinessReports({ q: exampleName, include_samples: true, limit: 20 });
      const list: any[] = Array.isArray(found) ? found : (found?.items || []);
      const hit = list.find((r: any) => r.name === exampleName);
      if (hit) { setOpeningCard(null); navigate(reportPath(hit)); return; }
    } catch { /* fall through: seeding (admins) or an honest message */ }
    if (!isAdmin) {
      setOpeningCard(null);
      setSeedMsg('This sample report is not installed. An admin can install the samples.');
      return;
    }
    // Not installed — an admin seeds the sample reports, then navigates
    try {
      const result = await api.seedSampleReports();
      const seeded = result?.reports || [];
      localStorage.setItem(SEED_KEY, 'true');
      const target = seeded.find((r: any) => r.name === exampleName);
      if (target) {
        navigate(reportPath(target));
      } else if (seeded.length > 0) {
        // Name mismatch — navigate to the first seeded report
        navigate(reportPath(seeded[0]));
      } else {
        setSeedMsg('Sample reports created! Refresh to see them.');
        loadReports(debouncedSearch);
      }
    } catch {
      setSeedMsg('Failed to create sample reports. Please try again.');
    } finally {
      setOpeningCard(null);
    }
  };

  const alreadySeeded = localStorage.getItem(SEED_KEY) === 'true';

  if (loading) {
    return (
      <Box sx={{ p: 3 }}>
        <Skeleton variant="text" width={200} height={40} sx={{ mb: 2 }} />
        <Grid container spacing={2}>
          {[0, 1, 2, 3, 4, 5].map(i => (
            <Grid key={i} size={{ xs: 12, sm: 6, lg: 4 }}>
              <Skeleton variant="rectangular" height={220} sx={{ borderRadius: 2 }} />
            </Grid>
          ))}
        </Grid>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 600 }}>Reports</Typography>
        {(reports.length > 0 || search.trim() !== '') && (
          <TextField
            size="small" placeholder="Search reports..."
            value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
            sx={{ width: 250 }}
          />
        )}
        {canAuthor && (
        <Button variant="contained" startIcon={<AddIcon />}
          onClick={() => navigate(NEW_REPORT_PATH)}>
          New Report
        </Button>
        )}
        {/* 2026-10-26 -- the canvas builder: tiles on a page, Business Objects / Power BI style */}
        {canAuthor && (
        <Button variant="outlined" startIcon={<AddIcon />} data-testid="new-canvas-report"
          onClick={() => navigate('/finance-reports/new/canvas')}>
          New canvas report
        </Button>
        )}
        <Tooltip title={showSamples
          ? 'Hide seeded demo and sample reports'
          : 'Show seeded demo and sample reports'}>
          <Button
            variant={showSamples ? 'contained' : 'outlined'}
            color={showSamples ? 'secondary' : 'inherit'}
            startIcon={showSamples ? <VisibilityOffIcon /> : <VisibilityIcon />}
            onClick={() => toggleSamples(!showSamples)}
            // 2026-09-18 - the Tooltip's title becomes the button's ACCESSIBLE
            // NAME, replacing the visible label.  A screen reader then
            // announced "Show seeded demo and sample reports" for a button
            // that reads "Show samples", and voice control saying "click Show
            // samples" matched nothing (WCAG 2.5.3, Label in Name).  Naming it
            // explicitly keeps the visible text inside the accessible name.
            aria-label={showSamples ? 'Hide samples' : 'Show samples'}
          >
            {showSamples ? 'Hide samples' : 'Show samples'}
          </Button>
        </Tooltip>
        {/* seeding is an admin endpoint (2026-09-25: offered to an analyst,
            it answered 403 "Failed to create sample reports") */}
        {isAdminLike(user) && (
        <Button variant="outlined" startIcon={<SeedIcon />}
          onClick={handleSeedSamples} disabled={seeding}>
          {seeding ? 'Creating...' : 'Seed Samples'}
        </Button>
        )}
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {seedMsg && <Alert severity={seedMsg.includes('Created') ? 'success' : 'info'} sx={{ mb: 2 }} onClose={() => setSeedMsg('')}>{seedMsg}</Alert>}

      {/* Reports table — server-paginated + virtualized (audit finding 3).
          Shown whenever rows are loaded OR a search is active (a zero-hit
          search must keep the search box and show the empty message). */}
      {(reports.length > 0 || search.trim() !== '') && (
        <>
          {reports.length === 0 ? (
            <Paper sx={{ p: 4, textAlign: 'center', mb: 4 }}>
              <Typography color="text.secondary">No matching reports found.</Typography>
            </Paper>
          ) : (
            <TableContainer component={Paper} ref={tableContainerRef}
              sx={{ mb: 1, maxHeight: '64vh', overflow: 'auto' }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Owner</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Executions</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Last Executed</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Updated</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {/* Top spacer — keeps the scroll thumb honest (same
                      padding-row pattern as DataGridViewer) */}
                  {vPaddingTop > 0 && (
                    <TableRow><TableCell colSpan={8} sx={{ height: vPaddingTop, p: 0, border: 0 }} /></TableRow>
                  )}
                  {renderRows.map(virtualRow => {
                    const r = reports[virtualRow.index];
                    if (!r) return null;
                    return (
                    <TableRow key={r.id} hover sx={{ cursor: 'pointer' }}
                      onClick={() => navigate(reportPath(r))}>
                      <TableCell>
                        <Typography variant="body2" fontWeight="bold">{r.name}</Typography>
                        {r.description && (
                          <Typography variant="caption" color="text.secondary">{r.description.slice(0, 60)}</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {/* Slim list projection carries a derived
                            `report_type`; legacy full payloads carry
                            layout_config — support both. */}
                        <Chip size="small" variant="outlined"
                          label={
                            r.data_source_type === 'raw_sql' ? 'Saved Query' :
                            ((r.report_type ?? r.layout_config?.report_type) === 'pivot') ? 'Pivot' :
                            'Tabular'
                          }
                          color={
                            r.data_source_type === 'raw_sql' ? 'info' :
                            ((r.report_type ?? r.layout_config?.report_type) === 'pivot') ? 'secondary' :
                            'default'
                          }
                        />
                      </TableCell>
                      <TableCell>{r.owner}</TableCell>
                      <TableCell>
                        {/* Lifecycle-aware status (2026-08-17): archived /
                            deprecated surface here too, tolerant of the
                            boolean-only backend via getLifecycleState. */}
                        {(() => {
                          const st = getLifecycleState(r);
                          return st === 'published'
                            ? <Chip size="small" label="Published" color="success" />
                            : st === 'deprecated'
                              ? <Chip size="small" label="Deprecated" color="warning" />
                              : st === 'archived'
                                ? <Chip size="small" label="Archived" variant="outlined" />
                                : <Chip size="small" label="Draft" variant="outlined" />;
                        })()}
                        {/* Certified tier (2026-08-09): the org-vetted trust
                            signal, surfaced where users choose what to open. */}
                        {r.is_certified && (
                          <Tooltip title={
                            `Certified${r.certified_by ? ` by ${r.certified_by}` : ''} — reviewed and approved as a trusted, authoritative report.`}>
                            <Chip size="small" icon={<CertifiedIcon />} label="Certified"
                              color="success" variant="outlined" sx={{ ml: 0.5 }} />
                          </Tooltip>
                        )}
                      </TableCell>
                      <TableCell>{r.execution_count || 0}</TableCell>
                      <TableCell>
                        {r.last_executed_at ? new Date(r.last_executed_at).toLocaleString() : '-'}
                      </TableCell>
                      <TableCell>
                        {r.updated_at ? new Date(r.updated_at).toLocaleDateString() : '-'}
                      </TableCell>
                      <TableCell align="right" onClick={e => e.stopPropagation()}>
                        {(() => {
                          const mine = r.owner === username || isAdmin;
                          const more: RowAction[] = [];
                          if (mine) more.push({ label: 'Rename', icon: <RenameIcon fontSize="small" />,
                            description: 'Change the report name', onClick: () => openRename(r) });
                          if (mine) more.push({
                            label: r.is_published ? 'Unpublish' : 'Publish',
                            icon: lifecycleBusyId === r.id ? <CircularProgress size={16} />
                              : r.is_published ? <UnpublishIcon fontSize="small" /> : <PublishIcon fontSize="small" />,
                            description: r.is_published ? 'Remove from the consumer portal' : 'Make visible in the consumer portal',
                            disabled: lifecycleBusyId === r.id, onClick: () => handleTogglePublish(r) });
                          if (canAuthor) more.push({ label: 'Duplicate', icon: <DuplicateIcon fontSize="small" />,
                            description: 'Copy it as a new report', onClick: () => handleDuplicate(r.id) });
                          if (mine) more.push({ label: 'Delete', icon: <DeleteIcon fontSize="small" />, danger: true,
                            onClick: () => setDeleteId(r.id) });
                          const primary: RowAction[] = [
                            { label: 'Open', icon: <ViewIcon fontSize="small" />, onClick: () => navigate(reportPath(r)) }];
                          if (mine) primary.push({ label: 'Edit', icon: <EditIcon fontSize="small" />,
                            onClick: () => navigate(reportEditPath(r)) });
                          return <RowActions rowName={r.name} primary={primary} more={more} />;
                        })()}
                      </TableCell>
                    </TableRow>
                    );
                  })}
                  {/* Bottom spacer */}
                  {vPaddingBottom > 0 && (
                    <TableRow><TableCell colSpan={8} sx={{ height: vPaddingBottom, p: 0, border: 0 }} /></TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          {reports.length > 0 && (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, mb: 4 }}>
              <Typography variant="caption" color="text.secondary">
                {reports.length} report{reports.length === 1 ? '' : 's'} loaded{hasMore ? ' — scroll or load more' : ''}
              </Typography>
              {hasMore && (
                <Button size="small" variant="outlined" onClick={loadMore}
                  disabled={loadingMore}
                  startIcon={loadingMore ? <CircularProgress size={14} /> : undefined}>
                  {loadingMore ? 'Loading…' : 'Load more'}
                </Button>
              )}
            </Box>
          )}
        </>
      )}

      {/* Example report showcase -- 2026-10-25 (the owner: "seed reports should be
          hide or show, rather than just occupying space"): shown when there are no
          reports yet (a new user's starting point) or when "Show samples" is on;
          otherwise ONE line that opens it. */}
      {reports.length > 0 && !showSamples && (
        <Box sx={{ mt: 2 }} data-testid="samples-collapsed">
          <Button size="small" onClick={() => toggleSamples(true)} data-testid="samples-show">
            Show sample reports ({EXAMPLE_REPORTS.length})
          </Button>
        </Box>
      )}
      {(reports.length === 0 || showSamples) && (
      <Box data-testid="samples-section">
        {reports.length === 0 && search.trim() === '' && (
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <AssessmentIcon sx={{ fontSize: 48, color: 'primary.main', mb: 1 }} />
            <Typography variant="h5" fontWeight={600} gutterBottom>
              Enterprise P&L and Position Reporting
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 640, mx: 'auto', mb: 2 }}>
              Build tabular P&L summaries, pivot crosstabs by book and currency, or parameterized
              query reports for trade reconciliation and desk-level analysis.
              Click any report below to open it with full execute, export, and share capabilities.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              {canAuthor ? (
              <Button variant="contained" size="large" startIcon={<AddIcon />}
                onClick={() => navigate(NEW_REPORT_PATH)}>
                Create Report
              </Button>
              ) : (
                <Typography variant="body2" color="text.secondary" data-testid="reports-empty-consumer">
                  No reports have been shared with you yet. Ask a report owner or an admin for access.
                </Typography>
              )}
              {isAdmin && !alreadySeeded && (
                <Button variant="outlined" size="large" startIcon={<SeedIcon />}
                  onClick={handleSeedSamples} disabled={seeding}>
                  {seeding ? 'Creating...' : 'Create Sample Reports'}
                </Button>
              )}
            </Box>
          </Box>
        )}

        {reports.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Divider sx={{ mb: 2 }} />
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="subtitle1" fontWeight={600} color="text.secondary" sx={{ flex: 1 }}>
                IB P&L Sample Reports — click to open
              </Typography>
              <Button size="small" onClick={() => toggleSamples(false)} data-testid="samples-hide">Hide samples</Button>
            </Stack>
          </Box>
        )}

        <Grid container spacing={2.5}>
          {EXAMPLE_REPORTS.map((ex, idx) => {
            const tc = TYPE_CONFIG[ex.type];
            const Icon = ex.icon;
            const isOpening = openingCard === ex.name;
            const hasReal = reports.some(r => r.name === ex.name);
            return (
              <Grid key={idx} size={{ xs: 12, sm: 6, lg: 4 }}>
                <Card
                  variant="outlined"
                  sx={{
                    height: '100%', display: 'flex', flexDirection: 'column',
                    borderLeft: `4px solid ${ex.color}`,
                    transition: 'box-shadow 0.2s, transform 0.2s',
                    cursor: 'pointer',
                    '&:hover': {
                      boxShadow: 4,
                      transform: 'translateY(-2px)',
                    },
                  }}
                  onClick={() => !isOpening && handleOpenExample(ex.name)}
                >
                  <CardContent sx={{ flex: 1, pb: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Icon sx={{ fontSize: 22, color: ex.color }} />
                        <Typography variant="subtitle1" fontWeight={700} sx={{ lineHeight: 1.3 }}>
                          {ex.name}
                        </Typography>
                      </Box>
                      <Chip size="small" label={tc.label} color={tc.color} variant="outlined" sx={{ fontSize: '0.7rem', height: 22 }} />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem', mb: 0.5, lineHeight: 1.4 }}>
                      {ex.description}
                    </Typography>
                    <MiniPreview preview={ex.preview} />
                  </CardContent>
                  <CardActions sx={{ px: 2, pb: 1.5, pt: 0.5 }}>
                    <Button
                      size="small"
                      variant={hasReal ? 'contained' : 'outlined'}
                      startIcon={isOpening ? <CircularProgress size={14} /> : <OpenIcon sx={{ fontSize: 14 }} />}
                      sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                      disabled={isOpening}
                      onClick={(e) => { e.stopPropagation(); handleOpenExample(ex.name); }}
                    >
                      {isOpening ? 'Opening...' : hasReal ? 'Open Report' : 'Open Report'}
                    </Button>
                    <Chip
                      size="small" variant="outlined"
                      label={hasReal ? 'Ready' : 'Will auto-create'}
                      color={hasReal ? 'success' : 'default'}
                      sx={{ ml: 'auto', fontSize: '0.65rem', height: 20 }}
                    />
                  </CardActions>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Box>
      )}

      <Dialog open={renameTarget !== null} onClose={closeRename} fullWidth maxWidth="sm">
        <DialogTitle>Rename report</DialogTitle>
        <DialogContent>
          <TextField autoFocus fullWidth margin="dense" label="Report name" value={renameValue}
            inputProps={{ 'data-testid': 'rename-report-input', maxLength: 255 }}
            onChange={e => setRenameValue(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') handleRename(); }}
            helperText={renameTrimmed ? 'Links, published APIs and schedules keep working: they use the report id, not its name.'
              : 'A report needs a name.'}
            error={!renameTrimmed} />
          {renameError && (
            <Alert severity="error" sx={{ mt: 1 }} data-testid="rename-report-error">{renameError}</Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeRename} disabled={renaming}>Cancel</Button>
          <Button variant="contained" onClick={handleRename} data-testid="rename-report-save"
            disabled={renaming || !renameTrimmed || renameTrimmed === renameTarget?.name}>
            {renaming ? 'Saving…' : 'Rename'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteId !== null} onClose={closeDelete}>
        <DialogTitle>Delete Report</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to delete this report? This cannot be undone.</Typography>
          {deleteBlocked !== null && (
            <Alert severity="warning" sx={{ mt: 2 }} data-testid="delete-report-dependents">
              {deleteBlocked}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeDelete}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>
            {deleteBlocked !== null ? 'Delete anyway' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ReportsListPage;
