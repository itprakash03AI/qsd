import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, Accordion, AccordionSummary, AccordionDetails,
  Chip, Button, TextField, MenuItem, Select, FormControl, InputLabel,
  Table, TableHead, TableRow, TableCell, TableBody,
  Alert, Divider, Stack, Tooltip, IconButton, CircularProgress,
  ToggleButton, ToggleButtonGroup,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  ContentCopy as CopyIcon,
  PlayArrow as PlayIcon,
  Launch as LaunchIcon,
  CheckCircle as CheckIcon,
  Science as TestIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { safeFetch } from '../services/api';
import { resolveApiBaseUrl } from '../services/api/core';
import { useAuth } from '../context/AuthContext';
import { isAdminLike } from '../utils/reportLifecycle';
import { DynamicWhereOverrideField } from './common/DynamicWhereOverrideField';
import { WHERE_OPERATORS } from './common/WhereClausesEditor';

interface ParamDef {
  name: string;
  type: string;
  required: boolean;
  default: string;
  description: string;
}

interface PublishedView {
  id: number;
  slug: string;
  name: string;
  description: string | null;
  is_active: boolean;
  // 2026-08-23 (P6 audit D9) — for a NON-ADMIN, /api/published-views returns
  // views published by OTHERS as REDACTED catalog entries (management.py
  // _PV_CATALOG_FIELDS): id/slug/name/description/… only.  Every field below
  // may be absent and must be presence-guarded — `default_limit.toLocaleString()`
  // on a redacted row was a render crash for exactly the analyst/viewer roles
  // this route admits.
  allowed_filters?: string[];
  default_limit?: number;
  max_limit?: number;
  cache_ttl_seconds?: number;
  param_definitions?: ParamDef[];
  created_by?: string | null;
  created_at?: string | null;
  connection_id?: number | null;
  execution_connection_id?: number | null;
  query_config?: Record<string, any> | null;
  _redacted?: boolean;
  // 2026-10-17 -- the API lifecycle the list route derives (design §3.4):
  // a deprecated view wears a banner with its sunset and successor; a
  // retired one is hidden under "show retired".
  lifecycle?: { status?: string; sunset_at?: string | null; successor?: string | null; deprecation_note?: string | null } | null;
}

// Mirrors backend ``core.where_clause_mapping.col_key``: lowercase,
// strip quotes/brackets, drop any qualifier prefix.  Used to match
// allowed_filters against the publisher's _where_clauses_mapping rows
// regardless of how the column was originally written.
const colKey = (c: string): string =>
  (c || '')
    .replace(/[`"\[\]]/g, '')
    .split('.')
    .pop()!
    .toLowerCase();

interface PublisherWhereHint {
  operator: string;
  defaultValue: any;
  // True when the column matched a Dynamic _where_clauses_mapping row.
  isDynamic: boolean;
}

// Best-effort lookup of the publisher's Dynamic-row metadata for a
// given allowed_filters column.  Falls back to operator='eq' / no
// default when the PV has no _where_clauses_mapping (legacy / not all
// PVs carry it).
const getPublisherHint = (
  qc: Record<string, any> | null | undefined,
  column: string,
): PublisherWhereHint => {
  const mapping: any[] = Array.isArray(qc?._where_clauses_mapping)
    ? qc!._where_clauses_mapping
    : [];
  const target = colKey(column);
  for (const row of mapping) {
    if (!row || typeof row !== 'object') continue;
    if (colKey(row.column || '') !== target) continue;
    if ((row.mode || 'static') !== 'dynamic') continue;
    return {
      operator: (row.operator || 'eq').toLowerCase(),
      defaultValue: row.value,
      isDynamic: true,
    };
  }
  return { operator: 'eq', defaultValue: undefined, isDynamic: false };
};

// Pull a usable table hint out of the PV's frozen query_config so the
// distinct-values lookup has somewhere to aim.  Mirrors the chain
// PublishedViewsPage's test dialog uses (files[__registered__:…] →
// raw_sql FROM-clause regex).  Returns null when nothing usable.
const extractTableHint = (qc: Record<string, any> | null | undefined): string | null => {
  if (!qc) return null;
  const files: any[] = Array.isArray(qc.files) ? qc.files : [];
  for (const f of files) {
    const p = typeof f === 'string' ? f : (f?.path || '');
    if (typeof p !== 'string') continue;
    if (p.startsWith('__registered__:')) return p.slice(15);
    if (p.startsWith('__iceberg__:')) return p.slice(12);
  }
  const sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
    .filter((s: any) => typeof s === 'string' && s.trim())
    .join('\n');
  const m = sqlBlob.match(/\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i);
  if (m) return m[1].replace(/[\s"`\[\]]/g, '');
  return null;
};

interface ApiKey {
  id: number;
  name: string;
  key_prefix: string;
  scoped_view_ids: number[] | null;
  is_active: boolean;
}

const CODE_BG = '#1e1e1e';
const CODE_COLOR = '#d4d4d4';

type CodeLang = 'curl' | 'python' | 'csharp' | 'javascript';

// Emit a language-safe double-quoted string literal.  JSON string
// escaping is valid for Python, JavaScript and C# regular strings, so
// this keeps the URL / key from ever breaking out of its quotes
// regardless of embedded quotes/backslashes.
const strLit = (s: string): string => JSON.stringify(s);

// Extract the row array from an API response regardless of shape.
const extractRows = (result: any): any[] => {
  if (!result) return [];
  if (Array.isArray(result.rows)) return result.rows;
  if (Array.isArray(result.data)) return result.data;
  return [];
};

// Derive the column order for the grid.  Honour an explicit
// ``columns`` list from the API (array of strings OR objects with a
// ``name``/``key``); otherwise take the union of keys across the first
// N rows, preserving first-seen order.
const deriveColumns = (rows: any[], explicit: any): string[] => {
  if (Array.isArray(explicit) && explicit.length > 0) {
    return explicit
      .map(c =>
        typeof c === 'string'
          ? c
          : (c?.name ?? c?.key ?? c?.field ?? String(c)),
      )
      .filter((c: any): c is string => typeof c === 'string' && c.length > 0);
  }
  const seen = new Set<string>();
  const cols: string[] = [];
  for (const r of rows.slice(0, 50)) {
    if (r && typeof r === 'object' && !Array.isArray(r)) {
      for (const k of Object.keys(r)) {
        if (!seen.has(k)) {
          seen.add(k);
          cols.push(k);
        }
      }
    }
  }
  return cols;
};

// Render a cell value readably: objects/arrays as compact JSON, null /
// undefined as a marker the caller styles muted.
const NULL_MARKER = '—'; // em-dash
const formatCell = (v: any): string => {
  if (v === null || v === undefined) return NULL_MARKER;
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
};

// True when the response is a real row set we can put in a grid.
const isTabular = (result: any): boolean => {
  const rows = extractRows(result);
  return (
    rows.length > 0 &&
    rows[0] != null &&
    typeof rows[0] === 'object' &&
    !Array.isArray(rows[0])
  );
};

const ApiExplorerPage = () => {
  // 2026-09-24 -- GET /api/api-keys is ``require_admin``; it only feeds the
  // "API key for curl examples" dropdown.  The walk saw analysts ask and get
  // a 403.  Only an admin can use that list, so only an admin asks for it.
  const { user } = useAuth();
  const canListKeys = isAdminLike(user);
  const [allViews, setAllViews] = useState<PublishedView[]>([]);
  const [showRetired, setShowRetired] = useState(false);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  // active views, plus the retired ones when asked for (they answer 410 Gone
  // with the successor -- a consumer debugging an old integration wants to see them)
  const views = allViews.filter(x => x.is_active || (showRetired && x.lifecycle?.status === 'retired'));
  const retiredCount = allViews.filter(x => !x.is_active && x.lifecycle?.status === 'retired').length;

  const [selectedKeyId, setSelectedKeyId] = useState<number | 'custom'>('custom');
  const [customKey, setCustomKey] = useState('YOUR_API_KEY');
  const [expanded, setExpanded] = useState<number | false>(false);

  // Per-view test state
  const [testingView, setTestingView] = useState<number | null>(null);
  const [testParams, setTestParams] = useState<Record<string, string>>({});
  // Filter VALUE only (no leading "op:" prefix any more — the operator
  // lives in testOps so we can render a dedicated picker and let the
  // value field be a real Autocomplete).
  const [testFilters, setTestFilters] = useState<Record<string, string>>({});
  const [testOps, setTestOps] = useState<Record<string, string>>({});
  const [testFormat, setTestFormat] = useState('json');
  const [testLimit, setTestLimit] = useState('100');
  const [testResult, setTestResult] = useState<any>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [testError, setTestError] = useState('');
  // 2026-10-24 -- "try as this consumer": a chosen key's short-lived try-as
  // token (POST /api/api-keys/{id}/try-as-token, admin) -- the REAL endpoint
  // then answers as that key (scope, row security, refusals).  Cached per key
  // until shortly before it expires.
  const tryAsRef = React.useRef<Record<number, { token: string; exp: number }>>({});
  const [ranAs, setRanAs] = useState<string>('');
  const [copied, setCopied] = useState<string | null>(null);
  // Result rendering: proper data grid vs raw JSON.
  const [resultView, setResultView] = useState<'grid' | 'json'>('grid');
  // Integration code-gen language switcher.
  const [codeLang, setCodeLang] = useState<CodeLang>('curl');

  useEffect(() => {
    // 2026-08-23 (P6 audit D7) — load INDEPENDENTLY.  This route admits
    // admin+analyst+viewer, but GET /api/api-keys is admin-only: coupling the
    // two in one Promise.all meant a non-admin's 403 on the keys call killed
    // the WHOLE page ("No active published views" — a lie) even though the
    // views list had loaded fine.  Keys are optional decoration for the
    // curl-example dropdown; only a views failure is a page failure.
    api.listPublishedViews()
      .then(v => setAllViews(Array.isArray(v) ? v : []))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
    if (!canListKeys) return;  // 2026-09-24: non-admin never asks; dropdown stays empty
    api.listApiKeys()
      .then(k => setApiKeys(Array.isArray(k) ? k.filter((x: any) => x.is_active) : []))
      .catch(() => setApiKeys([]));
  }, [canListKeys]);

  const displayKey =
    selectedKeyId === 'custom'
      ? customKey
      : `${apiKeys.find(k => k.id === selectedKeyId)?.key_prefix ?? 'qs'}...`;

  const buildQs = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    // Phase 132.36 — emit bare-form ?name=value where possible.  Only
    // fall back to bracketed ?param[name]=value / ?filter[name]=op:val
    // for reserved-name collisions.
    const RESERVED = new Set([
      'limit', 'offset', 'sort', 'columns', 'format', 'cache',
      'snapshot_id', 'as_of_timestamp', 'engine', 'filter',
    ]);
    const qp = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (!v) return;
      const key = RESERVED.has(k) ? `param[${k}]` : k;
      qp.set(key, v);
    });
    Object.entries(filters).forEach(([k, v]) => {
      const op = (ops[k] || 'eq').toLowerCase();
      const opSpec = WHERE_OPERATORS.find(o => o.value === op);
      // Use the BARE LEAF column name in the URL.  allowed_filters may store a
      // QUALIFIED spelling ("trades.business_close_date"), but the backend
      // filter-key parsers only accept ^filter\.(\w+)$ / bare \w+ (no dots) —
      // emitting the qualified key produced ?filter.trades.business_close_date
      // which the backend silently dropped.  The leaf matches allowed_filters
      // via the backend's _col_key normalisation (table-prefix-stripped).
      const leaf = k.includes('.') ? (k.split('.').pop() || k) : k;
      // is_null / is_not_null — emit op without value.
      if (opSpec && !opSpec.takesValue) {
        qp.set(`filter.${leaf}`, op);
        return;
      }
      if (!v || !v.trim()) return;
      // Default operator with simple scalar — bare form is friendlier
      // (?region=APAC).  Anything else routes via filter.col=op:val so
      // the backend's bare-form parser can't misread it.
      //
      // Dynamic _where_clauses_mapping columns route via the explicit
      // filter.col=eq:value form: it binds as a filter (never ceded to the
      // param parser), so the consumer's value reaches the dynamic WHERE
      // instead of the publisher's frozen default.
      const isDynamicMapped = getPublisherHint(view.query_config, k).isDynamic;
      if (op === 'eq' && !RESERVED.has(leaf) && !isDynamicMapped) {
        qp.set(leaf, v.trim());
      } else {
        qp.set(`filter.${leaf}`, `${op}:${v.trim()}`);
      }
    });
    if (format !== 'json') qp.set('format', format);
    if (limit && limit !== String(view.default_limit)) qp.set('limit', limit);
    return qp.toString();
  };

  const buildUrl = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    const origin = resolveApiBaseUrl() || window.location.origin;
    const base = `${origin}/api/v1/views/${view.slug}/data`;
    const qs = buildQs(view, params, filters, ops, format, limit);
    return qs ? `${base}?${qs}` : base;
  };

  const buildCurl = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) =>
    // --http1.1: force HTTP/1.1 (some corp proxies/LBs mishandle HTTP/2).
    // --ssl-no-revoke: skip cert-revocation check on Windows/Schannel behind a
    // corporate CA (the flags operators otherwise have to add by hand).
    `curl --http1.1 --ssl-no-revoke -H "X-API-Key: ${displayKey}" \\\n  "${buildUrl(view, params, filters, ops, format, limit)}"`;

  // ----- Integration code generators -----------------------------------
  // All four consume the SAME final URL that buildUrl produces (already
  // URL-encoded) plus the pasted / placeholder API key (displayKey).
  const usingPlaceholderKey = displayKey === 'YOUR_API_KEY';

  const buildPython = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    const url = buildUrl(view, params, filters, ops, format, limit);
    const note = usingPlaceholderKey ? '  # replace with your API key' : '';
    return `import requests

url = ${strLit(url)}
headers = {"X-API-Key": ${strLit(displayKey)}}${note}

resp = requests.get(url, headers=headers)
resp.raise_for_status()
data = resp.json()

rows = data.get("rows") or data.get("data") or []
print(f"{len(rows)} rows")
for row in rows[:10]:
    print(row)`;
  };

  const buildCsharp = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    const url = buildUrl(view, params, filters, ops, format, limit);
    const note = usingPlaceholderKey ? ' // replace with your API key' : '';
    return `using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

public class QueryStudioClient
{
    public static async Task Main()
    {
        using var client = new HttpClient();
        client.DefaultRequestHeaders.Add("X-API-Key", ${strLit(displayKey)});${note}

        var url = ${strLit(url)};
        var resp = await client.GetAsync(url);
        resp.EnsureSuccessStatusCode();

        var json = await resp.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        JsonElement rows;
        if (!root.TryGetProperty("rows", out rows))
            root.TryGetProperty("data", out rows);

        Console.WriteLine($"{(rows.ValueKind == JsonValueKind.Array ? rows.GetArrayLength() : 0)} rows");
        Console.WriteLine(json);
    }
}`;
  };

  const buildJavaScript = (
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ) => {
    const url = buildUrl(view, params, filters, ops, format, limit);
    const note = usingPlaceholderKey ? ' // replace with your API key' : '';
    // Note: inner back-ticks are escaped so this template literal emits
    // valid JS template literals in the generated snippet.
    return `const url = ${strLit(url)};

fetch(url, {
  headers: { "X-API-Key": ${strLit(displayKey)} },${note}
})
  .then((res) => {
    if (!res.ok) throw new Error(\`HTTP \${res.status} \${res.statusText}\`);
    return res.json();
  })
  .then((data) => {
    const rows = data.rows ?? data.data ?? [];
    console.log(\`\${rows.length} rows\`);
    console.table(rows.slice(0, 10));
  })
  .catch((err) => console.error(err));`;
  };

  const buildSnippet = (
    lang: CodeLang,
    view: PublishedView,
    params: Record<string, string>,
    filters: Record<string, string>,
    ops: Record<string, string>,
    format: string,
    limit: string,
  ): string => {
    switch (lang) {
      case 'python':
        return buildPython(view, params, filters, ops, format, limit);
      case 'csharp':
        return buildCsharp(view, params, filters, ops, format, limit);
      case 'javascript':
        return buildJavaScript(view, params, filters, ops, format, limit);
      case 'curl':
      default:
        return buildCurl(view, params, filters, ops, format, limit);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 1500);
    });
  };

  const [openApiError, setOpenApiError] = useState<{ slug: string; message: string } | null>(null);
  const downloadOpenApi = async (slug: string) => {
    setOpenApiError(null);
    try {
      const doc = await safeFetch(`/api/v1/views/${slug}/openapi.json`);
      const blob = new Blob([JSON.stringify(doc, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${slug}.openapi.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      setOpenApiError({ slug, message: `The OpenAPI document could not be downloaded: ${e?.message || 'unknown error'}` });
    }
  };

  const handleTest = async (view: PublishedView) => {
    setTestLoading(true);
    setTestError('');
    setTestResult(null);
    setRanAs('');
    try {
      const qs = buildQs(view, testParams, testFilters, testOps, testFormat, testLimit);
      const path = `/api/v1/views/${view.slug}/data${qs ? `?${qs}` : ''}`;

      // If the user pasted a custom key, use it as X-API-Key (bypass session auth).
      // This lets them verify their key works end-to-end before sharing it.
      // Otherwise fall back to session auth via safeFetch.
      const hasCustomKey =
        selectedKeyId === 'custom' &&
        customKey &&
        customKey !== 'YOUR_API_KEY' &&
        customKey.trim().length > 8;
      const chosenKey = typeof selectedKeyId === 'number'
        ? apiKeys.find(k => k.id === selectedKeyId) : undefined;

      if (hasCustomKey || chosenKey) {
        let credential: Record<string, string>;
        if (chosenKey) {
          const now = Date.now() / 1000;
          let cached = tryAsRef.current[chosenKey.id];
          if (!cached || cached.exp - now < 30) {
            const minted: any = await safeFetch(`/api/api-keys/${chosenKey.id}/try-as-token`, { method: 'POST' })
              .catch((e: any) => {
                throw new Error(/403/.test(String(e?.message)) || /admin/i.test(String(e?.message))
                  ? 'Only an admin can try an API as one of its consumers -- paste a key you hold instead.'
                  : (e?.message || 'Could not get a try-as token'));
              });
            cached = { token: minted.token, exp: minted.expires_at };
            tryAsRef.current[chosenKey.id] = cached;
          }
          credential = { 'X-QS-Try-As': cached.token };
          setRanAs(`as consumer ${chosenKey.name} (${chosenKey.key_prefix}…)`);
        } else {
          credential = { 'X-API-Key': customKey.trim() };
          setRanAs('with the pasted key');
        }
        const fullUrl = `${resolveApiBaseUrl()}${path}`;
        const resp = await fetch(fullUrl, {
          method: 'GET',
          headers: {
            'Accept': testFormat === 'json' ? 'application/json' : '*/*',
            ...credential,
          },
        });
        if (!resp.ok) {
          let detail = '';
          try { detail = (await resp.json()).detail ?? ''; } catch { detail = await resp.text(); }
          throw new Error(`HTTP ${resp.status} ${resp.statusText}${detail ? ' — ' + detail : ''}`);
        }
        if (testFormat === 'json') {
          setTestResult(await resp.json());
        } else {
          const blob = await resp.blob();
          setTestResult({
            _format: testFormat,
            _size_bytes: blob.size,
            _content_type: resp.headers.get('content-type'),
            _note: `${testFormat.toUpperCase()} blob received — download via curl or client SDK for full content.`,
          });
        }
      } else {
        setRanAs('as you (your own session)');
        const result = await safeFetch(path);
        setTestResult(result);
      }
    } catch (e: any) {
      setTestError(e.message || 'Request failed');
    } finally {
      setTestLoading(false);
    }
  };

  if (loading) return <Box p={4}><CircularProgress /></Box>;

  return (
    <Box p={3} maxWidth={1400}>
      {/* Header */}
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={3}>
        <Box>
          <Typography variant="h5" fontWeight={600}>API Explorer</Typography>
          <Typography variant="body2" color="text.secondary">
            Browse and test published data endpoints. All endpoints accept API key or AD session auth.
          </Typography>
        </Box>
        <Button
          variant="outlined"
          size="small"
          startIcon={<LaunchIcon />}
          onClick={() => window.open('/docs', '_blank')}
        >
          Full API Docs (Swagger)
        </Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Auth guide */}
      <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
        <Typography variant="subtitle2" fontWeight={600} gutterBottom>Authentication</Typography>
        <Typography variant="body2" color="text.secondary" mb={1.5}>
          <strong>Pick a consumer's key</strong> (admins) and every Send runs <strong>as that consumer</strong> --
          its scope, row security and refusals, exactly what it would get (a short-lived try-as token; the
          key itself never leaves the server).  Or paste a key you hold to test it end to end.  Get keys from the{' '}
          <a href="/api-keys" style={{ color: 'inherit', textDecoration: 'underline' }}>API Keys page</a>.
          With neither, Send runs as you (your own login session) -- view access then follows your own
          groups, not a key's scope.
        </Typography>

        <Box
          component="pre"
          sx={{
            bgcolor: CODE_BG, color: CODE_COLOR, px: 2, py: 1.5, borderRadius: 1,
            fontFamily: 'monospace', fontSize: '0.8rem', mb: 1.5, overflowX: 'auto', m: 0,
          }}
        >
          {`GET ${resolveApiBaseUrl() || window.location.origin}/api/v1/views/{slug}/data\nX-API-Key: qs_xxxxxxxxxxxxxxxx`}
        </Box>

        <Stack direction="row" spacing={2} alignItems="center" mt={1.5} flexWrap="wrap">
          <FormControl size="small" sx={{ minWidth: 220 }}>
            <InputLabel id="sel-apiexplorerpage-api-key-for-curl-examples">API key for curl examples</InputLabel>
            <Select labelId="sel-apiexplorerpage-api-key-for-curl-examples"
              value={selectedKeyId}
              label="API key for curl examples"
              onChange={e => setSelectedKeyId(e.target.value as any)}
            >
              <MenuItem value="custom">Custom / paste key</MenuItem>
              {apiKeys.map(k => (
                <MenuItem key={k.id} value={k.id}>{k.name} ({k.key_prefix}…)</MenuItem>
              ))}
            </Select>
          </FormControl>
          {selectedKeyId === 'custom' && (
            <TextField
              size="small"
              label="API Key"
              value={customKey}
              onChange={e => setCustomKey(e.target.value)}
              sx={{ minWidth: 280 }}
              InputProps={{ style: { fontFamily: 'monospace' } }}
            />
          )}
        </Stack>
      </Paper>

      {/* Endpoints list */}
      {retiredCount > 0 && (
        <Stack direction="row" justifyContent="flex-end" mb={1}>
          <Button size="small" variant={showRetired ? 'contained' : 'outlined'} onClick={() => setShowRetired(s => !s)}
                  data-testid="explorer-show-retired">
            {showRetired ? 'Hide' : 'Show'} retired ({retiredCount})
          </Button>
        </Stack>
      )}
      {views.length === 0 ? (
        <Alert severity="info">
          No active published views.{' '}
          <a href="/published-views" style={{ color: 'inherit' }}>Create one</a> to expose data via the API.
        </Alert>
      ) : (
        <>
          <Typography variant="body2" color="text.secondary" mb={1}>
            {views.length} {showRetired ? '' : 'active '}endpoint{views.length !== 1 ? 's' : ''}
          </Typography>
          {views.map(view => {
            const defaultParams = Object.fromEntries(
              (view.param_definitions || []).map(p => [p.name, p.default || ''])
            );
            const isOpen = expanded === view.id;
            const isTesting = testingView === view.id;
            // Redacted rows have no default_limit — '' keeps the example URL
            // clean (buildQs drops a falsy limit) instead of "limit=undefined".
            const exampleCurl = buildCurl(view, defaultParams, {}, {}, 'json',
              view.default_limit != null ? String(view.default_limit) : '');

            return (
              <Accordion
                key={view.id}
                expanded={isOpen}
                onChange={(_, open) => setExpanded(open ? view.id : false)}
                variant="outlined"
                sx={{ mb: 1, '&:before': { display: 'none' } }}
              >
                <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ py: 0.5 }}>
                  <Stack direction="row" alignItems="center" spacing={1.5} flexWrap="wrap">
                    <Chip
                      label="GET"
                      size="small"
                      color="success"
                      sx={{ fontWeight: 700, fontFamily: 'monospace', minWidth: 44 }}
                    />
                    <Typography variant="body2" fontFamily="monospace" sx={{ wordBreak: 'break-all' }}>
                      /api/v1/views/<strong>{view.slug}</strong>/data
                    </Typography>
                    <Typography variant="body2" color="text.secondary">— {view.name}</Typography>
                    {(view.param_definitions?.length ?? 0) > 0 && (
                      <Chip label={`${view.param_definitions!.length} params`} size="small" variant="outlined" />
                    )}
                    {(view.allowed_filters?.length ?? 0) > 0 && (
                      <Chip label={`${view.allowed_filters!.length} filters`} size="small" variant="outlined" />
                    )}
                  </Stack>
                </AccordionSummary>

                <AccordionDetails sx={{ pt: 0 }}>
                  <Divider sx={{ mb: 2 }} />

                  {/* 2026-10-17 -- the lifecycle banner (design §3.4): what the
                      Deprecation / Sunset / Link headers say, in words */}
                  {view.lifecycle?.status === 'deprecated' && (
                    <Alert severity="warning" sx={{ mb: 2 }} data-testid="explorer-deprecated">
                      Deprecated
                      {view.lifecycle.sunset_at ? ` — stops answering on ${new Date(view.lifecycle.sunset_at).toLocaleString()}` : ''}
                      {view.lifecycle.successor ? <> — use <code>/api/v1/views/{view.lifecycle.successor}/data</code> instead</> : ''}
                      {view.lifecycle.deprecation_note ? ` — ${view.lifecycle.deprecation_note}` : ''}
                    </Alert>
                  )}
                  {view.lifecycle?.status === 'retired' && (
                    <Alert severity="error" sx={{ mb: 2 }} data-testid="explorer-retired">
                      Retired — answers 410 Gone
                      {view.lifecycle.successor ? <>; use <code>/api/v1/views/{view.lifecycle.successor}/data</code></> : ''}
                      {view.lifecycle.deprecation_note ? ` — ${view.lifecycle.deprecation_note}` : ''}
                    </Alert>
                  )}

                  {view.description && (
                    <Typography variant="body2" color="text.secondary" mb={2}>{view.description}</Typography>
                  )}

                  {/* Meta chips — presence-guarded (P6 D9): redacted catalog
                      entries carry none of these numbers, and an ABSENT value
                      must render as nothing, never as "unlimited"/"undefined". */}
                  <Stack direction="row" spacing={1} mb={2} flexWrap="wrap">
                    {typeof view.default_limit === 'number' && (
                      <Chip label={`Default limit: ${view.default_limit.toLocaleString()}`} size="small" />
                    )}
                    {/* 2026-08-20 -- max_limit === 0 is UNLIMITED (product-wide 0-means-unlimited rule), */}
                    {/* not "zero rows".  This rendered "Max: 0", which reads as a broken view. */}
                    {typeof view.max_limit === 'number' && (
                      <Chip label={view.max_limit > 0 ? `Max: ${view.max_limit.toLocaleString()}` : "Max: unlimited"} size="small" />
                    )}
                    {typeof view.cache_ttl_seconds === 'number' && (
                      <Chip label={`Cache: ${view.cache_ttl_seconds}s`} size="small" />
                    )}
                    <Chip label="Formats: json · csv · parquet" size="small" />
                  </Stack>

                  {/* Runtime parameters */}
                  {(view.param_definitions?.length ?? 0) > 0 && (
                    <Box mb={2}>
                      <Typography variant="subtitle2" gutterBottom>Runtime Parameters</Typography>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ '& th': { fontWeight: 600 } }}>
                            <TableCell>Name</TableCell>
                            <TableCell>Type</TableCell>
                            <TableCell>Required</TableCell>
                            <TableCell>Default</TableCell>
                            <TableCell>Description</TableCell>
                            <TableCell>Query string key</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {view.param_definitions!.map(p => (
                            <TableRow key={p.name}>
                              <TableCell><code>{p.name}</code></TableCell>
                              <TableCell><Chip label={p.type || 'string'} size="small" /></TableCell>
                              <TableCell>{p.required ? '✓' : '—'}</TableCell>
                              <TableCell><code>{p.default || '—'}</code></TableCell>
                              <TableCell sx={{ color: 'text.secondary', fontSize: '0.8rem' }}>
                                {p.description || '—'}
                              </TableCell>
                              <TableCell>
                                {/* Phase 132.36 — bare-form preferred. */}
                                <code style={{ fontSize: '0.75rem' }}>{p.name}</code>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </Box>
                  )}

                  {/* Allowed filters */}
                  {(view.allowed_filters?.length ?? 0) > 0 && (
                    <Box mb={2}>
                      <Typography variant="subtitle2" gutterBottom>Allowed Filters</Typography>
                      <Typography variant="body2" color="text.secondary" mb={1}>
                        Bare form (simple): <code>?column=value</code> or
                        {' '}<code>?column=('A','B')</code> for IN.
                        <br />Explicit form (operators):
                        {' '}<code>?filter.column=operator:value</code> —
                        <code>eq</code>, <code>ne</code>, <code>gt</code>,{' '}
                        <code>gte</code>, <code>lt</code>, <code>lte</code>,{' '}
                        <code>in</code>, <code>not_in</code>,{' '}
                        <code>contains</code>, <code>between</code>.
                      </Typography>
                      <Stack direction="row" spacing={1} flexWrap="wrap">
                        {(view.allowed_filters || []).map(f => (
                          <Chip key={f} label={f} size="small" sx={{ fontFamily: 'monospace' }} />
                        ))}
                      </Stack>
                    </Box>
                  )}

                  {/* Curl example */}
                  <Box mb={2}>
                    <Stack direction="row" alignItems="center" spacing={1} mb={0.5}>
                      <Typography variant="subtitle2">Example Request</Typography>
                      <Tooltip title={copied === `curl-${view.id}` ? 'Copied!' : 'Copy'}>
                        <IconButton size="small" onClick={() => handleCopy(exampleCurl, `curl-${view.id}`)}>
                          {copied === `curl-${view.id}`
                            ? <CheckIcon fontSize="small" color="success" />
                            : <CopyIcon fontSize="small" />}
                        </IconButton>
                      </Tooltip>
                    </Stack>
                    <Box
                      component="pre"
                      sx={{
                        bgcolor: CODE_BG, color: CODE_COLOR, p: 2, borderRadius: 1,
                        fontFamily: 'monospace', fontSize: '0.8rem',
                        overflowX: 'auto', m: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                      }}
                    >
                      {exampleCurl}
                    </Box>
                  </Box>

                  {/* Try it button */}
                  <Button
                    variant={isTesting ? 'outlined' : 'contained'}
                    size="small"
                    startIcon={<TestIcon />}
                    onClick={() => {
                      if (isTesting) {
                        setTestingView(null);
                      } else {
                        setTestingView(view.id);
                        setTestParams(defaultParams);
                        // Auto-fill publisher defaults from
                        // _where_clauses_mapping (Dynamic rows only) so
                        // consumers see the intended starting values.
                        const initFilters: Record<string, string> = {};
                        const initOps: Record<string, string> = {};
                        (view.allowed_filters || []).forEach(col => {
                          const hint = getPublisherHint(view.query_config, col);
                          initOps[col] = hint.operator;
                          if (hint.defaultValue !== undefined && hint.defaultValue !== null) {
                            initFilters[col] = Array.isArray(hint.defaultValue)
                              ? hint.defaultValue.join(',')
                              : String(hint.defaultValue);
                          } else {
                            initFilters[col] = '';
                          }
                        });
                        setTestFilters(initFilters);
                        setTestOps(initOps);
                        setTestFormat('json');
                        setTestLimit(String(
                          view.default_limit == null || view.default_limit > 500
                            ? 100 : view.default_limit));
                        setTestResult(null);
                        setTestError('');
                      }
                    }}
                  >
                    {isTesting ? 'Close test panel' : 'Try it'}
                  </Button>
                  {/* 2026-10-23 -- the owner: "someone want to plug in api test
                      ui".  THIS API as an OpenAPI 3.0 document (its columns,
                      filters, limits, errors, the X-API-Key scheme) -- import it
                      into Postman, Swagger UI or a team's own tool. */}
                  <Tooltip title="This API as an OpenAPI document — import it into Postman, Swagger UI or your own test tool">
                    <Button size="small" variant="outlined" sx={{ ml: 1 }}
                            data-testid={`openapi-download-${view.slug}`}
                            onClick={() => downloadOpenApi(view.slug)}>
                      Download OpenAPI
                    </Button>
                  </Tooltip>
                  {openApiError?.slug === view.slug && (
                    <Alert severity="error" sx={{ mt: 1 }} onClose={() => setOpenApiError(null)}
                           data-testid="openapi-download-error">
                      {openApiError.message}
                    </Alert>
                  )}

                  {/* Inline test panel */}
                  {isTesting && (
                    <Box mt={2} p={2} bgcolor="action.hover" borderRadius={1}>
                      <Typography variant="subtitle2" gutterBottom>Live Request Builder</Typography>

                      {/* Param inputs */}
                      {(view.param_definitions?.length ?? 0) > 0 && (
                        <Box mb={2}>
                          <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                            Parameters
                          </Typography>
                          <Stack spacing={1}>
                            {view.param_definitions!.map(p => (
                              <TextField
                                key={p.name}
                                size="small"
                                fullWidth
                                label={p.name}
                                value={testParams[p.name] ?? ''}
                                onChange={e =>
                                  setTestParams(prev => ({ ...prev, [p.name]: e.target.value }))
                                }
                                placeholder={p.default || p.type || 'value'}
                                required={p.required}
                                helperText={p.description || undefined}
                              />
                            ))}
                          </Stack>
                        </Box>
                      )}

                      {/* Filter inputs — Phase 133-K: real Autocomplete
                          with distinct-value dropdown per (connection,
                          table, column), publisher defaults auto-filled,
                          operator picker beside each value. */}
                      {(view.allowed_filters?.length ?? 0) > 0 && (() => {
                        const cid = view.execution_connection_id ?? view.connection_id ?? null;
                        const table = extractTableHint(view.query_config);
                        const secondaryCid =
                          (view.query_config?.secondary_connection_id as number) ?? null;
                        const fallback =
                          secondaryCid && table
                            ? [{ connectionId: secondaryCid, table }]
                            : [];
                        return (
                          <Box mb={2}>
                            <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                              Filters — pick or type a value.  Publisher defaults are pre-filled where
                              available; change the operator if you need something other than equals.
                            </Typography>
                            <Stack spacing={1}>
                              {view.allowed_filters.map(f => {
                                const op = testOps[f] || 'eq';
                                const hint = getPublisherHint(view.query_config, f);
                                return (
                                  <Stack
                                    key={f}
                                    direction="row"
                                    spacing={1}
                                    alignItems="flex-start"
                                  >
                                    <FormControl size="small" sx={{ minWidth: 170, mt: 0 }}>
                                      <InputLabel id="sel-apiexplorerpage-field">{`op (${f})`}</InputLabel>
                                      <Select labelId="sel-apiexplorerpage-field"
                                        label={`op (${f})`}
                                        value={op}
                                        onChange={e =>
                                          setTestOps(prev => ({ ...prev, [f]: e.target.value }))
                                        }
                                      >
                                        {WHERE_OPERATORS.map(o => (
                                          <MenuItem key={o.value} value={o.value}>
                                            {o.label}
                                          </MenuItem>
                                        ))}
                                      </Select>
                                    </FormControl>
                                    <Box flex={1} minWidth={0}>
                                      <DynamicWhereOverrideField
                                        column={f}
                                        operator={op}
                                        publisherDefault={hint.defaultValue}
                                        value={testFilters[f] ?? ''}
                                        onChange={v =>
                                          setTestFilters(prev => ({
                                            ...prev,
                                            [f]: Array.isArray(v) ? v.join(',') : String(v ?? ''),
                                          }))
                                        }
                                        connectionId={cid}
                                        table={table}
                                        fallbackTargets={fallback}
                                        label={`filter[${f}]`}
                                        fullWidth
                                      />
                                    </Box>
                                  </Stack>
                                );
                              })}
                            </Stack>
                          </Box>
                        );
                      })()}

                      <Stack direction="row" spacing={2} mb={2} alignItems="flex-start">
                        <FormControl size="small" sx={{ minWidth: 110 }}>
                          <InputLabel id="sel-apiexplorerpage-format">Format</InputLabel>
                          <Select labelId="sel-apiexplorerpage-format"
                            value={testFormat}
                            label="Format"
                            onChange={e => setTestFormat(e.target.value)}
                          >
                            <MenuItem value="json">json</MenuItem>
                            <MenuItem value="csv">csv</MenuItem>
                            <MenuItem value="parquet">parquet</MenuItem>
                          </Select>
                        </FormControl>
                        <TextField
                          size="small"
                          label="Limit"
                          type="number"
                          value={testLimit}
                          onChange={e => setTestLimit(e.target.value)}
                          sx={{ width: 110 }}
                          /* 2026-08-20 -- with max_limit === 0 this emitted min:1 max:0, an impossible */
                          /* range that made the test form un-submittable on exactly the */
                          /* views that allow the most rows. 0 = no upper bound. */
                          inputProps={view.max_limit > 0 ? { min: 1, max: view.max_limit } : { min: 1 }}
                        />
                        <Button
                          variant="contained"
                          size="small"
                          startIcon={testLoading ? <CircularProgress size={14} /> : <PlayIcon />}
                          disabled={testLoading}
                          onClick={() => handleTest(view)}
                        >
                          Send
                        </Button>
                        {(() => {
                          const usingApiKey =
                            selectedKeyId === 'custom' &&
                            customKey &&
                            customKey !== 'YOUR_API_KEY' &&
                            customKey.trim().length > 8;
                          const tryKey = typeof selectedKeyId === 'number'
                            ? apiKeys.find(k => k.id === selectedKeyId) : undefined;
                          return (
                            <Chip
                              size="small" data-testid="explorer-auth-chip"
                              color={usingApiKey || tryKey ? 'primary' : 'default'}
                              label={tryKey
                                ? `As consumer: ${tryKey.name} (${tryKey.key_prefix}…)`
                                : usingApiKey
                                ? `Auth: X-API-Key (${customKey.trim().slice(0, 8)}…)`
                                : 'Auth: session (pick a key or paste one to test as a consumer)'}
                              sx={{ alignSelf: 'center' }}
                            />
                          );
                        })()}
                      </Stack>

                      {/* Integration code — multi-language switcher.
                          Regenerates live from the current params/filters
                          the request builder above uses. */}
                      {(() => {
                        const snippet = buildSnippet(
                          codeLang, view, testParams, testFilters, testOps, testFormat, testLimit,
                        );
                        const codeKey = `code-${view.id}`;
                        return (
                          <Box mb={2}>
                            <Stack
                              direction="row"
                              alignItems="center"
                              spacing={1}
                              mb={0.5}
                              flexWrap="wrap"
                            >
                              <Typography variant="caption" color="text.secondary">
                                Integration code
                              </Typography>
                              <ToggleButtonGroup
                                size="small"
                                exclusive
                                value={codeLang}
                                onChange={(_, v) => { if (v) setCodeLang(v as CodeLang); }}
                                sx={{ '& .MuiToggleButton-root': { py: 0.1, px: 1, textTransform: 'none' } }}
                              >
                                <ToggleButton value="curl">curl</ToggleButton>
                                <ToggleButton value="python">Python</ToggleButton>
                                <ToggleButton value="csharp">C#</ToggleButton>
                                <ToggleButton value="javascript">JavaScript</ToggleButton>
                              </ToggleButtonGroup>
                              <Tooltip title={copied === codeKey ? 'Copied!' : 'Copy code'}>
                                <IconButton size="small" onClick={() => handleCopy(snippet, codeKey)}>
                                  {copied === codeKey
                                    ? <CheckIcon fontSize="small" color="success" />
                                    : <CopyIcon fontSize="small" />}
                                </IconButton>
                              </Tooltip>
                            </Stack>
                            {usingPlaceholderKey && (
                              <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                                Using <code>YOUR_API_KEY</code> placeholder — paste a real key above to embed it.
                              </Typography>
                            )}
                            <Box
                              component="pre"
                              sx={{
                                bgcolor: CODE_BG, color: CODE_COLOR, p: 1.5, borderRadius: 1,
                                fontFamily: 'monospace', fontSize: '0.75rem',
                                overflowX: 'auto', m: 0, whiteSpace: 'pre', wordBreak: 'normal',
                              }}
                            >
                              {snippet}
                            </Box>
                          </Box>
                        );
                      })()}

                      {testError && <Alert severity="error" sx={{ mb: 1 }}>{testError}</Alert>}
                      {ranAs && (testResult || testError) && (
                        <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}
                                    data-testid="explorer-ran-as">
                          Ran {ranAs}.
                        </Typography>
                      )}

                      {testResult && (() => {
                        const rows = extractRows(testResult);
                        const tabular = isTabular(testResult);
                        const columns = tabular
                          ? deriveColumns(rows, testResult.columns)
                          : [];
                        const showGrid = tabular && resultView === 'grid';
                        return (
                          <Box>
                            <Stack
                              direction="row"
                              alignItems="center"
                              spacing={1}
                              mb={0.5}
                              flexWrap="wrap"
                            >
                              <Typography variant="caption" color="text.secondary">
                                Response — {rows.length} rows
                                {testResult.total_rows != null &&
                                  ` of ${Number(testResult.total_rows).toLocaleString()} total`}
                              </Typography>
                              {tabular && (
                                <ToggleButtonGroup
                                  size="small"
                                  exclusive
                                  value={resultView}
                                  onChange={(_, v) => { if (v) setResultView(v as 'grid' | 'json'); }}
                                  sx={{ '& .MuiToggleButton-root': { py: 0.1, px: 1, textTransform: 'none' } }}
                                >
                                  <ToggleButton value="grid">Grid</ToggleButton>
                                  <ToggleButton value="json">JSON</ToggleButton>
                                </ToggleButtonGroup>
                              )}
                            </Stack>

                            {showGrid ? (
                              <Box
                                sx={{
                                  maxHeight: 360,
                                  overflow: 'auto',
                                  border: theme => `1px solid ${theme.palette.divider}`,
                                  borderRadius: 1,
                                  mt: 0.5,
                                }}
                              >
                                <Table size="small" stickyHeader sx={{ width: 'max-content', minWidth: '100%' }}>
                                  <TableHead>
                                    <TableRow>
                                      {columns.map(c => (
                                        <TableCell
                                          key={c}
                                          sx={{
                                            fontWeight: 600,
                                            fontFamily: 'monospace',
                                            whiteSpace: 'nowrap',
                                            bgcolor: 'background.paper',
                                          }}
                                        >
                                          {c}
                                        </TableCell>
                                      ))}
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {rows.map((row: any, i: number) => (
                                      <TableRow key={i} hover>
                                        {columns.map(c => {
                                          const raw = row?.[c];
                                          const isNull = raw === null || raw === undefined;
                                          return (
                                            <TableCell
                                              key={c}
                                              sx={{
                                                fontFamily: 'monospace',
                                                fontSize: '0.75rem',
                                                whiteSpace: 'nowrap',
                                                maxWidth: 360,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                color: isNull ? 'text.disabled' : 'text.primary',
                                              }}
                                              title={isNull ? '' : formatCell(raw)}
                                            >
                                              {formatCell(raw)}
                                            </TableCell>
                                          );
                                        })}
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </Box>
                            ) : (
                              <Box
                                component="pre"
                                sx={{
                                  bgcolor: CODE_BG, color: CODE_COLOR, p: 1.5, borderRadius: 1,
                                  fontFamily: 'monospace', fontSize: '0.75rem',
                                  maxHeight: 360, overflow: 'auto', mt: 0.5,
                                }}
                              >
                                {JSON.stringify(testResult, null, 2).slice(0, 4000)}
                              </Box>
                            )}
                          </Box>
                        );
                      })()}
                    </Box>
                  )}
                </AccordionDetails>
              </Accordion>
            );
          })}
        </>
      )}
    </Box>
  );
};

export default ApiExplorerPage;
