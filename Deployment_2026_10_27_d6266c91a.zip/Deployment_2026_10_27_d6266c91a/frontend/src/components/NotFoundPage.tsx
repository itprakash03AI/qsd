/**
 * 2026-10-23 -- an address no route matches.  It rendered an EMPTY page under
 * the header (found proving the SQL page by clicks: /sql-query is not the SQL
 * page's address, /sql is) -- a blank screen reads as "broken or still
 * loading".  Say what happened and offer the way back.
 */
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Box, Button, Paper, Typography } from '@mui/material';

export default function NotFoundPage() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  return (
    <Box sx={{ p: 3, display: 'flex', justifyContent: 'center' }}>
      <Paper variant="outlined" sx={{ p: 3, maxWidth: 560, width: '100%' }} data-testid="page-not-found">
        <Typography variant="h6" gutterBottom>Page not found</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          There is no page at <b>{pathname}</b>. The link may be old or mistyped.
          Use the menu on the left, or go to the home page.
        </Typography>
        <Button variant="contained" onClick={() => navigate('/')}>Go to the home page</Button>
      </Paper>
    </Box>
  );
}
