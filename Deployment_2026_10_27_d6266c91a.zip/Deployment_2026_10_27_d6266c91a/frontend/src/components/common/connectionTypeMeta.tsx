/**
 * ONE vocabulary for a connection TYPE on screen (2026-10-25): its label, its
 * icon, a chip, and the sqlglot dialect a statement written for it is read as.
 *
 * `ConnectionManager.tsx` carries its own `CONN_TYPE_META` for the connection
 * forms; this module is the light-weight one for every OTHER screen that
 * names a connection's kind beside its name (the UNION dialog, pickers) so a
 * type is never spelled differently in two places.  An unknown type is shown
 * as its raw key, never hidden.
 */
import React from 'react';
import { Chip, ChipProps } from '@mui/material';
import CloudIcon from '@mui/icons-material/Cloud';
import FolderIcon from '@mui/icons-material/Folder';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import StorageIcon from '@mui/icons-material/Storage';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import BoltIcon from '@mui/icons-material/Bolt';
import HubIcon from '@mui/icons-material/Hub';
import ApiIcon from '@mui/icons-material/Api';
import DnsIcon from '@mui/icons-material/Dns';

export interface ConnectionTypeMeta {
  label: string;
  /** The icon as an element factory so a chip and an option can size it. */
  icon: React.ReactElement;
  /** The sqlglot dialect SQL written for this type is read as (Format). */
  dialect: string;
}

const META: Record<string, ConnectionTypeMeta> = {
  s3:            { label: 'AWS S3',        icon: <CloudIcon fontSize="inherit" />,      dialect: 'trino' },
  s3_minio:      { label: 'S3 (MinIO)',    icon: <CloudIcon fontSize="inherit" />,      dialect: 'trino' },
  s3_compatible: { label: 'S3-compatible', icon: <CloudIcon fontSize="inherit" />,      dialect: 'trino' },
  local:         { label: 'Local folder',  icon: <FolderIcon fontSize="inherit" />,     dialect: 'duckdb' },
  upload:        { label: 'Uploaded files', icon: <UploadFileIcon fontSize="inherit" />, dialect: 'duckdb' },
  trino:         { label: 'Trino',         icon: <BoltIcon fontSize="inherit" />,       dialect: 'trino' },
  starburst:     { label: 'Starburst',     icon: <BoltIcon fontSize="inherit" />,       dialect: 'trino' },
  snowflake:     { label: 'Snowflake',     icon: <AcUnitIcon fontSize="inherit" />,     dialect: 'snowflake' },
  databricks:    { label: 'Databricks',    icon: <HubIcon fontSize="inherit" />,        dialect: 'databricks' },
  oracle:        { label: 'Oracle',        icon: <StorageIcon fontSize="inherit" />,    dialect: 'oracle' },
  athena:        { label: 'Athena',        icon: <CloudIcon fontSize="inherit" />,      dialect: 'athena' },
  postgres:      { label: 'PostgreSQL',    icon: <StorageIcon fontSize="inherit" />,    dialect: 'postgres' },
  postgresql:    { label: 'PostgreSQL',    icon: <StorageIcon fontSize="inherit" />,    dialect: 'postgres' },
  rest_api:      { label: 'REST API',      icon: <ApiIcon fontSize="inherit" />,        dialect: 'duckdb' },
};

/** Storage connections: the SQL is QueryStudio's own engine's, and the
 *  connection may DECLARE the dialect it was written in (`config.sql_dialect`,
 *  qs-connections "SQL written for this connection"). */
const STORAGE_TYPES = new Set(['s3', 's3_minio', 's3_compatible', 'local', 'upload']);

export function connectionTypeMeta(type?: string | null): ConnectionTypeMeta {
  const key = (type ?? '').trim().toLowerCase();
  if (META[key]) return META[key];
  return {
    label: key ? key.charAt(0).toUpperCase() + key.slice(1) : 'Unknown type',
    icon: <DnsIcon fontSize="inherit" />,
    dialect: 'duckdb',
  };
}

export function connectionTypeLabel(type?: string | null): string {
  return connectionTypeMeta(type).label;
}

/** The sqlglot dialect to read a statement written for this connection as:
 *  the connection's DECLARED dialect when it is a storage connection that
 *  declares one, else the type's. */
export function sqlDialectFor(conn?: { connection_type?: string | null;
                                       config?: { sql_dialect?: string | null } | null } | null): string {
  const type = (conn?.connection_type ?? '').trim().toLowerCase();
  const declared = (conn?.config?.sql_dialect ?? '').trim().toLowerCase();
  if (STORAGE_TYPES.has(type) && declared) return declared;
  return connectionTypeMeta(type).dialect;
}

export function ConnectionTypeChip({ type, ...chip }: { type?: string | null } & Omit<ChipProps, 'label' | 'icon'>) {
  const meta = connectionTypeMeta(type);
  return (
    <Chip size="small" variant="outlined" icon={meta.icon} label={meta.label}
          data-testid="connection-type-chip" data-type={(type ?? '').toLowerCase()}
          sx={{ '& .MuiChip-icon': { fontSize: 16 }, ...chip.sx }} {...chip} />
  );
}
