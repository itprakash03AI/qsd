/**
 * "Filtered by your entitlement" -- the reader's own data entitlement beside
 * a result (2026-10-24, docs/DATA_ENTITLEMENT_DESIGN_2026_10_23.html §4).
 *
 * Reads GET /api/me/entitlements (what THIS reader holds per dimension) once
 * per page load.  Nothing is shown when no dimension exists.  An admin is
 * told their queries are not filtered (each such read is audited).  A reader
 * is told, per dimension, the values their rows are limited to -- on any
 * table that carries one of the dimension's columns.  Unknown != none: an
 * answer that could not be read is said, never shown as "not filtered".
 */
import React, { useEffect, useState } from 'react';
import { Chip, Tooltip } from '@mui/material';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import { safeFetch } from '../../services/api/core';

export interface MyEntitlements {
  is_admin?: boolean;
  enabled?: boolean;
  dimensions: { dimension: string; columns: string[]; values: string[] | 'all'; you_see: string }[];
}

let _cached: Promise<MyEntitlements | null> | null = null;

/** One read per page load (the answer changes only when an admin edits). */
export function loadMyEntitlements(force = false): Promise<MyEntitlements | null> {
  if (!_cached || force) {
    _cached = safeFetch('/api/me/entitlements', { retryOnTimeout: false })
      .then((r: any) => r as MyEntitlements)
      .catch(() => null);
  }
  return _cached;
}

/** The chip's words, or null when there is nothing to say. */
export function entitlementWords(e: MyEntitlements | null | undefined): { label: string; detail: string[] } | null {
  if (e === null) return { label: 'Entitlement: could not be read', detail: ['Your data entitlement could not be read just now.'] };
  if (!e || e.enabled === false || !(e.dimensions || []).length) return null;
  if (e.is_admin) {
    return { label: 'Not filtered (administrator)', detail: [
      'Administrators are not filtered by data entitlement; each such read is audited.'] };
  }
  const detail = e.dimensions.map(d => {
    const what = d.values === 'all' ? 'every value'
      : d.values.length ? d.values.join(', ') : (d.you_see.startsWith('everything') ? 'every value (no value set)' : 'no value -- no rows');
    return `${d.dimension} (${d.columns.join(', ')}): ${what}`;
  });
  return { label: 'Filtered by your entitlement', detail };
}

const EntitlementChip: React.FC = () => {
  const [state, setState] = useState<MyEntitlements | null | undefined>(undefined);
  useEffect(() => {
    let live = true;
    loadMyEntitlements().then(r => { if (live) setState(r); });
    return () => { live = false; };
  }, []);
  const words = state === undefined ? null : entitlementWords(state);
  if (!words) return null;
  return (
    <Tooltip title={<>{words.detail.map(t => <div key={t}>{t}</div>)}
      <div style={{ marginTop: 4, opacity: 0.8 }}>Rows on any table carrying these columns are limited to these values.</div></>}>
      <Chip size="small" variant="outlined" icon={<FilterAltIcon />} label={words.label}
            data-testid="entitlement-chip" sx={{ ml: 1 }} />
    </Tooltip>
  );
};

export default EntitlementChip;
