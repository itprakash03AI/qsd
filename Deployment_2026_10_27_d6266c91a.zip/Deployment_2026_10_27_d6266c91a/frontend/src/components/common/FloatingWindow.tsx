/**
 * THE floating window -- one look for every large popup (2026-10-27).
 *
 * The owner: "why can't we follow the standard popup, like when we preview
 * downloaded data from the Download Center".  That preview was a one-off
 * macOS-style window inside Downloads.tsx; the feed form was a plain MUI
 * Dialog.  Both now use this:
 *
 *   - a dark title bar with close / minimize / maximize (the "traffic
 *     lights"), the title centred, optional actions on the right;
 *   - dragged by its title bar, resized from the bottom-right corner,
 *     maximized to the whole screen and back, minimized to its title bar;
 *   - closed ONLY by its close control (or a caller's own Cancel): no Esc,
 *     and a click outside never closes it;
 *   - ``modal``: a backdrop stops the page behind it being used (a form with
 *     unsaved edits); without it the page stays usable (a preview);
 *   - it sits BELOW MUI's menus and dialogs (theme.zIndex.modal - 50), so a
 *     Select / Autocomplete list or a dialog opened from inside the window
 *     shows ABOVE it, never behind;
 *   - role="dialog" named by its title, so assistive technology and the
 *     tests find it the way they find any dialog.
 */
import React, { useCallback, useEffect, useId, useRef, useState } from 'react';
import { Box, Tooltip, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { clickable } from '../../utils/clickable';

export interface FloatingWindowProps {
  open: boolean;
  onClose: () => void;
  /** the window's name: shown in the title bar and announced as the dialog's name */
  title: React.ReactNode;
  /** a plain-text name when ``title`` is not plain text */
  ariaLabel?: string;
  /** an icon before the title */
  titleIcon?: React.ReactNode;
  /** controls at the right of the title bar */
  headerActions?: React.ReactNode;
  /** a bar under the content (a form's Back / Next / Save) */
  footer?: React.ReactNode;
  /** a backdrop blocks the page behind; a click on it does NOT close */
  modal?: boolean;
  /** the opening size: a share of the screen, capped */
  widthShare?: number;
  maxWidth?: number;
  heightShare?: number;
  maxHeight?: number;
  minWidth?: number;
  minHeight?: number;
  'data-testid'?: string;
  children: React.ReactNode;
}

const LIGHT = { width: 13, height: 13, borderRadius: '50%', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center' } as const;

export default function FloatingWindow({
  open, onClose, title, ariaLabel, titleIcon, headerActions, footer, modal = false,
  widthShare = 0.78, maxWidth = 1400, heightShare = 0.8, maxHeight = 900,
  minWidth = 520, minHeight = 300, children, ...rest
}: FloatingWindowProps) {
  const theme = useTheme();
  const titleId = useId();
  const startGeom = () => {
    const w = Math.round(Math.min(window.innerWidth * widthShare, maxWidth));
    const h = Math.round(Math.min(window.innerHeight * heightShare, maxHeight));
    return { pos: { x: Math.round((window.innerWidth - w) / 2), y: Math.round((window.innerHeight - h) / 4) },
             size: { w, h } };
  };
  const [pos, setPos] = useState(() => startGeom().pos);
  const [size, setSize] = useState(() => startGeom().size);
  const [minimized, setMinimized] = useState(false);
  const [maximized, setMaximized] = useState(false);
  const [prevGeom, setPrevGeom] = useState<{ pos: typeof pos; size: typeof size } | null>(null);
  const drag = useRef<{ mx: number; my: number; px: number; py: number } | null>(null);
  const resize = useRef<{ mx: number; my: number; w: number; h: number } | null>(null);

  // every opening starts centred, at its opening size
  useEffect(() => {
    if (!open) return;
    const g = startGeom();
    setPos(g.pos); setSize(g.size); setMinimized(false); setMaximized(false); setPrevGeom(null);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const follow = (onMove: (ev: MouseEvent) => void, done: () => void) => {
    const onUp = () => { done(); window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const startDrag = useCallback((e: React.MouseEvent) => {
    if (maximized || (e.target as HTMLElement).closest('[data-window-control]')) return;
    e.preventDefault();
    drag.current = { mx: e.clientX, my: e.clientY, px: pos.x, py: pos.y };
    follow(ev => {
      const d = drag.current;
      if (!d) return;
      setPos({ x: Math.max(0, Math.min(window.innerWidth - 120, d.px + ev.clientX - d.mx)),
               y: Math.max(0, Math.min(window.innerHeight - 40, d.py + ev.clientY - d.my)) });
    }, () => { drag.current = null; });
  }, [pos, maximized]);

  const startResize = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    resize.current = { mx: e.clientX, my: e.clientY, w: size.w, h: size.h };
    follow(ev => {
      const r = resize.current;
      if (!r) return;
      setSize({ w: Math.max(minWidth, r.w + ev.clientX - r.mx), h: Math.max(minHeight, r.h + ev.clientY - r.my) });
    }, () => { resize.current = null; });
  }, [size, minWidth, minHeight]);

  const toggleMaximize = () => {
    if (maximized && prevGeom) {
      setPos(prevGeom.pos); setSize(prevGeom.size); setPrevGeom(null); setMaximized(false);
    } else {
      setPrevGeom({ pos, size });
      setPos({ x: 0, y: 0 }); setSize({ w: window.innerWidth, h: window.innerHeight });
      setMaximized(true); setMinimized(false);
    }
  };
  const toggleMinimize = () => setMinimized(v => !v);

  if (!open) return null;

  const z = theme.zIndex.modal - 50;
  const frame = maximized
    ? { top: 0, left: 0, width: '100vw', height: '100vh', borderRadius: 0, boxShadow: 'none' }
    : minimized
      ? { top: pos.y, left: pos.x, width: size.w, height: 36, borderRadius: '10px', boxShadow: '0 8px 32px rgba(0,0,0,0.35)' }
      : { top: pos.y, left: pos.x, width: size.w, height: size.h, borderRadius: '10px', boxShadow: '0 20px 60px rgba(0,0,0,0.4)' };

  return (
    <>
      {modal && (
        <Box data-testid="floating-window-backdrop" aria-hidden
             sx={{ position: 'fixed', inset: 0, zIndex: z - 1, bgcolor: 'rgba(0,0,0,0.35)' }} />
      )}
      <Box role="dialog" aria-modal={modal || undefined}
           aria-labelledby={ariaLabel ? undefined : titleId} aria-label={ariaLabel}
           data-testid={rest['data-testid']}
           sx={{ position: 'fixed', zIndex: z, ...frame, display: 'flex', flexDirection: 'column',
                 overflow: 'hidden', bgcolor: 'background.paper', border: '1px solid rgba(0,0,0,0.18)' }}>
        {/* the title bar: drag here; the lights close, minimize, maximize */}
        <Box onMouseDown={startDrag} onDoubleClick={toggleMaximize}
             sx={{ height: 36, flexShrink: 0, display: 'flex', alignItems: 'center', px: 1.5, gap: 0.75,
                   background: 'linear-gradient(180deg, #3a3a3a 0%, #2b2b2b 100%)',
                   cursor: maximized ? 'default' : 'move', userSelect: 'none',
                   borderBottom: minimized ? 0 : '1px solid rgba(0,0,0,0.3)' }}>
          <Box data-window-control sx={{ display: 'flex', gap: 0.75, mr: 1.5 }}>
            <Tooltip title="Close">
              <Box {...clickable(onClose, { label: 'Close' })} data-testid="floating-window-close"
                   sx={{ ...LIGHT, bgcolor: '#ff5f57', border: '1px solid #e0443e',
                         '&:hover::after': { content: '"×"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)' } }} />
            </Tooltip>
            <Tooltip title={minimized ? 'Restore' : 'Minimize'}>
              <Box {...clickable(toggleMinimize, { label: minimized ? 'Restore' : 'Minimize' })}
                   sx={{ ...LIGHT, bgcolor: '#febc2e', border: '1px solid #d9a018',
                         '&:hover::after': { content: '"–"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)', lineHeight: 1 } }} />
            </Tooltip>
            <Tooltip title={maximized ? 'Restore' : 'Maximize'}>
              <Box {...clickable(toggleMaximize, { label: maximized ? 'Restore size' : 'Maximize' })}
                   sx={{ ...LIGHT, bgcolor: '#28c840', border: '1px solid #1aab2c',
                         '&:hover::after': { content: '"+"', fontSize: 10, fontWeight: 900, color: 'rgba(0,0,0,0.6)' } }} />
            </Tooltip>
          </Box>
          <Box sx={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1 }}>
            {titleIcon}
            <Typography id={titleId} variant="caption" noWrap component="h2"
                        sx={{ color: 'rgba(255,255,255,0.88)', fontWeight: 600, letterSpacing: 0.3, m: 0 }}>
              {title}
            </Typography>
          </Box>
          {headerActions && (
            <Box data-window-control sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>{headerActions}</Box>
          )}
        </Box>
        {!minimized && (
          <>
            <Box sx={{ flex: 1, minHeight: 0, overflow: 'hidden', position: 'relative', display: 'flex', flexDirection: 'column' }}>
              {children}
            </Box>
            {footer && (
              <Box sx={{ flexShrink: 0, borderTop: 1, borderColor: 'divider' }}>{footer}</Box>
            )}
            {!maximized && (
              <Box onMouseDown={startResize} aria-hidden
                   sx={{ position: 'absolute', bottom: 0, right: 0, width: 18, height: 18, cursor: 'nwse-resize', zIndex: 1,
                         '&::before': { content: '""', position: 'absolute', bottom: 4, right: 4, width: 0, height: 0,
                                        borderStyle: 'solid', borderWidth: '0 0 10px 10px',
                                        borderColor: 'transparent transparent rgba(0,0,0,0.2) transparent' } }} />
            )}
          </>
        )}
      </Box>
    </>
  );
}
