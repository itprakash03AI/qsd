import React, { useEffect, useState } from 'react';
import { Box, FormControl, InputLabel, MenuItem, Select, Typography } from '@mui/material';
import { engineWords } from '../feeds/feedFormSummary';
import api from '../../services/api';

/**
 * ExecutionBackendSelect — the per-feed "Execution Backend" picker.
 *
 * Options are DRIVEN BY THE BACKEND's own registry via
 * GET /api/feeds/backend-options (derived server-side from
 * core.feed.backend_router.VALID_BACKENDS +
 * core.feed.source_plan.BACKEND_CAPABILITIES), so a backend added on the
 * server — spark_k8s being the 2026-08-22 case — appears here without a
 * UI change.  A literal list in the UI is a second source of truth, and
 * "one of two twins drifted" is this codebase's dominant defect class.
 *
 * Backends the server reports as unavailable stay VISIBLE but disabled,
 * with the server's availability_detail shown — an operator should see
 * that spark_k8s exists and why it cannot be picked right now, not a
 * silently shorter list.
 *
 * Fallback: when the endpoint is missing (backend older than the
 * registry endpoint) or unreachable, the picker falls back to exactly
 * the pre-endpoint literal list — no new backend is ever invented
 * client-side, so the fallback can never offer an option the server
 * would reject.
 */

export interface BackendOption {
  value: string;
  label: string;
  available: boolean;
  /** false = this deployment switched the engine off (configuration, not an
   *  outage): it is not offered at all, unless the feed already names it. */
  offered?: boolean;
  availability_detail?: string | null;
  capabilities?: Record<string, boolean>;
}

// Pre-endpoint behaviour, verbatim (FeedConfigsPage BACKEND_TYPES).
// Deliberately does NOT include spark_k8s: only the server's registry
// may introduce a new backend to the UI.
export const FALLBACK_BACKEND_OPTIONS: BackendOption[] = [
  { value: 'auto',          label: 'auto',          available: true },
  { value: 'native',        label: 'native',        available: true },
  { value: 'spark_connect', label: 'spark connect', available: true },
  { value: 'airflow',       label: 'airflow',       available: true },
];

// Module-level cache: the registry is static per deploy, and the dialog
// re-mounts on every open — one fetch per page load is plenty.
let _optionsPromise: Promise<BackendOption[]> | null = null;
const loadBackendOptions = (): Promise<BackendOption[]> => {
  if (!_optionsPromise) {
    _optionsPromise = api.getBackendOptions()
      .then((res) => {
        const opts = res?.options;
        if (Array.isArray(opts) && opts.length > 0
            && opts.every(o => o && typeof o.value === 'string')) {
          return opts.map(o => ({
            value: o.value,
            label: o.label || o.value,
            available: o.available !== false,
            offered: o.offered !== false,
            availability_detail: o.availability_detail ?? null,
            capabilities: o.capabilities,
          }));
        }
        return FALLBACK_BACKEND_OPTIONS;
      })
      .catch(() => {
        // Do not cache the failure — a transient outage should not pin
        // the fallback list for the rest of the session.
        _optionsPromise = null;
        return FALLBACK_BACKEND_OPTIONS;
      });
  }
  return _optionsPromise;
};

/** Test hook: drop the module cache so MSW overrides take effect. */
export const _resetBackendOptionsCache = () => { _optionsPromise = null; };

export interface ExecutionBackendSelectProps {
  value: string;
  onChange: (value: string) => void;
  /** 2026-10-24 (the feed form redesign): the choice in plain words --
   *  "Automatic", "On this server", "On a Spark cluster", labelled "Engine"
   *  ("Runs on" is the schedule's field on the same step) -- with the
   *  technical name kept small underneath. */
  plain?: boolean;
}

const ExecutionBackendSelect: React.FC<ExecutionBackendSelectProps> = ({ value, onChange, plain = false }) => {
  const [options, setOptions] = useState<BackendOption[]>(FALLBACK_BACKEND_OPTIONS);

  useEffect(() => {
    let alive = true;
    loadBackendOptions().then((opts) => { if (alive) setOptions(opts); });
    return () => { alive = false; };
  }, []);

  // A feed persisted with a backend the registry no longer lists (or the
  // fallback doesn't know) must still render its current value rather
  // than a blanked-out select.
  const known = options.some(o => o.value === value);

  return (
    <FormControl fullWidth size="small">
      <InputLabel id="execution-backend-label">{plain ? 'Engine' : 'Execution Backend'}</InputLabel>
      <Select labelId="execution-backend-label" value={value} label={plain ? 'Engine' : 'Execution Backend'}
              onChange={e => onChange(e.target.value as string)}>
        {options.filter(o => o.offered !== false || o.value === value).map(o => (
          <MenuItem key={o.value} value={o.value} disabled={!o.available}>
            <Box>
              {plain ? engineWords(o.value) : o.label}
              {plain && (
                <Typography variant="caption" color="text.secondary" display="block">{o.label}</Typography>
              )}
              {!o.available && (
                <Typography variant="caption" color="text.secondary" display="block">
                  unavailable{o.availability_detail ? ` — ${o.availability_detail}` : ''}
                </Typography>
              )}
            </Box>
          </MenuItem>
        ))}
        {!known && value && (
          <MenuItem key={value} value={value}>{value}</MenuItem>
        )}
      </Select>
    </FormControl>
  );
};

export default ExecutionBackendSelect;
