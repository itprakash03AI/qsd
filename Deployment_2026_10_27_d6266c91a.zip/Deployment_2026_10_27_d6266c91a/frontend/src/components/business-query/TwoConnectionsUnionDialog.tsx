/**
 * 2026-10-23 -- the owner: "run BQB cross source with UNION ALL ... I don't
 * have [to] select tables ... I will write [the] query for both side[s]".
 * 2026-10-25 -- the owner: "improve the popup of query UNION ALL cross
 * source ... make it nicer": the AUTHORING experience of the two statements.
 *
 * One dialog: the second connection and the two statements, written by the
 * author, SIDE BY SIDE (stacked on a phone) in the app's real SQL editors.
 * Apply hands back exactly {crossConnId, primarySql, secondarySql}; the
 * builder puts them in its editor as the labelled pair (F8,
 * `composeCrossSourceSql`) that Execute already runs -- no table of either
 * connection needs to be ticked.  Connection 1 is the builder's own
 * connection (changing it resets the builder), so it is shown, not picked.
 *
 * "Check columns" runs each statement on ITS connection through the dataset
 * wizard's preview route (`api.previewDatasetSource` -> `POST
 * /api/datasets/preview`, a 1-row cap applied by the connector) and aligns
 * the two column lists BY NAME -- the rule the run merges by (`UNION ALL BY
 * NAME`, case-insensitive; `unionColumnAlignment.ts`) -- marking a column
 * only one side returns and a type that differs.  A side's failure is shown
 * beside that side in the server's words; a statement that came back with
 * no rows AND no column list is "could not tell", never "no columns".  The
 * check is advice: Apply never waits on it (the run shows the real verdict).
 *
 * "Format" is the server's formatter (`POST /api/sql/format`, sqlglot) read
 * in the dialect the connection's TYPE implies -- or, on a storage
 * connection, the dialect it DECLARES (`config.sql_dialect`); a statement
 * the formatter cannot read is left as typed and the reason is said.
 *
 * Keyboard: Ctrl/Cmd+Enter applies (inside an editor too -- a high-precedence
 * CodeMirror keymap, because the default keymap's Mod-Enter inserts a blank
 * line), Escape closes, focus starts in the first editor.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, Autocomplete, Avatar, Box, Button, Checkbox, Chip, CircularProgress, Dialog,
  DialogActions, DialogContent, DialogTitle, FormControlLabel, IconButton, Paper, Stack,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Tooltip,
  Typography, useMediaQuery,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';
import CallMergeIcon from '@mui/icons-material/CallMerge';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import FormatAlignLeftIcon from '@mui/icons-material/FormatAlignLeft';
import FactCheckOutlinedIcon from '@mui/icons-material/FactCheckOutlined';
import { keymap } from '@codemirror/view';
import { Prec } from '@codemirror/state';
import SqlEditor from '../SqlEditor';
import api from '../../services/api';
import { safeFetch } from '../../services/api/core';
import { safeStringify } from '../../utils/safeStringify';
import { describeLoadError } from '../../utils/loadError';
import { ConnectionTypeChip, connectionTypeLabel, connectionTypeMeta, sqlDialectFor }
  from '../common/connectionTypeMeta';
import {
  AlignedRow, AlignStatus, SideColumn, alignUnionColumns, alignmentWords,
} from './unionColumnAlignment';

export interface TwoConnectionsUnionValue {
  crossConnId: number;
  primarySql: string;
  secondarySql: string;
}

export interface UnionDialogConnection {
  id: number;
  name: string;
  connection_type?: string;
  config?: { sql_dialect?: string | null } | null;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onApply: (v: TwoConnectionsUnionValue) => void;
  connections: UnionDialogConnection[];
  primaryConnId: number | null;
  connName: (id: number | null) => string;
  initialCrossConnId: number | null;
  initialPrimarySql: string;
  initialSecondarySql: string;
}

/** What "Check columns" knows about one side. */
type SideCheck =
  | { state: 'idle' }
  | { state: 'running' }
  | { state: 'ok'; columns: SideColumn[]; typesReported: boolean; note?: string }
  | { state: 'failed'; message: string };

const IDLE: SideCheck = { state: 'idle' };

/** The route refuses a `;` inside the statement; a trailing one is the
 *  author's habit, not a second statement. */
const stripTerminator = (sql: string) => sql.trim().replace(/;+\s*$/, '');

/** Run one statement on its connection and read ITS columns (exported for
 *  the tests; the dialog is the only production caller). */
export async function describeStatementColumns(connectionId: number, sql: string): Promise<SideCheck> {
  try {
    const r: any = await api.previewDatasetSource({
      connection_id: connectionId, sql: stripTerminator(sql), limit: 1,
    });
    const names: string[] = Array.isArray(r?.columns) ? r.columns.map((c: unknown) => String(c)) : [];
    const types: Record<string, string> =
      r?.column_types && typeof r.column_types === 'object' ? r.column_types : {};
    if (names.length === 0) {
      // Unknown is not empty: the connector answered with no rows and no
      // column list, so the shape could not be read -- say that.
      return {
        state: 'failed',
        message: typeof r?.rows_unavailable === 'string' && r.rows_unavailable
          ? r.rows_unavailable
          : 'The statement ran but returned no rows and no column list, so its columns could '
            + 'not be read. Give it a row to return, or name the columns explicitly.',
      };
    }
    const columns = names.map(n => ({ name: n, type: types[n] ?? null }));
    return {
      state: 'ok', columns,
      typesReported: columns.some(c => !!c.type),
      note: typeof r?.rows_unavailable === 'string' ? r.rows_unavailable : undefined,
    };
  } catch (e) {
    return { state: 'failed', message: describeLoadError(e).message };
  }
}

const STATUS_WORDS: Record<AlignStatus, string> = {
  matched: 'Matched',
  type_mismatch: 'Type mismatch',
  only_1: 'Only on connection 1',
  only_2: 'Only on connection 2',
};

function StatusChip({ status }: { status: AlignStatus }) {
  const color = status === 'matched' ? 'success' : status === 'type_mismatch' ? 'warning' : 'default';
  const icon = status === 'matched' ? <CheckCircleOutlineIcon />
    : status === 'type_mismatch' ? <WarningAmberIcon /> : <RemoveCircleOutlineIcon />;
  return <Chip size="small" variant="outlined" color={color} icon={icon} label={STATUS_WORDS[status]}
               sx={{ height: 22, '& .MuiChip-label': { px: 0.75, fontSize: 11 } }} />;
}

const TwoConnectionsUnionDialog: React.FC<Props> = ({
  open, onClose, onApply, connections, primaryConnId, connName,
  initialCrossConnId, initialPrimarySql, initialSecondarySql,
}) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  const [crossConnId, setCrossConnId] = useState<number | ''>('');
  const [primarySql, setPrimarySql] = useState('');
  const [secondarySql, setSecondarySql] = useState('');
  const [check1, setCheck1] = useState<SideCheck>(IDLE);
  const [check2, setCheck2] = useState<SideCheck>(IDLE);
  const [checkedFor, setCheckedFor] = useState<{ sql1: string; sql2: string; conn2: number | '' } | null>(null);
  const [onlyDifferences, setOnlyDifferences] = useState(false);
  const [formatting, setFormatting] = useState<1 | 2 | null>(null);
  const [formatNote, setFormatNote] = useState<{ 1: string | null; 2: string | null }>({ 1: null, 2: null });

  // Each opening starts from what the builder holds now.
  useEffect(() => {
    if (!open) return;
    setCrossConnId(initialCrossConnId ?? '');
    setPrimarySql(initialPrimarySql);
    setSecondarySql(initialSecondarySql);
    setCheck1(IDLE); setCheck2(IDLE); setCheckedFor(null);
    setOnlyDifferences(false);
    setFormatNote({ 1: null, 2: null });
  }, [open, initialCrossConnId, initialPrimarySql, initialSecondarySql]);

  const primaryConn = useMemo(
    () => connections.find(c => c.id === primaryConnId) ?? null, [connections, primaryConnId]);
  const crossConn = useMemo(
    () => (crossConnId === '' ? null : connections.find(c => c.id === crossConnId) ?? null),
    [connections, crossConnId]);
  const name1 = primaryConnId ? connName(primaryConnId) : 'none picked';
  const name2 = crossConnId === '' ? '' : connName(crossConnId);

  // The second connection: every connection but the first, grouped by type.
  const options = useMemo(() => connections
    .filter(c => c.id !== primaryConnId)
    .slice()
    .sort((a, b) => connectionTypeLabel(a.connection_type).localeCompare(connectionTypeLabel(b.connection_type))
                 || a.name.localeCompare(b.name)),
  [connections, primaryConnId]);
  const selectedOption = useMemo(
    () => options.find(o => o.id === crossConnId) ?? null, [options, crossConnId]);

  const whatIsMissing = (): string => {
    if (!primaryConnId) return 'Pick connection 1 at the top of the builder first.';
    if (crossConnId === '') return 'Pick the second connection.';
    if (!primarySql.trim()) return 'Write the query for connection 1.';
    if (!secondarySql.trim()) return 'Write the query for the second connection (or copy the first).';
    return '';
  };
  const missing = whatIsMissing();

  const apply = useCallback(() => {
    if (whatIsMissing()) return;
    onApply({ crossConnId: Number(crossConnId),
              primarySql: primarySql.trim(),
              secondarySql: secondarySql.trim() });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onApply, crossConnId, primarySql, secondarySql, primaryConnId]);

  // Mod-Enter inside an editor: the default keymap inserts a blank line, so a
  // highest-precedence binding applies instead.  The ref keeps the extension
  // stable (a new extension array re-configures the editor on every render).
  const applyRef = useRef(apply);
  applyRef.current = apply;
  const applyKeymap = useMemo(() => [Prec.highest(keymap.of([
    { key: 'Mod-Enter', run: () => { applyRef.current(); return true; } },
  ]))], []);

  // Anywhere else in the dialog (the picker, a button): the same shortcut.
  // An event CodeMirror already handled arrives defaultPrevented -- skip it.
  const onPaperKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !e.isDefaultPrevented()) {
      e.preventDefault();
      applyRef.current();
    }
  };

  // ── Check columns ────────────────────────────────────────────────────────
  const canCheck = !!primaryConnId && crossConnId !== '' && !!primarySql.trim() && !!secondarySql.trim();
  const checking = check1.state === 'running' || check2.state === 'running';
  const runCheck = async () => {
    const conn1 = primaryConnId;
    const conn2: number | '' = crossConnId;
    if (!canCheck || checking || typeof conn1 !== 'number' || typeof conn2 !== 'number') return;
    setCheckedFor({ sql1: primarySql, sql2: secondarySql, conn2 });
    setCheck1({ state: 'running' }); setCheck2({ state: 'running' });
    await Promise.all([
      describeStatementColumns(conn1, primarySql).then(setCheck1),
      describeStatementColumns(conn2, secondarySql).then(setCheck2),
    ]);
  };
  const stale = !!checkedFor && !checking
    && (checkedFor.sql1 !== primarySql || checkedFor.sql2 !== secondarySql || checkedFor.conn2 !== crossConnId);
  const aligned: AlignedRow[] | null = useMemo(
    () => (check1.state === 'ok' && check2.state === 'ok'
      ? alignUnionColumns(check1.columns, check2.columns) : null),
    [check1, check2]);
  const shownRows = useMemo(
    () => (aligned ? (onlyDifferences ? aligned.filter(r => r.status !== 'matched') : aligned) : []),
    [aligned, onlyDifferences]);

  // ── Format ───────────────────────────────────────────────────────────────
  const formatSide = async (side: 1 | 2) => {
    const text = side === 1 ? primarySql : secondarySql;
    if (!text.trim() || formatting) return;
    const dialect = sqlDialectFor(side === 1 ? primaryConn : crossConn);
    setFormatting(side);
    try {
      const r: any = await safeFetch('/api/sql/format', {
        method: 'POST', body: safeStringify({ sql: text, dialect }),
      });
      if (r?.formatted && typeof r.sql === 'string') {
        (side === 1 ? setPrimarySql : setSecondarySql)(r.sql);
        setFormatNote(n => ({ ...n, [side]: null }));
      } else {
        setFormatNote(n => ({ ...n, [side]: `Could not format (read as ${dialect}): ${r?.reason || 'the server did not format it'}. The text is unchanged.` }));
      }
    } catch (e) {
      setFormatNote(n => ({ ...n, [side]: `Could not format: ${describeLoadError(e).message}` }));
    } finally {
      setFormatting(null);
    }
  };

  // ── The summary line ─────────────────────────────────────────────────────
  const columnWords = (() => {
    if (checking) return 'checking the columns on both connections…';
    if (aligned) return (stale ? 'the statements changed since the last check — ' : '')
      + alignmentWords(aligned, name1, name2);
    if (check1.state === 'failed' || check2.state === 'failed') {
      const sides = [check1.state === 'failed' ? `connection 1 (${name1})` : null,
                     check2.state === 'failed' ? `connection 2 (${name2})` : null].filter(Boolean);
      return `the statement on ${sides.join(' and ')} could not be run — see beside it`;
    }
    return 'columns not checked yet';
  })();
  const summary = `UNION ALL of 2 statements: ${connectionTypeLabel(primaryConn?.connection_type)} (${name1}) + `
    + (crossConn ? `${connectionTypeLabel(crossConn.connection_type)} (${name2})` : 'second connection not picked')
    + ` — ${columnWords}`;

  const editorBoxSx = {
    resize: 'vertical' as const, overflow: 'hidden', height: 280, minHeight: 120,
    border: '1px solid', borderColor: 'divider', borderRadius: 1,
    '&:focus-within': { borderColor: 'primary.main' },
  };

  const sideStatus = (n: 1 | 2, check: SideCheck) => {
    if (check.state === 'failed') {
      return <Alert severity="error" data-testid={`bqb-two-conn-error-${n}`} sx={{ py: 0 }}>
        <strong>Could not run on {n === 1 ? name1 : name2}:</strong> {check.message}
      </Alert>;
    }
    if (check.state === 'ok') {
      return <Typography variant="caption" color="success.main" data-testid={`bqb-two-conn-side-ok-${n}`}>
        Returns {check.columns.length} column{check.columns.length === 1 ? '' : 's'}
        {check.typesReported ? '' : ' (types not reported by this source)'}
        {check.note ? ` · ${check.note}` : ''}
      </Typography>;
    }
    return null;
  };

  const sideCard = (n: 1 | 2) => {
    const conn = n === 1 ? primaryConn : crossConn;
    const sql = n === 1 ? primarySql : secondarySql;
    const setSql = n === 1 ? setPrimarySql : setSecondarySql;
    const check = n === 1 ? check1 : check2;
    return (
      <Paper variant="outlined" data-testid={`bqb-two-conn-side-${n}`}
             sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1, minWidth: 0 }}>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ minHeight: 40 }}>
          <Avatar sx={{ width: 24, height: 24, fontSize: 13, bgcolor: 'primary.main' }}
                  aria-hidden="true">{n}</Avatar>
          {n === 1 ? (
            <>
              <Typography variant="subtitle2" noWrap sx={{ flex: 1, minWidth: 0 }}
                          data-testid="bqb-two-conn-name-1" title={name1}>
                {name1}
              </Typography>
              {primaryConn && <ConnectionTypeChip type={primaryConn.connection_type} />}
            </>
          ) : (
            <>
              <Autocomplete
                size="small" sx={{ flex: 1, minWidth: 0 }}
                options={options}
                value={selectedOption}
                onChange={(_e, v) => setCrossConnId(v ? v.id : '')}
                groupBy={o => connectionTypeLabel(o.connection_type)}
                getOptionLabel={o => o.name}
                isOptionEqualToValue={(a, b) => a.id === b.id}
                noOptionsText="No other connection matches"
                renderOption={(props, o) => {
                  const { key, ...rest } = props as React.HTMLAttributes<HTMLLIElement> & { key: string };
                  return (
                    <li key={key} {...rest}>
                      <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', mr: 1, fontSize: 16, color: 'text.secondary' }}>
                        {connectionTypeMeta(o.connection_type).icon}
                      </Box>
                      <Box component="span" sx={{ flex: 1, minWidth: 0 }}>{o.name}</Box>
                    </li>
                  );
                }}
                renderInput={params => (
                  <TextField {...params} label="Connection 2" placeholder="Search a connection by name…"
                             inputProps={{ ...params.inputProps, 'data-testid': 'bqb-two-conn-select' }} />
                )}
              />
              {crossConn && <ConnectionTypeChip type={crossConn.connection_type} />}
            </>
          )}
        </Stack>
        <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap" useFlexGap>
          <Typography variant="caption" color="text.secondary" sx={{ flex: 1, minWidth: 0 }}>
            {conn ? `SQL as ${connectionTypeLabel(conn.connection_type)} runs it` : 'SQL for this connection'}
          </Typography>
          {n === 2 && (
            <Button size="small" startIcon={<ContentCopyIcon />} data-testid="bqb-two-conn-copy"
                    disabled={!primarySql.trim() || primarySql === secondarySql}
                    onClick={() => setSecondarySql(primarySql)}>
              Copy query 1 here
            </Button>
          )}
          <Button size="small" startIcon={formatting === n ? <CircularProgress size={14} /> : <FormatAlignLeftIcon />}
                  data-testid={`bqb-two-conn-format-${n}`}
                  disabled={!sql.trim() || formatting !== null}
                  onClick={() => formatSide(n)}>
            Format
          </Button>
        </Stack>
        <Box sx={editorBoxSx}>
          <SqlEditor
            value={sql}
            onChange={setSql}
            ariaLabel={`Query on connection ${n}`}
            testId={`bqb-two-conn-sql${n}`}
            height="100%"
            autoFocus={n === 1}
            extensions={applyKeymap}
            placeholder={n === 1
              ? 'SELECT ... FROM ... WHERE ...'
              : 'The same columns, from this connection (or copy query 1)'}
            sx={{ height: '100%' }}
          />
        </Box>
        {formatNote[n] && (
          <Alert severity="warning" data-testid={`bqb-two-conn-format-note-${n}`} sx={{ py: 0 }}
                 onClose={() => setFormatNote(f => ({ ...f, [n]: null }))}>
            {formatNote[n]}
          </Alert>
        )}
        {sideStatus(n, check)}
      </Paper>
    );
  };

  const rowSx = (status: AlignStatus) => (
    status === 'matched' ? {}
      : status === 'type_mismatch' ? { bgcolor: 'warning.light', '& td': { color: 'warning.contrastText' } }
      : { bgcolor: 'action.hover' });

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xl" fullWidth fullScreen={fullScreen}
            data-testid="bqb-two-conn-dialog"
            aria-labelledby="bqb-two-conn-title"
            slotProps={{ paper: {
              onKeyDown: onPaperKeyDown,
              sx: fullScreen ? {} : { height: 'min(92vh, 980px)' },
            } }}>
      <DialogTitle id="bqb-two-conn-title" sx={{ display: 'flex', alignItems: 'center', gap: 1, pr: 6 }}>
        <CallMergeIcon color="primary" />
        <Box sx={{ flex: 1, minWidth: 0 }}>
          UNION ALL across two connections
          <Typography variant="body2" color="text.secondary" component="div">
            One statement per connection, each run where its data lives; the rows are
            stacked by column <strong>name</strong>. No table needs to be ticked.
          </Typography>
        </Box>
        <IconButton aria-label="Close" onClick={onClose}
                    sx={{ position: 'absolute', right: 8, top: 8 }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
          {sideCard(1)}
          {sideCard(2)}
        </Box>

        <Paper variant="outlined" sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1 }}
               data-testid="bqb-two-conn-check">
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <Tooltip title={canCheck
              ? 'Runs each statement on its connection with a 1-row cap and compares the columns by name'
              : 'Pick the second connection and write both statements first'}>
              <span>
                <Button variant="outlined" size="small" data-testid="bqb-two-conn-check-btn"
                        startIcon={checking ? <CircularProgress size={14} /> : <FactCheckOutlinedIcon />}
                        disabled={!canCheck || checking} onClick={runCheck}>
                  {checking ? 'Checking…' : aligned || check1.state === 'failed' || check2.state === 'failed'
                    ? 'Check columns again' : 'Check columns'}
                </Button>
              </span>
            </Tooltip>
            <Typography variant="body2" color={stale ? 'warning.main' : 'text.secondary'} sx={{ flex: 1, minWidth: 200 }}>
              {aligned
                ? (stale ? 'The statements changed since this check — check again.'
                         : `Columns compared by name, the way the run stacks them.`)
                : 'Compare the two column lists by name before putting the pair in the editor.'}
            </Typography>
            {aligned && aligned.length > 0 && (
              <FormControlLabel sx={{ mr: 0 }}
                control={<Checkbox size="small" checked={onlyDifferences}
                                   onChange={e => setOnlyDifferences(e.target.checked)}
                                   slotProps={{ input: { 'data-testid': 'bqb-two-conn-only-diff' } as any }} />}
                label={<Typography variant="body2">Only differences</Typography>} />
            )}
          </Stack>
          {aligned && (
            <TableContainer sx={{ maxHeight: 280, opacity: stale ? 0.6 : 1 }}>
              <Table size="small" stickyHeader data-testid="bqb-two-conn-columns"
                     aria-label="Columns of the two statements, aligned by name">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ width: '34%' }}>Column</TableCell>
                    <TableCell sx={{ width: '24%' }}>1 · {name1}</TableCell>
                    <TableCell sx={{ width: '24%' }}>2 · {name2}</TableCell>
                    <TableCell>Match</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {shownRows.length === 0 && (
                    <TableRow><TableCell colSpan={4}>
                      <Typography variant="body2" color="text.secondary">
                        {aligned.length === 0 ? 'Neither statement returned a column.' : 'No differences — every column is on both sides with the same type.'}
                      </Typography>
                    </TableCell></TableRow>
                  )}
                  {shownRows.map(r => (
                    <TableRow key={r.key} data-testid={`bqb-two-conn-col-${r.key}`} data-status={r.status}
                              sx={rowSx(r.status)}>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                        {r.name1 ?? r.name2}
                        {r.notes.length > 0 && (
                          <Typography variant="caption" color="text.secondary" component="div"
                                      sx={{ fontFamily: 'inherit', fontSize: 11 }}>
                            {r.notes.join(' · ')}
                          </Typography>
                        )}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>
                        {r.name1 ? (r.type1 ?? <em>type not reported</em>) : <em>not returned</em>}
                      </TableCell>
                      <TableCell sx={{ fontSize: 12 }}>
                        {r.name2 ? (r.type2 ?? <em>type not reported</em>) : <em>not returned</em>}
                      </TableCell>
                      <TableCell><StatusChip status={r.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Paper>
      </DialogContent>
      {/* pr: the app's assistant button floats above dialogs at the bottom right (Layout.tsx,
          zIndex 1400 on purpose) -- keep the primary action clear of it */}
      <DialogActions sx={{ justifyContent: 'space-between', flexWrap: 'wrap', gap: 1, pl: 3, pr: { xs: 3, md: 11 }, py: 1.5 }}>
        <Box sx={{ flex: 1, minWidth: 240 }}>
          <Typography variant="body2" data-testid="bqb-two-conn-summary">{summary}</Typography>
          {missing && (
            <Typography variant="caption" color="warning.main" data-testid="bqb-two-conn-missing"
                        role="status">
              {missing}
            </Typography>
          )}
        </Box>
        <Stack direction="row" spacing={1} alignItems="center">
          <Typography variant="caption" color="text.secondary" sx={{ display: { xs: 'none', sm: 'block' } }}>
            Ctrl/Cmd+Enter applies · Esc closes
          </Typography>
          <Button onClick={onClose}>Cancel</Button>
          <Tooltip title={missing || 'Put the labelled pair in the editor (Ctrl/Cmd+Enter)'}>
            <span>
              <Button variant="contained" data-testid="bqb-two-conn-apply" disabled={!!missing}
                      onClick={apply}>
                Put in editor
              </Button>
            </span>
          </Tooltip>
        </Stack>
      </DialogActions>
    </Dialog>
  );
};

export default TwoConnectionsUnionDialog;
