/**
 * The Business Query Builder's SQL, generated from its visual state by ONE
 * pure function (2026-10-07, F8 of the BQB audit).
 *
 * WHY THIS IS ONE PURE FUNCTION
 * -----------------------------
 * The builder generated its SQL inside a DEBOUNCED effect
 * (`setTimeout(..., 80-250 ms)`, the timer cleared and re-armed on every
 * re-render whose dependencies changed), while Execute built `query_config`
 * from the visual state AT THE CLICK and `raw_sql` from the editor text.
 * Two answers to "what is this query", computed at different times: the
 * audit removed a filter, the editor still showed `WHERE "region" = 'EMEA'`,
 * Execute ran without it (40 rows, not 20, served from cache) and only then
 * did the editor drop the WHERE.
 *
 * The rule now: the statement is a pure function of the visual state
 * (`useMemo` in the builder), the editor shows it whenever the user has not
 * typed their own, and Execute sends EXACTLY the editor's text.  In
 * cross-source mode the editor shows the two statements that run, each
 * under its label, and Execute sends the text under each label
 * (`splitCrossSourceSql`); it used to send a generated primary statement
 * whatever the editor showed.
 */
import { buildExpr, buildCaseExpr, buildWindowExpr, qid, toAlias } from './utils';
import type { BusinessFilter, JoinConfig, SortDef } from './types';
import { inListItems, isUnfilledFilter } from '../../utils/reportFilters';

export interface BqbSqlInput {
  /** A table is selected AND a connection is chosen. */
  hasSource: boolean;
  /** The selected tables, each already rendered as a SQL reference. */
  tableRefs: string[];
  /** The selected second-source tables, rendered as SQL references. */
  crossTableRefs: string[];
  /** The cross-source panel is on with a second connection chosen. */
  crossConn: boolean;
  primaryConnName: string;
  crossConnName: string;
  /** Any column is ticked -- the builder's `selectedPhysical`, which may
   *  name a column the auto-map has not (yet) resolved into `columns`. */
  anyColumnTicked: boolean;
  /** Physical names of the ticked, MAPPED columns, in display order. */
  columns: string[];
  columnAggregations: Record<string, string>;
  columnTransforms: Record<string, string>;
  computedColumns: Array<{ expression?: string; alias?: string }>;
  caseExpressions: any[];
  windowFunctions: any[];
  filters: BusinessFilter[];
  filterLogic: 'AND' | 'OR';
  having: Array<{ expression?: string }>;
  sortColumns: SortDef[];
  joinConfig: JoinConfig | null;
  distinct: boolean;
  queryLimit: number;
  crossConnMode: 'union' | 'join';
  crossJoinHow: string;
  crossJoinLeftOn: string;
  crossJoinRightOn: string;
}

export interface BqbSql {
  /** The statement the editor shows ('' = nothing to show). */
  sql: string;
  /** The second source's statement ('' when not cross-source). */
  secondarySql: string;
  /** Cross-source only: the primary side's statement (the editor shows both
   *  sides, labelled -- `composeCrossSourceSql`).  null when not cross-source. */
  primarySql: string | null;
}

const EMPTY: BqbSql = { sql: '', secondarySql: '', primarySql: null };

/**
 * Is this filter APPLIED?  (2026-10-07, F10.)  The ONE rule for every place a
 * BQB filter reaches -- the editor's WHERE, Execute's `query_config.filters`,
 * the save body, the partition checks -- and for the chip that says "not
 * applied".  It is `utils/reportFilters.ts::isUnfilledFilter` (the client
 * mirror of the server's rule: a blank value, an IN list with no items) on
 * the TRIMMED value -- the builder renders `value.trim()`, so `'   '` would
 * otherwise become `= ''` -- plus: a filter needs a column.
 */
export const isFilterApplied = (f: BusinessFilter): boolean =>
  !!f.physical_name
  && !isUnfilledFilter({ column_id: 0, operator: f.operator, value: String(f.value ?? '').trim() });

/** The filters that reach SQL and every payload. */
export const appliedFilters = (filters: BusinessFilter[]): BusinessFilter[] =>
  filters.filter(isFilterApplied);

const esc = (v: string) => v.replace(/'/g, "''");

const renderCondition = (f: BusinessFilter): string => {
  const col = qid(f.physical_name);
  const val = esc(f.value.trim());
  switch (f.operator) {
    case 'like': return `${col} LIKE '%${val}%'`;
    case 'in': {
      // The non-empty items, each escaped ONCE (it was escaped before the
      // split and again per item: O'Hare became 'O''''Hare').
      const items = inListItems(f.value).map(v => `'${esc(String(v))}'`);
      return `${col} IN (${items.join(', ')})`;
    }
    case 'neq':  return `${col} != '${val}'`;
    case 'gte':  return `${col} >= '${val}'`;
    case 'lte':  return `${col} <= '${val}'`;
    case 'gt':   return `${col} > '${val}'`;
    case 'lt':   return `${col} < '${val}'`;
    default:     return `${col} = '${val}'`;
  }
};

/** `\nWHERE ...` for the applied filters, '' when none. */
export const buildWhereClause = (
  filters: BusinessFilter[], filterLogic: 'AND' | 'OR',
): string => {
  const active = appliedFilters(filters);
  if (active.length === 0) return '';
  const joiner = filterLogic === 'OR' ? '\n  OR ' : '\n  AND ';
  return `\nWHERE ${active.map(renderCondition).join(joiner)}`;
};

/** The SELECT list; `*` when nothing renders, so filters still give valid SQL. */
const selectList = (i: BqbSqlInput): string => {
  // toAlias: SYSTEM_CODE -> "System Code" for readable column headers.
  const parts = i.columns.map(c => {
    const expr = buildExpr(c, i.columnAggregations[c] || '', i.columnTransforms[c] || '');
    return `  ${expr} AS ${qid(toAlias(c))}`;
  });
  i.computedColumns.forEach(cc => {
    if (cc.expression && cc.alias) parts.push(`  ${cc.expression} AS ${qid(cc.alias)}`);
  });
  i.caseExpressions.forEach(ce => {
    const expr = buildCaseExpr(ce);
    if (expr) parts.push(`  ${expr} AS ${qid(ce.alias)}`);
  });
  i.windowFunctions.forEach(wf => {
    const expr = buildWindowExpr(wf);
    if (expr) parts.push(`  ${expr} AS ${qid(wf.alias)}`);
  });
  return parts.length > 0 ? parts.join(',\n') : '*';
};

/** FROM -- BF-261: 2+ tables without an explicit JOIN are combined with
 *  UNION ALL BY NAME (an implicit cross join made shared columns ambiguous). */
const fromClause = (i: BqbSqlInput): string => {
  // 2026-10-07: NO `"<connection>".` prefix, ever.  With 2nd Source on but no
  // second table ticked this statement runs single-source on the primary
  // connection, where `"aws-real"."sales"` names a schema that does not
  // exist.  (The prefix belonged to the old combined DISPLAY, which no
  // longer exists.)
  const prefix = '';
  if (i.joinConfig && i.tableRefs.length >= 2) {
    const [left, right] = i.tableRefs;
    const on = `${left}.${qid(i.joinConfig.leftCol)} = ${right}.${qid(i.joinConfig.rightCol)}`;
    return `${prefix}${left}\n  ${i.joinConfig.joinType} JOIN ${prefix}${right} ON ${on}`;
  }
  if (i.tableRefs.length >= 2) {
    const unionParts = i.tableRefs.map(t => `SELECT * FROM ${prefix}${t}`)
      .join('\n  UNION ALL BY NAME\n  ');
    return `(\n  ${unionParts}\n) AS t0`;
  }
  return i.tableRefs.map(t => prefix + t).join(', ');
};

/** GROUP BY (auto: the non-aggregated columns when any aggregation is on),
 *  then HAVING, which needs a GROUP BY. */
const groupByAndHaving = (i: BqbSqlInput): string => {
  if (!Object.values(i.columnAggregations).some(Boolean)) return '';
  const groupCols = i.columns
    .filter(c => !i.columnAggregations[c])
    .map(c => buildExpr(c, '', i.columnTransforms[c] || ''));
  if (groupCols.length === 0) return '';
  const havingConds = i.having.filter(h => h.expression).map(h => h.expression);
  const having = havingConds.length > 0 ? `\nHAVING ${havingConds.join(' AND ')}` : '';
  return `\nGROUP BY ${groupCols.join(', ')}${having}`;
};

const orderByClause = (sorts: SortDef[]): string => {
  if (sorts.length === 0) return '';
  const keys = sorts.map(s => `${qid(s.column)} ${s.direction}`);
  return `\nORDER BY ${keys.join(', ')}`;
};

/**
 * Cross-source: what the editor shows IS the pair of statements that runs
 * (2026-10-07, F8 cross-source).
 *
 * `/api/execute` runs a cross-source query as TWO statements -- `raw_sql` on
 * the primary connection, `secondary_raw_sql` on the second -- combined by
 * `combine_mode` / `join_config` (backend `core/executors/cross_source_combine.py`).
 * There is no single statement spanning two connections that the backend
 * could run.  So the editor shows exactly those two statements, each under a
 * LABEL line that names its side and the combine, and Execute sends the text
 * under each label -- what the user typed there, if they typed.
 *
 * The union display used to be ONE wrapped statement
 * (`SELECT * FROM (... UNION ALL ...) AS combined ORDER BY ... LIMIT`) with
 * `"<connection>".` prefixes, which ran nowhere: Execute sent a DIFFERENT,
 * generated primary statement, and anything the user typed was ignored.
 *
 * The labels carry the 2nd Source settings (the combine is driven by the
 * panel, not by the text), so they must be exactly as generated: a label the
 * user edited, or one that no longer matches the panel, is REFUSED, never
 * silently re-interpreted (`splitCrossSourceSql`).
 */
export interface CrossSourceLabels {
  /** The line above the primary statement. */
  primary: string;
  /** The line above the secondary statement; names the combine. */
  secondary: string;
}

export const crossSourceLabels = (i: Pick<BqbSqlInput,
  'primaryConnName' | 'crossConnName' | 'crossConnMode' | 'crossJoinHow'
  | 'crossJoinLeftOn' | 'crossJoinRightOn'>): CrossSourceLabels => {
  const combine = i.crossConnMode === 'join'
    ? `${i.crossJoinHow.toUpperCase()} JOIN on ${i.crossJoinLeftOn || '?'} = ${i.crossJoinRightOn || '?'}`
    : 'UNION ALL';
  return {
    primary: `-- Primary (${i.primaryConnName})`,
    secondary: `-- Secondary (${i.crossConnName}) — ${combine}`,
  };
};

/** The editor's text for a cross-source pair -- the ONE composer. */
export const composeCrossSourceSql = (
  labels: CrossSourceLabels, primarySql: string, secondarySql: string,
): string => `${labels.primary}\n${primarySql}\n\n${labels.secondary}\n${secondarySql}`;

/**
 * The primary statement of a STORED cross-source raw_sql (2026-10-07).  A
 * query saved before that date holds the labelled display (both statements)
 * in raw_sql; the label layout is the builder's own, so the primary is the
 * text under "-- Primary (...)" and above the "-- Secondary (...)" line.
 * Text with no secondary label is returned as written.  Mirrors the server's
 * `backend/core/cross_source_display.py::primary_statement_of`.
 */
export const primaryStatementOfStored = (raw: string): string => {
  const lines = String(raw || '').split(/\r?\n/);
  const sec = lines.findIndex(l => /^\s*-- Secondary \(/.test(l));
  if (sec < 0) return raw;
  const head = lines.slice(0, sec);
  const first = head.findIndex(l => l.trim() !== '');
  if (first >= 0 && /^\s*-- Primary \(/.test(head[first])) head.splice(first, 1);
  const primary = head.join('\n').trim();
  return primary || raw;
};

/** The editor text for a LOADED cross-source pair (saved query or .sql
 *  file): the same composer a generated pair uses, so Execute reads it back
 *  exactly. */
export const loadedCrossSourceText = (
  labels: CrossSourceLabels, storedPrimary: string, storedSecondary: string,
): string => composeCrossSourceSql(labels, primaryStatementOfStored(storedPrimary).trim(),
  String(storedSecondary || '').trim());

export type CrossSourceSplit =
  | { ok: true; primary: string; secondary: string }
  | { ok: false; reason: string };

/** The statements of ``text`` split on top-level ``;`` -- quotes, quoted
 *  identifiers and comments respected.  Empty statements dropped. */
export const splitStatements = (text: string): string[] => {
  const out: string[] = [];
  let cur = '';
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    const two = text.slice(i, i + 2);
    if (two === '--') {                                   // line comment
      const j = text.indexOf('\n', i);
      const k = j < 0 ? text.length : j;
      cur += text.slice(i, k); i = k; continue;
    }
    if (two === '/*') {                                   // block comment
      const j = text.indexOf('*/', i + 2);
      const k = j < 0 ? text.length : j + 2;
      cur += text.slice(i, k); i = k; continue;
    }
    if (c === "'" || c === '"' || c === '`') {            // string / quoted identifier
      let j = i + 1;
      while (j < text.length) {
        if (text[j] === c) { if (text[j + 1] === c) { j += 2; continue; } break; }
        j += 1;
      }
      cur += text.slice(i, j + 1); i = j + 1; continue;
    }
    if (c === ';') { out.push(cur); cur = ''; i += 1; continue; }
    cur += c; i += 1;
  }
  out.push(cur);
  // a "statement" that is only comments (the labels) is not a statement
  return out.map(x => x.trim()).filter(x => x !== '' && !/^(\s*--[^\n]*)+\s*$/.test(x));
};

const PRIMARY_LINE = /^\s*--\s*primary\b/i;
const SECONDARY_LINE = /^\s*--\s*secondary\b/i;
const dropPrimaryLabel = (t: string): string => {
  const lines = t.split(/\r?\n/);
  const first = lines.findIndex(l => l.trim() !== '');
  if (first >= 0 && PRIMARY_LINE.test(lines[first])) lines.splice(first, 1);
  return lines.join('\n').trim();
};

/**
 * The two statements in the editor's text, or WHY they cannot be read
 * (2026-10-25, the owner: the label line must not be mandatory).  The labels
 * are DIVIDERS, not settings -- how the sides combine is the 2nd Source
 * panel's, never the text's:
 *   * a line starting ``-- Secondary`` (any words after it) divides the two
 *     statements; a leading ``-- Primary ...`` line is dropped;
 *   * no such line: two statements separated by ``;`` are primary then
 *     secondary;
 *   * anything else (one statement, three statements, two divider lines)
 *     is REFUSED with the reason -- never guessed.
 * ``_labels`` is kept for the callers' signature (the composer writes them).
 */
export const splitCrossSourceSql = (
  text: string, _labels?: CrossSourceLabels,
): CrossSourceSplit => {
  const lines = text.split(/\r?\n/);
  const sec = lines.reduce<number[]>((acc, l, k) => (SECONDARY_LINE.test(l) ? [...acc, k] : acc), []);
  let primary: string;
  let secondary: string;
  if (sec.length > 1) {
    return { ok: false, reason: 'there is more than one "-- Secondary" line -- keep one, above the second statement' };
  }
  if (sec.length === 1) {
    primary = dropPrimaryLabel(lines.slice(0, sec[0]).join('\n'));
    secondary = lines.slice(sec[0] + 1).join('\n').trim();
  } else {
    const stmts = splitStatements(dropPrimaryLabel(text));
    if (stmts.length !== 2) {
      return { ok: false, reason: stmts.length < 2
        ? 'only one statement was found -- put the second connection\'s statement after a line starting with "-- Secondary", or end the first statement with ";"'
        : `${stmts.length} statements were found -- cross-source runs exactly two, one per connection` };
    }
    [primary, secondary] = stmts;
  }
  if (!primary) return { ok: false, reason: 'the primary statement is empty' };
  if (!secondary) return { ok: false, reason: 'the secondary statement is empty' };
  return { ok: true, primary, secondary };
};

/** Cross-source: one statement per side (no connection prefix -- the
 *  backend runs each on its own source), shown as the labelled pair. */
const crossSourceSql = (
  i: BqbSqlInput, distinctKw: string, cols: string, where: string,
  groupHaving: string, orderBy: string,
): BqbSql => {
  const limit = `\nLIMIT ${i.queryLimit};`;
  const primarySql = `SELECT ${distinctKw}\n${cols}\nFROM ${i.tableRefs.join(', ')}${where}${groupHaving}${orderBy}${limit}`;
  const crossCols = i.columns.map(c => `  ${qid(c)}`).join(',\n');
  const secondarySql = `SELECT ${distinctKw}\n${crossCols}\nFROM ${i.crossTableRefs.join(', ')}${where}${limit}`;
  const sql = composeCrossSourceSql(crossSourceLabels(i), primarySql, secondarySql);
  return { sql, secondarySql, primarySql };
};

export function generateBqbSql(i: BqbSqlInput): BqbSql {
  if (!i.hasSource) return EMPTY;
  // No columns ticked AND no applied filters -> nothing useful to show.
  if (!i.anyColumnTicked && appliedFilters(i.filters).length === 0) return EMPTY;

  const distinctKw = i.distinct ? 'DISTINCT ' : '';
  const cols = selectList(i);
  const where = buildWhereClause(i.filters, i.filterLogic);
  const groupHaving = groupByAndHaving(i);
  const orderBy = orderByClause(i.sortColumns);

  if (i.crossConn && i.crossTableRefs.length > 0) {
    return crossSourceSql(i, distinctKw, cols, where, groupHaving, orderBy);
  }
  return {
    sql: `SELECT ${distinctKw}\n${cols}\nFROM ${fromClause(i)}${where}${groupHaving}${orderBy}\nLIMIT ${i.queryLimit};`,
    secondarySql: '',
    primarySql: null,
  };
}
