/**
 * Align the column lists of two statements the way the cross-source run
 * stacks them: UNION ALL BY NAME, case-insensitive (2026-10-25).
 *
 * The run (`core/executors/cross_source_combine.py`) merges the two sides by
 * column NAME, so the question the author needs answered before running is
 * "which names are on both sides, which on one, and do their types agree".
 * Pure: the dialog renders what this returns, and the tests pin it.
 *
 * Unknown is not a mismatch: a side whose driver reported no type for a
 * column is "type not reported", never a type mismatch.
 */

export interface SideColumn {
  name: string;
  /** The driver's type, or null/undefined when the source did not say. */
  type?: string | null;
}

export type AlignStatus = 'matched' | 'type_mismatch' | 'only_1' | 'only_2';

export interface AlignedRow {
  /** The lower-cased name both sides are matched on. */
  key: string;
  name1?: string;
  name2?: string;
  type1?: string | null;
  type2?: string | null;
  status: AlignStatus;
  /** Plain-word notes: spelled differently, a type not reported. */
  notes: string[];
}

export interface AlignmentCounts {
  both: number;
  typeMismatch: number;
  only1: number;
  only2: number;
  spelledDifferently: number;
}

/** A coarse family so `VARCHAR` vs `varchar(20)`, `BIGINT` vs `integer`
 *  are not called a mismatch, while `DOUBLE` vs `BIGINT` or `DATE` vs
 *  `VARCHAR` are. */
export function typeFamily(t?: string | null): string | null {
  if (!t) return null;
  const s = t.trim().toLowerCase().replace(/\(.*$/, '').replace(/\s+/g, ' ');
  if (!s) return null;
  if (/^(bool|boolean)$/.test(s)) return 'boolean';
  if (/^(tinyint|smallint|int|integer|bigint|int2|int4|int8|int32|int64|hugeint|ubigint|uinteger|number)$/.test(s)) return 'integer';
  if (/^(decimal|numeric|double|double precision|float|float4|float8|real)$/.test(s)) return 'decimal';
  if (/^(varchar|char|character|character varying|string|text|nvarchar|nchar|clob|varchar2|nvarchar2)$/.test(s)) return 'string';
  if (/^date$/.test(s)) return 'date';
  if (/^(timestamp|timestamp with time zone|timestamp without time zone|timestamptz|datetime|timestamp_ntz|timestamp_tz|timestamp_ltz)$/.test(s)) return 'timestamp';
  if (/^time/.test(s)) return 'time';
  if (/^(binary|varbinary|blob|bytea)$/.test(s)) return 'binary';
  return s;
}

export function alignUnionColumns(side1: SideColumn[], side2: SideColumn[]): AlignedRow[] {
  const by2 = new Map<string, SideColumn>();
  for (const c of side2) {
    const k = c.name.toLowerCase();
    if (!by2.has(k)) by2.set(k, c);
  }
  const seen = new Set<string>();
  const rows: AlignedRow[] = [];
  for (const c1 of side1) {
    const k = c1.name.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    const c2 = by2.get(k);
    if (!c2) {
      rows.push({ key: k, name1: c1.name, type1: c1.type ?? null, status: 'only_1', notes: [] });
      continue;
    }
    const notes: string[] = [];
    if (c1.name !== c2.name) notes.push(`spelled differently: ${c1.name} / ${c2.name} (merged as one column)`);
    const f1 = typeFamily(c1.type);
    const f2 = typeFamily(c2.type);
    if (!f1 && !f2) notes.push('type not reported on either side');
    else if (!f1) notes.push('type not reported on connection 1');
    else if (!f2) notes.push('type not reported on connection 2');
    const mismatch = !!f1 && !!f2 && f1 !== f2;
    rows.push({
      key: k, name1: c1.name, name2: c2.name,
      type1: c1.type ?? null, type2: c2.type ?? null,
      status: mismatch ? 'type_mismatch' : 'matched',
      notes,
    });
  }
  for (const c2 of side2) {
    const k = c2.name.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    rows.push({ key: k, name2: c2.name, type2: c2.type ?? null, status: 'only_2', notes: [] });
  }
  return rows;
}

export function alignmentCounts(rows: AlignedRow[]): AlignmentCounts {
  const c: AlignmentCounts = { both: 0, typeMismatch: 0, only1: 0, only2: 0, spelledDifferently: 0 };
  for (const r of rows) {
    if (r.status === 'only_1') c.only1 += 1;
    else if (r.status === 'only_2') c.only2 += 1;
    else {
      c.both += 1;
      if (r.status === 'type_mismatch') c.typeMismatch += 1;
      if (r.name1 && r.name2 && r.name1 !== r.name2) c.spelledDifferently += 1;
    }
  }
  return c;
}

const plural = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}`;

/** One sentence fragment for the summary line, e.g.
 *  "6 columns matched by name, 1 with a type mismatch, 2 only on aws-real". */
export function alignmentWords(rows: AlignedRow[], name1: string, name2: string): string {
  const c = alignmentCounts(rows);
  const parts = [`${plural(c.both, 'column')} matched by name`];
  if (c.typeMismatch) parts.push(`${c.typeMismatch} with a type mismatch`);
  if (c.spelledDifferently) parts.push(`${c.spelledDifferently} spelled differently`);
  if (c.only1) parts.push(`${c.only1} only on ${name1}`);
  if (c.only2) parts.push(`${c.only2} only on ${name2}`);
  return parts.join(', ');
}
