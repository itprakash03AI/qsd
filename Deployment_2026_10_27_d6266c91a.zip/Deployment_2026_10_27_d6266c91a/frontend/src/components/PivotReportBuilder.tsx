/**
 * Phase 106 — Pivot Report Builder
 *
 * 4-step wizard for creating drag-and-drop pivot reports.
 *  Step 0: Data Source — pick a published dataset
 *  Step 1: Build Pivot — drag dimensions/measures into Rows / Columns / Values zones
 *  Step 2: Filters & Parameters — default filters and report parameters
 *  Step 3: Review & Save — name, description, save as BusinessReport
 *
 * Pivot config is stored in BusinessReport.layout_config:
 *   { report_type: "pivot", pivot_config: { row_field_ids, col_field_ids, value_fields, ... } }
 */
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Stepper, Step, StepLabel, StepButton, Button, TextField,
  Checkbox, FormControlLabel, Select, MenuItem, InputLabel, FormControl,
  IconButton, Alert, CircularProgress, Divider, Tooltip,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  ArrowForward as ArrowForwardIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Close as CloseIcon,
  TableChart as PivotIcon,
  DragIndicator as DragIcon,
} from '@mui/icons-material';
import {
  DndContext,
  DragEndEvent,
  DragStartEvent,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  useDraggable,
  useDroppable,
  closestCenter,
} from '@dnd-kit/core';
import api from '../services/api';
import {
  ParamRow, paramRowsFromServer, paramRowsToBatchItems,
} from './reports/reportAuthoringModel';
import ReportParameterEditor from './reports/ReportParameterEditor';
import ReportFilterValueInput, { changeFilterField } from './reports/ReportFilterValueInput';
import { filterForSave, unfilledFilterProblems } from '../utils/reportFilters';
import { useServerDraft } from '../hooks/useServerDraft';
import { useRevealError } from '../hooks/useRevealError';
import { REPORTS_PATH, startDatasetIdFrom, useResolvedReportId } from '../utils/reportUrls';
import { clickable } from '../utils/clickable';

// ── Constants ────────────────────────────────────────────────────────────────

const WIZARD_STEPS = ['Data Source', 'Build Pivot', 'Filters & Parameters', 'Review & Save'];

const AGGREGATIONS = [
  { value: 'sum', label: 'SUM' },
  { value: 'avg', label: 'AVG' },
  { value: 'count', label: 'COUNT' },
  { value: 'count_distinct', label: 'COUNT DISTINCT' },
  { value: 'min', label: 'MIN' },
  { value: 'max', label: 'MAX' },
];

const FILTER_OPERATORS = [
  { value: 'eq', label: '= Equals' },
  { value: 'neq', label: '!= Not Equals' },
  { value: 'gt', label: '> Greater Than' },
  { value: 'gte', label: '>= Greater or Equal' },
  { value: 'lt', label: '< Less Than' },
  { value: 'lte', label: '<= Less or Equal' },
  { value: 'in', label: 'In List' },
  { value: 'between', label: 'Between' },
  { value: 'is_null', label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

const DIM_COLOR = '#1976d2';     // blue for dimensions
const MEASURE_COLOR = '#2e7d32'; // green for measures

// ── Types ────────────────────────────────────────────────────────────────────

interface PivotValueField {
  column_id: number;
  aggregation: string;
}

interface PivotConfig {
  row_field_ids: number[];
  col_field_ids: number[];
  value_fields: PivotValueField[];
  show_row_totals: boolean;
  show_col_totals: boolean;
  show_grand_total: boolean;
}

interface FilterEntry {
  column_id: number;
  operator: string;
  value: any;
  /** Upper bound for BETWEEN.  A field the shape does not declare is a
   *  field the save silently drops — `filter_specs: filters` passes the
   *  whole object through, so the type is what decides. */
  value2?: any;
}

interface PivotConfigLimits {
  enabled: boolean;
  max_row_dimensions: number;
  max_col_dimensions: number;
  max_measures: number;
  default_aggregation: string;
}

// ── Drag-and-drop helpers ────────────────────────────────────────────────────

interface DraggableFieldProps {
  id: string;
  column: any;
  inUse: boolean;
  fromZone?: 'available' | 'rows' | 'cols' | 'values';
}

const DraggableField: React.FC<DraggableFieldProps> = ({ id, column, inUse, fromZone = 'available' }) => {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id,
    data: { column, fromZone },
  });
  const isDim = column.column_type === 'dimension' || column.column_type === 'detail';
  const color = isDim ? DIM_COLOR : MEASURE_COLOR;
  return (
    <Box
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      sx={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 0.5,
        px: 1,
        py: 0.5,
        m: 0.25,
        borderRadius: 1,
        border: `1px solid ${color}`,
        bgcolor: inUse ? 'rgba(0,0,0,0.05)' : 'background.paper',
        color: inUse ? 'text.disabled' : color,
        cursor: 'grab',
        opacity: isDragging ? 0.4 : 1,
        fontSize: '0.85rem',
        userSelect: 'none',
      }}
    >
      <DragIcon fontSize="inherit" />
      {column.friendly_name || column.physical_name}
    </Box>
  );
};

interface DropZoneProps {
  id: 'rows' | 'cols' | 'values';
  title: string;
  hint: string;
  children: React.ReactNode;
}

const DropZone: React.FC<DropZoneProps> = ({ id, title, hint, children }) => {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <Paper
      ref={setNodeRef}
      elevation={isOver ? 6 : 1}
      sx={{
        p: 1.5,
        mb: 1.5,
        minHeight: 80,
        bgcolor: isOver ? 'action.hover' : 'background.default',
        border: isOver ? '2px dashed #1976d2' : '2px dashed transparent',
        transition: 'all 0.15s',
      }}
    >
      <Typography variant="subtitle2" sx={{ mb: 0.5, fontWeight: 600 }}>
        {title}
      </Typography>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5 }}>
        {hint}
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, minHeight: 32 }}>
        {children}
      </Box>
    </Paper>
  );
};

// ── Main component ───────────────────────────────────────────────────────────

const PivotReportBuilder: React.FC = () => {
  const navigate = useNavigate();
  const { id: editId } = useParams<{ id: string }>();
  const isEdit = !!editId;
  // 2026-09-20 -- editId is the SLUG in the URL; the numeric id is resolved
  // by the route element (ReportIdentityContext) or a numeric param.
  const editReportId = useResolvedReportId();
  // 2026-10-23 -- a NEW report started from a dataset (?dataset_id=N, the
  // dataset screens' "Create report"): that dataset chosen, Columns step.
  const location = useLocation();
  const startDatasetId = isEdit ? null : startDatasetIdFrom(location.search);
  const startAppliedRef = useRef(false);

  const [activeStep, setActiveStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const errorRef = useRevealError(error);

  // Step 0: Data Source
  const [datasets, setDatasets] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | null>(null);
  useEffect(() => {
    if (startDatasetId == null || startAppliedRef.current) return;
    startAppliedRef.current = true;
    setSelectedDatasetId(startDatasetId);
    setActiveStep(1);
  }, [startDatasetId]);
  const [dataset, setDataset] = useState<any>(null);
  const [allColumns, setAllColumns] = useState<any[]>([]);

  // Step 1: Pivot config
  const [rowFieldIds, setRowFieldIds] = useState<number[]>([]);
  const [colFieldIds, setColFieldIds] = useState<number[]>([]);
  const [valueFields, setValueFields] = useState<PivotValueField[]>([]);
  const [showRowTotals, setShowRowTotals] = useState(true);
  const [showColTotals, setShowColTotals] = useState(true);
  const [showGrandTotal, setShowGrandTotal] = useState(true);
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const [activeDragColumn, setActiveDragColumn] = useState<any>(null);

  // Step 2: Filters & Parameters
  const [filters, setFilters] = useState<FilterEntry[]>([]);
  const [params, setParams] = useState<ParamRow[]>([]);
  const [rowLimit, setRowLimit] = useState(50000);

  // Step 3: Review — Phase 142 persistence so user can come back to
  // a half-built pivot report after refresh / pod restart.
  // 2026-10-03 -- the NEW-pivot name draft (same defect as the tabular
  // wizard's): it was written while EDITING (the load sets these), so "New"
  // offered the last edited report's name, and it was never cleared after a
  // create.  Now: never touched in edit mode, deleted once the report exists.
  const [reportName, setReportName, nameDraft] =
    useServerDraft<string>('pivot.new.name', '', { disabled: isEdit });
  const [reportDescription, setReportDescription, descDraft] =
    useServerDraft<string>('pivot.new.desc', '', { disabled: isEdit });

  // Limits from admin config
  const [limits, setLimits] = useState<PivotConfigLimits>({
    enabled: true,
    max_row_dimensions: 3,
    max_col_dimensions: 2,
    max_measures: 5,
    default_aggregation: 'sum',
  });

  // ── Load admin limits + datasets on mount ─────────────────────────────────

  useEffect(() => {
    api.get('/api/admin/pivot/config')
      .then((cfg: any) => {
        if (cfg && typeof cfg === 'object') {
          setLimits({
            enabled: cfg.enabled !== false,
            max_row_dimensions: cfg.max_row_dimensions || 3,
            max_col_dimensions: cfg.max_col_dimensions || 2,
            max_measures: cfg.max_measures || 5,
            default_aggregation: cfg.default_aggregation || 'sum',
          });
        }
      })
      .catch(() => { /* non-admin: use defaults */ });

    // 2026-08-31 -- see the note in BusinessReportBuilder: the is_published
    // filter is a UI-only restriction the backend does not impose, and it hid
    // a user's own datasets from them.  Fixed in both builders together
    // because a rule applied in one sibling and not the other is how these
    // two screens disagreed in the first place.
    api.listDatasets().then((data: any) => {
      setDatasets(Array.isArray(data) ? data : []);
    }).catch(() => {});
  }, []);

  // ── Load existing pivot report for editing ────────────────────────────────

  useEffect(() => {
    if (!editId) return;
    setLoading(true);
    api.getBusinessReport(editReportId)
      .then((report: any) => {
        setSelectedDatasetId(report.dataset_id);
        setReportName(report.name || '');
        setReportDescription(report.description || '');
        setRowLimit(report.row_limit || 50000);
        setFilters(report.filter_specs || []);
        const lc = report.layout_config || {};
        const pc = lc.pivot_config || {};
        setRowFieldIds(pc.row_field_ids || []);
        setColFieldIds(pc.col_field_ids || []);
        setValueFields(pc.value_fields || []);
        setShowRowTotals(pc.show_row_totals !== false);
        setShowColTotals(pc.show_col_totals !== false);
        setShowGrandTotal(pc.show_grand_total !== false);
        if (report.parameters) {
          // 2026-09-03 -- this hand-written mapping listed SIX of a
          // parameter's eleven fields, so loading a pivot report for edit
          // dropped its static values, its cascade parent, the column that
          // cascade filtered and its help text.  The save below then wrote
          // the reduced set back, which means opening a pivot report in
          // the builder and pressing Save DESTROYED configuration the
          // author could not see.  paramRowsFromServer carries the whole
          // row, and there is one of it.
          setParams(paramRowsFromServer(report.parameters));
        }
      })
      .catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [editId]);

  // ── Load dataset detail when selected ─────────────────────────────────────

  useEffect(() => {
    if (!selectedDatasetId) return;
    // 2026-08-31 -- three fixes, matching BusinessReportBuilder so the two
    // builders behave the same way on the same screenful of data:
    //
    // 1. `cancelled` guard.  This is keyed on the SELECTED dataset, so
    //    switching quickly raced two in-flight loads and whichever answered
    //    last won -- the columns on screen could belong to the dataset the
    //    user had already moved off.
    // 2. A load failure no longer renders as "this dataset has no columns".
    // 3. A dataset with zero columns is healed once via auto-detect, which
    //    reads the dataset's own SQL and needs no live source.  Several
    //    creation paths leave columns empty when the source was unreachable
    //    at the time, and an empty list here empties the pivot field lists
    //    with nothing to explain why.
    let cancelled = false;
    const apply = (ds: any) => {
      if (cancelled) return;
      setDataset(ds);
      setAllColumns((ds.columns || []).filter((c: any) => !c.is_hidden));
    };
    api.getDataset(selectedDatasetId).then(async (ds: any) => {
      if (!ds?.columns?.length) {
        try {
          const res: any = await (api as any).autoDetectColumns(selectedDatasetId);
          if (res?.created > 0) {
            const healed = await api.getDataset(selectedDatasetId);
            apply(healed);
            return;
          }
        } catch {
          // fall through and render what we have, with the notice below
        }
      }
      apply(ds);
    }).catch(() => {
      if (!cancelled) setError('Could not load this dataset’s columns. '
        + 'This is a load failure, not an empty dataset — retry, or check '
        + 'you still have access to it.');
    });
    return () => { cancelled = true; };
  }, [selectedDatasetId]);

  // ── Column helpers ────────────────────────────────────────────────────────

  const dimensions = useMemo(
    () => allColumns.filter((c: any) => c.column_type === 'dimension' || c.column_type === 'detail'),
    [allColumns],
  );
  const measures = useMemo(
    () => allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi'),
    [allColumns],
  );

  const getCol = (colId: number) => allColumns.find((c: any) => c.id === colId);
  const getColName = (colId: number) => {
    const c = getCol(colId);
    return c ? (c.friendly_name || c.physical_name) : `Col #${colId}`;
  };

  const usedRowIds = new Set(rowFieldIds);
  const usedColIds = new Set(colFieldIds);
  const usedValueIds = new Set(valueFields.map(v => v.column_id));

  // ── Drag-and-drop handlers ────────────────────────────────────────────────

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const handleDragStart = (event: DragStartEvent) => {
    setActiveDragId(String(event.active.id));
    setActiveDragColumn(event.active.data.current?.column || null);
  };

  const removeFromAllZones = (colId: number) => {
    setRowFieldIds(prev => prev.filter(id => id !== colId));
    setColFieldIds(prev => prev.filter(id => id !== colId));
    setValueFields(prev => prev.filter(v => v.column_id !== colId));
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveDragId(null);
    setActiveDragColumn(null);
    const { active, over } = event;
    if (!over) return;

    const column = active.data.current?.column;
    if (!column) return;
    const fromZone = active.data.current?.fromZone || 'available';
    const toZone = String(over.id);

    if (fromZone === toZone) return;
    const isDim = column.column_type === 'dimension' || column.column_type === 'detail';
    const isMeasure = column.column_type === 'measure' || column.column_type === 'kpi';

    // Validate target zone matches column type
    if ((toZone === 'rows' || toZone === 'cols') && !isDim) {
      setError(`"${column.friendly_name || column.physical_name}" is a measure — drag it into Values instead.`);
      setTimeout(() => setError(''), 4000);
      return;
    }
    if (toZone === 'values' && !isMeasure) {
      setError(`"${column.friendly_name || column.physical_name}" is a dimension — drag it into Rows or Columns instead.`);
      setTimeout(() => setError(''), 4000);
      return;
    }

    // Limit checks
    if (toZone === 'rows' && rowFieldIds.length >= limits.max_row_dimensions && !rowFieldIds.includes(column.id)) {
      setError(`Max ${limits.max_row_dimensions} row dimensions allowed`);
      setTimeout(() => setError(''), 4000);
      return;
    }
    if (toZone === 'cols' && colFieldIds.length >= limits.max_col_dimensions && !colFieldIds.includes(column.id)) {
      setError(`Max ${limits.max_col_dimensions} column dimensions allowed`);
      setTimeout(() => setError(''), 4000);
      return;
    }
    if (toZone === 'values' && valueFields.length >= limits.max_measures && !valueFields.some(v => v.column_id === column.id)) {
      setError(`Max ${limits.max_measures} measure fields allowed`);
      setTimeout(() => setError(''), 4000);
      return;
    }

    // Remove from any other zones first (move semantics)
    removeFromAllZones(column.id);

    // Add to target zone
    if (toZone === 'rows') {
      setRowFieldIds(prev => [...prev, column.id]);
    } else if (toZone === 'cols') {
      setColFieldIds(prev => [...prev, column.id]);
    } else if (toZone === 'values') {
      setValueFields(prev => [...prev, {
        column_id: column.id,
        aggregation: column.aggregation || limits.default_aggregation || 'sum',
      }]);
    }
  };

  const removeFromZone = (zone: 'rows' | 'cols' | 'values', colId: number) => {
    if (zone === 'rows') setRowFieldIds(prev => prev.filter(id => id !== colId));
    else if (zone === 'cols') setColFieldIds(prev => prev.filter(id => id !== colId));
    else setValueFields(prev => prev.filter(v => v.column_id !== colId));
  };

  const updateValueAgg = (colId: number, agg: string) => {
    setValueFields(prev => prev.map(v => v.column_id === colId ? { ...v, aggregation: agg } : v));
  };

  // ── Filter management ─────────────────────────────────────────────────────

  const addFilter = () => {
    if (allColumns.length === 0) return;
    setFilters(prev => [...prev, { column_id: allColumns[0].id, operator: 'eq', value: '' }]);
  };
  // A new column or a change of operand kind drops the value.
  const updateFilter = (idx: number, field: string, val: any) =>
    setFilters(prev => prev.map((f, i) => (i === idx ? changeFilterField(f, field, val) : f)));
  // 2026-10-03 -- an unfilled row is not a filter; it is never submitted.
  const filterProblems = unfilledFilterProblems(filters, allColumns);
  const removeFilter = (idx: number) =>
    setFilters(prev => prev.filter((_, i) => i !== idx));

  // ── Save ──────────────────────────────────────────────────────────────────

  const handleSave = async () => {
    if (!reportName.trim()) {
      setError('Report name is required');
      return;
    }
    if (!selectedDatasetId) {
      setError('Please select a dataset');
      return;
    }
    if (rowFieldIds.length === 0) {
      setError('At least one row dimension is required');
      return;
    }
    if (valueFields.length === 0) {
      setError('At least one measure (value) is required');
      return;
    }
    if (filterProblems.length) {
      setError(filterProblems.join(' '));
      return;
    }

    setSaving(true);
    setError('');

    const pivot_config: PivotConfig = {
      row_field_ids: rowFieldIds,
      col_field_ids: colFieldIds,
      value_fields: valueFields,
      show_row_totals: showRowTotals,
      show_col_totals: showColTotals,
      show_grand_total: showGrandTotal,
    };

    const data: any = {
      name: reportName.trim(),
      description: reportDescription.trim(),
      dataset_id: selectedDatasetId,
      data_source_type: 'saved_query',
      // column_ids = all columns referenced (rows + cols + values) — required by BusinessReport schema
      column_ids: [...rowFieldIds, ...colFieldIds, ...valueFields.map(v => v.column_id)],
      filter_specs: filters.map(f => filterForSave(f)),
      condition_ids: [],
      order_by: [],
      row_limit: rowLimit,
      section_definitions: [],
      running_calculations: [],
      slicer_column_ids: [],
      drill_hierarchy_id: null,
      layout_config: {
        report_type: 'pivot',
        pivot_config,
      },
    };

    try {
      let report: any;
      if (isEdit) {
        report = await api.updateBusinessReport(editReportId, data);
      } else {
        report = await api.createBusinessReport(data);
      }

      if (report && report.id) {
        // 2026-09-03 -- was "delete every existing parameter, then create
        // them back one at a time", which is neither atomic nor complete:
        // a failure part-way through left the report with some of its
        // parameters and none of the ones after the failure, and the
        // create call hard-coded `depends_on_param_id: null`, so a pivot
        // report could not have a cascade even though PivotReportViewer
        // renders one (it shares the viewer's LOV hook).  The same atomic
        // batch endpoint the business builder uses replaces the whole set
        // in one transaction and resolves cascade parents by position.
        await api.batchSaveBusinessReportParams(
          report.id, paramRowsToBatchItems(params));
        if (!isEdit) { nameDraft.reset(); descDraft.reset(); }
        navigate(`/pivot-reports/${report.id}`);
      }
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to save pivot report');
    } finally {
      setSaving(false);
    }
  };

  // ── Step validation ───────────────────────────────────────────────────────

  const canProceed = (step: number): boolean => {
    switch (step) {
      case 0: return selectedDatasetId !== null;
      case 1: return rowFieldIds.length > 0 && valueFields.length > 0;
      case 2: return filterProblems.length === 0;
      case 3: return reportName.trim().length > 0 && filterProblems.length === 0;
      default: return true;
    }
  };

  // ── Render: Step 0 ────────────────────────────────────────────────────────

  const renderStep0 = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Select Data Source</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Choose a published dataset to build your pivot report on.
      </Typography>
      {datasets.length === 0 ? (
        <Alert severity="info">No published datasets available. Ask an admin to publish a dataset first.</Alert>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {datasets.map((ds: any) => (
            <Paper
              key={ds.id}
              elevation={selectedDatasetId === ds.id ? 4 : 1}
              sx={{
                p: 2, cursor: 'pointer',
                border: selectedDatasetId === ds.id ? '2px solid #1976d2' : '2px solid transparent',
                '&:hover': { bgcolor: 'action.hover' },
              }}
              {...clickable(() => {
                // 2026-10-03 -- another dataset's column ids never ride along
                // (the server refuses them with 422; the author should not
                // get that far).
                if (ds.id !== selectedDatasetId) {
                  setAllColumns([]); setRowFieldIds([]); setColFieldIds([]);
                  setValueFields([]); setFilters([]); setParams([]);
                }
                setSelectedDatasetId(ds.id);
              }, { label: ds.name, pressed: selectedDatasetId === ds.id })}
            >
              <Typography variant="subtitle1" fontWeight="bold">{ds.name}</Typography>
              <Typography variant="body2" color="text.secondary">
                {ds.description || 'No description'} — {ds.subject || 'General'}
              </Typography>
            </Paper>
          ))}
        </Box>
      )}
    </Box>
  );

  // ── Render: Step 1 — Drag & Drop Pivot Builder ────────────────────────────

  const renderStep1 = () => (
    <DndContext sensors={sensors} collisionDetection={closestCenter}
                onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <Box>
        <Typography variant="h6" sx={{ mb: 1 }}>Build Your Pivot</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Drag dimensions (blue) into Rows or Columns. Drag measures (green) into Values
          and pick an aggregation function.
        </Typography>

        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
          {/* ── Left: Available Fields ── */}
          <Paper elevation={1} sx={{ p: 2 }}>
            <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600 }}>
              Available Fields
            </Typography>
            <Divider sx={{ mb: 1 }} />

            <Typography variant="caption" sx={{ color: DIM_COLOR, fontWeight: 600 }}>
              DIMENSIONS
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.25, mb: 2, mt: 0.5, minHeight: 32 }}>
              {dimensions.length === 0 ? (
                <Typography variant="caption" color="text.disabled">No dimensions in this dataset</Typography>
              ) : dimensions.map((c: any) => (
                <DraggableField
                  key={`avail-dim-${c.id}`}
                  id={`avail-${c.id}`}
                  column={c}
                  inUse={usedRowIds.has(c.id) || usedColIds.has(c.id)}
                  fromZone="available"
                />
              ))}
            </Box>

            <Typography variant="caption" sx={{ color: MEASURE_COLOR, fontWeight: 600 }}>
              MEASURES
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.25, mt: 0.5, minHeight: 32 }}>
              {measures.length === 0 ? (
                <Typography variant="caption" color="text.disabled">No measures in this dataset</Typography>
              ) : measures.map((c: any) => (
                <DraggableField
                  key={`avail-measure-${c.id}`}
                  id={`avail-${c.id}`}
                  column={c}
                  inUse={usedValueIds.has(c.id)}
                  fromZone="available"
                />
              ))}
            </Box>
          </Paper>

          {/* ── Right: Drop Zones ── */}
          <Box>
            <DropZone
              id="rows"
              title={`Rows  (${rowFieldIds.length}/${limits.max_row_dimensions})`}
              hint="Dimensions that group rows of the pivot"
            >
              {rowFieldIds.length === 0 ? (
                <Typography variant="caption" color="text.disabled">Drop dimensions here</Typography>
              ) : rowFieldIds.map(cid => {
                const col = getCol(cid);
                if (!col) return null;
                return (
                  <Box key={`row-${cid}`} sx={{
                    display: 'inline-flex', alignItems: 'center', gap: 0.5,
                    px: 1, py: 0.5, m: 0.25,
                    borderRadius: 1, border: `1px solid ${DIM_COLOR}`,
                    bgcolor: `${DIM_COLOR}20`, color: DIM_COLOR,
                    fontSize: '0.85rem',
                  }}>
                    {col.friendly_name || col.physical_name}
                    <IconButton aria-label="Close" size="small" sx={{ p: 0, ml: 0.5 }}
                      onClick={() => removeFromZone('rows', cid)}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </Box>
                );
              })}
            </DropZone>

            <DropZone
              id="cols"
              title={`Columns  (${colFieldIds.length}/${limits.max_col_dimensions})`}
              hint="Dimensions that pivot into column headers (optional)"
            >
              {colFieldIds.length === 0 ? (
                <Typography variant="caption" color="text.disabled">Drop dimensions here (optional)</Typography>
              ) : colFieldIds.map(cid => {
                const col = getCol(cid);
                if (!col) return null;
                return (
                  <Box key={`col-${cid}`} sx={{
                    display: 'inline-flex', alignItems: 'center', gap: 0.5,
                    px: 1, py: 0.5, m: 0.25,
                    borderRadius: 1, border: `1px solid ${DIM_COLOR}`,
                    bgcolor: `${DIM_COLOR}20`, color: DIM_COLOR,
                    fontSize: '0.85rem',
                  }}>
                    {col.friendly_name || col.physical_name}
                    <IconButton aria-label="Close" size="small" sx={{ p: 0, ml: 0.5 }}
                      onClick={() => removeFromZone('cols', cid)}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </Box>
                );
              })}
            </DropZone>

            <DropZone
              id="values"
              title={`Values  (${valueFields.length}/${limits.max_measures})`}
              hint="Measures with aggregation function"
            >
              {valueFields.length === 0 ? (
                <Typography variant="caption" color="text.disabled">Drop measures here</Typography>
              ) : valueFields.map(vf => {
                const col = getCol(vf.column_id);
                if (!col) return null;
                return (
                  <Box key={`val-${vf.column_id}`} sx={{
                    display: 'inline-flex', alignItems: 'center', gap: 0.5,
                    px: 1, py: 0.5, m: 0.25,
                    borderRadius: 1, border: `1px solid ${MEASURE_COLOR}`,
                    bgcolor: `${MEASURE_COLOR}15`, color: MEASURE_COLOR,
                    fontSize: '0.85rem',
                  }}>
                    {col.friendly_name || col.physical_name}
                    <Select inputProps={{ 'aria-label': `Aggregation for ${col.friendly_name || col.physical_name}` }}
                      size="small"
                      value={vf.aggregation}
                      onChange={e => updateValueAgg(vf.column_id, e.target.value)}
                      sx={{
                        height: 22, fontSize: '0.75rem',
                        ml: 0.5, '.MuiSelect-select': { py: 0, pr: '20px !important' },
                      }}
                    >
                      {AGGREGATIONS.map(a => (
                        <MenuItem key={a.value} value={a.value}>{a.label}</MenuItem>
                      ))}
                    </Select>
                    <IconButton aria-label="Close" size="small" sx={{ p: 0, ml: 0.5 }}
                      onClick={() => removeFromZone('values', vf.column_id)}>
                      <CloseIcon sx={{ fontSize: 14 }} />
                    </IconButton>
                  </Box>
                );
              })}
            </DropZone>

            <Paper elevation={1} sx={{ p: 1.5 }}>
              <Typography variant="subtitle2" sx={{ mb: 0.5, fontWeight: 600 }}>Totals</Typography>
              <FormControlLabel
                control={<Checkbox size="small" checked={showRowTotals}
                                   onChange={e => setShowRowTotals(e.target.checked)} />}
                label={<Typography variant="body2">Show row totals</Typography>}
              />
              <FormControlLabel
                control={<Checkbox size="small" checked={showColTotals}
                                   onChange={e => setShowColTotals(e.target.checked)} />}
                label={<Typography variant="body2">Show column totals</Typography>}
              />
              <FormControlLabel
                control={<Checkbox size="small" checked={showGrandTotal}
                                   onChange={e => setShowGrandTotal(e.target.checked)} />}
                label={<Typography variant="body2">Show grand total</Typography>}
              />
            </Paper>
          </Box>
        </Box>
      </Box>

      <DragOverlay>
        {activeDragColumn ? (
          <Box sx={{
            display: 'inline-flex', alignItems: 'center', gap: 0.5,
            px: 1, py: 0.5, borderRadius: 1,
            border: `1px solid ${activeDragColumn.column_type === 'measure' || activeDragColumn.column_type === 'kpi'
              ? MEASURE_COLOR : DIM_COLOR}`,
            bgcolor: 'background.paper', boxShadow: 3, fontSize: '0.85rem',
          }}>
            <DragIcon fontSize="inherit" />
            {activeDragColumn.friendly_name || activeDragColumn.physical_name}
          </Box>
        ) : null}
      </DragOverlay>
    </DndContext>
  );

  // ── Render: Step 2 — Filters & Parameters ─────────────────────────────────

  const renderStep2 = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Filters & Parameters</Typography>

      <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Default Filters</Typography>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
        Filters applied before grouping. They reduce the rows fed into the pivot.
      </Typography>
      {filters.map((f, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 180 }}>
            <Select inputProps={{ 'aria-label': 'Filter column' }} value={f.column_id} onChange={e => updateFilter(idx, 'column_id', e.target.value)}>
              {allColumns.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select inputProps={{ 'aria-label': 'Filter operator' }} value={f.operator} onChange={e => updateFilter(idx, 'operator', e.target.value)}>
              {FILTER_OPERATORS.map(op => (
                <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* 2026-09-04 -- Between has BOTH bounds; 2026-10-03 -- values are
              picked from the column (ReportFilterValueInput, shared with
              the tabular builder). */}
          <ReportFilterValueInput filter={f} index={idx} columns={allColumns}
            datasetId={selectedDatasetId}
            unfilled={filterProblems.some(p => p.startsWith(`Filter ${idx + 1} `))}
            onChange={(field, v) => updateFilter(idx, field, v)} />
          <IconButton aria-label="Delete" size="small" onClick={() => removeFilter(idx)}>
            <DeleteIcon fontSize="small" />
          </IconButton>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addFilter}>Add Filter</Button>
      {filterProblems.length > 0 && (
        <Alert severity="warning" sx={{ mt: 1 }} data-testid="unfilled-filters">
          {filterProblems.join(' ')}
        </Alert>
      )}

      <Divider sx={{ my: 3 }} />

      <Typography variant="subtitle2" sx={{ mb: 1 }}>Report Parameters</Typography>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
        Prompts shown when the user runs the report. Optional. Dropdown
        parameters can cascade — the parent's selection filters the child's
        list.
      </Typography>
      <ReportParameterEditor rows={params} onChange={setParams}
                             columns={allColumns}
                             datasetId={selectedDatasetId} />

      <Divider sx={{ my: 3 }} />

      <Typography variant="subtitle2" sx={{ mb: 1 }}>Row Limit</Typography>
      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
        Max grouped rows returned (after aggregation).
      </Typography>
      <TextField size="small" type="number" value={rowLimit}
        onChange={e => setRowLimit(Math.max(1, Number(e.target.value)))} sx={{ width: 150 }} />
    </Box>
  );

  // ── Render: Step 3 — Review & Save ────────────────────────────────────────

  const renderStep3 = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Review & Save</Typography>

      <TextField fullWidth label="Report Name" value={reportName}
        onChange={e => setReportName(e.target.value)} required sx={{ mb: 2 }} />
      <TextField fullWidth label="Description" value={reportDescription}
        onChange={e => setReportDescription(e.target.value)} multiline rows={2} sx={{ mb: 3 }} />

      <Paper elevation={1} sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" sx={{ mb: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
          <PivotIcon fontSize="small" /> Pivot Summary
        </Typography>
        <Divider sx={{ mb: 1 }} />
        <Typography variant="body2"><strong>Dataset:</strong> {dataset?.name || `#${selectedDatasetId}`}</Typography>
        <Typography variant="body2">
          <strong>Rows ({rowFieldIds.length}):</strong> {rowFieldIds.map(getColName).join(', ') || '(none)'}
        </Typography>
        <Typography variant="body2">
          <strong>Columns ({colFieldIds.length}):</strong> {colFieldIds.map(getColName).join(', ') || '(none)'}
        </Typography>
        <Typography variant="body2">
          <strong>Values ({valueFields.length}):</strong>{' '}
          {valueFields.map(vf => `${getColName(vf.column_id)} [${vf.aggregation.toUpperCase()}]`).join(', ') || '(none)'}
        </Typography>
        <Typography variant="body2">
          <strong>Filters:</strong> {filters.length} | <strong>Parameters:</strong> {params.length} |{' '}
          <strong>Row limit:</strong> {rowLimit.toLocaleString()}
        </Typography>
        <Typography variant="body2">
          <strong>Totals:</strong>{' '}
          {showRowTotals && 'rows '}{showColTotals && 'cols '}{showGrandTotal && 'grand'}
          {!showRowTotals && !showColTotals && !showGrandTotal && '(none)'}
        </Typography>
      </Paper>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
    </Box>
  );

  const renderStep = () => {
    switch (activeStep) {
      case 0: return renderStep0();
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      default: return null;
    }
  };

  // ── Top-level render ──────────────────────────────────────────────────────

  if (!limits.enabled) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="warning">Pivot reports are disabled by your administrator.</Alert>
      </Box>
    );
  }

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <IconButton aria-label="Back" onClick={() => navigate(REPORTS_PATH)}>
          <ArrowBackIcon />
        </IconButton>
        <PivotIcon sx={{ ml: 1, mr: 1, color: '#1976d2' }} />
        <Typography variant="h5">{isEdit ? 'Edit Pivot Report' : 'New Pivot Report'}</Typography>
      </Box>

      {/* 2026-10-23 -- a step is a BUTTON: while editing, any step (the name is
          on the last one); a new report goes back freely and forward only past
          completed steps. */}
      <Stepper nonLinear activeStep={activeStep} sx={{ mb: 3 }}>
        {WIZARD_STEPS.map((label, i) => {
          const reachable = isEdit || i <= activeStep
            || Array.from({ length: i }, (_, k) => k).every(k => canProceed(k));
          return (
            <Step key={label} completed={isEdit ? false : i < activeStep}>
              <StepButton onClick={() => setActiveStep(i)} disabled={!reachable}
                          data-testid={`report-step-${i}`}>{label}</StepButton>
            </Step>
          );
        })}
      </Stepper>

      {error && <Alert ref={errorRef} severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Paper elevation={2} sx={{ p: 3, mb: 2 }}>
        {renderStep()}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Button startIcon={<ArrowBackIcon />} disabled={activeStep === 0}
                onClick={() => setActiveStep(s => s - 1)}>
          Back
        </Button>
        {activeStep < WIZARD_STEPS.length - 1 ? (
          <Button variant="contained" endIcon={<ArrowForwardIcon />}
                  disabled={!canProceed(activeStep)}
                  onClick={() => setActiveStep(s => s + 1)}>
            Next
          </Button>
        ) : (
          <Button variant="contained" startIcon={<SaveIcon />}
                  disabled={saving || !canProceed(activeStep)} onClick={handleSave}>
            {saving ? 'Saving…' : (isEdit ? 'Update Report' : 'Save Pivot Report')}
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default PivotReportBuilder;
