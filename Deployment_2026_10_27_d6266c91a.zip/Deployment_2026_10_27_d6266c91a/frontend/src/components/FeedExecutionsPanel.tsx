/**
 * FeedExecutionsPanel — the Execution History, on the RUN STATUS page
 * (2026-09-14).
 *
 * Until now the full history lived under an expand arrow on /feeds, the
 * AUTHORING page, which mixed "how is my feed configured" with "what did
 * it do" — an operator's words: "Execution History should be on feed run
 * status not at config set up areas".  The Feeds page keeps one read-only
 * chip per feed (its latest execution) and links here.
 *
 * THE SEAM THIS PANEL RESPECTS.  The "Today" tab reads feed_runs, scoped
 * to ONE business date.  This panel reads feed_executions, across ALL
 * feeds and all dates — and that includes a manual "Run Now", which has
 * NO feed_run row and NO business date (feed_executor resolves a run only
 * when a business_date is supplied; the UI's Run Now sends none).  Such
 * an execution has nowhere to live on the Today tab, so it lives here,
 * labelled "Manual (Run Now)", with an em dash — never a blank cell — in
 * the business-date column and the reason on hover.  No fake business
 * date is ever invented for it.
 *
 * LIVE.  The engine broadcasts feed_started / feed_progress /
 * feed_completed / feed_failed / feed_cancelled over the websocket
 * (feed_engine._notify).  Every refresh here is a RE-FETCH of the list
 * (real DB state), never an optimistic patch:
 *   1. any feed_* event for a listed feed → silent re-fetch of THAT feed's
 *      executions, trailing-debounced (300ms) so a burst of feed_progress
 *      frames coalesces into one request;
 *   2. while any execution is pending/running, its feed is re-fetched
 *      every 5s regardless — so a dropped websocket cannot freeze it.
 *
 * THERE IS NO CROSS-FEED LIST ENDPOINT (GET /api/feeds/{id}/executions
 * is per feed), so the panel fans out one request per feed.  A feed
 * whose history could not be read is reported BY NAME as unreadable — a
 * partial answer is labelled partial, and a failure never renders as
 * "this feed has never run" (CLAUDE.md: unknown is not empty).
 *
 * THREE empty states, three renderings (they are different findings):
 *   - never run          → "This feed has never run." / "No feed has run yet."
 *   - fetch failed       → an error alert naming the failure, no table
 *   - filter has no hits → "No executions match this filter" + clear
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, FormControl, IconButton,
  InputLabel, MenuItem, Paper, Select, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, Tooltip, Typography,
} from '@mui/material';
import {
  CheckCircle as DoneIcon, Error as FailIcon,
  HourglassTop as PendingIcon, Block as SkipIcon,
  Schedule as RunningIcon, Cancel as CancelIcon,
  Replay as RetryIcon, Download as DownloadIcon,
  Terminal as TerminalIcon, ContentCopy as CopyIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import StepsIcon from '@mui/icons-material/FormatListNumbered';
import api from '../services/api';
import { cancelledWords, confirmStopRun, STOP_REQUESTED } from './feeds/stopRun';
import { openDownload } from '../services/api/core';
import { toArray } from '../utils/toArray';
import FeedRunStepsDialog from './FeedRunStepsDialog';

// ── Shape ────────────────────────────────────────────────────────────────

/** One feed_executions row, as GET /api/feeds/{id}/executions returns it. */
export interface FeedExecutionRow {
  id: number;
  feed_config_id: number;
  execution_id: string;
  status: string;
  execution_backend: string | null;
  trigger_type: string;
  triggered_by: string | null;
  started_at: string | null;
  completed_at: string | null;
  total_rows: number | null;
  file_size_bytes: number | null;
  output_format: string | null;
  output_filename: string | null;
  destination_path: string | null;
  /** 2026-10-07 -- the file the run PRODUCED on the shared output volume,
   *  recorded whether or not it was delivered (null on older rows). */
  artifact_path?: string | null;
  /** stage_timings.delivery_chain.verdict: 'delivered' | 'suppressed' |
   *  'dry_run' | 'failed'; null = none recorded (unknown, NOT delivered). */
  delivery_verdict?: string | null;
  /** Why there is NO downloadable file, when the run recorded it (a Spark
   *  run whose file stayed pod-local; a multi-file output). */
  artifact_unavailable_reason?: string | null;
  error_message: string | null;
  duration_seconds: number | null;
  /** 2026-10-26 -- who stopped the run and when (the cancel routes write
   *  them); `error_message` then carries what the stop reached. */
  cancelled_by?: string | null;
  cancelled_at?: string | null;
  /** The workload the execution ran as (spark_k8s: the SparkApplication /
   *  driver-pod name, `<name>-driver` on the cluster).  Only a pod-backed
   *  run has one; a native run is in-process and never creates a pod. */
  external_job_id?: string | null;
  /** null for a manual Run Now — it has no feed_run and no business date. */
  business_date?: string | null;
  files_metadata?: {
    backend_choice?: { backend?: string; reason?: string; failed_over?: boolean };
    [k: string]: any;
  } | null;
}

export interface FeedRef { id: number; name: string }

// ── Formatting — the numbers are the point ───────────────────────────────

export const isLiveStatus = (s: string | null | undefined): boolean =>
  s === 'pending' || s === 'running';

/** 500000 → "500,000".  null → "—" (unknown is not zero). */
export const formatRowCount = (n: number | null | undefined): string =>
  n == null || !Number.isFinite(n) ? '—' : Math.trunc(n).toLocaleString('en-US');

/** 23.4 → "23s"; 64.2 → "1m 04s"; 3725 → "1h 02m".  null → "—". */
export const formatDurationHuman = (seconds: number | null | undefined): string => {
  if (seconds == null || !Number.isFinite(seconds) || seconds < 0) return '—';
  const total = Math.round(seconds);
  if (total < 60) return `${total}s`;
  if (total < 3600) {
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${m}m ${String(s).padStart(2, '0')}s`;
  }
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return `${h}h ${String(m).padStart(2, '0')}m`;
};

const parseTs = (iso: string | null | undefined): number | null => {
  if (!iso) return null;
  // The server's isoformat() carries no zone for a naive UTC datetime;
  // read a zone-less stamp as UTC rather than as the browser's local time.
  const withZone = /[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`;
  const t = new Date(withZone).getTime();
  return Number.isFinite(t) ? t : null;
};

/** "just now" / "2m ago" / "3h ago" / "5d ago"; older → the UTC date.
 *  Unparseable → "—". */
export const formatRelative = (iso: string | null | undefined, now: number = Date.now()): string => {
  const t = parseTs(iso);
  if (t == null) return '—';
  const sec = Math.max(0, Math.round((now - t) / 1000));
  if (sec < 45) return 'just now';
  const min = Math.round(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  if (day < 7) return `${day}d ago`;
  return new Date(t).toISOString().slice(0, 10);
};

/** The absolute UTC stamp, for the hover. */
export const formatUtc = (iso: string | null | undefined): string => {
  const t = parseTs(iso);
  return t == null ? 'time unknown' : `${new Date(t).toISOString().replace('T', ' ').slice(0, 19)} UTC`;
};

/** The backend in human terms; the raw enum stays available on hover. */
export const BACKEND_LABELS: Record<string, string> = {
  spark_k8s: 'Spark pod',
  native: 'In-process',
  airflow: 'Airflow',
  spark_connect: 'Spark session',
};
export const backendLabel = (backend: string | null | undefined): string =>
  backend ? (BACKEND_LABELS[backend] ?? backend) : 'backend unknown';

/** A run that executes on a pod: the only kind that has one to look for. */
export const runsOnPod = (backend: string | null | undefined): boolean =>
  backend === 'spark_k8s' || backend === 'airflow';

/** Scheduled vs manual — the distinction a user could not see.  A
 *  manual Run Now (trigger 'manual') runs with no feed_run and no
 *  business date; everything else was fired against a run record. */
export const triggerKind = (trigger: string | null | undefined): { kind: 'manual' | 'scheduled' | 'dry_run'; label: string } => {
  const t = String(trigger || '').toLowerCase();
  if (t === 'manual') return { kind: 'manual', label: 'Manual (Run Now)' };
  // 2026-09-27 -- a dry run is a manual run that delivered NOTHING
  if (t === 'dry_run') return { kind: 'dry_run', label: 'Dry run (nothing delivered)' };
  if (t === 'retry') return { kind: 'scheduled', label: 'Retry' };
  if (t === 'rerun') return { kind: 'scheduled', label: 'Rerun' };
  if (t === 'backfill') return { kind: 'scheduled', label: 'Backfill' };
  return { kind: 'scheduled', label: 'Scheduled' };
};

export const MANUAL_NO_DATE_REASON =
  'A manual Run Now does not create a scheduled run record, so it has no business date.';

/** 2026-10-07 -- a COMPLETED run that delivered nothing BY DESIGN: a
 *  backfill launched without delivery (or a policy) suppressed every hop,
 *  or a dry run.  It completes like any run, so without this marker it
 *  read as an ordinary green "completed" -- as if the counterparty had
 *  the file.  null when the run delivered, failed, or recorded no verdict
 *  (unknown is never shown as delivered OR as not delivered). */
export const notDeliveredNote = (
  exec: Pick<FeedExecutionRow, 'status' | 'delivery_verdict'>,
): { label: string; reason: string } | null => {
  if (exec.status !== 'completed') return null;
  if (exec.delivery_verdict === 'suppressed') {
    return {
      label: 'NOT DELIVERED',
      reason: 'Delivery was suppressed for this run (a backfill launched without delivery, or a '
        + 'suppression policy): the file was produced and kept on the server — Download it here — '
        + 'but nothing was sent to the destination. Retry the delivery hop to send it.',
    };
  }
  if (exec.delivery_verdict === 'dry_run') {
    return {
      label: 'NOT DELIVERED (DRY RUN)',
      reason: 'A dry run: the whole chain ran and nothing was sent to the destination. '
        + 'The produced file can be downloaded here.',
    };
  }
  return null;
};

/** The execution has a file on the server to download: where it went
 *  (a local destination) or what it produced (kept whether or not it
 *  was delivered).  The server confines both to the output volume. */
export const hasDownloadableFile = (
  exec: Pick<FeedExecutionRow, 'status' | 'destination_path' | 'artifact_path'>,
): boolean => exec.status === 'completed' && Boolean(exec.artifact_path || exec.destination_path);

const STATUS_COLOR: Record<string, 'success' | 'error' | 'warning' | 'info' | 'default'> = {
  completed: 'success', failed: 'error', running: 'info', pending: 'warning',
  cancelled: 'default', skipped: 'default',
};
const STATUS_ICON: Record<string, React.ReactElement> = {
  completed: <DoneIcon />, failed: <FailIcon />, running: <RunningIcon />,
  pending: <PendingIcon />, cancelled: <CancelIcon />, skipped: <SkipIcon />,
};

/** Colour AND the word, together — never colour alone. */
export const ExecutionStatusChip: React.FC<{ status: string; 'data-testid'?: string }> = ({ status, ...rest }) => (
  <Chip
    size="small"
    label={status || 'unknown'}
    color={STATUS_COLOR[status] || 'default'}
    icon={STATUS_ICON[status]}
    variant="filled"
    sx={{ fontWeight: 500, textTransform: 'uppercase', fontSize: '0.7rem' }}
    {...rest}
  />
);

/** A re-render tick so "2m ago" ages on screen. */
export const useNowTick = (everyMs = 30_000): number => {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), everyMs);
    return () => window.clearInterval(id);
  }, [everyMs]);
  return now;
};

const dayOf = (iso: string | null | undefined): string => {
  const t = parseTs(iso);
  return t == null ? 'unknown' : new Date(t).toISOString().slice(0, 10);
};
const dayLabel = (day: string, now: number): string => {
  if (day === 'unknown') return 'Start time unknown';
  const today = new Date(now).toISOString().slice(0, 10);
  const yesterday = new Date(now - 86_400_000).toISOString().slice(0, 10);
  if (day === today) return `Today · ${day}`;
  if (day === yesterday) return `Yesterday · ${day}`;
  return day;
};

// ── The panel ────────────────────────────────────────────────────────────

type WsListener = (cb: (msg: any) => void) => () => void;

interface Props {
  /** Deep link `?feed=<id>`: preselect this feed in the filter. */
  initialFeedId?: number | null;
  /** The page's websocket subscription (useWebSocket().addListener).
   *  Optional: without one the 5s poll is the whole live mechanism. */
  addListener?: WsListener | null;
  /** Open the live log tail for an execution (the Today page owns it). */
  onOpenLog?: (execDbId: number) => void;
}

type RowWithFeed = FeedExecutionRow & { feed_name: string };

const EXEC_PAGE = 100;

const FeedExecutionsPanel: React.FC<Props> = ({ initialFeedId = null, addListener = null, onOpenLog }) => {
  const [feeds, setFeeds] = useState<FeedRef[] | null>(null);
  const [feedsError, setFeedsError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [execsByFeed, setExecsByFeed] = useState<Record<number, FeedExecutionRow[]>>({});
  // Per-feed read failures, kept SEPARATE from the rows so a failed feed
  // can never be mistaken for a feed with no history.
  const [fetchErrors, setFetchErrors] = useState<Record<number, string>>({});
  const [feedFilter, setFeedFilter] = useState<number | ''>(initialFeedId ?? '');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [stepsExec, setStepsExec] = useState<RowWithFeed | null>(null);
  const [notice, setNotice] = useState<{ severity: 'success' | 'error'; text: string } | null>(null);
  const now = useNowTick(30_000);

  // A deep link that arrives after mount (the user pastes a new URL onto
  // an open page) still lands on the feed it names.
  useEffect(() => { if (initialFeedId != null) setFeedFilter(initialFeedId); }, [initialFeedId]);

  const feedsRef = useRef<FeedRef[]>([]);

  const loadFeedExecs = useCallback(async (feedId: number) => {
    try {
      const data = await api.listFeedExecutions(feedId, EXEC_PAGE);
      const rows = toArray(data) as FeedExecutionRow[];
      setExecsByFeed(prev => ({ ...prev, [feedId]: rows }));
      setFetchErrors(prev => {
        if (!(feedId in prev)) return prev;
        const next = { ...prev };
        delete next[feedId];
        return next;
      });
    } catch (e: any) {
      setFetchErrors(prev => ({ ...prev, [feedId]: e?.message || String(e) }));
    }
  }, []);

  const loadAll = useCallback(async () => {
    setLoading(true);
    setFeedsError(null);
    try {
      const raw = await api.listFeeds();
      const list = (toArray(raw) as any[])
        .filter(f => f && Number.isFinite(Number(f.id)))
        .map(f => ({ id: Number(f.id), name: String(f.name ?? `feed #${f.id}`) }));
      feedsRef.current = list;
      setFeeds(list);
      await Promise.all(list.map(f => loadFeedExecs(f.id)));
    } catch (e: any) {
      setFeedsError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [loadFeedExecs]);

  useEffect(() => { void loadAll(); }, [loadAll]);

  // 1. websocket → debounced silent re-fetch of the feed the event names.
  // The debounce timers live in a ref, NOT in the subscription effect:
  // a re-subscribe (the parent re-rendering with a new addListener
  // identity) must not cancel a re-fetch that is already scheduled.
  // Found by the test that starts from a TERMINAL row, where the poll
  // cannot mask a lost event.
  const timersRef = useRef<Map<number, number>>(new Map());
  useEffect(() => () => {
    timersRef.current.forEach(id => window.clearTimeout(id));
    timersRef.current.clear();
  }, []);
  useEffect(() => {
    if (!addListener) return undefined;
    const timers = timersRef.current;
    const unsub = addListener((msg) => {
      try {
        const t = String((msg as any)?.type || '');
        if (!t.startsWith('feed_')) return;
        const feedId = Number((msg as any).feed_id);
        if (!feedId || !feedsRef.current.some(f => f.id === feedId)) return;
        const prev = timers.get(feedId);
        if (prev != null) window.clearTimeout(prev);
        timers.set(feedId, window.setTimeout(() => {
          timers.delete(feedId);
          void loadFeedExecs(feedId);
        }, 300));
      } catch { /* fail-open */ }
    });
    return unsub;
  }, [addListener, loadFeedExecs]);

  // 2. 5s poll for every feed with a live execution.
  const liveKey = useMemo(() => Object.entries(execsByFeed)
    .filter(([, rows]) => rows.some(r => isLiveStatus(r.status)))
    .map(([id]) => id).sort().join(','), [execsByFeed]);
  useEffect(() => {
    if (!liveKey) return undefined;
    const ids = liveKey.split(',').map(Number);
    const id = window.setInterval(() => { ids.forEach(f => void loadFeedExecs(f)); }, 5000);
    return () => window.clearInterval(id);
  }, [liveKey, loadFeedExecs]);

  // ── Derived rows ────────────────────────────────────────────────────
  const allRows = useMemo<RowWithFeed[]>(() => {
    const out: RowWithFeed[] = [];
    for (const f of feeds ?? []) {
      for (const e of execsByFeed[f.id] ?? []) out.push({ ...e, feed_name: f.name });
    }
    // Newest first; ties (same second) by id so the order is stable.
    out.sort((a, b) => ((parseTs(b.started_at) ?? 0) - (parseTs(a.started_at) ?? 0)) || (b.id - a.id));
    return out;
  }, [feeds, execsByFeed]);
  const feedScoped = useMemo(
    () => (feedFilter === '' ? allRows : allRows.filter(r => r.feed_config_id === feedFilter)),
    [allRows, feedFilter]);
  const visible = useMemo(
    () => (statusFilter ? feedScoped.filter(r => r.status === statusFilter) : feedScoped),
    [feedScoped, statusFilter]);
  const spansDays = useMemo(() => new Set(visible.map(r => dayOf(r.started_at))).size > 1, [visible]);

  const failedFeeds = useMemo(() => (feeds ?? [])
    .filter(f => f.id in fetchErrors)
    .map(f => ({ ...f, error: fetchErrors[f.id] })), [feeds, fetchErrors]);
  const selectedFeedUnreadable = feedFilter !== '' && feedFilter in fetchErrors;
  const knownFeed = feedFilter === '' || (feeds?.some(f => f.id === feedFilter) ?? false);

  // ── Actions (carried over from the old panel) ──────────────────────
  const handleRetry = async (exec: RowWithFeed) => {
    try {
      await api.retryFeedExecution(exec.id);
      setNotice({ severity: 'success', text: `Retry started for ${exec.feed_name}` });
      void loadFeedExecs(exec.feed_config_id);
    } catch (e: any) {
      setNotice({ severity: 'error', text: e?.message || 'Retry failed' });
    }
  };
  const handleCancel = async (exec: RowWithFeed) => {
    // 2026-10-26 -- the same question everywhere a running feed is shown;
    // the server stops the query at the source and says what it reached
    if (!confirmStopRun(exec.feed_name)) return;
    try {
      await api.cancelFeedExecution(exec.id);
      setNotice({ severity: 'success', text: `${exec.feed_name}: ${STOP_REQUESTED}` });
      void loadFeedExecs(exec.feed_config_id);
    } catch (e: any) {
      setNotice({ severity: 'error', text: e?.message || 'Cancel failed' });
    }
  };
  // 2026-10-07 -- an AUTHENTICATED fetch through the configured API base.
  // This was window.open('/api/...'): a relative URL (wrong host on a
  // split-host deployment) that carries no Authorization header (a 401
  // with login on) -- and its failure was a blank tab, not a message.
  const handleDownload = async (exec: RowWithFeed) => {
    try {
      await openDownload(`/api/feed-executions/${exec.id}/download`);
    } catch (e: any) {
      setNotice({ severity: 'error', text: `Download failed for ${exec.feed_name}: ${e?.message || 'unknown error'}` });
    }
  };
  const copyText = (text: string) => {
    try { void navigator.clipboard?.writeText(text); } catch { /* clipboard unavailable */ }
  };

  const clearFilters = () => { setFeedFilter(''); setStatusFilter(''); };

  // ── Render ──────────────────────────────────────────────────────────
  const renderEmpty = () => {
    if (selectedFeedUnreadable) {
      return (
        <Alert severity="error" data-testid="exec-empty-error"
               action={<Button size="small" color="inherit" onClick={() => void loadFeedExecs(feedFilter as number)}>Retry</Button>}>
          The history for this feed could not be loaded — {fetchErrors[feedFilter as number]}. This is not "never run".
        </Alert>
      );
    }
    if (feedFilter !== '' && feeds != null && !knownFeed) {
      return (
        <Stack direction="row" spacing={1} alignItems="center" sx={{ p: 2 }} data-testid="exec-empty-unknown-feed">
          <Typography variant="body2" color="text.secondary">
            Feed #{feedFilter} is not in the feed list, so there is no history to show for it — it may have been deleted, or the link is stale.
          </Typography>
          <Button size="small" onClick={clearFilters}>Show all feeds</Button>
        </Stack>
      );
    }
    if (feedScoped.length === 0) {
      return (
        <Typography variant="body2" color="text.secondary" data-testid="exec-empty-never" sx={{ p: 2 }}>
          {feedFilter === '' ? 'No feed has run yet.' : 'This feed has never run.'}
        </Typography>
      );
    }
    return (
      <Stack direction="row" spacing={1} alignItems="center" sx={{ p: 2 }} data-testid="exec-empty-filtered">
        <Typography variant="body2" color="text.secondary">No executions match this filter.</Typography>
        <Button size="small" onClick={clearFilters}>Clear filter</Button>
      </Stack>
    );
  };

  const renderRow = (exec: RowWithFeed) => {
    const kind = triggerKind(exec.trigger_type);
    const onPod = runsOnPod(exec.execution_backend);
    const bc = exec.files_metadata?.backend_choice;
    const notDelivered = notDeliveredNote(exec);
    return (
      <TableRow key={exec.id} hover data-testid={`exec-row-${exec.id}`}>
        <TableCell>
          <Typography variant="body2" fontWeight={500}>{exec.feed_name}</Typography>
          <Typography variant="caption" component="span" sx={{ fontFamily: 'monospace', color: 'text.secondary', wordBreak: 'break-all' }}>
            {exec.execution_id}
          </Typography>
        </TableCell>
        <TableCell>
          <Tooltip title={`trigger: ${exec.trigger_type || 'unknown'}${exec.triggered_by ? ` · by ${exec.triggered_by}` : ''}`}>
            <Chip size="small" variant="outlined"
                  color={kind.kind === 'dry_run' ? 'warning' : kind.kind === 'manual' ? 'secondary' : 'primary'}
                  label={kind.label}
                  data-testid={`exec-kind-${exec.id}`}
                  sx={{ height: 20, fontSize: '0.65rem' }} />
          </Tooltip>
          <Box data-testid={`exec-bdate-${exec.id}`} sx={{ mt: 0.25 }}>
            {exec.business_date ? (
              <Typography variant="caption">{exec.business_date}</Typography>
            ) : (
              <Tooltip title={kind.kind !== 'scheduled' ? MANUAL_NO_DATE_REASON : 'This execution recorded no business date.'}>
                <Typography variant="caption" color="text.secondary" sx={{ cursor: 'help' }}>— no business date</Typography>
              </Tooltip>
            )}
          </Box>
        </TableCell>
        <TableCell>
          <ExecutionStatusChip status={exec.status} data-testid={`exec-status-${exec.id}`} />
          {notDelivered && (
            <Tooltip title={notDelivered.reason}>
              <Chip size="small" color="warning" variant="outlined" label={notDelivered.label}
                    data-testid={`exec-not-delivered-${exec.id}`}
                    sx={{ ml: 0.5, height: 20, fontSize: '0.6rem', fontWeight: 700, cursor: 'help' }} />
            </Tooltip>
          )}
          {exec.error_message && (
            <Tooltip title={exec.error_message}>
              <Typography variant="caption" color="error" noWrap display="block" sx={{ maxWidth: 220 }}>
                {exec.error_message.slice(0, 80)}
              </Typography>
            </Tooltip>
          )}
        </TableCell>
        <TableCell align="right" sx={{ fontVariantNumeric: 'tabular-nums' }}>
          {isLiveStatus(exec.status) && !exec.total_rows ? '…' : formatRowCount(exec.total_rows)}
        </TableCell>
        <TableCell>
          <Tooltip title={`${exec.execution_backend || 'unknown'}${bc?.reason ? ` — routing: ${bc.reason}` : ''}`}>
            <Chip size="small" variant="outlined" label={backendLabel(exec.execution_backend)}
                  color={bc?.failed_over ? 'warning' : 'default'}
                  sx={{ height: 20, fontSize: '0.65rem', cursor: 'help' }} />
          </Tooltip>
        </TableCell>
        <TableCell sx={{ maxWidth: 220 }} data-testid={`exec-pod-${exec.id}`}>
          {exec.external_job_id ? (
            <Stack direction="row" spacing={0.25} alignItems="center">
              <Tooltip title={exec.execution_backend === 'spark_k8s'
                ? `SparkApplication ${exec.external_job_id}; driver pod ${exec.external_job_id}-driver (kubectl get pod ${exec.external_job_id}-driver -n spark)`
                : exec.external_job_id}>
                <Typography variant="caption" component="span" data-testid={`exec-job-${exec.id}`}
                  sx={{ fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'block', maxWidth: 180 }}>
                  {exec.external_job_id}
                </Typography>
              </Tooltip>
              <Tooltip title="Copy pod name">
                <IconButton size="small" onClick={() => copyText(exec.external_job_id!)} aria-label={`copy pod name for execution ${exec.id}`}>
                  <CopyIcon sx={{ fontSize: 14 }} />
                </IconButton>
              </Tooltip>
            </Stack>
          ) : onPod ? (
            <Tooltip title="This backend runs on a pod, but no pod name was recorded for this execution.">
              <Typography variant="caption" color="text.secondary" sx={{ cursor: 'help' }}>— pod name not recorded</Typography>
            </Tooltip>
          ) : (
            <Tooltip title={`${backendLabel(exec.execution_backend)} (${exec.execution_backend || 'unknown'}) runs inside the API/worker process. There is no pod or container to look for.`}>
              <Typography variant="caption" color="text.secondary" sx={{ cursor: 'help' }}>ran in-process (no pod)</Typography>
            </Tooltip>
          )}
        </TableCell>
        <TableCell>
          <Tooltip title={formatUtc(exec.started_at)}>
            <Typography variant="body2" component="span" sx={{ cursor: 'help' }}>{formatRelative(exec.started_at, now)}</Typography>
          </Tooltip>
        </TableCell>
        <TableCell sx={{ fontVariantNumeric: 'tabular-nums' }}>
          {isLiveStatus(exec.status) && exec.duration_seconds == null
            ? formatDurationHuman(exec.started_at ? (now - (parseTs(exec.started_at) ?? now)) / 1000 : null)
            : formatDurationHuman(exec.duration_seconds)}
        </TableCell>
        <TableCell align="right">
          <Stack direction="row" spacing={0} justifyContent="flex-end">
            {exec.status === 'failed' && (
              <Tooltip title="Retry">
                <IconButton size="small" onClick={() => void handleRetry(exec)} aria-label={`retry execution ${exec.id}`}>
                  <RetryIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {isLiveStatus(exec.status) && (
              <Tooltip title="Stop this run — the query at the source is stopped too; nothing is delivered">
                <IconButton size="small" onClick={() => void handleCancel(exec)} aria-label={`cancel execution ${exec.id}`}>
                  <CancelIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {exec.status === 'cancelled' && (
              <Tooltip title={exec.error_message || cancelledWords(exec.cancelled_by, exec.cancelled_at)}>
                <Typography variant="caption" sx={{ alignSelf: 'center', color: 'warning.main', whiteSpace: 'nowrap' }}
                            data-testid={`exec-cancelled-${exec.id}`}>
                  {cancelledWords(exec.cancelled_by, exec.cancelled_at)}
                </Typography>
              </Tooltip>
            )}
            {isLiveStatus(exec.status) && onOpenLog && (
              <Tooltip title="Live log tail">
                <IconButton size="small" onClick={() => onOpenLog(exec.id)} aria-label={`live log for execution ${exec.id}`}>
                  <TerminalIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            <Tooltip title="Steps — the run's step sequence (recorded rows, or the timing projection); the Spark driver log is inside">
              <IconButton size="small" data-testid={`exec-steps-${exec.id}`} onClick={() => setStepsExec(exec)}
                          aria-label={`steps for execution ${exec.id}`}>
                <StepsIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            {hasDownloadableFile(exec) && (
              <Tooltip title={notDelivered ? 'Download the produced file (it was not delivered)' : 'Download'}>
                <IconButton size="small" aria-label={`download execution ${exec.id}`}
                            data-testid={`exec-download-${exec.id}`}
                            onClick={() => void handleDownload(exec)}>
                  <DownloadIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {exec.status === 'completed' && !hasDownloadableFile(exec) && exec.artifact_unavailable_reason && (
              <Tooltip title={`No download: ${exec.artifact_unavailable_reason}`}>
                <span data-testid={`exec-no-download-${exec.id}`}>
                  <IconButton size="small" disabled aria-label={`no download for execution ${exec.id}: ${exec.artifact_unavailable_reason}`}>
                    <DownloadIcon fontSize="small" />
                  </IconButton>
                </span>
              </Tooltip>
            )}
          </Stack>
        </TableCell>
      </TableRow>
    );
  };

  const body: React.ReactNode[] = [];
  let lastDay: string | null = null;
  for (const exec of visible) {
    const day = dayOf(exec.started_at);
    if (spansDays && day !== lastDay) {
      lastDay = day;
      body.push(
        <TableRow key={`day-${day}`} data-testid={`exec-day-${day}`}>
          <TableCell colSpan={9} sx={{ bgcolor: 'action.hover', py: 0.5 }}>
            <Typography variant="overline" sx={{ letterSpacing: 1 }}>{dayLabel(day, now)}</Typography>
          </TableCell>
        </TableRow>,
      );
    }
    body.push(renderRow(exec));
  }

  return (
    <Box data-testid="feed-executions-panel">
      {notice && (
        <Alert severity={notice.severity} onClose={() => setNotice(null)} sx={{ mb: 2 }}>{notice.text}</Alert>
      )}

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" spacing={2} alignItems="center" sx={{ flexWrap: 'wrap', rowGap: 1.5 }} useFlexGap>
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel id="exec-feed-filter-label">Feed</InputLabel>
            <Select labelId="exec-feed-filter-label" label="Feed" value={feedFilter}
                    inputProps={{ 'data-testid': 'exec-feed-filter' }}
                    onChange={e => { const v = e.target.value as unknown; setFeedFilter(v === '' || v == null ? '' : Number(v)); }}>
              <MenuItem value="">All feeds</MenuItem>
              {/* A deep-linked feed the list does not (yet) contain still
                  has an option, so the filter says what it is filtering
                  to rather than displaying "All feeds" over an empty table. */}
              {feedFilter !== '' && !knownFeed && (
                <MenuItem value={feedFilter}>
                  {feeds == null ? `feed #${feedFilter}` : `feed #${feedFilter} (not in the feed list)`}
                </MenuItem>
              )}
              {(feeds ?? []).map(f => <MenuItem key={f.id} value={f.id}>{f.name}</MenuItem>)}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel id="exec-status-filter-label">Status</InputLabel>
            <Select labelId="exec-status-filter-label" label="Status" value={statusFilter}
                    inputProps={{ 'data-testid': 'exec-status-filter' }}
                    onChange={e => setStatusFilter(String(e.target.value))}>
              <MenuItem value="">All statuses</MenuItem>
              {['pending', 'running', 'completed', 'failed', 'cancelled'].map(s => (
                <MenuItem key={s} value={s}>{s}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Typography variant="caption" color="text.secondary">
            {visible.length.toLocaleString('en-US')} of {allRows.length.toLocaleString('en-US')} executions · newest first · live
          </Typography>
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Re-read every feed's history now (the list also refreshes on engine events and polls while a run is live)">
            <span>
              <IconButton size="small" onClick={() => void loadAll()} disabled={loading} aria-label="refresh executions">
                <RefreshIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
        </Stack>
      </Paper>

      {feedsError && (
        <Alert severity="error" sx={{ mb: 2 }} data-testid="exec-feeds-error"
               action={<Button size="small" color="inherit" onClick={() => void loadAll()}>Retry</Button>}>
          The feed list could not be loaded, so no history can be shown — {feedsError}
        </Alert>
      )}
      {!feedsError && failedFeeds.length > 0 && !selectedFeedUnreadable && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="exec-partial-error"
               action={<Button size="small" color="inherit" onClick={() => failedFeeds.forEach(f => void loadFeedExecs(f.id))}>Retry</Button>}>
          What is shown is PARTIAL — the history of {failedFeeds.length === 1 ? 'one feed' : `${failedFeeds.length} feeds`} could not be read:{' '}
          {failedFeeds.map(f => `${f.name} (${f.error})`).join('; ')}
        </Alert>
      )}

      {loading && feeds == null ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>
      ) : feedsError ? null : visible.length === 0 ? (
        <Paper>{renderEmpty()}</Paper>
      ) : (
        <Paper sx={{ overflowX: 'auto' }}>
          <Table size="small" sx={{ minWidth: 900 }}>
            <TableHead>
              <TableRow>
                <TableCell>Feed</TableCell>
                <TableCell>
                  <Tooltip title="Scheduled = fired against a run record for a business date. Manual (Run Now) = fired from the Feeds page, with no run record and no business date.">
                    <span style={{ cursor: 'help' }}>Type · business date</span>
                  </Tooltip>
                </TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell>
                  <Tooltip title="Where the query ran. Hover a value for the raw backend name.">
                    <span style={{ cursor: 'help' }}>Backend</span>
                  </Tooltip>
                </TableCell>
                <TableCell>
                  <Tooltip title="The SparkApplication / driver pod this execution ran as (external_job_id). Only a Spark-backed run has one; an in-process run never creates a pod.">
                    <span style={{ cursor: 'help' }}>Spark pod</span>
                  </Tooltip>
                </TableCell>
                <TableCell>Started</TableCell>
                <TableCell>Duration</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>{body}</TableBody>
          </Table>
        </Paper>
      )}

      <FeedRunStepsDialog
        runId={null}
        executionId={stepsExec?.id ?? null}
        runName={stepsExec ? `${stepsExec.feed_name} · ${stepsExec.execution_id}` : null}
        onClose={() => setStepsExec(null)}
      />
    </Box>
  );
};

export default FeedExecutionsPanel;
