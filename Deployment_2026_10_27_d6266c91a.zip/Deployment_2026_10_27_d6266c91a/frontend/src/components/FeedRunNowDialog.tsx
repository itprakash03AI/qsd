/**
 * FeedRunNowDialog — Run Now with a PREFLIGHT (2026-09-27).
 *
 * Takes a business date (default today UTC) and shows, for that date, each
 * dependency's verdict and reason from GET /api/feeds/{id}/run-preflight —
 * THE gate the poller and the skip routes read; nothing is inferred here.
 *
 * "Run anyway" stays NON-blocking: Run Now is explicit operator intent.
 * When anything is not met (or the gate could not be read) a reason is
 * REQUIRED — the same category + free text as a dependency skip — and the
 * run is recorded as `dependencies_overridden`.  When the gate admits the
 * date, no reason is asked for.
 *
 * The parent owns the actual execute call (it also carries the Dynamic
 * WHERE overrides it renders as `children`); this dialog hands it the
 * business date and the reason.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions,
  DialogContent, DialogTitle, Stack, TextField, Tooltip, Typography,
} from '@mui/material';
import { PlayArrow as RunIcon, Warning as WarnIcon } from '@mui/icons-material';
import api from '../services/api';
import type { FeedRunPreflight, RunNowOptions } from '../services/api/feeds';
import SkipReasonFields, { useSkipReason } from './common/SkipReasonFields';

export interface RunNowFeedRef { id: number; name?: string | null }

interface Props {
  feed: RunNowFeedRef | null;
  onClose: () => void;
  /** Called with the date and (when required) the reason; the parent
   *  fires POST /api/feeds/{id}/execute and closes the dialog. */
  onRun: (opts: RunNowOptions) => void | Promise<void>;
  /** The Dynamic WHERE override inputs, rendered by the parent. */
  children?: React.ReactNode;
}

const todayUtc = () => new Date().toISOString().slice(0, 10);

const verdictWord = (v: string): string => {
  switch (v) {
    case 'met': return 'met';
    case 'not_met': return 'not met';
    case 'could_not_tell': return "can't check right now";
    case 'not_expected': return 'not expected';
    default: return String(v || 'unknown').split('_').join(' ');
  }
};
const verdictColor = (v: string): 'success' | 'warning' | 'default' | 'error' => {
  if (v === 'met' || v === 'not_expected') return 'success';
  if (v === 'not_met') return 'warning';
  if (v === 'could_not_tell') return 'error';
  return 'default';
};

const FeedRunNowDialog: React.FC<Props> = ({ feed, onClose, onRun, children }) => {
  const [businessDate, setBusinessDate] = useState(todayUtc());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preflight, setPreflight] = useState<FeedRunPreflight | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const reason = useSkipReason();

  const load = useCallback(async (feedId: number, bd: string) => {
    setLoading(true);
    setError(null);
    try {
      setPreflight(await api.getFeedRunPreflight(feedId, bd));
    } catch (e: any) {
      setPreflight(null);
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  // Reset per feed; re-preflight on every date change.
  useEffect(() => {
    if (feed) { setBusinessDate(todayUtc()); reason.reset(); setError(null); setPreflight(null); }
  }, [feed?.id]);  // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (feed && /^\d{4}-\d{2}-\d{2}$/.test(businessDate)) void load(feed.id, businessDate);
  }, [feed?.id, businessDate, load]);  // eslint-disable-line react-hooks/exhaustive-deps

  // A reason is required only for a dependency the gate READ and found not
  // met.  A preflight that could not be fetched, or a gate that could not
  // be read, is said in plain words and the run still goes (the server
  // fails open on it, loudly) -- unreadable is not "not met".
  const overrideRequired = preflight?.override_required ?? false;
  const canSubmit = !submitting && !loading && !!feed
    && /^\d{4}-\d{2}-\d{2}$/.test(businessDate)
    && (!overrideRequired || reason.valid);

  const submit = async () => {
    if (!feed || !canSubmit) return;
    setSubmitting(true);
    try {
      const opts: RunNowOptions = { business_date: businessDate };
      if (overrideRequired) {
        opts.override_reason_category = reason.body.reason_category;
        opts.override_reason = reason.body.reason;
      }
      await onRun(opts);
    } finally {
      setSubmitting(false);
    }
  };

  const verdicts = preflight?.verdicts ?? [];
  return (
    <Dialog open={feed != null} onClose={submitting ? undefined : onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Run feed: {feed?.name || ''}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ pt: 1 }}>
          <TextField
            label="Business date"
            type="date"
            value={businessDate}
            onChange={e => setBusinessDate(e.target.value)}
            size="small"
            InputLabelProps={{ shrink: true }}
            inputProps={{ 'data-testid': 'run-now-date' }}
            helperText="The date the run is for (its dependencies are checked for this date)."
          />

          <Box data-testid="run-now-preflight">
            <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                Dependencies for {businessDate}
              </Typography>
              {loading && <CircularProgress size={14} />}
            </Stack>
            {error && (
              <Alert severity="warning" data-testid="run-now-preflight-error">
                The dependency check could not be read ({error}). Running now
                proceeds UNCHECKED — the run does not wait for anything.
              </Alert>
            )}
            {!error && preflight && !preflight.has_dependencies && (
              <Typography variant="body2" color="text.secondary" data-testid="run-now-no-deps">
                This feed declares no dependencies.
              </Typography>
            )}
            {!error && preflight?.unavailable && (
              <Alert severity="warning" data-testid="run-now-gate-unavailable">
                The dependency gate could not be read: {preflight.unavailable}. Running
                now proceeds UNCHECKED — the run does not wait for anything.
              </Alert>
            )}
            {!error && verdicts.length > 0 && (
              <Stack spacing={0.5}>
                {verdicts.map(v => (
                  <Stack key={v.dependency_name} direction="row" spacing={1} alignItems="flex-start"
                    data-testid={`run-now-verdict-${v.dependency_name}`}>
                    <Tooltip title={v.reason || ''}>
                      <Chip size="small" variant="outlined" color={verdictColor(v.verdict)}
                        label={verdictWord(v.verdict)} sx={{ minWidth: 96, height: 20, fontSize: '0.66rem' }} />
                    </Tooltip>
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{v.dependency_name}</Typography>
                      <Typography variant="caption" color="text.secondary">{v.reason}</Typography>
                    </Box>
                  </Stack>
                ))}
              </Stack>
            )}
            {!error && preflight && preflight.has_dependencies && preflight.admitted && (
              <Alert severity="success" sx={{ mt: 1, py: 0 }} data-testid="run-now-admitted">
                Every dependency is met{preflight.asserted ? ' (at least one by an operator assertion)' : ''}.
              </Alert>
            )}
          </Box>

          {overrideRequired && (
            <Box data-testid="run-now-override">
              <Alert severity="warning" icon={<WarnIcon />} sx={{ mb: 1.5 }}>
                <strong>Running anyway.</strong> {preflight?.blocking?.length
                  ? <>Not met for {businessDate}: <strong>{preflight.blocking.join(', ')}</strong>. </>
                  : null}
                The run is yours to start, but it is recorded with your name and the
                reason below — the timeline will say the run went on intent, not on
                evidence.
              </Alert>
              <SkipReasonFields
                state={reason}
                disabled={submitting}
                textTestId="run-now-reason"
                categoryTestId="run-now-reason-category"
                textLabel="Why run without these inputs? (required)"
              />
            </Box>
          )}

          {children}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={submitting}>Cancel</Button>
        <Button
          variant="contained"
          color={overrideRequired ? 'warning' : 'primary'}
          startIcon={submitting ? <CircularProgress size={14} /> : <RunIcon />}
          onClick={() => void submit()}
          disabled={!canSubmit}
          data-testid="run-now-go"
        >
          {overrideRequired ? 'Run anyway' : 'Run Feed'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FeedRunNowDialog;
