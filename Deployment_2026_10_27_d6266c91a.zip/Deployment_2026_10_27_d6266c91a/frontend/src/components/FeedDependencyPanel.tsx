/**
 * FeedDependencyPanel — the REVERSE dependency index (2026-09-02).
 *
 * The run table answers "what is this feed waiting on".  This panel
 * answers the opposite question: "what is APAC_POSITIONS holding up?"
 * One row per blocking dependency, the count of feeds it blocks as the
 * headline number, which feeds those are, how long it has been waiting,
 * and the TIGHTEST SLA among the blocked feeds.
 *
 * Driven by GET /api/feed-dependencies/blocking (fetched by the parent
 * page, which also uses the same data for dependency grouping — one
 * fetch, two consumers).  The parent passes {loading, error, data} so
 * this panel can honour the non-negotiable rule: a FAILED load must
 * never render like "nothing is blocked".
 *
 * The "Skip for all" action (POST /api/feed-dependencies/{key}/skip)
 * lets every feed waiting on the dependency proceed WITHOUT that input
 * confirmed — the dialog says exactly that, names the dependency,
 * shows how many feeds are affected, and refuses to enable Confirm
 * until a reason is typed.
 */
import React, { useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Dialog,
  DialogActions, DialogContent, DialogTitle, IconButton, Paper, Stack,
  Tooltip, Typography,
} from '@mui/material';
import {
  ExpandMore as ExpandIcon, ExpandLess as CollapseIcon,
  Replay as RetryIcon, Warning as WarnIcon,
  RemoveCircleOutline as SkipDepIcon,
  AccountTree as DepIcon,
  CheckCircle as DoneIcon, Error as FailIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  BlockingDependenciesResponse, BlockingDependency, SkipDecision,
  SkipDependencyResponse, SourceEvidence, SourceVerdict,
} from '../services/api/feedDependencies';
import SkipReasonFields, { useSkipReason } from './common/SkipReasonFields';
import { decisionWords } from './feedDecisions';

/** "3h 12m" since an ISO timestamp; '—' when unknown. */
const waitingFor = (iso: string | null): string => {
  if (!iso) return '—';
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '—';
  const mins = Math.max(0, Math.floor((Date.now() - t) / 60000));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
};

/** The gate's verdict word, in plain words (2026-09-27). */
const verdictWord = (v: string | null | undefined): string => {
  switch (v) {
    case 'met': return 'met';
    case 'not_met': return 'not met';
    case 'could_not_tell': return "can't check right now";
    case 'not_expected': return 'not expected';
    default: return v ? String(v).split('_').join(' ') : 'unknown';
  }
};

/** One line of a source's evidence, when it has something to SHOW
 *  (2026-10-07): a file source names the rendered location it is waiting
 *  on, or the files that landed.  null = nothing beyond the reason. */
const baseName = (key: string): string => key.split('/').pop() ?? key;

/** "waiting for 1+ × *.csv + READY in s3://… — last looked …" */
const waitingLine = (ev: SourceEvidence): string | null => {
  const w = ev.waiting_for;
  if (!w) return null;
  const what = w.min_files > 0 ? `${w.min_files}+ × ${w.pattern}` : 'the control file';
  const ctl = w.control_file ? ` + ${w.control_file}` : '';
  const seen = ev.observed_at ? ` — last looked ${ev.observed_at}` : ' — not looked at yet';
  return `waiting for ${what}${ctl} in ${w.location}${seen}`;
};

/** "2 file(s) in s3://…: a.csv, b.csv (control READY)" */
const landedLine = (ev: SourceEvidence): string | null => {
  if (!ev.location) return null;
  const files = ev.files ?? [];
  const names = files.slice(0, 3).map((f) => baseName(f.key)).join(', ');
  const ctl = (ev.control ?? []).map((c) => baseName(c.key)).join(', ');
  return `${ev.file_count ?? files.length} file(s) in ${ev.location}`
    + (names ? `: ${names}` : '') + (ctl ? ` (control ${ctl})` : '');
};

const sourceEvidenceLine = (s: SourceVerdict): string | null => {
  const ev = s.evidence;
  if (!ev) return null;
  if (s.verdict === 'met') return landedLine(ev);
  // The producer is down: nothing will ever write this evidence by waiting.
  if (ev.producer?.state === 'down') {
    return `cannot be satisfied: ${s.kind} producer ${ev.producer.producer ?? '(none)'} not running (${ev.producer.reason})`;
  }
  return waitingLine(ev);
};

const verdictColor = (v: string | null | undefined): 'success' | 'warning' | 'default' => {
  if (v === 'met' || v === 'not_expected') return 'success';
  if (v === 'not_met') return 'warning';
  return 'default';
};

/** Tightest (earliest) SLA among the blocked feeds; null when none set. */
const tightestSla = (dep: BlockingDependency): string | null => {
  const slas = dep.blocked_feeds
    .map(f => f.sla_to)
    .filter((s): s is string => !!s)
    .sort();
  return slas.length ? slas[0] : null;
};

// ── Per-dependency skip dialog ──────────────────────────────────────────

const DependencySkipDialog: React.FC<{
  dep: BlockingDependency | null;
  businessDate: string;
  onClose: () => void;
  /** Called after a successful skip so the parent can refresh. */
  onSkipped: () => void;
}> = ({ dep, businessDate, onClose, onSkipped }) => {
  const reason = useSkipReason();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SkipDependencyResponse | null>(null);

  const reset = () => { reason.reset(); setError(null); setResult(null); };

  const handleConfirm = async () => {
    if (!dep || !reason.valid) return;
    setBusy(true);
    setError(null);
    try {
      const resp = await api.skipFeedDependency(dep.dependency_key, {
        business_date: businessDate,
        ...reason.body,
        etl_ids: null,
      });
      setResult(resp);
      onSkipped();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleClose = () => { reset(); onClose(); };

  return (
    <Dialog open={dep != null} onClose={busy ? undefined : handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>Skip dependency — {dep?.dependency_key}</DialogTitle>
      <DialogContent dividers>
        {result ? (
          <Box>
            <Alert severity="success" sx={{ mb: 1.5 }}>
              <strong>{result.dependency_key}</strong> waived for {result.business_date}
              {' '}by {result.asserted_by}. {result.affected_count} feed
              {result.affected_count === 1 ? '' : 's'} released.
            </Alert>
            {result.affected_runs.length > 0 && (
              <Box sx={{ maxHeight: 200, overflowY: 'auto' }}>
                {result.affected_runs.map(r => (
                  <Typography key={r.feed_run_id} variant="caption" sx={{ display: 'block' }}>
                    <DoneIcon sx={{ fontSize: 12, mr: 0.5, verticalAlign: 'middle' }} color="success" />
                    {r.feed_name} (run #{r.feed_run_id})
                  </Typography>
                ))}
              </Box>
            )}
          </Box>
        ) : (
          <>
            <Alert severity="warning" icon={<WarnIcon />} sx={{ mb: 2 }}>
              <strong>{dep?.blocked_count ?? 0} feed{(dep?.blocked_count ?? 0) === 1 ? '' : 's'} will
              proceed WITHOUT <code>{dep?.dependency_key}</code> confirmed</strong> for
              business date {businessDate}.  Their output may be produced from
              incomplete upstream data.  This is recorded with your name and
              the reason below.
            </Alert>
            {dep && dep.blocked_feeds.length > 0 && (
              <Box sx={{ mb: 2, maxHeight: 160, overflowY: 'auto' }}>
                <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
                  Feeds that will be released:
                </Typography>
                {dep.blocked_feeds.map(f => (
                  <Typography key={f.feed_run_id} variant="caption" sx={{ display: 'block' }}>
                    • {f.feed_name} {f.sla_to ? `(SLA ${f.sla_to})` : ''}
                  </Typography>
                ))}
              </Box>
            )}
            <SkipReasonFields
              state={reason}
              disabled={busy}
              textTestId="dep-skip-reason"
              categoryTestId="dep-skip-reason-category"
              textPlaceholder="Why is it safe to proceed without this input?"
            />
            {error && <Alert severity="error" sx={{ mt: 1.5 }}>{error}</Alert>}
          </>
        )}
      </DialogContent>
      <DialogActions>
        {result ? (
          <Button variant="contained" onClick={handleClose}>Close</Button>
        ) : (
          <>
            <Button onClick={handleClose} disabled={busy}>Cancel</Button>
            <Button
              variant="contained"
              color="warning"
              onClick={() => void handleConfirm()}
              disabled={busy || !reason.valid}
              startIcon={busy ? <CircularProgress size={14} /> : <SkipDepIcon />}
            >
              Skip for {dep?.blocked_count ?? 0} feed{(dep?.blocked_count ?? 0) === 1 ? '' : 's'}
            </Button>
          </>
        )}
      </DialogActions>
    </Dialog>
  );
};

// ── Panel ───────────────────────────────────────────────────────────────

interface Props {
  businessDate: string;
  loading: boolean;
  error: string | null;
  data: BlockingDependenciesResponse | null;
  onRetry: () => void;
  /** Refresh runs + dependency data after a successful skip. */
  onSkipped: () => void;
}

const FeedDependencyPanel: React.FC<Props> = ({
  businessDate, loading, error, data, onRetry, onSkipped,
}) => {
  const [expandedKey, setExpandedKey] = useState<string | null>(null);
  const [skipDep, setSkipDep] = useState<BlockingDependency | null>(null);

  const deps = data?.dependencies ?? [];

  // Headline counts DISTINCT runs — a feed blocked by two dependencies
  // is one held-up feed, not two.
  const uniqueBlockedFeeds = useMemo(() => {
    const ids = new Set<number>();
    for (const d of deps) for (const f of d.blocked_feeds) ids.add(f.feed_run_id);
    return ids.size;
  }, [deps]);

  return (
    <Paper sx={{ p: 2, mb: 2 }} data-testid="feed-dependency-panel">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <DepIcon color="primary" fontSize="small" />
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Dependency status — what is holding feeds up
        </Typography>
        {loading && <CircularProgress size={16} />}
        <Box sx={{ flex: 1 }} />
        <Button size="small" startIcon={<RetryIcon />} onClick={onRetry} disabled={loading}>
          Refresh
        </Button>
      </Stack>

      {error && !loading && (
        <Alert
          severity="error"
          action={<Button color="inherit" size="small" onClick={onRetry}>Retry</Button>}
        >
          Could not load dependency status — blocked feeds may exist but cannot
          be shown. {error}
        </Alert>
      )}

      {!error && !loading && data && deps.length === 0 && (
        <Alert severity="success" icon={<DoneIcon />}>
          No dependencies are blocking any feeds for {businessDate}.
        </Alert>
      )}

      {!error && data && (data.unavailable_sections?.length ?? 0) > 0 && (
        <Alert severity="warning" sx={{ mb: 1 }}>
          Some sections could not be evaluated: {data.unavailable_sections.join(', ')} —
          the list below may be incomplete.
        </Alert>
      )}

      {!error && deps.length > 0 && (
        <>
          <Typography variant="h6" sx={{ mb: 1.5 }} data-testid="dep-headline">
            <strong>{uniqueBlockedFeeds}</strong> feed{uniqueBlockedFeeds === 1 ? '' : 's'} blocked
            by <strong>{deps.length}</strong> dependenc{deps.length === 1 ? 'y' : 'ies'}
          </Typography>
          <Stack spacing={1}>
            {[...deps].sort((a, b) => b.blocked_count - a.blocked_count).map(dep => {
              const open = expandedKey === dep.dependency_key;
              const sla = tightestSla(dep);
              return (
                <Paper
                  key={dep.dependency_key}
                  variant="outlined"
                  sx={{ p: 1.25, borderLeft: '4px solid', borderLeftColor: 'warning.main' }}
                  data-testid={`dep-row-${dep.dependency_key}`}
                >
                  <Stack direction="row" alignItems="center" spacing={1.5} flexWrap="wrap">
                    {/* THE headline number: how many feeds this dependency holds. */}
                    <Tooltip title={`${dep.blocked_count} feeds are waiting on this dependency`}>
                      <Typography variant="h5" sx={{ fontWeight: 800, color: 'warning.dark', minWidth: 44, textAlign: 'center' }}>
                        {dep.blocked_count}
                      </Typography>
                    </Tooltip>
                    <Box sx={{ flex: 1, minWidth: 180 }}>
                      <Typography variant="body2" sx={{ fontWeight: 700 }}>
                        {dep.dependency_key}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {dep.type_name} · holding {dep.blocked_count} feed{dep.blocked_count === 1 ? '' : 's'}
                        {' '}· waiting {waitingFor(dep.first_waiting_since)}
                        {dep.last_arrival_at ? ` · last arrival ${dep.last_arrival_at}` : ''}
                      </Typography>
                      {/* 2026-09-27 — WHY, in the gate's own words: which
                          source met and which one blocks (or could not be
                          read).  "could not tell" is its own state here. */}
                      {dep.reason && (
                        <Typography variant="caption" sx={{ display: 'block', mt: 0.25 }}
                          data-testid={`dep-reason-${dep.dependency_key}`}>
                          <strong>{verdictWord(dep.verdict)}</strong>: {dep.reason}
                        </Typography>
                      )}
                      {dep.sources && dep.sources.length > 0 && (
                        <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap sx={{ mt: 0.5 }}>
                          {dep.sources.map((s, i) => (
                            <Tooltip key={`${s.kind}-${i}`} title={s.reason || ''}>
                              <Chip size="small" variant="outlined" color={verdictColor(s.verdict)}
                                label={`${s.kind}: ${verdictWord(s.verdict)}`}
                                sx={{ height: 20, fontSize: '0.66rem' }}
                                data-testid={`dep-source-${dep.dependency_key}-${s.kind}`} />
                            </Tooltip>
                          ))}
                        </Stack>
                      )}
                      {/* 2026-10-07 — a file source says WHERE it is looking
                          (rendered for the date) or WHICH files landed. */}
                      {(dep.sources ?? []).map((s, i) => {
                        const line = sourceEvidenceLine(s);
                        return line ? (
                          <Typography key={`ev-${s.kind}-${i}`} variant="caption" color="text.secondary"
                            sx={{ display: 'block', mt: 0.25, wordBreak: 'break-all' }}
                            data-testid={`dep-source-evidence-${dep.dependency_key}-${s.kind}-${i}`}>
                            {line}
                          </Typography>
                        ) : null;
                      })}
                    </Box>
                    {sla && (
                      <Tooltip title="Tightest SLA among the blocked feeds — first to breach if this dependency stays missing">
                        <Chip
                          size="small"
                          icon={<WarnIcon sx={{ fontSize: 14 }} />}
                          label={`tightest SLA ${sla}`}
                          color="warning"
                          variant="outlined"
                          sx={{ height: 22, fontSize: '0.68rem' }}
                        />
                      </Tooltip>
                    )}
                    <Button
                      size="small"
                      color="warning"
                      variant="outlined"
                      startIcon={<SkipDepIcon />}
                      onClick={() => setSkipDep(dep)}
                    >
                      Skip for all
                    </Button>
                    <IconButton
                      size="small"
                      onClick={() => setExpandedKey(open ? null : dep.dependency_key)}
                      aria-label={open ? 'collapse blocked feeds' : 'show blocked feeds'}
                    >
                      {open ? <CollapseIcon fontSize="small" /> : <ExpandIcon fontSize="small" />}
                    </IconButton>
                  </Stack>
                  <Collapse in={open}>
                    <Box sx={{ mt: 1, pl: 7 }}>
                      {dep.blocked_feeds.map(f => (
                        <Typography key={f.feed_run_id} variant="caption" sx={{ display: 'block' }}>
                          <FailIcon sx={{ fontSize: 11, mr: 0.5, verticalAlign: 'middle' }} color="warning" />
                          {f.feed_name} — run #{f.feed_run_id}
                          {f.sla_to ? ` · SLA ${f.sla_to}` : ' · no SLA'}
                        </Typography>
                      ))}
                    </Box>
                  </Collapse>
                </Paper>
              );
            })}
          </Stack>
        </>
      )}

      {/* 2026-09-27 — the decisions taken today: a dependency skipped an
          hour ago is no longer "blocking", so this is where it stays
          visible (who, when, which category, why). */}
      {!error && data && (data.skips?.length ?? 0) > 0 && (
        <Box sx={{ mt: 2 }} data-testid="dep-decisions-today">
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 0.5 }}>
            Decisions for {businessDate}
          </Typography>
          <Stack spacing={0.5}>
            {(data.skips as SkipDecision[]).map((d, i) => {
              const w = decisionWords(d);
              return (
                <Paper key={`${d.event_type}-${d.feed_run_id ?? 'x'}-${d.dependency_key}-${i}`}
                  variant="outlined" sx={{ p: 1, borderLeft: '4px solid', borderLeftColor: `${w.color}.main` }}
                  data-testid={`dep-decision-${d.dependency_key}`}>
                  <Typography variant="body2">
                    <strong>{w.title}</strong>
                    {d.feed_name ? <> — {d.feed_name}{d.feed_run_id ? ` (run #${d.feed_run_id})` : ''}</> : null}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    {w.detail}
                  </Typography>
                </Paper>
              );
            })}
          </Stack>
        </Box>
      )}

      <DependencySkipDialog
        dep={skipDep}
        businessDate={businessDate}
        onClose={() => setSkipDep(null)}
        onSkipped={onSkipped}
      />
    </Paper>
  );
};

export default FeedDependencyPanel;
