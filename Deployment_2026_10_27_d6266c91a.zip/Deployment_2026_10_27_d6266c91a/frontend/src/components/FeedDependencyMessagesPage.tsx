/**
 * Dependency messages -- the owner's "Kafka UI" (2026-10-11).
 *
 * Every upstream COMPLETE / IN_PROGRESS message that landed -- from the Kafka
 * topic AND from rows of the OG QS_KAFKA_MESSAGE table -- with its OG fields
 * (DATA_SOURCE, CODE, BUSINESS_EVENT, CLOUD_COMPLIANT, VERSION_STATE,
 * ROW_COUNT), what the resolver made of it (resolved / unmatched / filtered /
 * unresolvable, with the reason), and every feed declaring its dependency
 * with that feed's run for the business date: HELD (waiting on another
 * dependency) or RELEASED.  A second tab lists the NEW system entities a
 * message onboarded automatically from the template its DATA_SOURCE names.
 *
 * Backed by GET /api/admin/feeds/dependency-messages and
 * GET /api/feed-templates/onboarding.  Read-only: a dependency that will not
 * arrive (a holiday) is skipped from the feed's dependency panel.
 *
 * 2026-10-25 -- the first tab is the MESSAGE TRACKER (feeds/MessageTracker.tsx):
 * one business close date, CODE -> DATA_SOURCE -> message with its flow.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Chip, CircularProgress, IconButton, MenuItem, Paper, Stack, Tab, Table, TableBody,
  TableCell, TableHead, TableRow, Tabs, TextField, Tooltip, Typography,
} from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';
import api from '../services/api';
import IcebergCommitsPanel from './feeds/IcebergCommitsPanel';
import MessageTracker from './feeds/MessageTracker';
import ListPager, { type Paging } from './common/ListPager';

interface FeedLink {
  feed_id: number;
  feed_name: string;
  run_status: string | null;
  action_decision: string | null;
}

interface MessageRow {
  id: number;
  road: 'kafka' | 'oracle_table';
  topic: string;
  landed_at: string | null;
  resolution: string;
  reason: string | null;
  dependency_name: string | null;
  business_date: string | null;
  fields: Record<string, unknown>;
  /** the environment by the configured rule (server) */
  environment?: string | null;
  feeds: FeedLink[];
  released: FeedLink[];
  /** which arrival this is for its (dependency, business date) on the ledger */
  arrival?: { n: number; of: number | null; resend: boolean } | null;
  /** what a re-send did: each restatement decision (core/feed/restatement.py) */
  restatements?: { decision_id: number; status: string; resolution: string | null; resolved_by: string | null;
                   action: string | null; title: string | null; why: string | null; run_date: string | null }[];
}

interface OnboardingRow {
  id: number;
  template_id: number;
  values: Record<string, string>;
  business_date: string | null;
  dependency_name: string | null;
  source: string | null;
  status: string;
  feed_config_id: number | null;
  run: string | null;
  detail: string | null;
  created_at: string | null;
}

const RESOLUTIONS = ['', 'resolved', 'unmatched', 'filtered', 'unresolvable', 'landed'];
const RESOLUTION_COLOR: Record<string, 'success' | 'warning' | 'default' | 'error' | 'info'> = {
  resolved: 'success', unmatched: 'warning', filtered: 'default', unresolvable: 'error', landed: 'info',
};
const ONBOARD_COLOR: Record<string, 'success' | 'warning' | 'error' | 'info'> = {
  onboarded: 'success', pending: 'info', refused: 'warning', failed: 'error',
};

/** a column the server says to show (feed_message_fields -- DATA) */
interface Column { field: string; label: string }

/** One spelling for a value whichever road it came by: the message table
 *  returns a DATE as midnight (2026-10-01T00:00:00), Kafka as 2026-10-01. */
export function cellText(v: unknown): string {
  if (v == null) return '';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}[T ]00:00:00(\.0+)?$/.test(s) ? s.slice(0, 10) : s;
}

function FeedChips({ feeds }: { feeds: FeedLink[] }) {
  if (!feeds.length) return <Typography variant="caption" color="text.secondary">no feed declares it</Typography>;
  return (
    <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
      {feeds.map((f) => {
        const released = f.action_decision === 'RUN';
        const label = `${f.feed_name}: ${f.run_status ? (released ? 'released' : 'held') + ' · ' + f.run_status : 'no run for this date'}`;
        return (
          <Chip key={f.feed_id} size="small" variant="outlined" data-testid="dep-msg-feed"
                color={released ? 'success' : f.run_status ? 'warning' : 'default'} label={label} />
        );
      })}
    </Stack>
  );
}

/** ``embedded``: inside Feed Run Status (its "Upstream messages" tab) --
 *  no page title or outer padding; the page's own header says where you are. */
export default function FeedDependencyMessagesPage({ embedded = false }: { embedded?: boolean } = {}) {
  const [tab, setTab] = useState(0);
  const [resolution, setResolution] = useState('');
  const [days, setDays] = useState(7);
  const [rows, setRows] = useState<MessageRow[]>([]);
  const [columns, setColumns] = useState<Column[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [onboarding, setOnboarding] = useState<OnboardingRow[]>([]);
  const [onboardCounts, setOnboardCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // PAGED on the server (core/feed/paging.py): the page and its size per list
  const [mPage, setMPage] = useState(1);
  const [mSize, setMSize] = useState(50);
  const [mPaging, setMPaging] = useState<Paging | null>(null);
  const [oPage, setOPage] = useState(1);
  const [oSize, setOSize] = useState(50);
  const [oPaging, setOPaging] = useState<Paging | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [m, o] = await Promise.all([
        api.dependencyMessages({ resolution: resolution || undefined, days, page: mPage, page_size: mSize }),
        api.onboardingRequests(undefined, oPage, oSize),
      ]);
      setMPaging((m?.paging ?? null) as Paging | null);
      setOPaging((o?.paging ?? null) as Paging | null);
      setRows((m?.items ?? []) as MessageRow[]);
      setColumns((m?.columns ?? []) as Column[]);
      setCounts((m?.counts ?? {}) as Record<string, number>);
      setOnboarding((o?.requests ?? []) as OnboardingRow[]);
      setOnboardCounts((o?.counts ?? {}) as Record<string, number>);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [resolution, days, mPage, mSize, oPage, oSize]);
  // a new filter starts at page 1
  useEffect(() => { setMPage(1); }, [resolution, days]);

  useEffect(() => { void load(); }, [load]);

  const total = useMemo(() => Object.values(counts).reduce((a, b) => a + b, 0), [counts]);

  return (
    <Box sx={{ p: embedded ? 0 : 3 }} data-testid="dep-msg-page">
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Typography variant={embedded ? 'subtitle1' : 'h5'} sx={{ flex: 1, fontWeight: embedded ? 600 : undefined }}>
          {embedded ? 'Upstream messages — every Kafka / QS_KAFKA_MESSAGE message that landed' : 'Dependency Messages'}
        </Typography>
        <TextField select size="small" label="Window" value={days} sx={{ width: 140 }}
                   onChange={(e) => setDays(Number(e.target.value))} data-testid="dep-msg-days">
          {[1, 7, 31, 92, 0].map((d) => <MenuItem key={d} value={d}>{d ? `last ${d} day(s)` : 'all'}</MenuItem>)}
        </TextField>
        <Tooltip title="Refresh">
          <span><IconButton onClick={() => void load()} disabled={loading} aria-label="Refresh"><RefreshIcon /></IconButton></span>
        </Tooltip>
      </Stack>
      {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="dep-msg-error">{error}</Alert>}
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab label="Message tracker" data-testid="dep-msg-tab-tracker" />
        <Tab label={`Messages (${total})`} data-testid="dep-msg-tab-messages" />
        <Tab label={`Auto-onboarded entities (${oPaging?.total ?? onboarding.length})`} data-testid="dep-msg-tab-onboarding" />
        <Tab label="Iceberg commits" data-testid="dep-msg-tab-iceberg" />
      </Tabs>

      {tab === 0 && <MessageTracker />}

      {tab === 1 && (
        <Paper variant="outlined">
          <Stack direction="row" spacing={1} sx={{ p: 1.5 }} flexWrap="wrap" useFlexGap>
            {RESOLUTIONS.map((r) => (
              <Chip key={r || 'all'} clickable data-testid={`dep-msg-filter-${r || 'all'}`}
                    color={resolution === r ? 'primary' : 'default'}
                    label={`${r || 'all'}${r ? ` (${counts[r] ?? 0})` : ` (${total})`}`}
                    onClick={() => setResolution(r)} />
            ))}
          </Stack>
          {loading ? <Box sx={{ p: 3, textAlign: 'center' }}><CircularProgress size={28} /></Box> : (
            <Table size="small" data-testid="dep-msg-table">
              <TableHead>
                <TableRow>
                  <TableCell>Landed</TableCell><TableCell>Arrived via</TableCell><TableCell>Environment</TableCell>
                  {columns.map(c => <TableCell key={c.field} data-testid="dep-msg-col">{c.label}</TableCell>)}
                  <TableCell>Arrival</TableCell><TableCell>Resolution</TableCell><TableCell>Feeds</TableCell>
                  <TableCell>Re-send outcome</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.length === 0 && (
                  <TableRow><TableCell colSpan={columns.length + 7}><Typography color="text.secondary">
                    No messages in this window.
                  </Typography></TableCell></TableRow>
                )}
                {rows.map((m) => (
                  <TableRow key={m.id} data-testid="dep-msg-row" hover>
                    <TableCell sx={{ whiteSpace: 'nowrap' }}>{(m.landed_at ?? '').replace('T', ' ').slice(0, 19)}</TableCell>
                    <TableCell><Tooltip title={m.topic}><span>{m.road === 'kafka' ? 'Kafka' : 'Oracle table'}</span></Tooltip></TableCell>
                    <TableCell>{m.environment ?? ''}</TableCell>
                    {columns.map(c => (
                      <TableCell key={c.field}>{cellText(m.fields[c.field])}</TableCell>
                    ))}
                    <TableCell data-testid="dep-msg-arrival">
                      {m.arrival ? (
                        <Chip size="small" variant={m.arrival.resend ? 'filled' : 'outlined'}
                              color={m.arrival.resend ? 'warning' : 'default'}
                              label={`${m.arrival.resend ? 'Re-sent' : 'First'} · ${m.arrival.n}${m.arrival.of ? ` of ${m.arrival.of}` : ''}`} />
                      ) : ''}
                    </TableCell>
                    <TableCell>
                      <Tooltip title={m.reason ?? m.dependency_name ?? ''}>
                        <Chip size="small" label={m.resolution} color={RESOLUTION_COLOR[m.resolution] ?? 'default'}
                              data-testid="dep-msg-resolution" />
                      </Tooltip>
                    </TableCell>
                    <TableCell><FeedChips feeds={m.feeds} /></TableCell>
                    <TableCell data-testid="dep-msg-restatement">
                      {(m.restatements || []).map(r => (
                        <Tooltip key={r.decision_id} title={`${r.why || ''}${r.status !== 'open'
                          ? ` — answered ${r.resolution} by ${r.resolved_by}` : ''}`}>
                          <Chip size="small" sx={{ mr: 0.5, mb: 0.25 }}
                                color={r.status !== 'open' ? 'default' : r.action === 'hold' ? 'error'
                                  : r.action === 'rerun' ? 'info' : 'warning'}
                                label={`${r.action === 'hold' ? 'Re-run hold' : r.action === 'rerun' ? 'Re-run'
                                  : r.action === 'closed' ? 'After close' : 'Decision'}${r.run_date ? ` · ${r.run_date}` : ''}`
                                  + `${r.status !== 'open' ? ` · ${r.resolution === 'regenerate' ? 're-ran' : 'kept'}` : ''}`} />
                        </Tooltip>
                      ))}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          <ListPager paging={mPaging} onPage={setMPage} onPageSize={setMSize} testid="dep-msg-pager" />
        </Paper>
      )}

      {tab === 2 && (
        <Paper variant="outlined">
          <Stack direction="row" spacing={1} sx={{ p: 1.5 }}>
            {Object.entries(onboardCounts).map(([k, v]) => (
              <Chip key={k} size="small" color={ONBOARD_COLOR[k] ?? 'default'} label={`${k}: ${v}`} />
            ))}
          </Stack>
          <Table size="small" data-testid="dep-onboard-table">
            <TableHead>
              <TableRow>
                <TableCell>Requested</TableCell><TableCell>System entity</TableCell><TableCell>Event</TableCell>
                <TableCell>Business date</TableCell><TableCell>From</TableCell><TableCell>Status</TableCell>
                <TableCell>Feed</TableCell><TableCell>SOD task</TableCell><TableCell>Detail</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {onboarding.length === 0 && (
                <TableRow><TableCell colSpan={9}><Typography color="text.secondary">
                  No new system entity has arrived. A template onboards entities when it declares auto_onboard.
                </Typography></TableCell></TableRow>
              )}
              {onboarding.map((o) => (
                <TableRow key={o.id} data-testid="dep-onboard-row" hover>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{(o.created_at ?? '').replace('T', ' ').slice(0, 19)}</TableCell>
                  <TableCell>{o.values.SYSTEM_ENTITY ?? Object.values(o.values)[0]}</TableCell>
                  <TableCell>{o.values.EventCode ?? ''}</TableCell>
                  <TableCell>{o.business_date ?? ''}</TableCell>
                  <TableCell>{o.source === 'oracle_table' ? 'Oracle table' : 'Kafka'}</TableCell>
                  <TableCell><Chip size="small" label={o.status} color={ONBOARD_COLOR[o.status] ?? 'default'} /></TableCell>
                  <TableCell>{o.feed_config_id ? <a href={`/feeds?feed=${o.feed_config_id}`}>#{o.feed_config_id}</a> : ''}</TableCell>
                  <TableCell>{o.run ?? ''}</TableCell>
                  <TableCell sx={{ maxWidth: 420 }}><Typography variant="caption">{o.detail ?? ''}</Typography></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={oPaging} onPage={setOPage} onPageSize={setOSize} testid="dep-onboard-pager" />
        </Paper>
      )}

      {tab === 3 && <IcebergCommitsPanel />}
    </Box>
  );
}
