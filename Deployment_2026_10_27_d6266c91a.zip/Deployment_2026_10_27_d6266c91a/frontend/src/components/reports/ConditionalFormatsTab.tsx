/**
 * Conditional (value-based) formatting rules — persisted at
 * `layout_config.style_config.conditional_formats` in the exact shape the
 * export evaluator reads: {column_name, condition_type, condition_value,
 * bg_color, text_color, bold, is_enabled, rule_order}.
 *
 * Ordering is load-bearing: the renderer sorts by rule_order and the FIRST
 * matching rule wins, so the list is shown in evaluation order with reorder
 * controls, and rule_order is rewritten from the visible order on save.
 */
import React from 'react';
import {
  Alert, Box, Button, Card, CardContent, Checkbox, Chip, FormControl,
  FormControlLabel, IconButton, InputLabel, MenuItem, Select, Stack, Switch,
  TextField, Tooltip, Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import {
  ConditionalFormatRule, ConditionType, CONDITION_TYPES,
} from './reportAuthoringModel';

export interface ConditionalFormatsTabProps {
  rules: ConditionalFormatRule[];
  onChange: (rules: ConditionalFormatRule[]) => void;
  /** Result column names rules can target (report columns + calc names). */
  columnNames: string[];
}

/** A colour swatch input that can also be cleared back to "no colour". */
const ColorField: React.FC<{
  label: string; value: string | null; onChange: (v: string | null) => void;
}> = ({ label, value, onChange }) => (
  <Stack direction="row" spacing={0.5} alignItems="center">
    <Typography variant="caption">{label}</Typography>
    {/* "Fill colour" / "Text colour": a bare "Text" shared its name with the
        condition's Text field in the same row (found by the rig walk). */}
    <input type="color" aria-label={`${label} colour`}
      value={value || '#ffffff'}
      onChange={e => onChange(e.target.value)}
      style={{ width: 28, height: 24, padding: 0, border: '1px solid #ccc', cursor: 'pointer' }} />
    {value && (
      <Button size="small" sx={{ minWidth: 0, px: 0.5 }} onClick={() => onChange(null)}>
        clear
      </Button>
    )}
  </Stack>
);

const ConditionalFormatsTab: React.FC<ConditionalFormatsTabProps> = ({
  rules, onChange, columnNames,
}) => {
  const update = (idx: number, patch: Partial<ConditionalFormatRule>) =>
    onChange(rules.map((r, i) => (i === idx ? { ...r, ...patch } : r)));

  const move = (idx: number, delta: number) => {
    const j = idx + delta;
    if (j < 0 || j >= rules.length) return;
    const next = [...rules];
    [next[idx], next[j]] = [next[j], next[idx]];
    onChange(next.map((r, i) => ({ ...r, rule_order: i })));
  };

  const addRule = () => onChange([...rules, {
    column_name: columnNames[0] || '',
    condition_type: 'value_range',
    condition_value: {},
    bg_color: '#fff3cd',
    text_color: null,
    bold: false,
    is_enabled: true,
    rule_order: rules.length,
  }]);

  return (
    <Box>
      <Alert severity="info" sx={{ mb: 1 }} icon={false}>
        Rules are evaluated top to bottom per cell — the <strong>first matching
        rule wins</strong> and the rest are ignored. Reorder to change the result.
      </Alert>

      {rules.map((r, idx) => {
        const meta = CONDITION_TYPES.find(t => t.value === r.condition_type);
        const cv = r.condition_value || {};
        return (
          <Card key={idx} variant="outlined" sx={{ mb: 1, opacity: r.is_enabled ? 1 : 0.55 }}
            data-testid={`rule-card-${idx}`}>
            <CardContent sx={{ py: 1.5, '&:last-child': { pb: 1.5 } }}>
              <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                <Chip size="small" label={`#${idx + 1}`} />
                <FormControl size="small" sx={{ minWidth: 160 }}>
                  <InputLabel id={`rule-col-${idx}`}>Column</InputLabel>
                  <Select labelId={`rule-col-${idx}`} label="Column"
                    value={columnNames.includes(r.column_name) ? r.column_name : ''}
                    onChange={e => update(idx, { column_name: String(e.target.value) })}>
                    {columnNames.map(n => <MenuItem key={n} value={n}>{n}</MenuItem>)}
                  </Select>
                </FormControl>
                <FormControl size="small" sx={{ minWidth: 190 }}>
                  <InputLabel id={`rule-cond-${idx}`}>Condition</InputLabel>
                  <Select labelId={`rule-cond-${idx}`} label="Condition" value={r.condition_type}
                    onChange={e => {
                      const ct = e.target.value as ConditionType;
                      const needs = CONDITION_TYPES.find(t => t.value === ct)?.needs;
                      update(idx, {
                        condition_type: ct,
                        condition_value: needs === 'range' ? {} : needs === 'text' ? { text: '' }
                          : needs === 'n' ? { n: 10 } : null,
                      });
                    }}>
                    {CONDITION_TYPES.map(t => (
                      <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {meta?.needs === 'range' && (
                  <>
                    <TextField size="small" type="number" label="Min" sx={{ width: 110 }}
                      value={cv.min ?? ''}
                      onChange={e => update(idx, {
                        condition_value: {
                          ...cv,
                          min: e.target.value === '' ? undefined : Number(e.target.value),
                        },
                      })} />
                    <TextField size="small" type="number" label="Max" sx={{ width: 110 }}
                      value={cv.max ?? ''}
                      onChange={e => update(idx, {
                        condition_value: {
                          ...cv,
                          max: e.target.value === '' ? undefined : Number(e.target.value),
                        },
                      })} />
                  </>
                )}
                {meta?.needs === 'n' && (
                  <TextField size="small" type="number" label="N" sx={{ width: 90 }}
                    inputProps={{ min: 1, 'aria-label': 'How many values' }}
                    value={cv.n ?? 10}
                    onChange={e => update(idx, {
                      condition_value: { n: Math.max(1, Number(e.target.value) || 1) },
                    })} />
                )}
                {meta?.needs === 'text' && (
                  <TextField size="small" label="Text" sx={{ width: 160 }}
                    value={cv.text ?? ''}
                    onChange={e => update(idx, { condition_value: { text: e.target.value } })} />
                )}
                <ColorField label="Fill" value={r.bg_color}
                  onChange={v => update(idx, { bg_color: v })} />
                <ColorField label="Text" value={r.text_color}
                  onChange={v => update(idx, { text_color: v })} />
                <FormControlLabel control={
                  <Checkbox size="small" checked={r.bold}
                    onChange={e => update(idx, { bold: e.target.checked })} />
                } label="Bold" />
                <FormControlLabel control={
                  <Switch size="small" checked={r.is_enabled}
                    onChange={e => update(idx, { is_enabled: e.target.checked })} />
                } label="On" />
                <Tooltip title="Evaluate earlier">
                  <span><IconButton size="small" disabled={idx === 0}
                    aria-label={`move rule ${idx + 1} up`}
                    onClick={() => move(idx, -1)}><ArrowUpwardIcon fontSize="small" /></IconButton></span>
                </Tooltip>
                <Tooltip title="Evaluate later">
                  <span><IconButton size="small" disabled={idx === rules.length - 1}
                    aria-label={`move rule ${idx + 1} down`}
                    onClick={() => move(idx, 1)}><ArrowDownwardIcon fontSize="small" /></IconButton></span>
                </Tooltip>
                <Tooltip title="Delete rule">
                  <IconButton size="small" aria-label={`delete rule ${idx + 1}`}
                    onClick={() => onChange(rules.filter((_, i) => i !== idx)
                      .map((x, i) => ({ ...x, rule_order: i })))}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Stack>
              {meta?.help && (
                <Typography variant="caption" color="text.secondary">{meta.help}</Typography>
              )}
            </CardContent>
          </Card>
        );
      })}

      <Button size="small" startIcon={<AddIcon />} onClick={addRule}
        disabled={columnNames.length === 0}>
        Add rule
      </Button>
    </Box>
  );
};

export default ConditionalFormatsTab;
