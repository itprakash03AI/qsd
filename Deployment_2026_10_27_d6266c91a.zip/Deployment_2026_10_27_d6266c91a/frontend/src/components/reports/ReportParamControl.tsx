/**
 * ReportParamControl -- ONE prompt for one report parameter, in every viewer.
 *
 * 2026-10-03 (owner): "report parameter should be GENERIC and should come
 * from table distinct values", "if it's a date it should come from whatever
 * data is available in the table", "even same ways cascading columns".
 *
 * BusinessReportViewer, PivotReportViewer and SharedBusinessReportPage each
 * rendered their own copy of the prompt panel: a Select over a list loaded
 * up front for dropdowns, and a free calendar / free text box for everything
 * else -- so a date parameter bound to TRADES.DT let the viewer pick any day,
 * including the ones with no data.
 *
 * Now a parameter bound to a column (or carrying a curated list) is a
 * ColumnValuePicker over the report's own parameter route
 * (`POST /api/business-reports/{id}/parameter-values`, or the shared/embed
 * token twin): the column's distinct values under the viewer's row security,
 * a date parameter's dates newest first with the range said when the list is
 * cut, and a CASCADE child asked again whenever its parent's value changes
 * (the parent's value is part of the picker's fetch key).  A parameter bound
 * to nothing keeps the plain input -- there is nothing to list.
 */
import React from 'react';
import { Box, TextField, Tooltip } from '@mui/material';
import { InfoOutlined as InfoOutlinedIcon } from '@mui/icons-material';
import ColumnValuePicker, { ValueListAnswer } from '../common/ColumnValuePicker';

export type ParamValuesFetch = (body: {
  parameter_id: number; parent_values: Record<string, any>;
  /** 2026-10-24 -- type to search on the server (a cut list) */
  search?: string;
}) => Promise<ValueListAnswer>;

/** Every parameter that (transitively) depends on `paramId`. */
export function cascadeDescendants(params: any[], paramId: number): any[] {
  const out: any[] = [];
  const queue = [paramId];
  while (queue.length) {
    const id = queue.shift();
    for (const c of params) {
      if (c.depends_on_param_id === id && !out.includes(c)) {
        out.push(c);
        queue.push(c.id);
      }
    }
  }
  return out;
}

const emptyFor = (p: any) => (p.parameter_type === 'multi_select' ? []
  : p.parameter_type === 'date_range' ? {} : '');

/** The next values after `p` changes: its cascade children (and theirs)
 *  are cleared -- a child chosen under the old parent may not exist under
 *  the new one. */
export function applyParamChange(params: any[], prev: Record<string, any>,
                                 p: any, value: any): Record<string, any> {
  const next = { ...prev, [p.name]: value };
  for (const child of cascadeDescendants(params, p.id)) next[child.name] = emptyFor(child);
  return next;
}

export interface ReportParamControlProps {
  param: any;
  params: any[];
  values: Record<string, any>;
  onValues: (updater: (prev: Record<string, any>) => Record<string, any>) => void;
  fetchValues: ParamValuesFetch;
  showRequiredError?: boolean;
}

export function ReportParamControl({
  param: p, params, values, onValues, fetchValues, showRequiredError,
}: ReportParamControlProps) {
  const label = p.is_required ? `${p.label || p.name} *` : (p.label || p.name);
  const parent = p.depends_on_param_id
    ? params.find((x: any) => x.id === p.depends_on_param_id) : null;
  const parentValues: Record<string, any> = parent ? { [parent.name]: values[parent.name] } : {};
  const fetchKey = `${p.id}|${JSON.stringify(parentValues)}`;
  const fetch = () => fetchValues({ parameter_id: p.id, parent_values: parentValues });
  const search = (q: string) => fetchValues({ parameter_id: p.id, parent_values: parentValues, search: q });
  const set = (v: any) => onValues(prev => applyParamChange(params, prev, p, v));
  // A list-shaped prompt always ASKS: the server says where the values come
  // from (a curated list, the column) or why there are none -- the 2026-09-03
  // rule of the hook this replaces (a parameter with a static list was never
  // asked for).  Any other prompt is a list exactly when bound to a column.
  const listed = ['dropdown', 'multi_select'].includes(p.parameter_type)
    || !!p.lov_column_id;
  const isDate = p.parameter_type === 'date' || p.parameter_type === 'date_range';
  const help = p.description ? (
    <Tooltip title={p.description} placement="top">
      <InfoOutlinedIcon sx={{ fontSize: 14, color: 'text.secondary', cursor: 'help', ml: 0.5, mt: 1 }} />
    </Tooltip>
  ) : null;
  const requiredText = showRequiredError ? 'This parameter is required' : undefined;

  if (listed && p.parameter_type === 'date_range') {
    const cur = values[p.name] || {};
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
        <ColumnValuePicker eager isDate label={`${label} From`} testId={`param-${p.name}-from`}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search} value={cur.from || ''}
          onChange={v => set({ ...(values[p.name] || {}), from: v || '' })}
          error={showRequiredError} helperText={requiredText} sx={{ minWidth: 190 }} />
        <ColumnValuePicker eager isDate label={`${p.label || p.name} To`} testId={`param-${p.name}-to`}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search} value={cur.to || ''}
          onChange={v => set({ ...(values[p.name] || {}), to: v || '' })}
          sx={{ minWidth: 190 }} />
        {help}
      </Box>
    );
  }
  if (listed) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
        <ColumnValuePicker eager isDate={isDate} label={label} testId={`param-${p.name}`}
          multiple={p.parameter_type === 'multi_select'}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search}
          value={values[p.name] ?? (p.parameter_type === 'multi_select' ? [] : '')}
          onChange={v => set(v ?? '')}
          error={showRequiredError} helperText={requiredText}
          placeholder={p.is_required ? undefined : 'All'}
          sx={{ minWidth: 200 }} />
        {help}
      </Box>
    );
  }
  // Bound to nothing: there is no list to offer (the editor warns the
  // author that such a parameter filters nothing).
  if (isDate) {
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
        <TextField size="small" type="date" label={label + (p.parameter_type === 'date_range' ? ' From' : '')}
          error={showRequiredError} helperText={showRequiredError ? 'Required' : undefined}
          InputLabelProps={{ shrink: true }}
          value={p.parameter_type === 'date_range' ? (values[p.name]?.from || '') : (values[p.name] || '')}
          onChange={e => set(p.parameter_type === 'date_range'
            ? { ...(values[p.name] || {}), from: e.target.value } : e.target.value)} />
        {p.parameter_type === 'date_range' && (
          <TextField size="small" type="date" label={`${p.label || p.name} To`}
            InputLabelProps={{ shrink: true }} value={values[p.name]?.to || ''}
            onChange={e => set({ ...(values[p.name] || {}), to: e.target.value })} />
        )}
        {help}
      </Box>
    );
  }
  return (
    <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
      <TextField size="small" label={label}
        type={p.parameter_type === 'numeric' ? 'number' : 'text'}
        error={showRequiredError} helperText={showRequiredError ? 'Required' : undefined}
        value={values[p.name] || ''}
        onChange={e => set(e.target.value)} />
      {help}
    </Box>
  );
}

export default ReportParamControl;
