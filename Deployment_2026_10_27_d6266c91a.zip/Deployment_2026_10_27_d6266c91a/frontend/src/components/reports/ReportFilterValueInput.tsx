/**
 * The value side of one report filter row -- BOTH builders (tabular, pivot).
 *
 * 2026-10-03 (owner): "filter value should popup n fill dropdown".  A
 * filter's value is PICKED from the column's distinct values (the one LOV
 * route, POST /api/datasets/{id}/column-values, through ColumnValuePicker):
 * a list for IN / NOT IN, both ends of BETWEEN, a date column's dates that
 * exist.  Text PATTERNS (contains, starts with...) stay typed -- a pattern is
 * not a value of the column.  With no dataset to ask (a published-view
 * source) the value is typed.
 *
 * One component for both builders on purpose: the two builders have drifted
 * apart before (Between with one box in the pivot builder; the parameter
 * editor), and a capability in one of two copies is this codebase's
 * recurring defect.
 */
import React from 'react';
import { Autocomplete, TextField, Typography } from '@mui/material';
import api from '../../services/api';
import ColumnValuePicker from '../common/ColumnValuePicker';
import {
  FilterRow, LIST_OPERATORS, NO_VALUE_OPERATORS, PATTERN_OPERATORS, ASKABLE_OPERATORS,
} from '../../utils/reportFilters';
import { isTemporalColumn } from './reportWizardDraft';

export type OperandKind = 'none' | 'list' | 'range' | 'pattern' | 'one';

export function operandKind(op: string): OperandKind {
  if (NO_VALUE_OPERATORS.includes(op)) return 'none';
  if (LIST_OPERATORS.includes(op)) return 'list';
  if (op === 'between') return 'range';
  if (PATTERN_OPERATORS.includes(op)) return 'pattern';
  return 'one';
}

/** The row after one of its fields changed.  A new COLUMN or a change of
 *  operand KIND drops the value: a value picked from one column's list is
 *  not a value of another, and a list is not a single value. */
export function changeFilterField(f: FilterRow, field: string, val: any): FilterRow {
  const blankFor = (op: string) => (LIST_OPERATORS.includes(op) ? [] : '');
  if (field === 'column_id' && val !== f.column_id) {
    return { ...f, column_id: val, value: blankFor(f.operator), value2: undefined };
  }
  // an operator that cannot be ASKED at run time (2026-10-25) drops the question
  const asked = field === 'operator' && !ASKABLE_OPERATORS.includes(val) ? { ask_at_run: false } : {};
  if (field === 'operator' && operandKind(val) !== operandKind(f.operator)) {
    return { ...f, operator: val, value: blankFor(val), value2: undefined, ...asked };
  }
  return { ...f, [field]: val, ...asked };
}

export interface ReportFilterValueInputProps {
  filter: FilterRow;
  index: number;
  columns: any[];
  /** The dataset to list values from; null = nothing to ask, type it. */
  datasetId: number | null;
  onChange: (field: 'value' | 'value2', value: any) => void;
  /** The row is unfinished (no value yet). */
  unfilled?: boolean;
}

export function ReportFilterValueInput({
  filter: f, index: idx, columns, datasetId, onChange, unfilled,
}: ReportFilterValueInputProps) {
  const kind = operandKind(f.operator);
  if (kind === 'none') return null;
  const col = columns.find((c: any) => c.id === f.column_id);
  const colName = col ? (col.friendly_name || col.physical_name) : `column ${f.column_id}`;
  const isDate = isTemporalColumn(col);

  if (kind === 'pattern') {
    let placeholder = 'search text';
    if (f.operator === 'starts_with') placeholder = 'prefix...';
    else if (f.operator === 'ends_with') placeholder = '...suffix';
    return (
      <TextField size="small" value={f.value || ''} onChange={e => onChange('value', e.target.value)}
        inputProps={{ 'aria-label': `Filter ${idx + 1} text` }}
        error={unfilled} helperText={unfilled ? 'Type the text to match' : undefined}
        placeholder={placeholder} sx={{ minWidth: 150 }} />
    );
  }

  if (!datasetId) {
    if (kind === 'list') {
      return (
        <Autocomplete multiple freeSolo size="small" options={[]}
          value={Array.isArray(f.value) ? f.value : []}
          onChange={(_e, v: string[]) => onChange('value', v)}
          renderInput={(params) => (
            <TextField {...params} placeholder="Type a value and press Enter" size="small"
              error={unfilled} helperText="Press Enter to add each value" />
          )}
          sx={{ minWidth: 280 }} />
      );
    }
    return (
      <>
        <TextField size="small" value={f.value || ''} onChange={e => onChange('value', e.target.value)}
          inputProps={{ 'aria-label': `Filter ${idx + 1} value` }}
          error={unfilled} placeholder={kind === 'range' ? 'From' : 'Value'} sx={{ minWidth: 120 }} />
        {kind === 'range' && (
          <TextField size="small" value={f.value2 || ''} onChange={e => onChange('value2', e.target.value)}
            inputProps={{ 'aria-label': `Filter ${idx + 1} to` }}
            error={unfilled} placeholder="To" sx={{ minWidth: 120 }} />
        )}
      </>
    );
  }

  const fetchValues = () => api.getColumnValues(datasetId, {
    column_id: f.column_id, include_range: isDate });
  const fetchKey = `${datasetId}:${f.column_id}`;
  // 2026-10-25 -- typing searches EVERY value of the column on the server (a
  // "contains" on the same column), so a list cut at 500 is still picked from
  const searchValues = (q: string) => api.getColumnValues(datasetId, {
    column_id: f.column_id, parent_filters: [{ column_id: f.column_id, operator: 'contains', value: q }] });
  const blank = (v: any) => v === '' || v === null || v === undefined;

  if (kind === 'list') {
    return (
      <ColumnValuePicker multiple isDate={isDate} label={`${colName} values`}
        testId={`filter-${idx}-values`} fetchValues={fetchValues} fetchKey={fetchKey} searchValues={searchValues}
        value={f.value} onChange={v => onChange('value', v)}
        error={unfilled} sx={{ minWidth: 280 }} />
    );
  }
  if (kind === 'range') {
    return (
      <>
        <ColumnValuePicker isDate={isDate} label="From" testId={`filter-${idx}-from`}
          fetchValues={fetchValues} fetchKey={fetchKey} searchValues={searchValues}
          value={f.value} onChange={v => onChange('value', v)}
          error={unfilled && blank(f.value)} sx={{ minWidth: 170 }} />
        <Typography variant="body2" sx={{ mx: 0.5 }}>and</Typography>
        <ColumnValuePicker isDate={isDate} label="To" testId={`filter-${idx}-to`}
          fetchValues={fetchValues} fetchKey={fetchKey} searchValues={searchValues}
          value={f.value2} onChange={v => onChange('value2', v)}
          error={unfilled && blank(f.value2)} sx={{ minWidth: 170 }} />
      </>
    );
  }
  return (
    <ColumnValuePicker isDate={isDate} label={`${colName} value`} testId={`filter-${idx}-value`}
      fetchValues={fetchValues} fetchKey={fetchKey} searchValues={searchValues}
      value={f.value} onChange={v => onChange('value', v)}
      error={unfilled} sx={{ minWidth: 220 }} />
  );
}

export default ReportFilterValueInput;
