/**
 * The report canvas (2026-10-26, owner-approved design
 * docs/REPORT_CANVAS_DESIGN_2026_10_25.html).
 *
 * A report still runs ONE query: its columns are every field any tile uses.
 * Each tile is a view of that ONE result -- the stored, row-secured result
 * of the run -- never a second query to the source:
 *
 *   report  the report's own table (every existing feature: formatting,
 *           drill, slicers, paging through every row)
 *   table   chosen columns; with measures it is grouped by the other columns
 *   pivot   rows x one column field x measures
 *   bar / line / pie   one category field (+ an optional series) x a measure
 *   number  one measure over the whole result
 *
 * Tiles name columns by COLUMN ID (a renamed label cannot break a tile); the
 * physical name is resolved when the tile renders.  ``canvasProblems`` is the
 * ONE reading of what is wrong with a canvas, the builder shows it on the
 * tile it concerns, and the server applies the same rules on save
 * (backend/core/reports/canvas.py).
 */

export type TileKind = 'report' | 'number' | 'table' | 'pivot' | 'heatmap'
  | 'bar' | 'hbar' | 'stacked_bar' | 'line' | 'area' | 'stacked_area' | 'combo' | 'radar'
  | 'pie' | 'donut' | 'treemap' | 'funnel' | 'waterfall' | 'scatter' | 'bubble';
export type Aggregation = 'sum' | 'avg' | 'count' | 'min' | 'max' | 'count_distinct';

export const TILE_KINDS: TileKind[] = ['report', 'number', 'table', 'pivot', 'heatmap',
  'bar', 'hbar', 'stacked_bar', 'line', 'area', 'stacked_area', 'combo', 'radar',
  'pie', 'donut', 'treemap', 'funnel', 'waterfall', 'scatter', 'bubble'];
/** one category, 1..8 values (each a series) OR one value split by a series field */
export const SERIES_CHARTS: TileKind[] = ['bar', 'hbar', 'stacked_bar', 'line', 'area', 'stacked_area', 'radar'];
/** one category, one value */
export const ONE_VALUE_CHARTS: TileKind[] = ['pie', 'donut', 'treemap', 'funnel', 'waterfall'];
/** parts of a whole / a running total: the value is added up */
export const SUM_ONLY: TileKind[] = ['pie', 'donut', 'treemap', 'waterfall'];
export const CHART_KINDS: TileKind[] = [...SERIES_CHARTS, ...ONE_VALUE_CHARTS, 'combo', 'scatter', 'bubble'];
export const MAX_SERIES_VALUES = 8;
export const isChart = (k: TileKind) => CHART_KINDS.includes(k);
export const AGGREGATIONS: Aggregation[] = ['sum', 'avg', 'count', 'min', 'max', 'count_distinct'];
export const GRID_COLS = 12;
/** the deepest a canvas goes (grid rows); the server refuses and clamps to the same */
export const MAX_GRID_ROWS = 2000;
export const MAX_TILES = 40;
/** a chart draws at most this many categories; more are told, never dropped in silence */
export const MAX_CHART_POINTS = 500;
export const DEFAULT_CHART_POINTS = 25;
/** a pivot spreads at most this many column values across; more are told */
export const MAX_PIVOT_COLUMNS = 200;

export const KIND_LABEL: Record<TileKind, string> = {
  report: "The report's table", number: 'Number', table: 'Table', pivot: 'Pivot', heatmap: 'Heat map',
  bar: 'Bar chart', hbar: 'Bar chart (sideways)', stacked_bar: 'Stacked bars', line: 'Line chart',
  area: 'Area chart', stacked_area: 'Stacked areas', combo: 'Bars + lines', radar: 'Radar',
  pie: 'Pie chart', donut: 'Donut', treemap: 'Treemap', funnel: 'Funnel', waterfall: 'Waterfall',
  scatter: 'Scatter (x / y)', bubble: 'Bubble (x / y / size)',
};
export const AGG_LABEL: Record<Aggregation, string> = {
  sum: 'Sum', avg: 'Average', count: 'Count', min: 'Smallest', max: 'Largest',
  count_distinct: 'Count of different values',
};

export interface TileMeasure { column_id: number; aggregation: Aggregation }
export interface TileLayout { x: number; y: number; w: number; h: number }
export interface CanvasTile {
  id: string;
  kind: TileKind;
  title: string;
  /** table: its columns; pivot: its row fields; chart: [category]; number: [] */
  dimensions: number[];
  measures: TileMeasure[];
  /** pivot: the column field; bar/line: an optional series field */
  series: number | null;
  /** 'measure' sorts by the first measure; otherwise a column id */
  sort: { by: 'measure' | number; dir: 'asc' | 'desc' } | null;
  /** charts: how many categories to draw (the rest are counted and told) */
  top_n: number | null;
  layout: TileLayout;
}
export interface ReportCanvas { version: 1; tiles: CanvasTile[] }

/** The facts about a column a tile needs. */
export interface CanvasColumn {
  id: number;
  physical_name: string;
  label: string;
  data_type?: string | null;
  /** 'dimension' | 'measure' | 'kpi' | ... from the dataset */
  column_type?: string | null;
  aggregation?: string | null;
  /** the dataset column's display format (applyFormatPattern) */
  format_pattern?: string | null;
}

export interface CanvasProblem { tileId: string | null; message: string }

const NUMERIC = /int|decimal|numeric|double|float|real|number|money/i;
export const isNumericColumn = (c?: CanvasColumn | null) =>
  !!c && (NUMERIC.test(String(c.data_type || '')) || c.column_type === 'measure' || c.column_type === 'kpi');
export const isMeasureColumn = (c?: CanvasColumn | null) =>
  !!c && (c.column_type === 'measure' || c.column_type === 'kpi');

let _seq = 0;
export const newTileId = (kind: TileKind) =>
  `${kind}_${Date.now().toString(36)}${(_seq++).toString(36)}`;

const DATASET_AGGS = ['sum', 'avg', 'count', 'min', 'max', 'count_distinct'];
/** Does the query ADD UP this column (a measure with an aggregation)? */
export const emitsAggregate = (c?: CanvasColumn | null) =>
  !!c && isMeasureColumn(c) && DATASET_AGGS.includes(String(c.aggregation || '').toLowerCase());

/**
 * The server's grain rule (core/reports/canvas.py, the microcube): a dataset
 * that adds up any measure, or has a calculated metric, stores GROUPED rows.
 */
export function rowsAreGrouped(columns: CanvasColumn[], hasMetrics: boolean): boolean {
  return hasMetrics || columns.some(emitsAggregate);
}

/**
 * The ways a tile may add this column up that give an EXACT number for this
 * report.  Over grouped rows: an added-up measure is re-added (a count
 * measure too -- its "Total"), or its smallest / largest row taken; any other
 * column can be counted by its different values or its smallest / largest.
 * Over detail rows everything is exact; text cannot be added up or averaged.
 */
export function allowedAggregations(c: CanvasColumn | undefined | null, grouped: boolean): Aggregation[] {
  if (!c) return [];
  if (grouped) return emitsAggregate(c) ? ['sum', 'min', 'max'] : ['count_distinct', 'min', 'max'];
  return isNumericColumn(c) ? [...AGGREGATIONS] : ['count', 'count_distinct', 'min', 'max'];
}

/** How a tile adds this column up when it is first dropped. */
export function defaultAggregation(c: CanvasColumn | undefined | null, grouped = true): Aggregation {
  const allowed = allowedAggregations(c, grouped);
  const own = String(c?.aggregation || '').toLowerCase() as Aggregation;
  if (allowed.includes(own)) return own;
  if (allowed.includes('sum')) return 'sum';
  return allowed[0] ?? 'count_distinct';
}

/** The words for one value of a tile: "Amount (sum)", a count measure re-added is its "Total". */
export function measureWords(m: TileMeasure, cols: Map<number, CanvasColumn>, grouped: boolean): string {
  const c = cols.get(m.column_id);
  const name = c?.label ?? `column #${m.column_id}`;
  if (grouped && m.aggregation === 'sum' && String(c?.aggregation || '').toLowerCase() === 'count') return name;
  if (m.aggregation === 'sum' && emitsAggregate(c)) return name;
  return `${name} (${AGG_LABEL[m.aggregation]?.toLowerCase() ?? m.aggregation})`;
}

/** Size a new tile of this kind starts with. */
export function defaultSize(kind: TileKind): { w: number; h: number } {
  if (kind === 'number') return { w: 3, h: 2 };
  if (kind === 'report' || kind === 'table' || kind === 'pivot' || kind === 'heatmap') return { w: 12, h: 7 };
  return { w: 6, h: 5 };
}

/** The first free row under every tile. */
export function nextRow(tiles: CanvasTile[]): number {
  return tiles.reduce((m, t) => Math.max(m, t.layout.y + t.layout.h), 0);
}

export function makeTile(kind: TileKind, partial: Partial<CanvasTile>, tiles: CanvasTile[]): CanvasTile {
  const size = defaultSize(kind);
  return {
    id: newTileId(kind), kind, title: '', dimensions: [], measures: [], series: null,
    sort: isChart(kind) && !['line', 'area', 'stacked_area', 'waterfall', 'scatter', 'bubble'].includes(kind)
      ? { by: 'measure', dir: 'desc' } : null,
    top_n: isChart(kind) ? DEFAULT_CHART_POINTS : null,
    ...partial,
    layout: partial.layout ?? { x: 0, y: nextRow(tiles), ...size },
  };
}

/** An existing report (no canvas yet) opens as ONE tile: its own table. */
export function defaultCanvas(): ReportCanvas {
  return { version: 1, tiles: [makeTile('report', { id: 'report', title: '' }, [])] };
}

/** Read whatever is stored; anything unreadable becomes the default canvas. */
export function readCanvas(layoutConfig: any): ReportCanvas | null {
  const c = layoutConfig?.canvas;
  if (!c || typeof c !== 'object' || !Array.isArray(c.tiles)) return null;
  return {
    version: 1,
    tiles: c.tiles.filter((t: any) => t && typeof t === 'object').map((t: any) => ({
      id: String(t.id ?? ''), kind: t.kind, title: String(t.title ?? ''),
      dimensions: Array.isArray(t.dimensions) ? t.dimensions.map(Number) : [],
      measures: Array.isArray(t.measures)
        ? t.measures.map((m: any) => ({ column_id: Number(m?.column_id), aggregation: m?.aggregation }))
        : [],
      series: t.series == null ? null : Number(t.series),
      sort: t.sort && typeof t.sort === 'object'
        ? { by: t.sort.by === 'measure' ? 'measure' : Number(t.sort.by), dir: t.sort.dir === 'asc' ? 'asc' : 'desc' }
        : null,
      top_n: t.top_n == null ? null : Number(t.top_n),
      layout: {
        x: Number(t.layout?.x ?? 0), y: Number(t.layout?.y ?? 0),
        w: Number(t.layout?.w ?? 6), h: Number(t.layout?.h ?? 4),
      },
    })),
  };
}

/** Every column id a canvas needs the report's query to return. */
export function canvasColumnIds(canvas: ReportCanvas): number[] {
  const ids = new Set<number>();
  for (const t of canvas.tiles) {
    t.dimensions.forEach(i => ids.add(i));
    t.measures.forEach(m => ids.add(m.column_id));
    if (t.series != null) ids.add(t.series);
    if (t.sort && t.sort.by !== 'measure') ids.add(t.sort.by);
  }
  return [...ids];
}

export function tileName(t: CanvasTile, cols: Map<number, CanvasColumn>): string {
  if (t.title.trim()) return t.title.trim();
  if (t.kind === 'report') return 'Report';
  const m = t.measures[0] ? cols.get(t.measures[0].column_id)?.label : '';
  const d = t.dimensions[0] ? cols.get(t.dimensions[0])?.label : '';
  if (t.kind === 'number') return m || 'Number';
  if (m && d) return `${m} by ${d}`;
  return m || d || KIND_LABEL[t.kind];
}

/**
 * Everything wrong with a canvas, each said once on the tile it concerns.
 * ``columns`` are the fields the report can show (its dataset's columns).
 * An empty list = nothing stops a save.
 */
export function canvasProblems(canvas: ReportCanvas, columns: CanvasColumn[],
                               opts: { grouped?: boolean; selected?: number[] | null } = {}): CanvasProblem[] {
  const grouped = opts.grouped ?? true;
  const selected = opts.selected ? new Set(opts.selected) : null;
  const out: CanvasProblem[] = [];
  const cols = new Map(columns.map(c => [c.id, c]));
  const say = (t: CanvasTile | null, message: string) =>
    out.push({ tileId: t ? t.id : null, message: t ? `${tileName(t, cols)}: ${message}` : message });

  if (canvas.tiles.length === 0) say(null, 'The report has no tiles. Add at least one.');
  if (canvas.tiles.length > MAX_TILES) say(null, `A report can hold ${MAX_TILES} tiles; this one has ${canvas.tiles.length}.`);
  if (canvas.tiles.filter(t => t.kind === 'report').length > 1) say(null, "The report's own table can be placed once.");
  const seen = new Set<string>();
  for (const t of canvas.tiles) {
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(t.id) || seen.has(t.id)) say(t, 'its id is missing or used twice.');
    seen.add(t.id);
    if (!TILE_KINDS.includes(t.kind)) { say(t, `"${t.kind}" is not a kind of tile.`); continue; }
    if (t.title.length > 200) say(t, 'its title is longer than 200 characters.');
    const { x, y, w, h } = t.layout;
    if (![x, y, w, h].every(Number.isInteger) || x < 0 || y < 0 || w < 1 || h < 1 || x + w > GRID_COLS || h > 60 || y + h > MAX_GRID_ROWS) {
      say(t, 'its place on the page is outside the 12-column grid.');
    }
    const fields = [...t.dimensions, ...t.measures.map(m => m.column_id), ...(t.series != null ? [t.series] : [])];
    for (const id of fields) {
      if (!cols.has(id)) say(t, `it uses a field that is no longer in the data (column #${id}). Remove it from the tile.`);
      else if (selected && !selected.has(id)) say(t, `${cols.get(id)!.label} is not one of the report's columns, so the report does not return it. Add it to the report.`);
    }
    if (new Set(t.dimensions).size !== t.dimensions.length) say(t, 'the same field is used twice.');
    for (const m of t.measures) {
      if (!AGGREGATIONS.includes(m.aggregation)) { say(t, `"${m.aggregation}" is not a way to add up values.`); continue; }
      const c = cols.get(m.column_id);
      if (c && ['sum', 'avg'].includes(m.aggregation) && !isNumericColumn(c)) {
        say(t, `${c.label} is not a number, so it cannot be ${m.aggregation === 'sum' ? 'added up' : 'averaged'}. Use Count of different values instead.`);
      } else if (c && grouped && m.aggregation === 'count') {
        say(t, 'this report\'s rows are already added up, so counting them would count groups, not the underlying rows. Use a count measure of the data, or Count of different values.');
      } else if (c && grouped && m.aggregation === 'avg') {
        say(t, `this report's rows are already added up, so an average of ${c.label} here would be an average of averages -- a wrong number. Show the Sum instead.`);
      } else if (c && grouped && m.aggregation === 'count_distinct' && emitsAggregate(c)) {
        say(t, `${c.label} is added up in this report's rows, so its different values cannot be counted.`);
      }
    }
    if (t.top_n != null && (!Number.isInteger(t.top_n) || t.top_n < 1 || t.top_n > MAX_CHART_POINTS)) {
      say(t, `it can draw between 1 and ${MAX_CHART_POINTS} values.`);
    }
    switch (t.kind) {
      case 'report': break;
      case 'table':
        if (t.dimensions.length === 0 && t.measures.length === 0) say(t, 'add at least one field.');
        break;
      case 'pivot':
        if (t.dimensions.length === 0) say(t, 'needs at least one row field.');
        if (t.series == null) say(t, 'needs a column field to spread across.');
        if (t.series != null && t.dimensions.includes(t.series)) say(t, 'the column field is also a row field.');
        if (t.measures.length === 0) say(t, 'needs a value to show.');
        break;
      case 'heatmap':
        if (t.dimensions.length !== 1) say(t, 'needs one row field.');
        if (t.series == null) say(t, 'needs a column field to spread across.');
        else if (t.dimensions.includes(t.series)) say(t, 'the column field is also the row field.');
        if (t.measures.length !== 1) say(t, 'needs exactly one value to colour the cells by.');
        break;
      case 'number':
        if (t.measures.length !== 1 || t.dimensions.length > 0) say(t, 'shows exactly one value and no fields.');
        break;
      default:
        if (!isChart(t.kind)) break;
        if (t.dimensions.length !== 1) {
          say(t, t.kind === 'scatter' || t.kind === 'bubble' ? 'needs one field that names each point.' : 'needs exactly one category field.');
        }
        if (SERIES_CHARTS.includes(t.kind)) {
          if (t.measures.length < 1 || t.measures.length > MAX_SERIES_VALUES) say(t, `draws between 1 and ${MAX_SERIES_VALUES} values.`);
          if (t.series != null && t.measures.length > 1) say(t, 'can be split by a series field OR show several values -- not both.');
        } else if (ONE_VALUE_CHARTS.includes(t.kind)) {
          if (t.measures.length !== 1) say(t, 'needs exactly one value to draw.');
          if (t.series != null) say(t, 'cannot be split into series.');
          if (SUM_ONLY.includes(t.kind) && t.measures.some(m => m.aggregation !== 'sum')) {
            say(t, `${t.kind === 'waterfall' ? 'a waterfall adds its values up as it goes' : 'shows parts of a whole'}, so its value must be added up (Sum).`);
          }
        } else if (t.kind === 'combo') {
          if (t.measures.length < 2 || t.measures.length > MAX_SERIES_VALUES) say(t, `needs 2 to ${MAX_SERIES_VALUES} values: the first as bars, the rest as lines.`);
          if (t.series != null) say(t, 'cannot be split into series.');
        } else if (t.kind === 'scatter' && t.measures.length !== 2) {
          say(t, 'needs two values: across (x) and up (y).');
        } else if (t.kind === 'bubble' && t.measures.length !== 3) {
          say(t, 'needs three values: across (x), up (y) and the bubble size.');
        }
        if ((t.kind === 'scatter' || t.kind === 'bubble') && t.series != null) say(t, 'cannot be split into series.');
        if (t.series != null && t.dimensions.includes(t.series)) say(t, 'the series field is also the category.');
    }
  }
  // overlapping tiles: the grid never stores them, a hand-edited canvas might
  for (let i = 0; i < canvas.tiles.length; i++) {
    for (let j = i + 1; j < canvas.tiles.length; j++) {
      const a = canvas.tiles[i].layout, b = canvas.tiles[j].layout;
      if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) {
        say(canvas.tiles[j], `it sits on top of ${tileName(canvas.tiles[i], cols)}.`);
      }
    }
  }
  return out;
}

/** The output name of a tile's i-th value (never collides with a column name). */
export const measureAlias = (i: number) => `v${i}__`;

/** The body of one cube 'drill' call for a tile (null = the tile does not use the cube). */
export function tileCubeBody(t: CanvasTile, cols: Map<number, CanvasColumn>, page = 1, pageSize = 500) {
  if (t.kind === 'report') return null;
  const name = (id: number) => cols.get(id)?.physical_name || '';
  const dims = [...t.dimensions, ...(t.series != null ? [t.series] : [])].map(name);
  const measures = t.measures.map((m, i) => ({ column: name(m.column_id), aggregation: m.aggregation, alias: measureAlias(i) }));
  const firstMeasure = measures[0] ? measures[0].alias : null;
  let sortColumn: string | null = null;
  let sortDir: 'asc' | 'desc' = 'asc';
  if (t.sort) {
    sortColumn = t.sort.by === 'measure' ? firstMeasure : name(t.sort.by);
    sortDir = t.sort.dir;
  } else if (['line', 'area', 'stacked_area', 'waterfall', 'pivot', 'heatmap', 'table'].includes(t.kind)) {
    sortColumn = dims[0] || null;
  }
  return {
    operation: 'drill', dimensions: dims, measures, path_filters: [], slicers: {},
    sort_column: sortColumn, sort_direction: sortDir, page, page_size: pageSize,
  };
}
