/**
 * The report canvas on a 12-column grid (2026-10-26) -- the viewer's
 * read-only page and the builder's editable one are the SAME component, so a
 * report looks the same while it is built and when it is read.
 *
 * Uses react-grid-layout (already the dashboards' grid, v2 API).  Editable:
 * tiles drag by their header, resize from the corner, a click selects one,
 * and a field dragged from the builder's field list drops onto a tile (adds
 * it) or onto the empty canvas (a new tile).  On a narrow screen the tiles
 * stack in reading order, full width.
 */
import React from 'react';
import { Box, Paper, Typography, useMediaQuery, useTheme } from '@mui/material';
import GridLayout, { useContainerWidth } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import CanvasTileView, { CubeFetch, TileRunInfo } from './CanvasTileView';
import { CanvasColumn, CanvasTile, GRID_COLS, ReportCanvas, TileLayout } from './canvasModel';

export const ROW_HEIGHT = 56;
const MARGIN = 10;
export const FIELD_MIME = 'application/x-qs-canvas-field';

interface Props {
  canvas: ReportCanvas;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  grouped: boolean;
  run: TileRunInfo;
  reportTable?: React.ReactNode;
  editable?: boolean;
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  onLayout?: (layouts: Record<string, TileLayout>) => void;
  /** a field dropped on a tile (tileId) or on the empty canvas (null) */
  onDropField?: (columnId: number, tileId: string | null) => void;
  /** problems by tile id -- shown on the tile in the builder */
  problems?: Record<string, string[]>;
  /** a share link / embed reads its tiles through its own route */
  cubeFetch?: CubeFetch;
  /** the builder: per tile, the fields the shown preview ran without */
  staleFields?: Record<string, string[]>;
}

export default function ReportCanvasView({
  canvas, reportId, cols, grouped, run, reportTable, editable = false, selectedId, onSelect, onLayout,
  onDropField, problems, cubeFetch, staleFields,
}: Props) {
  const theme = useTheme();
  const narrow = useMediaQuery(theme.breakpoints.down('md'));
  const { width, containerRef, mounted } = useContainerWidth({ initialWidth: 1000 });
  const colWidth = (Math.max(320, width) - MARGIN * (GRID_COLS + 1)) / GRID_COLS;
  const pxW = (w: number) => Math.max(120, w * colWidth + (w - 1) * MARGIN - 24);
  const pxH = (h: number) => Math.max(60, h * ROW_HEIGHT + (h - 1) * MARGIN - 24);

  const fieldFrom = (e: React.DragEvent): number | null => {
    const raw = e.dataTransfer.getData(FIELD_MIME);
    const n = Number(raw);
    return raw && Number.isFinite(n) ? n : null;
  };
  const dropProps = (tileId: string | null) => editable && onDropField ? {
    onDragOver: (e: React.DragEvent) => {
      if (e.dataTransfer.types.includes(FIELD_MIME)) { e.preventDefault(); e.stopPropagation(); }
    },
    onDrop: (e: React.DragEvent) => {
      const id = fieldFrom(e);
      if (id != null) { e.preventDefault(); e.stopPropagation(); onDropField(id, tileId); }
    },
  } : {};

  const tileBox = (t: CanvasTile, w: number, h: number) => {
    const isSel = editable && selectedId === t.id;
    const tp = problems?.[t.id] ?? [];
    return (
      <Paper variant="outlined" data-testid={`canvas-tile-${t.id}`}
        onMouseDown={() => editable && onSelect?.(t.id)}
        {...dropProps(t.id)}
        sx={{
          height: '100%', p: 1.5, overflow: 'hidden', display: 'flex', flexDirection: 'column',
          borderColor: tp.length ? 'error.main' : isSel ? 'primary.main' : 'divider',
          borderWidth: isSel || tp.length ? 2 : 1,
        }}>
        {editable && (
          <Box className="canvas-drag-handle" sx={{ cursor: 'move', height: 6, mx: -1.5, mt: -1.5, mb: 0.5, bgcolor: isSel ? 'primary.light' : 'action.hover' }}
            aria-label="Drag to move this tile" />
        )}
        {tp.length > 0 && (
          <Typography variant="caption" color="error" component="div" data-testid={`tile-problem-${t.id}`}>
            {tp.join(' ')}
          </Typography>
        )}
        <Box sx={{ flex: 1, minHeight: 0, overflow: t.kind === 'report' ? 'auto' : 'hidden' }}>
          <CanvasTileView tile={t} reportId={reportId} cols={cols} grouped={grouped} run={run}
            reportTable={reportTable} width={w} height={h} cubeFetch={cubeFetch}
            staleFields={staleFields?.[t.id]} />
        </Box>
      </Paper>
    );
  };

  const empty = canvas.tiles.length === 0;
  if (narrow && !editable) {
    const ordered = [...canvas.tiles].sort((a, b) => a.layout.y - b.layout.y || a.layout.x - b.layout.x);
    return (
      <Box ref={containerRef} data-testid="report-canvas" data-layout="stacked" sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {ordered.map(t => (
          <Box key={t.id} sx={{ minHeight: t.kind === 'number' ? 110 : t.kind === 'report' ? undefined : 300 }}>
            {tileBox(t, Math.max(280, width - 24), t.kind === 'number' ? 90 : 280)}
          </Box>
        ))}
      </Box>
    );
  }
  return (
    <Box ref={containerRef} data-testid="report-canvas" data-layout="grid" {...dropProps(null)}
      onMouseDown={e => { if (editable && e.target === e.currentTarget) onSelect?.(null); }}
      sx={{ minHeight: editable ? 400 : undefined, position: 'relative',
            bgcolor: editable ? 'action.hover' : undefined, borderRadius: 1 }}>
      {empty && editable && (
        <Box sx={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <Typography color="text.secondary">Drag a field here to start, or pick a tile kind on the right.</Typography>
        </Box>
      )}
      {mounted && (
        <GridLayout
          width={Math.max(320, width)}
          layout={canvas.tiles.map(t => ({ i: t.id, ...t.layout, minW: 2, minH: 2 }))}
          gridConfig={{ cols: GRID_COLS, rowHeight: ROW_HEIGHT, margin: [MARGIN, MARGIN] }}
          dragConfig={{ enabled: editable, handle: '.canvas-drag-handle' }}
          resizeConfig={{ enabled: editable }}
          onLayoutChange={(layout: any) => {
            if (!editable || !onLayout) return;
            const next: Record<string, TileLayout> = {};
            for (const l of layout) next[l.i] = { x: l.x, y: l.y, w: l.w, h: l.h };
            onLayout(next);
          }}
        >
          {canvas.tiles.map(t => (
            <div key={t.id}>{tileBox(t, pxW(t.layout.w), pxH(t.layout.h))}</div>
          ))}
        </GridLayout>
      )}
    </Box>
  );
}
