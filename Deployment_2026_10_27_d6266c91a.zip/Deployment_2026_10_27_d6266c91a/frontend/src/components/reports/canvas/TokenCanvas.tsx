/**
 * A canvas report on a share link / embed (2026-10-26).
 *
 * The token run returns ``canvas_handle`` (its own stored result, sealed for
 * this link) and ``canvas_columns`` (the fields the tiles use); every tile
 * asks the link's cube route with that handle -- the rows this link was
 * served, added up, and nothing else.  The report's own table is the page's
 * rows table, so it is not repeated here.
 */
import { useMemo } from 'react';
import { Alert, Box } from '@mui/material';
import ReportCanvasView from './ReportCanvasView';
import { CanvasColumn, readCanvas, rowsAreGrouped } from './canvasModel';

interface Props {
  report: any;
  result: any;
  /** POST one cube body (with the handle) to this link's route */
  cube: (body: any) => Promise<any>;
}

export default function TokenCanvas({ report, result, cube }: Props) {
  const canvas = useMemo(() => {
    const c = readCanvas(report?.layout_config);
    if (!c) return null;
    const tiles = c.tiles.filter(t => t.kind !== 'report');
    if (tiles.length === 0) return null;
    // close the gap the report's own table leaves: tiles keep their order
    const top = Math.min(...tiles.map(t => t.layout.y));
    return { ...c, tiles: tiles.map(t => ({ ...t, layout: { ...t.layout, y: t.layout.y - top } })) };
  }, [report?.layout_config]);
  const cols = useMemo(() => new Map<number, CanvasColumn>(((result?.canvas_columns || []) as any[]).map(c => [Number(c.id), {
    id: Number(c.id), physical_name: c.physical_name, label: c.label || c.physical_name, data_type: c.data_type,
    column_type: c.column_type, aggregation: c.aggregation, format_pattern: c.format_pattern,
  }])), [result?.canvas_columns]);
  if (!canvas || !result) return null;
  const handle: string | undefined = result.canvas_handle;
  if (!handle) {
    return (
      <Alert severity="info" sx={{ mb: 2 }} data-testid="token-canvas-unavailable">
        This report&apos;s charts and numbers could not be prepared for this run. Its rows are below.
      </Alert>
    );
  }
  return (
    <Box sx={{ mb: 2 }} data-testid="token-canvas">
      <ReportCanvasView canvas={canvas} reportId={Number(report?.id) || 0} cols={cols}
        grouped={rowsAreGrouped([...cols.values()], false)}
        run={{ executionId: 'link', totalRows: typeof result.total_rows === 'number' ? result.total_rows : null,
               truncated: result.truncated === true, rowLimit: result.row_limit ?? null }}
        cubeFetch={(_r, _e, body) => cube({ ...body, handle })} />
    </Box>
  );
}
