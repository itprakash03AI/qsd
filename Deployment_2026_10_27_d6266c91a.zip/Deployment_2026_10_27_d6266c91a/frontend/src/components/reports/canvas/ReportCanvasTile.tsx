/**
 * A canvas report on a DASHBOARD tile (2026-10-26).
 *
 * The dashboard tile already runs the report as the signed-in person (its
 * filters as parameters); this draws the report's canvas from THAT run --
 * the same cube route the report viewer uses, so a number on the dashboard
 * is the number in the report.  A report without a canvas keeps the
 * dashboard's own chart / grid (``fallback``), unchanged.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { Box, CircularProgress } from '@mui/material';
import api from '../../../services/api';
import ReportCanvasView from './ReportCanvasView';
import { CanvasColumn, readCanvas, ReportCanvas, rowsAreGrouped } from './canvasModel';

interface Props {
  reportId: number;
  executionId: string | null;
  totalRows: number | null;
  truncated?: boolean;
  fallback: React.ReactNode;
}

export default function ReportCanvasTile({ reportId, executionId, totalRows, truncated, fallback }: Props) {
  const [state, setState] = useState<{ canvas: ReportCanvas | null; cols: CanvasColumn[]; ready: boolean }>(
    { canvas: null, cols: [], ready: false });
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await api.getBusinessReport(reportId);
        const c = readCanvas(r?.layout_config);
        const tiles = (c?.tiles || []).filter(t => t.kind !== 'report');
        if (!c || tiles.length === 0 || !r?.dataset_id) {
          if (!cancelled) setState({ canvas: null, cols: [], ready: true });
          return;
        }
        const top = Math.min(...tiles.map(t => t.layout.y));
        const ds = await api.getDataset(r.dataset_id);
        const cols = ((ds?.columns || []) as any[]).map(x => ({
          id: Number(x.id), physical_name: x.physical_name, label: x.friendly_name || x.physical_name,
          data_type: x.data_type, column_type: x.column_type, aggregation: x.aggregation, format_pattern: x.format_pattern,
        }));
        if (!cancelled) {
          setState({ canvas: { ...c, tiles: tiles.map(t => ({ ...t, layout: { ...t.layout, y: t.layout.y - top } })) },
                     cols, ready: true });
        }
      } catch {
        // the dashboard's own view still works; a canvas we cannot read is not drawn
        if (!cancelled) setState({ canvas: null, cols: [], ready: true });
      }
    })();
    return () => { cancelled = true; };
  }, [reportId]);
  const colMap = useMemo(() => new Map(state.cols.map(c => [c.id, c])), [state.cols]);
  if (!state.ready) return <Box sx={{ p: 2, textAlign: 'center' }}><CircularProgress size={18} /></Box>;
  if (!state.canvas) return <>{fallback}</>;
  return (
    <Box sx={{ height: '100%', overflow: 'auto', p: 0.5 }} data-testid="dashboard-report-canvas">
      <ReportCanvasView canvas={state.canvas} reportId={reportId} cols={colMap}
        grouped={rowsAreGrouped(state.cols, false)}
        run={{ executionId, totalRows, truncated: !!truncated }} />
    </Box>
  );
}
