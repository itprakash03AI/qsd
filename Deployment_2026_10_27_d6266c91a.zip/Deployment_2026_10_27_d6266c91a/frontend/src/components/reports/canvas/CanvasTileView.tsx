/**
 * One tile of the report canvas (2026-10-26).
 *
 * Every number comes from the run's STORED, row-secured result through the
 * microcube (POST /results/{exec_id}/cube 'drill') -- the same answer the
 * exports and the API give; nothing is recomputed in the browser.  What a
 * tile cannot show is said in words on the tile: no run yet, no rows, a value
 * that cannot be shown at this level (422), a result still being built (409),
 * a run older than a field the tile uses (400), more categories than drawn.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, CircularProgress, Table, TableBody, TableCell, TableHead, TableRow,
  TableSortLabel, Tooltip, Typography,
} from '@mui/material';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Funnel, FunnelChart, LabelList, Legend,
  Line, LineChart, Pie, PieChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, Scatter,
  ScatterChart, Tooltip as ReTooltip, Treemap, XAxis, YAxis, ZAxis,
} from 'recharts';
import api from '../../../services/api';
import { applyFormatPattern } from '../../../utils/formatters';
import ListPager, { type Paging } from '../../common/ListPager';
import { CHART_OTHER_COLOR, CHART_SERIES_COLORS } from '../../ReportChartView';
import {
  CanvasColumn, CanvasTile, MAX_PIVOT_COLUMNS, measureAlias, measureWords, SERIES_CHARTS, tileCubeBody, tileName,
} from './canvasModel';

/** kinds whose categories read in their own order (time, a sequence), not largest first */
const ORDERED = ['line', 'area', 'stacked_area', 'waterfall'];
/** a part-of-a-whole chart: its remainder is "Everything else" */
const WHOLE = ['pie', 'donut', 'treemap'];

export interface TileRunInfo {
  /** the run whose stored result the tiles read; null = not run yet */
  executionId: string | null;
  /** rows in that result (0 = the run returned nothing) */
  totalRows: number | null;
  /** the result was cut by a row limit: every tile says so */
  truncated: boolean;
  rowLimit?: number | null;
}

interface Props {
  tile: CanvasTile;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  grouped: boolean;
  run: TileRunInfo;
  /** the report's own table (kind 'report') -- rendered as is */
  reportTable?: React.ReactNode;
  width: number;
  height: number;
  /** a share link / embed asks ITS cube route with its handle (default: the signed-in route) */
  cubeFetch?: CubeFetch;
  /** the builder: this tile uses fields the shown preview ran WITHOUT (their names) */
  staleFields?: string[];
}

/** One cube request for a tile; the signed-in road is api.queryReportCube. */
export type CubeFetch = (reportId: number, executionId: string, body: any) => Promise<any>;

const MAX_SERIES = 8;
const PIVOT_FETCH = 50_000;

/** A cell's words: the column's own format, else a readable number; NULL is "(no value)". */
export function formatValue(v: any, c?: CanvasColumn | null): string {
  if (v === null || v === undefined) return '(no value)';
  if (v === '') return '(blank)';
  const pattern = c?.format_pattern;
  if (pattern) {
    const f = applyFormatPattern(v, pattern, c?.data_type || undefined);
    if (f != null) return f;
  }
  if (typeof v === 'number') return v.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (typeof v === 'string' && /^-?\d+(\.\d+)?$/.test(v) && v.length < 16) {
    return Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T00:00:00/.test(v)) return v.slice(0, 10);
  return String(v);
}

/** The shared pager's block for one page of a tile (first / last are 1-based; none when empty). */
export function pagingFor(total: number, page: number, pageSize: number, shown: number): Paging {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const first = total === 0 ? 0 : (page - 1) * pageSize + 1;
  return { total, page, page_size: pageSize, pages, first, last: total === 0 ? 0 : first + Math.max(0, shown) - 1 };
}

const toNum = (v: any): number | null => {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : null;
};

/** The plain sentence for a failed tile request. */
export function tileErrorWords(err: any, cols: Map<number, CanvasColumn>): string {
  const status = err?.status;
  const detail = err?.detail;
  if (status === 422 && detail?.refused) {
    const names = (detail.refused as any[]).map(r => {
      const c = [...cols.values()].find(x => x.physical_name === r.column);
      return `${c?.label ?? r.column}: ${r.reason}`;
    });
    return `This value cannot be shown at this level. ${names.join('; ')}`;
  }
  if (status === 409) return String(err?.message || 'This run’s result is not ready yet. Try again shortly.');
  if (status === 400) {
    return 'This run does not have every field this tile uses (the report changed after it ran). Run the report again.';
  }
  if (status === 404) return 'This run’s result is no longer available. Run the report again.';
  if (status === 403) return 'You do not have access to this run’s result.';
  return String(err?.message || 'The tile could not be read.');
}

function useTileData(tile: CanvasTile, reportId: number | null, cols: Map<number, CanvasColumn>,
                     run: TileRunInfo, page: number, pageSize: number, sort: { col: string; dir: 'asc' | 'desc' } | null,
                     cubeFetch?: CubeFetch) {
  const cube = cubeFetch ?? ((r: number, e: string, b: any) => api.queryReportCube(r, e, b));
  const [state, setState] = useState<{ loading: boolean; error: string; data: any | null; extra: any | null }>(
    { loading: false, error: '', data: null, extra: null });
  const key = JSON.stringify([tile.kind, tile.dimensions, tile.measures, tile.series, tile.sort, tile.top_n,
    run.executionId, page, pageSize, sort]);
  useEffect(() => {
    if (tile.kind === 'report' || !reportId || !run.executionId) {
      setState({ loading: false, error: '', data: null, extra: null });
      return;
    }
    let cancelled = false;
    const exec = run.executionId;
    (async () => {
      setState(s => ({ ...s, loading: true, error: '' }));
      try {
        const base: any = tileCubeBody(tile, cols, 1, 500);
        if (!base) throw new Error('This tile has nothing to show yet.');
        let data: any;
        let extra: any = null;
        if (tile.kind === 'number') {
          data = await cube(reportId, exec, { ...base, dimensions: [], page: 1, page_size: 1 });
        } else if (tile.kind === 'table') {
          const body = { ...base, page, page_size: pageSize };
          if (sort) { body.sort_column = sort.col; body.sort_direction = sort.dir; }
          data = await cube(reportId, exec, body);
        } else if (tile.kind === 'pivot' || tile.kind === 'heatmap') {
          data = await cube(reportId, exec, { ...base, page: 1, page_size: PIVOT_FETCH });
        } else {
          // charts: the top categories first, then (with a series) only those categories
          const cat = cols.get(tile.dimensions[0])?.physical_name || '';
          const topN = tile.top_n ?? 25;
          const catBody = { ...base, dimensions: [cat], page: 1, page_size: topN };
          if (ORDERED.includes(tile.kind) && !tile.sort) { catBody.sort_column = cat; catBody.sort_direction = 'asc'; }
          data = await cube(reportId, exec, catBody);
          if (tile.series != null && SERIES_CHARTS.includes(tile.kind)) {
            const ser = cols.get(tile.series)?.physical_name || '';
            const shown = (data.rows || []).map((r: any) => r[cat]);
            const seriesTotals = await cube(reportId, exec, {
              ...base, dimensions: [ser], page: 1, page_size: MAX_SERIES,
              sort_column: measureAlias(0), sort_direction: 'desc',
            });
            const pairs = await cube(reportId, exec, {
              ...base, dimensions: [cat, ser], page: 1, page_size: Math.max(1, shown.length) * MAX_SERIES * 4,
              slicers: { [cat]: shown.filter((v: any) => v !== null), [ser]: (seriesTotals.rows || []).map((r: any) => r[ser]).filter((v: any) => v !== null) },
            });
            extra = { seriesTotals, pairs, cat, ser };
          }
          if (WHOLE.includes(tile.kind)) {
            extra = { ...(extra || {}), whole: await cube(reportId, exec, { ...base, dimensions: [], page: 1, page_size: 1 }) };
          }
        }
        if (!cancelled) setState({ loading: false, error: '', data, extra });
      } catch (err: any) {
        if (!cancelled) setState({ loading: false, error: tileErrorWords(err, cols), data: null, extra: null });
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, reportId]);
  return state;
}

export default function CanvasTileView({ tile, reportId, cols, grouped, run, reportTable, width, height, cubeFetch, staleFields }: Props) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [sort, setSort] = useState<{ col: string; dir: 'asc' | 'desc' } | null>(null);
  useEffect(() => { setPage(1); }, [run.executionId, pageSize, sort]);
  const stale = !!staleFields && staleFields.length > 0;
  const { loading, error, data, extra } = useTileData(tile, reportId, cols,
    stale ? { ...run, executionId: null } : run, page, pageSize, sort, cubeFetch);
  const title = tileName(tile, cols);

  if (tile.kind === 'report') return <>{reportTable}</>;

  let body: React.ReactNode = null;
  if (stale && run.executionId) {
    body = (
      <Typography variant="body2" color="text.secondary" data-testid="tile-stale">
        Press Preview again to see this tile: {staleFields!.join(', ')} {staleFields!.length === 1 ? 'was' : 'were'} added
        after the preview ran.
      </Typography>
    );
  } else if (!run.executionId) {
    body = <Typography variant="body2" color="text.secondary" data-testid="tile-not-run">Run the report to see this.</Typography>;
  } else if (error) {
    body = <Alert severity="warning" data-testid="tile-error" sx={{ py: 0 }}>{error}</Alert>;
  } else if (loading && !data) {
    body = <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}><CircularProgress size={20} /></Box>;
  } else if (data) {
    body = renderBody();
  }

  function renderBody(): React.ReactNode {
    const rows: any[] = data.rows || [];
    const dimNames = tile.dimensions.map(id => cols.get(id)?.physical_name || '');
    if (tile.kind === 'number') {
      const m = tile.measures[0];
      const v = rows[0]?.[measureAlias(0)];
      if (run.totalRows === 0) return <Typography variant="h5" color="text.secondary" data-testid="tile-number">No rows</Typography>;
      const text = v === null || v === undefined ? 'No value' : formatValue(v, cols.get(m.column_id));
      // the number FITS its tile: the font follows the width and the length
      const byWidth = (width - 8) / Math.max(4, text.length * 0.62);
      const size = Math.max(14, Math.min(44, height / 3, byWidth));
      return (
        <Box data-testid="tile-number">
          <Typography title={text} noWrap sx={{ fontSize: size, fontWeight: 700, lineHeight: 1.1 }}>
            {text}
          </Typography>
          <Typography variant="caption" color="text.secondary">{measureWords(m, cols, grouped)}</Typography>
        </Box>
      );
    }
    if (tile.kind === 'table') {
      const total = data.total_rows ?? rows.length;
      const headers = [
        ...tile.dimensions.map(id => ({ key: cols.get(id)?.physical_name || '', label: cols.get(id)?.label || `#${id}`, col: cols.get(id) })),
        ...tile.measures.map((m, i) => ({ key: measureAlias(i), label: measureWords(m, cols, grouped), col: cols.get(m.column_id) })),
      ];
      return (
        <Box sx={{ overflow: 'auto', height: '100%' }}>
          <Table size="small" stickyHeader aria-label={title}>
            <TableHead>
              <TableRow>
                {headers.map(h => (
                  <TableCell key={h.key} sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    <TableSortLabel active={sort?.col === h.key} direction={sort?.col === h.key ? sort.dir : 'asc'}
                      onClick={() => setSort(s => s?.col === h.key ? { col: h.key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { col: h.key, dir: 'asc' })}>
                      {h.label}
                    </TableSortLabel>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={headers.length}>
                  <Typography variant="body2" color="text.secondary">No rows.</Typography>
                </TableCell></TableRow>
              )}
              {rows.map((r, i) => (
                <TableRow key={i} hover>
                  {headers.map((h, j) => (
                    <TableCell key={h.key} align={j >= tile.dimensions.length ? 'right' : 'left'} sx={{ whiteSpace: 'nowrap' }}>
                      {formatValue(r[h.key], h.col)}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={pagingFor(total, page, pageSize, rows.length)}
            onPage={setPage} onPageSize={setPageSize} testid={`tile-pager-${tile.id}`} />
        </Box>
      );
    }
    if (tile.kind === 'pivot' || tile.kind === 'heatmap') {
      const ser = cols.get(tile.series!)?.physical_name || '';
      const heat = tile.kind === 'heatmap';
      const heatVals = heat ? rows.map(r => toNum(r[measureAlias(0)])).filter((x): x is number => x != null) : [];
      const hMin = heatVals.length ? Math.min(...heatVals) : 0;
      const hMax = heatVals.length ? Math.max(...heatVals) : 0;
      const heatBg = (v: any) => {
        const n = toNum(v);
        if (!heat || n == null || hMax === hMin) return undefined;
        const f = (n - hMin) / (hMax - hMin);
        return `rgba(42, 120, 214, ${(0.08 + 0.72 * f).toFixed(2)})`;
      };
      const seriesVals: any[] = [];
      const seen = new Set<string>();
      for (const r of rows) {
        const k = JSON.stringify(r[ser]);
        if (!seen.has(k)) { seen.add(k); seriesVals.push(r[ser]); }
      }
      seriesVals.sort((a, b) => (a === null ? 1 : b === null ? -1 : String(a).localeCompare(String(b), undefined, { numeric: true })));
      const shownSeries = seriesVals.slice(0, MAX_PIVOT_COLUMNS);
      const byRow = new Map<string, { keys: any[]; cells: Map<string, any> }>();
      for (const r of rows) {
        const rk = JSON.stringify(dimNames.map(d => r[d]));
        if (!byRow.has(rk)) byRow.set(rk, { keys: dimNames.map(d => r[d]), cells: new Map() });
        byRow.get(rk)!.cells.set(JSON.stringify(r[ser]), r);
      }
      const total = data.total_rows ?? rows.length;
      return (
        <Box sx={{ overflow: 'auto', height: '100%' }}>
          {(seriesVals.length > MAX_PIVOT_COLUMNS || total > rows.length) && (
            <Typography variant="caption" color="warning.main" component="div" data-testid="tile-pivot-cut">
              {seriesVals.length > MAX_PIVOT_COLUMNS
                ? `Showing ${MAX_PIVOT_COLUMNS} of ${seriesVals.length} columns. `
                : ''}
              {total > rows.length ? `Showing ${rows.length.toLocaleString()} of ${total.toLocaleString()} combinations -- narrow the report with a parameter to see the rest here, or export it.` : ''}
            </Typography>
          )}
          <Table size="small" stickyHeader aria-label={title}>
            <TableHead>
              <TableRow>
                {tile.dimensions.map(id => <TableCell key={id} sx={{ fontWeight: 700 }}>{cols.get(id)?.label}</TableCell>)}
                {shownSeries.map(sv => tile.measures.map((m, i) => (
                  <TableCell key={`${JSON.stringify(sv)}-${i}`} align="right" sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {formatValue(sv, cols.get(tile.series!))}{tile.measures.length > 1 ? ` · ${measureWords(m, cols, grouped)}` : ''}
                  </TableCell>
                )))}
              </TableRow>
            </TableHead>
            <TableBody>
              {[...byRow.values()].slice((page - 1) * pageSize, page * pageSize).map((row, i) => (
                <TableRow key={i} hover>
                  {row.keys.map((k, j) => <TableCell key={j}>{formatValue(k, cols.get(tile.dimensions[j]))}</TableCell>)}
                  {shownSeries.map(sv => tile.measures.map((m, mi) => {
                    const cell = row.cells.get(JSON.stringify(sv));
                    return (
                      <TableCell key={`${JSON.stringify(sv)}-${mi}`} align="right"
                        sx={heat && cell ? { bgcolor: heatBg(cell[measureAlias(mi)]) } : undefined}>
                        {cell ? formatValue(cell[measureAlias(mi)], cols.get(m.column_id)) : ''}
                      </TableCell>
                    );
                  }))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {/* the rows are PAGED: a pivot of 9,000 rows x 200 columns drawn at
              once froze the browser (the owner's JOIN, 2026-10-26) */}
          <ListPager paging={pagingFor(byRow.size, page, pageSize, Math.min(pageSize, Math.max(0, byRow.size - (page - 1) * pageSize)))}
            onPage={setPage} onPageSize={setPageSize} testid={`tile-pager-${tile.id}`} />
        </Box>
      );
    }
    // charts -- every kind (2026-10-26, the owner: "all type of charts")
    const cat = dimNames[0];
    const catCol = cols.get(tile.dimensions[0]);
    const mCol = cols.get(tile.measures[0]?.column_id);
    const total = data.total_rows ?? rows.length;
    const catLabel = (v: any) => formatValue(v, catCol);
    // room under the chart for its one-line note ("Showing 25 of N ...")
    const chartH = Math.max(80, height - 58);
    const color = (i: number) => CHART_SERIES_COLORS[i % CHART_SERIES_COLORS.length];
    const compact = (v: any) => Number(v).toLocaleString(undefined, { notation: 'compact' });
    const cutNote = total > rows.length
      ? `Showing ${rows.length} of ${total.toLocaleString()} ${catCol?.label ?? 'values'}${tile.sort?.by === 'measure' ? (tile.sort.dir === 'desc' ? ', largest first' : ', smallest first') : ''}.`
      : '';
    const note = (extraWords = '') => (cutNote || extraWords)
      ? <Typography variant="caption" color="text.secondary" data-testid="tile-chart-cut">{cutNote}{extraWords}</Typography>
      : null;
    const tip = <ReTooltip formatter={(v: any) => formatValue(v, mCol)} />;

    // ── one value per category ──
    if (['pie', 'donut', 'treemap', 'funnel'].includes(tile.kind)) {
      const vals = rows.map(r => ({ name: catLabel(r[cat]), value: toNum(r[measureAlias(0)]) ?? 0 }));
      if (tile.kind !== 'funnel' && vals.some(v => v.value < 0)) {
        return <Alert severity="info" sx={{ py: 0 }} data-testid="tile-pie-negative">
          A {tile.kind === 'treemap' ? 'treemap' : 'pie'} cannot show negative values, and some here are below zero. Switch this tile to a bar chart.
        </Alert>;
      }
      const whole = toNum(extra?.whole?.rows?.[0]?.[measureAlias(0)]);
      const shownSum = vals.reduce((a, b) => a + b.value, 0);
      const rest = WHOLE.includes(tile.kind) && whole != null && total > rows.length && whole - shownSum > 0 ? whole - shownSum : 0;
      if (rest) vals.push({ name: 'Everything else', value: rest });
      const fill = (v: { name: string }, i: number) => v.name === 'Everything else' ? CHART_OTHER_COLOR : color(i);
      let chart: React.ReactNode;
      if (tile.kind === 'treemap') {
        chart = (
          <Treemap width={width} height={chartH} data={vals.map((v, i) => ({ ...v, fill: fill(v, i) }))} dataKey="value"
            nameKey="name" isAnimationActive={false} stroke="#fff"
            content={(props: any) => (
              <g>
                <rect x={props.x} y={props.y} width={props.width} height={props.height} fill={props.fill ?? color(props.index ?? 0)} stroke="#fff" />
                {props.width > 50 && props.height > 18 && (
                  <text x={props.x + 4} y={props.y + 14} fontSize={11} fill="#fff">{String(props.name ?? '').slice(0, 24)}</text>
                )}
              </g>
            )}>
            {tip}
          </Treemap>
        );
      } else if (tile.kind === 'funnel') {
        chart = (
          <FunnelChart width={width} height={chartH}>
            {tip}
            <Funnel data={vals.map((v, i) => ({ ...v, fill: color(i) }))} dataKey="value" nameKey="name" isAnimationActive={false}>
              <LabelList position="right" fill="#333" stroke="none" dataKey="name" fontSize={11} />
            </Funnel>
          </FunnelChart>
        );
      } else {
        const r = Math.max(30, Math.min(width, chartH) / 2 - 20);
        chart = (
          <PieChart width={width} height={chartH}>
            <Pie data={vals} dataKey="value" nameKey="name" outerRadius={r} innerRadius={tile.kind === 'donut' ? r * 0.55 : 0}
              isAnimationActive={false}>
              {vals.map((v, i) => <Cell key={i} fill={fill(v, i)} />)}
            </Pie>
            {tip}
            <Legend />
          </PieChart>
        );
      }
      return <Box data-testid="tile-chart" data-kind={tile.kind}>{chart}{note(rest ? ' The rest are one part, "Everything else".' : '')}</Box>;
    }

    // ── points: scatter (x, y) and bubble (x, y, size) ──
    if (tile.kind === 'scatter' || tile.kind === 'bubble') {
      const pts = rows.map(r => ({ name: catLabel(r[cat]), x: toNum(r[measureAlias(0)]), y: toNum(r[measureAlias(1)]),
                                   z: tile.kind === 'bubble' ? toNum(r[measureAlias(2)]) : 1 }))
        .filter(p => p.x != null && p.y != null);
      const words = tile.measures.map(m => measureWords(m, cols, grouped));
      return (
        <Box data-testid="tile-chart" data-kind={tile.kind}>
          <ScatterChart width={width} height={chartH} margin={{ top: 8, right: 12, bottom: 8, left: 8 }}>
            <CartesianGrid stroke="#e1e0d9" />
            <XAxis type="number" dataKey="x" name={words[0]} tick={{ fontSize: 11 }} tickFormatter={compact} />
            <YAxis type="number" dataKey="y" name={words[1]} tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
            {tile.kind === 'bubble' && <ZAxis type="number" dataKey="z" name={words[2]} range={[40, 900]} />}
            <ReTooltip cursor={{ strokeDasharray: '3 3' }}
              formatter={(v: any, n: any) => [formatValue(v, mCol), n]}
              labelFormatter={() => ''} />
            <Scatter data={pts} fill={color(0)} isAnimationActive={false} />
          </ScatterChart>
          {note(` Across: ${words[0]}; up: ${words[1]}${tile.kind === 'bubble' ? `; size: ${words[2]}` : ''}.`)}
        </Box>
      );
    }

    // ── a running total ──
    if (tile.kind === 'waterfall') {
      let run = 0;
      const steps = rows.map(r => {
        const v = toNum(r[measureAlias(0)]) ?? 0;
        const start = run;
        run += v;
        return { __cat: catLabel(r[cat]), base: Math.min(start, run), up: v >= 0 ? v : 0, down: v < 0 ? -v : 0 };
      });
      steps.push({ __cat: 'Total', base: Math.min(0, run), up: run >= 0 ? run : 0, down: run < 0 ? -run : 0 });
      return (
        <Box data-testid="tile-chart" data-kind="waterfall">
          <BarChart width={width} height={chartH} data={steps} margin={{ top: 4, right: 8, bottom: 4, left: 8 }}>
            <CartesianGrid stroke="#e1e0d9" vertical={false} />
            <XAxis dataKey="__cat" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
            <ReTooltip formatter={(v: any, n: any) => (n === 'base' ? null : [formatValue(v, mCol), n === 'up' ? 'Up' : 'Down'])} />
            <Bar dataKey="base" stackId="w" fill="transparent" isAnimationActive={false} />
            <Bar dataKey="up" stackId="w" fill="#1baf7a" isAnimationActive={false} />
            <Bar dataKey="down" stackId="w" fill="#e34948" isAnimationActive={false} />
          </BarChart>
          {note(' Each bar starts where the one before it ended; the last bar is the total.')}
        </Box>
      );
    }

    // ── categories x one or more series ──
    let chartData: any[];
    let seriesKeys: string[];
    let seriesNames: string[];
    let seriesNote = '';
    if (extra?.pairs) {
      const ser = extra.ser;
      const serVals: any[] = (extra.seriesTotals.rows || []).map((r: any) => r[ser]);
      seriesKeys = serVals.map(v => formatValue(v, cols.get(tile.series!)));
      seriesNames = seriesKeys;
      const byCat = new Map<string, any>();
      for (const r of rows) byCat.set(JSON.stringify(r[cat]), { __cat: catLabel(r[cat]) });
      for (const p of extra.pairs.rows || []) {
        const e = byCat.get(JSON.stringify(p[cat]));
        if (e) e[formatValue(p[ser], cols.get(tile.series!))] = toNum(p[measureAlias(0)]);
      }
      chartData = [...byCat.values()];
      const totalSeries = extra.seriesTotals.total_rows ?? serVals.length;
      if (totalSeries > serVals.length) seriesNote = ` ${serVals.length} of ${totalSeries} ${cols.get(tile.series!)?.label ?? 'series'} shown (the largest).`;
    } else {
      seriesKeys = tile.measures.map((_, i) => measureAlias(i));
      seriesNames = tile.measures.map(m => measureWords(m, cols, grouped));
      chartData = rows.map(r => {
        const o: any = { __cat: catLabel(r[cat]) };
        for (const k of seriesKeys) o[k] = toNum(r[k]);
        return o;
      });
    }
    const legend = seriesKeys.length > 1 ? <Legend /> : null;
    // values of very different size (an amount next to a quantity): the small
    // ones go on their own scale on the right, so their line keeps its shape.
    // Only for several VALUES -- series of one value share one scale.
    const peak = (k: string) => Math.max(0, ...chartData.map(d => Math.abs(Number(d[k]) || 0)));
    const top = Math.max(0, ...seriesKeys.map(peak));
    const onRight = new Set<string>(
      tile.kind === 'combo' ? seriesKeys.slice(1)
        : !extra?.pairs && seriesKeys.length > 1 && !['stacked_bar', 'stacked_area'].includes(tile.kind)
          ? seriesKeys.filter(k => top > 0 && peak(k) > 0 && top / peak(k) > 20) : []);
    const margin = { top: 4, right: 8, bottom: 4, left: 8 };
    let chart: React.ReactNode;
    if (tile.kind === 'radar') {
      chart = (
        <RadarChart width={width} height={chartH} data={chartData} outerRadius={Math.max(30, Math.min(width, chartH) / 2 - 30)}>
          <PolarGrid />
          <PolarAngleAxis dataKey="__cat" tick={{ fontSize: 11 }} />
          <PolarRadiusAxis tick={{ fontSize: 10 }} tickFormatter={compact} />
          {tip}{legend}
          {seriesKeys.map((k, i) => <Radar key={k} dataKey={k} name={seriesNames[i]} stroke={color(i)} fill={color(i)} fillOpacity={0.25} isAnimationActive={false} />)}
        </RadarChart>
      );
    } else if (tile.kind === 'hbar') {
      chart = (
        <BarChart width={width} height={chartH} data={chartData} layout="vertical" margin={margin}>
          <CartesianGrid stroke="#e1e0d9" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={compact} />
          <YAxis type="category" dataKey="__cat" tick={{ fontSize: 11 }} width={Math.min(160, Math.max(60, width * 0.25))} />
          {tip}{legend}
          {seriesKeys.map((k, i) => <Bar key={k} dataKey={k} name={seriesNames[i]} fill={color(i)} isAnimationActive={false} />)}
        </BarChart>
      );
    } else {
      const stacked = tile.kind === 'stacked_bar' || tile.kind === 'stacked_area';
      const Chart: any = tile.kind === 'combo' ? ComposedChart
        : tile.kind === 'line' ? LineChart
        : tile.kind === 'area' || tile.kind === 'stacked_area' ? AreaChart : BarChart;
      chart = (
        <Chart width={width} height={chartH} data={chartData} margin={margin}>
          <CartesianGrid stroke="#e1e0d9" vertical={false} />
          <XAxis dataKey="__cat" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
          <YAxis yAxisId="left" tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
          {onRight.size > 0 && <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />}
          {tip}{legend}
          {seriesKeys.map((k, i) => {
            const name = seriesNames[i];
            const axis = onRight.has(k) ? 'right' : 'left';
            const label = onRight.has(k) ? `${name} (right)` : name;
            if (tile.kind === 'line' || (tile.kind === 'combo' && i > 0)) {
              return <Line key={k} yAxisId={axis} type="monotone" dataKey={k} name={label} stroke={color(i)} dot={false} isAnimationActive={false} connectNulls={false} />;
            }
            if (tile.kind === 'area' || tile.kind === 'stacked_area') {
              return <Area key={k} yAxisId={axis} type="monotone" dataKey={k} name={label} stroke={color(i)} fill={color(i)} fillOpacity={0.3}
                stackId={stacked ? 'a' : undefined} isAnimationActive={false} />;
            }
            return <Bar key={k} yAxisId={axis} dataKey={k} name={label} fill={color(i)} stackId={stacked ? 'a' : undefined} isAnimationActive={false} />;
          })}
        </Chart>
      );
    }
    return <Box data-testid="tile-chart" data-kind={tile.kind}>{chart}{note(seriesNote)}</Box>;
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }} data-testid={`tile-${tile.id}`}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
        <Typography variant="subtitle2" noWrap sx={{ flex: 1 }} title={title}>{title}</Typography>
        {loading && data && <CircularProgress size={12} />}
      </Box>
      {run.truncated && run.executionId && (
        <Tooltip title="The report has a row limit; this tile adds up only the rows the run kept.">
          <Typography variant="caption" color="warning.main" data-testid="tile-truncated">
            Based on the first {run.rowLimit ? run.rowLimit.toLocaleString() : ''} rows only.
          </Typography>
        </Tooltip>
      )}
      <Box sx={{ flex: 1, minHeight: 0 }}>{body}</Box>
    </Box>
  );
}
