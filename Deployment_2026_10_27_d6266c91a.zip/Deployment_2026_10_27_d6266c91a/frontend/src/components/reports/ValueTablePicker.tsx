/**
 * "Choices come from: another table" -- the connection, the table and the
 * column whose values a parameter offers (2026-10-24; the owner: "SAP company
 * may come from some other table").
 *
 * Everything is PICKED from what the source has, never typed: the tables the
 * connection lists (GET /api/connections/{id}/tables -- registered tables on
 * S3, the catalog on a SQL source) and that table's columns
 * (GET /api/datasets/connections/{id}/schema/{table}).  A list that could
 * not be read says so.  The server checks the author may see the connection
 * when the report is saved (core: _refuse_unreadable_value_tables).
 */
import { useEffect, useState } from 'react';
import { Autocomplete, Box, TextField, Typography } from '@mui/material';
import api from '../../services/api';
import ConnectionPicker from '../common/ConnectionPicker';

export interface ValueTable {
  connectionId: number | null;
  table: string;
  column: string;
}

/** The table names a connection's table listing answers (schemas dropped). */
export function tableNames(data: any): string[] {
  const rows = Array.isArray(data) ? data : (data?.tables || []);
  return rows.filter((t: any) => !t?._is_schema)
    .map((t: any) => (typeof t === 'string' ? t : (t?.full_name || t?.name || '')))
    .filter(Boolean);
}

/** The column names a table schema answers. */
export function columnNames(data: any): string[] {
  const cols = Array.isArray(data) ? data : (data?.columns || []);
  return cols.map((c: any) => (typeof c === 'string' ? c : (c?.name || c?.column_name || '')))
    .filter(Boolean);
}

export default function ValueTablePicker({ value, onChange, idPrefix }: {
  value: ValueTable; onChange: (v: ValueTable) => void; idPrefix: string;
}) {
  const [tables, setTables] = useState<string[]>([]);
  const [columns, setColumns] = useState<string[]>([]);
  const [problem, setProblem] = useState('');

  useEffect(() => {
    setTables([]);
    if (!value.connectionId) return;
    api.listRegisteredTables(String(value.connectionId))
      .then((d: any) => { setTables(tableNames(d)); setProblem(''); })
      .catch((e: any) => setProblem(`The tables could not be listed: ${e?.message || e}`));
  }, [value.connectionId]);

  useEffect(() => {
    setColumns([]);
    if (!value.connectionId || !value.table) return;
    api.getDatasetTableSchema(value.connectionId, value.table)
      .then((d: any) => { setColumns(columnNames(d)); setProblem(''); })
      .catch((e: any) => setProblem(`The columns of ${value.table} could not be read: ${e?.message || e}`));
  }, [value.connectionId, value.table]);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, maxWidth: 520 }}
         data-testid={`${idPrefix}-value-table`}>
      <ConnectionPicker label="Value table's connection"
        value={value.connectionId ? String(value.connectionId) : ''}
        onChange={id => onChange({ connectionId: id ? Number(id) : null, table: '', column: '' })} />
      <Autocomplete size="small" options={tables} value={value.table || null}
        disabled={!value.connectionId}
        onChange={(_e, t) => onChange({ ...value, table: t || '', column: '' })}
        renderInput={p => <TextField {...p} label="Value table" />} />
      <Autocomplete size="small" options={columns} value={value.column || null}
        disabled={!value.table}
        onChange={(_e, c) => onChange({ ...value, column: c || '' })}
        renderInput={p => <TextField {...p} label="Value column" />} />
      {problem && <Typography variant="caption" color="error" role="alert">{problem}</Typography>}
    </Box>
  );
}
