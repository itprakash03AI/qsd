/**
 * Live authoring preview — real report rows (from the execute endpoint) with
 * the DRAFT grouping/bands, running calculations, conditional-format rules,
 * format patterns and style applied client-side.
 *
 * Banding + running calcs reuse the SAME engine the viewer renders with
 * (`hooks/useReportEngine`), and conditional rules use the client mirror of
 * the export evaluator (`reportAuthoringModel.evaluateRuleStyle`), so what
 * the author sees here is what the viewer / banded export will produce —
 * without saving first.
 */
import React, { useMemo } from 'react';
import {
  Box, Table, TableBody, TableCell, TableHead, TableRow, Typography,
  Alert, Chip, CircularProgress, Divider,
} from '@mui/material';
import useReportEngine, {
  SectionDef as EngineSectionDef,
  RunningCalcDef as EngineRunningCalcDef,
} from '../../hooks/useReportEngine';
import { applyFormatPattern } from '../../utils/formatters';
import {
  AuthoringColumn, AuthoringDraft, evaluateRuleStyle, cutoffsFromRows,
} from './reportAuthoringModel';

export interface FormattingPreviewProps {
  rows: any[];
  columns: string[];              // result column physical names, in order
  datasetColumns: AuthoringColumn[];
  draft: AuthoringDraft;
  loading?: boolean;
  error?: string;
  rowCap?: number;
}

const negativeDisplay = (
  text: string, num: number, mode: 'brackets' | 'minus' | 'red',
): { text: string; red: boolean } => {
  if (num >= 0) return { text, red: false };
  if (mode === 'brackets') return { text: `(${text.replace(/^-/, '')})`, red: true };
  return { text, red: mode === 'red' };
};

const FormattingPreview: React.FC<FormattingPreviewProps> = ({
  rows, columns, datasetColumns, draft,
  loading, error, rowCap,
}) => {
  const colByName = useMemo(() => {
    const m = new Map<string, AuthoringColumn>();
    datasetColumns.forEach(c => m.set(c.physical_name, c));
    return m;
  }, [datasetColumns]);
  const colNameById = useMemo(() => {
    const m = new Map<number, string>();
    datasetColumns.forEach(c => m.set(c.id, c.physical_name));
    return m;
  }, [datasetColumns]);

  // Resolve id-based draft definitions to the name-based engine input.
  const sectionDefs: EngineSectionDef[] = useMemo(() =>
    draft.sections
      .filter(s => colNameById.has(s.break_column_id))
      .map(s => ({
        name: s.name,
        break_column_id: s.break_column_id,
        break_column_name: colNameById.get(s.break_column_id)!,
        subtotal_measure_ids: s.subtotal_measure_ids,
        subtotal_measure_names: s.subtotal_measure_ids
          .map(id => colNameById.get(id))
          .filter((n): n is string => !!n && columns.includes(n)),
        show_count: s.show_count,
      })),
    [draft.sections, colNameById, columns]);

  const runningCalcs: EngineRunningCalcDef[] = useMemo(() =>
    draft.runningCalcs
      .filter(c => c.name.trim() && colNameById.has(c.measure_col_id)
        && columns.includes(colNameById.get(c.measure_col_id)!))
      .map(c => ({
        name: c.name.trim(),
        calc_type: c.calc_type,
        measure_col_name: colNameById.get(c.measure_col_id)!,
        partition_col_name: c.partition_col_id != null
          ? colNameById.get(c.partition_col_id) : undefined,
        format_pattern: c.format_pattern || undefined,
      })),
    [draft.runningCalcs, colNameById, columns]);

  const engine = useReportEngine({
    rows, columns, sectionDefs, runningCalcs,
    slicerValues: {}, drillState: { level: 0, filters: [] },
  });

  const style = draft.style;
  const allCols = [...columns, ...engine.calculatedColumns];

  // Effective format pattern per output column: draft edit → dataset column →
  // running-calc pattern (same precedence the export's col_fmt_map applies).
  const patternFor = (colName: string): string | undefined => {
    const dc = colByName.get(colName);
    if (dc) {
      const edited = draft.columnFormatEdits[dc.id];
      if (edited !== undefined) return edited || undefined;
      return dc.format_pattern || undefined;
    }
    const rc = draft.runningCalcs.find(c => c.name.trim() === colName);
    return rc?.format_pattern || undefined;
  };

  const renderCell = (colName: string, value: any): React.ReactNode => {
    if (value === null || value === undefined) {
      return <span style={{ color: '#aaa' }}>—</span>;
    }
    const dc = colByName.get(colName);
    const pattern = patternFor(colName);
    let text: string;
    const num = typeof value === 'number' ? value : parseFloat(String(value));
    const isNum = !isNaN(num) && String(value).trim() !== '';
    if (pattern) {
      text = applyFormatPattern(value, pattern, dc?.data_type) ?? String(value);
    } else if (isNum && typeof value === 'number') {
      text = value.toLocaleString();
    } else {
      text = String(value);
    }
    if (isNum) {
      const { text: display, red } = negativeDisplay(text, num, style.negative_format);
      return red ? <span style={{ color: '#d32f2f' }}>{display}</span> : display;
    }
    return text;
  };

  if (loading) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <CircularProgress size={28} />
        <Typography variant="body2" sx={{ mt: 1 }}>Running report for preview…</Typography>
      </Box>
    );
  }
  if (error) {
    return <Alert severity="error" data-testid="preview-error" sx={{ m: 1 }}>{error}</Alert>;
  }
  if (!rows.length) {
    return <Alert severity="info" sx={{ m: 1 }}>The report returned no rows to preview.</Alert>;
  }

  const bandedRows = style.show_grand_total
    ? engine.bandedRows
    : engine.bandedRows.filter(r => r._rowType !== 'grand_total');
  // top / bottom N rank the DATA rows (never a subtotal or a total band)
  const cutoffs = cutoffsFromRows(draft.rules,
    engine.bandedRows.filter((r: any) => !r._rowType || r._rowType === 'data'));

  const outerPageBreak = draft.sections.length > 0 && !!draft.sections[0].page_break;
  let seenFirstHeader = false;

  return (
    <Box sx={{ overflow: 'auto', maxHeight: 520 }} data-testid="formatting-preview">
      {rowCap != null && rows.length >= rowCap && (
        <Typography variant="caption" color="text.secondary" sx={{ px: 1 }}>
          Preview limited to the first {rowCap} rows.
        </Typography>
      )}
      <Table size="small" stickyHeader>
        <TableHead>
          <TableRow>
            {allCols.map(col => (
              <TableCell key={col} sx={{
                bgcolor: style.header_bg, color: style.header_text,
                fontWeight: 'bold', whiteSpace: 'nowrap',
              }}>
                {colByName.get(col)?.friendly_name || col}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {bandedRows.map((row, i) => {
            if (row._rowType === 'header') {
              const isOuter = (row._sectionLevel ?? 0) === 0;
              const breakBefore = outerPageBreak && isOuter && seenFirstHeader;
              if (isOuter) seenFirstHeader = true;
              return (
                <React.Fragment key={i}>
                  {breakBefore && (
                    <TableRow data-testid="page-break-marker">
                      <TableCell colSpan={allCols.length} sx={{ p: 0.5, border: 0 }}>
                        <Divider textAlign="center">
                          <Typography variant="caption" color="text.secondary">page break</Typography>
                        </Divider>
                      </TableCell>
                    </TableRow>
                  )}
                  <TableRow>
                    <TableCell colSpan={allCols.length} sx={{
                      bgcolor: style.accent_color, color: '#fff', fontWeight: 'bold',
                      pl: 1 + (row._sectionLevel ?? 0) * 2,
                    }}>
                      {row._sectionValue}
                      {row._sectionCount != null && (
                        <Chip size="small" label={`${row._sectionCount} rows`} sx={{ ml: 1, bgcolor: 'rgba(255,255,255,0.25)', color: '#fff' }} />
                      )}
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              );
            }
            if (row._rowType === 'subtotal') {
              return (
                <TableRow key={i} sx={{ bgcolor: style.subtotal_bg }}>
                  {allCols.map((col, ci) => (
                    <TableCell key={col} sx={{ fontWeight: 'bold', fontStyle: 'italic' }}>
                      {ci === 0
                        ? `Subtotal: ${row._sectionValue ?? ''}${row._count != null ? ` (${row._count})` : ''}`
                        : (row[col] !== undefined ? renderCell(col, row[col]) : '')}
                    </TableCell>
                  ))}
                </TableRow>
              );
            }
            if (row._rowType === 'grand_total') {
              return (
                <TableRow key={i} sx={{ bgcolor: style.grand_total_bg }} data-testid="grand-total-row">
                  {allCols.map((col, ci) => (
                    <TableCell key={col} sx={{ fontWeight: 'bold' }}>
                      {ci === 0 ? 'Grand Total'
                        : (row[col] !== undefined ? renderCell(col, row[col]) : '')}
                    </TableCell>
                  ))}
                </TableRow>
              );
            }
            // data row
            const stripe = style.stripe_rows && i % 2 === 1;
            return (
              <TableRow key={i} sx={stripe ? { bgcolor: 'action.hover' } : undefined}>
                {allCols.map(col => {
                  const ruleStyle = evaluateRuleStyle(row[col], col, draft.rules, cutoffs);
                  return (
                    <TableCell key={col} style={{
                      backgroundColor: ruleStyle.backgroundColor,
                      color: ruleStyle.color,
                      fontWeight: ruleStyle.fontWeight,
                    }}>
                      {renderCell(col, row[col])}
                    </TableCell>
                  );
                })}
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Box>
  );
};

export default FormattingPreview;
