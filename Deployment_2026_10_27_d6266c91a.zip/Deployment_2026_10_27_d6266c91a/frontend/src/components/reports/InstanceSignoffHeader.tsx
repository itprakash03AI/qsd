/**
 * Commentary + sign-off on a report INSTANCE (2026-09-28).
 *
 * The instance header on the finance report viewer: signed / unsigned, who
 * signed and when (per role), "signed version is #id from <time>; this run
 * is newer" with "What changed since signed", Sign and Revoke behind a
 * confirmation, the instance's comment thread, and a "Signed runs" list for
 * the report.
 *
 * Everything shown is the SERVER's answer
 * (`GET /api/business-reports/{id}/instances/header`): which instance this
 * view is, what this caller may do, which sign-offs and comments are visible
 * to their row-security scope.  The client offers only what the server said
 * it would accept (`can_sign`, `can_comment`, `can_revoke`), and a run that
 * was not recorded as an instance says so instead of showing a Sign button.
 *
 * Every control is named; destructive actions confirm and need a reason.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent,
  DialogContentText, DialogTitle, Divider, Drawer, FormControl, IconButton, InputLabel, List, ListItem,
  ListItemText, MenuItem, Paper, Popover, Select, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CommentIcon from '@mui/icons-material/ChatBubbleOutline';
import VerifiedIcon from '@mui/icons-material/Verified';
import PendingIcon from '@mui/icons-material/PendingOutlined';
import HistoryIcon from '@mui/icons-material/History';
import CompareIcon from '@mui/icons-material/CompareArrows';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import api from '../../services/api';
import type {
  InstanceComment, InstanceSignoff, InstanceSignoffHeader as HeaderShape, SignoffRole,
} from '../../services/api/businessReports';
import { useAuth } from '../../context/AuthContext';
import TipIconButton from '../common/TipIconButton';
import ListPager, { clientPage } from '../common/ListPager';
import InstanceDiffDialog from './InstanceDiffDialog';

interface Props {
  reportId: number;
  /** the served instance's id (from the envelope), when served from one */
  instanceId?: number | null;
  /** the live run's execution id — the lanes record the instance under it */
  executionId?: string | null;
  /** 2026-10-26 -- one line (the owner: "taking extra space"): the sign-off is
   *  a chip that opens its details, the comments open in a side panel */
  compact?: boolean;
  /** the parameter values of this view — the last resort key */
  paramValues?: Record<string, any>;
  /** the report's date-typed parameter value, if any: the default business date */
  defaultBusinessDate?: string | null;
  /** bump to re-read after the viewer re-executes */
  refreshKey?: any;
}

const when = (iso: string | null | undefined): string => {
  if (!iso) return 'an unknown time';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? 'an unknown time' : d.toLocaleString();
};

const ROLE_LABEL: Record<SignoffRole, string> = {
  preparer: 'Preparer', reviewer: 'Reviewer', approver: 'Approver',
};

const todayIso = () => new Date().toISOString().slice(0, 10);

export default function InstanceSignoffHeader({
  reportId, instanceId, executionId, paramValues, defaultBusinessDate, refreshKey, compact = false,
}: Props) {
  const [detailsAnchor, setDetailsAnchor] = useState<HTMLElement | null>(null);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const { user } = useAuth();
  const username = user?.username || '';
  const [header, setHeader] = useState<HeaderShape | null>(null);
  const [loadError, setLoadError] = useState('');
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');

  const [signOpen, setSignOpen] = useState(false);
  const [signRole, setSignRole] = useState<SignoffRole>('approver');
  const [signNote, setSignNote] = useState('');
  const [signDate, setSignDate] = useState('');

  const [revokeTarget, setRevokeTarget] = useState<InstanceSignoff | null>(null);
  const [revokeReason, setRevokeReason] = useState('');

  const [commentText, setCommentText] = useState('');
  const [diffOpen, setDiffOpen] = useState(false);
  const [runsOpen, setRunsOpen] = useState(false);
  const [runs, setRuns] = useState<InstanceSignoff[] | null>(null);
  const [runsError, setRunsError] = useState('');
  // Pages (2026-10-13, "pagination in all grids"): signed runs grow with use.
  const [runsPage, setRunsPage] = useState(1);
  const [runsPageSize, setRunsPageSize] = useState(50);

  // Keyed by the parameters' VALUE, not the object's identity: the viewer's
  // paramValues state is a new object on every keystroke, and the params are
  // only the last-resort key anyway (a served instance id or a live run's
  // execution id wins).
  const paramsKey = JSON.stringify(paramValues ?? {});
  const load = useCallback(async () => {
    setLoadError('');
    try {
      const h = await api.getInstanceSignoffHeader(reportId, {
        instanceId: instanceId ?? null, executionId: executionId ?? null,
        params: JSON.parse(paramsKey),
      });
      setHeader(h);
    } catch (e: any) {
      setHeader(null);
      setLoadError(e?.message || 'Could not read the sign-off state');
    }
  }, [reportId, instanceId, executionId, paramsKey]);

  useEffect(() => { load(); }, [load, refreshKey]);

  const inst = header?.instance ?? null;
  const so = header?.signoff;
  const signoffs = so?.signoffs ?? [];
  const signedVersion = so?.signed_version ?? null;
  const rolesLeft = (header?.roles ?? []).filter(r => !signoffs.some(s => s.role === r));

  const openSign = () => {
    setSignRole((rolesLeft[0] ?? 'approver') as SignoffRole);
    setSignNote('');
    setSignDate(defaultBusinessDate || todayIso());
    setActionError('');
    setSignOpen(true);
  };

  const doSign = async () => {
    if (!inst) return;
    setBusy(true); setActionError('');
    try {
      await api.signReportInstance(reportId, inst.id, {
        role: signRole,
        ...(signNote.trim() ? { note: signNote.trim() } : {}),
        ...(signDate ? { business_date: signDate } : {}),
      });
      setSignOpen(false);
      await load();
    } catch (e: any) {
      setActionError(e?.message || 'Sign-off failed');
    } finally { setBusy(false); }
  };

  const doRevoke = async () => {
    if (!inst || !revokeTarget) return;
    setBusy(true); setActionError('');
    try {
      await api.revokeReportInstanceSignoff(reportId, inst.id, revokeTarget.id, revokeReason.trim());
      setRevokeTarget(null); setRevokeReason('');
      await load();
    } catch (e: any) {
      setActionError(e?.message || 'Revoke failed');
    } finally { setBusy(false); }
  };

  const doComment = async () => {
    if (!inst || !commentText.trim()) return;
    setBusy(true); setActionError('');
    try {
      await api.postInstanceComment(reportId, inst.id, {
        text: commentText.trim(),
        ...(defaultBusinessDate ? { business_date: defaultBusinessDate } : {}),
      });
      setCommentText('');
      await load();
    } catch (e: any) {
      setActionError(e?.message || 'Comment failed');
    } finally { setBusy(false); }
  };

  const doDeleteComment = async (c: InstanceComment) => {
    if (!inst) return;
    setBusy(true); setActionError('');
    try {
      await api.deleteInstanceComment(reportId, inst.id, c.id);
      await load();
    } catch (e: any) {
      setActionError(e?.message || 'Delete failed');
    } finally { setBusy(false); }
  };

  const openRuns = async () => {
    setRunsOpen(true); setRuns(null); setRunsError(''); setRunsPage(1);
    try {
      const r = await api.listSignedRuns(reportId, true);
      setRuns(r.signed_runs);
    } catch (e: any) {
      setRunsError(e?.message || 'Could not list the signed runs');
    }
  };

  if (loadError) {
    return <Alert severity="error" data-testid="signoff-header-error" sx={{ mb: 2 }}>{loadError}</Alert>;
  }
  if (!header) return null;
  const shownRuns = clientPage(runs ?? [], runsPage, runsPageSize);

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  const signedChip = so?.status === 'known' && so.signed ? (
    <Chip size="small" color="success" icon={<VerifiedIcon />} label="Signed" data-testid="signoff-chip"
      {...(compact ? { onClick: (ev: React.MouseEvent<HTMLElement>) => setDetailsAnchor(ev.currentTarget), clickable: true } : {})} />
  ) : (
    <Chip size="small" variant="outlined" icon={<PendingIcon />} label="Not signed" data-testid="signoff-chip"
      {...(compact ? { onClick: (ev: React.MouseEvent<HTMLElement>) => setDetailsAnchor(ev.currentTarget), clickable: true } : {})} />
  );
  const instanceWords = inst && (
    <Typography variant="body2" color="text.secondary" data-testid="signoff-instance">
      Instance #{inst.id} · run {when(inst.created_at)}{inst.created_by ? ` by ${inst.created_by}` : ''}
      {header.sees_all_scopes && inst.scope_label !== 'open' ? ` · scope ${inst.scope_label}` : ''}
    </Typography>
  );
  const actions = (
    <>
      {inst && header.can_sign && rolesLeft.length > 0 && (
        <Button size="small" variant="contained" onClick={openSign} disabled={busy}
          data-testid="sign-button">Sign</Button>
      )}
      <Button size="small" startIcon={<HistoryIcon />} onClick={openRuns}>Signed runs</Button>
    </>
  );
  const details = (
    <>

      {so?.status === 'no_instance' && (
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}
          data-testid="signoff-no-instance">
          Nothing to sign: {so.reason}.
        </Typography>
      )}
      {so?.status === 'unknown' && (
        <Alert severity="warning" sx={{ mt: 1 }} data-testid="signoff-unknown">
          Sign-off state could not be read: {so.reason}
        </Alert>
      )}

      {signoffs.length > 0 && (
        <List dense disablePadding sx={{ mt: 1 }} aria-label="Sign-offs on this instance">
          {signoffs.map(s => (
            <ListItem key={s.id} disableGutters
              secondaryAction={s.can_revoke ? (
                <Button size="small" color="error" onClick={() => { setRevokeTarget(s); setRevokeReason(''); setActionError(''); }}
                  aria-label={`Revoke sign-off — ${ROLE_LABEL[s.role]} ${s.signed_by}`}>Revoke</Button>
              ) : undefined}>
              <ListItemText
                primary={`${ROLE_LABEL[s.role]}: ${s.signed_by} signed ${when(s.signed_at)}${s.business_date ? ` for ${s.business_date}` : ''}`}
                secondary={s.note || undefined} />
            </ListItem>
          ))}
        </List>
      )}

      {signedVersion && (
        <Alert severity="info" sx={{ mt: 1 }} data-testid="signed-version-banner"
          action={
            <Button color="inherit" size="small" startIcon={<CompareIcon />} onClick={() => setDiffOpen(true)}
              data-testid="diff-button">What changed since signed</Button>
          }>
          Signed version is #{signedVersion.instance_id} from {when(signedVersion.signed_at)}
          {' '}({ROLE_LABEL[signedVersion.role]} {signedVersion.signed_by})
          {so?.newer_than_signed ? '; this run is newer' : '; this run is a different one'}
          {so?.definition_changed_since_signed ? ' and the report definition has changed since' : ''}.
        </Alert>
      )}

      {actionError && <Alert severity="error" sx={{ mt: 1 }} data-testid="signoff-action-error">{actionError}</Alert>}

    </>
  );
  const commentary = (
    <>
      {inst && (
        <Box sx={{ mt: 1.5 }}>
          <Divider sx={{ mb: 1 }} />
          <Typography variant="subtitle2">Commentary on this instance</Typography>
          {header.comments.length === 0 && (
            <Typography variant="caption" color="text.secondary">No comments on this instance yet.</Typography>
          )}
          <List dense disablePadding aria-label="Instance comments">
            {header.comments.map(c => (
              <ListItem key={c.id} disableGutters sx={{ pl: c.parent_id ? 3 : 0 }}
                secondaryAction={(isAdmin || c.username === username) ? (
                  <TipIconButton tip={`Delete comment — ${c.username}`} size="small" edge="end"
                    onClick={() => doDeleteComment(c)} disabled={busy}>
                    <DeleteIcon fontSize="small" />
                  </TipIconButton>
                ) : undefined}>
                <ListItemText
                  primary={c.text}
                  secondary={`${c.username} · ${when(c.created_at)}`
                    + (c.anchor && c.anchor.kind !== 'instance'
                      ? ` · on ${c.anchor.kind}${c.anchor.column ? ` ${c.anchor.column}` : ''}${c.anchor.key ? ` ${Object.entries(c.anchor.key).map(([k, v]) => `${k}=${v}`).join(', ')}` : ''}`
                      : '')
                    + (header.sees_all_scopes && c.scope_label && c.scope_label !== 'open' ? ` · scope ${c.scope_label}` : '')} />
              </ListItem>
            ))}
          </List>
          {header.can_comment ? (
            <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
              <TextField size="small" fullWidth label="Add a comment" value={commentText}
                onChange={e => setCommentText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doComment(); } }} />
              <Button variant="outlined" size="small" onClick={doComment}
                disabled={busy || !commentText.trim()}>Post</Button>
            </Stack>
          ) : (
            <Tooltip title="Commenting needs an analyst or admin role, ownership, or an explicit grant on this report">
              <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}>
                You can read this thread but not post to it.
              </Typography>
            </Tooltip>
          )}
        </Box>
      )}

    </>
  );
  const dialogs = (
    <>
      {/* Sign dialog */}
      <Dialog open={signOpen} onClose={() => !busy && setSignOpen(false)} aria-labelledby="sign-title">
        <DialogTitle id="sign-title">Sign off this instance</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            You are signing instance #{inst?.id} — the exact rows of this run, its parameters and the
            row-security scope it was computed under. Signing locks the instance: it is kept past retention
            and cannot be expired or deleted while signed. A later run creates a new, unsigned instance.
          </DialogContentText>
          <FormControl fullWidth size="small" sx={{ mb: 2 }}>
            <InputLabel id="sign-role-label">Role</InputLabel>
            <Select labelId="sign-role-label" label="Role" value={signRole}
              onChange={e => setSignRole(e.target.value as SignoffRole)}>
              {(header.roles ?? []).map(r => (
                <MenuItem key={r} value={r} disabled={!rolesLeft.includes(r)}>
                  {ROLE_LABEL[r]}{!rolesLeft.includes(r) ? ' (already signed)' : ''}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField fullWidth size="small" label="Business date" type="date" value={signDate}
            onChange={e => setSignDate(e.target.value)} sx={{ mb: 2 }}
            InputLabelProps={{ shrink: true }} />
          <TextField fullWidth size="small" label="Note (optional)" multiline minRows={2}
            value={signNote} onChange={e => setSignNote(e.target.value)} />
          {actionError && <Alert severity="error" sx={{ mt: 1 }}>{actionError}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSignOpen(false)} disabled={busy}>Cancel</Button>
          <Button variant="contained" onClick={doSign} disabled={busy} data-testid="confirm-sign">
            {busy ? <CircularProgress size={16} /> : 'Confirm sign-off'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Revoke dialog */}
      <Dialog open={Boolean(revokeTarget)} onClose={() => !busy && setRevokeTarget(null)} aria-labelledby="revoke-title">
        <DialogTitle id="revoke-title">Revoke sign-off</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Revoking {revokeTarget ? `${ROLE_LABEL[revokeTarget.role]} ${revokeTarget.signed_by}` : ''}'s sign-off
            on instance #{inst?.id}. The revoke is recorded with your reason; if it was the last sign-off the
            instance returns to ordinary retention.
          </DialogContentText>
          <TextField fullWidth size="small" label="Reason (required)" multiline minRows={2} autoFocus
            value={revokeReason} onChange={e => setRevokeReason(e.target.value)}
            helperText="At least 3 characters" />
          {actionError && <Alert severity="error" sx={{ mt: 1 }}>{actionError}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRevokeTarget(null)} disabled={busy}>Cancel</Button>
          <Button color="error" variant="contained" onClick={doRevoke}
            disabled={busy || revokeReason.trim().length < 3} data-testid="confirm-revoke">
            Revoke
          </Button>
        </DialogActions>
      </Dialog>

      {/* Signed runs */}
      <Dialog open={runsOpen} onClose={() => setRunsOpen(false)} maxWidth="md" fullWidth aria-labelledby="runs-title">
        <DialogTitle id="runs-title">Signed runs of this report</DialogTitle>
        <DialogContent dividers>
          {runsError && <Alert severity="error">{runsError}</Alert>}
          {!runs && !runsError && <CircularProgress size={18} />}
          {runs && runs.length === 0 && (
            <Typography variant="body2" color="text.secondary">No run of this report has been signed off in your scope.</Typography>
          )}
          {runs && runs.length > 0 && (
            <>
            <Table size="small" aria-label="Signed runs">
              <TableHead><TableRow>
                <TableCell>Instance</TableCell><TableCell>Business date</TableCell><TableCell>Role</TableCell>
                <TableCell>Signed by</TableCell><TableCell>Signed at</TableCell><TableCell>Status</TableCell>
                {header.sees_all_scopes && <TableCell>Scope</TableCell>}
              </TableRow></TableHead>
              <TableBody>
                {shownRuns.rows.map(r => (
                  <TableRow key={r.id}>
                    <TableCell>#{r.instance_id}</TableCell>
                    <TableCell>{r.business_date || '—'}</TableCell>
                    <TableCell>{ROLE_LABEL[r.role]}</TableCell>
                    <TableCell>{r.signed_by}</TableCell>
                    <TableCell>{when(r.signed_at)}</TableCell>
                    <TableCell>{r.status === 'revoked'
                      ? `revoked by ${r.revoked_by} ${when(r.revoked_at)}: ${r.revoke_reason}` : 'active'}</TableCell>
                    {header.sees_all_scopes && <TableCell>{r.scope_label}</TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <ListPager paging={shownRuns.paging} onPage={setRunsPage} onPageSize={setRunsPageSize}
                       testid="signed-runs-pager" />
            </>
          )}
        </DialogContent>
        <DialogActions><Button onClick={() => setRunsOpen(false)}>Close</Button></DialogActions>
      </Dialog>

      {inst && (
        <InstanceDiffDialog open={diffOpen} onClose={() => setDiffOpen(false)}
          reportId={reportId} instanceId={inst.id} againstId={signedVersion?.instance_id ?? null} />
      )}
    </>
  );

  if (compact) {
    return (
      <Box data-testid="signoff-header" data-mode="compact" sx={{ display: 'contents' }}>
        {signedChip}
        {instanceWords}
        {inst && (
          <Chip size="small" variant="outlined" icon={<CommentIcon />} clickable
            label={`Comments (${header.comments.length})`} onClick={() => setCommentsOpen(true)}
            data-testid="signoff-comments-chip" />
        )}
        <Popover open={Boolean(detailsAnchor)} anchorEl={detailsAnchor} onClose={() => setDetailsAnchor(null)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }} slotProps={{ paper: { sx: { p: 1.5, maxWidth: 520 } } }}>
          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Sign-off</Typography>
          {instanceWords}
          {details}
          {so?.status === 'known' && !so.signed && signoffs.length === 0 && (
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>Nobody has signed this run yet.</Typography>
          )}
          <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>{actions}</Stack>
        </Popover>
        <Drawer anchor="right" open={commentsOpen} onClose={() => setCommentsOpen(false)}
          slotProps={{ paper: { sx: { width: { xs: '100%', sm: 420 }, p: 2 } } }}>
          <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="h6" sx={{ flex: 1 }}>Comments on this run</Typography>
            <IconButton aria-label="Close comments" onClick={() => setCommentsOpen(false)}><CloseIcon /></IconButton>
          </Stack>
          {instanceWords}
          {commentary}
        </Drawer>
        {dialogs}
      </Box>
    );
  }

  return (
    <Paper variant="outlined" sx={{ p: 1.5, mb: 2 }} data-testid="signoff-header">
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
        {signedChip}
        {instanceWords}
        <Box sx={{ flexGrow: 1 }} />
        {actions}
      </Stack>
      {details}
      {commentary}
      {dialogs}
    </Paper>
  );
}
