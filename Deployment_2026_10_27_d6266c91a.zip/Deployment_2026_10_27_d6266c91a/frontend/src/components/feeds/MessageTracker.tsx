/**
 * Message tracker -- every upstream message of ONE business close date
 * (2026-10-25, the owner: "group by code first ... then datasource ... show
 * all messages with process flow ... 1 message will have all steps like
 * processing --> complete or processing --> failed ... how many times the
 * same message came ... per business close date").
 *
 * ONE answer from GET /api/admin/feeds/message-tracker (core/feed/
 * message_tracker.py): CODE -> DATA_SOURCE -> message.  A message is its
 * identity fields (DATA_SOURCE, CODE, BUSINESS_EVENT, CLOUD_COMPLIANT,
 * SNAP_VERSION -- config), its FLOW is its states in arrival order with a
 * repeat folded and counted, and what is wrong with it is said on the row
 * (COMPLETE twice, a state after the end, one environment silent, a re-sent
 * load, completed after a failure).  The codes that need a look come first;
 * every tile filters.  The page decides nothing -- it shows the server's answer.
 */
import { Fragment, useCallback, useEffect, useState } from 'react';
import { clickable } from '../../utils/clickable';
import {
  Alert, Box, Button, Chip, IconButton, ToggleButton, ToggleButtonGroup, LinearProgress, MenuItem, Paper, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import api from '../../services/api';
import ListPager, { type Paging } from '../common/ListPager';
import { Tile } from './FeedDependencyTracker';

export type MsgStatus = 'failed' | 'stuck' | 'processing' | 'complete' | 'unknown';

export interface FlowStep { state: string; count: number; first_at: string | null; last_at: string | null }
export interface TrackedMessage {
  key: string; status: MsgStatus; final_state: string | null; fields: Record<string, unknown>;
  flow: FlowStep[]; times_seen: number; repeats: number; first_at: string | null; last_at: string | null;
  duration_seconds: number | null; age_minutes: number | null;
  flags: { kind: string; text: string }[]; roads: string[]; dependency_names: string[];
  resolution: string | null; reason: string | null; side?: string | null; side_label?: string | null;
  versions?: number; feeds?: { feed_id: number; feed_name: string; run_status: string | null; action_decision: string | null }[];
  feeds_unreadable?: boolean;
  arrivals: { id: number; at: string | null; state: string | null; road: string; resolution: string;
              reason: string | null; dependency_name: string | null;
              /** this arrival's OWN fields (its version, its row count) */
              fields?: Record<string, unknown>;
              /** what QueryStudio did with it, in plain words (server) */
              what_happened?: string }[];
}
export interface Counts {
  failed: number; stuck: number; processing: number; complete: number; unknown: number;
  messages: number; arrivals: number; repeats: number; flagged: number; flags: Record<string, number>;
  codes?: number; data_sources?: number; unidentified?: number;
}
export interface TrackerAnswer {
  business_date: string; generated_at: string; summary: Counts; paging: Paging; unread: number;
  groups: { code: string; counts: Counts; worst: MsgStatus;
            data_sources: { data_source: string; counts: Counts; worst: MsgStatus; messages: TrackedMessage[] }[] }[];
  config: { state_field: string; group_fields: string[]; stuck_after_minutes: number;
            complete_states: string[]; failed_states: string[] };
}

export const STATUS_FACE: Record<MsgStatus, { hex: string; label: string; color: 'error' | 'warning' | 'info' | 'success' | 'default' }> = {
  failed: { hex: '#c62828', label: 'failed', color: 'error' },
  stuck: { hex: '#ef6c00', label: 'stuck', color: 'warning' },
  processing: { hex: '#1565c0', label: 'processing', color: 'info' },
  complete: { hex: '#2e7d32', label: 'complete', color: 'success' },
  unknown: { hex: '#757575', label: 'no state', color: 'default' },
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
/** "25 Oct 03:26:47" -- a time a person reads (the server sends ISO) */
export function when(iso: string | null | undefined): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}:\d{2}:\d{2})/.exec(iso ?? '');
  return m ? `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[4]}` : (iso ?? '');
}
const fieldOf = (f: Record<string, unknown> | undefined, k: string) => {
  const v = f?.[k] ?? f?.[k.toLowerCase()];
  return v == null ? '' : String(v);
};

export function durationText(s: number | null | undefined): string {
  if (s == null) return '';
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m ${s % 60}s`;
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`;
}

/** PROCESSING ×2 → COMPLETE, each step coloured by what it means */
export function Flow({ flow, complete, failed }: { flow: FlowStep[]; complete: string[]; failed: string[] }) {
  return (
    <Stack direction="row" alignItems="center" spacing={0.25} flexWrap="wrap" useFlexGap data-testid="msg-flow">
      {flow.map((s, i) => (
        <Fragment key={i}>
          {i > 0 && <ArrowRightAltIcon fontSize="small" color="action" />}
          <Tooltip title={s.count > 1 ? `${s.count} times, ${when(s.first_at)} .. ${when(s.last_at)}` : when(s.first_at)}>
            <Chip size="small" data-testid="msg-flow-step"
                  color={complete.includes(s.state) ? 'success' : failed.includes(s.state) ? 'error' : 'info'}
                  variant={complete.includes(s.state) || failed.includes(s.state) ? 'filled' : 'outlined'}
                  label={s.count > 1 ? `${s.state} ×${s.count}` : s.state} />
          </Tooltip>
        </Fragment>
      ))}
    </Stack>
  );
}

function CountChips({ c }: { c: Counts }) {
  return (
    <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
      {(['failed', 'stuck', 'processing', 'complete'] as MsgStatus[]).filter(s => c[s]).map(s => (
        <Chip key={s} size="small" color={STATUS_FACE[s].color} variant="outlined" data-testid={`msg-count-${s}`}
              label={`${c[s]} ${STATUS_FACE[s].label}`} />
      ))}
      {c.flagged > 0 && <Chip size="small" color="warning" label={`${c.flagged} flagged`} />}
    </Stack>
  );
}

/** Every message received for one row: each with ITS version and row count
 *  (they can differ every time), what QueryStudio did with it, and the whole
 *  message when asked for. */
function Arrivals({ m }: { m: TrackedMessage }) {
  const [full, setFull] = useState<Record<number, unknown> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const showFull = async () => {
    if (full) { setFull(null); return; }
    setBusy(true); setErr(null);
    try {
      const r: any = await api.messageTrackerMessages(m.arrivals.map(a => a.id));
      const byId: Record<number, unknown> = {};
      for (const x of r?.messages ?? []) byId[x.id] = x.message ?? x.raw;
      setFull(byId);
    } catch (e: unknown) {
      setErr(`The full messages could not be loaded: ${e instanceof Error ? e.message : String(e)}`);
    } finally { setBusy(false); }
  };
  return (
    <Box>
      <Table size="small" data-testid="msg-arrivals">
        <TableHead><TableRow>
          <TableCell>Received</TableCell><TableCell>State</TableCell><TableCell>Version</TableCell>
          <TableCell align="right">Rows</TableCell><TableCell>Came by</TableCell><TableCell>What QueryStudio did</TableCell>
        </TableRow></TableHead>
        <TableBody>
          {m.arrivals.map(a => (
            <Fragment key={a.id}>
              <TableRow data-testid="msg-arrival">
                <TableCell sx={{ whiteSpace: 'nowrap' }}>{when(a.at)}</TableCell>
                <TableCell>{a.state ?? ''}</TableCell>
                <TableCell data-testid="msg-arrival-version">{fieldOf(a.fields, 'VERSION_NUMBER') || fieldOf(a.fields, 'SNAP_VERSION')}</TableCell>
                <TableCell align="right" data-testid="msg-arrival-rows">{fieldOf(a.fields, 'ROW_COUNT')}</TableCell>
                <TableCell>{a.road === 'table' ? 'QS_KAFKA_MESSAGE table' : 'Kafka'}</TableCell>
                <TableCell data-testid="msg-arrival-what">
                  <Tooltip title={a.reason ? `For support: ${a.resolution} -- ${a.reason}` : a.resolution}>
                    <span>{a.what_happened ?? a.resolution}</span>
                  </Tooltip>
                </TableCell>
              </TableRow>
              {full && (
                <TableRow>
                  <TableCell colSpan={6} sx={{ py: 0.5 }}>
                    <Box component="pre" data-testid="msg-arrival-full"
                         sx={{ m: 0, p: 1, fontSize: 12, bgcolor: 'background.paper', borderRadius: 1,
                               whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 260, overflow: 'auto' }}>
                      {typeof full[a.id] === 'string' ? String(full[a.id]) : JSON.stringify(full[a.id] ?? null, null, 2)}
                    </Box>
                  </TableCell>
                </TableRow>
              )}
            </Fragment>
          ))}
        </TableBody>
      </Table>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 0.5 }}>
        <Button size="small" variant="outlined" onClick={() => void showFull()} disabled={busy} data-testid="msg-show-full">
          {full ? 'Hide the full messages' : 'Show the full messages'}
        </Button>
        {err && <Typography variant="caption" color="error">{err}</Typography>}
      </Stack>
    </Box>
  );
}

function MessageRow({ m, cfg }: { m: TrackedMessage; cfg: { complete: string[]; failed: string[] } }) {
  const [open, setOpen] = useState(false);
  const f = (k: string) => m.fields[k] ?? m.fields[k.toLowerCase()];
  return (
    <>
      <TableRow hover data-testid="msg-row" data-status={m.status} sx={{ '& td': { borderBottom: open ? 0 : undefined } }}>
        <TableCell padding="checkbox">
          <IconButton size="small" aria-label="arrivals" onClick={() => setOpen(o => !o)} data-testid="msg-row-toggle">
            {open ? <KeyboardArrowDownIcon fontSize="small" /> : <KeyboardArrowRightIcon fontSize="small" />}
          </IconButton>
        </TableCell>
        <TableCell>{String(f('BUSINESS_EVENT') ?? '')}</TableCell>
        <TableCell>{m.side_label ?? String(f('CLOUD_COMPLIANT') ?? '')}</TableCell>
        <TableCell>{String(f('SNAP_VERSION') ?? '')}{m.versions && m.versions > 1 ? ` (of ${m.versions})` : ''}</TableCell>
        <TableCell><Flow flow={m.flow} complete={cfg.complete} failed={cfg.failed} /></TableCell>
        <TableCell>
          <Chip size="small" color={STATUS_FACE[m.status].color} label={STATUS_FACE[m.status].label} data-testid="msg-status"
                variant={m.status === 'processing' ? 'outlined' : 'filled'} />
        </TableCell>
        <TableCell align="right" data-testid="msg-times">
          <Tooltip title={m.repeats ? `${m.repeats} message(s) repeated a state already received` : 'each state received once'}>
            <span>{m.times_seen}{m.repeats ? ` (${m.repeats} repeat${m.repeats > 1 ? 's' : ''})` : ''}</span>
          </Tooltip>
        </TableCell>
        <TableCell>{durationText(m.duration_seconds)}</TableCell>
        <TableCell sx={{ whiteSpace: 'nowrap' }}>{when(m.last_at)}</TableCell>
        <TableCell data-testid="msg-flags">
          {m.flags.map((x, i) => <Chip key={i} size="small" color={x.kind === 'recovered' ? 'default' : 'warning'}
                                        sx={{ mr: 0.5, mb: 0.25 }} label={x.text} data-testid={`msg-flag-${x.kind}`} />)}
        </TableCell>
        <TableCell data-testid="msg-feeds">
          {m.feeds_unreadable ? <Typography variant="caption" color="error">feeds could not be read</Typography>
            : (m.feeds || []).map(x => (
              <Chip key={x.feed_id} size="small" variant="outlined" sx={{ mr: 0.5, mb: 0.25 }}
                    color={x.action_decision === 'RUN' ? 'success' : x.run_status ? 'warning' : 'default'}
                    label={`${x.feed_name}: ${x.run_status ? (x.action_decision === 'RUN' ? 'released' : 'held') : 'no run'}`} />
            ))}
          {!m.feeds_unreadable && !(m.feeds || []).length && (
            <Typography variant="caption" color="text.secondary">{m.dependency_names.length ? 'no feed declares it' : '—'}</Typography>
          )}
        </TableCell>
      </TableRow>
      {open && (
        <TableRow>
          <TableCell colSpan={11} sx={{ bgcolor: 'action.hover', py: 1 }}>
            <Arrivals m={m} />
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

type Filter = '' | MsgStatus | 'attention' | 'missing_side' | 'complete_repeated' | 'resent';

export default function MessageTracker({ businessDate, onBusinessDateChange }: {
  businessDate?: string; onBusinessDateChange?: (d: string) => void;
} = {}) {
  const [date, setDate] = useState(businessDate || '');
  // 2026-10-25 (the owner): messages come for a BUSINESS date; by RUN date =
  // the day the upstream created them (their CREATED_AT, else the day they landed)
  const [by, setBy] = useState<'business' | 'run'>('business');
  const [dates, setDates] = useState<{ business_date: string; messages: number }[]>([]);
  const [q, setQ] = useState('');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState<Filter>('');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(25);
  const [data, setData] = useState<TrackerAnswer | null>(null);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { if (businessDate) setDate(businessDate); }, [businessDate]);
  useEffect(() => {
    api.messageTrackerDates(by).then((r: any) => setDates(r?.dates ?? [])).catch(() => setDates([]));
  }, [by]);
  // a search is sent when typing pauses
  useEffect(() => { const t = setTimeout(() => setQuery(q.trim()), 350); return () => clearTimeout(t); }, [q]);
  useEffect(() => { setPage(1); }, [date, query, status, size, by]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await api.messageTracker({ business_date: date || undefined, q: query, status, page, page_size: size, by });
      // an answer missing a part shows what it has, never a blank page
      setData(r && Array.isArray(r.groups) ? (r as TrackerAnswer) : null);
      if (r && !Array.isArray(r.groups)) setError('The tracker answered without its message groups.');
      if (!date && r?.business_date) setDate(r.business_date);
      // what needs a look opens by itself
      const auto: Record<string, boolean> = {};
      for (const g of (r?.groups ?? []) as TrackerAnswer['groups']) {
        if (g.worst === 'failed' || g.worst === 'stuck') auto[g.code] = true;
      }
      setOpen(o => ({ ...auto, ...o }));
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, [date, query, status, page, size, by]);
  useEffect(() => { void load(); }, [load]);

  const s = data?.summary;
  const complete = data?.config?.complete_states ?? ['COMPLETE'];
  const failed = data?.config?.failed_states ?? ['FAILED'];
  const pick = (f: Filter) => setStatus(cur => (cur === f ? '' : f));
  const changeDate = (d: string) => { setDate(d); onBusinessDateChange?.(d); };

  return (
    <Box data-testid="msg-tracker">
      <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1.5 }} flexWrap="wrap" useFlexGap>
        <ToggleButtonGroup size="small" exclusive value={by} data-testid="msg-tracker-by"
                           onChange={(_, v) => { if (v) { setBy(v); setDate(''); } }}>
          <ToggleButton value="business" data-testid="msg-tracker-by-business">Business date</ToggleButton>
          <ToggleButton value="run" data-testid="msg-tracker-by-run">Run date</ToggleButton>
        </ToggleButtonGroup>
        <TextField size="small" type="date" label={by === 'run' ? 'Run date (day the message was created)' : 'Business close date'}
                   value={date} InputLabelProps={{ shrink: true }}
                   onChange={e => changeDate(e.target.value)} inputProps={{ 'data-testid': 'msg-tracker-date' }} />
        {dates.length > 0 && (
          <TextField select size="small" label="Dates with messages" value={dates.some(d => d.business_date === date) ? date : ''}
                     sx={{ minWidth: 200 }} onChange={e => changeDate(e.target.value)} data-testid="msg-tracker-dates">
            {dates.map(d => <MenuItem key={d.business_date} value={d.business_date}>{d.business_date} · {d.messages}</MenuItem>)}
          </TextField>
        )}
        <TextField size="small" label="Search code, source, event, dependency" value={q} sx={{ minWidth: 280 }}
                   onChange={e => setQ(e.target.value)} inputProps={{ 'data-testid': 'msg-tracker-search' }} />
        <Box sx={{ flex: 1 }} />
        <Tooltip title="Refresh">
          <span><IconButton onClick={() => void load()} disabled={loading} aria-label="Refresh"><RefreshIcon /></IconButton></span>
        </Tooltip>
      </Stack>
      {loading && <LinearProgress sx={{ mb: 1 }} />}
      {error && <Alert severity="error" sx={{ mb: 1.5 }} data-testid="msg-tracker-error">{error}</Alert>}
      {data && data.unread > 0 && (
        <Alert severity="info" sx={{ mb: 1.5 }} data-testid="msg-tracker-unread">
          {data.unread.toLocaleString()} older message(s) are still being added to this page. Refresh in a minute.
        </Alert>
      )}
      {data && data.unread < 0 && (
        <Alert severity="warning" sx={{ mb: 1.5 }} data-testid="msg-tracker-unread">
          Some older messages could not be read, so a few may be missing from this page.
        </Alert>
      )}
      {s && (
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1.5 }}>
          <Tile testid="msg-tile-all" label="messages" value={s.messages} hex="#455a64" active={status === ''} onClick={() => setStatus('')}
                hint={`${s.codes ?? 0} code(s), ${s.data_sources ?? 0} data source(s)`} />
          {(['complete', 'processing', 'stuck', 'failed'] as MsgStatus[]).map(k => (
            <Tile key={k} testid={`msg-tile-${k}`} label={STATUS_FACE[k].label} value={s[k]} hex={STATUS_FACE[k].hex}
                  active={status === k} onClick={() => pick(k)}
                  hint={k === 'stuck' ? `no COMPLETE / FAILED ${data?.config?.stuck_after_minutes ?? '?'} min after its last arrival` : undefined} />
          ))}
          <Tile testid="msg-tile-attention" label="need a look" value={s.flagged + s.failed + s.stuck} hex="#ad1457"
                active={status === 'attention'} onClick={() => pick('attention')} hint="failed, stuck, or flagged" />
          <Tile testid="msg-tile-missing_side" label="one side missing" value={s.flags?.missing_side ?? 0} hex="#6a1b9a"
                active={status === 'missing_side'} onClick={() => pick('missing_side')} />
          <Tile testid="msg-tile-repeated" label="COMPLETE twice" value={s.flags?.complete_repeated ?? 0} hex="#f9a825"
                active={status === 'complete_repeated'} onClick={() => pick('complete_repeated')} />
          <Tile testid="msg-tile-arrivals" label="messages received" value={s.arrivals} hex="#546e7a"
                hint={`${s.repeats} of them repeated a state already received`} />
        </Stack>
      )}
      {data && data.groups.length === 0 && !loading && (
        <Typography color="text.secondary" sx={{ p: 2 }} data-testid="msg-tracker-empty">
          {s?.messages ? 'Nothing matches this filter.'
            : by === 'run' ? `No upstream message was created on ${data.business_date}.`
              : `No upstream message is for business date ${data.business_date}.`}
        </Typography>
      )}
      {data?.groups.map(g => (
        <Paper key={g.code} variant="outlined" sx={{ mb: 1, borderLeft: 4, borderLeftColor: STATUS_FACE[g.worst].hex }}
               data-testid="msg-code">
          <Stack direction="row" alignItems="center" spacing={1} sx={{ px: 1, py: 0.75, cursor: 'pointer' }}
                 {...clickable(() => setOpen(o => ({ ...o, [g.code]: !o[g.code] })),
                               { label: `Code ${g.code || '(no code)'}`, expanded: !!open[g.code] })}
                 data-testid="msg-code-head">
            {open[g.code] ? <KeyboardArrowDownIcon fontSize="small" /> : <KeyboardArrowRightIcon fontSize="small" />}
            <Typography sx={{ fontWeight: 700, minWidth: 120 }} data-testid="msg-code-name">{g.code || '(no code)'}</Typography>
            <Typography variant="caption" color="text.secondary" sx={{ minWidth: 170 }}>
              {g.data_sources.length} data source(s) · {g.counts.messages} message(s) · {g.counts.arrivals} arrival(s)
            </Typography>
            <CountChips c={g.counts} />
          </Stack>
          {open[g.code] && g.data_sources.map(d => (
            <Box key={d.data_source} sx={{ px: 1, pb: 1 }} data-testid="msg-ds">
              <Stack direction="row" spacing={1} alignItems="center" sx={{ pl: 3, py: 0.5 }}>
                <Typography variant="subtitle2" data-testid="msg-ds-name">{d.data_source || '(no data source)'}</Typography>
                <CountChips c={d.counts} />
              </Stack>
              <Table size="small">
                <TableHead><TableRow>
                  <TableCell padding="checkbox" /><TableCell>Event</TableCell><TableCell>Environment</TableCell>
                  <TableCell>Snapshot</TableCell><TableCell>Flow</TableCell><TableCell>Status</TableCell>
                  <TableCell align="right">Messages received</TableCell><TableCell>Time to finish</TableCell>
                  <TableCell>Last received</TableCell><TableCell>Needs a look</TableCell><TableCell>Feeds</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {d.messages.map(m => <MessageRow key={m.key} m={m} cfg={{ complete, failed }} />)}
                </TableBody>
              </Table>
            </Box>
          ))}
        </Paper>
      ))}
      <ListPager paging={data?.paging} onPage={setPage} onPageSize={setSize} testid="msg-tracker-pager" />
    </Box>
  );
}
