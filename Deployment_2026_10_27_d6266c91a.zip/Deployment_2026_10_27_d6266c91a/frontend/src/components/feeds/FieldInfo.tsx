/**
 * The feed form's "i" (2026-10-24, the owner's redesign: "every field has an
 * i with what it does, its actual default and an example").  An end
 * adornment, so a Select or a TextField keeps its structure.
 */
import { IconButton, InputAdornment, Tooltip, Typography } from '@mui/material';
import { InfoOutlined as InfoIcon } from '@mui/icons-material';

export interface FieldInfoText {
  /** what the field does, in one sentence */
  what: string;
  /** the value used when it is left alone -- the deployment's real one */
  def?: string;
  example?: string;
}

export function FieldInfo({ id, label, info }: { id: string; label: string; info: FieldInfoText }) {
  return (
    <Tooltip arrow placement="top" title={
      <div data-testid={`field-info-text-${id}`}>
        <Typography variant="caption" component="div">{info.what}</Typography>
        {info.def && <Typography variant="caption" component="div"><b>Default:</b> {info.def}</Typography>}
        {info.example && <Typography variant="caption" component="div"><b>Example:</b> {info.example}</Typography>}
      </div>}>
      {/* named by its id, not the field's label: a label lookup of the field must find the field */}
      <IconButton size="small" aria-label={`Field help (${id})`} data-testid={`field-info-${id}`}
                  onMouseDown={e => e.stopPropagation()} onClick={e => e.stopPropagation()} sx={{ p: 0.25 }}>
        <InfoIcon sx={{ fontSize: 16 }} />
      </IconButton>
    </Tooltip>
  );
}

/** The adornment form: ``<Select endAdornment={infoAdornment(...)} />`` (a
 *  Select's own arrow sits at the far right, so the icon keeps clear of it). */
export function infoAdornment(id: string, label: string, info: FieldInfoText, select = false) {
  return (
    <InputAdornment position="end" sx={select ? { mr: 2.5 } : undefined}>
      <FieldInfo id={id} label={label} info={info} />
    </InputAdornment>
  );
}
