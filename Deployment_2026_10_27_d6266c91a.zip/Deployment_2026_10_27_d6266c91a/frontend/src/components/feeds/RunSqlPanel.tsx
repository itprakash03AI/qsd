/**
 * "SQL as executed" on an opened feed run (2026-10-24, the owner: "feed run
 * status page does not show what has been executed by resolving parameters
 * -- should show").  Each side's statement with every parameter and {TOKEN}
 * resolved, and the values it was resolved from -- as the run's own render
 * chokepoint RECORDED it (GET /api/feed-runs/{id}/sql); nothing is rendered
 * here.  Read when opened.
 */
import { useState } from 'react';
import { Alert, Box, Button, Chip, CircularProgress, IconButton, Paper, Stack, Tooltip, Typography } from '@mui/material';
import { Code as CodeIcon, ContentCopy as CopyIcon } from '@mui/icons-material';
import api from '../../services/api';
import type { FeedRunSqlResponse } from '../../services/api/feedDependencies';
import { envLabel } from './environments';

const sideWords = (side: string) => (side ? envLabel(side) : 'Query');

const norm = (k: string) => k.toUpperCase().replace(/_/g, '');
/** OG spellings that name the same resolved value (core/feed/sql_tokens.py). */
const ALIAS: Record<string, string> = { COB: 'BUSINESSDATE' };

/** The template the run was written as (a raw-SQL feed records it as the
 *  ``sql`` value), and the values split into those the template USES and the
 *  rest.  Pure. */
export function splitValues(params: Record<string, unknown>) {
  const template = typeof params.sql === 'string' && /[{]/.test(params.sql) ? params.sql : null;
  const entries = Object.entries(params).filter(([k]) => k !== 'sql');
  const names = new Set<string>();
  for (const m of (template || '').matchAll(/\{\{?\s*([A-Za-z_]\w*)/g)) {
    const n = norm(m[1]);
    names.add(ALIAS[n] || n);
  }
  const used = entries.filter(([k]) => names.has(norm(k)));
  const rest = entries.filter(([k]) => !names.has(norm(k)));
  return { template, used, rest };
}

const chip = ([k, v]: [string, unknown]) => (
  <Chip key={k} size="small" label={`${k} = ${v === null ? 'null' : String(v)}`}
        sx={{ fontFamily: 'monospace', fontSize: 11 }} />
);
const preSx = { m: 0, p: 1, borderRadius: 1, bgcolor: 'action.hover', fontSize: 12, fontFamily: 'monospace',
                whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 320, overflow: 'auto' } as const;

export default function RunSqlPanel({ runId }: { runId: number }) {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<FeedRunSqlResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [allVals, setAllVals] = useState<Record<number, boolean>>({});

  const toggle = () => {
    const next = !open;
    setOpen(next);
    if (next) {
      setLoading(true); setError(null);
      (api as any).getFeedRunSql(runId)
        .then((r: FeedRunSqlResponse) => setData(r))
        .catch((e: any) => setError(`The SQL of this run could not be read: ${e?.message || e}`))
        .finally(() => setLoading(false));
    }
  };

  return (
    <Box sx={{ mt: 1 }}>
      <Button size="small" variant={open ? 'contained' : 'outlined'} startIcon={<CodeIcon />}
              onClick={toggle} data-testid="board-run-sql-toggle">
        Query of this run
      </Button>
      {open && (
        <Paper variant="outlined" sx={{ mt: 1, p: 1.25 }} data-testid="board-run-sql">
          {loading && <CircularProgress size={16} />}
          {error && <Alert severity="error">{error}</Alert>}
          {data?.unavailable && <Alert severity="warning">{data.unavailable}</Alert>}
          {data && !data.unavailable && data.statements.length === 0 && (
            <Typography variant="body2" color="text.secondary" data-testid="board-run-sql-none" sx={{ mb: 1 }}>
              {data.note || 'No query was kept for this run.'}
            </Typography>
          )}
          {data && data.statements.length === 0 && (data.planned || []).map((pl, i) => {
            const { used, rest } = splitValues({ ...(pl.params || {}), ...(pl.template ? { sql: pl.template } : {}) });
            return (
              <Box key={i} data-testid="board-run-sql-planned" data-side={pl.side} sx={{ mb: 1.25 }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
                  <Typography variant="body2" sx={{ fontWeight: 700 }}>{sideWords(pl.side)}</Typography>
                  <Chip size="small" color="warning" variant="outlined" label="not sent yet" />
                  <Box sx={{ flexGrow: 1 }} />
                  {pl.sql && (
                    <Tooltip title="Copy this SQL">
                      <IconButton size="small" aria-label="Copy this SQL"
                                  onClick={() => navigator.clipboard?.writeText(pl.sql || '')}>
                        <CopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                </Stack>
                {pl.error && <Alert severity="warning" sx={{ mb: 0.5 }} data-testid="board-run-sql-planned-error">{pl.error}</Alert>}
                {(used.length > 0 ? used : rest).length > 0 && (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 0.5 }}>
                    <Typography variant="caption" color="text.secondary" sx={{ mr: 0.5, alignSelf: 'center' }}>
                      Values it will use:
                    </Typography>
                    {(used.length > 0 ? used : rest).map(chip)}
                  </Box>
                )}
                {pl.sql && (
                  <Box component="pre" data-testid="board-run-sql-planned-text" sx={preSx}>{pl.sql}</Box>
                )}
              </Box>
            );
          })}
          <Stack spacing={1.25}>
            {(data?.statements || []).map(st => {
              const { template, used, rest } = splitValues(st.params || {});
              const shownVals = template ? used : rest;
              return (
                <Box key={st.id} data-testid="board-run-sql-statement" data-side={st.side}>
                  <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
                    <Typography variant="body2" sx={{ fontWeight: 700 }}>{sideWords(st.side)}</Typography>
                    <Chip size="small" variant="outlined" label={st.lane === 'spark' ? 'sent to Spark' : 'run by QueryStudio'} />
                    {st.rendered_at && (
                      <Typography variant="caption" color="text.secondary">
                        sent {String(st.rendered_at).replace('T', ' ').slice(0, 16)} UTC
                      </Typography>
                    )}
                    <Box sx={{ flexGrow: 1 }} />
                    <Tooltip title="Copy this SQL">
                      <IconButton size="small" aria-label="Copy this SQL"
                                  onClick={() => navigator.clipboard?.writeText(st.sql)}>
                        <CopyIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                  {template && (
                    <>
                      <Typography variant="caption" color="text.secondary">The feed's query, as written</Typography>
                      <Box component="pre" data-testid="board-run-sql-template" sx={{ ...preSx, mb: 0.75, opacity: 0.85 }}>
                        {template}
                      </Box>
                    </>
                  )}
                  {shownVals.length > 0 && (
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 0.5 }} data-testid="board-run-sql-values">
                      <Typography variant="caption" color="text.secondary" sx={{ mr: 0.5, alignSelf: 'center' }}>
                        {template ? 'Values put in:' : 'Values available:'}
                      </Typography>
                      {shownVals.map(chip)}
                    </Box>
                  )}
                  {template && rest.length > 0 && (
                    <Box sx={{ mb: 0.5 }}>
                      <Button size="small" onClick={() => setAllVals(a => ({ ...a, [st.id]: !a[st.id] }))}
                              data-testid="board-run-sql-all-values">
                        {allVals[st.id] ? 'Hide' : 'Show'} all {rest.length} other values
                      </Button>
                      {allVals[st.id] && (
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>{rest.map(chip)}</Box>
                      )}
                    </Box>
                  )}
                  {template && <Typography variant="caption" color="text.secondary">What was sent (values filled in)</Typography>}
                  <Box component="pre" data-testid="board-run-sql-text" sx={preSx}>
                    {st.sql}
                  </Box>
                </Box>
              );
            })}
          </Stack>
          {data && data.history.length > data.statements.length && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
              Showing the latest attempt. This run was tried {data.history.length} times.
            </Typography>
          )}
        </Paper>
      )}
    </Box>
  );
}
