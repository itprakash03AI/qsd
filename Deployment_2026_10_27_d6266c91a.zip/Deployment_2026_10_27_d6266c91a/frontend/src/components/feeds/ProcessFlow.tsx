/**
 * A feed run as a PROCESS FLOW (2026-10-12, the owner: "process flow chart",
 * "what's the sequence -- think deeply").
 *
 *   ProcessFlow   the opened run: one node per step, joined left to right in
 *                 the order the steps REALLY happened (their start times --
 *                 the recorded ``seq`` put "File sent" before "File verified",
 *                 which ran first), preceded by "Upstream data ready" from the
 *                 run's dependencies.  Node colour = state; under it the step
 *                 in plain words and how long / how many rows.  Hover: every
 *                 detail.  Click: the step's panel (why it failed, Re-run
 *                 where the server allows).  "Show all step details" lists
 *                 every step with its sentence.
 *   MiniFlow      a run row: the same chain as small connected dots.
 *
 * Words: utils/feedStepWords.ts.  Every state and number is the server's.
 */
import React, { useMemo, useState } from 'react';
import { alpha } from '@mui/material/styles';
import { Box, Button, Chip, Paper, Stack, Tooltip, Typography } from '@mui/material';
import {
  Check as DoneIcon, Close as FailIcon, Autorenew as RunIcon, Remove as SkipIcon,
  MoreHoriz as WaitIcon, Replay as RerunIcon, Hub as DepsIcon, PlayArrow as StartIcon,
  Storage as FetchIcon, FactCheck as CountsIcon, CallMerge as MergeIcon, Description as FileIcon,
  VerifiedUser as VerifyIcon, Rule as CompareIcon, Send as SendIcon, TableChart as LoadIcon,
  TaskAlt as ConfirmIcon, Receipt as ReceiptIcon, Settings as StepIcon, PriorityHigh as WarnBadge,
  CloudDownload as UpstreamIcon,
} from '@mui/icons-material';
import { stepWords, stepKind, STEP_STATE_WORDS, plainDuration, type StepKind } from '../../utils/feedStepWords';

/** The icon of WHAT a step does (the colour and the corner badge say its state). */
export const KIND_ICON: Record<StepKind, any> = {
  start: StartIcon, upstream: UpstreamIcon, fetch: FetchIcon, counts: CountsIcon, merge: MergeIcon,
  file: FileIcon, verify: VerifyIcon, compare: CompareIcon, send: SendIcon, load: LoadIcon,
  confirm: ConfirmIcon, receipt: ReceiptIcon, step: StepIcon,
};
import { envLabel, envSide } from './environments';

export const STATE_HEX: Record<string, string> = {
  completed: '#2e7d32', failed: '#c62828', refused: '#c62828', running: '#1565c0',
  skipped: '#90a4ae', cancelled: '#90a4ae', not_started: '#b0bec5', pending: '#b0bec5', waiting: '#ed6c02',
  warning: '#ed6c02',
};

export interface FlowStep {
  name: string; alias?: string; state?: string; seq?: number;
  started_at?: string | null; ended_at?: string | null; seconds?: number | null;
  rows_out?: number | null; detail?: string | null;
}
export interface FlowDep {
  name: string; side?: string | null; satisfies: boolean; verdict?: string;
  action?: string | null; reason?: string | null;
}

/** One dependency's face in the "Upstream data ready" panel (2026-10-24, the
 *  owner: "if I click on upstream data ready it should show all dependencies
 *  arrived or what's pending, in red and green").  Words for the GATE's
 *  verdict (core/feed/dependency_gate.py): met = arrived (green), not_met =
 *  pending (red); could_not_tell is NOT pending (unknown != empty) and an
 *  operator's SKIP is not an arrival -- both amber; not_expected grey. */
export function depFace(d: FlowDep): { word: string; hex: string; tone: 'arrived' | 'pending' | 'unknown' | 'skipped' | 'not_expected' } {
  if (String(d.action || '').toUpperCase() === 'SKIP') return { word: 'Skipped by an operator', hex: STATE_HEX.warning, tone: 'skipped' };
  switch (d.verdict) {
    case 'met': return { word: 'Arrived', hex: STATE_HEX.completed, tone: 'arrived' };
    case 'not_expected': return { word: 'Not expected for this date', hex: STATE_HEX.skipped, tone: 'not_expected' };
    case 'could_not_tell': return { word: "Can't check", hex: STATE_HEX.warning, tone: 'unknown' };
    case 'not_met': return { word: 'Pending', hex: STATE_HEX.failed, tone: 'pending' };
    default:
      return d.satisfies ? { word: 'Arrived', hex: STATE_HEX.completed, tone: 'arrived' }
                         : { word: 'Pending', hex: STATE_HEX.failed, tone: 'pending' };
  }
}

/** Every dependency, arrived in green, pending in red -- the gate's own words. */
export function DepsPanel({ deps, side }: { deps: FlowDep[]; side?: 'primary' | 'secondary' }) {
  const shown = side ? deps.filter(d => envSide(d.side) === side) : deps;
  const faces = shown.map(d => ({ d, f: depFace(d) }));
  const arrived = faces.filter(x => x.f.tone === 'arrived' || x.f.tone === 'not_expected').length;
  const pending = faces.filter(x => x.f.tone === 'pending').length;
  const other = faces.length - arrived - pending;
  return (
    <Paper variant="outlined" data-testid="board-deps-panel"
           sx={{ mt: 1, p: 1.25, borderLeft: 4,
                 borderLeftColor: pending ? STATE_HEX.failed : other ? STATE_HEX.warning : STATE_HEX.completed }}>
      <Typography variant="body2" sx={{ fontWeight: 700 }} data-testid="board-deps-summary">
        Upstream data{side ? ` — ${SIDE_OF[side].label}` : ''} — {arrived} of {faces.length} arrived
        {pending ? `, ${pending} pending` : ''}{other ? `, ${other} to check` : ''}
      </Typography>
      {faces.length === 0 && (
        <Typography variant="caption" color="text.secondary">This feed waits for no upstream load.</Typography>
      )}
      <Stack spacing={0.5} sx={{ mt: 0.75 }}>
        {faces.map(({ d, f }) => (
          <Stack key={`${d.side || ''}:${d.name}`} direction="row" spacing={1} alignItems="flex-start"
                 data-testid="board-dep-row" data-tone={f.tone}
                 sx={{ px: 1, py: 0.5, borderRadius: 1, borderLeft: 4, borderColor: f.hex,
                       bgcolor: (t) => alpha(f.hex, t.palette.mode === 'dark' ? 0.18 : 0.08) }}>
            <Box sx={{ mt: '2px' }}>
              {f.tone === 'arrived' ? <DoneIcon sx={{ fontSize: 18, color: f.hex }} />
                : f.tone === 'pending' ? <FailIcon sx={{ fontSize: 18, color: f.hex }} />
                : <WaitIcon sx={{ fontSize: 18, color: f.hex }} />}
            </Box>
            <Box sx={{ minWidth: 0, flexGrow: 1 }}>
              <Typography variant="body2" sx={{ fontWeight: 600, wordBreak: 'break-word' }}>
                {d.name}{d.side ? <Typography component="span" variant="caption" color="text.secondary"> · {envLabel(d.side)}</Typography> : null}
              </Typography>
              {d.reason && <Typography variant="caption" color="text.secondary" component="div">{d.reason}</Typography>}
            </Box>
            <Chip size="small" label={f.word} data-testid="board-dep-word"
                  sx={{ bgcolor: f.hex, color: '#fff', fontWeight: 700 }} />
          </Stack>
        ))}
      </Stack>
    </Paper>
  );
}

const ts = (iso?: string | null) => {
  if (!iso) return NaN;
  const s = String(iso);
  return Date.parse(/Z$|[+-]\d\d:\d\d$/.test(s) ? s : `${s}Z`);
};
const hms = (iso?: string | null) => (iso ? String(iso).replace('T', ' ').slice(11, 19) : '');

/** The steps in the order they HAPPENED: started ones by start time, then
 *  the rest in their declared order.  Pure. */
export function flowOrder<T extends FlowStep>(steps: T[]): T[] {
  return steps.map((s, i) => ({ s, i, t: ts(s.started_at) }))
    .sort((a, b) => {
      const fa = Number.isFinite(a.t), fb = Number.isFinite(b.t);
      if (fa && fb && a.t !== b.t) return a.t - b.t;
      if (fa !== fb) return fa ? -1 : 1;
      return (a.s.seq ?? a.i) - (b.s.seq ?? b.i);
    })
    .map(x => x.s);
}

/** "started 13:02:38, finished 13:02:51" / "not started yet" */
export function whenWords(s: FlowStep): string {
  if (!s.started_at) return 'not started yet';
  return `started ${hms(s.started_at)}, ${s.ended_at ? `finished ${hms(s.ended_at)}`
    : s.state === 'running' ? 'still running' : 'end not recorded'}`;
}
/** "13 s · 7 rows" under a node. */
export function nodeCaption(s: FlowStep): string {
  const d = plainDuration(s.seconds);
  return [d === 'under a second' ? '< 1 s' : d, s.rows_out != null ? `${Number(s.rows_out).toLocaleString()} rows` : null]
    .filter(Boolean).join(' · ');
}

function NodeIcon({ state }: { state: string }) {
  const sx = { fontSize: 16, color: '#fff' };
  if (state === 'completed') return <DoneIcon sx={sx} />;
  if (state === 'failed' || state === 'refused') return <FailIcon sx={sx} />;
  if (state === 'running') {
    return <RunIcon sx={{ ...sx, animation: 'qsSpin 1.2s linear infinite',
                          '@keyframes qsSpin': { to: { transform: 'rotate(360deg)' } } }} />;
  }
  if (state === 'skipped' || state === 'cancelled') return <SkipIcon sx={sx} />;
  if (state === 'waiting') return <WaitIcon sx={sx} />;
  return <WaitIcon sx={{ ...sx, color: 'rgba(255,255,255,.9)' }} />;
}

/** The corner badge that says the state (done / failed / skipped / waiting /
 *  not checked); running is the turning ring; not started has none. */
function StateBadge({ state }: { state: string }) {
  const hex = STATE_HEX[state] || STATE_HEX.pending;
  const I = state === 'completed' ? DoneIcon : (state === 'failed' || state === 'refused') ? FailIcon
    : (state === 'skipped' || state === 'cancelled') ? SkipIcon : state === 'warning' ? WarnBadge
    : state === 'waiting' ? WaitIcon : null;
  if (!I) return null;
  return (
    <Box data-testid="board-step-state-badge" data-state={state}
         sx={{ position: 'absolute', right: -4, bottom: -4, width: 13, height: 13, borderRadius: '50%',
               bgcolor: hex, border: '1.5px solid', borderColor: 'background.paper', display: 'grid',
               placeItems: 'center', '& svg': { fontSize: '9px !important', color: '#fff' } }}>
      <I />
    </Box>
  );
}

function Node({ label, caption, state, tip, selected, onClick, icon, kind, testid, width = 128 }: {
  label: string; caption?: string; state: string; tip: React.ReactNode; selected?: boolean;
  onClick?: () => void; icon?: React.ReactNode; kind?: StepKind; testid: string; width?: number;
}) {
  const KindIcon = kind ? KIND_ICON[kind] : null;
  // a BOX per step: status colour on the left edge and in the badge, the step
  // in words, its numbers underneath (2026-10-12, the owner: "nicer boxes")
  const hex = STATE_HEX[state] || STATE_HEX.pending;
  return (
    <Tooltip title={tip} arrow placement="top">
      <Box role="button" tabIndex={0} aria-label={`${label}: ${STEP_STATE_WORDS[state] || state}`}
           data-testid={testid} data-state={state} onClick={onClick}
           onKeyDown={e => { if (e.key === 'Enter') onClick?.(); }}
           sx={{ width, flexShrink: 0, display: 'flex', alignItems: 'center', gap: 0.75, px: 0.75, py: 0.6,
                 minHeight: 46, borderRadius: 1.5, border: 1, borderLeft: 4, borderColor: alpha(hex, 0.45),
                 borderLeftColor: hex, cursor: onClick ? 'pointer' : 'default',
                 bgcolor: (t) => alpha(hex, selected ? (t.palette.mode === 'dark' ? 0.28 : 0.14)
                                                     : (t.palette.mode === 'dark' ? 0.12 : 0.05)),
                 boxShadow: selected ? `0 0 0 2px ${alpha(hex, 0.45)}` : '0 1px 2px rgba(0,0,0,.06)',
                 transition: 'box-shadow .15s', '&:hover': { boxShadow: `0 2px 6px ${alpha(hex, 0.35)}` } }}>
        <Box sx={{ position: 'relative', width: 22, height: 22, flexShrink: 0 }}>
          {state === 'running' && (
            // IN PROGRESS: a ring that turns around the badge
            <Box sx={{ position: 'absolute', inset: -3, borderRadius: '50%', border: `2px solid ${alpha(hex, 0.25)}`,
                       borderTopColor: hex, animation: 'qsSpin 1s linear infinite',
                       '@keyframes qsSpin': { to: { transform: 'rotate(360deg)' } } }} />
          )}
          <Box data-testid="board-step-icon" data-kind={kind || undefined}
               sx={{ width: 22, height: 22, borderRadius: '50%', bgcolor: hex, display: 'grid', placeItems: 'center',
                     '& svg': { fontSize: '14px !important', color: '#fff' } }}>
            {icon || (KindIcon ? <KindIcon /> : <NodeIcon state={state} />)}
          </Box>
          {KindIcon && !icon && <StateBadge state={state} />}
        </Box>
        <Box sx={{ minWidth: 0 }}>
          <Typography sx={{ fontSize: 12, fontWeight: 700, lineHeight: 1.2 }}>{label}</Typography>
          {caption && (
            <Typography sx={{ fontSize: 11, lineHeight: 1.2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                              color: state === 'failed' ? 'error.main' : state === 'warning' ? 'warning.main' : 'text.secondary' }}>
              {caption}
            </Typography>
          )}
        </Box>
      </Box>
    </Tooltip>
  );
}

/** The state an ARROW shows: the state of the step it LEADS INTO (2026-10-12,
 *  the owner: "arrow also coloured based on status ... everything
 *  sequential") -- green into a done step, blue and flowing into a running
 *  one, red into a failure, amber into a warning / waiting step, grey into
 *  one not reached.  An arrow from a step that did not complete is never
 *  green.  Pure. */
export function arrowState(from: string | null | undefined, into: string | null | undefined): string {
  const f = String(from || 'completed'), i = String(into || 'pending');
  if (f !== 'completed' && f !== 'skipped' && f !== 'warning') return 'pending';
  if (i === 'not_started' || i === 'pending' || i === 'cancelled') return 'pending';
  if (i === 'refused') return 'failed';
  return i;
}

function Link({ state, minWidth = 18 }: { state: string; minWidth?: number }) {
  // an ARROW in the colour of where it leads; flowing while that step runs
  const hex = STATE_HEX[state];
  const c = (t: any) => (state === 'pending' || !hex ? alpha(t.palette.text.primary, 0.25) : hex);
  const running = state === 'running';
  return (
    <Box data-testid="board-flow-arrow" data-state={state}
         sx={{ flex: `1 0 ${minWidth}px`, minWidth, display: 'flex', alignItems: 'center', alignSelf: 'center' }}>
      <Box sx={{ flex: 1, height: 2, bgcolor: running ? 'transparent' : c,
                 ...(running ? {
                   backgroundImage: `repeating-linear-gradient(90deg, ${hex} 0 6px, transparent 6px 10px)`,
                   backgroundSize: '20px 2px', animation: 'qsFlow .8s linear infinite',
                   '@keyframes qsFlow': { from: { backgroundPosition: '0 0' }, to: { backgroundPosition: '20px 0' } },
                 } : {}) }} />
      <Box sx={{ width: 0, height: 0, borderTop: '4px solid transparent', borderBottom: '4px solid transparent',
                 borderLeft: '6px solid', borderLeftColor: c }} />
    </Box>
  );
}

/** What the engine recorded per side for one run (GET /api/feed-dashboard). */
export interface RunSides {
  total: number | null; status?: string | null; failed_stage?: string | null;
  failed_side?: 'primary' | 'secondary' | 'both' | null; certification?: string | null; combined: boolean;
  /** the row-count check's OUTCOME (not just that it ran) */
  row_count_check?: { breach: boolean; action: string | null; skipped: boolean; skipped_reason?: string | null;
                      delta_pct?: number | null; baseline_avg?: number | null; threshold_pct?: number | null;
                      direction?: string | null; reason?: string | null; expect_zero?: boolean } | null;
  /** the per-side certification verdict: certified / mismatch / uncertified / null = never checked */
  certified?: string | null;
  primary: SideFacts; secondary: SideFacts;
}
/** May only the failed side re-run? (core/feed/side_resume.py::offer) */
export interface SideRerun {
  ok: boolean; reason: string | null; rerun_side: 'primary' | 'secondary' | null;
  kept_side: 'primary' | 'secondary' | null; kept_rows?: number | null; from_execution?: string | null;
}
export interface SideFacts {
  rows: number | null; reported: number | null; verdict: string | null; reason: string | null; dependency?: string | null;
}

/** the side's configured label (feeds/environments.ts -- never spelled here) */
const SIDE_OF = { primary: { get label() { return envLabel('primary'); } },
                  secondary: { get label() { return envLabel('secondary'); } } } as const;
const n = (v: number | null | undefined) => (v == null ? '?' : Number(v).toLocaleString());

/** A step's colour from its OUTCOME, not from "it ran" (2026-10-12, the owner:
 *  "how come it becomes green if the count did not match").  Pure. */
export function verdictOf(s: FlowStep, sides?: RunSides | null): { state: string; caption?: string } {
  const alias = s.alias || s.name;
  const state = String(s.state || 'pending');
  if (state !== 'completed') return { state };
  if (alias === 'row_count_check' || alias === 'row_count_floor') {
    const rc = sides?.row_count_check;
    if (rc?.breach) {
      const words = rc.reason === 'below_absolute_floor' ? 'below the minimum'
        : `${rc.direction === 'down' ? '-' : '+'}${Math.round(Number(rc.delta_pct ?? 0))}% vs usual ${n(rc.baseline_avg)}`;
      return { state: rc.action === 'fail' ? 'failed' : 'warning', caption: `breach: ${words}` };
    }
    if (rc?.skipped) return { state: 'skipped', caption: rc.skipped_reason ? 'no history to compare' : 'off' };
  }
  if ((alias === 'format_output' || alias.startsWith('format_')) && s.rows_out === 0
      && !sides?.row_count_check?.expect_zero) {
    return { state: 'warning', caption: 'EMPTY file (0 rows)' };
  }
  return { state };
}

/** One lane's three nodes -- upstream, fetch, count check -- from the
 *  recorded facts.  Pure, so the rule is testable. */
export function laneStates(side: 'primary' | 'secondary', sides: RunSides, deps: FlowDep[] | undefined,
                           extract: FlowStep | undefined) {
  const f = sides[side];
  const dep = (deps || []).find(d => envSide(d.side) === side);
  const upstream = !dep ? 'completed' : dep.satisfies ? 'completed' : 'waiting';
  const ex = String(extract?.state || 'pending');
  const failedHere = sides.failed_side === side || sides.failed_side === 'both';
  let fetch: string;
  if (ex === 'failed' || ex === 'refused') {
    // the engine says WHICH side's read broke; the other side read fine (primary
    // is read first: a secondary failure means the primary completed)
    fetch = failedHere && sides.failed_stage !== 'certify_reported_rows' ? 'failed'
      : sides.failed_side === 'primary' && side === 'secondary' ? 'not_started'
      : !sides.failed_side ? 'failed' : 'completed';
  } else {
    fetch = ex;
  }
  if (sides.failed_stage === 'certify_reported_rows') fetch = 'completed';
  // the message's ROW_COUNT is a contract: matched / FAILED / released by an
  // operator's skip (uncertified) -- and a run that never checked it is a
  // WARNING, never "not needed"
  let count: string;
  if (f.verdict === 'certified') count = 'completed';
  else if (f.verdict === 'mismatch') count = 'failed';
  else if (f.verdict === 'uncertified') count = 'skipped';
  else count = fetch === 'completed' ? 'warning' : 'pending';
  return { dep, upstream, fetch, count };
}

function Lane({ side, sides, deps, extract, onPick, picked, sideRerun, onRerunSide }: {
  side: 'primary' | 'secondary'; sides: RunSides; deps?: FlowDep[]; extract?: FlowStep;
  onPick: (k: string) => void; picked: string | null;
  sideRerun?: SideRerun | null; onRerunSide?: () => void;
}) {
  const f = sides[side];
  const s = laneStates(side, sides, deps, extract);
  const label = SIDE_OF[side].label;
  return (
    <Stack direction="row" alignItems="flex-start" data-testid={`board-lane-${side}`}
           sx={{ borderRadius: 1, px: 0.5, bgcolor: (t) => alpha(t.palette.text.primary, 0.03) }}>
      <Chip size="small" label={label} variant="outlined" sx={{ mt: '14px', mr: 0.5, fontWeight: 700, height: 20, fontSize: 10.5 }} />
      <Node testid="board-lane-node" width={118} label="Upstream" state={s.upstream} kind="upstream"
            selected={picked === `deps-${side}`} onClick={() => onPick(`deps-${side}`)}
            caption={s.dep ? (s.dep.satisfies ? 'arrived' : 'waiting') : 'none'}
            tip={s.dep ? <><b>{s.dep.name}</b><br />{s.dep.satisfies ? 'Arrived' : 'Not arrived yet'}</> : 'No dependency on this side'} />
      <Link state={arrowState(s.upstream, s.fetch)} minWidth={10} />
      <Node testid="board-lane-node" width={118} label="Data fetched" state={s.fetch} kind="fetch"
            selected={picked === `fetch-${side}`} onClick={() => onPick(`fetch-${side}`)}
            caption={f.rows != null ? `${n(f.rows)} rows` : s.fetch === 'failed' ? 'read failed' : undefined}
            tip={<>{label} side: the query ran on its source.<br />{f.rows != null ? `${n(f.rows)} rows read.` : ''}
              {s.fetch === 'failed' ? ' This side’s read FAILED.' : ''}</>} />
      <Link state={arrowState(s.fetch, s.count)} minWidth={10} />
      <Node testid="board-lane-node" width={150} label="Count matches" state={s.count} kind="counts"
            selected={picked === `count-${side}`} onClick={() => onPick(`count-${side}`)}
            caption={f.reported != null ? `${n(f.rows)} of ${n(f.reported)} expected`
              : s.count === 'skipped' ? 'skipped by an operator'
              : s.count === 'warning' ? 'count NOT checked' : undefined}
            tip={f.reason || 'The rows read are compared with the ROW_COUNT the upstream message reported.'} />
      {sideRerun && sideRerun.rerun_side === side && onRerunSide && (
        <Tooltip title={sideRerun.ok
          ? `Reads only the ${label} side again and reuses the ${SIDE_OF[sideRerun.kept_side || 'primary'].label} side's `
            + `${n(sideRerun.kept_rows)} rows already read (checked again when it runs)`
          : `Not possible: ${sideRerun.reason}`}>
          <span style={{ alignSelf: 'center' }}>
            <Button size="small" variant="contained" color="warning" disabled={!sideRerun.ok}
                    startIcon={<RerunIcon fontSize="small" />} sx={{ ml: 1, whiteSpace: 'nowrap' }}
                    data-testid={`board-rerun-side-${side}`} aria-label={`Re-run ${label} only`}
                    onClick={onRerunSide}>
              Re-run {label} only
            </Button>
          </span>
        </Tooltip>
      )}
    </Stack>
  );
}

export function ProcessFlow({ steps, deps, sides, error, verdicts, onRerun, sideRerun, onRerunSide }: {
  steps: FlowStep[];
  deps?: FlowDep[];
  sides?: RunSides | null;
  /** the failed side alone may re-run (or why not) */
  sideRerun?: SideRerun | null;
  onRerunSide?: () => void;
  error?: string | null;
  verdicts?: Record<string, { allowed: boolean; reason: string }>;
  onRerun?: (alias: string, label: string) => void;
}) {
  const ordered = useMemo(() => flowOrder(steps), [steps]);
  const lanes = !!sides?.combined;
  const startStep = ordered.find(s => (s.alias || s.name) === 'run_admission');
  const extract = ordered.find(s => (s.alias || s.name) === 'source_extract');
  // with lanes, the start and the per-side fetch are drawn in the lanes; the
  // shared chain is everything else, in the order it happened
  const chain = lanes ? ordered.filter(s => s !== startStep && s !== extract) : ordered;
  const firstBad = chain.findIndex(s => s.state === 'failed' || s.state === 'refused');
  const [picked, setPicked] = useState<string | null>(firstBad >= 0 ? `step-${firstBad}` : null);
  const [all, setAll] = useState(false);
  const met = (deps || []).filter(d => d.satisfies).length;
  const depState = !deps || deps.length === 0 ? 'completed' : met === deps.length ? 'completed' : 'waiting';
  const pick = (k: string) => setPicked(p => (p === k ? null : k));
  const selIdx = picked?.startsWith('step-') ? Number(picked.slice(5)) : null;
  const sel = selIdx != null ? chain[selIdx] : null;
  const laneSel = picked && (picked.startsWith('fetch-') || picked.startsWith('count-')) ? picked : null;
  const depsSel = picked === 'deps' ? 'all' : picked?.startsWith('deps-') ? picked.slice(5) as 'primary' | 'secondary' : null;

  const chainNodes = chain.map((s, i) => {
    const alias = s.alias || s.name;
    const w = stepWords(alias);
    const v = verdictOf(s, sides);
    const state = v.state;
    const prev = i === 0 ? null : chain[i - 1];
    return (
      <React.Fragment key={`${alias}-${i}`}>
        {(i > 0 || !lanes) && <Link state={arrowState(prev ? verdictOf(prev, sides).state : depState, state)} />}
        <Node testid="board-step" label={w.label} state={state} kind={stepKind(alias)} caption={v.caption || nodeCaption(s)}
              selected={picked === `step-${i}`} onClick={() => pick(`step-${i}`)}
              tip={<Box sx={{ maxWidth: 340 }}>
                <b>{w.label}</b> — {STEP_STATE_WORDS[state] || state}<br />
                {w.help}<br />{whenWords(s)}{nodeCaption(s) ? ` — ${nodeCaption(s)}` : ''}
                {s.detail ? <><br />{String(s.detail).slice(0, 300)}</> : null}
              </Box>} />
      </React.Fragment>
    );
  });

  // a delivered run that was NOT certified against its upstream counts says so
  const uncertified = sides && sides.status === 'completed' && (deps || []).length > 0
    && sides.certified !== 'certified'
    ? (sides.certified === 'uncertified'
      ? "Delivered with a side released by an operator's skip — that side was not checked against an upstream count."
      : 'Delivered WITHOUT being checked against the upstream message counts (this run is older than the row-count check, or no message carried a count).')
    : null;
  return (
    <Box data-testid="board-process-flow">
      {uncertified && (
        <Typography variant="body2" data-testid="board-uncertified"
                    sx={{ mb: 1, px: 1, py: 0.5, borderRadius: 1, borderLeft: 4, borderColor: STATE_HEX.warning,
                          bgcolor: (t) => alpha(STATE_HEX.warning, t.palette.mode === 'dark' ? 0.18 : 0.08) }}>
          {uncertified}
        </Typography>
      )}
      {lanes && sides ? (
        <Stack direction="row" alignItems="center" sx={{ overflowX: 'auto', pb: 0.5 }}>
          {startStep && (
            <Node testid="board-step" label="Started" state={String(startStep.state || 'pending')} kind="start"
                  caption={nodeCaption(startStep)} tip={<>{stepWords('run_admission').help}<br />{whenWords(startStep)}</>} />
          )}
          {/* the fork: one lane per side */}
          <Box sx={{ alignSelf: 'stretch', display: 'flex', alignItems: 'center' }}>
            <Box sx={{ width: 12, height: 3, bgcolor: STATE_HEX.completed }} />
            <Box sx={{ width: 3, height: '62%', bgcolor: (t) => alpha(t.palette.text.primary, 0.25), borderRadius: 2 }} />
          </Box>
          <Stack spacing={0.75} sx={{ mx: 0.5 }} data-testid="board-lanes">
            <Lane side="primary" sides={sides} deps={deps} extract={extract} onPick={pick} picked={picked}
                  sideRerun={sideRerun} onRerunSide={onRerunSide} />
            <Lane side="secondary" sides={sides} deps={deps} extract={extract} onPick={pick} picked={picked}
                  sideRerun={sideRerun} onRerunSide={onRerunSide} />
          </Stack>
          {/* the merge */}
          <Box sx={{ alignSelf: 'stretch', display: 'flex', alignItems: 'center' }}>
            <Box sx={{ width: 3, height: '62%', bgcolor: (t) => alpha(t.palette.text.primary, 0.25), borderRadius: 2 }} />
            <Box sx={{ width: 12, height: 3, bgcolor: (t) => alpha(t.palette.text.primary, 0.25) }} />
          </Box>
          <Tooltip title={`Cloud ${n(sides.primary.rows)} + on-prem ${n(sides.secondary.rows)} rows, merged by column name`}>
            <Box data-testid="board-merge" sx={{ px: 1, py: 0.5, borderRadius: 1, bgcolor: 'action.hover', textAlign: 'center', mr: 0.5 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, display: 'block' }}>Combined</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: 11 }}>
                {sides.total != null && sides.status === 'completed' ? `${n(sides.total)} rows` : `${n(sides.primary.rows)} + ${n(sides.secondary.rows)}`}
              </Typography>
            </Box>
          </Tooltip>
          {chainNodes}
        </Stack>
      ) : (
        <Stack direction="row" alignItems="flex-start" sx={{ overflowX: 'auto', pb: 0.5 }}>
          <Node testid="board-flow-deps" label="Upstream data ready" state={depState}
                selected={picked === 'deps'} onClick={() => pick('deps')}
                icon={depState === 'completed' ? undefined : <DepsIcon sx={{ fontSize: 16, color: '#fff' }} />}
                caption={deps && deps.length ? `${met} of ${deps.length} arrived` : 'waits for nothing'}
                tip={deps && deps.length
                  ? <>{deps.map(d => <div key={d.name}>{d.satisfies ? '✓' : '…'} {d.side ? `${d.side}: ` : ''}{d.name}</div>)}</>
                  : 'This feed waits for no upstream load.'} />
          {chainNodes}
        </Stack>
      )}

      {depsSel && (
        <DepsPanel deps={deps || []} side={depsSel === 'all' ? undefined : depsSel} />
      )}

      {laneSel && sides && (() => {
        const side = laneSel.endsWith('primary') ? 'primary' : 'secondary';
        const f = sides[side];
        const st = laneStates(side, sides, deps, extract);
        const isCount = laneSel.startsWith('count');
        const state = isCount ? st.count : st.fetch;
        return (
          <Paper variant="outlined" data-testid="board-step-panel"
                 sx={{ mt: 1, p: 1.25, borderLeft: 4, borderLeftColor: STATE_HEX[state] || STATE_HEX.pending }}>
            <Typography variant="body2" sx={{ fontWeight: 700 }}>
              {SIDE_OF[side].label} — {isCount ? 'Count matches upstream' : 'Data fetched'} — {STEP_STATE_WORDS[state] || state}
            </Typography>
            <Typography variant="caption" component="div">
              {isCount ? (f.reason || (state === 'warning'
                ? "This run did not check the rows against the message's ROW_COUNT — a run older than the row-count check, or a message without a count."
                : 'Not reached.'))
                : `${f.rows != null ? `${n(f.rows)} rows read` : 'rows not recorded'}${extract ? ` — ${whenWords(extract)}` : ''}`}
            </Typography>
            {state === 'failed' && error && !isCount && (
              <Typography variant="caption" color="error" component="div" sx={{ mt: 0.5 }}>{String(error).slice(0, 600)}</Typography>
            )}
          </Paper>
        );
      })()}

      {sel && (() => {
        const alias = sel.alias || sel.name;
        const w = stepWords(alias);
        const state = String(sel.state || 'pending');
        const bad = state === 'failed' || state === 'refused';
        const v = verdicts?.[alias];
        return (
          <Paper variant="outlined" data-testid="board-step-panel"
                 sx={{ mt: 1, p: 1.25, borderLeft: 4, borderLeftColor: STATE_HEX[state] || STATE_HEX.pending }}>
            <Stack direction="row" alignItems="flex-start" spacing={1}>
              <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                <Typography variant="body2" sx={{ fontWeight: 700 }}>{w.label} — {STEP_STATE_WORDS[state] || state}</Typography>
                {w.help && <Typography variant="caption" color="text.secondary" component="div">{w.help}</Typography>}
                <Typography variant="caption" component="div" sx={{ mt: 0.25 }}>
                  {[whenWords(sel), nodeCaption(sel)].filter(Boolean).join(' — ')}
                </Typography>
                {bad && (sel.detail || error) && (
                  <Typography variant="caption" color="error" component="div" sx={{ mt: 0.5 }}>
                    {String(sel.detail || error).slice(0, 600)}
                  </Typography>
                )}
              </Box>
              {v?.allowed && onRerun && (
                <Button size="small" startIcon={<RerunIcon fontSize="small" />}
                        aria-label={`Re-run step ${sel.name}`} onClick={() => onRerun(alias, w.label)}>
                  Re-run this step
                </Button>
              )}
            </Stack>
          </Paper>
        );
      })()}

      <Button size="small" sx={{ mt: 0.5 }} onClick={() => setAll(a => !a)} data-testid="board-steps-all-toggle">
        {all ? 'Hide step details' : 'Show all step details'}
      </Button>
      {all && (
        <Box data-testid="board-steps-all">
          {ordered.map((s, i) => {
            const w = stepWords(s.alias || s.name);
            const state = String(s.state || 'pending');
            return (
              <Stack key={i} direction="row" spacing={1.5} alignItems="baseline" data-testid="board-step-detail"
                     sx={{ py: 0.5, borderBottom: 1, borderColor: 'divider' }}>
                <Typography variant="caption" sx={{ width: 18, color: 'text.secondary' }}>{i + 1}</Typography>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>{w.label}</Typography>
                  <Typography variant="caption" color="text.secondary">{w.help}</Typography>
                </Box>
                <Typography variant="caption" sx={{ minWidth: 220, textAlign: 'right' }}>
                  <b style={{ color: STATE_HEX[state] }}>{STEP_STATE_WORDS[state] || state}</b>
                  {' — '}{[whenWords(s), nodeCaption(s)].filter(Boolean).join(' · ')}
                </Typography>
              </Stack>
            );
          })}
        </Box>
      )}
    </Box>
  );
}

/** A run row's chain: the step states as connected dots (from the counts). */
export function MiniFlow({ s, seq, deps, title }: {
  s?: { total: number; completed: number; failed: number; running: number; not_started: number; skipped: number };
  /** the steps IN THE ORDER THEY HAPPENED (the server's step_seq) */
  seq?: { alias: string; state: string }[];
  deps?: FlowDep[];
  title: React.ReactNode;
}) {
  const states: string[] = [];
  if (deps && deps.length) states.push(deps.every(d => d.satisfies) ? 'completed' : 'waiting');
  if (seq && seq.length) {
    seq.forEach(x => states.push(x.state === 'refused' ? 'failed' : x.state));
  } else if (s && s.total) {
    (['completed', 'skipped', 'failed', 'running', 'not_started'] as const)
      .forEach(k => { for (let i = 0; i < (s as any)[k]; i++) states.push(k); });
  }
  return (
    <Tooltip title={title}>
      <Stack direction="row" alignItems="center" data-testid="board-mini-flow" sx={{ mt: 0.5, maxWidth: 300 }}>
        {states.length === 0 && <Typography variant="caption" color="text.disabled">not started</Typography>}
        {states.map((st, i) => (
          <React.Fragment key={i}>
            {i > 0 && (() => {
              const a = arrowState(states[i - 1], st);
              return <Box data-testid="board-mini-arrow" data-state={a}
                          sx={{ flex: 1, minWidth: 6, height: 2, bgcolor: a === 'pending'
                                  ? (t) => alpha(t.palette.text.primary, 0.15) : (STATE_HEX[a] || STATE_HEX.pending) }} />;
            })()}
            <Box sx={{ width: 9, height: 9, borderRadius: '50%', flexShrink: 0, bgcolor: STATE_HEX[st] || STATE_HEX.pending,
                       animation: st === 'running' ? 'qsPulse2 1.4s ease-in-out infinite' : undefined,
                       '@keyframes qsPulse2': { '50%': { opacity: 0.4 } } }} />
          </React.Fragment>
        ))}
      </Stack>
    </Tooltip>
  );
}
