/**
 * The Feeds list, grouped (2026-10-26, the owner: "feeds should have a group
 * if the same system entity has 5 jobs, like FX-AMER code has 6 feeds").
 *
 * Nothing about a group is spelled here.  A list is grouped by:
 *  - its FEED GROUP (``feed_group_id``; a template's group rule fills it,
 *    e.g. one group per {SYSTEM_ENTITY});
 *  - its TEMPLATE (``template_id``);
 *  - a TEMPLATE PARAMETER -- the names come from the templates themselves
 *    (``parameters``), the value from the member's ``query_params`` (an apply
 *    adds the member's values there) -- so "by SYSTEM_ENTITY" works for a
 *    template that never declared a group rule;
 *  - or not at all.
 * A feed the grouping says nothing about lands in the last group ("No group",
 * "No template", "No <PARAM>") -- never dropped.
 */

export type GroupBy = 'feed_group' | 'template' | 'schedule' | 'none' | `param:${string}`;

export interface FeedLike {
  id: number;
  name?: string;
  is_active?: boolean;
  feed_group_id?: number | null;
  template_id?: number | null;
  query_params?: Record<string, unknown> | null;
  schedule_declaration?: { kind?: string; n?: number; business_date?: string } | null;
  schedule_enabled?: boolean | null;
}

/** A feed's DECLARED schedule in words -- what decides when its task is
 *  created and which date its data is for (core/feed/schedule.py).  The
 *  owner, 2026-10-26: "how do we categorise daily jobs vs month end jobs". */
export function scheduleWords(f: FeedLike): string {
  const d = f.schedule_declaration || {};
  const base: Record<string, string> = {
    daily: 'Daily', month_end: 'Month end', workdays: 'Chosen work days', on_demand: 'On demand',
    on_completion_of: 'When another feed completes', cron: 'Cron schedule',
  };
  let words = d.kind === 'workday_n' ? `Work day ${d.n ?? '?'} of the month` : base[d.kind || ''];
  if (!words) words = f.schedule_enabled ? 'Cron schedule' : 'Not scheduled';
  if (d.business_date === 'month_end' && d.kind !== 'month_end') words += ' -- data for the month end';
  if (d.business_date === 'previous_month_end') words += ' -- data for the previous month end';
  return words;
}

export interface FeedGroup<F extends FeedLike> {
  key: string;
  label: string;
  feeds: F[];
  /** true for the "No ..." bucket -- shown last */
  rest: boolean;
}

export interface Names {
  groups?: Array<{ id: number; name: string; display_label?: string | null }>;
  templates?: Array<{ id: number; name: string; parameters?: string[] | null }>;
}

export function groupByOptions(names: Names): Array<{ value: GroupBy; label: string }> {
  const params = Array.from(new Set((names.templates || []).flatMap(t => t.parameters || [])))
    .sort((a, b) => a.localeCompare(b));
  return [
    { value: 'feed_group', label: 'Feed group' },
    { value: 'template', label: 'Template' },
    { value: 'schedule', label: 'Schedule (daily, month end ...)' },
    ...params.map(p => ({ value: `param:${p}` as GroupBy, label: `${p} (template value)` })),
    { value: 'none', label: 'No grouping' },
  ];
}

function paramValue(f: FeedLike, name: string): string | null {
  const qp = f.query_params || {};
  const v = qp[name] ?? Object.entries(qp).find(([k]) => k.toLowerCase() === name.toLowerCase())?.[1];
  return v === undefined || v === null || v === '' || typeof v === 'object' ? null : String(v);
}

export function groupFeeds<F extends FeedLike>(feeds: F[], by: GroupBy, names: Names): FeedGroup<F>[] {
  if (by === 'none') return [{ key: 'all', label: 'All feeds', feeds, rest: false }];
  const groupName = new Map((names.groups || []).map(g => [g.id, g.display_label || g.name]));
  const templateName = new Map((names.templates || []).map(t => [t.id, t.name]));
  const param = by.startsWith('param:') ? by.slice('param:'.length) : null;
  const restLabel = by === 'feed_group' ? 'No group' : by === 'template' ? 'No template' : `No ${param}`;
  const buckets = new Map<string, FeedGroup<F>>();
  for (const f of feeds) {
    let key: string | null = null;
    let label = '';
    if (by === 'feed_group' && f.feed_group_id != null) {
      key = `g${f.feed_group_id}`;
      label = groupName.get(f.feed_group_id) || `Group ${f.feed_group_id}`;
    } else if (by === 'template' && f.template_id != null) {
      key = `t${f.template_id}`;
      label = templateName.get(f.template_id) || `Template ${f.template_id}`;
    } else if (by === 'schedule') {
      key = `s${scheduleWords(f)}`;
      label = scheduleWords(f);
    } else if (param) {
      const v = paramValue(f, param);
      if (v != null) { key = `p${v}`; label = v; }
    }
    const k = key ?? '~rest';
    if (!buckets.has(k)) buckets.set(k, { key: k, label: key ? label : restLabel, feeds: [], rest: !key });
    buckets.get(k)!.feeds.push(f);
  }
  return Array.from(buckets.values()).sort((a, b) =>
    a.rest !== b.rest ? (a.rest ? 1 : -1) : a.label.localeCompare(b.label, undefined, { numeric: true }));
}
