/**
 * Engine -- where the feed's runs execute, and why (2026-10-26).
 *
 * The owner: "where is Execution Backend?" -- it sat inside the closed
 * "Advanced: how it runs" box on the When step -- and "why by default is
 * native? native is really slow for 2m rows with 600 columns".  This is the
 * one place the engine is chosen, on the Review step, with the server's own
 * answer to "what does Automatic pick for this feed right now, and why"
 * (GET /api/feeds/{id}/engine-choice: the same size and router a run uses).
 * A new feed has no answer yet: it says how the choice is made.
 */
import { useCallback, useEffect, useState } from 'react';
import { Alert, Box, Button, CircularProgress, Paper, Stack, TextField, Typography } from '@mui/material';
import ExecutionBackendSelect from '../common/ExecutionBackendSelect';
import api from '../../services/api';

type Choice = Awaited<ReturnType<typeof api.getFeedEngineChoice>>;

export interface FeedEngineSectionProps {
  feedId?: number | null;
  value: string;
  onChange: (v: string) => void;
  sizeLimit: string;
  onSizeLimitChange: (v: string) => void;
  /** the engine choice was edited in this dialog: the saved answer is stale */
  dirty?: boolean;
}

const NOTES: Record<string, string> = {
  native: 'Runs on this server. Good for small and medium feeds. A very large or very wide feed is slow here.',
  spark_k8s: 'Each run gets its own Spark cluster, started for the run and removed after it. Best for large and wide feeds. Starting the cluster adds about a minute.',
  spark_connect: 'Runs on a shared Spark cluster.',
  airflow: 'Runs through Airflow on a separate worker.',
};

export default function FeedEngineSection({ feedId, value, onChange, sizeLimit, onSizeLimitChange, dirty }: FeedEngineSectionProps) {
  const [choice, setChoice] = useState<Choice | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ask = useCallback((count: boolean) => {
    if (!feedId) return;
    setLoading(true);
    setError(null);
    api.getFeedEngineChoice(feedId, count)
      .then(setChoice)
      .catch((e: any) => setError(e?.message || 'Could not work out the engine'))
      .finally(() => setLoading(false));
  }, [feedId]);

  useEffect(() => { ask(false); }, [ask]);

  return (
    <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="feed-engine-section">
      <Stack spacing={1}>
        <Typography variant="body2" sx={{ fontWeight: 700 }}>Engine</Typography>
        <ExecutionBackendSelect value={value} plain onChange={onChange} />
        {value === 'auto' && (
          <TextField
            label="Row limit for this server (optional)"
            value={sizeLimit}
            onChange={e => onSizeLimitChange(e.target.value.replace(/[^\d]/g, ''))}
            fullWidth size="small" placeholder={choice?.threshold_rows ? String(choice.threshold_rows) : '500000'}
            inputProps={{ 'data-testid': 'feed-size-limit' }}
            helperText="Blank = the deployment's limit. A run larger than this goes to a Spark cluster. A wide run counts as more rows."
          />
        )}
        {NOTES[value] && <Typography variant="caption" color="text.secondary">{NOTES[value]}</Typography>}
        {!feedId && (
          <Typography variant="caption" color="text.secondary" data-testid="feed-engine-new">
            Automatic decides when each run starts: it takes the size from your estimate, the upstream
            message's row count or the last run, and counts the rows on the source when none is known.
            Large or wide runs go to a Spark cluster.
          </Typography>
        )}
        {feedId && (
          <Box data-testid="feed-engine-choice">
            {loading && <CircularProgress size={16} />}
            {error && <Alert severity="warning">{error}</Alert>}
            {choice && !loading && (
              <Alert severity={choice.pinned_unavailable ? 'error' : 'info'} sx={{ py: 0 }}
                     action={choice.rows == null && value === 'auto' ? (
                       <Button size="small" onClick={() => ask(true)} data-testid="feed-engine-count">
                         Count the rows now
                       </Button>) : undefined}>
                {dirty ? 'As saved: ' : ''}{choice.sentence}
              </Alert>
            )}
          </Box>
        )}
      </Stack>
    </Paper>
  );
}
