/**
 * Dependencies & SLA -- the tracker tab of Feed Run Status (2026-10-25).
 *
 * The owner: "feed gen still doesn't show how many dependencies arrived or
 * pending ... a nice dashboard to track where the dependencies are ... SLA
 * tracker ... on Feed Run Status only ... interactive ... each feed wise".
 *
 * ONE answer from GET /api/feed-dependency-tracker (core/feed/
 * dependency_tracker.py): the summary tiles, a donut of dependency states, the
 * SLA verdicts, and two tables -- BY DEPENDENCY (where each one is, the feeds
 * waiting on it, the tightest SLA among them) and BY FEED (arrived / total,
 * what it still waits on, its SLA).  Every tile filters the table below it.
 * A dependency's state is THE gate's verdict and an SLA verdict THE SLA
 * board's -- this page decides nothing, it shows.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Chip, Collapse, IconButton, LinearProgress, Paper, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import { alpha } from '@mui/material/styles';
import RefreshIcon from '@mui/icons-material/Refresh';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RTooltip } from 'recharts';
import api from '../../services/api';
import ListPager, { clientPage } from '../common/ListPager';
import { slaChip } from './FeedRunBoard';
import { expectedWords, type PersonState } from './DependencyTiles';

export type DepState = 'arrived' | 'waiting' | 'skipped' | 'not_expected' | 'could_not_tell';

export interface TrackerSla {
  verdict: string | null; sla_to: string | null; sla_timezone: string | null; deadline_utc: string | null;
  minutes_vs_deadline: number | null; alerted: boolean | null; delivered_at?: string | null;
}
export interface TrackerDependency {
  dependency: string; side: string | null; state: DepState; verdict: string | null; action: string | null;
  reason: string | null; asserted: boolean; arrived_at: string | null; last_seen: string | null;
  expected_rows: number | null; reported_rows: number | null;
  roads: { kind: string; topic?: string | null; table?: string | null }[];
  feeds_total: number; feeds_waiting: number;
  feeds: { feed_id: number; feed_name: string | null; run_status: string | null; sla_verdict: string | null;
           deadline_utc: string | null }[];
  tightest_deadline_utc: string | null; tightest_sla_feed: string | null; worst_sla: string | null;
  minutes_to_deadline: number | null; overdue: boolean;
  clocks: { stage: string | null; usual_by: string | null; minutes_late: number | null;
            decision_deadline: string | null; summary: string | null } | null;
  /** 2026-10-25 -- what a PERSON reads: arrived | waiting | delayed | skipped | not_expected */
  person_state?: PersonState;
  /** THE delay rule's answer (acting_time.person_delays) */
  delay?: { expected_by: string | null; expected_by_source: 'sla' | 'usual' | null; delayed: boolean;
            minutes_delayed: number | null } | null;
  /** QueryStudio could not check it right now (the reason) */
  cant_check?: string | null;
}
export interface TrackerFeed {
  feed_id: number; feed_name: string | null; run_id: number | null; group_name: string | null;
  run_status: string | null; action_decision: string | null; sla: TrackerSla;
  deps_total: number; arrived: number; waiting: number; skipped: number; not_expected: number;
  could_not_tell: number; pending: number; waiting_on: string[]; deps_unavailable: string | null;
}
export interface Tracker {
  business_date: string; now: string; at_risk_minutes: number | null;
  summary: Record<string, number>; sla_counts: Record<string, number>;
  dependencies: TrackerDependency[]; feeds: TrackerFeed[]; gate_reads: number; unavailable: string[];
}

/** a state as the board's tiles word and colour it (depBadge) */
export const PERSON_FACE: Record<PersonState, { label: string; hex: string }> = {
  arrived: { label: 'Arrived', hex: '#2e7d32' },
  waiting: { label: 'Waiting', hex: '#ed6c02' },
  delayed: { label: 'Delayed', hex: '#c62828' },
  skipped: { label: 'Skipped', hex: '#0288d1' },
  not_expected: { label: 'Not expected', hex: '#78909c' },
};

export const STATE_FACE: Record<DepState, { label: string; hex: string }> = {
  arrived: { label: 'Arrived', hex: '#2e7d32' },
  waiting: { label: 'Waiting', hex: '#ed6c02' },
  could_not_tell: { label: "Can't check", hex: '#d32f2f' },
  skipped: { label: 'Skipped', hex: '#0288d1' },
  not_expected: { label: 'Not expected', hex: '#757575' },
};
const SLA_FACE: Record<string, { label: string; hex: string }> = {
  breached: { label: 'Breached', hex: '#c62828' }, late: { label: 'Delivered late', hex: '#e53935' },
  at_risk: { label: 'At risk', hex: '#ef6c00' }, on_track: { label: 'On track', hex: '#1565c0' },
  met: { label: 'Met', hex: '#2e7d32' }, no_sla: { label: 'No SLA', hex: '#757575' },
  not_due: { label: 'Nothing due', hex: '#9e9e9e' }, invalid_sla: { label: 'SLA unreadable', hex: '#6a1b9a' },
};
const SLA_ORDER = ['breached', 'late', 'at_risk', 'on_track', 'met', 'no_sla', 'not_due', 'invalid_sla'];

/** "in 2h 05m" / "4h 10m ago" -- a deadline relative to now.  Pure. */
export function untilText(minutes: number | null | undefined): string {
  if (minutes == null) return '';
  const m = Math.abs(minutes);
  const t = m >= 60 ? `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m` : `${m}m`;
  return minutes >= 0 ? `in ${t}` : `${t} ago`;
}
const at = (iso?: string | null) => (iso ? String(iso).replace('T', ' ').slice(0, 16) : '');
const roadWord = (r: { kind: string; topic?: string | null; table?: string | null }) =>
  ({ kafka: 'Kafka', oracle_table: 'Message table', file: 'File', iceberg_commit: 'Iceberg', etl: 'ETL' } as
   Record<string, string>)[r.kind] ?? r.kind;

type DepFilter = 'all' | 'pending' | 'overdue' | DepState;
type FeedFilter = 'all' | 'waiting' | 'all_arrived' | 'breached' | 'at_risk' | 'unreadable';

export function Tile({ label, value, hex, active, onClick, testid, hint }: {
  label: string; value: number | string; hex: string; active?: boolean; onClick?: () => void; testid: string;
  hint?: string;
}) {
  return (
    <Tooltip title={hint || ''}>
      <Paper variant="outlined" role={onClick ? 'button' : undefined} tabIndex={onClick ? 0 : undefined}
             aria-pressed={onClick ? !!active : undefined} data-testid={testid}
             onClick={onClick} onKeyDown={e => { if (onClick && (e.key === 'Enter' || e.key === ' ')) onClick(); }}
             sx={{ px: 1.5, py: 1, minWidth: 108, cursor: onClick ? 'pointer' : 'default', borderLeft: 4,
                   borderLeftColor: hex, bgcolor: (th) => active ? alpha(hex, th.palette.mode === 'dark' ? 0.25 : 0.1)
                                                                  : 'background.paper' }}>
        <Typography sx={{ fontSize: 22, fontWeight: 700, color: hex, lineHeight: 1.1 }}>{value}</Typography>
        <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>{label}</Typography>
      </Paper>
    </Tooltip>
  );
}

function StateChip({ s }: { s: DepState | PersonState }) {
  const f = (PERSON_FACE as any)[s] || STATE_FACE[s as DepState] || STATE_FACE.could_not_tell;
  return <Chip size="small" label={f.label} data-testid="tracker-state" data-state={s}
               sx={{ fontWeight: 700, color: f.hex, bgcolor: (th) => alpha(f.hex, th.palette.mode === 'dark' ? 0.22 : 0.1) }} />;
}

function SlaCell({ verdict, deadline, minutes }: { verdict: string | null; deadline: string | null; minutes?: number | null }) {
  const c = slaChip({ verdict: verdict || '', sla_to: null, sla_timezone: null, deadline_utc: deadline,
                      minutes_vs_deadline: minutes ?? null, alerted: false });
  if (!verdict || verdict === 'not_due') return <Typography variant="caption" color="text.disabled">—</Typography>;
  return (
    <Stack spacing={0.25}>
      {c ? <Chip size="small" color={c.color} label={c.label} variant={c.color === 'default' ? 'outlined' : 'filled'} />
         : <Typography variant="caption">{SLA_FACE[verdict]?.label ?? verdict}</Typography>}
      {deadline && <Typography variant="caption" color="text.secondary">due {at(deadline)} UTC</Typography>}
    </Stack>
  );
}

function DependencyRow({ d }: { d: TrackerDependency }) {
  const [open, setOpen] = useState(false);
  const ps = d.person_state ?? d.state;
  const where = d.state === 'arrived'
    ? `arrived ${at(d.arrived_at)}`
    : d.delay?.expected_by
      ? `${expectedWords(d.delay)}${ps === 'delayed' && d.delay.minutes_delayed != null ? ` — ${d.delay.minutes_delayed} min late` : ''}`
      : d.last_seen ? `last seen ${at(d.last_seen)}` : 'no message yet';
  return (
    <>
      <TableRow hover data-testid="tracker-dep-row" data-dependency={d.dependency}
                sx={d.overdue ? { bgcolor: (th) => alpha(th.palette.error.main, 0.06) } : undefined}>
        <TableCell padding="checkbox">
          <IconButton size="small" aria-label={open ? `Hide feeds waiting on ${d.dependency}` : `Show feeds waiting on ${d.dependency}`}
                      onClick={() => setOpen(o => !o)}>
            {open ? <KeyboardArrowDownIcon fontSize="small" /> : <KeyboardArrowRightIcon fontSize="small" />}
          </IconButton>
        </TableCell>
        <TableCell><StateChip s={ps} /></TableCell>
        <TableCell>
          <Typography sx={{ fontWeight: 600, fontSize: 13, wordBreak: 'break-all' }}>{d.dependency}</Typography>
          {d.cant_check && (
            <Tooltip title={`For support: ${d.cant_check}`}>
              <Typography variant="caption" color="error.main" data-testid="tracker-cant-check">
                {/is not running/i.test(d.cant_check) ? 'Listener not running -- new messages are not being read'
                  : "Can't check right now -- checked again automatically"}
              </Typography>
            </Tooltip>
          )}
        </TableCell>
        <TableCell>{d.side || '—'}</TableCell>
        <TableCell>
          <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
            {d.roads.length ? d.roads.map((r, i) => (
              <Tooltip key={i} title={r.topic || r.table || ''}><Chip size="small" variant="outlined" label={roadWord(r)} /></Tooltip>
            )) : <Typography variant="caption" color="text.disabled">any evidence</Typography>}
          </Stack>
        </TableCell>
        <TableCell>
          <Typography variant="body2">{where}</Typography>
          {d.reported_rows != null && <Typography variant="caption" color="text.secondary">{d.reported_rows.toLocaleString()} rows reported</Typography>}
          {d.clocks?.decision_deadline && d.state !== 'arrived' && (
            <Typography variant="caption" color="text.secondary" component="div">decide by {at(d.clocks.decision_deadline)} UTC</Typography>)}
        </TableCell>
        <TableCell align="right" data-testid="tracker-dep-feeds">
          <Typography sx={{ fontWeight: 700 }}>{d.feeds_waiting} / {d.feeds_total}</Typography>
          <Typography variant="caption" color="text.secondary">waiting / total</Typography>
        </TableCell>
        <TableCell>
          {d.tightest_deadline_utc ? (
            <Stack spacing={0.25}>
              <Typography variant="body2" sx={{ color: d.minutes_to_deadline != null && d.minutes_to_deadline < 0 ? 'error.main' : undefined, fontWeight: 600 }}>
                {untilText(d.minutes_to_deadline)}
              </Typography>
              <Typography variant="caption" color="text.secondary" noWrap title={d.tightest_sla_feed || ''}>{d.tightest_sla_feed}</Typography>
            </Stack>
          ) : <Typography variant="caption" color="text.disabled">no open SLA</Typography>}
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell colSpan={8} sx={{ py: 0, borderBottom: open ? undefined : 'none' }}>
          <Collapse in={open} unmountOnExit>
            <Box sx={{ py: 1, pl: 6 }} data-testid="tracker-dep-feed-list">
              {d.clocks?.summary && <Alert severity={d.overdue ? 'error' : 'info'} sx={{ mb: 1, py: 0 }}>{d.clocks.summary}</Alert>}
              <Table size="small">
                <TableHead><TableRow><TableCell>Feed</TableCell><TableCell>Run</TableCell><TableCell>SLA</TableCell></TableRow></TableHead>
                <TableBody>
                  {d.feeds.map(f => (
                    <TableRow key={f.feed_id}>
                      <TableCell>{f.feed_name ?? `feed ${f.feed_id}`}</TableCell>
                      <TableCell>{f.run_status ?? '—'}</TableCell>
                      <TableCell><SlaCell verdict={f.sla_verdict} deadline={f.deadline_utc} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {d.feeds.length < d.feeds_total && (
                <Typography variant="caption" color="text.secondary">
                  showing {d.feeds.length} of {d.feeds_total} feeds — search narrows the list
                </Typography>)}
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
}

function FeedRow({ f }: { f: TrackerFeed }) {
  const pct = f.deps_total ? Math.round(100 * (f.arrived + f.skipped + f.not_expected) / f.deps_total) : 100;
  return (
    <TableRow hover data-testid="tracker-feed-row" data-feed={f.feed_id}>
      <TableCell>
        <Typography sx={{ fontWeight: 600, fontSize: 13 }}>{f.feed_name ?? `feed ${f.feed_id}`}</Typography>
        {f.group_name && <Typography variant="caption" color="text.secondary">{f.group_name}</Typography>}
      </TableCell>
      <TableCell sx={{ minWidth: 170 }}>
        {f.deps_unavailable ? (
          <Tooltip title={f.deps_unavailable}><Chip size="small" color="error" variant="outlined" label="could not be read" /></Tooltip>
        ) : f.deps_total === 0 ? (
          <Typography variant="caption" color="text.disabled">waits for nothing</Typography>
        ) : (
          <Stack spacing={0.5}>
            <Typography variant="body2" data-testid="tracker-feed-progress">
              <b>{f.arrived}</b> of {f.deps_total} arrived{f.skipped ? ` · ${f.skipped} skipped` : ''}
            </Typography>
            <LinearProgress variant="determinate" value={pct} color={f.pending ? 'warning' : 'success'}
                            aria-label={`${f.arrived} of ${f.deps_total} dependencies arrived`} sx={{ height: 6, borderRadius: 3 }} />
          </Stack>
        )}
      </TableCell>
      <TableCell>
        <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
          {f.waiting_on.slice(0, 4).map(n => <Chip key={n} size="small" variant="outlined" color="warning" label={n} />)}
          {f.waiting_on.length > 4 && <Chip size="small" label={`+${f.waiting_on.length - 4}`} />}
        </Stack>
      </TableCell>
      <TableCell>{f.action_decision === 'WAIT' ? 'held — waiting' : (f.run_status ?? '—')}</TableCell>
      <TableCell><SlaCell verdict={f.sla.verdict} deadline={f.sla.deadline_utc} minutes={f.sla.minutes_vs_deadline} /></TableCell>
    </TableRow>
  );
}

export default function FeedDependencyTracker({ businessDate, onBusinessDateChange }: {
  businessDate: string; onBusinessDateChange?: (d: string) => void;
}) {
  const [data, setData] = useState<Tracker | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [applied, setApplied] = useState('');
  const [view, setView] = useState<'dependency' | 'feed'>('dependency');
  const [depFilter, setDepFilter] = useState<DepFilter>('all');
  const [feedFilter, setFeedFilter] = useState<FeedFilter>('all');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.feedDependencyTracker(businessDate, applied);
      setData(r as Tracker);
      setError(null);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [businessDate, applied]);
  useEffect(() => { void load(); }, [load]);
  // a tracker is watched: refresh every 30 s while the tab is open
  useEffect(() => {
    const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30_000);
    return () => window.clearInterval(t);
  }, [load]);
  useEffect(() => { setPage(1); }, [view, depFilter, feedFilter, applied, businessDate]);

  const s = data?.summary || {};
  const deps = useMemo(() => (data?.dependencies || []).filter(d =>
    depFilter === 'all' ? true
    : depFilter === 'pending' ? (d.state === 'waiting' || d.state === 'could_not_tell')
    : depFilter === 'overdue' ? d.overdue : d.state === depFilter), [data, depFilter]);
  const feeds = useMemo(() => (data?.feeds || []).filter(f =>
    feedFilter === 'all' ? true
    : feedFilter === 'waiting' ? f.pending > 0
    : feedFilter === 'all_arrived' ? (f.deps_total > 0 && f.pending === 0 && !f.deps_unavailable)
    : feedFilter === 'unreadable' ? !!f.deps_unavailable
    : feedFilter === 'breached' ? (f.sla.verdict === 'breached' || f.sla.verdict === 'late')
    : f.sla.verdict === feedFilter), [data, feedFilter]);

  const donut = (['arrived', 'waiting', 'could_not_tell', 'skipped', 'not_expected'] as DepState[])
    .map(k => ({ key: k, name: STATE_FACE[k].label, value: s[k] || 0, hex: STATE_FACE[k].hex }))
    .filter(x => x.value > 0);
  const slaBars = SLA_ORDER.map(k => ({ key: k, ...SLA_FACE[k], value: data?.sla_counts?.[k] || 0 }))
    .filter(x => x.value > 0 && x.key !== 'not_due');
  const slaTotal = slaBars.reduce((a, b) => a + b.value, 0);
  const pick = (f: DepFilter) => { setView('dependency'); setDepFilter(cur => (cur === f ? 'all' : f)); };
  const pickFeed = (f: FeedFilter) => { setView('feed'); setFeedFilter(cur => (cur === f ? 'all' : f)); };
  const depPage = clientPage(deps, page, pageSize);
  const feedPage = clientPage(feeds, page, pageSize);

  return (
    <Box data-testid="feed-dependency-tracker" sx={{ mt: 1 }}>
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mb: 1.5 }}>
        <TextField size="small" type="date" label="Business date" value={businessDate}
                   onChange={e => onBusinessDateChange?.(e.target.value)} InputLabelProps={{ shrink: true }}
                   inputProps={{ 'data-testid': 'tracker-date' }} />
        <TextField size="small" label="Search a feed or group" value={search} onChange={e => setSearch(e.target.value)}
                   onKeyDown={e => { if (e.key === 'Enter') setApplied(search.trim()); }}
                   onBlur={() => setApplied(search.trim())} inputProps={{ 'data-testid': 'tracker-search' }} />
        <Tooltip title="Refresh (refreshes itself every 30 s)">
          <span><IconButton aria-label="Refresh the tracker" onClick={() => void load()} disabled={loading}><RefreshIcon /></IconButton></span>
        </Tooltip>
        {data && <Typography variant="caption" color="text.secondary">as of {at(data.now)} UTC</Typography>}
      </Stack>
      {loading && <LinearProgress sx={{ mb: 1 }} />}
      {error && <Alert severity="error" sx={{ mb: 1 }} data-testid="tracker-error">The tracker could not be read: {error}</Alert>}
      {data && data.unavailable.length > 0 && (
        <Alert severity="warning" sx={{ mb: 1 }}>Part of the answer could not be read: {data.unavailable.join('; ')}</Alert>)}
      {data && (s.feeds_unreadable || 0) > 0 && (
        <Alert severity="warning" sx={{ mb: 1 }} action={<Chip size="small" label="show" onClick={() => pickFeed('unreadable')} />}>
          {s.feeds_unreadable} feed(s): dependencies could not be read — unknown, not "nothing to wait for".
        </Alert>)}

      {data && (
        <Stack direction={{ xs: 'column', lg: 'row' }} spacing={2} sx={{ mb: 2 }}>
          <Paper variant="outlined" sx={{ p: 1.5, flex: 1.4 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Dependencies on {data.business_date}</Typography>
            <Stack direction="row" spacing={2} alignItems="center">
              <Box sx={{ width: 150, height: 150, flexShrink: 0 }} data-testid="tracker-donut">
                {donut.length ? (
                  <ResponsiveContainer>
                    <PieChart>
                      <Pie data={donut} dataKey="value" nameKey="name" innerRadius={42} outerRadius={68} paddingAngle={2}
                           onClick={(e: any) => pick(e?.payload?.key ?? e?.key)} cursor="pointer" isAnimationActive={false}>
                        {donut.map(x => <Cell key={x.key} fill={x.hex} />)}
                      </Pie>
                      <RTooltip />
                    </PieChart>
                  </ResponsiveContainer>
                ) : <Typography variant="caption" color="text.disabled">no dependencies</Typography>}
              </Box>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                <Tile testid="tracker-tile-total" label="dependencies" value={s.dependencies ?? 0} hex="#455a64"
                      active={depFilter === 'all' && view === 'dependency'} onClick={() => pick('all')} />
                <Tile testid="tracker-tile-arrived" label="arrived" value={s.arrived ?? 0} hex={STATE_FACE.arrived.hex}
                      active={depFilter === 'arrived'} onClick={() => pick('arrived')} />
                <Tile testid="tracker-tile-pending" label="not arrived" value={s.pending ?? 0} hex={STATE_FACE.waiting.hex}
                      active={depFilter === 'pending'} onClick={() => pick('pending')}
                      hint="waiting or delayed" />
                <Tile testid="tracker-tile-overdue" label="delayed" value={s.overdue ?? 0} hex="#c62828"
                      active={depFilter === 'overdue'} onClick={() => pick('overdue')}
                      hint="past its feed's SLA, or past the time it usually arrives when the feed has no SLA" />
                <Tile testid="tracker-tile-skipped" label="skipped" value={s.skipped ?? 0} hex={STATE_FACE.skipped.hex}
                      active={depFilter === 'skipped'} onClick={() => pick('skipped')} hint="released by a person, not by evidence" />
              </Stack>
            </Stack>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5, flex: 1 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Feeds</Typography>
            <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 1.5 }}>
              <Tile testid="tracker-tile-feeds" label="feeds" value={s.feeds ?? 0} hex="#455a64"
                    active={view === 'feed' && feedFilter === 'all'} onClick={() => pickFeed('all')} />
              <Tile testid="tracker-tile-feeds-ready" label="all arrived" value={s.feeds_all_arrived ?? 0} hex={STATE_FACE.arrived.hex}
                    active={feedFilter === 'all_arrived'} onClick={() => pickFeed('all_arrived')} />
              <Tile testid="tracker-tile-feeds-waiting" label="still waiting" value={s.feeds_waiting ?? 0} hex={STATE_FACE.waiting.hex}
                    active={feedFilter === 'waiting'} onClick={() => pickFeed('waiting')} />
            </Stack>
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>SLA</Typography>
            {slaTotal === 0 ? <Typography variant="caption" color="text.disabled">no SLA on this date</Typography> : (
              <>
                <Box sx={{ display: 'flex', height: 14, borderRadius: 1, overflow: 'hidden', mb: 0.75 }} data-testid="tracker-sla-bar">
                  {slaBars.map(b => (
                    <Tooltip key={b.key} title={`${b.label}: ${b.value}`}>
                      <Box role="button" aria-label={`SLA ${b.label}: ${b.value}`} onClick={() =>
                             (b.key === 'breached' || b.key === 'late') ? pickFeed('breached')
                             : b.key === 'at_risk' ? pickFeed('at_risk') : pickFeed('all')}
                           sx={{ width: `${(100 * b.value) / slaTotal}%`, bgcolor: b.hex, cursor: 'pointer' }} />
                    </Tooltip>
                  ))}
                </Box>
                <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                  {slaBars.map(b => (
                    <Chip key={b.key} size="small" data-testid={`tracker-sla-${b.key}`}
                          label={`${b.label} ${b.value}`} onClick={() =>
                            (b.key === 'breached' || b.key === 'late') ? pickFeed('breached')
                            : b.key === 'at_risk' ? pickFeed('at_risk') : pickFeed('all')}
                          sx={{ color: b.hex, borderColor: b.hex }} variant="outlined" />
                  ))}
                </Stack>
              </>
            )}
          </Paper>
        </Stack>
      )}

      {data && (
        <Paper variant="outlined">
          <Stack direction="row" alignItems="center" spacing={1} sx={{ px: 1.5, py: 1 }} flexWrap="wrap" useFlexGap>
            <ToggleButtonGroup size="small" exclusive value={view} onChange={(_, v) => v && setView(v)} aria-label="Track by">
              <ToggleButton value="dependency" data-testid="tracker-view-dependency">By dependency</ToggleButton>
              <ToggleButton value="feed" data-testid="tracker-view-feed">By feed</ToggleButton>
            </ToggleButtonGroup>
            {view === 'dependency' && depFilter !== 'all' && (
              <Chip size="small" label={`showing: ${depFilter.replace(/_/g, ' ')}`} onDelete={() => setDepFilter('all')} />)}
            {view === 'feed' && feedFilter !== 'all' && (
              <Chip size="small" label={`showing: ${feedFilter.replace(/_/g, ' ')}`} onDelete={() => setFeedFilter('all')} />)}
            <Box sx={{ flex: 1 }} />
            <ListPager paging={view === 'dependency' ? depPage.paging : feedPage.paging}
                       onPage={setPage} onPageSize={n => { setPageSize(n); setPage(1); }} testid="tracker-pager" />
          </Stack>
          <Box sx={{ overflowX: 'auto' }}>
            {view === 'dependency' ? (
              <Table size="small" data-testid="tracker-dep-table">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" /><TableCell>State</TableCell><TableCell>Dependency</TableCell>
                    <TableCell>Side</TableCell><TableCell>Arrives via</TableCell><TableCell>Where it is</TableCell>
                    <TableCell align="right">Feeds</TableCell><TableCell>Next SLA</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {depPage.rows.map(d => <DependencyRow key={d.dependency} d={d} />)}
                  {depPage.rows.length === 0 && (
                    <TableRow><TableCell colSpan={8}><Typography variant="body2" color="text.secondary">
                      {(data.dependencies.length === 0) ? 'No feed on this date waits for a dependency.' : 'Nothing matches this filter.'}
                    </Typography></TableCell></TableRow>)}
                </TableBody>
              </Table>
            ) : (
              <Table size="small" data-testid="tracker-feed-table">
                <TableHead>
                  <TableRow>
                    <TableCell>Feed</TableCell><TableCell>Dependencies</TableCell><TableCell>Still waiting on</TableCell>
                    <TableCell>Run</TableCell><TableCell>SLA</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {feedPage.rows.map(f => <FeedRow key={f.feed_id} f={f} />)}
                  {feedPage.rows.length === 0 && (
                    <TableRow><TableCell colSpan={5}><Typography variant="body2" color="text.secondary">
                      {(data.feeds.length === 0) ? 'No feed task on this date.' : 'Nothing matches this filter.'}
                    </Typography></TableCell></TableRow>)}
                </TableBody>
              </Table>
            )}
          </Box>
        </Paper>
      )}
    </Box>
  );
}
