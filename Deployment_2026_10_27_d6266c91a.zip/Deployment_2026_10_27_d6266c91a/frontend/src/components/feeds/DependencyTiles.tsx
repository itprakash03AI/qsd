/**
 * A feed run's dependencies as TILES -- one per upstream dependency, colour
 * coded by the gate's own verdict (2026-10-12).  ONE component for Feed Run
 * Status's Board AND its List view's opened row.
 *
 * Each tile: the road (Kafka / file / Iceberg ...), CLOUD or ON-PREM, the
 * verdict in plain words (Arrived / Waiting / Skipped / Not expected / Could
 * not tell), the upstream message's own fields (CODE, STORE, SOURCE, BUSINESS
 * EVENT, CLOUD COMPLIANT, ROW COUNT) and when it arrived; (i) opens every
 * message; Skip (for the business date) on a tile still waiting.  From
 * GET /api/feed-dashboard/task -- the words are the server's.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { alpha } from '@mui/material/styles';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle,
  IconButton, MenuItem, Paper, Stack, TextField, Tooltip, Typography,
} from '@mui/material';
import { InfoOutlined as InfoIcon, SkipNext as SkipIcon } from '@mui/icons-material';
import api from '../../services/api';
import { envRank } from './environments';
import ListPager, { clientPage } from '../common/ListPager';

export interface DepCard {
  dependency_name: string;
  side: string | null;
  verdict: string;
  satisfies: boolean;
  action?: string | null;
  reason: string | null;
  sources?: { kind: string; verdict: string; reason: string | null }[] | null;
  messages: { source: string; arrived_at: string | null; reported_rows: number | null;
              message_identity?: string | null; fields: Record<string, unknown> }[];
  messages_unreadable: string | null;
  roads?: Road[];
  /** a WAITING dependency: the message it expects (the last one it received, or its name read back) */
  expected?: { fields: Record<string, unknown>; from: string; business_date?: string } | null;
  /** 2026-10-25 -- what a PERSON reads (the server's rule, acting_time.person_delays):
   *  arrived | waiting | delayed | skipped | not_expected */
  state?: PersonState;
  /** when it is expected by (HH:MM UTC) and why: the feed's SLA, or its usual arrival */
  expected_by?: string | null;
  expected_by_at?: string | null;
  expected_by_source?: 'sla' | 'usual' | null;
  minutes_delayed?: number | null;
  /** QueryStudio could not check it right now (the reason) -- it is still waiting / delayed */
  cant_check?: string | null;
}

export type PersonState = 'arrived' | 'waiting' | 'delayed' | 'skipped' | 'not_expected';

export const TONE_HEX: Record<string, string> = {
  success: '#2e7d32', warning: '#ed6c02', info: '#0288d1', error: '#d32f2f', default: '#78909c',
};

/** A tile's badge from the GATE's own (lower-case) words. */
export function depBadge(c: Pick<DepCard, 'verdict' | 'action'> & { state?: PersonState | null }):
    { label: string; color: 'success' | 'warning' | 'error' | 'default' | 'info' } {
  // the server's person state when it sent one (2026-10-25): arrived / waiting / delayed
  switch (c.state) {
    case 'arrived': return { label: 'ARRIVED', color: 'success' };
    case 'waiting': return { label: 'WAITING', color: 'warning' };
    case 'delayed': return { label: 'DELAYED', color: 'error' };
    case 'skipped': return { label: 'SKIPPED', color: 'info' };
    case 'not_expected': return { label: 'NOT EXPECTED', color: 'default' };
    default: break;
  }
  const v = String(c.verdict || '').toLowerCase();
  if (String(c.action || '').toUpperCase() === 'SKIP') return { label: 'SKIPPED', color: 'info' };
  if (v === 'met') return { label: 'ARRIVED', color: 'success' };
  if (v === 'not_expected') return { label: 'NOT EXPECTED', color: 'default' };
  if (v === 'not_met') return { label: 'WAITING', color: 'warning' };
  // 2026-10-25 (the owner: "COULD NOT TELL means?"): QueryStudio could not
  // check it right now -- not "not arrived"; the card says why
  if (v === 'could_not_tell') return { label: "CAN'T CHECK", color: 'error' };
  return { label: v ? v.toUpperCase() : 'UNKNOWN', color: 'default' };
}

const ROAD: Record<string, string> = {
  kafka: 'Kafka', oracle_table: 'Message table', file: 'File', iceberg_commit: 'Iceberg', etl: 'ETL',
};
/** a message field the tile shows -- DATABASE data (feed_message_fields),
 *  served with the task as `display_fields`; never spelled here */
export interface DisplayField { field: string; label: string }
/** a road a dependency is declared to arrive by */
export interface Road { kind: string; topic?: string | null; table?: string | null }
const fieldOf = (fields: Record<string, unknown> | undefined, name: string) => {
  if (!fields) return undefined;
  const key = Object.keys(fields).find(k => k.toUpperCase() === name.toUpperCase());
  return key === undefined ? undefined : fields[key];
};
/** what this side READ, for the tile's "expected vs read" (the run's record) */
export interface TileSideRead { rows: number | null; verdict: string | null }

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
/** "25 Oct 03:26" -- a time a person reads (the server sends ISO) */
function at(iso: string | null | undefined): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}:\d{2})/.exec(String(iso ?? ''));
  return m ? `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[4]}` : (iso ? String(iso) : '');
}
/** "03:59:00" -- the time of day only (the card's small line) */
function timeOnly(iso: string | null | undefined): string {
  const m = /[T ](\d{2}:\d{2}:\d{2})/.exec(String(iso ?? ''));
  return m ? m[1] : (iso ? String(iso) : '');
}

/** One sentence a support person reads without the code (the owner,
 *  2026-10-25: "text should be in human language"); the gate's own words stay
 *  in the tooltip for support. */
/** "expected by 06:00 (the feed's SLA)" / "usually arrives by 03:26" */
export function expectedWords(c: Pick<DepCard, 'expected_by' | 'expected_by_source'>): string {
  if (!c.expected_by) return '';
  return c.expected_by_source === 'sla' ? `expected by ${c.expected_by} UTC (the feed's SLA)`
    : `usually arrives by ${c.expected_by} UTC`;
}

function listenerWords(why: string): string {
  const road = /kafka/i.test(why) ? 'Kafka' : /oracle_table|QS_KAFKA_MESSAGE/i.test(why) ? 'message table' : '';
  return /is not running/i.test(why)
    ? ` QueryStudio cannot read new messages right now: the ${road || 'message'} listener is not running.`
    : ' QueryStudio could not check it just now; it is checked again automatically.';
}

export function plainReason(c: Pick<DepCard, 'verdict' | 'action' | 'satisfies' | 'messages'> & {
  reason?: string | null; state?: PersonState | null; expected_by?: string | null;
  expected_by_source?: 'sla' | 'usual' | null; minutes_delayed?: number | null; cant_check?: string | null }): string {
  if (c.state === 'delayed' || (c.state === 'waiting' && c.expected_by)) {
    const exp = expectedWords(c);
    const base = c.state === 'delayed'
      ? `Delayed -- ${exp}${c.minutes_delayed != null ? `, ${c.minutes_delayed} min late` : ''}.`
      : `Waiting -- ${exp}.`;
    return base + (c.cant_check ? listenerWords(c.cant_check) : '');
  }
  if (c.state === 'waiting' && c.cant_check) return 'Waiting -- no message yet for this date.' + listenerWords(c.cant_check);
  const msgs = c.messages || [];
  const last = msgs.length ? msgs[msgs.length - 1] : null;
  const n = msgs.length;
  const v = String(c.verdict || '').toLowerCase();
  if (String(c.action || '').toUpperCase() === 'SKIP') return 'Skipped by a person for this date.';
  if (v === 'met') {
    if (!last) return 'Released without a message.';
    return `Arrived ${at(last.arrived_at)} by ${ROAD[last.source] || last.source}`
      + ` (${n} message${n === 1 ? '' : 's'}${last.reported_rows != null ? `, ${last.reported_rows} rows` : ''}).`;
  }
  if (v === 'not_expected') return 'Not expected on this date (calendar rule).';
  if (v === 'could_not_tell') {
    const why = String((c as any).reason || '');
    const road = /kafka/i.test(why) ? 'Kafka' : /oracle_table|QS_KAFKA_MESSAGE/i.test(why) ? 'message table' : '';
    if (/is not running/i.test(why)) {
      return `Can't check: the ${road || 'message'} listener is not running, so new messages are not being read. `
        + 'It is checked again as soon as the listener is back.';
    }
    return "Can't check right now (QueryStudio could not read whether it arrived). It is checked again automatically.";
  }
  if (last) return `Waiting -- last message ${at(last.arrived_at)} did not complete it.`;
  return 'Waiting -- no message yet for this date.';
}

export type CardSort = 'waiting' | 'name' | 'latest' | 'side';

export default function DependencyTiles({ feedId, businessDate, onSkip, onCount, read }: {
  feedId: number;
  businessDate: string;
  /** Skip that dependency for the business date (the caller opens its dialog). */
  onSkip?: (dependencyName: string) => void;
  /** Reports (met, total) once read, for a summary elsewhere. */
  onCount?: (met: number, total: number) => void;
  /** rows each side READ in this run (CLOUD / ON-PREM), against the message's count */
  read?: Record<string, TileSideRead>;
}) {
  const [cards, setCards] = useState<DepCard[] | null>(null);
  const [shownFields, setShownFields] = useState<DisplayField[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<DepCard | null>(null);
  // the popup's messages are PAGED (a month end can carry dozens)
  // 2026-10-25 (the owner: "1 feed can have 500+ kafka message
  // dependencies"): the cards are FILTERED (state, search) and PAGED
  const [cardFilter, setCardFilter] = useState<'all' | 'waiting' | 'delayed' | 'arrived' | 'skipped'>('all');
  const [cardSearch, setCardSearch] = useState('');
  const [cardSort, setCardSort] = useState<CardSort>('waiting');
  const [cardPage, setCardPage] = useState(1);
  const [cardSize, setCardSize] = useState(25);
  useEffect(() => { setCardPage(1); }, [cardFilter, cardSearch, cardSort]);
  const [msgPage, setMsgPage] = useState(1);
  const [msgSize, setMsgSize] = useState(25);
  useEffect(() => { setMsgPage(1); }, [info]);      // another dependency starts at page 1

  const load = useCallback(() => {
    setError(null);
    api.feedDashboardTask(feedId, businessDate)
      .then((r: any) => {
        const c: DepCard[] = r.dependencies || [];
        setCards(c);
        setShownFields(r.display_fields || []);
        onCount?.(c.filter(x => x.satisfies).length, c.length);
      })
      .catch((e: any) => setError(e?.message || 'Could not read the dependencies'));
  }, [feedId, businessDate]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load]);

  const shownCards = useMemo(() => {
    const q = cardSearch.trim().toLowerCase();
    return [...(cards || [])]
      .filter(c => {
        const b = depBadge(c).label;
        if (cardFilter === 'waiting' && !(b === 'WAITING' || b === 'DELAYED' || b === "CAN'T CHECK")) return false;
        if (cardFilter === 'delayed' && b !== 'DELAYED') return false;
        if (cardFilter === 'arrived' && b !== 'ARRIVED') return false;
        if (cardFilter === 'skipped' && b !== 'SKIPPED') return false;
        return !q || c.dependency_name.toLowerCase().includes(q);
      })
      // the person's order; by default (past a dozen) waiting first, then
      // CLOUD before ON-PREM (the run's lanes)
      .sort((x, y) => {
        const lastAt = (c: DepCard) => String(c.messages?.[c.messages.length - 1]?.arrived_at || '');
        if (cardSort === 'name') return x.dependency_name.localeCompare(y.dependency_name);
        if (cardSort === 'latest') return lastAt(y).localeCompare(lastAt(x)) || x.dependency_name.localeCompare(y.dependency_name);
        if (cardSort === 'side') return envRank(x.side) - envRank(y.side) || x.dependency_name.localeCompare(y.dependency_name);
        const rank = (c: DepCard) => (c.state === 'delayed' ? 0 : c.satisfies ? 2 : 1);
        return ((cards || []).length > 12 ? rank(x) - rank(y) : 0)
               || envRank(x.side) - envRank(y.side);
      });
  }, [cards, cardFilter, cardSearch, cardSort]);
  const counts = useMemo(() => {
    const out = { all: 0, waiting: 0, delayed: 0, arrived: 0, skipped: 0 };
    for (const c of cards || []) {
      const b = depBadge(c).label;
      out.all += 1;
      if (b === 'WAITING' || b === 'DELAYED' || b === "CAN'T CHECK") out.waiting += 1;
      if (b === 'DELAYED') out.delayed += 1;
      else if (b === 'ARRIVED') out.arrived += 1;
      else if (b === 'SKIPPED') out.skipped += 1;
    }
    return out;
  }, [cards]);
  const cardPg = clientPage(shownCards, cardPage, cardSize);

  if (error) return <Alert severity="error" data-testid="dep-tiles-error">{error}</Alert>;
  if (!cards) return <CircularProgress size={16} />;
  if (cards.length === 0) {
    return (
      <Typography variant="body2" color="text.secondary" data-testid="dep-tiles-none">
        This feed waits for nothing — it runs when its schedule says.
      </Typography>
    );
  }
  // 2026-10-12 (owner: "dependency tile not as per shared", temp/dash_v1.jpeg):
  // a small card per dependency -- road tag + status + side, the skip icon on
  // the right; CODE / STORE / SOURCE / EVENT / ROWS; then "<ROAD> MESSAGES (n)"
  // with the latest few, each opening the full message.
  return (
    <>
      {cards.length > 12 && (
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mb: 1 }}
               data-testid="board-dep-toolbar">
          {(['all', 'waiting', 'delayed', 'arrived', 'skipped'] as const).map(k => (
            <Chip key={k} size="small" clickable data-testid={`board-dep-filter-${k}`}
                  color={cardFilter === k ? 'primary' : 'default'}
                  label={`${k === 'all' ? 'All' : k[0].toUpperCase() + k.slice(1)} ${counts[k]}`}
                  onClick={() => setCardFilter(k)} />
          ))}
          <TextField size="small" placeholder="Search a dependency" value={cardSearch}
                     onChange={e => setCardSearch(e.target.value)} inputProps={{ 'data-testid': 'board-dep-search' }} />
          <TextField select size="small" label="Order" value={cardSort} sx={{ minWidth: 170 }}
                     onChange={e => setCardSort(e.target.value as CardSort)} data-testid="board-dep-sort">
            <MenuItem value="waiting">Waiting first</MenuItem>
            <MenuItem value="name">Name A-Z</MenuItem>
            <MenuItem value="latest">Latest message first</MenuItem>
            <MenuItem value="side">Cloud / on-prem</MenuItem>
          </TextField>
          <Box sx={{ flex: 1 }} />
          <ListPager paging={cardPg.paging} onPage={setCardPage} onPageSize={setCardSize} testid="board-dep-pager" />
        </Stack>
      )}
      <Stack direction="row" useFlexGap sx={{ flexWrap: 'wrap', gap: 1 }} data-testid="board-dep-cards">
        {/* waiting first; CLOUD before ON-PREM -- the run's lanes */}
        {(cards.length > 12 ? cardPg.rows : shownCards).map(c => {
          const badge = depBadge(c);
          const m = c.messages[c.messages.length - 1];
          // the road the message ACTUALLY came by, else the first declared one
          const kind = m?.source || c.sources?.[0]?.kind || '';
          const road = ROAD[kind] || kind || 'Dependency';
          const hex = TONE_HEX[badge.color];
          return (
            <Paper key={c.dependency_name} variant="outlined" data-testid="board-dep-card" data-dependency={c.dependency_name}
                   sx={{ width: 236, p: 1, borderRadius: 1.5, borderTop: 3, borderTopColor: hex,
                         bgcolor: (t) => alpha(hex, t.palette.mode === 'dark' ? 0.12 : 0.04) }}>
              <Stack direction="row" alignItems="center" spacing={0.5}>
                <Typography sx={{ fontSize: 10, fontWeight: 800, letterSpacing: 0.5, color: 'info.main', textTransform: 'uppercase' }}>
                  {road}
                </Typography>
                <Chip size="small" label={badge.label} color={badge.color} data-testid="board-dep-badge"
                      sx={{ height: 18, fontSize: 10, fontWeight: 700 }} />
                {c.side && <Chip size="small" variant="outlined" label={c.side} data-testid="board-dep-side"
                                 sx={{ height: 18, fontSize: 10 }} />}
                <Box sx={{ flexGrow: 1 }} />
                <Tooltip title="All messages for this dependency">
                  <IconButton size="small" sx={{ p: 0.25 }} aria-label={`Details ${c.dependency_name}`} onClick={() => setInfo(c)}>
                    <InfoIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Tooltip>
                {!c.satisfies && onSkip && (
                  <Tooltip title={`Skip it for ${businessDate} (e.g. an upstream holiday)`}>
                    <IconButton size="small" color="warning" sx={{ p: 0.25 }} aria-label={`Skip ${c.dependency_name}`}
                                onClick={() => onSkip(c.dependency_name)}>
                      <SkipIcon sx={{ fontSize: 18 }} />
                    </IconButton>
                  </Tooltip>
                )}
              </Stack>
              <Box sx={{ mt: 0.75, display: 'grid', gridTemplateColumns: 'auto 1fr', columnGap: 1, rowGap: 0.1 }}>
                {(m ? shownFields.filter(f => fieldOf(m.fields, f.field) != null) : []).map(f => (
                  <Box key={f.field} sx={{ display: 'contents' }} data-testid="board-dep-field">
                    <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                      {f.label}
                    </Typography>
                    <Typography sx={{ fontSize: 12, fontWeight: 600, textAlign: 'right', wordBreak: 'break-all' }}>
                      {String(fieldOf(m!.fields, f.field))}
                    </Typography>
                  </Box>
                ))}
                {!m && (
                  // WAITING, as the reference board shows it: the message it
                  // EXPECTS (its fields), for which date; the technical routes
                  // only on hover (2026-10-12, the owner: "why are we showing
                  // waits on Kafka · topic ...")
                  <>
                    {shownFields.map(f => {
                      const v = c.expected?.fields ? fieldOf(c.expected.fields, f.field) : undefined;
                      if (v == null || v === '') return null;
                      return (
                        <Box key={f.field} sx={{ display: 'contents' }} data-testid="board-dep-expected-field">
                          <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                            {f.label}
                          </Typography>
                          <Typography sx={{ fontSize: 12, fontWeight: 600, textAlign: 'right', wordBreak: 'break-all', color: 'text.secondary' }}>
                            {String(v)}
                          </Typography>
                        </Box>
                      );
                    })}
                    <Tooltip title={<>{c.dependency_name}{(c.roads || []).map((rd, i) => (
                      <React.Fragment key={i}><br />arrives via {ROAD[rd.kind] || rd.kind}{rd.topic ? ` (${rd.topic})` : ''}{rd.table ? ` (${rd.table})` : ''}</React.Fragment>))}</>}>
                      <Typography sx={{ gridColumn: '1 / -1', fontSize: 11 }} color="text.secondary" data-testid="board-dep-waiting-for">
                        Message not received yet for {businessDate}
                      </Typography>
                    </Tooltip>
                  </>
                )}
                {/* WHEN, and the count this side must match (data completeness per environment) */}
                <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                  Arrived
                </Typography>
                <Typography sx={{ fontSize: 12, fontWeight: 600, textAlign: 'right' }} data-testid="board-dep-arrived"
                            color={m ? undefined : 'warning.main'}>
                  {m ? timeOnly(m.arrived_at) : c.satisfies ? 'skipped' : 'not yet'}
                </Typography>
                {!m && !c.satisfies && c.expected_by && (
                  <>
                    <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                      {c.expected_by_source === 'sla' ? 'Due (SLA)' : 'Usually by'}
                    </Typography>
                    <Typography sx={{ fontSize: 12, fontWeight: 600, textAlign: 'right' }} data-testid="board-dep-expected-by"
                                color={c.state === 'delayed' ? 'error.main' : undefined}>
                      {c.expected_by}{c.state === 'delayed' && c.minutes_delayed != null ? ` (+${c.minutes_delayed} min)` : ''}
                    </Typography>
                  </>
                )}
                {c.cant_check && (
                  <Tooltip title={`For support: ${c.cant_check}`}>
                    <Typography sx={{ gridColumn: '1 / -1', fontSize: 11 }} color="error.main" data-testid="board-dep-cant-check">
                      {/is not running/i.test(c.cant_check) ? 'Listener not running -- new messages are not being read' : "Can't check right now"}
                    </Typography>
                  </Tooltip>
                )}
                {(() => {
                  const expected = m ? (m.reported_rows ?? (m.fields?.ROW_COUNT as any)) : null;
                  const r = c.side ? read?.[c.side] : undefined;
                  const ok = r?.verdict === 'certified' ? true : r?.verdict === 'mismatch' ? false : null;
                  return (
                    <>
                      <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                        Expected rows
                      </Typography>
                      <Typography sx={{ fontSize: 12, fontWeight: 700, textAlign: 'right' }} data-testid="board-dep-expected">
                        {expected != null ? Number(expected).toLocaleString() : '-'}
                      </Typography>
                      {r && (
                        <>
                          <Typography sx={{ fontSize: 10, fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', pt: '1px' }}>
                            Read
                          </Typography>
                          <Typography sx={{ fontSize: 12, fontWeight: 700, textAlign: 'right',
                                            color: ok === false ? 'error.main' : ok ? 'success.main' : 'warning.main' }}
                                      data-testid="board-dep-read">
                            {r.rows != null ? Number(r.rows).toLocaleString() : '?'} {ok === true ? '✓' : ok === false ? '✗' : '(not checked)'}
                          </Typography>
                        </>
                      )}
                    </>
                  );
                })()}
              </Box>
              <Box sx={{ mt: 0.75, pt: 0.5, borderTop: 1, borderColor: 'divider' }}>
                <Typography sx={{ fontSize: 10, fontWeight: 800, color: 'text.secondary', textTransform: 'uppercase' }}>
                  {road} messages ({c.messages.length})
                </Typography>
                {c.messages_unreadable && (
                  <Typography sx={{ fontSize: 11 }} color="error">could not be read: {c.messages_unreadable}</Typography>
                )}
                {c.messages.length === 0 && !c.messages_unreadable && (
                  <Typography sx={{ fontSize: 11 }} color={c.satisfies ? 'text.secondary' : 'warning.main'}>
                    {c.satisfies ? 'released without a message' : 'none yet for this date'}
                  </Typography>
                )}
                {c.messages.slice(-3).reverse().map((x, i) => (
                  <Typography key={i} sx={{ fontSize: 11, fontFamily: 'monospace', cursor: 'pointer',
                                             '&:hover': { textDecoration: 'underline' } }}
                              onClick={() => setInfo(c)}>
                    {timeOnly(x.arrived_at)}{x.reported_rows != null ? ` · ${x.reported_rows} rows` : ''}
                  </Typography>
                ))}
              </Box>
            </Paper>
          );
        })}
      </Stack>
      <Dialog open={!!info} onClose={() => setInfo(null)} maxWidth="sm" fullWidth>
        <DialogTitle>{info?.dependency_name}</DialogTitle>
        <DialogContent>
          {info && (
            <>
              <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
                <Chip size="small" label={depBadge(info).label} color={depBadge(info).color} />
                {info.side && <Chip size="small" variant="outlined" label={info.side} />}
              </Stack>
              <Tooltip title={info.reason ? `For support: ${info.reason}` : ''}>
                <Alert severity={info.satisfies ? 'success' : 'warning'} sx={{ mb: 1 }} data-testid="board-dep-plain">
                  {plainReason(info)}
                </Alert>
              </Tooltip>
              <Typography variant="subtitle2" sx={{ mt: 1 }}>Messages ({info.messages.length})</Typography>
              {info.messages_unreadable && <Alert severity="error">{info.messages_unreadable}</Alert>}
              {info.messages.length === 0 && <Typography variant="body2" color="text.secondary">None for this date.</Typography>}
              {(() => {
                const pg = clientPage(info.messages, msgPage, msgSize);
                return (<>
              {pg.rows.map((x, i) => (
                <Paper key={i} variant="outlined" sx={{ p: 1, mt: 0.5 }}>
                  <Typography variant="caption" component="div">
                    {at(x.arrived_at)} · {ROAD[x.source] || x.source}{x.reported_rows != null ? ` · ${x.reported_rows} rows` : ''}
                    {x.message_identity ? ` · ref ${x.message_identity}` : ''}
                  </Typography>
                  <Typography variant="caption" component="pre" sx={{ m: 0, whiteSpace: 'pre-wrap', fontFamily: 'monospace' }}>
                    {Object.entries(x.fields || {}).map(([k, val]) => `${k}: ${val}`).join('\n')}
                  </Typography>
                </Paper>
              ))}
              {info.messages.length > msgSize && (
                <ListPager paging={pg.paging} onPage={setMsgPage} onPageSize={setMsgSize} testid="board-dep-msg-pager" />
              )}
                </>);
              })()}
            </>
          )}
        </DialogContent>
        <DialogActions><Button onClick={() => setInfo(null)}>Close</Button></DialogActions>
      </Dialog>
    </>
  );
}
