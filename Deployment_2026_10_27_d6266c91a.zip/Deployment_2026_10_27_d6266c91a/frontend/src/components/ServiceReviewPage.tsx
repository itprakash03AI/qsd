/**
 * ServiceReviewPage — the monthly service-review surface (2026-09-03;
 * backend GET /api/service-review, core/feed/service_review.py).
 * 2026-10-26: one tab per area of QueryStudio -- feeds, reports & queries,
 * published APIs, platform (core/service_review.py); the server's ``areas``
 * says which section belongs where.
 *
 * Four sections, each degrading INDEPENDENTLY server-side; the backend
 * names the unavailable ones and this page renders that distinction:
 * an unavailable section shows the failure it named, an empty section
 * says "nothing to report" — the two must never look alike, because an
 * operator taught to trust an absence stops looking.
 *
 * NOTE the backend's section keys: success_rate_by_group,
 * trending_slower, dependency_late_most_often and **skips** (not
 * "skip_counts").
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Chip, CircularProgress, MenuItem, Paper, Stack, Tab, Table,
  TableBody, TableCell, TableHead, TableRow, Tabs, TextField, Typography,
} from '@mui/material';
import { Assessment as ReviewIcon } from '@mui/icons-material';
import api from '../services/api';
import ListPager, { clientPage } from './common/ListPager';
import type {
  ServiceReviewResponse, ServiceReviewSection,
} from '../services/api/feedOperations';

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; review: ServiceReviewResponse };

/** One section shell that renders the three states distinctly.  A
 *  section's rows grow with the estate (one per feed or group), so they
 *  are paged here: ``children`` receives one page, the pager sits under it. */
const Section: React.FC<{
  title: string;
  section: ServiceReviewSection | undefined;
  emptyText: string;
  children: (rows: any[]) => React.ReactNode;
  testId: string;
}> = ({ title, section, emptyText, children, testId }) => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  // A new period's numbers start again at page 1.
  useEffect(() => { setPage(1); }, [section]);
  const shown = clientPage(section?.rows ?? [], page, pageSize);
  return (
  <Paper sx={{ p: 2, mb: 2 }} data-testid={testId}>
    <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
      {title}
    </Typography>
    {section == null || section.unavailable ? (
      <Alert severity="error" data-testid={`${testId}-unavailable`}>
        This section could not be read — its numbers may exist but cannot be
        shown.
        {' '}{section?.unavailable
          ?? 'The response did not include this section.'}
      </Alert>
    ) : section.rows.length === 0 ? (
      <Alert severity="success" data-testid={`${testId}-empty`}>
        {emptyText}
      </Alert>
    ) : (
      <>
        {children(shown.rows)}
        <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                   testid={`${testId}-pager`} />
      </>
    )}
  </Paper>
  );
};

const pct = (v: number | null | undefined): string =>
  v == null ? '—' : `${(v * 100).toFixed(1)}%`;
const secs = (v: number | null | undefined): string =>
  v == null ? '—' : v >= 120 ? `${(v / 60).toFixed(1)} min` : `${v} s`;
const ms = (v: number | null | undefined): string =>
  v == null ? '—' : v >= 1000 ? `${(v / 1000).toFixed(1)} s` : `${v} ms`;
const when = (iso: string | null | undefined): string =>
  iso ? new Date(iso.endsWith('Z') || /[+-]\d\d:\d\d$/.test(iso) ? iso : `${iso}Z`).toLocaleString() : '—';

// 2026-10-26 -- the review covers ALL of QueryStudio, not only feeds
type AreaKey = 'feeds' | 'reports' | 'published_apis' | 'platform';
const AREA_KEYS: AreaKey[] = ['feeds', 'reports', 'published_apis', 'platform'];
const AREA_LABEL: Record<AreaKey, string> = {
  feeds: 'Feeds', reports: 'Reports & queries', published_apis: 'Published APIs', platform: 'Platform',
};
const AREA_HELP: Record<AreaKey, string> = {
  feeds: 'How the feeds did: which groups succeed, which feeds are getting slower, which dependencies are late, and what people skipped.',
  reports: 'Which reports failed and how long they took, and how each engine did with the queries it answered.',
  published_apis: 'How often each published API was called, how many calls failed or were turned away, and how fast it answered.',
  platform: 'Which parts of QueryStudio went down or could not be checked, and the alerts raised for every area.',
};
const DEFAULT_AREAS: Record<string, string[]> = {
  feeds: ['success_rate_by_group', 'trending_slower', 'dependency_late_most_often', 'skips'],
  reports: ['report_runs', 'query_runs_by_engine'],
  published_apis: ['api_calls'],
  platform: ['component_downtime', 'alerts_raised'],
};

const ServiceReviewPage: React.FC = () => {
  const [days, setDays] = useState(28);
  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });

  const loadReview = async (d: number) => {
    setLoad({ phase: 'loading' });
    try {
      const review = await api.getServiceReview(d);
      setLoad({ phase: 'ready', review });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => { void loadReview(days); }, [days]);

  const review = load.phase === 'ready' ? load.review : null;
  const sections = review?.sections ?? {};
  // 2026-10-26 -- the review covers ALL of QueryStudio; the server says which
  // section belongs to which area (an older server sends only the feed ones)
  const areas = review?.areas ?? DEFAULT_AREAS;
  const [tab, setTab] = useState<AreaKey>('feeds');
  const brokenIn = (a: AreaKey) =>
    (areas[a] || []).filter(n => review?.unavailable_sections.includes(n)).length;

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mb: 2 }}>
        <ReviewIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 700 }}>
          Service Review
        </Typography>
        <Box sx={{ flex: 1 }} />
        <TextField
          select size="small" label="Period" value={days}
          onChange={e => setDays(Number(e.target.value))}
          sx={{ minWidth: 140 }}
        >
          <MenuItem value={7}>Last 7 days</MenuItem>
          <MenuItem value={28}>Last 28 days</MenuItem>
          <MenuItem value={90}>Last 90 days</MenuItem>
        </TextField>
      </Stack>

      {load.phase === 'loading' && (
        <Stack alignItems="center" sx={{ py: 4 }}>
          <CircularProgress size={24} />
        </Stack>
      )}

      {load.phase === 'error' && (
        <Alert severity="error" data-testid="review-load-error">
          The service review could not be loaded — the estate&apos;s numbers
          exist but cannot be shown here. {load.message}
        </Alert>
      )}

      {review && (
        <>
          <Typography variant="caption" color="text.secondary"
                      sx={{ display: 'block', mb: 1.5 }}>
            Since {new Date(`${review.since}T00:00:00`).toLocaleDateString()}, worked out {when(review.generated_at)}.
          </Typography>

          {review.unavailable_sections.length > 0 && (
            <Alert severity="warning" sx={{ mb: 2 }}
                   data-testid="review-unavailable-banner">
              {review.unavailable_sections.length} section(s) could not be
              read: {review.unavailable_sections.join(', ')} — their panels
              below name the failure.  The other sections are complete.
            </Alert>
          )}

          <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}
                variant="scrollable" allowScrollButtonsMobile>
            {AREA_KEYS.map(a => (
              <Tab key={a} value={a} data-testid={`review-tab-${a}`}
                   label={brokenIn(a) ? `${AREA_LABEL[a]} (${brokenIn(a)} not read)` : AREA_LABEL[a]} />
            ))}
          </Tabs>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            {AREA_HELP[tab]}
          </Typography>

          {tab === 'feeds' && (<>
          <Section
            title="Success rate by feed group"
            section={sections.success_rate_by_group}
            emptyText={`No runs recorded in the last ${review.period_days} days.`}
            testId="review-success-rate"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Group</TableCell>
                    <TableCell align="right">Runs</TableCell>
                    <TableCell align="right">Success rate</TableCell>
                    <TableCell>By status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={String(r.feed_group_id)}>
                      <TableCell>{r.feed_group}</TableCell>
                      <TableCell align="right">{r.runs}</TableCell>
                      <TableCell align="right">
                        <Chip size="small" label={pct(r.success_rate)}
                              color={r.success_rate == null ? 'default'
                                : r.success_rate >= 0.99 ? 'success'
                                : r.success_rate >= 0.95 ? 'warning' : 'error'}
                              sx={{ height: 20, fontSize: '0.7rem' }} />
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption" color="text.secondary">
                          {Object.entries(r.by_status || {})
                            .map(([k, v]) => `${k}: ${v}`).join(' · ')}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>

          <Section
            title="Trending slower"
            section={sections.trending_slower}
            emptyText="Nothing is trending slower under the review thresholds."
            testId="review-trending"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Feed</TableCell>
                    <TableCell align="right">Recent avg</TableCell>
                    <TableCell align="right">Prior avg</TableCell>
                    <TableCell align="right">Ratio</TableCell>
                    <TableCell align="right">Runs (recent/prior)</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.feed_config_id}>
                      <TableCell>{r.feed_name ?? r.feed_config_id}</TableCell>
                      <TableCell align="right">
                        {r.avg_duration_recent_s}s
                      </TableCell>
                      <TableCell align="right">
                        {r.avg_duration_prior_s}s
                      </TableCell>
                      <TableCell align="right">
                        <Chip size="small" label={`${r.ratio}×`}
                              color={r.ratio >= 2 ? 'error' : 'warning'}
                              sx={{ height: 20, fontSize: '0.7rem' }} />
                      </TableCell>
                      <TableCell align="right">
                        {r.runs_recent}/{r.runs_prior}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>

          <Section
            title="Dependencies late most often"
            section={sections.dependency_late_most_often}
            emptyText="No dependency was recorded late in the period."
            testId="review-deps-late"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Dependency</TableCell>
                    <TableCell align="right">Not-met events</TableCell>
                    <TableCell align="right">Feeds affected</TableCell>
                    <TableCell>Last seen</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.dependency}>
                      <TableCell>{r.dependency}</TableCell>
                      <TableCell align="right">{r.not_met_events}</TableCell>
                      <TableCell align="right">{r.feeds_affected}</TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          {r.last_seen ?? '—'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>

          <Section
            title="Human overrides (skips)"
            section={sections.skips}
            emptyText="No run or dependency was skipped by a human in the period."
            testId="review-skips"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Feed</TableCell>
                    <TableCell align="right">Run skips</TableCell>
                    <TableCell align="right">Dependency skips</TableCell>
                    <TableCell align="right">Total</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.feed_config_id}>
                      <TableCell>{r.feed_name ?? r.feed_config_id}</TableCell>
                      <TableCell align="right">{r.run_skips}</TableCell>
                      <TableCell align="right">{r.dependency_skips}</TableCell>
                      <TableCell align="right">
                        <strong>{r.total}</strong>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>
          </>)}

          {tab === 'reports' && (<>
          <Section
            title="Reports: runs and failures"
            section={sections.report_runs}
            emptyText={`No report was run in the last ${review.period_days} days.`}
            testId="review-report-runs"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Report</TableCell>
                    <TableCell align="right">Runs</TableCell>
                    <TableCell align="right">Failed</TableCell>
                    <TableCell align="right">Average time</TableCell>
                    <TableCell align="right">Longest</TableCell>
                    <TableCell>Last failure</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.report_id}>
                      <TableCell>{r.report}</TableCell>
                      <TableCell align="right">{r.runs}</TableCell>
                      <TableCell align="right">
                        <Chip size="small" label={`${r.failed} (${pct(r.failure_rate)})`}
                              color={r.failed ? 'error' : 'success'} sx={{ height: 20, fontSize: '0.7rem' }} />
                      </TableCell>
                      <TableCell align="right">{secs(r.avg_seconds)}</TableCell>
                      <TableCell align="right">{secs(r.max_seconds)}</TableCell>
                      <TableCell>
                        <Typography variant="caption" color="text.secondary">
                          {r.last_failure ? `${when(r.last_failure_at)}: ${r.last_failure}` : '—'}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>

          <Section
            title="Queries by the engine that answered them"
            section={sections.query_runs_by_engine}
            emptyText={`No query was run in the last ${review.period_days} days.`}
            testId="review-query-engines"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Engine</TableCell>
                    <TableCell align="right">Runs</TableCell>
                    <TableCell align="right">Failed</TableCell>
                    <TableCell align="right">Stopped by a person</TableCell>
                    <TableCell align="right">Average time</TableCell>
                    <TableCell align="right">95 of 100 finish within</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.engine}>
                      <TableCell>{r.engine}</TableCell>
                      <TableCell align="right">{r.runs}</TableCell>
                      <TableCell align="right">{r.failed} ({pct(r.failure_rate)})</TableCell>
                      <TableCell align="right">{r.cancelled}</TableCell>
                      <TableCell align="right">{secs(r.avg_seconds)}</TableCell>
                      <TableCell align="right">{secs(r.p95_seconds)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>
          </>)}

          {tab === 'published_apis' && (
          <Section
            title="Published APIs: calls, errors and speed"
            section={sections.api_calls}
            emptyText={`No published API was called in the last ${review.period_days} days.`}
            testId="review-api-calls"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>API</TableCell>
                    <TableCell align="right">Calls</TableCell>
                    <TableCell align="right">Errors</TableCell>
                    <TableCell align="right">Turned away</TableCell>
                    <TableCell align="right">Average answer</TableCell>
                    <TableCell align="right">Slowest</TableCell>
                    <TableCell>Last call</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={`${r.api_kind}:${r.api_id}`}>
                      <TableCell>{r.api}</TableCell>
                      <TableCell align="right">{r.calls}</TableCell>
                      <TableCell align="right">
                        <Chip size="small"
                              label={`${r.client_errors + r.server_errors} (${pct(r.error_rate)})`}
                              color={r.server_errors ? 'error' : r.client_errors ? 'warning' : 'success'}
                              sx={{ height: 20, fontSize: '0.7rem' }} />
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                          {r.server_errors} our side · {r.client_errors} caller&apos;s side
                        </Typography>
                      </TableCell>
                      <TableCell align="right">{r.refused}</TableCell>
                      <TableCell align="right">{ms(r.avg_ms)}</TableCell>
                      <TableCell align="right">{ms(r.max_ms)}</TableCell>
                      <TableCell><Typography variant="caption">{when(r.last_call)}</Typography></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>
          )}

          {tab === 'platform' && (<>
          <Section
            title="Parts of the platform that went down"
            section={sections.component_downtime}
            emptyText="Nothing went down and every part could be checked in the period."
            testId="review-downtime"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Part</TableCell>
                    <TableCell align="right">Times down</TableCell>
                    <TableCell align="right">Times it could not be checked</TableCell>
                    <TableCell align="right">Pods</TableCell>
                    <TableCell>Last time, and why</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={r.component}>
                      <TableCell>{r.component}</TableCell>
                      <TableCell align="right">{r.times_down}</TableCell>
                      <TableCell align="right">{r.times_not_checkable}</TableCell>
                      <TableCell align="right">{r.pods}</TableCell>
                      <TableCell>
                        <Typography variant="caption" color="text.secondary">
                          {when(r.last_at)}{r.last_reason ? `: ${r.last_reason}` : ''}
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>

          <Section
            title="Alerts raised, by area"
            section={sections.alerts_raised}
            emptyText="No alert was raised in the period."
            testId="review-alerts"
          >
            {rows => (
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Area</TableCell>
                    <TableCell>Alert</TableCell>
                    <TableCell align="right">Raised</TableCell>
                    <TableCell align="right">Still open</TableCell>
                    <TableCell align="right">Highest severity</TableCell>
                    <TableCell>Last raised</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((r: any) => (
                    <TableRow key={`${r.area}:${r.kind}`}>
                      <TableCell>{r.area}</TableCell>
                      <TableCell>{String(r.kind).replace(/_/g, ' ')}</TableCell>
                      <TableCell align="right">{r.raised}</TableCell>
                      <TableCell align="right">
                        <Chip size="small" label={r.still_open} color={r.still_open ? 'error' : 'success'}
                              sx={{ height: 20, fontSize: '0.7rem' }} />
                      </TableCell>
                      <TableCell align="right">{r.highest_severity}</TableCell>
                      <TableCell><Typography variant="caption">{when(r.last_raised)}</Typography></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Section>
          </>)}
        </>
      )}
    </Box>
  );
};

export default ServiceReviewPage;
