/**
 * The API dashboard as its own page (2026-10-23).  The owner: "API dashboard
 * missing" -- it existed, as the "Dashboard" TAB of Published APIs, which
 * nobody looking for a dashboard found.  Same numbers, same component
 * (publishedApis/DashboardTab), now reachable from the menu at /api-dashboard.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Alert, Box, Button, Typography } from '@mui/material';
import api from '../services/api';
import DashboardTab from './publishedApis/DashboardTab';
import type { InventoryAnswer, PublishedApiRow } from './publishedApis/types';

export default function ApiDashboardPage() {
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const [apis, setApis] = useState<PublishedApiRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const r: InventoryAnswer = await (api as any).listPublishedApis({ page_size: 500 });
      setApis(Array.isArray(r?.items) ? r.items : []);
    } catch (e: any) {
      setApis([]);
      setError(e?.message || 'The list of published APIs could not be read.');
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <Box sx={{ p: { xs: 2, md: 3 } }} data-testid="api-dashboard-page">
      <Typography variant="h5" sx={{ mb: 0.5 }}>API Dashboard</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Calls, errors, response times and consumers of every published API.
      </Typography>
      {error && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="api-dashboard-inventory-error"
               action={<Button color="inherit" size="small" onClick={load}>Retry</Button>}>
          {error} The numbers below are still shown; the API picker may be empty.
        </Alert>
      )}
      {apis !== null && (
        <DashboardTab apis={apis} initialKind={params.get('kind')} initialApi={params.get('api')} />
      )}
    </Box>
  );
}
