import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Autocomplete, FormControl, InputLabel, Select, MenuItem,
  RadioGroup, Radio, FormLabel, FormControlLabel, Divider, Tabs, Tab,
} from '@mui/material';
import {
  Publish as PublishIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  ContentCopy as CopyIcon, Edit as EditIcon, Visibility as ViewIcon,
  BarChart as UsageIcon, PlayArrow as TestIcon, VpnKey as VpnKeyIcon,
  Schema as SchemaIcon, Timeline as LifecycleIcon, Download as DownloadIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { safeFetch } from '../services/api';
import ListPager, { clientPage } from './common/ListPager';
import { openDownload, resolveApiBaseUrl, resolvePublishedApiBaseUrl } from '../services/api/core';
import { useAuth } from '../context/AuthContext';
import { isAdminLike } from '../utils/reportLifecycle';
// 2026-10-17 -- ONE page for every published API (design §3.9): the inventory
// (this table, re-based on /api/published-apis), the dashboard, consumers &
// keys (the API Keys page folded in), alerts.
import DashboardTab from './publishedApis/DashboardTab';
import AlertsTab from './publishedApis/AlertsTab';
import ConsumersTab from './publishedApis/ConsumersTab';
import LifecycleDialog from './publishedApis/LifecycleDialog';
import { apiRowKey, LIFECYCLE_COLOR, type InventoryAnswer, type PublishedApiRow } from './publishedApis/types';
import {
  distinctValues as fetchDistinctValues,
  previewColumns as fetchPreviewColumns,
} from './common/sqlPreviewApi';
// BF-488 — surface WHERE-clause editing in the Edit dialog so the
// publisher can change Static/Dynamic columns + values after publishing
// without having to delete + republish.  Backend's UpdateViewRequest
// already accepts ``where_clauses`` (re-applied to query_config on PUT).
import {
  WhereClausesEditor,
  type WhereClauseRow,
  type WhereColumnOption,
} from './common/WhereClausesEditor';
import RowActions from './common/RowActions';
import PublishViewDialog from './PublishViewDialog';
import FederationViewEditorDialog, {
  EMPTY_VIEW, type FederationView, type FederationConnection,
} from './federation/FederationViewEditorDialog';

interface PublishedView {
  /** another publisher's view, as a catalog entry (non-admin): its owner-only
   *  actions are refused server-side, so they are not offered -- 2026-09-25 */
  _redacted?: boolean;
  /** why it can no longer run (its source was deleted), else null -- 2026-09-25 */
  source_missing?: string | null;
  id: number;
  slug: string;
  name: string;
  description: string | null;
  query_id: number;
  connection_id: number | null;
  allowed_filters: string[];
  allowed_ad_groups: string[];
  default_limit: number;
  max_limit: number;
  is_active: boolean;
  cache_ttl_seconds: number;
  param_definitions?: any[];   // Phase 86: runtime parameter definitions
  // Phase 133-J — publisher-time credential routing.  See PublishViewDialog.
  credential_mode?: 'consumer' | 'publisher' | 'shared';
  execution_connection_id?: number | null;
  // 2026-10-24 -- data entitlement for API KEYS on this view (admin decides).
  entitlement_mode?: 'off' | 'apply' | null;
  /** 2026-10-25 -- what is SET on the API (null = it follows the config) */
  entitlement_mode_stored?: 'off' | 'apply' | null;
  entitlement_mode_source?: 'api' | 'config';
  entitlement_mode_default?: 'off' | 'apply';
  publisher_username?: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  // 2026-09-27 -- the latest recorded SCHEMA version (null = none recorded),
  // when it was recorded, and the last diff (null on the baseline)
  schema_version?: number | null;
  schema_changed_at?: string | null;
  schema_changes?: SchemaChanges | null;
}

interface SchemaColumn { name: string; type: string }
interface SchemaChanges {
  added: SchemaColumn[];
  removed: SchemaColumn[];
  retyped: { name: string; from: string; to: string }[];
}
interface SchemaVersion {
  id: number;
  view_id: number;
  version_no: number;
  columns: SchemaColumn[];
  changes: SchemaChanges | null;
  reason: string;
  changed_by: string | null;
  notified: { emails?: string[]; unrouted?: string[]; usernames?: string[]; sent?: boolean; reason?: string } | null;
  created_at: string | null;
}

/** one line per change, in the order a reader scans them */
export function describeSchemaChanges(c?: SchemaChanges | null): string[] {
  if (!c) return [];
  return [
    ...(c.added || []).map(x => `added ${x.name} (${x.type})`),
    ...(c.removed || []).map(x => `removed ${x.name} (${x.type})`),
    ...(c.retyped || []).map(x => `re-typed ${x.name}: ${x.from} → ${x.to}`),
  ];
}

interface UsageLog {
  id: number;
  api_key_id: number | null;
  view_id: number;
  response_rows: number | null;
  response_ms: number | null;
  status_code: number | null;
  client_ip: string | null;
  created_at: string | null;
}

const NOT_YOURS = 'Only its publisher or an admin can do this';

type TabName = 'inventory' | 'dashboard' | 'consumers' | 'alerts';
const TAB_NAMES: TabName[] = ['inventory', 'dashboard', 'consumers', 'alerts'];

/** ``?tab=`` without a Router dependency (the page is also rendered bare). */
const readTab = (): TabName => {
  try {
    const t = new URLSearchParams(window.location.search).get('tab') as TabName | null;
    return t && TAB_NAMES.includes(t) ? t : 'inventory';
  } catch { return 'inventory'; }
};
const readParam = (name: string): string | null => {
  try { return new URLSearchParams(window.location.search).get(name); } catch { return null; }
};

/** The signed-in user when an AuthProvider is above us; null otherwise (tests, storybook). */
const useOptionalUser = (): any => {
  try { return useAuth().user; } catch { return null; }
};

/** The inventory's status words: lifecycle + health, never a bare flag. */
export function StatusCell({ row, fallbackActive }: { row?: PublishedApiRow; fallbackActive: boolean }) {
  if (!row) {
    return <Chip label={fallbackActive ? 'Active' : 'Inactive'} size="small" color={fallbackActive ? 'success' : 'default'} />;
  }
  const lc = row.lifecycle || ({ status: fallbackActive ? 'active' : 'retired' } as any);
  const health = row.health || { state: 'unknown', reasons: ['health not read'] };
  const lcTip = [
    lc.sunset_at ? `sunset ${new Date(lc.sunset_at).toLocaleString()}` : '',
    lc.successor ? `use '${lc.successor}'` : '',
    lc.deprecation_note || '',
    lc.changed_by ? `changed by ${lc.changed_by}` : '',
  ].filter(Boolean).join(' · ');
  return (
    <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap" useFlexGap>
      <Tooltip title={lcTip}>
        <Chip label={lc.status} size="small" color={LIFECYCLE_COLOR[lc.status] || 'default'} data-testid="pv-lifecycle" />
      </Tooltip>
      {health.state === 'broken' && (
        <Tooltip title={(health.reasons || []).join('; ')}>
          <Chip label="BROKEN" size="small" color="error" variant="outlined" data-testid="pv-health-broken" />
        </Tooltip>
      )}
      {health.state === 'unknown' && (
        <Tooltip title={(health.reasons || []).join('; ') || 'a dependency could not be read'}>
          <Chip label="UNKNOWN" size="small" color="default" variant="outlined" data-testid="pv-health-unknown" />
        </Tooltip>
      )}
    </Stack>
  );
}

const lastCallWords = (row?: PublishedApiRow): string => {
  if (!row) return '—';
  const lc = row.last_call || {};
  if (lc.at) return new Date(lc.at).toLocaleString();
  if (lc.state === 'unknown') return `unknown: ${lc.reason || 'not read'}`;
  return 'never';
};

const PublishedViewsPage = () => {
  const [views, setViews] = useState<PublishedView[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const user = useOptionalUser();
  const isAdmin = isAdminLike(user);
  // 2026-10-23 -- the owner: build the union of two connections ON this
  // screen.  The ONE federation editor (a cross-source query), then the ONE
  // publish dialog over the view it saved.  Authoring is admin / analyst,
  // as on the Federation Views page.
  const canBuildCrossSource = isAdmin || String((user as any)?.role || '') === 'analyst';
  const [xsConnections, setXsConnections] = useState<FederationConnection[]>([]);
  const [xsEditorOpen, setXsEditorOpen] = useState(false);
  const [xsPublish, setXsPublish] = useState<FederationView | null>(null);
  const openCrossSourceEditor = async () => {
    try {
      setXsConnections(await api.listConnections());
      setXsEditorOpen(true);
    } catch (e: any) {
      setError(`Connections could not be read: ${e?.message || e}`);
    }
  };

  // ── the tabs (?tab=) ──────────────────────────────────────────────────
  const [tab, setTab] = useState<TabName>(readTab);
  const changeTab = (t: TabName) => {
    setTab(t);
    try {
      const u = new URL(window.location.href);
      u.searchParams.set('tab', t);
      window.history.replaceState({}, '', u.toString());
    } catch { /* no history in this host */ }
  };

  // ── the inventory (GET /api/published-apis) ───────────────────────────
  // Unknown != empty: when it cannot be read the columns say so and the
  // management table still works from its own route.
  const [inventory, setInventory] = useState<PublishedApiRow[]>([]);
  const [inventoryError, setInventoryError] = useState<string | null>(null);
  const [inventoryMeta, setInventoryMeta] = useState<Partial<InventoryAnswer> | null>(null);
  const [lifecycleOf, setLifecycleOf] = useState<PublishedApiRow | null>(null);
  const [lifecycleNotice, setLifecycleNotice] = useState<string | null>(null);

  const loadInventory = useCallback(async () => {
    const fn = (api as any).listPublishedApis;
    if (typeof fn !== 'function') {
      setInventoryError('the inventory service is not available in this build');
      return;
    }
    try {
      const r: InventoryAnswer = await fn({ page_size: 500 });
      setInventory(Array.isArray(r?.items) ? r.items : []);
      setInventoryMeta({ generated_at: r?.generated_at, problems: r?.problems, numbers_error: r?.numbers_error });
      setInventoryError(null);
    } catch (err: any) {
      setInventory([]);
      setInventoryError(err?.message || 'the inventory could not be read');
    }
  }, []);

  const inventoryByKey = React.useMemo(() => {
    const m: Record<string, PublishedApiRow> = {};
    inventory.forEach(r => { m[apiRowKey(r.api_kind, r.key)] = r; });
    return m;
  }, [inventory]);
  const reportApis = React.useMemo(() => inventory.filter(r => r.api_kind === 'published_report'), [inventory]);

  const consumersCell = (row?: PublishedApiRow) => {
    if (!row || row.is_redacted) return <Typography variant="caption" color="text.secondary">—</Typography>;
    const active = (row.consumers || []).filter(c => c.is_active);
    // each consumer with the limit it is HELD to (the operator's cap applied), never only the declared one
    const names = active.map(c => {
      const who = c.consumer ? `${c.name} (${c.consumer})` : c.name || c.id;
      const lim = c.effective_rate_limit
        ? ` — ${c.effective_rate_limit}${c.rate_limit_capped ? ` (declared ${c.rate_limit}, capped)` : ''}`
        : '';
      return who + lim;
    }).join(', ');
    return (
      <Tooltip title={names || 'nobody may call this API'}>
        <Chip size="small" label={active.length} variant="outlined" data-testid="pv-consumers"
              color={active.length ? 'default' : 'warning'} />
      </Tooltip>
    );
  };

  const exportCsv = () => {
    openDownload('/api/published-apis?format=csv&page_size=10000').catch((e: any) => setError(e?.message || 'export failed'));
  };

  // Edit dialog
  const [editView, setEditView] = useState<PublishedView | null>(null);
  const [editSlug, setEditSlug] = useState('');
  const [editName, setEditName] = useState('');
  const [editError, setEditError] = useState<string | null>(null);  // BF-564
  const [editDesc, setEditDesc] = useState('');
  const [editFilters, setEditFilters] = useState<string[]>([]);
  // Phase 133-I round 21 — column options for the Allowed Filters
  // Autocomplete in the edit dialog.  Was hardcoded to ``[]`` — user
  // had to type column names from memory.  Now fetched from
  // /api/sql/preview-columns when the dialog opens.
  const [editColumnOptions, setEditColumnOptions] = useState<string[]>([]);
  const [editDefaultLimit, setEditDefaultLimit] = useState(1000);
  const [editMaxLimit, setEditMaxLimit] = useState(50000);
  const [editCacheTtl, setEditCacheTtl] = useState(300);
  const [editAdGroupsInput, setEditAdGroupsInput] = useState('');
  // Phase 133-J — edit-time credential routing.  publisher_username is
  // immutable (backend strips it from update payload) but the publisher
  // can switch credential_mode and re-point execution_connection_id
  // after the fact (e.g. flip from 'consumer' to 'publisher' once they
  // realise curl callers are stuck on the password prompt).
  const [editCredentialMode, setEditCredentialMode] =
    useState<'consumer' | 'publisher' | 'shared'>('consumer');
  const [editExecConnId, setEditExecConnId] = useState<number | ''>('');
  // 2026-10-24 -- whether API keys read only their entitled values here.
  const [editEntitlementMode, setEditEntitlementMode] = useState<'default' | 'off' | 'apply'>('default');
  const [editConnOptions, setEditConnOptions] = useState<
    { id: number; name: string; connection_type: string; is_shared?: boolean }[]
  >([]);
  // BF-488 — WHERE-clause editing.  Seeded from
  // ``pv.query_config._where_clauses_mapping`` (Phase 132.37 sentinel
  // key).  Empty list = no Static/Dynamic overlay (legacy PVs published
  // before WHERE mapping existed will start with [] and the publisher
  // can add rows).
  const [editWhereClauses, setEditWhereClauses] = useState<WhereClauseRow[]>([]);
  const [editColumnObjects, setEditColumnObjects] = useState<WhereColumnOption[]>([]);

  // Usage dialog
  const [usageView, setUsageView] = useState<PublishedView | null>(null);
  const [usageLogs, setUsageLogs] = useState<UsageLog[]>([]);
  const [usageLoading, setUsageLoading] = useState(false);

  // 2026-09-27 -- schema history dialog
  const [schemaView, setSchemaView] = useState<PublishedView | null>(null);
  const [schemaVersions, setSchemaVersions] = useState<SchemaVersion[]>([]);
  const [schemaLoading, setSchemaLoading] = useState(false);
  const [schemaError, setSchemaError] = useState('');

  // Phase 85C-3: Test dialog state
  const [testView, setTestView] = useState<PublishedView | null>(null);
  const [testFilters, setTestFilters] = useState<Record<string, string>>({});
  const [testParamValues, setTestParamValues] = useState<Record<string, string>>({});
  const [testLoading, setTestLoading] = useState(false);
  const [testError, setTestError] = useState('');
  const [testRows, setTestRows] = useState<any[]>([]);
  const [testColumns, setTestColumns] = useState<string[]>([]);
  // Phase 133-H round 11 — table hint + lazy distinct-values cache
  // for the Test dialog so Runtime Parameter + Filter inputs show
  // searchable dropdowns of cached schema values instead of plain
  // textboxes.
  const [testTableHint, setTestTableHint] = useState<string | null>(null);
  const [testValueOptions, setTestValueOptions] = useState<Record<string, string[]>>({});

  // API Key request dialog
  const [reqKeyView, setReqKeyView] = useState<PublishedView | null>(null);
  const [reqKeyName, setReqKeyName] = useState('');
  const [reqJustification, setReqJustification] = useState('');
  const [reqRateLimit, setReqRateLimit] = useState('');
  const [reqExpiresHours, setReqExpiresHours] = useState('');
  const [reqSubmitting, setReqSubmitting] = useState(false);
  const [reqSuccess, setReqSuccess] = useState('');

  // My Requests
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [myReqLoading, setMyReqLoading] = useState(false);
  const [revealedKeys, setRevealedKeys] = useState<Record<number, string>>({});

  // Pages (2026-10-13, "pagination in all grids"): the views, my key
  // requests, a view's usage log and its schema history all grow with use.
  const [viewPage, setViewPage] = useState(1);
  const [viewPageSize, setViewPageSize] = useState(50);
  const [myReqPage, setMyReqPage] = useState(1);
  const [myReqPageSize, setMyReqPageSize] = useState(50);
  const [usagePage, setUsagePage] = useState(1);
  const [usagePageSize, setUsagePageSize] = useState(50);
  const [schemaPage, setSchemaPage] = useState(1);
  const [schemaPageSize, setSchemaPageSize] = useState(50);
  // A different view's usage log or schema history starts on its first page.
  useEffect(() => { setUsagePage(1); }, [usageView]);
  useEffect(() => { setSchemaPage(1); }, [schemaView]);

  const loadMyRequests = useCallback(async () => {
    setMyReqLoading(true);
    try {
      const data = await api.listApiKeyRequests();
      setMyRequests(Array.isArray(data) ? data : []);
    } catch {
      setMyRequests([]);
    } finally {
      setMyReqLoading(false);
    }
  }, []);

  const handleRevealKey = async (apiKeyId: number) => {
    try {
      const result = await api.revealApiKey(apiKeyId);
      setRevealedKeys(prev => ({ ...prev, [apiKeyId]: result.raw_key }));
    } catch (err: any) {
      setError(err.message || 'Failed to reveal key');
    }
  };

  const loadViews = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listPublishedViews();
      setViews(Array.isArray(data) ? data : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadViews(); loadMyRequests(); loadInventory(); }, [loadViews, loadMyRequests, loadInventory]);

  const reloadAll = () => { loadViews(); loadInventory(); };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Deactivate this published view?')) return;
    try {
      await api.deletePublishedView(id);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleRepublish = async (id: number) => {
    try {
      await api.republishView(id);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const openEdit = (v: PublishedView) => {
    setEditView(v);
    setEditSlug(v.slug);
    setEditName(v.name);
    setEditDesc(v.description || '');
    setEditFilters(v.allowed_filters || []);
    setEditDefaultLimit(v.default_limit);
    setEditMaxLimit(v.max_limit);
    setEditCacheTtl(v.cache_ttl_seconds);
    setEditAdGroupsInput((v.allowed_ad_groups || []).join(', '));
    // Phase 133-J — seed credential mode + execution connection from the
    // PV record.  Default to 'consumer' for legacy rows that pre-date the
    // column (matches backend default).
    setEditCredentialMode((v.credential_mode as any) || 'consumer');
    setEditExecConnId(v.execution_connection_id ?? '');
    setEditEntitlementMode(v.entitlement_mode_stored === 'apply' || v.entitlement_mode_stored === 'off'
      ? v.entitlement_mode_stored : 'default');
    // BF-488 — seed WHERE-clause rows from the publisher's saved
    // _where_clauses_mapping (Phase 132.37 sentinel key on query_config).
    // Mirrors the FeedConfigsPage edit pattern so the same persisted
    // contract works on both surfaces.
    const _qcEdit = (v as any).query_config || {};
    const _wcm = Array.isArray(_qcEdit._where_clauses_mapping)
      ? _qcEdit._where_clauses_mapping
      : [];
    setEditWhereClauses(
      _wcm.map((r: any) => ({
        column: r?.column || '',
        operator: r?.operator || 'eq',
        value: r?.value ?? '',
        mode: (r?.mode === 'static' ? 'static' : 'dynamic') as 'static' | 'dynamic',
      })),
    );
    // Fetch connection list for the picker; silent failure → empty picker.
    api.listConnections(true).then((rows: any) => {
      const list = Array.isArray(rows) ? rows : [];
      setEditConnOptions(list.map((c: any) => ({
        id: c.id,
        name: c.name,
        connection_type: c.connection_type,
        is_shared: !!c.is_shared,
      })));
    }).catch(() => setEditConnOptions([]));
    // Phase 133-I round 21 — fetch columns from the PV's underlying
    // SQL so the Allowed Filters Autocomplete has real options instead
    // of an empty list.  Best-effort: connection_id missing → empty
    // dropdown (freeSolo lets user still type).
    // Phase 133-I round 30 — fetch columns for BOTH saved_query AND
    // sql_file PVs.  Round 21 covered only query_id; sql_file PVs
    // were left with an empty dropdown.
    setEditColumnOptions([]);
    // BF-491 follow-up — also reset the WhereColumnOption[] used by the
    // WHERE-clause editor.  Without this, switching from PV-A to PV-B
    // briefly shows PV-A's column dropdown until PV-B's
    // fetchPreviewColumns completes (~200-500ms).
    setEditColumnObjects([]);
    (async () => {
      try {
        // BF-495 (2026-05-28) — populate the column dropdown for ALL
        // source types, not just saved_query / sql_file.  Federation
        // PVs source columns from the FV's output_columns + schema_cache;
        // business_report PVs have no SQL surface so they stay empty
        // (user types from memory, freeSolo on the column field).
        const vAny = v as any;
        const qc = vAny.query_config || {};
        const srcType = (qc.source_type || vAny.source_type || 'saved_query').toLowerCase();
        let cols: string[] = [];
        let colObjs: WhereColumnOption[] = [];

        if (srcType === 'federation' && (qc.federation_view_id || vAny.federation_view_id)) {
          // Federation PV — fetch the FV record so we get its declared
          // output_columns (publisher's explicit column list) AND
          // schema_cache (post-materialize column metadata).  Prefer
          // schema_cache for richer type info.
          const fvId = qc.federation_view_id || vAny.federation_view_id;
          try {
            const fv: any = await api.getFederationView(Number(fvId));
            const sc: any[] = Array.isArray(fv?.schema_cache) ? fv.schema_cache : [];
            const oc: string[] = Array.isArray(fv?.output_columns) ? fv.output_columns : [];
            const seen = new Set<string>();
            sc.forEach((c: any) => {
              const nm = typeof c === 'string' ? c : (c?.name || '');
              if (!nm || seen.has(nm)) return;
              seen.add(nm);
              cols.push(nm);
              colObjs.push({
                name: nm,
                type: typeof c === 'string' ? undefined : (c?.type || undefined),
                tableSource: `federation:${fv?.name || fvId}`,
              });
            });
            oc.forEach((nm: string) => {
              if (!nm || seen.has(nm)) return;
              seen.add(nm);
              cols.push(nm);
              colObjs.push({ name: nm, tableSource: `federation:${fv?.name || fvId}` });
            });
          } catch { /* best-effort — empty dropdown, user types */ }
        } else if (v.connection_id) {
          // saved_query / sql_file / business_report-with-raw_sql paths.
          let sqlBlob = '';
          if (v.query_id) {
            const sq: any = await api.getSavedQuery(String(v.query_id));
            const sqc = sq?.query_config || {};
            sqlBlob = [sqc.raw_sql, sqc.custom_sql, sqc.secondary_raw_sql]
              .filter((s: any) => typeof s === 'string' && s.trim())
              .join('\n');
          } else {
            sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
              .filter((s: any) => typeof s === 'string' && s.trim())
              .join('\n');
          }
          if (sqlBlob) {
            const pc = await fetchPreviewColumns(sqlBlob, 'duckdb', v.connection_id);
            const seen = new Set<string>();
            Object.entries(pc?.columns_by_table || {}).forEach(([tbl, arr]) => {
              (arr as any[]).forEach((c: any) => {
                if (!c?.name) return;
                cols.push(c.name);
                if (seen.has(c.name)) return;
                seen.add(c.name);
                colObjs.push({
                  name: c.name,
                  type: c.type || undefined,
                  isPartition: !!c.is_partition,
                  tableSource: tbl,
                });
              });
            });
          }
        }

        if (cols.length > 0) setEditColumnOptions(Array.from(new Set(cols)).sort());
        if (colObjs.length > 0) setEditColumnObjects(colObjs);
      } catch { /* best-effort */ }
    })();
  };

  const handleSaveEdit = async () => {
    if (!editView) return;
    // BF-564 (2026-05-29): client-side required-field validation before
    // PUT so the user gets an actionable inline error instead of an
    // opaque backend 400.
    if (!editName.trim()) {
      setEditError('Name is required.');
      return;
    }
    if (!editSlug.trim()) {
      setEditError('Slug is required.');
      return;
    }
    if (!/^[a-z0-9][a-z0-9_-]*$/i.test(editSlug.trim())) {
      setEditError(
        'Slug must contain only letters, numbers, hyphens, and underscores ' +
        '(and start with a letter or number).'
      );
      return;
    }
    try {
      const allowed_ad_groups = editAdGroupsInput
        .split(',')
        .map(g => g.trim())
        .filter(g => g.length > 0);
      await api.updatePublishedView(editView.id, {
        slug: editSlug,
        name: editName,
        description: editDesc || null,
        allowed_filters: editFilters,
        default_limit: editDefaultLimit,
        max_limit: editMaxLimit,
        cache_ttl_seconds: editCacheTtl,
        allowed_ad_groups,
        // Phase 133-J — edit-time routing changes.  publisher_username
        // is server-side immutable; backend strips it from the payload.
        credential_mode: editCredentialMode,
        execution_connection_id: editExecConnId === '' ? null : Number(editExecConnId),
        // 2026-10-24 -- only an admin may change it; an owner sends the
        // stored value back, which the server accepts as no change.
        entitlement_mode: editEntitlementMode,
        // BF-488 — WHERE-clause mapping re-applied to query_config server-side.
        // Empty list clears all Static/Dynamic overlays.
        where_clauses: editWhereClauses,
      });
      setEditView(null);
      loadViews();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const openUsage = async (v: PublishedView) => {
    setUsageView(v);
    setUsageLoading(true);
    try {
      const logs = await api.getPublishedViewUsage(v.id);
      setUsageLogs(Array.isArray(logs) ? logs : []);
    } catch {
      setUsageLogs([]);
    } finally {
      setUsageLoading(false);
    }
  };

  const openSchema = async (v: PublishedView) => {
    setSchemaView(v);
    setSchemaLoading(true);
    setSchemaError('');
    try {
      const res: any = await api.getPublishedViewSchemaVersions(v.id);
      setSchemaVersions(Array.isArray(res?.versions) ? res.versions : []);
    } catch (err: any) {
      // "could not read" and "none recorded" lead to opposite investigations
      setSchemaVersions([]);
      setSchemaError(err?.message || 'The schema history could not be loaded');
    } finally {
      setSchemaLoading(false);
    }
  };

  const openRequestKey = (v: PublishedView) => {
    setReqKeyView(v);
    setReqKeyName(`${v.slug}-key`);
    setReqJustification('');
    setReqRateLimit('');
    setReqExpiresHours('');
    setReqSuccess('');
  };

  const handleRequestKey = async () => {
    if (!reqKeyView || !reqKeyName.trim()) return;
    setReqSubmitting(true);
    try {
      const result = await api.requestApiKey({
        key_name: reqKeyName.trim(),
        scoped_view_ids: [reqKeyView.id],
        rate_limit: reqRateLimit.trim() || undefined,
        expires_hours: reqExpiresHours ? Number(reqExpiresHours) : undefined,
        justification: reqJustification.trim() || undefined,
      });
      if (result.auto_approved && result.raw_key) {
        setReqSuccess(`Key created: ${result.raw_key}`);
      } else {
        setReqSuccess('Request submitted! You will be notified when an admin reviews it.');
      }
      loadMyRequests();
    } catch (err: any) {
      setError(err.message || 'Failed to submit request');
      setReqKeyView(null);
    } finally {
      setReqSubmitting(false);
    }
  };

  // BF-124: Resolve view IDs to names for display
  const viewNameById = React.useMemo(() => {
    const map: Record<number, string> = {};
    views.forEach(v => { map[v.id] = v.name || v.slug; });
    return map;
  }, [views]);

  const resolveViewNames = (ids: number[]) =>
    ids.map(id => viewNameById[id] || `#${id}`).join(', ');

  // Use dedicated Published API URL if configured, otherwise fall back to main API
  const pubBase = resolvePublishedApiBaseUrl() || resolveApiBaseUrl() || window.location.origin;

  const copyEndpoint = (slug: string) => {
    const url = `${pubBase}/api/v1/views/${slug}/data`;
    navigator.clipboard.writeText(url);
  };

  // Phase 85C-3: Open test dialog
  const openTestDialog = async (v: PublishedView) => {
    setTestView(v);
    const initFilters: Record<string, string> = {};
    (v.allowed_filters || []).forEach(f => { initFilters[f] = ''; });
    setTestFilters(initFilters);
    // Phase 86: initialize param values from defaults
    const initParams: Record<string, string> = {};
    (v.param_definitions || []).forEach((p: any) => {
      initParams[p.name] = p.default != null ? String(p.default) : '';
    });
    setTestParamValues(initParams);
    setTestRows([]);
    setTestColumns([]);
    setTestError('');
    // Phase 133-H round 11 — resolve a table hint so the lazy
    // distinct-values lookup can target the right warehouse table.
    // Fetches the saved query (best-effort) to read the first FROM
    // target out of files[] or raw_sql.
    setTestTableHint(null);
    setTestValueOptions({});
    // Phase 133-I round 31 — also handle sql_file PVs (no query_id).
    // Use the PV's frozen query_config snapshot.  Same fallback chain
    // round 30's Edit dialog uses.
    try {
      let qc: any = null;
      if (v.query_id) {
        const sq: any = await api.getSavedQuery(String(v.query_id));
        qc = sq?.query_config || {};
      } else {
        qc = (v as any).query_config || {};
      }
      if (qc) {
        const files: any[] = qc.files || [];
        let table: string | null = null;
        for (const f of files) {
          const p = typeof f === 'string' ? f : (f?.path || '');
          if (p.startsWith('__registered__:')) { table = p.slice(15); break; }
          if (p.startsWith('__iceberg__:'))    { table = p.slice(12); break; }
        }
        if (!table) {
          const sqlBlob = [qc.raw_sql, qc.custom_sql, qc.secondary_raw_sql]
            .filter((s: any) => typeof s === 'string' && s.trim())
            .join('\n');
          const m = sqlBlob.match(
            /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
          );
          if (m) table = m[1].replace(/[\s"`\[\]]/g, '');
        }
        if (table) setTestTableHint(table);
      }
    } catch { /* best-effort */ }
  };

  // Phase 133-H round 11 — lazy distinct-values fetcher for the test
  // dialog's Runtime Parameters + Filter inputs.  Same /api/sql/distinct-values
  // endpoint the publish editor uses; caches per (connection, table, column)
  // for 5 minutes on the backend.
  const fetchTestValues = useCallback(async (column: string) => {
    if (!testView?.connection_id || !testTableHint || !column) return;
    const colKey = column.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(testValueOptions, colKey)) return;
    setTestValueOptions(prev => ({ ...prev, [colKey]: [] }));  // sentinel
    try {
      const res = await fetchDistinctValues(
        Number(testView.connection_id), testTableHint, column,
      );
      const vals = (res?.values || []).map(String);
      if (vals.length > 0) {
        setTestValueOptions(prev => ({ ...prev, [colKey]: vals }));
      }
    } catch { /* best-effort */ }
  }, [testView?.connection_id, testTableHint, testValueOptions]);

  // Auto-prime values when the dialog opens.
  useEffect(() => {
    if (!testView) return;
    (testView.allowed_filters || []).forEach(c => fetchTestValues(c));
    (testView.param_definitions || []).forEach((p: any) => p?.name && fetchTestValues(p.name));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testView, testTableHint]);

  // Phase 85C-3: Send test request using the published view's data endpoint
  const handleTestRequest = async () => {
    if (!testView) return;
    setTestLoading(true);
    setTestError('');
    setTestRows([]);
    setTestColumns([]);
    try {
      // Build query string from non-empty filters.
      // Phase 132.36 — emit bare-form ?name=value where the name doesn't
      // collide with a framework-reserved key; bracketed form only for
      // reserved-name collisions.
      const RESERVED = new Set([
        'limit', 'offset', 'sort', 'columns', 'format', 'cache',
        'snapshot_id', 'as_of_timestamp', 'engine', 'filter',
      ]);
      const params = new URLSearchParams({ limit: '20', format: 'json' });
      Object.entries(testFilters).forEach(([col, val]) => {
        if (val.trim()) {
          // Explicit filter.col= form for op:value values; bare for scalars.
          if (/^(eq|ne|gt|gte|lt|lte|in|not_in|contains|between):/.test(val)) {
            params.set(`filter.${col}`, val.trim());
          } else {
            params.set(RESERVED.has(col) ? `filter.${col}` : col, val.trim());
          }
        }
      });
      Object.entries(testParamValues).forEach(([name, val]) => {
        if (val.trim()) {
          params.set(RESERVED.has(name) ? `param[${name}]` : name, val.trim());
        }
      });
      // Call the Published API endpoint — use dedicated pod URL if configured
      const _pub = resolvePublishedApiBaseUrl();
      const testUrl = _pub
        ? `${_pub}/api/v1/views/${testView.slug}/data?${params.toString()}`
        : `/api/v1/views/${testView.slug}/data?${params.toString()}`;
      const result = await safeFetch(testUrl);
      // Phase 131 deep-dive #9: defensive normalisation.  If API returns
      // `{data: null}` (legacy / error path), prior code did
      // `Object.keys(null)` → TypeError.  Now coerce to [] explicitly.
      const rawRows = result?.rows ?? result?.data ?? (Array.isArray(result) ? result : null);
      const rows = Array.isArray(rawRows) ? rawRows : [];
      const cols = Array.isArray(result?.columns)
        ? result.columns
        : (rows.length > 0 && rows[0] && typeof rows[0] === 'object'
            ? Object.keys(rows[0])
            : []);
      setTestRows(rows.slice(0, 20));
      setTestColumns(cols);
    } catch (e: any) {
      setTestError(e.message || 'Request failed');
    } finally {
      setTestLoading(false);
    }
  };

  const shownViews = clientPage(views, viewPage, viewPageSize);
  const shownMyRequests = clientPage(myRequests, myReqPage, myReqPageSize);
  const shownUsage = clientPage(usageLogs, usagePage, usagePageSize);
  const shownSchema = clientPage(schemaVersions, schemaPage, schemaPageSize);

  const inventoryApis = inventory;

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        <Typography variant="h5" fontWeight={600}>Published APIs</Typography>
        <Stack direction="row" spacing={1}>
          {tab === 'inventory' && (
            <Button startIcon={<DownloadIcon />} onClick={exportCsv} size="small" data-testid="pv-export-csv">Export CSV</Button>
          )}
          {canBuildCrossSource && (
            <Button variant="outlined" size="small" data-testid="pv-new-cross-source"
                    onClick={openCrossSourceEditor}>
              New cross-source API
            </Button>
          )}
          <Button startIcon={<RefreshIcon />} onClick={reloadAll} size="small">Refresh</Button>
        </Stack>
      </Box>
      <Tabs value={tab} onChange={(_, t) => changeTab(t)} sx={{ mb: 2 }} aria-label="Published APIs sections">
        <Tab label="Inventory" value="inventory" data-testid="tab-inventory" />
        <Tab label="Dashboard" value="dashboard" data-testid="tab-dashboard" />
        {isAdmin && <Tab label="Consumers & keys" value="consumers" data-testid="tab-consumers" />}
        <Tab label="Alerts" value="alerts" data-testid="tab-alerts" />
      </Tabs>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {lifecycleNotice && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setLifecycleNotice(null)} data-testid="lifecycle-notice">{lifecycleNotice}</Alert>}

      {tab === 'dashboard' && (
        <DashboardTab apis={inventoryApis} initialKind={readParam('kind')} initialApi={readParam('api')} />
      )}
      {tab === 'consumers' && isAdmin && <ConsumersTab apis={inventoryApis} />}
      {tab === 'alerts' && <AlertsTab apis={inventoryApis} canEdit={isAdmin} />}

      {tab === 'inventory' && inventoryError && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="pv-inventory-error">
          The inventory could not be read ({inventoryError}); status, consumers and call numbers are not shown.
        </Alert>
      )}
      {tab === 'inventory' && !inventoryError && inventoryMeta?.numbers_error && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="pv-numbers-error">
          The call numbers could not be read: {inventoryMeta.numbers_error}
        </Alert>
      )}
      {tab === 'inventory' && !inventoryError && (inventoryMeta?.problems || []).length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }}>Some lookups failed: {(inventoryMeta?.problems || []).join('; ')}</Alert>
      )}

      {tab === 'inventory' && (loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : views.length === 0 && reportApis.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">
            No published views yet. Save a query and publish it as an API to get started.
          </Typography>
        </Paper>
      ) : (
        <Paper variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Name / key</strong></TableCell>
                <TableCell><strong>Owner · source</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
                <TableCell><strong>Consumers</strong></TableCell>
                <TableCell><strong>Filters · access</strong></TableCell>
                <TableCell><strong>Limits · cache</strong></TableCell>
                <TableCell><strong>Last call</strong></TableCell>
                <TableCell align="right"><strong>Calls 7d</strong></TableCell>
                <TableCell align="right"><strong>Actions</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {shownViews.rows.map(v => {
                const inv = inventoryByKey[apiRowKey('published_view', v.slug)];
                return (
                <TableRow key={v.id} sx={{ opacity: v.is_active ? 1 : 0.5 }}>
                  <TableCell>
                    <Stack direction="row" spacing={0.5} alignItems="center">
                      <Chip size="small" label="view" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                      <Typography variant="body2" fontWeight={500}>{v.name}</Typography>
                    </Stack>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <code style={{ fontSize: 12 }}>{v.slug}</code>
                      <Tooltip title="Copy API endpoint">
                        <IconButton size="small" onClick={() => copyEndpoint(v.slug)}>
                          <CopyIcon sx={{ fontSize: 14 }} />
                        </IconButton>
                      </Tooltip>
                    </Box>
                    {/* 2026-09-25: the thing this API serves was deleted --
                        said here, not discovered by a consumer's failing call */}
                    {v.source_missing && (
                      <Chip size="small" color="warning" variant="outlined" data-testid="pv-source-missing"
                            label={`Cannot run: ${v.source_missing}`}
                            sx={{ mt: 0.5, maxWidth: 260, height: 'auto',
                                  '& .MuiChip-label': { whiteSpace: 'normal', py: 0.25 } }} />
                    )}
                    {v.description && (
                      <Typography variant="caption" color="text.secondary" display="block">{v.description}</Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" display="block">{inv?.owner || v.created_by || '—'}</Typography>
                    {inv?.source?.kind && (
                      <Typography variant="caption" color="text.secondary" display="block">
                        {inv.source.word || inv.source.kind}{inv.source.name ? ` · ${inv.source.name}` : inv.source.id ? ` #${inv.source.id}` : ''}
                      </Typography>
                    )}
                    <Typography variant="caption" color="text.secondary">
                      {v.created_at ? new Date(v.created_at).toLocaleDateString() : ''}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <StatusCell row={inv} fallbackActive={v.is_active} />
                    {/* 2026-09-27 -- a view whose COLUMNS moved since it was
                        published wears its schema version; the tooltip is the
                        diff and "Schema history" in the menu is the record. */}
                    {v.schema_changes && (
                      <Tooltip title={
                        `Schema v${v.schema_version}` +
                        (v.schema_changed_at ? ` on ${new Date(v.schema_changed_at).toLocaleString()}` : '') +
                        ': ' + describeSchemaChanges(v.schema_changes).join('; ')}>
                        <Chip label={`schema v${v.schema_version}`} size="small" color="warning"
                          variant="outlined" icon={<SchemaIcon sx={{ fontSize: 14 }} />}
                          data-testid="schema-version-chip" sx={{ ml: 0.5, mt: 0.5 }} />
                      </Tooltip>
                    )}
                  </TableCell>
                  <TableCell>{consumersCell(inv)}</TableCell>
                  <TableCell>
                    {(v.allowed_filters || []).length > 0
                      ? v.allowed_filters.map(f => <Chip key={f} label={f} size="small" sx={{ mr: 0.5, mb: 0.5 }} />)
                      : <Typography variant="caption" color="text.secondary">All columns</Typography>
                    }
                    <Box>
                      {(v.allowed_ad_groups || []).length > 0
                        ? v.allowed_ad_groups.map(g => (
                            <Chip key={g} label={g} size="small" color="primary" variant="outlined" sx={{ mr: 0.5, mb: 0.5 }} />
                          ))
                        : <Chip label="All AD users" size="small" color="secondary" variant="outlined" />
                      }
                    </Box>
                  </TableCell>
                  {/* Redacted rows (another publisher's view, non-admin caller)
                      carry none of these numbers — render a dash, not "s" / " / ". */}
                  <TableCell>
                    <Typography variant="caption" display="block">
                      {v.default_limit != null || v.max_limit != null
                        ? `${v.default_limit ?? '—'} / ${v.max_limit ?? '—'} rows`
                        : '—'}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {v.cache_ttl_seconds != null ? `cache ${v.cache_ttl_seconds}s` : ''}
                    </Typography>
                  </TableCell>
                  <TableCell><Typography variant="caption" data-testid="pv-last-call">{lastCallWords(inv)}</Typography></TableCell>
                  <TableCell align="right"><Typography variant="caption" data-testid="pv-calls-7d">{inv ? (inv.calls_7d ?? 'unknown') : '—'}</Typography></TableCell>
                  <TableCell align="right">
                    {/* 2026-09-24 (screen walk): a labelled Edit (BF-488) was
                        followed by FIVE unlabelled icons.  Edit and Test stay
                        one click away as named buttons; republish, usage, key
                        request and deactivate live in a labelled menu
                        (common/RowActions).  The three actions this row used
                        to HIDE on an inactive view are now shown disabled with
                        the reason, so a person can see why they are missing. */}
                    <RowActions rowName={v.name}
                      primary={[
                        { label: 'Edit', icon: <EditIcon fontSize="small" />,
                          onClick: () => openEdit(v),
                          disabled: !!v._redacted, disabledReason: NOT_YOURS },
                        { label: 'Test endpoint', icon: <TestIcon fontSize="small" color={v.is_active ? 'success' : 'disabled'} />,
                          onClick: () => openTestDialog(v),
                          disabled: !v.is_active, disabledReason: 'Inactive view — it cannot be called' },
                      ]}
                      more={[
                        { label: 'Republish', icon: <RefreshIcon fontSize="small" />,
                          description: 'Re-snapshot the query from its source (saved query, SQL file, report)',
                          onClick: () => handleRepublish(v.id),
                          disabled: !!v._redacted, disabledReason: NOT_YOURS },
                        { label: 'View usage', icon: <UsageIcon fontSize="small" />,
                          description: 'Recent calls: status, rows, duration, client IP',
                          onClick: () => openUsage(v),
                          disabled: !!v._redacted, disabledReason: NOT_YOURS },
                        { label: 'Schema history', icon: <SchemaIcon fontSize="small" />,
                          description: 'Every column set this view has served, what changed, and who was told',
                          onClick: () => openSchema(v),
                          disabled: !!v._redacted, disabledReason: NOT_YOURS },
                        { label: 'Lifecycle', icon: <LifecycleIcon fontSize="small" />,
                          description: 'Draft / active / deprecated (with a sunset and a successor) / retired — consumers are told',
                          onClick: () => inv && setLifecycleOf(inv),
                          disabled: !!v._redacted || !inv,
                          disabledReason: v._redacted ? NOT_YOURS : 'The inventory could not be read' },
                        { label: 'Request API key', icon: <VpnKeyIcon fontSize="small" />, dividerBefore: true,
                          description: 'Ask for a key scoped to this view; an admin reviews it',
                          onClick: () => openRequestKey(v),
                          disabled: !v.is_active, disabledReason: 'Inactive view — it cannot be called' },
                        { label: 'Deactivate', icon: <DeleteIcon fontSize="small" />, danger: true,
                          description: 'Stop serving this endpoint (asks first)',
                          onClick: () => handleDelete(v.id),
                          disabled: !!v._redacted || !v.is_active,
                          disabledReason: v._redacted ? NOT_YOURS : 'Already inactive' },
                      ]} />
                  </TableCell>
                </TableRow>
                );
              })}
              {/* 2026-10-17 -- a published REPORT served by a token is an API of
                  another kind in the same inventory (design §3.2); it has no
                  view-management actions, its lifecycle is the one thing to act on */}
              {reportApis.map(r => (
                <TableRow key={`report-${r.api_id}`} data-testid="pv-report-row"
                          sx={{ opacity: (r.lifecycle?.status || 'active') === 'retired' ? 0.5 : 1 }}>
                  <TableCell>
                    <Stack direction="row" spacing={0.5} alignItems="center">
                      <Chip size="small" label="report" color="info" variant="outlined" sx={{ height: 18, fontSize: 10 }} />
                      <Typography variant="body2" fontWeight={500}>{r.name}</Typography>
                    </Stack>
                    <code style={{ fontSize: 12 }}>#{r.key}</code>
                    {r.description && <Typography variant="caption" color="text.secondary" display="block">{r.description}</Typography>}
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" display="block">{r.owner || '—'}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {(r.endpoints || []).length} endpoints · embed / share tokens
                    </Typography>
                  </TableCell>
                  <TableCell><StatusCell row={r} fallbackActive={true} /></TableCell>
                  <TableCell>{consumersCell(r)}</TableCell>
                  <TableCell>
                    {(r.filters || []).length > 0
                      ? r.filters!.map(f => <Chip key={f} label={f} size="small" sx={{ mr: 0.5, mb: 0.5 }} />)
                      : <Typography variant="caption" color="text.secondary">{(r.parameters || []).length} parameters</Typography>}
                  </TableCell>
                  <TableCell><Typography variant="caption" color="text.secondary">—</Typography></TableCell>
                  <TableCell><Typography variant="caption">{lastCallWords(r)}</Typography></TableCell>
                  <TableCell align="right"><Typography variant="caption">{r.calls_7d ?? 'unknown'}</Typography></TableCell>
                  <TableCell align="right">
                    <RowActions rowName={r.name}
                      primary={[
                        { label: 'Lifecycle', icon: <LifecycleIcon fontSize="small" />,
                          onClick: () => setLifecycleOf(r),
                          disabled: !!r.is_redacted, disabledReason: NOT_YOURS },
                      ]}
                      more={[]} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={shownViews.paging} onPage={setViewPage} onPageSize={setViewPageSize}
                     testid="pv-views-pager" />
        </Paper>
      ))}

      <LifecycleDialog api={lifecycleOf}
                       siblings={inventory.filter(a => a.api_kind === lifecycleOf?.api_kind)}
                       onClose={() => setLifecycleOf(null)}
                       onSaved={(res: any) => {
                         setLifecycleOf(null);
                         const n = res?.notified;
                         setLifecycleNotice(`${res?.key || 'the API'} is now ${res?.lifecycle?.status || res?.to || 'updated'}`
                           + (n ? (n.sent ? ` — ${(n.emails || []).length} consumer address(es) e-mailed` : n.reason ? ` — consumers not e-mailed: ${n.reason}` : '') : ''));
                         reloadAll();
                       }} />

      {/* Edit Dialog */}
      {/* BF-487 (2026-05-27) — widened to "md" so the inner dropdown
          poppers (capped at min(600px, 90vw)) fit inside the dialog. */}
      <Dialog open={!!editView} onClose={() => { setEditView(null); setEditError(null); }} maxWidth="md" fullWidth>
        <DialogTitle>Edit Published View</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            {/* BF-564 (2026-05-29): inline required-field validation
                error so the user sees the cause instead of a backend 400. */}
            {editError && (
              <Alert severity="error" onClose={() => setEditError(null)}>
                {editError}
              </Alert>
            )}
            <TextField label="Name" value={editName} onChange={e => setEditName(e.target.value)} fullWidth size="small" />
            <TextField label="Slug" value={editSlug} onChange={e => setEditSlug(e.target.value)} fullWidth size="small"
              helperText="URL-friendly identifier (lowercase, hyphens only)" />
            <TextField label="Description" value={editDesc} onChange={e => setEditDesc(e.target.value)} fullWidth size="small" multiline rows={2} />
            <Autocomplete
              multiple freeSolo size="small" openOnFocus
              options={editColumnOptions}
              value={editFilters}
              onChange={(_, v) => setEditFilters(v)}
              // BF-490 — popper auto-resize so long qualified column names
              // (e.g. "warehouse.dim_customer.email_domain") don't clip.
              slotProps={{
                popper: {
                  sx: {
                    maxWidth: '90vw',
                    '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                    '& .MuiAutocomplete-option': {
                      whiteSpace: 'normal',
                      wordBreak: 'break-word',
                    },
                  },
                },
              }}
              renderInput={params => (
                <TextField {...params}
                  label="Allowed Filters (columns)"
                  placeholder={editColumnOptions.length
                    ? 'Pick or type column name'
                    : 'Type column name...'}
                  helperText={editColumnOptions.length
                    ? `${editColumnOptions.length} columns available`
                    : 'Schema unavailable — type from memory'}
                />
              )}
            />
            <Stack direction="row" spacing={2}>
              <TextField label="Default Limit" type="number" value={editDefaultLimit}
                onChange={e => setEditDefaultLimit(Number(e.target.value))} size="small" sx={{ flex: 1 }} />
              <TextField label="Max Limit" type="number" value={editMaxLimit}
                onChange={e => setEditMaxLimit(Number(e.target.value))} size="small" sx={{ flex: 1 }} />
            </Stack>
            <TextField label="Cache TTL (seconds)" type="number" value={editCacheTtl}
              onChange={e => setEditCacheTtl(Number(e.target.value))} size="small"
              helperText="0 = always fresh" />
            <TextField
              label="Allowed AD Groups (optional)"
              value={editAdGroupsInput}
              onChange={e => setEditAdGroupsInput(e.target.value)}
              fullWidth size="small"
              placeholder="grp-analytics, grp-risk-team"
              helperText="Comma-separated LDAP group names. Leave empty to allow all authenticated AD users."
            />

            {/* BF-488 / BF-495 — WHERE-clause editing.  Same component
                the Publish dialog uses; persists into
                query_config._where_clauses_mapping via the backend's
                UpdateViewRequest.where_clauses field.  Heading + helper
                text make the section discoverable for users editing
                an existing PV. */}
            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
              WHERE Clauses
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              Click <strong>+ Add WHERE row</strong> to add a Static (locked) or
              Dynamic (consumer-overridable) filter.  Dynamic rows are
              auto-added to <code>param_definitions</code> + <code>allowed_filters</code> on save.
              {editColumnObjects.length === 0 && (
                <> Column dropdown is empty for this source — type column names directly.</>
              )}
            </Typography>
            <WhereClausesEditor
              value={editWhereClauses}
              onChange={setEditWhereClauses}
              columnOptions={editColumnObjects}
              title="Rows"
              addLabel="Add WHERE row"
              connectionId={editView?.connection_id ?? null}
            />

            {/* Phase 133-J — credential routing.  publisher_username is
                immutable (server strips it) but the publisher can change
                mode and re-point the execution connection. */}
            <Divider sx={{ my: 1 }} />
            <Typography variant="subtitle2">
              Execution Connection & Credentials
            </Typography>
            <FormControl fullWidth size="small">
              <InputLabel id="edit-exec-conn-label">Execution Connection</InputLabel>
              <Select
                labelId="edit-exec-conn-label"
                label="Execution Connection"
                value={editExecConnId === '' ? '' : String(editExecConnId)}
                onChange={e => {
                  const v = e.target.value;
                  setEditExecConnId(v === '' ? '' : Number(v));
                }}
              >
                <MenuItem value="">
                  <em>Inherit from saved query / file (default)</em>
                </MenuItem>
                {editConnOptions.map(c => (
                  <MenuItem key={c.id} value={String(c.id)}>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography variant="body2">{c.name}</Typography>
                      <Chip size="small" label={c.connection_type} variant="outlined" />
                      {c.is_shared && (
                        <Chip size="small" label="shared" color="info" variant="outlined" />
                      )}
                    </Stack>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl>
              <FormLabel sx={{ fontSize: '0.85rem' }}>Credential Mode</FormLabel>
              <RadioGroup
                value={editCredentialMode}
                onChange={e => setEditCredentialMode(e.target.value as any)}
              >
                <FormControlLabel value="publisher" control={<Radio size="small" />}
                  label="Use my credentials (delegated trust — no consumer prompt)" />
                <FormControlLabel value="shared" control={<Radio size="small" />}
                  label="Use connection's shared credentials (system account)" />
                <FormControlLabel value="consumer" control={<Radio size="small" />}
                  label="Require consumer credentials (legacy, may 401 curl)" />
              </RadioGroup>
              {editView?.publisher_username && editCredentialMode === 'publisher' && (
                <Typography variant="caption" color="text.secondary">
                  Publisher (frozen at publish time): <code>{editView.publisher_username}</code>
                </Typography>
              )}
            </FormControl>
            <FormControl>
              {/* 2026-10-25 -- THE data-policy switch of this API (stored as
                  entitlement_mode).  Off: an API key reads this API's data with no
                  row policy and no entitlement dimension applied.  Apply: the key
                  is the principal api_key:<id> -- the row policies bound to it and
                  its own entitlement values; a key holding nothing reads no rows.
                  A signed-in person is governed as a person either way. */}
              <FormLabel sx={{ fontSize: '0.85rem' }}>Data policies on this API</FormLabel>
              <RadioGroup
                data-testid="pv-data-policy-mode"
                value={editEntitlementMode}
                onChange={e => setEditEntitlementMode(e.target.value as 'default' | 'off' | 'apply')}
              >
                <FormControlLabel value="default" control={<Radio size="small" disabled={!isAdmin} />}
                  data-testid="pv-data-policy-default"
                  label={`Follow the configuration (published_views.default_data_policy_mode) — now ${
                    (editView?.entitlement_mode_default ?? 'apply') === 'apply' ? 'Apply' : 'Off'}.`} />
                <FormControlLabel value="off" control={<Radio size="small" disabled={!isAdmin} />}
                  label="Off — an API key reads this API's data with no row policy and no data-entitlement dimension applied." />
                <FormControlLabel value="apply" control={<Radio size="small" disabled={!isAdmin} />}
                  label="Apply — an API key reads only the rows its own bindings and entitlement values allow (a key holding nothing reads no rows)." />
              </RadioGroup>
              <Typography variant="caption" color="text.secondary">
                {isAdmin
                  ? 'Bind a row policy or an entitlement value to the key itself (principal type "API key", by the key\'s id) under Admin -> Row security. A signed-in person is governed as a person whatever this says.'
                  : 'Only the roles in row_security.data_policy_switch_roles change this. A signed-in person is governed as a person whatever this says.'}
              </Typography>
            </FormControl>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditView(null)}>Cancel</Button>
          <Button variant="contained" onClick={handleSaveEdit}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Phase 85C-3: Test Dialog */}
      <Dialog open={!!testView} onClose={() => setTestView(null)} maxWidth="md" fullWidth>
        <DialogTitle>Test Endpoint: {testView?.name}</DialogTitle>
        <DialogContent>
          {testView && (
            <Box>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                Endpoint: <code>{`${pubBase}/api/v1/views/${testView.slug}/data`}</code>
              </Typography>
              {/* 2026-10-25 -- the whole result as one CSV file (the owner) */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1, flexWrap: 'wrap' }} data-testid="pv-csv-link">
                <Typography variant="caption" color="text.secondary">
                  Whole result as a CSV file: <code>{`${pubBase}/api/v1/views/${testView.slug}/bulk.csv`}</code>
                </Typography>
                <Button size="small" onClick={() => navigator.clipboard.writeText(`${pubBase}/api/v1/views/${testView.slug}/bulk.csv`)}>
                  Copy link
                </Button>
                <Button size="small" onClick={() => navigator.clipboard.writeText(
                  `curl -H "X-API-Key: <your key>" "${pubBase}/api/v1/views/${testView.slug}/bulk.csv" -o ${testView.slug}.csv`)}>
                  Copy command
                </Button>
              </Box>

              {/* Phase 86: Runtime Parameter inputs.
                  Phase 133-H round 11: Autocomplete with lazy distinct-
                  values lookup against the cached schema — searchable
                  dropdown instead of plain textbox. */}
              {(testView.param_definitions || []).length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Runtime Parameters</Typography>
                  <Stack spacing={1}>
                    {(testView.param_definitions || []).map((p: any) => {
                      const opts = testValueOptions[(p.name || '').toLowerCase()] || [];
                      return (
                        <Box key={p.name} sx={{ display: 'flex', gap: 1, mb: 1 }}>
                          <Autocomplete
                            size="small" freeSolo openOnFocus
                            options={opts}
                            value={testParamValues[p.name] || ''}
                            onChange={(_, v) => setTestParamValues(prev => ({
                              ...prev, [p.name]: (v ?? '') as string,
                            }))}
                            onInputChange={(_, v, reason) => {
                              if (reason === 'input') setTestParamValues(prev => ({
                                ...prev, [p.name]: v,
                              }));
                            }}
                            onFocus={() => fetchTestValues(p.name)}
                            sx={{ flex: 1 }}
                            slotProps={{
                              popper: {
                                sx: {
                                  maxWidth: '90vw',
                                  '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                  '& .MuiAutocomplete-option': {
                                    whiteSpace: 'normal', wordBreak: 'break-word',
                                  },
                                },
                              },
                            }}
                            renderInput={(rp) => (
                              <TextField {...rp}
                                label={`${p.name}${p.required ? ' *' : ''}`}
                                placeholder={p.default != null ? String(p.default) : (opts.length ? 'Pick or type' : p.type)}
                                helperText={p.description || `Type: ${p.type}${opts.length ? ` · ${opts.length} known values` : ''}`}
                              />
                            )}
                          />
                        </Box>
                      );
                    })}
                  </Stack>
                </Box>
              )}

              {/* Filter inputs */}
              {(testView.allowed_filters || []).length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Filter Parameters</Typography>
                  <Stack spacing={1}>
                    {(testView.allowed_filters || []).map(col => {
                      const opts = testValueOptions[col.toLowerCase()] || [];
                      return (
                        <Autocomplete
                          key={col}
                          size="small" freeSolo openOnFocus
                          options={opts}
                          value={testFilters[col] || ''}
                          onChange={(_, v) => setTestFilters(prev => ({
                            ...prev, [col]: (v ?? '') as string,
                          }))}
                          onInputChange={(_, v, reason) => {
                            if (reason === 'input') setTestFilters(prev => ({
                              ...prev, [col]: v,
                            }));
                          }}
                          onFocus={() => fetchTestValues(col)}
                          slotProps={{
                            popper: {
                              sx: {
                                maxWidth: '90vw',
                                '& .MuiAutocomplete-listbox': { maxHeight: 360 },
                                '& .MuiAutocomplete-option': {
                                  whiteSpace: 'normal', wordBreak: 'break-word',
                                },
                              },
                            },
                          }}
                          renderInput={(rp) => (
                            <TextField {...rp}
                              label={`filter[${col}]`}
                              placeholder={opts.length ? 'Pick or type — eq:val or val' : 'e.g., eq:2024 or 2024'}
                              helperText={opts.length ? `${opts.length} known values` : undefined}
                            />
                          )}
                        />
                      );
                    })}
                  </Stack>
                </Box>
              )}

              {testError && <Alert severity="error" sx={{ mb: 1 }}>{testError}</Alert>}

              {/* Results */}
              {testRows.length > 0 && (
                <Box sx={{ overflowX: 'auto', mt: 1 }}>
                  <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Response ({testRows.length} rows)</Typography>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {testColumns.map(col => (
                          <TableCell key={col} sx={{ fontWeight: 700, fontSize: 11, whiteSpace: 'nowrap' }}>{col}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {testRows.map((row, idx) => (
                        <TableRow key={idx}>
                          {testColumns.map(col => (
                            <TableCell key={col} sx={{ fontSize: 11, whiteSpace: 'nowrap' }}>
                              {row[col] === null || row[col] === undefined ? (
                                <span style={{ color: '#aaa' }}>null</span>
                              ) : String(row[col]).substring(0, 60)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTestView(null)}>Close</Button>
          <Button
            variant="contained"
            color="success"
            startIcon={testLoading ? <CircularProgress size={14} /> : <TestIcon />}
            onClick={handleTestRequest}
            disabled={testLoading}
          >
            {testLoading ? 'Sending...' : 'Send Request'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Request API Key Dialog */}
      <Dialog open={!!reqKeyView} onClose={() => !reqSuccess && setReqKeyView(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Request API Key{reqKeyView ? `: ${reqKeyView.name}` : ''}</DialogTitle>
        <DialogContent>
          {reqSuccess ? (
            <Alert severity="success" sx={{ mt: 1 }}>{reqSuccess}</Alert>
          ) : (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="Key Name" value={reqKeyName} onChange={e => setReqKeyName(e.target.value)} fullWidth size="small" required />
              <TextField label="Justification (optional)" value={reqJustification} onChange={e => setReqJustification(e.target.value)} fullWidth size="small" multiline rows={2}
                placeholder="Why do you need this API key?" />
              <TextField label="Rate Limit (optional)" value={reqRateLimit} onChange={e => setReqRateLimit(e.target.value)} size="small"
                placeholder="e.g., 60/minute" helperText="Format: N/(second|minute|hour)" />
              <TextField label="Expiry Hours (optional)" value={reqExpiresHours} onChange={e => setReqExpiresHours(e.target.value)} type="number" size="small"
                placeholder="e.g., 720 (30 days)" />
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReqKeyView(null)}>{reqSuccess ? 'Close' : 'Cancel'}</Button>
          {!reqSuccess && (
            <Button variant="contained" onClick={handleRequestKey} disabled={reqSubmitting || !reqKeyName.trim()}
              startIcon={reqSubmitting ? <CircularProgress size={14} /> : <VpnKeyIcon />}>
              {reqSubmitting ? 'Submitting...' : 'Request Key'}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* My API Key Requests */}
      {tab === 'inventory' && myRequests.length > 0 && (
        <Box sx={{ mt: 4 }}>
          <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>My API Key Requests</Typography>
          <Paper variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Key Name</strong></TableCell>
                  <TableCell><strong>Views</strong></TableCell>
                  <TableCell><strong>Status</strong></TableCell>
                  <TableCell><strong>Justification</strong></TableCell>
                  <TableCell><strong>Reviewed By</strong></TableCell>
                  <TableCell><strong>Requested</strong></TableCell>
                  <TableCell align="right"><strong>Actions</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownMyRequests.rows.map((r: any) => (
                  <TableRow key={r.id}>
                    <TableCell>{r.key_name}</TableCell>
                    <TableCell>{resolveViewNames(r.scoped_view_ids || [])}</TableCell>
                    <TableCell>
                      <Chip label={r.status} size="small"
                        color={r.status === 'approved' ? 'success' : r.status === 'denied' ? 'error' : 'warning'} />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.justification || '-'}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.reviewed_by || '-'}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{r.created_at ? new Date(r.created_at).toLocaleDateString() : '-'}</Typography>
                    </TableCell>
                    <TableCell align="right">
                      {r.status === 'approved' && r.api_key_id && (
                        revealedKeys[r.api_key_id] ? (
                          <Tooltip title="Click to copy">
                            <Chip label={revealedKeys[r.api_key_id]} size="small" sx={{ fontFamily: 'monospace', fontSize: 10, maxWidth: 200 }}
                              onClick={() => navigator.clipboard.writeText(revealedKeys[r.api_key_id])} />
                          </Tooltip>
                        ) : (
                          <Button size="small" startIcon={<VpnKeyIcon />} onClick={() => handleRevealKey(r.api_key_id)}>
                            Reveal Key
                          </Button>
                        )
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <ListPager paging={shownMyRequests.paging} onPage={setMyReqPage} onPageSize={setMyReqPageSize}
                       testid="pv-requests-pager" />
          </Paper>
        </Box>
      )}

      {/* Usage Dialog */}
      <Dialog open={!!usageView} onClose={() => setUsageView(null)} maxWidth="md" fullWidth>
        <DialogTitle>Usage Logs: {usageView?.name}</DialogTitle>
        <DialogContent>
          {usageLoading ? (
            <Box sx={{ textAlign: 'center', py: 3 }}><CircularProgress size={24} /></Box>
          ) : usageLogs.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 2 }}>No access logs yet.</Typography>
          ) : (
            <>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Time</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Rows</TableCell>
                  <TableCell>Duration</TableCell>
                  <TableCell>Client IP</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownUsage.rows.map(log => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <Typography variant="caption">
                        {log.created_at ? new Date(log.created_at).toLocaleString() : '-'}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={log.status_code}
                        size="small"
                        color={log.status_code === 200 ? 'success' : 'error'}
                      />
                    </TableCell>
                    <TableCell>{log.response_rows ?? '-'}</TableCell>
                    <TableCell>{log.response_ms ? `${log.response_ms}ms` : '-'}</TableCell>
                    <TableCell><Typography variant="caption">{log.client_ip || '-'}</Typography></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <ListPager paging={shownUsage.paging} onPage={setUsagePage} onPageSize={setUsagePageSize}
                       testid="pv-usage-pager" />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUsageView(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* 2026-09-27 -- Schema history: the column sets this view has served */}
      <Dialog open={!!schemaView} onClose={() => setSchemaView(null)} maxWidth="md" fullWidth>
        <DialogTitle>Schema history: {schemaView?.name}</DialogTitle>
        <DialogContent>
          {schemaLoading ? (
            <Box sx={{ textAlign: 'center', py: 3 }}><CircularProgress size={24} /></Box>
          ) : schemaError ? (
            <Alert severity="error">{schemaError}</Alert>
          ) : schemaVersions.length === 0 ? (
            <Typography color="text.secondary" sx={{ py: 2 }}>
              No schema version has been recorded for this view yet — it is recorded at publish,
              on republish, on a query update, and when the dataset behind a report-sourced view
              is auto-detected.
            </Typography>
          ) : (
            <>
            <Table size="small" data-testid="schema-versions-table">
              <TableHead>
                <TableRow>
                  <TableCell>Version</TableCell>
                  <TableCell>When</TableCell>
                  <TableCell>Reason</TableCell>
                  <TableCell>Changes</TableCell>
                  <TableCell>Columns</TableCell>
                  <TableCell>Notified</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownSchema.rows.map(sv => {
                  const lines = describeSchemaChanges(sv.changes);
                  const n = sv.notified;
                  return (
                    <TableRow key={sv.id}>
                      <TableCell><Chip size="small" label={`v${sv.version_no}`} /></TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          {sv.created_at ? new Date(sv.created_at).toLocaleString() : '-'}
                          {sv.changed_by ? ` · ${sv.changed_by}` : ''}
                        </Typography>
                      </TableCell>
                      <TableCell><Typography variant="caption">{sv.reason}</Typography></TableCell>
                      <TableCell>
                        {sv.changes == null
                          ? <Typography variant="caption" color="text.secondary">baseline</Typography>
                          : lines.length === 0
                            ? <Typography variant="caption" color="text.secondary">re-recorded, no column change</Typography>
                            : lines.map(l => <Typography key={l} variant="caption" display="block">{l}</Typography>)}
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          {(sv.columns || []).map(c => c.name).join(', ')}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {n == null ? (
                          <Typography variant="caption" color="text.secondary">—</Typography>
                        ) : (
                          <Typography variant="caption" display="block">
                            {n.sent
                              ? `emailed ${(n.emails || []).join(', ')}`
                              : (n.emails && n.emails.length
                                ? `email failed: ${n.reason || 'unknown'}`
                                : `not emailed: ${n.reason || 'no recipient'}`)}
                            {n.unrouted && n.unrouted.length
                              ? ` · no address for ${n.unrouted.join(', ')}` : ''}
                          </Typography>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            <ListPager paging={shownSchema.paging} onPage={setSchemaPage} onPageSize={setSchemaPageSize}
                       testid="pv-schema-pager" />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSchemaView(null)}>Close</Button>
        </DialogActions>
      </Dialog>
      <FederationViewEditorDialog
        open={xsEditorOpen}
        initial={EMPTY_VIEW}
        connections={xsConnections}
        onClose={() => setXsEditorOpen(false)}
        onSaved={fv => { setXsEditorOpen(false); setXsPublish(fv); }}
      />
      {xsPublish && (
        <PublishViewDialog
          open={!!xsPublish}
          onClose={() => { setXsPublish(null); reloadAll(); }}
          queryName={xsPublish.name || ''}
          sourceType="federation"
          federationViewId={xsPublish.id}
          columns={xsPublish.output_columns || []}
        />
      )}
    </Box>
  );
};

export default PublishedViewsPage;
