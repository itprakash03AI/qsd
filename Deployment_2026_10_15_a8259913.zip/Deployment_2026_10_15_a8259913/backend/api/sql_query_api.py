"""
SQL Query API — Trino / Starburst / Snowflake / Databricks

Endpoints:
  GET    /api/sql/queries                      – list saved SQL queries
  POST   /api/sql/queries                      – create saved SQL query
  GET    /api/sql/queries/{id}                 – get single SQL query
  PUT    /api/sql/queries/{id}                 – update SQL query
  DELETE /api/sql/queries/{id}                 – delete SQL query
  POST   /api/sql/execute                      – execute (single or cross-source)
  GET    /api/sql/connections/{id}/catalogs    – list catalogs
  GET    /api/sql/connections/{id}/schemas     – list schemas in a catalog
  GET    /api/sql/connections/{id}/tables      – list tables in catalog.schema
  GET    /api/sql/connections/{id}/columns     – list columns in catalog.schema.table
  POST   /api/sql/connections/{id}/test        – test SQL connection
  GET    /api/sql/connector-types              – list supported connector types + field defs
"""

from __future__ import annotations

import asyncio
import threading
import functools
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query, BackgroundTasks, Request
from api.connector_errors import connector_http_error
from pydantic import BaseModel, Field
from api.models.query_models import CLIENT_REQUEST_ID_PATTERN

from core.roles import is_admin_like
from core.db_async import adb
from core.sql_filter_wrapper import dialect_for_connection_type

logger = logging.getLogger(__name__)

router = APIRouter()

# ── Injected from main.py startup ─────────────────────────────────────────────
_db_manager  = None
_ws_manager  = None
_main_loop   = None
_auth_cfg    = None   # core.config.auth singleton
_sql_executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix="sql_query")  # legacy, phasing out


def set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=None):
    global _db_manager, _ws_manager, _main_loop, _auth_cfg
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop
    _auth_cfg   = auth_cfg


def _get_current_user_sql(request: Request) -> Optional[dict]:
    """Local version of _get_current_user for the SQL router."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True, "groups": [], "role": "admin"}
    # 2026-10-07: the principal the request middleware already resolved for
    # THIS request (``api.deps.aresolve_user``, off the event loop).  This
    # function runs INLINE in async routes -- ``POST /api/sql/execute`` among
    # them -- and re-did the session-store read (a DB read every L1
    # revalidation) or the Basic password check on the event loop: measured
    # in-process as the SQL lane's loop stall once the middleware was fixed.
    try:
        _stashed = getattr(request.state, "qs_resolved_user", None)
    except Exception:
        _stashed = None
    if isinstance(_stashed, dict) and _stashed.get("username"):
        return _stashed
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    # Session token (Bearer) — look up server-side session
    if auth_header.startswith("Bearer "):
        from main import _get_session
        user = _get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user
    # Basic auth fallback
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _require_sql_writer(user: Optional[dict]) -> None:
    """Admin/analyst gate for routes that CREATE, MUTATE or EXECUTE SQL.

    2026-08-23 -- ONE definition.  create/update/delete each carried an inline
    copy of this rule while ``POST /api/sql/execute`` -- the route that runs
    arbitrary SQL with the connection's STORED credentials -- carried none, so
    a VIEWER could execute any SQL the UI's RoleGuard (admin/analyst) never
    let them type.  Mirrors ``require_execute_access`` on /api/execute.
    """
    if not (_auth_cfg and _auth_cfg.type != "none"):
        return
    role = (user or {}).get("role", "viewer")
    if role not in ("admin", "analyst", "super_admin"):
        raise HTTPException(403, "Requires role: admin, analyst")


def _require_conn_entitlement_sql(user: Optional[dict], connection_ids) -> None:
    """Connection entitlement for /api/sql/execute -- THE leak-gate decision.

    2026-08-23 -- the five browse routes gate via ``_require_conn_access_sql``
    but execute (saved-query AND inline modes) fetched the DECRYPTED record
    with no check at all: any analyst could run arbitrary SQL against any
    other analyst's PRIVATE connection by id.  Same decision as Data Quality
    rules and datasets: ``core.entitlements.denied_connection_ids`` (own /
    shared / legacy-unowned / ACL-granted; fail-closed).  404, not 403, so
    the route is not an existence oracle -- matching the browse routes.
    """
    if not (_auth_cfg and _auth_cfg.type != "none"):
        return
    ids = [c for c in (connection_ids or []) if c]
    if not ids:
        return
    from core.entitlements import denied_connection_ids
    denied = denied_connection_ids(user or {}, ids, db=_db_manager)
    if denied:
        raise HTTPException(
            status_code=404,
            detail=f"Connection {denied[0]} not found")


def _is_owner_or_shared_sql(item: dict, user: dict) -> bool:
    if not user or is_admin_like(user):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
    )


# ── ${user.*} principal variables in editor SQL (2026-08-29) ─────────────────
def _render_user_vars(sql, user, label: str):
    """Render ``${user.*}`` in author-typed SQL — the REPORT renderer, on the
    SQL-page path.

    Reports resolve ``${user.username|role|groups|is_admin|<attr>}`` at
    execution time (``core.reports.user_sql_vars`` — the ONE renderer; do not
    add a second).  ``POST /api/sql/execute`` (saved query_id AND inline
    modes) did not, so the same saved SQL ran as a report and was a raw
    syntax error here.  Byte-identical no-op when the SQL has no ``${``.

    Rendered against the VERIFIED session user only
    (``_get_current_user_sql``) — never a body-supplied identity field.
    ValueError = unknown token = authoring error → 400 with the message
    intact (it names the bad variable and the available vocabulary).
    MUST run before ``secure_sql``: the rewriter parses the SQL and ``${``
    does not parse.
    """
    if not sql or "${" not in sql:
        return sql
    from core.reports.user_sql_vars import resolve_user_sql_vars
    try:
        return resolve_user_sql_vars(sql, user, label=label)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        from core.worker_pool import get_pool
        _exec = get_pool().executor
    except RuntimeError:
        _exec = _sql_executor
    if kwargs:
        return await loop.run_in_executor(_exec, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_exec, fn, *args)


def _extract_lineage_for_sql_query(result: dict, sql_text: str, connection_id: int | None) -> None:
    """Phase 49: fire-and-forget lineage extraction after query create/update."""
    try:
        from core.sql_lineage_parser import extract_and_store_lineage
        query_id = result.get("id")
        if not query_id or not sql_text:
            return
        # Dialect resolution moved INTO extract_and_store_lineage — the
        # local lookup here read conn["type"], a key that does not exist
        # (it is "connection_type"), so every on-save extraction parsed
        # with the duckdb dialect regardless of source.
        extract_and_store_lineage(_db_manager, "sql_query", query_id, sql_text,
                                  connection_id=connection_id)
    except Exception:
        pass  # lineage is best-effort


def _get_connection_record(connection_id: int) -> Dict[str, Any]:
    """Fetch connection with credentials decrypted — for internal engine use only.
    Never return this dict to API clients."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    conn = _db_manager.get_connection_raw(connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail=f"Connection {connection_id} not found")
    return conn


async def _require_conn_access_sql(connection_id: int,
                                   request: Request) -> Dict[str, Any]:
    """Authenticate, authorize, THEN decrypt the connection.

    SECURITY 2026-08-17: the five catalog/schema/table/column/test routes below
    called ``_get_connection_record`` -- the DECRYPTING accessor -- straight
    from an unauthenticated request.  An anonymous caller could enumerate
    connection ids and walk the entire catalog/schema/table/column tree of any
    registered warehouse, and force outbound connections, using the stored
    credentials without ever seeing them.

    Reuses ``connections_api._connection_visible_to`` rather than restating the
    rule, so the two routers cannot drift apart.  404 on denial, matching
    ``get_connection``, so this is not an existence oracle.
    """
    user = _get_current_user_sql(request)          # raises 401 when unauthenticated
    conn_meta = await asyncio.to_thread(_db_manager.get_connection, connection_id) \
        if _db_manager else None
    if not conn_meta:
        raise HTTPException(status_code=404,
                            detail=f"Connection {connection_id} not found")
    from api.connections_api import _connection_visible_to
    if not await _connection_visible_to(conn_meta, user):
        raise HTTPException(status_code=404,
                            detail=f"Connection {connection_id} not found")
    return await asyncio.to_thread(_get_connection_record, connection_id)


def _is_s3_conn(conn: Dict[str, Any]) -> bool:
    """Return True iff the given connection record is an S3 connection."""
    return str(conn.get("connection_type") or "").lower() == "s3"


def _partition_columns_for(connection_id: int, table: str) -> List[str]:
    """Return partition column names for one S3 table (empty list on miss/error).

    Shared between the guardrail pre-check in ``_execute_s3_raw_sql`` and the
    ``list_tables`` S3 branch (which attaches them to the picker response so
    the frontend can build a starter query with a partition filter).
    """
    try:
        rows = _db_manager.get_connection_partitions(connection_id, table) or []
    except Exception:
        return []
    cols: List[str] = []
    for p in rows:
        if isinstance(p, dict):
            c = p.get("column")
            if c:
                cols.append(c)
    return cols


def _require_sql_connector_type(conn: Dict[str, Any]) -> str:
    """Return the connection_type and raise if it's not a SQL connector type."""
    from core.connectors import SQL_CONNECTOR_TYPES
    ctype = conn.get("connection_type", "").lower()
    if ctype not in SQL_CONNECTOR_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Connection type '{ctype}' is not a SQL connector. "
                   f"Supported SQL types: {', '.join(SQL_CONNECTOR_TYPES)}"
        )
    return ctype


def _make_connector(conn: Dict[str, Any]):
    from core.connectors import get_connector
    ctype = _require_sql_connector_type(conn)
    return get_connector(ctype, conn.get("config") or {})


def _broadcast(payload: dict, username: str = ""):
    if _ws_manager and _main_loop:
        if username:
            asyncio.run_coroutine_threadsafe(
                _ws_manager.broadcast_to_user(username, payload), _main_loop
            )
        else:
            asyncio.run_coroutine_threadsafe(
                _ws_manager.broadcast(payload), _main_loop
            )


# ── Phase 108: S3 raw-SQL dispatch ────────────────────────────────────────────

async def _execute_s3_raw_sql(
    *,
    conn: Dict[str, Any],
    sql: str,
    row_limit: Optional[int],
    user: Optional[dict],
    secondary_connection_id: Optional[int],
) -> Dict[str, Any]:
    """Execute a raw SQL query against an S3 connection.

    Reuses the Query Builder S3 pipeline by dispatching to
    ``execute_query_background`` in ``api.execute_api`` with:
      - a ``ParquetQueryEngine`` configured with S3 credentials
      - ``QueryConfig.files = ['__registered__:<table>', ...]``
      - ``raw_sql`` set to the user's SQL

    Validates that every table referenced in the SQL is registered on the
    connection before dispatching. Invokes the Phase 107 full-scan guardrail
    (default action = ``log``). Cross-source joins with S3 are rejected.
    """
    # Reject cross-source — S3 as primary or secondary needs the Query Builder
    # federation path; Phase 108 scope is single-source S3 raw SQL.
    if secondary_connection_id:
        raise HTTPException(
            status_code=400,
            detail="Cross-source S3 queries are not yet supported on the SQL page. "
                   "Use the Query Builder Federation view.",
        )

    if not sql or not sql.strip():
        raise HTTPException(status_code=400, detail="SQL is empty")

    conn_id = conn.get("id")
    cfg = conn.get("config") or {}
    bucket = (cfg.get("bucket_name") or "").strip()
    if not bucket:
        raise HTTPException(
            status_code=400,
            detail="S3 connection has no bucket_name configured.",
        )
    registered = cfg.get("registered_tables") or []
    if not registered:
        raise HTTPException(
            status_code=400,
            detail="S3 connection has no registered tables. Register tables "
                   "via the Connection Manager first.",
        )

    # ── Extract table references and validate against registered tables ─
    from core.sql_table_extractor import extract_table_names, validate_registered_tables
    referenced = extract_table_names(sql, dialect="duckdb")
    if not referenced:
        raise HTTPException(
            status_code=400,
            detail="Could not parse SQL to identify table references. "
                   "Ensure the query is valid DuckDB SQL and uses registered "
                   "tables by name (no catalog/schema qualifier).",
        )
    ok, missing = validate_registered_tables(referenced, registered)
    if not ok:
        raise HTTPException(
            status_code=400,
            detail=f"Table(s) not registered on this S3 connection: "
                   f"{', '.join(sorted(missing))}. "
                   f"Registered tables: {', '.join(sorted(r.get('name','') for r in registered))}.",
        )

    # Match referenced names to the canonical registered names (case-insensitive),
    # so files[] entries match exactly what setup_registered_views() expects.
    reg_by_lower = {str(r.get("name","")).lower(): r for r in registered if r.get("name")}
    canonical_tables = [reg_by_lower[t.lower()]["name"] for t in referenced
                        if t.lower() in reg_by_lower]

    # ── Phase 107 guardrail: detect full-scan on partition-aware tables ──
    try:
        from core.sql_table_extractor import has_where_on_any_column
        from core.query_guardrails import check_s3_full_scan
        # Phase 145.6 — use the same 3-tier resolver the other 4 features
        # use (BQB stream / BQB non-stream / CQB / Published API / Feed Gen).
        # _partition_columns_for above only checks tier 2 (partition_cache);
        # the resolver adds tier 1 (admin config) and tier 3 (iceberg metadata).
        from core.iceberg_partition_resolver import resolve_partition_columns
        from core.s3_utilities import make_s3_client_for_conn as _mk_s3

        _registered_list = (conn.get("config") or {}).get("registered_tables") or []
        _reg_by_name = {
            str(r.get("name", "")): r for r in _registered_list
            if isinstance(r, dict) and r.get("name")
        }
        _bucket = (conn.get("config") or {}).get("bucket_name") or ""
        # Lazy s3 client — built only if tier 3 is needed
        _sq_s3 = None
        part_cols_set = set()
        for _ct in canonical_tables:
            _rt = _reg_by_name.get(_ct)
            if (_rt and _rt.get("format") == "iceberg"
                    and _bucket and _rt.get("s3_prefix")
                    and _sq_s3 is None):
                try:
                    _sq_s3 = _mk_s3({"id": conn_id, "config": conn.get("config", {})})
                except Exception:
                    _sq_s3 = None
            _cols = resolve_partition_columns(
                registered_table=_rt,
                db_manager=_db_manager,
                connection_id=conn_id,
                table_name=_ct,
                s3_client=_sq_s3,
                bucket=_bucket,
                table_prefix=(_rt or {}).get("s3_prefix"),
            )
            part_cols_set.update(_cols)
        part_cols: List[str] = list(part_cols_set)
        has_pf = has_where_on_any_column(sql, part_cols, dialect="duckdb") if part_cols else False

        gr = check_s3_full_scan(
            db=_db_manager,
            connection_id=conn_id,
            tables=canonical_tables,
            has_partition_filter=has_pf,
            source="sql_query_api",
            user=(user or {}).get("username") if user else None,
        )
    except Exception:
        gr = None
        logger.exception("[sql_query_api] guardrail check failed (fail-open)")

    if gr is not None and gr.is_full_scan and gr.action == "block":
        raise HTTPException(status_code=400, detail=gr.message)

    # ── Build engine + query config, then dispatch to execute_query_background ─
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig as _EngineQueryConfig
    from core.s3_storage import build_s3_config
    from core.config import query_engine as _qe_cfg_global, paths as _paths_global
    from api.execute_api import execute_query_background

    # Per-user portal credential injection (matches execute_api.py:1634-1657)
    _cfg_injected = cfg
    _pri_auth = (cfg.get("auth_mode") or "").lower()
    if _pri_auth == "portal":
        try:
            from core.credential_manager import get_credential_manager
            # BF-461: .sql endpoint runs against registered S3 tables and
            # streams results — preflight refresh keeps creds alive for the
            # full scan.
            from core.config import aws_portal as _ap_sql_cfg
            _cm = get_credential_manager()
            if _cm:
                _cfg_injected = _cm.resolve_s3_credentials(
                    dict(cfg), (user or {}).get("username", "") if user else "",
                    min_lifetime_seconds=_ap_sql_cfg.preflight_min_lifetime_seconds,
                )
        except Exception:
            logger.debug("[sql_query_api] portal credential_manager resolution failed",
                         exc_info=True)
    else:
        try:
            from core.aws_portal_auth import inject_portal_creds as _inject_creds
            from core.aws_portal_auth import _current_portal_user as _cpu
            _pu = _cpu.get("")
            if _pu:
                _cfg_injected = _inject_creds(dict(cfg), _pu)
        except Exception:
            logger.debug("[sql_query_api] inject_portal_creds failed", exc_info=True)

    active_engine = ParquetQueryEngine(
        base_path=str(_paths_global.parquet_dir),
        chunk_size=_qe_cfg_global.chunk_size,
        s3_config=build_s3_config(_cfg_injected),
    )
    active_engine._registered_tables = registered
    active_engine._s3_conn_config = _cfg_injected
    active_engine._s3_bucket = bucket
    active_engine._s3_conn_id = conn_id

    engine_config = _EngineQueryConfig(
        files=[f"__registered__:{t}" for t in canonical_tables],
        limit=row_limit if row_limit else None,
    )

    execution_id = str(uuid.uuid4())
    executed_by = (user or {}).get("username") or "guest"

    # Create execution record (query_type=sql_s3 so it's distinguishable in UI)
    await _run_in_executor(
        _db_manager.create_execution,
        execution_id=execution_id,
        query_config={
            "primary_connection_id": conn_id,
            "primary_sql": sql,
            "raw_sql": sql,
            "query_type": "sql_s3",
        },
        executed_by=executed_by,
    )

    # Phase 102: audit trail
    try:
        _db_manager.audit(
            username=executed_by,
            action="sql_query_s3_execute",
            resource_type="execution",
            resource_id=execution_id,
            details={
                "connection_id": conn_id,
                "tables": canonical_tables,
                "guardrail_action": gr.action if gr else "skip",
                "is_full_scan": bool(gr.is_full_scan) if gr else False,
            },
        )
    except Exception:
        pass  # audit failure never blocks execution

    # BF-571/572 audit fix: translate cross-dialect format specifiers
    # + capture fixes for the response so the SqlQueryPage banner can
    # render "agent auto-corrected" the same way BQB / CQB do.  The
    # background worker re-translates idempotently — wasted CPU but
    # no correctness drift.
    _format_fixes: list = []
    try:
        from core.sql_dialect_translator import (
            translate_to_duckdb_with_fixes as _translate_sql_v2,
        )
        sql, _dt_dialect, _format_fixes = _translate_sql_v2(sql)
        if _format_fixes:
            logger.info(
                "sql_query_api: BF-571/572 auto-corrected %d format "
                "specifier(s) in user SQL", len(_format_fixes),
            )
    except Exception as _dt_err:
        logger.debug("sql_query_api: format normaliser skipped: %s", _dt_err)

    # Dispatch to the Query Builder background worker.
    # BF-594: track_bg_task closes the Python #88831 GC hazard.
    from core.bg_tasks import track_bg_task as _track_bg_task_sq
    _track_bg_task_sq(
        execute_query_background(
            execution_id,
            engine_config,
            query_id=None,
            active_engine=active_engine,
            executed_by=executed_by,
            raw_sql=sql,
            cache_strategy="auto",
            cache_key=None,
        )
    )

    logger.info(
        "SQL page S3 raw-SQL execution started: exec_id=%s conn_id=%s tables=%s user=%s",
        execution_id, conn_id, canonical_tables, executed_by,
    )
    return {
        "execution_id": execution_id,
        "status": "running",
        "message": "S3 SQL execution started",
        "is_cross_source": False,
        # BF-571/572: surface agent format-string repairs to the
        # SqlQueryPage frontend banner.
        "agent_format_fixes": [
            {
                "function": _f.function,
                "original_format": _f.original_format,
                "repaired_format": _f.repaired_format,
                "specifiers_fixed": _f.specifiers_fixed,
                "function_rewritten": _f.function_rewritten,
                "description": _f.describe(),
            }
            for _f in _format_fixes
        ] if _format_fixes else [],
    }


# ── Pydantic models ───────────────────────────────────────────────────────────

# ``combine_mode`` (2026-10-04): "join" | "union".  Absent = "join", the
# only mode this page had before -- a saved query keeps meaning what it meant.
_COMBINE_MODE_PATTERN = r"^(join|union)$"


class CreateSqlQueryRequest(BaseModel):
    name:                   str
    description:            Optional[str] = None
    primary_connection_id:  int
    primary_sql:            str
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None
    combine_mode:           Optional[str] = Field(default=None, pattern=_COMBINE_MODE_PATTERN)
    created_by:             Optional[str] = None


class UpdateSqlQueryRequest(BaseModel):
    name:                   Optional[str] = None
    description:            Optional[str] = None
    primary_connection_id:  Optional[int] = None
    primary_sql:            Optional[str] = None
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None
    combine_mode:           Optional[str] = Field(default=None, pattern=_COMBINE_MODE_PATTERN)


class ExecuteSqlRequest(BaseModel):
    query_id:               Optional[int] = None
    primary_connection_id:  Optional[int] = None
    primary_sql:            Optional[str] = None
    secondary_connection_id: Optional[int] = None
    secondary_sql:          Optional[str] = None
    join_config:            Optional[Dict[str, Any]] = None
    # 2026-10-04 -- this field did not exist, so a UNION request was silently
    # read as a JOIN (pydantic dropped the unknown key) and answered 200.
    combine_mode:           Optional[str] = Field(default=None, pattern=_COMBINE_MODE_PATTERN)
    # Bounds the RESULT (the combined rows on a cross-source query; it used to
    # cap EACH SIDE, so the join ran over a sample).  None / 0 = unlimited.
    row_limit:              Optional[int] = None
    # H1 (2026-10-07): the client's correlation id for this run -- carried by
    # every execution_queued event while the POST waits for a slot, and the
    # handle POST /api/execute/queued/cancel ends that wait by.
    client_request_id:      Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)


# ── Connector types ───────────────────────────────────────────────────────────

@router.get("/api/sql/connector-types")
async def get_connector_types():
    """Return all supported SQL connector types and their config field definitions."""
    from core.connectors import (
        CONNECTOR_FIELDS, CONNECTOR_DISPLAY_NAMES, SQL_CONNECTOR_TYPES,
        SQL_EDITOR_TYPES, driver_statuses,
    )
    return {
        "types": SQL_CONNECTOR_TYPES,
        # Types the SQL editor page may offer (declared in core.connectors,
        # next to the registry).  The page unions this with "s3" client-side.
        "editor_types": SQL_EDITOR_TYPES,
        "display_names": CONNECTOR_DISPLAY_NAMES,
        "fields": CONNECTOR_FIELDS,
        # 2026-09-15: whether THIS server can open each type.  ``databricks``
        # is registered and listed with no driver bundled; until now the
        # only way to find out was to save the connection and test it.
        # {type: {available, package, reason}} -- the same verdict the
        # browse routes answer with 501.
        "drivers": driver_statuses(),
    }


# ── Saved SQL Queries CRUD ────────────────────────────────────────────────────

@router.get("/api/sql/queries")
async def list_sql_queries(
    request: Request,
    active_only: bool = True,
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    items = await _run_in_executor(
        _db_manager.list_sql_queries, active_only, limit, offset
    )
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sql(request)
        items = [i for i in items if _is_owner_or_shared_sql(i, user)]
    return items


@router.post("/api/sql/queries", status_code=201)
async def create_sql_query(req: CreateSqlQueryRequest, request: Request):
    user = _get_current_user_sql(request)
    _require_sql_writer(user)
    result = await _run_in_executor(
        _db_manager.create_sql_query,
        name=req.name,
        description=req.description,
        primary_connection_id=req.primary_connection_id,
        primary_sql=req.primary_sql,
        secondary_connection_id=req.secondary_connection_id,
        secondary_sql=req.secondary_sql,
        join_config=req.join_config,
        combine_mode=req.combine_mode,
        created_by=(user or {}).get("username") or req.created_by or "guest",
    )
    # Phase 49: extract table lineage
    _extract_lineage_for_sql_query(result, req.primary_sql, req.primary_connection_id)
    return result


@router.get("/api/sql/queries/{query_id}")
async def get_sql_query(query_id: int, request: Request):
    q = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not q:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only see own or shared queries
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sql(request)
        if not _is_owner_or_shared_sql(q, user):
            raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    return q


@router.put("/api/sql/queries/{query_id}")
async def update_sql_query(query_id: int, req: UpdateSqlQueryRequest, request: Request):
    user = _get_current_user_sql(request)
    _require_sql_writer(user)
    existing = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only update their own queries
    if _auth_cfg and _auth_cfg.type != "none" and not is_admin_like(user):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(status_code=403, detail="Permission denied")
    # 2026-08-23 -- exclude_unset, NOT an is-None filter.  The save dialog
    # sends secondary_connection_id/secondary_sql/join_config as explicit
    # nulls when the user REMOVES the cross-source join; the old filter
    # discarded those nulls, so the saved query silently kept (and kept
    # executing) the join the user deleted.  Fields the client omits are
    # still left untouched.
    updates = req.model_dump(exclude_unset=True)
    result = await _run_in_executor(_db_manager.update_sql_query, query_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # Phase 49: re-extract lineage if SQL changed
    sql_text = req.primary_sql or existing.get("primary_sql", "")
    conn_id = req.primary_connection_id or existing.get("primary_connection_id")
    if sql_text:
        _extract_lineage_for_sql_query(result, sql_text, conn_id)
    return result


@router.delete("/api/sql/queries/{query_id}")
async def delete_sql_query(query_id: int, request: Request, permanent: bool = False):
    user = _get_current_user_sql(request)
    _require_sql_writer(user)
    existing = await _run_in_executor(_db_manager.get_sql_query, query_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # RLS: non-admins can only delete their own queries
    if _auth_cfg and _auth_cfg.type != "none" and not is_admin_like(user):
        if existing.get("created_by") != (user or {}).get("username"):
            raise HTTPException(status_code=403, detail="Permission denied")
    success = await _run_in_executor(
        _db_manager.delete_sql_query, query_id, not permanent
    )
    if not success:
        raise HTTPException(status_code=404, detail=f"SQL query {query_id} not found")
    # Phase 49: clean up lineage entries
    try:
        await adb(_db_manager.delete_table_lineage, "sql_query", query_id)
    except Exception:
        pass
    return {"message": "Deleted", "query_id": query_id}


# ── SQL Query Execution ───────────────────────────────────────────────────────

@router.post("/api/sql/execute")
async def execute_sql_query(req: ExecuteSqlRequest, background_tasks: BackgroundTasks,
                             request: Request = None):
    """
    Execute a SQL query on one or two SQL sources.

    Modes:
      1. Saved query by ID:         { "query_id": 5 }
      2. Inline single source:      { "primary_connection_id": 1, "primary_sql": "SELECT ..." }
      3. Inline cross-source join:  { "primary_connection_id": 1, "primary_sql": "...",
                                      "secondary_connection_id": 2, "secondary_sql": "...",
                                      "join_config": { "how": "inner", "left_on": "id", "right_on": "customer_id" } }
    """
    execution_id = str(uuid.uuid4())
    _exec_user = _get_current_user_sql(request) if request is not None else None

    # Resolve the query config
    if req.query_id:
        saved = await _run_in_executor(_db_manager.get_sql_query, req.query_id)
        if not saved:
            raise HTTPException(status_code=404, detail=f"SQL query {req.query_id} not found")
        # SECURITY 2026-08-23: executing a saved query is READING it (its
        # results, and its repaired SQL via agent_format_fixes).  The GET
        # route enforces owner/shared; execute-by-id reached the same row
        # with no check, so any authenticated user could run another
        # analyst's PRIVATE saved query by id.  Same rule, same 404.
        if _auth_cfg and _auth_cfg.type != "none":
            if not _is_owner_or_shared_sql(saved, _exec_user):
                raise HTTPException(status_code=404,
                                    detail=f"SQL query {req.query_id} not found")
        primary_conn_id    = saved["primary_connection_id"]
        primary_sql        = saved["primary_sql"]
        secondary_conn_id  = saved.get("secondary_connection_id")
        secondary_sql      = saved.get("secondary_sql")
        join_config        = saved.get("join_config")
        combine_mode       = saved.get("combine_mode")
    else:
        if not req.primary_connection_id or not req.primary_sql:
            raise HTTPException(
                status_code=400,
                detail="Must provide either query_id or (primary_connection_id + primary_sql)"
            )
        primary_conn_id   = req.primary_connection_id
        primary_sql       = req.primary_sql
        secondary_conn_id = req.secondary_connection_id
        secondary_sql     = req.secondary_sql
        join_config       = req.join_config
        combine_mode      = req.combine_mode

    # -- SECURITY 2026-08-23: role + connection entitlement BEFORE decrypt --
    # This route runs arbitrary SQL with stored credentials.  It must be at
    # least as gated as the browse routes above it and the UI RoleGuard in
    # front of it (admin/analyst).  Both modes (saved query_id and inline)
    # pass through here, so the saved-query mode cannot be used to reach a
    # connection the inline mode would refuse.
    _require_sql_writer(_exec_user)
    await asyncio.to_thread(
        _require_conn_entitlement_sql, _exec_user,
        [primary_conn_id, secondary_conn_id])

    # Validate connections
    primary_conn = await asyncio.to_thread(_get_connection_record, primary_conn_id)

    # ── Phase 141: row-security rewrite ───────────────────────────────────
    # The /api/sql/execute path bypasses the Query Builder pipeline so it
    # needs its own hook.  Primary AND secondary SQL are both rewritten
    # if row_security is enabled.  Wrapped in to_thread because the
    # rewriter does DB lookups.  Bad SQL falls through to the engine via
    # PolicyParseError handling in secure_sql; only true policy
    # enforcement failures produce HTTP 403.
    # ── ${user.*} principal variables (2026-08-29) ────────────────────────
    # Rendered against the VERIFIED session user (_exec_user), covering BOTH
    # modes (saved query_id and inline) and BOTH legs, immediately before
    # secure_sql — the rewriter parses the SQL and `${` does not parse.
    # ValueError (unknown token = authoring error) → 400 inside the helper.
    primary_sql = _render_user_vars(
        primary_sql, _exec_user, "editor SQL (/api/sql/execute primary)")
    if secondary_sql:
        secondary_sql = _render_user_vars(
            secondary_sql, _exec_user, "editor SQL (/api/sql/execute secondary)")

    # ── Cross-source request: THE capability's gates, before any work ──────
    # (2026-10-04) A secondary connection with no secondary SQL used to run
    # the primary ALONE and report it as the answer; a storage (s3) or local
    # side was refused; UNION did not exist.  Now the request is validated
    # by core.executors.cross_source_combine -- one vocabulary, one side-type
    # gate -- and a request that cannot run whole is a 400 naming why.
    from core.executors.cross_source_combine import (
        CrossSourceRefusal, refuse_unsupported_side, saved_sql_query_spec)
    secondary_conn = None
    _x_spec = None
    if secondary_conn_id and not (secondary_sql or "").strip():
        raise HTTPException(
            status_code=400,
            detail="secondary_connection_id was given without secondary_sql "
                   "-- refusing to run the primary alone and call it the "
                   "cross-source answer.")
    if secondary_conn_id:
        secondary_conn = await asyncio.to_thread(_get_connection_record, secondary_conn_id)
        try:
            # The saved-query spec: exactly the columns the pandas merge this
            # page used to run produced, so every saved query keeps its shape.
            _x_spec = saved_sql_query_spec(combine_mode, join_config)
            refuse_unsupported_side(primary_conn.get("connection_type"), "primary")
            refuse_unsupported_side(secondary_conn.get("connection_type"), "secondary")
        except CrossSourceRefusal as _x_ref:
            raise HTTPException(status_code=400, detail=str(_x_ref))

    _rs_user = _exec_user
    # 2026-09-05 -- this was a FUNCTION-LOCAL ``_RS_DIALECT_MAP``, invisible
    # to every grep for a second dialect vocabulary, and it knew six types.
    # A postgres / mysql / sqlserver / redshift / bigquery connection fell
    # through to "duckdb" and had its row-security predicate rewritten in
    # DuckDB grammar before being shipped to an engine that is not DuckDB.
    # The explicit ``_is_s3_conn`` short-circuit went with it: "s3" resolves
    # to duckdb through the resolver's own documented fallback, and asking
    # the same question twice is how the two come to disagree.
    _primary_dialect = dialect_for_connection_type(
        primary_conn.get("connection_type"))
    try:
        from core.row_security import secure_sql as _rs_secure
        if primary_sql:
            primary_sql = await asyncio.to_thread(
                _rs_secure, primary_sql,
                dialect=_primary_dialect,
                user_ctx=_rs_user,
                connection_id=primary_conn_id,
                request_id=execution_id,
            )
        if secondary_sql:
            secondary_sql = await asyncio.to_thread(
                _rs_secure, secondary_sql,
                # 2026-10-04: the SECONDARY's grammar (was hardcoded duckdb,
                # so a Snowflake/Oracle secondary's policy predicate was
                # rewritten in the wrong dialect).
                dialect=dialect_for_connection_type(
                    (secondary_conn or {}).get("connection_type")),
                user_ctx=_rs_user,
                connection_id=secondary_conn_id,
                request_id=execution_id,
            )
    except HTTPException:
        raise
    except Exception as _rs_exc:
        raise HTTPException(status_code=403,
                              detail=f"Row-security policy enforcement failed: {_rs_exc}")

    # ── Phase 108: S3 short-circuit ───────────────────────────────────────
    # S3 is not a real "SQL connector" (no Oracle-style connector class) but
    # we want the SQL Query page to support raw SQL against registered
    # parquet/iceberg tables. Dispatch to the Query Builder S3 pipeline.
    is_cross_source = bool(secondary_conn_id and secondary_sql)
    if _is_s3_conn(primary_conn) and not is_cross_source:
        return await _execute_s3_raw_sql(
            conn=primary_conn,
            sql=primary_sql,
            row_limit=req.row_limit,
            user=_exec_user,
            secondary_connection_id=None,
        )

    # A cross-source side may be ANY supported type (validated above); the
    # single-source road below is the connector road.
    primary_conn_type = (str(primary_conn.get("connection_type") or "").lower()
                         if is_cross_source
                         else _require_sql_connector_type(primary_conn))
    primary_conn_config = primary_conn.get("config") or {}

    # BF-597 (2026-05-30): per-user slot acquire for the CQB SQL connector
    # path.  Without this, a user can submit 200 heavy Trino/Snowflake/
    # Oracle queries simultaneously via CQB and starve the connector
    # pool — execute_api (BQB) is gated by `_acquire_user_slot`, but
    # before BF-597 CQB's non-S3 path bypassed it.  Now uses the same
    # QueueManager singleton so the per-user cap + queue + cancel
    # contract is consistent across CQB / BQB.
    # 2026-09-28: this lane incremented the counter and NEVER consulted
    # the global cap (query_engine.max_concurrent_global) -- one of the
    # lanes behind "11/8 concurrent queries" on the rig.  The cap is now
    # decided inside the same grant, the /api/execute shape (503 +
    # Retry-After).
    from api.execute_api import (_acquire_user_slot, _release_user_slot,
                                 _qe_cfg, _global_cap, _raise_if_load_shed,
                                 _interactive_global_wait)
    _cqb_username = (_exec_user or {}).get("username") or "guest"
    _cqb_max_per_user = _qe_cfg.max_concurrent_per_user if _qe_cfg else 50
    _cqb_max_queue    = _qe_cfg.max_queue_size if _qe_cfg else 100
    _cqb_wait_timeout = _qe_cfg.queue_wait_timeout_seconds if _qe_cfg else 60.0
    _cqb_slot_ok, _cqb_slot_reason, _cqb_slot_wait = await _acquire_user_slot(
        _cqb_username,
        _cqb_max_per_user,
        _cqb_max_queue,
        _cqb_wait_timeout,
        execution_id=execution_id,
        max_global=_global_cap(),
        # 2026-10-07: at the pod's cap, a fair bounded wait (the /api/execute
        # queue) instead of an immediate 503.
        global_wait_timeout=_interactive_global_wait(),
        client_request_id=req.client_request_id,
    )
    if not _cqb_slot_ok:
        _raise_if_load_shed(_cqb_slot_reason, _cqb_slot_wait)
        if _cqb_slot_reason == "cancelled":
            # H1: cancelled while it waited -- an answer, not "Server busy".
            from api.execute_api import _cancelled_while_queued
            return _cancelled_while_queued(execution_id)
        raise HTTPException(
            status_code=503,
            detail=(
                f"Server busy ({_cqb_slot_reason}): no slot freed within "
                f"{_cqb_wait_timeout}s."
            ),
            headers={"Retry-After": "30"},
        )

    # 2026-10-07 -- THE SLOT IS GIVEN BACK EXACTLY ONCE, whoever ends the run.
    # It used to be released ONLY in ``_run``'s finally.  A cancel that lands
    # after the pool admitted the task but before a worker thread started it
    # never runs ``_run`` (the pool's wrapper raises "Cancelled before start",
    # or Future.cancel() succeeds on a future PENDING in the executor queue),
    # and the request had already answered 200 -- so nothing released it.
    # Found live by capacity_wait_proof (cap full, 8 holders cancelled, one
    # holder's counter stuck at 1 until restart).  Now: the end of ``_run``,
    # the pool task's DONE-CALLBACK (fires on every ending, a cancel before
    # start included), or a submit that never made a task -- first one wins.
    _cqb_release_lock = threading.Lock()
    _cqb_released = [False]

    def _release_cqb_slot_once() -> None:
        with _cqb_release_lock:
            if _cqb_released[0]:
                return
            _cqb_released[0] = True
        try:
            _release_user_slot(_cqb_username)
        except Exception as _rel_exc:
            logger.warning("BF-597: _release_user_slot failed for %s: %s",
                           _cqb_username, _rel_exc)

    # Create DB execution record
    try:
        exec_record = await _run_in_executor(
            _db_manager.create_execution,
            execution_id=execution_id,
            query_config={
                "primary_connection_id": primary_conn_id,
                "primary_sql":           primary_sql,
                "secondary_connection_id": secondary_conn_id,
                "secondary_sql":         secondary_sql,
                "join_config":           join_config,
                "query_type":            "sql",
            },
            # 2026-09-24: this row had NO owner, so under login every
            # non-admin was refused the status and results of their own SQL
            # query (the read rule fails closed on an ownerless execution).
            executed_by=_cqb_username,
        )
    except Exception:
        # BF-597: release slot on create_execution failure so the cap
        # doesn't leak.  Re-raise so the user sees the error.
        _release_cqb_slot_once()
        raise

    # Capture event loop for background thread broadcasts
    try:
        current_loop = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    _sql_user = (_exec_user or {}).get("username") or ""

    def _run(cancel_event=None):
        from core.cross_source_engine import execute_single_source_query

        def _emit(payload):
            loop = current_loop or _main_loop
            if _ws_manager and loop:
                _msg = {**payload, "execution_id": execution_id, "username": _sql_user}
                if _sql_user:
                    asyncio.run_coroutine_threadsafe(
                        _ws_manager.broadcast_to_user(_sql_user, _msg), loop,
                    )
                else:
                    asyncio.run_coroutine_threadsafe(
                        _ws_manager.broadcast(_msg), loop,
                    )

        try:
            _emit({"type": "execution_progress", "data": {"status": "starting"}})

            def _progress(info):
                _emit({"type": "execution_progress", "data": {"status": info.get("step"), **info}})

            _x_disclosure = None
            if is_cross_source:
                # THE cross-source capability: each side on its own engine
                # (connector, storage or local), combined in DuckDB, the
                # row_limit bounding the RESULT with an overflow sentinel.
                from core.cross_source_engine import execute_cross_source_sql
                result = execute_cross_source_sql(
                    primary_conn={**primary_conn, "id": primary_conn_id},
                    primary_sql=primary_sql,
                    secondary_conn={**(secondary_conn or {}),
                                    "id": secondary_conn_id},
                    secondary_sql=secondary_sql,
                    spec=_x_spec,
                    execution_id=execution_id,
                    row_limit=req.row_limit,
                    progress_callback=_progress,
                    cancel_event=cancel_event,
                    db_manager=_db_manager,
                )
                _x_disclosure = result.disclosure
            else:
                result = execute_single_source_query(
                    conn_type=primary_conn_type,
                    conn_config=primary_conn_config,
                    # 2026-09-17 — the id the cross-source branch above has
                    # always passed.  Without it the engine cannot pool, so
                    # the SINGLE-source case (the common one) opened and
                    # closed a source connection per query while the
                    # cross-source case reused one.
                    conn_id=primary_conn_id,
                    # Names the pool entry in GET /api/admin/connection-pools.
                    # That view is a diagnostic surface: a blank name there
                    # reads as "unknown connection" when we knew it all along.
                    conn_name=(primary_conn or {}).get("name", ""),
                    sql=primary_sql,
                    execution_id=execution_id,
                    row_limit=req.row_limit,
                    progress_callback=_progress,
                    cancel_event=cancel_event,
                )

            # Update execution record
            # 2026-09-27 -- which engine answered (core/engine_attribution.py):
            # a cross-source run combines two sources in-process; a single
            # source runs AT that source.
            from core.engine_attribution import (
                engine_for_connection_type as _engine_for_ct,
                with_engine as _with_engine,
            )
            _engine_key = ("cross_source" if is_cross_source
                           else _engine_for_ct(primary_conn_type))
            _upd = dict(
                execution_id=execution_id,
                status="completed",
                engine=_engine_key,
                total_rows=result.total_rows,
                output_file=result.output_path,
            )
            if _x_disclosure:
                _upd["files_metadata"] = {"cross_source": _x_disclosure}
            _db_manager.update_execution(**_upd)

            # NOTE: raw execution CSVs are temporary grid-pagination files.
            # They are NOT registered in the Download Center.
            # The user exports explicitly via the Export button, which creates a named download.

            # Bump execution count if from saved query
            if req.query_id:
                _db_manager.increment_sql_query_execution(req.query_id)

            _emit(_with_engine({
                "type": "execution_completed",
                "stats": {
                    "total_rows": result.total_rows,
                    "duration_seconds": result.duration_seconds,
                    "primary_rows": result.primary_rows,
                    "secondary_rows": result.secondary_rows,
                    **({"cross_source": _x_disclosure} if _x_disclosure else {}),
                }
            }, _engine_key))
            logger.info(
                f"[{execution_id}] SQL execution completed: "
                f"{result.total_rows} rows in {result.duration_seconds:.2f}s"
            )

        except Exception as exc:
            logger.exception(f"[{execution_id}] SQL execution failed")
            # 2026-10-10 -- THE text every lane records (core.connectors.base
            # .describe_source_failure).  ``str(exc)`` stored the transport's
            # ``HTTPSConnectionPool(...) Max retries exceeded`` for an
            # untrusted certificate and the driver's repr
            # ``TrinoUserError(type=USER_ERROR, name=PERMISSION_DENIED, ...)``
            # for a hidden column, while the connection test and the browse
            # routes gave the sentence.  One classifier, one sentence.
            from core.connectors.base import describe_source_failure
            _failure_text = describe_source_failure(exc, primary_conn_type)
            try:
                _db_manager.update_execution(
                    execution_id=execution_id,
                    status="failed",
                    error_message=_failure_text,
                )
            # 2026-10-07: was ``except Exception as exc`` -- the same name as
            # the query's failure, and Python DELETES an except target when
            # the block ends, so a failed status write turned the
            # execution_failed message below into a NameError and the user
            # was told nothing.
            except Exception as _upd_exc:
                logging.getLogger(__name__).warning("%s failed: %s", "sql_query_api", _upd_exc, exc_info=True)
            # 2026-10-07: the failure carries THE agent suggestion every
            # road carries (core.agents.inline_suggestion) -- the UI renders
            # it and decides nothing.  This runs in a worker thread.
            _failed = {"type": "execution_failed", "error": _failure_text}
            from core.agents.inline_suggestion import suggestion_for_failure
            _sugg = suggestion_for_failure(_failure_text, type(exc).__name__,
                                           db_manager=_db_manager)
            if _sugg:
                _failed["agent_suggestion"] = _sugg
            _emit(_failed)
        finally:
            # BF-597: release the per-user slot acquired above.  Runs in
            # the worker thread; QueueManager.release_slot is thread-safe
            # (lock-protected) and can be called from any thread.  Once:
            # the pool task's done-callback below is the other door.
            _release_cqb_slot_once()

    # Submit via unified worker pool (falls back to legacy executor).
    # Phase 0 reports rewire (2026-08-08): await the async submit — the old
    # submit_sync blocked the event loop in _acquire_slot while waiting for
    # an INTERACTIVE slot (same defect class as reports_api execute_report;
    # pattern: execute_api.py:6437).  RuntimeError fallback semantics
    # unchanged.
    try:
        from core.worker_pool import get_pool, WorkType
        _cqb_record = await get_pool().submit(
            WorkType.INTERACTIVE, _run,
            execution_id=execution_id, username=_cqb_username)
        # Fires when the task ENDS however it ends -- including a cancel
        # before ``_run`` ever started (see _release_cqb_slot_once).
        _cqb_future = getattr(_cqb_record, "future", None)
        if _cqb_future is not None:
            _cqb_future.add_done_callback(lambda _f: _release_cqb_slot_once())
    except RuntimeError:
        background_tasks.add_task(lambda: _sql_executor.submit(_run))
    except BaseException:
        # 2026-09-28: a submit that never reached _run (the INTERACTIVE
        # queue full, or this request cancelled while queued) leaves _run's
        # finally -- the only release of the slot acquired above -- unrun,
        # and the user's counter leaked one slot per such refusal until the
        # process restarted.  Release here, then let the refusal propagate.
        _release_cqb_slot_once()
        raise

    return {
        "execution_id": execution_id,
        "status": "running",
        "message": "SQL execution started",
        "is_cross_source": is_cross_source,
        **({"combine_mode": _x_spec.mode} if _x_spec is not None else {}),
    }


# ── Schema browsing ───────────────────────────────────────────────────────────

@router.get("/api/sql/connections/{connection_id}/catalogs")
async def list_catalogs(connection_id: int, request: Request):
    conn = await _require_conn_access_sql(connection_id, request)  # SECURITY
    # Phase 108: S3 has no catalogs — expose a single synthetic "default"
    # so the schema browser tree works without special-casing the frontend.
    if _is_s3_conn(conn):
        return ["default"]
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_catalogs()
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise connector_http_error(e, conn.get("connection_type", ""),
                                   context="Error listing catalogs")


@router.get("/api/sql/connections/{connection_id}/schemas")
async def list_schemas(connection_id: int, request: Request, catalog: str = Query(...)):
    conn = await _require_conn_access_sql(connection_id, request)  # SECURITY
    # Phase 108: S3 has no schemas — return single synthetic "default"
    if _is_s3_conn(conn):
        return ["default"]
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_schemas(catalog)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise connector_http_error(e, conn.get("connection_type", ""),
                                   context="Error listing schemas")


@router.get("/api/sql/connections/{connection_id}/tables")
async def list_tables(
    connection_id: int,
    request: Request,
    catalog: str = Query(...),
    schema: str  = Query(...),
):
    conn = await _require_conn_access_sql(connection_id, request)  # SECURITY
    # Phase 108: S3 tables come from the connection's registered_tables list.
    # We also attach the list of partition columns so the frontend can render
    # a "click-to-insert" starter query that includes a WHERE on a partition
    # column (avoids the default full-scan).
    if _is_s3_conn(conn):
        cfg = conn.get("config") or {}
        registered = cfg.get("registered_tables") or []
        out: List[Dict[str, Any]] = []
        for r in registered:
            name = r.get("name")
            if not name:
                continue
            out.append({
                "name": name,
                "type": "table",
                "format": r.get("format", "parquet"),
                "partition_columns": _partition_columns_for(connection_id, name),
            })
        return out
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_tables(catalog, schema)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise connector_http_error(e, conn.get("connection_type", ""),
                                   context="Error listing tables")


@router.get("/api/sql/connections/{connection_id}/columns")
async def list_columns(
    connection_id: int,
    request: Request,
    catalog: str = Query(...),
    schema:  str = Query(...),
    table:   str = Query(...),
):
    conn = await _require_conn_access_sql(connection_id, request)  # SECURITY
    # Phase 108 / 2026-08-23: S3 columns come from the LOCAL column catalog
    # (``ColumnCatalog.get_entry`` -- never touches the source, migrates any
    # legacy ``schema_cache`` row on sight).  The previous direct
    # ``get_schema_cache`` read was a second spelling of the same fact and
    # ALSO ran its DB query on the event loop.
    if _is_s3_conn(conn):
        from core.schema_catalog import ColumnCatalog

        def _catalog_cols():
            entry = ColumnCatalog(_db_manager).get_entry(connection_id, table)
            cols = (entry or {}).get("columns") or []
            out = []
            for c in cols:
                if not isinstance(c, dict):
                    continue
                out.append({
                    "name": c.get("name") or c.get("column") or "",
                    "type": (c.get("data_type") or c.get("type")
                             or "unknown"),
                })
            return [c for c in out if c["name"]]
        return await asyncio.to_thread(_catalog_cols)
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.list_columns(catalog, schema, table)
        finally:
            connector.close()
    try:
        return await _run_in_executor(_do)
    except HTTPException:
        raise
    except Exception as e:
        raise connector_http_error(e, conn.get("connection_type", ""),
                                   context="Error listing columns")


@router.post("/api/sql/connections/{connection_id}/test")
async def test_sql_connection(connection_id: int, request: Request):
    conn = await _require_conn_access_sql(connection_id, request)  # SECURITY
    def _do():
        connector = _make_connector(conn)
        try:
            return connector.test_connection()
        finally:
            connector.close()
    try:
        result = await _run_in_executor(_do)
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("message", "Connection failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        # 2026-09-15 — this route already answers a FAILED test with 400 + the
        # reason (see the handled path above).  Raising 500 here sent the same
        # kind of answer through main.py's CWE-209 chokepoint, which replaces
        # every 5xx detail with "contact support" -- so a test that knew exactly
        # why it failed reported nothing.  ``explain_failure`` is the sanitising
        # renderer, so its text is safe to return; answer in this route's OWN
        # established shape rather than inventing a second one.
        from core.error_sanitizer import explain_failure
        _label = (f"Connection test for "
                  f"'{conn.get('name') or connection_id}' (id {connection_id})")
        raise HTTPException(
            status_code=400,
            detail=explain_failure(e, subject=_label,
                                   config=conn.get("config") or {}))
