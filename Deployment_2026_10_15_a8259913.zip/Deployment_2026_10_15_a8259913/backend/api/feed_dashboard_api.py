"""The feed DASHBOARD routes (2026-10-12, owner request R1; core/feed/dashboard.py).

``GET /api/feed-dashboard`` -- the business date's tasks grouped by the
defined Feed Groups, with the OTG's status chips; ``GET /api/feed-dashboard/
task`` -- one task's dependency cards (gate verdict + the upstream messages
that arrived).  Both scoped by THE feed view rule: a feed the caller may not
view is not on the dashboard, and its task detail is the feed route's 404/403.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user, require_admin_read
from core.db_async import adb
from core.feed import dashboard

router = APIRouter(tags=["feed-dashboard"])


def _fa():
    import api.feed_api as fa
    if fa._db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503, detail="The feed dashboard is not wired")
    return fa


@router.get("/api/feed-dashboard")
async def feed_dashboard(business_date: Optional[date] = None, run_date: Optional[date] = None,
                         search: str = "", status: str = Query("", pattern="^[a-z_]*$"),
                         page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                         group_by: str = Query("feed_group", pattern="^(feed_group|template|status|none)$"),
                         user: dict = Depends(get_current_user)):
    fa = _fa()
    allowed = list(dashboard.STATUSES) + ["sla_breached", "sla_at_risk"]
    if status and status not in allowed:
        raise HTTPException(status_code=422, detail=f"status must be one of {allowed}")
    if business_date and run_date:
        raise HTTPException(status_code=422, detail="Give a business date or a run date, not both")
    # 2026-10-13 -- ``run_date``: every task worked on that day, whatever its
    # business date (a September month end delivered on 13 October)
    bd = None if run_date else (business_date or datetime.now(timezone.utc).date())
    # 2026-10-12 -- admin / support / no-auth see every feed: no list to build.
    visible = None if fa._sees_every_feed(user) else await adb(fa._visible_feed_ids, user)
    return await adb(dashboard.build, fa._db_manager, bd, visible_feed_ids=visible,
                     search=search, status=status, page=page, page_size=page_size,
                     group_by=group_by, run_date=run_date)


@router.get("/api/feed-dashboard/task")
async def feed_dashboard_task(feed_id: int, business_date: date,
                              user: dict = Depends(get_current_user)):
    fa = _fa()
    feed = await fa._require_feed(feed_id, user, write=False)
    return await adb(dashboard.task_detail, fa._db_manager, feed, business_date)


@router.get("/api/feed-sla-board")
async def feed_sla_board(business_date: Optional[date] = None,
                         user: dict = Depends(get_current_user)):
    """2026-10-12 (owner R5) -- every visible feed's SLA verdict for the date
    (core/feed/sla_board.py), worst first."""
    from core.feed import sla_board
    fa = _fa()
    bd = business_date or datetime.now(timezone.utc).date()
    # 2026-10-12 -- admin / support / no-auth see every feed: no list to build.
    visible = None if fa._sees_every_feed(user) else await adb(fa._visible_feed_ids, user)
    return await adb(sla_board.build, fa._db_manager, bd, visible_feed_ids=visible)


@router.get("/api/admin/feeds/iceberg-commits")
async def iceberg_commits(days: int = Query(7, ge=0, le=90),
                          page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                          user: dict = Depends(require_admin_read)):
    """2026-10-12 (owner R4) -- the Iceberg monitor: watched tables, each new
    commit's inspection, and the feeds it released (core/feed/iceberg_monitor.py).
    The inspections are PAGED (core/feed/paging.py)."""
    from core.feed import iceberg_monitor
    fa = _fa()
    return await adb(iceberg_monitor.build, fa._db_manager, days=days, page=page, page_size=page_size)


# ── the UPSTREAM CONTRACT's vocabulary: DATA, edited here (2026-10-12) ─────
# The owner: "all db driven ... no hardcoded in code".  Environments (which
# side, its label, how a dependency name and a message say it) and message
# tokens ({version} -> VERSION_NUMBER) are rows; admins edit them, everyone
# reads them (the board needs the labels).

from pydantic import BaseModel, Field  # noqa: E402

from api.deps import require_admin  # noqa: E402


class EnvironmentBody(BaseModel):
    side: str = Field(pattern="^(primary|secondary)$")
    label: str = Field(min_length=1, max_length=60)
    dependency_suffixes: list[str] = Field(default_factory=list)
    message_field: Optional[str] = Field(default=None, max_length=120)
    message_values: list[str] = Field(default_factory=list)
    sort_order: int = 0
    is_active: bool = True


class MessageTokenBody(BaseModel):
    token: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_]{0,59}$")
    message_field: str = Field(min_length=1, max_length=120)
    description: Optional[str] = Field(default=None, max_length=500)
    is_active: bool = True


@router.get("/api/admin/feed-environments")
async def list_environments(user: dict = Depends(get_current_user)):
    fa = _fa()
    return {"environments": await adb(fa._db_manager.list_feed_environments, False)}


@router.put("/api/admin/feed-environments")
async def put_environment(body: EnvironmentBody, user: dict = Depends(require_admin)):
    from core.feed import environments
    fa = _fa()
    if body.message_field and not body.message_values:
        raise HTTPException(status_code=422, detail="message_values are required with a message_field "
                                                    "(the values that mean THIS environment)")
    row = await adb(fa._db_manager.upsert_feed_environment, body.model_dump(), user.get("username"))
    environments.invalidate()
    return row


@router.get("/api/admin/feed-message-tokens")
async def list_message_tokens(user: dict = Depends(get_current_user)):
    fa = _fa()
    return {"tokens": await adb(fa._db_manager.list_feed_message_tokens, False)}


@router.put("/api/admin/feed-message-tokens")
async def put_message_token(body: MessageTokenBody, user: dict = Depends(require_admin)):
    from core.feed import upstream_contract
    fa = _fa()
    row = await adb(fa._db_manager.upsert_feed_message_token, body.model_dump(), user.get("username"))
    upstream_contract.invalidate_tokens()
    return row


class MessageFieldBody(BaseModel):
    field: str = Field(min_length=1, max_length=120)
    label: str = Field(min_length=1, max_length=60)
    sort_order: int = 0
    on_tile: bool = True
    on_monitor: bool = True
    identifies: bool = False
    is_active: bool = True


@router.get("/api/admin/feed-message-fields")
async def list_message_fields(user: dict = Depends(get_current_user)):
    fa = _fa()
    return {"fields": await adb(fa._db_manager.list_feed_message_fields, False)}


@router.put("/api/admin/feed-message-fields")
async def put_message_field(body: MessageFieldBody, user: dict = Depends(require_admin)):
    from core.feed import message_fields
    fa = _fa()
    row = await adb(fa._db_manager.upsert_feed_message_field, body.model_dump(), user.get("username"))
    message_fields.invalidate()
    return row


# ── restatement + alerts (2026-10-12): every behaviour is a row ──────────

class RestatementPolicyBody(BaseModel):
    scope: str = Field(pattern="^(global|feed_group|template|feed)$")
    scope_id: Optional[int] = None
    name: Optional[str] = Field(default=None, max_length=80)
    on_new_message: str = "decide"
    same_run_date: str = "decide"
    window: str = "next_business_date"
    window_days: Optional[int] = None
    is_active: bool = True


@router.get("/api/admin/feed-restatement-policies")
async def list_restatement_policies(user: dict = Depends(get_current_user)):
    from core.feed.restatement import POLICY_ACTIONS, WINDOWS
    fa = _fa()
    return {"policies": await adb(fa._db_manager.list_restatement_policies, False),
            "actions": list(POLICY_ACTIONS), "windows": list(WINDOWS)}


@router.put("/api/admin/feed-restatement-policies")
async def put_restatement_policy(body: RestatementPolicyBody, user: dict = Depends(require_admin)):
    from core.feed.restatement import validate_policy
    fa = _fa()
    data = body.model_dump()
    why = validate_policy(data)
    if why:
        raise HTTPException(status_code=422, detail=why)
    return await adb(fa._db_manager.upsert_restatement_policy, data, user.get("username"))


@router.delete("/api/admin/feed-restatement-policies/{policy_id}")
async def delete_restatement_policy(policy_id: int, user: dict = Depends(require_admin)):
    fa = _fa()
    if not await adb(fa._db_manager.delete_restatement_policy, policy_id):
        raise HTTPException(status_code=404, detail=f"policy {policy_id} not found")
    return {"deleted": policy_id}


class AlertKindBody(BaseModel):
    kind: str = Field(pattern=r"^[a-z][a-z0-9_]{0,59}$")
    title: str = Field(min_length=1, max_length=120)
    severity: int = Field(ge=0, le=5)
    alert_group: str
    to_bell: bool = True
    to_email: bool = False
    to_netcool: bool = False
    clears_when: str = Field(min_length=1, max_length=255)
    is_active: bool = True


@router.get("/api/admin/feed-alert-kinds")
async def list_alert_kinds(user: dict = Depends(get_current_user)):
    from core.feed.netcool import ALERT_GROUPS
    fa = _fa()
    return {"kinds": await adb(fa._db_manager.list_feed_alert_kinds, False),
            "alert_groups": sorted(ALERT_GROUPS)}


@router.put("/api/admin/feed-alert-kinds")
async def put_alert_kind(body: AlertKindBody, user: dict = Depends(require_admin)):
    from core.feed import feed_alerts
    from core.feed.netcool import ALERT_GROUPS
    fa = _fa()
    if body.alert_group not in ALERT_GROUPS:
        raise HTTPException(status_code=422, detail=f"alert_group must be one of {sorted(ALERT_GROUPS)} "
                                                    f"-- the console routes by group")
    row = await adb(fa._db_manager.upsert_feed_alert_kind, body.model_dump(), user.get("username"))
    feed_alerts.invalidate()
    return row


class AlertRouteBody(BaseModel):
    scope: str = Field(pattern="^(global|feed_group|template|feed)$")
    scope_id: Optional[int] = None
    kind: Optional[str] = None
    channel: str = Field(pattern="^(bell|email)$")
    target: str = Field(min_length=1, max_length=255)


@router.get("/api/admin/feed-alert-routes")
async def list_alert_routes(user: dict = Depends(get_current_user)):
    fa = _fa()
    return {"routes": await adb(fa._db_manager.list_feed_alert_routes)}


@router.post("/api/admin/feed-alert-routes", status_code=201)
async def create_alert_route(body: AlertRouteBody, user: dict = Depends(require_admin)):
    from core.email_service import _valid_recipients
    fa = _fa()
    if body.scope != "global" and body.scope_id is None:
        raise HTTPException(status_code=422, detail=f"scope {body.scope!r} needs a scope_id")
    if body.channel == "email" and not _valid_recipients([body.target]):
        raise HTTPException(status_code=422, detail=f"{body.target!r} is not an e-mail address")
    return await adb(fa._db_manager.create_feed_alert_route, body.model_dump(), user.get("username"))


@router.delete("/api/admin/feed-alert-routes/{route_id}")
async def delete_alert_route(route_id: int, user: dict = Depends(require_admin)):
    fa = _fa()
    if not await adb(fa._db_manager.delete_feed_alert_route, route_id):
        raise HTTPException(status_code=404, detail=f"route {route_id} not found")
    return {"deleted": route_id}


@router.get("/api/feed-alerts")
async def list_feed_alerts(feed_id: Optional[int] = None, business_date: Optional[date] = None,
                           status: Optional[str] = Query(None, pattern="^(open|cleared)$"),
                           page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                           user: dict = Depends(require_admin_read)):
    from core.feed.feed_alerts import public
    from core.feed.paging import block, paging
    fa = _fa()
    p = paging(page, page_size)
    rows = await adb(fa._db_manager.list_feed_alerts, feed_config_id=feed_id,
                     business_date=business_date, status=status, limit=p.page_size, offset=p.offset)
    total = await adb(fa._db_manager.count_feed_alerts, feed_config_id=feed_id,
                      business_date=business_date, status=status)
    return {"alerts": [public(r) for r in rows], "count": len(rows), "paging": block(total, p, len(rows))}


class DecisionAnswerBody(BaseModel):
    action: str = Field(pattern="^(rerun|keep)$")
    reason: str = Field(default="", max_length=2000)


@router.post("/api/feed-regeneration-decisions/{decision_id}/answer")
async def answer_decision(decision_id: int, body: DecisionAnswerBody,
                          user: dict = Depends(get_current_user)):
    """Re-run or keep: a re-run hold, a restatement after close or a
    superseded delivery -- ONE action (core/feed/restatement.py::answer)."""
    from core.feed.restatement import AnswerRefused, answer
    fa = _fa()
    try:
        return await adb(answer, fa._db_manager, decision_id, user=user,
                         action=body.action, reason=body.reason)
    except AnswerRefused as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))


@router.get("/api/feeds/{feed_id}/definition-timeline")
async def definition_timeline(feed_id: int, user: dict = Depends(get_current_user)):
    """WHEN each saved definition change applies, newest first
    (core/feed/definition_timeline.py)."""
    from core.feed.definition_timeline import describe
    fa = _fa()
    await fa._require_feed(feed_id, user, write=False)
    return {"feed_id": feed_id, "timeline": await adb(describe, fa._db_manager, feed_id)}
