"""
Authentication endpoints — login / logout / me / config.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_auth_dependencies(limiter, auth_cfg)`` once at startup
    (in main.py after config is loaded).
"""
from __future__ import annotations

import os
import logging
from typing import Optional

import anyio
from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, SecretStr
from starlette.concurrency import run_in_threadpool

from api.deps import get_current_user
from core.audit import audit_event
from core.sessions import create_session, destroy_session

logger = logging.getLogger(__name__)

router = APIRouter(tags=["auth"])

# ── Module-level singletons set by main.py at startup ─────────────────────────
_limiter    = None   # slowapi.Limiter
_auth_cfg   = None   # core.config.auth singleton
_db_manager = None   # core.database.DatabaseManager

#: How long a browser may reuse GET /auth/public-key without asking again
#: (Cache-Control max-age).  The key never rotates on a schedule -- it is
#: loaded once per process and changes only across a process start without
#: its persisted file -- and the stale-key recovery revalidates, so a cached
#: copy is never USED past a rotation.  Short anyway: five minutes.
_PUBLIC_KEY_MAX_AGE_SECONDS = 300

# ── Which arm a login used (2026-09-29) ──────────────────────────────────────
#
# /auth/login accepts two body shapes: ``password_encrypted`` (the browser
# encrypted the password with GET /auth/public-key, RSA-OAEP) and the
# plaintext ``password`` (the browser could not fetch or use the key --
# frontend/src/services/loginCrypto.ts falls back on ANY non-2xx, a network
# error or no crypto.subtle -- or a curl / Postman client).  Until now
# nothing recorded which, so an org-wide downgrade (the 2026-09-29 public-key
# limiter) was invisible.  Every login / login_failed audit row now carries
# ``login_transport`` with one of these two values.
LOGIN_TRANSPORT_ENCRYPTED = "encrypted"
LOGIN_TRANSPORT_PLAINTEXT = "plaintext_fallback"

#: ``auth.login_plaintext_fallback = "refuse"`` answers a plaintext login
#: with 400 and this stable code; the sentence is what the browser shows.
LOGIN_PLAINTEXT_REFUSED_CODE = "login_plaintext_refused"
LOGIN_PLAINTEXT_REFUSED_MESSAGE = (
    "This server requires the encrypted login. Your browser could not fetch "
    "the login key -- reload the page; if it persists, tell your administrator."
)

#: A plaintext login under "allow" logs ONE warning per (process, account)
#: per this window -- the audit row carries every one; the log is for the
#: operator's eye, and per-request would be spam in a 9am wave.
_PLAINTEXT_WARN_WINDOW_SECONDS = 3600
_plaintext_warned_at: dict[str, float] = {}
_PLAINTEXT_WARNED_MAX = 10_000


def _warn_plaintext_login_once(username: str) -> bool:
    """Log the plaintext-fallback warning for ``username`` unless this
    process already did within the window.  Returns True when it logged.
    Keyed on the stripped, lower-cased account (the limiter's spelling)."""
    import time as _time
    account = (username or "").strip().lower()
    now = _time.monotonic()
    last = _plaintext_warned_at.get(account)
    if last is not None and now - last < _PLAINTEXT_WARN_WINDOW_SECONDS:
        return False
    if len(_plaintext_warned_at) >= _PLAINTEXT_WARNED_MAX:
        # Bounded: drop the expired entries; if none expired, start over
        # (the cost is one extra warning per account, never unbounded memory).
        expired = [k for k, t in _plaintext_warned_at.items()
                   if now - t >= _PLAINTEXT_WARN_WINDOW_SECONDS]
        for k in expired:
            _plaintext_warned_at.pop(k, None)
        if len(_plaintext_warned_at) >= _PLAINTEXT_WARNED_MAX:
            _plaintext_warned_at.clear()
    _plaintext_warned_at[account] = now
    logger.warning(
        "Login for user %r used the PLAINTEXT fallback (login_transport=%s): the "
        "client could not fetch or use the login key (GET /auth/public-key) and "
        "posted the password in the request body.  Allowed by "
        "auth.login_plaintext_fallback=allow; the audit row carries the arm.  "
        "Further plaintext logins for this account are not logged for %ds.",
        username, LOGIN_TRANSPORT_PLAINTEXT, _PLAINTEXT_WARN_WINDOW_SECONDS,
    )
    return True


def set_auth_dependencies(limiter, auth_cfg, db_manager=None) -> None:
    """Called once from main.py after config + limiter are created."""
    global _limiter, _auth_cfg, _db_manager
    _limiter    = limiter
    _auth_cfg   = auth_cfg
    _db_manager = db_manager


# ── Pydantic models ───────────────────────────────────────────────────────────

class _LoginRequest(BaseModel):
    username: str
    # Legacy plaintext field — kept for curl / Postman / mobile clients that
    # don't implement client-side RSA encryption.  Optional now; one of
    # ``password`` or ``password_encrypted`` MUST be present.
    password: Optional[SecretStr] = None  # SecretStr keeps it out of repr/tracebacks
    # Client-side RSA-OAEP-SHA256 ciphertext of the password, base64-encoded.
    # Frontend fetches the public key from /auth/public-key and uses Web Crypto
    # API to encrypt the password before sending — closes the "password visible
    # in DevTools Network tab" gap.
    password_encrypted: Optional[str] = None
    # Short SHA-256 fingerprint of the public key the frontend encrypted with.
    # Surface in the request so we can detect rotation-races server-side AND
    # respond with a structured 400 the frontend can interpret as "refetch
    # the public key and retry".  Optional — if omitted we just try to decrypt.
    key_fingerprint: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_container_env() -> bool:
    """Detect if running inside Docker/OpenShift/Kubernetes."""
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/auth/login")
async def login(request: Request, req: _LoginRequest):
    """
    Authenticate and return a session token + user info.

    Password is verified once, then discarded — only the opaque token is
    persisted server-side.  Clients send the token as ``Bearer <token>``
    on subsequent requests.

    Rate-limited per (client address, username) -- 10 attempts/minute by
    default -- under a looser per-address ceiling (300/minute).  Both are
    ``auth.login_rate_limit_*`` config keys.
    """
    # Rate check using the custom sliding-window limiter.
    # BF-150: Import both symbols together so RateLimitExceededError is always available
    #
    # 2026-09-29 -- keyed on (client address, username), NOT the address
    # alone.  Behind an ingress request.client.host is the ingress for every
    # user (unless server.forwarded_allow_ips trusts it), so one per-address
    # bucket of 10/min was ONE bucket for the whole organisation and the
    # 11th person in a 9am login wave got 429.  Per account the brute-force
    # cap is unchanged (auth.login_rate_limit_per_account_per_minute); a
    # looser per-address ceiling (auth.login_rate_limit_per_ip_per_minute)
    # still bounds password spraying from one address.  The username is
    # stripped and lower-cased so case variants share one bucket.  The
    # account bucket is checked FIRST so a locked-out account does not
    # spend its colleagues' shared address budget.
    if _limiter is not None:
        try:
            from core.rate_limiter import check_rate_limit, RateLimitExceededError
            from core.config import auth as _login_limits
            ip = (request.client.host if request.client else "unknown")
            account = (req.username or "").strip().lower()
            check_rate_limit(
                "auth_login", f"{ip}|{account}",
                limit=_login_limits.login_rate_limit_per_account_per_minute,
                window_seconds=60)
            check_rate_limit(
                "auth_login_ip", ip,
                limit=_login_limits.login_rate_limit_per_ip_per_minute,
                window_seconds=60)
        except RateLimitExceededError as exc:
            raise HTTPException(
                status_code=429,
                detail=f"Too many login attempts. Retry after {exc.retry_after}s.",
                headers={"Retry-After": str(exc.retry_after)},
            )
        except ImportError:
            pass  # rate_limiter module not available — skip rate limiting

    # ── Resolve the plaintext password from one of two payload shapes ──────
    # Preferred: ``password_encrypted`` (Web-Crypto RSA-OAEP ciphertext from
    # the React frontend).  Fallback: ``password`` (legacy plaintext for
    # curl / Postman / mobile / any non-browser client).  Exactly one must
    # be present; the request is rejected with 400 if neither is provided.
    #
    # 2026-09-29 -- the arm is RECORDED (``login_transport`` on every audit
    # row below) and the plaintext arm is a DECLARED policy,
    # ``auth.login_plaintext_fallback``: "allow" (default) keeps it working
    # -- the transport is TLS at the route, and refusing would turn a
    # public-key hiccup on one pod into an org-wide login outage -- with one
    # WARNING per (process, account, hour); "refuse" answers 400
    # ``login_plaintext_refused`` (a stable code plus the sentence the
    # browser shows) and creates no session.  The limiter above has already
    # counted the attempt either way: a refused plaintext POST is charged
    # exactly like every other 400 on this route (a stale key, a missing
    # password) -- the buckets count ATTEMPTS, there is no wrong-password
    # counter to charge, and a browser under "refuse" never sends it, so a
    # real user pays nothing; an unmetered 400 would be a free probe.
    plaintext_password: str
    login_transport: str
    if req.password_encrypted:
        login_transport = LOGIN_TRANSPORT_ENCRYPTED
        try:
            from core.login_crypto import decrypt_password, LoginCryptoError
            plaintext_password = decrypt_password(req.password_encrypted)
        except LoginCryptoError as exc:
            # Structured 400 — the frontend interprets the detail prefix
            # `login_crypto_stale_key` as "refetch /auth/public-key and retry".
            # We DO NOT echo back the underlying cryptography exception class
            # name to avoid padding-oracle hints.
            logger.warning(
                "Login crypto: rejected encrypted payload for user %r (fingerprint %r): %s",
                req.username, req.key_fingerprint, exc,
            )
            if _db_manager:
                audit_event(_db_manager, {"username": req.username}, request,
                            "login_failed", "auth",
                            details={"reason": "login_crypto_decrypt_failed",
                                     "login_transport": login_transport})
            raise HTTPException(
                status_code=400,
                detail="login_crypto_stale_key: refetch /auth/public-key and retry",
            )
    elif req.password is not None:
        login_transport = LOGIN_TRANSPORT_PLAINTEXT
        from core.config import auth as _login_policy
        if _login_policy.login_plaintext_fallback != "allow":
            logger.warning(
                "Login for user %r REFUSED: plaintext password with "
                "auth.login_plaintext_fallback=refuse (the client could not fetch "
                "or use the login key, or is not the browser).",
                req.username,
            )
            if _db_manager:
                audit_event(_db_manager, {"username": req.username}, request,
                            "login_failed", "auth",
                            details={"reason": LOGIN_PLAINTEXT_REFUSED_CODE,
                                     "login_transport": login_transport})
            # ``detail`` keeps the "<code>: <sentence>" convention the
            # frontend already parses for login_crypto_stale_key; ``code``
            # and ``message`` are the same two facts for any other client.
            return JSONResponse(
                status_code=400,
                content={
                    "detail": f"{LOGIN_PLAINTEXT_REFUSED_CODE}: {LOGIN_PLAINTEXT_REFUSED_MESSAGE}",
                    "code": LOGIN_PLAINTEXT_REFUSED_CODE,
                    "message": LOGIN_PLAINTEXT_REFUSED_MESSAGE,
                },
            )
        _warn_plaintext_login_once(req.username)
        plaintext_password = req.password.get_secret_value()
    else:
        raise HTTPException(
            status_code=400,
            detail="login requires either 'password' (plaintext) or 'password_encrypted' (RSA-OAEP)",
        )

    # authenticate_interactive = normal auth + super_admin break-glass fallback.
    # Basic-auth API calls MUST NOT call this path — they use authenticate_user
    # directly (in api.deps.get_current_user), which never touches the
    # super_admins table. This keeps every API request one DB call lighter.
    from core.ad_auth import authenticate_interactive
    # ldap3 is synchronous (blocking I/O). Offload to threadpool so the event loop
    # doesn't stall while waiting for the AD server to respond.
    # anyio.fail_after(15) adds a hard timeout as a safety net in case connect_timeout
    # or receive_timeout on the ldap3 Connection are not honoured by the OS.
    try:
        with anyio.fail_after(15):
            user = await run_in_threadpool(
                authenticate_interactive,
                req.username,
                plaintext_password,
            )
    except TimeoutError:
        logger.warning("AD authentication timed out for user: %s", req.username)
        if _db_manager:
            audit_event(_db_manager, {"username": req.username}, request,
                        "login_failed", "auth",
                        details={"reason": "ad_timeout", "login_transport": login_transport})
        raise HTTPException(status_code=504, detail="AD authentication timed out — check AD server connectivity") from None
    except HTTPException:
        raise
    except Exception as exc:
        logger.error(
            "Unhandled error during /auth/login for user: %s — %s: %s",
            req.username, type(exc).__name__, exc,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail="Authentication error")

    if not user:
        # Audit failed login attempt
        if _db_manager:
            audit_event(_db_manager, {"username": req.username}, request,
                        "login_failed", "auth",
                        details={"reason": "invalid_credentials", "login_transport": login_transport})
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token = create_session(user)

    # Audit successful login -- with the arm it used (2026-09-29).
    if _db_manager:
        audit_event(_db_manager, user, request, "login", "auth",
                    details={"role": user.get("role", "unknown"),
                             "login_transport": login_transport})

    # BF-415 — vault the password and eagerly refresh AWS portal credentials
    # for any portal-mode S3 connection the user owns / can access.  The user
    # already entered their AD password to log in; if their AWS connections
    # use portal auth (same AD credentials), do the portal call NOW so the
    # first query is fast — no second prompt, no upfront 401 → modal cycle.
    try:
        from core.portal_password_vault import store_password
        store_password(req.username, plaintext_password)
    except Exception as _vault_err:
        logger.debug("portal-vault store on login failed (non-fatal): %s", _vault_err)

    # Fire-and-forget background validation of every connection visible to
    # the user (owned + shared + ACL-granted).  Failure is silent — the
    # user can still run queries; the modal will pop if creds aren't
    # available at query time.  We don't await this so login stays fast.
    try:
        # BF-594: strong-ref track (Python issue #88831).
        from core.bg_tasks import track_bg_task as _track_bg_task_auth
        _track_bg_task_auth(
            _validate_user_connections_at_login(
                req.username, user.get("role", "viewer"),
            )
        )
    except Exception as _refresh_err:
        logger.debug("Connection validation kickoff failed (non-fatal): %s", _refresh_err)

    return {**user, "session_token": token}


# ── Post-login background connection validation ────────────────────────────
#
# 2026-06-16 — strategic expansion of BF-415's _refresh_aws_creds_for_user.
# Pre-fix the post-login task only fetched portal STS for personal portal-mode
# S3 connections.  Per operator: every connection the user can access (S3,
# Oracle, Trino/Starburst, Snowflake, Databricks, Athena, REST API) should
# be exercised at login so problems surface in the LOG with structured
# detail instead of crashing on first query.
#
# Contract:
#   - LOGIN RESPONSE IS NEVER BLOCKED.  Runs fire-and-forget after the
#     /auth/login route returns.
#   - Filters to visible connections: owned (created_by==username) OR
#     shared (is_shared=True) OR ACL-granted (list_connection_ids_for_user).
#   - Per-connection: lightweight `test_connection` for the type.
#   - Per-connection hard timeout via anyio.fail_after to bound bg work.
#   - Per-user cap to prevent N×M storm when many ACL grants exist.
#   - One structured log line PER CONNECTION + a final summary.
#
# Log shapes:
#   [conn-validate] user=… conn_id=N name='…' type='trino' result='ok'
#                    duration_ms=1240
#   [conn-validate] user=… conn_id=N name='…' type='s3' auth_mode='portal'
#                    result='portal_auth_failed' reason='…' duration_ms=4100
#   [conn-validate-summary] user=… owned=A visible=B ok=X failed=Y skipped=Z
#                            cap_skipped=K total_duration_ms=…

# Per-connection wall-clock cap.  Slow portals through corporate proxies
# routinely take 5-15s; pick 10s as the sweet spot between "slow enough
# to be useful in flaky envs" and "fast enough to not snowball".
_VALIDATE_PER_CONN_TIMEOUT_S = 10.0
# Per-user total work cap.  At max timeout this caps total bg time at
# ~200s per login.  Anyone with more than 20 visible connections at one
# pod gets the first 20 validated; the rest are noted in the summary
# and lazily validated at query time.
_VALIDATE_MAX_CONNS_PER_USER = 20
# Portal HTTP target cap retained from BF-415.  Per-target (not per-
# connection): two connections pointing at the same portal_base_url +
# account + role count as ONE target.
_VALIDATE_MAX_PORTAL_TARGETS = 10


async def _validate_user_connections_at_login(username: str,
                                                user_role: str = "viewer") -> None:
    """Background validator — exercises every connection visible to the
    user at login and emits structured logs per result.  Replaces (and
    supersets) the old _refresh_aws_creds_for_user.

    See module docstring above for log shape + contract.
    """
    import time as _time
    from starlette.concurrency import run_in_threadpool

    if not _db_manager:
        return

    _t_start = _time.monotonic()

    # Vault the user's AD password — needed by the portal-S3 branch only.
    # All other branches resolve creds from the connection config / pod role.
    try:
        from core.portal_password_vault import get_password
        password = get_password(username)
    except Exception:
        password = None

    # List ALL connections + ACL grants.  Two cheap DB reads.
    # NOTE: list_connections returns MASKED config (mask_config wraps every
    # SENSITIVE_FIELDS value as "***").  We use that ONLY for the visibility
    # filter — id/created_by/is_shared/connection_type are not sensitive.
    # For the actual validation we MUST refetch with get_connection_raw
    # per connection so real credentials reach S3StorageHandler /
    # get_connector.  Pre-fix the validator handed "***" to boto3 and
    # every connector test failed with auth error regardless of whether
    # the connection was correctly configured.
    try:
        conns = await run_in_threadpool(_db_manager.list_connections)
    except Exception as exc:
        logger.warning(
            "[conn-validate-summary] user=%r result='db_error' reason=%r",
            username, str(exc)[:200],
        )
        return

    try:
        acl_ids = await run_in_threadpool(
            _db_manager.list_connection_ids_for_user, username, [user_role],
        )
    except Exception:
        acl_ids = set()

    # Visible: owned OR shared OR ACL-granted OR legacy (no owner).
    # This mirrors the read-time ACL check in connections_api.list_connections
    # exactly — including the `not c.get("created_by")` legacy clause for
    # pre-Phase-78 connections that never had an owner attached.  Without
    # that clause the validator would silently skip every legacy connection
    # the user can otherwise access.
    owned_count = 0
    visible = []
    for c in (conns or []):
        if c.get("created_by") == username:
            owned_count += 1
            visible.append(c)
        elif bool(c.get("is_shared")):
            visible.append(c)
        elif not c.get("created_by"):
            # Legacy connections (pre-Phase-78) had no owner — they're
            # treated as broadly visible.  Same rule as the read API.
            visible.append(c)
        elif int(c.get("id", -1)) in acl_ids:
            visible.append(c)

    if not visible:
        logger.info(
            "[conn-validate-summary] user=%r owned=0 visible=0 "
            "(no connections to validate)", username,
        )
        return

    # Iterate with caps.  Counts mutated by inner helper so the summary
    # line tallies correctly across the per-connection log lines.
    #
    # 2026-10-07 -- A RECENT VERDICT IS SERVED, NOT RE-PROBED
    # (core/connection_verdicts.py).  Every sign-in used to probe the SOURCE
    # of every visible connection, a failing one included, with no backoff:
    # the rig's log carried the same ``snowflake-real ...
    # network_or_config_error`` line dozens of times in 40 minutes from two
    # users' logins -- at 100 users a storm against production sources.  Now
    # an ``ok`` is reused for ``connection_validation.ok_ttl_seconds``, a
    # failure is re-asked at a doubling backoff, a changed configuration or
    # an explicit Test re-decides, and concurrent sweeps share ONE probe.
    # A served verdict is counted (``cached``), logged at DEBUG only.
    from core import connection_verdicts as _cv
    counts = {"ok": 0, "failed": 0, "skipped": 0, "cached": 0, "shared": 0}
    portal_seen: set = set()
    cap_skipped = 0
    for c in visible:
        # a served verdict costs the source nothing: it is not counted here
        total = counts["ok"] + counts["failed"] + counts["skipped"] - counts["shared"]
        if total >= _VALIDATE_MAX_CONNS_PER_USER:
            cap_skipped += 1
            continue
        # Refetch with decrypted config so the validator sees the REAL
        # password / aws_secret_access_key / etc. — not the "***" mask.
        # Cost: one cheap DB read per visible connection.  For 20 conns
        # this adds <20ms total before any network call.
        try:
            raw_conn = await run_in_threadpool(
                _db_manager.get_connection_raw, int(c.get("id", -1)),
            )
        except Exception as raw_exc:
            counts["failed"] += 1
            logger.warning(
                "[conn-validate] user=%r conn_id=%r name=%r type=%r "
                "result='decrypt_failed' reason=%r",
                username, c.get("id"), c.get("name"),
                c.get("connection_type"), str(raw_exc)[:200],
            )
            continue
        if raw_conn is None:
            # Race: connection was deleted between list_connections and
            # get_connection_raw.  Skip cleanly.
            counts["skipped"] += 1
            logger.info(
                "[conn-validate] user=%r conn_id=%r name=%r type=%r "
                "result='skipped' reason='connection_deleted_concurrently'",
                username, c.get("id"), c.get("name"),
                c.get("connection_type"),
            )
            continue
        _vkey = _cv.key_for(raw_conn, username)
        _served = _cv.cached_verdict(_vkey, raw_conn)
        if _served is not None:
            counts["cached"] += 1
            logger.debug(
                "[conn-validate] user=%r conn_id=%r name=%r result=%r "
                "cached=true age_s=%d (re-probed after %ds)",
                username, raw_conn.get("id"), raw_conn.get("name"),
                _served.result, int(_time.time() - _served.at),
                int(max(0.0, _served.fresh_until() - _time.time())))
            continue
        try:
            async def _probe(_conn=raw_conn):
                _outcome: dict = {}
                _own = {"ok": 0, "failed": 0, "skipped": 0}
                await _validate_one_connection(
                    username=username, password=password, conn=_conn,
                    counts=_own, portal_seen=portal_seen, outcome=_outcome,
                )
                if "result" in _outcome:
                    return _outcome["result"], _outcome.get("reason", "")
                # a validator that tallied without naming its result
                return ((_cv.RESULT_OK, "") if _own["ok"]
                        else ("skipped", "") if _own["skipped"]
                        else ("internal_error", "no result recorded"))
            _result, _reason, _shared = await _cv.probe_once(_vkey, _probe)
            if str(_result).startswith("skipped"):
                counts["skipped"] += 1
            else:
                if not _shared:
                    _cv.record(_vkey, raw_conn, _result, _reason)
                counts["ok" if _result == _cv.RESULT_OK else "failed"] += 1
                if _shared:
                    counts["shared"] += 1
        except Exception as exc:
            # Outer guard — _validate_one_connection should swallow its own
            # errors, but a defensive net here means a single rotten
            # connection can never crash the whole sweep.
            counts["failed"] += 1
            # ...and is a verdict too: re-asked at the backoff, not per login
            _cv.record(_vkey, raw_conn, "internal_error", str(exc))
            logger.warning(
                "[conn-validate] user=%r conn_id=%r name=%r type=%r "
                "result='internal_error' reason=%r",
                username, c.get("id"), c.get("name"),
                c.get("connection_type"), str(exc)[:200],
            )

    _total_ms = int((_time.monotonic() - _t_start) * 1000)
    logger.info(
        "[conn-validate-summary] user=%r owned=%d visible=%d "
        "ok=%d failed=%d skipped=%d cap_skipped=%d cached=%d shared=%d "
        "total_duration_ms=%d",
        username, owned_count, len(visible),
        counts["ok"], counts["failed"], counts["skipped"],
        cap_skipped, counts["cached"], counts["shared"], _total_ms,
    )


async def _validate_one_connection(*, username: str,
                                     password: Optional[str],
                                     conn: dict,
                                     counts: dict,
                                     portal_seen: set,
                                     outcome: Optional[dict] = None) -> None:
    """Dispatch validation by connection_type and emit ONE structured log
    line.  Mutates ``counts`` so the caller's summary tallies correctly;
    ``outcome`` (when given) receives ``result`` / ``reason`` -- the verdict
    the caller records (2026-10-07)."""
    import time as _time
    import anyio
    from starlette.concurrency import run_in_threadpool

    conn_id = conn.get("id")
    conn_name = conn.get("name", "")
    conn_type = (conn.get("connection_type") or "").lower()
    cfg = conn.get("config") or {}
    auth_mode = (cfg.get("auth_mode") or "").lower()

    _t_conn = _time.monotonic()

    def _emit(result: str, reason: str = "", *, level: str = "info") -> None:
        _dur_ms = int((_time.monotonic() - _t_conn) * 1000)
        # f-string with %-args keeps the structured-log keys grep-friendly.
        # Quoting every value defensively so commas / spaces inside names
        # don't fragment the line.
        msg_parts = [
            "[conn-validate]",
            f"user={username!r}",
            f"conn_id={conn_id!r}",
            f"name={conn_name!r}",
            f"type={conn_type!r}",
        ]
        if auth_mode:
            msg_parts.append(f"auth_mode={auth_mode!r}")
        msg_parts.append(f"result={result!r}")
        msg_parts.append(f"duration_ms={_dur_ms}")
        if reason:
            msg_parts.append(f"reason={reason!r}")
        line = " ".join(msg_parts)
        if outcome is not None:
            outcome["result"] = result
            outcome["reason"] = reason
        if level == "warning":
            logger.warning(line)
        else:
            logger.info(line)
        # Counter bookkeeping.  'skipped*' results count as skipped.
        if result == "ok":
            counts["ok"] += 1
        elif result.startswith("skipped"):
            counts["skipped"] += 1
        else:
            counts["failed"] += 1

    # ── Local / upload: no remote target to validate ──────────────────
    if conn_type in ("local", "upload"):
        _emit("skipped", reason="local_no_remote_validation_needed")
        return

    # ── S3 portal-auth ───────────────────────────────────────────────
    if conn_type == "s3" and auth_mode == "portal":
        if not password:
            _emit("skipped", reason="no_vaulted_password")
            return
        if bool(conn.get("is_shared")) or \
           (cfg.get("credential_source") or "").lower() == "system_account":
            _emit("skipped", reason="uses_system_account_no_user_password_needed")
            return
        # Dedup portal targets so 10 connections to the same portal/account
        # don't fire 10 portal calls.
        key = (
            (cfg.get("portal_base_url") or ""),
            (cfg.get("portal_account_id") or ""),
            (cfg.get("role_name") or ""),
        )
        if key in portal_seen:
            _emit("skipped", reason="portal_target_already_validated")
            return
        if len(portal_seen) >= _VALIDATE_MAX_PORTAL_TARGETS:
            _emit("skipped", reason="portal_target_cap_reached")
            return
        portal_seen.add(key)
        try:
            from core.aws_portal_auth import (
                fetch_credentials, build_portal_kwargs_for_connection,
                PortalAuthError,
            )
            _portal_kwargs = build_portal_kwargs_for_connection(cfg)
            with anyio.fail_after(_VALIDATE_PER_CONN_TIMEOUT_S):
                await run_in_threadpool(
                    fetch_credentials, username, password, **_portal_kwargs,
                )
            _emit("ok")
        except TimeoutError:
            _emit("timeout", reason=f"portal_call_>_{_VALIDATE_PER_CONN_TIMEOUT_S}s",
                   level="warning")
        except PortalAuthError as exc:
            _emit("portal_auth_failed", reason=str(exc)[:200], level="warning")
        except Exception as exc:
            _emit("portal_error", reason=str(exc)[:200], level="warning")
        return

    # ── S3 non-portal (keys / iam_role / assume_role / profile) ──────
    if conn_type == "s3":
        try:
            from core.s3_storage import S3StorageHandler, build_s3_config
            with anyio.fail_after(_VALIDATE_PER_CONN_TIMEOUT_S):
                handler = await run_in_threadpool(
                    lambda: S3StorageHandler(build_s3_config(cfg)),
                )
                result = await run_in_threadpool(handler.test_connection)
            if result.get("connected"):
                _emit("ok")
            else:
                _emit("s3_test_failed",
                       reason=str(result.get("error", "unknown"))[:200],
                       level="warning")
        except TimeoutError:
            _emit("timeout", reason=f">{_VALIDATE_PER_CONN_TIMEOUT_S}s",
                   level="warning")
        except Exception as exc:
            _emit("s3_error", reason=str(exc)[:200], level="warning")
        return

    # ── SQL connectors + REST API ────────────────────────────────────
    try:
        from core.connectors import get_connector, SQL_CONNECTOR_TYPES
    except Exception as exc:
        _emit("connector_unavailable",
               reason=f"connectors_module_unavailable: {exc}"[:200])
        return

    if conn_type not in SQL_CONNECTOR_TYPES:
        _emit("skipped", reason="unknown_connection_type")
        return

    try:
        with anyio.fail_after(_VALIDATE_PER_CONN_TIMEOUT_S):
            # IMPORTANT: connection_id=None to BYPASS the circuit breaker
            # wrapper at connectors/__init__.py:359.  Without this, a
            # failed login validation would count against the real-query
            # circuit-breaker budget for this connection — after a few
            # login failures, the operator's actual queries would get
            # short-circuited even though the underlying connection is
            # fine.  Login validation is a NON-AUTHORITATIVE health
            # probe; it must not affect the breaker state used by the
            # real query path.
            connector = await run_in_threadpool(
                get_connector, conn_type, cfg, None, conn_name,
            )
            try:
                result = await run_in_threadpool(connector.test_connection)
                if result.get("success"):
                    _emit("ok")
                else:
                    _emit("auth_or_test_failed",
                           reason=str(result.get("message", "unknown"))[:200],
                           level="warning")
            finally:
                try:
                    await run_in_threadpool(connector.close)
                except Exception:
                    pass
    except TimeoutError:
        _emit("timeout", reason=f">{_VALIDATE_PER_CONN_TIMEOUT_S}s",
               level="warning")
    except ImportError as exc:
        # Connector module not installed (e.g., oracledb missing in image)
        _emit("connector_unavailable", reason=str(exc)[:200])
    except Exception as exc:
        _emit("network_or_config_error", reason=str(exc)[:200], level="warning")


@router.post("/auth/logout")
async def logout_endpoint(request: Request):
    """Destroy the server-side session associated with the caller's Bearer token."""
    # Resolve user before destroying session (so we know who logged out)
    user = None
    try:
        user = get_current_user(request)
    except Exception:
        pass

    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        destroy_session(auth_header[7:])

    # BF-285: clear vaulted AWS portal password on logout.  We don't
    # persist passwords, but the in-memory vault holds Fernet-encrypted
    # entries with up to 8h TTL — wipe them immediately on explicit
    # logout so a subsequent login on the same pod gets a clean slate.
    if user:
        try:
            from core.portal_password_vault import clear_password
            clear_password(user.get("username", ""))
        except Exception:
            pass  # vault helper may not be available in older deploys

    # Audit logout
    if _db_manager and user:
        audit_event(_db_manager, user, request, "logout", "auth")

    return {"message": "Logged out"}


@router.get("/auth/me")
async def whoami(request: Request):
    """Return the current user's identity (or guest when auth is disabled)."""
    return get_current_user(request)


@router.get("/auth/config")
async def auth_config():
    """Return auth configuration visible to the frontend (type only — no secrets).

    BF-AUTH-DI-RACE: when ``_auth_cfg`` is None — typically a partially-up
    backend where DI hasn't completed — return 503 instead of silently
    defaulting to ``type=none``.  Defaulting to "none" granted GUEST ADMIN
    access whenever the backend was midway through starting, which is
    both a visible regression (frontend showed home with guest login on
    a "down" backend) AND a security smell (auth-required setups
    momentarily looked auth-disabled).
    """
    if not _auth_cfg:
        raise HTTPException(
            status_code=503,
            detail="Auth subsystem not ready (backend still initialising)",
        )
    # 2026-07-15 FAIL-CLOSED: if the effective auth.type is 'none' ONLY because
    # the config file failed to load (missing/corrupt config, unmounted ConfigMap),
    # do NOT report 'none' — that would make the SPA grant a guest-ADMIN session
    # with no login screen (a silent auth bypass).  Report a login-REQUIRED mode
    # so the LOGIN PAGE shows.  The super_admin break-glass login still works in
    # this state (it's DB-backed and checked BEFORE AD — no LDAP/config needed),
    # so an operator can always get in and fix the config mount.  A genuine
    # no-auth dev deployment (config loaded, type explicitly 'none') is unaffected.
    try:
        from core.config import config_load_failed as _cfg_failed
        if _auth_cfg.type == "none" and _cfg_failed():
            return {
                "type": "ad",           # non-'none' → SPA shows the login page
                "config_error": True,   # signals "auth config didn't load"
                "domain": "",
                "upload_enabled": _is_container_env(),
                "plaintext_fallback": _plaintext_fallback_policy(),
            }
    except HTTPException:
        raise
    except Exception:
        pass
    return {
        "type": _auth_cfg.type,
        "domain": _auth_cfg.ad_domain,
        "upload_enabled": _is_container_env(),
        # 2026-09-29 -- "allow" | "refuse": what /auth/login does with a
        # plaintext password, so the browser under "refuse" never sends one
        # and shows LOGIN_PLAINTEXT_REFUSED_MESSAGE instead.
        "plaintext_fallback": _plaintext_fallback_policy(),
    }


def _plaintext_fallback_policy() -> str:
    """The effective ``auth.login_plaintext_fallback`` (normalised by
    ``core.config.auth``), read the same way ``login`` reads it."""
    from core.config import auth as _login_policy
    return _login_policy.login_plaintext_fallback


@router.get("/auth/public-key")
async def auth_public_key(request: Request = None):
    """Return the RSA-2048 public key the browser uses to encrypt the
    password before posting to ``/auth/login``.

    Frontend flow:
        1. On app load: GET /auth/public-key → cache the PEM in memory
           keyed by `fingerprint`.
        2. On login submit: Web Crypto ``crypto.subtle.encrypt`` with
           RSA-OAEP-SHA256 over the cached public key, send base64
           ciphertext as ``password_encrypted`` + the cached fingerprint.
        3. If /auth/login returns 400 ``login_crypto_stale_key`` — clear
           the cache, refetch this endpoint, encrypt with the fresh key,
           and retry the login transparently.

    Returns 503 when the cryptography package is unavailable so the
    frontend falls back to the legacy plaintext path with a console
    warning (the operator sees the warning and can install cryptography).

    Round 10 deep-dive (2026-06-30): rate-limited.  Pre-fix this
    endpoint had ZERO rate limiting, allowing an attacker to:
      * enumerate every pod restart by polling the fingerprint
      * correlate key rotations with deployment windows
      * exhaust the crypto module's PEM serialisation (cheap but DoS-y)
    Was bound to a hard-coded 30 req/min per client address.

    2026-09-29: the bound is ``auth.login_rate_limit_per_ip_per_minute``
    (300) in its OWN bucket.  Behind an ingress every browser shares the
    ingress address (until server.forwarded_allow_ips names it), so 30/min
    was thirty key fetches a minute for the whole organisation -- and the
    frontend answers ANY non-200 here by sending the password PLAINTEXT in
    the login body (frontend/src/services/loginCrypto.ts), so a 9am wave
    silently downgraded every login past the 31st.  The login ceiling is
    the right number: a legitimate client fetches the key at most once per
    login attempt (the SPA caches it in memory for the session and
    refetches only on a stale-key 400), so fetches per address can never
    legitimately exceed login attempts per address.  The enumeration / DoS
    bound Round 10 added is kept; only its size follows the declared knob.

    Cacheable by the browser: ``Cache-Control: private, max-age=300`` and
    an ``ETag`` of the fingerprint, ``If-None-Match`` answered 304.  The
    key never rotates on a schedule -- core/login_crypto.py loads it ONCE
    per process from QUERY_STUDIO_LOGIN_PRIVATE_KEY or data_dir/
    login_rsa.pem, and it changes only across a process start without
    that file -- and the stale-key contract (a 400 ``login_crypto_stale_
    key`` makes the client refetch with ``cache: 'no-cache'``, i.e.
    revalidate) means a cached copy is never USED past a rotation: the
    revalidation returns the new key.  ``private`` keeps intermediaries
    out: two pods without a shared key file hold two keys, and a shared
    cache would hand one pod's key to the other pod's client.  A 304
    counts against the limiter exactly like a 200 -- the fingerprint
    comparison IS the enumeration Round 10 closed.
    """
    try:
        from core.rate_limiter import check_rate_limit, RateLimitExceededError
        from core.config import auth as _login_limits
        ip = (request.client.host if request and request.client else "unknown")
        try:
            check_rate_limit(
                "auth_public_key", ip,
                limit=_login_limits.login_rate_limit_per_ip_per_minute,
                window_seconds=60)
        except RateLimitExceededError as rle:
            raise HTTPException(status_code=429,
                                detail=f"Too many public-key requests: {rle}",
                                headers={"Retry-After": str(rle.retry_after)})
    except HTTPException:
        raise
    except Exception:
        pass    # rate_limiter module missing -- best-effort, do not break login
    try:
        from core.login_crypto import (
            public_key_pem, public_key_fingerprint, LoginCryptoError,
        )
        fingerprint = public_key_fingerprint()
        etag = f'"{fingerprint}"'
        cache_headers = {
            "Cache-Control": f"private, max-age={_PUBLIC_KEY_MAX_AGE_SECONDS}",
            "ETag": etag,
        }
        inm = request.headers.get("if-none-match", "") if request is not None else ""
        if etag in [t.strip() for t in inm.split(",")]:
            return Response(status_code=304, headers=cache_headers)
        return JSONResponse(
            content={
                "algorithm": "RSA-OAEP",
                "hash":      "SHA-256",
                "key_size":  2048,
                "public_key_pem":  public_key_pem(),
                "fingerprint":     fingerprint,
            },
            headers=cache_headers,
        )
    except LoginCryptoError as exc:
        # Crypto not available — frontend will fall back to plaintext path.
        raise HTTPException(
            status_code=503,
            detail=f"login crypto unavailable: {exc}",
        )
