"""
Published API — BULK EXPORT: true incremental streaming for external consumers.

WHY THIS MODULE EXISTS
----------------------
The paged ``/api/v1/views/{slug}/data`` contract is correct but it is a
*page* reader: ``envelope.read_page`` collects ``limit`` rows into ONE
in-memory ``pyarrow.Table`` and hands it to the response builder.  The
``StreamingResponse`` helpers in ``helpers.py`` then stream the ENCODING of
that already-materialized table.  So peak memory on that path is

    O(page rows x row width)      -- NOT O(chunk)

which is exactly why ``max_limit`` (50 000) has to exist there: it is a
MEMORY bound, not a policy number.  Deleting it would move the failure from
a clean HTTP 400 to an OOM that kills the pod and every interactive user
sharing it.

This module takes the other half of the design that was already built and
uses it properly.  The executor ALREADY materializes the whole dataset into
a stable parquet file on disk (``_persist_result_to_cache``) with a
``DatasetManifest`` truth sidecar.  That file is an immutable, point-in-time
artifact.  For a bulk consumer we therefore never need a full in-memory
table at all:

    parquet file -> pf.iter_batches(batch_size=N) -> encode -> yield bytes

Peak memory becomes ONE RecordBatch.  Row count becomes irrelevant to
memory, so it can be unbounded.

WHAT THIS BUYS, BEYOND "no cap"
-------------------------------
Because the dataset is a stable file rather than a re-executed query, four
properties a bulk consumer actually needs fall out almost free:

* SNAPSHOT CONSISTENCY.  Every row in the stream comes from ONE
  materialization.  A 10M-row pull that spans minutes cannot tear, because
  nothing re-executes mid-stream.  The identity of that materialization is
  returned as ``X-QS-Dataset-Version`` so the consumer can prove what they
  got and re-pull the identical bytes.
* RESUMABILITY THAT IS ACTUALLY CORRECT.  A cursor carries
  (dataset_version, row_offset).  Resuming re-opens the SAME file, so the
  offset cannot drift.  If the dataset was refreshed underneath, the
  version check FAILS LOUD (409) instead of silently splicing two different
  point-in-time views together.
* AN AUTHORITATIVE ROW COUNT that does not come from the payload.  The
  parquet FOOTER knows ``num_rows`` in O(1) before a single row is encoded,
  so ``X-QS-Total-Rows`` is emitted in the response HEADERS -- a downstream
  ETL can reconcile rows-received against it.  A count derived from the
  streamed payload proves nothing.
* COLUMNAR FORMATS.  ``arrow`` / ``parquet`` re-encode straight from the
  RecordBatch with no Python row objects at all.

DELIBERATE REFUSALS (correctness gates stay loud)
-------------------------------------------------
* ``?sort=`` is REJECTED on bulk.  A global sort cannot be evaluated from a
  prefix -- honouring it would mean reading the whole dataset into RAM,
  reintroducing the exact OOM this module exists to remove.  The error tells
  the publisher to push ORDER BY into the view's query instead.
* A cursor whose ``dataset_version`` no longer matches is a 409, never a
  silent restart against the new data.
"""
from __future__ import annotations

import base64
import io
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional

from fastapi import HTTPException


logger = logging.getLogger(__name__)

__all__ = [
    "BULK_FORMATS",
    "BulkCursor",
    "DatasetRef",
    "bulk_enabled", "bulk_batch_rows", "bulk_max_rows", "bulk_dataset_row_cap",
    "bulk_max_concurrent", "bulk_max_per_key",
    "bulk_stall_timeout_seconds", "bulk_build_timeout_seconds",
    "open_dataset", "describe_dataset", "iter_dataset_batches", "validate_bulk_columns",
    "encode_batches", "bulk_headers", "stall_guard", "gzip_stream",
    "media_type_for", "ChunkSink",
]

# Formats this module can stream incrementally.  ``json`` is the paged
# envelope shape (familiar to existing consumers); ``jsonl`` is the
# line-delimited form an ETL actually wants.
BULK_FORMATS = ("jsonl", "json", "csv", "arrow", "parquet")


# ══════════════════════════════════════════════════════════════════════════════
# Config — every knob fail-safe, read from the ``published_views`` section
# ══════════════════════════════════════════════════════════════════════════════

def _cfg(key: str, default):
    try:
        from core.config import get as _get
        v = _get("published_views", key, default)
        return default if v is None else v
    except Exception:
        return default


def bulk_enabled() -> bool:
    """Master switch for the bulk streaming endpoints (default True).

    Default-ON is deliberate.  These are NEW routes -- they cannot change the
    behaviour of any existing caller, so the usual "default to the safe
    existing behaviour" rule has nothing to protect here, while defaulting
    off would ship the feature inert and defeat its purpose.
    """
    return bool(_cfg("bulk_enabled", True))


def bulk_batch_rows() -> int:
    """Rows per streamed batch — THE memory bound of this module (default 65536)."""
    try:
        return max(1, int(_cfg("bulk_batch_rows", 65536)))
    except (TypeError, ValueError):
        return 65536


def bulk_max_rows() -> int:
    """Max rows one bulk response may deliver.  0 = UNBOUNDED (the default).

    Unbounded is safe here precisely because memory is bounded by
    ``bulk_batch_rows``; the number of rows streamed does not change peak RSS.
    """
    try:
        return max(0, int(_cfg("bulk_max_rows", 0)))
    except (TypeError, ValueError):
        return 0


def bulk_dataset_row_cap() -> int:
    """Materialization cap for bulk requests.  0 = UNBOUNDED (the default).

    Distinct from ``envelope.dataset_row_cap`` (1M), which stays as-is for the
    paged ``/data`` contract.  The bulk cap governs a write to DISK, not to
    RAM: overrunning it fails as a clear out-of-space error, not an OOM that
    takes the pod's interactive users with it.
    """
    try:
        return max(0, int(_cfg("bulk_dataset_row_cap", 0)))
    except (TypeError, ValueError):
        return 0


def bulk_max_concurrent() -> int:
    """Concurrent bulk streams allowed per pod (default 4, 0 = unlimited).

    Bulk pulls are long-lived and share the DuckDB engine pool with the
    interactive data grid.  This is the isolation lever: bulk gets its own
    small lane so a burst of 10M-row exports cannot occupy the engine slots
    the ~1000 interactive users need.
    """
    try:
        return max(0, int(_cfg("bulk_max_concurrent", 4)))
    except (TypeError, ValueError):
        return 4


def bulk_max_per_key() -> int:
    """Concurrent bulk streams ONE api key may hold (default 2, 0 = unlimited).

    Without this, a single consumer can occupy the whole bulk lane and every
    other external team gets 429s -- the lane would isolate bulk from
    interactive users but not consumers from each other.  Must stay below
    ``bulk_max_concurrent`` to mean anything.
    """
    try:
        return max(0, int(_cfg("bulk_max_per_key", 2)))
    except (TypeError, ValueError):
        return 2


def bulk_stall_timeout_seconds() -> float:
    """Abort a stream after this many seconds with NO bytes produced.

    Bounds PROGRESS, not total duration: a legitimate 10M-row pull may run
    for an hour and is fine, a wedged one is killed in minutes.
    """
    try:
        return max(1.0, float(_cfg("bulk_stall_timeout_seconds", 300)))
    except (TypeError, ValueError):
        return 300.0


def bulk_build_timeout_seconds() -> float:
    """Max seconds for the dataset MATERIALIZATION phase (default 1800, 0 = none).

    The build produces no bytes, so a stall guard cannot supervise it; it
    needs its own bound.  Kept far above the paged path's 300s because
    materializing 10M rows legitimately exceeds it -- that 300s default is
    what makes a large pull impossible today.
    """
    try:
        return max(0.0, float(_cfg("bulk_build_timeout_seconds", 1800)))
    except (TypeError, ValueError):
        return 1800.0


def bulk_prepare_timeout_seconds() -> float:
    """Budget for a BACKGROUND (POST /bulk/prepare) materialization
    (default 14400 = 4 h, 0 = none).

    Deliberately far above ``bulk_build_timeout_seconds``: the inline build
    holds an HTTP request open, so its 1800s bound protects the connection;
    a background build holds only a job record, and a 140M-row Starburst
    materialization legitimately runs 1-2.5 h.  The value 0 means no
    budget at all — the build runs to completion or failure."""
    try:
        return max(0.0, float(_cfg("bulk_prepare_timeout_seconds", 14400)))
    except (TypeError, ValueError):
        return 14400.0


# ══════════════════════════════════════════════════════════════════════════════
# Dataset identity — the snapshot-consistency primitive
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class DatasetRef:
    """Identity + authoritative shape of ONE materialized dataset file.

    ``version`` is what makes a bulk pull provable: it is derived from the
    file's own bytes-on-disk identity (size + mtime_ns + footer row count +
    cache key), so two pulls that report the same version read byte-identical
    data, and a refreshed dataset necessarily reports a different one.
    """
    path: str
    version: str
    total_rows: int                 # footer-derived — NOT counted from the payload
    num_row_groups: int
    columns: List[str]
    total_mode: str = "exact"       # exact | at_least | unknown
    snapshot_id: Optional[int] = None
    as_of_timestamp_ms: Optional[int] = None
    data_status: str = "ok"
    # ── Parts datasets (2026-08-22, write ladder / §4.4) ─────────────────
    # A dataset may be a PARTS DIRECTORY (manifest + immutable part files)
    # instead of one parquet.  ``parts_manifest`` pins the manifest READ AT
    # OPEN TIME — parts are immutable and the manifest is append-only while
    # building, so the pinned object is a consistent snapshot by
    # construction.  ``building`` = the manifest was partial (opt-in
    # serving of an in-flight build); total_mode is then "at_least".
    is_parts: bool = False
    building: bool = False
    parts_manifest: Any = None


def _unavailable(exc: Exception, path) -> HTTPException:
    """F8 — a 500 body reaching an EXTERNAL consumer must not carry an internal
    filesystem path.

    ``OSError`` renders the full NFS path it failed on, and these routes are
    the ONE part of the product an unauthenticated-to-our-infrastructure third
    party reads error bodies from.  The paged ``/data`` sibling already gets
    this right: a generic message to the client, the sanitized detail to the
    log.  Same shape here, and the log keeps the real path so an operator
    loses nothing.
    """
    try:
        from core.error_sanitizer import sanitize_error as _sanitize
        detail = _sanitize(f"{type(exc).__name__}: {exc}")
    except Exception:                                # pragma: no cover
        detail = type(exc).__name__
    logger.error("[pv-bulk] dataset unavailable path=%s: %s", path, detail)
    return HTTPException(500, "Dataset unavailable — contact administrator")


class _PartsHandle:
    """Open handle over a PARTS dataset: the manifest object pinned at
    open time.  Parts are immutable and a building manifest is append-
    only, so this pin is the parts analogue of holding the single-file
    inode open — the rows served are provably the rows described."""

    def __init__(self, parts_dir, *, allow_partial: bool = False):
        from core.feed.parts_manifest import load_manifest
        self.parts_dir = str(parts_dir)
        self.manifest, src = load_manifest(parts_dir,
                                           allow_partial=allow_partial)
        self.is_partial = src.name.endswith("partial.json")

    def close(self):
        pass


def open_dataset(path: str | Path, *, allow_partial: bool = False):
    """Open the dataset parquet ONCE, for both the footer read and the stream.

    2026-08-22 — a parts DIRECTORY (write-ladder output) opens as a
    :class:`_PartsHandle`; ``allow_partial`` admits an in-flight build's
    partial manifest (explicit opt-in only — the default serves only
    COMPLETE datasets, exactly as before).

    Snapshot consistency depends on this.  ``_persist_result_to_cache``
    publishes a refreshed dataset with ``tmp.replace(cached_path)``; if the
    footer were read through one open and the rows through a later one, a
    concurrent refresh landing in between would have us advertise version A's
    row count while streaming version B's rows -- a torn read wearing a
    consistency header.  One handle, held for the life of the response, means
    the reader keeps reading the inode it validated.

    F3 (2026-08-08) -- the handle is a real OS file object and its ``fstat``
    is captured HERE, so the dataset's identity is read from the SAME inode
    the rows come from.  ``describe_dataset`` used to ``stat()`` the PATH: a
    refresh landing between that stat and the footer read let a response
    advertise version B while streaming version A's bytes -- provenance that
    is confidently wrong, which is worse than provenance that is missing.
    ``close_dataset`` releases the handle.
    """
    import os
    import pyarrow.parquet as pq

    if Path(str(path)).is_dir():
        try:
            return _PartsHandle(path, allow_partial=allow_partial)
        except Exception as exc:
            raise _unavailable(exc, path)

    fh = None
    try:
        fh = open(str(path), "rb")
        st = os.fstat(fh.fileno())
        pf = pq.ParquetFile(fh)
    except Exception as exc:
        if fh is not None:
            try:
                fh.close()
            except OSError as _cexc:
                logger.warning("[pv-bulk] could not close handle after a failed "
                               "open of %s: %s", path, _cexc)
        raise _unavailable(exc, path)
    # Identity of the exact inode being read, for describe_dataset.
    try:
        pf._qs_fh = fh                                   # type: ignore[attr-defined]
        pf._qs_size = int(st.st_size)                    # type: ignore[attr-defined]
        pf._qs_mtime_ns = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))  # type: ignore[attr-defined]
    except Exception as _iexc:                           # pragma: no cover
        # describe_dataset falls back to stat()ing the path, which is the
        # pre-F3 behaviour: correct, just no longer race-free.  Say so.
        logger.warning(
            "[pv-bulk] could not pin dataset identity to the open handle for %s "
            "(%s) — falling back to a path stat, which a concurrent refresh can race",
            path, _iexc,
        )
    return pf


def close_dataset(pf) -> None:
    """Release a handle from ``open_dataset`` (safe to call with None/any pf)."""
    if pf is None:
        return
    try:
        pf.close()
    except Exception as exc:
        logger.debug("[pv-bulk] ParquetFile.close() failed: %s", exc)
    fh = getattr(pf, "_qs_fh", None)
    if fh is not None:
        try:
            fh.close()
        except OSError as exc:
            logger.warning("[pv-bulk] dataset file handle would not close: %s", exc)


def describe_dataset(path: str | Path, *, cache_key: str = "", pf=None) -> DatasetRef:
    """Read a dataset parquet's FOOTER (O(1), no row data) and build its ref.

    The row count here is the authoritative, source-derived total the
    response advertises before streaming a single row.  Pass ``pf`` (from
    ``open_dataset``) to pin the same handle the stream will read -- the
    identity below is then taken from that handle's ``fstat``, not from a
    fresh ``stat()`` of the path that a concurrent refresh could have moved.

    The manifest is accepted only when it PROVABLY describes the open file
    (``DatasetManifest.read_bound``).  A manifest that describes a different
    materialization is the F3 torn-publish window: binding it here would
    advertise a stale, smaller ``total_rows``, stream exactly that many rows
    of a larger dataset, and the consumer's reconcile would PASS on a
    truncated export.  Unverifiable => ``total_mode="unknown"``, and the bulk
    materializer treats unknown as "re-materialize" (fail-closed).
    """
    import hashlib

    p = Path(str(path))
    _own_pf = pf is None
    if pf is None:
        pf = open_dataset(p)
    if isinstance(pf, _PartsHandle):
        # Parts dataset: the manifest IS the footer.  Its per-part row
        # counts were verified at write time (rung-1 footer-vs-engine
        # gate; rung-3 fed-vs-footer reconcile), so a COMPLETE manifest
        # is an exact total; a PARTIAL one is honestly "at_least" and
        # marked building.
        m = pf.manifest
        return DatasetRef(
            path=str(p), version=m.version(),
            total_rows=int(m.total_rows),
            num_row_groups=len(m.parts),
            columns=list(m.columns()) if m.schema_b64 else [],
            total_mode=("at_least" if pf.is_partial else "exact"),
            data_status="ok",
            is_parts=True, building=bool(pf.is_partial),
            parts_manifest=m,
        )
    try:
        size = getattr(pf, "_qs_size", None)
        mtime_ns = getattr(pf, "_qs_mtime_ns", None)
        if size is None or mtime_ns is None:
            # Caller supplied a bare ParquetFile (tests, legacy callers).
            try:
                st = p.stat()
                size = int(st.st_size)
                mtime_ns = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
            except OSError as exc:
                raise _unavailable(exc, p)

        md = pf.metadata
        footer_rows = int(md.num_rows)
        total_rows = footer_rows
        cols = list(pf.schema_arrow.names)

        fingerprint = f"{cache_key}|{size}|{mtime_ns}|{footer_rows}|{int(md.num_row_groups)}"
        version = hashlib.sha256(fingerprint.encode()).hexdigest()[:20]

        total_mode = "exact"
        snapshot_id = None
        as_of_ms = None
        data_status = "ok"
        try:
            from api.published_views.envelope import DatasetManifest
            m, verified = DatasetManifest.read_bound(p, size=size, rows=footer_rows)
            if m is None:
                # No sidecar, unreadable, or provably about another file =>
                # provenance unknown.  UNKNOWN = UNSAFE: say so rather than
                # implying the footer count is a verified total.
                total_mode = "unknown"
            else:
                if not verified:
                    # Legacy sidecar with no binding stamp.  Its truth is
                    # still the best available (and this is exactly the
                    # pre-existing behaviour), but it cannot be proven to
                    # describe this file.
                    logger.debug(
                        "[pv-bulk] manifest for %s carries no binding stamp — "
                        "using it unverified (legacy entry)", p,
                    )
                total_mode = m.total_mode.value
                snapshot_id = m.snapshot_id
                as_of_ms = m.as_of_timestamp_ms
                data_status = m.data_status
                if total_mode == "at_least":
                    # Capped datasets hold cap+1 rows (overflow sentinel); the
                    # manifest total is the honest readable bound.
                    total_rows = min(total_rows, int(m.total_rows))
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("[pv-bulk] manifest read failed for %s: %s", p, exc)
            total_mode = "unknown"

        return DatasetRef(
            path=str(p), version=version, total_rows=total_rows,
            num_row_groups=int(md.num_row_groups), columns=cols,
            total_mode=total_mode, snapshot_id=snapshot_id,
            as_of_timestamp_ms=as_of_ms, data_status=data_status,
        )
    finally:
        if _own_pf:
            close_dataset(pf)


# ══════════════════════════════════════════════════════════════════════════════
# Cursor — resumable, and loud when the ground moved
# ══════════════════════════════════════════════════════════════════════════════

@dataclass(frozen=True)
class BulkCursor:
    """Continuation token: (dataset version, next row offset).

    Not encrypted -- it carries no secret, only a position in a dataset the
    caller is already authorized for.  Base64url so it is header/query safe.

    F5 (2026-08-08) -- ``offset`` is OPTIMISTIC.  It is computed as
    ``base + expected`` and emitted in the response HEADERS, before a single
    row is on the wire, so it names where the stream WOULD end, not where the
    client actually got to.  A consumer that dies at row 400k of a 1M-row
    response and then replays this token resumes at 1M: 600 000 rows silently
    skipped, and ``verify`` PASSES because the dataset itself never moved.
    The token cannot be made self-correcting -- only the client knows how many
    rows it actually wrote -- so the token now carries the two extra facts
    that let the client correct it:

        ``base``     -- the row offset this response STARTED at
        ``expected`` -- how many rows it was going to deliver

    and the endpoint accepts ``?received=N`` alongside ``?cursor=``, resuming
    at ``base + N``.  ``received`` is validated against ``expected``: claiming
    more rows than the response could contain is a 400, not a silent skip.
    Legacy tokens (no base/expected) still decode and still resume at
    ``offset`` -- back-compatible, and no worse than before.
    """
    version: str
    offset: int
    base: Optional[int] = None
    expected: Optional[int] = None

    def encode(self) -> str:
        payload: Dict[str, Any] = {"v": self.version, "o": int(self.offset)}
        if self.base is not None:
            payload["b"] = int(self.base)
        if self.expected is not None:
            payload["e"] = int(self.expected)
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")

    @classmethod
    def decode(cls, token: str) -> "BulkCursor":
        try:
            pad = "=" * (-len(token) % 4)
            raw = base64.urlsafe_b64decode(token + pad)
            obj = json.loads(raw.decode("utf-8"))
            return cls(
                version=str(obj["v"]),
                offset=max(0, int(obj["o"])),
                base=(max(0, int(obj["b"])) if obj.get("b") is not None else None),
                expected=(max(0, int(obj["e"])) if obj.get("e") is not None else None),
            )
        except Exception:
            raise HTTPException(400, "Invalid cursor — expected an opaque token from a previous X-QS-Next-Cursor header")

    def resume_offset(self, received: Optional[int]) -> int:
        """Where to actually resume.

        ``received=None``  -> the optimistic ``offset`` (legacy behaviour).
        ``received=N``     -> ``base + N``, i.e. exactly where the client's
                              own write pointer stopped.  This is the only
                              form that is correct after a short read, and it
                              is why ``X-QS-Row-Offset`` is a documented
                              response header.

        A cursor issued before ``base`` existed cannot honour ``received``;
        rather than guess (guessing here means skipping rows) it says so.
        """
        if received is None:
            return int(self.offset)
        n = int(received)
        if n < 0:
            raise HTTPException(400, "?received= must be >= 0")
        if self.base is None:
            raise HTTPException(
                400,
                "?received= cannot be applied to this cursor — it was issued before "
                "the cursor carried its starting offset. Resume with "
                "?offset=<X-QS-Row-Offset + rows you received>&dataset_version=<X-QS-Dataset-Version> instead.",
            )
        if self.expected is not None and n > int(self.expected):
            raise HTTPException(
                400,
                f"?received={n} exceeds the {self.expected} row(s) that response could "
                "deliver (X-QS-Expected-Rows) — refusing to resume past the end of what "
                "was sent, which would skip rows.",
            )
        return int(self.base) + n

    def verify(self, ref: DatasetRef) -> None:
        """Fail LOUD when the dataset changed under a resuming consumer.

        Silently continuing would splice rows from two different
        point-in-time datasets into one 'consistent' export -- the torn-read
        failure mode a bulk API exists to prevent.
        """
        verify_dataset_version(self.version, ref, source="cursor")


def verify_dataset_version(expected: Optional[str], ref: DatasetRef, *,
                           source: str = "dataset_version") -> None:
    """409 unless ``expected`` names the materialization we are about to read.

    Shared by ``?cursor=`` and the explicit ``?dataset_version=`` pin, so a
    consumer that resumes by OFFSET gets exactly the same torn-read protection
    as one that replays a token -- which is what makes offset-based resume
    (the only form that is correct after a short read, see ``resume_offset``)
    a first-class mechanism rather than a downgrade.
    """
    if not expected:
        return
    if expected == ref.version:
        return
    if ref.is_parts and ref.parts_manifest is not None:
        # Append-only prefix rule (2026-08-22): parts are immutable and a
        # building manifest only APPENDS, so a cursor minted against a
        # shorter manifest of the SAME build still names byte-identical
        # data — accept it iff it equals the version of that exact
        # prefix.  A rebuild changes build_id, which changes every prefix
        # version, so splicing across two builds still 409s.
        try:
            _n = int(str(expected).split(":", 3)[1])
        except (IndexError, ValueError):
            _n = -1
        if (0 <= _n <= len(ref.parts_manifest.parts)
                and ref.parts_manifest.version_at(_n) == expected):
            return
    if expected != ref.version:
        raise HTTPException(
            409,
            "Dataset changed since this "
            f"{'cursor was issued' if source == 'cursor' else 'version was observed'} — "
            "the resumed rows would come from a different point-in-time snapshot. "
            "Restart the export without a cursor (or pin the dataset via "
            "?snapshot_id= / ?as_of_timestamp= for a stable re-pull). "
            f"cursor_version={expected} current_version={ref.version}",
        )


# ══════════════════════════════════════════════════════════════════════════════
# THE memory-bounded reader
# ══════════════════════════════════════════════════════════════════════════════

def validate_bulk_columns(ref: DatasetRef, columns: Optional[List[str]]) -> Optional[List[str]]:
    """Strict ?columns validation — unknown names are a 400, never dropped.

    Same reject-never-ignore contract as ``envelope.read_page(strict=True)``.
    """
    if not columns:
        return None
    unknown = [c for c in columns if c not in ref.columns]
    if unknown:
        raise HTTPException(
            400,
            f"Unknown column(s) in ?columns: {', '.join(unknown)}. "
            f"Available: {', '.join(ref.columns)}",
        )
    return list(columns)


def iter_dataset_batches(
    path: str | Path,
    *,
    columns: Optional[List[str]] = None,
    offset: int = 0,
    max_rows: int = 0,
    batch_rows: int = 65536,
    pf=None,
) -> Iterator[Any]:
    """Yield ``pyarrow.RecordBatch`` from a dataset parquet with O(batch) memory.

    This is the whole point of the module.  There is NO code path here that
    holds more than one batch: no ``read_table``, no ``Table.from_batches``,
    no accumulating list.  ``max_rows=0`` means unbounded, and it costs
    nothing extra in memory to say so.

    ``offset`` skips WHOLE ROW GROUPS without decoding them (footer
    arithmetic), then trims the remainder inside the first decoded batch --
    so resuming a 10M-row export at row 9M does not decode the first 9M rows.

    ``pf`` -- reuse an already-open handle (see ``open_dataset``) so the rows
    streamed are provably the same materialization whose footer was
    advertised.
    """
    if pf is None:
        pf = open_dataset(path)
    if isinstance(pf, _PartsHandle):
        # Keyset over parts: the manifest's cumulative row counts map the
        # offset straight to (part, row-within) — resume cost is O(part),
        # never O(scan).  Batch memory bound is identical (one batch).
        from core.feed.parts_manifest import iter_manifest_batches
        yield from iter_manifest_batches(
            pf.parts_dir, pf.manifest,
            columns=columns, offset=offset,
            max_rows=max_rows, batch_rows=batch_rows,
        )
        return
    md = pf.metadata
    n_groups = md.num_row_groups

    skip = max(0, int(offset))
    remaining = None if int(max_rows) <= 0 else max(0, int(max_rows))
    if remaining == 0 or n_groups == 0:
        return

    # Footer-only scan: find the first row group that contains row `skip`.
    start_group = 0
    consumed = 0
    while start_group < n_groups:
        rg_rows = md.row_group(start_group).num_rows
        if consumed + rg_rows <= skip:
            consumed += rg_rows
            start_group += 1
        else:
            break
    if start_group >= n_groups:
        return                       # offset past EOF — zero rows, zero reads
    within = skip - consumed         # rows to drop inside the first decoded batch

    groups = list(range(start_group, n_groups))
    # 2026-10-04 -- decode on THIS thread (``use_threads=False``).  Arrow's
    # CPU pool decodes on long-lived pool threads, and each keeps its own
    # allocator pages after the stream ends -- pages ``release_unused`` on
    # the calling thread cannot reach.  Measured (3 concurrent 1.5M-row CSV
    # streams, twice): +184 MiB retained with pool decoding, +78 MiB on the
    # stream's own thread; after the give-back +127 vs +51.  A published-api
    # process is sized at ~1 CPU (pod.workers = CPU limit), so the pool's
    # parallel decode only contended with the sibling worker anyway.
    for batch in pf.iter_batches(batch_size=int(batch_rows), columns=columns,
                                 row_groups=groups, use_threads=False):
        if within:
            if batch.num_rows <= within:
                within -= batch.num_rows
                continue
            batch = batch.slice(within)
            within = 0
        if remaining is not None and batch.num_rows > remaining:
            batch = batch.slice(0, remaining)
        if batch.num_rows:
            yield batch
            if remaining is not None:
                remaining -= batch.num_rows
                if remaining <= 0:
                    return


# ══════════════════════════════════════════════════════════════════════════════
# Incremental encoders — batch in, bytes out, nothing accumulated
# ══════════════════════════════════════════════════════════════════════════════

class ChunkSink(io.RawIOBase):
    """Write-only, non-seekable sink that hands each flush back as bytes.

    Lets pyarrow's IPC / Parquet writers -- which are push-oriented and want
    a file object -- drive a pull-oriented HTTP generator without buffering
    the whole encoded output.  ``drain()`` yields and clears what has been
    written since the last call.
    """

    def __init__(self) -> None:
        self._parts: List[bytes] = []
        self._pos = 0

    def writable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    def readable(self) -> bool:
        return False

    def write(self, b) -> int:  # type: ignore[override]
        data = bytes(b)
        self._parts.append(data)
        self._pos += len(data)
        return len(data)

    def tell(self) -> int:  # type: ignore[override]
        return self._pos

    def flush(self) -> None:  # type: ignore[override]
        return None

    def drain(self) -> bytes:
        if not self._parts:
            return b""
        out = b"".join(self._parts)
        self._parts = []
        return out


def bulk_encode_rows() -> int:
    """Rows per ENCODE slice in the jsonl / csv / json encoders
    (``published_views.bulk_encode_rows``, default 8192) -- the bound on the
    encoder's transient memory, independent of the decode batch."""
    try:
        return max(1, int(_cfg("bulk_encode_rows", 8192)))
    except (TypeError, ValueError):
        return 8192


def _encode_slices(batch) -> Iterator[Any]:
    """A decoded batch as slices of at most ``bulk_encode_rows`` rows.

    2026-10-04 -- THE PER-STREAM PEAK.  The row encoders turned a whole
    decode batch (``bulk_batch_rows``, 65,536) into Python dicts at once:
    163 MiB traced per 1M-row CSV stream, pages the allocators KEPT.  The
    encoders are columnar now (``bulk_text``) and the slice still bounds
    their transient Arrow memory: a slice is zero-copy, so nothing here
    scales with the batch."""
    step = bulk_encode_rows()
    n = batch.num_rows
    if n <= step:
        if n:
            yield batch
        return
    for start in range(0, n, step):
        yield batch.slice(start, step)


def _dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


# 2026-10-04 -- the text encoders are COLUMNAR (``bulk_text``): Arrow
# kernels format each column and join the rows, instead of a Python dict
# per row through ``csv.DictWriter`` / ``json.dumps``.  Measured in process
# on a 1M-row, 10-column report-shaped dataset (decode included): CSV
# ~71k -> ~560-690k rows/s, JSONL ~74k -> ~400-460k rows/s.  The bytes are
# the row encoder's, proven per type in
# tests/test_bulk_text_encoding_2026_10_04.py.

def _encode_jsonl(batches: Iterable[Any]) -> Iterator[bytes]:
    from api.published_views.bulk_text import jsonl_rows
    for batch in batches:
        for part in _encode_slices(batch):
            out = jsonl_rows(part)
            if out:
                yield out


def _encode_csv(batches: Iterable[Any], header: bool = True) -> Iterator[bytes]:
    from api.published_views.bulk_text import csv_header, csv_rows
    started = False
    for batch in batches:
        if not started:
            started = True
            # The header rides on the FIRST batch, as it always did: an
            # empty dataset streams an empty body (no header line).
            if header:
                yield csv_header(batch.schema.names)
        for part in _encode_slices(batch):
            out = csv_rows(part)
            if out:
                yield out


def _encode_arrow(batches: Iterable[Any]) -> Iterator[bytes]:
    """Arrow IPC stream — the cheapest bulk format on both ends (no row objects)."""
    import pyarrow as pa

    sink = ChunkSink()
    writer = None
    try:
        for batch in batches:
            if writer is None:
                writer = pa.ipc.new_stream(sink, batch.schema)
                head = sink.drain()
                if head:
                    yield head
            writer.write_batch(batch)
            chunk = sink.drain()
            if chunk:
                yield chunk
    finally:
        if writer is not None:
            writer.close()
            tail = sink.drain()
            if tail:
                yield tail


def _encode_parquet(batches: Iterable[Any]) -> Iterator[bytes]:
    """Parquet, written incrementally into the chunk sink (one row group per batch)."""
    import pyarrow.parquet as pq

    sink = ChunkSink()
    writer = None
    try:
        for batch in batches:
            if writer is None:
                writer = pq.ParquetWriter(sink, batch.schema)
                head = sink.drain()
                if head:
                    yield head
            writer.write_batch(batch)
            chunk = sink.drain()
            if chunk:
                yield chunk
    finally:
        if writer is not None:
            writer.close()          # writes the footer
            tail = sink.drain()
            if tail:
                yield tail


def _encode_json_envelope(
    batches: Iterable[Any], envelope: dict,
) -> Iterator[bytes]:
    """Envelope JSON with the ``data`` array streamed between the brackets.

    Same split-the-skeleton technique as ``helpers._json_streaming_from_df``,
    but fed from the batch iterator instead of a materialized table -- so the
    row list never exists.
    """
    skeleton = dict(envelope)
    skeleton["data"] = []
    full = _dumps(skeleton)
    marker = '"data":[]'
    idx = full.find(marker)
    if idx == -1:  # pragma: no cover — we just forced data=[]
        idx = len(full)
        prefix = full.encode("utf-8")
        suffix = b""
    else:
        prefix = (full[:idx] + '"data":[').encode("utf-8")
        suffix = (']' + full[idx + len(marker):]).encode("utf-8")

    yield prefix
    from api.published_views.bulk_text import json_array_items
    first = True
    for batch in batches:
        for part in _encode_slices(batch):
            out = json_array_items(part, first=first)
            if out:
                first = False
                yield out
    yield suffix


_MEDIA_TYPES = {
    "jsonl": "application/x-ndjson",
    "json": "application/json",
    "csv": "text/csv",
    "arrow": "application/vnd.apache.arrow.stream",
    "parquet": "application/vnd.apache.parquet",
}


def media_type_for(fmt: str) -> str:
    return _MEDIA_TYPES.get(fmt, "application/octet-stream")


def encode_batches(fmt: str, batches: Iterable[Any], *,
                   envelope: Optional[dict] = None) -> Iterator[bytes]:
    """Dispatch to the incremental encoder for ``fmt``."""
    if fmt == "jsonl":
        return _encode_jsonl(batches)
    if fmt == "csv":
        return _encode_csv(batches)
    if fmt == "arrow":
        return _encode_arrow(batches)
    if fmt == "parquet":
        return _encode_parquet(batches)
    if fmt == "json":
        return _encode_json_envelope(batches, envelope or {})
    raise HTTPException(400, f"Unsupported bulk format '{fmt}' — expected one of {', '.join(BULK_FORMATS)}")


# ══════════════════════════════════════════════════════════════════════════════
# Progress-bounded supervision
# ══════════════════════════════════════════════════════════════════════════════

# Streams whose producer thread was abandoned mid-read (see ``stall_guard``).
# Exposed for observability: a non-zero, growing value means real I/O is
# wedging and the pod should be recycled, even though the bulk lane is healthy.
_abandoned_producers = 0


def abandoned_producer_count() -> int:
    """How many producer threads have been abandoned to a wedged read."""
    return _abandoned_producers


def stall_guard(chunks: Iterable[bytes], *, timeout_s: float) -> Iterator[bytes]:
    """Bound PROGRESS, not duration -- including progress that never STARTS.

    A total-duration timeout makes a legitimate multi-hour 10M-row export
    impossible -- which is precisely what the paged path's 300s cap does
    today.  What actually needs bounding is a stream that has STOPPED
    producing.  Each yielded chunk resets the clock; only a gap longer than
    ``timeout_s`` between chunks aborts.

    F7 (2026-08-08) -- the previous implementation was a pure ``for chunk in
    chunks`` loop that compared timestamps AFTER each chunk arrived.  It could
    therefore only ever punish a producer that came back late; a producer that
    never came back at all -- ``pf.iter_batches`` blocked in an uninterruptible
    read against a hung NFS/EBS mount -- was never evaluated, never raised, and
    so the ``finally`` that returns the bulk lane slot never ran.  With
    ``bulk_max_concurrent=4``, four wedged streams zero the lane permanently
    and every external team gets 429 until the pod is restarted.  The guard was
    supervising the wrong side of the call.

    So the producer now runs on its own thread and hands chunks through a
    BOUNDED queue, and the timeout applies to the ``get`` -- i.e. to the WAIT.
    A wedged read is detected in ``timeout_s`` whether or not it ever yields.
    We cannot kill a thread parked in a blocking syscall (nothing in CPython
    can), and pretending otherwise would be the fiction the old code shipped;
    what we CAN do is stop waiting on it, raise, let the caller's ``finally``
    return the lane, and abandon the thread as a daemon that dies with the
    process.  The lane -- the resource whose exhaustion takes the whole
    endpoint down for everyone -- is recovered either way.

    Memory stays bounded by chunk: the queue holds at most ``_QUEUE_DEPTH``
    chunks, not the stream.
    """
    if timeout_s is None or timeout_s <= 0:
        # No supervision requested — stay a plain pass-through so we do not
        # spend a thread per stream for nothing.
        for chunk in chunks:
            yield chunk
        return

    import queue as _queue
    import threading

    _QUEUE_DEPTH = 2
    q: "_queue.Queue" = _queue.Queue(maxsize=_QUEUE_DEPTH)
    _DONE = object()
    stop = threading.Event()

    def _produce():
        try:
            for chunk in chunks:
                if stop.is_set():
                    break
                # Bounded put: the producer blocks here once the consumer is
                # behind, which is what keeps peak memory at queue depth.
                # Re-checked against `stop` so an abandoned producer that DOES
                # eventually wake up exits instead of parking forever.
                while not stop.is_set():
                    try:
                        q.put(("chunk", chunk), timeout=0.5)
                        break
                    except _queue.Full:
                        continue
            if not stop.is_set():
                q.put(("done", _DONE))
        except BaseException as exc:                 # noqa: BLE001 - relayed
            if not stop.is_set():
                try:
                    q.put(("error", exc))
                except Exception as _rexc:           # pragma: no cover
                    # The consumer will never learn why this stream ended, so
                    # the reason has to survive here or it is lost entirely.
                    logger.error(
                        "[pv-bulk] producer failed with %r and the failure could "
                        "not be relayed to the consumer (%s) — the stream will "
                        "look like a clean end", exc, _rexc,
                    )

    t = threading.Thread(target=_produce, name="pv-bulk-producer", daemon=True)
    t.start()
    try:
        while True:
            try:
                kind, payload = q.get(timeout=timeout_s)
            except _queue.Empty:
                global _abandoned_producers
                _abandoned_producers += 1
                stop.set()
                logger.error(
                    "[pv-bulk] producer made no progress for %.0fs (limit %.0fs) — "
                    "abandoning the read and returning the lane slot. "
                    "abandoned_producers=%d (a growing count means wedged storage I/O, "
                    "not a slow query)",
                    timeout_s, timeout_s, _abandoned_producers,
                )
                raise TimeoutError(
                    f"Bulk stream stalled — no data produced for {timeout_s:.0f}s "
                    f"(limit {timeout_s:.0f}s)"
                )
            if kind == "chunk":
                yield payload
            elif kind == "done":
                return
            else:
                raise payload
    finally:
        # Client disconnect / caller break: tell the producer to stop so it
        # does not sit forever on a full queue holding an open parquet handle.
        stop.set()
        try:
            q.get_nowait()      # unblock a producer parked on a full queue
        except _queue.Empty:
            pass


def gzip_stream(chunks: Iterable[bytes], *, level: int = 6,
                min_flush_bytes: int = 65536) -> Iterator[bytes]:
    """Compress a byte stream INCREMENTALLY, without wrecking the ratio.

    Deliberately not Starlette's ``GZipMiddleware``: that would apply to every
    endpoint in the app, and the point here is to keep the change scoped to
    bulk.

    The subtlety is WHEN to flush.  ``Z_SYNC_FLUSH`` after every input chunk
    keeps the stream maximally progressive but ends a deflate block each
    time; with small chunks (a caller passing ``batch_rows=100``, or the
    row-at-a-time shapes a test exercises) that collapses the ratio to ~2x
    on data that should compress ~8x.  So we flush only once at least
    ``min_flush_bytes`` of COMPRESSED output has accumulated: memory stays
    bounded by that buffer, the consumer still decompresses progressively,
    and the ratio no longer depends on the caller's batch size.
    """
    import zlib

    compressor = zlib.compressobj(level, zlib.DEFLATED, 16 + zlib.MAX_WBITS)
    pending: List[bytes] = []
    pending_len = 0

    for chunk in chunks:
        out = compressor.compress(chunk)
        if out:
            pending.append(out)
            pending_len += len(out)
        if pending_len >= min_flush_bytes:
            out = compressor.flush(zlib.Z_SYNC_FLUSH)
            if out:
                pending.append(out)
            yield b"".join(pending)
            pending, pending_len = [], 0

    tail = compressor.flush(zlib.Z_FINISH)
    if tail:
        pending.append(tail)
    if pending:
        yield b"".join(pending)


# ══════════════════════════════════════════════════════════════════════════════
# Consumer-facing headers — reconcilable without trusting the payload
# ══════════════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════════
# Signed part download (2026-08-22, design_starburst_140m §4.4)
# ══════════════════════════════════════════════════════════════════════════════
#
# GET /bulk/download hands the consumer per-part URLs signed with an HMAC
# over (view_id, cache_key, dataset_version, part_index, expiry).  The
# part route then serves the EXISTING immutable file as a byte stream —
# no conversion, no concatenation, no extra copy: the dataset is never
# re-materialised in the pod for a download.  The token is the
# credential: it names exactly one part of exactly one materialisation
# and dies at expiry.

_SIGNING_KEY: Optional[bytes] = None


def _bulk_signing_key() -> bytes:
    """Signing key: QUERY_STUDIO_SECRET_KEY, else the persistent key file
    (paths.secret_key_file — same source core.crypto trusts), else a
    per-process random key (links then die on pod restart — logged)."""
    global _SIGNING_KEY
    if _SIGNING_KEY is not None:
        return _SIGNING_KEY
    import os
    key = (os.environ.get("QUERY_STUDIO_SECRET_KEY") or "").strip()
    if not key:
        # 2026-10-03 -- a link signed by one process is verified by
        # whichever process (of whichever pod) the download lands on, so
        # every process must hold the SAME key.  Read only, this found no
        # file on a fresh volume and each process minted its own random
        # key: on an N-worker pod (N-1)/N of the part downloads answered
        # 403.  core.crypto publishes the key file ONCE (link/O_EXCL --
        # the 2026-10-02 race fix); ask it first, then read what is there.
        try:
            from core import crypto as _crypto
            _crypto._get_fernet()
        except Exception as exc:
            logger.debug("[pv-bulk] crypto key publication skipped: %s", exc)
        key = (os.environ.get("QUERY_STUDIO_SECRET_KEY") or "").strip()
    if not key:
        try:
            from core.config import paths as _paths
            kf = _paths.secret_key_file
            if kf and Path(str(kf)).is_file():
                key = Path(str(kf)).read_text().strip()
        except Exception as exc:
            logger.debug("[pv-bulk] secret key file unavailable: %s", exc)
    if not key:
        import secrets as _secrets
        key = _secrets.token_hex(32)
        logger.warning(
            "[pv-bulk] no persistent secret available — signed download "
            "URLs will not survive a pod restart (set "
            "QUERY_STUDIO_SECRET_KEY to fix)")
    _SIGNING_KEY = key.encode("utf-8")
    return _SIGNING_KEY


def _part_payload(view_id, cache_key: str, dataset_version: str,
                  part_index: int, expires: int) -> bytes:
    return (f"{view_id}|{cache_key}|{dataset_version}|{int(part_index)}|"
            f"{int(expires)}").encode("utf-8")


def sign_part_token(view_id, cache_key: str, dataset_version: str,
                    part_index: int, ttl_seconds: int) -> str:
    import hmac as _hmac
    import hashlib as _hl
    import time as _t
    expires = int(_t.time()) + max(1, int(ttl_seconds))
    mac = _hmac.new(_bulk_signing_key(),
                    _part_payload(view_id, cache_key, dataset_version,
                                  part_index, expires),
                    _hl.sha256).hexdigest()
    return f"{expires}.{mac}"


def verify_part_token(token: str, *, view_id, cache_key: str,
                      dataset_version: str, part_index: int) -> None:
    """403 on anything but a fresh, exact signature.  Compares with
    hmac.compare_digest — a prefix-guessable check is no check."""
    import hmac as _hmac
    import hashlib as _hl
    import time as _t
    try:
        expires_s, mac = str(token or "").split(".", 1)
        expires = int(expires_s)
    except (ValueError, AttributeError):
        raise HTTPException(403, "Invalid download token")
    if _t.time() > expires:
        raise HTTPException(
            403, "Download token expired — request GET /bulk/download again")
    want = _hmac.new(_bulk_signing_key(),
                     _part_payload(view_id, cache_key, dataset_version,
                                   part_index, expires),
                     _hl.sha256).hexdigest()
    if not _hmac.compare_digest(want, mac):
        raise HTTPException(403, "Invalid download token")


def bulk_download_url_ttl_seconds() -> int:
    return max(1, int(_cfg("bulk_download_url_ttl_seconds", 900)))


def bulk_headers(
    ref: DatasetRef, *,
    request_id: str,
    offset: int,
    expected_rows: int,
    next_cursor: Optional[str] = None,
    fmt: str = "jsonl",
    slug: str = "view",
    extra: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """Everything a downstream ETL needs to prove the pull was complete.

    ``X-QS-Total-Rows`` is footer-derived and emitted BEFORE the body, so
    reconciling rows-received against it is a real completeness check --
    unlike a count computed from the payload, which can only ever agree with
    itself.
    """
    ext = {"jsonl": "jsonl", "json": "json", "csv": "csv",
           "arrow": "arrow", "parquet": "parquet"}.get(fmt, "dat")
    h = {
        # ── authoritative, source-derived counts ──
        "X-QS-Total-Rows": str(ref.total_rows),
        "X-QS-Total-Mode": ref.total_mode,
        "X-QS-Row-Count-Source": "parquet-footer",
        "X-QS-Expected-Rows": str(max(0, int(expected_rows))),
        "X-QS-Row-Offset": str(max(0, int(offset))),
        # ── snapshot consistency / provenance ──
        "X-QS-Dataset-Version": ref.version,
        "X-QS-Data-Status": ref.data_status,
        # ── observability ──
        "X-Request-ID": request_id,
        "X-QS-Request-ID": request_id,
        "Content-Disposition": f'attachment; filename="{slug}.{ext}"',
        # A stream cannot be length-prefixed; make that explicit to proxies.
        "X-Accel-Buffering": "no",
        "Cache-Control": "no-store",
    }
    if ref.is_parts:
        h["X-QS-Parts"] = str(ref.num_row_groups)
    if ref.building:
        # An in-flight build being served by explicit opt-in: the total
        # is a floor, and more rows will exist shortly.  Total-Mode
        # already says at_least; this header makes the WHY visible.
        h["X-QS-Building"] = "true"
    if ref.snapshot_id is not None:
        h["X-QS-Snapshot-Id"] = str(ref.snapshot_id)
    if ref.as_of_timestamp_ms is not None:
        h["X-QS-As-Of-Timestamp-Ms"] = str(ref.as_of_timestamp_ms)
    if next_cursor:
        h["X-QS-Next-Cursor"] = next_cursor
    # Surface the custom headers to browser clients (CORS allowlist).
    h["Access-Control-Expose-Headers"] = ", ".join(
        k for k in h if k.startswith("X-")
    )
    if extra:
        h.update(extra)
    return h
