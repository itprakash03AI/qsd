"""
Phase 134-E: Published Views Background Warm-Up.

Pre-executes active views before consumers hit the API,
ensuring cache-hot responses (~50-100ms).
"""

import asyncio
import logging
from typing import Optional
from core.db_async import adb

logger = logging.getLogger(__name__)

_db_manager = None
_pv_cfg = None
_warmup_task: Optional[asyncio.Task] = None
_running = False


def set_warmup_dependencies(db_manager, pv_cfg):
    """Inject dependencies from main.py startup."""
    global _db_manager, _pv_cfg
    _db_manager = db_manager
    _pv_cfg = pv_cfg


async def _warmup_cycle():
    """Single warm-up cycle: refresh views whose cache is aging."""
    if not _db_manager or not _pv_cfg:
        return 0
    try:
        from api.published_views_api import (
            _execute_view, _persist_result_to_cache_async,
        )
        import api.published_views_api as _pv_core
        from api.published_views.helpers import (
            _build_cache_key, _default_params, _report_version_scope,
            pv_cache_path,
        )
        views = await adb(_db_manager.list_published_views, active_only=True) or []
        warmed = 0
        # 0 = UNLIMITED product-wide; Semaphore(0) is an outage, not a
        # limit — warm-up would hang on the first view forever.
        from core.concurrency_permits import sem_permits as _sem_permits
        semaphore = asyncio.Semaphore(_sem_permits(
            _pv_cfg.warmup_max_concurrent, name="published_views.warmup"))

        async def _warm_one(pv: dict):
            nonlocal warmed
            async with semaphore:
                try:
                    slug = pv.get("slug", "")
                    # 2026-08 redesign — warm-up must produce the EXACT cache
                    # entry a consumer request will look up, or it is a pure
                    # S3/engine burn.  The old loop called _execute_view and
                    # threw the result away: the response cache is written by
                    # the persist chokepoint below, which the loop never
                    # called, so consumers still got a MISS every time.
                    # Same key ingredients as the endpoint: no filters, the
                    # view's DECLARED PARAM DEFAULTS (shared _default_params
                    # chokepoint — the endpoint fills them identically), no
                    # user scope (RLS views are skipped above).
                    # P4 (2026-08-17): same limit resolution as the endpoint
                    # (NULL row → live config; 0 = unlimited) so the warmed
                    # entry matches what a default consumer request reads.
                    from api.published_views.helpers import effective_page_limit
                    _limit = effective_page_limit(pv, None)
                    _params = _default_params(pv.get("param_definitions") or [])
                    result = await _execute_view(
                        pv, filters=[], columns=None,
                        sort_column=None, sort_dir="asc",
                        limit=_limit, offset=0,
                        params=_params,
                    )
                    _cache_dir = getattr(_pv_core, "_cache_dir", None)
                    if _cache_dir is not None:
                        # 2026-09-05 — the publish-lifecycle ingredient is
                        # part of the key the ENDPOINT computes, so warm-up
                        # must compute it too or it fills a slot no consumer
                        # ever looks up (the exact "pure S3/engine burn" the
                        # comment above was written about).
                        _key = _build_cache_key(
                            pv["id"], [], None, "asc", None, _limit, 0, _params,
                            report_version=await adb(
                                _report_version_scope, pv, _db_manager),
                        )
                        # Paged slot only.  Warmup materializes under /data's
                        # 1M dataset_row_cap, so it must never be able to
                        # overwrite a bulk dataset — doing so replaced an
                        # uncapped export with a capped one every 5 minutes and
                        # invalidated every outstanding bulk cursor on exactly
                        # the views an operator marked hot (F10).
                        _cached_path = pv_cache_path(_cache_dir, pv["id"], _key)
                        # Off the event loop: this copy runs in a background
                        # task that shares the loop with ~1000 interactive users.
                        if not await _persist_result_to_cache_async(
                                result, _cached_path, slug=slug):
                            logger.warning(
                                "[pv-warmup] view %s executed but produced no "
                                "cacheable dataset — cache NOT warmed", slug,
                            )
                            return
                    warmed += 1
                    logger.debug("Warmed view %s", slug)
                except Exception as exc:
                    logger.warning("Warm-up failed for view %s: %s", pv.get("slug", "?"), exc)

        # BF-415 — skip PVs with row-security policies.  Warmup has no
        # consumer identity, so the RLS rewriter would either fall back to
        # a synthetic "pv:<slug>" principal (producing rows that don't match
        # any real user's policy) OR run unrestricted, then the resulting
        # parquet would be returned to consumers as a cache HIT — leaking
        # data across users.  RLS-bearing PVs must execute on-demand per
        # consumer; warmup is unsafe.
        # Phase 131 deep-dive #13 (hardening): if row_security is enabled
        # globally, EVERY PV is a potential RLS target via connection-
        # level policies — even if the PV itself doesn't carry an
        # explicit rls_enabled flag.  Warmup would either run as admin
        # (full data) or as anonymous (empty) and then cache that for
        # all consumers — a cross-user leak.
        #
        # 2026-09-26 (F0, row security ON by default) -- "globally on"
        # alone would have switched warm-up off for every deployment.  The
        # question is whether the UNSCOPED slot is safe for every consumer,
        # and ``core.row_security.cache_scope`` answers it: yes while the
        # policy set is readable and EMPTY (the rewriter is a no-op, and
        # that is the slot every consumer reads); no once any policy
        # exists or the store cannot be read -- then every view is skipped,
        # exactly as before.
        try:
            from core.row_security.cache_scope import shared_slot_is_safe
            _rls_global_on = not shared_slot_is_safe()
        except Exception:
            _rls_global_on = True

        def _has_rls(v: dict) -> bool:
            if _rls_global_on:
                return True
            if bool(
                v.get("row_security_policies")
                or v.get("row_security_enabled")
                or v.get("rls_enabled")
            ):
                return True
            # 2026-08-29 — the same rule this function already applies, for
            # the other way a view's SQL can differ per consumer.  A view
            # whose SQL references ``${user.*}`` renders per principal even
            # with row-security OFF, so warming it has no one to warm it AS:
            # it would execute with no identity (rendering the never-match
            # sentinel), then persist an EMPTY result under the unscoped
            # cache key -- which no real consumer can ever read, because
            # every consumer of such a view computes a non-None scope.
            # Engine burn every cycle, forever, for bytes nobody collects.
            try:
                from api.published_views.helpers import (
                    _pv_sql_is_principal_varying)
                return bool(_pv_sql_is_principal_varying(v))
            except Exception:
                return True          # cannot tell ⇒ do not warm

        warmup_views = [
            v for v in views
            if v.get("background_warmup", False) and not _has_rls(v)
        ]
        skipped_rls = sum(
            1 for v in views
            if v.get("background_warmup", False) and _has_rls(v)
        )
        if skipped_rls:
            logger.info(
                "[pv-warmup] skipped %d RLS-bearing view(s) — they execute on-demand per consumer",
                skipped_rls,
            )
        if not warmup_views:
            return 0
        await asyncio.gather(*[_warm_one(v) for v in warmup_views])
        return warmed
    except Exception as exc:
        logger.error("Warm-up cycle error: %s", exc)
        return 0


async def _warmup_loop():
    """Continuous warm-up loop running at configured interval."""
    global _running
    _running = True
    logger.info("PV warm-up loop started (interval=%dm)", _pv_cfg.warmup_interval_minutes if _pv_cfg else 5)
    while _running:
        interval = (_pv_cfg.warmup_interval_minutes if _pv_cfg else 5) * 60
        try:
            if await _claim_this_interval(interval):
                count = await _warmup_cycle()
                if count > 0:
                    logger.info("Warmed %d published views", count)
        except Exception as exc:
            logger.error("Warm-up loop error: %s", exc)
        await asyncio.sleep(interval)


async def _claim_this_interval(interval_seconds: int) -> bool:
    """ONE warm-up cycle per interval across the FLEET (2026-10-03).

    This loop starts in every process that boots main.py with
    ``published_views.warmup_enabled`` -- every pod, and every uvicorn worker
    of an N-process pod -- and each cycle re-executes every warm view
    against its SOURCE (Snowflake, Starburst ...) to refill the SHARED cache
    directory.  N processes x M pods meant N x M identical source queries per
    interval for one set of files.  The shared fixed window
    (``core.rate_limiter.claim_once_per_window``) lets the first tick of an
    interval run it; the rest skip.  A store failure degrades to one cycle
    per process -- repeated work, never a cache left cold."""
    from core.db_async import adb
    from core.rate_limiter import claim_once_per_window
    claimed = await adb(claim_once_per_window, "pv_warmup_cycle",
                        max(1, int(interval_seconds)))
    if not claimed:
        logger.debug("[pv-warmup] another process ran this interval's cycle")
    return claimed


def start_warmup(loop=None):
    """Start the warm-up background task. Call from main.py startup."""
    global _warmup_task
    if not _pv_cfg or not _pv_cfg.warmup_enabled:
        logger.info("PV warm-up disabled")
        return
    if _warmup_task and not _warmup_task.done():
        logger.warning("PV warm-up already running")
        return
    if loop is None:
        loop = asyncio.get_event_loop()
    _warmup_task = loop.create_task(_warmup_loop())
    logger.info("PV warm-up scheduler started")


def stop_warmup():
    """Stop the warm-up background task. Call from shutdown."""
    global _running, _warmup_task
    _running = False
    if _warmup_task and not _warmup_task.done():
        _warmup_task.cancel()
        logger.info("PV warm-up scheduler stopped")
    _warmup_task = None
