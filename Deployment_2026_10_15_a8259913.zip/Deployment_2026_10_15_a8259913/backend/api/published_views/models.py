"""
Phase 133-B — Pydantic request/response models for Published Views API.

Pure data models. The ONLY internal dependency is core.parameters,
which is stdlib-only and carries THE parameter-type vocabulary -- a
re-spelled copy here is what FB-14 was (2026-09-17).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, model_validator

from core.parameters import PARAM_TYPES as _CORE_PARAM_TYPES

__all__ = [
    "ParamDefinition", "WhereClauseMapping", "PublishViewRequest", "UpdateViewRequest",
    "CreateApiKeyRequest", "UpdateQueryConfigRequest", "DetectPartitionsRequest",
    "ImportViewRequest", "WebhookCreateRequest", "WebhookUpdateRequest",
    "ApiKeyRequestCreate", "ApiKeyRequestReview", "ApiKeyRequestApprove",
]


#: The published-view parameter types, derived from THE vocabulary so a
#: type this API accepts is a type the substituter knows how to render.
_PARAM_TYPE_PATTERN = "^(" + "|".join(
    sorted(_CORE_PARAM_TYPES)) + ")$"


class ParamDefinition(BaseModel):
    """Phase 80: declares a runtime parameter accepted by a published view."""
    name: str = Field(..., min_length=1, max_length=64, pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$")
    # 2026-09-17 (FB-14) -- built from core.parameters.PARAM_TYPES, not
    # re-spelled.  The hand-written pattern accepted integer/float and
    # rejected "number", while the SUBSTITUTER treated only "number" as
    # numeric -- so the numeric half of this vocabulary was quoted as a
    # string in the generated SQL.  One list, one answer.
    type: str = Field(default="string", pattern=_PARAM_TYPE_PATTERN)
    required: bool = False
    default: Optional[Any] = None
    description: Optional[str] = None
    # AQD-04 -- "report" marks an entry INHERITED from the business report
    # (core.published_view_params.INHERITED_SOURCE): recomputed on every read
    # from the version the view serves, never frozen by a round-trip.  Omit
    # it to declare an override of your own.
    source: Optional[str] = Field(default=None, pattern=r"^report$")


# Phase 132.38 — ``WhereClauseMapping`` has been lifted to the shared
# module ``core.where_clause_mapping`` so Feed Generation configs, Feed
# Run triggers, and DataFlow stages share the same primitive.  This
# re-export preserves the existing ``from api.published_views.models
# import WhereClauseMapping`` call sites and the ``__all__`` contract.
from core.where_clause_mapping import WhereClauseMapping  # noqa: E402,F401


# ── U-H2 / E-H4 — safe publish-time defaults (config-overridable) ────────────
# Audit finding: an API/curl publish that OMITS default_limit / max_limit /
# cache_ttl_seconds used to inherit the model's own huge defaults
# (100000 / 1000000 / 28800) while the UI publishes the far safer
# 1000 / 50000 / 300.  A curl consumer therefore silently got million-row,
# 8-hour-cached views → OOM risk.  These factories lower the OMITTED-FIELD
# default to the UI-safe values, sourced from the ``published_views`` config
# section so a deployment can restore any prior value without a code change.
#
# BACKWARD-COMPAT: these factories only fire when the corresponding field is
# ABSENT from the publish request.  A request that passes an explicit value
# uses that value verbatim (the factory never runs).  Existing published
# views are stored with their explicit ``default_limit`` / ``max_limit`` /
# ``cache_ttl_seconds`` in the DB and are read from the row at execute time —
# this change does NOT touch stored views, only the default applied to NEW
# publishes that omit the field.  Config keys (all under ``published_views``):
#   default_limit  (safe default 1000)
#   max_limit      (safe default 50000)
#   cache_ttl      (safe default 300)
def _cfg_int(key: str, safe_default: int) -> int:
    """Read an int from the ``published_views`` config section, fail-safe.

    Any config-read error → ``safe_default`` (the UI-safe value), so a
    missing/corrupt config can never re-introduce the dangerous large
    default.  Kept lazy (called by pydantic ``default_factory`` at
    instantiation) so ``models.py`` stays import-safe with no eager
    ``core.config`` dependency.
    """
    try:
        from core.config import get as _get
        v = _get("published_views", key, safe_default)
        return int(v) if v is not None else safe_default
    except Exception:
        return safe_default


def _default_default_limit() -> int:
    return _cfg_int("default_limit", 1000)


def _default_max_limit() -> int:
    return _cfg_int("max_limit", 50000)


def _default_cache_ttl_seconds() -> int:
    return _cfg_int("cache_ttl", 300)


class PublishViewRequest(BaseModel):
    """Publish-a-view request payload.

    U-H2/E-H4 (2026-07-16): ``default_limit`` / ``max_limit`` /
    ``cache_ttl_seconds`` now default to the UI-safe values
    (1000 / 50000 / 300) rather than the previous OOM-prone
    100000 / 1000000 / 28800, and are sourced from the ``published_views``
    config section (keys ``default_limit`` / ``max_limit`` / ``cache_ttl``)
    so a deployment can override.  Explicit request values always win over
    the factory; stored views are unaffected (see factory docstrings above).
    """
    query_id: Optional[int] = None                                            # Phase 91: optional (required only for saved_query source)
    slug: str = Field(..., min_length=2, max_length=100, pattern=r"^[a-z0-9][a-z0-9\-]*[a-z0-9]$")
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    allowed_filters: List[str] = Field(default_factory=list)
    # P4 (2026-08-17): ge=0 — an EXPLICIT 0 publishes an unlimited view (the
    # product-wide 0=unlimited spelling).  When the field is OMITTED entirely,
    # the publish endpoint stores NULL (detected via ``model_fields_set``) so
    # the view follows the LIVE ``published_views`` config at serve time
    # instead of freezing a snapshot; the factories below remain the
    # informational default shown on the request model.
    default_limit: int = Field(default_factory=_default_default_limit, ge=0, le=1000000)
    max_limit: int = Field(default_factory=_default_max_limit, ge=0, le=1000000)
    cache_ttl_seconds: int = Field(default_factory=_default_cache_ttl_seconds, ge=0, le=86400)   # U-H2/E-H4: UI-safe 300 (was 8hr)
    param_definitions: List[ParamDefinition] = Field(default_factory=list)   # Phase 80
    allowed_ad_groups: List[str] = Field(default_factory=list)               # Phase 82: AD group access control
    source_type: str = Field(default="saved_query", pattern="^(saved_query|business_report|federation|sql_file|sql_query)$")
    business_report_id: Optional[int] = None                                 # Phase 91
    federation_view_id: Optional[int] = None                                 # Phase 93
    sql_file_id: Optional[int] = None                                        # Phase 122C
    # Phase 154 (2026-06-25) -- CQB cross-source published API.  Closes
    # the operator gap where a CQB cross-source SQL query (saved in
    # ``sql_saved_queries`` with primary + secondary connection_ids
    # and SQL bodies) could not be published.  source_type="sql_query"
    # routes through SqlSavedQuery rather than the BQB SavedQuery
    # table; cross-conn fields snapshot directly from the row.
    sql_query_id: Optional[int] = None
    # Cache controls
    min_cache_age_seconds: int = Field(default=60, ge=0, le=86400)
    allow_cache_bypass: bool = True   # consumers can always request fresh data
    cache_strategy: str = Field(default="ttl", pattern="^(ttl|live)$")
    # Phase 146-A — Multi-engine: connection IDs the consumer may pick via
    # ?engine=.  Empty/None = legacy single-engine behaviour (uses
    # connection_id from the snapshotted query_config).
    allowed_engine_connections: Optional[List[int]] = None
    # BF-430A — per-PV reader override (registered name in core.s3_readers).
    # NULL = use snapshotted query_config / global s3_readers config.
    # Validated against registry by the API endpoint at write time.
    reader_override: Optional[str] = Field(None, max_length=64,
                                            pattern=r"^[a-z][a-z0-9_]*$")
    # Phase 132.37 — explicit per-PV WHERE mapping.  Static rows become
    # frozen filters in the query_config snapshot; Dynamic rows are added
    # to allowed_filters so consumers can override via ?col=value.
    where_clauses: List[WhereClauseMapping] = Field(default_factory=list)
    # Phase 133-J — publisher-time credential routing.  The publish dialog
    # asks the publisher (1) which connection consumers should run against
    # and (2) whose credentials should resolve at runtime.  All three modes
    # auto-resolve on the curl path — no per-consumer prompt.
    #   consumer  — calling user's vault (default; backwards compatible)
    #   publisher — publisher's vault, frozen at publish time
    #   shared    — connection's system_account (requires is_shared=true)
    execution_connection_id: Optional[int] = None
    credential_mode: str = Field(default="consumer",
                                 pattern="^(consumer|publisher|shared)$")

    @model_validator(mode="after")
    def _check_source_fields(self) -> "PublishViewRequest":
        """Phase 91/93: validate source-specific required fields."""
        if self.source_type == "business_report":
            if not self.business_report_id:
                raise ValueError("business_report_id is required when source_type='business_report'")
        elif self.source_type == "federation":
            if not self.federation_view_id:
                raise ValueError("federation_view_id is required when source_type='federation'")
        elif self.source_type == "sql_file":
            if not self.sql_file_id:
                raise ValueError("sql_file_id is required when source_type='sql_file'")
        elif self.source_type == "sql_query":
            if not self.sql_query_id:
                raise ValueError("sql_query_id is required when source_type='sql_query'")
        else:
            if not self.query_id:
                raise ValueError("query_id is required when source_type='saved_query'")
        return self


class UpdateViewRequest(BaseModel):
    slug: Optional[str] = Field(None, min_length=2, max_length=100, pattern=r"^[a-z0-9][a-z0-9\-]*[a-z0-9]$")
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    allowed_filters: Optional[List[str]] = None
    # P4 (2026-08-17): ge=0 — explicit 0 = unlimited; an explicit JSON null
    # clears the per-view value so the view follows the live config again.
    default_limit: Optional[int] = Field(None, ge=0, le=1000000)
    max_limit: Optional[int] = Field(None, ge=0, le=1000000)
    cache_ttl_seconds: Optional[int] = Field(None, ge=0, le=86400)
    param_definitions: List[ParamDefinition] = Field(default_factory=list)   # Phase 80
    allowed_ad_groups: Optional[List[str]] = None                            # Phase 82: AD group access control
    source_type: Optional[str] = Field(None, pattern="^(saved_query|business_report|federation|sql_file|sql_query)$")  # Phase 91 / 154
    business_report_id: Optional[int] = None                                 # Phase 91
    federation_view_id: Optional[int] = None                                 # Phase 93
    sql_query_id: Optional[int] = None                                       # Phase 154
    # Phase 98-G: per-view cache intelligence controls (admin-editable)
    min_cache_age_seconds: Optional[int] = Field(None, ge=0, le=86400)
    allow_cache_bypass: Optional[bool] = None
    cache_strategy: Optional[str] = Field(None, pattern="^(ttl|live)$")
    # Phase 146-A — Multi-engine connection whitelist
    allowed_engine_connections: Optional[List[int]] = None
    # BF-430A — per-PV reader override.  Pass empty string ("") to clear.
    reader_override: Optional[str] = Field(None, max_length=64,
                                            pattern=r"^([a-z][a-z0-9_]*)?$")
    # Phase 132.37 — explicit WHERE mapping (re-apply to query_config on update).
    where_clauses: Optional[List[WhereClauseMapping]] = None
    # Phase 133-J — publisher-time credential routing (see PublishViewRequest).
    execution_connection_id: Optional[int] = None
    credential_mode: Optional[str] = Field(None,
                                            pattern="^(consumer|publisher|shared)$")


class CreateApiKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    scoped_view_ids: List[int] = Field(default_factory=list)
    rate_limit: Optional[str] = Field(None, pattern=r"^\d{1,6}/(second|minute|hour)$")
    expires_hours: Optional[int] = Field(None, ge=1, le=87600)  # max ~10 years
    # P1 (2026-08-17) — a key with EMPTY scoped_view_ids no longer grants
    # access to every view (fail-closed).  A genuinely-global key must be
    # requested EXPLICITLY via this flag; it is stored as the "*" sentinel in
    # the key's scope list and audit-logged loudly at creation time.
    global_access: bool = False


# ── Self-Service API Key Request/Approval ─────────────────────────────────

class ApiKeyRequestCreate(BaseModel):
    """User submits a request for an API key."""
    key_name: str = Field(..., min_length=1, max_length=255)
    scoped_view_ids: List[int] = Field(..., min_length=1)
    rate_limit: Optional[str] = Field(None, pattern=r"^\d{1,6}/(second|minute|hour)$")
    expires_hours: Optional[int] = Field(None, ge=1, le=87600)
    justification: Optional[str] = Field(None, max_length=1000)


class ApiKeyRequestReview(BaseModel):
    """Base review model (shared by approve + deny)."""
    note: Optional[str] = Field(None, max_length=1000)


class ApiKeyRequestApprove(ApiKeyRequestReview):
    """Admin approves a pending API key request — optional overrides."""
    rate_limit_override: Optional[str] = Field(None, pattern=r"^\d{1,6}/(second|minute|hour)$")
    expires_hours_override: Optional[int] = Field(None, ge=1, le=87600)


class UpdateQueryConfigRequest(BaseModel):
    """Phase 98-C: Update the frozen query_config of a published view in-place."""
    query_config: dict


class DetectPartitionsRequest(BaseModel):
    """Phase 98-H: Detect partition columns for auto-param injection on publish."""
    query_config: dict
    connection_id: Optional[int] = None


class ImportViewRequest(BaseModel):
    """Phase 98-E: Portable import payload."""
    views: List[dict]  # list of exported view dicts
    connection_map: Optional[Dict[str, str]] = None  # {"UAT_conn": "PROD_conn"}
    overwrite_existing: bool = True  # upsert by slug


class WebhookCreateRequest(BaseModel):
    view_id: int | None = None
    url: str = Field(..., pattern=r"^https?://")
    events: List[str] = Field(..., min_length=1)
    secret: str | None = None
    retry_max: int = Field(default=3, ge=0, le=10)
    timeout_seconds: int = Field(default=10, ge=1, le=60)


class WebhookUpdateRequest(BaseModel):
    url: str | None = None
    events: List[str] | None = None
    secret: str | None = None
    is_active: bool | None = None
    retry_max: int | None = Field(None, ge=0, le=10)
    timeout_seconds: int | None = Field(None, ge=1, le=60)
