"""
Phase 133-B — Pure helper functions for Published Views API.

No router, no globals, no async endpoints. Functions that need config/cache/db
receive them as optional parameters — callers pass their module-level singletons.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import logging
import os
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from fastapi import HTTPException, Request, Response
from fastapi.responses import StreamingResponse

from core.json_utils import sanitize_for_json

# 2026-08 strategic redesign — single owner of result truth (manifest, page
# reader, Arrow-native renderers).  See envelope.py module docstring.
from api.published_views.envelope import (
    col_meta_from_schema, excel_cell, iter_row_batches, read_page,
    rows_from_table,
)

logger = logging.getLogger(__name__)


# ── U-H4 — in-process fail-CLOSED rate-limit fallback ─────────────────────────
# The primary limiter (core.rate_limiter: Redis, else the SHARED window on the
# metadata database) is authoritative, and it already falls back fail-closed
# itself when its store errors.  If it RAISES anyway (misconfig, an import
# failure) we must NOT sail through unthrottled — a broken limiter used to mean
# effectively unlimited access.  This process-local fixed-window counter is the
# conservative safety net used ONLY then.  It is per PROCESS, so it UNDER-counts
# a fleet (every process admits its own budget): 2026-10-03 it therefore limits
# at this process's share of the pod's budget (core.process_topology), so one
# pod admits at most the fallback rate however many workers it runs.
_FALLBACK_RL_STATE: Dict[str, tuple] = {}   # identity -> (count, window_start_epoch)
_FALLBACK_RL_LOCK = threading.Lock()


def _inprocess_rate_check(identity: str, limit: int, window_seconds: int) -> bool:
    """Fixed-window in-process rate check.  Returns True if allowed, False if
    the identity has exceeded ``limit`` within the current ``window_seconds``.

    Fail-safe: any internal error returns True (allow) — the caller has already
    logged the primary-limiter failure loudly, and we don't want the safety net
    itself to hard-fail every request.
    """
    try:
        if limit <= 0:
            return True
        now = time.time()
        with _FALLBACK_RL_LOCK:
            count, start = _FALLBACK_RL_STATE.get(identity, (0, now))
            if now - start >= window_seconds:
                count, start = 0, now
            count += 1
            _FALLBACK_RL_STATE[identity] = (count, start)
            # Opportunistic cleanup so the dict can't grow unbounded across many
            # distinct identities over time.
            if len(_FALLBACK_RL_STATE) > 50000:
                _stale = [k for k, (_c, s) in _FALLBACK_RL_STATE.items()
                          if now - s >= window_seconds]
                for k in _stale[:10000]:
                    _FALLBACK_RL_STATE.pop(k, None)
            return count <= limit
    except Exception:
        return True

__all__ = [
    "_export_view_dict", "_parse_rate_limit", "_enforce_api_key_rate_limit",
    "_check_key_scope", "_check_view_access", "_parse_filters",
    # P1 (2026-08-17) — explicit global-key sentinel; empty scope = NO views.
    "GLOBAL_KEY_SCOPE_SENTINEL", "_key_scope_is_global",
    # P4 (2026-08-17) — serve-time limit resolution (NULL follows config, 0 = unlimited).
    "PV_UNLIMITED_ROWS", "resolve_view_limits", "effective_page_limit",
    "_parse_params", "_default_params", "_validate_param_types", "_substitute_params",
    "_build_cache_key", "_user_cache_scope",
    # 2026-09-05 — publish-lifecycle identity of a BR-backed view.
    "_report_version_scope", "REPORT_VERSION_UNRESOLVED",
    # F2 (2026-08-08) — cache SLOT naming.  Bulk datasets are unbounded and
    # must never land in the slot the paged /data reader opens.
    "pv_cache_path", "pv_cache_is_bulk", "PV_BULK_MARKER",
    "_build_json_envelope", "_extract_schema_from_config",
    "_extract_schema_from_cache", "_build_col_meta",
    "_clear_view_cache", "_read_cached_result",
    "_csv_response", "_parquet_download", "_excel_response", "_log_access",
    "_build_cache_hit_headers", "_build_miss_headers", "_send_response",
    # E-H4 — bounded-memory streaming response builders
    "_csv_streaming_from_df", "_json_streaming_from_df",
    "_pv_stream_enabled", "_pv_stream_batch_rows",
    # Phase 132.37 — shared filter-merge helpers used by all three
    # _execute_view_* handlers (saved_query / business_report / federation).
    "_col_key", "merge_static_and_consumer_filters",
]


# ── Export / Import helpers ──────────────────────────────────────────────────

def _export_view_dict(pv: dict, conn_name: str) -> dict:
    """Serialize a published view to a portable, environment-neutral dict."""
    return {
        "_schema": "querystudio_published_view_v1",
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_from": os.environ.get("QUERYSTUDIO_HOSTNAME", "unknown"),
        "slug": pv["slug"],
        "name": pv["name"],
        "description": pv.get("description"),
        "connection_name": conn_name,
        "query_config": pv.get("query_config") or {},
        "param_definitions": pv.get("param_definitions") or [],
        "allowed_filters": pv.get("allowed_filters") or [],
        "allowed_ad_groups": pv.get("allowed_ad_groups") or [],
        "default_limit": pv.get("default_limit", 1000),
        "max_limit": pv.get("max_limit", 50000),
        "rate_limit_per_minute": pv.get("rate_limit_per_minute", 60),
        "cache_ttl_seconds": pv.get("cache_ttl_seconds", 28800),
        "min_cache_age_seconds": pv.get("min_cache_age_seconds", 60),
        "allow_cache_bypass": pv.get("allow_cache_bypass", True),
        "cache_strategy": pv.get("cache_strategy", "ttl"),
        "source_type": pv.get("source_type", "saved_query"),
        "version": pv.get("version", 1),
        "query_hash": pv.get("query_hash"),
        # Phase 133-J — publisher-time credential routing.  publisher_username
        # is intentionally portable so importer can preserve the publisher
        # context when round-tripping between environments; on import we
        # default credential_mode to 'consumer' if missing for back-compat.
        "credential_mode": pv.get("credential_mode") or "consumer",
        "execution_connection_id": pv.get("execution_connection_id"),
        "publisher_username": pv.get("publisher_username"),
    }


# ── Per-view page limits (P4, 2026-08-17) ────────────────────────────────────
#
# ``default_limit`` / ``max_limit`` used to be SNAPSHOTTED onto the DB row at
# publish time (1000 / 50000), so changing the ``published_views`` config
# changed nothing for existing views — a persisted per-view value defeats any
# config-level fix.  New contract, resolved at SERVE time:
#
#   row value NULL (publisher omitted it)  → follow the LIVE config
#                                            (published_views.default_limit /
#                                             published_views.max_limit)
#   row value  0                           → UNLIMITED (the product-wide
#                                            spelling; also honoured at the
#                                            config level)
#   row value >0                           → the publisher's deliberate cap,
#                                            preserved verbatim
#
# ``PV_UNLIMITED_ROWS`` is the concrete row count handed to the bounded page
# readers when the resolution is "unlimited" — large enough to never clip a
# real dataset, small enough to stay an exact JSON/float64 integer.  The
# envelope builder normalises it away before consumers see it.

PV_UNLIMITED_ROWS = 2 ** 53


def _pv_limit_cfg_int(key: str, fallback: int) -> int:
    """Read an int limit from the ``published_views`` config section, fail-safe."""
    try:
        from core.config import get as _cfg_get
        v = _cfg_get("published_views", key, fallback)
        return fallback if v is None else int(v)
    except Exception:
        return fallback


def resolve_view_limits(pv: dict) -> tuple[int, int]:
    """Effective ``(default_limit, max_limit)`` for a view.

    NULL on the row → live config; values are floored at 0 (0 = unlimited).
    """
    d = pv.get("default_limit")
    m = pv.get("max_limit")
    try:
        d = _pv_limit_cfg_int("default_limit", 1000) if d is None else int(d)
    except (TypeError, ValueError):
        d = _pv_limit_cfg_int("default_limit", 1000)
    try:
        m = _pv_limit_cfg_int("max_limit", 50000) if m is None else int(m)
    except (TypeError, ValueError):
        m = _pv_limit_cfg_int("max_limit", 50000)
    # 2026-08-19 -- APPLY THE GLOBAL CEILING.
    #
    # `published_views.max_row_limit` is declared in _DEFAULTS, is displayed
    # and PERSISTED by the admin screen (GET/PUT /api/admin/published-views/
    # config, audit-logged), and was read by NOTHING: enforcement uses the
    # per-view DB columns above.  An admin who lowered the global cap saw it
    # saved, saw the audit entry, and the API kept serving the old limit.
    #
    # min() only ever TIGHTENS: with the shipped 1,000,000 global and a
    # 50,000 per-view max the result is 50,000, exactly as before.  It bites
    # only when an operator deliberately sets the global lower, which is the
    # obvious meaning of a global maximum.
    # 2026-08-20 -- SCOPED TO POSITIVE CAPS.  The line above read
    # `if _global_max > 0 and (m <= 0 or m > _global_max)`, and `m <= 0` is
    # UNLIMITED.  So a view deliberately published with max_limit=0 stopped
    # being unlimited and started truncating at 1,000,000 -- the SHIPPED
    # DEFAULT of max_row_limit, a number no operator ever chose -- while
    # still returning 200 with a success envelope.  That is the zero-fold
    # bug this module is structured to prevent, landing on the unbounded
    # bulk export that is the published API's reason to exist.
    #
    # A global maximum now TIGHTENS caps that exist; it does not INVENT one.
    # The admin lever still bites where it matters: every view with a
    # positive max, and every NULL row (which falls back to the 50,000 config
    # default and is then tightened here).  A row carrying an explicit 0 is
    # the publisher stating "no restriction", the same deliberate per-view
    # declaration that already wins over config elsewhere in this function.
    try:
        from core.config import get as _pv_cfg_get
        _global_max = int(_pv_cfg_get("published_views", "max_row_limit", 0) or 0)
        if _global_max > 0 and m > _global_max:
            m = _global_max
    except Exception:
        pass  # fail-open: a config problem must not change row caps
    return max(0, d), max(0, m)


def effective_page_limit(pv: dict, requested: Optional[int]) -> int:
    """Resolve the concrete page limit for a /data-style request.

    ``requested=None``   → the view's effective default limit.
    ``requested=0``      → "as much as allowed": the effective max, or
                           unlimited when the max itself is 0/unlimited.
    ``requested>0``      → the request value, capped at the effective max
                           (no cap when max is 0/unlimited).

    Returns a positive int; ``PV_UNLIMITED_ROWS`` encodes "no limit".  The
    guard against the classic ``a or b`` zero-fold is structural here: 0 is
    handled EXPLICITLY, never truth-tested.
    """
    d, m = resolve_view_limits(pv)
    if requested is None:
        eff = d
    else:
        eff = max(0, int(requested))
    if eff == 0:
        # Unlimited request (explicit 0, or a view whose default is 0):
        # bounded by the max cap when one exists.
        return m if m > 0 else PV_UNLIMITED_ROWS
    if m > 0:
        return min(eff, m)
    return eff


# ── Rate limiting ────────────────────────────────────────────────────────────

def _parse_rate_limit(rate_str: str | None, default: str = "60/minute") -> tuple[int, int]:
    """Parse a rate limit string like '120/minute' into (limit, window_seconds).

    Supported formats: 'N/minute', 'N/hour', 'N/second'.
    Falls back to *default* on parse failure.
    """
    s = rate_str or default
    try:
        parts = s.strip().split("/", 1)
        limit = int(parts[0])
        unit = parts[1].lower().strip() if len(parts) > 1 else "minute"
        window = {"second": 1, "minute": 60, "hour": 3600}.get(unit, 60)
        return max(limit, 0), window
    except (ValueError, IndexError):
        return _parse_rate_limit(default, "60/minute") if rate_str else (60, 60)


# 2026-10-03 -- ONE log line per identity per window, not one per 429.  A
# hot key past its limit produced thousands of identical WARNINGs a minute
# (measured live), drowning the log the operator reads to find it.  Now: the
# FIRST refusal of a window is logged at WARNING (saying later ones are
# counted), and the window's total is logged when that identity's next
# window first refuses -- or, for a key that stopped, when any identity is
# refused after its window ended (the summary is never silently dropped
# while the process keeps refusing anyone).
#: identity -> [window_start, window_seconds, limit, refused_count]
_RL_LOG_STATE: Dict[str, list] = {}
_RL_LOG_LOCK = threading.Lock()


def _note_rate_limited(identity: str, limit: int, window: int,
                       retry_after: int, *, now: Optional[float] = None) -> None:
    t = time.time() if now is None else float(now)
    w = max(1, int(window))
    ws = int(t // w) * w
    finished: list = []
    first = False
    with _RL_LOG_LOCK:
        # Windows that have ENDED are summarised (and forgotten) here.
        for ident in [i for i, st in _RL_LOG_STATE.items() if st[0] + st[1] <= t]:
            finished.append((ident, *_RL_LOG_STATE.pop(ident)))
        st = _RL_LOG_STATE.get(identity)
        if st is None:
            _RL_LOG_STATE[identity] = [ws, w, int(limit), 1]
            first = True
        else:
            st[3] += 1
    for ident, start, fw, flimit, count in finished:
        if count > 1:
            logger.warning("[pv-ratelimit] identity=%s was refused %d request(s) "
                           "in the %ds window that began at epoch %d (limit %d)",
                           ident, count, fw, start, flimit)
    if first:
        logger.warning("Rate limit exceeded for API key %s: retry_after=%ss "
                       "(limit %d per %ds; further refusals in this window "
                       "are counted, not logged)", identity, retry_after,
                       limit, w)


def _enforce_api_key_rate_limit(api_user: dict, pv_cfg=None) -> None:
    """Enforce per-API-key rate limit on v1 endpoints.

    Applies when the caller authenticated via API key (has a 'rate_limit'
    field).  AD-authenticated users are, by default, NOT rate-limited here
    (governance handles them) — U-H4 makes that bypass a config flag
    ``published_views.rate_limit_ad_users`` (default False = current
    behaviour) so operators can opt AD users in without surprise.

    U-H4 — FAIL-CLOSED: if the primary (Redis-backed) limiter raises, we no
    longer sail through unthrottled.  We log LOUDLY (WARN) and apply a
    conservative in-process fixed-window fallback; exceeding it still returns
    429.  The Redis happy-path is untouched.
    """
    _auth_method = api_user.get("auth_method")
    if _auth_method != "api_key":
        # AD / basic_noauth: bypass unless the operator opted AD users in.
        _rl_ad = False
        try:
            from core.config import get as _cfg_get
            _rl_ad = bool(_cfg_get("published_views", "rate_limit_ad_users", False))
        except Exception:
            _rl_ad = False
        if not (_rl_ad and _auth_method == "ad_basic"):
            return

    from core.rate_limiter import check_rate_limit, RateLimitExceededError
    # 2026-10-03 -- WHO is charged is the ONE admission rule
    # (published_views_api._admission_identity: ``apikey:<id>`` for a key,
    # the username for an AD-Basic caller).  This read
    # ``api_user.get("api_key_id", username)``, the dict.get-DEFAULT trap the
    # 2026-09-29 fix removed from the concurrency door: an opted-in AD caller
    # whose dict carries ``api_key_id: None`` was charged to the ONE bucket
    # named "None", shared with every other AD caller.
    from api.published_views_api import _admission_identity
    identity = _admission_identity(api_user)
    # Resolve the effective (limit, window) up-front so the fallback path can
    # reuse it if the primary limiter dies.
    key_limit_str = api_user.get("rate_limit")
    default_rl = "60/minute"
    max_rl = "300/minute"
    if pv_cfg:
        try:
            v = pv_cfg.default_rate_limit
            if isinstance(v, str) and "/" in v:
                default_rl = v
            v2 = pv_cfg.max_rate_limit
            if isinstance(v2, str) and "/" in v2:
                max_rl = v2
        except Exception as e:
            logger.debug("Failed to parse rate limit config: %s", e)
    limit, window = _parse_rate_limit(key_limit_str, default_rl)
    max_limit, max_window = _parse_rate_limit(max_rl)
    if window == max_window and limit > max_limit:
        limit = max_limit

    try:
        check_rate_limit("pv_api", identity, limit=limit, window_seconds=window)
    except RateLimitExceededError as exc:
        _note_rate_limited(identity, limit, window, exc.retry_after)
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded. Retry after {exc.retry_after}s.",
            headers={"Retry-After": str(exc.retry_after)},
        )
    except HTTPException:
        raise
    except Exception as exc:
        # U-H4 — primary limiter FAILED.  Do NOT fail open.  Log loudly and
        # apply the conservative in-process fallback limit.
        try:
            from core.config import get as _cfg_get
            _fallback_per_min = int(_cfg_get(
                "published_views", "rate_limit_fallback_per_minute", 60))
        except Exception:
            _fallback_per_min = 60
        # Use the tighter of the key's own limit and the conservative cap so a
        # low-limit key isn't loosened by the fallback.
        _fb_limit = _fallback_per_min
        if window == 60 and 0 < limit < _fb_limit:
            _fb_limit = limit
        # 2026-10-03 -- the POD's fallback budget, split across its processes.
        from core.process_topology import per_process_share as _pp_share
        if _fb_limit > 0:
            _fb_limit = _pp_share(_fb_limit)
        logger.warning(
            "[pv-ratelimit] PRIMARY limiter FAILED for identity=%s (%s) — "
            "applying conservative in-process fallback %d/60s. FIX the limiter "
            "backend (e.g. Redis); this fallback is per-process only.",
            identity, exc, _fb_limit,
        )
        if not _inprocess_rate_check(identity, limit=_fb_limit, window_seconds=60):
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded (limiter degraded — conservative "
                       "fallback in effect). Retry after 60s.",
                headers={"Retry-After": "60"},
            )


# ── Access control ───────────────────────────────────────────────────────────

# 2026-08-17 (P1) — EXPLICIT global-key sentinel.  A key whose scoped_view_ids
# list contains this marker (or the legacy-safe integer form -1) is a
# deliberately-created master key over every published view.  Global access is
# a PRESENCE on the key record, never an ABSENCE: an empty/null scope now means
# NO views (fail-closed, the product-wide UNKNOWN=UNSAFE invariant), where it
# used to mean EVERY view.
GLOBAL_KEY_SCOPE_SENTINEL = "*"
_GLOBAL_SCOPE_MARKERS = {GLOBAL_KEY_SCOPE_SENTINEL, -1, "-1"}


def _key_scope_is_global(scoped) -> bool:
    """True when the key's scope list carries the EXPLICIT all-views marker."""
    try:
        return any(s in _GLOBAL_SCOPE_MARKERS for s in (scoped or []))
    except TypeError:
        return False


def _empty_scope_legacy_master_key() -> bool:
    """Config escape hatch for live deployments mid-migration (default OFF).

    ``published_views.empty_scope_master_key = true`` restores the pre-2026-08-17
    behaviour where an empty-scope key could read EVERY view.  Fail-CLOSED: any
    config error means the escape hatch is OFF.
    """
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("published_views", "empty_scope_master_key", False))
    except Exception:
        return False


def _check_key_scope(api_user: dict, view_id: int) -> None:
    """Verify the API key has access to this view.

    2026-08-17 (P1) — FAIL-CLOSED rewrite.  The old check was
    ``if scoped and view_id not in scoped: 403`` — an empty/null scope made the
    condition false and the key became a MASTER KEY over every published view.
    New contract:

      * scope contains the view id            → allow
      * scope carries the explicit global marker ("*" / -1) → allow
      * EMPTY scope → DENY (unless the operator flipped the loud, documented
        ``published_views.empty_scope_master_key`` legacy escape hatch)
      * anything else → 403
    """
    import logging as _logging
    _scope_log = _logging.getLogger("auth.api_key_scope")
    scoped = api_user.get("scoped_view_ids") or []

    if _key_scope_is_global(scoped):
        return  # explicit, deliberately-granted master key

    # Normalise entries to ints defensively (JSON-text columns / hand-edited
    # rows have been observed with stringified ids elsewhere in this API).
    _scoped_ids = set()
    for s in scoped:
        try:
            _scoped_ids.add(int(s))
        except (TypeError, ValueError):
            continue

    if int(view_id) in _scoped_ids:
        return

    if not _scoped_ids:
        # Empty scope.  Legacy behaviour (allow everything) only survives via
        # the explicit config opt-in — and even then we log every use loudly
        # so the operator can find and re-scope these keys.
        if _empty_scope_legacy_master_key():
            _scope_log.warning(
                "[api-key-scope-LEGACY-MASTER] key_id=%s name=%s granted view_id=%s "
                "via published_views.empty_scope_master_key=true. This key has an "
                "EMPTY scope; re-create it with explicit view ids (or the explicit "
                "global marker) and turn the legacy flag off.",
                api_user.get("api_key_id", api_user.get("key_id", "?")),
                api_user.get("key_name") or api_user.get("name", "?"),
                view_id,
            )
            return
        _scope_log.warning(
            "[api-key-scope-deny] key_id=%s name=%s view_id=%s scoped_to=EMPTY — "
            "empty scope now means NO views (was: every view). Re-issue the key "
            "with explicit scoped_view_ids, or as an explicit global key.",
            api_user.get("api_key_id", api_user.get("key_id", "?")),
            api_user.get("key_name") or api_user.get("name", "?"),
            view_id,
        )
        raise HTTPException(403, "API key does not have access to this view")

    # BF-405 — log scope mismatch so admins can debug why a valid
    # API key returns 403.  key_id (NOT the key itself) + view_id +
    # the scoped-view-id list are all safe to log (key metadata,
    # not credentials).
    _scope_log.warning(
        "[api-key-scope-deny] key_id=%s name=%s view_id=%d scoped_to=%s",
        api_user.get("api_key_id", api_user.get("key_id", "?")),
        api_user.get("key_name") or api_user.get("name", "?"),
        view_id,
        sorted(_scoped_ids)[:50],
    )
    raise HTTPException(403, "API key does not have access to this view")


def _check_view_access(pv: dict, auth_user: dict) -> None:
    """
    Phase 82 — Unified access control check for external endpoints.

    Rules:
      - auth_method == "api_key"    : check scoped_view_ids (existing Phase 75 logic)
      - auth_method == "ad_basic"   : check allowed_ad_groups on the view
          * empty/null allowed_ad_groups → all authenticated AD users may access
          * non-empty allowed_ad_groups  → user must be in at least one group
      - auth_method == "session"    : SAME rule as ad_basic (2026-08-23, P6 D8) —
          a session is the same identity class resolved through core.sessions
          instead of a fresh AD bind; its groups came from login.
      - auth_method == "basic_noauth": allow all (dev/test mode — auth is disabled globally)
    """
    method = auth_user.get("auth_method", "api_key")

    if method == "api_key":
        # Existing API key scope check
        _check_key_scope(auth_user, pv["id"])
        return

    if method == "basic_noauth":
        # 2026-08-17 (P7) — a ``basic_noauth`` principal is minted by
        # api/deps.py::get_api_key_or_ad_user for ANY HTTP Basic credentials
        # when ``auth.type == "none"``.  It is NOT an authenticated identity —
        # the username is caller-chosen and unverified.  Trusting the label
        # alone would let a forged/stale principal (or a deps regression)
        # bypass every view ACL, so RE-VERIFY here that auth is genuinely,
        # deliberately disabled before allowing: config must have loaded AND
        # explicitly selected type='none'.  Anything else — auth enabled,
        # config failed to load, config unreadable — is a DENY
        # (UNKNOWN = UNSAFE).
        _noauth_ok = False
        try:
            from core.config import auth as _auth_cfg_check
            _noauth_ok = (getattr(_auth_cfg_check, "type", None) == "none")
            if _noauth_ok:
                try:
                    from core.config import config_load_failed as _cfg_failed
                    if _cfg_failed():
                        _noauth_ok = False
                except ImportError:
                    pass  # older config builds without the probe — type check stands
        except Exception:
            _noauth_ok = False
        if _noauth_ok:
            # Auth is genuinely disabled (dev/test mode) — allow everything.
            return
        import logging as _logging
        _logging.getLogger("auth.pv_acl").warning(
            "[pv-acl-deny] basic_noauth principal presented while auth is NOT "
            "disabled (user=%s view=%s) — refusing. This principal is only "
            "valid when auth.type='none' genuinely loaded.",
            auth_user.get("name") or auth_user.get("username", "?"),
            pv.get("slug", "?"),
        )
        raise HTTPException(403, "Access denied")

    if method in ("ad_basic", "session"):
        # "session" (P6 D8, 2026-08-23) rides the IDENTICAL group rule — one
        # resolution of "may this human open this view", two credential kinds.
        allowed_groups = pv.get("allowed_ad_groups") or []
        if not allowed_groups:
            # View is open to all authenticated AD users
            return
        user_groups_raw = auth_user.get("ad_groups") or auth_user.get("groups") or []
        # BF-415 — Phase 83H originally used the string sentinel "__ALL__"
        # inside the groups list to mean "AD lookup failed but admin chose
        # fail_mode=allow, let the user through".  That sentinel collided
        # with real AD groups named "__ALL__" (e.g. corp test/admin prefixes),
        # giving such users master-key access.  Now driven by an
        # out-of-band flag set in api/deps.py — see ``_ad_fetch_failed_open``.
        # Reading the legacy literal here remains as a defence so an
        # in-flight upgrade where deps.py is patched but cache holds the
        # old shape doesn't immediately deny everything; logged loudly so
        # operators notice and rotate.
        if auth_user.get("_ad_fetch_failed_open") is True:
            return
        if "__ALL__" in user_groups_raw:
            import logging as _legacy_log
            _legacy_log.getLogger("auth.pv_acl").warning(
                "[pv-acl] legacy __ALL__ sentinel observed for user=%s — "
                "ignored; rely on _ad_fetch_failed_open instead",
                auth_user.get("name") or auth_user.get("username", "?"),
            )
            # Fall through to the real group intersection check.
        # Case-insensitive comparison
        user_groups_lower = {g.lower() for g in user_groups_raw}
        allowed_lower = {g.lower() for g in allowed_groups}
        if not user_groups_lower.intersection(allowed_lower):
            # BF-405 — log WHICH groups the user has vs which were required.
            # Group names are NOT secrets (they're public AD policy); the
            # 403-without-context behaviour was the actual debug blocker.
            import logging as _logging
            _logging.getLogger("auth.pv_acl").warning(
                "[pv-acl-deny] user=%s view=%s user_groups=%s allowed_groups=%s",
                auth_user.get("name") or auth_user.get("username", "?"),
                pv.get("slug", "?"),
                sorted(user_groups_lower)[:20],
                sorted(allowed_lower)[:20],
            )
            raise HTTPException(
                403,
                "Your AD account does not have access to this published view",
            )
        return

    # Unknown auth method — deny by default
    import logging as _logging
    _logging.getLogger("auth.pv_acl").warning(
        "[pv-acl-deny] unknown auth_method=%s for user=%s view=%s",
        method, auth_user.get("name", "?"), pv.get("slug", "?"),
    )
    raise HTTPException(403, "Access denied")


# ── Filter / parameter parsing ───────────────────────────────────────────────

# ── Filter query-key recognition ─────────────────────────────────────────────
# Accept BOTH forms so consumers don't have to URL-encode square brackets
# (RFC 3986 reserves ``[`` / ``]`` for IPv6 literals; many HTTP clients —
# curl in strict mode, fetch in some browsers — reject unencoded brackets
# with "bad range in url" / "bad hostname" errors).
#
#   ?filter[region]=eq:APAC   ← back-compat, bracketed form
#   ?filter.region=eq:APAC    ← dot notation, RFC-safe, preferred for new
#                               consumers
_FILTER_KEY_BRACKET_RE = re.compile(r"^filter\[(\w+)\]$")
_FILTER_KEY_DOT_RE     = re.compile(r"^filter\.(\w+)$")


def _filter_column_from_key(key: str) -> Optional[str]:
    """Return the column name if ``key`` is a recognised filter query
    parameter key (bracketed OR dot form), else ``None``."""
    m = _FILTER_KEY_BRACKET_RE.match(key)
    if m:
        return m.group(1)
    m = _FILTER_KEY_DOT_RE.match(key)
    if m:
        return m.group(1)
    return None


# Bare-form filter recognition:
#   ?col=value               → eq filter
#   ?col=('A','B','C')       → IN filter (tuple syntax — natural for SQL users)
#   ?col=A,B,C               → IN filter (comma-separated, no parens)
# The tuple-paren form is detected by a leading ``(`` and trailing ``)``;
# values between them are split on commas and stripped of surrounding
# whitespace and single/double quotes so ``code=('A','B')`` and
# ``code=(A,B)`` both work.
_TUPLE_RE = re.compile(r"^\s*\((.*)\)\s*$", re.DOTALL)


def _split_quoted_list(s: str) -> List[str]:
    """Split a comma-separated list, stripping surrounding quotes off
    each element.  ``'A','B', "C"`` → ``["A","B","C"]``.

    Phase 132.36 hotfix-1: quote-aware tokenizer — commas inside a
    single- or double-quoted segment do NOT split.  Example:
    ``'A,B','C'`` → ``["A,B","C"]`` instead of the broken
    ``["'A","B'","'C'"]`` produced by the previous naive ``str.split``.
    """
    out: List[str] = []
    buf: List[str] = []
    quote: Optional[str] = None   # currently-open quote char, or None
    for ch in s:
        if quote is None:
            if ch == "," and not buf:
                continue          # leading / consecutive commas → skip
            if ch == ",":
                v = "".join(buf).strip()
                if len(v) >= 2 and v[0] in ("'", '"') and v[-1] == v[0]:
                    v = v[1:-1]
                if v != "":
                    out.append(v)
                buf = []
                continue
            if ch in ("'", '"'):
                quote = ch
                buf.append(ch)
                continue
            buf.append(ch)
        else:
            buf.append(ch)
            if ch == quote:
                quote = None
    # Last segment
    v = "".join(buf).strip()
    if len(v) >= 2 and v[0] in ("'", '"') and v[-1] == v[0]:
        v = v[1:-1]
    if v != "":
        out.append(v)
    return out


# Phase 132.38 — the per-row Static/Dynamic merge primitive has been
# lifted to ``core.where_clause_mapping`` so Feed Generation configs,
# Feed Run triggers, and DataFlow stages share the same implementation.
# These re-exports preserve every existing import path that consumers
# (handlers + tests) used before the extraction.
from core.where_clause_mapping import (  # noqa: E402
    _col_key,
    merge_static_and_consumer_filters,
)


def _parse_filters(
    request: Request, allowed: List[str],
    *, param_names: Optional[List[str]] = None,
    dynamic_where_cols: Optional[Iterable[str]] = None,
) -> List[Dict[str, Any]]:
    """Parse filter query params.

    Three syntaxes supported, semantically equivalent for the
    overlapping cases:

        ?filter[col]=op:val      (back-compat — original Phase 80 form)
        ?filter.col=op:val       (RFC-safe dot notation — preferred)
        ?col=val                 (BARE FORM — Phase 132.35)
        ?col=('A','B')           (BARE TUPLE — Phase 132.35, IN clause)
        ?col=A,B,C               (BARE LIST — Phase 132.35, IN clause)

    The bare form requires the column to be in ``pv.allowed_filters``
    AND not in the framework-reserved-name list (``limit``, ``offset``,
    ``sort``, ``columns``, ``format``, ``cache``, ``snapshot_id``,
    ``as_of_timestamp``, ``engine``, ``filter``) AND not a declared
    runtime parameter name (those go to ``_parse_params``).  We only
    add a bare-form filter when ``allowed`` lists the column — there
    is no implicit "all columns are filterable" mode.

    Operators (explicit forms ``filter[col]=op:val``): ``eq``, ``ne``,
    ``gt``, ``gte``, ``lt``, ``lte``, ``in``, ``not_in``, ``contains``,
    ``between``.  Bare form infers the operator from value shape:
    tuple/list → ``in``; everything else → ``eq``.
    """
    filters: List[Dict[str, Any]] = []
    valid_ops = {"eq", "ne", "gt", "gte", "lt", "lte", "in", "not_in",
                  "contains", "between"}

    # Bare-form binding needs to know which keys are declared parameters
    # — those go through _parse_params, not here.
    pv_param_names: set = set(param_names or [])
    # Dynamic _where_clauses_mapping columns — filter-binding WINS over the
    # declared-param cede for these.  BF-491 auto-registers every Dynamic row
    # as a param_definitions entry (docs / typing / ""-default), so without
    # this exception the bare ?col=value form is swallowed by _parse_params,
    # where a mapping column has no {{name}} placeholder to substitute into.
    # Normalised via _col_key so a qualified / mixed-case publisher spelling
    # still matches the bare URL key.
    _dyn_where_keys: set = {
        _col_key(c) for c in (dynamic_where_cols or ()) if c
    }
    # Normalised allowed-filter set (2026-07-22 audit F1): the publisher's
    # allowed_filters may store a QUALIFIED / mixed-case spelling
    # (``trades.business_close_date``) while the consumer sends the bare leaf
    # key (``business_close_date``).  An exact-string membership test dropped
    # the filter silently — the exact bug the bare-form fix set out to close,
    # surviving for qualified columns.  Match on _col_key so qualified /
    # cased / quoted spellings are equivalent (same normaliser the merge uses).
    _allowed_norm: set = {_col_key(a) for a in (allowed or ()) if a}

    # Phase 132.36 hotfix-1: use ``multi_items()`` so ``?col=A&col=B`` is
    # not silently truncated to the first value.  Starlette's plain
    # ``items()`` returns only the first occurrence of each key.  When
    # the same key appears multiple times we treat them as an IN list
    # (matches the bare-CSV semantics ``?col=A,B``).
    #
    # Test mocks may pass a plain dict for ``query_params``; fall back
    # to ``.items()`` so existing tests don't need to change their
    # double-fixtures to model Starlette's MultiDict.
    qp = request.query_params
    if hasattr(qp, "multi_items"):
        pairs = list(qp.multi_items())
    else:
        pairs = list(qp.items())
    # Pre-aggregate values per key so we know whether a key recurs.
    from collections import defaultdict as _dd
    by_key: Dict[str, List[str]] = _dd(list)
    for k, v in pairs:
        by_key[k].append(v)

    for key, vals in by_key.items():
        # Multi-value detection for bare form — `?col=A&col=B` becomes
        # an IN filter via the single-key recurrence path below.  For
        # the explicit ``filter.col=op:val`` form, multi-value would
        # be a publisher misuse — we honour the LAST occurrence (most
        # specific) but log; consumers using the explicit form should
        # use ``in:A,B`` instead.
        val = vals[-1] if vals else ""
        is_multi_bare = len(vals) > 1
        # ── 1. filter.col / filter[col] explicit form ─────────────────
        col = _filter_column_from_key(key)
        if col is not None:
            if _allowed_norm and _col_key(col) not in _allowed_norm:
                raise HTTPException(
                    400,
                    f"Filter on column '{col}' not allowed. Allowed: {', '.join(allowed)}"
                )
            # Parse operator:value
            if ":" in val:
                op, v = val.split(":", 1)
            else:
                op, v = "eq", val

            op = op.lower()
            if op not in valid_ops:
                raise HTTPException(
                    400,
                    f"Invalid filter operator '{op}'. "
                    f"Valid: {', '.join(sorted(valid_ops))}",
                )

            # Parse value based on operator
            if op in ("in", "not_in"):
                parsed_val = [x.strip() for x in v.split(",")]
            elif op == "between":
                parts = v.split(",", 1)
                if len(parts) != 2:
                    raise HTTPException(
                        400, "between filter requires two comma-separated values"
                    )
                parsed_val = [parts[0].strip(), parts[1].strip()]
            else:
                parsed_val = v

            filters.append({"column": col, "operator": op, "value": parsed_val})
            continue

        # ── 2. Bare-form filter (?col=val) — Phase 132.35 ────────────
        # Skip framework-reserved names + declared parameter names.
        if key in _RESERVED_QUERY_NAMES or key == "filter":
            continue
        # Bracketed runtime-parameter form ``?param[name]=value`` — owned by
        # ``_parse_params`` (which 400s on undeclared names itself).
        if _PARAM_RE.match(key):
            continue
        # Declared params cede to _parse_params — EXCEPT dynamic WHERE-mapping
        # columns, where filter-binding wins (BF-491 also registered them as
        # params, but a mapping column has no {{name}} placeholder, so ceding
        # would silently drop the bare ?col=value filter).
        if key in pv_param_names and _col_key(key) not in _dyn_where_keys:
            continue
        # Bare form only fires when the column is explicitly in
        # ``allowed_filters`` — no implicit "all columns filterable" mode.
        # Normalised match (F1) so a qualified/cased publisher spelling in
        # allowed_filters still admits the bare ?col=value URL key.
        #
        # 2026-08 redesign — REJECT, never ignore.  A bare key that is not a
        # reserved framework param, not a declared runtime parameter, and not
        # an allowed filter used to be SILENTLY DROPPED — the consumer's
        # ``?region=EMEA`` on a view without ``region`` in allowed_filters
        # returned the FULL unfiltered dataset as 200 (silent over-delivery),
        # while the explicit ``filter.region=...`` spelling of the SAME
        # request correctly 400'd.  One request, one behaviour: unknown keys
        # are rejected with an actionable message.  (The old silent-drop
        # default IS the defect — this is the deliberate contract change.)
        if not _allowed_norm or _col_key(key) not in _allowed_norm:
            _declared = sorted(pv_param_names)
            raise HTTPException(
                400,
                f"Unknown query parameter '{key}'. It is not an allowed filter "
                f"column (allowed: {', '.join(sorted(allowed)) or 'none'}) and not a "
                f"declared runtime parameter (declared: {', '.join(_declared) or 'none'}). "
                f"Filters use ?filter.<column>=op:value or bare ?<column>=value for "
                f"allowed columns.",
            )

        # Multi-value bare form: ?col=A&col=B  → IN (Phase 132.36 hotfix)
        if is_multi_bare:
            items = [v.strip() for v in vals if v.strip() != ""]
            if items:
                filters.append({"column": key, "operator": "in", "value": items})
            continue

        # Tuple form: ?col=('A','B') → IN
        m = _TUPLE_RE.match(val)
        if m is not None:
            items = _split_quoted_list(m.group(1))
            if not items:
                raise HTTPException(
                    400, f"Empty IN list for filter '{key}'"
                )
            filters.append({"column": key, "operator": "in", "value": items})
            continue

        # Comma-separated list without parens: ?col=A,B → IN (only when
        # the value actually contains a comma — otherwise it's a scalar
        # that happens to have a tail-call value).
        if "," in val:
            items = [x.strip() for x in val.split(",") if x.strip() != ""]
            if len(items) >= 2:
                filters.append({"column": key, "operator": "in", "value": items})
                continue

        # Default: scalar eq
        filters.append({"column": key, "operator": "eq", "value": val})

    return filters


# ── Phase 80: Runtime parameter helpers ──────────────────────────────────────

# Bracketed form — kept for back-compat with existing consumers that
# already URL-encode the brackets or use HTTP clients that accept them.
_PARAM_RE = re.compile(r"^param\[(\w+)\]$")

# Framework-reserved query-parameter names that the FastAPI endpoint
# binds in its own signature.  These are consumed by the route handler
# BEFORE the bare-name parser sees them, so a published view that
# declares a parameter with one of these names MUST use the bracketed
# form ``?param[<name>]=value`` to disambiguate.  Error message in
# ``_parse_params`` points the user at this.
_RESERVED_QUERY_NAMES = frozenset({
    # Pagination + projection
    "limit", "offset", "sort", "columns",
    # Output / cache control
    "format", "cache",
    # Time travel
    "snapshot_id", "as_of_timestamp",
    # Phase 146-A — engine override
    "engine",
    # 2026-08-08 — BULK STREAMING params.  Added on the same day the /bulk
    # routes shipped, because omitting them made the resume feature DEAD ON
    # THE WIRE: the API hands the consumer an X-QS-Next-Cursor token, and the
    # very next request carrying ?cursor= was rejected by this parser with
    # "Unknown query parameter 'cursor'" — a 400 blaming the caller for a
    # value the API itself issued.  It fired for EVERY view, since the
    # `not _allowed_norm` disjunct below rejects unknown bare keys even when a
    # view declares no filters at all.
    #
    # Not caught by the bulk tests because they invoke the endpoint function
    # directly with an empty query_params mapping, so nothing exercised this
    # parser.  Any framework-level param MUST be listed here.
    "cursor", "max_rows", "batch_rows",
    # FB-37 (2026-09-19) -- the SAME defect, in the same place, a second
    # time: three parameters added to ext_bulk_stream AFTER the line above
    # was written (``received`` -- the resume correction; ``dataset_version``
    # -- the offset-resume pin; ``allow_partial``) were rejected by this
    # parser with "Unknown query parameter", so the resume path on the lane
    # with no human in it silently lost rows.  The instruction in the
    # comment above was doing the job a guard should do.  It is a guard now:
    # tests/test_published_views_bulk_query_params.py walks every
    # /api/v1/views/ route that reaches _parse_params and fails when a
    # Query() parameter is not listed here.  Add the name HERE, the test
    # tells you when.
    "received", "dataset_version", "allow_partial",
})
# {{name}} placeholder regex used by _substitute_params below.
# A second copy with different semantics lives in queries_api.py
# (_PARAM_TEMPLATE_RE) — that one raises on missing parameters and does not
# escape values.  Keep the two implementations aligned on syntax even though
# their semantics differ; if you change the placeholder syntax here, change it
# there too.
_TEMPLATE_RE = re.compile(r"\{\{(\w+)\}\}")

# Single source of truth for which query_config fields contain raw SQL and
# therefore need parameter values SQL-escaped before substitution.  Adding a
# new SQL-bearing field to query_config means adding it here too — otherwise
# parameters substituted into that field will NOT be escaped, which is a
# SQL-injection risk.  Filters are intentionally NOT in this list because
# they are bound as parameters by the engine downstream, not interpolated
# into SQL strings.
# BF-415 — ``secondary_raw_sql`` was missing from this list, so {{params}}
# substituted into the cross-source secondary side were NOT SQL-escaped.
# A consumer with parameter access could close the literal and append
# arbitrary DuckDB SQL on the secondary execution.
_QC_SQL_FIELDS: tuple[str, ...] = ("custom_sql", "raw_sql", "secondary_raw_sql")


def _parse_params(request: Request, param_defs: List[dict]) -> Dict[str, Any]:
    """Parse runtime parameter query strings.  Two equivalent syntaxes:

        ?<name>=value             (bare — preferred; RFC-safe, no
                                   URL-encoding needed)
        ?param[<name>]=value      (bracketed — back-compat with the
                                   original Phase 80 contract)

    The bare form is preferred because square brackets are reserved
    per RFC 3986 and many HTTP clients reject them unencoded (curl
    strict mode, some browsers, the JS ``URL`` constructor).  Both
    forms are accepted concurrently so existing consumers don't break.

    Reserved-name conflicts: when a published view declares a
    parameter with the same name as a framework query param (e.g.
    ``limit``, ``format``, ``cache`` — see ``_RESERVED_QUERY_NAMES``),
    the consumer MUST use the bracketed form for that parameter; the
    bare form is consumed by the FastAPI route signature before this
    parser sees it.  Error message points the user at the bracketed
    fallback.
    """
    def_map = {p["name"]: p for p in (param_defs or [])}
    _defaults = _default_params(param_defs)
    raw_params: Dict[str, str] = {}

    # Edge-case sweep 2026-09-24: ``?p_region=EUROPE&p_region=ASIA`` answered
    # with EUROPE only -- ``items()`` keeps ONE value per key, so the caller's
    # second value vanished without a word.  A parameter takes one value;
    # two is a question only the caller can answer.
    _qp = request.query_params
    if hasattr(_qp, "getlist"):
        for _name in def_map:
            for _k in (_name, f"param[{_name}]"):
                if len(_qp.getlist(_k)) > 1:
                    raise HTTPException(
                        400, f"Parameter '{_name}' was given "
                             f"{len(_qp.getlist(_k))} times; a parameter takes "
                             f"one value.")

    for key, val in request.query_params.items():
        # 1. Bracketed form ``?param[name]=value`` — explicit, unambiguous.
        m = _PARAM_RE.match(key)
        if m:
            pname = m.group(1)
            if pname not in def_map:
                raise HTTPException(
                    400,
                    f"Unknown parameter '{pname}'. Declared: {list(def_map.keys())}",
                )
            raw_params[pname] = val
            continue
        # 2. Filter query keys — handled by ``_parse_filters``, skip here so
        #    the bare-name path below doesn't misclassify them.
        if _filter_column_from_key(key) is not None:
            continue
        # 3. Framework-reserved names — consumed by the FastAPI endpoint
        #    signature itself.  Never treat these as user params.
        if key in _RESERVED_QUERY_NAMES:
            continue
        # 4. Bare form ``?<name>=value`` — RFC-safe, preferred for new
        #    consumers.  Silently ignore unknown keys here (forward-compat
        #    with future framework params); the bracketed form's explicit
        #    error covers typo'd param names.
        if key in def_map:
            raw_params[key] = val

    result: Dict[str, Any] = {}
    for pname, pdef in def_map.items():
        if pname in raw_params:
            raw = raw_params[pname]
            ptype = pdef.get("type", "string")
            try:
                if ptype == "integer":
                    result[pname] = int(raw)
                elif ptype == "float":
                    result[pname] = float(raw)
                elif ptype == "boolean":
                    result[pname] = raw.lower() in ("1", "true", "yes")
                elif ptype == "date":
                    from datetime import date as _date
                    _date.fromisoformat(raw)
                    result[pname] = raw
                else:
                    result[pname] = raw
            except (ValueError, TypeError):
                raise HTTPException(400, f"Parameter '{pname}' has invalid value for type '{ptype}'")
        elif pdef.get("required"):
            # Point users at the RFC-safe bare form, with the bracketed
            # fallback for reserved-name collisions.
            if pname in _RESERVED_QUERY_NAMES:
                hint = f"?param[{pname}]=value (this name conflicts with a framework query parameter; the bracketed form is required)"
            else:
                hint = f"?{pname}=value (or the back-compat ?param[{pname}]=value)"
            raise HTTPException(
                422,
                f"Required parameter '{pname}' is missing. Pass it as {hint}",
            )
        elif pname in _defaults:
            result[pname] = _defaults[pname]

    return result


def _default_params(param_defs: Optional[List[dict]]) -> Dict[str, Any]:
    """Default values for declared runtime parameters.

    SINGLE chokepoint shared by ``_parse_params`` (consumer requests) and the
    warmup loop.  Before this existed, warmup executed views with
    ``params=None`` while the endpoint filled declared defaults — the two
    computed DIFFERENT cache keys, so the warmup result could never be the
    entry a consumer's request looked up (one of the ways the warmup loop was
    inert by construction).
    """
    out: Dict[str, Any] = {}
    for p in (param_defs or []):
        if isinstance(p, dict) and p.get("name") and p.get("default") is not None:
            out[p["name"]] = p["default"]
    return out


# Phase 133-C: Safe-param allowlist — blocks SQL metacharacters in string params.
# Allows: word chars, space, tab, . / : @ , - (hyphen for regions/UUIDs/dates)
# Intentionally excludes: ; ' " \n \r to prevent SQL injection and multiline payloads.
# Double-dash (--) and block comments (/* */) caught by _SQL_COMMENT_RE below.
_SAFE_PARAM_RE = re.compile(r'^[\w \t./:@,\-]+$')
# Phase 133-D: Blocklist for SQL comment sequences — catches -- at end or before space
_SQL_COMMENT_RE = re.compile(r'--\s|--$|/\*|\*/')


def _validate_param_types(params: Dict[str, Any], param_defs: List[dict]) -> Dict[str, Any]:
    """Phase 133-C: Validate and cast param values against declared types.

    Raises HTTPException(400) if a value doesn't match the declared type.
    Returns params with correctly-typed values.
    """
    if not param_defs:
        return params

    def_map = {p["name"]: p for p in param_defs}
    validated: Dict[str, Any] = {}

    for name, value in params.items():
        pdef = def_map.get(name)
        if not pdef:
            validated[name] = value
            continue

        ptype = pdef.get("type", "string")
        str_val = str(value)

        try:
            if ptype == "integer":
                validated[name] = int(str_val)
            elif ptype == "float":
                validated[name] = float(str_val)
            elif ptype == "boolean":
                validated[name] = str_val.lower() in ("1", "true", "yes")
            elif ptype == "date":
                from datetime import date as _date
                _date.fromisoformat(str_val)
                validated[name] = str_val
            else:
                # String type: validate against safe-param allowlist + comment blocklist
                if str_val.strip() == "":
                    # Edge-case sweep 2026-09-24: an empty value was refused
                    # as "disallowed characters" -- the right refusal, the
                    # wrong reason.
                    raise HTTPException(
                        400, f"Parameter '{name}' is empty; pass a value "
                             f"(?{name}=value).")
                if not _SAFE_PARAM_RE.match(str_val) or _SQL_COMMENT_RE.search(str_val):
                    raise HTTPException(
                        400,
                        f"Parameter '{name}' contains disallowed characters. "
                        "Only letters, digits, spaces, and basic punctuation allowed.",
                    )
                validated[name] = str_val
        except HTTPException:
            raise
        except (ValueError, TypeError):
            raise HTTPException(
                400,
                f"Parameter '{name}' has invalid value '{str_val}' for type '{ptype}'",
            )

    return validated


def _substitute_params(
    query_config: dict,
    params: Dict[str, Any],
    param_defs: Optional[List[dict]] = None,
) -> dict:
    """Replace {{param_name}} placeholders in filter values and raw_sql fields.

    Phase 133-C: Validates param types against declarations before substitution.
    Values are SQL-escaped (single quotes doubled) to prevent injection.
    Only declared param names are substituted.

    CONTRACT: when ``param_defs`` is provided, this function calls
    ``_validate_param_types`` internally and will raise HTTPException(400) on
    invalid input.  Callers (e.g. the GraphQL bridge, business reports path)
    that already validate explicitly will pay the validation cost twice — that
    is intentional defense-in-depth and is asserted by
    test_published_views_enterprise.TestSubstituteParamsWithDefs.

    The set of query_config fields that get SQL-escaped is declared at module
    scope as ``_QC_SQL_FIELDS`` — add new SQL-bearing fields there.
    """
    if not params:
        return query_config

    # Phase 133-C: Validate param types before substitution
    if param_defs:
        params = _validate_param_types(params, param_defs)

    cfg = copy.deepcopy(query_config)

    def _sql_escape(val: str) -> str:
        """Escape single quotes for safe SQL interpolation."""
        return val.replace("'", "''")

    def _sub(s: str, escape: bool = False) -> str:
        def _replace(m):
            key = m.group(1)
            if key not in params:
                return m.group(0)
            v = str(params[key])
            return _sql_escape(v) if escape else v
        return _TEMPLATE_RE.sub(_replace, s)

    # Filter values: NOT escaped because the engine parameterizes these
    # via QueryConfigModel → _build_where (parameterized bind variables)
    for f in cfg.get("filters") or []:
        if isinstance(f.get("value"), str):
            f["value"] = _sub(f["value"])
        elif isinstance(f.get("value"), list):
            f["value"] = [_sub(v) if isinstance(v, str) else v for v in f["value"]]

    # SQL fields: escape values to prevent injection.
    # Source of truth for which fields are SQL-bearing is _QC_SQL_FIELDS (top
    # of file) — add new SQL fields there so escaping can't be silently missed.
    for key in _QC_SQL_FIELDS:
        if isinstance(cfg.get(key), str):
            cfg[key] = _sub(cfg[key], escape=True)

    return cfg


# ── Cache key / result helpers ───────────────────────────────────────────────

#: Marker used when the backing report's publish state could NOT be read.
#: A CONSTANT, deliberately: it is a distinct cache slot (so a stale entry
#: keyed on a resolved identity can never be served through it), but it is
#: not a nonce -- a nonce would turn a database hiccup into one fresh
#: execution per request, i.e. a stampede on exactly the surface that is
#: already unwell.  Unknown is not empty and it is not "published": it is
#: its own slot.
REPORT_VERSION_UNRESOLVED = "unresolved"


def _report_version_scope(pv: dict, db) -> Optional[str]:
    """The PUBLISH-LIFECYCLE identity of the view's backing business report.

    Returns ``None`` for every view that is not business-report backed --
    the dispatcher (``_SOURCE_HANDLERS``) sends only ``source_type ==
    "business_report"`` to the handler that consults the lifecycle, so only
    those views have a lifecycle to mix in, and every other view keeps its
    legacy cache key byte-identical.

    WHY THIS IS A CACHE-KEY INGREDIENT AND NOT A SECOND GATE.  The
    ``/data`` (and bulk) cache branches serve a materialised dataset and
    RETURN BEFORE ``_execute_view`` is entered, so
    ``_resolve_execution_report(..., consumer=True)`` -- the shared
    chokepoint that raises 410 for an ARCHIVED report and swaps the draft
    for the CURRENT PUBLISHED VERSION -- was simply not reached on a cache
    HIT.  Both guarantees held only on a MISS, for the full cache TTL
    (default 8h).  Consulting the lifecycle next to each cache read would
    fix the two sites that exist today and be forgotten by the third; an
    IDENTITY ingredient cannot be forgotten, because a slot that does not
    exist yet is a miss and a miss runs the gate.  Both effects fall out:

    * ARCHIVE  -> ``status`` changes -> different slot -> miss -> the
      handler runs -> ``ReportArchivedError`` -> **410**.
    * REPUBLISH -> a new version row -> different slot -> miss -> the
      handler runs -> the NEW published definition is materialised.
    * UNPUBLISH -> ``is_published`` flips -> different slot -> miss -> the
      handler runs -> ``ReportUnpublishedError`` -> **410** (2026-09-15;
      the resolver used to materialise the draft here).

    DELIBERATELY NOT COVERED: editing the DRAFT of a report that has no
    published version.  ``business_reports`` carries no ``updated_at``
    column, so there is nothing cheap to key on, and the resolver serves
    that draft either way -- the staleness window is the cache TTL, exactly
    as it was before the publish lifecycle existed.  Stated rather than
    implied: this closes the LIFECYCLE bypass, not draft freshness.

    Costs two primary-key reads.  Call it OFF the event loop (``adb``).
    """
    if not isinstance(pv, dict):
        return None
    if (pv.get("source_type") or "saved_query") != "business_report":
        return None
    br_id = pv.get("business_report_id")
    if not br_id:
        # The handler itself 500s on this; there is no lifecycle to read.
        return None
    if db is None:
        return REPORT_VERSION_UNRESOLVED
    try:
        report = db.get_business_report(int(br_id))
    except Exception as exc:
        logger.warning("[pv-cache-key] business report %s lifecycle lookup "
                       "failed (%s: %s) — using the '%s' slot so a cache "
                       "entry keyed on a KNOWN lifecycle can never be served "
                       "through it", br_id, type(exc).__name__, exc,
                       REPORT_VERSION_UNRESOLVED)
        return REPORT_VERSION_UNRESOLVED
    if not report:
        # The handler answers 404.  Its own slot, so a dataset cached while
        # the report existed is not served after it was deleted.
        return "missing"
    try:
        from core.reports.versions import effective_lifecycle_status
        status = effective_lifecycle_status(report)
    except Exception as exc:
        logger.warning("[pv-cache-key] lifecycle status for report %s could "
                       "not be derived (%s: %s)", br_id, type(exc).__name__, exc)
        return REPORT_VERSION_UNRESOLVED
    if not report.get("is_published"):
        # The handler REFUSES here (410, 2026-09-15) — there is no version
        # identity to key on; the slot exists so a dataset cached while the
        # report was published is never served after it was withdrawn.
        return f"{status}/draft"
    try:
        current = db.get_current_business_report_version(int(br_id))
    except Exception as exc:
        logger.warning("[pv-cache-key] version lookup failed for report %s "
                       "(%s: %s)", br_id, type(exc).__name__, exc)
        return f"{status}/{REPORT_VERSION_UNRESOLVED}"
    if not current:
        # Published with no version row (pre-backfill): the handler REFUSES
        # a token/API-key caller (410, 2026-09-15); its own slot regardless.
        return f"{status}/draft"
    return f"{status}/v{current.get('version_no')}#{current.get('id')}"


def _build_cache_key(view_id, filters, sort_col, sort_dir, columns, limit, offset,
                     params=None, snapshot_id=None, as_of_timestamp_ms=None,
                     engine_connection_id=None, user_scope=None,
                     report_version=None) -> str:
    """Build a deterministic DATASET cache key.

    2026-08 redesign — the key identifies the DATASET (which rows exist):
    view + filters + params + snapshot + engine + user-scope.  Presentation
    parameters (sort / columns / limit / offset) are deliberately EXCLUDED:
    they are pure reads over the materialized dataset, applied by
    ``envelope.read_page`` at response time.  Under the old per-page keying,
    every page/sort/projection combination was a separate execution AND a
    separate cache slot — which is exactly why pages could overlap or miss
    rows (each page re-ran a nondeterministically-ordered query) and why the
    warmup loop could never pre-fill what a consumer would look up.  The
    ``sort_col/sort_dir/columns/limit/offset`` parameters remain in the
    signature so the 6 existing call sites don't churn, but they no longer
    contribute to the key.  ETags mix the page spec back in separately at the
    endpoint (a page is a distinct HTTP representation of the same dataset).

    Phase 139 honest-fix: include time-travel params so cached time-travel
    results don't mix with live snapshot results. Both default None so the
    key is stable for callers that don't use time travel.

    Phase 146-A: include the engine_connection_id when the consumer pinned
    a specific engine via ?engine=X.  Different engines may return different
    rows for the same SQL (catalog/schema scope, row-level security, etc.),
    so they MUST get distinct cache slots.  When omitted/None, the key is
    identical to the legacy form so existing cache entries stay valid.

    BF-415 ``user_scope``: opaque string mixed into the key when row
    security rewrites the SQL per user.  Without it, user A's
    RLS-restricted result was being served to user B from cache.  Pass
    ``None`` (the default) when the PV has no row-security policies — the
    legacy unscoped key is preserved so existing cache entries remain
    valid.  See published_views_api.py for the call site that derives
    the scope from the consumer's identity.

    2026-09-05 ``report_version``: the PUBLISH-LIFECYCLE identity of the
    backing business report (see :func:`_report_version_scope`).  Without
    it, the cache branch in ``published_views_api.ext_get_view_data``
    RETURNS BEFORE ``_execute_view`` runs, so the resolver that surface
    calls -- ``_resolve_execution_report(..., consumer=True)`` -- never
    executes: for a full cache TTL an ARCHIVED report kept serving 200s
    instead of 410, and a REPUBLISHED report kept serving the previous
    version.  Those two guarantees were true only ON A CACHE MISS.  The
    ingredient is the fix that cannot be forgotten at a future call site:
    the lifecycle verdict is part of dataset IDENTITY, so archiving or
    republishing lands on a different slot and the gate necessarily runs.
    ``None`` (the default, and what every non-business-report view
    resolves to) keeps the legacy key byte-identical.
    """
    payload = {
        "v": view_id,
        "f": sorted(filters, key=lambda x: x["column"]) if filters else [],
        "p": dict(sorted(params.items())) if params else None,
        "snap": snapshot_id,
        "asof": as_of_timestamp_ms,
        "eng": engine_connection_id,
    }
    # BF-415 follow-up — only mix ``user_scope`` into the key when the
    # caller actually scoped per user.  Unconditional inclusion (even as
    # None) changed the hash for every existing cached PV at upgrade
    # time, orphaning the on-disk parquet cache.  Now: legacy callers
    # (no user_scope) get the same key as before, RLS callers get a
    # distinct slot.
    if report_version is not None:
        # NOT nested under user_scope: a business-report view without RLS is
        # the COMMON case, and it is exactly the case the archived/republish
        # gate was being skipped on.
        payload["rv"] = report_version
    if user_scope is not None:
        payload["us"] = user_scope
        # Phase 131 deep-dive #13 — mix in the row-security policy version
        # so a policy edit auto-invalidates every cached PV result that
        # was generated under the prior policy set.  Only applied when
        # the caller already opted into per-user scoping (user_scope!=None);
        # otherwise the PV has no RLS and the version is irrelevant.
        try:
            from core.row_security import current_policy_version as _cpv
            payload["pv_rls"] = _cpv()
        except Exception:
            pass
        # 2026-09-26 (F0) -- the in-process version above is per pod; the
        # policy SET's content digest (or "unverified") is not, so an edit
        # taken on a sibling pod moves this slot within the resolver TTL.
        from core.row_security.cache_scope import policy_set_marker
        payload["pv_rls_set"] = policy_set_marker()
    raw = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


# ── Cache SLOT naming — the paged and bulk namespaces are DISJOINT ───────────
#
# F2 (2026-08-08).  ``_build_cache_key`` identifies a DATASET by
# (view, filters, params, snapshot, engine, user-scope) and deliberately
# ignores sort/columns/limit/offset — so the key a bulk request computes is
# byte-identical to the one ``/data`` computes for the same filters.  That is
# correct for identity but catastrophic as a STORAGE decision: bulk
# materializes with ``dataset_row_cap_override(0)`` (unbounded), while every
# reader of the ``/data`` slot assumes the file is bounded by
# ``published_views.dataset_row_cap`` (1M).  ``envelope.read_page``'s sort
# branch does ``pq.read_table(...)`` — a FULL materialization — so one bulk
# pull publishing a 50M-row file into the shared slot turns an unrelated
# interactive ``/data?sort=col`` into an OOM that takes the pod, and every
# other consumer on it, down.
#
# The fix is a separate SLOT, not a separate key: the identity stays the same
# (bulk and /data still describe the same dataset), but the bytes live in a
# different file.  Consequences that fall out for free:
#
#   * ``/data`` can only ever open a capped file — the OOM is impossible by
#     construction rather than by everyone remembering the invariant.
#   * the 5-minute warmup loop (which writes the /data slot with the 1M cap)
#     can no longer overwrite a bulk dataset, so bulk cursors stop being
#     invalidated every 5 minutes on exactly the views an operator marked hot.
#   * bulk reuses its OWN uncapped entry, so the "capped entry → re-execute"
#     guard in ``_materialize_bulk_dataset`` becomes a fail-closed backstop
#     instead of the normal path.
#
# The marker is embedded AFTER the ``v{id}_`` prefix so every existing sweeper
# keeps working unchanged: ``_clear_view_cache`` (``v{id}_*``), the scheduler
# safety-net and the LRU evictor (``v*.parquet``, view id parsed from the stem)
# all still match.  Only the evictor needs to KNOW about the marker, and only
# so it can apply a separate budget (F10).
PV_BULK_MARKER = "bulk_"


def pv_cache_path(cache_dir, view_id, cache_key: str, *, scope: str = None):
    """SINGLE chokepoint for a Published-Views cache file path.

    ``scope=None``   → the paged ``/data`` slot: ``v{id}_{key}.parquet``
                       (byte-identical to the legacy name, so existing cache
                       entries stay valid across the upgrade).
    ``scope="bulk"`` → the bulk slot: ``v{id}_bulk_{key}.parquet``.

    Returns ``None`` when ``cache_dir`` is falsy so call sites keep their
    existing ``if cached_path:`` guards.
    """
    if not cache_dir:
        return None
    from pathlib import Path as _P
    marker = PV_BULK_MARKER if scope == "bulk" else ""
    return _P(cache_dir) / f"v{view_id}_{marker}{cache_key}.parquet"


def pv_cache_is_bulk(path) -> bool:
    """True when ``path`` names a BULK dataset slot (see ``pv_cache_path``).

    Used by the LRU evictor to bill bulk datasets against their own budget:
    a single 20 GB bulk export must not be able to evict every paged entry in
    the cache and still leave the total over budget, which would drop every
    ``/data`` consumer to a permanent MISS.
    """
    from pathlib import Path as _P
    name = _P(str(path)).name
    if not name.startswith("v"):
        return False
    _, sep, rest = name.partition("_")
    return bool(sep) and rest.startswith(PV_BULK_MARKER)


# BF-415 — used by both the execute path and the warmup loop to decide
# whether a PV's result cache must be scoped per-consumer.  Returns either
# an opaque scope string (sorted groups + username hash) or None when no
# scoping is needed.
def _pv_sql_is_principal_varying(pv: dict, db=None) -> bool:
    """Does this published view's underlying SQL differ per consumer?

    2026-08-29.  ``${user.*}`` in a report's own SQL renders per caller even
    with row-security OFF -- which is exactly when ``_user_cache_scope``
    returns None and the cache is shared.  Same premise break as the report
    cache and the business-report instance signature; this is the third site
    that assumed "no policies => identical bytes for everyone".

    Inspects what it can see: the PV's own query_config SQL, and the backing
    business report or SQL file resolved through the db manager.  A view it
    fully inspects and finds no tokens in keeps the legacy shared cache, so
    this cannot silently de-share every view.  Anything it CANNOT resolve
    counts as varying -- a cache miss is survivable, a cross-consumer serve
    is not.

    ``db`` (2026-10-03): the manager to read the report through -- the
    serving routes pass ``core.reports.preloaded.served_db_for(pv, ...)``,
    which answers from the row read with the view.  Default: this module's
    manager, as before.
    """
    from core.reports.user_sql_vars import referenced_user_vars

    def _any(texts) -> bool:
        return any(referenced_user_vars(t or "") for t in texts)

    try:
        qc = pv.get("query_config") or {}
        if isinstance(qc, str):
            qc = json.loads(qc) or {}
        if _any([qc.get(f) for f in _QC_SQL_FIELDS]):
            return True
        if _any([pv.get("raw_sql_override"), pv.get("raw_sql")]):
            return True

        br_id = pv.get("business_report_id")
        file_id = pv.get("sql_file_id")
        if not br_id and not file_id:
            return False          # nothing else can carry author SQL

        if db is None:
            db = _resolve_db_manager()
        if db is None:
            return True           # cannot tell => do not share

        # Delegate to the ONE rule rather than re-listing a record's SQL
        # fields here.  The first version of this branch spelled the
        # BusinessReport fields by hand and got them wrong -- they are
        # ``raw_sql_override`` / ``raw_sql_saved_query_id`` /
        # ``raw_sql_file_id``, not ``raw_sql`` alone -- so a view backed by a
        # saved query or a file reported "safe" and kept sharing its cache.
        from core.reports.user_sql_vars import report_references_user_vars
        if br_id:
            if report_references_user_vars(
                    db.get_business_report(br_id), db):
                return True
        if file_id:
            if report_references_user_vars({"raw_sql_file_id": file_id}, db):
                return True
        return False
    except Exception:
        return True


def _resolve_db_manager():
    """The db manager, resolved the way the rest of this module resolves it."""
    try:
        from api import published_views_api as _core
        return _core._db_manager
    except (ImportError, AttributeError):
        return None


def _user_cache_scope(pv: dict, consumer_user: Optional[dict], db=None) -> Optional[str]:
    """Return a stable scope string for the consumer or None.

    Returns None when the PV has no row-security policies (the cache can
    be shared across users).  Returns a hash-derived scope string when the
    PV will run row_security.secure_sql with user_ctx — those rewrites
    produce per-user SQL and therefore per-user results.
    """
    # Cheap detection: PVs that opt into RLS expose either explicit policies
    # or a flag.  We treat ANY of these markers as "scope per user".
    has_rls = bool(
        pv.get("row_security_policies")
        or pv.get("row_security_enabled")
        or pv.get("rls_enabled")
    )
    # Phase 131 deep-dive #13 (hardening): connection-level policies apply
    # to ALL queries on that connection regardless of PV opt-in flags.
    # When row_security is globally enabled we cannot safely share the
    # cache across users — we have no cheap way to tell at this layer
    # whether the underlying connection has policies that would rewrite
    # this PV's SQL.
    #
    # 2026-09-26 (F0, row security ON by default) -- "globally enabled"
    # alone de-shared every published view in every deployment, policies
    # or none.  ``core.row_security.cache_scope`` now decides for the four
    # caches at once: the shared slot stays when the engine is off or the
    # policy set is readable and EMPTY; any enabled policy anywhere, or a
    # store that cannot be read, scopes per consumer (and the key folds the
    # policy set's digest, see ``_build_cache_key``).
    if not has_rls:
        from core.row_security.cache_scope import shared_slot_is_safe
        if not shared_slot_is_safe():
            has_rls = True
    if not has_rls and _pv_sql_is_principal_varying(pv, db=db):
        # The executed SQL differs per consumer even with no policies at all,
        # so the cache must not be shared. See _pv_sql_is_principal_varying.
        has_rls = True
    if not has_rls:
        return None
    # 2026-09-07 -- the DERIVATION moved to core.cache_identity; it was a
    # byte-identical copy of ``core.query_cache.rls_user_scope``'s tail.
    # The sentinel and the "does this PV have RLS" policy above stay here.
    from core.cache_identity import (
        NO_PRINCIPAL, principal_fields, scope_token_for_fields,
    )
    if not consumer_user:
        # Caller knows the PV has RLS but provided no user — the safe
        # default is to refuse cache reuse with a sentinel that won't
        # collide with any real user identity.
        return NO_PRINCIPAL
    return scope_token_for_fields(*principal_fields(consumer_user))


# ── JSON response envelope ──────────────────────────────────────────────────

def _build_json_envelope(
    slug: str, result: dict, pv: dict,
    elapsed_ms: int, cached: bool, cache_age: int, auth_method: str,
    request_id: str = "",
    pv_cfg=None,
) -> dict:
    """Build a clean, consistent JSON response envelope for external consumers.

    Strips internal keys (cache_key, column_metadata, _parquet_path) and adds
    version + request_id from the published view record.
    """
    # Schema drift detection: warn if result columns don't match published config
    _drift_warning = None
    _expected_cols = {c.get("columnName", c.get("name", "")).lower()
                      for c in (pv.get("query_config") or {}).get("selected_columns") or []}
    if _expected_cols and result.get("columns"):
        _actual_cols = {(c["name"].lower() if isinstance(c, dict) else c.lower()) for c in result["columns"]}
        _missing = _expected_cols - _actual_cols
        if _missing:
            _drift_warning = f"Schema drift: {len(_missing)} expected column(s) missing from source"
            logger.warning("[schema-drift] view=%s missing_columns=%s", slug, sorted(_missing))

    # Large result warning — help consumers discover CSV/Parquet for big datasets
    _row_count = result.get("total_rows", 0)
    _large_result_threshold = int((pv_cfg.large_result_threshold if pv_cfg else None) or 50000)
    _large_result_warning = None
    if _row_count > _large_result_threshold:
        _large_result_warning = (
            f"Large result set ({_row_count:,} rows). "
            "Consider using format=csv or format=parquet for better performance."
        )

    # Phase 142+: explicit pagination metadata so consumers don't have to
    # do the math.  has_more / next_offset / page_number / total_pages
    # follow the convention used by Stripe, GitHub, and Atlassian APIs.
    #
    # 2026-08 redesign — pagination is computed from the DATASET TRUTH:
    #   * ``result["limit"]`` is now ALWAYS set by the producers (endpoint
    #     HIT path + all three executors).  The old ``result.get("limit")``
    #     read a key NO producer set, so has_more silently keyed off
    #     ``pv.default_limit`` and was wrong whenever the consumer's limit
    #     differed from the default.
    #   * ``total_rows`` is the dataset's true total (footer of the FULL
    #     materialized dataset / exact COUNT), so ``offset+returned < total``
    #     is sufficient for has_more — the old ``returned == limit`` conjunct
    #     existed only because total_rows could not be trusted.
    #   * ``total_mode`` (exact | at_least | unknown) is surfaced in meta so
    #     the envelope never implies exactness it doesn't have.  Missing mode
    #     → "unknown", never "exact" (UNKNOWN=UNSAFE is structural: the safe
    #     value is the fallback, the strong claim needs a producer).
    _returned = int(result.get("returned_rows") or 0)
    _offset = int(result.get("offset") or 0)
    # 2026-08-20 -- the `a or b` chain folded 0 through THREE fallbacks.
    # After sentinel normalisation an unlimited-but-EMPTY result carries
    # limit=0, which then fell through to the RAW (unresolved, possibly
    # None) row default and finally to 0.  Pagination cosmetics only, but it
    # is the banned idiom sitting in the module that bans it.  Each step
    # resolved explicitly; None means "not set", 0 means 0.
    _lim_raw = result.get("limit")
    if _lim_raw is None:
        _lim_raw = pv.get("default_limit")
    if _lim_raw is None:
        _lim_raw = _returned
    _limit = int(_lim_raw or 0)
    _total_mode = str(result.get("total_mode") or "unknown")
    _total_pages = (_row_count + _limit - 1) // _limit if _limit and _row_count else None
    _current_page = (_offset // _limit) + 1 if _limit else 1
    # 2026-09-29 -- the CEILING (envelope.paged_ceiling, THE rule).  On a
    # dataset the materialisation capped at ``published_views.dataset_row_cap``
    # ``total_rows`` IS the cap and ``total_pages`` counts the pages
    # available HERE, not the pages of the data.  Found live on Docker: a
    # 6,000,000-row federation view paged by has_more stopped at 1,000,000
    # as if that were the end.  Three fields say where the rows end, what
    # put the end there and where the rest is; ``total_pages_scope`` says
    # what ``total_pages`` counts.  Always present (a missing key must never
    # read as the strong claim): ``null`` / ``"dataset"`` on an exact result.
    # ``has_more`` / ``next_offset`` come from ``page_continuation`` (THE
    # decision): on the ceiling's LAST page they point AT the ceiling, so a
    # client that follows them alone meets the 416 with the bulk pointer
    # instead of stopping silently.
    from api.published_views.envelope import page_continuation as _page_continuation
    _has_more, _next_offset, _ceiling = _page_continuation(result, slug=slug)
    if _ceiling is not None:
        _total_pages_scope = "ceiling"
    elif _total_mode == "exact":
        _total_pages_scope = "dataset"
    else:
        _total_pages_scope = "unknown"

    envelope = {
        "view": slug,
        "total_rows": _row_count,
        "returned_rows": _returned,
        "offset": _offset,
        "columns": result.get("columns", []),
        "data": result.get("data", []),
        "pagination": {
            "limit":        _limit,
            "offset":       _offset,
            "has_more":     _has_more,
            "next_offset":  _next_offset,
            "current_page": _current_page,
            "total_pages":  _total_pages,
            # Hint URL the consumer can follow for the next page.  Omits
            # the original query string — caller must preserve filter/sort.
            "next_page_url": (
                f"/api/v1/views/{slug}?limit={_limit}&offset={_next_offset}"
                + (f"&dataset_version={result['_dataset_version']}"
                   if result.get("_dataset_version") else "")
                if _has_more else None
            ),
            # 2026-10-14 -- the materialization these rows came from; pass it
            # back as ?dataset_version= on every next page (409 if it changed)
            "dataset_version": result.get("_dataset_version"),
            # Where the paged rows END (null = they do not, this endpoint
            # serves the whole dataset), what put the end there, and where
            # the whole result is.  ``total_pages_scope``: "dataset" (pages
            # of the data), "ceiling" (pages available HERE, the first
            # ``truncated_at`` rows), "unknown" (a total of unknown or
            # lower-bound provenance -- see meta.total_mode).
            "truncated_at":      (_ceiling.rows if _ceiling else None),
            "truncated_by":      (_ceiling.set_by if _ceiling else None),
            "continue_with":     (_ceiling.continue_with if _ceiling else None),
            "total_pages_scope": _total_pages_scope,
        },
        "meta": {
            "cached": cached,
            "cache_age_seconds": cache_age,
            "execution_ms": elapsed_ms,
            "version": pv.get("version", 1),
            "auth_method": auth_method,
            "request_id": request_id,
            # 2026-08 redesign — truth provenance (see DatasetManifest):
            "total_mode": _total_mode,
        },
    }
    # Time-travel echo — a consumer who asked for a historical snapshot can
    # VERIFY the response is that snapshot, not current data mislabelled.
    if result.get("snapshot_id") is not None:
        envelope["meta"]["snapshot_id"] = result.get("snapshot_id")
    if result.get("as_of_timestamp_ms") is not None:
        envelope["meta"]["as_of_timestamp_ms"] = result.get("as_of_timestamp_ms")
    # Empty-result honesty (BF-271 made structural): a 0-row success carries a
    # data_status so consumers can tell "verified empty" from "engine wrote a
    # 0-row file and nobody can prove the pipeline didn't swallow a failure".
    if _row_count == 0 and _returned == 0:
        envelope["meta"]["data_status"] = str(result.get("data_status") or "empty_unverified")
        if result.get("empty_causes"):
            envelope["meta"]["empty_causes"] = list(result.get("empty_causes") or [])
    # If the dataset materialization hit its cap (total_mode=at_least), or a
    # response-size cap kicked in, surface it so the consumer KNOWS.
    if _total_mode == "at_least":
        envelope["meta"]["truncated"] = True
    if _ceiling is not None:
        envelope["meta"]["truncation_note"] = _ceiling.sentence()
    if result.get("truncated"):
        envelope["meta"]["truncated"] = True
        envelope["meta"]["truncation_cap"] = result.get("truncation_cap")
        envelope["meta"]["original_row_count"] = result.get("original_row_count")
    if _drift_warning:
        envelope["meta"]["schema_drift_warning"] = _drift_warning
    if _large_result_warning:
        envelope["meta"]["large_result_warning"] = _large_result_warning
    return envelope


# ── Cache header builders + format dispatch ─────────────────────────────────
#
# Phase 140 / publish-API impact analysis Hotspot A:
# ext_get_view_data() previously inlined three near-identical blocks for
# building cache-status headers and dispatching to format-specific Response
# builders.  These helpers centralise the dedup so the dispatch logic lives
# in one place — adding a new response format means editing _send_response,
# not three branches in a 360-line endpoint.

def _record_pv_cache_lookup(hit: bool) -> None:
    """BF-398 — Wire PV cache hit/miss into the shared core.metrics counter
    so the admin Cache Telemetry panel sees this layer (Phase 139 layer
    'published_view'.  Fail-open: telemetry must never break the request."""
    try:
        from core.metrics import record_cache_lookup
        record_cache_lookup("published_view", hit)
    except Exception as _telem_err:
        import logging
        logging.getLogger(__name__).debug(
            "[pv] telemetry record_cache_lookup failed: %s", _telem_err,
        )


def _cache_control_scope(private: bool) -> str:
    """``private`` when the response is USER-SCOPED, ``public`` otherwise.

    2026-09-15 — every response said ``public``, including RLS-scoped rows
    that the cache key scopes per consumer (``_user_cache_scope``).  A
    shared intermediary (a CDN, a corporate forward proxy) honouring that
    directive would serve consumer A's row-secured page to consumer B for
    ``max-age`` seconds.  No intermediary is wired today, so this was
    latent, not live; the directive is now truthful either way.
    """
    return "private" if private else "public"


def _build_cache_hit_headers(
    age: float, cache_ttl: int, etag: str, mtime: float, request_id: str,
    *, private: bool = False,
) -> Dict[str, str]:
    """Headers for a cache HIT (both fresh-cache and dedup-completed paths).

    Includes Last-Modified so consumers can do conditional GETs on retry.
    ``private`` — the response is scoped to this consumer (RLS / a
    principal-varying view): shared caches must not store it.
    """
    from email.utils import formatdate
    _record_pv_cache_lookup(hit=True)
    return {
        "X-Cache-Status": "HIT",
        "X-Cache-Age": str(int(age)),
        "X-Cache-TTL": str(cache_ttl),
        "ETag": etag,
        "Cache-Control": f"max-age={max(0, int(cache_ttl - age))}, {_cache_control_scope(private)}",
        "Last-Modified": formatdate(mtime, usegmt=True),
        "X-Request-ID": request_id,
    }


def _build_miss_headers(
    cache_status: str, cache_ttl: int, etag: str, request_id: str,
    *, private: bool = False,
) -> Dict[str, str]:
    """Headers for a cache MISS or BYPASS (no Last-Modified — content is brand-new).

    BF-398: BYPASS isn't a cache decision (consumer asked to skip cache), so
    it doesn't count as a hit OR miss in telemetry.  MISS counts.
    ``private`` — see ``_build_cache_hit_headers``.
    """
    if cache_status == "MISS":
        _record_pv_cache_lookup(hit=False)
    return {
        "X-Cache-Status": cache_status,
        "X-Cache-Age": "0",
        "X-Cache-TTL": str(cache_ttl),
        "ETag": etag,
        "Cache-Control": ("no-store" if cache_status == "BYPASS"
                          else f"max-age={cache_ttl}, {_cache_control_scope(private)}"),
        "X-Request-ID": request_id,
    }


def _send_response(
    *,
    format: str,
    result: dict,
    slug: str,
    pv: dict,
    elapsed_ms: int,
    cached: bool,
    cache_age: int,
    api_user: dict,
    request_id: str,
    headers: Dict[str, str],
    pv_cfg=None,
    cached_path: Optional[Path] = None,
    response: Optional[Response] = None,
    dataset_version: Optional[str] = None,
):
    """Apply cache headers to ``response`` and return the format-specific Response.

    ``dataset_version`` (2026-10-14): the version the CONSUMER pinned
    (``?dataset_version=``).  Every page names the materialization it came
    from (``X-QS-Dataset-Version`` / ``pagination.dataset_version``, and the
    next-page URL carries it); a pinned page whose dataset was refreshed or
    expired in between is a 409 -- found live: a refresh mid-paging over an
    unordered source gave a consumer 113,241 duplicate rows and lost as many,
    every page a 200.

    For format=parquet, prefers ``cached_path`` (atomic-write target) and falls
    back to ``result["_parquet_path"]`` (executor's working file) — matches the
    BF-144 behaviour that was inlined at the MISS site.

    For JSON, builds the envelope via _build_json_envelope() and returns it as
    a plain dict (FastAPI serialises).  Headers are still applied to the
    Response object that FastAPI hands the endpoint.
    """
    _served = result.get("_dataset_version")
    if dataset_version and dataset_version != _served:
        raise HTTPException(
            409,
            "The data changed while you were paging (it was refreshed or expired), so "
            "the rest of the pages would not match the pages you already have.  Start "
            f"again from offset 0 without dataset_version.  your_version={dataset_version} "
            f"current_version={_served or 'none (this response is not a stored dataset)'}")
    if _served:
        headers = dict(headers)
        headers["X-QS-Dataset-Version"] = _served
    if response is not None:
        for hk, hv in headers.items():
            response.headers[hk] = hv

    # ── 2026-09-29 — the paged CEILING, on every format and every source
    # type (this is the one exit all three source handlers and both cache
    # branches return through).  A page at or past the ceiling is a 416 with
    # the ceiling, the key that sets it and the bulk path in the body --
    # never an empty 200 that reads as "end of data".  A page inside it
    # carries ``X-QS-Truncated-At`` / ``X-QS-Continue-With`` beside the
    # existing ``X-QueryStudio-Truncated`` (csv / parquet / excel consumers
    # see only headers; JSON gets the same fields in ``pagination``).  The
    # route calls the same rule BEFORE its access log so the audit record
    # and the response agree; this is the format-independent backstop.
    from api.published_views.envelope import refuse_past_ceiling as _refuse_past_ceiling
    _ceiling = _refuse_past_ceiling(result, slug=slug)
    if _ceiling is not None:
        headers = dict(headers)
        headers["X-QS-Truncated-At"] = str(_ceiling.rows)
        headers["X-QS-Continue-With"] = _ceiling.continue_with
        if response is not None:
            response.headers["X-QS-Truncated-At"] = str(_ceiling.rows)
            response.headers["X-QS-Continue-With"] = _ceiling.continue_with

    # ── P4 (2026-08-17) — normalise the unlimited sentinel out of the envelope.
    # When the effective limit resolved to "unlimited" the readers were handed
    # PV_UNLIMITED_ROWS as the page bound; consumers should see the returned
    # row count as the page's limit, not the internal 2**53 read bound.
    try:
        if int(result.get("limit") or 0) >= PV_UNLIMITED_ROWS:
            result = dict(result)
            result["limit"] = int(result.get("returned_rows") or 0)
    except (TypeError, ValueError):
        pass

    # ── P6 (2026-08-17) — truncation disclosure is format-INDEPENDENT.
    # The JSON envelope already discloses via meta.truncated, but csv /
    # parquet / excel consumers only see HEADERS.  A dataset that hit its
    # materialization cap (total_mode="at_least"), or a result the response
    # cap already clipped, must carry X-QueryStudio-Truncated on EVERY
    # format — parquet included (it used to be silently exempt from all
    # disclosure).  The cap paths below still overwrite this with their more
    # precise "cap/original" spelling when they fire.
    _pre_truncated = bool(result.get("truncated")) or (
        str(result.get("total_mode") or "") == "at_least")
    if _pre_truncated and "X-QueryStudio-Truncated" not in headers:
        _cap_v = result.get("truncation_cap")
        _orig_v = result.get("original_row_count")
        _trunc_val = (f"{_cap_v}/{_orig_v}" if _cap_v and _orig_v
                      else f"at_least:{result.get('total_rows', '')}")
        headers = dict(headers)
        headers["X-QueryStudio-Truncated"] = _trunc_val
        if response is not None:
            response.headers["X-QueryStudio-Truncated"] = _trunc_val

    # ── E-H4 — bounded-memory streaming fast-path (JSON / CSV) ────────────────
    # When the executor / cache-reader attached a result DataFrame under
    # ``_stream_df`` (it does so only when the endpoint requested streaming for
    # a json/csv request), stream the encoding in bounded batches instead of
    # materializing the whole result.  Fail-SAFE: any error falls back to the
    # original materialized path below (we lazily build result["data"] from the
    # frame first, since streaming mode leaves it empty).  Excel/parquet are
    # never streamed here (the frame is only attached for json/csv).
    _stream_df = result.get("_stream_df")
    if (_stream_df is not None and format in ("csv", "json")
            and _pv_stream_enabled()):
        try:
            _batch = _pv_stream_batch_rows()
            # Apply the same optional result-size cap the materialized path uses
            # (published_api.max_result_rows) — but to the frame, before encode.
            try:
                from core.config import get as _cfg_get
                _cap = int(_cfg_get("published_api", "max_result_rows", 0) or 0)
            except Exception:
                _cap = 0
            if _cap > 0 and _frame_len(_stream_df) > _cap:
                _orig_n = _frame_len(_stream_df)
                _stream_df = _frame_head(_stream_df, _cap)
                result = dict(result)
                result["returned_rows"] = _frame_len(_stream_df)
                result["truncated"] = True
                result["truncation_cap"] = _cap
                result["original_row_count"] = _orig_n
                headers = dict(headers)
                headers["X-QueryStudio-Truncated"] = f"{_cap}/{_orig_n}"
                if response is not None:
                    response.headers["X-QueryStudio-Truncated"] = f"{_cap}/{_orig_n}"
                logger.warning(
                    "Published view '%s' result truncated %d → %d rows (cap=published_api.max_result_rows)",
                    slug, _orig_n, _cap,
                )
            if format == "csv":
                return _csv_streaming_from_df(
                    _stream_df, result.get("columns", []),
                    extra_headers=headers, chunk_size=_batch,
                )
            return _json_streaming_from_df(
                slug, result, pv, _stream_df,
                elapsed_ms, cached=cached, cache_age=cache_age,
                auth_method=api_user.get("auth_method", "api_key"),
                request_id=request_id, pv_cfg=pv_cfg,
                chunk_size=_batch, extra_headers=headers,
            )
        except Exception as _stream_exc:
            logger.warning(
                "[pv] streaming response failed for view '%s' — falling back to "
                "materialized path: %s", slug, _stream_exc,
            )
            # Materialize data from the frame so the fallback dispatch works.
            try:
                result = dict(result)
                result["data"] = _frame_records(_stream_df)
            except Exception:
                result.setdefault("data", [])

    # Phase 142+: result-size safety cap — opt-in via published_api.max_result_rows.
    # When > 0, truncate over-cap results + add a 'truncated' flag and
    # X-QueryStudio-Truncated response header so the consumer KNOWS data was clipped.
    # Default 0 = no cap (preserves existing behaviour).  Skipped for parquet
    # since that's a file download (full file is what the consumer asked for).
    try:
        from core.config import get as _cfg_get
        _max_rows = int(_cfg_get("published_api", "max_result_rows", 0) or 0)
    except Exception:
        _max_rows = 0
    if _max_rows > 0 and format != "parquet":
        _data = result.get("data") or []
        if isinstance(_data, list) and len(_data) > _max_rows:
            _orig_count = len(_data)
            result["data"] = _data[:_max_rows]
            result["truncated"] = True
            result["truncation_cap"] = _max_rows
            result["original_row_count"] = _orig_count
            headers["X-QueryStudio-Truncated"] = f"{_max_rows}/{_orig_count}"
            if response is not None:
                response.headers["X-QueryStudio-Truncated"] = f"{_max_rows}/{_orig_count}"
            logger.warning(
                "Published view '%s' result truncated %d → %d rows (cap=published_api.max_result_rows)",
                slug, _orig_count, _max_rows,
            )

    if format == "csv":
        return _csv_response(result.get("data", []), result.get("columns", []), extra_headers=headers)

    if format == "parquet":
        # 2026-08 redesign — the cache now stores the DATASET (not a page
        # truncated at limit+offset), so serving the cache file raw would
        # over-deliver: a ?limit=100 parquet request could download a
        # million-row dataset.  When the reader attached the PAGE as an Arrow
        # table, write exactly that page (respecting limit/offset/sort/
        # columns) and stream it; the temp file is unlinked after send.
        _page_tbl = result.get("_page_table")
        if _page_tbl is not None:
            import os as _os
            import tempfile as _tf
            import pyarrow.parquet as _ppq
            _fd, _tmp_name = _tf.mkstemp(suffix=".parquet", prefix="pv_page_")
            _os.close(_fd)
            _ppq.write_table(_page_tbl, _tmp_name, compression="zstd")
            return _parquet_download(Path(_tmp_name), slug,
                                     extra_headers=headers, cleanup=True)
        # Legacy fallback (no page table attached): serve the result file.
        target: Optional[Path] = None
        if cached_path and cached_path.exists():
            target = cached_path
        else:
            _result_pq = result.get("_parquet_path")
            if _result_pq and Path(_result_pq).exists():
                target = Path(_result_pq)
        if target is None:
            raise HTTPException(status_code=500, detail="Parquet result file unavailable")
        return _parquet_download(target, slug, extra_headers=headers)

    if format in ("excel", "xlsx"):
        return _excel_response(
            result.get("data", []), result.get("columns", []), slug, extra_headers=headers,
        )

    return _build_json_envelope(
        slug, result, pv, elapsed_ms,
        cached=cached, cache_age=cache_age,
        auth_method=api_user.get("auth_method", "api_key"),
        request_id=request_id,
        pv_cfg=pv_cfg,
    )


# ── Schema extraction ────────────────────────────────────────────────────────

def _extract_schema_from_config(query_config: dict) -> List[Dict[str, str]]:
    """Extract column schema from the frozen query_config (best effort)."""
    cols = query_config.get("selected_columns") or []
    return [
        {"name": c.get("columnName", c.get("name", str(c))),
         "type": c.get("type", "string")}
        for c in cols
    ] if cols else []


def _extract_schema_from_cache(view_id: int, cache_dir=None) -> List[Dict[str, str]]:
    """Fallback: extract column schema from the newest cached parquet file for this view."""
    if cache_dir is None:
        # Backward compat: resolve from core module
        try:
            from api import published_views_api as _core
            cache_dir = _core._cache_dir
        except (ImportError, AttributeError):
            pass
    if not cache_dir or not cache_dir.exists():
        return []
    try:
        import pyarrow.parquet as pq
        prefix = f"v{view_id}_"
        candidates = sorted(
            cache_dir.glob(f"{prefix}*.parquet"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            return []
        schema = pq.read_schema(str(candidates[0]))
        _type_map = {"int": "integer", "float": "float", "double": "float",
                      "date": "date", "timestamp": "datetime", "bool": "boolean"}
        result = []
        for field in schema:
            pa_type = str(field.type).lower()
            col_type = "string"
            for key, val in _type_map.items():
                if key in pa_type:
                    col_type = val
                    break
            result.append({"name": field.name, "type": col_type})
        return result
    except Exception as exc:
        logger.debug("Cache schema extraction failed for view %d: %s", view_id, exc)
        return []


# ── Column metadata ──────────────────────────────────────────────────────────

def _build_col_meta(df) -> List[Dict[str, str]]:
    """Build column type metadata from a pandas DataFrame."""
    meta = []
    for c in df.columns:
        dtype = str(df[c].dtype)
        if "int" in dtype:
            col_type = "integer"
        elif "float" in dtype:
            col_type = "float"
        elif "datetime" in dtype:
            col_type = "datetime"
        elif "bool" in dtype:
            col_type = "boolean"
        else:
            col_type = "string"
        meta.append({"name": c, "type": col_type})
    return meta


# ── Cache management ─────────────────────────────────────────────────────────

def _clear_view_cache(view_id: int, cache_dir=None) -> int:
    """Remove all cached responses for a specific view. Returns number of files deleted."""
    if cache_dir is None:
        # Backward compat: resolve from core module (for callers like admin_api)
        try:
            from api import published_views_api as _core
            cache_dir = _core._cache_dir
        except (ImportError, AttributeError):
            pass
    if not cache_dir or not cache_dir.exists():
        return 0
    count = 0
    try:
        prefix = f"v{view_id}_"
        for f in cache_dir.glob(f"{prefix}*.parquet"):
            f.unlink(missing_ok=True)
            count += 1
        # Phase 133-D: clean orphaned .tmp files from interrupted cache writes.
        # 2026-08-20 — AGE-GUARDED: an unconditional unlink here could delete
        # a publisher's IN-FLIGHT staging file mid-copy (on Windows that also
        # raises a sharing violation that aborted this whole loop).  A live
        # staging copy finishes in seconds; only files older than 15 minutes
        # are provably orphans from a crashed writer.
        import time as _t
        _orphan_cutoff = _t.time() - 900
        for f in cache_dir.glob(f"{prefix}*.tmp"):
            try:
                if f.stat().st_mtime > _orphan_cutoff:
                    continue  # in-flight staging file — leave it alone
            except OSError:
                continue
            try:
                f.unlink(missing_ok=True)
                count += 1
            except OSError:
                continue  # e.g. Windows sharing violation on an open file
        # 2026-08 redesign: manifest truth sidecars go with their datasets —
        # an orphaned sidecar could stamp stale truth onto a future entry.
        for f in cache_dir.glob(f"{prefix}*.manifest.json"):
            f.unlink(missing_ok=True)
            count += 1
        if count:
            logger.info("Cleared %d cached responses for view %d", count, view_id)
    except Exception as exc:
        logger.debug("Cache clear failed: %s", exc)
    return count


def _read_cached_result(
    path: Path,
    columns: Optional[List[str]],
    offset: int,
    limit: int,
    sort_column: Optional[str],
    sort_dir: str,
    stream: bool = False,
) -> dict:
    """Read a cached parquet and apply runtime transformations.

    E-H4: when ``stream`` is True the transformed frame is attached under
    ``_stream_df`` and ``data`` is left empty, so ``_send_response`` can stream
    the encoding in bounded batches rather than materializing the full
    list-of-dicts here.  All other fields (total_rows/returned_rows/columns)
    are computed identically regardless of ``stream``.

    2026-07-31 memory bound — this is the cache-HIT reader.  ``cache_ttl``
    defaults to 28800s, so MOST Published-API page requests land here, and
    this path still did ``pq.read_table(...).to_pandas()``: column projection
    only, FULL row materialisation.  At the target shape (10-20M rows x ~900
    cols) that is an O(result) allocation to hand back one page.  Delegate to
    the same bounded reader the cache-MISS path already uses
    (``_read_parquet_page``): footer-only total_rows, column projection pushed
    into the reader, offset/limit via ``iter_batches`` with early stop.  The
    SORT path still reads every row — a global sort cannot be evaluated from
    a prefix — but with the column projection applied, which is where the
    bytes are at 900 columns.  Side effect of the delegation: sorting by a
    column that is NOT in the requested projection now works on cache hits
    (it already did on cache misses — the two paths previously disagreed).
    """
    # 2026-08 redesign — Arrow-native page read via the SAME bounded pager the
    # MISS path uses (envelope.read_page: footer-only total, projection +
    # offset/limit pushdown, early stop).  No pandas on the wire path: int64
    # columns with NULLs keep exact values (the old ``.to_pandas()`` coerced
    # nullable int64 → float64, silently rounding IDs above 2^53).  strict=True
    # makes this the cache-HIT half of the ?columns/?sort validation
    # chokepoint — unknown names 400 here exactly as they do on a MISS.
    table, total_rows = read_page(
        str(path),
        columns=columns,
        limit=limit,
        offset=offset,
        sort_column=sort_column,
        sort_dir=sort_dir,
        strict=True,
    )

    _out = {
        "total_rows": total_rows,
        "returned_rows": table.num_rows,
        "offset": offset,
        "limit": limit,
        "columns": col_meta_from_schema(table.schema),
        # The page as Arrow — format renderers that need exact bytes
        # (parquet page download) read THIS, never the whole dataset file.
        "_page_table": table,
    }
    if stream:
        # Defer encoding to the streaming response builder (bounded memory).
        _out["data"] = []
        _out["_stream_df"] = table
    else:
        _out["data"] = rows_from_table(table)
    return _out


# ── Response format helpers ──────────────────────────────────────────────────

def _stamp_expected_rows(hdrs: Dict[str, str], n_rows: int) -> None:
    """Pre-body row-count disclosure (2026-08-20, bulk.py contract).

    A streaming 200 cannot revoke its status line, so the ONLY honest
    completeness signal is one emitted BEFORE the body.  ``n_rows`` is the
    count this response intends to deliver; a consumer reconciling
    rows-received against it detects a mid-stream abort that every CSV
    parser would otherwise swallow silently.
    """
    hdrs["X-QS-Expected-Rows"] = str(max(0, int(n_rows)))
    _ach = hdrs.get("Access-Control-Expose-Headers")
    if _ach:
        if "X-QS-Expected-Rows" not in _ach:
            hdrs["Access-Control-Expose-Headers"] = _ach + ", X-QS-Expected-Rows"
    else:
        hdrs["Access-Control-Expose-Headers"] = "X-QS-Expected-Rows"


def _csv_response(data: List[dict], columns: List[dict],
                   extra_headers: Optional[Dict[str, str]] = None) -> StreamingResponse:
    """Return data as true-streaming CSV response with cache/correlation headers.

    Phase 133-C: Yields rows in 1000-row chunks instead of materializing the
    entire result in memory — prevents OOM on large views.

    2026-08-20 — two "partial reported as success" fixes (mirrored in
    ``_csv_streaming_from_df``, which must stay byte-identical):
      * An empty result with KNOWN columns now emits a header-only CSV (the
        grid export has always done this) — a 0-byte 200 body was
        indistinguishable from a leg that failed before producing output.
      * A mid-stream failure emits an in-band ``#QS-EXPORT-ERROR`` trailer
        line and re-raises, and the pre-body ``X-QS-Expected-Rows`` header
        (bulk.py contract) lets consumers reconcile rows-received.
    """
    _CHUNK_SIZE = 1000

    def _csv_generator():
        if not data and not columns:
            return  # nothing known — cannot even emit a header
        fieldnames = [c["name"] for c in columns] if columns else list(data[0].keys())
        # Yield header
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        yield buf.getvalue().encode("utf-8")
        # Yield rows in chunks
        rows_sent = 0
        try:
            for i in range(0, len(data), _CHUNK_SIZE):
                chunk_buf = io.StringIO()
                chunk_writer = csv.DictWriter(chunk_buf, fieldnames=fieldnames)
                for row in data[i:i + _CHUNK_SIZE]:
                    chunk_writer.writerow({k: row.get(k, "") for k in fieldnames})
                yield chunk_buf.getvalue().encode("utf-8")
                rows_sent += len(data[i:i + _CHUNK_SIZE])
        except GeneratorExit:
            raise
        except Exception as exc:
            yield (f"\n#QS-EXPORT-ERROR: export aborted after {rows_sent} "
                   f"rows: {type(exc).__name__}: {exc}\n").encode("utf-8")
            raise

    hdrs = {"Content-Disposition": "attachment; filename=data.csv"}
    if extra_headers:
        hdrs.update(extra_headers)
    _stamp_expected_rows(hdrs, len(data))
    return StreamingResponse(
        _csv_generator(),
        media_type="text/csv",
        headers=hdrs,
    )


def _parquet_download(path: Path, slug: str,
                      extra_headers: Optional[Dict[str, str]] = None,
                      cleanup: bool = False) -> StreamingResponse:
    """Return a parquet file as download with cache/correlation headers.

    cleanup=True unlinks the file after the response is sent (used for
    per-request page files written by _send_response)."""
    def _iter_file():
        with open(str(path), "rb") as f:
            while chunk := f.read(64 * 1024):
                yield chunk

    file_size = path.stat().st_size
    hdrs = {
        "Content-Disposition": f'attachment; filename="{slug}.parquet"',
        "Content-Length": str(file_size),
    }
    if extra_headers:
        hdrs.update(extra_headers)
    _background = None
    if cleanup:
        from starlette.background import BackgroundTask

        def _unlink():
            try:
                Path(path).unlink(missing_ok=True)
            except OSError as _rm_exc:
                logger.debug("page parquet cleanup failed for %s: %s", path, _rm_exc)

        _background = BackgroundTask(_unlink)
    return StreamingResponse(
        _iter_file(),
        media_type="application/octet-stream",
        headers=hdrs,
        background=_background,
    )


def _excel_response(data: List[dict], columns: List[dict], slug: str,
                     extra_headers: Optional[Dict[str, str]] = None) -> StreamingResponse:
    """BF-269: Return data as XLSX (Excel) download.

    Published API previously only supported json / csv / parquet.  Users
    consuming the API from Excel-first workflows had to manually convert
    CSVs.  This adds native .xlsx via openpyxl through pandas' ExcelWriter.

    Streamed via BytesIO + StreamingResponse so the dialect matches the
    other format handlers (no on-disk temp).  openpyxl is already a hard
    dep for business reports so no extra requirements.

    2026-08 redesign — writes cells DIRECTLY via openpyxl instead of routing
    the records through ``pd.DataFrame(...)``: pandas infers float64 for an
    int column containing any None, so ``9007199254740993`` became
    ``9007199254740992.0`` in the workbook.  openpyxl stores Python ints
    exactly; ``excel_cell`` coerces only non-native values (via str) and
    leaves ints/Decimals/temporals intact.
    """
    import io as _io
    from openpyxl import Workbook as _Workbook

    fieldnames = [c["name"] for c in columns] if columns else (list(data[0].keys()) if data else [])

    wb = _Workbook(write_only=True)
    ws = wb.create_sheet(title=(slug or "data")[:31] or "data")
    ws.append(fieldnames)
    for row in (data or []):
        ws.append([excel_cell(row.get(k)) for k in fieldnames])
    buf = _io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    hdrs = {
        "Content-Disposition": f'attachment; filename="{slug}.xlsx"',
    }
    if extra_headers:
        hdrs.update(extra_headers)
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers=hdrs,
    )


# ── E-H4 — bounded-memory streaming of JSON / CSV from the result frame ───────
#
# Audit finding: the executor read the whole result parquet into pandas and
# then did ``to_dict(orient="records")`` + sanitize, turning the ENTIRE result
# into a giant Python list-of-dicts (typically 5-20x the frame's memory) before
# formatting — and for JSON the FastAPI layer then built the full response
# string on top of that.  For a million-row view that is the OOM path.
#
# These helpers stream the ENCODING of an already-computed result DataFrame in
# fixed-size row batches, so peak memory for the encode step is bounded by the
# batch size, not the result size — the list-of-dicts and the full JSON string
# are never materialized.  Output is byte-identical to the previous materialized
# path because we stream from the SAME transformed frame (same rows, same order,
# same per-row ``sanitize_for_json``) and, for JSON, reuse ``_build_json_envelope``
# for the envelope skeleton so only the ``data`` array is streamed.
#
# Config (published_views section, read fail-safe):
#   stream_results      (bool, default True)   — master switch; False restores
#                                                the fully-materialized path.
#   stream_batch_rows   (int,  default 10000)  — rows per encode batch.

def _pv_stream_enabled() -> bool:
    """True when streaming JSON/CSV responses is enabled (default True)."""
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("published_views", "stream_results", True))
    except Exception:
        return True


def _pv_bounded_page_scan_enabled() -> bool:
    """True (default) when a paged ``/data`` MISS materialises only what the
    page needs (``envelope.page_scan_bound``); False restores the pre-2026-09-15
    full ``dataset_row_cap`` materialisation on every miss."""
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("published_views", "bounded_page_scan", True))
    except Exception:
        return True


def _pv_stream_batch_rows() -> int:
    """Rows per streaming encode batch (default 10000, floor 1)."""
    try:
        from core.config import get as _cfg_get
        return max(1, int(_cfg_get("published_views", "stream_batch_rows", 10000)))
    except Exception:
        return 10000


def _is_arrow_table(obj) -> bool:
    """Duck-type check: Arrow tables page via ``slice``/``to_pylist``; legacy
    pandas frames via ``iloc``/``to_dict``.  Streaming helpers accept both so
    internal callers that still hold a frame keep working, while the external
    wire path is Arrow (exact int64)."""
    return hasattr(obj, "to_pylist") and hasattr(obj, "slice")


def _frame_len(obj) -> int:
    return int(getattr(obj, "num_rows", None) if _is_arrow_table(obj) else len(obj))


def _frame_head(obj, n: int):
    return obj.slice(0, n) if _is_arrow_table(obj) else obj.head(n)


def _frame_records(obj) -> List[dict]:
    if _is_arrow_table(obj):
        return rows_from_table(obj)
    return sanitize_for_json(obj.to_dict(orient="records"))


def _frame_columns(obj) -> List[str]:
    if _is_arrow_table(obj):
        return list(obj.column_names)
    return list(obj.columns)


def _iter_df_records(df, chunk_size: int):
    """Yield ``sanitize_for_json``'d record lists in bounded row batches.

    Accepts an Arrow table (redesign wire path — exact int64) or a legacy
    pandas frame.  Each yielded list is a batch of record dicts — identical,
    concatenated, to ``_frame_records(df)`` but produced one batch at a time.
    """
    if _is_arrow_table(df):
        yield from iter_row_batches(df, chunk_size)
        return
    n = len(df)
    for start in range(0, n, chunk_size):
        chunk = df.iloc[start:start + chunk_size]
        yield sanitize_for_json(chunk.to_dict(orient="records"))


def _csv_streaming_from_df(df, columns: List[dict],
                           extra_headers: Optional[Dict[str, str]] = None,
                           chunk_size: int = 10000) -> StreamingResponse:
    """Stream CSV directly from a result DataFrame in bounded batches.

    Byte-identical to ``_csv_response(sanitize_for_json(df.to_dict('records')),
    columns)``: same header derivation, same per-row ``row.get(k, "")`` cell
    projection, same empty-result behaviour (2026-08-20: header-only CSV when
    the frame is empty but columns are known — a 0-byte 200 body was
    indistinguishable from a failed leg).  Mid-stream failures emit the same
    in-band ``#QS-EXPORT-ERROR`` trailer and pre-body ``X-QS-Expected-Rows``
    header as ``_csv_response``.
    """
    def _gen():
        _empty = df is None or _frame_len(df) == 0
        if _empty and not columns and (df is None or not list(_frame_columns(df))):
            return  # nothing known — cannot even emit a header
        fieldnames = ([c["name"] for c in columns] if columns
                      else _frame_columns(df))
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        yield buf.getvalue().encode("utf-8")
        if _empty:
            return
        rows_sent = 0
        try:
            for recs in _iter_df_records(df, chunk_size):
                cbuf = io.StringIO()
                cw = csv.DictWriter(cbuf, fieldnames=fieldnames)
                for row in recs:
                    cw.writerow({k: row.get(k, "") for k in fieldnames})
                yield cbuf.getvalue().encode("utf-8")
                rows_sent += len(recs)
        except GeneratorExit:
            raise
        except Exception as exc:
            yield (f"\n#QS-EXPORT-ERROR: export aborted after {rows_sent} "
                   f"rows: {type(exc).__name__}: {exc}\n").encode("utf-8")
            raise

    hdrs = {"Content-Disposition": "attachment; filename=data.csv"}
    if extra_headers:
        hdrs.update(extra_headers)
    _stamp_expected_rows(hdrs, 0 if df is None else _frame_len(df))
    return StreamingResponse(_gen(), media_type="text/csv", headers=hdrs)


def _json_streaming_from_df(
    slug: str, result: dict, pv: dict, df,
    elapsed_ms: int, cached: bool, cache_age: int, auth_method: str,
    request_id: str, pv_cfg=None,
    chunk_size: int = 10000,
    extra_headers: Optional[Dict[str, str]] = None,
) -> StreamingResponse:
    """Stream the JSON envelope, with the ``data`` array streamed in batches.

    The envelope skeleton (view/total_rows/returned_rows/columns/pagination/
    meta and any truncation/drift/large-result flags) is built by the SAME
    ``_build_json_envelope`` used on the materialized path — with an empty
    ``data`` list — then serialized with the exact settings Starlette's
    JSONResponse uses (``ensure_ascii=False, allow_nan=False,
    separators=(",", ":")``).  We split the skeleton at the empty ``data``
    array and stream each row (already sanitized to JSON-native types) between
    the brackets.  Result: parsed-identical, and byte-identical for the common
    all-primitive case, to the previous dict-return path.
    """
    def _dumps(o) -> str:
        return json.dumps(o, ensure_ascii=False, allow_nan=False,
                          separators=(",", ":"))

    # Build the envelope with NO data so counts/pagination/meta are computed
    # from the result's own scalar fields (total_rows/returned_rows/columns),
    # not from the row list.
    _skeleton_src = dict(result)
    _skeleton_src["data"] = []
    skeleton = _build_json_envelope(
        slug, _skeleton_src, pv, elapsed_ms,
        cached=cached, cache_age=cache_age, auth_method=auth_method,
        request_id=request_id, pv_cfg=pv_cfg,
    )
    full = _dumps(skeleton)
    _marker = '"data":[]'
    idx = full.find(_marker)
    if idx == -1:
        # Should never happen (we forced data=[]) — fail safe by materializing.
        skeleton["data"] = _frame_records(df) if df is not None else []
        body = _dumps(skeleton).encode("utf-8")
        hdrs = {}
        if extra_headers:
            hdrs.update(extra_headers)
        return StreamingResponse(iter([body]), media_type="application/json", headers=hdrs)

    prefix = (full[:idx] + '"data":[').encode("utf-8")
    suffix = (']' + full[idx + len(_marker):]).encode("utf-8")

    def _gen():
        yield prefix
        first = True
        if df is not None and _frame_len(df):
            for recs in _iter_df_records(df, chunk_size):
                parts = []
                for rec in recs:
                    if first:
                        parts.append(_dumps(rec))
                        first = False
                    else:
                        parts.append("," + _dumps(rec))
                if parts:
                    yield "".join(parts).encode("utf-8")
        yield suffix

    hdrs = {}
    if extra_headers:
        hdrs.update(extra_headers)
    return StreamingResponse(_gen(), media_type="application/json", headers=hdrs)


# ── Access logging ───────────────────────────────────────────────────────────

def _log_access(
    api_user: dict, pv: dict, filters: list,
    rows: int, ms: int, status: int, request: Request,
    db_manager=None,
    *,
    cache_status: str = "",
    execution_id: str = "",
    error_details: str = "",
    columns_requested: Optional[List[str]] = None,
    sort_spec: str = "",
    params: Optional[Dict[str, Any]] = None,
) -> None:
    """Log API access (fire-and-forget).

    Phase 133-C: Enriched with request_id, cache_status, execution_id,
    error_details, columns, sort, and params for full per-request observability.
    """
    if db_manager is None:
        # Backward compat: resolve from core module
        try:
            from api import published_views_api as _core
            db_manager = _core._db_manager
        except (ImportError, AttributeError):
            pass
    if not db_manager:
        return

    # Build enriched request_params dict
    request_id = request.headers.get("x-request-id", "") if request else ""
    enriched_params: Dict[str, Any] = {"filters": filters}
    if cache_status:
        enriched_params["cache_status"] = cache_status
    if request_id:
        enriched_params["request_id"] = request_id
    if execution_id:
        enriched_params["execution_id"] = execution_id
    if error_details:
        enriched_params["error_details"] = error_details[:500]
    if columns_requested:
        enriched_params["columns"] = columns_requested
    if sort_spec:
        enriched_params["sort"] = sort_spec
    if params:
        enriched_params["params"] = params

    # 2026-10-03 -- QUEUED, not written: the row goes to the process's
    # access-log batcher (core/access_log_batcher.py -- one multi-row INSERT
    # per flush interval, a bounded queue, every drop counted and logged).
    # This was a synchronous INSERT on the event loop on EVERY request.
    try:
        from core.access_log_batcher import record as _record_access
        _record_access(
            db_manager,
            api_key_id=api_user.get("api_key_id"),
            view_id=pv["id"],
            execution_id=execution_id or None,
            request_params=enriched_params,
            response_rows=rows,
            response_ms=ms,
            status_code=status,
            client_ip=request.client.host if request.client else None,
        )
    except Exception as exc:
        logger.warning("Access log write failed (fire-and-forget): %s", exc)
