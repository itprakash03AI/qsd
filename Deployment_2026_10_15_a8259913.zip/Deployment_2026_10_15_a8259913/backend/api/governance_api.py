"""Change-control API — export, deploy, drift report (BRD §15, Step 8).

Thin HTTP shell over ``core.feed.governance``:

* ``GET  /api/governance/export/{object_type}/{object_id}`` — one object
  as deterministic YAML (raw ``text/yaml``: these are the bytes that go
  in git, byte-identical on every call for an unchanged object);
* ``GET  /api/governance/export/{object_type}`` — every object of a type,
  ``[{path, yaml}]`` (one file per object — a CI job writes these into
  the repo working tree and the diff is the review);
* ``POST /api/governance/deploy`` — apply reviewed definition files to
  an environment, transactionally, recording commit + ticket on every
  row touched (admin-gated; §16.4 platform-operator action);
* ``GET  /api/governance/drift`` — which prod rows no longer match what
  was deployed, answered from the database alone.

The pod never talks to git: a deploy pipeline (CI) reads the repository,
resolves the ref to a commit sha, and POSTs the file CONTENTS plus that
sha.  Secrets can never appear in any response here — exports are
secret-stripped and drift diffs strip both sides (core.feed.governance).
"""
import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from api.deps import require_admin, require_admin_read
from core.feed import governance
from core.feed.governance import GovernanceError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/governance", tags=["governance"])

# Module-level dependencies (same wiring pattern as api/feed_api.py)
_db_manager = None
_alarm_fn = None


def set_governance_dependencies(db_manager, alarm_fn=None) -> None:
    global _db_manager, _alarm_fn
    _db_manager = db_manager
    _alarm_fn = alarm_fn


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503,
                            detail="governance dependencies not wired")
    return _db_manager


def _check_object_type(object_type: str) -> None:
    if object_type not in governance.GOVERNED_OBJECT_TYPES:
        raise HTTPException(
            status_code=404,
            detail=f"unknown governed object type {object_type!r} — one of "
                   f"{sorted(governance.GOVERNED_OBJECT_TYPES)}")


def _gov_cfg() -> dict[str, Any]:
    from core import config as _config
    return _config.get("feed_generation", "governance", {}) or {}


@router.get("/export/{object_type}/{object_id}")
def export_one(object_type: str, object_id: int,
               _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """One governed object as its git file — raw deterministic YAML."""
    _check_object_type(object_type)
    row = _db().get_governed_object(object_type, object_id)
    if row is None:
        raise HTTPException(status_code=404,
                            detail=f"{object_type} {object_id} not found")
    try:
        # export_BYTES, not the str: this response IS the artifact that
        # lands in a git repo, and the function guarantees UTF-8 with LF
        # terminators — "git-canonical" in its own words.  Handing
        # FastAPI a str delegates the encoding decision to the response
        # layer, which is how a deterministic export stops being
        # deterministic on a different platform.  It had no caller.
        text = governance.export_bytes(row, object_type=object_type)
        path = governance.export_filename(object_type, row.get("name"))
    except GovernanceError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return Response(
        content=text,
        media_type="text/yaml; charset=utf-8",
        headers={"X-Governance-Path": path},
    )


@router.get("/export/{object_type}")
def export_all(object_type: str,
               _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """Every governed object of one type — one (path, yaml) per object."""
    _check_object_type(object_type)
    out: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for row in (_db().list_governed_objects(object_type) or []):
        try:
            out.append({
                "object_id": row.get("id"),
                "path": governance.export_filename(object_type,
                                                   row.get("name")),
                "yaml": governance.export_definition(
                    row, object_type=object_type),
            })
        except GovernanceError as exc:
            # One unexportable row (e.g. unnameable) must not hide the
            # rest of the estate — reported, never silently dropped.
            skipped.append({"object_id": row.get("id"),
                            "error": str(exc)})
    return {"object_type": object_type, "files": out, "skipped": skipped}


class DeployFile(BaseModel):
    path: str = Field(..., min_length=1)
    content: str


class DeployRequest(BaseModel):
    environment: str = Field(..., min_length=1)
    commit: str = Field(..., min_length=1,
                        description="git commit sha the CI job resolved")
    ticket: str | None = Field(None, description="JIRA ticket for this change")
    files: list[DeployFile]


@router.post("/deploy")
def deploy(req: DeployRequest, user: dict = Depends(require_admin)):  # noqa: B008 — FastAPI DI idiom
    """Apply a reviewed git ref's definition files to one environment.

    The CI pipeline reads the repo and posts contents + resolved sha —
    the pod itself has no git access.  Transactional: every row stamped
    or none.  Refused whole when any file is malformed, when any file
    carries a credential-shaped key, or when the JIRA ticket is invalid
    (a tracker OUTAGE follows governance.jira.outage_policy and is
    recorded on the result, never silently ignored)."""
    if not bool(_gov_cfg().get("enabled", False)):
        raise HTTPException(
            status_code=403,
            detail="governance deploys are disabled "
                   "(feed_generation.governance.enabled=false) — export and "
                   "drift remain available in shadow mode")
    try:
        result = governance.apply_deploy(
            _db(),
            environment=req.environment,
            commit=req.commit,
            ticket=req.ticket,
            deployed_by=(user or {}).get("username"),
            files=[f.model_dump() for f in req.files],
        )
    except GovernanceError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return result


@router.get("/drift")
def drift(environment: str,
          _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """Which rows no longer match what was deployed — from the DB alone.
    Detection only: nothing is corrected here (§15.2 break-glass)."""
    return governance.drift_report(_db(), environment=environment,
                                   alarm_fn=_alarm_fn)
