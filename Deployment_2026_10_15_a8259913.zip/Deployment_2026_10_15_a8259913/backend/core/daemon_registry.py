"""Daemon OWNERSHIP registry — who runs a gated daemon, made explicit.

THE DEFECT CLASS THIS CLOSES (2026-08-20)
-----------------------------------------
``core.pod_role.should_run(name)`` can say NO on a pod, but nothing in the
system could say WHERE the daemon runs instead.  Ownership was an accident of
which ENTRY FILE contained the start code: ``main.py`` starts a daemon where
the HTTP app runs, ``scheduler_worker.py`` starts what its own hand-written
list happens to carry, and the two had no shared source of truth.  So a gate
added in main.py without a matching worker-side registration silently DELETED
the capability — "gated everywhere, owned nowhere".  It happened to the four
retention sweeps on 2026-08-19 (caught same day), and again, unnoticed, to
SIX more capabilities: the ETL cron scheduler, DQ scheduled rule execution,
admin custom cron jobs, PV access-log retention, the DataFlow SLA scanner and
the prewarm service ran on NO pod in an api/worker split.

THE MECHANISM
-------------
One declarative table, three explicit categories, all consumed by machines:

* ``SCHEDULER_OWNED``  — gate name -> registration callable.  The scheduler
  pod (``scheduler_worker.py``) EXECUTES this dict at boot; it has no daemon
  list of its own any more, so a name in this table cannot fail to be owned.
* ``API_OWNED``        — gate name -> reason it deliberately stays with the
  HTTP app.  An unexplained entry is how a list becomes a rubber stamp, so
  the reason is part of the table.
* ``KNOWN_ORPHANS``    — honest debt: gated, no owner yet.  Alarmed at
  runtime (see ``is_owned_somewhere``) and FROZEN in the closure test so new
  debt fails the build instead of accumulating silently.

``core.pod_role.should_run`` consults :func:`is_owned_somewhere` whenever it
is about to answer False: gating a daemon nobody owns logs a grep-able
``DAEMON-ORPHAN`` ERROR.  The decision itself is unchanged — a gate must
fail LOUD, not quietly widen back onto the API pod (that would recreate the
2026-07-02 20 GB incident the role exists to prevent).

STATUS AND RUN-NOW (2026-10-07)
-------------------------------
Ownership says WHERE a daemon runs; it said nothing about whether it ran.
``core/background_job_contract.py`` is the sibling table this registry
owns: every name in ``SCHEDULER_OWNED`` (plus its ``EXTRA_JOBS``: the
snapshot listeners, the fleet syncer, the four init_scheduler S3 jobs)
declares a STATUS READER and a RUN-NOW tick -- or the reason it has none --
and ``GET/POST /api/admin/background-jobs/{name}/status|run-now`` are
answered by the OWNING process (proxied to the scheduler worker's control
API in external mode).  Scheduled fires and run-now write ONE ledger.  The
guard ``tests/test_background_job_contract_2026_10_07.py`` enumerates this
table, so adding a daemon HERE without a contract THERE fails the build.
Traps that produced it: a status route answered from the wrong pod's empty
ring (2026-10-07, the Iceberg watcher); per-daemon run-now routes that ran
the tick on the API pod; a tick wrapper that returned nothing, so "fired"
and "did something" were indistinguishable.

The closure guarantee lives in
``tests/test_daemon_ownership_registry_2026_08_20.py``, which EXECUTES this
registry against a paused scheduler + stub db and asserts every name main.py
gates is actually owned — no source-substring assertion, so a
``if True or _daemon_allowed(...)`` mutation cannot satisfy it.

Registration-callable contract: ``fn(ctx: DaemonContext) -> bool`` — True
means "this pod made the ownership decision" (including "feature flag off,
nothing to start"); False/raise means the registration itself failed.
Callables must be cheap to import (heavy imports live INSIDE them) because
``core.pod_role`` imports this module for the orphan check.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class DaemonContext:
    """Everything a scheduler-pod registration needs, in one place.

    * ``db_manager``  — the worker's DatabaseManager.
    * ``scheduler``   — the APScheduler singleton (None if init failed).
    * ``loop``        — the worker process's RUNNING asyncio loop, for
      service-shaped daemons (async poll loops).  None in a bare test.
    * ``connection_manager`` — lazily built; only DQ execution needs one.
    * ``started``     — names of service-shaped daemons actually started;
      the executable evidence of ownership for daemons that do not leave
      an APScheduler job id behind.
    """

    def __init__(self, db_manager: Any, scheduler: Any = None,
                 loop: Any = None) -> None:
        self.db_manager = db_manager
        self.scheduler = scheduler
        self.loop = loop
        self.started: List[str] = []
        #: name -> core.service_loop.ServiceHandle for the service-shaped
        #: daemons :func:`start_service` started on this context's loop.
        self.handles: Dict[str, Any] = {}
        self._conn_manager: Any = None
        self._retention_registered = False

    @property
    def connection_manager(self) -> Any:
        if self._conn_manager is None:
            from core.connection_manager import ConnectionManager
            self._conn_manager = ConnectionManager(self.db_manager)
        return self._conn_manager

    def start_async(self, name: str, coro_factory: Callable[[], Any]) -> bool:
        """Run a service coroutine on the owner's loop; record the start.
        The pre-2026-10-08 spelling of :func:`start_service`; ``False`` when
        the service could not be started (no loop runs here)."""
        return start_service(self, name, coro_factory) is not None


def start_service(ctx: "DaemonContext", name: str,
                  coro_factory: Callable[[], Any]) -> Optional[Any]:
    """THE one way a registration starts a service-shaped (asyncio) daemon
    on whatever process owns it (2026-10-08).

    Schedules ``coro_factory()`` through ``core.service_loop.start_service``
    on ``ctx.loop`` -- the owner's RUNNING loop (the worker's uvicorn loop,
    main.py's lifespan loop), thread-safe from the plain thread
    ``scheduler_worker._start_scheduler`` runs registrations on -- or, when
    the context names no loop, on the calling thread's running loop, else
    on the loop thread ``core.service_loop`` owns and runs.  Never on a loop
    nobody runs: that was how the iceberg manifest watcher came to be
    ``registered`` + ``running: True`` on the scheduler pod with a coroutine
    that had never executed its first line.

    Returns the :class:`core.service_loop.ServiceHandle` (its ``is_running``
    is the coroutine's own started-event), or None when the loop refused;
    ``ctx.started`` records the name only on a handle.
    """
    from core.service_loop import ServiceLoopNotRunning
    from core.service_loop import start_service as _start
    try:
        handle = _start(name, coro_factory, loop=ctx.loop)
    except ServiceLoopNotRunning as exc:
        logger.error("[daemon_registry] %s NOT started: %s", name, exc)
        return None
    ctx.started.append(name)
    ctx.handles[name] = handle
    return handle


# ─────────────────────────────────────────────────────────────────────────────
# Shared dependency wiring for scheduler-executed jobs (Defect B, 2026-08-20)
# ─────────────────────────────────────────────────────────────────────────────

def wire_scheduled_execution_deps(db_manager: Any) -> Dict[str, str]:
    """Wire the module-level dependencies that scheduler-executed jobs reach.

    The scheduler pod registers jobs (subscription delivery, scheduled legacy
    reports, feed runs) whose module dependencies used to be wired ONLY in
    main.py's lifespan — so on a dedicated scheduler pod
    ``delivery_engine._db_manager``, ``api.reports_api._db_manager`` and
    ``feed_engine._db_manager`` were all None and every tick raised
    AttributeError.  This function is the ONE wiring both entry files can
    share (main.py wires richer variants with ws broadcast where it has one).

    Only for processes that EXECUTE scheduled work (scheduler_worker, tests).
    Never call it from main.py — it would clobber main's ws-wired variants
    with broadcast-less ones.

    Each step is individually guarded: a missing optional module costs only
    its own capability.  Returns {step: "ok" | "failed: ..."} so callers/tests
    can see exactly what wired.
    """
    results: Dict[str, str] = {}

    def _step(name: str, fn: Callable[[], Any]) -> None:
        try:
            fn()
            results[name] = "ok"
        except Exception as exc:
            results[name] = f"failed: {exc}"
            logger.warning("[daemon_registry] wiring step %s failed "
                           "(non-fatal): %s", name, exc)

    def _wire_deps() -> None:
        from core.config import auth as _auth_cfg
        from api.deps import init_deps
        init_deps(_auth_cfg, db_manager)

    def _wire_reports_api() -> None:
        # ws_manager/loop stay None: scheduled runs pass a no-op emit and
        # never touch the websocket path (see scheduler._exec_report).
        from api.reports_api import set_report_dependencies
        set_report_dependencies(db_manager, None, None)

    def _wire_feed_engine() -> None:
        from core.config import feed_generation as _fg_cfg
        if not _fg_cfg.enabled:
            return
        from core.feed_engine import init_feed_engine
        # 2026-10-07 -- the scheduler pod's queue worker runs feeds, and with
        # broadcast_fn=None every run it executed was SILENT: no progress, no
        # terminal event, in any browser.  The addressed feed events now ride
        # the scheduler's own broadcast (this pod: the notification queue,
        # which every API pod's relay drains and delivers to the event's
        # AUDIENCE).  The per-line log stream is not sent this way: a durable
        # outbox row per log line would make the outbox a log sink -- the
        # run's log is on its record, and live tailing needs a pod that runs
        # the feed in-process with the bus (hybrid, feed_worker).
        from core.feed.event_audience import relay_feed_event_via_scheduler
        init_feed_engine(db_manager,
                         broadcast_fn=relay_feed_event_via_scheduler)

    def _wire_delivery() -> None:
        from core.delivery_engine import init_default_delivery_engine
        init_default_delivery_engine(db_manager)

    def _wire_business_reports() -> None:
        from core.config import paths as _paths
        from core.federation_engine import FederationEngine
        from api.business_reports_api import set_business_reports_dependencies
        engine = FederationEngine(db_manager,
                                  output_dir=str(_paths.downloads_dir))
        set_business_reports_dependencies(db_manager, engine, None)

    def _wire_notifications() -> None:
        from core.dataflow.notification_policy import init_notification_engine
        init_notification_engine(db_manager, broadcast_fn=None)

    def _wire_snapshot_reactions() -> None:
        register_snapshot_change_reactions(db_manager)

    def _wire_feed_authoring() -> None:
        # 2026-10-11 -- auto-onboarding (core/feed/auto_onboard.py) runs in
        # the dependency poller's tick ON THIS POD and creates a template
        # member through the template apply -> feed_api.create_feed.  Both
        # modules were wired only by main.py: live, every request failed
        # "503: feed templates not wired to a database".
        from core.config import auth as _auth_cfg
        from api.feed_api import set_feed_dependencies
        from api.feed_template_api import set_feed_template_dependencies
        set_feed_dependencies(db_manager, _auth_cfg, broadcast_fn=None)
        set_feed_template_dependencies(db_manager)
        # the dependency declaration validates an oracle_table arrival source
        # through connections_api._require_connection_access (its db + the
        # auth config; no query engine on this pod) -- live, the next failure
        # was "'NoneType' object has no attribute 'get_connection'".
        from core.config import paths as _paths
        from core.connection_manager import ConnectionManager
        from api.connections_api import set_connection_dependencies
        set_connection_dependencies(db_manager, None, ConnectionManager(db_manager),
                                    _paths, _auth_cfg, None)

    def _wire_s3_utilities() -> None:
        # 2026-10-11 -- main.py calls init_s3_utilities(conn_manager); this
        # pod never did, so ``s3_utilities._conn_manager`` was None here and
        # every make_s3_client_for_conn on the scheduler (the iceberg
        # watcher, bloom / prefetch / warm jobs, the feed lane's S3 reads)
        # raised AttributeError into a WARNING traceback and built a NEW
        # boto3 client per call -- 602 tracebacks in 3 h on the rig, and the
        # handler cache (its TTL, epoch and credential-fingerprint
        # invalidation) never applied on the pod doing the most S3 work.
        from core.connection_manager import ConnectionManager
        from core.s3_utilities import init_s3_utilities
        init_s3_utilities(ConnectionManager(db_manager))

    _step("api.deps", _wire_deps)
    _step("api.reports_api", _wire_reports_api)
    _step("core.feed_engine", _wire_feed_engine)
    _step("core.delivery_engine", _wire_delivery)
    _step("api.business_reports_api", _wire_business_reports)
    _step("dataflow.notification_policy", _wire_notifications)
    _step("iceberg.snapshot_change_reactions", _wire_snapshot_reactions)
    _step("core.s3_utilities", _wire_s3_utilities)
    _step("api.feed_template_api", _wire_feed_authoring)
    return results


def register_snapshot_change_reactions(db_manager: Any) -> bool:
    """React to an iceberg snapshot roll ON THE POD THAT DETECTS ONE.

    2026-09-06 — THE EMITTER AND THE LISTENER WERE ON DIFFERENT PODS.

    ``core.database.update_watched_iceberg_sync`` fires
    ``_snapshot_change_listeners`` when a watched table's snapshot id really
    moves.  That listener list is a MODULE-LEVEL, in-process list, and the
    only registration in the product was inside main.py's adaptive-prefetch
    block.  But the only caller of ``update_watched_iceberg_sync`` is
    ``core.iceberg_metadata_sync``, which runs where the DAEMONS run.  So in
    an api/worker split:

      * the API pod holds the listener and never emits the event;
      * the scheduler/worker pod emits it into an EMPTY list.

    Measured by booting both entry points: ``main.py`` (hybrid) ends with
    ``len(core.database._snapshot_change_listeners) == 1``;
    ``scheduler_worker.py`` ends with ``0``.  Two consequences, both silent:
    ``brain_freshness.ensure_fresh`` never fires (so the supplement/bloom
    coverage waits for the hourly adaptive-prefetch cron), and
    ``iceberg_mirror.on_snapshot_rollforward`` never marks a mirror stale.

    That matters more since ``iceberg.lazy_freshness_on_query`` was defaulted
    to false on the reasoning that "the watcher already keeps coverage
    fresh" — the watcher can only keep it fresh where this hook exists.

    Idempotent: ``register_snapshot_change_listener`` de-dupes on identity
    and this function keeps one module-level callback per db_manager.  The
    S3 client factory is built INSIDE the callback, not here, so registering
    costs nothing and cannot fail on a pod whose S3 config is unreadable.
    """
    global _SNAPSHOT_REACTION
    from core.database import (register_snapshot_change_listener,
                               unregister_snapshot_change_listener)

    if _SNAPSHOT_REACTION is not None:
        unregister_snapshot_change_listener(_SNAPSHOT_REACTION)
        _SNAPSHOT_REACTION = None

    def _on_snapshot_change(connection_id, bucket, table_prefix,
                            old_snapshot_id, new_snapshot_id):
        try:
            from core.brain_freshness import ensure_fresh as _ef
            from core.query_history_prefetcher import (
                make_default_s3_client_factory as _mksf,
            )
            _ef(db_manager, _mksf(db_manager), bucket, table_prefix,
                source="watcher", blocking=False)
        except Exception as exc:
            logger.debug("[snapshot-change] brain_freshness dispatch "
                         "failed for %s/%s: %s", bucket, table_prefix, exc)
        try:
            from core.iceberg_mirror import (
                on_snapshot_rollforward as _mirror_roll,
            )
            _mirror_roll(
                db_manager, bucket, table_prefix,
                current_snapshot_id=(str(new_snapshot_id)
                                     if new_snapshot_id else None),
                previous_snapshot_id=(str(old_snapshot_id)
                                      if old_snapshot_id else None),
            )
        except Exception as exc:
            logger.debug("[snapshot-change] mirror rollforward failed "
                         "for %s/%s: %s", bucket, table_prefix, exc)

    register_snapshot_change_listener(_on_snapshot_change)
    _SNAPSHOT_REACTION = _on_snapshot_change
    logger.info("[daemon_registry] snapshot-change reactions registered on "
                "this pod (brain_freshness + mirror rollforward)")
    return True


#: The one callback this module has registered, so a re-wire replaces it
#: instead of stacking a second copy.
_SNAPSHOT_REACTION: Optional[Callable[..., None]] = None


# ─────────────────────────────────────────────────────────────────────────────
# Registration callables — one per gate name main.py uses
# ─────────────────────────────────────────────────────────────────────────────

def _reg_apscheduler_core(ctx: DaemonContext) -> bool:
    """``apscheduler_embedded``: the owner IS the worker's init_scheduler.

    Registration runs AFTER init_scheduler in scheduler_worker, so this is
    executable evidence the worker really started APScheduler — not a
    rubber stamp.
    """
    return ctx.scheduler is not None


def _reg_retention(job_id: str) -> Callable[[DaemonContext], bool]:
    """One retention sweep gate name -> proof its job is on the scheduler.

    ``register_retention_daemons`` registers the whole group idempotently
    (replace_existing=True); each gate name then verifies ITS OWN job id
    exists, so a sweep dropped from the group fails exactly its own name.
    """
    def _reg(ctx: DaemonContext) -> bool:
        if ctx.scheduler is None:
            return False
        if not ctx._retention_registered:
            from core.retention_daemons import register_retention_daemons
            register_retention_daemons(ctx.scheduler, ctx.db_manager)
            ctx._retention_registered = True
        return any(j.id == job_id for j in ctx.scheduler.get_jobs())
    _reg.__name__ = f"_reg_retention_{job_id}"
    return _reg


def _reg_iceberg_metadata_sync(ctx: DaemonContext) -> bool:
    """BF-299 / BF-SCHED-EXTERNAL — moved verbatim from scheduler_worker."""
    try:
        from core.job_control import is_enabled as _jc_enabled
        admin_enabled = _jc_enabled("__iceberg_metadata_sync__")
    except Exception:
        admin_enabled = True
    if not admin_enabled:
        logger.info("iceberg metadata sync DISABLED by admin (job_control "
                    "toggle); skipping start_background_sync")
        return True
    from core.iceberg_metadata_sync import start_background_sync
    return _start_when_singleton(
        ctx, "iceberg_metadata_sync",
        lambda: start_background_sync(ctx.db_manager))


def _reg_iceberg_manifest_watcher(ctx: DaemonContext) -> bool:
    """Phase C — moved verbatim from scheduler_worker."""
    try:
        from core.job_control import is_enabled as _jc_enabled
        admin_enabled = _jc_enabled("__iceberg_manifest_watcher__")
    except Exception:
        admin_enabled = True
    if not admin_enabled:
        logger.info("iceberg manifest watcher DISABLED by admin (job_control "
                    "toggle); skipping start_background")
        return True
    from core.iceberg_manifest_watcher import (
        start_background as _icw_start,
        bootstrap_settings as _icw_bootstrap,
    )
    _icw_bootstrap(ctx.db_manager)
    return _start_when_singleton(
        ctx, "iceberg_manifest_watcher",
        lambda: _icw_start(ctx.db_manager))


def _reg_feed_sla_watcher(ctx: DaemonContext) -> bool:
    """BRD §8/§12 (2026-09-02) — acting time + Netcool.

    ``acting_time`` computes the three clocks and ``netcool`` shapes the
    events; NEITHER RUNS ITSELF.  Without this the two modules are code with
    passing tests and no production caller, which is indistinguishable from
    working code — every unit test agrees and nothing happens.

    Singleton by necessity, not preference: one overdue dependency blocking 34
    feeds must raise ONE alert.  Evaluated on three pods it raises three.
    """
    from core.feed.sla_watcher import start_background as _sla_start
    # session_factory is what enqueue_event hands to the durable queue —
    # without it every event the watcher raises dies at enqueue with
    # "THIS ALERT IS LOST" (loud in the log, lost all the same).
    # ``started`` means ACTUALLY started (see DaemonContext) — a daemon
    # that stated a refusal must not be recorded as running.  Returning
    # True regardless is deliberate and different: the REGISTRY did its
    # job by invoking the owner, and the driver's False branch says
    # "missing prerequisite", which is the wrong words for "an operator
    # turned it off".
    return _start_when_singleton(
        ctx, "feed_sla_watcher",
        lambda: _sla_start(ctx.db_manager, env=_deploy_env_name(),
                           session_factory=ctx.db_manager.SessionLocal))


def _reg_feed_kafka_arrivals(ctx: DaemonContext) -> bool:
    """BRD §7.1 (2026-09-02) — the dependency-arrival consumer.

    Called UNCONDITIONALLY: it announces its own refusal at INFO with the
    reason, which is the whole defect being fixed.  The previous consumer was
    disabled by default with its refusal at ``logger.debug``, so "no messages
    arriving" and "no consumer running" were indistinguishable from outside
    and led to opposite investigations.
    """
    from core.feed.kafka_arrivals import start_consumer as _kaf_start
    return _start_when_singleton(
        ctx, "feed_kafka_arrivals",
        lambda: _kaf_start(ctx.db_manager))


def _reg_feed_netcool_sender(ctx: DaemonContext) -> bool:
    """BRD §12.4 (2026-09-02) — the Netcool queue DRAINER.

    ``netcool`` enqueues and the sla_watcher raises; NOTHING SENDS.
    Store-and-forward without a forwarder is just store — the alert is as
    lost as if it were never raised, and the queue's own audit makes it
    look like alerting works.  Called UNCONDITIONALLY: with the shipped
    ``transport: "none"`` it refuses AT INFO with the reason (the §18
    transport inputs are owed by the Netcool team).

    Singleton like the watcher: one drainer, or every pod posts the same
    event to the console.
    """
    from core.feed.netcool_sender import start_sender as _ncs_start
    return _start_when_singleton(
        ctx, "feed_netcool_sender",
        lambda: _ncs_start(ctx.db_manager.SessionLocal,
                           env=_deploy_env_name()))


def _deploy_env_name() -> str:
    """Environment name for Netcool Identifiers (§12.2).

    Delegates to ``core.config.deploy_environment`` — THE resolver.  This
    body was a hand-copy of the same precedence chain (one of four), and a
    decision made four times is free to give four answers.  Still returns
    "" when nothing declares one; the daemons refuse loudly on "" rather
    than invent a name that keys every alert under a Node nobody routes.
    """
    try:
        from core.config import deploy_environment as _de
        return _de()
    except Exception:                              # noqa: BLE001
        return ""


def _reg_brain_duckdb_mirror(ctx: DaemonContext) -> bool:
    """Phase 160 — supervisor; writer self-gates on the admin toggle
    (DEFAULT OFF).  Moved verbatim from scheduler_worker."""
    # 2026-09-06 — LEADER GATE, restored on this pod.
    #
    # main.py passes ``is_leader_fn`` so at most ONE pod fleet-wide writes
    # the DuckDB mirror store; this entry passed none, so ``reconcile``'s
    # leader gate defaulted open and every scheduler replica would write it
    # concurrently.  The right predicate here is NOT ``is_scheduler_leader``:
    # the worker never acquires that lease (see
    # ``_worker_holds_singleton_role``), so it would answer False forever and
    # the writer would never run at all.  Same election every other singleton
    # duty on this pod uses.
    from core.brain_duckdb_mirror import start_supervisor
    start_supervisor(ctx.db_manager,
                     is_leader_fn=_worker_holds_singleton_role)
    ctx.started.append("brain_duckdb_mirror")
    return True


def _reg_kafka_cache_consumer(ctx: DaemonContext) -> bool:
    """Phase 98-I — moved verbatim from scheduler_worker.  The consumer
    runs on the scheduler pod (singleton) to avoid duplication across API
    replicas; start_kafka_consumer() itself returns False when Kafka is
    disabled/unavailable — that is still an ownership decision."""
    from pathlib import Path
    from core.config import published_views as _pv_cfg
    from core.kafka_cache_consumer import (
        set_kafka_consumer_dependencies, start_kafka_consumer,
    )
    _kv_cache_dir = Path(_pv_cfg.cache_dir) if _pv_cfg else None
    set_kafka_consumer_dependencies(ctx.db_manager, _kv_cache_dir, _pv_cfg)

    def _start() -> bool:
        if start_kafka_consumer():
            logger.info("Kafka cache invalidation consumer started on "
                        "scheduler pod")
            return True
        logger.debug("Kafka cache invalidation disabled or unavailable")
        return False

    return _start_when_singleton(ctx, "kafka_cache_consumer", _start)


def _reg_custom_jobs(ctx: DaemonContext) -> bool:
    """BF-312 admin cron jobs — ORPHAN until 2026-08-20 (ran on no pod in
    an api/worker split).  Registers into core.background_jobs; the worker
    lifespan's autostart_all() then starts it on the loop."""
    from core.custom_jobs import start_custom_jobs_scheduler
    return _start_when_singleton(
        ctx, "custom_jobs_scheduler",
        lambda: start_custom_jobs_scheduler(ctx.db_manager))


def _reg_prewarm_background(ctx: DaemonContext) -> bool:
    """Round 14 prewarm — DECLARED NOT WIRED (2026-09-07).

    ``start_background_prewarm`` now registers an INERT entry: not
    autostartable (its config section is absent from ``_DEFAULTS``), not
    admin-startable, and warming nothing any consumer reads — see
    ``prewarm_background_service.NOT_WIRED_REASON`` for the four
    measurements.  The hook is kept so this registry still OWNS the gate
    name; what it must not do is report a start that did not happen, so
    ``ctx.started`` is deliberately not appended to.
    """
    from core.prewarm_background_service import start_background_prewarm
    return _start_when_singleton(
        ctx, "prewarm_background",
        lambda: start_background_prewarm(ctx.db_manager),
        record_started=False)


def _reg_etl_pipelines(ctx: DaemonContext) -> bool:
    """BF-582 ETL cron scheduler — ORPHAN until 2026-08-20: with
    QS_POD_ROLE=api no loop anywhere called trigger_pipeline for
    trigger_type=schedule pipelines.  Same coroutine main.py runs, on the
    worker's own event loop; broadcast_fn=None (no websocket here)."""
    from core.config import etl_pipelines as _etl_cfg
    if not _etl_cfg.enabled:
        logger.info("[daemon_registry] etl_pipelines disabled by config — "
                    "scheduler loop not started")
        return True
    from core.etl_engine import init_etl_engine, run_etl_scheduler_loop
    init_etl_engine(ctx.db_manager, broadcast_fn=None)
    return _start_when_singleton(
        ctx, "etl_pipelines",
        lambda: start_service(ctx, "etl_pipelines",
                              run_etl_scheduler_loop) is not None,
        record_started=False)


def _reg_dq_scheduled_loop(ctx: DaemonContext) -> bool:
    """Phase 99 DQ scheduled rule execution — ORPHAN until 2026-08-20.
    Interval job mirroring main.py's thread loop (minus the ws broadcast:
    failures are logged; the results table is the record of truth).
    Executing DQ rules is real query-engine work — exactly what belongs on
    this pod instead of the DuckDB-serving API pod."""
    from core.config import data_quality as _dq_cfg
    if not _dq_cfg.enabled:
        logger.info("[daemon_registry] data_quality disabled by config — "
                    "scheduled loop not registered")
        return True
    if ctx.scheduler is None:
        return False
    from core.data_quality_engine import set_dq_engine_dependencies
    set_dq_engine_dependencies(
        db_manager=ctx.db_manager,
        connection_manager=ctx.connection_manager,
        cfg=_dq_cfg,
    )

    def _dq_tick() -> None:
        # 2026-09-06 — THE PAUSE READ THE WRONG DAEMON'S NAME.
        #
        # This tick registers, lists and is controlled as ``dq_scheduled_loop``
        # (that is the name in SCHEDULER_OWNED and the one
        # register_remote_placeholders publishes to the admin UI).  It asked
        # ``is_paused("dq_monitor")``.  Verified on a worker-shaped process:
        # ``dq_scheduled_loop`` is registered, ``dq_monitor`` is NOT, and
        # ``pause("dq_monitor")`` raises KeyError there.  So the check could
        # only ever answer False and DQ rules kept executing straight through
        # an admin Pause.
        #
        # ``dq_monitor`` is a REAL but DIFFERENT daemon — the Phase-120 agents
        # DQ monitor, registered on the API pod (main.py).  Reading it here
        # also meant pausing that agent silently stopped scheduled RULE
        # EXECUTION on the scheduler pod: two daemons, one flag, and neither
        # one spelled the way it is declared.
        try:
            from core.background_jobs import is_paused
            if is_paused("dq_scheduled_loop"):
                return {"status": "skipped", "reason": "paused by admin"}
        except Exception as exc:
            logger.debug("dq pause check unavailable (running): %s", exc)
        from core.data_quality_engine import run_all_enabled
        results = run_all_enabled()
        failures = [r for r in results if not r.get("passed")]
        if failures:
            logger.warning("DQ check: %d/%d rules failed",
                           len(failures), len(results))
        elif results:
            logger.info("DQ check: all %d rules passed", len(results))
        # 2026-10-07 -- the background-job ledger reads these counts.
        return {"rules": len(results), "failed": len(failures)}

    interval = max(int(getattr(_dq_cfg, "schedule_interval_minutes", 60))
                   * 60, 60)
    ctx.scheduler.add_job(
        _dq_tick, "interval", seconds=interval, id="dq_scheduled_run",
        replace_existing=True, max_instances=1, coalesce=True,
    )
    return True


def _reg_sla_scanner(ctx: DaemonContext) -> bool:
    """Phase 132.25 DataFlow mid-flight SLA scanner — ORPHAN until
    2026-08-20.  The async start() loop is just a poll wrapper around the
    sync _scan_once, so on this pod it becomes an ordinary interval job.
    Notification fire degrades gracefully when the notification engine is
    not wired (flag still lands; that is the correctness half)."""
    if ctx.scheduler is None:
        return False
    from core.config import get as _cfg_get
    poll = max(15, int(_cfg_get("dataflows", "sla_scan_seconds", 60) or 60))
    from core.dataflow.sla_scanner import init_sla_scanner
    scanner = init_sla_scanner(ctx.db_manager, poll_seconds=poll)
    ctx.scheduler.add_job(
        scanner._scan_once, "interval", seconds=poll, id="dataflow_sla_scan",
        replace_existing=True, max_instances=1, coalesce=True,
    )
    return True


def _worker_holds_singleton_role() -> bool:
    """THE single-runner predicate: does this process hold the APScheduler
    lock?  Used per tick by the DataFlow poll loop, the DuckDB mirror
    writer and the spark reconciler on the worker, and at start by
    :func:`start_when_singleton` on EVERY entry point.

    2026-09-28 -- THE LEASE IS NO LONGER CONSULTED, and the reason is a
    measurement.  This used to honour a live SchedulerLease first and fall
    back to the lock.  But the two elections have DIFFERENT electorates:
    the lease (BF-410.4) is taken only by ``main.py`` processes, the lock
    (Phase 83C, ``core.scheduler.init_scheduler``) by every process that
    boots a scheduler -- ``main.py`` AND ``scheduler_worker.py``.  On the
    Docker rig (a hybrid api container beside a scheduler container) the
    hybrid held the lease UNCONTESTED, the scheduler pod held the lock, both
    answered "leader", and the Netcool sender ran twice: six heartbeats per
    60 s on a 20 s interval, in pairs 3 s apart, and two drainers polling the
    same ``pending_notifications`` rows.  A predicate with two rungs whose
    electorates differ is two predicates.

    The lock is the one election every scheduler-booting process joins, and
    APScheduler itself runs only in the holder, so "holds the lock" is
    already what ``_this_process_runs_apscheduler`` answers for the five
    per-tick jobs fixed on 2026-09-27.  ONE answer, read from ONE place.
    ``_scheduler_worker_id`` is set on acquire, None on loss/never, and flips
    live when the 2026-08-03 lock retry wins -- which is what the deferral
    watcher below waits for.  On the scheduler worker (which never takes a
    lease) the answer is unchanged."""
    from core.scheduler import _this_process_runs_apscheduler
    return _this_process_runs_apscheduler()


#: Singletons whose start was DEFERRED because this process does not hold the
#: single-runner role yet, drained by the watcher below if it ever does.
#: (name, start_fn, ctx, record_started)
_DEFERRED_SINGLETONS: List[Any] = []
_deferred_lock = threading.Lock()
_deferred_watcher: Any = None

#: The daemons that must run in exactly ONE process fleet-wide.  Every one
#: of them starts through :func:`start_when_singleton` -- on the scheduler
#: pod via its SCHEDULER_OWNED entry, on a hybrid pod via main.py's
#: ``_start_singleton`` -- and through nothing else.  Named here so a guard
#: (tests/test_hybrid_singletons_share_the_gate_2026_09_28.py) can walk
#: main.py's start sites for exactly these names.
SINGLETON_DAEMONS = frozenset({
    "iceberg_metadata_sync",
    "iceberg_manifest_watcher",
    "feed_sla_watcher",
    "feed_kafka_arrivals",
    "feed_netcool_sender",
    "kafka_cache_consumer",
    "custom_jobs_scheduler",
    "prewarm_background",
    "etl_pipelines",
})

#: What the gate DID for each singleton in this process: "started",
#: "declined" (the starter returned False -- transport 'none', feature off)
#: or "deferred".  Read by :func:`register_scheduler_owned` so the blanket
#: "registered at boot" heartbeat record never overwrites the gate's own,
#: more precise, report (a deferred singleton reported as running from a
#: non-leader would make the Effective Posture card say "running on more
#: than one pod" for a daemon running on exactly one).
_SINGLETON_OUTCOMES: Dict[str, str] = {}

DEFERRED_HOW = ("deferred -- this process does not hold the scheduler lock, "
                "so the singleton is NOT running here (it starts here if "
                "the lock is won later)")
STARTED_HOW = "started by the singleton gate in the scheduler-lock holder"
DECLINED_HOW = ("the scheduler-lock holder invoked it and it declined to "
                "start (see its own log line for the reason)")


def _report_singleton(name: str, outcome: str) -> None:
    """Put the gate's decision in this pod's heartbeat, first-hand.

    A hybrid pod and the scheduler pod report through the same three words,
    so the Effective Posture card (read on ANY pod) sees one ``running``
    report for a singleton and a ``deferred`` one from every other process
    -- never two runners, never silence.  Advisory: a heartbeat that could
    fail a daemon start would be worse than none.
    """
    _SINGLETON_OUTCOMES[name] = outcome
    how = {"started": STARTED_HOW, "declined": DECLINED_HOW}.get(
        outcome, DEFERRED_HOW)
    try:
        from core import background_jobs as _bj
        _bj.record_boot_registrations(
            [name], how, running=(outcome == "started"),
            status=("registered" if outcome == "started" else outcome))
    except Exception as exc:                       # noqa: BLE001
        logger.debug("[daemon_registry] heartbeat record for %s failed: %s",
                     name, exc)


def _deferred_recheck_seconds() -> float:
    """How often to re-ask whether this process has become the single runner.

    Tied to the scheduler's own lock-retry cadence: there is no point checking
    faster than the thing that changes the answer.
    """
    try:
        from core.config import get as _cfg_get
        return max(5.0, float(_cfg_get("scheduler", "lock_retry_seconds", 20) or 20))
    except Exception:
        return 20.0


#: How long a late start dispatched onto the process's event loop may take
#: before the drain gives up waiting for its verdict.  A starter does no I/O
#: of its own (it spawns a thread or creates a task); this bounds a wedged
#: loop, not a slow start.
LATE_START_TIMEOUT_S = 30.0


def _on_loop_thread(loop: Any) -> bool:
    """True when the calling thread IS the one running ``loop``."""
    try:
        import asyncio
        return asyncio.get_running_loop() is loop
    except RuntimeError:
        return False


def _call_on_loop(ctx: DaemonContext, fn: Callable[[], Any]) -> Any:
    """Run a daemon's starter where its loop is, and return what it returned.

    2026-09-28 -- found live on the Docker rig after a rolling deploy: the
    new scheduler pod won the lock minutes after boot and the deferral
    watcher THREAD ran every deferred starter.  The thread-shaped daemons
    (Netcool sender, SLA watcher, Kafka arrivals) came up; the ASYNC ones did
    not.  ``iceberg_manifest_watcher.start_background`` asks
    ``asyncio.get_event_loop()`` -- on a plain thread that raises, it built a
    NEW loop nothing runs and ``create_task``'d onto it; the metadata sync
    registered a ``background_jobs`` entry that the boot-time
    ``autostart_all`` had already passed by.  Both sat ``status=stopped,
    running=false`` in ``daemon_heartbeat`` with the lock held here.

    A starter therefore runs ON ``ctx.loop`` (``run_coroutine_threadsafe``,
    the result awaited from the calling thread) whenever there is one and we
    are not already on its thread; with no loop (a bare test context) it
    runs inline, as before.  A late start is not complete until the
    ``background_jobs`` entries it registered are actually started, so the
    caller follows a successful drain with :func:`_autostart_new_jobs`.
    """
    loop = getattr(ctx, "loop", None)
    if loop is None or _on_loop_thread(loop):
        return fn()
    import asyncio

    async def _run():
        return fn()

    fut = asyncio.run_coroutine_threadsafe(_run(), loop)
    return fut.result(timeout=LATE_START_TIMEOUT_S)


def _autostart_new_jobs(ctx: DaemonContext) -> int:
    """Start the ``background_jobs`` entries a late start registered.

    At boot the entry points call ``background_jobs.autostart_all()`` AFTER
    every registration; a daemon that registers its entry later (a deferred
    singleton started on a lock win) has missed that call and would stay
    registered-but-stopped forever.  ``autostart_all`` is idempotent -- it
    skips running, paused and non-autostart entries -- and needs the loop it
    creates tasks on, so it runs there.  Returns how many it started.
    """
    from core import background_jobs as _bj
    loop = getattr(ctx, "loop", None)
    if loop is None:
        # A bare context has no loop to start tasks on; autostart_all would
        # log "no running loop" and return 0.  Nothing to do.
        return 0
    if _on_loop_thread(loop):
        return int(_bj.autostart_all() or 0)
    import asyncio

    async def _run():
        return int(_bj.autostart_all() or 0)

    return int(asyncio.run_coroutine_threadsafe(_run(), loop)
               .result(timeout=LATE_START_TIMEOUT_S) or 0)


def _drain_deferred_singletons() -> List[str]:
    """Start every deferred singleton, if this process now holds the role.

    Returns the names actually started.  Each entry is guarded on its own: one
    daemon's failure to start must not strand the others, which is the same
    contract ``register_scheduler_owned`` already keeps.  Each starter runs
    on its context's event loop (see :func:`_call_on_loop`), and the
    ``background_jobs`` entries the late starts registered are then
    autostarted on that loop -- so an async service really runs, not merely
    "was registered".
    """
    if not _worker_holds_singleton_role():
        return []
    with _deferred_lock:
        pending = list(_DEFERRED_SINGLETONS)
        _DEFERRED_SINGLETONS.clear()
    started: List[str] = []
    contexts: List[DaemonContext] = []
    for name, start_fn, ctx, record in pending:
        try:
            ok = _call_on_loop(ctx, start_fn)
            if record and ok is not False:
                ctx.started.append(name)
            started.append(name)
            if ctx not in contexts:
                contexts.append(ctx)
            _report_singleton(name, "declined" if ok is False else "started")
            logger.warning(
                "[daemon_registry] %s STARTED LATE — this process won the "
                "scheduler lock after boot, so the deferred singleton is now "
                "running here", name)
        except Exception as exc:
            logger.warning(
                "[daemon_registry] deferred singleton %s failed to start "
                "(non-fatal — others still start): %s", name, exc)
    for ctx in contexts:
        try:
            n = _autostart_new_jobs(ctx)
            if n:
                logger.info("[daemon_registry] late start: %d background_jobs "
                            "entr%s autostarted on the event loop", n,
                            "y" if n == 1 else "ies")
        except Exception as exc:                      # noqa: BLE001
            logger.warning("[daemon_registry] late start: background_jobs "
                           "autostart on the loop failed (entries stay "
                           "registered but NOT running): %s", exc)
    return started


#: Whether the "drain when APScheduler starts here" hook has been handed to
#: ``core.scheduler`` in this process.  One hook, queued at the first
#: deferral; ``_fire_started_hooks`` runs it once on the start that wins.
_drain_hook_queued = False


def _queue_drain_on_scheduler_start() -> None:
    """Hand the drain to the ONE event that changes the predicate's answer.

    The deferral watcher thread polls the predicate every lock-retry
    interval; this makes the lock-retry START itself drain the deferrals the
    moment it happens (``core.scheduler.on_apscheduler_started``), on the
    retry thread, with each starter dispatched onto the loop.  The watcher
    stays as the fallback poll; both call the same idempotent drain.
    """
    global _drain_hook_queued
    if _drain_hook_queued:
        return
    try:
        from core.scheduler import on_apscheduler_started
    except Exception as exc:                          # noqa: BLE001
        logger.debug("[daemon_registry] scheduler start hook unavailable "
                     "(the watcher thread still drains): %s", exc)
        return
    _drain_hook_queued = True

    def _drain_on_start() -> None:
        global _drain_hook_queued
        _drain_hook_queued = False
        _drain_deferred_singletons()
    _drain_on_start.__name__ = "drain_deferred_singletons_on_scheduler_start"
    on_apscheduler_started(_drain_on_start)


def drain_deferred_singletons() -> List[str]:
    """Start the deferred singletons NOW if this process holds the lock.

    For an entry point that wins the scheduler lock AFTER its daemon starts
    ran -- main.py's hybrid boot acquires the lock in a later background
    thread -- so the leader does not wait a lock-retry interval for the
    watcher thread to notice.  Idempotent; returns the names started.
    """
    return _drain_deferred_singletons()


def discard_deferred_for_loop(loop: Any) -> List[str]:
    """Forget the deferred singletons whose context runs on ``loop``.

    2026-10-04 -- for an app LIFESPAN shutdown (main.py's ``_shutdown``).  A
    deferral holds its context, and the hybrid context holds the lifespan's
    event loop; left in the list after that loop has closed, the next drain
    -- a later lifespan in the same process winning the lock, or the watcher
    -- ran the dead lifespan's starters and each failed with "Event loop is
    closed" (every test file that started the app logged eight of them).  A
    shutdown takes back the starts it deferred; another lifespan's (or the
    scheduler worker's) entries are untouched.  Returns the names dropped.
    """
    if loop is None:
        return []
    with _deferred_lock:
        keep = [e for e in _DEFERRED_SINGLETONS
                if getattr(e[2], "loop", None) is not loop]
        gone = [e[0] for e in _DEFERRED_SINGLETONS
                if getattr(e[2], "loop", None) is loop]
        _DEFERRED_SINGLETONS[:] = keep
    if gone:
        logger.info("[daemon_registry] lifespan shutdown: %d deferred "
                    "singleton start(s) withdrawn: %s", len(gone),
                    ", ".join(sorted(gone)))
    return gone


def _ensure_deferred_watcher() -> None:
    """One watcher thread per process, started lazily on the first deferral.

    It deliberately does NOT use ``ctx.scheduler``: a process that is not the
    single runner has no APScheduler running (``init_scheduler`` returns early
    when the lock is held elsewhere), so a job registered there would never
    tick and the deferral would be a permanent deletion — the exact failure
    this registry exists to prevent.  ``core.scheduler._start_lock_retry``
    keeps re-attempting the lock in the background, so leadership really can
    arrive later and this thread is what notices.
    """
    global _deferred_watcher
    if _deferred_watcher is not None and _deferred_watcher.is_alive():
        return

    def _loop() -> None:
        interval = _deferred_recheck_seconds()
        while True:
            time.sleep(interval)
            with _deferred_lock:
                if not _DEFERRED_SINGLETONS:
                    return
            try:
                if _drain_deferred_singletons():
                    return
            except Exception as exc:      # pragma: no cover - defensive
                logger.debug("deferred-singleton watcher tick failed: %s", exc)

    _deferred_watcher = threading.Thread(
        target=_loop, name="deferred-singleton-watcher", daemon=True)
    _deferred_watcher.start()


def start_when_singleton(ctx: DaemonContext, name: str,
                         start_fn: Callable[[], Any], *,
                         record_started: bool = True) -> bool:
    """Start a SINGLETON daemon only where this process is the single runner.

    2026-09-23.  Nine daemons on this pod are single-instance by nature — the
    iceberg metadata sync and manifest watcher, the feed SLA watcher, the
    Netcool sender, both Kafka consumers, the custom-jobs scheduler, the
    prewarm service and the ETL pipeline loop.  Their singleton-ness was
    enforced entirely by ``replicas: 1`` in one Helm values file and by nothing
    in the code, so any second host — a hybrid pod, a rolling restart without
    ``Recreate``, or the local rig's ``workers`` profile alongside a hybrid api
    — silently doubled SLA alerts, Netcool posts, Kafka consumption and
    iceberg metadata syncs.  The last of those is how the 2026-08-24 metadata
    LIST storms happened.

    2026-09-28 -- THE ONE GATE FOR BOTH ENTRY POINTS.  Until today only the
    scheduler pod's registrations came through here; ``main.py`` started the
    same nine on a hybrid/worker pod behind ``pod_role.should_run`` alone,
    which asks "may this KIND of pod run daemons?" and never "is this the
    ONE process?".  Measured on the rig with a hybrid api container beside a
    scheduler container: both ran the Netcool sender.  main.py now calls this
    function (``_start_singleton``) with the same names, so there is exactly
    one predicate (:func:`_worker_holds_singleton_role`) and one deferral
    list, and a guard walks main.py's start sites for the names in
    :data:`SINGLETON_DAEMONS`.

    A non-leader does NOT lose the capability — it DEFERS it and keeps
    checking, because ``core.scheduler`` retries the lock until it wins and a
    registration-time refusal would turn "not now" into "never".  The deferral
    logs at WARNING: a daemon that is not running here has to be
    distinguishable from one that is, and from one an admin disabled.  Both
    decisions land in this pod's heartbeat (:func:`_report_singleton`) so the
    Effective Posture card shows ONE runner and N deferrals, never N runners.
    """
    if _worker_holds_singleton_role():
        ok = start_fn()
        if record_started and ok is not False:
            ctx.started.append(name)
        _report_singleton(name, "declined" if ok is False else "started")
        return True
    with _deferred_lock:
        _DEFERRED_SINGLETONS.append((name, start_fn, ctx, record_started))
    _queue_drain_on_scheduler_start()
    _ensure_deferred_watcher()
    _report_singleton(name, "deferred")
    logger.warning(
        "[daemon_registry] %s DEFERRED — this process does not hold the "
        "single-runner role (the APScheduler lock is held elsewhere or not "
        "yet), so the daemon is NOT running here. It is not deleted: the "
        "scheduler retries the lock every %.0fs and this singleton starts if "
        "that succeeds. Exactly one process should run it.",
        name, _deferred_recheck_seconds())
    return True


#: The pre-2026-09-28 spelling; the tests written against it still hold.
_start_when_singleton = start_when_singleton


def _reg_dataflow_scheduler(ctx: DaemonContext) -> bool:
    """Phase 132 native DataFlow schedule poll loop — the LAST 2026-08-20
    orphan, ported same day: with QS_POD_ROLE=api the autostart was forced
    off and no pod ran init_workflow_subsystem's scheduler, so native
    DataFlow schedules fired NOWHERE (Airflow-backed dataflows unaffected).

    Semantics preserved from main.py: ``dataflows.scheduler_autostart``
    (default false) is the admin opt-in — false means "feature off" and IS
    an ownership decision (the _reg_etl_pipelines precedent).  Dependencies
    are passed EXPLICITLY (db from ctx, broadcast_fn=None — no websocket on
    this pod; run events still land in the DB and the notification engine
    wired by wire_scheduled_execution_deps).  ``ctx.scheduler is None``
    means this worker replica did NOT win the APScheduler lock — a second
    poll loop must not start there."""
    from core.config import get as _cfg_get
    autostart = bool(_cfg_get("dataflows", "scheduler_autostart", False))
    if not autostart:
        logger.info("[daemon_registry] dataflows.scheduler_autostart is off "
                    "— DataFlow poll loop not started (admin opt-in)")
        return True
    if ctx.scheduler is None:
        # another worker replica holds the singleton role (or APScheduler
        # init failed) — starting the loop here would double-fire schedules.
        return False
    poll = max(5, int(_cfg_get("dataflows", "scheduler_poll_seconds", 30)
                      or 30))
    max_conc = max(1, int(_cfg_get("dataflows", "max_concurrent_runs", 8)
                          or 8))
    from core.dataflow import init_workflow_subsystem
    subsys = init_workflow_subsystem(
        db_manager=ctx.db_manager,
        broadcast_fn=None,
        poll_seconds=poll,
        max_concurrent_runs=max_conc,
        is_leader_fn=_worker_holds_singleton_role,
        auto_start_scheduler=True,
    )
    return start_service(ctx, "dataflow_scheduler_autostart",
                         subsys["scheduler"].start) is not None


def _reg_spark_k8s_reconciler(ctx: DaemonContext) -> bool:
    """2026-08-22 — the spark_k8s job supervisor.  A service loop (not a
    cron job) that self-gates every iteration on (a) spark_k8s.enabled,
    (b) the scheduler lease (exactly one pod reconciles — the SAME
    election every singleton duty uses), (c) the availability ladder.
    ``start_reconciler`` returning False because the feature is disabled
    is still an OWNERSHIP decision — this pod looked and declined."""
    # 2026-09-06 — THIS GATE WAS FALSE FOREVER ON THE POD THAT OWNS IT.
    #
    # ``is_scheduler_leader`` reads the BF-410.4 SchedulerLease, and
    # ``scheduler_worker.py`` NEVER ACQUIRES IT — verified: the only
    # acquisition in the product is main.py's, and the worker file contains
    # no lease reference at all.  ``_worker_holds_singleton_role`` was
    # written for exactly this (see its docstring, and the DataFlow poll
    # loop that already uses it); the spark_k8s entry was simply not
    # converted.  The reconciler loop would have spun on
    # ``if not is_leader_fn(): wait; continue`` and supervised nothing —
    # latent only because ``spark_k8s.enabled`` ships false, i.e. flipping
    # the feature on would have looked like a broken reconciler.
    from core.spark_k8s.reconciler import start_reconciler
    start_reconciler(
        ctx.db_manager,
        is_leader_fn=_worker_holds_singleton_role,
    )
    return True


def _reg_brain_daemon(mod_path: str, fn_name: str,
                      name: str) -> Callable[[DaemonContext], bool]:
    """The classic ``register_*(scheduler, db_manager)`` brain-daemon shape
    (mirrors, prefetch, alerts, coordinator, prewarmer, output gateway,
    parquet sync) — carried unchanged from the worker's old hand list."""
    def _reg(ctx: DaemonContext) -> bool:
        if ctx.scheduler is None:
            return False
        mod = __import__(mod_path, fromlist=[fn_name])
        getattr(mod, fn_name)(ctx.scheduler, ctx.db_manager)
        return True
    _reg.__name__ = f"_reg_{name}"
    # 2026-09-06 — the registration TARGET, machine-readable.  The closure
    # test can now ask "which (module, function) does this table own?" and
    # compare that against the daemon registrations main.py makes inline, so
    # a job added to main.py's apscheduler block and forgotten here fails the
    # build instead of silently running on no pod in a split deployment.
    _reg.owns = (mod_path, fn_name)                       # type: ignore[attr-defined]
    return _reg


# ─────────────────────────────────────────────────────────────────────────────
# THE TABLES
# ─────────────────────────────────────────────────────────────────────────────

#: gate name (exactly what main.py passes to should_run/_daemon_allowed)
#: -> registration executed by the scheduler pod.
SCHEDULER_OWNED: Dict[str, Callable[[DaemonContext], bool]] = {
    # scheduler core
    "apscheduler_embedded": _reg_apscheduler_core,
    # retention sweeps (core/retention_daemons.py)
    "etl_cleanup": _reg_retention("etl_cleanup"),
    "feed_cleanup": _reg_retention("feed_cleanup"),
    "dq_cleanup": _reg_retention("dq_cleanup"),
    "agent_log_cleanup": _reg_retention("agent_log_cleanup"),
    "pv_cleanup": _reg_retention("pv_cleanup"),
    # 2026-09-15 — row_security_audit and delivery_history both had a
    # declared retention and no sweep.  A name in retention_daemons.JOB_IDS
    # that is absent HERE runs nowhere (the API pod declines it and nobody
    # claims it), which is the exact failure this registry was created to
    # stop -- and the guard in
    # tests/test_pod_role_honours_scheduler_mode_2026_08_19.py caught the
    # omission when these two were added upstream.
    "rls_audit_cleanup": _reg_retention("rls_audit_cleanup"),
    "delivery_history_cleanup": _reg_retention("delivery_history_cleanup"),
    "query_log_cleanup": _reg_retention("query_log_cleanup"),
    # 2026-09-27 -- the daily close-out digest (core/feed/close_out_digest.py)
    # rides the retention group's registration: one tick job, idempotent
    # per (group, business date) through a DB marker.
    "feed_close_out_digest": _reg_retention("feed_close_out_digest"),
    # 2026-09-28 -- the feed CONSUMER late watcher (core/feed/consumer_
    # notices.py) rides the same registration: one tick job, idempotent
    # per (feed, business date, subscriber) through the notice ledger.
    "feed_consumer_late_watch": _reg_retention("feed_consumer_late_watch"),
    # 2026-10-03 -- the shared rate limiter's finished windows
    # (core/rate_limiter.py::sweep_expired_windows), hourly.
    "rate_limit_window_cleanup": _reg_retention("rate_limit_window_cleanup"),
    # 2026-10-07 -- the FILE arrival watcher (core/feed/file_arrival_source.
    # py): the producer the ``file`` dependency kind never had.  Rides the
    # retention group's registration: one tick job, single-runner per tick.
    "feed_dependency_file_watch": _reg_retention("feed_dependency_file_watch"),
    # 2026-10-11 -- the ORACLE-TABLE arrival watcher (core/feed/
    # oracle_table_source.py): the producer of the ``oracle_table`` kind.
    # Rides the retention group's registration: one tick job, single runner.
    "feed_dependency_oracle_table_watch": _reg_retention("feed_dependency_oracle_table_watch"),
    "feed_template_requests": _reg_retention("feed_template_requests"),
    # 2026-09-15 — row_security.lake_formation_sync_interval_hours declared a
    # cadence and no daemon read it: the ONLY caller of sync_connection was
    # the admin's manual button, so imported access-control policies drifted
    # from Lake Formation silently and indefinitely.  The tick no-ops while
    # lake_formation_sync_enabled is false (it ships false), so registering
    # it unconditionally keeps "is it registered" and "is it enabled" as two
    # separate questions.
    "lake_formation_sync": _reg_brain_daemon(
        "core.row_security.lake_formation_daemon",
        "register_lake_formation_daemon", "lake_formation_sync"),
    # singleton services previously inline in scheduler_worker.py
    "iceberg_metadata_sync": _reg_iceberg_metadata_sync,
    "iceberg_manifest_watcher": _reg_iceberg_manifest_watcher,
    "brain_duckdb_mirror": _reg_brain_duckdb_mirror,
    "kafka_cache_consumer": _reg_kafka_cache_consumer,
    # the six 2026-08-20 orphans
    "custom_jobs_scheduler": _reg_custom_jobs,
    "prewarm_background": _reg_prewarm_background,
    "etl_pipelines": _reg_etl_pipelines,
    "dq_scheduled_loop": _reg_dq_scheduled_loop,
    "sla_scanner": _reg_sla_scanner,
    # the last orphan, ported 2026-08-20 (same day, second round)
    "dataflow_scheduler_autostart": _reg_dataflow_scheduler,
    # 2026-09-02 — the feed platform's two new singletons.  Registered
    # HERE and not only gated in main.py: a gate with no owner means the
    # capability runs on NO pod, which is the 2026-08-20 orphan class
    # this table exists to make impossible.
    "feed_sla_watcher": _reg_feed_sla_watcher,
    "feed_kafka_arrivals": _reg_feed_kafka_arrivals,
    "feed_netcool_sender": _reg_feed_netcool_sender,
    # 2026-08-22 — QueryStudio-owned Spark-on-K8s job supervisor
    "spark_k8s_reconciler": _reg_spark_k8s_reconciler,
    # brain daemons previously in the worker's hand-written _daemons list.
    # Not main.py gate names (main registers them behind the
    # apscheduler_embedded gate), but they live in the SAME table so exactly
    # one boot list exists.
    "iceberg_mirror_daemon": _reg_brain_daemon(
        "core.iceberg_mirror", "register_mirror_daemon",
        "iceberg_mirror_daemon"),
    "plain_parquet_mirror_daemon": _reg_brain_daemon(
        "core.plain_parquet_mirror", "register_mirror_daemon",
        "plain_parquet_mirror_daemon"),
    # 2026-09-26 (F4b) -- the bloom-sidecar BOOTSTRAP owner for every
    # Iceberg/parquet table that is not a landing dataset.  Input: equality
    # / IN filters in query_pruning_history (written per query by
    # iceberg_reader since 60d6bf85), >= 3 hits in the lookback, benefit-
    # ranked; every tick carries status ok / no_input / unreadable.  The
    # MAINTAINER after a snapshot roll is brain_freshness.ensure_fresh via
    # register_snapshot_change_reactions (same pod).  A landing dataset
    # owns its own bloom and registers its tables through
    # query_history_prefetcher.register_owned_elsewhere_resolver.
    "adaptive_prefetch": _reg_brain_daemon(
        "core.query_history_prefetcher", "init_prefetch_scheduler",
        "adaptive_prefetch"),
    "pruning_alerts_daemon": _reg_brain_daemon(
        "core.pruning_alerts", "register_alerts_daemon",
        "pruning_alerts_daemon"),
    "brain_coordinator_daemon": _reg_brain_daemon(
        "core.brain_coordinator", "register_coordinator_daemon",
        "brain_coordinator_daemon"),
    "portal_cred_prewarmer": _reg_brain_daemon(
        "core.portal_cred_prewarmer", "register_prewarmer_daemon",
        "portal_cred_prewarmer"),
    "output_gateway_cleanup": _reg_brain_daemon(
        "core.output_gateway", "register_output_gateway_daemon",
        "output_gateway_cleanup"),
    "plain_parquet_sync": _reg_brain_daemon(
        "core.plain_parquet_metadata_sync", "register_parquet_sync_daemon",
        "plain_parquet_sync"),
    # 2026-09-06 — THREE MORE "OWNED NOWHERE", FOUND BY DIFFING TWO REAL BOOTS.
    #
    # This table closes over GATE NAMES: the closure test walks main.py for
    # ``should_run("x")`` and proves an owner exists for each x.  These three
    # were registered INLINE inside main.py's ``apscheduler_embedded`` block
    # and never had a gate name of their own, so they were invisible to both
    # the closure test AND the runtime DAEMON-ORPHAN alarm — the alarm only
    # fires on a name that reaches ``should_run``.
    #
    # Booting main.py (hybrid) and scheduler_worker.py and DIFFING the
    # resulting APScheduler job ids shows them plainly: __reconciliation_check__,
    # brain_cleanup_daemon and writer_advisor_shadow_auto_apply exist on the
    # hybrid pod and on NO pod once ``QS_POD_ROLE=api`` turns that block off.
    # Consequences: reconciliation checks stop running, the brain tables
    # (brain_pruning_memo / brain_route_outcome) grow without bound, and the
    # writer-advisor shadow never auto-applies.
    #
    # The lesson for the table: "every gate name is owned" was never the same
    # claim as "every scheduled job is owned".  The new job-id diff test in
    # tests/test_daemon_fleet_reality_2026_09_06.py closes over the JOBS.
    "reconciliation_scheduler": _reg_brain_daemon(
        "core.reconciliation_scheduler", "init_reconciliation_scheduler",
        "reconciliation_scheduler"),
    "brain_cleanup_daemon": _reg_brain_daemon(
        "core.brain_cleanup_daemon", "register_cleanup_daemon",
        "brain_cleanup_daemon"),
    "writer_advisor_shadow_auto_apply": _reg_brain_daemon(
        "core.writer_advisor", "register_shadow_auto_apply_daemon",
        "writer_advisor_shadow_auto_apply"),
    # 2026-09-10 -- the Clockwork alert NOTIFIER: the one consumer of
    # ``clockwork_alerts``.  Owned HERE (scheduler pod) and registered in
    # main.py's apscheduler_embedded block (hybrid) -- the 2026-09-01
    # incident was a mechanism designed, documented and missing one call.
    "clockwork_alert_notifier": _reg_brain_daemon(
        "core.clockwork.notifier", "register_notifier_daemon",
        "clockwork_alert_notifier"),
}

#: gate name -> the reason it deliberately runs with the HTTP app.
API_OWNED: Dict[str, str] = {}

#: 2026-09-28 -- daemons that run on EVERY pod by design, with the reason.
#: The Effective Posture card does not call these "running on more than one
#: pod" (a false alarm on any deployment with 2+ API pods); everything else
#: seen on two pods is a double run and warns.
PER_POD_DAEMONS: Dict[str, str] = {
    "portal_cred_prewarmer": "warms core.aws_portal_auth._cred_cache, a MODULE "
                             "GLOBAL: each query-serving process needs its own "
                             "(main.py api branch starts a local warm task)",
}

#: gate name -> honest debt: gated somewhere, owned nowhere YET.  Every
#: entry here is alarmed at runtime (DAEMON-ORPHAN in the api-pod log) and
#: pinned by the closure test, which fails if this dict GROWS.
KNOWN_ORPHANS: Dict[str, str] = {
    # EMPTY as of 2026-08-20 (second round): dataflow_scheduler_autostart —
    # the last orphan — moved to SCHEDULER_OWNED (_reg_dataflow_scheduler).
    # Every gated daemon now has an explicit owner.  Adding an entry here is
    # declaring a capability that runs on NO pod: only do it with a dated
    # reason and a plan, and the frozen-orphan test will make you say so.
}


#: gate name -> the SCHEDULER_OWNED daemon that does this work instead.
#:
#: 2026-09-06.  Not every ``should_run()`` call site is a daemon START.  Some
#: use the role gate as a "may this pod do heavy work?" predicate for a
#: per-request decision, and refusing there deletes nothing: a declared owner
#: already does the same work on its own schedule.
#:
#: ``sentinel_table_resync`` is the case that surfaced this.  It gates a
#: single-table iceberg reconcile fired from the completeness sentinel on the
#: QUERY path; its own comment says "on an API pod the scheduled/worker
#: metadata-sync loop reconciles this table instead".  But the name was in no
#: table, so every declined resync logged
#:
#:     ERROR DAEMON-ORPHAN: 'sentinel_table_resync' ... this work will run
#:     NOWHERE
#:
#: at query cadence on every API pod — a false alarm on the one alarm that
#: exists to catch real orphans, which is how an alarm stops being read.
#: Verified by execution under ``QS_POD_ROLE=api``.
#:
#: An entry here is a CLAIM that the named owner covers the work.  The value
#: must be a key of SCHEDULER_OWNED; the closure test enforces that, so this
#: cannot become a place to make an orphan disappear by asserting it.
DELEGATED_TO: Dict[str, str] = {
    "sentinel_table_resync": "iceberg_metadata_sync",
}


def is_owned_somewhere(daemon_name: str) -> bool:
    """True when SOME pod explicitly owns (or explicitly defers) the daemon.

    Consulted by core.pod_role.should_run before answering False, so gating
    an unowned daemon shows up as a DAEMON-ORPHAN error instead of a silent
    deletion of the work.
    """
    return (daemon_name in SCHEDULER_OWNED
            or daemon_name in API_OWNED
            or daemon_name in DELEGATED_TO
            or daemon_name in KNOWN_ORPHANS)


def register_scheduler_owned(ctx: DaemonContext) -> Dict[str, Any]:
    """Execute every SCHEDULER_OWNED registration.  The scheduler pod's
    entire daemon boot list — scheduler_worker.py consumes this and nothing
    else, so the table and the boot behaviour cannot drift.

    Each entry individually guarded: one daemon's failure never blocks the
    rest (the old worker list's contract, kept).  Returns
    {name: True | False | "failed: ..."} for logs and tests.
    """
    results = _run_registrations(ctx, SCHEDULER_OWNED.keys())
    # 2026-09-28 -- THE ROLLING-DEPLOY CASE.  With the scheduler lock held by
    # the previous pod (its heartbeat still fresh), ``ctx.scheduler`` is
    # None here and every APScheduler-dependent registration answers False.
    # The lock retry wins minutes later and used to leave those as they
    # were: a pod holding the lock with no retention sweeps, no close-out
    # digest, no DQ loop, no SLA scanner.  "Not now" must not be "never":
    # the ones that need APScheduler are handed to the scheduler's own
    # started-hook and registered when THIS process starts it.
    if ctx.scheduler is None:
        _queue_late_registrations(
            ctx, [n for n, ok in results.items() if ok is False])
    # 2026-09-27 -- put what registered in this pod's heartbeat, so the
    # admin Effective Posture card (read on ANY pod) sees it.  The
    # singletons are NOT in this blanket record (2026-09-28): the gate
    # already reported each one as started / declined / deferred, and
    # "registered" from a non-leader replica would read as a second runner.
    try:
        from core import background_jobs as _bj
        _bj.record_boot_registrations(
            [n for n, ok in results.items()
             if ok is True and n not in _SINGLETON_OUTCOMES],
            "registered at boot by daemon_registry.register_scheduler_owned")
    except Exception as exc:  # advisory -- never costs the boot
        logger.warning("[daemon_registry] boot registrations not recorded "
                       "for the heartbeat: %s", exc)
    return results


def _run_registrations(ctx: DaemonContext, names) -> Dict[str, Any]:
    """Execute the named SCHEDULER_OWNED registrations, each guarded on its
    own, and say per name what happened: registered, not registered because
    APScheduler is not running here YET (it will be retried on the start),
    or not registered for a prerequisite that is genuinely missing."""
    results: Dict[str, Any] = {}
    for name in names:
        reg = SCHEDULER_OWNED[name]
        try:
            results[name] = bool(reg(ctx))
            if results[name]:
                logger.info("[daemon_registry] registered %s on the "
                            "scheduler pod", name)
            elif ctx.scheduler is None:
                logger.warning(
                    "[daemon_registry] %s NOT registered yet -- it needs "
                    "APScheduler, which this process is not running (the "
                    "scheduler lock is held elsewhere); it will register "
                    "when this process wins the scheduler lock", name)
            else:
                logger.warning("[daemon_registry] %s NOT registered "
                               "(missing prerequisite)", name)
        except Exception as exc:
            results[name] = f"failed: {exc}"
            logger.warning("[daemon_registry] %s registration failed "
                           "(non-fatal — other daemons still register): %s",
                           name, exc)
    return results


LATE_REGISTERED_HOW = ("registered by daemon_registry after this process "
                       "won the scheduler lock (APScheduler started late)")


def _queue_late_registrations(ctx: DaemonContext, names: List[str]) -> None:
    """Re-run the named registrations when APScheduler starts in this
    process -- the boot-time attempt found ``ctx.scheduler`` None.

    One hook per boot, through ``core.scheduler.on_apscheduler_started``:
    the same seam the lock-retry start fires, so there is exactly one place
    that knows "APScheduler is now running here".  Idempotent by
    construction: only the names that answered False are re-run, and every
    APScheduler registration in the table uses ``replace_existing=True``.
    """
    if not names:
        return
    try:
        from core.scheduler import on_apscheduler_started
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[daemon_registry] scheduler start hook unavailable; "
                       "%d registration(s) will NOT be retried on a late "
                       "lock win: %s", len(names), exc)
        return

    def _register_late() -> None:
        register_late_scheduler_owned(ctx, names)
    _register_late.__name__ = "register_scheduler_owned_late"
    on_apscheduler_started(_register_late)
    logger.warning(
        "[daemon_registry] %d scheduler-dependent registration(s) queued "
        "for when this process wins the scheduler lock: %s",
        len(names), ", ".join(sorted(names)))


def register_late_scheduler_owned(ctx: DaemonContext, names: List[str]
                                  ) -> Dict[str, Any]:
    """The late half of :func:`register_scheduler_owned`: APScheduler is now
    running in this process, so give the context the daemon-jobstore handle
    and run the registrations that could not run at boot.  Records the ones
    that registered in this pod's heartbeat (running), so the Effective
    Posture card reads them from the pod that actually holds the lock.
    Returns {name: True | False | "failed: ..."} like the boot half."""
    from core.scheduler import get_daemon_scheduler
    sched = get_daemon_scheduler()
    if sched is None:
        logger.warning("[daemon_registry] late registration asked for with "
                       "no APScheduler running here -- nothing registered")
        return {}
    ctx.scheduler = sched
    results = _run_registrations(ctx, names)
    done = [n for n, ok in results.items() if ok is True]
    logger.warning(
        "[daemon_registry] REGISTERED LATE %d/%d scheduler-dependent "
        "daemon(s) -- this process won the scheduler lock after boot: %s",
        len(done), len(results), ", ".join(sorted(done)) or "none")
    try:
        from core import background_jobs as _bj
        _bj.record_boot_registrations(
            [n for n in done if n not in _SINGLETON_OUTCOMES],
            LATE_REGISTERED_HOW)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[daemon_registry] late registrations not recorded "
                       "for the heartbeat: %s", exc)
    # 2026-09-28 (found live on Docker) -- several of these registrations
    # create background_jobs entries (the brain / mirror daemons).  The
    # deferred-singleton drain autostarts on the loop, but it can run FIRST
    # (it did: 13:20:34 autostart, 13:20:35 REGISTERED LATE), leaving those
    # entries registered-but-stopped forever.  Autostart after registering.
    try:
        started = _autostart_new_jobs(ctx)
        if started:
            logger.info("[daemon_registry] late registration: %d "
                        "background_jobs entries autostarted", started)
    except Exception as exc:                          # noqa: BLE001
        logger.error("[daemon_registry] late-registered background jobs "
                     "could not be autostarted: %s", exc)
    return results


#: daemon name -> its ``core.job_control`` toggle id, for the daemons an
#: admin can switch off entirely.
#:
#: 2026-09-01.  A disabled daemon never registers, so nothing reports it, and
#: the fleet listing called it "no pod has reported this daemon" — which
#: reads as a fault when it is a decision somebody made on purpose.  That is
#: the same confusion as an unrecognised filter spelling looking identical to
#: a deliberate refusal: the two need different words, or an operator goes
#: hunting for a broken pod.
#:
#: Pinned by a test against the ``_jc_enabled`` calls above, so a daemon that
#: gains a toggle cannot quietly fall out of this map.
ADMIN_TOGGLES: Dict[str, str] = {
    "iceberg_metadata_sync":    "__iceberg_metadata_sync__",
    "iceberg_manifest_watcher": "__iceberg_manifest_watcher__",
}


def admin_disabled(daemon_name: str) -> bool:
    """True when an admin has switched this daemon off.

    Fails to False: a toggle that cannot be read must not make a running
    daemon look deliberately stopped.
    """
    toggle = ADMIN_TOGGLES.get(daemon_name)
    if not toggle:
        return False
    try:
        from core.job_control import is_enabled as _jc_enabled
        return not _jc_enabled(toggle)
    except Exception as exc:
        logger.debug("[daemon_registry] toggle %s unreadable: %s", toggle, exc)
        return False


def register_remote_placeholders() -> Dict[str, str]:
    """Give this pod a visible, controllable entry for every declared daemon
    it does not itself run.  Returns {name: owner} for the ones added.

    2026-09-01.  ``background_jobs._jobs`` is process-local, so the API pod
    — which serves the admin UI — listed none of the scheduler pod's daemons
    and answered 404 "unknown job" for every control call against them.  The
    fix belongs here because THIS module is the only place that knows which
    pod owns what; ``background_jobs`` deliberately knows nothing about pods.

    Called after the real registrations on each pod, so a placeholder can
    never shadow a daemon that actually runs here (``register_remote`` also
    refuses to displace a real entry — the rule is enforced on both sides,
    because the ordering is the kind of thing a later edit silently breaks).

    Orphans are included on purpose.  A capability owned by no pod is the
    one an operator most needs to see; leaving it out would hide it behind
    the same silence that hid the rest.
    """
    from core import background_jobs as _bj

    declared: Dict[str, str] = {}
    for n in SCHEDULER_OWNED:
        declared[n] = "scheduler/worker pod"
    for n in API_OWNED:
        declared[n] = "api pod"
    for n in KNOWN_ORPHANS:
        declared[n] = "NO POD — declared orphan"

    added: Dict[str, str] = {}
    for name, owner in declared.items():
        try:
            if _bj.get_job(name) is not None:
                continue          # runs here for real — that entry wins
            _bj.register_remote(
                name, f"Runs on the {owner} (placeholder on this pod)", owner)
            added[name] = owner
        except Exception as exc:
            logger.warning("[daemon_registry] placeholder for %s failed "
                           "(non-fatal): %s", name, exc)
    if added:
        logger.info("[daemon_registry] %d remote daemon placeholder(s) "
                    "registered so the admin UI can see the whole fleet",
                    len(added))
    return added


__all__ = [
    "DaemonContext",
    "SINGLETON_DAEMONS",
    "start_when_singleton",
    "drain_deferred_singletons",
    "SCHEDULER_OWNED",
    "API_OWNED",
    "KNOWN_ORPHANS",
    "DELEGATED_TO",
    "is_owned_somewhere",
    "register_scheduler_owned",
    "register_late_scheduler_owned",
    "register_remote_placeholders",
    "ADMIN_TOGGLES",
    "admin_disabled",
    "wire_scheduled_execution_deps",
    "register_snapshot_change_reactions",
]
