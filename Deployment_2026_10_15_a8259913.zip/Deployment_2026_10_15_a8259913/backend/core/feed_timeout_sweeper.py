"""Phase 131 deep-dive #13 (round 18) — feed execution timeout sweeper.

Fires periodically (via APScheduler) and flips any feed_execution
that's been ``in_progress`` / ``running`` for longer than
``feed_generation.execution_timeout_seconds`` to status='failed'.

This is the safety net the user asked for: feeds should NOT stay
"In Progress" indefinitely.  If something hangs (proxy stall,
iceberg pre-download wedged, network partition), the dashboard
must show a clear failure with the captured logs — not a forever
spinning row.

Best-effort: errors during the sweep are logged but never raised.
Idempotent: each tick re-checks live state.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _timeout_seconds() -> int:
    """Read the timeout from config; 0 disables the sweep."""
    try:
        from core.config import feed_generation as _fg
        return int(getattr(_fg, "execution_timeout_seconds", 3600))
    except Exception:
        return 3600


def _now() -> datetime:
    return datetime.now(timezone.utc)


def sweep_timed_out_executions(db_manager: Any) -> Dict[str, int]:
    """Find feed_executions stuck in running/in_progress past the
    timeout and mark them failed.  Returns counter dict for telemetry.
    """
    counters = {"scanned": 0, "timed_out": 0, "errors": 0}
    threshold = _timeout_seconds()
    if threshold <= 0:
        return counters

    cutoff = _now() - timedelta(seconds=threshold)
    try:
        # Use the existing helper that returns all running/in-progress
        # feed_executions.  Falls back to a list query if the helper
        # doesn't exist.
        try:
            stuck = db_manager.list_running_feed_executions()
        except AttributeError:
            stuck = _fallback_list_running(db_manager)
    except Exception as exc:
        logger.warning("[feed_timeout_sweeper] list query failed: %s", exc)
        counters["errors"] += 1
        return counters

    for row in (stuck or []):
        counters["scanned"] += 1
        started = _coerce_dt(row.get("started_at") or row.get("created_at"))
        if started is None:
            continue  # no start time → can't decide; skip
        if started > cutoff:
            continue  # still within budget
        # Stale — mark failed with a clear message + persist logs if
        # the per-execution log buffer has anything for this exec id.
        exec_id_str = row.get("execution_id") or ""
        exec_db_id = row.get("id")
        elapsed = (_now() - started).total_seconds()
        msg = (
            f"Feed execution timed out after {int(elapsed)}s "
            f"(threshold={threshold}s).  Probable causes: stuck pre-"
            f"download, network partition, or unresponsive upstream.  "
            f"Check captured logs below for the last activity before "
            f"the timeout."
        )
        # Best-effort log capture from the in-process buffer.
        files_metadata: Dict[str, Any] = {}
        try:
            from core.feed_perf import capture_perf_metadata
            files_metadata = capture_perf_metadata(exec_id_str)
        except Exception:
            files_metadata = {}
        try:
            db_manager.update_feed_execution(int(exec_db_id), {
                "status": "failed",
                "error_message": msg,
                "completed_at": _now(),
                "duration_seconds": round(elapsed, 1),
                "failed_stage": "timeout",
                "files_metadata": files_metadata,
            })
            counters["timed_out"] += 1
            logger.warning(
                "[feed_timeout_sweeper] feed_execution %s timed out at "
                "%ds (exec_id=%s)",
                exec_db_id, int(elapsed), exec_id_str,
            )

            # CRITICAL BUG FIX (2026-05-18): the sweeper was only updating
            # feed_executions.status.  Dashboard reads feed_runs.status —
            # so even after sweep marked the EXECUTION failed, the daily
            # TASK row stayed "running" forever, leaving users staring
            # at perpetually-running feeds that had actually died.
            #
            # The FeedExecution model does NOT carry a feed_run_id FK
            # (the runtime link is via execute_feed's parameter, not
            # persisted).  We reconstruct the link here using the
            # canonical unique key (feed_config_id, business_date) — same
            # key the SOD generator uses and that the uniqueness index
            # enforces.  business_date is derived from started_at.date()
            # which matches what execute_feed passes to update_feed_run
            # during normal operation.
            try:
                feed_config_id = row.get("feed_config_id")
                if (feed_config_id
                        and hasattr(db_manager, "feed_run_for_execution")
                        and hasattr(db_manager, "update_feed_run")):
                    # Edge-case sweep 2026-09-24: the execution's OWN run --
                    # a timed-out manual Run Now failed the day's pending
                    # scheduled row, which then never ran.
                    feed_run = db_manager.feed_run_for_execution(row)
                    if feed_run and feed_run.get("status") in (
                            "pending", "running"):
                        db_manager.update_feed_run(int(feed_run["id"]), {
                            "status": "failed",
                            "completed_at": _now(),
                            "error": msg[:500],
                        })
                        logger.warning(
                            "[feed_timeout_sweeper] feed_run %s "
                            "(feed_config=%s biz_date=%s) also marked "
                            "failed (was orphaned in %s state)",
                            feed_run["id"], feed_config_id, feed_run.get("business_date"),
                            feed_run.get("status"),
                        )
            except Exception as fr_exc:
                logger.warning(
                    "[feed_timeout_sweeper] feed_execution %s flipped to "
                    "failed but feed_runs sync failed (%s) — dashboard "
                    "may still show stale running status",
                    exec_db_id, fr_exc,
                )
        except Exception as exc:
            logger.warning(
                "[feed_timeout_sweeper] could not update execution %s: %s",
                exec_db_id, exc,
            )
            counters["errors"] += 1
    return counters


def _fallback_list_running(db_manager: Any):
    """Defensive listing when the dedicated helper isn't present.

    Reads feed_executions with status IN ('running','in_progress',
    'pending') — narrow enough to be cheap; the sweeper runs on a
    timer so a one-time table scan per minute is acceptable even on
    big DBs.
    """
    try:
        from sqlalchemy import text as _text
        sess_ctx = db_manager.get_session(read_only=True) if hasattr(db_manager, "get_session") else None
        if sess_ctx is None:
            return []
        with sess_ctx as session:
            # feed_config_id is REQUIRED so the sweeper can find the
            # parent feed_runs row via (feed_config_id, business_date).
            # The FeedExecution model does NOT carry feed_run_id directly
            # (the link is runtime-only via execute_feed's parameter); we
            # reconstruct it from feed_config_id + started_at.date() at
            # sweep time using db.get_feed_run_by_feed_date.
            rs = session.execute(_text(
                "SELECT id, execution_id, feed_config_id, started_at, "
                "       created_at, status "
                "FROM feed_executions "
                "WHERE status IN ('running','in_progress','pending') "
                "ORDER BY id DESC LIMIT 500"
            )).mappings()
            return [dict(r) for r in rs]
    except Exception as exc:
        logger.debug("[feed_timeout_sweeper] fallback list failed: %s", exc)
        return []


def _coerce_dt(value: Any) -> Optional[datetime]:
    """Accept ISO string / datetime / None — return tz-aware UTC datetime
    or None when we can't parse."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, str):
        try:
            d = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
        except ValueError:
            return None
    return None
