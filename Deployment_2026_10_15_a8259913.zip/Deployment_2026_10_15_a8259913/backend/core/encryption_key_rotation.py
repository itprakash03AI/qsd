"""Every stored credential readable under ONE key (2026-10-15).

Found deploying to a new server with connections already in the database:
each component started with a different key (or a new one), all 16 stored
connection credentials became unreadable in every pod, and every pod still
reported healthy.  ``core/crypto.py`` now resolves ONE primary key for every
component plus DECRYPT-ONLY older keys (``QUERY_STUDIO_SECRET_KEY_PREVIOUS``;
the old key FILE after an upgrade).  This sweep, run at start-up by every
component (idempotent: concurrent sweeps write equally valid tokens):

* re-encrypts under the PRIMARY every stored secret an older key can read --
  connections, and the feed tables whose secret columns are encrypted at
  rest (``core/secrets_at_rest.py``) -- so the older key can be removed;
* lists, by name, every stored secret NO key can read, with the fix --
  never blanked, never re-written (a pod with the wrong key must not destroy
  a credential it cannot read);
* does nothing while the process has NO key (a component waiting for the
  key the API creates; see ``core/crypto.py``) -- said once, never a list
  of thousands of "unreadable" records.

It works on the STORED values (``enc::...`` text), never on decrypted ones.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Tuple

logger = logging.getLogger(__name__)

#: the last sweep this process ran (the admin status shows it)
LAST_REPORT: Dict[str, Any] = {}

FIX = ("Give every component the key these were saved with: set "
       "QUERY_STUDIO_SECRET_KEY_PREVIOUS (the api chart: secrets.encryptionKeyPrevious) to "
       "the old server's key -- its QUERY_STUDIO_SECRET_KEY, or the contents of its key file "
       "(paths.secret_key_file).  The next start re-encrypts them under the current key.  "
       "Or re-enter each password.")


def _rotate(obj: Any, is_secret, counts: Dict[str, int], bad: List[str], path: str = "") -> Any:
    from core.crypto import rotate_value
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            p = f"{path}.{k}" if path else str(k)
            if is_secret(k) and isinstance(v, str) and v:
                nv, state = rotate_value(v)
                counts[state] = counts.get(state, 0) + 1
                if state == "unreadable":
                    bad.append(p)
                out[k] = nv
            else:
                out[k] = _rotate(v, is_secret, counts, bad, p)
        return out
    if isinstance(obj, list):
        return [_rotate(v, is_secret, counts, bad, f"{path}[{i}]") for i, v in enumerate(obj)]
    return obj


def _connection_rows(db) -> List[Tuple[int, str, Any]]:
    from sqlalchemy import text
    with db.engine.connect() as c:
        return [(r[0], r[1], r[2]) for r in
                c.execute(text("SELECT id, name, config FROM connections")).fetchall()]


def sweep(db, *, write: bool = True) -> Dict[str, Any]:
    """The sweep (module docstring).  ``write=False`` only counts (the admin
    status).  Returns ``{key, rotated, current, unreadable: [...], fix}``."""
    from core import crypto
    from core.secrets_at_rest import _secret_columns, is_secret_key
    status = crypto.key_status()
    may_write = write and crypto.rotation_allowed()
    report: Dict[str, Any] = {"key": status, "rotated": 0, "current": 0, "unreadable": [],
                              "wrote": bool(may_write)}

    # ── connections (config JSON; the connection rule of what is secret) ──
    con_secret = lambda k: k in crypto.SENSITIVE_FIELDS          # noqa: E731
    todo = {}
    for cid, name, cfg in _connection_rows(db):
        cfg = json.loads(cfg) if isinstance(cfg, str) else (cfg or {})
        counts, bad = {}, []
        new = _rotate(cfg, con_secret, counts, bad)
        report["rotated"] += counts.get("rotated", 0)
        report["current"] += counts.get("current", 0)
        if bad:
            report["unreadable"].append({"kind": "connection", "id": cid, "name": name, "fields": bad})
        if counts.get("rotated"):
            todo[cid] = new
    if todo and may_write:
        from core.db.models import Connection
        with db.get_session() as s:
            for cid, new in todo.items():
                obj = s.get(Connection, cid)
                if obj is not None:
                    obj.config = new

    # ── feed tables encrypted at rest (SecretJSON columns) ──
    from sqlalchemy import text
    for model, cols in _secret_columns():
        table = model.__table__.name
        has_name = "name" in model.__table__.columns
        with db.engine.connect() as c:
            rows = c.execute(text(f"SELECT id, {'name, ' if has_name else ''}{', '.join(cols)} "
                                  f"FROM {table}")).fetchall()
        writes = []
        for r in rows:
            rid, name = r[0], (r[1] if has_name else None)
            vals = r[2:] if has_name else r[1:]
            changed = {}
            for col, raw in zip(cols, vals):
                if raw is None:
                    continue
                v = json.loads(raw) if isinstance(raw, str) else raw
                counts, bad = {}, []
                new = _rotate(v, is_secret_key, counts, bad)
                report["rotated"] += counts.get("rotated", 0)
                report["current"] += counts.get("current", 0)
                if bad:
                    report["unreadable"].append({"kind": table, "id": rid, "name": name,
                                                 "fields": [f"{col}.{b}" for b in bad]})
                if counts.get("rotated"):
                    changed[col] = new
            if changed:
                writes.append((rid, changed))
        if writes and may_write:
            with db.get_session() as s:
                for rid, changed in writes:
                    obj = s.get(model, rid)
                    for col, new in changed.items():
                        # already ciphertext: the column type leaves enc:: values as they are
                        setattr(obj, col, new)
    report["fix"] = FIX if report["unreadable"] else ""
    return report


def rotate_stored_secrets(db) -> Dict[str, Any]:
    """The start-up sweep, logged: rotated, and every unreadable secret NAMED
    with the fix.  Never raises (a pod must start; the status says why its
    credentials cannot be read)."""
    from core.crypto import key_status
    st = key_status()
    if not st.get("available"):
        LAST_REPORT.clear()
        LAST_REPORT.update({"skipped": st.get("source"), "key": st})
        logger.warning("[encryption-key] stored-credential sweep skipped: %s", st.get("source"))
        return dict(LAST_REPORT)
    try:
        rep = sweep(db, write=True)
    except Exception as exc:                                 # noqa: BLE001
        logger.error("[encryption-key] the stored-credential sweep failed: %s", exc, exc_info=True)
        LAST_REPORT.clear()
        LAST_REPORT.update({"error": f"{type(exc).__name__}: {exc}"})
        return dict(LAST_REPORT)
    LAST_REPORT.clear()
    LAST_REPORT.update(rep)
    k = rep["key"]
    if rep["rotated"]:
        logger.warning("[encryption-key] %d stored secret(s) re-encrypted under the key from %s "
                       "(%s); the older key may now be removed", rep["rotated"], k.get("source"),
                       k.get("fingerprint"))
    if rep["unreadable"]:
        names = ", ".join(f"{u['kind']} {u.get('name') or u['id']}" for u in rep["unreadable"][:20])
        logger.error("[encryption-key] %d stored record(s) hold a secret NO key of this "
                     "deployment can read (key from %s, %s): %s.  %s",
                     len(rep["unreadable"]), k.get("source"), k.get("fingerprint"), names, FIX)
    return rep


__all__ = ["sweep", "rotate_stored_secrets", "LAST_REPORT", "FIX"]
