"""
Mixin — Datasets, Federation, Agg Cache, Business Reports, Parameters, Subscriptions.
Extracted from DatabaseManager for modularity.
"""
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any

from sqlalchemy import func as _sa_func, update as _sa_update

from sqlalchemy import text
from core.db.models import (
    BusinessDataset, DatasetClass, DatasetColumn, DatasetRelationship,
    DrillHierarchy, PreDefinedCondition, AggregationAwareness,
    FederationExecution, MergedDimension, AggCacheEntry, AggCacheSuggestion,
    BusinessReport, BusinessReportVersion, ReportParameter, ReportSubscription,
    SubscriptionDelivery, CalculatedMetric, ReportInstance,
    ReportInstanceSignoff, ReportInstanceComment,
    # Catalog association tables reused for portal favourites / grouping
    # (2026-08-11).  They already discriminate on report_type and already
    # accept "business" — a second set of tables would let the portal star
    # and the catalog star disagree.
    ReportFavorite, ReportFolderAssignment, ReportTag, ReportTagAssignment,
    BusinessReportShareToken, ReportEmbedToken,
)

# 2026-08-13 -- this module had NO logger and never imported logging, yet
# three ``except`` handlers added with the portal work (2026-08-11) call
# ``logger.debug(...)``.  F821 caught it.  It is not a style nit: each of
# those handlers exists so a decoration lookup CANNOT break the report list
# ("fail-open"), and a NameError raised INSIDE the handler defeats exactly
# that -- a failed favourites/tag/folder query would propagate and take the
# whole list endpoint down instead of degrading to no-decoration.
logger = logging.getLogger(__name__)


def _ri_utc(dt: Optional[datetime]) -> Optional[datetime]:
    """Normalise a datetime to aware-UTC (SQLite hands naive values back;
    all ReportInstance writers store aware-UTC so comparisons stay
    consistent)."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class InstanceLocked(ValueError):
    """A signed report instance refused a mutation (2026-09-28).

    Raised by ``delete_report_instance`` and by a demotion to ``expired``
    while an ACTIVE sign-off references the instance.  A ``ValueError`` so
    the DB layer stays free of HTTP types; the route maps it to 409 with
    the message, which names the sign-off.
    """


def _active_signoff_instance_ids(session, instance_ids=None) -> set:
    """Instance ids that hold at least one ACTIVE sign-off (the lock)."""
    q = session.query(ReportInstanceSignoff.instance_id).filter(
        ReportInstanceSignoff.status == "active")
    if instance_ids is not None:
        ids = [int(i) for i in instance_ids]
        if not ids:
            return set()
        q = q.filter(ReportInstanceSignoff.instance_id.in_(ids))
    return {int(r[0]) for r in q.distinct().all()}


class DatasetsMixin:
    """Database methods for datasets, federation, agg cache, business reports, subscriptions."""

    def list_datasets(self, subject: str = None, published_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(BusinessDataset)
            if subject:
                q = q.filter(BusinessDataset.subject == subject)
            if published_only:
                q = q.filter(BusinessDataset.is_published)
            return [r.to_dict() for r in q.order_by(BusinessDataset.name).all()]

    def list_datasets_visible(self, *, username: str, group_ids: list = None,
                              subject: str = None) -> List[Dict[str, Any]]:
        """2026-08-09 dataset self-service — the non-admin visible list:
        published datasets + the caller's own drafts + drafts owned by a
        group the caller belongs to.  Same OR-bucket shape as
        ``_br_visibility_clauses`` for business reports; every visible
        dataset falls in one of the buckets, so the SQL filter is
        loss-free."""
        from sqlalchemy import func, or_
        with self.get_session() as session:
            q = session.query(BusinessDataset)
            if subject:
                q = q.filter(BusinessDataset.subject == subject)
            vis = [BusinessDataset.is_published == True]  # noqa: E712
            if username:
                vis.append(func.lower(BusinessDataset.owner) == username.lower())
            if group_ids:
                vis.append(BusinessDataset.owner_group_id.in_(
                    sorted({int(g) for g in group_ids})))
            q = q.filter(or_(*vis))
            return [r.to_dict() for r in q.order_by(BusinessDataset.name).all()]

    def count_user_datasets(self, username: str) -> int:
        """Per-user dataset count for the self-service quota CAP
        (case-insensitive owner match, same as the entitlement resolver)."""
        if not username:
            return 0
        from sqlalchemy import func
        with self.get_session() as session:
            return int(session.query(BusinessDataset).filter(
                func.lower(BusinessDataset.owner) == username.lower()
            ).count())

    def get_dataset(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            return row.to_dict() if row else None

    def create_dataset(self, name: str, subject: str, description: str = "",
                       owner: str = "admin", connection_ids: list = None,
                       source_tables: list = None, base_query: str = "",
                       is_published: bool = False,
                       owner_group_id: Optional[int] = None,
                       partition_config: Optional[dict] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            ds = BusinessDataset(
                name=name, subject=subject, description=description,
                owner=owner, connection_ids=connection_ids or [],
                source_tables=source_tables or [], base_query=base_query,
                is_published=is_published, owner_group_id=owner_group_id,
                # 2026-09-05 — stored VERBATIM, never a model dump: writing
                # the planner's defaults into the row would freeze them at
                # save time and hand the author back a document they did
                # not send.  ``None`` stays NULL (not declared).
                partition_config=(partition_config or None),
            )
            # FB-49 (2026-09-20) -- the slug is assigned HERE, the one place
            # a dataset comes into existence, so no dataset can be created
            # without a URL.  It is not a caller-supplied field: the name
            # decides it, and it never moves afterwards.
            ds.slug = self._dataset_slug_for(session, name)
            session.add(ds)
            session.flush()
            return ds.to_dict()

    # ── URL slugs (FB-49, 2026-09-20) ───────────────────────────────────────
    #: A slugless legacy row's URL falls back to its id; keep slugs from ever
    #: looking like one, so the two token kinds cannot collide.
    _DATASET_SLUG_MAX = 200

    def _dataset_slug_for(self, session, name: str, *,
                          exclude_id: Optional[int] = None) -> str:
        from core.slugs import slugify, unique_slug
        base = slugify(name, fallback="dataset", max_len=self._DATASET_SLUG_MAX)
        if base.isdigit():
            base = f"dataset-{base}"

        def _taken(candidate: str) -> bool:
            q = session.query(BusinessDataset.id).filter(
                BusinessDataset.slug == candidate)
            if exclude_id is not None:
                q = q.filter(BusinessDataset.id != exclude_id)
            return q.first() is not None

        return unique_slug(base, _taken, max_len=self._DATASET_SLUG_MAX)

    def get_dataset_by_slug(self, slug: str) -> Optional[Dict[str, Any]]:
        """The dataset whose URL slug this is, or None.  A purely numeric
        token is the documented fallback -- a legacy row the backfill could
        not slug, and every /datasets/<id>/query URL anyone has bookmarked --
        resolved by id, through this one route."""
        from core.slugs import is_numeric_token
        token = str(slug or "").strip()
        if not token:
            return None
        with self.get_session(read_only=True) as session:
            r = (session.query(BusinessDataset)
                 .filter(BusinessDataset.slug == token).first())
            if r is None and is_numeric_token(token):
                r = (session.query(BusinessDataset)
                     .filter(BusinessDataset.id == int(token)).first())
            return r.to_dict() if r else None

    def _ensure_dataset_slugs(self) -> Dict[str, int]:
        """Backfill a slug onto every dataset that has none, then make the
        column unique.  Idempotent: a second run slugs nothing and the index
        creation is IF NOT EXISTS on both dialects."""
        filled = 0
        with self.get_session() as session:
            rows = (session.query(BusinessDataset)
                    .filter((BusinessDataset.slug.is_(None))
                            | (BusinessDataset.slug == ""))
                    .order_by(BusinessDataset.id).all())
            for r in rows:
                r.slug = self._dataset_slug_for(
                    session, r.name or "dataset", exclude_id=r.id)
                session.flush()
                filled += 1
        with self.get_session() as session:
            session.execute(text(
                "CREATE UNIQUE INDEX IF NOT EXISTS ux_business_datasets_slug "
                "ON business_datasets (slug)"))
        if filled:
            logger.info("business_datasets: %d dataset(s) received a URL slug",
                        filled)
        return {"filled": filled}

    def update_dataset(self, dataset_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return None
            allowed = {"name", "description", "subject", "owner", "connection_ids",
                       "source_tables", "base_query", "is_published",
                       # 2026-09-05 progressive partition loading.  A field
                       # missing from this set is the "200 and stored
                       # nothing" defect this repo hit three times in one
                       # day; the API validates it, this stores it.
                       "partition_config",
                       # 2026-08-09 dataset self-service — group ownership +
                       # certification (all still policy-gated at the API).
                       "owner_group_id", "is_certified", "certified_by",
                       "certified_at"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def delete_dataset(self, dataset_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(BusinessDataset).filter(BusinessDataset.id == dataset_id).first()
            if not row:
                return False
            # Cascade: delete related objects
            session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id).delete()
            session.query(DatasetClass).filter(DatasetClass.dataset_id == dataset_id).delete()
            session.query(DatasetRelationship).filter(DatasetRelationship.dataset_id == dataset_id).delete()
            session.query(DrillHierarchy).filter(DrillHierarchy.dataset_id == dataset_id).delete()
            session.query(PreDefinedCondition).filter(PreDefinedCondition.dataset_id == dataset_id).delete()
            session.query(AggregationAwareness).filter(AggregationAwareness.dataset_id == dataset_id).delete()
            # 2026-08-22 — CalculatedMetric and MergedDimension were NOT in
            # this cascade.  On SQLite an INTEGER PRIMARY KEY reuses
            # max(rowid)+1, so deleting the newest dataset and creating
            # another HANDED THE ORPHANED METRICS TO THE NEW DATASET: ghost
            # expressions surfaced in its glossary and were executable via
            # metric_ids against columns that don't exist.
            session.query(CalculatedMetric).filter(CalculatedMetric.dataset_id == dataset_id).delete()
            session.query(MergedDimension).filter(
                (MergedDimension.primary_dataset_id == dataset_id)
                | (MergedDimension.secondary_dataset_id == dataset_id)).delete()
            session.delete(row)
            return True

    # ── DatasetClass CRUD ─────────────────────────────────────────────────

    def list_dataset_classes(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetClass).filter(
                DatasetClass.dataset_id == dataset_id
            ).order_by(DatasetClass.sort_order, DatasetClass.name).all()
            return [r.to_dict() for r in rows]

    def create_dataset_class(self, dataset_id: int, name: str,
                             label: str = "", icon: str = "",
                             sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            obj = DatasetClass(dataset_id=dataset_id, name=name,
                               label=label, icon=icon, sort_order=sort_order)
            session.add(obj)
            session.flush()
            return obj.to_dict()

    def get_dataset_class(self, class_id: int) -> Optional[Dict[str, Any]]:
        """2026-08-09 dataset self-service — parent-resolution getter so the
        API can authorize child mutations against the OWNING dataset before
        touching the row (same pattern for relationship/hierarchy/condition
        below)."""
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            return row.to_dict() if row else None

    def update_dataset_class(self, class_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "icon", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_class(self, class_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetClass).filter(DatasetClass.id == class_id).first()
            if not row:
                return False
            # Unlink columns from this class (set class_id=None)
            session.query(DatasetColumn).filter(DatasetColumn.class_id == class_id).update(
                {"class_id": None}, synchronize_session="fetch")
            session.delete(row)
            return True

    # ── DatasetColumn CRUD ────────────────────────────────────────────────

    def list_dataset_columns(self, dataset_id: int,
                             column_type: str = None,
                             include_hidden: bool = True) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(DatasetColumn).filter(DatasetColumn.dataset_id == dataset_id)
            if column_type:
                q = q.filter(DatasetColumn.column_type == column_type)
            if not include_hidden:
                q = q.filter(DatasetColumn.is_hidden == False)  # noqa: E712  (SQLAlchemy: `not <Column>` collapses to literal False)
            return [r.to_dict() for r in q.order_by(DatasetColumn.sort_order, DatasetColumn.friendly_name).all()]

    def get_dataset_column(self, column_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            return row.to_dict() if row else None

    def create_dataset_column(self, dataset_id: int, physical_name: str,
                              friendly_name: str, column_type: str = "dimension",
                              data_type: str = "string", aggregation: str = "",
                              format_pattern: str = "", description: str = "",
                              synonyms: list = None, role_whitelist: list = None,
                              class_id: int = None, sort_order: int = 0,
                              is_hidden: bool = False) -> Dict[str, Any]:
        with self.get_session() as session:
            col = DatasetColumn(
                dataset_id=dataset_id, physical_name=physical_name,
                friendly_name=friendly_name, column_type=column_type,
                data_type=data_type, aggregation=aggregation,
                format_pattern=format_pattern, description=description,
                synonyms=synonyms or [], role_whitelist=role_whitelist or [],
                class_id=class_id, sort_order=sort_order, is_hidden=is_hidden,
            )
            session.add(col)
            session.flush()
            return col.to_dict()

    def update_dataset_column(self, column_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return None
            allowed = {"physical_name", "friendly_name", "column_type", "data_type",
                       "aggregation", "format_pattern", "description", "synonyms",
                       "role_whitelist", "class_id", "sort_order", "is_hidden"}
            for k, v in kwargs.items():
                if k in allowed:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_column(self, column_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetColumn).filter(DatasetColumn.id == column_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    def bulk_create_dataset_columns(self, dataset_id: int,
                                    columns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Bulk-create columns for a dataset (used by auto-detect from schema)."""
        results = []
        with self.get_session() as session:
            for c in columns:
                col = DatasetColumn(
                    dataset_id=dataset_id,
                    physical_name=c.get("physical_name", ""),
                    friendly_name=c.get("friendly_name", c.get("physical_name", "")),
                    column_type=c.get("column_type", "dimension"),
                    data_type=c.get("data_type", "string"),
                    aggregation=c.get("aggregation", ""),
                    format_pattern=c.get("format_pattern", ""),
                    description=c.get("description", ""),
                    synonyms=c.get("synonyms", []),
                    role_whitelist=c.get("role_whitelist", []),
                    class_id=c.get("class_id"),
                    sort_order=c.get("sort_order", 0),
                    is_hidden=c.get("is_hidden", False),
                )
                session.add(col)
                session.flush()
                results.append(col.to_dict())
        return results

    # ── DatasetRelationship CRUD ──────────────────────────────────────────

    def list_dataset_relationships(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DatasetRelationship).filter(
                DatasetRelationship.dataset_id == dataset_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_dataset_relationship(self, dataset_id: int, left_table: str,
                                    right_table: str, join_keys: list,
                                    join_type: str = "inner",
                                    cardinality: str = "many_to_one") -> Dict[str, Any]:
        with self.get_session() as session:
            rel = DatasetRelationship(
                dataset_id=dataset_id, left_table=left_table,
                right_table=right_table, join_keys=join_keys,
                join_type=join_type, cardinality=cardinality,
            )
            session.add(rel)
            session.flush()
            return rel.to_dict()

    def get_dataset_relationship(self, rel_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            return row.to_dict() if row else None

    def update_dataset_relationship(self, rel_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"left_table", "right_table", "join_type", "join_keys", "cardinality"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_dataset_relationship(self, rel_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DatasetRelationship).filter(DatasetRelationship.id == rel_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── DrillHierarchy CRUD ───────────────────────────────────────────────

    def list_drill_hierarchies(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(DrillHierarchy).filter(
                DrillHierarchy.dataset_id == dataset_id
            ).order_by(DrillHierarchy.name).all()
            return [r.to_dict() for r in rows]

    def create_drill_hierarchy(self, dataset_id: int, name: str,
                               levels: list) -> Dict[str, Any]:
        with self.get_session() as session:
            h = DrillHierarchy(dataset_id=dataset_id, name=name, levels=levels)
            session.add(h)
            session.flush()
            return h.to_dict()

    def get_drill_hierarchy(self, hierarchy_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            return row.to_dict() if row else None

    def update_drill_hierarchy(self, hierarchy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "levels"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_drill_hierarchy(self, hierarchy_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(DrillHierarchy).filter(DrillHierarchy.id == hierarchy_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── PreDefinedCondition CRUD ──────────────────────────────────────────

    def list_predefined_conditions(self, dataset_id: int) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(PreDefinedCondition).filter(
                PreDefinedCondition.dataset_id == dataset_id
            ).order_by(PreDefinedCondition.sort_order, PreDefinedCondition.name).all()
            return [r.to_dict() for r in rows]

    def create_predefined_condition(self, dataset_id: int, name: str,
                                    where_clause: str, label: str = "",
                                    description: str = "",
                                    sort_order: int = 0) -> Dict[str, Any]:
        with self.get_session() as session:
            c = PreDefinedCondition(
                dataset_id=dataset_id, name=name, where_clause=where_clause,
                label=label, description=description, sort_order=sort_order,
            )
            session.add(c)
            session.flush()
            return c.to_dict()

    def get_predefined_condition(self, condition_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            return row.to_dict() if row else None

    def update_predefined_condition(self, condition_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"name", "label", "description", "where_clause", "sort_order"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_predefined_condition(self, condition_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(PreDefinedCondition).filter(PreDefinedCondition.id == condition_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── AggregationAwareness CRUD ─────────────────────────────────────────

    def list_aggregation_awareness(self, dataset_id: Optional[int] = None) -> List[Dict[str, Any]]:
        # Phase 7 (2026-08-09): dataset_id became optional so the scheduled
        # verification sweep can enumerate EVERY mapping.  Existing callers
        # all pass a dataset_id — behaviour unchanged for them.
        with self.get_session() as session:
            q = session.query(AggregationAwareness)
            if dataset_id is not None:
                q = q.filter(AggregationAwareness.dataset_id == dataset_id)
            return [r.to_dict() for r in q.all()]

    def get_aggregation_awareness(self, agg_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(AggregationAwareness).filter(
                AggregationAwareness.id == agg_id).first()
            return row.to_dict() if row else None

    def update_aggregation_awareness(self, agg_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Phase 7 (2026-08-09): needed by the verification GATE — a probe
        mismatch flips ``is_enabled`` to False so a wrong customer table can
        never serve again until an admin re-enables (and re-verifies) it."""
        with self.get_session() as session:
            row = session.query(AggregationAwareness).filter(
                AggregationAwareness.id == agg_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if k in {"agg_table", "agg_dimensions", "connection_id",
                         "is_enabled", "measure_col_id"}:
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def create_aggregation_awareness(self, dataset_id: int, measure_col_id: int,
                                     agg_table: str, agg_dimensions: list,
                                     connection_id: int = None,
                                     is_enabled: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            aa = AggregationAwareness(
                dataset_id=dataset_id, measure_col_id=measure_col_id,
                agg_table=agg_table, agg_dimensions=agg_dimensions,
                connection_id=connection_id, is_enabled=is_enabled,
            )
            session.add(aa)
            session.flush()
            return aa.to_dict()

    def delete_aggregation_awareness(self, agg_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(AggregationAwareness).filter(AggregationAwareness.id == agg_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── CalculatedMetric CRUD ─────────────────────────────────────────────

    def list_calculated_metrics(self, dataset_id: int, active_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(CalculatedMetric).filter(CalculatedMetric.dataset_id == dataset_id)
            if active_only:
                q = q.filter(CalculatedMetric.is_active)
            return [r.to_dict() for r in q.order_by(CalculatedMetric.name).all()]

    def get_calculated_metric(self, metric_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(CalculatedMetric).filter(CalculatedMetric.id == metric_id).first()
            return row.to_dict() if row else None

    def create_calculated_metric(self, dataset_id: int, name: str, expression: str,
                                  **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            m = CalculatedMetric(dataset_id=dataset_id, name=name, expression=expression, **kwargs)
            session.add(m)
            session.flush()
            return m.to_dict()

    def update_calculated_metric(self, metric_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(CalculatedMetric).filter(CalculatedMetric.id == metric_id).first()
            if not row:
                return None
            for k, v in kwargs.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def delete_calculated_metric(self, metric_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(CalculatedMetric).filter(CalculatedMetric.id == metric_id).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── Full dataset with all children (single round-trip) ────────────────

    def get_dataset_full(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        """Return a dataset with all its classes, columns, relationships,
        hierarchies, conditions, and aggregation awareness rules."""
        ds = self.get_dataset(dataset_id)
        if not ds:
            return None
        ds["classes"]        = self.list_dataset_classes(dataset_id)
        ds["columns"]        = self.list_dataset_columns(dataset_id)
        ds["relationships"]  = self.list_dataset_relationships(dataset_id)
        ds["hierarchies"]    = self.list_drill_hierarchies(dataset_id)
        ds["conditions"]     = self.list_predefined_conditions(dataset_id)
        ds["agg_awareness"]  = self.list_aggregation_awareness(dataset_id)
        ds["metrics"]        = self.list_calculated_metrics(dataset_id, active_only=True)
        return ds

    # ── Federation Executions ─────────────────────────────────────────────────

    def create_federation_execution(self, *, execution_id: str, dataset_id: int,
                                    merged_dataset_id: Optional[int] = None,
                                    sql_generated: str = "", column_ids: list = None,
                                    filters: list = None, condition_ids: list = None,
                                    executed_by: str = "",
                                    report_id: Optional[int] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            fe = FederationExecution(
                execution_id=execution_id, dataset_id=dataset_id,
                report_id=report_id,
                merged_dataset_id=merged_dataset_id, sql_generated=sql_generated,
                column_ids=column_ids or [], filters=filters or [],
                condition_ids=condition_ids or [], status="running",
                executed_by=executed_by,
            )
            session.add(fe)
            session.flush()
            return fe.to_dict()

    def update_federation_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return None
            for k, v in kwargs.items():
                if hasattr(fe, k):
                    setattr(fe, k, v)
            session.flush()
            return fe.to_dict()

    def get_federation_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            return fe.to_dict() if fe else None

    def list_federation_executions(self, dataset_id: Optional[int] = None,
                                    limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(FederationExecution)
            if dataset_id is not None:
                q = q.filter(FederationExecution.dataset_id == dataset_id)
            q = q.order_by(FederationExecution.created_at.desc()).limit(limit)
            return [fe.to_dict() for fe in q.all()]

    def delete_federation_execution(self, execution_id: str) -> bool:
        with self.get_session() as session:
            fe = session.query(FederationExecution).filter(
                FederationExecution.execution_id == execution_id
            ).first()
            if not fe:
                return False
            session.delete(fe)
            return True

    # ── Merged Dimensions ─────────────────────────────────────────────────────

    def create_merged_dimension(self, *, primary_dataset_id: int,
                                secondary_dataset_id: int, name: str,
                                merge_keys: list, merge_type: str = "inner",
                                is_active: bool = True) -> Dict[str, Any]:
        with self.get_session() as session:
            md = MergedDimension(
                primary_dataset_id=primary_dataset_id,
                secondary_dataset_id=secondary_dataset_id,
                name=name, merge_keys=merge_keys, merge_type=merge_type,
                is_active=is_active,
            )
            session.add(md)
            session.flush()
            return md.to_dict()

    def list_merged_dimensions(self, dataset_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(MergedDimension)
            if dataset_id is not None:
                q = q.filter(
                    (MergedDimension.primary_dataset_id == dataset_id) |
                    (MergedDimension.secondary_dataset_id == dataset_id)
                )
            return [md.to_dict() for md in q.all()]

    def get_merged_dimension(self, md_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            return md.to_dict() if md else None

    def update_merged_dimension(self, md_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return None
            for k, v in kwargs.items():
                if hasattr(md, k):
                    setattr(md, k, v)
            session.flush()
            return md.to_dict()

    def delete_merged_dimension(self, md_id: int) -> bool:
        with self.get_session() as session:
            md = session.query(MergedDimension).filter(MergedDimension.id == md_id).first()
            if not md:
                return False
            session.delete(md)
            return True

    # ── AggCacheEntry CRUD ────────────────────────────────────────────

    def list_agg_cache_entries(self, dataset_id: int = None,
                               status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheEntry.status == status)
            return [e.to_dict() for e in q.order_by(AggCacheEntry.id).all()]

    def get_agg_cache_entry(self, entry_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            e = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            return e.to_dict() if e else None

    def create_agg_cache_entry(self, *, dataset_id: int, name: str,
                                description: str = "",
                                dimension_col_ids: list = None,
                                measure_col_ids: list = None,
                                grain_label: str = "custom",
                                condition_ids: list = None,
                                schedule_config: dict = None,
                                is_enabled: bool = True,
                                incremental_enabled: bool = False,
                                incremental_column: str = None,
                                created_by: str = "admin",
                                rls_mode: str = None,
                                security_dimension_col_ids: list = None,
                                policy_version: str = None,
                                rls_signature: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            entry = AggCacheEntry(
                dataset_id=dataset_id,
                name=name,
                description=description,
                dimension_col_ids=dimension_col_ids or [],
                measure_col_ids=measure_col_ids or [],
                grain_label=grain_label,
                condition_ids=condition_ids or [],
                schedule_config=schedule_config,
                is_enabled=is_enabled,
                incremental_enabled=incremental_enabled,
                incremental_column=incremental_column,
                created_by=created_by,
                # Phase 5 RLS-aware cubes (2026-08-09) — normally stamped by
                # the build path; accepted here for scoped-entry creation.
                rls_mode=rls_mode,
                security_dimension_col_ids=security_dimension_col_ids,
                policy_version=policy_version,
                rls_signature=rls_signature,
            )
            session.add(entry)
            session.flush()
            return entry.to_dict()

    def update_agg_cache_entry(self, entry_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return None
            for k, v in kwargs.items():
                if hasattr(entry, k):
                    setattr(entry, k, v)
            session.flush()
            return entry.to_dict()

    def delete_agg_cache_entry(self, entry_id: int) -> bool:
        with self.get_session() as session:
            entry = session.query(AggCacheEntry).filter(AggCacheEntry.id == entry_id).first()
            if not entry:
                return False
            session.delete(entry)
            return True

    def increment_agg_cache_hit(self, entry_id: int) -> None:
        # 2026-09-15: atomic in SQL -- see increment_business_report_execution.
        with self.get_session() as session:
            session.execute(
                _sa_update(AggCacheEntry)
                .where(AggCacheEntry.id == entry_id)
                .values(hit_count=_sa_func.coalesce(AggCacheEntry.hit_count, 0) + 1,
                        last_served_at=datetime.now(timezone.utc)))

    def increment_agg_cache_miss(self, entry_id: int) -> None:
        # 2026-09-15: atomic in SQL -- see increment_business_report_execution.
        with self.get_session() as session:
            session.execute(
                _sa_update(AggCacheEntry)
                .where(AggCacheEntry.id == entry_id)
                .values(miss_count=_sa_func.coalesce(AggCacheEntry.miss_count, 0) + 1))

    def get_agg_cache_stats(self, dataset_id: int = None) -> Dict[str, Any]:
        with self.get_session() as session:
            q = session.query(AggCacheEntry)
            if dataset_id is not None:
                q = q.filter(AggCacheEntry.dataset_id == dataset_id)
            entries = q.all()
            total_hits = sum(e.hit_count or 0 for e in entries)
            total_misses = sum(e.miss_count or 0 for e in entries)
            total_size = sum(e.file_size_bytes or 0 for e in entries)
            by_status: Dict[str, int] = {}
            ds_ids = set()
            for e in entries:
                by_status[e.status] = by_status.get(e.status, 0) + 1
                ds_ids.add(e.dataset_id)
            total_requests = total_hits + total_misses
            suggestions_q = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.status == "pending")
            if dataset_id is not None:
                suggestions_q = suggestions_q.filter(
                    AggCacheSuggestion.dataset_id == dataset_id)
            return {
                "total_entries": len(entries),
                "entries_by_status": by_status,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2) if total_size else 0,
                "total_hits": total_hits,
                "total_misses": total_misses,
                "hit_rate_percent": round(total_hits / total_requests * 100, 1) if total_requests else 0,
                "datasets_cached": len(ds_ids),
                "suggestions_pending": suggestions_q.count(),
            }

    # ── AggCacheSuggestion CRUD ───────────────────────────────────────

    def list_agg_cache_suggestions(self, dataset_id: int = None,
                                    status: str = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(AggCacheSuggestion)
            if dataset_id is not None:
                q = q.filter(AggCacheSuggestion.dataset_id == dataset_id)
            if status is not None:
                q = q.filter(AggCacheSuggestion.status == status)
            return [s.to_dict() for s in q.order_by(AggCacheSuggestion.id.desc()).all()]

    def create_agg_cache_suggestion(self, *, dataset_id: int,
                                     dimension_col_ids: list,
                                     measure_col_ids: list,
                                     query_count: int,
                                     estimated_speedup: float = 0.0) -> Dict[str, Any]:
        with self.get_session() as session:
            s = AggCacheSuggestion(
                dataset_id=dataset_id,
                dimension_col_ids=dimension_col_ids,
                measure_col_ids=measure_col_ids,
                query_count=query_count,
                estimated_speedup=estimated_speedup,
            )
            session.add(s)
            session.flush()
            return s.to_dict()

    def update_agg_cache_suggestion(self, suggestion_id: int,
                                     **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return None
            for k, v in kwargs.items():
                if hasattr(s, k):
                    setattr(s, k, v)
            session.flush()
            return s.to_dict()

    def delete_agg_cache_suggestion(self, suggestion_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(AggCacheSuggestion).filter(
                AggCacheSuggestion.id == suggestion_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    # ── Phase 56: Business Reports ──────────────────────────────────────────

    def list_business_reports(self, owner: str = None, dataset_id: int = None,
                              is_published: bool = None) -> list:
        with self.get_session() as session:
            q = session.query(BusinessReport)
            if owner:
                q = q.filter(BusinessReport.owner == owner)
            if dataset_id:
                q = q.filter(BusinessReport.dataset_id == dataset_id)
            if is_published is not None:
                q = q.filter(BusinessReport.is_published == is_published)
            return [r.to_dict() for r in q.order_by(BusinessReport.updated_at.desc()).all()]

    # ── 2026-08-09 metadata-scale audit finding 1: paginated visible list ──

    def _br_visibility_clauses(self, ctx: Dict[str, Any]) -> list:
        """SQL rendering of the resolve_viewer_context visibility rule —
        ONE builder (2026-08-09), shared by ``search_reports_unified``
        (where cabf95b7 introduced it inline) and
        ``list_business_reports_page``.

        Returns OR-able clauses forming the candidate SUPERSET of what the
        viewer may see: published rows (a non-empty ``role_whitelist``
        still needs the dict-only Python trim — it is a JSON column not
        safely expressible in portable SQLite+PG SQL), own rows,
        owner-group rows, and explicitly granted rows.  Every visible
        report falls in one of these buckets, so filtering to this
        superset in SQL is loss-free; the trim only ever REMOVES rows.
        """
        from sqlalchemy import and_, func, or_
        # Publish lifecycle (2026-08-17): archived/deprecated reports keep
        # is_published (direct id stays resolvable for audit) but must NOT
        # appear in the consumer listing's published bucket.  NULL lifecycle
        # = pre-migration row = visible as before.  Own / owner-group /
        # granted buckets are NOT filtered — the author keeps seeing their
        # own archived reports.
        vis = [and_(
            BusinessReport.is_published == True,  # noqa: E712
            or_(BusinessReport.lifecycle_status.is_(None),
                BusinessReport.lifecycle_status.notin_(
                    ("archived", "deprecated"))),
        )]
        username = (ctx or {}).get("username") or ""
        if username:
            vis.append(func.lower(BusinessReport.owner) == username.lower())
        if (ctx or {}).get("group_ids"):
            vis.append(BusinessReport.owner_group_id.in_(sorted(ctx["group_ids"])))
        if (ctx or {}).get("granted_report_ids"):
            vis.append(BusinessReport.id.in_(sorted(ctx["granted_report_ids"])))
        return vis

    # ── Sort options for the keyset list (2026-08-11) ───────────────────────
    #
    # (column, direction, is_datetime).  The cursor CARRIES the sort name, so
    # a cursor minted under one sort can never be replayed under another —
    # that would compare a name against a timestamp and silently skip or
    # repeat rows.  ``updated`` stays first and stays the default: it is the
    # order the list has always used, and old cursors (no ``s`` key) decode
    # to it unchanged.
    _BR_SORTS = {
        "updated":  ("updated_at",       "desc", True),
        "name":     ("name",             "asc",  False),
        "last_run": ("last_executed_at", "desc", True),
    }
    _BR_DEFAULT_SORT = "updated"

    @classmethod
    def _br_normalise_sort(cls, sort: Optional[str]) -> str:
        s = (sort or cls._BR_DEFAULT_SORT).strip().lower()
        if s not in cls._BR_SORTS:
            raise ValueError(
                f"invalid sort {sort!r} — must be one of "
                f"{sorted(cls._BR_SORTS)}")
        return s

    @classmethod
    def _br_encode_cursor(cls, sort_key, row_id: int,
                          sort: str = _BR_DEFAULT_SORT) -> str:
        """Opaque keyset cursor: urlsafe-base64 JSON of the last row's
        (sort key, id) pair PLUS the sort it was minted under.  Padding is
        stripped so the token is query-string safe end to end (the
        published-API resume-token defect was a token the parser could not
        read back — tests here round-trip the ENCODED string through the
        route).

        ``sort_key`` is a datetime for the time-based sorts and a plain value
        otherwise; ``None`` is preserved so NULLS-LAST paging works.
        """
        import base64
        import json as _json
        key = sort_key.isoformat() if hasattr(sort_key, "isoformat") else sort_key
        payload = {"u": key, "i": int(row_id)}
        if sort != cls._BR_DEFAULT_SORT:
            # Omitted for the default so tokens stay byte-identical to the
            # ones already in flight when this shipped.
            payload["s"] = sort
        return base64.urlsafe_b64encode(
            _json.dumps(payload, separators=(",", ":")).encode()
        ).decode().rstrip("=")

    @classmethod
    def _br_decode_cursor(cls, cursor: str, expect_sort: Optional[str] = None):
        """Inverse of ``_br_encode_cursor`` -> ``(sort_key, id)``.

        Raises ValueError on any malformed token (callers map that to HTTP
        400 — never a 500), and ALSO when the token was minted under a
        different sort than the request asks for: continuing a name-sorted
        walk with a timestamp cursor silently skips or repeats rows, which
        looks like missing data rather than an error.
        """
        import base64
        import json as _json
        try:
            raw = cursor.strip()
            raw += "=" * (-len(raw) % 4)
            payload = _json.loads(base64.urlsafe_b64decode(raw.encode()).decode())
            cur_sort = payload.get("s") or cls._BR_DEFAULT_SORT
            if cur_sort not in cls._BR_SORTS:
                raise ValueError(f"unknown sort in cursor: {cur_sort!r}")
            if expect_sort is not None and cur_sort != expect_sort:
                raise ValueError(
                    f"cursor was issued for sort={cur_sort!r} but the request "
                    f"asks for sort={expect_sort!r} — restart the listing "
                    f"without a cursor when the sort changes")
            key = payload.get("u")
            if key is not None and cls._BR_SORTS[cur_sort][2]:
                key = datetime.fromisoformat(key)
            return key, int(payload["i"])
        except (ValueError, TypeError, KeyError) as exc:
            raise ValueError(f"invalid cursor: {exc}") from exc
        except Exception as exc:  # binascii.Error etc.
            raise ValueError(f"invalid cursor: {exc}") from exc

    def _br_favorite_ids(self, session, username: Optional[str]) -> set:
        """Report ids this user has starred, from the EXISTING catalog table.

        ``report_favorites`` already discriminates on ``report_type`` and
        already accepts ``"business"`` (catalog_api has written that value
        since 23A/58).  Reusing it means the portal star and the catalog star
        are the same star — a second favourites table would have let them
        disagree.
        """
        if not username:
            return set()
        try:
            rows = session.query(ReportFavorite.report_id).filter(
                ReportFavorite.report_type == "business",
                ReportFavorite.username == username,
            ).all()
            return {int(r[0]) for r in rows}
        except Exception:  # noqa: BLE001 - a decoration must never break the list
            logger.debug("favourite lookup failed", exc_info=True)
            return set()

    def _br_tags_and_folders(self, session, report_ids: list) -> tuple:
        """``({report_id: [tag dict]}, {report_id: folder_id})`` for a PAGE.

        Two queries for the whole page, not one per row — the list endpoint is
        the hot path and N+1 here is what makes a portal feel broken at 10k
        reports.  Fail-open: grouping metadata is decoration, never the
        visibility rule.
        """
        tags: dict = {}
        folders: dict = {}
        if not report_ids:
            return tags, folders
        try:
            rows = session.query(
                ReportTagAssignment.report_id, ReportTag.id, ReportTag.name,
                ReportTag.color,
            ).join(ReportTag, ReportTag.id == ReportTagAssignment.tag_id).filter(
                ReportTagAssignment.report_type == "business",
                ReportTagAssignment.report_id.in_(report_ids),
            ).all()
            for rid, tid, tname, tcolor in rows:
                tags.setdefault(int(rid), []).append(
                    {"id": int(tid), "name": tname,
                     "color": tcolor or "#666666"})
        except Exception:  # noqa: BLE001
            logger.debug("tag lookup failed", exc_info=True)
        try:
            rows = session.query(
                ReportFolderAssignment.report_id,
                ReportFolderAssignment.folder_id,
            ).filter(
                ReportFolderAssignment.report_type == "business",
                ReportFolderAssignment.report_id.in_(report_ids),
            ).all()
            folders = {int(r[0]): int(r[1]) for r in rows}
        except Exception:  # noqa: BLE001
            logger.debug("folder lookup failed", exc_info=True)
        return tags, folders

    def list_business_reports_page(self, *, viewer: Optional[Dict[str, Any]] = None,
                                   ctx: Optional[Dict[str, Any]] = None,
                                   limit: int = 100, cursor: Optional[str] = None,
                                   owner: Optional[str] = None,
                                   dataset_id: Optional[int] = None,
                                   is_published: Optional[bool] = None,
                                   q: Optional[str] = None,
                                   sort: Optional[str] = None,
                                   favorites_only: bool = False,
                                   folder_id: Optional[int] = None,
                                   tag_id: Optional[int] = None,
                                   include_samples: bool = False) -> Dict[str, Any]:
        """Keyset-paginated business-report list with the visibility rule
        INSIDE the query (2026-08-09, metadata-scale audit finding 1).

        Why keyset and not OFFSET: at 100k rows OFFSET re-scans everything
        before the page on every request, and the dict-only role_whitelist
        trim shifts row positions between requests so OFFSET pages can skip
        or repeat rows.  The cursor pins the (updated_at, id) sort key of
        the last returned row; the next page continues strictly after it
        regardless of how many rows the trim removed.

        Ordering: ``updated_at DESC NULLS LAST, id DESC`` — the same
        updated_at-descending order the legacy list used, with id as the
        unique tiebreaker keyset needs.

        PAGE HONESTY (same pattern as ``search_reports_unified``): the
        role_whitelist trim runs AFTER SQL, so the method over-fetches in
        batches until ``limit`` visible rows are found or candidates are
        exhausted — a run of hidden rows can never silently shrink or empty
        a page.  The per-row check is dict-only (ctx pre-resolved): 0 SQL
        per row.

        ``ctx=None`` (or ``ctx["sees_all"]``) skips the visibility
        predicate — admin tier and trusted internal callers, mirroring
        ``search_reports_unified(viewer=None)``.

        Returns ``{"items": [summary...], "next_cursor": str|None,
        "has_more": bool}`` — items are ``to_summary_dict()`` projections
        (no raw_sql_override / filter_specs / section_definitions /
        layout_config: a list payload, not a detail payload).

        Concurrency note (inherent to any keyset list): a report updated
        between two page fetches moves to the top and will not re-appear on
        later pages of the SAME walk; no duplicates are ever emitted.
        """
        from sqlalchemy import and_, or_
        limit = max(1, min(int(limit or 100), 500))
        sort = self._br_normalise_sort(sort)      # ValueError → caller's 400
        col_name, direction, _is_dt = self._BR_SORTS[sort]
        sort_col = getattr(BusinessReport, col_name)
        restricted = ctx is not None and not ctx.get("sees_all")
        trim = None
        if restricted:
            from core.reports.authorization import can_view_business_report
            trim = can_view_business_report

        viewer_name = ((viewer or {}).get("username") or "").strip() or None

        with self.get_session(read_only=True) as session:
            fav_ids = self._br_favorite_ids(session, viewer_name)

            bq = session.query(BusinessReport)
            if owner:
                bq = bq.filter(BusinessReport.owner == owner)
            if dataset_id:
                bq = bq.filter(BusinessReport.dataset_id == dataset_id)
            if is_published is not None:
                bq = bq.filter(BusinessReport.is_published == is_published)
            if not include_samples:
                # 2026-09-18 -- INSIDE the query, not after it.  This call
                # site's own docstring says why: "filtering AFTER a limit
                # silently shrinks or empties pages".
                #
                # TWO markers, deliberately.  ``is_sample`` is the new
                # general flag; ``template_category == "ib_sample"`` is what
                # POST /api/admin/seed-sample-reports has always stamped on
                # the reports it creates (and uses to find them again).
                # Honouring both means already-seeded demos are hidden with
                # no backfill, and a report can be marked a sample without
                # pretending it came from the seeder.
                #
                # ``is_(False)`` / ``is_(None)`` rather than ``== False`` so
                # rows written before the column existed are treated as NOT
                # samples -- the safe direction: a real report is never
                # hidden by a flag nobody set.
                bq = bq.filter(
                    or_(BusinessReport.is_sample.is_(False),
                        BusinessReport.is_sample.is_(None)),
                    or_(BusinessReport.template_category.is_(None),
                        BusinessReport.template_category != "ib_sample"))
            if q:
                term = f"%{q}%"
                bq = bq.filter(or_(BusinessReport.name.ilike(term),
                                   BusinessReport.description.ilike(term),
                                   BusinessReport.owner.ilike(term)))
            if favorites_only:
                # An empty favourites set must yield an EMPTY page, not an
                # unfiltered one — ``in_([])`` is the correct false predicate;
                # skipping the filter would show every report instead.
                bq = bq.filter(BusinessReport.id.in_(sorted(fav_ids)))
            if folder_id is not None:
                bq = bq.filter(BusinessReport.id.in_(
                    session.query(ReportFolderAssignment.report_id).filter(
                        ReportFolderAssignment.report_type == "business",
                        ReportFolderAssignment.folder_id == int(folder_id))))
            if tag_id is not None:
                bq = bq.filter(BusinessReport.id.in_(
                    session.query(ReportTagAssignment.report_id).filter(
                        ReportTagAssignment.report_type == "business",
                        ReportTagAssignment.tag_id == int(tag_id))))
            # VISIBILITY IS UNCHANGED.  Sort / favourites / folder / tag are
            # all NARROWING filters layered on top of the same
            # ``_br_visibility_clauses`` + ``can_view_business_report`` pair.
            # None of them can widen what a viewer sees, and there is
            # deliberately no second access rule anywhere in this method.
            if restricted:
                bq = bq.filter(or_(*self._br_visibility_clauses(ctx)))
            if cursor:
                # ValueError → caller's 400, including a cursor minted under a
                # DIFFERENT sort (comparing a name to a timestamp would skip
                # or repeat rows and read as missing data).
                c_key, c_id = self._br_decode_cursor(cursor, expect_sort=sort)
                if direction == "desc":
                    if c_key is not None:
                        bq = bq.filter(or_(
                            sort_col < c_key,
                            and_(sort_col == c_key, BusinessReport.id < c_id),
                            sort_col.is_(None),
                        ))
                    else:
                        # Already inside the NULLS-LAST tail.
                        bq = bq.filter(and_(sort_col.is_(None),
                                            BusinessReport.id < c_id))
                else:
                    if c_key is not None:
                        bq = bq.filter(or_(
                            sort_col > c_key,
                            and_(sort_col == c_key, BusinessReport.id > c_id),
                        ))
                    else:
                        bq = bq.filter(BusinessReport.id > c_id)
            if direction == "desc":
                bq = bq.order_by(sort_col.desc().nullslast(),
                                 BusinessReport.id.desc())
            else:
                bq = bq.order_by(sort_col.asc().nullsfirst(),
                                 BusinessReport.id.asc())

            # Over-fetch loop: collect limit+1 VISIBLE rows to learn has_more
            # without a COUNT(*).  Each row carries its raw sort key so the
            # cursor is built from column values, never from the projection.
            visible: list = []          # [(summary_dict, sort_key, id)]
            offset, batch = 0, max(limit * 3, 30)
            while len(visible) <= limit:
                rows = bq.limit(batch).offset(offset).all()
                for r in rows:
                    if trim is not None:
                        d = r.to_summary_dict()
                        # Published rows with a non-empty whitelist are the
                        # only candidates SQL could not decide; everything
                        # the predicate admitted otherwise is visible.
                        if (d.get("role_whitelist") or []) and not trim(
                                d, viewer, self, ctx=ctx):
                            continue
                    else:
                        d = r.to_summary_dict()
                    visible.append((d, getattr(r, col_name), r.id))
                    if len(visible) > limit:
                        break
                if len(rows) < batch:
                    break
                if len(visible) > limit:
                    break
                offset += batch

            has_more = len(visible) > limit
            page = visible[:limit]
            next_cursor = (
                self._br_encode_cursor(page[-1][1], page[-1][2], sort=sort)
                if has_more and page else None)

            # Decorate the PAGE only (never the candidate set): favourite
            # flag + tag/folder grouping, two queries for the whole page.
            items = [d for d, _k, _i in page]
            page_ids = [int(d["id"]) for d in items if d.get("id") is not None]
            tag_map, folder_map = self._br_tags_and_folders(session, page_ids)
            for d in items:
                rid = int(d.get("id") or 0)
                d["is_favorite"] = rid in fav_ids
                d["tags"] = tag_map.get(rid, [])
                d["folder_id"] = folder_map.get(rid)

            return {
                "items": items,
                "next_cursor": next_cursor,
                "has_more": has_more,
                "limit": limit,
                "sort": sort,
            }

    def get_business_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            return r.to_dict() if r else None

    def get_business_report_by_legacy_id(self, legacy_id: int) -> Optional[Dict[str, Any]]:
        """Phase 111: Find a migrated business report by its original reports.id."""
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(
                BusinessReport.legacy_report_id == legacy_id
            ).first()
            return r.to_dict() if r else None

    # ── URL slugs (2026-09-20) ──────────────────────────────────────────────
    #: A slugless legacy row's URL falls back to its id; keep slugs from
    #: ever looking like one, so the two token kinds cannot collide.
    _REPORT_SLUG_MAX = 200

    def _report_slug_for(self, session, name: str, *, exclude_id: Optional[int] = None) -> str:
        from core.slugs import slugify, unique_slug
        base = slugify(name, fallback="report", max_len=self._REPORT_SLUG_MAX)
        if base.isdigit():
            base = f"report-{base}"

        def _taken(candidate: str) -> bool:
            q = session.query(BusinessReport.id).filter(BusinessReport.slug == candidate)
            if exclude_id is not None:
                q = q.filter(BusinessReport.id != exclude_id)
            return q.first() is not None

        return unique_slug(base, _taken, max_len=self._REPORT_SLUG_MAX)

    def create_business_report(self, *, name: str, owner: str, dataset_id: int,
                                **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            # 2026-09-20 -- the slug is assigned HERE, the one place a
            # report row is created (duplicate, clone-from-template and the
            # create route all come through), so no path can mint a report
            # without a URL.  A caller-supplied slug is ignored: the name
            # decides, and uniqueness is this method's job.
            kwargs.pop("slug", None)
            r = BusinessReport(name=name, owner=owner, dataset_id=dataset_id, **kwargs)
            r.slug = self._report_slug_for(session, name)
            session.add(r)
            session.flush()
            return r.to_dict()

    def get_business_report_by_slug(self, slug: str) -> Optional[Dict[str, Any]]:
        """The report whose URL slug this is, or None.  A purely numeric
        token is the documented fallback for a legacy row the backfill could
        not slug (its URL carries the id) -- resolved by id, one route."""
        from core.slugs import is_numeric_token
        token = str(slug or "").strip()
        if not token:
            return None
        with self.get_session(read_only=True) as session:
            r = session.query(BusinessReport).filter(BusinessReport.slug == token).first()
            if r is None and is_numeric_token(token):
                r = session.query(BusinessReport).filter(BusinessReport.id == int(token)).first()
            return r.to_dict() if r else None

    def _ensure_report_slugs(self) -> Dict[str, int]:
        """Backfill a slug onto every report that has none, then make the
        column unique.  Idempotent: a second run slugs nothing and the index
        creation is IF NOT EXISTS on both dialects."""
        from core.slugs import slugify, unique_slug
        filled = 0
        with self.get_session() as session:
            rows = (session.query(BusinessReport)
                    .filter((BusinessReport.slug.is_(None)) | (BusinessReport.slug == ""))
                    .order_by(BusinessReport.id).all())
            for r in rows:
                r.slug = self._report_slug_for(session, r.name or "report", exclude_id=r.id)
                session.flush()
                filled += 1
        with self.get_session() as session:
            session.execute(text(
                "CREATE UNIQUE INDEX IF NOT EXISTS ux_business_reports_slug "
                "ON business_reports (slug)"))
        if filled:
            logger.info("business_reports: %d report(s) received a URL slug", filled)
        return {"filled": filled}

    def update_business_report(self, report_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        # 2026-09-20 -- the slug is assigned once and does not follow a
        # rename; it cannot be set through here either (structural, not
        # merely "the API model has no such field").
        kwargs.pop("slug", None)
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            for k, v in kwargs.items():
                if hasattr(r, k):
                    setattr(r, k, v)
            session.flush()
            return r.to_dict()

    def delete_business_report(self, report_id: int) -> bool:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return False
            # Also delete associated parameters + published-version snapshots
            session.query(ReportParameter).filter(ReportParameter.report_id == report_id).delete()
            session.query(BusinessReportVersion).filter(
                BusinessReportVersion.report_id == report_id).delete()
            # 2026-09-15: the report's share + embed tokens stayed
            # ``is_active`` pointing at a dead id.  Harmless only while ids
            # are never reused; a resurrected id would resurrect every old
            # link.  DEACTIVATED (not deleted) in the SAME transaction —
            # revocation is first-class here and the rows remain an audit
            # trail of what was minted.
            session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.report_id == report_id,
            ).update({"is_active": False}, synchronize_session=False)
            session.query(ReportEmbedToken).filter(
                ReportEmbedToken.report_id == report_id,
                ReportEmbedToken.report_type == "business",
            ).update({"is_active": False}, synchronize_session=False)
            session.delete(r)
            return True

    # ── Publish lifecycle — version snapshots (2026-08-17) ──────────────────

    def create_business_report_version(self, *, report_id: int,
                                       definition: Dict[str, Any],
                                       parameters: Optional[list] = None,
                                       published_by: str = "",
                                       semantic_version: Optional[str] = None,
                                       notes: Optional[str] = None,
                                       ) -> Dict[str, Any]:
        """Mint the next published version for a report — ONE transaction.

        Allocates ``version_no = max + 1``, clears ``is_current`` on every
        older row and inserts the new snapshot as current, all in a single
        session so a crash can never leave two current versions (or none
        while rows exist).
        """
        from sqlalchemy import func
        with self.get_session() as session:
            max_no = session.query(
                func.max(BusinessReportVersion.version_no)).filter(
                BusinessReportVersion.report_id == int(report_id)).scalar() or 0
            session.query(BusinessReportVersion).filter(
                BusinessReportVersion.report_id == int(report_id),
                BusinessReportVersion.is_current == True,  # noqa: E712
            ).update({"is_current": False})
            v = BusinessReportVersion(
                report_id=int(report_id),
                version_no=int(max_no) + 1,
                definition=definition,
                parameters=parameters,
                semantic_version=semantic_version,
                published_by=str(published_by or ""),
                published_at=datetime.now(timezone.utc),
                notes=notes,
                is_current=True,
            )
            session.add(v)
            session.flush()
            return v.to_dict()

    def get_current_business_report_version(self, report_id: int
                                            ) -> Optional[Dict[str, Any]]:
        """The version consumers execute — newest row flagged current."""
        with self.get_session(read_only=True) as session:
            v = session.query(BusinessReportVersion).filter(
                BusinessReportVersion.report_id == int(report_id),
                BusinessReportVersion.is_current == True,  # noqa: E712
            ).order_by(BusinessReportVersion.version_no.desc()).first()
            return v.to_dict() if v else None

    def get_business_report_version(self, report_id: int, version_no: int
                                    ) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(BusinessReportVersion).filter(
                BusinessReportVersion.report_id == int(report_id),
                BusinessReportVersion.version_no == int(version_no),
            ).first()
            return v.to_dict() if v else None

    def list_business_report_versions(self, report_id: int) -> list:
        """Version HISTORY metadata, newest first — list projection only
        (``to_meta_dict``): a version list is not a detail payload."""
        with self.get_session(read_only=True) as session:
            rows = session.query(BusinessReportVersion).filter(
                BusinessReportVersion.report_id == int(report_id),
            ).order_by(BusinessReportVersion.version_no.desc()).all()
            return [v.to_meta_dict() for v in rows]

    def increment_business_report_execution(self, report_id: int) -> None:
        """Bump the report's execution counter -- ATOMICALLY, in SQL.

        2026-09-15: this was a Python read-modify-write (``r.execution_count
        = (r.execution_count or 0) + 1``): every concurrent run read the
        same value and the last writer won -- measured live, 20 concurrent
        runs advanced the counter 2 -> 13.  ``UPDATE ... SET n = n + 1``
        is evaluated by the database under its row lock on every dialect
        this repo supports (postgres, sqlite), so N runs advance it by N.
        ``coalesce`` covers rows created before the column had a default.
        """
        with self.get_session() as session:
            session.execute(
                _sa_update(BusinessReport)
                .where(BusinessReport.id == report_id)
                .values(execution_count=_sa_func.coalesce(BusinessReport.execution_count, 0) + 1,
                        last_executed_at=datetime.now(timezone.utc)))

    def list_report_parameters(self, report_id: int) -> list:
        with self.get_session() as session:
            return [p.to_dict() for p in session.query(ReportParameter).filter(
                ReportParameter.report_id == report_id
            ).order_by(ReportParameter.sort_order).all()]

    def create_report_parameter(self, *, report_id: int, name: str, label: str,
                                 parameter_type: str = "dropdown", **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ReportParameter(report_id=report_id, name=name, label=label,
                                parameter_type=parameter_type, **kwargs)
            session.add(p)
            session.flush()
            return p.to_dict()

    def update_report_parameter(self, param_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ReportParameter).filter(ReportParameter.id == param_id).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            session.flush()
            return p.to_dict()

    def delete_report_parameter(self, param_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ReportParameter).filter(ReportParameter.id == param_id).first()
            if not p:
                return False
            session.delete(p)
            return True

    def replace_report_parameters(self, report_id: int, params_list: list) -> list:
        """Atomically replace all parameters for a report in a single transaction.

        Deletes existing parameters and bulk-inserts the new set within one session,
        so either all succeed or all roll back.

        A parameter may name its cascade parent POSITIONALLY, as
        ``depends_on_index`` — the index of the parent within
        ``params_list``.  It has to: this call REPLACES the whole set, so
        when the caller builds the list none of the rows have ids yet.  The
        ids come into existence here, inside this transaction, which is
        therefore the only place the reference can be resolved without a
        second round trip.  Resolving it here also keeps the guarantee the
        docstring above promises — the previous design linked the cascade
        with follow-up PUTs after this call returned, so a failure between
        the two left the parameters created and the cascade unlinked.

        ``depends_on_param_id`` is still honoured when given and no index
        is: a caller that already knows real ids (the duplicate-report
        path remaps them itself) is not forced through positions.
        """
        with self.get_session() as session:
            session.query(ReportParameter).filter(
                ReportParameter.report_id == report_id
            ).delete(synchronize_session="fetch")
            rows = []
            for item in params_list:
                p = ReportParameter(
                    report_id=report_id,
                    name=item["name"],
                    label=item["label"],
                    parameter_type=item.get("parameter_type", "dropdown"),
                    lov_column_id=item.get("lov_column_id"),
                    # 2026-08-31 -- the FOURTH place a parameter's fields are
                    # enumerated by hand (two request models, the batch
                    # handler's dict, and here).  A field missing from any
                    # one of them is dropped silently on the path that omits
                    # it, and the batch path is the one the report builder
                    # saves through -- so it is the one users would have hit.
                    static_values=item.get("static_values"),
                    depends_on_param_id=item.get("depends_on_param_id"),
                    cascade_filter_column_id=item.get("cascade_filter_column_id"),
                    default_value=item.get("default_value"),
                    description=item.get("description"),
                    is_required=item.get("is_required", True),
                    sort_order=item.get("sort_order", 0),
                )
                session.add(p)
                rows.append((item, p))
            # One flush for the whole set: every id now exists.
            session.flush()

            for item, p in rows:
                idx = item.get("depends_on_index")
                if idx is None:
                    continue
                if not isinstance(idx, int) or not (0 <= idx < len(rows)):
                    # The API validates this before calling; a caller that
                    # skips the route gets the reference dropped rather than
                    # a dangling id, because a WRONG parent silently filters
                    # the child's dropdown by the wrong column.
                    logger.warning(
                        "Parameter %r names cascade parent position %r, which "
                        "is not in the batch of %d; leaving it unlinked.",
                        item.get("name"), idx, len(rows))
                    continue
                p.depends_on_param_id = rows[idx][1].id
            session.flush()

            return [p.to_dict() for _, p in rows]

    # ── Report Subscription methods (Phase 60) ──────────────────────────

    def create_subscription(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            sub = ReportSubscription(**kwargs)
            session.add(sub)
            session.flush()
            return sub.to_dict()

    def get_subscription(self, sub_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            return sub.to_dict() if sub else None

    def list_subscriptions(self, created_by: Optional[str] = None,
                           report_id: Optional[int] = None,
                           report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            q = session.query(ReportSubscription)
            if created_by:
                q = q.filter(ReportSubscription.created_by == created_by)
            if report_id is not None:
                q = q.filter(ReportSubscription.report_id == report_id)
            if report_type:
                q = q.filter(ReportSubscription.report_type == report_type)
            return [s.to_dict() for s in q.order_by(ReportSubscription.created_at.desc()).all()]

    def update_subscription(self, sub_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            if not sub:
                return None
            for k, v in kwargs.items():
                if hasattr(sub, k):
                    setattr(sub, k, v)
            session.flush()
            return sub.to_dict()

    def delete_subscription(self, sub_id: int) -> bool:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(ReportSubscription.id == sub_id).first()
            if not sub:
                return False
            session.delete(sub)
            return True

    def get_subscription_by_unsubscribe_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            sub = session.query(ReportSubscription).filter(
                ReportSubscription.unsubscribe_token == token
            ).first()
            return sub.to_dict() if sub else None

    def get_pending_subscriptions(self, before: datetime) -> List[Dict[str, Any]]:
        """Return active subscriptions whose next_send_at is at or before the given time."""
        with self.get_session() as session:
            subs = session.query(ReportSubscription).filter(
                ReportSubscription.is_active,
                ReportSubscription.next_send_at != None,  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                ReportSubscription.next_send_at <= before,
            ).order_by(ReportSubscription.next_send_at).all()
            return [s.to_dict() for s in subs]

    def record_subscription_delivery(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            rec = SubscriptionDelivery(**kwargs)
            session.add(rec)
            session.flush()
            return rec.to_dict()

    def list_subscription_deliveries(self, subscription_id: int,
                                     limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            recs = session.query(SubscriptionDelivery).filter(
                SubscriptionDelivery.subscription_id == subscription_id
            ).order_by(SubscriptionDelivery.attempted_at.desc()).limit(limit).all()
            return [r.to_dict() for r in recs]

    # ── Report Instances (Phase 2 instance layer, 2026-08-09) ────────────
    #
    # An instance row REFERENCES an execution artifact — it never owns
    # bytes.  Delete/prune here removes ROWS only; artifact retention
    # stays with the execution lifecycle.  The serve-key components
    # (params_fingerprint, rls_signature, semantic_version) are GATES:
    # blank values are refused at both write and lookup so an empty key
    # can never wildcard-match (fail-closed).

    _RI_STATUSES = ("ready", "stale", "expired")

    @staticmethod
    def _ri_require(field_name: str, value: Any) -> str:
        v = str(value or "").strip()
        if not v:
            raise ValueError(
                f"report instance {field_name} must be non-empty — a blank "
                "key component could wildcard-match across scopes "
                "(fail-closed)"
            )
        return v

    def create_report_instance(self, *, report_id: int, execution_id: str,
                               params_fingerprint: str, rls_signature: str,
                               semantic_version: str, created_by: str,
                               artifact_path: Optional[str] = None,
                               row_count: Optional[int] = None,
                               source_version: Optional[str] = None,
                               is_scheduled: bool = False,
                               status: str = "ready",
                               stale_at: Optional[datetime] = None,
                               expires_at: Optional[datetime] = None,
                               created_at: Optional[datetime] = None,
                               row_limit: Optional[int] = None,
                               truncated: Optional[bool] = None,
                               unstable_truncation: Optional[bool] = None,
                               ) -> Dict[str, Any]:
        """Insert an instance row (write-through after a successful
        execution, or a scheduled pre-warm).  ``created_at`` override
        exists for backfill/tests only.

        ``row_limit`` / ``truncated`` / ``unstable_truncation`` (D1/D2,
        2026-08-09 cross-feature review) are the RUN's truncation facts —
        stored so a serve can disclose the run's verdict instead of
        recomputing one against the (possibly larger) report limit.  All
        tri-state: ``None`` = unknown, stored as NULL, never coerced."""
        execution_id = self._ri_require("execution_id", execution_id)
        params_fingerprint = self._ri_require("params_fingerprint", params_fingerprint)
        rls_signature = self._ri_require("rls_signature", rls_signature)
        semantic_version = self._ri_require("semantic_version", semantic_version)
        created_by = self._ri_require("created_by", created_by)
        if status not in self._RI_STATUSES:
            raise ValueError(f"report instance status must be one of "
                             f"{self._RI_STATUSES}, got {status!r}")
        with self.get_session() as session:
            inst = ReportInstance(
                report_id=int(report_id),
                execution_id=execution_id,
                artifact_path=artifact_path,
                params_fingerprint=params_fingerprint,
                rls_signature=rls_signature,
                semantic_version=semantic_version,
                source_version=source_version,
                status=status,
                is_scheduled=bool(is_scheduled),
                row_count=row_count,
                row_limit=(int(row_limit) if row_limit is not None else None),
                truncated=(bool(truncated) if truncated is not None else None),
                unstable_truncation=(bool(unstable_truncation)
                                     if unstable_truncation is not None
                                     else None),
                created_by=created_by,
                stale_at=_ri_utc(stale_at),
                expires_at=_ri_utc(expires_at),
            )
            if created_at is not None:
                inst.created_at = _ri_utc(created_at)
            session.add(inst)
            session.flush()
            return inst.to_dict()

    def get_report_instance(self, instance_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(ReportInstance).filter(
                ReportInstance.id == instance_id).first()
            return r.to_dict() if r else None

    def find_report_instance_by_artifact(self, artifact_path: str,
                                         ) -> Optional[Dict[str, Any]]:
        """The instance backing ``artifact_path``, if any.

        2026-08-09.  Used by the paged-results endpoint to recover an
        instance's stored truncation facts (``row_limit`` / ``truncated`` /
        ``unstable_truncation``) for its pages.

        Keyed on the ARTIFACT, not the execution id, deliberately: a serve
        registers its job row under a FRESH ``ri_…`` execution id owned by the
        caller (so retrieval works without widening the executor/owner/admin
        gate on the original execution), so the two ids differ by design.
        The artifact path is what they genuinely share.

        Returns the NEWEST match — retention can keep several rows pointing at
        one artifact, and their truncation facts are identical because they
        describe the same bytes.  Blank path returns None rather than matching
        every row with an empty artifact_path.
        """
        path = str(artifact_path or "").strip()
        if not path:
            return None
        with self.get_session(read_only=True) as session:
            r = (session.query(ReportInstance)
                 .filter(ReportInstance.artifact_path == path)
                 .order_by(ReportInstance.created_at.desc(),
                           ReportInstance.id.desc())
                 .first())
            return r.to_dict() if r else None

    def find_latest_report_instance(self, *, report_id: int,
                                    params_fingerprint: str,
                                    rls_signature: str,
                                    semantic_version: Optional[str] = None,
                                    max_age_seconds: Optional[int] = None,
                                    statuses: tuple = ("ready", "stale"),
                                    ) -> Optional[Dict[str, Any]]:
        """Latest valid instance for (report, params, scope[, version]).

        All key components are EXACT-match filters; ``max_age_seconds``
        and ``expires_at`` bound temporal validity.  Blank key components
        raise (a blank key must never wildcard-match — that would be a
        cross-scope serve)."""
        params_fingerprint = self._ri_require("params_fingerprint", params_fingerprint)
        rls_signature = self._ri_require("rls_signature", rls_signature)
        if semantic_version is not None:
            semantic_version = self._ri_require("semantic_version", semantic_version)
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            q = session.query(ReportInstance).filter(
                ReportInstance.report_id == int(report_id),
                ReportInstance.params_fingerprint == params_fingerprint,
                ReportInstance.rls_signature == rls_signature,
            )
            if semantic_version is not None:
                q = q.filter(ReportInstance.semantic_version == semantic_version)
            if statuses:
                q = q.filter(ReportInstance.status.in_(list(statuses)))
            if max_age_seconds is not None:
                cutoff = now - timedelta(seconds=int(max_age_seconds))
                q = q.filter(ReportInstance.created_at >= cutoff)
            rows = q.order_by(ReportInstance.created_at.desc(),
                              ReportInstance.id.desc()).limit(50).all()
            for r in rows:
                exp = _ri_utc(r.expires_at)
                if exp is not None and exp <= now:
                    continue  # hard-TTL expired → miss
                return r.to_dict()
            return None

    def list_report_instances(self, report_id: int,
                              limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            rows = session.query(ReportInstance).filter(
                ReportInstance.report_id == int(report_id)
            ).order_by(ReportInstance.created_at.desc(),
                       ReportInstance.id.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    def update_report_instance_status(self, instance_id: int,
                                      status: str) -> Optional[Dict[str, Any]]:
        """Lifecycle demotion (ready → stale → expired)."""
        if status not in self._RI_STATUSES:
            raise ValueError(f"report instance status must be one of "
                             f"{self._RI_STATUSES}, got {status!r}")
        with self.get_session() as session:
            r = session.query(ReportInstance).filter(
                ReportInstance.id == instance_id).first()
            if not r:
                return None
            # 2026-09-28 -- the LOCK: a signed instance may go stale (still
            # served, with its banner) but never expired (a MISS that lets
            # the cleaner take the bytes the signature vouches for).
            if status == "expired" and _active_signoff_instance_ids(
                    session, [instance_id]):
                raise InstanceLocked(
                    f"report instance {instance_id} is signed off and "
                    "cannot be expired; revoke the sign-off first")
            r.status = status
            session.flush()
            return r.to_dict()

    def delete_report_instance(self, instance_id: int) -> bool:
        """Delete the ROW only — artifact bytes stay with the execution
        retention lifecycle.  Refuses (``InstanceLocked``) while an active
        sign-off references the instance (2026-09-28)."""
        with self.get_session() as session:
            r = session.query(ReportInstance).filter(
                ReportInstance.id == instance_id).first()
            if not r:
                return False
            if _active_signoff_instance_ids(session, [instance_id]):
                raise InstanceLocked(
                    f"report instance {instance_id} is signed off and "
                    "cannot be deleted; revoke the sign-off first")
            session.delete(r)
            return True

    def prune_report_instances(self, report_id: Optional[int] = None,
                               keep_latest: Optional[int] = 3,
                               max_age_seconds: Optional[int] = None) -> int:
        """Retention CAP: keep the newest ``keep_latest`` rows per serve
        key (report_id, params_fingerprint, rls_signature), drop rows past
        ``max_age_seconds`` and rows past their own ``expires_at``.
        BO retains latest-N instances; Cognos keeps ONE output version by
        default — N is deliberately small.  Deletes ROWS only.  Returns
        rows deleted."""
        now = datetime.now(timezone.utc)
        cutoff = (now - timedelta(seconds=int(max_age_seconds))
                  if max_age_seconds is not None else None)
        deleted = 0
        with self.get_session() as session:
            q = session.query(ReportInstance)
            if report_id is not None:
                q = q.filter(ReportInstance.report_id == int(report_id))
            rows = q.order_by(ReportInstance.created_at.desc(),
                              ReportInstance.id.desc()).all()
            # 2026-09-28 -- a signed instance is outside retention entirely
            # (neither counted against keep_latest nor aged out): the lock
            # is a correctness gate, and the newest-N cap must still keep
            # N UNSIGNED rows so serving is unaffected by a signed one.
            signed_ids = _active_signoff_instance_ids(
                session, [r.id for r in rows])
            per_key_seen: Dict[tuple, int] = {}
            for r in rows:
                if int(r.id) in signed_ids:
                    continue
                key = (r.report_id, r.params_fingerprint, r.rls_signature)
                n = per_key_seen.get(key, 0) + 1
                per_key_seen[key] = n
                created = _ri_utc(r.created_at)
                expires = _ri_utc(r.expires_at)
                kill = False
                if keep_latest is not None and n > int(keep_latest):
                    kill = True
                if cutoff is not None and created is not None and created < cutoff:
                    kill = True
                if expires is not None and expires <= now:
                    kill = True
                if kill:
                    session.delete(r)
                    deleted += 1
            return deleted

    def find_report_instance_by_execution(self, report_id: int,
                                          execution_id: str,
                                          ) -> Optional[Dict[str, Any]]:
        """The instance a LIVE run recorded, by the run's execution id
        (2026-09-28).  The sync and async lanes both record under the id
        the viewer holds, so the sign-off header can find "the run I am
        looking at" without a second identity.  ``None`` = the run was
        not recorded (extra filters, overrides, flag off)."""
        eid = str(execution_id or "").strip()
        if not eid:
            return None
        with self.get_session(read_only=True) as session:
            r = (session.query(ReportInstance)
                 .filter(ReportInstance.report_id == int(report_id),
                         ReportInstance.execution_id == eid)
                 .order_by(ReportInstance.id.desc())
                 .first())
            return r.to_dict() if r else None

    # ── Instance sign-off (2026-09-28) ──────────────────────────────────────
    #
    # The RULES (who may sign, who sees what, what a lock means) live in
    # core/reports/signoff.py; these methods only persist and read rows.

    _SIGNOFF_STATUSES = ("active", "revoked")

    def create_report_instance_signoff(self, *, instance: Dict[str, Any],
                                       role: str, signed_by: str,
                                       note: Optional[str] = None,
                                       business_date: Optional[str] = None,
                                       ) -> Dict[str, Any]:
        """Insert an ACTIVE sign-off copying the instance's identity."""
        signed_by = self._ri_require("signed_by", signed_by)
        role = self._ri_require("role", role)
        with self.get_session() as session:
            row = ReportInstanceSignoff(
                report_id=int(instance["report_id"]),
                instance_id=int(instance["id"]),
                execution_id=self._ri_require("execution_id",
                                              instance.get("execution_id")),
                artifact_path=instance.get("artifact_path"),
                params_fingerprint=self._ri_require(
                    "params_fingerprint", instance.get("params_fingerprint")),
                rls_signature=self._ri_require(
                    "rls_signature", instance.get("rls_signature")),
                semantic_version=self._ri_require(
                    "semantic_version", instance.get("semantic_version")),
                source_version=instance.get("source_version"),
                row_count=instance.get("row_count"),
                business_date=(str(business_date) if business_date else None),
                role=role,
                signed_by=signed_by,
                note=(str(note) if note else None),
                status="active",
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_report_instance_signoff(self, signoff_id: int,
                                    ) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            r = session.query(ReportInstanceSignoff).filter(
                ReportInstanceSignoff.id == int(signoff_id)).first()
            return r.to_dict() if r else None

    def list_report_instance_signoffs(self, *, report_id: Optional[int] = None,
                                      instance_id: Optional[int] = None,
                                      params_fingerprint: Optional[str] = None,
                                      rls_signature: Optional[str] = None,
                                      active_only: bool = True,
                                      limit: int = 500) -> List[Dict[str, Any]]:
        """Sign-off rows, newest first.  Every filter is exact-match; a
        blank ``rls_signature`` is refused (it would wildcard scopes)."""
        with self.get_session(read_only=True) as session:
            q = session.query(ReportInstanceSignoff)
            if report_id is not None:
                q = q.filter(ReportInstanceSignoff.report_id == int(report_id))
            if instance_id is not None:
                q = q.filter(ReportInstanceSignoff.instance_id == int(instance_id))
            if params_fingerprint is not None:
                q = q.filter(ReportInstanceSignoff.params_fingerprint
                             == self._ri_require("params_fingerprint",
                                                 params_fingerprint))
            if rls_signature is not None:
                q = q.filter(ReportInstanceSignoff.rls_signature
                             == self._ri_require("rls_signature", rls_signature))
            if active_only:
                q = q.filter(ReportInstanceSignoff.status == "active")
            rows = q.order_by(ReportInstanceSignoff.signed_at.desc(),
                              ReportInstanceSignoff.id.desc()).limit(int(limit)).all()
            return [r.to_dict() for r in rows]

    def revoke_report_instance_signoff(self, signoff_id: int, *,
                                       revoked_by: str, reason: str,
                                       ) -> Optional[Dict[str, Any]]:
        """Flip an active sign-off to ``revoked`` with who/when/why.  The
        row is never deleted.  ``None`` = no such row; an already-revoked
        row is returned unchanged (idempotent)."""
        revoked_by = self._ri_require("revoked_by", revoked_by)
        reason = self._ri_require("reason", reason)
        with self.get_session() as session:
            r = session.query(ReportInstanceSignoff).filter(
                ReportInstanceSignoff.id == int(signoff_id)).first()
            if not r:
                return None
            if r.status == "active":
                r.status = "revoked"
                r.revoked_by = revoked_by
                r.revoked_at = datetime.now(timezone.utc)
                r.revoke_reason = reason
                session.flush()
            return r.to_dict()

    def report_instance_is_signed(self, instance_id: int) -> bool:
        with self.get_session(read_only=True) as session:
            return bool(_active_signoff_instance_ids(session, [instance_id]))

    # ── Instance comments (2026-09-28) ──────────────────────────────────────

    def create_report_instance_comment(self, *, instance: Dict[str, Any],
                                       username: str, text: str,
                                       parent_id: Optional[int] = None,
                                       anchor: Optional[Dict[str, Any]] = None,
                                       business_date: Optional[str] = None,
                                       ) -> Dict[str, Any]:
        """Insert a comment stamped with the INSTANCE's rls_signature."""
        import re as _re
        username = self._ri_require("username", username)
        text = str(text or "")
        if not text.strip():
            raise ValueError("comment text must be non-empty")
        mentions = sorted(set(_re.findall(r"@(\w+)", text)))
        with self.get_session() as session:
            if parent_id is not None:
                parent = session.query(ReportInstanceComment).filter(
                    ReportInstanceComment.id == int(parent_id),
                    ReportInstanceComment.instance_id == int(instance["id"]),
                ).first()
                if not parent:
                    raise ValueError(
                        f"parent comment {parent_id} is not on instance "
                        f"{instance['id']}")
            row = ReportInstanceComment(
                report_id=int(instance["report_id"]),
                instance_id=int(instance["id"]),
                rls_signature=self._ri_require(
                    "rls_signature", instance.get("rls_signature")),
                business_date=(str(business_date) if business_date else None),
                parent_id=(int(parent_id) if parent_id is not None else None),
                username=username,
                text=text,
                mentions=mentions,
                anchor=(dict(anchor) if isinstance(anchor, dict) else {"kind": "instance"}),
                is_resolved=False,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def list_report_instance_comments(self, instance_id: int,
                                      limit: int = 500) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(ReportInstanceComment)
                    .filter(ReportInstanceComment.instance_id == int(instance_id))
                    .order_by(ReportInstanceComment.created_at.asc(),
                              ReportInstanceComment.id.asc())
                    .limit(int(limit)).all())
            return [r.to_dict() for r in rows]

    def count_report_instance_comments(self, instance_id: int) -> int:
        with self.get_session(read_only=True) as session:
            return int(session.query(_sa_func.count(ReportInstanceComment.id))
                       .filter(ReportInstanceComment.instance_id == int(instance_id))
                       .scalar() or 0)

    def get_report_instance_comment(self, comment_id: int,
                                    ) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            r = session.query(ReportInstanceComment).filter(
                ReportInstanceComment.id == int(comment_id)).first()
            return r.to_dict() if r else None

    def update_report_instance_comment(self, comment_id: int, *,
                                       text: Optional[str] = None,
                                       is_resolved: Optional[bool] = None,
                                       ) -> Optional[Dict[str, Any]]:
        import re as _re
        with self.get_session() as session:
            r = session.query(ReportInstanceComment).filter(
                ReportInstanceComment.id == int(comment_id)).first()
            if not r:
                return None
            if text is not None:
                if not str(text).strip():
                    raise ValueError("comment text must be non-empty")
                r.text = str(text)
                r.mentions = sorted(set(_re.findall(r"@(\w+)", r.text)))
            if is_resolved is not None:
                r.is_resolved = bool(is_resolved)
            session.flush()
            return r.to_dict()

    def delete_report_instance_comment(self, comment_id: int) -> bool:
        with self.get_session() as session:
            r = session.query(ReportInstanceComment).filter(
                ReportInstanceComment.id == int(comment_id)).first()
            if not r:
                return False
            session.delete(r)
            # replies go with their parent
            session.query(ReportInstanceComment).filter(
                ReportInstanceComment.parent_id == int(comment_id)).delete(
                    synchronize_session=False)
            return True
