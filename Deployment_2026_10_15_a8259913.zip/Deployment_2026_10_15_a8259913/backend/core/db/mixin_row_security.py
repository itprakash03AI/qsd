"""Row & Column Security mixin — Phase 141.

CRUD helpers for ``RowLevelPolicy``, ``ColumnPolicy``, ``PolicyBinding``, and
``RowSecurityAuditLog``.  Resolution logic lives in ``core.row_security.resolver``
so this mixin stays a thin DB layer.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from core.db.models import (
    RowLevelPolicy,
    ColumnPolicy,
    PolicyBinding,
    RowSecurityAuditLog,
)

_log = logging.getLogger(__name__)


class RowSecurityMixin:

    # ── RowLevelPolicy CRUD ─────────────────────────────────────────────────

    def list_row_policies(
        self,
        enabled_only: bool = False,
        connection_id: Optional[int] = None,
        source: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(RowLevelPolicy)
            if enabled_only:
                q = q.filter(RowLevelPolicy.enabled == True)  # noqa: E712
            if connection_id is not None:
                q = q.filter(
                    (RowLevelPolicy.connection_id == connection_id)
                    | (RowLevelPolicy.connection_id.is_(None))
                )
            if source:
                q = q.filter(RowLevelPolicy.source == source)
            return [p.to_dict() for p in
                    q.order_by(RowLevelPolicy.priority.asc(),
                                RowLevelPolicy.id.asc()).all()]

    def get_row_policy(self, policy_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            p = session.query(RowLevelPolicy).filter(
                RowLevelPolicy.id == policy_id
            ).first()
            return p.to_dict() if p else None

    def get_row_policy_by_external(self, source: str, external_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            p = session.query(RowLevelPolicy).filter(
                RowLevelPolicy.source == source,
                RowLevelPolicy.external_id == external_id,
            ).first()
            return p.to_dict() if p else None

    def create_row_policy(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = RowLevelPolicy(**kwargs)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def update_row_policy(self, policy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(RowLevelPolicy).filter(
                RowLevelPolicy.id == policy_id
            ).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def delete_row_policy(self, policy_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(RowLevelPolicy).filter(
                RowLevelPolicy.id == policy_id
            ).first()
            if not p:
                return False
            session.query(PolicyBinding).filter(
                PolicyBinding.policy_kind == "row",
                PolicyBinding.policy_id == policy_id,
            ).delete()
            session.delete(p)
            return True

    def _ensure_policy_classes(self) -> Dict[str, int]:
        """FB-45 migration rule: every row policy with NO class is stamped
        ``restrictive`` explicitly, so its composed predicate is byte-for-byte
        what the pre-FB-45 AND produced.  Nobody's data exposure changes
        because they upgraded; ``permissive`` applies only to policies
        authored afterwards.  Idempotent: only NULL classes are touched, and
        every authoring path stores an explicit class, so a second run stamps
        nothing.  "Restamp as permissive" is an explicit audited admin action
        (``POST /api/admin/row-security/policies/restamp``), never this."""
        from core.row_security.composition import LEGACY_CLASS
        with self.get_session() as session:
            n = session.query(RowLevelPolicy).filter(
                RowLevelPolicy.policy_class.is_(None)
            ).update({RowLevelPolicy.policy_class: LEGACY_CLASS,
                      # A migration stamp is not an edit: keep updated_at
                      # (the ORM would otherwise apply the column's onupdate
                      # and every pod start would move the policy-set
                      # fingerprint -- measured 2026-09-20 as a cross-process
                      # scope-signature mismatch).  NULL and "restrictive"
                      # compose identically, so nothing observable changed.
                      RowLevelPolicy.updated_at: RowLevelPolicy.updated_at},
                     synchronize_session=False)
        n = int(n or 0)
        if n:
            _log.info("row_level_policies: %d pre-existing polic%s stamped %r "
                      "(FB-45 migration rule: composition unchanged by the upgrade)",
                      n, "y" if n == 1 else "ies", LEGACY_CLASS)
        return {"stamped": n}

    def restamp_row_policies(self, policy_ids: Optional[List[int]],
                             policy_class: str, updated_by: Optional[str]
                             ) -> List[Dict[str, Any]]:
        """The explicit action: set ``policy_class`` on the named policies
        (all row policies when ``policy_ids`` is None).  Returns
        ``[{id, name, from, to}]`` for the audit event."""
        from core.row_security.composition import normalise_class
        cls = normalise_class(policy_class)
        if cls is None:
            raise ValueError(f"policy_class must be permissive or restrictive, got {policy_class!r}")
        changed: List[Dict[str, Any]] = []
        with self.get_session() as session:
            q = session.query(RowLevelPolicy)
            if policy_ids is not None:
                q = q.filter(RowLevelPolicy.id.in_(list(policy_ids)))
            for p in q.order_by(RowLevelPolicy.id.asc()).all():
                before = p.policy_class
                if before == cls:
                    continue
                p.policy_class = cls
                p.updated_by = updated_by
                changed.append({"id": p.id, "name": p.name, "from": before, "to": cls})
            session.flush()
        return changed

    # ── ColumnPolicy CRUD ───────────────────────────────────────────────────

    def list_column_policies(
        self,
        enabled_only: bool = False,
        connection_id: Optional[int] = None,
        source: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ColumnPolicy)
            if enabled_only:
                q = q.filter(ColumnPolicy.enabled == True)  # noqa: E712
            if connection_id is not None:
                q = q.filter(
                    (ColumnPolicy.connection_id == connection_id)
                    | (ColumnPolicy.connection_id.is_(None))
                )
            if source:
                q = q.filter(ColumnPolicy.source == source)
            return [p.to_dict() for p in
                    q.order_by(ColumnPolicy.priority.asc(),
                                ColumnPolicy.id.asc()).all()]

    def get_column_policy(self, policy_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            p = session.query(ColumnPolicy).filter(
                ColumnPolicy.id == policy_id
            ).first()
            return p.to_dict() if p else None

    def create_column_policy(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ColumnPolicy(**kwargs)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def update_column_policy(self, policy_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ColumnPolicy).filter(
                ColumnPolicy.id == policy_id
            ).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def delete_column_policy(self, policy_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ColumnPolicy).filter(
                ColumnPolicy.id == policy_id
            ).first()
            if not p:
                return False
            session.query(PolicyBinding).filter(
                PolicyBinding.policy_kind == "column",
                PolicyBinding.policy_id == policy_id,
            ).delete()
            session.delete(p)
            return True

    # ── PolicyBinding CRUD ──────────────────────────────────────────────────

    def list_policy_bindings(
        self,
        policy_kind: Optional[str] = None,
        policy_id: Optional[int] = None,
        principal_type: Optional[str] = None,
        principal_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(PolicyBinding)
            if policy_kind:
                q = q.filter(PolicyBinding.policy_kind == policy_kind)
            if policy_id is not None:
                q = q.filter(PolicyBinding.policy_id == policy_id)
            if principal_type:
                q = q.filter(PolicyBinding.principal_type == principal_type)
            if principal_id:
                q = q.filter(PolicyBinding.principal_id == principal_id)
            return [b.to_dict() for b in
                    q.order_by(PolicyBinding.priority.asc(),
                                PolicyBinding.id.asc()).all()]

    def create_policy_binding(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            b = PolicyBinding(**kwargs)
            session.add(b)
            session.flush()
            session.refresh(b)
            return b.to_dict()

    def delete_policy_binding(self, binding_id: int) -> bool:
        with self.get_session() as session:
            b = session.query(PolicyBinding).filter(
                PolicyBinding.id == binding_id
            ).first()
            if not b:
                return False
            session.delete(b)
            return True

    def delete_policy_bindings_for(self, policy_kind: str, policy_id: int) -> int:
        with self.get_session() as session:
            n = session.query(PolicyBinding).filter(
                PolicyBinding.policy_kind == policy_kind,
                PolicyBinding.policy_id == policy_id,
            ).delete()
            return int(n or 0)

    # ── Resolution helper (used by resolver) ────────────────────────────────

    def find_applicable_policies(
        self,
        principal_ids: List[str],
        connection_id: Optional[int],
        kind: str,
    ) -> List[Dict[str, Any]]:
        """Return enabled policies where ANY of ``principal_ids`` has a binding.

        ``principal_ids`` typically = ``["user:alice", "role:analyst",
        "group:finance", "all:*"]`` — the resolver builds this list.

        Policies are scoped to ``connection_id`` OR connection_id IS NULL
        (cross-connection policies).  Ordered by priority ascending.
        """
        if kind not in ("row", "column"):
            raise ValueError(f"kind must be 'row' or 'column', got {kind!r}")
        if not principal_ids:
            return []

        # Split principal_ids of form "type:id" into two parallel lists
        pairs = []
        for p in principal_ids:
            if ":" in p:
                t, _, i = p.partition(":")
                pairs.append((t, i))
        if not pairs:
            return []

        with self.get_session(read_only=True) as session:
            from sqlalchemy import and_, or_

            # Find policy ids matching any (principal_type, principal_id) pair
            bind_filter = or_(*[
                and_(
                    PolicyBinding.principal_type == t,
                    PolicyBinding.principal_id == i,
                )
                for t, i in pairs
            ])
            bind_q = session.query(PolicyBinding.policy_id).filter(
                PolicyBinding.policy_kind == kind,
                bind_filter,
            ).distinct()
            policy_ids = {row[0] for row in bind_q.all()}
            if not policy_ids:
                return []

            Model = RowLevelPolicy if kind == "row" else ColumnPolicy
            pq = session.query(Model).filter(
                Model.id.in_(policy_ids),
                Model.enabled == True,  # noqa: E712
            )
            if connection_id is not None:
                pq = pq.filter(
                    (Model.connection_id == connection_id)
                    | (Model.connection_id.is_(None))
                )
            return [p.to_dict() for p in
                    pq.order_by(Model.priority.asc(),
                                 Model.id.asc()).all()]

    def find_policies_any_principal(
        self,
        connection_id: Optional[int],
        kind: str,
    ) -> List[Dict[str, Any]]:
        """Enabled policies on ``connection_id``, IGNORING principal bindings.

        2026-08-19.  ``find_applicable_policies`` answers "which policies bind
        to THIS principal", which cannot distinguish the two cases that matter
        when a principal could not be resolved:

          * the table has no policies at all -- RLS is simply not configured
            for it, and running unfiltered is correct;
          * the table HAS policies, and we cannot tell whether they apply --
            running unfiltered silently returns rows a policy excludes.

        Only the second must refuse.  Without this lookup both look identical
        (an empty policy list), which is how a fabricated ``groups: []``
        principal came to widen results while calling itself least-privilege.
        """
        if kind not in ("row", "column"):
            raise ValueError(f"kind must be 'row' or 'column', got {kind!r}")
        with self.get_session(read_only=True) as session:
            Model = RowLevelPolicy if kind == "row" else ColumnPolicy
            pq = session.query(Model).filter(Model.enabled == True)  # noqa: E712
            if connection_id is not None:
                pq = pq.filter(
                    (Model.connection_id == connection_id)
                    | (Model.connection_id.is_(None))
                )
            return [p.to_dict() for p in
                    pq.order_by(Model.priority.asc(), Model.id.asc()).all()]

    # ── Audit log ───────────────────────────────────────────────────────────

    def record_row_security_audit(
        self,
        username: str,
        role: Optional[str],
        table_ref: str,
        connection_id: Optional[int],
        row_policies: List[Dict[str, Any]],
        column_policies: List[Dict[str, Any]],
        mode: str,
        sql_before: Optional[str] = None,
        sql_after: Optional[str] = None,
        request_id: Optional[str] = None,
        notes: Optional[str] = None,
        max_sql_len: int = 8000,
        composition: Optional[str] = None,
    ) -> None:
        try:
            with self.get_session() as session:
                session.add(RowSecurityAuditLog(
                    composition=(composition or None),
                    username=(username or "unknown")[:100],
                    role=role,
                    table_ref=table_ref[:500],
                    connection_id=connection_id,
                    row_policies=row_policies or [],
                    column_policies=column_policies or [],
                    mode=mode,
                    sql_before=(sql_before or "")[:max_sql_len] or None,
                    sql_after=(sql_after or "")[:max_sql_len] or None,
                    request_id=request_id,
                    notes=notes,
                ))
        except Exception as exc:
            _log.warning("row_security audit insert failed (non-fatal): %s", exc)

    def list_row_security_audit(
        self,
        username: Optional[str] = None,
        table_ref: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(RowSecurityAuditLog).order_by(
                RowSecurityAuditLog.ts.desc()
            )
            if username:
                q = q.filter(RowSecurityAuditLog.username == username)
            if table_ref:
                q = q.filter(RowSecurityAuditLog.table_ref == table_ref)
            if since:
                q = q.filter(RowSecurityAuditLog.ts >= since)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def cleanup_row_security_audit(self, retain_days: int) -> int:
        """Delete audit rows older than ``retain_days``.  Returns rows deleted."""
        if retain_days <= 0:
            return 0
        cutoff = datetime.now(timezone.utc) - timedelta(days=retain_days)
        with self.get_session() as session:
            n = session.query(RowSecurityAuditLog).filter(
                RowSecurityAuditLog.ts < cutoff
            ).delete()
            return int(n or 0)
