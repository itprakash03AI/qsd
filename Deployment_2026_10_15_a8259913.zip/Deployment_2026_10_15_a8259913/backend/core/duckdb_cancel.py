"""Phase 131 deep-dive #13 — cooperative DuckDB cancel via ``con.interrupt()``.

Extracted from ``api.execute_api._spawn_duckdb_interrupt_watchdog`` so the
same watchdog mechanism can be reused by the federation engine, the reports
RLS-rewrite path, and any other site that runs a blocking
``con.execute(sql)`` on a DuckDB connection.

Why this matters: without a watchdog, ``con.execute(sql)`` holds the worker
thread for the full duration of the query.  The per-execution cancel_event
flips to True when the user clicks Cancel, but the engine has nowhere to
observe it until the next chunk boundary — and metadata-only queries
(``COUNT(*) / aggregates / partition probes``) often have no chunk
boundary at all, so the worker hangs until the query naturally completes.

``con.interrupt()`` is thread-safe in DuckDB and aborts the in-flight
statement.  The watchdog polls the cancel_event every 500 ms and fires
interrupt() on the first observation, then exits.  Tear-down is
controlled by the caller via the returned stop_event (must be set in a
finally block so the daemon thread exits cleanly when the query finishes
on its own).
"""
from __future__ import annotations

import logging
import threading
from typing import Optional

logger = logging.getLogger(__name__)


#: Appended to a worker-thread error that DuckDB reported as an interrupt
#: (see ``is_masked_worker_error``).  Kept short: the multi-worker
#: dispatcher shows the first 160 characters of a worker's message.
MASKED_WORKER_ERROR_NOTE = (
    "no cancel was requested -- DuckDB reports a query error raised on one "
    "of its own worker threads mid-stream as INTERRUPT and drops the real "
    "error; re-run the query single-engine to see it"
)


def is_masked_worker_error(exc: BaseException, cancel_requested: bool) -> bool:
    """True when ``exc`` is DuckDB's ``INTERRUPT Error: Interrupted!`` and
    nobody asked for an interrupt -- i.e. a QUERY error wearing a cancel's
    label.

    2026-09-26, read in the DuckDB 1.5.3 source and reproduced on the CI
    replica: when a query error is raised on one of DuckDB's own worker
    threads, ``Executor::PushError`` pushes the real error and then flips
    ``ClientContext::interrupted``.  A streaming result's pulling thread
    checks that flag at the top of ``SimpleBufferedData::ExecuteTaskInternal``
    and throws a BARE ``InterruptException`` there, before re-entering
    ``ClientContext::ExecuteTaskInternal`` -- the only place that swaps an
    interrupt for ``executor.GetError()``.  The Arrow reader then surfaces
    ``OSError: INTERRUPT Error: Interrupted!`` and the real message (e.g. a
    Conversion Error) is gone.  The window is a few hundred ns unless the
    pulling thread is preempted; on a 2-CPU cgroup where DuckDB still
    spawns one thread per HOST cpu that is ~3% of failing queries.

    The only legitimate producers of an INTERRUPT in this codebase are the
    cancel watchdogs (``spawn_interrupt_watchdog`` here, the thread-lane
    watcher in ``core.multi_worker_executor``) and they fire on a cancel
    event -- so INTERRUPT with no cancel requested is this race, and must be
    reported as a query failure, never as a cancel.  The real message cannot
    be recovered through the Python API (the executor holding it is torn
    down with the stream), so callers NAME the class instead: the feed
    engine re-raises (``feed_engine._reraise_stream_abort``), the thread
    lane annotates the worker's recorded error, and ``duckdb_subprocess``
    re-runs its canonical COPY (cheap there, not here).
    """
    if cancel_requested:
        return False
    return "INTERRUPT" in str(exc).upper()


def spawn_interrupt_watchdog(
    con,
    cancel_event: threading.Event,
    execution_id: str = "",
) -> threading.Event:
    """Watch ``cancel_event``; call ``con.interrupt()`` when it flips.

    Caller MUST set the returned stop_event in a finally block to wind the
    watchdog down once the query finishes (success or error).  Failing to
    do so leaks a daemon thread per execution.
    """
    stop_event = threading.Event()

    def _watchdog() -> None:
        while not stop_event.is_set():
            if cancel_event.is_set():
                try:
                    con.interrupt()
                    logger.info("[execution %s] DuckDB interrupt() called via watchdog",
                                execution_id)
                except Exception as exc:
                    logger.debug("[execution %s] interrupt() failed: %s",
                                 execution_id, exc)
                return
            stop_event.wait(0.5)

    t = threading.Thread(
        target=_watchdog,
        name=f"qs-interrupt-{(execution_id or 'anon')[:8]}",
        daemon=True,
    )
    t.start()
    return stop_event


def lookup_cancel_event(execution_id: str) -> Optional[threading.Event]:
    """Look up the cancel_event registered for ``execution_id`` in the
    worker pool, or return None if no record is registered yet.

    Best-effort — never raises.  Returning None means "no cancel support"
    and the caller should run the query normally without a watchdog.
    """
    if not execution_id:
        return None
    try:
        from core.worker_pool import get_pool
        wp = get_pool()
        # 2026-08-10 -- was ``hasattr(wp, "get_active")`` then
        # ``wp.get_active(execution_id)``.  WorkerPool has never had a
        # ``get_active``; the method is ``get_cancel_event``.  So the hasattr
        # guard was ALWAYS False and this function ALWAYS returned None --
        # cancellation via the worker pool was silently dead, and the guard
        # is what made it silent instead of an AttributeError.
        #
        # ``get_active_tasks`` is NOT the right rename: it takes a WorkType
        # and returns a list of dicts.  ``get_cancel_event(execution_id)`` is
        # precisely the two-step lookup this code was hand-rolling.
        if wp is None or not hasattr(wp, "get_cancel_event"):
            return None
        ev = wp.get_cancel_event(execution_id)
        if isinstance(ev, threading.Event):
            return ev
    except Exception as exc:
        logger.debug("lookup_cancel_event failed for %s: %s", execution_id, exc)
    return None


def maybe_spawn_watchdog(con, execution_id: str) -> Optional[threading.Event]:
    """Convenience wrapper: lookup cancel_event + spawn watchdog in one call.

    Returns the stop_event when a watchdog was spawned, or None when no
    cancel_event was registered for this execution.  Caller pattern::

        stop = maybe_spawn_watchdog(con, execution_id)
        try:
            con.execute(sql).fetchdf()
        finally:
            if stop is not None:
                stop.set()
    """
    ev = lookup_cancel_event(execution_id)
    if ev is None:
        return None
    return spawn_interrupt_watchdog(con, ev, execution_id)
