"""Phase 131 deep-dive #13 (round 16) — feed-execution performance capture.

Single-purpose helpers that wire the same BQB-parity log + stage
capture machinery (``core.execution_log_buffer`` +
``core.execution_stage``) into feed_engine.  Each function is small
and named for one job — easy to debug, easy to reuse from any caller
that wants the same per-execution timeline.

The data shape we emit matches ``query_executions.files_metadata`` so
the frontend ``ExecutionPerformanceChip`` rendering can be reused
(via a feed-specific endpoint + thin chip wrapper).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def begin_log_capture(execution_id: str):
    """Start per-execution log + stage capture for a feed run.

    Returns an opaque context object that must be passed to
    :func:`end_log_capture`.  When the import or contextvar setup
    fails, returns ``None`` (no-op) — feed execution proceeds without
    log capture.

    Idempotent at the contextvar level — nested calls override but
    restore on exit.
    """
    try:
        from core.execution_log_buffer import (
            install as _install, with_execution_id as _with)
        # 2026-10-07 -- the capture HANDLER was installed only by the BQB
        # path (execute_api), so a pod that had never served a BQB query
        # (the scheduler pod, a dedicated feed worker) bound the context
        # to a handler that was not there and stored NO log lines.  A feed
        # run installs it itself; idempotent (re-attaches if stripped).
        _install()
        ctx = _with(execution_id)
        ctx.__enter__()
        return ctx
    except Exception as exc:
        logger.debug("feed_perf: begin_log_capture skipped (%s)", exc)
        return None


def end_log_capture(ctx: Optional[Any], execution_id: str) -> None:
    """Release the log-capture context AND call
    ``execution_stage.end_execution`` to free registry memory.

    Safe to call multiple times / with ``ctx=None``.
    """
    if ctx is not None:
        try:
            ctx.__exit__(None, None, None)
        except Exception as exc:
            logger.debug("feed_perf: log_capture exit failed (%s)", exc)
    try:
        from core.execution_stage import end_execution as _end
        _end(execution_id)
    except Exception as exc:
        logger.debug("feed_perf: end_execution failed (%s)", exc)


def capture_perf_metadata(execution_id: str) -> Dict[str, Any]:
    """Compose the BQB-shape ``files_metadata`` payload for this run.

    Returns a dict with up to two keys:

      - ``stage_history`` — ``{stages, total_seconds, extras}`` from
        :func:`core.execution_stage.finalise_history`.  Empty if no
        stages were recorded.
      - ``log_lines``     — list of ``{ts, level, logger, msg, stage}``
        drained from the per-execution log buffer.  Empty if no logs
        were captured.

    Either key may be absent.  Returns ``{}`` when nothing was captured
    (e.g. registry / buffer initialisation failed).  Never raises.
    """
    out: Dict[str, Any] = {}
    try:
        from core.execution_stage import finalise_history as _fin
        hist = _fin(execution_id)
        if hist and hist.get("stages"):
            out["stage_history"] = hist
    except Exception as exc:
        logger.debug("feed_perf: finalise_history failed (%s)", exc)
    try:
        from core.execution_log_buffer import drain as _drain
        logs = _drain(execution_id) or []
        if logs:
            # Strip the internal monotonic-time field before persisting
            # (matches execute_api's filter at line 4038).
            out["log_lines"] = [
                {k: v for k, v in r.items() if k != "_mt"}
                for r in logs
            ]
    except Exception as exc:
        logger.debug("feed_perf: drain logs failed (%s)", exc)
    # ── 2026-07-18 COMPLETENESS CERTIFICATE — surface the feed's SOURCE-READ
    # trust verdict.  A feed's source query runs through the iceberg reader,
    # which (Phase 2a) builds the certificate and pushes it to the per-execution
    # diagnostic store under THIS execution_id (feed_engine sets it via
    # set_current_execution_id(exec_id)).  Capture it here so it rides into
    # feed_executions.files_metadata and /api/feed-executions surfaces a
    # Complete / Incomplete / Unverified badge — the SAME rail reports use.
    # Observational + fail-open: absence simply omits the key (a feed whose
    # source is not an Iceberg read, or a subprocess/cross-pod reader, has no
    # entry — honest omission, never a fabricated verdict).
    try:
        from core.query_diagnostic_store import get_pruning as _get_pruning
        _cert = (_get_pruning(execution_id) or {}).get("completeness_certificate")
        if _cert:
            out["completeness_certificate"] = _cert
    except Exception as exc:
        logger.debug("feed_perf: completeness certificate capture failed (%s)", exc)
    return out


def build_feed_certificate(
    execution_id: str,
    *,
    subject_id: Any,
    source_rows: Optional[int],
    dest_rows: Optional[int],
    sentinel_state: Any = None,
    issued_at: Any = None,
) -> Optional[Dict[str, Any]]:
    """Build the FEED-scope Completeness Certificate for a COMPLETED feed run.

    2026-07-22 — closes the "feed run shows UNVERIFIED forever" gap.  Previously
    a feed surfaced only its SOURCE-READ query-scope certificate, which is
    honestly UNVERIFIED in fast (pruned) mode (rows_read isn't finalised, so
    completeness/scan-ledger/freshness are all UNKNOWN).  But a feed is a WRITE
    we control end-to-end: it is COMPLETE when it provably moved every source row
    into the delivered file and the source table is not quarantined — exactly the
    FEED scope's required signals (reconciliation + sentinel; freshness NOT
    required — a fresh WRITE is current by construction).

    This helper fuses:
      • RECONCILIATION — ``source_rows`` (rows the engine produced from the
        source into the output) vs ``dest_rows`` (rows PHYSICALLY present in the
        delivered file, independently recounted by ``feed.file_integrity``).
        Equal ⇒ every produced row reached the file.  A mismatch ⇒ INCOMPLETE.
      • The SOURCE-READ certificate's hard-negatives — if the source read itself
        proved INCOMPLETE / over-count, or the table is quarantined, those fuse
        in from the diagnostic store so a broken source can never yield a false
        feed COMPLETE.  (Its fast-mode UNKNOWNs are NOT required for feed scope,
        so they never withhold the verdict.)

    Fail-open: returns ``None`` on any error (caller then keeps the source-read
    cert / omits — never a fabricated verdict).
    """
    try:
        import core.completeness_certificate as _cert
        if not _cert.enabled():
            return None

        # Reconstruct a minimal out_meta from the source-read cert so its
        # hard-negatives (and sentinel/quarantine) re-fuse into the feed verdict.
        om: Dict[str, Any] = {}
        _sentinel = sentinel_state
        try:
            from core.query_diagnostic_store import get_pruning as _gp
            _src = (_gp(execution_id) or {}).get("completeness_certificate")
        except Exception:
            _src = None
        if isinstance(_src, dict):
            _ev = _src.get("evidence") or {}
            if isinstance(_ev.get("completeness"), dict):
                om["completeness"] = _ev["completeness"]
            if isinstance(_ev.get("scan_ledger"), dict):
                om["scan_ledger"] = _ev["scan_ledger"]
            # 2026-08-20 — hard negatives must survive the re-fuse.  The
            # file_cap (BF-579 slice / listing-cap truncation) and
            # pruning_gate evidence were NOT copied, so a source read the
            # certificate itself called INCOMPLETE could still yield a
            # clean feed certificate (both feed-required signals passing).
            if isinstance(_ev.get("file_cap"), dict):
                om["file_cap"] = _ev["file_cap"]
            if isinstance(_ev.get("pruning_gate"), dict):
                om["pruning_gate"] = _ev["pruning_gate"]
            if _src.get("snapshot_id"):
                om["snapshot_id"] = _src["snapshot_id"]
            if _sentinel is None and isinstance(_ev.get("sentinel"), dict):
                _sentinel = _ev["sentinel"]   # carries the quarantined flag
        # 2026-08-03 (C2) — UNKNOWN=UNSAFE.  Previously a missing source-read
        # cert coerced ``_sentinel = False`` (affirmatively "not quarantined"),
        # on the reasoning that "a feed WRITE cannot be quarantined".  That
        # reasoning is wrong for the COMMON case: subprocess / cross-pod
        # source reads leave NO entry in the per-execution diagnostic store
        # (see the capture comment above), so a QUARANTINED source produced a
        # feed cert whose two required signals both passed → a false COMPLETE.
        # Absence of evidence is not evidence of absence: when no sentinel
        # evidence exists, leave it None → the sentinel signal evaluates
        # UNKNOWN → the verdict is withheld as UNVERIFIED (honest), never a
        # fabricated COMPLETE.  Callers that affirmatively KNOW there is no
        # prunable source may pass ``sentinel_state=False`` explicitly.

        recon: Optional[Dict[str, Any]] = None
        if source_rows is not None and dest_rows is not None:
            _sr, _dr = int(source_rows), int(dest_rows)
            recon = {"source_rows": _sr, "dest_rows": _dr,
                     "break_detected": _sr != _dr}

        cert = _cert.build_certificate(
            _cert.SCOPE_FEED, str(subject_id),
            out_meta=om, reconciliation=recon,
            sentinel_state=_sentinel, issued_at=issued_at,
        )
        return cert.to_dict()
    except Exception as exc:
        logger.debug("feed_perf: build_feed_certificate failed (%s)", exc)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Flow-B (webhook) completion verification — 2026-08-05.
#
# Feeds have two completion flows.  Flow A (QS-triggered) runs the shared
# convert → integrity → certificate pipeline in feed_engine.  Flow B — the
# factory-scheduled Spark-batch DAG posting /api/webhooks/feed-complete —
# marked the run completed with the caller's row counts and NO CERTIFICATE
# AT ALL: the scheduled overnight runs, exactly where nobody is watching,
# got no completeness verification while interactive runs did.
#
# This helper closes that gap by REUSING the same pieces Flow A uses:
#   * an INDEPENDENT server-side recount of the delivered output
#     (``feed.file_integrity`` — the same module that backs Flow A's
#     reconciliation), constrained to the allowed local destination roots;
#   * ``build_feed_certificate`` above — the same certificate builder, so
#     both flows reach their verdict by the same code.
#
# UNKNOWN = UNSAFE: a delivered output that cannot be recounted (remote
# s3a://sftp/oracle URIs, compressed text parts, path outside the allowed
# roots, path not visible from this pod) yields NO dest evidence — the
# certificate then reads UNVERIFIED, never COMPLETE.  A recount that
# disagrees with the reported count reads INCOMPLETE (hard negative).
# ─────────────────────────────────────────────────────────────────────────────


def verify_webhook_completion(
    *,
    execution_id: str,
    subject_id: Any,
    output_path: Optional[str],
    reported_rows: Any,
    issued_at: Any = None,
    destination_rows: Any = None,
    delivery_receipt: Any = None,
) -> Dict[str, Any]:
    """Server-side verification for a webhook-completed (Flow B) feed run.

    ``delivery_receipt`` (2026-10-07, D1): the receipt a job that delivered
    ITSELF reports -- the same shape native's transports fill
    (``core/feed/delivery_protocol.receipt``: the transfer's verification,
    the rows the job's renderer wrote, its own recount of the file it
    rendered).  The destination evidence is then chosen by THE rule,
    ``core.feed.delivery_verdict.certified_dest_rows``, exactly as the
    native engine chooses it; a job image that reports no receipt keeps
    the old answer (a local recount, else none -> UNVERIFIED).

    ``destination_rows`` (2026-10-07): the DESTINATION's own count, when the
    job delivered into a database and the database counted (an Oracle
    publish: rows inserted, rejected ones excluded).  It is the evidence
    the certificate reconciles against -- the same priority native gives
    its Oracle receipt's ``delivered_rows`` (``_certificate_dest_rows``) --
    because a remote table cannot be recounted from this pod.

    Returns a ``files_metadata`` fragment:
    ``{"completeness_certificate": {...}, "webhook_verification": {...}}``.
    Fail-open on its own errors (returns whatever it could build — the
    certificate builder itself already fails closed to UNVERIFIED); never
    raises into the webhook handler.
    """
    import os
    import re
    import time

    verification: Dict[str, Any] = {
        "output_path": output_path or "",
        "reported_rows": reported_rows if isinstance(reported_rows, int) else None,
        "recount_rows": None,
        "recountable": False,
        "reason": "",
    }
    dest_rows: Optional[int] = None
    path = (output_path or "").strip()
    receipt = dict(delivery_receipt) if isinstance(delivery_receipt, dict) \
        else None
    if isinstance(destination_rows, int) \
            and not isinstance(destination_rows, bool):
        receipt = dict(receipt or {}, delivered_rows=int(destination_rows))
    try:
        from core.feed.delivery_verdict import (
            BASIS_DESTINATION, BASIS_RECOUNT, BASIS_RENDERED,
            certified_dest_rows,
        )
        _rows, _basis = certified_dest_rows(
            receipt=receipt, rendered_rows=reported_rows)
        if _basis in (BASIS_DESTINATION, BASIS_RECOUNT, BASIS_RENDERED):
            dest_rows = _rows
            verification["recountable"] = True
            verification["recount_rows"] = dest_rows
            verification["basis"] = _basis
            verification["reason"] = {
                BASIS_DESTINATION: (
                    "destination-reported row count (the database's own "
                    "count of the rows it accepted)"),
                BASIS_RECOUNT: (
                    "the job's independent recount of the file it rendered "
                    "and delivered (transfer " + str(
                        (receipt or {}).get("verification") or "unreported")
                    + ")"),
                BASIS_RENDERED: (
                    "rows the job's renderer wrote into the file it "
                    "delivered (transfer " + str(
                        (receipt or {}).get("verification") or "unreported")
                    + ")"),
            }[_basis]
        elif not path:
            verification["reason"] = "no output_path reported by the caller"
        elif re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", path):
            verification["reason"] = (
                f"remote destination ({path.split('://', 1)[0]}://) — no "
                f"server-side recount possible from this pod"
            )
        elif not os.path.exists(path):
            verification["reason"] = "output_path does not exist on this server"
        else:
            # Same allowed-roots guard the download endpoint and local
            # delivery use — a signature-valid caller must not be able to
            # point the recount at arbitrary server files.
            _dir = path if os.path.isdir(path) else (os.path.dirname(path) or path)
            try:
                from core.feed_engine import _resolve_and_validate_local_dest_dir
                _resolve_and_validate_local_dest_dir(_dir)
            except ValueError:
                verification["reason"] = (
                    "output_path is outside the allowed local destination "
                    "roots — recount refused"
                )
            else:
                from core.feed.file_integrity import physical_row_count_delivered
                dest_rows = physical_row_count_delivered(path)
                if dest_rows is None:
                    verification["reason"] = (
                        "delivered output is not independently countable "
                        "(compressed / unknown part format / no data parts)"
                    )
                else:
                    verification["recountable"] = True
                    verification["recount_rows"] = int(dest_rows)
    except Exception as exc:
        logger.warning(
            "feed_perf: webhook recount failed for %s (%s) — certificate "
            "will reconcile without dest evidence", execution_id, exc,
        )
        verification["reason"] = f"recount error: {exc}"
        dest_rows = None

    src_rows = reported_rows if isinstance(reported_rows, int) \
        and not isinstance(reported_rows, bool) else None
    out: Dict[str, Any] = {"webhook_verification": verification}
    cert = build_feed_certificate(
        execution_id,
        subject_id=subject_id,
        source_rows=src_rows,
        dest_rows=dest_rows,
        issued_at=issued_at if issued_at is not None else time.time(),
    )
    if cert:
        out["completeness_certificate"] = cert
        if (cert.get("verdict") or "").upper() == "INCOMPLETE":
            logger.warning(
                "feed_perf: webhook-completed execution %s certified "
                "INCOMPLETE — reported %s row(s) but the delivered output "
                "holds %s", execution_id, src_rows, dest_rows,
            )
    return out
