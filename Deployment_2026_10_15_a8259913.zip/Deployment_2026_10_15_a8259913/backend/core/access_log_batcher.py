"""Published-API access-log rows, written in BATCHES off the request
(2026-10-03).

WHY
---
``api/published_views/helpers.py::_log_access`` wrote one ``api_access_log``
row per request, synchronously, ON THE EVENT LOOP (its docstring said
"fire-and-forget"; the INSERT was inline): a transaction -- checkout, ping,
BEGIN, INSERT, COMMIT -- in the middle of every published-API answer, and
the event loop blocked for it.  Measured live: under 50 paced consumers
Postgres sat at ~100% CPU and a cached call cost ~19-30 metadata
transactions; this was one of them on every call.

WHAT THE ROW IS, AND WHAT IT MUST GUARANTEE
-------------------------------------------
``api_access_log`` is the per-request USAGE record of the published API (the
publisher's "who pulled what" view, ``GET /api/published-views/{id}/access-
logs``, swept after ``api_access_log_retention_days``).  It is not the
security audit trail (``audit_log`` records authoring and administrative
actions; a cached read writes no ``audit_log`` row -- verified by statement
count, see ``tests/test_pv_cached_call_db_budget_2026_10_03.py``).  Before
this change its write was already best-effort: a failed INSERT was swallowed
by ``except Exception: pass`` in ``DatabaseManager.log_api_access`` -- lost
SILENTLY.  The requirement this module meets is therefore stronger than the
one it replaces: every row is written, or its loss is COUNTED and LOGGED.

HOW
---
* ``submit`` stamps the row's ``created_at`` (the request's time, not the
  flush's) and puts it on a BOUNDED queue -- O(1), no I/O, never blocks.
* A daemon thread per process drains the queue every
  ``published_views.access_log_flush_seconds`` (1) or as soon as
  ``access_log_batch_rows`` (500) are waiting, and writes each batch as ONE
  multi-row INSERT in one transaction.
* A full queue (``access_log_queue_max``, 10000 -- the database is not
  keeping up) DROPS the new row: the request is never slowed by its own
  usage record.  Every drop is counted and an ERROR names the count, at most
  once a minute.
* A batch whose INSERT fails on a DEAD connection (nothing was committed --
  ``DBAPIError.connection_invalidated``) is retried ONCE on a fresh one.
  Any other failure, and any failure of the COMMIT itself (ambiguous: it may
  have landed), is not retried -- retry safety is a declaration, never a
  default -- and the batch is counted LOST and logged at ERROR.
* ``flush()`` writes everything queued so far, in the caller's thread; the
  access-log reader calls it first (a publisher reading the log on this
  process sees their own last request), and ``atexit`` calls it on a clean
  process exit.  A process KILLED (SIGKILL / OOM) loses at most the rows of
  its current flush interval -- the declared bound.
* A database manager that cannot take a batch (no ``log_api_access_many``)
  is written per row, synchronously, as before;
  ``published_views.access_log_mode = "sync"`` restores that for every one.
"""
from __future__ import annotations

import atexit
import logging
import os
import queue
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: How often (at most) a drop / loss is reported per kind.
_REPORT_EVERY_S = 60.0

#: Every column ``_log_access`` supplies -- a multi-row INSERT needs the same
#: keys on every row.
ROW_KEYS = ("api_key_id", "view_id", "execution_id", "request_params",
            "response_rows", "response_ms", "status_code", "client_ip",
            "created_at")


def _cfg(key: str, fallback):
    try:
        from core.config import get as _get
        v = _get("published_views", key, fallback)
        return fallback if v is None else v
    except Exception:
        return fallback


def configured_mode() -> str:
    """``published_views.access_log_mode``: "batched" (default) | "sync"."""
    mode = str(_cfg("access_log_mode", "batched") or "batched").strip().lower()
    return "sync" if mode == "sync" else "batched"


def accepts_batches(db_manager: Any) -> bool:
    """Can this manager take a batch?  (A test double usually cannot.)"""
    return callable(getattr(type(db_manager), "log_api_access_many", None))


class AccessLogBatcher:
    """A bounded queue of access-log rows and the thread that writes them."""

    def __init__(self, *, flush_seconds: float = 1.0, batch_rows: int = 500,
                 queue_max: int = 10000, clock=time.monotonic):
        self.flush_seconds = max(0.05, float(flush_seconds))
        self.batch_rows = max(1, int(batch_rows))
        self.queue_max = max(1, int(queue_max))
        self._clock = clock
        self._q: "queue.Queue" = queue.Queue(maxsize=self.queue_max)
        self._write_lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._thread_lock = threading.Lock()
        self._pid = os.getpid()
        self._stats_lock = threading.Lock()
        self._stats = {"submitted": 0, "written": 0, "batches": 0,
                       "dropped_queue_full": 0, "lost_write_failed": 0}
        self._unreported = {"dropped_queue_full": 0, "lost_write_failed": 0}
        self._last_report = {"dropped_queue_full": 0.0, "lost_write_failed": 0.0}

    # ── accounting ────────────────────────────────────────────────────────

    def _count(self, key: str, n: int = 1) -> None:
        with self._stats_lock:
            self._stats[key] = self._stats.get(key, 0) + n

    def stats(self) -> Dict[str, int]:
        with self._stats_lock:
            out = dict(self._stats)
        out["queued"] = self._q.qsize()
        return out

    def _report_loss(self, kind: str, n: int, why: str) -> None:
        """Count a loss and say so at ERROR -- at most once a minute per
        kind, with the number lost since the last report."""
        self._count(kind, n)
        now = self._clock()
        with self._stats_lock:
            self._unreported[kind] += n
            if now - self._last_report[kind] < _REPORT_EVERY_S:
                return
            pending, self._unreported[kind] = self._unreported[kind], 0
            self._last_report[kind] = now
        logger.error("[pv-access-log] %d published-API access-log row(s) LOST "
                     "(%s): %s.  Total since start: %d.", pending, kind, why,
                     self.stats().get(kind, 0))

    # ── the request side ─────────────────────────────────────────────────

    def submit(self, db_manager: Any, row: Dict[str, Any]) -> bool:
        """Queue one row.  Never blocks, never raises; False = dropped."""
        try:
            item = {k: row.get(k) for k in ROW_KEYS}
            if item.get("created_at") is None:
                item["created_at"] = datetime.now(timezone.utc)
            self._ensure_thread()
            try:
                self._q.put_nowait((db_manager, item))
            except queue.Full:
                self._report_loss(
                    "dropped_queue_full", 1,
                    f"the write queue is full ({self.queue_max} rows waiting "
                    f"-- the metadata database is not keeping up); raise "
                    f"published_views.access_log_queue_max or fix the database")
                return False
            self._count("submitted")
            if self._q.qsize() >= self.batch_rows:
                self._wake.set()
            return True
        except Exception as exc:                       # pragma: no cover
            self._report_loss("lost_write_failed", 1, f"could not queue: {exc}")
            return False

    # ── the writer side ──────────────────────────────────────────────────

    def _ensure_thread(self) -> None:
        if os.getpid() != self._pid:
            # A forked child inherits the queue object but not the thread;
            # start clean (the parent's rows are the parent's to write).
            self._q = queue.Queue(maxsize=self.queue_max)
            self._thread = None
            self._pid = os.getpid()
        t = self._thread
        if t is not None and t.is_alive():
            return
        with self._thread_lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(
                target=self._run, name="pv-access-log", daemon=True)
            self._thread.start()

    def _run(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(self.flush_seconds)
            self._wake.clear()
            try:
                self.flush()
            except Exception as exc:                   # pragma: no cover
                logger.error("[pv-access-log] writer loop error: %s", exc)

    def flush(self, timeout: Optional[float] = None) -> int:
        """Write every row queued before this call; returns rows written.

        All draining happens under one lock, so a flush also waits for a
        batch the writer thread is in the middle of."""
        if not self._write_lock.acquire(timeout=-1 if timeout is None else timeout):
            return 0
        try:
            written = 0
            while True:
                batch = []
                while len(batch) < self.batch_rows:
                    try:
                        batch.append(self._q.get_nowait())
                    except queue.Empty:
                        break
                if not batch:
                    return written
                by_db: Dict[int, list] = {}
                dbs: Dict[int, Any] = {}
                for db, item in batch:
                    by_db.setdefault(id(db), []).append(item)
                    dbs[id(db)] = db
                for key, rows in by_db.items():
                    written += self._write(dbs[key], rows)
        finally:
            self._write_lock.release()

    def _write(self, db: Any, rows: list) -> int:
        try:
            db.log_api_access_many(rows)
            self._count("written", len(rows))
            self._count("batches")
            return len(rows)
        except Exception as exc:
            self._report_loss("lost_write_failed", len(rows),
                              f"the batch INSERT failed ({type(exc).__name__}: "
                              f"{str(exc)[:200]})")
            return 0

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        self._wake.set()
        t = self._thread
        if t is not None:
            t.join(timeout)
        self.flush(timeout=timeout)


_batcher: Optional[AccessLogBatcher] = None
_batcher_lock = threading.Lock()


def get_batcher() -> AccessLogBatcher:
    """The process's batcher, built from config on first use."""
    global _batcher
    b = _batcher
    if b is not None:
        return b
    with _batcher_lock:
        if _batcher is None:
            _batcher = AccessLogBatcher(
                flush_seconds=float(_cfg("access_log_flush_seconds", 1.0)),
                batch_rows=int(_cfg("access_log_batch_rows", 500)),
                queue_max=int(_cfg("access_log_queue_max", 10000)),
            )
        return _batcher


def flush_access_log(timeout: Optional[float] = 10.0) -> int:
    """Write whatever this process has queued (a no-op when nothing was)."""
    b = _batcher
    return b.flush(timeout=timeout) if b is not None else 0


def record(db_manager: Any, **row) -> None:
    """THE write: batched when the mode and the manager allow it, else the
    per-row synchronous write.  Never raises."""
    if configured_mode() == "batched" and accepts_batches(db_manager):
        get_batcher().submit(db_manager, row)
        return
    try:
        db_manager.log_api_access(**row)
    except Exception as exc:
        logger.warning("Access log write failed (sync): %s", exc)


def _flush_at_exit() -> None:                          # pragma: no cover
    try:
        flush_access_log(timeout=10.0)
    except Exception as exc:
        logger.error("[pv-access-log] flush at exit failed: %s", exc)


atexit.register(_flush_at_exit)
