"""Feed-level SQL preview helper.

Given a ``feed_config`` row, returns the SQL that would actually be
executed — without touching DuckDB / S3 / network.  Lets the
``/api/feeds/{id}/preview-sql`` endpoint surface "what query will this
feed run?" in the FeedConfigs UI so users can verify before scheduling.

Why a separate helper (not inside feed_engine):
  ``feed_engine.execute_feed`` resolves the same sources but also opens
  connections, registers DuckDB views, downloads parquet, and finally
  runs the SQL.  None of that work is needed for a preview — the user
  just wants to see the string.  Doing it in feed_engine would couple
  preview latency to S3 access + side-effect the connection pool.

Pure read-only: never opens a DuckDB connection, never touches S3,
never calls the connector.  Falls back gracefully when a source is
missing instead of raising — so the preview UI can show *why* a feed
won't run (e.g. "sql_file deleted") rather than throwing 500.

Returned dict shape:
    {
      "sql":              str,          # the resolved SQL, "" if unavailable
      "dialect":          str,          # duckdb | trino | snowflake | … | "unknown"
      "source_type":      str,          # saved_query | sql_file | published_view | raw_sql
      "source_id":        int,
      "source_name":      str,          # human-readable label
      "source_status":    str,          # ok | not_found | inactive | missing_file | empty | refused
      "source_message":   str,          # one-line explanation when status != "ok"
      #   "empty"   = the source HAS no SQL.
      #   "refused" = the SQL exists but could not be built for the
      #               connection it runs on (the RUN refuses too, by name:
      #               parquet_engine_v2.QueryNotExpressible).  A refusal is
      #               never reported as an absence - they lead to opposite
      #               investigations.
      "connection_id":    int | None,
      "connection_name":  str,
      "connection_type":  str,          # s3 | local | trino | snowflake | …
      "secondary_sql":    str | None,   # cross-connection feeds
      "secondary_connection_name": str | None,
      "combine_mode":     str | None,   # "union" | "join" | None
    }
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _connection_summary(db_manager: Any, connection_id: Optional[int]) -> Dict[str, Any]:
    """Return ``{name, type}`` for the connection — ``("", "")`` when unknown.

    Uses get_connection (NOT get_connection_raw) so we never accidentally
    surface decrypted credentials through the preview endpoint.
    """
    if not connection_id:
        return {"name": "", "type": ""}
    try:
        conn = db_manager.get_connection(connection_id)
    except Exception:
        conn = None
    if not conn:
        return {"name": f"<missing connection {connection_id}>", "type": ""}
    return {
        "name": conn.get("name") or f"connection_{connection_id}",
        "type": conn.get("connection_type") or "",
    }


def _dialect_for(conn_type: str) -> str:
    """Map a connection_type to a Monaco-friendly SQL dialect hint."""
    if not conn_type:
        return "duckdb"
    t = conn_type.lower()
    if t in ("s3", "local", "aws_s3"):
        return "duckdb"
    if t in ("trino", "starburst"):
        return "trino"
    if t in ("snowflake",):
        return "snowflake"
    if t in ("databricks",):
        return "databricks"
    if t in ("oracle",):
        return "oracle"
    if t in ("athena",):
        return "athena"
    if t == "rest":
        return "rest"
    return t or "unknown"


def _apply_run_side_shape(qcfg: Dict[str, Any], cross_side: Optional[str],
                          source_label: str) -> Dict[str, Any]:
    """Item 3 (2026-08-05) — run the SAME secondary-shape substitution the
    execution path runs (``core.feed.source_plan.apply_secondary_shape``),
    so the preview of a cross feed's secondary side shows the saved
    secondary shape, not the primary's.  Fail-open: any error keeps the
    unmodified config (preview must never 500 on shape metadata)."""
    if cross_side not in ("primary", "secondary"):
        return qcfg
    try:
        from core.feed.source_plan import apply_secondary_shape
        return apply_secondary_shape(
            dict(qcfg), {"_cross_side": cross_side}, source_label)
    except Exception as exc:
        logger.debug("[feed_preview] apply_secondary_shape failed for %s: %s",
                     source_label, exc)
        return qcfg


def _build_side_sql(db_manager: Any, qcfg: Dict[str, Any],
                    connection_id: Optional[int],
                    what: str) -> Dict[str, Any]:
    """Build a BUILDER-MODE source's SQL **for the connection it will run
    on**, and report a refusal AS a refusal.

    2026-09-05 -- two things were wrong here, and they compounded.

    *The preview did not match the run.*  Both call sites reached
    ``core.duckdb_views.build_query_sql(qcfg)`` with NO target connection,
    so a builder-mode saved query over a Trino / Snowflake / Oracle /
    Databricks / Athena connection previewed as DUCKDB grammar (``FROM
    read_parquet('...') AS t0``).  The RUN path was fixed the same day to
    thread the connection through to
    ``parquet_engine_v2.build_query_sql_for_connection``, which renders for
    the real engine or raises ``QueryNotExpressible`` naming it -- so
    preview showed SQL the run now refuses, breaking this module's own
    "preview == run BY CONSTRUCTION" claim.

    *And the refusal was rendered as an ABSENCE.*  Both sites swallowed the
    exception into ``sql = ""``, which the caller reported as
    ``status="empty"`` / "Saved query has no SQL content".  "Could not
    build this for Trino, and here is why" and "this query has no SQL" lead
    to opposite investigations; unknown is not empty is a defect class in
    this codebase, not a nicety.

    Returns ``{"sql": str, "refusal": str}`` -- ``refusal`` empty when the
    build succeeded.  Never raises: the preview must not 500.  An unknown
    or missing connection resolves to type ``""``, which
    ``build_query_sql`` treats as DuckDB exactly as before -- cannot-tell
    is not a refusal.
    """
    conn_type = _connection_summary(db_manager, connection_id)["type"]
    try:
        from core.parquet_engine_v2 import QueryNotExpressible
    except Exception:  # pragma: no cover - engine import unavailable
        QueryNotExpressible = ()  # type: ignore[assignment]
    try:
        from core.duckdb_views import build_query_sql as _build
        return {"sql": _build(qcfg, connection_type=conn_type) or "",
                "refusal": ""}
    except QueryNotExpressible as exc:
        logger.info("[feed_preview] %s cannot be expressed on %s: %s",
                    what, conn_type or "duckdb", exc)
        return {"sql": "", "refusal": str(exc)}
    except Exception as exc:
        logger.debug("[feed_preview] build_query_sql failed for %s: %s",
                     what, exc)
        return {
            "sql": "",
            "refusal": (
                "Could not build SQL for %s on %s (%s: %s). This is a build "
                "FAILURE, not an empty query -- the feed run would fail the "
                "same way." % (what, conn_type or "duckdb",
                               type(exc).__name__, exc)),
        }


def _resolve_one_side(
    db_manager: Any,
    source_type: str,
    source_id: Any,
    connection_id_override: Optional[int],
    query_params: Optional[Dict[str, Any]],
    cross_side: Optional[str] = None,
) -> Dict[str, Any]:
    """Resolve one side (primary OR secondary) to ``{sql, status, message,
    connection_id, source_name}``.  Same source-type vocabulary as
    feed_engine, but read-only.

    ``cross_side`` (2026-08-05) — ``"primary"`` / ``"secondary"`` on a
    cross-connection feed, ``"single"`` on a single-source feed, ``None``
    for RAW resolution (no run-side semantics — the cross-source
    preflight consumes the unsplit content for its own probes).  A
    non-None value routes the resolution through the SAME
    ``core.feed.source_plan`` side selection the run path uses (sql_file
    ``-- ===SECONDARY===`` splitting incl. the single-source refusal,
    saved-query secondary shapes), so preview == run BY CONSTRUCTION —
    the defect class commit 4d94c60f closed for the query builders.
    """
    if not source_type:
        return {"sql": "", "status": "empty",
                "message": "source_type not set",
                "connection_id": connection_id_override,
                "source_name": ""}

    if source_type == "saved_query":
        try:
            sq = db_manager.get_query(int(source_id)) if source_id else None
        except Exception:
            sq = None
        if not sq:
            return {"sql": "", "status": "not_found",
                    "message": f"Saved query {source_id} not found",
                    "connection_id": connection_id_override,
                    "source_name": f"saved_query:{source_id}"}
        qcfg = sq.get("query_config") or {}
        qcfg = _apply_run_side_shape(qcfg, cross_side, f"saved query {source_id}")
        sql = qcfg.get("raw_sql") or qcfg.get("custom_sql") or ""
        # The connection is resolved BEFORE the build, not after it: the
        # builder must be told where this SQL is going (the run path's
        # ``core.feed.sources.sql_branches`` does exactly this), and a
        # refusal must surface as a refusal.  Same precedence as the run.
        conn_id = connection_id_override or qcfg.get("connection_id")
        if not sql:
            built = _build_side_sql(db_manager, qcfg, conn_id,
                                    f"saved query {source_id}")
            sql = built["sql"]
            if built["refusal"]:
                return {"sql": "", "status": "refused",
                        "message": built["refusal"],
                        "connection_id": conn_id,
                        "source_name": (sq.get("name")
                                        or f"saved_query:{source_id}")}
        return {
            "sql": sql,
            "status": "ok" if sql else "empty",
            "message": "" if sql else "Saved query has no SQL content",
            "connection_id": conn_id,
            "source_name": sq.get("name") or f"saved_query:{source_id}",
        }

    if source_type == "sql_file":
        try:
            sf = db_manager.get_sql_file(int(source_id)) if source_id else None
        except Exception:
            sf = None
        if not sf:
            return {"sql": "", "status": "not_found",
                    "message": f"SQL file {source_id} not found",
                    "connection_id": connection_id_override,
                    "source_name": f"sql_file:{source_id}"}
        if not sf.get("is_active", True):
            return {"sql": "", "status": "inactive",
                    "message": "SQL file is inactive",
                    "connection_id": connection_id_override or sf.get("connection_id"),
                    "source_name": sf.get("name") or f"sql_file:{source_id}"}
        rel_path = sf.get("file_path") or ""
        sql = ""
        status = "ok"
        message = ""
        try:
            from api.sql_files_api import _get_storage_dir
            storage_root = _get_storage_dir().resolve()
            resolved = (storage_root / rel_path).resolve()
            resolved.relative_to(storage_root)  # path-traversal guard
            if not resolved.exists():
                status = "missing_file"
                message = f"On-disk file missing: {rel_path}"
            else:
                sql = resolved.read_text(encoding="utf-8")
                if not sql.strip():
                    status = "empty"
                    message = "SQL file is empty"
        except Exception as exc:
            status = "missing_file"
            message = f"Cannot read SQL file: {exc}"
        if sql and status == "ok" and cross_side is not None:
            # Item 3 (2026-08-05) — the run path splits a
            # ``-- ===SECONDARY===`` sql_file per side and REFUSES the
            # marker on a single-source feed (source_plan.select_sql_file_side).
            # The preview previously returned the UNSPLIT file for the
            # secondary side — SQL that is not what executes.  Route through
            # the SAME implementation; a run-path refusal previews as
            # status="refused" with the run's own fix-naming message.
            # (cross_side=None = RAW mode for the preflight profiler.)
            try:
                from core.feed.source_plan import select_sql_file_side
                sql = select_sql_file_side(
                    sql,
                    {"_cross_side": None if cross_side == "single" else cross_side},
                    source_id, sf.get("name") or "")
            except ValueError as exc:
                return {"sql": "", "status": "refused",
                        "message": str(exc),
                        "connection_id": connection_id_override or sf.get("connection_id"),
                        "source_name": sf.get("name") or f"sql_file:{source_id}"}
            except Exception as exc:
                logger.debug("[feed_preview] sql_file side selection failed "
                             "(showing unsplit content): %s", exc)
        return {
            "sql": sql,
            "status": status,
            "message": message,
            "connection_id": connection_id_override or sf.get("connection_id"),
            "source_name": sf.get("name") or f"sql_file:{source_id}",
        }

    if source_type == "published_view":
        try:
            pv = db_manager.get_published_view(int(source_id)) if source_id else None
        except Exception:
            pv = None
        if not pv:
            return {"sql": "", "status": "not_found",
                    "message": f"Published view {source_id} not found",
                    "connection_id": connection_id_override,
                    "source_name": f"published_view:{source_id}"}
        try:
            sq = db_manager.get_query(pv.get("query_id")) if pv.get("query_id") else None
        except Exception:
            sq = None
        qcfg = (sq.get("query_config") if sq else None) or {}
        qcfg = _apply_run_side_shape(
            qcfg, cross_side,
            f"published_view {source_id}'s saved query {pv.get('query_id')}")
        sql = qcfg.get("raw_sql") or qcfg.get("custom_sql") or ""
        # Same connection precedence the run path uses for this branch
        # (feed_config -> published_view -> saved query), resolved BEFORE
        # the build so the builder renders for the engine that executes it.
        conn_id = (
            connection_id_override
            or pv.get("connection_id")
            or qcfg.get("connection_id")
        )
        if not sql:
            built = _build_side_sql(
                db_manager, qcfg, conn_id,
                f"published view {source_id}'s saved query "
                f"{pv.get('query_id')}")
            sql = built["sql"]
            if built["refusal"]:
                return {"sql": "", "status": "refused",
                        "message": built["refusal"],
                        "connection_id": conn_id,
                        "source_name": (pv.get("name")
                                        or f"published_view:{source_id}")}
        return {
            "sql": sql,
            "status": "ok" if sql else "empty",
            "message": "" if sql else "Published view has no SQL content",
            "connection_id": conn_id,
            "source_name": pv.get("name") or f"published_view:{source_id}",
        }

    if source_type == "raw_sql":
        sql = (query_params or {}).get("sql", "") if query_params else ""
        # 2026-10-11 -- a raw_sql SECOND side reads query_params.secondary_raw_sql
        # (source_plan.secondary_side_config, the same rule the run applies).
        if cross_side == "secondary":
            _sec = (query_params or {}).get("secondary_raw_sql") if query_params else None
            if isinstance(_sec, str) and _sec.strip():
                sql = _sec
        return {
            "sql": sql,
            "status": "ok" if sql else "empty",
            "message": "" if sql else (
                "raw_sql second side has no 'secondary_raw_sql' in query_params"
                if cross_side == "secondary"
                else "raw_sql feed has no 'sql' in query_params"),
            "connection_id": connection_id_override,
            "source_name": "raw_sql",
        }

    # 2026-09-02 — non-SQL source kinds are STEP-served
    # (core/feed/steps: builtin api / landed_file + discovered steps).
    # There is no SQL to preview; surface the step's identity and the
    # THREE-outcome resolution (loaded / failed-to-load naming the file /
    # unknown listing what is registered) instead of the old
    # "Unsupported source_type".  Read-only and never raises — preview
    # must not 500 on a broken step; it must SAY the step is broken.
    try:
        from core.feed.steps import StepLoadFailed, UnknownStep, get_step
        try:
            step = get_step("source", source_type)
            desc = getattr(step, "description", "") or "step-served source"
            return {"sql": "", "status": "ok",
                    "message": (f"Step-served source '{source_type}' — "
                                f"no SQL; the extract is defined by "
                                f"query_params.source.  {desc}"),
                    "connection_id": connection_id_override,
                    "source_name": f"step:{source_type}"}
        except StepLoadFailed as exc:
            return {"sql": "", "status": "refused",
                    "message": str(exc),
                    "connection_id": connection_id_override,
                    "source_name": f"step:{source_type}"}
        except UnknownStep as exc:
            return {"sql": "", "status": "not_found",
                    "message": str(exc),
                    "connection_id": connection_id_override,
                    "source_name": source_type}
    except Exception as exc:  # step layer unavailable — degrade, don't 500
        logger.debug("[feed_preview] step resolution failed for %s: %s",
                     source_type, exc)
    return {"sql": "", "status": "empty",
            "message": f"Unsupported source_type: {source_type}",
            "connection_id": connection_id_override,
            "source_name": source_type}


def resolve_feed_sql(db_manager: Any, feed_config: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve a feed's primary (+ optional secondary) source to SQL.

    Pure read-only.  Never raises; surfaces structured errors instead.

    Item 3 (2026-08-05) — cross-source detection now runs the SAME
    inheritance the run path runs (``source_plan.inherit_cross_source`` on
    a probe copy), and each side resolves through the same side-selection
    helpers, so the previewed SQL is the SQL that executes.  A run-path
    refusal (partial cross config, unsplit-marker sql_file on a
    single-source feed) previews as ``source_status="refused"`` with the
    run's own fix-naming message instead of showing SQL that would never
    run.
    """
    probe = dict(feed_config)  # never mutate the caller's config
    plan_refusal: Optional[str] = None
    if not probe.get("secondary_connection_id"):
        try:
            from core.feed.source_plan import inherit_cross_source
            inherit_cross_source(
                db_manager,
                probe.get("source_type") or "",
                probe.get("source_id"),
                probe,
            )
        except ValueError as exc:
            # The run would REFUSE this shape fail-closed — preview says so.
            plan_refusal = str(exc)
        except Exception as exc:
            logger.debug("[feed_preview] cross-source inheritance probe "
                         "failed (previewing declared fields only): %s", exc)
    is_cross = bool(probe.get("secondary_connection_id"))

    primary = _resolve_one_side(
        db_manager,
        source_type=feed_config.get("source_type") or "",
        source_id=feed_config.get("source_id"),
        connection_id_override=feed_config.get("connection_id"),
        query_params=feed_config.get("query_params"),
        cross_side="primary" if is_cross else "single",
    )
    if plan_refusal and primary["status"] == "ok":
        primary = dict(primary)
        primary["status"] = "refused"
        primary["message"] = plan_refusal
    primary_conn = _connection_summary(db_manager, primary["connection_id"])

    secondary_sql: Optional[str] = None
    secondary_conn_name: Optional[str] = None
    secondary: Optional[Dict[str, Any]] = None
    combine_mode: Optional[str] = probe.get("combine_mode")
    secondary_conn_id = probe.get("secondary_connection_id")

    if secondary_conn_id or combine_mode:
        # Cross-connection feed.  Secondary may reuse primary's source_type
        # + source_id when not explicitly overridden (mirrors feed_engine).
        sec_type = probe.get("secondary_source_type") or probe.get("source_type") or ""
        sec_id = probe.get("secondary_source_id") or probe.get("source_id")
        secondary = _resolve_one_side(
            db_manager,
            source_type=sec_type,
            source_id=sec_id,
            connection_id_override=secondary_conn_id,
            query_params=feed_config.get("query_params"),
            cross_side="secondary",
        )
        secondary_sql = secondary["sql"]
        secondary_conn = _connection_summary(db_manager, secondary_conn_id)
        secondary_conn_name = secondary_conn["name"]

    return {
        "sql":             primary["sql"],
        "dialect":         _dialect_for(primary_conn["type"]),
        "source_type":     feed_config.get("source_type") or "",
        "source_id":       feed_config.get("source_id"),
        "source_name":     primary["source_name"],
        "source_status":   primary["status"],
        "source_message":  primary["message"],
        "connection_id":   primary["connection_id"],
        "connection_name": primary_conn["name"],
        "connection_type": primary_conn["type"],
        "secondary_sql":   secondary_sql,
        "secondary_connection_name": secondary_conn_name,
        # 2026-10-11 -- the second side's status, name and connection, so a
        # second side that does not resolve is SAID (the preview used to
        # answer secondary_sql: null for "not found" and "no second side"
        # alike -- unknown is not empty).
        "secondary_connection_id": secondary_conn_id,
        "secondary_source_status": (secondary or {}).get("status"),
        "secondary_source_message": (secondary or {}).get("message"),
        "secondary_source_name": (secondary or {}).get("source_name"),
        "combine_mode":    combine_mode,
    }
