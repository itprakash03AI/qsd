"""Map a feed_config to its equivalent DataFlow stage sequence — for
VISUALIZATION only (read-only preview).

feed_engine and DataFlow are parallel execution engines today; this helper lets
a feed be SEEN as the DataFlow pipeline it is equivalent to
(query -> apply WHERE -> convert format -> deliver -> control-file -> notify),
without executing anything.  Every step names the DataFlow stage that would
implement it, so the preview doubles as the blueprint for an eventual
feed->DataFlow auto-map.

Pure + defensive: unknown/absent fields degrade gracefully; secrets are the
caller's responsibility to mask before passing the feed in.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional


_SOURCE_LABELS = {
    "saved_query":    "Saved Query",
    "raw_sql":        "Raw SQL",
    "sql_file":       "SQL File",
    "published_view": "Published View",
}


def feed_to_dataflow_steps(feed: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Return ``{"trigger": {...}|None, "steps": [ {order, stage, label,
    detail, note?}, ... ]}`` describing the feed as DataFlow stages.

    ``stage`` values are real DataFlow stage names (core/dataflow/stages/*),
    so the UI can render them and a future mapper can emit a runnable
    definition from the same shape.
    """
    steps: List[Dict[str, Any]] = []
    if not isinstance(feed, dict):
        return {"trigger": None, "steps": steps}

    def add(stage: str, label: str, detail: str, note: Optional[str] = None) -> None:
        step: Dict[str, Any] = {
            "order": len(steps) + 1, "stage": stage, "label": label, "detail": detail,
        }
        if note:
            step["note"] = note
        steps.append(step)

    # ── Trigger (calendar_trigger) ────────────────────────────────────
    trigger: Optional[Dict[str, Any]] = None
    if feed.get("schedule_enabled") and feed.get("cron_expression"):
        trigger = {
            "stage": "calendar_trigger",
            "label": "Schedule",
            "detail": f"cron: {feed.get('cron_expression')} ({feed.get('timezone') or 'UTC'})",
        }

    # ── 1. Source query (sql_query_stage) ─────────────────────────────
    st = (feed.get("source_type") or "").lower()
    src_label = _SOURCE_LABELS.get(st, st or "source")
    _conn = feed.get("connection_id")
    add("sql_query", f"Query — {src_label}",
        f"source_id={feed.get('source_id')}"
        + (f", connection={_conn}" if _conn is not None else ""))

    # ── 1b. WHERE mapping (set_context / variables) ───────────────────
    qp = feed.get("query_params")
    wc = (qp.get("_where_clauses_mapping") or []) if isinstance(qp, dict) else []
    if isinstance(wc, list) and wc:
        n_dyn = sum(1 for w in wc if isinstance(w, dict)
                    and (w.get("mode") or "static") == "dynamic")
        add("set_context", "Apply WHERE mapping",
            f"{len(wc)} clause(s), {n_dyn} dynamic (runtime-overridable), "
            f"{len(wc) - n_dyn} static")

    # ── 2. Format (convert_file_format_stage) ─────────────────────────
    fmt = (feed.get("output_format") or "csv").lower()
    add("convert_file_format", f"Format — {fmt.upper()}",
        f"filename: {feed.get('output_filename_template') or '(default template)'}")

    # ── 3. Control file / checksum (checksum_stage) ───────────────────
    # Ordered BEFORE delivery: the feed engine builds the .ctl sidecar and
    # ships data-then-control inside the delivery step (feed_engine
    # _deliver_data_then_control), so the integrity artifact is produced ahead
    # of / together with delivery.  The engine's ACTUAL gate is
    # ``control_file_template`` (or ``control_file_format_id`` selecting a
    # feed_control_file_formats layout) — NOT output_options, which drives
    # only compression.  Keying off the real fields so a feed that writes a
    # control file always shows the step (and one that doesn't, never does).
    if feed.get("control_file_template") or feed.get("control_file_format_id"):
        _cf = feed.get("control_file_template") or "(format-table layout)"
        add("checksum", "Control file / checksum",
            f"row-count + checksum sidecar ({_cf}) — written with delivery")

    # ── 4. Delivery ───────────────────────────────────────────────────
    dt = (feed.get("destination_type") or "local").lower()
    dc = feed.get("destination_config") or {}
    if not isinstance(dc, dict):
        dc = {}
    if dt == "s3":
        add("s3_put", "Deliver — S3",
            f"bucket={dc.get('bucket', '?')} "
            f"prefix={dc.get('prefix') or dc.get('path') or '(root)'}")
    elif dt == "local":
        add("write_file", "Deliver — Local file",
            f"path={dc.get('path') or '(default feeds dir)'}")
    elif dt == "sftp":
        add("etl_bridge", "Deliver — SFTP (via ETL bridge)",
            f"host={dc.get('host', '?')} "
            f"dir={dc.get('remote_dir') or dc.get('path') or '(default)'}",
            note="No native DataFlow SFTP stage yet — routes through "
                 "etl_bridge → the ETL SFTP delivery step.")
    elif dt == "oracle":
        add("etl_bridge", "Deliver — Oracle (via ETL bridge)",
            f"table={dc.get('table') or dc.get('target_table') or '?'}",
            note="No native DataFlow Oracle stage yet — routes through "
                 "etl_bridge → the ETL Oracle load step.")
    else:
        add("write_file", f"Deliver — {dt}", "(destination config)")

    # ── 5. Notify (send_email_stage / notify_stage) ───────────────────
    conds = []
    if feed.get("notify_on_success"):
        conds.append("success")
    if feed.get("notify_on_failure"):
        conds.append("failure")
    if conds:
        # Label + stage reflect the actual channel: email vs webhook.
        _emails = feed.get("notify_emails")
        _webhook = feed.get("notify_webhook")
        if _emails:
            stage, label, target = "send_email", "Notify (email)", _emails
        elif _webhook:
            stage, label, target = "send_email", "Notify (webhook)", _webhook
        else:
            stage, label, target = "send_email", "Notify", "(configured)"
        add(stage, label, f"on {', '.join(conds)} → {target}")

    return {"trigger": trigger, "steps": steps}


__all__ = ["feed_to_dataflow_steps"]
