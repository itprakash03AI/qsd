"""A feed's SQL side read BY PARTITION VALUES (2026-10-14, the owner: "rather
than running the full query we should partition the query based on defined
columns in config ... first pull the SAP_COMPANY_CODE values for that query,
then grouping and streaming back").

This is OG's ``partition_config`` (``ETL/steps/file/starburst_file_base.py``:
discover the distinct values WITH the query's own WHERE, pack them into
count-aware buckets, run ``base AND key IN (bucket)`` a few at a time) on a
feed's SQL-connector side, through the SAME planner and executor reports and
the published API already use (``core/scan_partitions``) -- one reading of
"can this query be split exactly", never a second.

What a feed adds over a report:

* the file's rows come out in the SAME order every run without a whole-result
  ORDER BY: buckets are built from the values in sorted order and their parts
  are written in bucket order (``value_order="sorted"``, executor
  ``ordered=True``); ``order_within`` sorts each small bucket on the engine
  when the order inside one key value must be fixed too;
* the plan, or the reason the query ran whole, is on the execution record
  (``files_metadata.partitioned_read``) -- a refusal (an aggregation that does
  not group by the key, a LIMIT, ...) runs the query WHOLE and says why;
* the completeness ledger's verdict travels with it, and a failed gate fails
  the run (``fail_on_bucket_mismatch``).

The declaration lives in ``backend_config.partition_config`` (the feed's
engine settings JSON, carried by the API, the form, templates and the SQL
setup function as it is)::

    {"column": "SAP_COMPANY_CODE"}                 # one column
    {"columns": ["SAP_COMPANY_CODE", "EVENT"]}     # a composite key
    {"column": "FACT_TETB.SAP_COMPANY_CODE",       # qualified: the table's column
     "max_buckets": 64, "max_concurrent": 4,
     "target_rows_per_bucket": 2000000,
     "order_within": ["SAP_COMPANY_CODE", "ID"],
     "secondary": {"column": "SAP_COMPANY_CODE"}}  # the on-prem side's own key
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

RECORD_KEY = "_partitioned_read"

#: keys a side override may set; anything else in ``secondary`` is ignored
_SIDE_KEYS = ("column", "columns", "enabled", "max_buckets", "max_concurrent",
              "target_rows_per_bucket", "bucket_size", "bucket_strategy",
              "discovery_sql", "discovery_with_counts", "discovery_wrap",
              "max_discovery_values", "preflight_count", "order_within")


def feed_partition_config(feed_config: dict) -> Dict[str, Any]:
    """The partition declaration THIS side of the feed runs with, or {}.

    ``backend_config.partition_config`` (a top-level ``partition_config`` is
    read too, for a caller that hands one over directly).  On the second side
    of a cross-source feed (``_cross_side == "secondary"``) the ``secondary``
    block overrides the shared settings -- the two sides may name the key
    differently.  ``column`` / ``columns`` become ONE spelling under
    ``column`` (``"A, B"``)."""
    from core.scan_partitions.sql_shapes import column_spec
    fc = feed_config or {}
    bc = fc.get("backend_config") if isinstance(fc.get("backend_config"), dict) else {}
    raw = bc.get("partition_config") or fc.get("partition_config")
    if not isinstance(raw, dict) or not raw:
        return {}
    cfg = {k: v for k, v in raw.items() if k != "secondary"}
    side = raw.get("secondary")
    if fc.get("_cross_side") == "secondary" and isinstance(side, dict):
        if "column" in side or "columns" in side:
            cfg.pop("column", None)
            cfg.pop("columns", None)
        cfg.update({k: v for k, v in side.items() if k in _SIDE_KEYS})
    cfg["column"] = column_spec(cfg.pop("columns", None) or cfg.get("column"))
    return cfg


def _record(feed_config: dict, entry: Dict[str, Any]) -> None:
    side = feed_config.get("_cross_side") or "single"
    rec = feed_config.get(RECORD_KEY)
    if not isinstance(rec, dict):
        rec = {}
        feed_config[RECORD_KEY] = rec
    rec[side] = entry


def _plan_scan(cfg: dict, probe_connector: Any, sql: str, conn_type: str,
               feed_config: dict, max_rows: int = 0):
    """THE plan of a declared partition key -- one call for QueryStudio's
    engine (:func:`read_partitioned`) and a detached Spark job
    (:func:`plan_for_detached_side`).  ``(plan, summary)``, or
    ``(None, summary)`` when the query runs whole -- the reason recorded."""
    from core.scan_partitions import plan_partitioned_scan
    from core.sql_filter_wrapper import dialect_for_connection_type
    try:
        dialect = dialect_for_connection_type(conn_type) or "trino"
    except Exception:                                       # noqa: BLE001
        dialect = "trino"
    try:
        plan = plan_partitioned_scan(
            probe_connector, sql, partition_column=cfg["column"], dialect=dialect,
            max_buckets=int(cfg.get("max_buckets") or 64),
            max_concurrent=int(cfg.get("max_concurrent") or 2),
            target_rows_per_bucket=cfg.get("target_rows_per_bucket"),
            bucket_size=cfg.get("bucket_size"),
            bucket_strategy=str(cfg.get("bucket_strategy") or "auto"),
            discovery_sql=(str(cfg.get("discovery_sql") or "").strip() or None),
            discovery_with_counts=bool(cfg.get("discovery_with_counts", True)),
            discovery_wrap=bool(cfg.get("discovery_wrap", False)),
            max_discovery_values=int(cfg.get("max_discovery_values") or 200_000),
            preflight_count=cfg.get("preflight_count"),
            row_limit=(max_rows if max_rows and max_rows > 0 else None),
            on_refusal="declare",
            value_order="sorted",
            order_within=cfg.get("order_within"))
    except Exception as exc:                                # noqa: BLE001
        # planning is an optimisation: the query still runs, whole, and says why
        logger.warning("[feed-partition] feed %s: planning failed (%s: %s) -- the "
                       "query runs whole", feed_config.get("id"), type(exc).__name__, exc)
        summary = {"mode": "single", "column": cfg["column"],
                   "why": f"planning failed: {type(exc).__name__}: {exc}"[:500]}
        _record(feed_config, summary)
        return None, summary
    summary = {k: v for k, v in plan.to_dict().items() if k != "buckets"}
    if plan.mode.value != "partition_values":
        why = (plan.refusal.message() if plan.refusal is not None else
               "discovery found nothing to split (the query returns no rows)")
        logger.info("[feed-partition] feed %s runs WHOLE on %r: %s",
                    feed_config.get("id"), cfg["column"], why)
        summary = dict(summary, why=why)
        _record(feed_config, summary)
        return None, summary
    return plan, summary


def plan_for_detached_side(db: Any, side_fc: dict, connection_id: Any, conn_type: str,
                           sql: str) -> Optional[Dict[str, Any]]:
    """The partitioned read of a JDBC side a DETACHED Spark job executes
    (2026-10-14): the SAME plan QueryStudio's engine would run, planned here
    at submit (the discovery query runs on the source now), shipped as one
    query per bucket.  The job reads one JDBC partition per bucket, several
    at a time across its executors, and writes them in bucket (= sorted
    value) order -- the same file the native engine writes.  None = nothing
    declared; ``{"mode": "single", "why": ...}`` = the query runs whole and
    the run says why."""
    cfg = feed_partition_config(side_fc)
    if not cfg or not cfg.get("column") or cfg.get("enabled") is False:
        return None
    from core.connectors import get_connector
    conn = db.get_connection_raw(int(connection_id)) or {}
    probe = get_connector(conn_type, dict(conn.get("config") or {}))
    try:
        plan, summary = _plan_scan(cfg, probe, sql, conn_type, side_fc)
    finally:
        try:
            probe.close()
        except Exception:                                   # noqa: BLE001
            pass
    if plan is None:
        return dict(summary, lane="spark")
    buckets = [{"index": b.index, "sql": b.sql, "expected_rows": b.expected_rows}
               for b in plan.buckets]
    logger.info("[feed-partition] feed %s: the Spark job reads %d bucket(s) on %r, one JDBC "
                "partition each, in value order", side_fc.get("id"), len(buckets),
                plan.partition_column)
    return dict(summary, lane="spark", buckets=buckets)


def by_files_record(side_fc: dict, conn_type: str) -> Optional[Dict[str, Any]]:
    """What a declared key means for a side read straight from its FILES --
    on QueryStudio's engine (:func:`note_read_by_files`) and on a Spark
    job's "tables" side alike: the files are the parts.  None = nothing
    declared."""
    cfg = feed_partition_config(side_fc)
    if not cfg or not cfg.get("column") or cfg.get("enabled") is False:
        return None
    col = cfg["column"]
    return {
        "mode": "by_files", "partition_column": col,
        "connection_type": conn_type,
        "why": ("this side is read straight from its files, so the files are the parts: "
                "each file is read once, several at a time. A query per group of "
                + str(col) + " values would read every file that holds those values once "
                "per group -- the whole table again for each group when the values are "
                "spread over the files.")}


def read_partitioned(
    *,
    connector_factory: Callable[[], Any],
    probe_connector: Any,
    sql: str,
    conn_type: str,
    feed_config: dict,
    output_path: str,
    cancel_event=None,
    chunk_size: int = 10_000,
    max_rows: int = 0,
    rows_per_part: int = 5_000_000,
) -> Optional[Tuple[str, int]]:
    """Read ``sql`` bucket by bucket into a parts dir: ``(parts_dir, rows)``.

    None = run the query WHOLE (nothing declared, switched off, or the shape
    refused) -- the reason is on the record either way.  A failure DURING the
    partitioned read raises: its parts are not a file anyone may deliver, and
    running whole after some buckets were read would be a second answer."""
    cfg = feed_partition_config(feed_config)
    if not cfg or not cfg.get("column") or cfg.get("enabled") is False:
        return None
    from core.scan_partitions import execute_plan_to_parts
    plan, summary = _plan_scan(cfg, probe_connector, sql, conn_type, feed_config, max_rows)
    if plan is None:
        return None

    parts_dir = output_path + ".parts"
    logger.info("[feed-partition] feed %s: %d bucket(s) on %r, %d at a time, in value "
                "order%s", feed_config.get("id"), len(plan.buckets), plan.partition_column,
                plan.max_concurrent,
                f", each sorted by {plan.order_within}" if plan.order_within else "")
    res = execute_plan_to_parts(
        connector_factory, plan, parts_dir,
        rows_per_part=rows_per_part, chunk_size=chunk_size,
        cancel_event=cancel_event, reuse=False, ordered=True,
        source_meta={"feed_id": feed_config.get("id"), "connection_type": conn_type})
    ledger = res.get("ledger") or {}
    _record(feed_config, dict(summary, rows=int(res.get("total_rows") or 0),
                              parts=int(res.get("parts") or 0),
                              ledger_verdict=ledger.get("verdict"),
                              ledger_reason=ledger.get("verdict_reason")))
    return parts_dir, int(res.get("total_rows") or 0)


def note_read_by_files(feed_config: dict, conn_type: str) -> None:
    """A side read by QueryStudio's own engine straight from FILES (S3,
    local): the files ARE the parts.

    Measured 2026-10-14 on the owner's 40M-row table (360 Iceberg files):
    every file's SAP_COMPANY_CODE bounds were the whole range (``sapc0`` to
    ``sapc996``) -- the key is not a partition column and the writer did not
    cluster by it.  A query per group of values would then read EVERY file
    once per group (64 groups = the table 64 times).  Reading by files reads
    each file once, several at a time (the engine's multi-worker split), and
    is never more bytes than reading by value even when the data IS clustered
    (each file is still read once).  So a declared key does not re-read the
    data here; the run says so instead of looking split."""
    rec = by_files_record(feed_config, conn_type)
    if rec:
        _record(feed_config, rec)


__all__ = ["feed_partition_config", "read_partitioned", "note_read_by_files",
           "plan_for_detached_side", "by_files_record", "RECORD_KEY"]
