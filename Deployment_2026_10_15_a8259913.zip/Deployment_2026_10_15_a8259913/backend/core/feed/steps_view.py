"""Per-step view of one feed run — derived, never invented (BRD §13.1).

**2026-09-05 — this module is now the FALLBACK, not the answer.**  A run
executed since the step model shipped has REAL rows in ``feed_run_steps``
(``core/feed/step_model``): a row per step with wall-clock boundaries, a
record count, the pod and the error.  :func:`steps_from_rows` projects
those into the same shape this module has always returned, so one route
answers "what are this run's steps" with one vocabulary.

Everything below it stays, and stays reachable, for exactly one reason:
runs that executed BEFORE the step model existed have no rows, and a
timing projection is a smaller honest answer where the alternative is an
empty list.  The response says WHICH it gave (``source``:
``"recorded"`` / ``"derived"``) — "we recorded nothing" and "this run had
no steps" are opposite findings, and a caller that cannot tell them apart
will read a projection as fact.

The engine already records where the time went: ``_enter_stage`` /
``_exit_stage`` write ``stage_timings`` onto the execution row at
finalisation, ``failed_stage`` names where a failure broke, and the live
in-process registry (``core.execution_stage``) knows the CURRENT stage of a
run that is still executing.  This module only projects those facts into
one list; it never fabricates a step that did not run, and it never guesses
a canonical pipeline — the vocabulary is exactly the stage names the engine
entered (``status_running``, ``query_native``, ``format_csv``,
``deliver_sftp``, ...).

Honesty notes, both deliberate:

* ``started_at`` / ``ended_at`` are ``None`` for recorded steps.  The
  engine stores DURATIONS (and the live registry uses a monotonic clock);
  wall-clock step boundaries were never recorded, and synthesising them by
  accumulation would misattribute the un-timed gaps between stages.
* ``stage_timings`` also carries measurements that are not steps
  (``row_count``, byte sizes, dict-valued verification records).  Those are
  filtered out by an explicit list plus a numeric-type check — a row count
  rendered as a 12,345-second step is how a timeline stops being read.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: Run states after which nothing more will happen.
TERMINAL_RUN_STATES = frozenset({"completed", "failed", "cancelled",
                                 "skipped"})

#: Numeric ``stage_timings`` keys that are MEASUREMENTS, not stages.  The
#: engine writes both into the same dict; only these carry a number that is
#: not a duration in seconds.
#:
#: AQD-06 (2026-09-23): this list was a DENYLIST that had fallen behind the
#: engine -- ``output_bytes`` and ``output_size_limit_mb`` were missing, so a
#: manual run's 76-byte file rendered as a step that took "76.0 seconds".
#: It is now half of a DECLARATION (``STAGE_TIMINGS_NON_STEP_KEYS`` below)
#: that a guard checks against every key the engine writes by name: a new
#: key fails the build until someone says what it is.
NON_STEP_NUMERIC_KEYS = frozenset({
    "row_count",
    "query_output_bytes",
    "file_size_bytes_local",
    "remote_size_bytes",
    "output_bytes",
    "output_size_limit_mb",
})

#: Every OTHER key the engine writes into ``stage_timings`` by literal name:
#: verdicts, records and flags.  Non-numeric today, so the type check would
#: skip them -- but "skipped because it happens to be a string" is not a
#: declaration, and the day one becomes a number it would render as seconds.
NON_STEP_RECORD_KEYS = frozenset({
    # 2026-10-13 -- the size the lane was chosen by and where it came from
    # (core/feed/run_size.py: {rows, source})
    "run_size",
    "partition_declaration", "partition_comparison",
    "fanout", "fanout_not_wired_backend", "fanout_delivery_refused",
    "output_truncated", "integrity_local_warning", "integrity_post_delivery_warning",
    "packaging", "encryption", "checksum_sidecar",
    "output_size_verdict",
    "delivery_hops", "delivery_chain", "delivery_verification",
    "control_file_delivery",
    "notifications",
    # {to, reason}: an auto-routed spark_k8s run that met an unreachable
    # cluster at submit and moved to native (2026-10-07, lane contract D3)
    "spark_k8s_fallback",
    # 2026-10-11 -- {verdict, sides, failures}: each side's rows judged
    # against the upstream message's ROW_COUNT (core/feed/
    # reported_rows_certification.py), on both lanes, before any output.
    "reported_rows_certification",
    # 2026-10-12 -- {hold_id, status, decided_by}: the file the row-count
    # check HELD for the release group (core/feed/variance_hold.py).
    "variance_hold",
    # 2026-10-12 -- THE UPSTREAM CONTRACT the run read, per environment
    # (core/feed/upstream_contract.py); the empty-result verdict; which side
    # failed; the side kept for / reused by a one-side re-run, or why the
    # kept rows were refused (core/feed/side_resume.py).
    "upstream_contract", "empty_result", "failed_side",
    "kept_side", "reused_side", "reuse_refused",
})

#: The whole declaration: a ``stage_timings`` key that is NOT a step.
STAGE_TIMINGS_NON_STEP_KEYS = NON_STEP_NUMERIC_KEYS | NON_STEP_RECORD_KEYS

#: Stages whose entry is replaced by an OUTCOME dict that carries the stage's
#: duration inside it as ``duration_seconds`` (``row_count_check``: a float
#: there used to crash the completeness verdict).  The projection used to skip
#: the dict, so the step vanished from the timeline it had run in.
STAGES_WITH_OUTCOME_DICT = frozenset({"row_count_check"})


def stage_seconds(name: str, value: Any) -> Optional[float]:
    """The duration a ``stage_timings`` entry records, or None when the entry
    is not a stage.  THE rule; the projection and its guard both use it."""
    if name in STAGE_TIMINGS_NON_STEP_KEYS:
        return None
    if isinstance(value, dict):
        if name not in STAGES_WITH_OUTCOME_DICT:
            return None
        value = value.get("duration_seconds")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


#: FR-ID-05 — the SYSTEM's type vocabulary, derived from the stage-name
#: prefix the engine already writes.  The alias is the parameterised
#: remainder — the part the AUTHOR chose (``deliver_sftp``: the author
#: chose sftp; ``format_csv``: the author chose csv).  A name outside
#: the vocabulary keeps itself as both (honest, never invented).
_STEP_TYPE_PREFIXES = (
    ("query_", "query"),
    ("format_", "format"),
    ("deliver_", "delivery"),
    ("delivery_", "delivery"),
    ("integrity_", "integrity"),
    ("status_", "lifecycle"),
    ("partition_", "partition"),
    ("fanout", "fanout"),
    ("spark_", "spark"),
    ("control_file", "control_file"),
)


def classify_step(name: str) -> tuple:
    """FR-ID-05 — ``(type, alias)`` for one recorded stage name.

    The type groups behaviour across feeds (the system's); the alias is
    the author-meaningful parameter within it.  ``deliver_sftp`` →
    ``("delivery", "sftp")``; an unrecognised name is its own type and
    alias — stated, never guessed.
    """
    n = str(name or "")
    for prefix, type_ in _STEP_TYPE_PREFIXES:
        if n.startswith(prefix):
            alias = n[len(prefix):].strip("_") or n
            return type_, alias
    return n, n


def _step(name: str, state: str, seconds: Optional[float] = None,
          detail: Optional[str] = None) -> Dict[str, Any]:
    type_, alias = classify_step(name)
    return {"name": name, "state": state, "type": type_, "alias": alias,
            "started_at": None, "ended_at": None, "seconds": seconds,
            "detail": detail}


def _recorded_steps(execution: dict) -> List[Dict[str, Any]]:
    """Completed steps from the persisted ``stage_timings`` dict.

    JSON object order is insertion order, and the engine inserts on exit —
    so the dict order IS the execution order.
    """
    timings = execution.get("stage_timings") or {}
    if not isinstance(timings, dict):
        return []
    steps = []
    for name, value in timings.items():
        seconds = stage_seconds(str(name), value)
        if seconds is None:
            continue                      # a measurement or a record: not a step
        steps.append(_step(str(name), "completed", seconds=seconds))
    return steps


def _live_steps(snapshot: dict) -> tuple:
    """(steps, current) from the in-process stage registry of a RUNNING run.

    The registry is process-local: it answers only when the engine runs in
    this pod's process.  When it cannot answer, the caller falls back to
    whatever the execution row already persisted — an honest smaller answer,
    never an invented one.
    """
    steps: List[Dict[str, Any]] = []
    for h in snapshot.get("stage_history") or []:
        name = str(h.get("stage") or "")
        if not name:
            continue
        steps.append(_step(name, "completed",
                           seconds=h.get("duration_seconds")))
    current = snapshot.get("stage")
    if current:
        steps.append(_step(str(current), "running",
                           seconds=snapshot.get("stage_elapsed_seconds"),
                           detail=(snapshot.get("message") or None)))
    return steps, (str(current) if current else None)


def _qualify(steps: List[Dict[str, Any]], run: dict,
             execution: Optional[dict], feed_name) -> None:
    """FR-ID-06 — stamp each step with THE fully-qualified identity
    (``<feed>/<business_date>/<build>/<step>``), the same string the
    engine log line carries, so the run screen and the log need no
    translation.  Missing components render as ``-`` (a visible hole),
    never invented — see ``core.feed.step_identity``."""
    from core.feed.step_identity import qualified_task_id
    feed = feed_name or (run or {}).get("feed_name")
    if not feed and (run or {}).get("feed_config_id") is not None:
        feed = f"feed-{run['feed_config_id']}"
    build = ((run or {}).get("build_id")
             or (execution or {}).get("execution_id"))
    bd = (run or {}).get("business_date")
    for s in steps:
        s["qualified_id"] = qualified_task_id(feed, bd, build, s["name"])


#: ``feed_run_steps.status`` -> the state vocabulary this module has
#: always emitted.  ``refused`` is carried THROUGH rather than folded
#: into ``failed``: a correctness verdict and a crash lead to opposite
#: investigations, and this projection is where they would be conflated.
_ROW_STATE = {
    "not_started": "pending",
    "running": "running",
    "completed": "completed",
    "failed": "failed",
    "refused": "refused",
    "skipped": "skipped",
    "cancelled": "cancelled",
}


def steps_from_rows(run: dict, execution: Optional[dict],
                    rows: List[Dict[str, Any]],
                    feed_name: Optional[str] = None) -> dict:
    """Project REAL ``feed_run_steps`` rows into the step-view shape.

    Same keys the caller already consumed (``name``, ``state``, ``type``,
    ``alias``, ``started_at``, ``ended_at``, ``seconds``, ``detail``,
    ``qualified_id``) so nothing that reads this breaks — plus the facts
    a duration dict could never carry: ``seq``, ``level``,
    ``depends_on``, ``attempt``, ``rows_out``, ``worker_node``,
    ``executor`` and the step's own resolved ``params``.

    ``level`` is what makes "these three ran at once" visible rather than
    implied: steps sharing a level had no declared dependency between
    them.
    """
    steps: List[Dict[str, Any]] = []
    current = None
    for row in rows:
        state = _ROW_STATE.get(str(row.get("status") or ""),
                               str(row.get("status") or ""))
        type_, alias = classify_step(str(row.get("step_type") or ""))
        step = {
            "name": row.get("alias"),
            "state": state,
            "type": row.get("step_type") or type_,
            "alias": row.get("alias") or alias,
            "started_at": row.get("started_at"),
            "ended_at": row.get("ended_at"),
            "seconds": row.get("duration_seconds"),
            "detail": row.get("error"),
            "seq": row.get("seq"),
            "level": row.get("level"),
            "depends_on": row.get("depends_on") or [],
            "attempt": row.get("attempt"),
            "max_attempts": row.get("max_attempts"),
            "rows_in": row.get("rows_in"),
            "rows_out": row.get("rows_out"),
            "worker_node": row.get("worker_node"),
            "executor": row.get("executor"),
            "params": row.get("params") or {},
            "outputs": row.get("outputs") or {},
        }
        if state == "running":
            current = step["name"]
        steps.append(step)
    _qualify(steps, run, execution, feed_name)
    failed = next((s for s in steps
                   if s["state"] in ("failed", "refused")), None)
    return {
        "execution_id": (execution or {}).get("execution_id"),
        "steps": steps,
        "current": current,
        "terminal": str((run or {}).get("status") or "") in TERMINAL_RUN_STATES,
        # The run-level error stays the run's; the STEP-level one is on
        # the step.  Naming the failing step here too is what answers
        # "which step failed, and why" without a second request.
        "error": (failed or {}).get("detail") or (run or {}).get("error"),
        "failed_step": (failed or {}).get("name"),
        "source": "recorded",
    }


def derive_steps(run: dict, execution: Optional[dict],
                 live_snapshot: Optional[dict] = None,
                 feed_name: Optional[str] = None) -> dict:
    """Project one run's step timeline.

    Returns ``{"execution_id", "steps", "current", "terminal", "error"}``.
    ``steps`` states are ``completed`` / ``running`` / ``failed`` — a step
    that never started is simply absent, because the engine's stage list is
    dynamic (per backend, per format, per destination) and inventing an
    expected pipeline would show steps that were never going to run.

    Each step also carries (2026-09-03):

    * ``type`` / ``alias`` (FR-ID-05) — the system's grouping and the
      author's parameter, derived from the stage vocabulary;
    * ``qualified_id`` (FR-ID-06) — the SAME
      ``<feed>/<business_date>/<build>/<step>`` string the engine logs.
      Pass ``feed_name`` for the ``<feed>`` position; without it the
      formatter falls back to ``feed-<id>`` (honest, still unique).
    """
    status = str((run or {}).get("status") or "")
    terminal = status in TERMINAL_RUN_STATES
    result: dict = {
        "execution_id": (execution or {}).get("execution_id"),
        "steps": [], "current": None, "terminal": terminal, "error": None,
    }
    if execution is None:
        # No execution row — the run never reached the engine (still
        # pending/waiting, or the link could not be established).  Zero
        # steps is the true answer; anything else would be invention.
        result["error"] = run.get("error") if terminal else None
        return result

    if not terminal and live_snapshot:
        steps, current = _live_steps(live_snapshot)
        _qualify(steps, run, execution, feed_name)
        result["steps"] = steps
        result["current"] = current
        return result

    steps = _recorded_steps(execution)
    exec_status = str(execution.get("status") or "")
    error_message = execution.get("error_message") or run.get("error")
    if status == "failed" or exec_status == "failed":
        result["error"] = error_message
        failed_stage = execution.get("failed_stage")
        if failed_stage:
            named = [s for s in steps if s["name"] == failed_stage]
            if named:
                # Edge: the stage exited (so it has a duration) and the
                # failure was attributed to it anyway — keep the timing,
                # flip the state.
                named[-1]["state"] = "failed"
                named[-1]["detail"] = error_message
            else:
                # The usual shape: _exit_stage never ran for the failing
                # stage, so it has no timing row.  It DID run — appending
                # it is reporting, not invention.
                steps.append(_step(str(failed_stage), "failed",
                                   detail=error_message))
        # No failed_stage recorded (legacy row): the steps stand as
        # recorded and the error is carried at the top level — naming a
        # step we cannot identify would be a guess.
    _qualify(steps, run, execution, feed_name)
    result["steps"] = steps
    if not terminal:
        # Running run with no live registry answer (cross-pod, or restart):
        # the persisted timings are from a PRIOR attempt if present at all.
        result["current"] = None
    return result
