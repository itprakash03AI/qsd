"""The four SQL source kinds as source STEPS — bodies extracted VERBATIM
from ``feed_engine._run_single_source_native_query`` (2026-09-03).

These branch bodies carry years of incident fixes — the falsy-coalesce
on NULL query_config (2026-05-16 prod crash), the secondary-shape
substitution (2026-08-04: before it, the primary SQL ran TWICE on cross
feeds), the registered-tables stash, and above all the fail-CLOSED
WHERE wrap (2026-08-19: its fail-open predecessor shipped a feed's
whole unfiltered table to its recipients as a successful run).  They
were MOVED, not rewritten: each ``_run`` body is byte-identical to the
branch it replaces (line terminators normalised to this file's LF), the
local names (``source_id``, ``feed_config``, ``db``, ``output_path``)
are bound by the ``_run`` signature, and the module logger keeps the
``core.feed_engine`` name so every log line stays byte-identical.
``tests/test_feed_sql_sources_golden_2026_09_03.py`` was written against
the ORIGINAL branches and pins the equivalence.

``_execute_duckdb_query`` / ``_apply_secondary_shape`` are late-binding
aliases into feed_engine — resolved at call time, so tests that patch
``feed_engine._execute_duckdb_query`` still intercept, and importing
this module never imports the engine.
"""
from __future__ import annotations

import logging

from core.feed.sources.base import (
    SourceRequest,
    SourceResolver,
    SourceTraits,
)

#: The branches always logged as core.feed_engine; keeping that logger
#: name keeps every operational log line byte-identical post-move.
logger = logging.getLogger("core.feed_engine")


def _execute_duckdb_query(*args, **kwargs):
    from core import feed_engine as _fe
    return _fe._execute_duckdb_query(*args, **kwargs)


def _apply_secondary_shape(*args, **kwargs):
    from core import feed_engine as _fe
    return _fe._apply_secondary_shape(*args, **kwargs)


class _SqlBranchSource(SourceResolver):
    """Shared face: unpack the request into the exact local names the
    verbatim bodies close over."""
    traits = SourceTraits(streamable=True, replayable=False,
                          reports_count=False,
                          supports_partitioning=False,
                          needs_connection=True,
                          # SQL shape: the Spark lanes can serve these
                          # kinds by resolving the SQL themselves — the
                          # router's step_source floor reads THIS, not a
                          # name list (2026-09-03).
                          sql_shape=True)

    def resolve(self, request: SourceRequest) -> str:
        return self._run(request.source_id, request.feed_config,
                         request.db, request.output_path)

    def _run(self, source_id, feed_config, db, output_path):
        raise NotImplementedError


class SavedQuerySourceStep(_SqlBranchSource):
    name = "saved_query"
    description = "Saved query (BQB/CQB) as a feed source"

    def _run(self, source_id, feed_config, db, output_path):
        # Load the saved query config and execute via DuckDB
        sq = db.get_query(source_id)
        if not sq:
            raise ValueError(f"Saved query {source_id} not found")


        # Falsy-coalesce: dict.get("k", {}) only returns {} when the KEY
        # is missing.  If the key is present with value None (NULL in DB),
        # get() returns None and the subsequent qcfg.get(...) blows up
        # with "'NoneType' object has no attribute 'get'" — observed in
        # prod against feeds whose saved_query.query_config is NULL.
        qcfg = sq.get("query_config") or {}

        # Cross-source SECONDARY side (2026-08-04): run the saved
        # secondary shape when this execution serves it — see
        # _apply_secondary_shape.
        qcfg = _apply_secondary_shape(qcfg, feed_config,
                                      f"saved query {source_id}")

        connection_id = feed_config.get("connection_id") or qcfg.get("connection_id")

        # Build and execute query via DuckDB
        # Use get_connection_raw() for decrypted creds (get_connection() masks secrets)
        conn = db.get_connection_raw(connection_id) if connection_id else None
        if not conn:
            raise ValueError(f"Connection {connection_id} not found or not specified")

        # Use the existing query infrastructure to get results.  For
        # registered-table references (__registered__:foo) we need the
        # full view-registration setup that the main /api/execute path
        # uses — otherwise DuckDB sees the bare table name and fails.
        # The connection's connection_manager.list_registered_tables
        # provides the per-conn table → file mapping.
        # 2026-09-05 -- TELL THE BUILDER WHERE THIS SQL IS GOING.
        # This call used to pass the config alone, so a builder-mode saved
        # query was rendered in DuckDB grammar (``FROM read_parquet(...)
        # AS t0``) and then handed to _execute_duckdb_query, which routes
        # every SQL_CONNECTOR_TYPES connection to that connector VERBATIM.
        # Only raw-SQL-mode sources survived the trip; the same saved
        # query worked in the builder and failed at the source in its
        # feed.  With the connection type threaded, the builder renders
        # for the real engine -- or refuses by name (QueryNotExpressible)
        # rather than emitting SQL the engine never agreed to speak.
        _conn_type = (conn or {}).get("connection_type")
        from core.duckdb_views import build_query_sql
        sql = build_query_sql(qcfg, connection_type=_conn_type)
        if not sql:
            raise ValueError("Could not build SQL from saved query config")

        # Phase 130 hotfix-13 follow-up: pull registered_tables for the
        # connection so _execute_duckdb_query can create the DuckDB
        # views before running the SQL.  Without this, references to
        # __registered__:foo or local parquet table names fail with
        # "IO Error: No files found that match the pattern ...".
        registered_tables: list = []
        try:
            from core.connection_manager import ConnectionManager
            _cm = ConnectionManager(db)
            registered_tables = _cm.get_registered_tables(connection_id) or []
        except Exception as _rt_exc:
            logger.debug("[feed_engine] could not load registered_tables: %s", _rt_exc)

        # Stash on feed_config so _execute_duckdb_query can pick them up
        feed_config["_registered_tables"] = registered_tables
        feed_config["_query_config"] = qcfg

        # Phase 132.38 — merge Static rows + consumer Dynamic overrides
        # INTO ``qcfg.filters`` before re-running build_query_sql so the
        # engine's structured WHERE-build picks them up.  No-op when the
        # feed has no WHERE mapping or no overrides.
        from core.feed_where_apply import apply_where_to_query_config
        apply_where_to_query_config(qcfg, feed_config)
        # Rebuild SQL when filters were touched so the merge actually
        # lands on the executed query.
        if (feed_config.get("query_params") or {}).get("_where_clauses_mapping"):
            from core.duckdb_views import build_query_sql as _rebuild_sql
            # Same target as the first build -- a rebuild that dropped the
            # connection type would re-render the merged filters in DuckDB
            # grammar and undo the fix above.
            _rebuilt = _rebuild_sql(qcfg, connection_type=_conn_type)
            if _rebuilt:
                sql = _rebuilt
            # Phase 132.38 deep-dive (2026-06-26) -- BUG FIX.  When the
            # saved query is in raw-SQL mode (qcfg.raw_sql set), the
            # structured ``apply_where_to_query_config`` modifies
            # ``qcfg.filters`` but build_query_sql's ``raw_sql shortcut''
            # returns raw_sql AS-IS (duckdb_views.py:268-270).  The
            # merged Static + Dynamic filters silently die in
            # qcfg.filters and the publisher's hardcoded predicate
            # always wins -- consumer override is lost.  Mirror the
            # raw_sql source branch's fix: wrap the raw SQL with the
            # merged predicates + the REPLACE-semantics that strip
            # Dynamic hardcoded predicates first.
            if isinstance(qcfg, dict) and (qcfg.get("raw_sql") or "").strip():
                # Phase 132.38 deep-dive R2 (2026-06-26) -- dialect
                # threading.  feed_engine doesn't stamp connection_type
                # on feed_config; without it, dialect_for_connection_type
                # falls back to DuckDB grammar.  That breaks AST
                # pushdown for Trino/Starburst/Snowflake/Oracle saved
                # queries (forces subquery wrap -> partition pruning
                # silently lost -> full table scan).  Stamp it from
                # the resolved conn record so the wrap renders in the
                # right dialect.
                if conn and not feed_config.get("connection_type"):
                    feed_config["connection_type"] = conn.get("connection_type")
                try:
                    from core.feed_where_apply import apply_where_to_raw_sql
                    sql = apply_where_to_raw_sql(sql, feed_config) or sql
                except Exception as _sw_exc:
                    # 2026-08-19 -- was log-and-continue, i.e. the feed ran
                    # with NO WHERE clause and delivered the whole table to
                    # its recipients as a successful run.  Same fix as the
                    # PV+raw_sql branch below; this one was missed, which
                    # left the identical leak alive on the saved_query path.
                    logger.error(
                        "[feed_engine] saved_query+raw_sql wrap FAILED for "
                        "feed %s (%s) -- failing the run rather than "
                        "delivering unfiltered data",
                        (feed_config or {}).get("id"), _sw_exc,
                    )
                    raise RuntimeError(
                        f"Feed filter application failed: {_sw_exc}. The run "
                        f"was aborted because delivering this feed "
                        f"unfiltered would expose rows the filters exclude."
                    ) from _sw_exc

        # Execute via DuckDB in a subprocess-safe way
        result_path = _execute_duckdb_query(sql, conn, output_path, feed_config, db=db)
        return result_path


class PublishedViewSourceStep(_SqlBranchSource):
    name = "published_view"
    description = "Published view's underlying saved query"

    def _run(self, source_id, feed_config, db, output_path):
        pv = db.get_published_view(source_id)
        if not pv:
            raise ValueError(f"Published view {source_id} not found")

        # Get the underlying saved query
        sq = db.get_query(pv["query_id"])
        if not sq:
            raise ValueError(f"Underlying saved query {pv['query_id']} not found for view")

        # Falsy-coalesce (see saved_query branch above for the same fix).
        qcfg = sq.get("query_config") or {}
        # Cross-source SECONDARY side (2026-08-04): a PV over a
        # cross-source saved query must run the saved secondary shape on
        # the secondary side — same substitution as the saved_query
        # branch (see _apply_secondary_shape).
        qcfg = _apply_secondary_shape(
            qcfg, feed_config,
            f"published_view {source_id}'s saved query {pv.get('query_id')}")
        # Phase 130 hotfix-2: feed_config.connection_id wins FIRST.  Mirrors
        # the saved_query + sql_file resolvers (which already do this) so
        # cross-source feeds can swap the connection per side without the
        # PV's own pinned connection silently winning.  When feed_config
        # doesn't set one, fall back to the PV's connection, then the
        # query config's.
        connection_id = (
            feed_config.get("connection_id")
            or pv.get("connection_id")
            or qcfg.get("connection_id")
        )
        conn = db.get_connection_raw(connection_id) if connection_id else None
        if not conn:
            raise ValueError(f"Connection {connection_id} not found")

        # 2026-09-05 -- TELL THE BUILDER WHERE THIS SQL IS GOING.
        # This call used to pass the config alone, so a builder-mode saved
        # query was rendered in DuckDB grammar (``FROM read_parquet(...)
        # AS t0``) and then handed to _execute_duckdb_query, which routes
        # every SQL_CONNECTOR_TYPES connection to that connector VERBATIM.
        # Only raw-SQL-mode sources survived the trip; the same saved
        # query worked in the builder and failed at the source in its
        # feed.  With the connection type threaded, the builder renders
        # for the real engine -- or refuses by name (QueryNotExpressible)
        # rather than emitting SQL the engine never agreed to speak.
        _conn_type = (conn or {}).get("connection_type")
        from core.duckdb_views import build_query_sql
        sql = build_query_sql(qcfg, connection_type=_conn_type)
        if not sql:
            raise ValueError("Could not build SQL from view's query config")

        # Phase 130 hotfix-13 follow-up: same view-registration setup as
        # the saved_query branch — without this, __registered__:foo
        # table refs aren't resolved to actual parquet paths.
        registered_tables: list = []
        try:
            from core.connection_manager import ConnectionManager
            _cm = ConnectionManager(db)
            registered_tables = _cm.get_registered_tables(connection_id) or []
        except Exception as _rt_exc:
            logger.debug("[feed_engine] could not load registered_tables: %s", _rt_exc)
        feed_config["_registered_tables"] = registered_tables
        feed_config["_query_config"] = qcfg

        # Phase 132.38 — apply WHERE mapping for published_view-sourced feeds
        # the same way as saved_query above.
        from core.feed_where_apply import apply_where_to_query_config
        apply_where_to_query_config(qcfg, feed_config)
        if (feed_config.get("query_params") or {}).get("_where_clauses_mapping"):
            from core.duckdb_views import build_query_sql as _rebuild_sql
            # Same target as the first build -- a rebuild that dropped the
            # connection type would re-render the merged filters in DuckDB
            # grammar and undo the fix above.
            _rebuilt = _rebuild_sql(qcfg, connection_type=_conn_type)
            if _rebuilt:
                sql = _rebuilt
            # Phase 132.38 deep-dive (2026-06-26) -- BUG FIX.  Same
            # raw_sql shortcut issue as the saved_query branch.  When
            # the PV's underlying saved query is in raw-SQL mode,
            # apply_where_to_query_config modifies qcfg.filters but
            # those go nowhere because build_query_sql returns raw_sql
            # as-is.  Wrap explicitly so the consumer override on
            # a Dynamic column actually replaces the publisher's
            # hardcoded predicate.
            if isinstance(qcfg, dict) and (qcfg.get("raw_sql") or "").strip():
                # Phase 132.38 deep-dive R2 -- same dialect threading
                # as the saved_query branch.  Without this the PV's
                # underlying Trino/Snowflake/Oracle SQL gets wrapped
                # in DuckDB grammar -> AST pushdown fails parse ->
                # subquery wrap -> partition pruning lost.
                if conn and not feed_config.get("connection_type"):
                    feed_config["connection_type"] = conn.get("connection_type")
                try:
                    from core.feed_where_apply import apply_where_to_raw_sql
                    sql = apply_where_to_raw_sql(sql, feed_config) or sql
                except Exception as _sw_exc:
                    # 2026-08-19 -- this used to log and CONTINUE, which
                    # meant the feed ran with NO WHERE clause and shipped the
                    # unfiltered table to its SFTP / email / S3 destination
                    # as a successful run.  A feed's filters are the whole
                    # contract with its recipient; losing them is a data
                    # leak, not a degraded delivery.  Fail the run instead --
                    # a missing file is recoverable, a wrong one already sent
                    # is not.
                    logger.error(
                        "[feed_engine] PV+raw_sql wrap FAILED for feed %s "
                        "(%s) -- failing the run rather than delivering "
                        "unfiltered data",
                        (feed_config or {}).get("id"), _sw_exc,
                    )
                    raise RuntimeError(
                        f"Feed filter application failed: {_sw_exc}. The run "
                        f"was aborted because delivering this feed unfiltered "
                        f"would expose rows the filters exclude."
                    ) from _sw_exc

        return _execute_duckdb_query(sql, conn, output_path, feed_config, db=db)


class RawSqlSourceStep(_SqlBranchSource):
    name = "raw_sql"
    description = "Inline SQL from query_params.sql"

    def _run(self, source_id, feed_config, db, output_path):
        # Falsy-coalesce: NULL in DB makes dict.get("k", {}) return None,
        # not {} — same anti-pattern as the qcfg fix above.
        query_params = feed_config.get("query_params") or {}
        sql = query_params.get("sql", "")
        if not sql:
            raise ValueError("raw_sql source requires 'sql' in query_params")

        connection_id = feed_config.get("connection_id")
        conn = db.get_connection_raw(connection_id) if connection_id else None
        if not conn:
            raise ValueError(f"Connection {connection_id} not found")

        # Round 10 hardening: raw_sql feeds reference registered tables
        # by name (e.g. ``SELECT * FROM "fact_table"``).  Load the
        # connection's registered_tables list so setup_registered_views
        # actually creates the views.  Without this the SQL fails with
        # "Catalog Error: Table does not exist".
        try:
            from core.connection_manager import ConnectionManager
            _cm = ConnectionManager(db)
            feed_config["_registered_tables"] = _cm.get_registered_tables(connection_id) or []
        except Exception as _rt_exc:
            logger.debug("[feed_engine] raw_sql: could not load registered_tables: %s", _rt_exc)
            feed_config["_registered_tables"] = []
        feed_config["_query_config"] = {"files": []}  # raw_sql has no structured files

        # Phase 132.38 — wrap raw SQL with merged Static + consumer
        # Dynamic filters from the WHERE mapping.  No-op when the feed
        # has no mapping or no consumer overrides.
        from core.feed_where_apply import apply_where_to_raw_sql
        sql = apply_where_to_raw_sql(sql, feed_config) or sql

        return _execute_duckdb_query(sql, conn, output_path, feed_config, db=db)


class SqlFileSourceStep(_SqlBranchSource):
    name = "sql_file"
    description = "Stored .sql file (BF-415 traversal-guarded)"

    def _run(self, source_id, feed_config, db, output_path):
        # BF-415 / Phase 122-C — read SQL from a stored .sql file (SqlFile
        # model) and execute it against the file's primary connection_id.
        # If feed_config provides its own connection_id, that overrides the
        # file's default (lets the same .sql run against multiple engines —
        # e.g. dev/staging/prod).  Cross-connection combine (combine_mode +
        # secondary_connection_id) is documented but executed via the same
        # path PVs use; for the basic case we just run the SQL on the
        # resolved connection.
        sf = db.get_sql_file(source_id)
        if not sf:
            raise ValueError(f"SQL file {source_id} not found")
        if not sf.get("is_active", True):
            raise ValueError(f"SQL file {source_id} is inactive")

        # Read SQL content from the file path on disk.
        # BF-415 follow-up — SqlFile.file_path is stored RELATIVE to
        # ``sql_files.storage_dir`` (see api/sql_files_api.py:144-161).
        # Previously we passed the raw value to ``open()``, which resolved
        # it against the worker process CWD and failed for every normally
        # created sql file.  Resolve against the storage root and verify
        # the resolved path lives UNDER that root so a tampered DB row
        # can't read /etc/passwd.
        _rel_path = sf.get("file_path") or ""
        if not _rel_path:
            raise ValueError(f"SQL file {source_id} has no file_path")
        try:
            from api.sql_files_api import _get_storage_dir
            _storage_root = _get_storage_dir().resolve()
            _resolved = (_storage_root / _rel_path).resolve()
        except Exception as _path_exc:
            raise ValueError(
                f"SQL file {source_id}: storage path resolution failed: {_path_exc}"
            )
        # Path traversal guard
        try:
            _resolved.relative_to(_storage_root)
        except ValueError:
            raise ValueError(
                f"SQL file {source_id}: file_path resolves outside the "
                f"storage directory (possible tampered DB row); refusing to read"
            )
        try:
            with open(_resolved, "r", encoding="utf-8") as _f:
                sql = _f.read()
        except OSError as _io_exc:
            raise ValueError(
                f"SQL file {source_id} could not be read: {_io_exc.strerror}"
            )
        if not sql.strip():
            raise ValueError(f"SQL file {source_id} is empty")

        # ── Cross-source split (2026-08-04) ───────────────────────────
        # Cross-connection SQL files store BOTH sides in one file joined
        # by ``-- ===SECONDARY===`` (api/sql_files_api._join_cross_sql).
        # Split semantics (side selection + the single-source-with-marker
        # refusal) live ONCE in core.feed.source_plan.select_sql_file_side
        # so the Spark path executes the identical rule — before this,
        # the feed path executed the whole concatenated file (a
        # guaranteed DuckDB parse error, verified by execution).
        from core.feed.source_plan import select_sql_file_side
        sql = select_sql_file_side(sql, feed_config, source_id,
                                   sf.get("name") or "")

        # Optional {{param}} substitution from query_params (mirrors the PV
        # raw_sql substitution path).  Uses the same SQL-escape helper so a
        # literal closing-quote in a param value doesn't break out of the
        # string.
        query_params = feed_config.get("query_params") or {}
        if query_params:
            try:
                from api.published_views.helpers import _substitute_params as _pv_sub
                _stub_qc = {"raw_sql": sql}
                _stub_qc = _pv_sub(_stub_qc, query_params)
                sql = _stub_qc.get("raw_sql", sql)
            except Exception as _sub_exc:
                logger.warning(
                    "[feed_engine] sql_file param substitution failed (%s) — "
                    "executing raw SQL", _sub_exc,
                )

        # Resolve the connection: explicit feed_config.connection_id wins,
        # otherwise fall back to the SqlFile's connection.
        connection_id = (
            feed_config.get("connection_id")
            or sf.get("connection_id")
        )
        if not connection_id:
            raise ValueError(
                f"sql_file {source_id} has no connection_id and feed_config "
                f"didn't override one"
            )
        conn = db.get_connection_raw(connection_id)
        if not conn:
            raise ValueError(f"Connection {connection_id} not found")

        # Round 10 hardening: load registered_tables (same reason as
        # raw_sql branch — .sql files often reference registered tables
        # by name and need views set up).
        try:
            from core.connection_manager import ConnectionManager
            _cm = ConnectionManager(db)
            feed_config["_registered_tables"] = _cm.get_registered_tables(connection_id) or []
        except Exception as _rt_exc:
            logger.debug("[feed_engine] sql_file: could not load registered_tables: %s", _rt_exc)
            feed_config["_registered_tables"] = []
        feed_config["_query_config"] = {"files": []}

        # Phase 132.38 — same WHERE-mapping wrap as the raw_sql branch.
        from core.feed_where_apply import apply_where_to_raw_sql
        sql = apply_where_to_raw_sql(sql, feed_config) or sql

        return _execute_duckdb_query(sql, conn, output_path, feed_config, db=db)
