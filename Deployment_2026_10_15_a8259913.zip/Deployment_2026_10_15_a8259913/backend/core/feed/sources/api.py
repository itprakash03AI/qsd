"""Builtin ``api`` source step — paged, authenticated HTTP bulk extract.

First dialect: SAP OData v2, the operator's month-end-balance (MEBAL)
feed — modelled on the OG ETL's ``sap_odata`` workflow
(``ETL/configs/sap_mebal_config.json`` + ``etl_polling_task_query.yaml``,
read-only reference).  A SECOND API source is CONFIGURATION of this
step (different URLs, rows_path, knobs), never a new deployment — and a
genuinely different protocol is a dropped ``source__<name>.py`` step
file, still not a deployment.

Shape of the extract (all knobs in ``query_params.source``):

  * optional DRIVER endpoint: fetch a code list (e.g. SAP company
    codes), sort it, split into groups of ``codes_per_group`` (default
    100); each group substitutes its first/last code into the entity
    URL's ``{min}`` / ``{max}`` placeholders — the OG range-filter
    pattern.  No driver → one ungrouped extract.
  * per group: page with ``$top`` / ``$skip`` (``page_size`` default
    50000, which is ALSO the hard MAX_TOP ceiling — authors can only go
    DOWN, exactly like the OG), reading the group's authoritative row
    count from ``$inlinecount=allpages`` (``count_path``, default
    ``d.__count``).
  * CORRECTNESS over throughput: a group whose received rows do not
    match its reported count is retried WHOLE (its partial temp file
    deleted first — the OG "sink truncates the partial file" semantics)
    up to ``group_max_retries``, then REFUSED.  ``allow_count_mismatch``
    and ``allow_empty_extract`` default false; the shared harness
    enforces the totals again — defence in depth.
  * bounded parallelism, both DECLARED and defaulted conservatively:
    ``max_parallel_groups`` (default 1) × ``intra_group_parallel``
    (default 1, page fetches within a group once the count is known)
    under ONE shared ``rate_limit_rps`` token bucket (default 5) — a
    feed that hammers SAP is worse than a slow one.
  * deterministic replay: ``{TIMESTAMP}`` resolves from the feed_run's
    STORED timestamp, never the wall clock, and is REFUSED when the run
    carries none; ``{YEAR}`` / ``{MONTH}`` from declared
    ``fiscal_year`` / ``fiscal_period`` or the run's business_date; all
    ``{{token}}`` names come from ``core.feed.param_resolver`` — one
    vocabulary.
  * credentials: from the feed's CONNECTION (a ``rest_api``-type
    connection row — base_url, auth_type basic/bearer/api_key/oauth2 —
    decrypted via the registry), never a literal in the feed row, never
    in a log line (every outbound message is scrubbed).

Relationship to the ``rest_api`` CONNECTOR (stated so nobody merges
them by mistake): the connector is request/response — it accumulates
rows in memory under a ``max_rows_per_query`` governor for
interactive reports.  This step is a bulk EXTRACT: streaming, count-
reconciled, group-parallel, replay-deterministic.  They share the
CONNECTION (auth registry) and the transport guards (SSRF validation
via ``core.url_safety``), not the row path.

Transport is a SEAM (kafka_arrivals precedent): anything with
``get_json(url) -> parsed`` works, injected via
``feed_config["_source_transport"]`` — every test runs with no network.
The real transport wraps ``RestApiConnector`` (auth headers, session,
retry-free single request) and validates every URL through the shared
SSRF guard.
"""
from __future__ import annotations

import json
import logging

import re
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Iterator, List, Optional, Tuple

from core.feed.sources.base import (
    ExtractContext,
    SourceRefusal,
    SourceTraits,
    StreamingSourceResolver,
    TokenBucket,
    scrub_secrets,
)

logger = logging.getLogger(__name__)

#: Hard per-page ceiling — mirrors the OG's MAX_TOP.  page_size can only
#: go DOWN from here; asking for more is refused, not clamped, so the
#: author learns the ceiling exists.
MAX_TOP = 50_000

#: Runaway-pagination guard when the source reports no count.  Tripping
#: it RAISES (never a silent partial) — same posture as the rest_api
#: connector's RestPaginationExhausted.
DEFAULT_MAX_PAGES = 100_000

_PLACEHOLDER_RE = re.compile(r"\{\{(\w+)\}\}")


class _GroupCountMismatch(Exception):
    """Internal: one group's received rows != its reported count."""

    def __init__(self, reported: int, received: int):
        self.reported = reported
        self.received = received
        super().__init__(f"reported={reported} received={received}")


class _TransportFailure(Exception):
    """Internal: a page request failed after its page-level retries.
    Message ALREADY SCRUBBED.  Deliberately not a SourceRefusal so the
    GROUP retry loop catches it and refetches the whole group — the OG
    'network drop refetches the group' semantics; only when the group
    retries are exhausted too does it become a stated refusal."""


class RestApiTransport:
    """The real transport: one authenticated GET per call via
    ``RestApiConnector`` (auth headers, pooled session, timeout), with
    the shared SSRF guard on EVERY url — absolute URLs included, because
    ``_single_request`` alone does not validate."""

    def __init__(self, connection_config: Dict[str, Any]):
        from core.connectors import get_connector
        self._connector = get_connector("rest_api", connection_config)

    def get_json(self, url: str) -> Any:
        # 2026-09-13 (Docker end-to-end).  The step's documented shape is
        # "url: absolute, or RELATIVE to the connection's base_url" -- and
        # the relative form never worked: this method validated the bare
        # path (``/odata/Balances?...``) through the SSRF guard, which
        # refuses anything without a hostname, so every relative entity
        # URL was ``Invalid URL: no hostname`` after 4 x 3 retries and a
        # FAILED run.  Invisible to the suite because every test injects a
        # fake transport (a fixture kinder than reality).  ``_build_url``
        # is the connector's own join-then-validate: a relative path gets
        # base_url in front of it, an absolute one is used as given, and
        # BOTH are validated as the URL actually dialled.
        full_url = self._connector._build_url(url)
        return self._connector._single_request("GET", full_url, {}, None)


class ApiSourceStep(StreamingSourceResolver):
    name = "api"
    description = ("Paged, authenticated HTTP bulk extract (first "
                   "dialect: SAP OData v2 — driver-code grouping, "
                   "count-reconciled, replay-deterministic)")
    traits = SourceTraits(
        streamable=True,
        replayable=True,
        reports_count=True,
        supports_partitioning=True,
        needs_connection=True,
    )

    # ── Config ─────────────────────────────────────────────────────────

    def validate_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        cfg = super().validate_config(raw)

        url = str(cfg.get("url") or "").strip()
        if not url:
            raise SourceRefusal(
                "api source requires query_params.source.url — the "
                "entity URL template (absolute, or relative to the "
                "connection's base_url)")
        cfg["url"] = url

        # ``or`` would fold an EXPLICIT empty string into the default,
        # and an empty rows_path is the only way to say "the payload IS
        # the array" — the commonest REST shape there is, and one this
        # source could not express at all until this was separated
        # (2026-09-21; same fold as the ``a or b`` cap idiom).
        _rp = cfg.get("rows_path")
        cfg["rows_path"] = "d.results" if _rp is None else str(_rp)
        cfg["count_path"] = str(cfg.get("count_path") or "d.__count")
        count_mode = str(cfg.get("count_mode") or "inline").strip().lower()
        if count_mode not in ("inline", "none"):
            raise SourceRefusal(
                f"api source count_mode must be 'inline' (read "
                f"$inlinecount from count_path) or 'none' (source "
                f"publishes no count — reconciliation impossible, say so "
                f"explicitly), got {count_mode!r}")
        cfg["count_mode"] = count_mode

        cfg["page_size"] = _int_knob(cfg, "page_size", 50_000, 1, MAX_TOP,
                                     refuse_above=True)
        cfg["max_parallel_groups"] = _int_knob(
            cfg, "max_parallel_groups", 1, 1, 32)
        cfg["intra_group_parallel"] = _int_knob(
            cfg, "intra_group_parallel", 1, 1, 8)
        cfg["rate_limit_rps"] = _float_knob(
            cfg, "rate_limit_rps", 5.0, 0.01, 100.0)
        cfg["timeout_seconds"] = _int_knob(cfg, "timeout_seconds", 120,
                                           1, 3600)
        cfg["max_retries"] = _int_knob(cfg, "max_retries", 3, 0, 10)
        cfg["retry_backoff"] = _float_knob(cfg, "retry_backoff", 2.0,
                                           0.0, 300.0)
        cfg["group_max_retries"] = _int_knob(cfg, "group_max_retries",
                                             3, 0, 10)
        cfg["group_retry_backoff"] = _float_knob(
            cfg, "group_retry_backoff", 5.0, 0.0, 600.0)
        cfg["max_pages"] = _int_knob(cfg, "max_pages", DEFAULT_MAX_PAGES,
                                     1, 10_000_000)
        cfg["top_param"] = str(cfg.get("top_param") or "$top")
        cfg["skip_param"] = str(cfg.get("skip_param") or "$skip")
        cfg["inline_count_query"] = str(
            cfg.get("inline_count_query") or "$inlinecount=allpages")

        for k in ("fiscal_year", "fiscal_period"):
            if cfg.get(k) is not None:
                cfg[k] = str(cfg[k]).strip()
        period_style = str(cfg.get("period_style") or "month").strip().lower()
        if period_style not in ("month", "poper"):
            raise SourceRefusal(
                f"api source period_style must be 'month' (2-digit MM) "
                f"or 'poper' (SAP 3-digit fiscal period, e.g. '008'), "
                f"got {period_style!r}")
        cfg["period_style"] = period_style

        driver = cfg.get("driver")
        if driver is not None:
            if not isinstance(driver, dict):
                raise SourceRefusal(
                    f"api source 'driver' must be an object, got "
                    f"{type(driver).__name__}")
            d = dict(driver)
            d_url = str(d.get("url") or "").strip()
            d_field = str(d.get("field") or "").strip()
            if not d_url or not d_field:
                raise SourceRefusal(
                    "api source driver requires 'url' (the code-list "
                    "endpoint) and 'field' (the code attribute name)")
            d["url"] = d_url
            d["field"] = d_field
            d["rows_path"] = str(d.get("rows_path") or cfg["rows_path"])
            d["codes_per_group"] = _int_knob(d, "codes_per_group", 100,
                                             1, 10_000)
            d["allow_empty"] = bool(d.get("allow_empty", False))
            cfg["driver"] = d
            if "{min}" not in url or "{max}" not in url:
                raise SourceRefusal(
                    "api source declares a driver (code grouping) but "
                    "the entity url carries no {min}/{max} placeholders "
                    "— the groups would have no way into the request; "
                    "add e.g. \"Bukrs ge '{min}' and Bukrs le '{max}'\" "
                    "to the $filter")
        else:
            if "{min}" in url or "{max}" in url:
                raise SourceRefusal(
                    "api source url carries {min}/{max} placeholders but "
                    "no driver is declared — nothing would ever fill "
                    "them; declare query_params.source.driver or remove "
                    "the placeholders")
        return cfg

    # ── Extract ────────────────────────────────────────────────────────

    def extract(self, ctx: ExtractContext) -> Iterator[Any]:
        import pyarrow.parquet as pq

        cfg = ctx.source_config
        bucket = TokenBucket(
            cfg["rate_limit_rps"],
            monotonic_fn=cfg.get("_monotonic_fn"),
            sleep_fn=cfg.get("_sleep_fn"),
        )
        sleep_fn = cfg.get("_sleep_fn") or _default_sleep
        transport = self._build_transport(ctx)

        groups = self._build_groups(ctx, transport, bucket, sleep_fn)
        if not groups:
            # Driver returned no codes and declared that acceptable —
            # zero groups, zero rows; the harness applies the
            # allow_empty_extract decision.
            return

        results: List[Tuple[int, str, int, Optional[int]]] = []
        max_workers = min(cfg["max_parallel_groups"], len(groups))
        if max_workers <= 1:
            for idx, grp in enumerate(groups):
                results.append(self._extract_group(
                    ctx, transport, bucket, sleep_fn, idx, grp))
        else:
            with ThreadPoolExecutor(
                    max_workers=max_workers,
                    thread_name_prefix="feed-api-group") as pool:
                results = list(pool.map(
                    lambda t: self._extract_group(
                        ctx, transport, bucket, sleep_fn, t[0], t[1]),
                    enumerate(groups)))

        # Concatenate per-group temp files IN GROUP ORDER — the parallel
        # path yields the same rows in the same order as the serial one.
        for idx, path, received, reported in sorted(results):
            if reported is not None:
                ctx.add_reported_count(reported)
            if received == 0:
                _remove(path)
                continue
            pf = pq.ParquetFile(path)
            try:
                for batch in pf.iter_batches(batch_size=65_536):
                    yield batch
            finally:
                try:
                    pf.close()
                except Exception:
                    pass
                _remove(path)

    # ── Internals ──────────────────────────────────────────────────────

    def _build_transport(self, ctx: ExtractContext) -> Any:
        if ctx.transport is not None:
            return ctx.transport
        conn_cfg = dict((ctx.connection or {}).get("config") or {})
        # The step's declared knobs win over the connection's defaults —
        # rate limiting is ALSO enforced by our shared bucket; setting
        # the connector's own limiter to the same declared rate keeps
        # the two guards agreeing instead of one silently dominating.
        conn_cfg["timeout_seconds"] = ctx.source_config["timeout_seconds"]
        conn_cfg["rate_limit_rps"] = ctx.source_config["rate_limit_rps"]
        try:
            return RestApiTransport(conn_cfg)
        except Exception as exc:
            raise SourceRefusal(scrub_secrets(
                f"api source could not build its HTTP transport from "
                f"connection '{(ctx.connection or {}).get('name')}': "
                f"{type(exc).__name__}: {exc}", ctx.secrets))

    def _render_url(self, template: str, ctx: ExtractContext,
                    min_code: Optional[str] = None,
                    max_code: Optional[str] = None) -> str:
        cfg = ctx.source_config
        out = template

        # {{token}} — the ONE param vocabulary (param_resolver output +
        # scalar query_params overrides).  Plain substitution, not the
        # SQL-escaping helper: this is a URL, not a SQL literal.
        def _sub(m: "re.Match[str]") -> str:
            key = m.group(1)
            v = ctx.params.get(key)
            if v is None:
                raise SourceRefusal(
                    f"api source url references {{{{{key}}}}} but the "
                    f"param resolver knows no such token (feed "
                    f"query_params can pin one)")
            return str(v)
        out = _PLACEHOLDER_RE.sub(_sub, out)

        # SAP-vocabulary placeholders.
        bd = str(ctx.params.get("business_date") or "")
        year = cfg.get("fiscal_year") or (bd[:4] if len(bd) >= 7 else "")
        month = cfg.get("fiscal_period") or (bd[5:7] if len(bd) >= 7 else "")
        if month and not cfg.get("fiscal_period") and \
                cfg.get("period_style") == "poper":
            # SAP Poper is 3-digit ('006' = June).  Derived only — an
            # explicit fiscal_period is used verbatim.
            month = f"{int(month):03d}"
        if "{YEAR}" in out:
            if not year:
                raise SourceRefusal(
                    "api source url uses {YEAR} but neither fiscal_year "
                    "nor a business_date is available")
            out = out.replace("{YEAR}", year)
        if "{MONTH}" in out:
            if not month:
                raise SourceRefusal(
                    "api source url uses {MONTH} but neither "
                    "fiscal_period nor a business_date is available")
            out = out.replace("{MONTH}", month)
        if "{TIMESTAMP}" in out:
            # Deterministic replay: the RUN's stored timestamp, never
            # datetime.now().  A run without a stored stamp is refused —
            # inventing one would make every retry a different call.
            if not ctx.run_timestamp:
                raise SourceRefusal(
                    "api source url uses {TIMESTAMP} but this execution "
                    "has no feed_run with a stored timestamp "
                    "(scheduled_time/created_at) — refusing to fall "
                    "back to the wall clock, which would break "
                    "deterministic replay.  Trigger via a feed run.")
            out = out.replace("{TIMESTAMP}", ctx.run_timestamp)
        if min_code is not None:
            out = out.replace("{min}", str(min_code))
        if max_code is not None:
            out = out.replace("{max}", str(max_code))
        return out

    def _get_json(self, ctx: ExtractContext, transport: Any,
                  bucket: TokenBucket, sleep_fn: Any, url: str) -> Any:
        """One logical GET: rate-limited, retried with backoff, secrets
        scrubbed from every failure."""
        cfg = ctx.source_config
        last: Optional[BaseException] = None
        for attempt in range(cfg["max_retries"] + 1):
            if ctx.cancel_event is not None and \
                    getattr(ctx.cancel_event, "is_set", lambda: False)():
                raise SourceRefusal("api source extract cancelled")
            bucket.acquire()
            try:
                return transport.get_json(url)
            except Exception as exc:  # noqa: BLE001 — reported, never swallowed
                last = exc
                if attempt < cfg["max_retries"]:
                    sleep_fn(cfg["retry_backoff"] * (attempt + 1))
        raise _TransportFailure(scrub_secrets(
            f"api source request failed after "
            f"{cfg['max_retries'] + 1} attempt(s): "
            f"{type(last).__name__}: {last} (url={url})", ctx.secrets))

    def _build_groups(self, ctx: ExtractContext, transport: Any,
                      bucket: TokenBucket, sleep_fn: Any,
                      ) -> List[Tuple[Optional[str], Optional[str]]]:
        cfg = ctx.source_config
        driver = cfg.get("driver")
        if not driver:
            return [(None, None)]
        url = self._render_url(driver["url"], ctx)
        try:
            data = self._get_json(ctx, transport, bucket, sleep_fn, url)
        except _TransportFailure as exc:
            # No group exists yet to retry — the roster fetch failing is
            # a whole-extract refusal (already scrubbed).
            raise SourceRefusal(str(exc))
        rows = _dig(data, driver["rows_path"])
        if not isinstance(rows, list):
            raise SourceRefusal(
                f"api source driver endpoint returned no list at "
                f"rows_path '{driver['rows_path']}' — got "
                f"{type(rows).__name__}")
        codes: List[str] = []
        for r in rows:
            if isinstance(r, dict) and r.get(driver["field"]) is not None:
                codes.append(str(r[driver["field"]]))
        codes = sorted(set(codes))
        if not codes:
            if driver["allow_empty"]:
                logger.warning(
                    "[feed-sources] api driver returned ZERO codes and "
                    "driver.allow_empty=true — extract will be empty")
                return []
            raise SourceRefusal(
                "api source driver endpoint returned ZERO codes — "
                "refusing to run an extract whose scope is empty (an "
                "empty roster and a broken roster endpoint look "
                "identical; set driver.allow_empty=true only if an "
                "empty roster is a valid business state)")
        n = driver["codes_per_group"]
        return [(chunk[0], chunk[-1])
                for chunk in (codes[i:i + n]
                              for i in range(0, len(codes), n))]

    def _extract_group(self, ctx: ExtractContext, transport: Any,
                       bucket: TokenBucket, sleep_fn: Any, idx: int,
                       group: Tuple[Optional[str], Optional[str]],
                       ) -> Tuple[int, str, int, Optional[int]]:
        """Fetch ONE group to its own temp parquet.  Count mismatch or a
        transport failure retries the WHOLE group (partial file deleted
        first) — the OG per-group semantics."""
        import os
        cfg = ctx.source_config
        path = os.path.join(ctx.tmp_dir, f"group_{idx:05d}.parquet")
        last_reason = ""
        for attempt in range(cfg["group_max_retries"] + 1):
            _remove(path)  # a retry always restreams from scratch
            try:
                received, reported = self._fetch_group_to_file(
                    ctx, transport, bucket, sleep_fn, group, path)
                if reported is not None and received != reported:
                    raise _GroupCountMismatch(reported, received)
                return (idx, path, received, reported)
            except _GroupCountMismatch as cm:
                last_reason = (
                    f"group {idx} (codes {group[0]}..{group[1]}) count "
                    f"mismatch: source reported {cm.reported} row(s), "
                    f"received {cm.received}")
            except SourceRefusal:
                raise
            except Exception as exc:  # noqa: BLE001 — retried, then surfaced
                last_reason = (
                    f"group {idx} (codes {group[0]}..{group[1]}) fetch "
                    f"failed: {type(exc).__name__}: {exc}")
            if attempt < cfg["group_max_retries"]:
                logger.warning(
                    "[feed-sources] api %s — retrying whole group "
                    "(attempt %d/%d)",
                    scrub_secrets(last_reason, ctx.secrets),
                    attempt + 1, cfg["group_max_retries"])
                sleep_fn(cfg["group_retry_backoff"] * (attempt + 1))
        _remove(path)
        if cfg["allow_count_mismatch"] and "count mismatch" in last_reason:
            # Explicitly accepted: refetch once more WITHOUT the
            # reconciliation gate so the operator gets what the source
            # will give, with the shortfall on record at ERROR.
            logger.error(
                "[feed-sources] api %s — ACCEPTED by explicit "
                "allow_count_mismatch=true",
                scrub_secrets(last_reason, ctx.secrets))
            received, reported = self._fetch_group_to_file(
                ctx, transport, bucket, sleep_fn, group, path)
            return (idx, path, received, reported)
        raise SourceRefusal(scrub_secrets(
            f"api source REFUSED after {cfg['group_max_retries'] + 1} "
            f"attempt(s): {last_reason}.  allow_count_mismatch is false "
            f"— a short group delivered as success is the exact failure "
            f"this platform exists to prevent.", ctx.secrets))

    def _fetch_group_to_file(self, ctx: ExtractContext, transport: Any,
                             bucket: TokenBucket, sleep_fn: Any,
                             group: Tuple[Optional[str], Optional[str]],
                             path: str) -> Tuple[int, Optional[int]]:
        """Stream one group's pages into ``path``.  Returns
        (received_rows, reported_count_or_None)."""
        import pyarrow as pa
        import pyarrow.parquet as pq

        cfg = ctx.source_config
        base = self._render_url(cfg["url"], ctx, group[0], group[1])
        sep = "&" if "?" in base else "?"
        page_size = cfg["page_size"]
        inline = (cfg["count_mode"] == "inline")

        def _page_url(skip: int) -> str:
            u = (f"{base}{sep}{cfg['top_param']}={page_size}"
                 f"&{cfg['skip_param']}={skip}")
            if inline:
                u += f"&{cfg['inline_count_query']}"
            return u

        writer = None
        schema = None
        received = 0
        reported: Optional[int] = None
        texted: set = set()

        def _write_rows(rows: List[dict]) -> None:
            nonlocal writer, schema, received
            if not rows:
                return
            table = pa.Table.from_pylist(_uniform_fields(rows, texted))
            if writer is None:
                schema = table.schema
                writer = pq.ParquetWriter(path, schema, compression="zstd")
            elif table.schema != schema:
                # from_pylist re-infers types per chunk — pin to the
                # first page's schema; an uncastable drift is a refusal.
                try:
                    table = table.cast(schema)
                except Exception as _c_exc:
                    raise SourceRefusal(scrub_secrets(
                        f"api source page schema drifted from the "
                        f"group's first page and could not be cast "
                        f"({_c_exc})", ctx.secrets))
            for b in table.to_batches():
                writer.write_batch(b)
            received += table.num_rows

        try:
            # First page — also carries the count when inline.
            data = self._get_json(ctx, transport, bucket, sleep_fn,
                                  _page_url(0))
            rows = _rows_at(data, cfg["rows_path"])
            if inline:
                raw_count = _dig(data, cfg["count_path"])
                if raw_count is None:
                    raise SourceRefusal(
                        f"api source count_mode=inline but the response "
                        f"carries nothing at count_path "
                        f"'{cfg['count_path']}' — either fix count_path "
                        f"or declare count_mode='none' (which also "
                        f"declares that reconciliation is impossible)")
                try:
                    reported = int(str(raw_count))
                except (TypeError, ValueError):
                    raise SourceRefusal(
                        f"api source count at '{cfg['count_path']}' is "
                        f"not an integer: {raw_count!r}")
            _write_rows(rows)

            if reported is not None:
                # Offsets known up front — bounded intra-group page
                # parallelism, results consumed IN ORDER (executor.map).
                offsets = list(range(page_size, reported, page_size))
                intra = min(cfg["intra_group_parallel"], len(offsets)) \
                    if offsets else 0
                if intra > 1:
                    with ThreadPoolExecutor(
                            max_workers=intra,
                            thread_name_prefix="feed-api-page") as pool:
                        for page_rows in pool.map(
                                lambda s: _rows_at(
                                    self._get_json(ctx, transport, bucket,
                                                   sleep_fn, _page_url(s)),
                                    cfg["rows_path"]),
                                offsets):
                            _write_rows(page_rows)
                else:
                    for s in offsets:
                        page_rows = _rows_at(
                            self._get_json(ctx, transport, bucket,
                                           sleep_fn, _page_url(s)),
                            cfg["rows_path"])
                        _write_rows(page_rows)
            else:
                # No count — sequential paging until a short/empty page.
                pages = 1
                while len(rows) == page_size:
                    if pages >= cfg["max_pages"]:
                        raise SourceRefusal(
                            f"api source hit the {cfg['max_pages']}-page "
                            f"guard while the endpoint was still "
                            f"returning full pages ({received} row(s) "
                            f"so far) — refusing a silently truncated "
                            f"result.  Either the offset is not "
                            f"advancing at the source, or this feed "
                            f"needs max_pages raised.")
                    rows = _rows_at(
                        self._get_json(ctx, transport, bucket, sleep_fn,
                                       _page_url(pages * page_size)),
                        cfg["rows_path"])
                    _write_rows(rows)
                    pages += 1
        finally:
            if writer is not None:
                try:
                    writer.close()
                except Exception:
                    pass
        return received, reported


def _value_kind(v: Any) -> str:
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "text"
    if isinstance(v, (list, tuple)):
        return "list"
    if isinstance(v, dict):
        return "object"
    return type(v).__name__


def _one_kind(values: List[Any], depth: int = 0) -> bool:
    """True when Arrow can type ``values`` as ONE column -- the same kind
    everywhere, and, for lists and objects, consistent all the way down.

    2026-10-04: the top-level check alone missed a field whose OBJECTS held
    a key that was a list in one row and a string in the next -- Arrow's
    struct inference refuses that exactly as it refuses the top-level mix.
    """
    kinds = {_value_kind(v) for v in values if v is not None}
    if len(kinds) > 1:
        return False
    if not kinds or depth > 32:
        return True
    kind = next(iter(kinds))
    if kind == "list":
        return _one_kind([x for v in values if v is not None for x in v], depth + 1)
    if kind == "object":
        sub: Dict[str, list] = {}
        for v in values:
            if v is not None:
                for sk, sv in v.items():
                    sub.setdefault(sk, []).append(sv)
        return all(_one_kind(sv, depth + 1) for sv in sub.values())
    return True


def _uniform_fields(rows: List[dict], texted: set) -> List[dict]:
    """Make every field ONE kind across the rows, so Arrow can type it.

    2026-10-04, live: a feed reading QueryStudio's own ``/api/feeds`` failed
    with ``ArrowInvalid: cannot mix list and non-list, non-null values`` --
    one field was a list in some rows and a string in others.  Real APIs do
    this all the time (a tag that is a string or a list of strings, an id
    that is a number or a string), and ``pa.Table.from_pylist`` refuses the
    whole page, so the feed failed on data that is perfectly deliverable.

    A field whose non-null values are of MORE THAN ONE kind is delivered as
    TEXT: lists and objects as compact JSON, scalars as their text.  Nothing
    is dropped and nothing is guessed.  A field with one kind keeps its type.
    ``texted`` carries the decision across pages, so page 2 never types a
    column page 1 delivered as text (the schema pin would refuse that).
    """
    values: Dict[str, list] = {}
    for r in rows:
        if isinstance(r, dict):
            for k, v in r.items():
                values.setdefault(k, []).append(v)
    for k, vs in values.items():
        if k not in texted and not _one_kind(vs):
            texted.add(k)
    if not texted:
        return rows
    out = []
    for r in rows:
        if not isinstance(r, dict):
            out.append(r)
            continue
        r = dict(r)
        for k in texted:
            v = r.get(k)
            if v is None:
                continue
            if isinstance(v, (list, tuple, dict)):
                r[k] = json.dumps(v, separators=(",", ":"), default=str)
            elif isinstance(v, bool):
                r[k] = "true" if v else "false"
            else:
                r[k] = str(v)
        out.append(r)
    return out


def _shape_of(data: Any) -> str:
    """What the payload actually looks like, for a refusal an operator
    can act on without adding a print statement to production."""
    if isinstance(data, dict):
        keys = sorted(data)[:8]
        return (f"a JSON object whose top-level keys are {keys}"
                + (" (truncated)" if len(data) > 8 else ""))
    if isinstance(data, list):
        return (f"a bare JSON array of {len(data)} item(s) — declare "
                f"rows_path='' (empty) to take the array itself")
    return f"a bare {type(data).__name__}"


def _rows_at(data: Any, rows_path: str) -> List[dict]:
    rows = _dig(data, rows_path)
    if rows is None:
        # 2026-09-21 — this returned [].  UNKNOWN IS NOT EMPTY: a
        # rows_path that does not describe the payload is a
        # MISCONFIGURATION, and reporting it as "this page has no rows"
        # is the exact shape this platform refuses everywhere else.  The
        # branch immediately below already refuses a rows_path that
        # lands on a non-list, which is the same mistake one step later.
        #
        # Proved live on 2026-09-21, first time the ``api`` source was
        # ever run: rows_path pointing at a key the response does not
        # have, against an endpoint returning 20 records, gave
        # status=completed / total_rows=0 / a 0-BYTE CSV DELIVERED and
        # no error, as soon as the feed declared
        # allow_empty_extract=true — which an operator sets the first
        # time the feed legitimately has an empty day.
        raise SourceRefusal(
            f"api source response carries NOTHING at rows_path "
            f"{rows_path!r}; the response is {_shape_of(data)}. A "
            f"rows_path that does not describe the payload is a "
            f"misconfiguration, not an empty page — an empty LIST at "
            f"rows_path is how this source says 'no rows'.")
    if not isinstance(rows, list):
        raise SourceRefusal(
            f"api source response carries no list at rows_path "
            f"'{rows_path}' — got {type(rows).__name__}")
    return rows


def _dig(data: Any, path: str) -> Any:
    """Walk a dotted path into parsed JSON — None on any miss."""
    cur = data
    for part in (path or "").split("."):
        if not part:
            continue
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


def _int_knob(cfg: Dict[str, Any], key: str, default: int, lo: int,
              hi: int, refuse_above: bool = False) -> int:
    raw = cfg.get(key)
    if raw is None or raw == "":
        return default
    try:
        v = int(raw)
    except (TypeError, ValueError):
        raise SourceRefusal(
            f"api source config key '{key}' must be an integer, got "
            f"{raw!r}")
    if v < lo:
        raise SourceRefusal(
            f"api source config key '{key}'={v} is below the minimum "
            f"{lo}")
    if v > hi:
        if refuse_above:
            raise SourceRefusal(
                f"api source config key '{key}'={v} exceeds the hard "
                f"ceiling {hi} (operators can only go DOWN from the "
                f"ceiling — mirror of the OG MAX_TOP rule)")
        raise SourceRefusal(
            f"api source config key '{key}'={v} exceeds the maximum "
            f"{hi}")
    return v


def _float_knob(cfg: Dict[str, Any], key: str, default: float, lo: float,
                hi: float) -> float:
    raw = cfg.get(key)
    if raw is None or raw == "":
        return default
    try:
        v = float(raw)
    except (TypeError, ValueError):
        raise SourceRefusal(
            f"api source config key '{key}' must be a number, got "
            f"{raw!r}")
    if not (lo <= v <= hi):
        raise SourceRefusal(
            f"api source config key '{key}'={v} is outside [{lo}, {hi}]")
    return v


def _default_sleep(seconds: float) -> None:
    import time
    if seconds > 0:
        time.sleep(seconds)


def _remove(path: str) -> None:
    import os
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
