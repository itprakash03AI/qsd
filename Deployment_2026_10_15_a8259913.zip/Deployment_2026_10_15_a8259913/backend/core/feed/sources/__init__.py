"""Feed-source steps — the SOURCE role of :mod:`core.feed.steps`.

Layout:
  * :mod:`core.feed.sources.base` — the role's typed contract
    (``SourceResolver`` / ``StreamingSourceResolver``, ``SourceTraits``,
    ``ExtractContext``, the streaming harness, secret hygiene, the
    rate limiter).
  * :mod:`core.feed.sources.api` — builtin ``api`` step: paged,
    authenticated HTTP bulk extract (first dialect: SAP OData v2 —
    the month-end-balance shape).
  * :mod:`core.feed.sources.landed_file` — builtin ``landed_file``
    step: a feed whose input is a file already landed on local/NFS
    storage (the OG ``file_standalone`` shape).

Every source kind is a step (2026-09-03): the four SQL kinds'
incident-hardened branch bodies moved VERBATIM into
:mod:`core.feed.sources.sql_branches` (golden-equivalence pinned by
``tests/test_feed_sql_sources_golden_2026_09_03.py``), and the engine's
``_run_single_source_native_query`` is pure
``core.feed.steps.get_step("source", source_type)`` dispatch.
"""
from __future__ import annotations

from core.feed.sources.base import (  # noqa: F401 — public re-exports
    ExtractContext,
    SourceRefusal,
    SourceRequest,
    SourceResolver,
    SourceTraits,
    StreamingSourceResolver,
    TokenBucket,
    collect_secrets,
    run_extract_to_parquet,
    scrub_secrets,
    stored_run_timestamp,
)
