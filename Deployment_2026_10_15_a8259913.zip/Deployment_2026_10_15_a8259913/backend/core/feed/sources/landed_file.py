"""Builtin ``landed_file`` source step — a feed whose input is a file
already landed on local/NFS storage (the OG ``file_standalone`` shape).

Scope, stated so nobody builds a duplicate: QueryStudio ALREADY serves
"query a file" well — registered tables on ``local``/``s3`` connections
plus the four SQL source kinds (DuckDB reads CSV/parquet, prunes,
filters).  What was missing is "take THIS landed file as the feed's
rows, with the platform's refusal posture": an expected row count to
reconcile against (a landed file's producer often publishes one in a
CTL sidecar), an explicit empty-extract decision, streaming, and
``{{token}}`` path templates resolved from the RUN's stored values so a
re-run reads the same file.  S3-landed files stay with the existing S3
SQL lanes — this step reads the local/NFS filesystem only, through a
``local``-type connection's ``base_path`` with the same traversal guard
the schema browser applies.

Config (``query_params.source``):

    path            REQUIRED — relative to the connection's base_path;
                    ``{{token}}`` templates resolve via
                    core.feed.param_resolver (business_date etc.)
    format          csv | delimited | parquet (default: by extension)
    delimiter       for delimited (default ",")
    has_header      default true
    encoding        default utf-8
    batch_rows      streaming batch size (default 65536)
    expected_rows   optional int — the producer's declared count
    sidecar         optional {"path": "...ctl", "pattern":
                    "RECORD_COUNT=(\\d+)"} — read the expected count
                    from a control file next to the data
    allow_count_mismatch / allow_empty_extract — shared harness knobs
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, Iterator, Optional

from core.feed.sources.base import (
    ExtractContext,
    SourceRefusal,
    SourceTraits,
    StreamingSourceResolver,
)

logger = logging.getLogger(__name__)

_PLACEHOLDER_RE = re.compile(r"\{\{(\w+)\}\}")
_FORMATS = ("csv", "delimited", "parquet")
_EXT_FORMAT = {".csv": "csv", ".txt": "delimited", ".dat": "delimited",
               ".tsv": "delimited", ".parquet": "parquet"}


class LandedFileSourceStep(StreamingSourceResolver):
    name = "landed_file"
    description = ("A file already landed on local/NFS storage as the "
                   "feed's rows — count-reconciled against the "
                   "producer's declared count, streaming, "
                   "replay-deterministic paths")
    traits = SourceTraits(
        streamable=True,
        replayable=True,
        reports_count=True,       # when expected_rows / sidecar declared
        supports_partitioning=False,
        needs_connection=True,
    )

    def validate_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        cfg = super().validate_config(raw)
        path = str(cfg.get("path") or "").strip()
        if not path:
            raise SourceRefusal(
                "landed_file source requires query_params.source.path "
                "(relative to the connection's base_path)")
        cfg["path"] = path

        fmt = str(cfg.get("format") or "").strip().lower()
        if fmt and fmt not in _FORMATS:
            raise SourceRefusal(
                f"landed_file format must be one of {list(_FORMATS)}, "
                f"got {fmt!r} — a typo must not become a new behaviour")
        cfg["format"] = fmt  # "" = infer from extension at extract time

        cfg["delimiter"] = str(cfg.get("delimiter") or ",")
        if len(cfg["delimiter"]) != 1:
            raise SourceRefusal(
                f"landed_file delimiter must be a single character, got "
                f"{cfg['delimiter']!r}")
        has_header = cfg.get("has_header")
        cfg["has_header"] = True if has_header is None else bool(has_header)
        cfg["encoding"] = str(cfg.get("encoding") or "utf-8")
        try:
            cfg["batch_rows"] = int(cfg.get("batch_rows") or 65_536)
        except (TypeError, ValueError):
            raise SourceRefusal(
                f"landed_file batch_rows must be an integer, got "
                f"{cfg.get('batch_rows')!r}")
        if cfg["batch_rows"] <= 0:
            raise SourceRefusal(
                f"landed_file batch_rows must be > 0, got "
                f"{cfg['batch_rows']}")

        exp = cfg.get("expected_rows")
        if exp is not None:
            try:
                exp = int(exp)
            except (TypeError, ValueError):
                raise SourceRefusal(
                    f"landed_file expected_rows must be an integer, got "
                    f"{cfg.get('expected_rows')!r}")
            if exp < 0:
                raise SourceRefusal(
                    f"landed_file expected_rows must be >= 0, got {exp}")
        cfg["expected_rows"] = exp

        sidecar = cfg.get("sidecar")
        if sidecar is not None:
            if not isinstance(sidecar, dict) or \
                    not str(sidecar.get("path") or "").strip():
                raise SourceRefusal(
                    "landed_file sidecar must be an object with 'path' "
                    "(the control file, relative to base_path)")
            sc = dict(sidecar)
            sc["path"] = str(sc["path"]).strip()
            sc["pattern"] = str(sc.get("pattern")
                                or r"RECORD_COUNT=(\d+)")
            try:
                re.compile(sc["pattern"])
            except re.error as rexc:
                raise SourceRefusal(
                    f"landed_file sidecar.pattern is not a valid regex: "
                    f"{rexc}")
            cfg["sidecar"] = sc
        if exp is not None and sidecar is not None:
            raise SourceRefusal(
                "landed_file declares BOTH expected_rows and a sidecar "
                "— two count authorities can disagree; declare one")
        return cfg

    # ── Extract ────────────────────────────────────────────────────────

    def extract(self, ctx: ExtractContext) -> Iterator[Any]:
        cfg = ctx.source_config
        base = self._base_path(ctx)
        data_path = self._resolve_under(base, cfg["path"], ctx)
        if not data_path.is_file():
            raise SourceRefusal(
                f"landed_file: {data_path} does not exist — an absent "
                f"landed file is a refusal, not an empty feed (the "
                f"producer has not delivered)")

        reported = self._expected_count(ctx, base)
        if reported is not None:
            ctx.add_reported_count(reported)

        fmt = cfg["format"] or _EXT_FORMAT.get(data_path.suffix.lower())
        if not fmt:
            raise SourceRefusal(
                f"landed_file: cannot infer format from extension "
                f"{data_path.suffix!r} — declare "
                f"query_params.source.format ({list(_FORMATS)})")

        if fmt == "parquet":
            yield from self._stream_parquet(data_path, cfg)
        else:
            yield from self._stream_csv(data_path, cfg, fmt)

    # ── Internals ──────────────────────────────────────────────────────

    def _base_path(self, ctx: ExtractContext) -> Path:
        conn = ctx.connection or {}
        conn_cfg = conn.get("config") or {}
        base = str(conn_cfg.get("base_path") or "").strip()
        if not base:
            ctype = conn.get("connection_type") or conn_cfg.get("type") \
                or "?"
            raise SourceRefusal(
                f"landed_file reads the local/NFS filesystem through a "
                f"connection with a base_path; connection "
                f"'{conn.get('name')}' (type {ctype}) has none.  "
                f"S3-landed files are served by the existing S3 SQL "
                f"lanes, not this step.")
        return Path(base).resolve()

    def _resolve_under(self, base: Path, template: str,
                       ctx: ExtractContext) -> Path:
        """Render ``{{token}}`` templates and confine the result under
        ``base`` — same traversal posture as the schema browser and the
        sql_file loader (BF-415)."""
        def _sub(m: "re.Match[str]") -> str:
            key = m.group(1)
            v = ctx.params.get(key)
            if v is None:
                raise SourceRefusal(
                    f"landed_file path references {{{{{key}}}}} but the "
                    f"param resolver knows no such token")
            return str(v)
        rendered = _PLACEHOLDER_RE.sub(_sub, template)
        resolved = (base / rendered).resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            raise SourceRefusal(
                f"landed_file path {rendered!r} resolves outside the "
                f"connection's base_path — refusing (path traversal)")
        return resolved

    def _expected_count(self, ctx: ExtractContext,
                        base: Path) -> Optional[int]:
        cfg = ctx.source_config
        if cfg.get("expected_rows") is not None:
            return int(cfg["expected_rows"])
        sc = cfg.get("sidecar")
        if not sc:
            return None
        sc_path = self._resolve_under(base, sc["path"], ctx)
        if not sc_path.is_file():
            raise SourceRefusal(
                f"landed_file sidecar {sc_path} does not exist — the "
                f"declared count authority is missing, so the extract "
                f"cannot be reconciled; refusing rather than delivering "
                f"unverified (remove the sidecar declaration only if "
                f"the producer stops publishing one)")
        try:
            text = sc_path.read_text(encoding=cfg["encoding"],
                                     errors="replace")
        except OSError as exc:
            raise SourceRefusal(
                f"landed_file sidecar {sc_path} unreadable: "
                f"{exc.strerror}")
        m = re.search(sc["pattern"], text)
        if not m or not m.groups():
            raise SourceRefusal(
                f"landed_file sidecar {sc_path} carries nothing "
                f"matching pattern {sc['pattern']!r} (group 1 must be "
                f"the count) — cannot reconcile; fix the pattern or the "
                f"producer")
        try:
            return int(m.group(1))
        except (TypeError, ValueError):
            raise SourceRefusal(
                f"landed_file sidecar count {m.group(1)!r} is not an "
                f"integer")

    def _stream_parquet(self, path: Path,
                        cfg: Dict[str, Any]) -> Iterator[Any]:
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(str(path))
        try:
            for batch in pf.iter_batches(batch_size=cfg["batch_rows"]):
                yield batch
        finally:
            try:
                pf.close()
            except Exception:
                pass

    def _stream_csv(self, path: Path, cfg: Dict[str, Any],
                    fmt: str) -> Iterator[Any]:
        import pyarrow.csv as pacsv
        delimiter = cfg["delimiter"] if fmt == "delimited" else ","
        read_opts = pacsv.ReadOptions(encoding=cfg["encoding"])
        if not cfg["has_header"]:
            read_opts.autogenerate_column_names = True
        parse_opts = pacsv.ParseOptions(delimiter=delimiter)
        with pacsv.open_csv(str(path), read_options=read_opts,
                            parse_options=parse_opts) as reader:
            for batch in reader:
                if batch.num_rows:
                    yield batch
