"""The SOURCE role — typed ABC + streaming harness for feed-source steps.

2026-09-02.  Every feed source the platform had was SQL-over-a-connection,
hardcoded as a branch chain in ``feed_engine._run_single_source_native_query``
(``saved_query | sql_file | published_view | raw_sql | else: raise``).  A
SAP month-end-balance feed — an API extract, not a query — could not be
configured at all, and adding it as a fifth branch would have repeated
the mistake the delivery side already fixed once.

The MECHANISM (registry, discovery, three-outcome resolution, boot
report) lives in :mod:`core.feed.steps` and is shared with the delivery
role.  What lives HERE is the source role's own typed contract:

  * :class:`SourceResolver` — ``role="source"``; ``resolve(request)``
    returns the path of a written parquet.  The step's ``name`` is the
    ``source_type`` value a feed author writes.
  * :class:`SourceTraits` — the capability declaration (streamable,
    replayable, reports-count, supports-partitioning, needs-connection).
    The engine and router trust the declaration; UNKNOWN = UNSAFE.
  * :class:`StreamingSourceResolver` — the base concrete resolvers
    extend: implements ``resolve`` by building a per-run
    :class:`ExtractContext` (connection credentials from the registry,
    ONE param vocabulary via ``core.feed.param_resolver``, the stored
    run timestamp for deterministic replay) and streaming the step's
    ``extract`` through :func:`run_extract_to_parquet`.
  * :func:`run_extract_to_parquet` — the ONE harness.  The correctness
    posture lives here, not in each step:
      - **count reconciliation refuses a mismatch** (default
        ``allow_count_mismatch=false`` — silent truncation with a
        success status is the failure this platform exists to prevent);
      - **an empty extract is a decision, not a default** (refused
        unless the feed declares ``allow_empty_extract=true`` — mirrors
        ``partition_shape.on_empty``);
      - a refusal DELETES the partial output file, so a refused extract
        can never be delivered by a later stage that only checks the
        path exists.
  * :func:`scrub_secrets` — credentials come from the connection
    registry and must never appear in a log line or an error message.
  * :class:`TokenBucket` — the shared, injectable-clock rate limiter so
    "bounded parallelism and rate limiting, both declared" is one
    tested implementation rather than one per step.

``extract`` yields ``pyarrow.RecordBatch`` chunks — NEVER a list.  A
160M-row extract must be O(one chunk) in memory, exactly like the
engine's ``to_arrow_reader -> ParquetWriter`` lanes.
"""
from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional

from core.feed.steps import CONTRACT, FeedStep

logger = logging.getLogger(__name__)


class SourceRefusal(ValueError):
    """A DELIBERATE, stated refusal (count mismatch, empty extract,
    missing prerequisite).  Subclasses ``ValueError`` so the engine's
    retry loop treats it as a deterministic configuration/correctness
    error — same posture as ``UnsupportedDeliveryTarget``."""


@dataclass(frozen=True)
class SourceTraits:
    """What a source step declares about itself."""
    #: Rows arrive in bounded chunks (required for this contract — a
    #: non-streamable source has no place in this platform).
    streamable: bool = True
    #: Re-running the same feed_run reproduces the same extract
    #: (placeholders resolve from STORED run values, never wall clock).
    replayable: bool = False
    #: The source can report an authoritative row count to reconcile
    #: against.  False means the harness has nothing to compare — the
    #: completeness certificate must rely on downstream recounts.
    reports_count: bool = False
    #: The source can split its extract into parallel partitions/groups.
    supports_partitioning: bool = False
    #: The source resolves credentials/endpoint from the feed's
    #: connection row (``db.get_connection_raw``).
    needs_connection: bool = True
    #: 2026-09-03 (router step_source floor) — this source is a
    #: SQL-over-a-connection SHAPE: its definition resolves to SQL that
    #: the Spark lanes (airflow / spark_k8s) can ALSO serve by resolving
    #: the SQL themselves (generic_feed.py).  False (the default) means
    #: only the native step dispatch can run it, and the router floors
    #: any Spark choice to native.  Declared BY the step so the router
    #: never needs a hardcoded name list.
    sql_shape: bool = False

    def to_dict(self) -> Dict[str, bool]:
        return {
            "streamable": self.streamable,
            "replayable": self.replayable,
            "reports_count": self.reports_count,
            "supports_partitioning": self.supports_partitioning,
            "needs_connection": self.needs_connection,
            "sql_shape": self.sql_shape,
        }


@dataclass
class SourceRequest:
    """What the engine hands a source step: the feed row, where to write,
    and the DB handle for registry lookups.  ``source_id`` is carried
    for signature parity with the SQL branches; step-served sources are
    configured entirely by ``query_params["source"]`` — the feed row IS
    the source definition."""
    feed_config: Dict[str, Any]
    output_path: str
    db: Any = None
    source_id: Any = None


@dataclass
class ExtractContext:
    """Everything ONE extract run may read — built per run so step
    instances stay stateless and concurrent runs share no mutable
    state."""
    feed_config: Dict[str, Any]
    #: The validated ``query_params["source"]`` block — the step's whole
    #: configuration surface.
    source_config: Dict[str, Any]
    #: Decrypted connection row (``db.get_connection_raw``) or None when
    #: the step's traits say ``needs_connection=False``.
    connection: Optional[Dict[str, Any]]
    #: Calendar-aware token dict from ``core.feed.param_resolver`` —
    #: ``business_date``, ``month_end``, ``prev_eom``, ``wd1..15`` … one
    #: vocabulary, never a second one.
    params: Dict[str, Any]
    feed_run: Optional[Dict[str, Any]] = None
    #: DB-stored run timestamp (ISO-8601, UTC) for the ``{TIMESTAMP}``
    #: placeholder — from the feed_run row (scheduled_time/created_at),
    #: NEVER ``datetime.now()``.  None when the run has no stored stamp;
    #: a step whose template needs it must REFUSE then, not invent one.
    run_timestamp: Optional[str] = None
    #: Scratch directory for per-group temp files; the harness owns the
    #: final output path.
    tmp_dir: str = ""
    #: Secret VALUES (never keys) collected from the connection config —
    #: everything that must never reach a log line.  Steps pass every
    #: outbound error message through :func:`scrub_secrets` with this.
    secrets: List[str] = field(default_factory=list)
    #: Test seam: a transport object injected instead of the real HTTP
    #: stack (same idea as kafka_arrivals' transport — every test runs
    #: with no network).
    transport: Any = None
    cancel_event: Any = None
    #: Source-authoritative row count, accumulated by the step during
    #: extract via :meth:`add_reported_count`.  None = never reported.
    _reported_count: Optional[int] = None

    def add_reported_count(self, n: int) -> None:
        """Accumulate the source's own row count (e.g. one OData
        ``__count`` per group).  The harness reconciles the TOTAL."""
        self._reported_count = (self._reported_count or 0) + int(n)

    @property
    def reported_count(self) -> Optional[int]:
        return self._reported_count


class SourceResolver(FeedStep, ABC):
    """One source kind.  ``name`` is the ``source_type`` a feed author
    writes; ``resolve`` must write a parquet and return its path, or
    raise with an operator-facing message."""
    role = "source"
    contract = CONTRACT
    description: str = ""
    traits: SourceTraits = SourceTraits()

    @abstractmethod
    def resolve(self, request: SourceRequest) -> str:
        """Materialise this source for one run → parquet path."""


class StreamingSourceResolver(SourceResolver):
    """The base concrete source steps extend: ``resolve`` builds the
    per-run :class:`ExtractContext` and streams ``extract`` through the
    shared harness, so every step inherits the refusal posture instead
    of re-implementing (or forgetting) it."""

    def validate_config(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        """Normalise + type the ``query_params["source"]`` block.  MUST
        refuse (raise :class:`SourceRefusal`) on a config it cannot run
        rather than guessing — a typo must not become a new behaviour.
        Base implementation handles the two shared correctness knobs."""
        cfg = dict(raw or {})
        cfg["allow_count_mismatch"] = _coerce_bool(
            cfg.get("allow_count_mismatch"), False, "allow_count_mismatch")
        cfg["allow_empty_extract"] = _coerce_bool(
            cfg.get("allow_empty_extract"), False, "allow_empty_extract")
        return cfg

    @abstractmethod
    def extract(self, ctx: ExtractContext) -> Iterator[Any]:
        """Yield ``pyarrow.RecordBatch`` chunks.  NEVER return a list —
        memory must stay O(one chunk) regardless of row count.  Report
        any source-authoritative count via ``ctx.add_reported_count``.
        Raise :class:`SourceRefusal` (with secrets scrubbed) on any
        condition where delivering would be wrong."""

    # ── The role's resolve: context build + harness ────────────────────

    def resolve(self, request: SourceRequest) -> str:
        import uuid
        from pathlib import Path

        feed_config = request.feed_config
        db = request.db

        # Step-served sources are single-source by declaration.
        if feed_config.get("secondary_connection_id") or \
                feed_config.get("_cross_side"):
            raise SourceRefusal(
                f"source '{self.name}' is a step-served (non-SQL) source "
                f"and cannot serve a cross-connection feed — remove "
                f"secondary_connection_id from the feed, or combine "
                f"downstream.")

        raw_cfg = (feed_config.get("query_params") or {}).get("source")
        if not isinstance(raw_cfg, dict):
            raise SourceRefusal(
                f"source '{self.name}' requires its configuration under "
                f"query_params.source (a JSON object) on the feed — "
                f"found "
                f"{type(raw_cfg).__name__ if raw_cfg is not None else 'nothing'}."
                f"  The feed row is the source definition; there is no "
                f"other place it can come from.")
        cfg = self.validate_config(raw_cfg)

        # Connection / credential resolution — the registry, never a
        # literal in the feed row.  get_connection_raw returns DECRYPTED
        # credentials (get_connection masks them); the values are
        # collected as secrets so no downstream message can carry them.
        connection = None
        if self.traits.needs_connection:
            connection_id = feed_config.get("connection_id")
            if not connection_id:
                raise SourceRefusal(
                    f"source '{self.name}' resolves credentials from the "
                    f"feed's connection (traits.needs_connection) but "
                    f"the feed has no connection_id.")
            connection = db.get_connection_raw(connection_id) if db else None
            if not connection:
                raise ValueError(
                    f"Connection {connection_id} not found for source "
                    f"'{self.name}'")
        secrets = collect_secrets(
            (connection or {}).get("config"), connection)

        # ONE parameter vocabulary — core.feed.param_resolver
        # (business_date, month_end, prev_eom, wd1..15 …),
        # calendar-aware when the feed has a calendar.
        feed_run = feed_config.get("_feed_run") \
            if isinstance(feed_config, dict) else None
        calendar = None
        try:
            from core import feed_engine as _fe
            calendar = _fe._load_calendar_for_feed(feed_config, db=db)
        except Exception as _cal_exc:
            logger.warning(
                "[feed-sources] calendar load failed (%s) — date tokens "
                "degrade to calendar-day arithmetic", _cal_exc)
        from core.feed.param_resolver import resolve_feed_params
        params = resolve_feed_params(feed_config, feed_run, calendar)

        tmp_dir = Path(request.output_path).parent / \
            f"src_{uuid.uuid4().hex[:12]}"
        tmp_dir.mkdir(parents=True, exist_ok=True)

        ctx = ExtractContext(
            feed_config=feed_config,
            source_config=cfg,
            connection=connection,
            params=params,
            feed_run=feed_run,
            run_timestamp=stored_run_timestamp(feed_run),
            tmp_dir=str(tmp_dir),
            secrets=secrets,
            transport=feed_config.get("_source_transport"),  # test seam
            cancel_event=feed_config.get("_cancel_event"),
        )
        try:
            rows = run_extract_to_parquet(self, ctx, request.output_path)
        finally:
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)
        logger.info(
            "[feed-sources] feed=%s source=%s rows=%d reported=%s -> %s",
            feed_config.get("id"), self.name, rows, ctx.reported_count,
            request.output_path)
        return request.output_path


def stored_run_timestamp(feed_run: Optional[Dict[str, Any]]) -> Optional[str]:
    """The DB-stored timestamp for the ``{TIMESTAMP}`` placeholder —
    deterministic replay means a re-run of the SAME feed_run row must
    produce the SAME value, so this reads STORED columns in stability
    order (``scheduled_time`` is SOD-stamped and never rewritten;
    ``created_at`` is stamped once at INSERT) and NEVER the wall clock.
    ``started_at`` is deliberately excluded: the engine restamps it on
    every attempt, which would make each retry a different call.
    Returns ISO-8601 seconds precision, or None when the run carries no
    stored stamp (a step that needs one must refuse then)."""
    from datetime import date, datetime
    if not feed_run:
        return None
    for key in ("scheduled_time", "created_at"):
        v = feed_run.get(key)
        if v is None:
            continue
        if isinstance(v, datetime):
            return v.strftime("%Y-%m-%dT%H:%M:%S")
        if isinstance(v, date):
            return v.strftime("%Y-%m-%dT00:00:00")
        if isinstance(v, str) and v.strip():
            try:
                return (datetime.fromisoformat(v.replace("Z", "+00:00"))
                        .strftime("%Y-%m-%dT%H:%M:%S"))
            except ValueError:
                continue
    return None


def _coerce_bool(v: Any, default: bool, key: str) -> bool:
    """Strict bool coercion — a typo must not silently become False."""
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        low = v.strip().lower()
        if low in ("true", "1", "yes", "y"):
            return True
        if low in ("false", "0", "no", "n", ""):
            return False
    raise SourceRefusal(
        f"source config key '{key}' must be a boolean, got {v!r} — "
        f"refusing to guess")


# ── Secret hygiene ──────────────────────────────────────────────────────────

#: Connection-config keys whose VALUES are secrets.  Matches the
#: ``type: password`` fields of the connector registry's rest_api entry.
SECRET_CONFIG_KEYS = (
    "password", "token", "api_key_value", "client_secret",
    "sap_password", "secret_key", "aws_secret_access_key",
    "aws_session_token",
)


def collect_secrets(*configs: Optional[Dict[str, Any]]) -> List[str]:
    """Pull the secret VALUES out of the given config dicts."""
    out: List[str] = []
    for cfg in configs:
        if not isinstance(cfg, dict):
            continue
        for k in SECRET_CONFIG_KEYS:
            v = cfg.get(k)
            if isinstance(v, str) and v:
                out.append(v)
    return out


def scrub_secrets(text: str, secrets: List[str]) -> str:
    """Replace every known secret value in ``text`` with ``***``.  Every
    error message that could carry transport detail passes through here
    BEFORE being raised or logged — a traceback with a Basic-Auth
    password in a URL is a credential leak with a stack trace."""
    if not text:
        return text
    out = str(text)
    for s in secrets or []:
        if s:
            out = out.replace(s, "***")
    return out


# ── Rate limiting (declared, conservative, injectable clock) ────────────────

class TokenBucket:
    """Aggregate requests-per-second limiter shared across every worker
    thread of one extract.  ``monotonic_fn`` / ``sleep_fn`` are
    injectable so tests OBSERVE the limiter without wall-clock waits."""

    def __init__(self, rps: float,
                 monotonic_fn: Optional[Callable[[], float]] = None,
                 sleep_fn: Optional[Callable[[float], None]] = None):
        import time as _time
        if rps <= 0:
            raise SourceRefusal(
                f"rate_limit_rps must be > 0, got {rps!r} — an unlimited "
                f"API extract is a declared decision, not a default; set "
                f"an explicit high value if the source can take it")
        self.rps = float(rps)
        self._monotonic = monotonic_fn or _time.monotonic
        self._sleep = sleep_fn or _time.sleep
        self._lock = threading.Lock()
        self._next_free = self._monotonic()
        #: Observability + test hook: total seconds this bucket made
        #: callers wait.
        self.waited_seconds = 0.0
        self.acquisitions = 0

    def acquire(self) -> None:
        interval = 1.0 / self.rps
        with self._lock:
            now = self._monotonic()
            wait = self._next_free - now
            self._next_free = max(self._next_free, now) + interval
            self.acquisitions += 1
            if wait > 0:
                self.waited_seconds += wait
        if wait > 0:
            self._sleep(wait)


# ── The one streaming harness ───────────────────────────────────────────────

def run_extract_to_parquet(source: StreamingSourceResolver,
                           ctx: ExtractContext,
                           output_path: str) -> int:
    """Stream ``source.extract(ctx)`` into ``output_path`` (parquet,
    zstd — same writer posture as the engine's DuckDB lane) and enforce
    the shared correctness gates.  Returns rows written.

    Refusals (each deletes the partial file first):
      * count mismatch when the source reported a count and the config
        does not carry ``allow_count_mismatch=true``;
      * zero rows without ``allow_empty_extract=true``.

    Schema drift between chunks is a refusal, not a coercion: chunk 2
    silently re-inferring a different type is the ``from_pylist``
    per-chunk trap this repo already took an incident from — batches
    after the first are CAST to the first chunk's schema, and a cast
    failure names the problem.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq

    cfg = ctx.source_config or {}
    allow_mismatch = bool(cfg.get("allow_count_mismatch", False))
    allow_empty = bool(cfg.get("allow_empty_extract", False))

    rows_written = 0
    writer = None
    schema = None
    try:
        for batch in source.extract(ctx):
            if batch is None or batch.num_rows == 0:
                continue
            if writer is None:
                schema = batch.schema
                writer = pq.ParquetWriter(output_path, schema,
                                          compression="zstd")
            elif batch.schema != schema:
                try:
                    batch = pa.Table.from_batches([batch]) \
                        .cast(schema).combine_chunks().to_batches()[0]
                except Exception as _cast_exc:
                    raise SourceRefusal(scrub_secrets(
                        f"source '{source.name}' produced a chunk whose "
                        f"schema drifted from the first chunk's and "
                        f"could not be cast back ({_cast_exc}); refusing "
                        f"to write a mixed-schema file", ctx.secrets))
            writer.write_batch(batch)
            rows_written += batch.num_rows
    except BaseException:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass
            writer = None
        _remove_quietly(output_path)
        raise
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                pass

    reported = ctx.reported_count
    if reported is not None and reported != rows_written:
        if allow_mismatch:
            logger.error(
                "[feed-sources] source=%s COUNT MISMATCH ACCEPTED by "
                "explicit allow_count_mismatch=true: reported=%d "
                "received=%d — the delivered file is short/long by %d "
                "row(s)", source.name, reported, rows_written,
                abs(reported - rows_written))
        else:
            _remove_quietly(output_path)
            raise SourceRefusal(
                f"source '{source.name}' reported {reported} row(s) but "
                f"{rows_written} were received — REFUSING the extract "
                f"(allow_count_mismatch is false).  A short file with a "
                f"success status is the exact failure this platform "
                f"exists to prevent; re-run, and if the mismatch is "
                f"expected, set query_params.source.allow_count_mismatch"
                f"=true on the feed to accept it deliberately.")

    if rows_written == 0:
        if not allow_empty:
            _remove_quietly(output_path)
            raise SourceRefusal(
                f"source '{source.name}' produced ZERO rows and the feed "
                f"does not declare that as acceptable — refusing to "
                f"deliver an empty file (set query_params.source."
                f"allow_empty_extract=true if empty is a valid business "
                f"outcome for this feed).")
        # Deliberate empty: typed header-only parquet when a schema was
        # seen (zero batches means it wasn't), else minimal empty table.
        pq.write_table(
            schema.empty_table() if schema is not None else pa.table({}),
            output_path)
        logger.info(
            "[feed-sources] source=%s empty extract ACCEPTED "
            "(allow_empty_extract=true) — header-only file written",
            source.name)

    return rows_written


def _remove_quietly(path: str) -> None:
    import os
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except OSError as exc:
        logger.warning("[feed-sources] could not remove partial output "
                       "%s: %s", path, exc)
