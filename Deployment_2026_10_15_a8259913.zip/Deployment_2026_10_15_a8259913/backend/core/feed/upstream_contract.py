"""THE UPSTREAM CONTRACT -- the message is a contract, resolved ONCE
(2026-10-12, the owner: "no patching ... only strategic solution").

A feed task reads one or more ENVIRONMENTS (core/feed/environments.py:
configuration -- today CLOUD and ON-PREM).  Each environment is governed by
an upstream message (a Kafka topic or the QS_KAFKA_MESSAGE table, both
landing on the arrival ledger).  That message says WHAT the upstream loaded:
its identity, its version / snapshot, every field, and how many rows.  It is
the contract the run must honour, so it is resolved ONCE per execution --
here -- stored on the execution (``stage_timings.upstream_contract``) and
every consumer READS it instead of re-reading the ledger its own way:

  query        ``{version}`` / ``{snapshot}`` / any configured message field
               as a token in THAT environment's SQL (``token_values``) -- the
               run reads exactly the data the message announced
  certify      rows read == the contract's ``expected_rows`` per environment
               (``as_reported_side_rows`` feeds the existing judge, mirrored
               into the Spark job, unchanged)
  empty file   valid only when every governed environment's contract expects
               0 (``all_expect_zero``); the variance check still applies
  side re-run  kept rows are reusable only while that environment's contract
               is unchanged (``identity``)
  supersede    a NEWER contract for a delivered run = "superseded by version
               N" (``superseding``) -- re-run offered, never re-delivered by
               itself
  board        tiles and lanes render the contract

The contract of an environment:
  {"side", "environment", "dependency", "inferred",
   "status": "arrived" | "missing" | "unreadable",
   "message": {"identity", "arrived_at", "source", "fields"},
   "expected_rows", "version", "snapshot"}
``version`` / ``snapshot`` are the configured message tokens' values (see
``feed_generation.message_tokens``).  Which dependency governs which
environment is THE certification rule (declared ``certifies_side``, else the
configured environment of its name) -- one decision, made here.
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Dict, List, Mapping, Optional

logger = logging.getLogger(__name__)

RECORD_KEY = "upstream_contract"
SIDES = ("primary", "secondary")


# ── configuration ───────────────────────────────────────────────────────

_tok_cache: Dict[str, Any] = {"at": 0.0, "map": None}
TOKEN_CACHE_SECONDS = 30


def invalidate_tokens() -> None:
    _tok_cache["at"], _tok_cache["map"] = 0.0, None


def message_tokens(db=None) -> Dict[str, str]:
    """token name -> message field: the table ``feed_message_tokens`` (DATA,
    seeded once with version / snapshot, edited at /api/admin/feed-message-
    tokens).  Token names match case-insensitively: ``{version}`` and
    ``{VERSION}``.  Cached ``TOKEN_CACHE_SECONDS``; writes invalidate."""
    import time as _t
    now = _t.monotonic()
    if db is None and _tok_cache["map"] is not None and now - _tok_cache["at"] < TOKEN_CACHE_SECONDS:
        return _tok_cache["map"]
    if db is None:
        from core.database import get_db_manager
        db = get_db_manager()
    try:
        rows = list(db.list_feed_message_tokens() or []) if db is not None else []
    except Exception:                                   # noqa: BLE001 -- unreadable = no tokens
        rows = []
    out = {str(r["token"]).strip().lower(): str(r["message_field"]).strip() for r in rows
           if str(r.get("token") or "").strip() and str(r.get("message_field") or "").strip()}
    _tok_cache["at"], _tok_cache["map"] = now, out
    return out


# ── resolution ──────────────────────────────────────────────────────────

def _governing_dependencies(db, feed_config: Mapping[str, Any]) -> Dict[str, Dict[str, Any]]:
    """side -> {dependency, inferred}: the certification's rule (declared
    ``certifies_side``; when the feed declares none, the configured
    environment of the dependency's name; a single-source feed's one
    dependency)."""
    from core.feed.etl_dependency import effective_etl_id, infer_certified_side
    lister = getattr(db, "list_etl_dependency_mappings", None)
    if lister is None:
        return {}
    rows = [r for r in list(lister(effective_etl_id(feed_config)) or []) if r.get("is_active", True)]
    declared_any = any(str(r.get("certifies_side") or "").strip() for r in rows)
    # has the feed a second side?  THE answer (explicit, or inherited from its
    # saved query / shared SQL file) -- asked once
    from core.feed.source_plan import detect_cross_source
    combined = detect_cross_source(db, dict(feed_config or {})) if not declared_any else None
    out: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        side = str(r.get("certifies_side") or "").strip().lower()
        inferred = False
        if not side and not declared_any:
            side = infer_certified_side(feed_config, r, len(rows), combined) or ""
            inferred = bool(side)
        if side not in SIDES:
            continue
        if side in out:
            logger.error("[upstream_contract] feed %s: %r and %r both govern the %s side; "
                         "the first is the contract", feed_config.get("id"),
                         out[side]["dependency"], r.get("dependency_key"), side)
            continue
        out[side] = {"dependency": str(r.get("dependency_key") or ""), "inferred": inferred}
    return out


def _fields(event: Mapping[str, Any]) -> Dict[str, Any]:
    payload = event.get("payload") or {}
    f = payload.get("fields") if isinstance(payload, Mapping) and isinstance(payload.get("fields"), Mapping) else payload
    return dict(f) if isinstance(f, Mapping) else {}


def _governing_arrival(events: List[Mapping[str, Any]]) -> Optional[Mapping[str, Any]]:
    """The arrival the contract is: the LATEST that carried a count (the
    ledger's own rule for the reported rows), else the latest."""
    for e in reversed(events):
        if e.get("reported_rows") is not None:
            return e
    return events[-1] if events else None


def resolve(db, feed_config: Mapping[str, Any], business_date: Optional[date]) -> Dict[str, Any]:
    """{side: contract} for every governed environment, or
    ``{"_unreadable": why}`` when the mappings or the ledger cannot be read
    (the consumers then refuse -- an unknown contract is not an empty one)."""
    from core.feed.environments import label
    from core.feed.ledger import arrivals_for
    try:
        gov = _governing_dependencies(db, feed_config)
    except Exception as exc:                            # noqa: BLE001
        return {"_unreadable": f"dependency mappings could not be read ({exc})"}
    tokens = message_tokens()
    out: Dict[str, Any] = {}
    for side, g in gov.items():
        c: Dict[str, Any] = {"side": side, "environment": label(side), "dependency": g["dependency"],
                             "inferred": g["inferred"], "status": "missing", "message": None,
                             "expected_rows": None, "tokens": {}}
        if business_date is not None:
            try:
                events = arrivals_for(db, g["dependency"], business_date)
            except Exception as exc:                    # noqa: BLE001
                return {"_unreadable": f"the arrival ledger could not be read for "
                                       f"{g['dependency']!r} ({exc})"}
            ev = _governing_arrival(events)
            if ev is not None:
                fields = _fields(ev)
                arrived = ev.get("arrived_at")
                c["status"] = "arrived"
                c["message"] = {"identity": ev.get("message_identity"),
                                "arrived_at": arrived.isoformat() if hasattr(arrived, "isoformat") else arrived,
                                "source": ev.get("source"), "fields": fields}
                try:
                    c["expected_rows"] = None if ev.get("reported_rows") is None else int(ev["reported_rows"])
                except (TypeError, ValueError):
                    c["expected_rows"] = None
                upper = {str(k).upper(): v for k, v in fields.items()}
                c["tokens"] = {t: upper.get(f.upper()) for t, f in tokens.items()
                               if upper.get(f.upper()) is not None}
        out[side] = c
    return out


# ── readers ─────────────────────────────────────────────────────────────

def as_reported_side_rows(contracts: Mapping[str, Any]) -> Dict[str, Any]:
    """The shape the reported-rows judge reads (core/feed/reported_rows_
    certification.py, mirrored into the Spark job) -- derived, so the count
    certified and the contract the query read are the same arrival."""
    from core.feed.reported_rows_certification import (
        STATUS_NO_ARRIVAL, STATUS_NO_COUNT, STATUS_REPORTED,
    )
    if "_unreadable" in contracts:
        return {"_unreadable": contracts["_unreadable"]}
    out = {}
    for side, c in contracts.items():
        if side not in SIDES:
            continue
        status = (STATUS_NO_ARRIVAL if c["status"] != "arrived"
                  else STATUS_REPORTED if c.get("expected_rows") is not None else STATUS_NO_COUNT)
        e = {"dependency": c["dependency"], "status": status, "reported_rows": c.get("expected_rows")}
        if c.get("inferred"):
            e["inferred"] = True
        out[side] = e
    return out


def token_values(contracts: Optional[Mapping[str, Any]], side: str) -> Dict[str, Any]:
    """The message tokens of one environment's contract, under both
    spellings (``version`` and ``VERSION``).  ``side`` '' = the feed's own
    (primary) side."""
    c = (contracts or {}).get(side or "primary") or {}
    out: Dict[str, Any] = {}
    for k, v in (c.get("tokens") or {}).items():
        out[k] = v
        out[k.upper()] = v
    return out


def token_names() -> List[str]:
    """Every configured token name, both spellings -- DECLARED, so a query
    that uses one and has no contract value REFUSES (never runs literal text)."""
    names = []
    for k in message_tokens():
        names += [k, k.upper()]
    return names


def all_expect_zero(contracts: Optional[Mapping[str, Any]]) -> bool:
    """Every governed environment's message says 0 rows."""
    cs = [c for s, c in (contracts or {}).items() if s in SIDES]
    return bool(cs) and all(c.get("status") == "arrived" and c.get("expected_rows") == 0 for c in cs)


def identity(contract: Optional[Mapping[str, Any]]) -> Optional[str]:
    """What makes a contract THIS contract: the dependency, the governing
    message, its version tokens and expected rows.  A new or replayed
    message changes it."""
    if not contract or contract.get("status") != "arrived":
        return None
    m = contract.get("message") or {}
    return "|".join(str(x) for x in (contract.get("dependency"), m.get("identity"), m.get("arrived_at"),
                                     sorted((contract.get("tokens") or {}).items()),
                                     contract.get("expected_rows")))


def public(contracts: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    """The record stored on the execution (and read by the board)."""
    if not contracts:
        return {}
    if "_unreadable" in contracts:
        return {"_unreadable": contracts["_unreadable"]}
    return {s: {**c, "identity": identity(c)} for s, c in contracts.items() if s in SIDES}


def superseding(db, stored: Optional[Mapping[str, Any]], business_date: Optional[date]) -> List[Dict[str, Any]]:
    """For a DELIVERED execution's stored contract: every environment whose
    contract has since been replaced by a newer message (a restatement).
    Each: {side, environment, dependency, was, now} (versions and
    identities).  Unreadable = nothing claimed (never a false alarm)."""
    from core.feed.ledger import arrivals_for
    out: List[Dict[str, Any]] = []
    tokens = message_tokens()
    for side, c in (stored or {}).items():
        if side not in SIDES or not isinstance(c, Mapping) or c.get("status") != "arrived":
            continue
        try:
            ev = _governing_arrival(arrivals_for(db, c["dependency"], business_date))
        except Exception:                               # noqa: BLE001
            continue
        if ev is None or ev.get("message_identity") == (c.get("message") or {}).get("identity"):
            continue
        fields = {str(k).upper(): v for k, v in _fields(ev).items()}
        now_tokens = {t: fields.get(f.upper()) for t, f in tokens.items() if fields.get(f.upper()) is not None}
        out.append({"side": side, "environment": c.get("environment"), "dependency": c.get("dependency"),
                    "was": {"identity": (c.get("message") or {}).get("identity"), **(c.get("tokens") or {})},
                    "now": {"identity": ev.get("message_identity"), **now_tokens,
                            "expected_rows": ev.get("reported_rows")}})
    return out


def contract_for(feed_config: Optional[Mapping[str, Any]], params: Optional[Mapping[str, Any]],
                 db=None) -> Optional[Dict[str, Any]]:
    """The contract a render should use: the one the execution RESOLVED
    (``feed_config['_upstream_contract']``), else -- for a render outside an
    execution (the Airflow DAG's later submit, a SQL preview) -- resolved now
    for the params' business date.  None when nothing can be resolved."""
    fc = feed_config or {}
    stored = fc.get("_upstream_contract")
    if isinstance(stored, Mapping):
        return dict(stored)
    raw = (params or {}).get("business_date") or ((fc.get("_feed_run") or {}).get("business_date"))
    if not raw:
        return None
    try:
        bd = raw if isinstance(raw, date) else date.fromisoformat(str(raw)[:10])
    except ValueError:
        return None
    if db is None:
        from core.database import get_db_manager
        db = get_db_manager()
    if db is None or getattr(db, "list_etl_dependency_mappings", None) is None:
        return None
    try:
        return resolve(db, fc, bd)
    except Exception:                                   # noqa: BLE001 -- a declared token then refuses
        return None
