"""Same-engine UNION pushdown — one statement, zero client-side combine.

2026-08-22, design_starburst_140m §4.3 decision-ladder step 1.  When the
primary and secondary sides of a UNION cross-source feed live on the
SAME Trino/Starburst cluster (any catalogs), federating them is the
engine's day job::

    SELECT …side A cols…
    FROM ( <side A SQL, row-secured for the PRIMARY connection> ) qs_union_a
    UNION ALL
    SELECT …aligned side B cols…
    FROM ( <side B SQL, row-secured for the SECONDARY connection> ) qs_union_b

One query, no second materialisation, no combine copy — the feed then
runs as a SINGLE-source query and rides whatever write rung the
connection supports (rung 1: the cluster writes the union straight to
S3).

Alignment is BY NAME with typed NULLs, in SQL — the ``__empty__``
semantics of ``cross_source_combine.build_union_combine_sql``, done
where the data lives: output columns are side A's columns in order,
then side B's extras; a side missing a column contributes
``CAST(NULL AS <the other side's type>) AS "col"``.

RLS: EACH side is secured with ITS OWN connection id BEFORE embedding —
the combined statement executes on the primary connection, and without
per-side securing the secondary's policies (scoped to the secondary
connection) would never fire.  That is the 2026-08-19 P0 shape
(filtered on one route, unfiltered on another), and the tests assert
the secured text of BOTH sides appears verbatim in the generated
statement.  The feed engine's own ``secure_feed_sql`` on the combined
statement still runs afterwards (primary-scoped, narrowing-only) — the
pushdown never suppresses it.

Refusals are DECLARED, never silent: ``plan()`` returns a
``PushdownRefusal`` naming the reason, the caller logs it and runs the
existing two-side path.  UNKNOWN = UNSAFE throughout: any doubt about
hosts, users, dialects, table qualification or probe results refuses.

2026-09-05 — a refusal now also carries a ``kind``:

``not_applicable``
    This feed was never a candidate (join mode, single-source, a
    different cluster, a structured side, the knob off).  Routine.
``unsafe``
    It WAS a candidate and could not be done safely — a policy said no,
    the engine could not be asked, a table could not be qualified.  The
    optimisation did not happen and the operator's question is "why".
``bug``
    Our own code raised a programming error.  Same outcome (refuse — the
    two-side path is the always-correct floor and an optimiser must never
    fail a feed), opposite diagnosis: a ``TypeError`` out of the
    row-security call means row security was never ASKED, and calling
    that "row security failed" is a defect wearing the costume of a safe
    decision.  Logged at ERROR with the traceback.

Every refusal is logged HERE, at a level matching its kind.  Before that,
this module logged one line and only on success, so "refused, and why"
was indistinguishable from "never attempted" — the system logging what it
did and never what it declined to do.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
from core.best_effort import note_best_effort

logger = logging.getLogger(__name__)

#: connection types that are the same engine family for pushdown purposes.
_PUSHDOWN_ENGINE_TYPES = frozenset({"trino", "starburst"})

#: engine type strings must look like SQL types before they are pasted
#: into CAST(NULL AS <type>).  They come from the engine's own cursor
#: description, but a guard costs nothing and an injection here would
#: run on the customer's cluster.
#:
#: 2026-09-05 -- WIDENED, deliberately.  The first spelling
#: (``(\s*\([0-9,\s]*\))?``) admitted a parenthesised parameter only when
#: every character of it was a DIGIT, so it accepted ``decimal(18,2)``
#: and refused every other parameterised Trino type: ``array(varchar)``,
#: ``map(varchar, bigint)``, ``row(k bigint, amt double)``,
#: ``interval day to second``.  Those are ordinary column types on a
#: Starburst feed, and ONE of them anywhere in EITHER side -- including
#: on a column present on both sides, which is never rendered as a type
#: at all -- refused the whole pushdown as "probe/build failed".  That is
#: a refusal with no safety value: silent, safe-looking, and the
#: optimisation simply never happened.
#:
#: Still a guard, and still the same one: a type is a bare identifier,
#: optionally followed by ONE parenthesised parameter list and/or
#: trailing bare words.  The characters admitted inside the parentheses
#: are identifiers, digits, commas, spaces/tabs and nested parentheses --
#: no quote, no semicolon, no operator, no comment marker -- so the
#: 2026-08-22 payload ``bigint); DROP TABLE x;--`` is refused exactly as
#: before (``test_suspicious_type_string_is_refused``).
#:
#: 2026-09-05 (round 2) -- NARROWED, so the pattern accepts only what the
#: paragraph above says it accepts.  Two places had drifted:
#:
#: * ``\s`` MATCHES A NEWLINE.  A base type name, a newline, and
#:   ``DROP TABLE users`` therefore satisfied the "trailing bare words"
#:   clause and was ACCEPTED.  Not exploitable -- an 18-payload battery
#:   confirmed every escape-shaped string is still refused, and what got
#:   through stays inside the balanced ``CAST(NULL AS ...)`` parens and
#:   becomes an engine syntax error -- but a guard whose comment is
#:   NARROWER than its pattern is worse than no comment, because the next
#:   reader trusts the comment instead of the code.  A SQL type name is
#:   one line: the separators are now ``[ \t]`` and nothing else.
#: * ``$`` also matches just before a trailing newline; ``\A``/``\Z``
#:   anchor the WHOLE string.  (The one call site ``.strip()``s first, so
#:   this refuses nothing that used to be accepted.)
#:
#: Narrowing only -- every widening case stays accepted (``array(varchar)``,
#: ``map(varchar, bigint)``, ``row(k bigint, v varchar)``,
#: ``interval day to second``, ``decimal(38,9)``,
#: ``timestamp(6) with time zone``); see
#: tests/test_union_pushdown_2026_08_22.py.
#:
#: And the trailing clause is now DESCRIBED honestly.  It is any run of
#: bare words, not literally ``WITH TIME ZONE``, and that breadth is
#: deliberate: ``interval day to second`` and ``double precision`` are the
#: same shape, and a closed vocabulary here would refuse the next engine's
#: spelling -- which is precisely the silent "pushdown disabled for every
#: feed carrying such a column" failure this pattern was widened to fix.
_TYPE_RE = re.compile(
    r"\A[A-Za-z_][A-Za-z0-9_]*"                # base type name
    r"([ \t]*\([A-Za-z0-9_,() \t]*\))?"        # optional parameter list
    r"([ \t]+[A-Za-z][A-Za-z0-9_]*)*\Z",       # trailing bare words, e.g.
    re.IGNORECASE)                             # WITH TIME ZONE, DAY TO SECOND


def _looks_like_sql_type(raw: Any) -> bool:
    """True when ``raw`` may be pasted into ``CAST(NULL AS <raw>)``.

    TWO conditions, and the second one is the one that actually contains
    the string:

    1. :data:`_TYPE_RE` -- the ALPHABET and the shape.  No quote, no
       semicolon, no operator, no comment marker, one line.
    2. BALANCED parentheses that never dip below zero.

    2026-09-05 (round 2) -- (2) is new, and it closes a hole that the
    SAME-DAY widening of ``_TYPE_RE`` opened.  Admitting ``(`` and ``)``
    inside the parameter list is required (``array(row(a bigint, b
    varchar))`` is an ordinary Trino type), but the character class alone
    says nothing about NESTING, and the regex's ONE parenthesised group
    ends at the LAST ``)`` it can find.  So this was ACCEPTED::

        varchar(1)) x , ((SELECT pw FROM users)

    and rendered into::

        CAST(NULL AS varchar(1)) x , ((SELECT pw FROM users)) AS "col"

    which is not a syntax error -- it is VALID SQL: a completed cast, an
    implicit alias ``x``, and a second select item that is a scalar
    SUBQUERY against another table.  The leading ``))`` escaped the
    ``CAST(`` the guard's whole purpose was to keep the value inside.  The
    pre-widening pattern refused it only incidentally (it allowed nothing
    but digits between the parens); the widening removed that accident
    without replacing the property, and the 18-payload battery that
    cleared the widening did not contain this shape.

    Balance IS the containment property, and it is stated once, here:
    while the depth can never go negative, no prefix of the value can
    close ``CAST(``; and since the alphabet carries no operator, quote or
    statement separator, everything the value contributes stays inside the
    cast.  A balanced-but-nonsensical type (``bigint(1)(2)``) is still
    accepted and still becomes an engine syntax error -- that is a
    LOUD failure on the customer's cluster, which is what a guard may
    permit; silent execution of an injected subquery is what it may not.
    """
    text = str(raw or "").strip()
    if not _TYPE_RE.match(text):
        return False
    depth = 0
    for ch in text:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0

#: Refusal classes.  The distinction IS the deliverable: the first two
#: mean "this feed is not a pushdown candidate" / "it cannot be pushed
#: down safely", and the third means "our own code is broken".  Reporting
#: the third as one of the first two is how a defect hides behind a
#: decision that looks safe.
KIND_NOT_APPLICABLE = "not_applicable"
KIND_UNSAFE = "unsafe"
KIND_BUG = "bug"

#: Exception types that mean the CODE is wrong, not that the FEED cannot
#: be unioned.  A ``TypeError`` out of the per-side row-security call is a
#: signature/wiring defect -- row security was never ASKED -- so "per-side
#: row security failed" is a false statement about a security decision,
#: and indistinguishable in the log and on the execution record from a
#: policy that legitimately refused.  We still return a refusal (the
#: two-side path is the always-correct floor; an optimiser must never
#: fail a feed) but it is labelled BUG and logged at ERROR with the
#: traceback, so it can never again be read as a safe decision.
_BUG_EXCEPTIONS = (TypeError, AttributeError, ImportError, NameError,
                   SyntaxError)


@dataclass(frozen=True)
class PushdownRefusal:
    reason: str
    #: one of KIND_NOT_APPLICABLE / KIND_UNSAFE / KIND_BUG.  Defaults to
    #: KIND_UNSAFE so a refusal constructed without thinking about it is
    #: never silently filed as "expected".
    kind: str = KIND_UNSAFE

    def to_dict(self) -> dict:
        return {"applied": False, "reason": self.reason, "kind": self.kind}


def _is_bug(exc: BaseException) -> bool:
    """True when ``exc`` -- or the exception it was raised FROM -- is a
    programming error rather than a decision about this feed.

    The cause chain matters: ``core.feed.rls.secure_feed_sql`` wraps every
    enforcement error in a ``ValueError`` (its documented fail-closed
    posture), so a ``TypeError`` raised inside ``core.row_security``
    arrives here dressed as a policy failure.  Walking ``__cause__`` /
    ``__context__`` (bounded) undresses it.  The OUTCOME is unchanged --
    we refuse either way -- only the label and the log level change, and
    those are what make the defect findable.
    """
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 5:
        if isinstance(cur, _BUG_EXCEPTIONS):
            return True
        cur = cur.__cause__ or cur.__context__
        seen += 1
    return False


def _refuse(feed_config, reason: str, kind: str = KIND_UNSAFE,
            exc: Optional[BaseException] = None) -> PushdownRefusal:
    """Build the refusal AND SAY SO, at a level that matches what it means.

    2026-09-05 -- before this, the module logged exactly one line and only
    on success ("APPLIED").  Every refusal was silent HERE; the caller
    logged a single INFO line, so on a real run "the pushdown was refused,
    and why" looked exactly like "the pushdown was never attempted".  That
    is the repo rule from the 2026-08-21 island incident, verbatim: the
    system logs what it DID, never what it DECLINED to do.  Every exit
    from :func:`plan_same_engine_union` now goes through here.

    Levels are chosen so the log answers the operator's question:
    ``not_applicable`` is routine bookkeeping (INFO), ``unsafe`` is "this
    feed COULD have been one statement and was not" (WARNING), and ``bug``
    is a defect in this code path (ERROR, with the traceback).
    """
    feed_id = (feed_config or {}).get("id")
    if kind == KIND_BUG:
        logger.error("[union-pushdown] feed=%s REFUSED (bug) %s",
                     feed_id, reason, exc_info=exc)
    elif kind == KIND_UNSAFE:
        logger.warning("[union-pushdown] feed=%s REFUSED (unsafe) %s",
                       feed_id, reason)
    else:
        logger.info("[union-pushdown] feed=%s not a candidate: %s",
                    feed_id, reason)
    return PushdownRefusal(reason, kind=kind)


@dataclass(frozen=True)
class SameEngineUnionPlan:
    sql: str
    connection_id: Any
    reason: str
    columns: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"applied": True, "reason": self.reason,
                "columns": list(self.columns)}


def _conn_engine_identity(conn: dict) -> Optional[Tuple]:
    """The tuple that must MATCH for two connections to be 'the same
    cluster, same principal'.  None = not a pushdown-capable engine."""
    ctype = str(conn.get("connection_type") or "").lower()
    if ctype not in _PUSHDOWN_ENGINE_TYPES:
        return None
    cfg = conn.get("config") or {}
    return (
        str(cfg.get("host") or "").strip().lower(),
        int(cfg.get("port") or 443),
        str(cfg.get("http_scheme") or "https").strip().lower(),
        str(cfg.get("user") or "").strip(),
        str(cfg.get("auth_type") or "none").strip().lower(),
    )


def _qi(name: str) -> str:
    from core.connectors.trino_connector import _qi as _trino_qi
    return _trino_qi(name)


def qualify_side_tables(sql: str, *, catalog: str, schema: str) -> str:
    """Fully qualify unqualified table references with the SIDE's own
    default catalog/schema, so the statement means the same thing when
    executed on the OTHER side's connection.

    Uses sqlglot's qualify_tables (CTE-aware: CTE names are never
    qualified).  Raises on parse failure or when a table cannot be
    qualified — the caller converts that into a declared refusal.
    """
    import sqlglot
    from sqlglot.optimizer.qualify_tables import qualify_tables

    ast = sqlglot.parse_one(sql, read="trino")
    if ast is None:
        raise ValueError("sqlglot returned no AST")
    qualified = qualify_tables(
        ast,
        catalog=catalog or None,
        db=schema or None,
    )
    # Verify the promise: every real table now carries a catalog.  A
    # table sqlglot could not qualify (no default catalog) would execute
    # against the WRONG catalog on the primary connection — refuse.
    from sqlglot import exp
    cte_names = {c.alias_or_name.lower() for c in qualified.find_all(exp.CTE)}
    for t in qualified.find_all(exp.Table):
        if t.name.lower() in cte_names and not t.args.get("catalog"):
            continue
        if not t.args.get("catalog") or not t.args.get("db"):
            raise ValueError(
                f"table {t.sql(dialect='trino')!r} could not be fully "
                f"qualified (side connection has no default "
                f"catalog/schema)")
    return qualified.sql(dialect="trino")


def build_union_statement(
    a_sql: str, a_cols: List[Tuple[str, str]],
    b_sql: str, b_cols: List[Tuple[str, str]],
) -> Tuple[str, List[str]]:
    """The exact UNION ALL text.  ``*_cols`` are (name, engine_type)
    from a LIMIT-0 probe of each secured side."""
    a_by_lower = {n.lower(): (n, t) for n, t in a_cols}
    b_by_lower = {n.lower(): (n, t) for n, t in b_cols}
    ordered: List[Tuple[str, str]] = []   # (canonical name, lower key)
    for n, _t in a_cols:
        ordered.append((n, n.lower()))
    for n, _t in b_cols:
        if n.lower() not in a_by_lower:
            ordered.append((n, n.lower()))

    mismatched = [
        key for key in a_by_lower
        if key in b_by_lower
        and a_by_lower[key][1].strip().lower()
        != b_by_lower[key][1].strip().lower()
    ]
    if mismatched:
        logger.warning(
            "[union-pushdown] type mismatch on shared column(s) %s — the "
            "engine will coerce or refuse loudly (same behaviour as the "
            "DuckDB combine's type-mismatch warning)", sorted(mismatched))

    for side in (a_by_lower, b_by_lower):
        for _n, t in side.values():
            if not _looks_like_sql_type(t):
                raise ValueError(
                    f"engine reported a column type {t!r} that does not "
                    f"look like a SQL type — refusing to paste it into "
                    f"CAST(NULL AS …)")

    def _select_list(side: Dict[str, Tuple[str, str]],
                     other: Dict[str, Tuple[str, str]]) -> str:
        items = []
        for canonical, key in ordered:
            if key in side:
                items.append(_qi(side[key][0]))
            else:
                null_type = other[key][1].strip()
                items.append(f"CAST(NULL AS {null_type}) AS {_qi(canonical)}")
        return ",\n       ".join(items)

    stmt = (
        f"SELECT {_select_list(a_by_lower, b_by_lower)}\n"
        f"FROM (\n{a_sql}\n) AS qs_union_a\n"
        f"UNION ALL\n"
        f"SELECT {_select_list(b_by_lower, a_by_lower)}\n"
        f"FROM (\n{b_sql}\n) AS qs_union_b"
    )
    return stmt, [c for c, _k in ordered]


def probe_columns(connector, sql: str) -> List[Tuple[str, str]]:
    """(name, engine_type) per column via a zero-row engine round trip.

    ``WHERE 1 = 0`` rather than ``LIMIT 0`` so an inner LIMIT keeps its
    meaning untouched; either way no data pages are read."""
    probe_sql = f"SELECT * FROM (\n{sql}\n) AS qs_union_probe WHERE 1 = 0"
    res = connector.execute_query(probe_sql)
    cols = res.get("columns") or []
    if not cols:
        raise ValueError("LIMIT-0 probe returned no column metadata")
    return [(str(c.get("name") or ""), str(c.get("type") or "")) for c in cols]


def plan_same_engine_union(
    db,
    feed_config: dict,
    *,
    secure_sql_fn: Callable[[str, Any, str], str],
    connector_factory: Optional[Callable[[str, dict], Any]] = None,
    substitute_fn: Optional[Callable[[str, str], str]] = None,
    cfg=None,
):
    """Return a :class:`SameEngineUnionPlan` or a :class:`PushdownRefusal`.

    ``secure_sql_fn(sql, connection_id, connection_type)`` MUST apply
    row security for that side's connection — the caller provides the
    feed's own ``secure_feed_sql`` closure so this module cannot drift
    from the product's RLS chokepoint.

    ``substitute_fn(sql, side)`` applies the feed's calendar/param
    substitution to a side's SQL BEFORE securing (tokens like
    ``{{business_date}}`` break the RLS parser, so substitution must come
    first — the same order the native branch uses).  ``side`` is
    ``"primary"`` / ``"secondary"`` (2026-10-11): a token BINDING is
    declared per side and must be applied -- and gated -- on that side.
    """
    # TOTAL BY CONSTRUCTION (2026-09-05): every exit from here is a
    # SameEngineUnionPlan or a CLASSIFIED PushdownRefusal — this function
    # does not raise.  It used to be able to: three module-level imports
    # and the identity computation sat outside every try, so an
    # ImportError or a non-numeric port escaped into feed_engine's
    # "planner crashed" handler, which builds its own refusal with no
    # kind on it.  That is the one refusal shape the classification
    # cannot see, and it is exactly the shape a BUG produces.
    if cfg is None:
        try:
            from core.config import feed_generation as _fg
        except Exception as exc:
            return _refuse(feed_config,
                           f"BUG: the feed_generation config could not be "
                           f"read ({type(exc).__name__}: {exc})",
                           KIND_BUG, exc)
        cfg = _fg
    if not bool(getattr(cfg, "union_pushdown_enabled", True)):
        return _refuse(
            feed_config,
            "disabled(feed_generation.union_pushdown_enabled=false)",
            KIND_NOT_APPLICABLE)

    combine_mode = (feed_config.get("combine_mode") or "union").strip().lower()
    if combine_mode != "union":
        return _refuse(feed_config,
                       f"combine_mode={combine_mode} (only union pushes down)",
                       KIND_NOT_APPLICABLE)

    pri_id = feed_config.get("connection_id")
    sec_id = feed_config.get("secondary_connection_id")
    if not pri_id or not sec_id:
        return _refuse(feed_config, "not cross-source", KIND_NOT_APPLICABLE)

    try:
        pri_conn = db.get_connection_raw(pri_id)
        sec_conn = db.get_connection_raw(sec_id)
    except Exception as exc:
        return _refuse(feed_config,
                       f"connection lookup failed "
                       f"({type(exc).__name__}: {exc})",
                       KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)
    if not pri_conn or not sec_conn:
        return _refuse(feed_config, "connection row missing", KIND_UNSAFE)

    try:
        pri_ident = _conn_engine_identity(pri_conn)
        sec_ident = _conn_engine_identity(sec_conn)
    except Exception as exc:
        # ``int(cfg.get("port") or 443)`` on a port stored as "8443 " or
        # "https" is a ValueError — a CONFIG problem, not a code one.
        return _refuse(feed_config,
                       f"connection config is not readable as an engine "
                       f"identity ({type(exc).__name__}: {exc})",
                       KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)
    if pri_ident is None or sec_ident is None:
        return _refuse(
            feed_config,
            f"engine family not pushdown-capable "
            f"(primary={pri_conn.get('connection_type')}, "
            f"secondary={sec_conn.get('connection_type')})",
            KIND_NOT_APPLICABLE)
    if pri_ident != sec_ident:
        return _refuse(
            feed_config,
            "same engine family but NOT the same cluster+principal "
            f"(primary={pri_ident[0]}:{pri_ident[1]} user={pri_ident[3]!r}, "
            f"secondary={sec_ident[0]}:{sec_ident[1]} user={sec_ident[3]!r}) "
            "— running side B under side A's session would change its "
            "privileges",
            KIND_NOT_APPLICABLE)

    # ── Resolve both sides' SQL through the ONE side resolver ────────
    try:
        from core.feed.source_plan import resolve_side_query_config
    except Exception as exc:
        return _refuse(feed_config,
                       f"BUG: the side resolver could not be imported "
                       f"({type(exc).__name__}: {exc})",
                       KIND_BUG, exc)

    def _side_sql(side: str) -> Optional[str]:
        if side == "secondary":
            # THE one secondary-side builder (2026-10-11), shared with the
            # engine's two-side path and the Spark plan.
            from core.feed.source_plan import secondary_side_config
            fc = secondary_side_config(feed_config)
            fc["connection_id"] = sec_id
        else:
            fc = dict(feed_config)
            fc["_cross_side"] = side
        side_res = resolve_side_query_config(db, fc)
        qcfg = side_res.query_config or {}
        raw = qcfg.get("raw_sql") or qcfg.get("custom_sql")
        return raw if isinstance(raw, str) and raw.strip() else None

    try:
        a_sql = _side_sql("primary")
        b_sql = _side_sql("secondary")
    except Exception as exc:
        return _refuse(feed_config,
                       f"side resolution failed "
                       f"({type(exc).__name__}: {exc})",
                       KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)
    if not a_sql or not b_sql:
        return _refuse(
            feed_config,
            "a side is structured (no raw SQL) — pushdown handles raw-SQL "
            "sides only",
            KIND_NOT_APPLICABLE)

    if substitute_fn is not None:
        try:
            # 2026-10-11 -- each side is substituted AS that side, so a
            # token binding declared for one side is applied (and gated)
            # on that side's text only.
            a_sql = substitute_fn(a_sql, "primary")
            b_sql = substitute_fn(b_sql, "secondary")
        except Exception as exc:
            return _refuse(feed_config,
                           f"parameter substitution failed "
                           f"({type(exc).__name__}: {exc})",
                           KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)

    # ── Qualify the SECONDARY side for execution on the primary ─────
    sec_cfg = sec_conn.get("config") or {}
    pri_cfg = pri_conn.get("config") or {}
    same_defaults = (
        str(sec_cfg.get("catalog") or "").strip().lower()
        == str(pri_cfg.get("catalog") or "").strip().lower()
        and str(sec_cfg.get("schema") or "").strip().lower()
        == str(pri_cfg.get("schema") or "").strip().lower()
    )
    if not same_defaults:
        try:
            b_sql = qualify_side_tables(
                b_sql,
                catalog=str(sec_cfg.get("catalog") or ""),
                schema=str(sec_cfg.get("schema") or ""),
            )
        except Exception as exc:
            # sqlglot is a STUB-PRONE module in this repo's test rig and a
            # pinned-but-moving parser in production (2026-08-19: a bump
            # inverted NOT LIKE).  An ImportError/AttributeError out of it
            # is our problem, not this feed's — label it as such.
            return _refuse(
                feed_config,
                f"secondary side could not be safely re-homed onto the "
                f"primary connection ({type(exc).__name__}: {exc})",
                KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)

    # ── Row security PER SIDE, each with its own connection ──────────
    try:
        a_secured = secure_sql_fn(a_sql, pri_id,
                                  str(pri_conn.get("connection_type") or ""))
        b_secured = secure_sql_fn(b_sql, sec_id,
                                  str(sec_conn.get("connection_type") or ""))
    except Exception as exc:
        # Two different things arrive here and they are NOT the same event.
        #
        #  * A policy refusal / an enforcement error (``secure_feed_sql``
        #    raises ValueError, honouring row_security.fail_open first):
        #    row security was ASKED and the answer was no or unknown.
        #    Fail CLOSED — refuse the plan, and the two-side path applies
        #    each side's policies exactly as before.  Nothing is skipped.
        #
        #  * A TypeError / AttributeError / ImportError: row security was
        #    never asked at all, because the CALL is broken.  Reporting
        #    that as "row security failed" is a false statement about a
        #    security decision, and it is the one refusal an operator will
        #    never question.  Same outcome (refuse), opposite diagnosis.
        _kind = KIND_BUG if _is_bug(exc) else KIND_UNSAFE
        if _kind == KIND_BUG:
            _reason = (f"BUG: the per-side row-security CALL raised "
                       f"{type(exc).__name__}: {exc} — row security was "
                       f"never asked; this is a wiring defect in the "
                       f"pushdown planner, not a policy decision")
        else:
            _reason = (f"per-side row security refused "
                       f"({type(exc).__name__}: {exc})")
        return _refuse(feed_config, _reason, _kind, exc)

    # ── Schema probes on the secured sides ───────────────────────────
    if connector_factory is None:
        try:
            from core.connectors import get_connector as connector_factory  # type: ignore
        except Exception as exc:
            return _refuse(feed_config,
                           f"BUG: the connector factory could not be "
                           f"resolved ({type(exc).__name__}: {exc})",
                           KIND_BUG, exc)
    connector = None
    try:
        connector = connector_factory(
            str(pri_conn.get("connection_type") or "").lower(),
            pri_cfg,
        )
        a_cols = probe_columns(connector, a_secured)
        b_cols = probe_columns(connector, b_secured)
    except Exception as exc:
        # The probe is a real engine round trip: a timeout, a dead
        # coordinator or a permission error here is genuinely "we cannot
        # know the shape", and refusing is right.  A TypeError from the
        # factory or the connector's own signature is not.
        return _refuse(feed_config,
                       f"probe/build failed ({type(exc).__name__}: {exc})",
                       KIND_BUG if _is_bug(exc) else KIND_UNSAFE, exc)
    finally:
        if connector is not None:
            try:
                connector.close()
            except Exception as _be_exc:
                note_best_effort("connector.close()", _be_exc,
                                 logger=logger)

    # Assembly is PURE and LOCAL — no engine, no network.  Kept out of the
    # probe's try so a defect in our own SQL generation can never be
    # reported as "the cluster said no".  ``build_union_statement`` raises
    # ValueError for its ONE declared refusal (a type string it will not
    # paste into a CAST); anything else out of it is a bug in this module.
    try:
        stmt, out_cols = build_union_statement(a_secured, a_cols,
                                               b_secured, b_cols)
    except ValueError as exc:
        return _refuse(feed_config, f"probe/build failed ({exc})",
                       KIND_UNSAFE)
    except Exception as exc:
        return _refuse(feed_config,
                       f"BUG: union assembly raised "
                       f"{type(exc).__name__}: {exc}",
                       KIND_BUG, exc)

    reason = (f"same_engine_union(host={pri_ident[0]}:{pri_ident[1]}, "
              f"cols={len(out_cols)})")
    logger.info("[union-pushdown] feed=%s APPLIED %s",
                feed_config.get("id"), reason)
    return SameEngineUnionPlan(sql=stmt, connection_id=pri_id,
                               reason=reason, columns=out_cols)


__all__ = [
    "PushdownRefusal", "SameEngineUnionPlan",
    "plan_same_engine_union", "build_union_statement",
    "qualify_side_tables", "probe_columns",
    "KIND_NOT_APPLICABLE", "KIND_UNSAFE", "KIND_BUG",
]
