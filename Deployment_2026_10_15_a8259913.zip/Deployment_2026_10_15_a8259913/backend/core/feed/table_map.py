"""ONE query, each side's tables renamed by configuration (2026-10-14).

The owner: the cloud data (AWS S3) and the on-prem data (Hive) hold the SAME
tables under different catalogs / schemas; the feed keeps ONE query and the
on-prem side runs it "by changing the schema".  Declared on the feed as
``query_params.table_map``::

    {"secondary": {"icbg.fins": "hive.fins"}}                  # a schema prefix
    {"primary":   {"icbg.fins.fact_tetb": "jq_fact_tetb"},      # one table
     "secondary": {"icbg.fins": "hive.fins"}}

A key names a table (``catalog.schema.table`` / ``schema.table``) or a prefix
of one (``catalog.schema`` / ``catalog``); the matched prefix is replaced by
the value and the rest of the name kept.  Applied by THE chokepoints every
lane renders a side's SQL through (``param_resolver.apply_og_tokens``, the
Spark / Airflow plan's ``substitute_airflow_sql``), beside the token
bindings, BEFORE tokens render -- so a saved query, an SQL file and typed SQL
all get it, on the native lane and on Spark alike.

What makes it safe (a correctness gate, never a best effort):

* names are found in sqlglot's TOKEN stream, so text inside a string literal
  or a comment is never touched and the author's SQL is never reformatted;
* a dotted name is renamed only when the PARSED statement reads it as a
  table (FROM / JOIN / a subquery's FROM) -- a column ``FACT_TETB.CODE`` or
  an alias is never a table;
* a map entry for this side that matches NO table the query reads REFUSES
  (:class:`TableMapRefused`): the query was edited since it was mapped, and
  running it unmapped would read the WRONG data with a green status.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

_WORD = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")


class TableMapRefused(ValueError):
    """A table map that cannot be applied: malformed, or naming a table /
    schema the side's query does not read.  The run is refused."""


def _side(side: Any) -> str:
    return "secondary" if str(side or "").strip().lower() == "secondary" else "primary"


def _norm(name: str) -> str:
    """``"ICBG"."fins".x`` -> ``icbg.fins.x`` (quotes off, lower case)."""
    return ".".join(p.strip().strip('"').strip("`").strip("[]").lower()
                    for p in str(name).split("."))


def side_map(table_map: Any, side: Any) -> Dict[str, str]:
    """This side's ``{from: to}`` (normalised keys), or {}.  Malformed = refused."""
    if not table_map:
        return {}
    if not isinstance(table_map, dict):
        raise TableMapRefused("query_params.table_map must be an object: "
                              '{"secondary": {"icbg.fins": "hive.fins"}}')
    bad = [k for k in table_map if _side(k) != str(k).strip().lower()]
    if bad:
        raise TableMapRefused(f"query_params.table_map keys are the sides 'primary' / "
                              f"'secondary'; got {bad}")
    mine = table_map.get(_side(side)) or {}
    if not isinstance(mine, dict):
        raise TableMapRefused(f"query_params.table_map.{_side(side)} must be an object "
                              f"of {{from: to}} names")
    out: Dict[str, str] = {}
    for k, v in mine.items():
        if not isinstance(k, str) or not isinstance(v, str) or not k.strip() or not v.strip():
            raise TableMapRefused(f"query_params.table_map.{_side(side)}: every entry is "
                                  f"a name -> a name; got {k!r}: {v!r}")
        for part in (k, v):
            if not all(_WORD.match(p.strip().strip('"')) for p in part.split(".")):
                raise TableMapRefused(f"query_params.table_map.{_side(side)}: {part!r} is "
                                      f"not a dotted table / schema name")
        out[_norm(k)] = v.strip()
    return out


def _tables_read(sql: str, dialect: str) -> set:
    import sqlglot
    from sqlglot import exp
    try:
        tree = sqlglot.parse_one(sql, dialect=dialect)
    except Exception as exc:                                # noqa: BLE001
        raise TableMapRefused(f"the query could not be parsed to apply its table map "
                              f"({type(exc).__name__}: {exc})") from exc
    names = set()
    for t in tree.find_all(exp.Table):
        parts = [p for p in (t.catalog, t.db, t.name) if p]
        if parts:
            names.add(".".join(p.lower() for p in parts))
    return names


def _chains(sql: str, dialect: str) -> List[Tuple[int, int, str]]:
    """Every dotted name in the token stream: ``(start, end_inclusive, text)``."""
    from sqlglot.dialects.dialect import Dialect
    from sqlglot.tokens import TokenType
    toks = Dialect.get_or_raise(dialect).tokenize(sql)
    out, i = [], 0
    word = lambda t: (t.token_type in (TokenType.VAR, TokenType.IDENTIFIER)  # noqa: E731
                      or _WORD.match(t.text or ""))
    while i < len(toks):
        if word(toks[i]) and toks[i].token_type != TokenType.STRING:
            j = i
            while (j + 2 < len(toks) and toks[j + 1].token_type == TokenType.DOT
                   and word(toks[j + 2]) and toks[j + 2].token_type != TokenType.STRING):
                j += 2
            if j > i:
                out.append((toks[i].start, toks[j].end, sql[toks[i].start:toks[j].end + 1]))
            i = j + 1
        else:
            i += 1
    return out


def apply_table_map(sql: Optional[str], table_map: Any, *, side: str = "",
                    dialect: str = "trino", feed_id: Any = None) -> Optional[str]:
    """``sql`` with this side's tables renamed (module docstring).  Unchanged
    when nothing maps for this side; refuses a map that matches nothing."""
    mine = side_map(table_map, side)
    if not sql or not mine:
        return sql
    tables = _tables_read(sql, dialect)
    edits: List[Tuple[int, int, str]] = []
    used = {k: 0 for k in mine}
    for start, end, text in _chains(sql, dialect):
        name = _norm(text)
        if name not in tables:
            continue                               # a column, an alias -- never a table
        for key in sorted(mine, key=len, reverse=True):     # the longest key wins
            if name == key or name.startswith(key + "."):
                rest = text.split(".")[len(key.split(".")):]
                edits.append((start, end, ".".join([mine[key], *rest])))
                used[key] += 1
                break
    # a key whose TARGET the query already reads was applied before (a path
    # that renders the same SQL twice): nothing to do, not a stale map
    unused = [k for k, n in used.items() if not n
              and not any(t == _norm(mine[k]) or t.startswith(_norm(mine[k]) + ".")
                          for t in tables)]
    if unused:
        raise TableMapRefused(
            f"Feed {feed_id}: the {_side(side)} side's table map names {unused}, but its "
            f"query reads no such table (it reads {sorted(tables)}).  The query was "
            f"edited since it was mapped -- running it unmapped would read the wrong "
            f"data.  Fix query_params.table_map.{_side(side)}.")
    out = sql
    for start, end, new in sorted(edits, reverse=True):
        out = out[:start] + new + out[end + 1:]
    return out


def apply_for_feed(sql: Optional[str], feed_config: Any, *, side: Any = None,
                   dialect: str = "trino") -> Optional[str]:
    """THE call every lane makes: this feed's ``query_params.table_map`` for
    ``side`` (default: the side this execution serves, ``_cross_side``)."""
    fc = feed_config if isinstance(feed_config, dict) else {}
    qp = fc.get("query_params") if isinstance(fc.get("query_params"), dict) else {}
    tm = qp.get("table_map")
    if not tm or not sql:
        return sql
    return apply_table_map(sql, tm, side=fc.get("_cross_side") if side is None else side,
                           dialect=dialect, feed_id=fc.get("id"))


__all__ = ["TableMapRefused", "apply_table_map", "apply_for_feed", "side_map"]
