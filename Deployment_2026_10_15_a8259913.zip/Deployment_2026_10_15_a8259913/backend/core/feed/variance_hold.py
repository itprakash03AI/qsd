"""Variance HOLD -- a file whose row count moved beyond its threshold is
kept, not delivered, until the release group decides (2026-10-12).

The owner (R2, ``docs/OWNER_REQUESTS_2026_10_12.html``): "if the count
increased or reduced between today and yesterday beyond the threshold we
should not send files downstream via SFTP -- it will be held for the RTB
support team to verify, and only then sent".

What already existed: the threshold (``row_count_threshold_pct`` /
``_up`` / ``_down``, ``row_count_min_rows``) checked at stage
``row_count_check`` BEFORE delivery, with the actions ``warn`` (deliver)
and ``fail`` (fail the run).  This module is the third action and the one
comparison the owner asked for:

* ``row_count_action = 'hold'`` -- the check records the breach exactly as
  ``warn`` does (``row_count_check.evaluate``); the ENGINE then runs no
  delivery hop, completes the execution with the chain verdict ``held``
  and records a ``feed_variance_holds`` row (the numbers, the kept file,
  what the chain would have been handed).  A hold whose row cannot be
  written FAILS the run: a held file nobody can see is a lost file.
* ``row_count_compare_to = 'previous'`` -- today's count against the rows
  the previous business date's run DELIVERED (``previous_baseline``), not
  the rolling average.
* WHO may release or reject (2026-10-12, the owner: "admin or feed owner
  ... need generic mapping also ... can't just hardcode"): an ADMIN; the
  feed's OWNER (its creator, or a read-write member of its owner group --
  ``permissions.can_edit_feed``, the rule that edits the feed); or a member
  of a user group MAPPED as an approver (``feed_hold_approvers``: global,
  one feed group -- e.g. a system entity's --, one template, one feed;
  managed from the Variance holds popup).  The deployment may also name a
  global group in ``feed_generation.variance_hold_release_group`` (empty by
  default -- data, not code).  Never "everybody": a hold no rule covers is
  decided by an admin, and the answer says who may.
* RELEASE sends the SAME file (``artifact_path``) through the feed's
  CURRENT delivery chain, claimed compare-and-swap so two clicks send
  once; the execution's ``stage_timings.delivery_chain`` then carries the
  real verdict and ``destination_path`` -- the one write every reader
  (receipts, the on-completion trigger, the Today board) already reads.
  REJECT records the decision; nothing is ever sent for that file.
* Nothing else sends a held file: the run wrote no delivery attempt (so
  there is no hop to retry), a rerun produces a NEW file that is checked
  again, and an open hold of the same (feed, business date) is SUPERSEDED
  by the newer execution's.

Which lanes: the check and the hold happen in the engine's shared
pipeline; a lane whose job delivers its own file (spark_k8s, and airflow
through it) cannot hold, so the router floors a ``hold`` feed to native
(``source_plan.BACKEND_CAPABILITIES[...]['variance_hold']``).
"""
from __future__ import annotations

import logging
import os
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

#: the delivery-chain verdicts this module writes (``stage_timings.
#: delivery_chain.verdict``).  Neither is ``delivered``: every reader that
#: means "it went" keeps reading "it did not".
CHAIN_HELD = "held"
CHAIN_REJECTED = "rejected"

HOLD_ACTION = "hold"
OPEN_STATUSES = ("held", "release_failed")
DECISION_REASON_MIN_CHARS = 10

DEFAULT_RELEASE_GROUP = ""


class HoldRefused(Exception):
    """A release / reject that must not happen; ``status`` is the HTTP code
    the route answers with, the message says why and what to do."""

    def __init__(self, message: str, status: int = 409):
        super().__init__(message)
        self.status = status


# ── the decision at run time ─────────────────────────────────────────────

def is_hold_action(feed_config: Mapping[str, Any]) -> bool:
    return str(feed_config.get("row_count_action") or "").lower() == HOLD_ACTION


def should_hold(feed_config: Mapping[str, Any], outcome: Optional[Mapping[str, Any]], *,
                dry_run: bool = False, delivery_suppressed: Optional[bool] = False) -> bool:
    """Hold this execution's file?  Only for a feed that DECLARED 'hold',
    whose check ran and breached, on a run that would otherwise deliver
    (a dry run or a suppressed run sends nothing anyway)."""
    if dry_run or delivery_suppressed:
        return False
    if not is_hold_action(feed_config):
        return False
    o = outcome or {}
    return bool(not o.get("skipped") and o.get("breach"))


def previous_baseline(db, feed_config: Mapping[str, Any], business_date) -> Optional[Dict[str, Any]]:
    """The baseline ``row_count_check.evaluate`` reads.  'previous': the
    rows the latest EARLIER business date DELIVERED (None when none was
    ever delivered -- the check then says ``no_previous_delivery``).
    Anything else: the rolling baseline row, as before."""
    from core.feed.row_count_check import PREVIOUS_BASELINE_KIND
    fid = int(feed_config.get("id") or 0)
    if str(feed_config.get("row_count_compare_to") or "").lower() == "previous":
        if business_date is None or db is None:
            return None
        bd = _as_date(business_date)
        prev = db.previous_delivered_rows(fid, bd)
        if not prev:
            return None
        pbd = prev.get("business_date")
        return {"kind": PREVIOUS_BASELINE_KIND, "avg_rows": int(prev["rows"]),
                "sample_count": 1,
                "business_date": pbd.isoformat() if hasattr(pbd, "isoformat") else pbd,
                "execution_db_id": prev.get("execution_db_id")}
    return db.get_feed_row_count_baseline(fid) if db is not None else None


def hold_sentence(outcome: Mapping[str, Any]) -> str:
    """One sentence for the run record, the log and the bell."""
    o = outcome or {}
    actual = o.get("actual_rows")
    if o.get("reason") == "below_absolute_floor":
        return (f"HELD for verification: {actual} rows is below the floor "
                f"{o.get('min_rows')} (row_count_min_rows)")
    if o.get("reason") == "previous_was_zero":
        return (f"HELD for verification: {actual} rows after a previous business "
                f"date that delivered 0")
    base = ("the previous business date's delivered "
            + str(o.get("baseline_avg"))
            + (f" ({o.get('baseline_business_date')})" if o.get("baseline_business_date") else "")
            if o.get("baseline_kind") == "previous_business_date"
            else f"the rolling baseline {o.get('baseline_avg')}")
    return (f"HELD for verification: {actual} rows is {o.get('direction')} "
            f"{o.get('delta_pct')}% against {base}, beyond the "
            f"{o.get('threshold_pct')}% threshold")


def record_hold(db, *, feed_config: Mapping[str, Any], feed_run_id: Optional[int],
                exec_db_id: int, exec_id: str, business_date, outcome: Mapping[str, Any],
                artifact_path: str, file_size: Optional[int],
                delivery_inputs: Mapping[str, Any]) -> Dict[str, Any]:
    """Write the queue entry.  RAISES when it cannot: the engine calls this
    before the execution's terminal write, so a failure fails the run."""
    o = dict(outcome or {})
    pbd = o.get("baseline_business_date")
    row = db.create_variance_hold({
        "feed_config_id": int(feed_config.get("id")),
        "feed_name": feed_config.get("name"),
        "feed_run_id": int(feed_run_id) if feed_run_id else None,
        "execution_db_id": int(exec_db_id), "execution_id": exec_id,
        "business_date": _as_date(business_date) if business_date else None,
        "actual_rows": o.get("actual_rows"),
        "baseline_rows": o.get("baseline_avg"),
        "baseline_kind": o.get("baseline_kind") or (
            "floor" if o.get("reason") == "below_absolute_floor" else None),
        "baseline_business_date": _as_date(pbd) if pbd else None,
        "delta_pct": o.get("delta_pct"), "direction": o.get("direction"),
        "threshold_pct": o.get("threshold_pct"),
        "reason": o.get("reason") or "threshold",
        "artifact_path": artifact_path, "file_size_bytes": file_size,
        "delivery_inputs": dict(delivery_inputs or {}),
        "status": "held",
    })
    _alert(db, feed_config, row, hold_sentence(o))
    return row


def _alert(db, feed: Mapping[str, Any], row: Mapping[str, Any], sentence: str) -> None:
    """THE alert road (core/feed/feed_alerts.py, 2026-10-12): the people who
    may decide (owner + approver groups) in the bell, plus the kind's e-mail
    and Netcool channels -- all data (``feed_alert_kinds.variance_hold``).
    Advisory: the queue row IS the record; who was told is on the alert."""
    from core.feed import feed_alerts
    # an earlier hold of the same (feed, date) was SUPERSEDED by this one in
    # create_variance_hold's transaction: its alert is answered with it
    feed_alerts.clear(db, by=f"superseded by hold {row.get('id')}",
                      feed_config_id=feed.get("id"), business_date=row.get("business_date"),
                      kinds_=["variance_hold"])
    feed_alerts.raise_alert(
        db, "variance_hold", feed=feed, business_date=row.get("business_date"),
        feed_run_id=row.get("feed_run_id"), execution_id=row.get("execution_id"),
        dedupe_key=alert_key(row), href="/feeds/today?holds=1",
        message=f"{row.get('feed_name')} {row.get('business_date')}: {sentence}")


def alert_key(row: Mapping[str, Any]) -> str:
    return f"variance_hold:{row.get('id')}"


def _clear_alert(db, row: Mapping[str, Any], by: str) -> None:
    from core.feed import feed_alerts
    feed_alerts.clear(db, by=by, dedupe_keys=[alert_key(row)])


def deciders_for(db, row: Mapping[str, Any]) -> List[str]:
    """Who is told a hold waits: the feed's owner and every member of a
    group mapped as its approver (the same rule ``decision_authority``
    applies; admins see the queue, they are not paged)."""
    names = set()
    feed = None
    try:
        feed = db.get_feed_config(int(row.get("feed_config_id")))
    except Exception:                                   # noqa: BLE001
        feed = None
    if feed and feed.get("created_by"):
        names.add(str(feed["created_by"]))
    for g, _ in approver_groups_for(db, feed or {}):
        for m in db.list_user_group_members(int(g["id"])) or []:
            if m.get("username"):
                names.add(str(m["username"]))
    return sorted(names)


# ── who may decide ───────────────────────────────────────────────────────

def release_group_name() -> str:
    try:
        from core import config as _c
        return str(_c.feed_generation.variance_hold_release_group or "").strip()
    except Exception:                                   # noqa: BLE001
        return DEFAULT_RELEASE_GROUP


def release_group(db) -> Optional[Dict[str, Any]]:
    name = release_group_name()
    if not name:
        return None
    return db.get_user_group_by_name(name)


def approver_groups_for(db, feed: Optional[Mapping[str, Any]]) -> List[Tuple[Dict[str, Any], str]]:
    """The user groups mapped as approvers for this feed, each with the scope
    that put it there (``global`` / ``feed group <name>`` / ``template ...`` /
    ``this feed``), plus the deployment's configured group if one is named.
    ``feed=None`` -> every mapped group (the list screen's "approver
    somewhere")."""
    out: List[Tuple[Dict[str, Any], str]] = []
    seen = set()

    def _add(gid, why):
        if gid in seen:
            return
        g = db.get_user_group(int(gid)) if hasattr(db, "get_user_group") else None
        if g:
            seen.add(gid)
            out.append((g, why))
    for a in db.list_hold_approvers() or []:
        sc, sid = a.get("scope"), a.get("scope_id")
        if feed is None:
            _add(a["user_group_id"], f"approver ({sc})")
        elif sc == "global":
            _add(a["user_group_id"], "approver for every feed")
        elif sc == "feed_group" and sid is not None and feed.get("feed_group_id") == sid:
            _add(a["user_group_id"], "approver for this feed's group")
        elif sc == "template" and sid is not None and feed.get("template_id") == sid:
            _add(a["user_group_id"], "approver for this feed's template")
        elif sc == "feed" and sid is not None and feed.get("id") == sid:
            _add(a["user_group_id"], "approver for this feed")
    g = release_group(db)
    if g:
        _add(g["id"], "the deployment's release group")
    return out


def deciders_sentence(db, feed: Optional[Mapping[str, Any]]) -> str:
    """"an admin, the feed's owner or a member of RTB_EMEA" -- who may
    decide this feed's hold, in the words the run's record carries."""
    try:
        names = sorted({str(g.get("name")) for g, _ in approver_groups_for(db, feed or {})})
    except Exception:                                   # noqa: BLE001 -- the generic words
        names = []
    return "an admin, the feed's owner" + (f" or a member of {', '.join(names)}" if names else "")


def decision_authority(db, user: Mapping[str, Any],
                       hold: Optional[Mapping[str, Any]] = None) -> Tuple[bool, str]:
    """(may decide, why) for THIS hold -- THE rule (module docstring): an
    admin, the feed's owner, or a member of a group mapped as its approver.
    Without a hold: may this user decide ANY hold (admin, or an approver
    somewhere) -- the list's "can decide" before a row is chosen."""
    from core.entitlements import is_admin_like
    from core.feed.permissions import can_edit_feed, user_in_group
    if is_admin_like(user):
        return True, "admin"
    username = str((user or {}).get("username") or "")
    feed = None
    if hold is not None:
        try:
            feed = db.get_feed_config(int(hold.get("feed_config_id")))
        except Exception:                               # noqa: BLE001 -- unreadable = not the owner
            feed = None
        if feed and username and str(feed.get("created_by") or "") == username:
            return True, "owner of the feed"
        if feed and feed.get("owner_group_id") and can_edit_feed(feed, user, db):
            return True, "read-write member of the feed's owner group"
    groups = approver_groups_for(db, feed if hold is not None else None)
    for g, why in groups:
        if username and user_in_group(db, username, int(g["id"])):
            return True, f"member of {g.get('name')} ({why})"
    if hold is not None:
        names = ", ".join(sorted({str(g.get("name")) for g, _ in groups}))
        return False, ("only an admin, the feed's owner"
                       + (f", or a member of {names}" if names else "")
                       + " may release or reject this held file"
                       + ("" if names else " -- no approver group is mapped for it "
                          "(Variance holds -> Approvers)"))
    return False, "you are not an admin or a mapped approver; a feed's owner decides its own holds"


def _clean_reason(reason: Optional[str]) -> str:
    text = " ".join(str(reason or "").split())
    if len(text) < DECISION_REASON_MIN_CHARS or len(set(text.lower().split())) < 2:
        raise HoldRefused(
            f"a reason of at least {DECISION_REASON_MIN_CHARS} characters and two "
            f"words is required -- it is the audit record of why this file was "
            f"(or was not) sent", status=422)
    return text


# ── the decisions ────────────────────────────────────────────────────────

def reject(db, hold_id: int, user: Mapping[str, Any], reason: Optional[str]) -> Dict[str, Any]:
    ok, why = decision_authority(db, user, _hold_or_404(db, hold_id))
    if not ok:
        raise HoldRefused(why, status=403)
    text = _clean_reason(reason)
    actor = str(user.get("username") or "unknown")
    row = db.claim_variance_hold(hold_id, OPEN_STATUSES, "rejected", {
        "decided_by": actor, "decided_at": datetime.now(timezone.utc),
        "decision_reason": text, "delivery_verdict": CHAIN_REJECTED})
    if row is None:
        raise HoldRefused(_not_open(db, hold_id))
    _stamp_execution(db, row, {"verdict": CHAIN_REJECTED,
                               "reason": f"rejected by {actor}: {text}",
                               "hold_id": row["id"]})
    _clear_alert(db, row, f"{actor}: rejected")
    logger.warning("[variance_hold] hold %s (%s %s) REJECTED by %s: %s -- nothing sent",
                   row["id"], row.get("feed_name"), row.get("business_date"), actor, text)
    return row


def release(db, hold_id: int, user: Mapping[str, Any], reason: Optional[str]) -> Dict[str, Any]:
    """Send the held file through the feed's delivery chain.  Claimed
    first (held|release_failed -> releasing); the outcome is ``released``
    or ``release_failed`` with the chain's own reason."""
    ok, why = decision_authority(db, user, _hold_or_404(db, hold_id))
    if not ok:
        raise HoldRefused(why, status=403)
    text = _clean_reason(reason)
    actor = str(user.get("username") or "unknown")
    current = db.get_variance_hold(hold_id)
    if current is None:
        raise HoldRefused(f"variance hold {hold_id} does not exist", status=404)
    path = str(current.get("artifact_path") or "")
    if not path or not os.path.exists(path):
        raise HoldRefused(
            f"the held file is no longer on the output volume ({path or 'no path recorded'}) "
            f"-- nothing can be sent; rerun the feed for "
            f"{current.get('business_date')} to produce it again (it is checked again)",
            status=409)
    row = db.claim_variance_hold(hold_id, OPEN_STATUSES, "releasing", {
        "decided_by": actor, "decided_at": datetime.now(timezone.utc),
        "decision_reason": text, "release_error": None})
    if row is None:
        raise HoldRefused(_not_open(db, hold_id))
    try:
        verdict, chain_reason, dest_uri, hops = _deliver(db, row, actor)
    except Exception as exc:                            # noqa: BLE001
        logger.exception("[variance_hold] release of hold %s failed", hold_id)
        verdict, chain_reason, dest_uri, hops = "failed", f"{type(exc).__name__}: {exc}", "", None
    from core.feed.delivery_hops import CHAIN_DELIVERED
    released = verdict == CHAIN_DELIVERED
    record = {"verdict": verdict, "reason": chain_reason, "hold_id": row["id"],
              "released_by": actor, "release_reason": text}
    _stamp_execution(db, row, record, delivered_uri=dest_uri if released else None,
                     hops=hops)
    out = db.update_variance_hold(row["id"], {
        "status": "released" if released else "release_failed",
        "delivery_verdict": verdict, "delivered_uri": dest_uri or None,
        "release_error": None if released else chain_reason})
    if released:
        _clear_alert(db, row, f"{actor}: released")
    logger.warning("[variance_hold] hold %s (%s %s) released by %s -> %s %s", row["id"],
                   row.get("feed_name"), row.get("business_date"), actor, verdict,
                   dest_uri or chain_reason)
    return out


def _hold_or_404(db, hold_id: int) -> Dict[str, Any]:
    h = db.get_variance_hold(int(hold_id))
    if not h:
        raise HoldRefused(f"variance hold {hold_id} not found", status=404)
    return h


def _not_open(db, hold_id: int) -> str:
    cur = db.get_variance_hold(hold_id)
    if cur is None:
        return f"variance hold {hold_id} does not exist"
    return (f"variance hold {hold_id} is {cur.get('status')} "
            f"(by {cur.get('decided_by') or '-'}: {cur.get('decision_reason') or '-'}) -- "
            f"only a held or release_failed file can be decided")


def _deliver(db, hold: Mapping[str, Any], actor: str):
    """The feed's CURRENT chain, over the held file, through THE transport
    the engine and the hop retry use.  Returns (verdict, reason, uri, hops)."""
    from core import feed_engine as _fe
    from core.feed.delivery_hops import DeliveryHopRunner, build_hop_plan, chain_verdict
    feed = db.get_feed_config(int(hold["feed_config_id"]))
    if not feed:
        return "failed", f"feed {hold['feed_config_id']} no longer exists", "", None
    inputs = dict(hold.get("delivery_inputs") or {})
    output_path = str(hold["artifact_path"])
    filename = inputs.get("filename") or os.path.basename(output_path)
    control_file_path = inputs.get("control_file_path")
    sidecar_path = inputs.get("sidecar_path")
    exec_id = str(hold.get("execution_id") or "")
    biz = _as_date(hold["business_date"]) if hold.get("business_date") else None
    dest_config = dict(feed.get("destination_config") or {})
    _, retry_delay = _fe.delivery_retry_policy(feed, _fe._cfg)
    receipt: Dict[str, Any] = {}

    def _transport(hop, _manifest):
        uri = _fe._deliver_data_then_control(
            output_path, filename, control_file_path, hop.target_type, dict(hop.config),
            0, retry_delay, int(hold["feed_config_id"]), exec_id, _receipt=receipt,
            sidecar_path=sidecar_path)
        return {"uri": uri, "sent_path": output_path,
                "verification": receipt.get("verification"),
                "verification_detail": receipt.get("verification_detail")}

    plan = build_hop_plan({**feed, "destination_config": dest_config},
                          run_identity={"feed": feed.get("name"), "business_date": biz,
                                        "build_id": exec_id})
    manifest = _fe._delivery_manifest_for(output_path, int(hold.get("actual_rows") or 0),
                                          int(hold["feed_config_id"]), exec_id)
    runner = DeliveryHopRunner(
        db, {h.target_type: _transport for h in plan},
        environment=_fe._deploy_environment(), actor=actor,
        suppression_policy=getattr(_fe._cfg, "delivery_suppression", None)
        if _fe._cfg is not None else None)
    # run_suppressed=False: a held execution was, by construction, one that
    # would have delivered (should_hold refuses a suppressed run).
    outcomes = runner.execute_chain(plan, manifest, feed_config_id=int(hold["feed_config_id"]),
                                    business_date=biz, feed_key=feed.get("name"),
                                    run_suppressed=False)
    verdict, why = chain_verdict(plan, outcomes)
    uri = next((o.uri for o in (outcomes or []) if getattr(o, "uri", None)), "")
    hops = [o.to_dict() if hasattr(o, "to_dict") else str(o) for o in (outcomes or [])]
    return verdict, why, uri, hops


def _stamp_execution(db, hold: Mapping[str, Any], chain: Dict[str, Any], *,
                     delivered_uri: Optional[str] = None, hops=None) -> None:
    """The decision on the EXECUTION -- the record every other reader reads.
    ``update_feed_execution`` is the one write the on-completion trigger
    watches: a verdict CHANGING to delivered on a completed row fires it."""
    ex = db.get_feed_execution(int(hold["execution_db_id"])) or {}
    st = dict(ex.get("stage_timings") or {})
    st["delivery_chain"] = chain
    if hops is not None:
        st["delivery_hops"] = hops
    vh = dict(st.get("variance_hold") or {})
    vh.update({"hold_id": hold.get("id"), "status": hold.get("status"),
               "decided_by": hold.get("decided_by")})
    st["variance_hold"] = vh
    upd: Dict[str, Any] = {"stage_timings": st}
    if delivered_uri:
        upd["destination_path"] = delivered_uri
        upd["delivery_completed_at"] = datetime.now(timezone.utc)
    db.update_feed_execution(int(hold["execution_db_id"]), upd)
    if delivered_uri and hold.get("feed_run_id"):
        try:
            db.update_feed_run(int(hold["feed_run_id"]), {"output_path": delivered_uri})
        except Exception:                               # noqa: BLE001
            logger.debug("[variance_hold] run output_path not updated", exc_info=True)


def _as_date(v) -> date:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])
