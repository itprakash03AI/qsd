"""Airflow/Spark-batch feed plan serialization — resolve HERE, execute THERE.

2026-08-04.  The third feed backend (Airflow → ``spark/jobs/generic_feed.py``)
is the one that actually orchestrates in production (``spark_connect.enabled``
is False), yet it was the only backend left OUT of the source-plan
unification: ``generic_feed.py`` carried its own cross-source resolution
("Mirrors core.executors.cross_source_combine" — a mirror kept in sync by
DISCIPLINE), and the trigger side (``feed_engine._execute_airflow`` + the DAG
factory) shipped RAW feed-config fields, so none of the 2026-08-04 resolution
semantics (referenced-source inheritance, saved-query secondary shapes,
sql_file ``-- ===SECONDARY===`` splitting, fail-closed partial-config
refusals) ever reached the Spark job.

The fix is the same relationship ``render_inline``/``render_bound`` have to
``query_compiler`` (commit 4d94c60f): the BACKEND resolves the feed's source
shape ONCE — through ``core.feed.source_plan``, the exact chokepoint the
native and Spark Connect paths consume — and SERIALIZES the resolved plan
into the DAG-run conf.  ``generic_feed.py`` then EXECUTES a plan instead of
re-resolving one: the Spark job is a renderer, not a second brain.  The Spark
job cannot import ``backend/core`` (different process, different image, no DB
access), which is exactly why serialization — not a shared import — is the
seam.

Serialized shape (JSON-safe by construction)::

    {
      "plan_version": "1.0",           # major.minor — job refuses major≠1
      "resolved_by":  "core.feed.airflow_plan",
      "feed_config_id": ...,
      "is_cross": bool,
      "combine_mode": "union"|"join"|None,
      "join_config": {...}|None,
      "primary":   {"kind": "sql", "sql": str, "connection_id": ...,
                    "source_label": "sql_file:7"},
      "secondary": {...same shape...} | None,
    }

Version/compat contract (tested in
``tests/test_feed_airflow_source_plan_2026_08_04.py``):

  * NEW job + NEW conf: executes the plan; refuses LOUDLY when
    ``plan_version``'s major differs from what the job supports — explicit
    refusal beats silent misinterpretation.
  * OLD job + NEW conf: an old ``generic_feed.py`` ignores the unknown
    ``source_plan`` key and executes the LEGACY keys — which the plan
    producer OVERLAYS with the resolved SQL (``query_params.sql`` /
    ``secondary_query_params.sql`` carry the plan sides' exact SQL text).
    The legacy projection IS the plan, so an old worker executes the same
    resolved SQL rather than misreading anything.
  * NEW job + OLD conf (no ``source_plan``): the legacy branch runs
    byte-identically to before — existing feeds change nothing.

Fail-closed vs fail-open (deliberate, per case):

  * The four defect shapes (unsplit sql_file, ignored saved-query secondary
    shape, skipped published_view inheritance, partial cross config) surface
    as ``ValueError`` / ``BackendCapabilityError`` from ``source_plan`` —
    those PROPAGATE.  Running anyway would emit half the data and certify it
    COMPLETE.
  * Feed configs OUTSIDE the backend source vocabulary (hand-authored
    ``s3_parquet`` / ``jdbc`` / pre-extracted ``source_path`` configs that
    ``generic_feed.py`` executes directly today) return ``None`` — the
    caller ships the legacy conf unchanged.  Refusing those would break
    working feeds; they never had backend-side resolution to unify.
  * A ``{{token}}`` this feed's calendar vocabulary cannot resolve is a
    ``ValueError`` too (2026-09-05, :func:`substitute_airflow_sql`).  The
    job is detached: a literal ``{{business_date}}`` is a JDBC error at
    best, and at worst a string a source matches nothing against — a wrong
    answer that certifies COMPLETE.  Unknown must never silently become
    the literal text.

Every side's SQL leaves here fully SUBSTITUTED: the feed calendar
vocabulary is resolved once per submission
(:func:`resolve_airflow_feed_params`, the same
``core.feed.param_resolver`` every other lane uses) and applied BEFORE the
RLS rewrite — the order the native, Spark Connect and union-pushdown lanes
enforce, because a token breaks the RLS parser.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

logger = logging.getLogger(__name__)

# The feed token grammar, identical to the one the resolver substitutes and
# the one ``spark/jobs/generic_feed.py::_substitute_feed_params`` looks for.
# Used ONLY to detect what substitution did NOT resolve.
_FEED_TOKEN_RE = re.compile(r"\{\{(\w+)\}\}")

# Bump the MINOR for additive fields old jobs may ignore; bump the MAJOR
# only for changes an old executor would MISREAD (the job refuses on major
# mismatch — see spark/jobs/generic_feed.py::_require_supported_plan).
PLAN_FORMAT_VERSION = "1.1"   # 1.1 (2026-10-14): the "tables" side kind (core/feed/read_plan.py)

# The source vocabulary the backend can resolve.  Anything else
# (``s3_parquet`` / ``s3_csv`` / ``jdbc`` / ``auto`` — generic_feed.py's own
# hand-authored vocabulary) is executed by the Spark job from the raw conf
# exactly as before; there is nothing backend-side to resolve for them.
BACKEND_SOURCE_TYPES = frozenset(
    {"saved_query", "sql_file", "published_view", "raw_sql"}
)


def resolve_airflow_feed_params(db_manager: Any,
                                feed_config: dict) -> Dict[str, Any]:
    """The feed calendar vocabulary for THIS run, resolved once per
    submission (2026-09-05).

    Every other lane resolves it — native (``apply_to_raw_sql``), union
    pushdown, Spark Connect, spark_k8s (in-pod, via
    ``core.spark_k8s.feed_conf.build_calendar_feed_params``) — and Airflow,
    the lane the SIZE router sends the BIGGEST feeds to, resolved nothing:
    ``{{business_date}}`` reached the DAG conf as literal text and the Spark
    job's own substitution found ``conf["feed_params"]`` absent (nothing on
    this lane ever produced that key), so it shipped the token to JDBC.

    Same resolver, same feed_run, same calendar as the native path — one
    date vocabulary, not a second implementation of it.
    """
    from core.feed.param_resolver import resolve_feed_params

    feed_run = (feed_config.get("_feed_run")
                if isinstance(feed_config, dict) else None)
    calendar = None
    try:
        # The calendar lookup the native / Spark Connect / union lanes use,
        # imported lazily: feed_engine imports THIS module at trigger time.
        from core.feed_engine import _load_calendar_for_feed
        calendar = _load_calendar_for_feed(feed_config, db=db_manager)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning(
            "[feed-airflow-params] calendar lookup unavailable (%s) — tokens "
            "resolve with plain calendar-day arithmetic", exc)
    return resolve_feed_params(feed_config or {}, feed_run, calendar)


def substitute_airflow_sql(sql: Optional[str], params: Dict[str, Any], *,
                           which: str = "primary",
                           feed_id: Any = None,
                           bindings: Any = None, contract: Any = None) -> Optional[str]:
    """Substitute ``{{token}}`` in SQL bound for the Airflow/Spark lane.

    REFUSES (``ValueError``) when a token survives substitution.  The Spark
    job runs detached, with no DB and no principal, so a token that reaches
    it is either a JDBC syntax error at 2am or — worse — a string literal
    that a source happily matches nothing against and certifies COMPLETE.
    "Unknown must never silently become the literal text": an unresolvable
    token is a REFUSAL at trigger time, naming the token, not a shipped
    ``{{business_date}}``.

    Substitution is the same one every other lane performs (the
    ``api.published_views.helpers._substitute_params`` chokepoint that
    ``core.feed.param_resolver.apply_to_query_config`` calls), fed by
    :func:`resolve_airflow_feed_params`.  Its import/escaping failure is
    fail-CLOSED here, unlike ``apply_to_raw_sql``'s silent
    return-unchanged: returning the SQL unchanged is exactly the literal
    shipment this refuses.
    """
    # 2026-10-11 -- a feed's token BINDINGS rewrite the saved query's bound
    # literals to tokens on THIS side first (the same function the native
    # lane calls through render_og_tokens); a binding that no longer
    # matches is a ValueError (BindingRefused) and never ships.
    if bindings:
        from core.feed.sql_tokens import apply_token_bindings
        sql = apply_token_bindings(sql, bindings, side=which, feed_id=feed_id)
    if not sql or "{" not in sql:
        return sql
    out = sql
    if "{{" in sql:
        try:
            from api.published_views.helpers import _substitute_params
            out = (_substitute_params({"raw_sql": sql}, params or {})
                   or {}).get("raw_sql", sql)
        except Exception as exc:
            raise ValueError(
                f"Feed {feed_id!r} {which} side carries calendar tokens but "
                f"parameter substitution is unavailable ({type(exc).__name__}: "
                f"{exc}).  Refusing to submit SQL with unresolved tokens to a "
                f"detached Spark job."
            ) from exc
    # 2026-10-10 -- the OG single-brace vocabulary, THE same renderer the
    # native lane applies after its {{}} pass (core/feed/sql_tokens.py).
    # Its refusals are ValueErrors already: a declared token with no value
    # or a value a literal cannot hold never ships to the detached job.
    from core.feed.sql_tokens import render_og_tokens
    out = render_og_tokens(out, params or {}, feed_id=feed_id, side=which, contract=contract)
    unresolved = sorted(set(_FEED_TOKEN_RE.findall(out or "")))
    if unresolved:
        known = ", ".join(sorted(params or {})[:12])
        raise ValueError(
            f"Feed {feed_id!r} {which} side references parameter(s) "
            f"{unresolved} that the feed calendar vocabulary does not "
            f"resolve.  Refusing to ship them as literal text to the "
            f"Airflow/Spark job — an unresolved token is a wrong answer, "
            f"not a smaller one.  Fix: correct the token, or declare the "
            f"value in the feed's query_params.  Resolved names include: "
            f"{known}..."
        )
    return out


def _extract_side_sql(side_qcfg: dict, source_label: str) -> Optional[str]:
    """The SQL text a resolved side executes on the Spark batch job.

    Mirrors the precedence the Spark Connect path uses
    (``feed_engine._execute_spark_connect``: ``raw_sql or custom_sql``).
    Returns ``None`` for a structured builder config with no SQL text —
    the caller decides between legacy passthrough and a loud refusal.
    """
    for key in ("raw_sql", "custom_sql"):
        val = side_qcfg.get(key)
        if isinstance(val, str) and val.strip():
            return val
    logger.info(
        "[feed-crosssource] %s resolves to a structured builder config "
        "with no SQL text — not serializable for the Spark batch job",
        source_label,
    )
    return None


def _stamp_dialect(db_manager: Any, side_fc: dict, connection_id: Any) -> None:
    """Stamp ``connection_type`` on the side's feed_config from the side's
    OWN connection, so ``apply_where_to_raw_sql`` renders the WHERE-mapping
    wrap — and ``secure_feed_sql`` emits the policy rewrite — in the dialect
    of the engine that side actually executes on.

    2026-09-05 — this used to ``return`` the moment ``connection_type`` was
    ALREADY set, which made an INHERITED value authoritative.  Every side
    dict here starts life as a copy of the feed config, and the native path
    stamps ``connection_type`` onto that feed config IN PLACE, so a feed
    arriving with the primary's type handed the SECONDARY side the
    PRIMARY's dialect: the rewrite that decides what rows a delivered file
    contains was emitted for the wrong engine, on the plan path — the one
    that was supposed to be the safe one.  The legacy conf path closed the
    identical hole by popping the key before re-resolving from the
    secondary's own connection (``feed_engine._secure_airflow_side_sql``);
    the two paths now agree.  Row security PER SIDE, each with its OWN
    connection — the rule ``core.feed.union_pushdown`` states.

    Fail-open in ONE direction only: when the lookup cannot answer, whatever
    was already there is kept (an unknown connection falls back to the
    helper's own lookup / DuckDB grammar, exactly like the native path).
    A lookup that DOES answer wins — "cannot tell" keeps the old value,
    "can tell" is the value.
    """
    if not connection_id:
        return
    resolved = None
    try:
        conn = db_manager.get_connection(connection_id)
        if conn and conn.get("connection_type"):
            resolved = conn.get("connection_type")
    except Exception as exc:
        logger.debug(
            "[feed-crosssource] dialect stamp lookup failed for connection "
            "%s: %s", connection_id, exc,
        )
    if not resolved:
        return
    existing = side_fc.get("connection_type")
    if existing and existing != resolved:
        logger.warning(
            "[feed-crosssource] feed %s side carried connection_type=%r but "
            "its OWN connection %s is %r — securing in the side's own "
            "dialect (an inherited dialect rewrites for the wrong engine)",
            side_fc.get("id"), existing, connection_id, resolved,
        )
    side_fc["connection_type"] = resolved


def _resolve_serialized_side(db_manager: Any, side_fc: dict,
                             which: str,
                             params: Optional[Dict[str, Any]] = None,
                             ) -> Optional[Dict[str, Any]]:
    """Resolve ONE side through the shared chokepoint and serialize it.

    Returns ``None`` when the side cannot be expressed as SQL text AND the
    legacy conf already carries a pre-extracted ``source_path`` for it
    (a shape generic_feed.py executes directly today — regressing it into
    a refusal would break a working feed).  Raises ``ValueError`` when the
    side can neither be serialized nor legacy-executed: that feed has
    never produced output on this backend, and failing at trigger time
    with the fix named beats failing inside a detached Spark pod.
    """
    from core.feed.source_plan import resolve_side_query_config
    from core.feed_where_apply import apply_where_to_raw_sql

    side = resolve_side_query_config(db_manager, side_fc)
    sql = _extract_side_sql(side.query_config, side.source_label)
    if sql is None:
        # Legacy pre-extracted shape: primary side reads
        # ``query_params.source_path``; a secondary side's overrides live
        # under ``query_params.secondary`` (shipped to the job as
        # ``secondary_query_params`` — see _execute_airflow / DAG factory).
        _qp = side_fc.get("query_params") or {}
        legacy_qp = _qp if which == "primary" else ((_qp.get("secondary")) or {})
        if (legacy_qp or {}).get("source_path"):
            # Pre-extracted data path (legacy contract): the Spark job
            # reads query_params.source_path from S3 directly.  Ship the
            # legacy conf unchanged.
            logger.info(
                "[feed-crosssource] feed %s %s side %s: pre-extracted "
                "source_path present — shipping legacy conf (no plan)",
                side_fc.get("id"), which, side.source_label,
            )
            return None
        raise ValueError(
            f"Feed '{side_fc.get('name') or side_fc.get('id')}' {which} side "
            f"({side.source_label}) resolves to a structured query-builder "
            f"config with no SQL text.  The Airflow/Spark batch backend "
            f"executes SQL text via JDBC and cannot execute a builder "
            f"config.  Fix: run this feed on the native backend, re-save "
            f"the source query in SQL mode, or supply a pre-extracted "
            f"query_params.source_path."
        )

    # Feed-level WHERE mapping (Static + consumer Dynamic), applied per
    # side with the side's own dialect — the same wrap the native path
    # applies inside _run_single_source_native_query and the Spark Connect
    # path applies inline.  No-op when the feed carries no mapping.
    _stamp_dialect(db_manager, side_fc, side.connection_id)
    try:
        sql = apply_where_to_raw_sql(sql, side_fc) or sql
    except Exception as exc:
        # 2026-08-19 -- the parity argument below is no longer true: the
        # native branches now FAIL on a wrap crash rather than running
        # unwrapped, precisely because dropping publisher filters widens the
        # result.  Matching that behaviour keeps the two trigger paths
        # equivalent, which is the property this comment was defending.
        logger.error(
            "[feed-crosssource] WHERE-mapping wrap FAILED on %s side of "
            "feed %s (%s) -- refusing to serialize unfiltered SQL",
            which, side_fc.get("id"), exc,
        )
        raise RuntimeError(
            f"Feed filter application failed on the {which} side: {exc}. "
            f"Refusing to serialize SQL with the publisher's filters "
            f"dropped."
        ) from exc

    # ── Calendar parameter substitution (2026-09-05) ──────────────────
    # BEFORE the RLS rewrite, and after the WHERE wrap: the exact order
    # the Spark Connect branch and the union-pushdown planner enforce
    # (a ``{{token}}`` breaks the RLS parser, and a wrap-injected token
    # must be resolved too).  Unresolvable tokens REFUSE here — see
    # substitute_airflow_sql.
    if params is None:
        params = resolve_airflow_feed_params(db_manager, side_fc)
    # the UPSTREAM CONTRACT this side reads (resolved by the execution, else
    # now -- core/feed/upstream_contract.py::contract_for)
    from core.feed.upstream_contract import contract_for
    # ONE query, this side's tables renamed (core/feed/table_map.py)
    from core.feed.table_map import apply_for_feed as _map_tables
    sql = _map_tables(sql, side_fc, side=which)
    sql = substitute_airflow_sql(sql, params, which=which,
                                 feed_id=side_fc.get("id"),
                                 bindings=side_fc.get("token_bindings"),
                                 contract=contract_for(side_fc, params, db_manager))

    # ── Row-level security (2026-08-17, F1) ───────────────────────────
    # The Spark batch job executes this SQL detached, with no DB access
    # and no principal — so policy enforcement MUST happen here, at
    # serialization time, exactly like the native path enforces it at
    # execution time.  Feed-owner principal; dialect from the side's
    # connection_type (stamped above).  NOT inside the fail-open WHERE
    # try/except: an enforcement failure propagates as ValueError, which
    # _execute_airflow treats as a deliberate fail-closed refusal.
    from core.feed.rls import secure_feed_sql
    sql = secure_feed_sql(
        db_manager, sql, side_fc,
        connection_id=side.connection_id,
        connection_type=side_fc.get("connection_type"),
        request_id=side_fc.get("_exec_id"),
    )

    # 2026-10-14 -- an S3 side is a "tables" side: QueryStudio's planner
    # decides what each table reads (pinned Iceberg snapshot / Hive-rule
    # files) and the job runs the SQL over those tables -- never a JDBC read
    # of a connection that has no JDBC (core/feed/read_plan.py)
    from core.feed.partitioned_read import by_files_record, plan_for_detached_side
    _ctype = str(side_fc.get("connection_type") or "").lower()
    if _ctype == "s3":
        from core.feed.read_plan import plan_tables_side
        _tables = plan_tables_side(db_manager, side.connection_id, sql,
                                   source_label=side.source_label, feed_id=side_fc.get("id"))
        # a declared partition key on a FILES side: the files are the parts
        # (the decision QueryStudio's engine makes, recorded the same way)
        _rec = by_files_record(side_fc, _ctype)
        if _rec:
            _tables["partitions"] = _rec
        return _tables
    out = {
        "kind": "sql",
        "sql": sql,
        "connection_id": side.connection_id,
        "source_label": side.source_label,
    }
    # 2026-10-14 -- a declared partition key (OG's partition_config) on a
    # JDBC side: planned HERE with the planner QueryStudio's engine uses,
    # shipped as one query per bucket; the job reads one JDBC partition per
    # bucket in value order (core/feed/partitioned_read.py).  It used to be
    # ignored on the Spark lane -- the whole query through ONE connection.
    _parts = plan_for_detached_side(db_manager, side_fc, side.connection_id, _ctype, sql)
    if _parts:
        out["partitions"] = _parts
    return out


def build_serialized_plan(db_manager: Any,
                          feed_config: dict,
                          params: Optional[Dict[str, Any]] = None,
                          ) -> Optional[Dict[str, Any]]:
    """THE producer: resolve a feed's source shape for the ``airflow``
    backend and serialize it for the detached Spark job.

    * Returns a plan dict (see module docstring) for backend-vocabulary
      sources.
    * Returns ``None`` for out-of-vocabulary sources (hand-authored
      generic_feed configs) and for pre-extracted ``source_path`` shapes —
      the caller ships the legacy conf unchanged.
    * Raises ``ValueError`` / ``BackendCapabilityError`` for the deliberate
      fail-closed refusals (partial cross config, unsplit-marker sql_file
      on a single-source feed, unserializable side with no legacy path).

    Never mutates ``feed_config`` — resolution runs on a shallow copy, and
    the returned plan carries every field the caller needs (the native
    path's in-place mutation contract stays native-only).
    """
    if db_manager is None:
        logger.info(
            "[feed-crosssource] airflow plan: no db_manager (early boot?) — "
            "shipping legacy conf")
        return None

    source_type = (feed_config.get("source_type") or "").strip()
    if source_type not in BACKEND_SOURCE_TYPES:
        logger.info(
            "[feed-crosssource] airflow plan: source_type %r is outside the "
            "backend vocabulary %s — shipping legacy conf for feed %s",
            source_type, sorted(BACKEND_SOURCE_TYPES), feed_config.get("id"),
        )
        return None

    from core.feed.source_plan import resolve_source_plan

    fc = dict(feed_config)  # inheritance mutates top-level keys only
    plan = resolve_source_plan(db_manager, fc, "airflow")

    # ONE resolution of the run's date vocabulary for BOTH sides (and, when
    # the caller passes it in, the same dict that rides in the DAG conf as
    # ``feed_params``): two sides of one run must never disagree about what
    # ``{{business_date}}`` is.
    if params is None:
        params = resolve_airflow_feed_params(db_manager, fc)

    primary_fc = dict(fc)
    if plan.is_cross:
        primary_fc["_cross_side"] = "primary"
    primary = _resolve_serialized_side(db_manager, primary_fc, "primary",
                                       params)
    if primary is None:
        return None

    secondary: Optional[Dict[str, Any]] = None
    if plan.is_cross:
        # Same side-construction as the native cross path
        # (feed_engine._run_cross_source_native_query): connection swaps to
        # the secondary; source_type/source_id fall back to the primary's
        # when unset (common case: same query, different warehouse).
        # ONE builder for the secondary's feed_config (2026-10-11,
        # ``source_plan.secondary_side_config``): the connection swap, the
        # fallback to the primary's source, the dropped dialect stamp
        # (2026-09-05: a config that already ran natively carries the
        # PRIMARY's connection_type; the secondary re-resolves its own) and
        # a raw_sql second side's ``query_params.secondary_raw_sql``.
        from core.feed.source_plan import secondary_side_config
        secondary_fc = secondary_side_config(fc, plan)
        secondary = _resolve_serialized_side(db_manager, secondary_fc,
                                             "secondary", params)
        if secondary is None:
            return None

    serialized: Dict[str, Any] = {
        "plan_version": PLAN_FORMAT_VERSION,
        "resolved_by": "core.feed.airflow_plan",
        "resolved_at_utc": datetime.now(timezone.utc).isoformat(),
        "feed_config_id": feed_config.get("id"),
        "is_cross": bool(plan.is_cross),
        "combine_mode": plan.combine_mode if plan.is_cross else None,
        "join_config": plan.join_config if plan.is_cross else None,
        "primary": primary,
        "secondary": secondary,
    }
    logger.info(
        "[feed-crosssource] airflow plan serialized for feed=%s "
        "(is_cross=%s combine=%s primary=%s secondary=%s plan_version=%s)",
        feed_config.get("id"), serialized["is_cross"],
        serialized["combine_mode"], primary.get("source_label"),
        (secondary or {}).get("source_label"), PLAN_FORMAT_VERSION,
    )
    return serialized


def overlay_legacy_projection(conf_query_params: Optional[dict],
                              conf_secondary_query_params: Optional[dict],
                              plan: Dict[str, Any]) -> None:
    """Overlay the plan sides' resolved SQL onto the LEGACY conf keys
    (in place) so an OLD ``generic_feed.py`` — which ignores the
    ``source_plan`` key entirely — executes the SAME resolved SQL instead
    of misreading the conf.  This is the version-compat rule's second
    half: the legacy projection IS the plan.
    """
    primary = plan.get("primary") or {}
    if (conf_query_params is not None
            and primary.get("kind") == "sql" and primary.get("sql")):
        conf_query_params["sql"] = primary["sql"]
    secondary = plan.get("secondary") or {}
    if (conf_secondary_query_params is not None
            and secondary.get("kind") == "sql" and secondary.get("sql")):
        conf_secondary_query_params["sql"] = secondary["sql"]


# ─────────────────────────────────────────────────────────────────────────
# Is the LEGACY conf, for THIS feed, something the backend can secure?
# (2026-09-05)
# ─────────────────────────────────────────────────────────────────────────
#
# ``_execute_airflow`` may ship the legacy DAG conf instead of a plan (an
# out-of-vocabulary source_type, a pre-extracted ``source_path``, or an
# UNEXPECTED serializer crash).  Whether that is safe depends on ONE
# property of the conf, and it is a property that can be computed BEFORE
# anything is attempted: does every side ship as SQL TEXT the backend
# rewrites, or as a SOURCE REFERENCE the detached Spark job resolves and
# executes itself?
#
# A source reference cannot be secured by anyone.  ``generic_feed.py`` runs
# with no DB and no principal: a ``saved_query`` / ``published_view`` side
# with no ``query_params.sql`` is read straight off
# ``query_params.source_path`` (raw parquet, no WHERE mapping, no policy
# rewrite), and a ``sql_file`` side falls back to a driver-local
# ``sql_file_path``.  Nothing downstream re-applies what the backend did
# not apply.
#
# This is a CLASSIFIER, not a handler.  It is pure, it never raises, it
# touches no DB, and it is called BEFORE the plan build — so the
# ship-or-refuse decision is made by code that looked at the conf, not by
# an ``except Exception`` that looked at a traceback.  Today's lesson,
# twice over: catch it BEFORE the fail-open handler.


@dataclass(frozen=True)
class LegacyConfSecurity:
    """The verdict on one feed's legacy DAG conf.

    ``securable`` — every side this conf ships is SQL TEXT, so the backend
    applies the WHERE wrap + calendar substitution + RLS rewrite to all of
    it before it leaves.

    ``unsecured_sides`` — the sides that would ship as a source REFERENCE,
    named ("primary" / "secondary").  ``reason`` says what and why, in the
    words an operator has to act on.
    """
    securable: bool
    unsecured_sides: Tuple[str, ...] = ()
    reason: str = ""


def _side_ref_label(feed_config: dict, which: str) -> str:
    """How a side would ship when it carries no SQL text — for the message."""
    fc = feed_config or {}
    if which == "secondary":
        s_type = fc.get("secondary_source_type") or fc.get("source_type")
        s_id = fc.get("secondary_source_id") or fc.get("source_id")
        qp = ((fc.get("query_params") or {}).get("secondary")) or {}
    else:
        s_type, s_id = fc.get("source_type"), fc.get("source_id")
        qp = fc.get("query_params") or {}
    extra = (" (query_params.source_path=%r)" % qp.get("source_path")
             if isinstance(qp, dict) and qp.get("source_path") else "")
    return f"{which}: source_type={s_type!r} source_id={s_id!r}{extra}"


def _side_sql_text(feed_config: dict, which: str) -> Optional[str]:
    qp = feed_config.get("query_params") or {}
    if which == "secondary":
        qp = (qp.get("secondary") or {}) if isinstance(qp, dict) else {}
    sql = qp.get("sql") if isinstance(qp, dict) else None
    return sql if isinstance(sql, str) and sql.strip() else None


def classify_legacy_conf(feed_config: dict) -> LegacyConfSecurity:
    """Can the legacy DAG conf for this feed be shipped SECURED?

    Pure and total: no DB, no network, no exceptions.  ``_execute_airflow``
    calls this BEFORE building the plan and logs the verdict
    unconditionally, so "this feed's fallback would refuse" is visible from
    the first submission — not discovered the day a plan build crashes.
    """
    fc = feed_config if isinstance(feed_config, dict) else {}
    unsecured: List[str] = []
    if _side_sql_text(fc, "primary") is None:
        unsecured.append("primary")
    if fc.get("secondary_connection_id") and _side_sql_text(
            fc, "secondary") is None:
        unsecured.append("secondary")
    if not unsecured:
        return LegacyConfSecurity(
            True, (),
            "every side ships as SQL text the backend wraps, substitutes "
            "and row-security rewrites before submission")
    refs = "; ".join(_side_ref_label(fc, w) for w in unsecured)
    return LegacyConfSecurity(
        False, tuple(unsecured),
        f"the legacy conf ships {len(unsecured)} side(s) as a SOURCE "
        f"REFERENCE with no SQL text — {refs}.  The detached Spark job "
        f"resolves and executes those itself, with no DB and no principal, "
        f"so no WHERE mapping and no row-security rewrite of ours can reach "
        f"them.")


#: The route an operator is told to run.  Declared once so the refusal
#: message in ``feed_engine._execute_airflow``, this module's docstring and
#: the route's own docstring cannot drift apart -- the last three copies of
#: this sentence named ``db.get_feed_configs()``, a method that does not
#: exist (it is ``list_feed_configs``), so the instruction could not be
#: followed at all.
AUDIT_ROUTE = "GET /api/feeds/legacy-fallback-security-audit"

#: Why ``_execute_airflow`` would refuse.  TWO branches refuse on a
#: source-plan crash and they are not the same finding, so an operator must
#: not have to guess which one applies:
#:
#: ``cross_source``
#:     the feed has a ``secondary_connection_id``, so the crash refuses
#:     UNCONDITIONALLY (``feed_engine.py`` ~5666) -- the legacy conf cannot
#:     express the plan's RESOLVED, row-security-rewritten secondary side,
#:     whether or not the conf happens to carry SQL text for it.  Fix: the
#:     serialization error, or the native backend.
#: ``unsecurable_sides``
#:     a side ships as a SOURCE REFERENCE with no SQL text, so the detached
#:     job resolves and executes it itself (``feed_engine.py`` ~5683).
#:     Fix: additionally available by giving the side an explicit
#:     ``query_params.sql``.
REFUSE_CROSS_SOURCE = "cross_source"
REFUSE_UNSECURABLE_SIDES = "unsecurable_sides"


def audit_legacy_fallback_security(
        feed_configs: Iterable[dict]) -> List[Dict[str, Any]]:
    """THE MIGRATION PREFLIGHT: which feeds would REFUSE if the Airflow
    source-plan build crashed, and why.

    ``_execute_airflow`` refuses rather than downgrading to a conf it
    cannot secure.  A refusal an operator meets for the first time at 2am
    is a worse outage than the one it prevents, so the same verdict is
    available AHEAD of it, over the whole feed population, from a plain
    list of feed rows::

        from core.feed.airflow_plan import audit_legacy_fallback_security
        rows = audit_legacy_fallback_security(db.list_feed_configs())

    or, without a REPL, ``GET /api/feeds/legacy-fallback-security-audit``.

    **BOTH refusal branches are reported, and they are distinguished.**
    2026-09-05: this predicted only ``classify_legacy_conf``'s verdict, and
    so under-reported the population it exists to predict.  A CROSS-SOURCE
    feed refuses on a plan crash UNCONDITIONALLY -- ``if
    feed_config.get("secondary_connection_id")`` is checked FIRST and does
    not consult the classifier at all -- so a cross-source feed carrying
    SQL text on both sides classified ``securable=True`` and produced NO
    audit row, while it would still refuse at 3am.  Every row now carries
    ``refuse_because``, one of :data:`REFUSE_CROSS_SOURCE` or
    :data:`REFUSE_UNSECURABLE_SIDES`, naming the branch the engine reaches
    FIRST; the cross branch wins when both apply, because that is the order
    ``_execute_airflow`` evaluates them in.

    Only feeds that can reach the Airflow lane are reported
    (``execution_backend`` in ``airflow``/``auto``/unset -- ``auto`` is
    included because the size router sends the BIGGEST feeds there).  Each
    row is ``{feed_id, feed_name, source_type, source_id,
    execution_backend, refuse_because, secondary_connection_id,
    unsecured_sides, reason}``.

    ``unsecured_sides`` is EMPTY on a ``cross_source`` row whose conf does
    carry SQL text on both sides -- that is not "nothing is wrong with it",
    it is "the classifier had no complaint and the feed refuses anyway",
    which is precisely the case this branch was added for; ``reason`` says
    so in words.  An EMPTY LIST of rows means no feed is affected; it does
    not mean the check could not run.
    """
    out: List[Dict[str, Any]] = []
    for fc in (feed_configs or []):
        if not isinstance(fc, dict):
            continue
        backend = str(fc.get("execution_backend") or "auto").strip().lower()
        if backend not in ("airflow", "auto", ""):
            continue
        verdict = classify_legacy_conf(fc)
        # Evaluated in _execute_airflow's OWN order: the cross-source gate
        # runs BEFORE the classifier verdict, so a cross-source feed is a
        # cross_source row even when a side is also unsecurable.  Reporting
        # it the other way round would send the operator after a
        # query_params.sql that would not lift the refusal.
        secondary = fc.get("secondary_connection_id")
        if secondary:
            reason = (
                "this feed is CROSS-SOURCE (secondary_connection_id="
                f"{secondary!r}), so a source-plan serialization crash "
                "refuses UNCONDITIONALLY: the legacy conf cannot carry the "
                "plan's resolved, row-security-rewritten secondary side, "
                "and the detached Spark job would resolve that side itself "
                "with no rewrite of ours applied.")
            if verdict.securable:
                reason += (
                    "  The conf's own sides are fine -- "
                    f"{verdict.reason} -- so giving it more SQL text will "
                    "NOT lift this refusal.  Fix: correct the "
                    "serialization error, or run this feed on the native "
                    "backend.")
            else:
                reason += f"  On top of that, {verdict.reason}"
            why = REFUSE_CROSS_SOURCE
        elif not verdict.securable:
            reason = verdict.reason
            why = REFUSE_UNSECURABLE_SIDES
        else:
            continue
        out.append({
            "feed_id": fc.get("id"),
            "feed_name": fc.get("name"),
            "source_type": fc.get("source_type"),
            "source_id": fc.get("source_id"),
            "execution_backend": backend,
            "refuse_because": why,
            "secondary_connection_id": secondary,
            "unsecured_sides": list(verdict.unsecured_sides),
            "reason": reason,
        })
    return out
