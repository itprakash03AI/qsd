"""
Step 8 — change control: git-backed, JIRA-linked feed definitions
(BRD 2026-09-02 §15, FR-GOV-01/02, FR-SEC-05).

The model (§15.2, decided — this module implements, it does not re-litigate):

    JIRA ticket        "why"      required for any change to a governed object
    git repository     "what"     the definition, as a reviewed file
    environment deploy "when"     a deploy applies definitions to an environment
    QueryStudio DB     "runtime"  rows the engine reads, stamped with commit+ticket

* git is the SOURCE OF TRUTH for PROD; DB-first in DEV — stated per
  environment via ``feed_generation.governance.git_truth_environments``.
* Export is YAML, one file per object, deterministic key order: the diff
  IS the review.  Same object, same bytes, every time — no timestamps in
  the body, sorted keys, pinned line width.
* A deploy applies definitions transactionally (ONE db-seam call owns the
  transaction) and records commit + ticket on a ``config_deployments``
  row per object — "which commit is running in prod?" is answered FROM
  THE DATABASE.
* A direct prod edit is ALLOWED (break-glass) and DETECTED: the drift
  report compares the row's current governed hash against the hash
  stamped at deploy time and reports WHAT changed.  Drift is never
  silently corrected — someone edited prod for a reason.
* JIRA binds to the CHANGE (the deploy record), never the object, and
  validates the CHANGE only — nothing on the run path imports
  ``jira_link`` and this module is never called by the run path.

Secrets (the primary threat): an export that leaks a password into a git
repository is the worst outcome of this feature.  Definitions reference
a connection; credentials live in the connection registry behind a
resolver (FR-SEC-05).  Exports STRIP credential-shaped keys entirely
(never mask — a ``***`` round-tripped back over a real stored value
would destroy it); imports REFUSE files carrying credential-shaped keys
(a secret in git means git history needs purging — say so, loudly);
drift diffs strip BOTH sides so a drift report can never leak a secret
value either.

Builds ON ``core.feed.pinning`` (canonical_definition / definition_hash)
— versioning + per-run pinning already live there and are not duplicated
here.  Deliberately no imports from feed_engine / queue_worker /
pipeline: run-path workstreams never call into this module.
"""

import copy
import logging
import re
from collections.abc import Callable
from datetime import date, datetime
from typing import Any

import yaml

from core.feed.pinning import canonical_definition, definition_hash

logger = logging.getLogger(__name__)

# ── Governed object vocabulary (BRD §15.1) ──────────────────────────────
# Runtime state (runs, claims, heartbeats, results) is NEVER governed and
# never belongs in git.
GOVERNED_OBJECT_TYPES = frozenset({
    "feed",
    "saved_query",
    "dependency_mapping",
    "delivery_endpoint",
    "partition_config",
    "calendar",
    "size_class",
    "contract_template",
})

#: Export envelope schema version — bump ONLY on an incompatible envelope
#: change; the importer refuses versions it does not know rather than
#: guessing.
SCHEMA_VERSION = 1

# ── Secret detection ────────────────────────────────────────────────────
# Mirrors api/feed_api.py's masking vocabulary (kept in parity — feed_api
# MASKS for display, governance STRIPS for export; core must not import
# from api, so the sets are declared here with the same members).
_SECRET_EXACT = frozenset({
    "password", "pwd", "secret_access_key", "aws_secret_access_key",
    "secret_key", "private_key", "passphrase", "token", "api_key",
    "sas_token", "connection_string", "access_token", "client_secret",
    "session_token", "aws_session_token",
})
# Substring matches — deliberately excludes bare "key" so identifiers like
# ``access_key_id`` / ``key_prefix`` stay exportable.
_SECRET_SUBSTR = (
    "password", "secret", "token", "passphrase", "private_key",
    "client_secret", "connection_string", "credential", "sas",
)


class GovernanceError(ValueError):
    """A refused governance operation — the message says exactly why."""


def is_secret_key(key: Any) -> bool:
    """True when ``key`` looks credential-shaped (exact or substring)."""
    if not isinstance(key, str):
        return False
    kl = key.lower()
    return kl in _SECRET_EXACT or any(s in kl for s in _SECRET_SUBSTR)


def strip_secrets(tree: Any, _path: str = "") -> tuple[Any, list[str]]:
    """Return ``(copy_without_secret_keys, removed_paths)``.

    Credential-shaped KEYS are removed entirely (with their subtrees) —
    never masked, because a placeholder written back over a stored value
    on import would destroy the real credential.  The input is never
    mutated.
    """
    removed: list[str] = []
    if isinstance(tree, dict):
        out = {}
        for k, v in tree.items():
            child_path = f"{_path}.{k}" if _path else str(k)
            if is_secret_key(k):
                removed.append(child_path)
                continue
            clean, sub = strip_secrets(v, child_path)
            out[k] = clean
            removed.extend(sub)
        return out, removed
    if isinstance(tree, list):
        out_list = []
        for i, item in enumerate(tree):
            clean, sub = strip_secrets(item, f"{_path}[{i}]")
            out_list.append(clean)
            removed.extend(sub)
        return out_list, removed
    return copy.deepcopy(tree), removed


def find_secret_paths(tree: Any, _path: str = "") -> list[str]:
    """Dotted paths of every credential-shaped key in ``tree`` (any value,
    even empty — a secret KEY in a reviewed file is already wrong)."""
    _, removed = strip_secrets(tree, _path)
    return removed


# ── Deterministic serialization ─────────────────────────────────────────

def _normalize(value: Any) -> Any:
    """Make a definition YAML-stable: datetimes → ISO strings, tuples/sets
    → lists (sets sorted — set iteration order is not deterministic).
    Dict key ORDER is left to the dumper (sort_keys=True)."""
    if isinstance(value, dict):
        return {str(k): _normalize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_normalize(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted(_normalize(v) for v in value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def governed_definition(obj: dict[str, Any]) -> dict[str, Any]:
    """The governed (exportable/comparable) form of a runtime row:
    pinning's canonical subset (volatile/runtime keys stripped), secrets
    stripped, scalars normalized.  This is the ONE shape both export and
    drift comparison use — a definition compared in one shape and
    exported in another would report phantom drift."""
    clean, removed = strip_secrets(canonical_definition(obj))
    if removed:
        logger.warning(
            "[governance] definition %r carries credential-shaped keys %s — "
            "stripped from the governed form (FR-SEC-05: credentials belong "
            "in the connection registry, never in a definition)",
            (obj or {}).get("name"), removed)
    return _normalize(clean)


def governed_hash(obj: dict[str, Any]) -> str:
    """Content hash of the GOVERNED form (secret-stripped, normalized) —
    comparable between a git file and a DB row.  Reuses pinning's hash so
    there is exactly one hashing spelling in the platform."""
    return definition_hash(governed_definition(obj))


def export_definition(obj: dict[str, Any], *, object_type: str) -> str:
    """One governed object → deterministic YAML text (same object, same
    bytes, every time).  No timestamps in the body: ``created_at`` /
    ``updated_at`` are volatile keys pinning already strips."""
    if object_type not in GOVERNED_OBJECT_TYPES:
        raise GovernanceError(
            f"unknown governed object type {object_type!r} — one of "
            f"{sorted(GOVERNED_OBJECT_TYPES)}")
    definition = governed_definition(obj)
    envelope = {
        "kind": object_type,
        "name": (obj or {}).get("name"),
        "schema_version": SCHEMA_VERSION,
        "definition": definition,
    }
    return yaml.safe_dump(
        envelope,
        sort_keys=True,           # deterministic key order — the diff IS the review
        default_flow_style=False, # block style: one field per line, reviewable
        allow_unicode=True,       # no \uXXXX noise diffs on accented names
        width=100,                # pinned — the library default must not move our bytes
    )


def export_bytes(obj: dict[str, Any], *, object_type: str) -> bytes:
    """Exported file bytes (UTF-8, LF — git-canonical)."""
    return export_definition(obj, object_type=object_type).encode("utf-8")


_SLUG_RE = re.compile(r"[^A-Za-z0-9._-]+")


def export_filename(object_type: str, name: str) -> str:
    """One file per object: ``<object_type>/<name>.yaml`` with the name
    slugged to filesystem-safe chars.  §14.3 makes the feed name unique
    per environment, so the filename is stable and unique."""
    slug = _SLUG_RE.sub("_", str(name or "")).strip("_")
    if not slug:
        raise GovernanceError(
            f"cannot derive an export filename from name {name!r}")
    return f"{object_type}/{slug}.yaml"


def import_definition(text: str) -> dict[str, Any]:
    """Parse + validate one exported YAML file.

    Returns ``{"object_type", "name", "definition", "definition_hash"}``.
    REFUSES (never repairs):
    * a non-mapping / malformed file,
    * an unknown ``kind`` or ``schema_version``,
    * a missing/empty ``name`` or non-mapping ``definition``,
    * ANY credential-shaped key in the definition — a secret in a
      reviewed file means a secret in git history; the fix is purging
      the repository, not a quiet import.
    """
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise GovernanceError(f"not valid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise GovernanceError(
            "a governed definition file must be a YAML mapping "
            f"(got {type(data).__name__})")
    kind = data.get("kind")
    if kind not in GOVERNED_OBJECT_TYPES:
        raise GovernanceError(
            f"unknown kind {kind!r} — one of {sorted(GOVERNED_OBJECT_TYPES)}")
    sv = data.get("schema_version")
    if sv != SCHEMA_VERSION:
        raise GovernanceError(
            f"unsupported schema_version {sv!r} (this build understands "
            f"{SCHEMA_VERSION})")
    name = data.get("name")
    if not isinstance(name, str) or not name.strip():
        raise GovernanceError("definition file has no usable 'name'")
    definition = data.get("definition")
    if not isinstance(definition, dict):
        raise GovernanceError("'definition' must be a mapping")
    secret_paths = find_secret_paths(definition)
    if secret_paths:
        raise GovernanceError(
            "REFUSED: credential-shaped keys in a definition file: "
            f"{secret_paths} — credentials live in the connection registry "
            "(FR-SEC-05); a secret committed to git requires purging the "
            "repository history, not importing the file")
    definition = _normalize(definition)
    return {
        "object_type": kind,
        "name": name,
        "definition": definition,
        "definition_hash": definition_hash(definition),
    }


# ── Drift (§15.2: detected and reported, NEVER silently corrected) ──────

def _flat_diff(deployed: Any, current: Any, path: str = "") -> list[dict]:
    """Dotted-path field diff.  Both inputs must already be governed
    (secret-stripped) forms — this function never re-strips, so callers
    own that invariant (both call sites do)."""
    if isinstance(deployed, dict) and isinstance(current, dict):
        out: list[dict] = []
        for k in sorted(set(deployed) | set(current)):
            child = f"{path}.{k}" if path else str(k)
            if k not in current:
                out.append({"path": child, "change": "removed",
                            "deployed": deployed[k], "current": None})
            elif k not in deployed:
                out.append({"path": child, "change": "added",
                            "deployed": None, "current": current[k]})
            else:
                out.extend(_flat_diff(deployed[k], current[k], child))
        return out
    if deployed != current:
        return [{"path": path or "<root>", "change": "changed",
                 "deployed": deployed, "current": current}]
    return []


def compute_drift(deployed_definition: dict[str, Any],
                  current_row: dict[str, Any]) -> dict[str, Any]:
    """Compare the definition stamped at deploy time against the row as
    it is NOW.  Returns ``{"drifted": bool, "changes": [...]}`` with
    per-field deployed/current values.  Secrets are stripped from BOTH
    sides before diffing so a drift report can never leak a credential
    value.  Detection only — nothing is written back."""
    deployed = _normalize(strip_secrets(deployed_definition or {})[0])
    current = governed_definition(current_row or {})
    changes = _flat_diff(deployed, current)
    return {"drifted": bool(changes), "changes": changes}


def drift_report(db, *, environment: str,
                 alarm_fn: Callable[[dict], Any] | None = None,
                 ) -> dict[str, Any]:
    """Full drift report for one environment, answerable FROM THE
    DATABASE (no git access needed at report time — the deploy snapshot
    on ``config_deployments`` is the comparison baseline).

    Statuses per object:
    * ``in_sync``   — current governed hash == hash stamped at deploy;
    * ``drifted``   — a break-glass/direct edit happened; ``changes``
      says exactly what moved.  Reported + alarmed, never corrected;
    * ``deleted``   — deployed object no longer present in the DB;
    * ``unmanaged`` — a DB object with NO deploy record, reported only
      when ``environment`` is a git-truth environment (DB-first in DEV
      is legitimate; in PROD an undeployed object IS drift).

    ``alarm_fn`` is an injected seam (Netcool etc.) called once per
    drifted/deleted/unmanaged entry; an alarm failure is logged at ERROR
    and never kills the report (fail-open, but loud).
    """
    from core import config as _config  # late import: config is heavyweight
    gov = _config.get("feed_generation", "governance", {}) or {}
    git_truth = gov.get("git_truth_environments", ["prod"]) or []

    deployments = db.get_latest_deployments(environment) or []
    entries: list[dict[str, Any]] = []
    deployed_ids: set[tuple[str, Any]] = set()
    for dep in deployments:
        otype, oid = dep.get("object_type"), dep.get("object_id")
        deployed_ids.add((otype, oid))
        row = db.get_governed_object(otype, oid)
        entry: dict[str, Any] = {
            "object_type": otype,
            "object_id": oid,
            "name": dep.get("name"),
            "git_commit": dep.get("git_commit"),
            "jira_ticket": dep.get("jira_ticket"),
            "deployed_at": dep.get("deployed_at"),
        }
        if row is None:
            entry["status"] = "deleted"
            entry["changes"] = []
        else:
            current_hash = governed_hash(row)
            if current_hash == dep.get("definition_hash"):
                entry["status"] = "in_sync"
            else:
                entry["status"] = "drifted"
                entry["changes"] = compute_drift(
                    dep.get("definition") or {}, row)["changes"]
        entries.append(entry)

    if environment in git_truth:
        for otype in sorted(GOVERNED_OBJECT_TYPES):
            for row in (db.list_governed_objects(otype) or []):
                key = (otype, row.get("id"))
                if key not in deployed_ids:
                    entries.append({
                        "object_type": otype,
                        "object_id": row.get("id"),
                        "name": row.get("name"),
                        "status": "unmanaged",
                        "changes": [],
                    })

    flagged = [e for e in entries if e["status"] != "in_sync"]
    for entry in flagged:
        # Persist the drift MARK when the seam offers it (detection is
        # a report + a flag — never a corrective write to the definition).
        mark = getattr(db, "mark_config_drift", None)
        if callable(mark):
            try:
                mark(entry["object_type"], entry["object_id"],
                     drifted=True, details=entry.get("changes") or [])
            except Exception:
                logger.exception("[governance] could not persist drift mark "
                                 "for %s/%s", entry["object_type"],
                                 entry["object_id"])
        if alarm_fn is not None:
            try:
                alarm_fn(entry)
            except Exception:
                logger.exception("[governance] drift alarm failed for %s/%s "
                                 "(report continues)", entry["object_type"],
                                 entry["object_id"])
        logger.warning(
            "[governance] drift: %s %s/%s (%r) — %d field(s) differ from "
            "deployed commit %s", entry["status"], entry["object_type"],
            entry["object_id"], entry.get("name"),
            len(entry.get("changes") or []), entry.get("git_commit"))

    return {
        "environment": environment,
        "checked": len(entries),
        "in_sync": sum(1 for e in entries if e["status"] == "in_sync"),
        "drifted": [e for e in entries if e["status"] == "drifted"],
        "deleted": [e for e in entries if e["status"] == "deleted"],
        "unmanaged": [e for e in entries if e["status"] == "unmanaged"],
    }


# ── Deploy (§15.2: transactional, records commit on every row touched) ──

def plan_deploy(files: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Parse + validate EVERY file before anything is applied
    (all-or-nothing starts at validation).  ``files`` is
    ``[{"path", "content"}, ...]``; any bad file refuses the whole
    deploy with its path named."""
    if not files:
        raise GovernanceError("deploy carries no definition files")
    items: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for f in files:
        path = (f or {}).get("path") or "<unnamed>"
        try:
            item = import_definition((f or {}).get("content") or "")
        except GovernanceError as exc:
            raise GovernanceError(f"{path}: {exc}") from exc
        key = (item["object_type"], item["name"])
        if key in seen:
            raise GovernanceError(
                f"{path}: duplicate object {key[0]}/{key[1]} in one deploy")
        seen.add(key)
        item["path"] = path
        items.append(item)
    return items


def apply_deploy(db, *, environment: str, commit: str,
                 ticket: str | None, deployed_by: str | None,
                 files: list[dict[str, Any]],
                 validate_ticket_fn: Callable[..., dict] | None = None,
                 ) -> dict[str, Any]:
    """Apply a reviewed set of definition files to one environment.

    * JIRA binds to THIS CHANGE: the ticket is validated (change path —
      the only place JIRA is consulted) and recorded on the deploy rows.
      An invalid ticket refuses the deploy; a JIRA OUTAGE follows
      ``governance.jira.outage_policy`` (default ``allow`` — a tracker
      outage must not become a platform availability risk) and the
      validation outcome is recorded on the result either way.
    * The whole apply is ONE db-seam call (``db.apply_config_deploy``)
      so the mixin owns a single transaction: every row stamped with
      ``commit`` + ``ticket``, one ``config_deployments`` row per object
      carrying the definition snapshot — or nothing at all.
    """
    if not commit or not str(commit).strip():
        raise GovernanceError(
            "a deploy must name the git commit it applies — 'which commit "
            "is running in prod?' must be answerable from the database")

    ticket_validation: dict[str, Any] = {"outcome": "skipped"}
    if validate_ticket_fn is None:
        # Change path — jira_link is imported HERE, never at module import
        # time and never anywhere the run path reaches.
        from core.feed.jira_link import gate_change, validate_ticket
        ticket_validation = validate_ticket(ticket)
        allowed, reason = gate_change(ticket_validation)
    else:
        ticket_validation = validate_ticket_fn(ticket)
        from core.feed.jira_link import gate_change
        allowed, reason = gate_change(ticket_validation)
    if not allowed:
        raise GovernanceError(f"deploy refused: {reason}")

    items = plan_deploy(files)
    applied = db.apply_config_deploy(
        environment=environment,
        commit=str(commit),
        ticket=ticket,
        deployed_by=deployed_by,
        items=items,
    )
    logger.info(
        "[governance] deployed %d object(s) to %s at commit %s "
        "(ticket %s, by %s)", len(items), environment, commit, ticket,
        deployed_by)
    return {
        "environment": environment,
        "commit": str(commit),
        "ticket": ticket,
        "ticket_validation": ticket_validation,
        "deployed_by": deployed_by,
        "objects": applied,
        "count": len(items),
    }
