"""The bridge from the engine's stages to real per-step rows.

``core/feed_engine.py`` keeps doing exactly what it does.  Where it
called ``_enter_stage`` / ``_exit_stage`` and wrote a duration into a
dict, it now ALSO tells this recorder, and the recorder:

* flips the planned row for that stage (``running`` -> ``completed``),
  with real wall-clock boundaries and the pod that ran it;
* publishes the artifacts that stage produced into the run's artifact
  map;
* drives any RUNNER steps that just became ready — which is what puts a
  dropped-in step at its declared position without the engine knowing it
  exists.

FAIL-OPEN, ONCE, AND IT SAYS SO
--------------------------------
Bookkeeping must not kill a run.  Every public method here swallows its
own exceptions and logs at ERROR — with ONE exception, which is the
whole design: :meth:`after_stage` re-raises
:class:`~core.feed.step_model.runner.StepExecutionHalted`.  A quality gate
that refused must stop the feed; swallowing that would turn a correctness
gate into a cap, and this codebase has shipped that mistake before.

So: a broken RECORDER is invisible to the run.  A broken STEP is not.

DEGRADED IS NAMED, NOT SILENT
------------------------------
``self.degraded`` carries the reason the recorder gave up, and the engine
puts it on the run.  "No steps were recorded" and "this run had no steps"
are opposite findings, and a null timeline with no explanation is how the
last one of these went unnoticed for three weeks.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Mapping, Optional

from core.feed.step_model import runner as _runner
from core.feed.step_model.registry import get_registry
from core.feed.step_model.store import (
    begin_attempt,
    close_unfulfilled,
    create_planned_steps,
    open_new_attempt,
    finish_attempt,
)

logger = logging.getLogger(__name__)


class StepPlanRefused(RuntimeError):
    """The plan could not be built for a feed that DECLARED steps.

    Raised before any work, which is the point: OG's ``run_id=969000``
    fell through to the wrong workflow and died at execute time with
    "Unsupported step name", having already burned its failure budget on
    a route that could never have worked.  Resolve the whole sequence
    first; a refusal then costs only the admission.

    Only raised when the feed is MAPPED TO A FLOW with runner steps.  A
    feed that declared nothing gets its refusal recorded and its run
    proceeds — refusing to draw a timeline is not a reason to stop
    delivering a file.  A cap throttles; a gate fails; this is the line
    between them.
    """


class StepRecorder:
    """One per feed execution.  Cheap to construct, safe to ignore."""

    def __init__(self, db_manager, *, feed_config: Mapping[str, Any],
                 feed_run: Optional[Mapping[str, Any]],
                 plan, execution_id: str = "", registry=None) -> None:
        self._db = db_manager
        self._feed_config = dict(feed_config or {})
        self._feed_run = dict(feed_run or {})
        self._plan = plan
        self._execution_id = execution_id
        self._registry = registry or get_registry()
        self._run_id = self._feed_run.get("id")
        self.artifacts: Dict[str, Any] = {}
        self.statuses: Dict[str, str] = {
            s.alias: "not_started" for s in (plan.steps if plan else ())}
        self._open: Dict[str, int] = {}          # alias -> row id
        self.degraded: Optional[str] = None
        self.active = bool(self._run_id) and bool(plan) and bool(plan.steps)
        if plan is not None and plan.refusals:
            self.degraded = "; ".join(plan.refusals)
            self.active = False

    # ── plan materialisation ──────────────────────────────────────────

    def ensure_rows(self) -> None:
        """Write the plan's rows if SOD did not (a manually triggered
        run, a legacy row, a feed created after today's SOD ran) -- and
        when the rows are there but already SPENT by an earlier
        execution of this run, open a fresh attempt for every step so
        this execution records onto its own rows (2026-09-14; see
        ``store.open_new_attempt``)."""
        if not self.active:
            return
        try:
            created = create_planned_steps(
                self._db, self._feed_run, self._plan,
                execution_id=self._execution_id)
            if created == 0:
                attempt = open_new_attempt(
                    self._db, int(self._run_id),
                    execution_id=self._execution_id)
                if attempt is not None:
                    logger.info(
                        "[feed_steps] run %s executed again as %s -- "
                        "recording attempt %d on fresh rows",
                        self._run_id, self._execution_id or "?", attempt)
        except Exception as exc:                   # noqa: BLE001
            self._give_up("planned step rows could not be written", exc)

    # ── the engine's stage boundaries ─────────────────────────────────

    def _class_for(self, step):
        """The step CLASS behind a planned step — off the manifest when the
        service put it there, else resolved once from the registry."""
        cls = (step.manifest or {}).get("_class")
        if cls is None:
            try:
                cls = type(self._registry.resolve(step.step_type))
            except Exception:                      # noqa: BLE001
                return None
        return cls

    def _match(self, stage_name: str):
        """The planned step this engine stage fulfils, or None.

        None is legitimate and common: the engine enters stages that no
        step declares (a warning stage, a measurement).  Recording them
        as ad-hoc rows would put things in the timeline that the plan
        never promised, which is how a step list stops being readable.
        """
        for step in self._plan.steps:
            if step.executor != "engine":
                continue
            cls = (step.manifest or {}).get("_class")
            if cls is None:
                try:
                    cls = type(self._registry.resolve(step.step_type))
                except Exception:                  # noqa: BLE001
                    continue
            try:
                if cls.matches_engine_stage(stage_name):
                    return step
            except Exception:                      # noqa: BLE001
                continue
        return None

    def enter(self, stage_name: str) -> None:
        if not self.active:
            return
        try:
            step = self._match(stage_name)
            if step is None or step.alias in self._open:
                return
            row_id = begin_attempt(
                self._db, int(self._run_id), step.alias,
                params=step.stored_params,
                execution_id=self._execution_id,
                rows_in=self.artifacts.get("row_count"))
            if row_id is not None:
                self._open[step.alias] = row_id
                self.statuses[step.alias] = "running"
        except Exception as exc:                   # noqa: BLE001
            self._give_up(f"could not open the row for stage "
                          f"'{stage_name}'", exc)

    def exit(self, stage_name: str, seconds: Optional[float] = None, *,
             rows_out: Optional[int] = None,
             artifacts: Optional[Mapping[str, Any]] = None) -> None:
        """Close the row for *stage_name* and publish what it produced.

        Does NOT drive the runner — :meth:`after_stage` does, because
        driving is ``async`` and this is called from the engine's sync
        stage helper.  Splitting them means a recording still happens
        even where the engine has no ``await`` to give.
        """
        if not self.active:
            return
        try:
            if artifacts:
                self.publish(**artifacts)
            step = self._match(stage_name)
            if step is None:
                return
            row_id = self._open.pop(step.alias, None)
            if row_id is None:
                return
            declared = list((step.manifest or {}).get("produces") or [])
            # A CONTROL step's artifacts are MARKERS — the stage having
            # closed IS the artifact — and the engine never publishes
            # them, so they are published here or nowhere.  Anything
            # else is published by the engine with a real value, or not
            # at all (see ``FeedPipelineStep.marker_artifacts``).
            cls = self._class_for(step)
            for kind in (cls.marker_artifacts() if cls is not None else ()):
                if kind not in self.artifacts:
                    self.publish(**{kind: stage_name})
            resolved_rows = rows_out
            if resolved_rows is None and "row_count" in declared:
                resolved_rows = self.artifacts.get("row_count")
            finish_attempt(
                self._db, row_id, "completed", rows_out=resolved_rows,
                outputs={k: str(self.artifacts[k]) for k in declared
                         if k in self.artifacts},
                duration_seconds=seconds)
            self.statuses[step.alias] = "completed"
        except Exception as exc:                   # noqa: BLE001
            self._give_up(f"could not close the row for stage "
                          f"'{stage_name}'", exc)

    async def after_stage(self, stage_name: str) -> None:
        """Run the steps that just became ready.

        RE-RAISES :class:`~core.feed.step_model.runner.StepExecutionHalted`
        — a gate that refused must stop the feed.  Everything else is
        swallowed: a recorder that cannot record must not be the reason a
        file is not delivered.
        """
        if not self.active:
            return
        try:
            await _runner.drive(
                self._db, feed_run_id=int(self._run_id),
                planned=self._plan.steps, statuses=self.statuses,
                artifacts=self.artifacts, feed_config=self._feed_config,
                feed_run=self._feed_run, execution_id=self._execution_id,
                registry=self._registry)
        except _runner.StepExecutionHalted:
            raise
        except Exception as exc:                   # noqa: BLE001
            self._give_up(f"the step runner failed after stage "
                          f"'{stage_name}'", exc)

    def fail(self, stage_name: str, error: str) -> None:
        """The run broke inside this stage."""
        if not self.active:
            return
        try:
            step = self._match(stage_name)
            if step is None:
                return
            row_id = self._open.pop(step.alias, None)
            if row_id is None:
                row_id = begin_attempt(
                    self._db, int(self._run_id), step.alias,
                    execution_id=self._execution_id)
            if row_id is not None:
                finish_attempt(self._db, row_id, "failed", error=error)
                self.statuses[step.alias] = "failed"
        except Exception as exc:                   # noqa: BLE001
            self._give_up(f"could not record the failure of stage "
                          f"'{stage_name}'", exc)

    def finalize(self, run_status: str, *, reason: str = "") -> None:
        """Close every step that never started.

        A row left at ``not_started`` forever reads as a hung step, and
        an operator cannot tell that from one the engine simply did not
        enter — the engine's stage list is genuinely dynamic.
        """
        if not self.active:
            return
        try:
            close_unfulfilled(
                self._db, int(self._run_id), terminal_status="skipped",
                reason=reason or (
                    "the engine did not enter this stage on this run"
                    if run_status == "completed" else
                    f"the run ended '{run_status}' before this step started"),
                # A runner step that never ran was waiting on SOMETHING,
                # and that something is knowable right now.  Writing it
                # onto the row is the difference between "this step did
                # not run" and "this step did not run because the extract
                # was skipped, so its input was never produced".
                reasons={b["alias"]: b["reason"] for b in self.blocked()})
        except Exception as exc:                   # noqa: BLE001
            self._give_up("could not close the unfulfilled step rows", exc)

    # ── artifacts ─────────────────────────────────────────────────────

    def publish(self, **artifacts: Any) -> None:
        """Record what the run has produced so far.

        Values of ``None`` are DROPPED rather than stored: an artifact
        present with a null value would satisfy the runner's readiness
        check and then blow up inside the step.  "Not produced" and
        "produced as nothing" are different, and only the first is a
        state the graph understands.
        """
        for kind, value in artifacts.items():
            if value is None:
                continue
            self.artifacts[str(kind)] = value

    def blocked(self) -> List[Dict[str, str]]:
        """Every runner step that has not run, and WHY.

        Read by :meth:`finalize`, which writes each reason onto that
        step's own row.  The system logs what it did and never what it
        declined to do; this is the answer to that for a step that never
        got to run, and it lands in the record rather than in somebody's
        head.
        """
        out: List[Dict[str, str]] = []
        for step in (self._plan.steps if self._plan else ()):
            if step.executor != "runner":
                continue
            if self.statuses.get(step.alias) != "not_started":
                continue
            reason = _runner.blocked_reason(step, self.statuses,
                                            self.artifacts)
            if reason:
                out.append({"alias": step.alias, "reason": reason})
        return out

    # ── degradation ───────────────────────────────────────────────────

    def _give_up(self, what: str, exc: BaseException) -> None:
        self.active = False
        self.degraded = f"{what}: {type(exc).__name__}: {exc}"
        logger.error(
            "[feed-pipeline] step recording DISABLED for this run — %s. "
            "The feed continues; the timeline for this run will be "
            "incomplete, and that is recorded on the run rather than "
            "left to look like a feed with no steps",
            self.degraded, exc_info=True)


def build_recorder(db_manager, *, feed_config: Mapping[str, Any],
                   feed_run: Optional[Mapping[str, Any]],
                   execution_id: str = "",
                   calendar=None) -> StepRecorder:
    """Plan this run and return its recorder.  Never raises.

    A feed with no flow still gets a recorder — it records the ENGINE
    SPINE, which is the whole point of the migration story: every feed
    that exists today gains the per-step screen without declaring
    anything and without a single behaviour change.

    Raises :class:`StepPlanRefused` — and ONLY that — when the feed IS
    mapped to a flow whose plan refuses.
    """
    plan = None
    try:
        from core.feed.step_model.service import plan_for_feed
        plan = plan_for_feed(db_manager, feed_config, feed_run,
                             calendar=calendar)
    except Exception as exc:                       # noqa: BLE001
        logger.error("[feed-pipeline] planning failed for feed %s: %s",
                     (feed_config or {}).get("id"), exc, exc_info=True)
    if plan is not None and plan.is_fatal:
        raise StepPlanRefused(
            "this feed is mapped to a step flow and the plan REFUSES: "
            + "; ".join(plan.refusals))
    rec = StepRecorder(db_manager, feed_config=feed_config,
                       feed_run=feed_run, plan=plan,
                       execution_id=execution_id)
    if plan is None:
        rec.degraded = ("the step plan could not be built; this run "
                        "records no steps")
    rec.ensure_rows()
    return rec


__all__ = ["StepPlanRefused", "StepRecorder", "build_recorder"]
