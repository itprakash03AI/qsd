"""The run PROFILE — the declarative facts a step's predicate reads.

A profile is what the planner matches ``APPLIES_WHEN`` against.  It is a
FLAT dict of scalars, deliberately: a predicate has to be JSON so a
database-registered plugin can carry it, and a JSON predicate cannot walk
an object graph.

THIS MODULE CONSUMES DECISIONS; IT DOES NOT MAKE THEM
------------------------------------------------------
The lane comes from ``core/feed/backend_router.pick_backend`` — the
size-based router with its capability floors — not from a size
comparison written again here.  The calendar tokens come from
``core/feed/param_resolver.resolve_feed_params``.  The contract terms are
read off the feed row's own ``output_options`` with the same key mapping
the authoring API uses.  A step engine that re-decides any of these is
the "a decision made twice is a bug" defect at a new layer, and the
second answer is always the one nobody notices is wrong.

UNKNOWN IS NOT FALSE
--------------------
A fact the profile could not resolve is recorded in ``unknown`` and keeps
its ``None`` value.  A predicate that reads an unknown fact REFUSES the
plan (:class:`~core.feed.step_model.contract.PredicateError`) instead of
evaluating to False.  Silently dropping a step because its scoping fact
could not be read is how a quality gate disappears on exactly the days
something is wrong — "could not read" and "has none" lead to opposite
investigations.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Dict, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

#: THE fact vocabulary.  A predicate naming anything outside this tuple is
#: refused AT REGISTRATION, not at dispatch — OG's ``run_id=969000`` died
#: with "Unsupported step name" at execute time, having already burned its
#: failure budget on a route that could never have worked.  Resolve the
#: whole thing before running.
FACT_NAMES: Tuple[str, ...] = (
    # identity
    "feed_id",
    "feed_name",
    "task_type",
    "flow_id",
    # source (property 1)
    "source_type",
    "secondary_source_type",
    "combine_mode",
    "has_secondary_source",
    "connection_id",
    # schedule (property 2)
    "calendar_name",
    "schedule_kind",
    "frequency_category",
    # dependencies (property 3)
    "has_dependencies",
    # shape (property 4)
    "has_partition_shape",
    # contract (property 5)
    "output_format",
    "codec",
    "packaging",
    "encryption",
    "checksum_algorithm",
    "has_checksum",
    "has_control_file",
    "sequencing",
    # delivery (property 6)
    "destination_type",
    "delivery_hop_count",
    "has_delivery_chain",
    "suppress_delivery",
    # controls
    "row_count_action",
    "integrity_check_enabled",
    # derived by other subsystems, CONSUMED here
    "lane",
    # run-scoped
    "run_type",
    "business_date",
    "is_backfill",
)

#: Read off ``output_options`` with the mapping the authoring API uses.
#: Duplicated spellings (``compression`` / ``codec``) are the author's,
#: not ours -- both already exist in stored configs.
_OPTION_FACTS = {
    "compression": "codec",
    "codec": "codec",
    "packaging": "packaging",
    "encryption": "encryption",
    "checksum": "checksum_algorithm",
    "checksum_algorithm": "checksum_algorithm",
    "sequencing": "sequencing",
}


@dataclass(frozen=True)
class FeedProfile:
    """The six properties, flattened, plus what other subsystems decided.

    ``unknown`` names the facts whose value could NOT be resolved.  It is
    a separate set rather than a sentinel value because ``None`` is a
    legitimate value for several facts (no secondary source, no codec)
    and conflating "none declared" with "could not read" is precisely
    the confusion this codebase keeps paying for.
    """
    facts: Dict[str, Any]
    unknown: Tuple[str, ...] = ()
    notes: Tuple[str, ...] = field(default=())

    def __post_init__(self) -> None:
        missing = sorted(set(FACT_NAMES) - set(self.facts))
        if missing:
            raise ValueError(
                f"profile is missing fact(s) {missing} — every fact in "
                f"FACT_NAMES must be present (with None when absent) so a "
                f"predicate reading it gets a value or a stated 'unknown', "
                f"never a KeyError at 03:00")
        extra = sorted(set(self.facts) - set(FACT_NAMES))
        if extra:
            raise ValueError(
                f"profile carries undeclared fact(s) {extra} — a fact no "
                f"predicate can be validated against is a fact no author "
                f"can safely use")

    def get(self, name: str, default: Any = None) -> Any:
        return self.facts.get(name, default)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "facts": dict(self.facts),
            "unknown": list(self.unknown),
            "notes": list(self.notes),
        }


def _lane(feed_config: Mapping[str, Any],
          lane_resolver=None) -> Tuple[Optional[str], Optional[str]]:
    """The execution lane, CONSUMED from the router.  ``(lane, note)``.

    Returns ``(None, reason)`` when the router cannot answer.  It is
    deliberately not defaulted to ``'native'``: a guessed lane that
    happens to be right most of the time is exactly the shape that makes
    the wrong case invisible.
    """
    declared = (feed_config.get("execution_backend") or "auto").strip().lower()
    if declared and declared not in ("auto", ""):
        # The author pinned it.  No routing decision to consume.
        return declared, None
    try:
        if lane_resolver is None:
            from core.feed.backend_router import pick_backend as lane_resolver  # noqa: N806
        choice = lane_resolver(feed_config)
        lane = getattr(choice, "backend", None) or (
            choice.get("backend") if isinstance(choice, Mapping) else None)
        if lane:
            return str(lane), None
        return None, "router returned no backend"
    except Exception as exc:                       # noqa: BLE001
        return None, f"router unavailable ({type(exc).__name__}: {exc})"


def build_profile(feed_config: Mapping[str, Any],
                  feed_run: Optional[Mapping[str, Any]] = None,
                  *, lane_resolver=None) -> FeedProfile:
    """Flatten one feed (and optionally one run) into its profile.

    ``feed_run`` may be None — the feed's plan is answerable BEFORE any
    run exists, which is what makes "show me what will run tonight" a
    read rather than a feature.
    """
    fc = dict(feed_config or {})
    fr = dict(feed_run or {})
    opts = fc.get("output_options") or {}
    if not isinstance(opts, Mapping):
        opts = {}

    facts: Dict[str, Any] = {name: None for name in FACT_NAMES}
    unknown: list = []
    notes: list = []

    facts["feed_id"] = fc.get("id")
    facts["feed_name"] = fc.get("name")
    facts["task_type"] = fc.get("task_type") or "file_feed"
    facts["flow_id"] = fc.get("flow_id")

    facts["source_type"] = fc.get("source_type")
    facts["secondary_source_type"] = fc.get("secondary_source_type")
    facts["combine_mode"] = fc.get("combine_mode")
    facts["has_secondary_source"] = bool(fc.get("secondary_connection_id"))
    facts["connection_id"] = fc.get("connection_id")

    facts["calendar_name"] = fc.get("calendar_name")
    _decl = fc.get("schedule_declaration") or {}
    facts["schedule_kind"] = (
        _decl.get("kind") if isinstance(_decl, Mapping) else None
    ) or ("cron" if fc.get("cron_expression") else None)
    facts["frequency_category"] = fc.get("frequency_category")

    facts["has_dependencies"] = fc.get("etl_id") is not None

    _shape = fc.get("partition_config") or fc.get("partition_columns")
    facts["has_partition_shape"] = bool(_shape)

    facts["output_format"] = (fc.get("output_format") or "csv").lower()
    for opt_key, fact_name in _OPTION_FACTS.items():
        val = opts.get(opt_key)
        if val is not None and facts.get(fact_name) is None:
            facts[fact_name] = val
    facts["codec"] = (facts["codec"] or "none")
    facts["packaging"] = (facts["packaging"] or "none")
    facts["encryption"] = (facts["encryption"] or "none")
    facts["has_checksum"] = bool(facts["checksum_algorithm"])
    facts["sequencing"] = facts["sequencing"] or "none"
    facts["has_control_file"] = bool(
        fc.get("control_file_template") or fc.get("control_file_format_id"))

    facts["destination_type"] = (fc.get("destination_type") or "local").lower()
    chain = fc.get("delivery_chain")
    facts["has_delivery_chain"] = bool(chain)
    facts["delivery_hop_count"] = (
        len(chain) if isinstance(chain, (list, tuple)) else (1 if chain else 1))
    facts["suppress_delivery"] = bool(fr.get("suppress_delivery"))

    facts["row_count_action"] = (fc.get("row_count_action") or "warn").lower()
    facts["integrity_check_enabled"] = bool(fc.get("integrity_check_enabled"))

    lane, lane_note = _lane(fc, lane_resolver)
    facts["lane"] = lane
    if lane is None:
        unknown.append("lane")
        notes.append(f"lane unknown: {lane_note}")

    facts["run_type"] = fr.get("run_type") or "scheduled"
    facts["is_backfill"] = (facts["run_type"] == "backfill")
    bd = fr.get("business_date")
    facts["business_date"] = bd.isoformat() if isinstance(bd, date) else (
        str(bd) if bd else None)
    if feed_run is not None and facts["business_date"] is None:
        unknown.append("business_date")
        notes.append("business_date unknown: the run row carries none")

    return FeedProfile(facts=facts, unknown=tuple(unknown), notes=tuple(notes))


def resolve_step_params(step_params: Optional[Mapping[str, Any]],
                        feed_config: Mapping[str, Any],
                        feed_run: Optional[Mapping[str, Any]] = None,
                        calendar=None) -> Dict[str, Any]:
    """Resolve ``{{calendar_token}}`` inside a step's own parameters.

    Uses ``core/feed/param_resolver.resolve_feed_params`` — THE feed
    calendar vocabulary, the same one feed SQL substitutes against.  It
    is called, not copied: a second copy would answer
    ``{{prev_business_day}}`` differently the first time a holiday
    calendar changed, and the two answers would both look right.

    Only string values are substituted, and only whole ``{{token}}``
    fragments.  An unknown token is LEFT AS IT IS rather than blanked —
    a parameter that silently became an empty string is a path that
    silently became the wrong path.
    """
    import re

    params = dict(step_params or {})
    if not params:
        return params
    try:
        from core.feed.param_resolver import resolve_feed_params
        tokens = resolve_feed_params(dict(feed_config or {}),
                                     dict(feed_run or {}), calendar)
    except Exception as exc:                       # noqa: BLE001
        logger.warning(
            "[feed-pipeline] calendar token resolution unavailable (%s: %s) "
            "— step parameters keep their literal values, tokens included",
            type(exc).__name__, exc)
        return params

    pattern = re.compile(r"\{\{(\w+)\}\}")

    def _sub(value: Any) -> Any:
        if not isinstance(value, str) or "{{" not in value:
            return value
        return pattern.sub(
            lambda m: str(tokens[m.group(1)]) if m.group(1) in tokens
            else m.group(0), value)

    return {k: _sub(v) for k, v in params.items()}


def mask_params(params: Optional[Mapping[str, Any]],
                config_schema: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """The stored copy of a step's resolved parameters, secrets masked.

    A parameter declared ``"type": "secret"`` is replaced with
    ``"***"``.  The record has to say WHAT the step ran with — a value
    resolved for a decision and then thrown away disagrees with what the
    system did — and it must not become a place credentials accumulate.
    """
    schema = config_schema or {}
    out: Dict[str, Any] = {}
    for key, value in (params or {}).items():
        decl = schema.get(key) if isinstance(schema, Mapping) else None
        is_secret = isinstance(decl, Mapping) and decl.get("type") == "secret"
        out[key] = "***" if (is_secret and value is not None) else value
    return out


__all__ = [
    "FACT_NAMES",
    "FeedProfile",
    "build_profile",
    "mask_params",
    "resolve_step_params",
]
