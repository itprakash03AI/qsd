"""Where steps come from: a folder, and a database row.

Two paths, one registry:

* **built-in / dropped-in** — a ``FeedPipelineStep`` subclass in
  ``core/feed/step_model/steps/``.  Discovery imports the package and takes
  every subclass with a ``NAME``.  "create new class as steps n drop in
  steps folder n register."
* **plugin** — a row in ``feed_custom_step_types`` naming a module and a
  class.  The registry importlib's it at boot.  "if new workflow
  comes .... we just need to install plugin etc."  No engine change, no
  redeploy of this codebase, and the step's ``config_schema`` renders its
  own parameter form so the UI needs no deploy either.

THREE OUTCOMES, NEVER TWO
--------------------------
``resolve(name)`` answers with the step, or raises one of two DIFFERENT
exception types:

* :class:`UnknownFeedStep` — nothing answers to that name (the message
  lists what does);
* :class:`FeedStepLoadFailed` — a step with that name EXISTS and failed
  to import, naming the module and the reason.

They lead to opposite investigations, so they are never the same
exception.  The OG ETL caught an ImportError, WARNed and SKIPPED, so a
missing module surfaced at dispatch as "Unsupported step name" and
pointed the operator at the config row instead of the broken file.

A FAILED PLUGIN LOAD IS A TOMBSTONE, NOT A SILENCE
----------------------------------------------------
Boot never fails on a bad plugin row — one broken plugin must not stop
every feed in the estate — but the row is remembered by name, so a flow
mapping it REFUSES with the import error rather than planning a run
without it.
"""
from __future__ import annotations

import importlib
import logging
import pkgutil
import threading
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from core.feed.step_model.contract import (
    CONTRACT,
    FeedPipelineStep,
    PredicateError,
    predicate_facts,
)
from core.feed.step_model.profile import FACT_NAMES

logger = logging.getLogger(__name__)

#: The package built-in and dropped-in steps live in.
BUILTIN_PACKAGE = "core.feed.step_model.steps"


class UnknownFeedStep(ValueError):
    """No step answers to this name.  The message lists what does."""


class FeedStepLoadFailed(RuntimeError):
    """A step with this name exists and FAILED to load.  Names the
    module and the reason — the opposite finding from
    :class:`UnknownFeedStep`, and deliberately a different type."""


@dataclass(frozen=True)
class LoadFailure:
    where: str
    reason: str


class StepRegistry:
    """The in-process catalogue.  Thread-safe; boot is idempotent."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._steps: Dict[str, FeedPipelineStep] = {}
        self._origins: Dict[str, str] = {}
        self._tombstones: Dict[str, LoadFailure] = {}
        self._report: List[str] = []

    # ── registration ──────────────────────────────────────────────────

    def register(self, cls, origin: str = "builtin") -> None:
        """Register one step class.  Validates what
        ``__init_subclass__`` cannot: that the predicate names facts the
        profile actually carries.

        That check is here rather than at class definition because
        ``FACT_NAMES`` is the *profile's* vocabulary — a step declaring a
        fact nobody produces must be refused where the two meet, and the
        refusal must arrive at REGISTRATION rather than at dispatch, so
        nothing burns a run finding out.
        """
        name = getattr(cls, "NAME", "") or ""
        if not name:
            raise ValueError(
                f"{getattr(cls, '__name__', cls)!r} has no NAME — an "
                f"abstract intermediate must not be registered")
        if getattr(cls, "CONTRACT", None) != CONTRACT:
            raise ValueError(
                f"step {name!r} declares contract "
                f"{getattr(cls, 'CONTRACT', None)!r}; this runtime "
                f"implements {CONTRACT!r} — a step built against another "
                f"contract must refuse rather than half-work")
        try:
            facts = predicate_facts(getattr(cls, "APPLIES_WHEN", {}) or {})
        except PredicateError as exc:
            raise ValueError(f"step {name!r}: APPLIES_WHEN invalid: {exc}")
        bad = sorted(set(facts) - set(FACT_NAMES))
        if bad:
            raise ValueError(
                f"step {name!r}: APPLIES_WHEN names profile fact(s) {bad} "
                f"that do not exist.  A predicate on a fact nothing "
                f"produces can never hold, so the step would register "
                f"cleanly and never run — the exact shape this codebase "
                f"keeps producing.  Known facts: {list(FACT_NAMES)}")
        with self._lock:
            self._steps[name] = cls() if isinstance(cls, type) else cls
            self._origins[name] = origin
            self._tombstones.pop(name, None)

    def tombstone(self, name: str, where: str, reason: str) -> None:
        with self._lock:
            self._tombstones[name] = LoadFailure(where, reason)

    def forget_tombstone(self, name: str) -> None:
        """Drop a tombstone whose ROW no longer exists (2026-10-07).  The
        custom-step POST tries the load before storing; a refused row is
        deleted, and its tombstone used to stay in the PROCESS registry --
        every later resolve of that name said "FAILED TO LOAD" for a step
        nobody has, and the catalogue's load failures listed a phantom for
        the life of the pod (it also failed an unrelated test that checks
        the registry has no tombstones, whenever both ran in one worker)."""
        with self._lock:
            self._tombstones.pop(name, None)

    # ── resolution ────────────────────────────────────────────────────

    def resolve(self, name: str):
        with self._lock:
            step = self._steps.get(name)
            tomb = self._tombstones.get(name)
            known = sorted(self._steps)
        if step is not None:
            return step
        if tomb is not None:
            raise FeedStepLoadFailed(
                f"step '{name}' EXISTS at {tomb.where} but FAILED TO LOAD: "
                f"{tomb.reason}.  This is not a missing step — fix the "
                f"module (or deactivate the row) and reload.")
        raise UnknownFeedStep(
            f"no feed step named '{name}'.  Registered: {known}")

    def manifest(self, name: str) -> Dict[str, Any]:
        """The declaration, plus the class itself under ``_class`` so the
        planner can call ``validate_params`` without a second lookup."""
        step = self.resolve(name)
        m = dict(type(step).manifest())
        m["_class"] = type(step)
        m["origin"] = self._origins.get(name)
        return m

    def has(self, name: str) -> bool:
        with self._lock:
            return name in self._steps

    def names(self) -> List[str]:
        with self._lock:
            return sorted(self._steps)

    def manifests(self) -> List[Dict[str, Any]]:
        out = []
        for name in self.names():
            m = self.manifest(name)
            m.pop("_class", None)
            out.append(m)
        return out

    def tombstones(self) -> Dict[str, LoadFailure]:
        with self._lock:
            return dict(self._tombstones)

    def boot_report(self) -> List[str]:
        with self._lock:
            return list(self._report)

    # ── discovery ─────────────────────────────────────────────────────

    def register_builtins(self) -> int:
        """The SHIPPED steps, from a static list — never discovered.

        This is the ``core/feed/steps/__init__.py`` precedent, and it is
        load-bearing rather than stylistic: discovery is a deploy knob,
        and a mispointed or unreadable steps directory must not be able
        to take ``source_extract`` or ``deliver_artifact`` away.  A run
        whose plan silently lost its extract step is a plan that looks
        complete.

        It also makes every shipped class REFERENCED from production
        code, which is what ``test_no_feed_module_is_callerless`` asks
        for — a class reached only by ``importlib`` is indistinguishable
        from a dead one to any static reader, human or test.
        """
        from core.feed.step_model.steps.dependencies import CheckDependencies
        from core.feed.step_model.steps.notify import NotifyEmail, NotifyWebhook
        from core.feed.step_model.steps.quality import (
            ArtifactNotEmpty, RowCountFloor,
        )
        from core.feed.step_model.steps.spine import (
            DeliverArtifact, FormatOutput, LocalIntegrity,
            PostDeliveryIntegrity, RowCountCheck, RunAdmission,
            SourceExtract,
        )
        shipped = (
            RunAdmission, SourceExtract, FormatOutput, LocalIntegrity,
            DeliverArtifact, PostDeliveryIntegrity, RowCountCheck,
            RowCountFloor, ArtifactNotEmpty, NotifyWebhook,
            # 2026-09-14 -- OG parity: CheckDependencies (SEQ 1 in every
            # OG workflow) and SendEmailNotifications, as declared steps.
            CheckDependencies, NotifyEmail,
        )
        n = 0
        for cls in shipped:
            try:
                self.register(cls, origin="builtin")
                n += 1
            except Exception as exc:               # noqa: BLE001
                # AUDIBLY, never fatally: one bad shipped declaration
                # must not stop the estate, and the tombstone keeps it
                # refusable by name.
                self.tombstone(getattr(cls, "NAME", cls.__name__),
                               cls.__module__, f"registration refused: {exc}")
                self._report.append(
                    f"REFUSED builtin {getattr(cls, 'NAME', cls)}: {exc}")
                logger.error("[feed-pipeline] builtin step %s REFUSED: %s",
                             getattr(cls, "NAME", cls), exc)
        return n

    def discover(self, package: str = BUILTIN_PACKAGE) -> int:
        """Import every module in *package* and register what it defines.

        The shipped classes are already registered by
        :meth:`register_builtins`; this picks up anything DROPPED IN
        beside them — "create new class as steps n drop in steps folder n
        register" with no list to edit.  A dropped file that reuses a
        shipped NAME is refused as a shadow attempt rather than replacing
        it.

        Fail-ISOLATED per module: one step that will not import must not
        take the other twenty with it, and the failure is a tombstone
        under the module's name so it is still refusable BY NAME.
        """
        found = 0
        try:
            pkg = importlib.import_module(package)
        except Exception as exc:                   # noqa: BLE001
            self._report.append(
                f"REFUSED package {package}: {type(exc).__name__}: {exc}")
            logger.error("[feed-pipeline] step package %s failed to "
                         "import: %s", package, exc, exc_info=True)
            return 0
        for mod in pkgutil.iter_modules(getattr(pkg, "__path__", [])):
            if mod.name.startswith("_"):
                continue
            full = f"{package}.{mod.name}"
            try:
                module = importlib.import_module(full)
            except Exception as exc:               # noqa: BLE001
                self.tombstone(mod.name, full,
                               f"import raised {type(exc).__name__}: {exc}")
                self._report.append(f"REFUSED {full}: {exc}")
                logger.error("[feed-pipeline] step module %s REFUSED: %s",
                             full, exc, exc_info=True)
                continue
            for attr in vars(module).values():
                if not isinstance(attr, type):
                    continue
                if not issubclass(attr, FeedPipelineStep):
                    continue
                if attr is FeedPipelineStep or not getattr(attr, "NAME", ""):
                    continue
                if attr.__module__ != full:
                    continue          # re-exported, not defined here
                if self.has(attr.NAME):
                    with self._lock:
                        same = type(self._steps[attr.NAME]) is attr
                    if same:
                        # The shipped class, met again through the same
                        # package.  Not a shadow — refusing it here would
                        # log ten ERRORs on every boot and teach the
                        # operator that the shadow warning means nothing.
                        continue
                    # A DIFFERENT class claiming a registered name.  A
                    # dropped file cannot take a builtin away; it is
                    # refused BY NAME so the operator sees the collision
                    # rather than wondering why their file had no effect.
                    self._report.append(
                        f"REFUSED {full}:{attr.__name__}: '{attr.NAME}' "
                        f"would shadow a registered step")
                    logger.error(
                        "[feed-pipeline] %s REFUSED: '%s' would shadow the "
                        "registered step of that name", full, attr.NAME)
                    continue
                try:
                    self.register(attr, origin="builtin")
                    found += 1
                except Exception as exc:           # noqa: BLE001
                    self.tombstone(attr.NAME, full,
                                   f"registration refused: {exc}")
                    self._report.append(
                        f"REFUSED {attr.NAME} from {full}: {exc}")
                    logger.error("[feed-pipeline] step %s REFUSED: %s",
                                 attr.NAME, exc)
        return found

    def load_db_plugins(self, db_manager) -> int:
        """Register every active ``feed_custom_step_types`` row.

        The row's declarations OVERRIDE the class's where present, so one
        Python class can be registered twice under two names with
        different scoping and different defaults — the same reuse
        ``dataflow_custom_stage_types`` was built for.
        """
        if db_manager is None:
            return 0
        from core.db.models import FeedCustomStepType
        registered = 0
        try:
            with db_manager.get_session(read_only=True) as session:
                rows = [r.to_dict() for r in session.query(FeedCustomStepType)
                        .filter(FeedCustomStepType.is_active == True)  # noqa: E712
                        .all()]
        except Exception as exc:                   # noqa: BLE001
            self._report.append(f"plugin table unreadable: {exc}")
            logger.warning("[feed-pipeline] custom step table unreadable: "
                           "%s — builtins only", exc)
            return 0
        for row in rows:
            name = row.get("name") or ""
            where = f"{row.get('step_module')}.{row.get('step_class')}"
            try:
                module = importlib.import_module(row["step_module"])
                base = getattr(module, row["step_class"])
            except Exception as exc:               # noqa: BLE001
                self.tombstone(name, where,
                               f"import raised {type(exc).__name__}: {exc}")
                self._report.append(f"REFUSED plugin {name}: {exc}")
                logger.error("[feed-pipeline] plugin step %s REFUSED: %s",
                             name, exc)
                continue
            if not (isinstance(base, type)
                    and issubclass(base, FeedPipelineStep)):
                self.tombstone(name, where, (
                    f"{where} is not a FeedPipelineStep subclass — it "
                    f"implements another contract and would half-work"))
                self._report.append(
                    f"REFUSED plugin {name}: not a FeedPipelineStep")
                continue
            overrides: Dict[str, Any] = {"NAME": name}
            if row.get("category"):
                overrides["CATEGORY"] = row["category"]
            if row.get("description"):
                overrides["DESCRIPTION"] = row["description"]
            if row.get("config_schema"):
                overrides["CONFIG_SCHEMA"] = row["config_schema"]
            if row.get("requires"):
                overrides["REQUIRES"] = tuple(row["requires"])
            if row.get("produces"):
                overrides["PRODUCES"] = tuple(row["produces"])
            if row.get("applies_when"):
                overrides["APPLIES_WHEN"] = row["applies_when"]
            if row.get("after"):
                overrides["AFTER"] = tuple(row["after"])
            if row.get("idempotency"):
                overrides["IDEMPOTENCY"] = row["idempotency"]
            if row.get("max_attempts"):
                overrides["MAX_ATTEMPTS"] = int(row["max_attempts"])
            # RERUNNABLE is taken from the ROW, and the row's NULL means
            # UNDECLARED — it does NOT fall back to the class's value.
            # An admin registering a plugin is making the declaration; a
            # silent inheritance would let a row that never said anything
            # borrow a True from a class written for another purpose.
            overrides["RERUNNABLE"] = row.get("rerunnable")
            try:
                cls = type(f"_FeedPlugin_{name}", (base,), overrides)
                self.register(cls, origin="plugin")
                registered += 1
                self._report.append(f"plugin {name} -> {where}")
                logger.info("[feed-pipeline] registered DB step %s -> %s",
                            name, where)
            except Exception as exc:               # noqa: BLE001
                self.tombstone(name, where, f"registration refused: {exc}")
                self._report.append(f"REFUSED plugin {name}: {exc}")
                logger.error("[feed-pipeline] plugin step %s REFUSED: %s",
                             name, exc)
        return registered

    def sync_to_db(self, db_manager) -> int:
        """Project the registry into ``feed_step_types``.

        So the admin UI can list steps and RENDER THEIR PARAMETER FORM
        without importing Python — the same job
        ``StageTypeRegistry.sync_to_db`` does for dataflow.
        """
        if db_manager is None:
            return 0
        from core.db.models import FeedStepType
        written = 0
        try:
            with db_manager.get_session() as session:
                live = set()
                for name in self.names():
                    m = self.manifest(name)
                    m.pop("_class", None)
                    live.add(name)
                    row = session.get(FeedStepType, name)
                    if row is None:
                        row = FeedStepType(name=name)
                        session.add(row)
                    row.display_name = m.get("display_name")
                    row.category = m.get("category")
                    row.class_path = m.get("class_path")
                    row.description = m.get("description")
                    row.config_schema = m.get("config_schema")
                    row.requires = m.get("requires")
                    row.produces = m.get("produces")
                    row.applies_when = m.get("applies_when")
                    row.after = m.get("after")
                    row.idempotency = m.get("idempotency")
                    row.rerunnable = m.get("rerunnable")
                    row.executor = m.get("executor")
                    row.max_attempts = m.get("max_attempts")
                    row.origin = m.get("origin")
                    row.is_active = True
                    written += 1
                # A class that was removed leaves a row that resolves to
                # nothing.  Deactivate rather than delete: the flows that
                # mapped it must still be able to say what they mapped.
                for row in session.query(FeedStepType).all():
                    if row.name not in live and row.is_active:
                        row.is_active = False
        except Exception as exc:                   # noqa: BLE001
            logger.warning("[feed-pipeline] step-type sync failed: %s", exc)
            return 0
        return written

    def reset_for_tests(self) -> None:
        """TEST SEAM — clear the registry so a test can boot it against
        its own package or its own plugin rows."""
        with self._lock:
            self._steps.clear()
            self._origins.clear()
            self._tombstones.clear()
            self._report.clear()


_registry: Optional[StepRegistry] = None
_registry_lock = threading.RLock()


def get_registry() -> StepRegistry:
    """THE process registry.  Boots the built-ins on first use so a
    read-only caller (a route asking for the catalogue) never sees an
    empty list just because nothing initialised yet."""
    global _registry
    with _registry_lock:
        if _registry is None:
            _registry = StepRegistry()
            _registry.register_builtins()
            _registry.discover()
    return _registry


def init_feed_pipeline(db_manager) -> Dict[str, Any]:
    """One-call boot, from ``core.feed_engine.init_feed_engine``.

    Order matters: built-ins first, so a plugin row cannot shadow one by
    registering the same name earlier — a dropped file must not be able
    to take a built-in away.
    """
    reg = get_registry()
    plugins = reg.load_db_plugins(db_manager)
    synced = reg.sync_to_db(db_manager)
    tombs = reg.tombstones()
    logger.info(
        "[feed-pipeline] boot — %d step type(s) registered "
        "(%d from the database), %d synced, %d refused%s",
        len(reg.names()), plugins, synced, len(tombs),
        (": " + ", ".join(sorted(tombs))) if tombs else "")
    return {"registered": len(reg.names()), "plugins": plugins,
            "synced": synced, "refused": sorted(tombs)}


__all__ = [
    "BUILTIN_PACKAGE",
    "FeedStepLoadFailed",
    "LoadFailure",
    "StepRegistry",
    "UnknownFeedStep",
    "get_registry",
    "init_feed_pipeline",
]
