"""The planner — order is DERIVED, never written down.

Grep this module for the name of any step.  There isn't one, and that is
the test: adding "SAP OData to file" must not touch this file, or the
engine, or any route.  It is a class declaring
``PRODUCES = ("extract",)`` and ``APPLIES_WHEN = {"source_type":
"sap_odata"}``, and the plan rearranges itself around it.

HOW THE ORDER COMES OUT
-----------------------
1. **Scope.**  Every registered step whose ``APPLIES_WHEN`` predicate
   holds for the run's profile is a candidate, plus every step the feed's
   FLOW maps in (a flow-mapped step still has to pass its own predicate —
   mapping a Starburst step onto an Oracle feed should not run it).
2. **Edges.**  For each candidate S and each artifact kind S REQUIRES,
   every candidate producing that kind gets an edge to S.  That is the
   whole dependency rule — plus the two named-type escapes, ``AFTER``
   and ``BEFORE``, which only add an edge when the named type is in the
   plan (an optional gate ahead of the extract cannot be spelled as an
   artifact: on feeds without the gate nothing would produce it).  Two producers of one kind is legitimate and
   common — OG's ``ConsolidateFiles`` waits on ``StarburstToFile_OnCloud``
   AND ``_OnPrem`` — so a consumer depends on ALL of them.
3. **Levels.**  Kahn's algorithm, taking every zero-in-degree node at
   once.  Steps sharing a level have no declared dependency between them,
   so they may run in parallel; the level number is stored, which is what
   makes "these three ran together" a visible fact rather than an
   implication.
4. **Seq.**  1..N in level-major order, ties broken by (flow seq, alias)
   so the numbering is deterministic across pods and re-plans.

WHAT REFUSES, AND WHY IT REFUSES RATHER THAN DROPS
---------------------------------------------------
* a REQUIRES nothing produces;
* a cycle;
* a step name the registry does not know (or knows as a failed import —
  two different findings, two different messages);
* a required parameter with no value;
* a predicate that cannot be EVALUATED (unknown operator, or a fact this
  run could not resolve).

Every one of these is a refusal naming the step, because the alternative
— quietly leaving the step out — produces a plan that looks complete and
is missing a gate.  A cap may throttle; a correctness gate must fail.

The refusal is carried on the :class:`Plan`, not raised, so the CALLER
decides what it costs.  ``Plan.is_fatal`` is True exactly when the plan
was supposed to run something (a flow-mapped runner step) and now cannot;
a feed with no flow gets its refusal recorded and its run proceeds
unchanged, because refusing to record a timeline is not a reason to stop
delivering a file.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from core.feed.step_model.contract import (
    PredicateError,
    evaluate_predicate,
)
from core.feed.step_model.profile import FeedProfile, mask_params

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StepCandidate:
    """One step considered for the plan.

    ``manifest`` is the registry's declaration; ``params`` are the values
    a flow row supplied (empty for a spine step, which is mapped by
    nobody and configured by nobody).
    """
    alias: str
    manifest: Mapping[str, Any]
    params: Mapping[str, Any] = field(default_factory=dict)
    flow_seq: int = 100
    max_attempts: Optional[int] = None
    source: str = "registry"          # registry | flow


@dataclass(frozen=True)
class PlannedStep:
    alias: str
    step_type: str
    seq: int
    level: int
    depends_on: Tuple[str, ...]
    executor: str
    #: What the step RUNS with — resolved, unmasked.
    params: Mapping[str, Any]
    #: What is RECORDED — the same values with every parameter the step
    #: declared ``"type": "secret"`` replaced by ``***``.
    #:
    #: Two fields rather than masking at the write, because there are
    #: three writers (SOD's planned rows, the recorder's engine rows, the
    #: runner's attempt rows) and a mask applied at three call sites is a
    #: mask that will one day be applied at two.  Derived ONCE, here,
    #: where the manifest is already in hand.
    stored_params: Mapping[str, Any]
    manifest: Mapping[str, Any]
    max_attempts: int
    source: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alias": self.alias,
            "step_type": self.step_type,
            "seq": self.seq,
            "level": self.level,
            "depends_on": list(self.depends_on),
            "executor": self.executor,
            "params": dict(self.stored_params),
            "max_attempts": self.max_attempts,
            "source": self.source,
            "idempotency": self.manifest.get("idempotency"),
            "rerunnable": self.manifest.get("rerunnable"),
            "display_name": self.manifest.get("display_name"),
            "description": self.manifest.get("description"),
            "requires": list(self.manifest.get("requires") or []),
            "produces": list(self.manifest.get("produces") or []),
        }


@dataclass(frozen=True)
class SkippedStep:
    """A candidate whose predicate did NOT hold.

    Recorded rather than discarded so "why did this step not run" has an
    answer that is not "read the source".  The system logs what it did
    and never what it declined to do — that sentence cost a session.
    """
    alias: str
    step_type: str
    reason: str


@dataclass(frozen=True)
class Plan:
    steps: Tuple[PlannedStep, ...]
    skipped: Tuple[SkippedStep, ...] = ()
    refusals: Tuple[str, ...] = ()
    is_fatal: bool = False

    @property
    def ok(self) -> bool:
        return not self.refusals

    def by_alias(self, alias: str) -> Optional[PlannedStep]:
        for s in self.steps:
            if s.alias == alias:
                return s
        return None

    def levels(self) -> List[List[PlannedStep]]:
        """The parallel waves, in order.  ``levels()[0]`` may start at
        once; nothing in ``levels()[n]`` may start until every step in
        ``levels()[n-1]`` is green."""
        out: Dict[int, List[PlannedStep]] = {}
        for s in self.steps:
            out.setdefault(s.level, []).append(s)
        return [out[k] for k in sorted(out)]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "steps": [s.to_dict() for s in self.steps],
            "skipped": [{"alias": s.alias, "step_type": s.step_type,
                         "reason": s.reason} for s in self.skipped],
            "refusals": list(self.refusals),
            "ok": self.ok,
            "is_fatal": self.is_fatal,
            "level_count": len(self.levels()),
        }


def _in_scope(cand: StepCandidate, profile: FeedProfile) -> Tuple[bool, str]:
    """``(applies, reason)`` — and a PredicateError propagates."""
    predicate = cand.manifest.get("applies_when") or {}
    if evaluate_predicate(predicate, profile.facts, profile.unknown):
        return True, "predicate holds"
    return False, (
        f"APPLIES_WHEN {predicate!r} does not hold for this feed "
        f"(profile: " + ", ".join(
            f"{k}={profile.facts.get(k)!r}"
            for k in sorted(predicate) if not k.startswith("$")) + ")")


def plan_steps(profile: FeedProfile,
               candidates: Sequence[StepCandidate],
               *, fatal_when_flow_mapped: bool = True) -> Plan:
    """Turn declarations into an ordered, levelled plan.

    Pure: no DB, no clock, no registry lookup.  Everything it needs
    arrives as arguments, which is what lets the whole ordering rule be
    tested without standing anything up.
    """
    refusals: List[str] = []
    skipped: List[SkippedStep] = []
    in_scope: List[StepCandidate] = []
    saw_flow_runner = False

    seen_aliases: set = set()
    for cand in candidates:
        if cand.alias in seen_aliases:
            refusals.append(
                f"two steps share the alias '{cand.alias}' — an alias is "
                f"the run row's identity, so a duplicate would make one "
                f"attempt overwrite the other's record")
            continue
        seen_aliases.add(cand.alias)
        if cand.source == "flow" and cand.manifest.get("executor") == "runner":
            saw_flow_runner = True
        try:
            applies, reason = _in_scope(cand, profile)
        except PredicateError as exc:
            refusals.append(
                f"step '{cand.alias}' ({cand.manifest.get('name')}): its "
                f"scoping predicate could not be EVALUATED — {exc}")
            continue
        if not applies:
            skipped.append(SkippedStep(cand.alias,
                                       str(cand.manifest.get("name") or ""),
                                       reason))
            continue
        problems = _param_problems(cand)
        if problems:
            refusals.extend(
                f"step '{cand.alias}': {p}" for p in problems)
            continue
        in_scope.append(cand)

    # ── edges, from REQUIRES/PRODUCES and nothing else ────────────────
    producers: Dict[str, List[str]] = {}
    for cand in in_scope:
        for kind in (cand.manifest.get("produces") or []):
            producers.setdefault(str(kind), []).append(cand.alias)

    by_alias = {c.alias: c for c in in_scope}
    types_present: Dict[str, List[str]] = {}
    for cand in in_scope:
        types_present.setdefault(str(cand.manifest.get("name") or ""), []) \
            .append(cand.alias)

    deps: Dict[str, set] = {c.alias: set() for c in in_scope}
    for cand in in_scope:
        for kind in (cand.manifest.get("requires") or []):
            kind = str(kind)
            supply = [a for a in producers.get(kind, []) if a != cand.alias]
            if not supply:
                refusals.append(
                    f"step '{cand.alias}' requires artifact '{kind}' and "
                    f"NOTHING in this plan produces it.  Refusing rather "
                    f"than dropping the step: a plan missing a step it was "
                    f"asked for looks exactly like a plan that never "
                    f"needed one")
                continue
            deps[cand.alias].update(supply)
        for after_type in (cand.manifest.get("after") or []):
            for other in types_present.get(str(after_type), []):
                if other != cand.alias:
                    deps[cand.alias].add(other)
        # BEFORE is AFTER seen from the other side: the declaring step
        # becomes a dependency of every planned step of the named type.
        # Nothing happens when the type is not in this plan — that is
        # what makes it the tool for an OPTIONAL predecessor.
        for before_type in (cand.manifest.get("before") or []):
            for other in types_present.get(str(before_type), []):
                if other != cand.alias:
                    deps[other].add(cand.alias)

    if refusals:
        return Plan(steps=(), skipped=tuple(skipped), refusals=tuple(refusals),
                    is_fatal=bool(fatal_when_flow_mapped and saw_flow_runner))

    # ── levels (Kahn, whole frontier at a time) ───────────────────────
    remaining = dict(deps)
    level_of: Dict[str, int] = {}
    level = 0
    while remaining:
        frontier = [a for a, d in remaining.items() if not (d & set(remaining))]
        if not frontier:
            cycle = sorted(remaining)
            return Plan(
                steps=(), skipped=tuple(skipped),
                refusals=(
                    f"the declared dependencies form a CYCLE among "
                    f"{cycle} — no order exists, so no plan is produced. "
                    f"Check the REQUIRES/PRODUCES declarations of those "
                    f"steps",),
                is_fatal=bool(fatal_when_flow_mapped and saw_flow_runner))
        for alias in frontier:
            level_of[alias] = level
            remaining.pop(alias)
        level += 1

    ordered = sorted(
        in_scope,
        key=lambda c: (level_of[c.alias], int(c.flow_seq or 100), c.alias))

    planned: List[PlannedStep] = []
    for i, cand in enumerate(ordered, start=1):
        m = cand.manifest
        planned.append(PlannedStep(
            alias=cand.alias,
            step_type=str(m.get("name") or ""),
            seq=i,
            level=level_of[cand.alias],
            depends_on=tuple(sorted(deps[cand.alias])),
            executor=str(m.get("executor") or "runner"),
            params=dict(cand.params or {}),
            stored_params=mask_params(cand.params,
                                      m.get("config_schema") or {}),
            manifest=dict(m),
            max_attempts=int(cand.max_attempts or m.get("max_attempts") or 1),
            source=cand.source,
        ))
    return Plan(steps=tuple(planned), skipped=tuple(skipped))


def _param_problems(cand: StepCandidate) -> List[str]:
    """Validate a candidate's parameters against its declared schema.

    Resolved BEFORE anything runs, with everything else — OG's
    ``run_id=969000`` failed at execute time on a route that could never
    have worked, having already spent its retry budget getting there.
    """
    cls = cand.manifest.get("_class")
    if cls is not None and hasattr(cls, "validate_params"):
        try:
            return list(cls.validate_params(cand.params or {}))
        except Exception as exc:                   # noqa: BLE001
            return [f"parameter validation raised "
                    f"{type(exc).__name__}: {exc}"]
    schema = cand.manifest.get("config_schema") or {}
    problems: List[str] = []
    for key, decl in schema.items():
        if isinstance(decl, Mapping) and decl.get("required") \
                and (cand.params or {}).get(key) is None:
            problems.append(f"required parameter '{key}' is missing")
    return problems


__all__ = ["Plan", "PlannedStep", "SkippedStep", "StepCandidate", "plan_steps"]
