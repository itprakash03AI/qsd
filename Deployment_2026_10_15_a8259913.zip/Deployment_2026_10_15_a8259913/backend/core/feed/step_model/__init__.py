"""The feed pipeline STEP MODEL — one row per step, declared not coded.

2026-09-05.  The gap this package closes is the one
``docs/FABLE_CONTEXT_STEPS_2026_09_05.html`` was written to settle: the
feed engine performs named stages and stores them as ONE dict of
DURATIONS, so the run screen renders *logs* rather than steps.

THE DECISION, and the reasoning, because "a decision made twice is a
bug":

    FeedGen converges on DataFlow's step DECLARATION and step RECORD.
    It does NOT converge on DataFlow's run model, and it does NOT
    converge on DataFlow's authoring model.

* **Declaration is shared.**  The idempotency vocabulary is *imported*
  from :mod:`core.dataflow.base` — not re-declared — and a step's
  manifest is a superset of ``BaseStage.manifest()``, so one UI form
  renderer serves both catalogues.  ``feed_custom_step_types`` is
  ``dataflow_custom_stage_types``' shape.
* **The run model is not shared.**  BRD §2.2: "Two run models. Feed runs
  are feed runs."  A feed run stays a ``feed_runs`` row created by
  ``SodTaskGenerator``; steps hang off the run SOD already creates.
* **The authoring model is not shared.**  A dataflow author composes a
  graph because there is nothing to derive one from.  A feed author
  supplies the six properties, and the STEP SEQUENCE IS DERIVED.  Nobody
  draws a DAG, so BRD §2.2's "a feed author drawing a graph" is not
  reintroduced.

WHY IT IS NOT A HARDCODED LIST
------------------------------
A dumb step engine is an ordered list of names the engine walks, where
every new capability means editing the engine.  Here:

* a step declares ``REQUIRES`` / ``PRODUCES`` over an **open** artifact
  namespace, and the planner derives the DAG from those two lists —
  :mod:`core.feed.step_model.planner` contains **no step name at all**;
* a step declares ``APPLIES_WHEN`` as a **declarative predicate** (JSON,
  not code), so a step registered from the DATABASE carries its own
  scoping rule and the UI can answer "why did this step not run";
* independent steps land in the same LEVEL and may run together —
  parallelism is derived, not configured;
* "re-run from the first non-green step" is a QUERY over
  ``feed_run_steps``, not a feature with its own code path.

WHAT IS DELIBERATELY *NOT* RE-DECIDED HERE
------------------------------------------
The profile (:mod:`core.feed.step_model.profile`) CONSUMES the answers this
product already has — the lane from ``core/feed/backend_router.py``, the
calendar vocabulary from ``core/feed/param_resolver.py``, the contract
terms off the feed config.  A step engine that re-decides any of them is
the "decision made twice" bug at a new layer.

MIGRATION
---------
Every feed that exists today has ``flow_id = NULL``.  It plans and
records the engine spine — so it gains the per-step screen — and runs
byte-for-byte as it did before, because the engine's own work is
*recorded*, never re-executed by this package.  Only a feed mapped to a
flow gets extra steps, and only those extra steps are executed here.
"""
from __future__ import annotations

from core.feed.step_model.contract import (
    ARTIFACT_CERTIFIED,
    ARTIFACT_CHECKSUM,
    ARTIFACT_CONTROL_FILE,
    ARTIFACT_DELIVERED,
    ARTIFACT_EXTRACT,
    ARTIFACT_FORMATTED_FILE,
    ARTIFACT_PACKAGED_FILE,
    ARTIFACT_ROW_COUNT,
    FeedPipelineStep,
    PredicateError,
    StepContext,
    StepRefused,
    StepResult,
    rerun_verdict,
)
from core.feed.step_model.planner import Plan, PlannedStep, plan_steps
from core.feed.step_model.profile import FeedProfile, build_profile
from core.feed.step_model.registry import (
    StepRegistry,
    UnknownFeedStep,
    get_registry,
    init_feed_pipeline,
)

__all__ = [
    "ARTIFACT_CERTIFIED",
    "ARTIFACT_CHECKSUM",
    "ARTIFACT_CONTROL_FILE",
    "ARTIFACT_DELIVERED",
    "ARTIFACT_EXTRACT",
    "ARTIFACT_FORMATTED_FILE",
    "ARTIFACT_PACKAGED_FILE",
    "ARTIFACT_ROW_COUNT",
    "FeedPipelineStep",
    "FeedProfile",
    "Plan",
    "PlannedStep",
    "PredicateError",
    "StepContext",
    "StepRefused",
    "StepRegistry",
    "StepResult",
    "UnknownFeedStep",
    "build_profile",
    "get_registry",
    "init_feed_pipeline",
    "plan_steps",
    "rerun_verdict",
]
