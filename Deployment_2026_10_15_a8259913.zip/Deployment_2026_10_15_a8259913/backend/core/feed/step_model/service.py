"""One place that answers "what steps does this feed run, and why".

The route asking for a preview, the SOD generator writing tomorrow's
rows, and the engine recording tonight's all call THIS.  Three callers
resolving the same question three ways is the defect this codebase keeps
finding; ``setup_registered_views`` resolved "what SQL is this" five ways
in one function and the row-loss bug survived in the two nobody fixed.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Mapping, Optional

from core.feed.step_model.planner import Plan, StepCandidate, plan_steps
from core.feed.step_model.profile import build_profile, resolve_step_params
from core.feed.step_model.registry import (
    FeedStepLoadFailed,
    UnknownFeedStep,
    get_registry,
)
from core.feed.step_model.store import resolve_flow_steps

logger = logging.getLogger(__name__)


def _spine_candidates(registry) -> List[StepCandidate]:
    """Every registered ``EXECUTOR='engine'`` step, aliased by its name.

    The spine is not mapped by anybody — it is what the engine does — so
    its candidates come from the registry itself and its alias is its
    step type.  A feed does not opt in to having an extract.
    """
    out: List[StepCandidate] = []
    for name in registry.names():
        m = registry.manifest(name)
        if m.get("executor") != "engine":
            continue
        out.append(StepCandidate(alias=name, manifest=m, params={},
                                 flow_seq=int(m.get("_spine_seq") or 10),
                                 source="registry"))
    return out


def plan_for_feed(db_manager,
                  feed_config: Mapping[str, Any],
                  feed_run: Optional[Mapping[str, Any]] = None,
                  *, calendar=None, lane_resolver=None,
                  registry=None) -> Plan:
    """THE plan for one feed (and optionally one run).

    Answerable with ``feed_run=None``, which is what makes "show me what
    will run" a read on a feed that has never run.
    """
    registry = registry or get_registry()
    profile = build_profile(feed_config, feed_run, lane_resolver=lane_resolver)
    candidates = _spine_candidates(registry)
    refusals: List[str] = []

    try:
        flow_rows = resolve_flow_steps(db_manager, feed_config.get("flow_id"))
    except LookupError as exc:
        # A mapping that cannot be resolved is FATAL by construction: the
        # feed was configured to run something and we cannot say what.
        return Plan(steps=(), refusals=(str(exc),), is_fatal=True)
    except Exception as exc:                       # noqa: BLE001
        return Plan(steps=(), is_fatal=True, refusals=(
            f"the feed's step flow could not be read "
            f"({type(exc).__name__}: {exc}) — refusing rather than "
            f"planning a run without steps that were configured for it",))

    for row in flow_rows:
        step_type = row.get("step_type") or ""
        try:
            manifest = registry.manifest(step_type)
        except UnknownFeedStep as exc:
            refusals.append(
                f"flow step '{row.get('alias')}' names step type "
                f"'{step_type}': {exc}")
            continue
        except FeedStepLoadFailed as exc:
            refusals.append(
                f"flow step '{row.get('alias')}': {exc}")
            continue
        if manifest.get("executor") == "engine":
            refusals.append(
                f"flow step '{row.get('alias')}' maps '{step_type}', which "
                f"is part of the engine's own spine — it already runs on "
                f"every feed and mapping it would plan it twice")
            continue
        params = resolve_step_params(row.get("params"), feed_config,
                                     feed_run, calendar)
        candidates.append(StepCandidate(
            alias=row.get("alias") or step_type,
            manifest=manifest,
            params=params,
            flow_seq=int(row.get("seq") or 100),
            max_attempts=row.get("max_attempts"),
            source="flow",
        ))

    plan = plan_steps(profile, candidates)
    if refusals:
        return Plan(steps=(), skipped=plan.skipped,
                    refusals=tuple(refusals) + plan.refusals,
                    is_fatal=True)
    return plan


def describe_plan(db_manager, feed_config: Mapping[str, Any],
                  feed_run: Optional[Mapping[str, Any]] = None,
                  **kwargs) -> Dict[str, Any]:
    """The preview payload: the plan, the skips WITH THEIR REASONS, and
    the refusals.  What a UI needs to answer "what will run tonight" and
    "why is my step not in the list"."""
    plan = plan_for_feed(db_manager, feed_config, feed_run, **kwargs)
    profile = build_profile(feed_config, feed_run,
                            lane_resolver=kwargs.get("lane_resolver"))
    # ``Plan.to_dict`` already renders each step's MASKED params —
    # one masking, in the planner, so the preview and the stored row can
    # never disagree about what a step ran with.
    out = plan.to_dict()
    out["profile"] = profile.to_dict()
    out["feed_id"] = feed_config.get("id")
    out["feed_name"] = feed_config.get("name")
    out["flow_id"] = feed_config.get("flow_id")
    return out


__all__ = ["describe_plan", "plan_for_feed"]
