"""Executing the steps the engine does not — and re-running one.

The runner is deliberately small, because most of what an executor
usually does is already decided by the plan: WHICH steps exist, in WHAT
order, and WHAT may go in parallel all come out of the declarations.  All
that is left is "run the ones whose inputs have arrived".

PARALLELISM IS DERIVED, NOT CONFIGURED
---------------------------------------
Steps that became ready together have no declared dependency between
them, so they are launched together with ``asyncio.gather``.  Nobody sets
a concurrency option; the artifact graph already said which steps are
independent, and honouring that is free.

RETRY WITHIN A RUN USES THE SAME RULE AS RE-RUN BY HAND
--------------------------------------------------------
Both ask :func:`core.feed.step_model.contract.rerun_verdict`.  One rule in
one place — an automatic retry that used a laxer rule than the operator's
button is precisely OG's 50-million-row incident, where a step nobody had
declared safe was retried by the framework after a driver call-timeout.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, List, Mapping, Optional, Sequence

from core.db.models import FEED_RUN_STEP_GREEN_STATUSES
from core.feed.step_model.contract import (
    StepContext,
    StepRefused,
    StepResult,
    rerun_verdict,
)
from core.feed.step_model.registry import get_registry
from core.feed.step_model.store import (
    begin_attempt,
    finish_attempt,
    first_not_green,
    latest_attempts,
)

logger = logging.getLogger(__name__)


class StepExecutionHalted(RuntimeError):
    """A planned step failed or refused; the run stops here.

    Carries the alias so the engine's ``failed_stage`` and the run's
    error name the STEP rather than "something in the pipeline".
    """

    def __init__(self, alias: str, status: str, message: str) -> None:
        super().__init__(f"step '{alias}' {status}: {message}")
        self.alias = alias
        self.status = status
        self.detail = message


def ready_aliases(planned: Sequence[Any],
                  statuses: Mapping[str, str],
                  artifacts: Mapping[str, Any]) -> List[str]:
    """Which runner steps may start NOW.

    Three conditions, and the third is the one that is easy to forget: a
    step whose predecessor was SKIPPED has a green prefix but may still
    be missing the artifact it declared.  Refusing to start it (rather
    than starting it and letting ``ctx.artifact`` raise) is the
    difference between "this step could not run because the extract was
    skipped" and a stack trace.
    """
    out: List[str] = []
    for step in planned:
        if step.executor != "runner":
            continue
        if statuses.get(step.alias) != "not_started":
            continue
        if any(statuses.get(dep) not in FEED_RUN_STEP_GREEN_STATUSES
               for dep in step.depends_on):
            continue
        if any(kind not in artifacts
               for kind in (step.manifest.get("requires") or [])):
            continue
        out.append(step.alias)
    return out


def blocked_reason(step: Any, statuses: Mapping[str, str],
                   artifacts: Mapping[str, Any]) -> Optional[str]:
    """Why a not-yet-run step cannot start — stated, never inferred.

    The system logs what it DID and never what it DECLINED to do; that
    sentence cost a session, and this function is the answer to it for
    this subsystem.
    """
    stale = [d for d in step.depends_on
             if statuses.get(d) not in FEED_RUN_STEP_GREEN_STATUSES]
    if stale:
        return (f"waiting on {', '.join(sorted(stale))} "
                f"({', '.join(f'{d}={statuses.get(d)}' for d in sorted(stale))})")
    missing = [k for k in (step.manifest.get("requires") or [])
               if k not in artifacts]
    if missing:
        return (f"its declared input(s) {sorted(missing)} were never "
                f"produced — every step it depends on is green, so the "
                f"producer must have been skipped on this run")
    return None


def _run_one(step_instance, ctx: StepContext) -> StepResult:
    result = step_instance.execute(ctx)
    if not isinstance(result, StepResult):
        raise TypeError(
            f"step '{ctx.alias}' returned {type(result).__name__}, not a "
            f"StepResult — a step that does not say what it produced "
            f"cannot be read by the step after it")
    return result


async def execute_step(db_manager, *, feed_run_id: int, step: Any,
                       feed_config: Mapping[str, Any],
                       feed_run: Mapping[str, Any],
                       artifacts: Dict[str, Any],
                       execution_id: str = "",
                       attempt: Optional[int] = None,
                       triggered_by: Optional[str] = None,
                       registry=None) -> Dict[str, Any]:
    """Run ONE step, with its declared retry budget.  Never raises for a
    step outcome — it returns it, and the caller decides.

    Returns ``{"alias", "status", "rows_out", "outputs", "error"}``.
    """
    registry = registry or get_registry()
    instance = registry.resolve(step.step_type)
    manifest = step.manifest or {}
    budget = max(1, int(step.max_attempts or 1))
    attempt_no = attempt
    last: Dict[str, Any] = {}

    for n in range(budget):
        this_attempt = attempt_no if n == 0 else (attempt_no or 1) + n
        row_id = await asyncio.to_thread(
            begin_attempt, db_manager, feed_run_id, step.alias,
            attempt=this_attempt, params=step.stored_params,
            execution_id=execution_id, triggered_by=triggered_by,
            rows_in=artifacts.get("row_count"))
        if row_id is None:
            return {"alias": step.alias, "status": "failed",
                    "error": (f"step '{step.alias}' has no planned row on "
                              f"run {feed_run_id} — refusing to execute a "
                              f"step nothing planned")}
        ctx = StepContext(
            feed_config=feed_config, feed_run=feed_run,
            business_date=feed_run.get("business_date"),
            params=dict(step.params or {}), artifacts=artifacts,
            alias=step.alias, attempt=int(this_attempt or 1),
            execution_id=execution_id, logger=logger, db=db_manager)
        started = time.time()
        try:
            result = await asyncio.to_thread(_run_one, instance, ctx)
        except StepRefused as exc:
            # A REFUSAL is a verdict, not a transient.  Retrying it would
            # ask the same question and get the same answer, while
            # burning the budget a real transient might have needed.
            await asyncio.to_thread(
                finish_attempt, db_manager, row_id, "refused",
                error=str(exc), duration_seconds=time.time() - started)
            return {"alias": step.alias, "status": "refused",
                    "error": str(exc)}
        except Exception as exc:                   # noqa: BLE001
            await asyncio.to_thread(
                finish_attempt, db_manager, row_id, "failed",
                error=f"{type(exc).__name__}: {exc}",
                duration_seconds=time.time() - started)
            last = {"alias": step.alias, "status": "failed",
                    "error": f"{type(exc).__name__}: {exc}"}
            if n + 1 >= budget:
                return last
            verdict = rerun_verdict(manifest, step.params)
            if not verdict.allowed:
                logger.error(
                    "[feed-pipeline] step '%s' failed and has %d attempt(s) "
                    "left, but it is NOT re-runnable: %s.  Stopping at one "
                    "attempt — an undeclared step run twice is how OG "
                    "produced 50 million duplicate rows",
                    step.alias, budget - n - 1, verdict.reason)
                return last
            logger.warning(
                "[feed-pipeline] step '%s' attempt %s failed (%s); "
                "retrying — declared re-runnable (%s)",
                step.alias, this_attempt, exc, manifest.get("idempotency"))
            continue
        outputs = dict(result.outputs or {})
        if result.rows_out is not None:
            outputs.setdefault("rows_out", int(result.rows_out))
        if result.message:
            outputs.setdefault("message", result.message)
        await asyncio.to_thread(
            finish_attempt, db_manager, row_id, "completed",
            rows_out=result.rows_out, outputs=outputs,
            duration_seconds=time.time() - started)
        for kind in (manifest.get("produces") or []):
            if kind in outputs:
                artifacts[str(kind)] = outputs[kind]
        return {"alias": step.alias, "status": "completed",
                "rows_out": result.rows_out, "outputs": outputs}
    return last


async def drive(db_manager, *, feed_run_id: int, planned: Sequence[Any],
                statuses: Dict[str, str], artifacts: Dict[str, Any],
                feed_config: Mapping[str, Any],
                feed_run: Mapping[str, Any],
                execution_id: str = "", registry=None) -> None:
    """Run every runner step that has become ready, in parallel waves.

    Called after each engine stage closes.  Halts the run on the first
    failure or refusal — OG halts on first failure and re-raises so
    cleanup and the failure email fire, and that is the right shape: a
    pipeline that carries on past a broken step delivers something
    nobody checked.
    """
    while True:
        wave = ready_aliases(planned, statuses, artifacts)
        if not wave:
            return
        by_alias = {s.alias: s for s in planned}
        results = await asyncio.gather(*[
            execute_step(db_manager, feed_run_id=feed_run_id,
                         step=by_alias[a], feed_config=feed_config,
                         feed_run=feed_run, artifacts=artifacts,
                         execution_id=execution_id, registry=registry)
            for a in wave
        ])
        for res in results:
            statuses[res["alias"]] = res["status"]
        broken = [r for r in results if r["status"] in ("failed", "refused")]
        if broken:
            first = broken[0]
            raise StepExecutionHalted(first["alias"], first["status"],
                                      first.get("error") or "")


# ── Re-run, by hand ────────────────────────────────────────────────────


def rerun_precheck(db_manager, feed_run_id: int, alias: str,
                   registry=None) -> Dict[str, Any]:
    """May this step be re-run?  ``{"allowed", "reason", "step"}``.

    Resolved ONCE and the reason kept, because a value computed for a
    gate and then thrown away disagrees with what the system does.  The
    UI shows this reason on the disabled button; the POST re-checks it
    rather than trusting the UI, because the UI is not the gate.
    """
    registry = registry or get_registry()
    rows = latest_attempts(db_manager, feed_run_id)
    row = next((r for r in rows if r["alias"] == alias), None)
    if row is None:
        return {"allowed": False, "step": None, "reason": (
            f"run {feed_run_id} has no step '{alias}'")}
    if row["status"] == "running":
        return {"allowed": False, "step": row, "reason": (
            "the step is RUNNING — re-running it now would race the "
            "worker that owns it")}
    try:
        manifest = registry.manifest(row["step_type"])
    except Exception as exc:                       # noqa: BLE001
        return {"allowed": False, "step": row, "reason": (
            f"step type '{row['step_type']}' cannot be resolved: {exc}")}
    deps = list(row.get("depends_on") or [])
    blocker = first_not_green(rows, among=deps) if deps else None
    verdict = rerun_verdict(
        manifest, row.get("params") or {},
        blocking_alias=(blocker or {}).get("alias") if blocker else None,
        blocking_status=(blocker or {}).get("status") if blocker else None)
    return {"allowed": verdict.allowed, "reason": verdict.reason,
            "step": row}


__all__ = [
    "StepExecutionHalted",
    "blocked_reason",
    "drive",
    "execute_step",
    "ready_aliases",
    "rerun_precheck",
]
