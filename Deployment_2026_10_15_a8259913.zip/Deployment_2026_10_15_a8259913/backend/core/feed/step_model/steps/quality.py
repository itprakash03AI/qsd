"""Runnable quality steps — the shape a dropped-in step takes.

These are ``EXECUTOR = "runner"``: the pipeline runner calls
``execute(ctx)`` at the position the artifact graph put them in.  They
are also the worked example a new step is copied from, which is why the
declarations are spelled out rather than defaulted.

Both are correctness GATES, so both raise
:class:`~core.feed.step_model.contract.StepRefused` — a gate must fail,
where a cap may throttle.  The two are identical in code and opposite in
consequence, and this codebase has shipped the wrong one before.
"""
from __future__ import annotations

import os

from core.dataflow.base import CATEGORY_QUALITY, IDEMPOTENT_SAFE
from core.feed.step_model.contract import (
    ARTIFACT_FORMATTED_FILE,
    ARTIFACT_ROW_COUNT,
    FeedPipelineStep,
    StepContext,
    StepRefused,
    StepResult,
)


class RowCountFloor(FeedPipelineStep):
    """Refuse a run that produced fewer rows than the consumer expects.

    Different from the built-in ``row_count_check``, which compares
    against a MOVING baseline: this is an absolute floor a counterparty
    stated, and it does not drift down with a run of bad days.
    """
    NAME = "row_count_floor"
    DISPLAY_NAME = "Row Count Floor"
    DESCRIPTION = ("Refuses the run when the extract produced fewer rows "
                   "than the declared minimum.  An absolute floor, not a "
                   "baseline comparison.")
    CATEGORY = CATEGORY_QUALITY
    REQUIRES = (ARTIFACT_ROW_COUNT,)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    #: Reading a number and comparing it has no side effect at all, so
    #: this is one of the few steps that can honestly say True.
    RERUNNABLE = True
    CONFIG_SCHEMA = {
        "minimum": {
            "type": "int", "required": True,
            "label": "Minimum rows",
            "help": "Refuse the run below this row count.",
        },
        "allow_zero_on_declared_empty": {
            "type": "bool", "required": False, "default": False,
            "label": "Allow a declared-empty day",
            "help": ("When true, a run whose partition shape declared "
                     "NO entities passes at zero rows.  'No count' is "
                     "not zero, so this is opt-in."),
        },
    }

    def execute(self, ctx: StepContext) -> StepResult:
        minimum = int(ctx.params["minimum"])
        rows = ctx.row_count
        if rows is None:
            raise StepRefused(
                "the run reported NO row count, which is not the same as "
                "zero rows — refusing rather than passing a floor check "
                "against a number nobody produced")
        if rows < minimum:
            if rows == 0 and ctx.params.get("allow_zero_on_declared_empty"):
                return StepResult(
                    rows_out=0,
                    message="zero rows accepted: a declared-empty day")
            raise StepRefused(
                f"{rows:,} rows, floor is {minimum:,}")
        return StepResult(rows_out=rows,
                          message=f"{rows:,} rows, floor {minimum:,}")


class ArtifactNotEmpty(FeedPipelineStep):
    """Refuse an artifact that is missing or smaller than a floor.

    A zero-byte file delivers successfully, verifies its own checksum,
    and satisfies every status the run writes.  It is a failure that
    looks exactly like a success, which is the only kind this product
    keeps shipping.
    """
    NAME = "artifact_not_empty"
    DISPLAY_NAME = "Artifact Not Empty"
    DESCRIPTION = ("Refuses the run when the formatted artifact is "
                   "missing, unreadable, or smaller than the declared "
                   "minimum size.")
    CATEGORY = CATEGORY_QUALITY
    REQUIRES = (ARTIFACT_FORMATTED_FILE,)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    RERUNNABLE = True
    CONFIG_SCHEMA = {
        "min_bytes": {
            "type": "int", "required": False, "default": 1,
            "label": "Minimum size (bytes)",
            "help": "Refuse an artifact smaller than this.  Default 1.",
        },
    }

    def execute(self, ctx: StepContext) -> StepResult:
        path = ctx.artifact(ARTIFACT_FORMATTED_FILE)
        minimum = int(ctx.params.get("min_bytes") or 1)
        if not path:
            raise StepRefused(
                "the run recorded no artifact path — 'could not read' and "
                "'has none' lead to opposite investigations, so this "
                "refuses rather than treating an absent path as a small "
                "file")
        try:
            size = os.path.getsize(str(path))
        except OSError as exc:
            raise StepRefused(
                f"artifact {path} could not be measured: {exc}")
        if size < minimum:
            raise StepRefused(
                f"artifact {path} is {size:,} bytes, floor is "
                f"{minimum:,}")
        return StepResult(outputs={"size_bytes": size},
                          message=f"{size:,} bytes")
