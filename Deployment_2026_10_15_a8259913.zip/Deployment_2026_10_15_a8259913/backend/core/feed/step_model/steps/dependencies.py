"""OG's ``CheckDependencies`` at SEQ 1 — as a DECLARED step, not a second gate.

THE DECISION IS NOT MADE HERE
-----------------------------
QueryStudio already answers "are this feed's dependencies met for this
business date" in exactly one place:
``core.feed.etl_dependency.evaluate_gate_verdicts`` — the four-verdict
gate (met / not met / NOT EXPECTED / could not tell) over the tracking
rows, with each dependency's own upstream calendar.  The dependency
poller consults it to flip a queued run WAIT -> RUN, the run surface
consults it for "blocked on what", the SLA watcher's reverse index
consults it, and the operator API consults it.  This step is the fifth
CALLER of that function, and it is nothing else: a second engine
answering the same question is the defect CLAUDE.md names outright.

WHAT IT ADDS, THEN
------------------
A row in the timeline, at the position OG's operators expect it, and a
gate at the RUN rather than at the QUEUE.  The poller's verdict is a
cache — it flips ``action_decision`` on a cadence, and the paths that do
not go through the queue (a Today-page re-run, an Airflow/OTG trigger, a
cron fire that creates its own row) never re-ask.  Evaluating the ONE
resolver again at admission costs a read and closes that gap; it cannot
disagree with the poller except by being more current.

IT IS A GATE, SO IT FAILS
-------------------------
Unmet dependencies REFUSE the run naming each one and why (``StepRefused``
— a verdict, recorded as ``refused``, never retried).  A dependency whose
state could not be determined refuses too, with its own wording: "could
not tell" is not "no blockers", and folding the two together is how a
feed ships on the night the tracking table is unreadable.

Wired only when a feed's flow maps it — the step model's migration
guarantee is that no existing feed changes behaviour until somebody
declares it should.  Making it DERIVED for every feed with an ``etl_id``
is one line in the service and a behaviour change for the estate, so it
is the operator's call and is stated in the record rather than taken.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from typing import Any, List, Optional

from core.dataflow.base import CATEGORY_CONTROL, IDEMPOTENT_SAFE
from core.feed.step_model.contract import (
    ARTIFACT_ADMITTED,
    ARTIFACT_DEPENDENCIES,
    FeedPipelineStep,
    StepContext,
    StepRefused,
    StepResult,
)

logger = logging.getLogger(__name__)


def _as_date(value: Any) -> Optional[date]:
    """The run's business date as a ``date``, from whatever the run row
    carried (a date, a datetime, an ISO string) — or None."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str) and value.strip():
        try:
            return date.fromisoformat(value.strip()[:10])
        except ValueError:
            return None
    return None


class CheckDependencies(FeedPipelineStep):
    """Refuse the run unless every declared upstream dependency is met.

    ``IDEMPOTENT_SAFE`` and ``RERUNNABLE = True``, stated: the step reads
    tracking rows and compares them with a calendar.  It writes nothing
    and calls nothing external, so asking twice is the same question with
    (at most) a fresher answer — one of the few steps that can honestly
    say so.  ``MAX_ATTEMPTS = 1`` because a refusal is a verdict, not a
    transient; an operator who wants a periodic re-check has the
    dependency poller, which exists for exactly that.
    """
    NAME = "check_dependencies"
    DISPLAY_NAME = "Check Dependencies"
    DESCRIPTION = ("Consults the feed's dependency gate for the run's "
                   "business date and REFUSES the run naming every "
                   "dependency that is not met or could not be read.  "
                   "The same resolver the dependency poller and the run "
                   "surface use — this step records it at the run.")
    CATEGORY = CATEGORY_CONTROL
    REQUIRES = (ARTIFACT_ADMITTED,)
    PRODUCES = (ARTIFACT_DEPENDENCIES,)
    #: The extract must wait for the gate on feeds that HAVE one.  The
    #: extract cannot REQUIRE ``dependencies_cleared`` — on a feed with no
    #: dependencies nothing would produce it and the plan would refuse —
    #: so the gate declares itself BEFORE the extract, and the edge exists
    #: only in plans where both are present.  The spine never learns this
    #: step's name.
    BEFORE = ("source_extract",)
    #: In scope exactly when the feed declares dependencies (an
    #: ``etl_id``).  ``has_dependencies`` is a profile fact the planner
    #: can always resolve, so this predicate never refuses a plan.
    APPLIES_WHEN = {"has_dependencies": True}
    IDEMPOTENCY = IDEMPOTENT_SAFE
    RERUNNABLE = True
    MAX_ATTEMPTS = 1
    CONFIG_SCHEMA = {}

    def execute(self, ctx: StepContext) -> StepResult:
        # THE resolver for the key (2026-09-27): explicit etl_id, else the
        # feed's own id -- the key the authoring routes write mappings
        # under.  A feed record with neither is not a feed.
        from core.feed.etl_dependency import effective_etl_id
        try:
            etl_id = effective_etl_id(ctx.feed_config or {})
        except (KeyError, TypeError, ValueError):
            raise StepRefused(
                "the feed declares no etl_id and carries no id, so it has "
                "no dependency mappings to check — a gate mapped onto a "
                "feed with nothing to gate is a misconfiguration, not a "
                "pass")
        business_date = _as_date(ctx.business_date)
        if business_date is None:
            raise StepRefused(
                f"the run carries no usable business_date "
                f"({ctx.business_date!r}); a dependency is met FOR A DATE, "
                f"so there is nothing to evaluate against")
        if ctx.db is None:
            raise StepRefused(
                "no database handle reached the step, so the tracking rows "
                "cannot be read — refusing rather than reporting 'no "
                "blockers' about rows nobody looked at")

        # THE resolver.  Imported here, not copied: the poller, the run
        # surface, the reverse index and the ops API all call this exact
        # function, and a fifth caller must get the fifth identical answer.
        from core.feed.etl_dependency import evaluate_gate_verdicts

        gate = evaluate_gate_verdicts(ctx.db, int(etl_id), business_date)
        if gate is None:
            raise StepRefused(
                "the dependency gate module is not available on this "
                "build, so the dependencies could not be evaluated.  Unknown "
                "is not 'met'")

        unknown = list(gate.unknown)
        blocking = [v for v in gate.blocking if v.verdict != "could_not_tell"]
        if unknown:
            names = ", ".join(_describe(v) for v in unknown)
            raise StepRefused(
                f"{len(unknown)} of {len(gate.verdicts)} dependencies COULD "
                f"NOT BE READ for {business_date.isoformat()}: {names}.  "
                f"'Could not tell' is not 'no blockers'"
                + (f"; also NOT MET: "
                   + ", ".join(_describe(v) for v in blocking)
                   if blocking else ""))
        if blocking:
            names = ", ".join(_describe(v) for v in blocking)
            raise StepRefused(
                f"{len(blocking)} of {len(gate.verdicts)} dependencies NOT "
                f"MET for {business_date.isoformat()}: {names}")

        total = len(gate.verdicts)
        met = sum(1 for v in gate.verdicts if v.satisfies)
        outputs = {
            "etl_id": int(etl_id),
            "business_date": business_date.isoformat(),
            "total": total,
            "met": met,
            "asserted": bool(gate.asserted),
            "verdicts": [v.to_dict() for v in gate.verdicts],
            ARTIFACT_DEPENDENCIES: business_date.isoformat(),
        }
        if total == 0:
            message = (f"etl_id {etl_id} has 0 active dependency mappings "
                       f"— vacuously admitted (a readable EMPTY answer, "
                       f"not an unreadable one)")
        elif gate.asserted:
            message = (f"{met}/{total} met — proceeding on an operator "
                       f"ASSERTION, not on evidence alone")
        else:
            message = f"{met}/{total} dependencies met"
        return StepResult(outputs=outputs, message=message)


def _describe(verdict: Any) -> str:
    reason = getattr(verdict, "reason", "") or ""
    return f"{verdict.dependency_name} ({verdict.verdict}: {reason})"


__all__ = ["CheckDependencies"]
