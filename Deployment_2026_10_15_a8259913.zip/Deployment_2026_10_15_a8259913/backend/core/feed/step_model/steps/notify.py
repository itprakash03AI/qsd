"""A step whose re-run is genuinely unsafe — and says so.

``NotifyWebhook`` exists as much for the refusal as for the feature: it
is the case where "every prior step is green" is TRUE and re-running is
still wrong, because sending a message twice is a second message at the
recipient.  Rerunnability is a property of the step's SIDE EFFECTS, not
of its position in the sequence — the correction the 09-04 plan had to
make to itself.

The button is DISABLED with the reason, rather than offered and then
regretted.
"""
from __future__ import annotations

import json
import logging

from core.dataflow.base import CATEGORY_NOTIFY, IDEMPOTENT_UNSAFE
from core.feed.step_model.contract import (
    ARTIFACT_DELIVERED,
    FeedPipelineStep,
    StepContext,
    StepRefused,
    StepResult,
)

logger = logging.getLogger(__name__)


class NotifyWebhook(FeedPipelineStep):
    """POST a small JSON receipt to a URL once the file has landed."""
    #: NOT "notify_webhook": that is already the name of a
    #: feed_configs COLUMN (the feed-level failure notification),
    #: and two different things sharing one name is the trap this
    #: codebase keeps paying for.
    NAME = "webhook_receipt"
    DISPLAY_NAME = "Notify Webhook"
    DESCRIPTION = ("POSTs a JSON receipt (feed, business date, rows, "
                   "artifact) to a URL after delivery.")
    CATEGORY = CATEGORY_NOTIFY
    REQUIRES = (ARTIFACT_DELIVERED,)
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    #: Declared FALSE, explicitly.  Leaving it None would also refuse,
    #: but for the wrong reason — "nobody said" and "we thought about it
    #: and the answer is no" are different findings.
    RERUNNABLE = False
    MAX_ATTEMPTS = 3
    CONFIG_SCHEMA = {
        "url": {
            "type": "string", "required": True,
            "label": "Webhook URL",
            "help": "Where the receipt is POSTed.",
        },
        "timeout_seconds": {
            "type": "int", "required": False, "default": 10,
            "label": "Timeout (seconds)",
        },
    }

    def execute(self, ctx: StepContext) -> StepResult:
        import urllib.request

        url = str(ctx.params["url"])
        timeout = int(ctx.params.get("timeout_seconds") or 10)
        payload = {
            "feed": ctx.feed_config.get("name"),
            "feed_id": ctx.feed_config.get("id"),
            "business_date": (str(ctx.business_date)
                              if ctx.business_date else None),
            "rows": ctx.row_count,
            "artifacts": {k: str(v) for k, v in ctx.artifacts.items()
                          if k != "row_count"},
            "execution_id": ctx.execution_id,
            "attempt": ctx.attempt,
        }
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, method="POST",
            headers={"Content-Type": "application/json"})
        # 2026-09-13 security-hotspot triage (ruff S310).  ``url`` is a
        # STEP PARAMETER, and ``POST /api/feeds`` is
        # ``Depends(get_current_user)`` -- any authenticated user, not an
        # admin, can author the feed that supplies it.  This called
        # ``urllib.request.urlopen`` directly, so the backend would POST
        # wherever that user pointed it: internal services, and the cloud
        # metadata endpoint that hands out IAM credentials.  The failure
        # was visible to the author too -- the step raises the HTTP status
        # below -- which turns it into a working internal port scanner.
        # core/http_utils.open_checked applies the SAME url_safety gate and
        # the SAME no-redirect opener the other notification senders use;
        # a refusal raises, which this step already treats as a failure.
        from core.http_utils import open_checked
        with open_checked(req, timeout=timeout) as resp:
            status = int(getattr(resp, "status", 0) or 0)
        # A non-2xx is a FAILURE, not a warning.  A notification the
        # recipient never got, recorded as success, is the same defect as
        # an empty file that certifies VERIFIED.
        if not (200 <= status < 300):
            raise RuntimeError(
                f"webhook {url} answered HTTP {status}")
        return StepResult(outputs={"http_status": status},
                          message=f"HTTP {status}")


class NotifyEmail(FeedPipelineStep):
    """OG's ``SendEmailNotifications`` — a receipt e-mail once the file
    has landed, to recipients the STEP declares.

    ONE MAILER, AND IT IS NOT THE FEED'S ``notify_emails`` PATH
    ---------------------------------------------------------
    The product's SMTP path is ``core.email_service.send_email`` — the
    Clockwork notifier, the DataFlow notification policy and DataFlow's
    ``send_email`` stage all call it.  This step calls it too.

    It deliberately does NOT reuse the feed engine's own
    ``_send_notifications``: until 2026-09-15 that function enqueued a
    ``{"type": "email"}`` payload into ``pending_notifications``, whose
    only readers (``core/notification_poller.py``) broadcast rows to
    WebSocket clients.  Nothing dispatched that payload to SMTP, so a
    feed's ``notify_on_failure`` e-mail had never reached a mailbox.
    Found 2026-09-14 while wiring this step; the engine was pointed at
    ``send_email`` the next day and now records its verdict on the run
    (``stage_timings.notifications``).  The two remain separate
    senders on purpose: a run-outcome mail and a step-position receipt
    are different things, and both may fire on one run.

    This is OG's shape exactly: the pipeline-level start/finish e-mails
    are one thing (the engine's), and the operator's declared receipt at
    a step position is another.  Both may fire on one run.

    ``IDEMPOTENT_UNSAFE`` and ``RERUNNABLE = False``, like the webhook:
    a second send is a second e-mail in somebody's inbox.
    ``MAX_ATTEMPTS = 1`` because ``send_email`` already retries the SMTP
    conversation three times with backoff; a budget here on top would
    multiply that, and a partially-delivered attempt (accepted by the
    relay, then a timeout) is exactly the state a retry duplicates.
    """
    #: NOT "notify_emails" / "notify_email": ``feed_configs.notify_emails``
    #: is the engine's own recipient column, and the webhook step already
    #: paid for a step/column name clash once.
    NAME = "email_receipt"
    DISPLAY_NAME = "Notify Email"
    DESCRIPTION = ("Sends a delivery receipt e-mail (feed, business date, "
                   "rows, artifact) to the declared recipients after "
                   "delivery, through the product's SMTP service.")
    CATEGORY = CATEGORY_NOTIFY
    REQUIRES = (ARTIFACT_DELIVERED,)
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    RERUNNABLE = False
    MAX_ATTEMPTS = 1
    CONFIG_SCHEMA = {
        "recipients": {
            "type": "string", "required": False,
            "label": "Recipients",
            "help": ("Comma-separated addresses.  When empty, the feed's "
                     "own notify_emails are used; when BOTH are empty the "
                     "step refuses rather than 'sending' to nobody."),
        },
        "subject": {
            "type": "string", "required": False,
            "label": "Subject",
            "help": ("Optional.  Tokens: {feed} {business_date} {rows} "
                     "{execution_id}.  Default: "
                     "\"Feed '{feed}' delivered for {business_date}\"."),
        },
    }

    _DEFAULT_SUBJECT = "Feed '{feed}' delivered for {business_date}"

    def _recipients(self, ctx: StepContext):
        raw = str(ctx.params.get("recipients") or "").strip()
        source = "step parameter 'recipients'"
        if not raw:
            raw = str(ctx.feed_config.get("notify_emails") or "").strip()
            source = "the feed's notify_emails"
        out = [a.strip() for a in raw.split(",") if a.strip()]
        if not out:
            raise StepRefused(
                "no recipients: the step's 'recipients' parameter is empty "
                "and the feed declares no notify_emails.  A receipt nobody "
                "receives recorded as sent is the defect this step exists "
                "to avoid")
        return out, source

    def execute(self, ctx: StepContext) -> StepResult:
        recipients, source = self._recipients(ctx)
        tokens = {
            "feed": ctx.feed_config.get("name") or ctx.feed_config.get("id"),
            "business_date": (str(ctx.business_date)
                              if ctx.business_date else "-"),
            "rows": ctx.row_count if ctx.row_count is not None else "-",
            "execution_id": ctx.execution_id or "-",
        }
        subject_tpl = str(ctx.params.get("subject") or self._DEFAULT_SUBJECT)
        try:
            subject = subject_tpl.format(**tokens)
        except (KeyError, IndexError, ValueError) as exc:
            raise StepRefused(
                f"subject template {subject_tpl!r} could not be rendered "
                f"({type(exc).__name__}: {exc}); known tokens: "
                f"{sorted(tokens)}")
        delivered = ctx.artifact(ARTIFACT_DELIVERED)
        lines = [
            f"Feed: {tokens['feed']}",
            f"Business date: {tokens['business_date']}",
            f"Rows: {tokens['rows']}",
            f"Delivered: {delivered}",
            f"Execution: {tokens['execution_id']} (attempt {ctx.attempt})",
        ]
        text_body = "\n".join(lines)
        html_body = "<pre>" + "\n".join(
            _escape(line) for line in lines) + "</pre>"

        # THE mailer.  ``send_email`` returns a bool and never raises; a
        # False is a FAILURE here, not a note — a receipt the recipient
        # never got, recorded as success, is the empty-file-certified-
        # VERIFIED defect wearing a different hat.
        from core.email_service import (NOT_CONFIGURED_REASON,
                                        is_email_enabled, send_email)

        if not is_email_enabled():
            raise RuntimeError(
                f"{NOT_CONFIGURED_REASON} — the receipt cannot be sent, and "
                f"a step that says 'sent' when the relay was never dialled "
                f"would be lying")
        sent = send_email(to_addresses=recipients, subject=subject,
                          html_body=html_body, text_body=text_body)
        if not sent:
            raise RuntimeError(
                f"send_email returned False for {recipients} — the SMTP "
                f"conversation failed after its own retries, or every "
                f"address was rejected by validation")
        return StepResult(
            outputs={"recipients": recipients, "recipients_source": source,
                     "subject": subject, "sent": True},
            message=f"sent to {len(recipients)} recipient(s) ({source})")


def _escape(text: str) -> str:
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))
