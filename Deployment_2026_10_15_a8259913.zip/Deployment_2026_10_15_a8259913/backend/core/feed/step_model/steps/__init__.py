"""Where step classes live.  Drop a file in here; that is the whole
registration ritual.

Two kinds live side by side, and the difference is ``EXECUTOR``:

* ``spine.py`` declares the work the FEED ENGINE already does.  Those
  steps are not executed here — the engine does the work and the
  recorder flips their rows.  They exist so a plan covers ALL of what
  happens rather than only what somebody added, which is BRD §20 step
  P4 / the 09-04 plan's D1(a): "the flow shows all of what happens".
* the rest are ``EXECUTOR = "runner"`` steps that
  ``core/feed/step_model/runner.py`` actually calls.  A new one is a file
  in this folder or a row in ``feed_custom_step_types``.

Discovery imports every module here at boot
(:meth:`core.feed.step_model.registry.StepRegistry.discover`), per-module
fail-isolated, and a module that will not import leaves a TOMBSTONE so a
flow mapping it refuses BY NAME rather than planning a run without it.
"""
