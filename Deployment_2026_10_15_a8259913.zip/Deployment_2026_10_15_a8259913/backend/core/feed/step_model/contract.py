"""What a feed pipeline step DECLARES, and what it receives when it runs.

Everything an author writes about a step is a declaration on the class.
Nothing about a step's position, its order, or the feeds it applies to is
written procedurally anywhere — that is the whole point, and it is what
lets a new step be a file dropped in a folder (or a row in
``feed_custom_step_types``) rather than an edit to an 8,223-line engine.

THE IDEMPOTENCY VOCABULARY IS IMPORTED, NOT DECLARED
----------------------------------------------------
``IDEMPOTENT_SAFE / OVERWRITE / CONFIGURED / UNSAFE`` come from
:mod:`core.dataflow.base`.  Two engines is fine; two answers to "is this
safe to re-run" is not, and a second copy of that vocabulary would drift
the way OG's status CHECK constraints drifted across two tables.

RE-RUN SAFETY IS DECLARED, AND UNDECLARED MEANS UNSAFE
-------------------------------------------------------
``RERUNNABLE`` is tri-state on purpose: ``True`` / ``False`` /
``None``.  ``None`` is "never said", and it resolves to *not rerunnable*
with a reason that says so.  A default of ``False`` would be safe but
would look identical to a considered ``False``, and the diagnosis
"nobody declared this" is the one that gets fixed.  OG defaulted
``RETRY_SAFE`` to True by inheritance; a step that mutated external state
and forgot to declare was retried after a driver call-timeout and moved
the same staging rows into production a second time — 50 million
duplicate rows.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, List, Mapping, Optional, Sequence, Tuple

from core.dataflow.base import (
    CATEGORY_CONTROL,
    CATEGORY_NOTIFY,
    CATEGORY_QUALITY,
    CATEGORY_SINK,
    CATEGORY_SOURCE,
    CATEGORY_TRANSFORM,
    IDEMPOTENT_CONFIGURED,
    IDEMPOTENT_OVERWRITE,
    IDEMPOTENT_SAFE,
    IDEMPOTENT_UNSAFE,
)
from core.db.models import FEED_STEP_EXECUTORS

logger = logging.getLogger(__name__)

#: The contract version a step is built against.  A step declaring
#: anything else is refused at registration rather than half-run — the
#: three-outcome lesson ``core/feed/steps/__init__.py`` already learned.
CONTRACT = "qs-feed-step/1"

_VALID_IDEMPOTENCY = frozenset({
    IDEMPOTENT_SAFE, IDEMPOTENT_OVERWRITE,
    IDEMPOTENT_CONFIGURED, IDEMPOTENT_UNSAFE,
})

_VALID_CATEGORIES = frozenset({
    CATEGORY_SOURCE, CATEGORY_TRANSFORM, CATEGORY_SINK,
    CATEGORY_CONTROL, CATEGORY_QUALITY, CATEGORY_NOTIFY,
})

_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


# ── The artifact namespace ─────────────────────────────────────────────
#
# OPEN, not closed.  A plugin step may produce ``sap_extract`` and
# another may require it, and neither needs a change here — that is what
# "very generic" has to mean if a new workflow is to arrive as a plugin.
# The constants below are only the kinds the BUILT-IN spine uses; they
# exist so the built-ins and the planner spell them identically and a
# typo is an import error rather than a step that never runs.
#
# An unproduced requirement is a PLAN REFUSAL naming the step and the
# artifact — never a step silently dropped.  Dropping a step because its
# input has no producer is how a quality gate disappears.

ARTIFACT_DEPENDENCIES = "dependencies_cleared"
ARTIFACT_ADMITTED = "run_admitted"
ARTIFACT_EXTRACT = "extract"
ARTIFACT_ROW_COUNT = "row_count"
ARTIFACT_FORMATTED_FILE = "formatted_file"
ARTIFACT_PACKAGED_FILE = "packaged_file"
ARTIFACT_CHECKSUM = "checksum"
ARTIFACT_CONTROL_FILE = "control_file"
ARTIFACT_DELIVERED = "delivered"
ARTIFACT_CERTIFIED = "certified"


# ── Exceptions ─────────────────────────────────────────────────────────


class StepRefused(Exception):
    """A correctness gate said no.

    Distinct from an ordinary exception ON PURPOSE: a refusal is a
    verdict the step reached deliberately (``0 rows, floor is 1``),
    while an exception is something that broke.  Both halt the run; they
    lead to opposite investigations, so they are recorded under
    different statuses (``refused`` / ``failed``).
    """


class PredicateError(ValueError):
    """An ``APPLIES_WHEN`` predicate could not be EVALUATED.

    Raised for an unknown operator, a malformed clause, or a fact the
    profile does not carry.  Deliberately NOT the same as "the predicate
    evaluated to False": an unrecognised spelling and a deliberate
    refusal are indistinguishable if both fail open, and this repo has
    already paid for that once — ``equals`` was classified 'unsupported'
    and the most selective partition predicate produced no island on
    every raw-SQL query.
    """


# ── The declarative predicate ──────────────────────────────────────────
#
# Small on purpose.  It has to be expressible as JSON (so a DB-registered
# plugin carries its own scoping rule), renderable in a UI, and
# explainable to an operator asking "why did this step not run".  Any
# operator it does not know REFUSES rather than guessing.

_OPERATORS = ("$eq", "$ne", "$in", "$nin", "$exists", "$truthy", "$gte", "$lte")


def _clause_matches(fact_name: str, clause: Any, profile_facts: Mapping[str, Any],
                    unknown: frozenset) -> bool:
    if fact_name not in profile_facts:
        raise PredicateError(
            f"predicate names fact {fact_name!r}, which this run's profile "
            f"does not carry.  Known facts: {sorted(profile_facts)}")
    if fact_name in unknown:
        raise PredicateError(
            f"predicate names fact {fact_name!r}, whose value could NOT be "
            f"resolved for this run.  Unknown is not False: refusing the "
            f"plan rather than silently dropping the step.")
    value = profile_facts[fact_name]
    if isinstance(clause, dict):
        if not clause:
            raise PredicateError(
                f"empty operator object for fact {fact_name!r} — an empty "
                f"clause would match everything, which is never what it "
                f"was written to mean")
        for op, operand in clause.items():
            if op not in _OPERATORS:
                raise PredicateError(
                    f"unknown operator {op!r} on fact {fact_name!r}; "
                    f"supported: {list(_OPERATORS)}")
            if op == "$eq" and value != operand:
                return False
            if op == "$ne" and value == operand:
                return False
            if op == "$in" and value not in (operand or []):
                return False
            if op == "$nin" and value in (operand or []):
                return False
            if op == "$exists" and bool(value is not None) != bool(operand):
                return False
            if op == "$truthy" and bool(value) != bool(operand):
                return False
            if op == "$gte":
                if value is None or value < operand:
                    return False
            if op == "$lte":
                if value is None or value > operand:
                    return False
        return True
    if isinstance(clause, (list, tuple)):
        return value in clause
    return value == clause


def evaluate_predicate(predicate: Optional[Mapping[str, Any]],
                       profile_facts: Mapping[str, Any],
                       unknown: Sequence[str] = ()) -> bool:
    """Does *predicate* hold for these profile facts?

    ``{}`` / ``None`` means ALWAYS — a step with no scoping rule is in
    scope for every feed, which is right for the spine.

    Raises :class:`PredicateError` rather than returning False for
    anything it cannot evaluate.
    """
    if not predicate:
        return True
    if not isinstance(predicate, Mapping):
        raise PredicateError(
            f"predicate must be an object, got {type(predicate).__name__}")
    unk = frozenset(unknown or ())
    for key, clause in predicate.items():
        if key == "$all":
            if not all(evaluate_predicate(p, profile_facts, unk) for p in clause):
                return False
        elif key == "$any":
            if not clause:
                raise PredicateError("$any with no clauses can never match")
            if not any(evaluate_predicate(p, profile_facts, unk) for p in clause):
                return False
        elif key == "$not":
            if evaluate_predicate(clause, profile_facts, unk):
                return False
        elif key.startswith("$"):
            raise PredicateError(
                f"unknown top-level operator {key!r}; supported: "
                f"$all, $any, $not")
        else:
            if not _clause_matches(key, clause, profile_facts, unk):
                return False
    return True


def predicate_facts(predicate: Optional[Mapping[str, Any]]) -> Tuple[str, ...]:
    """Every profile fact *predicate* reads.

    Used at REGISTRATION to refuse a step whose predicate names a fact
    that does not exist — the ``run_id=969000`` lesson: resolve the whole
    routing decision before running, not at dispatch time having already
    burned the budget.
    """
    if not predicate or not isinstance(predicate, Mapping):
        return ()
    out: List[str] = []
    for key, clause in predicate.items():
        if key in ("$all", "$any"):
            for p in clause or []:
                out.extend(predicate_facts(p))
        elif key == "$not":
            out.extend(predicate_facts(clause))
        elif not key.startswith("$"):
            out.append(key)
    return tuple(dict.fromkeys(out))


# ── Execution surface ──────────────────────────────────────────────────


@dataclass(frozen=True)
class StepResult:
    """What a step hands back.

    ``rows_out`` is the operator's "total record count if its Cloud to
    file".  It is not merely logged: it lands on the step row AND becomes
    the ``row_count`` artifact later steps read, so a count computed for
    one purpose cannot disagree with the count another purpose uses.
    """
    rows_out: Optional[int] = None
    outputs: Dict[str, Any] = field(default_factory=dict)
    message: Optional[str] = None


@dataclass
class StepContext:
    """Everything a step is given.  Read-only by convention.

    ``artifacts`` is the live map of what the run has produced so far —
    ``{kind: value}``.  A step that declared ``REQUIRES`` is guaranteed
    every kind it named is present, because the planner refuses a plan
    where it would not be.
    """
    feed_config: Mapping[str, Any]
    feed_run: Mapping[str, Any]
    business_date: Any
    params: Mapping[str, Any]
    artifacts: Dict[str, Any]
    alias: str
    attempt: int = 1
    execution_id: str = ""
    logger: Any = None
    #: The database manager the runner is executing under, for a step
    #: that CONSULTS an existing resolver (the dependency gate reads the
    #: tracking rows).  Optional so a pure step is constructible without
    #: one; a step that needs it and finds None must refuse, not guess.
    db: Any = None

    @property
    def row_count(self) -> Optional[int]:
        """The run's current row count, from the artifact map."""
        v = self.artifacts.get(ARTIFACT_ROW_COUNT)
        return int(v) if isinstance(v, (int, float)) else None

    def artifact(self, kind: str) -> Any:
        """One declared input.  Raises when the kind was not declared —
        reading an undeclared artifact would work by accident until the
        planner reordered the graph."""
        if kind not in self.artifacts:
            raise KeyError(
                f"step {self.alias!r} read artifact {kind!r}, which is not "
                f"available.  Declare it in REQUIRES so the planner orders "
                f"this step after its producer (available: "
                f"{sorted(self.artifacts)}).")
        return self.artifacts[kind]


# ── The base class ─────────────────────────────────────────────────────


class FeedPipelineStep:
    """Subclass, declare, drop the file in ``core/feed/step_model/steps/``.

    The class attributes ARE the registration.  ``__init_subclass__``
    validates them at import time, so a step that declares nonsense fails
    where it is written rather than at 03:00 on the night it first
    matches a feed.
    """

    NAME: ClassVar[str] = ""
    DISPLAY_NAME: ClassVar[str] = ""
    DESCRIPTION: ClassVar[str] = ""
    CATEGORY: ClassVar[str] = CATEGORY_QUALITY
    CONTRACT: ClassVar[str] = CONTRACT

    #: Artifact kinds consumed / produced.  The planner uses ONLY these.
    REQUIRES: ClassVar[Tuple[str, ...]] = ()
    PRODUCES: ClassVar[Tuple[str, ...]] = ()

    #: Ordering the artifact graph genuinely cannot express — named step
    #: types this one must follow.  A step naming another step is a
    #: coupling, so it is the exception; artifacts are the rule.
    AFTER: ClassVar[Tuple[str, ...]] = ()

    #: The mirror of ``AFTER``: named step types that must follow THIS
    #: one, when they are in the plan.  It exists for the OPTIONAL
    #: predecessor, which artifacts cannot spell: a gate that is in scope
    #: for some feeds must precede the extract on those feeds, but the
    #: extract cannot REQUIRE the gate's artifact — on every other feed
    #: nothing would produce it and the plan would refuse.  Declared on
    #: the dropped-in step, so the spine never learns a plugin's name;
    #: an edge is added only when the named type is actually planned.
    #: (2026-09-14, for OG's CheckDependencies at SEQ 1.)
    BEFORE: ClassVar[Tuple[str, ...]] = ()

    #: The declarative scoping rule.  ``{}`` = every feed.
    APPLIES_WHEN: ClassVar[Dict[str, Any]] = {}

    #: The parameter declaration.  ``{name: {"type": ..., "required":
    #: bool, "help": str, ...}}`` — the UI renders THIS.
    CONFIG_SCHEMA: ClassVar[Dict[str, Any]] = {}

    IDEMPOTENCY: ClassVar[str] = IDEMPOTENT_UNSAFE
    #: Tri-state.  None = undeclared = NOT rerunnable, loudly.
    RERUNNABLE: ClassVar[Optional[bool]] = None
    MAX_ATTEMPTS: ClassVar[int] = 1

    #: ``engine`` — the work already happens inside ``core/feed_engine``
    #: and this class only DECLARES it so it can be planned, recorded and
    #: shown.  ``runner`` — ``core/feed/step_model/runner.py`` calls
    #: ``execute``.
    EXECUTOR: ClassVar[str] = "runner"

    #: For ``EXECUTOR == "engine"``: which of the engine's own stages
    #: fulfil this step.  An entry is either a stage TYPE (``"query"``,
    #: matching every ``query_*``) or ``"type/alias"``
    #: (``"integrity/local"``, matching only ``integrity_local``).
    #:
    #: Types rather than literal names because the engine's stage names
    #: are parameterised — ``deliver_sftp``, ``format_csv``, and one per
    #: backend — and the classifier that splits a name into
    #: ``(type, alias)`` already exists in
    #: ``core.feed.steps_view.classify_step``.  It is CALLED, not
    #: re-implemented: a second copy would disagree the first time
    #: someone added a prefix, and both answers would look right.
    ENGINE_STAGE_TYPES: ClassVar[Tuple[str, ...]] = ()

    @classmethod
    def marker_artifacts(cls) -> Tuple[str, ...]:
        """The PRODUCES kinds whose value IS the fact that this step
        completed.

        A CONTROL step produces no bytes: ``run_admitted`` is not a file,
        it is the admission having happened.  So when a CONTROL engine
        step's stage closes, the recorder publishes each declared kind
        that the engine did not, valued with the stage name.  Every other
        category publishes REAL values from the engine (a path, a count, a
        URI), and a missing one STAYS missing — a placeholder path would
        satisfy the runner's readiness check and blow up inside the step,
        and a placeholder count would turn "never produced, step skipped
        with that reason" into "produced, step refused", a behaviour
        change for every mapped feed.

        2026-09-14: ``run_admitted`` was declared on 09-05 and nothing
        ever published it, so a step at OG's SEQ 1 (requiring only the
        admission) could be planned, recorded, and never become ready —
        closed ``skipped`` at the end of a run it was meant to gate.
        """
        if cls.CATEGORY != CATEGORY_CONTROL:
            return ()
        return tuple(cls.PRODUCES or ())

    @classmethod
    def matches_engine_stage(cls, stage_name: str) -> bool:
        """Does the engine stage *stage_name* fulfil this step?"""
        if not cls.ENGINE_STAGE_TYPES:
            return False
        from core.feed.steps_view import classify_step
        type_, alias = classify_step(str(stage_name or ""))
        for pattern in cls.ENGINE_STAGE_TYPES:
            if "/" in pattern:
                want_type, want_alias = pattern.split("/", 1)
                if type_ == want_type and alias == want_alias:
                    return True
            elif type_ == pattern:
                return True
        return False

    # ── identity / manifest ────────────────────────────────────────────

    @classmethod
    def class_path(cls) -> str:
        return f"{cls.__module__}.{cls.__name__}"

    @classmethod
    def get_display_name(cls) -> str:
        return cls.DISPLAY_NAME or (cls.NAME or "").replace("_", " ").title()

    @classmethod
    def manifest(cls) -> Dict[str, Any]:
        """The catalogue row.  A SUPERSET of ``BaseStage.manifest()``'s
        keys so one UI form renderer serves both catalogues."""
        return {
            "name": cls.NAME,
            "display_name": cls.get_display_name(),
            "category": cls.CATEGORY,
            "class_path": cls.class_path(),
            "description": cls.DESCRIPTION,
            "config_schema": dict(cls.CONFIG_SCHEMA or {}),
            "requires": list(cls.REQUIRES or ()),
            "produces": list(cls.PRODUCES or ()),
            "applies_when": dict(cls.APPLIES_WHEN or {}),
            "after": list(cls.AFTER or ()),
            "before": list(cls.BEFORE or ()),
            "idempotency": cls.IDEMPOTENCY,
            "rerunnable": cls.RERUNNABLE,
            "executor": cls.EXECUTOR,
            "max_attempts": int(cls.MAX_ATTEMPTS or 1),
        }

    # ── hooks ──────────────────────────────────────────────────────────

    @classmethod
    def validate_params(cls, params: Mapping[str, Any]) -> List[str]:
        """Problems with *params*, as strings.  Empty list = valid.

        The base implementation enforces the ``CONFIG_SCHEMA``'s
        ``required`` flags and its declared types.  Override to ADD
        cross-field checks; call ``super()`` to keep the schema ones.
        """
        problems: List[str] = []
        schema = cls.CONFIG_SCHEMA or {}
        for key, decl in schema.items():
            if not isinstance(decl, Mapping):
                continue
            present = key in (params or {}) and params.get(key) is not None
            if decl.get("required") and not present:
                problems.append(
                    f"{cls.NAME}: required parameter '{key}' is missing"
                    + (f" ({decl['help']})" if decl.get("help") else ""))
                continue
            if not present:
                continue
            want = decl.get("type")
            val = params.get(key)
            if want in ("int", "integer"):
                if isinstance(val, bool) or not isinstance(val, int):
                    problems.append(
                        f"{cls.NAME}: parameter '{key}' must be an integer, "
                        f"got {type(val).__name__}")
            elif want == "bool":
                if not isinstance(val, bool):
                    problems.append(
                        f"{cls.NAME}: parameter '{key}' must be a boolean, "
                        f"got {type(val).__name__}")
            elif want == "choice":
                choices = decl.get("choices") or []
                if val not in choices:
                    problems.append(
                        f"{cls.NAME}: parameter '{key}'={val!r} is not one "
                        f"of {list(choices)}")
        unknown = sorted(set(params or {}) - set(schema))
        if unknown:
            problems.append(
                f"{cls.NAME}: parameter(s) {unknown} are not declared in "
                f"CONFIG_SCHEMA — a value nothing reads is a typo that "
                f"looks like configuration")
        return problems

    def execute(self, ctx: StepContext) -> StepResult:
        """Do the work.  Only called for ``EXECUTOR == 'runner'``.

        Raise :class:`StepRefused` for a correctness verdict; raise
        anything else for a failure.  Both halt the run — OG halts on
        first failure and re-raises so cleanup and the failure email
        fire, and that is the right shape.
        """
        raise NotImplementedError(
            f"{type(self).__name__} declares EXECUTOR='runner' but does not "
            f"implement execute()")

    # ── definition-time validation ─────────────────────────────────────

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if not cls.NAME:
            return                       # abstract intermediate, deliberate
        if not _NAME_RE.match(cls.NAME):
            raise TypeError(
                f"{cls.__name__}: NAME {cls.NAME!r} must match "
                f"[a-z][a-z0-9_]* (max 64)")
        if cls.CATEGORY not in _VALID_CATEGORIES:
            raise TypeError(
                f"{cls.__name__}: CATEGORY {cls.CATEGORY!r} not in "
                f"{sorted(_VALID_CATEGORIES)}")
        if cls.IDEMPOTENCY not in _VALID_IDEMPOTENCY:
            raise TypeError(
                f"{cls.__name__}: IDEMPOTENCY {cls.IDEMPOTENCY!r} not in "
                f"{sorted(_VALID_IDEMPOTENCY)}")
        if cls.EXECUTOR not in FEED_STEP_EXECUTORS:
            raise TypeError(
                f"{cls.__name__}: EXECUTOR {cls.EXECUTOR!r} not in "
                f"{list(FEED_STEP_EXECUTORS)}")
        if cls.RERUNNABLE not in (True, False, None):
            raise TypeError(
                f"{cls.__name__}: RERUNNABLE must be True, False or None "
                f"(None = undeclared = not rerunnable)")
        if cls.EXECUTOR == "engine" and not cls.ENGINE_STAGE_TYPES:
            raise TypeError(
                f"{cls.__name__}: EXECUTOR='engine' with no "
                f"ENGINE_STAGE_TYPES declares a step nothing can ever "
                f"fulfil — it would sit at not_started for the life of "
                f"every run")
        if cls.EXECUTOR == "runner" and cls.ENGINE_STAGE_TYPES:
            raise TypeError(
                f"{cls.__name__}: ENGINE_STAGE_TYPES is meaningless for "
                f"EXECUTOR='runner' — the runner calls execute(); "
                f"declaring both hides which one actually happens")
        if not cls.PRODUCES and cls.CATEGORY != CATEGORY_QUALITY \
                and cls.CATEGORY != CATEGORY_NOTIFY:
            raise TypeError(
                f"{cls.__name__}: declares no PRODUCES.  Only a quality "
                f"or notify step legitimately produces nothing; anything "
                f"else nothing can depend on is unreachable in the graph")
        if cls.NAME in set(cls.AFTER or ()) | set(cls.BEFORE or ()):
            raise TypeError(
                f"{cls.__name__}: AFTER/BEFORE names the step itself — a "
                f"step cannot be ordered against itself")
        overlap = set(cls.REQUIRES) & set(cls.PRODUCES)
        if overlap:
            raise TypeError(
                f"{cls.__name__}: REQUIRES and PRODUCES both name "
                f"{sorted(overlap)} — a step cannot depend on itself")
        try:
            _ = predicate_facts(cls.APPLIES_WHEN)
        except PredicateError as exc:
            raise TypeError(f"{cls.__name__}: APPLIES_WHEN invalid: {exc}")


# ── The re-run verdict — ONE place, and it answers with a REASON ───────


@dataclass(frozen=True)
class RerunVerdict:
    allowed: bool
    reason: str


def rerun_verdict(manifest: Mapping[str, Any],
                  params: Optional[Mapping[str, Any]] = None,
                  *, blocking_alias: Optional[str] = None,
                  blocking_status: Optional[str] = None) -> RerunVerdict:
    """May this step be re-run?  Resolved ONCE, with the reason kept.

    Two independent conditions, and BOTH must hold.  Position in the
    sequence alone is not sufficient — that was the proposal the
    09-04 plan retracted: a step can have a perfectly green prefix and
    still be unsafe to run twice, because rerunnability is a property of
    the step's SIDE EFFECTS.

    * the prefix is green (the caller passes the first offender, if any);
    * the step DECLARED itself safe.

    A value computed for a gate and then thrown away disagrees with what
    the system does, so the reason travels with the verdict and is what
    the UI shows on the disabled button.
    """
    if blocking_alias:
        return RerunVerdict(False, (
            f"step '{blocking_alias}' is {blocking_status or 'not green'} — "
            f"a step may only be re-run when every step it depends on "
            f"completed green in its latest attempt"))
    executor = manifest.get("executor")
    if executor == "engine":
        return RerunVerdict(False, (
            "this step is executed INSIDE the feed engine and its state "
            "lives in the engine's local variables — there is nothing to "
            "resume from, so re-running it means re-running the feed. "
            "Offering a button here would be a lie"))
    declared = manifest.get("rerunnable")
    if declared is None:
        return RerunVerdict(False, (
            f"step type '{manifest.get('name')}' never declared RERUNNABLE. "
            f"Undeclared means UNSAFE — OG defaulted retry-safety to true "
            f"and a non-idempotent step was retried into 50 million "
            f"duplicate rows"))
    if declared is False:
        return RerunVerdict(False, (
            f"step type '{manifest.get('name')}' declares RERUNNABLE = "
            f"False"))
    idem = manifest.get("idempotency")
    if idem == IDEMPOTENT_UNSAFE:
        return RerunVerdict(False, (
            f"step type '{manifest.get('name')}' declares idempotency "
            f"'{IDEMPOTENT_UNSAFE}' — re-running it repeats an external "
            f"side effect.  RERUNNABLE=True does not override this; the "
            f"two declarations contradict each other and the STRICTER "
            f"one wins"))
    if idem == IDEMPOTENT_CONFIGURED:
        safe_key = (manifest.get("config_schema") or {}) \
            .get("_rerun_safe_when", {})
        want = safe_key.get("equals") if isinstance(safe_key, Mapping) else None
        field_name = safe_key.get("param") if isinstance(safe_key, Mapping) else None
        if not field_name:
            return RerunVerdict(False, (
                f"step type '{manifest.get('name')}' declares idempotency "
                f"'{IDEMPOTENT_CONFIGURED}' — whether a re-run is safe "
                f"depends on its parameters — but the step names no "
                f"parameter to decide it.  Cannot tell means unsafe"))
        actual = (params or {}).get(field_name)
        if actual != want:
            return RerunVerdict(False, (
                f"step '{manifest.get('name')}' is re-runnable only when "
                f"parameter '{field_name}' is {want!r}; this instance has "
                f"{actual!r}"))
    return RerunVerdict(True, "declared re-runnable and every prior step is green")


__all__ = [
    "ARTIFACT_ADMITTED",
    "ARTIFACT_CERTIFIED",
    "ARTIFACT_CHECKSUM",
    "ARTIFACT_CONTROL_FILE",
    "ARTIFACT_DELIVERED",
    "ARTIFACT_DEPENDENCIES",
    "ARTIFACT_EXTRACT",
    "ARTIFACT_FORMATTED_FILE",
    "ARTIFACT_PACKAGED_FILE",
    "ARTIFACT_ROW_COUNT",
    "CONTRACT",
    "FeedPipelineStep",
    "PredicateError",
    "RerunVerdict",
    "StepContext",
    "StepRefused",
    "StepResult",
    "evaluate_predicate",
    "predicate_facts",
    "rerun_verdict",
]
