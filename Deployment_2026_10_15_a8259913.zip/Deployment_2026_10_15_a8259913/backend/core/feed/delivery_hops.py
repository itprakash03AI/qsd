"""Foundation M — delivery as independently retryable hops over a certified manifest.

BRD 2026-09-02 §11 (FR-DEL-01..06, FR-DEL-13), §10.2, §19 H1.

Why this module exists (H1, a LIVE hazard): on the Spark lane delivery
happens INSIDE the job, and the reconciler resubmits a failed CR once.
A job that delivered over SFTP and then died before its webhook landed
presents as FAILED, is resubmitted, and delivers a regulatory file to a
counterparty a SECOND time.  No declaration can prevent that while the
retry unit (the whole pod) contains the non-idempotent act.  The
structural fix is here: delivery leaves generation and becomes a chain
of hops that CONSUME a certified parts manifest — the pod becomes
retry-safe by construction because it no longer delivers anything.

The shape (FR-DEL-01):

    certified manifest
      -> materialise to NFS path     (local target)
      -> SFTP to counterparty        (sftp target)
      -> archive to S3               (lifecycle target)
      -> control file + checksum sidecar

Design rules, each load-bearing:

  * A hop NEVER regenerates data.  There is no generation callable
    anywhere in this module's seams — a transport receives the manifest
    and the already-built artifact, nothing else.
  * Each hop has its own status, retry policy and re-run (FR-DEL-02).
    A failed SFTP hop leaves the local hop's success intact; re-running
    the SFTP hop alone is the NORMAL path, not a special request.
  * Every attempt row NAMES the manifest version it sent (FR-DEL-04) —
    a re-delivery after a regeneration would otherwise silently send
    different bytes under the same name.  A regeneration mints a NEW
    build id, hence a NEW manifest version, so the two are always
    distinguishable in the record.
  * Idempotency is DECLARED per target, never assumed (FR-DEL-05).
    ``local``/``s3`` are overwrite-idempotent (same bytes to the same
    name — repeating is harmless); ``sftp``/``oracle`` are NOT and are
    NEVER auto-retried.  An unknown target has no traits and is refused.
  * Where we cannot tell whether a non-idempotent hop already ran (an
    attempt row stuck in ``running`` — a pod died mid-send), we say so
    and REFUSE rather than repeat.  There is deliberately no ``force``
    flag: the honest escape hatch is ``mark_attempt_lost`` — a human
    verifies out-of-band that nothing landed, records that verdict with
    their name on it, and only then is a manual retry possible.
  * Delivery is suppressible per feed, per environment, from POLICY
    (config), never by editing the feed definition (FR-DEL-06).
  * Artifact preparation order is fixed by the engine, not chosen per
    run: package -> compress -> encrypt -> checksum (§10.2).  The
    checksum covers the bytes that are actually SENT — a digest taken
    before compression or encryption describes bytes the counterparty
    never receives.
  * Acknowledgment is a state on the delivery record (FR-DEL-13):
    expected / received / rejected / not-required, declared per target.

Everything is pure logic over two injected seams:

  * ``db`` — an object with the FeedsMixin delivery-attempt methods
    (``insert_delivery_attempt`` / ``update_delivery_attempt`` /
    ``list_delivery_attempts`` / ``get_delivery_attempt``);
  * ``transports`` — a mapping ``{hop label or target type: callable}``.
    A transport takes ``(hop, manifest)`` and returns a mapping with
    ``uri`` and optionally ``bytes_sent``, ``files_sent``, ``checksum``,
    ``sent_path``, ``verification``, ``verification_detail``,
    ``endpoint_ref``.  It raises on failure.

No live SFTP, S3 or Postgres is ever touched from here.
"""
from __future__ import annotations

import logging
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

# Single-sourced vocabularies — the DB CHECK constraints are built from
# these same tuples (core/db/models.py), so code and schema cannot drift.
from core.db.models import DELIVERY_ACK_STATES, DELIVERY_ATTEMPT_STATUSES
from core.feed.checksum import compute_file_checksum

logger = logging.getLogger(__name__)

# ── statuses (closed vocabulary; mirrors delivery_attempts CHECK) ──────────
RUNNING = "running"
SUCCEEDED = "succeeded"
FAILED = "failed"
REFUSED = "refused"
SUPPRESSED = "suppressed"
SKIPPED = "skipped"

# ── acknowledgment states (FR-DEL-13; mirrors the CHECK) ───────────────────
ACK_EXPECTED = "expected"
ACK_RECEIVED = "received"
ACK_REJECTED = "rejected"
ACK_NOT_REQUIRED = "not_required"

#: §10.2 — the fixed artifact preparation order.  The checksum is LAST
#: because it must cover what is sent, not a pre-compression form.
ARTIFACT_STEP_ORDER = ("package", "compress", "encrypt", "checksum")


class DeliveryHopError(Exception):
    """Base class for every refusal this module makes."""


class ManifestNotCertified(DeliveryHopError):
    """The manifest is not certified complete — delivering it would ship
    a partial (or still-moving) part list under a real filename."""


class UnknownDeliveryTarget(DeliveryHopError):
    """No declared traits for this target.  Idempotency is declared,
    never assumed (FR-DEL-05) — an undeclared target cannot be delivered
    to, because we cannot know whether repeating it is safe."""


class DeliveryRefused(DeliveryHopError):
    """A hop that must not run: already delivered on a non-idempotent
    target, outcome indeterminate, or prerequisite unmet."""


class DeliveryChainFailed(DeliveryHopError):
    """The chain RAN and the artifact did not reach every declared
    destination (2026-09-15).

    Raised by the CONSUMER of :meth:`DeliveryHopRunner.execute_chain`
    (the engine), never by the runner: the runner's record-and-continue
    semantics are correct for a multi-hop chain (a failed hop is written
    down and later independent hops still run, FR-DEL-02).  What was
    missing was the question nobody asked afterwards -- did the delivery
    HAPPEN?  ``chain_verdict`` answers it; this is what the answer "no"
    is raised as.
    """


class HopPlanError(DeliveryHopError):
    """The declared delivery chain cannot be turned into a valid plan."""


class ArtifactOrderError(DeliveryHopError):
    """An author tried to choose the artifact step order (§10.2 fixes it)."""


# ── target traits (FR-DEL-05) ──────────────────────────────────────────────

@dataclass(frozen=True)
class TargetTraits:
    """The per-target declaration.  ``idempotent`` means repeating the
    hop with the same bytes to the same name is harmless (overwrite).
    ``auto_retry`` may only be True for an idempotent target — the
    constructor enforces it, so a mis-declaration cannot exist at all."""

    name: str
    idempotent: bool
    auto_retry: bool
    ack_default: str = ACK_NOT_REQUIRED

    def __post_init__(self):
        if self.auto_retry and not self.idempotent:
            raise ValueError(
                f"target {self.name!r}: auto_retry=True on a non-idempotent "
                f"target would repeat a send whose duplicate is a real "
                f"incident (BRD §19 H1) — declare it idempotent or disable "
                f"auto retry")
        if self.ack_default not in DELIVERY_ACK_STATES:
            raise ValueError(
                f"target {self.name!r}: ack_default {self.ack_default!r} is "
                f"not one of {DELIVERY_ACK_STATES}")


#: The declarations.  s3/local overwrite the same key/path with the same
#: bytes — repeat-safe.  sftp lands a file on a counterparty's server
#: (they may sweep it the moment it appears — a second copy is a second
#: regulatory submission); oracle inserts rows.  Neither is repeatable.
DEFAULT_TARGET_TRAITS: dict[str, TargetTraits] = {
    "local": TargetTraits("local", idempotent=True, auto_retry=True,
                          ack_default=ACK_NOT_REQUIRED),
    "s3": TargetTraits("s3", idempotent=True, auto_retry=True,
                       ack_default=ACK_NOT_REQUIRED),
    "sftp": TargetTraits("sftp", idempotent=False, auto_retry=False,
                         ack_default=ACK_EXPECTED),
    "oracle": TargetTraits("oracle", idempotent=False, auto_retry=False,
                           ack_default=ACK_NOT_REQUIRED),
    "control_file": TargetTraits("control_file", idempotent=True,
                                 auto_retry=True,
                                 ack_default=ACK_NOT_REQUIRED),
    # FR-DEL-08 — the archive lifecycle stage.  Same key + same bytes on
    # a re-run (the key embeds feed/business_date/build_id, FR-DEL-09),
    # so overwrite is harmless and auto-retry is safe.
    "archive": TargetTraits("archive", idempotent=True, auto_retry=True,
                            ack_default=ACK_NOT_REQUIRED),
}

#: Internal hop-config marker set by :func:`build_hop_plan` when the
#: feed's contract declares encryption.  Read by ``_run_single``: an
#: artifact whose parts do not carry an encrypted name is REFUSED before
#: any transport is touched — the last tripwire between a plaintext file
#: and a counterparty under a contract that says encrypted (FR-ART-06).
ENCRYPTION_REQUIRED_KEY = "_encryption_required"


def traits_for(target_type: str,
               registry: Mapping[str, TargetTraits] | None = None
               ) -> TargetTraits:
    """The declared traits — or a refusal.  NEVER a guessed default:
    assuming idempotency for an unknown target is exactly how a second
    regulatory file reaches a counterparty (FR-DEL-05, §19 H1)."""
    reg = registry if registry is not None else DEFAULT_TARGET_TRAITS
    t = reg.get(str(target_type or "").lower())
    if t is None:
        raise UnknownDeliveryTarget(
            f"no idempotency declaration for target {target_type!r} — "
            f"declared targets: {sorted(reg)}.  Idempotency is declared, "
            f"never assumed (FR-DEL-05)")
    return t


# ── hop plan ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class HopSpec:
    """One hop.  ``label`` is the DB key half (``delivery_attempts.target``)
    and must be unique within a chain — two SFTP endpoints in one chain
    need two labels, or their attempt rows would collide on the
    ``(manifest_version, target, attempt)`` natural key (§14.2)."""

    label: str
    target_type: str
    config: Mapping[str, Any] = field(default_factory=dict)
    #: label of the hop whose success this one consumes (the SFTP hop
    #: sends the file the local hop materialised).  None = independent.
    requires: str | None = None
    #: attempts allowed within one execute_chain call.  Clamped to 1 for
    #: any target whose traits forbid auto retry — the plan builder and
    #: the runner BOTH enforce it (belt and braces on H1).
    max_attempts: int = 1


def build_hop_plan(feed_definition: Mapping[str, Any],
                   *, traits_registry: Mapping[str, TargetTraits] | None
                   = None,
                   run_identity: Mapping[str, Any] | None = None
                   ) -> list[HopSpec]:
    """Turn a feed's declared delivery chain into an ordered hop plan.

    Modern shape — ``feed_definition["delivery_chain"]`` is a list of
    ``{"target": "sftp", "label": ..., "config": {...}, "requires": ...,
    "max_attempts": n}``.  Legacy shape — a single ``destination_type``
    + ``destination_config`` becomes a one-hop plan, unchanged behaviour.

    Any non-local hop that does not say otherwise depends on the first
    local hop in the chain (it sends the materialised file).  An entry
    may set ``"requires": null`` explicitly to declare independence.

    ``run_identity`` (2026-09-03) carries the per-run facts — feed name,
    business date, build id — that some targets file BY.  It is stamped
    only onto hops whose registered target declares
    ``needs_run_identity``, so a static destination config never gains
    fields it did not ask for and a target that files by run is never
    handed a config without them.  ``core.feed.archive`` is the first
    such target: archiving under a guessed key is filing a document in a
    random drawer, so it refuses rather than defaults.
    """
    # FR-ART-06 — a feed whose contract declares encryption gets the
    # marker stamped on EVERY hop config; the runner then refuses to
    # hand a plaintext artifact to any transport.  Read from the same
    # bag the contract validator and the artifact chain read
    # (output_options), so the three cannot disagree about what the
    # author declared.
    _opts = feed_definition.get("output_options") or {}
    _encryption = str(_opts.get("encryption") or "none").strip().lower()

    def _needs_identity(target_type: str) -> bool:
        """Ask the REGISTERED target, never a name list here — a second
        list is a second thing to forget to update."""
        try:
            from core.feed.delivery_targets import get_delivery_target
            return bool(getattr(get_delivery_target(target_type),
                                "needs_run_identity", False))
        except Exception:
            return False

    def _hop_config(raw: Mapping[str, Any] | None,
                    target_type: str = "") -> dict:
        cfg = dict(raw or {})
        if _encryption not in ("", "none"):
            cfg[ENCRYPTION_REQUIRED_KEY] = _encryption
        if run_identity and target_type and _needs_identity(target_type):
            from core.feed.archive import inject_run_identity
            cfg = inject_run_identity(
                cfg,
                feed_name=(run_identity.get("feed")
                           or feed_definition.get("name")),
                business_date=run_identity.get("business_date"),
                build_id=run_identity.get("build_id"))
        return cfg

    chain = feed_definition.get("delivery_chain")
    if not chain:
        dest_type = str(feed_definition.get("destination_type") or "local")
        traits_for(dest_type, traits_registry)  # refuse unknown now, loudly
        return [HopSpec(label=dest_type, target_type=dest_type,
                        config=_hop_config(
                            feed_definition.get("destination_config"),
                            dest_type))]

    # First local-typed hop label — the default prerequisite for the rest.
    local_label: str | None = None
    for entry in chain:
        if str(entry.get("target") or entry.get("target_type") or "").lower() == "local":
            local_label = str(entry.get("label") or "local")
            break

    plan: list[HopSpec] = []
    seen: set = set()
    for entry in chain:
        target_type = str(entry.get("target")
                          or entry.get("target_type") or "").lower()
        traits = traits_for(target_type, traits_registry)
        label = str(entry.get("label") or target_type)
        if label in seen:
            raise HopPlanError(
                f"duplicate hop label {label!r} — attempt rows are keyed "
                f"(manifest_version, target, attempt); two hops sharing a "
                f"label would collide.  Give each hop a distinct label")
        seen.add(label)
        if "requires" in entry:
            requires = entry["requires"]
        elif target_type != "local" and local_label is not None:
            requires = local_label
        else:
            requires = None
        declared = int(entry.get("max_attempts") or 1)
        # H1 clamp: a non-auto-retryable target gets exactly ONE attempt
        # per run regardless of what the author typed.
        max_attempts = declared if traits.auto_retry else 1
        plan.append(HopSpec(label=label, target_type=target_type,
                            config=_hop_config(entry.get("config"),
                                               target_type),
                            requires=requires,
                            max_attempts=max(1, max_attempts)))
    return plan


# ── suppression (FR-DEL-06) ────────────────────────────────────────────────

def is_delivery_suppressed(policy: Mapping[str, Any] | None,
                           feed_key: Any, environment: str) -> bool:
    """Policy comes from CONFIG (the engine wires it), never from the
    feed definition — that is the whole point of FR-DEL-06: a backfill
    or an acceptance run must not require editing the feed.

    Policy shape::

        {"all": ["dev", "uat"],                  # whole environments
         "feeds": {"<feed name or id>": ["uat"], # one feed, some envs
                   "risk_daily": ["*"]}}         # one feed, everywhere
    """
    if not policy:
        return False
    env = str(environment or "").lower()

    def _hit(envs) -> bool:
        return any(str(e).lower() in ("*", env) for e in (envs or []))

    if _hit(policy.get("all")):
        return True
    for key, envs in (policy.get("feeds") or {}).items():
        if str(key) == str(feed_key) and _hit(envs):
            return True
    return False


def decide_run_delivery_suppression(feed_run: Mapping[str, Any] | None
                                    ) -> Optional[bool]:
    """THE decision, taken ONCE when an execution is created for a bound
    feed_run: True when the run must produce but NOT deliver (a backfill
    launched without delivery -- ``feed_runs.suppress_delivery``), False
    when it delivers, None when there is no bound run (no run knowledge:
    the ledger lookup stays the fallback).  Stored on the execution as
    ``delivery_suppressed``; every lane reads THAT."""
    if not isinstance(feed_run, Mapping) or not feed_run:
        return None
    return feed_run.get("suppress_delivery") in (True, 1)


def stored_delivery_suppression(execution: Mapping[str, Any] | None
                                ) -> Optional[bool]:
    """The run's "do not deliver" decision as STORED on its execution row
    (``feed_executions.delivery_suppressed``, written once at creation from
    the bound feed_run), or None when the row carries none (legacy rows,
    a Run Now with no bound run).  The one reader every lane uses."""
    # Only a real row and a real boolean are an answer.  A MagicMock seam
    # (or a drifted DAO returning an object) is NOT: treating a truthy
    # non-answer as "suppress" would silently stop deliveries, exactly
    # the trap is_run_delivery_suppressed already documents.
    if not isinstance(execution, Mapping):
        return None
    v = execution.get("delivery_suppressed")
    if isinstance(v, bool):
        return v
    if isinstance(v, int):
        return bool(v)
    return None


def is_run_delivery_suppressed(db, feed_config_id, business_date) -> bool:
    """FR-OPS-08 (2026-09-02) — RUN-level suppression: a backfill
    PRODUCES but does not deliver unless the launch explicitly (and
    auditedly) said so.  The flag lives on the feed_runs row
    (``suppress_delivery``); the db seam resolves which run is currently
    executing for (feed, business_date)
    (``mixin_feeds.feed_run_delivery_suppressed``).

    A seam without the method (older doubles, standalone tests) means
    "no run-level knowledge" — not suppressed, exactly the pre-backfill
    behaviour.  A seam WITH the method that RAISES propagates: this is a
    correctness gate against the re-delivery incident, and a gate that
    cannot be read must not silently mean "send".
    """
    fn = getattr(db, "feed_run_delivery_suppressed", None)
    if fn is None:
        return False
    # business_date=None (legacy execution rows) is handled by the seam
    # itself — mixin_feeds.feed_run_delivery_suppressed returns False on
    # "no run identity"; the policy lives in ONE place, not two.
    res = fn(feed_config_id, business_date)
    # The seam contract is a BOOLEAN.  Anything else (a MagicMock in an
    # engine test, a row object from a drifted implementation) is not an
    # answer — treating a truthy non-answer as "suppress" would silently
    # kill every delivery behind such a seam, and treating it as "send"
    # is just the documented no-run-knowledge default.  An EXCEPTION
    # still propagates above (a ledger that exists but cannot be read
    # must not silently mean "send").
    if isinstance(res, bool):
        return res
    if isinstance(res, int):
        return bool(res)
    return False


# ── artifact preparation order (§10.2) ─────────────────────────────────────

def plan_artifact_steps(options: Mapping[str, Any] | None) -> tuple[str, ...]:
    """The enabled artifact steps, ALWAYS in the fixed engine order:
    package -> compress -> encrypt -> checksum.  An author-declared
    ``step_order`` that disagrees is refused at planning time — a
    checksum taken before compression or encryption describes bytes the
    counterparty never receives (FR-ART-02), and that mismatch is a
    support call every time."""
    o = options or {}
    enabled = set()
    if str(o.get("packaging") or "none") != "none":
        enabled.add("package")
    if str(o.get("codec") or "none") != "none":
        enabled.add("compress")
    if str(o.get("encryption") or "none") != "none":
        enabled.add("encrypt")
    if o.get("checksum"):
        enabled.add("checksum")
    canonical = tuple(s for s in ARTIFACT_STEP_ORDER if s in enabled)
    declared = o.get("step_order")
    if declared is not None and tuple(declared) != canonical:
        raise ArtifactOrderError(
            f"artifact step order is fixed by the engine "
            f"({' -> '.join(ARTIFACT_STEP_ORDER)}); declared "
            f"{tuple(declared)!r} but the plan is {canonical!r}.  The "
            f"checksum must cover what is SENT (§10.2)")
    return canonical


def checksum_of_sent_bytes(path, algorithm: str = "sha256") -> str:
    """Digest of the file as it goes over the wire — call this on the
    FINAL artifact (post package/compress/encrypt), never on the
    plaintext source."""
    return compute_file_checksum(path, algorithm)


def checksum_sidecar_line(digest: str, filename: str) -> str:
    """The coreutils shape most counterparties diff against (FR-ART-05):
    ``<hash><SP><SP><filename>``."""
    return f"{digest}  {filename}"


# ── outcomes ───────────────────────────────────────────────────────────────

@dataclass
class HopOutcome:
    label: str
    target_type: str
    status: str
    attempt: int
    manifest_version: str
    attempt_id: int | None = None
    uri: str | None = None
    error: str | None = None
    acknowledgment: str | None = None
    checksum: str | None = None

    def to_dict(self) -> dict:
        """The record shape.  Until 2026-09-15 the engine stored
        ``str(outcome)`` -- a dataclass repr -- under
        ``stage_timings['delivery_hops']`` because nothing answered
        ``to_dict``; a JSON column carrying ``HopOutcome(status='failed',
        ...)`` as prose cannot be queried for the status."""
        return {
            "label": self.label,
            "target_type": self.target_type,
            "status": self.status,
            "attempt": self.attempt,
            "manifest_version": self.manifest_version,
            "attempt_id": self.attempt_id,
            "uri": self.uri,
            "error": self.error,
            "acknowledgment": self.acknowledgment,
            "checksum": self.checksum,
        }


# ── did the delivery HAPPEN?  (2026-09-15) ─────────────────────────────────
#
# ``execute_chain`` records every hop and moves on -- correct for a chain,
# and NOT the question.  Both consumers (the native engine and the Spark
# webhook lane) then need one answer to "did the file reach where the
# author said it goes?", and until 2026-09-15 the native engine never
# asked: it read the first URI any hop produced, found none, and carried
# on to certify a file that never left the machine as COMPLETE (execution
# 61: every hop failed, status=completed, completeness=verified).
# The Spark lane asked a WEAKER question ("did any hop succeed?").  A
# decision made twice is a bug; this is the one place it is decided.

CHAIN_DELIVERED = "delivered"
CHAIN_SUPPRESSED = "suppressed"
CHAIN_FAILED = "failed"

# Config keys that identify WHERE a hop was going.  Anything not listed
# here is never rendered, so a secret can not reach an error message by
# being spelled in a way a deny-list did not anticipate.
_DESTINATION_KEYS = ("host", "port", "remote_dir", "remote_path", "bucket",
                     "prefix", "key_prefix", "path", "url", "base_url",
                     "table", "table_name", "schema", "dsn", "recipients",
                     "to", "region")


def describe_destination(target_type: str,
                         config: Mapping[str, Any] | None) -> str:
    """``sftp[host=localhost port=1 remote_dir=/inbox]`` -- the destination
    named for an error message, from an ALLOW-list of address-shaped keys
    only.  Credentials are never on the list, so they can never be in the
    message."""
    cfg = config or {}
    parts = []
    for k in _DESTINATION_KEYS:
        v = cfg.get(k)
        if v in (None, ""):
            continue
        if isinstance(v, (list, tuple)):
            v = ",".join(str(x) for x in v)
        parts.append(f"{k}={str(v)[:200]}")
    return f"{target_type}[{' '.join(parts)}]" if parts else str(target_type)


def chain_verdict(plan: Sequence[HopSpec] | None,
                  outcomes: Sequence[HopOutcome] | None
                  ) -> tuple[str, str | None]:
    """ONE rule for "did the chain deliver?", read from what the plan
    DECLARES.

    A ``HopSpec`` declares a dependency (``requires``) and nothing else --
    there is no "optional" hop -- so every hop the author listed is a
    delivery the author expects to happen.  Hence:

      * DELIVERED  -- every hop SUCCEEDED.
      * FAILED     -- any hop did not: FAILED and REFUSED are the transport
                      or the gate saying the file did not arrive there;
                      SKIPPED means its declared prerequisite never
                      succeeded, so it was never sent either.  The
                      dependency is honoured as declared rather than a new
                      notion of "required hop" being invented beside it.
                      NO outcomes at all is also FAILED: a chain that ran
                      nothing delivered nothing, and unknown is not
                      delivered.
      * SUPPRESSED -- every hop was SUPPRESSED.  That is a deliberate
                      non-delivery (policy, FR-DEL-06; or a backfill run
                      without deliver=true, FR-OPS-08) whose attempt rows
                      already say why nothing went out.  It is its own
                      state so the consumer can decide, never folded into
                      either of the others.

    Returns ``(verdict, reason)``; ``reason`` names every hop that did not
    deliver, its destination (never its credentials) and the transport's
    own error text, and is ``None`` only for DELIVERED.
    """
    outs = list(outcomes or [])
    if not outs:
        return CHAIN_FAILED, ("no delivery hop ran -- the chain produced no "
                              "outcome, so nothing was delivered")
    if all(o.status == SUPPRESSED for o in outs):
        why = next((o.error for o in outs if o.error), None)
        return CHAIN_SUPPRESSED, (why or "delivery suppressed on every hop")
    configs = {h.label: (h.target_type, h.config) for h in (plan or [])}
    bad = [o for o in outs if o.status != SUCCEEDED]
    if not bad:
        return CHAIN_DELIVERED, None
    lines = []
    for o in bad:
        t_type, cfg = configs.get(o.label, (o.target_type, None))
        lines.append(f"hop {o.label!r} -> {describe_destination(t_type, cfg)} "
                     f"{o.status.upper()}: {o.error or 'no error text recorded'}")
    delivered = [o.label for o in outs if o.status == SUCCEEDED]
    head = (f"delivery did not happen on {len(bad)} of {len(outs)} hop(s)"
            + (f" (delivered: {', '.join(delivered)})" if delivered else ""))
    return CHAIN_FAILED, head + " -- " + "; ".join(lines)


# ── the runner ─────────────────────────────────────────────────────────────

class DeliveryHopRunner:
    """Executes hop plans over the injected db + transport seams.

    ``execute_chain`` is the automatic path (engine after certification);
    ``retry_hop`` is the operator path (re-run ONE hop, nothing else).
    Neither ever regenerates data — there is no generation seam here.
    """

    def __init__(self, db, transports: Mapping[str, Callable],
                 *, environment: str, actor: str = "system",
                 traits_registry: Mapping[str, TargetTraits] | None = None,
                 suppression_policy: Mapping[str, Any] | None = None,
                 clock: Callable[[], datetime] | None = None):
        self.db = db
        self.transports = dict(transports or {})
        self.environment = environment
        self.actor = actor
        self.traits_registry = traits_registry
        self.suppression_policy = suppression_policy
        self._now = clock or (lambda: datetime.now(timezone.utc))

    # ── gates ────────────────────────────────────────────────────────

    def require_certified(self, manifest) -> str:
        """The one entry gate: only a CERTIFIED manifest may be
        delivered (FR-DEL-01).  Returns its version string — the
        identity every attempt row will carry (FR-DEL-04)."""
        status = getattr(manifest, "status", None)
        if status != "complete":
            raise ManifestNotCertified(
                f"manifest status is {status!r}, not 'complete' — delivery "
                f"consumes a CERTIFIED manifest; a building/partial part "
                f"list must never ship under a real filename (FR-DEL-01)")
        version = manifest.version()
        if not version:
            raise ManifestNotCertified(
                "manifest has no version identity — a delivery record must "
                "name the manifest version it sent (FR-DEL-04)")
        return version

    # ── helpers ──────────────────────────────────────────────────────

    def _history(self, manifest_version: str, label: str) -> list[dict]:
        rows = self.db.list_delivery_attempts(manifest_version, label)
        return sorted(rows, key=lambda r: int(r.get("attempt") or 0))

    def _next_attempt_no(self, manifest_version: str, label: str) -> int:
        rows = self._history(manifest_version, label)
        return (max(int(r["attempt"]) for r in rows) + 1) if rows else 1

    def _has_success(self, manifest_version: str, label: str) -> bool:
        return any(r.get("status") == SUCCEEDED
                   for r in self._history(manifest_version, label))

    def _insert_row(self, hop: HopSpec, traits: TargetTraits,
                    manifest_version: str, ctx: dict, status: str,
                    *, error: str | None = None,
                    actor: str | None = None) -> dict:
        # FR-DEL-04, enforced at the write: a record that does not name
        # what it sent is not a delivery record.
        if not manifest_version:
            raise DeliveryHopError(
                "refusing to write a delivery attempt with no "
                "manifest_version (FR-DEL-04)")
        if status not in DELIVERY_ATTEMPT_STATUSES:
            raise DeliveryHopError(
                f"status {status!r} not in {DELIVERY_ATTEMPT_STATUSES}")
        data = {
            "feed_config_id": ctx["feed_config_id"],
            "business_date": ctx["business_date"],
            "build_id": ctx.get("build_id"),
            "manifest_version": manifest_version,
            "target": hop.label,
            "target_type": hop.target_type,
            "attempt": self._next_attempt_no(manifest_version, hop.label),
            "status": status,
            "idempotent": traits.idempotent,
            "acknowledgment": ACK_NOT_REQUIRED,
            "created_by": actor or self.actor,
        }
        if status == RUNNING:
            data["started_at"] = self._now()
        if error is not None:
            data["error_message"] = error
            data["completed_at"] = self._now()
        return self.db.insert_delivery_attempt(data)

    def _plaintext_refusal(self, hop: HopSpec, manifest) -> str | None:
        """FR-ART-06, the LAST tripwire: a hop whose config carries the
        encryption marker must not send an artifact whose parts do not
        carry an encrypted name.  This is a NAME check by design — the
        runner deliberately touches no file; the byte-level guarantee
        lives in ``core.feed.pgp.encrypt_file``'s output verification,
        which is the only thing that produces those names.  It exists so
        a pgp feed saved before 2026-09-03 (under the old warn-and-save
        posture), or a native run whose engine has not wired
        ``apply_encryption`` yet, FAILS LOUDLY instead of delivering
        plaintext with a green status."""
        required = hop.config.get(ENCRYPTION_REQUIRED_KEY)
        if not required:
            return None
        from core.feed.pgp import looks_encrypted_name
        # What will actually be handed to the transport: the artifact
        # chain declares the prepared deliverable names on the manifest
        # (packaging/compression/encryption rename the staged files);
        # without that declaration — the native lane's one-part manifest
        # — the part names ARE the deliverables.
        declared = getattr(manifest, "delivered_names", None)
        names = list(declared) if declared else [
            getattr(p, "name", "")
            for p in (getattr(manifest, "parts", None) or [])]
        plain = [n for n in names if not looks_encrypted_name(n)]
        if not names or plain:
            return (
                f"contract declares encryption={required!r} and the staged "
                f"artifact is NOT encrypted "
                f"(unencrypted part names: {plain or '<none staged>'}) — "
                f"refusing to deliver plaintext under a contract that says "
                f"encrypted (FR-ART-06).  The artifact chain's encrypt "
                f"step produces *.pgp deliverables; a run reaching this "
                f"refusal skipped it")
        return None

    def _run_single(self, hop: HopSpec, traits: TargetTraits, manifest,
                    manifest_version: str, ctx: dict,
                    actor: str | None = None) -> HopOutcome:
        refusal = self._plaintext_refusal(hop, manifest)
        if refusal is not None:
            row = self._insert_row(hop, traits, manifest_version, ctx,
                                   REFUSED, error=refusal, actor=actor)
            return HopOutcome(hop.label, hop.target_type, REFUSED,
                              row["attempt"], manifest_version,
                              attempt_id=row["id"], error=refusal)
        row = self._insert_row(hop, traits, manifest_version, ctx, RUNNING,
                               actor=actor)
        transport = (self.transports.get(hop.label)
                     or self.transports.get(hop.target_type))
        if transport is None:
            msg = (f"no transport wired for hop {hop.label!r} "
                   f"(type {hop.target_type!r}) — configuration error, "
                   f"not retried")
            self.db.update_delivery_attempt(row["id"], {
                "status": REFUSED, "error_message": msg,
                "completed_at": self._now(), "updated_by": actor or self.actor})
            return HopOutcome(hop.label, hop.target_type, REFUSED,
                              row["attempt"], manifest_version,
                              attempt_id=row["id"], error=msg)
        try:
            result = dict(transport(hop, manifest) or {})
        except Exception as exc:  # noqa: BLE001 — a hop failure is data
            msg = f"{type(exc).__name__}: {exc}"
            self.db.update_delivery_attempt(row["id"], {
                "status": FAILED, "error_message": msg,
                "completed_at": self._now(), "updated_by": actor or self.actor})
            return HopOutcome(hop.label, hop.target_type, FAILED,
                              row["attempt"], manifest_version,
                              attempt_id=row["id"], error=msg)

        # Checksum of the bytes actually SENT (§10.2).  Prefer the
        # transport's own digest; else compute over the file it sent.
        algo = str(hop.config.get("checksum_algorithm") or "sha256")
        digest = result.get("checksum")
        if digest is None and result.get("sent_path"):
            digest = checksum_of_sent_bytes(result["sent_path"], algo)

        update = {
            "status": SUCCEEDED,
            "destination_uri": result.get("uri"),
            "bytes_sent": result.get("bytes_sent"),
            "files_sent": result.get("files_sent"),
            "verification": result.get("verification"),
            "verification_detail": result.get("verification_detail"),
            "endpoint_ref": result.get("endpoint_ref"),
            "acknowledgment": traits.ack_default,
            "completed_at": self._now(),
            "updated_by": actor or self.actor,
        }
        if digest is not None:
            update["checksum"] = digest
            update["checksum_algorithm"] = algo
        self.db.update_delivery_attempt(row["id"], update)
        return HopOutcome(hop.label, hop.target_type, SUCCEEDED,
                          row["attempt"], manifest_version,
                          attempt_id=row["id"], uri=result.get("uri"),
                          acknowledgment=traits.ack_default,
                          checksum=digest)

    def _suppress_all(self, hops, manifest_version: str, ctx: dict,
                      reason: str) -> list:
        """Write one SUPPRESSED attempt row per hop — nothing is sent,
        but the record still answers "why did nothing go out?" a year
        later (shared by the FR-DEL-06 policy gate and the FR-OPS-08
        run gate)."""
        outcomes = []
        for hop in hops:
            traits = traits_for(hop.target_type, self.traits_registry)
            row = self._insert_row(hop, traits, manifest_version, ctx,
                                   SUPPRESSED, error=reason)
            outcomes.append(HopOutcome(
                hop.label, hop.target_type, SUPPRESSED, row["attempt"],
                manifest_version, attempt_id=row["id"]))
        return outcomes

    # ── the automatic path ───────────────────────────────────────────

    def execute_chain(self, hops: Sequence[HopSpec], manifest, *,
                      feed_config_id: int, business_date,
                      feed_key: Any = None,
                      run_suppressed: Optional[bool] = None) -> list[HopOutcome]:
        """Run every hop in plan order.  A failed hop is RECORDED and the
        chain moves on — later hops that do not depend on it still run,
        and each remains independently re-runnable (FR-DEL-02).  Only a
        hop whose declared prerequisite has not succeeded (this run or
        any earlier one for the same manifest version) is skipped."""
        manifest_version = self.require_certified(manifest)
        ctx = {"feed_config_id": feed_config_id,
               "business_date": business_date,
               "build_id": getattr(manifest, "build_id", None)}

        # FR-DEL-06 — suppression from policy, checked before ANY
        # transport is touched.  Rows are still written so the record
        # answers "why did nothing go out on the 3rd?" a year later.
        if is_delivery_suppressed(self.suppression_policy,
                                  feed_key if feed_key is not None
                                  else feed_config_id,
                                  self.environment):
            return self._suppress_all(
                hops, manifest_version, ctx,
                f"delivery suppressed by policy for environment "
                f"{self.environment!r}")

        # FR-OPS-08 — RUN-level suppression: the currently executing
        # feed_runs row said "produce but do not deliver" (a backfill
        # launched without deliver=true).  Same posture as the policy
        # gate: the SUPPRESSED attempt rows are still written, and an
        # operator retry of one hop (the audited path) sends it later.
        #
        # 2026-10-07 -- ``run_suppressed`` is the decision STORED on the
        # execution when it was created (feed_executions.delivery_suppressed).
        # A caller that has it passes it and it is final: True suppresses,
        # False delivers.  Only a caller with no stored decision (None: a
        # legacy row) falls back to the ledger lookup, which asks for a
        # RUNNING suppressed feed_run -- and so races the completed write
        # on the Spark webhook path.
        if run_suppressed is None:
            run_suppressed = is_run_delivery_suppressed(
                self.db, feed_config_id, business_date)
        if run_suppressed:
            return self._suppress_all(
                hops, manifest_version, ctx,
                "delivery suppressed for this run (backfill without "
                "deliver=true) — retry the hop explicitly to send it")

        outcomes: list[HopOutcome] = []
        succeeded_now: set = set()
        for hop in hops:
            traits = traits_for(hop.target_type, self.traits_registry)
            if hop.requires and hop.requires not in succeeded_now \
                    and not self._has_success(manifest_version, hop.requires):
                msg = (f"prerequisite hop {hop.requires!r} has not succeeded "
                       f"for manifest {manifest_version} — nothing to send")
                row = self._insert_row(hop, traits, manifest_version, ctx,
                                       SKIPPED, error=msg)
                outcomes.append(HopOutcome(
                    hop.label, hop.target_type, SKIPPED, row["attempt"],
                    manifest_version, attempt_id=row["id"], error=msg))
                continue

            # H1 — the runner clamps too, independently of the plan
            # builder: a non-auto-retryable target gets ONE attempt.
            allowed = hop.max_attempts if traits.auto_retry else 1
            outcome: HopOutcome | None = None
            for _ in range(max(1, allowed)):
                outcome = self._run_single(hop, traits, manifest,
                                           manifest_version, ctx)
                if outcome.status in (SUCCEEDED, REFUSED):
                    break
            if outcome.status == SUCCEEDED:
                succeeded_now.add(hop.label)
            outcomes.append(outcome)
        return outcomes

    # ── the operator path ────────────────────────────────────────────

    def retry_hop(self, hop: HopSpec, manifest, *,
                  feed_config_id: int, business_date,
                  initiated_by: str, feed_key: Any = None) -> HopOutcome:
        """Re-run ONE hop over the SAME certified manifest.  Nothing is
        regenerated and no other hop is touched (FR-DEL-02).

        Refusals (recorded, then raised):
          * a non-idempotent hop whose last attempt SUCCEEDED for this
            manifest version — re-sending would double-deliver; a
            regeneration mints a NEW manifest version, which is how a
            deliberate re-send of different bytes is expressed;
          * a non-idempotent hop whose last attempt is still ``running``
            — the outcome is INDETERMINATE (a pod died mid-send).  We
            cannot tell whether it ran, so we refuse rather than repeat.
            ``mark_attempt_lost`` is the human path out.
        """
        manifest_version = self.require_certified(manifest)
        traits = traits_for(hop.target_type, self.traits_registry)
        ctx = {"feed_config_id": feed_config_id,
               "business_date": business_date,
               "build_id": getattr(manifest, "build_id", None)}

        if is_delivery_suppressed(self.suppression_policy,
                                  feed_key if feed_key is not None
                                  else feed_config_id,
                                  self.environment):
            row = self._insert_row(
                hop, traits, manifest_version, ctx, SUPPRESSED,
                error=(f"delivery suppressed by policy for environment "
                       f"{self.environment!r}"), actor=initiated_by)
            return HopOutcome(hop.label, hop.target_type, SUPPRESSED,
                              row["attempt"], manifest_version,
                              attempt_id=row["id"])

        history = self._history(manifest_version, hop.label)
        last = history[-1] if history else None
        if last is not None and not traits.idempotent:
            if last.get("status") == RUNNING:
                msg = (f"hop {hop.label!r} attempt {last['attempt']} for "
                       f"manifest {manifest_version} is still 'running' — "
                       f"its outcome is INDETERMINATE and the target is not "
                       f"idempotent.  Refusing to repeat what may already "
                       f"have been sent; verify out-of-band and use "
                       f"mark_attempt_lost first")
                self._insert_row(hop, traits, manifest_version, ctx,
                                 REFUSED, error=msg, actor=initiated_by)
                raise DeliveryRefused(msg)
            if last.get("status") == SUCCEEDED:
                msg = (f"hop {hop.label!r} already delivered manifest "
                       f"{manifest_version} (attempt {last['attempt']}) and "
                       f"the target is not idempotent — re-sending would "
                       f"double-deliver.  A regeneration mints a NEW "
                       f"manifest version; deliver that instead")
                self._insert_row(hop, traits, manifest_version, ctx,
                                 REFUSED, error=msg, actor=initiated_by)
                raise DeliveryRefused(msg)

        if hop.requires and not self._has_success(manifest_version,
                                                  hop.requires):
            raise DeliveryRefused(
                f"prerequisite hop {hop.requires!r} has not succeeded for "
                f"manifest {manifest_version} — run it first")

        return self._run_single(hop, traits, manifest, manifest_version,
                                ctx, actor=initiated_by)

    # ── the human path out of an indeterminate attempt ───────────────

    def mark_attempt_lost(self, attempt_id: int, *, actor: str,
                          reason: str) -> dict:
        """A human verified OUT-OF-BAND that an in-doubt (``running``)
        attempt never landed, and records that verdict with their name
        on it.  Only then does ``retry_hop`` become possible for a
        non-idempotent target.  Anything not in 'running' is refused —
        this is for resolving indeterminacy, not rewriting history."""
        row = self.db.get_delivery_attempt(attempt_id)
        if row is None:
            raise DeliveryHopError(f"no delivery attempt {attempt_id}")
        if row.get("status") != RUNNING:
            raise DeliveryRefused(
                f"attempt {attempt_id} is {row.get('status')!r}, not "
                f"'running' — only an indeterminate attempt can be marked "
                f"lost")
        if not (reason or "").strip():
            raise DeliveryHopError(
                "a reason is required — 'marked lost' with no evidence is "
                "how a double delivery gets waved through")
        updated = self.db.update_delivery_attempt(attempt_id, {
            "status": FAILED,
            "error_message": f"marked lost by {actor}: {reason}",
            "completed_at": self._now(),
            "updated_by": actor,
        })
        return updated

    # ── acknowledgment (FR-DEL-13) ───────────────────────────────────

    #: legal transitions.  ``expected`` is set by a successful hop on a
    #: target that declares it; ``received`` may later become
    #: ``rejected`` (a counterparty can bounce a file after sweeping
    #: it); ``rejected`` is terminal; ``not_required`` never moves.
    _ACK_TRANSITIONS = frozenset({
        (ACK_EXPECTED, ACK_RECEIVED),
        (ACK_EXPECTED, ACK_REJECTED),
        (ACK_RECEIVED, ACK_REJECTED),
    })

    def record_acknowledgment(self, manifest_version: str, label: str,
                              state: str, *, actor: str,
                              detail: str | None = None) -> dict:
        """Record the counterparty's verdict on the LATEST successful
        delivery of (manifest_version, target)."""
        if state not in (ACK_RECEIVED, ACK_REJECTED):
            raise DeliveryHopError(
                f"only {ACK_RECEIVED!r} or {ACK_REJECTED!r} can be recorded "
                f"— {ACK_EXPECTED!r}/{ACK_NOT_REQUIRED!r} are declarations "
                f"the delivery itself makes, got {state!r}")
        successes = [r for r in self._history(manifest_version, label)
                     if r.get("status") == SUCCEEDED]
        if not successes:
            raise DeliveryRefused(
                f"no successful delivery of manifest {manifest_version} to "
                f"{label!r} — there is nothing to acknowledge")
        last = successes[-1]
        current = last.get("acknowledgment") or ACK_NOT_REQUIRED
        if (current, state) not in self._ACK_TRANSITIONS:
            raise DeliveryRefused(
                f"acknowledgment on attempt {last['attempt']} is "
                f"{current!r}; transition to {state!r} is not allowed "
                f"(legal: {sorted(self._ACK_TRANSITIONS)})")
        return self.db.update_delivery_attempt(last["id"], {
            "acknowledgment": state,
            "acknowledged_at": self._now(),
            "acknowledgment_detail": detail,
            "updated_by": actor,
        })
