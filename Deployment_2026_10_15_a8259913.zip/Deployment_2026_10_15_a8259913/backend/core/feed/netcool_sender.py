"""The Netcool queue drainer (BRD §12.4, FR-ALT-03..07).

``core.feed.netcool`` builds events and ENQUEUES them; ``sla_watcher``
raises and clears.  Neither sends anything.  Store-and-forward without a
forwarder is just store — the alert is as lost as if it were never
raised, and the queue's own audit trail makes it LOOK like alerting
works.  This module is the forwarder.

Design, requirement by requirement:

* **FR-ALT-03 — transport is configuration.**  Netcool is reached by an
  EIF probe, an SNMP trap, or a REST gateway in front of ObjectServer,
  depending on the site standard.  The transport here is a SEAM:
  anything with ``send(body: dict) -> None`` (raising on failure) works.
  The site standard, endpoint and credentials are §18 inputs owed by the
  Netcool team and DO NOT EXIST YET — so the shipped default is
  ``transport: "none"``, which REFUSES AT INFO with the reason.  A
  disabled sender that says nothing is the defect; one that says why is
  honest (the same rule the Kafka consumer follows, FR-DEP-04).

* **FR-ALT-04 — a Netcool outage delays alerts, never a feed.**  The
  sender runs in its own thread, drains the durable queue, and nothing
  in it can raise into a feed's path.  A transport failure is a retry,
  never an exception to a caller.

* **FR-ALT-05 — the queue is the audit.**  A sent event is marked
  delivered (``delivered_at`` = when the console accepted it); an unsent
  one stays undelivered.  "Why did nobody get paged?" is answered from
  the table, not from memory.

* **FR-ALT-06 — bounded retry with a dead letter.**  An event
  undeliverable after ``max_attempts`` moves to the dead-letter registry
  and raises a LOCAL alarm (CRITICAL log + a counter on the status
  surface).  Silently dropping alerts is the worst possible failure of
  an alerting system — worse than never building it, because everyone
  believes it works.

* **FR-ALT-07 — heartbeat.**  Netcool cannot tell "nothing is wrong"
  from "the sender is dead".  A low-severity heartbeat is enqueued on a
  fixed interval and drained through the SAME path as real alerts — so
  its absence on the console means the whole pipeline is down, not just
  one function.  The event carries an ExpireTime so a dead sender's last
  heartbeat does not sit green forever.

* **One malformed event never stops the ones behind it** — it is
  dead-lettered loudly and the pass continues.

Known limitation (reported, not hidden): the ``pending_notifications``
table is age-reaped at ~1 hour by the WebSocket notification poller
(``cleanup_expired``).  An alert that cannot be sent within that window
survives only in this sender's in-memory retry state; a sender restart
during a >1 h Netcool outage loses the queued backlog.  Fixing that
means a kind-aware reap in ``core/notification_queue.py``, which is
outside this module's remit.
"""
from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

DAEMON_NAME = "feed_netcool_sender"

#: The payload discriminator ``core.feed.netcool.enqueue_event`` writes.
#: The queue is shared with WebSocket UI notifications — everything else
#: passes through untouched.
NETCOOL_KIND = "netcool_event"

TRANSPORT_NONE = "none"
TRANSPORT_REST = "rest"
TRANSPORT_EIF = "eif"
TRANSPORT_SNMP = "snmp"

#: How many dead letters the in-memory registry keeps.  Bounded so a
#: long outage cannot grow it without limit; the CRITICAL log line is
#: the durable record.
MAX_DEAD_LETTERS = 200


class NetcoolSendError(RuntimeError):
    """A transport could not deliver an event, or could not be built."""


# ── Config (every key here is DECLARED in core/config.py) ─────────────────

def load_config() -> dict:
    """The declared ``feed_generation.netcool`` block, typed.

    Every key read here is DECLARED in core/config.py — a guard on an
    undeclared key is vacuous.
    """
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "netcool", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, Mapping):
        logger.error("[netcool_sender] feed_generation.netcool is %s, not "
                     "an object — treating as unconfigured",
                     type(raw).__name__)
        raw = {}
    return {
        "transport": str(raw.get("transport") or TRANSPORT_NONE)
        .strip().lower(),
        "endpoint": str(raw.get("endpoint") or ""),
        "poll_interval_seconds": float(raw.get("poll_interval_seconds", 5.0)),
        "batch_size": int(raw.get("batch_size", 50)),
        "max_attempts": max(1, int(raw.get("max_attempts", 5))),
        "retry_backoff_seconds": float(raw.get("retry_backoff_seconds",
                                               30.0)),
        "heartbeat_interval_seconds": float(
            raw.get("heartbeat_interval_seconds", 300.0)),
        "timeout_seconds": float(raw.get("timeout_seconds", 10.0)),
    }


# ── The transport seam (FR-ALT-03) ────────────────────────────────────────

class RestGatewayTransport:
    """POST the OMNIbus event body as JSON to a REST gateway in front of
    ObjectServer.

    No SSRF validation on purpose: the endpoint is ADMIN CONFIGURATION
    (core/config.py), not user input, and an event-console gateway
    normally lives on a private address that an SSRF check would block.
    """

    def __init__(self, endpoint: str, *, timeout: float = 10.0,
                 client_factory: Callable | None = None) -> None:
        self._endpoint = endpoint
        self._timeout = timeout
        self._client_factory = client_factory

    def send(self, body: Mapping[str, Any]) -> None:
        import httpx
        factory = self._client_factory or (
            lambda: httpx.Client(timeout=self._timeout))
        with factory() as client:
            resp = client.post(self._endpoint, json=dict(body))
            if not (200 <= resp.status_code < 300):
                raise NetcoolSendError(
                    f"REST gateway answered {resp.status_code} for "
                    f"Identifier={body.get('Identifier')!r}")


def sender_refusal(cfg: Mapping[str, Any] | None = None) -> str | None:
    """Why the sender will NOT run, or None when it can.

    Pure over its input so every refusal branch is testable without
    config files or a network.
    """
    cfg = dict(cfg) if cfg is not None else load_config()
    transport = cfg["transport"]
    if transport == TRANSPORT_NONE:
        return (
            "feed_generation.netcool.transport is 'none' — the site "
            "transport (EIF probe / SNMP trap / REST gateway), its endpoint "
            "and credentials are §18 inputs owed by the Netcool team.  "
            "Events keep enqueueing durably and the queue remains the "
            "audit, but NO ALERT LEAVES THIS POD until a transport is "
            "configured")
    if transport in (TRANSPORT_EIF, TRANSPORT_SNMP):
        return (
            f"feed_generation.netcool.transport is {transport!r} and no "
            f"{transport} transport ships yet — only 'rest' is implemented. "
            f"The site standard is an §18 input; if the site's answer is "
            f"{transport}, that transport must be built before alerts can "
            f"leave the building")
    if transport != TRANSPORT_REST:
        return (
            f"feed_generation.netcool.transport {transport!r} is not one of "
            f"'none', 'rest', 'eif' or 'snmp' — refusing to guess, because "
            f"a misspelt transport that silently disabled alerting would "
            f"look exactly like a working integration")
    if not cfg["endpoint"]:
        return (
            "feed_generation.netcool.transport is 'rest' but "
            "feed_generation.netcool.endpoint is empty — there is no "
            "gateway to post to (§18 input)")
    return None


def announce_refusal(cfg: Mapping[str, Any] | None = None) -> str | None:
    """State the refusal AT INFO with the reason, and return it.

    INFO, not DEBUG: "no alerts on the console" (quiet night) and "no
    sender running" (our problem) are OPPOSITE investigations, and this
    line is the difference — the same rule the Kafka consumer follows.
    """
    reason = sender_refusal(cfg)
    if reason is not None:
        logger.info("[netcool_sender] alert sender NOT running: %s", reason)
    return reason


def create_transport(cfg: Mapping[str, Any]):
    """Build the configured transport, or raise with the refusal."""
    reason = sender_refusal(cfg)
    if reason is not None:
        raise NetcoolSendError(reason)
    return RestGatewayTransport(cfg["endpoint"],
                                timeout=cfg["timeout_seconds"])


# ── Sender state ──────────────────────────────────────────────────────────

_lock = threading.Lock()
_thread: threading.Thread | None = None
_stop = threading.Event()
_session_factory: Callable | None = None

#: id > cursor is what the next pass scans.  Starts at 0 on purpose: an
#: alert enqueued while the sender was down must still be sent, and the
#: ``delivered`` flag (not the cursor) is what stops re-sends.
_cursor: int = 0

#: queue row id -> {body, attempts, next_at, last_error} for events that
#: failed transport delivery and are within their retry budget.
_retry: dict[int, dict[str, Any]] = {}

#: The dead-letter registry (FR-ALT-06).  This list is what the status
#: surface shows an operator; the CRITICAL log line is the local alarm.
#:
#: Bounded, but NOT ephemeral (corrected 2026-09-02).  It used to be
#: in-memory only, so after a restart "what did we fail to page anyone
#: about?" answered NOTHING — indistinguishable from a clean answer, and
#: the worst possible wrong answer to that particular question.  The
#: durable record is the queue row itself, stamped with DEAD_LETTER_KEY,
#: and ``recover_dead_letters`` rebuilds this list from those rows at
#: startup.
_dead: list[dict[str, Any]] = []

_last_pass: dict[str, Any] = {}
_last_heartbeat_monotonic: float | None = None
_last_heartbeat_at: str | None = None
#: The environment this sender resolved at start, and where from.  The
#: sender only DRAINS the queue, so a blank env does not refuse alerts here
#: the way it does in the SLA watcher — it degrades the HEARTBEAT to Node
#: "UNSET" (see maybe_heartbeat).  That is a milder defect, but it was
#: equally invisible: nothing reported which environment this pod believed
#: it was in (2026-09-07).
_env: str = ""
_env_source: str = "unset"
_hb_disabled_logged = False


def reset_state_for_tests() -> None:
    """Return the module to its pre-start state.

    ``_thread`` and ``_session_factory`` are cleared here too (2026-09-02).
    Leaving them behind leaks ACROSS TEST FILES: ``get_status`` reports the
    sender as configured and reads queue depth through whatever fake
    session factory the previous test installed, so an unrelated file's
    daemon-surface assertions fail depending on the order xdist happened to
    pick.  A reset that leaves two globals behind is not a reset.
    """
    global _cursor, _last_heartbeat_monotonic, _last_heartbeat_at
    global _hb_disabled_logged, _thread, _session_factory
    global _env, _env_source
    # Stop OUTSIDE the lock — stop_sender takes it to read the thread.
    if _thread is not None and _thread.is_alive():
        stop_sender(timeout=5.0)
    with _lock:
        _cursor = 0
        _retry.clear()
        _dead.clear()
        _last_pass.clear()
        _env = ""
        _env_source = "unset"
        _last_heartbeat_monotonic = None
        _last_heartbeat_at = None
        _hb_disabled_logged = False
        _thread = None
        _session_factory = None


# ── Queue access ──────────────────────────────────────────────────────────

def _fetch_undelivered(session_factory, after_id: int,
                       limit: int) -> list[tuple[int, Any]]:
    """Undelivered rows with id > after_id, oldest first.

    Deliberately NOT ``notification_queue.poll``: that returns the first
    N undelivered rows of ANY kind, and in fan-out mode WebSocket rows
    are never marked delivered — ≥N of them sitting in front would
    starve every alert behind them forever.  A cursor the sender owns
    walks past what is not its to consume.
    """
    from core.database import PendingNotification

    session = session_factory()
    try:
        rows = (
            session.query(PendingNotification)
            .filter(PendingNotification.delivered == False,
                    PendingNotification.id > int(after_id))
            .order_by(PendingNotification.id)
            .limit(int(limit))
            .all()
        )
        return [(r.id, r.payload) for r in rows]
    finally:
        session.close()


def _mark_delivered_safe(session_factory, ids: list[int]) -> None:
    """Record acceptance (FR-ALT-05).  A failure here is logged, never
    raised: the send succeeded, and a re-send later is absorbed by
    OMNIbus deduplication (same Identifier -> Tally), which is cheaper
    than losing the pass."""
    try:
        from core.notification_queue import mark_delivered
        mark_delivered(session_factory, ids)
    except Exception as exc:  # noqa: BLE001 — a failed audit write must not undo a send
        logger.warning("[netcool_sender] sent %s but could not mark "
                       "delivered (%s) — a re-send is possible and the "
                       "console's dedup absorbs it", ids, exc)


# ── Dead letter (FR-ALT-06) ───────────────────────────────────────────────

#: The reserved payload key that marks a row as dead-lettered.  Stamped
#: onto the row itself, not held in memory alone, for two reasons found
#: 2026-09-02:
#:
#: * the sender's cursor is IN MEMORY and resets to 0 on restart, so a
#:   dead-lettered row -- which deliberately stays UNDELIVERED as the
#:   audit answer to "was it accepted?" -- was re-read, re-attempted and
#:   re-dead-lettered on every single pod restart, for ever;
#: * the in-memory registry the ops endpoint reads was empty after a
#:   restart, so the answer to "what did we fail to page anyone about?"
#:   silently became "nothing" -- the worst possible wrong answer for
#:   this particular question.
#:
#: This is the same discipline the Kafka landing table already applies to
#: poison: landed, marked, alerted ONCE, and stepped over.
DEAD_LETTER_KEY = "dead_lettered"


def _stamp_dead_letter_safe(session_factory, nid: int, entry: dict) -> None:
    """Mark the row so it leaves the read set permanently.

    Fail-open and audible: if the stamp cannot be written the event is
    still dead-lettered in memory and still logged CRITICAL — the only
    cost is that a restart re-attempts it, which is the behaviour that
    existed before this function.  Losing the CRITICAL log line to a
    failed stamp write would be far worse.
    """
    if session_factory is None:
        return
    try:
        from core.database import PendingNotification
        session = session_factory()
        try:
            row = session.get(PendingNotification, int(nid))
            if row is None:
                return
            payload = dict(row.payload or {})
            payload[DEAD_LETTER_KEY] = entry
            row.payload = payload
            session.commit()
        finally:
            session.close()
    except Exception as exc:  # noqa: BLE001 — a failed audit write must never swallow the alarm
        logger.error(
            "[netcool_sender] alert %s was dead-lettered but the row could "
            "NOT be marked (%s) — it will be re-attempted after a restart "
            "and may be dead-lettered again", nid, exc)


def recover_dead_letters(session_factory, *, limit: int = MAX_DEAD_LETTERS
                         ) -> int:
    """Rebuild the in-memory registry from the marked rows, at startup.

    Without this, "what did we fail to page anyone about?" answers
    "nothing" after every restart — and an empty answer to that question
    is indistinguishable from a clean one.
    """
    if session_factory is None:
        return 0
    try:
        from sqlalchemy import Text, cast

        from core.database import PendingNotification
        session = session_factory()
        try:
            rows = (session.query(PendingNotification)
                    .filter(PendingNotification.delivered == False,  # noqa: E712
                            cast(PendingNotification.payload, Text)
                            .like('%"' + DEAD_LETTER_KEY + '"%'))
                    .order_by(PendingNotification.id.desc())
                    .limit(int(limit)).all())
        finally:
            session.close()
    except Exception as exc:  # noqa: BLE001 — recovery must never block startup
        logger.error("[netcool_sender] dead-letter registry could not be "
                     "recovered (%s) — the ops view will under-report until "
                     "the next dead letter", exc)
        return 0
    recovered = 0
    with _lock:
        known = {e.get("id") for e in _dead}
        for row in reversed(rows):
            # The SQL narrows; THIS decides.  A JSON `like` matches any
            # payload that merely MENTIONS the key name, and a row that
            # only mentions it was never dead-lettered.
            payload = row.payload if isinstance(row.payload, Mapping) else {}
            entry = payload.get(DEAD_LETTER_KEY)
            if isinstance(entry, Mapping) and row.id not in known:
                _dead.append(dict(entry))
                recovered += 1
        del _dead[:-MAX_DEAD_LETTERS]
    if recovered:
        logger.warning(
            "[netcool_sender] recovered %d dead-lettered alert(s) from the "
            "queue — these were NEVER delivered to the event console",
            recovered)
    return recovered


def _dead_letter(nid: int, body: Any, reason: str,
                 session_factory=None) -> None:
    """Move an event to the dead-letter state and raise the LOCAL alarm.

    CRITICAL, because this line fires exactly when the system built to
    page people could not page anybody: it must be the loudest thing in
    the log.  The row stays UNDELIVERED in the table — the audit answer
    to "was it accepted?" is honestly "no".
    """
    identifier = body.get("Identifier") if isinstance(body, Mapping) else None
    summary = body.get("Summary") if isinstance(body, Mapping) else None
    entry = {
        "id": nid,
        "identifier": identifier,
        "summary": summary,
        "severity": (body.get("Severity")
                     if isinstance(body, Mapping) else None),
        "reason": reason,
        "at": datetime.now(timezone.utc).isoformat(),
    }
    with _lock:
        _dead.append(entry)
        del _dead[:-MAX_DEAD_LETTERS]
    _stamp_dead_letter_safe(session_factory, nid, entry)
    logger.critical(
        "[netcool_sender] DEAD-LETTER: alert %s was NOT delivered to the "
        "event console and will not be retried (%s). A HUMAN MUST LOOK — "
        "whatever this alert was about, nobody was paged for it. "
        "Summary=%.200s", identifier or f"queue row {nid}", reason, summary)


# ── The pass ──────────────────────────────────────────────────────────────

def _validate_body(body: Any) -> str | None:
    """The refusal reason for an unsendable event body, or None."""
    if not isinstance(body, Mapping):
        return (f"event body is {type(body).__name__}, not an object — "
                f"nothing to send")
    if not str(body.get("Identifier") or "").strip():
        return ("event has no Identifier — OMNIbus deduplicates on it, so "
                "an event without one cannot be raised or cleared")
    if not str(body.get("Summary") or "").strip():
        return "event has no Summary — nothing for a human to read at 04:50"
    return None


def _attempt(session_factory, transport, nid: int, body: Mapping[str, Any],
             cfg: Mapping[str, Any], counters: dict[str, int],
             attempts_so_far: int, now: float) -> None:
    """One delivery attempt.  Success marks the row delivered; failure
    schedules a retry or dead-letters after the budget (FR-ALT-06).
    Never raises (FR-ALT-04)."""
    try:
        transport.send(body)
    except Exception as exc:  # noqa: BLE001 — ANY transport failure is a retry, never a raise (FR-ALT-04)
        attempts = attempts_so_far + 1
        if attempts >= int(cfg["max_attempts"]):
            with _lock:
                _retry.pop(nid, None)
            _dead_letter(
                nid, body,
                f"undeliverable after {attempts} attempts, last error: {exc}",
                session_factory=session_factory)
            counters["dead_lettered"] += 1
            return
        with _lock:
            _retry[nid] = {
                "body": dict(body),
                "attempts": attempts,
                "next_at": now + float(cfg["retry_backoff_seconds"]),
                "last_error": str(exc),
            }
        counters["failed"] += 1
        logger.warning(
            "[netcool_sender] send failed for %s (attempt %d/%d, retrying "
            "in %.0fs): %s", body.get("Identifier"), attempts,
            cfg["max_attempts"], cfg["retry_backoff_seconds"], exc)
        return
    with _lock:
        _retry.pop(nid, None)
    _mark_delivered_safe(session_factory, [nid])
    counters["sent"] += 1


def run_pass(session_factory, transport, cfg: Mapping[str, Any] | None
             = None, *, now: float | None = None) -> dict[str, Any]:
    """One drain pass.  Returns counters — numbers, not adjectives.

    Never raises: a broken queue read or a broken transport is a
    counted, logged event, because nothing in the alerting path may fail
    a feed (FR-ALT-04).
    """
    global _cursor, _last_pass
    cfg = dict(cfg) if cfg is not None else load_config()
    at = time.monotonic() if now is None else float(now)
    counters: dict[str, Any] = {
        "polled": 0, "matched": 0, "sent": 0, "failed": 0,
        "invalid": 0, "dead_lettered": 0, "retry_pending": 0, "errors": 0,
    }

    # Retries first — they are older than anything the cursor will find.
    with _lock:
        due = [(nid, dict(entry)) for nid, entry in _retry.items()
               if entry["next_at"] <= at]
    for nid, entry in due:
        _attempt(session_factory, transport, nid, entry["body"], cfg,
                 counters, entry["attempts"], at)

    try:
        rows = _fetch_undelivered(session_factory, _cursor,
                                  cfg["batch_size"])
    except Exception as exc:  # noqa: BLE001 — a broken queue read delays alerts, never fails a feed (FR-ALT-04)
        logger.error("[netcool_sender] queue poll failed (alerts are "
                     "DELAYED, not lost — the rows stay queued): %s", exc)
        counters["errors"] += 1
        counters["retry_pending"] = len(_retry)
        _last_pass = dict(counters)
        return counters

    for nid, payload in rows:
        counters["polled"] += 1
        with _lock:
            _cursor = max(_cursor, int(nid))
        if not (isinstance(payload, Mapping)
                and payload.get("kind") == NETCOOL_KIND):
            continue          # someone else's row (WS fan-out) — untouched
        if payload.get(DEAD_LETTER_KEY):
            # Already dead-lettered and already screamed about.  Stepping
            # over it is what stops a restart replaying every permanently
            # undeliverable alert, one CRITICAL line at a time.
            continue
        counters["matched"] += 1
        body = payload.get("event")
        refusal = _validate_body(body)
        if refusal is not None:
            # One malformed event must never stop the ones behind it.
            counters["invalid"] += 1
            _dead_letter(nid, body if isinstance(body, Mapping) else {},
                         f"malformed event: {refusal}",
                         session_factory=session_factory)
            continue
        _attempt(session_factory, transport, nid, body, cfg, counters,
                 attempts_so_far=0, now=at)

    counters["retry_pending"] = len(_retry)
    _last_pass = dict(counters)
    return counters


# ── Heartbeat (FR-ALT-07) ─────────────────────────────────────────────────

def maybe_heartbeat(session_factory, cfg: Mapping[str, Any], env: str, *,
                    now: float | None = None) -> bool:
    """Enqueue the heartbeat when its interval has elapsed.

    Through the QUEUE, not straight to the transport: the console's
    absence rule then covers the whole pipeline — enqueue, drain and
    send — not just the last hop.  The event's ExpireTime means a dead
    sender's final heartbeat goes stale on the console instead of
    sitting green forever.
    """
    global _last_heartbeat_monotonic, _last_heartbeat_at, _hb_disabled_logged
    interval = float(cfg["heartbeat_interval_seconds"])
    if interval <= 0:
        if not _hb_disabled_logged:
            logger.info(
                "[netcool_sender] heartbeat DISABLED "
                "(heartbeat_interval_seconds=%s) — the console cannot tell "
                "'nothing is wrong' from 'the sender is dead' (FR-ALT-07)",
                interval)
            _hb_disabled_logged = True
        return False
    at = time.monotonic() if now is None else float(now)
    if (_last_heartbeat_monotonic is not None
            and at - _last_heartbeat_monotonic < interval):
        return False
    from core.feed import netcool as _nc
    try:
        # A blank env would be REFUSED by build_identifier; "UNSET" keeps
        # the heartbeat alive and makes the misconfiguration visible on
        # the console instead of silencing the liveness signal.
        event = _nc.heartbeat_event(
            env=str(env or "").strip() or "UNSET",
            business_date=datetime.now(timezone.utc).date())
        _nc.enqueue_event(session_factory, event)
    except Exception as exc:  # noqa: BLE001 — a failed heartbeat is a logged miss, not a crash
        logger.error("[netcool_sender] heartbeat enqueue failed: %s", exc)
        return False
    _last_heartbeat_monotonic = at
    _last_heartbeat_at = datetime.now(timezone.utc).isoformat()
    return True


# ── Daemon wrapper ────────────────────────────────────────────────────────

def _loop(session_factory, transport, cfg: Mapping[str, Any],
          env: str) -> None:
    while not _stop.wait(float(cfg["poll_interval_seconds"])):
        try:
            maybe_heartbeat(session_factory, cfg, env)
            counters = run_pass(session_factory, transport, cfg)
            if counters["matched"] or counters["dead_lettered"]:
                logger.info("[netcool_sender] pass: %s", counters)
        except Exception as exc:  # noqa: BLE001 — pragma: no cover - loop guard
            logger.error("[netcool_sender] pass failed (continuing): %s",
                         exc)


def start_sender(session_factory, *, env: str = "",
                 transport_factory: Callable | None = None) -> bool:
    """Start the drainer, or SAY at INFO why not.  Idempotent.

    ``transport_factory(cfg) -> transport`` injects the transport
    (tests, or a future site transport); default builds from config.
    Returns whether the sender is running.
    """
    global _thread, _session_factory, _env, _env_source
    # Resolve the environment through THE resolver, so the sender's
    # heartbeat and the watcher's alerts can never disagree about which
    # environment this pod is.  An explicit argument still wins.
    if str(env or "").strip():
        _env, _env_source = str(env).strip(), "caller"
    else:
        try:
            from core.config import deploy_environment_source as _des
            _env, _env_source = _des()
        except Exception:                          # noqa: BLE001
            _env, _env_source = "", "unset"
    env = _env
    if not _env:
        logger.warning(
            "[netcool_sender] the deployment environment is UNSET — "
            "heartbeats will be posted under Node 'UNSET' and the console "
            "cannot attribute them to this deployment. Set app.environment "
            "(or QUERYSTUDIO_APP_ENVIRONMENT), e.g. UAT or PROD.")
    cfg = load_config()
    if transport_factory is None:
        reason = announce_refusal(cfg)
        if reason is not None:
            return False
    with _lock:
        if _thread is not None and _thread.is_alive():
            logger.info("[netcool_sender] already running")
            return True
    try:
        transport = (transport_factory(cfg) if transport_factory is not None
                     else create_transport(cfg))
    except Exception as exc:  # noqa: BLE001 — a broken transport is a stated refusal, not a crash
        logger.error("[netcool_sender] alert sender NOT running: transport "
                     "construction failed: %s", exc)
        return False
    _session_factory = session_factory
    # Rebuild "what did we fail to page anyone about?" BEFORE the first
    # pass.  An empty answer to that question is indistinguishable from a
    # clean one, and a restart used to produce exactly that.
    recover_dead_letters(session_factory)
    _stop.clear()
    thread = threading.Thread(
        target=_loop, args=(session_factory, transport, cfg, env),
        name=DAEMON_NAME, daemon=True)
    with _lock:
        _thread = thread
    thread.start()
    logger.info(
        "[netcool_sender] alert sender STARTED: transport=%s "
        "poll_interval=%.0fs max_attempts=%d heartbeat=%.0fs",
        cfg["transport"], cfg["poll_interval_seconds"],
        cfg["max_attempts"], cfg["heartbeat_interval_seconds"])
    return True


def stop_sender(timeout: float = 10.0) -> None:
    _stop.set()
    with _lock:
        thread = _thread
    if thread is not None and thread.is_alive():
        thread.join(timeout=timeout)
        logger.info("[netcool_sender] alert sender stopped")


# ── Status (the operator surface reads this) ──────────────────────────────

def queue_depth(session_factory, *, scan_limit: int = 1000) -> int | None:
    """Undelivered netcool events waiting, or None when unreadable.

    None, never 0, on a read failure: "empty" and "could not be read"
    are opposite findings, and rendering both as 0 teaches an operator
    to trust an absence.
    """
    try:
        rows = _fetch_undelivered(session_factory, 0, scan_limit)
    except Exception as exc:  # noqa: BLE001 — an unreadable depth is None, never a 500
        logger.warning("[netcool_sender] queue depth unreadable: %s", exc)
        return None
    return sum(1 for _, p in rows
               if isinstance(p, Mapping) and p.get("kind") == NETCOOL_KIND)


def get_status(session_factory=None) -> dict:
    """For the operator surface: running or not, and if not, exactly why."""
    cfg = load_config()
    with _lock:
        running = bool(_thread is not None and _thread.is_alive())
        dead = list(_dead)
        retry_pending = len(_retry)
        last_pass = dict(_last_pass)
        hb_at = _last_heartbeat_at
        env, env_source = _env, _env_source
    refusal = None
    if not running:
        refusal = sender_refusal(cfg)
        if refusal is None:
            refusal = (
                "transport is configured but the sender is not running in "
                "this process — either this pod's role gates it to the "
                "worker/scheduler pod, or its startup failed; grep the log "
                "for '[netcool_sender]'")
    sf = session_factory or _session_factory
    depth = queue_depth(sf) if sf is not None else None
    return {
        "running": running,
        "refusal": refusal,
        "transport": cfg["transport"],
        "queue_depth": depth,
        "retry_pending": retry_pending,
        "dead_letter_count": len(dead),
        "dead_letters": dead[-20:],
        "last_pass": last_pass,
        "last_heartbeat_at": hb_at,
        # "which env does this pod think it is, and why" — a pod that
        # believes it is UAT while sitting in PROD is a plausible
        # misconfiguration and was previously unobservable.
        "environment": env or None,
        "environment_source": env_source,
    }
