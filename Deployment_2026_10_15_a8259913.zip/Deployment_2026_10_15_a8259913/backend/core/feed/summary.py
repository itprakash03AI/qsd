"""A feed's WHOLE configuration in words a person reads (2026-10-13, the
owner: "from the dashboard how can I see the config ... if I want to visit
the full config details").

ONE description of a feed, read by the board's "Configuration" view (and any
other screen that needs it): what it reads, when it runs and on which
business calendar, what it waits for, what file it makes, where the file
goes, the checks, the alerts, the re-send policy, and who changed it last.
This module DECIDES nothing: every answer comes from the module that owns it
(the calendar from ``SodTaskGenerator.effective_calendar_name``, the
re-send policy from ``restatement.policy_for``, the dependencies from the
mapping rows, the next date from ``restatement.next_business_date``).  A
secret is never shown -- the destination is read through the same mask the
feed routes use.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Mapping, Optional

logger = logging.getLogger(__name__)

_SOURCE_WORDS = {"saved_query": "Saved query", "sql_file": "Shared SQL file",
                 "published_view": "Published view", "raw_sql": "SQL written in the feed"}
_SCHEDULE_WORDS = {"daily": "Every business day", "month_end": "Last business day of the month",
                   "workday_n": "Business day {n} of the month", "workdays": "Business days {days} of the month",
                   "cron": "Cron {cron}", "on_completion_of": "When {upstream} completes",
                   "on_demand": "Only when someone runs it"}
_POLICY_WORDS = {"rerun": "re-run and deliver again", "hold": "hold for an approver",
                 "decide": "ask a person to decide"}
_WINDOW_WORDS = {"next_business_date": "until the next scheduled business date",
                 "days": "for {d} days", "open": "with no end"}
#: plainer names for a destination's common settings (anything else is
#: shown with its own name, humanized)
_DEST_LABELS = {"remote_dir": "Folder on the server", "remote_path": "Folder on the server",
                "host_key_b64": "Server identity key (pinned)", "username": "Sign-in user",
                "bucket": "Bucket", "prefix": "Folder (prefix)", "path": "Folder"}
_BACKEND_WORDS = {None: "Chosen automatically by size", "": "Chosen automatically by size",
                  "auto": "Chosen automatically by size", "native": "Built in (DuckDB)",
                  "spark_k8s": "Spark on Kubernetes", "airflow": "Airflow + Spark",
                  "spark_connect": "Spark Connect"}


def _humanize(key: str) -> str:
    return str(key).replace("_", " ").strip().capitalize()


_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def _when(v: Any) -> Any:
    """A stored timestamp as a person reads it: "13 Oct 2026, 02:11 UTC"
    (anything that is not one is returned as it was)."""
    try:
        t = v if isinstance(v, datetime) else datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return v
    if t.tzinfo is not None:
        t = t.astimezone(timezone.utc)
    return f"{t.day} {_MONTHS[t.month - 1]} {t.year}, {t.hour:02d}:{t.minute:02d} UTC"


def _row(label: str, value: Any, hint: Optional[str] = None) -> Dict[str, Any]:
    if value is None or value == "" or value == []:
        value = "Not set"
    elif isinstance(value, bool):
        value = "Yes" if value else "No"
    out = {"label": label, "value": value}
    if hint:
        out["hint"] = hint
    return out


def _safe(fn, default=None):
    try:
        return fn()
    except Exception as exc:                            # noqa: BLE001 -- the row says unreadable
        logger.warning("[feed summary] %s", exc)
        return default


def _name_of(db, kind: str, ident: Any) -> Optional[str]:
    if not ident:
        return None
    getter = {"saved_query": "get_query", "sql_file": "get_sql_file",
              "published_view": "get_published_view", "connection": "get_connection"}.get(kind)
    if not getter or not hasattr(db, getter):
        return None
    row = _safe(lambda: getattr(db, getter)(int(ident)))
    if not row:
        return f"#{ident} (not found)"
    return str(row.get("name") or row.get("display_name") or f"#{ident}")


def _schedule_text(feed: Mapping[str, Any]) -> str:
    decl = feed.get("schedule_declaration")
    if not isinstance(decl, dict) or not decl.get("kind"):
        if feed.get("cron_expression"):
            return f"Cron {feed.get('cron_expression')}"
        return "No date rule (every day, the old default)"
    kind = str(decl.get("kind"))
    for_ = {"month_end": ", for the current month end",
            "previous_month_end": ", for the previous month end"}.get(str(decl.get("business_date") or ""), "")
    days = (f"{decl.get('from')} to {decl.get('to')}" if decl.get("from") is not None
            else ", ".join(str(d) for d in decl.get("days") or []))
    return _SCHEDULE_WORDS.get(kind, kind).format(
        n=decl.get("n"), days=days, cron=decl.get("cron") or feed.get("cron_expression"),
        upstream=decl.get("feed") or "?") + for_


def _flat(cfg: Any, prefix: str = "") -> List[Dict[str, Any]]:
    """A (masked) config tree as label/value rows: a secret shows as set,
    never its value."""
    out: List[Dict[str, Any]] = []
    if isinstance(cfg, dict):
        for k, v in cfg.items():
            label = f"{prefix}{_DEST_LABELS.get(str(k), _humanize(k))}"
            if str(k) == "host_key_b64" and isinstance(v, str) and len(v) > 16:
                v = f"…{v[-12:]}"
            if isinstance(v, (dict, list)) and v:
                out += _flat(v, f"{label} › ")
            elif v == "***":
                out.append(_row(label, "Set (hidden)"))
            elif v not in (None, ""):
                out.append(_row(label, v))
    elif isinstance(cfg, list):
        for i, v in enumerate(cfg, 1):
            out += _flat(v, f"{prefix}{i} › ")
    return out


def describe(db, feed: Mapping[str, Any], *, masked: Optional[Mapping[str, Any]] = None,
             today: Optional[date] = None) -> Dict[str, Any]:
    """The feed in sections of (label, value) rows, plus who changed it last.

    ``masked`` is the feed with its secrets masked (the routes'
    ``_mask_feed_secrets``); the destination is read from it only."""
    from core.feed import restatement
    from core.feed.dashboard import calendar_of
    from core.feed.etl_dependency import effective_etl_id
    masked = masked or {}
    today = today or datetime.now(timezone.utc).date()
    sections: List[Dict[str, Any]] = []

    # ── overview ───────────────────────────────────────────────────────
    group = _safe(lambda: db.get_feed_group(int(feed["feed_group_id"]))) if feed.get("feed_group_id") else None
    tmpl = _safe(lambda: db.get_feed_template(int(feed["template_id"]))) if feed.get("template_id") else None
    versions = _safe(lambda: db.list_feed_definition_versions(int(feed["id"]), limit=1), []) or []
    latest = versions[0] if versions else None
    sections.append({"title": "Overview", "rows": [
        _row("Name", feed.get("name")),
        _row("Description", feed.get("description")),
        _row("Switched on", bool(feed.get("is_active", True))),
        _row("Owner", feed.get("created_by")),
        _row("Feed group", (group or {}).get("display_label") or (group or {}).get("name")),
        _row("Made from template", (f"{tmpl.get('name')} ({feed.get('template_member_key')})" if tmpl else None)),
        _row("Created", _when(feed.get("created_at")) if feed.get("created_at") else None),
        _row("Last saved", _when(feed.get("updated_at")) if feed.get("updated_at") else None),
    ]})

    # ── what it reads ──────────────────────────────────────────────────
    st = str(feed.get("source_type") or "")
    qp = feed.get("query_params") if isinstance(feed.get("query_params"), dict) else {}
    rows = [_row("Source", f"{_SOURCE_WORDS.get(st, st)}"
                           + (f": {_name_of(db, st, feed.get('source_id'))}" if st != "raw_sql" else "")),
            _row("Connection", _name_of(db, "connection", feed.get("connection_id"))
                 or "The source's own connection")]
    if feed.get("secondary_connection_id"):
        sst = feed.get("secondary_source_type")
        how = ("the same query" if not sst else
               f"saved query {_name_of(db, 'saved_query', feed.get('secondary_source_id'))}" if sst == "saved_query"
               else "SQL written in the feed")
        rows += [_row("Second connection", _name_of(db, "connection", feed.get("secondary_connection_id"))),
                 _row("Second side runs", how),
                 _row("Combined by", "JOIN" if str(feed.get("combine_mode") or "").lower() == "join"
                      else "Stacking rows, matching columns by name (UNION ALL)")]
    for k, v in sorted(qp.items()):
        if k in ("sql", "secondary_raw_sql") or isinstance(v, (dict, list)):
            continue
        rows.append(_row(f"Value of {{{k}}}", v, "typed in the feed; the query reads it as {%s}" % k))
    if feed.get("token_bindings"):
        rows.append(_row("Values bound in the query", len(feed.get("token_bindings") or []),
                         "literals in the SQL replaced by a date or a feed value each run"))
    rows.append(_row("Runs on", _BACKEND_WORDS.get(feed.get("execution_backend"), feed.get("execution_backend"))))
    sections.append({"title": "What it reads", "rows": rows})

    # ── when it runs ───────────────────────────────────────────────────
    cal = calendar_of(feed)
    from core.feed.sod_generator import SodTaskGenerator
    cur = _safe(lambda: SodTaskGenerator(db).current_business_date(feed, today))
    nxt = _safe(lambda: restatement.next_task(db, feed, cur)) if cur else None
    decl = feed.get("schedule_declaration") if isinstance(feed.get("schedule_declaration"), dict) else None
    kind = str((decl or {}).get("kind") or "")
    # who creates its task: start of day takes every ACTIVE feed and lets the
    # date rule decide (SodTaskGenerator); schedule_enabled is the OLD cron
    # path only, so it is shown only for a feed that has a cron
    if not feed.get("is_active", True):
        made_by = "Nothing -- the feed is switched off"
    elif kind == "on_demand":
        made_by = "Nobody -- it runs only when someone starts it"
    elif kind == "on_completion_of":
        made_by = "Its upstream feed, when that completes and delivers"
    else:
        made_by = "Start of day, on every business date the rule names"
    rows_when = [_row("Its task is created by", made_by),
                 _row("Business-date rule", _schedule_text(feed))]
    if feed.get("cron_expression") and not decl:
        rows_when.append(_row("Cron schedule", "On" if feed.get("schedule_enabled") else "Paused"))
    sections.append({"title": "When it runs", "rows": rows_when + [
        _row("Business calendar", cal["name"],
             {"feed": "set on this feed", "schedule": "named by the date rule",
              "default": "the platform default (none set on the feed)"}.get(cal["from"] or "", None)),
        _row("Business date today", cur.isoformat() if cur else None,
             "the date its data is for on today's run date"),
        _row("Next task", f"runs on {nxt[0].isoformat()} for business date {nxt[1].isoformat()}" if nxt else None),
        _row("Time zone", feed.get("timezone") or "UTC"),
        _row("Expected from", feed.get("sla_from")),
        _row("Due by (SLA)", f"{feed['sla_to']} {feed.get('sla_timezone') or 'UTC'}" if feed.get("sla_to") else None),
        _row("Valid from", feed.get("valid_from")),
        _row("Valid until", feed.get("valid_until")),
        _row("Priority", feed.get("priority"), "1 runs first"),
        # a declaration's rule is translated into this condition for the old
        # path; only a condition written by hand is a separate check
        _row("Run / skip check", "Yes (a SQL check decides each day)"
             if feed.get("action_condition_sql") and not decl else None),
    ]})

    # ── what it waits for ──────────────────────────────────────────────
    deps = _safe(lambda: db.list_etl_dependency_mappings(effective_etl_id(dict(feed))), None)
    if deps is None:
        dep_rows = [_row("Dependencies", "Could not be read")]
    elif not deps:
        dep_rows = [_row("Dependencies", "None -- it runs as soon as it is due")]
    else:
        dep_rows = []
        for m in deps:
            roads = []
            for s in m.get("arrival_sources") or []:
                if not isinstance(s, dict):
                    continue
                kind = s.get("kind")
                roads.append(f"Kafka topic {s['topic']}" if kind == "kafka" and s.get("topic") else
                             f"a row in {s['table']}" if s.get("table") else _humanize(kind or "?"))
            mode = "any one road" if str(m.get("require_mode") or "").lower() == "any" else None
            dep_rows.append(_row(str(m.get("dependency_key")),
                                 (" or ".join(roads) or str(m.get("dependency_type") or "")) +
                                 (f" ({mode})" if mode else ""),
                                 None if m.get("is_active", True) else "switched off"))
    sections.append({"title": "What it waits for", "rows": dep_rows})

    # ── the file ───────────────────────────────────────────────────────
    file_rows = [_row("Format", str(feed.get("output_format") or "csv").upper()),
                 _row("File name", feed.get("output_filename_template"),
                      "{business_date:...} and {run_date:...} are filled each run")]
    file_rows += _flat(feed.get("output_options") or {}, "")
    file_rows.append(_row("Control file", "Yes" if feed.get("control_file_format_id") or feed.get("control_file_template") else "No"))
    sections.append({"title": "The file", "rows": file_rows})

    # ── where it goes ──────────────────────────────────────────────────
    dest = [_row("Delivered by", str(feed.get("destination_type") or "?").upper())]
    dest += _flat(masked.get("destination_config") or {}, "")
    if masked.get("delivery_chain"):
        dest.append(_row("Further delivery steps", len(masked.get("delivery_chain") or [])))
        dest += _flat(masked.get("delivery_chain"), "Step ")
    sections.append({"title": "Where it goes", "rows": dest})

    # ── checks ─────────────────────────────────────────────────────────
    sections.append({"title": "Checks", "rows": [
        _row("Row count change allowed",
             f"{feed['row_count_threshold_pct']}%" if feed.get("row_count_threshold_pct") is not None else None,
             "compared with recent runs; beyond it the file is "
             + ("held for a person" if str(feed.get("row_count_action") or "") == "hold" else "flagged")),
        _row("An empty file is expected", bool(feed.get("row_count_expect_zero"))),
        _row("Fewest rows allowed", feed.get("row_count_min_rows")),
        _row("File checked after delivery", bool(feed.get("integrity_check_enabled"))),
        _row("Retries when it fails", feed.get("max_retries")),
        _row("Wait between retries", f"{feed['retry_delay_seconds']} s" if feed.get("retry_delay_seconds") else None),
    ]})

    # ── alerts + re-sends ──────────────────────────────────────────────
    routes = _safe(lambda: [r for r in (db.list_feed_alert_routes() or [])
                            if (r.get("scope"), r.get("scope_id")) == ("feed", feed.get("id"))], [])
    pol = restatement.policy_for(db, feed)
    win = _WINDOW_WORDS.get(pol.get("window"), str(pol.get("window"))).format(d=pol.get("window_days"))
    sections.append({"title": "Alerts and re-sends", "rows": [
        _row("E-mail when it fails", bool(feed.get("notify_on_failure"))),
        _row("E-mail when it succeeds", bool(feed.get("notify_on_success"))),
        _row("E-mail to", ", ".join(feed.get("notify_emails") or []) if isinstance(feed.get("notify_emails"), list)
             else feed.get("notify_emails")),
        _row("Alert routes for this feed", "; ".join(f"{r.get('kind') or 'every alert'} → {r.get('channel')} {r.get('target')}"
                                                      for r in routes) or None),
        _row("Re-send policy", pol.get("name") or ("this feed's own" if pol.get("scope") == "feed" else None)),
        _row("A newer upstream version on a later day", _POLICY_WORDS.get(pol.get("on_new_message"), pol.get("on_new_message"))),
        _row("A newer upstream version on the same day", _POLICY_WORDS.get(pol.get("same_run_date"), pol.get("same_run_date"))),
        _row("Re-sends accepted", win),
    ]})

    return {"feed_id": feed.get("id"), "name": feed.get("name"), "sections": sections,
            "calendar": cal,
            "last_version": ({"version": latest.get("version"), "by": latest.get("created_by"),
                              "at": latest.get("created_at"),
                              "at_text": _when(latest.get("created_at")) if latest.get("created_at") else None}
                             if latest else None)}
