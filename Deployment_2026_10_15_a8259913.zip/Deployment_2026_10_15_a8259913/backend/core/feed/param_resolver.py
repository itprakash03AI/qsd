"""Feed query parameter resolver — Phase 130 hotfix-13 audit fix #4.

Auto-resolves calendar-derived date tokens for feed SQL execution.
Bridges the gap between scheduled feeds (which have NO user supplying
parameter values) and parametric queries that need `business_date`,
`prev_business_day`, `prev_eom`, etc.

Token syntax: ``{{name}}`` (same as Published Views; reuses
:func:`api.published_views.helpers._substitute_params` so SQL escaping
is uniform across both surfaces).

Built-in tokens (always populated when feed_run + calendar are wired):

  ``business_date``         feed_run.business_date (calendar-rolled by SOD)
  ``business_date_yyyymmdd`` same, formatted YYYYMMDD
  ``business_date_iso``     same, formatted YYYY-MM-DD
  ``run_date``              today UTC
  ``run_date_yyyymmdd``     same, formatted
  ``run_date_iso``          same, formatted
  ``prev_business_day``     business_date - 1 business day (calendar-aware)
  ``prev_business_day_yyyymmdd``
  ``prev_business_day_iso``
  ``prev_eom``              previous month's last business day (COB_PREV_EOM)
  ``prev_eom_yyyymmdd``
  ``prev_eom_iso``
  ``month_end``             this month's last business day
  ``month_end_yyyymmdd``
  ``month_end_iso``
  ``next_month_end``        next month's last business day
  ``next_month_end_yyyymmdd``
  ``next_month_end_iso``

User-defined parameters in ``feed_config.query_params`` override the
auto-resolved tokens by name (so an admin can pin
``{{business_date}}`` to a specific value for a backfill).

Returns a flat dict suitable for passing directly to
``_substitute_params(query_config, params)``.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _fmt(d: date, fmt: str) -> str:
    """Format a date using strftime — graceful on None."""
    if d is None:
        return ""
    return d.strftime(fmt)


def _next_eom(d: date, calendar=None) -> date:
    """End-of-NEXT-month rolled to the most recent business day on/before.

    For Dec 15 → end of January next-year.  For Jan 31 → end of Feb.
    Mirrors the COB_NEXT_EOM convention used by enterprise schedulers.
    """
    # Find first day of (current month + 2), then back up 1 day → last
    # day of (current month + 1).
    y, m = d.year, d.month
    # next-month start
    if m == 12:
        next_first = date(y + 1, 1, 1)
    else:
        next_first = date(y, m + 1, 1)
    # month-after-next start
    if next_first.month == 12:
        month_after_next_first = date(next_first.year + 1, 1, 1)
    else:
        month_after_next_first = date(next_first.year, next_first.month + 1, 1)
    last_day = month_after_next_first - timedelta(days=1)
    if calendar is not None:
        return calendar.previous_business_day_or_today(last_day)
    return last_day


def _this_month_end(d: date, calendar=None) -> date:
    """Last business day of the CURRENT month."""
    y, m = d.year, d.month
    if m == 12:
        next_first = date(y + 1, 1, 1)
    else:
        next_first = date(y, m + 1, 1)
    last_day = next_first - timedelta(days=1)
    if calendar is not None:
        return calendar.previous_business_day_or_today(last_day)
    return last_day


def resolve_feed_params(
    feed_config: Dict[str, Any],
    feed_run: Optional[Dict[str, Any]] = None,
    calendar=None,
) -> Dict[str, Any]:
    """Build the parameter dict for feed SQL substitution.

    :param feed_config: the feed_configs row (used for ``query_params``
        overrides + calendar_name lookup if calendar arg is None).
    :param feed_run: the feed_runs row (used for ``business_date``).
        When None (manual exec without a feed_run), falls back to
        today UTC for business_date.
    :param calendar: a :class:`core.feed.calendar.BusinessCalendar`
        instance or None.  When None, business-day walks degrade to
        plain calendar-day arithmetic (still useful, less precise).
    :returns: flat dict ready for ``_substitute_params(qc, dict)``.
    """
    feed_config = feed_config or {}
    feed_run = feed_run or {}

    # Run date: when the SOD created the row it stored scheduled_time;
    # otherwise use today UTC.
    run_d = None
    if feed_run.get("run_date"):
        rd = feed_run["run_date"]
        run_d = rd if isinstance(rd, date) else _coerce_date(rd)
    if run_d is None:
        scheduled = feed_run.get("scheduled_time")
        if scheduled:
            if isinstance(scheduled, datetime):
                run_d = scheduled.date()
            else:
                run_d = _coerce_date(scheduled)
    if run_d is None:
        run_d = datetime.now(timezone.utc).date()

    # Business date: SOD already calendar-rolled it; trust that value.
    bd = feed_run.get("business_date")
    if bd is None:
        bd = run_d
    elif not isinstance(bd, date):
        bd = _coerce_date(bd) or run_d

    # Calendar-derived helpers
    if calendar is not None:
        prev_bd = calendar.previous_business_day(bd)
        prev_eom_d = calendar.previous_eom(bd)
    else:
        # Best-effort without calendar — back 1 calendar day, prev-month-end.
        prev_bd = bd - timedelta(days=1)
        first_of_this = bd.replace(day=1)
        prev_eom_d = first_of_this - timedelta(days=1)

    month_end_d = _this_month_end(bd, calendar=calendar)
    next_month_end_d = _next_eom(bd, calendar=calendar)

    params: Dict[str, Any] = {
        # Default rendering: ISO (YYYY-MM-DD) for the bare token — what
        # most SQL dialects accept directly.  Specific formats via the
        # *_yyyymmdd / *_iso variants.
        "business_date":            bd.isoformat(),
        "business_date_yyyymmdd":   _fmt(bd, "%Y%m%d"),
        "business_date_iso":        bd.isoformat(),

        "run_date":                 run_d.isoformat(),
        "run_date_yyyymmdd":        _fmt(run_d, "%Y%m%d"),
        "run_date_iso":             run_d.isoformat(),

        "prev_business_day":            prev_bd.isoformat(),
        "prev_business_day_yyyymmdd":   _fmt(prev_bd, "%Y%m%d"),
        "prev_business_day_iso":        prev_bd.isoformat(),

        "prev_eom":                 prev_eom_d.isoformat(),
        "prev_eom_yyyymmdd":        _fmt(prev_eom_d, "%Y%m%d"),
        "prev_eom_iso":             prev_eom_d.isoformat(),

        "month_end":                month_end_d.isoformat(),
        "month_end_yyyymmdd":       _fmt(month_end_d, "%Y%m%d"),
        "month_end_iso":            month_end_d.isoformat(),

        "next_month_end":           next_month_end_d.isoformat(),
        "next_month_end_yyyymmdd":  _fmt(next_month_end_d, "%Y%m%d"),
        "next_month_end_iso":       next_month_end_d.isoformat(),
    }

    # BF-472 (2026-05-19) — workday-N tokens for enterprise feeds that
    # need the actual DATE of the Nth business day of the current
    # month.  Example: a feed that publishes "month-to-date as of WD6"
    # can write its SQL as
    #   WHERE business_close_date <= '{{wd6_this_month_iso}}'
    # and the resolver fills in the literal.  Common workday slots:
    # WD1, WD2, WD3, WD5, WD6, WD10, WD15.  When the requested workday
    # exceeds the month's business-day count, the token expands to
    # an empty string (visible failure mode rather than silent skip).
    if calendar is not None:
        for _n in (1, 2, 3, 5, 6, 10, 15):
            _wd = calendar.nth_business_day_of_month(bd.year, bd.month, _n)
            _key = f"wd{_n}_this_month"
            params[_key] = _wd.isoformat() if _wd else ""
            params[f"{_key}_yyyymmdd"] = _fmt(_wd, "%Y%m%d") if _wd else ""
            params[f"{_key}_iso"] = _wd.isoformat() if _wd else ""
        # BF-472 — first business day of THIS month (== wd1_this_month).
        # Kept as a separate token because "month_start" reads more
        # naturally in feed SQL than "wd1_this_month".
        _ms = calendar.nth_business_day_of_month(bd.year, bd.month, 1)
        params["month_start"] = _ms.isoformat() if _ms else ""
        params["month_start_yyyymmdd"] = _fmt(_ms, "%Y%m%d") if _ms else ""
        params["month_start_iso"] = _ms.isoformat() if _ms else ""

    # User-supplied query_params override the auto-resolved ones.  This
    # lets an admin pin a specific value for backfills (e.g. set
    # business_date='2026-01-15' on a one-off rerun) without editing
    # SQL.  Scalar values only — nested dicts (like
    # query_params.secondary) are intentionally NOT merged into the
    # substitution dict; the secondary side gets its own dict.
    user_params = feed_config.get("query_params") or {}
    for k, v in user_params.items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            params[k] = v

    return params


def _coerce_date(v: Any) -> Optional[date]:
    """Best-effort coercion of strings / datetimes into ``date``."""
    if v is None:
        return None
    if isinstance(v, date) and not isinstance(v, datetime):
        return v
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, str):
        try:
            # ISO-8601, with or without time
            return datetime.fromisoformat(v.replace("Z", "+00:00")).date()
        except ValueError:
            pass
        try:
            # YYYYMMDD compact form
            if len(v) == 8 and v.isdigit():
                return datetime.strptime(v, "%Y%m%d").date()
        except ValueError:
            pass
    return None


def apply_to_query_config(
    query_config: Dict[str, Any],
    feed_config: Dict[str, Any],
    feed_run: Optional[Dict[str, Any]] = None,
    calendar=None,
) -> Dict[str, Any]:
    """Convenience: resolve params + apply substitution in one call.

    Returns the substituted query_config dict (deep-copied), or the
    original when substitution is unavailable (silent fallback so a
    broken import path can't break feed execution).
    """
    params = resolve_feed_params(feed_config, feed_run, calendar)
    try:
        from api.published_views.helpers import _substitute_params
        out = _substitute_params(query_config, params)
    except Exception as exc:
        logger.warning(
            "[param_resolver] _substitute_params unavailable, returning unchanged config: %s",
            exc,
        )
        out = query_config
    # 2026-10-10 -- the OG single-brace vocabulary ({BUSINESSDATE},
    # {SYSTEM_ENTITY}, ...) on every SQL-bearing field, from the SAME
    # resolved params (core/feed/sql_tokens.py is the one renderer; the
    # Spark/Airflow plan calls it too).  Its refusals -- a declared token
    # with no value, a value a literal cannot hold -- PROPAGATE: they are
    # correctness gates, and a feed run with the token left as text
    # matches nothing and certifies an empty file.
    return apply_og_tokens(out, feed_config, params)


def apply_og_tokens(query_config: Dict[str, Any], feed_config: Dict[str, Any],
                    params: Dict[str, Any]) -> Dict[str, Any]:
    """Render ``{TOKEN}`` (OG spelling) in each SQL-bearing field of a
    query_config.  Returns a copy when anything changed, else the input."""
    from core.feed.sql_tokens import render_og_tokens
    try:
        from api.published_views.helpers import _QC_SQL_FIELDS as _fields
    except Exception:  # pragma: no cover -- the tuple is a module constant
        _fields = ("custom_sql", "raw_sql", "secondary_raw_sql")
    if not isinstance(query_config, dict):
        return query_config
    declared = [k for k, v in ((feed_config or {}).get("query_params") or {}).items()
                if isinstance(v, (str, int, float, bool))]
    # 2026-10-11 -- the feed's token BINDINGS (feed_configs.token_bindings)
    # ride into the renderer: a bound literal in the saved query's text is
    # rewritten to its token on the side it was bound for.  The
    # ``secondary_raw_sql`` field IS the secondary side whatever
    # ``_cross_side`` says (a BQB cross-source saved query carries both
    # sides in one config); every other field is the side this execution
    # serves.
    bindings = (feed_config or {}).get("token_bindings") or None
    exec_side = str((feed_config or {}).get("_cross_side") or "")
    # the UPSTREAM CONTRACT this render reads (core/feed/upstream_contract.py)
    from core.feed.upstream_contract import contract_for
    contract = contract_for(feed_config, params) if any(
        isinstance(query_config.get(k), str) and "{" in query_config.get(k) for k in _fields) else None
    out = None
    # 2026-10-14 -- ONE query, each side's tables renamed by configuration
    # (core/feed/table_map.py): applied here, before the tokens, so every
    # source type and every native road gets it
    from core.feed.table_map import apply_for_feed as _map_tables
    has_map = bool(((feed_config or {}).get("query_params") or {}).get("table_map"))
    for key in _fields:
        text = query_config.get(key)
        if not isinstance(text, str) or (not bindings and not has_map and "{" not in text):
            continue
        side = "secondary" if key == "secondary_raw_sql" else exec_side
        if has_map:
            mapped = _map_tables(text, feed_config, side=side)
            if mapped != text:
                if out is None:
                    out = dict(query_config)
                out[key] = mapped
                text = mapped
        if not bindings and "{" not in text:
            continue
        rendered = render_og_tokens(
            text, params, declared=declared,
            feed_id=(feed_config or {}).get("id"),
            side=side, bindings=bindings, contract=contract)
        if rendered != text:
            if out is None:
                out = dict(query_config)
            out[key] = rendered
    return out if out is not None else query_config


def apply_to_raw_sql(
    sql: str,
    feed_config: Dict[str, Any],
    feed_run: Optional[Dict[str, Any]] = None,
    calendar=None,
) -> str:
    """Apply param substitution to a raw SQL string (no query_config wrapping).

    Used by the raw_sql + sql_file source-type branches where the SQL
    is a bare string, not a query_config dict.  Wraps the string in a
    minimal query_config so the canonical substitution helper does the
    SQL-escaping.
    """
    if not sql:
        return sql
    # Wrap into the minimal shape _substitute_params understands.
    qc = {"raw_sql": sql}
    out = apply_to_query_config(qc, feed_config, feed_run, calendar)
    return out.get("raw_sql", sql)
