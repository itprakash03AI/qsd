"""Set feeds up FROM SQL -- the Oracle-package way, through THE template
routes (2026-10-13; the owner: "based on two shared queries I have to set up
5000 jobs ... can I do it directly from PostgreSQL? ... write a function
like an Oracle package and just set up from the DB").

On PostgreSQL this module creates:

``qs_feed_template_apply(p_template, p_matrix, p_feed, p_parameters,
p_dependencies, p_retire_missing, p_dry_run, p_requested_by) -> integer``
    Queues a create / update / apply of the feed TEMPLATE ``p_template``
    and returns the request id.  An existing template takes only what is
    passed (``NULL`` = keep); a new one needs ``p_parameters`` and
    ``p_feed``.  ``p_matrix`` is a JSON array of parameter rows -- build it
    with ``jsonb_agg`` from any table.
``qs_feed_template_apply_status`` (view)
    One row per request: state (pending / running / done / failed), the
    counts (created, updated, unchanged, conflicts, refused, retired,
    orphaned), the error, the times.  ``report`` holds every member's
    outcome, refusals with their reason.

The scheduler's ``feed_template_requests`` job (the scheduler-lock holder,
every few seconds) applies each request through ``api/feed_template_api``
-- the routes the screen uses, so every authoring rule holds (names,
filename collisions, dependency cycles, secrets, version history) and
nothing is ever written to ``feed_configs`` around them.  The database is
the gate: whoever may EXECUTE the function on QueryStudio's own database
already controls every feed, so the request is applied with administrator
rights and stamped with who asked (the database login, or ``p_requested_by``).
Grant EXECUTE to the release / DBA role only.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

FUNCTION_NAME = "qs_feed_template_apply"
STATUS_VIEW = "qs_feed_template_apply_status"
#: requests applied per tick at most (each may be thousands of feeds)
MAX_PER_TICK = 5

_FUNCTION_SQL = f"""
CREATE OR REPLACE FUNCTION {FUNCTION_NAME}(
    p_template       text,
    p_matrix         jsonb   DEFAULT NULL,
    p_feed           jsonb   DEFAULT NULL,
    p_parameters     jsonb   DEFAULT NULL,
    p_dependencies   jsonb   DEFAULT NULL,
    p_retire_missing boolean DEFAULT false,
    p_dry_run        boolean DEFAULT false,
    p_requested_by   text    DEFAULT NULL
) RETURNS integer LANGUAGE sql AS $fn$
    INSERT INTO feed_template_apply_requests
        (template_name, requested_by, parameters, feed, dependencies, matrix,
         retire_missing, dry_run, state, requested_at)
    VALUES (p_template, COALESCE(p_requested_by, session_user),
            p_parameters::json, p_feed::json, p_dependencies::json, p_matrix::json,
            COALESCE(p_retire_missing, false), COALESCE(p_dry_run, false),
            'pending', (now() AT TIME ZONE 'utc'))
    RETURNING id
$fn$;
COMMENT ON FUNCTION {FUNCTION_NAME}(text, jsonb, jsonb, jsonb, jsonb, boolean, boolean, text) IS
  'QueryStudio: queue a feed template create/update/apply; returns the request id. '
  'See view {STATUS_VIEW}. Applied by the scheduler through the authoring rules.';
"""

_VIEW_SQL = f"""
CREATE OR REPLACE VIEW {STATUS_VIEW} AS
SELECT r.id AS request_id, r.template_name, r.template_id, r.requested_by, r.state,
       r.dry_run,
       (r.counts::jsonb ->> 'created')::int   AS created,
       (r.counts::jsonb ->> 'updated')::int   AS updated,
       (r.counts::jsonb ->> 'unchanged')::int AS unchanged,
       (r.counts::jsonb ->> 'conflicts')::int AS conflicts,
       (r.counts::jsonb ->> 'refused')::int   AS refused,
       (r.counts::jsonb ->> 'retired')::int   AS retired,
       (r.counts::jsonb ->> 'orphaned')::int  AS orphaned,
       r.error, r.requested_at, r.started_at, r.finished_at, r.report
FROM feed_template_apply_requests r;
"""

_ensured: Dict[int, bool] = {}


def ensure_sql_objects(db: Any) -> bool:
    """Create / refresh the function and the view (PostgreSQL only; another
    database has no stored functions -- the table is there regardless).
    Once per process.  True when they exist."""
    key = id(db)
    if _ensured.get(key):
        return True
    engine = getattr(db, "engine", None)
    if engine is None or engine.dialect.name != "postgresql":
        return False
    from sqlalchemy import text
    from core.db.models import FeedTemplateApplyRequest
    FeedTemplateApplyRequest.__table__.create(bind=engine, checkfirst=True)
    with engine.begin() as conn:
        conn.execute(text(_FUNCTION_SQL))
        conn.execute(text(_VIEW_SQL))
    _ensured[key] = True
    logger.info("[template_requests] %s() and %s are in place", FUNCTION_NAME, STATUS_VIEW)
    return True


def submit(db: Any, template: str, *, matrix=None, feed=None, parameters=None,
           dependencies=None, retire_missing: bool = False, dry_run: bool = False,
           requested_by: Optional[str] = None) -> int:
    """The function's INSERT for any database (tests, SQLite)."""
    from core.db.models import FeedTemplateApplyRequest
    with db.get_session() as s:
        row = FeedTemplateApplyRequest(
            template_name=template, requested_by=requested_by, parameters=parameters,
            feed=feed, dependencies=dependencies, matrix=matrix,
            retire_missing=bool(retire_missing), dry_run=bool(dry_run), state="pending",
            requested_at=datetime.now(timezone.utc))
        s.add(row)
        s.flush()
        return int(row.id)


def get(db: Any, request_id: int) -> Optional[Dict[str, Any]]:
    from core.db.models import FeedTemplateApplyRequest as R
    with db.get_session(read_only=True) as s:
        row = s.query(R).filter(R.id == int(request_id)).first()
        if row is None:
            return None
        return {c.name: getattr(row, c.name) for c in R.__table__.columns}


#: a request still ``running`` this long after it started belonged to a
#: scheduler that died: it is applied again (an apply is idempotent -- the
#: members it already wrote come back ``unchanged``)
STALE_RUNNING_SECONDS = 1800


def _requeue_stale(db: Any) -> int:
    from datetime import timedelta
    from core.db.models import FeedTemplateApplyRequest as R
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=STALE_RUNNING_SECONDS)
    with db.get_session() as s:
        return int(s.query(R).filter(R.state == "running", R.started_at < cutoff)
                   .update({"state": "pending", "started_at": None}, synchronize_session=False) or 0)


def _claim(db: Any) -> Optional[Dict[str, Any]]:
    """The oldest pending request, moved to ``running`` by a compare-and-
    swap (two schedulers never apply one request twice)."""
    from core.db.models import FeedTemplateApplyRequest as R
    with db.get_session() as s:
        cand = (s.query(R.id).filter(R.state == "pending").order_by(R.id).first())
        if cand is None:
            return None
        n = (s.query(R).filter(R.id == cand[0], R.state == "pending")
             .update({"state": "running", "started_at": datetime.now(timezone.utc)},
                     synchronize_session=False))
        if not n:
            return None
    return get(db, cand[0])


def _finish(db: Any, request_id: int, **fields) -> None:
    from core.db.models import FeedTemplateApplyRequest as R
    fields["finished_at"] = datetime.now(timezone.utc)
    with db.get_session() as s:
        s.query(R).filter(R.id == int(request_id)).update(fields, synchronize_session=False)


async def _apply(db: Any, req: Dict[str, Any]) -> Dict[str, Any]:
    """One request through the template ROUTES; ``{template_id, report}``."""
    from starlette.responses import Response
    import api.feed_template_api as fta
    user = {"username": (req.get("requested_by") or "database")[:100], "role": "admin",
            "auth_source": "sql_function"}
    name = str(req["template_name"]).strip()
    existing = await asyncio.to_thread(db.get_feed_template_by_name, name)
    if existing:
        given = {k: req.get(k) for k in ("parameters", "feed", "dependencies", "matrix")
                 if req.get(k) is not None}
        body = fta.FeedTemplateUpdate(**given, dry_run=bool(req.get("dry_run")),
                                      retire_missing=bool(req.get("retire_missing")),
                                      background=False)
        out = await fta.update_feed_template(int(existing["id"]), body, Response(), user)
        return {"template_id": int(existing["id"]), "report": out.get("report")}
    missing = [k for k in ("parameters", "feed") if req.get(k) is None]
    if missing:
        raise ValueError(f"there is no template named {name!r} yet: a new one needs "
                         + " and ".join(f"p_{m}" for m in missing))
    body = fta.FeedTemplateCreate(name=name, parameters=req["parameters"], feed=req["feed"],
                                  dependencies=req.get("dependencies") or [],
                                  matrix=req.get("matrix") or [],
                                  dry_run=bool(req.get("dry_run")),
                                  retire_missing=bool(req.get("retire_missing")),
                                  background=False)
    out = await fta.create_feed_template(body, Response(), user)
    tpl = out.get("template") or {}
    return {"template_id": tpl.get("id"), "report": out.get("report")}


def process_one(db: Any) -> Optional[Dict[str, Any]]:
    """Claim and apply the oldest pending request; the finished row, or None."""
    req = _claim(db)
    if req is None:
        return None
    if req.get("feed") is not None:
        # the SQL function inserts p_feed past the column type: re-write it
        # through SecretJSON now, so its password is ciphertext from here on
        from core.db.models import FeedTemplateApplyRequest as R
        with db.get_session() as s:
            s.query(R).filter(R.id == req["id"]).update({"feed": req["feed"]},
                                                         synchronize_session=False)
    try:
        res = asyncio.run(_apply(db, req))
        report = res.get("report") or {}
        _finish(db, req["id"], state="done", template_id=res.get("template_id"),
                counts=report.get("counts"), report=report, error=None)
        logger.info("[template_requests] request %s (%s) done: %s", req["id"],
                    req["template_name"], report.get("counts"))
    except Exception as exc:  # noqa: BLE001 -- every failure is RECORDED on the row
        detail = getattr(exc, "detail", None) or str(exc) or type(exc).__name__
        _finish(db, req["id"], state="failed", error=str(detail)[:4000])
        logger.warning("[template_requests] request %s (%s) failed: %s", req["id"],
                       req["template_name"], detail)
    return get(db, req["id"])


def tick(db: Any) -> Dict[str, Any]:
    """One pass: make sure the SQL objects exist, apply up to MAX_PER_TICK."""
    out: Dict[str, Any] = {"sql_objects": False, "applied": 0, "failed": 0}
    try:
        out["sql_objects"] = ensure_sql_objects(db)
    except Exception as exc:  # noqa: BLE001 -- the queue still drains; said
        out["sql_objects_error"] = str(exc)[:300]
        logger.warning("[template_requests] could not create %s(): %s", FUNCTION_NAME, exc)
    out["requeued"] = _requeue_stale(db)
    for _ in range(MAX_PER_TICK):
        row = process_one(db)
        if row is None:
            break
        out["applied" if row["state"] == "done" else "failed"] += 1
    return out


def pending_count(db: Any) -> int:
    from core.db.models import FeedTemplateApplyRequest as R
    with db.get_session(read_only=True) as s:
        return int(s.query(R).filter(R.state.in_(("pending", "running"))).count())
