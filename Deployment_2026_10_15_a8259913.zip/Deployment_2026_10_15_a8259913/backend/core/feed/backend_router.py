"""Backend router — Phase 130 hotfix-13.

Single source of truth for picking the execution backend for a feed.
Replaces the inline `_pick_backend()` in `feed_engine.py` with a
testable, deterministic decision tree that supports operator overrides
+ automated failover.

Decision order (highest priority first):

  1. **Per-execution override** (``backend_override`` kwarg) —
     admin clicked "rerun via airflow" / "rerun via native" on a
     specific row.  Wins over everything else.
  2. **Global override** (``feed_generation.backend_override``) —
     fleet-wide flip set by an admin OR auto-set by the failover
     agent.  Values: ``auto`` | ``native_only`` | ``airflow_only`` |
     ``halt``.  ``halt`` raises ``ExecutionHaltedError`` so nothing
     runs.
  3. **Per-feed manual** (``feed_configs.execution_backend``) — set
     at feed-create time.  Honoured when global override is ``auto``.
     If a feed is pinned to ``airflow`` but the breaker is open AND
     ``airflow_failover_to_native=true`` (default), routes to native
     instead of failing.
  4. **Size threshold** — when manual is ``auto``, queries above
     ``auto_route_threshold_rows`` go to airflow (if enabled +
     breaker closed); otherwise native.

Cross-source feeds (those with ``secondary_connection_id``) used to be
pinned to native — the default feed DAG had no multi-source support.
Phase 130 hotfix-13 lifted that restriction: ``querystudio_feed_factory``
now propagates secondary_* fields and ``generic_feed.py`` reads both
sides + combines via Spark UNION ALL BY NAME / JOIN.  Cross-source feeds
now route through the standard decision tree.

The ``BackendChoice`` result carries a ``reason`` string so failover
events are observable in audit logs / WebSocket broadcasts / admin UI.

LANE AVAILABILITY IS ONE DECISION (2026-10-07, feed lane contract C4/K3;
docs/FEED_LANE_CONTRACT_2026_10_07.html).  "Can this lane take this run?"
is answered ONLY by :func:`lane_availability` (one resolver per lane in
``LANE_AVAILABILITY_RESOLVERS``; every lane BACKEND_CAPABILITIES declares
``detached`` must have one), and "it cannot -- now what?" ONLY by
:func:`lane_unavailable`: an AUTO-routed run falls back to the next
available lane and the fallback is recorded in its reason; a PINNED run
(per-feed pin, per-run override, the global override) is NEVER moved --
it fails with the lane's reason code and message (:class:`LaneRefused`).
The same rule applies when the cluster turns out to be unreachable AT
SUBMIT (:func:`lane_failed_at_submit`), with one more condition: a run
that may already exist on the cluster is never moved at all.  Until this
date the spark_k8s floor moved pinned runs to native silently and the
per-feed airflow pin did the same by default.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


VALID_BACKENDS = ("native", "spark_k8s", "airflow")
VALID_GLOBAL_OVERRIDES = ("auto", "native_only", "airflow_only", "halt")
VALID_PER_EXECUTION_OVERRIDES = ("native", "spark_k8s", "spark_connect", "airflow")  # 'auto' rejected at API


def _spark_k8s_availability(injected=None):
    """Resolve spark_k8s availability for a routing decision.

    ``injected`` (tests / callers that already probed) short-circuits.
    NEVER raises: a broken probe is itself a declared refusal
    (``probe_error``), so routing always proceeds with an auditable
    reason instead of failing the run at the router.
    """
    if injected is not None:
        return injected
    try:
        from core.spark_k8s.availability import current as _sk_current
        return _sk_current()
    except Exception as exc:
        logger.error(
            "[backend_router] spark_k8s availability probe raised (BUG in "
            "the probe, treated as unavailable): %s", exc, exc_info=True,
        )
        # A declared rung, never a bare object: the lane decision reads its
        # reason code (2026-10-07).
        from core.spark_k8s.availability import (
            REASON_PROBE_ERROR, RUNG_UNAVAILABLE, Availability)
        return Availability(False, RUNG_UNAVAILABLE, REASON_PROBE_ERROR,
                            type(exc).__name__)


class ExecutionHaltedError(RuntimeError):
    """Raised when ``backend_override='halt'`` blocks an execution.

    Callers should NOT retry — the operator has explicitly paused new
    work.  Pending rows wait until the operator flips the override
    back to ``auto`` / ``native_only`` / ``airflow_only``.
    """


#: WHO chose the backend (``BackendChoice.origin``, 2026-10-07).  Read
#: when the chosen lane turns out to be unreachable AT RUN TIME: a choice
#: the SIZE ROUTER made may move to native (nobody asked for Spark; the
#: router picked it for capacity), one a person made -- the feed's pin, a
#: per-run override -- fails with the reason instead.
ORIGIN_PER_EXECUTION_OVERRIDE = "per_execution_override"
ORIGIN_PER_FEED_PIN = "per_feed_pin"
ORIGIN_SIZE_ROUTER = "size_router"


@dataclass(frozen=True)
class BackendChoice:
    """Typed result of ``pick_backend()`` — what backend was chosen
    and *why* so the choice is auditable."""

    backend: str            # 'native' | 'spark_k8s' | 'airflow' | 'spark_connect'
    reason: str             # human-readable explanation
    failed_over: bool = False  # True when the chosen backend differs from per-feed preference
    # ORIGIN_* -- set on every branch that can choose spark_k8s; "" for the
    # rest.  Deliberately NOT in to_dict(): the recorded shape is a
    # contract other readers compare by value, and ``reason`` already says
    # it in words.
    origin: str = ""

    def to_dict(self) -> dict:
        return {
            "backend": self.backend,
            "reason": self.reason,
            "failed_over": self.failed_over,
        }


# ═════════════════════════════════════════════════════════════════════════
# THE lane-availability decision (2026-10-07, feed lane contract C4 / K3)
# ═════════════════════════════════════════════════════════════════════════

#: The global override is an operator's fleet-wide statement of intent:
#: like a pin, it is never moved when its lane is unavailable.
ORIGIN_GLOBAL_OVERRIDE = "global_override"

#: Who asked for the lane by NAME.  A run they chose is never moved to
#: another engine when that lane is unavailable -- it fails with the
#: lane's reason (K3).  Only the size router's choices fall back.
PINNED_ORIGINS = frozenset({ORIGIN_PER_EXECUTION_OVERRIDE,
                            ORIGIN_PER_FEED_PIN, ORIGIN_GLOBAL_OVERRIDE})

REASON_LANE_OK = "ok"
REASON_AIRFLOW_DISABLED = "airflow_disabled"
REASON_AIRFLOW_BREAKER_OPEN = "airflow_breaker_open"
REASON_SPARK_CONNECT_DISABLED = "spark_connect_disabled"
#: K6: the run's output must come back through QueryStudio's artifact
#: store (suppressed / delivered from the webhook) and none is usable.
REASON_NO_ARTIFACT_STORE = "no_artifact_store"
#: A lane with no resolver -- unknown is unsafe, so it is unavailable.
REASON_NO_RESOLVER = "no_availability_resolver"


@dataclass(frozen=True)
class LaneAvailability:
    """THE answer to "can this lane take this run?" -- never a bare bool:
    the reason code travels into ``BackendChoice.reason``, the refusal,
    the API error and the log.  ``rung`` is the spark_k8s ladder's rung
    (``spark_application`` / ``driver_pod`` / ``unavailable``), so the
    describe() text the routing reasons carry is unchanged for that lane."""

    lane: str
    available: bool
    reason_code: str
    detail: str = ""
    rung: str = ""
    #: The ladder's own describe() text, kept verbatim for spark_k8s so
    #: every routing reason and API detail reads exactly as before.
    described: str = ""

    def describe(self) -> str:
        if self.described:
            return self.described
        head = self.rung or ("available" if self.available else "unavailable")
        return (f"{head}:{self.reason_code}"
                + (f"({self.detail})" if self.detail else ""))


class LaneRefused(RuntimeError):
    """A PINNED run's lane cannot take it, and a pinned run is never moved
    (K3).  The message is plain language with the reason code; no
    transport text.  ``choice`` is the pinned choice (what the run asked
    for), so the caller records the lane the operator named."""

    def __init__(self, choice: "BackendChoice",
                 availability: LaneAvailability, message: str):
        self.choice = choice
        self.availability = availability
        self.lane = availability.lane
        self.reason_code = availability.reason_code
        self.detail = availability.detail
        self.origin = choice.origin
        super().__init__(message)


class _LaneContext:
    """What a resolver may read: the router's config accessor, the
    breaker state the engine owns, an injected spark_k8s ladder answer
    (tests / callers that already probed), and the run's stored "do not
    deliver" decision."""

    __slots__ = ("cfg", "airflow_breaker_open", "spark_k8s_availability",
                 "delivery_suppressed")

    def __init__(self, cfg, airflow_breaker_open, spark_k8s_availability,
                 delivery_suppressed):
        self.cfg = cfg
        self.airflow_breaker_open = bool(airflow_breaker_open)
        self.spark_k8s_availability = spark_k8s_availability
        self.delivery_suppressed = delivery_suppressed


def _native_lane(feed_config: dict, ctx: _LaneContext) -> LaneAvailability:
    """In-process DuckDB: no detached compute to be down."""
    return LaneAvailability("native", True, REASON_LANE_OK)


def _spark_k8s_lane(feed_config: dict, ctx: _LaneContext) -> LaneAvailability:
    """The spark_k8s ladder (core/spark_k8s/availability.py: config,
    client, credentials, cluster answering, RBAC, operator) -- and K6:
    a run whose output must come back through QueryStudio's artifact
    store needs a usable one."""
    ladder = _spark_k8s_availability(ctx.spark_k8s_availability)
    try:
        ladder_text = str(ladder.describe())
    except Exception:
        ladder_text = ""
    if not getattr(ladder, "available", False):
        return LaneAvailability(
            "spark_k8s", False,
            str(getattr(ladder, "reason_code", "") or "probe_error"),
            str(getattr(ladder, "detail", "") or ""),
            rung=str(getattr(ladder, "rung", "") or "unavailable"),
            described=ladder_text)
    from core.spark_k8s.feed_conf import (
        artifact_store_problem, run_needs_artifact_store)
    if run_needs_artifact_store(feed_config, ctx.delivery_suppressed):
        problem = artifact_store_problem()
        if problem:
            return LaneAvailability(
                "spark_k8s", False, REASON_NO_ARTIFACT_STORE,
                f"this run does not deliver from the Spark job (a backfill "
                f"without delivery, or QueryStudio delivers it), so its file "
                f"must come back through the artifact store -- {problem}",
                rung="unavailable")
    return LaneAvailability("spark_k8s", True,
                            str(getattr(ladder, "reason_code", "")
                                or REASON_LANE_OK),
                            str(getattr(ladder, "detail", "") or ""),
                            rung=str(getattr(ladder, "rung", "") or ""),
                            described=ladder_text)


def _airflow_lane(feed_config: dict, ctx: _LaneContext) -> LaneAvailability:
    """Airflow is the ONE road's orchestrator, not a second engine
    (2026-10-08): its DAG submits the run through POST /spark-submit, so
    the lane can take a run only when Airflow is enabled, its breaker is
    closed AND spark_k8s can take that run (the ladder and, for a run
    whose file comes back through QueryStudio, the artifact store).  The
    spark_k8s answer travels under its own reason code so a pinned
    airflow run fails naming the rung (``no_artifact_store``,
    ``crd_not_installed``, ...) and the remedy table applies.  Until this
    date the lane said "available" whenever Airflow was up and the DAG
    then failed at /spark-submit, five minutes and one retry later."""
    if not getattr(ctx.cfg, "airflow_enabled", False):
        return LaneAvailability("airflow", False, REASON_AIRFLOW_DISABLED,
                                "feed_generation.airflow.enabled=false")
    if ctx.airflow_breaker_open:
        return LaneAvailability("airflow", False, REASON_AIRFLOW_BREAKER_OPEN,
                                "the Airflow circuit breaker is open")
    via = _spark_k8s_lane(feed_config, ctx)
    if not via.available:
        return LaneAvailability(
            "airflow", False, via.reason_code,
            f"the Airflow road submits through POST /spark-submit, and "
            f"spark_k8s cannot take this run: {via.describe()}",
            rung=via.rung or "unavailable")
    return LaneAvailability("airflow", True, REASON_LANE_OK,
                            f"via spark_k8s {via.describe()}",
                            rung=via.rung)


def _spark_connect_lane(feed_config: dict,
                        ctx: _LaneContext) -> LaneAvailability:
    try:
        from core.config import spark_connect as _sc_cfg
        enabled = bool(getattr(_sc_cfg, "enabled", False))
    except Exception as exc:
        return LaneAvailability(
            "spark_connect", False, REASON_SPARK_CONNECT_DISABLED,
            f"spark_connect config unreadable ({type(exc).__name__})")
    if not enabled:
        return LaneAvailability("spark_connect", False,
                                REASON_SPARK_CONNECT_DISABLED,
                                "spark_connect.enabled=false")
    return LaneAvailability("spark_connect", True, REASON_LANE_OK)


#: One resolver per lane.  A lane BACKEND_CAPABILITIES declares
#: ``detached`` without an entry here is UNAVAILABLE (unknown = unsafe),
#: and the conformance guard fails the build.
LANE_AVAILABILITY_RESOLVERS = {
    "native": _native_lane,
    "spark_k8s": _spark_k8s_lane,
    "airflow": _airflow_lane,
    "spark_connect": _spark_connect_lane,
}


def lane_availability(lane: str, feed_config: Optional[dict] = None, *,
                      cfg=None, airflow_breaker_open: bool = False,
                      spark_k8s_availability=None,
                      delivery_suppressed: Optional[bool] = None,
                      ) -> LaneAvailability:
    """THE answer to "can ``lane`` take this run?" -- the ONE place it is
    decided, for routing (every branch of :func:`pick_backend`), the
    Airflow DAG's ``/spark-submit`` seam, the backend picker and the
    posture card.  Never raises.

    ``delivery_suppressed`` is the run's stored "do not deliver" decision
    (``feed_executions.delivery_suppressed``); None falls back to the
    engine's stash on ``feed_config['_delivery_suppressed']``.
    """
    name = (lane or "").strip().lower()
    resolver = LANE_AVAILABILITY_RESOLVERS.get(name)
    if resolver is None:
        return LaneAvailability(
            name, False, REASON_NO_RESOLVER,
            f"lane {name!r} declares no availability resolver "
            f"(backend_router.LANE_AVAILABILITY_RESOLVERS) -- unknown is "
            f"unsafe")
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg
    fc = dict(feed_config or {})
    if delivery_suppressed is None and fc.get("_delivery_suppressed") \
            is not None:
        delivery_suppressed = bool(fc["_delivery_suppressed"])
    ctx = _LaneContext(cfg, airflow_breaker_open, spark_k8s_availability,
                       delivery_suppressed)
    try:
        return resolver(fc, ctx)
    except Exception as exc:
        logger.error("[backend_router] availability resolver for %s raised "
                     "(a BUG in the resolver, treated as unavailable): %s",
                     name, exc, exc_info=True)
        return LaneAvailability(name, False, "probe_error",
                                f"BUG {type(exc).__name__}: {exc}"[:300])


#: Where an AUTO-routed run goes when its lane cannot take it: the large
#: feed order (spark_k8s -> airflow -> native).  Native is always last
#: and always available.
_AUTO_FALLBACK_ORDER = ("spark_k8s", "airflow", "native")

_REMEDY = {
    REASON_NO_ARTIFACT_STORE: (
        "configure spark_k8s.artifact_bucket (QueryStudio's own S3 store "
        "for a Spark run that does not deliver), or run it with "
        "backend=native"),
    REASON_AIRFLOW_DISABLED: (
        "enable feed_generation.airflow, or pin the feed to another "
        "backend"),
    REASON_AIRFLOW_BREAKER_OPEN: (
        "wait for the Airflow breaker to close, or run it with "
        "backend=native"),
    REASON_SPARK_CONNECT_DISABLED: (
        "enable spark_connect, or run it with another backend"),
}


def _who_asked(choice: "BackendChoice") -> str:
    if choice.origin == ORIGIN_PER_EXECUTION_OVERRIDE:
        return (f"This run was sent to {choice.backend} by a per-run "
                f"backend override")
    if choice.origin == ORIGIN_PER_FEED_PIN:
        return f"This feed is pinned to {choice.backend}"
    if choice.origin == ORIGIN_GLOBAL_OVERRIDE:
        return (f"feed_generation.backend_override sends every feed to "
                f"{choice.backend}")
    return f"This run was sent to {choice.backend}"


def _refusal_message(choice: "BackendChoice",
                     availability: LaneAvailability) -> str:
    detail = f": {availability.detail}" if availability.detail else ""
    remedy = _REMEDY.get(availability.reason_code) or (
        "start the cluster, or run it with backend=native"
        if availability.lane in ("spark_k8s", "airflow")
        else "make the lane available, or run it with backend=native")
    return (f"{availability.lane} is unavailable "
            f"[{availability.reason_code}]{detail}.  {_who_asked(choice)}, "
            f"so it was not moved to another engine -- {remedy}.")


def lane_unavailable(choice: "BackendChoice", availability: LaneAvailability,
                     *, feed_config: Optional[dict] = None, cfg=None,
                     airflow_breaker_open: bool = False,
                     spark_k8s_availability=None,
                     delivery_suppressed: Optional[bool] = None,
                     fallback_order: Optional[tuple] = None,
                     ) -> "BackendChoice":
    """THE answer to "the chosen lane cannot take this run -- now what?"

    * a PINNED choice (``PINNED_ORIGINS``; an unknown origin counts as one
      -- unknown is unsafe) raises :class:`LaneRefused` with the lane's
      reason code and message.  One DECLARED exception, the operator's
      own: ``feed_generation.airflow_failover_to_native=true`` lets a
      per-FEED airflow pin move to native while the breaker is open,
      naming that key in the reason;
    * an AUTO-routed choice moves to the next available lane of
      ``fallback_order`` (default spark_k8s -> airflow -> native), and the
      reason records which lane refused and why.
    """
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg
    if choice.origin in PINNED_ORIGINS or not choice.origin:
        if (choice.origin == ORIGIN_PER_FEED_PIN
                and availability.lane == "airflow"
                and availability.reason_code == REASON_AIRFLOW_BREAKER_OPEN
                and getattr(cfg, "airflow_failover_to_native", False)
                is True):
            return BackendChoice(
                backend="native",
                reason=("airflow_pinned_but_breaker_open_failover_enabled"
                        "(declared: feed_generation."
                        "airflow_failover_to_native=true)"),
                failed_over=True)
        raise LaneRefused(choice, availability,
                          _refusal_message(choice, availability))
    for lane in (fallback_order or _AUTO_FALLBACK_ORDER):
        if lane == availability.lane:
            continue
        av = lane_availability(lane, feed_config, cfg=cfg,
                               airflow_breaker_open=airflow_breaker_open,
                               spark_k8s_availability=spark_k8s_availability,
                               delivery_suppressed=delivery_suppressed)
        if av.available:
            logger.warning(
                "[backend_router] feed %s: %s cannot take this run (%s) -- "
                "auto-routed, so it moves to %s",
                (feed_config or {}).get("id"), availability.lane,
                availability.describe(), lane)
            return BackendChoice(
                backend=lane,
                reason=(f"{availability.lane}_unavailable"
                        f"[{availability.describe()}](was={choice.reason})"),
                failed_over=True, origin=choice.origin)
    return BackendChoice(
        backend="native",
        reason=(f"{availability.lane}_unavailable"
                f"[{availability.describe()}](was={choice.reason})"),
        failed_over=True, origin=choice.origin)


def _feed_source_is_iceberg(feed_config: dict) -> bool:
    """Iceberg-format safety-floor probe (2026-07-15).

    Returns True when the feed's resolved SQL (primary or secondary side)
    references a registered table whose format == "iceberg" on its
    connection.  Both non-native feed backends are Iceberg-blind:

      * ``spark_connect`` — spark_connect_executor does
        ``session.read.parquet(prefix)``
      * ``airflow`` — generic_feed.py DAG does the same via Spark on K8s

    A plain-parquet scan of an Iceberg prefix is snapshot-blind (reads
    every historical file) AND delete-blind (V2 merge-on-read delete
    files never applied) → silent overcount.  Only the native DuckDB
    backend reads through the MoR-correct iceberg_reader chokepoint.

    Resolution mirrors the Phase 145.2 estimator in feed_engine
    (resolve_feed_sql → connection config registered_tables →
    extract_referenced_tables).  Returns False on ANY resolution error
    or when the DB manager isn't initialised (unit tests) so existing
    routing behaviour is preserved for non-iceberg / unresolvable feeds.
    """
    try:
        # Lazy import — feed_engine owns the initialised _db_manager.
        # No top-level cycle: feed_engine imports this module lazily too.
        from core import feed_engine as _fe
        dbm = getattr(_fe, "_db_manager", None)
        if dbm is None:
            return False
        from core.feed_sql_resolver import resolve_feed_sql
        from core.query_hints import extract_referenced_tables

        preview = resolve_feed_sql(dbm, feed_config)

        def _side_is_iceberg(sql, conn_id) -> bool:
            if not sql or not conn_id:
                return False
            conn_raw = dbm.get_connection_raw(conn_id)
            reg = (conn_raw or {}).get("config", {}).get("registered_tables") or []
            iceberg_names = {
                str(t.get("name") or "").strip().lower()
                for t in reg
                if isinstance(t, dict)
                and str(t.get("format") or "parquet").lower() == "iceberg"
            }
            iceberg_names.discard("")
            if not iceberg_names:
                return False
            refs = extract_referenced_tables(reg, sql)
            return any(
                str(r).strip().lower() in iceberg_names for r in (refs or [])
            )

        if _side_is_iceberg(
            preview.get("sql"),
            preview.get("connection_id") or feed_config.get("connection_id"),
        ):
            return True
        return _side_is_iceberg(
            preview.get("secondary_sql"),
            feed_config.get("secondary_connection_id"),
        )
    except Exception as exc:
        logger.debug(
            "[backend_router] iceberg floor probe failed (floor skipped): %s",
            exc,
        )
        return False


def snowflake_uses_key_pair(conn_cfg: dict) -> bool:
    """Does this Snowflake connection log in with a KEY PAIR -- a typed or
    attached key, or a key-pair System Account (auth_type key_pair)?"""
    cfg = conn_cfg or {}
    return (str(cfg.get("auth_type") or "").strip().lower() == "key_pair"
            or bool(str(cfg.get("private_key") or "").strip()))


def _feed_sql_connector_type(feed_config: dict) -> str:
    """SQL-connector safety-floor probe (2026-08-22; type-aware 2026-09-03).

    Returns the PRIMARY connection's connector type (lowered) when the
    feed reads from a SQL connector, and "" when it is S3-backed or the
    probe cannot tell.  Mirrors the interactive gate's S3 test
    (``spark_dispatch.should_use_spark_connect`` gate 4 ``not_s3``:
    bucket/bucket_name in the connection config), plus the explicit
    ``connection_type == "s3"`` spelling.

    The TYPE (not just the boolean) matters since the capability
    declaration was corrected to name WHICH connector types a Spark lane
    has a JDBC grammar for — ``databricks``/``athena``/``rest_api`` are
    SQL connectors with no grammar, and the old boolean floor waved them
    through to die at conf-build.

    Fail-open ("" — floor skipped) on ANY resolution error or when the
    DB manager isn't initialised (unit tests) — same posture as the
    iceberg floor probe above.  The execution-time refusal in
    ``build_jdbc_config`` remains the guarantee; this floor is the
    routing courtesy that keeps the feed RUNNING on a backend that can
    actually read its source.
    """
    try:
        from core import feed_engine as _fe
        dbm = getattr(_fe, "_db_manager", None)
        if dbm is None:
            return ""
        conn_id = feed_config.get("connection_id")
        if not conn_id:
            return ""
        conn_raw = dbm.get_connection_raw(conn_id)
        if not conn_raw:
            return ""
        ctype = str(conn_raw.get("connection_type") or "").lower()
        ccfg = conn_raw.get("config") or {}
        _is_s3 = (ctype == "s3"
                  or bool(ccfg.get("bucket") or ccfg.get("bucket_name")))
        if _is_s3:
            return ""
        # 2026-10-03 -- a Snowflake KEY-PAIR login is its own source kind
        # here: the Spark JDBC lanes carry a user + password only, so no
        # typed lane declares "snowflake:key_pair" and the floor keeps the
        # feed on native (which logs in with the key, Vault or attached)
        # instead of building a pod that cannot log in.
        if ctype == "snowflake" and snowflake_uses_key_pair(ccfg):
            return "snowflake:key_pair"
        return ctype or "unknown"
    except Exception as exc:
        logger.debug(
            "[backend_router] sql-connector floor probe failed "
            "(floor skipped): %s", exc,
        )
        return ""


def _feed_source_is_sql_connector(feed_config: dict) -> bool:
    """Boolean face of :func:`_feed_sql_connector_type` (kept for the
    pre-2026-09-03 callers/tests)."""
    return bool(_feed_sql_connector_type(feed_config))


def pick_backend(
    feed_config: dict,
    *,
    per_execution_override: Optional[str] = None,
    estimated_rows: Optional[int] = None,
    cfg=None,
    airflow_breaker_open: bool = False,
    spark_k8s_availability=None,
    delivery_suppressed: Optional[bool] = None,
) -> BackendChoice:
    """Resolve the backend for one execution.

    Raises :class:`LaneRefused` when the run was PINNED (per-feed pin,
    per-run override, global override) to a lane that cannot take it --
    K3: a pin is never moved silently.  ``delivery_suppressed`` is the
    run's "do not deliver" decision (K6 reads it: a run whose file must
    come back through the artifact store).

    Then apply the iceberg
    safety floor (2026-07-15) as a SINGLE post-decision chokepoint:
    when the decision tree picks ``spark_connect`` or ``airflow`` but
    the feed's source references an iceberg-format registered table,
    the choice is floored to ``native`` (DuckDB — the only backend that
    applies Iceberg snapshots + V2 merge-on-read delete files).  The
    floor covers every branch — per-execution override, global override,
    per-feed pin and the auto tiers — without touching the decision
    tree itself.  It can be lifted once the Spark executors read through
    a real Iceberg catalog.  ``halt`` still raises before the floor.

    See :func:`_pick_backend_decision` for the decision tree contract.
    """
    choice = _pick_backend_decision(
        feed_config,
        per_execution_override=per_execution_override,
        estimated_rows=estimated_rows,
        cfg=cfg,
        airflow_breaker_open=airflow_breaker_open,
        spark_k8s_availability=spark_k8s_availability,
        delivery_suppressed=delivery_suppressed,
    )
    # CAPABILITY first (K2: what a lane cannot DO floors to native, pin or
    # not), then AVAILABILITY -- a run the floors send to native never
    # needed the lane, so its being down must not refuse it.
    choice = _apply_capability_floors(choice, feed_config)
    # ── Lane availability (2026-10-07, C4/K3; was the spark_k8s floor of
    # 2026-08-22) ─────────────────────────────────────────────────────
    # ONE decision for every detached lane and every branch that can
    # choose one: the lane's resolver answers, and lane_unavailable says
    # what happens -- an auto-routed run falls back with the reason, a
    # PINNED run raises LaneRefused.  The old floor moved a pinned
    # spark_k8s run to native in silence (D4); the per-feed airflow pin
    # did the same by default.
    if choice.backend != "native":
        _lane_av = lane_availability(
            choice.backend, feed_config, cfg=cfg,
            airflow_breaker_open=airflow_breaker_open,
            spark_k8s_availability=spark_k8s_availability,
            delivery_suppressed=delivery_suppressed)
        if not _lane_av.available:
            choice = lane_unavailable(
                choice, _lane_av, feed_config=feed_config, cfg=cfg,
                airflow_breaker_open=airflow_breaker_open,
                spark_k8s_availability=spark_k8s_availability,
                delivery_suppressed=delivery_suppressed)
            # the fallback lane answers to the same capability floors
            choice = _apply_capability_floors(choice, feed_config)
    return choice


def _apply_capability_floors(choice: BackendChoice,
                             feed_config: dict) -> BackendChoice:
    """The CAPABILITY floors (K2): each can only move a choice toward
    native, each carries its reason.  Availability is not decided here
    (:func:`lane_availability`)."""
    # ── Cross-source capability floor (2026-08-04) ────────────────────
    # Spark Connect executes a SINGLE source (feed_engine.
    # _execute_spark_connect) — it cannot materialise + combine a
    # secondary side.  The capability gate in core.feed.source_plan
    # refuses such a run fail-CLOSED at execution time; this floor is the
    # routing courtesy that keeps the feed RUNNING (on native, which
    # combines) instead of failing at 3 AM.  Covers every branch incl.
    # per-execution override.  Detection is inheritance-aware (a feed
    # over a cross-source saved query / sql_file / PV counts) and
    # fail-open — the execution-time gate remains the guarantee.
    # NEVER changes the completeness verdict: native produces the full
    # combined output.
    if choice.backend == "spark_connect":
        _is_cross = False
        try:
            from core import feed_engine as _fe
            from core.feed.source_plan import detect_cross_source
            _is_cross = detect_cross_source(
                getattr(_fe, "_db_manager", None), feed_config,
            )
        except Exception as _cs_exc:
            logger.debug(
                "[backend_router] cross-source floor probe failed "
                "(floor skipped): %s", _cs_exc,
            )
        if _is_cross:
            logger.warning(
                "[backend_router] [feed-crosssource] feed %s is cross-source "
                "(primary_conn=%s secondary_conn=%s combine=%s) — flooring "
                "backend spark_connect → native (Spark Connect executes a "
                "single source; running it there would emit only the "
                "primary side).  Original reason: %s",
                feed_config.get("id"),
                feed_config.get("connection_id"),
                feed_config.get("secondary_connection_id"),
                feed_config.get("combine_mode") or "union",
                choice.reason,
            )
            return BackendChoice(
                backend="native",
                reason=f"cross_source_spark_connect_floor(was={choice.reason})",
                failed_over=True,
            )

    # ── SQL-connector capability floor (2026-08-22) ───────────────────
    # Spark Connect reads ONLY S3 parquet (spark_connect_executor:
    # _resolve_s3_paths / _register_tables_as_views): a Starburst /
    # Snowflake / Oracle-sourced feed routed there fails at execution
    # with "no S3-backed tables resolved".  The interactive path has had
    # this gate since day one (spark_dispatch gate 4 ``not_s3``); feeds
    # had floors for iceberg and cross-source but not this one, so with
    # ``spark_connect.enabled=true`` the auto middle tier dispatched any
    # 0.5M-10M SQL-connector feed to a backend that cannot read it.
    # Declaration-driven (repo registry pattern): a backend that does not
    # declare ``sql_connector_source: True`` in BACKEND_CAPABILITIES
    # never receives a SQL-connector feed — UNKNOWN = UNSAFE.  Covers
    # every branch incl. the per-execution override.
    if choice.backend != "native":
        _sql_ctype = _feed_sql_connector_type(feed_config)
        if _sql_ctype:
            # 2026-09-03 — TYPE-aware: the declaration names which
            # connector types each Spark lane has a JDBC grammar for
            # (imported from that grammar).  A boolean check waved
            # databricks/athena/rest_api through to die at conf-build.
            _can_sql_connector = False
            try:
                from core.feed.source_plan import (
                    backend_supports_sql_connector,
                )
                _can_sql_connector = backend_supports_sql_connector(
                    choice.backend, _sql_ctype)
            except Exception as _cap_exc:
                logger.debug(
                    "[backend_router] capability registry unreadable — "
                    "treating %s as unable to read SQL connectors: %s",
                    choice.backend, _cap_exc,
                )
            if not _can_sql_connector:
                logger.warning(
                    "[backend_router] feed %s reads from a SQL connector "
                    "(connection_id=%s, type=%s) but backend %s has no "
                    "read path for that type — flooring to native "
                    "(connector streaming).  Original reason: %s",
                    feed_config.get("id"), feed_config.get("connection_id"),
                    _sql_ctype, choice.backend, choice.reason,
                )
                return BackendChoice(
                    backend="native",
                    reason=(
                        f"sql_connector_source_floor(type={_sql_ctype},"
                        f"was={choice.backend}:{choice.reason})"
                    ),
                    failed_over=True,
                )

    # ── Step-source capability floor (2026-09-03) ─────────────────────
    # Source kinds are discovered STEPS; a Spark lane's job resolves
    # SQL/S3 shapes only.  Whether a kind needs the native dispatch is
    # declared BY THE STEP (SourceTraits.sql_shape) and read through
    # source_plan.source_step_requires_native — never a hardcoded name
    # list, or the coupling the step registry removed comes back here.
    # Before this floor, an ``api``-source feed pinned or routed to
    # spark_k8s reached source_plan.assert_backend_capability and was
    # refused LOUDLY at execution; the floor keeps it RUNNING instead.
    # Fail-open (None = probe couldn't answer → floor skipped): the
    # execution-time gate remains the guarantee.
    if choice.backend != "native":
        _caps_step = False
        _needs_native = False
        try:
            from core.feed.source_plan import (
                BACKEND_CAPABILITIES as _ss_caps,
                source_step_requires_native,
            )
            _caps_step = bool(_ss_caps.get(choice.backend, {})
                              .get("step_source", False))
            if not _caps_step:
                _needs_native = source_step_requires_native(
                    feed_config.get("source_type") or "") is True
        except Exception as _ss_exc:
            logger.debug(
                "[backend_router] step-source floor probe failed "
                "(floor skipped): %s", _ss_exc,
            )
        if not _caps_step and _needs_native:
            logger.warning(
                "[backend_router] feed %s uses the STEP-served source "
                "%r but backend %s executes SQL/S3 shapes only — "
                "flooring to native (step dispatch).  Original "
                "reason: %s",
                feed_config.get("id"), feed_config.get("source_type"),
                choice.backend, choice.reason,
            )
            return BackendChoice(
                backend="native",
                reason=(
                    f"step_source_floor("
                    f"source_type={feed_config.get('source_type')},"
                    f"was={choice.backend}:{choice.reason})"
                ),
                failed_over=True,
            )

    # ── Output-format capability floor (2026-10-07, lane contract K2) ─
    # What a lane cannot produce it refuses HERE, at routing -- never by
    # degrading at run time.  The Spark job answered an Excel feed with a
    # PARQUET file and a log warning, so the counterparty's file format
    # depended on the size router.  Declaration-driven like every floor
    # (BACKEND_CAPABILITIES ``output_formats``); covers every branch.
    if choice.backend != "native":
        _fmt = str(feed_config.get("output_format") or "csv").lower()
        _can_fmt = False
        try:
            from core.feed.source_plan import backend_supports_output_format
            _can_fmt = backend_supports_output_format(choice.backend, _fmt)
        except Exception as _of_exc:
            logger.debug(
                "[backend_router] capability registry unreadable -- "
                "treating %s as unable to produce %s: %s",
                choice.backend, _fmt, _of_exc)
        if not _can_fmt:
            logger.warning(
                "[backend_router] feed %s outputs %s, which backend %s "
                "cannot produce with the native rules -- flooring to "
                "native.  Original reason: %s",
                feed_config.get("id"), _fmt, choice.backend, choice.reason)
            return BackendChoice(
                backend="native",
                reason=(f"output_capability_floor(format={_fmt},"
                        f"was={choice.backend}:{choice.reason})"),
                failed_over=True,
            )

    # ── Control-file capability floor (Phase 4, 2026-08-23) ──────────
    # A feed that asks for a sidecar .ctl (template or DB format id) must
    # never land on a backend that cannot write one: spark_k8s
    # self-delivers from the Spark job, which has no control-file logic,
    # so the data arrived with NO READY signal while the run said
    # COMPLETED -- the recipient's watcher waits forever or ingests an
    # unverified file.  Declaration-driven like every other floor.
    if choice.backend != "native" and (
            feed_config.get("control_file_template")
            or feed_config.get("control_file_format_id")):
        _can_ctl = False
        try:
            from core.feed.source_plan import BACKEND_CAPABILITIES as _cf_caps
            _can_ctl = bool(_cf_caps.get(choice.backend, {})
                            .get("control_file", False))
        except Exception as _cf_exc:
            logger.debug(
                "[backend_router] capability registry unreadable -- "
                "treating %s as unable to write control files: %s",
                choice.backend, _cf_exc,
            )
        if not _can_ctl:
            logger.warning(
                "[backend_router] feed %s requires a control file but "
                "backend %s cannot write one (self-delivering job) -- "
                "flooring to native.  Original reason: %s",
                feed_config.get("id"), choice.backend, choice.reason,
            )
            return BackendChoice(
                backend="native",
                reason=f"control_file_floor(was={choice.backend}:{choice.reason})",
                failed_over=True,
            )

    # ── Variance-hold capability floor (2026-10-12, owner R2) ─────────
    # A feed whose row_count_action is 'hold' must be able to KEEP its file
    # when the count breaches -- a lane whose job delivers its own file
    # would have sent it before anything could hold it.  Declaration-driven.
    if (choice.backend != "native"
            and str(feed_config.get("row_count_action") or "").lower() == "hold"):
        try:
            from core.feed.source_plan import BACKEND_CAPABILITIES as _vh_caps
            _can_hold = bool(_vh_caps.get(choice.backend, {}).get("variance_hold", False))
        except Exception:
            _can_hold = False
        if not _can_hold:
            logger.warning(
                "[backend_router] feed %s declares row_count_action=hold but "
                "backend %s delivers inside its job and cannot hold a file -- "
                "flooring to native.  Original reason: %s",
                feed_config.get("id"), choice.backend, choice.reason)
            return BackendChoice(
                backend="native",
                reason=f"variance_hold_floor(was={choice.backend}:{choice.reason})",
                failed_over=True,
            )

    # Floor probe only runs for non-native choices → zero cost for the
    # common native path, one DB read pair otherwise (once per execution).
    # 2026-08-22: declaration-driven (was a hardcoded backend-name tuple
    # that a NEW backend — spark_k8s — would have silently bypassed).
    # UNKNOWN = UNSAFE: a backend that does not declare
    # ``iceberg_source: True`` never receives an iceberg-sourced feed.
    _can_iceberg = True
    if choice.backend != "native":
        try:
            from core.feed.source_plan import BACKEND_CAPABILITIES as _caps
            _can_iceberg = bool(
                _caps.get(choice.backend, {}).get("iceberg_source", False))
        except Exception as _ib_exc:
            logger.debug(
                "[backend_router] capability registry unreadable — treating "
                "%s as iceberg-blind: %s", choice.backend, _ib_exc,
            )
            _can_iceberg = False
    if not _can_iceberg and _feed_source_is_iceberg(feed_config):
        logger.warning(
            "[backend_router] feed %s references an iceberg-format table — "
            "flooring backend %s → native (Spark paths read Iceberg as "
            "plain parquet: snapshot/delete-blind).  Original reason: %s",
            feed_config.get("id"), choice.backend, choice.reason,
        )
        return BackendChoice(
            backend="native",
            reason=f"iceberg_source_floor(was={choice.backend}:{choice.reason})",
            failed_over=True,
        )
    # 2026-10-14 -- an S3 side runs on a detached backend only as a "tables"
    # side (core/feed/read_plan.py).  UNKNOWN = UNSAFE: a backend that does
    # not declare ``tables_source`` never receives one (before this, an S3
    # SQL side reached Spark as a JDBC read of a connection with no JDBC).
    if choice.backend != "native" and _feed_reads_s3_tables(feed_config):
        try:
            from core.feed.source_plan import BACKEND_CAPABILITIES as _caps_t
            _can_tables = bool(_caps_t.get(choice.backend, {}).get("tables_source", False))
        except Exception:                                   # noqa: BLE001
            _can_tables = False
        if not _can_tables:
            return BackendChoice(
                backend="native",
                reason=f"tables_source_floor(was={choice.backend}:{choice.reason})",
                failed_over=True,
            )
    return choice


def _feed_reads_s3_tables(feed_config: dict) -> bool:
    """True when the feed's primary or second connection is an S3 one (its
    SQL reads registered tables).  False on any resolution error -- the
    routing courtesy, like the other probes; the plan builder refuses an
    unplannable side as the guarantee."""
    try:
        from core import feed_engine as _fe
        dbm = getattr(_fe, "_db_manager", None)
        if dbm is None:
            return False
        for cid in (feed_config.get("connection_id"), feed_config.get("secondary_connection_id")):
            if not cid:
                continue
            raw = dbm.get_connection_raw(cid) or {}
            cfg = raw.get("config") or {}
            if (str(raw.get("connection_type") or "").lower() == "s3"
                    or cfg.get("bucket") or cfg.get("bucket_name")):
                return True
        return False
    except Exception:                                       # noqa: BLE001
        return False


def _pick_backend_decision(
    feed_config: dict,
    *,
    per_execution_override: Optional[str] = None,
    estimated_rows: Optional[int] = None,
    cfg=None,
    airflow_breaker_open: bool = False,
    spark_k8s_availability=None,
    delivery_suppressed: Optional[bool] = None,
) -> BackendChoice:
    """Resolve the backend for one execution.  Pure function — no
    side effects, no logging beyond the warning for cross-source +
    airflow-pinned conflict.

    Every "is lane X available?" this tree asks goes through
    :func:`lane_availability` (2026-10-07); a choice a PERSON made (a
    per-run override, a per-feed pin) is returned as asked, with its
    ``origin``, and :func:`pick_backend` applies the one availability
    rule to it.

    :param feed_config: row from feed_configs (dict-like)
    :param per_execution_override: ``'native'`` / ``'airflow'`` set by
        the admin on this specific rerun/execute call.  ``None`` means
        no per-execution override.
    :param estimated_rows: query row estimate when available (for the
        auto-router); ``None`` skips the size check.
    :param cfg: ``core.config.feed_generation`` accessor; injected for
        testability.  ``None`` lazy-loads it.
    :param airflow_breaker_open: pass the circuit-breaker state from
        the caller (feed_engine owns the breaker).
    :raises ExecutionHaltedError: when ``backend_override='halt'``.
    :returns: ``BackendChoice``.
    """
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg

    # 1. Per-execution override (admin clicked "rerun via X")
    if per_execution_override:
        choice = per_execution_override.lower()
        if choice not in VALID_PER_EXECUTION_OVERRIDES:
            raise ValueError(
                f"per_execution_override must be one of "
                f"{VALID_PER_EXECUTION_OVERRIDES}; got {per_execution_override!r}"
            )
        return BackendChoice(
            backend=choice,
            reason=f"per_execution_override={choice}",
            failed_over=False,
            origin=ORIGIN_PER_EXECUTION_OVERRIDE,
        )

    # 2. Global override (set by admin or auto-flipped by failover agent)
    global_override = (getattr(cfg, "backend_override", "auto") or "auto").lower()
    if global_override == "halt":
        raise ExecutionHaltedError(
            "feed_generation.backend_override='halt' — all feed executions "
            "are paused.  Flip the override to resume."
        )
    if global_override == "native_only":
        per_feed = (feed_config.get("execution_backend") or "auto").lower()
        return BackendChoice(
            backend="native",
            reason="global_override=native_only",
            failed_over=(per_feed == "airflow"),
        )
    def _lane(name: str) -> LaneAvailability:
        return lane_availability(
            name, feed_config, cfg=cfg,
            airflow_breaker_open=airflow_breaker_open,
            spark_k8s_availability=spark_k8s_availability,
            delivery_suppressed=delivery_suppressed)

    if global_override == "airflow_only":
        # If airflow is disabled at config level, we cannot honour this
        # override — fall back to native and surface as failed_over so
        # the admin notices.  (A deployment-level contradiction the
        # override's own contract resolves; an OPEN BREAKER under
        # airflow_only is a lane outage, and the override -- an operator's
        # fleet-wide intent -- then fails the run with the reason.)
        if _lane("airflow").reason_code == REASON_AIRFLOW_DISABLED:
            return BackendChoice(
                backend="native",
                reason="global_override=airflow_only_but_airflow_disabled",
                failed_over=True,
            )
        per_feed = (feed_config.get("execution_backend") or "auto").lower()
        return BackendChoice(
            backend="airflow",
            reason="global_override=airflow_only",
            failed_over=(per_feed == "native"),
            origin=ORIGIN_GLOBAL_OVERRIDE,
        )

    # 3. Per-feed manual setting
    per_feed = (feed_config.get("execution_backend") or "auto").lower()
    if per_feed == "native":
        return BackendChoice(
            backend="native",
            reason="per_feed=native",
            failed_over=False,
        )
    if per_feed in ("spark_k8s", "airflow"):
        # The pin is returned AS ASKED.  Whether its lane can take the run
        # -- and what happens when it cannot (K3: a pin FAILS with the
        # reason; it is never moved, save the operator's declared
        # airflow_failover_to_native exception) -- is pick_backend's ONE
        # availability decision.  This branch used to answer it itself for
        # airflow (breaker open -> native by default; airflow disabled ->
        # native), and the spark_k8s floor moved spark pins in silence.
        return BackendChoice(
            backend=per_feed,
            reason=f"per_feed={per_feed}",
            failed_over=False,
            origin=ORIGIN_PER_FEED_PIN,
        )

    # 4. Auto — three-tier size-based routing.
    #    [0, native_threshold)             → native (DuckDB on the pod)
    #    [native_threshold, airflow_threshold) → spark_connect (gRPC, in-VPC)
    #    [airflow_threshold, ∞)            → airflow (Spark on K8s, async DAG)
    #
    # Phase 131 deep-dive #13 (round 9) — added the middle tier.
    # Previously only two tiers (native / airflow); medium-sized feeds
    # either OOM'd on native or paid the DAG-dispatch overhead of
    # Airflow.  Spark Connect bridges the gap: reads S3 directly inside
    # the VPC (no pre-download to NFS), returns Arrow batches over gRPC,
    # response time comparable to native for the user.  Disabled by
    # default — set ``spark_connect.enabled=true`` to enable.
    def _as_int(value, default):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    native_threshold = _as_int(
        feed_config.get("size_threshold_rows")
        or getattr(cfg, "auto_route_threshold_rows", 500000),
        500000,
    )
    airflow_threshold = _as_int(
        getattr(cfg, "auto_route_airflow_threshold_rows", 10_000_000),
        10_000_000,
    )
    if airflow_threshold < native_threshold:
        # Defensive: invalid config — keep two-tier behaviour.
        airflow_threshold = native_threshold

    # Availability of each candidate: the ONE decision, never re-derived.
    spark_connect_enabled = _lane("spark_connect").available
    airflow_available = _lane("airflow").available

    if estimated_rows is None or estimated_rows <= native_threshold:
        return BackendChoice(
            backend="native",
            reason="auto_route_small" if estimated_rows is not None
                   else "auto_route_no_estimate",
            failed_over=False,
        )

    # Medium: prefer Spark Connect if enabled.
    if estimated_rows <= airflow_threshold and spark_connect_enabled:
        return BackendChoice(
            backend="spark_connect",
            reason=(
                f"auto_route_medium("
                f"rows={estimated_rows},"
                f"native_threshold={native_threshold},"
                f"airflow_threshold={airflow_threshold})"
            ),
            failed_over=False,
            origin=ORIGIN_SIZE_ROUTER,
        )

    # Large (or medium with Spark Connect disabled):
    # 2026-08-22 — spark_k8s is the PREFERRED large-feed backend when the
    # availability ladder says yes (operator directive: QueryStudio spins
    # its own Spark pods; Airflow is a peer, not a prerequisite).  When
    # the ladder refuses, the refusal reason is logged here AND carried
    # into the fallback BackendChoice.reason by the pick_backend floor,
    # so "why didn't my big feed use spark_k8s" is always answerable from
    # the execution record.
    _sk_av = _lane("spark_k8s")
    if _sk_av.available:
        return BackendChoice(
            backend="spark_k8s",
            reason=(
                f"auto_route_large_spark_k8s(rows={estimated_rows}>"
                f"threshold={native_threshold})"
            ),
            failed_over=False,
            origin=ORIGIN_SIZE_ROUTER,
        )
    _sk_refusal = _sk_av.describe()
    logger.info(
        "[backend_router] feed %s large tier: spark_k8s unavailable (%s) — "
        "trying airflow/spark_connect/native",
        feed_config.get("id"), _sk_refusal,
    )

    if airflow_available:
        return BackendChoice(
            backend="airflow",
            reason=(
                f"auto_route_large(rows={estimated_rows}>"
                f"threshold={native_threshold},"
                f"spark_k8s={_sk_refusal})"
            ),
            failed_over=False,
            origin=ORIGIN_SIZE_ROUTER,
        )

    # Airflow unavailable — try Spark Connect even for >airflow_threshold
    # as a degraded fallback (better than OOM-ing native).
    if spark_connect_enabled:
        return BackendChoice(
            backend="spark_connect",
            reason=(
                f"auto_route_large_airflow_unavailable_spark_connect_fallback("
                f"rows={estimated_rows},spark_k8s={_sk_refusal})"
            ),
            failed_over=True,
            origin=ORIGIN_SIZE_ROUTER,
        )

    # Last resort: native.  Reason string includes "airflow_unavailable"
    # for backwards-compat with existing telemetry / log monitors that
    # match on that substring — and the spark_k8s refusal, so "why did my
    # 140M feed run native" is answerable from the execution record alone.
    return BackendChoice(
        backend="native",
        reason=(
            f"auto_route_large_airflow_unavailable_no_spark_connect("
            f"rows={estimated_rows}>threshold={native_threshold},"
            f"airflow_enabled={getattr(cfg, 'airflow_enabled', False)},"
            f"breaker_open={airflow_breaker_open},"
            f"spark_connect_enabled={spark_connect_enabled},"
            f"spark_k8s={_sk_refusal})"
        ),
        failed_over=True,
    )


# ── The chosen lane turned out unavailable AT SUBMIT (2026-10-07, D3) ──────

def lane_failed_at_submit(choice: BackendChoice, exc, *,
                          cfg=None) -> BackendChoice:
    """A spark_k8s submit met a cluster that did not answer
    (``SparkK8sUnreachable``) or a ladder refusal at submit
    (``SparkK8sUnavailable``) -- AFTER routing said yes.  The SAME rule as
    routing (:func:`lane_unavailable`): an auto-routed run moves to native
    with the reason, a pinned run raises :class:`LaneRefused` with the
    reason code.  Plus the one condition only submit time has: a run that
    may already EXIST on the cluster (a create succeeded, or the failing
    request may have reached the server) is never moved at all -- a
    second engine could run it twice.  Raises ``LaneRefused`` for every
    run that must fail; ``exc`` of any other type is not this decision's
    and is re-raised."""
    from core.spark_k8s.availability import (REASON_UNREACHABLE,
                                             RUNG_UNAVAILABLE)
    from core.spark_k8s.errors import SparkK8sUnavailable, SparkK8sUnreachable
    if isinstance(exc, SparkK8sUnreachable):
        av = LaneAvailability(
            choice.backend, False, REASON_UNREACHABLE,
            f"spark cluster unreachable at submit: {exc.host} ({exc.cause})",
            rung=RUNG_UNAVAILABLE)
        if not exc.nothing_created:
            raise LaneRefused(choice, av, (
                f"{choice.backend} is unavailable [{REASON_UNREACHABLE}]: "
                f"{av.detail}.  The cluster stopped answering after this "
                f"run's Spark job was submitted, so the job may already exist "
                f"there; the run was NOT moved to another engine, which could "
                f"run it twice.  Whatever reached the cluster is deleted by "
                f"the spark_k8s reconciler once the cluster answers again -- "
                f"re-run the feed when it is back."))
    elif isinstance(exc, SparkK8sUnavailable):
        av = LaneAvailability(choice.backend, False, exc.reason_code,
                              (exc.detail or "")[:300],
                              rung=RUNG_UNAVAILABLE)
    else:
        raise exc
    return lane_unavailable(choice, av, cfg=cfg, fallback_order=("native",))
