"""WHERE A RUNNING FEED IS -- one record for every lane (2026-10-14).

The owner, watching a 40M-row run on the Spark pods for an hour: "we don't
know where it is ... we don't have anything on the UI to see what's actually
happening".  A native run broadcast its stage names; a Spark run said nothing
between submit and completion -- the only way to see it was ``kubectl exec``
into the driver and read Spark's REST API by hand.

The record, kept on the execution (``files_metadata.run_progress``, merged,
so a page refresh or another API pod sees it) and broadcast as the existing
``feed_progress`` event:

* ``phase``         -- what the run is doing in the job's own words
                       (read / certify / transform / write / render /
                       deliver / done), and when it entered it;
* ``tasks_done`` / ``tasks_total`` / ``tasks_active`` / ``tasks_failed``
                    -- Spark's own counters for the stages running now
                       (``statusTracker``), so "157 of 225" is the engine's
                       number, never an estimate of ours;
* ``stage``         -- what Spark calls the running stage;
* ``reported_at``   -- server time of the report.

Read through :func:`progress_view`, which adds ``percent``, an ``eta_seconds``
from the rate of the CURRENT phase (said as unknown when there is no rate
yet -- unknown is not zero), and ``stale`` when no report arrived for
``feed_generation.progress_stale_seconds``: a run that stopped reporting is
SAID, never shown as quietly running.

The job's own log lines travel with each report and are appended to the
execution's stored log (``files_metadata.log_lines``, the same list the
run-log dialog reads) and broadcast as ``feed_run_log`` -- so a Spark run is
tailed live in the SAME dialog as a native one.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional

#: files_metadata key of the record
PROGRESS_KEY = "run_progress"
#: files_metadata key of the stored log (the run-log dialog's list)
LOG_LINES_KEY = "log_lines"
#: How many job log lines an execution keeps (the newest win); the driver
#: pod's full log stays readable through the driver-log route.
MAX_STORED_LINES = 2000
#: A line longer than this is cut (a stack trace line can be huge).
MAX_LINE_CHARS = 2000

_INT_FIELDS = ("tasks_done", "tasks_total", "tasks_active", "tasks_failed",
               "stages_active", "rows_written", "executors_lost")
_FLOAT_FIELDS = ("elapsed_seconds", "phase_elapsed_seconds")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _int(v: Any) -> Optional[int]:
    try:
        return None if v is None else max(0, int(v))
    except (TypeError, ValueError):
        return None


def _float(v: Any) -> Optional[float]:
    try:
        return None if v is None else max(0.0, float(v))
    except (TypeError, ValueError):
        return None


def normalise_report(report: Mapping[str, Any], *, lane: str,
                     now: Optional[datetime] = None) -> Dict[str, Any]:
    """The stored shape of one report -- only declared fields, typed, the
    time the SERVER received it (a pod's clock is not trusted)."""
    out: Dict[str, Any] = {
        "lane": str(lane or ""),
        "phase": str(report.get("phase") or "")[:40],
        "stage": str(report.get("stage") or "")[:200],
        # Spark's own words for the last executor it removed (OOMKilled ...)
        "executor_loss_reason": str(report.get("executor_loss_reason") or "")[:300],
        "reported_at": (now or _now()).isoformat(),
    }
    for k in _INT_FIELDS:
        out[k] = _int(report.get(k))
    for k in _FLOAT_FIELDS:
        out[k] = _float(report.get(k))
    if out["tasks_total"] is not None and out["tasks_done"] is not None:
        out["tasks_done"] = min(out["tasks_done"], out["tasks_total"])
    return out


def clean_lines(lines: Iterable[Any]) -> List[str]:
    out = []
    for ln in lines or []:
        s = str(ln).rstrip("\r\n")
        if s:
            out.append(s[:MAX_LINE_CHARS])
    return out


def merged_metadata(files_metadata: Optional[Mapping[str, Any]],
                    progress: Mapping[str, Any],
                    lines: List[str]) -> Dict[str, Any]:
    """``files_metadata`` with the new record and the lines appended (the
    newest :data:`MAX_STORED_LINES` kept)."""
    fm = dict(files_metadata or {})
    progress = dict(progress)
    # WHEN THE COUNTERS LAST MOVED: a job that keeps reporting the same
    # phase / tasks / rows is STALLED, not progressing (still_progressing)
    prev = fm.get(PROGRESS_KEY) if isinstance(fm.get(PROGRESS_KEY), Mapping) else None
    if prev is not None and _signature(prev) == _signature(progress):
        progress["moved_at"] = prev.get("moved_at") or prev.get("reported_at")
    else:
        progress["moved_at"] = progress.get("reported_at")
    fm[PROGRESS_KEY] = progress
    if lines:
        stored = list(fm.get(LOG_LINES_KEY) or [])
        stored.extend(lines)
        fm[LOG_LINES_KEY] = stored[-MAX_STORED_LINES:]
    return fm


def _signature(rec: Mapping[str, Any]) -> tuple:
    return (rec.get("phase"), rec.get("tasks_done"), rec.get("tasks_total"),
            rec.get("rows_written"))


def _age(value: Any, now: datetime) -> Optional[float]:
    try:
        at = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    return max(0.0, (now - at).total_seconds())


def still_progressing(execution: Mapping[str, Any], *, stall_seconds: int,
                      stale_seconds: int, now: Optional[datetime] = None) -> tuple:
    """``(True/False, reason)`` -- is this run MOVING?  The question a job
    budget asks before it stops a run (2026-10-14: the 40M pod run, healthy
    and 37% through, was killed by a 2-hour budget).  Moving = a report
    within ``stale_seconds`` AND its counters changed within
    ``stall_seconds``.  A run that never reported is not known to move --
    the budget applies as before (unknown is not progress)."""
    fm = execution.get("files_metadata")
    rec = fm.get(PROGRESS_KEY) if isinstance(fm, Mapping) else None
    if not isinstance(rec, Mapping):
        return False, "the run reports no progress"
    now = now or _now()
    seen = _age(rec.get("reported_at"), now)
    moved = _age(rec.get("moved_at") or rec.get("reported_at"), now)
    if seen is None or seen > stale_seconds:
        return False, f"no progress report for {int(seen or 0)}s"
    if moved is None or moved > stall_seconds:
        return False, (f"reporting, but nothing moved for {int(moved or 0)}s "
                       f"(phase {rec.get('phase')}, {rec.get('tasks_done')}/{rec.get('tasks_total')})")
    return True, (f"moving: phase {rec.get('phase')}, {rec.get('tasks_done')}/"
                  f"{rec.get('tasks_total')} tasks, {rec.get('rows_written')} rows")


def budget_verdict(execution: Mapping[str, Any], *, age_seconds: float, budget_seconds: int,
                   ceiling_seconds: int, now: Optional[datetime] = None) -> tuple:
    """``(stop, reason)`` -- THE decision both Spark supervisors make when a
    run reaches its job budget (the engine's await loop and the reconciler):
    a budget stops a STUCK run, never a moving one.  Past the budget a run
    that is still moving (:func:`still_progressing`) keeps going up to the
    absolute ``ceiling_seconds``; one that stopped moving, or passed the
    ceiling, is stopped -- and the reason says which."""
    if budget_seconds <= 0 or age_seconds <= budget_seconds:
        return False, "within its budget"
    ceiling = max(int(ceiling_seconds or 0), int(budget_seconds))
    if ceiling_seconds and age_seconds > ceiling:
        return True, (f"ran {int(age_seconds)}s, past the {ceiling}s ceiling "
                      f"(spark_k8s.job_ceiling_seconds) even for a run that is moving")
    if not ceiling_seconds:
        return True, f"ran {int(age_seconds)}s, past its {budget_seconds}s budget"
    moving, why = still_progressing(execution, stall_seconds=stall_seconds(),
                                    stale_seconds=stale_after_seconds(), now=now)
    if moving:
        return False, f"past its {budget_seconds}s budget but {why}"
    return True, f"past its {budget_seconds}s budget and {why}"


def stall_seconds() -> int:
    try:
        from core.config import feed_generation as _fg
        return int(_fg.progress_stall_seconds)
    except Exception:                                        # noqa: BLE001
        return 1800


def progress_view(execution: Mapping[str, Any], *, stale_after_seconds: int,
                  now: Optional[datetime] = None) -> Optional[Dict[str, Any]]:
    """The record as the UI shows it, or None when the run never reported.

    ``percent`` and ``eta_seconds`` come from Spark's task counters of the
    CURRENT phase; with no counters (or none done yet) they are None --
    shown as "not known yet", never as 0."""
    fm = execution.get("files_metadata")
    rec = fm.get(PROGRESS_KEY) if isinstance(fm, Mapping) else None
    if not isinstance(rec, Mapping):
        return None
    view = dict(rec)
    now = now or _now()
    try:
        at = datetime.fromisoformat(str(rec.get("reported_at")))
        if at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        age = max(0.0, (now - at).total_seconds())
    except (TypeError, ValueError):
        age = None
    view["seconds_since_report"] = None if age is None else round(age)
    running = str(execution.get("status") or "").lower() in ("pending", "running")
    view["stale"] = bool(running and age is not None and age > stale_after_seconds)
    done, total = rec.get("tasks_done"), rec.get("tasks_total")
    view["percent"] = (round(100.0 * done / total, 1)
                       if isinstance(done, int) and isinstance(total, int) and total > 0
                       else None)
    pe = rec.get("phase_elapsed_seconds")
    view["eta_seconds"] = (round(pe * (total - done) / done)
                           if isinstance(done, int) and isinstance(total, int)
                           and done > 0 and total >= done and isinstance(pe, (int, float))
                           else None)
    return view


def stale_after_seconds() -> int:
    try:
        from core.config import feed_generation as _fg
        return int(_fg.progress_stale_seconds)
    except Exception:                                        # noqa: BLE001
        return 300


__all__ = ["PROGRESS_KEY", "LOG_LINES_KEY", "MAX_STORED_LINES", "normalise_report",
           "clean_lines", "merged_metadata", "progress_view", "stale_after_seconds",
           "still_progressing", "stall_seconds", "budget_verdict"]
