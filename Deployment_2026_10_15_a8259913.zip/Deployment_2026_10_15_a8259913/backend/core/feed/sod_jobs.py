"""The SOD run-now as a JOB (2026-10-11).

``POST /api/admin/feeds/sod/run-now`` (and the user twin) used to run
``SodTaskGenerator.run_for_date`` over EVERY active feed inside the request.
At the owner's scale -- thousands of feeds per pass, daily -- that is minutes
of one HTTP request, so above ``feed_generation.sod_run_now_sync_max_feeds``
feeds in scope (or with ``?background=true``) the route CLAIMS the one SOD
job slot, answers **202** with the job and a ``status_url``, and runs the
SAME ``run_for_date`` as a task on the API process that took it, writing
progress + heartbeat to the job record every ``PROGRESS_EVERY_SECONDS``.

The record lives in ``system_settings`` (``feed_sod.run_now.job.<job_id>``)
so a poller on ANY pod reads it; the claim is an insert-first row
(``feed_sod.run_now.claim``) -- one run-now at a time, a live job makes a
second POST a 409 naming it, and a job whose heartbeat is older than
``STALE_SECONDS`` belongs to a process that ended: reported ``failed`` with
``DEAD_OWNER_REASON`` and superseded by the next POST.  The same shape as the
feed-template apply job (core/feed/feed_template.py), whose state vocabulary
this module imports rather than re-declaring.  The CRON pass never comes
through here -- it runs in the scheduler's thread, unclaimed.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from core.feed.feed_template import (JOB_COMPLETED, JOB_FAILED, JOB_LIVE_STATES,
                                     JOB_QUEUED, JOB_RUNNING, job_is_stale)

logger = logging.getLogger(__name__)

__all__ = [
    "CLAIM_KEY", "JOB_KEY_PREFIX", "STALE_SECONDS", "PROGRESS_EVERY_SECONDS",
    "DEAD_OWNER_REASON", "JOB_COMPLETED", "JOB_FAILED", "JOB_RUNNING", "JOB_QUEUED",
    "new_job", "claim", "release", "write_job", "read_job", "live_job", "sync_max_feeds",
]

CLAIM_KEY = "feed_sod.run_now.claim"
JOB_KEY_PREFIX = "feed_sod.run_now.job."
#: a queued/running job whose heartbeat is older than this is a dead owner's
#: (the same bound the template apply uses, read through its predicate)
STALE_SECONDS = 120.0
PROGRESS_EVERY_SECONDS = 2.0
#: job records older than this are pruned when a new one is claimed
KEEP_DAYS = 7
DEAD_OWNER_REASON = (
    "the process running this SOD pass stopped (a pod restart or a worker exit) "
    "before it finished; the runs it had already created are runs like any other "
    "-- POST run-now again, which finds them already_existed")
UPDATED_BY = "sod_run_now"


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def sync_max_feeds() -> int:
    """``feed_generation.sod_run_now_sync_max_feeds`` through the config object."""
    try:
        from core.config import feed_generation as _fg
        return int(_fg.sod_run_now_sync_max_feeds)
    except Exception:                              # noqa: BLE001 -- declared default
        return 100


def new_job(job_id: str, *, total: int, by: Optional[str], owner: str,
            background: bool, scope: Dict[str, Any], business_date, now: datetime
            ) -> Dict[str, Any]:
    """The job record as first written: queued, nothing done."""
    return {"job_id": job_id, "state": JOB_QUEUED, "background": bool(background),
            "total": int(total), "done": 0, "by": by, "owner": owner,
            "scope": dict(scope),
            "business_date": (business_date.isoformat()
                              if hasattr(business_date, "isoformat") else business_date),
            "started_at": _iso(now), "heartbeat_at": _iso(now),
            "finished_at": None, "error": None, "result": None}


def write_job(db: Any, job: Dict[str, Any]) -> None:
    db.set_system_setting(JOB_KEY_PREFIX + str(job["job_id"]), dict(job),
                          updated_by=UPDATED_BY,
                          description="SOD run-now job record (core/feed/sod_jobs.py)")


def read_job(db: Any, job_id: str, *, now: Optional[datetime] = None
             ) -> Optional[Dict[str, Any]]:
    """What a poller is told; a live job with a stale heartbeat reads
    ``failed`` + ``stale: true`` with :data:`DEAD_OWNER_REASON`.  Pure on the
    row.  None when no such job."""
    raw = db.get_system_setting(JOB_KEY_PREFIX + str(job_id), None)
    if not isinstance(raw, dict) or not raw.get("job_id"):
        return None
    now = now or datetime.now(timezone.utc)
    view = dict(raw)
    if view.get("state") in JOB_LIVE_STATES and _stale(view, now):
        view["state"] = JOB_FAILED
        view["error"] = DEAD_OWNER_REASON
        view["stale"] = True
    return view


def _stale(job: Dict[str, Any], now: datetime) -> bool:
    hb = job.get("heartbeat_at") or job.get("started_at")
    if not hb:
        return True
    try:
        then = datetime.fromisoformat(str(hb))
    except ValueError:
        return True
    if then.tzinfo is None:
        then = then.replace(tzinfo=timezone.utc)
    return (now - then).total_seconds() > STALE_SECONDS


def live_job(db: Any, *, now: Optional[datetime] = None) -> Optional[Dict[str, Any]]:
    """The job the claim row names, if it is still in flight (not stale)."""
    claim_row = db.get_system_setting(CLAIM_KEY, None)
    if not isinstance(claim_row, dict) or not claim_row.get("job_id"):
        return None
    view = read_job(db, str(claim_row["job_id"]), now=now)
    if view is None:
        return None
    return view if view.get("state") in JOB_LIVE_STATES else None


def claim(db: Any, job: Dict[str, Any], *, now: Optional[datetime] = None) -> bool:
    """INSERT-FIRST: this process owns the SOD run-now slot, or a LIVE job
    does (False).  A claim held by a finished or stale job is taken over.
    A db double without sessions is always claimed (the claim is the
    product's rule, not the double's)."""
    now = now or datetime.now(timezone.utc)
    if not hasattr(db, "get_session"):
        return True
    from sqlalchemy.exc import IntegrityError
    from core.db.models import SystemSetting
    value = {"job_id": str(job["job_id"]), "claimed_at": _iso(now), "owner": job.get("owner")}
    for attempt in range(2):
        try:
            with db.get_session() as session:
                session.add(SystemSetting(key=CLAIM_KEY, value=value,
                                          description="SOD run-now: one pass at a time",
                                          updated_by=UPDATED_BY, updated_at=now))
                session.flush()
            _prune(db, now)
            return True
        except IntegrityError:
            pass
        if live_job(db, now=now) is not None:
            return False
        # held by a finished job, a stale owner, or an unreadable record:
        # take it over (the second attempt's insert is the arbiter)
        try:
            db.delete_system_setting(CLAIM_KEY)
        except Exception:                          # noqa: BLE001 -- retried below
            logger.debug("[sod_jobs] stale claim could not be deleted", exc_info=True)
    return live_job(db, now=now) is None and _claim_is_ours(db, job)


def _claim_is_ours(db: Any, job: Dict[str, Any]) -> bool:
    row = db.get_system_setting(CLAIM_KEY, None)
    return isinstance(row, dict) and row.get("job_id") == str(job["job_id"])


def release(db: Any, job_id: str) -> None:
    """Give the slot back when THIS job holds it (never another's)."""
    try:
        row = db.get_system_setting(CLAIM_KEY, None)
        if isinstance(row, dict) and row.get("job_id") == str(job_id):
            db.delete_system_setting(CLAIM_KEY)
    except Exception:                              # noqa: BLE001 -- the stale rule covers it
        logger.warning("[sod_jobs] claim for job %s could not be released; a stale "
                       "heartbeat lets the next run-now take it over", job_id)


def _prune(db: Any, now: datetime) -> None:
    """Drop job records older than KEEP_DAYS (best effort)."""
    try:
        cutoff = now - timedelta(days=KEEP_DAYS)
        for row in db.list_system_settings(prefix=JOB_KEY_PREFIX) or []:
            job = row.get("value") if isinstance(row, dict) else None
            stamp = (job or {}).get("finished_at") or (job or {}).get("started_at")
            try:
                when = datetime.fromisoformat(str(stamp))
            except (TypeError, ValueError):
                continue
            if when.tzinfo is None:
                when = when.replace(tzinfo=timezone.utc)
            if when < cutoff:
                db.delete_system_setting(row["key"])
    except Exception:                              # noqa: BLE001 -- housekeeping
        logger.debug("[sod_jobs] prune skipped", exc_info=True)


def finish(db: Any, job: Dict[str, Any], *, result: Optional[Dict[str, Any]] = None,
           error: Optional[str] = None, now: Optional[datetime] = None) -> None:
    """Write the terminal state and release the slot."""
    now = now or datetime.now(timezone.utc)
    job["finished_at"] = _iso(now)
    job["heartbeat_at"] = _iso(now)
    if error is not None:
        job["state"] = JOB_FAILED
        job["error"] = str(error)[:2000]
    else:
        job["state"] = JOB_COMPLETED
        job["result"] = result
        job["done"] = int(job.get("total") or 0)
    write_job(db, job)
    release(db, job["job_id"])
