"""The service-review surface (BRD FR-OPS-17) — 2026-09-03.

The monthly service review asks four questions the raw tables already
answer but nothing computed:

  1. success rate by feed group over the period;
  2. which feeds are TRENDING SLOWER (recent vs prior average duration);
  3. which dependency is late most often (dependency_not_met events by
     dependency name);
  4. how often humans skipped things (run skips + dependency skips).

Same honesty contract as core/feed/run_surface.py, and the same
section shape: each section degrades INDEPENDENTLY and an unreadable
section says so in ``unavailable`` — an empty section because a query
failed must never read as "nothing to report".  Read-only by
construction: every number is derived from rows something else writes.

Aggregates run as SQL/sessions directly over the models (the accepted
pattern for cross-feed aggregation — feed_engine, reconciliation and
several api routers do the same) because the DAO exposes only per-feed
listings and an N-per-feed sweep would not survive a real estate.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from core.feed.run_surface import SurfaceSection, _section

logger = logging.getLogger(__name__)

#: trending-slower thresholds: at least this many completed executions in
#: EACH half, and recent/prior average duration ratio at or above this.
MIN_RUNS_PER_HALF = 3
SLOWER_RATIO = 1.25


def _group_names(db: Any) -> dict:
    out = {}
    try:
        for g in db.list_feed_groups() or []:
            out[int(g["id"])] = g.get("display_label") or g.get("name")
    except Exception as exc:
        logger.warning("[service_review] feed group names unreadable: %s",
                       exc)
    return out


def success_rate_by_group(db: Any, *, since: date) -> SurfaceSection:
    """Q4 of FR-OPS-17 — run outcomes per feed group over the period."""
    def _fn():
        from sqlalchemy import func
        from core.db.models import FeedConfig, FeedRun
        names = _group_names(db)
        with db.get_session(read_only=True) as session:
            rows = (session.query(
                        FeedConfig.feed_group_id,
                        FeedRun.status,
                        func.count(FeedRun.id))
                    .join(FeedConfig,
                          FeedRun.feed_config_id == FeedConfig.id)
                    .filter(FeedRun.business_date >= since)
                    .group_by(FeedConfig.feed_group_id, FeedRun.status)
                    .all())
        agg: dict = {}
        for gid, status, n in rows:
            key = int(gid) if gid is not None else None
            bucket = agg.setdefault(key, {"total": 0, "by_status": {}})
            bucket["total"] += int(n)
            bucket["by_status"][str(status)] = \
                bucket["by_status"].get(str(status), 0) + int(n)
        out = []
        for gid, bucket in sorted(agg.items(),
                                  key=lambda kv: (kv[0] is None, kv[0])):
            completed = bucket["by_status"].get("completed", 0)
            terminal = sum(v for k, v in bucket["by_status"].items()
                           if k in ("completed", "failed", "cancelled",
                                    "skipped"))
            out.append({
                "feed_group_id": gid,
                "feed_group": (names.get(gid)
                               if gid is not None else "(ungrouped)"),
                "runs": bucket["total"],
                "by_status": bucket["by_status"],
                # Rate over TERMINAL runs only — a period ending with 40
                # pending rows must not read as a 60% success rate.
                "success_rate": (round(completed / terminal, 4)
                                 if terminal else None),
            })
        return out
    return _section("success_rate_by_group", _fn)


def trending_slower(db: Any, *, since: date,
                    now: Optional[datetime] = None) -> SurfaceSection:
    """Feeds whose recent average duration outgrew their prior one.

    The window [since, now] is split at its midpoint; a feed appears
    when both halves carry at least MIN_RUNS_PER_HALF completed
    executions and recent/prior >= SLOWER_RATIO.  An empty list
    honestly means "nothing is trending slower under these thresholds".
    """
    def _fn():
        from core.db.models import FeedConfig, FeedExecution
        ts_now = now or datetime.now(timezone.utc)
        start = datetime(since.year, since.month, since.day,
                         tzinfo=timezone.utc)
        mid = start + (ts_now - start) / 2
        # The DateTime columns are timezone-NAIVE (UTC by convention) on
        # both sqlite and postgres — filter with a naive UTC bound so the
        # comparison is value-vs-value, not naive-vs-aware.
        start_naive = start.replace(tzinfo=None)
        with db.get_session(read_only=True) as session:
            rows = (session.query(
                        FeedExecution.feed_config_id,
                        FeedExecution.started_at,
                        FeedExecution.duration_seconds,
                        FeedExecution.completed_at)
                    .filter(FeedExecution.status == "completed",
                            FeedExecution.started_at >= start_naive)
                    .all())
            name_rows = session.query(FeedConfig.id, FeedConfig.name).all()
        names = {int(i): n for i, n in name_rows}
        halves: dict = {}
        for fid, started, dur, completed in rows:
            if started is None:
                continue
            if dur is None:
                if completed is None:
                    continue
                dur = (completed - started).total_seconds()
            if dur is None or dur < 0:
                continue
            st = started if started.tzinfo else \
                started.replace(tzinfo=timezone.utc)
            half = "recent" if st >= mid else "prior"
            halves.setdefault(int(fid), {"recent": [], "prior": []})[
                half].append(float(dur))
        out = []
        for fid, h in halves.items():
            if (len(h["recent"]) < MIN_RUNS_PER_HALF
                    or len(h["prior"]) < MIN_RUNS_PER_HALF):
                continue
            avg_r = sum(h["recent"]) / len(h["recent"])
            avg_p = sum(h["prior"]) / len(h["prior"])
            if avg_p <= 0:
                continue
            ratio = avg_r / avg_p
            if ratio >= SLOWER_RATIO:
                out.append({
                    "feed_config_id": fid,
                    "feed_name": names.get(fid),
                    "avg_duration_recent_s": round(avg_r, 2),
                    "avg_duration_prior_s": round(avg_p, 2),
                    "ratio": round(ratio, 3),
                    "runs_recent": len(h["recent"]),
                    "runs_prior": len(h["prior"]),
                })
        out.sort(key=lambda r: r["ratio"], reverse=True)
        return out
    return _section("trending_slower", _fn)


def dependency_late_most_often(db: Any, *, since: date) -> SurfaceSection:
    """dependency_not_met events grouped by dependency name — who to
    call about chronic lateness, with evidence."""
    def _fn():
        from sqlalchemy import func
        from core.db.models import RunEvent
        with db.get_session(read_only=True) as session:
            rows = (session.query(
                        RunEvent.subject,
                        func.count(RunEvent.id),
                        func.count(func.distinct(
                            RunEvent.feed_config_id)),
                        func.max(RunEvent.created_at))
                    .filter(RunEvent.event_type == "dependency_not_met",
                            RunEvent.business_date >= since)
                    .group_by(RunEvent.subject)
                    .all())
        out = [{
            "dependency": subj,
            "not_met_events": int(n),
            "feeds_affected": int(feeds),
            "last_seen": (last.isoformat()
                          if hasattr(last, "isoformat") else last),
        } for subj, n, feeds, last in rows]
        out.sort(key=lambda r: r["not_met_events"], reverse=True)
        return out
    return _section("dependency_late_most_often", _fn)


def skip_counts(db: Any, *, since: date) -> SurfaceSection:
    """Human overrides per feed: run skips + dependency skips.  A feed
    that only ships because someone skips its gate every week is a
    finding a service review exists to surface."""
    def _fn():
        from sqlalchemy import func
        from core.db.models import FeedConfig, RunEvent
        with db.get_session(read_only=True) as session:
            rows = (session.query(
                        RunEvent.feed_config_id,
                        RunEvent.event_type,
                        func.count(RunEvent.id))
                    .filter(RunEvent.event_type.in_(
                                ("run_skipped", "dependency_skipped")),
                            RunEvent.business_date >= since)
                    .group_by(RunEvent.feed_config_id,
                              RunEvent.event_type)
                    .all())
            name_rows = session.query(FeedConfig.id, FeedConfig.name).all()
        names = {int(i): n for i, n in name_rows}
        agg: dict = {}
        for fid, etype, n in rows:
            bucket = agg.setdefault(int(fid), {"run_skipped": 0,
                                               "dependency_skipped": 0})
            bucket[str(etype)] = bucket.get(str(etype), 0) + int(n)
        out = [{
            "feed_config_id": fid,
            "feed_name": names.get(fid),
            "run_skips": bucket.get("run_skipped", 0),
            "dependency_skips": bucket.get("dependency_skipped", 0),
            "total": (bucket.get("run_skipped", 0)
                      + bucket.get("dependency_skipped", 0)),
        } for fid, bucket in agg.items()]
        out.sort(key=lambda r: r["total"], reverse=True)
        return out
    return _section("skips", _fn)


def build_review(db: Any, *, days: int = 28,
                 now: Optional[datetime] = None) -> dict:
    """The whole review.  Sections degrade independently; the response
    NAMES the unavailable ones (run_surface convention)."""
    ts_now = now or datetime.now(timezone.utc)
    since = (ts_now - timedelta(days=int(days))).date()
    sections = [
        success_rate_by_group(db, since=since),
        trending_slower(db, since=since, now=ts_now),
        dependency_late_most_often(db, since=since),
        skip_counts(db, since=since),
    ]
    return {
        "period_days": int(days),
        "since": since.isoformat(),
        "generated_at": ts_now.isoformat(),
        "sections": {s.name: s.to_dict() for s in sections},
        "unavailable_sections": [s.name for s in sections if s.unavailable],
    }
