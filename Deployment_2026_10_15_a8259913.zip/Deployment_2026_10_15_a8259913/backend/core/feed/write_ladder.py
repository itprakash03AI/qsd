"""The write ladder — which mechanism WRITES a SQL-connector feed's rows.

2026-08-22, design_starburst_140m §4.2.  Three rungs:

  rung 1  ``engine_write``   the SOURCE ENGINE writes parquet parts to
                             S3 (Trino/Starburst CTAS with
                             external_location).  Zero rows transit a
                             QueryStudio process; 140M ≈ minutes.
  rung 2  ``spark``          distributed pull (spark_k8s / airflow).
                             Chosen by the BACKEND router, not here —
                             this module only ever runs inside the
                             NATIVE backend.
  rung 3  ``native_stream``  connector streaming through the pod,
                             part-rotated.  The floor: always works.

Declaration mechanism (the repo's own registry pattern —
``BACKEND_CAPABILITIES``, ``core/file_formats/``, connectors
``_REGISTRY``): a connector DECLARES what it can do by overriding
``SqlConnector.write_capabilities()``.  The base class declares
NOTHING, so UNKNOWN = UNSAFE: a connector that never heard of rung 1
can never be routed there, and a probe that CRASHES counts as "declared
nothing" (with the crash recorded in the decision's reason — a broken
probe must not brick every feed on that connection, but it must not
pass unseen either).

Every decision is auditable: ``RungDecision`` carries the rung, the
reason, and what was (or wasn't) declared; the feed engine stamps it
into the execution record's ``files_metadata.write_ladder`` and logs
ONE greppable ``[write-ladder]`` line — including for the default
choice, because a system that only logs what it DID and never what it
DECLINED is the reason the 08-21 incident took a day to see.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

RUNG_ENGINE_WRITE = "engine_write"     # rung 1
RUNG_SPARK = "spark"                   # rung 2 (backend router's territory)
RUNG_NATIVE_STREAM = "native_stream"   # rung 3 (the floor)

#: values a per-feed override (backend_config.write_rung) may take.
VALID_RUNG_OVERRIDES = (RUNG_ENGINE_WRITE, RUNG_NATIVE_STREAM)


@dataclass(frozen=True)
class RungDecision:
    """Which rung, and WHY — the auditable routing record."""
    rung: str
    reason: str
    capability: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"rung": self.rung, "reason": self.reason,
                "capability": dict(self.capability)}


def connector_write_capabilities(connector) -> Dict[str, Any]:
    """What this connector DECLARES about writing.  Missing method or a
    crashing probe both mean "declared nothing" — UNKNOWN = UNSAFE —
    but a crash is surfaced in the returned dict so the decision's
    reason names it instead of silently reading as 'unsupported'."""
    probe = getattr(connector, "write_capabilities", None)
    if probe is None:
        return {}
    try:
        caps = probe()
    except Exception as exc:
        logger.error(
            "[write-ladder] write_capabilities probe raised on %s — treating "
            "as DECLARED NOTHING (a broken probe must not brick the feed, "
            "and must not pass unseen): %s",
            type(connector).__name__, exc, exc_info=True,
        )
        return {"_probe_error": f"{type(exc).__name__}: {exc}"}
    return dict(caps) if isinstance(caps, dict) else {}


def select_write_rung(
    connector,
    feed_config: Optional[dict] = None,
    *,
    cfg=None,
) -> RungDecision:
    """Pick the highest rung the source supports, auditable.

    Order of authority:
      1. per-feed pin  ``backend_config.write_rung``  (an operator's
         explicit escape hatch — e.g. force ``native_stream`` while the
         scratch schema is being fixed).  An engine_write pin on a
         connection that has NOT declared the capability is refused
         LOUDLY: pinning cannot conjure a scratch schema into existence,
         and silently degrading a pin is how "pinned but ignored" knobs
         are born.
      2. global kill switch  ``feed_generation.engine_write_enabled``.
      3. the connector's declaration (UNKNOWN = UNSAFE → rung 3).
    """
    feed_config = feed_config if isinstance(feed_config, dict) else {}
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg

    caps = connector_write_capabilities(connector)
    eng = caps.get(RUNG_ENGINE_WRITE)
    declared = isinstance(eng, dict) and bool(eng)

    bc = feed_config.get("backend_config") or {}
    pin = str(bc.get("write_rung") or "").strip().lower() if isinstance(bc, dict) else ""
    if pin:
        if pin not in VALID_RUNG_OVERRIDES:
            raise ValueError(
                f"backend_config.write_rung must be one of "
                f"{VALID_RUNG_OVERRIDES}; got {pin!r}")
        if pin == RUNG_NATIVE_STREAM:
            decision = RungDecision(RUNG_NATIVE_STREAM,
                                    "per_feed_pin=native_stream", caps)
            _log(decision, feed_config)
            return decision
        # pin == engine_write
        if not declared:
            raise ValueError(
                f"Feed {feed_config.get('id')} pins write_rung=engine_write "
                f"but the connection has NOT declared the capability "
                f"(missing unload_scratch_catalog / unload_scratch_schema / "
                f"unload_s3_location on the connection config"
                + (f"; capability probe error: {caps.get('_probe_error')}"
                   if caps.get('_probe_error') else "")
                + "). A pin cannot conjure a scratch schema — configure the "
                  "connection, or remove the pin.")
        decision = RungDecision(RUNG_ENGINE_WRITE,
                                "per_feed_pin=engine_write", caps)
        _log(decision, feed_config)
        return decision

    enabled = bool(getattr(cfg, "engine_write_enabled", True))
    if declared and enabled:
        decision = RungDecision(
            RUNG_ENGINE_WRITE,
            f"engine_write_declared({','.join(sorted(k for k in eng if not k.startswith('_')))})",
            caps)
    elif declared and not enabled:
        decision = RungDecision(
            RUNG_NATIVE_STREAM,
            "engine_write_declared_but_globally_disabled"
            "(feed_generation.engine_write_enabled=false)", caps)
    else:
        why = caps.get("_probe_error")
        decision = RungDecision(
            RUNG_NATIVE_STREAM,
            (f"engine_write_probe_error({why})" if why
             else "engine_write_not_declared"),
            caps)
    _log(decision, feed_config)
    return decision


def _log(decision: RungDecision, feed_config: dict) -> None:
    # Unconditional: refusals/declines are logged with the same weight as
    # selections (the 08-21 lesson — the system must log what it DECLINED).
    logger.info(
        "[write-ladder] feed=%s rung=%s reason=%s",
        feed_config.get("id"), decision.rung, decision.reason,
    )


__all__ = [
    "RUNG_ENGINE_WRITE", "RUNG_SPARK", "RUNG_NATIVE_STREAM",
    "VALID_RUNG_OVERRIDES", "RungDecision",
    "connector_write_capabilities", "select_write_rung",
]
