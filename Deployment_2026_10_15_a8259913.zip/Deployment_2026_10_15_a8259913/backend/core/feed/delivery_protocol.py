"""THE delivery protocol of a feed file -- one copy, every lane that sends.

docs/FEED_LANE_CONTRACT_2026_10_07.html, decision K5 (inventory C1-C3).

The native engine sends a feed's file from the API/worker pod; the Spark
job (``spark/jobs/generic_feed.py``) sends it from its driver when it
delivers itself.  Until 2026-10-07 the job had its own protocol:

* SFTP: a direct ``put`` under the FINAL name, no rename, no size check --
  a counterparty polling its inbox could ingest a half-written file, and a
  dropped transfer left the fragment behind under the expected name;
* S3: a part DIRECTORY ``<prefix>/<execution id>/part-*`` instead of one
  object named by the feed's template;
* local: ``/tmp/feed_output`` with no allowed-roots check.

The protocol is decided HERE, and both lanes run it.  The job imports
``spark/jobs/qs_delivery_protocol.py``, a BYTE-IDENTICAL copy of this file
(guard: ``tests/test_lane_mirrors_2026_10_07.py``).  The TRANSPORT stays
each lane's own -- paramiko on both, boto3 natively and Hadoop's S3A
filesystem in the job -- because those are engines, not decisions.

What is decided here:

* :func:`sftp_publish` -- upload to ``<name>.part``, rename into place
  (``posix_rename``, else remove-then-rename), remove the partial on any
  failure, then stat the remote file over the SAME connection and compare
  its size; a known size that disagrees FAILS the delivery, a stat that
  cannot run is recorded as ``absent`` with the reason.
* :func:`sftp_remote_path` -- the ``remote_dir`` rules (no traversal, not
  empty).
* :func:`s3_object_key` -- ONE object, ``<prefix>/<filename>``.
* :func:`verify_size` -- the one size comparison every transport uses.
* :func:`resolve_local_destination` -- the allowed-roots rule for a local
  destination (relative paths resolve under the output dir; anything
  outside the roots is refused, naming the three ways out).
* :func:`check_filename` -- a delivered filename has no path components.
* :func:`receipt` -- the shape every transport reports, which the
  certificate's destination evidence reads (``core/feed/delivery_verdict``).
* :func:`publishing` / :func:`close_publishing` -- THE PUBLISH GATE
  (2026-10-14).  Every final step that makes a file visible to the
  counterparty (the SFTP rename, the local ``os.replace``, the S3 object
  put, the Oracle commit) runs inside ``publishing(...)``.  A process that is
  shutting down closes the gate: a publish not yet started is REFUSED
  (:class:`PublishRefused`), one already inside is waited for.  Only then may
  the process hand its unfinished runs back to the queue -- without the gate a
  run handed back while its publish was still completing would be delivered
  TWICE.  A process that never closes it (the Spark job) is unaffected.

Standard library only.
"""
from __future__ import annotations

import contextlib
import os
import threading
import time
from typing import Any, Dict, Iterator, List, Optional, Sequence

#: The pair the mirror guard byte-compares.
MIRROR_PATHS = (
    "backend/core/feed/delivery_protocol.py",
    "spark/jobs/qs_delivery_protocol.py",
)

VERIFIED = "verified"
ABSENT = "absent"


class PublishRefused(RuntimeError):
    """The publish gate is closed: this process is shutting down, so nothing
    more is made visible to a counterparty (the run is handed back)."""


_GATE_LOCK = threading.Lock()
_GATE = {"open": True, "reason": "", "active": 0}


@contextlib.contextmanager
def publishing(what: str) -> Iterator[None]:
    """Wrap the ONE step that makes ``what`` visible to the counterparty.
    Refused when the gate is closed; counted while inside."""
    with _GATE_LOCK:
        if not _GATE["open"]:
            raise PublishRefused(f"{what} was not published: {_GATE['reason']}")
        _GATE["active"] += 1
    try:
        yield
    finally:
        with _GATE_LOCK:
            _GATE["active"] -= 1


def close_publishing(reason: str, wait_seconds: float = 5.0) -> int:
    """Close the gate and wait up to ``wait_seconds`` for publishes already
    inside it.  Returns how many are STILL inside (0 = nothing can be
    published by this process any more)."""
    with _GATE_LOCK:
        _GATE["open"] = False
        _GATE["reason"] = str(reason or "this process is shutting down")
    deadline = time.monotonic() + max(0.0, float(wait_seconds))
    while True:
        with _GATE_LOCK:
            active = int(_GATE["active"])
        if active == 0 or time.monotonic() >= deadline:
            return active
        time.sleep(0.05)


def reopen_publishing() -> None:
    """TEST SEAM: open the gate again between tests.  No production caller
    by design -- a process that closed its gate is exiting (hand_back_on_exit
    in core/feed/run_lifecycle.py) and must never publish again."""
    with _GATE_LOCK:
        _GATE["open"] = True
        _GATE["reason"] = ""


def receipt(uri: str, *, verification: str, detail: str = "",
            written_rows: Optional[int] = None,
            physical_rows: Optional[int] = None,
            delivered_rows: Optional[int] = None,
            dropped_rows: Optional[int] = None) -> Dict[str, Any]:
    """What a transport says it did -- the same keys on every lane."""
    out: Dict[str, Any] = {"uri": uri, "verification": verification,
                           "verification_detail": detail}
    for key, val in (("written_rows", written_rows),
                     ("physical_rows", physical_rows),
                     ("delivered_rows", delivered_rows),
                     ("dropped_rows", dropped_rows)):
        if isinstance(val, int) and not isinstance(val, bool):
            out[key] = int(val)
    return out


def verify_size(local_size: Optional[int], remote_size: Optional[int],
                where: str) -> None:
    """A size that is KNOWN on both sides and disagrees is a failed
    delivery.  (An unknown size is the caller's to record as ``absent``.)"""
    if isinstance(local_size, int) and isinstance(remote_size, int) \
            and local_size != remote_size:
        raise RuntimeError(
            f"delivery verification failed: {where} is {remote_size} "
            f"bytes, the local file is {local_size} bytes")


def check_filename(filename: Any) -> str:
    if not isinstance(filename, str) or not filename:
        raise ValueError("delivered filename must be a non-empty string")
    if "\x00" in filename or "/" in filename or "\\" in filename \
            or ".." in filename:
        raise ValueError(
            f"delivered filename {filename!r} contains illegal path "
            f"components (.., /, \\, NUL); refused")
    return filename


# ── SFTP ───────────────────────────────────────────────────────────────

def sftp_remote_path(remote_dir: Any, filename: str) -> str:
    if ".." in str(remote_dir):
        raise ValueError(f"SFTP remote_dir contains path traversal: {remote_dir}")
    if not isinstance(remote_dir, str) or not remote_dir.strip():
        raise ValueError(
            f"SFTP remote_dir must be a non-empty string, got {remote_dir!r}")
    return f"{remote_dir.rstrip('/')}/{check_filename(filename)}"


def sftp_publish(sftp: Any, remote_dir: Any, filename: str, local_path: str,
                 *, log: Any = None) -> Dict[str, Any]:
    """Send ``local_path`` as ``<remote_dir>/<filename>`` ATOMICALLY and
    verify it.  Returns ``{"remote_path", "verification", "detail"}``.

    ``.part`` + rename: the final name either does not exist or is the
    COMPLETE file -- a consumer polling the directory can never ingest a
    fragment, and a dropped transfer leaves nothing under the real name.
    """
    remote_path = sftp_remote_path(remote_dir, filename)
    remote_tmp = f"{remote_path}.part"
    try:
        sftp.put(local_path, remote_tmp)
        with publishing(f"sftp {remote_path}"):
            try:
                # posix-rename (an SSH extension) replaces an existing target
                # atomically.
                sftp.posix_rename(remote_tmp, remote_path)
            except (OSError, IOError, AttributeError):
                # A server without it: classic rename refuses an existing
                # target, so remove the previous delivery first (the window
                # is one rename, not the whole transfer).
                try:
                    sftp.remove(remote_path)
                except (OSError, IOError):
                    pass
                sftp.rename(remote_tmp, remote_path)
    except BaseException:
        try:
            sftp.remove(remote_tmp)
        except (OSError, IOError) as rm_exc:
            if log is not None:
                log.warning("could not remove partial SFTP upload %s: %s",
                            remote_tmp, rm_exc)
        raise
    # In-band verification, over the SAME connection that uploaded it.
    remote_size, err = None, None
    try:
        size = getattr(sftp.stat(remote_path), "st_size", None)
        if isinstance(size, int):
            remote_size = size
    except (OSError, IOError, AttributeError) as st_exc:
        err = f"stat failed: {st_exc}"
    if remote_size is None:
        return {"remote_path": remote_path, "verification": ABSENT,
                "detail": err or "remote stat returned no usable size"}
    try:
        local_size = os.path.getsize(local_path)
    except OSError:
        local_size = None
    verify_size(local_size, remote_size, f"SFTP {remote_path}")
    return {"remote_path": remote_path,
            "verification": VERIFIED if local_size is not None else ABSENT,
            "detail": f"stat size={remote_size} (same connection as upload)"}


def sftp_publish_parts(sftp: Any, remote_dir: Any, filename: str, parts: Any,
                       *, log: Any = None, chunk_bytes: int = 8 * 1024 * 1024) -> Dict[str, Any]:
    """Send ONE file built from ordered PARTS (2026-10-13: a large feed is
    rendered in parallel, each Spark executor its own part) with THE
    protocol of :func:`sftp_publish`: ``.part``, rename into place, remote
    size check over the same connection.

    ``parts`` yields LOCAL file paths in order; each is appended to the one
    remote ``.part`` file and may be deleted by the caller's iterator once
    the next is asked for -- a driver holds one part on disk, never the
    file.  Returns ``{"remote_path", "verification", "detail", "bytes",
    "lines", "sha256", "parts"}``: the byte count, the newline count and the
    SHA-256 of exactly what was sent (an independent recount)."""
    import hashlib
    remote_path = sftp_remote_path(remote_dir, filename)
    remote_tmp = f"{remote_path}.part"
    digest, sent, lines, count = hashlib.sha256(), 0, 0, 0
    try:
        with sftp.open(remote_tmp, "wb") as out:
            try:
                out.set_pipelined(True)
            except AttributeError:
                pass
            for local in parts:
                count += 1
                with open(local, "rb") as fh:
                    while True:
                        chunk = fh.read(chunk_bytes)
                        if not chunk:
                            break
                        out.write(chunk)
                        digest.update(chunk)
                        sent += len(chunk)
                        lines += chunk.count(b"\n")
        with publishing(f"sftp {remote_path}"):
            try:
                sftp.posix_rename(remote_tmp, remote_path)
            except (OSError, IOError, AttributeError):
                try:
                    sftp.remove(remote_path)
                except (OSError, IOError):
                    pass
                sftp.rename(remote_tmp, remote_path)
    except BaseException:
        try:
            sftp.remove(remote_tmp)
        except (OSError, IOError) as rm_exc:
            if log is not None:
                log.warning("could not remove partial SFTP upload %s: %s", remote_tmp, rm_exc)
        raise
    remote_size, err = None, None
    try:
        size = getattr(sftp.stat(remote_path), "st_size", None)
        if isinstance(size, int):
            remote_size = size
    except (OSError, IOError, AttributeError) as st_exc:
        err = f"stat failed: {st_exc}"
    out_rec = {"remote_path": remote_path, "bytes": sent, "lines": lines,
               "sha256": digest.hexdigest(), "parts": count}
    if remote_size is None:
        return {**out_rec, "verification": ABSENT,
                "detail": err or "remote stat returned no usable size"}
    verify_size(sent, remote_size, f"SFTP {remote_path}")
    return {**out_rec, "verification": VERIFIED,
            "detail": f"stat size={remote_size} (same connection as upload; {count} parts)"}


# ── S3 ─────────────────────────────────────────────────────────────────

def s3_object_key(prefix: Any, filename: str) -> str:
    """ONE object per delivered file, named by the feed's template."""
    p = str(prefix or "").strip().strip("/")
    name = check_filename(filename)
    return f"{p}/{name}" if p else name


# ── local ──────────────────────────────────────────────────────────────

def allowed_roots(output_dir: str, extra_roots: Sequence[Any] = ()) -> List[str]:
    """THE allowed roots of a local delivery, normalised: ``output_dir`` plus
    every configured extra root that is an ABSOLUTE path on THIS machine
    (2026-10-12).  A root that is not -- ``C:/DEV/...`` on a Linux pod -- used
    to resolve under the process's working directory (``/app/C:/DEV/...``)
    and silently became an allowed folder nobody configured; it is ignored
    now, and the refusal says so.  Both checks below read this one list."""
    out = [os.path.realpath(os.path.abspath(output_dir))]
    for r in (extra_roots or ()):
        r = str(r or "")
        if r and os.path.isabs(r):
            out.append(os.path.realpath(r))
    return out


def ignored_roots(extra_roots: Sequence[Any] = ()) -> List[str]:
    """The configured extra roots :func:`allowed_roots` ignores (not absolute here)."""
    return [str(r) for r in (extra_roots or ()) if r and not os.path.isabs(str(r))]


def resolve_local_destination(raw_dir: Any, output_dir: str,
                              extra_roots: Sequence[Any] = ()) -> str:
    """The normalised directory a local delivery may write to, or a
    ValueError naming the fix.  Relative paths resolve under
    ``output_dir`` (never the process's CWD); the allowed roots are
    ``output_dir`` plus ``extra_roots``
    (``feed_generation.local_destination_allowed_roots``)."""
    if not isinstance(raw_dir, str) or not raw_dir:
        raise ValueError("Local destination: 'path' must be a non-empty string")
    roots_norm = allowed_roots(output_dir, extra_roots)
    resolved = raw_dir if os.path.isabs(raw_dir) \
        else os.path.join(output_dir, raw_dir)
    dest = os.path.realpath(os.path.abspath(resolved))
    if not any(dest == r or dest.startswith(r + os.sep) for r in roots_norm):
        raise ValueError(
            f"Local destination: path {raw_dir!r} resolves to {dest!r}, "
            f"which is outside the allowed roots ({roots_norm})"
            + (f" -- configured but IGNORED, not an absolute path here: {ignored_roots(extra_roots)}"
               if ignored_roots(extra_roots) else "")
            + ".  Either: "
            f"(a) add {dest!r} to feed_generation.local_destination_allowed_"
            f"roots in system_settings, (b) re-enter the destination path "
            f"relative to the configured output_dir ({output_dir!r}), or "
            f"(c) point output_dir at the directory you want to write to.")
    return dest


def local_target(dest_dir: str, filename: str, output_dir: str,
                 extra_roots: Sequence[Any] = ()) -> str:
    """The final path inside an allowed destination directory -- checked
    again after the join (the last line of defence for an exotic name)."""
    target = os.path.realpath(os.path.abspath(
        os.path.join(dest_dir, check_filename(filename))))
    roots_norm = allowed_roots(output_dir, extra_roots)
    if not any(target == r or target.startswith(r + os.sep)
               for r in roots_norm):
        raise ValueError(
            f"Local destination: resolved path {target!r} escaped allowed "
            f"roots -- refusing write.")
    return target


def publish_local(src: str, target: str) -> Dict[str, Any]:
    """Copy ``src`` to ``target`` through a scratch file in a
    ``.qs-partial`` sibling directory (invisible to a consumer globbing
    the destination; same filesystem, so the ``os.replace`` is atomic),
    remove the scratch FILE on any failure, then compare sizes over the
    published file.  BOTH lanes' local delivery runs this --
    ``core/feed_engine._deliver_local`` and the job's ``_deliver_local``
    -- so "how a local file comes into being" is decided once.  A copy
    that fails raises; a stat that cannot run afterwards reads ``absent``
    with the reason, like :func:`sftp_publish`.

    The scratch DIRECTORY is never removed (2026-10-11).  It is shared by
    every delivery into one destination directory, and a sibling delivery
    sits between its ``makedirs`` and its ``copy2`` for a moment on every
    run: removing the directory "when empty" deleted it from under that
    sibling, whose copy then failed with ``No such file or directory``
    on its own scratch path.  One owner, one cleanup: a publish removes
    ITS scratch file and nothing else (the same rule as
    ``core/feed/publication.py``)."""
    import shutil
    dest_dir, name = os.path.split(target)
    scratch_dir = os.path.join(dest_dir, ".qs-partial")
    tmp = os.path.join(scratch_dir, f"{name}.part-{os.getpid()}")
    os.makedirs(scratch_dir, exist_ok=True)
    try:
        shutil.copy2(src, tmp)          # metadata too, as native always did
        with publishing(f"local {target}"):
            os.replace(tmp, target)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    try:
        local, remote = os.path.getsize(src), os.path.getsize(target)
    except OSError as exc:
        return {"verification": ABSENT, "detail": f"stat-failed: {exc}"}
    verify_size(local, remote, target)
    return {"verification": VERIFIED, "detail": f"size={remote}"}
