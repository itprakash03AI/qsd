"""Backend-agnostic feed SOURCE RESOLUTION — one plan, every backend.

2026-08-04.  Feed generation has multiple execution backends (native
DuckDB, Spark Connect, Airflow/Spark batch).  Until this module existed,
each backend re-derived "which SQL/config runs on which side" on its own:
the native path learned cross-source inheritance, saved-query secondary
shapes, sql_file ``-- ===SECONDARY===`` splitting and fail-closed
partial-config refusals (commit 71a0022c), while ``_execute_spark_connect``
kept its own older branch chain and received none of it — a feed routed
to Spark silently ran SINGLE-source (half the data, certified COMPLETE,
and the completeness certificate cannot catch it because source-rows and
dest-rows are wrong TOGETHER).

This is the same defect class the query compiler closed for BQB/CQB
(commit 4d94c60f: one compile, two renderers — preview == run BY
CONSTRUCTION).  Applied here: the feed's source shape resolves ONCE,
through the functions below, and every backend consumes the SAME
resolution.  A backend that cannot execute the resolved plan refuses
LOUDLY at the capability gate instead of silently degrading.

Registry shape (repo convention — core/file_formats/, FILTER_OPERATORS,
cross_source_preflight._CHECKS): adding a backend is one
``BACKEND_CAPABILITIES`` entry, not another if/elif chain.

Observability: refusals and gate decisions log ONE greppable
``[feed-crosssource]`` line carrying backend, both connection ids,
source_type and combine_mode.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# ── Backend capability registry ──────────────────────────────────────────
#
# ``cross_source``: can this backend materialise BOTH sides of a
# cross-connection feed and combine them (union/join)?
#   * native   — yes: each side runs through
#     ``feed_engine._run_single_source_native_query`` on its own pooled
#     DuckDB session; ``cross_source_combine`` merges the parquets.
#   * airflow  — yes: ``spark/jobs/generic_feed.py::maybe_combine_sources``
#     reads both sides in the Spark batch job and combines in PySpark.
#   * spark_connect — NO: ``feed_engine._execute_spark_connect`` drives a
#     single Spark session/DataFrame for ONE source; there is no
#     second-side materialisation or combine step.  Until one exists,
#     running a cross feed here would emit only the primary side.
#
# ``sql_connector_source`` (2026-08-22, design_starburst_140m §1.2;
# CORRECTED 2026-09-03): can this backend READ a feed whose primary
# source is a SQL connector — and WHICH connector types?  The value is
# either ``True`` (every connector type), ``False`` (none), or a
# tuple of the connector types the backend has a real read path for.
#   * native   — True: ``connector_to_parquet.execute_sql_to_parquet``
#     streams from the connector's OWN driver, whatever it is.
#   * airflow / spark_k8s — the JDBC grammar's exact type list
#     (``core.spark_k8s.jdbc.JDBC_SUPPORTED_TYPES``), imported so the
#     declaration CANNOT drift from the grammar.  The 2026-08-22
#     declaration said ``True``, which was coarser than reality:
#     ``databricks`` / ``athena`` / ``rest_api`` are connector types
#     with NO Spark JDBC grammar, so the router sent them to spark_k8s
#     where they died at conf-build inside build_jdbc_config.
#   * spark_connect — NO: ``spark_connect_executor`` resolves ONLY
#     s3a:// paths (``_resolve_s3_paths`` / ``_register_tables_as_views``);
#     a connector source has no bucket, resolves to [], and dies at
#     execution with "no S3-backed tables resolved".  The interactive
#     path has had this gate since day one (spark_dispatch ``not_s3``);
#     the feed router floors on this declaration.
#
# ``iceberg_source`` (2026-08-22): can this backend read an Iceberg-format
# registered table CORRECTLY (snapshot-aware + V2 merge-on-read deletes)?
#   * native — yes: the MoR-correct iceberg_reader chokepoint.
#   * every Spark path (airflow, spark_k8s, spark_connect) — NO: they scan
#     the prefix as plain parquet → snapshot-blind + delete-blind silent
#     overcount.  The router's iceberg floor keys on THIS declaration
#     (it used to be a hardcoded backend-name tuple — the registry is the
#     single chokepoint now, so a new backend is safe by default).
#
# ``spark_k8s`` (2026-08-22): QueryStudio's OWN Spark-on-Kubernetes
# backend (core/spark_k8s/) — submits the SAME generic_feed.py job the
# Airflow factory ran, so its source capabilities are identical to
# airflow's; the difference is who supervises (QS reconciler vs DAG).
#
# UNKNOWN = UNSAFE: a backend name not in this registry is treated as
# having NO capabilities.
# ``control_file`` (Phase 4, 2026-08-23): does a run on this backend
# produce the sidecar .ctl when the feed asks for one?  native /
# spark_connect / airflow all return a local artifact into the SHARED
# conversion+delivery pipeline, which writes the ctl.  spark_k8s
# self-delivers from the Spark job (generic_feed.py) which has NO
# control-file logic -- a ctl-requiring feed routed there delivered its
# data with no READY signal and reported COMPLETED.  UNKNOWN = UNSAFE.
# ``variance_hold`` (2026-10-12, owner R2): can a run on this backend HOLD
# its file for the release group when the row count breaches a 'hold'
# feed's threshold (core/feed/variance_hold.py)?  Only where the file comes
# back into the shared pipeline before delivery (native, Spark Connect); a
# job that delivers its own file (spark_k8s, airflow through it) cannot.
# ``step_source`` (2026-09-02): can this backend execute a STEP-served
# source (core/feed/steps — ``api``, ``landed_file``, and anything
# discovered from feed_generation.steps_dir)?  Honest declaration:
#   * native — yes: ``_run_single_source_native_query``'s dispatch calls
#     ``get_step("source", ...)`` and streams the step's extract.
#   * every Spark path (airflow, spark_k8s, spark_connect) — NO: their
#     jobs resolve SQL/S3 shapes only; a step source has neither, so
#     routing one there dies at execution (or worse, half-works).  The
#     router floors on THIS declaration instead of finding out.
# ``detached`` (2026-10-07, feed lane contract C4): does the run leave
# this process -- compute that can be UNAVAILABLE (a cluster, a DAG
# scheduler, a session pod)?  Every detached lane is answered by ONE
# function, ``core.feed.backend_router.lane_availability``, through a
# resolver in ``LANE_AVAILABILITY_RESOLVERS``; a detached lane with no
# resolver is unavailable (unknown = unsafe), and the conformance guard
# (tests/test_lane_conformance_lifecycle_2026_10_07.py) fails the build.
# The Spark-lane connector-type list is IMPORTED from the JDBC grammar
# so this declaration cannot drift from the code that builds the URLs.
# core.spark_k8s.jdbc is dependency-light (stdlib only) — no cycle.
from core.spark_k8s.jdbc import JDBC_SUPPORTED_TYPES as _SPARK_JDBC_TYPES

#
# ``output_formats`` (2026-10-07, feed lane contract K2): the output
# formats a backend produces with the native rules
# (``core/feed/lane_output.py``).  native and spark_connect render through
# ``core.feed.renderers`` in the API/worker pod (Spark Connect hands back a
# parquet).  The two lanes that run ``spark/jobs/generic_feed.py`` render
# csv / json / parquet with the shared rules -- and NOT Excel: the job
# image has no xlsx writer, and the job used to answer an Excel feed with a
# parquet file and a warning.  K2: what a lane cannot do it refuses at
# ROUTING, never degrades at run time -- the router's output-format floor
# reads this declaration.
_ALL_OUTPUT_FORMATS = ("csv", "json", "parquet", "excel")
_JOB_OUTPUT_FORMATS = ("csv", "json", "parquet")

BACKEND_CAPABILITIES: Dict[str, Dict[str, Any]] = {
    # ``tables_source`` (2026-10-14): can this backend run an S3 side's SQL
    # over the tables QueryStudio's planner decided (core/feed/read_plan.py,
    # the plan's "tables" kind)?  Iceberg tables additionally need
    # ``iceberg_source``.
    "native": {"cross_source": True, "sql_connector_source": True,
               "iceberg_source": True, "tables_source": True, "control_file": True,
               "step_source": True, "detached": False,
               "output_formats": _ALL_OUTPUT_FORMATS,
               "variance_hold": True,
               "label": "Native (DuckDB)"},
    "airflow": {"cross_source": True,
                "sql_connector_source": _SPARK_JDBC_TYPES,
                # 2026-10-14 -- Iceberg via the read plan ("tables" side: the planner's pinned
                # snapshot + metadata file, read by Iceberg's own reader).  The
                # merge-on-read tripwire PASSED: a real v2 table on AWS with 2,000
                # position + 150 equality deletes -> 17,850 rows, sum exact, = the
                # native engine (docs/READ_PLAN_ALL_ENGINES_2026_10_14.html, step 4).
                "iceberg_source": True, "tables_source": True, "control_file": True,
                "step_source": False, "detached": True,
                "output_formats": _JOB_OUTPUT_FORMATS,
                "variance_hold": False,
                "label": "Airflow (Spark batch job)"},
    "spark_k8s": {"cross_source": True,
                  "sql_connector_source": _SPARK_JDBC_TYPES,
                  # 2026-10-14 -- Iceberg via the read plan ("tables" side: the planner's pinned
                  # snapshot + metadata file, read by Iceberg's own reader).  The
                  # merge-on-read tripwire PASSED: a real v2 table on AWS with 2,000
                  # position + 150 equality deletes -> 17,850 rows, sum exact, = the
                  # native engine (docs/READ_PLAN_ALL_ENGINES_2026_10_14.html, step 4).
                  "iceberg_source": True, "tables_source": True, "control_file": False,
                  "step_source": False, "detached": True,
                  "output_formats": _JOB_OUTPUT_FORMATS,
                  "variance_hold": False,
                  "label": "QueryStudio Spark-on-K8s (SparkApplication)"},
    "spark_connect": {"cross_source": False, "sql_connector_source": False,
                      # its OWN s3a reader (spark_connect_executor), not the
                      # plan's "tables" side -- declared so the 2026-10-14
                      # tables floor leaves its routing exactly as it was
                      "tables_source": True,
                      "iceberg_source": False, "control_file": True,
                      "step_source": False, "detached": True,
                      "output_formats": _ALL_OUTPUT_FORMATS,
                      "variance_hold": True,
                      "label": "Spark Connect"},
}


def backend_supports_output_format(backend: str, output_format: str) -> bool:
    """Does ``backend`` produce ``output_format`` with the native rules?
    UNKNOWN = UNSAFE: an undeclared backend or format answers False."""
    caps = BACKEND_CAPABILITIES.get((backend or "").lower()) or {}
    return str(output_format or "csv").strip().lower() in \
        tuple(caps.get("output_formats") or ())


def backend_supports_sql_connector(backend: str, connector_type: str) -> bool:
    """Can ``backend`` read a feed sourced from ``connector_type``?

    The declaration is ``True`` (all types), ``False``/absent (none), or
    a collection of type names (the backend's real grammar).  UNKNOWN =
    UNSAFE: an unknown backend or an unknown connector type against a
    typed list answers False, so the router floors it to native instead
    of shipping a run that dies at conf-build.
    """
    caps = BACKEND_CAPABILITIES.get((backend or "").lower()) or {}
    declared = caps.get("sql_connector_source", False)
    if declared is True:
        return True
    if not declared:
        return False
    return (connector_type or "").strip().lower() in {
        str(t).lower() for t in declared}


def source_step_requires_native(source_type: str) -> Optional[bool]:
    """Does this feed's source kind REQUIRE the native backend?

    Derived from the source STEP's own declared traits, never from a
    hardcoded name list — the coupling the step registry removed must
    not come back through the router.  A step whose traits declare
    ``sql_shape=True`` is a SQL-over-a-connection shape the Spark jobs
    can also serve by resolving the SQL themselves; anything else only
    the native dispatch (``get_step("source", ...)``) can run.

    Returns True (only native can run it), False (Spark lanes may also
    serve it), or None (could not consult the registry — the caller
    decides its own posture; the execution-time gate remains the
    guarantee).  An UNKNOWN or load-failed step answers True: routing
    it native yields the loud, named refusal instead of a Spark pod
    dying on a shape its job never knew.
    """
    stype = (source_type or "").strip().lower()
    if not stype:
        return False                       # legacy default: SQL path
    try:
        from core.feed.steps import StepLoadFailed, UnknownStep, get_step
    except ImportError:
        return None
    try:
        step = get_step("source", stype)
    except (UnknownStep, StepLoadFailed):
        return True                        # unknown = unsafe for Spark
    except Exception as exc:               # registry broken — say so
        logger.debug(
            "[source_plan] step registry unavailable for source_type=%r "
            "(%s)", stype, exc)
        return None
    traits = getattr(step, "traits", None)
    return not bool(getattr(traits, "sql_shape", False))

#: Source types the ENGINE serves with built-in SQL branches; everything
#: else is a step-served source (core/feed/steps) and floors on the
#: ``step_source`` capability above.
SQL_SOURCE_TYPES = ("saved_query", "sql_file", "published_view", "raw_sql")


class BackendCapabilityError(ValueError):
    """The selected backend cannot execute the resolved source plan.

    Raised INSTEAD of silently degrading (e.g. running a cross-source
    feed single-source).  The message names the backend, both sides and
    the fix, in the operator's terms.
    """


@dataclass
class SourcePlan:
    """The backend-agnostic resolution of a feed's source shape."""
    is_cross: bool
    source_type: str
    source_id: Any
    connection_id: Any
    combine_mode: str = "union"
    join_config: Optional[dict] = None
    secondary_connection_id: Any = None
    secondary_source_type: str = ""
    secondary_source_id: Any = None


@dataclass
class SideResolution:
    """What ONE side of a feed must execute: its query_config (raw_sql or
    structured) and the connection it runs on."""
    query_config: dict
    connection_id: Any
    source_label: str


# ── Cross-source inheritance (single implementation) ─────────────────────


def inherit_cross_source(db_manager: Any, source_type: str, source_id: Any,
                         feed_config: dict) -> None:
    """Lift cross-source fields from a referenced saved_query / sql_file /
    published_view onto ``feed_config`` IN-PLACE when the feed itself has
    no explicit secondary_connection_id.  No-op when nothing to inherit.

    Moved verbatim from ``feed_engine._inherit_cross_source_from_referenced``
    (2026-08-04) so BOTH backends run the SAME inheritance — the native
    path and the Spark path used to disagree on whether a referenced
    cross-source query made the feed cross-source.

    Inheritance rules:
      * saved_query: read sq["query_config"].secondary_connection_id +
        combine_mode + join_config.  The secondary SQL SHAPE
        (secondary_query_config / secondary_raw_sql) is NOT copied here —
        the saved_query resolver reads it off the saved query directly
        when executing the secondary side (``_cross_side == "secondary"``).
      * sql_file:    read row.secondary_connection_id + combine_mode +
        join_config; secondary SQL lives in the file content (split via
        _split_cross_sql).
      * published_view: read the PV's UNDERLYING saved query's config the
        same way (2026-08-04 — before this, a feed on a cross-source PV
        silently ran single-source and certified COMPLETE on half the
        data).
      * raw_sql: not supported (feed-inline only; the feed's own
        secondary_connection_id covers the cross case).

    Fail-CLOSED (2026-08-04, was fail-open): a lookup error here used to
    log a WARNING and let the feed run SINGLE-source — emitting half the
    intended data and certifying the run COMPLETE.  UNKNOWN = UNSAFE:
    if we cannot determine whether the referenced source is cross-source,
    we refuse to run.  Likewise a saved query that carries a secondary
    SHAPE (secondary_query_config / secondary_raw_sql) but NO
    secondary_connection_id is refused with the fix spelled out, not
    silently half-run.
    """
    if db_manager is None:
        # Engine not initialized (unit-test import / early boot) — there
        # is nothing to look up.  The single-source path will fail on its
        # own if the DB is genuinely unavailable at execution time.
        return

    def _lift_from_query_cfg(qcfg: dict, label: str) -> None:
        """Shared lift for saved_query and published_view (which lifts
        from its UNDERLYING saved query's config)."""
        sec_cid = qcfg.get("secondary_connection_id")
        if not sec_cid:
            _sec_shape = (
                (isinstance(qcfg.get("secondary_query_config"), dict)
                 and qcfg.get("secondary_query_config"))
                or (isinstance(qcfg.get("secondary_raw_sql"), str)
                    and qcfg.get("secondary_raw_sql", "").strip())
            )
            if _sec_shape:
                raise ValueError(
                    f"{label} carries a cross-connection secondary side "
                    f"(secondary_query_config/secondary_raw_sql) but no "
                    f"secondary_connection_id. Running it single-source "
                    f"would silently emit only the primary side's rows. "
                    f"Fix: re-save the query with its secondary "
                    f"connection selected, or remove the secondary SQL "
                    f"from the saved query."
                )
            return
        feed_config["secondary_connection_id"] = sec_cid
        # ``secondary_source_type`` falls back to the primary; explicit
        # secondary_source_id stays None so the cross path reuses
        # the primary source row on the secondary connection.
        if qcfg.get("combine_mode"):
            feed_config.setdefault("combine_mode", qcfg["combine_mode"])
        if qcfg.get("join_config"):
            feed_config.setdefault("join_config", qcfg["join_config"])
        logger.info(
            "[feed-crosssource] inherited cross-source from %s "
            "(secondary_connection_id=%s combine=%s)",
            label, sec_cid, feed_config.get("combine_mode") or "union",
        )

    try:
        if source_type == "saved_query" and source_id:
            sq = db_manager.get_query(source_id)
            qcfg = (sq or {}).get("query_config") or {}
            _lift_from_query_cfg(
                qcfg if isinstance(qcfg, dict) else {},
                f"saved_query {source_id} ('{(sq or {}).get('name') or ''}')",
            )
        elif source_type == "published_view" and source_id:
            # 2026-08-04 — a PV publishes an upstream saved query; when
            # THAT query is cross-source, the feed must combine both
            # sides too.  Before this branch existed, PV-sourced feeds
            # silently ran single-source (half the data, certified
            # COMPLETE).
            pv = db_manager.get_published_view(source_id)
            if not pv:
                return
            sq = db_manager.get_query(pv.get("query_id")) if pv.get("query_id") else None
            qcfg = (sq or {}).get("query_config") or {}
            _lift_from_query_cfg(
                qcfg if isinstance(qcfg, dict) else {},
                f"published_view {source_id}'s saved query "
                f"{pv.get('query_id')} ('{(sq or {}).get('name') or ''}')",
            )
        elif source_type == "sql_file" and source_id:
            sf = db_manager.get_sql_file(source_id)
            if not sf:
                return
            sec_cid = sf.get("secondary_connection_id")
            if not sec_cid:
                return
            feed_config["secondary_connection_id"] = sec_cid
            if sf.get("combine_mode"):
                feed_config.setdefault("combine_mode", sf["combine_mode"])
            if sf.get("join_config"):
                feed_config.setdefault("join_config", sf["join_config"])
            logger.info(
                "[feed-crosssource] inherited cross-source from sql_file %s "
                "(secondary_connection_id=%s combine=%s)",
                source_id, sec_cid, feed_config.get("combine_mode") or "union",
            )
    except ValueError:
        # Deliberate refusal (partial cross-source config) — propagate
        # verbatim; the message already names the fix.
        raise
    except Exception as exc:
        # Fail-CLOSED (2026-08-04).  Previously this warned and fell back
        # to single-source: a transient DB error during the lookup made a
        # cross-source feed emit HALF its data and certify the run
        # COMPLETE.  The same lookup re-runs inside the single-source
        # resolvers, so a feed that genuinely is single-source loses
        # nothing — it would have failed there anyway.
        raise ValueError(
            f"[feed-crosssource] Could not determine whether {source_type} "
            f"{source_id} is cross-source ({type(exc).__name__}: {exc}). "
            f"Refusing to run rather than risk silently dropping the "
            f"secondary side. Retry the run; if this persists, check the "
            f"referenced {source_type} exists and is readable."
        ) from exc


def detect_cross_source(db_manager: Any, feed_config: dict) -> bool:
    """Read-only probe: is this feed cross-source, explicitly or by
    inheritance from its referenced source?  Used by the backend router's
    capability floor.  Fail-OPEN (returns False on any error) because the
    router floor is a routing convenience — the fail-CLOSED guarantee is
    the capability gate inside ``resolve_source_plan``, which every
    backend passes through at execution time.
    """
    if isinstance(feed_config, dict) and feed_config.get("secondary_connection_id"):
        return True
    if db_manager is None or not isinstance(feed_config, dict):
        return False
    try:
        probe = dict(feed_config)  # never mutate the caller's config
        inherit_cross_source(
            db_manager,
            probe.get("source_type") or "",
            probe.get("source_id"),
            probe,
        )
        return bool(probe.get("secondary_connection_id"))
    except Exception:
        # Includes the deliberate partial-config refusal: for ROUTING
        # purposes a half-built cross config counts as cross (route it
        # to a backend whose gate will explain the problem properly).
        return True


# ── Capability gate + plan resolution ────────────────────────────────────


def assert_backend_capability(backend: str, feed_config: dict) -> None:
    """Refuse LOUDLY when ``backend`` cannot execute this feed's shape.

    Called after inheritance, so an inherited cross-source feed is
    caught the same as an explicit one.  Registry-driven: a new backend
    is one ``BACKEND_CAPABILITIES`` entry.
    """
    caps = BACKEND_CAPABILITIES.get((backend or "").lower()) or {}
    _stype = (feed_config.get("source_type") or "").strip().lower()
    if _stype and _stype not in SQL_SOURCE_TYPES \
            and not caps.get("step_source"):
        label = caps.get("label") or backend or "unknown backend"
        msg = (
            f"Feed '{feed_config.get('name') or feed_config.get('id')}' "
            f"uses the STEP-served source '{_stype}' (core/feed/steps), "
            f"but the selected backend '{backend}' ({label}) executes "
            f"SQL/S3 shapes only — it cannot run a source step.  "
            f"Routing it there would die at execution or silently "
            f"half-work.  Fix: use the native backend (default), or "
            f"change the feed to a SQL source type "
            f"{list(SQL_SOURCE_TYPES)}."
        )
        logger.error(
            "[feed-crosssource] backend-capability REFUSED feed=%s "
            "backend=%s source_type=%s (step-served; backend lacks "
            "step_source)",
            feed_config.get("id"), backend, _stype,
        )
        raise BackendCapabilityError(msg)
    if feed_config.get("secondary_connection_id") and not caps.get("cross_source"):
        label = caps.get("label") or backend or "unknown backend"
        msg = (
            f"Feed '{feed_config.get('name') or feed_config.get('id')}' is "
            f"CROSS-SOURCE (primary connection "
            f"{feed_config.get('connection_id')}, secondary connection "
            f"{feed_config.get('secondary_connection_id')}, combine_mode="
            f"{feed_config.get('combine_mode') or 'union'}), but the "
            f"selected backend '{backend}' ({label}) executes a single "
            f"source only — it cannot materialise the secondary side or "
            f"combine.  Running it here would silently emit only the "
            f"primary side's rows and certify the run COMPLETE on half "
            f"the data.  Fix: use the native backend (default) or the "
            f"airflow backend (both combine cross-source feeds), or "
            f"remove the secondary side from the feed."
        )
        logger.error(
            "[feed-crosssource] backend-capability REFUSED feed=%s backend=%s "
            "primary_conn=%s secondary_conn=%s source=%s/%s combine=%s",
            feed_config.get("id"), backend,
            feed_config.get("connection_id"),
            feed_config.get("secondary_connection_id"),
            feed_config.get("source_type"), feed_config.get("source_id"),
            feed_config.get("combine_mode") or "union",
        )
        raise BackendCapabilityError(msg)


def resolve_source_plan(db_manager: Any, feed_config: dict,
                        backend: str) -> SourcePlan:
    """THE chokepoint: resolve a feed's source shape once, backend-aware.

    1. Runs cross-source inheritance (single implementation above) —
       mutates ``feed_config`` in place exactly like the native path
       always has, so downstream code on every backend sees the same
       lifted fields.
    2. Applies the backend capability gate (loud refusal, never silent
       degrade).
    3. Returns the resolved :class:`SourcePlan`.
    """
    if not feed_config.get("secondary_connection_id"):
        inherit_cross_source(
            db_manager,
            feed_config.get("source_type") or "",
            feed_config.get("source_id"),
            feed_config,
        )
    assert_backend_capability(backend, feed_config)
    return SourcePlan(
        is_cross=bool(feed_config.get("secondary_connection_id")),
        source_type=feed_config.get("source_type") or "",
        source_id=feed_config.get("source_id"),
        connection_id=feed_config.get("connection_id"),
        combine_mode=(feed_config.get("combine_mode") or "union").strip().lower(),
        join_config=feed_config.get("join_config"),
        secondary_connection_id=feed_config.get("secondary_connection_id"),
        secondary_source_type=feed_config.get("secondary_source_type") or "",
        secondary_source_id=feed_config.get("secondary_source_id"),
    )


# ── Per-side shape resolution (single implementations) ───────────────────


def secondary_side_config(feed_config: dict, plan: Optional[SourcePlan] = None) -> dict:
    """THE feed_config the SECONDARY side of a cross feed executes with.

    2026-10-11 -- until now the native engine, the Spark/Airflow plan and
    the union pushdown each built this dict by hand (three copies of
    "connection swaps, source_type / source_id fall back to the primary,
    stamp ``_cross_side``").  One builder now, so the fourth reader cannot
    disagree with the other three:

    * ``connection_id`` becomes ``secondary_connection_id``;
    * ``source_type`` / ``source_id`` are the secondary's when declared,
      else the primary's ("same query, different warehouse");
    * ``_cross_side = "secondary"``; an inherited dialect stamp is dropped
      (the secondary has its OWN connection -- 2026-09-05 lesson);
    * a ``raw_sql`` second side reads ``query_params.secondary_raw_sql`` --
      the feed form's "SQL" choice for the second side (2026-10-11) -- so
      ``RawSqlSourceStep`` / the plan's raw_sql branch see it as ``sql``.
      Without this the secondary of a raw_sql cross feed ran the PRIMARY's
      text on the native lane (the plan lane had read
      ``secondary_raw_sql`` since 2026-09-14; native never did).
    """
    fc = dict(feed_config)
    fc["_cross_side"] = "secondary"
    fc["connection_id"] = (plan.secondary_connection_id if plan is not None
                           else feed_config.get("secondary_connection_id"))
    fc.pop("connection_type", None)
    fc.pop("source_connection_type", None)
    primary_st = feed_config.get("source_type")
    primary_sid = feed_config.get("source_id")
    sec_st = ((plan.secondary_source_type if plan is not None
               else feed_config.get("secondary_source_type")) or primary_st)
    sec_sid = ((plan.secondary_source_id if plan is not None
                else feed_config.get("secondary_source_id")) or primary_sid)
    fc["source_type"] = sec_st
    fc["source_id"] = sec_sid
    if str(sec_st or "").lower() == "raw_sql":
        qp = dict(feed_config.get("query_params") or {})
        sec_sql = qp.get("secondary_raw_sql")
        if isinstance(sec_sql, str) and sec_sql.strip():
            qp["sql"] = sec_sql
            fc["query_params"] = qp
    return fc


def apply_secondary_shape(qcfg: dict, feed_config: dict,
                          source_label: str) -> dict:
    """Return the query_config this SIDE of a cross feed must execute.

    Moved verbatim from ``feed_engine._apply_secondary_shape``
    (2026-08-04) so both backends substitute the SAME saved secondary
    shape.

    BQB saves cross-connection queries with the secondary side's OWN
    shape on the saved query config (post-163ccd2:
    ``secondary_query_config`` for builder mode, ``secondary_raw_sql``
    for SQL-editor mode).  When this execution IS the secondary side
    (``feed_config["_cross_side"] == "secondary"``), run THAT shape —
    not the primary's.  Before this fix the secondary side re-ran the
    PRIMARY SQL against the secondary connection: verified by execution
    (2026-08-04) to emit the primary rows TWICE and complete
    "successfully" — half the intended data, certified COMPLETE.

    Falls through unchanged when the saved query has no distinct
    secondary shape (common case: same query, different warehouse) or
    when this is the primary side.
    """
    if feed_config.get("_cross_side") != "secondary":
        return qcfg
    _sec_qcfg = qcfg.get("secondary_query_config")
    _sec_raw = qcfg.get("secondary_raw_sql")
    if isinstance(_sec_qcfg, dict) and _sec_qcfg:
        logger.info(
            "[feed-crosssource] feed %s secondary side: using %s's "
            "secondary_query_config (distinct secondary shape)",
            feed_config.get("id"), source_label,
        )
        return dict(_sec_qcfg)
    if isinstance(_sec_raw, str) and _sec_raw.strip():
        logger.info(
            "[feed-crosssource] feed %s secondary side: using %s's "
            "secondary_raw_sql (distinct secondary SQL)",
            feed_config.get("id"), source_label,
        )
        out = {k: v for k, v in qcfg.items()
               if k not in ("secondary_query_config",
                            "secondary_raw_sql",
                            "secondary_connection_id")}
        out["raw_sql"] = _sec_raw
        return out
    return qcfg


def select_sql_file_side(sql: str, feed_config: dict, source_id: Any,
                         file_name: str = "") -> str:
    """Pick the side of a (possibly cross-connection) .sql file this
    execution serves.  Single implementation of the split semantics the
    native path gained on 2026-08-04 (feed_engine sql_file branch) so the
    Spark path cannot diverge from it.

    * File WITHOUT a ``-- ===SECONDARY===`` separator: returned as-is
      (both sides run the same SQL — "same query, different warehouse").
    * File WITH the separator on a SINGLE-source feed: REFUSED.
      Executing the concatenation is a parse error; silently running only
      the primary section would emit half the intended data and certify
      it COMPLETE.  UNKNOWN = UNSAFE.
    * Cross feed: returns the section for ``feed_config["_cross_side"]``.
    """
    from api.sql_files_api import _split_cross_sql
    _pri_sql, _sec_sql = _split_cross_sql(sql)
    _side = feed_config.get("_cross_side")
    if _sec_sql is not None and _side is None:
        raise ValueError(
            f"SQL file {source_id} ('{file_name}') contains a "
            f"'-- ===SECONDARY===' cross-connection section, but this "
            f"feed is configured single-source (no secondary_connection_id "
            f"on the feed or the SQL file). Running only the primary "
            f"section would silently emit half the data. Fix: set "
            f"secondary_connection_id on the SQL file (or the feed), or "
            f"remove the secondary section from the file."
        )
    if _side == "secondary" and _sec_sql:
        logger.info(
            "[feed-crosssource] feed %s secondary side: using the "
            "secondary section of sql_file %s",
            feed_config.get("id"), source_id,
        )
        return _sec_sql
    return _pri_sql


def read_sql_file_content(db_manager: Any, source_id: Any) -> Dict[str, Any]:
    """Load a SqlFile row + its on-disk content with the BF-415
    path-traversal guard.  Returns ``{"row": <sql_file row>, "sql": str}``.
    Raises ValueError with an operator-facing message on every failure
    mode (missing row, inactive, traversal, missing/empty file).
    """
    sf = db_manager.get_sql_file(source_id)
    if not sf:
        raise ValueError(f"SQL file {source_id} not found")
    if not sf.get("is_active", True):
        raise ValueError(f"SQL file {source_id} is inactive")
    _rel_path = sf.get("file_path") or ""
    if not _rel_path:
        raise ValueError(f"SQL file {source_id} has no file_path")
    try:
        from api.sql_files_api import _get_storage_dir
        _storage_root = _get_storage_dir().resolve()
        _resolved = (_storage_root / _rel_path).resolve()
    except Exception as _path_exc:
        raise ValueError(
            f"SQL file {source_id}: storage path resolution failed: {_path_exc}"
        )
    # BF-415 — path-traversal guard.  A tampered DB row could otherwise
    # read arbitrary files from disk via "../../etc/passwd".
    try:
        _resolved.relative_to(_storage_root)
    except ValueError:
        raise ValueError(
            f"SQL file {source_id}: file_path resolves outside the "
            f"storage directory (possible tampered DB row); refusing to read"
        )
    try:
        sql = _resolved.read_text(encoding="utf-8")
    except OSError as _io_exc:
        raise ValueError(
            f"SQL file {source_id} could not be read: {_io_exc.strerror}"
        )
    if not sql.strip():
        raise ValueError(f"SQL file {source_id} is empty")
    return {"row": sf, "sql": sql}


def resolve_side_query_config(db_manager: Any,
                              feed_config: dict) -> SideResolution:
    """Resolve ONE side of a feed to the query_config + connection it
    must execute.  Backend-agnostic: this is the same source-shape
    vocabulary the native path executes (saved_query / sql_file /
    published_view / raw_sql), including the 2026-08-04 cross-source
    semantics (secondary shape substitution, sql_file side selection,
    loud refusals).  The Spark Connect path consumes this INSTEAD of its
    former private branch chain, so the two backends cannot diverge on
    "which SQL runs".

    Note: the native path additionally performs execution-coupled setup
    (registered-table views, WHERE-mapping rebuild) inside
    ``_run_single_source_native_query``; those stay where the execution
    is.  What lives HERE is the part both backends must agree on: which
    SQL/config, on which connection.
    """
    source_type = feed_config.get("source_type")
    source_id = feed_config.get("source_id")
    connection_id = feed_config.get("connection_id")

    if source_type == "saved_query":
        sq = db_manager.get_query(source_id)
        if not sq:
            raise ValueError(f"Saved query {source_id} not found")
        qcfg = sq.get("query_config") or {}
        qcfg = apply_secondary_shape(qcfg, feed_config,
                                     f"saved query {source_id}")
        return SideResolution(
            query_config=dict(qcfg),
            connection_id=connection_id or qcfg.get("connection_id"),
            source_label=f"saved_query:{source_id}",
        )

    if source_type == "sql_file":
        loaded = read_sql_file_content(db_manager, source_id)
        sf = loaded["row"]
        sql = select_sql_file_side(
            loaded["sql"], feed_config, source_id, sf.get("name") or "",
        )
        # Optional {{param}} substitution from query_params (same helper
        # the native branch uses; fail-open, mirrors feed_engine).
        query_params = feed_config.get("query_params") or {}
        if query_params:
            try:
                from api.published_views.helpers import _substitute_params as _pv_sub
                _stub_qc = _pv_sub({"raw_sql": sql}, query_params)
                sql = _stub_qc.get("raw_sql", sql)
            except Exception as _sub_exc:
                logger.warning(
                    "[feed-crosssource] sql_file param substitution failed "
                    "(%s) — executing raw SQL", _sub_exc,
                )
        conn_id = connection_id or sf.get("connection_id")
        return SideResolution(
            query_config={"raw_sql": sql, "connection_id": conn_id},
            connection_id=conn_id,
            source_label=f"sql_file:{source_id}",
        )

    if source_type == "published_view":
        pv = db_manager.get_published_view(source_id)
        if not pv:
            raise ValueError(f"Published view {source_id} not found")
        sq = db_manager.get_query(pv["query_id"]) if pv.get("query_id") else None
        if not sq:
            raise ValueError(
                f"Underlying saved query {pv.get('query_id')} not found for view"
            )
        qcfg = sq.get("query_config") or {}
        qcfg = apply_secondary_shape(
            qcfg, feed_config,
            f"published_view {source_id}'s saved query {pv.get('query_id')}")
        return SideResolution(
            query_config=dict(qcfg),
            connection_id=(connection_id
                           or pv.get("connection_id")
                           or qcfg.get("connection_id")),
            source_label=f"published_view:{source_id}",
        )

    if source_type == "raw_sql":
        query_params = feed_config.get("query_params") or {}
        sql = query_params.get("sql", "")
        if not sql:
            raise ValueError("raw_sql source requires 'sql' in query_params")
        # 2026-09-14 -- the cross-source secondary shape reached THREE of
        # the four source types.  saved_query and published_view call
        # apply_secondary_shape; sql_file calls select_sql_file_side;
        # raw_sql called NEITHER and returned query_params["sql"], so the
        # secondary side of a raw_sql cross-source feed executed THE
        # PRIMARY'S SQL.  That is the exact defect apply_secondary_shape's
        # own docstring records being fixed for saved queries on
        # 2026-08-04 ("emit the primary rows TWICE and complete
        # successfully") -- fixed there, never applied here.  Observed on
        # feed 3: a declared INNER JOIN on a 97-row dimension serialized
        # with the 500k fact SQL on BOTH sides, i.e. a silent self-join.
        # Nothing refused it, because nothing compared the two sides.
        _qc = dict(query_params)
        _qc["raw_sql"] = sql
        _qc = apply_secondary_shape(_qc, feed_config, "raw_sql feed")
        sql = _qc.get("raw_sql", sql)
        return SideResolution(
            query_config={"raw_sql": sql, "connection_id": connection_id},
            connection_id=connection_id,
            source_label="raw_sql",
        )

    raise ValueError(f"Unsupported source_type: {source_type}")
