"""ON COMPLETION OF -- a feed starts by itself when its upstream finishes.

Owner decision 2026-10-03 ("yes it's common sense").  A feed whose
``schedule_declaration`` is ``{"kind": "on_completion_of", "feed": X}`` is
EVENT-DRIVEN: the SOD generator writes it no row (``Due.EVENT_DRIVEN``) and,
until this module, NOTHING else did either -- it ran only on Run Now.

The rule
--------
When a run of feed X reaches a TERMINAL SUCCESS -- the execution is
``completed`` AND its delivery chain says ``delivered``
(``stage_timings.delivery_chain.verdict``, the slot
``core.feed.delivery_hops.chain_verdict`` fills on every lane) -- every
ACTIVE feed declaring ``on_completion_of X`` gets ONE pending run for the
SAME business date.  Anything else triggers nothing and says why: failed,
cancelled, completed undelivered (a failed chain, a SUPPRESSED chain -- a
backfill without delivery, policy -- or a DRY RUN), or completed with no
verdict recorded (a spark_k8s run the reconciler finalised without its
webhook: its delivery was never confirmed, and unknown is not delivered).

Where it is called -- ONE place
-------------------------------
Every lane's execution row reaches its terminal state through
``FeedsMixin.update_feed_execution``: the native engine's
``_finalize_execution_row``, the Spark/Airflow lanes' signed webhook
(``POST /api/webhooks/feed-complete``), the spark_k8s reconciler, and the
webhook-side delivery that records its chain verdict AFTER the row went
``completed``.  The DAO captures the row's state before the write in the
same session and calls :func:`on_execution_written` after it committed; the
hook acts only on the EDGE (:func:`should_fire`) -- the write that changed
the terminal outcome -- so the dozens of non-terminal writes a run makes
cost nothing, and a later re-write of the same outcome never re-fires.

How the run is created -- the SAME body SOD uses
-------------------------------------------------
``SodTaskGenerator.create_upstream_triggered_run``: the downstream's
validity window, its OWN calendar (a non-business day is a SKIP row, "a
holiday SKIP stays a skip"), its ACTION_CONDITION, its creation-time
dependency hold (WAIT until the poller releases it), the INSERT and the
planned step rows -- ``_create_run_row``, shared with the daily SOD pass.
The queue worker claims it like any pending row; nothing here executes.

Idempotency
-----------
Exactly one downstream run per (feed, business_date) however often the
upstream completes (rerun, regeneration, a duplicate webhook, two pods):
a pre-check (``get_feed_run_by_feed_date``) and, for the race, a
DETERMINISTIC build id ``upstream-<date>`` under the partial unique index
``ux_feed_runs_identity`` -- the second INSERT loses inside the database.

Visibility
----------
The downstream row says what started it (``triggered_by =
'upstream_completion'``, ``upstream_feed_name``, ``upstream_execution_id``,
``upstream_feed_run_id``).  The UPSTREAM's ledger gets one run event per
evaluated transition -- ``downstream_triggered`` (which runs were created)
or ``downstream_not_triggered`` (why none) -- and the same sentence is
logged.  A feed that nothing declares downstream of records nothing.

A manual Run Now of the upstream counts (decision 2026-10-03): it owns a
``run_type='manual'`` feed_run whose business date is the one the run
executed for (the date the dialog preflighted, else today), and its
completion triggers the downstream for THAT date, naming the manual
execution.  A date that cannot be resolved triggers nothing and says so.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

#: Execution statuses that END a run.  ``skipped`` (an idempotent
#: short-circuit releasing a pre-created row) is not a run having happened.
TERMINAL_STATUSES = ("completed", "failed", "cancelled")

#: The ledger event types (closed vocabulary: core.db.models.RUN_EVENT_TYPES).
EVENT_TRIGGERED = "downstream_triggered"
EVENT_NOT_TRIGGERED = "downstream_not_triggered"

#: The one verdict that means the file reached every declared destination
#: (core.feed.delivery_hops.CHAIN_DELIVERED).
_DELIVERED = "delivered"


# ── the edge ──────────────────────────────────────────────────────────────

def chain_verdict_of(stage_timings: Any) -> Optional[str]:
    """``stage_timings.delivery_chain.verdict``, or None when the record
    carries none."""
    if not isinstance(stage_timings, Mapping):
        return None
    chain = stage_timings.get("delivery_chain")
    if isinstance(chain, Mapping) and chain.get("verdict"):
        return str(chain.get("verdict"))
    return None


def terminal_outcome(status: Any, stage_timings: Any) -> Optional[Tuple[str, Optional[str]]]:
    """``(status, verdict)`` of a TERMINAL execution, else None."""
    s = str(status or "").lower()
    if s not in TERMINAL_STATUSES:
        return None
    return s, (chain_verdict_of(stage_timings) if s == "completed" else None)


def should_fire(before: Mapping[str, Any], after: Mapping[str, Any]) -> bool:
    """Did THIS write change the terminal outcome?

    * the row became terminal (it was not before), or moved to another
      terminal status;
    * the status stayed ``completed`` and a delivery verdict APPEARED or
      CHANGED -- the webhook-side delivery records its verdict after the
      callback already closed the row, and an Airflow run's engine fills
      the verdict onto a row its webhook completed first.

    A verdict DISAPPEARING (a later write that carried stage timings
    without it) is not an outcome and never fires: a "not triggered"
    after a "triggered" for the same run would be a lie.
    """
    new = terminal_outcome((after or {}).get("status"),
                           (after or {}).get("stage_timings"))
    if new is None:
        return False
    old = terminal_outcome((before or {}).get("status"),
                           (before or {}).get("stage_timings"))
    if old is None or old[0] != new[0]:
        return True
    return new[1] is not None and new[1] != old[1]


def success_verdict(execution: Mapping[str, Any]) -> Tuple[bool, Optional[str]]:
    """``(True, None)`` for a terminal SUCCESS (completed AND delivered),
    else ``(False, why)`` in words an operator can act on."""
    status = str(execution.get("status") or "").lower()
    if status in ("failed", "cancelled"):
        where = (f" at {execution.get('failed_stage')}"
                 if execution.get("failed_stage") else "")
        err = str(execution.get("error_message") or "").strip()
        return False, (f"the upstream run {status}{where}"
                       + (f": {err[:300]}" if err else ""))
    if status != "completed":
        return False, f"the upstream run is not terminal ({status or 'unknown'})"
    verdict = chain_verdict_of(execution.get("stage_timings"))
    if verdict == _DELIVERED:
        return True, None
    return False, _why_completed_undelivered(execution, verdict)


def _why_completed_undelivered(execution: Mapping[str, Any],
                               verdict: Optional[str]) -> str:
    """The reason a COMPLETED run is not a terminal success."""
    st = execution.get("stage_timings")
    chain = st.get("delivery_chain") if isinstance(st, Mapping) else None
    reason = chain.get("reason") if isinstance(chain, Mapping) else None
    if verdict == "suppressed":
        return ("the upstream completed but delivery was SUPPRESSED on every "
                "hop (a backfill without delivery, or policy)"
                + (f": {reason}" if reason else ""))
    if verdict == "dry_run":
        return "the upstream run was a DRY RUN: nothing was delivered"
    if verdict:
        return (f"the upstream completed but its delivery chain says "
                f"{verdict!r}" + (f": {reason}" if reason else ""))
    fm = execution.get("files_metadata")
    sk = fm.get("spark_k8s") if isinstance(fm, Mapping) else None
    if isinstance(sk, Mapping) and sk.get("delivery"):
        return (f"the upstream completed via "
                f"{sk.get('completed_via') or 'the reconciler'} and its "
                f"delivery is {sk.get('delivery')} -- unknown is not delivered")
    return ("the upstream completed but no delivery verdict is recorded (yet) "
            "-- unknown is not delivered; a verdict that lands later is "
            "evaluated again")


# ── who is downstream ─────────────────────────────────────────────────────

def declared_upstream(declaration: Any) -> Optional[str]:
    """The upstream feed NAME an ``on_completion_of`` declaration names,
    or None (no declaration, another kind, or unparseable -- the authoring
    routes refuse those; a legacy row is skipped with a log)."""
    if not isinstance(declaration, Mapping):
        return None
    from core.feed.schedule import KIND_ON_COMPLETION, parse_schedule
    if declaration.get("kind") != KIND_ON_COMPLETION:
        return None
    try:
        sched = parse_schedule(dict(declaration))
    except Exception as exc:   # noqa: BLE001 -- one bad row must not hide the rest
        logger.warning("[on_completion] unparseable on_completion_of "
                       "declaration %r skipped: %s", declaration, exc)
        return None
    name = str(getattr(sched, "upstream_feed", "") or "").strip()
    return name or None


def same_feed_name(a: Any, b: Any) -> bool:
    """Feed names are unique CASE-INSENSITIVELY (``get_feed_ids_by_name``),
    and ``_refuse_unknown_upstream_feed`` accepts a declaration on that
    rule -- so the trigger must match on it too, or a saved declaration
    could never fire."""
    return (str(a or "").strip().upper() == str(b or "").strip().upper()
            and bool(str(a or "").strip()))


def on_completion_edges(rows: List[Mapping[str, Any]]) -> Dict[str, List[Mapping[str, Any]]]:
    """``{UPSTREAM NAME (upper): [feed rows declaring on_completion_of it]}``
    -- the ONE edge rule (also walked by
    ``core.feed.regeneration.enumerate_downstream_feeds``)."""
    edges: Dict[str, List[Mapping[str, Any]]] = {}
    for r in rows or []:
        up = declared_upstream(r.get("schedule_declaration"))
        if up:
            edges.setdefault(up.upper(), []).append(r)
    return edges


def direct_downstream_feeds(db, feed_name: str,
                            rows: Optional[List[Mapping[str, Any]]] = None) -> List[Mapping[str, Any]]:
    """Feeds of ``rows`` (default: the ACTIVE feeds) whose declaration is
    ``on_completion_of feed_name`` -- never the feed itself."""
    if rows is None:
        rows = db.list_feed_schedule_declarations(active_only=True)
    return [r for r in on_completion_edges(rows).get(
                str(feed_name or "").strip().upper(), [])
            if not same_feed_name(r.get("name"), feed_name)]


# ── the hook ──────────────────────────────────────────────────────────────

def on_execution_written(db, before: Mapping[str, Any],
                         row: Mapping[str, Any]) -> Optional[dict]:
    """Called by ``FeedsMixin.update_feed_execution`` after EVERY committed
    execution write; acts only on the edge (:func:`should_fire`)."""
    if not should_fire(before, row):
        return None
    return on_upstream_terminal(db, row)


def _coerce_date(value: Any) -> Optional[date]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _upstream_identity(db, execution: Mapping[str, Any],
                       feed_name: str) -> Tuple[Dict[str, Any], Optional[date]]:
    """``(upstream, business_date)``: the run this execution belongs to
    and the business date it ran for.  The run row is THE answer (SOD /
    queue rows, a backfill row, a manual Run Now's own run -- whose date is
    what the engine resolved ``{{business_date}}`` from); the execution's
    own stamp is the fallback; None when neither says."""
    run = None
    try:
        run = db.feed_run_for_execution(dict(execution))
    except Exception as exc:   # noqa: BLE001 -- the fallback below is stated
        logger.warning("[on_completion] the run of execution %s could not be "
                       "resolved (%s) -- using the execution's own business "
                       "date", execution.get("execution_id"), exc)
    bd = _coerce_date((run or {}).get("business_date")) \
        or _coerce_date(execution.get("business_date"))
    upstream = {
        "feed_id": execution.get("feed_config_id"),
        "feed_name": feed_name,
        "execution_id": execution.get("execution_id"),
        "execution_db_id": execution.get("id"),
        "feed_run_id": (run or {}).get("id"),
        "run_type": (run or {}).get("run_type"),
        "build_id": (run or {}).get("build_id") or execution.get("build_id"),
        "trigger_type": execution.get("trigger_type"),
    }
    return upstream, bd


def _record(db, *, upstream: Mapping[str, Any], business_date: date,
            event_type: str, downstream_names: List[str],
            payload: Dict[str, Any]) -> None:
    from core.feed.ledger import record_run_event
    record_run_event(
        db, feed_config_id=int(upstream["feed_id"]),
        business_date=business_date, event_type=event_type,
        subject=", ".join(downstream_names)[:500] or None, actor="system",
        build_id=(str(upstream.get("build_id"))[:100]
                  if upstream.get("build_id") else None),
        payload={"upstream_feed": upstream.get("feed_name"),
                 "upstream_execution_id": upstream.get("execution_id"),
                 "feed_run_id": upstream.get("feed_run_id"),
                 "upstream_trigger_type": upstream.get("trigger_type"),
                 **payload})


def on_upstream_terminal(db, execution: Mapping[str, Any]) -> Optional[dict]:
    """Evaluate one terminal upstream execution against the feeds declared
    downstream of it.  Returns ``{"triggered": bool, "reason", "business_
    date", "downstream": [outcome...]}``, or None when no feed declares
    ``on_completion_of`` this one (nothing to say).  Each downstream's
    creation and the ledger write are fail-soft and stated; a feed list
    that cannot be read raises, and the DAO hook names it in the log."""
    feed_id = execution.get("feed_config_id")
    if feed_id is None:
        return None
    rows = db.list_feed_schedule_declarations(active_only=False)
    me = next((r for r in rows if int(r["id"]) == int(feed_id)), None)
    if me is None:
        return None
    feed_name = str(me.get("name") or "")
    downstream = direct_downstream_feeds(
        db, feed_name, rows=[r for r in rows if r.get("is_active")])
    if not downstream:
        return None
    names = [str(d.get("name")) for d in downstream]
    upstream, bd = _upstream_identity(db, execution, feed_name)
    ok, why = success_verdict(execution)
    exec_id = execution.get("execution_id")
    if ok and bd is None:
        ok, why = False, ("no business date could be resolved for the upstream "
                          "run (no run row, no business date on the execution) "
                          "-- refusing to guess one")
    if not ok:
        logger.info("[on_completion] %s execution %s: downstream %s NOT "
                    "triggered -- %s", feed_name, exec_id, names, why)
        _record(db, upstream=upstream,
                business_date=bd or datetime.now(timezone.utc).date(),
                event_type=EVENT_NOT_TRIGGERED, downstream_names=names,
                payload={"reason": why, "business_date_unresolved": bd is None,
                         "execution_status": execution.get("status"),
                         "delivery_verdict": chain_verdict_of(
                             execution.get("stage_timings")),
                         "downstream": [{"feed_id": d.get("id"),
                                         "feed_name": d.get("name"),
                                         "outcome": "not_triggered"}
                                        for d in downstream]})
        return {"triggered": False, "reason": why, "business_date": bd,
                "downstream": []}
    return _trigger(db, downstream, names, upstream, bd)


def _trigger(db, downstream: List[Mapping[str, Any]], names: List[str],
             upstream: Mapping[str, Any], bd: date) -> dict:
    """Create one run per downstream feed through THE creator, then say
    what happened -- in the log and on the upstream's ledger."""
    from core.feed.sod_generator import SodTaskGenerator
    gen = SodTaskGenerator(db)
    outcomes = []
    for d in downstream:
        fc = db.get_feed_config(int(d["id"]))
        if not fc or not fc.get("is_active"):
            outcomes.append({"feed_id": d.get("id"), "feed_name": d.get("name"),
                             "outcome": "inactive", "run_id": None,
                             "reason": "the downstream feed is no longer active"})
            continue
        outcomes.append(gen.create_upstream_triggered_run(fc, bd, upstream=upstream))
    created = [o for o in outcomes if o.get("outcome") == "created"]
    consumer = _queue_consumer(db, created)
    for o in outcomes:
        loud = o.get("outcome") in ("error", "beyond_calendar_horizon")
        (logger.warning if loud else logger.info)(
            "[on_completion] %s completed+delivered for %s (execution %s) -> "
            "%s: %s run %s (%s) %s", upstream.get("feed_name"), bd,
            upstream.get("execution_id"), o.get("feed_name"), o.get("outcome"),
            o.get("run_id"), o.get("action_decision") or "-", o.get("reason") or "")
    if consumer is not None and not consumer.get("present"):
        logger.warning("[on_completion] %d downstream run(s) of %s are PENDING "
                       "and %s", len(created), upstream.get("feed_name"),
                       consumer.get("detail") or "no queue consumer was found")
    _record(db, upstream=upstream, business_date=bd,
            event_type=EVENT_TRIGGERED if created else EVENT_NOT_TRIGGERED,
            downstream_names=names,
            payload={"reason": (None if created else
                                "no downstream run was created -- see each "
                                "feed's outcome"),
                     "delivery_verdict": _DELIVERED,
                     "downstream": outcomes, "queue_consumer": consumer})
    return {"triggered": bool(created), "reason": None, "business_date": bd,
            "downstream": outcomes, "queue_consumer": consumer}


def _queue_consumer(db, created: List[Mapping[str, Any]]) -> Optional[dict]:
    """The producer's question (``core.feed.health.probe_queue_consumer``):
    a pending row nothing will claim is a run that silently never happens,
    so the record says whether a consumer exists.  Asked only when a
    PENDING RUN row was created (a SKIP row needs no consumer)."""
    if not any(o.get("status") == "pending" for o in created):
        return None
    try:
        from core.feed.health import probe_queue_consumer
        p = probe_queue_consumer(None, db=db)
        return {"present": bool(p.present), "determined": bool(p.determined),
                "detail": p.reason or None, "source": p.source or None}
    except Exception as exc:   # noqa: BLE001 -- could-not-tell is said
        return {"present": False, "determined": False,
                "detail": f"could not determine: {exc}", "source": "probe_error"}
