"""The four builtin delivery adapters — moved out of feed_engine
(2026-09-03) so the engine carries no step wiring at import time.

The delivery IMPLEMENTATIONS (``_deliver_local`` / ``_deliver_s3`` /
``_sftp_upload`` / ``_deliver_oracle``) remain in feed_engine — they are
the engine's delivery plumbing (atomic rename, S3 in-band verification,
SFTP host-key pinning, Oracle row accounting) and their receipt
out-param contract is unchanged.  These classes are the step FACES:
one per destination type, registered from the static builtin list in
``core.feed.steps`` (never filesystem-discovered — a mispointed
steps_dir cannot take ``s3`` or ``local`` away).

Imports are late-binding — resolved at deliver time — so importing this
module never imports the engine, and tests that patch the feed_engine
functions still intercept."""
from __future__ import annotations

from core.feed.delivery_targets import DeliveryReceipt, DeliveryTarget


class LocalDeliveryTarget(DeliveryTarget):
    name = "local"

    def deliver(self, local_path, filename, dest_config):
        from core import feed_engine as _fe
        raw: dict = {}
        uri = _fe._deliver_local(local_path, filename, dest_config,
                                 _receipt=raw)
        return DeliveryReceipt.from_outparam(uri, self.name, raw)


class S3DeliveryTarget(DeliveryTarget):
    name = "s3"

    def deliver(self, local_path, filename, dest_config):
        from core import feed_engine as _fe
        raw: dict = {}
        uri = _fe._deliver_s3(local_path, filename, dest_config,
                              _receipt=raw)
        return DeliveryReceipt.from_outparam(uri, self.name, raw)


class SftpDeliveryTarget(DeliveryTarget):
    name = "sftp"

    def deliver(self, local_path, filename, dest_config):
        from core import feed_engine as _fe
        raw: dict = {}
        uri = _fe._sftp_upload(local_path, dest_config, filename,
                               _receipt=raw)
        return DeliveryReceipt.from_outparam(uri, self.name, raw)


class OracleDeliveryTarget(DeliveryTarget):
    name = "oracle"

    def deliver(self, local_path, filename, dest_config):
        from core import feed_engine as _fe
        raw: dict = {}
        uri = _fe._deliver_oracle(local_path, filename, dest_config,
                                  _receipt=raw)
        return DeliveryReceipt.from_outparam(uri, self.name, raw)
