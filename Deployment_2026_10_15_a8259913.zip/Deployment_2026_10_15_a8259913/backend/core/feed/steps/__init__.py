"""Feed STEPS — one discovery + registry + boot report for every role.

2026-09-02.  The unit is a **step**; the slot it fills is a **role**.
(Vocabulary borrowed from the OG ETL's own ``step_mapping`` so the
operator's team does not translate.  Rejected alternatives, with
reasons: *operator* means the human in every incident log in this repo;
*connector* is already a QueryStudio connection type; *task* collides
with SOD tasks; *skill* names instructions in a reasoning loop — we take
the discovery property, not the word.)  The config value an author types
is UNCHANGED: ``source_type: saved_query``, ``destination_type: sftp`` —
the step's ``name`` IS that value.

This module generalises the MECHANISM, not the base class: registry,
discovery, three-outcome resolution and the boot report are shared;
each role keeps its own typed ABC (``DeliveryTarget.deliver`` still
returns a receipt that must state verification; ``SourceResolver``
returns a parquet path).  There is deliberately no universal
``execute(ctx)``.

**Exactly two roles — and the rule for stopping.**  A point becomes a
role when a NEW MEMBER IS NEW I/O and the engine dispatches by name at
a fixed slot.  Config vocabularies stay data (kafka resolver rules,
control-file formats — "a config change, never a deployment" is the
feature); semantic vocabularies stay closed (schedule kinds, partition
shapes, completeness claims — if a plugin could define "complete", an
extension could weaken the one mechanism whose job is to distrust
extensions; daemon ownership likewise).  A new member there changes
what the engine MEANS, so it is a code review, not a dropped file.

**Three outcomes, never two.**  The OG ETL shipped the two-outcome bug
this designs out (``ETL/configs/step_mapping.yaml`` documents it): an
ImportError was caught, WARNed and SKIPPED, so a missing module
surfaced at dispatch as "Unsupported step name" — pointing the operator
at the DB row instead of the missing file.  Here the FILENAME carries
identity (``<role>__<name>.py``), so a step that fails to import is
still refusable BY NAME: the registry keeps a tombstone
``(role, name) -> LoadFailure(path, reason)`` and resolution is
  * registered   → the step;
  * tombstoned   → :class:`StepLoadFailed` naming the FILE PATH and reason;
  * unknown      → :class:`UnknownStep` listing what IS registered.
Two exception TYPES, never one — the findings lead to opposite
investigations.

**Builtins are a static list, never filesystem-discovered** — a
mispointed root cannot take ``s3`` or ``local`` away.  Discovery is a
deploy knob (``feed_generation.steps_dir`` config key / the
``QS_FEED_STEPS_DIR`` env var; DEFAULT EMPTY = OFF) and never shadows a
builtin — a shadow attempt is refused by name in the boot report.

**Foreign-but-present roots** (the ``$ETL_CONFIG_DIR`` incident class:
the dangerous root is not the missing one, which fails loudly, but
another environment's, which runs a foreign vocabulary and reports
success): a root must carry a marker file ``qs-steps-root.json``
declaring ``{"platform": "querystudio-feed-steps", "environment":
"<env>"}``.  Marker absent, wrong platform, or an environment that
CONTRADICTS this deployment's declared environment → the WHOLE root is
refused at ERROR naming both values and the absolute path, and boot
continues on builtins.  Environment undeclared on either side → loaded
with a WARNING.  The absolute resolved path is always logged.

**Trust — stated, not faked.**  A discovered step is in-process Python:
RCE-equivalent BY DESIGN.  There is no AST scanning or import hook here
(this repo already proved a keyword test that cannot see string
literals is not a parser, and a scanner would only be that at scale).
The security boundary is the steps-dir ACL plus the knob's default-off;
the production stance is that steps ship in the image or via an
explicit package allow-list.

Migration state (stated plainly): BOTH roles are fully on discovery.
  * delivery: the four adapters (local/s3/sftp/oracle) are builtins in
    ``delivery_builtin.py``; the import-time ``register_target`` loop
    and the adapter classes feed_engine carried are deleted.
  * source: ALL SIX kinds are builtin steps — the four SQL kinds'
    branch bodies moved VERBATIM to ``core/feed/sources/sql_branches.py``
    (2026-09-03, golden-equivalence pinned by
    ``tests/test_feed_sql_sources_golden_2026_09_03.py``) alongside
    ``api`` and ``landed_file``; the engine's if/elif chain is gone and
    ``_run_single_source_native_query`` is pure registry dispatch.
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: The step contract this runtime implements.  A discovered step
#: declaring anything else is tombstoned — built against another
#: contract, it must refuse rather than half-work.
CONTRACT = "qs-step/1"

ROLES = ("source", "delivery")

#: Names the ENGINE serves outside the registry.  EMPTY since 2026-09-03:
#: the four SQL kinds migrated to builtin steps (sql_branches.py), so
#: every source kind now resolves through the registry; the builtin
#: registrations themselves are what a dropped file cannot shadow.  The
#: mechanism stays so a future engine-only name can be fenced in one line.
RESERVED_ENGINE_NAMES: Dict[str, Tuple[str, ...]] = {}

_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_FILE_RE = re.compile(r"^(?P<role>[a-z][a-z0-9_]*)__(?P<name>[a-z][a-z0-9_]*)\.py$")

MARKER_FILENAME = "qs-steps-root.json"
MARKER_PLATFORM = "querystudio-feed-steps"

CONFIG_SECTION = "feed_generation"
CONFIG_KEY_ROOT = "steps_dir"
CONFIG_KEY_ENV = "environment"
ENV_KEY_ROOT = "QS_FEED_STEPS_DIR"
ENV_KEY_ENV = "QS_ENVIRONMENT"


class UnknownStep(ValueError):
    """No step — builtin or discovered — answers to (role, name).  The
    message lists what IS registered.  A ``ValueError`` so dispatchers
    treat it as a deterministic configuration error."""


class StepLoadFailed(RuntimeError):
    """A step with this name EXISTS on disk and FAILED to load.  The
    message names the file path and the reason — the opposite finding
    from :class:`UnknownStep`, and deliberately a different type."""


@dataclass(frozen=True)
class LoadFailure:
    path: str
    reason: str


class FeedStep:
    """Base of every step, of every role.  Three class attributes ONLY —
    the typed work surface belongs to each role's own ABC
    (``SourceResolver.resolve``, ``DeliveryTarget.deliver``)."""
    role: str = ""
    name: str = ""
    contract: str = CONTRACT


# ── Registry state ──────────────────────────────────────────────────────────

_lock = threading.RLock()
_registry: Dict[Tuple[str, str], FeedStep] = {}
_origins: Dict[Tuple[str, str], str] = {}      # builtin | discovered | runtime
_tombstones: Dict[Tuple[str, str], LoadFailure] = {}
_refusal_lines: List[str] = []                  # boot-report only
_shadow_attempts = 0
_booted = False


def register_step(step: FeedStep, origin: str = "runtime") -> None:
    """Register one step under (role, name).  Runtime registration (an
    explicit code call — tests, deployment overrides) may replace;
    that is the documented ``register_target`` behaviour and is NOT the
    same thing as a dropped file shadowing a builtin, which discovery
    refuses."""
    role = (getattr(step, "role", "") or "").strip().lower()
    name = (getattr(step, "name", "") or "").strip().lower()
    if role not in ROLES:
        raise ValueError(
            f"step role must be one of {ROLES}, got {role!r} "
            f"(step {type(step).__name__})")
    if not _NAME_RE.match(name):
        raise ValueError(
            f"step name {getattr(step, 'name', None)!r} is not valid "
            f"([a-z][a-z0-9_]*, max 64)")
    if getattr(step, "contract", None) != CONTRACT:
        raise ValueError(
            f"step {role}/{name} declares contract "
            f"{getattr(step, 'contract', None)!r}; this runtime "
            f"implements {CONTRACT!r}")
    if name in RESERVED_ENGINE_NAMES.get(role, ()):
        raise ValueError(
            f"step name '{name}' (role {role}) is reserved for the "
            f"engine's built-in branch and cannot be registered")
    with _lock:
        _registry[(role, name)] = step
        _origins[(role, name)] = origin
        _tombstones.pop((role, name), None)


def registered_names(role: str) -> List[str]:
    ensure_booted()
    with _lock:
        return sorted(n for (r, n) in _registry if r == role)


def remove_step(role: str, name: str) -> Optional[FeedStep]:
    """Remove one registered step (test cleanup / admin).  Returns the
    removed step or None.  Does NOT touch tombstones — a failed load
    stays visible until the file is fixed or gone and rediscovery runs."""
    key = ((role or "").strip().lower(), (name or "").strip().lower())
    with _lock:
        _origins.pop(key, None)
        return _registry.pop(key, None)


def get_step(role: str, name: str) -> FeedStep:
    """THE resolution — three outcomes, never two."""
    ensure_booted()
    key = ((role or "").strip().lower(), (name or "").strip().lower())
    with _lock:
        step = _registry.get(key)
        tomb = _tombstones.get(key)
        names = sorted(n for (r, n) in _registry if r == key[0])
    if step is not None:
        return step
    if tomb is not None:
        raise StepLoadFailed(
            f"step {key[0]}/{key[1]} EXISTS at {tomb.path} but FAILED TO "
            f"LOAD: {tomb.reason}.  This is not a missing step — fix the "
            f"file (or remove it) and reload.")
    reserved = RESERVED_ENGINE_NAMES.get(key[0], ())
    extra = (f"  Engine-builtin {key[0]} branches (not steps): "
             f"{list(reserved)}." if reserved else "")
    raise UnknownStep(
        f"no {key[0]} step named '{key[1]}'.  Registered {key[0]} steps: "
        f"{names}.{extra}")


# ── Builtins (static list — never filesystem-discovered) ───────────────────

def _register_builtins() -> List[str]:
    """The static builtin list.  Lazy imports so this package stays
    import-light and cycle-free (feed_engine imports delivery_targets,
    which imports this module; the adapters are only pulled when boot
    actually happens, which is at first dispatch)."""
    lines: List[str] = []
    # Delivery role — the four adapter faces (delivery_builtin.py); the
    # deliver implementations stay in feed_engine, late-bound.
    try:
        from core.feed.archive import ArchiveDeliveryTarget
        from core.feed.steps.delivery_builtin import (
            LocalDeliveryTarget, OracleDeliveryTarget, S3DeliveryTarget,
            SftpDeliveryTarget,
        )
        # ``archive`` is a BUILTIN, not a discovered step (wired
        # 2026-09-03): it was written with its registration left as an
        # anchor, so the class existed and no chain could name it — the
        # built-but-unreachable class this registry exists to end.  A
        # builtin also means a mispointed steps_dir cannot take the
        # archive lifecycle stage away.
        for _cls in (LocalDeliveryTarget, S3DeliveryTarget,
                     SftpDeliveryTarget, OracleDeliveryTarget,
                     ArchiveDeliveryTarget):
            register_step(_cls(), origin="builtin")
        lines.append("builtin delivery: archive, local, oracle, s3, sftp")
    except Exception as exc:  # noqa: BLE001 — builtins must fail AUDIBLY, not fatally
        lines.append(f"builtin delivery FAILED to register: "
                     f"{type(exc).__name__}: {exc}")
        logger.error("[feed-steps] builtin delivery registration failed: "
                     "%s", exc, exc_info=True)
    # Source role — the four SQL kinds (bodies moved VERBATIM from the
    # engine's former branch chain; golden-equivalence pinned) plus the
    # two non-SQL sources.
    try:
        from core.feed.sources.api import ApiSourceStep
        from core.feed.sources.landed_file import LandedFileSourceStep
        from core.feed.sources.sql_branches import (
            PublishedViewSourceStep, RawSqlSourceStep,
            SavedQuerySourceStep, SqlFileSourceStep,
        )
        for _scls in (SavedQuerySourceStep, PublishedViewSourceStep,
                      RawSqlSourceStep, SqlFileSourceStep,
                      ApiSourceStep, LandedFileSourceStep):
            register_step(_scls(), origin="builtin")
        lines.append(
            "builtin source: api, landed_file, published_view, raw_sql, "
            "saved_query, sql_file")
    except Exception as exc:  # noqa: BLE001
        lines.append(f"builtin source FAILED to register: "
                     f"{type(exc).__name__}: {exc}")
        logger.error("[feed-steps] builtin source registration failed: "
                     "%s", exc, exc_info=True)
    return lines


# ── Discovery (deploy knob, marker-guarded, fail-isolated) ─────────────────

def _cfg_get(section: str, key: str, fallback: str = "") -> str:
    try:
        from core.config import get as _get
        return str(_get(section, key, fallback) or fallback or "").strip()
    except Exception:
        return fallback


def configured_root() -> Optional[str]:
    val = _cfg_get(CONFIG_SECTION, CONFIG_KEY_ROOT, "")
    if not val:
        val = str(os.environ.get(ENV_KEY_ROOT, "") or "").strip()
    return val or None


def platform_environment() -> str:
    """This deployment's declared environment ('' = undeclared).

    2026-09-07 — falls back to ``core.config.deploy_environment``, THE
    resolver for this fact.  Both keys read here (``feed_generation.
    environment`` and ``$QS_ENVIRONMENT``) were a private FOURTH spelling
    of the deployment's environment and neither was declared, so this
    returned "" everywhere and ``_check_marker``'s foreign-root guard --
    which refuses another environment's step vocabulary -- was disarmed by
    construction on every deployment.  The danger it exists for is not a
    MISSING root (that fails loudly) but a FOREIGN-BUT-PRESENT one.

    The two local spellings still win, so a site that set either keeps its
    value; the fallback only ARMS a guard that was previously inert.
    """
    val = _cfg_get(CONFIG_SECTION, CONFIG_KEY_ENV, "")
    if not val:
        val = str(os.environ.get(ENV_KEY_ENV, "") or "").strip()
    if not val:
        try:
            from core.config import deploy_environment as _de
            val = _de()
        except Exception:                          # noqa: BLE001
            val = ""
    return str(val or "")


def _check_marker(root: Path, lines: List[str]) -> bool:
    """Marker gate for a discovery root.  True = root may load."""
    marker = root / MARKER_FILENAME
    if not marker.is_file():
        lines.append(f"root REFUSED (whole root): {root} has no "
                     f"{MARKER_FILENAME} marker — cannot tell whose "
                     f"steps these are")
        logger.error(
            "[feed-steps] discovery root %s REFUSED: no %s marker — a "
            "root that cannot say whose it is might be another "
            "environment's; boot continues on builtins",
            root, MARKER_FILENAME)
        return False
    try:
        data = json.loads(marker.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError(f"marker is {type(data).__name__}, not object")
    except (OSError, ValueError) as exc:
        lines.append(f"root REFUSED (whole root): {root} marker "
                     f"unreadable: {exc}")
        logger.error("[feed-steps] discovery root %s REFUSED: marker "
                     "unreadable: %s", root, exc)
        return False
    plat = str(data.get("platform") or "")
    if plat != MARKER_PLATFORM:
        lines.append(f"root REFUSED (whole root): {root} marker platform "
                     f"is {plat!r}, expected {MARKER_PLATFORM!r}")
        logger.error(
            "[feed-steps] discovery root %s REFUSED: marker platform %r "
            "!= %r — this is not a feed-steps root", root, plat,
            MARKER_PLATFORM)
        return False
    root_env = str(data.get("environment") or "").strip()
    our_env = platform_environment()
    if root_env and our_env and root_env.lower() != our_env.lower():
        lines.append(
            f"root REFUSED (whole root): {root} declares environment "
            f"{root_env!r} but this deployment is {our_env!r}")
        logger.error(
            "[feed-steps] discovery root %s REFUSED: marker environment "
            "%r CONTRADICTS this deployment's %r — running another "
            "environment's vocabulary reports success right up until it "
            "doesn't; boot continues on builtins",
            root, root_env, our_env)
        return False
    if not root_env or not our_env:
        logger.warning(
            "[feed-steps] discovery root %s: environment undeclared on "
            "%s side (root=%r deployment=%r) — loading, but declare "
            "both to arm the foreign-root guard",
            root, "the root's" if not root_env else "this deployment's",
            root_env, our_env)
        lines.append(f"root marker: {root} environment undeclared "
                     f"(root={root_env!r} deployment={our_env!r}) — "
                     f"loaded with WARNING")
    else:
        lines.append(f"root marker: {root} ok (environment={root_env})")
    return True


def _root_is_usable(root: Path, lines: List[str]) -> bool:
    """Whether *root* can be walked at all: readable, present, marker-matched.

    Every refusal here is whole-root — boot continues on builtins.
    """
    try:
        exists = root.is_dir()
    except OSError as exc:
        lines.append(f"root REFUSED (whole root): unreadable: {exc}")
        logger.error("[feed-steps] discovery root %s unreadable: %s",
                     root, exc)
        return False
    if not exists:
        lines.append("root REFUSED (whole root): does not exist — the "
                     "knob points at nothing")
        logger.error("[feed-steps] discovery root %s does not exist — "
                     "the steps_dir knob points at nothing; boot "
                     "continues on builtins", root)
        return False
    return _check_marker(root, lines)


def _admit_step_file(f: Path, lines: List[str]) -> Optional[Tuple[str, str]]:
    """Decide whether *f* may be loaded; returns its (role, name) or None.

    Non-``.py`` entries are skipped silently.  The three REFUSALS are
    recorded: a filename carrying no ``<role>__<name>`` identity, an
    unknown role, and a shadow attempt on a builtin/reserved step.
    """
    global _shadow_attempts
    if not f.is_file() or not f.name.endswith(".py"):
        return None
    m = _FILE_RE.match(f.name)
    if not m:
        lines.append(f"REFUSED {f.name}: filename must be "
                     f"<role>__<name>.py")
        logger.error("[feed-steps] %s REFUSED: filename does not "
                     "carry a <role>__<name> identity", f)
        return None
    role, name = m.group("role"), m.group("name")
    if role not in ROLES:
        lines.append(f"REFUSED {f.name}: unknown role '{role}' "
                     f"(roles: {list(ROLES)})")
        logger.error("[feed-steps] %s REFUSED: unknown role %r",
                     f, role)
        return None
    key = (role, name)
    with _lock:
        already = key in _registry or \
            name in RESERVED_ENGINE_NAMES.get(role, ())
    if already:
        _shadow_attempts += 1
        lines.append(f"REFUSED {f.name}: shadow attempt on "
                     f"builtin/reserved {role}/{name}")
        logger.error(
            "[feed-steps] %s REFUSED: '%s' would shadow the builtin/"
            "reserved %s step — a dropped file cannot take a builtin "
            "away", f, name, role)
        return None
    return role, name


def _discover_root(root_raw: str, lines: List[str]) -> None:
    root = Path(root_raw).expanduser().resolve()
    lines.append(f"root: {root}")
    if not _root_is_usable(root, lines):
        return
    for f in sorted(root.iterdir()):
        admitted = _admit_step_file(f, lines)
        if admitted is None:
            continue
        role, name = admitted
        _load_step_file(f, role, name, lines)


def _import_step_module(path: Path, role: str, name: str) -> Tuple[Any, Optional[str]]:
    """Import *path* under its own module name; returns (module, refusal).

    Fail-isolated by design: a step file that blows up on import must
    tombstone itself and leave every other step loadable.
    """
    import importlib.util as _ilu
    spec = _ilu.spec_from_file_location(
        f"qs_feed_step_{role}__{name}", str(path))
    if spec is None or spec.loader is None:
        return None, "import spec could not be built"
    module = _ilu.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except BaseException as exc:  # noqa: BLE001 — fail-isolated by design
        return None, f"import raised {type(exc).__name__}: {exc}"
    return module, None


def _instantiate_step(module: Any) -> Tuple[Any, Optional[str]]:
    """Call the module's ``create_step()`` factory; returns (step, refusal)."""
    factory = getattr(module, "create_step", None)
    if not callable(factory):
        return None, "module defines no create_step()"
    try:
        return factory(), None
    except BaseException as exc:  # noqa: BLE001
        return None, f"create_step() raised {type(exc).__name__}: {exc}"


def _step_refusal_reason(step: Any, role: str, name: str) -> Optional[str]:
    """Why *step* may not be registered as *role*/*name*, or None if it may.

    The filename is the identity, so a step declaring a different one is an
    ambiguity we refuse rather than resolve; and a step built against
    another contract must refuse rather than half-work.
    """
    if not isinstance(step, FeedStep):
        return (f"create_step() returned {type(step).__name__}, "
                f"not a FeedStep")
    srole = (getattr(step, "role", "") or "").strip().lower()
    sname = (getattr(step, "name", "") or "").strip().lower()
    if (srole, sname) != (role, name):
        return (f"step declares {srole}/{sname} but the filename "
                f"declares {role}/{name} — the filename is the "
                f"identity; refusing the ambiguity")
    if getattr(step, "contract", None) != CONTRACT:
        return (f"declares contract "
                f"{getattr(step, 'contract', None)!r}; this runtime "
                f"implements {CONTRACT!r} — a step built against "
                f"another contract must refuse rather than half-work")
    return None


def _load_step_file(path: Path, role: str, name: str,
                    lines: List[str]) -> None:
    """Import ONE step file.  Failure → TOMBSTONE, by name, with path
    and reason — the three-outcome guarantee depends on this write."""
    key = (role, name)

    def _tomb(reason: str) -> None:
        with _lock:
            _tombstones[key] = LoadFailure(path=str(path), reason=reason)
        lines.append(f"REFUSED {path.name}: {reason} (tombstoned — "
                     f"dispatch will name this file)")
        logger.error("[feed-steps] step %s/%s at %s REFUSED: %s",
                     role, name, path, reason)

    try:
        module, reason = _import_step_module(path, role, name)
        if reason is not None:
            _tomb(reason)
            return
        step, reason = _instantiate_step(module)
        if reason is not None:
            _tomb(reason)
            return
        reason = _step_refusal_reason(step, role, name)
        if reason is not None:
            _tomb(reason)
            return
        register_step(step, origin="discovered")
        lines.append(f"discovered {role}/{name} from {path} "
                     f"contract={CONTRACT}")
        logger.info("[feed-steps] discovered step %s/%s from %s",
                    role, name, path)
    except BaseException as exc:  # noqa: BLE001 — outermost isolation
        _tomb(f"unexpected discovery failure "
              f"{type(exc).__name__}: {exc}")


# ── Boot ────────────────────────────────────────────────────────────────────

def ensure_booted() -> None:
    global _booted
    with _lock:
        if _booted:
            return
        _booted = True
    _boot()


def _boot() -> None:
    global _refusal_lines
    lines = _register_builtins()
    root = configured_root()
    if root:
        _discover_root(root, lines)
    else:
        lines.append("root: <none configured> (feed_generation."
                     f"{CONFIG_KEY_ROOT} / {ENV_KEY_ROOT} unset — "
                     "discovery off, builtins only)")
    with _lock:
        _refusal_lines = [ln for ln in lines if "REFUSED" in ln]
        n_reg = len(_registry)
        n_disc = sum(1 for v in _origins.values() if v == "discovered")
        n_tomb = len(_tombstones)
        n_ref = len(_refusal_lines)
    lines.append(
        f"tally: registered={n_reg} discovered={n_disc} "
        f"refused={n_ref} tombstoned={n_tomb} "
        f"shadow_attempts={_shadow_attempts}")
    # ONE grep-able block.
    logger.info("[feed-steps] boot report\n%s",
                "\n".join(f"[feed-steps]   {ln}" for ln in lines))


def reset_for_tests() -> None:
    """Test seam + admin reload: clear the registry and re-discover on
    next use (the knob is re-read, so tests point the CONFIG KNOB rather
    than monkeypatching registry internals)."""
    global _booted, _shadow_attempts
    with _lock:
        _registry.clear()
        _origins.clear()
        _tombstones.clear()
        _refusal_lines.clear()
        _shadow_attempts = 0
        _booted = False
