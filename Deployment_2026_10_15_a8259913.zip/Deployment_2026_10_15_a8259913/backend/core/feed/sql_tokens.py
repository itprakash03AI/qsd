"""The OG-style ``{TOKEN}`` vocabulary in feed SQL -- ONE renderer for every
lane (2026-10-10, the owner's ``test_query_001.json``).

The owner's queries are written the way the OG Output Gateway wrote them::

    WHERE BUSINESS_CLOSE_DATE = CAST('{BUSINESSDATE}' AS DATE)
      AND CODE = '{SYSTEM_ENTITY}' AND BUSINESSEVENT = '{EventCode}'

Single braces, the author's own quotes around the token, a date token the
calendar resolves and PARAMETER tokens the feed itself declares (its
``query_params``: a template member carries ``SYSTEM_ENTITY`` and
``EventCode``).  QueryStudio's own vocabulary is ``{{name}}``
(``core/feed/param_resolver.py``); this module adds the single-brace
spelling WITHOUT touching the ``{{}}`` chokepoint every report shares.

Rules -- the same on the native lane, the union pushdown and the
Spark/Airflow plan, because every one of them calls :func:`render_og_tokens`
after the ``{{}}`` pass:

* ``{BUSINESSDATE}`` (and ``{BUSINESS_DATE}``, ``{COB}``) is the run's
  business date, ISO ``YYYY-MM-DD`` -- the value the calendar resolver
  already put under ``business_date``.  ``{RUNDATE}`` / ``{RUN_DATE}`` is
  the run date.  A format suffix is accepted the way the filename renderer
  spells it: ``{BUSINESSDATE:YYYYMMDD}``.
* ``{NAME}`` for every DECLARED parameter -- a scalar key of the feed's
  ``query_params`` (the resolver merges them into ``params``).  Nothing
  else is substituted: ``{foo}`` with no declaration is left as written
  and WARNED about once per render, because the SQL may legitimately hold
  braces of its own.  The exception is a token that LOOKS declared -- a
  date token or a parameter name -- with no value: that REFUSES
  (``UnresolvedToken``), never ships as literal text matching nothing.
* A value is pasted INSIDE the author's quotes, so it is validated, never
  escaped: a quote, a backslash, a semicolon, a comment marker or a
  control character in the value REFUSES (``UnsafeTokenValue``).  Doubling
  the quote would be "safe" and still wrong -- the author asked for an
  entity code, not a sentence.  :func:`validate_token_value` is the ONE
  rule; the feed-template matrix applies it at authoring, this module at
  run time.
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime
from typing import Any, Dict, Iterable, Mapping, Optional

logger = logging.getLogger(__name__)

#: ``{NAME}`` / ``{NAME:FMT}`` -- never ``{{`` (that is the other
#: vocabulary) and never a brace with spaces or punctuation inside (a JSON
#: literal, a regex in the SQL).
_OG_TOKEN_RE = re.compile(
    r"(?<!\{)\{([A-Za-z_][A-Za-z0-9_]*)(?::([A-Za-z0-9_-]+))?\}(?!\})")

#: Date tokens -> the resolver key holding the ISO value.
DATE_TOKENS: Dict[str, str] = {
    "BUSINESSDATE": "business_date",
    "BUSINESS_DATE": "business_date",
    "COB": "business_date",
    "RUNDATE": "run_date",
    "RUN_DATE": "run_date",
    "PREV_BUSINESS_DAY": "prev_business_day",
    "PREV_EOM": "prev_eom",
    "MONTH_END": "month_end",
}

#: What a parameter VALUE may look like once pasted inside the author's
#: quotes.  Letters, digits, and the punctuation entity / event codes carry
#: (``_`` ``-`` ``.`` ``/`` space ``:`` ``@`` ``#`` ``+`` ``&``).
_VALUE_OK_RE = re.compile(r"^[A-Za-z0-9 _\-./:@#+&]*$")
MAX_VALUE_LEN = 200


class UnsafeTokenValue(ValueError):
    """A parameter value that cannot be pasted inside a SQL literal."""


class UnresolvedToken(ValueError):
    """A declared token with no value at render time."""


class BindingRefused(ValueError):
    """A token BINDING that cannot be applied: malformed, naming a token
    nothing resolves, or -- at render time -- matching NO literal predicate
    in the SQL that runs (the saved query was edited since it was bound).
    A correctness gate: the run is refused, never run with the literal."""


#: The literal-binding vocabulary (2026-10-11).  A saved query built in the
#: query builder carries LITERAL filter values (``BUSINESS_CLOSE_DATE = DATE
#: '2025-06-30'``, ``CODE = 'SAP-2504'``).  A feed -- above all a TEMPLATE
#: of 4,000 members -- needs them as ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``.
#: A binding is stored on the FEED (``feed_configs.token_bindings``) as
#: ``{"side": "primary"|"secondary", "column": "CODE", "literal": "SAP-2504",
#: "token": "SYSTEM_ENTITY", "format": null}`` and applied here, by the SAME
#: renderer every lane calls, BEFORE the ``{TOKEN}`` pass: every predicate
#: ``<column> <op> <literal>`` on that side whose column (last identifier
#: segment, case-insensitive) and literal text match has its literal
#: replaced by ``{TOKEN}`` (``{TOKEN:FMT}`` for a date token with a format),
#: INSIDE the author's own quotes -- so the rendered value is validated,
#: never escaped, exactly as a hand-written token is.
BINDING_SIDES = ("primary", "secondary")
_BINDING_OPERATORS = {"EQ", "NEQ", "GT", "GTE", "LT", "LTE"}
_IDENT_TOKENS = {"VAR", "IDENTIFIER"}
_DATE_KEYWORDS = {"DATE", "TIMESTAMP", "DATETIME", "TIMESTAMPTZ", "TIMESTAMPLTZ",
                  "TIMESTAMPNTZ"}
_DATE_FUNCS = {"TO_DATE", "TO_TIMESTAMP", "DATE", "TIMESTAMP", "STR_TO_DATE",
               "PARSE_DATE", "TO_CHAR"}
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2}(\.\d+)?)?)?$")
_TOKEN_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _binding_side(side: Any) -> str:
    """``"secondary"`` is the second side; anything else (``""``,
    ``"single"``, ``"primary"``, None) is the primary."""
    return "secondary" if str(side or "").strip().lower() == "secondary" else "primary"


def literal_predicates(sql: Optional[str]) -> list:
    """Every ``<column> <op> <literal>`` predicate in ``sql``, read from
    sqlglot's TOKEN stream (positions, not a regenerated tree -- the
    author's text is never reformatted).

    Recognised right-hand sides: ``'text'``, ``42``, ``DATE 'x'`` /
    ``TIMESTAMP 'x'``, ``CAST('x' AS <type>)`` and ``FUNC('x', ...)`` (the
    FIRST literal argument).  The left-hand side is an identifier chain
    (``t.COL``, ``"Col"``) or one wrapped in a function (``CAST(COL AS
    DATE)``, ``TRUNC(COL)``).  Each entry::

        {"column": "CODE", "qualified": "FACT_TETB_EXT.CODE", "operator": "=",
         "literal": "SAP-2504", "kind": "string"|"number"|"date",
         "wrapper": None|"DATE"|"CAST"|"TO_DATE", "spans": [(start, end)],
         "occurrences": 1}

    Entries are merged by (column lower, literal): ``spans`` holds every
    occurrence, which is what a binding replaces.  An unparseable statement
    yields ``[]`` -- "cannot read" is reported by the caller, never as
    "has none".
    """
    if not sql or not str(sql).strip():
        return []
    try:
        from sqlglot.tokens import Tokenizer
        toks = Tokenizer().tokenize(str(sql))
    except Exception as exc:  # noqa: BLE001 -- an unreadable statement
        logger.info("[sql_tokens] literal_predicates: tokenizer refused the SQL (%s)", exc)
        return []
    n = len(toks)
    text = str(sql)

    def _tt(i: int) -> str:
        return toks[i].token_type.name if 0 <= i < n else ""

    def _column_before(op_i: int):
        """The identifier chain ending just before ``op_i`` -> (column,
        qualified, lhs_wrapper, start_index) or None."""
        j = op_i - 1
        wrapper = None
        if _tt(j) == "R_PAREN":
            depth = 0
            k = j
            while k >= 0:
                if _tt(k) == "R_PAREN":
                    depth += 1
                elif _tt(k) == "L_PAREN":
                    depth -= 1
                    if depth == 0:
                        break
                k -= 1
            if k <= 0 or _tt(k - 1) not in _IDENT_TOKENS:
                return None
            wrapper = toks[k - 1].text.upper()
            # first identifier chain inside the parens
            m = k + 1
            if _tt(m) not in _IDENT_TOKENS:
                return None
            parts = [toks[m].text]
            while _tt(m + 1) == "DOT" and _tt(m + 2) in _IDENT_TOKENS:
                parts.append(toks[m + 2].text)
                m += 2
            return parts[-1], ".".join(parts), wrapper, k - 1
        if _tt(j) not in _IDENT_TOKENS:
            return None
        parts = [toks[j].text]
        while _tt(j - 1) == "DOT" and _tt(j - 2) in _IDENT_TOKENS:
            parts.insert(0, toks[j - 2].text)
            j -= 2
        # a chain preceded by DOT-less identifier is a column; a preceding
        # keyword like AND/WHERE/( is what we expect
        return parts[-1], ".".join(parts), None, j

    def _literal_after(op_i: int):
        """-> (literal_text, kind, wrapper, (start, end)) or None."""
        i = op_i + 1
        t = _tt(i)
        if t == "STRING":
            tok = toks[i]
            kind = "date" if _ISO_DATE_RE.match(tok.text) else "string"
            return tok.text, kind, None, (tok.start, tok.end)
        if t == "NUMBER":
            tok = toks[i]
            return tok.text, "number", None, (tok.start, tok.end)
        if t in _DATE_KEYWORDS and _tt(i + 1) == "STRING":
            tok = toks[i + 1]
            return tok.text, "date", toks[i].text.upper(), (tok.start, tok.end)
        if t in _IDENT_TOKENS and _tt(i + 1) == "L_PAREN":
            func = toks[i].text.upper()
            # first literal at depth 1
            depth = 0
            k = i + 1
            while k < n:
                tk = _tt(k)
                if tk == "L_PAREN":
                    depth += 1
                elif tk == "R_PAREN":
                    depth -= 1
                    if depth == 0:
                        return None
                elif depth == 1 and tk in ("STRING", "NUMBER"):
                    tok = toks[k]
                    kind = "number" if tk == "NUMBER" else (
                        "date" if _ISO_DATE_RE.match(tok.text) else "string")
                    if func == "CAST":
                        # CAST('x' AS DATE) -> the type after AS
                        m = k + 1
                        if _tt(m) in ("ALIAS", "AS") and _tt(m + 1) in _DATE_KEYWORDS:
                            kind = "date"
                    elif func in _DATE_FUNCS:
                        kind = "date"
                    return tok.text, kind, func, (tok.start, tok.end)
                elif depth == 1 and tk not in ("STRING", "NUMBER"):
                    # a column or expression as the first argument: no literal
                    if tk not in ("L_PAREN",):
                        return None
                k += 1
            return None
        return None

    found: Dict[tuple, dict] = {}
    op_text = {"EQ": "=", "NEQ": "<>", "GT": ">", "GTE": ">=", "LT": "<", "LTE": "<="}
    for i in range(n):
        tt = _tt(i)
        if tt not in _BINDING_OPERATORS:
            continue
        lhs = _column_before(i)
        rhs = _literal_after(i)
        if lhs is None or rhs is None:
            continue
        column, qualified, lhs_wrapper, lhs_start = lhs
        literal, kind, wrapper, span = rhs
        key = (column.lower(), literal)
        entry = found.get(key)
        if entry is None:
            entry = {
                "column": column, "qualified": qualified,
                "operator": op_text.get(tt, toks[i].text),
                "literal": literal, "kind": kind,
                "wrapper": wrapper or lhs_wrapper,
                "spans": [], "occurrences": 0,
                "text": text[toks[lhs_start].start: span[1] + 1],
            }
            found[key] = entry
        entry["spans"].append(span)
        entry["occurrences"] += 1
    return list(found.values())


def validate_token_bindings(bindings: Any, declared: Iterable[str] | None = None) -> list:
    """THE authoring rule for ``token_bindings`` (the feed routes call it at
    save; the template apply reaches it through the same routes).  Returns
    the normalised list; raises :class:`BindingRefused` naming the entry
    and the fault.  ``declared`` = the feed's scalar ``query_params`` keys
    (a template member carries its parameters there); a token must be a
    date token or one of them -- an undeclared token would render as text
    and match nothing."""
    if bindings is None:
        return []
    if not isinstance(bindings, list):
        raise BindingRefused("token_bindings must be a list of bindings")
    declared_set = {str(d) for d in (declared or ())}
    out = []
    seen = set()
    for idx, b in enumerate(bindings):
        if not isinstance(b, dict):
            raise BindingRefused(f"token_bindings[{idx}] must be an object")
        side = _binding_side(b.get("side"))
        if b.get("side") not in (None, "", *BINDING_SIDES, "single"):
            raise BindingRefused(
                f"token_bindings[{idx}].side must be one of {list(BINDING_SIDES)}, "
                f"not {b.get('side')!r}")
        column = str(b.get("column") or "").strip()
        if not column:
            raise BindingRefused(f"token_bindings[{idx}] names no column")
        literal = b.get("literal")
        if literal is None or (isinstance(literal, str) and not literal.strip()):
            raise BindingRefused(
                f"token_bindings[{idx}] ({column}) has no literal to replace")
        literal = str(literal)
        token = str(b.get("token") or "").strip().strip("{}")
        if not _TOKEN_NAME_RE.match(token):
            raise BindingRefused(
                f"token_bindings[{idx}] ({column} = {literal!r}) binds to "
                f"{b.get('token')!r}, which is not a token name "
                f"(letters, digits, underscore)")
        is_date = token in DATE_TOKENS
        if not is_date and token not in declared_set:
            raise BindingRefused(
                f"token_bindings[{idx}] ({column} = {literal!r}) binds to "
                f"{{{token}}}, which is neither a date token "
                f"({', '.join(sorted(DATE_TOKENS))}) nor a parameter the feed "
                f"declares in query_params ({sorted(declared_set) or 'none'}); "
                f"a template member declares its parameters there, a single "
                f"feed must set a value")
        fmt = b.get("format")
        if fmt not in (None, ""):
            if not is_date:
                raise BindingRefused(
                    f"token_bindings[{idx}]: a format ({fmt!r}) is only "
                    f"meaningful on a date token; {token!r} is a parameter")
            from core.feed.filename_renderer import _resolve_date_format
            if not _resolve_date_format(str(fmt)):
                raise BindingRefused(
                    f"token_bindings[{idx}]: date format {fmt!r} is not a known "
                    f"format code (YYYYMMDD, YYYY-MM-DD, DD-MON-YYYY, ...)")
            fmt = str(fmt).upper()
        else:
            fmt = None
        key = (side, column.lower(), literal)
        if key in seen:
            raise BindingRefused(
                f"token_bindings[{idx}] repeats {column} = {literal!r} on the "
                f"{side} side; one literal binds to one token")
        seen.add(key)
        out.append({"side": side, "column": column, "literal": literal,
                    "token": token, "format": fmt})
    return out


def apply_token_bindings(sql: Optional[str], bindings: Any, *, side: str = "",
                         feed_id: Any = None) -> Optional[str]:
    """Rewrite every bound literal predicate of ``sql`` (this ``side``) to
    its ``{TOKEN}``.  A binding for this side that matches NO predicate
    REFUSES (:class:`BindingRefused`): the saved query was edited since it
    was bound, and running the literal would deliver the wrong date or
    entity with a green status.  Bindings for the other side are ignored.
    Returns ``sql`` unchanged when nothing binds to this side."""
    if not sql or not bindings:
        return sql
    this_side = _binding_side(side)
    mine = [b for b in (bindings if isinstance(bindings, list) else [])
            if isinstance(b, dict) and _binding_side(b.get("side")) == this_side]
    if not mine:
        return sql
    preds = literal_predicates(sql)
    by_key = {(p["column"].lower(), p["literal"]): p for p in preds}
    text = str(sql)
    edits = []  # (start, end, replacement)
    for b in mine:
        column = str(b.get("column") or "").strip()
        literal = str(b.get("literal") if b.get("literal") is not None else "")
        token = str(b.get("token") or "").strip().strip("{}")
        fmt = b.get("format")
        hit = by_key.get((column.lower(), literal))
        if hit is None:
            have = sorted({f"{p['qualified']} {p['operator']} {p['literal']!r}" for p in preds})
            raise BindingRefused(
                f"feed {feed_id!r} {this_side} side: token binding "
                f"{column} = {literal!r} -> {{{token}}} matches no literal "
                f"predicate in the SQL that runs (the saved query was edited "
                f"since the binding was made?).  Predicates found: "
                f"{have or 'none'}.  The run is REFUSED rather than run with "
                f"the literal; re-bind the feed or restore the query.")
        if fmt and token not in DATE_TOKENS:
            raise BindingRefused(
                f"feed {feed_id!r}: binding {column} = {literal!r} carries a "
                f"format {fmt!r} but {token!r} is not a date token")
        placeholder = "{" + token + (f":{fmt}" if fmt else "") + "}"
        for start, end in hit["spans"]:
            if text[start] in ("'", '"'):
                q = text[start]
                edits.append((start, end, f"{q}{placeholder}{q}"))
            else:
                edits.append((start, end, placeholder))
    # apply right-to-left so earlier offsets stay valid
    for start, end, rep in sorted(edits, key=lambda e: e[0], reverse=True):
        text = text[:start] + rep + text[end + 1:]
    return text


def validate_token_value(name: str, value: Any) -> str:
    """THE rule for a parameter value: a short string of letters, digits
    and code punctuation.  Returns the value as text; raises
    :class:`UnsafeTokenValue` naming the parameter and the offending
    character class.  Used at authoring (the template matrix) and at
    render (this module), so what is accepted is what is rendered."""
    if value is None:
        raise UnsafeTokenValue(f"parameter {name!r} has no value (null)")
    if isinstance(value, bool):
        text = "true" if value else "false"
    elif isinstance(value, (date, datetime)):
        text = value.date().isoformat() if isinstance(value, datetime) else value.isoformat()
    else:
        text = str(value)
    if len(text) > MAX_VALUE_LEN:
        raise UnsafeTokenValue(
            f"parameter {name!r} value is {len(text)} characters; the limit "
            f"is {MAX_VALUE_LEN}")
    if not text.strip():
        raise UnsafeTokenValue(f"parameter {name!r} value is blank")
    if "--" in text or "/*" in text or "*/" in text:
        raise UnsafeTokenValue(
            f"parameter {name!r} value {text!r} contains a SQL comment marker "
            f"(-- or /* */); the value is REFUSED, never escaped")
    if not _VALUE_OK_RE.match(text):
        bad = sorted({c for c in text if not _VALUE_OK_RE.match(c)})
        raise UnsafeTokenValue(
            f"parameter {name!r} value {text!r} contains character(s) {bad!r} "
            f"that cannot be pasted inside a SQL literal (a quote, a "
            f"backslash, a semicolon, a comment marker or a control "
            f"character).  The value is REFUSED, never escaped: an entity or "
            f"event code is a code, not a sentence.")
    return text


def _format_date(iso: Any, fmt: Optional[str]) -> str:
    """``YYYY-MM-DD`` -> the filename renderer's format codes, or ISO."""
    text = str(iso)
    if not fmt:
        return text
    from core.feed.filename_renderer import _resolve_date_format
    strftime = _resolve_date_format(fmt)
    if not strftime:
        raise UnresolvedToken(f"date format {fmt!r} is not a known format code")
    try:
        d = date.fromisoformat(text[:10])
    except ValueError as exc:
        raise UnresolvedToken(f"date value {text!r} is not ISO") from exc
    return d.strftime(strftime)


def tokens_in(sql: Optional[str]) -> list:
    """Every ``{NAME}`` / ``{NAME:FMT}`` token the SQL carries, in order of
    first use: ``[{"name", "format"}]`` (2026-10-12: the feed form asks for
    a value of every PARAMETER token a query needs -- the owner's shared
    fact_tetb query carries ``{SYSTEM_ENTITY}`` / ``{EventCode}``)."""
    seen, out = set(), []
    if not isinstance(sql, str):
        return out
    for m in _OG_TOKEN_RE.finditer(sql):
        if m.group(1) not in seen:
            seen.add(m.group(1))
            out.append({"name": m.group(1), "format": m.group(2)})
    return out


def declared_token_names(params: Mapping[str, Any] | None,
                         declared: Iterable[str] | None = None) -> set:
    """Which ``{NAME}`` tokens this render will resolve: the date tokens,
    every scalar key of ``params`` (the resolver's vocabulary plus the
    feed's query_params), and anything ``declared`` names explicitly."""
    names = set(DATE_TOKENS)
    for k, v in (params or {}).items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            names.add(str(k))
    names.update(str(d) for d in (declared or ()))
    return names


def render_og_tokens(sql: Optional[str], params: Mapping[str, Any] | None, *,
                     declared: Iterable[str] | None = None,
                     feed_id: Any = None, side: str = "",
                     bindings: Any = None, contract: Any = None) -> Optional[str]:
    """Render every single-brace token in ``sql`` from ``params``.

    ``params`` is the dict ``core.feed.param_resolver.resolve_feed_params``
    builds (calendar vocabulary + the feed's scalar ``query_params``).
    ``declared`` adds parameter names that MUST resolve even when absent
    from ``params`` (a template member's parameters) -- their absence is a
    refusal, not a literal.  ``bindings`` (the feed's ``token_bindings``,
    2026-10-11) rewrite bound LITERAL predicates of this ``side`` to their
    tokens FIRST, so a saved query's ``CODE = 'SAP-2504'`` renders exactly as
    a hand-written ``CODE = '{SYSTEM_ENTITY}'`` would -- and a binding that
    no longer matches refuses (:class:`BindingRefused`).
    """
    if bindings:
        sql = apply_token_bindings(sql, bindings, side=side, feed_id=feed_id)
    if not sql or "{" not in sql:
        return sql
    params = params or {}
    # 2026-10-12 -- THE UPSTREAM CONTRACT's tokens (core/feed/upstream_
    # contract.py): ``{version}`` / ``{snapshot}`` / any message token in the
    # DB are THIS side's governing message's values.  Always DECLARED: a
    # query that uses one with no contract value REFUSES (it would read a
    # version nobody announced).
    from core.feed import upstream_contract as _uc
    _ctok = _uc.token_names()
    if _ctok:
        params = {**params, **_uc.token_values(contract, side)}
        declared = list(declared or ()) + _ctok
    known = declared_token_names(params, declared)
    unknown: Dict[str, None] = {}

    def _sub(m: "re.Match[str]") -> str:
        name, fmt = m.group(1), m.group(2)
        if name in DATE_TOKENS:
            key = DATE_TOKENS[name]
            value = params.get(key)
            if value in (None, ""):
                raise UnresolvedToken(
                    f"{{{name}}} needs the run's {key} and none was resolved "
                    f"(feed {feed_id!r}{' ' + side if side else ''}); the SQL "
                    f"is not run with the token as literal text")
            return _format_date(value, fmt)
        if name in known:
            if name not in params or params.get(name) is None:
                raise UnresolvedToken(
                    f"{{{name}}} is a declared parameter of feed {feed_id!r}"
                    f"{' ' + side if side else ''} and has NO value; the SQL "
                    f"is not run with the token as literal text (it would "
                    f"match nothing and certify an empty file)")
            text = validate_token_value(name, params[name])
            if fmt:
                raise UnresolvedToken(
                    f"{{{name}:{fmt}}}: a format suffix is only meaningful on "
                    f"a date token; {name!r} is a parameter")
            return text
        unknown.setdefault(name, None)
        return m.group(0)

    out = _OG_TOKEN_RE.sub(_sub, sql)
    if unknown:
        logger.warning(
            "[sql_tokens] feed %s%s: SQL carries single-brace token(s) %s that "
            "no date token or declared parameter resolves -- left as written. "
            "If they are parameters, declare them in the feed's query_params.",
            feed_id, f" {side}" if side else "", sorted(unknown))
    return out
