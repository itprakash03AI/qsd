"""FR-ID-06 — THE fully-qualified task identity formatter (2026-09-03).

``<feed>/<business_date>/<build>/<step>[/<partition>]`` — the ONE string
that appears in the engine log line, the Netcool AlertKey and the run
screen, so an operator at 3am moves between the three without
translating.  Before this module, the three mandated consumers used
three home-grown identities: the engine logged feed-id + exec-uuid,
Netcool's AlertKey was a bare dependency name, and the run screen keyed
on run_id + bare step name — none of which could NAME the thing that
failed.

Design rules:

* **One formatter, three consumers.**  The property that matters is not
  the exact spelling but that every consumer produces the SAME string
  for the same task.  Nothing else in the codebase may join these
  fields by hand.
* **A missing component is shown, never invented.**  An adhoc run with
  no business date renders ``-`` in that position — a visible hole,
  not a fabricated date.  The positions are fixed so the string always
  parses the same way.
* **A component cannot forge extra positions** (the Netcool Identifier
  lesson: a value containing the separator forges fields).  ``/`` inside
  a component is replaced by ``~`` — the feed-name charset (FR-ID-01)
  makes this unreachable for compliant names, so it only ever bites
  legacy/foreign values, and visibly.

Pure functions only.  No database, no config, no I/O.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

#: Rendered in a position whose value is unknown — a visible hole.
MISSING = "-"

_SEPARATOR = "/"
_ESCAPE = "~"


def _component(value: Any) -> str:
    """One position of the identity: stringified, separator-escaped,
    ``-`` when empty/None.  Never raises."""
    if value is None:
        return MISSING
    if isinstance(value, datetime):
        value = value.date().isoformat()
    elif isinstance(value, date):
        value = value.isoformat()
    text = str(value).strip()
    if not text:
        return MISSING
    return text.replace(_SEPARATOR, _ESCAPE)


def qualified_task_id(feed: Any, business_date: Any, build: Any,
                      step: Any = None,
                      partition: Optional[Any] = None) -> str:
    """The FR-ID-06 identity string.

    ``feed`` — the feed NAME (FR-ID-01 charset) where known, else its id.
    ``business_date`` — date/datetime/ISO string.
    ``build`` — the run's build id (feed_runs.build_id) where present,
    else the execution uuid (the engine's ``build_id=exec_id`` is the
    established fallback — see ``_assemble_fanout_manifest``).
    ``step`` — the stable per-feed step name (FR-ID-04: same name every
    night; never derived from a run id or timestamp).  Omitted (None)
    renders the RUN-level identity ``<feed>/<date>/<build>``.
    ``partition`` — the child partition identity, only for fan-out
    children.
    """
    parts = [_component(feed), _component(business_date), _component(build)]
    if step is not None:
        parts.append(_component(step))
        if partition is not None:
            parts.append(_component(partition))
    return _SEPARATOR.join(parts)
