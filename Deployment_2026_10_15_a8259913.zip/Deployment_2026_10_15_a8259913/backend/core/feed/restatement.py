"""RESTATEMENT -- a new upstream message for a business date already
delivered (2026-10-12, the owner's month end).

  "Kafka message will come on daily basis ... run date is calendar date and
  business date is kafka business date i.e. month end date ... gen on daily
  basis till new month started ... file name sap_2920_{businessDate}_{rundate}
  ... on same day (same month end date and same run date) kafka message came
  multiple times then we have to hold rerun and raise alert to RTB"

A task is (feed, business date); every delivery of it is an EXECUTION whose
run date is its own day (``core/feed/rerun.py::run_date_of`` -- the date a
file's ``{run_date}`` is named with).  When the ledger classifies an arrival
as a REPLAY of a dependency a delivered run already read, the regeneration
decision is raised (core/feed/regeneration.py) and THIS module decides what
it does, from the feed's POLICY -- a ``feed_restatement_policies`` row
mapped at the feed's most specific scope (feed / template / feed group /
global; ``core/feed/feed_scope.py``).  No behaviour is spelled in code:

==================  =================================================
``on_new_message``  a new message on a LATER run date: ``rerun`` (the
                    business date is delivered again today, by itself),
                    ``hold`` or ``decide``
``same_run_date``   a re-send on the SAME run date as the last delivery:
                    ``hold`` (a RE-RUN HOLD -- the approvers are alerted
                    and decide), ``rerun`` or ``decide``
``window``          how long the business date stays open to
                    restatement: ``next_business_date`` (until the feed's
                    next scheduled business date), ``days`` (window_days
                    after the business date) or ``open``
==================  =================================================

Outcomes (``Verdict.action``):

* ``rerun``  -- the run is re-queued (``triggered_by = restatement``); the
  engine closes the decision when the delivery reads the new message
  (``regeneration.close_answered_decisions``).
* ``hold``   -- the decision stays open as a RE-RUN HOLD; the alert kind
  ``restatement_hold`` reaches the approvers (bell, e-mail, Netcool).  An
  approver re-runs or keeps the delivered file (:func:`act`); the gate is
  ``variance_hold.decision_authority`` -- the SAME rule that decides a
  variance hold (admin, the feed's owner, a mapped approver group).
* ``closed`` -- the window has passed: recorded and alerted
  (``restatement_closed``); nothing re-runs by itself.
* ``decide`` -- the decision a person answers (every feed's behaviour
  before this module: the seeded global policy).
* a run still EXECUTING is never re-queued under itself: ``decide``, with
  the reason.
"""
from __future__ import annotations

import logging
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Mapping, Optional

from core.feed.rerun import TRIGGER_RESTATEMENT, run_date_of

logger = logging.getLogger(__name__)

ACTION_RERUN, ACTION_HOLD, ACTION_DECIDE, ACTION_CLOSED = "rerun", "hold", "decide", "closed"
POLICY_ACTIONS = (ACTION_DECIDE, ACTION_RERUN, ACTION_HOLD)
WINDOWS = ("next_business_date", "days", "open")
EVIDENCE_KEY = "restatement"
#: how far ahead the next scheduled business date is looked for
_NEXT_DUE_HORIZON_DAYS = 400

#: the words a person reads, per action
TITLES = {
    ACTION_RERUN: "Restatement -- re-running for the new upstream version",
    ACTION_HOLD: "Re-run hold -- upstream re-sent on the same run date",
    ACTION_CLOSED: "Restatement after close -- upstream re-sent after the business date closed",
    ACTION_DECIDE: "Superseded -- a newer upstream version arrived",
}
ALERT_KIND = {ACTION_HOLD: "restatement_hold", ACTION_RERUN: "restatement_rerun",
              ACTION_CLOSED: "restatement_closed"}


@dataclass
class Verdict:
    action: str
    why: str
    title: str
    policy_id: Optional[int]
    policy_name: Optional[str]
    run_date: str
    delivered_run_date: Optional[str]
    window: str
    window_closes: Optional[str]

    def to_dict(self) -> dict:
        return asdict(self)


def validate_policy(data: Mapping[str, Any]) -> Optional[str]:
    """Why a policy row is refused, or None (the admin route's rule)."""
    from core.feed.feed_scope import SCOPES
    if data.get("scope") not in SCOPES:
        return f"scope must be one of {SCOPES}"
    if data.get("scope") != "global" and data.get("scope_id") is None:
        return f"scope {data.get('scope')!r} needs a scope_id"
    for k in ("on_new_message", "same_run_date"):
        if k in data and data[k] not in POLICY_ACTIONS:
            return f"{k} must be one of {POLICY_ACTIONS}"
    if "window" in data and data["window"] not in WINDOWS:
        return f"window must be one of {WINDOWS}"
    if data.get("window") == "days" and not (isinstance(data.get("window_days"), int)
                                             and data["window_days"] > 0):
        return "window 'days' needs window_days > 0"
    return None


def policy_for(db, feed: Mapping[str, Any]) -> dict:
    """The feed's policy: the active row of its most specific scope.  None
    readable -> the seeded default's words (decide), said in the name."""
    from core.feed.feed_scope import most_specific
    try:
        row = most_specific(db.list_restatement_policies(active_only=True) or [], feed)
    except Exception as exc:                            # noqa: BLE001 -- unknown: a person decides
        logger.error("[restatement] policies unreadable (%s) -- a person decides", exc)
        row = None
    return row or {"id": None, "name": "no policy mapped (a person decides)",
                   "on_new_message": ACTION_DECIDE, "same_run_date": ACTION_DECIDE,
                   "window": "open", "window_days": None}


def next_task(db, feed: Mapping[str, Any], business_date: date):
    """``(run day, business date)`` of the feed's NEXT task after the one for
    ``business_date`` (schedule + THE calendar SOD uses; 2026-10-13: the
    data's date may differ from the run day -- schedule.next_task), or None
    when its schedule has no date rule or none falls in the horizon."""
    from core.feed.schedule import next_task as _next, parse_schedule
    from core.feed.sod_generator import SodTaskGenerator
    sched = parse_schedule(feed.get("schedule_declaration"))
    if sched is None:
        return None
    cal = SodTaskGenerator(db)._resolve_calendar(feed)
    return _next(sched, business_date, cal, _NEXT_DUE_HORIZON_DAYS)



def window_closes(db, feed: Mapping[str, Any], policy: Mapping[str, Any],
                  business_date: date) -> Optional[date]:
    """The first run date on which the business date is CLOSED to
    restatement, or None (open)."""
    w = policy.get("window") or "open"
    if w == "days" and policy.get("window_days"):
        return business_date + timedelta(days=int(policy["window_days"]) + 1)
    if w == "next_business_date":
        # closed from the RUN DAY of the next task (a month end delivered on
        # workday 5 stays open until the next workday 5, not the next month
        # end's calendar date)
        nt = next_task(db, feed, business_date)
        return nt[0] if nt else None
    return None


def decide(db, feed: Mapping[str, Any], delivered_run: Mapping[str, Any], business_date: date,
           *, now: Optional[datetime] = None) -> Verdict:
    """What this replay does for this feed's delivered run."""
    policy = policy_for(db, feed)
    today = run_date_of(now)
    delivered = delivered_run.get("completed_at")
    delivered_rd = run_date_of(delivered) if delivered else None
    closes = None
    try:
        closes = window_closes(db, feed, policy, business_date)
    except Exception as exc:                            # noqa: BLE001 -- unknown window: a person decides
        logger.error("[restatement] window of feed %s @ %s unreadable (%s)",
                     feed.get("id"), business_date, exc)
        policy = {**policy, "on_new_message": ACTION_DECIDE, "same_run_date": ACTION_DECIDE}

    def v(action: str, why: str) -> Verdict:
        return Verdict(action=action, why=why, title=TITLES[action], policy_id=policy.get("id"),
                       policy_name=policy.get("name"), run_date=today.isoformat(),
                       delivered_run_date=delivered_rd.isoformat() if delivered_rd else None,
                       window=str(policy.get("window")),
                       window_closes=closes.isoformat() if closes else None)

    if str(delivered_run.get("status") or "") == "running":
        return v(ACTION_DECIDE, "the run is still executing on the earlier message -- decide "
                                "once it ends (its output may mix the two versions)")
    if closes is not None and today >= closes:
        return v(ACTION_CLOSED, f"the business date closed to restatement on {closes} "
                                f"({policy.get('window')}); nothing re-runs by itself")
    if delivered_rd is not None and delivered_rd == today:
        action = policy.get("same_run_date") or ACTION_DECIDE
        why = (f"already delivered today (run date {today}); policy "
               f"{policy.get('name')!r} says {action} for a same-day re-send")
    else:
        action = policy.get("on_new_message") or ACTION_DECIDE
        why = (f"last delivered on run date {delivered_rd or 'unknown'}, now {today}; "
               f"policy {policy.get('name')!r} says {action}")
    return v(action if action in TITLES else ACTION_DECIDE, why)


def act(db, verdict: Verdict, *, feed: Mapping[str, Any], run: Mapping[str, Any],
        decision: Mapping[str, Any], business_date: date) -> None:
    """Do what the verdict says.  Never raises (called on the arrival path)."""
    try:
        _act(db, verdict, feed=feed, run=run, decision=decision, business_date=business_date)
    except Exception as exc:                            # noqa: BLE001
        logger.error("[restatement] decision %s (%s) could not be acted on: %s -- it stays "
                     "open for a person", decision.get("id"), verdict.action, exc, exc_info=True)


def _act(db, verdict, *, feed, run, decision, business_date):
    from core.feed import feed_alerts
    from core.feed.rerun import refusal, requeue
    kind = ALERT_KIND.get(verdict.action)
    if verdict.action == ACTION_RERUN:
        why_not = refusal(run, db)
        if why_not:
            logger.warning("[restatement] decision %s: re-run refused (%s) -- left open",
                           decision.get("id"), why_not)
            return
        requeue(db, run, actor="restatement", triggered_by=TRIGGER_RESTATEMENT,
                reason=f"restatement: {verdict.why} (decision {decision.get('id')})")
    if kind:
        feed_alerts.raise_alert(
            db, kind, feed=feed, business_date=business_date, run_date=verdict.run_date,
            feed_run_id=run.get("id"), dedupe_key=alert_key(decision),
            message=f"{decision.get('dependency_name')} re-sent for {business_date}: "
                    f"{verdict.why}.")
    logger.warning("[restatement] feed %s @ %s decision %s: %s -- %s", feed.get("name"),
                   business_date, decision.get("id"), verdict.action, verdict.why)


def alert_key(decision: Mapping[str, Any]) -> str:
    return f"restatement:{decision.get('id')}"


def is_held(decision: Mapping[str, Any]) -> bool:
    ev = (decision.get("evidence") or {}).get(EVIDENCE_KEY) or {}
    return decision.get("status") == "open" and ev.get("action") in (ACTION_HOLD, ACTION_CLOSED)


# ── a person answers (the board's Re-run / Keep) ─────────────────────────

ANSWER_RERUN, ANSWER_KEEP = "rerun", "keep"


class AnswerRefused(Exception):
    def __init__(self, message: str, status: int = 409):
        super().__init__(message)
        self.status = status


def answer(db, decision_id: int, *, user: Mapping[str, Any], action: str,
           reason: Optional[str]) -> dict:
    """Answer one open decision -- a re-run hold, a restatement after close
    or a plain "superseded" -- in ONE server action: who may (THE hold rule,
    ``variance_hold.decision_authority``), the reason (the hold's rule), the
    resolution on the record, the re-queue of the delivered run on
    ``rerun``, and the alert cleared.  Raises :class:`AnswerRefused`."""
    from core.feed import feed_alerts
    from core.feed.regeneration import (RESOLUTION_NO_REGENERATION, RESOLUTION_REGENERATE,
                                        resolve_decision)
    from core.feed.rerun import refusal, requeue
    from core.feed.variance_hold import HoldRefused, _clean_reason, decision_authority
    if action not in (ANSWER_RERUN, ANSWER_KEEP):
        raise AnswerRefused(f"action must be {ANSWER_RERUN!r} or {ANSWER_KEEP!r}", 422)
    d = db.get_regeneration_decision(int(decision_id))
    if not d:
        raise AnswerRefused(f"decision {decision_id} not found", 404)
    if d.get("status") != "open":
        raise AnswerRefused(f"decision {decision_id} is already {d.get('resolution')} by "
                            f"{d.get('resolved_by')} -- it stays decided")
    ok, why = decision_authority(db, user, {"feed_config_id": d.get("feed_config_id")})
    if not ok:
        raise AnswerRefused(why, 403)
    try:
        text = _clean_reason(reason)
    except HoldRefused as exc:
        raise AnswerRefused(str(exc), 422)
    run = None
    if action == ANSWER_RERUN:
        rid = ((d.get("evidence") or {}).get("already_delivered") or {}).get("feed_run_id")
        run = db.get_feed_run(int(rid)) if rid else None
        if not run:
            raise AnswerRefused(f"the delivered run of decision {decision_id} is gone -- "
                                f"nothing to re-run", 409)
        why_not = refusal(run, db)
        if why_not:
            raise AnswerRefused(why_not)
    actor = str(user.get("username") or "")
    row = resolve_decision(
        db, int(decision_id), actor=actor, reason=f"{text} ({why})",
        resolution=RESOLUTION_REGENERATE if action == ANSWER_RERUN else RESOLUTION_NO_REGENERATION)
    queued = None
    if run is not None:
        queued = requeue(db, run, actor=actor, triggered_by=TRIGGER_RESTATEMENT,
                         reason=f"re-run approved by {actor}: {text} (decision {decision_id})")
    feed_alerts.clear(db, by=f"{actor}: {action}", dedupe_keys=[alert_key(d)])
    return {"decision": row, "action": action, "queued_run": queued, "authority": why}
