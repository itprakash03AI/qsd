"""The regeneration decision — replay-after-run as a first-class record
(FR-DEP-10 / FR-DEP-18 / FR-DEP-20, 2026-09-03).

``decision_raised`` / ``decision_resolved`` /
``run_flagged_read_during_reload`` sat in the run_events vocabulary with
ZERO producers: when an upstream replayed after a feed had already run, the
whole platform's response was a log-line suffix (", REPLAY SEEN") in
``etl_dependency``.  Nothing decided whether to regenerate, nothing
cascaded to downstream feeds, nothing recorded who decided.  This module
is the producer:

* :func:`on_replay_detected` — called by ``core.feed.ledger`` on EVERY
  arrival it classifies as a REPLAY (the one chokepoint every transport
  goes through, so no future arrival path can forget to raise).  For each
  feed that consumed the replayed dependency and has ALREADY run (or is
  running) for that business date, it raises one
  ``feed_regeneration_decisions`` row carrying the EVIDENCE — what
  replayed (identities, prior arrival count) and what had already been
  delivered (build, rows, output path, completion time) — plus a
  ``decision_raised`` ledger event.  A run still EXECUTING when the
  replay lands additionally gets ``run_flagged_read_during_reload``: its
  output may mix pre- and post-reload rows (§7.5).
* the FR-DEP-18 CASCADE — feed-to-feed dependencies ARE representable
  here: schedule kind ``on_completion_of`` declares "this feed runs when
  that one completes".  :func:`enumerate_downstream_feeds` walks that
  edge transitively (cycle-guarded); every downstream feed that already
  ran for the date gets its own linked decision
  (``parent_decision_id``), so "we regenerated X, what read X's old
  output?" is a query, not archaeology.
* :func:`resolve_decision` — a PERSON closes the decision with a named
  resolution and a reason; anonymous or reasonless resolutions are
  refused, because a skip nobody can explain a year on is the audit
  failure the platform exists to prevent.  Both transitions append
  run_events rows, so the who/when/why stays in the append-only ledger
  while the decision row carries current state.

Raising is FAIL-OPEN (an arrival must never be lost to a decision
bookkeeping error) but AUDIBLE — every refusal or failure is logged with
its reason.  Resolving FAILS LOUD: it is a human action whose caller must
see the refusal.

Deliberately NOT here: executing the regeneration itself.  Resolving with
``regenerate`` records the decision; actually re-running the feed is the
trigger paths' job (api / feed_engine), which read this record.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

RESOLUTION_REGENERATE = "regenerate"
RESOLUTION_NO_REGENERATION = "no_regeneration"
RESOLUTIONS = (RESOLUTION_REGENERATE, RESOLUTION_NO_REGENERATION)

#: Run statuses that mean "this feed already consumed the OLD data" —
#: the exact set FR-DEP-10 exists for.  pending/skipped runs need no
#: decision: the gate re-evaluates them against the NEW arrival anyway.
_ALREADY_CONSUMED_STATUSES = ("completed", "running")

#: Cascade depth guard — a chain deeper than this is a mis-declared
#: cycle, not a real pipeline.
_MAX_CASCADE_DEPTH = 10


# ── Downstream enumeration (FR-DEP-18) ────────────────────────────────────

def enumerate_downstream_feeds(db: Any, feed_name: str) -> list:
    """Feeds downstream of ``feed_name`` via ``on_completion_of``, with depth.

    Transitive and cycle-guarded.  Returns
    ``[{"id", "name", "depth", "upstream"}...]`` in breadth-first order.
    A schedule declaration that cannot be parsed is skipped with a log —
    a broken declaration must not hide the rest of the cascade.
    """
    try:
        configs = db.list_feed_configs(is_active=True) or []
    except Exception as exc:  # noqa: BLE001 — enumeration is advisory; a failure is stated, never fatal
        logger.error("[regeneration] downstream enumeration failed for %r: "
                     "%s", feed_name, exc)
        return []

    # 2026-10-03 — THE edge rule (core/feed/upstream_completion.py), shared
    # with the completion trigger: a declaration names its upstream
    # CASE-INSENSITIVELY (feed names are unique that way and the authoring
    # route accepts it so), keyed here by the upper-cased name.  This walk
    # matched exact case, so a declaration the trigger fires could be
    # invisible to the cascade -- two answers to "who is downstream".
    from core.feed.upstream_completion import on_completion_edges
    edges = on_completion_edges(configs)

    out: list = []
    seen = {str(feed_name).upper()}
    frontier = [(str(feed_name), 0)]
    while frontier:
        current, depth = frontier.pop(0)
        if depth >= _MAX_CASCADE_DEPTH:
            logger.warning(
                "[regeneration] cascade from %r exceeded depth %d — "
                "stopping (a chain this deep is a mis-declared cycle)",
                feed_name, _MAX_CASCADE_DEPTH)
            break
        for cfg in edges.get(current.upper(), []):
            name = str(cfg.get("name") or "")
            if not name or name.upper() in seen:
                continue
            seen.add(name.upper())
            out.append({"id": cfg.get("id"), "name": name,
                        "depth": depth + 1, "upstream": current})
            frontier.append((name, depth + 1))
    return out


# ── Raising (called from the ledger chokepoint; fail-open) ────────────────

def on_replay_detected(db: Any, *, dependency_name: str,
                       business_date: date,
                       arrival_event: Optional[dict] = None,
                       actor: str = "system") -> list:
    """Raise the regeneration decision(s) one REPLAY arrival demands.

    Returns the decision rows raised (possibly empty).  NEVER raises —
    this runs inside the arrival path, and an arrival must not be lost
    to decision bookkeeping; every failure is logged at ERROR instead.
    """
    try:
        return _raise_for_replay(db, dependency_name=dependency_name,
                                 business_date=business_date,
                                 arrival_event=arrival_event, actor=actor)
    except Exception as exc:  # noqa: BLE001 — deliberate fail-open: the arrival itself must survive
        logger.error(
            "[regeneration] replay of %r @ %s: decisions could NOT be "
            "raised (%s) — the arrival is recorded, the decision is NOT; "
            "an operator must raise it by hand",
            dependency_name, business_date, exc)
        return []


def _raise_for_replay(db: Any, *, dependency_name: str, business_date: date,
                      arrival_event: Optional[dict], actor: str) -> list:
    try:
        etl_ids = db.list_etl_ids_for_dependency_key(dependency_name) or []
    except Exception as exc:  # noqa: BLE001 — stated, not silent
        logger.error(
            "[regeneration] replay of %r @ %s: the feeds consuming it "
            "could not be enumerated (%s) — NO decision was raised",
            dependency_name, business_date, exc)
        return []
    feeds: dict = {}
    for etl_id in etl_ids:
        try:
            for cfg in db.list_feed_configs_by_etl_id(int(etl_id)) or []:
                if cfg.get("id") is not None:
                    feeds[int(cfg["id"])] = cfg
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "[regeneration] feeds for etl_id=%s unreadable (%s)",
                etl_id, exc)

    raised: list = []
    for fid, cfg in sorted(feeds.items()):
        decision = _raise_for_feed(
            db, feed_config=cfg, business_date=business_date,
            dependency_name=dependency_name, arrival_event=arrival_event,
            actor=actor, parent_decision_id=None)
        if decision is None:
            continue
        raised.append(decision)
        # FR-DEP-18 — the cascade: every downstream feed (on_completion_of,
        # transitively) that already consumed THIS feed's output for the
        # date gets its own decision, linked to the one that caused it.
        for downstream in enumerate_downstream_feeds(
                db, str(cfg.get("name") or "")):
            try:
                ds_cfg = db.get_feed_config(int(downstream["id"])) or {}
            except Exception:  # noqa: BLE001
                ds_cfg = {"id": downstream["id"],
                          "name": downstream["name"]}
            child = _raise_for_feed(
                db, feed_config=ds_cfg, business_date=business_date,
                dependency_name=dependency_name,
                arrival_event=arrival_event, actor=actor,
                parent_decision_id=int(decision["id"]),
                cascade_via=downstream.get("upstream"))
            if child is not None:
                raised.append(child)
    return raised


def _raise_for_feed(db: Any, *, feed_config: dict, business_date: date,
                    dependency_name: str, arrival_event: Optional[dict],
                    actor: str, parent_decision_id: Optional[int],
                    cascade_via: Optional[str] = None) -> Optional[dict]:
    """One feed's decision, or None when no decision is due.

    No decision when the feed has not consumed the old data (no
    completed/running run for the date) or when an OPEN decision for the
    same (feed, date, dependency) already exists — a second replay the
    same morning is MORE evidence for the same open question, not a
    second question.
    """
    fid = int(feed_config["id"])
    try:
        runs = db.list_feed_runs_for_feed_date(fid, business_date) or []
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "[regeneration] runs for feed %s @ %s unreadable (%s) — no "
            "decision raised for it", fid, business_date, exc)
        return None
    consumed = [r for r in runs
                if str(r.get("status") or "") in _ALREADY_CONSUMED_STATUSES]
    if not consumed:
        return None                    # the gate re-evaluates pending runs

    existing = db.list_regeneration_decisions(
        feed_config_id=fid, business_date=business_date,
        dependency_name=dependency_name, status="open", limit=1)
    if existing:
        logger.info(
            "[regeneration] feed %s @ %s already has open decision #%s "
            "for %r — not raising a duplicate",
            fid, business_date, existing[0].get("id"), dependency_name)
        return None

    newest = consumed[-1]
    evidence = {
        "replayed_dependency": dependency_name,
        "arrival": _arrival_evidence(arrival_event),
        "already_delivered": {
            "feed_run_id": newest.get("id"),
            "build_id": newest.get("build_id"),
            "status": newest.get("status"),
            "completed_at": newest.get("completed_at"),
            "total_rows": newest.get("total_rows"),
            "output_path": newest.get("output_path"),
        },
        "runs_for_date": len(runs),
    }
    if cascade_via:
        evidence["cascade_via"] = str(cascade_via)
    # 2026-10-12 -- what this re-send DOES is the feed's RESTATEMENT POLICY
    # (core/feed/restatement.py, data mapped at a scope): re-run on a later
    # run date, a RE-RUN HOLD on the same run date, nothing after the window.
    # Decided BEFORE the row is written so the evidence says it; a cascaded
    # feed is not restated by itself (its upstream's delivery re-triggers it).
    verdict = None
    if parent_decision_id is None:
        from core.feed import restatement
        verdict = restatement.decide(db, feed_config, newest, business_date)
        evidence[restatement.EVIDENCE_KEY] = verdict.to_dict()

    decision = db.insert_regeneration_decision({
        "feed_config_id": fid,
        "business_date": business_date,
        "dependency_name": str(dependency_name),
        "build_id": newest.get("build_id"),
        "parent_decision_id": parent_decision_id,
        "status": "open",
        "evidence": evidence,
        "raised_by": str(actor),
        "raised_at": datetime.now(timezone.utc),
    })

    from core.feed.ledger import record_run_event
    record_run_event(
        db, feed_config_id=fid, business_date=business_date,
        event_type="decision_raised", subject=str(dependency_name),
        actor=str(actor), build_id=newest.get("build_id"),
        payload={"decision_id": decision.get("id"),
                 "parent_decision_id": parent_decision_id,
                 "evidence": evidence})
    if str(newest.get("status") or "") == "running":
        # §7.5 — the replay landed while this run was EXECUTING: its
        # output may mix pre- and post-reload rows.  Flagged on the
        # ledger, never inferred later from timestamps.
        record_run_event(
            db, feed_config_id=fid, business_date=business_date,
            event_type="run_flagged_read_during_reload",
            subject=str(dependency_name), actor=str(actor),
            build_id=newest.get("build_id"),
            payload={"decision_id": decision.get("id"),
                     "feed_run_id": newest.get("id")})
    if verdict is not None:
        restatement.act(db, verdict, feed=feed_config, run=newest, decision=decision,
                        business_date=business_date)
    logger.warning(
        "[regeneration] DECISION #%s raised: %r replayed for %s after "
        "feed %s had already %s — an operator must resolve "
        "regenerate / no_regeneration",
        decision.get("id"), dependency_name, business_date, fid,
        newest.get("status"))
    return decision


def _arrival_evidence(event: Optional[dict]) -> dict:
    if not event:
        return {}
    return {
        "message_identity": event.get("message_identity"),
        "arrived_at": (event["arrived_at"].isoformat()
                       if isinstance(event.get("arrived_at"), datetime)
                       else event.get("arrived_at")),
        "source": event.get("source"),
        "reported_rows": event.get("reported_rows"),
    }


# ── Resolving (a human action; fails loud) ────────────────────────────────

def resolve_decision(db: Any, decision_id: int, *, resolution: str,
                     actor: str, reason: str) -> dict:
    """Resolve one open decision.  Raises ``ValueError`` on any refusal.

    Refused: an unknown resolution, a missing actor, a missing reason,
    an unknown decision, and a decision already resolved (the first
    answer stands; a second resolver must read it, not overwrite it).
    """
    if resolution not in RESOLUTIONS:
        raise ValueError(
            f"resolution {resolution!r} is not one of {RESOLUTIONS} — "
            "an unknown resolution recorded now is an unanswerable audit "
            "row a year later")
    if not str(actor or "").strip():
        raise ValueError("a regeneration decision must be resolved by a "
                         "NAMED person — actor is required (FR-DEP-20)")
    if not str(reason or "").strip():
        raise ValueError("a regeneration decision needs a REASON — "
                         "'why' is the part audit exists for (FR-DEP-20)")

    row = db.resolve_regeneration_decision(
        int(decision_id), resolution=str(resolution),
        resolved_by=str(actor).strip(), reason=str(reason).strip())
    if row is None:
        current = db.get_regeneration_decision(int(decision_id))
        if current is None:
            raise ValueError(f"decision {decision_id} does not exist")
        raise ValueError(
            f"decision {decision_id} is already resolved "
            f"({current.get('resolution')!r} by "
            f"{current.get('resolved_by')!r} at "
            f"{current.get('resolved_at')}) — it stays decided")

    from core.feed.ledger import record_run_event
    record_run_event(
        db, feed_config_id=int(row["feed_config_id"]),
        business_date=_coerce_date(row.get("business_date")),
        event_type="decision_resolved",
        subject=str(row.get("dependency_name") or ""),
        actor=str(actor).strip(), build_id=row.get("build_id"),
        payload={"decision_id": row.get("id"),
                 "resolution": str(resolution),
                 "reason": str(reason).strip()})
    logger.info(
        "[regeneration] decision #%s resolved %r by %s: %s",
        row.get("id"), resolution, actor, reason)
    return row


def _coerce_date(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value[:10]).date()
        except ValueError:
            return value
    return value


def close_answered_decisions(db: Any, *, feed_config_id: int, business_date: date,
                             contract: Any, execution_id: str) -> list:
    """A run that COMPLETED having read the CURRENT upstream contract
    (core/feed/upstream_contract.py) ANSWERS every open decision raised for
    one of that contract's dependencies on that date (2026-10-12): the data
    the counterparty now holds IS the restated data.  Closed as
    ``regenerate`` by the engine, naming the run and the message it read --
    never left open to claim "superseded" over a file that is current.  A
    decision whose dependency the run did NOT read on the current message
    stays open.  Never raises (the run is already complete)."""
    closed: list = []
    try:
        open_ = db.list_regeneration_decisions(
            feed_config_id=int(feed_config_id), business_date=business_date,
            status="open", limit=100) or []
    except Exception as exc:  # noqa: BLE001
        logger.error("[regeneration] open decisions of feed %s @ %s unreadable (%s) -- "
                     "none closed", feed_config_id, business_date, exc)
        return closed
    read = {str(c.get("dependency")): (c.get("message") or {}).get("identity")
            for s, c in (contract or {}).items()
            if not str(s).startswith("_") and isinstance(c, dict) and c.get("status") == "arrived"}
    if not read:
        return closed
    from core.feed.ledger import arrivals_for
    from core.feed.upstream_contract import _governing_arrival
    for d in open_:
        dep = str(d.get("dependency_name") or "")
        if dep not in read:
            continue
        try:
            latest = _governing_arrival(arrivals_for(db, dep, business_date))
        except Exception:  # noqa: BLE001 -- unknown: leave the decision to a person
            continue
        if latest is None or latest.get("message_identity") != read[dep]:
            continue                        # the run read an older message: still a question
        try:
            closed.append(resolve_decision(
                db, int(d["id"]), resolution=RESOLUTION_REGENERATE, actor="engine",
                reason=f"answered by execution {execution_id}, which delivered the current "
                       f"message {read[dep]!r} of {dep}"))
        except Exception as exc:  # noqa: BLE001
            logger.error("[regeneration] decision %s could not be closed by %s (%s)",
                         d.get("id"), execution_id, exc)
    return closed
