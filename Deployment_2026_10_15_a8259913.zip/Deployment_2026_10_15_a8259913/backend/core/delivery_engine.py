"""
Delivery Engine — Phase 60

Handles subscription-based report delivery:
  - Render report output as PDF/Excel/CSV
  - Email to recipients with attachment
  - Evaluate alert rules post-execution
  - Process pending subscriptions (called by scheduler)

Dependencies injected via init_delivery_engine().
"""
from __future__ import annotations

import io
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from croniter import croniter

from core import config

logger = logging.getLogger(__name__)

# ── Injected dependencies ─────────────────────────────────────────────────────

_db_manager = None
_email_send_fn: Optional[Callable] = None
_report_execute_fn: Optional[Callable] = None       # (report_id, params, username, limit, report_type) -> pd.DataFrame
_pdf_render_fn: Optional[Callable] = None            # (df, report_name, params) -> bytes
_webhook_fire_fn: Optional[Callable] = None


def init_delivery_engine(db_manager, email_send_fn, report_execute_fn,
                         pdf_render_fn=None, webhook_fire_fn=None):
    """Wire up dependencies from _startup()."""
    global _db_manager, _email_send_fn, _report_execute_fn, _pdf_render_fn, _webhook_fire_fn
    _db_manager = db_manager
    _email_send_fn = email_send_fn
    _report_execute_fn = report_execute_fn
    _pdf_render_fn = pdf_render_fn
    _webhook_fire_fn = webhook_fire_fn
    logger.info("DeliveryEngine initialised")


def init_default_delivery_engine(db_manager) -> None:
    """The STANDARD delivery wiring, shared by main.py and the scheduler
    worker.

    2026-08-20 — these closures used to live inline in main.py's lifespan,
    which made main.py the only process where subscription delivery could
    execute: the scheduler pod registered the __subscription_delivery__ tick
    but its ``_db_manager``/``_report_execute_fn`` here were None, so every
    tick raised AttributeError — while scheduler/values.yaml promises that
    pod "EXECUTES ... subscription deliveries in-process".  One shared
    constructor means the two entry files cannot drift.

    None of these closures needs a websocket or an event loop — they were
    moved VERBATIM from main.py (Phase 60 / Phase 113-E wiring).
    """
    from core.email_service import send_email_with_attachment as _email_attach_fn

    # Phase 113-E: styled PDF render (report's style_config).
    def _styled_pdf_render(df, name, params, report_id):
        """Render a DataFrame to styled PDF bytes using report's style_config."""
        from api.business_reports_api import (
            _render_pdf_bytes, _extract_style_and_formats,
            _extract_fmt_rules, _require_db,
            _banding_spec, _section_sort_rows, _banded_disclosure_suffix,
        )
        report = None
        try:
            _db = _require_db()
            report = _db.get_business_report(report_id) or {}
            # EXACTLY six names — _extract_style_and_formats is pinned six
            # wide (tests/test_report_formatting_2026_08_30.py,
            # TestDeliveryEngineContract): widening the tuple would not
            # crash, this except would silently blank every style on every
            # delivered PDF.  Conditional-format rules therefore ride their
            # OWN accessor below, never this tuple.  ds_cols is the tuple's
            # EXISTING sixth element (previously discarded here) — binding
            # it is not a widening.
            hdr_bg, hdr_txt, neg_fmt, _, col_fmt_map, ds_cols = \
                _extract_style_and_formats(report, _db)
        except Exception:
            hdr_bg, hdr_txt, neg_fmt, col_fmt_map = (
                "1976D2", "FFFFFF", "brackets", {})
            # Sentinel, NOT []: [] means "the dataset has no columns" (the
            # interactive path skips id-keyed calcs there too — parity);
            # None means "we could not find out", which for a report that
            # DECLARES running calcs must fail the delivery, never silently
            # drop the calc column (see _augment_delivery_running_calcs).
            ds_cols = None
        # 2026-08-30 conditional formats: value-based rules must reach the
        # DELIVERED document, not only the interactive download.  Rules come
        # from the SAME row this closure already reads for styles (one
        # spelling of "which row"), via _extract_fmt_rules BY IMPORT — the
        # evaluator behind it is the legacy one shared by identity.
        #
        # FAIL-CLOSED: if the row could not be read at all (report is None
        # — the except above fired before the read completed) we cannot know
        # whether the author configured rules, and silently mailing a
        # possibly-unstyled document is the flattened-pivot / format-swap
        # defect class this engine already rejects.  For a business_report
        # delivery the row was JUST read successfully by the send-time authz
        # gate, the executor and _pivot_report_or_none, so landing here is a
        # genuine mid-delivery loss: raise → deliver_subscription records
        # the delivery FAILED and the retry ladder applies.  A legacy id
        # with no business-report row reads fine as {} → no rules, byte-
        # identical output.  (Style-extraction failure alone keeps report
        # set → defaults + rules, the pinned fallback behaviour.)
        if report is None:
            raise RuntimeError(
                f"could not read report {report_id} to resolve its "
                "conditional-format rules — failing the delivery rather "
                "than silently mailing an unstyled document")
        fmt_rules = _extract_fmt_rules(report)
        from core.json_utils import sanitize_for_json
        rows = sanitize_for_json(df.to_dict(orient="records"))
        columns = list(df.columns)
        # GAP-4 (2026-08-30) BANDED LAYOUT: section_definitions reach the
        # DELIVERED document through the interactive helpers BY IMPORT —
        # _banding_spec (what is a band), _section_sort_rows (display
        # order), _banded_layout inside _render_pdf_bytes (one "what is a
        # group", one total implementation) — the emailed PDF groups and
        # subtotals exactly as the interactive download.  Section-less
        # reports get spec None → historical call shape, byte-identical.
        # PIVOT boundary lives INSIDE _banding_spec (returns None for
        # pivots — the matrix carries its own totals), and pivot deliveries
        # never reach this closure anyway (_render_output routes them to
        # _render_pivot_delivery_bytes).
        #
        # FAIL-CLOSED (same posture as _augment_delivery_running_calcs
        # below): ds_cols is None means the style/columns read failed —
        # break_column_id / subtotal_measure_ids cannot be resolved, so a
        # report that DECLARES sections must FAIL the delivery, never
        # silently mail the flat table the author designed away.
        if ds_cols is None and (report or {}).get("section_definitions"):
            raise RuntimeError(
                "report declares section definitions but its dataset "
                "columns could not be resolved — failing the delivery "
                "rather than silently mailing a flat document")
        _band_spec, _band_notes = _banding_spec(report, ds_cols, columns)
        if _band_spec:
            # Section sort BEFORE the running calcs (same order as the
            # interactive route): calc columns accumulate over the BANDED
            # display order, so the delivered cumulative column equals the
            # screen's.
            rows = _section_sort_rows(rows, _band_spec["defs"])
        # GAP-2 (2026-08-30) running calculations: computed over EXACTLY the
        # rows in this document (df is already cut at delivery.max_pdf_rows),
        # via the interactive helper BY IMPORT — the delivered column carries
        # the same values in the same display order as the screen and the
        # interactive download.  Inert (same objects back, historical call
        # shape below) for reports without calcs.  A failure RAISES →
        # deliver_subscription records the delivery FAILED (retry ladder) —
        # never a document silently missing the column the report exists for.
        rows, columns, _rc_aug = _augment_delivery_running_calcs(
            report, rows, columns, ds_cols)
        # TRUNCATION POSTURE = the interactive one: when calc columns or
        # banded totals ride a cut document, the disclosure banner ON the
        # document gains the covers-included-rows-only sentence(s) — totals
        # are computed over the rows IN the document, and the document must
        # say so.  Unrenderable bands are never silently dropped: their
        # _banding_spec notes ride the banner even untruncated.  Flat
        # deliveries had no in-document banner before (the e-mail body
        # carries the truncation note), so the banner is added ONLY for
        # calc-carrying/banded documents — plain deliveries keep the
        # historical call shape byte-for-byte.
        _rc_disc = ""
        if _rc_aug or _band_spec or _band_notes:
            from api.business_reports_api import \
                _running_calc_disclosure_suffix
            _note = _truncation_note(df, config.delivery.max_pdf_rows)
            _rc_disc = (_note
                        + _running_calc_disclosure_suffix(_rc_aug, bool(_note))
                        + _banded_disclosure_suffix(bool(_band_spec),
                                                    bool(_note)))
            if _band_notes:
                _rc_disc += " " + " ".join(_band_notes)
        # kwarg only when rules exist: a rule-less report keeps the
        # HISTORICAL call shape (injected renderer doubles with closed
        # signatures keep working — same convention as the interactive
        # routes).
        return _render_pdf_bytes(rows, columns, name, hdr_bg, hdr_txt,
                                 neg_fmt, col_fmt_map,
                                 **({"fmt_rules": fmt_rules}
                                    if fmt_rules else {}),
                                 **({"sections": _band_spec}
                                    if _band_spec else {}),
                                 **({"disclosure_text": _rc_disc}
                                    if _rc_disc else {}))

    # Delivery dispatcher — business-report subscriptions resolve against
    # the business_reports table with OWNER-scoped RLS.  FB-60 (2026-09-26):
    # the legacy "report" family is refused by name; _authorize_delivery
    # already blocks it before execution, this is the second lock.
    def _delivery_execute_fn(report_id, param_values, username,
                             limit=10000, report_type="business_report"):
        if report_type == "business_report":
            from api.business_reports_api import run_business_report_to_df
            return run_business_report_to_df(
                report_id, param_values, username, limit=limit)
        from core.reports.legacy_parametric import refusal
        raise ValueError(refusal(f"subscription report_type {report_type!r}"))

    init_delivery_engine(
        db_manager=db_manager,
        email_send_fn=_email_attach_fn,
        report_execute_fn=_delivery_execute_fn,
        pdf_render_fn=_styled_pdf_render,
        webhook_fire_fn=None,      # added lazily below via webhook_service
    )
    try:
        from core.webhook_service import fire_webhook as _wh_fire
        global _webhook_fire_fn
        _webhook_fire_fn = _wh_fire
    except ImportError:
        pass


# ── Public API ────────────────────────────────────────────────────────────────

def deliver_subscription(sub_id: int, db_manager=None) -> Dict[str, Any]:
    """Execute one subscription: run report → render → email to all recipients.

    Returns summary dict with sent/failed counts.

    ``db_manager``: explicit db from the caller (the scheduler pod's tick
    passes its own — see process_pending_subscriptions); falls back to the
    module global wired by init_delivery_engine.
    """
    db = db_manager if db_manager is not None else _db_manager
    cfg = config.delivery
    sub = db.get_subscription(sub_id)
    if not sub:
        return {"error": "Subscription not found"}

    report_id = sub["report_id"]
    report_type = sub["report_type"]
    output_format = sub["output_format"]
    params = sub.get("param_values") or {}
    recipients = sub.get("recipient_emails") or []

    if not recipients:
        return {"error": "No recipients configured"}

    # ── 0. Delivery authorization (send-time re-check, fail-closed) ──────
    # DESIGN (core.reports.authorization): delivery runs at the report
    # OWNER's RLS scope and mails the same bytes to all recipients, so the
    # enforceable boundary is authorization-to-DISTRIBUTE: the subscription
    # creator must STILL hold view access to the report at send time
    # (revocation-safe), and the audience must satisfy the configured
    # recipient-domain policy.  A failure records delivery FAILURES — never
    # a silent send, never a silent skip.
    auth_error = _authorize_delivery(sub)
    if auth_error:
        logger.warning("Subscription %d delivery blocked: %s", sub_id, auth_error)
        _record_failures(sub_id, recipients, auth_error)
        return {"error": auth_error, "sent": 0, "failed": len(recipients)}

    # ── 1. Execute the report ────────────────────────────────────────────
    # Dispatch on report_type: a "business_report" subscription resolves the
    # id against the business_reports table (owner-scoped RLS), while the
    # legacy "report" path is unchanged.  The dispatcher is injected from
    # main.py so this module stays dependency-injected (no api/* imports).
    try:
        df = _report_execute_fn(
            report_id, params, sub["created_by"],
            limit=cfg.max_pdf_rows,
            report_type=report_type,
        )
    except Exception as exc:
        logger.error("Subscription %d: report execution failed: %s", sub_id, exc)
        _record_failures(sub_id, recipients, f"Report execution failed: {exc}")
        return {"error": str(exc), "sent": 0, "failed": len(recipients)}

    # ── 1b. Truncation disclosure (2026-08-05 audit) ─────────────────────
    # The executor caps EVERY delivered format at delivery.max_pdf_rows.
    # That cut used to be INVISIBLE: a subscribed CSV of a 100k-row report
    # mailed 10k rows presented as the report.  The cap stays (bounded
    # delivery is deliberate) but is now DISCLOSED — in the e-mail body and
    # in the one greppable [br-serve] line.  The business-report executor
    # declares exact numbers via DataFrame.attrs; when attrs are absent
    # (legacy path) an at-the-cap row count is reported honestly as "row
    # limit reached — may be incomplete" (tri-state, never a fabricated
    # claim of completeness).
    truncation_note = _truncation_note(df, cfg.max_pdf_rows)

    # ── 2. Render output ─────────────────────────────────────────────────
    # 2026-08-30 pivot parity: report_type + db + truncation_note flow into
    # the renderer so a pivot business report is delivered as the SAME
    # crosstab document the interactive download produces (see
    # _render_output), with the truncation disclosure inside the document —
    # pivot totals aggregated over a cut input must never present themselves
    # as complete.
    try:
        data_bytes, filename, content_type = _render_output(
            df, sub["name"], params, output_format, report_id,
            report_type=report_type, db=db, truncation_note=truncation_note,
        )
    except Exception as exc:
        logger.error("Subscription %d: render failed: %s", sub_id, exc)
        _record_failures(sub_id, recipients, f"Render failed: {exc}")
        return {"error": str(exc), "sent": 0, "failed": len(recipients)}

    try:
        from core.reports.serve_log import log_report_serve
        _attrs = getattr(df, "attrs", {}) or {}
        log_report_serve(
            report_id=report_id, user=sub.get("created_by") or "",
            rls=("owner" if report_type == "business_report" else "creator"),
            surface="delivery", fmt=output_format, rows=len(df),
            total_rows=_attrs.get("qs_total_rows"),
            row_limit=_attrs.get("qs_row_limit", cfg.max_pdf_rows),
            truncated=(_attrs.get("qs_truncated")
                       if "qs_truncated" in _attrs
                       else (True if len(df) >= int(cfg.max_pdf_rows or 0) > 0
                             else False)),
            detail=f"sub_id={sub_id}")
    except Exception as _log_exc:
        logger.debug("delivery serve-log emit failed: %s", _log_exc)

    # ── 3. Send to all recipients ────────────────────────────────────────
    send_reasons: list = []
    sent, failed = _send_to_recipients(sub, data_bytes, filename, content_type,
                                       truncation_note=truncation_note,
                                       reasons_out=send_reasons)

    # ── 4. Update subscription metadata ──────────────────────────────────
    # 2026-09-01 -- NOBODY RECEIVED IT IS A FAILURE.
    #
    # F-P3A-09 unified the failure ladder for the two shapes it knew about:
    # a raised exception, and a returned ``{"error": ...}``.  It missed the
    # third.  When every recipient failed, ``_send_to_recipients`` returns
    # ``(0, N)`` and no error key, so the caller's ``if error:`` never fired
    # and the metadata update below ran anyway -- stamping ``last_sent_at``
    # (the subscription reads as DELIVERED in the admin UI) and resetting
    # ``retry_count`` to 0, which makes ``retry_max_attempts`` unreachable
    # for the failure shape it most needs to catch.  A mailbox that has been
    # bouncing for a month looked healthy on every tick.
    #
    # That is the same defect F-P3A-09 describes in its own comment --
    # "Failure is failure, whichever way it is spelled" -- fixed for the
    # sibling spelling and not for this one.
    #
    # PARTIAL delivery is deliberately still a success: the report reached
    # someone, the individual failures are already recorded per-recipient by
    # ``_send_to_recipients``, and advancing the schedule is right.  Only a
    # complete miss is escalated.
    if sent == 0 and failed > 0:
        logger.error(
            "Subscription %d: delivery FAILED for all %d recipient(s) -- "
            "not stamping last_sent_at, ladder applies", sub_id, failed)
        _why = "; ".join(send_reasons)
        return {"error": (f"delivery failed for all {failed} recipient(s)"
                          + (f": {_why}" if _why else "")),
                "sent": 0, "failed": failed}

    now = datetime.now(timezone.utc)
    next_at = compute_next_send(sub["frequency"], sub.get("timezone", "UTC"))
    db.update_subscription(sub_id, last_sent_at=now, next_send_at=next_at, retry_count=0)

    logger.info("Subscription %d delivered: %d sent, %d failed", sub_id, sent, failed)
    return {"sent": sent, "failed": failed, "next_send_at": next_at.isoformat() if next_at else None}


def process_pending_subscriptions(db_manager=None) -> Dict[str, Any]:
    """Batch-process all subscriptions whose next_send_at has passed.

    Called periodically by the scheduler system job.

    ``db_manager``: 2026-08-20 — the scheduler tick passes its OWN db
    explicitly (the `_exec_business_report` precedent).  On a dedicated
    scheduler pod the module globals here were wired only by main.py's
    lifespan, so ``_db_manager`` was None and every tick raised
    AttributeError.  When a db arrives and the module is unwired, the
    chokepoint self-wires the standard engine so execution deps
    (email/report/pdf fns) are functional too — not just the db reads.
    """
    global _db_manager
    if db_manager is not None and _db_manager is None:
        try:
            init_default_delivery_engine(db_manager)
        except Exception as exc:
            logger.warning("default delivery wiring failed (tick continues "
                           "with explicit db only): %s", exc)
    db = db_manager if db_manager is not None else _db_manager
    if db is None:
        return {"skipped": True, "reason": "delivery engine not initialised"}

    cfg = config.delivery
    if not cfg.enabled:
        return {"skipped": True, "reason": "delivery disabled"}

    now = datetime.now(timezone.utc)
    pending = db.get_pending_subscriptions(before=now)
    batch = pending[:cfg.batch_size]

    results = []
    for sub in batch:
        # F-P3A-09 (2026-08-23): ONE failure ladder for BOTH failure shapes.
        # ``deliver_subscription`` catches its own execution/render/authz
        # failures and RETURNS ``{"error": ...}`` — the old ladder lived only
        # in the ``except`` arm, so a returned failure never advanced
        # ``next_send_at`` and never counted a retry: a persistently failing
        # subscription re-executed its FULL report on EVERY scheduler tick,
        # forever, and ``retry_max_attempts`` was dead code for the dominant
        # failure modes.  Failure is failure, whichever way it is spelled.
        try:
            result = deliver_subscription(sub["id"], db_manager=db)
            error = (result or {}).get("error")
        except Exception as exc:
            logger.error("Subscription %d processing failed: %s", sub["id"], exc, exc_info=True)
            result, error = {"error": str(exc)}, str(exc)
        if error:
            _apply_failure_ladder(db, sub, error, cfg)
        results.append({"id": sub["id"], **(result or {})})

    logger.info("Processed %d/%d pending subscriptions", len(batch), len(pending))
    return {"processed": len(batch), "total_pending": len(pending), "results": results}


def _apply_failure_ladder(db, sub: Dict[str, Any], error: str, cfg) -> None:
    """The ONE outcome rule for a failed scheduled delivery (F-P3A-09).

    * ``next_send_at`` advances to the NEXT cron slot — a failing
      subscription retries on its own schedule, never on every tick.
    * ``retry_count`` increments (success resets it to 0 inside
      ``deliver_subscription``), and at ``delivery.retry_max_attempts``
      consecutive failures the subscription deactivates loudly.
    * A cron that can no longer compute (corrupted row — create/update
      validate it) deactivates immediately: it could never deliver anyway,
      and leaving ``next_send_at`` in the past re-creates the tick storm.
    """
    retry = (sub.get("retry_count") or 0) + 1
    updates: Dict[str, Any] = {"retry_count": retry}
    next_at = compute_next_send(sub.get("frequency") or "",
                                sub.get("timezone", "UTC"))
    if next_at is not None:
        updates["next_send_at"] = next_at
    else:
        updates["is_active"] = False
        logger.warning("Subscription %s deactivated: cron %r no longer "
                       "computes a next send", sub.get("id"), sub.get("frequency"))
    if retry >= cfg.retry_max_attempts:
        updates["is_active"] = False
        logger.warning("Subscription %s deactivated after %d consecutive "
                       "failed deliveries (last error: %s)",
                       sub.get("id"), retry, str(error)[:200])
    db.update_subscription(sub["id"], **updates)


def evaluate_alerts_for_schedule(schedule_id: int, execution_result: Dict[str, Any]) -> List[Dict]:
    """Post-execution: check alert rules for the given schedule's source report.

    Returns list of triggered alerts.
    """
    if not _db_manager:
        return []

    schedule = _db_manager.get_schedule(schedule_id)
    if not schedule or not schedule.get("auto_evaluate_alerts"):
        return []

    report_id = schedule.get("source_id")
    source_type = schedule.get("source_type", "")
    if source_type != "business_report":   # FB-60: 'report' is decommissioned
        return []

    # Get alert rules for this report
    try:
        rules = [r for r in _db_manager.list_alert_rules(report_id=report_id) if r.get("is_enabled", True)]
    except Exception:
        rules = []

    if not rules:
        return []

    triggered = []
    for rule in rules:
        try:
            col = rule.get("column_name", "")
            agg_fn = rule.get("aggregation", "").upper()
            operator = rule.get("operator", "")
            threshold = float(rule.get("threshold_value", 0))

            # Extract value from execution result summary
            actual = _extract_metric(execution_result, col, agg_fn)
            if actual is None:
                continue

            if _check_condition(actual, operator, threshold):
                triggered.append({
                    "rule_id": rule["id"],
                    "actual_value": actual,
                    "threshold_value": threshold,
                    "column": col,
                    "operator": operator,
                })
                _fire_alert(rule, actual, threshold)

        except Exception as exc:
            logger.warning("Alert rule %s evaluation failed: %s", rule.get("id"), exc)

    return triggered


#: What a subscription ``frequency`` accepts, in one sentence. AQD-08
#: (2026-09-23): the field is named "frequency" and takes only a cron
#: expression, so "daily" -- the obvious value for a field with that name --
#: was refused with "Invalid cron expression or timezone", which named neither
#: the format nor an example and fused two different causes. The OpenAPI
#: description and the 400 both quote THIS sentence, so they cannot drift.
SCHEDULE_GRAMMAR = (
    "a 5-field cron expression such as '0 6 * * *' (06:00 every day) or "
    "'30 7 * * 1-5' (07:30 on weekdays), or one of the shorthands @hourly, "
    "@daily, @weekly, @monthly, @yearly"
)

_SHORTHAND_WORDS = {"hourly", "daily", "weekly", "monthly", "yearly",
                    "annually", "midnight"}


def schedule_problem(cron_expr: Optional[str], tz: Optional[str] = "UTC") -> Optional[str]:
    """Why ``(cron_expr, tz)`` cannot schedule a send, or None when it can.

    The timezone and the expression are checked SEPARATELY so the message says
    which one is wrong. Nothing is widened: "daily" is still refused, with a
    pointer to the shorthand that means it -- two spellings for one schedule
    would be a second vocabulary to keep in step.
    """
    try:
        from zoneinfo import ZoneInfo
        ZoneInfo(tz or "")
    except Exception:
        return (f"timezone {tz!r} is not a recognised IANA timezone name "
                "(for example UTC, Europe/London, America/New_York)")
    expr = (cron_expr or "").strip()
    try:
        valid = bool(expr) and croniter.is_valid(expr)
    except Exception:
        valid = False
    if valid:
        return None
    hint = ""
    if expr.lower() in _SHORTHAND_WORDS:
        hint = f" -- did you mean '@{expr.lower()}'?"
    return f"frequency {expr!r} is not a schedule: it must be {SCHEDULE_GRAMMAR}{hint}"


def compute_next_send(cron_expr: str, tz: str = "UTC") -> Optional[datetime]:
    """Compute the next send time from a cron expression."""
    try:
        from zoneinfo import ZoneInfo
        local_tz = ZoneInfo(tz)
        now_local = datetime.now(timezone.utc).astimezone(local_tz)
        cron = croniter(cron_expr, now_local)
        next_local = cron.get_next(datetime)
        if next_local.tzinfo is None:
            next_local = next_local.replace(tzinfo=local_tz)
        return next_local.astimezone(timezone.utc)
    except Exception as exc:
        logger.warning("Failed to compute next_send for cron='%s' tz='%s': %s", cron_expr, tz, exc)
        return None


# ── Internal helpers ──────────────────────────────────────────────────────────

def _authorize_delivery(sub: dict) -> Optional[str]:
    """Send-time delivery authorization chokepoint.  Returns error or None.

    Business-report subscriptions: the creator's VIEW access to the report is
    re-validated on every send (the create-time gate lives in
    ``api.subscription_api``; this re-check makes revocation effective — an
    unshared/unpublished report stops being mailed on the next tick).
    Recipient addresses are re-validated against the configured domain
    allowlist (``delivery.allowed_recipient_domains``; empty = allow all).

    Legacy ``report_type="report"`` subscriptions (FB-60, 2026-09-26): the
    parametric entity is decommissioned, so such a row is blocked with the
    decommission reason (recorded as the failure) rather than executed.
    WHOSE permissions apply for business reports: the SUBSCRIPTION
    CREATOR's (authorization-to-distribute — see the module docstring of
    ``core.reports.authorization``); the creator is resolved server-side
    via ``build_principal`` (F1 chokepoint, least-privilege on failure).
    Fail-closed on any resolution error.
    """
    from core.reports.authorization import (
        build_principal, can_view_business_report, validate_recipients,
    )

    invalid = validate_recipients(sub.get("recipient_emails") or [])
    if invalid:
        return ("Recipients violate the delivery audience policy "
                f"(delivery.allowed_recipient_domains): {', '.join(str(i) for i in invalid)}")

    if sub.get("report_type") != "business_report":
        # FB-60 (2026-09-26): a subscription authored against the legacy
        # parametric entity.  Blocked with the reason -- recorded as the
        # delivery failure, so the owner sees WHY instead of a missing mail.
        from core.reports.legacy_parametric import refusal
        return refusal(
            f"subscription report_type {sub.get('report_type')!r}",
            instead="Re-create the subscription against the migrated finance "
                    "report (report_type='business_report').")

    creator = (sub.get("created_by") or "").strip()
    try:
        report = _db_manager.get_business_report(sub["report_id"])
    except Exception as exc:
        return f"Could not resolve business report {sub.get('report_id')}: {exc}"
    if not report:
        return f"Business report {sub.get('report_id')} no longer exists"

    principal = build_principal(creator)
    if not can_view_business_report(report, principal, _db_manager):
        return (f"Subscription creator '{creator}' no longer has view access to "
                f"business report {sub.get('report_id')} — delivery blocked (fail-closed)")
    return None


def _pivot_report_or_none(report_id: int, report_type: str, db) -> Optional[dict]:
    """Return the business-report row when the delivered report is a PIVOT,
    else None.

    Detection is THE SAME signal the interactive download routes use
    (api.business_reports_api.download_business_report_pdf / _excel):
    ``layout_config.report_type == "pivot" and layout_config.pivot_config``.
    One rule, read from the same persisted row — do not add a second spelling
    here; if the two paths could ever disagree, that disagreement is the bug.

    Legacy ``report_type="report"`` subscriptions are never pivots (the
    legacy ``reports`` table has no layout_config/pivot concept) — and
    consulting ``business_reports`` for a LEGACY id would collide with an
    unrelated business report that happens to share the id.

    FAIL-CLOSED: if the row cannot be read we cannot know whether the
    author's document is a crosstab, and silently delivering a flattened
    table is exactly the defect this wiring removes — so a read failure
    raises and the delivery is recorded as FAILED (retried by the ladder),
    never guessed flat.  Note this is not a new dependency: the report row
    was already read moments earlier by both the send-time authorization
    gate and the executor, so a failure here is a genuine mid-delivery loss.
    """
    if report_type != "business_report":
        return None
    _db = db if db is not None else _db_manager
    if _db is None:
        raise RuntimeError(
            "delivery engine has no db to resolve the report layout — "
            "cannot determine whether the document is a pivot (fail-closed)")
    report = _db.get_business_report(report_id)
    if not report:
        raise RuntimeError(
            f"Business report {report_id} disappeared before render — "
            "cannot determine whether the document is a pivot (fail-closed)")
    lc = report.get("layout_config") or {}
    if lc.get("report_type") == "pivot" and lc.get("pivot_config"):
        return report
    return None


def _delivery_fmt_rules(report_id: int, report_type: str, db) -> list:
    """Value-based conditional-format rules for a delivered document.

    Reuses api.business_reports_api._extract_fmt_rules BY IMPORT — one
    spelling of "what does this rule mean"; the evaluator behind it is the
    legacy _apply_conditional_formats, already shared by identity with the
    interactive export routes.

    DELIBERATELY NOT part of _extract_style_and_formats: this engine unpacks
    that tuple into EXACTLY six names inside a try/except that falls back to
    defaults, so widening it would not crash — it would silently blank every
    style on every delivered document.  The six-tuple is pinned by
    tests/test_report_formatting_2026_08_30.py (TestDeliveryEngineContract);
    rules travel through this separate accessor instead.

    Legacy ``report_type="report"`` subscriptions have no style_config /
    conditional_formats concept, and consulting business_reports for a
    LEGACY id could collide with an unrelated business report sharing the
    id — so they resolve to no rules, the same line _pivot_report_or_none
    draws.

    FAIL-CLOSED: for a business_report, failure to read the row RAISES →
    deliver_subscription records the delivery FAILED (retry ladder applies).
    Quietly mailing a document stripped of the author's threshold
    highlights is the same defect class as the flattened-pivot and
    format-swap fallbacks this file already rejects: a loud, recorded,
    retried failure is recoverable; a silently unstyled document is not.
    Note the row was already read moments earlier by the send-time authz
    gate, the executor and _pivot_report_or_none — a failure here is a
    genuine mid-delivery loss, never the steady state.  (Individual
    malformed rules are NOT a failure: _extract_fmt_rules skips them with a
    log line.)
    """
    if report_type != "business_report":
        return []
    from api.business_reports_api import _extract_fmt_rules
    _db = db if db is not None else _db_manager
    if _db is None:
        raise RuntimeError(
            "delivery engine has no db to read conditional-format rules — "
            "cannot deliver a possibly-unstyled document (fail-closed)")
    report = _db.get_business_report(report_id)
    if not report:
        raise RuntimeError(
            f"Business report {report_id} disappeared before render — "
            "cannot read its conditional-format rules (fail-closed)")
    return _extract_fmt_rules(report)


def _augment_delivery_running_calcs(report: dict, rows: list, columns: list,
                                    ds_cols) -> Tuple[list, list, bool]:
    """Append the report's running-calculation columns to delivery rows.

    Returns ``(rows, columns, augmented)``.  Reuses
    api.business_reports_api._augment_rows_with_running_calcs BY IMPORT —
    the ONE implementation of the window semantics (which itself calls
    core/reports/microcube.read_artifact_running_calcs), so the delivered
    column cannot drift from the screen or the interactive export.  That
    helper also owns the PIVOT boundary (calcs are a flat-report feature —
    a pivot report returns the same objects untouched, exactly as the
    interactive exports skip calcs for pivots) and the unrenderable-def
    skip-with-log rule (the screen cannot render those either, so skipping
    keeps delivery == screen).

    A calc-less report gets the VERY SAME input objects back (augmented =
    False) — byte-identical delivery, historical renderer call shapes.

    FAIL-CLOSED (``ds_cols is None`` = the style/columns read failed
    upstream): a report that DECLARES running calculations whose dataset
    columns cannot be resolved must FAIL the delivery — the id→name mapping
    is what renders the calc, and silently mailing the document without the
    column the report exists for is the flattened-pivot defect class this
    file already rejects.  ``[]`` is NOT a failure: it means the dataset
    genuinely has no columns, where the interactive path skips id-keyed
    calcs too (parity, logged by the imported helper).
    """
    rcs = (report or {}).get("running_calculations") or []
    if not rcs:
        return rows, columns, False
    if ds_cols is None:
        raise RuntimeError(
            "report declares running calculations but its dataset columns "
            "could not be resolved — failing the delivery rather than "
            "silently mailing the document without its calculated columns")
    from api.business_reports_api import _augment_rows_with_running_calcs
    new_rows, new_cols = _augment_rows_with_running_calcs(
        rows, columns, report, ds_cols)
    return new_rows, new_cols, new_cols is not columns


def _delivery_running_calcs_expected(report_id: int, report_type: str,
                                     db) -> Optional[dict]:
    """The business-report row when the delivered document is EXPECTED to
    carry running-calculation columns (non-pivot business report declaring
    at least one), else None.

    Used by the paths that CANNOT carry the calcs (the bare PDF fallback,
    the bare Excel export) to decide between historical behaviour and a
    loud failure.  Declaration-based on purpose: renderability of each def
    needs ds_cols + the styled machinery, which is exactly what is broken
    or unwired when these paths run — fail-closed, same posture as
    _delivery_fmt_rules.  Mirrors that accessor's boundaries: legacy
    ``report_type="report"`` subscriptions have no running-calc concept
    (and a business_reports read for a legacy id could collide with an
    unrelated report sharing the id); PIVOT reports deliberately take no
    calcs — the same line the interactive exports draw
    (_running_calc_defs_for_export returns [] for pivots).

    FAIL-CLOSED: an unreadable row RAISES → the delivery is recorded FAILED
    and retried, never guessed calc-less.
    """
    if report_type != "business_report":
        return None
    _db = db if db is not None else _db_manager
    if _db is None:
        raise RuntimeError(
            "delivery engine has no db to read running calculations — "
            "cannot deliver a possibly calc-less document (fail-closed)")
    report = _db.get_business_report(report_id)
    if not report:
        raise RuntimeError(
            f"Business report {report_id} disappeared before render — "
            "cannot read its running calculations (fail-closed)")
    if not (report.get("running_calculations") or []):
        return None
    # PIVOT boundary: same signal + same outcome as the interactive path
    # (calcs are a flat-report feature; the pivot renders a matrix).
    if ((report.get("layout_config") or {}).get("report_type")) == "pivot":
        return None
    return report


def _delivery_banding_expected(report_id: int, report_type: str,
                               db) -> Optional[dict]:
    """The business-report row when the delivered document is EXPECTED to
    be BANDED (non-pivot business report declaring section_definitions),
    else None — the banding twin of _delivery_running_calcs_expected, with
    the same boundaries for the same reasons:

    * Declaration-based on purpose: renderability of each band needs
      ds_cols + the styled machinery, which is exactly what is broken or
      unwired when the bare fallbacks consult this — fail-closed.  (Where
      the styled machinery IS available, _banding_spec judges renderability
      and discloses every skipped band on the document, same as the
      interactive routes.)
    * Legacy ``report_type="report"`` subscriptions have no
      section_definitions concept, and a business_reports read for a legacy
      id could collide with an unrelated report sharing the id.
    * PIVOT reports take no banding — sections are a FLAT-report feature
      (the crosstab carries its own row/col/grand totals); _banding_spec
      draws the identical line for the interactive exports.

    FAIL-CLOSED: an unreadable row RAISES → the delivery is recorded FAILED
    and retried, never guessed flat.  A silently flat document under a
    report the author designed as banded is the flattened-pivot defect
    class this file already rejects.
    """
    if report_type != "business_report":
        return None
    _db = db if db is not None else _db_manager
    if _db is None:
        raise RuntimeError(
            "delivery engine has no db to read section definitions — "
            "cannot deliver a possibly-flat document (fail-closed)")
    report = _db.get_business_report(report_id)
    if not report:
        raise RuntimeError(
            f"Business report {report_id} disappeared before render — "
            "cannot read its section definitions (fail-closed)")
    if not (report.get("section_definitions") or []):
        return None
    if ((report.get("layout_config") or {}).get("report_type")) == "pivot":
        return None
    return report


def _render_pivot_delivery_bytes(df, name: str, fmt: str, report: dict, db,
                                 truncation_note: str = "") -> bytes:
    """Render a pivot business report to PDF/Excel bytes for delivery.

    Reuses the INTERACTIVE export renderers by import
    (api.business_reports_api._build_pivot_matrix / _render_pivot_pdf_bytes /
    _render_pivot_excel_bytes) so the emailed document is the same crosstab —
    merged column-group headers, row/col/grand totals, style_config colors —
    the author signed off on screen.  Never a reimplementation.

    FAILURE MODE — FAIL THE DELIVERY, never fall back flat: any exception
    here propagates to deliver_subscription's render try/except, which
    records a delivery FAILURE for every recipient and lets the retry ladder
    advance/deactivate.  Justification: a flat table under a document the
    recipient expects to be pivoted misrepresents the signed-off report
    (wrong shape, missing totals) — the same defect class as bursting's old
    CSV-on-PDF-failure fallback, which was removed as a defect because it
    returned success for the wrong artifact.  A loud, recorded, retried
    failure is recoverable; a quietly wrong document is not.
    """
    # Running calculations (GAP-2 2026-08-30) are DELIBERATELY NOT applied
    # here either: the interactive exports skip calcs for pivots (calcs are
    # a flat-report feature — _running_calc_defs_for_export returns [] for
    # a pivot report; row-sequential windows have no meaning over a
    # crosstab's aggregated cells).  Delivery keeps that exact boundary.
    #
    # Value-based conditional formats (style_config.conditional_formats) are
    # DELIBERATELY NOT applied here.  The legacy rule semantics are
    # ROW-LEVEL — a rule tests one source row's cell value — while every
    # pivot cell is an AGGREGATE over many rows: colouring SUM(sales)
    # against a threshold the author wrote for per-row sales would silently
    # mean something different.  The interactive pivot exports draw exactly
    # the same line (business_reports_api passes fmt_rules only on the flat
    # _render_pdf_bytes/_render_excel_bytes branches, never the pivot ones).
    from api.business_reports_api import (
        _build_pivot_matrix, _extract_style_and_formats,
        _render_pivot_excel_bytes, _render_pivot_pdf_bytes,
    )
    from core.json_utils import sanitize_for_json

    _db = db if db is not None else _db_manager
    # ds_cols is load-bearing for the matrix (column_id → physical_name):
    # a failure here would mis-key every dimension, so it propagates too.
    hdr_bg, hdr_txt, neg_fmt, stripe, col_fmt_map, ds_cols = \
        _extract_style_and_formats(report, _db)
    rows = sanitize_for_json(df.to_dict(orient="records"))
    pivot_config = (report.get("layout_config") or {})["pivot_config"]
    matrix = _build_pivot_matrix(rows, pivot_config, ds_cols)
    if fmt == "pdf":
        return _render_pivot_pdf_bytes(
            matrix, name, hdr_bg, hdr_txt,
            config.business_reports.pdf_page_size,
            neg_fmt, col_fmt_map,
            disclosure_text=truncation_note)
    return _render_pivot_excel_bytes(
        matrix, name, hdr_bg, hdr_txt, neg_fmt, stripe, col_fmt_map,
        disclosure_text=truncation_note)


def _render_output(df, name: str, params: dict, fmt: str,
                   report_id: int, report_type: str = "business_report",
                   db=None, truncation_note: str = "") -> Tuple[bytes, str, str]:
    """Render a DataFrame to bytes in the requested format.

    Returns (data_bytes, filename, content_type).

    2026-08-30 pivot parity: a pivot business report (detected via
    _pivot_report_or_none — the interactive routes' own signal) renders
    through the interactive crosstab renderers for PDF and Excel, so the
    delivered document matches the on-screen / downloaded one.  Non-pivot
    reports take the pre-existing flat paths unchanged.

    CSV stays FLAT even for pivots — DELIBERATE: CSV is a data format, not a
    document; the flat GROUP BY rows are the loadable/joinable truth, and a
    crosstab serialized to CSV (merged headers, total rows mixed with data)
    would corrupt any downstream consumer.  The interactive path draws the
    same line: only its PDF/Excel exports pivot.
    """
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_name = name.replace(" ", "_").replace("/", "_")[:80]

    pivot_report = None
    if fmt in ("pdf", "excel"):
        pivot_report = _pivot_report_or_none(report_id, report_type, db)

    if fmt == "pdf":
        if pivot_report is not None:
            pdf_bytes = _render_pivot_delivery_bytes(
                df, name, "pdf", pivot_report, db, truncation_note)
        elif _pdf_render_fn:
            pdf_bytes = _pdf_render_fn(df, name, params, report_id)
        else:
            # Fallback: simple HTML table.  This bare path CANNOT carry
            # value-based conditional formats — if the author configured
            # rules, fail the delivery loudly (fail-closed, see
            # _delivery_fmt_rules) instead of mailing them stripped.
            if _delivery_fmt_rules(report_id, report_type, db):
                raise RuntimeError(
                    "report has conditional-format rules but no styled PDF "
                    "renderer is wired — failing the delivery rather than "
                    "mailing an unstyled document")
            # …nor running-calculation columns (GAP-2 2026-08-30): the bare
            # df.to_html path renders raw rows only, and a delivered
            # document missing the cumulative column the report exists for
            # silently disagrees with the screen — fail loud instead.
            if _delivery_running_calcs_expected(
                    report_id, report_type, db) is not None:
                raise RuntimeError(
                    "report declares running calculations but no styled PDF "
                    "renderer is wired — failing the delivery rather than "
                    "mailing a document without its calculated columns")
            # …nor banded layout (GAP-4 2026-08-30): the bare df.to_html
            # path renders a flat table only, and a flat document under a
            # report the author designed as banded (group headers,
            # subtotals, grand total) is the flattened-pivot defect class —
            # fail loud instead.
            if _delivery_banding_expected(
                    report_id, report_type, db) is not None:
                raise RuntimeError(
                    "report declares section definitions (banded layout) "
                    "but no styled PDF renderer is wired — failing the "
                    "delivery rather than mailing a flat document")
            # 2026-10-04: through THE door (core.reports.pdf_engine.render_pdf)
            # -- a budgeted child process, so a document too large for this
            # pod fails the delivery instead of OOM-killing the scheduler.
            from core.reports.pdf_engine import render_pdf
            html = f"<h2>{name}</h2>" + df.head(config.delivery.max_pdf_rows).to_html(index=False)
            pdf_bytes = render_pdf(html)
        return pdf_bytes, f"{safe_name}_{ts}.pdf", "application/pdf"

    elif fmt == "excel":
        if pivot_report is not None:
            # NO try/except: a failed pivot render must FAIL the delivery
            # (see _render_pivot_delivery_bytes), never fall through to the
            # bare flat export below.
            excel_bytes = _render_pivot_delivery_bytes(
                df, name, "excel", pivot_report, db, truncation_note)
            return excel_bytes, f"{safe_name}_{ts}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        # 2026-08-30 conditional formats: rules are resolved OUTSIDE the
        # styled-render try/except below, through their own accessor (never
        # the pinned six-tuple).  A failure to determine the author's rules
        # must FAIL the delivery — the bare fallback under the except cannot
        # carry them, and silently mailing a workbook stripped of its
        # threshold highlights is the flattened-pivot / format-swap defect
        # class.  Rule-less reports keep every historic path byte-identical.
        fmt_rules = _delivery_fmt_rules(report_id, report_type, db)
        # GAP-2 (2026-08-30) running calculations: resolved OUTSIDE the
        # styled try/except below through their own accessor, exactly like
        # fmt_rules (and NEVER by widening the pinned six-tuple).  When the
        # report declares calcs, the styled render is the only flat-Excel
        # path that can carry the columns — any fall-through to the bare
        # export must FAIL the delivery instead of silently mailing a
        # workbook without the cumulative column the recipient subscribed
        # for.  Calc-less reports keep every historic path byte-identical.
        rc_expected = _delivery_running_calcs_expected(report_id, report_type, db)
        # GAP-4 (2026-08-30) banded layout: resolved OUTSIDE the styled
        # try/except through its own accessor, exactly like fmt_rules and
        # rc_expected (and NEVER by widening the pinned six-tuple).  When
        # the report declares sections, the styled render is the only
        # flat-Excel path that can carry the banded document — any
        # fall-through to the bare export must FAIL the delivery instead of
        # silently mailing the flat table the author designed away.
        # Section-less reports keep every historic path byte-identical.
        band_expected = _delivery_banding_expected(report_id, report_type, db)
        # Phase 113-E: Try styled Excel rendering with report colors
        try:
            from api.business_reports_api import (
                _render_excel_bytes, _extract_style_and_formats,
                _banding_spec, _section_sort_rows, _banded_disclosure_suffix,
            )
            _db = _db_manager
            report = _db.get_business_report(report_id) if _db and report_id else None
            if report:
                # EXACTLY six names — see _delivery_fmt_rules; ds_cols is
                # the tuple's existing sixth element, not a widening.
                hdr_bg, hdr_txt, neg_fmt, stripe, col_fmt_map, ds_cols = _extract_style_and_formats(report, _db)
                rows = df.to_dict(orient="records")
                columns = list(df.columns)
                # GAP-4 (2026-08-30) banded layout via the interactive
                # helpers BY IMPORT — one "what is a band" (_banding_spec),
                # one grouping/total engine (_banded_layout inside
                # _render_excel_bytes): the emailed workbook groups and
                # subtotals exactly as the interactive download.  Section
                # sort BEFORE the running calcs (same order as the
                # interactive route) so calc columns accumulate over the
                # banded display order.  Section-less reports get spec None
                # → historical call shape, byte-identical.  The PIVOT
                # boundary lives inside _banding_spec (pivots carry their
                # own totals and never reach this flat branch anyway).
                _band_spec, _band_notes = _banding_spec(report, ds_cols,
                                                        columns)
                if _band_spec:
                    rows = _section_sort_rows(rows, _band_spec["defs"])
                # Calc columns over EXACTLY the rows in this document (df is
                # already cut at delivery.max_pdf_rows) — same values, same
                # display order as the screen / interactive download.  A
                # failure propagates: with calcs declared it re-raises out
                # of this try (original exception recorded), never the bare
                # fallback.
                rows, columns, _rc_aug = _augment_delivery_running_calcs(
                    report, rows, columns, ds_cols)
                # TRUNCATION POSTURE = the interactive one: a cut workbook
                # carrying calc columns or banded totals states IN the
                # document that those numbers cover only the included rows,
                # appended to the truncation banner (totals over a
                # truncated set are a different number — the document must
                # say whose rows they cover).  Unrenderable bands are never
                # silently dropped: their _banding_spec notes ride the
                # banner even untruncated.  Plain deliveries keep the
                # historical call shape (no disclosure kwarg) byte-for-byte.
                _rc_disc = ""
                if _rc_aug or _band_spec or _band_notes:
                    from api.business_reports_api import \
                        _running_calc_disclosure_suffix
                    _rc_disc = (truncation_note
                                + _running_calc_disclosure_suffix(
                                    _rc_aug, bool(truncation_note))
                                + _banded_disclosure_suffix(
                                    bool(_band_spec), bool(truncation_note)))
                    if _band_notes:
                        _rc_disc += " " + " ".join(_band_notes)
                # kwarg only when rules exist — a rule-less report keeps the
                # historical call shape (closed-signature doubles survive).
                excel_bytes = _render_excel_bytes(rows, columns, name, hdr_bg, hdr_txt,
                                                  neg_fmt, stripe, col_fmt_map,
                                                  **({"fmt_rules": fmt_rules}
                                                     if fmt_rules else {}),
                                                  **({"sections": _band_spec}
                                                     if _band_spec else {}),
                                                  **({"disclosure_text": _rc_disc}
                                                     if _rc_disc else {}))
                return excel_bytes, f"{safe_name}_{ts}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        except Exception:
            if fmt_rules or rc_expected is not None or band_expected is not None:
                # The styled render is the ONLY flat-Excel path that can
                # carry the rules / the calc columns / the banded layout —
                # falling through would strip them.
                raise
            # else: fall back to bare export (rule-less: historic behaviour)
        if fmt_rules:
            # Styled path was skipped without an exception (e.g. the
            # module-global db is unwired while the caller's db could read
            # the rules) — the bare export below cannot carry the rules.
            raise RuntimeError(
                "conditional-format rules resolved but the styled Excel "
                "renderer was unavailable — failing the delivery rather "
                "than mailing an unstyled document")
        if rc_expected is not None:
            # Same skip-without-exception hole, calc flavour: the bare
            # df.to_excel export below cannot carry the calc columns.
            raise RuntimeError(
                "running calculations resolved but the styled Excel "
                "renderer was unavailable — failing the delivery rather "
                "than mailing a document without its calculated columns")
        if band_expected is not None:
            # Same skip-without-exception hole, banding flavour: the bare
            # df.to_excel export below cannot carry the banded layout.
            raise RuntimeError(
                "section definitions resolved but the styled Excel "
                "renderer was unavailable — failing the delivery rather "
                "than mailing a flat document")
        buf = io.BytesIO()
        df.to_excel(buf, index=False, engine="openpyxl")
        return buf.getvalue(), f"{safe_name}_{ts}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    else:  # csv
        # DELIBERATELY FLAT even when the report is a pivot: CSV is a data
        # format, not a document — recipients load/join it, and a serialized
        # crosstab (merged headers, totals interleaved with data) would break
        # them.  The interactive export draws the same PDF/Excel-only line.
        # Value-based conditional formats likewise do not apply: CSV has no
        # presentation channel AT ALL (no fills, fonts or styles exist in
        # the format), so an unstyled CSV is the correct document, not a
        # stripped one — nothing to fail closed over.
        #
        # Banded layout (GAP-4 2026-08-30) likewise does NOT apply: group
        # header rows, subtotal rows and a grand-total row interleaved with
        # the data would corrupt every downstream parser — CSV stays the
        # flat, loadable truth.  The interactive CSV export draws exactly
        # the same line (no _banding_spec / _section_sort_rows on its
        # route), so a delivered CSV and a downloaded CSV stay identical.
        #
        # Running calculations DO apply (GAP-2 2026-08-30): they are DATA
        # columns, not presentation, and the interactive CSV download
        # carries them — a subscribed CSV without them would disagree with
        # the downloaded one.  Only the calc columns are APPENDED to a copy
        # of the frame (original columns keep their dtypes → calc-less
        # reports and legacy/pivot reports serialize byte-identically to
        # today).  CSV keeps the house disclosure posture: the format
        # cannot carry an in-file note, so the calcs-over-included-rows
        # fact rides where CSV truncation already does (e-mail body note +
        # [br-serve] log).  A failure raises → delivery recorded FAILED,
        # never a document silently missing its calculated columns.
        rc_report = _delivery_running_calcs_expected(report_id, report_type, db)
        if rc_report is not None:
            from api.business_reports_api import _extract_style_and_formats
            _db = db if db is not None else _db_manager
            # ds_cols only (the tuple's sixth element) — same spelling as
            # the interactive CSV route; styles are meaningless in CSV.
            ds_cols = _extract_style_and_formats(rc_report, _db)[5]
            rows = df.to_dict(orient="records")
            aug_rows, aug_cols, _rc_aug = _augment_delivery_running_calcs(
                rc_report, rows, list(df.columns), ds_cols)
            if _rc_aug:
                df = df.copy()
                for _cn in aug_cols[len(df.columns):]:
                    df[_cn] = [r.get(_cn) for r in aug_rows]
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        return buf.getvalue().encode("utf-8"), f"{safe_name}_{ts}.csv", "text/csv"


def _truncation_note(df, cap: int) -> str:
    """Human-readable truncation disclosure for a delivered DataFrame.

    Returns "" when the delivery is definitely complete.  States both sides
    of the problem in real numbers and names the actions that change the
    outcome (the ``format_refusal`` model): what was cut, by which knob, and
    what to do about it.
    """
    try:
        attrs = getattr(df, "attrs", {}) or {}
        n = len(df)
        if attrs.get("qs_truncated"):
            total = attrs.get("qs_total_rows")
            limit = attrs.get("qs_row_limit") or cap
            return (f"This delivery contains the first {n:,} rows of a "
                    f"{total:,}-row result — the delivery row limit "
                    f"(delivery.max_pdf_rows = {limit:,}) truncated it. "
                    "Add filters or parameters to the report so the full "
                    "result fits, or ask your administrator to raise the "
                    "delivery row limit.")
        if "qs_truncated" in attrs:
            return ""  # executor declared it complete — trust the declaration
        # Legacy executors don't declare; at-the-cap is honestly "may be cut".
        if cap and n >= int(cap):
            return (f"The delivery row limit ({int(cap):,} rows, "
                    "delivery.max_pdf_rows) was reached — the attached file "
                    "may be incomplete. Add filters to the report or ask "
                    "your administrator to raise the delivery row limit.")
        return ""
    except Exception as exc:
        logger.debug("truncation note skipped: %s", exc)
        return ""


#: Recorded when an injected sender returns False and states no reason of its
#: own.  Still better than the old "Email send returned False": it says the
#: cause is unknown rather than implying the function's return value IS one.
_UNSTATED_SEND_FAILURE = ("the mail sender reported a failure without "
                          "stating a reason")


def _send_failure_reason() -> str:
    """The cause of the send that just returned False on this thread."""
    try:
        from core.email_service import last_send_failure_reason
        return last_send_failure_reason() or _UNSTATED_SEND_FAILURE
    except Exception:
        return _UNSTATED_SEND_FAILURE


def _send_to_recipients(sub: dict, data_bytes: bytes, filename: str,
                        content_type: str,
                        truncation_note: str = "",
                        reasons_out: Optional[list] = None) -> Tuple[int, int]:
    """Email the attachment to each recipient, recording delivery records.

    AQD-09 (2026-09-23): a failed send records WHY -- "the e-mail service is
    not configured (config email.host / email.enabled)", or the relay's own
    SMTP error -- instead of "Email send returned False", which named the
    function's return value as if it were a cause.  ``reasons_out``, when
    given, collects each distinct reason so the caller's total-failure error
    can carry it to the API response.
    """
    recipients = sub.get("recipient_emails") or []
    sent_count = 0
    fail_count = 0
    sub_id = sub["id"]

    subject = f"Report Delivery: {sub['name']}"
    html_body = _build_delivery_html(sub, filename,
                                     truncation_note=truncation_note)

    def _note(reason: str) -> None:
        if reasons_out is not None and reason not in reasons_out:
            reasons_out.append(reason)

    for email_addr in recipients:
        try:
            try:
                from core.email_service import clear_send_failure_reason
                clear_send_failure_reason()
            except Exception:
                pass
            ok = _email_send_fn(
                to_addresses=[email_addr],
                subject=subject,
                html_body=html_body,
                attachments=[(data_bytes, filename, content_type)],
            )
            if ok:
                _db_manager.record_subscription_delivery(
                    subscription_id=sub_id,
                    recipient_email=email_addr,
                    status="sent",
                    sent_at=datetime.now(timezone.utc),
                    file_size_bytes=len(data_bytes),
                )
                sent_count += 1
            else:
                reason = _send_failure_reason()
                _note(reason)
                _db_manager.record_subscription_delivery(
                    subscription_id=sub_id,
                    recipient_email=email_addr,
                    status="failed",
                    error_message=reason[:500],
                )
                fail_count += 1
        except Exception as exc:
            _note(str(exc)[:500])
            _db_manager.record_subscription_delivery(
                subscription_id=sub_id,
                recipient_email=email_addr,
                status="failed",
                error_message=str(exc)[:500],
            )
            fail_count += 1

    return sent_count, fail_count


def _record_failures(sub_id: int, recipients: list, error: str):
    """Record failure delivery records for all recipients."""
    for email_addr in recipients:
        try:
            _db_manager.record_subscription_delivery(
                subscription_id=sub_id,
                recipient_email=email_addr,
                status="failed",
                error_message=error[:500],
            )
        except Exception:
            pass


def _build_delivery_html(sub: dict, filename: str,
                         truncation_note: str = "") -> str:
    """Build the HTML email body for a subscription delivery.

    ``truncation_note`` (2026-08-05 audit): non-empty when the attachment is
    (or may be) an incomplete cut of the full result — rendered as a visible
    warning row so a truncated report can never present itself as complete.
    """
    _trunc_html = ""
    if truncation_note:
        _trunc_html = (
            '<div style="background: #fef3c7; border: 1px solid #f59e0b; '
            'border-radius: 6px; padding: 12px; margin: 12px 0; '
            'color: #92400e; font-size: 13px;">'
            f"⚠ {truncation_note}</div>"
        )
    return f"""
    <div style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: #1e40af; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
        <h2 style="margin: 0;">QueryStudio Report Delivery</h2>
      </div>
      <div style="background: #f8fafc; padding: 20px; border: 1px solid #e2e8f0;">
        <p>Your scheduled report <strong>{sub['name']}</strong> is attached.</p>
        {_trunc_html}
        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
          <tr><td style="padding: 6px 12px; color: #64748b;">Report</td><td style="padding: 6px 12px; font-weight: 600;">{sub['name']}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">Format</td><td style="padding: 6px 12px;">{sub.get('output_format', 'csv').upper()}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">File</td><td style="padding: 6px 12px;">{filename}</td></tr>
          <tr><td style="padding: 6px 12px; color: #64748b;">Delivered</td><td style="padding: 6px 12px;">{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}</td></tr>
        </table>
        <p style="font-size: 12px; color: #94a3b8;">
          To unsubscribe, click <a href="{{{{unsubscribe_url}}}}">here</a> or contact your administrator.
        </p>
      </div>
    </div>
    """


def _extract_metric(result: Dict, column: str, agg_fn: str) -> Optional[float]:
    """Extract a metric value from an execution result for alert evaluation."""
    summary = result.get("summary") or result.get("stats") or {}
    if column in summary:
        return float(summary[column])

    # Try to compute from rows
    rows = result.get("rows") or result.get("data") or []
    if not rows or column not in (rows[0] if rows else {}):
        return None

    values = [r[column] for r in rows if r.get(column) is not None]
    if not values:
        return None

    try:
        nums = [float(v) for v in values]
    except (ValueError, TypeError):
        return None

    if agg_fn == "SUM":
        return sum(nums)
    elif agg_fn == "AVG":
        return sum(nums) / len(nums) if nums else None
    elif agg_fn == "MAX":
        return max(nums)
    elif agg_fn == "MIN":
        return min(nums)
    elif agg_fn == "COUNT":
        return float(len(nums))
    return None


def _check_condition(actual: float, operator: str, threshold: float) -> bool:
    """Evaluate an alert condition."""
    if operator == ">":
        return actual > threshold
    elif operator == ">=":
        return actual >= threshold
    elif operator == "<":
        return actual < threshold
    elif operator == "<=":
        return actual <= threshold
    elif operator == "==":
        return actual == threshold
    elif operator == "!=":
        return actual != threshold
    return False


def _fire_alert(rule: dict, actual: float, threshold: float):
    """Send alert notification via configured channels."""
    channels = rule.get("channels") or []
    rule_id = rule.get("id")
    col = rule.get("column_name", "")
    op = rule.get("operator", "")

    msg = f"Alert: {col} {op} {threshold} (actual: {actual:.2f})"

    # Record in alert history
    try:
        _db_manager.record_alert(
            rule_id=rule_id,
            actual_value=actual,
            threshold_value=threshold,
            channel=",".join(channels),
            sent_to=rule.get("recipients", ""),
            suppressed=False,
        )
    except Exception as exc:
        logger.warning("Failed to record alert history: %s", exc)

    # Email
    if "email" in channels and rule.get("recipients"):
        recipients = [r.strip() for r in rule["recipients"].split(",") if r.strip()]
        try:
            from core.email_service import send_email
            send_email(
                to_addresses=recipients,
                subject=f"QueryStudio Alert: {col}",
                html_body=f"<p>{msg}</p><p>Rule ID: {rule_id}</p>",
            )
        except Exception as exc:
            logger.warning("Alert email failed: %s", exc)

    # Webhook
    if "webhook" in channels and rule.get("slack_webhook") and _webhook_fire_fn:
        try:
            _webhook_fire_fn(
                url=rule["slack_webhook"],
                payload={"text": msg, "rule_id": rule_id},
            )
        except Exception as exc:
            logger.warning("Alert webhook failed: %s", exc)
