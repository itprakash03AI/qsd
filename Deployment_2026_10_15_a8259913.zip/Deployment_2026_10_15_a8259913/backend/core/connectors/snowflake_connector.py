"""
Snowflake connector.

Required config keys:
  account       – Snowflake account identifier (e.g. "xy12345.us-east-1")
  user          – Snowflake username
  auth_type     – "password" | "key_pair" | "oauth" | "sso_portal"
  password      – for password auth
  private_key   – PEM private key string (for key_pair auth); "\n"-escaped,
                  CRLF and bare-base64 forms are accepted (_pem_from_key_text),
                  and it may come from a System Account's Vault kv entry
                  (core.connectors.get_connector maps it)
  private_key_passphrase – optional passphrase for private key
  token         – for oauth
  system_account_id – for sso_portal (references SystemAccount in DB)
  warehouse     – virtual warehouse name (optional)
  database      – default database (optional)
  schema        – default schema (optional)
  role          – Snowflake role (optional)
  login_timeout – seconds, default 30
  network_timeout – seconds; UNSET by default (see _connect: 60 cancelled every
                    query that ran longer than a minute)
"""

import logging
import re
from typing import Any, Dict, List, Optional

from .base import SqlConnector, unique_column_names, DriverNotInstalled


_QUOTE = '"'   # identifier quote for this dialect
_LITQ = "'"


def _qi(name):
    """Quote ONE identifier -- but only when it actually needs quoting.

    2026-08-20 -- catalog/schema/table were interpolated BARE into SHOW and
    DESCRIBE.  The Trino connector got a quoter on 2026-08-19 and the commit
    claimed the audit lens had been applied to Snowflake/Databricks too; it
    had not.  Any name needing quoting (a hyphen, a reserved word) failed on
    browse, and since these values arrive from an authenticated user's
    connection config they were an injection surface running under that
    connection's own credentials.

    CONDITIONAL on purpose.  Quoting unconditionally would be a REGRESSION
    here: unquoted identifiers case-FOLD (Snowflake upper-folds, Databricks
    lower-folds) while quoted ones are case-SENSITIVE, so wrapping a plain
    `mydb` in quotes turns a working browse into "object does not exist".
    A bare-safe name is therefore passed through byte-identical -- current
    behaviour, preserved exactly -- and only a name that could not have
    worked before (or could have injected) is quoted.

    2026-08-20 (third pass) -- delegates to the ONE shared implementation in
    base.py.  Three verbatim local copies of the bare-safe test had already
    drifted; the shared one also quotes RESERVED WORDS (``_qi("order")``
    used to pass bare -> parse error on ``DESCRIBE TABLE db.sch.order``),
    upper-folding them first because that is what Snowflake would have done
    to the bare spelling.  ``allow_dollar=True``: Snowflake is the one
    dialect where ``$`` is bare-legal.
    """
    from .base import quote_identifier
    return quote_identifier(name, quote=_QUOTE, fold=str.upper,
                            allow_dollar=True)


def _exact_retry_spellings(exc, catalog, schema, table):
    """Case-exact spellings to try after a bare one was not found -- or [].

    Only for an object-does-not-exist error (002003) and only when a part
    holds a lower-case letter: Snowflake stores every unquoted name
    upper-case, so that part can only exist as a QUOTED name and the bare
    spelling folded it away.  The TABLE quoted exactly first (its name came
    from SHOW TABLES as stored; a database / schema may be a lower-case
    spelling typed into the connection), then every part.  Every other
    failure is not ours to retry."""
    try:
        errno = int(getattr(exc, "errno", 0) or 0)
    except (TypeError, ValueError):
        errno = 0
    parts = (catalog, schema, table)
    if errno != 2003 or not any(str(p) != str(p).upper() for p in parts):
        return []
    def exact(p):
        return '"' + str(p).replace('"', '""') + '"'
    out = []
    if str(table) != str(table).upper():
        out.append(f"{_qi(catalog)}.{_qi(schema)}.{exact(table)}")
    every = ".".join(exact(p) for p in parts)
    if every not in out:
        out.append(every)
    return out


def _ql(value):
    """Quote a string LITERAL (SHOW ... LIKE takes one, not an identifier)."""
    s = str(value)
    return _LITQ + s.replace(_LITQ, _LITQ + _LITQ) + _LITQ


logger = logging.getLogger(__name__)


def _column_index(description, name: str, fallback: int) -> int:
    """Where column ``name`` sits in a SHOW / DESCRIBE result -- BY NAME.

    2026-10-03 -- ``list_tables`` read SHOW TABLES by POSITION (name=1,
    kind=4) and, on a layout that puts ``kind`` third, reported the table's
    type as the SCHEMA name (``'type': 'FIN'``).  It is the same class as
    the 2026-08-19 ``cluster_by``/``owner`` defect in ``detect_partitions``:
    a SHOW command's column order is Snowflake's to change (columns are
    added release by release; TERSE variants drop most of them), its column
    NAMES are the contract.  The documented position is only a fallback for
    a cursor that carries no description.
    """
    try:
        cols = [str(d[0]).lower() for d in (description or [])]
        if name in cols:
            return cols.index(name)
    except Exception:
        pass
    return fallback


def _cell(row, idx: int, default=None):
    return row[idx] if idx < len(row) else default


def _close_quietly(cur) -> None:
    try:
        cur.close()
    except Exception as exc:
        logger.debug("Snowflake cursor close failed: %s", exc)


#: One PEM block anywhere in the text (a Vault value may carry quotes or a
#: trailing note around it); the END label must match the BEGIN label.
_PEM_BLOCK = re.compile(r"-----BEGIN ([A-Z0-9 ]+)-----(.*?)-----END \1-----", re.S)
_B64_BODY = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")


def _der_key_label(der: bytes) -> Optional[str]:
    """The PEM label a DER private key carries, read from its ASN.1 shape --
    or None when the bytes are not one private key.

    EncryptedPrivateKeyInfo is SEQUENCE { SEQUENCE alg, OCTET STRING };
    PKCS#8 PrivateKeyInfo is SEQUENCE { INTEGER 0, SEQUENCE alg, ... };
    PKCS#1 RSAPrivateKey is SEQUENCE { INTEGER 0, INTEGER n, ... }.  The
    outer SEQUENCE must span the whole buffer, so random base64 that
    happens to decode is refused rather than wrapped."""
    def _header(i):
        if i + 2 > len(der):
            return None
        tag, length, i = der[i], der[i + 1], i + 2
        if length & 0x80:
            n = length & 0x7F
            if n == 0 or n > 4 or i + n > len(der):
                return None
            length, i = int.from_bytes(der[i:i + n], "big"), i + n
        if i + length > len(der):
            return None
        return tag, i, length

    outer = _header(0)
    if not outer or outer[0] != 0x30 or outer[1] + outer[2] != len(der):
        return None
    first = _header(outer[1])
    if not first:
        return None
    if first[0] == 0x30:
        return "ENCRYPTED PRIVATE KEY"
    if first[0] != 0x02:
        return None
    second = _header(first[1] + first[2])
    if not second:
        return None
    if second[0] == 0x30:
        return "PRIVATE KEY"
    if second[0] == 0x02:
        return "RSA PRIVATE KEY"
    return None


def _pem_block(label: str, b64: str, headers=()) -> bytes:
    lines = [f"-----BEGIN {label}-----", *headers]
    if headers:
        lines.append("")
    lines += [b64[i:i + 64] for i in range(0, len(b64), 64)]
    lines.append(f"-----END {label}-----")
    return ("\n".join(lines) + "\n").encode()


def _pem_from_key_text(text) -> bytes:
    """THE one place a key-pair private key's TEXT becomes PEM bytes --
    pasted in the form, attached as a file, or read from a Vault kv entry.

    2026-10-03 -- the key now also arrives from Vault, and a kv value is
    rarely the file byte for byte.  Three shapes are accepted:

      * literal ``\\n`` escapes for the line breaks (a value stored through
        JSON, an env var or ``vault kv put key="$(cat k.p8)"`` gone wrong);
      * Windows CRLF / bare CR line breaks;
      * the bare base64 BODY with no BEGIN / END lines -- the label is read
        from the key's own ASN.1 shape (PRIVATE KEY, ENCRYPTED PRIVATE KEY
        or RSA PRIVATE KEY), never guessed.

    A block's body is re-wrapped at 64 characters (a single-line block
    parses too); legacy ``Proc-Type`` / ``DEK-Info`` header lines are kept.
    Anything else is returned as given, so the loader refuses it with the
    connector's own "could not be read" message.  The key text is never
    logged or put into an exception here."""
    if isinstance(text, (bytes, bytearray)):
        text = bytes(text).decode("utf-8", "replace")
    s = str(text or "")
    s = s.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n")
    s = s.replace("\r\n", "\n").replace("\r", "\n").strip()
    m = _PEM_BLOCK.search(s)
    if m:
        lines = [ln.strip() for ln in m.group(2).split("\n") if ln.strip()]
        headers = []
        while lines and ":" in lines[0]:
            headers.append(lines.pop(0))
        b64 = "".join("".join(lines).split())
        if not _B64_BODY.match(b64):
            return s.encode()
        return _pem_block(m.group(1), b64, headers)
    b64 = "".join(s.split())
    if not _B64_BODY.match(b64):
        return s.encode()
    import base64
    try:
        der = base64.b64decode(b64, validate=True)
    except Exception:
        return s.encode()
    label = _der_key_label(der)
    return _pem_block(label, b64) if label else s.encode()


def load_private_key_der(key_text, passphrase=None) -> bytes:
    """A key-pair private key (text, as pasted / attached / read from
    Vault) and its optional passphrase -> the unencrypted PKCS#8 DER bytes
    ``snowflake.connector.connect(private_key=...)`` takes.

    Raises ValueError saying which half is wrong, in words a person can act
    on -- never with the key text in it.  Used by the connector at login and
    by the System Account Test of a ``snowflake_keypair`` account
    (``core.connectors.snowflake_key_pair_problem``), so both answer alike."""
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.serialization import (
        Encoding, NoEncryption, PrivateFormat, load_pem_private_key,
    )
    if not str(key_text or "").strip():
        raise ValueError(
            "Snowflake key-pair: no private key -- attach the .p8 key file, paste it, or pick a "
            "System Account whose Vault entry holds private_key")
    pem = _pem_from_key_text(key_text)
    # 2026-10-03 -- found connecting to a REAL account: the form sends an
    # EMPTY passphrase ("") for an unencrypted key, and only a non-empty one
    # was encoded, so "" reached load_pem_private_key as a str ("argument
    # 'password': Cannot convert str to a buffer") -- every key-pair
    # connection without a passphrase failed.  No passphrase is None; a
    # given one is bytes.
    password = str(passphrase).encode() if passphrase else None
    try:
        key = load_pem_private_key(pem, password=password, backend=default_backend())
    except (TypeError, ValueError) as kexc:
        m = str(kexc)
        if "not encrypted" in m:
            why = "a passphrase was given but this private key is not encrypted -- clear the passphrase"
        elif password is not None and ("decrypt" in m.lower() or "password" in m.lower()):
            why = "the passphrase does not open this private key -- check the passphrase"
        elif "encrypted" in m or "password" in m.lower():
            why = "this private key is encrypted -- enter its passphrase"
        else:
            why = ("the private key could not be read -- attach the .p8 key file, or paste the whole "
                   ".p8 file, including the BEGIN PRIVATE KEY / END PRIVATE KEY lines")
        raise ValueError(f"Snowflake key-pair: {why} ({m})") from kexc
    return key.private_bytes(Encoding.DER, PrivateFormat.PKCS8, NoEncryption())


#: Snowflake's internal result type names (``FIELD_ID_TO_NAME``) that are not
#: spellings a user or ``DESCRIBE TABLE`` ever shows.  Rendered as the SQL
#: type so the two type readers of this connector -- the catalog
#: (``list_columns``) and a result (``execute_query``) -- name a column's
#: type the same way.
_SQL_SPELLING = {"FIXED": "NUMBER", "REAL": "FLOAT", "TEXT": "VARCHAR"}


def _result_type_name(d) -> str:
    """A cursor-description entry's type as a Snowflake TYPE NAME.

    2026-10-03 -- both result readers did ``str(d[1])``, and ``d[1]`` is
    the driver's numeric ``type_code``: ``'0'`` for NUMBER, ``'2'`` for
    VARCHAR, ``'3'`` for DATE.  That string is what the connector contract
    calls ``"type"``, so ``core.source_types.driver_data_type`` received
    ``'0'``, recognised nothing, and every Snowflake column's type was
    GUESSED from sample values (a NUMBER column whose first rows were
    NULL became a string).  The Oracle connector had the same defect
    (2026-09-15, ``_column_type_name``).

    The driver ships the mapping (``FIELD_ID_TO_NAME``); FIXED / REAL /
    TEXT are rendered as NUMBER(p,s) / FLOAT / VARCHAR(n) -- what DESCRIBE
    says -- and precision/scale come from the description, so a FIXED
    column with scale 0 reads ``NUMBER(38,0)`` (an integer) and one with
    scale 2 reads ``NUMBER(18,2)``.  An unknown code is reported as
    ``UNKNOWN(<code>)`` -- unknown, not text: ``driver_data_type`` maps it
    to None and the caller samples.
    """
    code = getattr(d, "type_code", None)
    if code is None and len(d) > 1:
        code = d[1]
    if isinstance(code, str) and not code.strip().isdigit():
        return code                                   # already a name
    try:
        from snowflake.connector.constants import FIELD_ID_TO_NAME
        name = FIELD_ID_TO_NAME.get(int(code))
    except Exception:
        name = None
    if not name:
        return f"UNKNOWN({code})"

    def _attr(field, idx):
        v = getattr(d, field, None)
        if v is None and len(d) > idx:
            v = d[idx]
        return v

    precision, scale = _attr("precision", 4), _attr("scale", 5)
    internal_size = _attr("internal_size", 3)
    name = str(name)
    sql = _SQL_SPELLING.get(name, name)
    if name == "FIXED" and precision is not None and scale is not None:
        return f"{sql}({precision},{scale})"
    if name == "TEXT" and internal_size:
        return f"{sql}({internal_size})"
    if (name.startswith("TIMESTAMP") or name == "TIME") and scale is not None:
        return f"{sql}({scale})"
    return sql


#: SQLSTATEs the driver raises when the SESSION, not the statement, is gone:
#: 08001 "connection was not established" (a session / master-token renewal
#: was refused) and 08003 "connection does not exist" (closed locally).
_SESSION_GONE_SQLSTATES = frozenset({"08001", "08003"})
#: ...and the error numbers behind them: 250002 connection is closed, 252007
#: failed to renew session, 390110-390115 id/session/master token
#: expired/not found/invalid (snowflake.connector.network *_GS_CODE).
#: 390111 "Session no longer exists. New login required" is the one a
#: session ENDED server-side raises (idle timeout, SYSTEM$ABORT_SESSION, an
#: admin) -- found on a REAL account 2026-10-03: the driver names no constant
#: for it, so it was missing here and a pooled session killed by Snowflake
#: failed every later query instead of logging in again.
_SESSION_GONE_ERRNOS = frozenset(
    {250002, 252007, 390110, 390111, 390112, 390113, 390114, 390115})


def _session_is_gone(exc: BaseException) -> bool:
    """True when ``exc`` says the Snowflake SESSION is dead -- a failure the
    client raises while authenticating the request, before the statement
    was accepted, so re-running the statement on a fresh session cannot
    run it twice.  A network error mid-statement (08S01, a timeout) is
    deliberately NOT included: whether that statement ran is unknown, and
    unknown is unsafe to retry."""
    if getattr(exc, "sqlstate", None) in _SESSION_GONE_SQLSTATES:
        return True
    try:
        return int(getattr(exc, "errno", 0) or 0) in _SESSION_GONE_ERRNOS
    except (TypeError, ValueError):
        return False


class SnowflakeConnector(SqlConnector):
    """Connector for Snowflake cloud data platform."""

    #: 2026-09-16 — audited for reuse.  ``_conn`` is the only instance
    #: field; there is no ALTER SESSION, no USE WAREHOUSE/DATABASE/SCHEMA
    #: issued after connect (the session is pinned by the connect kwargs,
    #: which are part of the config and therefore part of the POOL KEY), no
    #: explicit transaction and no temp object.  Cursors are per call.
    POOL_SAFE = True

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        # 2026-10-03 -- LOCAL liveness check, not a network ping.  This ran
        # ``SELECT 1`` before EVERY call, so one browse (databases ->
        # schemas -> tables -> columns) paid four extra round trips to the
        # cloud service, and every pooled reuse paid one more.  What the
        # ping guarded against is covered without it:
        #   * a session closed on our side -> ``is_closed()`` (no I/O);
        #   * the 1-hour session token -> the driver renews it itself with
        #     the master token, inside the request;
        #   * the master token expiring after long idle (the pool already
        #     evicts a connector idle for ``idle_timeout``, 300 s by
        #     default) -> the request fails with a session-gone error
        #     (``_session_is_gone``), and ``_execute`` reconnects and
        #     re-runs ONCE.  That is safe because the driver raises it
        #     while authenticating, before the statement is accepted.
        # So a dead session is not made to look alive: it is detected on
        # the call that needed it, at no cost to the calls that did not.
        if self._conn is not None:
            try:
                closed = self._conn.is_closed()
            except Exception:
                closed = True
            if not closed:
                return self._conn
            self._conn = None

        try:
            import snowflake.connector
        except ImportError:
            raise DriverNotInstalled(
                "snowflake-connector-python",
                "snowflake-connector-python is not installed. "
                "Add 'snowflake-connector-python' to requirements.txt."
            )

        auth_type = self.config.get("auth_type", "password").lower()
        conn_kwargs: Dict[str, Any] = dict(
            account=self.config["account"],
            user=self.config["user"],
            login_timeout=int(self.config.get("login_timeout", 30)),
        )
        # 2026-10-03, REAL account: ``network_timeout`` defaulted to 60, and the
        # driver bounds a whole STATEMENT by it -- every query that ran past a
        # minute was "cancelled by the client due to a timeout" (a 50,000-row x
        # 1,000-column report; the engine's retry then paid a second minute).
        # A query's length is the warehouse's business (Snowflake's own
        # STATEMENT_TIMEOUT_IN_SECONDS) and the product's (Cancel, admission);
        # it is only passed when an admin sets it on the connection.
        if self.config.get("network_timeout") not in (None, "", 0, "0"):
            conn_kwargs["network_timeout"] = int(self.config["network_timeout"])
        # 2026-08-19 -- SHARED TRUST STORE.  This connector passed no TLS/CA
        # options, so a private-CA deployment had no configuration recourse.
        # core.ssl_config is what DuckDB/httpfs, boto3, pyiceberg and REST
        # already use; a corporate bundle found there is merged with certifi.
        try:
            from core.ssl_config import as_boto3_verify, resolve_ssl
            _sf_verify = as_boto3_verify(resolve_ssl(
                self.config.get("verify_ssl", True)))
            if isinstance(_sf_verify, str):
                # snowflake-connector-python reads requests' CA env var.
                import os as _os
                _os.environ.setdefault("REQUESTS_CA_BUNDLE", _sf_verify)
                _os.environ.setdefault("SSL_CERT_FILE", _sf_verify)
            elif _sf_verify is False:
                conn_kwargs["insecure_mode"] = True
        except Exception as _ssl_exc:
            logger.warning("Snowflake TLS resolution skipped (%s) -- using "
                           "the driver default trust store", _ssl_exc)


        # Optional context
        if self.config.get("warehouse"):
            conn_kwargs["warehouse"] = self.config["warehouse"]
        if self.config.get("database"):
            conn_kwargs["database"] = self.config["database"]
        if self.config.get("schema"):
            conn_kwargs["schema"] = self.config["schema"]
        if self.config.get("role"):
            conn_kwargs["role"] = self.config["role"]
        # 2026-10-03 -- an explicit endpoint: PrivateLink / a regional URL
        # (``host``), a non-default ``port``, and ``protocol`` ("https"
        # default).  Standard snowflake-connector-python options; absent, the
        # driver derives the host from ``account`` exactly as before.  The
        # Docker rig uses them to reach a fakesnow server over the wire.
        if self.config.get("host"):
            conn_kwargs["host"] = str(self.config["host"])
        if self.config.get("port"):
            conn_kwargs["port"] = int(self.config["port"])
        if self.config.get("protocol"):
            conn_kwargs["protocol"] = str(self.config["protocol"]).lower()

        if auth_type == "password":
            conn_kwargs["password"] = self.config.get("password", "")
        elif auth_type == "key_pair":
            # 2026-10-03 -- the key may come from a Vault kv entry through
            # the connection's System Account (core.connectors.get_connector
            # maps it here); one loader serves a paste, an attached file and
            # a Vault value alike.
            conn_kwargs["private_key"] = load_private_key_der(
                self.config.get("private_key"),
                self.config.get("private_key_passphrase"))
        elif auth_type == "oauth":
            conn_kwargs["token"] = self.config.get("token", "")
            conn_kwargs["authenticator"] = "oauth"
        elif auth_type == "sso_portal":
            # Phase 87: Resolve credentials from system account via credential manager
            try:
                from core.credential_manager import get_credential_manager
                cm = get_credential_manager()
                if cm:
                    resolved = cm.resolve_snowflake_credentials(self.config)
                    conn_kwargs["user"] = resolved.get("user", conn_kwargs.get("user", ""))
                    conn_kwargs["password"] = resolved.get("password", "")
                else:
                    raise RuntimeError("Credential manager not initialized")
            except Exception as exc:
                raise RuntimeError(f"SSO portal credential resolution failed: {exc}") from exc

        self._conn = snowflake.connector.connect(**conn_kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    def _drop_dead_session(self) -> None:
        conn, self._conn = self._conn, None
        if conn is not None:
            try:
                conn.close()
            except Exception as exc:
                logger.debug("Snowflake: closing a dead session failed: %s",
                             exc)

    def _execute(self, sql: str):
        """Run ``sql`` on a cursor and return the cursor (the caller closes
        it).  If a REUSED session turns out to be dead, reconnect and run it
        once more -- see ``_get_connection`` for why that is the liveness
        check and why one retry cannot run a statement twice.  A session
        opened by THIS call is never retried: its failure is the answer."""
        reused = self._conn is not None
        return self._run_on(self._get_connection().cursor(), sql, reused)

    def _run_on(self, cur, sql: str, reused: bool, on_new_cursor=None):
        """Execute ``sql`` on ``cur``; return the cursor that ran it.  On a
        dead REUSED session: reconnect, hand the new cursor to
        ``on_new_cursor`` (the streaming cancel watchdog must abort the
        cursor that is actually running), and run it once more.  A cursor
        whose statement failed is closed before the error propagates."""
        try:
            cur.execute(sql)
            return cur
        except Exception as exc:
            _close_quietly(cur)
            if not (reused and _session_is_gone(exc)):
                raise
            logger.info("Snowflake session expired (%s) -- reconnecting and "
                        "retrying once", exc)
        self._drop_dead_session()
        cur = self._get_connection().cursor()
        if on_new_cursor is not None:
            on_new_cursor(cur)
        try:
            cur.execute(sql)
        except Exception:
            _close_quietly(cur)
            raise
        return cur

    def _cancel_if_abandoned(self, cur) -> None:
        """A streamed result left before it was drained: cancel it at the
        warehouse.

        2026-10-03 -- this was ``cur.cancel()``, and SnowflakeCursor has NO
        ``cancel`` (connector 4.8.0) -- the exact defect
        ``_abort_running_query`` was written to fix on 2026-08-19, left
        behind on this path.  The AttributeError was swallowed at DEBUG and
        nothing was ever cancelled.  It now goes through
        ``_abort_running_query`` like the watchdog does -- and only when the
        service gave the statement a query id: with none (a session that
        died before the statement was accepted) there is nothing at the
        warehouse to cancel.
        """
        if not getattr(cur, "sfqid", None):
            return
        try:
            if self._abort_running_query(cur):
                logger.info("Snowflake: result set abandoned before "
                            "completion — cancelled at the warehouse")
        except Exception as exc:
            logger.warning("Snowflake cancel on abandon failed: %s", exc)

    def _dict_cursor(self):
        try:
            import snowflake.connector
            return self._get_connection().cursor(snowflake.connector.DictCursor)
        except Exception:
            return self._get_connection().cursor()

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        cur = None
        try:
            cur = self._execute(
                "SELECT CURRENT_VERSION(), CURRENT_USER(), CURRENT_ROLE()")
            row = cur.fetchone()
            version, user, role = (row or ("?", "?", "?"))[:3]
            return {
                "success": True,
                "message": f"Connected to Snowflake {version} as {user} ({role})",
                "details": {
                    "version": version,
                    "user": user,
                    "role": role,
                    "account": self.config.get("account"),
                },
            }
        except Exception as e:
            logger.exception("Snowflake test_connection failed")
            return self._test_failure(e)
        finally:
            if cur:
                cur.close()

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "snowflake_connector", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    # Every SHOW / DESCRIBE column below is resolved BY NAME from
    # ``cursor.description`` (``_column_index``); the number beside each is
    # the documented position, used only when there is no description.

    def _show_names(self, sql: str) -> List[str]:
        cur = self._execute(sql)
        try:
            rows = cur.fetchall()
            i = _column_index(cur.description, "name", 1)
            return [_cell(r, i) for r in rows]
        finally:
            cur.close()

    def list_catalogs(self) -> List[str]:
        return self._show_names("SHOW DATABASES")

    def list_schemas(self, catalog: str) -> List[str]:
        return self._show_names(f"SHOW SCHEMAS IN DATABASE {_qi(catalog)}")

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """Tables AND views.

        2026-10-03 -- ``SHOW TABLES`` does not list views, and this method
        ran nothing else, so a Snowflake VIEW could not be found in the
        query builder or the dataset wizard at all -- while ``SELECT``
        from it, and ``DESCRIBE TABLE`` on it, both work.  ``SHOW VIEWS``
        is asked as well and its rows are typed ``VIEW``.  Tables and views
        share one namespace in a Snowflake schema, so a name is never both;
        the de-duplication below is for a layout that would list one twice,
        and a name SHOW TABLES already gave keeps its table row.

        A table's ``type`` is its SHOW TABLES ``kind`` (TABLE, TRANSIENT,
        TEMPORARY) -- read by NAME; read by position on a layout that
        orders the columns differently it was the SCHEMA name.
        """
        where = f"{_qi(catalog)}.{_qi(schema)}"
        out: List[Dict[str, Any]] = []
        seen = set()
        cur = self._execute(f"SHOW TABLES IN {where}")
        try:
            rows = cur.fetchall()
            ni = _column_index(cur.description, "name", 1)
            ki = _column_index(cur.description, "kind", 4)
            for r in rows:
                name = _cell(r, ni)
                if name is None or name in seen:
                    continue
                seen.add(name)
                out.append({"name": name,
                            "type": _cell(r, ki) or "TABLE",
                            "catalog": catalog, "schema": schema})
        finally:
            cur.close()
        cur = self._execute(f"SHOW VIEWS IN {where}")
        try:
            rows = cur.fetchall()
            ni = _column_index(cur.description, "name", 1)
            for r in rows:
                name = _cell(r, ni)
                if name is None or name in seen:
                    continue
                seen.add(name)
                out.append({"name": name, "type": "VIEW",
                            "catalog": catalog, "schema": schema})
        finally:
            cur.close()
        return out

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Columns of a table OR a view.

        Snowflake documents ``DESCRIBE TABLE`` and ``DESCRIBE VIEW`` as
        interchangeable -- either returns the columns of a table or a view
        -- so the one statement serves both kinds ``list_tables`` returns.
        """
        try:
            cur = self._execute(
                f"DESCRIBE TABLE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
        except Exception as exc:
            # 2026-10-03, REAL account: a table created as "MixedCase" is
            # listed by SHOW TABLES as MixedCase, and the bare spelling above
            # folds to MIXEDCASE -> "does not exist".  Snowflake stores every
            # UNQUOTED name upper-case, so a name with a lower-case letter that
            # the bare form cannot find can only be a quoted one: ask again
            # with the EXACT spelling.  Bare stays first so a lower-case name
            # typed for an upper-case object (``mydb``) keeps working.
            cur = None
            for spelling in _exact_retry_spellings(exc, catalog, schema, table):
                try:
                    cur = self._execute(f"DESCRIBE TABLE {spelling}")
                    break
                except Exception:  # noqa: BLE001 -- the ORIGINAL error is the answer
                    continue
            if cur is None:
                raise
        try:
            rows = cur.fetchall()
            ni = _column_index(cur.description, "name", 0)
            ti = _column_index(cur.description, "type", 1)
            nl = _column_index(cur.description, "null?", 3)
            out = []
            for i, r in enumerate(rows):
                null_flag = _cell(r, nl)
                out.append({
                    "name": _cell(r, ni),
                    "type": _cell(r, ti),
                    "nullable": (str(null_flag).upper() == "Y")
                                if null_flag is not None else True,
                    "ordinal": i,
                })
            return out
        finally:
            cur.close()

    # ── Partition detection ────────────────────────────────────────────────────

    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Detect clustering keys (Snowflake's partition equivalent)."""
        cur = None
        try:
            cur = self._execute(
                f"SHOW TABLES LIKE {_ql(table)} IN {_qi(catalog)}.{_qi(schema)}")
            rows = cur.fetchall()
            if not rows:
                return []
            # 2026-08-20 -- the table name is a LIKE *PATTERN*, and `_` (in
            # nearly every real table name) matches ANY character -- so on a
            # schema holding both MY_TABLE and MY1TABLE this returns BOTH
            # rows, and rows[0] may belong to the WRONG table: phantom or
            # missing clustering columns silently steering partition
            # prompting and pruning.  Select the row whose `name` column
            # equals the requested table -- exact first, then case-folded
            # (SHOW's LIKE is case-insensitive and Snowflake upper-folds
            # bare names, so a caller's "my_table" is stored as MY_TABLE).
            _name_idx = _column_index(cur.description, "name", 1)
            _want = str(table)
            _exact = [r for r in rows
                      if len(r) > _name_idx and str(r[_name_idx]) == _want]
            if not _exact:
                _exact = [r for r in rows
                          if len(r) > _name_idx
                          and str(r[_name_idx]).upper() == _want.upper()]
            if not _exact:
                return []
            rows = _exact
            # 2026-08-19 -- index 9 is "owner", NOT "cluster_by".
            # Snowflake SHOW TABLES is
            #   0 created_on  1 name  2 database_name  3 schema_name
            #   4 kind  5 comment  6 cluster_by  7 rows  8 bytes  9 owner
            # -- the documented layout (list_tables above used to read name
            # at 1 and kind at 4 from it by position; since 2026-10-03 it
            # reads both by name too).  Reading 9 returned the OWNER ROLE, which is
            # never empty, so the "not clustered" guard below never fired and
            # EVERY table reported a phantom partition column named after its
            # owner ("SYSADMIN"), while a genuinely clustered table's
            # LINEAR(...) at index 6 was never seen.
            #
            # Resolved BY NAME from cursor.description rather than by another
            # positional guess -- a drifting index is the bug itself.
            _idx = _column_index(cur.description, "cluster_by", 6)
            cluster_by = str(rows[0][_idx]) if len(rows[0]) > _idx else ""
            if cluster_by.lower() in ("none", "null"):
                cluster_by = ""
            if not cluster_by or cluster_by.strip() == "":
                return []
            # Parse "LINEAR(col1, col2)" or plain "col1, col2"
            cleaned = re.sub(r'LINEAR\s*\(', '', cluster_by)
            cleaned = cleaned.rstrip(')')
            cols = [c.strip().strip('"').strip("'") for c in cleaned.split(',') if c.strip()]
            return [
                {"name": c, "type": "string", "transform": "cluster"}
                for c in cols if c.upper() != 'LINEAR'
            ]
        except Exception:
            # WARNING, not DEBUG: [] means both "not clustered" and "could
            # not find out", and the second silently disables partition
            # prompting so queries full-scan.
            logger.warning(
                "detect_partitions failed for %s.%s.%s -- treating as "
                "unclustered, so no partition filter will be offered",
                catalog, schema, table, exc_info=True)
            return []
        finally:
            if cur is not None:
                cur.close()

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        cur = self._execute(sql)
        try:
            desc = cur.description or []
            col_info = [{"name": n, "type": _result_type_name(d)} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
            col_names = unique_column_names(d[0] for d in desc)
            rows_raw = cur.fetchall()
            rows = [dict(zip(col_names, row)) for row in rows_raw]
            return {"columns": col_info, "rows": rows, "total_rows": len(rows)}
        finally:
            cur.close()

    def _abort_via_api(self, cur, qid) -> bool:
        """The driver's REST abort for ``qid`` -- True only if it was issued
        and not answered as failed."""
        abort = (getattr(cur, "abort_query", None)
                 or getattr(self._conn, "abort_query", None))
        if not callable(abort):
            return False
        try:
            if abort(qid) is not False:
                logger.info("Snowflake query %s aborted", qid)
                return True
            logger.debug("Snowflake abort_query(%s) answered not-aborted", qid)
        except Exception as exc:
            logger.debug("Snowflake abort_query(%s) failed: %s", qid, exc)
        return False

    def _abort_session_queries(self) -> bool:
        """Cancel what THIS connector's session is running, by session id
        (``SYSTEM$CANCEL_ALL_QUERIES``) -- for a statement whose query id
        the driver has not exposed yet.  True if the cancel was issued."""
        sid = getattr(self._conn, "session_id", None)
        try:
            sid = int(sid)
        except (TypeError, ValueError):
            logger.warning(
                "Snowflake cancel requested but neither the query id nor the "
                "session id is known -- the query will run to completion")
            return False
        try:
            c2 = self._conn.cursor()
            try:
                c2.execute(f"SELECT SYSTEM$CANCEL_ALL_QUERIES({sid})")
                logger.info("Snowflake session %s: its running query cancelled "
                            "via SYSTEM$CANCEL_ALL_QUERIES", sid)
                return True
            finally:
                c2.close()
        except Exception as exc:
            logger.warning(
                "Snowflake cancel FAILED for session %s (%s) -- its query is "
                "still running and still consuming credits", sid, exc)
            return False

    def _abort_running_query(self, cur) -> bool:
        """Actually stop an in-flight Snowflake query.  True if a cancel was
        issued.

        2026-08-19 -- this used to be ``cur.cancel()`` inside a bare
        ``except: pass``.  SnowflakeCursor has NO ``cancel`` method, so every
        cancel raised AttributeError, was swallowed, and the warehouse ran the
        query to completion -- burning credits -- while the UI reported
        "cancelled".  That is precisely the defect BF-262 recorded as fixed.

        The driver's real API is the query id (``cursor.sfqid``) plus
        ``abort_query(qid)``; ``SYSTEM$CANCEL_QUERY`` is the SQL equivalent
        and is used as a second attempt on its own cursor, because the
        original cursor is blocked inside execute().

        2026-10-03 -- ``abort_query`` is a CURSOR method (connector 4.8.0:
        ``SnowflakeCursor.abort_query``; ``SnowflakeConnection`` has none),
        and this called it on the connection, so the first attempt always
        raised AttributeError and only the SQL fallback ever ran.  The
        cursor's method is asked first now, the connection's only if a
        driver has one there.
        """
        # Kept first so a driver version that DOES add cancel() is used.
        try:
            fn = getattr(cur, "cancel", None)
            if callable(fn):
                fn()
                return True
        except Exception as exc:
            logger.debug("Snowflake cur.cancel() unavailable: %s", exc)

        qid = getattr(cur, "sfqid", None)
        if not qid:
            # 2026-10-03, REAL account: the driver sets ``sfqid`` only when
            # execute() RETURNS, so for the query a user actually cancels --
            # a long one, still inside execute() -- it is never known, and
            # the warehouse ran on (~50 s measured, until a client timeout
            # happened to stop it).  This connector's session runs ONE
            # statement at a time (the pool hands an instance to one caller;
            # cursors are per call), so cancelling every query IN THIS
            # SESSION cancels exactly that one -- never another session's.
            return self._abort_session_queries()
        if self._abort_via_api(cur, qid):
            return True
        try:
            c2 = self._conn.cursor()
            try:
                c2.execute(f"SELECT SYSTEM$CANCEL_QUERY('{qid}')")
                logger.info("Snowflake query %s cancelled via "
                            "SYSTEM$CANCEL_QUERY", qid)
                return True
            finally:
                c2.close()
        except Exception as exc:
            # WARNING, not silence: a cancel that did not cancel keeps
            # billing the warehouse while the UI says otherwise.
            logger.warning(
                "Snowflake cancel FAILED for query %s (%s) -- it is still "
                "running and still consuming credits", qid, exc)
        return False

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Phase 139 (Tier 2.1) — real cursor-based streaming via fetchmany.

        First chunk yields as soon as Snowflake returns the first N rows,
        NOT after the full result lands.

        BF-262 follow-up: when ``cancel_event`` is set, the watchdog calls
        ``_abort_running_query`` (the query id + ``abort_query``, then
        ``SYSTEM$CANCEL_QUERY``) -- SnowflakeCursor has no ``cancel()``.
        Without this, cancel was a no-op for Snowflake — query ran to
        completion even after the user clicked Cancel.
        """
        import threading as _th
        sql = self._apply_limit(sql, limit)
        reused = self._conn is not None
        cur = self._get_connection().cursor()
        # The cursor the watchdog must abort -- replaced if the statement is
        # re-run on a fresh session (see below).
        _live = [cur]
        # Spawn watchdog thread that aborts the query the moment
        # cancel_event fires.  Daemon thread; stops itself when query completes.
        _stop = _th.Event()
        if cancel_event is not None:
            def _wd():
                while not _stop.is_set():
                    if cancel_event.is_set():
                        self._abort_running_query(_live[0])
                        return
                    _stop.wait(0.5)
            _th.Thread(target=_wd, name="qs-snowflake-cancel", daemon=True).start()
        _drained = False
        try:
            # Same rule as ``_execute``: only a REUSED session found dead is
            # re-run, and only before a row has been read.
            cur = self._run_on(cur, sql, reused,
                               on_new_cursor=lambda c: _live.__setitem__(0, c))
            desc = cur.description or []
            col_info = [{"name": n, "type": _result_type_name(d)} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
            col_names = unique_column_names(d[0] for d in desc)
            yielded_any = False
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    break
                batch = cur.fetchmany(chunk_size)
                if not batch:
                    break
                yielded_any = True
                yield col_info, [dict(zip(col_names, row)) for row in batch]
            if not yielded_any:
                yield col_info, []
            _drained = True
        finally:
            # 2026-08-21 — CANCEL AT THE SOURCE ON ANY EARLY EXIT.
            #
            # This used to `_stop.set()` then close.  Both are wrong for an
            # abandoned query: _stop.set() kills the cancel WATCHDOG — the only
            # thing that ever calls cancel, and it polls on a timer, so an abort
            # usually beat it — and close() is not a cancel; the warehouse keeps
            # executing and keeps billing.  A consumer that stopped reading
            # (user cancel, a write-side failure, GeneratorExit on GC) left the
            # query running to completion.
            #
            # Cancel FIRST, then stop the watchdog, then close — and only when
            # the result set was NOT drained, since a finished query needs no
            # cancel.  ``_live[0]`` is the cursor that actually ran it.
            cur = _live[0]
            if not _drained:
                self._cancel_if_abandoned(cur)
            _stop.set()
            try:
                cur.close()
            except Exception as _cls:
                # Not silent: a close that fails after an abandoned read is
                # how a cursor leaks back into the pool still bound to a
                # running statement.  Rare, but it must leave a trace.
                logger.debug("Snowflake cursor close after abandon failed: %s",
                             _cls)
