"""
Databricks SQL connector.
Supports Databricks SQL Warehouses (formerly SQL Endpoints) and clusters.

Required config keys:
  server_hostname  – e.g. "adb-1234567890.12.azuredatabricks.net"
  http_path        – SQL Warehouse HTTP path,
                     e.g. "/sql/1.0/warehouses/abc123def456"
  access_token     – Personal Access Token or Service Principal token
  catalog          – Unity Catalog catalog name (optional, default "hive_metastore")
  schema           – default schema (optional)
  http_headers     – list of [key, value] pairs (optional)
  session_config   – dict of Spark conf keys (optional)
  max_download_threads – int, default 10
"""

import logging
from typing import Any, Dict, List, Optional

from .base import SqlConnector, unique_column_names, DriverNotInstalled


_QUOTE = '`'   # identifier quote for this dialect
_LITQ = "'"


def _qi(name):
    """Quote ONE identifier -- but only when it actually needs quoting.

    2026-08-20 -- catalog/schema/table were interpolated BARE into SHOW and
    DESCRIBE.  The Trino connector got a quoter on 2026-08-19 and the commit
    claimed the audit lens had been applied to Snowflake/Databricks too; it
    had not.  Any name needing quoting (a hyphen, a reserved word) failed on
    browse, and since these values arrive from an authenticated user's
    connection config they were an injection surface running under that
    connection's own credentials.

    CONDITIONAL on purpose.  Quoting unconditionally would be a REGRESSION
    here: unquoted identifiers case-FOLD (Snowflake upper-folds, Databricks
    lower-folds) while quoted ones are case-SENSITIVE, so wrapping a plain
    `mydb` in quotes turns a working browse into "object does not exist".
    A bare-safe name is therefore passed through byte-identical -- current
    behaviour, preserved exactly -- and only a name that could not have
    worked before (or could have injected) is quoted.

    2026-08-20 (third pass) -- delegates to the ONE shared implementation in
    base.py.  The local copy had two defects: reserved words passed bare
    (``_qi("order")`` -> parse error on ``DESCRIBE TABLE cat.sch.order``),
    and ``$`` was treated as bare-safe when it is only bare-legal on
    Snowflake -- ``acct$x`` bare is a parse error in Spark grammar.
    Reserved words lower-fold first, matching what Spark does to the bare
    spelling, so quoting does not change which object is addressed.
    """
    from .base import quote_identifier
    return quote_identifier(name, quote=_QUOTE, fold=str.lower,
                            allow_dollar=False)


def _ql(value):
    """Quote a string LITERAL (SHOW ... LIKE takes one, not an identifier)."""
    s = str(value)
    return _LITQ + s.replace(_LITQ, _LITQ + _LITQ) + _LITQ


logger = logging.getLogger(__name__)


class DatabricksConnector(SqlConnector):
    """Connector for Databricks SQL Warehouses."""

    #: 2026-09-16 — NOT declared, and not because of what it holds:
    #: ``_conn`` is its only instance field and it would audit clean.
    #: ``databricks-sql-connector`` was REMOVED from requirements on
    #: 2026-07-11 as a documented security decision (thrift < 0.23, six High
    #: CVEs, pinned by a test), so this connector cannot open a connection
    #: at all and there is nothing to pool.  Declaring it would be
    #: asserting an audit of behaviour no one can exercise.  If the driver
    #: is ever restored, read it and flip this with the same evidence the
    #: other four carry.
    POOL_SAFE = False

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None
        #: set by test_connection for the duration of one interactive check
        self._connect_bound_override = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self, bound_s: float | None = None):
        """Open (or reuse) the session.

        ``bound_s`` caps how long the driver may spend RETRYING before it
        gives up, overriding ``login_timeout``.  test_connection passes a
        tighter one because a person is waiting on it.
        """
        if self._conn is not None:
            return self._conn
        try:
            from databricks import sql as dbsql
        except ImportError:
            # 2026-09-20: this IS bundled again (requirements.txt).  It was
            # removed 2026-07-11 for pinning thrift <0.23 and its CVEs;
            # connector 4.4.0 moved the pin to thrift >=0.24.0, which OSV
            # reports clean.  Reaching here now means a hand-built image
            # dropped it, not that the product declines to ship it.
            raise DriverNotInstalled(
                "databricks-sql-connector",
                "databricks-sql-connector is not installed on this image. "
                "It IS in requirements.txt (restored 2026-09-20), so this "
                "image was built without it or the install failed: run "
                "pip install 'databricks-sql-connector>=4.4.0' and restart "
                "the backend. Keep the >=4.4.0 floor -- earlier releases "
                "cap thrift <0.23, which carries open CVEs."
            )

        kwargs: Dict[str, Any] = dict(
            server_hostname=self.config["server_hostname"],
            http_path=self.config["http_path"],
            access_token=self.config["access_token"],
        )

        if self.config.get("catalog"):
            kwargs["catalog"] = self.config["catalog"]
        if self.config.get("schema"):
            kwargs["schema"] = self.config["schema"]
        if self.config.get("http_headers"):
            # stored as list of [key, val] pairs
            kwargs["http_headers"] = self.config["http_headers"]
        if self.config.get("session_config"):
            kwargs["session_configuration"] = self.config["session_config"]
        if self.config.get("max_download_threads"):
            kwargs["max_download_threads"] = int(self.config["max_download_threads"])

        # 2026-08-19 -- SHARED TRUST STORE.  Only the Trino connector used
        # core.ssl_config; this one passed no TLS options at all, so on a
        # deployment whose CA bundle the helm chart drops in (the seven
        # spellings ssl_config scans) there was no way to make it verify.
        # Same class as the 2026-08-07 "3 client stacks, 3 CA stores".
        try:
            from core.ssl_config import as_boto3_verify, resolve_ssl
            _verify = as_boto3_verify(resolve_ssl(
                self.config.get("verify_ssl", True)))
            if _verify is False:
                kwargs["_tls_verify"] = False
            elif isinstance(_verify, str):
                kwargs["_tls_trusted_ca_file"] = _verify
        except Exception as _ssl_exc:
            logger.warning("Databricks TLS resolution skipped (%s) -- using "
                           "the driver default trust store", _ssl_exc)

        # 2026-09-20 -- BOUND THE CONNECT ATTEMPT.  The driver's default
        # retry policy is NINE HUNDRED SECONDS and nothing here overrode it,
        # so a connection whose hostname is wrong or whose warehouse is
        # stopped hung for fifteen minutes on the request thread before
        # answering.  Measured, not inferred: a probe against a fake
        # workspace ran past 600s and the driver's own error names the
        # policy -- "Retry request would exceed Retry policy max retry
        # duration of 900.0 seconds".  Athena refuses a bad config
        # immediately; that is the behaviour to match.
        #
        # The kwarg name is the DRIVER'S OWN, read off
        # databricks.sql.backend.thrift_backend rather than guessed:
        # dbsql.connect() takes **kwargs, so a misspelled option is
        # silently ignored and would leave this change doing nothing while
        # looking correct.
        #
        # Spelled ``login_timeout`` to match the Snowflake connector rather
        # than inventing a fifth vocabulary for the same idea.  Only the
        # RETRY WINDOW is bounded -- deliberately not ``_socket_timeout``,
        # which would also cap a legitimately long-running query, and this
        # connector cannot be exercised against a real workspace here.
        _override = getattr(self, "_connect_bound_override", None)
        kwargs["_retry_stop_after_attempts_duration"] = float(
            bound_s if bound_s is not None
            else _override if _override is not None
            else self.config.get("login_timeout", self._CONNECT_BOUND_S))

        self._conn = dbsql.connect(**kwargs)
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    # ── Connection lifecycle ─────────────────────────────────────────────────

    #: How long a connect may spend RETRYING before it answers.  The
    #: driver's own default is 900s; nobody waits fifteen minutes to be
    #: told a hostname is wrong.  Raise ``login_timeout`` on the connection
    #: to buy back more patience on a flaky network.
    _CONNECT_BOUND_S = 120.0

    #: The same bound when a PERSON is waiting on a Test Connection button.
    #: Tighter on purpose: an interactive check that takes two minutes to
    #: fail reads as a hang, and the user retries into it.
    _TEST_BOUND_S = 30.0

    def test_connection(self) -> Dict[str, Any]:
        try:
            # a PERSON is waiting on this one, so open the session under the
            # tighter bound.  Carried on the instance rather than passed as
            # an argument so this still goes through _cursor(): that is the
            # one chokepoint every query path shares, and a guard patches it
            # to prove this connector names a missing field.  Reshaping the
            # call path to carry a timeout would have silently disarmed it.
            self._connect_bound_override = float(
                self.config.get("test_timeout", self._TEST_BOUND_S))
            with self._cursor() as cur:
                cur.execute("SELECT 1 AS ping")
                cur.fetchone()
            # Get cluster/warehouse version info
            try:
                with self._cursor() as cur:
                    cur.execute("SELECT version()")
                    row = cur.fetchone()
                    version = row[0] if row else "unknown"
            except Exception:
                version = "unknown"
            return {
                "success": True,
                "message": f"Connected to Databricks SQL ({version})",
                "details": {
                    "version": version,
                    "server": self.config.get("server_hostname"),
                    "http_path": self.config.get("http_path"),
                },
            }
        except Exception as e:
            logger.exception("Databricks test_connection failed")
            return self._test_failure(e)

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "databricks_connector", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        try:
            with self._cursor() as cur:
                cur.execute("SHOW CATALOGS")
                rows = cur.fetchall()
                # Unity Catalog: column 0 is catalog name
                return [r[0] for r in rows]
        except Exception:
            # Fallback for non-Unity Catalog workspaces
            with self._cursor() as cur:
                cur.execute("SHOW DATABASES")
                rows = cur.fetchall()
                return [r[0] for r in rows]

    def list_schemas(self, catalog: str) -> List[str]:
        with self._cursor() as cur:
            cur.execute(f"SHOW SCHEMAS IN {_qi(catalog)}")
            rows = cur.fetchall()
            return [r[0] for r in rows]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        with self._cursor() as cur:
            cur.execute(f"SHOW TABLES IN {_qi(catalog)}.{_qi(schema)}")
            rows = cur.fetchall()
            desc = [d[0] for d in cur.description]
            result = []
            for row in rows:
                r = dict(zip(desc, row))
                result.append({
                    "name": r.get("tableName") or r.get("name") or row[0],
                    "type": "VIEW" if r.get("isTemporary") else "TABLE",
                    "catalog": catalog,
                    "schema": schema,
                })
            return result

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        with self._cursor() as cur:
            cur.execute(f"DESCRIBE TABLE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
            rows = cur.fetchall()
            result = []
            for i, row in enumerate(rows):
                if not row[0] or row[0].startswith('#'):
                    continue
                result.append({
                    "name": row[0],
                    "type": row[1] if len(row) > 1 else "string",
                    "nullable": True,
                    "ordinal": i,
                    "comment": row[2] if len(row) > 2 else None,
                })
            return result

    # ── Partition detection ────────────────────────────────────────────────────

    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Detect partition columns from DESCRIBE TABLE output.

        2026-08-20 -- this connector had NO override, so the base default []
        was returned for EVERY Delta table: indistinguishable from
        "unpartitioned", so no partition filter was ever offered and every
        Databricks query was a candidate full scan.  The metadata was
        ALREADY being fetched: ``DESCRIBE TABLE`` emits a
        ``# Partition Information`` section, which ``list_columns`` above
        explicitly SKIPS (``row[0].startswith('#')``).  Same statement,
        read instead of discarded.
        """
        try:
            with self._cursor() as cur:
                cur.execute(f"DESCRIBE TABLE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
                rows = cur.fetchall()
        except Exception:
            # WARNING, not DEBUG: [] means both "not partitioned" and
            # "could not find out", and the second silently disables
            # partition prompting so queries full-scan.
            logger.warning(
                "detect_partitions failed for %s.%s.%s -- treating as "
                "unpartitioned, so no partition filter will be offered",
                catalog, schema, table, exc_info=True)
            return []
        parts: List[Dict[str, Any]] = []
        in_partition_section = False
        for row in rows:
            name = str(row[0]).strip() if row and row[0] is not None else ""
            if not name:
                continue
            if name.startswith("#"):
                low = name.lower()
                if "partition" in low:
                    in_partition_section = True
                elif "col_name" in low:
                    # header row WITHIN the partition section -- stay in it
                    pass
                else:
                    # a different `#` section (e.g. DESCRIBE EXTENDED's
                    # `# Detailed Table Information`) ends the partition one
                    in_partition_section = False
                continue
            if in_partition_section:
                parts.append({
                    "name": name,
                    "type": str(row[1]) if len(row) > 1 and row[1] else "string",
                    "transform": "identity",
                })
        return parts

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        with self._cursor() as cur:
            cur.execute(sql)
            desc = cur.description or []
            col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
            col_names = unique_column_names(d[0] for d in desc)
            rows_raw = cur.fetchall()
            rows = [dict(zip(col_names, row)) for row in rows_raw]
        return {"columns": col_info, "rows": rows, "total_rows": len(rows)}

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Phase 139 (Tier 2.1) — cursor streaming via Databricks fetchmany_arrow.

        BF-262 follow-up: ``cancel_event`` watchdog calls ``cur.cancelOperation()``
        (databricks-sql-connector) which cancels the active operation on the
        Databricks SQL warehouse.
        """
        import threading as _th
        sql = self._apply_limit(sql, limit)
        with self._cursor() as cur:
            _stop = _th.Event()
            if cancel_event is not None:
                def _wd():
                    while not _stop.is_set():
                        if cancel_event.is_set():
                            # databricks-sql cursor exposes cancel via cancelOperation
                            try:
                                if hasattr(cur, "cancel"):
                                    cur.cancel()
                                elif hasattr(cur, "cancelOperation"):
                                    cur.cancelOperation()
                            except Exception:
                                pass
                            return
                        _stop.wait(0.5)
                _th.Thread(target=_wd, name="qs-databricks-cancel", daemon=True).start()
            _drained = False
            try:
                cur.execute(sql)
                desc = cur.description or []
                col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
                col_names = unique_column_names(d[0] for d in desc)
                yielded_any = False
                while True:
                    if cancel_event is not None and cancel_event.is_set():
                        break
                    batch = cur.fetchmany(chunk_size)
                    if not batch:
                        break
                    yielded_any = True
                    yield col_info, [dict(zip(col_names, row)) for row in batch]
                if not yielded_any:
                    yield col_info, []
                _drained = True
            finally:
                # 2026-08-21 — CANCEL AT THE SOURCE ON ANY EARLY EXIT.
                # _stop.set() kills the cancel watchdog — the only caller of
                # cancel, and it polls on a timer — so a consumer that stopped
                # reading (user cancel, write-side failure, GeneratorExit on GC)
                # left the warehouse executing and billing to completion.
                if not _drained:
                    try:
                        cur.cancel()
                        logger.info("Databricks: result set abandoned before "
                                    "completion — cancelled at the warehouse")
                    except Exception as _cxl:
                        logger.debug("Databricks cancel on abandon failed: %s",
                                     _cxl)
                _stop.set()
