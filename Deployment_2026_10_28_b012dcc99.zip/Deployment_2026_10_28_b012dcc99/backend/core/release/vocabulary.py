"""The leaf vocabulary of configuration release -- declarations only, no
imports from the rest of the product, so ``core/db/models.py`` (the CHECK
constraint on ``config_deployments``) and ``core/feed/governance.py``
(``GOVERNED_OBJECT_TYPES``) can both derive from it.  Before 2026-10-17 the
two spelled the vocabulary separately and DISAGREED (``partition_config`` /
``contract_template`` in one, ``contract`` in the other): a deploy of a type
one side knew and the other refused would have failed the whole transaction
at the database.  One declaration, here.

Three KINDS of table (docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §4):

* ``RELEASE``      configuration a person authored -- exported by natural
                   key, diffed field by field, applied;
* ``ENVIRONMENT``  exists in every environment but DIFFERS per environment
                   (credentials, hosts, people, keys, capacity) -- never
                   copied raw: mapped by name, or required to exist already;
* ``RUNTIME``      state the system produces (runs, caches, logs, locks,
                   heartbeats, audit, drafts, version histories, registries
                   the IMAGE seeds) -- never exported.

EVERY ORM table is declared exactly once in ``TABLE_KINDS``.  The guard
``tests/test_release_vocabulary_2026_10_17.py`` fails when a table exists
that is not declared, or is declared and does not exist -- a feature added
next month cannot be silently missing from a release.
"""

# (lower-case values: the deploy-environment resolver guard treats the string
# constant "ENVIRONMENT" as a raw $ENVIRONMENT read -- a kind label is not one)
KIND_RELEASE = "release"
KIND_ENVIRONMENT = "environment"
KIND_RUNTIME = "runtime"
KINDS = (KIND_RELEASE, KIND_ENVIRONMENT, KIND_RUNTIME)

R, E, X = KIND_RELEASE, KIND_ENVIRONMENT, KIND_RUNTIME

#: table -> (kind, how it travels).  For RELEASE tables the second element
#: names the OBJECT TYPE that carries the table: either its own type, or
#: ``"child of <type>"`` when its rows are serialized inside the parent's
#: definition (matched within the parent by their own key, never released
#: alone).  For ENVIRONMENT / RUNTIME tables it is the reason.
TABLE_KINDS: dict[str, tuple[str, str]] = {
    # ── FeedGen setup ───────────────────────────────────────────────────
    "feed_configs":               (R, "feed -- hand-authored feeds; template MEMBERS are derived, re-rendered in the target"),
    "feed_templates":             (R, "feed_template"),
    "feed_groups":                (R, "feed_group -- notification_email is an ENVIRONMENT field"),
    "feed_calendars":             (R, "calendar"),
    "feed_holidays":              (R, "child of calendar (key: holiday_date)"),
    "etl_dependency_types":       (R, "dependency_type -- server / param_value are ENVIRONMENT fields"),
    "etl_dependency_mappings":    (R, "child of feed (key: dependency_type + dependency_key)"),
    "feed_restatement_policies":  (R, "restatement_policy (key: scope + the scoped object's name)"),
    "feed_alert_kinds":           (R, "alert_kind"),
    "netcool_rules":              (E, "WHEN an event pages and WHAT it says -- UAT and PROD page differently; authored in each environment (2026-10-25)"),
    "feed_alert_routes":          (R, "alert_route -- target (an address) is an ENVIRONMENT field"),
    "feed_hold_approvers":        (R, "hold_approver (user group BY NAME)"),
    "feed_environments":          (R, "feed_environment"),
    "feed_message_fields":        (R, "message_field"),
    "feed_message_tokens":        (R, "message_token -- 'token' is a {TOKEN} vocabulary word, declared not-secret"),
    "feed_control_file_formats":  (R, "control_file_format"),
    "feed_flows":                 (R, "feed_flow"),
    "feed_flow_steps":            (R, "child of feed_flow (key: alias)"),
    "feed_custom_step_types":     (R, "custom_step_type"),
    "sql_files":                  (R, "sql_file -- the SQL TEXT travels in the package; file_path is the key"),
    "cloud_delivery_configs":     (R, "child of schedule -- bucket is an ENVIRONMENT field"),
    "watched_iceberg_tables":     (R, "watched_iceberg_table -- definition fields only; sync state stripped; bucket/connection mapped"),
    "feed_step_types":            (X, "seeded by the image at start-up (class_path) -- a release never carries code registries"),
    "feed_partition_declarations": (X, "per feed RUN (feed_run_id)"),
    "feed_runtime_profiles":      (X, "measured p50/p95 per environment"),
    "component_health":           (X, "each pod's observed state, written every 15 s -- never released"),
    "component_health_events":    (X, "confirmed state transitions (history) -- per environment"),
    "component_intents":          (X, "an operator's standing control (drain / pause), auto-expiring -- never carried to another environment"),
    "feed_consumer_subscriptions": (E, "people (usernames, e-mail)"),
    # ── FeedGen runtime ─────────────────────────────────────────────────
    "feed_runs": (X, "run"), "feed_executions": (X, "run"), "feed_run_steps": (X, "run"),
    "feed_file_runs": (X, "run"), "feed_sod_gaps": (X, "run"), "feed_run_sql": (X, "run"), "feed_alerts": (X, "alert"),
    "feed_variance_holds": (X, "run decision"), "feed_regeneration_decisions": (X, "run decision"),
    "feed_skip_approvals": (X, "run decision"), "feed_consumer_notices": (X, "notice log"),
    "feed_sequence_allocations": (X, "counter state"), "feed_row_count_baseline": (X, "measured"),
    "feed_definition_versions": (X, "version history -- a release CREATES a new version in the target"),
    "feed_definition_timeline": (X, "version history"),
    "feed_template_apply_requests": (X, "request queue"), "feed_onboarding_requests": (X, "request queue"),
    "etl_dependency_tracking": (X, "per business date"), "dependency_events": (X, "arrivals"),
    "file_arrival_observations": (X, "observations"), "kafka_messages": (X, "landed messages"),
    "qs_kafka_message": (X, "upstream messages the owner's Kafka service inserts"),
    "run_events": (X, "event log"), "delivery_attempts": (X, "run"), "delivery_history": (X, "run"),
    "connection_claims": (X, "lock"),
    # ── Reports ─────────────────────────────────────────────────────────
    "business_reports":           (R, "business_report (key: slug -- unique, backfilled by _ensure_report_slugs; owner is an ENVIRONMENT field; column ids travel as column NAMES)"),
    "report_parameters":          (R, "child of business_report (key: name)"),
    "report_pdf_configs":         (R, "child of business_report"),
    "report_slos":                (R, "child of business_report"),
    "report_dependency_mappings": (R, "child of business_report (key: dependency_type + dependency_key)"),
    "report_readiness_subjects":  (R, "child of business_report"),
    "conditional_format_rules":   (R, "child of business_report (key: column_name + rule_order)"),
    "rls_policies":               (R, "child of business_report (key: column_name + operator)"),
    "alert_rules":                (R, "child of business_report (key: name) -- recipients are ENVIRONMENT fields"),
    "report_folders":             (R, "report_folder (key: path of names, parent/child)"),
    "report_folder_assignments":  (R, "child of business_report"),
    "report_tags":                (R, "report_tag"),
    "report_tag_assignments":     (R, "child of business_report"),
    "reports":                    (R, "legacy_report -- DECIDED: not in a release (migrated to business_reports); declared so the guard is honest"),
    "report_subscriptions":       (E, "recipients (people)"),
    "business_report_grants":     (E, "people"),
    "business_report_versions": (X, "version history"), "business_report_async_jobs": (X, "job"),
    "business_report_access_requests": (X, "request"), "business_report_certification_requests": (X, "request"),
    "business_report_permission_events": (X, "event log"), "business_report_share_tokens": (X, "token"),
    "report_embed_tokens": (X, "token"), "report_instances": (X, "instance"), "report_instance_signoffs": (X, "sign-off"),
    "report_instance_comments": (X, "comment"), "report_comments": (X, "comment"), "report_change_log": (X, "log"),
    "report_readiness_runs": (X, "run"), "report_slo_breaches": (X, "breach"), "report_bookmarks": (X, "per-user state"),
    "report_favorites": (X, "per-user state"), "report_views": (X, "per-user state"),
    "burst_jobs": (X, "job"), "burst_tasks": (X, "job"), "subscription_deliveries": (X, "delivery log"),
    "legacy_report_migration_journal": (X, "migration journal"),
    # ── Datasets / semantic layer ───────────────────────────────────────
    "business_datasets":          (R, "dataset (key: name) -- connection_ids mapped by name"),
    "dataset_columns":            (R, "child of dataset (key: physical_name)"),
    "dataset_classes":            (R, "child of dataset (key: name)"),
    "dataset_relationships":      (R, "child of dataset (key: left_table + right_table)"),
    "drill_hierarchies":          (R, "child of dataset (key: name)"),
    "calculated_metrics":         (R, "child of dataset (key: name)"),
    "predefined_conditions":      (R, "child of dataset (key: name)"),
    "merged_dimensions":          (R, "child of dataset (key: secondary dataset name + name)"),
    "aggregation_awareness":      (R, "child of dataset -- connection mapped by name"),
    "logical_tables":             (R, "logical_table"),
    "logical_table_bindings":     (R, "child of logical_table (key: connection name) -- physical_ref is an ENVIRONMENT field"),
    "federation_views":           (R, "federation_view -- connections mapped by name"),
    "materialized_views":         (R, "materialized_view -- definition fields only; refresh state stripped"),
    "saved_queries":              (R, "saved_query (key: release_key -- minted on first export, carried, stored in the target)"),
    "sql_saved_queries":          (R, "sql_saved_query (key: release_key)"),
    "rest_query_defs":            (R, "rest_query_def (key: connection name + name)"),
    "table_descriptions":         (R, "table_description (key: connection name + table_name)"),
    "local_tables":               (E, "uploaded DATA, not configuration -- DECIDED: never released"),
    "agg_cache_entries":          (X, "rebuilt per environment from its own queries (DECIDED)"),
    "agg_cache_suggestions": (X, "learned"), "query_versions": (X, "version history"),
    "federation_executions": (X, "run"), "column_lineage": (X, "derived"), "table_lineage": (X, "derived"),
    "lineage_snapshots": (X, "derived"), "query_usage_stats": (X, "measured"),
    # ── Published APIs ──────────────────────────────────────────────────
    "published_views":            (R, "published_view (key: slug) -- connection + execution connection mapped by name"),
    "published_view_webhooks":    (R, "child of published_view (key: url) -- secret stripped, PROD sets its own"),
    "api_keys":                   (E, "consumers request keys in PROD; never copied"),
    "api_key_requests": (X, "request"), "api_access_log": (X, "log -- THE call record of every published API"),
    "published_view_schema_versions": (X, "version history"),
    # 2026-10-17 -- one row per access-log writer process (core/access_log_batcher.py)
    "published_api_ingest_health": (X, "heartbeat -- the writer's counters: what it queued, wrote, dropped, lost"),
    "published_api_call_rollups": (X, "measured -- hourly / daily buckets rebuilt from the call record"),
    "published_api_rollup_state": (X, "state -- the rollup's watermark per grain"),
    # 2026-10-17 -- alert thresholds are configuration (core/published_api/alerts.py);
    # a threshold scoped to one REPORT API carries the report's release key (its slug), never its id
    "published_api_alert_thresholds": (R, "api_alert_threshold (key: scope + api kind + scope key + metric + name)"),
    "published_api_alert_state":  (X, "state -- each (threshold, API)'s last verdict and its streaks"),
    "pv_bulk_prepare_claims": (X, "lock"), "pv_bulk_prepare_jobs": (X, "job"), "pv_materialise_flights": (X, "job"),
    # ── Dashboards ──────────────────────────────────────────────────────
    "dashboards":                 (R, "dashboard (key: release_key)"),
    "dashboard_widgets":          (R, "child of dashboard (key: release_key) -- sources by name"),
    "dashboard_shares":           (X, "share tokens"),
    # ── DataFlows ───────────────────────────────────────────────────────
    "dataflows":                  (R, "dataflow (key: name) -- a release creates the next version in the target"),
    "dataflow_stages":            (R, "child of dataflow (key: stage_alias) -- connection ids inside config mapped by name"),
    "dataflow_schedules":         (R, "child of dataflow (key: name)"),
    "dataflow_variables":         (R, "child of dataflow (key: name) -- is_secret values stripped; per-environment values mapped"),
    "dataflow_notification_policies": (R, "child of dataflow (key: name + event + channel)"),
    "dataflow_custom_stage_types": (R, "custom_stage_type"),
    "dataflow_webhook_triggers":  (E, "token + signing_secret: PROD mints its own"),
    "dataflow_stage_types":       (X, "seeded by the image at start-up (class_path)"),
    "dataflow_runs": (X, "run"), "dataflow_run_stages": (X, "run"), "dataflow_run_annotations": (X, "run"),
    "dataflow_approval_requests": (X, "request"),
    # ── Clockwork (scheduler) ───────────────────────────────────────────
    "clockwork_jobs":             (R, "clockwork_job (key: name) -- cron / timezone offered as a schedule mapping"),
    "clockwork_query_templates":  (R, "clockwork_query_template (key: name)"),
    "clockwork_settings":         (E, "per-deployment settings (DECIDED: environment, like the config overlay)"),
    "clockwork_task_types":       (X, "reported by each deployment at start-up"),
    "clockwork_deployments": (X, "deployment registry"), "clockwork_schema_migrations": (X, "migration journal"),
    "clockwork_job_versions": (X, "version history"), "clockwork_manual_requests": (X, "request"),
    "clockwork_alerts": (X, "alert"), "clockwork_alert_notifications": (X, "alert"),
    "clockwork_fire_resolutions": (X, "fire log"), "clockwork_job_health": (X, "health"),
    # ── Security / governance ───────────────────────────────────────────
    "row_level_policies":         (R, "row_level_policy (key: name) -- connection mapped by name"),
    "column_policies":            (R, "column_policy (key: name) -- connection mapped by name"),
    "policy_bindings":            (R, "child of row_level_policy / column_policy -- user principals are ENVIRONMENT, group principals by name"),
    "entitlement_dimensions":     (R, "entitlement_dimension (key: name) -- the dimension and its no-value rule"),
    "entitlement_dimension_columns": (R, "child of entitlement_dimension -- column spellings, connection by name"),
    "entitlement_values":         (E, "who holds which value -- people / keys / groups of THIS environment, never packaged"),
    "entitlement_uploads":        (X, "log"),
    "value_lists":                (R, "value_list (key: name) -- the DEFINITION: query, key / label columns, sync; connection by name"),
    "value_list_items":           (X, "the synced VALUES -- each environment syncs its own from its own connection, never packaged"),
    "user_groups":                (R, "user_group (the group itself; members are people)"),
    "ui_component_visibility":    (R, "ui_visibility (key: component_key + role)"),
    "dq_rules":                   (R, "dq_rule (key: release_key)"),
    "reconciliation_entities":    (R, "reconciliation_entity (key: name) -- connections + sql files by name"),
    "agent_rules":                (R, "agent_rule (key: release_key)"),
    "agent_config":               (R, "agent_config (key: key)"),
    "workspaces":                 (R, "workspace (key: slug)"),
    "user_group_members":         (E, "people"),
    "workspace_members":          (E, "people"),
    "connection_access":          (E, "people x connections"),
    "super_admins":               (E, "identities + password hashes"),
    "system_accounts":            (E, "credentials / Vault references"),
    "dq_results": (X, "result"), "dq_alerts": (X, "alert"), "alert_history": (X, "log"),
    "row_security_audit": (X, "audit"), "agent_decisions": (X, "log"), "audit_log": (X, "audit"),
    "user_sessions": (X, "session"), "user_preferences": (X, "per-user state"), "user_drafts": (X, "per-user state"),
    "table_favorites": (X, "per-user state"), "query_shares": (X, "token"), "rate_limit_windows": (X, "counter"),
    # ── Connections + platform ──────────────────────────────────────────
    "connections":                (E, "hosts, ports, SECRETS -- matched to PROD's own connection BY NAME, never carried"),
    "encryption_data_keys":       (E, "each environment's data keys, wrapped by ITS OWN Vault master key -- never carried (UAT's keys would not open under PROD's master)"),
    "connection_profiles":        (E, "maps connections within ONE environment"),
    "connection_profile_mappings": (E, "maps connections within ONE environment"),
    "connection_concurrency_budgets": (E, "capacity per environment (DECIDED)"),
    "system_settings":            (E, "the cross-pod config overlay -- environment configuration, verified by scripts/verify_prod_config.py"),
    "etl_pipeline_configs":       (R, "etl_pipeline (key: name) -- connections mapped by name; buckets are ENVIRONMENT fields"),
    "sap_task_configs":           (R, "sap_task (key: name) -- connections mapped by name"),
    "schedules":                  (R, "schedule (key: name) -- notify_emails is an ENVIRONMENT field"),
    "custom_background_jobs":     (R, "custom_background_job (key: name) -- cron offered as a schedule mapping"),
    "background_job_state": (X, "operator pause state"), "background_job_ticks": (X, "log"),
    "etl_pipeline_executions": (X, "run"), "schedule_run_stats": (X, "measured"),
    "task_queue": (X, "queue"), "dead_letter_queue": (X, "queue"), "pending_notifications": (X, "queue"),
    "notification_log": (X, "log"), "queued_wait_cancels": (X, "queue"), "execution_checkpoints": (X, "run"),
    "scheduler_lease": (X, "lock"), "scheduler_lock": (X, "lock"), "daemon_heartbeat": (X, "heartbeat"),
    "worker_health_state": (X, "heartbeat"), "worker_registry": (X, "heartbeat"),
    "spark_connect_sessions": (X, "session"), "spark_job_reports": (X, "run"),
    "duckdb_subprocess_crashes": (X, "log"), "circuit_breaker_states": (X, "state"),
    "download_files": (X, "artifact"), "config_deployments": (X, "the release LEDGER itself"),
    "config_releases": (X, "the release HEADER itself (package, preview, snapshot, audit)"),
    "release_mappings": (X, "THIS environment's name mapping -- never travels"),
    "reconciliation_runs": (X, "run"),
    # ── Query execution, caches, pruning brain, Iceberg ─────────────────
    "query_executions": (X, "run"), "query_jobs": (X, "job"), "query_performance_log": (X, "log"),
    "query_pruning_history": (X, "log"), "query_result_cache": (X, "cache"), "query_scan_plans": (X, "plan"),
    "result_artifacts": (X, "artifact"), "schema_cache": (X, "cache"), "catalog_table_columns": (X, "cache"),
    "partition_cache": (X, "cache"), "snapshot_tracker": (X, "cache"), "data_freshness": (X, "measured"),
    "brain_pruning_memo": (X, "cache"), "brain_route_outcome": (X, "learned"), "passport_calibration": (X, "learned"),
    "materialized_islands": (X, "cache"), "pruning_alert_events": (X, "alert"),
    "iceberg_bloom_sidecar_v1": (X, "cache"), "iceberg_column_stats_supplement_v2": (X, "cache"),
    "iceberg_commit_inspections": (X, "cache"), "iceberg_file_cache": (X, "cache"),
    "iceberg_file_partition_index": (X, "cache"), "iceberg_file_stats_v3": (X, "cache"),
    "iceberg_freshness_reliability": (X, "learned"), "iceberg_manifest_cache": (X, "cache"),
    "iceberg_metadata_content_cache": (X, "cache"), "iceberg_metadata_key_cache": (X, "cache"),
    "iceberg_mirror_dual_run_v1": (X, "run"), "iceberg_mirror_v1": (X, "state"),
    "iceberg_prunability_profile": (X, "learned"), "iceberg_snapshot_cache": (X, "cache"),
    "iceberg_snapshot_files": (X, "cache"), "iceberg_supplement_build_v1": (X, "job"),
    "iceberg_watcher_certificate": (X, "state"), "iceberg_watcher_changes": (X, "log"),
    # ── NL / learning ───────────────────────────────────────────────────
    "nl_conversations": (X, "per-user history"), "nl_feedback": (X, "learned"), "nl_patterns": (X, "learned"),
    "nl_query_history": (X, "history"), "nl_synonyms": (X, "learned"), "suggestion_corrections": (X, "learned"),
}

#: The closed vocabulary of RELEASABLE OBJECT TYPES -- what a package item's
#: ``kind`` may be and what ``config_deployments.object_type`` may hold.  A
#: type appears here when its adapter is REGISTERED (core/release/registry);
#: the guard fails when the registry and this tuple disagree.  Ordered: the
#: apply walks types in this order so a dependency lands before its user.
OBJECT_TYPES: tuple[str, ...] = (
    # the things everything else names first
    "user_group",
    "calendar",
    "dependency_type",
    "control_file_format",
    "sql_file",
    "saved_query",
    "sql_saved_query",
    "federation_view",
    # published APIs (phase 3) -- a feed or a report may read one
    "published_view",
    # FeedGen setup (phase 1)
    "feed_group",
    "alert_kind",
    # a published-API alert threshold names an alert kind and, when scoped to
    # one API, a published_view (by slug) or a business_report (by release key)
    # -- it lands after alert_kind and published_view; a report-scoped one is
    # resolved at apply through the registry (core/release/types/published.py)
    "api_alert_threshold",
    "feed_environment",
    "message_field",
    "message_token",
    "custom_step_type",
    "feed_flow",
    "feed",
    "feed_template",
    # rows ATTACHED to a feed / group / template land after their scope
    "alert_route",
    "restatement_policy",
    "hold_approver",
    # Reports + datasets (phase 2)
    "report_folder",
    "report_tag",
    "logical_table",
    "materialized_view",
    # 2026-10-24 -- a named value list (a report parameter names it, so first)
    "value_list",
    "rest_query_def",
    "table_description",
    "dataset",
    "business_report",
    # Dashboards + DataFlows (phase 4) -- a dashboard tile names a report
    "dashboard",
    "custom_stage_type",
    "dataflow",
)


def kind_of(table: str) -> str | None:
    """The declared kind of a table, or None when undeclared (the guard's
    question -- never a default: an undeclared table is a HOLE)."""
    entry = TABLE_KINDS.get(table)
    return entry[0] if entry else None


def tables_of_kind(kind: str) -> list[str]:
    return sorted(t for t, (k, _) in TABLE_KINDS.items() if k == kind)
