"""ONE set of names for where a feed runs (2026-10-27, the owner: "native
should be something worker ... how airflow says").

Every screen that names an engine -- the feed form's Engine, the
configuration summary's "Runs on", the engine the next run takes -- reads
these words.  The frontend's ``engineWords`` (frontend/src/components/feeds/
feedFormSummary.ts) says the same.
"""
from __future__ import annotations

from typing import Optional

#: the automatic choice, before a run decides
AUTO_WORDS = "Automatic (decided by size)"

ENGINE_WORDS = {
    "native": "QueryStudio worker",
    "spark_k8s": "Spark cluster",
    "spark_connect": "Shared Spark cluster",
    "airflow": "Airflow worker",
}


def engine_words(backend: Optional[str]) -> str:
    """The engine in words; an unknown name is shown as it is (never hidden)."""
    v = str(backend or "").strip().lower()
    if not v or v == "auto":
        return AUTO_WORDS
    return ENGINE_WORDS.get(v, str(backend))
