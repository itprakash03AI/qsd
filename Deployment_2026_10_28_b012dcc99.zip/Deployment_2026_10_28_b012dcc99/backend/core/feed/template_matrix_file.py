"""A feed template's matrix as an EXCEL file (2026-10-28).

The owner: "if someone wants to onboard 4000 jobs with same query with dynamic
where clause and kafka dependencies and if they upload excel file ... if we
provide template ... are we able to configure?"  The template dialog took CSV or
JSON only.  This module is the file half:

* ``matrix_template_xlsx(parameters)`` -- the workbook a person fills in: a
  "Feeds" sheet whose header row IS the template's parameters (one example
  row), and a "How to fill" sheet in plain words.
* ``read_matrix_file(filename, data, parameters)`` -- an uploaded .xlsx or
  .csv as rows {parameter: text}, with every problem named by row and column
  (an empty cell, the same feed twice, a missing column).  Values are TEXT, as
  the template renders them: a date cell is ``YYYY-MM-DD``, a whole number has
  no ``.0``.  Unknown is never empty: an unreadable file is a refusal with the
  reason, never "0 rows".

The apply itself is unchanged (api/feed_template_api.py, Plan / Apply).
"""
from __future__ import annotations

import csv
import io
from datetime import date, datetime
from typing import Any, Dict, List, Sequence

#: the largest matrix one file may carry (the owner's case is ~4,000)
MAX_ROWS = 20000
#: the largest upload, in bytes
MAX_BYTES = 10 * 1024 * 1024
#: an .xlsx is a zip: the most it may unpack to, and how far past its own size
#: (2026-10-28 security review: a small file can unpack to gigabytes before any
#: row count is reached -- checked BEFORE openpyxl opens it)
MAX_UNPACKED_BYTES = 100 * 1024 * 1024
MAX_UNPACK_RATIO = 200
#: columns read per row, and the longest cell
MAX_COLUMNS = 200
MAX_CELL_CHARS = 1000
#: all the text one file may carry (20,000 rows x a few short codes is ~1 MB)
MAX_TOTAL_CHARS = 20 * 1024 * 1024


class _Budget:
    """Checked AS EACH CELL IS READ, before it is copied (2026-10-28 security
    review: one long shared string can be referenced by every cell)."""

    def __init__(self) -> None:
        self.total = 0

    def take(self, v: Any, row_no: int) -> None:
        if isinstance(v, str):
            if len(v) > MAX_CELL_CHARS:
                raise MatrixFileRefused(f"Row {row_no} has a cell longer than {MAX_CELL_CHARS:,} characters; "
                                        f"a parameter value is a short code or name.")
            self.total += len(v)
            if self.total > MAX_TOTAL_CHARS:
                raise MatrixFileRefused("The file holds far more text than a list of feeds needs; "
                                        "keep only the parameter columns and upload it again.")
SHEET = "Feeds"


class MatrixFileRefused(ValueError):
    """The file cannot be read as a matrix; the message says why, plainly."""


def _clean_parameters(parameters: Sequence[str]) -> List[str]:
    out = [str(p).strip() for p in parameters if str(p).strip()]
    if not out:
        raise MatrixFileRefused("The template has no parameters, so there is nothing to fill in.")
    return out


def matrix_template_xlsx(parameters: Sequence[str]) -> bytes:
    """The workbook to fill in: header row = the parameters, one example row."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    params = _clean_parameters(parameters)
    wb = Workbook()
    ws = wb.active
    assert ws is not None
    ws.title = SHEET
    ws.append(params)
    ws.append([f"example {p}" for p in params])
    for c in ws[1]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="DDEBF7")
    for i, p in enumerate(params, start=1):
        ws.column_dimensions[get_column_letter(i)].width = max(14, len(p) + 4)
    ws.freeze_panes = "A2"
    help_ws = wb.create_sheet("How to fill")
    for line in (
        ["How to fill this file"],
        [""],
        [f"1. On the '{SHEET}' sheet, write ONE row per feed."],
        ["2. Keep the first row as it is: its column names are the template's parameters."],
        ["3. Replace the example row; every cell needs a value."],
        ["4. The same feed must not appear twice (the same values in every column)."],
        ["5. Save as .xlsx and upload it in Feeds -> Bulk feeds from a template."],
        ["6. Press Plan first: it shows what would be created, changed or refused, and writes nothing."],
    ):
        help_ws.append(line)
    help_ws["A1"].font = Font(bold=True)
    help_ws.column_dimensions["A"].width = 100
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _text(v: Any) -> str:
    """A cell as the text the template renders."""
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.isoformat(sep=" ")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _refuse_zip_bomb(data: bytes) -> None:
    """An .xlsx that would unpack too far is refused before it is parsed."""
    import zipfile
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            unpacked = sum(i.file_size for i in z.infolist())
    except zipfile.BadZipFile as exc:
        raise MatrixFileRefused(f"The file could not be read as an Excel workbook ({exc}).") from exc
    if unpacked > MAX_UNPACKED_BYTES or unpacked > MAX_UNPACK_RATIO * max(1, len(data)):
        raise MatrixFileRefused(
            f"The workbook would unpack to {unpacked // (1024 * 1024)} MB, far more than its rows need; "
            f"save the sheet again as a plain .xlsx (or .csv) and upload that.")


def _rows_from_xlsx(data: bytes) -> List[List[str]]:
    from openpyxl import load_workbook
    _refuse_zip_bomb(data)
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:  # noqa: BLE001 -- the reason is the answer
        raise MatrixFileRefused(f"The file could not be read as an Excel workbook ({exc}).") from exc
    ws = wb[SHEET] if SHEET in wb.sheetnames else wb.worksheets[0]
    out = []
    budget = _Budget()
    for n, row in enumerate(ws.iter_rows(values_only=True, max_col=MAX_COLUMNS), start=1):
        for v in row:
            budget.take(v, n)
        out.append([_text(v) for v in row])
        if len(out) > MAX_ROWS + 1:
            break
    wb.close()
    return out


def _rows_from_csv(data: bytes) -> List[List[str]]:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise MatrixFileRefused("The CSV file is not UTF-8 text; save it as 'CSV UTF-8'.") from exc
    budget, out = _Budget(), []
    for n, r in enumerate(csv.reader(io.StringIO(text)), start=1):
        r = r[:MAX_COLUMNS]
        for c in r:
            budget.take(c, n)
        out.append([c.strip() for c in r])
        if len(out) > MAX_ROWS + 1:
            break
    return out


def read_matrix_file(filename: str, data: bytes, parameters: Sequence[str]) -> Dict[str, Any]:
    """``{"rows", "problems", "columns", "ignored_columns", "total"}``.  A problem
    is ``{"row": <the file's row number>, "column", "message"}``; a refusal of the
    whole file raises MatrixFileRefused."""
    params = _clean_parameters(parameters)
    if len(data) > MAX_BYTES:
        raise MatrixFileRefused(f"The file is {len(data) // (1024 * 1024)} MB; the most is "
                                f"{MAX_BYTES // (1024 * 1024)} MB.")
    name = str(filename or "").lower()
    if name.endswith((".xlsx", ".xlsm")):
        grid = _rows_from_xlsx(data)
    elif name.endswith(".csv"):
        grid = _rows_from_csv(data)
    else:
        raise MatrixFileRefused("Upload an Excel file (.xlsx) or a CSV file (.csv).")
    while grid and not any(grid[0]):
        grid.pop(0)
    if not grid:
        raise MatrixFileRefused("The file has no header row: the first row must name the parameters.")
    header = [h.strip() for h in grid[0]]
    missing = [p for p in params if p not in header]
    if missing:
        raise MatrixFileRefused(
            f"The first row lacks the column(s) {', '.join(missing)}. It must name every parameter "
            f"of the template: {', '.join(params)}. Download the template to start from the right columns.")
    index = {p: header.index(p) for p in params}
    ignored = [h for h in header if h and h not in params]
    rows: List[Dict[str, str]] = []
    problems: List[Dict[str, Any]] = []
    seen: Dict[tuple, int] = {}
    body = grid[1:]
    if len(body) > MAX_ROWS:
        raise MatrixFileRefused(f"The file has more than {MAX_ROWS:,} rows; split it into smaller files.")
    for i, cells in enumerate(body, start=2):              # the file's own row number
        if not any(c for c in cells):
            continue                                       # a blank line is not a feed
        row = {p: (cells[j] if j < len(cells) else "") for p, j in index.items()}
        for p in params:
            if not row[p]:
                problems.append({"row": i, "column": p, "message": f"Row {i}: '{p}' is empty."})
        key = tuple(row[p] for p in params)
        if key in seen:
            problems.append({"row": i, "column": None,
                             "message": f"Row {i} is the same feed as row {seen[key]}."})
        else:
            seen[key] = i
        rows.append(row)
    if not rows:
        problems.append({"row": None, "column": None, "message": "The file has no feed rows under the header."})
    return {"rows": rows, "problems": problems, "columns": params,
            "ignored_columns": ignored, "total": len(rows)}
