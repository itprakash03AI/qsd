"""The ORACLE-TABLE arrival source (2026-10-11): an upstream's Oracle table
drives feed dependencies EXACTLY like a Kafka topic.

The owner's OG system lands every "partition ready" Kafka message in an
Oracle table (``QS_KAFKA_MESSAGE``: DATA_SOURCE, CODE, BUSINESS_EVENT,
BUSINESS_DATE, CLOUD_COMPLIANT, VERSION_STATE, ROW_COUNT, ...) -- one row per
message, a sequence for its ID.  Until this module the ``ORACLE_TABLE``
dependency TYPE existed in the catalogue and NOTHING could satisfy it: no
evaluator, no producer.

Design -- one resolver, two roads::

    Kafka topic  --> consumer lands kafka_messages row --> resolve_message(rules)
    Oracle table --> THIS watcher reads new rows      --> resolve_message(rules)
                                                      --> record_dependency_arrival
                                                      --> the ONE gate releases the run

* A row IS a message: ``{"topic": "oracle_table:<connection_id>/<TABLE>",
  "partition": 0, "offset": <ID>, "payload": {<COLUMN>: <value>, ...}}``.
  The resolver rules (``feed_generation.dependency_oracle_table.tables[].
  resolver_rules``) are the SAME vocabulary as ``dependency_kafka.
  resolver_rules`` -- a templated ``dependency_name`` with ``field_values``
  maps, ``business_date_field``, ``match`` (``VERSION_STATE: COMPLETE``),
  ``row_count_field`` -- parsed by the same ``kafka_arrivals.rules_from_
  config``.  A decision made twice is a bug; here it is made once.
* Each row read is LANDED in ``kafka_messages`` under that pseudo-topic with
  its final resolution (``resolved`` / ``unmatched`` / ``filtered`` /
  ``unresolvable``): the table's unique (topic, partition, offset) is the
  dedupe (a row re-read inside the rescan window lands nothing), the
  admin's unmatched route lists Oracle rows beside Kafka ones, and support
  sees what was read and what it meant without an Oracle client.
* The WATERMARK (the highest ID landed) is a system setting per (connection,
  table); every tick re-reads from ``watermark - rescan_rows`` so a row
  that COMMITTED late with a lower ID (two upstream sessions, one slow) is
  still caught, and the landing dedupe keeps that re-read free.  A row
  further back than the rescan window is missed -- stated here, bounded by
  ``rescan_rows``, and the admin run-now exists.  A row whose LEDGER write
  failed is not landed and the watermark does not pass it: the next tick
  retries it.
* Payload keys are the Oracle column names as the cursor returns them,
  UPPER-cased (Oracle folds unquoted identifiers up; a rule written
  ``BUSINESS_DATE`` matches); values are made JSON-safe (a DATE / TIMESTAMP
  -> ISO text, which the resolver's date parser already accepts; a NUMBER
  -> int when integral).

The producer is the daemon ``feed_dependency_oracle_table_watch`` (the
retention group's relocatable-daemon contract: ``retention_daemons.JOB_IDS``,
``daemon_registry.SCHEDULER_OWNED``, main.py's literal, a
``background_job_contract``); the tick acts only in the scheduler-lock
holder, like the file watcher.  Switched off, or configured with no table,
the kind's producer is DOWN and an unmet source reads "cannot be
satisfied" through ``arrival_sources.producer_health`` -- never "not met".
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from core.feed.dependency_gate import (
    MET, NOT_MET, UNKNOWN, FilteredMessage, ResolverRule, UnresolvedMessage,
    resolve_message,
)
from core.feed.ledger import record_dependency_arrival

logger = logging.getLogger(__name__)

KIND = "oracle_table"
LEDGER_SOURCE = "oracle_table"
TOPIC_PREFIX = "oracle_table:"
DAEMON = "feed_dependency_oracle_table_watch"
WRITER = "oracle_table_source"

#: An Oracle identifier, optionally schema-qualified, as this module will
#: paste it into SQL.  Anything else is refused at authoring / config load:
#: a table name is never escaped, only validated.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$#]*(\.[A-Za-z_][A-Za-z0-9_$#]*)?$")

#: Resolution states written on the landed rows (the kafka_messages
#: vocabulary, ``core.db.models.KAFKA_MESSAGE_RESOLUTIONS``).
RESOLVED, UNMATCHED, FILTERED, UNRESOLVABLE = ("resolved", "unmatched",
                                               "filtered", "unresolvable")


# ── Configuration ─────────────────────────────────────────────────────────

def load_config() -> Dict[str, Any]:
    """The declared ``feed_generation.dependency_oracle_table`` block, typed.
    Every key read here is declared in core/config.py.  A malformed table
    entry is REFUSED loudly (ERROR naming what is missing) and dropped --
    one bad entry must not take the good ones down, and a silent skip would
    be a dark table nobody can debug."""
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "dependency_oracle_table", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, Mapping):
        logger.error("[oracle_table_source] feed_generation.dependency_oracle_table "
                     "is %s, not an object -- treating as unconfigured",
                     type(raw).__name__)
        raw = {}

    def _int(name: str, default: int, lo: int, hi: int) -> int:
        try:
            v = int(raw.get(name, default))
        except (TypeError, ValueError):
            v = default
        return max(lo, min(hi, v))

    tables: List[Dict[str, Any]] = []
    raw_tables = raw.get("tables") or []
    if not isinstance(raw_tables, (list, tuple)):
        logger.error("[oracle_table_source] dependency_oracle_table.tables must be "
                     "a list, got %s -- NO tables are watched", type(raw_tables).__name__)
        raw_tables = []
    for i, entry in enumerate(raw_tables):
        norm = _table_entry(entry, i)
        if norm is not None:
            tables.append(norm)
    return {
        "enabled": bool(raw.get("enabled", True)),
        "interval_seconds": _int("interval_seconds", 15, 5, 86400),
        "batch_rows": _int("batch_rows", 500, 1, 10000),
        "rescan_rows": _int("rescan_rows", 200, 0, 1000000),
        "initial_lookback_rows": _int("initial_lookback_rows", 0, 0, 10000000),
        "tables": tables,
    }


def _table_entry(entry: Any, i: int) -> Optional[Dict[str, Any]]:
    if not isinstance(entry, Mapping):
        logger.error("[oracle_table_source] tables[%d] REFUSED: not an object (%r)", i, entry)
        return None
    conn = entry.get("connection")
    if conn is None or (isinstance(conn, str) and not conn.strip()):
        logger.error("[oracle_table_source] tables[%d] REFUSED: 'connection' (an id "
                     "or a connection name) is required", i)
        return None
    table = str(entry.get("table") or "").strip()
    if not _IDENT_RE.match(table):
        logger.error("[oracle_table_source] tables[%d] REFUSED: table %r is not an "
                     "Oracle identifier ([SCHEMA.]TABLE)", i, table)
        return None
    id_col = str(entry.get("id_column") or "ID").strip()
    if not _IDENT_RE.match(id_col) or "." in id_col:
        logger.error("[oracle_table_source] tables[%d] REFUSED: id_column %r is not "
                     "a column identifier", i, id_col)
        return None
    rules = entry.get("resolver_rules")
    if not isinstance(rules, (list, tuple)) or not rules:
        logger.error("[oracle_table_source] tables[%d] (%s) REFUSED: resolver_rules "
                     "must be a non-empty list -- a watched table with no rule can "
                     "satisfy nothing", i, table)
        return None
    try:
        conn_ref: Any = int(conn) if not isinstance(conn, bool) and str(conn).strip().isdigit() else str(conn).strip()
    except (TypeError, ValueError):
        conn_ref = str(conn).strip()
    return {"connection": conn_ref, "table": table.upper(),
            "id_column": id_col.upper(),
            "resolver_rules": [dict(r) for r in rules if isinstance(r, Mapping)]}


def producer_refusal(cfg: Optional[Mapping[str, Any]] = None) -> Optional[str]:
    """Why the watcher will NOT write evidence on this configuration, or
    None.  Read by ``arrival_sources.producer_health`` on EVERY pod that
    evaluates the gate, so the config block must be on the api pod too."""
    cfg = cfg if cfg is not None else load_config()
    if not cfg.get("enabled", True):
        return ("feed_generation.dependency_oracle_table.enabled is false -- "
                "no Oracle table is read")
    if not cfg.get("tables"):
        return ("feed_generation.dependency_oracle_table.tables is empty -- no "
                "Oracle table is watched, so no row can ever be recorded")
    return None


# ── The declaration ───────────────────────────────────────────────────────

def source_key(connection_id: int, table: str) -> str:
    """The ledger ``source_key`` of an arrival from THIS table AND the
    pseudo-topic its rows land under: ``oracle_table:<connection_id>/<TABLE>``.
    One spelling, written by the watcher, read by the evaluator and the
    rules' ``topic``."""
    return f"{TOPIC_PREFIX}{int(connection_id)}/{str(table).strip().upper()}"


def normalise_declaration(entry: Mapping[str, Any], norm: Dict[str, Any],
                          where: str) -> Dict[str, Any]:
    """The ``table`` must be an Oracle identifier; it is stored UPPER so the
    key the evaluator reads is the one the watcher writes."""
    table = str(norm.get("table") or "").strip()
    if not _IDENT_RE.match(table):
        raise ValueError(f"{where} ({KIND}).table={table!r} is not an Oracle "
                         f"identifier ([SCHEMA.]TABLE)")
    norm["table"] = table.upper()
    return norm


def validate_against_connection(db: Any, spec: Mapping[str, Any]) -> Optional[str]:
    """The authoring check that needs the database: the connection exists,
    is active and is an Oracle connection.  Returns the refusal, or None."""
    conn_id = int(spec["connection_id"])
    conn = db.get_connection_raw(conn_id)
    if not conn or conn.get("is_active") is False:
        return f"connection {conn_id} does not exist"
    ctype = str(conn.get("connection_type") or "").strip().lower()
    if ctype != "oracle":
        return (f"connection {conn_id} ({conn.get('name')}) is {ctype or '?'}; an "
                f"oracle_table source reads an Oracle connection")
    # 2026-10-12 (found by the owner's month-end journey, by clicks): a
    # (connection, table) the watcher does NOT watch can never be met -- the
    # tile said "COULD NOT TELL" for ever.  Refused at the save, naming what
    # IS watched (feed_generation.dependency_oracle_table.tables).
    try:
        wt, res = watched_table_for(db, spec)
    except Exception:                                   # noqa: BLE001 -- unreadable config: not judged here
        return None
    if wt is None:
        watched = ", ".join(f"{t.table} on {t.connection_name} (connection {t.connection_id})"
                            for t in res.tables) or "none"
        return (f"{spec.get('table')} on connection {conn_id} ({conn.get('name')}) is not watched -- "
                f"no row of it would ever be recorded.  Watched: {watched} "
                f"(feed_generation.dependency_oracle_table.tables)")
    return None


def watched_pairs(db: Any) -> List[Dict[str, Any]]:
    """The (connection, table) pairs the watcher reads -- what an
    ``oracle_table`` source may name (the feed form offers exactly these)."""
    res = resolve_watched_tables(db)
    return [{"connection_id": t.connection_id, "connection_name": t.connection_name,
             "table": t.table} for t in res.tables]


# ── What is watched ───────────────────────────────────────────────────────

@dataclass
class WatchedTable:
    connection_id: int
    connection_name: str
    table: str
    id_column: str
    rules: List[ResolverRule]
    conn_raw: Optional[Dict[str, Any]] = None

    @property
    def topic(self) -> str:
        return source_key(self.connection_id, self.table)


@dataclass
class Resolution:
    """What the configuration resolves to on this database: the tables that
    can be watched, and every entry that cannot (with its reason)."""
    tables: List[WatchedTable] = field(default_factory=list)
    problems: List[str] = field(default_factory=list)


#: the reserved connection name for QueryStudio's OWN database (2026-10-28): the
#: owner's Kafka service inserts into its qs_kafka_message table -- no Oracle, no
#: connection row, read through QueryStudio's own engine
OWN_DATABASE = "querystudio"
OWN_DATABASE_ID = 0


def _connection_for(db: Any, ref: Any) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """``(raw connection, refusal)`` for a configured ``connection`` -- an id
    or a name.  Credentials decrypted (the watcher opens a connector).
    ``querystudio`` is QueryStudio's own database (no connection row)."""
    if isinstance(ref, str) and ref.strip().lower() == OWN_DATABASE:
        return {"id": OWN_DATABASE_ID, "name": "QueryStudio database",
                "connection_type": OWN_DATABASE, "is_active": True}, None
    if isinstance(ref, int):
        conn = db.get_connection_raw(ref)
        if not conn:
            return None, f"connection id {ref} does not exist"
    else:
        rows = db.list_connections(active_only=True, limit=10000)
        hit = next((c for c in rows if str(c.get("name")) == str(ref)), None)
        if hit is None:
            return None, f"no active connection is named {ref!r}"
        conn = db.get_connection_raw(int(hit["id"]))
        if not conn:
            return None, f"connection {ref!r} (id {hit['id']}) could not be read"
    if conn.get("is_active") is False:
        return None, f"connection {conn.get('name')!r} (id {conn.get('id')}) is inactive"
    if str(conn.get("connection_type") or "").lower() != "oracle":
        return None, (f"connection {conn.get('name')!r} (id {conn.get('id')}) is "
                      f"{conn.get('connection_type')}, not oracle")
    return conn, None


def resolve_watched_tables(db: Any, cfg: Optional[Mapping[str, Any]] = None) -> Resolution:
    """Every configured table bound to its connection and its rules; an
    entry whose connection cannot be resolved is a stated problem."""
    from core.feed.kafka_arrivals import rules_from_config
    cfg = cfg if cfg is not None else load_config()
    out = Resolution()
    for entry in cfg.get("tables") or []:
        try:
            conn, why = _connection_for(db, entry["connection"])
        except Exception as exc:  # noqa: BLE001 -- the connection table unreadable: say so
            conn, why = None, f"connection lookup failed: {exc}"
        if conn is None:
            out.problems.append(f"table {entry['table']}: {why}")
            continue
        topic = source_key(int(conn["id"]), entry["table"])
        rules = rules_from_config([{**r, "topic": topic} for r in entry["resolver_rules"]])
        if not rules:
            out.problems.append(f"table {entry['table']}: every resolver rule was refused")
            continue
        out.tables.append(WatchedTable(
            connection_id=int(conn["id"]), connection_name=str(conn.get("name") or ""),
            table=entry["table"], id_column=entry["id_column"], rules=rules,
            conn_raw=conn))
    return out


def watched_table_for(db: Any, spec: Mapping[str, Any],
                      cfg: Optional[Mapping[str, Any]] = None) -> Tuple[Optional[WatchedTable], Resolution]:
    """The configured table a declaration ``{connection_id, table}`` names,
    if any -- the evaluator's "can this ever be satisfied" question."""
    res = resolve_watched_tables(db, cfg)
    want = source_key(int(spec["connection_id"]), str(spec.get("table") or ""))
    return next((t for t in res.tables if t.topic == want), None), res


# ── Reading the table ─────────────────────────────────────────────────────

def _watermark_key(wt: WatchedTable) -> str:
    return f"feed_oracle_table_source.watermark.{wt.connection_id}.{wt.table}"


def _floor_key(wt: WatchedTable) -> str:
    return _watermark_key(wt) + ".floor"


def read_watermark(db: Any, wt: WatchedTable) -> Optional[int]:
    """The highest id landed, or None before the table was first seen."""
    return _int_setting(db, _watermark_key(wt))


def read_floor(db: Any, wt: WatchedTable) -> Optional[int]:
    """The id the watcher STARTED at (first sight, less initial_lookback_rows):
    rows at or below it predate the watcher and are never read, whatever the
    rescan window -- without this floor the second tick would re-read
    ``watermark - rescan_rows`` into the table's history and land years of
    rows as today's arrivals."""
    return _int_setting(db, _floor_key(wt))


def _int_setting(db: Any, key: str) -> Optional[int]:
    raw = db.get_system_setting(key, None)
    try:
        return int(raw) if raw is not None else None
    except (TypeError, ValueError):
        return None


def write_watermark(db: Any, wt: WatchedTable, value: int, *, floor: bool = False) -> None:
    db.set_system_setting(_watermark_key(wt), int(value), updated_by=WRITER,
                          description=f"highest {wt.table}.{wt.id_column} landed by the "
                                      f"oracle_table dependency watcher")
    if floor:
        db.set_system_setting(_floor_key(wt), int(value), updated_by=WRITER,
                              description=f"{wt.table}.{wt.id_column} the watcher started "
                                          f"at; rows at or below it are never read")


def default_query(db: Any, wt: WatchedTable) -> Callable[[str], List[Dict[str, Any]]]:
    """``sql -> rows`` through THE connector factory (circuit breaker, the
    product's own Oracle client), one connector per tick per table."""
    if wt.connection_id == OWN_DATABASE_ID:
        from sqlalchemy import text as _text

        def _own(sql: str) -> List[Dict[str, Any]]:
            with db.engine.connect() as c:
                return [dict(r._mapping) for r in c.execute(_text(sql))]
        return _own
    from core.connectors import get_connector
    conn = wt.conn_raw or db.get_connection_raw(wt.connection_id)
    connector = get_connector(str(conn["connection_type"]), dict(conn.get("config") or {}),
                              connection_id=int(conn["id"]),
                              connection_name=str(conn.get("name") or ""))

    def _run(sql: str) -> List[Dict[str, Any]]:
        try:
            out = connector.execute_query(sql, limit=None)
            return list((out or {}).get("rows") or [])
        finally:
            try:
                connector.close()
            except Exception:  # noqa: BLE001 -- closing is best effort
                pass
    return _run


def new_rows_sql(wt: WatchedTable, low: int, batch: int) -> str:
    """The ONE statement: new rows above the watermark, oldest first, bounded."""
    if wt.connection_id == OWN_DATABASE_ID:     # PostgreSQL / SQLite: LIMIT
        return (f"SELECT * FROM {wt.table} WHERE {wt.id_column} > {int(low)} "
                f"ORDER BY {wt.id_column} LIMIT {int(batch)}")
    return (f"SELECT * FROM {wt.table} WHERE {wt.id_column} > {int(low)} "
            f"ORDER BY {wt.id_column} FETCH FIRST {int(batch)} ROWS ONLY")


def max_id_sql(wt: WatchedTable) -> str:
    return f"SELECT MAX({wt.id_column}) AS MAX_ID FROM {wt.table}"


def normalise_row(row: Mapping[str, Any]) -> Dict[str, Any]:
    """A cursor row as a MESSAGE PAYLOAD: UPPER keys, JSON-safe scalars."""
    out: Dict[str, Any] = {}
    for k, v in (row or {}).items():
        out[str(k).upper()] = _json_safe(v)
    return out


def _json_safe(v: Any) -> Any:
    if isinstance(v, bool) or v is None or isinstance(v, (int, float, str)):
        return v
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    if isinstance(v, (bytes, bytearray)):
        try:
            return bytes(v).decode("utf-8")
        except UnicodeDecodeError:
            return bytes(v).hex()
    return str(v)


# ── The tick ──────────────────────────────────────────────────────────────

def _new_summary() -> Dict[str, Any]:
    return {"status": "ran", "tables": 0, "rows_read": 0, "landed": 0,
            "resolved": 0, "unmatched": 0, "filtered": 0, "unresolvable": 0,
            "already_seen": 0, "retry_later": 0, "errors": 0,
            "arrivals": {"first": 0, "redelivery": 0, "replay": 0, "undecidable": 0},
            "problems": [], "detail": []}


def watch_tick(db: Any, *, cfg: Optional[Mapping[str, Any]] = None,
               query_factory: Optional[Callable[[Any, WatchedTable], Callable[[str], List[Dict[str, Any]]]]] = None,
               alert_fn: Optional[Callable[[str], None]] = None,
               now: Optional[datetime] = None) -> Dict[str, Any]:
    """One pass over every watched table: read the rows above the watermark
    (less the rescan window), resolve each through the rules, record the
    arrivals, land the rows, advance the watermark.  Never raises; the
    summary is the record (status ran / disabled / unconfigured / error)."""
    cfg = dict(cfg) if cfg is not None else load_config()
    summary = _new_summary()
    refusal = producer_refusal(cfg)
    if refusal:
        summary["status"] = "disabled" if not cfg.get("enabled", True) else "unconfigured"
        summary["reason"] = refusal
        return summary
    try:
        res = resolve_watched_tables(db, cfg)
    except Exception as exc:  # noqa: BLE001
        logger.error("[oracle_table_source] could not resolve the watched tables: %s", exc)
        summary.update(status="error", reason=str(exc))
        return summary
    summary["problems"] = list(res.problems)
    summary["errors"] += len(res.problems)
    for p in res.problems:
        logger.error("[oracle_table_source] %s -- not watched this pass", p)
    factory = query_factory or default_query
    for wt in res.tables:
        summary["tables"] += 1
        detail: Dict[str, Any] = {"table": wt.table, "connection": wt.connection_name,
                                  "connection_id": wt.connection_id}
        summary["detail"].append(detail)
        try:
            _watch_table(db, wt, cfg, factory(db, wt), summary, detail, alert_fn,
                         now or datetime.now(timezone.utc))
        except Exception as exc:  # noqa: BLE001 -- one table's failure is not the pass's
            summary["errors"] += 1
            detail["error"] = str(exc)[:500]
            logger.error("[oracle_table_source] %s on %s: tick failed: %s",
                         wt.table, wt.connection_name, exc)
    if summary["rows_read"] or summary["problems"]:
        logger.info("[oracle_table_source] tick: %d table(s), %d row(s) read, %d landed "
                    "(%d resolved, %d unmatched, %d filtered, %d unresolvable), %d seen "
                    "before, %d to retry, %d error(s)",
                    summary["tables"], summary["rows_read"], summary["landed"],
                    summary["resolved"], summary["unmatched"], summary["filtered"],
                    summary["unresolvable"], summary["already_seen"],
                    summary["retry_later"], summary["errors"])
    return summary


def _watch_table(db: Any, wt: WatchedTable, cfg: Mapping[str, Any],
                 query: Callable[[str], List[Dict[str, Any]]],
                 summary: Dict[str, Any], detail: Dict[str, Any],
                 alert_fn: Optional[Callable[[str], None]], now: datetime) -> None:
    wm = read_watermark(db, wt)
    if wm is None:
        # First sight of this table: start at its current MAX id (less the
        # configured initial look-back) -- a table holding years of rows
        # must not re-land its history as arrivals on day one.
        rows = query(max_id_sql(wt))
        raw_max = (rows[0] if rows else {}) or {}
        current = next((v for k, v in raw_max.items() if str(k).upper() == "MAX_ID"), None)
        current_i = int(_json_safe(current) or 0) if current is not None else 0
        wm = max(0, current_i - int(cfg.get("initial_lookback_rows", 0)))
        write_watermark(db, wt, wm, floor=True)
        detail["initialised_at"] = wm
        logger.info("[oracle_table_source] %s on %s: watermark initialised at %d "
                    "(table max %d, initial_lookback_rows %s)", wt.table,
                    wt.connection_name, wm, current_i, cfg.get("initial_lookback_rows", 0))
    floor = read_floor(db, wt)
    low = max(0, wm - int(cfg.get("rescan_rows", 0)), floor if floor is not None else 0)
    detail["watermark_before"] = wm
    detail["read_from"] = low
    rows = query(new_rows_sql(wt, low, int(cfg.get("batch_rows", 500))))
    detail["rows"] = len(rows)
    summary["rows_read"] += len(rows)
    highest, lowest_retry = wm, None
    for row in rows:
        payload = normalise_row(row)
        rid = payload.get(wt.id_column)
        if not isinstance(rid, int) or isinstance(rid, bool):
            summary["errors"] += 1
            logger.error("[oracle_table_source] %s: a row's %s is %r, not an integer -- "
                         "the row cannot be landed (no identity) and is skipped",
                         wt.table, wt.id_column, rid)
            continue
        outcome = _process_row(db, wt, rid, payload, summary, alert_fn, now)
        if outcome == "retry_later":
            lowest_retry = rid if lowest_retry is None else min(lowest_retry, rid)
        else:
            highest = max(highest, rid)
    new_wm = highest if lowest_retry is None else min(highest, lowest_retry - 1)
    if new_wm > wm:
        write_watermark(db, wt, new_wm)
    detail["watermark_after"] = max(wm, new_wm)
    detail["rows_batch_full"] = len(rows) >= int(cfg.get("batch_rows", 500))


def _process_row(db: Any, wt: WatchedTable, rid: int, payload: Dict[str, Any],
                 summary: Dict[str, Any], alert_fn: Optional[Callable[[str], None]],
                 now: datetime) -> str:
    """One row: seen before -> nothing; else resolve, record, land.  Returns
    the outcome word (``resolved`` / ``unmatched`` / ``filtered`` /
    ``unresolvable`` / ``already_seen`` / ``retry_later``)."""
    from core.feed.kafka_arrivals import alert_once, dependency_is_unmatched
    topic = wt.topic
    if db.get_kafka_message(topic, 0, rid) is not None:
        summary["already_seen"] += 1
        return "already_seen"
    message = {"topic": topic, "partition": 0, "offset": rid, "payload": payload}
    try:
        arrival = resolve_message(message, wt.rules)
    except FilteredMessage as exc:
        if _land(db, topic, rid, payload, FILTERED, reason=str(exc), now=now):
            summary["landed"] += 1
        summary["filtered"] += 1
        return "filtered"
    except UnresolvedMessage as exc:
        if _land(db, topic, rid, payload, UNRESOLVABLE, reason=str(exc), now=now):
            summary["landed"] += 1
        summary["unresolvable"] += 1
        alert_once(f"unresolvable:{topic}:{rid}",
                   f"[oracle_table_source] row {wt.table}.{wt.id_column}={rid} on "
                   f"{wt.connection_name} is UNRESOLVABLE and will not be retried: {exc}",
                   alert_fn)
        return "unresolvable"
    result = record_dependency_arrival(
        db, dependency_name=arrival.dependency_name,
        business_date=arrival.business_date, source=LEDGER_SOURCE,
        message_identity=f"{topic}#{rid}", payload=payload,
        reported_rows=arrival.reported_rows, source_key=topic)
    if not result.recorded:
        # Not landed: the next tick re-reads it (the watermark stops short).
        summary["retry_later"] += 1
        return "retry_later"
    summary["arrivals"][result.classification] = (
        summary["arrivals"].get(result.classification, 0) + 1)
    if arrival.derived and dependency_is_unmatched(db, arrival.dependency_name):
        reason = (f"no active feed declares dependency {arrival.dependency_name!r} "
                  f"(rendered from row {wt.id_column}={rid} of {wt.table} by its rule); "
                  f"the arrival for {arrival.business_date.isoformat()} is on the ledger "
                  f"and will satisfy a feed declared later")
        if _land(db, topic, rid, payload, UNMATCHED, dependency_name=arrival.dependency_name,
                 business_date=arrival.business_date, reason=reason, now=now):
            summary["landed"] += 1
        summary["unmatched"] += 1
        alert_once(f"unmatched:{arrival.dependency_name}",
                   f"[oracle_table_source] UNMATCHED arrival: {reason}", alert_fn)
        # 2026-10-11 -- a template that declares auto_onboard turns this new
        # system entity into a feed (core/feed/auto_onboard.py).
        from core.feed.auto_onboard import request_onboarding
        request_onboarding(db, payload, dependency_name=arrival.dependency_name,
                           business_date=arrival.business_date, source="oracle_table",
                           message_identity=f"{topic}#{rid}")
        return "unmatched"
    if _land(db, topic, rid, payload, RESOLVED, dependency_name=arrival.dependency_name,
             business_date=arrival.business_date, now=now):
        summary["landed"] += 1
    summary["resolved"] += 1
    return "resolved"


def _land(db: Any, topic: str, rid: int, payload: Mapping[str, Any], resolution: str, *,
          dependency_name: Optional[str] = None, business_date: Optional[date] = None,
          reason: Optional[str] = None, now: datetime) -> bool:
    """Land the row ALREADY DECIDED (the Kafka resolver pass never sees it as
    'landed', so the two producers cannot race over one row).  False when
    the unique key says it was landed already, or the write failed."""
    data = {
        "topic": topic, "partition": 0, "offset": int(rid), "message_key": None,
        "payload": json.dumps(payload, default=str), "landed_at": now,
        "resolution": resolution,
        "unresolvable_reason": (str(reason)[:1000] if reason else None),
        "dependency_name": dependency_name, "business_date": business_date,
        "resolved_at": now, "created_by": WRITER, "updated_at": now, "updated_by": WRITER,
    }
    try:
        return db.insert_kafka_message(data) is not None
    except Exception as exc:  # noqa: BLE001 -- the arrival is recorded; the landing is the audit row
        logger.error("[oracle_table_source] row %s#%s could not be landed (%s) -- the "
                     "arrival (if any) IS on the ledger; the next tick re-reads the row "
                     "and the ledger classifies that as a redelivery", topic, rid, exc)
        return False


# ── The evaluator (one declared source -> verdict, reason, evidence) ───────

def evaluate_source(db: Any, *, dependency_name: str, spec: Mapping[str, Any],
                    business_date: date,
                    ledger_events: Optional[List[Dict[str, Any]]],
                    ledger_error: Optional[str]) -> tuple:
    """Order of evidence:
      1. the ledger unreadable                              -> COULD NOT TELL;
      2. an ``oracle_table`` arrival for D from THIS table  -> MET (with the
         row id and the reported row count);
      3. no configured table entry watches (connection, table), or none of
         its rules can render this dependency                -> COULD NOT TELL,
         "cannot be satisfied" -- no row read will ever be recorded for it;
      4. otherwise NOT MET, naming the table and the watermark.
    (A watcher that is switched off or not running is the producer's
    health, decided once in ``arrival_sources.producer_health``.)"""
    from core.feed.kafka_arrivals import rules_routing
    from core.feed.ledger import same_source_rows
    if ledger_events is None:
        return (UNKNOWN, f"the arrival ledger could not be read ({ledger_error})", None)
    key = source_key(int(spec["connection_id"]), str(spec.get("table") or ""))
    hits = same_source_rows(
        [e for e in ledger_events if str(e.get("source") or "") == LEDGER_SOURCE], key)
    if hits:
        last = hits[-1]
        return (MET,
                f"row in {spec.get('table')} (connection {spec.get('connection_id')}) "
                f"arrived at {last.get('arrived_at')} ({len(hits)} arrival(s), identity "
                f"{last.get('message_identity')}, reported rows {last.get('reported_rows')})",
                {"arrival_count": len(hits), "last_arrived_at": last.get("arrived_at"),
                 "reported_rows": last.get("reported_rows"),
                 "message_identity": last.get("message_identity"), "table": key})
    try:
        wt, res = watched_table_for(db, spec)
    except Exception as exc:  # noqa: BLE001 -- unreadable config: say so, never "not met"
        return (UNKNOWN, f"the oracle_table configuration could not be read: {exc}", None)
    if wt is None:
        why = "; ".join(res.problems) if res.problems else "no tables[] entry names it"
        return (UNKNOWN,
                f"cannot be satisfied: no feed_generation.dependency_oracle_table.tables "
                f"entry watches {spec.get('table')} on connection {spec.get('connection_id')} "
                f"({why}), so no row of it will ever be recorded", {"table": key})
    if not rules_routing(wt.rules, dependency_name, wt.topic):
        return (UNKNOWN,
                f"cannot be satisfied: none of the {len(wt.rules)} resolver rule(s) for "
                f"{wt.table} on {wt.connection_name} renders dependency "
                f"{dependency_name!r}, so no row of it will ever be recorded for this "
                f"dependency", {"table": key, "rules": len(wt.rules)})
    try:
        wm = read_watermark(db, wt)
    except Exception:  # noqa: BLE001 -- the watermark is evidence, not the verdict
        wm = None
    cfg = load_config()
    return (NOT_MET,
            f"no row of {wt.table} on {wt.connection_name} for "
            f"{business_date.isoformat()} has matched the rule yet (the watcher reads "
            f"the table every {cfg['interval_seconds']} s; watermark "
            f"{wt.id_column}={wm if wm is not None else 'not started'})",
            {"table": key, "watermark": wm, "interval_seconds": cfg["interval_seconds"]})


__all__ = [
    "KIND", "LEDGER_SOURCE", "DAEMON", "WatchedTable", "Resolution", "load_config",
    "producer_refusal", "source_key", "normalise_declaration",
    "validate_against_connection", "resolve_watched_tables", "watched_table_for",
    "read_watermark", "read_floor", "write_watermark", "default_query", "new_rows_sql",
    "max_id_sql", "normalise_row", "watch_tick", "evaluate_source",
]
