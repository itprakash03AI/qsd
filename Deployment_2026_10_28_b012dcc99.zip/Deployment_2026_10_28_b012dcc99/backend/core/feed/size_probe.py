"""Count THIS run's rows on the source before the engine is chosen (2026-10-26).

The owner: "native is really slow for 2m rows with 600 columns ... why by
default is native?".  A feed with no admin estimate, no upstream ROW_COUNT
for the date and no previous run had NO size, and the router's "no estimate"
rule sends such a run to the shared server however large it is.  The source
count meant for this case (``feed_engine._build_noniceberg_jdbc_count_fn``)
was a stub that always answered None, behind a config key nothing declared.

``count_rows(db, feed_config, timeout=)`` renders each side's SQL for the
run's business date with the engine's own render
(``test_as_feed.planned_sql`` -- the "Query of this run" text), runs
``SELECT COUNT(*) FROM (<it>)`` on that side's connection
(``cross_source_combine.run_side_to_parquet``, every connection type) and
adds the sides -- on SQL sources only, each side secured under the feed's
own principal (see ``count_rows``).  Bounded: a count still running after ``timeout`` seconds is
answered ``timed_out`` -- a source that needs that long just to COUNT is no
job for the shared server, and the caller sizes the run as large.  A side
that cannot be counted is unknown (None, with the reason): the router's
no-estimate rule then stands.  The count is for routing only; nothing it
reads is shown or delivered.

``columns_of(db, feed_config)`` is the run's width from its SQL text
(``batch_budget.sql_width``; a cross-source feed = the wider side;
``SELECT *`` = unknown) -- the router weighs a wide run by it
(``run_size.width_weighted_rows``).
"""
from __future__ import annotations

import logging
import os
import shutil
import tempfile
import threading
import uuid
from datetime import date
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _business_date(feed_config: Dict[str, Any]) -> date:
    from core.feed.run_size import run_business_date
    return run_business_date(feed_config) or date.today()


def size_this_run(db: Any, feed_config: Dict[str, Any], cfg: Any, *,
                  count_on_source: bool = True) -> Dict[str, Any]:
    """THE size the router decides on, in order: ``run_size.estimate`` (an
    admin's estimate, the upstream messages' ROW_COUNT for this business
    date, the previous run), the Iceberg statistics of the tables the SQL
    reads, else -- when ``feed_generation.size_probe_enabled`` and the caller
    allows it -- a bounded COUNT on the source (``count_rows``; a count that
    does not finish sizes the run as large).  Plus the run's ``columns``.
    The engine records the answer as ``_run_size``; the feed form's "what
    Automatic will pick" asks the same function (without the count)."""
    from core.feed.run_size import estimate
    size = dict(estimate(db, feed_config))
    if size["rows"] is None:
        iceberg = _iceberg_estimate(db, feed_config)
        if iceberg:
            size = {"rows": iceberg, "source": "Iceberg table statistics"}
    if size["rows"] is None:
        catalog = _catalog_sizes(db, feed_config)
        if catalog["rows"]:
            # the WHOLE tables' size -- an upper bound for a filtered query,
            # so it errs toward the larger engine, never the smaller
            size = {"rows": catalog["rows"], "source": "the tables' size in the schema catalog"}
    if size["rows"] is None and count_on_source and bool(getattr(cfg, "size_probe_enabled", True)):
        try:
            probe = count_rows(db, feed_config, timeout=float(getattr(cfg, "size_probe_timeout_seconds", 30)))
        except Exception as exc:                          # noqa: BLE001 -- unknown size, said
            probe = {"rows": None, "timed_out": False, "why": f"could not count: {_safe(exc)}"}
        rows = probe["rows"]
        if rows is None and probe["timed_out"]:
            rows = int(getattr(cfg, "auto_route_threshold_rows", 500_000)) + 1
        size = {"rows": rows, "source": probe["why"], "probe": probe}
        logger.info("[size_probe] feed %s: %s -> rows=%s", feed_config.get("id"), probe["why"], rows)
    try:
        size["columns"] = columns_of(db, feed_config)
    except Exception:                                     # noqa: BLE001 -- unknown width
        size["columns"] = None
    return size


def _iceberg_estimate(db: Any, feed_config: Dict[str, Any]) -> Optional[int]:
    """Sum of the Iceberg manifest record counts of the registered tables
    each side's SQL reads (the background sync's cache; no S3 work), or
    None.  Moved from the engine (Phase 145.2) unchanged."""
    try:
        from core.feed_row_estimator import estimate_rows_from_iceberg_cache
        from core.feed_sql_resolver import resolve_feed_sql
        from core.query_hints import extract_referenced_tables
        resolved = resolve_feed_sql(db, feed_config)
    except Exception as exc:                              # noqa: BLE001
        logger.debug("[size_probe] feed %s: Iceberg estimate unavailable (%s)", feed_config.get("id"), exc)
        return None

    def one(sql: Optional[str], conn_id: Any) -> Optional[int]:
        if not sql or not conn_id:
            return None
        try:
            reg = ((db.get_connection_raw(conn_id) or {}).get("config") or {}).get("registered_tables") or []
            refs = extract_referenced_tables(reg, sql)
            if not refs:
                return None
            return estimate_rows_from_iceberg_cache(connection_id=conn_id, registered_tables=reg,
                                                    referenced_tables=refs, partition_filters=None)
        except Exception as exc:                          # noqa: BLE001
            logger.debug("[size_probe] Iceberg side estimate failed (conn=%s): %s", conn_id, exc)
            return None

    total = ((one(resolved.get("sql"), resolved.get("connection_id") or feed_config.get("connection_id")) or 0)
             + (one(resolved.get("secondary_sql"), feed_config.get("secondary_connection_id")) or 0))
    return total or None


def _side_tables(db: Any, sql: Optional[str], conn_id: Any) -> list:
    """(connection_id, table name) for every table a side's SQL reads, by the
    connection's registered names when it has them, else the SQL's own."""
    if not sql or not conn_id:
        return []
    try:
        reg = ((db.get_connection_raw(conn_id) or {}).get("config") or {}).get("registered_tables") or []
    except Exception:                                     # noqa: BLE001
        reg = []
    names = None
    if reg:
        from core.query_hints import extract_referenced_tables
        names = extract_referenced_tables(reg, sql)
    if not names:
        try:
            import sqlglot
            from sqlglot import exp
            names = {t.name for t in sqlglot.parse_one(sql, read="trino").find_all(exp.Table) if t.name}
        except Exception:                                 # noqa: BLE001
            names = set()
    return [(conn_id, n) for n in sorted(names)]


def _catalog_sizes(db: Any, feed_config: Dict[str, Any]) -> Dict[str, Optional[int]]:
    """Rows and columns of the tables the run reads, from the schema catalog
    (what a schema browse recorded: never a source read).  ``rows`` = their
    sum (unknown when any table's is), ``columns`` = their sum."""
    try:
        from core.feed_sql_resolver import resolve_feed_sql
        from core.schema_catalog import ColumnCatalog
        resolved = resolve_feed_sql(db, feed_config)
        cat = ColumnCatalog(db)
    except Exception:                                     # noqa: BLE001
        return {"rows": None, "columns": None}
    pairs = (_side_tables(db, resolved.get("sql"), resolved.get("connection_id") or feed_config.get("connection_id"))
             + _side_tables(db, resolved.get("secondary_sql"), feed_config.get("secondary_connection_id")))
    rows: Optional[int] = 0
    cols = 0
    for conn_id, name in pairs:
        try:
            entry = cat.get_entry(int(conn_id), name)
        except Exception:                                 # noqa: BLE001
            entry = None
        n = (entry or {}).get("row_estimate")
        rows = rows + int(n) if (rows is not None and isinstance(n, int)) else None
        cols += len((entry or {}).get("columns") or [])
    return {"rows": rows if pairs and rows else None, "columns": cols or None}


def columns_of(db: Any, feed_config: Dict[str, Any]) -> Optional[int]:
    """The run's output column count from its SQL text -- for ``SELECT *``,
    the read tables' columns in the schema catalog -- or None (unknown)."""
    try:
        from core.feed.batch_budget import sql_width
        from core.feed_sql_resolver import resolve_feed_sql
        resolved = resolve_feed_sql(db, feed_config)
    except Exception as exc:                              # noqa: BLE001 -- unknown width, said
        logger.debug("[size_probe] feed %s: width unreadable (%s)", feed_config.get("id"), exc)
        return None
    widths = [w for w in (sql_width(resolved.get("sql") or ""),
                          sql_width(resolved.get("secondary_sql") or "")) if w]
    if widths:
        return max(widths)
    return _catalog_sizes(db, feed_config)["columns"]


#: feeds being counted right now -- one count per feed at a time
_COUNTING: set = set()
_COUNTING_LOCK = threading.Lock()


def _safe(exc: BaseException) -> str:
    """The source's verdict in the platform's sanitised words (never raw text)."""
    try:
        from core.error_sanitizer import describe_exception
        return describe_exception(exc)
    except Exception:                                     # noqa: BLE001
        return type(exc).__name__


def _side_configs(feed: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    from core.feed.source_plan import secondary_side_config
    if not feed.get("secondary_connection_id"):
        return {"primary": dict(feed)}
    return {"primary": {**feed, "_cross_side": "primary"}, "secondary": secondary_side_config(feed)}


def _is_sql_source(conn_type: str) -> bool:
    """Counted on the SOURCE engine (never in this process)."""
    from core.connectors import SQL_CONNECTOR_TYPES
    return conn_type in SQL_CONNECTOR_TYPES


def count_rows(db: Any, feed_config: Dict[str, Any], *, timeout: float) -> Dict[str, Any]:
    """``{"rows": int | None, "timed_out": bool, "why": str}`` for this run.

    Counted ONLY on SQL sources (Trino / Starburst / Snowflake / Oracle ...):
    the work is the source engine's and this process waits for one number.
    A FILE side (S3 / local, read by DuckDB in THIS process) is never counted
    here -- found live 2026-10-26: a count of a 40M x 460-column table ran
    inside the scheduler after its time was up and held 4 GB; its table
    statistics are the estimate instead.  Each side is SECURED under the
    feed's own principal first (``rls.secure_feed_sql_report``, the run's
    call), so the count is the rows the run would read.  A count still
    running at ``timeout`` is CANCELLED on the source (the connector's
    cursor cancel) and answered ``timed_out``.  One count per feed at a time."""
    from core.feed.rls import secure_feed_sql_report
    from core.feed.test_as_feed import planned_sql
    feed = {k: v for k, v in feed_config.items() if not str(k).startswith("_")}
    sides = planned_sql(db, feed, _business_date(feed_config))
    broken = [s for s in sides if not s.get("sql") or s.get("error")]
    if not sides or broken:
        return {"rows": None, "timed_out": False,
                "why": "could not count: the query could not be prepared for this date"}
    configs = _side_configs(feed)
    plans = []
    for side in sides:
        cfg = configs.get(side["side"]) or feed
        conn_id = cfg.get("connection_id")
        conn = db.get_connection_raw(int(conn_id)) if conn_id else None
        if not conn:
            return {"rows": None, "timed_out": False, "why": f"could not count: the {side['side']} connection is missing"}
        conn_type = str(conn.get("connection_type") or (conn.get("config") or {}).get("type") or "")
        if not _is_sql_source(conn_type):
            return {"rows": None, "timed_out": False,
                    "why": "not counted: the source is files, read by this server (its table statistics are used)"}
        try:
            secured, _report = secure_feed_sql_report(db, side["sql"], cfg, connection_id=conn.get("id"),
                                                       connection_type=conn_type,
                                                       request_id=f"size-probe-{uuid.uuid4().hex[:8]}")
        except ValueError:
            return {"rows": None, "timed_out": False, "why": "not counted: row security refuses this side"}
        plans.append((side["side"], conn, secured))
    key = feed_config.get("id") or id(feed_config)
    with _COUNTING_LOCK:
        if key in _COUNTING:
            return {"rows": None, "timed_out": False, "why": "not counted: a count for this feed is already running"}
        _COUNTING.add(key)
    done = threading.Event()
    stop = threading.Event()
    result: Dict[str, Any] = {}

    def work() -> None:
        tmp = tempfile.mkdtemp(prefix="qs_size_probe_")
        try:
            total = 0
            for label, conn, sql in plans:
                n = _count_one(db, conn, sql, tmp, label, stop)
                if n is None:
                    result["why"] = f"could not count the {label} side"
                    return
                total += n
            result["rows"] = total
        except Exception as exc:                          # noqa: BLE001 -- unknown, said (sanitised)
            result["why"] = f"could not count: {_safe(exc)}"
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
            with _COUNTING_LOCK:
                _COUNTING.discard(key)
            done.set()

    threading.Thread(target=work, name=f"size-probe-{key}", daemon=True).start()
    if not done.wait(timeout):
        stop.set()                                        # the connector cancels the statement
        return {"rows": None, "timed_out": True,
                "why": f"counting the rows on the source took longer than {timeout:g} s"}
    if "rows" in result:
        return {"rows": int(result["rows"]), "timed_out": False, "why": "counted on the source"}
    return {"rows": None, "timed_out": False, "why": result.get("why") or "could not count"}


def _count_one(db: Any, conn: Dict[str, Any], sql: str, tmp: str, label: str,
               stop: threading.Event) -> Optional[int]:
    from core.executors.cross_source_combine import SideSpec, run_side_to_parquet, _strip_sql
    path = os.path.join(tmp, f"{label}_{uuid.uuid4().hex[:8]}.parquet")
    run_side_to_parquet(SideSpec(label=f"{label}-size", connection=conn,
                                 sql=f"SELECT COUNT(*) AS qs_rows FROM ({_strip_sql(sql)}) AS _qs_size"),
                        path, row_cap=None, cancel_event=stop, db_manager=db,
                        execution_id=f"size-probe-{uuid.uuid4().hex[:8]}")
    import pyarrow.parquet as pq
    tbl = pq.read_table(path)
    n = tbl.column(0)[0].as_py() if tbl.num_rows else None
    return int(n) if n is not None else None


# ── what the feed form shows: the engine the next run takes, in words ──────

# 2026-10-27: the ONE set of engine names (core/feed/engine_words.py)
from core.feed.engine_words import ENGINE_WORDS as _ENGINE_WORDS  # noqa: E402


def _n(v: Optional[int]) -> str:
    return f"{v:,}" if isinstance(v, int) else "?"


def engine_choice(db: Any, feed: Dict[str, Any], cfg: Any, *, count_on_source: bool = False) -> Dict[str, Any]:
    """The engine the feed's next run takes and why, through THE size
    (``size_this_run``) and THE router (``pick_backend``).  Never raises: a
    pinned engine that cannot run now is said (``pinned_unavailable``)."""
    from core.feed.backend_router import LaneRefused, pick_backend
    from core.feed.run_size import width_weighted_rows
    feed = dict(feed)
    size = size_this_run(db, feed, cfg, count_on_source=count_on_source)
    feed["_run_size"] = size
    rows, cols = size.get("rows"), size.get("columns")
    base = int(getattr(cfg, "auto_route_width_base_columns", 100) or 100)
    threshold = int(feed.get("size_threshold_rows") or getattr(cfg, "auto_route_threshold_rows", 500_000))
    weighted = width_weighted_rows(rows, cols, base)
    asked = (feed.get("execution_backend") or "auto").lower()
    unavailable = None
    try:
        choice = pick_backend(feed, estimated_rows=rows, cfg=cfg)
    except LaneRefused as refused:
        choice, unavailable = refused.choice, str(refused)
    except Exception as exc:                              # noqa: BLE001 -- said, never raised
        logger.warning("[size_probe] feed %s: engine choice failed: %s", feed.get("id"), _safe(exc))
        return {"engine": None, "words": "Could not tell", "sentence": "The engine could not be worked out right now.",
                "asked": asked, "rows": rows, "rows_source": size.get("source"), "columns": cols}
    engine = choice.backend
    words = _ENGINE_WORDS.get(engine, engine)
    if asked != "auto":
        sentence = (f"You chose the {_ENGINE_WORDS.get(asked, asked)}. "
                    + (f"It cannot run there right now: {unavailable}" if unavailable
                       else "Every run goes there."))
    elif rows is None:
        sentence = (f"Automatic picks the {_ENGINE_WORDS['native']} for now: the size of this feed is not known yet. "
                    + ("When a run starts it counts the rows on the source first and moves to a "
                       "Spark cluster when the run is large." if getattr(cfg, "size_probe_enabled", True)
                       else "Give it an estimated row count, or choose the engine yourself."))
    else:
        size_words = f"about {_n(rows)} rows ({size.get('source')})"
        if cols:
            size_words += f" x {_n(cols)} columns"
        wide = (f", which weighs as {_n(weighted)} rows of {base} columns" if weighted != rows else "")
        if engine == "native":
            moved = ""
            if (weighted or 0) > threshold:
                moved = " A Spark cluster is not available right now, so it runs here."
            sentence = (f"Automatic picks {words}: {size_words}{wide}. The limit for this server is "
                        f"{_n(threshold)} rows.{moved}")
        else:
            sentence = (f"Automatic picks {words}: {size_words}{wide} is more than the "
                        f"{_n(threshold)}-row limit for this server.")
    return {"engine": engine, "words": words, "sentence": sentence, "asked": asked,
            "pinned_unavailable": unavailable, "rows": rows, "rows_source": size.get("source"),
            "columns": cols, "weighted_rows": weighted, "threshold_rows": threshold,
            "base_columns": base, "counted": "probe" in size, "reason": choice.reason}
