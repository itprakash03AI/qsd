"""The parameters a published view over a business report ACCEPTS.

AQD-04 (2026-09-23).  FB-25 made a view published over a business report
inherit that report's parameters -- but only at PUBLISH (and republish) time,
as a snapshot written into ``param_definitions``.  A required parameter added
to the report AFTER the publish reached the report and never the view, and the
deadlock FB-25 fixed came straight back:

* the view's parser did not recognise ``?p_region=`` -- "declared: none";
* the report underneath refused without it -- "Required parameter(s) missing".

A view nobody could call, with nothing to tell the publisher.  A snapshot of a
fact that lives somewhere else is the defect, so the inheritance is no longer a
snapshot: it is computed on every READ of the view (``DatabaseManager.
get_published_view*``), which is the one door every serving route, the view
GET, the OpenAPI/catalog listing and the warm-up already come through.  The
publish/republish paths call the same function, so there is one answer to
"which parameters does this view take", not two.

``inherit_report_params`` is pure (no DB, no HTTP); ``served_report_parameters``
asks the report-version fork which parameters the served definition carries.
The caller decides what an unusable report parameter name means -- the publish REFUSES it (a 400 naming it), a read logs it and
serves what it can (refusing a READ would take the whole view down, the
management screen included, which is where the publisher fixes it).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

#: A view parameter name, as ``ParamDefinition`` validates it.
_NAME_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

#: FB-25 -- a business report's ``parameter_type`` vocabulary onto the
#: published view's ``ParamDefinition.type`` (core.parameters.PARAM_TYPES).
REPORT_PARAM_TYPE_TO_VIEW = {
    "dropdown": "select", "select": "select", "multiselect": "multiselect",
    # 2026-10-28: the report editor SAVES "multi_select"
    # (frontend ReportParameterEditor) -- unmapped, it fell to "string" and a
    # published finance report took one value only.
    "multi_select": "multiselect", "multi-select": "multiselect",
    "date": "date", "datetime": "datetime",
    "number": "number", "numeric": "number", "integer": "integer", "int": "integer",
    "float": "number", "decimal": "number",
    "boolean": "boolean", "bool": "boolean",
    "text": "string", "string": "string",
}


#: The ``source`` an INHERITED entry carries.  An entry marked this way is a
#: copy of the report's parameter, never a publisher's decision: every read
#: DROPS it and recomputes it from the version the view serves.  Without the
#: mark the copy froze -- the view edit route builds its update from the read
#: (which is effective), so one rename persisted the inherited entries as if
#: the publisher had declared them, and a parameter the report later made
#: optional or removed stayed REQUIRED on the view (AQD-04 edge case, found
#: reviewing the fix for what could go wrong).
INHERITED_SOURCE = "report"

_COMPARE_KEYS = ("type", "required", "default", "description")


def valid_param_name(name: str) -> bool:
    return bool(_NAME_RE.match(name or ""))


def _name_of(p: Any) -> str:
    return (p.get("name") if isinstance(p, dict) else getattr(p, "name", "")) or ""


def inherit_report_params(
    param_definitions: Iterable[Any] | None,
    report_params: Iterable[Dict[str, Any]] | None,
) -> Tuple[List[Any], List[str]]:
    """Return ``(effective_definitions, unusable_report_param_names)``.

    Additive and idempotent: an entry the publisher declared (by name,
    case-insensitive) is kept exactly as written; each report parameter not
    already declared is appended in the report's order.
    """
    existing = {_name_of(p).lower() for p in (param_definitions or []) if _name_of(p)}
    out = list(param_definitions or [])
    bad: List[str] = []
    for rp in report_params or []:
        name = str(rp.get("name") or "").strip()
        if not name:
            continue
        if not valid_param_name(name):
            bad.append(name)
            continue
        if name.lower() in existing:
            continue
        ptype = REPORT_PARAM_TYPE_TO_VIEW.get(
            str(rp.get("parameter_type") or "").lower(), "string")
        default = rp.get("default_value")
        out.append({
            "name": name,
            "type": ptype,
            "required": bool(rp.get("is_required")),
            "default": default if default not in ("", None) else None,
            "description": rp.get("label") or rp.get("description") or None,
            "source": INHERITED_SOURCE,
        })
        existing.add(name.lower())
    return out, bad


def _field(p: Any, key: str) -> Any:
    return p.get(key) if isinstance(p, dict) else getattr(p, key, None)


def effective_view_params(
    stored: Iterable[Any] | None,
    served_params: Iterable[Dict[str, Any]] | None,
) -> Tuple[List[Any], List[str]]:
    """THE rule for a view over a business report: the publisher's own
    declarations, plus the served version's parameters recomputed NOW.

    Two kinds of stored entry are copies, not declarations, and are dropped
    before recomputing:

    * an entry marked ``source: "report"`` (every inherited entry since the
      mark exists);
    * a LEGACY unmarked entry (persisted by the FB-25 publish before the
      mark) that is IDENTICAL to what inheritance produces from the served
      version right now -- dropping it changes nothing today and stops it
      freezing tomorrow.

    An unmarked entry that DIFFERS from the report is kept as written: that
    is either a publisher's deliberate override (a default, an optional flag)
    or a legacy copy that has already drifted, and the two cannot be told
    apart -- declared wins, as FB-25 decided.
    """
    fresh, _ = inherit_report_params([], served_params)
    fresh_by_name = {e["name"].lower(): e for e in fresh}
    declared = []
    for p in stored or []:
        if _field(p, "source") == INHERITED_SOURCE:
            continue
        twin = fresh_by_name.get(_name_of(p).lower())
        if twin is not None and _field(p, "source") is None and all(
                _field(p, k) == twin.get(k) for k in _COMPARE_KEYS):
            continue
        # a legacy copy made while "multi_select" was unmapped differs ONLY by
        # the "string" that mapping produced -- still a copy, not a decision
        if (twin is not None and _field(p, "source") is None
                and twin.get("type") == "multiselect" and _field(p, "type") == "string"
                and all(_field(p, k) == twin.get(k) for k in _COMPARE_KEYS if k != "type")):
            continue
        declared.append(p)
    return inherit_report_params(declared, served_params)


def served_report_parameters(db, report_id: int) -> Optional[List[Dict[str, Any]]]:
    """The parameter rows of the definition a published view over this report
    actually SERVES -- or None when it serves none.

    A view is a CONSUMER (no session): it runs the report's current published
    version's snapshot (``core.reports.versions.resolve_execution_report(...,
    consumer=True)``), and that run reads the SNAPSHOT's parameters, not the
    author's draft (``_report_parameters_for_execution``).  Inheriting from
    the draft would make the view demand a parameter the version it serves
    does not declare -- the same deadlock from the other side.  So this asks
    the one fork execution asks, and applies the same rule to its answer: the
    snapshot's rows, or the live table when the version never captured any.

    None when the report cannot be served (missing, unpublished, archived,
    version store unreadable): there is nothing to inherit, and the serving
    path refuses with its own 404/410/503.
    """
    from core.reports.versions import ReportNotServableError, resolve_execution_report
    report = db.get_business_report(int(report_id))
    if not report:
        return None
    try:
        effective, _meta = resolve_execution_report(db, report, None, consumer=True)
    except ReportNotServableError:
        return None
    if "_version_parameters" in effective:
        return list(effective.get("_version_parameters") or [])
    return list(db.list_report_parameters(int(report_id)) or [])
