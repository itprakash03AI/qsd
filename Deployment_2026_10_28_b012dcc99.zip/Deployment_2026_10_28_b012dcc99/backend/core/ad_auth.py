"""
Active Directory / LDAP authentication for QueryStudio.

When auth.type = "ad" in config.json, all API requests must include an
Authorization: Bearer <base64(user:password)> header (HTTP Basic encoded
as Bearer for API compatibility) OR a session token obtained from POST /auth/login.

AD configuration (config.json or QUERYSTUDIO_AUTH_* env vars):
  ad_server              – LDAP server URL  e.g. "ldap://ad.example.com"
  ad_domain              – Windows domain   e.g. "EXAMPLE"
  ad_base_dn             – Search base      e.g. "DC=example,DC=com"
  ad_user_search_filter  – LDAP filter with {username} placeholder
  ad_group_attribute     – Attribute holding group memberships (memberOf)
  ad_admin_groups        – Comma-separated list of AD groups → admin role

Requires: ldap3   (pip install ldap3)
"""
from __future__ import annotations

import base64
import hashlib
import logging
import secrets
from typing import Optional

from core.config import dn_common_name
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

# ── Password hashing (PBKDF2-SHA256, stdlib only) ────────────────────────────

_PBKDF2_PREFIX = "$pbkdf2$"
_PBKDF2_ITERATIONS = 260_000  # OWASP 2024 recommendation


def hash_password(password: str) -> str:
    """Hash a password using PBKDF2-SHA256 with a random 16-byte salt."""
    salt = secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), _PBKDF2_ITERATIONS
    )
    return f"{_PBKDF2_PREFIX}{salt}${h.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verify a password against a stored PBKDF2 hash.

    Also accepts plain-text passwords (legacy/migration) — if the stored value
    doesn't start with the PBKDF2 prefix, it's compared as plain text.
    """
    # 2026-07-14 hardening: reject empty inputs up front.  Without this an
    # account row seeded with an empty password_hash would authenticate on an
    # empty password (``compare_digest("", "") is True``) — a silent bypass on
    # a misconfigured break-glass row.  A real credential is never empty.
    if not password or not stored_hash:
        return False
    if stored_hash.startswith(_PBKDF2_PREFIX):
        # Format: $pbkdf2$<salt>$<hash_hex>
        rest = stored_hash[len(_PBKDF2_PREFIX):]
        if "$" not in rest:
            return False
        salt, expected_hex = rest.split("$", 1)
        h = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt.encode("utf-8"), _PBKDF2_ITERATIONS
        )
        return secrets.compare_digest(h.hex(), expected_hex)
    # Plain-text fallback (pre-migration)
    return secrets.compare_digest(password, stored_hash)


def _sanitize_ldap(value: str) -> str:
    """Escape special LDAP filter characters to prevent injection."""
    # RFC 4515 § 3: escape *, (, ), \\, NUL
    value = value.replace("\\", "\\5c")
    value = value.replace("*", "\\2a")
    value = value.replace("(", "\\28")
    value = value.replace(")", "\\29")
    value = value.replace("\x00", "\\00")
    return value


def _ldap3():
    try:
        import ldap3
        return ldap3
    except ImportError:
        raise RuntimeError(
            "ldap3 is not installed. Run: pip install ldap3  then restart the backend."
        )


def _resolve_role(username: str, groups: list, group_dns: tuple | list = ()) -> str:
    """
    Determine user role: admin > analyst > viewer (highest wins).

    Resolution order:
      1. Explicit per-user role from config (user_roles)
      2. AD group-based role (ad_admin_groups > ad_analyst_groups > ad_viewer_groups)
      3. Default: viewer (least privilege)
    """
    from core.config import auth as _auth
    user_roles = _auth.user_roles

    # 1. Explicit per-user role — validated against the DECLARED
    # assignable vocabulary (core.roles.assignable_roles), not a local
    # spelling of it.  2026-08-23: the old inline tuple omitted the
    # support role, so "user:support" silently degraded to viewer while
    # every support gate in the product stayed dead.
    from core.roles import assignable_roles
    explicit = user_roles.get(username.lower())
    if explicit in assignable_roles():
        return explicit

    # 2. AD group-based role (highest priority wins).  A setting written as
    # a bare name matches a group's CN; one written as a full DN matches
    # ONLY the user's full memberOf DN (2026-10-28: by its CN alone, a
    # same-named group in another OU would be granted the role) --
    # core/config.py::_ad_group_names keeps a DN whole.  The two are kept
    # APART: a group whose own NAME reads like a DN (escaped '=' and ',')
    # must never satisfy a DN setting.
    from core.config import normalize_dn
    user_names = {g.lower() for g in groups}
    user_dns = {normalize_dn(d) for d in (group_dns or ()) if d}

    def _member_of(configured) -> bool:
        for entry in configured:
            if ("=" in entry and entry in user_dns) or ("=" not in entry and entry in user_names):
                return True
        return False

    if _member_of(_auth.ad_admin_groups):
        return "admin"
    if _member_of(_auth.ad_analyst_groups):
        return "analyst"
    if _member_of(_auth.ad_viewer_groups):
        return "viewer"

    # 3. Default: viewer (least privilege)
    return "viewer"


def _make_ldap_server(
    ldap3,
    server_url: str,
    connect_timeout: int,
    use_ssl: bool,
    tls_validate: bool,
    ca_file: str = "",
    check_hostname: bool = False,
):
    """Build an ldap3 Server object with TLS and timeout config.

    ``ca_file`` (optional): path to a PEM CA bundle used to validate the AD
    server certificate.  If empty, falls back to the OS default trust store.
    Ignored when ``tls_validate`` is False (all certs accepted).

    ``check_hostname`` (default **False**): when True, the peer certificate's
    CN / SAN must match the hostname in ``server_url``.  Defaults to False
    because AD certs are almost always issued to a specific DC FQDN
    (e.g. ``dc01.intranet.corp.com``) rather than the domain name used in
    ``ad_server`` (e.g. ``intranet.corp.com``).
    """
    tls = None
    _server_url_norm = (server_url or "").strip().lower()
    _is_ssl = use_ssl or _server_url_norm.startswith("ldaps://")

    if _is_ssl:
        import ssl as _ssl

        if not tls_validate:
            # ── Option A: skip ALL validation (dev/testing only) ──────────
            tls = ldap3.Tls(validate=_ssl.CERT_NONE)
        else:
            # ── Option B: validate cert chain ± hostname ──────────────────
            # ldap3.Tls delegates to Python's ssl module.  When validate is
            # CERT_REQUIRED, Python auto-sets check_hostname=True on the
            # SSLContext — which rejects the cert if the CN/SAN doesn't
            # match the connection target.  AD certs are almost always issued
            # to the DC FQDN, not the domain name, so we need to override.
            #
            # Strategy: override the Tls instance's wrap_socket() to create
            # our own SSLContext with check_hostname explicitly controlled.
            _ca = ca_file
            _do_check = check_hostname

            if _ca:
                logger.info("AD TLS: using custom CA bundle at %s", _ca)
            logger.info(
                "AD TLS: validate=%s  check_hostname=%s  ca_file=%s",
                True, _do_check, _ca or "(OS default)",
            )

            # Build a normal Tls so ldap3 sees use_ssl=True.  We override
            # wrap_socket below so the validate/ca_certs_file here are unused
            # by ldap3, but set them for introspection/debugging.
            tls = ldap3.Tls(
                validate=_ssl.CERT_REQUIRED,
                ca_certs_file=_ca if _ca else None,
            )

            # ── Monkey-patch wrap_socket on THIS instance only ────────────
            def _custom_wrap(connection, do_handshake=False):
                """Wrap the raw socket with our own SSLContext."""
                ctx = _ssl.create_default_context(cafile=_ca if _ca else None)
                ctx.check_hostname = _do_check
                ctx.verify_mode = _ssl.CERT_REQUIRED
                # Apply the connect_timeout to the SSL handshake too, so a
                # bad cert doesn't hang for 22+ seconds waiting for OCSP.
                if connection.socket and connect_timeout:
                    connection.socket.settimeout(connect_timeout)
                connection.socket = ctx.wrap_socket(
                    connection.socket,
                    server_hostname=connection.server.host,
                    do_handshake_on_connect=do_handshake,
                )

            tls.wrap_socket = _custom_wrap

    return ldap3.Server(
        server_url,
        get_info=ldap3.NONE,
        connect_timeout=connect_timeout or None,
        use_ssl=_is_ssl,
        tls=tls,
    )


def _catch_ldap_connection_errors(ldap3):
    """Return a tuple of ldap3 exception types that indicate a connection/auth failure."""
    return (
        ldap3.core.exceptions.LDAPBindError,
        ldap3.core.exceptions.LDAPSocketOpenError,
        ldap3.core.exceptions.LDAPSocketSendError,
        ldap3.core.exceptions.LDAPSocketReceiveError,
        ldap3.core.exceptions.LDAPStartTLSError,
        ldap3.core.exceptions.LDAPSSLConfigurationError,
        ldap3.core.exceptions.LDAPConnectionIsReadOnlyError,
        OSError,          # plain socket errors (e.g. connection refused, host unreachable)
    )


def lookup_ad_user(username: str) -> Optional[dict]:
    """
    Look up a user in Active Directory by sAMAccountName (Windows ID).

    Uses the configured service account (ad_service_account / ad_service_password)
    to bind and search — no user password required.

    Returns user-info dict on success:
        { "username": str, "display_name": str, "email": str,
          "groups": [str], "role": str }
    Returns None if not found or if service account is not configured.
    """
    from core.config import auth as _auth

    if _auth.type != "ad":
        return None

    svc_account = _auth.ad_service_account
    svc_password = _auth.ad_service_password
    if not svc_account or not svc_password:
        logger.warning("AD service account not configured — cannot look up users")
        return None

    ldap3 = _ldap3()

    server_url    = _auth.ad_server
    base_dn       = _auth.ad_base_dn
    search_filter = _auth.ad_user_search_filter.format(username=_sanitize_ldap(username))
    group_attr    = _auth.ad_group_attribute

    server = _make_ldap_server(
        ldap3, server_url, _auth.ad_connect_timeout, _auth.ad_use_ssl,
        _auth.ad_tls_validate, _auth.ad_tls_ca_file, _auth.ad_tls_check_hostname,
    )
    _receive_timeout = getattr(_auth, "ad_receive_timeout", 10)
    try:
        conn = ldap3.Connection(
            server,
            user=svc_account,
            password=svc_password,
            authentication=ldap3.SIMPLE,
            receive_timeout=_receive_timeout,
            auto_bind=True,
        )
    except _catch_ldap_connection_errors(ldap3) as e:
        logger.error("AD service account bind failed (%s: %s) — check ad_server / ad_service_account / ad_service_password",
                     type(e).__name__, e)
        return None

    conn.search(
        search_base=base_dn,
        search_filter=search_filter,
        attributes=["displayName", "mail", "sAMAccountName", group_attr],
    )

    if not conn.entries:
        conn.unbind()
        return None

    entry = conn.entries[0]
    display_name = str(entry.displayName) if hasattr(entry, "displayName") else username
    email        = str(entry.mail)        if hasattr(entry, "mail")        else ""
    sam          = str(entry.sAMAccountName) if hasattr(entry, "sAMAccountName") else username

    raw_groups: list = []
    if hasattr(entry, group_attr):
        raw_groups = list(getattr(entry, group_attr))

    groups = [cn for cn in (dn_common_name(str(dn)) for dn in raw_groups) if cn]

    role = _resolve_role(username, groups, [str(dn) for dn in raw_groups])

    conn.unbind()
    return {
        "username": sam,
        "display_name": display_name,
        "email": email,
        "groups": groups,
        "role": role,
    }


def _try_super_admin_login(
    username: str, password: str, *, record_login: bool = False,
) -> Optional[dict]:
    """Phase 107-F: break-glass login against the SQLite super_admins table.

    Runs as a FALLBACK after normal auth fails, so that an operator can always
    recover access — even when ``auth.type == "ad"`` and AD is unreachable.

    ``record_login`` must be explicitly set to ``True`` by the caller when this
    is a fresh interactive login (e.g. the ``/auth/login`` endpoint). Basic-auth
    fall-through (``deps.get_current_user``) MUST call with the default
    ``record_login=False`` — otherwise every API request by a super_admin would
    issue an UPDATE + WAL fsync for ``last_login_at``. Simplify-review H2.

    Fail-open: any exception returns ``None`` and the caller continues.
    """
    try:
        from api.deps import _db_manager  # populated at startup
        if _db_manager is None:
            return None
        sa = _db_manager.get_super_admin_by_username(username)
        if not sa or not sa.get("is_active"):
            return None
        if not verify_password(password, sa.get("password_hash") or ""):
            return None
        if record_login:
            try:
                _db_manager.record_super_admin_login(username)
            except Exception:
                pass
            logger.info("super_admin break-glass login: %s", username)
        return {
            "username": username,
            "display_name": f"Super Admin ({username})",
            "email": "",
            "groups": [],
            "is_admin": True,
            "role": "super_admin",
        }
    except Exception:
        logger.exception("super_admin auth check failed; falling through to normal auth")
        return None


def authenticate_user(username: str, password: str) -> Optional[dict]:
    """
    Authenticate `username` / `password` against the configured auth backend.

    **Does NOT check the super_admin table.** This function is called on
    every Basic-auth API request via ``deps.get_current_user``, so a DB
    lookup per request would be a perf regression (simplify H1). Break-glass
    super_admin is ONLY available through the interactive UI login endpoint —
    see :func:`authenticate_interactive`.

    Supports three modes (auth.type in config):
      - "none"  → accept any credentials, return admin guest
      - "local" → validate against config.json local_users
      - "ad"    → validate against Active Directory / LDAP

    Returns a user-info dict on success:
        { "username": str, "display_name": str, "email": str,
          "groups": [str], "is_admin": bool, "role": str }
    Returns None on failure.
    """
    from core.config import auth as _auth

    # ── Auth disabled — accept any credentials. ──
    if _auth.type == "none":
        return {"username": username, "display_name": username,
                "email": "", "groups": [], "is_admin": True, "role": "admin"}

    # ── Local auth — validate against config.json users ──
    if _auth.type == "local":
        local_users = _auth.local_users
        if username in local_users and verify_password(password, local_users[username]):
            role = _resolve_role(username, [])
            return {
                "username": username,
                "display_name": username.title(),
                "email": "",
                "groups": [],
                "is_admin": role in ADMIN_TIER_ROLES,
                "role": role,
            }
        logger.warning("Local auth failed for user: %s", username)
        return None

    # ── AD / LDAP auth ──
    try:
        ldap3 = _ldap3()
    except Exception as e:
        logger.error("AD auth: failed to import ldap3: %s: %s", type(e).__name__, e)
        return None

    server_url = _auth.ad_server
    domain     = _auth.ad_domain
    base_dn    = _auth.ad_base_dn
    search_filter = _auth.ad_user_search_filter.format(username=_sanitize_ldap(username))
    group_attr    = _auth.ad_group_attribute

    if not server_url:
        logger.error("AD auth is enabled but ad_server is not configured")
        return None

    # Effective timeouts — connect must be > 0 to avoid blocking forever
    _connect_timeout = _auth.ad_connect_timeout or 3
    _receive_timeout = getattr(_auth, "ad_receive_timeout", 10)

    # Always use SIMPLE auth with UPN format (user@domain).
    # NTLM is deprecated by Microsoft and uses MD4 hashing which is rejected
    # by OpenSSL's FIPS policy on OpenShift — causing a hard crash.
    # SIMPLE + UPN works on both ldap:// and ldaps://.
    auth_method = ldap3.SIMPLE
    bind_user = f"{username}@{domain}" if domain and "@" not in username else username
    _server_url_norm = (server_url or "").strip().lower()
    _use_ssl = bool(_auth.ad_use_ssl) or _server_url_norm.startswith("ldaps://")
    logger.info(
        "AD bind decision: user=%s ad_server=%r ad_use_ssl=%r domain=%r "
        "normalized_url=%r → use_ssl=%s → auth_method=SIMPLE (UPN)",
        username, server_url, _auth.ad_use_ssl, domain,
        _server_url_norm, _use_ssl,
    )

    try:
        server = _make_ldap_server(
            ldap3, server_url, _connect_timeout, _auth.ad_use_ssl,
            _auth.ad_tls_validate, _auth.ad_tls_ca_file, _auth.ad_tls_check_hostname,
        )
    except Exception as e:
        logger.error("AD auth: failed to build LDAP server object: %s: %s", type(e).__name__, e)
        return None

    try:
        conn = ldap3.Connection(
            server,
            user=bind_user,
            password=password,
            authentication=auth_method,
            receive_timeout=_receive_timeout,
            auto_bind=True,
        )
    except _catch_ldap_connection_errors(ldap3) as e:
        logger.warning("AD bind failed for user %s (%s: %s)", username, type(e).__name__, e)
        return None
    except Exception as e:
        logger.error("AD bind unexpected error for user %s: %s: %s", username, type(e).__name__, e)
        return None

    # Search for the user to get display name, email, groups
    conn.search(
        search_base=base_dn,
        search_filter=search_filter,
        attributes=["displayName", "mail", group_attr],
    )

    if not conn.entries:
        conn.unbind()
        logger.warning("AD search returned no entries for: %s", username)
        return None

    entry = conn.entries[0]
    display_name = str(entry.displayName) if hasattr(entry, "displayName") else username
    email        = str(entry.mail)        if hasattr(entry, "mail")        else ""

    raw_groups: list = []
    if hasattr(entry, group_attr):
        raw_groups = list(getattr(entry, group_attr))

    # Each group's CN ("CN=Admins,DC=..." -> "Admins"; an escaped comma
    # stays in the name); the full DNs go to the role decision too.
    groups = [cn for cn in (dn_common_name(str(dn)) for dn in raw_groups) if cn]

    role = _resolve_role(username, groups, [str(dn) for dn in raw_groups])

    conn.unbind()
    return {
        "username": username,
        "display_name": display_name,
        "email": email,
        "groups": groups,
        "is_admin": role in ADMIN_TIER_ROLES,
        "role": role,
    }


def authenticate_interactive(username: str, password: str) -> Optional[dict]:
    """Interactive UI login entry point — used ONLY by ``POST /auth/login``.

    Break-glass FIRST: consult the SQLite ``super_admins`` table before the
    normal auth backend (none / local / AD).  Only if the entered credentials
    don't match an active super_admin do we fall through to normal auth.

    Why super_admin first (2026-07-13 fix):
      * The whole point of break-glass is to recover access *even when AD is
        down or slow*.  When AD was checked first, a reachable-but-slow AD
        server (connect + receive can approach the /auth/login 15s deadline)
        exhausted the request budget and returned 504 BEFORE the break-glass
        fallback ran — so the superadmin was locked out by exactly the
        AD-unavailable condition break-glass exists to survive.
      * A break-glass login no longer transmits the operator's recovery
        password to the AD/LDAP server at all.
      * Cost is one indexed SQLite lookup per interactive login for non-
        super-admin users (get_super_admin_by_username → None → fall through).
        Basic-auth API requests are unaffected — they call
        :func:`authenticate_user` directly and never touch this table.

    A username that is NOT an active super_admin (or whose password doesn't
    match the stored hash) falls straight through to normal auth, so ordinary
    AD/local users are unaffected.

    Returns the same user-info dict as :func:`authenticate_user`, with
    ``role == "super_admin"`` and ``is_admin == True`` when break-glass wins.
    """
    # 1. Break-glass super_admin — independent of AD availability.
    sa_user = _try_super_admin_login(username, password, record_login=True)
    if sa_user is not None:
        return sa_user
    # 2. Not a super_admin (or wrong password) — normal auth backend.
    return authenticate_user(username, password)


def decode_basic_header(authorization: str) -> tuple[str, str]:
    """Parse 'Basic <base64(user:password)>' or 'Bearer <base64(user:password)>' header."""
    parts = authorization.split(" ", 1)
    if len(parts) != 2:
        raise ValueError("Invalid Authorization header format")
    encoded = parts[1]
    try:
        decoded = base64.b64decode(encoded).decode("utf-8")
    except Exception:
        raise ValueError("Could not base64-decode Authorization header")
    if ":" not in decoded:
        raise ValueError("Authorization payload must be user:password")
    user, pw = decoded.split(":", 1)
    return user, pw
