/** System Account types that can log in to the AWS portal.
 *
 *  The portal takes an AD username + password, which an AD account (its own
 *  password or a Vault AD_accounts entry) holds as well as an AWS Portal
 *  account -- the server resolves either the same way
 *  (backend core/credential_manager.py::system_account_login).  Used by the
 *  S3 connection form and Admin -> AWS Portal (2026-10-28). */
export const PORTAL_ACCOUNT_TYPES = ['aws_portal', 'ad_account'];
