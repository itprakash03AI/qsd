/**
 * The run-log view of ONE feed execution (Phase 132.27; its own component
 * since 2026-10-07).
 *
 * It used to be a WebSocket tail alone and said "Waiting for log lines..."
 * forever when the run executed on a pod that streams none (the scheduler
 * pod's relay).  The execution now SAYS what this view is looking at --
 * `run_log` on GET /api/feed-executions/{id} (core/feed/run_log_view.py):
 *
 *   live        -- tail the WebSocket (feed_run_log events), as before;
 *   unavailable -- no live tail on that pod: show the server's message,
 *                  re-read the stored log every `recheck_seconds` while the
 *                  run is still going, name the driver log when there is one;
 *   unknown     -- the execution does not say: message + the same re-read;
 *   stored      -- finished: the lines stored on the execution, or "stored
 *                  no log lines".
 *
 * Nothing here decides client-side which case applies.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Box, Button, Chip,
  Stack, Typography,
} from '@mui/material';
import FloatingWindow, { WindowBody } from './common/FloatingWindow';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';

export type RunLogMode = 'live' | 'unavailable' | 'unknown' | 'stored';

export interface RunLogView {
  mode: RunLogMode;
  message: string;
  stored_log_route: string;
  recheck_seconds: number | null;
  driver_log_route: string | null;
  stored_line_count: number;
}

interface LogLine { at: string; level: string; line: string; }

const MAX_LINES = 1000;

const levelColor: Record<string, string> = {
  INFO: '#e0e0e0', WARNING: '#ffb74d', ERROR: '#ef5350', DEBUG: '#888',
};

/** files_metadata.log_lines ({ts, level, msg}) in the tail's shape. */
function storedLinesOf(ex: any): LogLine[] {
  const raw = ex?.files_metadata?.log_lines;
  if (!Array.isArray(raw)) return [];
  return raw.map((l: any) => {
    const ts = typeof l?.ts === 'number' ? new Date(l.ts * 1000).toISOString() : String(l?.ts ?? '');
    return { at: ts, level: String(l?.level ?? 'INFO'), line: String(l?.msg ?? '') };
  });
}

const FeedLiveLogDialog: React.FC<{
  execDbId: string | null; onClose: () => void;
}> = ({ execDbId, onClose }) => {
  const ws = useWebSocket();
  const [liveLines, setLiveLines] = useState<LogLine[]>([]);
  const [storedLines, setStoredLines] = useState<LogLine[]>([]);
  const [runLog, setRunLog] = useState<RunLogView | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);

  // ── What is this view looking at?  The execution says. ────────────────
  const load = useCallback(async () => {
    if (execDbId === null) return;
    try {
      const ex: any = await api.getFeedExecution(Number(execDbId));
      setRunLog(ex?.run_log ?? null);
      setStoredLines(storedLinesOf(ex));
      setLoadError(null);
    } catch (e: any) {
      setLoadError(String(e?.message || e));
    }
  }, [execDbId]);

  useEffect(() => {
    setLiveLines([]); setStoredLines([]); setRunLog(null); setLoadError(null);
    void load();
  }, [load]);

  // Not live and the run still going: re-read the stored log at the pace
  // the server named.  A finished run comes back `stored` with no
  // recheck, which stops the timer.
  const recheck = runLog && runLog.mode !== 'live' ? runLog.recheck_seconds : null;
  useEffect(() => {
    if (execDbId === null || !recheck || recheck <= 0) return;
    const t = setInterval(() => { void load(); }, recheck * 1000);
    return () => clearInterval(t);
  }, [execDbId, recheck, load]);

  // ── The live tail (only meaningful when the execution says `live`) ─────
  useEffect(() => {
    if (!ws?.addListener || !execDbId) return;
    const target = Number(execDbId);
    const handler = (msg: any) => {
      if (!msg || msg.event !== 'feed_run_log') return;
      if (msg.exec_db_id !== target) return;
      if (paused) return;
      setLiveLines(prev => {
        const next = prev.concat([{ at: msg.at, level: msg.level, line: msg.line }]);
        return next.length > MAX_LINES ? next.slice(-MAX_LINES) : next;
      });
    };
    const unsub = ws.addListener(handler);
    return () => { unsub && unsub(); };
  }, [ws, execDbId, paused]);

  const mode: RunLogMode | null = runLog?.mode ?? null;
  const lines = mode === 'stored' ? storedLines : liveLines;

  const modeChip: Record<RunLogMode, { label: string; color: 'success' | 'warning' | 'default' | 'info' }> = {
    live: { label: 'live', color: 'success' },
    unavailable: { label: 'no live tail on this pod', color: 'warning' },
    unknown: { label: 'stream unknown', color: 'default' },
    stored: { label: 'stored log', color: 'info' },
  };

  return (
    // 2026-10-27 (the owner: "popup boxes are still not good"): the ONE window
    <FloatingWindow open={execDbId !== null} onClose={onClose} modal
                    title={`Run log — execution #${execDbId}`} data-testid="run-log-window"
                    widthShare={0.8} maxWidth={1300} heightShare={0.8} maxHeight={1000}>
      <WindowBody>
        <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
          {mode && (
            <Chip label={modeChip[mode].label} color={modeChip[mode].color}
                  size="small" variant="outlined" sx={{ fontSize: 10 }} />
          )}
          <Chip label={`${lines.length}${lines.length >= MAX_LINES ? ' (capped)' : ''}`}
                size="small" variant="outlined" sx={{ fontSize: 10 }} />
          <Box sx={{ flex: 1 }} />
          {mode === 'live' && (
            <Button size="small" onClick={() => setPaused(p => !p)}>
              {paused ? 'Resume' : 'Pause'}
            </Button>
          )}
          {mode === 'live' && (
            <Button size="small" onClick={() => setLiveLines([])}>Clear</Button>
          )}
        </Stack>
        {loadError && (
          <Typography variant="body2" color="error" sx={{ mb: 1 }}>
            Could not read execution #{execDbId}: {loadError}
          </Typography>
        )}
        {runLog && mode !== 'live' && (
          <Box sx={{ mb: 1 }}>
            <Typography variant="body2" sx={{ mb: 0.5 }}>{runLog.message}</Typography>
            {recheck ? (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                Re-reading {runLog.stored_log_route} every {recheck} s.
              </Typography>
            ) : null}
            {runLog.driver_log_route && (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                Driver pod log: {runLog.driver_log_route}
              </Typography>
            )}
          </Box>
        )}
        <Box sx={{ p: 1, height: 'calc(100% - 64px)', minHeight: 240, overflow: 'auto',
                    fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
                    background: '#1e1e1e', color: '#e0e0e0', borderRadius: 1 }}>
          {lines.length === 0 && !runLog && !loadError && (
            <Typography variant="caption" sx={{ color: '#888' }}>
              Reading the execution…
            </Typography>
          )}
          {lines.length === 0 && mode === 'live' && (
            <Typography variant="caption" sx={{ color: '#888' }}>
              Waiting for log lines… (live-tail starts as soon as the next
              feed_engine logger.info() fires).
            </Typography>
          )}
          {lines.map((l, i) => (
            <Box key={i} sx={{ whiteSpace: 'pre-wrap', mb: 0.25 }}>
              <span style={{ color: '#888' }}>
                {(l.at || '').slice(11, 19)}
              </span>{' '}
              <span style={{ color: levelColor[l.level] || '#e0e0e0',
                              fontWeight: l.level === 'ERROR' ? 600 : 400 }}>
                [{l.level || 'INFO'}]
              </span>{' '}
              {l.line}
            </Box>
          ))}
        </Box>
      </WindowBody>
    </FloatingWindow>
  );
};

export default FeedLiveLogDialog;
