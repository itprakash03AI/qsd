/**
 * Netcool rules -- WHEN an event goes to Netcool and WHAT it says (2026-10-25).
 *
 * The owner: "we need config based netcool -- when to send and what events".
 * Rows of /api/admin/netcool-rules, decided by the server at the one door
 * every alert uses (core/feed/netcool_rules.py): the first active rule (lowest
 * priority) whose match + when fields hold sends or suppresses, and may
 * override the severity and the console group.  No match -> the default.
 * "Test an event" asks the server which rule would decide, nothing is sent.
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, FormControlLabel,
  IconButton, MenuItem, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import FloatingWindow, { WindowActions, WindowBody } from '../common/FloatingWindow';
import { Delete as DeleteIcon, Edit as EditIcon } from '@mui/icons-material';
import api from '../../services/api';

const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const SEVERITIES = [
  { v: 5, l: '5 Critical' }, { v: 4, l: '4 Major' }, { v: 3, l: '3 Minor' },
  { v: 2, l: '2 Warning' }, { v: 1, l: '1 Indeterminate' }, { v: 0, l: '0 Clear' },
];
const EMPTY = {
  name: '', priority: 100, is_active: true, match_alert_group: '', match_alert_type: '', match_object: '',
  match_min_severity: '', match_max_severity: '', days: [] as number[], business_days_calendar: '',
  window_from: '', window_to: '', timezone: '', action: 'send', severity_override: '', alert_group_override: '',
  note: '',
};

/** One rule's match + when in words.  Pure. */
export function ruleWords(r: any): { what: string; when: string } {
  const what = [
    r.match_alert_group ? `group ${r.match_alert_group}` : null,
    r.match_alert_type ? `type ${r.match_alert_type}` : null,
    r.match_object ? `object ${r.match_object}` : null,
    r.match_min_severity != null && r.match_min_severity !== '' ? `severity >= ${r.match_min_severity}` : null,
    r.match_max_severity != null && r.match_max_severity !== '' ? `severity <= ${r.match_max_severity}` : null,
  ].filter(Boolean).join(', ') || 'every event';
  const days = (r.days || []).length ? (r.days as number[]).map(d => DAY_NAMES[d]).join(' ') : null;
  const when = [
    days, r.business_days_calendar ? `business days of ${r.business_days_calendar}` : null,
    (r.window_from || r.window_to) ? `${r.window_from || '00:00'}-${r.window_to || '24:00'} ${r.timezone || 'UTC'}` : null,
  ].filter(Boolean).join(', ') || 'always';
  return { what, when };
}

const nul = (v: any) => (v === '' || v === undefined ? null : v);
function toBody(f: any) {
  return {
    ...f, priority: Number(f.priority) || 0,
    match_alert_group: nul(f.match_alert_group), match_alert_type: nul(f.match_alert_type),
    match_object: nul(f.match_object), business_days_calendar: nul(f.business_days_calendar),
    window_from: nul(f.window_from), window_to: nul(f.window_to), timezone: nul(f.timezone),
    alert_group_override: nul(f.alert_group_override), note: nul(f.note),
    match_min_severity: f.match_min_severity === '' ? null : Number(f.match_min_severity),
    match_max_severity: f.match_max_severity === '' ? null : Number(f.match_max_severity),
    severity_override: f.severity_override === '' ? null : Number(f.severity_override),
    days: (f.days || []).length ? f.days : null,
  };
}

export default function NetcoolRulesSection() {
  const [rules, setRules] = useState<any[]>([]);
  const [groups, setGroups] = useState<string[]>([]);
  const [deflt, setDeflt] = useState('send');
  const [err, setErr] = useState<string | null>(null);
  const [edit, setEdit] = useState<any | null>(null);
  const [test, setTest] = useState<any>({ alert_group: 'FEED_SLA', alert_type: 'BREACHED', object: '', severity: 5, at: '' });
  const [verdict, setVerdict] = useState<any | null>(null);

  const load = useCallback(async () => {
    try {
      const r: any = await api.netcoolRules();
      setRules(r.rules || []); setGroups(r.alert_groups || []); setDeflt(r.default_action || 'send'); setErr(null);
    } catch (e: any) { setErr(`The Netcool rules could not be read: ${e?.message || e}`); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const save = async () => {
    try {
      const body = toBody(edit);
      if (edit.id) await api.updateNetcoolRule(edit.id, body); else await api.createNetcoolRule(body);
      setEdit(null); await load();
    } catch (e: any) { setErr(e?.message || String(e)); }
  };
  const remove = async (id: number) => {
    try { await api.deleteNetcoolRule(id); await load(); } catch (e: any) { setErr(e?.message || String(e)); }
  };
  const runTest = async () => {
    try {
      const v: any = await api.testNetcoolRules({ ...test, object: test.object || 'SOME_OBJECT',
        severity: Number(test.severity), at: test.at ? new Date(test.at).toISOString() : undefined });
      setVerdict(v);
    } catch (e: any) { setVerdict({ error: e?.message || String(e) }); }
  };

  return (
    <Box data-testid="netcool-rules">
      {err && <Alert severity="error" sx={{ mb: 1 }}>{err}</Alert>}
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <Typography variant="body2">An event no rule matches is <b>{deflt === 'send' ? 'sent' : 'not sent'}</b>
          {' '}(feed_generation.netcool.default_action). The heartbeat is always sent.</Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" variant="contained" data-testid="netcool-rule-add" onClick={() => setEdit({ ...EMPTY })}>Add a rule</Button>
      </Stack>
      <Box sx={{ overflowX: 'auto' }}>
        <Table size="small" data-testid="netcool-rules-table">
          <TableHead><TableRow>
            <TableCell>Order</TableCell><TableCell>Rule</TableCell><TableCell>Events</TableCell><TableCell>When</TableCell>
            <TableCell>Then</TableCell><TableCell>Used</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {rules.map(r => {
              const w = ruleWords(r);
              return (
                <TableRow key={r.id} data-testid="netcool-rule-row" sx={{ opacity: r.is_active ? 1 : 0.5 }}>
                  <TableCell>{r.priority}</TableCell>
                  <TableCell><b>{r.name}</b>{!r.is_active && <Chip size="small" label="off" sx={{ ml: 0.5 }} />}
                    {r.note && <Typography variant="caption" color="text.secondary" component="div">{r.note}</Typography>}</TableCell>
                  <TableCell>{w.what}</TableCell>
                  <TableCell>{w.when}</TableCell>
                  <TableCell>
                    <Chip size="small" color={r.action === 'send' ? 'success' : 'default'}
                          label={r.action === 'send' ? 'Send' : 'Do not send'} />
                    {r.severity_override != null && <Typography variant="caption" component="div">as severity {r.severity_override}</Typography>}
                    {r.alert_group_override && <Typography variant="caption" component="div">to {r.alert_group_override}</Typography>}
                  </TableCell>
                  <TableCell><Typography variant="caption">{r.match_count || 0}x
                    {r.last_matched_at ? `, last ${String(r.last_matched_at).replace('T', ' ').slice(0, 16)}` : ''}</Typography></TableCell>
                  <TableCell>
                    <IconButton size="small" aria-label={`Edit rule ${r.name}`} onClick={() => setEdit({ ...EMPTY, ...r,
                      match_min_severity: r.match_min_severity ?? '', match_max_severity: r.match_max_severity ?? '',
                      severity_override: r.severity_override ?? '', days: r.days || [] })}><EditIcon fontSize="small" /></IconButton>
                    <IconButton size="small" aria-label={`Delete rule ${r.name}`} onClick={() => remove(r.id)}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
            {rules.length === 0 && <TableRow><TableCell colSpan={7}><Typography variant="body2" color="text.secondary">
              No rules: every event is {deflt === 'send' ? 'sent' : 'held back'}.</Typography></TableCell></TableRow>}
          </TableBody>
        </Table>
      </Box>

      <Typography variant="subtitle2" sx={{ mt: 2 }}>Test an event</Typography>
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center" sx={{ mt: 0.5 }}>
        <TextField select size="small" label="Group" value={test.alert_group} sx={{ minWidth: 170 }}
                   onChange={e => setTest({ ...test, alert_group: e.target.value })}>
          {groups.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
        </TextField>
        <TextField size="small" label="Type" value={test.alert_type} onChange={e => setTest({ ...test, alert_type: e.target.value })} />
        <TextField size="small" label="Object" placeholder="feed / dependency" value={test.object}
                   onChange={e => setTest({ ...test, object: e.target.value })} />
        <TextField select size="small" label="Severity" value={test.severity} sx={{ minWidth: 140 }}
                   onChange={e => setTest({ ...test, severity: e.target.value })}>
          {SEVERITIES.map(s => <MenuItem key={s.v} value={s.v}>{s.l}</MenuItem>)}
        </TextField>
        <TextField size="small" type="datetime-local" label="At (local)" value={test.at} InputLabelProps={{ shrink: true }}
                   onChange={e => setTest({ ...test, at: e.target.value })} />
        <Button size="small" variant="outlined" data-testid="netcool-rule-test" onClick={runTest}>Which rule decides?</Button>
      </Stack>
      {verdict && (
        <Alert severity={verdict.error ? 'error' : verdict.action === 'send' ? 'success' : 'info'} sx={{ mt: 1 }}
               data-testid="netcool-rule-verdict">
          {verdict.error ? verdict.error
            : <>{verdict.action === 'send' ? 'Sent' : 'Not sent'} -- {verdict.reason}
                {verdict.would_send && <> (severity {verdict.would_send.Severity}, group {verdict.would_send.AlertGroup})</>}</>}
        </Alert>
      )}

      {/* 2026-10-27 (the owner: "popup boxes are still not good"): the ONE window */}
      <FloatingWindow open={!!edit} onClose={() => setEdit(null)} modal
                      title={edit?.id ? 'Edit the rule' : 'A new rule'} data-testid="netcool-rule-window"
                      widthShare={0.55} maxWidth={900} heightShare={0.8} maxHeight={900} minWidth={520}
                      footer={
                        <WindowActions>
                          <Button onClick={() => setEdit(null)}>Cancel</Button>
                          <Button variant="contained" data-testid="netcool-rule-save" onClick={save} disabled={!edit?.name}>Save</Button>
                        </WindowActions>
                      }>
        {edit && (
          <WindowBody>
            <Stack spacing={1.5} sx={{ mt: 1 }}>
              <Stack direction="row" spacing={1}>
                <TextField label="Name" value={edit.name} onChange={e => setEdit({ ...edit, name: e.target.value })} fullWidth
                           inputProps={{ 'data-testid': 'netcool-rule-name' }} />
                <Tooltip title="Rules are tried in this order, lowest first; the first that matches decides">
                  <TextField label="Order" type="number" value={edit.priority} sx={{ width: 110 }}
                             onChange={e => setEdit({ ...edit, priority: e.target.value })} />
                </Tooltip>
                <FormControlLabel control={<Checkbox checked={!!edit.is_active}
                  onChange={e => setEdit({ ...edit, is_active: e.target.checked })} />} label="On" />
              </Stack>
              <Typography variant="subtitle2">Which events (empty = any)</Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                <TextField select label="Group" value={edit.match_alert_group || ''} sx={{ minWidth: 190 }}
                           onChange={e => setEdit({ ...edit, match_alert_group: e.target.value })}>
                  <MenuItem value="">any</MenuItem>{groups.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                </TextField>
                <TextField label="Type (e.g. BREACHED)" value={edit.match_alert_type || ''}
                           onChange={e => setEdit({ ...edit, match_alert_type: e.target.value })} />
                <TextField label="Object (wildcards: FACT_TETB_*)" value={edit.match_object || ''}
                           onChange={e => setEdit({ ...edit, match_object: e.target.value })} />
                <TextField select label="Severity from" value={edit.match_min_severity} sx={{ minWidth: 150 }}
                           onChange={e => setEdit({ ...edit, match_min_severity: e.target.value })}>
                  <MenuItem value="">any</MenuItem>{SEVERITIES.map(s => <MenuItem key={s.v} value={s.v}>{s.l}</MenuItem>)}
                </TextField>
                <TextField select label="Severity up to" value={edit.match_max_severity} sx={{ minWidth: 150 }}
                           onChange={e => setEdit({ ...edit, match_max_severity: e.target.value })}>
                  <MenuItem value="">any</MenuItem>{SEVERITIES.map(s => <MenuItem key={s.v} value={s.v}>{s.l}</MenuItem>)}
                </TextField>
              </Stack>
              <Typography variant="subtitle2">When (empty = always; a clear is never held back by these)</Typography>
              <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                {DAY_NAMES.map((d, i) => (
                  <Chip key={d} label={d} clickable color={(edit.days || []).includes(i) ? 'primary' : 'default'}
                        onClick={() => setEdit({ ...edit, days: (edit.days || []).includes(i)
                          ? edit.days.filter((x: number) => x !== i) : [...(edit.days || []), i].sort() })} />
                ))}
              </Stack>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                <TextField label="From (HH:MM)" value={edit.window_from || ''} sx={{ width: 140 }}
                           onChange={e => setEdit({ ...edit, window_from: e.target.value })} />
                <TextField label="To (HH:MM)" value={edit.window_to || ''} sx={{ width: 140 }}
                           onChange={e => setEdit({ ...edit, window_to: e.target.value })} />
                <TextField label="Time zone (e.g. Europe/London)" value={edit.timezone || ''}
                           onChange={e => setEdit({ ...edit, timezone: e.target.value })} />
                <TextField label="Only on business days of calendar" value={edit.business_days_calendar || ''}
                           onChange={e => setEdit({ ...edit, business_days_calendar: e.target.value })} />
              </Stack>
              <Typography variant="subtitle2">Then</Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                <TextField select label="Action" value={edit.action} sx={{ minWidth: 160 }}
                           onChange={e => setEdit({ ...edit, action: e.target.value })}>
                  <MenuItem value="send">Send</MenuItem><MenuItem value="suppress">Do not send</MenuItem>
                </TextField>
                <TextField select label="Send as severity" value={edit.severity_override} sx={{ minWidth: 170 }}
                           onChange={e => setEdit({ ...edit, severity_override: e.target.value })}>
                  <MenuItem value="">as raised</MenuItem>{SEVERITIES.map(s => <MenuItem key={s.v} value={s.v}>{s.l}</MenuItem>)}
                </TextField>
                <TextField select label="Send to group" value={edit.alert_group_override || ''} sx={{ minWidth: 190 }}
                           onChange={e => setEdit({ ...edit, alert_group_override: e.target.value })}>
                  <MenuItem value="">as raised</MenuItem>{groups.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                </TextField>
              </Stack>
              <TextField label="Note" value={edit.note || ''} onChange={e => setEdit({ ...edit, note: e.target.value })} multiline />
            </Stack>
          </WindowBody>
        )}
      </FloatingWindow>
    </Box>
  );
}
