/**
 * The feed form in SENTENCES (2026-10-24, the owner's feed form redesign,
 * docs/FEED_FORM_REDESIGN_2026_10_23.html: "cards with one-line summaries",
 * "human readable text", "a review page in sentences").
 *
 * Pure: the form's current values in, plain words out.  Each step's card
 * shows its one-line summary; the Review step joins them into the feed's
 * description, each sentence linking back to its step.  Nothing here decides
 * anything the server decides -- it only SAYS what the author has set.
 */

export interface FeedFormFacts {
  name: string;
  sourceType: string;
  sourceName?: string;          // the saved query / SQL file / view picked
  connectionName?: string;
  rawSql?: string;
  cross?: { on: boolean; secondaryConnectionName?: string; combine?: string };
  schedule: {
    declared: boolean; kind: string; workdayN?: string; businessDate?: string;
    cron?: string; upstreamFeed?: string; legacyCron?: string; enabled?: boolean;
  };
  calendar?: string;
  deps: string[];
  fileName?: string;
  format?: string;
  compression?: string;
  controlFile?: string;
  checksum?: string;
  dest: { type: string; where?: string };
  dueBy?: string;
  dueZone?: string;
  notifyEmails?: string;
  notifyOnSuccess?: boolean;
  notifyOnFailure?: boolean;
  rowCountAction?: string;
  retries?: { value: string; defaultValue?: number | null };
  engine?: string;
}

/** A step of the redesigned form and where its sentence comes from. */
export const FORM_STEPS = ['What data', 'When', 'Waits for', 'The file', 'Where it goes',
                           'Checks & alerts', 'Review'] as const;

const ORD = (n: number) => {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

export function whenSentence(f: FeedFormFacts): string {
  const s = f.schedule;
  const cal = f.calendar ? ` (${f.calendar} calendar)` : '';
  if (!s.declared) {
    if (s.enabled === false) return 'Not scheduled -- runs only when started';
    return s.legacyCron ? `On the schedule ${s.legacyCron}${cal}` : `Not scheduled yet${cal}`;
  }
  const n = parseInt(String(s.workdayN || ''), 10);
  const runs: Record<string, string> = {
    daily: 'Every working day',
    month_end: 'The last working day of the month',
    workday_n: Number.isFinite(n)
      ? (n > 0 ? `The ${ORD(n)} working day of the month` : `The ${ORD(-n)} working day before month end`)
      : 'One working day of the month (which one is not set yet)',
    workdays: 'Chosen working days of the month',
    cron: s.cron ? `On the schedule ${s.cron}` : 'On a schedule (not set yet)',
    on_completion_of: s.upstreamFeed ? `When ${s.upstreamFeed} completes` : 'When another feed completes',
    on_demand: 'Only when started (on demand)',
  };
  const base = (runs[s.kind] || s.kind) + cal;
  const forDate: Record<string, string> = {
    month_end: 'for the current month end',
    previous_month_end: 'for the previous month end',
  };
  const bd = s.businessDate && forDate[s.businessDate] ? `, ${forDate[s.businessDate]}` : '';
  return base + bd;
}

export function whatDataSentence(f: FeedFormFacts): string {
  const src = f.sourceName
    ? `${f.sourceName}`
    : f.sourceType === 'raw_sql' ? 'its own SQL' : 'a source not picked yet';
  const on = f.connectionName ? ` on ${f.connectionName}` : '';
  const cross = f.cross?.on
    ? ` and on ${f.cross.secondaryConnectionName || 'a second connection'}, ${
        (f.cross.combine || 'union') === 'join' ? 'joined' : 'stacked by column name'}`
    : '';
  return `Reads ${src}${on}${cross}`;
}

export function waitsForSentence(f: FeedFormFacts): string {
  if (!f.deps.length) return 'Waits for nothing (no upstream data)';
  const shown = f.deps.slice(0, 3).join(', ') + (f.deps.length > 3 ? ` and ${f.deps.length - 3} more` : '');
  return `Waits for ${shown}`;
}

export function fileSentence(f: FeedFormFacts): string {
  const fmt = (f.format || 'csv').toUpperCase();
  const comp = f.compression && f.compression !== 'none' ? `, ${f.compression}` : '';
  const name = f.fileName ? `${f.fileName}` : 'a file (name not set yet)';
  const ctl = f.controlFile ? ` with a control file ${f.controlFile}` : '';
  const sum = f.checksum ? ` and a ${f.checksum.toUpperCase()} checksum` : '';
  return `Writes ${name} (${fmt}${comp})${ctl}${sum}`;
}

const DEST_WORDS: Record<string, string> = {
  sftp: 'by SFTP', s3: 'to S3', local: 'to a folder', email: 'by e-mail', smtp: 'by e-mail',
  oracle: 'into an Oracle table', iceberg: 'into an Iceberg table', none: 'nowhere (kept only)',
};

export function whereSentence(f: FeedFormFacts): string {
  const how = DEST_WORDS[f.dest.type] || `by ${f.dest.type}`;
  return `Sends it ${how}${f.dest.where ? ` to ${f.dest.where}` : ''}`;
}

export function checksSentence(f: FeedFormFacts): string {
  const parts: string[] = [];
  if (f.dueBy) parts.push(`due by ${f.dueBy}${f.dueZone ? ` ${f.dueZone}` : ''}`);
  if (f.rowCountAction && f.rowCountAction !== 'off' && f.rowCountAction !== 'none') {
    parts.push(`row count checked (${f.rowCountAction})`);
  }
  const who = (f.notifyEmails || '').split(',').map(x => x.trim()).filter(Boolean);
  if (who.length) {
    const on = [f.notifyOnFailure ? 'failure' : '', f.notifyOnSuccess ? 'success' : ''].filter(Boolean).join(' and ');
    parts.push(`tells ${who.length === 1 ? who[0] : `${who.length} people`}${on ? ` on ${on}` : ''}`);
  }
  return parts.length ? parts.join('; ').replace(/^./, c => c.toUpperCase()) : 'No due time and no one told';
}

/** One sentence per step, in step order (Review excluded). */
export function stepSentences(f: FeedFormFacts): string[] {
  return [whatDataSentence(f), whenSentence(f), waitsForSentence(f), fileSentence(f),
          whereSentence(f), checksSentence(f)];
}

/** "Default: 2 (the deployment's value)" -- the design's words for an
 *  inherited field; ``value`` set = the feed's own. */
export function defaultWords(defaultValue: number | string | null | undefined, unit = ''): string {
  if (defaultValue === null || defaultValue === undefined || defaultValue === '') {
    return "Leave blank for the deployment's value";
  }
  return `Default: ${defaultValue}${unit} (the deployment's value) -- leave blank to use it`;
}

/**
 * Server sentences in plain words (the design's "before -> after" table).
 * An unknown message is returned as it is: a rewording is a translation of
 * a refusal the server made, never a different verdict.
 */
const PLAIN: Array<[RegExp, string]> = [
  [/Contract refused at authoring \(FR-ART-01\)/i, "This file setting can't be saved:"],
  [/checksum covers the whole package/i,
   "the checksum covers the whole package, which this engine can't produce yet. Choose \"the file sent\"."],
  [/_partition\.max_parts must be an integer/i, '"Most parts" must be a whole number'],
  [/workday_n requires ['"]?n['"]?/i, 'Pick which working day (1st, 2nd, ...)'],
  [/Sequencing: gapless/i, 'Number each file in order, never skipping a number'],
];

export function plainWords(message: string): string {
  let out = String(message || '');
  for (const [re, words] of PLAIN) out = out.replace(re, words);
  return out;
}

/** Where a feed runs, in ONE set of words (2026-10-27, the owner: "native should be
 *  something worker ... how airflow says") -- the same as the server's
 *  core/feed/engine_words.py. */
export function engineWords(value: string, label?: string): string {
  const v = String(value || '').toLowerCase();
  if (!v || v === 'auto') return 'Automatic (decided by size)';
  if (v === 'native') return 'QueryStudio worker';
  if (v === 'spark_connect') return 'Shared Spark cluster';
  if (v.startsWith('spark')) return 'Spark cluster';
  if (v === 'airflow') return 'Airflow worker';
  return label || value;
}

/** "QueryStudio worker · qs-scheduler-7d9f" -- the engine and WHICH worker ran it
 *  (the pod for the QueryStudio worker, the Spark / Airflow job otherwise). */
export function ranOnWords(ex: { execution_backend?: string | null; external_job_id?: string | null;
                                 files_metadata?: any } | null | undefined): string {
  if (!ex || !ex.execution_backend) return '-';
  const worker = ex.files_metadata?.backend_choice?.worker || ex.external_job_id || '';
  return `${engineWords(ex.execution_backend)}${worker ? ` · ${worker}` : ''}`;
}
