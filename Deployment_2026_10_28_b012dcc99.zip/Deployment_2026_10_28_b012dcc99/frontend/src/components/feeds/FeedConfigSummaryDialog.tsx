/**
 * A feed's whole configuration, in words, opened from Feed Run Status
 * (2026-10-13, the owner: "from the dashboard how can I see the config ...
 * if I want to visit the full config details").
 *
 * The words come from the server (GET /api/feeds/{id}/summary,
 * core/feed/summary.py) so every screen describes a feed the same way; this
 * dialog lays them out, links to the edit form (/feeds?edit=<id>, Cancel
 * returns here) and opens the version history (who changed what, when).
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Paper, Stack, Table, TableBody, TableCell, TableRow, Typography,
} from '@mui/material';
import FloatingWindow, { WindowActions, WindowBody } from '../common/FloatingWindow';
import { History as HistoryIcon, Edit as EditIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import FeedVersionHistoryDialog from '../FeedVersionHistoryDialog';

interface Row { label: string; value: any; hint?: string }
interface Summary {
  feed_id: number; name: string;
  sections: { title: string; rows: Row[] }[];
  last_version: { version: number; by: string | null; at: string | null; at_text?: string | null } | null;
}

const shown = (v: any) => (v === null || v === undefined ? 'Not set' : String(v));

export default function FeedConfigSummaryDialog({ feedId, feedName, onClose }: {
  feedId: number | null; feedName?: string | null; onClose: () => void;
}) {
  const [data, setData] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState(false);
  const [tick, setTick] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (feedId == null) return;
    let alive = true;
    setData(null); setError(null);
    api.feedSummary(feedId)
      .then((r: any) => { if (alive) setData(r as Summary); })
      .catch((e: any) => { if (alive) setError(e?.message || 'The configuration could not be read'); });
    return () => { alive = false; };
  }, [feedId, tick]);

  const editHref = feedId != null
    ? `/feeds?edit=${feedId}&return_to=${encodeURIComponent(window.location.pathname + window.location.search)}`
    : '';

  return (
    // 2026-10-27 (the owner: "popup boxes are still not good"): the ONE window
    <FloatingWindow open={feedId != null} onClose={onClose} modal
                    title={data?.name || feedName || 'Feed'} data-testid="feed-config-dialog"
                    widthShare={0.62} maxWidth={980} heightShare={0.86} maxHeight={1100} minWidth={560}
                    footer={
                      <WindowActions start={<>
                        <Button startIcon={<HistoryIcon />} disabled={feedId == null} onClick={() => setHistory(true)}
                                data-testid="feed-config-history">Version history</Button>
                        <Button startIcon={<EditIcon />} disabled={feedId == null}
                                onClick={() => { onClose(); navigate(editHref); }} data-testid="feed-config-edit">
                          Edit this feed
                        </Button>
                      </>} />
                    }>
      <WindowBody subtitle={data?.last_version ? (
        <span data-testid="feed-config-last-change">
          Version {data.last_version.version}
          {data.last_version.by ? `, saved by ${data.last_version.by}` : ', recorded when it ran'}
          {data.last_version.at_text ? ` on ${data.last_version.at_text}` : ''}
        </span>) : undefined}>
        {error && <Alert severity="error" data-testid="feed-config-error">{error}</Alert>}
        {!data && !error && <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress size={24} /></Box>}
        {data && (
          <Stack spacing={1.5}>
            {data.sections.map(sec => (
              <Paper key={sec.title} variant="outlined" data-testid="feed-config-section">
                <Typography variant="subtitle2" sx={{ px: 1.5, pt: 1 }}>{sec.title}</Typography>
                <Table size="small">
                  <TableBody>
                    {sec.rows.map((r, i) => (
                      <TableRow key={`${r.label}-${i}`}>
                        <TableCell sx={{ width: '34%', color: 'text.secondary', verticalAlign: 'top' }}>{r.label}</TableCell>
                        <TableCell sx={{ wordBreak: 'break-word' }} data-testid={`feed-config-value-${r.label}`}>
                          {shown(r.value)}
                          {r.hint && (
                            <Typography variant="caption" color="text.secondary" component="div">{r.hint}</Typography>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Paper>
            ))}
          </Stack>
        )}
      </WindowBody>
      <FeedVersionHistoryDialog feedId={history ? feedId : null} feedName={data?.name || feedName}
                                open={history} onClose={() => setHistory(false)}
                                onRestored={() => { setHistory(false); setTick(t => t + 1); }} />
    </FloatingWindow>
  );
}
