/**
 * Every way to call a published API, filled in with THIS API's address,
 * parameters and filter columns (2026-10-28, owner: "on published api create
 * or dashboard we should [show] all examples ... need pagination details").
 *
 * The rules shown here are the server's own (backend/api/published_views_api.py
 * ext_get_view_data, helpers.next_page_url_for, envelope.paged_ceiling):
 * a page is ?limit=&offset=; the answer's pagination.next_page_url is the
 * next page of the SAME question; ?dataset_version= keeps every page on the
 * same data (409 = start again); paging stops at 1,000,000 rows (416 -> /bulk).
 */
import React, { useState } from 'react';
import {
  Accordion, AccordionDetails, AccordionSummary, Box, Button, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, Typography,
} from '@mui/material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';

export interface ApiExampleInput {
  baseUrl: string;
  slug: string;
  paramDefs?: Array<{ name?: string; type?: string; required?: boolean } | Record<string, unknown>>;
  filterColumns?: string[];
  keyText?: string;
}

export interface ApiExample { id: string; title: string; explain: string; code: string }

const KEY_HEADER = (k: string) => `-H "X-API-Key: ${k}"`;

/** The server's own words (backend api/published_views/helpers.py
 *  _RESERVED_QUERY_NAMES): a parameter NAMED one of these must be sent as
 *  ?param[name]=value, or the server reads it as its own setting. */
export const RESERVED_QUERY_NAMES = new Set([
  'limit', 'offset', 'sort', 'columns', 'format', 'cache', 'snapshot_id', 'as_of_timestamp',
  'engine', 'cursor', 'max_rows', 'batch_rows', 'received', 'dataset_version', 'allow_partial',
]);
const qsKey = (name: string) => (RESERVED_QUERY_NAMES.has(name) ? `param[${name}]` : name);

/** Every example as plain text -- one function, so a test can read them all. */
export function buildApiExamples(input: ApiExampleInput): ApiExample[] {
  let base = input.baseUrl || '';
  while (base.endsWith('/')) base = base.slice(0, -1);
  const key = input.keyText || '<your key>';
  const data = `${base}/api/v1/views/${input.slug}/data`;
  const view = `${base}/api/v1/views/${input.slug}`;
  const params = (input.paramDefs || []).map((p: any) => ({
    name: String(p?.name || ''), type: String(p?.type || 'string'), required: !!p?.required,
  })).filter(p => p.name);
  const col = (input.filterColumns || [])[0] || 'region';
  const col2 = (input.filterColumns || [])[1] || col;
  const paramQs = params.filter(p => p.required).map(p => `${qsKey(p.name)}=${sampleValue(p.type)}`).join('&');
  const withParams = (qs: string) => (paramQs ? `${qs}&${paramQs}` : qs);
  const multi = params.find(p => p.type === 'multiselect');

  const out: ApiExample[] = [
    {
      id: 'first-page', title: 'First page',
      explain: 'Ask for up to 1,000 rows (the most per page is set on the API, usually 50,000). '
        + 'The answer has the rows in "data" and a "pagination" block.',
      code: `curl ${KEY_HEADER(key)} \\\n  "${data}?${withParams('limit=1000&offset=0')}"`,
    },
    {
      id: 'next-page', title: 'Next page',
      explain: 'Take pagination.next_page_url from the answer and call it (add the address of '
        + 'this server in front). It asks the SAME question one page on, and carries '
        + 'dataset_version so every page comes from the same data. Stop when has_more is false.',
      code: `curl ${KEY_HEADER(key)} \\\n  "${base}<pagination.next_page_url>"\n\n`
        + `# the same, written out:\ncurl ${KEY_HEADER(key)} \\\n  "${data}?${withParams('limit=1000&offset=1000')}&dataset_version=<pagination.dataset_version>"`,
    },
    {
      id: 'loop', title: 'Read every page (Python)',
      explain: 'Follows next_page_url until has_more is false. A 409 means the data was refreshed '
        + 'while you were paging: start again from the first page. A 416 means you reached the '
        + 'paging limit: take the whole result from /bulk instead. A 429 (too many calls) or 503 '
        + '(a large result is still being prepared) means wait the Retry-After seconds and try again.',
      code: [
        'import time, requests',
        `BASE = "${base}"`,
        `URL = BASE + "/api/v1/views/${input.slug}/data?${withParams('limit=1000&offset=0')}"`,
        `HEADERS = {"X-API-Key": "${key}"}`,
        '',
        'def read_all():',
        '    rows, url = [], URL',
        '    while url:',
        '        r = requests.get(url, headers=HEADERS, timeout=300)',
        '        if r.status_code == 409:          # data refreshed mid-way: start again',
        '            rows, url = [], URL',
        '            continue',
        '        if r.status_code == 416:          # past the paging limit: use /bulk',
        '            raise SystemExit(r.json()["detail"]["continue_with"])',
        '        if r.status_code in (429, 503):   # too many calls / still being prepared: wait',
        '            time.sleep(int(r.headers.get("Retry-After", "5")))',
        '            continue',
        '        r.raise_for_status()',
        '        body = r.json()',
        '        rows.extend(body["data"])',
        '        page = body["pagination"]',
        '        url = BASE + page["next_page_url"] if page["has_more"] else None',
        '    return rows',
      ].join('\n'),
    },
    {
      id: 'filters', title: 'Filters',
      explain: 'filter.<column>=<operator>:<value>. Operators: eq, ne, gt, gte, lt, lte, '
        + 'in, not_in, contains, between. Only the columns this API allows can be filtered.',
      code: [
        `"${data}?filter.${col}=eq:APAC"`,
        `"${data}?filter.${col}=in:APAC,EMEA"`,
        `"${data}?filter.${col2}=between:2025-01-01,2025-12-31"`,
        `"${data}?filter.${col2}=gt:100"`,
      ].map(u => `curl ${KEY_HEADER(key)} ${u}`).join('\n'),
    },
  ];
  if (params.length) {
    out.push({
      id: 'params', title: 'Parameters',
      explain: 'Pass each parameter by its name. '
        + (multi ? `"${multi.name}" takes several values: repeat it, or separate the values with commas. ` : '')
        + 'Every other parameter takes one value.',
      code: params.map(p => p.type === 'multiselect'
        ? `curl ${KEY_HEADER(key)} "${data}?${qsKey(p.name)}=A&${qsKey(p.name)}=B"\ncurl ${KEY_HEADER(key)} "${data}?${qsKey(p.name)}=A,B"`
        : `curl ${KEY_HEADER(key)} "${data}?${qsKey(p.name)}=${sampleValue(p.type)}"${p.required ? '   # required' : ''}`)
        .join('\n'),
    });
  }
  out.push(
    {
      id: 'sort-columns', title: 'Sort and choose columns',
      explain: 'sort=<column>:asc or :desc. columns= picks which columns come back. '
        + 'Keep the same sort on every page.',
      code: `curl ${KEY_HEADER(key)} "${data}?${withParams(`sort=${col}:desc&columns=${col},${col2}&limit=1000&offset=0`)}"`,
    },
    {
      id: 'formats', title: 'CSV, Excel and Parquet',
      explain: 'format=csv, excel or parquet returns one page as a file (no next link). '
        + 'For the whole result use the next example.',
      code: [
        `curl ${KEY_HEADER(key)} "${data}?${withParams('format=csv&limit=50000&offset=0')}" -o page1.csv`,
        `curl ${KEY_HEADER(key)} "${data}?${withParams('format=excel&limit=50000')}" -o page1.xlsx`,
        `curl ${KEY_HEADER(key)} "${data}.parquet?${withParams('limit=50000')}" -o page1.parquet`,
      ].join('\n'),
    },
    {
      id: 'bulk', title: 'The whole result as one file',
      explain: 'No paging and no 1,000,000-row limit: the whole result is streamed. '
        + 'Filters and parameters work the same way.',
      code: [
        `curl ${KEY_HEADER(key)} "${view}/bulk.csv${paramQs ? `?${paramQs}` : ''}" -o ${input.slug}.csv`,
        `curl ${KEY_HEADER(key)} "${view}/bulk.jsonl${paramQs ? `?${paramQs}` : ''}" -o ${input.slug}.jsonl`,
        `curl ${KEY_HEADER(key)} "${view}/bulk/manifest${paramQs ? `?${paramQs}` : ''}"   # size and parts first`,
      ].join('\n'),
    },
    {
      id: 'describe', title: 'What this API returns',
      explain: 'The columns, the filters it allows and its parameters; openapi.json for tools.',
      code: `curl ${KEY_HEADER(key)} "${view}"\ncurl ${KEY_HEADER(key)} "${view}/openapi.json"`,
    },
  );
  return out;
}

function sampleValue(type: string): string {
  if (type === 'date') return '2026-09-30';
  if (type === 'datetime') return '2026-09-30T00:00:00Z';
  if (['integer', 'int', 'number', 'float'].includes(type)) return '100';
  if (type === 'boolean') return 'true';
  return 'value';
}

/** The paging rules, in plain words. */
export const PAGING_RULES: Array<[string, string]> = [
  ['limit / offset', 'limit = rows per page (default 1,000; the most is set on the API, usually 50,000). offset = how many rows to skip.'],
  ['pagination.has_more', 'true while there is another page.'],
  ['pagination.next_page_url', 'The next page of the same question: your filters, sort and parameters are kept.'],
  ['pagination.dataset_version', 'Which copy of the data this page came from. Send it back on the next page (next_page_url does this).'],
  ['409', 'The data was refreshed while you were paging. Start again from offset 0.'],
  ['total_rows + meta.total_mode', 'exact = the full count; at_least = at least this many (the count is still running).'],
  ['416', 'You asked past the paging limit (1,000,000 rows). Take the whole result from /bulk.'],
  ['429', 'Too many calls for this key. Wait the Retry-After seconds. Every page counts as one call.'],
  ['503', 'A large result is still being prepared. Wait the Retry-After seconds and ask again.'],
];

const ApiCallExamples: React.FC<ApiExampleInput & { compact?: boolean }> = ({ compact, ...input }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const examples = buildApiExamples(input);
  const copy = (ex: ApiExample) => {
    // no clipboard (an http page, an old browser): the text is on screen to select
    navigator.clipboard?.writeText(ex.code).catch(() => undefined);
    setCopied(ex.id);
    setTimeout(() => setCopied(null), 1500);
  };
  return (
    <Box data-testid="api-call-examples">
      {!compact && (
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" sx={{ mb: 1 }}>How paging works</Typography>
          <Table size="small" data-testid="api-paging-rules">
            <TableHead>
              <TableRow><TableCell>What</TableCell><TableCell>Meaning</TableCell></TableRow>
            </TableHead>
            <TableBody>
              {PAGING_RULES.map(([k, v]) => (
                <TableRow key={k}><TableCell sx={{ fontFamily: 'monospace', whiteSpace: 'nowrap' }}>{k}</TableCell><TableCell>{v}</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}
      {examples.map((ex, i) => (
        <Accordion key={ex.id} defaultExpanded={i < 2} disableGutters data-testid={`api-example-${ex.id}`}>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="body2" fontWeight={600}>{ex.title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>{ex.explain}</Typography>
            <Stack direction="row" spacing={1} alignItems="flex-start">
              <Box component="pre" sx={{ m: 0, p: 1.5, flex: 1, bgcolor: 'action.hover', borderRadius: 1,
                fontFamily: 'monospace', fontSize: 11, overflowX: 'auto', whiteSpace: 'pre' }}>
                {ex.code}
              </Box>
              <Button size="small" onClick={() => copy(ex)} aria-label={`Copy ${ex.title}`}>
                {copied === ex.id ? 'Copied' : 'Copy'}
              </Button>
            </Stack>
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
};

export default ApiCallExamples;
