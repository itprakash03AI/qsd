"""Shared runner for the S3-source standalones.

2026-06-22 -- single ``run_pipeline`` async function used by ALL three
S3 standalones (s3_to_file, s3_to_oracle, deprecated s3_query alias).
Each standalone is now a thin shim that imports this module + invokes
``run_pipeline`` with its own workflow / worker / polling-query
constants.

Was: 341-line ``s3_query_standalone.py`` duplicated twice.
Now: one runner + three 60-line shims.  Adding a fourth S3 workflow
(e.g., s3_to_kafka) becomes one new shim file.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Type

import yaml


# Console logger -- file handler attaches after we know the batch context.
_LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


SPARK_UPLOAD_ROOT = Path("/usr/local/spark/gvc/jars")
MAX_AGE_HOURS = 1
PREFIX = "spark-upload-"
QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"


def _build_log_file(
    log_dir: str, log_prefix: str,
    dag_id: str, report_id: int, business_date: str,
) -> str:
    """Per-batch log filename.  Same shape across all S3 workflows --
    only the prefix changes."""
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    ts = datetime.now().strftime("%H%M%S")
    return os.path.join(
        log_dir,
        f"{log_prefix}_{safe_dag}_{report_id}_{safe_date}_{ts}.log",
    )


def _attach_file_handler(logger: logging.Logger, log_file: str, log_dir: str) -> None:
    try:
        os.makedirs(log_dir, exist_ok=True)
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter(_LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} -- console only")


def cleanup_old_spark_uploads(logger: logging.Logger) -> None:
    """Delete spark-upload-* directories older than MAX_AGE_HOURS."""
    cutoff = time.time() - (MAX_AGE_HOURS * 3600)
    try:
        for item in SPARK_UPLOAD_ROOT.iterdir():
            if item.is_dir() and item.name.startswith(PREFIX):
                if item.stat().st_atime < cutoff:
                    logger.info(f"Deleting: {item}")
                    try:
                        shutil.rmtree(item)
                    except Exception as e:
                        logger.error(f"Failed to delete {item}: {e}")
    except Exception as e:
        logger.error(f"cleanup_old_spark_uploads failed: {e}")


async def _execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    worker_class: Type,
    logger: logging.Logger,
    run_report=None,
    artifacts=None,
) -> None:
    """Run all task steps for a RUN_ID through the supplied worker class."""
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError(
            "tasks + worker_connection_string + dest_connection_string required"
        )

    from managers.oracle_metadata_manager import OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)
    worker = worker_class(oracle_data_manager, logger)

    for task in tasks:
        task["log_file"] = log_file
        if run_report is not None:
            task["_run_report"] = run_report
        if artifacts is not None:
            task["_run_artifacts"] = artifacts
        logger.info(
            f"Executing task {task.get('run_id')} DAG_ID={task.get('fk_dag_id')} "
            f"REPORT_ID={task.get('fk_report_id')} step={task.get('task_steps')} "
            f"SEQ={task.get('seq')}"
        )
        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {e}"
            )
            raise  # StandaloneRunLifecycle catches + runs cleanup / failure email


async def run_pipeline(
    *,
    workflow: str,
    worker_class: Type,
    log_prefix: str,
    polling_query_key: str,
    description: str,
    logger_name: str,
) -> None:
    """Top-level driver: parse args -> fetch tasks -> wrap with lifecycle ->
    dispatch each step through the supplied worker class.

    Args:
      workflow: step_mapping.yaml section name (s3_to_file / s3_to_oracle / s3_query).
      worker_class: Python class to instantiate per RUN_ID.
      log_prefix: filename + logger-name prefix (e.g., 's3_to_file').
      polling_query_key: key in etl_polling_task_query.yaml.
      description: argparse description text.
      logger_name: module logger name (e.g., 's3_to_file_standalone').
    """
    # Module logger -- console output until file handler attaches.
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(logging.Formatter(_LOG_FMT))
        logger.addHandler(sh)

    cleanup_old_spark_uploads(logger)

    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--report_id", type=int, required=True)
    parser.add_argument("--business_date", type=str, required=True)
    parser.add_argument("--dag_id", type=str, required=True)
    parser.add_argument(
        "--config_path", type=str,
        default="/usr/local/spark/pvc/code/configs/oracle_config.yaml",
    )
    parser.add_argument("--no-auto-install", action="store_true")
    parser.add_argument("--no-install-optional", action="store_true")
    args = parser.parse_args()

    if args.no_auto_install or args.no_install_optional:
        try:
            from preflight import preflight_check
            preflight_check(
                workflow=workflow,
                auto_install=not args.no_auto_install,
                install_optional=not args.no_install_optional,
            )
        except ImportError:
            pass

    # Resolve log directory via the shared helper.
    from log_config import get_log_dir
    log_dir = get_log_dir()
    log_file = _build_log_file(
        log_dir, log_prefix, args.dag_id, args.report_id, args.business_date,
    )
    _attach_file_handler(logger, log_file, log_dir)

    logger.info(
        f"Starting {workflow} batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    if not os.path.exists(args.config_path):
        raise FileNotFoundError(f"Configuration file not found: {args.config_path}")
    with open(args.config_path, "r") as f:
        config = yaml.safe_load(f)
    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    if not os.path.exists(QUERIES_PATH):
        raise FileNotFoundError(f"Queries file not found: {QUERIES_PATH}")
    with open(QUERIES_PATH, "r") as qf:
        queries = yaml.safe_load(qf)
    if polling_query_key not in queries:
        raise ValueError(
            f"{polling_query_key!r} not found in etl_polling_task_query.yaml.  "
            f"Available keys: {sorted(queries.keys())}."
        )

    # 2026-06-22 -- vault-aware connection string resolution.
    from oracle_config_loader import (
        resolve_etl_connection_string,
        resolve_dest_connection_string,
    )
    worker_connection_string = resolve_etl_connection_string(config)
    dest_connection_string = resolve_dest_connection_string(config)
    if not worker_connection_string:
        raise ValueError(
            "ETL Oracle connection string unresolved.  Set yaml literal, "
            "oracle.etl.secret_ref (vault), or ETL_ORACLE_CONN env var."
        )

    from managers.oracle_metadata_manager import OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries[polling_query_key],
        {"1": args.report_id, "2": args.business_date, "3": args.dag_id},
        worker_connection_string,
    )
    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    tasks: List[Dict[str, Any]] = [
        {k.lower(): v for k, v in row.items()}
        for row in tasks_df.to_dict(orient="records")
    ]
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    from standalone_lifecycle import StandaloneRunLifecycle
    async with StandaloneRunLifecycle(
        pipeline=workflow,
        dag_id=args.dag_id,
        report_id=args.report_id,
        business_date=args.business_date,
        log_file=log_file,
        config=config,
        sample=tasks[0],
        logger=logger,
    ) as lc:
        await _execute_tasks(
            tasks, config,
            worker_connection_string, dest_connection_string,
            log_file, worker_class, logger,
            run_report=lc.run_report, artifacts=lc.artifacts,
        )
