"""The ReconciliationCycle state machine: detect → discover → estimate → dispatch.

This is the brain.  Compare runs, turns rows into actions, dispatcher
routes them.  Idempotency is checked HERE — not in the dispatcher —
because the dispatcher is intentionally dumb.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Protocol

from .comparator import TableComparator
from .dispatcher import SyncDispatcher
from .models import (
    DiscrepancyRow, DispatchMode, SyncAction, TableTriple,
)

_log = logging.getLogger(__name__)


class IdempotencyStore(Protocol):
    """Has this idempotency key been dispatched recently?

    Implementation typically backed by Oracle's existing job-state table —
    one row per (idempotency_key, status, dispatched_at).  Returning True
    suppresses re-dispatch; the caller logs and moves on.
    """
    def already_dispatched(self, idempotency_key: str) -> bool: ...
    def record_dispatch(self, action: SyncAction, dispatch_result: str) -> None: ...


@dataclass
class CycleResult:
    triple: TableTriple
    discrepancies: List[DiscrepancyRow]
    actions: List[SyncAction]
    dispatched: List[str]   # one id per successful dispatch
    suppressed: List[str]   # idempotency_keys we skipped
    failures: List[str]     # idempotency_keys where dispatch raised


class SyncOrchestrator:
    """Runs one reconciliation cycle for one TableTriple."""

    DEFAULT_THRESHOLD = 500_000

    def __init__(
        self,
        comparator: TableComparator,
        dispatcher: SyncDispatcher,
        idempotency: IdempotencyStore,
        proc_name: str,
        polling_threshold: int = DEFAULT_THRESHOLD,
        proc_param_builder: Optional[Callable[[SyncAction], Dict[str, object]]] = None,
    ) -> None:
        self._comparator = comparator
        self._dispatcher = dispatcher
        self._idempotency = idempotency
        self._proc_name = proc_name
        self._threshold = int(polling_threshold)
        self._proc_param_builder = proc_param_builder or self._default_param_builder

    def run(self, triple: TableTriple) -> CycleResult:
        _log.info(
            "[sync.cycle] start triple=%s threshold=%d",
            triple.logical_name, self._threshold,
        )
        discrepancies = self._comparator.compare(triple)
        actions = [self._build_action(triple, row) for row in discrepancies]

        dispatched: List[str] = []
        suppressed: List[str] = []
        failures: List[str] = []

        for action in actions:
            if self._idempotency.already_dispatched(action.idempotency_key):
                _log.info(
                    "[sync.cycle] SKIP (already dispatched) idemp=%s",
                    action.idempotency_key,
                )
                suppressed.append(action.idempotency_key)
                continue
            try:
                result = self._dispatcher.dispatch(action)
                self._idempotency.record_dispatch(action, result)
                dispatched.append(result)
            except Exception as exc:
                _log.error(
                    "[sync.cycle] DISPATCH-FAILED idemp=%s mode=%s: %s",
                    action.idempotency_key, action.dispatch_mode.value, exc,
                    exc_info=True,
                )
                failures.append(action.idempotency_key)

        _log.info(
            "[sync.cycle] done triple=%s discrepancies=%d dispatched=%d "
            "suppressed=%d failed=%d",
            triple.logical_name, len(discrepancies),
            len(dispatched), len(suppressed), len(failures),
        )
        return CycleResult(
            triple=triple,
            discrepancies=discrepancies,
            actions=actions,
            dispatched=dispatched,
            suppressed=suppressed,
            failures=failures,
        )

    # ── Internals ─────────────────────────────────────────────────────

    def _build_action(self, triple: TableTriple, row: DiscrepancyRow) -> SyncAction:
        mode = (
            DispatchMode.POLLING
            if row.affected_estimate < self._threshold
            else DispatchMode.AIRFLOW
        )
        idem = row.key.idempotency_key(triple.logical_name)
        action = SyncAction(
            logical_name=triple.logical_name,
            key=row.key,
            estimated_rows=row.affected_estimate,
            dispatch_mode=mode,
            proc_name=self._proc_name,
            proc_params={},  # filled below
            idempotency_key=idem,
        )
        action.proc_params = self._proc_param_builder(action)
        return action

    @staticmethod
    def _default_param_builder(action: SyncAction) -> Dict[str, object]:
        """Default proc bind variables — driven entirely by the discovered key.
        Override via constructor when your proc takes a different shape."""
        return {
            "p_code":                action.key.code,
            "p_business_close_date": action.key.business_close_date,
            "p_business_event":      action.key.business_event,
            "p_idempotency_key":     action.idempotency_key,
        }
