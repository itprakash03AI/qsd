"""Entry point for the sync process.

Two modes:
  1. CLI one-shot:  python -m ETL.sync.main run --config configs/sync_tables.yaml
  2. FastAPI service: python -m ETL.sync.main serve --port 9100

Real connectors get wired here, NOT in the orchestrator — keeps the
business logic test-only and the network layer ops-tunable.
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List

import yaml

from .comparator import TableComparator
from .dispatcher import SyncDispatcher
from .models import TableRef, TableTriple
from .orchestrator import SyncOrchestrator

_log = logging.getLogger("etl.sync")


# ── Config loading ────────────────────────────────────────────────────


def load_triples(path: Path) -> tuple[List[TableTriple], dict]:
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    triples: List[TableTriple] = []
    for entry in data.get("triples", []):
        refs = [TableRef(**r) for r in entry["refs"]]
        triples.append(TableTriple(
            logical_name=entry["logical_name"],
            refs=refs,
            cron_schedule=entry.get("cron_schedule") or entry.get("schedule", ""),
            timezone=entry.get("timezone", "UTC"),
            code_column=entry.get("code_column", "code"),
            close_date_column=entry.get("close_date_column", "business_close_date"),
            event_column=entry.get("event_column", "business_event"),
        ))
    return triples, data


# ── Connector factory ─────────────────────────────────────────────────
# Imported lazily so unit tests don't need trino/oracledb installed.


def build_connectors() -> Dict[str, "object"]:
    connectors = {}
    if os.environ.get("STARBURST_CLOUD_HOST"):
        from ETL.starburst_config_loader import load as _sbload  # type: ignore
        from ETL.managers.querystudio_bridge import (   # type: ignore
            QueryStudioStarburstAdapter as _Adapter,
        )
        connectors["starburst_cloud"] = _Adapter(_sbload("cloud"))
    if os.environ.get("STARBURST_ONPREM_HOST"):
        from ETL.starburst_config_loader import load as _sbload  # type: ignore
        from ETL.managers.querystudio_bridge import (   # type: ignore
            QueryStudioStarburstAdapter as _Adapter,
        )
        connectors["starburst_onprem"] = _Adapter(_sbload("onprem"))
    if os.environ.get("ETL_ORACLE_USER"):
        from ETL.managers.oracledblib import OracleDBLib   # type: ignore
        connectors["oracle"] = OracleDBLib()  # already env-driven
    return connectors


# ── Dispatcher backends ───────────────────────────────────────────────


def build_dispatcher() -> SyncDispatcher:
    """SyncDispatcher with direct-proc backend (<500K) + Airflow (≥500K).

    DropsThe polling-service queue path entirely — orchestrator runs the
    remediation proc inline for small jobs (user choice: "I have proc and
    parameter to execute just").
    """
    from ETL.cron.airflow_client import AirflowConfig, AirflowDispatcher
    from ETL.managers.oracledblib import OracleDBLib  # type: ignore
    airflow = AirflowDispatcher(AirflowConfig.from_env())

    class _DirectProcBackend:
        """Run the remediation proc inline.  Same proc the Airflow DAG
        would call — just executed in the orchestrator pod instead of
        Spark.  Suited only for <500K row jobs."""
        def __init__(self):
            self._db = OracleDBLib()
        def execute(self, action):
            self._db.execute_procedure(action.proc_name, action.proc_params)
            return action.idempotency_key

    return SyncDispatcher(direct=_DirectProcBackend(), airflow=airflow)


def build_idempotency():
    """Oracle-table-backed (no PL/SQL package needed) with cron-derived
    suppression window.  See ETL/sync/idempotency.py for the schema."""
    from ETL.managers.oracledblib import OracleDBLib  # type: ignore
    from .idempotency import OracleIdempotencyStore
    return OracleIdempotencyStore(oracle_invoker=OracleDBLib())


# ── CLI ───────────────────────────────────────────────────────────────


def cmd_run(args) -> int:
    triples, data = load_triples(Path(args.config))
    connectors = build_connectors()
    orch = SyncOrchestrator(
        comparator=TableComparator(connectors=connectors),
        dispatcher=build_dispatcher(),
        idempotency=build_idempotency(),
        proc_name=data.get("default_proc_name", "OTG_PKG_RECONCILE.SYNC_ONE_GROUP"),
        polling_threshold=int(data.get("polling_threshold", 500_000)),
    )
    total_fail = 0
    for triple in triples:
        result = orch.run(triple)
        total_fail += len(result.failures)
    return 1 if total_fail else 0


def cmd_serve(args) -> int:
    """Optional FastAPI mode — exposes POST /sync/run for ad-hoc triggers."""
    from fastapi import FastAPI
    import uvicorn
    triples, data = load_triples(Path(args.config))
    orch = SyncOrchestrator(
        comparator=TableComparator(connectors=build_connectors()),
        dispatcher=build_dispatcher(),
        idempotency=build_idempotency(),
        proc_name=data.get("default_proc_name", "OTG_PKG_RECONCILE.SYNC_ONE_GROUP"),
        polling_threshold=int(data.get("polling_threshold", 500_000)),
    )
    app = FastAPI(title="ETL Sync Service")

    @app.get("/health")
    def health(): return {"ok": True, "triples": [t.logical_name for t in triples]}

    @app.post("/sync/run")
    def run_all():
        return [{
            "logical_name": t.logical_name,
            "result": orch.run(t).__dict__,
        } for t in triples]

    @app.post("/sync/run/{logical_name}")
    def run_one(logical_name: str):
        for t in triples:
            if t.logical_name == logical_name:
                return orch.run(t).__dict__
        return {"error": f"unknown logical_name={logical_name}"}

    uvicorn.run(app, host=args.host, port=args.port)
    return 0


def main(argv=None) -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )
    p = argparse.ArgumentParser(description="ETL Sync Process")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="One-shot run for all triples")
    p_run.add_argument("--config", default="ETL/configs/sync_tables.yaml")
    p_run.set_defaults(func=cmd_run)

    p_srv = sub.add_parser("serve", help="Run as FastAPI service")
    p_srv.add_argument("--config", default="ETL/configs/sync_tables.yaml")
    p_srv.add_argument("--host", default="0.0.0.0")
    p_srv.add_argument("--port", type=int, default=9100)
    p_srv.set_defaults(func=cmd_serve)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
