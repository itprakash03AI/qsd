"""Cron-window idempotency — suppresses re-dispatch within one cron cycle.

User choice: window is auto-derived from the triple's cron expression
(answer to question 2: "cron expressions based").  If the cycle fires
every 4 hours, the window is 4 hours — we never re-fire within the same
cycle, but the next cycle's re-detect causes retry.

Oracle-table backed.  Two implementations available:
  - OracleIdempotencyStore — production; uses ETL_SYNC_AUDIT.
  - InMemoryIdempotencyStore — dev/test; resets at pod restart.

Both satisfy the orchestrator.IdempotencyStore protocol.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone
from typing import Dict, Optional, Protocol

from .models import SyncAction

_log = logging.getLogger(__name__)


# ── Cron parsing → window ────────────────────────────────────────────


def cron_to_window(cron_expr: str, now: Optional[datetime] = None) -> timedelta:
    """Return the INTERVAL between consecutive fires of this cron.

    Semantics: "if we dispatched at the previous fire, suppress until the
    next fire."  Concretely:
      - "0 */4 * * *"  → 4 hours
      - "0 * * * *"    → 1 hour
      - "0 0 * * *"    → 24 hours

    Computed as (next_fire - prev_fire) so the value is the actual cron
    interval, not "time since prev_fire from now" (which would shrink as
    `now` drifts toward the next fire).

    Falls back to 4h if the expression is empty / unparseable.  Always
    returns ≥ 1 minute as a defensive lower bound.
    """
    if not cron_expr or not cron_expr.strip():
        return timedelta(hours=4)
    if now is None:
        now = datetime.now(timezone.utc)
    try:
        from croniter import croniter
        prev_it = croniter(cron_expr, now)
        prev_fire = prev_it.get_prev(datetime)
        next_it = croniter(cron_expr, now)
        next_fire = next_it.get_next(datetime)
        return max(next_fire - prev_fire, timedelta(minutes=1))
    except Exception as exc:
        _log.warning(
            "[idempotency] cron_to_window: could not parse %r — "
            "falling back to 4h window (%s)",
            cron_expr, exc,
        )
        return timedelta(hours=4)


# ── In-memory (dev/test) ─────────────────────────────────────────────


class InMemoryIdempotencyStore:
    """Volatile store — wipes on pod restart.  Use ONLY in dev/test."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # idempotency_key → (dispatched_at, status)
        self._records: Dict[str, tuple[datetime, str]] = {}
        # logical_name → cron expression (set by orchestrator at register)
        self._cron_by_triple: Dict[str, str] = {}

    def set_cron_for_triple(self, logical_name: str, cron_expr: str) -> None:
        self._cron_by_triple[logical_name] = cron_expr or ""

    def already_dispatched(self, idempotency_key: str) -> bool:
        with self._lock:
            rec = self._records.get(idempotency_key)
        if rec is None:
            return False
        dispatched_at, status = rec
        # Failed remediations are ALWAYS retried — clear the suppression
        # so the next cycle re-dispatches.  Mirrors G9 fix from the deploy
        # plan (feedback loop from polling/airflow back to sync).
        if status == "failed":
            return False
        # The cron-window check requires a logical_name → cron lookup.
        # The idempotency_key has the logical_name embedded
        # (sync:<logical_name>:<hash>); parse it back out.
        logical_name = idempotency_key.split(":", 2)[1] if ":" in idempotency_key else ""
        window = cron_to_window(self._cron_by_triple.get(logical_name, ""))
        return (datetime.now(timezone.utc) - dispatched_at) < window

    def record_dispatch(self, action: SyncAction, dispatch_result: str) -> None:
        with self._lock:
            self._records[action.idempotency_key] = (
                datetime.now(timezone.utc),
                "in_flight",  # updated to success/failed by remediation feedback
            )

    def mark_status(self, idempotency_key: str, status: str) -> None:
        """Called by the remediation-feedback path (Airflow DAG webhook
        or direct-proc completion) to update the row.  No-op if key
        unknown."""
        with self._lock:
            rec = self._records.get(idempotency_key)
            if rec:
                self._records[idempotency_key] = (rec[0], status)


# ── Oracle-backed (production) ───────────────────────────────────────


class OracleIdempotencyStore:
    """Persistent store backed by ETL_SYNC_AUDIT.

    Schema (run once via DBA):

        CREATE TABLE ETL_SYNC_AUDIT (
          IDEMPOTENCY_KEY VARCHAR2(64) PRIMARY KEY,
          LOGICAL_NAME    VARCHAR2(200) NOT NULL,
          DISPATCH_MODE   VARCHAR2(20)  NOT NULL,
          DISPATCH_RESULT VARCHAR2(500),
          STATUS          VARCHAR2(20)  DEFAULT 'in_flight',
          DISPATCHED_AT   TIMESTAMP     DEFAULT SYSTIMESTAMP,
          UPDATED_AT      TIMESTAMP
        );
        CREATE INDEX IX_ETL_SYNC_AUDIT_LOOKUP
          ON ETL_SYNC_AUDIT(LOGICAL_NAME, DISPATCHED_AT);

    No PL/SQL package needed — straight SELECT/INSERT/UPDATE via the
    oracledb connection we already have.
    """

    def __init__(self, oracle_invoker) -> None:
        # oracle_invoker is the same OracleDBLib instance the ProcRunner
        # uses — reuses the connection pool.
        self._db = oracle_invoker
        self._lock = threading.Lock()
        self._cron_by_triple: Dict[str, str] = {}

    def set_cron_for_triple(self, logical_name: str, cron_expr: str) -> None:
        with self._lock:
            self._cron_by_triple[logical_name] = cron_expr or ""

    def already_dispatched(self, idempotency_key: str) -> bool:
        logical_name = idempotency_key.split(":", 2)[1] if ":" in idempotency_key else ""
        with self._lock:
            cron_expr = self._cron_by_triple.get(logical_name, "")
        window = cron_to_window(cron_expr)
        cutoff = datetime.now(timezone.utc) - window
        sql = (
            "SELECT 1 FROM ETL_SYNC_AUDIT "
            "WHERE IDEMPOTENCY_KEY = :k "
            "  AND DISPATCHED_AT > :cutoff "
            "  AND STATUS != 'failed'"
        )
        try:
            rows = self._db.query_rows(sql, {"k": idempotency_key, "cutoff": cutoff})
            return bool(rows)
        except Exception as exc:
            # On audit-table failure we fall OPEN (re-dispatch) — better
            # to double-fire and let the remediation proc handle dedup
            # than to silently suppress a real discrepancy.
            _log.warning(
                "[idempotency] audit lookup failed (failing OPEN — "
                "may double-dispatch): %s", exc,
            )
            return False

    def record_dispatch(self, action: SyncAction, dispatch_result: str) -> None:
        # Upsert pattern — MERGE so re-dispatch within the same cron window
        # (shouldn't happen, but tolerate) doesn't crash with PK violation.
        sql = (
            "MERGE INTO ETL_SYNC_AUDIT t "
            "USING (SELECT :k AS k FROM dual) s ON (t.IDEMPOTENCY_KEY = s.k) "
            "WHEN MATCHED THEN UPDATE SET "
            "  LOGICAL_NAME = :ln, "
            "  DISPATCH_MODE = :dm, "
            "  DISPATCH_RESULT = :dr, "
            "  STATUS = 'in_flight', "
            "  UPDATED_AT = SYSTIMESTAMP "
            "WHEN NOT MATCHED THEN INSERT ("
            "  IDEMPOTENCY_KEY, LOGICAL_NAME, DISPATCH_MODE, DISPATCH_RESULT, "
            "  STATUS, DISPATCHED_AT, UPDATED_AT) "
            "VALUES (:k, :ln, :dm, :dr, 'in_flight', SYSTIMESTAMP, SYSTIMESTAMP)"
        )
        try:
            self._db.execute(sql, {
                "k":  action.idempotency_key,
                "ln": action.logical_name,
                "dm": action.dispatch_mode.value,
                "dr": dispatch_result[:500],
            })
        except Exception as exc:
            _log.error(
                "[idempotency] record_dispatch FAILED key=%s: %s",
                action.idempotency_key, exc,
            )

    def mark_status(self, idempotency_key: str, status: str) -> None:
        """Feedback hook — call this from the remediation completion
        path so future cron windows can re-detect if a job failed."""
        sql = (
            "UPDATE ETL_SYNC_AUDIT "
            "SET STATUS = :s, UPDATED_AT = SYSTIMESTAMP "
            "WHERE IDEMPOTENCY_KEY = :k"
        )
        try:
            self._db.execute(sql, {"k": idempotency_key, "s": status})
        except Exception as exc:
            _log.warning(
                "[idempotency] mark_status key=%s status=%s failed: %s",
                idempotency_key, status, exc,
            )
