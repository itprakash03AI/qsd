"""Cross-environment table comparator.

Strategy: GROUP BY (code, business_close_date, BusinessEvent) per env,
emit one DiscrepancyRow per key where counts disagree.

We do NOT do row-by-row diffs — those don't scale, and the user's
remediation contract is "given (code, date, event), re-run the proc",
which is a group-level operation by design.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from typing import Callable, Dict, List, Protocol

from .models import DiscrepancyKey, DiscrepancyRow, TableRef, TableTriple

_log = logging.getLogger(__name__)


# ── Connection protocol ────────────────────────────────────────────────
# Every environment connector (StarburstConnector, OracleConnector) just
# needs to implement this one method.  Keeps the comparator decoupled
# from how rows get read.


class EnvConnector(Protocol):
    """One method, one return shape — caller-controlled SQL."""
    def query_rows(self, sql: str) -> List[dict]:
        ...


@dataclass
class _GroupCount:
    key: DiscrepancyKey
    count: int


class TableComparator:
    """Detects per-group count discrepancies across N environments.

    Usage:
        comp = TableComparator(connectors={"starburst_cloud": c1, ...})
        rows = comp.compare(triple)
        # rows is a list of DiscrepancyRow — only mismatches, never matches.
    """

    def __init__(
        self,
        connectors: Dict[str, EnvConnector],
        sql_dialect_overrides: Dict[str, Callable[[TableRef, TableTriple], str]] | None = None,
    ) -> None:
        self._connectors = connectors
        self._dialect_overrides = sql_dialect_overrides or {}

    # ── Public ────────────────────────────────────────────────────────

    def compare(self, triple: TableTriple) -> List[DiscrepancyRow]:
        """Run the GROUP BY per env, diff the results, return mismatches."""
        per_env_counts = self._collect(triple)
        return self._diff(per_env_counts)

    # ── Internals ─────────────────────────────────────────────────────

    def _collect(self, triple: TableTriple) -> Dict[str, Dict[DiscrepancyKey, int]]:
        out: Dict[str, Dict[DiscrepancyKey, int]] = {}
        for ref in triple.refs:
            connector = self._connectors.get(ref.env)
            if connector is None:
                # Surface loudly — silent skip = false-positive "everything in sync"
                raise KeyError(
                    f"No connector registered for env={ref.env!r} "
                    f"(triple={triple.logical_name!r})"
                )
            sql = self._build_sql(triple, ref)
            _log.info(
                "[sync.compare] env=%s table=%s — running GROUP BY",
                ref.env, ref.fqn,
            )
            rows = connector.query_rows(sql)
            out[ref.env] = {
                self._row_to_key(row, triple): int(row["cnt"])
                for row in rows
            }
            _log.info(
                "[sync.compare] env=%s table=%s — %d groups",
                ref.env, ref.fqn, len(out[ref.env]),
            )
        return out

    def _build_sql(self, triple: TableTriple, ref: TableRef) -> str:
        # Priority order:
        #   1. ref.query — user-supplied SQL, used verbatim.  This is
        #      the recommended path — you control the WHERE clause and
        #      the dialect quirks per env.
        #   2. self._dialect_overrides[ref.env] — programmatic override.
        #   3. Built from triple column names — portable ANSI fallback.
        if ref.has_custom_query:
            return ref.query
        override = self._dialect_overrides.get(ref.env)
        if override is not None:
            return override(ref, triple)
        # Oracle treats unquoted identifiers as case-insensitive (folded to
        # upper); Starburst/Trino are case-sensitive by default but folded
        # to lower-case for unquoted names.  Skip the quotes entirely in
        # the fallback so both work.  For dialect-specific quoting needs,
        # use the ref.query path instead.
        return (
            f'SELECT {triple.code_column} AS code, '
            f'{triple.close_date_column} AS close_date, '
            f'{triple.event_column} AS event, '
            f'COUNT(*) AS cnt '
            f'FROM {ref.fqn} '
            f'GROUP BY {triple.code_column}, '
            f'{triple.close_date_column}, '
            f'{triple.event_column}'
        )

    @staticmethod
    def _row_to_key(row: dict, triple: TableTriple) -> DiscrepancyKey:
        # Case-insensitive column lookup so Oracle (uppercase) and
        # Starburst (lowercase) results both work without preprocessing.
        get = lambda c: (
            row.get(c) if c in row else
            row.get(c.lower()) if c.lower() in row else
            row.get(c.upper())
        )
        code = get("code")
        close = get("close_date")
        event = get("event")
        if isinstance(close, str):
            close = date.fromisoformat(close[:10])
        return DiscrepancyKey(
            code=str(code),
            business_close_date=close,
            business_event=str(event),
        )

    def _diff(
        self,
        per_env: Dict[str, Dict[DiscrepancyKey, int]],
    ) -> List[DiscrepancyRow]:
        all_keys: set[DiscrepancyKey] = set()
        for env_counts in per_env.values():
            all_keys.update(env_counts.keys())
        rows: List[DiscrepancyRow] = []
        for key in all_keys:
            counts = {env: per_env[env].get(key, 0) for env in per_env}
            row = DiscrepancyRow(key=key, counts=counts)
            if not row.in_sync:
                rows.append(row)
        rows.sort(key=lambda r: r.affected_estimate, reverse=True)
        _log.info(
            "[sync.compare] %d discrepancy groups (max affected=%d)",
            len(rows), rows[0].affected_estimate if rows else 0,
        )
        return rows
