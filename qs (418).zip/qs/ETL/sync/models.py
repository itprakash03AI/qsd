"""Domain model for cross-environment table reconciliation.

ONE unifying abstraction: a `ReconciliationCycle` consumes a TableTriple,
produces a list of DiscrepancyRow (one per group-by key where envs
disagree), and the orchestrator turns each row into a SyncAction
(carrying everything the proc needs — no hardcoding).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from enum import Enum
from typing import Dict, List, Optional


# ── Where the table lives ────────────────────────────────────────────────

@dataclass(frozen=True)
class TableRef:
    """One physical location of a logical table.

    Two shapes:
      - column-driven (legacy): supply catalog/schema/table; comparator
        builds the GROUP BY SQL from the triple's column names.
      - query-driven (recommended): supply `query` — the comparator
        runs it as-is.  The query MUST return columns named
        `code`, `close_date`, `event`, `cnt` (case-insensitive).
        This frees you from any dialect quirks across Starburst /
        Trino / Oracle — write each env's SQL the way that env wants it.
    """
    env: str                    # "starburst_cloud" | "starburst_onprem" | "oracle"
    catalog: str = ""
    schema: str = ""
    table: str = ""
    query: str = ""             # user-supplied SQL; overrides catalog/schema/table

    @property
    def fqn(self) -> str:
        return f"{self.catalog}.{self.schema}.{self.table}"

    @property
    def has_custom_query(self) -> bool:
        return bool(self.query and self.query.strip())


@dataclass(frozen=True)
class TableTriple:
    """One logical table across N environments (typically 3)."""
    logical_name: str
    refs: List[TableRef]
    # Optional cron expression — when set, sync_orchestrator_main picks
    # it up and registers the cycle on APScheduler.  Also used by the
    # IdempotencyStore to compute the per-cycle suppression window.
    cron_schedule: str = ""
    timezone: str = "UTC"
    # Column names for the column-driven SQL path.  Ignored when refs
    # supply their own query.
    code_column: str = "code"
    close_date_column: str = "business_close_date"
    event_column: str = "business_event"


# ── What was found ──────────────────────────────────────────────────────

@dataclass(frozen=True)
class DiscrepancyKey:
    """The discovered params — feeds straight into the remediation proc.

    Hashes for idempotency keys to suppress double-fires.
    """
    code: str
    business_close_date: date
    business_event: str

    def idempotency_key(self, logical_name: str) -> str:
        h = hashlib.sha256(
            f"{logical_name}|{self.code}|{self.business_close_date.isoformat()}"
            f"|{self.business_event}".encode()
        ).hexdigest()[:16]
        return f"sync:{logical_name}:{h}"


@dataclass
class DiscrepancyRow:
    """One row of the comparator output."""
    key: DiscrepancyKey
    counts: Dict[str, int]      # env → count.  Missing env means 0.
    detected_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc),
    )

    @property
    def max_count(self) -> int:
        return max(self.counts.values(), default=0)

    @property
    def min_count(self) -> int:
        return min(self.counts.values(), default=0)

    @property
    def in_sync(self) -> bool:
        return self.max_count == self.min_count

    @property
    def affected_estimate(self) -> int:
        """Rows the remediation must move.  Use MAX so we never
        under-provision the dispatch tier."""
        return self.max_count


# ── What gets dispatched ────────────────────────────────────────────────

class DispatchMode(str, Enum):
    POLLING = "polling"     # < threshold rows
    AIRFLOW = "airflow"     # ≥ threshold rows


@dataclass
class SyncAction:
    """The work order — produced by orchestrator, consumed by dispatcher."""
    logical_name: str
    key: DiscrepancyKey
    estimated_rows: int
    dispatch_mode: DispatchMode
    proc_name: str                          # Oracle proc to run
    proc_params: Dict[str, object]          # bind variables for the proc
    idempotency_key: str
    detected_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc),
    )

    def as_dict(self) -> Dict[str, object]:
        return {
            "logical_name":       self.logical_name,
            "code":               self.key.code,
            "business_close_date": self.key.business_close_date.isoformat(),
            "business_event":     self.key.business_event,
            "estimated_rows":     self.estimated_rows,
            "dispatch_mode":      self.dispatch_mode.value,
            "proc_name":          self.proc_name,
            "proc_params":        self.proc_params,
            "idempotency_key":    self.idempotency_key,
            "detected_at":        self.detected_at.isoformat(),
        }
