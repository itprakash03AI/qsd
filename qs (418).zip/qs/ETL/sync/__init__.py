"""Process 1: Data sync — detect cross-env discrepancies and dispatch remediation.

Public surface:
  - SyncOrchestrator: run a reconciliation cycle for a TableTriple.
  - models: TableTriple, TableRef, DiscrepancyKey, DiscrepancyRow, SyncAction.
"""
from .models import (
    TableRef, TableTriple,
    DiscrepancyKey, DiscrepancyRow,
    SyncAction, DispatchMode,
)
from .orchestrator import SyncOrchestrator
from .idempotency import (
    InMemoryIdempotencyStore, OracleIdempotencyStore, cron_to_window,
)

__all__ = [
    "TableRef", "TableTriple",
    "DiscrepancyKey", "DiscrepancyRow",
    "SyncAction", "DispatchMode",
    "SyncOrchestrator",
    "InMemoryIdempotencyStore", "OracleIdempotencyStore", "cron_to_window",
]
