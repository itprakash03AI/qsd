"""Size-based dispatch — strategy pattern.

The dispatcher itself owns ZERO routing intelligence: it asks each
SyncAction `dispatch_mode` (set by the orchestrator after consulting the
threshold) and forwards to the matching backend.

2026-06-15 — dropped the polling-service queue path per user input
("I have proc and parameter to execute just").  Small (<500K)
remediations now run the proc DIRECTLY from the orchestrator pod;
large (>=500K) trigger Airflow → Spark.  Simpler control flow, no
extra Oracle queue / step_mapping wiring needed.
"""
from __future__ import annotations

import logging
from typing import Protocol

from .models import DispatchMode, SyncAction

_log = logging.getLogger(__name__)


# ── Backend protocols — implement these to plug in real systems ────────


class DirectProcBackend(Protocol):
    """Execute the remediation proc directly on Oracle (for <500K).

    Implementation just wraps oracledblib.execute_procedure(...).
    """
    def execute(self, action: SyncAction) -> str:
        """Return a result identifier (proc invocation id, or the
        idempotency key when the proc has no native id)."""


class AirflowBackend(Protocol):
    """POST to Airflow REST API to trigger a DAG run."""
    def trigger(self, action: SyncAction) -> str:
        """Return the Airflow dag_run_id."""


# ── The dispatcher itself ──────────────────────────────────────────────


class SyncDispatcher:
    """Routes SyncActions to direct-proc or airflow based on dispatch_mode."""

    def __init__(self, direct: DirectProcBackend, airflow: AirflowBackend) -> None:
        self._direct = direct
        self._airflow = airflow

    def dispatch(self, action: SyncAction) -> str:
        if action.dispatch_mode is DispatchMode.POLLING:
            # POLLING is the legacy name kept for back-compat in the enum;
            # under the new design it just means "small enough to execute
            # the proc inline rather than fan out to Spark."
            _log.info(
                "[sync.dispatch] DIRECT-PROC table=%s key=(%s, %s, %s) rows=%d idemp=%s",
                action.logical_name, action.key.code,
                action.key.business_close_date.isoformat(),
                action.key.business_event, action.estimated_rows,
                action.idempotency_key,
            )
            return self._direct.execute(action)
        if action.dispatch_mode is DispatchMode.AIRFLOW:
            _log.info(
                "[sync.dispatch] AIRFLOW table=%s key=(%s, %s, %s) rows=%d idemp=%s",
                action.logical_name, action.key.code,
                action.key.business_close_date.isoformat(),
                action.key.business_event, action.estimated_rows,
                action.idempotency_key,
            )
            return self._airflow.trigger(action)
        raise ValueError(f"Unknown dispatch_mode={action.dispatch_mode!r}")
