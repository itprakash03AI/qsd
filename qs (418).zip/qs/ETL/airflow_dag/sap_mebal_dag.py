"""
SAP Month End Balance (MEBAL) download DAGs.

Two DAGs:
  1. sap_mebal_current_month  — downloads current fiscal period
  2. sap_mebal_previous_month — downloads previous fiscal period

Both run every 6 hours via KubernetesPodOperator (lightweight Python pod,
NOT Spark — this is HTTP download, not distributed compute).

Entry point: sap_odata_standalone.py → 5 sequential steps:
  SapOdataDownload → ConsolidateFiles → CompressFiles → CreateCTLFile → DeliverFiles

Phase 134-K (audit SERIOUS #4) — legacy file mode no longer renders
SAP credentials into ``env_vars`` (which Airflow bakes into the pod
spec YAML — visible to anyone with namespace read).  Instead, when
``sap_mebal_secret_name`` Airflow Variable is set, we mount the named
Kubernetes Secret into the pod's env so SAP_USERNAME / SAP_PASSWORD
come from kubectl-protected storage.  DB-driven mode (the preferred
path) keeps using zero env_vars.
"""
import logging
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import (
    KubernetesPodOperator,
)

logger = logging.getLogger(__name__)

# ── Shared configuration ────────────────────────────────────────────────

SAP_MEBAL_IMAGE = Variable.get(
    "sap_mebal_image",
    default_var="registry.company.com/etl/sap-odata:latest",
)
SAP_MEBAL_NAMESPACE = Variable.get(
    "sap_mebal_namespace",
    default_var="etl-jobs",
)
ORACLE_CONFIG_PATH = Variable.get(
    "sap_mebal_oracle_config",
    default_var="/usr/local/spark/pvc/code/db.yaml",
)
SUPPORT_EMAIL = Variable.get(
    "sap_mebal_email",
    default_var="etl-support@company.com",
)

# 2026-06-03 — strict oracle_standalone parity.  Polling-row identity
# is the only per-run input the standalone takes: FK_REPORT_ID + the
# business date + FK_DAG_ID drive the polling query, and every other
# per-run knob (P_GJAHR / P_POPER / RUN_TIMESTAMP / NUM_GROUPS / SAPU /
# SAPP / SAP_*_API URLs) lives on the row itself.  Two Airflow
# Variables pin the report + dag identity; business_date is Airflow's
# {{ ds }} (UTC).
SAP_MEBAL_REPORT_ID = Variable.get("sap_mebal_report_id", default_var="0")
SAP_MEBAL_FK_DAG_ID_CURRENT = Variable.get(
    "sap_mebal_fk_dag_id_current",
    default_var="SAP_MEBAL_CURRENT",
)
SAP_MEBAL_FK_DAG_ID_PREVIOUS = Variable.get(
    "sap_mebal_fk_dag_id_previous",
    default_var="SAP_MEBAL_PREVIOUS",
)

# Phase 134-K (audit SERIOUS #4) — name of the Kubernetes Secret in
# SAP_MEBAL_NAMESPACE that holds SAP_USERNAME + SAP_PASSWORD keys.
# Kept as defense-in-depth for any environment where the polling row
# leaves SAPU/SAPP NULL (e.g. early rollout).  Setting this to "" is
# fine in production — SAPU/SAPP on the row win.
SAP_MEBAL_SECRET_NAME = Variable.get(
    "sap_mebal_secret_name",
    default_var="",
)


def _get_default_args() -> dict:
    return {
        'owner': Variable.get("dag_owner", default_var="Output Gateway"),
        'depends_on_past': False,
        'start_date': datetime(2025, 7, 14),
        'retries': 1,
        'retry_delay': timedelta(minutes=10),
        'email_on_failure': True,
        'email': [e.strip() for e in SUPPORT_EMAIL.split(',')],
    }


def _build_pod_operator(dag: DAG, period_mode: str) -> KubernetesPodOperator:
    """Build KubernetesPodOperator for SAP OData download.

    2026-06-03 — strict oracle_standalone.py parity.  Airflow triggers
    one pod per RUN_ID; the standalone takes only the three polling-
    query bind values (--report_id / --business_date / --dag_id) plus
    the oracle-connection YAML.  Every other per-run knob lives on
    the polling row (P_GJAHR / P_POPER / RUN_TIMESTAMP / NUM_GROUPS /
    SAPU / SAPP / SAP_*_API URLs).

    Phase 134-K (audit SERIOUS #4) — SAP_USERNAME / SAP_PASSWORD never
    go into ``env_vars`` (which Airflow bakes into the pod-spec YAML).
    When ``sap_mebal_secret_name`` Airflow Variable points at a
    Kubernetes Secret, we mount it via the ``secrets=[...]`` arg so
    the values land in the pod's env at runtime from kubectl-protected
    storage.  In the DB-driven flow SAPU/SAPP on the polling row are
    the primary credential source; the Secret mount is defense-in-depth.

    Set ``sap_mebal_secret_name`` to the name of a Secret in
    ``SAP_MEBAL_NAMESPACE``.  Default empty ⇒ standalone relies
    entirely on polling-row SAPU/SAPP.
    """
    from airflow.providers.cncf.kubernetes.secret import Secret

    secrets: list = []
    env_vars: dict = {}

    fk_dag_id = (
        SAP_MEBAL_FK_DAG_ID_PREVIOUS
        if period_mode == "previous"
        else SAP_MEBAL_FK_DAG_ID_CURRENT
    )
    args = [
        "sap_odata_standalone.py",
        "--report_id",     str(SAP_MEBAL_REPORT_ID),
        "--business_date", "{{ ds }}",         # Airflow execution date (UTC, YYYY-MM-DD)
        "--dag_id",        str(fk_dag_id),
        "--config_path",   ORACLE_CONFIG_PATH,
    ]
    # Creds come from the polling row's SAPU/SAPP columns.  Optional
    # K8s Secret mount below acts as fallback when the row leaves
    # them NULL — never as the primary path.
    secret_name = SAP_MEBAL_SECRET_NAME.strip()
    if secret_name:
        secrets = [
            Secret(
                deploy_type="env", deploy_target="SAP_USERNAME",
                secret=secret_name, key="SAP_USERNAME",
            ),
            Secret(
                deploy_type="env", deploy_target="SAP_PASSWORD",
                secret=secret_name, key="SAP_PASSWORD",
            ),
        ]
    else:
        logger.warning(
            "sap_mebal_dag: no sap_mebal_secret_name Airflow "
            "Variable — pod relies entirely on polling-row SAPU/SAPP "
            "columns for SAP credentials.  This is the production "
            "path; set sap_mebal_secret_name only if you need a "
            "K8s Secret fallback for rows that leave SAPU/SAPP NULL "
            "(audit SERIOUS #4 — never via env_vars Jinja)."
        )

    return KubernetesPodOperator(
        task_id=f"sap_mebal_{period_mode}",
        namespace=SAP_MEBAL_NAMESPACE,
        image=SAP_MEBAL_IMAGE,
        cmds=["python"],
        arguments=args,
        env_vars=env_vars,
        secrets=secrets,   # K8s Secret mount (audit SERIOUS #4)
        # NFS mount for output files + group history
        volumes=[],       # Configure via Airflow connections or Helm values
        volume_mounts=[],  # Mount NFS PVC for /usr/local/spark/nfs/bcp/batch/
        is_delete_operator_pod=True,
        get_logs=True,
        startup_timeout_seconds=300,
        dag=dag,
    )


# ═══════════════════════════════════════════════════════════════════════
#  DAG 1: Current month (every 6 hours)
# ═══════════════════════════════════════════════════════════════════════

current_dag = DAG(
    dag_id="sap_mebal_current_month",
    default_args=_get_default_args(),
    description="SAP MEBAL download — current fiscal period (every 6 hours)",
    schedule="0 */6 * * *",
    catchup=False,
    is_paused_upon_creation=True,
    tags=["etl", "sap", "mebal", "odata"],
    render_template_as_native_obj=True,
)

_build_pod_operator(current_dag, "current")
globals()["sap_mebal_current_month"] = current_dag


# ═══════════════════════════════════════════════════════════════════════
#  DAG 2: Previous month (every 6 hours)
# ═══════════════════════════════════════════════════════════════════════

previous_dag = DAG(
    dag_id="sap_mebal_previous_month",
    default_args=_get_default_args(),
    description="SAP MEBAL download — previous fiscal period (every 6 hours)",
    schedule="0 */6 * * *",
    catchup=False,
    is_paused_upon_creation=True,
    tags=["etl", "sap", "mebal", "odata"],
    render_template_as_native_obj=True,
)

_build_pod_operator(previous_dag, "previous")
globals()["sap_mebal_previous_month"] = previous_dag


logger.info("Created 2 SAP MEBAL DAGs: current_month + previous_month (6-hour schedule)")
