"""Phase 134-P — Airflow DAG for the s3_query pipeline.

Triggers ``s3_query_standalone.py`` inside the Spark container via
``SparkSubmitOperator``.  Same shape as the SparkSubmit task in
``parameterized_dags.py`` that runs ``oracle_standalone.py`` — only
the application script + DAG id change.

Two trigger modes
-----------------
1. **Entity trigger** (``s3_query_entity_runner``): Kafka / API drops
   a ``{"report_id": …, "business_date": …, "dag_id": …}`` payload
   into ``dag_run.conf`` and the DAG runs the Spark job once.
2. **Manual** via Airflow UI — same payload via the Params tab.

The standalone runner is fully polling-driven, so the DAG itself
stays a thin SparkSubmit shell — no per-entity config in this file.
All pipeline shape (which steps, in what SEQ) lives in
``Vw_otg_dag_task`` rows in Oracle.
"""
import logging
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.models.param import Param
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

logger = logging.getLogger(__name__)


# ── Configuration (Airflow Variables) ───────────────────────────────────

APPLICATION_PATH = Variable.get(
    "s3_query_application_path",
    default_var="/usr/local/spark/pvc/code/s3_query_standalone.py",
)
CONFIG_PATH = Variable.get(
    "s3_query_config_path",
    default_var="/usr/local/spark/pvc/code/configs/oracle_config.yaml",
)
SPARK_CONN_ID = Variable.get(
    "s3_query_spark_conn_id",
    default_var="spark_default",
)
SPARK_CONF_PATH = Variable.get(
    "s3_query_spark_conf_path",
    default_var="/usr/local/spark/pvc/code/configs/spark.properties",
)
SUPPORT_EMAIL = Variable.get(
    "s3_query_email",
    default_var="etl-support@company.com",
)


# ── Spark conf loader (mirrors parameterized_dags._get_spark_confs) ─────

def _get_spark_confs(spark_conf_path: str, delimiter: str = ":::") -> dict:
    """Read spark-submit ``--conf`` key/value pairs from a properties file.

    Mirrors ``parameterized_dags._get_spark_confs`` so both DAGs share
    the same conf baseline.  ``::`` -delimited (not standard ``=``) so
    spark-submit values can themselves contain ``=``.
    """
    spark_conf = {
        "spark.kubernetes.driverEnv.SPARK_DIST_CLASSPATH":   "/usr/local/spark/pvc/jars/*",
        "spark.kubernetes.executorEnv.SPARK_DIST_CLASSPATH": "/usr/local/spark/pvc/jars/*",
        "spark.kubernetes.driverEnv.PYTHONPATH":             "/usr/local/spark/pvc:/usr/local/spark/pvc/code",
        "spark.kubernetes.executorEnv.PYTHONPATH":           "/usr/local/spark/pvc:/usr/local/spark/pvc/code",
    }
    try:
        with open(spark_conf_path) as f:
            for line in f:
                line = line.strip()
                if line and delimiter in line:
                    key, value = line.split(delimiter, 1)
                    key, value = key.strip(), value.strip()
                    if key not in spark_conf:
                        spark_conf[key] = value
    except Exception as exc:
        logger.error(
            "Error reading spark properties from %s: %s", spark_conf_path, exc,
        )
    return spark_conf


# ── DAG definition ──────────────────────────────────────────────────────

default_args = {
    "owner": Variable.get("dag_owner", default_var="Output Gateway"),
    "depends_on_past": False,
    "start_date": datetime(2026, 6, 1),
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
    "email_on_failure": True,
    "email": [e.strip() for e in SUPPORT_EMAIL.split(",")],
}


with DAG(
    dag_id="s3_query_entity_runner",
    default_args=default_args,
    description=(
        "Phase 134-P — runs s3_query_standalone.py via SparkSubmit.  "
        "Trigger via Kafka / API with dag_run.conf={report_id, "
        "business_date, dag_id} or manually with the Params tab."
    ),
    schedule_interval=None,             # trigger-only
    catchup=False,
    max_active_runs=int(Variable.get("s3_query_max_active_runs", default_var="3")),
    tags=["s3_query", "spark", "phase_134_p"],
    params={
        "report_id":      Param(0,   type="integer",
                                 description="FK_REPORT_ID for the run"),
        "business_date":  Param("",  type="string",
                                 description="Business date (DD-MM-YY or YYYY-MM-DD)"),
        "dag_id":         Param("",  type="string",
                                 description="FK_DAG_ID for the run"),
    },
) as dag:

    spark_conf = _get_spark_confs(SPARK_CONF_PATH)

    run_s3_query_standalone = SparkSubmitOperator(
        task_id="run_s3_query_standalone",
        application=APPLICATION_PATH,
        conn_id=SPARK_CONN_ID,
        application_args=[
            "--report_id",     "{{ dag_run.conf.get('report_id', params.report_id) }}",
            "--business_date", "{{ dag_run.conf.get('business_date', params.business_date) }}",
            "--dag_id",        "{{ dag_run.conf.get('dag_id', params.dag_id) }}",
            "--config_path",   CONFIG_PATH,
        ],
        conf=spark_conf,
        verbose=False,
    )
