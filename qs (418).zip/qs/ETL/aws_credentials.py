"""ETL AWS credential resolver -- same contract as QS API's
``backend/core/credential_resolver.py``.

2026-06-20 -- STRATEGIC: pre-fix, every ETL S3 job had literal
``s3_access_key`` / ``s3_secret_key`` strings in its per-job JSON.
Rotating creds meant updating N files; pod-identity / IAM-role-for-
service-account couldn't be used because ``_configure_s3a`` passed
empty strings to Spark and the connection failed silently.

This module mirrors the QS API credential_resolver.resolve_s3_credentials
shape so ETL operators see the SAME auth_mode contract:

  auth_mode = "keys"        -> credentials already in config (pass through)
              "iam_role"    -> boto3 default credential chain (EC2 instance
                                profile / EKS IRSA / ECS task role)
              "profile"     -> AWS CLI profile via boto3
              "assume_role" -> STS AssumeRole via boto3
              "env"         -> read from AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY
                                env vars (the pod's runtime env)

Field naming bridges ETL's legacy ``s3_*`` keys to the AWS-standard
names the resolver chain produces:
  ETL legacy           ->  AWS standard
  s3_access_key        ->  aws_access_key_id
  s3_secret_key        ->  aws_secret_access_key
  (none)               ->  aws_session_token
  s3_endpoint_url      ->  endpoint_url
  s3_path_style_access ->  path_style

Resolver writes BOTH sets so downstream Spark config + boto3 callers
work unchanged.

Operator surface:
  * Per-job JSON sets ``auth_mode`` once per connection
  * For "iam_role": leave s3_access_key/secret EMPTY; boto3 picks creds
    from the pod's IAM identity (EKS IRSA via service account annotation)
  * For "env": leave keys empty; resolver reads AWS_ACCESS_KEY_ID etc.
    from the pod's runtime env (set by helm secret)
  * For "keys" or unset: literal keys from JSON used as-is (back-compat)
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def resolve_s3_credentials(config: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve AWS credentials for an ETL S3 connection config.

    Always returns a COPY -- never mutates the input.  Returns a config
    with BOTH ETL-legacy ``s3_*`` keys AND AWS-standard ``aws_*`` keys
    populated so any downstream caller works unchanged.

    Resolution chain:
      1. ``auth_mode == "keys"`` (or any non-empty s3_access_key already
         present): pass through unchanged.
      2. ``auth_mode == "env"``: read AWS_ACCESS_KEY_ID /
         AWS_SECRET_ACCESS_KEY / AWS_SESSION_TOKEN from env.
      3. ``auth_mode == "profile"``: boto3 Session with named profile
         (``aws_profile`` field on config).
      4. ``auth_mode == "iam_role"``: boto3 default credential chain.
         On EKS this picks up IRSA (IAM Role for Service Account) creds
         from the SA's web-identity token automatically.
      5. ``auth_mode == "assume_role"``: STS AssumeRole on a base
         session.  ``role_arn`` required.

    Never raises -- credential resolution failure logs WARN and returns
    the config with empty credential fields so Spark's connection
    attempt fails with a clear error message at use time rather than
    crashing the planner.
    """
    out = dict(config)
    auth_mode = (out.get("auth_mode") or "").lower().strip()

    # Existing legacy keys (always populate both spellings).
    legacy_ak = (out.get("s3_access_key") or "").strip()
    legacy_sk = (out.get("s3_secret_key") or "").strip()

    # Short-circuit: explicit keys + non-portal mode -> pass through.
    if legacy_ak and legacy_sk and auth_mode in ("", "keys"):
        out["aws_access_key_id"] = legacy_ak
        out["aws_secret_access_key"] = legacy_sk
        out["aws_session_token"] = (out.get("s3_session_token") or "").strip()
        out["auth_mode"] = "keys"
        _bridge_endpoint_fields(out)
        return out

    # ── ENV mode: read from pod's runtime env ─────────────────────────
    if auth_mode == "env":
        ak = (os.environ.get("AWS_ACCESS_KEY_ID") or "").strip()
        sk = (os.environ.get("AWS_SECRET_ACCESS_KEY") or "").strip()
        token = (os.environ.get("AWS_SESSION_TOKEN") or "").strip()
        if not ak or not sk:
            logger.warning(
                "[aws-cred] auth_mode='env' but AWS_ACCESS_KEY_ID / "
                "AWS_SECRET_ACCESS_KEY are not set in pod env -- S3 "
                "calls will fail.  Set them via helm secret or use "
                "auth_mode='iam_role' for EKS IRSA."
            )
        out["aws_access_key_id"] = ak
        out["aws_secret_access_key"] = sk
        out["aws_session_token"] = token
        out["s3_access_key"] = ak
        out["s3_secret_key"] = sk
        out["auth_mode"] = "keys"
        _bridge_endpoint_fields(out)
        if ak:
            logger.info(
                "[aws-cred] Resolved via env vars "
                "(AWS_ACCESS_KEY_ID set, token=%s)",
                "yes" if token else "no",
            )
        return out

    # ── PROFILE / IAM_ROLE: boto3 credential chain ────────────────────
    if auth_mode in ("profile", "iam_role"):
        try:
            return _resolve_via_boto3(out, auth_mode)
        except Exception as exc:
            logger.warning(
                "[aws-cred] boto3 %s resolution failed: %s -- returning "
                "config with empty credentials (Spark will fail at use).",
                auth_mode, exc,
            )
            return out

    # ── ASSUME_ROLE: STS AssumeRole ────────────────────────────────────
    if auth_mode == "assume_role":
        try:
            return _resolve_assume_role(out)
        except Exception as exc:
            logger.warning(
                "[aws-cred] AssumeRole failed: %s -- returning config "
                "with empty credentials.", exc,
            )
            return out

    # ── Unset / unknown mode: pass through whatever was given ─────────
    # Also bridge any legacy fields that ARE set.
    if legacy_ak:
        out["aws_access_key_id"] = legacy_ak
    if legacy_sk:
        out["aws_secret_access_key"] = legacy_sk
    _bridge_endpoint_fields(out)
    if not legacy_ak and not legacy_sk and not auth_mode:
        logger.info(
            "[aws-cred] No auth_mode + no legacy keys -- attempting "
            "boto3 default chain (IRSA / instance profile / env) as "
            "last resort.  Set auth_mode='keys' to silence this."
        )
        try:
            return _resolve_via_boto3(out, "iam_role")
        except Exception as exc:
            logger.warning(
                "[aws-cred] Default-chain fallback failed: %s -- "
                "returning config with empty credentials.", exc,
            )
    return out


def _resolve_via_boto3(config: Dict[str, Any], auth_mode: str) -> Dict[str, Any]:
    """Use boto3 Session to resolve credentials via profile or default
    credential chain (IRSA / instance profile / env)."""
    import boto3
    out = dict(config)

    region = out.get("region_name") or out.get("region") or os.environ.get("AWS_REGION") or "us-east-1"
    profile = out.get("aws_profile") if auth_mode == "profile" else None
    session = boto3.Session(profile_name=profile, region_name=region)

    creds = session.get_credentials()
    if creds is None:
        raise ValueError(
            f"boto3 Session returned no credentials for auth_mode={auth_mode!r} "
            f"(profile={profile!r}, region={region!r})"
        )
    frozen = creds.get_frozen_credentials()
    if not frozen.access_key:
        raise ValueError(
            f"boto3 default chain returned empty access_key for "
            f"auth_mode={auth_mode!r}"
        )

    out["aws_access_key_id"] = frozen.access_key
    out["aws_secret_access_key"] = frozen.secret_key or ""
    out["aws_session_token"] = frozen.token or ""
    # Mirror into ETL-legacy field names so Spark builder picks them up.
    out["s3_access_key"] = frozen.access_key
    out["s3_secret_key"] = frozen.secret_key or ""
    out["s3_session_token"] = frozen.token or ""
    out["auth_mode"] = "keys"
    out["region_name"] = region
    _bridge_endpoint_fields(out)
    logger.info(
        "[aws-cred] Resolved via boto3 %s (region=%s, profile=%s, "
        "session_token=%s)",
        auth_mode, region, profile or "(default)",
        "yes" if frozen.token else "no",
    )
    return out


def _resolve_assume_role(config: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve credentials via STS AssumeRole.  Mirrors the QS API
    pattern -- base session built from ``aws_profile`` (if set) or the
    default chain, then STS.assume_role with ``role_arn``."""
    import boto3
    out = dict(config)

    role_arn = out.get("role_arn")
    if not role_arn:
        raise ValueError("role_arn required for assume_role auth mode")

    region = out.get("region_name") or out.get("region") or "us-east-1"
    session_name = out.get("role_session_name") or "etl-standalone"

    base_session = boto3.Session(
        profile_name=out.get("aws_profile") or None,
        region_name=region,
    )
    sts = base_session.client("sts")
    resp = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName=session_name,
        DurationSeconds=int(out.get("session_duration_seconds") or 3600),
    )
    creds = resp["Credentials"]
    out["aws_access_key_id"] = creds["AccessKeyId"]
    out["aws_secret_access_key"] = creds["SecretAccessKey"]
    out["aws_session_token"] = creds["SessionToken"]
    out["s3_access_key"] = creds["AccessKeyId"]
    out["s3_secret_key"] = creds["SecretAccessKey"]
    out["s3_session_token"] = creds["SessionToken"]
    out["auth_mode"] = "keys"
    out["region_name"] = region
    _bridge_endpoint_fields(out)
    logger.info(
        "[aws-cred] Resolved via STS AssumeRole (role=%s, region=%s, "
        "expiry=%s)",
        role_arn, region, creds.get("Expiration"),
    )
    return out


def _bridge_endpoint_fields(config: Dict[str, Any]) -> None:
    """Populate AWS-standard endpoint / path-style fields from ETL legacy
    names so downstream boto3 / Spark consumers see consistent shape."""
    if config.get("s3_endpoint_url") and not config.get("endpoint_url"):
        config["endpoint_url"] = config["s3_endpoint_url"]
    if "s3_path_style_access" in config and "path_style" not in config:
        config["path_style"] = bool(config["s3_path_style_access"])
