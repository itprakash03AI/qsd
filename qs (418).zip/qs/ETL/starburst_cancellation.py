"""Cross-thread cancellation propagation for Starburst-related steps.

2026-06-12 — when the polling service times out a run (or the operator
forces a shutdown) the underlying step is typically mid-``cursor.execute()``
or mid-``df.write.jdbc(...)``.  asyncio cancellation does NOT propagate
to native threads or to a JVM Spark job — without an explicit cancel
the query keeps running on Starburst, holding cluster slots indefinitely
after the client has given up.

Both client-side cancel APIs we need are thread-safe and quick:

  * ``trino.dbapi.Cursor.cancel()`` — issues ``DELETE /v1/statement/<id>``
    to the Trino coordinator.  Coordinator marks the query CANCELLED;
    the blocked ``fetchmany`` on the step's thread raises an error and
    finally-cleanup runs.
  * ``pyspark.SparkContext.cancelJobGroup(group_id)`` — sends a
    cancellation signal to every executor task in the group.  The
    ``setJobGroup(..., interruptOnCancel=True)`` flag set at submit
    time then raises ``TaskKilledException`` inside the JVM, which the
    Python step receives as a ``Py4JJavaError`` (caught + propagated).

The lifecycle is REGISTER -> EXECUTE -> UNREGISTER (success) OR
CANCEL_ALL (timeout / shutdown).  The runner that wraps the step in
``asyncio.wait_for`` reads the registry on TimeoutError /
CancelledError and fires every handle BEFORE re-raising.

CONTRACT for callers (steps):
  1. Build a ``StarburstCancellable`` describing the underlying handle.
  2. ``register_starburst_cancellable(task, handle)`` BEFORE submitting
     the long-running call (``cursor.execute`` / ``df.write.jdbc``).
  3. On normal completion, ``unregister_starburst_cancellable(task, handle)``
     in the ``finally`` block.
  4. Forget about cancel during normal execution — the runner handles it.

CONTRACT for callers (runners):
  On asyncio.CancelledError / asyncio.TimeoutError, call
  ``cancel_all_starburst(task, logger)`` for every task in the run
  BEFORE re-raising.  Safe to call multiple times.  Empty registry
  (no Starburst step ran yet) is a no-op.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

_logger = logging.getLogger("starburst_cancellation")

_TASK_KEY = "_starburst_resources"

# Supported handle kinds.
KIND_TRINO_CURSOR = "trino_cursor"
KIND_SPARK_JOB_GROUP = "spark_job_group"


class StarburstCancellable:
    """A typed handle on a cancellable Starburst-side resource.

    Two kinds are supported today; new kinds extend ``cancel()`` with
    one more elif branch.

    For ``trino_cursor``:
        StarburstCancellable(KIND_TRINO_CURSOR, cursor=<trino cursor>)
        cancel() calls cursor.cancel() then cursor.close().

    For ``spark_job_group``:
        StarburstCancellable(KIND_SPARK_JOB_GROUP, spark=<SparkSession>,
                             group_id=<unique str>)
        cancel() calls spark.sparkContext.cancelJobGroup(group_id).
        Caller is responsible for setJobGroup(... interruptOnCancel=True)
        BEFORE the long-running call so the cancel actually interrupts.
    """

    __slots__ = ("kind", "_payload", "_cancelled", "label")

    def __init__(self, kind: str, *, label: str = "", **payload: Any) -> None:
        self.kind = kind
        self._payload = payload
        self._cancelled = False
        self.label = label or kind

    def cancel(self, logger: Optional[logging.Logger] = None) -> bool:
        """Fire the cancel.  Idempotent — second call is a no-op.

        Returns True if cancel was attempted (regardless of underlying
        success), False if already cancelled.  Underlying exceptions
        are caught + logged at WARN — cancellation must never crash
        the runner's shutdown path.
        """
        if self._cancelled:
            return False
        self._cancelled = True
        log = logger or _logger
        try:
            if self.kind == KIND_TRINO_CURSOR:
                cursor = self._payload.get("cursor")
                if cursor is not None:
                    try:
                        cursor.cancel()
                    except Exception as exc:
                        log.warning(
                            "StarburstCancellable[%s].cursor.cancel() raised: %s",
                            self.label, exc,
                        )
                    try:
                        cursor.close()
                    except Exception as exc:
                        log.warning(
                            "StarburstCancellable[%s].cursor.close() raised: %s",
                            self.label, exc,
                        )
            elif self.kind == KIND_SPARK_JOB_GROUP:
                spark = self._payload.get("spark")
                group_id = self._payload.get("group_id")
                if spark is not None and group_id:
                    try:
                        spark.sparkContext.cancelJobGroup(group_id)
                    except Exception as exc:
                        log.warning(
                            "StarburstCancellable[%s].cancelJobGroup(%s) raised: %s",
                            self.label, group_id, exc,
                        )
            else:
                log.warning(
                    "StarburstCancellable[%s] unknown kind %r — nothing to cancel",
                    self.label, self.kind,
                )
        except Exception as exc:
            log.warning(
                "StarburstCancellable[%s].cancel(): unexpected %r",
                self.label, exc,
            )
        return True


def register_starburst_cancellable(
    task: Dict[str, Any], cancellable: StarburstCancellable,
) -> None:
    """Add ``cancellable`` to the task's resource list.

    Idempotent on the same instance.  Safe to call from any thread —
    the resource list is a plain Python list and the asyncio runner
    only iterates it from the event-loop thread.  (Iteration uses a
    snapshot copy in ``cancel_all_starburst`` to avoid races with
    concurrent unregister calls.)
    """
    resources = task.setdefault(_TASK_KEY, [])
    if cancellable not in resources:
        resources.append(cancellable)


def unregister_starburst_cancellable(
    task: Dict[str, Any], cancellable: StarburstCancellable,
) -> None:
    """Remove ``cancellable`` after normal cleanup.  Silent if absent."""
    resources = task.get(_TASK_KEY)
    if not resources:
        return
    try:
        resources.remove(cancellable)
    except ValueError:
        pass


def cancel_all_starburst(
    task: Dict[str, Any], logger: Optional[logging.Logger] = None,
) -> int:
    """Fire ``cancel()`` on every registered Starburst handle.

    Called by runners on ``asyncio.TimeoutError`` /
    ``asyncio.CancelledError`` BEFORE re-raising so the in-flight
    Starburst query is told to stop server-side.

    Returns the number of handles cancelled (for logging).  Safe to
    call multiple times; cancellables are idempotent.  An empty
    registry is a no-op.
    """
    log = logger or _logger
    resources = task.get(_TASK_KEY)
    if not resources:
        return 0
    # Iterate a snapshot so concurrent step unregister doesn't trip us.
    snapshot: List[StarburstCancellable] = list(resources)
    fired = 0
    for handle in snapshot:
        try:
            if handle.cancel(logger=log):
                fired += 1
        except Exception as exc:  # pragma: no cover — handle.cancel swallows
            log.warning(
                "cancel_all_starburst: %s.cancel() raised: %s",
                getattr(handle, "label", "?"), exc,
            )
    if fired:
        log.warning(
            "cancel_all_starburst: cancelled %d Starburst handle(s)", fired,
        )
    return fired
