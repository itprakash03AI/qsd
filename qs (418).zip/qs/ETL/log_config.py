"""ETL runtime-path resolution — one source of truth across the codebase.

Two resolvers live here:

  * ``get_log_dir()``  — where logs are written.
  * ``get_data_root()`` — where pipeline data (group_history.json,
    output_dir defaults, …) lives.

Both use the same priority chain:
  1. Env var override  (``ETL_LOG_DIR`` / ``ETL_DATA_ROOT``).  Highest
     priority so an operator can force a path without touching config.
  2. YAML config value at ``$ETL_LOG_CONFIG_PATH`` or, when that env
     var is unset, ``ETL/config/polling_service_config.yaml`` next to
     this module (``logging.dir`` / ``data.root``).
  3. Platform-aware default:
       * POSIX  → the existing PVC mount path (``/usr/local/spark/nfs/...``)
                  — every K8s pod has this mounted, so prod is untouched.
       * Windows → ``ETL/_runtime/...`` next to this module.  Lets
                   local dev runs work with zero env / config setup.

Results are cached process-wide so a tick that spans the standalone +
manager + steps writes all logs / data to the same directory.

Tests call ``reset_for_tests()`` to clear the cache between cases.
"""
from __future__ import annotations
import os
from typing import Optional


_HERE = os.path.dirname(os.path.abspath(__file__))
_POSIX_LOG_PATH = "/usr/local/spark/nfs/bcp/batch/logs"
_POSIX_DATA_ROOT = "/usr/local/spark/nfs/bcp/batch"
_WIN_LOG_PATH = os.path.join(_HERE, "_runtime", "logs")
_WIN_DATA_ROOT = os.path.join(_HERE, "_runtime")

_RESOLVED_LOG: Optional[str] = None
_RESOLVED_DATA: Optional[str] = None


def _platform_default_log_dir() -> str:
    return _WIN_LOG_PATH if os.name == "nt" else _POSIX_LOG_PATH


def _platform_default_data_root() -> str:
    return _WIN_DATA_ROOT if os.name == "nt" else _POSIX_DATA_ROOT


def _read_yaml_key(env_key: str, *path: str) -> Optional[str]:
    """Read a nested key from polling_service_config.yaml (or the file
    pointed at by ``ETL_LOG_CONFIG_PATH``)."""
    cfg_path = os.environ.get("ETL_LOG_CONFIG_PATH", "").strip()
    if not cfg_path:
        cfg_path = os.path.join(_HERE, "config", "polling_service_config.yaml")
    if not os.path.exists(cfg_path):
        return None
    try:
        import yaml
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except Exception:
        return None
    node = cfg
    for key in path:
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    if isinstance(node, str) and node.strip():
        return node.strip()
    return None


def get_log_dir() -> str:
    """Return the resolved ETL log directory; cache result process-wide."""
    global _RESOLVED_LOG
    if _RESOLVED_LOG is not None:
        return _RESOLVED_LOG

    env = os.environ.get("ETL_LOG_DIR", "").strip()
    if env:
        _RESOLVED_LOG = env
        return _RESOLVED_LOG

    yaml_val = _read_yaml_key("ETL_LOG_DIR", "logging", "dir")
    # Skip the legacy POSIX placeholder so Windows runs don't try to
    # create ``/usr/local/...``; an operator who genuinely wants a
    # POSIX path on Windows can still force it via the env var.
    if yaml_val and yaml_val != _POSIX_LOG_PATH:
        _RESOLVED_LOG = yaml_val
        return _RESOLVED_LOG

    _RESOLVED_LOG = _platform_default_log_dir()
    return _RESOLVED_LOG


def get_data_root() -> str:
    """Return the resolved ETL data root; cache result process-wide.

    Used by steps that need a deployment-aware base directory for
    pipeline state (e.g. ``group_history.json``).  Falls back to the
    POSIX PVC mount on Linux and a repo-relative ``_runtime/`` dir on
    Windows.
    """
    global _RESOLVED_DATA
    if _RESOLVED_DATA is not None:
        return _RESOLVED_DATA

    env = os.environ.get("ETL_DATA_ROOT", "").strip()
    if env:
        _RESOLVED_DATA = env
        return _RESOLVED_DATA

    yaml_val = _read_yaml_key("ETL_DATA_ROOT", "data", "root")
    if yaml_val and yaml_val != _POSIX_DATA_ROOT:
        _RESOLVED_DATA = yaml_val
        return _RESOLVED_DATA

    _RESOLVED_DATA = _platform_default_data_root()
    return _RESOLVED_DATA


def reset_for_tests() -> None:
    """Clear the caches so the next ``get_*`` call re-resolves.

    Only call from tests — production code should rely on the cache.
    """
    global _RESOLVED_LOG, _RESOLVED_DATA, _RUN_LOG_FILE
    _RESOLVED_LOG = None
    _RESOLVED_DATA = None
    _RUN_LOG_FILE = None


# ──────────────────────────────────────────────────────────────────────
#  Single-file-per-execution logging
# ──────────────────────────────────────────────────────────────────────

import logging as _logging
from datetime import datetime as _datetime


# When set (via ``set_run_log_file``), every ``build_module_logger``
# call attaches to THIS exact file instead of building a date-stamped
# per-module file.  Lets the standalone collect oracle_metadata_manager
# / step_executor / step / base logs all into one batch log.
_RUN_LOG_FILE: Optional[str] = None


def set_run_log_file(path: str) -> None:
    """Pin the log file path for this entire run.

    Call from the standalone after ``_build_log_file`` so every module
    that later imports + uses ``build_module_logger`` writes to the
    SAME file.  Without this, each module would land in its own
    date-stamped file and a post-mortem would require greping N files.

    Passing an empty string clears the pin (next ``build_module_logger``
    call goes back to per-module date-stamped files).
    """
    global _RUN_LOG_FILE
    _RUN_LOG_FILE = path or None


def get_run_log_file() -> Optional[str]:
    """Return the pinned run-log-file path, or None when unpinned."""
    return _RUN_LOG_FILE


def build_module_logger(name: str, file_stem: str) -> "_logging.Logger":
    """Build a stdlib logger.

    Output file selection:
      * If ``set_run_log_file(path)`` was called → write to that path.
      * Otherwise → ``<log_dir>/<file_stem>_YYYY-MM-DD.log``.

    Windows-safe by design — uses ``logging.FileHandler`` (no rotation,
    no rename).  CentralizedLogger from core_libs (rotating handler) is
    NOT used because Windows refuses to rename an open file, so
    ``doRollover`` fails with ``PermissionError [WinError 32]``.

    On POSIX, stdlib FileHandler is still fine — pods are short-lived
    enough that no-rotation works.  If long-running rotation is needed
    on POSIX, route logs through a sidecar / fluentd / loki collector.

    Use this instead of hand-rolling logger setup in every module so
    all loggers honour the same path-resolution chain
    (``ETL_LOG_DIR`` → YAML → platform default) AND the single-file
    pin.
    """
    log_path = _RUN_LOG_FILE or os.path.join(
        get_log_dir(),
        f"{file_stem}_{_datetime.now().strftime('%Y-%m-%d')}.log",
    )

    logger = _logging.getLogger(name)
    if logger.handlers:
        # Already configured (e.g. by an earlier call in the same
        # process).  Return as-is so we don't duplicate handlers.
        return logger

    logger.setLevel(_logging.INFO)
    fmt = _logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
    )

    sh = _logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    try:
        os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
        fh = _logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError as exc:
        logger.warning(
            "build_module_logger(%s): could not open %s (%s) — "
            "console-only", name, log_path, exc,
        )

    return logger
