"""Back-compat shim -- 2026-06-22.

Module renamed to ``workers.s3_worker`` to match its content (the
file used to be the only home for ``S3QueryWorker``; today it hosts
``S3ToFileWorker`` / ``S3ToOracleWorker`` as well).  All names re-
exported here so existing ``from workers.s3_query_worker import ...``
imports keep working.

New code should ``from workers.s3_worker import S3ToFileWorker`` etc.
"""
from workers.s3_worker import (  # noqa: F401
    S3WorkflowWorker,
    S3ToFileWorker,
    S3ToOracleWorker,
    S3QueryWorker,
)
