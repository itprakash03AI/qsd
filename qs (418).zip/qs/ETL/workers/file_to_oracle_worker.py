"""FileToOracleWorker — worker for the File→Oracle workflow.

Mirrors the FileWorker shape but loads the ``file_to_oracle`` block
from step_mapping.yaml.  No CentralizedLogger; logs go to whichever
path ``log_config.set_run_log_file()`` the standalone pinned.
"""
from __future__ import annotations

import importlib
import logging
import os
from typing import Any, Callable, Dict

import yaml

from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor
from managers.oracle_metadata_manager import OracleMetadataManager


class FileToOracleWorker(BaseWorker):
    """Worker for the ``file_to_oracle`` workflow."""

    WORKFLOW = "file_to_oracle"

    def __init__(
        self,
        oracle_data_manager: OracleMetadataManager,
        logger: logging.Logger,
        load_config: Dict[str, Any] = None,
    ):
        # Spark JDBC loaders don't carry Starburst clients — empty dict
        # satisfies the BaseWorker signature without leaking concerns.
        super().__init__({}, oracle_data_manager, logger)
        self.load_config = load_config or {}
        self.logger.info("FileToOracleWorker init: load_config=%s", self.load_config)
        self.step_mapping = self._load_step_mapping(self.WORKFLOW)

    def _load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        prod_path = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"
        local_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "configs", "step_mapping.yaml",
        )
        mapping_path = prod_path if os.path.exists(prod_path) else local_path
        if not os.path.exists(mapping_path):
            raise FileNotFoundError(
                f"Step mapping not found: tried {prod_path} and {local_path}"
            )
        with open(mapping_path, "r", encoding="utf-8") as f:
            mappings = yaml.safe_load(f) or {}
        if workflow not in mappings:
            raise ValueError(f"No mapping for workflow '{workflow}' in {mapping_path}")

        step_mapping: Dict[str, Callable] = {}
        for step_name, details in mappings[workflow].items():
            module_path = details.get("module")
            class_name = details.get("class")
            if not module_path or not class_name:
                self.logger.warning(
                    "Skipping step '%s' — missing module/class in yaml", step_name,
                )
                continue
            try:
                module = importlib.import_module(module_path)
                step_class = getattr(module, class_name)
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as exc:
                self.logger.warning(
                    "Step '%s' not loadable from %s.%s: %s",
                    step_name, module_path, class_name, exc,
                )
        self.logger.info(
            "FileToOracleWorker loaded %d step(s) for workflow '%s': %s",
            len(step_mapping), workflow, sorted(step_mapping.keys()),
        )
        return step_mapping

    async def execute_step(
        self,
        task: Dict[str, Any],
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
    ) -> Any:
        task_id = task.get("run_id")
        if not all([task_id, worker_connection_string, dest_connection_string, step_name]):
            raise ValueError(
                "FileToOracleWorker.execute_step: run_id, worker_connection_string, "
                "dest_connection_string, and step_name are required"
            )
        if step_name not in self.step_mapping:
            raise ValueError(
                f"Unsupported step name '{step_name}' — available: "
                f"{sorted(self.step_mapping.keys())}"
            )
        step_class = self.step_mapping[step_name]
        executor = StepExecutor(self, self.logger)
        self.logger.info(
            "FileToOracleWorker dispatch: step='%s' run_id=%s run_detail_id=%s "
            "report_id=%s seq=%s",
            step_name, task_id, task.get("run_detail_id"),
            task.get("fk_report_id"), task.get("seq"),
        )
        return await executor.execute_step(
            step_class, task, worker_connection_string, dest_connection_string, step_name,
            event_id=str(task.get("seq", 0)),
            dag_run_id=task.get("dag_run_id", f"run_{task_id}"),
            fk_report_id=task.get("fk_report_id"),
        )
