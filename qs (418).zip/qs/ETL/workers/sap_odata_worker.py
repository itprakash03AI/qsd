"""
Worker for SAP OData pipeline steps.
Extends BaseWorker — no Starburst/Spark dependencies.
Loads step mapping from 'sap_odata' workflow in step_mapping.yaml.
"""
import importlib
import logging
import os
import yaml
from typing import Any, Callable, Dict

from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor


logger = logging.getLogger(__name__)


class SapOdataWorker(BaseWorker):
    """Worker for SAP OData pipeline workflows."""

    def __init__(self, oracle_data_manager: Any, logger: logging.Logger = None):
        super().__init__(
            starburst_clients={},
            oracle_data_manager=oracle_data_manager,
            logger=logger,
        )
        self.step_mapping = self.load_step_mapping('sap_odata')

    def load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        """Load step mapping from YAML and dynamically import classes.

        Looks at the prod (pod) path first; falls back to the in-repo
        ``ETL/configs/step_mapping.yaml`` so local Windows runs work
        without a /usr/local/... mount.
        """
        prod_path = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"
        local_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "configs", "step_mapping.yaml",
        )
        mapping_path = prod_path if os.path.exists(prod_path) else local_path
        if not os.path.exists(mapping_path):
            raise FileNotFoundError(
                f"Step mapping file not found: tried {prod_path} and {local_path}"
            )
        with open(mapping_path, "r") as f:
            mappings = yaml.safe_load(f)
        if workflow not in mappings:
            raise ValueError(f"No mapping found for workflow: {workflow}")

        step_mapping = {}
        for step_name, details in mappings[workflow].items():
            try:
                module = importlib.import_module(details["module"])
                step_class = getattr(module, details["class"])
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as e:
                self.logger.warning(f"Step {step_name} not available: {e}")

        self.logger.info(f"Loaded step mapping for {workflow}: {list(step_mapping.keys())}")
        return step_mapping

    async def execute_step(self, task: Dict, worker_connection_string: str,
                           dest_connection_string: str, step_name: str) -> None:
        """Execute a single pipeline step (no retry — fail fast)."""
        task_id = task.get("run_id")
        self.logger.info(f"Executing step {step_name} for task {task_id}")

        if step_name not in self.step_mapping:
            raise ValueError(f"Unsupported step name: {step_name}")

        step_class = self.step_mapping[step_name]
        step_executor = StepExecutor(self, self.logger)

        await step_executor.execute_step(
            step_class, task, worker_connection_string, dest_connection_string,
            step_name, event_id=str(task.get("seq", 0)),
            dag_run_id=task.get("dag_run_id", f"run_{task.get('run_id', 'unknown')}"),
            fk_report_id=task.get("fk_report_id"),
        )
