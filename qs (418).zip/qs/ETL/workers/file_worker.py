"""FileWorker — worker for the Starburst-to-file workflow.

Mirrors the workflow-agnostic shape used by SapOdataWorker /
OracleWorker / S3QueryWorker.

Loads its step mapping from the ``file`` block of
``step_mapping.yaml``.  No CentralizedLogger — log goes to whatever
``set_run_log_file()`` the standalone pinned (single-file-per-execution
contract).
"""
from __future__ import annotations

import importlib
import logging
import os
from typing import Any, Callable, Dict

import yaml

from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor
from managers.oracle_metadata_manager import OracleMetadataManager


class FileWorker(BaseWorker):
    """Worker for the ``file`` workflow."""

    WORKFLOW = "file"

    def __init__(
        self,
        starburst_clients: Dict[str, Any],
        oracle_data_manager: OracleMetadataManager,
        download_config: Dict[str, Any],
        logger: logging.Logger,
    ):
        super().__init__(starburst_clients, oracle_data_manager, logger)
        self.download_config = download_config or {}
        self.logger.info("FileWorker init: download_config=%s", self.download_config)
        self.step_mapping = self._load_step_mapping(self.WORKFLOW)

    # ----- step-mapping loader (workflow-agnostic) ---------------------

    def _load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        prod_path = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"
        local_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "configs", "step_mapping.yaml",
        )
        mapping_path = prod_path if os.path.exists(prod_path) else local_path
        if not os.path.exists(mapping_path):
            raise FileNotFoundError(
                f"Step mapping not found: tried {prod_path} and {local_path}"
            )
        with open(mapping_path, "r", encoding="utf-8") as f:
            mappings = yaml.safe_load(f) or {}
        if workflow not in mappings:
            raise ValueError(f"No mapping for workflow '{workflow}' in {mapping_path}")

        step_mapping: Dict[str, Callable] = {}
        for step_name, details in mappings[workflow].items():
            module_path = details.get("module")
            class_name = details.get("class")
            if not module_path or not class_name:
                self.logger.warning(
                    "Skipping step '%s' — missing module/class in yaml", step_name,
                )
                continue
            try:
                module = importlib.import_module(module_path)
                step_class = getattr(module, class_name)
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as exc:
                # Don't hard-fail — some steps (e.g. Spark variants) may
                # be optional on a non-Spark pod.  Log loudly so the
                # operator can spot the gap.
                self.logger.warning(
                    "Step '%s' not loadable from %s.%s: %s",
                    step_name, module_path, class_name, exc,
                )
        self.logger.info(
            "FileWorker loaded %d step(s) for workflow '%s': %s",
            len(step_mapping), workflow, sorted(step_mapping.keys()),
        )
        return step_mapping

    # ----- step dispatch ----------------------------------------------

    async def execute_step(
        self,
        task: Dict[str, Any],
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
    ) -> Any:
        """Execute a single step by name (called per polling row by the standalone)."""
        task_id = task.get("run_id")
        if not all([task_id, worker_connection_string, dest_connection_string, step_name]):
            raise ValueError(
                "FileWorker.execute_step: run_id, worker_connection_string, "
                "dest_connection_string, and step_name are required"
            )
        if step_name not in self.step_mapping:
            raise ValueError(
                f"Unsupported step name '{step_name}' — available: "
                f"{sorted(self.step_mapping.keys())}"
            )

        step_class = self.step_mapping[step_name]
        executor = StepExecutor(self, self.logger)

        self.logger.info(
            "FileWorker dispatch: step='%s' run_id=%s run_detail_id=%s dag_id=%s "
            "report_id=%s seq=%s",
            step_name, task_id, task.get("run_detail_id"),
            task.get("fk_dag_id"), task.get("fk_report_id"), task.get("seq"),
        )
        return await executor.execute_step(
            step_class, task, worker_connection_string, dest_connection_string, step_name,
            event_id=str(task.get("seq", 0)),
            dag_run_id=task.get("dag_run_id", f"run_{task_id}"),
            fk_report_id=task.get("fk_report_id"),
        )
