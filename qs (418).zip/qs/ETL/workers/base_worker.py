"""
Base worker class for ETL step execution.
Provides shared state (starburst_clients, oracle_data_manager, logger)
that step executors and step classes rely on.
"""
import logging
from typing import Dict, Any


class BaseWorker:
    """Base class for all ETL workers."""

    def __init__(
        self,
        starburst_clients: Dict[str, Any],
        oracle_data_manager: Any,
        logger: logging.Logger = None,
    ):
        self.starburst_clients = starburst_clients
        self.oracle_data_manager = oracle_data_manager
        self.logger = logger or logging.getLogger(__name__)
