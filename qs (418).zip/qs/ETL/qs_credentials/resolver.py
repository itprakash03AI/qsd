"""qs_credentials.resolver -- ETL facade for vault-backed credentials.

Translates yaml-driven secret_refs into vault calls (via the shared
chokepoint in qs_credentials.vault) + caches via QSCredCache.

Usage:
    from qs_credentials import resolve_db_account
    user, pw = resolve_db_account("dest_oracle")
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import yaml

# Relative import works in BOTH ETL containers (polling-service flat
# PYTHONPATH + sync-cron prefixed PYTHONPATH) since resolver.py is a
# package member.
from .cache import QSCredCache
from .vault import is_valid_vault_payload


_PROD_PATH = "/usr/local/spark/pvc/code/configs/vault_config.yaml"
_LOCAL_PATH = str(
    Path(__file__).resolve().parent / "configs" / "vault_config.yaml"
)

_logger = logging.getLogger("qs_credentials.resolver")


# ────────────────────────────────────────────────────────────────────────
#  Global enable/disable
# ────────────────────────────────────────────────────────────────────────


def is_vault_enabled(workflow_config: Optional[Dict[str, Any]] = None) -> bool:
    """Three-layer toggle for vault-based credential resolution.

    Resolution order (highest priority wins):

      1. ``ETL_USE_VAULT`` env var
         * "1" / "true" / "yes"  -> ON  (returns True immediately)
         * "0" / "false" / "no"  -> OFF (returns False immediately)
         * unset / blank          -> defer to layer 2

      2. Per-workflow override -- when ``workflow_config`` is supplied
         AND has a ``vault_enabled`` key with explicit true/false
         (NOT empty / None).  Each workflow's yaml can independently
         opt in or opt out -- e.g., set ``starburst.vault_enabled:
         false`` to keep using literal yaml even when global is on.

      3. Global yaml setting ``secrets.enabled`` in
         ``vault_config.yaml``.  Default false (dev-safe).

    Args:
      workflow_config: optional per-workflow yaml dict (e.g., what
        ``starburst_config_loader.load_shared_starburst_config()``
        returns).  Pass the inner workflow section, not the full yaml.
    """
    # Layer 1: env var (highest -- ops escape hatch)
    env = os.environ.get("ETL_USE_VAULT", "").strip().lower()
    if env in ("1", "true", "yes"):
        return True
    if env in ("0", "false", "no"):
        return False

    # Layer 2: per-workflow override
    if workflow_config is not None:
        wf_flag = workflow_config.get("vault_enabled")
        if wf_flag is not None and str(wf_flag).strip() != "":
            return str(wf_flag).strip().lower() in ("1", "true", "yes")

    # Layer 3: global yaml flag in vault_config.yaml
    return bool(_vault_settings().get("enabled", False))

# ────────────────────────────────────────────────────────────────────────
#  yaml loading
# ────────────────────────────────────────────────────────────────────────


def _load_vault_yaml() -> Dict[str, Any]:
    """Return the parsed ``secrets`` section of vault_config.yaml,
    or ``{}`` if absent / malformed."""
    for path in (_PROD_PATH, _LOCAL_PATH):
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            return data.get("secrets", {}) or {}
        except yaml.YAMLError as exc:
            _logger.warning(
                "vault_config.yaml at %s is malformed (%s) -- secret "
                "resolution will fail.", path, exc,
            )
            return {}
        except OSError as exc:
            _logger.warning(
                "Cannot read vault_config.yaml at %s (%s).", path, exc,
            )
            return {}
    return {}


@lru_cache(maxsize=1)
def _vault_settings() -> Dict[str, Any]:
    """Cached parse of the ``secrets.vault`` block (machine, token_method, ttl)."""
    secrets = _load_vault_yaml()
    return secrets.get("vault", {}) or {}


@lru_cache(maxsize=1)
def _secret_refs() -> Dict[str, Dict[str, Any]]:
    """Cached parse of the ``secrets.refs`` block."""
    secrets = _load_vault_yaml()
    return secrets.get("refs", {}) or {}


# ────────────────────────────────────────────────────────────────────────
#  Shared cache + retry/stale fallback (Phase 158 chokepoint)
# ────────────────────────────────────────────────────────────────────────


def _etl_disk_cache_settings() -> Dict[str, Any]:
    """Pod-specific settings provider for the shared QSCredCache.

    Read from ``vault_config.yaml -> secrets.vault.*`` -- ETL's own
    knobs.  Backend uses ``core.config.secrets.*`` for the same keys.
    """
    s = _vault_settings()
    return {
        "enabled": bool(s.get("disk_cache_enabled", True)),
        "path":    str(s.get("disk_cache_path", "/tmp/.etl_secrets.enc")),
        "ttl":     int(s.get("disk_cache_ttl_seconds", 86400) or 0),
        "key_env": str(s.get("disk_cache_key_env", "ETL_SECRETS_KEY")),
        "mem_ttl": int(s.get("cache_ttl_seconds", 900) or 0),
    }


# Pod-singleton instance of the shared cache.  Constructed lazily on
# first access so module import doesn't fail when ETL is loaded in
# import-only test contexts.
_cred_cache = QSCredCache(
    settings_provider=_etl_disk_cache_settings,
    plaintext_env_var="ETL_SECRETS_ALLOW_PLAINTEXT",
    logger=_logger,
)


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R4 -- periodic refresh daemon
# ────────────────────────────────────────────────────────────────────────
#
# Bounds the rotation propagation window.  The mem_ttl (default 15 min)
# already guarantees Vault rotations get picked up within 15 min on the
# happy path, but a hot secret that's continuously re-cached will never
# hit the natural TTL expiry.  This periodic invalidation forces a
# fresh fetch every ``ETL_CRED_REFRESH_HOURS`` hours (default 24h).
#
# Set ``ETL_CRED_REFRESH_HOURS=0`` to disable (tests, dev pods).
_REFRESH_HOURS = float(
    os.environ.get("ETL_CRED_REFRESH_HOURS", "24") or 24,
)
_cred_cache.start_periodic_refresh(
    _REFRESH_HOURS, name_hint="etl-cred-cache-refresh",
)


def reset_cache() -> None:
    """Drop yaml + secret caches (test hook)."""
    _vault_settings.cache_clear()
    _secret_refs.cache_clear()
    _cred_cache.reset_mem()


# Back-compat aliases -- existing call sites use these names.
def _cache_get(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_fresh(name)


def _mem_get_fresh(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_fresh(name)


def _mem_get_any(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_any(name)


def _cache_put(name: str, payload: Any, ttl_seconds: int) -> None:
    _cred_cache.mem_put(name, payload, ttl_seconds)


def invalidate(name: str) -> None:
    """Drop the cached entry for ``name`` -- call after an auth
    failure so the next resolve fetches a fresh secret."""
    _cred_cache.invalidate(name)


# ────────────────────────────────────────────────────────────────────────
#  Public API
# ────────────────────────────────────────────────────────────────────────


def _get_ref_config(name: str) -> Dict[str, Any]:
    """Look up the secret access config for ``name``; raise with
    actionable error when the name isn't registered."""
    refs = _secret_refs()
    if name not in refs:
        available = sorted(refs.keys())
        raise ValueError(
            f"secret_ref={name!r} not found in vault_config.yaml.\n"
            f"  Available refs: {available}\n"
            f"  Add an entry under configs/vault_config.yaml -> "
            f"secrets.refs.{name} with type / auth_url / role_name / "
            f"role_type / rotate_url / secret_url fields."
        )
    ref = refs[name]
    required = ("type", "auth_url", "role_name", "role_type", "secret_url")
    missing = [k for k in required if not ref.get(k)]
    if missing:
        raise ValueError(
            f"secret_ref={name!r} entry in vault_config.yaml is "
            f"missing required field(s) {missing}.  Fill in "
            f"configs/vault_config.yaml -> secrets.refs.{name}."
        )
    return ref


def _resolve_with_cache(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Any:
    """Cache-aware resolver -- single point of Vault traffic.

    Phase 158 (2026-06-26) -- delegates the cache + retry + stale
    fallback to the shared ``QSCredCache`` instance so this function
    only owns ETL-specific concerns (vault toggle, ref lookup,
    machine/token-method from yaml).

    Linear flow:
      1. vault enabled?  (env var > workflow yaml > global yaml)
                                          no  -> raise (operator bug)
      2. In-process cache fresh?          hit -> return
      3. Disk cache fresh?                hit -> warm memory + return
      4. Vault fetch (retry + stale-fallback inside ``fetch_with_fallback``)
    """
    if not is_vault_enabled(workflow_config):
        raise RuntimeError(
            f"secret_ref={name!r} requested but vault resolution is "
            f"DISABLED.  Three places control this:\n"
            f"  1. ETL_USE_VAULT env var (set '1' to force ON, "
            f"'0' to force OFF)\n"
            f"  2. per-workflow yaml: vault_enabled in starburst_config "
            f"/ oracle_config / s3_config\n"
            f"  3. global yaml: secrets.enabled in vault_config.yaml\n"
            f"For dev: leave all three unset/false; fill literal "
            f"user/password in yaml."
        )

    # Layer 1: in-process cache (only fresh entries)
    fresh = _cred_cache.mem_get_fresh(name)
    if fresh is not None:
        return fresh

    # Layer 2: disk cache (only fresh entries)
    disk_fresh = _cred_cache.disk_get_fresh(name)
    if disk_fresh is not None:
        ttl_proc = int(_etl_disk_cache_settings().get("mem_ttl", 0) or 0)
        _cred_cache.mem_put(name, disk_fresh, ttl_proc)
        return disk_fresh

    # Layer 3: Vault (retry + last-known-good inside QSCredCache)
    ref = _get_ref_config(name)
    vault_settings = _vault_settings()
    machine = (vault_settings.get("machine") or "tprd").lower()
    token_method = vault_settings.get("token_method", "JWT")
    return _cred_cache.fetch_with_fallback(
        name, ref, machine=machine, token_method=token_method,
    )


# Disk cache test-hook -- delegates to the shared instance.
def disk_cache_clear() -> None:
    """Wipe the disk cache file + sidecar key (test hook + manual
    rotation trigger).  Delegates to the shared QSCredCache."""
    _cred_cache.disk_clear()


# Back-compat aliases for any older caller / test that pokes the disk
# layer directly.  All forward to the shared QSCredCache instance.
def _disk_cache_get(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_fresh(name)


def _disk_cache_get_any(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_any(name)


def _disk_cache_put(name: str, payload: Any) -> None:
    _cred_cache.disk_put(name, payload)


def _disk_cache_settings() -> Dict[str, Any]:
    """Back-compat: returns the ETL settings dict (tests + old callers)."""
    return _etl_disk_cache_settings()


def _is_valid_payload(payload: Any, secret_type: str) -> bool:
    """Back-compat alias to the shared chokepoint validator."""
    return is_valid_vault_payload(payload, secret_type)


def resolve_db_account(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str]:
    """Fetch DB account creds via Vault (QSClient).

    Returns ``(user, password)``.  Used for Oracle DB schema creds.

    Args:
      name: secret_ref name registered in vault_config.yaml.
      workflow_config: per-workflow yaml dict for the vault_enabled
        flag check (e.g., the ``oracle`` section dict).
    """
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, (tuple, list)) and len(payload) >= 2:
        return str(payload[0]), str(payload[1])
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected (user, password) tuple, got {type(payload).__name__})."
    )


def resolve_db_account_with_tns(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str, str]:
    """Variant that also returns tns_alias."""
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, (tuple, list)) and len(payload) >= 3:
        return str(payload[0]), str(payload[1]), str(payload[2])
    if isinstance(payload, (tuple, list)) and len(payload) >= 2:
        return str(payload[0]), str(payload[1]), ""
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected (user, password, tns_alias) tuple, got {type(payload).__name__})."
    )


def resolve_ad_account(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str]:
    """Fetch AD account creds (e.g., Starburst service account)."""
    return resolve_db_account(name, workflow_config)


def resolve_kv_secret(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Fetch a kv-store secret (AWS keys, API tokens, ...)."""
    payload = _resolve_with_cache(name, workflow_config)
    if isinstance(payload, dict):
        return payload
    raise RuntimeError(
        f"secret_ref={name!r} returned unexpected payload shape "
        f"(expected dict for kv_secrets, got {type(payload).__name__})."
    )


def fill_creds_from_ref(
    config: Dict[str, Any],
    *,
    user_key: str,
    password_key: str,
    ref_key: str = "secret_ref",
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Helper for config loaders.

    If ``config[user_key]`` OR ``config[password_key]`` is blank AND
    ``config[ref_key]`` is set, resolve via vault and fill the blanks.
    Per-job literal values ALWAYS win when set -- vault only fills blanks.

    In-place mutation; returns the same dict for chaining.

    Raises ValueError when ref is set but resolution fails (operator
    sees the actionable Vault error).
    """
    log = logger or _logger
    user_val = config.get(user_key) or ""
    pass_val = config.get(password_key) or ""
    ref = (config.get(ref_key) or "").strip()

    if not ref:
        return config  # no vault ref -- literal values stand
    if user_val and pass_val:
        return config  # both filled in literal -- no need to hit vault

    try:
        user, password = resolve_db_account(ref)
    except (ValueError, RuntimeError) as exc:
        # Re-raise with context but don't swallow.
        raise

    if not user_val:
        config[user_key] = user
    if not pass_val:
        config[password_key] = password

    log.info(
        "Resolved secret_ref=%s via vault (filled %s%s%s)",
        ref,
        user_key if not user_val else "",
        ", " if not user_val and not pass_val else "",
        password_key if not pass_val else "",
    )
    return config


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R4 -- auth-failure refresh + retry helpers
# ────────────────────────────────────────────────────────────────────────


def refresh(
    name: str,
    workflow_config: Optional[Dict[str, Any]] = None,
) -> Any:
    """Drop the cached entry for ``name`` and re-resolve from Vault.

    Use this when an auth attempt with cached creds returned a
    password-failure error -- e.g., Oracle ORA-01017 (invalid
    user/password) or Starburst 401.  The cache may be holding a
    pre-rotation credential; this forces a fresh fetch.

    Returns the freshly-resolved payload (tuple for DB/AD, dict for
    kv).  Raises with the actionable cause if Vault is also down.
    """
    _cred_cache.invalidate(name)
    _logger.info(
        "qs_credentials.refresh: cache invalidated for secret_ref=%r "
        "(auth failure suspected) -- re-fetching from Vault.", name,
    )
    return _resolve_with_cache(name, workflow_config)


def resolve_with_auth_retry(
    name: str,
    auth_callable,
    *,
    workflow_config: Optional[Dict[str, Any]] = None,
    secret_type: str = "AD_accounts",
):
    """Resolve creds + call ``auth_callable(creds)``.  If the call
    raises (typical: driver auth failure), drop the cache + re-fetch
    fresh creds + retry ONCE.  Re-raises on the second failure.

    Apply rule: use this wrapper around DB driver / connector
    constructors so a rotated-password incident self-heals on the
    NEXT request rather than the next mem_ttl expiry (15 min default).

    Example::

        from qs_credentials import resolve_with_auth_retry

        def _open_oracle(creds):
            return oracledb.connect(
                user=creds[0], password=creds[1], dsn=tns,
            )

        conn = resolve_with_auth_retry(
            "dest_oracle", _open_oracle,
            secret_type="DB_accounts",
        )

    Args:
      name:           secret_ref name.
      auth_callable:  callable taking the resolved creds tuple/dict and
                      returning the authenticated object (connection,
                      client, ...) or raising on failure.
      workflow_config: per-workflow vault_enabled toggle dict.
      secret_type:    ``DB_accounts`` / ``AD_accounts`` (returns tuple)
                      or ``kv_secrets`` (returns dict).  Drives which
                      resolver function to call.

    Returns whatever ``auth_callable`` returns on success.
    Raises the second auth_callable exception when retry also fails.
    """
    def _resolve_one():
        if secret_type == "kv_secrets":
            return resolve_kv_secret(name, workflow_config)
        # default DB/AD shape
        if secret_type == "DB_accounts":
            payload = _resolve_with_cache(name, workflow_config)
            # Preserve tns_alias slot when present.
            if isinstance(payload, (tuple, list)):
                if len(payload) >= 3:
                    return (str(payload[0]), str(payload[1]),
                            str(payload[2]))
                if len(payload) >= 2:
                    return (str(payload[0]), str(payload[1]))
        return resolve_ad_account(name, workflow_config)

    creds = _resolve_one()
    try:
        return auth_callable(creds)
    except Exception as exc:
        # First failure -- could be auth (cached stale password) OR
        # something else (network, syntax, ...).  Either way we drop
        # the cache to be safe, re-fetch, retry ONCE.  If the cause
        # was non-auth, the retry will hit the same error + raise.
        # Inline invalidate + re-resolve (NOT refresh()) so we make
        # exactly TWO resolve calls total, not three -- refresh()
        # would do its own internal resolve before _resolve_one().
        _logger.warning(
            "resolve_with_auth_retry: secret_ref=%r auth attempt "
            "raised %s: %s -- refreshing cache + retrying once.",
            name, type(exc).__name__, exc,
        )
        _cred_cache.invalidate(name)
        creds = _resolve_one()
        return auth_callable(creds)  # raises if still bad
