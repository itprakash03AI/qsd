"""vault_token.py This module contains a class VaultToken to get a Vault Token required
to interact with stored secrets"""

import json
import logging
from .qs_utils import send_request

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class QSVaultToken:
    """QueryStudio Vault Token helper.

    Phase 158 (2026-06-26) -- renamed from VaultToken to QSVaultToken
    so it doesn't collide with the same-named vendor class when both
    are imported in the same process.
    """
    def __init__(self, access_configs, midtoken):
        """
        Initializes the QSVaultToken instance.

        Args:
        - accessConfigs (dict): Dictionary containing access configurations.
        - midtoken (str): Machine token for authentication.
        """
        self.config = access_configs
        self.midtoken = midtoken
        self.secret_access_configs = access_configs.get("secret_access_configs")
        self.method = self.config.get("token_method")
        self.vault_role = self.secret_access_configs.get("STEP_UP_NAME")
        self.role_id = self.config.get("role_id")

    def get_token(self):
        """
        Retrieves token from Vault using the configured method.

        Returns:
        - str or None: Token if successfully retrieved, None otherwise.
        """
        # Phase 158 (2026-06-26) strategic hardening -- chained
        # ``res_data["auth"]["client_token"]`` accesses used to
        # KeyError when Vault returned a body without the expected
        # shape (transient outage / wrong role / mid-rotation).  All
        # accessors now go through ``.get(...)`` with defaults so the
        # path returns None cleanly and the caller's last-known-good
        # cache layer can take over.
        def _safe_load(_res):
            if _res is None:
                return None
            try:
                return json.loads(_res.data)
            except Exception as exc:
                logger.error("Vault response not JSON: %s", exc)
                return None

        # AppRole
        if self.method == "approle":
            logger.info("Retrieving vault token from Vault (AppRole)")

            # JWT Login to Vault
            logger.info("JWT Login to Vault")
            url = self.secret_access_configs.get("STEP_UP_AUTH_URL")
            headers = {"Content-Type": "application/json"}
            payload = {"role": self.vault_role, "jwt": self.midtoken}
            res = send_request(
                request_type="POST", url=url,
                body=json.dumps(payload), headers=headers,
            )
            res_data = _safe_load(res) or {}
            client_token = (res_data.get("auth") or {}).get("client_token")
            if not client_token:
                logger.error(
                    "Vault token step-up returned no client_token "
                    "(role=%s)", self.vault_role,
                )
                return None

            # Generate Secret ID on AppRole
            logger.info("Generating Secret ID on AppRole")
            url = self.secret_access_configs.get("APPROLE_SECRET_ID_URL")
            headers = {"X-Vault-Token": client_token}
            res = send_request(request_type="POST", url=url, headers=headers)
            res_data = _safe_load(res) or {}
            secret_id = (res_data.get("data") or {}).get("secret_id")
            if not secret_id:
                logger.error("AppRole secret_id retrieval returned empty")
                return None

            # AppRole Login to Vault
            logger.info("AppRole Login to Vault")
            url = self.secret_access_configs.get("APPROLE_AUTH_URL")
            headers = {"Content-Type": "application/json"}
            payload = {"role_id": self.role_id, "secret_id": secret_id}
            res = send_request(
                request_type="POST", url=url,
                body=json.dumps(payload), headers=headers,
            )
            res_data = _safe_load(res) or {}
            client_token = (res_data.get("auth") or {}).get("client_token")
            if client_token:
                return client_token
            logger.error("AppRole login returned no client_token")
            return None

        if self.method == "JWT":
            logger.info("Retrieving vault token (JWT)")
            url = self.secret_access_configs.get("AUTH_URL")
            headers = {"Content-Type": "application/json"}
            payload = {
                "role": self.secret_access_configs.get("ROLE_NAME"),
                "jwt":  self.midtoken,
            }
            res = send_request(
                request_type="POST", url=url, headers=headers,
                body=json.dumps(payload),
            )
            res_data = _safe_load(res) or {}
            client_token = (res_data.get("auth") or {}).get("client_token")
            if client_token:
                return client_token

        logger.error("Error retrieving vault token!")
        return None