"""qs_credentials.vault -- pure-Python HashiCorp Vault client.

DUAL-COPY: this subpackage + the sibling ``cache.py`` are
byte-identical between ``ETL/qs_credentials/`` and
``backend/core/qs_credentials/``.  CI ``TestSyncedCopies`` fails
when they drift; any edit MUST land in both copies.

Files in this subpackage:
  qs_client.py        -- QSClient (the orchestrator) + resolve_secret
  qs_machine_token.py -- step 1 (pod's K8s machine identity)
  qs_vault_token.py   -- step 2 (exchange for Vault session token)
  qs_read_secrets.py  -- step 3 (GET the secret payload)
  qs_utils.py         -- send_request (HTTP helper used by the steps)

Public surface (re-exported below):
  QSClient                  -- end-to-end client
  resolve_secret            -- functional wrapper around QSClient
  QSMachineToken/Vault/Read -- the 3 step classes (advanced callers)
  fetch_secret              -- chokepoint consumed by QSCredCache
  is_valid_vault_payload    -- payload validator (rejects blank fields)

Fail-OPEN: any step that raises -> ``None`` returned from QSClient.
``fetch_secret`` (the chokepoint) converts ``None`` to a clear
RuntimeError with the operator-actionable cause.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from .qs_client import QSClient, resolve_secret
from .qs_machine_token import QSMachineToken
from .qs_vault_token import QSVaultToken
from .qs_read_secrets import QSReadSecrets

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
#  Chokepoint helpers consumed by QSCredCache (qs_credentials.cache)
# ────────────────────────────────────────────────────────────────────


_REF_REQUIRED = ("type", "auth_url", "role_name", "role_type", "secret_url")


def _build_access_cfg(ref: dict) -> dict:
    """Map a SystemAccount / vault_config.yaml row to QSClient's
    access_cfg dict.

    AppRole-only fields are optional -- harmless to pass as None when
    ``token_method='JWT'``; required when ``token_method='approle'``.
    """
    return {
        "AUTH_URL":              ref.get("auth_url") or "",
        "ROLE_NAME":             ref.get("role_name") or "",
        "ROLE_TYPE":             ref.get("role_type") or "",
        "ROTATE_URL":            ref.get("rotate_url") or "",
        "SECRET_URL":            ref.get("secret_url") or "",
        "STEP_UP_NAME":          ref.get("step_up_name"),
        "STEP_UP_AUTH_URL":      ref.get("step_up_auth_url"),
        "APPROLE_SECRET_ID_URL": ref.get("approle_secret_id_url"),
        "APPROLE_AUTH_URL":      ref.get("approle_auth_url"),
    }


def fetch_secret(
    name: str,
    ref: dict,
    *,
    machine: str = "tprd",
    token_method: str = "JWT",
    _out: Optional[dict] = None,
) -> Any:
    """Resolve ``ref`` via QSClient.

    Args:
      name:         Logical secret_ref name (for log/error messages).
      ref:          Per-account ref dict (type / auth_url / role_name /
                    role_type / secret_url required; rotate_url +
                    AppRole fields optional).
      machine:      ``tprd`` (reads /var/run/secrets/token/vault-token)
                    or ``test`` (127.0.0.1:3003 mock).  Legacy slug
                    ``openshift`` is mapped to ``tprd``.
      token_method: ``JWT`` or ``approle``.
      _out:         Optional dict.  When passed,
                    ``_out['lease_duration']`` is populated with
                    Vault's lease_duration (int seconds, or None).
                    Lets QSCredCache drive lease-aware TTL.

    Returns the tuple/dict matching QSClient's shape per ``ref['type']``.
    Raises RuntimeError with the operator-actionable cause on failure.
    """
    eff_machine = "tprd" if machine == "openshift" else machine
    access_cfg = _build_access_cfg(ref)
    role_id = ref.get("role_id") if token_method == "approle" else None

    try:
        client = QSClient()
        result = client.get_secrets(
            machine=eff_machine,
            secret_access_configs=access_cfg,
            token_method=token_method,
            secret_type=ref.get("type") or "",
            role_id=role_id,
        )
    except Exception as exc:
        raise RuntimeError(
            f"secret_ref={name!r}: QSClient raised "
            f"{type(exc).__name__}: {exc}.  Fix the underlying vault "
            f"config / role / secret_url, OR flip use_vault=False "
            f"on the row to fall back to the encrypted password column."
        ) from exc

    if result is None:
        raise RuntimeError(
            f"secret_ref={name!r}: QSClient returned None "
            f"(type={ref.get('type')!r}).  Check vault role / "
            f"secret_url validity."
        )

    if _out is not None:
        _out["lease_duration"] = getattr(
            client, "last_lease_duration", None,
        )
    logger.info(
        "[resolve] secret_ref=%r resolved via QSClient", name,
    )
    return result


# Back-compat alias -- existing callers + tests still grep this name.
fetch_secret_with_vendor_fallback = fetch_secret


def is_valid_vault_payload(payload: Any, secret_type: str) -> bool:
    """Single source of truth for "what's a good Vault payload".

    Vault occasionally returns blank fields (transient mid-rotation,
    network glitch).  Cache MUST NEVER store these.  QSCredCache
    consults this before every cache write.
    """
    if payload is None:
        return False
    if secret_type in ("DB_accounts", "AD_accounts"):
        if not isinstance(payload, (tuple, list)) or len(payload) < 2:
            return False
        user = str(payload[0] or "").strip()
        password = str(payload[1] or "").strip()
        return bool(user) and bool(password)
    if secret_type == "kv_secrets":
        if not isinstance(payload, dict) or not payload:
            return False
        return any(str(v or "").strip() for v in payload.values())
    return True  # unknown type -- trust caller


__all__ = [
    "QSClient",
    "QSMachineToken", "QSVaultToken", "QSReadSecrets",
    "resolve_secret",
    "fetch_secret",
    "fetch_secret_with_vendor_fallback",
    "is_valid_vault_payload",
]
