"""read_secrets.py This module contains a class ReadSecrets to retrieve secrets
from Vault by authenticating with the Vault Token"""

import json
import logging

from .qs_utils import send_request

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class QSReadSecrets:
    """QueryStudio Read Secrets helper.

    Phase 158 (2026-06-26) -- renamed from ReadSecrets to
    QSReadSecrets to avoid collision with the vendor class.

    Utility class to read secrets from a vault.

    Attributes:
    - config (dict): Dictionary containing access configurations.
    - vault_token (str): Token for accessing the vault.
    - consul_configs (dict): Dictionary containing configurations fetched from Consul.

    Methods:
    - __init__(self, accessConfigs, vault_token): Initializes the ReadSecrets instance
                                                  with access configurations
                                                  and vault token.
    - get_secrets(self): Retrieves secrets from the configured source.
    """

    def __init__(self, access_configs, vault_token):
        """
        Initializes the ReadSecrets instance.

        Args:
        - access_configs (dict): Dictionary containing access configurations.
        - vault_token (str): Token for accessing the vault.
        """
        self.config = access_configs
        self.vault_token = vault_token
        self.secret_access_configs = access_configs.get("secret_access_configs")
        # Phase 158 R4 (2026-06-26) -- exposes the lease_duration from
        # the Vault response after ``get_secrets()`` completes.  None
        # when Vault didn't return one (static KV secrets), an int
        # (seconds) for dynamic / leased responses.  Consumed by
        # ``QSCredCache.fetch_with_fallback`` to override the default
        # mem_ttl when Vault has a meaningful lease.
        self.last_lease_duration = None

    def get_secrets(self):
        """
        Retrieves secrets from the Vault.

        Phase 158 (2026-06-26) -- hardened against None response,
        non-JSON body, and missing keys at every level so a transient
        Vault hiccup falls through to None cleanly (caller's
        last-known-good cache takes over).

        Returns:
        - tuple | dict | None depending on secret_type:
            AD_accounts -> (username, password)
            DB_accounts -> (username, password, tns_alias)
            kv_secrets  -> the kv dict
        """
        logger.info("Start retrieving secrets from the Vault!")
        secret_type = self.config.get("secret_type")
        secret_url = self.secret_access_configs.get("SECRET_URL")
        headers = {"X-Vault-Token": self.vault_token}
        res = send_request(request_type="GET", url=secret_url, headers=headers)
        if res is None:
            logger.error("ReadSecrets: HTTP call returned None")
            return None
        try:
            res_data = json.loads(res.data)
        except Exception as exc:
            logger.error("ReadSecrets: response not JSON: %s", exc)
            return None
        if not res_data:
            return None

        # Phase 158 R4 (2026-06-26) -- capture Vault's lease_duration
        # when present (dynamic secrets, leased credentials, auth
        # tokens).  Static KV secrets typically have no lease so this
        # stays None and the cache falls back to the configured mem_ttl.
        lease = res_data.get("lease_duration")
        if isinstance(lease, (int, float)) and lease > 0:
            self.last_lease_duration = int(lease)
        else:
            self.last_lease_duration = None

        # All accessors go through ``.get(...)`` so a missing
        # ``data`` envelope returns None instead of AttributeError.
        data = res_data.get("data") or {}

        if secret_type == "AD_accounts":
            return data.get("username"), data.get("password")

        if secret_type == "kv_secrets":
            # KV v2 wraps the actual payload under data.data; KV v1
            # exposes it at data directly.  Try both, in order.
            inner = data.get("data")
            if isinstance(inner, dict) and inner:
                return inner
            if isinstance(data, dict) and data:
                return data
            return None

        if secret_type == "DB_accounts":
            return (
                data.get("username"),
                data.get("password"),
                data.get("tns_alias"),
            )

        logger.warning("ReadSecrets: unknown secret_type=%r", secret_type)
        return None