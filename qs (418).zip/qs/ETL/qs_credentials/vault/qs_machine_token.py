"""machine_token.py This module contains a class MachineToken for fetching Machine Identity"""

import json
import logging

from .qs_utils import send_request

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class QSMachineToken:
    """QueryStudio Machine Identity Token helper.

    Phase 158 (2026-06-26) -- renamed from MachineToken to
    QSMachineToken to avoid collision with the vendor class.

    Utility class to retrieve machine token.

    Attributes:
    - configs (dict): Dictionary containing access configurations.
    - test_url (str): URL for retrieving machine identity token on test.

    Methods:
    - __init__(self, accessConfigs): Initializes the MachineToken
                                     instance with access configurations.
    - get_token(self): Retrieves machine token from the configured source.
    """

    def __init__(self, access_configs):
        """
        Initializes the MachineToken instance.

        Args:
        - accessConfigs (dict): Dictionary containing access configurations.
        """
        self.configs = access_configs
        self.test_url = "http://127.0.0.1:3003?appName={appName}&Env=PROD"
        self.machine = self.configs.get("machine")

    def get_token(self):
        """
        Retrieves machine token from the configured source.

        Returns:
        - str or None: Machine token if successfully retrieved, None otherwise.
        """
        if self.machine == "test":
            logger.info("Retrieving machine identity token from test")
            # Phase 158 (2026-06-26) strategic fix -- send_request may
            # return None on network error; calling .data on it would
            # AttributeError.  Also, the parsed JSON is a dict so the
            # ``.data`` accessor (legacy bug) was wrong -- use the
            # standard dict lookup AND fall through cleanly when the
            # mock returns an unexpected shape.
            res = send_request(request_type="GET", url=self.test_url)
            if res is None:
                logger.error("Machine token: test mock unreachable")
                return None
            try:
                test_mid_token = json.loads(res.data)
            except Exception as exc:
                logger.error("Machine token: test mock returned non-JSON: %s", exc)
                return None
            if isinstance(test_mid_token, dict):
                return test_mid_token.get("data") or test_mid_token.get("token")
            if isinstance(test_mid_token, str):
                return test_mid_token
            return None

        if self.machine == "tprd":
            logger.info("Retrieving machine identity token from tprd")

            # Read machine token from file
            try:
                with open('/var/run/secrets/token/vault-token', 'r') as file:
                    tprd_mid_token = file.read().strip()
                    logger.info("Machine identity token retrieved!")
                    return tprd_mid_token
            except FileNotFoundError:
                logger.error("Machine token file at /var/run/secrets/token/vault-token is not found!")
                return None
            except PermissionError:
                logger.error("Permission denied to read machine token file")
                return None
            except Exception as e:
                logger.error(f"Error reading token: {e}")
                return None
        logger.error("Please specify either tprd/test as the machine type!")
        return None