##utils.py
import urllib3
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def urllib3_client_builder():
    """Setups and builds urllib3 client"""
    retry = urllib3.Retry(total=5, raise_on_status=False, backoff_factor=0.1)
    timeout = urllib3.Timeout(3.0)
    urllib3.util.ssl_.DEFAULT_CIPHERS = "DEFAULT@SECLEVEL=1"
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    http = urllib3.PoolManager(cert_reqs="CERT_NONE", retries=retry, timeout=timeout)
    return http


def send_request(request_type, url, headers=None, body=None, auth=None):
    """
    Sends an HTTP request using urllib3.

    Args:
    - type (str): The HTTP request type ('GET', 'POST', etc.).
    - url (str): The URL to send the request to.
    - headers (dict, optional): Dictionary of HTTP headers. Default is None.
    - body (bytes, optional): The request body. Default is None.
    - auth (tuple, optional): Tuple containing (username, password)
                              for basic authentication. Default is None.

    Returns:
    - dict or None: The response data as a dictionary if the request is successful,
                    None otherwise.
    """
    http = urllib3_client_builder()
    try:
        if auth:
            headers = urllib3.make_headers(basic_auth=auth[0] + ":" + auth[1])
        res = http.request(request_type, url, body=body, headers=headers)
        if res and res.status >= 400:
            raise urllib3.exceptions.HTTPError(res.data)
        return res
    except urllib3.exceptions.HTTPError as e:
        logger.exception(f"HTTP Error: {e}")
        return None