"""QSClient -- end-to-end pure-Python HashiCorp Vault client.

Orchestrates the 3-step Vault dance via QSMachineToken (step 1),
QSVaultToken (step 2), QSReadSecrets (step 3).  Single user-facing
class of the ``qs_credentials.vault`` subpackage.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional

from .qs_machine_token import QSMachineToken
from .qs_vault_token import QSVaultToken
from .qs_read_secrets import QSReadSecrets

logger = logging.getLogger(__name__)


class QSClient:
    """End-to-end Vault client.  Returns the same shape per ``secret_type``:

      * ``AD_accounts`` -> ``(username, password)``
      * ``DB_accounts`` -> ``(username, password, tns_alias)``
      * ``kv_secrets``  -> the full kv dict
      * ``None`` on any failure (fail-OPEN)
    """

    def __init__(self, access_configs: Optional[dict] = None):
        """``access_configs`` is held for forward-compat; the per-call
        ``secret_access_configs`` arg on ``get_secrets`` wins."""
        self.access_configs = dict(access_configs or {})
        # After ``get_secrets()`` completes, this attribute holds the
        # Vault response's lease_duration (int seconds) when one was
        # returned, or None for static secrets.  QSCredCache reads it
        # via getattr() to drive lease-aware cache TTL.
        self.last_lease_duration: Optional[int] = None

    def get_secrets(
        self,
        *,
        machine: str = "tprd",
        secret_access_configs: Any,
        token_method: str = "JWT",
        secret_type: str = "AD_accounts",
        role_id: Optional[str] = None,
    ) -> Any:
        """End-to-end vault secret resolution.

        Args:
          machine: ``tprd`` (read /var/run/secrets/token/vault-token)
                    or ``test`` (local 127.0.0.1:3003 mock).
          secret_access_configs: JSON-encoded string OR dict.  QSClient
                                  accepts either so call sites don't
                                  need to json.dumps for no reason.
          token_method: ``JWT`` (single-step) or ``approle`` (two-step).
          secret_type:  ``AD_accounts`` | ``DB_accounts`` | ``kv_secrets``.
          role_id:      Only required when ``token_method='approle'``.
        """
        # Normalise secret_access_configs -- accept JSON string or dict.
        if isinstance(secret_access_configs, str):
            try:
                sac = json.loads(secret_access_configs)
            except Exception as exc:
                logger.error(
                    "QSClient.get_secrets: secret_access_configs is "
                    "not valid JSON: %s", exc,
                )
                return None
        elif isinstance(secret_access_configs, dict):
            sac = dict(secret_access_configs)
        else:
            logger.error(
                "QSClient.get_secrets: secret_access_configs must be "
                "JSON string or dict, got %s",
                type(secret_access_configs).__name__,
            )
            return None

        # The downstream QS* classes take a single ``access_configs``
        # dict.  Merge instance-level config (if any) with per-call.
        access_configs = dict(self.access_configs)
        access_configs.update({
            "machine":               machine,
            "token_method":          token_method,
            "secret_type":           secret_type,
            "role_id":               role_id,
            "secret_access_configs": sac,
        })

        # Step 1 -- machine identity token.
        try:
            midtoken = QSMachineToken(access_configs).get_token()
        except Exception as exc:
            logger.exception(
                "QSClient: machine token step raised %s: %s",
                type(exc).__name__, exc,
            )
            return None
        if not midtoken:
            logger.error("QSClient: machine token retrieval failed")
            return None

        # Step 2 -- vault token.
        try:
            vault_token = QSVaultToken(
                access_configs, midtoken,
            ).get_token()
        except Exception as exc:
            logger.exception(
                "QSClient: vault token step raised %s: %s",
                type(exc).__name__, exc,
            )
            return None
        if not vault_token:
            logger.error("QSClient: vault token retrieval failed")
            return None

        # Step 3 -- read secret.
        try:
            reader = QSReadSecrets(access_configs, vault_token)
            payload = reader.get_secrets()
            # Propagate Vault's lease_duration upward so the cache can
            # use it as a per-secret TTL override.
            self.last_lease_duration = getattr(
                reader, "last_lease_duration", None,
            )
        except Exception as exc:
            logger.exception(
                "QSClient: read secrets step raised %s: %s",
                type(exc).__name__, exc,
            )
            return None
        return payload


def resolve_secret(
    *,
    machine: str = "tprd",
    secret_access_configs: Any,
    token_method: str = "JWT",
    secret_type: str = "AD_accounts",
    role_id: Optional[str] = None,
) -> Any:
    """Thin functional wrapper -- equivalent to
    ``QSClient().get_secrets(...)`` for callers that prefer the
    call-site syntax over instantiation."""
    return QSClient().get_secrets(
        machine=machine,
        secret_access_configs=secret_access_configs,
        token_method=token_method,
        secret_type=secret_type,
        role_id=role_id,
    )
