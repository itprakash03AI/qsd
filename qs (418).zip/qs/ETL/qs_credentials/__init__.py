"""qs_credentials -- ETL's single entry point for vault-backed creds.

Public API (call sites only need this import line)::

    from qs_credentials import resolve_db_account, resolve_ad_account

Layout:
  resolver.py      -- ETL facade (yaml-driven; public functions live here)
  cache.py         -- QSCredCache (in-process + disk Fernet + retry)
  vault/           -- HashiCorp Vault HTTP client (QSClient + helpers)
"""
from __future__ import annotations

from .resolver import (
    # Resolve secrets by name (the main API).
    resolve_db_account,
    resolve_db_account_with_tns,
    resolve_ad_account,
    resolve_kv_secret,
    fill_creds_from_ref,

    # Auth-failure recovery + manual cache invalidation.
    refresh,
    resolve_with_auth_retry,
    invalidate,
    reset_cache,
    disk_cache_clear,

    # Three-layer enable toggle (env / per-workflow / global yaml).
    is_vault_enabled,
)

# Re-export shared classes for advanced callers / tests.
from .cache import QSCredCache
from .vault import (
    QSClient,
    QSMachineToken,
    QSVaultToken,
    QSReadSecrets,
    fetch_secret,
    fetch_secret_with_vendor_fallback,  # back-compat alias of fetch_secret
    is_valid_vault_payload,
    resolve_secret,
)

__all__ = [
    # public resolver API
    "resolve_db_account",
    "resolve_db_account_with_tns",
    "resolve_ad_account",
    "resolve_kv_secret",
    "fill_creds_from_ref",
    # rotation / auth-failure handling
    "refresh",
    "resolve_with_auth_retry",
    "invalidate",
    "reset_cache",
    "disk_cache_clear",
    # toggles
    "is_vault_enabled",
    # advanced
    "QSCredCache",
    "QSClient",
    "QSMachineToken",
    "QSVaultToken",
    "QSReadSecrets",
    "fetch_secret",
    "fetch_secret_with_vendor_fallback",
    "is_valid_vault_payload",
    "resolve_secret",
]
