"""qs_credentials.cache -- shared in-process + disk Fernet cache.

Phase 158 R6 (2026-06-26) -- single-chokepoint extraction.  Owns:

  * in-process TTL cache (dict + threading.Lock)
  * Fernet disk cache (sidecar-key atomic-link dance, .tmp rename)
  * ``fetch_with_fallback`` retry-then-stale algorithm
  * 24h periodic refresh daemon (``start_periodic_refresh``)
  * Per-name lock for thundering-herd protection

Each pod's ``qs_credentials.resolver`` module constructs ONE
:class:`QSCredCache` instance, configures the pod-specific settings
provider, and the only code that stays pod-specific is:

  * The ref source (ETL: yaml file; QS: SystemAccount DB row)
  * The public API shape (``resolve_db_account`` for ETL,
    ``resolve_system_account`` for QS)
  * The vault-enabled toggle (different env var names)

Cache invariants:
  * Only VALIDATED payloads enter the cache (blank user/password
    transient blanks NEVER poison the cache).
  * Two attempts at vault on miss; last-known-good fallback when
    both fail; short-TTL re-cache so the next retry is in 60s.
  * Disk cache is Fernet-encrypted; sidecar-key file lets pods on
    shared PVC agree on a key without per-pod ceremony.
  * Helm-secret env var is the recommended prod setup.

DUAL-COPY: byte-identical with ``backend/core/qs_credentials/cache.py``;
the ``TestSyncedCopies`` contract test fails CI when the two drift.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Callable, Dict, Optional, Tuple


def _running_in_spark_context() -> bool:
    """Detect whether this process is a Spark driver / executor pod.

    Spark pods are ephemeral (one workflow run = boot + work + die in
    minutes), so the 24h periodic refresh daemon never reaches its
    first tick.  Worse, the daemon thread leaks until process exit.
    Skip auto-start when we're clearly in a Spark context.

    Detection order (any positive = Spark context):
      1. ``QS_CRED_DAEMON_FORCE=1`` -- operator override (run daemon anyway)
      2. ``SPARK_HOME`` env var set + non-empty
      3. ``pyspark.SparkContext._active_spark_context`` is not None
    """
    if os.environ.get("QS_CRED_DAEMON_FORCE", "").strip().lower() in (
        "1", "true", "yes",
    ):
        return False  # operator forced daemon ON
    if os.environ.get("SPARK_HOME", "").strip():
        return True
    try:
        from pyspark import SparkContext  # type: ignore
        if SparkContext._active_spark_context is not None:
            return True
    except Exception:
        pass
    return False


# Settings provider contract -- a callable returning a dict with:
#   enabled  (bool)  -- master toggle for the disk cache layer
#   path     (str)   -- absolute path to the encrypted cache file
#   ttl      (int)   -- TTL of disk-cached entries, seconds
#   key_env  (str)   -- env var name that holds the Fernet key
#   mem_ttl  (int)   -- TTL of in-process cache entries, seconds
SettingsProvider = Callable[[], Dict[str, Any]]


class QSCredCache:
    """Per-pod credential cache + vault fetch with retry + stale fallback.

    Constructor args:
      settings_provider: callable() -> dict with the 5 keys above.  Must
        be a callable (not a frozen dict) so test hooks / config
        reloads pick up new values without rebuilding the cache.
      plaintext_env_var: env var name whose truthy value allows the
        disk cache to fall back to plaintext when ``cryptography`` is
        not installed (test envs).  Set to '' to disable plaintext.
      logger: pod-specific logger.  All cache events log through it
        so the operator's grep finds ETL vs QS lines as expected.
    """

    def __init__(
        self,
        settings_provider: SettingsProvider,
        plaintext_env_var: str,
        logger: logging.Logger,
    ):
        self._settings = settings_provider
        self._plaintext_env = plaintext_env_var
        self._log = logger
        # In-process cache: name -> (expires_at_unix_ts, payload).
        # Thread-safe via a single lock; callers may resolve concurrently
        # (Spark executor + driver, multiple steps on one pod, FastAPI
        # workers).
        self._mem: Dict[str, Tuple[float, Any]] = {}
        self._lock = threading.Lock()
        # Per-name fetch coalescing locks -- prevents thundering-herd
        # on cold-cache start (pod restart / post-rotation) when N
        # concurrent requests for the SAME secret would otherwise fire
        # N parallel vault calls.  First caller hits vault; the others
        # wait + read the result from cache.
        self._fetch_locks: Dict[str, threading.Lock] = {}
        self._fetch_locks_mutex = threading.Lock()

    def _get_fetch_lock(self, name: str) -> threading.Lock:
        """Per-name lock for coalescing concurrent vault fetches."""
        with self._fetch_locks_mutex:
            lk = self._fetch_locks.get(name)
            if lk is None:
                lk = threading.Lock()
                self._fetch_locks[name] = lk
            return lk

    # ──────────────────────────────────────────────────────────────
    # In-process TTL cache
    # ──────────────────────────────────────────────────────────────

    def mem_get_fresh(self, name: str) -> Optional[Any]:
        """Return cached payload if still within TTL, else None."""
        with self._lock:
            entry = self._mem.get(name)
            if entry is None:
                return None
            expires_at, payload = entry
            return payload if time.time() < expires_at else None

    def mem_get_any(self, name: str) -> Optional[Any]:
        """Return cached payload IGNORING TTL.  Last-known-good fallback
        when Vault returns blanks."""
        with self._lock:
            entry = self._mem.get(name)
            return entry[1] if entry else None

    def mem_put(self, name: str, payload: Any, ttl_seconds: int) -> None:
        if ttl_seconds <= 0:
            return  # caching disabled
        with self._lock:
            self._mem[name] = (time.time() + ttl_seconds, payload)

    def invalidate(self, name: str) -> None:
        """Drop the cached entry for ``name`` -- call after an auth
        failure so the next resolve fetches a fresh secret."""
        with self._lock:
            self._mem.pop(name, None)

    def reset_mem(self) -> None:
        """Test hook -- wipe in-process cache."""
        with self._lock:
            self._mem.clear()

    def invalidate_all(self) -> None:
        """Wipe BOTH in-process AND disk cache.  Next call for any
        name will re-fetch from Vault.

        Used by the periodic-refresh daemon to bound the rotation
        propagation window: if Vault rotates a secret outside the
        natural mem_ttl window, the next periodic tick guarantees a
        fresh fetch within ``refresh_hours``.
        """
        with self._lock:
            self._mem.clear()
        self.disk_clear()
        self._log.info(
            "QSCredCache.invalidate_all: dropped mem + disk cache "
            "(next call re-fetches from Vault).",
        )

    def start_periodic_refresh(
        self,
        hours: float = 24.0,
        *,
        name_hint: str = "qs-cred-cache-refresh",
    ) -> bool:
        """Start a background daemon thread that invalidates the cache
        every ``hours`` hours.  Idempotent -- second call is a no-op
        if a thread is already running on this instance.

        Returns True when a NEW thread was started, False when an
        existing thread is already running (or when ``hours <= 0`` /
        Spark context detected -- both disable the daemon).

        Apply rule: prod long-running pods should run with ``hours=24``
        (default); tests + dev + Spark/ephemeral pods get ``hours=0``
        (manually OR auto-detected via SparkContext / SPARK_HOME).
        """
        if hours <= 0:
            self._log.info(
                "QSCredCache.start_periodic_refresh: hours=%s -> "
                "daemon DISABLED.", hours,
            )
            return False
        if _running_in_spark_context():
            self._log.info(
                "QSCredCache.start_periodic_refresh: Spark context "
                "detected -> daemon SKIPPED (ephemeral pod won't reach "
                "the %sh tick).  Set QS_CRED_DAEMON_FORCE=1 to override.",
                hours,
            )
            return False
        existing = getattr(self, "_refresh_thread", None)
        if existing is not None and existing.is_alive():
            return False  # already running

        interval = float(hours) * 3600.0

        def _loop() -> None:
            while True:
                # Sleep first so the FIRST tick is N hours after
                # startup, not at boot (avoids a fresh-pod immediately
                # wiping the disk cache it just inherited from PVC).
                time.sleep(interval)
                try:
                    self.invalidate_all()
                except Exception as exc:
                    # Never let the daemon die -- log + continue.
                    self._log.warning(
                        "QSCredCache periodic refresh tick failed "
                        "(%s); continuing.", exc,
                    )

        thread = threading.Thread(
            target=_loop, daemon=True, name=name_hint,
        )
        thread.start()
        self._refresh_thread = thread
        self._log.info(
            "QSCredCache.start_periodic_refresh: daemon started "
            "(invalidate-all every %sh).", hours,
        )
        return True

    # ──────────────────────────────────────────────────────────────
    # Disk-backed encrypted (Fernet) cache
    # ──────────────────────────────────────────────────────────────

    def _read_sidecar_key(self, key_sidecar: str) -> str:
        """Read the sidecar key file.  Returns '' on missing or empty
        file (caller will create one)."""
        if not os.path.exists(key_sidecar):
            return ""
        try:
            with open(key_sidecar, "rb") as f:
                k = f.read().decode().strip()
            # File can exist but be EMPTY if another pod won the O_EXCL
            # race but its write hadn't landed yet.  Treat as missing
            # so the caller waits and retries via the atomic-write path.
            return k
        except Exception:
            return ""

    def _write_sidecar_key_atomic(self, key_sidecar: str, Fernet) -> str:
        """Atomically create the sidecar key file, then re-read whatever
        landed (ours OR a winning pod's that raced us).

        Atomicity: write to ``<sidecar>.tmp.<pid>``, then ``os.link`` it
        to the final name (POSIX atomic create-or-fail).  Falls back to
        ``os.rename`` + best-effort retry on platforms without link
        semantics.  Either way, the final file at ``key_sidecar`` is
        either NON-EXISTENT or has the FULL key -- never partial.  This
        closes the race where another pod could read between O_EXCL
        create-success and the subsequent write-complete.
        """
        my_key = Fernet.generate_key().decode()
        try:
            os.makedirs(os.path.dirname(key_sidecar) or ".", exist_ok=True)
        except OSError as exc:
            self._log.warning(
                "Could not create dir for Fernet sidecar (%s) -- "
                "disk cache disabled for this pod.", exc,
            )
            return ""

        tmp_path = f"{key_sidecar}.tmp.{os.getpid()}"
        try:
            # Write key + flush to OS buffer
            fd = os.open(
                tmp_path,
                os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                0o600,
            )
            try:
                with os.fdopen(fd, "wb") as f:
                    f.write(my_key.encode())
                    f.flush()
                    try:
                        os.fsync(f.fileno())
                    except (OSError, AttributeError):
                        # fsync unavailable / non-fsyncable fd; tolerate.
                        pass
            except Exception:
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
                raise

            # Atomic publish.  Try POSIX hard-link first (atomic
            # create-or-fail).  On Windows / non-POSIX, fall back to
            # rename + race-loser branch.
            try:
                os.link(tmp_path, key_sidecar)
                published = True
            except FileExistsError:
                published = False
            except (OSError, AttributeError):
                # link not supported (Windows + some FS).  Best-effort:
                # rename to final.  Slight risk of clobber when two
                # pods race -- but rename is itself atomic on POSIX,
                # and both pods writing the SAME-format key is harmless
                # (cross-pod read will use whichever wins).
                try:
                    if not os.path.exists(key_sidecar):
                        os.rename(tmp_path, key_sidecar)
                        published = True
                    else:
                        published = False
                except OSError:
                    published = False

            # Cleanup our tmp -- whether we won or lost.
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass

            if published:
                self._log.warning(
                    "Auto-generated Fernet key at %s (mode 0600). "
                    "Prod recommendation: set %s env var globally "
                    "via Helm secret.", key_sidecar,
                    self._settings()["key_env"],
                )
                return my_key

            # We lost the race.  Re-read the winner's key.
            try:
                with open(key_sidecar, "rb") as f:
                    return f.read().decode().strip()
            except Exception as exc:
                self._log.warning(
                    "Lost sidecar race AND couldn't re-read winner's "
                    "key (%s) -- disk cache disabled.", exc,
                )
                return ""

        except OSError as exc:
            self._log.warning(
                "Could not persist auto-generated Fernet key (%s) -- "
                "disk cache disabled for this pod.", exc,
            )
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            return ""

    def _get_fernet(self):
        """Returns (Fernet_instance, mode_str) where mode is one of
        ``fernet``, ``plaintext`` (only when explicitly allowed via
        env var), or ``disabled`` (cryptography missing or key invalid).

        Recommended prod setup: set ``key_env`` via Helm secret so all
        pods share the SAME key.  Sidecar-key file is best-effort
        cross-pod sharing for dev envs.
        """
        settings = self._settings()
        key_env = settings["key_env"]
        key = os.environ.get(key_env, "").strip()
        try:
            from cryptography.fernet import Fernet  # type: ignore
        except ImportError:
            allow_plain = (
                self._plaintext_env
                and os.environ.get(self._plaintext_env, "")
                       .strip().lower() in ("1", "true", "yes")
            )
            if allow_plain:
                self._log.warning(
                    "cryptography unavailable; disk cache will be "
                    "PLAINTEXT (%s=1 set).  Install cryptography "
                    "for encryption.", self._plaintext_env,
                )
                return None, "plaintext"
            return None, "disabled"

        if not key:
            # SHARED disk cache on PVC needs the SAME Fernet key on
            # every pod.  Auto-generating per-pod keys BREAKS cross-pod
            # decrypt -- pod B can't decrypt what pod A wrote.
            #
            # Try a sidecar file (.key) next to the cache file -- works
            # when the cache path is on shared PVC (first pod writes
            # the key, other pods read it).  Per-pod /tmp volumes mean
            # each pod overwrites the sidecar -- recommended prod fix:
            # set the key_env env var globally via Helm secret.
            key_sidecar = settings["path"] + ".key"
            key = self._read_sidecar_key(key_sidecar)
            if not key:
                key = self._write_sidecar_key_atomic(key_sidecar, Fernet)
                if not key:
                    return None, "disabled"

        try:
            return Fernet(
                key.encode() if isinstance(key, str) else key,
            ), "fernet"
        except Exception as exc:
            self._log.warning(
                "Invalid Fernet key (%s); disk cache disabled.", exc,
            )
            return None, "disabled"

    def _disk_read_all(self) -> Dict[str, Any]:
        """Decrypt + decode the full on-disk cache dict.  Returns {} on
        any error (caller treats as no cache)."""
        settings = self._settings()
        if not settings["enabled"]:
            return {}
        path = settings["path"]
        if not os.path.exists(path):
            return {}
        fernet, mode = self._get_fernet()
        if mode == "disabled":
            return {}
        try:
            with open(path, "rb") as f:
                raw = f.read()
            if mode == "fernet":
                raw = fernet.decrypt(raw)
            return json.loads(raw.decode("utf-8")) or {}
        except Exception as exc:
            self._log.warning(
                "Disk cache read failed (%s); falling through to vault.",
                exc,
            )
            return {}

    def disk_get_fresh(self, name: str) -> Optional[Any]:
        """Return disk-cached payload if entry is fresh, else None."""
        cache = self._disk_read_all()
        entry = cache.get(name)
        if not entry:
            return None
        if time.time() >= entry.get("expires_at", 0):
            return None
        return entry.get("payload")

    def disk_get_any(self, name: str) -> Optional[Any]:
        """Return disk-cached payload IGNORING TTL.  Last-known-good
        fallback when Vault returns blanks AND in-process cache is
        empty (e.g. after pod restart)."""
        cache = self._disk_read_all()
        entry = cache.get(name)
        return entry.get("payload") if entry else None

    def disk_put(self, name: str, payload: Any) -> None:
        """Encrypt + write the cache atomically.  Reads the existing
        cache, inserts / updates ``name``, writes back via .tmp +
        rename."""
        settings = self._settings()
        if not settings["enabled"]:
            return
        ttl = settings["ttl"]
        if ttl <= 0:
            return
        path = settings["path"]
        fernet, mode = self._get_fernet()
        if mode == "disabled":
            return

        # Read existing (best-effort).
        cache: Dict[str, Any] = {}
        if os.path.exists(path):
            try:
                with open(path, "rb") as f:
                    raw = f.read()
                if mode == "fernet":
                    raw = fernet.decrypt(raw)
                cache = json.loads(raw.decode("utf-8")) or {}
            except Exception:
                cache = {}

        # tuple -> list so JSON round-trips (QSClient returns
        # tuple for DB / AD accounts).
        payload_to_store = (
            list(payload) if isinstance(payload, tuple) else payload
        )
        cache[name] = {
            "expires_at": time.time() + ttl,
            "payload":    payload_to_store,
        }

        # Atomic write.
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            body = json.dumps(cache).encode("utf-8")
            if mode == "fernet":
                body = fernet.encrypt(body)
            tmp = path + ".tmp"
            with open(tmp, "wb") as f:
                f.write(body)
            os.chmod(tmp, 0o600)
            os.replace(tmp, path)
            self._log.info(
                "Disk cache updated (%s, mode=%s, ttl=%ss): %s",
                path, mode, ttl, name,
            )
        except OSError as exc:
            self._log.warning("Disk cache write failed (%s)", exc)

    def disk_clear(self) -> None:
        """Wipe the disk cache file + sidecar key (test hook + manual
        rotation trigger)."""
        settings = self._settings()
        for p in (settings["path"], settings["path"] + ".key"):
            try:
                os.remove(p)
            except OSError:
                pass

    # ──────────────────────────────────────────────────────────────
    # Vault fetch with retry + last-known-good fallback
    # ──────────────────────────────────────────────────────────────

    def fetch_with_fallback(
        self,
        name: str,
        ref: Dict[str, Any],
        *,
        machine: str = "tprd",
        token_method: str = "JWT",
    ) -> Any:
        """Hit Vault for ``name``, validate, retry once on invalid,
        fall back to last-known-good cache when both attempts fail.

        Decision order:
          1. Vault call -> validate -> cache both layers + return
          2. Retry once -> validate -> cache both layers + return
          3. In-process cache last-known-good (any TTL) -> WARN + return
          4. Disk cache last-known-good (any TTL) -> WARN + return
          5. Raise RuntimeError (caller decides next step)

        Caching only validated payloads + serving stale on failure
        means a single transient Vault blank can't break the pipeline.
        """
        # Late-bind sibling helpers to avoid any circular-import risk
        # at module-load time.  ``vault`` is the sibling subpackage
        # under ``qs_credentials/`` that owns the QSClient + vendor
        # fallback ladder.
        from .vault import (
            fetch_secret_with_vendor_fallback,
            is_valid_vault_payload,
        )

        # Thundering-herd protection: coalesce concurrent fetches for
        # the SAME secret to a single vault call.  N callers race for
        # the per-name lock; FIRST gets it + does the work; OTHERS
        # wait, then read from the cache via DCL (double-checked
        # locking).  In production this prevents an API pod restart
        # from sending 100 parallel calls to Vault for the same
        # system_account.
        per_name_lock = self._get_fetch_lock(name)
        with per_name_lock:
            # DCL: someone may have populated the cache while we were
            # blocked on the lock.  Return their result.
            fresh = self.mem_get_fresh(name)
            if fresh is not None:
                return fresh

            secret_type = ref.get("type") or ""
            default_ttl = int(self._settings().get("mem_ttl", 0) or 0)

            for attempt in (1, 2):
                # Phase 158 R4 -- capture lease_duration via _out so we
                # can use Vault's lease as a per-secret TTL override.
                fetch_out: Dict[str, Any] = {}
                try:
                    payload = fetch_secret_with_vendor_fallback(
                        name, ref,
                        machine=machine, token_method=token_method,
                        _out=fetch_out,
                    )
                except Exception as exc:
                    self._log.warning(
                        "Vault fetch attempt %d for secret_ref=%r raised "
                        "%s: %s",
                        attempt, name, type(exc).__name__, exc,
                    )
                    continue

                if is_valid_vault_payload(payload, secret_type):
                    # Lease-aware TTL: prefer Vault's lease when it
                    # returned one + it's tighter than our default
                    # (we never extend beyond the configured ceiling).
                    lease = fetch_out.get("lease_duration")
                    if isinstance(lease, int) and lease > 0:
                        ttl_proc = min(lease, default_ttl) if default_ttl > 0 else lease
                        self._log.info(
                            "secret_ref=%r vault lease_duration=%ds -> "
                            "cache TTL=%ds (was %ds default).",
                            name, lease, ttl_proc, default_ttl,
                        )
                    else:
                        ttl_proc = default_ttl

                    self.mem_put(name, payload, ttl_proc)
                    self.disk_put(name, payload)
                    if attempt > 1:
                        self._log.info(
                            "Vault retry succeeded for secret_ref=%r",
                            name,
                        )
                    return payload

                self._log.warning(
                    "Vault fetch attempt %d for secret_ref=%r returned "
                    "invalid/blank payload (type=%s); will %s",
                    attempt, name, secret_type,
                    "retry once" if attempt == 1
                    else "fall back to last-known-good",
                )

            # Both attempts failed.  Serve last-known-good if any.
            stale = self.mem_get_any(name) or self.disk_get_any(name)
            if stale is not None:
                # Re-cache with a SHORT TTL so we retry Vault sooner
                # than the full 15-min window -- a transient blank
                # shouldn't lock us into stale for a quarter hour.
                self.mem_put(name, stale, ttl_seconds=60)
                self._log.warning(
                    "Vault returned invalid for secret_ref=%r after 2 "
                    "attempts; serving LAST-KNOWN-GOOD cached value "
                    "(next retry in 60s).", name,
                )
                return stale

        raise RuntimeError(
            f"secret_ref={name!r}: Vault returned invalid/blank "
            f"payload after 2 attempts AND no cached fallback "
            f"available.  Verify vault config -> secret_url is correct "
            f"+ the secret actually exists in Vault under that path."
        )


__all__ = ["QSCredCache", "SettingsProvider"]
