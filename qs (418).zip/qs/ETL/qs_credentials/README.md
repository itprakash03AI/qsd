# qs_credentials — operator quick reference

Pure-Python Vault credential resolver with in-process + disk Fernet
cache, periodic refresh, and auth-failure retry.

## What's here

```
ETL/qs_credentials/
├── __init__.py         public API (import from here)
├── resolver.py         ETL facade -- resolve_db_account etc.
├── cache.py            QSCredCache -- mem + disk Fernet + 24h refresh
└── vault/              HashiCorp Vault HTTP client
    ├── __init__.py     fetch_secret + is_valid_vault_payload
    ├── qs_client.py    QSClient -- the orchestrator
    ├── qs_machine_token.py   step 1: pod K8s identity
    ├── qs_vault_token.py     step 2: Vault session token
    ├── qs_read_secrets.py    step 3: GET the secret payload
    └── qs_utils.py     send_request HTTP helper
```

## Public API

```python
from qs_credentials import (
    resolve_db_account,           # Oracle DB    -> (user, pw)
    resolve_db_account_with_tns,  # Oracle + DSN -> (user, pw, tns_alias)
    resolve_ad_account,           # Starburst / AD -> (user, pw)
    resolve_kv_secret,            # AWS / kv     -> dict
    refresh,                      # drop cache + re-fetch
    resolve_with_auth_retry,      # auth-failure self-heal
    is_vault_enabled,             # 3-layer toggle check
)
```

## Setup checklist

### 1. `vault_config.yaml`

```yaml
secrets:
  enabled: true                  # global ON
  vault:
    machine: "openshift"         # or "tprd" / "test"
    token_method: "JWT"          # or "approle"
    disk_cache_path: "/usr/local/spark/pvc/code/.cache/etl_secrets.enc"
  refs:
    my_oracle_dest:
      type:       "DB_accounts"
      auth_url:   "https://vault.corp/v1/auth/kubernetes/login"
      role_name:  "etl-dest-writer"
      role_type:  "JWT"
      secret_url: "https://vault.corp/v1/database/creds/etl_dest_role"
```

### 2. Workflow yaml (oracle / starburst / s3)

```yaml
oracle:
  destination:
    password: ""                       # blank => loader fires
    secret_ref: "my_oracle_dest"       # points at vault_config.yaml ref
```

### 3. Pod env vars (Helm)

| Var | Long-running pod | Spark/ephemeral pod |
|---|---|---|
| `ETL_USE_VAULT` | `1` | `1` |
| `ETL_SECRETS_KEY` | `<44-char Fernet, same all pods>` | same |
| `ETL_CRED_REFRESH_HOURS` | `24` | not needed (auto-skipped) |
| `ETL_SECRETS_ALLOW_PLAINTEXT` | unset | unset |

The 24h refresh daemon **auto-skips on Spark pods** (detects `SPARK_HOME`
env var or active `pyspark.SparkContext`). Override with
`QS_CRED_DAEMON_FORCE=1` if needed.

## Cache layers (what hits Vault)

```
Caller calls resolve_db_account("name")
   ↓
1. In-process mem cache (15 min)         hit -> return (µs)
   ↓ miss
2. Disk Fernet cache on PVC (24 h)       hit -> warm mem + return
   ↓ miss
3. Vault HTTP call (QSClient 3-step)     populate both layers + return
   ↓ vault returns blank/invalid
4. Retry once                            still bad -> serve stale OR raise
```

## Three-layer enable toggle

```
1. ETL_USE_VAULT env var ("1"/"0" forces ON/OFF)         HIGHEST
2. per-workflow yaml ``vault_enabled`` flag
3. global ``secrets.enabled`` in vault_config.yaml       LOWEST
   default: false (dev-safe)
```

## Operational cheat sheet

| Goal | Action |
|---|---|
| Add a new vault secret | Add entry under `secrets.refs.<name>` in vault_config.yaml; blank password + add `secret_ref` in workflow yaml |
| Force-refresh after rotation | Admin endpoint: invalidates cache + re-fetches. Otherwise wait for mem_ttl (15 min) |
| Disable for one workflow | Set `vault_enabled: false` in that workflow's yaml |
| Emergency disable globally | `ETL_USE_VAULT=0` in pod env, falls back to literal yaml |
| Rotate Fernet key | Update `ETL_SECRETS_KEY` Helm secret, restart pods. Cache regenerates on next miss. |
| Inspect cache | File at `disk_cache_path` (Fernet-encrypted). Use the test hook `disk_cache_clear()` to wipe |

## Auth-failure self-heal

Wrap connector constructors so a rotated password recovers on the
next request (not the next mem_ttl expiry):

```python
from qs_credentials import resolve_with_auth_retry

def _open_oracle(creds):
    return oracledb.connect(
        user=creds[0], password=creds[1], dsn=dsn,
    )

conn = resolve_with_auth_retry(
    "my_oracle_dest", _open_oracle,
    secret_type="DB_accounts",
)
```

On auth failure: invalidate cache + re-resolve from Vault + retry once.
Second failure propagates.

## Failure modes

| Symptom | Cause | Fix |
|---|---|---|
| `secret_ref={name!r} not found` | typo in workflow yaml | check name matches an entry in vault_config.yaml `secrets.refs.<name>` |
| `vault resolution is DISABLED` | one of the 3 toggle layers said no | error message names all 3; flip the right one |
| `QSClient returned None` | machine token / vault auth / secret URL config bad | check pod's machine identity file `/var/run/secrets/token/vault-token` exists; verify auth_url/role_name |
| `invalid/blank payload after 2 attempts` | Vault mid-rotation returning blanks | wait 60s for short-TTL retry; check Vault audit log |
| 50/50 pods got "disk cache disabled" | Fernet key mismatch across pods | ensure `ETL_SECRETS_KEY` is set via Helm secret on every pod, NOT auto-generated per-pod |

## Dual-copy notice

This package is duplicated byte-for-byte between:
- `ETL/qs_credentials/` (this folder)
- `backend/core/qs_credentials/` (QueryStudio API pod)

CI test `TestSyncedCopies` fails if the shared library files (`cache.py`
+ `vault/*`) drift between the two trees. Any edit to one MUST land in
the other in the same commit.

The pod-specific facade (`resolver.py` + `__init__.py`) is allowed to
differ -- ETL reads from yaml, QueryStudio reads from the
`system_accounts` DB table.
