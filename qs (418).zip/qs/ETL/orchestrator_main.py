"""Combined entry for sync + cron in ONE pod.

Same APScheduler drives:
  - Oracle proc jobs (loaded from cron_jobs.yaml)
  - Sync cycles (loaded from sync_tables.yaml, optional `schedule:` per triple)

FastAPI surface:
  GET  /health                       — liveness/readiness
  GET  /jobs                         — last-N outcomes per cron job
  POST /sync/run/{logical_name}      — ad-hoc sync trigger
  POST /sync/run                     — run every triple once
"""
from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
from pathlib import Path

import yaml
from fastapi import FastAPI, HTTPException

from ETL.cron.airflow_client import AirflowConfig, AirflowDispatcher
from ETL.cron.proc_runner import ProcRunner
from ETL.cron.scheduler import CronScheduler
from ETL.sync.comparator import TableComparator
from ETL.sync.dispatcher import SyncDispatcher
from ETL.sync.main import (
    build_connectors,
    build_dispatcher,
    build_idempotency,
    load_triples,
)
from ETL.sync.orchestrator import SyncOrchestrator

_log = logging.getLogger("etl.orchestrator")


def _build_proc_runner() -> ProcRunner:
    from ETL.managers.oracledblib import OracleDBLib  # type: ignore
    return ProcRunner(invoker=OracleDBLib())


def _build_airflow() -> AirflowDispatcher | None:
    if "AIRFLOW_BASE_URL" not in os.environ:
        _log.warning(
            "[orch] AIRFLOW_BASE_URL not set — proc jobs with dispatch_rule "
            "!= proc_only will log errors instead of firing.",
        )
        return None
    return AirflowDispatcher(AirflowConfig.from_env())


def _wire_sync_into_scheduler(
    sched: CronScheduler,
    sync_orch: SyncOrchestrator,
    triples_path: Path,
) -> dict:
    """Read sync_tables.yaml.  Each triple with a `cron_schedule:`
    becomes a callback job on the shared APScheduler AND its cron
    expression is registered with the idempotency store so the
    suppression window matches the cycle interval.  Return a
    {logical_name: triple} map for the REST endpoints to use."""
    triples, _data = load_triples(triples_path)
    name_to_triple = {t.logical_name: t for t in triples}

    # Push each triple's cron expression into the idempotency store so
    # cron_to_window() can derive the per-triple suppression window.
    # InMemory and Oracle implementations both expose set_cron_for_triple.
    set_cron = getattr(sync_orch._idempotency, "set_cron_for_triple", None)  # noqa: SLF001
    if set_cron is not None:
        for t in triples:
            set_cron(t.logical_name, t.cron_schedule or "")

    for triple in triples:
        sched_expr = triple.cron_schedule
        if not sched_expr:
            continue
        # Closure-captured callback — runs one sync cycle for this triple
        def _make_cb(t=triple):
            def _cb():
                _log.info("[orch.sync-fire] cycle start triple=%s", t.logical_name)
                try:
                    sync_orch.run(t)
                except Exception as exc:
                    _log.error(
                        "[orch.sync-fire] cycle failed triple=%s: %s",
                        t.logical_name, exc, exc_info=True,
                    )
            return _cb
        sched.add_callback_job(
            name=f"sync:{triple.logical_name}",
            schedule=sched_expr,
            callback=_make_cb(),
            timezone=triple.timezone,
        )
        _log.info(
            "[orch] sync triple=%s scheduled at %r tz=%s",
            triple.logical_name, sched_expr, triple.timezone,
        )
    return name_to_triple


def main(argv=None) -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )
    p = argparse.ArgumentParser(description="ETL Orchestrator (sync + cron)")
    p.add_argument("--cron-config", default="ETL/configs/cron_jobs.yaml")
    p.add_argument("--sync-config", default="ETL/configs/sync_tables.yaml")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=9100)
    args = p.parse_args(argv)

    # ── Wire shared building blocks ──────────────────────────────────
    proc_runner = _build_proc_runner()
    airflow = _build_airflow()
    sched = CronScheduler(proc_runner=proc_runner, airflow=airflow)

    # Build sync orchestrator
    sync_triples, sync_data = load_triples(Path(args.sync_config))
    sync_orch = SyncOrchestrator(
        comparator=TableComparator(connectors=build_connectors()),
        dispatcher=build_dispatcher(),
        idempotency=build_idempotency(),
        proc_name=sync_data.get(
            "default_proc_name", "OTG_PKG_RECONCILE.SYNC_ONE_GROUP",
        ),
        polling_threshold=int(sync_data.get("polling_threshold", 500_000)),
    )

    # ── Load + start scheduler (proc jobs + sync cycles share one engine) ─
    sched.load_yaml(Path(args.cron_config))
    name_to_triple = _wire_sync_into_scheduler(
        sched, sync_orch, Path(args.sync_config),
    )
    sched.start()

    # ── FastAPI surface ──────────────────────────────────────────────
    app = FastAPI(title="ETL Orchestrator (sync + cron)")

    @app.get("/health")
    def health():
        return {
            "ok": True,
            "cron_jobs": list(sched._jobs.keys()),  # noqa: SLF001 — inspection only
            "sync_triples": list(name_to_triple.keys()),
        }

    @app.get("/jobs")
    def jobs():
        return sched.status()

    @app.post("/sync/run/{logical_name}")
    def sync_run_one(logical_name: str):
        triple = name_to_triple.get(logical_name)
        if triple is None:
            raise HTTPException(404, f"Unknown logical_name={logical_name!r}")
        return sync_orch.run(triple).__dict__

    @app.post("/sync/run")
    def sync_run_all():
        return [
            {"logical_name": t.logical_name, "result": sync_orch.run(t).__dict__}
            for t in name_to_triple.values()
        ]

    # ── Graceful shutdown ────────────────────────────────────────────
    def _shutdown(*_):
        _log.info("[orch] received signal — stopping scheduler")
        sched.stop(wait=True)
    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
