"""StepExecutor — production-grade step orchestrator.

Workflow-agnostic.  Used by FileWorker, SapOdataWorker, OracleWorker,
S3QueryWorker, and any future worker.  ONE responsibility: run an
ordered sequence of step classes on a single task dict, with:

  * Single-file logging   — every module writes to the path pinned by
                            ``log_config.set_run_log_file()`` (the
                            standalone calls this BEFORE dispatch so
                            the whole run lands in one file).  No
                            CentralizedLogger / no rolling handlers —
                            stdlib FileHandler only.
  * Retry + backoff       — outer retry for whole-step transient
                            errors.  Steps that do their own chunk-level
                            categorization (Starburst FATAL / RETRYABLE
                            / SKIPPABLE) handle internal retry; this
                            handles infra transients on top.
  * Status updates        — every step pushes INPROGRESS / COMPLETED /
                            FAILED via the existing
                            ``update_otg_etl_batch_status`` SP.
  * Halt-on-failure       — first failure halts the run and re-raises
                            so the standalone's except branch fires
                            (RunArtifacts cleanup + failure email).
  * Step status verify    — after every step, re-read the DB row to
                            confirm the upstream update landed.  Cuts
                            the "step ran but DB never saw it"
                            diagnostic class.

task_events parsing:
  * ``task['task_events']`` — JSON list of ``{task_steps, SEQ}`` dicts.
  * Fallback: single step from ``task['task_steps'] + task['seq']``.

Pre-Phase-PRD this class lived in ``step_executor.py`` AND
``step_executor_prd.py`` — they've now been merged here.  The _prd
module is kept as a thin re-export for back-compat.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, Callable, Dict, List, Optional

try:
    from log_config import build_module_logger
except Exception:  # pragma: no cover — log_config optional in some test envs
    build_module_logger = None  # type: ignore


_DEFAULT_TRANSIENT_PATTERNS = (
    "timeout", "timed out", "503", "service unavailable",
    "connection reset", "temporarily unavailable", "broken pipe",
)


def _is_transient(exc: BaseException) -> bool:
    msg = str(exc).lower()
    return any(p in msg for p in _DEFAULT_TRANSIENT_PATTERNS)


class StepExecutor:
    """Production-grade workflow-agnostic step executor.

    Used by every worker.  One instance per task — created with a
    bound worker, calls ``execute_steps`` (or ``execute_step``) once.
    """

    def __init__(
        self,
        worker: Any,
        logger: Optional[logging.Logger] = None,
        max_retries: int = 2,
        retry_backoff_base: int = 2,
        retry_backoff_max: int = 60,
    ):
        self.worker = worker
        self.logger = logger or (
            build_module_logger(__name__, "step_executor")
            if build_module_logger else logging.getLogger(__name__)
        )
        self.max_retries = max_retries
        self.retry_backoff_base = retry_backoff_base
        self.retry_backoff_max = retry_backoff_max
        self.logger.info(
            "StepExecutor initialised: worker=%s max_retries=%d",
            worker.__class__.__name__, max_retries,
        )

    # ----- single step execution ---------------------------------------

    async def execute_step(
        self,
        step_class: Callable,
        task: Dict[str, Any],
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> Any:
        task_id = task.get("run_detail_id")
        dag_run_id = task.get("run_id")
        fk_report_id = task.get("fk_report_id", 0)

        if not task_id or not step_name:
            raise ValueError("execute_step: run_detail_id and step_name are required")

        self.logger.info(
            "→ Step '%s' START | run_detail_id=%s run_id=%s report_id=%s",
            step_name, task_id, dag_run_id, fk_report_id,
        )
        step_start = time.time()
        try:
            step_instance = step_class(
                getattr(self.worker, "starburst_clients", {}),
                self.worker.oracle_data_manager,
                self.worker.logger,
            )
            result = await step_instance.execute(
                task, worker_connection_string, dest_connection_string, step_name,
                *args,
                event_id=kwargs.get("event_id", task_id),
                dag_run_id=dag_run_id,
                fk_report_id=fk_report_id,
            )
            duration = time.time() - step_start
            self.logger.info(
                "✓ Step '%s' OK in %.1fs | run_detail_id=%s", step_name, duration, task_id,
            )
            return result
        except Exception as exc:
            duration = time.time() - step_start
            self.logger.error(
                "✗ Step '%s' FAILED after %.1fs | run_detail_id=%s | %s",
                step_name, duration, task_id, exc,
            )
            raise

    async def execute_step_with_retry(
        self,
        step_class: Callable,
        task: Dict[str, Any],
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> Any:
        """Outer-loop retry for whole-step transient failures.

        Each step class decides what's transient at the chunk / row
        level (Starburst extract step categorizes errors as FATAL /
        RETRYABLE / SKIPPABLE).  This wrapper retries on infra
        transients ("connection reset", "503", "timeout") only.
        """
        last_exc: Optional[BaseException] = None
        for attempt in range(1, self.max_retries + 2):
            try:
                return await self.execute_step(
                    step_class, task, worker_connection_string,
                    dest_connection_string, step_name, *args, **kwargs,
                )
            except Exception as exc:
                last_exc = exc
                if attempt > self.max_retries:
                    break
                if not _is_transient(exc):
                    self.logger.error(
                        "Step '%s' non-transient failure (attempt %d) — not retrying: %s",
                        step_name, attempt, exc,
                    )
                    break
                wait = min(self.retry_backoff_base ** attempt, self.retry_backoff_max)
                self.logger.warning(
                    "Step '%s' transient failure (attempt %d/%d) — retrying in %ds: %s",
                    step_name, attempt, self.max_retries + 1, wait, exc,
                )
                await asyncio.sleep(wait)
        assert last_exc is not None
        raise last_exc

    # ----- multi-step orchestration -----------------------------------

    async def execute_steps(
        self,
        task: Dict[str, Any],
        worker_connection_string: str,
        dest_connection_string: str,
        step_mapping: Dict[str, Callable],
    ) -> Dict[str, Any]:
        """Execute the task's full step sequence in SEQ order."""
        task_id = task.get("run_detail_id")
        dag_run_id = task.get("run_id")
        fk_report_id = task.get("fk_report_id", 0)

        if not task_id or not worker_connection_string or not dest_connection_string:
            raise ValueError(
                "execute_steps: run_detail_id, worker_connection_string, "
                "dest_connection_string are required"
            )

        task_events = self._resolve_task_events(task)
        if not task_events:
            raise ValueError(f"execute_steps: no task events for task {task_id}")

        task_event_names = [e["task_steps"] for e in task_events]
        unsupported = [n for n in task_event_names if n not in step_mapping]
        if unsupported:
            raise ValueError(
                f"execute_steps: task {task_id} has unsupported step names: {unsupported}"
            )

        results: Dict[str, Any] = {}
        for event in task_events:
            event_name = event["task_steps"]
            event_seq = str(event.get("SEQ", "?"))
            self.logger.info("=" * 72)
            self.logger.info(
                "Running step SEQ=%s name='%s' for run_detail_id=%s",
                event_seq, event_name, task_id,
            )
            self.logger.info("=" * 72)
            step_start = time.time()
            try:
                results[event_name] = await self.execute_step_with_retry(
                    step_mapping[event_name],
                    task,
                    worker_connection_string,
                    dest_connection_string,
                    event_name,
                    event_id=event_seq,
                    dag_run_id=dag_run_id,
                    fk_report_id=fk_report_id,
                )
                duration = time.time() - step_start
                self.logger.info(
                    "Step '%s' completed in %.1fs", event_name, duration,
                )
                await self._verify_step_completed(
                    dag_run_id, task_id, worker_connection_string, event_name,
                )
            except Exception as exc:
                duration = time.time() - step_start
                self.logger.error(
                    "Step '%s' FAILED after %.1fs for task %s: %s",
                    event_name, duration, task_id, exc,
                )
                await self._mark_failed(
                    dag_run_id, task_id, event_name, str(exc), worker_connection_string,
                )
                raise

        await self._mark_completed(
            dag_run_id, task_id, worker_connection_string,
            total=task.get("totalcount") or task.get("consolidated_total") or 0,
        )
        return results

    # ----- helpers ------------------------------------------------------

    def _resolve_task_events(self, task: Dict[str, Any]) -> List[Dict[str, Any]]:
        raw = task.get("task_events")
        if raw is None:
            step_name = task.get("task_steps", "")
            if step_name:
                return [{"task_steps": step_name, "SEQ": task.get("seq", 1)}]
            return []
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"task_events is not valid JSON: {exc}; raw={raw[:120]!r}"
                )
        elif isinstance(raw, list):
            parsed = raw
        else:
            raise ValueError(f"task_events has unexpected type {type(raw).__name__}")
        events = [e for e in parsed if isinstance(e, dict) and "task_steps" in e]
        events.sort(key=lambda e: int(e.get("SEQ", 0)))
        return events

    async def _verify_step_completed(
        self, dag_run_id: Any, task_id: Any,
        worker_connection_string: str, event_name: str,
    ) -> None:
        try:
            df = await self.worker.oracle_data_manager.execute_query_asynch(
                "SELECT TASK_STATUS AS STATUS FROM OTG_AIRFLOW_DAG_RUN_DETAIL "
                "WHERE FK_RUN_ID = :1 AND RUN_DETAIL_ID = :2",
                {"1": dag_run_id, "2": task_id},
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.warning(
                "Could not verify status for step '%s' (run_id=%s, run_detail_id=%s): %s",
                event_name, dag_run_id, task_id, exc,
            )
            return
        if df is None or df.empty:
            self.logger.warning(
                "verify_step_completed: no DB row for run_id=%s run_detail_id=%s — "
                "step '%s' may not have flushed its status",
                dag_run_id, task_id, event_name,
            )
            return
        status = str(df["STATUS"].iloc[0])
        if status != "COMPLETED":
            raise RuntimeError(
                f"Step '{event_name}' returned successfully but OTG_AIRFLOW_DAG_RUN_DETAIL "
                f"shows status={status!r} for run_id={dag_run_id} "
                f"run_detail_id={task_id}. Halting workflow."
            )

    async def _mark_failed(
        self, dag_run_id: Any, task_id: Any, event_name: str,
        error_msg: str, worker_connection_string: str,
    ) -> None:
        try:
            await self.worker.oracle_data_manager.update_otg_etl_batch_status(
                dag_run_id, task_id, "FAILED", event_name, 0, error_msg,
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.error("Failed to mark FAILED for task %s: %s", task_id, exc)

    async def _mark_completed(
        self, dag_run_id: Any, task_id: Any,
        worker_connection_string: str, total: int = 0,
    ) -> None:
        try:
            await self.worker.oracle_data_manager.update_otg_etl_batch_status(
                dag_run_id, task_id, "COMPLETED", "ALL_STEPS", int(total or 0), "",
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.error("Failed to mark final COMPLETED for task %s: %s", task_id, exc)
