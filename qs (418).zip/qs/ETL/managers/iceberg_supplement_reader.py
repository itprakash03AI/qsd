"""Phase 134-P (supplement pruning) — read QueryStudio's
``iceberg_column_stats_supplement_v2`` table from inside the ETL
Spark container.

QS scans iceberg snapshots in the background and persists per-file
column min/max/null counts to a supplement table keyed on
``(bucket, table_prefix, snapshot_id, file_path, column_name)``.
The standalone iceberg-via-Spark path normally has access only to
column bounds Iceberg writers emit in manifests; this reader makes
the QS-scanned supplement bounds available too, so file-level
pruning is possible on columns lacking manifest bounds.

Decoupling
==========

This module imports from ``oracledb`` ONLY — no SQLAlchemy, no
backend coupling.  When the QS DB is something other than Oracle
(SQLite for dev / Postgres for newer deploys), the operator points
``querystudio_db_*`` config at an Oracle-protocol equivalent or
disables supplement pruning via ``use_supplement_pruning: false``.
A future session can add Postgres support via a thin connector
abstraction; for now Oracle-only matches QS's production deployment.

Schema (from backend/core/db/models.py:1060)
============================================
::

  CREATE TABLE iceberg_column_stats_supplement_v2 (
      id            INTEGER PRIMARY KEY,
      bucket        VARCHAR(255)  NOT NULL,
      table_prefix  VARCHAR(512)  NOT NULL,
      snapshot_id   VARCHAR(64)   NOT NULL,
      file_path     VARCHAR(1024) NOT NULL,
      column_name   VARCHAR(255)  NOT NULL,
      connection_id INTEGER       NULL,
      table_name    VARCHAR(255)  NULL,
      lower_bound   VARCHAR(512)  NULL,
      upper_bound   VARCHAR(512)  NULL,
      null_count    BIGINT        DEFAULT 0,
      row_count     BIGINT        DEFAULT 0,
      scanned_at    TIMESTAMP
  );

  -- Indexed by (bucket, table_prefix, snapshot_id, column_name) so
  -- the per-column range-scan below is O(matching rows).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)


_SELECT_BY_COLUMN_SQL = """
    SELECT file_path, lower_bound, upper_bound, null_count, row_count
      FROM iceberg_column_stats_supplement_v2
     WHERE bucket = :1
       AND table_prefix = :2
       AND snapshot_id = :3
       AND LOWER(column_name) = LOWER(:4)
"""
# Phase H (2026-06-08) — case-insensitive column match.  The column-
# stats scanner stores column_name with the parquet schema's case
# (e.g. "BusinessDate"); the SQL filter extractor lowercases predicate
# columns (e.g. "businessdate").  An exact-case match silently misses
# every mixed-case column.  LOWER() on both sides closes the gap.


_MAX_SCANNED_AT_SQL = """
    SELECT MAX(scanned_at)
      FROM iceberg_column_stats_supplement_v2
     WHERE bucket = :1
       AND table_prefix = :2
       AND snapshot_id = :3
"""


# Phase F default freshness window — matches the QS backend default for
# iceberg_db_first.max_age_seconds.  Overridable per-call via the
# ``max_age_seconds`` kwarg.
DEFAULT_MAX_AGE_SECONDS = 3600


class IcebergSupplementReader:
    """Per-(bucket, table_prefix, snapshot_id) supplement-bound reader.

    Instantiate once per Spark job, then call ``bounds_for(column)``
    on each column the WHERE clause references.  Results cached
    in-memory for the lifetime of the reader so a multi-predicate
    query queries the DB at most ``N_filter_columns`` times.

    Fail-OPEN: any error reading the supplement (driver missing,
    connection refused, table missing, query timeout) returns an
    empty dict — caller falls back to using only manifest bounds.
    """

    def __init__(
        self,
        connection_string: str,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
    ):
        self._conn_str = connection_string
        self._bucket = bucket or ""
        self._table_prefix = table_prefix or ""
        self._snapshot_id = str(snapshot_id) if snapshot_id is not None else ""
        # column_name (lowercased) → {file_path: (lower, upper, nulls, rows)}
        self._cache: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]] = {}
        # Phase F: freshness decision cached per-reader so callers can
        # call is_fresh() multiple times cheaply.
        self._is_fresh_cache: Optional[bool] = None
        # Phase G: pool ONE connection across bounds_for() + is_fresh()
        # calls so an N-filter query opens 1 oracledb connection, not N+1.
        # Lazy-initialised on first DB access; closed by .close() or
        # __del__.
        self._pooled_conn: Any = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def close(self) -> None:
        """Close the pooled oracledb connection (if any)."""
        if self._pooled_conn is not None:
            try:
                self._pooled_conn.close()
            except Exception:
                pass
            self._pooled_conn = None

    def _get_conn(self):
        """Lazy-init the pooled connection.  Returns None on import or
        connect failure (caller falls back to manifest-only path)."""
        if self._pooled_conn is not None:
            # Verify still alive — Oracle can drop idle sessions.
            try:
                self._pooled_conn.ping()
                return self._pooled_conn
            except Exception:
                try:
                    self._pooled_conn.close()
                except Exception:
                    pass
                self._pooled_conn = None
        try:
            import oracledb
        except ImportError:
            logger.warning(
                "oracledb not installed — supplement pruning disabled, "
                "falling back to manifest bounds only"
            )
            return None
        try:
            self._pooled_conn = oracledb.connect(self._conn_str)
            return self._pooled_conn
        except Exception as exc:
            logger.warning(
                "supplement: oracledb.connect failed (%s) — falling back",
                exc,
            )
            return None

    def bounds_for(self, column_name: str) -> Dict[str, Tuple[Optional[str], Optional[str], int, int]]:
        """Return ``{file_path: (lower_bound, upper_bound, null_count, row_count)}``
        for the supplement rows matching this reader's identity tuple
        and the given column.

        Empty dict on missing config, driver, or query failure —
        caller treats absence as "use manifest bounds only".
        """
        if not (self._conn_str and self._bucket and self._snapshot_id):
            return {}
        key = column_name.lower()
        if key in self._cache:
            return self._cache[key]

        conn = self._get_conn()
        if conn is None:
            self._cache[key] = {}
            return {}

        rows: Dict[str, Tuple[Optional[str], Optional[str], int, int]] = {}
        try:
            with conn.cursor() as cur:
                cur.execute(
                    _SELECT_BY_COLUMN_SQL,
                    {
                        "1": self._bucket,
                        "2": self._table_prefix,
                        "3": self._snapshot_id,
                        "4": column_name,
                    },
                )
                for file_path, lower, upper, nulls, rcount in cur:
                    rows[file_path] = (
                        lower, upper,
                        int(nulls or 0), int(rcount or 0),
                    )
        except Exception as exc:
            logger.warning(
                "Supplement read failed for column=%s: %s -- INVALIDATING "
                "pooled connection AND entire reader cache (Phase H: "
                "session death must not produce mixed-old/new bounds)",
                column_name, exc,
            )
            # Phase H (2026-06-08) — when Oracle drops the session mid-
            # query (ORA-02396 idle timeout / kill session), ANY prior
            # cached bounds were fetched on the now-dead session.  A
            # subsequent query on the next session would see fresh
            # bounds but old cache.  Nuke EVERYTHING: pooled conn +
            # the entire bounds cache + freshness cache.
            self.close()
            self._cache.clear()
            self._is_fresh_cache = None
            return {}

        logger.info(
            f"Supplement: {len(rows)} bound row(s) for column={column_name} "
            f"in snapshot={self._snapshot_id}"
        )
        self._cache[key] = rows
        return rows

    # ── Phase F (2026-06-08) freshness gate ────────────────────────────

    def is_fresh(
        self,
        max_age_seconds: int = DEFAULT_MAX_AGE_SECONDS,
    ) -> bool:
        """Return True when the supplement has entries for this
        snapshot whose newest scanned_at is within ``max_age_seconds``.

        Mirrors backend/core/iceberg_db_first_reader.is_fresh.  When
        the supplement is stale (or empty for this snapshot), the
        ETL caller MUST fall back to the standard Spark+Iceberg
        reader — pruning on stale bounds risks dropping files that
        a new snapshot added.

        Fail-OPEN on any error: returns False (caller falls back to
        standard path); never raises.  Decision is cached per-reader.
        """
        if self._is_fresh_cache is not None:
            return self._is_fresh_cache
        if not (self._conn_str and self._bucket and self._snapshot_id):
            self._is_fresh_cache = False
            return False
        conn = self._get_conn()
        if conn is None:
            self._is_fresh_cache = False
            return False

        from datetime import datetime, timedelta, timezone
        threshold = datetime.now(timezone.utc) - timedelta(seconds=max_age_seconds)
        fresh = False
        try:
            with conn.cursor() as cur:
                cur.execute(
                    _MAX_SCANNED_AT_SQL,
                    {
                        "1": self._bucket,
                        "2": self._table_prefix,
                        "3": self._snapshot_id,
                    },
                )
                row = cur.fetchone()
                max_scanned = row[0] if row else None
                if max_scanned is None:
                    logger.info(
                        "[supplement] %s/%s snapshot=%s: NOT fresh "
                        "(no rows)",
                        self._bucket, self._table_prefix,
                        self._snapshot_id,
                    )
                else:
                    # Oracle returns naive datetime — treat as UTC.
                    if max_scanned.tzinfo is None:
                        max_scanned = max_scanned.replace(
                            tzinfo=timezone.utc)
                    fresh = max_scanned >= threshold
                    if fresh:
                        logger.info(
                            "[supplement] %s/%s snapshot=%s: FRESH "
                            "(max scanned_at=%s, threshold=%s)",
                            self._bucket, self._table_prefix,
                            self._snapshot_id,
                            max_scanned.isoformat(),
                            threshold.isoformat(),
                        )
                    else:
                        age_seconds = (
                            datetime.now(timezone.utc) - max_scanned
                        ).total_seconds()
                        logger.info(
                            "[supplement] %s/%s snapshot=%s: STALE "
                            "(age=%ds, max_age=%ds) — caller falls "
                            "back to standard iceberg path",
                            self._bucket, self._table_prefix,
                            self._snapshot_id,
                            int(age_seconds), max_age_seconds,
                        )
        except Exception as exc:
            logger.warning(
                "[supplement] freshness check failed for %s/%s "
                "snapshot=%s: %s — caller falls back to standard path",
                self._bucket, self._table_prefix, self._snapshot_id,
                exc,
            )
            fresh = False

        self._is_fresh_cache = fresh
        return fresh

    # ── Test seam ──────────────────────────────────────────────────────

    def _seed_cache(
        self,
        column_name: str,
        bounds: Dict[str, Tuple[Optional[str], Optional[str], int, int]],
    ) -> None:
        """Pre-seed the cache so tests can skip the DB call."""
        self._cache[column_name.lower()] = bounds
