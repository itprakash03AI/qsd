"""Phase F+G (2026-06-08) — type-aware value coercion + iceberg byte
bound decoder for ETL iceberg pruning.

Mirrors backend/core/iceberg_db_first_reader._coerce_filter_value but
kept INSIDE the ETL package so the polling-service container stays
decoupled from the QueryStudio backend (per the s3_query_base.py
docstring at line 36-44).  Same supplement table → same bug class
unless both sides coerce identically.

What the column-stats scanner stores
------------------------------------

backend/core/iceberg_column_stats.py:_decode_stat calls
``str(stat_value)`` on whatever pyarrow returns from
ParquetFile.metadata.row_group(i).column(j).statistics:

  parquet DATE32     -> datetime.date           -> "YYYY-MM-DD"
  parquet TIMESTAMP  -> datetime.datetime       -> "YYYY-MM-DD HH:MM:SS[.fff]"
  parquet INT32/64   -> int                     -> "<digits>"
  parquet DOUBLE     -> float                   -> "<float>"
  parquet BYTE_ARRAY -> bytes (utf-8 decoded)   -> "<text>"
  parquet DECIMAL    -> Decimal (with scale)    -> "<digits>.<digits>"

To compare a user filter value against those stored strings safely,
we coerce the filter value to the SAME shape.  Pure stdlib (no
pyarrow dep) so the lightweight polling pod doesn't pull in Spark
just to coerce a date.

Public API
----------

  * ``coerce_value(value, iceberg_type) -> str | None``
      Returns the supplement-shaped string form of the filter value
      (or None when coercion fails — caller falls back).

  * ``ICEBERG_TYPES``
      Sentinel list of recognised type tags.  Callers can pre-check
      whether a column's iceberg type is something we know how to
      coerce; unknown types fall through to string passthrough.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Optional


logger = logging.getLogger(__name__)


# Order matters for the "starts with" matching in coerce_value (decimal
# is parameterised: decimal(p,s)).
ICEBERG_TYPES = (
    "date", "timestamp", "timestamptz", "timestamp_tz",
    "timestamp with local time zone",
    "int", "integer", "long", "bigint", "smallint", "tinyint",
    "float", "double", "real",
    "decimal", "boolean", "bool", "string",
    # Iceberg transform pseudo-types
    "_transform_day", "_transform_month", "_transform_year",
    "_transform_hour",
    "_month", "_year", "_hour",
)


def _strip_cast_and_quotes(value: str) -> str:
    """Strip DuckDB/Spark ``DATE 'literal'`` cast syntax and surrounding
    quotes that sometimes leak in from sqlglot's literal nodes."""
    v = value.strip()
    upper = v.upper()
    for prefix in ("DATE ", "TIMESTAMP ", "TIME "):
        if upper.startswith(prefix):
            inner = v[len(prefix):].strip()
            if (inner.startswith("'") and inner.endswith("'")) \
                    or (inner.startswith('"') and inner.endswith('"')):
                v = inner[1:-1]
            else:
                v = inner
            break
    if len(v) >= 2 and (
        (v.startswith("'") and v.endswith("'"))
        or (v.startswith('"') and v.endswith('"'))
    ):
        v = v[1:-1]
    return v


def _normalise_type(iceberg_type: str) -> str:
    """Collapse transform pseudo-types to the underlying physical type."""
    t = (iceberg_type or "string").lower().strip()
    if t == "_transform_day":
        return "date"
    if t in ("_transform_month", "_month"):
        return "_month"
    if t in ("_transform_year", "_year"):
        return "_year"
    if t in ("_transform_hour", "_hour"):
        return "_hour"
    return t


def coerce_value(value: Any, iceberg_type: str) -> Optional[str]:
    """Coerce a user-supplied filter value to the string form the
    column-stats scanner stored in iceberg_column_stats_supplement_v2.

    Returns None when the value can't be coerced (caller MUST fall
    back to standard Spark+Iceberg).

    Edge cases handled:
      * DuckDB ``DATE '2025-09-30'`` cast syntax
      * Quoted string values from sqlglot
      * Date-only user input on a TIMESTAMP column (pad to ...00:00:00)
      * ``T`` separator vs space in ISO timestamps
      * Decimal precision -- normalised via Decimal so scale-matching
        relies on the column's actual scale (caller may need to pad
        trailing zeros if their column has scale > the user's input).
    """
    if value is None:
        return None
    t = _normalise_type(iceberg_type)

    # Coerce input to a workable scalar.
    if isinstance(value, str):
        v: Any = _strip_cast_and_quotes(value)
    else:
        v = value

    try:
        if t == "date":
            if isinstance(v, datetime):
                return v.date().isoformat()
            if isinstance(v, date):
                return v.isoformat()
            parsed = datetime.strptime(str(v)[:10], "%Y-%m-%d").date()
            return parsed.isoformat()

        if t in ("timestamp", "timestamptz", "timestamp_tz",
                 "timestamp with local time zone"):
            sv = str(v).strip()
            if "T" in sv:
                sv = sv.replace("T", " ")
            # Date-only -> pad time
            if " " not in sv and len(sv) == 10:
                return f"{sv} 00:00:00"
            # Validate parseable so we surface garbage as a coerce failure
            try:
                if "." in sv:
                    datetime.strptime(sv.split(".")[0], "%Y-%m-%d %H:%M:%S")
                else:
                    datetime.strptime(sv[:19], "%Y-%m-%d %H:%M:%S")
                return sv
            except ValueError:
                return None

        if t in ("int", "integer", "long", "bigint",
                 "smallint", "tinyint"):
            return str(int(v))

        if t in ("float", "double", "real"):
            return str(float(v))

        if t.startswith("decimal"):
            # Phase H (2026-06-08) — extract scale from "decimal(p,s)"
            # and quantize so the user's "123.45" matches the
            # supplement's "123.4500" (str of Decimal preserves scale).
            # Pre-Phase-H this returned "123.45" against a "123.4500"
            # bound -> file pruning silently dropped legitimate matches.
            # Handles "decimal(10,4)", "decimal( 10 , 4 )" (spaces),
            # "DECIMAL(10,4)" (uppercase) by stripping whitespace.
            try:
                user_decimal = Decimal(str(v))
            except (InvalidOperation, ValueError):
                return None
            try:
                stripped = t.replace(" ", "")
                if "(" in stripped and ")" in stripped:
                    inside = stripped[
                        stripped.index("(") + 1: stripped.index(")")]
                    parts = inside.split(",")
                    if len(parts) == 2:
                        scale = int(parts[1])
                        quantum = Decimal(1).scaleb(-scale)
                        return str(user_decimal.quantize(quantum))
                # Bare "decimal" or missing scale -- pass through
                return str(user_decimal)
            except (InvalidOperation, ValueError):
                # If quantize fails (user supplied more digits than
                # scale), fall back to unquantized -- mismatch is
                # still possible but better than dropping the predicate.
                return str(user_decimal)

        if t in ("boolean", "bool"):
            sv = str(v).strip().lower()
            if sv in ("true", "1", "t", "yes"):
                return "True"
            if sv in ("false", "0", "f", "no"):
                return "False"
            return sv

        # Transform pseudo-types: day was already normalised to "date".
        # Month / year / hour go through as raw int days/months/etc.
        if t == "_month":
            # e.g. months-since-epoch -- caller would have transformed
            # the user value already.  Best-effort: stringify.
            return str(v)
        if t == "_year":
            return str(v)
        if t == "_hour":
            return str(v)

        # Default: string passthrough.
        return str(v)
    except Exception as exc:
        logger.debug(
            "coerce_value(%r, %r) failed: %s", value, iceberg_type, exc)
        return None


# ── Partition transform helpers (Phase F.4) ─────────────────────────


def apply_transform_to_value(
    value: Any,
    source_type: str,
    transform: str,
) -> Optional[Any]:
    """Apply an iceberg partition transform to a user filter value so it
    can be compared against the partition bound stored in the manifest.

    Supported transforms (the common date/time partitioning patterns):
      * ``identity`` -> value unchanged
      * ``day``      -> days since 1970-01-01 (int)
      * ``month``    -> months since 1970-01 (int)
      * ``year``     -> years since 1970 (int)
      * ``hour``     -> hours since 1970-01-01 00:00 (int)

    Returns None for unsupported transforms (bucket / truncate) --
    caller must refuse to prune that partition and let Spark+Iceberg's
    native reader handle the partition.

    All inputs accept either parsed datetime/date or string; strings
    are coerced via ``coerce_value`` first.
    """
    t = (transform or "").lower().strip()
    if t in ("", "identity"):
        return value
    if t not in ("day", "month", "year", "hour"):
        return None

    # Parse the value into a comparable datetime/date.
    parsed: Any = None
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, date):
        parsed = datetime(value.year, value.month, value.day)
    elif isinstance(value, str):
        s = _strip_cast_and_quotes(value)
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M", "%Y-%m-%d",
        ):
            try:
                parsed = datetime.strptime(s, fmt)
                break
            except ValueError:
                continue
    if parsed is None:
        return None

    try:
        if t == "day":
            epoch = date(1970, 1, 1)
            d = parsed.date() if isinstance(parsed, datetime) else parsed
            return (d - epoch).days
        if t == "month":
            return (parsed.year - 1970) * 12 + (parsed.month - 1)
        if t == "year":
            return parsed.year - 1970
        if t == "hour":
            base = datetime(1970, 1, 1, tzinfo=parsed.tzinfo)
            if parsed.tzinfo is None and base.tzinfo is not None:
                base = base.replace(tzinfo=None)
            delta = parsed - base
            return int(delta.total_seconds() // 3600)
    except Exception as exc:
        logger.debug(
            "apply_transform_to_value(%r, %r, %r) failed: %s",
            value, source_type, transform, exc)
        return None
    return None


__all__ = [
    "ICEBERG_TYPES",
    "coerce_value",
    "apply_transform_to_value",
    "decode_iceberg_bound",
]


# ── Iceberg byte-bound decoder (Phase G correctness fix) ──────────


def decode_iceberg_bound(raw, iceberg_type: str) -> Optional[str]:
    """Decode a raw iceberg manifest bound (bytes) into the same string
    form the column-stats scanner stores.

    Iceberg spec encodes column bounds as binary little-endian for
    numeric / temporal types, utf-8 for strings, big-endian two's-
    complement for decimal.  pyiceberg's ``DataFile.lower_bounds`` /
    ``upper_bounds`` return RAW bytes keyed by field_id -- the caller
    must decode based on the column's iceberg type.

    Pre-Phase-G, ETL's ``_bytes_to_str`` did ``b.decode('utf-8')`` and
    fell back to ``b.hex()`` -- correct only for STRING columns.  For
    an int32 day count like 20361 (= 0x4F99), the bytes are
    ``b'\\x99O\\x00\\x00'``; utf-8 fails, hex returns ``"994f0000"``;
    the pruner then compared ``"994f0000"`` against the user's
    coerced date string ``"2025-09-30"`` and dropped nothing.  This
    function returns the correct ``"2025-09-30"``.

    Returns None when the type can't be decoded safely (caller treats
    as "no bound" -> conservative keep).
    """
    if raw is None:
        return None
    # pyiceberg sometimes already decodes the bound to a typed Python
    # value (datetime / int / etc).  Detect that case and stringify.
    if not isinstance(raw, (bytes, bytearray)):
        if isinstance(raw, datetime):
            return raw.strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(raw, date):
            return raw.isoformat()
        try:
            return str(raw)
        except Exception:
            return None

    import struct

    t = _normalise_type(iceberg_type)
    try:
        if t in ("string", "varchar", "char", "uuid"):
            try:
                return raw.decode("utf-8")
            except UnicodeDecodeError:
                return raw.hex()

        if t in ("boolean", "bool"):
            return "True" if raw[0] != 0 else "False"

        if t in ("int", "integer", "smallint", "tinyint"):
            val = struct.unpack_from("<i", raw)[0]
            return str(val)

        if t in ("long", "bigint"):
            val = struct.unpack_from("<q", raw)[0]
            return str(val)

        if t == "date":
            # int32 days since 1970-01-01
            days = struct.unpack_from("<i", raw)[0]
            try:
                return (date(1970, 1, 1) + timedelta(days=days)).isoformat()
            except (OverflowError, ValueError):
                return str(days)

        if t in ("timestamp", "timestamptz", "timestamp_tz",
                 "timestamp with local time zone"):
            # int64 microseconds since epoch
            micros = struct.unpack_from("<q", raw)[0]
            try:
                dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + \
                     timedelta(microseconds=micros)
                # Match column-stats scanner format: "YYYY-MM-DD HH:MM:SS"
                # (no tz suffix for naive comparison).
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except (OverflowError, ValueError):
                return str(micros)

        if t == "_month":
            months = struct.unpack_from("<i", raw)[0]
            return str(months)

        if t == "_year":
            years = struct.unpack_from("<i", raw)[0]
            return str(years)

        if t == "_hour":
            hours = struct.unpack_from("<q", raw)[0]
            return str(hours)

        if t in ("float", "real"):
            import math
            val = struct.unpack_from("<f", raw)[0]
            if math.isnan(val) or math.isinf(val):
                return None
            return str(val)
        if t == "double":
            import math
            val = struct.unpack_from("<d", raw)[0]
            if math.isnan(val) or math.isinf(val):
                return None
            return str(val)

        if t.startswith("decimal"):
            # Iceberg §4.1.6: big-endian two's-complement unscaled int.
            # Phase H -- be lenient on type string format:
            # "decimal(10,4)" / "decimal( 10 , 4 )" / "DECIMAL(10,4)"
            # all accepted via whitespace strip + .lower() upstream.
            stripped = t.replace(" ", "")
            if "(" not in stripped or ")" not in stripped:
                return None
            inside = stripped[stripped.index("(") + 1: stripped.index(")")]
            parts = inside.split(",")
            try:
                scale = int(parts[1]) if len(parts) == 2 else 0
            except (ValueError, IndexError):
                return None
            unscaled = int.from_bytes(raw, byteorder="big", signed=True)
            if scale == 0:
                return str(Decimal(unscaled))
            # Preserve scale (trailing zeros) to match what pyarrow's
            # stats.min returns -- str(Decimal('123.4500')) for a
            # decimal(10,4) column gives "123.4500", not "123.45".
            # Without quantize, division drops trailing zeros and the
            # supplement-string compare silently misses.
            divisor = Decimal(10) ** scale
            quotient = Decimal(unscaled) / divisor
            quantum = Decimal(1).scaleb(-scale)
            return str(quotient.quantize(quantum))

        # Unknown type — best-effort utf-8 with replacement.
        return raw.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.debug(
            "decode_iceberg_bound(%r, %r) failed: %s",
            raw, iceberg_type, exc)
        return None
