"""TCP + proxy pre-flight for Trino/Starburst JDBC connections.

2026-06-22 -- operator hit a 2.02-minute hang ending in:
    Caused by: java.net.SocketTimeoutException: Connect timed out
    at io.trino.jdbc.$internal.okhttp3...RealConnection.connectSocket

OkHttp tries 4 attempts at ~30s each before surfacing the error.
Two helpers here:

  * ``tcp_preflight(jdbc_url, timeout=5)`` -- raw socket probe BEFORE
    Spark hands the URL to the JDBC driver.  Fails in ~5s with the
    exact host/port + a checklist (URL typo / NetworkPolicy / proxy)
    instead of sitting silent for 2 minutes.

  * ``enrich_trino_jdbc_url(url)`` -- if HTTP(S)_PROXY env vars are set
    in the pod environment, injects the corresponding ``httpProxy``
    query parameter into the JDBC URL.  Trino JDBC ignores OS-level
    HTTP_PROXY env vars -- proxy MUST be in the URL.

Both functions are best-effort.  ``tcp_preflight`` raises with a
descriptive error on failure; ``enrich_trino_jdbc_url`` returns the
URL unchanged when no proxy is configured (no surprise behaviour).
"""
from __future__ import annotations

import logging
import os
import socket
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse


def _parse_trino_url(url: str):
    """Split ``jdbc:trino://host:port/...`` into (host, port, parsed_url)."""
    raw = url[5:] if url.startswith("jdbc:") else url
    parsed = urlparse(raw)
    host = parsed.hostname or ""
    # Default ports: 443 if SSL=true in query, 8080 otherwise.
    qs = dict(parse_qsl(parsed.query or "", keep_blank_values=True))
    ssl_flag = (qs.get("SSL", "false")).lower() in ("true", "1", "yes")
    port = parsed.port or (443 if ssl_flag else 8080)
    return host, port, parsed, qs


def tcp_preflight(
    jdbc_url: str,
    timeout: float = 5.0,
    logger: Optional[logging.Logger] = None,
) -> None:
    """Open a raw TCP socket to the JDBC URL's host:port and close it.

    2026-06-22 -- FAIL-OPEN BY DEFAULT.  Operator hit "both workflows
    stopped working at OpenShift" after preflight rolled out;
    corporate firewalls in some environments DROP raw TCP probes from
    pods while ALLOWING full HTTPS handshakes (HTTP-aware filtering).
    A strict preflight would block requests the actual JDBC driver
    could have completed.

    Default behaviour now: WARN on failure, return normally -- letting
    the downstream JDBC driver attempt its own connect.  The JDBC
    driver's eventual error is still informative; this helper just
    adds a heads-up log line.

    Strict mode (raise on probe failure) opt-in via env var
    ``TRINO_JDBC_STRICT_PREFLIGHT=1``.

    Skip entirely via ``TRINO_JDBC_SKIP_PREFLIGHT=1``.
    """
    log = logger or logging.getLogger(__name__)
    strict = os.environ.get("TRINO_JDBC_STRICT_PREFLIGHT", "").lower() in ("1", "true", "yes")
    host, port, _, _ = _parse_trino_url(jdbc_url)
    if not host:
        msg = f"Trino JDBC URL has no host component -- check the URL: {jdbc_url!r}"
        if strict:
            raise RuntimeError(msg)
        log.warning(msg)
        return
    log.info("TCP pre-flight: probing %s:%s (timeout=%ss)", host, port, timeout)
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            log.info(
                "TCP pre-flight OK: %s:%s reachable (local=%s)",
                host, port, sock.getsockname(),
            )
        return
    except socket.gaierror as exc:
        diag = (
            f"Trino TCP pre-flight FAILED: DNS could not resolve host "
            f"{host!r} from this pod.\n"
            f"  Underlying error: {exc}\n"
            f"  Checklist:\n"
            f"    1. Is the URL correct?  Got: {jdbc_url!r}\n"
            f"    2. Does the pod have the right cluster DNS / "
            f"/etc/resolv.conf entries?\n"
            f"    3. Is the host an internal name that only resolves "
            f"inside corporate VPN?  Pod may need a CoreDNS rewrite."
        )
    except socket.timeout as exc:
        diag = (
            f"Trino TCP pre-flight FAILED: connect to {host}:{port} timed "
            f"out after {timeout}s.\n"
            f"  Checklist:\n"
            f"    1. Wrong URL or stale dev URL in query_fact_table.json "
            f"/ starburst_config.yaml?  Got: {jdbc_url!r}\n"
            f"    2. OpenShift NetworkPolicy / egress firewall blocking "
            f"pod -> {host}:{port}?\n"
            f"    3. Corporate proxy required?\n"
            f"    4. DNS resolves but port {port} blocked?\n"
            f"  Underlying: {exc}"
        )
    except OSError as exc:
        diag = (
            f"Trino TCP pre-flight FAILED: connect to {host}:{port} raised "
            f"{type(exc).__name__}: {exc}\n"
            f"  URL: {jdbc_url!r}\n"
            f"  Host resolves but connect failed -- check NetworkPolicy + "
            f"Starburst service's actual listen port."
        )

    # Probe failed.  Default = WARN AND CONTINUE (let JDBC driver try);
    # strict mode = raise (legacy behaviour, opt-in).
    if strict:
        raise RuntimeError(diag)
    log.warning(
        "%s\n  ** Continuing anyway (FAIL-OPEN default) -- the JDBC "
        "driver will attempt its own connect.  Set "
        "TRINO_JDBC_STRICT_PREFLIGHT=1 to abort on probe failure.",
        diag,
    )


def enrich_trino_jdbc_url(
    jdbc_url: str,
    logger: Optional[logging.Logger] = None,
) -> str:
    """If HTTP(S)_PROXY env vars are set, inject ``httpProxy=host:port`` into
    the JDBC URL.  Returns the URL unchanged if no proxy is configured OR
    if the URL already has an ``httpProxy`` param.

    Trino JDBC driver requires the proxy in the URL -- it ignores
    OS-level HTTP_PROXY env vars.  This helper bridges that gap so the
    pod's existing proxy env vars actually take effect.
    """
    log = logger or logging.getLogger(__name__)
    # Operator can disable enrichment with TRINO_JDBC_NO_PROXY_ENRICH=1
    if os.environ.get("TRINO_JDBC_NO_PROXY_ENRICH", "").lower() in ("1", "true", "yes"):
        return jdbc_url

    raw = jdbc_url[5:] if jdbc_url.startswith("jdbc:") else jdbc_url
    parsed = urlparse(raw)
    qs = dict(parse_qsl(parsed.query or "", keep_blank_values=True))

    # Don't overwrite an explicit JDBC-URL proxy setting.
    if "httpProxy" in qs or "socksProxy" in qs:
        log.info("Trino JDBC URL already has proxy param -- leaving as-is")
        return jdbc_url

    # Prefer HTTPS_PROXY (most Starburst URLs are HTTPS), fall back to HTTP_PROXY.
    proxy_env = (
        os.environ.get("HTTPS_PROXY")
        or os.environ.get("https_proxy")
        or os.environ.get("HTTP_PROXY")
        or os.environ.get("http_proxy")
        or ""
    ).strip()
    if not proxy_env:
        return jdbc_url

    proxy_parsed = urlparse(
        proxy_env if "://" in proxy_env else f"http://{proxy_env}"
    )
    if not proxy_parsed.hostname:
        log.warning(
            "HTTP(S)_PROXY=%r could not be parsed as a host:port -- "
            "leaving JDBC URL unchanged", proxy_env,
        )
        return jdbc_url
    proxy_port = proxy_parsed.port or (443 if proxy_parsed.scheme == "https" else 80)
    qs["httpProxy"] = f"{proxy_parsed.hostname}:{proxy_port}"

    new_query = urlencode(qs)
    enriched = urlunparse(parsed._replace(query=new_query))
    if jdbc_url.startswith("jdbc:"):
        enriched = "jdbc:" + enriched
    log.info(
        "Trino JDBC URL enriched with httpProxy=%s (from env)",
        qs["httpProxy"],
    )
    return enriched
