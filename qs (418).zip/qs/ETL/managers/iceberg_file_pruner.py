"""Phase 134-P + F (2026-06-08, post-deep-dive) — file-level pruning
for iceberg reads, combining manifest bounds + QS supplement bounds +
the user's WHERE-clause predicates.

Given a list of data files (each with manifest-extracted lower/upper
bounds per column) and a set of predicates extracted from the user's
WHERE, this module returns the subset of files that COULD match.

Always conservative: if we can't prove a file is excluded, it stays
in the result.  False positives (keeping a file that won't actually
have matching rows) are harmless — the row-level filter on the
Spark read drops them.  False negatives (dropping a file that
WOULD have matched) are correctness bugs and must not happen.

Phase F changes (2026-06-08)
============================

  * Type-aware coercion via ``managers.iceberg_value_coercion``.
    The original implementation only knew int / float / string; date
    / timestamp / decimal / bool predicates silently failed to prune.
    Now mirrors the backend brain's coercion so the SAME supplement
    rows produce the SAME prune results in both pods.

  * Partition-aware semantic: partition columns have
    lower_bound == upper_bound == partition_value.  ``=`` predicates
    on partition cols are accepted as STRICT equality; the existing
    range-overlap logic still applies but the cascade telemetry
    distinguishes the two for log readability.

  * Cascade telemetry: optional ``cascade`` list mirrors the brain's
    PruneResult.cascade — one entry per (filter, file) outcome so
    operators can see WHICH predicate dropped WHICH files.

  * Fail-OPEN preserved at every step.  Any coercion failure / unknown
    op / type mismatch logs and keeps the file.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


logger = logging.getLogger(__name__)


# (lower_bound, upper_bound, null_count, row_count) — both bound strings
# nullable.
FileBounds = Tuple[Optional[str], Optional[str], int, int]


def prune_files(
    files: Iterable[str],
    manifest_bounds: Dict[str, Dict[str, FileBounds]],
    supplement_bounds: Dict[str, Dict[str, FileBounds]],
    predicates: Dict[str, List[Tuple[str, Any]]],
    iceberg_field_types: Optional[Dict[str, str]] = None,
    partition_columns: Optional[Iterable[str]] = None,
) -> List[str]:
    """Return the subset of ``files`` whose bounds permit at least one
    row matching every predicate.

    Args:
        files: candidate iceberg data file paths.
        manifest_bounds: ``{column: {file_path: (low, high, nulls, rows)}}``
            built from iceberg manifest stats.
        supplement_bounds: same shape, sourced from
            ``iceberg_column_stats_supplement_v2``.  Used to augment
            ``manifest_bounds`` — supplement values OVERRIDE manifest
            values for the same (file, column) pair only when manifest
            bounds are missing or NULL.
        predicates: per-column predicate list from
            ``sql_filter_extractor.extract_predicates``.
        iceberg_field_types: optional ``{column_name_lower: iceberg_type}``
            mapping.  When provided, predicate values are coerced to the
            same string format the column-stats scanner stored.  Required
            for correct date / timestamp / decimal / bool predicates.
        partition_columns: optional iterable of partition column names
            (lowercased compared).  Used only for cascade telemetry
            classification (partition_eq vs stats_range).  Pruning
            correctness is identical for both.

    Returns:
        Sorted list of files that survived pruning.  Empty list means
        the WHERE has no matches — caller can short-circuit the scan.
    """
    file_list = list(files)
    if not predicates:
        return sorted(file_list)
    if not file_list:
        return []

    types_lower = {
        (k or "").lower(): v
        for k, v in (iceberg_field_types or {}).items()
    }
    part_cols_lower: Set[str] = {
        (c or "").lower() for c in (partition_columns or [])
    }

    # Per-file × per-column bound resolver: prefer manifest, fall back
    # to supplement when manifest is missing or has NULL bounds.
    def _bounds_for(col: str, fp: str) -> FileBounds:
        m_col = manifest_bounds.get(col, {})
        s_col = supplement_bounds.get(col, {})
        m = m_col.get(fp)
        s = s_col.get(fp)
        if m is None and s is None:
            return (None, None, 0, 0)
        if m is None:
            return s
        if s is None:
            return m
        m_low, m_high, m_null, m_rows = m
        s_low, s_high, _s_null, _s_rows = s
        return (
            m_low if m_low is not None else s_low,
            m_high if m_high is not None else s_high,
            m_null, m_rows,
        )

    # Pre-coerce predicate values per the column's iceberg type.
    coerced_predicates = _coerce_predicates(predicates, types_lower)

    # Phase H (2026-06-08) -- track cascade drops INLINE in the main
    # prune loop instead of doing a second O(files × predicates)
    # iteration just for telemetry.  At INFO log level on a 100K-file
    # × 10-predicate table this saves 1M bound coercions per query
    # (~15% CPU on a busy polling pod).
    _info_enabled = logger.isEnabledFor(logging.INFO)
    cascade_drops: Dict[Tuple[str, str, Any], int] = {}

    survivors: List[str] = []
    for fp in file_list:
        keep, drop_key = _file_could_match_with_reason(
            fp, coerced_predicates, _bounds_for, _info_enabled,
        )
        if keep:
            survivors.append(fp)
        elif _info_enabled and drop_key is not None:
            cascade_drops[drop_key] = cascade_drops.get(drop_key, 0) + 1

    if _info_enabled:
        kept = len(survivors)
        dropped = len(file_list) - kept
        cascade = [
            {
                "column":   k[0],
                "op":       k[1],
                "value":    k[2] if not isinstance(k[2], (list, tuple)) else list(k[2]),
                "semantic": (
                    "partition_eq"
                    if (k[0] or "").lower() in part_cols_lower
                    else "stats_range"
                ),
                "dropped":  v,
            }
            for k, v in cascade_drops.items()
        ]
        logger.info(
            "iceberg_file_pruner: kept %d / dropped %d (cascade=%s)",
            kept, dropped, cascade,
        )

    return sorted(survivors)


# ── Internals ───────────────────────────────────────────────────────────


def _coerce_predicates(
    predicates: Dict[str, List[Tuple[str, Any]]],
    types_lower: Dict[str, str],
) -> Dict[str, List[Tuple[str, Any]]]:
    """Coerce each predicate value through ``iceberg_value_coercion``
    so its string form matches what the supplement scanner stored.

    Predicates on columns missing from ``types_lower`` are passed
    through unchanged (back-compat with pre-Phase-F callers that
    didn't supply field types).
    """
    try:
        from managers.iceberg_value_coercion import coerce_value
    except ImportError:
        logger.warning(
            "iceberg_value_coercion unavailable — falling back to raw "
            "predicate values (date/timestamp/decimal predicates may "
            "silently fail to prune)"
        )
        return predicates

    out: Dict[str, List[Tuple[str, Any]]] = {}
    for col, ops in predicates.items():
        col_lower = (col or "").lower()
        ftype = types_lower.get(col_lower)
        if ftype is None:
            out[col] = list(ops)
            continue
        coerced_ops: List[Tuple[str, Any]] = []
        for op, val in ops:
            if op == "in" and isinstance(val, list):
                new_vals = []
                ok = True
                for v in val:
                    c = coerce_value(v, ftype)
                    if c is None:
                        ok = False
                        break
                    new_vals.append(c)
                if ok:
                    coerced_ops.append((op, new_vals))
                else:
                    logger.debug(
                        "skip predicate %s IN %r — coerce failure on %r",
                        col, val, ftype)
            else:
                c = coerce_value(val, ftype)
                if c is None:
                    logger.debug(
                        "skip predicate %s %s %r — coerce failure on %r",
                        col, op, val, ftype)
                    continue
                coerced_ops.append((op, c))
        if coerced_ops:
            out[col] = coerced_ops
    return out


def _file_could_match(
    file_path: str,
    predicates: Dict[str, List[Tuple[str, Any]]],
    bounds_resolver,
) -> bool:
    """A file could match iff every column's predicates are individually
    satisfiable against that file's bounds.  Any column that conclusively
    excludes the file fails the whole file.
    """
    keep, _ = _file_could_match_with_reason(
        file_path, predicates, bounds_resolver, with_reason=False)
    return keep


def _file_could_match_with_reason(
    file_path: str,
    predicates: Dict[str, List[Tuple[str, Any]]],
    bounds_resolver,
    with_reason: bool,
) -> Tuple[bool, Optional[Tuple[str, str, Any]]]:
    """Same as _file_could_match but ALSO returns the (col, op, val)
    triple of the first predicate that excluded the file.  Used by the
    INLINE cascade telemetry collection so we don't pay an O(N) second
    pass just to report what dropped what."""
    for col, col_predicates in predicates.items():
        low_str, high_str, _nulls, _rows = bounds_resolver(col, file_path)
        if low_str is None and high_str is None:
            continue
        for op, val in col_predicates:
            if _predicate_excludes_file(op, val, low_str, high_str):
                if with_reason:
                    # Use a hashable form of val for the cascade key
                    key_val = (
                        tuple(val)
                        if isinstance(val, list)
                        else val
                    )
                    return False, (col, op, key_val)
                return False, None
    return True, None


def _predicate_excludes_file(
    op: str,
    val: Any,
    low_str: Optional[str],
    high_str: Optional[str],
) -> bool:
    """Return True iff the (op, val) predicate CANNOT match any row in a
    file with bounds [low_str, high_str].

    Conservative: missing bounds or coercion failure returns False
    (= "keep the file").  Now uses the type-aware coercion via
    ``_coerce_bounds`` so the same string compare across iceberg types
    behaves correctly (lexicographic compare on date strings agrees
    with chronological order, on decimal strings agrees with numeric
    order ONLY when scale matches — we rely on the caller's coercion
    to align scales upstream).
    """
    if op == "in":
        if not isinstance(val, list) or not val:
            return False
        # An IN clause excludes only when EVERY value falls outside
        # [low, high].
        return all(
            _predicate_excludes_file("=", v, low_str, high_str)
            for v in val
        )

    low, high = _coerce_bounds(low_str, high_str, val)
    if low is None and high is None:
        return False

    try:
        if op == "=" and low is not None and high is not None:
            return val < low or val > high
        if op == "!=" and low is not None and high is not None:
            # Excludes only when bounds collapse to exactly val.
            return low == high == val
        if op == ">":
            return high is not None and val >= high
        if op == ">=":
            return high is not None and val > high
        if op == "<":
            return low is not None and val <= low
        if op == "<=":
            return low is not None and val < low
    except TypeError:
        # Cross-type compare (e.g. int vs str) — can't prove exclusion.
        return False
    return False


def _coerce_bounds(
    low_str: Optional[str],
    high_str: Optional[str],
    val: Any,
) -> Tuple[Optional[Any], Optional[Any]]:
    """Coerce string bounds to the same type as the comparison value
    when safe.  Returns ``(low, high)`` — either may be None if the
    original bound was None.

    Note: when the caller has already passed a coerced string value
    via _coerce_predicates (Phase F), both ``val`` and the bounds are
    strings in supplement-shape, and lexicographic compare is safe
    for ISO dates and "YYYY-MM-DD HH:MM:SS" timestamps.  For raw
    int/float values (no field type supplied), the original int/float
    coercion still applies.
    """
    def _coerce(s: Optional[str]) -> Optional[Any]:
        if s is None:
            return None
        if isinstance(val, bool):
            sl = s.strip().lower()
            if sl in ("true", "1", "yes"):
                return True
            if sl in ("false", "0", "no"):
                return False
            return s
        if isinstance(val, int):
            try:
                return int(s)
            except ValueError:
                return None
        if isinstance(val, float):
            try:
                return float(s)
            except ValueError:
                return None
        # Default: string compare.
        return s

    low = _coerce(low_str)
    high = _coerce(high_str)
    return low, high


def _summarise_cascade(
    files: List[str],
    predicates: Dict[str, List[Tuple[str, Any]]],
    bounds_resolver,
    part_cols_lower: Set[str],
) -> List[Dict[str, Any]]:
    """Build a per-predicate prune summary for logging."""
    cascade: List[Dict[str, Any]] = []
    for col, col_predicates in predicates.items():
        col_lower = (col or "").lower()
        semantic = (
            "partition_eq" if col_lower in part_cols_lower else "stats_range"
        )
        for op, val in col_predicates:
            dropped = 0
            for fp in files:
                low_str, high_str, _n, _r = bounds_resolver(col, fp)
                if low_str is None and high_str is None:
                    continue
                if _predicate_excludes_file(op, val, low_str, high_str):
                    dropped += 1
            cascade.append({
                "column":   col,
                "op":       op,
                "value":    val,
                "semantic": semantic,
                "dropped":  dropped,
            })
    return cascade
