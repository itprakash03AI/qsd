"""
QueryStudio ETL Bridge — connects Oracle ETL pipeline to QueryStudio monitoring.

All calls are try/except with graceful degradation — if QS is unreachable,
the Oracle ETL pipeline continues to run normally without monitoring.

Usage in oracle_standalone.py:
    bridge = QueryStudioBridge.from_config(config)
    if bridge:
        exec_id = bridge.register_execution(pipeline_id, triggered_by)
        # ... run steps ...
        bridge.report_completion(exec_id, "completed", {"output_row_count": 1000})
"""
import logging
from typing import Dict, Any, Optional

try:
    import requests
except ImportError:
    requests = None

logger = logging.getLogger(__name__)


class QueryStudioBridge:
    """Bridge between Oracle ETL and QueryStudio ETL monitoring."""

    def __init__(self, qs_api_url: str, api_key: Optional[str] = None, timeout: int = 30):
        """
        Args:
            qs_api_url: QueryStudio API base URL (e.g., "http://querystudio-api:8000")
            api_key: Optional API key for authentication
            timeout: Request timeout in seconds
        """
        if requests is None:
            raise ImportError("requests library required for QueryStudioBridge")

        self.base_url = qs_api_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        if api_key:
            self.session.headers['Authorization'] = f'Bearer {api_key}'
        self.session.headers['Content-Type'] = 'application/json'

    @classmethod
    def from_config(cls, config: Dict) -> Optional['QueryStudioBridge']:
        """Create bridge from config dict. Returns None if QS not configured."""
        qs_config = config.get('querystudio', {})
        if not qs_config.get('enabled', False):
            logger.info("QueryStudio bridge disabled (querystudio.enabled=false)")
            return None

        api_url = qs_config.get('api_url', '')
        if not api_url:
            logger.warning("QueryStudio bridge: no api_url configured")
            return None

        try:
            bridge = cls(
                qs_api_url=api_url,
                api_key=qs_config.get('api_key'),
                timeout=qs_config.get('timeout', 30),
            )
            logger.info(f"QueryStudio bridge initialized: {api_url}")
            return bridge
        except Exception as e:
            logger.warning(f"QueryStudio bridge init failed: {e}")
            return None

    def register_execution(self, pipeline_id: int, triggered_by: str) -> Optional[str]:
        """
        Register a new execution with QueryStudio.
        POST /api/etl-pipelines/{pipeline_id}/trigger

        Returns execution_id string, or None on failure.
        """
        try:
            resp = self.session.post(
                f"{self.base_url}/api/etl-pipelines/{pipeline_id}/trigger",
                json={
                    "trigger_type": "external",
                    "triggered_by": triggered_by,
                },
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            exec_id = data.get("execution_id")
            logger.info(f"QS execution registered: {exec_id}")
            return exec_id
        except Exception as e:
            logger.warning(f"QS register_execution failed (non-fatal): {e}")
            return None

    def report_step_status(
        self, execution_id: str, step_name: str, status: str,
        row_count: int = 0, duration_seconds: float = 0, error: str = ""
    ) -> bool:
        """
        Report step-level status to QueryStudio via webhook.
        POST /api/webhooks/etl-complete (partial update)

        Returns True on success, False on failure.
        """
        if not execution_id:
            return False

        try:
            payload = {
                "execution_id": execution_id,
                "state": "running",  # intermediate — not final
                "step_name": step_name,
                "step_status": status,
                "output_row_count": row_count,
                "duration_seconds": duration_seconds,
            }
            if error:
                payload["error"] = error

            resp = self.session.post(
                f"{self.base_url}/api/webhooks/etl-complete",
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return True
        except Exception as e:
            logger.warning(f"QS report_step_status failed (non-fatal): {e}")
            return False

    def report_completion(
        self, execution_id: str, state: str, metrics: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Report final completion/failure to QueryStudio.
        POST /api/webhooks/etl-complete

        Args:
            execution_id: From register_execution()
            state: "completed" or "failed"
            metrics: Optional dict with keys like output_row_count, duration_seconds, error
        """
        if not execution_id:
            return False

        try:
            payload = {
                "execution_id": execution_id,
                "state": state,
            }
            if metrics:
                payload.update(metrics)

            resp = self.session.post(
                f"{self.base_url}/api/webhooks/etl-complete",
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            logger.info(f"QS execution {execution_id} reported as {state}")
            return True
        except Exception as e:
            logger.warning(f"QS report_completion failed (non-fatal): {e}")
            return False

    def check_circuit_breaker(self, backend: str = "spark_submit") -> str:
        """
        Check QueryStudio circuit breaker status.
        GET /api/admin/etl-pipelines/circuit-breakers

        Returns: "closed" (OK), "open" (degraded), or "unknown" on error.
        """
        try:
            resp = self.session.get(
                f"{self.base_url}/api/admin/etl-pipelines/circuit-breakers",
                timeout=self.timeout,
            )
            resp.raise_for_status()
            breakers = resp.json()
            state = breakers.get(backend, {}).get("state", "unknown")
            if state == "open":
                logger.warning(f"QS circuit breaker for {backend} is OPEN — backend degraded")
            return state
        except Exception as e:
            logger.warning(f"QS circuit breaker check failed (non-fatal): {e}")
            return "unknown"
