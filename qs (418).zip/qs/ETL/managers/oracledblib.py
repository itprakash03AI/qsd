"""
Oracle database library using oracledb (python-oracledb).
Implements DatabaseInterface ABC: execute_procedure, execute_query,
bulk_copy, execute_transaction, fetch_procedure_data.
Plus utility methods: load_csv_to_oracle, load_parquet_to_oracle,
release_connection, fetch_dag_configs, fetch_dag_template_configs,
get_procedure_params.
"""
import csv
import json
import logging
import os
from abc import ABC, abstractmethod
from contextlib import contextmanager
from datetime import datetime
from typing import List, Optional, Dict, Any, Callable, Tuple

import oracledb
import pandas as pd
from pydantic import BaseModel, ValidationError, validator, BaseSettings
from tenacity import retry, stop_after_attempt, wait_exponential

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════
#  ABC + Pydantic models
# ═══════════════════════════════════════════════════════════════════════

class DatabaseInterface(ABC):
    """Abstract base class defining the database operations interface."""

    @abstractmethod
    def execute_procedure(self, procedure_name: str, parameters: Optional[List[Dict]],
                          connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def bulk_copy(self, table_name: str, data: pd.DataFrame,
                  batch_size: Optional[int] = None,
                  connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None,
                      connection_string: Optional[str] = None) -> pd.DataFrame:
        pass

    @abstractmethod
    def execute_transaction(self, statements: List[Tuple[str, Optional[Dict[str, Any]]]],
                            connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def fetch_procedure_data(self, procedure_name: str, parameters: Optional[List[Dict]],
                             connection_string: Optional[str] = None) -> pd.DataFrame:
        pass


class Parameter(BaseModel):
    """Pydantic model for stored procedure parameters."""
    name: str
    value: Any
    direction: str
    type_hint: Optional[str] = None

    @validator('direction')
    def validate_direction(cls, v):
        if v not in ('IN', 'OUT', 'IN OUT'):
            raise ValueError("Direction must be 'IN', 'OUT', or 'IN OUT'")
        return v

    @validator('type_hint')
    def validate_type_hint(cls, v):
        if v and v.upper() not in OracleDBLib.TYPE_MAPPING:
            raise ValueError(f"Invalid type hint: {v}. Must be one of {list(OracleDBLib.TYPE_MAPPING.keys())}")
        return v.upper() if v else v

    @validator('value')
    def validate_json(cls, v, values):
        if values.get('type_hint') == 'JSON' and v is not None:
            if not isinstance(v, (dict, list)):
                raise ValueError("JSON type hint requires dict or list value")
            json.dumps(v)
        return v


class OracleConfig(BaseSettings):
    """Pydantic model for Oracle configuration."""
    pool_min: int = 1
    pool_max: int = 10
    batch_size: int = 1000
    retry_attempts: int = 3
    oracle_user: Optional[str] = None
    oracle_password: Optional[str] = None
    oracle_dsn: Optional[str] = None

    class Config:
        env_prefix = 'ORACLE_'
        case_sensitive = False


# ═══════════════════════════════════════════════════════════════════════
#  OracleDBLib — concrete implementation
# ═══════════════════════════════════════════════════════════════════════

class OracleDBLib(DatabaseInterface):

    TYPE_MAPPING = {
        'NUMBER': oracledb.NUMBER,
        'VARCHAR2': oracledb.STRING,
        'CHAR': oracledb.STRING,
        'CLOB': oracledb.CLOB,
        'NCLOB': oracledb.NCLOB,
        'BLOB': oracledb.BLOB,
        'RAW': oracledb.RAW,
        'DATE': oracledb.DATETIME,
        'TIMESTAMP': oracledb.TIMESTAMP,
        'BINARY_DOUBLE': oracledb.BINARY_DOUBLE,
        'BINARY_FLOAT': oracledb.BINARY_FLOAT,
        'INTERVAL_DS': oracledb.INTERVAL_DS,
        'INTERVAL_YM': oracledb.INTERVAL_YM,
        'JSON': oracledb.JSON,
        'XMLTYPE': oracledb.CLOB,
        'CURSOR': oracledb.CURSOR,
        'BOOLEAN': oracledb.NUMBER,
    }

    PYTHON_TO_ORACLE = {
        int: 'NUMBER',
        float: 'NUMBER',
        str: 'VARCHAR2',
        bytes: 'BLOB',
        bool: 'BOOLEAN',
        datetime: 'DATE',
        dict: 'JSON',
        list: 'JSON',
        None: 'VARCHAR2',
    }

    def __init__(
        self,
        connection_string: Optional[str] = None,
        logger: logging.Logger = logger,
        pool_factory: Callable = oracledb.create_pool,
        config: Optional[OracleConfig] = None,
    ):
        self.logger = logger
        self.pool_factory = pool_factory
        self.config = config or OracleConfig()
        self.default_connection_string = self._resolve_connection_string(connection_string)

        try:
            self.pool = self.pool_factory(
                user=self.default_connection_string['user'],
                password=self.default_connection_string['password'],
                dsn=self.default_connection_string['dsn'],
                min=self.config.pool_min,
                max=self.config.pool_max,
                increment=1,
            )
            self.logger.info("Default connection pool created successfully")
        except oracledb.Error as e:
            self.logger.error(f"Failed to create default connection pool: {str(e)}")
            raise

    # ── Connection helpers ──────────────────────────────────────────────

    def _resolve_connection_string(self, connection_string: Optional[str]) -> Dict[str, str]:
        """Resolve connection string from input or config."""
        if connection_string:
            try:
                user, rest = connection_string.split('/', 1)
                password, dsn = rest.split('@', 1)
                return {'user': user, 'password': password, 'dsn': dsn}
            except ValueError:
                raise ValueError(
                    "Invalid connection string format. Expected 'user/pass@host:port/service'"
                )

        if self.config.oracle_user and self.config.oracle_password and self.config.oracle_dsn:
            return {
                'user': self.config.oracle_user,
                'password': self.config.oracle_password,
                'dsn': self.config.oracle_dsn,
            }

        raise ValueError("No valid connection string provided")

    @contextmanager
    def _get_connection(self, connection_string: Optional[str] = None):
        """Context manager for connection, supporting per-method connection strings."""
        connection = None
        temp_pool = None
        try:
            if connection_string:
                conn_details = self._resolve_connection_string(connection_string)
                temp_pool = self.pool_factory(
                    user=conn_details['user'],
                    password=conn_details['password'],
                    dsn=conn_details['dsn'],
                    min=1, max=1, increment=1,
                )
                connection = temp_pool.acquire()
            else:
                connection = self.pool.acquire()
            yield connection
        except oracledb.Error as e:
            self.logger.error(f"Failed to acquire connection: {str(e)}")
            raise
        finally:
            if connection:
                try:
                    if temp_pool:
                        temp_pool.release(connection)
                        temp_pool.close()
                    else:
                        self.pool.release(connection)
                except Exception as release_err:
                    self.logger.warning(f"Error releasing connection: {release_err}")

    def release_connection(self, connection, connection_string: Optional[str] = None):
        """Release a connection back to the pool (for manual management)."""
        try:
            self.pool.release(connection)
        except Exception as e:
            self.logger.warning(f"Error releasing connection: {e}")

    # ── Validation helpers ──────────────────────────────────────────────

    def _validate_name(self, name: str) -> None:
        """Validate table or procedure name."""
        import re
        if not re.match(r'^[A-Za-z0-9_.]+$', name):
            raise ValueError(f"Invalid name format: {name}")

    def _get_parameter_type(self, value: Any, type_hint: Optional[str],
                            metadata_type: Optional[str]) -> Any:
        """Determine Oracle parameter type."""
        if type_hint and type_hint.upper() in self.TYPE_MAPPING:
            return self.TYPE_MAPPING[type_hint.upper()]
        if metadata_type and metadata_type.upper() in self.TYPE_MAPPING:
            return self.TYPE_MAPPING[metadata_type.upper()]
        return self.TYPE_MAPPING.get(
            self.PYTHON_TO_ORACLE.get(type(value), 'VARCHAR2')
        )

    def _fetch_procedure_metadata(self, procedure_name: str,
                                  connection_string: Optional[str] = None) -> Dict[str, Dict]:
        """Fetch parameter metadata from ALL_ARGUMENTS."""
        try:
            with self._get_connection(connection_string) as connection:
                cursor = connection.cursor()
                try:
                    parts = procedure_name.split('.')
                    if len(parts) == 2:
                        owner, proc_name = parts
                        query = """
                            SELECT ARGUMENT_NAME, DATA_TYPE, IN_OUT
                            FROM ALL_ARGUMENTS
                            WHERE OBJECT_NAME = :proc_name
                            AND PACKAGE_NAME IS NULL
                            AND OWNER = :owner
                            ORDER BY POSITION
                        """
                        cursor.execute(query, {'proc_name': proc_name, 'owner': owner})
                    elif len(parts) == 3:
                        # PKG_NAME.PROC_NAME format
                        owner_or_pkg, pkg_or_proc, proc_name = parts[0], parts[1], parts[2]
                        query = """
                            SELECT ARGUMENT_NAME, DATA_TYPE, IN_OUT
                            FROM ALL_ARGUMENTS
                            WHERE OBJECT_NAME = :proc_name
                            AND PACKAGE_NAME = :pkg_name
                            ORDER BY POSITION
                        """
                        cursor.execute(query, {'proc_name': proc_name, 'pkg_name': pkg_or_proc})
                    else:
                        return {}

                    metadata = {}
                    for row in cursor.fetchall():
                        param_name, data_type, in_out = row
                        if param_name:
                            metadata[param_name] = {'type': data_type, 'direction': in_out}
                    return metadata
                finally:
                    cursor.close()
        except oracledb.Error as e:
            self.logger.warning(f"Failed to fetch metadata for {procedure_name}: {str(e)}")
            return {}

    # ═══════════════════════════════════════════════════════════════════
    #  ABC implementations
    # ═══════════════════════════════════════════════════════════════════

    def execute_procedure(self, procedure_name: str, parameters: Optional[List[Dict]] = None,
                          connection_string: Optional[str] = None) -> Dict:
        """Execute an Oracle stored procedure.

        Parameters is a list of dicts:
          [{"name": "p_id", "value": 1, "direction": "IN", "type_hint": "NUMBER"}, ...]

        OUT parameters are updated in-place with their returned values.
        Returns {"status": "SUCCESS", "out_parameters": {name: value, ...}}
        """
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                # Fetch procedure metadata for type resolution
                metadata = self._fetch_procedure_metadata(procedure_name, connection_string)

                # Build cursor variables for each parameter
                call_params = {}
                out_vars = {}

                if parameters:
                    for param in parameters:
                        name = param['name']
                        value = param.get('value')
                        direction = param.get('direction', 'IN').upper()
                        type_hint = param.get('type_hint')
                        meta = metadata.get(name.upper(), {})
                        oracle_type = self._get_parameter_type(value, type_hint, meta.get('type'))

                        if direction in ('OUT', 'IN OUT'):
                            var = cursor.var(oracle_type)
                            if direction == 'IN OUT' and value is not None:
                                var.setvalue(0, value)
                            call_params[name] = var
                            out_vars[name] = var
                        else:
                            # IN parameter
                            if type_hint and type_hint.upper() == 'JSON' and isinstance(value, (dict, list)):
                                call_params[name] = json.dumps(value)
                            else:
                                call_params[name] = value

                cursor.callproc(procedure_name, keywordParameters=call_params)
                connection.commit()

                # Extract OUT values
                out_parameters = {}
                for name, var in out_vars.items():
                    out_val = var.getvalue()
                    out_parameters[name] = out_val
                    # Also update the original parameter dict in-place
                    if parameters:
                        for p in parameters:
                            if p['name'] == name:
                                p['value'] = out_val
                                break

                return {"status": "SUCCESS", "out_parameters": out_parameters}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Procedure {procedure_name} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None,
                      connection_string: Optional[str] = None) -> pd.DataFrame:
        """Execute a SQL query and return results as a pandas DataFrame."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                if parameters:
                    cursor.execute(query, parameters)
                else:
                    cursor.execute(query)

                if cursor.description:
                    columns = [col[0] for col in cursor.description]
                    rows = cursor.fetchall()
                    return pd.DataFrame(rows, columns=columns)
                return pd.DataFrame()

            except oracledb.Error as e:
                self.logger.error(f"Query failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def bulk_copy(self, table_name: str, data: pd.DataFrame,
                  batch_size: Optional[int] = None,
                  connection_string: Optional[str] = None) -> Dict:
        """Bulk insert a DataFrame into an Oracle table."""
        if data.empty:
            return {"status": "SUCCESS", "rows_inserted": 0}

        batch_size = batch_size or self.config.batch_size

        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                columns = list(data.columns)
                placeholders = ", ".join([f":{i+1}" for i in range(len(columns))])
                col_list = ", ".join(columns)
                insert_sql = f"INSERT INTO {table_name} ({col_list}) VALUES ({placeholders})"

                # Convert DataFrame to list of tuples
                rows = [tuple(row) for row in data.itertuples(index=False, name=None)]
                total_inserted = 0

                for i in range(0, len(rows), batch_size):
                    batch = rows[i:i + batch_size]
                    cursor.executemany(insert_sql, batch)
                    total_inserted += len(batch)
                    self.logger.info(
                        f"Inserted batch {i // batch_size + 1}: "
                        f"{len(batch)} rows (total: {total_inserted})"
                    )

                connection.commit()
                return {"status": "SUCCESS", "rows_inserted": total_inserted}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Bulk copy to {table_name} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e), "rows_inserted": 0}
            finally:
                cursor.close()

    def execute_transaction(self, statements: List[Tuple[str, Optional[Dict[str, Any]]]],
                            connection_string: Optional[str] = None) -> Dict:
        """Execute multiple SQL statements in a single transaction."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                results = []
                for sql, params in statements:
                    if params:
                        cursor.execute(sql, params)
                    else:
                        cursor.execute(sql)
                    results.append({
                        "sql": sql[:100],
                        "rowcount": cursor.rowcount,
                    })

                connection.commit()
                return {"status": "SUCCESS", "statements": results}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Transaction failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def fetch_procedure_data(self, procedure_name: str, parameters: Optional[List[Dict]] = None,
                             connection_string: Optional[str] = None) -> pd.DataFrame:
        """Execute a stored procedure that returns a cursor, return as DataFrame."""
        result = self.execute_procedure(procedure_name, parameters, connection_string)

        if result["status"] != "SUCCESS":
            raise RuntimeError(
                f"Procedure {procedure_name} failed: {result.get('error_message', 'unknown')}"
            )

        # Find the cursor OUT parameter
        out_params = result.get("out_parameters", {})
        for name, value in out_params.items():
            if hasattr(value, 'fetchall') and hasattr(value, 'description'):
                columns = [col[0] for col in value.description]
                rows = value.fetchall()
                value.close()
                return pd.DataFrame(rows, columns=columns)

        return pd.DataFrame()

    # ═══════════════════════════════════════════════════════════════════
    #  Extra methods used by oracle_metadata_manager
    # ═══════════════════════════════════════════════════════════════════

    def get_procedure_params(self, procedure_name: str, p_dagid: str,
                             p_businessdate: str, procconfigid: int,
                             proctype: str, connection_string: Optional[str] = None) -> List[Dict]:
        """Fetch procedure params via stored procedure with cursor output."""
        params = [
            {"name": "p_dagid", "value": p_dagid, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_businessdate", "value": p_businessdate, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_procconfigid", "value": procconfigid, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "p_proctype", "value": proctype, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_cursor", "value": None, "direction": "OUT", "type_hint": "CURSOR"},
        ]
        result = self.execute_procedure(procedure_name, params, connection_string)

        if result["status"] != "SUCCESS":
            raise RuntimeError(f"get_procedure_params failed: {result.get('error_message')}")

        cursor = result.get("out_parameters", {}).get("p_cursor")
        if cursor and hasattr(cursor, 'fetchall'):
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            cursor.close()
            return [dict(zip(columns, row)) for row in rows]
        return []

    def fetch_dag_configs(self, query1: str, query2: str,
                          connection_string: Optional[str] = None) -> Dict[str, Any]:
        """Fetch DAG configs from two views and merge."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                # Fetch main DAG configs
                cursor.execute(query1)
                columns1 = [col[0].lower() for col in cursor.description]
                rows1 = cursor.fetchall()
                configs = {}
                dag_ids = []
                for row in rows1:
                    row_dict = dict(zip(columns1, row))
                    dag_id = row_dict.get('dag_id')
                    if dag_id:
                        configs[dag_id] = row_dict
                        dag_ids.append(dag_id)

                # Fetch step configs for those DAG IDs
                if dag_ids and '{placeholders}' in query2:
                    placeholders = ", ".join([f":d{i}" for i in range(len(dag_ids))])
                    query2_resolved = query2.replace('{placeholders}', placeholders)
                    bind_vars = {f"d{i}": dag_id for i, dag_id in enumerate(dag_ids)}
                    cursor.execute(query2_resolved, bind_vars)
                    columns2 = [col[0].lower() for col in cursor.description]
                    for row in cursor.fetchall():
                        row_dict = dict(zip(columns2, row))
                        dag_id = row_dict.get('dag_id')
                        if dag_id and dag_id in configs:
                            configs[dag_id].setdefault('steps', []).append(row_dict)

                return configs
            except oracledb.Error as e:
                self.logger.error(f"fetch_dag_configs failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def fetch_dag_template_configs(self, query: str,
                                   connection_string: Optional[str] = None) -> List[Dict]:
        """Fetch DAG template configs from view."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(query)
                columns = [col[0].lower() for col in cursor.description]
                rows = cursor.fetchall()
                return [dict(zip(columns, row)) for row in rows]
            except oracledb.Error as e:
                self.logger.error(f"fetch_dag_template_configs failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def load_csv_to_oracle(self, table_name: str, csv_file: str,
                           dest_connection_string: Optional[str] = None,
                           schema: Optional[str] = None,
                           use_direct_path: bool = False) -> Dict:
        """Load CSV file into Oracle table using bulk insert."""
        target = f"{schema}.{table_name}" if schema else table_name

        with self._get_connection(dest_connection_string) as connection:
            cursor = connection.cursor()
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    columns = [col.strip() for col in header]

                    placeholders = ", ".join([f":{i+1}" for i in range(len(columns))])
                    col_list = ", ".join(columns)
                    insert_sql = f"INSERT INTO {target} ({col_list}) VALUES ({placeholders})"

                    batch = []
                    total_rows = 0
                    batch_size = self.config.batch_size

                    for row in reader:
                        batch.append(tuple(row))
                        if len(batch) >= batch_size:
                            cursor.executemany(insert_sql, batch)
                            total_rows += len(batch)
                            batch = []

                    if batch:
                        cursor.executemany(insert_sql, batch)
                        total_rows += len(batch)

                connection.commit()
                self.logger.info(f"Loaded {total_rows} rows from {csv_file} into {target}")
                return {"status": "SUCCESS", "rows_inserted": total_rows}

            except Exception as e:
                connection.rollback()
                self.logger.error(f"CSV load to {target} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def load_parquet_to_oracle(self, table_name: str, parquet_file: str,
                               dest_connection_string: Optional[str] = None,
                               schema: Optional[str] = None,
                               use_direct_path: bool = False) -> Dict:
        """Load Parquet file into Oracle table using bulk insert."""
        target = f"{schema}.{table_name}" if schema else table_name

        try:
            df = pd.read_parquet(parquet_file)
        except Exception as e:
            return {"status": "FAILED", "error_message": f"Failed to read parquet: {str(e)}"}

        return self.bulk_copy(target, df, self.config.batch_size, dest_connection_string)
