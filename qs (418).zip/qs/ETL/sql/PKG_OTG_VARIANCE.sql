-- ─────────────────────────────────────────────────────────────────────────
-- PKG_OTG_VARIANCE  -- variance-check helpers for the QueryStudio file flow
-- 2026-06-18 -- created for VarianceCheckAgainstPreviousCobRun step.
--
-- Companion to the Python step in
--   ETL/steps/file/variance_check_against_previous_cob_run.py
--
-- Schema assumptions (verified against the prior task state observed in
-- live logs):
--   OTG_DAG_TASK -- one row per (run_id, run_detail_id).  Columns
--     consulted: RUN_ID, FK_DAG_ID, FK_REPORT_ID, BUSINESS_DATE,
--     TASK_STATUS, TOTALCOUNT.  BUSINESS_DATE format is 'DD-MM-YYYY'
--     (string; that's what the polling rows feed in via OTG_DAG_TASK
--     column today -- see file_standlone.py CLI args).
--   TASK_STATUS = 'COMPLETED' identifies a finalised run.
--
-- If your install has DIFFERENT column names (TOTAL_RECORD vs
-- TOTALCOUNT, etc.) adjust the column references in the SELECTs below
-- and re-deploy.  Logic is unchanged.
-- ─────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE PACKAGE PKG_OTG_VARIANCE AS
    PROCEDURE CHECK_VARIANCE (
        p_run_id                 IN  NUMBER,
        p_dag_id                 IN  VARCHAR2,
        p_report_id              IN  NUMBER,
        p_business_date          IN  VARCHAR2,
        p_variance_threshold_pct IN  NUMBER DEFAULT 5,
        p_curr_count             OUT NUMBER,
        p_prev_count             OUT NUMBER,
        p_prev_business_date     OUT VARCHAR2,
        p_variance_pct           OUT NUMBER,
        p_status                 OUT VARCHAR2,
        p_message                OUT VARCHAR2
    );
END PKG_OTG_VARIANCE;
/

CREATE OR REPLACE PACKAGE BODY PKG_OTG_VARIANCE AS

    PROCEDURE CHECK_VARIANCE (
        p_run_id                 IN  NUMBER,
        p_dag_id                 IN  VARCHAR2,
        p_report_id              IN  NUMBER,
        p_business_date          IN  VARCHAR2,
        p_variance_threshold_pct IN  NUMBER DEFAULT 5,
        p_curr_count             OUT NUMBER,
        p_prev_count             OUT NUMBER,
        p_prev_business_date     OUT VARCHAR2,
        p_variance_pct           OUT NUMBER,
        p_status                 OUT VARCHAR2,
        p_message                OUT VARCHAR2
    ) AS
        l_curr  NUMBER;
        l_prev  NUMBER;
        l_pdate VARCHAR2(32);
    BEGIN
        -- Defensive defaults.
        p_curr_count         := NULL;
        p_prev_count         := NULL;
        p_prev_business_date := NULL;
        p_variance_pct       := NULL;
        p_status             := 'UNKNOWN';
        p_message            := NULL;

        -- Current run total: pick the max totalcount across this run's
        -- detail rows.  ConsolidateFiles is the last step that writes
        -- the final cross-source total, so its row should be the largest.
        BEGIN
            SELECT MAX(TOTALCOUNT)
              INTO l_curr
              FROM OTG_DAG_TASK
             WHERE RUN_ID = p_run_id
               AND TOTALCOUNT IS NOT NULL;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN l_curr := NULL;
        END;
        p_curr_count := l_curr;

        -- Previous COB run: most recent COMPLETED run for same dag +
        -- report, BEFORE today's business_date.  business_date is a
        -- string in 'DD-MM-YYYY' format -- TO_DATE it for ordering.
        BEGIN
            SELECT BUSINESS_DATE, MAX(TOTALCOUNT)
              INTO l_pdate, l_prev
              FROM OTG_DAG_TASK
             WHERE FK_DAG_ID    = p_dag_id
               AND FK_REPORT_ID = p_report_id
               AND TASK_STATUS  = 'COMPLETED'
               AND TOTALCOUNT IS NOT NULL
               AND TO_DATE(BUSINESS_DATE, 'DD-MM-YYYY')
                   < TO_DATE(p_business_date, 'DD-MM-YYYY')
             GROUP BY BUSINESS_DATE
             ORDER BY TO_DATE(BUSINESS_DATE, 'DD-MM-YYYY') DESC
             FETCH FIRST 1 ROW ONLY;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_status  := 'NO_PREVIOUS_RUN';
                p_message := 'First run for this dag/report -- no prior COB to compare';
                RETURN;
        END;

        p_prev_count         := l_prev;
        p_prev_business_date := l_pdate;

        IF l_prev IS NULL OR l_prev = 0 THEN
            p_status  := 'PREV_ZERO';
            p_message := 'Previous COB count was 0 -- variance % undefined';
            RETURN;
        END IF;

        IF l_curr IS NULL THEN
            -- Current run hasn't yet recorded a totalcount.  Treat as
            -- BREACHED so the support team is alerted that no data has
            -- been written.
            p_variance_pct := 100;
            p_status       := 'BREACHED';
            p_message      := 'Current run produced NO row count -- treating as 100% variance';
            RETURN;
        END IF;

        p_variance_pct := ROUND(ABS(l_curr - l_prev) * 100 / l_prev, 2);

        IF p_variance_pct > p_variance_threshold_pct THEN
            p_status  := 'BREACHED';
            p_message := 'Variance ' || p_variance_pct
                      || '% EXCEEDS threshold '
                      || p_variance_threshold_pct || '%';
        ELSE
            p_status  := 'UNDER_THRESHOLD';
            p_message := 'Variance ' || p_variance_pct
                      || '% within threshold '
                      || p_variance_threshold_pct || '%';
        END IF;
    END CHECK_VARIANCE;

END PKG_OTG_VARIANCE;
/

-- Grant execute to the Oracle user that the QS workers connect as.
-- Replace <QS_WORKER_USER> with the actual schema/role per your install.
-- GRANT EXECUTE ON PKG_OTG_VARIANCE TO <QS_WORKER_USER>;
