"""Cross-engine SQL adapter — one query, many engines.

2026-06-20 -- STRATEGIC: operators want to author a query ONCE and run
it on whichever engine the polling-row workflow points at:

  * Starburst/Trino (workflows A, B) -- runs against Trino DBAPI
  * Spark SQL on S3 (workflow D)     -- runs against Spark + Iceberg/Parquet
  * DuckDB (QueryStudio backend)     -- runs against the parquet engine

Pre-2026-06-20 the same SQL would NOT work across these:

  Starburst expects:   SELECT a, b FROM iceberg.gmi.fact_summary WHERE ...
  Spark S3 expects:    SELECT a, b FROM source                   WHERE ...
                       (the iceberg/parquet reader is exposed via a temp
                        view named "source")
  DuckDB expects:      SELECT a, b FROM read_parquet('s3://...')  WHERE ...

This module unifies the surface via TWO primitives:

1. ``{SOURCE}`` placeholder
     User writes:   SELECT a, b FROM {SOURCE} WHERE biz_date = DATE '2025-06-19'
     We resolve to:
       * Starburst -> "<catalog>.<schema>.<table>" from polling row's
                      C_CATALOG/C_SCHEMAINFO/TABLE_NAME (or P_*) columns
       * Spark S3  -> "source" (the temp view name the s3 step creates)
       * DuckDB    -> "source" or read_parquet(...) -- caller picks

2. Dialect transpile via sqlglot
     Optional: when ``transpile_to`` is supplied, sqlglot rewrites the
     SQL from its source dialect to the target.  Default keeps SQL
     verbatim (most operator queries already use the cross-dialect
     subset).  Transpile becomes the escape hatch for the few features
     that diverge.

Lock contract:
  * Empty / None SQL -> ValueError (caller must validate).
  * Missing {SOURCE} when expected -> ValueError (operator error, fail
    loud).
  * Multiple {SOURCE} occurrences all get the same expansion.
  * Sqlglot transpile errors -> log WARN + return original SQL
    (best-effort -- never block the run on a dialect quirk).

Used by:
  * ETL/steps/file/starburst_file_base.py -- via render_for_starburst
  * ETL/steps/s3/s3_query_base.py        -- via render_for_spark_s3
  * Future DuckDB-backed s3 path         -- via render_for_duckdb

Tests in ETL/tests/test_engine_sql_adapter.py.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional


# Source-table placeholder.  Case-sensitive to avoid collisions with
# legitimate SQL tokens.  Bare {SOURCE} OR ${SOURCE} both work so
# operators using shell-style templating don't get tripped up.
_SOURCE_PLACEHOLDER_REGEX = re.compile(r"\$?\{SOURCE\}")


# Reserved placeholders -- operator's own {…} placeholders MUST NOT
# collide with these.  Extend cautiously (each new name closes the
# escape hatch for ad-hoc operator templating).
RESERVED_PLACEHOLDERS = {"SOURCE"}


def has_source_placeholder(sql: str) -> bool:
    """True iff ``sql`` references ``{SOURCE}`` or ``${SOURCE}``."""
    if not sql:
        return False
    return bool(_SOURCE_PLACEHOLDER_REGEX.search(sql))


def render_for_starburst(
    sql: str,
    *,
    catalog: Optional[str] = None,
    schema: Optional[str] = None,
    table: Optional[str] = None,
    fully_qualified: Optional[str] = None,
    transpile_to: Optional[str] = None,
    transpile_from: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """Render ``sql`` for the Trino/Starburst engine.

    Substitutes ``{SOURCE}`` with the fully-qualified table reference.
    Priority for the FQN:

      1. ``fully_qualified`` argument (operator already built the FQN)
      2. ``catalog.schema.table`` assembled from the three args
      3. ``schema.table`` (no catalog -- depends on session default)
      4. ``table`` (no schema -- depends on session default)

    Raises ValueError when ``{SOURCE}`` appears in ``sql`` but none of
    the FQN parts were supplied.
    """
    if sql is None or not sql.strip():
        raise ValueError("render_for_starburst: empty SQL")

    if has_source_placeholder(sql):
        fqn = fully_qualified or _build_fqn(catalog, schema, table)
        if not fqn:
            raise ValueError(
                "render_for_starburst: {SOURCE} placeholder present but "
                "no catalog/schema/table or fully_qualified provided"
            )
        sql = _SOURCE_PLACEHOLDER_REGEX.sub(fqn, sql)

    if transpile_to:
        sql = _transpile(sql, transpile_from or "trino", transpile_to, logger)

    return sql


def render_for_spark_s3(
    sql: str,
    *,
    source_view: str = "source",
    transpile_to: Optional[str] = None,
    transpile_from: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """Render ``sql`` for the Spark-on-S3 engine.

    Substitutes ``{SOURCE}`` with the Spark temp view name (default
    ``source`` -- matches the convention in s3_query_base.py).  Custom
    view names are supported for steps that expose multiple sources.
    """
    if sql is None or not sql.strip():
        raise ValueError("render_for_spark_s3: empty SQL")

    if has_source_placeholder(sql):
        sql = _SOURCE_PLACEHOLDER_REGEX.sub(source_view, sql)

    if transpile_to:
        sql = _transpile(sql, transpile_from or "spark", transpile_to, logger)

    return sql


def render_for_duckdb(
    sql: str,
    *,
    source_view: str = "source",
    transpile_to: Optional[str] = None,
    transpile_from: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """Render ``sql`` for the DuckDB engine.

    Same convention as Spark -- DuckDB caller registers a view named
    ``source`` (via ``CREATE VIEW source AS SELECT * FROM read_parquet(...)``
    or similar) before executing the rendered SQL.
    """
    if sql is None or not sql.strip():
        raise ValueError("render_for_duckdb: empty SQL")

    if has_source_placeholder(sql):
        sql = _SOURCE_PLACEHOLDER_REGEX.sub(source_view, sql)

    if transpile_to:
        sql = _transpile(sql, transpile_from or "duckdb", transpile_to, logger)

    return sql


def validate_cross_engine_safe(
    sql: str,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Lint ``sql`` for constructs that won't survive cross-engine.

    Returns a dict::

        {
          "safe":     bool,   # True iff no warnings
          "warnings": [str],  # human-readable issues found
        }

    Caller decides whether to fail or just log.  Never raises.

    Heuristics (intentionally conservative -- false-positives are
    acceptable, false-negatives are not):

      * ``LISTAGG``   -- Trino-only; use ``array_join(array_agg(...))``
      * ``FOR VERSION AS OF``  -- Trino iceberg syntax; pass snapshot
        via engine config instead
      * Trino-specific functions: ``array_distinct``, ``element_at``,
        ``slice`` -- need rewrite for Spark
      * ``CONCAT(...) AS col`` -- portable (left for reference)
      * ``DATE 'YYYY-MM-DD'`` literal -- portable (both engines accept)
      * Backtick-quoted identifiers (Spark-only)
      * Double-quoted identifiers with spaces -- needs both engines'
        treatment verified case-by-case
    """
    if sql is None or not sql.strip():
        return {"safe": True, "warnings": []}
    warnings = []
    sql_upper = sql.upper()
    sql_lower = sql.lower()

    if "LISTAGG" in sql_upper:
        warnings.append(
            "LISTAGG is Trino-only -- use array_join(array_agg(col), ',') "
            "for cross-engine portability"
        )
    if "FOR VERSION AS OF" in sql_upper:
        warnings.append(
            "FOR VERSION AS OF is Trino iceberg syntax -- "
            "pass snapshot_id via engine config (Spark uses option('snapshot-id', ...))"
        )
    if "ELEMENT_AT(" in sql_upper:
        warnings.append(
            "element_at(...) is Trino-only -- Spark uses array indexing [n]"
        )
    if "ARRAY_DISTINCT(" in sql_upper:
        warnings.append(
            "array_distinct is Trino-only -- Spark has the same function "
            "but check syntax of nested-array case"
        )
    if "`" in sql:
        warnings.append(
            "backtick-quoted identifiers are Spark-only -- "
            "use double-quotes for cross-engine"
        )
    if "GETDATE(" in sql_upper or "SYSDATE" in sql_upper:
        warnings.append(
            "GETDATE()/SYSDATE are SQL-Server/Oracle -- "
            "use CURRENT_DATE or CURRENT_TIMESTAMP for cross-engine"
        )

    if logger and warnings:
        for w in warnings:
            logger.warning("Cross-engine SQL lint: %s", w)
    return {"safe": not warnings, "warnings": warnings}


# ── Internal helpers ─────────────────────────────────────────────────


def _build_fqn(
    catalog: Optional[str],
    schema: Optional[str],
    table: Optional[str],
) -> str:
    """Assemble the FQN from the available parts.  Empty / None parts
    are dropped so the caller's session defaults take over for the
    missing levels."""
    parts = [p for p in (catalog, schema, table) if p and str(p).strip()]
    return ".".join(str(p).strip() for p in parts)


def _transpile(
    sql: str,
    src_dialect: str,
    dst_dialect: str,
    logger: Optional[logging.Logger],
) -> str:
    """Best-effort sqlglot transpile.  Falls back to the original SQL
    if sqlglot is missing OR the transpile raises (logged at WARN)."""
    if src_dialect == dst_dialect:
        return sql
    try:
        import sqlglot
    except ImportError:
        if logger:
            logger.warning(
                "sqlglot not available -- skipping %s->%s transpile, "
                "passing SQL through unchanged.",
                src_dialect, dst_dialect,
            )
        return sql
    try:
        # sqlglot.transpile returns a list (one entry per statement).
        out = sqlglot.transpile(
            sql, read=src_dialect, write=dst_dialect,
        )
        return ";\n".join(out) if out else sql
    except Exception as exc:
        if logger:
            logger.warning(
                "sqlglot transpile %s->%s failed (%s) -- passing "
                "SQL through unchanged.",
                src_dialect, dst_dialect, exc,
            )
        return sql
