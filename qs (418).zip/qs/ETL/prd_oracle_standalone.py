import asyncio
import argparse
import os
import time
import shutil
from pathlib import Path
from datetime import datetime
import sys
import yaml
from typing import Dict, List
from workers.oracle_worker import OracleWorker
from datasources.starburst_datasource import StarburstDataSource
# Add core_libs to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
core_libs_path = os.path.join(current_dir, 'core_libs')
if core_libs_path not in sys.path:
    sys.path.insert(0, core_libs_path)
from core_libs.logger.firelogger import CentralizedLogger
from managers.oracle_metadata_manager import OracleMetadataManager

# Get current date
logger = CentralizedLogger(
    log_file="/usr/local/spark/nfs/bcp/batch/logs/oracle_standalone_{date_str}.log",
    log_level="INFO",
    backup_count=30,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
).get_logger(__name__)

SPARK_UPLOAD_ROOT = Path("/usr/local/spark/pvc/jars")
MAX_AGE_HOURS = ...
PREFIX = "spark-upload-"


def cleanup_old_spark_uploads():
    cutoff_timestamp = time.time() - (MAX_AGE_HOURS * 3600)
    for item in SPARK_UPLOAD_ROOT.iterdir():
        if item.is_dir() and item.name.startswith(PREFIX):
            if item.stat().st_mtime < cutoff_timestamp:
                print(f"Deleting: {item}")
                try:
                    shutil.rmtree(item)
                except Exception as e:
                    logger.error(f"cleanup_old_spark_uploads failed with error: {str(e)}")
                pass


async def execute_tasks(tasks: List[Dict], worker_connection_string: str, dest_connection_string: str) -> None:
    """Execute all Oracle task steps for a given RUN_ID based on dynamic sequence."""
    # Validate inputs
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError("Tasks, worker_connection_string, and dest_connection_string are required")
    oracle_data_manager = OracleMetadataManager(worker_connection_string)
    # Configure StarburstDataSource per task
    for task in tasks:
        cloud_config = {
            "host": task["c_hostname"], "port": task["c_port"], "user": task["c_username"], "password": task["c_pwd"],
            "catalog": task["c_catalog"], "schema": task["c_schemainfo"], "use_ssl": True
        }
        prem_config = {
            "host": task["p_hostname"], "port": task["p_port"], "user": task["p_username"], "password": task["p_pwd"],
            "catalog": task["p_catalog"], "schema": task["p_schemainfo"], "use_ssl": True
        }
        task["starburst_clients"] = {"cloud": StarburstDataSource(cloud_config), "prem": StarburstDataSource(prem_config)}
        # for client in task["starburst_clients"].values():
        #     await client.connect()

        logger.info(f"Executing task {task.get('run_id')} with DAG ID: {task.get('fk_dag_id')} and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} (SEQ: {task.get('seq')})")
        worker = OracleWorker(task["starburst_clients"], oracle_data_manager, logger)
        logger.info(f"Starting execution of Step {task['task_steps']} for task {task['run_id']}")
        try:
            await worker.execute_step(task, worker_connection_string, dest_connection_string, task["task_steps"])
        except Exception as e:
            logger.error(f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}")
            raise  # Halt execution for this RUN_ID


async def main():
    cleanup_old_spark_uploads()
    """Main function to execute an Oracle task based on command-line arguments."""
    parser = argparse.ArgumentParser(description="Execute an Oracle task for a specific report ID and business date.")
    parser.add_argument("--report_id", type=int, default=77, required=True, help="The report ID to process.")
    parser.add_argument("--business_date", type=str, default="30-SEP-24", required=True, help="The business date to process (e.g., '2025-07-10').")
    parser.add_argument("--dag_id", type=str, default="RADIAL_TETB_EOD_1200_GMI_APAC", required=True, help="The DAG ID to process.")
    parser.add_argument("--config_path", type=str, default="/usr/local/spark/pvc/code/configs/oracle_config.yaml", help="Path to the configuration file.")
    args = parser.parse_args()
    # logger.info(f"Passed arguments are {args}")

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing oracle section")

    # Load queries from YAML
    queries_path = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")
    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)
    if "polling_query_sb_to_oracle" not in queries:
        raise ValueError("polling_query_sb_to_oracle not found in queries.yaml")

    # Establish database connection
    worker_connection_string = f"{config['oracle']['etl_connection_string']}"
    dest_connection_string = f"{config['oracle']['dest_connection_string']}"

    # Fetch all tasks from database using OracleDataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)
    # logger.info(f"Queries {queries['polling_query_sb_to_oracle']}")

    tasks = await oracle_data_manager.execute_query_async(
        queries["polling_query_sb_to_oracle"],
        {"1": args.report_id, "2": args.business_date, "3": args.dag_id},
        worker_connection_string
    )
    if tasks is not None and not tasks.empty:
        tasks = [dict(row) for _, row in tasks.iterrows()]
        if not tasks:
            raise ValueError(f"No tasks found for report_id {args.report_id}, business_date {args.business_date}, and dag_id {args.dag_id}")
        for task in tasks:
            task["task_id"] = task["run_id"]  # Use RUN_ID as task_id
            task["dag_run_id"] = f"run_{task['run_id']}"  # Generate dag_run_id from RUN_ID
        await execute_tasks(tasks, config, worker_connection_string, dest_connection_string)
    else:
        logger.info("no task found to execute")

if __name__ == "__main__":
    asyncio.run(main())