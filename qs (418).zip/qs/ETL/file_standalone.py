"""File-flow standalone entry point.

ONE invocation per RUN_ID (Airflow triggers one pod with --report_id +
--business_date + --dag_id).  Cross-pod safety is owned by the polling
service; this script just executes the steps that the polling row
demands, sequentially, halting on the first failure.

Lifecycle (the four contracts the user asked for):

  1. **Single log file per execution**
     ``set_run_log_file(path)`` pins every ``build_module_logger``
     call to ONE file for the whole run.  No CentralizedLogger,
     no rolling handler.  Whole batch lives in one greppable file.

  2. **HTML run report + email**
     ``FileRunReport`` is created BEFORE any step runs and ALWAYS
     written (success or fail) in the ``finally`` block.  Start
     email sent on entry; finish email (SUCCESS or FAILED) sent on
     exit; both inline the HTML body.  Reports + emails are
     opt-in via the ``send_email`` knob from polling-row / oracle
     config — safe defaults so local-dev never accidentally mails
     prod.

  3. **Catch failures → wipe chunks**
     ``RunArtifacts`` registers every chunk / consolidated / gz /
     ctl file the steps write.  On ANY exception the
     ``cleanup_on_failure()`` walks the registry and removes every
     non-deliverable artefact, so the operator never sees a
     half-written file masquerading as a successful delivery.

  4. **Data completeness**
     Each step pushes its counts into the run report's G1-G5
     completeness ledger.  The ConsolidateFiles step is the gate:
     G5 raises if consolidated rows != G1 source COUNT(*).  Anything
     past G5 is guaranteed-complete.
"""
from __future__ import annotations

# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
#
# 2026-06-21 bug #13: previously `import yaml` (and downstream `oracledb`,
# `pandas`, `trino` via project modules) happened BEFORE preflight_check
# was reached at line ~680.  On a fresh OpenShift / Spark pod without
# those packages, the standalone DIED at the first `import yaml` with
# ModuleNotFoundError -- preflight's auto-install logic never got a chance.
#
# Fix: import preflight (stdlib-only) at the very top + run auto-install
# NOW, before any other import.  Then the subsequent yaml / oracledb /
# trino / workers.X imports succeed.
#
# preflight.py is intentionally stdlib-only (importlib + subprocess) so
# this bootstrap can run on a minimal Python image.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="file",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    # preflight module itself missing -- run will fail with a clearer
    # error on the next import.  Don't crash here.
    pass
# === END PREFLIGHT BOOTSTRAP ===

import argparse
import asyncio
import logging
import os
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import yaml

# Make ETL importable when invoked as a script.
#
# spark-submit uploads ONLY the entry script to a temp dir like
# ``/usr/local/spark/pvc/jars/spark-upload-<uuid>/file_standalone.py``
# and PythonRunner sets ``__file__`` to that path.  If we trust
# ``__file__.parent``, sys.path[0] becomes an empty upload dir and
# ``import log_config`` fails (the rest of the etl tree lives at
# ``/usr/local/spark/pvc/code/`` per dynamic_dags.py's PYTHONPATH).
#
# Strategy: probe well-known roots in priority order and pick the
# first one that actually contains the ``log_config.py`` sentinel.
# Falls through to ``__file__.parent`` for local dev where the script
# IS co-located with the rest of the package.
_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",        # prod PVC code root (matches DAG PYTHONPATH)
    "/usr/local/spark/pvc/code/etl",    # prod with etl/ subpackage layout
    "/usr/local/spark/pvc",             # PVC root (matches DAG PYTHONPATH first entry)
    str(Path(__file__).resolve().parent),  # local-dev / co-located fallback
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from log_config import (  # noqa: E402  — must come AFTER sys.path adjust
    get_log_dir,
    set_run_log_file,
)
from date_utils import normalize_business_date  # noqa: E402
from managers.oracle_metadata_manager import OracleMetadataManager  # noqa: E402
from workers.file_worker import FileWorker  # noqa: E402
from steps.file.run_report import FileRunReport  # noqa: E402
from steps.file.run_state import (  # noqa: E402
    RunArtifacts, get_or_create_artifacts,
    delete_sidecar, backup_stale_sidecar,
)

# Optional — only used when Spark variants run on a Spark pod.
try:
    from datasources.starburst_datasource import StarburstDataSource  # noqa: E402
except ImportError:
    StarburstDataSource = None  # type: ignore


# ----- Defaults --------------------------------------------------------

_PROD_CONFIG_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_PROD_QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
_LOCAL_CONFIG_PATH = os.path.join(ETL_ROOT, "configs", "oracle_config.yaml")
_LOCAL_QUERIES_PATH = os.path.join(ETL_ROOT, "configs", "etl_polling_task_query.yaml")

SPARK_UPLOAD_ROOT = Path("/usr/local/spark/pyc/jars")
SPARK_UPLOAD_PREFIX = "spark-upload-"
SPARK_UPLOAD_MAX_AGE_HOURS = 1


def _resolve_path(prod: str, local: str) -> str:
    return prod if os.path.exists(prod) else local


def _truthy_yaml(v: Any) -> bool:
    """Treat the usual Oracle/YAML string values as bool."""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    s = str(v).strip().upper()
    return s in {"TRUE", "1", "YES", "Y", "T"}


def _summarise_task_state(task: Dict[str, Any]) -> str:
    """Snapshot the task-dict keys that downstream steps inspect.

    Renders one ``  key=value`` per line.  Truncates long lists to the
    count + first 2 items so the log line stays scannable.  Called from
    the per-step except block so a failure log carries enough state to
    diagnose without re-running.
    """
    def _short(v: Any) -> str:
        if isinstance(v, (list, tuple)):
            n = len(v)
            head = ", ".join(repr(x) for x in v[:2])
            tail = f", ... (+{n - 2})" if n > 2 else ""
            return f"[{head}{tail}] (len={n})"
        s = repr(v)
        return s[:200] + ("..." if len(s) > 200 else "")

    KEYS = (
        "run_id", "run_detail_id", "fk_dag_id", "fk_report_id",
        "task_steps", "seq",
        "output_dir", "log_file", "sql_query_path",
        "job_results", "chunk_files", "consolidated_file", "consolidated_total",
        "expected_total", "sum_partition_expected", "sum_chunk_actual",
        "totalcount", "artifact_paths",
    )
    rows = []
    for k in KEYS:
        if k in task:
            rows.append(f"  {k}={_short(task.get(k))}")
        else:
            rows.append(f"  {k}=<absent>")
    return "\n".join(rows)


# ----- Logger setup (single-file pin) ---------------------------------

def _build_log_file(
    dag_id: str, report_id: int, business_date: str,
    log_dir_override: Optional[str] = None,
) -> str:
    """Build a filename that uniquely identifies this run.

    2026-06-18 -- ``log_dir_override`` lets the polling row's
    ``LOGFILEPATH`` column or the mapped output directory take over the
    log destination after the polling fetch.  When None (call site
    before polling row is available), falls back to ``get_log_dir()``
    (the legacy ETL_LOG_DIR / yaml / platform default chain).
    """
    safe_dag = re.sub(r"[\\/\s]+", "_", str(dag_id))[:60]
    safe_date = re.sub(r"[\\/\s]+", "-", str(business_date))[:20]
    ts = datetime.now().strftime("%H%M%S")
    base_dir = log_dir_override.strip() if (log_dir_override and log_dir_override.strip()) else get_log_dir()
    return os.path.join(
        base_dir,
        f"file_flow_{safe_dag}_{report_id}_{safe_date}_{ts}.log",
    )


def _resolve_log_dir_from_polling_row(sample: dict) -> Optional[str]:
    """Pick a log directory from the polling row, in order of preference.

    Honoured columns (any case):
      1. ``LOGFILEPATH`` / ``log_file_path`` -- explicit log directory.
         When the value is a file path (contains a filename), only the
         directory portion is taken.
      2. ``OUTPUT_FILE_LOCATION`` / ``output_file_location`` / ``OUTPUT_DIR``
         -- the mapped output folder; log goes under
         ``<output_dir>/_runtime/logs/``.

    Returns None when neither is set -- caller falls back to
    ``get_log_dir()``.
    """
    if not isinstance(sample, dict):
        return None
    # Direct LOGFILEPATH override.
    for key in ("LOGFILEPATH", "logfilepath", "log_file_path", "LOG_FILE_PATH"):
        v = sample.get(key)
        if v and isinstance(v, str) and v.strip():
            v = v.strip()
            # Operator may supply a file or a directory; normalise to dir.
            if os.path.splitext(v)[1]:
                return os.path.dirname(v) or v
            return v
    # Fall back to mapped output folder with a _runtime/logs subdir.
    for key in ("output_file_location", "OUTPUT_FILE_LOCATION",
                "output_dir", "OUTPUT_DIR"):
        v = sample.get(key)
        if v and isinstance(v, str) and v.strip():
            return os.path.join(v.strip(), "_runtime", "logs")
    return None


def _relocate_log_file(old_log: str, new_log: str, logger_obj) -> str:
    """Move the active log file from ``old_log`` to ``new_log`` and
    re-attach the file handler.  Returns the path actually in use
    afterwards -- new_log on success, old_log on failure.

    Best-effort: any error logs WARN and we keep the original handler.
    """
    if not new_log or new_log == old_log:
        return old_log
    try:
        os.makedirs(os.path.dirname(new_log) or ".", exist_ok=True)
        # Detach the existing FileHandlers (we'll write to the moved path).
        _to_close = [
            h for h in logger_obj.handlers if isinstance(h, logging.FileHandler)
        ]
        for h in _to_close:
            try:
                h.flush()
                h.close()
            except Exception:
                pass
            logger_obj.removeHandler(h)
        # Move the file contents (rename within volume; copy across).
        if os.path.exists(old_log):
            try:
                os.replace(old_log, new_log)
            except OSError:
                # Cross-volume -- copy + delete.
                import shutil as _sh
                _sh.copy2(old_log, new_log)
                try:
                    os.remove(old_log)
                except OSError:
                    pass
        # Re-attach a handler at the new path.
        fh = logging.FileHandler(new_log, encoding="utf-8")
        fh.setFormatter(
            logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        )
        logger_obj.addHandler(fh)
        logger_obj.info("Log file relocated to: %s (from %s)", new_log, old_log)
        return new_log
    except Exception as exc:
        logger_obj.warning(
            "Log relocation %s -> %s failed (non-fatal, keeping original): %s",
            old_log, new_log, exc,
        )
        # Try to restore a file handler on the old log so we don't lose logging.
        try:
            fh = logging.FileHandler(old_log, encoding="utf-8")
            fh.setFormatter(
                logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
            )
            logger_obj.addHandler(fh)
        except Exception:
            pass
        return old_log


# Module-level logger — file handler attached after we know the batch
# context (so the log filename can name the batch).
logger = logging.getLogger("file_standalone")
logger.setLevel(logging.INFO)
if not logger.handlers:
    _sh = logging.StreamHandler(sys.stdout)
    _sh.setFormatter(logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s"))
    logger.addHandler(_sh)


def _attach_file_handler(log_file: str) -> None:
    try:
        os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s"))
        logger.addHandler(fh)
        logger.info("Logging pinned to: %s", log_file)
    except OSError as exc:
        logger.warning("Cannot create log file %s: %s — console only", log_file, exc)


# ----- Spark cleanup (best-effort) ------------------------------------

def cleanup_old_spark_uploads() -> None:
    """Remove stale /spark-upload-* dirs older than MAX_AGE_HOURS.

    Best-effort: missing directory or permission errors are logged at
    WARN and the function returns without raising.  Pre-fix this was
    silent — now we know what was attempted.
    """
    if not SPARK_UPLOAD_ROOT.is_dir():
        return
    cutoff = time.time() - (SPARK_UPLOAD_MAX_AGE_HOURS * 3600)
    removed = 0
    for item in SPARK_UPLOAD_ROOT.iterdir():
        if not item.is_dir() or not item.name.startswith(SPARK_UPLOAD_PREFIX):
            continue
        try:
            if item.stat().st_mtime < cutoff:
                shutil.rmtree(item)
                removed += 1
        except OSError as exc:
            logger.warning("Spark cleanup: could not remove %s: %s", item, exc)
    if removed:
        logger.info("Spark cleanup: removed %d stale upload dirs", removed)


# ----- Email config sourcing ------------------------------------------

def _email_config_from(config: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
    """Build the email config dict from yaml + polling-row columns.

    Polling-row values win over yaml; both are optional.  The
    FileRunReport.send_email() short-circuits when send_email is
    False or smtp_host/email_to/email_from are missing — so it's safe
    to call unconditionally in any environment.
    """
    email_cfg: Dict[str, Any] = {}
    # 1. yaml block
    yaml_block = (config or {}).get("email", {}) or {}
    for k in (
        "send_email", "smtp_host", "smtp_port", "smtp_user", "smtp_password",
        "smtp_use_tls", "email_from", "email_to", "email_subject",
    ):
        if k in yaml_block:
            email_cfg[k] = yaml_block[k]

    # 2. polling-row overlay (UPPER-case columns)
    for src, dst in (
        ("SEND_EMAIL", "send_email"),
        ("SMTP_HOST", "smtp_host"),
        ("SMTP_PORT", "smtp_port"),
        ("SMTP_USER", "smtp_user"),
        ("SMTP_PASSWORD", "smtp_password"),
        ("SMTP_USE_TLS", "smtp_use_tls"),
        ("EMAIL_FROM", "email_from"),
        ("EMAIL_TO", "email_to"),
        ("EMAIL_SUBJECT", "email_subject"),
    ):
        v = task.get(src) or task.get(src.lower())
        if v not in (None, "", 0):
            email_cfg[dst] = v
    return email_cfg


# ----- Execution loop -------------------------------------------------

async def execute_tasks(
    tasks: List[Dict[str, Any]],
    config: Dict[str, Any],
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    run_report: FileRunReport,
    artifacts: RunArtifacts,
) -> None:
    """Execute each polling row in SEQ order; halt + raise on first failure."""
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError("execute_tasks: tasks + both connection strings required")

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Hoisted out of the Starburst-only block: every code path below
    # (sidecar_dir, prior_output_mode, backup_ts wiring) reads polling-row
    # values off the first task.  Before this hoist, `sample` was bound
    # only inside `if StarburstDataSource is not None and tasks:` so non-
    # Spark pods (where StarburstDataSource fails to import) raised
    # UnboundLocalError at the `prior_output_mode = (sample.get(...))`
    # line.  Safe to bind unconditionally because the guard on line 274
    # already raises when tasks is empty.
    sample = tasks[0]

    # One starburst client pair (cloud + onprem) shared across tasks.
    # 2026-06-22 -- file workflow does NOT read Starburst creds from
    # the polling row.  Per user direction:
    #   "starburst details should come from common config files which is
    #    shared with file workflow so we have single truth of source for
    #    starburst connections"
    #   "file_standalone doesn't read from polling row"
    #
    # File-workflow extract steps (starburst_file_base._build_connection_config)
    # build their own Starburst connections at extract time, reading
    # creds from the shared configs/starburst_config.yaml via
    # starburst_config_loader.shared_creds_for(endpoint).  Per-job
    # server_name + port come from the GenerateSQL output JSON.
    #
    # Verified no file-workflow code path reads task["starburst_clients"]
    # (grep across steps/file/ + workers/file_worker.py returned 0 hits).
    # The dict is passed for BaseWorker signature compat only; empty
    # dict is fine.
    starburst_clients: Dict[str, Any] = {}

    worker = FileWorker(
        starburst_clients=starburst_clients,
        oracle_data_manager=oracle_data_manager,
        download_config=config.get("download", {}) or {},
        logger=logger,
    )

    # 2026-06-12 — per-run STABLE sidecar location, decoupled from
    # per-row file_location.  Cross-step state (chunk_files,
    # consolidated_file, compress_results, ...) MUST live in ONE
    # location across every task in the run; otherwise CLOUD writes
    # its sidecar at C:\usc\..., ONPREM at C:\usr\..., ConsolidateFiles
    # at C:\usr\, etc. and each step hydrates from a different spot --
    # CompressFile never sees ConsolidateFiles' merged-file path,
    # CreateControlFile never sees compress_results.  Pin to log dir
    # (already per-run via the date-stamped log filename).
    sidecar_dir = os.path.dirname(log_file) if log_file else ""

    # 2026-06-13 -- per-run timestamp for the "rename prior deliverables
    # to backup folder" feature.  Every step that's about to overwrite
    # a deliverable (consolidated .dat, .ctl, .gz, run_report.html /
    # .txt) reads task["backup_ts"] and moves the existing file to
    # <output_dir>/backup_<ts>/ before its own write.  ONE timestamp
    # per run so all files from this run's pre-existing state land in
    # ONE folder, not scattered.
    backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    # 2026-06-13 -- operator-controllable: "backup" (move to
    # backup_<ts>/) or "delete" (just os.remove).  Lives in the
    # polling row (PRIOR_OUTPUT_MODE column) OR oracle_config.yaml's
    # run_report block; polling row wins.  Default "backup".  Pick
    # "delete" if your output_dir is shared with many runs and the
    # backup folders would accumulate.
    _file_cfg = (config.get("file_flow") or {}) if isinstance(config, dict) else {}
    prior_output_mode = (
        (sample.get("prior_output_mode") or sample.get("PRIOR_OUTPUT_MODE"))
        or _file_cfg.get("prior_output_mode")
        or "backup"
    )

    for task in tasks:
        task["log_file"] = log_file
        task["_run_report"] = run_report
        task["_run_artifacts"] = artifacts
        # 2026-06-12 — set task["output_dir"] from polling-row columns
        # ONLY (no derived paths invented in this module).  Resolution
        # order matches what was already present at the call sites:
        #   1. file_location  (the polling-row FILE_LOCATION column)
        #   2. output_file_location  (alias used by some pipelines)
        #   3. output_dir  (already explicitly set upstream)
        # When none are populated, task["output_dir"] is left alone --
        # the downstream Starburst step will fall back to its per-job
        # JSON's output_file_location and the sidecar will land there.
        fl = (
            task.get("file_location")
            or task.get("output_file_location")
            or task.get("output_dir")
        )
        if fl:
            task["output_dir"] = fl
        # Sidecar location -- stable across all tasks in this run.
        # save_task_state / hydrate_task_from_sidecar prefer this over
        # the per-task output_dir.
        if sidecar_dir:
            task["sidecar_dir"] = sidecar_dir
        # Per-run backup_ts -- consumed by backup_if_exists() at each
        # write site so all prior-run files for this run share ONE
        # backup folder.
        task["backup_ts"] = backup_ts
        # Per-task prior-output handling: operator's flag in YAML /
        # polling row.  "backup" (default) or "delete".
        task["prior_output_mode"] = prior_output_mode
        # Make sure get_or_create_artifacts picks it back up.
        get_or_create_artifacts(task, logger=logger)

        step_name = task.get("task_steps")
        logger.info(
            "Dispatching: run_id=%s seq=%s step='%s' dag_id=%s report_id=%s",
            task.get("run_id"), task.get("seq"), step_name,
            task.get("fk_dag_id"), task.get("fk_report_id"),
        )
        # 2026-06-21 -- stash current step + seq on run_report so the
        # outer failure handler (in main()) can pass them to mark_failed
        # for the failure email body.  Cleared on success of this step.
        try:
            run_report.failed_step_name = step_name
            run_report.failed_step_seq = task.get("seq")
        except Exception:
            pass

        # 2026-06-18 -- HARD COMPLETENESS GATE with auto-rerun.
        # Operator requirement: "we cant complete process if data
        # completeness fails" + "it has to rerun by itself n get
        # correct files".
        #
        # Behaviour:
        #   1. Run the step.  If the step itself raises -> propagate
        #      (no retry on connection / cred / catalog errors -- those
        #      need operator intervention).
        #   2. After an EXTRACT step succeeds, check whether the
        #      source's per-source job_result has expected_total ==
        #      records (cumulative cross-source check is a backstop).
        #   3. If completeness fails: clean this source's chunk
        #      artifacts, drop the per-source job_result entry so the
        #      next attempt's data replaces it cleanly, and re-run the
        #      step.  Bounded by COMPLETENESS_MAX_RETRIES (default 2,
        #      overridable via config.file_flow.completeness_max_retries
        #      OR env QS_COMPLETENESS_MAX_RETRIES).
        #   4. On retry exhaustion: raise to halt the pipeline before
        #      consolidate runs.  RunArtifacts.cleanup_on_failure then
        #      wipes whatever the failed attempts left on disk.
        #
        # WHY at orchestrator level (not in the step): the step has
        # its own per-chunk retries.  This is a JOB-level retry that
        # treats the whole source extract as a unit.  Use when the
        # chunk-level retries weren't enough -- e.g. Iceberg snapshot
        # drift mid-run, partition discovery vs extract drift, Trino
        # spilled silently.  Cannot be bypassed by fail_on_mismatch=False.
        _is_extract_step = step_name and "starburst_to_file" in (step_name or "").lower()
        _max_retries = int(
            os.environ.get("QS_COMPLETENESS_MAX_RETRIES", "").strip()
            or (config.get("file_flow") or {}).get("completeness_max_retries", 2)
        )
        _attempt = 0
        while True:
            _attempt += 1
            try:
                await worker.execute_step(
                    task, worker_connection_string, dest_connection_string, step_name,
                )
            except Exception as exc:
                import traceback as _tb
                _state = _summarise_task_state(task)
                logger.error(
                    "Step '%s' for task run_id=%s FAILED: %s\n"
                    "TASK STATE AT FAILURE:\n%s\n"
                    "TRACEBACK:\n%s",
                    step_name, task.get("run_id"), exc, _state, _tb.format_exc(),
                )
                raise

            if not _is_extract_step:
                break  # non-extract step -- no completeness check needed

            # Identify THIS source's job_result by datasource name on
            # the step class (set by DATASOURCE_NAME = "CLOUD"/"ONPREM"
            # in the Starburst subclass).  Heuristic: most recent
            # job_result entries belong to this step.  Per-source
            # mismatch = source != download for any job in this batch.
            _bad: list = []
            for _jr in run_report.job_results:
                src = _jr.get("expected_total")
                dl = _jr.get("records")
                if src is None or dl is None:
                    continue
                if int(src) != int(dl):
                    _bad.append(_jr)
            # Cumulative backstop (catches the case where per-source
            # check passed locally but cumulative diverged -- usually
            # a bug, log loudly so operator sees it).
            _cum_src = run_report._cum_source_count()
            _cum_dl = run_report._cum_downloaded()
            _cumulative_ok = (
                _cum_src is None or _cum_dl is None or int(_cum_src) == int(_cum_dl)
            )

            if not _bad and _cumulative_ok:
                logger.info(
                    "Completeness gate OK after '%s' (attempt %d): "
                    "cumulative source=%s downloaded=%s",
                    step_name, _attempt,
                    f"{_cum_src:,}" if _cum_src is not None else "-",
                    f"{_cum_dl:,}" if _cum_dl is not None else "-",
                )
                break

            if _attempt > _max_retries:
                _msg = (
                    f"COMPLETENESS GATE FAILED after '{step_name}' "
                    f"(attempts={_attempt - 1}+1, max retries reached).  "
                    f"Cumulative source={_cum_src:,} downloaded={_cum_dl:,} "
                    f"delta={(_cum_dl or 0) - (_cum_src or 0):+,}.  "
                    f"{len(_bad)} per-source job_result(s) showed mismatch: "
                    f"{[(j.get('datasource'), int(j.get('expected_total') or 0), int(j.get('records') or 0)) for j in _bad]}.  "
                    f"Refusing to proceed to consolidate -- partial / "
                    f"duplicated data would ship.  Chunks from failed "
                    f"attempts are wiped via RunArtifacts.cleanup_on_failure."
                )
                logger.error(_msg)
                raise ValueError(_msg)

            # Failed -- prepare to retry this source.
            logger.warning(
                "Completeness mismatch after '%s' (attempt %d/%d): "
                "cumulative source=%s downloaded=%s.  Cleaning %d "
                "chunk file(s) for this source and re-running the step.",
                step_name, _attempt, _max_retries + 1,
                f"{_cum_src:,}" if _cum_src is not None else "-",
                f"{_cum_dl:,}" if _cum_dl is not None else "-",
                sum(len(j.get("chunk_files") or []) for j in _bad),
            )
            # Wipe this step's chunk files so the retry starts clean.
            for _jr in _bad:
                for _cp in (_jr.get("chunk_files") or []):
                    try:
                        if os.path.exists(_cp):
                            os.remove(_cp)
                    except OSError as _rm_exc:
                        logger.debug(
                            "Could not remove chunk %s on retry prep: %s",
                            _cp, _rm_exc,
                        )
            # Drop the bad job_result entries so the next attempt's
            # results replace them cleanly (no double-counting in
            # cumulative sums).  Identify by (report_id, datasource).
            _bad_keys = {(j.get("report_id"), j.get("datasource")) for j in _bad}
            run_report.job_results[:] = [
                j for j in run_report.job_results
                if (j.get("report_id"), j.get("datasource")) not in _bad_keys
            ]
            # Reset task state that the step uses to track its own
            # progress, so the retry doesn't see "already done" via
            # the sidecar.
            for _k in ("chunk_files", "job_results", "consolidated_file",
                       "consolidated_total", "expected_total",
                       "sum_partition_expected", "sum_chunk_actual",
                       "totalcount", "artifact_paths"):
                task.pop(_k, None)


# ----- Main ------------------------------------------------------------

async def main() -> None:
    parser = argparse.ArgumentParser(
        description="Execute a File-flow task for a specific report ID and business date.",
    )
    parser.add_argument("--report_id", type=int, required=True)
    parser.add_argument("--business_date", type=str, required=True,
                         help='Accepted: dd-MM-yyyy ("30-06-2025"), ISO ("2025-06-30"), '
                              'dd/MM/yyyy, dd-Mon-yyyy.  Normalised to DD-MM-YYYY for '
                              'the polling SQL bind.')
    parser.add_argument("--dag_id", type=str, required=True)
    parser.add_argument(
        "--config_path", type=str,
        default=_resolve_path(_PROD_CONFIG_PATH, _LOCAL_CONFIG_PATH),
    )
    parser.add_argument(
        "--queries_path", type=str,
        default=_resolve_path(_PROD_QUERIES_PATH, _LOCAL_QUERIES_PATH),
    )
    # 2026-06-21 -- preflight package check + auto-install.
    # Default ON because this script runs in TWO modes:
    #   1. Polling-service container (helm image pre-bakes deps -- no-op)
    #   2. Airflow SparkSubmit driver pod (generic Spark image may be
    #      MISSING workflow deps -- pip install at startup unblocks)
    # --no-auto-install flips it off for CI sanity checks.
    parser.add_argument(
        "--no-auto-install", action="store_true",
        help="Skip auto-install of missing REQUIRED packages.  Pre-flight "
             "still runs + reports; fails fast on missing deps.",
    )
    parser.add_argument(
        "--no-install-optional", action="store_true",
        help="Skip auto-install of OPTIONAL packages (sqlglot / psutil / "
             "boto3 / etc.).  Required deps still auto-install.",
    )
    args = parser.parse_args()

    # 2026-06-21 -- preflight already ran at top-of-file bootstrap
    # BEFORE any 3rd-party import.  Honour the CLI flags here for
    # explicit re-check + report (idempotent: packages installed at
    # bootstrap are now importable, the check is a fast no-op).
    if args.no_auto_install or args.no_install_optional:
        from preflight import preflight_check
        preflight_check(
            workflow="file",
            auto_install=not args.no_auto_install,
            install_optional=not args.no_install_optional,
        )

    # 2026-06-12 — tolerate common business_date input formats and
    # normalise to DD-MM-YYYY for the polling_query_sb_to_file bind
    # (``TO_DATE(:2, 'DD-MM-YYYY')``).  Was a strict regex that
    # rejected ISO 8601 and 2-digit-year forms operators commonly pasted.
    try:
        args.business_date = normalize_business_date(args.business_date)
    except ValueError as exc:
        parser.error(str(exc))

    # 1) Pin the log file for the entire run.
    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    set_run_log_file(log_file)

    # 2) Best-effort spark cleanup BEFORE anything else.
    try:
        cleanup_old_spark_uploads()
    except Exception as exc:
        logger.warning("Spark cleanup failed (continuing): %s", exc)

    # 3) Load configs.
    if not os.path.exists(args.config_path):
        raise FileNotFoundError(f"Configuration file not found: {args.config_path}")
    with open(args.config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    if "oracle" not in config:
        raise ValueError(f"oracle_config.yaml missing 'oracle' section: {args.config_path}")

    if not os.path.exists(args.queries_path):
        raise FileNotFoundError(f"Queries file not found: {args.queries_path}")
    with open(args.queries_path, "r", encoding="utf-8") as f:
        queries = yaml.safe_load(f) or {}
    if "polling_query_sb_to_file" not in queries:
        raise ValueError(
            "polling_query_sb_to_file not found in etl_polling_task_query.yaml"
        )

    # 2026-06-22 -- route through oracle_config_loader so vault-based
    # secret_ref resolution kicks in when ETL_USE_VAULT=1.  Literal
    # etl_connection_string in yaml STILL WINS when set (back-compat).
    from oracle_config_loader import resolve_etl_connection_string
    worker_connection_string = resolve_etl_connection_string(config)
    if not worker_connection_string:
        raise ValueError(
            "ETL Oracle connection string unresolved.  Set either "
            "oracle.etl_connection_string in yaml, oracle.etl.secret_ref "
            "(vault) + dsn_host, or ETL_ORACLE_CONN env var."
        )
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # 4) Fetch all tasks for this RUN_ID.
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_sb_to_file"],
        {"1": args.report_id, "2": args.business_date, "3": args.dag_id},
        worker_connection_string,
    )
    if tasks_df is None or tasks_df.empty:
        logger.info(
            "No tasks for report_id=%s business_date=%s dag_id=%s",
            args.report_id, args.business_date, args.dag_id,
        )
        return
    tasks = tasks_df.to_dict(orient="records")
    # Normalize keys to lowercase so step code can use task['run_id'] etc.
    tasks = [{(k.lower() if isinstance(k, str) else k): v for k, v in row.items()}
              for row in tasks]
    # Stable SEQ ordering
    tasks.sort(key=lambda t: int(t.get("seq") or 0))

    for t in tasks:
        t["task_id"] = t.get("run_id")
        t["dag_run_id"] = f"run_{t.get('run_id')}"

    # 5) Build the run report.  EVERY write path resolves from the
    # polling row first, then oracle_config.yaml's run_report block,
    # then a sensible default — no hard-coded paths in this module.
    sample = tasks[0]

    # 2026-06-18 -- LOG RELOCATION from polling row.  The log file was
    # pinned at line 448 using get_log_dir() (default ETL_LOG_DIR).  If
    # the polling row supplies LOGFILEPATH OR an output_file_location,
    # move the log file there now so all subsequent step logs land
    # alongside the data.  Falls back to the original path on any
    # failure -- never blocks the run.
    _new_log_dir = _resolve_log_dir_from_polling_row(sample)
    if _new_log_dir:
        _new_log = os.path.join(_new_log_dir, os.path.basename(log_file))
        log_file = _relocate_log_file(log_file, _new_log, logger)
        # If a per-module loggers / a separate set_run_log_file was used
        # earlier, refresh it so downstream code sees the new path.
        try:
            set_run_log_file(log_file)
        except Exception:
            pass

    output_dir = (
        sample.get("output_dir")
        or sample.get("output_file_location")
        or os.path.join(get_log_dir(), f"file_flow_run_{args.report_id}_{args.business_date}")
    )
    try:
        os.makedirs(output_dir, exist_ok=True)
    except OSError as exc:
        logger.warning("Could not create output_dir %s: %s", output_dir, exc)

    _rr_cfg = (config.get("run_report") or {}) if isinstance(config, dict) else {}
    # Compute backup_ts here too -- FileRunReport.write() backs up its
    # own .html / .txt independently of the step-level writes.
    _rr_backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    _rr_file_cfg = (config.get("file_flow") or {}) if isinstance(config, dict) else {}
    _rr_prior_mode = (
        (sample.get("prior_output_mode") or sample.get("PRIOR_OUTPUT_MODE"))
        or _rr_file_cfg.get("prior_output_mode")
        or "backup"
    )
    run_report = FileRunReport(
        output_dir=output_dir,
        logger=logger,
        queries_subdir=(
            sample.get("queries_subdir")
            or _rr_cfg.get("queries_subdir", "")
        ),
        report_filename_html=(
            sample.get("report_filename_html")
            or _rr_cfg.get("report_filename_html", "")
        ),
        report_filename_txt=(
            sample.get("report_filename_txt")
            or _rr_cfg.get("report_filename_txt", "")
        ),
        sql_file_extension=(
            sample.get("sql_file_extension")
            or _rr_cfg.get("sql_file_extension", "")
        ),
        backup_ts=_rr_backup_ts,
        prior_output_mode=_rr_prior_mode,
    )
    # 2026-06-17 -- file_name hint from the polling row (FILE_NAME
    # column).  Without this, the FIRST run_report.write() at startup
    # resolves to `run_report.html` (no deliverable known yet) and the
    # FINAL write resolves to `<deliverable>_<business_date>.report.html`
    # -- two different paths.  Dashboards / heartbeat consumers polling
    # the first path forever see "in progress".  By threading the
    # polling-row FILE_NAME as context up front, every write resolves
    # to the SAME `<file_name>_<business_date>.report.html` from start
    # to finish.
    _file_name_hint = (
        sample.get("file_name")
        or sample.get("FILE_NAME")
        or sample.get("output_file_name")
        or sample.get("OUTPUT_FILE_NAME")
        or ""
    )
    run_report.set_context(
        run_id=sample.get("run_id"),
        run_detail_id=sample.get("run_detail_id"),
        dag_id=args.dag_id,
        report_id=args.report_id,
        business_date=args.business_date,
        log_file=log_file,
        output_dir=output_dir,
        file_name=_file_name_hint or None,
    )
    # 2026-06-13 -- 170M concern: opt-in chunk preservation on failure.
    # When `preserve_chunks_on_failure: true` is set in the polling row
    # or oracle_config.yaml's file_flow block, RunArtifacts skips the
    # chunk category in cleanup_on_failure so a single late-partition
    # failure doesn't wipe hours of upstream work.
    _preserve_chunks = _truthy_yaml(
        sample.get("preserve_chunks_on_failure")
        or sample.get("PRESERVE_CHUNKS_ON_FAILURE")
        or _rr_file_cfg.get("preserve_chunks_on_failure")
    )
    artifacts = RunArtifacts(
        logger=logger,
        preserve_chunks_on_failure=_preserve_chunks,
    )
    artifacts.add(log_file, RunArtifacts.REPORT)  # so the report shows the log path

    # 2026-06-12 -- pre-run sidecar hygiene.
    # If a sidecar from a PRIOR run with the same run_id is still on
    # disk (e.g. the prior run failed and left it for forensics), rename
    # it to ``<file>.bak_<ts>`` so this run starts with a clean slate.
    # Hydration in early steps would otherwise seed the new run with
    # stale references to files that cleanup_on_failure already
    # removed.  The backup keeps the prior state inspectable.
    #
    # Sidecar lives at log_dir (per-run stable) -- DECOUPLED from the
    # per-row file_location.  Earlier code looped tasks reading
    # file_location, which targeted N different paths for the N polling
    # rows of the same run; the sidecar that mattered lived elsewhere
    # and was never backed up.  Back up each unique (sidecar_dir, run_id)
    # pair, falling back to file_location for back-compat with older runs.
    _run_sidecar_dir = os.path.dirname(log_file) if log_file else ""
    _seen_backups = set()
    for _t in tasks:
        _bases = []
        if _run_sidecar_dir:
            _bases.append(_run_sidecar_dir)
        _legacy = (
            _t.get("file_location")
            or _t.get("output_file_location")
            or _t.get("output_dir")
        )
        if _legacy and _legacy not in _bases:
            _bases.append(_legacy)
        _rid = _t.get("run_id")
        for _b in _bases:
            _key = (_b, _rid)
            if _key in _seen_backups:
                continue
            _seen_backups.add(_key)
            backup_stale_sidecar(_b, _rid, logger=logger)

    # 2026-06-21 -- ORPHAN-QUERY CLEANUP at startup.
    #
    # Real scenario from pilot: operator ran 8-chunk job, network dropped
    # mid-run, 2 chunks still RUNNING on Trino when client died.  No client
    # cleanup ran -> the 2 queries kept running on the cluster.  Operator
    # restarted the workflow -> the 2 new chunks for the same partitions
    # COLLIDED with the 2 orphans writing to the same staging dir.
    #
    # Fix: at startup, scan Trino for queries tagged with our run_id and
    # kill them via system.runtime.kill_query.  Safe: only kills queries
    # with OUR run_id tag (set by StarburstConnection.connect every job).
    # Skipped silently when Trino role lacks system.runtime privilege.
    # Operator opt-out via polling-row SKIP_ORPHAN_KILL='TRUE'.
    _skip_orphan_kill = (
        str(sample.get("skip_orphan_kill") or sample.get("SKIP_ORPHAN_KILL") or "")
        .strip().upper() in {"TRUE", "1", "YES", "Y", "T"}
    )
    if not _skip_orphan_kill:
        # 2026-06-22 -- build minimal Trino connection config from the
        # SHARED starburst_config.yaml (NOT from polling row).  Per
        # user direction: "file_standalone doesn't read from polling
        # row" + "starburst details should come from common config
        # files... single truth of source".
        # Orphan-query lookup needs ONE working endpoint; CLOUD
        # preferred, ONPREM fallback.  Either works because orphans
        # are matched by run_id tag, not by source.
        _scan_cfg = None
        try:
            from starburst_config_loader import shared_creds_for
            cloud = shared_creds_for("oncloud")
            if cloud.get("host"):
                _scan_cfg = {
                    "host":     cloud["host"],
                    "port":     int(cloud.get("port") or 443),
                    "user":     cloud["user"],
                    "password": cloud["password"],
                    "catalog":  cloud["catalog"],
                    "schema":   cloud["schema"],
                    "use_ssl":  True,
                }
            else:
                onprem = shared_creds_for("onprem")
                if onprem.get("host"):
                    _scan_cfg = {
                        "host":     onprem["host"],
                        "port":     int(onprem.get("port") or 443),
                        "user":     onprem["user"],
                        "password": onprem["password"],
                        "catalog":  onprem["catalog"],
                        "schema":   onprem["schema"],
                        "use_ssl":  True,
                    }
        except ImportError:
            logger.warning(
                "starburst_config_loader unavailable; orphan-kill scan "
                "skipped (no polling-row fallback by design)."
            )
        if _scan_cfg and _scan_cfg.get("host"):
            try:
                from steps.file.starburst_file_base import kill_orphan_trino_queries
                _unique_run_ids = {t.get("run_id") for t in tasks}
                for _rid in _unique_run_ids:
                    if _rid is None:
                        continue
                    try:
                        await kill_orphan_trino_queries(
                            _scan_cfg, _rid, logger=logger, task=sample,
                        )
                    except Exception as _kx:
                        logger.warning(
                            "Orphan-query cleanup for run_id=%s raised "
                            "(%s) -- continuing with new run.",
                            _rid, _kx,
                        )
            except ImportError as _imp:
                logger.info(
                    "Orphan-query cleanup helper unavailable (%s) -- "
                    "skipping.  Set SKIP_ORPHAN_KILL='TRUE' to silence.",
                    _imp,
                )
        else:
            logger.info(
                "Orphan-query cleanup skipped -- no Trino connection "
                "info on polling row (c_hostname / p_hostname both empty)."
            )

    # 6) Start email (best-effort; never raises).
    run_report.mark_started()
    email_cfg = _email_config_from(config, sample)
    run_report.write()
    run_report.send_email(email_cfg)

    # 2026-06-22 -- destination DB string also routes through the loader
    # so vault-based oracle.destination.secret_ref fires when set.
    # Polling-row db_connection column STILL wins (highest priority).
    from oracle_config_loader import resolve_dest_connection_string
    dest_connection_string = (
        sample.get("db_connection")
        or resolve_dest_connection_string(config)
        or ""
    )

    exit_code = 0
    failure_message = ""
    try:
        await execute_tasks(
            tasks=tasks,
            config=config,
            worker_connection_string=worker_connection_string,
            dest_connection_string=dest_connection_string,
            log_file=log_file,
            run_report=run_report,
            artifacts=artifacts,
        )
        run_report.mark_success()
        # Lift G1-G5 counts from the last task dict (every step updates them).
        last = tasks[-1] if tasks else {}
        run_report.set_counts(
            expected_total=last.get("expected_total"),
            sum_partition_expected=last.get("sum_partition_expected"),
            sum_chunk_actual=last.get("sum_chunk_actual"),
            consolidated_total=last.get("consolidated_total"),
        )
        # 2026-06-12 -- on SUCCESS, delete the sidecar.  It's a
        # cross-step handoff aid; once the run is complete it's just
        # clutter on NFS AND would seed a future re-run with the same
        # run_id with stale state.  On FAILURE the sidecar is
        # intentionally NOT deleted (see the except branch) so the
        # operator can inspect what happened.
        #
        # Sidecar location is the per-run stable log_dir (matches where
        # save_task_state / hydrate_task_from_sidecar look thanks to
        # task["sidecar_dir"] injection above); also clean any legacy
        # per-row file_location sidecars from older builds.
        _seen_deletes = set()
        for _t in tasks:
            _bases = []
            _sd = _t.get("sidecar_dir")
            if _sd:
                _bases.append(_sd)
            _fallback = _t.get("output_dir") or _t.get("file_location")
            if _fallback and _fallback not in _bases:
                _bases.append(_fallback)
            _rid = _t.get("run_id")
            for _b in _bases:
                _key = (_b, _rid)
                if _key in _seen_deletes:
                    continue
                _seen_deletes.add(_key)
                delete_sidecar(_b, _rid, logger=logger)
    except Exception as exc:
        import traceback
        # 2026-06-22 -- use the COMMON failure-handling helper from
        # StandaloneRunLifecycle so every workflow (oracle, s3_query,
        # sap_odata via __aexit__; file + file_to_oracle inline) follows
        # the SAME failure-email contract.  Email utility is common
        # across all 5 standalones via this single helper.
        from standalone_lifecycle import StandaloneRunLifecycle
        StandaloneRunLifecycle.handle_run_failure(
            run_report=run_report,
            exc=exc,
            traceback_text=traceback.format_exc(),
            logger=logger,
            log_file=log_file,
            artifacts=artifacts,
        )
        exit_code = 1
    finally:
        # 7) Final report + finish email -- always.  Shared helper.
        from standalone_lifecycle import StandaloneRunLifecycle
        StandaloneRunLifecycle.finalise_run_report(
            run_report, email_cfg, logger,
        )

    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    asyncio.run(main())
