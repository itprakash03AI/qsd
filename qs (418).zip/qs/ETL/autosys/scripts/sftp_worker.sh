#!/usr/bin/env bash
# =====================================================================
# sftp_worker.sh -- Autosys og_sftp_worker command.
#
# One file pair per invocation.  Steps:
#   1. Atomic-move .gz + .ctl + .READY from queue/<dest>/ to
#      inflight/<dest>/.  Prevents the poller from re-firing while
#      we're working.
#   2. Recompute MD5 of the .gz on this Linux box.
#   3. sed-replace the literal {md5_checksum} placeholder in the .ctl
#      with the freshly computed MD5.  (CreateControlFile on the
#      OpenShift side left the placeholder for us to fill -- see
#      ETL/steps/file/create_ctl_file.py docstring.)
#   4. SFTP the .gz + .ctl to the destination.
#   5. On success: move pair to done/<dest>/ + audit row.
#      On failure: bump attempt counter, move to failed/<dest>/.
#
# Concurrency is capped by Autosys (max_load=5 on og_sftp_worker).
# This script itself is single-threaded -- one file per process.
# =====================================================================
set -euo pipefail

ETC=${OG_SFTP_ETC:-/opt/og_etl/etc}
# shellcheck disable=SC1090
source "$ETC/og_sftp.env"

QUEUE_ROOT=${OG_SFTP_QUEUE_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/queue}
INFLIGHT_ROOT=${OG_SFTP_INFLIGHT_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/inflight}
DONE_ROOT=${OG_SFTP_DONE_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/done}
FAILED_ROOT=${OG_SFTP_FAILED_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/failed}
AUDIT_ROOT=${OG_SFTP_AUDIT_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/audit}
LOG=${OG_SFTP_WORKER_LOG:-/usr/local/spark/nfs/bcp/batch/sftp/logs/worker.$(date +%Y%m%d).log}

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') | worker[$$] | $*" >>"$LOG"; }
audit() {
  local outcome="$1" base="$2" dest="$3" md5="$4" attempt="$5" duration="$6" err="$7"
  local audit_file="$AUDIT_ROOT/$(date +%Y-%m-%d).csv"
  mkdir -p "$AUDIT_ROOT"
  if [[ ! -s "$audit_file" ]]; then
    echo "timestamp,outcome,destination,file,md5,attempt,duration_sec,error" >>"$audit_file"
  fi
  echo "$(date -Iseconds),$outcome,$dest,$base,$md5,$attempt,$duration,${err//,/;}" >>"$audit_file"
}

if [[ $# -ne 1 ]]; then
  log "ERROR: usage: $0 <queue-path-of-gz-file>"
  exit 2
fi
SRC_GZ="$1"
if [[ ! -f "$SRC_GZ" ]]; then
  log "ERROR: source gz not found: $SRC_GZ"
  exit 2
fi

base_with_ext=$(basename "$SRC_GZ")
base=${base_with_ext%.gz}
src_dir=$(dirname "$SRC_GZ")
dest=$(basename "$src_dir")

src_ctl="$src_dir/$base.ctl"
src_ready="$src_dir/${base_with_ext%.gz}.READY"
if [[ ! -f "$src_ready" ]]; then
  # Some pipelines write the READY marker with the .gz basename
  # rather than the .dat basename -- try the alternative form.
  src_ready="$src_dir/$base_with_ext.READY"
fi

# ---------------------------------------------------------------------
# 1. Atomic claim (move to inflight/)
# ---------------------------------------------------------------------
inflight_dir="$INFLIGHT_ROOT/$dest"
mkdir -p "$inflight_dir"
inflight_gz="$inflight_dir/$base_with_ext"
inflight_ctl="$inflight_dir/$base.ctl"
inflight_ready="$inflight_dir/$(basename "$src_ready")"

# mv across the same NFS export is atomic at the inode level on most
# enterprise NAS.  If the rename races another worker, the second
# loses and exits 0 -- another worker has the file.
if ! mv "$SRC_GZ" "$inflight_gz" 2>/dev/null; then
  log "SKIP $dest/$base_with_ext -- already claimed by another worker"
  exit 0
fi
mv "$src_ctl"    "$inflight_ctl"   || true
mv "$src_ready"  "$inflight_ready" || true
rm -f "$inflight_ready"  # marker no longer needed once claimed
log "CLAIMED $dest/$base_with_ext"

start_ts=$(date +%s)
attempt_file="$inflight_dir/.attempts.$base"
attempt=$(( $(cat "$attempt_file" 2>/dev/null || echo 0) + 1 ))
echo "$attempt" >"$attempt_file"

cleanup_on_failure() {
  # Move pair to failed/ with the attempt counter.  og_sftp_retry
  # will move it back to queue/ after backoff (until max attempts).
  local reason="$1"
  failed_dir="$FAILED_ROOT/$dest"
  mkdir -p "$failed_dir"
  mv -f "$inflight_gz" "$failed_dir/" 2>/dev/null || true
  mv -f "$inflight_ctl" "$failed_dir/" 2>/dev/null || true
  mv -f "$attempt_file" "$failed_dir/.attempts.$base" 2>/dev/null || true
  log "FAILED $dest/$base attempt=$attempt reason=$reason"
  audit "FAILED" "$base" "$dest" "" "$attempt" "$(( $(date +%s) - start_ts ))" "$reason"
}
trap 'cleanup_on_failure "trap"' ERR

# ---------------------------------------------------------------------
# 2. Recompute MD5 of the .gz (canonical hash of what we ship)
# ---------------------------------------------------------------------
md5_hash=$(md5sum "$inflight_gz" | awk '{print $1}')
log "MD5 $dest/$base_with_ext = $md5_hash"

# ---------------------------------------------------------------------
# 3. Fill the {md5_checksum} placeholder in the .ctl
# ---------------------------------------------------------------------
if ! grep -q '{md5_checksum}' "$inflight_ctl"; then
  log "WARN $dest/$base.ctl has no {md5_checksum} placeholder -- shipping as-is"
else
  # sed -i with a tmp + mv is safer than direct in-place edit on NFS.
  tmp_ctl="$inflight_ctl.tmp"
  sed "s|{md5_checksum}|$md5_hash|g" "$inflight_ctl" >"$tmp_ctl"
  mv -f "$tmp_ctl" "$inflight_ctl"
  log "filled placeholder in $dest/$base.ctl"
fi

# ---------------------------------------------------------------------
# 4. SFTP the pair to the destination
# ---------------------------------------------------------------------
# Destination credentials + remote path are sourced from og_sftp.env's
# per-destination block.  Convention:
#   OG_SFTP_${DEST}_HOST     -- hostname / IP
#   OG_SFTP_${DEST}_USER     -- SFTP user
#   OG_SFTP_${DEST}_KEY      -- path to private key
#   OG_SFTP_${DEST}_REMOTE   -- remote upload dir
DEST_UPPER=$(echo "$dest" | tr '[:lower:]' '[:upper:]')
HOST_VAR="OG_SFTP_${DEST_UPPER}_HOST"
USER_VAR="OG_SFTP_${DEST_UPPER}_USER"
KEY_VAR="OG_SFTP_${DEST_UPPER}_KEY"
REMOTE_VAR="OG_SFTP_${DEST_UPPER}_REMOTE"
host=${!HOST_VAR:-}
user=${!USER_VAR:-}
key=${!KEY_VAR:-}
remote=${!REMOTE_VAR:-}

if [[ -z "$host" || -z "$user" || -z "$key" || -z "$remote" ]]; then
  cleanup_on_failure "destination env vars missing for $DEST_UPPER"
  exit 1
fi

# OpenSSH sftp batch file -- avoids interactive auth.
sftp_batch=$(mktemp "$inflight_dir/.sftp.XXXXXX")
trap 'rm -f "$sftp_batch"' EXIT
cat >"$sftp_batch" <<EOF
cd $remote
put $inflight_gz
put $inflight_ctl
quit
EOF

log "SFTP -> $user@$host:$remote ($base_with_ext + $base.ctl)"
if ! sftp -oBatchMode=yes -oStrictHostKeyChecking=accept-new \
        -i "$key" -b "$sftp_batch" "$user@$host" >>"$LOG" 2>&1; then
  cleanup_on_failure "sftp command failed"
  exit 1
fi

# ---------------------------------------------------------------------
# 5. Success -- move to done/ and audit
# ---------------------------------------------------------------------
done_dir="$DONE_ROOT/$dest/$(date +%Y-%m-%d)"
mkdir -p "$done_dir"
mv -f "$inflight_gz" "$done_dir/"
mv -f "$inflight_ctl" "$done_dir/"
rm -f "$attempt_file"

duration=$(( $(date +%s) - start_ts ))
log "DONE $dest/$base_with_ext duration=${duration}s attempt=$attempt"
audit "OK" "$base" "$dest" "$md5_hash" "$attempt" "$duration" ""
trap - ERR
exit 0
