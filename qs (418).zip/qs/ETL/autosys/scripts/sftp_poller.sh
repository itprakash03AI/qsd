#!/usr/bin/env bash
# =====================================================================
# sftp_poller.sh -- Autosys og_sftp_poller command.
#
# Walks the NFS SFTP queue tree for *.READY markers and force-starts
# the parametrised og_sftp_worker once per ready file pair.
#
# DESIGN:
#   * .READY is the LAST file the OpenShift pod writes.  Its presence
#     guarantees both the .gz AND .ctl are fully fsync'd.
#   * Once the worker is fired, the poller does NOT delete .READY --
#     the WORKER deletes it after claiming the pair (atomic move to
#     inflight/).  This prevents the poller from re-firing the same
#     file every tick while the worker is still claiming it.
#   * Poller exits 0 even when there's nothing to do (Autosys success).
# =====================================================================
set -euo pipefail

ETC=${OG_SFTP_ETC:-/opt/og_etl/etc}
# shellcheck disable=SC1090
source "$ETC/og_sftp.env"

QUEUE_ROOT=${OG_SFTP_QUEUE_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/queue}
INFLIGHT_ROOT=${OG_SFTP_INFLIGHT_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/inflight}
LOG=${OG_SFTP_POLLER_LOG:-/usr/local/spark/nfs/bcp/batch/sftp/logs/poller.$(date +%Y%m%d).log}

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') | poller | $*" >>"$LOG"; }

log "scan start (queue=$QUEUE_ROOT)"

if [[ ! -d "$QUEUE_ROOT" ]]; then
  log "queue root does not exist -- nothing to do"
  exit 0
fi

# Iterate every .READY marker under queue/<dest>/.  Sorted so the
# oldest goes first (FIFO) -- avoids starvation on a long backlog.
fired=0
while IFS= read -r -d '' ready_path; do
  # ready_path = /.../queue/destX/report_31__report.dat.READY
  dest_dir=$(dirname "$ready_path")
  dest=$(basename "$dest_dir")
  marker=$(basename "$ready_path")
  base=${marker%.READY}  # report_31__report.dat
  gz_path="$dest_dir/$base.gz"
  ctl_path="$dest_dir/$base.ctl"

  # Defensive: skip if the pair isn't actually present yet (pod crashed
  # mid-write).  The marker stays so the next tick re-evaluates.
  if [[ ! -f "$gz_path" ]] || [[ ! -f "$ctl_path" ]]; then
    log "SKIP $dest/$base -- gz or ctl missing"
    continue
  fi

  # Per-destination inflight directory must exist for the atomic
  # move the worker performs.
  mkdir -p "$INFLIGHT_ROOT/$dest"

  log "FIRE worker for $dest/$base.gz"
  # Fire the parametrised worker.  Each force-start spawns a fresh
  # Autosys run history row -- per-file audit in the GUI / DB.
  sendevent \
    -E FORCE_STARTJOB \
    -J og_sftp_worker \
    -A "OG_FILE_PATH=$gz_path" \
    >>"$LOG" 2>&1 || {
      log "ERROR sendevent failed for $gz_path"
      continue
    }
  fired=$((fired + 1))
done < <(find "$QUEUE_ROOT" -mindepth 2 -maxdepth 2 -name '*.READY' -print0 | sort -z)

log "scan done -- fired $fired worker instance(s)"
exit 0
