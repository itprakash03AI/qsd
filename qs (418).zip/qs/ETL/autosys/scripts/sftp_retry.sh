#!/usr/bin/env bash
# =====================================================================
# sftp_retry.sh -- Autosys og_sftp_retry command.
#
# Walks failed/<dest>/ and moves files back to queue/<dest>/ for the
# next poller tick to fire, subject to:
#   * attempt_count < OG_SFTP_MAX_ATTEMPTS (default 3)
#   * file age >= backoff(attempt) where backoff = 5 * 2^(attempt-1) min
#       attempt 1 failed -> retry after 5 min
#       attempt 2 failed -> retry after 10 min
#       attempt 3 failed -> KEPT in failed/, alert sent
#
# Alerts on max-attempts-exhausted files via a sentinel file
# .alert.<dest>.<base> that an external monitoring job picks up
# (or you can wire a mail / Slack hook here).
# =====================================================================
set -euo pipefail

ETC=${OG_SFTP_ETC:-/opt/og_etl/etc}
# shellcheck disable=SC1090
source "$ETC/og_sftp.env"

QUEUE_ROOT=${OG_SFTP_QUEUE_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/queue}
FAILED_ROOT=${OG_SFTP_FAILED_ROOT:-/usr/local/spark/nfs/bcp/batch/sftp/failed}
LOG=${OG_SFTP_RETRY_LOG:-/usr/local/spark/nfs/bcp/batch/sftp/logs/retry.$(date +%Y%m%d).log}
MAX_ATTEMPTS=${OG_SFTP_MAX_ATTEMPTS:-3}

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') | retry | $*" >>"$LOG"; }

log "sweep start"
now_epoch=$(date +%s)
requeued=0
held=0
exhausted=0

if [[ ! -d "$FAILED_ROOT" ]]; then
  log "no failed/ dir -- nothing to do"
  exit 0
fi

# Iterate per-destination failed dirs.
for dest_dir in "$FAILED_ROOT"/*/; do
  [[ -d "$dest_dir" ]] || continue
  dest=$(basename "$dest_dir")

  while IFS= read -r -d '' gz_path; do
    base_with_ext=$(basename "$gz_path")  # report_31__report.dat.gz
    base=${base_with_ext%.gz}             # report_31__report.dat
    ctl_path="$dest_dir/$base.ctl"
    attempt_file="$dest_dir/.attempts.$base"
    attempt=$(cat "$attempt_file" 2>/dev/null || echo 1)

    # Exhausted?  Park + alert.
    if (( attempt >= MAX_ATTEMPTS )); then
      alert_file="$dest_dir/.alert.$base"
      if [[ ! -f "$alert_file" ]]; then
        touch "$alert_file"
        log "EXHAUSTED $dest/$base after $attempt attempts -- alert sentinel created"
        exhausted=$((exhausted + 1))
        # Optional: trigger immediate alert here.  Examples:
        #   echo "SFTP exhausted: $dest/$base" | mail -s "[OG-SFTP] $dest" ops@yourorg
        #   curl -s -X POST -d "{\"text\":\"SFTP fail $dest/$base\"}" "$SLACK_HOOK"
      fi
      continue
    fi

    # Backoff: 5 * 2^(attempt-1) minutes from last modify time.
    last_modify=$(stat -c %Y "$gz_path")
    backoff_min=$(( 5 * (1 << (attempt - 1)) ))
    age_sec=$(( now_epoch - last_modify ))
    if (( age_sec < backoff_min * 60 )); then
      held=$((held + 1))
      continue
    fi

    # Requeue: move back to queue/<dest>/.
    queue_dir="$QUEUE_ROOT/$dest"
    mkdir -p "$queue_dir"
    mv -f "$gz_path" "$queue_dir/" || { log "WARN could not requeue $gz_path"; continue; }
    [[ -f "$ctl_path" ]] && mv -f "$ctl_path" "$queue_dir/"
    [[ -f "$attempt_file" ]] && mv -f "$attempt_file" "$queue_dir/.attempts.$base"
    # New READY marker so the poller picks it up.
    touch "$queue_dir/$base.READY"
    log "REQUEUED $dest/$base_with_ext attempt=$attempt backoff=${backoff_min}min"
    requeued=$((requeued + 1))
  done < <(find "$dest_dir" -maxdepth 1 -name '*.gz' -print0)
done

log "sweep done -- requeued=$requeued held=$held exhausted=$exhausted"
exit 0
