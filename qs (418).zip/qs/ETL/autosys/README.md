# OG-ETL Autosys SFTP delivery — 3 jobs handle 100+ daily SFTPs

OpenShift pods write the data archive + CTL + a `.READY` marker into the
NFS SFTP staging tree.  Three Autosys jobs on a Linux box pick them up,
recompute MD5, fill the CTL placeholder, and SFTP to the destination.

## Layout

```
/usr/local/spark/nfs/bcp/batch/sftp/
├── queue/                              # OpenShift pod writes HERE
│   └── <dest>/                         # one subdir per destination
│       ├── report_31__report.dat.gz
│       ├── report_31__report.dat.ctl
│       └── report_31__report.dat.READY # marker = pair is fsync'd
├── inflight/                           # claimed by a worker (atomic mv)
│   └── <dest>/
├── done/                               # delivered OK
│   └── <dest>/<YYYY-MM-DD>/
├── failed/                             # all retries exhausted OR retrying
│   └── <dest>/
├── audit/                              # per-attempt audit CSV
│   └── <YYYY-MM-DD>.csv
└── logs/                               # poller / worker / retry stdout
```

## Jobs (3 total)

| Job | Cadence | Concurrency | What it does |
|---|---|---|---|
| `og_sftp_poller` | every 30s in window | n/a (single instance) | finds `.READY` markers, force-starts workers |
| `og_sftp_worker` | on demand (one per file) | `max_load=5` | MD5 + fill CTL + SFTP + move to done/ or failed/ |
| `og_sftp_retry`  | every 5 min in window | n/a (single instance) | move failed/ back to queue/ with exponential backoff |

### Why 3 jobs, not 100

- One JIL per file = 100 JIL definitions to maintain and 100 rows in
  the Autosys GUI for the same conceptual operation.  Painful.
- The parametrised worker pattern (`FORCE_STARTJOB -A "OG_FILE_PATH=..."`)
  spawns one Autosys run-history row PER FIRE — you still get per-file
  audit in the GUI / DB without the JIL bloat.
- Autosys regularly handles 10K+ jobs in enterprise deployments; the
  question is JIL maintainability, not Autosys throughput.

### Concurrency math

100+ files/day × ~50 MB avg = ~5 GB / 4-hour window = trivial bandwidth.
The cap that matters is **concurrent SFTP sessions per source IP** —
most enterprise SFTP servers throttle at 5–10.  `max_load=5` on
`og_sftp_worker` matches that.

For wildly different per-destination throttles, the JIL has an optional
per-destination worker block (see bottom of `sftp_delivery.jil`).

## Files in this dir

```
sftp_delivery.jil           # JIL for the 3 jobs (insert via jil < file)
scripts/sftp_poller.sh      # og_sftp_poller command
scripts/sftp_worker.sh      # og_sftp_worker command
scripts/sftp_retry.sh       # og_sftp_retry command
og_sftp.env.example         # copy to /opt/og_etl/etc/og_sftp.env, fill secrets, chmod 600
```

## OpenShift pod side — the NFS handoff contract

The pod's `CreateControlFile` step (`ETL/steps/file/create_ctl_file.py`)
writes `<file>.ctl` with the literal `{md5_checksum}` placeholder.  The
worker's `sed` pass replaces it with the freshly computed MD5.  Don't
fill the placeholder inline on the pod side (`task["inline_checksums"]`
must NOT be set when delivering through Autosys).

After writing both `<file>.gz` and `<file>.ctl`, the pod writes
`<file>.READY` LAST.  The poller will not fire until that marker
exists, which guarantees both halves of the pair are present + fsync'd.

For the marker convention, your delivery step on the pod should do:

```python
gz_path  = os.path.join(queue_dir, f"{base}.gz")
ctl_path = os.path.join(queue_dir, f"{base}.ctl")
# ... write gz + ctl, fsync ...
ready_path = os.path.join(queue_dir, f"{base}.READY")
open(ready_path, "w").close()  # zero-byte marker
```

The basename pair contract holds: `<base>.gz` ⇔ `<base>.ctl` ⇔
`<base>.READY` all share the same `<base>`.

## Failure semantics

- Worker fails (SFTP timeout, bad creds, missing dest env) → pair
  moves to `failed/<dest>/`, attempt counter bumps.
- `og_sftp_retry` (every 5 min) checks the age + attempt count:
  - attempt 1, age ≥ 5 min → requeue
  - attempt 2, age ≥ 10 min → requeue
  - attempt 3 reached → park in `failed/`, write `.alert.<base>` sentinel
- An external monitoring job watches `.alert.*` files and pages ops.

## Audit

Every attempt (OK and FAILED) appends a row to
`audit/<YYYY-MM-DD>.csv`:

```
timestamp,outcome,destination,file,md5,attempt,duration_sec,error
2026-06-12T22:01:14+00:00,OK,FRB,report_31__report.dat,af09...,1,3,
2026-06-12T22:01:18+00:00,FAILED,ICE,report_5__report.dat,,1,12,sftp command failed
```

Cheap to load into a dashboard or grep for post-mortem.

## Installing

1. Copy `scripts/*.sh` → `/opt/og_etl/scripts/` on the Linux box;
   `chmod 750`, owner `og_etl_svc`.
2. Copy `og_sftp.env.example` → `/opt/og_etl/etc/og_sftp.env`,
   fill in per-destination creds + key paths, `chmod 600`.
3. Generate SSH keys, exchange public keys with each destination SFTP.
4. Install the JIL:
   ```bash
   jil < sftp_delivery.jil
   ```
5. Test a single delivery manually before turning on the poller window:
   ```bash
   # On the OpenShift pod test write:
   touch /usr/local/spark/nfs/bcp/batch/sftp/queue/FRB/test.gz
   touch /usr/local/spark/nfs/bcp/batch/sftp/queue/FRB/test.ctl
   touch /usr/local/spark/nfs/bcp/batch/sftp/queue/FRB/test.READY
   # On the Linux box:
   sendevent -E FORCE_STARTJOB -J og_sftp_poller
   tail -f /usr/local/spark/nfs/bcp/batch/sftp/logs/poller.$(date +%Y%m%d).log
   ```
