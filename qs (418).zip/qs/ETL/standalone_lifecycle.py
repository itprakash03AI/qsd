"""Shared run-lifecycle helper for ETL pipeline standalones.

2026-06-20 -- STRATEGIC: every standalone pipeline (file, file_to_oracle,
oracle, s3_query, sap_odata) needs the SAME run-report + email + cleanup
lifecycle.  Pre-2026-06-20 only file_standalone.py + file_to_oracle_standalone.py
implemented it; the other three pipelines ran without operator-facing
visibility (no result.html, no start/finish email, no cleanup-on-failure).

This module lifts the lifecycle into ONE reusable async context manager so
the other standalones get the SAME behaviour for free:

    async with StandaloneRunLifecycle(
        pipeline="oracle",
        dag_id=args.dag_id, report_id=args.report_id,
        business_date=args.business_date,
        log_file=log_file, config=config, sample=tasks[0],
        logger=logger,
    ) as run_ctx:
        for task in tasks:
            task["_run_report"]  = run_ctx.run_report
            task["_run_artifacts"] = run_ctx.artifacts
        await execute_tasks(...)
    # __aexit__ marks success/failure, cleans artifacts, writes final
    # report, sends finish email -- ALWAYS, success or fail.

Operator activation: same set of polling-row / yaml columns the file
flow already reads (SEND_EMAIL, EMAIL_FROM, EMAIL_TO, SMTP_HOST, etc.).
No new knobs.
"""
from __future__ import annotations

import logging
import os
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional

from steps.file.run_report import FileRunReport
from steps.file.run_state import RunArtifacts


def truthy_yaml(v: Any) -> bool:
    """Treat the usual Oracle/YAML string values as bool.

    Shared between every standalone -- Oracle drivers return strings
    even for boolean-shaped columns, so plain ``bool(v)`` reads inverted
    on quoted ``"FALSE"`` / ``"0"`` / ``"NO"``.
    """
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    return str(v).strip().upper() in {"TRUE", "1", "YES", "Y", "T"}


def build_email_config(config: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
    """Build the email config dict from env vars + yaml + polling-row.

    Resolution order (highest -> lowest priority):
      1. Polling-row columns      (per-job operator override)
      2. ``oracle_config.yaml`` email block (per-environment yaml)
      3. Pod env vars             (cluster-wide defaults from helm)

    Matches the QS API's email_service.py resolution shape so the
    helm-injected ``SMTP_HOST`` / ``SMTP_PASSWORD`` / ``EMAIL_FROM`` /
    ``EMAIL_TO`` env vars actually propagate to the standalones.

    The FileRunReport.send_email() short-circuits when send_email is
    False or smtp_host / email_to / email_from are missing -- so it's
    safe to call unconditionally in any environment.

    2026-06-20 -- added env-var fallback (Phase 152 helm support).
    Cluster-wide SMTP defaults set via helm's ``config.email`` block
    now actually propagate -- pre-fix the env vars were unread.
    """
    email_cfg: Dict[str, Any] = {}

    # 1. Env-var defaults (lowest priority -- helm sets these).
    # Standard names match QS API's email_service.py + helm configmap.
    _env_map = (
        ("SMTP_HOST",        "smtp_host"),
        ("SMTP_PORT",        "smtp_port"),
        ("SMTP_USER",        "smtp_user"),
        ("SMTP_PASSWORD",    "smtp_password"),
        ("SMTP_USE_TLS",     "smtp_use_tls"),
        ("EMAIL_FROM",       "email_from"),
        ("EMAIL_TO",         "email_to"),
        ("EMAIL_SUBJECT",    "email_subject"),
    )
    # Also accept the QS_DEFAULT_* prefix that the helm chart writes
    # (so we don't collide with whatever the operator might have set
    # in their pod env for other reasons).
    for env_key, cfg_key in _env_map:
        v = os.environ.get(f"QS_DEFAULT_{env_key}") or os.environ.get(env_key)
        if v not in (None, "", "0"):
            email_cfg[cfg_key] = v
    # Master enable flag from env -- helm sets QS_DEFAULT_SEND_EMAIL.
    _v = os.environ.get("QS_DEFAULT_SEND_EMAIL") or os.environ.get("SEND_EMAIL")
    if _v not in (None, ""):
        email_cfg["send_email"] = _v

    # 2. yaml block overrides env (operator's oracle_config.yaml).
    yaml_block = (config or {}).get("email", {}) or {}
    for k in (
        "send_email", "smtp_host", "smtp_port", "smtp_user", "smtp_password",
        "smtp_use_tls", "email_from", "email_to", "email_subject",
    ):
        if k in yaml_block:
            email_cfg[k] = yaml_block[k]

    # 3. polling-row overlay (highest priority -- per-job override).
    for src, dst in (
        ("SEND_EMAIL", "send_email"),
        ("SMTP_HOST", "smtp_host"),
        ("SMTP_PORT", "smtp_port"),
        ("SMTP_USER", "smtp_user"),
        ("SMTP_PASSWORD", "smtp_password"),
        ("SMTP_USE_TLS", "smtp_use_tls"),
        ("EMAIL_FROM", "email_from"),
        ("EMAIL_TO", "email_to"),
        ("EMAIL_SUBJECT", "email_subject"),
    ):
        v = task.get(src) or task.get(src.lower())
        if v not in (None, "", 0):
            email_cfg[dst] = v
    return email_cfg


class StandaloneRunLifecycle:
    """Async context manager: build FileRunReport + RunArtifacts, send
    start email, execute, send finish email, clean up on failure.

    Standalones MUST share this lifecycle so every pipeline has the
    SAME operator-visible artefacts (result.html, start/finish email,
    failure cleanup).  Use as::

        async with StandaloneRunLifecycle(
            pipeline="s3_query", dag_id=args.dag_id, ...,
        ) as lc:
            for task in tasks:
                task["_run_report"] = lc.run_report
                task["_run_artifacts"] = lc.artifacts
            await execute_tasks(...)

    Attributes available inside the context block:
      * ``self.run_report``  -- FileRunReport instance
      * ``self.artifacts``   -- RunArtifacts instance
      * ``self.email_cfg``   -- resolved email config dict
      * ``self.output_dir``  -- the resolved output directory

    On any uncaught exception inside the block, __aexit__ calls
    ``artifacts.cleanup_on_failure()`` (drops chunks / consolidated /
    compressed / ctl files) and sends the failure email.  Exception
    is then re-raised so the caller sees the failure.
    """

    def __init__(
        self,
        *,
        pipeline: str,
        dag_id: str,
        report_id: int,
        business_date: str,
        log_file: str,
        config: Dict[str, Any],
        sample: Dict[str, Any],
        logger: logging.Logger,
        output_dir: Optional[str] = None,
        extra_context: Optional[Dict[str, Any]] = None,
    ):
        self.pipeline = pipeline
        self.dag_id = dag_id
        self.report_id = report_id
        self.business_date = business_date
        self.log_file = log_file
        self.config = config or {}
        self.sample = sample or {}
        self.logger = logger
        self.extra_context = dict(extra_context or {})

        # Resolve output_dir from polling row / yaml / default.  When
        # the caller passes an explicit one (already resolved), use it.
        if output_dir:
            self.output_dir = output_dir
        else:
            self.output_dir = self._resolve_output_dir()

        self.run_report: Optional[FileRunReport] = None
        self.artifacts: Optional[RunArtifacts] = None
        self.email_cfg: Dict[str, Any] = {}

    def _resolve_output_dir(self) -> str:
        """Pick the output directory in priority order: polling row ->
        yaml -> log_dir/<pipeline>_run_<report>_<biz>."""
        for key in (
            "output_dir", "OUTPUT_DIR",
            "output_file_location", "OUTPUT_FILE_LOCATION",
            "file_location", "FILE_LOCATION",
            "source_file_location", "SOURCE_FILE_LOCATION",
        ):
            v = self.sample.get(key)
            if v and isinstance(v, str) and v.strip():
                return v.strip()
        # Yaml fallback (optional).
        yaml_dir = (
            (self.config.get(self.pipeline) or {}).get("output_dir")
            or (self.config.get("run_report") or {}).get("output_dir")
        )
        if yaml_dir:
            return str(yaml_dir)
        # Default to log_file's dir + a per-run subdir.
        base = os.path.dirname(self.log_file) if self.log_file else "."
        safe_biz = str(self.business_date).replace("/", "-").replace(" ", "_")
        return os.path.join(base, f"{self.pipeline}_run_{self.report_id}_{safe_biz}")

    async def __aenter__(self) -> "StandaloneRunLifecycle":
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as exc:
            self.logger.warning(
                "Could not create output_dir %s: %s", self.output_dir, exc,
            )

        # FileRunReport configuration -- mirror what file_standalone.py
        # resolves from polling row / yaml.
        _rr_cfg = (self.config.get("run_report") or {})
        _backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        _file_cfg = (self.config.get("file_flow") or {})
        _prior_mode = (
            self.sample.get("prior_output_mode")
            or self.sample.get("PRIOR_OUTPUT_MODE")
            or _file_cfg.get("prior_output_mode")
            or "backup"
        )
        # 2026-06-20 -- advisory-verdict thresholds + filename_priority
        # come from the polling row first, oracle_config.yaml second,
        # FileRunReport class defaults third.  All optional; None is
        # passed through so the constructor uses its tighter defaults.
        def _row_or_yaml(key_upper: str, yaml_key: str) -> Any:
            v = self.sample.get(key_upper) or self.sample.get(yaml_key)
            if v in (None, "", 0):
                v = _rr_cfg.get(yaml_key)
            return v

        _c2_drift = _row_or_yaml("C2_ADVISORY_DRIFT_PCT", "c2_advisory_drift_pct")
        _c2_max = _row_or_yaml("C2_ADVISORY_MAX_ROWS", "c2_advisory_max_rows")
        _c4_max = _row_or_yaml("C4_ADVISORY_NET_DELTA_MAX", "c4_advisory_net_delta_max")
        _fn_pri = _row_or_yaml("FILENAME_PRIORITY", "filename_priority")
        self.run_report = FileRunReport(
            output_dir=self.output_dir,
            logger=self.logger,
            queries_subdir=(
                self.sample.get("queries_subdir")
                or _rr_cfg.get("queries_subdir", "")
            ),
            report_filename_html=(
                self.sample.get("report_filename_html")
                or _rr_cfg.get("report_filename_html", "")
            ),
            report_filename_txt=(
                self.sample.get("report_filename_txt")
                or _rr_cfg.get("report_filename_txt", "")
            ),
            sql_file_extension=(
                self.sample.get("sql_file_extension")
                or _rr_cfg.get("sql_file_extension", "")
            ),
            backup_ts=_backup_ts,
            prior_output_mode=_prior_mode,
            c2_advisory_drift_pct=(
                float(_c2_drift) if _c2_drift not in (None, "") else None
            ),
            c2_advisory_max_rows=(
                int(_c2_max) if _c2_max not in (None, "") else None
            ),
            c4_advisory_net_delta_max=(
                int(_c4_max) if _c4_max not in (None, "") else None
            ),
            filename_priority=(
                str(_fn_pri).strip().lower() if _fn_pri not in (None, "") else None
            ),
        )
        # Polling-row FILE_NAME hint -- _deliverable_basename reads it
        # FIRST so start-of-run + post-step writes resolve to the SAME
        # path (no orphan in backup_<ts>/).
        _file_name_hint = (
            self.sample.get("file_name")
            or self.sample.get("FILE_NAME")
            or self.sample.get("output_file_name")
            or self.sample.get("OUTPUT_FILE_NAME")
            or ""
        )
        ctx_kwargs = {
            "run_id": self.sample.get("run_id"),
            "run_detail_id": self.sample.get("run_detail_id"),
            "dag_id": self.dag_id,
            "report_id": self.report_id,
            "business_date": self.business_date,
            "log_file": self.log_file,
            "output_dir": self.output_dir,
            "workflow": self.pipeline,
        }
        if _file_name_hint:
            ctx_kwargs["file_name"] = _file_name_hint
        ctx_kwargs.update(self.extra_context)
        self.run_report.set_context(**ctx_kwargs)

        # RunArtifacts -- honours preserve_chunks_on_failure when set.
        _preserve = truthy_yaml(
            self.sample.get("preserve_chunks_on_failure")
            or self.sample.get("PRESERVE_CHUNKS_ON_FAILURE")
            or _file_cfg.get("preserve_chunks_on_failure")
        )
        self.artifacts = RunArtifacts(
            logger=self.logger,
            preserve_chunks_on_failure=_preserve,
        )
        if self.log_file:
            self.artifacts.add(self.log_file, RunArtifacts.REPORT)

        # Email config + start email.
        self.email_cfg = build_email_config(self.config, self.sample)
        self.run_report.mark_started()
        try:
            self.run_report.write()
        except Exception as exc:
            self.logger.warning("Start-of-run report write failed: %s", exc)
        try:
            self.run_report.send_email(self.email_cfg)
        except Exception as exc:
            self.logger.warning("Start-of-run email failed: %s", exc)

        return self

    # ------------------------------------------------------------------
    # 2026-06-22 -- COMMON failure-handling helper.
    # Used by:
    #   * StandaloneRunLifecycle.__aexit__ (this class -- oracle, s3_query,
    #     sap_odata)
    #   * file_standalone.py main()'s except block
    #   * file_to_oracle_standalone.py main()'s except block
    # All 5 workflows now produce identical rich failure emails:
    # exception + traceback + WHICH step + WHERE log file is + WHICH pod.
    # ------------------------------------------------------------------

    @staticmethod
    def handle_run_failure(
        run_report,
        exc,
        traceback_text: str,
        logger,
        log_file: Optional[str] = None,
        artifacts=None,
    ) -> None:
        """Shared failure-handler used by every standalone.  Builds the
        rich failure message + calls mark_failed with step_name +
        log_file_path + cleanup_on_failure.

        Args:
            run_report: FileRunReport instance (must have failed_step_name
                + failed_step_seq stashed by the workflow's dispatcher)
            exc: the caught exception
            traceback_text: pre-formatted traceback string
            logger: logger for ERROR-level RUN FAILED line
            log_file: absolute path to the pinned log file (operator
                greps from this in the failure email)
            artifacts: RunArtifacts instance for cleanup_on_failure (or
                None to skip cleanup)
        """
        failure_message = f"{exc}\n\n{traceback_text}"
        try:
            run_report.mark_failed(
                failure_message,
                step_name=getattr(run_report, "failed_step_name", None),
                step_seq=getattr(run_report, "failed_step_seq", None),
                log_file_path=log_file,
            )
        except Exception:
            pass
        logger.error(
            "RUN FAILED: %s\nTRACEBACK:\n%s", exc, traceback_text,
        )
        if artifacts is not None:
            try:
                artifacts.cleanup_on_failure()
            except Exception as cleanup_exc:
                logger.error(
                    "Cleanup-on-failure raised: %s", cleanup_exc,
                )

    @staticmethod
    def finalise_run_report(
        run_report, email_cfg, logger,
    ) -> None:
        """Shared finalize: write the report + send finish email.
        Used in the finally block of every standalone.  Both ops are
        best-effort -- errors logged but never raised."""
        try:
            run_report.write()
        except Exception as exc:
            logger.warning("Final run-report write failed: %s", exc)
        try:
            run_report.send_email(email_cfg)
        except Exception as exc:
            logger.warning("Final run-report email failed: %s", exc)

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type is not None and not issubclass(
            exc_type, (KeyboardInterrupt, SystemExit)
        ):
            # Use the SHARED helper -- same code path as file_standalone +
            # file_to_oracle_standalone, so failure emails are identical
            # across all 5 workflows.
            self.handle_run_failure(
                run_report=self.run_report,
                exc=exc_val,
                traceback_text="".join(traceback.format_tb(exc_tb)),
                logger=self.logger,
                log_file=getattr(self, "log_file", None),
                artifacts=self.artifacts,
            )
        else:
            try:
                self.run_report.mark_success()
            except Exception:
                pass

        # ALWAYS write final report + send finish email -- success OR fail.
        self.finalise_run_report(
            self.run_report, self.email_cfg, self.logger,
        )

        # Do not suppress the exception -- let the caller decide
        # (typically SystemExit non-zero).
        return False
