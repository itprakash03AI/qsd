"""
Generic dispatcher — routes any dag_type to its registered worker class.

Adding a new pipeline type requires:
  1. One new entry in WORKER_REGISTRY below
  2. A new section in config/step_mapping.yaml

No other code changes needed.

BF-595 (2026-05-30): when ``use_lightweight_steps=True`` is passed to
the constructor, dag_type ``createJob`` is rerouted to the
``createJob_light`` step_mapping.yaml section, which uses the
non-Spark Trino→Oracle steps (``LightStarburstToOracle_OnCloud`` /
``LightStarburstToOracle_OnPrem``).  This is the polling-service
default — Spark removed for <500K-row workloads.
"""
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from managers.oracle_metadata_manager import OracleMetadataManager
from workers.oracle_worker import OracleWorker
from workers.sap_odata_worker import SapOdataWorker

try:
    from datasources.starburst_datasource import StarburstDataSource
except ImportError:
    StarburstDataSource = None

# 2026-06-22 -- s3_query SPLIT: was one mixed workflow, now two
# proper ones (s3_to_file, s3_to_oracle).  Both Spark-backed; not
# registered when pyspark is unavailable on lightweight pods.
# S3QueryWorker kept as deprecation shim -> S3ToFileWorker.
try:
    from workers.s3_worker import (
        S3ToFileWorker,
        S3ToOracleWorker,
        S3QueryWorker,
    )
except ImportError:
    S3ToFileWorker = S3ToOracleWorker = S3QueryWorker = None

from log_config import get_log_dir as _get_log_dir
LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Generic worker registry.
# dag_type → (worker_class, needs_starburst_clients)
# All types in step_mapping.yaml are auto-handled via this registry.
WORKER_REGISTRY: Dict[str, Tuple] = {
    "createJob": (OracleWorker, True),
    "file":      (OracleWorker, True),   # same worker, different step_mapping section
    "sap_odata": (SapOdataWorker, False),
}
if S3ToFileWorker is not None:
    WORKER_REGISTRY["s3_to_file"]   = (S3ToFileWorker, False)
    WORKER_REGISTRY["s3_to_oracle"] = (S3ToOracleWorker, False)
    # Deprecation alias -- legacy OTG_DAG_ID="s3_query*" routes here
    # and logs a warning.  Remove once all DAG IDs migrated.
    WORKER_REGISTRY["s3_query"]     = (S3QueryWorker, False)


class Dispatcher:
    """Generic dispatcher — mirrors oracle_standalone.execute_tasks() exactly.

    For each run, instantiates the correct worker via WORKER_REGISTRY, builds
    Starburst clients (if needed), attaches shared context to each task dict,
    then executes each step sequentially — stopping on first failure.

    Note on step_mapping.yaml path: OracleWorker/SapOdataWorker load their
    step mappings from the path hardcoded in each worker class
    (/usr/local/spark/pvc/code/configs/step_mapping.yaml — the production PVC).
    The Dockerfile symlinks /app/config/step_mapping.yaml to that path for
    dev/test environments. No path override is needed here.

    BF-595 / BF-596: ``use_lightweight_steps`` controls Spark vs non-Spark
    routing.  Default False to preserve back-compat with sap_odata_standalone
    / oracle_standalone callers; polling service sets it True.

    BF-596 (2026-05-30): replaced the YAML-section-swap approach
    (createJob_light) with in-memory Python-class swaps via
    LIGHTWEIGHT_STEP_SWAPS.  Rationale: the DB row's TASK_TYPE column
    is the step name (per oracle_standalone.py:54 — ``TASK_TYPE AS
    Task_steps``), so any routing decision driven by a parallel YAML
    section would force operators to either maintain two YAMLs in
    sync OR add new DB rows.  Swapping in-memory keeps the YAML as
    a pure step-name → Python-class CONTRACT and lets the polling
    service flip Spark off via a single config flag, no YAML/DB
    changes required.
    """

    # BF-596: in-memory Python-class swaps applied AFTER
    # ``worker.load_step_mapping(dag_type)`` returns.  Operators do
    # NOT touch this — it's a dispatcher implementation detail.
    # Format: step_name (matches DB TASK_TYPE) → (module_path, class_name).
    # Lazy import via __import__ so the polling-service image doesn't
    # need to load the light step modules until they're actually needed.
    LIGHTWEIGHT_STEP_SWAPS: Dict[str, Tuple[str, str]] = {
        "StarburstToOracleOnCloud": (
            "steps.oracle.light_starburst_to_oracle_oncloud",
            "LightStarburstToOracle_OnCloud",
        ),
        "StarburstToOracleOnPrem": (
            "steps.oracle.light_starburst_to_oracle_onprem",
            "LightStarburstToOracle_OnPrem",
        ),
    }

    def __init__(
        self,
        logger: logging.Logger,
        use_lightweight_steps: bool = False,
    ):
        self.logger = logger
        self.use_lightweight_steps = bool(use_lightweight_steps)
        if self.use_lightweight_steps:
            self.logger.info(
                "Dispatcher: lightweight (no-Spark) mode enabled — "
                "step classes %s will be swapped to their Light* variants "
                "at runtime (YAML unchanged, DB unchanged).",
                sorted(self.LIGHTWEIGHT_STEP_SWAPS.keys()),
            )

    def _apply_lightweight_swaps(self, step_mapping: dict) -> dict:
        """BF-596: overlay the lightweight Python classes on top of the
        YAML-loaded step_mapping for any step name in LIGHTWEIGHT_STEP_SWAPS.

        Returns the same dict object with selected entries replaced.
        Steps NOT in the swap table are left as-is (so polling-pod
        workflows that mix Trino→Oracle with other steps work normally
        — only the Spark-heavy ones get swapped).

        Lazy-imports the light modules to keep import-time cost zero
        when lightweight mode is disabled (e.g. unit-test loops that
        construct dispatchers in tight cycles).
        """
        if not step_mapping:
            return step_mapping
        import importlib
        swapped = []
        for step_name, (module_path, class_name) in self.LIGHTWEIGHT_STEP_SWAPS.items():
            if step_name not in step_mapping:
                # Step isn't in this workflow's mapping — nothing to swap.
                continue
            try:
                mod = importlib.import_module(module_path)
                light_class = getattr(mod, class_name)
                step_mapping[step_name] = light_class
                swapped.append(step_name)
            except (ImportError, AttributeError) as exc:
                # Hard fail — caller asked for lightweight mode and we
                # can't deliver.  Don't silently fall back to Spark
                # (would re-introduce the memory-bomb in a pod that
                # doesn't have the JVM).
                raise RuntimeError(
                    f"BF-596: lightweight swap for step '{step_name}' "
                    f"failed: cannot import {module_path}.{class_name} "
                    f"({exc}).  Either install the light variant or "
                    f"disable use_lightweight_steps."
                ) from exc
        if swapped:
            self.logger.info(
                f"Lightweight mode: swapped {len(swapped)} step class(es) "
                f"to Light* variants: {swapped}"
            )
        return step_mapping

    async def execute(
        self,
        run_id: int,
        tasks: List[dict],
        dag_type: str,
        etl_conn_str: str,
        dest_conn_str: str,
    ) -> None:
        """Execute all steps for one RUN_ID sequentially.

        Args:
            run_id: Oracle RUN_ID (for logging only; already in each task dict)
            tasks:  List of task dicts sorted by SEQ (from Oracle query)
            dag_type: Worker type key from WORKER_REGISTRY (createJob/file/sap_odata)
            etl_conn_str:  Oracle ETL connection string (worker DB)
            dest_conn_str: Oracle destination connection string
        """
        if dag_type not in WORKER_REGISTRY:
            raise ValueError(
                f"Unknown dag_type '{dag_type}' for run_id={run_id}. "
                f"Add it to WORKER_REGISTRY in dispatcher.py."
            )

        worker_cls, needs_starburst = WORKER_REGISTRY[dag_type]
        first_task = tasks[0]

        # Build OracleMetadataManager — one per run (thread-safe, lightweight)
        oracle_mgr = OracleMetadataManager(etl_conn_str)

        # Build log file path (same format as oracle_standalone.py)
        log_file = _build_log_file(
            str(first_task.get("fk_dag_id", "unknown")),
            int(first_task.get("fk_report_id", 0)),
            str(first_task.get("business_date", "unknown")),
        )

        # BF-595 / BF-596: lightweight (no-Spark) mode does NOT touch
        # the YAML routing — `worker.load_step_mapping(dag_type)`
        # returns the standard ``createJob`` / ``file`` / ``sap_odata``
        # section.  Instead we overlay Python-class swaps in memory
        # via ``_apply_lightweight_swaps`` so the DB row's TASK_TYPE
        # column still drives selection AND operators don't maintain
        # a parallel YAML.
        if needs_starburst:
            # BF-595: the light Starburst→Oracle steps do NOT consume the
            # StarburstDataSource clients (they use trino-python-client
            # directly via the step's own config).  Skip the heavy client
            # build in lightweight mode — pass an empty dict to preserve
            # the task['starburst_clients'] contract for non-Starburst
            # steps in the same workflow (CheckDependencies, GenerateSQL, …).
            if self.use_lightweight_steps:
                starburst_clients = {}
            else:
                starburst_clients = _build_starburst_clients(first_task, self.logger)
            worker = worker_cls(starburst_clients, oracle_mgr, self.logger)
            worker.step_mapping = worker.load_step_mapping(dag_type)
            if self.use_lightweight_steps:
                worker.step_mapping = self._apply_lightweight_swaps(worker.step_mapping)
        else:
            worker = worker_cls(oracle_mgr, self.logger)
            starburst_clients = {}

        # Attach shared context to each task dict — steps may read these fields
        dag_run_id = f"bg_run_{run_id}"
        # 2026-06-12 — per-run STABLE sidecar location (decoupled from
        # per-row file_location).  See file_standalone.py for rationale:
        # different polling rows for CLOUD vs ONPREM vs ConsolidateFiles
        # vs CompressFile vs CreateControlFile can carry different
        # file_location values; the sidecar must live in ONE place
        # across them or cross-step state is lost.
        sidecar_dir = os.path.dirname(log_file) if log_file else ""
        # 2026-06-13 — per-run backup_ts for the "rename prior file to
        # backup folder" feature.  Same shape as the standalone.
        backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        # 2026-06-13 — prior-output handling: "backup" or "delete".
        # Polling row's PRIOR_OUTPUT_MODE column wins; default "backup".
        prior_output_mode = (
            first_task.get("prior_output_mode")
            or first_task.get("PRIOR_OUTPUT_MODE")
            or "backup"
        )
        for task in tasks:
            task["starburst_clients"] = starburst_clients
            task["log_file"] = log_file
            task["dag_run_id"] = dag_run_id
            task["task_id"] = task.get("run_id", run_id)
            # 2026-06-12 — promote the polling-row FILE_LOCATION (or
            # equivalent column) onto task["output_dir"] so the file
            # output lands where the polling row says it should.
            fl = (
                task.get("file_location")
                or task.get("output_file_location")
                or task.get("output_dir")
            )
            if fl:
                task["output_dir"] = fl
            # Sidecar location is stable across all tasks in this run;
            # save_task_state / hydrate_task_from_sidecar prefer this
            # over per-task output_dir.
            if sidecar_dir:
                task["sidecar_dir"] = sidecar_dir
            task["backup_ts"] = backup_ts
            task["prior_output_mode"] = prior_output_mode

        self.logger.info(
            f"run_id={run_id} dag_type={dag_type} steps={[t.get('task_steps') for t in tasks]}"
        )

        # 2026-06-12 -- pre-run sidecar hygiene (parity with standalones).
        # Back up any sidecar from a PRIOR failed run with the same run_id
        # so a fresh dispatch starts with a clean slate.  Reads at the
        # per-run-stable sidecar_dir (log dir); also covers legacy per-row
        # file_location sidecars from older builds.
        if sidecar_dir or first_task.get("file_location"):
            try:
                from steps.file.run_state import backup_stale_sidecar
                _seen_backups = set()
                for _t in tasks:
                    _bases = []
                    if sidecar_dir:
                        _bases.append(sidecar_dir)
                    _legacy = (
                        _t.get("file_location")
                        or _t.get("output_file_location")
                        or _t.get("output_dir")
                    )
                    if _legacy and _legacy not in _bases:
                        _bases.append(_legacy)
                    _rid = _t.get("run_id")
                    for _b in _bases:
                        _key = (_b, _rid)
                        if _key in _seen_backups:
                            continue
                        _seen_backups.add(_key)
                        backup_stale_sidecar(_b, _rid, logger=self.logger)
            except ImportError:
                pass  # non-file workflow

        # Execute steps sequentially — same as oracle_standalone.execute_tasks()
        # _all_succeeded flips True only AFTER every task in the loop
        # completes without exception.  Using "did it succeed" rather
        # than "did it fail" so BaseException (KeyboardInterrupt,
        # asyncio.CancelledError) ALSO leaves the sidecar untouched --
        # cancellation mid-run is a forensic-keep case too.
        _all_succeeded = False
        try:
            for task in tasks:
                step_name = task.get("task_steps", "")
                if not step_name:
                    self.logger.warning(
                        f"run_id={run_id}: task row has no task_steps — skipping (seq={task.get('seq')})"
                    )
                    continue
                try:
                    await worker.execute_step(
                        task,
                        etl_conn_str,
                        dest_conn_str,
                        step_name,
                    )
                except Exception as e:
                    self.logger.error(
                        f"run_id={run_id} step={step_name} failed — halting run: {e}"
                    )
                    raise  # Poller._execute_run catches this and records failure
            _all_succeeded = True
        finally:
            # 2026-06-12 -- on SUCCESS, delete the sidecar (cross-step
            # handoff aid; once the run completes it's just clutter on
            # NFS).  On ANY non-success exit (Exception, KeyboardInterrupt,
            # CancelledError) keep it for forensics.  Parity with
            # standalones.
            if _all_succeeded:
                try:
                    from steps.file.run_state import delete_sidecar
                    _seen_deletes = set()
                    for _t in tasks:
                        _bases = []
                        _sd = _t.get("sidecar_dir")
                        if _sd:
                            _bases.append(_sd)
                        _fallback = _t.get("output_dir") or _t.get("file_location")
                        if _fallback and _fallback not in _bases:
                            _bases.append(_fallback)
                        _rid = _t.get("run_id")
                        for _b in _bases:
                            _key = (_b, _rid)
                            if _key in _seen_deletes:
                                continue
                            _seen_deletes.add(_key)
                            delete_sidecar(_b, _rid, logger=self.logger)
                except ImportError:
                    pass  # non-file workflow


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that matches oracle_standalone.py format."""
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"bg_poller_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    return os.path.join(LOG_DIR, filename)


def _build_starburst_clients(first_task: dict, logger: logging.Logger) -> dict:
    """Build Starburst client dict from polling row + shared config fallback.

    2026-06-12 — delegates to ``starburst_config_loader.build_starburst_clients_from_row``
    so this path and ``oracle_standalone.execute_tasks`` use ONE merge
    implementation (single source of truth for the polling-row -> shared-YAML
    fallback chain).
    """
    if StarburstDataSource is None:
        raise RuntimeError(
            "StarburstDataSource could not be imported "
            "(check datasources/starburst_datasource.py is on PYTHONPATH). "
            "Required for createJob/file dag types."
        )
    from starburst_config_loader import build_starburst_clients_from_row
    return build_starburst_clients_from_row(
        first_task, StarburstDataSource, logger=logger,
    )
