"""
FastAPI health/status/control API for the ETL Background Polling Service.

Endpoints (port 9000):
  GET  /health           → 200 {"status": "ok", "active_runs": N, "paused": bool}
  GET  /health/ready     → 200 if Oracle reachable, else 503
  GET  /status           → aggregated stats; ``workflows`` key surfaces
                            per-runner state when multi-workflow mode is on
  GET  /workflows        → list of per-workflow snapshots (multi mode only)
  POST /pause            → pause polling (all runners in multi mode)
  POST /resume           → resume polling
  POST /workflows/{name}/pause   → pause a single runner (multi mode)
  POST /workflows/{name}/resume  → resume a single runner (multi mode)

2026-06-12 — multi-workflow mode.  ``init_health_service`` wires the
``BackgroundService`` instead of the legacy ``BackgroundPoller``.  Both
inject paths are mutually exclusive — main.py picks one based on
``cfg.workflows``.  All endpoints transparently fan out to whichever
backend is wired (back-compat preserved for the single-loop deploy).
"""
import asyncio
import logging
from typing import TYPE_CHECKING

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

if TYPE_CHECKING:
    from polling_service.poller import BackgroundPoller
    from polling_service.service import BackgroundService
    from managers.oracle_metadata_manager import OracleMetadataManager

# Child of "bg_poller" — propagates to the root logger configured in main.py
# so health endpoint logs reach the same console + file as the rest of the service.
# getLogger(__name__) = "polling_service.health" would propagate to root only,
# which has no handlers until main.py runs → INFO logs silently lost.
logger = logging.getLogger("bg_poller.health")

app = FastAPI(title="ETL Background Polling Service", version="1.0.0")

# Injected at startup by main.py — at most ONE of (_poller, _service)
# is non-None for the life of the process.
_poller: "BackgroundPoller | None" = None
_service: "BackgroundService | None" = None
_oracle_manager: "OracleMetadataManager | None" = None
_etl_conn_str: str = ""


def init_health(poller: "BackgroundPoller", oracle_manager: "OracleMetadataManager", etl_conn_str: str) -> None:
    """Inject dependencies for the legacy single-loop path."""
    global _poller, _service, _oracle_manager, _etl_conn_str
    _poller = poller
    _service = None
    _oracle_manager = oracle_manager
    _etl_conn_str = etl_conn_str


def init_health_service(service: "BackgroundService", oracle_manager: "OracleMetadataManager", etl_conn_str: str) -> None:
    """Inject dependencies for the multi-workflow path."""
    global _poller, _service, _oracle_manager, _etl_conn_str
    _poller = None
    _service = service
    _oracle_manager = oracle_manager
    _etl_conn_str = etl_conn_str


def _initialized() -> bool:
    return _poller is not None or _service is not None


@app.get("/health")
async def health() -> JSONResponse:
    """Liveness check — always 200 if the process is running."""
    if not _initialized():
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    if _service is not None:
        return JSONResponse(content={
            "status": "ok",
            "mode": "multi",
            "active_runs": _service.total_active_runs(),
            "paused": _service.paused,
            "worker_id": _service.config.worker_id,
            "workflows": [r.workflow.name for r in _service.runners],
        })
    return JSONResponse(content={
        "status": "ok",
        "mode": "single",
        "active_runs": len(_poller.active_runs),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
    })


@app.get("/health/ready")
async def health_ready() -> JSONResponse:
    """Readiness check — 503 if Oracle is unreachable."""
    if not _initialized() or _oracle_manager is None:
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    try:
        ok = await _oracle_check()
        if ok:
            return JSONResponse(content={"status": "ready"})
        return JSONResponse(status_code=503, content={"status": "oracle_unreachable"})
    except Exception as e:
        logger.warning(f"Readiness check failed: {e}")
        return JSONResponse(status_code=503, content={"status": "error", "detail": str(e)})


@app.get("/status")
async def status() -> JSONResponse:
    """Full stats snapshot — aggregated across runners in multi mode."""
    if not _initialized():
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    if _service is not None:
        return JSONResponse(content={
            **_service.aggregate_stats(),
            "mode": "multi",
            "active_runs": _service.total_active_runs(),
            "active_run_ids": _service.all_active_run_ids(),
            "paused": _service.paused,
            "worker_id": _service.config.worker_id,
            "workflows": _service.workflow_snapshots(),
        })
    return JSONResponse(content={
        **_poller.stats,
        "mode": "single",
        "active_runs": len(_poller.active_runs),
        "active_run_ids": list(_poller.active_runs.keys()),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
        "interval_seconds": _poller.config.interval_seconds,
        "max_concurrent_runs": _poller.config.max_concurrent_runs,
    })


@app.get("/workflows")
async def workflows() -> JSONResponse:
    """Per-workflow snapshots (multi-workflow mode only).

    Returns 404 when running in legacy single-loop mode so operators
    get a clear signal instead of an empty list.
    """
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    if _service is None:
        raise HTTPException(
            status_code=404,
            detail="single-loop mode active — no per-workflow stats. "
                   "Configure polling.workflows in polling_service_config.yaml.",
        )
    return JSONResponse(content={"workflows": _service.workflow_snapshots()})


@app.post("/pause")
async def pause() -> JSONResponse:
    """Pause polling — every runner in multi mode."""
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    if _service is not None:
        _service.pause_all()
        return JSONResponse(content={
            "status": "paused",
            "active_runs": _service.total_active_runs(),
        })
    _poller.pause()
    return JSONResponse(content={"status": "paused", "active_runs": len(_poller.active_runs)})


@app.post("/resume")
async def resume() -> JSONResponse:
    """Resume polling."""
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    if _service is not None:
        _service.resume_all()
        return JSONResponse(content={"status": "resumed"})
    _poller.resume()
    return JSONResponse(content={"status": "resumed"})


@app.post("/workflows/{name}/pause")
async def workflow_pause(name: str) -> JSONResponse:
    """Pause a single runner without affecting siblings."""
    if _service is None:
        raise HTTPException(status_code=404, detail="multi-workflow mode not active")
    runner = _service.find_runner(name)
    if runner is None:
        raise HTTPException(status_code=404, detail=f"no runner '{name}'")
    runner.pause()
    return JSONResponse(content={"status": "paused", "workflow": name})


@app.post("/workflows/{name}/resume")
async def workflow_resume(name: str) -> JSONResponse:
    if _service is None:
        raise HTTPException(status_code=404, detail="multi-workflow mode not active")
    runner = _service.find_runner(name)
    if runner is None:
        raise HTTPException(status_code=404, detail=f"no runner '{name}'")
    runner.resume()
    return JSONResponse(content={"status": "resumed", "workflow": name})


async def _oracle_check() -> bool:
    """Lightweight Oracle connectivity check (async). Fail-open — returns False on any error."""
    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(_oracle_manager.health_check),
            timeout=10.0,
        )
        return bool(result)
    except asyncio.TimeoutError:
        logger.warning("Oracle readiness check timed out (10s)")
        return False
    except Exception as e:
        logger.warning(f"Oracle readiness check failed: {e}")
        return False
