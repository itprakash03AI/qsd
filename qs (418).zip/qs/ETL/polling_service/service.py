"""
BackgroundService — single polling loop + per-workflow runners.

2026-06-12 (revised) — strategic redesign around single-query + Python
routing.

ARCHITECTURE:

  Oracle (Vw_otg_dag_task)
        │
        │ bg_polling_query (one shared SQL, no per-workflow predicate)
        ▼
  BackgroundService._poll_once
        │ group rows by RUN_ID
        │ infer dag_type via polling_service.poller._infer_dag_type
        │   (the canonical OTG_DAG_ID → workflow mapping)
        ▼
  WorkflowRunner.try_dispatch(run_id, tasks, claimer_id, etl_conn_str)
        │ capacity check + cross-pod claim + per-run timeout
        ▼
  Dispatcher.execute(run_id, tasks, dag_type, ...)
        │ load step_mapping section, build worker, execute steps
        ▼
  Step.execute(task, ...)

WHY single-query + routing (vs the per-workflow polling queries of
the previous iteration):
  * ONE place owns the OTG_DAG_ID → workflow mapping (_infer_dag_type).
    The per-workflow polling SQLs had brittle negative discriminators
    on createJob (NOT LIKE %SAP% AND NOT LIKE %FILE% AND ...) that
    drifted any time a new workflow was added.
  * One Oracle round-trip per cycle (was N).
  * Each WorkflowRunner still owns its concurrency cap, stats, pause
    flag — a SAP backlog still can't starve createJob slots.

What is shared:
  * One ``OracleMetadataManager`` (poll + cross-pod claim).
  * One ``Dispatcher`` (the lightweight-vs-Spark image flag is
    service-level via cfg.use_lightweight_steps; per-workflow lightweight
    typing is explicitly rejected — OG DB stays agnostic).
  * One asyncio default-executor (bounded thread pool wired in main.py).
  * One log root + per-runner ``wf.<name>`` child loggers.
"""
from __future__ import annotations

import asyncio
import importlib
import logging
import os
import socket
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

from polling_service.dispatcher import Dispatcher, WORKER_REGISTRY
from polling_service.poller import _infer_dag_type
from polling_service.workflow_runner import WorkflowRunner

if TYPE_CHECKING:
    from polling_service.config import PollingServiceConfig, WorkflowConfig
    from managers.oracle_metadata_manager import OracleMetadataManager


class BackgroundService:
    """Single polling loop; one ``WorkflowRunner`` per enabled workflow.

    Lifecycle:
      __init__   -> build runners + shared Dispatcher (no IO yet)
      start()    -> spawn ONE poll task; wait_for_stop() unblocks on stop()
      stop()     -> sets stop_event, signals every runner.pause-equivalent
      shutdown() -> drain in-flight RUN_ID tasks across runners up to
                    shutdown_timeout, then cancel stragglers
    """

    def __init__(
        self,
        config: "PollingServiceConfig",
        oracle_manager: "OracleMetadataManager",
        logger: logging.Logger,
    ) -> None:
        self.config = config
        self.oracle_manager = oracle_manager
        self.logger = logger
        self.runners: List[WorkflowRunner] = []
        self._poll_task: Optional[asyncio.Task] = None
        self._stopped_event: Optional[asyncio.Event] = None
        # AUDIT-5 idempotency.
        self._started = False
        self._shutdown_done = False
        # Global pause — when True, the poll loop skips its cycle.
        # Per-runner pause is independent (set via runner.pause()).
        self.paused = False

        # Service-level stats — was previously distributed across runners
        # because each owned its own poll loop.  Now centralised.
        self.stats: Dict[str, int] = {
            "polls": 0,
            "unrouted": 0,        # row whose dag_type has no enabled runner
        }

        # Cross-pod claim audit ID — host:pid.  Each runner adds its
        # ``:<workflow>:<pid>`` suffix when invoking try_claim_run so
        # the DBMS_LOCK audit line names the workflow.
        try:
            self._claimer_id = f"{socket.gethostname()}:{os.getpid()}"
        except Exception:
            self._claimer_id = config.worker_id

        self.dispatcher: Optional[Dispatcher] = None
        self._build_runners()

    def _ensure_stopped_event(self) -> asyncio.Event:
        if self._stopped_event is None:
            self._stopped_event = asyncio.Event()
        return self._stopped_event

    @property
    def stopped(self) -> bool:
        return self._stopped_event is not None and self._stopped_event.is_set()

    async def wait_for_stop(self) -> None:
        """Block until ``stop()`` is called."""
        await self._ensure_stopped_event().wait()

    # ── construction ─────────────────────────────────────────────────

    def _build_runners(self) -> None:
        """Materialise one ``WorkflowRunner`` per enabled config entry.

        Single shared Dispatcher — Spark vs no-Spark is image-level
        (cfg.use_lightweight_steps).  See class docstring for why
        per-workflow lightweight typing is rejected.
        """
        cfg = self.config
        if not cfg.workflows:
            return

        self.dispatcher = Dispatcher(
            logger=self.logger.getChild("dispatcher"),
            use_lightweight_steps=cfg.use_lightweight_steps,
        )

        for wf in cfg.workflows:
            if not wf.enabled:
                self.logger.info(
                    f"WorkflowRunner [wf={wf.name}] enabled=false — registered "
                    f"but not started (flip enabled:true in config to start)"
                )
                continue

            self._register_worker_override(wf)

            runner = WorkflowRunner(
                workflow=wf,
                etl_connection_string=cfg.etl_connection_string,
                dest_connection_string=cfg.dest_connection_string,
                oracle_manager=self.oracle_manager,
                dispatcher=self.dispatcher,
                logger=self.logger,
            )
            self.runners.append(runner)

        self.logger.info(
            f"BackgroundService: {len(self.runners)} enabled workflow runner(s): "
            f"{[r.workflow.name for r in self.runners]} "
            f"(use_lightweight_steps={cfg.use_lightweight_steps})"
        )

    def _register_worker_override(self, wf: "WorkflowConfig") -> None:
        """Honour ``WorkflowConfig.worker_class_path`` by extending
        ``Dispatcher.WORKER_REGISTRY`` at startup."""
        if not wf.worker_class_path:
            if wf.name not in WORKER_REGISTRY:
                self.logger.warning(
                    f"[wf={wf.name}] no worker_class_path AND not registered "
                    f"in dispatcher.WORKER_REGISTRY — dispatch will raise. "
                    f"Either add a registry entry in dispatcher.py or set "
                    f"worker_class_path in the workflow config."
                )
            return

        module_path, _, class_name = wf.worker_class_path.rpartition(".")
        if not module_path or not class_name:
            raise ValueError(
                f"[wf={wf.name}] worker_class_path={wf.worker_class_path!r} "
                f"must be a dotted import path like 'workers.oracle_worker.OracleWorker'"
            )
        try:
            module = importlib.import_module(module_path)
            worker_cls = getattr(module, class_name)
        except (ImportError, AttributeError) as exc:
            self.logger.error(
                f"[wf={wf.name}] STARTUP FAILURE — cannot import "
                f"worker_class_path={wf.worker_class_path!r}: {exc}. "
                f"Either fix the dotted path or remove worker_class_path "
                f"and ensure {wf.name!r} is in dispatcher.WORKER_REGISTRY."
            )
            raise RuntimeError(
                f"[wf={wf.name}] cannot import worker_class_path="
                f"{wf.worker_class_path!r}: {exc}"
            ) from exc

        needs_starburst = wf.needs_starburst_clients
        if needs_starburst is None:
            needs_starburst = "Oracle" in class_name or "File" in class_name

        WORKER_REGISTRY[wf.name] = (worker_cls, needs_starburst)
        self.logger.info(
            f"[wf={wf.name}] registered worker={wf.worker_class_path} "
            f"needs_starburst={needs_starburst}"
        )

    # ── lifecycle ────────────────────────────────────────────────────

    async def start(self) -> None:
        """Spawn the single poll task.  Idempotent."""
        if self._started:
            self.logger.warning(
                "BackgroundService.start(): already started — ignoring repeat call"
            )
            return
        self._started = True
        self._ensure_stopped_event()

        if not self.runners:
            self.logger.warning(
                "BackgroundService.start(): no enabled runners — service idle"
            )
            return

        self._poll_task = asyncio.create_task(
            self._poll_loop(), name="bg_poll_loop",
        )
        self._poll_task.add_done_callback(self._on_poll_done)
        self.logger.info(
            f"BackgroundService started — single poll loop, "
            f"interval={self.config.interval_seconds}s, "
            f"runners={[r.workflow.name for r in self.runners]}"
        )

    def _on_poll_done(self, task: asyncio.Task) -> None:
        """AUDIT-2 equivalent — log the poll loop's death loudly.

        The poll loop is the heartbeat of the whole service.  If it
        dies unexpectedly, EVERY runner becomes a zombie holding empty
        slots while nothing reads Oracle.  Surface this immediately.
        """
        if task.cancelled():
            self.logger.info("Poll loop cancelled")
            return
        exc = task.exception()
        if exc is None:
            self.logger.info("Poll loop exited cleanly")
            return
        self.logger.error(
            f"Poll loop CRASHED unexpectedly — entire service is now blind; "
            f"NO new runs will be dispatched until the pod restarts.  "
            f"Last error: {exc!r}",
            exc_info=exc,
        )

    def stop(self) -> None:
        """Signal the poll loop + every runner to stop.  Idempotent."""
        if self.stopped:
            return
        self._ensure_stopped_event().set()

    async def shutdown(self) -> None:
        """Drain in-flight RUN_ID tasks across runners, then exit.

        Same drain semantics as the previous iteration (AUDIT-1):
          1. Drain in-flight tasks up to ``shutdown_timeout_seconds``.
          2. Cancel stragglers.
          3. Await the poll loop (exits fast once stop_event fires).
        """
        if self._shutdown_done:
            return
        self._shutdown_done = True

        timeout = max(0, int(self.config.shutdown_timeout_seconds))

        # Phase 1: drain in-flight RUN_ID tasks across every runner.
        in_flight: List[Tuple[str, int, asyncio.Task]] = []
        for runner in self.runners:
            for rid, t in list(runner.active_runs.items()):
                if not t.done():
                    in_flight.append((runner.workflow.name, rid, t))

        if not in_flight:
            self.logger.info(
                "BackgroundService.shutdown: no in-flight runs to drain"
            )
        else:
            self.logger.info(
                f"BackgroundService.shutdown: draining {len(in_flight)} "
                f"in-flight run(s) across {len(self.runners)} runner(s) "
                f"(timeout={timeout}s) — "
                f"{[f'{w}:{r}' for w, r, _ in in_flight]}"
            )
            try:
                await asyncio.wait_for(
                    asyncio.gather(*[t for _, _, t in in_flight],
                                   return_exceptions=True),
                    timeout=timeout if timeout > 0 else None,
                )
                self.logger.info(
                    "BackgroundService.shutdown: in-flight runs drained cleanly"
                )
            except asyncio.TimeoutError:
                stragglers = [(w, r, t) for w, r, t in in_flight if not t.done()]
                self.logger.warning(
                    f"BackgroundService.shutdown: drain timeout exceeded — "
                    f"cancelling {len(stragglers)} straggler run(s): "
                    f"{[f'{w}:{r}' for w, r, _ in stragglers]}"
                )
                for _, _, t in stragglers:
                    t.cancel()
                await asyncio.gather(
                    *[t for _, _, t in stragglers], return_exceptions=True
                )

        # Phase 2: await the poll loop.  Swallow any exception — it has
        # already been logged by _on_poll_done; re-raising would surface
        # the same error twice and bury the "shutdown clean" line.
        if self._poll_task is not None:
            try:
                await asyncio.wait_for(self._poll_task, timeout=5)
                self.logger.info(
                    "BackgroundService.shutdown: poll loop exited"
                )
            except asyncio.TimeoutError:
                self.logger.warning(
                    "BackgroundService.shutdown: poll loop did NOT exit "
                    "within 5s — cancelling"
                )
                self._poll_task.cancel()
                try:
                    await self._poll_task
                except (asyncio.CancelledError, Exception):
                    pass
            except Exception:
                # Done-callback already logged the crash; nothing else to do.
                pass

        self.logger.info("BackgroundService shut down")

    # ── poll loop ────────────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        """Single polling loop — drives every runner."""
        cfg = self.config
        stop_event = self._ensure_stopped_event()
        while not stop_event.is_set():
            if not self.paused:
                try:
                    await self._poll_once()
                except Exception as exc:
                    self.logger.error(
                        f"Poll cycle error: {exc}", exc_info=True
                    )
            try:
                await asyncio.wait_for(
                    asyncio.shield(stop_event.wait()),
                    timeout=max(1, int(cfg.interval_seconds)),
                )
            except asyncio.TimeoutError:
                pass
        self.logger.info(
            f"Poll loop stop signalled — active_runs_remaining="
            f"{sum(len(r.active_runs) for r in self.runners)}"
        )

    async def _poll_once(self) -> None:
        """One poll cycle: shared query → group by RUN_ID → route → dispatch."""
        cfg = self.config
        self.stats["polls"] += 1
        poll_num = self.stats["polls"]

        # Row limit sized to cover the union of runner caps so a hot
        # workflow doesn't starve its peers under SOD spikes.
        total_cap = max(1, sum(r.workflow.max_concurrent_runs for r in self.runners))
        row_limit = max(
            total_cap, total_cap * cfg.polling_query_limit_multiplier,
        )

        rows = await self.oracle_manager.get_all_start_tasks(
            cfg.etl_connection_string,
            cfg.bg_polling_sql,
            row_limit=row_limit,
        )
        if not rows:
            self.logger.debug(f"Poll cycle #{poll_num}: no START tasks")
            return

        # Group by RUN_ID — rows already sorted RUN_ID ASC, SEQ ASC.
        runs: Dict[int, list] = {}
        dropped_no_run_id = 0
        for row in rows:
            run_id = row.get("run_id")
            if run_id is None:
                dropped_no_run_id += 1
                continue
            runs.setdefault(run_id, []).append(row)

        if dropped_no_run_id:
            self.logger.warning(
                f"Poll cycle #{poll_num}: dropped {dropped_no_run_id} "
                f"row(s) with NULL run_id — check bg_polling_query"
            )

        self.logger.info(
            f"Poll cycle #{poll_num}: {len(rows)} task row(s) "
            f"across {len(runs)} run(s) (limit={row_limit})"
        )

        # Route + dispatch.  Tally outcomes for the cycle summary line.
        outcomes: Dict[str, int] = {}
        for run_id, tasks in runs.items():
            dag_type = _infer_dag_type(tasks[0])
            runner = self.find_runner(dag_type)
            if runner is None:
                self.stats["unrouted"] += 1
                outcomes["unrouted"] = outcomes.get("unrouted", 0) + 1
                self.logger.warning(
                    f"Poll cycle #{poll_num}: run_id={run_id} routed to "
                    f"dag_type={dag_type!r} but no enabled runner exists — "
                    f"row is left in STATUS=START.  Either enable the "
                    f"runner, or fix the OTG_DAG_ID prefix on the polling row."
                )
                continue
            outcome = await runner.try_dispatch(
                int(run_id), tasks,
                claimer_id_prefix=self._claimer_id,
                etl_connection_string=cfg.etl_connection_string,
            )
            outcomes[outcome] = outcomes.get(outcome, 0) + 1

        # Compact outcome summary — easier to scan than per-row INFOs.
        summary = ", ".join(f"{k}={v}" for k, v in sorted(outcomes.items()))
        if summary:
            self.logger.info(
                f"Poll cycle #{poll_num}: routing outcomes — {summary}"
            )

    # ── observability ────────────────────────────────────────────────

    def aggregate_stats(self) -> Dict[str, int]:
        """Service-level + per-runner counters merged into one dict."""
        agg = dict(self.stats)
        for runner in self.runners:
            for k, v in runner.stats.items():
                agg[k] = agg.get(k, 0) + int(v)
        return agg

    def total_active_runs(self) -> int:
        return sum(len(r.active_runs) for r in self.runners)

    def all_active_run_ids(self) -> List[int]:
        ids: List[int] = []
        for runner in self.runners:
            ids.extend(runner.active_runs.keys())
        return ids

    def workflow_snapshots(self) -> List[Dict]:
        return [r.snapshot() for r in self.runners]

    def find_runner(self, name: str) -> Optional[WorkflowRunner]:
        for r in self.runners:
            if r.workflow.name == name:
                return r
        return None

    # ── pause / resume ───────────────────────────────────────────────

    def pause_all(self) -> None:
        """Pause the global poll loop AND every runner.

        Two layers because:
          * Pausing the poll loop -> no Oracle hits, slot pipeline drains.
          * Pausing every runner -> if poll resumes (e.g. via single-runner
            resume) the per-runner pause still blocks dispatch.
        Calling `resume_all()` reverses both.
        """
        self.paused = True
        for r in self.runners:
            r.pause()

    def resume_all(self) -> None:
        self.paused = False
        for r in self.runners:
            r.resume()
