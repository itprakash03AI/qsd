"""
ETL Background Polling Service — asyncio entry point.

Starts two concurrent coroutines:
  1. BackgroundPoller.run()  — poll loop (Oracle discovery + dispatch)
  2. Uvicorn health API      — FastAPI on port 9000 (health/status/pause/resume)

Usage:
  python -m polling_service.main
  python -m polling_service.main --config /app/config/polling_service_config.yaml
  python -m polling_service.main --config /app/config/polling_service_config.yaml --port 9000
"""
import argparse
import asyncio
import logging
import os
import signal
import sys
from datetime import datetime
from typing import Optional

import uvicorn

# Add ETL root to sys.path so managers/workers/steps are importable
_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from polling_service.config import load_config
from polling_service.dispatcher import Dispatcher
from polling_service.health import app as health_app, init_health, init_health_service
from polling_service.poller import BackgroundPoller
from polling_service.service import BackgroundService
from managers.oracle_metadata_manager import OracleMetadataManager

LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def _build_logger(log_dir: str, log_level: str, worker_id: str) -> logging.Logger:
    """Configure root logger so ALL loggers in the process write to the same file.

    Logging hierarchy problem without this:
      - polling_service.health   → root (no handlers) → WARNING+ to stderr only
      - workers.oracle_worker    → root (no handlers) → WARNING+ to stderr only
      - managers.*               → root (no handlers) → WARNING+ to stderr only

    By configuring the ROOT logger here, every getLogger(__name__) call anywhere
    in the process automatically propagates to console + file — no handler wiring
    needed in each module.

    oracle_metadata_manager has its own _build_logger() that also adds a file
    handler (oraclemetadatamanager_*.log). Its messages will appear in both files,
    which is fine — the per-service log file is the primary ops tool.
    """
    level = getattr(logging, log_level, logging.INFO)

    try:
        os.makedirs(log_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(log_dir, f"bg_poller_{worker_id}_{ts}.log")
    except OSError as e:
        log_file = None
        logging.warning(f"Cannot create log dir {log_dir}: {e} — console only")

    fmt = logging.Formatter(LOG_FMT)

    # Configure root logger — every logger in the process inherits this
    root = logging.getLogger()
    root.setLevel(level)
    if not root.handlers:
        console = logging.StreamHandler(sys.stdout)
        console.setFormatter(fmt)
        root.addHandler(console)
        if log_file:
            try:
                fh = logging.FileHandler(log_file)
                fh.setFormatter(fmt)
                root.addHandler(fh)
            except OSError as e:
                logging.warning(f"Cannot open log file {log_file}: {e} — console only")

    # Silence noisy third-party loggers that propagate to root
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    # Return a named child logger for the polling service itself
    # (allows filtering by name; propagates to root so file handler applies)
    logger = logging.getLogger("bg_poller")
    logger.setLevel(level)
    return logger


async def _run_uvicorn(host: str, port: int) -> None:
    """Run uvicorn health API in the asyncio event loop."""
    config = uvicorn.Config(
        health_app,
        host=host,
        port=port,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(config)
    await server.serve()


async def main_async(config_path: str, health_host: str, health_port: int) -> None:
    """Async entry point — starts poller + health API concurrently."""
    cfg = load_config(config_path)
    logger = _build_logger(cfg.log_dir, cfg.log_level, cfg.worker_id)

    logger.info("=" * 60)
    logger.info("ETL Background Polling Service starting")
    logger.info(f"  worker_id        : {cfg.worker_id}")
    logger.info(f"  interval_seconds : {cfg.interval_seconds}")
    logger.info(f"  max_concurrent   : {cfg.max_concurrent_runs}")
    logger.info(f"  thread_pool      : {cfg.thread_pool_workers}")
    logger.info(f"  lightweight_mode : {cfg.use_lightweight_steps}")
    logger.info(f"  max_run_seconds  : {cfg.max_run_seconds}")
    logger.info(f"  shutdown_timeout : {cfg.shutdown_timeout_seconds}s")
    logger.info(f"  health_api       : http://{health_host}:{health_port}")
    logger.info("=" * 60)

    if not cfg.etl_connection_string:
        logger.error("ETL_ORACLE_CONN / etl_connection_string is not set — cannot start")
        sys.exit(1)

    # BF-595 (SERIOUS #3): wire ``thread_pool_workers`` into a dedicated
    # executor + set it as the event loop's default executor.  Every
    # ``asyncio.to_thread(...)`` and ``loop.run_in_executor(None, ...)``
    # call (e.g. OracleMetadataManager's blocking Oracle round-trips)
    # now routes through this bounded pool instead of the unbounded
    # anyio default (~40 threads).  Bounded + dedicated == predictable
    # CPU/IO behaviour under load.
    import concurrent.futures as _cf_bg
    import atexit as _atexit_bg
    _bg_executor = _cf_bg.ThreadPoolExecutor(
        max_workers=max(1, int(cfg.thread_pool_workers)),
        thread_name_prefix="bg-poller-io",
    )
    asyncio.get_running_loop().set_default_executor(_bg_executor)
    _atexit_bg.register(
        lambda: _bg_executor.shutdown(wait=False, cancel_futures=True)
    )
    logger.info(
        f"Default asyncio executor: ThreadPoolExecutor(max_workers="
        f"{cfg.thread_pool_workers}, name='bg-poller-io')"
    )

    oracle_manager = OracleMetadataManager(cfg.etl_connection_string)

    # 2026-06-12 — multi-workflow mode engages when the YAML declared
    # ``polling.workflows``.  Otherwise the legacy single-loop
    # BackgroundPoller path runs unchanged (BF-595 deploy preserved).
    multi_mode = bool(cfg.workflows)
    logger.info(
        "Service mode: %s",
        "multi-workflow (BackgroundService)" if multi_mode
        else "single-loop (BackgroundPoller, legacy)",
    )

    poller: Optional[BackgroundPoller] = None
    service: Optional[BackgroundService] = None

    if multi_mode:
        service = BackgroundService(
            config=cfg,
            oracle_manager=oracle_manager,
            logger=logger,
        )
        init_health_service(service, oracle_manager, cfg.etl_connection_string)
    else:
        # BF-595: pass the lightweight-mode flag through to the dispatcher.
        dispatcher = Dispatcher(
            logger=logger,
            use_lightweight_steps=cfg.use_lightweight_steps,
        )
        poller = BackgroundPoller(
            config=cfg,
            oracle_manager=oracle_manager,
            dispatcher=dispatcher,
            logger=logger,
        )
        init_health(poller, oracle_manager, cfg.etl_connection_string)

    # Graceful shutdown on SIGTERM / SIGINT
    loop = asyncio.get_running_loop()

    def _handle_signal(sig_name: str) -> None:
        logger.info(f"Received {sig_name} — initiating graceful shutdown")
        if service is not None:
            service.stop()
        if poller is not None:
            poller.stop()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, lambda s=sig.name: _handle_signal(s))
        except (NotImplementedError, OSError):
            # Windows does not support add_signal_handler for SIGTERM
            pass

    # Run the poller / service + health API concurrently.
    health_task = asyncio.create_task(
        _run_uvicorn(health_host, health_port), name="health_api"
    )

    try:
        if service is not None:
            await service.start()
            # Block on the service's stop event (set by the SIGTERM/SIGINT
            # handler via service.stop()), then run the drain.  No busy-poll.
            await service.wait_for_stop()
            await service.shutdown()
        else:
            assert poller is not None
            await poller.run()
    finally:
        health_task.cancel()
        try:
            await health_task
        except asyncio.CancelledError:
            pass

    logger.info("ETL Background Polling Service shut down cleanly")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="ETL Background Polling Service"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="",
        help="Path to polling_service_config.yaml. Defaults to CONFIG_PATH env var.",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Health API bind host (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("HEALTH_PORT", "9000")),
        help="Health API port (default: 9000, env: HEALTH_PORT)",
    )
    args = parser.parse_args()

    asyncio.run(main_async(
        config_path=args.config or "",
        health_host=args.host,
        health_port=args.port,
    ))


if __name__ == "__main__":
    main()
