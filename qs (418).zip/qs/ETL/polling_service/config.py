"""
Configuration loader for the ETL Background Polling Service.

Resolution order (highest wins):
  1. Environment variables (BG_POLL_INTERVAL, BG_MAX_CONCURRENT, etc.)
  2. polling_service_config.yaml
  3. Hard-coded defaults

2026-06-12 — multi-workflow mode:
  When ``polling.workflows`` is set in the YAML, the service runs
  one ``WorkflowRunner`` per entry (each with its own polling query,
  worker class, interval, concurrency cap).  When the key is absent
  the legacy single-loop ``BackgroundPoller`` path is used.  Both
  paths share the same OracleMetadataManager, thread pool, health
  API, cross-pod claim and graceful-shutdown machinery.
"""
import logging
import os
from dataclasses import dataclass, field
from typing import List, Optional

import yaml


@dataclass
class WorkflowConfig:
    """Per-workflow knobs for a single ``WorkflowRunner``.

    2026-06-12 (revised): single-query + Python routing.  The
    ``BackgroundService`` owns the ONE polling loop and routes rows
    to runners via ``_infer_dag_type``.  Each runner is a capacity
    gate + dispatcher, NOT a poll loop.  So polling-related per-workflow
    knobs (polling_query_key, polling_sql, interval_seconds,
    polling_query_limit_multiplier) are no longer here — they live at
    the service level on ``PollingServiceConfig``.

    Fields:
      name:                    Workflow id (matches dispatcher.WORKER_REGISTRY
                               key AND the step_mapping.yaml section name).
      enabled:                 If False, the runner is registered but never
                               started (operator can flip without code edits).
      worker_class_path:       Dotted import path to the worker class.
                               Empty == use dispatcher.WORKER_REGISTRY.
      max_concurrent_runs:     Per-workflow slot cap.  Each runner owns its
                               pool — a SAP backlog can't starve createJob.
      max_run_seconds:         Per-workflow run timeout.  0 inherits from
                               the service-level default.
      needs_starburst_clients: When True the dispatcher pre-builds
                               StarburstDataSource clients before invoking
                               the worker.  Empty == inferred from registry.

    NOT here on purpose (rationale):
      polling_query_key /      Single-query design: one bg_polling_query
      polling_sql              services every workflow.  Per-workflow queries
                               led to discriminator drift on createJob's
                               negative predicate list.
      interval_seconds         Single poll loop -> single cadence.  Per-runner
                               cadence has no meaning when one query feeds
                               every runner.  Runner throttling is implicit
                               via max_concurrent_runs (full slot pool ->
                               row stays in STATUS=START for next cycle).
      polling_query_limit_multiplier
                               Service-level — the row limit must cover the
                               UNION of every runner's demand, not one
                               workflow's.
      use_lightweight_steps    Image-level (BG_USE_LIGHTWEIGHT env var).
                               OG DB stays agnostic of lightweight typing.
    """
    name: str = ""
    enabled: bool = True
    worker_class_path: str = ""
    max_concurrent_runs: int = 3
    max_run_seconds: int = 0
    needs_starburst_clients: Optional[bool] = None


@dataclass
class PollingServiceConfig:
    # Polling behaviour
    interval_seconds: int = 30
    max_concurrent_runs: int = 5
    thread_pool_workers: int = 16
    worker_id: str = "bg_poller_1"

    # BF-595 (2026-05-30) — lightweight (no-Spark) mode.
    # When True, dispatcher routes createJob runs to step_mapping.yaml
    # `createJob_light` section which uses direct trino-python-client +
    # oracledb instead of PySpark.  Default True for the polling
    # service pod (workloads < 500K rows).  Set False to use the
    # legacy Spark path (requires Spark image + JARs + PVC mount).
    use_lightweight_steps: bool = True

    # BF-595 — per-run hard timeout (SERIOUS #4).  A run wedged longer
    # than this is cancelled and STATUS flipped to FAILED so the slot
    # frees up.  Default 2 hours.  Set 0 to disable.
    max_run_seconds: int = 7200

    # BF-595 — graceful-shutdown wait cap (SERIOUS #6).  On SIGTERM the
    # poller waits up to this many seconds for in-flight runs to drain
    # then cancels stragglers.  Default 60s, matches the K8s
    # terminationGracePeriodSeconds typical value.
    shutdown_timeout_seconds: int = 60

    # BF-595 — polling query LIMIT (SERIOUS #5).  Caps the number of
    # rows the bg_polling_query returns per cycle so a 1000-START-row
    # spike doesn't slow every poll to a crawl.  Computed at runtime
    # from max_concurrent_runs × this multiplier so the polling query
    # always returns enough rows to keep the slot pipeline full.
    polling_query_limit_multiplier: int = 20

    # Oracle connection strings
    etl_connection_string: str = ""
    dest_connection_string: str = ""

    # File paths (resolved at load time)
    queries_path: str = "config/etl_polling_task_query.yaml"
    step_mapping_path: str = "config/step_mapping.yaml"

    # Logging — defaults to the shared ``log_config.get_log_dir()``
    # resolution (ETL_LOG_DIR env > polling YAML > legacy PVC path).
    # Use ``dataclasses.field(default_factory=...)`` so the call
    # happens at instance-construction time, not at class-definition
    # time (avoids freezing the cache before env vars are set).
    log_dir: str = ""
    log_level: str = "INFO"

    # Loaded SQL (not from YAML directly — loaded by config loader)
    bg_polling_sql: str = ""

    # 2026-06-12 — multi-workflow mode.  When non-empty, ``main.py``
    # spawns one ``WorkflowRunner`` per entry inside a single
    # ``BackgroundService`` orchestrator.  When empty, the legacy
    # single-loop ``BackgroundPoller`` is used (back-compat with
    # existing BF-595 deployment).  Use ``default_factory`` to keep
    # the default safely mutable-per-instance.
    workflows: List[WorkflowConfig] = field(default_factory=list)


def load_config(config_path: Optional[str] = None) -> PollingServiceConfig:
    """Load config from YAML file + environment variable overrides.

    Args:
        config_path: Path to polling_service_config.yaml.
                     Falls back to CONFIG_PATH env var, then
                     <ETL_DIR>/config/polling_service_config.yaml.
    """
    cfg = PollingServiceConfig()

    # Resolve config file path
    if not config_path:
        config_path = os.environ.get(
            "CONFIG_PATH",
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "config",
                "polling_service_config.yaml",
            ),
        )

    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

        polling = raw.get("polling", {})
        oracle = raw.get("oracle", {})
        logging_cfg = raw.get("logging", {})

        cfg.interval_seconds = int(polling.get("interval_seconds", cfg.interval_seconds))
        cfg.max_concurrent_runs = int(polling.get("max_concurrent_runs", cfg.max_concurrent_runs))
        cfg.thread_pool_workers = int(polling.get("thread_pool_workers", cfg.thread_pool_workers))
        cfg.worker_id = str(polling.get("worker_id", cfg.worker_id))
        # BF-595
        cfg.use_lightweight_steps = bool(
            polling.get("use_lightweight_steps", cfg.use_lightweight_steps)
        )
        cfg.max_run_seconds = int(polling.get("max_run_seconds", cfg.max_run_seconds))
        cfg.shutdown_timeout_seconds = int(
            polling.get("shutdown_timeout_seconds", cfg.shutdown_timeout_seconds)
        )
        cfg.polling_query_limit_multiplier = int(
            polling.get(
                "polling_query_limit_multiplier",
                cfg.polling_query_limit_multiplier,
            )
        )

        cfg.etl_connection_string = str(oracle.get("etl_connection_string", cfg.etl_connection_string))
        cfg.dest_connection_string = str(oracle.get("dest_connection_string", cfg.dest_connection_string))
        cfg.queries_path = str(oracle.get("queries_path", cfg.queries_path))
        cfg.step_mapping_path = str(oracle.get("step_mapping_path", cfg.step_mapping_path))

        cfg.log_dir = str(logging_cfg.get("dir", cfg.log_dir))
        cfg.log_level = str(logging_cfg.get("level", cfg.log_level)).upper()

        # 2026-06-12 — per-workflow runners.  Operators can list zero
        # or more workflows; absent / empty key means legacy single-loop
        # path engages (existing BF-595 behaviour preserved).
        #
        # Polling-related knobs (query key, interval, row-limit multiplier)
        # are SERVICE-LEVEL on PollingServiceConfig — one polling loop
        # services every workflow.
        for raw_wf in polling.get("workflows", []) or []:
            wf = WorkflowConfig(
                name=str(raw_wf.get("name", "")).strip(),
                enabled=bool(raw_wf.get("enabled", True)),
                worker_class_path=str(raw_wf.get("worker_class_path", "")).strip(),
                max_concurrent_runs=int(raw_wf.get("max_concurrent_runs", 3)),
                max_run_seconds=int(raw_wf.get("max_run_seconds", 0)),
            )
            if "needs_starburst_clients" in raw_wf and raw_wf["needs_starburst_clients"] is not None:
                wf.needs_starburst_clients = bool(raw_wf["needs_starburst_clients"])
            if not wf.name:
                logging.warning("polling.workflows entry missing 'name' — skipping")
                continue
            cfg.workflows.append(wf)
    else:
        logging.warning(f"Config file not found: {config_path} — using defaults + env vars")

    # Environment variable overrides (highest priority)
    cfg.interval_seconds = int(os.environ.get("BG_POLL_INTERVAL", cfg.interval_seconds))
    cfg.max_concurrent_runs = int(os.environ.get("BG_MAX_CONCURRENT", cfg.max_concurrent_runs))
    cfg.thread_pool_workers = int(os.environ.get("BG_THREAD_WORKERS", cfg.thread_pool_workers))
    cfg.worker_id = os.environ.get("BG_WORKER_ID", cfg.worker_id)
    cfg.etl_connection_string = os.environ.get("ETL_ORACLE_CONN", cfg.etl_connection_string)
    cfg.dest_connection_string = os.environ.get("DEST_ORACLE_CONN", cfg.dest_connection_string)

    # 2026-06-22 -- vault layer.  Fires when yaml literal AND env var
    # are blank.  Resolves via oracle_config_loader.resolve_*_connection_string
    # which honours oracle.etl.secret_ref / oracle.destination.secret_ref.
    if not cfg.etl_connection_string or not cfg.dest_connection_string:
        try:
            from oracle_config_loader import (
                resolve_etl_connection_string,
                resolve_dest_connection_string,
            )
            # Build a shim that matches the loader's expected shape.
            shim = {"oracle": {
                "etl_connection_string":  cfg.etl_connection_string,
                "dest_connection_string": cfg.dest_connection_string,
                # Loader re-reads its own yaml for etl.secret_ref /
                # destination.secret_ref -- shim is for the literal
                # fields above.
            }}
            if not cfg.etl_connection_string:
                cfg.etl_connection_string = resolve_etl_connection_string(shim)
            if not cfg.dest_connection_string:
                cfg.dest_connection_string = resolve_dest_connection_string(shim)
        except ImportError:
            pass
    # BF-595 env overrides
    if "BG_USE_LIGHTWEIGHT" in os.environ:
        cfg.use_lightweight_steps = os.environ["BG_USE_LIGHTWEIGHT"].lower() in ("1", "true", "yes", "on")
    cfg.max_run_seconds = int(os.environ.get("BG_MAX_RUN_SECONDS", cfg.max_run_seconds))
    cfg.shutdown_timeout_seconds = int(os.environ.get("BG_SHUTDOWN_TIMEOUT", cfg.shutdown_timeout_seconds))
    cfg.polling_query_limit_multiplier = int(
        os.environ.get("BG_POLL_LIMIT_MULT", cfg.polling_query_limit_multiplier)
    )

    # Resolve log_dir last via the shared resolver so ETL_LOG_DIR env
    # var wins over polling YAML, and polling YAML wins over the
    # legacy hardcoded PVC path.  Only call the shared resolver when
    # the YAML+env didn't already provide a value (preserves explicit
    # operator intent).
    if not cfg.log_dir:
        try:
            etl_root_for_logs = os.path.dirname(
                os.path.dirname(os.path.abspath(__file__))
            )
            if etl_root_for_logs not in os.sys.path:
                os.sys.path.insert(0, etl_root_for_logs)
            from log_config import get_log_dir as _shared_log_dir
            cfg.log_dir = _shared_log_dir()
        except Exception:
            cfg.log_dir = "/usr/local/spark/nfs/bcp/batch/logs"

    # Resolve paths relative to ETL root if not absolute
    etl_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if not os.path.isabs(cfg.queries_path):
        cfg.queries_path = os.path.join(etl_root, cfg.queries_path)
    if not os.path.isabs(cfg.step_mapping_path):
        cfg.step_mapping_path = os.path.join(etl_root, cfg.step_mapping_path)

    # Single polling SQL — bg_polling_query serves every workflow.
    # The BackgroundService routes each row to the right WorkflowRunner
    # via ``polling_service.poller._infer_dag_type`` (the canonical
    # OTG_DAG_ID -> workflow mapping).
    queries = _load_queries_yaml(cfg.queries_path)
    if "bg_polling_query" not in queries:
        raise ValueError(
            f"'bg_polling_query' not found in {cfg.queries_path}. "
            "Add the query to etl_polling_task_query.yaml."
        )
    cfg.bg_polling_sql = str(queries["bg_polling_query"]).strip()

    for wf in cfg.workflows:
        # Inherit service-level max_run_seconds when the workflow didn't set one.
        if wf.max_run_seconds <= 0:
            wf.max_run_seconds = cfg.max_run_seconds

    return cfg


def _load_queries_yaml(queries_path: str) -> dict:
    """Load the etl_polling_task_query.yaml file as a dict.

    Forces UTF-8 because the YAML file contains box-drawing comment
    headers (``══`` separators) that crash the Windows default cp1252
    codec.
    """
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")
    with open(queries_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}
