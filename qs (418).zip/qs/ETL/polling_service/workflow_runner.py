"""
WorkflowRunner — per-workflow capacity gate + dispatcher.

2026-06-12 (revised) — single-query + Python routing design.

Each ``WorkflowRunner`` owns:
  - The workflow's concurrency cap, stats, active_runs dict, pause flag.
  - The cross-pod DBMS_LOCK claim before each dispatch.
  - The per-run timeout + STATUS-flip-on-timeout semantics.

What the runner does NOT own (vs the previous per-runner-polling design):
  - It has NO polling query.
  - It has NO poll loop.
  - It has NO interval.

The ``BackgroundService`` owns ONE polling loop, polls the single
shared ``bg_polling_query`` once per cycle, infers each row's dag_type
via ``polling_service.poller._infer_dag_type`` (the canonical mapping)
and calls ``runner.try_dispatch(run_id, tasks, claimer_id, etl_conn_str)``.

Why single-query routing:
  * One mapping place — no more N polling queries duplicating the
    OTG_DAG_ID→workflow logic (was leaking into etl_polling_task_query.yaml
    `bg_polling_query_<wf>` discriminators).
  * No discriminator drift — adding a new workflow no longer requires
    editing createJob's `NOT LIKE` exclusion list.
  * One Oracle round-trip per service tick — not N.
  * Per-workflow concurrency caps + stats preserved (each runner owns
    its slot pool — a SAP backlog still can't starve createJob).
"""
from __future__ import annotations

import asyncio
import logging
import socket
from typing import TYPE_CHECKING, Any, Dict

if TYPE_CHECKING:
    from polling_service.config import WorkflowConfig
    from polling_service.dispatcher import Dispatcher
    from managers.oracle_metadata_manager import OracleMetadataManager


class WorkflowRunner:
    """Per-workflow capacity gate + dispatcher.

    Lifecycle is purely reactive — the BackgroundService drives it via
    ``try_dispatch``.  No background asyncio.Task for the runner itself;
    only the ``_execute_run`` Tasks for each in-flight RUN_ID.
    """

    def __init__(
        self,
        workflow: "WorkflowConfig",
        etl_connection_string: str,
        dest_connection_string: str,
        oracle_manager: "OracleMetadataManager",
        dispatcher: "Dispatcher",
        logger: logging.Logger,
    ) -> None:
        self.workflow = workflow
        self.etl_connection_string = etl_connection_string
        self.dest_connection_string = dest_connection_string
        self.oracle_manager = oracle_manager
        self.dispatcher = dispatcher
        # Child logger tagged with the workflow name so multi-runner
        # log lines are filterable: ``[wf=sap_odata] ...``.
        self.logger = logger.getChild(f"wf.{workflow.name}")

        self.active_runs: Dict[int, asyncio.Task] = {}
        self.paused = False
        self.stats: Dict[str, int] = {
            "dispatched": 0,
            "completed": 0,
            "failed": 0,
            "skipped_cross_pod": 0,
            "timed_out": 0,
            "skipped_at_capacity": 0,
        }
        try:
            import os as _os
            self._claimer_id_suffix = f":{workflow.name}:{_os.getpid()}"
        except Exception:
            self._claimer_id_suffix = f":{workflow.name}"

    # ── operator control ─────────────────────────────────────────────

    def pause(self) -> None:
        self.paused = True
        self.logger.info(f"[wf={self.workflow.name}] paused")

    def resume(self) -> None:
        self.paused = False
        self.logger.info(f"[wf={self.workflow.name}] resumed")

    # ── cross-thread Starburst cancellation ──────────────────────────

    def _cancel_starburst_for_tasks(self, tasks: list) -> None:
        """Fire ``cancel_all_starburst`` on each task in the run.

        Called from the TimeoutError + CancelledError branches of
        ``_execute_run`` so the Starburst coordinator is told to stop
        the query at the same moment we give up locally.  Safe to call
        even when no step has registered a cancellable yet (e.g. a
        non-Starburst step in the workflow) — empty registry is a
        no-op inside ``cancel_all_starburst``.
        """
        try:
            from starburst_cancellation import cancel_all_starburst
        except Exception as exc:
            self.logger.warning(
                "[wf=%s] starburst_cancellation unavailable (%s) — "
                "in-flight Starburst queries will continue on the server",
                self.workflow.name, exc,
            )
            return
        for task in tasks or ():
            try:
                cancel_all_starburst(task, logger=self.logger)
            except Exception as exc:
                self.logger.warning(
                    "[wf=%s] cancel_all_starburst raised: %s",
                    self.workflow.name, exc,
                )

    # ── snapshot for /status endpoint ────────────────────────────────

    def snapshot(self) -> Dict[str, Any]:
        wf = self.workflow
        return {
            "name": wf.name,
            "enabled": wf.enabled,
            "paused": self.paused,
            "active_runs": len(self.active_runs),
            "active_run_ids": list(self.active_runs.keys()),
            "max_concurrent_runs": wf.max_concurrent_runs,
            "stats": dict(self.stats),
        }

    # ── public dispatch entry point ──────────────────────────────────

    async def try_dispatch(
        self,
        run_id: int,
        tasks: list,
        claimer_id_prefix: str,
        etl_connection_string: str,
    ) -> str:
        """Attempt to dispatch one RUN_ID.

        Returns a status string for the BackgroundService's poll-cycle
        log line:
          ``"dispatched"`` — new asyncio.Task created
          ``"already_active"`` — already running in this pod
          ``"paused"`` — runner is paused
          ``"at_capacity"`` — runner slot pool full
          ``"cross_pod"`` — another pod already claimed it

        Cross-pod claim semantics + per-run timeout + finally-cleanup
        match BackgroundPoller 1:1 (BF-595 contract preserved).
        """
        wf = self.workflow

        if run_id in self.active_runs:
            return "already_active"
        if self.paused:
            return "paused"
        if len(self.active_runs) >= wf.max_concurrent_runs:
            self.stats["skipped_at_capacity"] += 1
            return "at_capacity"

        claimer_id = f"{claimer_id_prefix}{self._claimer_id_suffix}"
        try:
            claimed = await self.oracle_manager.try_claim_run(
                int(run_id), claimer_id, etl_connection_string,
            )
        except Exception as claim_exc:
            self.logger.warning(
                f"[wf={wf.name}] run_id={run_id} try_claim_run raised "
                f"{claim_exc!r} — proceeding without claim"
            )
            claimed = True
        if not claimed:
            self.stats["skipped_cross_pod"] += 1
            self.logger.info(
                f"[wf={wf.name}] run_id={run_id} claimed by another pod"
            )
            return "cross_pod"

        self.stats["dispatched"] += 1
        self.logger.info(
            f"[wf={wf.name}] dispatching run_id={run_id} steps={len(tasks)} "
            f"({len(self.active_runs) + 1}/{wf.max_concurrent_runs} slots)"
        )
        task = asyncio.create_task(
            self._execute_run(int(run_id), tasks),
            name=f"wf_{wf.name}_run_{run_id}",
        )
        self.active_runs[int(run_id)] = task
        return "dispatched"

    # ── per-run execution ────────────────────────────────────────────

    async def _execute_run(self, run_id: int, tasks: list) -> None:
        """Execute one RUN_ID via the shared dispatcher, with per-run timeout.

        Mirrors the original implementation — same Cancel / Timeout /
        Exception handling, same STATUS-flip on timeout, same finally
        cleanup.  AUDIT-3 CancelledError log line retained.
        """
        wf = self.workflow
        max_secs = int(wf.max_run_seconds)
        try:
            coro = self.dispatcher.execute(
                run_id,
                tasks,
                wf.name,  # dag_type for WORKER_REGISTRY lookup
                self.etl_connection_string,
                self.dest_connection_string,
            )
            if max_secs > 0:
                await asyncio.wait_for(coro, timeout=max_secs)
            else:
                await coro
            self.stats["completed"] += 1
            self.logger.info(
                f"[wf={wf.name}] run_id={run_id} completed successfully"
            )
        except asyncio.TimeoutError:
            self.stats["timed_out"] += 1
            self.logger.error(
                f"[wf={wf.name}] run_id={run_id} TIMED OUT after {max_secs}s — "
                f"cancelling and flipping STATUS=FAILED"
            )
            # 2026-06-12 — propagate cancel to Starburst BEFORE we move
            # on.  Without this the query keeps running server-side
            # after we've given up, holding coordinator slots.
            self._cancel_starburst_for_tasks(tasks)
            first_task = tasks[0] if tasks else {}
            try:
                await self.oracle_manager.update_otg_etl_batch_status(
                    int(run_id),
                    int(first_task.get("run_detail_id", 0)),
                    "FAILED",
                    str(first_task.get("task_steps", "TIMEOUT")),
                    0,
                    f"workflow={wf.name} timeout: run exceeded {max_secs}s",
                    self.etl_connection_string,
                )
            except Exception as flip_exc:
                self.logger.warning(
                    f"[wf={wf.name}] run_id={run_id}: status-flip-to-FAILED "
                    f"after timeout raised {flip_exc!r}"
                )
        except asyncio.CancelledError:
            self.logger.warning(
                f"[wf={wf.name}] run_id={run_id} CANCELLED (external) — "
                f"run is left in STATUS=INPROGRESS; the next pod cycle will "
                f"NOT pick it up unless ops resets STATUS=START or the "
                f"BF-595 cross-pod claim TTL releases on session end."
            )
            # Same Starburst cancel on external cancel (shutdown drain).
            self._cancel_starburst_for_tasks(tasks)
            raise
        except Exception as exc:
            self.stats["failed"] += 1
            self.logger.error(
                f"[wf={wf.name}] run_id={run_id} failed: {exc}", exc_info=True
            )
        finally:
            self.active_runs.pop(int(run_id), None)
