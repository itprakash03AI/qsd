"""Shared date helpers for ETL standalone scripts.

The polling queries used by the standalones bind ``:2`` as
``TO_DATE(:2, 'DD-MM-YYYY')`` (file workflow) or ``TO_DATE(:2, 'DD-MM-YY')``
(SAP / sb_to_oracle / s3_query workflows).  The Python side received
this value as a CLI arg or from an Airflow Variable, and the input
format varies in practice:

  * Airflow Variables today carry ``"14-07-2025"`` (DD-MM-YYYY)
  * Ad-hoc invocations often use ``"2025-07-14"`` (ISO)
  * Some operators paste ``"14/07/2025"`` or ``"14-Jul-2025"``

Until 2026-06-12 the file standalones rejected anything that wasn't
the exact ``\\d{2}-\\d{2}-\\d{4}`` regex, producing:

    --business_date '2025-07-14' does not match dd-MM-yyyy

This module accepts the common forms and normalises to a target
format the polling SQL expects.
"""
from __future__ import annotations

from datetime import datetime
from typing import Tuple

# Order matters — we try these in sequence and pick the first match.
# DD-MM ordering is tried BEFORE month-DD ordering because most of the
# OTG operator inputs use day-first (Indian / European convention).
_ACCEPTED_INPUT_FORMATS: Tuple[str, ...] = (
    "%d-%m-%Y",      # 14-07-2025  (legacy strict format)
    "%d-%m-%y",      # 14-07-25
    "%d/%m/%Y",      # 14/07/2025
    "%d/%m/%y",      # 14/07/25
    "%Y-%m-%d",      # 2025-07-14  (ISO 8601)
    "%Y/%m/%d",      # 2025/07/14
    "%d-%b-%Y",      # 14-Jul-2025
    "%d-%b-%y",      # 14-Jul-25
    "%d %b %Y",      # 14 Jul 2025
    "%d-%B-%Y",      # 14-July-2025
)


def normalize_business_date(value: str, target_format: str = "%d-%m-%Y") -> str:
    """Parse ``value`` with any accepted input format and return it
    formatted as ``target_format`` (default ``DD-MM-YYYY``, the format
    ``polling_query_sb_to_file`` binds via ``TO_DATE(:2, 'DD-MM-YYYY')``).

    Raises ``ValueError`` with a clear message + examples on no match.
    """
    if value is None:
        raise ValueError("business_date is required")
    cleaned = str(value).strip()
    if not cleaned:
        raise ValueError("business_date is empty")
    for fmt in _ACCEPTED_INPUT_FORMATS:
        try:
            return datetime.strptime(cleaned, fmt).strftime(target_format)
        except ValueError:
            continue
    raise ValueError(
        f"business_date {value!r} does not match any accepted format. "
        f"Accepted: {list(_ACCEPTED_INPUT_FORMATS)}. "
        f"Examples: '14-07-2025', '2025-07-14', '14/07/2025', '14-Jul-2025'."
    )
