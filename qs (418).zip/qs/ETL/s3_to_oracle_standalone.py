"""DB-polling entry point for the s3_to_oracle pipeline.

2026-06-22 -- thin shim around ``s3_standalone_runner.run_pipeline``.
Reads S3 (parquet OR iceberg) via Spark, writes DataFrame directly to
Oracle via JDBC.  No file artefacts.

CLI contract:

    spark-submit ... s3_to_oracle_standalone.py \\
        --report_id 42 --business_date 02-06-26 \\
        --dag_id S3_TO_ORACLE_RUNNER \\
        --config_path /usr/local/spark/pvc/code/configs/oracle_config.yaml

Step mapping: ``configs/step_mapping.yaml -> s3_to_oracle:`` section.
Polling query: ``polling_query_s3_to_oracle`` in
``configs/etl_polling_task_query.yaml``.
"""
from __future__ import annotations

# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="s3_to_oracle",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    pass
# === END PREFLIGHT BOOTSTRAP ===

import asyncio
import os
import sys
from pathlib import Path
from typing import List

_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",
    "/usr/local/spark/pvc/code/etl",
    "/usr/local/spark/pvc",
    str(Path(__file__).resolve().parent),
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


from s3_standalone_runner import run_pipeline
from workers.s3_worker import S3ToOracleWorker


if __name__ == "__main__":
    asyncio.run(run_pipeline(
        workflow="s3_to_oracle",
        worker_class=S3ToOracleWorker,
        log_prefix="s3_to_oracle",
        polling_query_key="polling_query_s3_to_oracle",
        description=(
            "Execute an s3_to_oracle task for a specific report ID + business date.  "
            "Reads S3 (parquet/iceberg) via Spark, writes DataFrame to Oracle via JDBC."
        ),
        logger_name="s3_to_oracle_standalone",
    ))
