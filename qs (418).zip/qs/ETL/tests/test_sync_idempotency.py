"""Cron-window idempotency — auto-derive suppression from cron expression."""
from datetime import date, datetime, timedelta, timezone

import pytest

from ETL.sync.idempotency import (
    InMemoryIdempotencyStore, cron_to_window,
)
from ETL.sync.models import DiscrepancyKey, DispatchMode, SyncAction


# ── cron_to_window ────────────────────────────────────────────────────


def test_cron_to_window_hourly():
    """Every hour → ~1 hour window."""
    w = cron_to_window("0 * * * *")
    assert timedelta(minutes=50) < w <= timedelta(hours=1)


def test_cron_to_window_every_4_hours():
    """0 */4 * * * → ~4 hour window."""
    w = cron_to_window("0 */4 * * *")
    assert timedelta(hours=3, minutes=50) < w <= timedelta(hours=4)


def test_cron_to_window_daily():
    """0 0 * * * → ~24 hour window."""
    w = cron_to_window("0 0 * * *")
    assert timedelta(hours=23) < w <= timedelta(hours=24)


def test_cron_to_window_invalid_falls_back():
    """Unparseable cron → 4h default, not crash."""
    w = cron_to_window("not a cron")
    assert w == timedelta(hours=4)


def test_cron_to_window_empty_falls_back():
    """Empty → 4h default."""
    assert cron_to_window("") == timedelta(hours=4)
    assert cron_to_window("   ") == timedelta(hours=4)


def test_cron_to_window_never_zero():
    """Minimum window is 1 minute (defensive against edge cases)."""
    # Should never return 0 even if cron parser thinks "now == prev_fire"
    w = cron_to_window("* * * * *")
    assert w >= timedelta(minutes=1)


# ── InMemoryIdempotencyStore ─────────────────────────────────────────


def _action(key="sync:fact_x:abc123"):
    return SyncAction(
        logical_name="fact_x",
        key=DiscrepancyKey(
            code="A", business_close_date=date(2026, 1, 1), business_event="OPEN",
        ),
        estimated_rows=100,
        dispatch_mode=DispatchMode.POLLING,
        proc_name="P",
        proc_params={},
        idempotency_key=key,
    )


def test_record_then_already_dispatched_within_window():
    store = InMemoryIdempotencyStore()
    store.set_cron_for_triple("fact_x", "0 */4 * * *")
    a = _action()
    assert store.already_dispatched(a.idempotency_key) is False
    store.record_dispatch(a, "ok")
    # Within the 4h window → suppressed
    assert store.already_dispatched(a.idempotency_key) is True


def test_failed_status_clears_suppression():
    """Mirrors G9 fix: failed remediations must be retried on next cycle."""
    store = InMemoryIdempotencyStore()
    store.set_cron_for_triple("fact_x", "0 */4 * * *")
    a = _action()
    store.record_dispatch(a, "ok")
    assert store.already_dispatched(a.idempotency_key) is True
    store.mark_status(a.idempotency_key, "failed")
    assert store.already_dispatched(a.idempotency_key) is False


def test_unknown_triple_uses_default_window():
    """If the idempotency key's logical_name has no registered cron,
    fall back to the 4h default — never crash."""
    store = InMemoryIdempotencyStore()
    # NOT calling set_cron_for_triple
    a = _action()
    store.record_dispatch(a, "ok")
    assert store.already_dispatched(a.idempotency_key) is True


def test_idempotency_key_without_colon_falls_back_gracefully():
    """Defensive: a key that doesn't follow the sync:<name>:<hash>
    shape shouldn't crash the suppression lookup."""
    store = InMemoryIdempotencyStore()
    a = _action(key="some-other-shape")
    store.record_dispatch(a, "ok")
    # Doesn't crash, just uses fallback window
    assert store.already_dispatched("some-other-shape") is True
