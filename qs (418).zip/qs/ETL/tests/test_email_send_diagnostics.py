"""2026-06-22 bug #17: emails appeared "sent" in logs but never arrived
in operator's inbox.

Root cause: send_message() returns silently if SMTP relay accepts the
message, but acceptance is NOT delivery.  Pre-fix code threw away the
return value of send_message() so partial refusals + post-acceptance
drops vanished without trace.

These tests lock the new diagnostics:
  1. Message-ID header is set on every email (greppable in mail logs)
  2. PRE-SEND log line emits BEFORE smtplib invoked (audit trail)
  3. SMTP NOOP + EHLO responses logged (proves which relay we hit)
  4. send_message() return value inspected for partial refusals
  5. Specific exception types get specific actionable error messages
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


@pytest.fixture
def rr(tmp_path):
    from steps.file.run_report import FileRunReport
    rr = FileRunReport(output_dir=str(tmp_path))
    rr.mark_started()
    rr.context.update({
        "report_id": "1001",
        "business_date": "20250831",
        "run_id": "12345",
    })
    rr.mark_success()
    return rr


@pytest.fixture
def email_cfg():
    return {
        "send_email": "true",
        "smtp_host": "smtp.corp.local",
        "smtp_port": 25,
        "email_from": "etl@corp.local",
        "email_to": "ops@corp.local",
    }


def _smtp_mock(refused=None):
    """Build a mock smtplib.SMTP that mimics a real relay.

    refused: dict of {recipient: (code, reason)} for partial refusals,
             or None for accept-all.
    """
    m = MagicMock()
    m.docmd.return_value = (250, b"OK")
    m.ehlo.return_value = (250, b"smtp.corp.local Hello\nSIZE 52428800\nSTARTTLS")
    m.send_message.return_value = refused or {}
    # Context-manager support: __enter__ / __exit__
    cm = MagicMock()
    cm.__enter__.return_value = m
    cm.__exit__.return_value = None
    return cm, m


class TestMessageIdHeader:
    """Every email MUST carry a Message-ID so operators can grep
    mail-relay logs by it when emails go missing."""

    def test_message_id_set(self, rr, email_cfg):
        cm, mock_smtp = _smtp_mock()
        with patch("smtplib.SMTP", return_value=cm):
            ok = rr.send_email(email_cfg)
        assert ok is True
        sent_msg = mock_smtp.send_message.call_args[0][0]
        assert sent_msg["Message-ID"] is not None
        assert "qs-etl" in sent_msg["Message-ID"]

    def test_date_header_set(self, rr, email_cfg):
        cm, mock_smtp = _smtp_mock()
        with patch("smtplib.SMTP", return_value=cm):
            rr.send_email(email_cfg)
        sent_msg = mock_smtp.send_message.call_args[0][0]
        assert sent_msg["Date"] is not None


class TestPreSendLogging:
    """Operators must see what we're about to send BEFORE smtplib is
    invoked, in case the call hangs or silently drops."""

    def test_pre_send_logs_all_critical_fields(self, rr, email_cfg, caplog):
        import logging as _lg
        caplog.set_level(_lg.INFO)
        # FileRunReport.logger needs a real logger that caplog can capture
        rr.logger = _lg.getLogger("test_email_diag")
        rr.logger.setLevel(_lg.INFO)

        cm, _ = _smtp_mock()
        with patch("smtplib.SMTP", return_value=cm):
            rr.send_email(email_cfg)

        msgs = " ".join(r.message for r in caplog.records)
        assert "Email PRE-SEND" in msgs
        assert "smtp.corp.local" in msgs
        assert "etl@corp.local" in msgs
        assert "ops@corp.local" in msgs
        assert "msg_id=" in msgs
        assert "html_bytes=" in msgs

    def test_smtp_noop_and_ehlo_logged(self, rr, email_cfg, caplog):
        import logging as _lg
        caplog.set_level(_lg.INFO)
        rr.logger = _lg.getLogger("test_email_diag2")
        rr.logger.setLevel(_lg.INFO)

        cm, _ = _smtp_mock()
        with patch("smtplib.SMTP", return_value=cm):
            rr.send_email(email_cfg)

        msgs = " ".join(r.message for r in caplog.records)
        assert "SMTP NOOP" in msgs
        assert "SMTP EHLO" in msgs


class TestPartialRefusal:
    """send_message() returns dict of refused recipients.  Previously
    this was discarded -- partial failures went silent."""

    def test_partial_refusal_logged_as_error(self, rr, email_cfg, caplog):
        import logging as _lg
        caplog.set_level(_lg.ERROR)
        rr.logger = _lg.getLogger("test_email_partial")
        rr.logger.setLevel(_lg.ERROR)
        email_cfg["email_to"] = "ops@corp.local,baduser@corp.local"

        # Mock: ops@ accepted, baduser@ refused
        cm, _ = _smtp_mock(refused={
            "baduser@corp.local": (550, b"User unknown"),
        })
        with patch("smtplib.SMTP", return_value=cm):
            ok = rr.send_email(email_cfg)

        # Return True since SOME went out
        assert ok is True
        msgs = " ".join(r.message for r in caplog.records)
        assert "SMTP refused" in msgs
        assert "baduser@corp.local" in msgs
        assert "550" in msgs or "User unknown" in msgs


class TestSpecificExceptionMessages:
    """Each SMTP exception type gets a specific actionable error msg."""

    def test_recipients_refused_error_message(self, rr, email_cfg, caplog):
        import smtplib
        import logging as _lg
        caplog.set_level(_lg.ERROR)
        rr.logger = _lg.getLogger("test_email_refused")
        rr.logger.setLevel(_lg.ERROR)

        cm, mock_smtp = _smtp_mock()
        mock_smtp.send_message.side_effect = smtplib.SMTPRecipientsRefused(
            {"ops@corp.local": (550, b"User unknown")}
        )
        with patch("smtplib.SMTP", return_value=cm):
            ok = rr.send_email(email_cfg)

        assert ok is False
        msgs = " ".join(r.message for r in caplog.records)
        assert "DMARC" in msgs or "blocklisted" in msgs or "invalid email_to" in msgs

    def test_auth_failure_error_message(self, rr, email_cfg, caplog):
        import smtplib
        import logging as _lg
        caplog.set_level(_lg.ERROR)
        rr.logger = _lg.getLogger("test_email_auth")
        rr.logger.setLevel(_lg.ERROR)
        email_cfg["smtp_user"] = "etl"
        email_cfg["smtp_password"] = "bad"

        cm, mock_smtp = _smtp_mock()
        mock_smtp.login.side_effect = smtplib.SMTPAuthenticationError(
            535, b"Authentication failed",
        )
        with patch("smtplib.SMTP", return_value=cm):
            ok = rr.send_email(email_cfg)

        assert ok is False
        msgs = " ".join(r.message for r in caplog.records)
        assert "SMTP AUTH" in msgs
        assert "STARTTLS" in msgs or "smtp_password" in msgs

    def test_connection_failure_error_message(self, rr, email_cfg, caplog):
        import smtplib
        import logging as _lg
        caplog.set_level(_lg.ERROR)
        rr.logger = _lg.getLogger("test_email_conn")
        rr.logger.setLevel(_lg.ERROR)

        with patch("smtplib.SMTP", side_effect=smtplib.SMTPConnectError(
            421, b"Connection refused",
        )):
            ok = rr.send_email(email_cfg)

        assert ok is False
        msgs = " ".join(r.message for r in caplog.records)
        assert "SMTP connect" in msgs
        assert "587" in msgs or "network" in msgs.lower()


class TestAcceptedAlsoMeansDeliveredHint:
    """Even on full SMTP accept, the success log must clarify that
    'accepted by relay != delivered to inbox' + give the operator
    next-steps if the email never arrives."""

    def test_accepted_log_has_delivery_hint(self, rr, email_cfg, caplog):
        import logging as _lg
        caplog.set_level(_lg.INFO)
        rr.logger = _lg.getLogger("test_email_accept")
        rr.logger.setLevel(_lg.INFO)

        cm, _ = _smtp_mock()
        with patch("smtplib.SMTP", return_value=cm):
            ok = rr.send_email(email_cfg)

        assert ok is True
        msgs = " ".join(r.message for r in caplog.records)
        assert "ACCEPTED" in msgs
        assert "acceptance != delivery" in msgs.lower()
        assert "spam" in msgs.lower() or "junk" in msgs.lower()
        assert "msg_id=" in msgs
