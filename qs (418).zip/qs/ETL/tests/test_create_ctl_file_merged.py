"""Tests for the merged CreateControlFile (2026-06-12).

Locks the contract:
  * Per-report dedup (refer_createctl).
  * Filename normalisation (refer_createctl).
  * _find_data_file fallback (refer_createctl).
  * Post-write integrity validation (refer_createctl).
  * Optional CTL zip (refer_createctl).
  * Existing pipeline contract: reads compress_results, hydrates from
    sidecar, returns ctl_results, registers CTL artifacts, no
    CentralizedLogger, no /tmp fallback.
"""
from __future__ import annotations

import os
import sys
import zipfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    """Build a bare CreateControlFile instance bypassing BaseStep.__init__."""
    from steps.file.create_ctl_file import CreateControlFile
    s = CreateControlFile.__new__(CreateControlFile)
    s.logger = MagicMock()
    from steps.file.run_state import RunArtifacts
    s.artifacts = RunArtifacts(logger=MagicMock())
    s.run_report = None
    s.processed_report_ids = set()
    s.oracle_data_manager = None
    return s


# ─── 1. Reference helpers ──────────────────────────────────────────────


class TestReferenceHelpers:
    def test_normalize_filename_strips_markers(self):
        from steps.file.create_ctl_file import CreateControlFile as C
        assert C._normalize_filename("report_CLOUD.dat") == "report.dat"
        assert C._normalize_filename("x_ONPREM_y.gz") == "x_y.gz"
        assert C._normalize_filename("plain.dat") == "plain.dat"
        assert C._normalize_filename("") == ""

    def test_find_data_file_exact_match(self, tmp_path):
        step = _make_step()
        (tmp_path / "x.dat").write_text("data", encoding="utf-8")
        got = step._find_data_file(str(tmp_path), "x.dat")
        assert got == str(tmp_path / "x.dat")

    def test_find_data_file_normalised_fallback(self, tmp_path):
        """Requesting ``report_CLOUD.dat`` should find ``report.dat``."""
        step = _make_step()
        (tmp_path / "report.dat").write_text("data", encoding="utf-8")
        got = step._find_data_file(str(tmp_path), "report_CLOUD.dat")
        assert got == str(tmp_path / "report.dat")

    def test_find_data_file_directory_scan_fallback(self, tmp_path):
        """Requesting ``report.dat`` should find ``report_CLOUD.dat``
        via the directory scan (normalised match)."""
        step = _make_step()
        (tmp_path / "report_CLOUD.dat").write_text("data", encoding="utf-8")
        got = step._find_data_file(str(tmp_path), "report.dat")
        assert got == str(tmp_path / "report_CLOUD.dat")

    def test_find_data_file_returns_none_on_no_match(self, tmp_path):
        step = _make_step()
        assert step._find_data_file(str(tmp_path), "nope.dat") is None

    def test_is_report_already_processed_dedups(self):
        step = _make_step()
        assert step._is_report_already_processed("31") is False
        step._mark_report_as_processed("31")
        assert step._is_report_already_processed("31") is True
        assert step._is_report_already_processed("32") is False

    def test_normalize_zip_format_truthy(self):
        from steps.file.create_ctl_file import _normalize_zip_format
        for v in (True, "zip", "gzip", "yes", "1", "True"):
            assert _normalize_zip_format(v) is True
        for v in (False, "", "false", "no", "0", None):
            assert _normalize_zip_format(v) is False


# ─── 2. Validation + zip helpers ────────────────────────────────────────


class TestValidateAndZip:
    def test_validate_passes_for_good_ctl(self, tmp_path):
        step = _make_step()
        ctl = tmp_path / "out.ctl"
        ctl.write_text("File_Name,x\nNumber_Of_Records,5\n", encoding="utf-8")
        assert step._validate_control_file(str(ctl)) is True

    def test_validate_fails_for_missing(self, tmp_path):
        step = _make_step()
        assert step._validate_control_file(str(tmp_path / "nope.ctl")) is False

    def test_validate_fails_for_empty(self, tmp_path):
        step = _make_step()
        ctl = tmp_path / "empty.ctl"
        ctl.write_text("", encoding="utf-8")
        assert step._validate_control_file(str(ctl)) is False

    def test_zip_control_file_creates_archive_and_removes_original(self, tmp_path):
        step = _make_step()
        ctl = tmp_path / "report.ctl"
        ctl.write_text("Number_Of_Records,123\n", encoding="utf-8")
        zip_path = step._zip_control_file(str(ctl))
        assert zip_path.endswith("_ctl.zip")
        assert Path(zip_path).exists()
        # Original removed.
        assert not ctl.exists()
        # Archive contains the original CTL filename.
        with zipfile.ZipFile(zip_path, "r") as zf:
            assert "report.ctl" in zf.namelist()


# ─── 3. _build_ctl_for end-to-end ───────────────────────────────────────


class TestBuildCtlEndToEnd:
    def test_writes_ctl_next_to_compressed_file(self, tmp_path):
        step = _make_step()
        gz = tmp_path / "report.dat.gz"
        gz.write_bytes(b"gz-bytes")
        cr = {
            "report_id": 31,
            "compressed_file": str(gz),
            "md5_checksum": "abc123",
            "sha256_checksum": "def456",
            "total_records": 444024,
        }
        res = step._build_ctl_for(cr, consolidation_lookup={}, task={})
        assert res["status"] == "success"
        assert res["validation_passed"] is True
        assert res["total_records"] == 444024
        ctl = Path(res["ctl_file"])
        # Lock the file-pair contract: ``report.dat.gz`` -> ``report.dat.ctl``
        # (matches reference; matches what the Autosys polling shell pairs).
        assert ctl.name == "report.dat.ctl"
        assert ctl.exists()
        content = ctl.read_text(encoding="utf-8")
        # File / records placeholders rendered.
        assert "File_Name,report.dat.gz" in content
        assert "Number_Of_Records,444024" in content
        # MD5 placeholder is LEFT IN PLACE (Autosys handoff contract)
        # -- the polling shell fills it before SFTP.
        assert "MD5,{md5_checksum}" in content
        # Default template no longer emits a SHA256 line.
        assert "SHA256" not in content

    @pytest.mark.parametrize("data_name,ctl_name", [
        ("report.dat.gz",  "report.dat.ctl"),   # canonical pair
        ("report.zip",     "report.ctl"),
        ("report.tar.gz",  "report.tar.ctl"),
        ("report",         "report.ctl"),
    ])
    def test_ctl_filename_pair_matches_reference(self, data_name, ctl_name):
        from steps.file.create_ctl_file import CreateControlFile
        # Lock the file-pair naming so a future "tidy up the
        # extension" patch doesn't break the Autosys shell's
        # <base>.gz / <base>.ctl basename match.
        assert CreateControlFile._ctl_filename_for(data_name) == ctl_name

    def test_dedup_returns_skipped_on_second_call(self, tmp_path):
        step = _make_step()
        gz = tmp_path / "a.gz"
        gz.write_bytes(b"x")
        cr = {"report_id": 99, "compressed_file": str(gz)}
        first = step._build_ctl_for(cr, {}, {})
        second = step._build_ctl_for(cr, {}, {})
        assert first["status"] == "success"
        assert second["status"] == "skipped"
        assert "already processed" in second["message"]

    def test_zip_ctl_when_task_requests(self, tmp_path):
        step = _make_step()
        gz = tmp_path / "x.gz"
        gz.write_bytes(b"x")
        cr = {"report_id": 5, "compressed_file": str(gz)}
        task = {"zip_ctl": "zip"}
        res = step._build_ctl_for(cr, {}, task)
        assert res["status"] == "success"
        assert res.get("ctl_zip_path"), "zip_ctl=zip should produce a CTL zip"
        assert Path(res["ctl_zip_path"]).exists()
        # The original CTL was removed after zip.
        assert not Path(res["ctl_file"]).exists()

    def test_find_data_file_fallback_inside_build(self, tmp_path):
        """compress_result references report_CLOUD.dat.gz but disk has
        report.dat.gz -- the resilient lookup must find it."""
        step = _make_step()
        actual = tmp_path / "report.dat.gz"
        actual.write_bytes(b"x")
        cr = {
            "report_id": 1,
            "compressed_file": str(tmp_path / "report_CLOUD.dat.gz"),
        }
        res = step._build_ctl_for(cr, {}, {})
        assert res["status"] == "success"
        assert res["compressed_file"] == str(actual)

    def test_missing_compressed_file_raises_with_report_id(self, tmp_path):
        step = _make_step()
        cr = {"report_id": 77, "compressed_file": str(tmp_path / "nope.gz")}
        with pytest.raises(ValueError, match="report_id=77"):
            step._build_ctl_for(cr, {}, {})


# ─── 4. Contract locks: no CentralizedLogger / /tmp ─────────────────────


class TestContractLocks:
    def test_no_centralized_logger(self):
        import ast
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = getattr(node, "module", None) or ""
                names = " ".join(n.name for n in node.names)
                combined = f"{module} {names}"
                assert "CentralizedLogger" not in combined
                assert "core_libs.logger" not in module

    def test_no_tempfile_import(self):
        import ast
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for n in node.names:
                    assert n.name != "tempfile"
            elif isinstance(node, ast.ImportFrom):
                assert node.module != "tempfile"

    def test_hydrates_from_sidecar(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        assert "hydrate_task_from_sidecar(" in src

    def test_saves_sidecar(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        assert "save_task_state(" in src

    def test_registers_ctl_artifact(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        assert "RunArtifacts.CTL" in src

    def test_calls_oracle_proc_best_effort(self):
        """OTG_UPSERT_FILE_LOG_TABLE call must remain (preserved from
        current AND reference)."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        assert "OTG_UPSERT_FILE_LOG_TABLE" in src
        assert "_maybe_log_ctl_to_db" in src


# ─── 5. Autosys / Linux SFTP handoff contract ──────────────────────────


class TestAutosysHandoffContract:
    """OpenShift pods cannot SFTP; an external Linux Autosys polling
    script recomputes MD5, fills the ``{md5_checksum}`` placeholder in
    the CTL, then SFTPs.  This step MUST therefore leave the
    placeholder literal so the shell search-and-replace finds it."""

    def test_md5_placeholder_kept_literal_by_default(self, tmp_path):
        step = _make_step()
        gz = tmp_path / "x.gz"
        gz.write_bytes(b"x")
        cr = {
            "report_id": 31,
            "compressed_file": str(gz),
            "md5_checksum": "real_hash_from_compress_step",
            "total_records": 100,
        }
        res = step._build_ctl_for(cr, {}, task={})
        content = Path(res["ctl_file"]).read_text(encoding="utf-8")
        # The literal placeholder MUST appear — the Autosys polling
        # shell's sed/awk pass will find it and replace with the
        # freshly computed MD5 of the .gz on the Linux host.
        assert "{md5_checksum}" in content
        # And the eager fill from the compress step is NOT written —
        # otherwise the shell's replace would target a hex hash that
        # doesn't match its pattern and silently leave a bad CTL.
        assert "real_hash_from_compress_step" not in content

    def test_sha256_not_emitted_by_default(self, tmp_path):
        step = _make_step()
        gz = tmp_path / "x.gz"
        gz.write_bytes(b"x")
        cr = {
            "report_id": 31, "compressed_file": str(gz),
            "sha256_checksum": "fake_sha", "total_records": 1,
        }
        res = step._build_ctl_for(cr, {}, task={})
        content = Path(res["ctl_file"]).read_text(encoding="utf-8")
        # Default template doesn't include the SHA256 line at all
        # (matches the reference's commented-out behaviour).
        assert "SHA256" not in content
        assert "fake_sha" not in content

    def test_inline_checksums_opt_in_fills_md5(self, tmp_path):
        """For non-Autosys delivery (e.g. pod-direct), operator can
        opt in via task['inline_checksums'] and the placeholder is
        replaced with the actual hash."""
        step = _make_step()
        gz = tmp_path / "x.gz"
        gz.write_bytes(b"x")
        cr = {
            "report_id": 31, "compressed_file": str(gz),
            "md5_checksum": "actual_md5_value",
            "total_records": 1,
        }
        task = {"inline_checksums": True}
        res = step._build_ctl_for(cr, {}, task)
        content = Path(res["ctl_file"]).read_text(encoding="utf-8")
        assert "MD5,actual_md5_value" in content
        assert "{md5_checksum}" not in content

    def test_custom_template_with_sha256_when_operator_provides(self, tmp_path):
        """Operators who want SHA256 emit a custom template via the
        polling row's ctl_file_format.  Verify the override works AND
        the placeholder stays literal under default handoff mode."""
        step = _make_step()
        gz = tmp_path / "x.gz"
        gz.write_bytes(b"x")
        custom = (
            "File_Name,{file_name}\n"
            "Records,{total_records}\n"
            "MD5,{md5_checksum}\n"
            "SHA256,{sha256_checksum}\n"
        )
        cr = {
            "report_id": 5, "compressed_file": str(gz),
            "control_template": custom,
            "md5_checksum": "m5",
            "sha256_checksum": "s256",
            "total_records": 1,
        }
        res = step._build_ctl_for(cr, {}, task={})
        content = Path(res["ctl_file"]).read_text(encoding="utf-8")
        # Custom template applied, but BOTH checksum placeholders left
        # literal under the default Autosys handoff mode.
        assert "MD5,{md5_checksum}" in content
        assert "SHA256,{sha256_checksum}" in content

    def test_docstring_calls_out_handoff_contract(self):
        """Lock the rationale in the module docstring so a future
        maintainer doesn't 'fix' the placeholder back to inline."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "create_ctl_file.py").read_text(encoding="utf-8")
        assert "Autosys" in src
        assert "SFTP" in src
        assert "{md5_checksum}" in src.split("class CreateControlFile")[0], (
            "Module docstring must mention the {md5_checksum} placeholder "
            "contract so the design intent survives future edits"
        )


# ─── 6. Byte-for-byte parity with refer_createctl.py transformation ────


def _reference_process_template(template, total_records, zip_file_path):
    """Mirror of refer_createctl.py:216 ``_process_control_template`` —
    used by the parity test below as the ground-truth transformation.
    Re-implemented locally so the test doesn't depend on importing the
    reference module (which has a syntax issue: ``from pathlib import
    import Path``)."""
    import time as _t
    processed = template
    replacements = {
        '{total_records}': str(total_records),
        # '{sha256_checksum}': sha256,  # commented out in reference
        '{md5_checksum}': '{md5_checksum}',     # literal -- no-op
        '{file_name}': os.path.basename(zip_file_path),
        '{file_path}': zip_file_path,
        '{timestamp}': _t.strftime("%Y-%m-%d %H:%M:%S"),
        '{date}': _t.strftime("%Y-%m-%d"),
        '{year}': _t.strftime("%Y"),
        '{month}': _t.strftime("%m"),
        '{day}': _t.strftime("%d"),
    }
    for placeholder, value in replacements.items():
        if placeholder in processed:
            processed = processed.replace(placeholder, value)
    processed = processed.replace('_CLOUD.', '.').replace('_ONPREM.', '.')
    return processed


def _reference_ctl_filename(data_filename):
    """Mirror of refer_createctl.py:34 ``_get_control_filename``."""
    return f"{os.path.splitext(data_filename)[0]}.ctl"


class TestByteForByteParityWithReference:
    """Lock every CTL we produce to be byte-identical to what
    refer_createctl.py would produce for the same input.  Tests are
    parametrised over file-naming variations the user's pipeline can
    realistically present."""

    @pytest.mark.parametrize("gz_basename", [
        "report.dat.gz",
        "report_CLOUD.dat.gz",
        "report_ONPREM.dat.gz",
        "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.dat.gz",
        "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001_CLOUD.dat.gz",
    ])
    def test_ctl_filename_matches_reference(self, gz_basename):
        from steps.file.create_ctl_file import CreateControlFile
        # The reference doesn't pre-normalise the filename before
        # deriving the CTL name.  Mine must do the same.
        mine = CreateControlFile._ctl_filename_for(gz_basename)
        ref = _reference_ctl_filename(gz_basename)
        assert mine == ref, (
            f"CTL filename diverges from refer_createctl for "
            f"{gz_basename!r}: mine={mine!r} ref={ref!r}"
        )

    @pytest.mark.parametrize("gz_basename,template,total_records", [
        # Canonical case — no markers.
        (
            "report.dat.gz",
            "File_Name,{file_name}\nNumber_Of_Records,{total_records}\nMD5,{md5_checksum}",
            100,
        ),
        # With _CLOUD marker -- the marker should be stripped from the
        # rendered file_name in the CTL CONTENT (the .gz on disk keeps
        # the marker, but the CTL line reads File_Name,report.dat.gz).
        (
            "report_CLOUD.dat.gz",
            "File_Name,{file_name}\nMD5,{md5_checksum}",
            2878,
        ),
        # With _ONPREM marker.
        (
            "report_ONPREM.dat.gz",
            "File_Name,{file_name}\nMD5,{md5_checksum}",
            444024,
        ),
        # Real-shape filename from the user's failing run.
        (
            "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.dat.gz",
            "File_Name,{file_name}\nExtract_Date,{date}\n"
            "Business_Close_Date,{date}\nNumber_Of_Records,{total_records}\n"
            "MD5,{md5_checksum}",
            446902,
        ),
        # All template placeholders together — make sure no replacement
        # silently mutates anything.
        (
            "x.dat.gz",
            "FN,{file_name}\nFP,{file_path}\nN,{total_records}\n"
            "TS,{timestamp}\nD,{date}\nY,{year}\nM,{month}\nDD,{day}\n"
            "MD5,{md5_checksum}\nSHA,{sha256_checksum}",
            7,
        ),
    ])
    def test_ctl_content_matches_reference(self, tmp_path, gz_basename, template, total_records):
        """For the same template + file_path, what I render must equal
        what the reference's ``_process_control_template`` renders."""
        from steps.file.create_ctl_file import CreateControlFile
        gz_path = str(tmp_path / gz_basename)

        # Build the same replacements dict my _render uses (mirrors
        # _build_ctl_for line by line so the test catches drift).
        # Note: my replacements skip md5_checksum / sha256_checksum --
        # the reference also leaves md5 literal and never sets sha256
        # in its dict (it's commented out).  Same outcome.
        import time as _t
        replacements = {
            "file_name": os.path.basename(gz_path),
            "file_path": gz_path,
            "total_records": total_records,
            "timestamp": _t.strftime("%Y-%m-%d %H:%M:%S"),
            "date": _t.strftime("%Y-%m-%d"),
            "year": _t.strftime("%Y"),
            "month": _t.strftime("%m"),
            "day": _t.strftime("%d"),
        }
        mine = CreateControlFile._render(template, replacements)
        ref = _reference_process_template(template, total_records, gz_path)
        assert mine == ref, (
            f"CTL content diverges from refer_createctl:\n"
            f"--- MINE ---\n{mine}\n--- REF ---\n{ref}\n"
        )
