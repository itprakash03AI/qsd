"""Phase 152 Trino-pressure profiles + capacity probe + chunk-timing diagnostic.

Pins the operator surface added 2026-06-21:
  * trino_profile knob ("shared_busy" / "shared_normal" / "dedicated" /
    "high" / "low" / "auto") drives the concurrency ceiling
  * Only "auto" fires the Trino capacity probe (one quick query)
  * All other profiles are zero-overhead (just a constant)
  * Chunk timing: queue_wait_sec + stream_sec on ChunkResult so result.html
    shows operators where the time went on slow chunks
"""
from __future__ import annotations

import os
import sys
from decimal import Decimal
from unittest.mock import patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  Profile -> ceiling mapping
# ──────────────────────────────────────────────────────────────────────


class TestProfileMapping:
    def test_known_profiles_yield_expected_ceilings(self):
        from steps.file.autoplan import TRINO_PROFILES
        # Lock the per-profile ceiling values so operators see consistent
        # behaviour across runs.
        assert TRINO_PROFILES["low"] == 1
        assert TRINO_PROFILES["shared_busy"] == 2
        assert TRINO_PROFILES["shared_normal"] == 4
        assert TRINO_PROFILES["dedicated"] == 8
        assert TRINO_PROFILES["high"] == 12

    def test_default_profile_is_shared_normal(self):
        from steps.file.autoplan import DEFAULT_TRINO_PROFILE, TRINO_PROFILES
        assert DEFAULT_TRINO_PROFILE == "shared_normal"
        assert TRINO_PROFILES[DEFAULT_TRINO_PROFILE] == 4

    def test_default_ceiling_dropped_from_8_to_4(self):
        """Post-pilot regression fix: ceiling 8 caused Trino coordinator
        queueing on busy shared cluster -> 9 min vs 7 min."""
        from steps.file.autoplan import DEFAULT_CONCURRENCY_CEILING
        assert DEFAULT_CONCURRENCY_CEILING == 4


class TestProfileDrivesConcurrency:
    def _inputs(self, **kw):
        from steps.file.autoplan import AutoPlanInputs
        defaults = dict(
            total_rows=10_000_000,
            partition_cardinality=100,
            max_partition_rows=100_000,
            avg_partition_rows=100_000,
            avg_row_bytes=200,
            cpu_cores=16,
            available_memory_bytes=64 * 1024**3,  # huge so memory isn't the cap
            partition_column_configured=True,
        )
        defaults.update(kw)
        return AutoPlanInputs(**defaults)

    def test_shared_busy_caps_at_2(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_profile="shared_busy"))
        assert out.max_concurrent_chunks == 2

    def test_shared_normal_caps_at_4(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_profile="shared_normal"))
        assert out.max_concurrent_chunks == 4

    def test_dedicated_caps_at_8(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_profile="dedicated"))
        assert out.max_concurrent_chunks == 8

    def test_high_caps_at_12(self):
        from steps.file.autoplan import autoplan
        # Need enough CPU cores to actually reach 12 (cpu_cap = cores/2).
        out = autoplan(self._inputs(trino_profile="high", cpu_cores=32))
        assert out.max_concurrent_chunks == 12

    def test_low_caps_at_floor_2(self):
        """low profile maps to 1, but global CONCURRENCY_FLOOR = 2."""
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_profile="low"))
        assert out.max_concurrent_chunks == 2  # floor protects

    def test_unknown_profile_falls_back_to_default(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_profile="garbage"))
        assert out.max_concurrent_chunks == 4  # shared_normal default

    def test_operator_max_concurrent_override_wins(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(
            trino_profile="shared_busy",
            override_max_concurrent=6,
        ))
        assert out.max_concurrent_chunks == 6


# ──────────────────────────────────────────────────────────────────────
#  Auto profile + capacity probe
# ──────────────────────────────────────────────────────────────────────


class TestAutoProfile:
    """When trino_profile='auto' AND a capacity probe ran, AutoPlan picks
    the ceiling from the live cluster state.  No probe data -> fall back
    to shared_normal."""

    def _inputs(self, **kw):
        from steps.file.autoplan import AutoPlanInputs
        defaults = dict(
            total_rows=10_000_000,
            partition_cardinality=100,
            max_partition_rows=100_000,
            avg_partition_rows=100_000,
            avg_row_bytes=200,
            cpu_cores=32,
            available_memory_bytes=128 * 1024**3,
            partition_column_configured=True,
            trino_profile="auto",
        )
        defaults.update(kw)
        return AutoPlanInputs(**defaults)

    def test_auto_no_probe_falls_back_to_normal(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(trino_state_hint=None))
        # Falls back to shared_normal ceiling = 4.
        assert out.max_concurrent_chunks == 4

    def test_auto_heavy_queueing_picks_shared_busy(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(
            trino_state_hint={"queued": 15, "running": 30, "active_workers": 8},
        ))
        assert out.max_concurrent_chunks == 2  # shared_busy

    def test_auto_moderate_load_picks_shared_normal(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(
            trino_state_hint={"queued": 5, "running": 20, "active_workers": 8},
        ))
        assert out.max_concurrent_chunks == 4  # shared_normal

    def test_auto_idle_cluster_picks_dedicated(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(
            trino_state_hint={"queued": 0, "running": 2, "active_workers": 12},
        ))
        assert out.max_concurrent_chunks == 8  # dedicated

    def test_auto_decision_reason_carries_probe_data(self):
        from steps.file.autoplan import autoplan
        out = autoplan(self._inputs(
            trino_state_hint={"queued": 15, "running": 30, "active_workers": 8},
        ))
        ceil_dec = next(
            d for d in out.decisions if d.knob == "max_concurrent_chunks"
        )
        assert "queued=15" in ceil_dec.reason
        assert "shared_busy" in ceil_dec.reason


class TestCeilingFromAutoProbeHelper:
    def test_no_state_returns_shared_normal(self):
        from steps.file.autoplan import _ceiling_from_auto_probe
        ceiling, reason = _ceiling_from_auto_probe(None)
        assert ceiling == 4
        assert "no capacity probe" in reason

    def test_empty_state_returns_shared_normal(self):
        from steps.file.autoplan import _ceiling_from_auto_probe
        ceiling, reason = _ceiling_from_auto_probe({})
        assert ceiling == 4

    def test_heavily_queued_returns_shared_busy(self):
        from steps.file.autoplan import _ceiling_from_auto_probe
        ceiling, _ = _ceiling_from_auto_probe(
            {"queued": 20, "running": 50, "active_workers": 8}
        )
        assert ceiling == 2

    def test_idle_dedicated_returns_dedicated(self):
        from steps.file.autoplan import _ceiling_from_auto_probe
        ceiling, _ = _ceiling_from_auto_probe(
            {"queued": 0, "running": 0, "active_workers": 15}
        )
        assert ceiling == 8


# ──────────────────────────────────────────────────────────────────────
#  Profile resolution from polling row + env
# ──────────────────────────────────────────────────────────────────────


class TestProfileFromJobConfig:
    def test_profile_from_job_config_lowercase(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={"trino_profile": "dedicated"},
        )
        assert inp.trino_profile == "dedicated"

    def test_profile_from_polling_row_uppercase(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={"TRINO_PROFILE": "shared_busy"},
        )
        assert inp.trino_profile == "shared_busy"

    def test_profile_from_env_var(self):
        from steps.file.autoplan import build_inputs_from_probe
        with patch.dict(os.environ, {"QS_DEFAULT_TRINO_PROFILE": "high"}, clear=False):
            inp = build_inputs_from_probe(
                probe_result=None, total_rows=1000, job_config={},
            )
        assert inp.trino_profile == "high"

    def test_polling_row_wins_over_env(self):
        from steps.file.autoplan import build_inputs_from_probe
        with patch.dict(os.environ, {"QS_DEFAULT_TRINO_PROFILE": "high"}, clear=False):
            inp = build_inputs_from_probe(
                probe_result=None, total_rows=1000,
                job_config={"TRINO_PROFILE": "shared_busy"},
            )
        assert inp.trino_profile == "shared_busy"

    def test_default_when_nothing_set(self):
        from steps.file.autoplan import build_inputs_from_probe
        with patch.dict(os.environ, {"QS_DEFAULT_TRINO_PROFILE": ""}, clear=False):
            inp = build_inputs_from_probe(
                probe_result=None, total_rows=1000, job_config={},
            )
        assert inp.trino_profile == "shared_normal"


# ──────────────────────────────────────────────────────────────────────
#  Chunk timing instrumentation
# ──────────────────────────────────────────────────────────────────────


class TestChunkTimingMarkers:
    def test_writer_exposes_three_timing_markers(self, tmp_path):
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id"],
            delimiter="|",
            logger=logging.getLogger("test"),
        )
        # Markers default to None.
        assert cw.time_started is None
        assert cw.time_first_batch is None
        assert cw.time_completed is None

    def test_writer_sets_markers_through_lifecycle(self, tmp_path):
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id"],
            delimiter="|",
            logger=logging.getLogger("test"),
        )
        cw.start()
        cw.put_batch([("1",), ("2",)])
        cw.signal_end()
        cw.join()
        assert cw.time_started is not None
        assert cw.time_first_batch is not None
        assert cw.time_completed is not None
        assert cw.time_started <= cw.time_first_batch <= cw.time_completed

    def test_first_batch_timeout_distinct_from_idle(self, tmp_path):
        """Two thresholds: pre-first-batch (longer) and idle (shorter)."""
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id"],
            delimiter="|",
            logger=logging.getLogger("test"),
            first_batch_timeout_seconds=900,
            idle_timeout_seconds=120,
        )
        assert cw.first_batch_timeout == 900
        assert cw.idle_timeout == 120

    def test_first_batch_timeout_default_is_30min(self, tmp_path):
        """30 min covers typical Trino coordinator queue wait."""
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id"],
            delimiter="|",
            logger=logging.getLogger("test"),
        )
        assert cw.first_batch_timeout == 1800  # 30 min default


# ──────────────────────────────────────────────────────────────────────
#  ChunkResult carries timing
# ──────────────────────────────────────────────────────────────────────


class TestChunkResultTiming:
    def test_chunkresult_has_timing_fields(self):
        from steps.file.starburst_file_base import ChunkResult
        r = ChunkResult(
            partition_index=0, partition_value="X",
            file_path="/tmp/x.dat",
            expected=100, actual=100, attempts=1, duration_sec=5.0,
            success=True,
            queue_wait_sec=3.2, stream_sec=1.8,
        )
        assert r.queue_wait_sec == 3.2
        assert r.stream_sec == 1.8

    def test_chunkresult_timing_defaults_to_none(self):
        from steps.file.starburst_file_base import ChunkResult
        r = ChunkResult(
            partition_index=0, partition_value="X",
            file_path="/tmp/x.dat",
            expected=100, actual=100, attempts=1, duration_sec=5.0,
            success=True,
        )
        assert r.queue_wait_sec is None
        assert r.stream_sec is None


# ──────────────────────────────────────────────────────────────────────
#  result.html surfaces queue-pressure rows
# ──────────────────────────────────────────────────────────────────────


class TestHtmlQueuePressureRow:
    def test_queue_pressure_class_when_qw_greatly_exceeds_stream(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        # 60s queue wait vs 5s stream -- queue pressure.
        rr.add_chunk_result({
            "job_id": "42", "datasource": "CLOUD",
            "partition_index": 0, "partition_value": "X",
            "expected": 100, "actual": 100, "attempts": 1,
            "duration_sec": 65.0,
            "queue_wait_sec": 60.0,
            "stream_sec": 5.0,
        })
        html = rr.to_html()
        assert "queue-pressure" in html
        assert "60.0s" in html  # queue_wait visible
        assert "Trino coordinator queued this chunk" in html

    def test_normal_chunk_no_queue_pressure_class(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        # 2s queue wait vs 30s stream -- normal.
        rr.add_chunk_result({
            "job_id": "42", "datasource": "CLOUD",
            "partition_index": 0, "partition_value": "X",
            "expected": 100, "actual": 100, "attempts": 1,
            "duration_sec": 32.0,
            "queue_wait_sec": 2.0,
            "stream_sec": 30.0,
        })
        html = rr.to_html()
        # No queue-pressure class on this chunk's row.
        # (it's still rendered with the verdict class only).
        lines = [l for l in html.split("\n") if "partition_value" not in l and "<tr" in l]
        # Find the chunk row -- should NOT have queue-pressure.
        chunk_rows = [l for l in lines if "X" in l and "queue-pressure" in l]
        assert chunk_rows == []

    def test_html_table_has_queue_wait_and_stream_columns(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        html = rr.to_html()
        assert "Queue wait" in html
        assert "Stream" in html
