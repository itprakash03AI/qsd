"""2026-06-22 deep-audit guards: lock the standalone -> worker ->
yaml workflow key -> step-modules chain so future drift breaks tests
instead of breaking prod runs.

Bugs caught by this audit pass (now locked):
  * bug #19: oracle_worker hardcoded "createJob" but yaml had "oracle"
    after Phase 152 docs; user's older yaml only had "oracle"
  * bug #20a: yaml referenced moved-but-not-updated modules
    (steps.check_dependencies, steps.send_email_notifications, etc.)
  * bug #20b: s3_query_worker hardcoded prod-only yaml path
  * bug #20c: nonexistent module references (steps.pre_data_validation,
    steps.sub_to_file_poc) silently logged WARN on import + failed at
    execute time

This file does NOT test the dispatcher.py routing layer -- there's a
known pre-existing landmine where dag_type="file" routes to OracleWorker
(loads "oracle" yaml) instead of FileWorker (loads "file" yaml).  Not
exercised in current production but flagged in code comments.
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# Expected: standalone file -> worker module -> yaml workflow key
# 2026-06-22 -- s3_query split into s3_to_file + s3_to_oracle.
_WORKFLOW_CHAIN = [
    # (standalone_file, worker_module, worker_class_name, yaml_workflow_key)
    ("file_standalone.py", "workers/file_worker.py", "FileWorker", "file"),
    ("oracle_standalone.py", "workers/oracle_worker.py", "OracleWorker", "oracle"),
    ("file_to_oracle_standalone.py", "workers/file_to_oracle_worker.py",
     "FileToOracleWorker", "file_to_oracle"),
    ("s3_to_file_standalone.py", "workers/s3_worker.py",
     "S3ToFileWorker", "s3_to_file"),
    ("s3_to_oracle_standalone.py", "workers/s3_worker.py",
     "S3ToOracleWorker", "s3_to_oracle"),
    ("sap_odata_standalone.py", "workers/sap_odata_worker.py",
     "SapOdataWorker", "sap_odata"),
]


def _read(rel_path: str) -> str:
    with open(os.path.join(_ETL_ROOT, rel_path), encoding="utf-8") as f:
        return f.read()


# ──────────────────────────────────────────────────────────────────────
# Chain 1 -- standalone files exist
# ──────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("standalone,_w,_c,_k", _WORKFLOW_CHAIN)
def test_standalone_file_exists(standalone, _w, _c, _k):
    path = os.path.join(_ETL_ROOT, standalone)
    assert os.path.exists(path), f"Standalone {standalone} missing"


def test_oracle_standalone_canonical_file_present():
    """Phase 158 R9 (2026-06-26) -- the typo'd ``oracle_standlone.py``
    was renamed to ``oracle_standalone.py`` everywhere; the shim was
    removed.  This test guards the canonical file's presence."""
    canonical = os.path.join(_ETL_ROOT, "oracle_standalone.py")
    assert os.path.exists(canonical), (
        "oracle_standalone.py missing -- typo'd version was renamed; "
        "the no-typo file is now canonical."
    )
    body = _read("oracle_standalone.py")
    assert "async def main" in body or "def main" in body, (
        "oracle_standalone.py must define main() (the asyncio entry)"
    )


# ──────────────────────────────────────────────────────────────────────
# Chain 2 -- worker module + class exist
# ──────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("_s,worker_path,_c,_k", _WORKFLOW_CHAIN)
def test_worker_module_exists(_s, worker_path, _c, _k):
    path = os.path.join(_ETL_ROOT, worker_path)
    assert os.path.exists(path), f"Worker {worker_path} missing"


@pytest.mark.parametrize("_s,worker_path,cls_name,_k", _WORKFLOW_CHAIN)
def test_worker_class_declared(_s, worker_path, cls_name, _k):
    body = _read(worker_path)
    assert f"class {cls_name}" in body, (
        f"{worker_path} must declare class {cls_name}"
    )


# ──────────────────────────────────────────────────────────────────────
# Chain 3 -- worker loads the CORRECT yaml workflow key
# ──────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("_s,worker_path,_c,yaml_key", _WORKFLOW_CHAIN)
def test_worker_loads_correct_workflow_key(_s, worker_path, _c, yaml_key):
    """Worker must call load_step_mapping with the matching yaml key."""
    body = _read(worker_path)
    # Tolerate either pattern:
    #   self.load_step_mapping("oracle")
    #   self.load_step_mapping(self.WORKFLOW)  + WORKFLOW = "oracle"
    direct_call = f'load_step_mapping("{yaml_key}")' in body or \
                  f"load_step_mapping('{yaml_key}')" in body
    via_attr = f'WORKFLOW = "{yaml_key}"' in body or \
               f"WORKFLOW = '{yaml_key}'" in body
    assert direct_call or via_attr, (
        f"{worker_path} must load yaml workflow {yaml_key!r} either "
        f"directly or via WORKFLOW class attribute"
    )


# ──────────────────────────────────────────────────────────────────────
# Chain 4 -- yaml workflow key exists
# ──────────────────────────────────────────────────────────────────────


def test_all_yaml_workflow_keys_present():
    import yaml
    body = _read("configs/step_mapping.yaml")
    m = yaml.safe_load(body)
    expected = {chain[3] for chain in _WORKFLOW_CHAIN}
    actual = set(m.keys())
    missing = expected - actual
    assert not missing, f"Missing workflow keys in yaml: {missing}"


def test_createJob_not_in_yaml():
    """Regression guard: 'createJob' yaml key was removed in bug #19
    fix.  Should never come back -- it was a misguided rename."""
    import yaml
    body = _read("configs/step_mapping.yaml")
    m = yaml.safe_load(body)
    assert "createJob" not in m, (
        "createJob should NOT be a yaml workflow key.  Use 'oracle' "
        "(canonical) -- the worker fallback handles old deployments "
        "still on the createJob name."
    )


# ──────────────────────────────────────────────────────────────────────
# Chain 5 -- step modules referenced in yaml ACTUALLY EXIST on disk
# ──────────────────────────────────────────────────────────────────────


# 2 modules are INTENTIONALLY broken (production-yaml-parity markers).
# These point at modules that exist in the user's production PVC but
# were NEVER committed to git (operator-added on the cluster).  Kept
# in yaml to match the production reference verbatim; will fail
# clean-import in this repo but work on the PVC where they exist.
_INTENTIONALLY_BROKEN = {
    "steps.pre_data_validation",   # exists on prod PVC, not in repo
    "steps.sb_to_file_poc",        # exists on prod PVC, not in repo
}


def test_yaml_step_modules_all_exist_on_disk():
    """Every step's module: <name> in yaml must map to an existing
    .py file on disk (except intentional deprecation markers)."""
    import yaml
    body = _read("configs/step_mapping.yaml")
    m = yaml.safe_load(body)
    missing = []
    for workflow, steps in m.items():
        for step_name, details in steps.items():
            mod = details.get("module", "")
            if mod in _INTENTIONALLY_BROKEN:
                continue
            rel = mod.replace(".", "/") + ".py"
            if not os.path.exists(os.path.join(_ETL_ROOT, rel)):
                missing.append(f"{workflow}/{step_name} -> {mod} ({rel})")
    assert not missing, (
        f"Yaml references step modules that don't exist on disk:\n  "
        + "\n  ".join(missing) + "\n"
        f"Either: (a) module was moved -- update yaml path, "
        f"(b) module never existed -- remove from yaml, or "
        f"(c) module is being added in this PR -- create it."
    )


# ──────────────────────────────────────────────────────────────────────
# Chain 6 -- yaml loader resilience (prod -> local fallback)
# ──────────────────────────────────────────────────────────────────────


_NON_PROD_PATH_WORKERS = [
    "workers/file_worker.py",
    "workers/file_to_oracle_worker.py",
    "workers/oracle_worker.py",
    "workers/s3_worker.py",   # 2026-06-22 -- renamed from s3_query_worker
    "workers/sap_odata_worker.py",
]


def test_oracle_standalone_uses_shared_starburst_loader():
    """2026-06-22 user request: 'starburst details should come from
    common config files... single truth of source for starburst
    connections'.

    oracle_standalone.py builds Starburst clients (StarburstDataSource
    instances) -- must use the shared loader so polling-row > yaml >
    env precedence is honoured uniformly.
    """
    body = _read("oracle_standalone.py")
    assert "build_starburst_clients_from_row" in body, (
        "oracle_standalone must use starburst_config_loader for "
        "Starburst credentials (single source of truth)."
    )


def test_file_standalone_does_not_read_starburst_creds_from_polling_row():
    """2026-06-22 user direction: 'file_standalone doesn't read from
    polling row'.

    File-workflow extract steps (starburst_file_base) build their own
    Starburst connections at extract time via the shared
    configs/starburst_config.yaml.  file_standalone must NOT build
    starburst_clients from polling-row c_hostname/c_pwd/etc. columns
    -- doing so would (a) duplicate logic, (b) read creds from the
    wrong source, (c) drift from the documented single-source pattern.
    """
    body = _read("file_standalone.py")
    # The legacy inline pattern that read polling-row Starburst creds
    # must be gone.  Specifically: no `sample.get("c_pwd")` /
    # `sample.get("p_pwd")` Starburst-cred reads in file_standalone.
    assert 'sample.get("c_pwd")' not in body, (
        "file_standalone must NOT read Starburst password from polling "
        "row -- creds belong in shared starburst_config.yaml"
    )
    assert 'sample.get("p_pwd")' not in body, (
        "file_standalone must NOT read Starburst password from polling "
        "row -- creds belong in shared starburst_config.yaml"
    )
    # And no fallback inline-builder that constructs StarburstDataSource
    # from c_hostname/c_username.
    assert "sample.get(\"c_hostname\")" not in body or "starburst_config_loader" not in body or "starburst_clients[\"cloud\"] = StarburstDataSource" not in body, (
        "file_standalone has reintroduced polling-row Starburst client "
        "construction.  Use shared starburst_config.yaml instead."
    )


@pytest.mark.parametrize("worker_path", _NON_PROD_PATH_WORKERS)
def test_worker_yaml_loader_has_local_fallback(worker_path):
    """Each worker must resolve yaml path via prod-then-local fallback
    (not hardcoded prod-only).  Catches bug #19/#20 reintroduction."""
    body = _read(worker_path)
    has_local_fallback = (
        "_LOCAL_MAPPING_PATH" in body
        or "local_path" in body
        or "candidate_paths" in body
        or "_LOCAL_PATH" in body
    )
    assert has_local_fallback, (
        f"{worker_path}: yaml loader appears to hardcode the prod path "
        f"with no local-dev fallback.  Required pattern: try "
        f"/usr/local/spark/pvc/code/configs/step_mapping.yaml first, "
        f"then fall back to ETL/configs/step_mapping.yaml."
    )
