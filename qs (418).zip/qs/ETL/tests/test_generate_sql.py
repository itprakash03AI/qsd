"""GenerateSQL contract + Phase 152 landmine tests.

Locks 3 contracts:

  1. jobs[] JSON shape MATCHES sourcequery.json byte-for-byte.
     Every key, every type (port=int, zip_format=str, system_entity=
     None->null).  Any future change adding/removing/renaming keys
     trips this test.

  2. Landmine #2 -- partial-source success is FAIL-LOUD by default.
     A per-data-source failure raises RuntimeError unless polling row
     opts in via allow_partial_datasources=true.

  3. Landmine #3 -- missing run_date is FAIL-LOUD by default.
     If OTG_AIRFLOW_DAG_RUN has no row for (dag_id, dag_run_id,
     business_date), raise RuntimeError unless polling row opts in
     via allow_missing_run_date=true.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from unittest.mock import MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  Fixtures -- mock Oracle returning a 2-data-source FLEX_ADJ report
#  (mirrors the sourcequery.json sample shipped with the repo).
# ──────────────────────────────────────────────────────────────────────


def _build_cursor(
    *,
    run_date: str = "20260131",
    data_sources: tuple = (("CLOUD", "claude", 8443), ("ONPREM", "claude.com", 443)),
    data_source_details_override: dict | None = None,
    table_mapping_override: dict | None = None,
):
    """Build a MagicMock cursor that returns the 7 Oracle metadata
    queries in deterministic order based on the EXEC sql + params.

    Default returns the same shape as sourcequery.json: report 1001,
    2 data sources (CLOUD via oncludeschema, ONPREM via onpremschema).
    """
    cursor = MagicMock()
    fetch_one_calls: list = []
    fetch_all_calls: list = []

    def _execute(sql, binds=None):
        cursor._last_sql = sql
        cursor._last_binds = binds or {}

    def _all_ds_ids_from_in_binds(binds):
        """The batched fetcher binds :id0, :id1, ... to data source ids."""
        return [v for k, v in sorted(binds.items()) if k.startswith("id")]

    def _details_for(ds_id):
        if data_source_details_override is not None:
            return data_source_details_override.get(ds_id)
        for idx, (name, host, port) in enumerate(data_sources):
            if str(ds_id) == f"ds_{idx + 1}":
                return (ds_id, name, host, port)
        return None

    def _table_map_for(ds_id):
        if table_mapping_override is not None:
            v = table_mapping_override.get(ds_id)
            return v if v is not None else []
        if str(ds_id) == "ds_1":
            return [("ds_1", "oncludeschema.FLEX_ADJ_MONTHEND_20250831_20260131", "t1")]
        if str(ds_id) == "ds_2":
            return [("ds_2", "onpremschema.FLEX_ADJ_MONTHEND_20250831_20260131", "t1")]
        return []

    def _fetchone():
        sql = cursor._last_sql
        if "OTG_AIRFLOW_DAG_RUN" in sql:
            if run_date is None:
                return None
            return (run_date,)
        if "OTG_REPORT_CONFIG" in sql:
            # report_id, file_format, file_name, delimiter, file_location,
            # control_template_id, zip_format
            return (
                1001, "dat",
                "FLEX_ADJ_MONTHEND_{business_date}_{run_date}_U_pk",
                "|", "/usr/local/spark/nfs/OutputGatewayDev/daily/",
                "CT_001", "false",
            )
        # Legacy single-source API (kept for back-compat tests).
        if "OTG_DATA_SOURCE_DETAILS" in sql and "IN (" not in sql:
            return _details_for(cursor._last_binds.get("data_source_id"))
        return None

    def _fetchall():
        sql = cursor._last_sql
        binds = cursor._last_binds
        if "OTG_REPORT_DATA_SOURCE_MAPPING" in sql:
            return [(1001, f"ds_{i + 1}") for i in range(len(data_sources))]
        # Batched IN-list per-source fetchers (2026-06-21).
        if "OTG_DATA_SOURCE_DETAILS" in sql and "IN (" in sql:
            ids = _all_ds_ids_from_in_binds(binds)
            return [r for r in (_details_for(i) for i in ids) if r is not None]
        if "OTG_DATA_SOURCE_TABLE_MAPPING" in sql and "IN (" in sql:
            ids = _all_ds_ids_from_in_binds(binds)
            out: list = []
            for i in ids:
                out.extend(_table_map_for(i))
            return out
        # Legacy single-source table mapping (kept for back-compat).
        if "OTG_DATA_SOURCE_TABLE_MAPPING" in sql:
            return _table_map_for(binds.get("data_source_id"))
        if "OTG_REPORT_COLUMN_MAPPING" in sql:
            return [("*", "*", 1, "t1")]
        if "OTG_REPORT_PARAM_CONFIG" in sql:
            return [("FROM_TABLE", "{{t1}}")]
        if "OTG_CONTROL_TEMPLATE" in sql:
            return [("CT_001",
                     "File_Name,{file_name}\n"
                     "Extract_Date,{run_date}\n"
                     "Business_Close_Date,{business_date}\n"
                     "Number_Of_Records,{total_records}")]
        return []

    cursor.execute.side_effect = _execute
    cursor.fetchone.side_effect = _fetchone
    cursor.fetchall.side_effect = _fetchall
    return cursor


def _make_step(tmp_path):
    """Construct a GenerateSQL instance with stub deps, override the
    YAML/Oracle config load + connection, and pre-set logger."""
    from unittest.mock import MagicMock

    fake_oracle_config = {
        "user": "x", "password": "y", "dsn": "host/sid",
    }
    with patch.object(
        __import__("steps.file.generate_sql", fromlist=["GenerateSQL"]).GenerateSQL,
        "load_oracle_config",
        return_value=fake_oracle_config,
    ):
        from steps.file.generate_sql import GenerateSQL
        step = GenerateSQL(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )
    step.logger = MagicMock()  # silence file-handler attach
    return step


def _make_task(tmp_path, **overrides):
    out_json = tmp_path / "sourcequery.json"
    task = {
        "task_id": 1,
        "run_id": "run_xyz",
        "fk_report_id": 1001,
        "fk_dag_id": "DAG_FLEX",
        "business_date": "2025-08-31",
        "sql_query_path": str(out_json),
        "log_file": str(tmp_path / "run.log"),
        "job_type": "FILE",
        "system_entity": None,
    }
    task.update(overrides)
    return task


# ──────────────────────────────────────────────────────────────────────
#  Contract 1 -- jobs[] shape matches sourcequery.json byte-for-byte
# ──────────────────────────────────────────────────────────────────────


class TestJobsShapeContract:
    """sourcequery.json (in steps/file/) is THE contract.  Composer
    output keys + types must remain byte-equivalent."""

    REQUIRED_KEYS = {
        "job_id", "report_id", "datasource_name", "business_date", "run_date",
        "generated_sql", "output_file_name", "output_file_type",
        "output_file_delimiter", "output_file_location", "ctl_file_format",
        "system_entity", "server_name", "port", "zip_format",
    }
    OPTIONAL_PHASE152_KEYS = {"checksum_columns", "partition_config"}

    def test_jobs_keys_match_sourcequery_json(self, tmp_path):
        """Every key in the produced jobs[] entry matches the prod
        sample.  No extra keys (unless Phase 152 opt-ins)."""
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)

        assert "jobs" in doc
        assert len(doc["jobs"]) == 2  # CLOUD + ONPREM
        for job in doc["jobs"]:
            actual = set(job.keys())
            missing = self.REQUIRED_KEYS - actual
            extra = actual - self.REQUIRED_KEYS - self.OPTIONAL_PHASE152_KEYS
            assert not missing, f"Missing required keys: {missing}"
            assert not extra, f"Unexpected extra keys: {extra}"

    def test_jobs_type_contract(self, tmp_path):
        """port = int, zip_format = str, system_entity = None (->null
        in JSON).  Type drift is silently breaking for downstream
        connectors that expect specific types."""
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)

        for job in doc["jobs"]:
            assert isinstance(job["port"], int)
            assert isinstance(job["zip_format"], str)
            assert isinstance(job["job_id"], str)
            assert job["job_id"] == "job_1001"
            assert isinstance(job["report_id"], int)
            assert job["system_entity"] is None
            assert isinstance(job["generated_sql"], str) and job["generated_sql"]
            assert isinstance(job["output_file_name"], str)
            assert "_" in job["output_file_name"]  # datasource suffix added

    def test_per_datasource_sql_resolves_to_different_tables(self, tmp_path):
        """The CORE of cross-data-source composition: same logical
        config -> different FQN per data source via OTG_DATA_SOURCE_
        TABLE_MAPPING alias resolution.  Locks the cross-engine
        readiness."""
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)

        sqls = {j["datasource_name"]: j["generated_sql"] for j in doc["jobs"]}
        assert "oncludeschema" in sqls["CLOUD"]
        assert "onpremschema" in sqls["ONPREM"]
        # Same logical structure -- SELECT * FROM <alias-resolved>
        assert sqls["CLOUD"].split()[:2] == sqls["ONPREM"].split()[:2]

    def test_phase152_passthrough_only_when_polling_row_sets_them(self, tmp_path):
        """checksum_columns + partition_config keys are ADDITIVE.
        Absent on polling row -> absent in JSON (matches prod sample).
        Present on polling row -> appear as optional keys."""
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)
        for job in doc["jobs"]:
            assert "checksum_columns" not in job
            assert "partition_config" not in job

        # Now opt in -- both keys appear
        step2 = _make_step(tmp_path)
        cursor2 = _build_cursor()
        task2 = _make_task(
            tmp_path,
            sql_query_path=str(tmp_path / "sq2.json"),
            checksum_columns="amt,qty",
            partition_column="cob_date",
            partition_enabled=True,
        )
        with patch.object(step2, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor2
            asyncio.run(step2._execute_step(task2, "", "", "GenerateSQL"))

        with open(task2["sql_query_path"], encoding="utf-8") as f:
            doc2 = json.load(f)
        for job in doc2["jobs"]:
            assert job["checksum_columns"] == ["amt", "qty"]
            assert job["partition_config"]["partition_column"] == "cob_date"


# ──────────────────────────────────────────────────────────────────────
#  Contract 2 -- partial-source FAIL-LOUD by default
# ──────────────────────────────────────────────────────────────────────


class TestLandmineNo2_PartialDatasources:
    """If 1 of N data sources fails to fetch details / table_mapping,
    the PRE-Phase-152 code silently `continue`d and emitted half the
    jobs.  Now it MUST raise unless polling row sets
    allow_partial_datasources=true."""

    def test_default_raises_on_per_source_failure(self, tmp_path):
        step = _make_step(tmp_path)
        # ds_2 returns None from _fetch_data_source_details
        cursor = _build_cursor(
            data_source_details_override={
                "ds_1": ("ds_1", "CLOUD", "claude", 8443),
                "ds_2": None,  # simulates missing OTG_DATA_SOURCE_DETAILS row
            },
        )
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            with pytest.raises(Exception) as exc_info:
                asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        # Either the inner RuntimeError bubbles or the outer wrap; both
        # must mention failed source + opt-in.
        msg = str(exc_info.value)
        assert "data source" in msg.lower() or "Failed to generate SQL" in msg

    def test_opt_in_emits_partial_jobs(self, tmp_path):
        step = _make_step(tmp_path)
        cursor = _build_cursor(
            data_source_details_override={
                "ds_1": ("ds_1", "CLOUD", "claude", 8443),
                "ds_2": None,
            },
        )
        task = _make_task(tmp_path, allow_partial_datasources="true")
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            # With opt-in, completes successfully with 1 job in JSON
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)
        assert len(doc["jobs"]) == 1
        assert doc["jobs"][0]["datasource_name"] == "CLOUD"

    def test_all_sources_failing_still_raises_even_with_opt_in(self, tmp_path):
        """allow_partial_datasources lets you tolerate SOME failures,
        not ALL.  Empty result still raises (Failed to generate SQL)."""
        step = _make_step(tmp_path)
        cursor = _build_cursor(
            data_source_details_override={"ds_1": None, "ds_2": None},
        )
        task = _make_task(tmp_path, allow_partial_datasources="true")
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            with pytest.raises(Exception):
                asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))


# ──────────────────────────────────────────────────────────────────────
#  Contract 3 -- missing run_date FAIL-LOUD by default
# ──────────────────────────────────────────────────────────────────────


class TestLandmineNo3_MissingRunDate:
    """OTG_AIRFLOW_DAG_RUN may not have a row for manual replays.
    Pre-Phase-152 silently used datetime.now() which baked TODAY's
    date into file names + WHERE filters -- wrong cob, hardest bug to
    spot.  Now MUST raise unless allow_missing_run_date=true."""

    def test_default_raises_when_run_date_missing(self, tmp_path):
        step = _make_step(tmp_path)
        cursor = _build_cursor(run_date=None)
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            with pytest.raises(Exception) as exc_info:
                asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        msg = str(exc_info.value)
        assert "run_date" in msg.lower() or "Failed to generate SQL" in msg

    def test_opt_in_falls_back_to_now(self, tmp_path):
        from datetime import datetime
        step = _make_step(tmp_path)
        cursor = _build_cursor(run_date=None)
        task = _make_task(tmp_path, allow_missing_run_date="true")
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))

        with open(task["sql_query_path"], encoding="utf-8") as f:
            doc = json.load(f)
        today = datetime.now().strftime("%Y%m%d")
        for job in doc["jobs"]:
            assert job["run_date"] == today


# ──────────────────────────────────────────────────────────────────────
#  _truthy helper -- polling-row cell coercion
# ──────────────────────────────────────────────────────────────────────


class TestSqlHash:
    """Stable sha256[:12] hash so operators see SQL drift across runs
    in result.html runtime_knobs."""

    def test_hash_is_stable(self):
        from steps.file.generate_sql import GenerateSQL
        h1 = GenerateSQL._sql_hash("SELECT * FROM t WHERE x=1")
        h2 = GenerateSQL._sql_hash("SELECT * FROM t WHERE x=1")
        assert h1 == h2
        assert len(h1) == 12

    def test_hash_changes_on_sql_change(self):
        from steps.file.generate_sql import GenerateSQL
        h1 = GenerateSQL._sql_hash("SELECT * FROM t WHERE x=1")
        h2 = GenerateSQL._sql_hash("SELECT * FROM t WHERE x=2")
        assert h1 != h2

    def test_hash_empty_sql(self):
        from steps.file.generate_sql import GenerateSQL
        assert GenerateSQL._sql_hash("") == ""


class TestSqlValidation:
    """sqlglot.parse_one(sql, dialect='trino') catches malformed
    FILTER / JOIN rows at compose time."""

    def test_valid_sql_passes(self, tmp_path):
        step = _make_step(tmp_path)
        # Should NOT raise.
        step._validate_composed_sql(
            "SELECT a, b FROM tbl WHERE x = 1", "CLOUD",
        )

    def test_malformed_sql_raises_with_offending_text(self, tmp_path):
        step = _make_step(tmp_path)
        # Trino SELECT requires a target list -- empty FROM is a parse err.
        bad_sql = "SELECT a, FROM WHERE x ===== 1 GROUP BY"
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed -- validation is a no-op")
        with pytest.raises(RuntimeError) as exc_info:
            step._validate_composed_sql(bad_sql, "CLOUD")
        assert "CLOUD" in str(exc_info.value)
        assert "FILTER" in str(exc_info.value) or "JOIN" in str(exc_info.value)


class TestSqlOptimization:
    """Composer-side optimization for faster execution on both
    Starburst (Trino) and Spark (Iceberg/S3) engines."""

    def test_simplify_removes_redundant_true(self, tmp_path):
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed")
        step = _make_step(tmp_path)
        sql = "SELECT a FROM t WHERE TRUE AND x = 1"
        optimized, info = step._optimize_composed_sql(sql, "CLOUD")
        # Either optimized==True (TRUE removed) or no-change (already
        # optimal in sqlglot's view).  Both are valid; the test that
        # matters is no exception + info dict shape.
        assert isinstance(info["original_len"], int)
        assert isinstance(info["optimized_len"], int)
        assert "simplify" in info["passes_applied"]
        assert "normalize" in info["passes_applied"]
        # 2026-06-21 -- pushdown_predicates is OPT-IN (default OFF) after
        # audit caught alias-rewriting bug on FROM (SELECT...) sub shapes.
        assert "pushdown_predicates" not in info["passes_applied"]

    def test_pushdown_opt_in_enables_pushdown_pass(self, tmp_path):
        """When polling row sets enable_sql_pushdown_optimization=true,
        pushdown_predicates joins the pipeline."""
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed")
        step = _make_step(tmp_path)
        step._enable_sql_pushdown_optimization = True
        sql = "SELECT a FROM t WHERE x = 1"
        _, info = step._optimize_composed_sql(sql, "CLOUD")
        assert "pushdown_predicates" in info["passes_applied"]

    def test_pushdown_disabled_by_default_protects_subquery_alias_shape(
        self, tmp_path,
    ):
        """The dangerous shape (FROM (SELECT...) sub WHERE sub.col=...)
        must NOT be rewritten by default -- pushdown would push sub.col
        into the subquery scope where it's undefined and Trino rejects.
        Verifies the safety-by-default contract."""
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed")
        step = _make_step(tmp_path)
        # Default: pushdown is OFF.
        assert step._enable_sql_pushdown_optimization is False
        sql = ("SELECT cob FROM (SELECT * FROM iceberg.fact) sub "
               "WHERE sub.cob = '2025-08-31'")
        optimized, _ = step._optimize_composed_sql(sql, "CLOUD")
        # The dangerous rewrite would push 'sub.cob' INTO the subquery.
        # Default pipeline must NOT do this.
        # Verify the predicate stays at the OUTER level.
        assert "WHERE sub.cob" in optimized or "WHERE sub.\"cob\"" in optimized

    def test_optimization_never_breaks_on_complex_sql(self, tmp_path):
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed")
        step = _make_step(tmp_path)
        # A real-shape composed SQL with JOINs, WHERE, GROUP BY.
        sql = (
            'SELECT t1.a AS "Acct", SUM(t1.b) AS "Amt" '
            'FROM oncludeschema.fact_table t1 '
            'JOIN oncludeschema.dim_table t2 ON t1.id = t2.id '
            "WHERE t1.cob_date = '2025-08-31' AND t2.active = 1 "
            'GROUP BY t1.a'
        )
        optimized, info = step._optimize_composed_sql(sql, "CLOUD")
        # Must be parseable, must not crash.
        assert optimized
        assert "SELECT" in optimized.upper()
        assert "FROM" in optimized.upper()
        # Preserves the data source schema.
        assert "oncludeschema" in optimized.lower()

    def test_optimization_failure_returns_original(self, tmp_path):
        """Even if sqlglot can't optimize (parse failure mid-pass),
        the original SQL must come back untouched."""
        step = _make_step(tmp_path)
        # Force the path even when sqlglot is absent.
        sql = "SELECT * FROM t"
        optimized, info = step._optimize_composed_sql(sql, "CLOUD")
        assert optimized == sql or len(optimized) > 0

    def test_optimization_opt_out_via_polling_row(self, tmp_path):
        """disable_sql_optimization=true on polling row -> no
        rewriting, raw composed SQL goes into JSON."""
        from steps.file.generate_sql import _SQLGLOT_AVAILABLE
        if not _SQLGLOT_AVAILABLE:
            pytest.skip("sqlglot not installed")
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path, disable_sql_optimization="true")
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        # _opt_info_by_source should be empty (optimization skipped).
        assert step._opt_info_by_source == {}

    def test_sql_hash_reaches_run_report(self, tmp_path):
        """sql_hash_<datasource> must land in run_report.runtime_knobs."""
        from steps.file.run_report import FileRunReport
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        rr = FileRunReport(output_dir=str(tmp_path))
        task = _make_task(tmp_path, _run_report=rr)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        # Both data sources should have a hash key.
        assert "sql_hash_CLOUD" in rr.runtime_knobs
        assert "sql_hash_ONPREM" in rr.runtime_knobs
        assert len(rr.runtime_knobs["sql_hash_CLOUD"]) == 12

    def test_batched_fetch_is_single_round_trip(self, tmp_path):
        """Batched IN-list fetch should make ONE query per metadata table,
        not N per data source.  Counts cursor.execute calls."""
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        # Count how many times each metadata table was queried.
        sqls = [str(call.args[0]) for call in cursor.execute.call_args_list]
        details_calls = [s for s in sqls if "OTG_DATA_SOURCE_DETAILS" in s]
        table_calls = [s for s in sqls if "OTG_DATA_SOURCE_TABLE_MAPPING" in s]
        # Exactly 1 batched call each, NOT 2 per data source.
        assert len(details_calls) == 1, f"Expected 1 batched details call, got {len(details_calls)}"
        assert len(table_calls) == 1, f"Expected 1 batched table call, got {len(table_calls)}"
        # Verify it's the IN-list shape.
        assert "IN (" in details_calls[0]
        assert "IN (" in table_calls[0]


class TestAggFlag:
    """Phase 152 explicit AGG_FLAG column with substring fallback."""

    def test_legacy_substring_fallback_when_agg_flag_is_none(self, tmp_path):
        """Pre-migration rows have 4-tuple shape (no AGG_FLAG).  The
        substring check on source_table still triggers GROUP BY."""
        step = _make_step(tmp_path)
        components = step._build_sql_components(
            columns=[
                ("col1", "Acct", 1, "fact"),       # not AGG -> goes to GROUP BY
                ("SUM(col2)", "Amt", 2, "AGG"),    # legacy AGG -> aggregation
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        assert components["group_by_flag"] == "Y"

    def test_explicit_agg_flag_y_triggers_aggregation(self, tmp_path):
        """5-tuple with AGG_FLAG='Y' triggers GROUP BY regardless of
        source_table substring."""
        step = _make_step(tmp_path)
        components = step._build_sql_components(
            columns=[
                ("col1", "Acct", 1, "fact", "N"),
                # source_table doesn't contain 'AGG' but AGG_FLAG='Y'.
                ("SUM(col2)", "Amt", 2, "fact_table", "Y"),
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        assert components["group_by_flag"] == "Y"

    def test_explicit_agg_flag_n_prevents_false_positive(self, tmp_path):
        """source_table='STORAGE_AGGREGATE' would FALSELY trigger
        legacy substring match.  AGG_FLAG='N' overrides correctly."""
        step = _make_step(tmp_path)
        components = step._build_sql_components(
            columns=[
                # source_table contains 'AGG' but AGG_FLAG='N'.
                ("col1", "Acct", 1, "STORAGE_AGGREGATE", "N"),
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        assert components["group_by_flag"] == "N"

    @pytest.mark.parametrize("agg_flag_value", [
        "",            # DEFAULT '' after migration -- common
        "  ",          # whitespace-only cell
        "NULL",        # literal-NULL string written by some Oracle imports
        " Y ",         # paste-from-spreadsheet padding
    ])
    def test_unactionable_agg_flag_falls_back_to_substring(
        self, tmp_path, agg_flag_value,
    ):
        """2026-06-21 deep-dive bug #3: empty / whitespace / 'NULL' /
        padded AGG_FLAG values must NOT bypass the legacy substring
        fallback -- otherwise a source_table='AGG_*' that previously
        triggered GROUP BY silently regresses on column migration."""
        step = _make_step(tmp_path)
        components = step._build_sql_components(
            columns=[
                ("SUM(amt)", "Amt", 1, "AGG_SUMS", agg_flag_value),
            ],
            params=[("FROM_TABLE", "fact f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        # ' Y ' DOES become actionable after strip+upper; the other
        # 3 values are non-actionable and fall back to substring (Y).
        if agg_flag_value.strip().upper() == "Y":
            expected = "Y"
        else:
            # Non-actionable -- substring fallback on 'AGG_SUMS' triggers.
            expected = "Y"
        assert components["group_by_flag"] == expected, (
            f"AGG_FLAG={agg_flag_value!r} regressed GROUP BY behavior"
        )

    def test_padded_y_value_actionable_after_strip(self, tmp_path):
        """' Y ' after strip+upper IS actionable; substring fallback
        doesn't fire even on source_table=fact."""
        step = _make_step(tmp_path)
        components = step._build_sql_components(
            columns=[
                ("SUM(amt)", "Amt", 1, "fact", " Y "),
            ],
            params=[("FROM_TABLE", "fact f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        assert components["group_by_flag"] == "Y"


class TestModuleLevelRegex:
    """Hygiene -- _FROM_TABLE_RE is compiled once at module load."""

    def test_from_table_re_exists_module_level(self):
        from steps.file.generate_sql import _FROM_TABLE_RE
        import re as _re
        assert isinstance(_FROM_TABLE_RE, _re.Pattern)
        # Verify it matches the {from_table} <alias> pattern.
        m = _FROM_TABLE_RE.search("WHERE x = 1 AND {from_table} fact JOIN ...")
        assert m is not None
        assert m.group(1) == "fact"


class TestMetadataCache:
    """Cross-step reuse: GenerateSQL publishes the per-source
    metadata dict on task['_metadata_cache'] so downstream steps
    (RowCountCheck, CTL writer, send_email) can lookup without a
    second Oracle hit."""

    def test_cache_populated_after_compose(self, tmp_path):
        step = _make_step(tmp_path)
        cursor = _build_cursor()
        task = _make_task(tmp_path)
        with patch.object(step, "_get_database_connection") as mock_conn:
            mock_conn.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, "", "", "GenerateSQL"))
        assert "_metadata_cache" in task
        cache = task["_metadata_cache"]
        assert "report:1001:CLOUD" in cache
        assert "report:1001:ONPREM" in cache
        # Cached entries carry the full metadata dict.
        assert cache["report:1001:CLOUD"]["server_name"] == "claude"

    def test_cache_get_helper_returns_none_on_miss(self):
        from steps.file.generate_sql import GenerateSQL
        # Missing cache -> None
        assert GenerateSQL.metadata_cache_get({}, "report:99:X") is None
        # Wrong type in cache -> None (defensive)
        assert GenerateSQL.metadata_cache_get(
            {"_metadata_cache": "not_a_dict"}, "report:99:X",
        ) is None
        # Cache present, key missing -> None
        assert GenerateSQL.metadata_cache_get(
            {"_metadata_cache": {}}, "report:99:X",
        ) is None

    def test_cache_get_helper_returns_entry_on_hit(self):
        from steps.file.generate_sql import GenerateSQL
        task = {"_metadata_cache": {"report:1:X": {"server_name": "host"}}}
        result = GenerateSQL.metadata_cache_get(task, "report:1:X")
        assert result == {"server_name": "host"}


class TestNoExecutorWrap:
    """fetch_report_metadata used to wrap a sync call in
    loop.run_in_executor -- async-shape with zero parallelism.
    Removed 2026-06-21; coroutine still awaits cleanly."""

    def test_fetch_report_metadata_is_still_coroutine(self):
        """BaseStep.execute awaits this, so it MUST remain async."""
        import inspect
        from steps.file.generate_sql import GenerateSQL
        assert inspect.iscoroutinefunction(GenerateSQL.fetch_report_metadata)

    def test_no_run_in_executor_call(self):
        """Sanity grep: the run_in_executor() call site is gone.
        Looks for the call, not the word (docstring may mention it)."""
        import inspect
        from steps.file.generate_sql import GenerateSQL
        src = inspect.getsource(GenerateSQL.fetch_report_metadata)
        # Strip docstring before checking -- the docstring legitimately
        # mentions the old run_in_executor wrap that was removed.
        body = src.split('"""', 2)[-1] if src.count('"""') >= 2 else src
        assert "run_in_executor(" not in body
        assert "loop.run_in_executor" not in body


class TestLoadOracleConfigRoute:
    """2026-06-21 deep-dive bug #11: original Prd_generate_sql.py
    hardcoded the prod Spark-pod path ``/usr/local/spark/pvc/code/...``
    as the default for load_oracle_config.  Broken on Windows / CI /
    local / any env that doesn't mount /usr/local/spark.
    Fix: delegate to oracle_config_loader (same pattern file_standalone
    uses) which handles prod -> local fallback."""

    def test_default_path_uses_canonical_loader(self, tmp_path):
        """No config_path arg -> delegates to oracle_config_loader.
        That loader tries prod first, falls back to ETL/configs/."""
        from steps.file.generate_sql import GenerateSQL

        sample = {"user": "u", "password": "p", "dsn": "h/s"}
        # Build a step instance whose __init__ uses our mocked load.
        with patch.object(
            GenerateSQL, "load_oracle_config", return_value=sample,
        ):
            step = GenerateSQL(
                starburst_clients={}, oracle_data_manager=None,
                logger=MagicMock(), config={},
            )
        # Now exercise the REAL method via canonical loader patch.
        with patch(
            "oracle_config_loader.load_shared_oracle_config",
            return_value=sample,
        ):
            result = step.load_oracle_config(config_path=None)
        assert result == sample

    def test_explicit_path_still_honored(self, tmp_path):
        """Back-compat: callers passing config_path explicitly still
        get the YAML loaded from that path."""
        from steps.file.generate_sql import GenerateSQL

        cfg = tmp_path / "oracle_config.yaml"
        cfg.write_text(
            "oracle:\n  user: explicit_u\n  password: explicit_p\n  dsn: h/s\n",
            encoding="utf-8",
        )
        step = _make_step(tmp_path)
        result = GenerateSQL.load_oracle_config(step, config_path=str(cfg))
        assert result == {"user": "explicit_u", "password": "explicit_p", "dsn": "h/s"}

    def test_no_hardcoded_prod_path_in_signature(self):
        """Sanity grep: the broken default ('/usr/local/spark/...') is gone.
        Default must be None so the canonical loader fallback engages."""
        import inspect
        from steps.file.generate_sql import GenerateSQL
        sig = inspect.signature(GenerateSQL.load_oracle_config)
        assert sig.parameters["config_path"].default is None, (
            "config_path default must be None to engage the canonical "
            "loader's prod->local fallback. A hardcoded prod path "
            "breaks the composer on every non-prod env."
        )


class TestDuplicateDataSourceDedup:
    """2026-06-21 deep-dive bug #10: duplicate rows in
    OTG_REPORT_DATA_SOURCE_MAPPING (accidental double-insert) used to
    produce N identical job entries with the SAME output_file_name --
    extract step would race-write to the same file = corruption.
    Composer now dedups by data_source_id with a WARN."""

    def test_duplicate_data_sources_dedup(self, tmp_path):
        step = _make_step(tmp_path)
        # Custom cursor that returns 3 duplicate rows for the same ds_id.
        from unittest.mock import MagicMock
        cursor = MagicMock()
        state = {'sql': '', 'binds': {}}

        def _exec(sql, binds=None):
            state['sql'] = sql; state['binds'] = binds or {}
        def _fetchone():
            sql = state['sql']
            if 'OTG_AIRFLOW_DAG_RUN' in sql: return ('20260131',)
            if 'OTG_REPORT_CONFIG' in sql:
                return (1001, 'dat', 'f', '|', '/tmp/', 'CT', 'false')
            return None
        def _fetchall():
            sql = state['sql']; binds = state['binds']
            if 'OTG_REPORT_DATA_SOURCE_MAPPING' in sql:
                return [(1001, 'ds_1'), (1001, 'ds_1'), (1001, 'ds_1')]
            if 'OTG_DATA_SOURCE_DETAILS' in sql and 'IN (' in sql:
                return [('ds_1', 'CLOUD', 'h', 8443)]
            if 'OTG_DATA_SOURCE_TABLE_MAPPING' in sql and 'IN (' in sql:
                return [('ds_1', 'oncluedschema.fact', 't1')]
            if 'OTG_REPORT_COLUMN_MAPPING' in sql:
                return [('*', '*', 1, 't1', 'N')]
            if 'OTG_REPORT_PARAM_CONFIG' in sql:
                return [('FROM_TABLE', '{{t1}}')]
            if 'OTG_CONTROL_TEMPLATE' in sql:
                return [('CT', 'File_Name,{file_name}')]
            return []
        cursor.execute.side_effect = _exec
        cursor.fetchone.side_effect = _fetchone
        cursor.fetchall.side_effect = _fetchall

        task = _make_task(tmp_path)
        with patch.object(step, '_get_database_connection') as mc:
            mc.return_value.__enter__.return_value.cursor.return_value\
                .__enter__.return_value = cursor
            asyncio.run(step._execute_step(task, '', '', 'GenerateSQL'))

        with open(task['sql_query_path'], encoding='utf-8') as f:
            doc = json.load(f)
        # 3 duplicates -> 1 unique entry after dedup.
        assert len(doc['jobs']) == 1
        assert doc['jobs'][0]['datasource_name'] == 'CLOUD'


class TestCryptricCrashFixes:
    """2026-06-21 deep-dive bugs #7, #8, #9 -- pre-existing crashes in
    Prd_generate_sql.py that produced confusing error messages.  Now
    converted to clear, actionable fail-loud errors at compose time
    pointing at the misconfigured Oracle metadata row."""

    def test_null_operation_value_in_filter_skipped_with_warn(self, tmp_path):
        """Bug #8: NULL OPERATION_VALUE used to crash with cryptic
        AttributeError.  Now: skipped with WARN; other params still process."""
        step = _make_step(tmp_path)
        c = step._build_sql_components(
            columns=[("a", "A", 1, "fact", "N")],
            params=[
                ("FILTER1", None),                          # NULL -> skipped
                ("FILTER2", "a = 1"),                       # processed
                ("FROM_TABLE", "fact_table f"),
            ],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        # Other params processed; bad one skipped silently.
        assert c["where_clauses"] == ["a = 1"]
        assert c["from_table_name"] == "fact_table f"

    def test_missing_from_table_raises_clearly(self, tmp_path):
        """Bug #7: missing FROM_TABLE used to emit dangling SELECT...FROM.
        Now: fail-loud with a message pointing at the metadata row."""
        step = _make_step(tmp_path)
        with pytest.raises(RuntimeError) as exc_info:
            step._build_sql_components(
                columns=[("a", "A", 1, "fact", "N")],
                params=[("FILTER1", "x = 1")],   # no FROM_TABLE
                business_date_formatted="2025-08-31",
                system_entity="",
                job_type="FILE",
            )
        msg = str(exc_info.value)
        assert "FROM_TABLE" in msg
        assert "OTG_REPORT_PARAM_CONFIG" in msg

    def test_null_source_table_raises_clearly(self, tmp_path):
        """Bug #9: NULL SOURCE_TABLE on plain (non-AGG/non-EXPRESSION)
        column used to compose 'None.col'.  Now: fail-loud with the
        SEQ + target_column so operator finds the bad row instantly."""
        step = _make_step(tmp_path)
        with pytest.raises(RuntimeError) as exc_info:
            step._build_sql_components(
                columns=[
                    ("the_col", "MyAcct", 42, None, "N"),  # NULL source_table
                ],
                params=[("FROM_TABLE", "fact_table f")],
                business_date_formatted="2025-08-31",
                system_entity="",
                job_type="FILE",
            )
        msg = str(exc_info.value)
        assert "SEQ=42" in msg
        assert "MyAcct" in msg
        assert "SOURCE_TABLE" in msg

    def test_null_source_table_on_expression_column_is_fine(self, tmp_path):
        """EXPRESSION columns explicitly mark as not-source-tied, so
        a NULL source_table would otherwise hit the plain-column path.
        Verify EXPRESSION marker takes precedence over null check."""
        step = _make_step(tmp_path)
        # source_table='EXPRESSION' takes the expression branch -- no crash.
        c = step._build_sql_components(
            columns=[
                ("CURRENT_DATE", "Today", 1, "EXPRESSION", "N"),
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        sql = step._generate_sql(c)
        assert "CURRENT_DATE" in sql


class TestAllAggregationReport:
    """2026-06-21 deep-dive bug #6: all-AGG reports (no plain columns)
    used to emit ``GROUP BY `` (dangling, empty).  Trino rejects.
    Fix: skip GROUP BY entirely when group_by_columns is empty even
    if group_by_flag='Y' (pure-aggregation query)."""

    def test_all_agg_columns_omits_group_by(self, tmp_path):
        step = _make_step(tmp_path)
        c = step._build_sql_components(
            columns=[
                ("SUM(amt)", "TotalAmt", 1, "fact", "Y"),
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        sql = step._generate_sql(c)
        # Pure-aggregation query: no GROUP BY clause at all.
        assert "GROUP BY" not in sql, (
            f"Pure-aggregation should not emit GROUP BY: {sql!r}"
        )

    def test_mixed_agg_and_plain_still_groups_by_plain(self, tmp_path):
        """When SOME columns are plain (non-AGG), GROUP BY is emitted
        for those columns -- standard behavior preserved."""
        step = _make_step(tmp_path)
        c = step._build_sql_components(
            columns=[
                ("acct", "Acct", 1, "fact", "N"),       # plain -> goes into GROUP BY
                ("SUM(amt)", "TotalAmt", 2, "fact", "Y"),  # AGG
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        sql = step._generate_sql(c)
        assert "GROUP BY fact.acct" in sql, (
            f"Mixed agg+plain should still GROUP BY plain cols: {sql!r}"
        )

    def test_all_plain_no_group_by(self, tmp_path):
        """No AGG columns at all -> no GROUP BY clause."""
        step = _make_step(tmp_path)
        c = step._build_sql_components(
            columns=[
                ("acct", "Acct", 1, "fact", "N"),
                ("amt", "Amt", 2, "fact", "N"),
            ],
            params=[("FROM_TABLE", "fact_table f")],
            business_date_formatted="2025-08-31",
            system_entity="",
            job_type="FILE",
        )
        sql = step._generate_sql(c)
        assert "GROUP BY" not in sql


class TestCobPrevEoqPlaceholder:
    """2026-06-21 deep-dive bug #5: ${COB_PREV_EOQ(YYYYMMDD)} was dead
    code in Prd_generate_sql.py.  Chain replace stripped it BEFORE the
    conditional substitution checked for it.  Operators using the
    placeholder silently got business_date instead of prev-quarter-end.
    Fixed: prev_quarter_end computed upfront, used directly in chain."""

    def test_cob_prev_eoq_resolves_to_prev_quarter_end_in_filename(self, tmp_path):
        step = _make_step(tmp_path)
        cleaned, _ = step._format_file_names(
            file_name="report_${COB_PREV_EOQ(YYYYMMDD)}.dat",
            file_format="dat",
            ctl_file_format="",
            business_date="20250831",  # Aug 2025 (Q3) -> prev quarter end = 20250630
            run_date="20260131",
            datasource_name="CLOUD",
        )
        # business_date Aug 31, 2025 -> previous quarter end = June 30, 2025
        assert "20250630" in cleaned, f"prev-quarter-end not substituted: {cleaned}"
        # And NOT the business_date (the old broken behavior).
        assert "20250831" not in cleaned.replace("_CLOUD", ""), (
            f"placeholder fell back to business_date (regression): {cleaned}"
        )

    def test_cob_prev_eoq_resolves_to_prev_quarter_end_in_ctl(self, tmp_path):
        step = _make_step(tmp_path)
        _, ctl = step._format_file_names(
            file_name="report.dat",
            file_format="dat",
            ctl_file_format=("File_Name,{file_name}\n"
                             "Quarter_End,${COB_PREV_EOQ(YYYYMMDD)}\n"),
            business_date="20250831",
            run_date="20260131",
            datasource_name="CLOUD",
        )
        assert "Quarter_End,20250630" in ctl, (
            f"CTL placeholder not substituted: {ctl}"
        )

    @pytest.mark.parametrize("business_date,expected_prev_q_end", [
        ("20250215", "20241231"),  # Q1 2025 -> Q4 2024 end
        ("20250515", "20250331"),  # Q2 2025 -> Q1 2025 end
        ("20250815", "20250630"),  # Q3 2025 -> Q2 2025 end
        ("20251115", "20250930"),  # Q4 2025 -> Q3 2025 end
    ])
    def test_prev_quarter_end_per_quarter(
        self, tmp_path, business_date, expected_prev_q_end,
    ):
        step = _make_step(tmp_path)
        cleaned, _ = step._format_file_names(
            file_name="r_${COB_PREV_EOQ(YYYYMMDD)}.dat",
            file_format="dat",
            ctl_file_format="",
            business_date=business_date,
            run_date="20260131",
            datasource_name="X",
        )
        assert expected_prev_q_end in cleaned, (
            f"biz_date={business_date} expected prev_q={expected_prev_q_end}, "
            f"got: {cleaned}"
        )


class TestQueryPlanCapture:
    """OPT-IN EXPLAIN-capture: zero perf impact when off (default);
    surfaces stage/partition/join shape to FileRunReport when on.
    Lives on StarburstFileBase, not GenerateSQL, since it uses the
    Trino connection that the extract step opens."""

    def test_summarize_query_plan_shape(self):
        """Plan summary lines extract the key metrics from EXPLAIN
        output regardless of whether all fields are present."""
        from steps.file.starburst_file_base import StarburstFileBase
        plan = (
            "Fragment 0 [SINGLE]\n"
            "  Output[]\n"
            "    Project\n"
            "      ScanFilterAndProject[table=iceberg.fact, "
            "splits=42, predicate = [cob_date = '2025-08-31']]\n"
            "Fragment 1 [HASH]\n"
            "  RemoteSource\n"
        )
        summary = StarburstFileBase._summarize_query_plan(plan, elapsed_ms=120)
        assert "2 stages" in summary
        assert "42 splits/partitions" in summary
        assert "partitioned" in summary
        assert "filter_pushdown=YES" in summary
        assert "EXPLAIN took 120ms" in summary

    def test_summarize_handles_missing_markers(self):
        """No splits, no join markers, no filter pushdown -- still
        produces a one-liner with 'n/a' placeholders."""
        from steps.file.starburst_file_base import StarburstFileBase
        plan = "Fragment 0\n  Output\n"
        summary = StarburstFileBase._summarize_query_plan(plan, elapsed_ms=50)
        assert "1 stages" in summary
        assert "n/a splits" in summary
        assert "join=n/a" in summary
        assert "filter_pushdown=no" in summary

    def test_summarize_detects_broadcast_join(self):
        from steps.file.starburst_file_base import StarburstFileBase
        plan = (
            "Fragment 0\n  LocalExchange[REPLICATED]\n"
            "    ScanFilter[table=t1, predicate = [...]]\n"
        )
        summary = StarburstFileBase._summarize_query_plan(plan, elapsed_ms=80)
        assert "join=broadcast" in summary
        assert "filter_pushdown=YES" in summary


class TestTruthyCoercion:
    @pytest.mark.parametrize("v,expected", [
        (True, True), (False, False),
        ("true", True), ("TRUE", True), ("True", True),
        ("1", True), (1, True),
        ("yes", True), ("y", True), ("Y", True),
        (None, False), ("", False), ("0", False),
        ("false", False), ("no", False), ("n", False),
        (0, False),
    ])
    def test_truthy(self, v, expected):
        from steps.file.generate_sql import _truthy
        assert _truthy(v) is expected


# ──────────────────────────────────────────────────────────────────────
#  Atomic-write parent-directory creation (2026-06-22 -- prod blocker)
# ──────────────────────────────────────────────────────────────────────


class TestAtomicWriteCreatesParentDir:
    """Operator hit ``[Errno 2] No such file or directory:
    '/usr/local/spark/nfs/bcp/queryjson/FLEX_GSIB_SAP_MONTHEND_V4.json.tmp'``
    because the parent directory didn't exist on the pod when
    GenerateSql tried the atomic-write ``open(tmp, 'w')``.

    Fix locks: write site MUST ``os.makedirs(dirname, exist_ok=True)``
    before opening the ``.tmp`` file.
    """

    def test_writes_when_parent_dir_missing(self, tmp_path):
        """Atomic write succeeds even when the target parent directory
        does not exist yet -- ``os.makedirs(..., exist_ok=True)`` runs
        before ``open(tmp, 'w')``."""
        import os
        import json
        import sys
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

        # Deliberately use a nested non-existent parent dir.
        target_dir = tmp_path / "nested" / "missing" / "dirs"
        target_path = target_dir / "out.json"
        assert not target_dir.exists()

        # Inline the atomic-write contract from generate_sql.py:1340-...
        # (mirroring the production code shape so a future regression
        # of the pattern -- e.g., someone reverting the makedirs -- is
        # caught by this test).
        from steps.file import generate_sql as gs_mod
        source = (
            os.path.dirname(os.path.abspath(gs_mod.__file__))
            + os.sep + "generate_sql.py"
        )
        with open(source, "r", encoding="utf-8") as f:
            src = f.read()
        # The fix marker -- guard against silent regression.
        assert "os.makedirs(output_dir, exist_ok=True)" in src, (
            "GenerateSql atomic-write MUST call os.makedirs on the "
            "parent dir of output_file BEFORE opening the .tmp file. "
            "Operator hit ENOENT on queryjson/ folder otherwise."
        )

        # Replicate the actual write path with the fix applied.
        output_dir = str(target_dir)
        os.makedirs(output_dir, exist_ok=True)
        tmp = str(target_path) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"jobs": [{"x": 1}]}, f)
        os.replace(tmp, str(target_path))
        assert target_path.exists()
        with open(target_path) as f:
            assert json.load(f) == {"jobs": [{"x": 1}]}

    def test_makedirs_error_message_actionable(self, tmp_path):
        """When makedirs itself fails (permission denied / read-only
        FS), the wrapping RuntimeError mentions the path + operator
        action so the failure is self-explanatory."""
        import os
        import sys
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from steps.file import generate_sql as gs_mod

        # Source-level lock: the error message must mention the path
        # and the operator's next step.  Operators run on OpenShift
        # where ``/usr/local/spark/nfs/...`` failures are common; the
        # error has to point at the right thing.
        source = (
            os.path.dirname(os.path.abspath(gs_mod.__file__))
            + os.sep + "generate_sql.py"
        )
        with open(source, "r", encoding="utf-8") as f:
            src = f.read()
        assert "cannot create parent directory" in src
        assert "polling-row" in src
        assert "sql_query_path" in src
