"""Phase F (2026-06-08) — ETL supplement freshness gate tests.

Verifies the IcebergSupplementReader.is_fresh() method that gates
whether ETL trusts the supplement bounds vs falling back to Spark+
Iceberg's native pruning when stale.
"""
from __future__ import annotations

import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from managers.iceberg_supplement_reader import (
    DEFAULT_MAX_AGE_SECONDS,
    IcebergSupplementReader,
)


def _make_reader(conn="user/pw@dsn", bucket="b", prefix="t/", snap="snap-1"):
    return IcebergSupplementReader(
        connection_string=conn,
        bucket=bucket,
        table_prefix=prefix,
        snapshot_id=snap,
    )


def _fake_oracledb(scalar_value):
    """Build a stub oracledb module whose connect() returns a conn
    whose cursor().execute() makes fetchone() return (scalar_value,)."""
    cur = MagicMock()
    cur.fetchone.return_value = (scalar_value,)
    cur.__enter__ = lambda self: cur
    cur.__exit__ = lambda self, *a: False
    conn = MagicMock()
    conn.cursor.return_value = cur
    conn.__enter__ = lambda self: conn
    conn.__exit__ = lambda self, *a: False
    mod = MagicMock()
    mod.connect.return_value = conn
    return mod, cur


class TestFreshness(unittest.TestCase):
    def test_fresh_when_recent(self):
        recent = datetime.now(timezone.utc) - timedelta(seconds=30)
        mod, _cur = _fake_oracledb(recent)
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            self.assertTrue(reader.is_fresh(max_age_seconds=3600))

    def test_stale_when_old(self):
        old = datetime.now(timezone.utc) - timedelta(hours=5)
        mod, _cur = _fake_oracledb(old)
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            self.assertFalse(reader.is_fresh(max_age_seconds=3600))

    def test_not_fresh_when_no_rows(self):
        mod, _cur = _fake_oracledb(None)
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            self.assertFalse(reader.is_fresh())

    def test_naive_utc_normalised(self):
        # Oracle commonly returns naive datetime — module must treat
        # as UTC, not local.
        naive_recent = (
            datetime.now(timezone.utc) - timedelta(seconds=10)
        ).replace(tzinfo=None)
        mod, _cur = _fake_oracledb(naive_recent)
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            self.assertTrue(reader.is_fresh(max_age_seconds=3600))

    def test_fail_open_on_db_exception(self):
        mod = MagicMock()
        mod.connect.side_effect = RuntimeError("ORA-12545")
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            self.assertFalse(reader.is_fresh())

    def test_decision_cached_per_reader(self):
        recent = datetime.now(timezone.utc) - timedelta(seconds=10)
        mod, cur = _fake_oracledb(recent)
        reader = _make_reader()
        with patch.dict("sys.modules", {"oracledb": mod}):
            reader.is_fresh()
            reader.is_fresh()
            reader.is_fresh()
        # Only one DB roundtrip — cached after first call.
        self.assertEqual(cur.execute.call_count, 1)

    def test_empty_config_returns_false(self):
        reader = IcebergSupplementReader(
            connection_string="", bucket="", table_prefix="",
            snapshot_id="",
        )
        self.assertFalse(reader.is_fresh())

    def test_default_max_age_is_one_hour(self):
        self.assertEqual(DEFAULT_MAX_AGE_SECONDS, 3600)


if __name__ == "__main__":
    unittest.main()
