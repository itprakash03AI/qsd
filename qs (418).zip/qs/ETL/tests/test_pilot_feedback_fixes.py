"""Regression tests for the 4 issues found during the 2026-06-20 pilot.

Each test pins ONE user-reported issue so it can't silently regress:

  1. "no partition_column configured" message when operator DID configure
     one (probe didn't run because no checksum_columns).
  2. batch_size regression: 5.6M-row job went 7 min -> 9 min because
     AutoPlan picked 26K (5MB target / 200B rows) -- below legacy 100K
     default.
  3. C4 chip "0 of 9 chunks match" displayed as FAIL when C3 cumulative
     count was correct (5,634,098 rows).  Per-chunk discovery vs extract
     drift is benign when total reconciles.
  4. .dat ctime != mtime on Windows -- final merged file inherited
     stale ctime from a same-named file via NTFS file-name tunneling.
     Downstream consumers got confused.
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  Issue 1: AutoPlan must honour partition_column even when probe didn't run
# ──────────────────────────────────────────────────────────────────────


class TestIssue1PartitionColumnHonoured:
    """User saw: 'autoplan_mode = single -- no partition_column configured'
    when the polling row DID set partition_column.  Root cause: probe
    didn't run (no checksum_columns), so partition_cardinality=0 made
    AutoPlan think partition_column was empty.  Fix: thread the
    partition_column flag through build_inputs_from_probe."""

    def test_partition_column_in_job_config_changes_mode(self):
        from steps.file.autoplan import autoplan, build_inputs_from_probe
        # No probe result (operator didn't set checksum_columns) but
        # partition_config.partition_column IS set on the job.
        job_config = {
            "partition_config": {"partition_column": "region"},
        }
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=5_634_098, job_config=job_config,
        )
        assert inp.partition_column_configured is True
        out = autoplan(inp)
        assert out.mode == "partition_values"
        mode_dec = next(d for d in out.decisions if d.knob == "mode")
        assert "partition_column configured" in mode_dec.reason

    def test_partition_column_at_top_level_also_works(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={"partition_column": "region"},
        )
        assert inp.partition_column_configured is True

    def test_truly_no_partition_column_still_picks_single(self):
        from steps.file.autoplan import autoplan, build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000, job_config={},
        )
        assert inp.partition_column_configured is False
        out = autoplan(inp)
        assert out.mode == "single"
        mode_dec = next(d for d in out.decisions if d.knob == "mode")
        assert "no partition_column configured" in mode_dec.reason


# ──────────────────────────────────────────────────────────────────────
#  Issue 2: batch_size regression -- floor must be >= legacy 100K
# ──────────────────────────────────────────────────────────────────────


class TestIssue2BatchSizeFloor:
    """User saw: 5.6M-row job went 7 min -> 9 min after Phase 152.  Root
    cause: AutoPlan's 5 MB target gave batch_size=26K for 200-B rows,
    which is SMALLER than the legacy 100K default -- 4x more fetchmany
    round trips on the same data.  Fix: raise floor to 100K (legacy
    default) so we never regress."""

    def test_batch_size_floor_is_legacy_default(self):
        from steps.file.autoplan import autoplan
        from steps.file.autoplan import AutoPlanInputs
        # 200-byte rows (the regression case).
        inp = AutoPlanInputs(
            total_rows=5_634_098,
            partition_cardinality=9,
            max_partition_rows=700_000,
            avg_partition_rows=626_000,
            avg_row_bytes=200,
            cpu_cores=8,
            available_memory_bytes=8 * 1024**3,
        )
        out = autoplan(inp)
        # Must NOT be < legacy 100K default.
        assert out.batch_size >= 100_000

    def test_batch_size_target_is_20mb(self):
        """20 MB target / 200 B row -> 104K (just above floor)."""
        from steps.file.autoplan import autoplan, AutoPlanInputs
        inp = AutoPlanInputs(
            total_rows=1_000_000, avg_row_bytes=200,
        )
        out = autoplan(inp)
        # ~104K is target; floor 100K guarantees no regression.
        assert 100_000 <= out.batch_size <= 110_000

    def test_narrow_rows_can_still_grow_above_floor(self):
        """50-B rows -> 20MB/50 = 400K -> within ceiling."""
        from steps.file.autoplan import autoplan, AutoPlanInputs
        inp = AutoPlanInputs(
            total_rows=1_000_000, avg_row_bytes=50,
        )
        out = autoplan(inp)
        assert out.batch_size >= 100_000

    def test_operator_override_still_wins(self):
        from steps.file.autoplan import autoplan, AutoPlanInputs
        inp = AutoPlanInputs(
            total_rows=1_000_000, avg_row_bytes=200,
            override_batch_size=50_000,  # operator explicitly picks smaller
        )
        out = autoplan(inp)
        assert out.batch_size == 50_000


# ──────────────────────────────────────────────────────────────────────
#  Issue 3: C4 chip should be advisory when C3 cumulative matches G1
# ──────────────────────────────────────────────────────────────────────


class TestIssue3C4AdvisoryByDefault:
    """User saw: '0 of 9 chunks match' displayed as FAIL even though the
    cumulative row count was correct (5,634,098).  Per-chunk discovery
    counts can legitimately differ from extract (source snapshot drift,
    DISTINCT/GROUP BY in base_sql).  When C3 cumulative anchor matches
    G1, the run produced correct data -- C4 chip is informational."""

    def test_c4_advisory_ok_when_all_chunks_mismatch_but_c3_passes(self):
        """The exact pilot scenario: 9 chunks all mismatching but
        cumulative count is correct."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_counts(
            expected_total=5_634_098,
            sum_chunk_actual=5_634_098,  # C3 anchor matches G1
            consolidated_total=5_634_098,
        )
        # 9 chunks each off by some amount, but they sum to the right total.
        per_chunk_expected = 5_634_098 // 9
        per_chunk_extract_delta = [+10, -20, +5, -3, +15, -7, -2, +1, +1]
        # Sum of deltas = 0 by construction.
        for i, d in enumerate(per_chunk_extract_delta):
            rr.add_chunk_result({
                "expected": per_chunk_expected,
                "actual": per_chunk_expected + d,
            })
        ledger = rr._ledger_entries()
        c4 = next(e for e in ledger if e["control"] == "G4")
        # All 9 chunks "mismatch" but C4 should advisory-OK by default.
        assert c4["ok"] is True
        assert "ADVISORY" in c4["detail"]

    def test_c4_default_is_unlimited(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        # Default sentinel is -1 (unlimited tolerance).
        assert rr.c4_advisory_net_delta_max == -1

    def test_c4_strict_override_restores_pre_fix_behaviour(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x", c4_advisory_net_delta_max=0)
        rr.set_counts(
            expected_total=100,
            sum_chunk_actual=100,
            consolidated_total=100,
        )
        rr.add_chunk_result({"expected": 60, "actual": 61})
        rr.add_chunk_result({"expected": 40, "actual": 38})  # net -1
        ledger = rr._ledger_entries()
        c4 = next(e for e in ledger if e["control"] == "G4")
        # Net delta = +1 + (-2) = -1, exceeds strict 0 cap -> FAIL.
        assert c4["ok"] is False


# ──────────────────────────────────────────────────────────────────────
#  Issue 4: .dat ctime fix on cross-source merged file
# ──────────────────────────────────────────────────────────────────────


class TestIssue4DatFileCtimeFix:
    """User saw: final .dat ctime didn't match mtime.  Downstream
    consumers (file-arrival watchers) inferred stale arrival time.
    Root cause: per-source consolidated files got force_creation_time_now
    but the FINAL cross-source merged file did not.  Fix: call
    force_creation_time_now in merge_files.py after os.replace."""

    def test_merge_files_calls_force_creation_time_now(self):
        """The fix is a code-level addition -- this test confirms the
        helper is imported + called in the merge_files completion path.
        Behavioural test (actual ctime match) would need Windows + same-
        named pre-existing file to reproduce tunneling, which CI doesn't
        easily provide.  Symbolic check ensures the call exists."""
        import inspect
        from steps.file import merge_files
        src = inspect.getsource(merge_files)
        # The function imports + calls force_creation_time_now after
        # os.replace.  Both substrings must appear post-Phase-152.
        assert "force_creation_time_now" in src, (
            "merge_files.py must call force_creation_time_now on the "
            "final cross-source merged file to defeat NTFS tunneling"
        )
        assert "from steps.file.run_state import force_creation_time_now" in src

    def test_force_creation_time_now_is_noop_on_posix(self, tmp_path):
        """Helper must NOT raise on POSIX.  Returns True (no-fix-needed)."""
        from steps.file.run_state import force_creation_time_now
        f = tmp_path / "test.dat"
        f.write_text("hello\n")
        # On POSIX returns True immediately; on Windows attempts SetFileTime.
        result = force_creation_time_now(str(f))
        assert result is True or result is False  # boolean either way; doesn't raise


# ──────────────────────────────────────────────────────────────────────
#  Inline runtime-knob docs (so operators don't need to grep code)
# ──────────────────────────────────────────────────────────────────────


class TestRuntimeKnobDocsInline:
    """Every runtime knob the planner emits should have inline help in
    result.html so operators don't have to read the source code."""

    def test_html_renders_knob_help(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_runtime_knobs(
            scan_mode="single",
            autoplan_mode="single -- 1M rows fits memory budget",
            batch_size=100_000,
            max_concurrent_chunks=4,
        )
        html = rr.to_html()
        # The doc strings for known knobs should appear in the rendered HTML.
        assert "SINGLE = one Trino query" in html  # scan_mode doc
        assert "AutoPlan-derived scan mode" in html  # autoplan_mode doc
        assert "AutoPlan to target ~20 MB" in html   # batch_size doc

    def test_unknown_knob_renders_without_crash(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_runtime_knobs(some_custom_knob="value")
        html = rr.to_html()
        assert "some_custom_knob" in html
        assert "value" in html
