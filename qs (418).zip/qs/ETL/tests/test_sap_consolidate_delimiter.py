"""Phase 134-K — SAP consolidator emits pipe-separated output by default,
matching the CTL template's ``csv-separator:|`` advertisement.

Also locks the mapping-aware ``_merge_parquet_files`` against
re-introduction of the duplicate (mapping-less) definition that was
silently shadowing it (audit SERIOUS #1, 2026-05-26).

2026-06-21 -- post the steps/ refactor (commit 933b641), the SAP
consolidate logic now lives in ``steps.sap.sap_consolidate_files
.SapConsolidateFiles`` (not the generic ``ConsolidateFiles`` which is
S3-flow oriented and merges via ``_merge_datasource_files``).  The
test imports were retargeted accordingly; the audit-style guards now
inspect the SAP class + source file.
"""
from __future__ import annotations

import asyncio
import inspect
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    from steps.sap.sap_consolidate_files import SapConsolidateFiles
    return SapConsolidateFiles(
        starburst_clients={}, oracle_data_manager=None,
        logger=MagicMock(), config={},
    )


def _make_input(tmp_path: Path, name: str, rows: list) -> Path:
    """Write a comma-separated per-group CSV (matches what
    ``_paginated_odata_to_csv`` produces via csv.DictWriter default).
    """
    p = tmp_path / name
    p.write_text("\n".join([",".join(r) for r in rows]) + "\n",
                 encoding="utf-8")
    return p


class TestConsolidatedDelimiter:
    """The data file must use the same delimiter the CTL declares —
    otherwise every downstream pipe-split reader mangles every row.
    Audit BLOCKER #1 (2026-05-26).
    """

    def test_output_default_is_pipe_separated(self, tmp_path):
        step = _make_step()
        f1 = _make_input(tmp_path, "g0.csv", [
            ["company_code", "amount", "currency"],
            ["8129", "1234.56", "USD"],
            ["8130", "9999.99", "GBP"],
        ])
        f2 = _make_input(tmp_path, "g1.csv", [
            ["company_code", "amount", "currency"],
            ["9000", "0", "EUR"],
        ])
        out = tmp_path / "merged.csv"
        n = step._merge_csv_files(
            [str(f1), str(f2)], str(out),
            mapping_spec=None,
            source_delim=",", output_delim="|",
            write_bom=False,  # easier-to-assert plain UTF-8
        )
        assert n == 3
        body = out.read_text(encoding="utf-8")
        # Every line MUST be pipe-separated.
        for line in body.splitlines():
            if not line:
                continue
            assert "|" in line, f"line not pipe-separated: {line!r}"
            assert "," not in line, (
                f"line still contains a comma — delimiter swap failed: "
                f"{line!r}"
            )
        # 2026-06-21 -- SapConsolidateFiles builds a UNION master header
        # alphabetically sorted (Phase 134-K hardening so cross-group
        # column-order mismatches don't misalign rows).  Assert on the
        # actual columns rather than the original source order.
        header_cols = body.splitlines()[0].split("|")
        assert set(header_cols) == {"company_code", "amount", "currency"}
        # Spot-check: 8129's row appears in body with the right values
        # in the right columns regardless of column order.
        rows = [ln.split("|") for ln in body.splitlines()[1:] if ln]
        col_idx = {c: i for i, c in enumerate(header_cols)}
        row_8129 = next(r for r in rows if r[col_idx["company_code"]] == "8129")
        assert row_8129[col_idx["amount"]] == "1234.56"
        assert row_8129[col_idx["currency"]] == "USD"

    def test_writer_honours_explicit_output_delim(self, tmp_path):
        """Explicit override should win (e.g. ; for European-CSV consumers)."""
        step = _make_step()
        f1 = _make_input(tmp_path, "g0.csv", [
            ["a", "b"],
            ["1", "2"],
        ])
        out = tmp_path / "out.csv"
        step._merge_csv_files(
            [str(f1)], str(out),
            mapping_spec=None,
            source_delim=",", output_delim=";",
            write_bom=False,
        )
        body = out.read_text(encoding="utf-8")
        assert "a;b" in body
        assert "1;2" in body

    def test_reader_handles_pipe_separated_sources(self, tmp_path):
        """When source files are already pipe-separated (re-run on
        already-consolidated output), the reader must honour the
        configured source delimiter — NOT silently mis-parse.
        """
        step = _make_step()
        # Pipe-separated source.
        f = tmp_path / "g0.csv"
        f.write_text(
            "company_code|amount|currency\n8129|100|USD\n",
            encoding="utf-8",
        )
        out = tmp_path / "out.csv"
        n = step._merge_csv_files(
            [str(f)], str(out),
            mapping_spec=None,
            source_delim="|", output_delim="|",
            write_bom=False,
        )
        assert n == 1
        body = out.read_text(encoding="utf-8")
        # Round-trip preserves the 3 columns — if reader had used `,`
        # it would have seen one column "company_code|amount|currency"
        # and `out` would be ONE long pipe-less cell.
        # 2026-06-21 -- the UNION-master-header sort means the columns
        # may have been alphabetised; assert presence + per-row value
        # mapping rather than positional order.
        header = body.splitlines()[0].split("|")
        first_data_line = body.splitlines()[1]
        assert set(header) == {"company_code", "amount", "currency"}
        cells = first_data_line.split("|")
        row = dict(zip(header, cells))
        assert row == {
            "company_code": "8129",
            "amount":       "100",
            "currency":     "USD",
        }


class TestRunIntegration:
    """End-to-end through ``_execute_step`` — verifies the config knob
    actually plumbs through to the writer (not just unit-level)."""

    def test_execute_step_honours_consolidated_csv_delimiter(self, tmp_path):
        step = _make_step()
        # Synthesise two per-group CSVs.
        f1 = _make_input(tmp_path, "mebal_group_0_2025_009.csv", [
            ["company_code", "amount"],
            ["8129", "1"],
        ])
        f2 = _make_input(tmp_path, "mebal_group_1_2025_009.csv", [
            ["company_code", "amount"],
            ["9000", "2"],
        ])
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(
            '{"output_dir":"%s",'
            '"consolidated_csv_delimiter":"|",'
            '"source_csv_delimiter":",",'
            '"csv_write_bom":false}' % str(tmp_path).replace("\\", "/"),
        )
        task = {
            "sql_query_path": str(cfg_path),
            "downloaded_files": [str(f1), str(f2)],
            "output_dir": str(tmp_path),
            "p_gjahr": "2025",
            "p_poper": "009",
            "output_format": "csv",
            "totalcount": 2,           # SapConsolidateFiles guards on this
            "log_file": str(tmp_path / "log.txt"),
        }
        n = asyncio.run(step._execute_step(
            task, worker_connection_string="",
            dest_connection_string="", step_name="SapConsolidateFiles",
        ))
        assert n == 2
        out = Path(task["consolidated_file"])
        assert out.exists()
        body = out.read_text(encoding="utf-8")
        # CTL contract: csv-separator is `|`.  The UNION master header
        # may have re-ordered columns alphabetically; assert per-row
        # via dict lookup rather than positional substring.
        lines = [ln for ln in body.splitlines() if ln]
        header = lines[0].split("|")
        rows = [dict(zip(header, ln.split("|"))) for ln in lines[1:]]
        assert any(
            r.get("company_code") == "8129" and r.get("amount") == "1"
            for r in rows
        ), f"missing 8129|1 row in {body!r}"
        assert any(
            r.get("company_code") == "9000" and r.get("amount") == "2"
            for r in rows
        ), f"missing 9000|2 row in {body!r}"


class TestNoDuplicateMergeParquet:
    """Audit SERIOUS #1 regression guard — there must be exactly ONE
    ``_merge_parquet_files`` definition on the SAP consolidate class,
    and it must be the mapping-aware (mapping_spec=) signature.

    2026-06-21 -- retargeted at ``steps.sap.sap_consolidate_files
    .SapConsolidateFiles`` after the steps/ split moved SAP-specific
    consolidate out of the generic module.
    """

    def test_only_one_definition(self):
        from steps.sap.sap_consolidate_files import SapConsolidateFiles
        # The class dict carries the WINNING definition; previously a
        # second def with a 3-arg signature shadowed the 4-arg one and
        # silently dropped column mapping for parquet output.
        fn = SapConsolidateFiles.__dict__.get("_merge_parquet_files")
        assert fn is not None
        sig = inspect.signature(fn)
        params = list(sig.parameters.keys())
        # self, files, output_path, mapping_spec
        assert "mapping_spec" in params, (
            f"_merge_parquet_files lost mapping_spec parameter — "
            f"a duplicate definition may have been reintroduced. "
            f"params={params}"
        )

    def test_source_grep_only_one_def(self):
        """Belt-and-suspenders: text search of the source file."""
        src = (
            Path(__file__).parent.parent / "steps" / "sap" /
            "sap_consolidate_files.py"
        )
        body = src.read_text(encoding="utf-8")
        defs = [
            ln for ln in body.splitlines()
            if ln.strip().startswith("def _merge_parquet_files(")
        ]
        assert len(defs) == 1, (
            f"expected exactly 1 def _merge_parquet_files, found {len(defs)}: "
            f"{defs}"
        )
