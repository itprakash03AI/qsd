"""Tests for cross-thread Starburst cancellation (2026-06-12).

Locks the contract that:
  * StarburstCancellable.cancel() routes to the right underlying API
    for each kind (trino cursor / Spark job group).
  * register / unregister / cancel_all are idempotent + safe.
  * Both Starburst-related step bases register a cancellable around
    their long-running call.
  * Both WorkflowRunner._execute_run AND BackgroundPoller._execute_run
    fire cancel_all on TimeoutError so the in-flight query is cancelled
    server-side, not just abandoned client-side.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. StarburstCancellable + helpers ─────────────────────────────────


class TestStarburstCancellable:
    def test_trino_cursor_kind_calls_cancel_then_close(self):
        from starburst_cancellation import StarburstCancellable, KIND_TRINO_CURSOR
        cursor = MagicMock()
        handle = StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor, label="t")
        assert handle.cancel() is True
        cursor.cancel.assert_called_once()
        cursor.close.assert_called_once()

    def test_second_cancel_is_noop(self):
        from starburst_cancellation import StarburstCancellable, KIND_TRINO_CURSOR
        cursor = MagicMock()
        handle = StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor)
        assert handle.cancel() is True
        assert handle.cancel() is False
        cursor.cancel.assert_called_once()

    def test_spark_job_group_kind_calls_cancelJobGroup(self):
        from starburst_cancellation import StarburstCancellable, KIND_SPARK_JOB_GROUP
        spark = MagicMock()
        handle = StarburstCancellable(
            KIND_SPARK_JOB_GROUP, spark=spark, group_id="g123",
        )
        handle.cancel()
        spark.sparkContext.cancelJobGroup.assert_called_once_with("g123")

    def test_underlying_cancel_exception_is_swallowed(self, caplog):
        from starburst_cancellation import StarburstCancellable, KIND_TRINO_CURSOR
        import logging
        cursor = MagicMock()
        cursor.cancel.side_effect = RuntimeError("network down")
        handle = StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor, label="t")
        caplog.set_level(logging.WARNING, logger="starburst_cancellation")
        # Must NOT raise — cancel path is best-effort.
        handle.cancel()
        # And the failure was logged at WARN so ops sees it.
        assert any("cursor.cancel() raised" in r.message for r in caplog.records)

    def test_unknown_kind_does_not_crash(self):
        from starburst_cancellation import StarburstCancellable
        handle = StarburstCancellable("unknown_kind", label="x")
        handle.cancel()  # no exception


class TestRegisterCancelAll:
    def test_register_appends_to_task_list(self):
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable,
        )
        task = {}
        h = StarburstCancellable(KIND_TRINO_CURSOR, cursor=MagicMock())
        register_starburst_cancellable(task, h)
        assert task["_starburst_resources"] == [h]

    def test_register_is_idempotent_on_same_instance(self):
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable,
        )
        task = {}
        h = StarburstCancellable(KIND_TRINO_CURSOR, cursor=MagicMock())
        register_starburst_cancellable(task, h)
        register_starburst_cancellable(task, h)
        assert len(task["_starburst_resources"]) == 1

    def test_unregister_after_normal_cleanup(self):
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable, unregister_starburst_cancellable,
        )
        task = {}
        h = StarburstCancellable(KIND_TRINO_CURSOR, cursor=MagicMock())
        register_starburst_cancellable(task, h)
        unregister_starburst_cancellable(task, h)
        assert task["_starburst_resources"] == []

    def test_cancel_all_fires_every_registered_handle(self):
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR, KIND_SPARK_JOB_GROUP,
            register_starburst_cancellable, cancel_all_starburst,
        )
        task = {}
        c1 = MagicMock(); c2 = MagicMock(); spark = MagicMock()
        h1 = StarburstCancellable(KIND_TRINO_CURSOR, cursor=c1)
        h2 = StarburstCancellable(KIND_TRINO_CURSOR, cursor=c2)
        h3 = StarburstCancellable(
            KIND_SPARK_JOB_GROUP, spark=spark, group_id="g",
        )
        register_starburst_cancellable(task, h1)
        register_starburst_cancellable(task, h2)
        register_starburst_cancellable(task, h3)
        fired = cancel_all_starburst(task)
        assert fired == 3
        c1.cancel.assert_called_once()
        c2.cancel.assert_called_once()
        spark.sparkContext.cancelJobGroup.assert_called_once_with("g")

    def test_cancel_all_empty_registry_is_noop(self):
        from starburst_cancellation import cancel_all_starburst
        assert cancel_all_starburst({}) == 0

    def test_cancel_all_called_twice_only_fires_once(self):
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable, cancel_all_starburst,
        )
        task = {}
        cursor = MagicMock()
        h = StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor)
        register_starburst_cancellable(task, h)
        cancel_all_starburst(task)
        cancel_all_starburst(task)  # idempotent
        cursor.cancel.assert_called_once()


# ─── 2. Step bases register a cancellable ──────────────────────────────


class TestStepBasesRegisterCancellable:
    """Source-level checks so a future refactor that strips the
    register call fails CI loudly instead of silently degrading."""

    def test_light_starburst_base_registers_cursor(self):
        src = (Path(ETL_ROOT) / "steps" / "oracle" / "light_starburst_base.py").read_text(encoding="utf-8")
        assert "register_starburst_cancellable" in src
        assert "unregister_starburst_cancellable" in src
        assert "KIND_TRINO_CURSOR" in src

    def test_starburst_base_registers_spark_job_group(self):
        src = (Path(ETL_ROOT) / "steps" / "oracle" / "starburst_base.py").read_text(encoding="utf-8")
        assert "register_starburst_cancellable" in src
        assert "setJobGroup" in src
        assert "interruptOnCancel=True" in src

    def test_starburst_file_base_registers_cursor(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        assert "register_starburst_cancellable" in src
        assert "KIND_TRINO_CURSOR" in src

    def test_starburst_file_spark_base_registers_spark_job_group(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_spark_base.py").read_text(encoding="utf-8")
        assert "register_starburst_cancellable" in src
        assert "setJobGroup" in src
        assert "interruptOnCancel=True" in src


# ─── 3. Runners fire cancel_all on Timeout/Cancel ──────────────────────


class TestRunnersFireCancelOnTimeout:
    @pytest.mark.asyncio
    async def test_workflow_runner_fires_cancel_on_timeout(self):
        """When _execute_run times out, cancel_all_starburst must be
        invoked on every task in the run BEFORE the status flip."""
        from polling_service.workflow_runner import WorkflowRunner
        from polling_service.config import WorkflowConfig
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable,
        )
        import logging

        wf = WorkflowConfig(name="createJob", max_concurrent_runs=2,
                            max_run_seconds=1)
        oracle_mgr = MagicMock()
        oracle_mgr.update_otg_etl_batch_status = AsyncMock()
        dispatcher = MagicMock()
        async def _hang(*a, **kw):
            await asyncio.sleep(5)
        dispatcher.execute = AsyncMock(side_effect=_hang)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )

        # Pre-register a cancellable on the task so we can verify it fires.
        cursor = MagicMock()
        handle = StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor, label="t")
        task = {"run_id": 7, "run_detail_id": 1007, "task_steps": "X",
                "fk_dag_id": "DAG_X", "fk_report_id": 42}
        register_starburst_cancellable(task, handle)

        await runner._execute_run(7, [task])
        # Timeout branch should have fired cursor.cancel().
        cursor.cancel.assert_called_once()
        assert runner.stats["timed_out"] == 1

    @pytest.mark.asyncio
    async def test_workflow_runner_fires_cancel_on_external_cancel(self):
        from polling_service.workflow_runner import WorkflowRunner
        from polling_service.config import WorkflowConfig
        from starburst_cancellation import (
            StarburstCancellable, KIND_TRINO_CURSOR,
            register_starburst_cancellable,
        )
        import logging

        wf = WorkflowConfig(name="createJob", max_concurrent_runs=2, max_run_seconds=30)
        oracle_mgr = MagicMock()
        dispatcher = MagicMock()
        # Dispatcher hangs until external cancel.
        cancel_signal = asyncio.Event()
        async def _wait(*a, **kw):
            await cancel_signal.wait()
        dispatcher.execute = AsyncMock(side_effect=_wait)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        cursor = MagicMock()
        task = {"run_id": 8, "run_detail_id": 1008}
        register_starburst_cancellable(
            task,
            StarburstCancellable(KIND_TRINO_CURSOR, cursor=cursor),
        )
        t = asyncio.create_task(runner._execute_run(8, [task]))
        await asyncio.sleep(0.05)
        t.cancel()
        with pytest.raises(asyncio.CancelledError):
            await t
        cursor.cancel.assert_called_once()

    def test_poller_fires_cancel_on_timeout(self):
        """Source-level check on the legacy single-loop poller — it
        also calls cancel_all_starburst on TimeoutError."""
        src = (Path(ETL_ROOT) / "polling_service" / "poller.py").read_text(encoding="utf-8")
        assert "from starburst_cancellation import cancel_all_starburst" in src
        # And the call is INSIDE the TimeoutError branch.
        timeout_idx = src.find("except asyncio.TimeoutError:")
        cancel_idx = src.find("cancel_all_starburst(t", timeout_idx)
        assert 0 < timeout_idx < cancel_idx, (
            "cancel_all_starburst must be called inside the timeout "
            "branch — fires BEFORE status-flip so Starburst sees the cancel"
        )
