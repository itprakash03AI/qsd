"""Sidecar location fix + per-source self-consolidation (2026-06-12).

Two related contracts:
  1. Standalone -> task["output_dir"] -> Starburst step saves sidecar
     -> ConsolidateFiles hydrates from THE SAME location.
  2. Starburst step self-consolidates its own N chunks into ONE
     per-source file with a per-source completeness check
     (sum(chunk rows) == consolidated rows).  ConsolidateFiles then
     receives 1 file per source and runs the cross-source check
     (cloud + onprem == final).
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. Sidecar location fix — both ends agree on task["output_dir"] ──


class TestSidecarLocationContract:
    def test_standalones_inject_task_output_dir(self):
        """Both standalones MUST set task['output_dir'] on every task
        before dispatching so the upstream Starburst step's
        save_task_state lands at the path ConsolidateFiles hydrates
        from."""
        for rel in ("file_standalone.py", "file_to_oracle_standalone.py"):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            assert 'task["output_dir"]' in src, (
                f"{rel}: must inject task['output_dir'] before dispatch — "
                f"sidecar mismatch is the failure mode"
            )

    def test_starburst_step_saves_sidecar_to_task_output_dir(self):
        """starburst_file_base.py's save_task_state call must prefer
        task['output_dir'] over the per-job results[0]['output_dir']."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        # The new logic prefers task["output_dir"].
        assert 'sidecar_dir = task.get("output_dir")' in src
        # And falls back to the per-job dir for back-compat.
        assert 'results[0].get("output_dir"' in src

    def test_sidecar_roundtrip_via_task_output_dir(self, tmp_path):
        """Functional check: save_task_state(base_dir) +
        hydrate_task_from_sidecar(base_dir) round-trip the keys when
        both sides use the same base_dir."""
        from steps.file.run_state import save_task_state, hydrate_task_from_sidecar
        src_task = {
            "output_dir": str(tmp_path),
            "run_id": 12345,
            "chunk_files": ["a.dat", "b.dat"],
            "job_results": [{"report_id": 31, "datasource": "CLOUD"}],
            "totalcount": 999,
        }
        save_task_state(src_task, str(tmp_path), 12345)
        dst_task = {"output_dir": str(tmp_path), "run_id": 12345}
        hydrate_task_from_sidecar(dst_task, str(tmp_path), 12345)
        assert dst_task["chunk_files"] == ["a.dat", "b.dat"]
        assert dst_task["job_results"][0]["report_id"] == 31
        assert dst_task["totalcount"] == 999


# ─── 2. Per-source self-consolidation contract ──────────────────────────


class TestSelfConsolidation:
    """Lock the source-level contract that the Starburst step
    self-consolidates its own chunks BEFORE returning, and runs the
    per-source completeness check."""

    def test_helper_is_called_in_execute_one_job(self):
        """starburst_file_base.py's _execute_one_job must call
        _self_consolidate_chunks AFTER the chunk reconcile and the
        result dict must carry consolidated_file + consolidated_rows."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        assert "_self_consolidate_chunks" in src
        assert '"consolidated_file"' in src
        assert '"consolidated_rows"' in src
        # Per-source completeness check must raise on row mismatch.
        assert "per-source completeness FAILED" in src

    def test_self_consolidate_merges_chunks_and_skips_extra_headers(self, tmp_path):
        """Two chunk CSVs -> one consolidated file.  Header from
        chunk 1 only; data rows from both."""
        from steps.file.starburst_file_base import StarburstFileBase

        # Make a minimal subclass to bypass abstract methods.
        class _Concrete(StarburstFileBase):
            DATASOURCE_NAME = "CLOUD"
            LOG_PREFIX = "test"
            def _build_connection_config(self, jc):
                return {}
        step = _Concrete.__new__(_Concrete)
        step.logger = MagicMock()
        step.artifacts = None

        chunk1 = tmp_path / "CLOUD.part_0000.dat"
        chunk1.write_text("col_a|col_b\n1|x\n2|y\n", encoding="utf-8")
        chunk2 = tmp_path / "CLOUD.part_0001.dat"
        chunk2.write_text("col_a|col_b\n3|z\n", encoding="utf-8")

        path, rows, _sums = step._self_consolidate_chunks(
            str(tmp_path), "CLOUD", "dat",
            [str(chunk1), str(chunk2)], "|",
        )
        assert path == str(tmp_path / "CLOUD.dat")
        assert rows == 3  # 3 data rows total
        assert _sums == {}
        content = Path(path).read_text(encoding="utf-8")
        # Header appears ONCE; data rows from both chunks present.
        assert content.count("col_a|col_b") == 1
        for needed in ("1|x", "2|y", "3|z"):
            assert needed in content

    def test_self_consolidate_single_chunk_still_produces_consolidated(self, tmp_path):
        """Even with 1 chunk the consolidated file is produced so
        ConsolidateFiles' input shape is uniform."""
        from steps.file.starburst_file_base import StarburstFileBase

        class _Concrete(StarburstFileBase):
            DATASOURCE_NAME = "ONPREM"
            LOG_PREFIX = "test"
            def _build_connection_config(self, jc):
                return {}
        step = _Concrete.__new__(_Concrete)
        step.logger = MagicMock()
        step.artifacts = None

        chunk1 = tmp_path / "ONPREM.part_0000.dat"
        chunk1.write_text("h1|h2\nrow1|a\nrow2|b\n", encoding="utf-8")

        path, rows, _sums = step._self_consolidate_chunks(
            str(tmp_path), "ONPREM", "dat",
            [str(chunk1)], "|",
        )
        assert Path(path).exists()
        assert rows == 2
        assert _sums == {}

    def test_self_consolidate_empty_chunk_list_raises(self, tmp_path):
        from steps.file.starburst_file_base import StarburstFileBase

        class _Concrete(StarburstFileBase):
            DATASOURCE_NAME = "X"
            LOG_PREFIX = "test"
            def _build_connection_config(self, jc):
                return {}
        step = _Concrete.__new__(_Concrete)
        step.logger = MagicMock()
        step.artifacts = None

        with pytest.raises(ValueError, match="no non-empty chunk"):
            step._self_consolidate_chunks(
                str(tmp_path), "X", "dat", [], "|",
            )


# ─── 3. ConsolidateFiles prefers consolidated_file when present ─────────


class TestConsolidateFilesPrefersConsolidatedInput:
    """ConsolidateFiles must merge per-source consolidated files (one
    per source) when they're present, and run the final cross-source
    G5 check (cloud + onprem == final)."""

    def test_consolidate_files_source_prefers_consolidated_file(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "merge_files.py").read_text(encoding="utf-8")
        # Branch that picks consolidated_file per source.
        assert 'g.get("consolidated_file")' in src
        assert "len(source_files) == len(group)" in src

    def test_cross_source_g5_check_unchanged(self):
        """The existing G5 reconcile (sum(expected_total) ==
        total_consolidated) is the cross-source check the user
        described.  Make sure it's still in place."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "merge_files.py").read_text(encoding="utf-8")
        assert "G5 reconcile FAILED" in src
        assert "total_consolidated != expected_total" in src
