"""2026-06-22 bug #29 -- close honest-gap items from S3 pruning audit.

Three concrete env-resilience hardenings:

  Gap 1: STS token refresh during long-running Spark reads
    -> when auth_mode=assume_role + role_arn present, use Hadoop S3A
       AssumedRoleCredentialProvider (auto-refresh STS internally)
       instead of TemporaryAWSCredentialsProvider (static token; dies
       on token expiry mid-read)

  Gap 2: S3A connector retry/throttle tuning
    -> add sensible defaults for retry.limit, throttle.interval,
       connection.maximum, threads.max, input.fadvise=random, etc.
    -> all per-config-overridable via s3a_* keys in per-job JSON

  Gap 3: Huge-table manifest observability
    -> when supplement pruning hits a manifest with >= N files (default
       5000), log WARN suggesting Spark+Iceberg native may be faster.
    -> surface kept/total file count + scan time to FileRunReport
       runtime_knobs so result.html shows pruning effectiveness.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


class _FakeBuilder:
    """Captures every .config() call so tests can verify the resulting
    SparkSession config dict."""
    def __init__(self):
        self.captured = {}

    def config(self, key, value):
        self.captured[key] = value
        return self


def _make_step():
    """Construct an S3BaseStep with minimal mocks."""
    # Avoid the real BaseStep + Spark imports by patching what's used.
    from unittest.mock import patch
    sys.modules.setdefault("oracledb", MagicMock())
    sys.modules.setdefault("pyspark", MagicMock())
    sys.modules.setdefault("pyspark.sql", MagicMock())
    sys.modules.setdefault("pyspark.sql.functions", MagicMock())
    sys.modules.setdefault("pyspark.sql.types", MagicMock())
    from steps.s3.s3_base_step import S3BaseStep

    class _Concrete(S3BaseStep):
        LOG_PREFIX = "test_s3"
        REQUIRED_FIELDS = []
        async def _execute_step(self, *a, **kw):
            return 0

    inst = _Concrete.__new__(_Concrete)
    inst.logger = MagicMock()
    return inst


# ──────────────────────────────────────────────────────────────────────
#  Gap 1: STS token refresh via AssumedRoleCredentialProvider
# ──────────────────────────────────────────────────────────────────────


class TestStsTokenRefreshGap:
    """When auth_mode=assume_role, Hadoop S3A must use the auto-refresh
    AssumedRoleCredentialProvider so long Spark reads don't die on
    token expiry."""

    def test_assume_role_engages_provider(self):
        step = _make_step()
        builder = _FakeBuilder()
        config = {
            'auth_mode': 'assume_role',
            'role_arn': 'arn:aws:iam::123:role/qs-etl',
            's3_access_key': '',
            's3_secret_key': '',
        }
        step._configure_s3a(builder, config)
        assert (
            builder.captured.get(
                "spark.hadoop.fs.s3a.aws.credentials.provider"
            ) == "org.apache.hadoop.fs.s3a.auth.AssumedRoleCredentialProvider"
        )
        assert builder.captured.get(
            "spark.hadoop.fs.s3a.assumed.role.arn"
        ) == "arn:aws:iam::123:role/qs-etl"

    def test_assume_role_session_duration_configurable(self):
        step = _make_step()
        builder = _FakeBuilder()
        config = {
            'auth_mode': 'assume_role',
            'role_arn': 'arn:aws:iam::123:role/qs-etl',
            'assume_role_session_duration': '4h',  # max for chained roles
        }
        step._configure_s3a(builder, config)
        assert builder.captured.get(
            "spark.hadoop.fs.s3a.assumed.role.session.duration"
        ) == "4h"

    def test_non_assume_role_keeps_static_provider(self):
        """Without auth_mode=assume_role, the legacy
        TemporaryAWSCredentialsProvider stays in place."""
        step = _make_step()
        builder = _FakeBuilder()
        config = {
            's3_access_key': 'AKIA...',
            's3_secret_key': 'secret',
            's3_session_token': 'token',
        }
        step._configure_s3a(builder, config)
        # AssumedRoleCredentialProvider NOT set
        assert "AssumedRole" not in str(
            builder.captured.get(
                "spark.hadoop.fs.s3a.aws.credentials.provider", "",
            )
        )


# ──────────────────────────────────────────────────────────────────────
#  Gap 2: S3A retry / throttle / connection pool hardening
# ──────────────────────────────────────────────────────────────────────


class TestS3aRetryHardeningGap:
    """Hadoop S3A defaults are flaky under heavy parquet/iceberg
    parallelism.  Each hardening config must be present (with defaults
    that survive moderate throttling) AND per-job overridable."""

    def test_default_retry_configs_present(self):
        step = _make_step()
        builder = _FakeBuilder()
        step._configure_s3a(builder, {})  # no overrides
        required = [
            "spark.hadoop.fs.s3a.attempts.maximum",
            "spark.hadoop.fs.s3a.retry.limit",
            "spark.hadoop.fs.s3a.retry.interval",
            "spark.hadoop.fs.s3a.retry.throttle.limit",
            "spark.hadoop.fs.s3a.retry.throttle.interval",
            "spark.hadoop.fs.s3a.connection.maximum",
            "spark.hadoop.fs.s3a.threads.max",
            "spark.hadoop.fs.s3a.connection.timeout",
            "spark.hadoop.fs.s3a.experimental.input.fadvise",
        ]
        missing = [k for k in required if k not in builder.captured]
        assert not missing, f"S3A hardening missing keys: {missing}"

    def test_parquet_input_fadvise_random(self):
        """Random fadvise is better for parquet row-group reads.
        Sequential is the legacy default for CSV-style scans."""
        step = _make_step()
        builder = _FakeBuilder()
        step._configure_s3a(builder, {})
        assert builder.captured.get(
            "spark.hadoop.fs.s3a.experimental.input.fadvise"
        ) == "random"

    def test_connection_max_bumped_above_default(self):
        """Hadoop default is 96; tune up to 200 for heavy parallelism."""
        step = _make_step()
        builder = _FakeBuilder()
        step._configure_s3a(builder, {})
        cmax = int(builder.captured.get(
            "spark.hadoop.fs.s3a.connection.maximum", "0",
        ))
        assert cmax >= 200, f"connection.maximum too low: {cmax}"

    def test_per_job_override_wins(self):
        """Operator config overrides win over hardening defaults."""
        step = _make_step()
        builder = _FakeBuilder()
        step._configure_s3a(builder, {
            's3a_retry_limit': '15',
            's3a_throttle_interval': '2000ms',
            's3a_input_fadvise': 'sequential',
        })
        assert builder.captured["spark.hadoop.fs.s3a.retry.limit"] == "15"
        assert builder.captured["spark.hadoop.fs.s3a.retry.throttle.interval"] == "2000ms"
        assert builder.captured["spark.hadoop.fs.s3a.experimental.input.fadvise"] == "sequential"


# ──────────────────────────────────────────────────────────────────────
#  Gap 3: Huge-manifest observability (source-grep only -- runtime
#  needs full Spark+pyiceberg stack to exercise)
# ──────────────────────────────────────────────────────────────────────


class TestHugeManifestObservability:
    def test_huge_manifest_warn_in_source(self):
        """Source-grep: the LARGE manifest WARN path exists in
        s3_query_base.py + threshold is config-overridable."""
        with open(os.path.join(_ETL_ROOT, "steps/s3/s3_query_base.py"),
                  encoding="utf-8") as f:
            body = f.read()
        assert "supplement_pruning_huge_manifest_warn" in body
        assert "LARGE manifest" in body
        assert "Spark+Iceberg" in body or "spark+iceberg" in body.lower()

    def test_pruning_effectiveness_in_runtime_knobs(self):
        """Source-grep: supplement-pruning effectiveness ends up in
        FileRunReport.runtime_knobs so result.html shows kept/total."""
        with open(os.path.join(_ETL_ROOT, "steps/s3/s3_query_base.py"),
                  encoding="utf-8") as f:
            body = f.read()
        assert "runtime_knobs[f\"supplement_pruning_" in body \
            or "runtime_knobs['supplement_pruning_" in body \
            or "supplement_pruning_{full_table}" in body
