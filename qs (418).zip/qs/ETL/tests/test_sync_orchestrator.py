"""Orchestrator: detect → discover → estimate → dispatch + idempotency."""
from datetime import date
from typing import List

from ETL.sync.dispatcher import SyncDispatcher
from ETL.sync.models import DispatchMode, SyncAction, TableRef, TableTriple
from ETL.sync.orchestrator import SyncOrchestrator


class _FakeComparator:
    def __init__(self, rows):
        self._rows = rows
    def compare(self, triple):
        return self._rows


class _FakePolling:
    """Implements the new DirectProcBackend protocol — name kept for
    test-file compatibility but semantics: directly executes the proc."""
    def __init__(self):
        self.calls: List[SyncAction] = []
    def execute(self, action):
        self.calls.append(action)
        return f"proc-{action.idempotency_key}"


class _FakeAirflow:
    def __init__(self):
        self.calls: List[SyncAction] = []
    def trigger(self, action):
        self.calls.append(action)
        return f"airflow-run-{action.idempotency_key}"


class _MemIdempotency:
    def __init__(self, already=None):
        self._already = set(already or [])
        self._recorded = []
    def already_dispatched(self, key): return key in self._already
    def record_dispatch(self, action, result):
        self._recorded.append((action, result))
        self._already.add(action.idempotency_key)


def _disc_row(code, count):
    """Mimic comparator output: one DiscrepancyRow with mismatched counts."""
    from ETL.sync.models import DiscrepancyKey, DiscrepancyRow
    return DiscrepancyRow(
        key=DiscrepancyKey(
            code=code,
            business_close_date=date(2026, 1, 1),
            business_event="OPEN",
        ),
        counts={"sb_cloud": count, "sb_onprem": count, "oracle": 0},
    )


def _triple():
    return TableTriple(
        logical_name="fact_x",
        refs=[TableRef("sb_cloud", "c", "s", "t")],
    )


def _orch(comp, polling, airflow, idem, threshold=500_000):
    return SyncOrchestrator(
        comparator=comp,
        dispatcher=SyncDispatcher(direct=polling, airflow=airflow),
        idempotency=idem,
        proc_name="OTG_PKG_REC.SYNC_ONE",
        polling_threshold=threshold,
    )


def test_no_discrepancies_means_no_dispatch():
    polling, airflow, idem = _FakePolling(), _FakeAirflow(), _MemIdempotency()
    result = _orch(_FakeComparator([]), polling, airflow, idem).run(_triple())
    assert result.actions == []
    assert result.dispatched == []
    assert polling.calls == []
    assert airflow.calls == []


def test_small_discrepancy_routed_to_polling():
    rows = [_disc_row("A", 100)]
    polling, airflow, idem = _FakePolling(), _FakeAirflow(), _MemIdempotency()
    result = _orch(_FakeComparator(rows), polling, airflow, idem).run(_triple())
    assert len(polling.calls) == 1
    assert airflow.calls == []
    assert polling.calls[0].dispatch_mode is DispatchMode.POLLING
    assert polling.calls[0].estimated_rows == 100
    assert len(result.dispatched) == 1


def test_large_discrepancy_routed_to_airflow():
    rows = [_disc_row("BIG", 1_000_000)]
    polling, airflow, idem = _FakePolling(), _FakeAirflow(), _MemIdempotency()
    result = _orch(_FakeComparator(rows), polling, airflow, idem).run(_triple())
    assert polling.calls == []
    assert len(airflow.calls) == 1
    assert airflow.calls[0].dispatch_mode is DispatchMode.AIRFLOW
    assert len(result.dispatched) == 1


def test_idempotency_suppresses_re_dispatch():
    rows = [_disc_row("DUP", 100)]
    polling, airflow = _FakePolling(), _FakeAirflow()
    pre_key = rows[0].key.idempotency_key("fact_x")
    idem = _MemIdempotency(already={pre_key})
    result = _orch(_FakeComparator(rows), polling, airflow, idem).run(_triple())
    assert polling.calls == []
    assert result.dispatched == []
    assert result.suppressed == [pre_key]


def test_dispatch_failure_recorded_does_not_abort_cycle():
    class _BoomPolling:
        def enqueue(self, _): raise RuntimeError("polling worker down")
    rows = [_disc_row("A", 10), _disc_row("B", 20)]
    polling, airflow, idem = _BoomPolling(), _FakeAirflow(), _MemIdempotency()
    result = _orch(_FakeComparator(rows), polling, airflow, idem).run(_triple())
    assert len(result.failures) == 2
    assert result.dispatched == []


def test_threshold_boundary_inclusive_at_airflow_side():
    # exactly == threshold → airflow (≥ threshold goes to airflow)
    rows = [_disc_row("EXACT", 500_000)]
    polling, airflow, idem = _FakePolling(), _FakeAirflow(), _MemIdempotency()
    _orch(_FakeComparator(rows), polling, airflow, idem,
          threshold=500_000).run(_triple())
    assert polling.calls == []
    assert len(airflow.calls) == 1


def test_proc_params_carry_discovered_key():
    rows = [_disc_row("XYZ", 100)]
    polling, airflow, idem = _FakePolling(), _FakeAirflow(), _MemIdempotency()
    _orch(_FakeComparator(rows), polling, airflow, idem).run(_triple())
    p = polling.calls[0].proc_params
    assert p["p_code"] == "XYZ"
    assert p["p_business_close_date"] == date(2026, 1, 1)
    assert p["p_business_event"] == "OPEN"
    assert p["p_idempotency_key"].startswith("sync:fact_x:")
