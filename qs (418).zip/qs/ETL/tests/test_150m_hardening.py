"""Phase 152 deep-dive: 150M-scale failure-mode hardening.

These tests lock the contracts around the SCALE-specific risks that
unit-tests can't catch by exercising small inputs:

  * Probe partition-count CAP (refuse runaway cardinality)
  * Probe NULL partition value handling (legal Trino, must propagate)
  * Decimal precision under very large sums (no overflow / no truncation)
  * Spark session resolution from DataFrame (no auto-getOrCreate)
  * verify_max_rows threshold (auto-skip sink verify on huge files)
  * ChunkWriter throughput + sums under simulated high row counts
  * Per-chunk SUM gate behaviour under 100+ partitions

Each test simulates the 150M failure mode in a small/fast unit so the
contracts are locked before the first real prod run.
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  ProbeQuery partition-count CAP
# ──────────────────────────────────────────────────────────────────────


class TestProbePartitionCap:
    """Probe MUST refuse and return None when partition cardinality
    exceeds the cap -- protects from runaway memory consumption when
    operator points partition_column at a high-cardinality dimension."""

    def _stub_step(self):
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "CLOUD", "LOG_PREFIX": "stub",
        })
        s = cls.__new__(cls)
        s.logger = logging.getLogger("probe-cap")
        return s

    @pytest.mark.asyncio
    async def test_probe_abandons_when_cardinality_exceeds_cap(self):
        """Stub Trino returns 1001 partitions; probe_max_partitions=1000
        triggers abandon."""
        step = self._stub_step()

        class _FakeConn:
            def __init__(self, cfg, logger):
                self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                # 1001 partition values -- crosses the cap.
                yield [(f"p{i}", 100, Decimal("1.0")) for i in range(1001)]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["a"],
                connection_config={},
                timeout=60,
                task={"probe_max_partitions": 1000},
            )
        assert result is None  # abandoned

    @pytest.mark.asyncio
    async def test_probe_accepts_when_within_cap(self):
        step = self._stub_step()

        class _FakeConn:
            def __init__(self, cfg, logger):
                self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                yield [(f"p{i}", 100, Decimal("1.0")) for i in range(50)]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["a"],
                connection_config={},
                timeout=60,
                task={"probe_max_partitions": 1000},
            )
        assert result is not None
        assert len(result["values"]) == 50

    @pytest.mark.asyncio
    async def test_default_cap_is_100k(self):
        """Default cap (100k) is what protects most production jobs --
        verify it's the right order of magnitude."""
        step = self._stub_step()

        # Empty result still triggers cap-init logic, so probe SQL log
        # line should show the cap value.
        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                if False:
                    yield None  # pragma: no cover

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["a"],
                connection_config={},
                timeout=60,
                task={},  # no probe_max_partitions -> default 100k
            )
        # Result is empty (no rows yielded) but not None.
        assert result is not None
        assert result["values"] == []


# ──────────────────────────────────────────────────────────────────────
#  Probe NULL partition value handling
# ──────────────────────────────────────────────────────────────────────


class TestProbeNullPartitionValue:
    """Trino emits a row with partition_col=NULL when the source has
    NULL partition values.  Probe must:
      * accept the NULL row (don't crash)
      * include None in values list (downstream chunk SQL uses IS NULL)
      * flag had_null_partition=True on the result for operator visibility"""

    @pytest.mark.asyncio
    async def test_null_partition_value_propagates(self):
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "X", "LOG_PREFIX": "stub",
        })
        step = cls.__new__(cls)
        step.logger = logging.getLogger("null-pv")

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                yield [
                    ("NA", 100, Decimal("50")),
                    (None, 200, Decimal("75")),  # NULL partition
                    ("EU", 50,  Decimal("25")),
                ]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["a"],
                connection_config={},
                timeout=60,
            )
        assert result is not None
        assert None in result["values"]
        assert result["counts"][None] == 200
        assert result["had_null_partition"] is True
        assert result["total_count"] == 350


# ──────────────────────────────────────────────────────────────────────
#  Decimal precision at 150M scale
# ──────────────────────────────────────────────────────────────────────


class TestDecimalPrecisionAt150M:
    """At 150M rows, SUM(decimal_col) can produce values that exceed
    standard float precision.  Verify the probe / writer / verifier
    all preserve Decimal precision exactly."""

    @pytest.mark.asyncio
    async def test_probe_preserves_high_precision_sum(self):
        """A SUM that exceeds 2^53 (float precision limit) must
        round-trip through the probe without losing digits."""
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "X", "LOG_PREFIX": "stub",
        })
        step = cls.__new__(cls)
        step.logger = logging.getLogger("decimal-150m")

        # 150M rows averaging $100.50 each = $15,075,000,000.00 (15B).
        # Plus a fractional cent -- proves digit-level precision.
        big_sum = Decimal("15075000000.13")

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                yield [("ALL", 150_000_000, big_sum)]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["amount"],
                connection_config={},
                timeout=60,
            )
        # No precision loss -- exact Decimal compare.
        assert result["total_sums"]["amount"] == big_sum
        assert result["sums"]["ALL"]["amount"] == big_sum

    @pytest.mark.asyncio
    async def test_probe_non_numeric_sum_coerced_to_zero_with_warning(self):
        """Trino driver edge case: a SUM returns a non-numeric string
        (e.g. driver type-coercion bug).  Probe must coerce + warn,
        not crash."""
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "X", "LOG_PREFIX": "stub",
        })
        step = cls.__new__(cls)
        step.logger = logging.getLogger("decimal-bad")

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                yield [("X", 100, "not-a-number")]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["amount"],
                connection_config={},
                timeout=60,
            )
        assert result is not None  # didn't crash
        assert result["total_sums"]["amount"] == Decimal(0)

    @pytest.mark.asyncio
    async def test_probe_non_int_count_coerced_with_warning(self):
        """Same edge case for COUNT -- some drivers return bigint as
        Decimal.  int() coercion + 0-fallback on failure."""
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "X", "LOG_PREFIX": "stub",
        })
        step = cls.__new__(cls)
        step.logger = logging.getLogger("count-bad")

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                # Driver returns count as Decimal -- int() works fine.
                yield [("X", Decimal("12345"), Decimal("99.0"))]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            result = await step._run_probe_query(
                base_sql="SELECT a, region FROM t",
                partition_column="region",
                checksum_columns=["amount"],
                connection_config={},
                timeout=60,
            )
        assert result["counts"]["X"] == 12345


# ──────────────────────────────────────────────────────────────────────
#  Spark session resolution from DataFrame (no auto-getOrCreate)
# ──────────────────────────────────────────────────────────────────────


class TestSparkSessionResolution:
    """The sink-verify path MUST resolve the spark session from the
    DataFrame -- NEVER call SparkSession.builder.getOrCreate() because
    on a fresh runner that constructs a new session with no S3 creds
    and the re-read fails noisily.  Test the resolution order."""

    def _stub(self):
        from steps.s3.s3_query_base import S3QueryBase
        return S3QueryBase

    def test_resolves_from_sparkSession_attr(self):
        cls = self._stub()
        df = MagicMock(spec=["sparkSession"])
        df.sparkSession = "MY_SESSION"
        assert cls._resolve_spark_session_from_df(df) == "MY_SESSION"

    def test_resolves_from_sql_ctx_fallback(self):
        cls = self._stub()
        df = MagicMock(spec=["sql_ctx"])
        df.sql_ctx.sparkSession = "FALLBACK_SESSION"
        assert cls._resolve_spark_session_from_df(df) == "FALLBACK_SESSION"

    def test_resolves_from_jdf_fallback(self):
        cls = self._stub()
        df = MagicMock(spec=["_jdf"])
        df._jdf.sparkSession = "JVM_SESSION"
        assert cls._resolve_spark_session_from_df(df) == "JVM_SESSION"

    def test_returns_none_when_no_resolution_path(self):
        cls = self._stub()
        df = MagicMock(spec=[])  # no attrs
        assert cls._resolve_spark_session_from_df(df) is None


# ──────────────────────────────────────────────────────────────────────
#  ChunkWriter stress: high-volume row + sum integrity
# ──────────────────────────────────────────────────────────────────────


class TestChunkWriterStress:
    """Push enough rows through ChunkWriter to exercise the queue
    back-pressure path + per-column SUM accumulator at scale."""

    def test_high_volume_sum_integrity(self, tmp_path):
        """100k rows in 10 batches of 10k.  Cumulative SUM must equal
        the expected value EXACTLY (no float drift)."""
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        log = logging.getLogger("chunk-stress")
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id", "amount"],
            delimiter="|",
            logger=log,
            sum_columns=["amount"],
            queue_maxsize=4,
        )
        cw.start()
        # Each row contributes 1.50 -- 100k rows -> 150_000.00 exactly.
        total_rows = 100_000
        per_row = Decimal("1.50")
        batch_size = 10_000
        for batch_idx in range(total_rows // batch_size):
            batch = [
                (str(batch_idx * batch_size + i), per_row)
                for i in range(batch_size)
            ]
            cw.put_batch(batch)
        cw.signal_end()
        cw.join(timeout=60.0)
        assert cw.records_written == total_rows
        assert cw.sums["amount"] == per_row * total_rows == Decimal("150000.00")

    def test_sum_decimal_precision_at_scale(self, tmp_path):
        """Sum many small-fraction Decimals; expect exact arithmetic,
        not float drift."""
        from steps.file.starburst_file_base import ChunkWriter
        import logging
        cw = ChunkWriter(
            file_path=str(tmp_path / "chunk.dat"),
            columns=["id", "amount"],
            delimiter="|",
            logger=logging.getLogger("decimal-stress"),
            sum_columns=["amount"],
        )
        cw.start()
        # 10000 rows of $0.01 = $100.00 EXACTLY in Decimal,
        # but 100.0 + 0.01 * 10000 in float would have drift.
        for i in range(10_000):
            cw.put_batch([(str(i), Decimal("0.01"))])
        cw.signal_end()
        cw.join(timeout=60.0)
        assert cw.sums["amount"] == Decimal("100.00")


# ──────────────────────────────────────────────────────────────────────
#  Per-chunk SUM gate: 100+ partitions with mixed mismatches
# ──────────────────────────────────────────────────────────────────────


class TestPerChunkSumGateScale:
    """When the per-chunk SUM gate fires across 100+ partitions, the
    pipeline should isolate failed buckets without halting the whole
    run -- and the failure messages should be diagnosable."""

    def _stub_step(self):
        from steps.file.starburst_file_base import StarburstFileBase
        import logging
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "X", "LOG_PREFIX": "stub",
        })
        s = cls.__new__(cls)
        s.logger = logging.getLogger("sum-gate-scale")
        return s

    def _build_plan(self, n_partitions=100, *, fail_on_mismatch=True):
        from steps.file.starburst_file_base import ScanPlan, ScanMode
        return ScanPlan(
            mode=ScanMode.PARTITION_VALUES,
            base_sql="SELECT a, region FROM t",
            expected_total=n_partitions * 100,
            partition_column="region",
            partition_values=[f"p{i}" for i in range(n_partitions)],
            expected_per_partition={f"p{i}": 100 for i in range(n_partitions)},
            checksum_columns=["amount"],
            source_checksums={"amount": Decimal(str(n_partitions * 50))},
            expected_per_partition_sums={
                f"p{i}": {"amount": Decimal("50.00")}
                for i in range(n_partitions)
            },
            max_chunk_retries=0,  # fast-fail for the test
            fail_on_mismatch=fail_on_mismatch,
        )

    @pytest.mark.asyncio
    async def test_clean_runs_all_succeed(self, tmp_path):
        from steps.file.starburst_file_base import ChunkResult
        import threading
        step = self._stub_step()
        plan = self._build_plan(n_partitions=100)
        step._execute_one_chunk = AsyncMock(
            return_value=(100, {"amount": Decimal("50.00")})
        )
        sig = threading.Event()
        results = []
        for idx, pv in enumerate(plan.partition_values):
            r = await step._execute_chunk_with_retry(
                plan, {}, idx, pv,
                str(tmp_path / f"chunk_{idx}.dat"), "|", sig,
            )
            results.append(r)
        assert all(r.success for r in results)

    @pytest.mark.asyncio
    async def test_isolated_failure_doesnt_halt(self, tmp_path):
        """5 buckets out of 100 have SUM mismatches.  Failed buckets are
        ISOLATED (should_stop_process=False) so the other 95 keep going."""
        from steps.file.starburst_file_base import ChunkResult
        import threading
        step = self._stub_step()
        plan = self._build_plan(n_partitions=100)
        # Buckets 7, 19, 42, 71, 88 return wrong sum.
        bad_indices = {7, 19, 42, 71, 88}
        call_count = {"i": 0}

        async def _mock_chunk(*args, **kwargs):
            # partition_index is the 3rd positional arg of _execute_one_chunk
            idx = args[2] if len(args) > 2 else kwargs.get("partition_index")
            if idx in bad_indices:
                return (100, {"amount": Decimal("49.99")})
            return (100, {"amount": Decimal("50.00")})

        step._execute_one_chunk = _mock_chunk
        sig = threading.Event()
        results = []
        for idx, pv in enumerate(plan.partition_values):
            r = await step._execute_chunk_with_retry(
                plan, {}, idx, pv,
                str(tmp_path / f"chunk_{idx}.dat"), "|", sig,
            )
            results.append(r)
        # All 5 bad buckets failed but should_stop_process=False on all.
        failed = [r for r in results if not r.success]
        assert len(failed) == 5
        assert all(not r.should_stop_process for r in failed)
        # The other 95 succeeded.
        assert sum(1 for r in results if r.success) == 95


# ──────────────────────────────────────────────────────────────────────
#  verify_max_rows auto-skip + sink verify behaviour
# ──────────────────────────────────────────────────────────────────────


class TestVerifyMaxRowsSkip:
    """At 150M rows the sink-verify re-read costs another Spark job.
    Operator-tunable verify_max_rows lets them skip it for big jobs."""

    def test_verify_helper_unsupported_format_raises(self):
        from steps.s3.s3_query_base import S3QueryBase
        cls = type("_StubS3Step", (S3QueryBase,), {
            "_execute_step": lambda self, *a, **kw: None,
        })
        inst = cls.__new__(cls)
        import logging
        inst.logger = logging.getLogger("verify-skip")
        spark = MagicMock()
        with pytest.raises(ValueError, match="Cannot verify"):
            inst._verify_output_completeness(
                spark, "/tmp/x.orc", "orc",
                expected_rows=100, expected_sums={},
            )
