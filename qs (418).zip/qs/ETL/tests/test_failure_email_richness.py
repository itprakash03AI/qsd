"""2026-06-21 bug #15: failure emails were sparse -- exception + traceback
only, no indication of WHICH step crashed, WHERE the log file is, or
WHICH pod ran the failed extract.

These tests lock the contract that failure emails carry actionable
post-mortem context.  Each failing run must surface:
  1. Failed step name + SEQ
  2. Log file path (for grep)
  3. Pod hostname (for K8s log correlation)
  4. Quick-action grep commands operators can copy/paste
  5. Exception + full traceback (already had this)
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


@pytest.fixture
def rr(tmp_path):
    from steps.file.run_report import FileRunReport
    rr = FileRunReport(output_dir=str(tmp_path))
    rr.mark_started()
    rr.context.update({
        "report_id": "1001",
        "business_date": "20250831",
        "run_id": "12345",
    })
    return rr


class TestMarkFailedSignature:
    """mark_failed accepts step_name + step_seq + log_file_path.
    Older callers passing only error_message still work."""

    def test_back_compat_single_arg(self, rr):
        rr.mark_failed("boom")
        assert rr.status == "FAILED"
        assert rr.error_message == "boom"
        assert rr.failed_step_name is None
        assert rr.log_file_path is None

    def test_full_signature(self, rr):
        rr.mark_failed(
            "boom",
            step_name="starburst_to_file_oncloud",
            step_seq=2,
            log_file_path="/path/to/run.log",
        )
        assert rr.status == "FAILED"
        assert rr.failed_step_name == "starburst_to_file_oncloud"
        assert rr.failed_step_seq == 2
        assert rr.log_file_path == "/path/to/run.log"

    def test_pod_hostname_auto_captured(self, rr):
        rr.mark_failed("boom")
        # socket.gethostname() always returns something, even on test rigs.
        assert rr.pod_hostname is not None


class TestFailureEmailBody:
    """The to_html() output for a FAILED status must include the
    failure-context block with all 5 actionable items."""

    def _failed_html(self, rr):
        rr.mark_failed(
            "TrinoQueryError(QUERY_EXCEEDED_TIMEOUT): partition_query timed out\n"
            "  at trino/client.py:485",
            step_name="starburst_to_file_oncloud",
            step_seq=2,
            log_file_path="/usr/local/spark/nfs/bcp/batch/logs/file_flow_run_1001_20250831.log",
        )
        return rr.to_html()

    def test_failure_block_header(self, rr):
        """Failure email leads with a clear 'Failure details' heading."""
        html = self._failed_html(rr)
        assert "Failure details" in html

    def test_failed_step_name_in_html(self, rr):
        html = self._failed_html(rr)
        assert "Failed step" in html
        assert "starburst_to_file_oncloud" in html
        assert "SEQ 2" in html

    def test_log_file_path_in_html(self, rr):
        html = self._failed_html(rr)
        assert "Log file" in html
        assert "file_flow_run_1001_20250831.log" in html

    def test_pod_hostname_in_html(self, rr):
        html = self._failed_html(rr)
        assert "Pod" in html
        # hostname is non-empty by socket.gethostname() contract

    def test_quick_action_grep_commands(self, rr):
        """Operators get copy/paste grep commands to dig into the log."""
        html = self._failed_html(rr)
        assert "Quick-action" in html or "quick-action" in html
        assert "grep -A" in html or "grep -E" in html
        # Specific actions that should be present
        assert "RUN FAILED" in html
        assert "qs_run:" in html or "trino query id" in html.lower()

    def test_traceback_block_labeled(self, rr):
        """The exception + traceback are now in a labeled section,
        not just a bare <pre>."""
        html = self._failed_html(rr)
        assert "Exception + traceback" in html
        assert "TrinoQueryError" in html

    def test_success_email_has_no_failure_block(self, rr):
        rr.mark_success()
        html = rr.to_html()
        assert "Failure details" not in html
        assert "Quick-action" not in html

    def test_failure_email_size_still_reasonable(self, rr):
        """Failure block adds ~1KB; total stays under Outlook's 75KB
        auto-attach threshold so HTML renders inline, not as attachment."""
        html = self._failed_html(rr)
        assert len(html) < 75_000


class TestStandaloneIntegration:
    """Source-grep that file_standalone.py passes the right args to
    mark_failed at the failure site -- prevents regression where
    someone refactors and drops the step_name / log_file_path args."""

    def test_shared_helper_passes_step_name_to_mark_failed(self):
        """2026-06-22 -- the mark_failed call moved into the shared
        StandaloneRunLifecycle.handle_run_failure helper.  Verify
        the helper still passes step_name + log_file_path."""
        path = os.path.join(_ETL_ROOT, "standalone_lifecycle.py")
        with open(path, encoding="utf-8") as f:
            body = f.read()
        # Find the mark_failed call in the helper.
        assert "run_report.mark_failed(" in body
        idx = body.find("run_report.mark_failed(")
        snippet = body[idx:idx + 800]
        assert "step_name=" in snippet
        assert "log_file_path=" in snippet

    def test_file_standalone_uses_shared_helper(self):
        """Regression guard: file_standalone routes failure through the
        shared helper instead of inlining the mark_failed logic."""
        path = os.path.join(_ETL_ROOT, "file_standalone.py")
        with open(path, encoding="utf-8") as f:
            body = f.read()
        assert "StandaloneRunLifecycle.handle_run_failure" in body

    def test_step_name_stashed_on_run_report_per_iteration(self):
        """execute_tasks must stash current step on run_report so the
        outer failure handler (shared helper) can read it."""
        path = os.path.join(_ETL_ROOT, "file_standalone.py")
        with open(path, encoding="utf-8") as f:
            body = f.read()
        assert "run_report.failed_step_name = step_name" in body
        assert "run_report.failed_step_seq = task.get(" in body
