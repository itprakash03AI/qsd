"""Sidecar hydration chain for the file-flow steps (2026-06-12).

Each polling row gets its own task dict, so cross-step state has to
flow through the sidecar.  Before this fix only ConsolidateFiles called
``hydrate_task_from_sidecar``; CompressFile and CreateControlFile
read upstream keys directly from the task dict and raised "CompressFile
must run first" / "ConsolidateFiles must run first" even when the
upstream step had completed and persisted its state.

End-to-end: ConsolidateFiles writes sidecar -> CompressFile reads it +
writes sidecar -> CreateControlFile reads it.  Lock the chain.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. Source-level lock: every consumer hydrates on entry ─────────────


class TestEveryConsumerHydrates:
    """Each step that reads cross-step state MUST call
    ``hydrate_task_from_sidecar`` on entry so a fresh polling-row
    task dict picks up upstream state."""

    @pytest.mark.parametrize("rel", [
        "steps/file/merge_files.py",
        "steps/file/compress_file.py",
        "steps/file/create_ctl_file.py",
    ])
    def test_imports_hydrate(self, rel):
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        assert "hydrate_task_from_sidecar" in src, (
            f"{rel}: must import hydrate_task_from_sidecar"
        )

    @pytest.mark.parametrize("rel", [
        "steps/file/merge_files.py",
        "steps/file/compress_file.py",
        "steps/file/create_ctl_file.py",
    ])
    def test_calls_hydrate_in_execute_step(self, rel):
        """Hydrate must happen inside ``_execute_step`` BEFORE the
        upstream-state validation that would otherwise raise."""
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        exec_idx = src.find("async def _execute_step")
        assert exec_idx > 0, f"{rel}: no _execute_step"
        # Either next async def or class def closes the block.
        end_a = src.find("async def ", exec_idx + 1)
        end_b = src.find("\nclass ", exec_idx + 1)
        ends = [e for e in (end_a, end_b) if e > 0]
        end = min(ends) if ends else len(src)
        body = src[exec_idx:end]
        hyd_idx = body.find("hydrate_task_from_sidecar(")
        assert hyd_idx > 0, (
            f"{rel}: _execute_step must call hydrate_task_from_sidecar"
        )
        # And the hydrate call must precede the raise statement
        # (not just the comment quoting the raise text — the raise
        # itself).  Lock the ordering.
        raise_idx = body.find("raise ValueError(")
        if raise_idx > 0:
            assert hyd_idx < raise_idx, (
                f"{rel}: hydrate_task_from_sidecar must run BEFORE "
                f"the raise ValueError(...) statement; otherwise the "
                f"sidecar is consulted only after raising"
            )


# ─── 2. Functional: round-trip through the sidecar ─────────────────────


class TestSidecarRoundTrip:
    """Functional check: save state with one task dict, hydrate from a
    DIFFERENT task dict carrying only the polling-row keys, and verify
    the upstream state flows through."""

    def test_compress_state_visible_to_create_ctl(self, tmp_path):
        from steps.file.run_state import save_task_state, hydrate_task_from_sidecar

        run_id = 874757
        base = str(tmp_path)
        # Simulate CompressFile leaving its state on disk.
        compress_task = {
            "run_id": run_id,
            "output_dir": base,
            "compress_results": [{
                "compressed_file": f"{base}/report.dat.gz",
                "md5_checksum": "abc123",
                "report_id": 31,
            }],
            "compressed_file": f"{base}/report.dat.gz",
            "md5_checksum": "abc123",
            "totalcount": 446902,
        }
        save_task_state(compress_task, base, run_id)

        # Fresh task dict (the next polling row) — only run_id +
        # output_dir present (mirrors what the dispatcher / standalone
        # set up before invoking the next step).
        ctl_task = {"run_id": run_id, "output_dir": base}
        hydrate_task_from_sidecar(ctl_task, base, run_id)
        assert ctl_task.get("compressed_file") == f"{base}/report.dat.gz"
        crs = ctl_task.get("compress_results") or []
        assert crs and crs[0]["md5_checksum"] == "abc123"
        assert ctl_task.get("totalcount") == 446902

    def test_consolidate_state_visible_to_compress(self, tmp_path):
        """Same shape one tier up: ConsolidateFiles -> CompressFile."""
        from steps.file.run_state import save_task_state, hydrate_task_from_sidecar

        run_id = 1
        base = str(tmp_path)
        consolidate_task = {
            "run_id": run_id,
            "output_dir": base,
            "consolidation_results": [{
                "consolidated_file": f"{base}/report.dat",
                "consolidated_rows": 1000,
                "report_id": 31,
            }],
            "consolidated_file": f"{base}/report.dat",
            "consolidated_total": 1000,
        }
        save_task_state(consolidate_task, base, run_id)

        compress_task = {"run_id": run_id, "output_dir": base}
        hydrate_task_from_sidecar(compress_task, base, run_id)
        assert compress_task.get("consolidated_file") == f"{base}/report.dat"

    def test_hydrate_skipped_when_state_already_present(self, tmp_path):
        """If the task dict already carries the keys (in-process run
        where every step sees the same dict), the hydrate call is a
        no-op and existing values are preserved."""
        from steps.file.run_state import save_task_state, hydrate_task_from_sidecar
        run_id = 5
        base = str(tmp_path)
        # Sidecar with OLD value.
        save_task_state(
            {"run_id": run_id, "output_dir": base,
             "compressed_file": f"{base}/old.gz"},
            base, run_id,
        )
        # Task dict already has NEW value.
        task = {"run_id": run_id, "output_dir": base,
                "compressed_file": f"{base}/new.gz"}
        # The consumer-side gating: hydrate only when key absent.
        # Mimics what compress_file/create_ctl now do.
        if not task.get("compressed_file"):
            hydrate_task_from_sidecar(task, base, run_id)
        assert task["compressed_file"] == f"{base}/new.gz"

    def test_missing_sidecar_leaves_task_unchanged(self, tmp_path):
        """If the sidecar doesn't exist, hydrate is a clean no-op."""
        from steps.file.run_state import hydrate_task_from_sidecar
        task = {"run_id": 999, "output_dir": str(tmp_path)}
        hydrate_task_from_sidecar(task, str(tmp_path), 999)
        # Nothing added.
        assert "compressed_file" not in task
        assert "consolidated_file" not in task
