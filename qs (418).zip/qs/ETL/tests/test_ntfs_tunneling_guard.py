"""Regression guard: every file-flow write site that produces a
durable output (.dat / .ctl / .sql / .html / .txt / .gz / .zip) MUST
call ``force_creation_time_now`` after the write to defeat Windows
NTFS file-name tunneling.

Without this, re-runs of the same report show the .dat file with
TODAY's ctime but the .ctl / result.html / .sql / .gz files with the
ORIGINAL creation date (NTFS preserves first-ever creation ctime when
a file with the same name is re-created within ~15 seconds; tunneling
window can be longer in practice).

This test source-greps every relevant module and asserts that any
``open(path, 'w')`` / ``gzip.open(target, 'wb')`` / ``zipfile.ZipFile``
write site has ``force_creation_time_now`` invoked within a small window
after it.

Audit reference: 2026-06-21 deep-dive bug #12.
"""
from __future__ import annotations

import os
import re
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# Modules that write durable output files for the file-flow workflow.
# Add to this list as new file-writers land in the codebase.
_FILE_FLOW_WRITERS = [
    "steps/file/merge_files.py",          # cross-source merged .dat
    "steps/file/create_ctl_file.py",      # .ctl file
    "steps/file/compress_file.py",        # .gz, .zip
    "steps/file/run_report.py",           # result.html + run_report.txt + .sql per job
    "steps/file/starburst_file_base.py",  # per-source .dat post-merge publish
    "steps/s3_to_file/consolidate_files.py",  # S3 workflow consolidated .dat
]

# Write-site patterns we care about (regex).  These are the calls that
# create / overwrite a durable file path on disk.
_WRITE_PATTERNS = [
    r"open\([^)]*['\"](?:w|wb)['\"]",       # open(path, 'w') or 'wb'
    r"gzip\.open\([^)]*['\"]wb['\"]",       # gzip.open(target, 'wb')
    r"zipfile\.ZipFile\([^,]+,\s*['\"]w['\"]",  # zipfile.ZipFile(target, 'w')
    r"os\.replace\(",                       # atomic publish (tmp -> final)
]


def _read(rel_path: str) -> str:
    with open(os.path.join(_ETL_ROOT, rel_path), encoding="utf-8") as f:
        return f.read()


@pytest.mark.parametrize("module_rel_path", _FILE_FLOW_WRITERS)
def test_writer_module_invokes_force_creation_time_now(module_rel_path):
    """Each writer module must call force_creation_time_now somewhere.
    Loose check -- presence in the file at all.  Detail tests below
    catch specific missing-after-write cases."""
    body = _read(module_rel_path)
    assert "force_creation_time_now" in body, (
        f"{module_rel_path} writes files but never calls "
        f"force_creation_time_now -- NTFS tunneling will leave stale "
        f"ctime on re-runs.  Add the call after each file-write site. "
        f"See run_state.py:force_creation_time_now docstring."
    )


def test_create_ctl_file_calls_fct_after_write():
    """Specific: the .ctl write in create_ctl_file.py must be followed
    by force_creation_time_now within ~15 lines."""
    body = _read("steps/file/create_ctl_file.py")
    # Find the write site: `open(ctl_path, "w", ...)`
    match = re.search(r"open\(ctl_path,\s*['\"]w['\"]", body)
    assert match, "Could not find ctl_path write site"
    # Check force_creation_time_now appears within 800 chars after.
    snippet = body[match.start():match.start() + 800]
    assert "force_creation_time_now" in snippet, (
        "ctl_path write is not followed by force_creation_time_now -- "
        "NTFS tunneling regression."
    )


def test_run_report_html_txt_writes_call_fct():
    """Specific: result.html / run_report.txt write at run_report.py:~1500."""
    body = _read("steps/file/run_report.py")
    # The site of interest is the `with open(path, "w") as f:` inside
    # FileRunReport.write() for the html + txt artefacts.
    matches = list(re.finditer(r"with open\(path,\s*['\"]w['\"]", body))
    assert matches, "Could not find FileRunReport.write() open(path, 'w')"
    # Each such site must have force_creation_time_now within 1500 chars.
    for m in matches:
        snippet = body[m.start():m.start() + 1500]
        assert "force_creation_time_now" in snippet, (
            f"FileRunReport write site at offset {m.start()} missing "
            f"force_creation_time_now -- result.html/run_report.txt "
            f"will have stale ctime on re-runs."
        )


def test_run_report_sql_files_write_calls_fct():
    """Specific: per-job .sql files written in FileRunReport.write()."""
    body = _read("steps/file/run_report.py")
    match = re.search(r"with open\(sql_path,\s*['\"]w['\"]", body)
    assert match, "Could not find sql_path write site"
    snippet = body[match.start():match.start() + 800]
    assert "force_creation_time_now" in snippet, (
        "Per-job .sql write is not followed by force_creation_time_now"
    )


def test_compress_file_gz_zip_call_fct():
    """Specific: gzip + zip outputs in compress_file.py."""
    body = _read("steps/file/compress_file.py")
    # gzip.open call
    gz_match = re.search(r"gzip\.open\([^)]*['\"]wb['\"]", body)
    assert gz_match, "Could not find gzip.open write site"
    gz_snippet = body[gz_match.start():gz_match.start() + 1000]
    assert "force_creation_time_now" in gz_snippet, (
        ".gz output write not followed by force_creation_time_now"
    )
    # zipfile.ZipFile call
    zip_match = re.search(r"zipfile\.ZipFile\(", body)
    assert zip_match, "Could not find zipfile.ZipFile write site"
    zip_snippet = body[zip_match.start():zip_match.start() + 1500]
    assert "force_creation_time_now" in zip_snippet, (
        ".zip output write not followed by force_creation_time_now"
    )
