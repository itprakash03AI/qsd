"""Cross-engine SQL adapter (engine_sql_adapter.py).

Lock the contract that one SQL with ``{SOURCE}`` placeholder renders
correctly for Starburst (FQN substitution), Spark-S3 (temp view name),
and DuckDB (temp view name), AND that the cross-engine lint catches
the common dialect-trap constructs.

Tests:
  * Placeholder detection (with / without / case-sensitive)
  * render_for_starburst: catalog/schema/table FQN assembly
  * render_for_spark_s3: temp view substitution
  * render_for_duckdb: temp view substitution
  * Multiple {SOURCE} occurrences all get substituted
  * Missing FQN raises when placeholder present
  * Empty SQL raises (caller must validate)
  * validate_cross_engine_safe flags LISTAGG, FOR VERSION AS OF,
    element_at, backticks, GETDATE/SYSDATE
  * Transpile fallback when sqlglot raises -- returns original SQL
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


class TestPlaceholderDetection:
    def test_bare_placeholder_detected(self):
        from engine_sql_adapter import has_source_placeholder
        assert has_source_placeholder("SELECT * FROM {SOURCE} WHERE x = 1")

    def test_dollar_form_detected(self):
        from engine_sql_adapter import has_source_placeholder
        assert has_source_placeholder("SELECT * FROM ${SOURCE}")

    def test_case_sensitive(self):
        from engine_sql_adapter import has_source_placeholder
        assert not has_source_placeholder("SELECT * FROM {source}")
        assert not has_source_placeholder("SELECT * FROM {Source}")

    def test_none_or_empty_safe(self):
        from engine_sql_adapter import has_source_placeholder
        assert not has_source_placeholder(None)
        assert not has_source_placeholder("")


class TestRenderForStarburst:
    def test_fqn_assembled_from_parts(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst(
            "SELECT a FROM {SOURCE} WHERE x = 1",
            catalog="iceberg", schema="gmi", table="fact_summary",
        )
        assert "iceberg.gmi.fact_summary" in sql
        assert "{SOURCE}" not in sql

    def test_explicit_fqn_wins(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst(
            "SELECT a FROM {SOURCE}",
            catalog="ignored", schema="ignored", table="ignored",
            fully_qualified="prod_iceberg.gmi.fact_v2",
        )
        assert "prod_iceberg.gmi.fact_v2" in sql
        assert "ignored" not in sql

    def test_partial_fqn_when_only_table(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst(
            "SELECT a FROM {SOURCE}", table="fact_summary",
        )
        assert "fact_summary" in sql
        # Three-part dot-separated FQN should not be present.
        assert ".fact_summary" not in sql

    def test_dollar_form_substituted(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst(
            "SELECT a FROM ${SOURCE}", table="t",
        )
        assert "${SOURCE}" not in sql
        assert "t" in sql

    def test_multiple_occurrences_all_substituted(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst(
            "SELECT a FROM {SOURCE} WHERE id IN (SELECT id FROM {SOURCE})",
            table="t",
        )
        assert "{SOURCE}" not in sql
        assert sql.count("t") >= 2  # at least 2 occurrences

    def test_missing_fqn_raises_when_placeholder_present(self):
        from engine_sql_adapter import render_for_starburst
        with pytest.raises(ValueError, match="no catalog/schema/table"):
            render_for_starburst("SELECT a FROM {SOURCE}")

    def test_no_placeholder_no_fqn_needed(self):
        from engine_sql_adapter import render_for_starburst
        sql = render_for_starburst("SELECT a FROM literal_table")
        assert sql == "SELECT a FROM literal_table"

    def test_empty_raises(self):
        from engine_sql_adapter import render_for_starburst
        with pytest.raises(ValueError, match="empty SQL"):
            render_for_starburst("")
        with pytest.raises(ValueError):
            render_for_starburst("   ")


class TestRenderForSparkS3:
    def test_default_view_name(self):
        from engine_sql_adapter import render_for_spark_s3
        sql = render_for_spark_s3("SELECT a FROM {SOURCE} WHERE x = 1")
        assert "FROM source" in sql
        assert "{SOURCE}" not in sql

    def test_custom_view_name(self):
        from engine_sql_adapter import render_for_spark_s3
        sql = render_for_spark_s3(
            "SELECT a FROM {SOURCE}", source_view="my_view",
        )
        assert "FROM my_view" in sql

    def test_multiple_occurrences_all_substituted(self):
        from engine_sql_adapter import render_for_spark_s3
        sql = render_for_spark_s3(
            "SELECT a FROM {SOURCE} UNION ALL SELECT b FROM {SOURCE}",
        )
        assert "{SOURCE}" not in sql

    def test_no_placeholder_passes_through(self):
        from engine_sql_adapter import render_for_spark_s3
        sql = render_for_spark_s3("SELECT a FROM literal_view")
        assert sql == "SELECT a FROM literal_view"


class TestRenderForDuckDB:
    def test_default_view_name(self):
        from engine_sql_adapter import render_for_duckdb
        sql = render_for_duckdb("SELECT a FROM {SOURCE}")
        assert "FROM source" in sql

    def test_custom_view_name(self):
        from engine_sql_adapter import render_for_duckdb
        sql = render_for_duckdb(
            "SELECT a FROM {SOURCE}", source_view="bqb_view",
        )
        assert "FROM bqb_view" in sql


class TestCrossEngineLint:
    def test_listagg_flagged(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT LISTAGG(name, ',') FROM t",
        )
        assert v["safe"] is False
        assert any("LISTAGG" in w for w in v["warnings"])

    def test_for_version_as_of_flagged(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT * FROM iceberg.t FOR VERSION AS OF 12345",
        )
        assert v["safe"] is False
        assert any("FOR VERSION AS OF" in w for w in v["warnings"])

    def test_element_at_flagged(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT element_at(arr, 1) FROM t",
        )
        assert v["safe"] is False

    def test_backtick_flagged(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT `col` FROM t",
        )
        assert v["safe"] is False
        assert any("backtick" in w for w in v["warnings"])

    def test_getdate_flagged(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT GETDATE() FROM t",
        )
        assert v["safe"] is False

    def test_clean_sql_passes(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe(
            "SELECT id, amount FROM source WHERE biz_date = DATE '2025-06-19'",
        )
        assert v["safe"] is True
        assert v["warnings"] == []

    def test_empty_sql_safe(self):
        from engine_sql_adapter import validate_cross_engine_safe
        v = validate_cross_engine_safe("")
        assert v["safe"] is True


class TestTranspileFallback:
    def test_transpile_failure_returns_original(self):
        """When sqlglot raises (or is missing), we return the original
        SQL instead of crashing the pipeline."""
        from engine_sql_adapter import render_for_starburst
        # No-op transpile to same dialect -> just runs through.
        sql = render_for_starburst(
            "SELECT a FROM t", transpile_to="trino", transpile_from="trino",
        )
        assert "SELECT" in sql

    def test_transpile_garbage_falls_back(self):
        """Transpiling unparseable garbage should not crash."""
        from engine_sql_adapter import render_for_spark_s3
        sql = render_for_spark_s3(
            "@@@ NOT VALID SQL @@@",
            transpile_to="trino", transpile_from="spark",
        )
        # Original returned unchanged (transpile failed gracefully).
        assert "NOT VALID SQL" in sql


class TestOneQueryTwoEngines:
    """The end-to-end contract: ONE source SQL renders correctly for
    BOTH engines without operator rewrite."""

    def test_same_sql_renders_for_both_engines(self):
        from engine_sql_adapter import render_for_starburst, render_for_spark_s3
        author_sql = (
            "SELECT account_id, SUM(amount) AS total "
            "FROM {SOURCE} "
            "WHERE biz_date = DATE '2025-06-19' "
            "GROUP BY account_id"
        )
        sb = render_for_starburst(
            author_sql, catalog="iceberg", schema="gmi", table="fact_txn",
        )
        sk = render_for_spark_s3(author_sql)
        # Both have the same shape, only the FROM differs.
        assert "iceberg.gmi.fact_txn" in sb
        assert "source" in sk
        # Same projection + WHERE + GROUP BY survived in both.
        for rendered in (sb, sk):
            assert "SUM(amount)" in rendered
            assert "biz_date" in rendered
            assert "GROUP BY account_id" in rendered
