"""Cron scheduler: proc execution + per-rule airflow routing + YAML loader."""
import textwrap
from pathlib import Path

import pytest

from ETL.cron.job import CronJob, JobDispatchRule
from ETL.cron.proc_runner import ProcResult, ProcRunner
from ETL.cron.scheduler import CronScheduler


class _FakeInvoker:
    """Mimics ETL/managers/oracledblib.execute_procedure shape."""
    def __init__(self, ret):
        self.ret = ret
        self.calls = []
    def execute_procedure(self, name, params):
        self.calls.append((name, params))
        return self.ret


class _FakeAirflow:
    def __init__(self):
        self.calls = []
    def trigger_for_cron(self, **kwargs):
        self.calls.append(kwargs)
        return f"af-run-{kwargs['cron_job_name']}"


def _scheduler(invoker_ret, airflow=None):
    runner = ProcRunner(invoker=_FakeInvoker(invoker_ret))
    return CronScheduler(proc_runner=runner, airflow=airflow), runner


# ── ProcRunner normalisation ──────────────────────────────────────────


def test_proc_runner_int_return():
    rn = ProcRunner(_FakeInvoker(1234))
    r = rn.run("p", {})
    assert r.status == "ok"
    assert r.rows_affected == 1234


def test_proc_runner_dict_with_rows_affected():
    rn = ProcRunner(_FakeInvoker({"status": "ok", "rows_affected": 99}))
    assert rn.run("p", {}).rows_affected == 99


def test_proc_runner_dict_with_p_count():
    rn = ProcRunner(_FakeInvoker({"p_status": "ok", "p_count": 7}))
    r = rn.run("p", {})
    assert r.status == "ok"
    assert r.rows_affected == 7


def test_proc_runner_tuple_return():
    rn = ProcRunner(_FakeInvoker(("ok", 42)))
    r = rn.run("p", {})
    assert r.status == "ok"
    assert r.rows_affected == 42


def test_proc_runner_exception_caught():
    class _Boom:
        def execute_procedure(self, *a, **kw): raise RuntimeError("oracle down")
    r = ProcRunner(_Boom()).run("p", {})
    assert r.status == "error"
    assert "oracle down" in r.error


# ── Job-spec validation ───────────────────────────────────────────────


def test_cronjob_proc_only_does_not_require_airflow():
    CronJob(name="j", schedule="0 * * * *", proc_name="p",
            dispatch_rule=JobDispatchRule.PROC_ONLY)


def test_cronjob_airflow_rule_requires_dag_id():
    with pytest.raises(ValueError, match="airflow_dag_id"):
        CronJob(name="j", schedule="0 * * * *", proc_name="p",
                dispatch_rule=JobDispatchRule.ALWAYS_AIRFLOW)


# ── _fire dispatch routing ────────────────────────────────────────────


def _job(rule, threshold=500_000, dag_id="dag"):
    return CronJob(
        name="my_job", schedule="0 * * * *", proc_name="P.PROC",
        proc_params={"x": 1}, dispatch_rule=rule,
        airflow_dag_id=dag_id, airflow_size_threshold=threshold,
    )


def test_proc_only_does_not_call_airflow():
    af = _FakeAirflow()
    sched, _ = _scheduler({"rows_affected": 100}, airflow=af)
    sched._jobs["my_job"] = _job(JobDispatchRule.PROC_ONLY)
    sched._outcomes["my_job"] = __import__("collections").deque(maxlen=10)
    sched._fire("my_job")
    assert af.calls == []
    assert sched._outcomes["my_job"][-1].proc_status == "ok"
    assert sched._outcomes["my_job"][-1].rows_affected == 100


def test_always_airflow_fires_regardless_of_rows():
    af = _FakeAirflow()
    sched, _ = _scheduler({"rows_affected": 5}, airflow=af)
    sched._jobs["my_job"] = _job(JobDispatchRule.ALWAYS_AIRFLOW)
    sched._outcomes["my_job"] = __import__("collections").deque(maxlen=10)
    sched._fire("my_job")
    assert len(af.calls) == 1
    assert af.calls[0]["cron_job_name"] == "my_job"


def test_airflow_if_large_skips_below_threshold():
    af = _FakeAirflow()
    sched, _ = _scheduler({"rows_affected": 1000}, airflow=af)
    sched._jobs["my_job"] = _job(JobDispatchRule.AIRFLOW_IF_LARGE, threshold=500_000)
    sched._outcomes["my_job"] = __import__("collections").deque(maxlen=10)
    sched._fire("my_job")
    assert af.calls == []


def test_airflow_if_large_fires_at_or_above_threshold():
    af = _FakeAirflow()
    sched, _ = _scheduler({"rows_affected": 500_000}, airflow=af)
    sched._jobs["my_job"] = _job(JobDispatchRule.AIRFLOW_IF_LARGE, threshold=500_000)
    sched._outcomes["my_job"] = __import__("collections").deque(maxlen=10)
    sched._fire("my_job")
    assert len(af.calls) == 1


def test_proc_error_skips_airflow():
    class _Boom:
        def execute_procedure(self, *a, **kw): raise RuntimeError("ORA-12345")
    runner = ProcRunner(_Boom())
    af = _FakeAirflow()
    sched = CronScheduler(proc_runner=runner, airflow=af)
    sched._jobs["my_job"] = _job(JobDispatchRule.ALWAYS_AIRFLOW)
    sched._outcomes["my_job"] = __import__("collections").deque(maxlen=10)
    sched._fire("my_job")
    assert af.calls == []
    assert sched._outcomes["my_job"][-1].proc_status == "error"


# ── YAML loader ───────────────────────────────────────────────────────


def test_yaml_loader_skips_invalid_entries(tmp_path: Path):
    p = tmp_path / "jobs.yaml"
    p.write_text(textwrap.dedent("""
        jobs:
          - name: ok_job
            schedule: "0 * * * *"
            proc_name: P.OK
            dispatch_rule: proc_only
          - name: bad_no_dag
            schedule: "0 * * * *"
            proc_name: P.BAD
            dispatch_rule: always_airflow
            # missing airflow_dag_id → CronJob raises → skipped
    """), encoding="utf-8")
    sched, _ = _scheduler({"rows_affected": 0})
    # Don't actually start the scheduler — just exercise the loader.
    sched._scheduler = None  # avoid real APScheduler scheduling
    try:
        loaded = sched.load_yaml(p)
    except AttributeError:
        # APScheduler was None — register tried to use it.  Stub it out.
        from unittest.mock import MagicMock
        sched._scheduler = MagicMock()
        loaded = sched.load_yaml(p)
    names = [j.name for j in loaded]
    assert "ok_job" in names
    assert "bad_no_dag" not in names
