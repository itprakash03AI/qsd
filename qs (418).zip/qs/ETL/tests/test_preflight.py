"""Pre-flight package check (preflight.py).

Tests:
  * Per-workflow REQUIREMENTS dict shape -- all 5 workflows covered
  * check() detects installed + missing packages without installing
  * report() logs ERROR for required-missing, INFO for optional-missing
  * install_missing() invokes pip subprocess with correct args
  * preflight_check() default auto-install ON
  * preflight_check() --no-auto-install skips install + raises on missing
  * preflight_check() raises SystemExit when required missing + no install
  * preflight_check() unknown workflow returns empty result + WARN
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
from unittest.mock import MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  Per-workflow requirements dict shape
# ──────────────────────────────────────────────────────────────────────


class TestWorkflowRequirements:
    def test_all_workflows_defined(self):
        """2026-06-22 -- s3_query split into s3_to_file + s3_to_oracle.
        s3_query kept as deprecated alias for back-compat."""
        from preflight import WORKFLOW_REQUIREMENTS
        expected = {
            "file", "oracle", "file_to_oracle", "sap_odata",
            "s3_to_file", "s3_to_oracle", "s3_query",
        }
        assert set(WORKFLOW_REQUIREMENTS.keys()) == expected

    def test_each_workflow_has_required_and_optional(self):
        from preflight import WORKFLOW_REQUIREMENTS
        for wf, spec in WORKFLOW_REQUIREMENTS.items():
            assert "required" in spec
            assert "optional" in spec
            assert isinstance(spec["required"], list)
            assert isinstance(spec["optional"], list)

    def test_package_spec_shape(self):
        """Each package spec is (import_name, pip_name, description)."""
        from preflight import WORKFLOW_REQUIREMENTS
        for wf, spec in WORKFLOW_REQUIREMENTS.items():
            for lst in (spec["required"], spec["optional"]):
                for entry in lst:
                    assert isinstance(entry, tuple)
                    assert len(entry) == 3
                    imp, pip_name, desc = entry
                    assert isinstance(imp, str) and imp
                    assert isinstance(pip_name, str) and pip_name
                    assert isinstance(desc, str) and desc

    def test_file_workflow_requires_trino(self):
        from preflight import WORKFLOW_REQUIREMENTS
        names = [s[0] for s in WORKFLOW_REQUIREMENTS["file"]["required"]]
        assert "trino" in names

    def test_s3_query_workflow_requires_pyspark(self):
        from preflight import WORKFLOW_REQUIREMENTS
        names = [s[0] for s in WORKFLOW_REQUIREMENTS["s3_query"]["required"]]
        assert "pyspark" in names

    def test_sap_odata_requires_requests(self):
        from preflight import WORKFLOW_REQUIREMENTS
        names = [s[0] for s in WORKFLOW_REQUIREMENTS["sap_odata"]["required"]]
        assert "requests" in names

    def test_sqlglot_and_psutil_optional_everywhere(self):
        """2026-06-22 -- user-confirmed: sqlglot must stay in
        _BASE_OPTIONAL so every workflow auto-installs it.  Without
        sqlglot the file workflow falls back to OOM-unsafe legacy
        wraps (wraps the full query) and Starburst-to-file fails
        ('unable to create query, wraps full query').  Even workflows
        that don't directly invoke AST rewrites benefit from the
        defensive install -- they may load shared modules that do."""
        from preflight import WORKFLOW_REQUIREMENTS
        for wf, spec in WORKFLOW_REQUIREMENTS.items():
            opt_names = [s[0] for s in spec["optional"]]
            assert "sqlglot" in opt_names, f"sqlglot must be optional in {wf}"
            assert "psutil" in opt_names, f"psutil must be optional in {wf}"


# ──────────────────────────────────────────────────────────────────────
#  check() -- detect without installing
# ──────────────────────────────────────────────────────────────────────


class TestCheckDetection:
    def test_check_returns_result_object(self):
        from preflight import check, PreflightResult
        result = check("file")
        assert isinstance(result, PreflightResult)
        assert result.workflow == "file"
        # At least one of installed_required + missing_required is non-empty.
        assert (len(result.installed_required) + len(result.missing_required)) > 0

    def test_check_unknown_workflow(self):
        from preflight import check
        result = check("not_a_real_workflow")
        assert result.workflow == "not_a_real_workflow"
        assert result.installed_required == []
        assert result.missing_required == []

    def test_check_detects_installed_pyyaml(self):
        """yaml is in BASE_REQUIRED; should be installed in test env."""
        from preflight import check
        result = check("file")
        assert "yaml" in result.installed_required

    def test_check_detects_missing_package(self):
        """A nonexistent package name appears in missing."""
        from preflight import check, WORKFLOW_REQUIREMENTS
        with patch.dict(WORKFLOW_REQUIREMENTS, {
            "test_only_workflow": {
                "required": [("definitely_not_installed_xyz123", "fake-pkg", "test")],
                "optional": [],
            }
        }):
            result = check("test_only_workflow")
        assert len(result.missing_required) == 1
        assert result.missing_required[0][1] == "fake-pkg"


# ──────────────────────────────────────────────────────────────────────
#  PreflightResult helpers
# ──────────────────────────────────────────────────────────────────────


class TestResultHelpers:
    def test_ok_true_when_no_required_missing(self):
        from preflight import PreflightResult
        r = PreflightResult("file", ["a", "b"], [], ["c"], [])
        assert r.ok is True

    def test_ok_false_when_required_missing(self):
        from preflight import PreflightResult
        r = PreflightResult("file", [], [("x", "x-pip", "desc")], [], [])
        assert r.ok is False

    def test_required_pip_command_format(self):
        from preflight import PreflightResult
        r = PreflightResult("file", [], [
            ("trino", "trino", "desc"),
            ("yaml", "pyyaml", "desc"),
        ], [], [])
        cmd = r.required_pip_command()
        assert cmd == "pip install trino pyyaml"

    def test_empty_pip_command_when_nothing_missing(self):
        from preflight import PreflightResult
        r = PreflightResult("file", ["a"], [], ["b"], [])
        assert r.required_pip_command() == ""
        assert r.optional_pip_command() == ""


# ──────────────────────────────────────────────────────────────────────
#  install_missing() -- pip subprocess
# ──────────────────────────────────────────────────────────────────────


class TestInstallMissing:
    def test_install_invokes_pip_with_correct_args(self):
        from preflight import install_missing
        specs = [("trino", "trino", "desc"), ("oracledb", "oracledb", "desc")]
        fake_result = MagicMock(returncode=0, stdout="ok", stderr="")
        # subprocess.run is called multiple times now (pip version check
        # for ensurepip bootstrap + the actual install).  Use side_effect
        # so every call returns OK.
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ok = install_missing(specs)
        assert ok is True
        # Find the install call (some args might be the ensurepip check).
        install_calls = [
            c for c in mock_run.call_args_list
            if len(c[0]) > 0 and "install" in c[0][0]
        ]
        assert install_calls, "No pip install call observed"
        called_cmd = install_calls[0][0][0]
        assert sys.executable in called_cmd
        assert "-m" in called_cmd
        assert "pip" in called_cmd
        assert "install" in called_cmd
        assert "trino" in called_cmd
        assert "oracledb" in called_cmd

    def test_install_calls_ensurepip_before_pip_install(self):
        """2026-06-22 user-validated pattern: ensurepip runs BEFORE
        every pip install (matches operator's working OpenShift fix)."""
        from preflight import install_missing
        fake_ok = MagicMock(returncode=0, stdout="", stderr="")
        calls = []
        def fake_run(cmd, **kw):
            calls.append(list(cmd))
            return fake_ok
        with patch("subprocess.run", side_effect=fake_run):
            ok = install_missing([("trino", "trino", "d")])
        assert ok is True
        # Two subprocess calls: ensurepip then pip install
        assert len(calls) == 2
        assert "ensurepip" in calls[0]
        assert "install" in calls[1]
        assert "trino" in calls[1]

    def test_install_no_user_or_target_flags(self):
        """The user-validated pattern uses PLAIN `pip install <pkg>`.
        No --user, no --target.  Those flags BROKE the install on
        user's OpenShift pod -- their working fix uses neither."""
        from preflight import install_missing
        fake_ok = MagicMock(returncode=0, stdout="", stderr="")
        with patch("subprocess.run", return_value=fake_ok) as mock_run:
            install_missing([("trino", "trino", "d")])
        install_calls = [c for c in mock_run.call_args_list
                         if "install" in c[0][0]]
        assert install_calls
        called_cmd = install_calls[0][0][0]
        assert "--user" not in called_cmd, (
            "--user flag was removed (broke on OpenShift HOME=/)"
        )
        assert "--target" not in called_cmd, (
            "--target fallback removed (over-engineered; user's "
            "simple pattern works without it)"
        )

    def test_install_no_cache_dir_flag_always_present(self):
        """--no-cache-dir prevents the '/.cache/pip not writable'
        warning observed in user's OpenShift logs.  Kept from the
        previous attempt because it's purely additive."""
        from preflight import install_missing
        fake_ok = MagicMock(returncode=0, stdout="", stderr="")
        with patch("subprocess.run", return_value=fake_ok) as mock_run:
            install_missing([("trino", "trino", "d")])
        install_calls = [c for c in mock_run.call_args_list
                         if "install" in c[0][0]]
        assert install_calls
        assert "--no-cache-dir" in install_calls[0][0][0]

    def test_install_continues_when_ensurepip_fails(self, caplog):
        """ensurepip is best-effort -- failure logs a WARN but the
        install still proceeds (might still succeed if pip is fine)."""
        from preflight import install_missing
        import logging as _lg
        caplog.set_level(_lg.WARNING, logger="preflight")
        fake_install_ok = MagicMock(returncode=0, stdout="", stderr="")
        fake_ensurepip_fail = MagicMock(returncode=1, stdout="", stderr="can't bootstrap")
        def fake_run(cmd, **kw):
            if "ensurepip" in cmd:
                return fake_ensurepip_fail
            return fake_install_ok
        with patch("subprocess.run", side_effect=fake_run):
            ok = install_missing([("trino", "trino", "d")])
        assert ok is True  # install still succeeded
        msgs = " ".join(r.message for r in caplog.records)
        assert "ensurepip" in msgs.lower()

    def test_install_logs_pip_index_url_when_set(self, caplog):
        """When PIP_INDEX_URL is set (corporate nexus), log it so
        operators can confirm the right registry is in use."""
        from preflight import install_missing
        import logging as _lg, os as _os
        caplog.set_level(_lg.INFO, logger="preflight")
        fake_result = MagicMock(returncode=0, stdout="", stderr="")
        with patch.dict(_os.environ, {"PIP_INDEX_URL": "https://nexus.corp/pypi/"}), \
             patch("subprocess.run", return_value=fake_result):
            install_missing([("trino", "trino", "d")])
        all_msgs = " ".join(r.message for r in caplog.records)
        assert "PIP_INDEX_URL" in all_msgs
        assert "nexus.corp" in all_msgs

    def test_install_empty_list_returns_true_no_call(self):
        from preflight import install_missing
        with patch("subprocess.run") as mock_run:
            ok = install_missing([])
        assert ok is True
        mock_run.assert_not_called()

    def test_install_failure_returns_false(self):
        from preflight import install_missing
        fake_result = MagicMock(returncode=1, stdout="", stderr="pip: error")
        with patch("subprocess.run", return_value=fake_result):
            ok = install_missing([("x", "x", "d")])
        assert ok is False

    def test_install_timeout_returns_false(self):
        from preflight import install_missing
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="pip", timeout=300)):
            ok = install_missing([("x", "x", "d")], timeout_seconds=300)
        assert ok is False

    def test_install_exception_returns_false_no_crash(self):
        from preflight import install_missing
        with patch("subprocess.run", side_effect=OSError("permission denied")):
            ok = install_missing([("x", "x", "d")])
        assert ok is False


# ──────────────────────────────────────────────────────────────────────
#  preflight_check() top-level
# ──────────────────────────────────────────────────────────────────────


class TestPreflightCheckDefaults:
    def test_default_is_auto_install_on(self):
        """Post-2026-06-21: auto_install defaults to True so Airflow
        SparkSubmit pods get unblocked without operator action."""
        import inspect
        from preflight import preflight_check
        sig = inspect.signature(preflight_check)
        assert sig.parameters["auto_install"].default is True
        assert sig.parameters["install_optional"].default is True

    def test_fail_on_missing_required_default_true(self):
        import inspect
        from preflight import preflight_check
        sig = inspect.signature(preflight_check)
        assert sig.parameters["fail_on_missing_required"].default is True


class TestPreflightCheckBehaviour:
    def test_all_installed_returns_ok_result(self):
        from preflight import preflight_check
        # 'file' workflow base packages should all be installed in test env.
        result = preflight_check(
            workflow="file",
            auto_install=False,
            install_optional=False,
            fail_on_missing_required=False,
        )
        # In CI test env, yaml/pandas/oracledb/trino may or may not all be
        # installed -- the test just confirms we got a result back.
        assert result.workflow == "file"

    def test_missing_required_no_install_raises_systemexit(self):
        from preflight import preflight_check, WORKFLOW_REQUIREMENTS
        with patch.dict(WORKFLOW_REQUIREMENTS, {
            "test_fail_workflow": {
                "required": [("definitely_not_installed_abc", "fake-pkg", "test")],
                "optional": [],
            }
        }):
            with pytest.raises(SystemExit) as exc_info:
                preflight_check(
                    workflow="test_fail_workflow",
                    auto_install=False,
                    fail_on_missing_required=True,
                )
            assert exc_info.value.code == 1

    def test_missing_required_no_install_no_raise_when_fail_off(self):
        from preflight import preflight_check, WORKFLOW_REQUIREMENTS
        with patch.dict(WORKFLOW_REQUIREMENTS, {
            "test_no_fail_workflow": {
                "required": [("definitely_not_installed_def", "fake-pkg", "test")],
                "optional": [],
            }
        }):
            # Should not raise.
            result = preflight_check(
                workflow="test_no_fail_workflow",
                auto_install=False,
                fail_on_missing_required=False,
            )
        assert not result.ok
        assert len(result.missing_required) == 1

    def test_auto_install_triggers_pip_install(self):
        from preflight import preflight_check, WORKFLOW_REQUIREMENTS
        with patch.dict(WORKFLOW_REQUIREMENTS, {
            "test_ai_workflow": {
                "required": [("nonexistent_pkg_ghi", "fake-pkg", "test")],
                "optional": [],
            }
        }):
            fake_pip = MagicMock(returncode=0, stdout="", stderr="")
            with patch("subprocess.run", return_value=fake_pip) as mock_run:
                # Will still raise (re-check after pip install still finds
                # the package missing since it's nonexistent).
                with pytest.raises(SystemExit):
                    preflight_check(
                        workflow="test_ai_workflow",
                        auto_install=True,
                        install_optional=False,
                        fail_on_missing_required=True,
                    )
            # pip install was attempted.
            mock_run.assert_called()

    def test_unknown_workflow_returns_empty_no_raise(self):
        from preflight import preflight_check
        result = preflight_check(
            workflow="not_real_workflow",
            auto_install=False,
            fail_on_missing_required=True,
        )
        # No required missing (none defined) -- no raise.
        assert result.installed_required == []
        assert result.missing_required == []
