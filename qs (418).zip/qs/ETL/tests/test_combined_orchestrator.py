"""Combined sync+cron orchestrator — same APScheduler drives both."""
import collections
import textwrap
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock

from ETL.cron.proc_runner import ProcRunner
from ETL.cron.scheduler import CronScheduler


class _FakeInvoker:
    def __init__(self, ret):
        self.ret = ret
        self.calls = []
    def execute_procedure(self, name, params):
        self.calls.append((name, params))
        return self.ret


def test_add_callback_job_registers_with_apscheduler():
    """Verify the new add_callback_job method actually adds to APScheduler."""
    sched = CronScheduler(proc_runner=ProcRunner(_FakeInvoker({"rows_affected": 0})))
    fired = []
    sched.add_callback_job(
        name="my_sync_cycle",
        schedule="* * * * *",
        callback=lambda: fired.append(1),
    )
    # APScheduler exposes the registered jobs via get_jobs()
    job_ids = [j.id for j in sched._scheduler.get_jobs()]
    assert "my_sync_cycle" in job_ids


def test_add_callback_job_and_proc_job_coexist():
    """Both proc jobs and callback jobs go onto the same scheduler instance —
    that's the whole point of the consolidation.  Verify they share one
    APScheduler instance (not two)."""
    sched = CronScheduler(proc_runner=ProcRunner(_FakeInvoker({"rows_affected": 0})))
    from ETL.cron.job import CronJob, JobDispatchRule
    sched.register(CronJob(
        name="proc_job", schedule="0 * * * *", proc_name="P.X",
        dispatch_rule=JobDispatchRule.PROC_ONLY,
    ))
    sched.add_callback_job(
        name="sync_job", schedule="0 * * * *",
        callback=lambda: None,
    )
    job_ids = sorted(j.id for j in sched._scheduler.get_jobs())
    assert "proc_job" in job_ids
    assert "sync_job" in job_ids


def test_callback_job_re_registration_does_not_raise():
    """add_callback_job is called with replace_existing=True so re-loading
    sync_tables.yaml (e.g. on config hot-swap or restart) doesn't error.
    The exact "replace vs duplicate" semantics depend on APScheduler
    version; we just guarantee it doesn't crash."""
    sched = CronScheduler(proc_runner=ProcRunner(_FakeInvoker({"rows_affected": 0})))
    sched.add_callback_job(name="x", schedule="* * * * *", callback=lambda: None)
    # Second call must NOT raise even when the job is already registered
    sched.add_callback_job(name="x", schedule="*/5 * * * *", callback=lambda: None)


def test_combined_main_wires_sync_schedules_into_scheduler(tmp_path: Path, monkeypatch):
    """End-to-end check: load a sync_tables.yaml with a schedule:, verify
    orchestrator_main._wire_sync_into_scheduler registers it on the
    CronScheduler."""
    cfg = tmp_path / "sync.yaml"
    cfg.write_text(textwrap.dedent("""
        polling_threshold: 500000
        default_proc_name: P.X
        triples:
          - logical_name: scheduled_table
            schedule: "0 */4 * * *"
            refs:
              - env: sb_cloud
                catalog: c
                schema: s
                table: t
          - logical_name: manual_table
            # no schedule — only available via REST /sync/run
            refs:
              - env: sb_cloud
                catalog: c
                schema: s
                table: t2
    """), encoding="utf-8")

    sched = CronScheduler(proc_runner=ProcRunner(_FakeInvoker({"rows_affected": 0})))
    sync_orch = MagicMock()

    # Import the function under test
    from ETL.orchestrator_main import _wire_sync_into_scheduler
    name_map = _wire_sync_into_scheduler(sched, sync_orch, cfg)

    # Both triples loaded into the map
    assert set(name_map.keys()) == {"scheduled_table", "manual_table"}

    # Only the scheduled one got registered with APScheduler
    job_ids = [j.id for j in sched._scheduler.get_jobs()]
    assert "sync:scheduled_table" in job_ids
    assert "sync:manual_table" not in job_ids   # no schedule → REST only
