"""Phase 134-P supplement-pruning tests.

Three layers:
  1. ``sql_filter_extractor`` — WHERE → per-column predicates
  2. ``iceberg_file_pruner``  — files + bounds + predicates → kept files
  3. ``iceberg_supplement_reader`` — DB lookup (stubbed)
  4. Integration: ``S3QueryBase._supplement_pruned_read`` — refuses
     gracefully when deps missing / table has unsupported features,
     and falls back to the standard path.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── 1. SQL filter extractor ─────────────────────────────────────────────


class TestExtractPredicates:
    def test_simple_equality(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE business_date = '2026-06-02'"
        )
        assert p == {"business_date": [("=", "2026-06-02")]}

    def test_numeric_inequality(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates("SELECT * FROM source WHERE balance > 100")
        assert p == {"balance": [(">", 100)]}

    def test_between(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE bd BETWEEN '2026-06-01' AND '2026-06-30'"
        )
        # Order doesn't matter; check both bounds present.
        assert ("bd" in p) and (len(p["bd"]) == 2)
        ops = sorted(o for o, _ in p["bd"])
        assert ops == ["<=", ">="]

    def test_in_clause(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE region IN ('APAC', 'EMEA')"
        )
        assert p == {"region": [("in", ["APAC", "EMEA"])]}

    def test_multiple_and(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source "
            "WHERE business_date = '2026-06-02' "
            "  AND region = 'APAC' "
            "  AND balance > 0"
        )
        assert p["business_date"] == [("=", "2026-06-02")]
        assert p["region"] == [("=", "APAC")]
        assert p["balance"] == [(">", 0)]

    def test_value_on_left_flips_operator(self):
        from managers.sql_filter_extractor import extract_predicates
        # ``100 < balance`` is equivalent to ``balance > 100``.
        p = extract_predicates("SELECT * FROM source WHERE 100 < balance")
        assert p == {"balance": [(">", 100)]}

    def test_qualified_column_name(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE source.region = 'APAC'"
        )
        assert p == {"region": [("=", "APAC")]}

    def test_no_where_returns_empty(self):
        from managers.sql_filter_extractor import extract_predicates
        assert extract_predicates("SELECT * FROM source") == {}

    def test_or_predicate_silently_skipped(self):
        """Top-level OR is not extractable for conservative pruning.
        sqlglot still parses fine; we just don't emit predicates."""
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE region = 'APAC' OR balance > 0"
        )
        # The OR is treated as one non-extractable node.
        assert p == {}

    def test_function_call_silently_skipped(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE UPPER(region) = 'APAC'"
        )
        # UPPER(col) doesn't match _column_name; predicate dropped.
        assert p == {}

    def test_subquery_in_clause_silently_skipped(self):
        from managers.sql_filter_extractor import extract_predicates
        p = extract_predicates(
            "SELECT * FROM source WHERE region IN (SELECT r FROM x)"
        )
        assert p == {}

    def test_malformed_sql_returns_empty(self):
        from managers.sql_filter_extractor import extract_predicates
        # Don't crash on bad SQL — return empty so caller falls back
        # to the standard path.
        assert extract_predicates("SELECT * FROM WHERE") == {}


# ── 2. File pruner ──────────────────────────────────────────────────────


class TestPruneFiles:
    def test_no_predicates_keeps_all(self):
        from managers.iceberg_file_pruner import prune_files
        files = ["f1", "f2"]
        assert prune_files(files, {}, {}, {}) == ["f1", "f2"]

    def test_no_files_returns_empty(self):
        from managers.iceberg_file_pruner import prune_files
        assert prune_files([], {}, {}, {"col": [("=", 1)]}) == []

    def test_equality_prunes_out_of_range_files(self):
        from managers.iceberg_file_pruner import prune_files
        # f1: balance [1, 10]   — could match balance = 5
        # f2: balance [100, 200] — CANNOT match balance = 5 (5 < 100)
        manifest = {"balance": {
            "f1": ("1",   "10",  0, 100),
            "f2": ("100", "200", 0, 100),
        }}
        kept = prune_files(
            ["f1", "f2"], manifest, {}, {"balance": [("=", 5)]},
        )
        assert kept == ["f1"]

    def test_greater_than_prunes(self):
        from managers.iceberg_file_pruner import prune_files
        # balance > 50 — f1 [1, 10] excluded (10 <= 50); f2 [100, 200] kept.
        manifest = {"balance": {
            "f1": ("1",   "10",  0, 0),
            "f2": ("100", "200", 0, 0),
        }}
        kept = prune_files(
            ["f1", "f2"], manifest, {}, {"balance": [(">", 50)]},
        )
        assert kept == ["f2"]

    def test_in_clause_keeps_files_where_any_value_could_match(self):
        from managers.iceberg_file_pruner import prune_files
        manifest = {"region": {
            "f1": ("AAA", "AMR", 0, 0),
            "f2": ("EUR", "EUR", 0, 0),
        }}
        # IN ('AMR', 'EMEA') — f1 keeps (AMR in [AAA, AMR]); f2 dropped.
        kept = prune_files(
            ["f1", "f2"], manifest, {},
            {"region": [("in", ["AMR", "EMEA"])]},
        )
        assert kept == ["f1"]

    def test_supplement_fills_missing_manifest_bounds(self):
        from managers.iceberg_file_pruner import prune_files
        # f1 has no manifest bounds; supplement says balance [100, 200].
        # Query balance = 5 should prune f1 via supplement.
        manifest = {}
        supplement = {"balance": {"f1": ("100", "200", 0, 0)}}
        kept = prune_files(
            ["f1"], manifest, supplement, {"balance": [("=", 5)]},
        )
        assert kept == []

    def test_missing_bounds_keeps_file_conservatively(self):
        from managers.iceberg_file_pruner import prune_files
        # No bounds anywhere — can't prove exclusion, keep the file.
        kept = prune_files(
            ["f1"], {}, {}, {"balance": [("=", 5)]},
        )
        assert kept == ["f1"]

    def test_multi_column_predicate_intersection(self):
        from managers.iceberg_file_pruner import prune_files
        # f1: bd=[2026-01, 2026-02], region=[AMR, AMR]
        # f2: bd=[2026-06, 2026-07], region=[EUR, EUR]
        # Query bd='2026-06-15' AND region='AMR' — f1 fails on bd, f2 on region.
        manifest = {
            "bd":     {"f1": ("2026-01-01", "2026-02-28", 0, 0),
                       "f2": ("2026-06-01", "2026-07-31", 0, 0)},
            "region": {"f1": ("AMR",        "AMR",        0, 0),
                       "f2": ("EUR",        "EUR",        0, 0)},
        }
        kept = prune_files(
            ["f1", "f2"], manifest, {},
            {"bd": [("=", "2026-06-15")], "region": [("=", "AMR")]},
        )
        assert kept == []


# ── 3. Supplement reader (DB stubbed) ──────────────────────────────────


class TestSupplementReader:
    def test_empty_connection_string_returns_empty(self):
        from managers.iceberg_supplement_reader import IcebergSupplementReader
        r = IcebergSupplementReader(
            connection_string="", bucket="b",
            table_prefix="p", snapshot_id="123",
        )
        assert r.bounds_for("col") == {}

    def test_cache_hit_skips_db(self, monkeypatch):
        """A pre-seeded cache must not trigger an oracledb import."""
        from managers.iceberg_supplement_reader import IcebergSupplementReader
        r = IcebergSupplementReader(
            connection_string="conn", bucket="b",
            table_prefix="p", snapshot_id="123",
        )
        seeded = {"f1": ("1", "10", 0, 100)}
        r._seed_cache("region", seeded)
        assert r.bounds_for("region") == seeded
        assert r.bounds_for("REGION") == seeded  # case-insensitive lookup

    def test_db_error_falls_back_to_empty(self, monkeypatch):
        from managers.iceberg_supplement_reader import IcebergSupplementReader

        class _BrokenOracleDb:
            def connect(self, *args, **kwargs):
                raise RuntimeError("connection refused")

        # Stub oracledb at the module level so the reader's lazy import
        # hits our broken stub.
        monkeypatch.setitem(sys.modules, "oracledb", _BrokenOracleDb())

        r = IcebergSupplementReader(
            connection_string="conn", bucket="b",
            table_prefix="p", snapshot_id="123",
        )
        assert r.bounds_for("col") == {}


# ── 4. Integration: _supplement_pruned_read refusals ────────────────────


class TestSupplementPrunedReadRefusals:
    """Every refusal path must return None (falling back to the
    standard reader), not crash.  These tests target the safety
    contract: a misconfigured supplement-pruning request never breaks
    a working baseline."""

    def _make_step(self):
        from steps.s3_to_file.s3_iceberg_query_extract import S3IcebergQueryExtract
        return S3IcebergQueryExtract(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_disabled_when_flag_false(self):
        step = self._make_step()
        assert step._supplement_pruned_read(
            spark=MagicMock(),
            config={"iceberg_table": "db.t", "query": "SELECT 1 FROM source"},
            full_table="iceberg_catalog.db.t",
            snapshot_id=None, as_of_ts_ms=None,
        ) is None

    def test_disabled_when_qs_conn_string_missing(self):
        step = self._make_step()
        assert step._supplement_pruned_read(
            spark=MagicMock(),
            config={
                "iceberg_table": "db.t",
                "query": "SELECT * FROM source WHERE a = 1",
                "use_supplement_pruning": True,
                # no querystudio_db_connection_string
            },
            full_table="iceberg_catalog.db.t",
            snapshot_id=None, as_of_ts_ms=None,
        ) is None

    def test_disabled_when_pyiceberg_missing(self, monkeypatch):
        # Force the pyiceberg import to fail.
        import builtins
        real_import = builtins.__import__

        def _no_pyiceberg(name, *args, **kwargs):
            if name == "pyiceberg.catalog" or name.startswith("pyiceberg"):
                raise ImportError(f"stubbed missing: {name}")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", _no_pyiceberg)
        step = self._make_step()
        assert step._supplement_pruned_read(
            spark=MagicMock(),
            config={
                "iceberg_table": "db.t",
                "query": "SELECT * FROM source WHERE a = 1",
                "use_supplement_pruning": True,
                "querystudio_db_connection_string": "x",
            },
            full_table="iceberg_catalog.db.t",
            snapshot_id=None, as_of_ts_ms=None,
        ) is None

    def test_disabled_when_no_extractable_predicates(self, monkeypatch):
        """Query has WHERE but it's all non-extractable (OR / function /
        subquery) — running the supplement path would be a no-op so
        we skip it entirely."""
        # Pre-import pyiceberg.catalog so the deps check passes (we
        # stub the module, then it's already in sys.modules).
        import types
        pyc = types.ModuleType("pyiceberg.catalog")
        monkeypatch.setitem(sys.modules, "pyiceberg.catalog", pyc)
        # pyiceberg package itself needs to be importable.
        pyi = types.ModuleType("pyiceberg")
        monkeypatch.setitem(sys.modules, "pyiceberg", pyi)

        step = self._make_step()
        result = step._supplement_pruned_read(
            spark=MagicMock(),
            config={
                "iceberg_table": "db.t",
                "query": "SELECT * FROM source WHERE UPPER(a) = 'X'",
                "use_supplement_pruning": True,
                "querystudio_db_connection_string": "x",
            },
            full_table="iceberg_catalog.db.t",
            snapshot_id=None, as_of_ts_ms=None,
        )
        assert result is None


class TestSupplementPrunedReadAuditMarkers:
    """Source-shape assertions: the integration must always be
    behind an explicit flag check + fall-back path, never the
    default behaviour.  Locks the contract for future audits."""

    def test_default_path_uses_standard_iceberg_reader(self):
        import inspect
        from steps.s3.s3_query_base import S3QueryBase
        src = inspect.getsource(S3QueryBase._read_iceberg_with_query)
        # Standard reader is the fallback when _supplement_pruned_read
        # returns None.
        assert 'spark.read.format("iceberg")' in src
        assert "_supplement_pruned_read" in src
        # And the fallback only fires on None return — verify the if-None
        # branch exists.
        assert "if df is None" in src

    def test_supplement_path_refuses_transforms_and_deletes(self):
        """Source must explicitly mention the two refusal reasons that
        protect correctness (transforms + delete files).  Without
        these, the pruned read could silently return wrong results."""
        import inspect
        from steps.s3.s3_query_base import S3QueryBase
        src = inspect.getsource(S3QueryBase._scan_iceberg_for_pruning)
        assert "IdentityTransform" in src, (
            "supplement pruning must explicitly refuse non-Identity "
            "partition transforms — pruned path can't reproduce them"
        )
        assert "delete_files" in src, (
            "supplement pruning must explicitly refuse snapshots with "
            "delete files — pruned read.parquet() doesn't apply deletes"
        )
