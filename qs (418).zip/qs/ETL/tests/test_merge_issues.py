"""Tests for the three merge issues found 2026-06-12.

Issue #1 (CRITICAL — data loss):
  When a source-file path equals the target-file path (e.g. no
  ``_CLOUD``/``_ONPREM`` suffix to strip), the previous code opened
  the target for write -> truncated the source -> read 0 rows from
  the now-empty source -> silently produced an empty file.
  Fix: atomic .merging -> os.replace.  Lock the contract.

Issue #2:
  Per-source consolidated files (``CLOUD.dat`` / ``ONPREM.dat``)
  stayed on disk after the cross-source merge produced the
  canonical deliverable.  Operator-facing clutter.
  Fix: clean up after successful G5.

Issue #3:
  Missing chunk files were warned-and-skipped, then the G5 check
  caught the row mismatch with a confusing message.  All-missing
  produced 'nothing to consolidate' with no list of which files
  vanished.
  Fix: refuse loudly + name the missing files.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    """Build a bare ConsolidateFiles instance bypassing BaseStep.__init__."""
    from steps.file.merge_files import ConsolidateFiles
    s = ConsolidateFiles.__new__(ConsolidateFiles)
    s.logger = MagicMock()
    from steps.file.run_state import RunArtifacts
    s.artifacts = RunArtifacts(logger=MagicMock())
    return s


# ─── Issue #1: atomic write — source == target is safe ─────────────────


class TestSourceEqualsTarget:
    def test_source_path_equals_target_no_data_loss(self, tmp_path):
        """Source file IS the target path.  Pre-fix this wiped the file;
        post-fix the merge writes to .merging then os.replace, so the
        original survives the read."""
        step = _make_step()
        target = tmp_path / "report.dat"
        # The source file lives at the SAME path that will be the
        # final output (no _CLOUD/_ONPREM suffix to strip away).
        target.write_text("col_a|col_b\n1|x\n2|y\n3|z\n", encoding="utf-8")
        job_result = {
            "report_id": 99,
            "datasource": "CLOUD",
            "chunk_files": [str(target)],
            "output_dir": str(tmp_path),
            "output_filename": "report.dat",
            "expected_total": 3,
        }
        res = step._merge_chunks_for_job(job_result)
        assert res["consolidated_rows"] == 3
        # The target file still exists AND carries the original rows.
        content = target.read_text(encoding="utf-8")
        assert "col_a|col_b" in content
        for needle in ("1|x", "2|y", "3|z"):
            assert needle in content

    def test_uses_atomic_tmp_file_during_merge(self, tmp_path):
        """Source-level: the merge writes to ``.merging`` not directly
        to the final path."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "merge_files.py").read_text(encoding="utf-8")
        assert "tmp_path = final_path" in src
        assert ".merging" in src
        assert "os.replace(tmp_path, final_path)" in src


# ─── Issue #3: missing chunk = HARD error ──────────────────────────────


class TestMissingChunkIsHardError:
    def test_missing_chunk_raises_with_filename(self, tmp_path):
        step = _make_step()
        present = tmp_path / "c1.dat"
        present.write_text("h|h\n1|x\n", encoding="utf-8")
        missing = tmp_path / "c2.dat"  # never created
        job_result = {
            "report_id": 99,
            "datasource": "CLOUD",
            "chunk_files": [str(present), str(missing)],
            "output_dir": str(tmp_path),
            "output_filename": "out.dat",
            "expected_total": 2,
        }
        with pytest.raises(ValueError) as exc_info:
            step._merge_chunks_for_job(job_result)
        # The missing file BASENAME must appear (path repr-escapes on Windows).
        assert "c2.dat" in str(exc_info.value)
        assert "Refusing to merge a partial input" in str(exc_info.value)

    def test_all_empty_chunks_raises_clearly(self, tmp_path):
        step = _make_step()
        empty1 = tmp_path / "e1.dat"
        empty2 = tmp_path / "e2.dat"
        empty1.write_text("", encoding="utf-8")
        empty2.write_text("", encoding="utf-8")
        job_result = {
            "report_id": 99,
            "datasource": "CLOUD",
            "chunk_files": [str(empty1), str(empty2)],
            "output_dir": str(tmp_path),
            "output_filename": "out.dat",
            "expected_total": 0,
        }
        with pytest.raises(ValueError, match="every chunk file is empty"):
            step._merge_chunks_for_job(job_result)


# ─── 2026-06-18: Iceberg snapshot pin (root-cause fix for drift) ───────


class TestIcebergSnapshotPin:
    """The +9,552 row delta operators see on single-SELECT + partitioned
    iceberg + no UNION has exactly one mechanism: snapshot drift
    between G1 / discovery / per-chunk extract.  ``_pin_iceberg_snapshots``
    queries the source table's current snapshot ONCE and rewrites
    base_sql with ``FOR VERSION AS OF <id>`` so every Trino read
    sees the same iceberg state.  This test asserts the source-level
    contract (presence + correctness of the rewrite).  Live Trino
    probing is integration-tested separately.
    """

    def test_pin_method_exists_and_is_called_from_orchestrator(self):
        """Source-level lock -- the method must exist on the base
        class and the orchestrator must call it gated on the opt-in
        flag."""
        from steps.file import starburst_file_base
        # Method exists.
        assert hasattr(starburst_file_base.StarburstFileBase,
                        "_pin_iceberg_snapshots"), (
            "_pin_iceberg_snapshots must exist on StarburstFileBase so "
            "subclasses inherit the iceberg-pin capability."
        )
        # Orchestrator call site present, gated on the config flag.
        src = (Path(ETL_ROOT) / "steps" / "file" /
                "starburst_file_base.py").read_text(encoding="utf-8")
        assert 'pin_iceberg_snapshot' in src
        assert 'await self._pin_iceberg_snapshots(' in src
        # Must mutate job_config so downstream readers see the pinned SQL.
        assert 'job_config["generated_sql"] = base_sql' in src

    def test_regex_injects_for_version_after_fully_qualified_table(self):
        """The post-AST regex injection inserts FOR VERSION AS OF
        AFTER the fully-qualified table name and BEFORE any alias.
        Validated by re-parsing the result -- if Trino can't parse
        it, the iceberg connector won't accept it either.
        """
        import sqlglot
        import re
        base_sql = (
            "SELECT a.id FROM iceberg_cat.sch.fact_t AS a "
            "WHERE a.dt = DATE '2026-06-18'"
        )
        snap = 7777777
        fq = "iceberg_cat.sch.fact_t"
        rendered = sqlglot.parse_one(base_sql, dialect="trino").sql(dialect="trino")
        pat = r"\b" + re.escape(fq) + r"\b(?!\s*FOR\s+VERSION)"
        out, n = re.subn(pat, f"{fq} FOR VERSION AS OF {snap}", rendered, count=1)
        assert n == 1
        assert "FOR VERSION AS OF 7777777" in out
        # Reparse to prove valid Trino syntax.
        re_parsed = sqlglot.parse_one(out, dialect="trino")
        assert "FOR VERSION AS OF 7777777" in re_parsed.sql(dialect="trino")

    def test_pin_idempotent_does_not_double_inject(self):
        """If the SQL already has FOR VERSION AS OF on a table, the
        regex must NOT inject a second one (negative-lookahead).
        """
        import re
        base_sql = "SELECT * FROM iceberg.s.t FOR VERSION AS OF 100 AS a"
        fq = "iceberg.s.t"
        pat = r"\b" + re.escape(fq) + r"\b(?!\s*FOR\s+VERSION)"
        out, n = re.subn(pat, f"{fq} FOR VERSION AS OF 200", base_sql, count=1)
        assert n == 0  # already pinned; lookahead prevents double-inject
        assert out == base_sql


# ─── 2026-06-18: CompletenessProbe AST source-SUM derivation ───────────


class TestDeriveSumSQL:
    """``_derive_sum_sql`` MUST emit SUM over the source FROM/JOIN/WHERE
    (no subquery wrap of base_sql) so it doesn't OOM Trino on 170M-
    row jobs.  Same posture as ``_derive_count_sql``: skip when base_sql
    has shape-affecting clauses (DISTINCT / GROUP BY / HAVING / LIMIT /
    QUALIFY) -- AST rewrite would change semantics and the wrap is
    OOM-unsafe.
    """

    def test_plain_select_ast_strips_to_source_sum(self):
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT a, b, c FROM tbl WHERE x = 1",
            ["amount", "qty"],
            dialect="trino",
        )
        assert mode == "ast"
        # Must NOT wrap base_sql.
        assert "FROM (" not in sql
        assert "SUM(" in sql.upper()
        assert "from tbl" in sql.lower()
        assert "WHERE" in sql.upper()

    def test_distinct_skips(self):
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT DISTINCT a, b FROM tbl",
            ["a"],
            dialect="trino",
        )
        assert mode == "skip"
        assert sql == ""

    def test_group_by_skips(self):
        """Conservative -- AVG / MAX / MIN projections of the same
        column break SUM-of-sums == grand-sum.  Skip to avoid false
        positives.  Operator gets internal-consistency checks only.
        """
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT a, SUM(amount) FROM tbl GROUP BY a",
            ["amount"],
            dialect="trino",
        )
        assert mode == "skip"

    def test_limit_skips(self):
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT a FROM tbl LIMIT 100",
            ["a"],
            dialect="trino",
        )
        assert mode == "skip"

    def test_having_skips(self):
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT a, COUNT(*) FROM tbl GROUP BY a HAVING COUNT(*) > 5",
            ["a"],
            dialect="trino",
        )
        # GROUP BY catches first, but either skip is correct.
        assert mode == "skip"

    def test_join_preserved_in_ast_mode(self):
        from steps.file.starburst_file_base import _derive_sum_sql
        sql, mode = _derive_sum_sql(
            "SELECT t1.a, t2.b FROM t1 JOIN t2 ON t1.id = t2.id WHERE t1.x = 1",
            ["t1.a"],
            dialect="trino",
        )
        assert mode == "ast"
        assert "JOIN" in sql.upper()
        assert "ON" in sql.upper()


# ─── 2026-06-18: CompletenessProbe value-column checksum ───────────────


class TestCompletenessProbeChecksum:
    """Opt-in value-column SUM checksum that survives shape-affected
    base_sql.  ChunkWriter / per-source consolidate / cross-source
    consolidate all sum the same columns; G5 compares against the
    source-side SUM (computed via `SELECT SUM(col) FROM (base_sql) AS t`).
    """

    def test_merge_sums_checksum_column_correctly(self, tmp_path):
        """Consolidated merge reports the right per-column sums when
        ``checksum_columns`` is requested.
        """
        from steps.file.merge_files import ConsolidateFiles
        step = ConsolidateFiles.__new__(ConsolidateFiles)
        step.logger = MagicMock()
        from steps.file.run_state import RunArtifacts
        step.artifacts = RunArtifacts(logger=MagicMock())

        c1 = tmp_path / "c1.dat"
        c1.write_text("id|amount\n1|100.50\n2|200\n", encoding="utf-8")
        c2 = tmp_path / "c2.dat"
        c2.write_text("id|amount\n3|50.25\n", encoding="utf-8")
        job_result = {
            "report_id": 99, "datasource": "CLOUD",
            "chunk_files": [str(c1), str(c2)],
            "output_dir": str(tmp_path),
            "output_filename": "out.dat",
            "expected_total": 3,
            "checksum_columns": ["amount"],
            "delimiter": "|",
        }
        res = step._merge_chunks_for_job(job_result)
        assert res["consolidated_rows"] == 3
        # Decimal('100.50') + Decimal('200') + Decimal('50.25') == 350.75
        assert res["consolidated_checksums"]["amount"] == "350.75"

    def test_merge_handles_null_value_as_zero(self, tmp_path):
        """Empty CSV cell -> contributes 0 to the sum (matches SQL NULL
        behaviour).  No crash, no spurious mismatch.
        """
        from steps.file.merge_files import ConsolidateFiles
        step = ConsolidateFiles.__new__(ConsolidateFiles)
        step.logger = MagicMock()
        from steps.file.run_state import RunArtifacts
        step.artifacts = RunArtifacts(logger=MagicMock())

        c1 = tmp_path / "c1.dat"
        c1.write_text("id|amount\n1|10\n2|\n3|5\n", encoding="utf-8")
        job_result = {
            "report_id": 99, "datasource": "CLOUD",
            "chunk_files": [str(c1)],
            "output_dir": str(tmp_path),
            "output_filename": "out.dat",
            "expected_total": 3,
            "checksum_columns": ["amount"],
            "delimiter": "|",
        }
        res = step._merge_chunks_for_job(job_result)
        assert res["consolidated_rows"] == 3
        assert res["consolidated_checksums"]["amount"] == "15"

    def test_merge_skips_missing_column_with_warning(self, tmp_path):
        """``checksum_columns`` includes a name not in the header -> skip
        that column, warn, continue.  Other columns + row count still
        succeed.
        """
        from steps.file.merge_files import ConsolidateFiles
        step = ConsolidateFiles.__new__(ConsolidateFiles)
        step.logger = MagicMock()
        from steps.file.run_state import RunArtifacts
        step.artifacts = RunArtifacts(logger=MagicMock())

        c1 = tmp_path / "c1.dat"
        c1.write_text("id|amount\n1|10\n", encoding="utf-8")
        job_result = {
            "report_id": 99, "datasource": "CLOUD",
            "chunk_files": [str(c1)],
            "output_dir": str(tmp_path),
            "output_filename": "out.dat",
            "expected_total": 1,
            "checksum_columns": ["amount", "does_not_exist"],
            "delimiter": "|",
        }
        res = step._merge_chunks_for_job(job_result)
        assert res["consolidated_rows"] == 1
        assert res["consolidated_checksums"]["amount"] == "10"
        # Missing column dropped entirely.
        assert "does_not_exist" not in res["consolidated_checksums"]


# ─── 2026-06-18: G3-vs-G5 unit mismatch on shape-affected base_sql ─────


class TestG3G5UnitMismatchOnShapedBaseSQL:
    """When base_sql has DISTINCT / GROUP BY / HAVING etc, G1 counts
    SOURCE rows pre-aggregation but chunks produce AGGREGATED rows.
    The operator sets ``fail_on_mismatch=False`` per the planning
    warning so G3 doesn't fire false positives.  But pre-fix,
    measured_g1 was still plan.expected_total (the wrong G1 number),
    which got surfaced as job_result["expected_total"] and then
    ConsolidateFiles' G5 compared:

        consolidated_rows (= sum_actual, post-aggregation)
        vs expected_total (= G1, pre-aggregation)

    -> false "rows lost or duplicated" failure at the MERGE step
    even though every chunk consolidated correctly.

    Fix: when fail_on_mismatch=False AND G1 != sum_actual, treat
    sum_actual as authoritative G1.
    """

    def test_measured_g1_uses_sum_actual_when_fail_on_mismatch_false(self):
        """Source-level: the strategic branch must be in
        starburst_file_base.py and must assign sum_actual to
        measured_g1 in the fail_on_mismatch=False mismatch branch.
        """
        src_path = Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py"
        src = src_path.read_text(encoding="utf-8")
        # The branch must exist.
        assert "fail_on_mismatch=False AND G1 != sum_actual" in src
        # And in that branch, measured_g1 := sum_actual (NOT plan.expected_total).
        # We assert by locating the warning text and checking the
        # nearby assignment.
        idx = src.find("G3 mismatch tolerated")
        assert idx >= 0
        window = src[idx:idx + 1500]
        assert "measured_g1 = sum_actual" in window, (
            "fail_on_mismatch=False branch must assign sum_actual to "
            "measured_g1; otherwise downstream G5 compares against "
            "G1 (the wrong unit) and false-fails."
        )

    def test_g3_reconcile_still_fails_when_mismatch_flag_is_default(self):
        """fail_on_mismatch=TRUE (default) must STILL raise on G1 != sum_actual.
        The fix only relaxes the surfacing of measured_g1, not the check.
        """
        src_path = Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py"
        src = src_path.read_text(encoding="utf-8")
        assert "G3 reconcile FAILED -- Sum(chunk actual)" in src
        assert "if plan.fail_on_mismatch and sum_actual != plan.expected_total" in src.replace("elif", "if")


# ─── Issue #2: per-source intermediates cleaned post-merge ─────────────


class TestIntermediateCleanup:
    def test_cleanup_source_logic_present(self):
        """Source-level lock — the per-source-intermediate cleanup
        path must be in _execute_step and must skip the final
        consolidated file."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "merge_files.py").read_text(encoding="utf-8")
        assert "delete_intermediate_consolidated" in src
        assert "per-source intermediate" in src
        # Must NOT delete the final deliverable.
        assert "if inter_abs in final_paths:" in src
        assert "continue  # this IS the final deliverable" in src

    def test_intermediate_files_cleaned_up_after_cross_source_merge(self, tmp_path):
        """End-to-end: after _merge_chunks_for_job produces the final,
        the per-source files in job_results[i]['consolidated_file'] are
        removed (when they differ from the final path)."""
        step = _make_step()
        step.run_report = MagicMock()
        step.run_report.set_counts = MagicMock()
        step.run_report.add_output_file = MagicMock()
        step.run_report.write = MagicMock()

        # Simulate two source steps each having produced their own
        # consolidated file with the _CLOUD / _ONPREM suffix.
        cloud_file = tmp_path / "report_CLOUD.dat"
        cloud_file.write_text("h|h\n1|x\n2|y\n", encoding="utf-8")
        prem_file = tmp_path / "report_ONPREM.dat"
        prem_file.write_text("h|h\n3|z\n", encoding="utf-8")

        # job_results carrying the per-source consolidated files.
        job_results = [
            {
                "report_id": 99, "datasource": "CLOUD",
                "consolidated_file": str(cloud_file),
                "consolidated_rows": 2,
                "chunk_files": [str(cloud_file)],
                "output_dir": str(tmp_path),
                "output_filename": "report_CLOUD.dat",
                "expected_total": 2,
            },
            {
                "report_id": 99, "datasource": "ONPREM",
                "consolidated_file": str(prem_file),
                "consolidated_rows": 1,
                "chunk_files": [str(prem_file)],
                "output_dir": str(tmp_path),
                "output_filename": "report_ONPREM.dat",
                "expected_total": 1,
            },
        ]

        # Drive _execute_step directly with a stub task dict.
        task = {
            "run_id": 7,
            "output_dir": str(tmp_path),
            "job_results": job_results,
            "fk_report_id": 99,
        }
        import asyncio
        asyncio.run(step._execute_step(task, "wcs", "dcs", "ConsolidateFiles"))

        # The per-source intermediates have been cleaned up.
        assert not cloud_file.exists(), (
            "per-source intermediate report_CLOUD.dat should be removed "
            "after the cross-source merge"
        )
        assert not prem_file.exists()
        # The cross-source merged file (canonical) exists.
        final = tmp_path / "report.dat"
        assert final.exists()
        content = final.read_text(encoding="utf-8")
        assert "1|x" in content and "2|y" in content and "3|z" in content
        # Header only ONCE.
        assert content.count("h|h") == 1

    def test_intermediate_cleanup_opt_out(self, tmp_path):
        """Operator can disable intermediate cleanup via task flag."""
        step = _make_step()
        step.run_report = MagicMock()
        step.run_report.set_counts = MagicMock()
        step.run_report.add_output_file = MagicMock()
        step.run_report.write = MagicMock()

        cloud_file = tmp_path / "x_CLOUD.dat"
        cloud_file.write_text("h\nrow1\n", encoding="utf-8")
        job_results = [{
            "report_id": 1, "datasource": "CLOUD",
            "consolidated_file": str(cloud_file),
            "consolidated_rows": 1,
            "chunk_files": [str(cloud_file)],
            "output_dir": str(tmp_path),
            "output_filename": "x_CLOUD.dat",
            "expected_total": 1,
        }]
        task = {
            "run_id": 8,
            "output_dir": str(tmp_path),
            "job_results": job_results,
            "fk_report_id": 1,
            "delete_intermediate_consolidated": False,  # opt out
        }
        import asyncio
        asyncio.run(step._execute_step(task, "wcs", "dcs", "ConsolidateFiles"))
        # Intermediate survives.
        assert cloud_file.exists()


# ─── Deep-dive audit gaps in MY OWN code (caught on second pass) ───────


class TestSelfConsolidateAudit:
    """Self-consolidate had the same source==target data-loss bug I'd
    just fixed in merge_files.  Plus the missing-chunk handling
    silently warned, mismatching merge_files' new HARD-error.  Lock the
    fix so neither comes back."""

    def _make_concrete_step(self):
        from steps.file.starburst_file_base import StarburstFileBase
        class _Concrete(StarburstFileBase):
            DATASOURCE_NAME = "X"
            LOG_PREFIX = "test"
            def _build_connection_config(self, jc):
                return {}
        s = _Concrete.__new__(_Concrete)
        s.logger = MagicMock()
        s.artifacts = None
        return s

    def test_self_consolidate_atomic_tmp_path(self):
        """Self-consolidate must write to .merging tmp, not the final
        path directly (mirrors merge_files fix)."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        sc_idx = src.find("def _self_consolidate_chunks")
        end = src.find("def ", sc_idx + 1)
        block = src[sc_idx:end]
        assert "tmp_path = consolidated_path" in block
        assert ".merging" in block
        assert "os.replace(tmp_path, consolidated_path)" in block

    def test_self_consolidate_source_equals_target_safe(self, tmp_path):
        """The atomic .merging pattern protects against source==target
        overlap in self-consolidation too."""
        step = self._make_concrete_step()
        target = tmp_path / "X.dat"
        target.write_text("h|h\n1|x\n2|y\n", encoding="utf-8")
        # base_filename + ext yields the SAME path as the source.
        path, rows, _sums = step._self_consolidate_chunks(
            str(tmp_path), "X", "dat", [str(target)], "|",
        )
        assert path == str(tmp_path / "X.dat")
        assert rows == 2
        assert _sums == {}  # no checksum_columns requested -> empty
        content = Path(path).read_text(encoding="utf-8")
        assert "1|x" in content and "2|y" in content

    def test_self_consolidate_missing_chunk_is_hard_error(self, tmp_path):
        step = self._make_concrete_step()
        present = tmp_path / "c1.dat"
        present.write_text("h\nrow\n", encoding="utf-8")
        missing = tmp_path / "c2.dat"  # not created
        with pytest.raises(ValueError) as exc:
            step._self_consolidate_chunks(
                str(tmp_path), "X", "dat",
                [str(present), str(missing)], "|",
            )
        assert "c2.dat" in str(exc.value)
        assert "Refusing to consolidate" in str(exc.value)


class TestZeroChunkJob:
    """A scan that produced 0 chunks (legitimate 0-row result OR no
    partitions discovered) must NOT raise from self-consolidation.
    My first pass forced every job through self-consolidate which made
    a 0-chunk run fail with 'no non-empty chunk files'."""

    def test_execute_one_job_source_skips_self_consolidate_when_no_chunks(self):
        """Source-level: _execute_one_job must guard with
        ``if chunk_files:`` before calling _self_consolidate_chunks.

        2026-06-21 -- bumped window from 1500 -> 10000 chars because the
        ``if chunk_files:`` body grew with per-source completeness +
        checksum gates (commits b32d516..ebce142).  The ``else: ... no
        chunks to self-consolidate`` branch is now ~7300 chars past the
        marker (was ~600 originally).
        """
        src = (Path(ETL_ROOT) / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        idx = src.find("chunk_files = [r.file_path for r in successful]")
        assert idx > 0
        block = src[idx:idx + 10000]
        assert "if chunk_files:" in block
        assert "no chunks to self-consolidate" in block


class TestDispatcherPromotesPollingRowOutputDir:
    """The polling-service dispatcher promotes the polling-row's
    file_location (or output_file_location / output_dir alias) onto
    task['output_dir'].  NO invented paths -- if no polling column
    carries one, the step's per-job JSON output_file_location wins
    downstream."""

    def test_dispatcher_reads_polling_row_columns(self):
        src = (Path(ETL_ROOT) / "polling_service" / "dispatcher.py").read_text(encoding="utf-8")
        assert 'task.get("file_location")' in src
        assert 'task.get("output_file_location")' in src
        assert 'task["output_dir"] = fl' in src

    def test_dispatcher_does_not_invent_paths(self):
        """The previous version derived a fallback path from
        ``os.path.dirname(log_file)`` -- that was an invented path.
        Operator's principle: every write path comes from the polling
        row OR the per-job JSON, never from code-side derivation."""
        src = (Path(ETL_ROOT) / "polling_service" / "dispatcher.py").read_text(encoding="utf-8")
        # The previously-introduced derivation must NOT be present.
        # ``os`` is still imported for other reasons but the specific
        # ``os.path.dirname(log_file)`` derivation in the output_dir
        # promotion path is gone.
        # Search the for-loop block that does the promotion.
        idx = src.find('for task in tasks:')
        assert idx > 0
        end = src.find('# Execute steps sequentially', idx)
        block = src[idx:end]
        assert "os.path.dirname(log_file)" not in block
        assert "LOG_DIR" not in block  # not used as a fallback either

    def test_standalones_read_polling_row_columns(self):
        for rel in ("file_standalone.py", "file_to_oracle_standalone.py"):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            assert 'task.get("file_location")' in src
            assert 'task.get("output_file_location")' in src
            # And do NOT use run_report.output_dir as a derived fallback
            # (that was the earlier invented-path mistake).
            for_idx = src.find('for task in tasks:')
            assert for_idx > 0
            end_idx = src.find('await execute_tasks', for_idx)
            if end_idx == -1:
                end_idx = len(src)
            block = src[for_idx:end_idx]
            assert "run_report.output_dir" not in block
