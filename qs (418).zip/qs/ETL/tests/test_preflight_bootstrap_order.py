"""Regression guard: every standalone MUST run preflight_check at the
TOP of the file, BEFORE any 3rd-party / project imports.

User-reported bug #13 (2026-06-21): on a fresh OpenShift / Spark pod
without yaml / oracledb / pandas / trino pre-installed, the standalone
crashed at the first ``import yaml`` because preflight_check was called
AFTER that import (line ~680 in file_standalone.py, similarly mid-file
in the other 4 standalones).  Auto-install logic never got a chance.

Fix verified by this test: each standalone has a bootstrap block at
the top of the file (BEFORE ``import yaml`` / ``from workers.X``) that:
  1. Sets sys.path to include the ETL root
  2. Imports preflight (stdlib-only -- no chicken-and-egg)
  3. Calls preflight_check with auto_install=True

This test source-greps each standalone to confirm the order, so any
future refactor that breaks the contract trips immediately.
"""
from __future__ import annotations

import os
import re
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


_STANDALONES = [
    ("file_standalone.py", "file"),
    ("oracle_standalone.py", "oracle"),
    ("file_to_oracle_standalone.py", "file_to_oracle"),
    ("s3_query_standalone.py", "s3_query"),
    ("sap_odata_standalone.py", "sap_odata"),
]


def _read(rel_path: str) -> str:
    with open(os.path.join(_ETL_ROOT, rel_path), encoding="utf-8") as f:
        return f.read()


@pytest.mark.parametrize("filename,workflow", _STANDALONES)
def test_bootstrap_runs_before_yaml_import(filename, workflow):
    """The bootstrap _preflight_check(...) call must appear BEFORE the
    first ``import yaml`` line."""
    body = _read(filename)

    preflight_match = re.search(r"_preflight_check\(", body)
    yaml_match = re.search(r"^import yaml", body, flags=re.MULTILINE)

    assert preflight_match, (
        f"{filename} missing bootstrap _preflight_check(...) call at top. "
        f"Bug #13: without it, fresh OpenShift pods fail at the first "
        f"3rd-party import."
    )
    assert yaml_match, f"{filename} unexpectedly missing 'import yaml'"
    assert preflight_match.start() < yaml_match.start(), (
        f"{filename}: bootstrap _preflight_check at offset "
        f"{preflight_match.start()} must run BEFORE 'import yaml' at "
        f"offset {yaml_match.start()}.  Bug #13 regression."
    )


@pytest.mark.parametrize("filename,workflow", _STANDALONES)
def test_bootstrap_passes_correct_workflow(filename, workflow):
    """Bootstrap must pass the CORRECT workflow name (matches the
    standalone's purpose)."""
    body = _read(filename)
    # Find the bootstrap block (before the first regular import yaml).
    yaml_match = re.search(r"^import yaml", body, flags=re.MULTILINE)
    bootstrap_block = body[: yaml_match.start()] if yaml_match else body

    # Look for workflow="<name>" in the bootstrap block.
    wf_match = re.search(rf'workflow=["\']({workflow})["\']', bootstrap_block)
    assert wf_match, (
        f"{filename} bootstrap must call _preflight_check(workflow={workflow!r}, ...) "
        f"to match this standalone's purpose. Found block: "
        f"{bootstrap_block[-500:]!r}"
    )


@pytest.mark.parametrize("filename,workflow", _STANDALONES)
def test_bootstrap_enables_auto_install(filename, workflow):
    """Bootstrap must call with auto_install=True so fresh pods
    pip-install the required packages instead of crashing."""
    body = _read(filename)
    yaml_match = re.search(r"^import yaml", body, flags=re.MULTILINE)
    bootstrap_block = body[: yaml_match.start()] if yaml_match else body

    assert "auto_install=True" in bootstrap_block, (
        f"{filename} bootstrap must pass auto_install=True so missing "
        f"packages are pip-installed at startup.  Without this, the "
        f"fresh OpenShift pod still crashes."
    )


@pytest.mark.parametrize("filename,workflow", _STANDALONES)
def test_bootstrap_handles_missing_preflight_gracefully(filename, workflow):
    """Bootstrap must catch ImportError so deployments without
    preflight.py don't break (graceful degrade -- they'll hit the
    next ImportError with a slightly less helpful message)."""
    body = _read(filename)
    yaml_match = re.search(r"^import yaml", body, flags=re.MULTILINE)
    bootstrap_block = body[: yaml_match.start()] if yaml_match else body

    # Block must contain a try/except ImportError around the preflight import.
    assert "except ImportError:" in bootstrap_block, (
        f"{filename} bootstrap must wrap preflight import in "
        f"try/except ImportError for graceful degradation."
    )


def test_preflight_module_is_stdlib_only():
    """preflight.py itself must use only stdlib -- otherwise the
    bootstrap has a chicken-and-egg problem (can't import preflight
    until preflight's deps are installed, but preflight is what
    installs them)."""
    body = _read("preflight.py")
    # Only stdlib imports allowed at module top.
    # Extract all import lines from the top (before any class/function).
    lines = body.split("\n")
    for i, line in enumerate(lines):
        if line.startswith("def ") or line.startswith("class "):
            break
        stripped = line.strip()
        if stripped.startswith("import ") or stripped.startswith("from "):
            # Allow stdlib modules + nothing else
            stdlib_ok = any(line.lstrip().startswith(prefix) for prefix in [
                "from __future__",
                "import importlib", "import logging", "import subprocess",
                "import sys", "import os",
                "from dataclasses", "from typing", "from pathlib",
            ])
            assert stdlib_ok, (
                f"preflight.py line {i + 1}: {line!r} is not a stdlib "
                f"import.  Bootstrap can't pip-install preflight's own "
                f"dependencies -- preflight MUST be stdlib-only."
            )
