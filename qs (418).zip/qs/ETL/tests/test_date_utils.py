"""Tests for ETL/date_utils.normalize_business_date.

Locks the accepted-input matrix so a future tightening of the regex
doesn't silently break Airflow / ad-hoc invocations again.
"""
from __future__ import annotations

import os
import sys

import pytest

ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from date_utils import normalize_business_date  # noqa: E402


class TestNormalizeBusinessDate:
    @pytest.mark.parametrize("value,expected", [
        # legacy strict format — must still work
        ("14-07-2025", "14-07-2025"),
        ("30-06-2025", "30-06-2025"),
        # ISO 8601 (the format oracle_standalone's help suggests)
        ("2025-07-14", "14-07-2025"),
        ("2025-06-30", "30-06-2025"),
        # slashes (common paste from spreadsheets)
        ("14/07/2025", "14-07-2025"),
        ("2025/07/14", "14-07-2025"),
        # 2-digit year
        ("14-07-25", "14-07-2025"),
        ("14/07/25", "14-07-2025"),
        # month name forms
        ("14-Jul-2025", "14-07-2025"),
        ("14 Jul 2025", "14-07-2025"),
        ("14-July-2025", "14-07-2025"),
        # whitespace tolerated
        ("  14-07-2025  ", "14-07-2025"),
    ])
    def test_accepted_formats_normalised(self, value, expected):
        assert normalize_business_date(value) == expected

    @pytest.mark.parametrize("value", [
        "",
        "   ",
        "garbage",
        "14-13-2025",   # invalid month
        "32-01-2025",   # invalid day
        "2025-13-01",   # invalid month, ISO
        "07/14/2025",   # MM/DD/YYYY US ordering — intentionally rejected
                        # because day-first is the OTG convention; flagging
                        # the ambiguity is safer than silent mis-routing.
    ])
    def test_unaccepted_inputs_raise(self, value):
        with pytest.raises(ValueError) as exc_info:
            normalize_business_date(value)
        # Message should be operator-actionable.
        if value.strip():
            assert "Accepted" in str(exc_info.value) or "empty" in str(exc_info.value) \
                   or "required" in str(exc_info.value)

    def test_none_raises_required(self):
        with pytest.raises(ValueError, match="required"):
            normalize_business_date(None)  # type: ignore[arg-type]

    def test_alternate_target_format(self):
        """Target format is configurable for callers binding DD-MM-YY
        polling queries (SAP / s3_query / sb_to_oracle)."""
        assert normalize_business_date("2025-07-14", target_format="%d-%m-%y") == "14-07-25"
        assert normalize_business_date("14-07-2025", target_format="%Y-%m-%d") == "2025-07-14"

    def test_default_target_matches_sb_to_file_bind(self):
        """Default target MUST be DD-MM-YYYY — that's what
        polling_query_sb_to_file binds via TO_DATE(:2, 'DD-MM-YYYY')."""
        # 2026-06-12: regression guard.  If someone changes the default
        # to DD-MM-YY (matching the other workflows) without updating
        # file_standalone's polling query, the standalone will silently
        # query for the wrong date.  Lock the contract.
        from datetime import datetime
        out = normalize_business_date("2025-07-14")
        # Round-trip MUST parse as DD-MM-YYYY.
        datetime.strptime(out, "%d-%m-%Y")


class TestStandalonesWireTheHelper:
    """The strict regex must NOT come back to file_standalone.py or
    file_to_oracle_standalone.py — guarding against a future refactor
    re-introducing the brittle check."""

    def test_file_standalone_uses_normalize_business_date(self):
        from pathlib import Path
        src = (Path(ETL_ROOT) / "file_standalone.py").read_text(encoding="utf-8")
        assert "normalize_business_date" in src
        assert 'does not match dd-MM-yyyy' not in src, (
            "file_standalone.py still has the strict regex error — "
            "use normalize_business_date instead"
        )

    def test_file_to_oracle_standalone_uses_normalize_business_date(self):
        from pathlib import Path
        src = (Path(ETL_ROOT) / "file_to_oracle_standalone.py").read_text(encoding="utf-8")
        assert "normalize_business_date" in src
        assert 'does not match dd-MM-yyyy' not in src
