"""Sidecar lifecycle (2026-06-12).

Hygiene contract:
  * Run START -> any pre-existing sidecar is RENAMED to .bak_<ts>
    (backup_stale_sidecar).  A failed prior run's state is preserved
    for forensics but won't pollute the new run.
  * Run SUCCESS -> sidecar is DELETED (delete_sidecar).  It was a
    cross-step handoff; the run is complete; leaving it on NFS
    accumulates clutter AND would seed a future re-run with the
    same run_id with stale state.
  * Run FAILURE -> sidecar is KEPT (no delete call in the except
    branch).  Operator can inspect what happened.

Locked at the helper level + the standalone-wiring level.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. delete_sidecar helper ──────────────────────────────────────────


class TestDeleteSidecar:
    def test_removes_existing_sidecar(self, tmp_path):
        from steps.file.run_state import save_task_state, delete_sidecar, state_path
        run_id = 874757
        save_task_state({"run_id": run_id, "consolidated_file": "x.dat"},
                        str(tmp_path), run_id)
        path = state_path(str(tmp_path), run_id)
        assert os.path.exists(path)
        ok = delete_sidecar(str(tmp_path), run_id)
        assert ok is True
        assert not os.path.exists(path)

    def test_missing_sidecar_is_noop_not_error(self, tmp_path):
        from steps.file.run_state import delete_sidecar
        # No sidecar at this path -> returns False, doesn't raise.
        assert delete_sidecar(str(tmp_path), 99) is False

    def test_run_id_none_or_empty_dir_returns_false(self, tmp_path):
        from steps.file.run_state import delete_sidecar
        assert delete_sidecar(str(tmp_path), None) is False
        assert delete_sidecar("", 1) is False


# ─── 2. backup_stale_sidecar helper ────────────────────────────────────


class TestBackupStaleSidecar:
    def test_renames_existing_sidecar_to_bak_with_timestamp(self, tmp_path):
        # save_state writes the dict verbatim; save_task_state filters to
        # _SIDECAR_KEYS, so the test uses save_state to carry a forensic
        # marker (`stale`) through to assertions.
        from steps.file.run_state import save_state, backup_stale_sidecar, state_path
        run_id = 42
        save_state({"run_id": run_id, "stale": True}, str(tmp_path), run_id)
        original = state_path(str(tmp_path), run_id)
        assert os.path.exists(original)

        backup = backup_stale_sidecar(str(tmp_path), run_id)
        assert backup is not None
        assert backup.startswith(original)
        # Filename pattern: <original>.bak_YYYYMMDD_HHMMSS
        import re
        assert re.search(r"\.bak_\d{8}_\d{6}(?:\.\d+)?$", backup)
        # Original gone, backup carries the prior payload.
        assert not os.path.exists(original)
        assert os.path.exists(backup)
        with open(backup, "r", encoding="utf-8") as f:
            data = json.load(f)
        assert data.get("stale") is True

    def test_no_existing_sidecar_returns_none_silently(self, tmp_path):
        from steps.file.run_state import backup_stale_sidecar
        assert backup_stale_sidecar(str(tmp_path), 1) is None

    def test_idempotent_on_second_call(self, tmp_path):
        from steps.file.run_state import save_state, backup_stale_sidecar, state_path
        run_id = 7
        save_state({"run_id": run_id}, str(tmp_path), run_id)
        first = backup_stale_sidecar(str(tmp_path), run_id)
        # Sidecar removed by the first backup; second call: nothing to back up.
        second = backup_stale_sidecar(str(tmp_path), run_id)
        assert first is not None
        assert second is None

    def test_sub_second_collision_appends_counter(self, tmp_path):
        """If two backups land in the same second (unlikely on real NFS
        but possible in tests), the second appends a numeric suffix
        instead of overwriting the first."""
        from steps.file.run_state import save_state, backup_stale_sidecar, state_path
        run_id = 13
        save_state({"v": 1}, str(tmp_path), run_id)
        first = backup_stale_sidecar(str(tmp_path), run_id)
        assert first is not None

        # Recreate the sidecar with new content, force timestamp collision.
        save_state({"v": 2}, str(tmp_path), run_id)
        # Lock the timestamp by patching datetime to the SAME second.
        from steps.file import run_state as rs
        from unittest.mock import patch

        class _FakeDT:
            @staticmethod
            def now():
                class _T:
                    def strftime(self, _fmt):
                        return first.split(".bak_")[1].split(".")[0]
                return _T()

        with patch.object(rs, "_datetime", _FakeDT):
            second = backup_stale_sidecar(str(tmp_path), run_id)
        assert second is not None
        assert second != first
        # Second backup should have the counter suffix.
        assert second.endswith(".1")
        # And the FIRST backup is intact (not overwritten).
        with open(first, "r", encoding="utf-8") as f:
            assert json.load(f)["v"] == 1
        with open(second, "r", encoding="utf-8") as f:
            assert json.load(f)["v"] == 2


# ─── 3. Standalone wiring locks (source-level) ─────────────────────────


class TestStandalonesWireLifecycle:
    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
        "polling_service/dispatcher.py",
    ])
    def test_imports_helpers(self, rel):
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        assert "delete_sidecar" in src, f"{rel}: must import/use delete_sidecar"
        assert "backup_stale_sidecar" in src, f"{rel}: must import/use backup_stale_sidecar"

    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
    ])
    def test_backup_called_before_execute_tasks(self, rel):
        """Pre-run hygiene must fire BEFORE execute_tasks runs --
        otherwise a step's hydrate could pick up a stale sidecar
        before backup_stale_sidecar gets the chance to rename it."""
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        backup_idx = src.find("backup_stale_sidecar(")
        exec_idx = src.find("await execute_tasks(")
        assert backup_idx > 0
        assert exec_idx > 0
        assert backup_idx < exec_idx, (
            f"{rel}: backup_stale_sidecar must be called BEFORE execute_tasks"
        )

    def test_dispatcher_backup_before_loop_delete_only_on_success(self):
        """polling_service/dispatcher.py must wire backup BEFORE the
        worker.execute_step loop and delete ONLY when every task
        completed successfully -- specifically using a `_all_succeeded
        = True` flip AFTER the loop (positive-success pattern), so
        BaseException (KeyboardInterrupt, asyncio.CancelledError) ALSO
        keeps the sidecar for forensics."""
        src = (Path(ETL_ROOT) / "polling_service/dispatcher.py").read_text(encoding="utf-8")
        backup_idx = src.find("backup_stale_sidecar(")
        loop_idx = src.find("await worker.execute_step(")
        assert backup_idx > 0 and loop_idx > 0
        assert backup_idx < loop_idx, (
            "dispatcher: backup_stale_sidecar must run BEFORE execute_step loop"
        )
        # Positive-success pattern: flag flipped TRUE only after the
        # whole loop completes; delete guarded by `if _all_succeeded:`.
        assert "_all_succeeded = True" in src, (
            "dispatcher: must use positive-success pattern (_all_succeeded = True)"
        )
        assert "if _all_succeeded:" in src, (
            "dispatcher: delete must be guarded by `if _all_succeeded:`"
        )
        # Delete after the guard.
        delete_idx = src.find("delete_sidecar(")
        guard_idx = src.find("if _all_succeeded:")
        assert delete_idx > guard_idx, (
            "dispatcher: delete_sidecar must live inside the success guard"
        )
        # Sanity: success flip is AFTER the for-loop body, not before.
        success_flip_idx = src.find("_all_succeeded = True")
        # Last execute_step call before the flip.
        last_execute_idx = src.rfind("await worker.execute_step(", 0, success_flip_idx)
        assert last_execute_idx > 0 and last_execute_idx < success_flip_idx, (
            "dispatcher: _all_succeeded flip must come AFTER the for-loop"
        )

    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
    ])
    def test_delete_called_in_success_branch_only(self, rel):
        """delete_sidecar must appear in the try (success) block,
        NOT in the except (failure) block.  Failure must KEEP the
        sidecar for forensics."""
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        # Find the try/except block around execute_tasks.  The success
        # block's `try:` lives BEFORE `await execute_tasks(`; the inner
        # `try:` that the except branch wraps around cleanup_on_failure
        # is irrelevant here — locate the OUTER try.
        exec_idx = src.find("await execute_tasks(")
        try_idx = src.rfind("try:", 0, exec_idx)
        except_idx = src.find("except Exception", exec_idx)
        finally_idx = src.find("finally:", except_idx)
        if finally_idx == -1:
            finally_idx = len(src)
        success_block = src[try_idx:except_idx]
        failure_block = src[except_idx:finally_idx]

        assert "delete_sidecar(" in success_block, (
            f"{rel}: delete_sidecar must be called in the success branch"
        )
        assert "delete_sidecar(" not in failure_block, (
            f"{rel}: delete_sidecar must NOT be called in the failure "
            f"branch -- sidecar is forensic evidence and must survive"
        )


# ─── 4. Per-run stable sidecar_dir contract ────────────────────────────


class TestSidecarDirHonored:
    """task['sidecar_dir'] decouples sidecar location from per-task
    output_dir.  Without this, CLOUD step writes to one location, ONPREM
    to another, ConsolidateFiles to a third -- and cross-step state is
    lost because each hydrate looks at a different path.

    The standalones inject task['sidecar_dir'] = dirname(log_file)
    (per-run stable).  save_task_state + hydrate_task_from_sidecar
    MUST prefer it over the passed base_output_dir."""

    def test_save_task_state_writes_to_sidecar_dir_not_base(self, tmp_path):
        from steps.file.run_state import save_task_state, state_path
        # output_dir is per-row (varies); sidecar_dir is per-run (stable).
        per_row = tmp_path / "row_specific"
        stable = tmp_path / "log_dir"
        per_row.mkdir()
        stable.mkdir()
        task = {
            "run_id": 100,
            "sidecar_dir": str(stable),
            "output_dir": str(per_row),
            "consolidated_file": "/some/file.dat",
        }
        path = save_task_state(task, str(per_row), 100)
        # Wrote to stable, NOT per_row.
        assert path == state_path(str(stable), 100)
        assert os.path.exists(state_path(str(stable), 100))
        assert not os.path.exists(state_path(str(per_row), 100))

    def test_hydrate_reads_from_sidecar_dir_not_base(self, tmp_path):
        from steps.file.run_state import (
            save_task_state, hydrate_task_from_sidecar,
        )
        stable = tmp_path / "log_dir"
        per_row_a = tmp_path / "cloud_dir"
        per_row_b = tmp_path / "onprem_dir"
        stable.mkdir(); per_row_a.mkdir(); per_row_b.mkdir()

        # Step A (CLOUD) saves with sidecar_dir=stable, output_dir=per_row_a
        writer = {
            "run_id": 200,
            "sidecar_dir": str(stable),
            "output_dir": str(per_row_a),
            "chunk_files": ["cloud_chunk.dat"],
            "consolidated_file": "cloud.dat",
        }
        save_task_state(writer, str(per_row_a), 200)

        # Step B (ONPREM) hydrates with sidecar_dir=stable, output_dir=per_row_b
        reader = {
            "run_id": 200,
            "sidecar_dir": str(stable),
            "output_dir": str(per_row_b),
        }
        hydrated = hydrate_task_from_sidecar(reader, str(per_row_b), 200)
        assert hydrated is True
        # Saw CLOUD's state even though its own output_dir is per_row_b.
        assert reader.get("chunk_files") == ["cloud_chunk.dat"]
        assert reader.get("consolidated_file") == "cloud.dat"

    def test_backward_compat_no_sidecar_dir_falls_back_to_base(self, tmp_path):
        from steps.file.run_state import save_task_state, state_path
        task = {
            "run_id": 300,
            "consolidated_file": "x.dat",
        }
        path = save_task_state(task, str(tmp_path), 300)
        assert path == state_path(str(tmp_path), 300)


class TestStandalonesInjectSidecarDir:
    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
        "polling_service/dispatcher.py",
    ])
    def test_dispatch_sites_set_sidecar_dir_from_log_dir(self, rel):
        """Every task gets task['sidecar_dir'] set to a per-run-stable
        path inside the dispatch loop -- in BOTH the standalone entry
        points AND the polling-service dispatcher.  Without this the
        cross-step state-handoff regresses to per-row sidecars on
        whichever path is missing the injection."""
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        assert 'task["sidecar_dir"] = sidecar_dir' in src or \
               "task['sidecar_dir'] = sidecar_dir" in src, (
            f"{rel}: must inject task['sidecar_dir'] in dispatch loop"
        )
        # And that sidecar_dir must be derived from log_file (per-run stable).
        assert "os.path.dirname(log_file)" in src, (
            f"{rel}: sidecar_dir must be derived from log_file dir"
        )


# ─── 5. Cross-source merge contract (CLOUD + ONPREM accumulate) ────────


class TestCrossSourceMerge:
    """Two starburst steps (CLOUD then ONPREM, or vice versa) MUST
    accumulate their chunk_files + job_results in the sidecar so
    ConsolidateFiles downstream sees BOTH sources.  Without this the
    second step overwrites the first's state and the merge silently
    drops one source -- the exact failure the operator reported on
    2026-06-12 (CTL failed because ConsolidateFiles only saw ONPREM)."""

    def test_starburst_base_merges_with_prior_sidecar_state(self, tmp_path):
        """Lock the source-level merge pattern in starburst_file_base.py.
        The code must hydrate prior state and prepend it before saving."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # Must hydrate before re-saving (the merge prelude).
        assert "load_state" in src or "_existing_state" in src, (
            "starburst_file_base must hydrate prior sidecar state before saving"
        )
        # Must combine prior + this step's results, not overwrite.
        assert "prior_chunks + all_chunk_files" in src, (
            "must prepend prior chunks instead of overwriting"
        )
        assert "prior_jobs + results" in src, (
            "must prepend prior job_results instead of overwriting"
        )

    def test_starburst_spark_base_merges_with_prior_sidecar_state(self):
        from steps.file import starburst_file_spark_base
        src = Path(starburst_file_spark_base.__file__).read_text(encoding="utf-8")
        assert "load_state" in src
        assert "prior_chunks + all_chunks" in src
        assert "prior_jobs + results" in src

    @pytest.mark.parametrize("rel", [
        "steps/file/starburst_file_base.py",
        "steps/file/starburst_file_spark_base.py",
    ])
    def test_starburst_step_republishes_merged_counts_to_run_report(self, rel):
        """After the cross-source merge, the step MUST re-publish counts
        to run_report so a mid-run failure (before the standalone's
        final set_counts) leaves a forensically-correct HTML report.
        Without this, the report shows only the LAST source's totals
        (e.g. ONPREM 2878 expected when CLOUD+ONPREM = 3878)."""
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        # The merge code must include a re-publish gated on `prior_jobs`
        # (so single-source runs don't double-set with the same value).
        assert "if prior_jobs:" in src, (
            f"{rel}: must gate re-publish on prior_jobs"
        )
        # The re-publish must call set_counts with merged_expected.
        assert "merged_expected" in src, (
            f"{rel}: merged_expected must be defined and used"
        )
        # Verify set_counts appears AFTER the merge code (positional check).
        merge_marker = "prior_jobs"
        first_merge = src.find(merge_marker)
        last_set_counts = src.rfind("set_counts(")
        assert first_merge > 0 and last_set_counts > 0
        assert last_set_counts > first_merge, (
            f"{rel}: re-publish set_counts must come AFTER merge code"
        )

    def test_round_trip_two_sources_through_sidecar(self, tmp_path):
        """Direct unit test: simulate CLOUD save, then ONPREM hydrate +
        save with merge -- the final sidecar must carry BOTH sources."""
        from steps.file.run_state import save_state, load_state

        sidecar_dir = str(tmp_path)
        run_id = 555

        # Step 1: CLOUD step persists its results.
        cloud_state = {
            "run_id": run_id,
            "chunk_files": ["/data/cloud_chunk_0.dat"],
            "job_results": [{
                "report_id": 31, "datasource": "CLOUD",
                "records": 1000, "expected_total": 1000,
                "chunk_files": ["/data/cloud_chunk_0.dat"],
            }],
            "expected_total": 1000,
            "sum_chunk_actual": 1000,
            "totalcount": 1000,
        }
        save_state(cloud_state, sidecar_dir, run_id)

        # Step 2: ONPREM step starts. Simulate the merge-then-save the
        # starburst step now performs.
        existing = load_state(sidecar_dir, run_id) or {}
        prior_chunks = list(existing.get("chunk_files") or [])
        prior_jobs = list(existing.get("job_results") or [])

        onprem_chunks = ["/data/onprem_chunk_0.dat"]
        onprem_results = [{
            "report_id": 31, "datasource": "ONPREM",
            "records": 2878, "expected_total": 2878,
            "chunk_files": onprem_chunks,
        }]

        merged = {
            "run_id": run_id,
            "chunk_files": prior_chunks + onprem_chunks,
            "job_results": prior_jobs + onprem_results,
            "expected_total": 2878 + sum(j["expected_total"] for j in prior_jobs),
            "sum_chunk_actual": 2878 + sum(j["records"] for j in prior_jobs),
        }
        save_state(merged, sidecar_dir, run_id)

        # Step 3: ConsolidateFiles hydrates -- must see BOTH sources.
        final = load_state(sidecar_dir, run_id)
        assert final is not None
        assert len(final["chunk_files"]) == 2
        assert "/data/cloud_chunk_0.dat" in final["chunk_files"]
        assert "/data/onprem_chunk_0.dat" in final["chunk_files"]
        assert len(final["job_results"]) == 2
        sources = {j["datasource"] for j in final["job_results"]}
        assert sources == {"CLOUD", "ONPREM"}
        # Counts aggregate across sources (3878 = 1000 + 2878).
        assert final["expected_total"] == 3878
        assert final["sum_chunk_actual"] == 3878


# ─── 6. Uncompressed-workflow fallback in CreateControlFile ────────────


class TestCreateCtlUncompressedFallback:
    """When the polling rows don't include a CompressFile step (the OG
    ETL uncompressed-delivery workflow whose CTL templates reference
    .dat directly), CreateControlFile MUST fall back to
    consolidation_results / consolidated_file rather than crash with
    'CompressFile must run first'.  Locks the 2026-06-13 fix to the
    operator's recurring failure."""

    def test_source_contains_consolidation_results_fallback(self):
        from steps.file import create_ctl_file
        src = Path(create_ctl_file.__file__).read_text(encoding="utf-8")
        # Must check task["consolidation_results"] when compress missing.
        assert 'task.get("consolidation_results"' in src, (
            "must fall back to consolidation_results when compress_results "
            "and compressed_file are both absent"
        )
        # Must also handle consolidated_file last-resort.
        assert 'task.get("consolidated_file")' in src, (
            "must have last-resort fallback to consolidated_file"
        )
        # The error message must call out the WHOLE chain that's missing,
        # not just 'CompressFile must run first' (which is misleading
        # when CompressFile was never in the polling rows).
        assert "ConsolidateFiles must have produced" in src, (
            "error message must explain the actual minimum requirement"
        )

    def test_ctl_filename_works_for_dat_input(self):
        """Reference contract: <base>.dat -> <base>.ctl."""
        from steps.file.create_ctl_file import CreateControlFile
        assert CreateControlFile._ctl_filename_for("report.dat") == "report.ctl"
        # The .gz case (kept for back-compat with the compressed path).
        assert CreateControlFile._ctl_filename_for("report.dat.gz") == "report.dat.ctl"

    def test_render_strips_datasource_marker_from_template(self):
        """CTL CONTENT must have _CLOUD./_ONPREM. stripped (so the CTL
        references the canonical merged filename, not the per-source
        intermediate that ConsolidateFiles already deleted)."""
        from steps.file.create_ctl_file import CreateControlFile
        template = (
            "File_Name,report_CLOUD.dat\n"
            "Number_Of_Records,1000\n"
            "MD5_SUM,{md5_checksum}\n"
        )
        out = CreateControlFile._render(template, {"md5_checksum": "{md5_checksum}"})
        # _CLOUD. stripped -> canonical filename in CTL.
        assert "report.dat" in out
        assert "_CLOUD." not in out
        # md5 placeholder preserved verbatim for Autosys shell.
        assert "{md5_checksum}" in out


# ─── 7. backup_if_exists -- backup or delete prior-run files ──────────


class TestCheckDiskSpace:
    """170M-record concern: silent disk-fill at hour 5 of an 8-hour
    extract is the worst-case failure.  check_disk_space() fires
    BEFORE the extract starts so the failure is upfront."""

    def test_returns_none_when_enough_free(self, tmp_path):
        from steps.file.run_state import check_disk_space
        # 100 rows * 200 B/row * 4x safety = 80 KB.  tmp_path always
        # has more free than that.
        assert check_disk_space(str(tmp_path), expected_rows=100) is None

    def test_returns_shortage_dict_when_insufficient(self, tmp_path):
        from steps.file.run_state import check_disk_space
        # 1e15 rows * 200 B * 4 = 800 PB -- nobody has that.
        shortage = check_disk_space(str(tmp_path), expected_rows=10**15)
        assert shortage is not None
        assert "free" in shortage
        assert "need" in shortage
        assert "shortage" in shortage
        assert shortage["need"] > shortage["free"]
        assert shortage["shortage"] == shortage["need"] - shortage["free"]

    def test_skips_when_expected_rows_unknown(self, tmp_path):
        from steps.file.run_state import check_disk_space
        assert check_disk_space(str(tmp_path), expected_rows=None) is None
        assert check_disk_space(str(tmp_path), expected_rows=0) is None

    def test_skips_when_output_dir_missing(self):
        from steps.file.run_state import check_disk_space
        assert check_disk_space("", expected_rows=1000) is None

    def test_skips_when_disk_usage_fails(self, tmp_path, monkeypatch):
        """Best-effort: never block the run on a measurement failure."""
        from steps.file.run_state import check_disk_space
        import shutil as _sh
        monkeypatch.setattr(
            _sh, "disk_usage",
            lambda p: (_ for _ in ()).throw(OSError("simulated NFS failure")),
        )
        # Returns None instead of raising.
        assert check_disk_space(str(tmp_path), expected_rows=100) is None


class TestPreserveChunksOnFailure:
    """170M-record concern: a late-partition failure must not wipe
    169 successful chunks.  Operator opts in via
    preserve_chunks_on_failure=True."""

    def test_default_off_preserves_back_compat(self, tmp_path):
        from steps.file.run_state import RunArtifacts
        art = RunArtifacts()
        chunk_a = tmp_path / "chunk_a.dat"
        chunk_a.write_text("x", encoding="utf-8")
        art.add(str(chunk_a), RunArtifacts.CHUNK)
        removed = art.cleanup_on_failure()
        assert removed == 1
        assert not chunk_a.exists()

    def test_on_skips_chunks_keeps_consolidated_cleanup(self, tmp_path):
        from steps.file.run_state import RunArtifacts
        art = RunArtifacts(preserve_chunks_on_failure=True)
        chunk_a = tmp_path / "chunk_a.dat"
        cons = tmp_path / "merged.dat"
        chunk_a.write_text("x", encoding="utf-8")
        cons.write_text("y", encoding="utf-8")
        art.add(str(chunk_a), RunArtifacts.CHUNK)
        art.add(str(cons), RunArtifacts.CONSOLIDATED)
        art.cleanup_on_failure()
        # Chunk survived; consolidated wiped.
        assert chunk_a.exists()
        assert not cons.exists()

    def test_standalones_thread_the_flag(self):
        from pathlib import Path
        for rel in ("file_standalone.py", "file_to_oracle_standalone.py"):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            assert "preserve_chunks_on_failure" in src, (
                f"{rel}: must thread preserve_chunks_on_failure"
            )
            assert "_preserve_chunks" in src


class TestPollingRowOverlay:
    """Operator request 2026-06-13: 'I will add in polling query, can't
    modify queryjson.'  The polling row must be able to drive every
    per-job knob WITHOUT touching the per-query JSON.  Lookup is
    case-insensitive (Oracle drivers vary).  Empty / NULL columns are
    silently skipped so partial overrides work."""

    def test_overlay_lifts_partition_column_from_polling_row(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        job_config = {"generated_sql": "SELECT 1"}
        task = {"partition_column": "business_date", "partition_enabled": "TRUE"}
        _overlay_polling_row_onto_job_config(job_config, task)
        assert job_config["partition_config"]["partition_column"] == "business_date"
        assert job_config["partition_config"]["enabled"] is True

    def test_overlay_is_case_insensitive(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        job_config = {"generated_sql": "SELECT 1"}
        task = {"PARTITION_COLUMN": "business_date", "PARTITION_ENABLED": "Y"}
        _overlay_polling_row_onto_job_config(job_config, task)
        assert job_config["partition_config"]["partition_column"] == "business_date"
        assert job_config["partition_config"]["enabled"] is True

    def test_overlay_lifts_bucketing_knobs_from_polling_row(self):
        """2026-06-17 -- bucket_strategy + bucket_size + max_partitions
        must all be drivable from the polling row.  Operator wants:
            partition_column='FACT_table.SAP_COMPANY_ID', max_partitions=150,
            bucket_strategy='auto'
        ...without touching the per-query JSON."""
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        job_config = {"generated_sql": "SELECT 1"}
        task = {
            "partition_column": "FACT_table.SAP_COMPANY_ID",
            "max_partitions": "150",
            "bucket_strategy": "auto",
        }
        _overlay_polling_row_onto_job_config(job_config, task)
        pc = job_config["partition_config"]
        assert pc["partition_column"] == "FACT_table.SAP_COMPANY_ID"
        assert pc["max_partitions"] == 150
        assert pc["bucket_strategy"] == "auto"

    def test_overlay_bucketing_knobs_case_insensitive(self):
        """Polling row column may arrive UPPER (Oracle default) -- the
        overlay must accept BUCKET_STRATEGY / BUCKET_SIZE / MAX_PARTITIONS
        too."""
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        jc = {"generated_sql": "x"}
        _overlay_polling_row_onto_job_config(jc, {
            "BUCKET_STRATEGY": "auto",
            "BUCKET_SIZE": "8",
            "MAX_PARTITIONS": "150",
        })
        assert jc["partition_config"]["bucket_strategy"] == "auto"
        assert jc["partition_config"]["bucket_size"] == 8
        assert jc["partition_config"]["max_partitions"] == 150

    def test_overlay_coerces_bool_strings(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        for truthy in ("TRUE", "Y", "1", "yes", "T"):
            jc = {"generated_sql": "x"}
            _overlay_polling_row_onto_job_config(jc, {"skip_pre_flight_count": truthy})
            assert jc["skip_pre_flight_count"] is True, f"{truthy!r} should be True"
        for falsey in ("FALSE", "N", "0", "no"):
            jc = {"generated_sql": "x"}
            _overlay_polling_row_onto_job_config(jc, {"skip_pre_flight_count": falsey})
            assert jc["skip_pre_flight_count"] is False, f"{falsey!r} should be False"

    def test_overlay_coerces_numeric_strings(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        jc = {"generated_sql": "x"}
        _overlay_polling_row_onto_job_config(jc, {
            "max_partitions": "750",
            "avg_row_bytes": "300",
            "disk_safety_factor": "3.5",
            "writer_idle_timeout_seconds": "1800",
        })
        assert jc["partition_config"]["max_partitions"] == 750
        assert jc["avg_row_bytes"] == 300
        assert jc["disk_safety_factor"] == 3.5
        assert jc["writer_idle_timeout_seconds"] == 1800

    def test_overlay_ignores_empty_and_null_columns(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        jc = {"generated_sql": "x", "max_partitions": 500}
        task = {"max_partitions": "", "partition_column": None}
        # When jc has no nested partition_config + task is empty, the
        # function shouldn't invent a partition_config dict at all.
        _overlay_polling_row_onto_job_config(jc, task)
        # The empty / None polling-row values left jc alone.
        assert jc.get("partition_config", {}).get("partition_column") is None

    def test_overlay_polling_row_wins_over_json(self):
        """Operator's whole point: when polling row sets a value, it
        overrides whatever the per-query JSON has."""
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        jc = {
            "generated_sql": "x",
            "partition_config": {
                "enabled": False,
                "partition_column": "old_col",
                "max_partitions": 100,
            },
        }
        task = {
            "partition_enabled": "TRUE",
            "partition_column": "new_col",
            "max_partitions": "750",
        }
        _overlay_polling_row_onto_job_config(jc, task)
        assert jc["partition_config"]["enabled"] is True
        assert jc["partition_config"]["partition_column"] == "new_col"
        assert jc["partition_config"]["max_partitions"] == 750

    def test_overlay_covers_all_170M_knobs(self):
        """All four 170M-hardening knobs (A/B-adjacent/D/E) must be
        threadable from the polling row."""
        from steps.file.starburst_file_base import (
            _POLLING_ROW_OVERLAYS, _overlay_polling_row_onto_job_config,
        )
        polling_keys = {k for k, _, _ in _POLLING_ROW_OVERLAYS}
        # Each of these knobs MUST be polling-row driveable for 170M.
        required = {
            "partition_column", "partition_enabled", "max_partitions",
            "discovery_mode", "derive_g1_from_discovery",
            "skip_pre_flight_count", "avg_row_bytes",
            "disk_safety_factor", "writer_idle_timeout_seconds",
            "max_chunk_retries",
        }
        missing = required - polling_keys
        assert not missing, f"missing polling-row overlay for: {missing}"

    def test_overlay_handles_no_task(self):
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        jc = {"generated_sql": "x"}
        # Should be a no-op, not raise.
        _overlay_polling_row_onto_job_config(jc, None)
        _overlay_polling_row_onto_job_config(jc, {})


class TestG1Acquisition:
    """170M concern: SELECT COUNT(*) FROM (base) is a full scan -- on a
    170M-row table it's 5-15 minutes of Trino burn that we then repeat
    via partition discovery's GROUP BY.  When `derive_g1_from_discovery`
    is true (default), the COUNT is SKIPPED for partition+group_by
    mode and G1 comes from the discovery sum (same plan, same number).
    `skip_pre_flight_count` is the escape hatch when COUNT itself
    times out / OOMs."""

    def test_starburst_base_supports_g1_knobs(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # Both knobs readable from per-job JSON via the bool-coerce helper
        # (deep-dive #3 -- accepts quoted "false" / "FALSE" / "0" as opt-out).
        assert '_job_bool("derive_g1_from_discovery", True)' in src
        assert '_job_bool("skip_pre_flight_count", False)' in src
        # Deferred branch logged so operator sees savings.
        assert "G1 acquisition: DEFERRED" in src
        # Skip branch logged.
        assert "G1 acquisition: SKIPPED" in src

    def test_scan_plan_carries_g1_source(self):
        from steps.file.starburst_file_base import ScanPlan, ScanMode
        plan = ScanPlan(
            mode=ScanMode.PARTITION_VALUES,
            base_sql="SELECT 1",
            expected_total=100,
            g1_source="partition discovery sum [3.2s]",
        )
        assert plan.g1_source == "partition discovery sum [3.2s]"

    def test_scan_plan_expected_total_optional(self):
        """ScanPlan must accept expected_total=None for the deferred
        / skipped G1 cases (no upfront anchor)."""
        from steps.file.starburst_file_base import ScanPlan, ScanMode
        plan = ScanPlan(
            mode=ScanMode.SINGLE,
            base_sql="SELECT 1",
            expected_total=None,
            g1_source="deferred (measured from extract)",
        )
        assert plan.expected_total is None

    def test_run_report_renders_g1_source_in_ledger(self, tmp_path):
        """When the step pushes g1_source via set_counts, the HTML G1
        ledger row shows the source so the operator can see whether
        the anchor is authoritative or derived."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_counts(
            expected_total=170_000_000,
            g1_source="partition discovery sum [12.4s]",
        )
        html_out = rr.to_html()
        # G1 chip + label include the source.
        assert "partition discovery sum" in html_out
        assert "170,000,000" in html_out


class TestPartitionDiscoveryModeKnob:
    """170M-record concern: GROUP BY on a high-cardinality column on
    170M rows can OOM Trino.  partition_config.discovery_mode='distinct'
    uses DISTINCT instead; group_by mode FALLS BACK to distinct on a
    RETRYABLE GROUP BY error (typical Trino OOM signal)."""

    def test_starburst_base_supports_discovery_mode_knob(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The knob is read from partition_cfg.
        assert 'partition_cfg.get("discovery_mode")' in src
        # Distinct fallback path exists in _discover_partition_values.
        assert "_try_distinct" in src
        assert "_try_group_by" in src
        # Fallback only fires on RETRYABLE classification.
        assert "err.is_retryable" in src


class TestPartitionByDefault:
    """2026-06-17 -- partition-by-default + silent SINGLE fallback.

    Contract:
      1. `partition_config.enabled` unspecified -> inherits from whether
         partition_column is set.
      2. Operator explicit `enabled=True` + missing partition_column ->
         WARN + run SINGLE (don't silently ignore intent).
      3. FORCE_MODE=PARTITION_VALUES + missing partition_column ->
         WARN + fall back to SINGLE (no raise).
      4. `partition_column = ""` / whitespace is normalised to None.
      5. JSON-side `enabled` value goes through _coerce_polling_value so
         quoted `"false"` opt-out is honoured (plain bool() would return
         True for the non-empty string).
      6. Fallback ScanPlan's g1_source is re-anchored to truthful label
         when discovery never ran.
    """

    def test_enabled_default_inherits_from_partition_column_presence(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # cfg_enabled defaults from partition_column presence when enabled
        # is unspecified.
        assert "cfg_enabled = bool(partition_column)" in src

    def test_enabled_uses_coerce_polling_value_not_plain_bool(self):
        """JSON path must accept quoted bool strings the same way the
        polling overlay does -- otherwise `enabled: \"false\"` silently
        becomes True (operator opt-out lost)."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        assert '_coerce_polling_value(_enabled_raw, "bool")' in src

    def test_partition_column_defensive_strip(self):
        """`"   "` / `""` must normalise to None so the no-set branch
        fires correctly."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        assert "_raw_column.strip()" in src
        assert "isinstance(_raw_column, str)" in src

    def test_warn_on_silent_operator_intent_drop(self):
        """When operator sets enabled=True but forgets partition_column,
        the planner WARNs instead of silently dropping the intent."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        assert "partitioning request IGNORED" in src
        assert "_enabled_coerced is True and not partition_column" in src

    def test_force_mode_no_column_falls_back_to_single_not_raises(self):
        """FORCE_MODE=PARTITION_VALUES with no partition_column must
        WARN and return a SINGLE-mode ScanPlan instead of raising
        ValueError (no-fail contract from 2026-06-17)."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The old raise must be GONE.
        assert (
            'raise ValueError(\n                "PARTITION_VALUES mode requested'
            not in src
        )
        # And the SINGLE-fallback return must exist inside the
        # PARTITION_VALUES branch (with the partition_column-missing WARN).
        assert "falling back to SINGLE mode" in src
        # AND the fallback re-anchors g1_source so the run report
        # doesn't lie about a partition discovery that never happened.
        assert "_fallback_g1_source" in src

    def test_no_raise_value_error_for_missing_partition_column(self):
        """Regression guard: the historic
        `raise ValueError(\"PARTITION_VALUES mode requested but ...\")`
        must stay gone -- the user explicitly asked for go-with-normal."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        assert "PARTITION_VALUES mode requested but partition_config.partition_column not set" not in src


class TestBoolKnobCoercion:
    """2026-06-17 deep-dive #3 -- every per-job JSON bool knob must go
    through `_job_bool` (which delegates to `_coerce_polling_value`) so
    that operator-quoted "false" / "FALSE" / "0" / "no" honours the
    opt-out.  Plain `bool("false")` returns True in Python -- the JSON
    path had this gotcha on 4 separate knobs."""

    BOOL_KNOBS = (
        # (knob_name, default_value)
        ("fail_on_mismatch", "True"),
        ("derive_g1_from_discovery", "True"),
        ("skip_pre_flight_count", "False"),
        ("skip_disk_check", "False"),
    )

    def test_every_bool_knob_uses_job_bool_helper(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        for knob, default in self.BOOL_KNOBS:
            expected = f'_job_bool("{knob}", {default})'
            assert expected in src, f"{knob}: expected `{expected}` in source"

    def test_no_legacy_plain_bool_on_job_config_get(self):
        """Regression guard: any new `bool(job_config.get(...))` patterns
        for a bool knob re-introduce the quoted-string gotcha."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        for knob, _ in self.BOOL_KNOBS:
            forbidden = f'bool(job_config.get("{knob}"'
            assert forbidden not in src, (
                f"{knob}: plain `bool(job_config.get(...))` re-introduced -- "
                f"quoted YAML \"false\" silently becomes True"
            )

    def test_job_bool_helper_defined(self):
        """The helper itself is defined inside _build_scan_plan and
        delegates to _coerce_polling_value with 'bool' coerce_type."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        assert "def _job_bool(key: str, default: bool) -> bool:" in src
        assert '_coerce_polling_value(job_config.get(key), "bool")' in src


class TestDiscoveryModeCaseInsensitive:
    """2026-06-17 deep-dive #3 -- `discovery_mode` comparison at line
    947 (defer_count_to_discovery) AND line 1267 (group_by vs distinct
    branch) is case-sensitive.  Oracle polling rows commonly arrive
    uppercase; the comparison would silently fall through to default
    group_by and ignore operator intent."""

    def test_discovery_mode_normalised_lowercase(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The read site strips + lowercases.
        assert ".strip().lower()" in src
        # The case-normalising read site exists in _build_scan_plan.
        assert "_raw_disc_mode" in src

    def test_coerce_polling_value_bool_strings(self):
        """Behavioural verification of `_coerce_polling_value` for the
        bool strings that the JSON path now relies on."""
        from steps.file.starburst_file_base import _coerce_polling_value
        # Truthy strings -> True
        for s in ("TRUE", "true", "1", "yes", "Y", "T", "t"):
            assert _coerce_polling_value(s, "bool") is True, f"{s!r}"
        # Falsy strings -> False
        for s in ("FALSE", "false", "0", "no", "N", "F", "f"):
            assert _coerce_polling_value(s, "bool") is False, f"{s!r}"
        # Native bools pass through
        assert _coerce_polling_value(True, "bool") is True
        assert _coerce_polling_value(False, "bool") is False
        # None -> None (caller decides default)
        assert _coerce_polling_value(None, "bool") is None
        # Unrecognised -> None
        assert _coerce_polling_value("maybe", "bool") is None


class TestRunReportStableFilename:
    """2026-06-17 -- the FIRST run_report.write() at startup MUST
    resolve to the same filename as the FINAL write at shutdown.
    Pre-fix: first write went to `run_report.html` (no deliverable
    known yet); final write went to `<deliverable>.report.html`
    once output_files was populated.  Operators / heartbeat
    dashboards polling the first path saw permanent "in progress"
    because nothing ever overwrote it.

    Fix: (1) polling-row FILE_NAME is threaded into context via
    set_context(file_name=...) so _deliverable_basename has a
    primary fallback even before steps run; (2) business_date is
    appended when the basename doesn't already carry it; (3) any
    orphan from a prior write at a different path is backed up
    on the next write."""

    def test_deliverable_basename_uses_file_name_context_hint(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(file_name="orders.dat", business_date="2025-09-30")
        # No output_files / consolidated_file / compressed_file yet
        # -- the file_name hint is the only signal.
        assert rr._deliverable_basename() == "orders_2025-09-30"

    def test_basename_appends_business_date_when_missing(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(file_name="orders.dat", business_date="2025-09-30")
        assert "2025-09-30" in rr._deliverable_basename()

    def test_basename_does_not_double_append_business_date(self):
        """When the FILE_NAME already carries business_date, don't
        repeat it."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(
            file_name="orders_2025-09-30.dat", business_date="2025-09-30",
        )
        # Should be `orders_2025-09-30`, NOT `orders_2025-09-30_2025-09-30`.
        base = rr._deliverable_basename()
        assert base == "orders_2025-09-30", base
        assert base.count("2025-09-30") == 1

    def test_basename_normalises_slashes_in_business_date(self):
        """`DD/MM/YYYY` (some Oracle formats) should not produce a
        filename with `/` separators."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(file_name="orders.dat", business_date="30/09/2025")
        base = rr._deliverable_basename()
        assert "/" not in base

    def test_output_files_still_wins_over_hint(self):
        """When steps have populated output_files, that takes
        precedence over the polling-row hint.

        2026-06-20 -- INVERTED.  Polling-row FILE_NAME is the operator's
        CANONICAL name and now has PRIORITY over output_files[0] so
        every write (start-of-run + post-step) resolves to the SAME
        path.  Pre-2026-06-20 ordering had output_files winning, which
        produced two different report paths within one run -- mitigated
        by orphan cleanup but a strategic root-cause fix is preferred.
        """
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(file_name="hint.dat", business_date="2025-09-30")
        rr.add_output_file("/some/path/actual_consolidated.dat")
        base = rr._deliverable_basename()
        # Polling-row hint now wins; "actual_consolidated" not in base.
        assert "hint" in base
        assert "actual_consolidated" not in base

    def test_first_and_final_write_use_same_filename(self, tmp_path):
        """End-to-end: simulate the start-of-run + end-of-run write
        sequence file_standalone.py does.  Both writes MUST land at
        the same path (no orphan)."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path), backup_ts="20260617_140000")
        rr.set_context(file_name="orders.dat", business_date="2025-09-30")
        # 1. Start-of-run write (status=START)
        rr.mark_started()
        first_paths = rr.write()
        first_html = first_paths.get("html")
        assert first_html and os.path.basename(first_html) == "orders_2025-09-30.report.html"
        # 2. End-of-run write after steps registered the deliverable
        rr.add_output_file(str(tmp_path / "orders.dat"))
        rr.mark_success()
        final_paths = rr.write()
        final_html = final_paths.get("html")
        # The polling-row hint already encoded the right name, AND
        # the consolidated file basename here (orders) matches.  So
        # both writes land at the same path.
        assert first_html == final_html
        # And the file content reflects SUCCESS, not "in progress".
        content = Path(final_html).read_text(encoding="utf-8")
        assert "SUCCESS" in content
        assert "in progress" not in content.lower()

    def test_orphan_cleanup_when_filename_changes_mid_run(self, tmp_path):
        """Defensive: even when the first write goes to a DIFFERENT
        path than the final (e.g. no file_name hint), the orphan is
        cleaned up so the operator never sees a stale in-progress
        report at the legacy path."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path), backup_ts="20260617_140000")
        # Intentionally NO file_name hint so first write falls back
        # to the default `run_report.html`.
        rr.set_context(business_date="2025-09-30")
        rr.mark_started()
        first_paths = rr.write()
        first_html = first_paths.get("html")
        assert os.path.basename(first_html) == "run_report.html"
        assert Path(first_html).exists()
        # Steps now register a deliverable -- filename will switch.
        rr.add_output_file(str(tmp_path / "orders.dat"))
        rr.mark_success()
        final_paths = rr.write()
        final_html = final_paths.get("html")
        assert "orders" in os.path.basename(final_html)
        assert first_html != final_html
        # CRITICAL: the orphan first_html MUST be gone (or backed up)
        # so polling consumers don't see a stale "in progress" file.
        assert not Path(first_html).exists() or "backup_" in str(Path(first_html).resolve())


class TestG2SkipWhenNoPartitionCounts:
    """2026-06-17 -- the G2 completeness control fires `0 != G1` and
    renders permanent FAIL when ScanPlan.sum_partition_expected is 0
    (which happens in SINGLE mode and in distinct-discovery mode --
    both legitimate cases where per-partition counts are NOT collected).

    Contract: when no per-partition counts are available, the property
    returns None and the run-report SKIPS the G2 chip entirely rather
    than rendering FAIL with a meaningless 0.
    """

    def test_scan_plan_returns_none_when_no_partition_counts(self):
        from steps.file.starburst_file_base import ScanPlan, ScanMode
        plan = ScanPlan(
            mode=ScanMode.SINGLE,
            base_sql="SELECT 1",
            expected_total=100,
            expected_per_partition={},  # empty -- SINGLE or distinct mode
        )
        # Property MUST return None, NOT 0, so the run-report's
        # `if sum_partition_expected is not None` check skips G2.
        assert plan.sum_partition_expected is None

    def test_scan_plan_returns_sum_when_populated(self):
        from steps.file.starburst_file_base import ScanPlan, ScanMode
        plan = ScanPlan(
            mode=ScanMode.PARTITION_VALUES,
            base_sql="SELECT 1",
            expected_total=100,
            expected_per_partition={"a": 40, "b": 60},
        )
        assert plan.sum_partition_expected == 100

    def test_g2_skipped_in_render_when_sum_is_none(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_counts(expected_total=5_634_098, sum_partition_expected=None)
        ledger = rr._ledger_entries()
        controls = [e["control"] for e in ledger]
        # G1 present, G2 SKIPPED, G3-G5 also absent (no data yet) -- only G1.
        assert "G1" in controls
        assert "G2" not in controls, "G2 must be skipped when no per-partition counts"

    def test_g2_renders_when_sum_present(self):
        """When discovery collected per-partition counts, G2 renders
        and verifies sum == G1 (by construction)."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_counts(expected_total=5_634_098, sum_partition_expected=5_634_098)
        ledger = rr._ledger_entries()
        controls = [e["control"] for e in ledger]
        assert "G2" in controls
        g2 = [e for e in ledger if e["control"] == "G2"][0]
        assert g2["ok"] is True

    def test_aggregator_propagates_none_if_any_job_lacks_g2(self):
        """starburst_file_base's per-step aggregator must propagate
        None across jobs -- a mixed sum of 0 + real number renders a
        partial, meaningless G2 chip."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The per-step aggregator (line ~1914) MUST use the
        # all-not-None gating pattern.
        assert "all(p is not None for p in _g2_per_job)" in src
        # The cross-source merge (line ~1994) MUST also propagate None.
        assert "any(p is None for p in _prior_g2)" in src


class TestGatesAreNowControls:
    """2026-06-17 -- the run-report's G1-G5 completeness ledger is
    surfaced to operators as 'controls' (matching the QueryStudio-wide
    controls vocabulary from Phase 131), not as 'gates'.  Lock the
    rename so a future refactor can't accidentally re-introduce the
    old 'Gate' label."""

    def test_html_renders_control_not_gate(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_context(business_date="2025-09-30")
        rr.set_counts(expected_total=100, sum_partition_expected=100,
                      sum_chunk_actual=100, consolidated_total=100)
        html_out = rr.to_html()
        assert "<th>Control</th>" in html_out
        assert "Completeness controls" in html_out
        assert "control-tag" in html_out
        assert "control-why" in html_out
        # Old labels MUST be gone.
        assert "<th>Gate</th>" not in html_out
        assert "Completeness ledger</h2>" not in html_out
        assert "gate-tag" not in html_out
        assert "gate-why" not in html_out

    def test_text_renders_control_not_gate(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_context(business_date="2025-09-30")
        rr.set_counts(expected_total=100, sum_partition_expected=100,
                      sum_chunk_actual=100)
        text_out = rr.to_text()
        assert "COMPLETENESS CONTROLS:" in text_out

    def test_ledger_entry_uses_control_key(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        rr.set_counts(expected_total=100)
        ledger = rr._ledger_entries()
        assert ledger
        entry = ledger[0]
        assert "control" in entry, f"missing 'control' key: {entry.keys()}"
        assert "gate" not in entry, f"stale 'gate' key still present: {entry.keys()}"


class TestPartitionASTRewrite:
    """2026-06-17 -- per-chunk SQL is now AST-rewritten by sqlglot:
    the partition predicate is INJECTED into base_sql's top-level
    WHERE clause instead of wrapped in a subquery.  Trino sees the
    filter on the source SELECT and prunes natively (Iceberg
    partition pruning + JOIN-side filter pushdown) instead of
    re-executing the full base_sql 100 times for a 100-partition
    job.  Falls back to legacy wrap on sqlglot parse failure."""

    def test_inject_where_into_simple_select(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT a, b, col FROM t WHERE d = DATE '2025-01-01'"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # The injected predicate appears INLINE in the WHERE, not as a wrap.
        assert "col = 'X'" in sql
        assert "FROM t" in sql
        # No outer wrap with pv.
        assert "FROM (" not in sql or "AS pv" not in sql

    def test_inject_where_into_join_query(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = ("SELECT a.id, b.col FROM A a JOIN B b ON a.k = b.k "
                "WHERE a.d = DATE '2025-01-01' GROUP BY a.id, b.col")
        sql, mode = _inject_where_into_base_sql(base, "col", "Y", dialect="trino")
        assert mode == "ast"
        assert "col = 'Y'" in sql
        # JOIN preserved.
        assert "JOIN B" in sql
        # GROUP BY preserved.
        assert "GROUP BY" in sql

    def test_inject_where_with_numeric_value(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT id FROM t WHERE x = 1"
        sql, mode = _inject_where_into_base_sql(base, "id", 42, dialect="trino")
        assert mode == "ast"
        # Numeric value rendered without quotes.
        assert "id = 42" in sql or "id = 42 " in sql or "= 42" in sql

    def test_inject_where_with_null_value(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT id FROM t WHERE x = 1"
        sql, mode = _inject_where_into_base_sql(base, "id", None, dialect="trino")
        assert mode == "ast"
        assert "IS NULL" in sql

    def test_inject_falls_back_to_wrap_on_parse_failure(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        # Deliberately broken SQL.
        base = "SELECT FROM nowhere syntax fail !!"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "wrap"
        # Legacy wrap format: SELECT * FROM (...) AS pv WHERE pv.col = 'X'
        assert "AS pv" in sql

    def test_inject_does_NOT_recurse_into_where_subquery(self):
        """2026-06-17 deep-dive #2: AST inject was recursing into EVERY
        Select node, including correlated subqueries in WHERE clauses
        where the partition column doesn't exist.  Result: runtime
        'Column not resolved' errors OR silently filtered subquery
        results.  The fix scopes inject to ONLY the outermost SELECT
        (and UNION branches' outermost SELECTs)."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = (
            "SELECT a.id, a.col FROM tableA a "
            "WHERE a.fk IN (SELECT b.fk FROM tableB b WHERE b.flag = 1)"
        )
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # The inner subquery (SELECT b.fk FROM tableB...) MUST NOT contain
        # the injected predicate -- it has no `col` column at all.
        # Extract inner SELECT and check it.
        inner_start = sql.index("IN (") + 4
        inner_end = sql.rindex(")")
        inner = sql[inner_start:inner_end]
        assert "col" not in inner, (
            f"inner subquery wrongly got the partition predicate: {inner}"
        )
        # Outer WHERE DOES have the predicate.
        assert "col = 'X'" in sql

    def test_inject_does_NOT_recurse_into_from_derived_table(self):
        """FROM-derived tables must not get the predicate either --
        the outer WHERE is the right place; Trino's optimizer pushes
        down to the derived table natively."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = (
            "SELECT s.id, s.col FROM "
            "(SELECT id, col, flag FROM source WHERE d = DATE '2025-01-01') s "
            "WHERE s.flag = 1"
        )
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # Inner derived table must not have the inject -- check by
        # counting "col = 'X'" occurrences: should be exactly 1 (outer only).
        assert sql.count("col = 'X'") == 1

    def test_inject_does_NOT_recurse_into_cte_body(self):
        """CTE body stays as-is -- inject only on the outer SELECT.
        Trino's optimizer pushes down to the CTE materialisation."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = (
            "WITH cte AS (SELECT id, col, flag FROM source WHERE d = DATE '2025-01-01') "
            "SELECT id, col FROM cte WHERE flag = 1"
        )
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # CTE body unchanged: count "col = 'X'" occurrences == 1.
        assert sql.count("col = 'X'") == 1

    def test_inject_into_each_union_branch_outermost(self):
        """UNION at the top: each branch's outermost SELECT gets the
        predicate (semantically equivalent to filtering the unioned
        result).  Subqueries within a branch still don't get touched."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT id, col FROM A UNION ALL SELECT id, col FROM B"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # Both branches got the predicate.
        assert sql.count("col = 'X'") == 2
        assert "UNION ALL" in sql

    def test_inject_auto_fallback_on_computed_alias(self):
        """2026-06-17 deep-dive #5 -- user directive: 'query extraction
        should never fail'.  When the partition column is an alias of
        a computed expression (`a||b AS col`, `CASE ... AS col`), AST
        `WHERE col = X` would fail at runtime (Trino doesn't expose
        SELECT aliases in WHERE).  Auto-fallback to wrap mode."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        for base in (
            "SELECT a || b AS col FROM t",
            "SELECT CASE WHEN x THEN 1 ELSE 0 END AS col FROM t",
        ):
            sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
            assert mode == "wrap", f"expected wrap fallback, got ast for: {base}"
            assert "AS pv" in sql
            assert "pv.col = 'X'" in sql

    def test_inject_auto_fallback_on_renaming_alias(self):
        """`t.other AS col` where the underlying column has a different
        name -- AST WHERE col can't see the alias.  Wrap fallback."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT t.other AS col FROM t"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "wrap"
        assert "AS pv" in sql

    def test_inject_stays_ast_for_redundant_rename(self):
        """`t.col AS col` -- alias name MATCHES the underlying column
        name.  Trino's WHERE clause resolves `col` to the real column;
        AST inject is still safe."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT t.col AS col FROM t"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        assert "col = 'X'" in sql

    def test_derive_distinct_auto_fallback_on_computed_alias(self):
        """Same alias gotcha for discovery: `SELECT DISTINCT col FROM
        source` fails when col is a computed alias.  Wrap fallback."""
        from steps.file.starburst_file_base import _derive_distinct_partition_sql
        base = "SELECT a || b AS col FROM t WHERE d = DATE '2025-01-01'"
        sql, mode = _derive_distinct_partition_sql(base, "col", dialect="trino")
        assert mode == "wrap"
        assert "AS plan_q" in sql

    def test_value_with_single_quote_escaped(self):
        """Operator partition values can contain single quotes
        (`O'Brien`).  Must be escaped, not break the SQL."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT col FROM t WHERE x = 1"
        sql, mode = _inject_where_into_base_sql(base, "col", "O'Brien", dialect="trino")
        assert mode == "ast"
        assert "O''Brien" in sql or "'O\\'Brien'" in sql  # sqlglot doubles the quote

    def test_value_with_float(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT col FROM t"
        sql, mode = _inject_where_into_base_sql(base, "col", 3.14, dialect="trino")
        assert mode == "ast"
        assert "3.14" in sql

    def test_multiple_ctes_inject_only_outer(self):
        """Multi-CTE base_sql: outer SELECT gets the inject; CTE bodies
        stay untouched."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = (
            "WITH cte1 AS (SELECT id, col FROM A WHERE x = 1), "
            "     cte2 AS (SELECT id FROM B) "
            "SELECT c1.id, c1.col FROM cte1 c1 JOIN cte2 c2 ON c1.id = c2.id"
        )
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        # Exactly one inject (outer only); CTE bodies unchanged.
        assert sql.count("col = 'X'") == 1

    def test_union_distinct_both_branches(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT id, col FROM A UNION SELECT id, col FROM B"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        assert sql.count("col = 'X'") == 2
        # UNION without ALL is still a Union exp in sqlglot.
        assert "UNION" in sql

    def test_correlated_subquery_in_projection(self):
        """`SELECT a.x, (SELECT MAX(b.y) FROM B b WHERE b.fk = a.id)
        FROM A a` -- inject ONLY on the outer SELECT, not the
        correlated subquery in projection."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = (
            "SELECT a.id, a.col, "
            "  (SELECT MAX(b.amount) FROM B b WHERE b.fk = a.id) AS max_amt "
            "FROM A a"
        )
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        assert sql.count("col = 'X'") == 1
        # Inner correlated subquery untouched.
        assert "MAX(b.amount)" in sql or "MAX(b.amount" in sql

    def test_trailing_semicolon_handled(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT col FROM t WHERE x = 1;"
        sql, mode = _inject_where_into_base_sql(base, "col", "X", dialect="trino")
        assert mode == "ast"
        assert ";" not in sql  # stripped
        assert "col = 'X'" in sql

    def test_validator_detects_ambiguous_partition_column(self):
        """Gap 1: SELECT a.col, b.col FROM A JOIN B with PARTITION_COLUMN='col'
        is ambiguous -- both AST and wrap would emit `WHERE col = X` which
        Trino can't disambiguate.  Validator must flag with AMBIGUOUS in
        the warning text so _build_scan_plan can fail-fast at planning."""
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = "SELECT a.col, b.col FROM A a JOIN B b ON a.k = b.k"
        is_safe, warnings = _validate_base_sql_ast_safe(base, "col", dialect="trino")
        assert not is_safe
        assert any("AMBIGUOUS" in w for w in warnings)
        # The warning names BOTH offending qualifiers so the operator
        # knows what to fix.
        joined = " ".join(warnings)
        assert "'a'" in joined and "'b'" in joined

    def test_validator_does_not_flag_non_ambiguous_join(self):
        """When the partition column appears only on one side of a JOIN,
        it's NOT ambiguous -- validator should pass clean."""
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = "SELECT a.col, b.other FROM A a JOIN B b ON a.k = b.k"
        is_safe, warnings = _validate_base_sql_ast_safe(base, "col", dialect="trino")
        assert is_safe
        assert warnings == []

    def test_inject_reserved_word_partition_column(self):
        """Gap 2: partition_column='order' (Trino reserved word) -- sqlglot
        must emit quoted `WHERE \"order\" = 'X'` so the query parses."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = 'SELECT t."order", col FROM t'
        sql, mode = _inject_where_into_base_sql(base, "order", "X", dialect="trino")
        assert mode == "ast"
        # The injected predicate must use the QUOTED identifier so Trino
        # parses it -- bare WHERE order = 'X' is a syntax error.
        assert '"order" = \'X\'' in sql or '"order"=\'X\'' in sql

    def test_inject_never_raises_returns_some_sql(self):
        """User directive: query extraction should NEVER fail.  Even on
        wild input, _inject_where_into_base_sql must return a string
        and a mode tag -- never raise."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        for wild in ("", ";;;", "NOT SQL AT ALL", "x" * 5000):
            try:
                sql, mode = _inject_where_into_base_sql(
                    wild, "col", "X", dialect="trino",
                )
                assert isinstance(sql, str) and sql
                assert mode in ("ast", "wrap")
            except Exception as exc:
                raise AssertionError(
                    f"inject raised on wild input {wild!r}: {exc}"
                )

    def test_derive_distinct_strips_projection_and_group_by(self):
        from steps.file.starburst_file_base import _derive_distinct_partition_sql
        base = ("SELECT a.id, a.amount, b.col, b.region "
                "FROM A a JOIN B b ON a.k = b.k "
                "WHERE a.d = DATE '2025-01-01' "
                "GROUP BY a.id, a.amount, b.col, b.region")
        sql, mode = _derive_distinct_partition_sql(base, "col", dialect="trino")
        assert mode == "ast"
        # Projection collapsed to DISTINCT col.
        assert "DISTINCT col" in sql or "DISTINCT" in sql and "col" in sql
        # FROM/JOIN/WHERE preserved.
        assert "JOIN B" in sql
        # GROUP BY stripped (no aggregation on the cheap distinct probe).
        assert "GROUP BY" not in sql

    def test_derive_distinct_falls_back_to_wrap_on_parse_failure(self):
        from steps.file.starburst_file_base import _derive_distinct_partition_sql
        base = "broken SQL syntax"
        sql, mode = _derive_distinct_partition_sql(base, "col", dialect="trino")
        assert mode == "wrap"
        assert "SELECT DISTINCT col FROM" in sql
        assert "AS plan_q" in sql

    def test_ast_safety_warns_on_window_function(self):
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = ("SELECT id, col, ROW_NUMBER() OVER (PARTITION BY region ORDER BY id) "
                "FROM t WHERE d = DATE '2025-01-01'")
        is_safe, warnings = _validate_base_sql_ast_safe(
            base, "col", dialect="trino",
        )
        assert not is_safe
        assert any("window" in w.lower() for w in warnings)

    def test_ast_safety_warns_when_partition_column_missing_from_projection(self):
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = "SELECT id, amount FROM t WHERE d = DATE '2025-01-01'"
        is_safe, warnings = _validate_base_sql_ast_safe(
            base, "missing_col", dialect="trino",
        )
        assert not is_safe
        assert any("projection" in w.lower() or "select" in w.lower() for w in warnings)

    def test_ast_safety_passes_clean_sql(self):
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = ("SELECT id, col, amount FROM t WHERE d = DATE '2025-01-01' "
                "GROUP BY id, col, amount")
        is_safe, warnings = _validate_base_sql_ast_safe(base, "col", dialect="trino")
        assert is_safe
        assert warnings == []

    def test_ast_safety_warns_on_top_level_limit(self):
        """base_sql with LIMIT has different semantics in AST vs wrap mode:
        AST applies LIMIT after filter (per-chunk = LIMIT rows of THIS
        partition), wrap applied LIMIT before (per-chunk = subset of
        SAME sample).  Validator warns operator."""
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = "SELECT id, col FROM t WHERE d = DATE '2025-01-01' LIMIT 1000"
        is_safe, warnings = _validate_base_sql_ast_safe(base, "col", dialect="trino")
        assert not is_safe
        assert any("LIMIT" in w for w in warnings)

    def test_no_operator_facing_rewrite_mode_knob(self):
        """No REWRITE_MODE polling-row column / no rewrite_mode JSON
        knob -- the AST rewriter is unconditional, with auto-fallback
        to wrap on parse failure.  Locks the design decision so a
        future commit doesn't accidentally re-introduce the toggle."""
        from steps.file.starburst_file_base import _POLLING_ROW_OVERLAYS
        keys = {k for k, _, _ in _POLLING_ROW_OVERLAYS}
        assert "rewrite_mode" not in keys

    def test_add_partition_predicate_uses_ast_unconditionally(self):
        """The per-chunk SQL builder has no rewrite_mode parameter --
        AST is always tried first, with auto-fallback on parse failure."""
        from steps.file import starburst_file_base
        import inspect
        sig = inspect.signature(starburst_file_base.StarburstFileBase._add_partition_predicate)
        params = list(sig.parameters.keys())
        # self, base_sql, column, value -- nothing else.
        assert params == ["self", "base_sql", "column", "value"]


class TestQualifiedPartitionColumn:
    """2026-06-17 follow-up -- user reported `partition_column =
    'FACT_TABLE.SAP_COMPANY_ID'` failing with 'Column not resolved' on
    Trino, and pre-flight COUNT still on full wrapper.

    Root causes:
      1. `exp.to_identifier("FACT_TABLE.SAP_COMPANY_ID")` doesn't split
         on dots -- emitted one identifier literally containing the dot.
      2. `_fetch_count` and `_try_group_by` were never wired to AST --
         they still wrapped the entire base_sql in a subquery.

    These tests lock the fix so the qualified-column case (which is
    the COMMON case per user feedback: 'partition column will have
    table alias always') doesn't regress."""

    def test_parse_qualified_column_splits_on_dot(self):
        from steps.file.starburst_file_base import _parse_qualified_column
        assert _parse_qualified_column("FACT_TABLE.SAP_COMPANY_ID") == ("FACT_TABLE", "SAP_COMPANY_ID")
        assert _parse_qualified_column("SAP_COMPANY_ID") == (None, "SAP_COMPANY_ID")
        assert _parse_qualified_column('"a"."b"') == ("a", "b")
        # Trailing/leading whitespace tolerated.
        assert _parse_qualified_column("  T.C  ") == ("T", "C")

    def test_bare_column_name_strips_qualifier(self):
        from steps.file.starburst_file_base import _bare_column_name
        assert _bare_column_name("FACT_TABLE.SAP_COMPANY_ID") == "SAP_COMPANY_ID"
        assert _bare_column_name("SAP_COMPANY_ID") == "SAP_COMPANY_ID"

    def test_inject_ast_preserves_qualifier(self):
        """AST mode must emit `FACT_TABLE.COL = 'X'` as a two-part name,
        not `"FACT_TABLE.COL" = 'X'` (one quoted identifier with a dot
        which Trino can't resolve)."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = ("SELECT FACT_TABLE.SAP_COMPANY_ID, FACT_TABLE.AMOUNT "
                "FROM FACT_TABLE JOIN DIM_TABLE ON FACT_TABLE.K = DIM_TABLE.K")
        sql, mode = _inject_where_into_base_sql(
            base, "FACT_TABLE.SAP_COMPANY_ID", "X100", dialect="trino",
        )
        assert mode == "ast"
        assert "FACT_TABLE.SAP_COMPANY_ID = 'X100'" in sql
        # And NOT the broken one-identifier form.
        assert '"FACT_TABLE.SAP_COMPANY_ID"' not in sql

    def test_derive_distinct_ast_preserves_qualifier(self):
        from steps.file.starburst_file_base import _derive_distinct_partition_sql
        base = ("SELECT FACT_TABLE.SAP_COMPANY_ID, FACT_TABLE.AMOUNT "
                "FROM FACT_TABLE")
        sql, mode = _derive_distinct_partition_sql(
            base, "FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode == "ast"
        assert "DISTINCT FACT_TABLE.SAP_COMPANY_ID" in sql
        assert '"FACT_TABLE.SAP_COMPANY_ID"' not in sql

    def test_derive_count_sql_ast_no_wrap(self):
        """Pre-flight COUNT: AST emits `SELECT COUNT(*) FROM source`
        directly, no subquery wrap.  This is the central regression --
        user reported still seeing the wrap after today's commits."""
        from steps.file.starburst_file_base import _derive_count_sql
        base = ("SELECT FACT_TABLE.SAP_COMPANY_ID, FACT_TABLE.AMOUNT "
                "FROM FACT_TABLE WHERE RUN_DATE = DATE '2026-06-17'")
        sql, mode = _derive_count_sql(base, dialect="trino")
        assert mode == "ast"
        assert "COUNT(*)" in sql
        # The smoking gun: AST output must NOT include a subquery wrap.
        assert "AS pre_flight_q" not in sql
        # And the operator's WHERE survives (drives Trino pushdown).
        assert "RUN_DATE" in sql

    def test_derive_count_sql_falls_back_to_wrap_on_parse_failure(self):
        from steps.file.starburst_file_base import _derive_count_sql
        sql, mode = _derive_count_sql("not parseable SQL", dialect="trino")
        assert mode == "wrap"
        assert "SELECT COUNT(*) FROM" in sql
        assert "AS pre_flight_q" in sql

    def test_derive_count_sql_skip_mode_when_outer_group_by_present(self):
        """2026-06-18 STRATEGIC REVISION: prior policy wrapped the whole
        base_sql in COUNT(*) when DISTINCT/GROUP BY/HAVING/LIMIT was
        present.  User flagged the OOM risk: wrapping a 170M-row
        DISTINCT JOIN forces Trino to materialise the full result first.

        New policy: skip the pre-flight COUNT entirely when shape is
        detected.  G1 is measured from extract at end-of-job; the
        operator must set FAIL_ON_MISMATCH=FALSE since per-chunk
        completeness checks aren't possible without a count.

        Trade-off vs prior "wrap mode is correct": correct counts cost
        OOM; we'd rather lose the pre-flight count than crash Trino."""
        from steps.file.starburst_file_base import _derive_count_sql
        base = ("SELECT region, COUNT(*) c FROM t "
                "GROUP BY region ORDER BY c DESC LIMIT 100")
        sql, mode = _derive_count_sql(base, dialect="trino")
        assert mode == "skip", (
            "Outer GROUP BY/LIMIT -> skip pre-flight COUNT entirely.  "
            "Wrap would OOM on large tables."
        )
        assert sql == ""

    def test_derive_group_by_count_qualified_column_no_wrap(self):
        """The exact bug the user hit: `partition_column =
        'FACT_TABLE.SAP_COMPANY_ID'` produced
            SELECT FACT_TABLE.SAP_COMPANY_ID AS pv, ... FROM (...) AS plan_q
            GROUP BY FACT_TABLE.SAP_COMPANY_ID
        which Trino rejects because FACT_TABLE isn't in scope after the
        wrap.  AST mode emits the GROUP BY against the source FROM
        where FACT_TABLE resolves."""
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        base = ("SELECT FACT_TABLE.SAP_COMPANY_ID, FACT_TABLE.AMOUNT "
                "FROM FACT_TABLE JOIN DIM_TABLE ON FACT_TABLE.K = DIM_TABLE.K "
                "WHERE FACT_TABLE.RUN_DATE = DATE '2026-06-17'")
        sql, mode = _derive_group_by_count_sql(
            base, "FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode == "ast"
        # GROUP BY against the qualified column -- FACT_TABLE in scope.
        assert "GROUP BY FACT_TABLE.SAP_COMPANY_ID" in sql
        assert "ORDER BY FACT_TABLE.SAP_COMPANY_ID" in sql
        # No subquery wrap.
        assert "AS plan_q" not in sql
        # Original WHERE survives so Trino prunes.
        assert "RUN_DATE" in sql

    def test_derive_group_by_count_unqualified_works(self):
        """Single-table base + bare column -- AST mode still produces
        the right shape."""
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        base = "SELECT region, amount FROM t WHERE d = DATE '2026-06-17'"
        sql, mode = _derive_group_by_count_sql(base, "region", dialect="trino")
        assert mode == "ast"
        assert "GROUP BY region" in sql
        assert "AS plan_q" not in sql

    def test_derive_group_by_count_falls_back_to_wrap_on_parse_failure(self):
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        sql, mode = _derive_group_by_count_sql(
            "not parseable", "FACT_TABLE.COL", dialect="trino",
        )
        assert mode == "wrap"
        # Wrap fallback MUST strip the qualifier because the source
        # table isn't in scope after the subquery alias.
        assert "GROUP BY COL" in sql
        assert "FACT_TABLE.COL" not in sql

    def test_wrap_group_by_count_strips_qualifier(self):
        """Direct unit test of the wrap fallback's qualifier-strip."""
        from steps.file.starburst_file_base import _wrap_group_by_count
        sql = _wrap_group_by_count("SELECT * FROM t", "FACT_TABLE.SAP_COMPANY_ID")
        assert "SELECT SAP_COMPANY_ID AS pv" in sql
        assert "GROUP BY SAP_COMPANY_ID" in sql
        # Qualifier MUST NOT leak through.
        assert "FACT_TABLE" not in sql.split(" FROM (")[0]

    def test_wrap_with_where_strips_qualifier(self):
        from steps.file.starburst_file_base import _wrap_with_where
        sql = _wrap_with_where("SELECT * FROM t", "FACT_TABLE.SAP_COMPANY_ID", "X")
        assert "pv.SAP_COMPANY_ID = 'X'" in sql
        # 3-part name `pv.FACT_TABLE.col` would be a Trino error.
        assert "pv.FACT_TABLE" not in sql

    def test_wrap_distinct_strips_qualifier(self):
        from steps.file.starburst_file_base import _wrap_distinct
        sql = _wrap_distinct("SELECT * FROM t", "FACT_TABLE.SAP_COMPANY_ID")
        assert "SELECT DISTINCT SAP_COMPANY_ID" in sql
        assert "ORDER BY SAP_COMPANY_ID" in sql

    def test_validator_skips_ambiguity_warning_when_operator_qualifies(self):
        """When SAP_COMPANY_ID lives on BOTH joined tables (the common
        QS shape per user feedback) but the operator pre-qualifies as
        FACT_TABLE.SAP_COMPANY_ID, the ambiguity is resolved -- the
        validator must NOT emit a false-positive warning."""
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = ("SELECT FACT_TABLE.SAP_COMPANY_ID, DIM_TABLE.SAP_COMPANY_ID AS dim_co "
                "FROM FACT_TABLE JOIN DIM_TABLE ON FACT_TABLE.K = DIM_TABLE.K")
        # Unqualified -> warns (existing behaviour).
        is_safe, warnings = _validate_base_sql_ast_safe(
            base, "SAP_COMPANY_ID", dialect="trino",
        )
        assert not is_safe
        assert any("AMBIGUOUS" in w for w in warnings)
        # Operator-qualified -> NO warning.
        is_safe, warnings = _validate_base_sql_ast_safe(
            base, "FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert is_safe
        assert warnings == []

    def test_build_column_expr_handles_n_part_names(self):
        """3-part (schema.table.col) and 4-part (catalog.schema.table.col)
        identifiers must emit as plain dotted names -- NOT as one quoted
        identifier with literal dots in it.  The initial fix only handled
        2-part via rsplit; sqlglot's exp.to_column delegates handle N-part
        correctly."""
        from steps.file.starburst_file_base import _build_column_expr
        cases = {
            "SAP_COMPANY_ID":                                "SAP_COMPANY_ID",
            "FACT_TABLE.SAP_COMPANY_ID":                     "FACT_TABLE.SAP_COMPANY_ID",
            "MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID":            "MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID",
            "MYCATALOG.MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID":  "MYCATALOG.MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID",
        }
        for given, expected in cases.items():
            emitted = _build_column_expr(given).sql(dialect="trino")
            assert emitted == expected, f"{given!r} -> {emitted!r} (expected {expected!r})"

    def test_three_part_name_in_group_by_no_dot_quoting(self):
        """Regression: rsplit('.', 1) collapsed `MYSCHEMA.FACT_TABLE` into
        a single identifier with a literal dot -- Trino rejected it as
        an unknown column.  Emit must be plain `MYSCHEMA.FACT_TABLE.COL`."""
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        base = "SELECT MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID FROM MYSCHEMA.FACT_TABLE"
        sql, mode = _derive_group_by_count_sql(
            base, "MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode == "ast"
        assert "MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID" in sql
        # The smoking-gun anti-pattern: one quoted identifier with a dot.
        assert '"MYSCHEMA.FACT_TABLE"' not in sql
        assert '"MYSCHEMA.FACT_TABLE.SAP_COMPANY_ID"' not in sql

    def test_collect_from_qualifiers_returns_aliases_and_table_names(self):
        """The single source of truth for 'which qualifiers are in scope
        at the outermost SELECT'.  Used by every AST helper to detect
        the alias-mismatch case.  These contract cases lock the behaviour."""
        import sqlglot
        from steps.file.starburst_file_base import _collect_from_qualifiers
        cases = [
            ("SELECT FT.c FROM FACT_TABLE FT",                                 {"ft"}),
            ("SELECT c FROM FACT_TABLE",                                       {"fact_table"}),
            ("SELECT FT.c FROM FACT_TABLE FT JOIN DIM_TABLE DT ON FT.k=DT.k",  {"ft", "dt"}),
            ("SELECT c FROM FACT_TABLE JOIN DIM_TABLE DT ON FACT_TABLE.k=DT.k",{"fact_table", "dt"}),
            ("WITH r AS (SELECT c FROM t) SELECT r.c FROM r",                  {"r"}),
        ]
        for base, expected in cases:
            tree = sqlglot.parse_one(base, dialect="trino")
            got = _collect_from_qualifiers(tree)
            assert got == expected, f"{base!r}: got {got}, expected {expected}"

    def test_alias_mismatch_group_by_stays_ast_user_fixes_qualifier(self):
        """2026-06-18 STRATEGIC REVISION: prior fallback to WRAP on
        alias mismatch is now OOM-unsafe for large tables.  The new
        policy: emit AST anyway and let Trino reject if the qualifier
        is wrong.  Operator gets a clear COLUMN_NOT_FOUND error with
        line+column and fixes the polling-row qualifier.

        The wrap fallback was hiding operator errors AND opening an
        OOM vector for any case where wrap was forced.  Fail loud =
        operator catches the typo at planning time."""
        from steps.file.starburst_file_base import (
            _derive_group_by_count_sql,
            _derive_distinct_partition_sql,
        )
        base = ("SELECT FT.SAP_COMPANY_ID, FT.AMOUNT "
                "FROM FACT_TABLE FT WHERE FT.RUN_DATE = DATE '2026-06-17'")
        bad_col = "FACT_TABLE.SAP_COMPANY_ID"

        sql, mode = _derive_group_by_count_sql(base, bad_col, dialect="trino")
        assert mode == "ast"
        assert "FACT_TABLE.SAP_COMPANY_ID" in sql
        # Trino will reject this at run-time -- operator fixes qualifier.

        sql, mode = _derive_distinct_partition_sql(base, bad_col, dialect="trino")
        # distinct_partition still has the qualifier_in_scope guard for
        # back-compat (less impact than wrap-mode group_by).  Test that
        # it didn't crash; either ast or wrap is acceptable here.
        assert mode in ("ast", "wrap")

    def test_alias_match_stays_in_ast_mode(self):
        """When operator passes the alias (FT.col) that base_sql uses,
        AST mode is correct and should be used."""
        from steps.file.starburst_file_base import (
            _derive_group_by_count_sql, _inject_where_into_base_sql,
        )
        base = "SELECT FT.SAP_COMPANY_ID FROM FACT_TABLE FT"
        sql, mode = _derive_group_by_count_sql(base, "FT.SAP_COMPANY_ID", dialect="trino")
        assert mode == "ast"
        assert "GROUP BY FT.SAP_COMPANY_ID" in sql

        sql, mode = _inject_where_into_base_sql(base, "FT.SAP_COMPANY_ID", "X", dialect="trino")
        assert mode == "ast"
        assert "FT.SAP_COMPANY_ID = 'X'" in sql

    def test_unaliased_table_with_full_qualifier_stays_in_ast_mode(self):
        """When base_sql has no alias on the source table (`FROM FACT_TABLE`),
        the table name IS the in-scope qualifier.  Operator's qualified
        column references the same name and AST mode works."""
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        base = "SELECT SAP_COMPANY_ID FROM FACT_TABLE"
        sql, mode = _derive_group_by_count_sql(
            base, "FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode == "ast"
        assert "GROUP BY FACT_TABLE.SAP_COMPANY_ID" in sql

    def test_validator_projection_check_uses_bare_name(self):
        """Operator passes FACT_TABLE.SAP_COMPANY_ID; sqlglot's parsed
        Column has .name='SAP_COMPANY_ID' and .table='FACT_TABLE'.
        Bare-name comparison must find it in the projection -- otherwise
        we'd false-warn 'partition column not in projection'."""
        from steps.file.starburst_file_base import _validate_base_sql_ast_safe
        base = "SELECT FACT_TABLE.SAP_COMPANY_ID, FACT_TABLE.AMOUNT FROM FACT_TABLE"
        is_safe, warnings = _validate_base_sql_ast_safe(
            base, "FACT_TABLE.SAP_COMPANY_ID", dialect="trino",
        )
        assert is_safe
        assert warnings == []


class TestPartitionBucketing:
    """2026-06-17 -- single-column bucketing.  When a partition column
    has high cardinality (1139 SAP_COMPANY_IDs in the user's case), we
    group N adjacent discovered values into one chunk and emit
    ``WHERE col IN (v1, v2, ..., vN)``.  Reduces 1139 Trino queries to
    ~100-200 chunks, each scanning ~N*single-value rows.  G3/G5 reconcile
    is unchanged (sum-of-bucket-actuals == G1)."""

    def test_inject_single_value_back_compat(self):
        """Single scalar value still emits ``col = v`` -- bucketing must
        not regress the non-bucket path."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(base, "FACT.col", "X100", dialect="trino")
        assert mode == "ast"
        assert "FACT.col = 'X100'" in sql
        assert " IN " not in sql.upper()

    def test_inject_bucket_strings_emits_in_clause(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", ["X100", "X101", "X102"], dialect="trino",
        )
        assert mode == "ast"
        assert "FACT.col IN ('X100', 'X101', 'X102')" in sql

    def test_inject_bucket_numeric_no_quotes(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", [100, 101, 102], dialect="trino",
        )
        assert mode == "ast"
        assert "FACT.col IN (100, 101, 102)" in sql

    def test_inject_bucket_with_null_uses_or(self):
        """NULL members must be split out into ``OR col IS NULL`` since
        SQL's IN-clause does NOT match NULL (NULL = NULL is unknown)."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", ["X100", None, "X102"], dialect="trino",
        )
        assert mode == "ast"
        assert "FACT.col IN ('X100', 'X102')" in sql
        assert "FACT.col IS NULL" in sql
        assert " OR " in sql.upper()

    def test_inject_bucket_all_nulls_collapses(self):
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", [None, None], dialect="trino",
        )
        assert mode == "ast"
        assert "FACT.col IS NULL" in sql
        assert " IN " not in sql.upper()

    def test_inject_bucket_single_element_collapses_to_eq(self):
        """Single-element bucket emits ``col = v`` (cleaner SQL than
        ``col IN (v)``).  No semantic difference but reads better in logs."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", ["X100"], dialect="trino",
        )
        assert mode == "ast"
        assert "FACT.col = 'X100'" in sql
        assert " IN " not in sql.upper()

    def test_inject_bucket_escapes_single_quotes(self):
        """Operator partition values can contain ``O'Brien`` -- must be
        escaped, not break the IN-clause SQL."""
        from steps.file.starburst_file_base import _inject_where_into_base_sql
        base = "SELECT FACT.col FROM FACT_TABLE FACT"
        sql, mode = _inject_where_into_base_sql(
            base, "FACT.col", ["O'Brien", "Smith"], dialect="trino",
        )
        assert mode == "ast"
        # sqlglot doubles the embedded quote.
        assert "'O''Brien'" in sql
        assert "'Smith'" in sql

    def test_wrap_fallback_bucket_emits_in_clause(self):
        """When AST can't parse base_sql, wrap fallback must still
        produce a working IN-clause with the qualifier stripped (since
        the wrap loses source FROM scope)."""
        from steps.file.starburst_file_base import _wrap_with_where
        sql = _wrap_with_where("NOT SQL", "FACT.col", ["X100", "X101"])
        assert "pv.col IN ('X100', 'X101')" in sql
        # Qualifier stripped on wrap (3-part name would be invalid).
        assert "pv.FACT" not in sql

    def test_wrap_fallback_bucket_null_aware(self):
        from steps.file.starburst_file_base import _wrap_with_where
        sql = _wrap_with_where("NOT SQL", "FACT.col", ["X100", None])
        assert "pv.col IN ('X100')" in sql
        assert "pv.col IS NULL" in sql
        assert " OR " in sql.upper()

    def test_discovery_uses_source_only_ast_on_distinct(self):
        """2026-06-18 STRATEGIC REVISION (user-reported OOM concern):
        the prior wrap-fallback for DISTINCT/GROUP BY shapes forced
        Trino to materialise the full base_sql before counting -- OOM
        risk on 170M+ row tables, plus column-resolution errors at the
        wrap level when base_sql aliased the partition column.

        New policy: discovery NEVER wraps.  When base_sql has DISTINCT/
        GROUP BY/etc, group_by discovery uses AST strip (source-only
        FROM/JOIN/WHERE) -- counts source rows per partition value, not
        the post-aggregation counts.  Counts differ from chunk semantics
        but are cheap and give partition_min_rows an upper-bound signal.

        Pre-flight COUNT auto-SKIPS instead of wrapping -- the count
        wouldn't be useful anyway (pre-aggregation source rows).  G1
        gets measured from extract at end-of-job.

        Operator must set FAIL_ON_MISMATCH=FALSE for these shapes."""
        from steps.file.starburst_file_base import (
            _derive_count_sql, _derive_group_by_count_sql,
        )
        base = ("SELECT DISTINCT FACT.SAP_COMPANY_ID, FACT.AMOUNT "
                "FROM FACT_TABLE FACT WHERE FACT.RUN_DATE = DATE '2026-06-17'")
        sql_c, mode_c = _derive_count_sql(base, dialect="trino")
        assert mode_c == "skip", f"expected skip for DISTINCT, got {mode_c}"
        assert sql_c == ""
        sql_g, mode_g = _derive_group_by_count_sql(
            base, "FACT.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode_g == "ast", f"expected AST source-only, got {mode_g}"
        # Source-only -- queries FROM/JOIN/WHERE directly, no inner wrap.
        assert "AS plan_q" not in sql_g
        assert "FACT.SAP_COMPANY_ID AS pv" in sql_g

    def test_discovery_uses_source_only_ast_on_outer_group_by(self):
        from steps.file.starburst_file_base import (
            _derive_count_sql, _derive_group_by_count_sql,
        )
        base = ("SELECT FACT.SAP_COMPANY_ID, SUM(FACT.AMOUNT) "
                "FROM FACT_TABLE FACT "
                "WHERE FACT.RUN_DATE = DATE '2026-06-17' "
                "GROUP BY FACT.SAP_COMPANY_ID")
        _, mode_c = _derive_count_sql(base, dialect="trino")
        _, mode_g = _derive_group_by_count_sql(
            base, "FACT.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode_c == "skip" and mode_g == "ast"

    def test_discovery_skip_count_on_having(self):
        from steps.file.starburst_file_base import _derive_count_sql
        base = ("SELECT FACT.SAP_COMPANY_ID, SUM(FACT.AMOUNT) "
                "FROM FACT_TABLE FACT "
                "GROUP BY FACT.SAP_COMPANY_ID HAVING SUM(FACT.AMOUNT) > 100")
        _, mode = _derive_count_sql(base, dialect="trino")
        assert mode == "skip"

    def test_discovery_uses_source_only_ast_on_limit(self):
        from steps.file.starburst_file_base import _derive_group_by_count_sql
        base = ("SELECT FACT.SAP_COMPANY_ID, FACT.AMOUNT FROM FACT_TABLE FACT "
                "WHERE FACT.RUN_DATE = DATE '2026-06-17' LIMIT 1000")
        _, mode = _derive_group_by_count_sql(
            base, "FACT.SAP_COMPANY_ID", dialect="trino",
        )
        # AST strip drops the LIMIT -- discovery counts source rows
        # without the limit.  Cheap; operator's chunk-time queries get
        # the limit applied properly (it's still in the preserved
        # base_sql at inject time).
        assert mode == "ast"

    def test_discovery_stays_ast_when_base_sql_is_plain(self):
        """Control case: plain SELECT projection FROM ... WHERE ...
        must STAY in AST mode (no perf regression for the common path)."""
        from steps.file.starburst_file_base import (
            _derive_count_sql, _derive_group_by_count_sql,
        )
        base = ("SELECT FACT.SAP_COMPANY_ID, FACT.AMOUNT FROM FACT_TABLE FACT "
                "WHERE FACT.RUN_DATE = DATE '2026-06-17'")
        _, mode_c = _derive_count_sql(base, dialect="trino")
        _, mode_g = _derive_group_by_count_sql(
            base, "FACT.SAP_COMPANY_ID", dialect="trino",
        )
        assert mode_c == "ast" and mode_g == "ast"

    def test_row_count_affecting_shape_helper(self):
        """Direct unit test of the shape detector."""
        import sqlglot
        from steps.file.starburst_file_base import _row_count_affecting_shape
        cases = [
            ("SELECT col FROM t",                                   None),
            ("SELECT col FROM t WHERE x=1",                          None),
            ("SELECT DISTINCT col FROM t",                          "DISTINCT"),
            ("SELECT col FROM t GROUP BY col",                      "outer GROUP BY"),
            ("SELECT col, COUNT(*) FROM t GROUP BY col HAVING COUNT(*) > 1",
                                                                     "outer GROUP BY"),
            ("SELECT col FROM t LIMIT 100",                         "LIMIT"),
        ]
        for sql, expected in cases:
            tree = sqlglot.parse_one(sql, dialect="trino")
            got = _row_count_affecting_shape(tree)
            assert got == expected, f"{sql!r}: got {got!r}, expected {expected!r}"

    def test_per_chunk_completeness_retry_then_isolate_policy(self):
        """2026-06-18 -- user-driven policy revision.  Per-chunk mismatch
        is now treated as POSSIBLY transient for max_chunk_retries
        attempts (writer race / partial Trino disconnect could produce
        a real transient mismatch).  After retries exhausted with
        persistent mismatch: THIS bucket fails but the run CONTINUES
        with remaining buckets so operator can re-trigger just the
        failed bucket(s) at end-of-job.

        Three locks: (a) soft phase retries via continue, (b) hard
        phase isolates (should_stop_process=False so other buckets
        proceed), (c) diagnostic explains both likely causes."""
        import inspect
        from steps.file import starburst_file_base
        src = inspect.getsource(starburst_file_base.StarburstFileBase._execute_chunk_with_retry)
        # SOFT phase: retry loop spins via `continue`
        assert "elif attempt <= plan.max_chunk_retries:" in src
        assert "continue" in src
        assert "transient" in src
        # HARD phase: isolate the failed bucket, run continues
        assert "should_stop_process=False" in src
        assert "persistent across" in src
        # Operator guidance present
        assert "Likely causes" in src
        assert "iceberg snapshot drift" in src

    def test_per_chunk_completeness_honors_fail_on_mismatch(self):
        """When operator sets fail_on_mismatch=False, per-chunk mismatch
        becomes a WARN (not a hard-fail).  Job-level G3 reconcile still
        anchors cumulative completeness."""
        import inspect
        from steps.file import starburst_file_base
        src = inspect.getsource(starburst_file_base.StarburstFileBase._execute_chunk_with_retry)
        # The check still branches on plan.fail_on_mismatch.
        assert "if not plan.fail_on_mismatch:" in src
        assert "treating as success" in src
        # Hard-fail branch still exists when fail_on_mismatch=True,
        # but with retry-then-isolate semantics (not halt-the-run).
        assert "persistent across" in src

    def test_safe_partition_label_renders_bucket_compactly(self):
        """Deep-dive defect A: ``_safe_partition_label`` was rendering
        bucket tuples via ``str()`` which produced
        ``__X100___X101___X102__...`` truncated to 60 chars.  Risk:
        chunk filenames for buckets sharing a common prefix collide.
        Fix renders bucket as ``<first>_to_<last>_<N>v`` -- readable +
        unique."""
        from steps.file.starburst_file_base import StarburstFileBase
        # Single value -- back-compat unchanged.
        assert StarburstFileBase._safe_partition_label("X100") == "X100"
        assert StarburstFileBase._safe_partition_label(None) == "NULL"
        assert StarburstFileBase._safe_partition_label(42) == "42"
        # Bucket of N values -- compact rendering.
        label = StarburstFileBase._safe_partition_label(
            ("X100", "X101", "X102", "X103", "X104", "X105", "X106", "X107"),
        )
        assert label == "X100_to_X107_8v"
        # One-element bucket -- unwrap to scalar form.
        assert StarburstFileBase._safe_partition_label(("A",)) == "A"
        # NULL members render correctly (no Python None leak).
        assert StarburstFileBase._safe_partition_label((None, None, "C", None)) \
            == "NULL_to_NULL_4v"
        # Defensive: empty bucket.
        assert StarburstFileBase._safe_partition_label([]) == "NULL"

    def test_bucketing_preserves_distinct_mode_g2_advisory_contract(self):
        """Deep-dive defect B: discovery_mode='distinct' returns
        ``expected_per_partition = {}`` (per-value counts NOT measured,
        per the docstring on _discover_partition_values).  Naively
        bucketing those values via ``{bucket: sum(...for v in bucket)}``
        would produce ``{tuple: 0, tuple: 0, ...}`` -- non-empty dict of
        zeros.  That makes ``sum_partition_expected`` return 0 instead
        of None, firing a false G2 FAIL chip on the run report.

        Fix: when source counts are empty, bucketed counts stay empty
        -- G2 stays advisory-only.  This test exercises the math at the
        helper layer (the runtime path is async + needs Trino; locking
        the contract here protects the invariant).
        """
        # Simulate the bucketing dict-comp the planner uses:
        values = [f"V{i}" for i in range(20)]
        empty_counts: dict = {}
        bucket_size = 5
        buckets = [
            tuple(values[i:i + bucket_size])
            for i in range(0, len(values), bucket_size)
        ]
        # The fix logic (mirrors what _build_scan_plan does):
        if empty_counts:
            bucketed = {
                b: sum(empty_counts.get(v, 0) for v in b) for b in buckets
            }
        else:
            bucketed = {}
        assert bucketed == {}, (
            "Bucketing must NOT synthesize zero-counts from an empty "
            "expected_per_partition (would fire false G2 FAIL)"
        )

        # And the populated path: sum-over-buckets == sum-over-values.
        populated_counts = {v: 1000 + i for i, v in enumerate(values)}
        bucketed_pop = {
            b: sum(populated_counts.get(v, 0) for v in b) for b in buckets
        }
        assert sum(bucketed_pop.values()) == sum(populated_counts.values())

    def test_bucketing_preserves_g3_completeness_invariant(self):
        """G3 reconcile = sum of per-chunk actuals == G1.  Bucketing
        groups N adjacent values; per-bucket expected count is the sum
        of per-value counts.  Sum over buckets == sum over values
        (mathematical identity).  This test exercises the math, not the
        SQL, to lock the invariant explicitly."""
        # 1139 values with counts; group into ~150 buckets.
        values = [f"V{i:04d}" for i in range(1139)]
        counts = {v: 1000 + i for i, v in enumerate(values)}  # arbitrary
        import math
        max_partitions = 150
        bucket_size = math.ceil(len(values) / max_partitions)
        buckets = [
            tuple(values[i:i + bucket_size])
            for i in range(0, len(values), bucket_size)
        ]
        bucket_counts = {b: sum(counts.get(v, 0) for v in b) for b in buckets}
        assert len(buckets) <= max_partitions
        # G2 anchor invariant: sum over buckets must equal sum over values.
        assert sum(bucket_counts.values()) == sum(counts.values())


class TestVarianceCheckStep:
    """2026-06-18 -- VarianceCheckAgainstPreviousCobRun step.  Compares
    current run's total row count vs the previous COB run's via
    PKG_OTG_VARIANCE.CHECK_VARIANCE; alerts support team on breach."""

    def test_step_module_importable(self):
        """Lock the import path used by step_mapping.yaml."""
        from steps.file.variance_check_against_previous_cob_run import (
            VarianceCheckAgainstPreviousCobRun,
        )
        assert hasattr(VarianceCheckAgainstPreviousCobRun, "_execute_step")
        # Status constants form the contract with the stored proc.
        assert VarianceCheckAgainstPreviousCobRun.STATUS_UNDER == "UNDER_THRESHOLD"
        assert VarianceCheckAgainstPreviousCobRun.STATUS_BREACH == "BREACHED"
        assert VarianceCheckAgainstPreviousCobRun.STATUS_NO_PREV == "NO_PREVIOUS_RUN"
        assert VarianceCheckAgainstPreviousCobRun.STATUS_PREV_ZERO == "PREV_ZERO"

    def test_step_registered_in_step_mapping(self):
        """Lock the step_mapping.yaml registration -- without this the
        FileWorker can't load the class."""
        import yaml
        import os as _os
        here = _os.path.dirname(_os.path.abspath(__file__))
        mapping_path = _os.path.normpath(
            _os.path.join(here, "..", "configs", "step_mapping.yaml")
        )
        with open(mapping_path, "r", encoding="utf-8") as f:
            mappings = yaml.safe_load(f) or {}
        assert "file" in mappings
        assert "VarianceCheckAgainstPreviousCobRun" in mappings["file"]
        entry = mappings["file"]["VarianceCheckAgainstPreviousCobRun"]
        assert entry["module"] == "steps.file.variance_check_against_previous_cob_run"
        assert entry["class"] == "VarianceCheckAgainstPreviousCobRun"

    def test_polling_row_overlay_includes_variance_knobs(self):
        """Operator must be able to drive variance threshold + email +
        breach behaviour from the polling row, without editing per-job
        JSON."""
        from steps.file.starburst_file_base import _POLLING_ROW_OVERLAYS
        keys = {row[0] for row in _POLLING_ROW_OVERLAYS}
        assert "variance_threshold_pct" in keys
        assert "variance_email_to" in keys
        assert "email_on_variance_pass" in keys
        assert "fail_on_variance_breach" in keys

    def test_coerce_bool_accepts_oracle_string_spellings(self):
        from steps.file.variance_check_against_previous_cob_run import (
            VarianceCheckAgainstPreviousCobRun,
        )
        cb = VarianceCheckAgainstPreviousCobRun._coerce_bool
        for t in ("TRUE", "true", "Y", "y", "1", "YES", "yes", True):
            assert cb(t) is True, t
        for f in ("FALSE", "false", "N", "n", "0", "NO", "no", False):
            assert cb(f) is False, f
        # Default applies on unknown / None.
        assert cb(None, default=True) is True
        assert cb(None, default=False) is False
        assert cb("maybe", default=False) is False

    def test_coerce_int_handles_oracle_returns(self):
        from steps.file.variance_check_against_previous_cob_run import (
            VarianceCheckAgainstPreviousCobRun,
        )
        ci = VarianceCheckAgainstPreviousCobRun._coerce_int
        assert ci(42) == 42
        assert ci("42") == 42
        assert ci(None) is None
        assert ci("") is None
        assert ci("not-a-number") is None


class TestStagingDirectory:
    """2026-06-18 -- staging directory per extract under the polling-row
    mapped output folder.  Chunks land in a sub-directory so the mapped
    folder stays clean.  Self-consolidate publishes the final per-source
    file via atomic os.replace to the mapped folder.  Staging dir is
    deleted on SUCCESS and on FAILURE (unless preserve_chunks_on_failure
    is TRUE, then kept for partial recovery)."""

    def test_resolve_output_paths_returns_staging_dir(self, tmp_path):
        from steps.file.starburst_file_base import StarburstFileBase

        class _Step(StarburstFileBase):
            DATASOURCE_NAME = "CLOUD"
            LOG_PREFIX = "test"
            FORCE_MODE = None
        step = _Step.__new__(_Step)  # skip __init__
        import logging
        step.logger = logging.getLogger("test")

        mapped = str(tmp_path)
        job_config = {
            "output_file_location": mapped,
            "output_file_name": "myreport.dat",
            "report_id": 99,
        }
        output_dir, staging_dir, base, ext, delim = step._resolve_output_paths(
            job_config, run_id=12345,
        )
        # Mapped dir unchanged
        assert output_dir == mapped
        # Staging dir LIVES INSIDE mapped dir (same volume -> atomic move)
        assert staging_dir.startswith(mapped)
        # Dot-prefix so default ls hides it; tags include run_id + datasource
        assert os.path.basename(staging_dir).startswith(".staging_12345_CLOUD_")
        # Auto-created
        assert os.path.isdir(staging_dir)
        assert base == "myreport"
        assert ext == "dat"

    def test_chunk_path_lives_in_staging_not_mapped(self, tmp_path):
        from steps.file.starburst_file_base import StarburstFileBase
        class _Step(StarburstFileBase):
            DATASOURCE_NAME = "CLOUD"; LOG_PREFIX = "test"; FORCE_MODE = None
        step = _Step.__new__(_Step)
        import logging
        step.logger = logging.getLogger("test")
        _, staging, base, ext, _ = step._resolve_output_paths(
            {"output_file_location": str(tmp_path), "output_file_name": "r.dat", "report_id": 1},
            run_id=1,
        )
        chunk = step._chunk_file_path(staging, base, ext, 1, ("X100", "X101", "X102"))
        # Chunk lives under staging, NOT mapped
        assert chunk.startswith(staging)
        assert os.path.dirname(chunk) == staging
        # Bucket label format preserved
        assert "part_0001_X100_to_X102_3v.dat" in chunk

    def test_is_pid_alive_helper_classifications(self):
        """Cross-platform helper used by the orphan-cleanup scan."""
        from steps.file.starburst_file_base import _is_pid_alive
        import os
        assert _is_pid_alive(os.getpid()) is True
        assert _is_pid_alive(0) is False
        assert _is_pid_alive(-1) is False
        # Very large pid -- almost certainly not assigned.  On rare
        # systems with huge pid_max this could flake; if so adjust.
        assert _is_pid_alive(999999999) is False

    def test_startup_scan_cleans_orphan_staging_from_dead_pid(self, tmp_path):
        """Layer-2 orphan recovery: a staging dir whose owning PID is
        no longer alive should be auto-rmtree'd on next run startup.
        This is the SIGKILL / machine restart safety net -- without it,
        orphans accumulate forever in the mapped folder."""
        from steps.file.starburst_file_base import StarburstFileBase
        class _Step(StarburstFileBase):
            DATASOURCE_NAME = "CLOUD"; LOG_PREFIX = "t"; FORCE_MODE = None
        import logging
        step = _Step.__new__(_Step)
        step.logger = logging.getLogger("t")
        mapped = str(tmp_path)
        # Plant an orphan staging dir whose pid is dead (999999999).
        orphan = os.path.join(mapped, ".staging_42_CLOUD_20260101_000000_000001_p999999999")
        os.makedirs(orphan, exist_ok=True)
        # Plant a "live" staging dir whose pid IS alive but is OWNED BY
        # ANOTHER PROCESS (use our parent pid -- pytest runner is up).
        # Our-own-pid would be SAFE to clean (couldn't be concurrent
        # since pid is unique per live process); we need a different
        # alive pid to exercise the "skip live owner" branch.
        live_pid = os.getppid()
        live = os.path.join(mapped, f".staging_99_CLOUD_20260101_000000_000002_p{live_pid}")
        os.makedirs(live, exist_ok=True)

        # Trigger a startup scan via _resolve_output_paths.
        _, new_staging, _, _, _ = step._resolve_output_paths(
            {"output_file_location": mapped, "output_file_name": "x.dat", "report_id": 1},
            run_id=42,
        )
        # Orphan gone:
        assert not os.path.exists(orphan)
        # Live left alone:
        assert os.path.exists(live)
        # New dir created:
        assert os.path.isdir(new_staging)
        assert new_staging != orphan and new_staging != live

    def test_staging_dir_name_is_unique_across_concurrent_runs(self, tmp_path):
        """Two runs with the same run_id but different DATASOURCE should
        get DIFFERENT staging dirs (CLOUD vs ONPREM don't collide)."""
        from steps.file.starburst_file_base import StarburstFileBase
        class _CloudStep(StarburstFileBase):
            DATASOURCE_NAME = "CLOUD"; LOG_PREFIX = "c"; FORCE_MODE = None
        class _OnpremStep(StarburstFileBase):
            DATASOURCE_NAME = "ONPREM"; LOG_PREFIX = "o"; FORCE_MODE = None
        import logging
        c = _CloudStep.__new__(_CloudStep); c.logger = logging.getLogger("c")
        o = _OnpremStep.__new__(_OnpremStep); o.logger = logging.getLogger("o")
        jc = {"output_file_location": str(tmp_path), "output_file_name": "r.dat", "report_id": 1}
        _, c_staging, _, _, _ = c._resolve_output_paths(jc, run_id=42)
        _, o_staging, _, _, _ = o._resolve_output_paths(jc, run_id=42)
        assert c_staging != o_staging
        assert "_CLOUD_" in c_staging
        assert "_ONPREM_" in o_staging


class TestPartitionCompletenessContract:
    """2026-06-17 -- user directive: 'data completeness is a key'.
    The G3 reconcile (sum of per-chunk row counts == G1 source row
    count) is the completeness contract.  Verify it's still in place
    and hard-fails on drift -- AST mode doesn't relax it."""

    def test_g3_hard_fails_on_mismatch(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The hard-fail exists.
        assert "G3 reconcile FAILED" in src
        assert "raise ValueError" in src
        # Gated on fail_on_mismatch (which honours bool coercion).
        assert "plan.fail_on_mismatch and sum_actual != plan.expected_total" in src

    def test_completeness_contract_unchanged_by_ast_rewrite(self):
        """AST rewrite shouldn't relax the completeness gate -- the
        G3 reconcile still requires sum(chunk actuals) == G1, regardless
        of how the per-chunk SQL was built (AST inject vs auto-fallback
        wrap)."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The reconcile is in _execute_one_job AFTER all chunks complete --
        # downstream of the per-chunk SQL building.
        assert "sum_actual = sum(r.actual for r in chunk_results if r.success)" in src
        # Per-chunk SQL is built BEFORE the reconcile.
        idx_reconcile = src.index("G3 reconcile FAILED")
        idx_build = src.index("self._add_partition_predicate(")
        assert idx_build < idx_reconcile

    def test_pre_flight_ast_safety_warn_logged(self):
        """When partition mode is selected and base_sql has window funcs
        / set ops / missing-projection, the planner logs WARN(s).  The
        WARNs name the SQL fix (rewrite the SQL), NOT a planner toggle --
        there is no rewrite_mode operator knob (intentional)."""
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # The validator hook in _build_scan_plan exists.
        assert "_validate_base_sql_ast_safe" in src
        # The G3 reconcile is still the downstream guard.
        assert "G3 reconcile" in src


class TestSparkSubmitSysPathProbe:
    """2026-06-17 -- spark-submit uploads ONLY the entry script to a
    temp dir, so __file__.parent is an EMPTY upload folder.  Every
    standalone must probe well-known prod roots for the log_config
    sentinel rather than trusting __file__.parent.  Tested by source-grep
    rather than via import because re-importing the standalone modules
    rewires sys.path globally."""

    STANDALONES = (
        "file_standalone.py",
        "file_to_oracle_standalone.py",
        "s3_query_standalone.py",
        "sap_odata_standalone.py",
    )

    def test_every_standalone_probes_sentinel(self):
        etl_root = Path(__file__).resolve().parent.parent
        for name in self.STANDALONES:
            src = (etl_root / name).read_text(encoding="utf-8")
            assert '_SENTINEL = "log_config.py"' in src, f"{name} missing sentinel"
            assert "_CANDIDATE_ROOTS" in src, f"{name} missing candidates list"
            # All four candidate roots present.
            assert '"/usr/local/spark/pvc/code"' in src, f"{name} missing prod root"
            assert '"/usr/local/spark/pvc/code/etl"' in src, f"{name} missing etl subpkg root"
            assert '"/usr/local/spark/pvc"' in src, f"{name} missing PVC root"
            # ETL_HOME env override honoured.
            assert 'os.environ.get("ETL_HOME")' in src, f"{name} missing ETL_HOME override"
            # __file__.parent kept as final fallback.
            assert "str(Path(__file__).resolve().parent)" in src, f"{name} missing __file__.parent fallback"


class TestStructuredPartitionFailure:
    """170M-record concern: when many partitions fail, the error
    message must enumerate WHICH partitions and how many succeeded so
    a re-run knows what to target."""

    def test_failure_message_has_structured_summary(self):
        from steps.file import starburst_file_base
        src = Path(starburst_file_base.__file__).read_text(encoding="utf-8")
        # Cap-at-5 + tail-summary pattern in the error message.
        assert "successful_count" in src
        assert "failed[:5]" in src
        assert "partial_failure" in src


class TestBackupIfExistsBackupMode:
    """`backup_if_exists(path, mode='backup')` moves a prior-run file
    to `<dirname>/backup_<ts>/` so the re-run can write fresh without
    silently clobbering the operator's prior delivery."""

    def test_missing_path_is_noop(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        assert backup_if_exists(str(tmp_path / "nope.dat")) is None

    def test_moves_existing_file_to_backup_folder(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        src = tmp_path / "report.dat"
        src.write_text("prior content", encoding="utf-8")
        backup_path = backup_if_exists(str(src), backup_ts="20260613_120000")
        # Source gone; backup carries the prior payload.
        assert not src.exists()
        assert backup_path is not None
        assert "backup_20260613_120000" in backup_path
        assert os.path.exists(backup_path)
        with open(backup_path, "r", encoding="utf-8") as f:
            assert f.read() == "prior content"

    def test_default_timestamp_when_none_provided(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        src = tmp_path / "report.dat"
        src.write_text("x", encoding="utf-8")
        backup_path = backup_if_exists(str(src))
        assert backup_path is not None
        import re
        assert re.search(r"backup_\d{8}_\d{6}", backup_path)

    def test_collision_appends_counter(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        # Create first backup.
        src = tmp_path / "report.dat"
        src.write_text("v1", encoding="utf-8")
        first = backup_if_exists(str(src), backup_ts="20260613_120000")
        # Recreate source; second backup with same ts must not clobber.
        src.write_text("v2", encoding="utf-8")
        second = backup_if_exists(str(src), backup_ts="20260613_120000")
        assert second is not None and second != first
        assert second.endswith(".1")


class TestBackupIfExistsDeleteMode:
    """`backup_if_exists(path, mode='delete')` removes the prior-run
    file outright -- for operators worried about backup folder bloat
    on shared NFS."""

    def test_delete_mode_removes_file_no_backup_folder(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        src = tmp_path / "report.dat"
        src.write_text("doomed", encoding="utf-8")
        result = backup_if_exists(str(src), mode="delete")
        assert result is None  # delete mode returns None
        assert not src.exists()
        # No backup folder created.
        assert not any(p.name.startswith("backup_") for p in tmp_path.iterdir())

    def test_delete_mode_noop_on_missing(self, tmp_path):
        from steps.file.run_state import backup_if_exists
        assert backup_if_exists(str(tmp_path / "nope.dat"), mode="delete") is None


class TestDispatchSitesThreadBackupKnobs:
    """All three dispatch sites must thread backup_ts + prior_output_mode
    onto the task so step-level writes can honor the flag."""

    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
        "polling_service/dispatcher.py",
    ])
    def test_backup_ts_and_mode_injected(self, rel):
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        assert 'task["backup_ts"] = backup_ts' in src, (
            f"{rel}: must inject task['backup_ts']"
        )
        assert 'task["prior_output_mode"] = prior_output_mode' in src, (
            f"{rel}: must inject task['prior_output_mode']"
        )
        # Polling-row precedence over yaml fallback over default.
        assert "prior_output_mode" in src
        assert '"backup"' in src, (
            f"{rel}: must default prior_output_mode to 'backup'"
        )


class TestWriteSitesCallBackupIfExists:
    """Every step that overwrites a deliverable must call
    backup_if_exists first, threading the per-run backup_ts + mode."""

    @pytest.mark.parametrize("rel", [
        "steps/file/merge_files.py",
        "steps/file/compress_file.py",
        "steps/file/create_ctl_file.py",
        "steps/file/run_report.py",
        "steps/file/starburst_file_base.py",
    ])
    def test_write_site_calls_backup_if_exists(self, rel):
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        assert "backup_if_exists" in src, (
            f"{rel}: write site must call backup_if_exists before "
            f"overwriting any prior-run deliverable"
        )


# ─── 8. Backup reads polling-row column, not derived path ──────────────


class TestBackupReadsPollingRow:
    """The backup helper at run START must read from polling-row
    columns (``file_location`` / ``output_file_location``), NOT from
    a derived run_report.output_dir.  task["output_dir"] gets set
    later inside execute_tasks; at backup time it isn't there yet."""

    @pytest.mark.parametrize("rel", [
        "file_standalone.py",
        "file_to_oracle_standalone.py",
    ])
    def test_backup_block_reads_file_location(self, rel):
        src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
        # Locate the backup_stale_sidecar block.
        backup_idx = src.find("backup_stale_sidecar(")
        assert backup_idx > 0
        # Look back ~500 chars for the resolver line.
        prelude = src[max(0, backup_idx - 500):backup_idx]
        assert 'get("file_location")' in prelude, (
            f"{rel}: pre-run backup must read polling-row 'file_location' "
            f"column (output_dir isn't set on task dict yet at this point)"
        )
