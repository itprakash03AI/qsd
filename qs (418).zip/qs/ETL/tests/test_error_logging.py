"""Tests for detailed error logging in the file standalones (2026-06-12).

User reported that the run log only showed ``RUN FAILED: <msg>`` --
the full traceback lived only in the HTML report and the per-task
state at failure wasn't captured anywhere.

Locks the contract:
  * Per-step except block logs full traceback + task-state snapshot.
  * Outer RUN FAILED block logs full traceback (not just message).
  * Cleanup-on-failure exception also gets its full traceback logged.
  * _summarise_task_state names every key downstream steps inspect.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. _summarise_task_state ──────────────────────────────────────────


class TestSummariseTaskState:
    def test_keys_listed_in_summary(self):
        from file_standalone import _summarise_task_state
        task = {
            "run_id": 42, "fk_dag_id": "DAG_X",
            "job_results": [{"a": 1}, {"b": 2}, {"c": 3}],
            "chunk_files": ["c1.dat", "c2.dat"],
        }
        out = _summarise_task_state(task)
        # Present keys rendered with value.
        assert "run_id=42" in out
        assert "fk_dag_id='DAG_X'" in out
        # Lists get a len + first-N preview.
        assert "(len=3)" in out
        assert "(len=2)" in out
        # Absent keys still rendered so the operator sees the gap.
        assert "output_dir=<absent>" in out
        assert "consolidated_file=<absent>" in out

    def test_long_values_truncated(self):
        from file_standalone import _summarise_task_state
        task = {"sql_query_path": "x" * 500}
        out = _summarise_task_state(task)
        # 200 chars + "..." marker.
        assert "..." in out


# ─── 2. Source-level lock: per-step except logs traceback + state ─────


class TestPerStepErrorLogging:
    def test_file_standalone_logs_task_state_and_traceback(self):
        src = (Path(ETL_ROOT) / "file_standalone.py").read_text(encoding="utf-8")
        # The per-step except block must call _summarise_task_state.
        assert "_summarise_task_state(task)" in src
        # And include traceback in the logged record.
        assert "TASK STATE AT FAILURE" in src
        assert "TRACEBACK:" in src

    def test_file_to_oracle_standalone_logs_task_state_and_traceback(self):
        src = (Path(ETL_ROOT) / "file_to_oracle_standalone.py").read_text(encoding="utf-8")
        assert "_summarise_task_state(task)" in src
        assert "TASK STATE AT FAILURE" in src
        assert "TRACEBACK:" in src


# ─── 3. Outer RUN FAILED block logs full traceback ─────────────────────


class TestRunFailedBlockLogsTraceback:
    """2026-06-22 -- the RUN FAILED + cleanup-traceback logging moved
    into the SHARED helper StandaloneRunLifecycle.handle_run_failure
    (so every standalone gets identical failure-email behavior).
    Tests now verify:
      1. Each standalone CALLS the shared helper (regression guard)
      2. The shared helper itself contains the RUN FAILED + traceback
         + cleanup logging"""

    def test_shared_helper_logs_run_failed_with_traceback(self):
        src = (Path(ETL_ROOT) / "standalone_lifecycle.py").read_text(encoding="utf-8")
        idx = src.find('"RUN FAILED:')
        assert idx > 0, "shared helper missing RUN FAILED log"
        block = src[idx:idx + 500]
        assert "TRACEBACK:" in block
        assert "traceback_text" in block

    def test_shared_helper_logs_cleanup_error(self):
        src = (Path(ETL_ROOT) / "standalone_lifecycle.py").read_text(encoding="utf-8")
        idx = src.find('"Cleanup-on-failure raised')
        assert idx > 0, "shared helper missing cleanup-on-failure log"

    def test_file_standalone_calls_shared_handler(self):
        """Regression guard: file_standalone must use the shared helper."""
        src = (Path(ETL_ROOT) / "file_standalone.py").read_text(encoding="utf-8")
        assert "StandaloneRunLifecycle.handle_run_failure" in src

    def test_file_to_oracle_calls_shared_handler(self):
        src = (Path(ETL_ROOT) / "file_to_oracle_standalone.py").read_text(encoding="utf-8")
        assert "StandaloneRunLifecycle.handle_run_failure" in src

    def test_file_standalone_calls_shared_finalise(self):
        src = (Path(ETL_ROOT) / "file_standalone.py").read_text(encoding="utf-8")
        assert "StandaloneRunLifecycle.finalise_run_report" in src

    def test_file_to_oracle_calls_shared_finalise(self):
        src = (Path(ETL_ROOT) / "file_to_oracle_standalone.py").read_text(encoding="utf-8")
        assert "StandaloneRunLifecycle.finalise_run_report" in src
