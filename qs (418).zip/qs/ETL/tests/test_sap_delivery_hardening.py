"""Phase 134-K — DeliverFiles + CA-bundle hardening tests.

Covers audit SERIOUS #2 / #7 / #8 / #13:

  * SFTP requires a host-key policy (RejectPolicy by default,
    AutoAddPolicy ONLY with explicit ``sftp_auto_add_host=true``).
  * SFTP mkdir is recursive (multi-level remote dirs).
  * Data file uploads BEFORE the CTL file (S3 + NFS + SFTP).
  * SFTP uses ``.tmp`` + posix_rename so partial uploads never look
    complete.
  * S3 multipart uploads are aborted on exception.
  * NFS copies via ``.tmp`` + ``os.replace`` (atomic on the same
    filesystem).
  * SapOdataBase honours ``ca_bundle_path`` for SSL verification and
    fails loud when the file doesn't exist.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    from steps.s3_to_file.deliver_files import DeliverFiles
    return DeliverFiles(
        starburst_clients={}, oracle_data_manager=None,
        logger=MagicMock(), config={},
    )


def _make_task(tmp_path: Path, with_ctl: bool = True) -> dict:
    """Two files: a fake compressed data file + a fake CTL file."""
    data = tmp_path / "MEBAL_2025_009.csv.gz"
    data.write_bytes(b"\x1f\x8b\x08\x00\x00\x00\x00\x00")  # gz header
    task = {"compressed_file": str(data), "totalcount": 42}
    if with_ctl:
        ctl = tmp_path / "MEBAL_2025_009.ctl"
        ctl.write_text("md5Checksum:abc\ncsv-separator:|\n")
        task["ctl_file"] = str(ctl)
    task["sql_query_path"] = ""  # config keyed in task
    task["log_file"] = str(tmp_path / "log.txt")
    return task


# ── NFS delivery ────────────────────────────────────────────────────


class TestNfsDelivery:
    def test_data_uploads_before_ctl_via_atomic_rename(self, tmp_path):
        step = _make_step()
        task = _make_task(tmp_path)
        dest = tmp_path / "nfs_out"
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"nfs","nfs_dest_dir":"%s"}'
            % str(dest).replace("\\", "/")
        )
        task["sql_query_path"] = str(cfg_path)

        asyncio.run(step._execute_step(
            task, worker_connection_string="",
            dest_connection_string="", step_name="DeliverFiles",
        ))

        # Both files landed.
        data_dest = dest / "MEBAL_2025_009.csv.gz"
        ctl_dest = dest / "MEBAL_2025_009.ctl"
        assert data_dest.exists()
        assert ctl_dest.exists()
        # No .tmp residue.
        assert not (dest / "MEBAL_2025_009.csv.gz.tmp").exists()
        assert not (dest / "MEBAL_2025_009.ctl.tmp").exists()
        # CTL contents preserved.
        assert "md5Checksum:abc" in ctl_dest.read_text()


# ── S3 delivery ─────────────────────────────────────────────────────


class TestS3Delivery:
    def test_data_uploads_before_ctl_explicit_ordering(self, tmp_path):
        """boto3.upload_file is called twice — first with the data
        file, then with the CTL file.  Locks the ordering contract."""
        step = _make_step()
        task = _make_task(tmp_path)
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"s3","s3_bucket":"out","s3_prefix":"sap/mebal"}'
        )
        task["sql_query_path"] = str(cfg_path)

        fake_client = MagicMock()
        with patch("boto3.client", return_value=fake_client):
            asyncio.run(step._execute_step(
                task, worker_connection_string="",
                dest_connection_string="", step_name="DeliverFiles",
            ))

        # 2 calls.  First arg is local-file path, third is S3 key.
        calls = fake_client.upload_file.call_args_list
        assert len(calls) == 2
        # call 0 → data file, call 1 → CTL file
        first_path = calls[0][0][0]
        second_path = calls[1][0][0]
        assert first_path.endswith(".csv.gz"), (
            f"data file did not upload first: {first_path!r}"
        )
        assert second_path.endswith(".ctl"), (
            f"CTL file did not upload last: {second_path!r}"
        )

    def test_multipart_upload_aborted_on_exception(self, tmp_path):
        """When upload_file raises, the engine calls
        list_multipart_uploads + abort_multipart_upload for cleanup."""
        from botocore.exceptions import ClientError

        step = _make_step()
        task = _make_task(tmp_path)
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"s3","s3_bucket":"out","s3_prefix":"x"}'
        )
        task["sql_query_path"] = str(cfg_path)

        fake_client = MagicMock()
        fake_client.upload_file.side_effect = ClientError(
            {"Error": {"Code": "500", "Message": "boom"}}, "UploadPart"
        )
        fake_client.list_multipart_uploads.return_value = {
            "Uploads": [{"Key": "x/MEBAL_2025_009.csv.gz", "UploadId": "U1"}]
        }
        with patch("boto3.client", return_value=fake_client):
            with pytest.raises(ClientError):
                asyncio.run(step._execute_step(
                    task, worker_connection_string="",
                    dest_connection_string="", step_name="DeliverFiles",
                ))

        # Abort was called for the in-flight upload.
        fake_client.abort_multipart_upload.assert_called_once_with(
            Bucket="out", Key="x/MEBAL_2025_009.csv.gz", UploadId="U1",
        )


# ── SFTP delivery ───────────────────────────────────────────────────


class TestSftpHostKey:
    """Audit SERIOUS #2 — paramiko.SSHClient MUST have a host-key
    policy set BEFORE connect.  Default policy is RejectPolicy unless
    sftp_auto_add_host=true is explicitly set.
    """

    def _setup_paramiko_mocks(self):
        """Build patched paramiko module fixtures.  Returns
        (mock_paramiko, fake_client, fake_sftp).
        """
        mock_paramiko = MagicMock()
        fake_client = MagicMock()
        fake_sftp = MagicMock()
        fake_client.open_sftp.return_value = fake_sftp
        # paramiko.SSHClient() → fake_client
        mock_paramiko.SSHClient.return_value = fake_client
        # Policies are instances of these classes — patch them too.
        mock_paramiko.AutoAddPolicy = MagicMock()
        mock_paramiko.RejectPolicy = MagicMock()
        # stat behaviour: pretend remote dir already exists
        fake_sftp.stat.return_value = MagicMock()
        return mock_paramiko, fake_client, fake_sftp

    def test_default_uses_reject_policy(self, tmp_path):
        step = _make_step()
        task = _make_task(tmp_path)
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"sftp","sftp_host":"sftp.example.com",'
            '"sftp_username":"u","sftp_password":"p",'
            '"sftp_remote_dir":"/inbound"}'
        )
        task["sql_query_path"] = str(cfg_path)

        mp, fake_client, _ = self._setup_paramiko_mocks()
        with patch.dict("sys.modules", {"paramiko": mp}):
            asyncio.run(step._execute_step(
                task, worker_connection_string="",
                dest_connection_string="", step_name="DeliverFiles",
            ))
        # RejectPolicy used by default, NOT AutoAddPolicy.
        assert mp.RejectPolicy.called, "default policy should be RejectPolicy"
        assert not mp.AutoAddPolicy.called, (
            "AutoAddPolicy must not be used by default — that's MITM-trivial"
        )
        # Policy is set BEFORE connect (ordering matters — paramiko
        # only consults the policy during connect).
        method_order = [
            c[0] for c in fake_client.method_calls
            if c[0] in ("set_missing_host_key_policy", "connect")
        ]
        assert method_order.index("set_missing_host_key_policy") < method_order.index("connect")

    def test_auto_add_only_when_explicitly_enabled(self, tmp_path):
        step = _make_step()
        task = _make_task(tmp_path)
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"sftp","sftp_host":"sftp.example.com",'
            '"sftp_username":"u","sftp_password":"p",'
            '"sftp_remote_dir":"/inbound",'
            '"sftp_auto_add_host":true}'
        )
        task["sql_query_path"] = str(cfg_path)

        mp, _, _ = self._setup_paramiko_mocks()
        with patch.dict("sys.modules", {"paramiko": mp}):
            asyncio.run(step._execute_step(
                task, worker_connection_string="",
                dest_connection_string="", step_name="DeliverFiles",
            ))
        # AutoAddPolicy used — bootstrap mode.
        assert mp.AutoAddPolicy.called


class TestSftpRecursiveMkdir:
    """Audit SERIOUS #8 — multi-level remote dirs must be created
    parent-by-parent.
    """

    def test_recursive_mkdir_creates_missing_parents(self):
        from steps.s3_to_file.deliver_files import DeliverFiles
        sftp = MagicMock()
        # First two levels don't exist; the third does.
        existing = {"/a/b/c"}

        def fake_stat(path):
            if path in existing:
                return MagicMock()
            raise IOError(f"missing {path}")

        def fake_mkdir(path):
            existing.add(path)

        sftp.stat.side_effect = fake_stat
        sftp.mkdir.side_effect = fake_mkdir
        DeliverFiles._sftp_makedirs(sftp, "/a/b/c/d/e")

        # mkdir was called for the missing levels in order.
        created = [c[0][0] for c in sftp.mkdir.call_args_list]
        assert created == ["/a", "/a/b", "/a/b/c/d", "/a/b/c/d/e"]

    def test_skips_when_top_level_already_exists(self):
        from steps.s3_to_file.deliver_files import DeliverFiles
        sftp = MagicMock()
        sftp.stat.return_value = MagicMock()  # everything exists
        DeliverFiles._sftp_makedirs(sftp, "/already/here")
        assert not sftp.mkdir.called


class TestSftpAtomicRename:
    """Audit SERIOUS #7 — SFTP upload writes ``<remote>.tmp`` then
    renames to the final path so a crashed upload never leaves a
    half-file the downstream reader can mistake for complete.
    """

    def test_put_targets_tmp_then_posix_rename(self, tmp_path):
        step = _make_step()
        task = _make_task(tmp_path)
        cfg_path = tmp_path / "cfg.json"
        cfg_path.write_text(
            '{"delivery_type":"sftp","sftp_host":"sftp.example.com",'
            '"sftp_username":"u","sftp_password":"p",'
            '"sftp_remote_dir":"/inbound"}'
        )
        task["sql_query_path"] = str(cfg_path)

        # Build paramiko module mocks.
        mp = MagicMock()
        fake_client = MagicMock()
        fake_sftp = MagicMock()
        fake_client.open_sftp.return_value = fake_sftp
        mp.SSHClient.return_value = fake_client
        fake_sftp.stat.return_value = MagicMock()

        with patch.dict("sys.modules", {"paramiko": mp}):
            asyncio.run(step._execute_step(
                task, worker_connection_string="",
                dest_connection_string="", step_name="DeliverFiles",
            ))

        # Every sftp.put target ends in .tmp.
        for put_call in fake_sftp.put.call_args_list:
            tmp_target = put_call[0][1]
            assert tmp_target.endswith(".tmp"), (
                f"SFTP put target {tmp_target!r} not via .tmp — "
                "atomic-rename contract violated"
            )

        # posix_rename called for every put.
        assert fake_sftp.posix_rename.call_count == fake_sftp.put.call_count


# ── CA bundle threading ─────────────────────────────────────────────


class TestCaBundleThreading:
    """Audit SERIOUS #11 + #13 — SapOdataBase._build_session honours
    ``ca_bundle_path``, coerces NULL verify_ssl to True, and fails
    loud when the CA bundle path doesn't exist.
    """

    def _make_base(self):
        from steps.sap.sap_odata_base import SapOdataBase

        class _Probe(SapOdataBase):
            async def _execute_step(self, *args, **kwargs):
                return 0

        return _Probe(
            starburst_clients={}, oracle_data_manager=None,
            logger=MagicMock(), config={},
        )

    def test_ca_bundle_path_used_when_set(self, tmp_path):
        ca = tmp_path / "corp-ca.pem"
        ca.write_text("dummy pem")
        b = self._make_base()
        sess = b._build_session({
            'sap_username': 'u', 'sap_password': 'p',
            'verify_ssl': True,
            'ca_bundle_path': str(ca),
        })
        assert sess.verify == str(ca)

    def test_missing_ca_bundle_falls_back_to_system_store(self, tmp_path):
        """2026-06-06 policy change: a missing ca_bundle_path no longer
        HALTS the run -- raising blocked perfectly fine system-CA runs
        when an operator left a stale CA_BUNDLE_PATH in the row.
        Instead we log a WARN + fall back to the system CA store
        (session.verify=True).  Verify the fallback shape.
        """
        b = self._make_base()
        # MUST NOT raise -- log + fall back.
        sess = b._build_session({
            'sap_username': 'u', 'sap_password': 'p',
            'verify_ssl': True,
            'ca_bundle_path': str(tmp_path / "does-not-exist.pem"),
        })
        # Fell back to system CA store (verify=True), did NOT silently
        # disable SSL.
        assert sess.verify is True

    def test_null_verify_ssl_coerces_to_true(self, tmp_path):
        """NULL verify_ssl must coerce to True (safe default), NOT
        bool(None)=False which would silently disable SSL.
        """
        b = self._make_base()
        sess = b._build_session({
            'sap_username': 'u', 'sap_password': 'p',
            'verify_ssl': None,   # ← NULL from the DB column
        })
        assert sess.verify is True, (
            "NULL verify_ssl silently disabled SSL — audit SERIOUS #11"
        )

    def test_explicit_false_verify_ssl_disables(self, tmp_path):
        """Explicit False stays False (the on-prem self-signed escape)."""
        b = self._make_base()
        sess = b._build_session({
            'sap_username': 'u', 'sap_password': 'p',
            'verify_ssl': False,
        })
        assert sess.verify is False

    def test_verify_ssl_false_always_wins_over_ca_bundle(self, tmp_path):
        """2026-06-06 precedence reversal: ``verify_ssl=False`` is the
        HIGHEST precedence -- ca_bundle_path is IGNORED.  The operator
        said 'no SSL', we respect it everywhere (previously a stale
        CA_BUNDLE_PATH env var sneaked verification back on past the
        explicit ``verify=False`` flag).  Locks the new contract.
        """
        ca = tmp_path / "ca.pem"
        ca.write_text("x")
        b = self._make_base()
        sess = b._build_session({
            'sap_username': 'u', 'sap_password': 'p',
            'verify_ssl': False,           # hard skip wins
            'ca_bundle_path': str(ca),     # ignored
        })
        assert sess.verify is False, (
            "verify_ssl=False MUST win over ca_bundle_path "
            "(operator opted out of SSL verification)"
        )
