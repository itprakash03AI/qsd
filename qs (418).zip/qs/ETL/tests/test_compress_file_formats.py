"""Tests for the merged CompressFile (2026-06-12).

Locks the contract:
  * Multi-format support (gzip / zip / tar / tar.gz) from refer_compresfile.
  * Per-file md5 + sha256 checksums of the ARCHIVE (existing pipeline).
  * Integrity validation of the produced archive (refer_compresfile).
  * Sidecar hydration on entry (existing).
  * Same task["compress_results"] shape downstream CreateControlFile reads.
  * NO CentralizedLogger (memory rule).
"""
from __future__ import annotations

import gzip
import os
import sys
import tarfile
import zipfile
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _make_step():
    """Build a bare CompressFile instance bypassing BaseStep.__init__."""
    from steps.file.compress_file import CompressFile
    s = CompressFile.__new__(CompressFile)
    s.logger = MagicMock()
    from steps.file.run_state import RunArtifacts
    s.artifacts = RunArtifacts(logger=MagicMock())
    s.run_report = None
    s.supported_formats = ("gzip", "zip", "tar", "tar.gz")
    return s


# ─── 1. Format selection + filename derivation ─────────────────────────


class TestFormatHelpers:
    def test_get_format_default_is_gzip(self):
        step = _make_step()
        assert step._get_compression_format({}) == "gzip"

    def test_get_format_reads_task_knob(self):
        step = _make_step()
        assert step._get_compression_format({"compression_format": "zip"}) == "zip"
        assert step._get_compression_format({"compression_format": "TAR"}) == "tar"

    def test_unsupported_format_raises(self):
        step = _make_step()
        with pytest.raises(ValueError, match="Unsupported compression_format"):
            step._get_compression_format({"compression_format": "rar"})

    @pytest.mark.parametrize("fmt,source,expected", [
        ("gzip",   "/tmp/report.dat", "/tmp/report.dat.gz"),
        ("zip",    "/tmp/report.dat", "/tmp/report.zip"),
        ("tar",    "/tmp/report.dat", "/tmp/report.tar"),
        ("tar.gz", "/tmp/report.dat", "/tmp/report.tar.gz"),
    ])
    def test_compressed_filename(self, fmt, source, expected):
        step = _make_step()
        # normalise separators to be cross-OS safe.
        got = step._compressed_filename(source, fmt).replace("\\", "/")
        assert got == expected


# ─── 2. Multi-format compress + validation ──────────────────────────────


class TestCompressOne:
    @pytest.mark.parametrize("fmt", ["gzip", "zip", "tar", "tar.gz"])
    def test_compresses_and_validates_each_format(self, tmp_path, fmt):
        step = _make_step()
        src = tmp_path / "report.dat"
        src.write_text("col_a|col_b\n1|x\n2|y\n3|z\n", encoding="utf-8")
        res = step._compress_one(
            str(src), fmt, level=6, delete_uncompressed=False,
        )
        assert res["status"] == "success"
        assert res["format"] == fmt
        assert res["validation_passed"] is True
        assert os.path.exists(res["compressed_file"])
        assert res["compressed_size"] > 0
        assert res["uncompressed_size"] == len(src.read_bytes())
        # md5 + sha256 always present.
        assert len(res["md5_checksum"]) == 32
        assert len(res["sha256_checksum"]) == 64
        # Source preserved when delete_uncompressed=False.
        assert src.exists()

    def test_gzip_archive_readable(self, tmp_path):
        step = _make_step()
        src = tmp_path / "x.dat"
        src.write_text("hello world", encoding="utf-8")
        res = step._compress_one(str(src), "gzip", level=6, delete_uncompressed=False)
        with gzip.open(res["compressed_file"], "rb") as gz:
            assert gz.read() == b"hello world"

    def test_zip_archive_contains_source(self, tmp_path):
        step = _make_step()
        src = tmp_path / "x.dat"
        src.write_text("hello", encoding="utf-8")
        res = step._compress_one(str(src), "zip", level=6, delete_uncompressed=False)
        with zipfile.ZipFile(res["compressed_file"], "r") as zf:
            assert "x.dat" in zf.namelist()
            assert zf.read("x.dat") == b"hello"

    def test_tar_archive_contains_source(self, tmp_path):
        step = _make_step()
        src = tmp_path / "x.dat"
        src.write_text("hello", encoding="utf-8")
        res = step._compress_one(str(src), "tar", level=6, delete_uncompressed=False)
        with tarfile.open(res["compressed_file"], "r") as tar:
            names = tar.getnames()
            assert "x.dat" in names

    def test_targz_archive_contains_source(self, tmp_path):
        step = _make_step()
        src = tmp_path / "x.dat"
        src.write_text("hello", encoding="utf-8")
        res = step._compress_one(str(src), "tar.gz", level=6, delete_uncompressed=False)
        with tarfile.open(res["compressed_file"], "r:gz") as tar:
            assert "x.dat" in tar.getnames()

    def test_delete_uncompressed_removes_source(self, tmp_path):
        step = _make_step()
        src = tmp_path / "x.dat"
        src.write_text("hello", encoding="utf-8")
        step._compress_one(str(src), "gzip", level=6, delete_uncompressed=True)
        assert not src.exists()

    def test_empty_source_raises(self, tmp_path):
        step = _make_step()
        src = tmp_path / "empty.dat"
        src.write_text("", encoding="utf-8")
        with pytest.raises(ValueError, match="source is empty"):
            step._compress_one(str(src), "gzip", level=6, delete_uncompressed=False)

    def test_missing_source_raises(self, tmp_path):
        step = _make_step()
        with pytest.raises(ValueError, match="source not found"):
            step._compress_one(
                str(tmp_path / "nope.dat"), "gzip", level=6, delete_uncompressed=False,
            )


# ─── 3. Source-level contract locks ─────────────────────────────────────


class TestContractLocks:
    def test_no_centralized_logger(self):
        """Memory rule: never CentralizedLogger -- always
        build_module_logger pattern.  Check the IMPORT lines / usage,
        not the docstring (which legitimately calls out the rule)."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "compress_file.py").read_text(encoding="utf-8")
        import ast
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = getattr(node, "module", None) or ""
                names = " ".join(n.name for n in node.names)
                combined = f"{module} {names}"
                assert "CentralizedLogger" not in combined, (
                    f"compress_file imports CentralizedLogger ({combined!r}) — "
                    f"file-flow architecture rule forbids it"
                )
                assert "core_libs.logger" not in module, (
                    f"compress_file imports from core_libs.logger ({module!r})"
                )

    def test_hydrates_from_sidecar(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "compress_file.py").read_text(encoding="utf-8")
        assert "hydrate_task_from_sidecar(" in src

    def test_saves_sidecar(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "compress_file.py").read_text(encoding="utf-8")
        assert "save_task_state(" in src

    def test_registers_artifacts(self):
        src = (Path(ETL_ROOT) / "steps" / "file" / "compress_file.py").read_text(encoding="utf-8")
        assert "RunArtifacts.COMPRESSED" in src

    def test_supports_all_four_formats(self):
        from steps.file.compress_file import SUPPORTED_FORMATS
        assert set(SUPPORTED_FORMATS) == {"gzip", "zip", "tar", "tar.gz"}

    def test_returns_existing_pipeline_shape(self):
        """Lock the dict keys downstream CreateControlFile reads."""
        src = (Path(ETL_ROOT) / "steps" / "file" / "compress_file.py").read_text(encoding="utf-8")
        for key in (
            '"compressed_file"', '"md5_checksum"', '"sha256_checksum"',
            '"uncompressed_size"', '"compressed_size"', '"status"',
        ):
            assert key in src, f"compress_file.py missing key {key}"
