"""Tests for the shared Starburst config loader + the file/oracle
wiring that consumes it.

The loader + wiring close the 'Starburst creds duplicated across N
job JSONs + INI sections + polling-row columns' problem flagged
2026-06-12.
"""
from __future__ import annotations

import json
import os
import sys
import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 1. starburst_config_loader.shared_creds_for ───────────────────────


class TestSharedCredsResolution:
    @pytest.fixture(autouse=True)
    def _reset_cache(self):
        from starburst_config_loader import reset_cache
        reset_cache()
        yield
        reset_cache()

    def _write_shared(self, tmp_path: Path, body: dict) -> Path:
        p = tmp_path / "starburst_config.yaml"
        import yaml
        p.write_text(yaml.safe_dump(body), encoding="utf-8")
        return p

    def test_empty_when_no_file(self, monkeypatch, tmp_path):
        """No shared YAML anywhere -> empty strings, no crash."""
        from starburst_config_loader import shared_creds_for
        import starburst_config_loader as mod
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no_prod.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(tmp_path / "no_local.yaml"))
        mod.reset_cache()
        out = shared_creds_for("oncloud")
        assert out["user"] == ""
        assert out["password"] == ""
        assert out["url"] == ""

    def test_root_user_shared_across_endpoints(self, monkeypatch, tmp_path):
        """Root-level user/password applies to BOTH oncloud and onprem
        unless an endpoint-specific override is set — the user's stated
        ask ('one config used across both')."""
        import starburst_config_loader as mod
        p = self._write_shared(tmp_path, {
            "starburst": {
                "user": "shared_user",
                "password": "shared_pw",
                "oncloud": {"url": "trino://cloud:443/cat/sch"},
                "onprem":  {"url": "trino://onprem:443/cat/sch"},
            }
        })
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "nope.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(p))
        mod.reset_cache()
        oncloud = mod.shared_creds_for("oncloud")
        onprem = mod.shared_creds_for("onprem")
        assert oncloud["user"] == "shared_user"
        assert oncloud["password"] == "shared_pw"
        assert oncloud["url"] == "trino://cloud:443/cat/sch"
        assert onprem["user"] == "shared_user"
        assert onprem["password"] == "shared_pw"
        assert onprem["url"] == "trino://onprem:443/cat/sch"

    def test_endpoint_override_wins_over_root(self, monkeypatch, tmp_path):
        import starburst_config_loader as mod
        p = self._write_shared(tmp_path, {
            "starburst": {
                "user": "root_user",
                "password": "root_pw",
                "oncloud": {"url": "u", "user": "cloud_user", "password": "cloud_pw"},
                "onprem":  {"url": "u"},
            }
        })
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "nope.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(p))
        mod.reset_cache()
        oncloud = mod.shared_creds_for("oncloud")
        onprem = mod.shared_creds_for("onprem")
        assert oncloud["user"] == "cloud_user"        # endpoint wins
        assert oncloud["password"] == "cloud_pw"
        assert onprem["user"] == "root_user"          # inherits root

    def test_env_var_fallback(self, monkeypatch, tmp_path):
        """No file, env vars set -> env vars used."""
        import starburst_config_loader as mod
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no_prod.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(tmp_path / "no_local.yaml"))
        monkeypatch.setenv("STARBURST_USER", "env_user")
        monkeypatch.setenv("STARBURST_PASSWORD", "env_pw")
        monkeypatch.setenv("STARBURST_ONCLOUD_URL", "trino://cloud:443/c/s")
        mod.reset_cache()
        out = mod.shared_creds_for("oncloud")
        assert out["user"] == "env_user"
        assert out["password"] == "env_pw"
        assert out["url"] == "trino://cloud:443/c/s"

    def test_endpoint_specific_env_var_wins_over_generic(self, monkeypatch, tmp_path):
        import starburst_config_loader as mod
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setenv("STARBURST_USER", "generic_user")
        monkeypatch.setenv("STARBURST_ONCLOUD_USER", "cloud_specific")
        mod.reset_cache()
        assert mod.shared_creds_for("oncloud")["user"] == "cloud_specific"
        assert mod.shared_creds_for("onprem")["user"] == "generic_user"

    def test_invalid_endpoint_raises(self):
        from starburst_config_loader import shared_creds_for
        with pytest.raises(ValueError, match="endpoint"):
            shared_creds_for("nowhere")


# ─── 2. Oracle non-Spark flow (light_starburst_base) ────────────────────


class TestOracleNonSparkFallback:
    """light_starburst_base._load_and_validate_config merges the shared
    YAML into the per-job JSON when keys are missing.  Locks the fix."""

    def test_yaml_credentials_win_url_does_not(self, tmp_path, monkeypatch):
        """2026-06-22 -- scope narrowed.  YAML wins over per-job JSON
        ONLY for credentials (user / password).  URL stays per-job
        because every job targets a different host/catalog/schema and
        the polling query is what delivers per-job context.

        Per-user: "only starburst related credentials will come from
        starburst_config.yaml" + "fact_query.json per job is diff ...
        comes via polling query in case of oracle standalone"
        """
        from steps.oracle.light_starburst_to_oracle_oncloud import (
            LightStarburstToOracle_OnCloud,
        )
        import starburst_config_loader as mod

        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "trino_user": "job_user",
            "trino_password": "job_pw",
            "trino_oncloud_url": "trino://job:443/c/s",
            "query_on_cloud": "SELECT 1",
            "oracle_url": "jdbc:oracle:thin:@h:1521/s",
            "oracle_user": "ora",
            "oracle_password": "ora_pw",
        }))
        # YAML provides real creds + a different URL.
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: shared_user\n  password: shared_pw\n"
            "  oncloud:\n    url: trino://shared:443/c/s\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        step = LightStarburstToOracle_OnCloud(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        # CREDENTIALS: YAML wins.
        assert out["trino_user"] == "shared_user", \
            "YAML must win over per-job JSON for trino_user"
        assert out["trino_password"] == "shared_pw", \
            "YAML must win over per-job JSON for trino_password"
        # URL: per-job JSON wins (yaml's url field is IGNORED).
        assert out["trino_oncloud_url"] == "trino://job:443/c/s", \
            "URL must stay per-job; yaml URL must NOT override it"

    def test_yaml_creds_fill_when_per_job_blank(self, tmp_path, monkeypatch):
        """Per-job JSON omits trino_user/password -> YAML fills them.
        URL still comes from per-job JSON (would fail if not set)."""
        from steps.oracle.light_starburst_to_oracle_oncloud import (
            LightStarburstToOracle_OnCloud,
        )
        import starburst_config_loader as mod

        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "trino_oncloud_url": "trino://job:443/c/s",
            "query_on_cloud": "SELECT 1",
            "oracle_url": "jdbc:oracle:thin:@h:1521/s",
            "oracle_user": "ora",
            "oracle_password": "ora_pw",
        }))
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: yaml_user\n  password: yaml_pw\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        step = LightStarburstToOracle_OnCloud(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        assert out["trino_user"] == "yaml_user"
        assert out["trino_password"] == "yaml_pw"
        assert out["trino_oncloud_url"] == "trino://job:443/c/s"

    def test_shared_fills_missing_creds(self, tmp_path, monkeypatch):
        """Per-job JSON omits trino_user/password -> shared YAML fills
        them.  URL must still be in per-job JSON (yaml no longer
        supplies URLs -- they're per-job and arrive via polling)."""
        from steps.oracle.light_starburst_to_oracle_oncloud import (
            LightStarburstToOracle_OnCloud,
        )
        import starburst_config_loader as mod

        # Per-job JSON has the URL (per-job context) but no creds.
        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "query_on_cloud": "SELECT 1",
            "trino_oncloud_url": "trino://job-host:443/c/s",
            "oracle_url": "jdbc:oracle:thin:@h:1521/s",
            "oracle_user": "ora",
            "oracle_password": "ora_pw",
        }))
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: shared_user\n  password: shared_pw\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        step = LightStarburstToOracle_OnCloud(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        # YAML supplied the creds.
        assert out["trino_user"] == "shared_user"
        assert out["trino_password"] == "shared_pw"
        # URL stays per-job JSON value.
        assert out["trino_oncloud_url"] == "trino://job-host:443/c/s"

    def test_onprem_picks_onprem_creds(self, tmp_path, monkeypatch):
        """The onprem light step must pull the ONPREM-section creds
        (not the cloud ones) -- locks the per-endpoint mapping.  URLs
        are per-job, so the test supplies them in the per-job JSON."""
        from steps.oracle.light_starburst_to_oracle_onprem import (
            LightStarburstToOracle_OnPrem,
        )
        import starburst_config_loader as mod

        # Per-job JSON has the URL (per-job context).
        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "query_on_prem": "SELECT 1",
            "trino_onprem_url": "trino://onprem-host:443/c/s",
            "oracle_url": "jdbc:oracle:thin:@h:1521/s",
            "oracle_user": "ora", "oracle_password": "ora_pw",
        }))
        # YAML has different creds per endpoint.
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: root_u\n  password: root_p\n"
            "  oncloud:\n    user: cloud_u\n    password: cloud_p\n"
            "  onprem:\n    user: onprem_u\n    password: onprem_p\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        step = LightStarburstToOracle_OnPrem(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        # The onprem step picked the onprem-section creds.
        assert out["trino_user"] == "onprem_u"
        assert out["trino_password"] == "onprem_p"
        # URL stays per-job.
        assert out["trino_onprem_url"] == "trino://onprem-host:443/c/s"


# ─── 3. File flow (4 subclasses) ───────────────────────────────────────


class TestFileFlowFallback:
    """All 4 file-workflow subclasses consult the shared YAML when
    both the INI and per-job JSON come up empty."""

    @pytest.fixture(autouse=True)
    def _reset_cache(self):
        from starburst_config_loader import reset_cache
        reset_cache()
        yield
        reset_cache()

    def test_helper_present_on_both_bases(self):
        """Both StarburstFileBase and StarburstFileSparkBase carry
        _shared_starburst_fallback so all 4 subclasses inherit it."""
        from steps.file.starburst_file_base import StarburstFileBase
        from steps.file.starburst_file_spark_base import StarburstFileSparkBase
        assert hasattr(StarburstFileBase, "_shared_starburst_fallback")
        assert hasattr(StarburstFileSparkBase, "_shared_starburst_fallback")

    def test_all_four_subclasses_call_helper(self):
        """The 4 file step files must all invoke _shared_starburst_fallback.
        Lock the wiring against a future refactor silently dropping it."""
        for rel in (
            "steps/file/starburst_to_file_oncloud.py",
            "steps/file/starburst_to_file_onprem.py",
            "steps/file/starburst_to_file_oncloud_spark.py",
            "steps/file/starburst_to_file_onprem_spark.py",
        ):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            assert "_shared_starburst_fallback" in src, (
                f"{rel}: missing shared-config fallback call"
            )

    def test_file_flow_yaml_creds_host_from_db(self, monkeypatch, tmp_path):
        """2026-06-22 -- file workflow contract:
          * YAML supplies CREDS (user / password / optional catalog,schema)
          * host + port come from per-job JSON (DB metadata via GenerateSQL)
          * No validation on host/port/catalog/schema at yaml level --
            those travel via per-job context, not the shared yaml.
        """
        from steps.file.starburst_to_file_oncloud_spark import (
            StarburstToFile_OnCloud_Spark,
        )
        import starburst_config_loader as mod

        # Realistic yaml: creds only.  Catalog/schema also yaml-supplied
        # (operator preference -- mirrors prod yaml shape).
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: yaml_user\n  password: yaml_pw\n"
            "  oncloud:\n    catalog: yaml_cat\n    schema: yaml_sch\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        # job_config supplies host/port (the per-job source of truth).
        job_config = {
            "server_name": "real.starburst.host",
            "port": 8443,
            "report_id": 99,
            "fetchsize": 50000,
        }
        step = StarburstToFile_OnCloud_Spark.__new__(StarburstToFile_OnCloud_Spark)
        step.ini_config = None
        step.logger = MagicMock()
        conn = step._build_connection_config(job_config)
        # Host + port from per-job JSON.
        assert "real.starburst.host:8443" in conn["jdbc_url"]
        # Creds from YAML.
        assert conn["user"] == "yaml_user"
        assert conn["password"] == "yaml_pw"
        # Catalog/schema YAML-supplied (yaml > job_config).
        assert "yaml_cat" in conn["jdbc_url"]
        assert "yaml_sch" in conn["jdbc_url"]

    def test_file_flow_missing_creds_raises_with_checklist(self, monkeypatch, tmp_path):
        """Empty user/password from EVERY source -> ValueError that
        names ALL consulted sources so the operator knows where to fill."""
        from steps.file.starburst_to_file_oncloud_spark import (
            StarburstToFile_OnCloud_Spark,
        )
        import starburst_config_loader as mod

        # Yaml has password but no user.  No INI.  Per-job JSON also blank.
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: ''\n  password: yaml_pw\n"
            "  oncloud:\n    catalog: c\n    schema: s\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        job_config = {"server_name": "h", "port": 8080, "report_id": 99}
        step = StarburstToFile_OnCloud_Spark.__new__(StarburstToFile_OnCloud_Spark)
        step.ini_config = None
        step.logger = MagicMock()
        with pytest.raises(ValueError) as exc_info:
            step._build_connection_config(job_config)
        msg = str(exc_info.value)
        # Specific missing field named.
        assert "user" in msg
        # All sources enumerated.
        assert "starburst_config.yaml" in msg
        assert "$EXPORT_TOOL_CONFIG_PATH" in msg
        assert "per-job JSON" in msg
        assert "env STARBURST_ONCLOUD" in msg


# ─── 4. Dispatcher path (Spark oracle flow / starburst_clients) ────────


class TestDispatcherFallback:
    """dispatcher._build_starburst_clients uses the shared YAML when
    polling-row C_*/P_* columns are empty.  Locks the Spark-oracle
    flow alignment with the rest of the design."""

    @pytest.fixture(autouse=True)
    def _reset_cache(self):
        from starburst_config_loader import reset_cache
        reset_cache()
        yield
        reset_cache()

    def test_shared_fills_empty_polling_row(self, monkeypatch, tmp_path):
        from polling_service import dispatcher as disp
        import starburst_config_loader as mod

        # Mock StarburstDataSource so we can inspect its received config.
        captured = {}
        def _ds(cfg):
            captured.setdefault("instances", []).append(cfg)
            return MagicMock()
        monkeypatch.setattr(disp, "StarburstDataSource", _ds)

        # Shared YAML with creds.
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: shared_u\n  password: shared_pw\n"
            "  oncloud:\n    host: cloud.host\n    port: 443\n"
            "    catalog: cat\n    schema: sch\n"
            "  onprem:\n    host: prem.host\n    port: 443\n"
            "    catalog: cat\n    schema: sch\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        # Polling row with EMPTY credentials.
        first_task = {
            "c_hostname": "", "c_port": None, "c_username": "",
            "c_pwd": "", "c_catalog": "", "c_schemainfo": "",
            "p_hostname": "", "p_port": None, "p_username": "",
            "p_pwd": "", "p_catalog": "", "p_schemainfo": "",
        }
        result = disp._build_starburst_clients(first_task, MagicMock())
        assert "cloud" in result and "pres" in result
        # 2 StarburstDataSource calls — cloud + pres.
        cloud_cfg, pres_cfg = captured["instances"]
        assert cloud_cfg["user"] == "shared_u"
        assert cloud_cfg["password"] == "shared_pw"
        assert cloud_cfg["host"] == "cloud.host"
        assert pres_cfg["user"] == "shared_u"
        assert pres_cfg["host"] == "prem.host"

    def test_polling_row_wins_over_shared(self, monkeypatch, tmp_path):
        """Backward-compat — polling row populated => those values win."""
        from polling_service import dispatcher as disp
        import starburst_config_loader as mod

        captured = {}
        def _ds(cfg):
            captured.setdefault("instances", []).append(cfg)
            return MagicMock()
        monkeypatch.setattr(disp, "StarburstDataSource", _ds)

        # YAML has full onprem config (so onprem isn't partial after merge).
        # CLOUD is intentionally NOT in yaml -- polling row must supply.
        shared_yaml = tmp_path / "starburst_config.yaml"
        shared_yaml.write_text(
            "starburst:\n  user: shared_u\n  password: shared_pw\n"
            "  onprem:\n    host: prem.host\n    port: 443\n"
            "    catalog: cat\n    schema: sch\n"
        )
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(shared_yaml))
        mod.reset_cache()

        first_task = {
            "c_hostname": "row.host", "c_port": 8443,
            "c_username": "row_u", "c_pwd": "row_pw",
            "c_catalog": "row_cat", "c_schemainfo": "row_sch",
            # ONPREM polling-row columns intentionally blank -- yaml fills.
            "p_hostname": "", "p_port": None,
            "p_username": "", "p_pwd": "",
            "p_catalog": "", "p_schemainfo": "",
        }
        disp._build_starburst_clients(first_task, MagicMock())
        cloud_cfg, _ = captured["instances"]
        assert cloud_cfg["user"] == "row_u"        # row wins
        assert cloud_cfg["host"] == "row.host"


# ─── 5. Audit fixes — Spark Oracle base + oracle_standalone share helper ─


class TestAuditCoverage:
    """Locks the audit fixes that close the 'duplicate dispatcher /
    standalone client builder' gap and the 'Spark Oracle base doesn't
    consult shared YAML' gap."""

    @pytest.fixture(autouse=True)
    def _reset_cache(self):
        from starburst_config_loader import reset_cache
        reset_cache()
        yield
        reset_cache()

    def test_spark_oracle_base_calls_shared_merger(self):
        """``starburst_base`` (Spark Oracle base) must call the same
        shared merger as the non-Spark light variant.  Source-level
        check because pyspark.sql.DataFrame isn't in the test stubs."""
        src = (Path(ETL_ROOT) / "steps" / "oracle" / "starburst_base.py").read_text(encoding="utf-8")
        assert "from starburst_config_loader import merge_shared_into_job_config" in src, (
            "starburst_base must import the shared Starburst merger — Spark "
            "Oracle path was missing the shared-YAML fallback (audit gap #1)"
        )
        assert "from oracle_config_loader import merge_shared_into_job_config" in src, (
            "starburst_base must import the shared Oracle merger so the Spark "
            "path picks up the destination Oracle creds from oracle_config.yaml"
        )
        # And these calls must precede the missing-field check — the
        # whole point of the merge is to FILL missing fields.
        sb_idx = src.find("from starburst_config_loader import merge_shared_into_job_config")
        missing_idx = src.find("missing = [f for f in required")
        assert 0 < sb_idx < missing_idx, (
            "merge_shared_into_job_config must be called BEFORE the "
            "missing-field validation, otherwise the merge has no effect"
        )

    def test_oracle_standalone_uses_shared_helper(self):
        """``oracle_standalone.execute_tasks`` MUST route through
        ``build_starburst_clients_from_row`` so the standalone and the
        polling-service dispatcher cannot diverge on credential
        resolution."""
        src = (Path(ETL_ROOT) / "oracle_standalone.py").read_text(encoding="utf-8")
        assert "build_starburst_clients_from_row" in src, (
            "oracle_standalone.py must call build_starburst_clients_from_row "
            "(shared helper) — direct dict access to c_username/c_pwd is the "
            "pre-audit anti-pattern"
        )
        # And the direct KeyError-prone access has been removed.
        assert 'first_task["c_username"]' not in src
        assert 'first_task["c_pwd"]' not in src

    def test_dispatcher_uses_shared_helper(self):
        """``polling_service.dispatcher._build_starburst_clients`` must
        delegate to the shared helper so the standalone + dispatcher
        share ONE merge implementation."""
        src = (Path(ETL_ROOT) / "polling_service" / "dispatcher.py").read_text(encoding="utf-8")
        assert "build_starburst_clients_from_row" in src

    def test_yaml_parse_error_logged_not_silent(self, tmp_path, monkeypatch, caplog):
        """Malformed starburst_config.yaml must log WARNING so operator
        sees a clear signal instead of confusing 'missing credentials'."""
        import starburst_config_loader as mod
        bad_yaml = tmp_path / "starburst_config.yaml"
        bad_yaml.write_text("starburst:\n  user: [unclosed list\n")
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(bad_yaml))
        mod.reset_cache()

        import logging
        caplog.set_level(logging.WARNING, logger="starburst_config_loader")
        out = mod.shared_creds_for("oncloud")
        # Falls back to empty defaults (no env var set).
        assert out["user"] == ""
        # WARN was emitted.
        assert any("malformed" in r.message.lower() for r in caplog.records), (
            "malformed YAML must log a WARNING — silent swallow was the bug"
        )


# ─── 6. Shared Oracle credentials (the new 'oracle one config' ask) ────


class TestSharedOracleCreds:
    """Locks the oracle_config_loader behaviour — same pattern as the
    Starburst loader.  Per-job JSON wins; shared dest_connection_string
    fills missing fields; broken connection string logs WARN and falls
    through to empty."""

    @pytest.fixture(autouse=True)
    def _reset_cache(self):
        from oracle_config_loader import reset_cache
        reset_cache()
        yield
        reset_cache()

    def test_parse_dest_dsn_canonical(self):
        from oracle_config_loader import parse_dest_dsn
        out = parse_dest_dsn("user1/pw1@h.local:1521/SERVICE")
        assert out == {
            "oracle_user": "user1",
            "oracle_password": "pw1",
            "oracle_url": "jdbc:oracle:thin:@h.local:1521/SERVICE",
        }

    def test_parse_dest_dsn_malformed_returns_empty(self, caplog):
        from oracle_config_loader import parse_dest_dsn
        import logging
        caplog.set_level(logging.WARNING, logger="oracle_config_loader")
        out = parse_dest_dsn("garbage_no_separator")
        assert out == {"oracle_user": "", "oracle_password": "", "oracle_url": ""}
        assert any("not in the expected" in r.message for r in caplog.records)

    def test_shared_dest_used_when_job_json_omits(self, tmp_path, monkeypatch):
        """Per-job JSON missing oracle_user/password/url => shared
        dest_connection_string fills them in."""
        from steps.oracle.light_starburst_to_oracle_oncloud import (
            LightStarburstToOracle_OnCloud,
        )
        import starburst_config_loader as sb_mod
        import oracle_config_loader as ora_mod

        # Per-job JSON with only Starburst fields (NO oracle_* keys).
        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "query_on_cloud": "SELECT 1",
            "trino_user": "u", "trino_password": "p",
            "trino_oncloud_url": "trino://h:443/c/s",
        }))
        # Shared oracle_config.yaml carries the destination DSN.
        ora_yaml = tmp_path / "oracle_config.yaml"
        ora_yaml.write_text(
            "oracle:\n"
            "  dest_connection_string: dora/dora_pw@dest.host:1521/DESTSVC\n"
        )
        monkeypatch.setattr(ora_mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(ora_mod, "_LOCAL_PATH", str(ora_yaml))
        # Starburst loader needs a benign no-op so the test doesn't
        # accidentally pull from a real file.
        monkeypatch.setattr(sb_mod, "_PROD_PATH", str(tmp_path / "no_sb.yaml"))
        monkeypatch.setattr(sb_mod, "_LOCAL_PATH", str(tmp_path / "no_sb.yaml"))
        ora_mod.reset_cache()
        sb_mod.reset_cache()

        step = LightStarburstToOracle_OnCloud(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        assert out["oracle_user"] == "dora"
        assert out["oracle_password"] == "dora_pw"
        assert out["oracle_url"] == "jdbc:oracle:thin:@dest.host:1521/DESTSVC"

    def test_per_job_oracle_creds_win_over_shared(self, tmp_path, monkeypatch):
        from steps.oracle.light_starburst_to_oracle_oncloud import (
            LightStarburstToOracle_OnCloud,
        )
        import starburst_config_loader as sb_mod
        import oracle_config_loader as ora_mod

        job_json = tmp_path / "job.json"
        job_json.write_text(json.dumps({
            "query_on_cloud": "SELECT 1",
            "trino_user": "u", "trino_password": "p",
            "trino_oncloud_url": "trino://h:443/c/s",
            # Per-job JSON HAS the oracle fields — shared must NOT win.
            "oracle_url": "jdbc:oracle:thin:@job:1521/JOBSVC",
            "oracle_user": "job_user",
            "oracle_password": "job_pw",
        }))
        ora_yaml = tmp_path / "oracle_config.yaml"
        ora_yaml.write_text(
            "oracle:\n"
            "  dest_connection_string: shared_u/shared_pw@shared:1521/SHRD\n"
        )
        monkeypatch.setattr(ora_mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(ora_mod, "_LOCAL_PATH", str(ora_yaml))
        monkeypatch.setattr(sb_mod, "_PROD_PATH", str(tmp_path / "no_sb.yaml"))
        monkeypatch.setattr(sb_mod, "_LOCAL_PATH", str(tmp_path / "no_sb.yaml"))
        ora_mod.reset_cache()
        sb_mod.reset_cache()

        step = LightStarburstToOracle_OnCloud(
            starburst_clients={}, oracle_data_manager=MagicMock(),
            logger=MagicMock(),
        )
        out = step._load_and_validate_config({"sql_query_path": str(job_json)})
        assert out["oracle_user"] == "job_user"
        assert out["oracle_password"] == "job_pw"
        assert out["oracle_url"] == "jdbc:oracle:thin:@job:1521/JOBSVC"

    def test_env_var_fallback(self, tmp_path, monkeypatch):
        from oracle_config_loader import shared_dest_oracle_creds, reset_cache
        import oracle_config_loader as mod
        monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setattr(mod, "_LOCAL_PATH", str(tmp_path / "no.yaml"))
        monkeypatch.setenv("DEST_ORACLE_CONN", "envu/envp@envhost:1521/ENVSVC")
        reset_cache()
        out = shared_dest_oracle_creds()
        assert out["oracle_user"] == "envu"
        assert out["oracle_url"] == "jdbc:oracle:thin:@envhost:1521/ENVSVC"


# ─── 7. Trino JDBC TCP preflight (2026-06-22 -- fail-in-5s diagnostic) ──


class TestTrinoJdbcPreflight:
    """Locks the TCP probe + proxy enrichment helpers that close the
    'silent 2-min connect timeout' bug class observed on OpenShift.
    """

    def test_tcp_preflight_succeeds_on_open_port(self, monkeypatch):
        """Listening loopback socket -> preflight passes silently."""
        import socket as _socket
        from managers.trino_jdbc_preflight import tcp_preflight

        srv = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        try:
            # Should NOT raise.
            tcp_preflight(f"jdbc:trino://127.0.0.1:{port}/cat/sch", timeout=2.0)
        finally:
            srv.close()

    def test_tcp_preflight_warns_on_dead_host_default_fail_open(self, caplog):
        """2026-06-22 -- DEFAULT IS FAIL-OPEN.  Operator hit production
        outage when preflight blocked otherwise-working HTTPS connects
        (firewall dropped raw TCP probes).  Default now: WARN and
        continue (let JDBC driver attempt its own connect)."""
        import logging
        from managers.trino_jdbc_preflight import tcp_preflight
        caplog.set_level(logging.WARNING)
        # 192.0.2.x is RFC 5737 TEST-NET-1, guaranteed unreachable.
        # Should NOT raise -- just warn.
        tcp_preflight(
            "jdbc:trino://192.0.2.1:443/cat/sch?SSL=true",
            timeout=1.0,
        )
        msg = " ".join(r.message for r in caplog.records)
        assert "192.0.2.1" in msg
        assert "FAIL-OPEN" in msg or "Continuing anyway" in msg

    def test_tcp_preflight_strict_raises(self, monkeypatch):
        """Opt-in strict mode via TRINO_JDBC_STRICT_PREFLIGHT=1 -> raise."""
        from managers.trino_jdbc_preflight import tcp_preflight
        monkeypatch.setenv("TRINO_JDBC_STRICT_PREFLIGHT", "1")
        with pytest.raises(RuntimeError) as exc_info:
            tcp_preflight(
                "jdbc:trino://192.0.2.1:443/cat/sch?SSL=true",
                timeout=1.0,
            )
        assert "192.0.2.1" in str(exc_info.value)

    def test_tcp_preflight_warns_on_dns_failure(self, caplog):
        """Default fail-open: DNS failure warns + continues."""
        import logging
        from managers.trino_jdbc_preflight import tcp_preflight
        caplog.set_level(logging.WARNING)
        tcp_preflight(
            "jdbc:trino://this-host-does-not-exist-xyz123.invalid:443/c/s",
            timeout=1.0,
        )
        assert "DNS" in " ".join(r.message for r in caplog.records)

    def test_tcp_preflight_warns_on_empty_host_default(self, caplog):
        """URL with no host component -> warn, don't raise (default)."""
        import logging
        from managers.trino_jdbc_preflight import tcp_preflight
        caplog.set_level(logging.WARNING)
        tcp_preflight("jdbc:trino:///cat/sch", timeout=1.0)
        assert "no host" in " ".join(r.message for r in caplog.records).lower()

    def test_enrich_url_injects_proxy_from_env(self, monkeypatch):
        """HTTPS_PROXY env var -> httpProxy query param baked into URL."""
        from managers.trino_jdbc_preflight import enrich_trino_jdbc_url
        monkeypatch.setenv("HTTPS_PROXY", "http://corp.proxy:3128")
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        out = enrich_trino_jdbc_url(
            "jdbc:trino://host.starburst.io:443/cat/sch?SSL=true",
        )
        assert "httpProxy=corp.proxy%3A3128" in out or \
               "httpProxy=corp.proxy:3128" in out, f"got {out!r}"

    def test_enrich_url_unchanged_when_no_proxy_env(self, monkeypatch):
        """No HTTP(S)_PROXY env -> URL unchanged."""
        from managers.trino_jdbc_preflight import enrich_trino_jdbc_url
        monkeypatch.delenv("HTTP_PROXY", raising=False)
        monkeypatch.delenv("HTTPS_PROXY", raising=False)
        monkeypatch.delenv("http_proxy", raising=False)
        monkeypatch.delenv("https_proxy", raising=False)
        url = "jdbc:trino://h:443/c/s?SSL=true"
        assert enrich_trino_jdbc_url(url) == url

    def test_enrich_url_respects_existing_httpProxy(self, monkeypatch):
        """Existing httpProxy in URL -> NOT overwritten by env var."""
        from managers.trino_jdbc_preflight import enrich_trino_jdbc_url
        monkeypatch.setenv("HTTPS_PROXY", "http://corp.proxy:3128")
        original = "jdbc:trino://h:443/c/s?SSL=true&httpProxy=explicit:8080"
        assert "explicit:8080" in enrich_trino_jdbc_url(original)
        assert "corp.proxy" not in enrich_trino_jdbc_url(original)

    def test_enrich_url_disabled_by_env_var(self, monkeypatch):
        """TRINO_JDBC_NO_PROXY_ENRICH=1 -> bypass entirely."""
        from managers.trino_jdbc_preflight import enrich_trino_jdbc_url
        monkeypatch.setenv("HTTPS_PROXY", "http://corp.proxy:3128")
        monkeypatch.setenv("TRINO_JDBC_NO_PROXY_ENRICH", "1")
        url = "jdbc:trino://h:443/c/s?SSL=true"
        assert enrich_trino_jdbc_url(url) == url
