"""Phase G (2026-06-08) — byte-level iceberg bound decoder tests.

Locks down the correctness fix for the pyiceberg raw-bytes -> string
conversion.  Pre-Phase-G the ETL pruner called b.decode('utf-8') on
ALL bound bytes, which silently corrupted every non-string column's
bounds (int32 day counts came out as garbage hex, pruner kept every
file regardless of date filter).
"""
from __future__ import annotations

import os
import struct
import sys
import unittest
from datetime import date, datetime
from decimal import Decimal

_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from managers.iceberg_value_coercion import decode_iceberg_bound


class TestDateDecoder(unittest.TestCase):
    """Iceberg DATE columns are int32 days since 1970-01-01.
    pyiceberg returns raw little-endian bytes."""

    def test_2025_09_30_decoded(self):
        # 2025-09-30 - 1970-01-01 = 20361 days
        days = (date(2025, 9, 30) - date(1970, 1, 1)).days
        raw = struct.pack("<i", days)
        self.assertEqual(
            decode_iceberg_bound(raw, "date"),
            "2025-09-30",
        )

    def test_epoch_decoded(self):
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<i", 0), "date"),
            "1970-01-01",
        )

    def test_old_date_decoded(self):
        days = (date(2000, 1, 1) - date(1970, 1, 1)).days
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<i", days), "date"),
            "2000-01-01",
        )


class TestIntDecoder(unittest.TestCase):
    def test_int32_positive(self):
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<i", 12345), "int"),
            "12345",
        )

    def test_int32_negative(self):
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<i", -42), "int"),
            "-42",
        )

    def test_int64(self):
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<q", 12345678901234), "long"),
            "12345678901234",
        )


class TestTimestampDecoder(unittest.TestCase):
    """TIMESTAMP columns are int64 microseconds since epoch."""

    def test_2025_09_30_decoded(self):
        # 2025-09-30 00:00:00 UTC = (date - 1970-01-01) * 86400_000_000 us
        epoch = datetime(1970, 1, 1)
        target = datetime(2025, 9, 30, 0, 0, 0)
        micros = int((target - epoch).total_seconds() * 1_000_000)
        raw = struct.pack("<q", micros)
        out = decode_iceberg_bound(raw, "timestamp")
        self.assertEqual(out, "2025-09-30 00:00:00")

    def test_with_time_component(self):
        epoch = datetime(1970, 1, 1)
        target = datetime(2025, 9, 30, 13, 45, 7)
        micros = int((target - epoch).total_seconds() * 1_000_000)
        out = decode_iceberg_bound(struct.pack("<q", micros), "timestamp")
        self.assertEqual(out, "2025-09-30 13:45:07")


class TestDecimalDecoder(unittest.TestCase):
    """DECIMAL bounds are big-endian two's-complement unscaled int."""

    def test_decimal_10_4(self):
        # 123.4500 stored as unscaled 1234500 (scale 4)
        raw = (1234500).to_bytes(8, byteorder="big", signed=True)
        out = decode_iceberg_bound(raw, "decimal(10,4)")
        self.assertEqual(out, "123.4500")

    def test_decimal_scale_zero(self):
        raw = (42).to_bytes(4, byteorder="big", signed=True)
        out = decode_iceberg_bound(raw, "decimal(10,0)")
        self.assertEqual(out, "42")

    def test_decimal_no_scale_in_type_returns_none(self):
        # Bare "decimal" is unsafe -- caller can't apply scale.
        raw = (100).to_bytes(4, byteorder="big", signed=True)
        self.assertIsNone(decode_iceberg_bound(raw, "decimal"))


class TestStringDecoder(unittest.TestCase):
    def test_utf8_string(self):
        self.assertEqual(
            decode_iceberg_bound(b"AAPL", "string"),
            "AAPL",
        )

    def test_non_utf8_falls_to_hex(self):
        # binary garbage that's not valid utf-8
        raw = b"\x99\x4f\x00\x00"
        self.assertEqual(
            decode_iceberg_bound(raw, "string"),
            raw.hex(),
        )


class TestBooleanDecoder(unittest.TestCase):
    def test_true(self):
        self.assertEqual(decode_iceberg_bound(b"\x01", "boolean"), "True")

    def test_false(self):
        self.assertEqual(decode_iceberg_bound(b"\x00", "boolean"), "False")


class TestFloatDecoder(unittest.TestCase):
    def test_double(self):
        raw = struct.pack("<d", 3.14159)
        out = decode_iceberg_bound(raw, "double")
        self.assertIsNotNone(out)
        self.assertAlmostEqual(float(out), 3.14159, places=4)

    def test_float(self):
        raw = struct.pack("<f", 1.5)
        out = decode_iceberg_bound(raw, "float")
        self.assertIsNotNone(out)
        self.assertAlmostEqual(float(out), 1.5, places=3)

    def test_nan_returns_none(self):
        import math
        raw = struct.pack("<d", float("nan"))
        self.assertIsNone(decode_iceberg_bound(raw, "double"))

    def test_inf_returns_none(self):
        raw = struct.pack("<d", float("inf"))
        self.assertIsNone(decode_iceberg_bound(raw, "double"))


class TestAlreadyDecodedPassthrough(unittest.TestCase):
    """pyiceberg sometimes pre-decodes bounds to Python types."""

    def test_datetime_input(self):
        self.assertEqual(
            decode_iceberg_bound(datetime(2025, 9, 30, 13, 45), "timestamp"),
            "2025-09-30 13:45:00",
        )

    def test_date_input(self):
        self.assertEqual(
            decode_iceberg_bound(date(2025, 9, 30), "date"),
            "2025-09-30",
        )

    def test_int_input(self):
        self.assertEqual(
            decode_iceberg_bound(42, "int"),
            "42",
        )

    def test_none_input(self):
        self.assertIsNone(decode_iceberg_bound(None, "date"))


class TestTransformTypes(unittest.TestCase):
    """Iceberg transform-result types use specific physical encodings."""

    def test_transform_day(self):
        # _transform_day normalises to "date" internally
        days = (date(2025, 9, 30) - date(1970, 1, 1)).days
        self.assertEqual(
            decode_iceberg_bound(struct.pack("<i", days), "_transform_day"),
            "2025-09-30",
        )


if __name__ == "__main__":
    unittest.main()
