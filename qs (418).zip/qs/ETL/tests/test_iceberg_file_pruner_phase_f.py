"""Phase F (2026-06-08) — ETL iceberg file pruner type-aware tests.

Locks down the partition-aware + type-aware prune semantics added in
Phase F.  Verifies the same scenarios the backend brain handles also
work in the ETL Spark path: date predicates prune correctly, stats
columns use range overlap, partition columns enjoy the same prune
result, cascade telemetry is emitted.
"""
from __future__ import annotations

import logging
import os
import sys
import unittest

_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from managers.iceberg_file_pruner import prune_files


# Bound tuple shape: (lower, upper, null_count, row_count)
def _b(low, high, nulls=0, rows=0):
    return (low, high, nulls, rows)


class TestPhaseFTypedDatePruning(unittest.TestCase):
    """The deep-dive bug class: date predicates were silently keeping
    every file because the original ``_coerce_bounds`` didn't know what
    a date was — so 'YYYY-MM-DD' compared lexicographically vs
    'YYYY-MM-DD' which actually works by coincidence... but only when
    the supplement stored exact equal strings.  Verify the post-Phase-F
    pruner handles the date case correctly."""

    def test_partition_eq_prunes_non_matching_dates(self):
        files = ["f1", "f2", "f3"]
        # Each file is a single partition value (partition col semantic
        # lower==upper==date)
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-09-30", "2025-09-30"),
                "f2": _b("2025-10-01", "2025-10-01"),
                "f3": _b("2025-09-30", "2025-09-30"),
            },
        }
        predicates = {
            "business_close_date": [("=", "2025-09-30")],
        }
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={"business_close_date": "date"},
            partition_columns=["business_close_date"],
        )
        self.assertEqual(result, ["f1", "f3"])

    def test_stats_col_range_overlap_keeps_correctly(self):
        # Non-partition string column with [MIN, MAX] bounds per file
        files = ["f1", "f2", "f3"]
        manifest_bounds = {
            "code": {
                "f1": _b("A", "C"),    # could contain 'A'
                "f2": _b("D", "F"),    # cannot contain 'A'
                "f3": _b("A", "Z"),    # could contain 'A'
            },
        }
        predicates = {"code": [("=", "A")]}
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={"code": "string"},
            partition_columns=[],
        )
        self.assertEqual(result, ["f1", "f3"])

    def test_mixed_partition_plus_stats(self):
        # business_close_date (partition) + code (stats)
        files = ["f1", "f2", "f3"]
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-09-30", "2025-09-30"),
                "f2": _b("2025-10-01", "2025-10-01"),
                "f3": _b("2025-09-30", "2025-09-30"),
            },
            "code": {
                "f1": _b("A", "C"),
                "f2": _b("A", "Z"),
                "f3": _b("D", "F"),     # no 'A' rows
            },
        }
        predicates = {
            "business_close_date": [("=", "2025-09-30")],
            "code":                 [("=", "A")],
        }
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={
                "business_close_date": "date",
                "code":                "string",
            },
            partition_columns=["business_close_date"],
        )
        # f1: date matches + code overlap   -> keep
        # f2: date doesn't match            -> drop
        # f3: date matches but code excludes-> drop
        self.assertEqual(result, ["f1"])

    def test_in_filter_partition_col(self):
        files = ["f1", "f2", "f3"]
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-09-30", "2025-09-30"),
                "f2": _b("2025-10-01", "2025-10-01"),
                "f3": _b("2025-11-01", "2025-11-01"),
            },
        }
        predicates = {
            "business_close_date": [
                ("in", ["2025-09-30", "2025-10-01"]),
            ],
        }
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={"business_close_date": "date"},
            partition_columns=["business_close_date"],
        )
        self.assertEqual(result, ["f1", "f2"])

    def test_between_filter(self):
        files = ["f1", "f2", "f3", "f4"]
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-08-30", "2025-08-30"),
                "f2": _b("2025-09-30", "2025-09-30"),
                "f3": _b("2025-10-15", "2025-10-15"),
                "f4": _b("2025-11-01", "2025-11-01"),
            },
        }
        # sql_filter_extractor decomposes BETWEEN to ['>=', '<='] tuples
        predicates = {
            "business_close_date": [
                (">=", "2025-09-01"),
                ("<=", "2025-10-31"),
            ],
        }
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={"business_close_date": "date"},
            partition_columns=["business_close_date"],
        )
        self.assertEqual(result, ["f2", "f3"])

    def test_no_predicates_returns_all(self):
        files = ["a", "b", "c"]
        result = prune_files(files, {}, {}, {})
        self.assertEqual(result, ["a", "b", "c"])

    def test_coerce_failure_keeps_file(self):
        # Filter value can't coerce to date -> predicate dropped ->
        # file kept (conservative, fail-OPEN).
        files = ["f1"]
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-09-30", "2025-09-30"),
            },
        }
        predicates = {"business_close_date": [("=", "totally invalid")]}
        result = prune_files(
            files, manifest_bounds, {}, predicates,
            iceberg_field_types={"business_close_date": "date"},
            partition_columns=["business_close_date"],
        )
        # Predicate was dropped by _coerce_predicates -> no exclusion ->
        # file survives.
        self.assertEqual(result, ["f1"])


class TestPhaseFSupplementOverridesManifestNulls(unittest.TestCase):
    """When manifest bounds are NULL (writer didn't track stats for
    this column), supplement bounds fill in.  Standard 134-P
    behaviour, but verify it still works post-Phase-F."""

    def test_supplement_used_when_manifest_null(self):
        files = ["f1", "f2"]
        manifest_bounds = {
            "code": {
                "f1": _b(None, None),
                "f2": _b(None, None),
            },
        }
        supplement_bounds = {
            "code": {
                "f1": _b("A", "C"),
                "f2": _b("D", "F"),
            },
        }
        predicates = {"code": [("=", "A")]}
        result = prune_files(
            files, manifest_bounds, supplement_bounds, predicates,
            iceberg_field_types={"code": "string"},
        )
        self.assertEqual(result, ["f1"])


class TestPhaseFCascadeLogging(unittest.TestCase):
    """Confirm the cascade telemetry log is emitted at INFO level
    with both predicates referenced."""

    def test_cascade_logged_at_info(self):
        files = ["f1", "f2"]
        manifest_bounds = {
            "business_close_date": {
                "f1": _b("2025-09-30", "2025-09-30"),
                "f2": _b("2025-10-01", "2025-10-01"),
            },
            "code": {
                "f1": _b("A", "Z"),
                "f2": _b("D", "F"),
            },
        }
        predicates = {
            "business_close_date": [("=", "2025-09-30")],
            "code":                 [("=", "A")],
        }
        with self.assertLogs(
            "managers.iceberg_file_pruner", level=logging.INFO,
        ) as cap:
            prune_files(
                files, manifest_bounds, {}, predicates,
                iceberg_field_types={
                    "business_close_date": "date",
                    "code":                "string",
                },
                partition_columns=["business_close_date"],
            )
        log_text = "\n".join(cap.output)
        self.assertIn("iceberg_file_pruner", log_text)
        self.assertIn("cascade", log_text)
        # Phase H: cascade now records the FIRST predicate that excluded
        # each file (inline collection, no second O(N) pass).  The
        # partition filter is checked first and drops f2 before code
        # gets evaluated, so the cascade reflects partition_eq -- which
        # is more useful info than counting per-predicate drops.
        self.assertIn("business_close_date", log_text)
        self.assertIn("partition_eq", log_text)


if __name__ == "__main__":
    unittest.main()
