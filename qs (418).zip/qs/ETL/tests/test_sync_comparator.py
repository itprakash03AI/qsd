"""Comparator + diff logic — the load-bearing piece of the sync process."""
from datetime import date

import pytest

from ETL.sync.comparator import TableComparator
from ETL.sync.models import TableRef, TableTriple


class _FakeConn:
    def __init__(self, rows):
        self._rows = rows
        self.last_sql = None

    def query_rows(self, sql):
        self.last_sql = sql
        return self._rows


def _triple():
    return TableTriple(
        logical_name="fact_x",
        refs=[
            TableRef(env="sb_cloud", catalog="iceberg", schema="s", table="t"),
            TableRef(env="sb_onprem", catalog="hive", schema="s", table="t"),
            TableRef(env="oracle", catalog="", schema="QSPROD", table="T"),
        ],
    )


def test_no_discrepancies_returns_empty_list():
    rows = [
        {"code": "A", "close_date": "2026-01-01", "event": "OPEN", "cnt": 100},
        {"code": "B", "close_date": "2026-01-02", "event": "CLOSE", "cnt": 50},
    ]
    comp = TableComparator(connectors={
        "sb_cloud": _FakeConn(rows),
        "sb_onprem": _FakeConn(rows),
        "oracle": _FakeConn(rows),
    })
    result = comp.compare(_triple())
    assert result == []


def test_discrepancy_with_missing_env_shown_as_zero_count():
    rows_full = [{"code": "A", "close_date": "2026-01-01", "event": "OPEN", "cnt": 100}]
    rows_short = []   # oracle has no rows for any group
    comp = TableComparator(connectors={
        "sb_cloud": _FakeConn(rows_full),
        "sb_onprem": _FakeConn(rows_full),
        "oracle":   _FakeConn(rows_short),
    })
    result = comp.compare(_triple())
    assert len(result) == 1
    row = result[0]
    assert row.counts["sb_cloud"] == 100
    assert row.counts["sb_onprem"] == 100
    assert row.counts["oracle"] == 0
    assert row.in_sync is False
    assert row.affected_estimate == 100


def test_discrepancies_sorted_by_affected_estimate_desc():
    big   = [{"code": "BIG", "close_date": "2026-01-01", "event": "X", "cnt": 1_000_000}]
    small = [{"code": "SML", "close_date": "2026-01-01", "event": "X", "cnt": 5}]
    cloud = [
        {"code": "BIG", "close_date": "2026-01-01", "event": "X", "cnt": 1_000_000},
        {"code": "SML", "close_date": "2026-01-01", "event": "X", "cnt": 5},
    ]
    comp = TableComparator(connectors={
        "sb_cloud": _FakeConn(cloud),
        "sb_onprem": _FakeConn(big),     # missing SML group
        "oracle":   _FakeConn(small),    # missing BIG group
    })
    result = comp.compare(_triple())
    assert len(result) == 2
    assert result[0].affected_estimate == 1_000_000   # BIG comes first
    assert result[1].affected_estimate == 5


def test_unknown_env_raises_loud():
    comp = TableComparator(connectors={"sb_cloud": _FakeConn([])})   # missing others
    with pytest.raises(KeyError, match="No connector registered"):
        comp.compare(_triple())


def test_close_date_string_coerced_to_date():
    rows = [{"code": "A", "close_date": "2026-04-15", "event": "X", "cnt": 1}]
    comp = TableComparator(connectors={
        "sb_cloud": _FakeConn(rows),
        "sb_onprem": _FakeConn([]),
        "oracle":   _FakeConn([]),
    })
    [row] = comp.compare(_triple())
    assert row.key.business_close_date == date(2026, 4, 15)


def test_idempotency_key_stable_for_same_inputs():
    from ETL.sync.models import DiscrepancyKey
    k1 = DiscrepancyKey(code="A", business_close_date=date(2026, 1, 1), business_event="X")
    k2 = DiscrepancyKey(code="A", business_close_date=date(2026, 1, 1), business_event="X")
    assert k1.idempotency_key("fact_x") == k2.idempotency_key("fact_x")
    # Different table → different key
    assert k1.idempotency_key("fact_x") != k1.idempotency_key("fact_y")


def test_sql_uses_configured_column_names():
    triple = TableTriple(
        logical_name="t", refs=[TableRef("sb_cloud", "c", "s", "t")],
        code_column="MY_CODE",
        close_date_column="MY_DATE",
        event_column="MY_EVENT",
    )
    conn = _FakeConn([])
    comp = TableComparator(connectors={"sb_cloud": conn})
    comp.compare(triple)
    # New shape: unquoted (Oracle UPPER + Trino lower both work).
    assert "MY_CODE" in conn.last_sql
    assert "MY_DATE" in conn.last_sql
    assert "MY_EVENT" in conn.last_sql


def test_custom_query_overrides_built_sql():
    """When ref.query is set, comparator uses it VERBATIM — no template SQL."""
    custom = (
        "SELECT code, business_close_date AS close_date, "
        "business_event AS event, COUNT(*) AS cnt "
        "FROM my_special_view "
        "WHERE business_close_date >= CURRENT_DATE - INTERVAL '7' DAY "
        "GROUP BY 1,2,3"
    )
    triple = TableTriple(
        logical_name="t",
        refs=[TableRef(env="sb_cloud", query=custom)],
    )
    conn = _FakeConn([])
    comp = TableComparator(connectors={"sb_cloud": conn})
    comp.compare(triple)
    assert conn.last_sql == custom


def test_custom_query_per_env_can_differ():
    """Each ref carries its own query — Oracle gets uppercase, Trino lowercase."""
    triple = TableTriple(
        logical_name="t",
        refs=[
            TableRef(env="sb_cloud", query="SELECT code, close_date, event, cnt FROM trino_view"),
            TableRef(env="oracle",   query="SELECT CODE, CLOSE_DATE, EVENT, CNT FROM ORACLE_VIEW"),
        ],
    )
    c_sb = _FakeConn([])
    c_or = _FakeConn([])
    comp = TableComparator(connectors={"sb_cloud": c_sb, "oracle": c_or})
    comp.compare(triple)
    assert "trino_view" in c_sb.last_sql
    assert "ORACLE_VIEW" in c_or.last_sql
