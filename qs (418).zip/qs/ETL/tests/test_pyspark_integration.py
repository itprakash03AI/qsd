"""Real pyspark integration tests for the S3 completeness primitives.

SLOW: each test class spawns a local SparkSession (cold JVM ~5-10s
first time, then reused).  Run separately from the unit-test sweep:

    pytest ETL/tests/test_pyspark_integration.py -v

Tests the actual Spark behaviour, not stubbed:
  * _compute_source_anchors against a real DataFrame
  * _verify_output_completeness re-reading a real Spark-written file
  * _resolve_spark_session_from_df on real DataFrames

These close the last 5-10% confidence gap on the S3 path -- the
behaviour unit tests can't reproduce because they stub the Spark
API surface.
"""
from __future__ import annotations

import logging
import os
import shutil
import sys
import tempfile
from decimal import Decimal

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# Skip entire module if pyspark isn't importable.
pyspark = pytest.importorskip("pyspark")


@pytest.fixture(scope="module")
def spark():
    """Module-scoped SparkSession -- cold start ~5-10s, then reused.

    Skips with a clear reason when the local pyspark + JVM combination
    can't start (common in containerised dev envs / Windows with no
    Hadoop libs).  CI image MUST run these tests against a real Spark
    cluster -- they close the 5-10% confidence gap on the S3 path.
    """
    from pyspark.sql import SparkSession
    try:
        sess = (
            SparkSession.builder
            .appName("phase152-integration")
            .master("local[2]")
            .config("spark.sql.shuffle.partitions", "2")
            .config("spark.driver.extraJavaOptions", "-Dlog4j.logLevel=WARN")
            .getOrCreate()
        )
        # Touch the context to trigger JVM init -- raises here if
        # py4j / hadoop / JVM bindings are broken.
        _ = sess.sparkContext
        sess.sparkContext.setLogLevel("ERROR")
    except Exception as exc:
        pytest.skip(
            f"Local SparkSession startup failed (pyspark/JVM/Hadoop "
            f"compatibility issue): {type(exc).__name__}: {str(exc)[:200]}. "
            f"Integration tests must run against a real Spark image in CI."
        )
    yield sess
    try:
        sess.stop()
    except Exception:
        pass


def _bare_s3_base():
    from steps.s3.s3_query_base import S3QueryBase
    cls = type("_StubS3", (S3QueryBase,), {
        "_execute_step": lambda self, *a, **kw: None,
    })
    inst = cls.__new__(cls)
    inst.logger = logging.getLogger("integration-test-s3")
    return inst


# ──────────────────────────────────────────────────────────────────────
#  _compute_source_anchors -- REAL agg pass
# ──────────────────────────────────────────────────────────────────────


class TestComputeSourceAnchorsReal:
    """Real Spark df.agg(count + sums) -- proves the single-pass
    contract that AutoPlan + S3 path depend on."""

    def test_count_only_no_checksum_columns(self, spark):
        df = spark.createDataFrame(
            [(1, "a"), (2, "b"), (3, "c")], ["id", "label"],
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, [])
        assert rows == 3
        assert sums == {}

    def test_count_plus_single_sum(self, spark):
        df = spark.createDataFrame(
            [(1, Decimal("10.50")), (2, Decimal("20.00")), (3, Decimal("5.25"))],
            ["id", "amount"],
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount"])
        assert rows == 3
        assert sums["amount"] == Decimal("35.75")

    def test_count_plus_multiple_sums(self, spark):
        df = spark.createDataFrame(
            [
                (1, Decimal("10.00"), 100),
                (2, Decimal("20.00"), 200),
                (3, Decimal("30.00"), 300),
            ],
            ["id", "amount", "qty"],
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount", "qty"])
        assert rows == 3
        assert sums["amount"] == Decimal("60.00")
        assert sums["qty"] == Decimal("600")

    def test_null_sum_coerced_to_zero(self, spark):
        df = spark.createDataFrame(
            [(1, None), (2, None), (3, None)],
            ["id", "amount"],
        ).withColumn(
            "amount",
            __import__("pyspark.sql.functions", fromlist=["col"])
                .col("amount").cast("double"),
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount"])
        assert rows == 3
        assert sums["amount"] == Decimal(0)

    def test_decimal_precision_preserved(self, spark):
        """100k rows of $0.01 -> $1000.00 EXACTLY, no float drift."""
        from pyspark.sql import functions as F
        df = spark.range(0, 100_000).withColumn(
            "amount", F.lit(Decimal("0.01")).cast("decimal(10,2)"),
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount"])
        assert rows == 100_000
        assert sums["amount"] == Decimal("1000.00")

    def test_one_agg_pass_returns_count_and_sums(self, spark):
        """Spark's catalyst optimiser should fuse count + sum into one
        shuffle.  We can't directly assert "only one stage" without
        plan inspection, but we can verify both anchors are produced
        from one call and they're consistent."""
        df = spark.createDataFrame(
            [(i, Decimal(f"{i}.50")) for i in range(1, 11)],
            ["id", "amount"],
        )
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount"])
        # 1+2+...+10 = 55, plus 10 * 0.50 = 5 -> 60.00
        assert rows == 10
        assert sums["amount"] == Decimal("60.00")


# ──────────────────────────────────────────────────────────────────────
#  _verify_output_completeness -- REAL re-read
# ──────────────────────────────────────────────────────────────────────


class TestVerifyOutputCompletenessReal:
    """Write a real Spark file, then re-read via the helper.  Verify
    counts + sums match."""

    def test_csv_round_trip_matches(self, spark, tmp_path):
        df = spark.createDataFrame(
            [(1, Decimal("10.00")), (2, Decimal("20.00")), (3, Decimal("30.00"))],
            ["id", "amount"],
        )
        out = str(tmp_path / "out")
        df.coalesce(1).write.option("header", "true").csv(out)
        s = _bare_s3_base()
        actual_rows, actual_sums, mism = s._verify_output_completeness(
            spark, out, "csv",
            expected_rows=3,
            expected_sums={"amount": Decimal("60.00")},
            delimiter=",",
            header=True,
        )
        assert actual_rows == 3
        assert mism == []

    def test_row_mismatch_raises(self, spark, tmp_path):
        df = spark.createDataFrame(
            [(i,) for i in range(10)], ["id"],
        )
        out = str(tmp_path / "out")
        df.coalesce(1).write.option("header", "true").csv(out)
        s = _bare_s3_base()
        with pytest.raises(ValueError, match="row count"):
            s._verify_output_completeness(
                spark, out, "csv",
                expected_rows=100,  # wrong
                expected_sums={},
                header=True,
            )

    def test_parquet_round_trip(self, spark, tmp_path):
        df = spark.createDataFrame(
            [(1, Decimal("100.00")), (2, Decimal("200.00"))],
            ["id", "amount"],
        )
        out = str(tmp_path / "out.parquet")
        df.coalesce(1).write.parquet(out)
        s = _bare_s3_base()
        actual_rows, actual_sums, mism = s._verify_output_completeness(
            spark, out, "parquet",
            expected_rows=2,
            expected_sums={"amount": Decimal("300.00")},
        )
        assert actual_rows == 2
        assert mism == []

    def test_sum_mismatch_raises(self, spark, tmp_path):
        df = spark.createDataFrame(
            [(1, Decimal("10.00")), (2, Decimal("20.00"))],
            ["id", "amount"],
        )
        out = str(tmp_path / "out.parquet")
        df.coalesce(1).write.parquet(out)
        s = _bare_s3_base()
        with pytest.raises(ValueError, match="SUM"):
            s._verify_output_completeness(
                spark, out, "parquet",
                expected_rows=2,
                expected_sums={"amount": Decimal("999.99")},  # wrong
            )


# ──────────────────────────────────────────────────────────────────────
#  _resolve_spark_session_from_df -- REAL DataFrames
# ──────────────────────────────────────────────────────────────────────


class TestSparkSessionResolutionReal:
    """Real pyspark DataFrames must expose the session via the
    canonical attr."""

    def test_resolves_from_real_dataframe(self, spark):
        df = spark.createDataFrame([(1,)], ["x"])
        from steps.s3.s3_query_base import S3QueryBase
        sess = S3QueryBase._resolve_spark_session_from_df(df)
        assert sess is spark

    def test_resolves_after_chained_transformations(self, spark):
        from pyspark.sql import functions as F
        df = (
            spark.createDataFrame([(1, 10), (2, 20)], ["id", "v"])
            .withColumn("v2", F.col("v") * 2)
            .filter(F.col("id") > 0)
        )
        from steps.s3.s3_query_base import S3QueryBase
        sess = S3QueryBase._resolve_spark_session_from_df(df)
        assert sess is spark


# ──────────────────────────────────────────────────────────────────────
#  End-to-end Phase 152 round-trip
# ──────────────────────────────────────────────────────────────────────


class TestPhase152EndToEnd:
    """Source -> anchors -> write -> verify -- the complete Spark path
    one operator call would take."""

    def test_full_loop_csv(self, spark, tmp_path):
        # 1. Source DataFrame (simulates Spark reading from S3)
        df = spark.createDataFrame(
            [(i, Decimal(str(i * 1.5))) for i in range(1, 101)],
            ["id", "amount"],
        )

        # 2. Anchor in one pass.
        s = _bare_s3_base()
        rows, sums = s._compute_source_anchors(df, ["amount"])
        # 1.5 + 3.0 + ... + 150 = 1.5 * (100 * 101 / 2) = 7575
        assert rows == 100
        assert sums["amount"] == Decimal("7575.0")

        # 3. Write to file (mimics _write_to_file's staging+publish).
        out = str(tmp_path / "out")
        df.coalesce(1).write.option("header", "true").csv(out)

        # 4. Re-read verify -- counts + sums must match anchors exactly.
        actual_rows, actual_sums, mism = s._verify_output_completeness(
            spark, out, "csv",
            expected_rows=rows,
            expected_sums=sums,
            header=True,
        )
        assert actual_rows == rows
        assert actual_sums["amount"] == sums["amount"]
        assert mism == []
