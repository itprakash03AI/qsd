"""AutoPlan: measure-then-decide planner -- record count irrelevant.

These tests prove that ONE codepath produces sensible plans across
6 orders of magnitude of input size (1K -> 1B rows) without any
operator-tunable size thresholds.  The plan's decisions are
verifiable + explained per-decision.

Test matrix covers:
  * Scale: 1K, 1M, 10M, 150M, 1B rows
  * Partition shape: single / 10 partitions / 1000 partitions / 100K skewed
  * Row width: narrow (50 B), normal (200 B), wide (2 KB), very wide (10 KB)
  * Pod size: small (2 cores, 4 GB), medium (8 cores, 32 GB), large (32 cores, 128 GB)
  * Operator overrides: each knob individually + combined
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


def _build_inputs(**kw):
    """Convenience: AutoPlanInputs with sensible defaults overridable per-test."""
    from steps.file.autoplan import AutoPlanInputs
    defaults = dict(
        total_rows=1_000_000,
        partition_cardinality=100,
        max_partition_rows=20_000,
        avg_partition_rows=10_000,
        avg_row_bytes=200,
        cpu_cores=8,
        available_memory_bytes=32 * 1024**3,  # 32 GB
    )
    defaults.update(kw)
    return AutoPlanInputs(**defaults)


# ──────────────────────────────────────────────────────────────────────
#  Mode decision is RECORD-COUNT-DRIVEN automatically
# ──────────────────────────────────────────────────────────────────────


class TestModeDecision:
    """Mode (SINGLE vs PARTITION_VALUES) flows from the memory math,
    not from an operator-tunable row threshold."""

    def test_no_partition_column_forces_single(self):
        from steps.file.autoplan import autoplan
        inp = _build_inputs(partition_cardinality=0)
        out = autoplan(inp)
        assert out.mode == "single"
        mode_dec = next(d for d in out.decisions if d.knob == "mode")
        assert "no partition_column" in mode_dec.reason

    def test_tiny_job_picks_single(self):
        """1M rows x 200 B = 200 MB fits in 12.8 GB memory budget."""
        from steps.file.autoplan import autoplan
        inp = _build_inputs(total_rows=1_000_000, available_memory_bytes=32*1024**3)
        out = autoplan(inp)
        assert out.mode == "single"

    def test_huge_job_picks_partition_values(self):
        """150M rows x 200 B = 30 GB exceeds 12.8 GB budget."""
        from steps.file.autoplan import autoplan
        inp = _build_inputs(total_rows=150_000_000, available_memory_bytes=32*1024**3)
        out = autoplan(inp)
        assert out.mode == "partition_values"
        mode_dec = next(d for d in out.decisions if d.knob == "mode")
        assert "exceeds" in mode_dec.reason

    def test_wide_rows_trigger_partition_sooner(self):
        """50M rows x 200 B = 10 GB SINGLE OK.
           50M rows x 5000 B = 250 GB PARTITION required."""
        from steps.file.autoplan import autoplan
        narrow = autoplan(_build_inputs(
            total_rows=50_000_000, avg_row_bytes=200,
            available_memory_bytes=32*1024**3,
        ))
        wide = autoplan(_build_inputs(
            total_rows=50_000_000, avg_row_bytes=5000,
            available_memory_bytes=32*1024**3,
        ))
        assert narrow.mode == "single"
        assert wide.mode == "partition_values"

    def test_operator_can_override_mode(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=100,  # would pick single
            override_mode="partition_values",
        ))
        assert out.mode == "partition_values"
        mode_dec = next(d for d in out.decisions if d.knob == "mode")
        assert "operator override" in mode_dec.reason


# ──────────────────────────────────────────────────────────────────────
#  Scale-agnostic behaviour: same code 1K..1B
# ──────────────────────────────────────────────────────────────────────


class TestScaleAgnostic:
    """Run AutoPlan at 6 orders of magnitude.  Confirm the planner
    produces a sensible plan for every scale without crashing or
    returning nonsense values."""

    @pytest.mark.parametrize("rows", [
        1_000, 100_000, 1_000_000, 10_000_000,
        150_000_000, 1_000_000_000,
    ])
    def test_sensible_plan_at_every_scale(self, rows):
        from steps.file.autoplan import autoplan
        inp = _build_inputs(total_rows=rows)
        out = autoplan(inp)
        assert out.mode in ("single", "partition_values")
        assert 2 <= out.max_concurrent_chunks <= 16
        assert 10_000 <= out.batch_size <= 500_000
        assert 1 <= out.queue_maxsize <= 4
        assert out.target_chunk_rows >= 100_000
        assert out.verify_strategy in ("full", "sample", "skip")
        # Every knob has a decision explained.
        knobs = {d.knob for d in out.decisions}
        for required in ("mode", "max_concurrent_chunks", "batch_size",
                          "queue_maxsize", "verify_strategy"):
            assert required in knobs


# ──────────────────────────────────────────────────────────────────────
#  Concurrency picks the right number
# ──────────────────────────────────────────────────────────────────────


class TestConcurrencyDecision:
    """max_concurrent_chunks = min(cpu_cap, mem_cap, ceiling) with
    operator override always winning."""

    def test_large_pod_picks_ceiling(self):
        from steps.file.autoplan import autoplan, DEFAULT_CONCURRENCY_CEILING
        out = autoplan(_build_inputs(
            cpu_cores=64, available_memory_bytes=256*1024**3,
        ))
        assert out.max_concurrent_chunks == DEFAULT_CONCURRENCY_CEILING

    def test_small_pod_capped_by_cpu(self):
        """4 cores -> cpu_cap=2.  Memory cap higher.  Floor = 2."""
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            cpu_cores=4, available_memory_bytes=32*1024**3,
        ))
        assert out.max_concurrent_chunks == 2  # cpu_cap

    def test_tiny_memory_pod_capped_by_memory(self):
        """Constrained pod (cores + RAM) drives down via mem_cap.

        With per_chunk_bytes = batch_size * row_bytes * queue, even
        modest concurrency saturates a tiny pod.  Use truly tiny RAM
        + very wide rows so mem_cap = 2 (the floor).
        """
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            cpu_cores=16,
            available_memory_bytes=256 * 1024**2,  # 256 MB
            avg_row_bytes=10_000,                  # 10 KB rows
        ))
        # per_chunk = 10000 (batch floor) * 10000 (row) * 2 (queue) = 200 MB
        # mem_cap = 256MB * 0.4 / 200MB = 0 -> floor 2
        assert out.max_concurrent_chunks == 2

    def test_explicit_override(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(override_max_concurrent=12))
        assert out.max_concurrent_chunks == 12

    def test_ceiling_override(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            cpu_cores=64, available_memory_bytes=512*1024**3,
            override_concurrency_ceiling=4,
        ))
        assert out.max_concurrent_chunks == 4


# ──────────────────────────────────────────────────────────────────────
#  Batch size adapts to row width
# ──────────────────────────────────────────────────────────────────────


class TestBatchSizeDecision:
    """batch_size targets ~5 MB per batch -- so narrow rows pack more
    rows per batch than wide rows."""

    def test_narrow_rows_pack_bigger_batches(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=50))
        # 5 MB / 50 B = 100K rows per batch (clamped to 500K cap)
        assert out.batch_size >= 100_000

    def test_wide_rows_smaller_batches(self):
        """2026-06-20 deep-dive: floor raised from 10K -> 100K to match
        legacy DEFAULT_BATCH_SIZE.  Pre-fix the 10K floor caused a
        regression on 5.6M-row jobs (7 min -> 9 min) because the new
        floor was below the legacy default that was working fine."""
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=5000))
        # 20 MB / 5000 B = 4000 rows -- below 100K floor -> floor.
        assert out.batch_size == 100_000  # legacy-parity floor

    def test_very_wide_rows_hit_floor(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=50_000))
        assert out.batch_size == 100_000  # floor


# ──────────────────────────────────────────────────────────────────────
#  Queue depth adapts to row width
# ──────────────────────────────────────────────────────────────────────


class TestQueueMaxsizeDecision:
    """Narrow rows allow deeper queue; wide rows need shallow to keep
    per-chunk memory bounded."""

    def test_narrow_rows_deep_queue(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=100))
        assert out.queue_maxsize == 4

    def test_medium_rows_default_queue(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=500))
        assert out.queue_maxsize == 3

    def test_wide_rows_shallow_queue(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(avg_row_bytes=5000))
        assert out.queue_maxsize == 2


# ──────────────────────────────────────────────────────────────────────
#  Auto-bucketing
# ──────────────────────────────────────────────────────────────────────


class TestAutoBucketing:
    """When partition cardinality exceeds the chunk target, auto-bucket
    so adjacent values are grouped into one chunk."""

    def test_no_bucketing_when_within_budget(self):
        """Few partitions + small max_concurrent -> target_chunks tiny ->
        no bucketing.  Use 4 partitions on a 2-cpu pod so target_chunks=8."""
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=10_000_000_000,
            avg_row_bytes=2000,
            available_memory_bytes=4*1024**3,
            cpu_cores=2,                    # max_concurrent = 2
            partition_cardinality=4,        # 4 partitions
            max_partition_rows=500_000_000,
            avg_partition_rows=500_000_000,
        ))
        # mode = partition_values, 4 partitions < target_chunks (2*4=8).
        # No bucketing needed.
        assert out.auto_bucket_size == 1

    def test_bucketing_when_cardinality_huge(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=10_000_000_000,  # ensure partition mode
            avg_row_bytes=2000,
            available_memory_bytes=4*1024**3,
            partition_cardinality=10_000,
            max_partition_rows=1_000_000,
            avg_partition_rows=1_000_000,
        ))
        # 10K partitions / (~8 * 4 = 32) chunks -> bucket size 313
        assert out.auto_bucket_size > 1

    def test_single_mode_no_bucketing(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=1000,
            partition_cardinality=0,  # forces single
        ))
        assert out.auto_bucket_size == 1


# ──────────────────────────────────────────────────────────────────────
#  Verify strategy adapts to size
# ──────────────────────────────────────────────────────────────────────


class TestVerifyStrategy:
    """Small/medium jobs get full re-read; huge jobs get sample-based
    verification so the verify cost stays bounded."""

    def test_small_gets_full(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=1_000_000,
            available_memory_bytes=32*1024**3,
        ))
        assert out.verify_strategy == "full"

    def test_huge_gets_sample(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs(
            total_rows=10_000_000_000,  # 10B
            avg_row_bytes=200,
            available_memory_bytes=8*1024**3,
        ))
        assert out.verify_strategy == "sample"
        assert 0.001 <= out.verify_sample_pct <= 0.05

    def test_sample_pct_shrinks_for_larger_rows(self):
        from steps.file.autoplan import autoplan
        out1 = autoplan(_build_inputs(
            total_rows=1_000_000_000,  # 1B
            available_memory_bytes=8*1024**3,
        ))
        out2 = autoplan(_build_inputs(
            total_rows=100_000_000_000,  # 100B
            available_memory_bytes=8*1024**3,
        ))
        # Both should sample; larger row count -> smaller pct.
        if out1.verify_strategy == "sample" and out2.verify_strategy == "sample":
            assert out2.verify_sample_pct <= out1.verify_sample_pct


# ──────────────────────────────────────────────────────────────────────
#  Decision explanations
# ──────────────────────────────────────────────────────────────────────


class TestExplanations:
    """Every decision has a human-readable reason -- operators can see
    WHY the plan picked what it picked."""

    def test_every_decision_has_reason(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs())
        for d in out.decisions:
            assert d.reason and isinstance(d.reason, str)
            assert d.knob and isinstance(d.knob, str)
            assert d.chosen is not None

    def test_explain_dict_for_run_report(self):
        from steps.file.autoplan import autoplan
        out = autoplan(_build_inputs())
        explanations = out.explain()
        assert "mode" in explanations
        assert "max_concurrent_chunks" in explanations
        # Reason is appended to value.
        for k, v in explanations.items():
            assert " -- " in v  # "<chosen> -- <reason>" format


# ──────────────────────────────────────────────────────────────────────
#  build_inputs_from_probe convenience
# ──────────────────────────────────────────────────────────────────────


class TestBuildInputsFromProbe:
    """build_inputs_from_probe extracts everything AutoPlan needs from
    the probe result + job_config."""

    def test_probe_result_drives_cardinality(self):
        from steps.file.autoplan import build_inputs_from_probe
        from decimal import Decimal
        probe = {
            "counts": {"NA": 100, "EU": 200, "AP": 50, None: 10},
            "had_null_partition": True,
        }
        inp = build_inputs_from_probe(
            probe_result=probe, total_rows=360, job_config={},
        )
        assert inp.partition_cardinality == 4
        assert inp.max_partition_rows == 200
        assert inp.null_partition_present is True

    def test_no_probe_means_no_partition_cardinality(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000, job_config={},
        )
        assert inp.partition_cardinality == 0

    def test_force_single_override(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={"force_single": "TRUE"},
        )
        assert inp.override_mode == "single"

    def test_force_partition_override(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={"force_partition": "TRUE"},
        )
        assert inp.override_mode == "partition_values"

    def test_job_config_overrides_propagate(self):
        from steps.file.autoplan import build_inputs_from_probe
        inp = build_inputs_from_probe(
            probe_result=None, total_rows=1000,
            job_config={
                "max_concurrent_chunks": 6,
                "batch_size": 25_000,
                "queue_maxsize": 2,
            },
        )
        assert inp.override_max_concurrent == 6
        assert inp.override_batch_size == 25_000
        assert inp.override_queue_maxsize == 2


# ──────────────────────────────────────────────────────────────────────
#  System measurement
# ──────────────────────────────────────────────────────────────────────


class TestSystemMeasurement:
    def test_returns_cpu_and_mem_keys(self):
        from steps.file.autoplan import measure_system_resources
        sysm = measure_system_resources()
        assert "cpu_cores" in sysm
        assert "available_memory_bytes" in sysm
        assert sysm["cpu_cores"] >= 1
        assert sysm["available_memory_bytes"] > 0

    def test_psutil_missing_falls_back(self):
        from unittest.mock import patch
        from steps.file.autoplan import measure_system_resources
        import builtins
        real_import = builtins.__import__

        def _no_psutil(name, *a, **kw):
            if name == "psutil":
                raise ImportError()
            return real_import(name, *a, **kw)

        with patch("builtins.__import__", side_effect=_no_psutil):
            sysm = measure_system_resources()
        assert sysm["available_memory_bytes"] > 0  # fallback default
