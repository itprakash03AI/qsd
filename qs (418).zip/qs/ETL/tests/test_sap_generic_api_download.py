"""Regression net for SapGenericApiDownload.

Locks the four contract guarantees the new step needs to honour:

  1. Polling-row overlay (SAP_API_URL + creds + output_dir) lands on config
     and required-field gate fires when one is missing.
  2. URL placeholder substitution — {YEAR}/{MONTH}/{TIMESTAMP} +
     arbitrary {KEY} from url_substitutions (both config + polling row).
  3. The end-to-end task dict shape downstream steps consume
     (downloaded_files, totalcount, full_count, output_dir, p_gjahr,
     p_poper, output_format, completeness_ledger).
  4. Fail-loud on a zero-row extract unless allow_empty_extract=true.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── Helpers ──────────────────────────────────────────────────────────


def _make_step(logger=None):
    from steps.sap.sap_generic_api_download import SapGenericApiDownload
    return SapGenericApiDownload(
        starburst_clients={}, oracle_data_manager=None,
        logger=logger or MagicMock(), config={},
    )


# ── 1. Config overlay + required-field gate ─────────────────────────


class TestLoadAndValidateConfig:

    def test_polling_row_overlays_url_and_creds(self, tmp_path):
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "output_dir": str(tmp_path),
            "page_size": 1000,
        }))
        step = _make_step()
        task = {
            "sql_query_path":   str(cfg_path),
            "SAPU":             "alice",
            "SAPP":             "secret",
            # SAP_API_URL is a new key — we read it via the JSON config
            # path in the merge below, because the base class overlay
            # only maps explicitly-listed SAP_* columns.  Use the JSON
            # path to deliver it.
        }
        # Add sap_api_url to the JSON so the polling row doesn't need
        # to name a new column (operator can still drop it on the row
        # under SQL_QUERY_PATH's contents).
        cfg_path.write_text(json.dumps({
            "output_dir": str(tmp_path),
            "page_size": 1000,
            "sap_api_url": "https://sap.example/DocAPI/Data?$format=json",
        }))
        from steps.sap.sap_generic_api_download import SapGenericApiDownload
        cfg = step._load_and_validate_config(
            task, SapGenericApiDownload.REQUIRED_FIELDS,
        )
        assert cfg["sap_username"] == "alice"
        assert cfg["sap_password"] == "secret"
        assert cfg["sap_api_url"].startswith("https://sap.example/DocAPI")
        assert cfg["page_size"] == 1000

    def test_polling_row_carries_sap_api_url_directly(self, tmp_path):
        """SAP_API_URL on the task row should land on config without
        needing a JSON config — first-class polling-row column added
        2026-06-10."""
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({"output_dir": str(tmp_path)}))
        step = _make_step()
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "alice", "SAPP": "secret",
            "SAP_API_URL": "https://sap.example/DocAPI/Data?$format=json",
        }
        from steps.sap.sap_generic_api_download import SapGenericApiDownload
        cfg = step._load_and_validate_config(
            task, SapGenericApiDownload.REQUIRED_FIELDS,
        )
        assert cfg["sap_api_url"] == "https://sap.example/DocAPI/Data?$format=json"

    def test_polling_row_sap_api_url_overrides_json(self, tmp_path):
        """Polling-row SAP_API_URL must win over the JSON value —
        same precedence rule MEBAL's SAP_ME_BALANCE_API uses."""
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "output_dir":  str(tmp_path),
            "sap_api_url": "https://json-side/Data",
        }))
        step = _make_step()
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "SAP_API_URL": "https://polling-row-side/Data",
        }
        from steps.sap.sap_generic_api_download import SapGenericApiDownload
        cfg = step._load_and_validate_config(
            task, SapGenericApiDownload.REQUIRED_FIELDS,
        )
        assert cfg["sap_api_url"] == "https://polling-row-side/Data"

    def test_missing_required_field_raises(self, tmp_path):
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "output_dir": str(tmp_path),
            # sap_api_url missing on purpose
        }))
        from steps.sap.sap_generic_api_download import SapGenericApiDownload
        step = _make_step()
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
        }
        with pytest.raises(ValueError, match="Missing required config fields"):
            step._load_and_validate_config(
                task, SapGenericApiDownload.REQUIRED_FIELDS,
            )


# ── 2. URL placeholder substitution ──────────────────────────────────


class TestBuildApiUrl:

    def test_year_month_timestamp_substitution(self, tmp_path):
        step = _make_step()
        config = {
            "sap_api_url": (
                "https://sap.example/DocAPI("
                "p_gjahr='{YEAR}',p_poper='{MONTH}',"
                "p_timestamp=datetime'{TIMESTAMP}')/Data"
            ),
            "run_timestamp": "2026-06-10T12:00:00",
        }
        url = step._build_api_url(config, "2026", "006")
        assert "p_gjahr='2026'" in url
        assert "p_poper='006'" in url
        assert "datetime'2026-06-10T12:00:00'" in url

    def test_arbitrary_substitutions_from_config(self):
        step = _make_step()
        config = {
            "sap_api_url": "https://sap.example/Doc/{DOC_TYPE}/Status/{STATUS}/Data",
            "url_substitutions": {
                "DOC_TYPE": "invoice",
                "STATUS":   "posted",
            },
        }
        url = step._build_api_url(config, "", "")
        assert url == "https://sap.example/Doc/invoice/Status/posted/Data"

    def test_task_substitutions_win_over_config(self):
        step = _make_step()
        config = {
            "sap_api_url": "https://sap.example/Doc/{DOC_TYPE}/Data",
            "url_substitutions": {"DOC_TYPE": "invoice"},
        }
        task = {"url_substitutions": {"DOC_TYPE": "credit_note"}}
        url = step._build_api_url(config, "", "", task=task)
        assert "credit_note" in url
        assert "invoice" not in url

    def test_no_placeholders_passes_url_through_unchanged(self):
        step = _make_step()
        config = {
            "sap_api_url": "https://sap.example/Doc/All?$format=json",
        }
        url = step._build_api_url(config, "", "")
        assert url == "https://sap.example/Doc/All?$format=json"

    def test_empty_period_substitutes_to_empty_string(self):
        """A generic API without periods should NOT leave literal
        {YEAR} / {MONTH} sitting in the URL — substitute to ''."""
        step = _make_step()
        config = {
            "sap_api_url": "https://sap.example/Doc?year={YEAR}&month={MONTH}",
        }
        url = step._build_api_url(config, "", "")
        assert "{YEAR}" not in url
        assert "{MONTH}" not in url


# ── 3. End-to-end task dict shape ────────────────────────────────────


class TestEndToEndTaskShape:
    """The downstream Consolidate / CTL / Compress / Deliver /
    CheckCompleteness steps consume specific keys from the task dict.
    Lock each one so a future refactor can't silently drop them."""

    def _run_end_to_end(self, tmp_path, *,
                        rows=None, expected_count=None,
                        url_substitutions=None):
        """Set up the JSON config, stub the network calls, run one
        invocation, return the populated task dict."""
        if rows is None:
            rows = [
                [{"DocNo": "1001", "Amount": "100"},
                 {"DocNo": "1002", "Amount": "200"}],
                [{"DocNo": "1003", "Amount": "300"}],
            ]
        if expected_count is None:
            expected_count = sum(len(p) for p in rows)
        cfg = {
            "sap_api_url": "https://sap.example/DocAPI/Data?$format=json",
            "output_dir": str(tmp_path),
            "page_size": 2,
            "rate_limit_rps": 1000,
            "enable_count_reconcile": True,
            "verify_ssl": False,
        }
        if url_substitutions:
            cfg["url_substitutions"] = url_substitutions
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps(cfg))
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "run_id": 42, "run_detail_id": 1,
            "fk_dag_id": "test", "fk_report_id": "test",
            "p_gjahr": "2026", "p_poper": "006",
        }

        step = _make_step()
        # Stub network so the test doesn't actually hit SAP.
        with patch.object(
            type(step), "_build_session",
            return_value=MagicMock(close=MagicMock()),
        ), patch.object(
            type(step), "_fetch_odata_count",
            return_value=expected_count,
        ), patch.object(
            type(step), "_stream_odata_pages",
            return_value=iter(enumerate(rows)),
        ):
            asyncio.run(step._execute_step(
                task, "WORKER_CONN", "DEST_CONN", "test_step",
            ))
        return task

    def test_downloaded_files_emits_single_path(self, tmp_path):
        task = self._run_end_to_end(tmp_path)
        files = task["downloaded_files"]
        assert isinstance(files, list)
        assert len(files) == 1
        assert os.path.exists(files[0])

    def test_totalcount_equals_streamed_rows(self, tmp_path):
        task = self._run_end_to_end(tmp_path)
        assert task["totalcount"] == 3
        assert task["full_count"] == 3

    def test_emits_output_dir_and_run_subdir(self, tmp_path):
        task = self._run_end_to_end(tmp_path)
        assert task["output_dir"] == task["run_subdir"]
        assert os.path.isdir(task["output_dir"])

    def test_period_flows_through(self, tmp_path):
        task = self._run_end_to_end(tmp_path)
        assert task["p_gjahr"] == "2026"
        assert task["p_poper"] == "006"

    def test_output_format_emitted(self, tmp_path):
        task = self._run_end_to_end(tmp_path)
        assert task["output_format"] == "csv"
        assert task["output_formats"] == ["csv"]

    def test_completeness_ledger_shape_matches_mebal(self, tmp_path):
        """SapCheckCompleteness reads task['completeness_ledger']
        with these exact keys — same shape MEBAL emits."""
        task = self._run_end_to_end(tmp_path)
        ledger = task["completeness_ledger"]
        assert set(ledger.keys()) == {
            "full_count", "sum_expected", "sum_actual",
            "groups_total", "period",
        }
        assert ledger["full_count"]   == 3
        assert ledger["sum_expected"] == 3
        assert ledger["sum_actual"]   == 3
        assert ledger["groups_total"] == 1


# ── 4. Fail-loud on empty / mismatched extract ───────────────────────


class TestSafetyNets:

    def test_zero_rows_raises_unless_bypassed(self, tmp_path):
        step = _make_step()
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "sap_api_url": "https://sap.example/Doc/Data",
            "output_dir":  str(tmp_path),
            "verify_ssl":  False,
            "enable_count_reconcile": False,
        }))
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "run_id": 1, "run_detail_id": 1,
        }
        with patch.object(
            type(step), "_build_session",
            return_value=MagicMock(close=MagicMock()),
        ), patch.object(
            type(step), "_stream_odata_pages",
            return_value=iter([]),
        ):
            with pytest.raises(ValueError, match="0 rows returned"):
                asyncio.run(step._execute_step(
                    task, "W", "D", "step",
                ))

    def test_zero_rows_bypass_via_allow_empty_extract(self, tmp_path):
        step = _make_step()
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "sap_api_url": "https://sap.example/Doc/Data",
            "output_dir":  str(tmp_path),
            "verify_ssl":  False,
            "enable_count_reconcile": False,
            "allow_empty_extract": True,
        }))
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "run_id": 1, "run_detail_id": 1,
        }
        with patch.object(
            type(step), "_build_session",
            return_value=MagicMock(close=MagicMock()),
        ), patch.object(
            type(step), "_stream_odata_pages",
            return_value=iter([]),
        ):
            asyncio.run(step._execute_step(
                task, "W", "D", "step",
            ))
        assert task["totalcount"] == 0

    def test_count_mismatch_raises_unless_bypassed(self, tmp_path):
        step = _make_step()
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "sap_api_url": "https://sap.example/Doc/Data",
            "output_dir":  str(tmp_path),
            "verify_ssl":  False,
            "enable_count_reconcile": True,
        }))
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "run_id": 1, "run_detail_id": 1,
        }
        with patch.object(
            type(step), "_build_session",
            return_value=MagicMock(close=MagicMock()),
        ), patch.object(
            type(step), "_fetch_odata_count",
            return_value=100,
        ), patch.object(
            type(step), "_stream_odata_pages",
            return_value=iter([(0, [{"x": "1"}, {"x": "2"}])]),
        ):
            with pytest.raises(ValueError, match="count.*"):
                asyncio.run(step._execute_step(
                    task, "W", "D", "step",
                ))

    def test_count_unavailable_falls_back_gracefully(self, tmp_path):
        """When the API doesn't expose $count, the pre-flight fails
        but the run must complete with totalcount == streamed rows."""
        step = _make_step()
        cfg_path = tmp_path / "task.json"
        cfg_path.write_text(json.dumps({
            "sap_api_url": "https://sap.example/Doc/Data",
            "output_dir":  str(tmp_path),
            "verify_ssl":  False,
            "enable_count_reconcile": True,
        }))
        task = {
            "sql_query_path": str(cfg_path),
            "SAPU": "u", "SAPP": "p",
            "run_id": 1, "run_detail_id": 1,
        }
        with patch.object(
            type(step), "_build_session",
            return_value=MagicMock(close=MagicMock()),
        ), patch.object(
            type(step), "_fetch_odata_count",
            side_effect=RuntimeError("API does not support $count"),
        ), patch.object(
            type(step), "_stream_odata_pages",
            return_value=iter([(0, [{"x": "1"}, {"x": "2"}])]),
        ):
            asyncio.run(step._execute_step(
                task, "W", "D", "step",
            ))
        assert task["totalcount"] == 2
        # full_count falls back to actual when $count is unavailable
        assert task["full_count"] == 2
