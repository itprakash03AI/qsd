"""Tests for FileRunReport's full-SQL download feature (2026-06-12).

Locks the contract that:
  * ``add_sql_summary`` stores BOTH a one-line summary AND the full
    SQL.
  * ``write()`` emits one ``queries/<safe_job_id>.sql`` file per
    recorded job.
  * ``to_html()`` renders a ``<a href ... download>`` link per row.
  * The Starburst -> Oracle steps (both Spark + light) feed the
    same report when ``task['_run_report']`` is attached.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── 2026-06-18: Multi-source cumulative totals (operator-reported bug) ───


class TestMultiSourceCumulativeTotals:
    """``set_counts`` was last-writer-wins: cloud step set
    ``expected_total=3M``, onprem step overwrote with ``2.6M``, the
    rendered result.html showed 2.6M as if cloud never extracted.
    Fix: render G1/G3/G5 chips by SUMMING ``expected_total`` /
    ``records`` / ``consolidated_rows`` across ``job_results`` -- one
    entry per source.  TOTAL row at the bottom of the job-summary
    table makes "cloud + onprem == final file" visible.
    """

    def test_cumulative_source_count_sums_across_sources(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp")
        rr.add_job_result({"report_id": 1, "datasource": "CLOUD",
                           "status": "success",
                           "expected_total": 3_000_000, "records": 3_000_000})
        rr.add_job_result({"report_id": 1, "datasource": "ONPREM",
                           "status": "success",
                           "expected_total": 2_624_546, "records": 2_624_546})
        assert rr._cum_source_count() == 5_624_546
        assert rr._cum_downloaded() == 5_624_546

    def test_g3_chip_renders_cumulative_delta_on_multi_source(self):
        """Operator-reported scenario: source 5,624,546 vs downloaded
        5,634,098.  Pre-fix the chip showed only the last source's
        local total (and looked OK).  Post-fix it shows the cumulative
        delta +9,552 against the cumulative source.
        """
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp")
        rr.add_job_result({"report_id": 1, "datasource": "CLOUD",
                           "status": "success",
                           "expected_total": 3_000_000, "records": 3_005_000})
        rr.add_job_result({"report_id": 1, "datasource": "ONPREM",
                           "status": "success",
                           "expected_total": 2_624_546, "records": 2_629_098})
        entries = {e["control"]: e for e in rr._ledger_entries()}
        assert entries["G1"]["detail"] == "5,624,546"
        # G3 must compare cumulative download (5,634,098) to cumulative
        # source (5,624,546) and surface the +9,552 delta.
        assert "delta +9,552" in entries["G3"]["detail"]
        assert entries["G3"]["ok"] is False

    def test_set_counts_last_writer_wins_is_now_overridden_by_job_results(self):
        """Even when per-step set_counts calls overwrite each other
        (cloud sets 3M then onprem sets 2.6M into self.expected_total),
        the rendered chips read the cumulative from job_results, NOT
        the stale single-source last value.
        """
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp")
        rr.add_job_result({"report_id": 1, "datasource": "CLOUD",
                           "status": "success",
                           "expected_total": 3_000_000, "records": 3_000_000})
        rr.add_job_result({"report_id": 1, "datasource": "ONPREM",
                           "status": "success",
                           "expected_total": 2_624_546, "records": 2_624_546})
        # Simulate the last-writer-wins overwrite the orchestrator did pre-fix.
        rr.set_counts(expected_total=2_624_546, sum_chunk_actual=2_624_546)
        # Render still shows cumulative thanks to the job_results-based fix.
        entries = {e["control"]: e for e in rr._ledger_entries()}
        assert entries["G1"]["detail"] == "5,624,546"

    def test_html_table_has_total_row_when_multi_source(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp")
        rr.add_job_result({"report_id": 1, "datasource": "CLOUD",
                           "status": "success",
                           "expected_total": 3_000_000, "records": 3_005_000,
                           "consolidated_rows": 3_005_000,
                           "chunks": 10, "file_path": "cloud.dat"})
        rr.add_job_result({"report_id": 1, "datasource": "ONPREM",
                           "status": "success",
                           "expected_total": 2_624_546, "records": 2_629_098,
                           "consolidated_rows": 2_629_098,
                           "chunks": 8, "file_path": "onprem.dat"})
        html = rr.to_html()
        assert "TOTAL (sum across sources)" in html
        # Cumulative source AND cumulative download both visible in HTML.
        assert "5,624,546" in html
        assert "5,634,098" in html
        # Mismatch annotation on the TOTAL row.
        assert "+9,552" in html or "Δ +9,552" in html


# ─── 1. FileRunReport.add_sql_summary + write + HTML ───────────────────


class TestQueryDownloadFeature:
    def test_add_sql_summary_stores_full_text(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="")
        sql = "SELECT *\nFROM hive.bcp_pres.daily\nWHERE dt='2025-07-14'"
        rr.add_sql_summary("report_42", sql)
        # First-line abbrev kept.
        assert rr.sql_summary["report_42"].startswith("SELECT *")
        # Full SQL preserved verbatim.
        assert rr.sql_full["report_42"] == sql

    def test_empty_sql_is_skipped(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="")
        rr.add_sql_summary("rep_x", "")
        assert "rep_x" not in rr.sql_full

    def test_write_emits_per_job_sql_file(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_context(report_id=42, business_date="2025-07-14")
        rr.add_sql_summary("report_42", "SELECT 1 FROM dual")
        rr.add_sql_summary("report_999",
                           "SELECT *\nFROM big_table\nWHERE dt='2025-07-14'")
        rr.mark_success()
        paths = rr.write()
        # HTML written (TXT opt-in since 2026-06-22).
        assert "html" in paths
        assert "txt" not in paths  # .txt disabled by default
        # Per-job .sql files exist.
        queries_dir = tmp_path / "queries"
        assert queries_dir.is_dir()
        f1 = queries_dir / "report_42.sql"
        f2 = queries_dir / "report_999.sql"
        assert f1.exists() and f2.exists()
        assert f1.read_text() == "SELECT 1 FROM dual"
        assert "big_table" in f2.read_text()
        # sql_files dict mapped both jobs.
        assert rr.sql_files["report_42"] == str(f1)
        assert rr.sql_files["report_999"] == str(f2)

    def test_html_contains_download_link_per_job(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_context(report_id=42, business_date="2025-07-14")
        rr.add_sql_summary("report_42", "SELECT 1 FROM dual")
        rr.add_sql_summary("report_999", "SELECT 2 FROM dual")
        rr.mark_success()
        rr.write()
        html = (tmp_path / "run_report.html").read_text(encoding="utf-8")
        # Relative download links (forward slashes regardless of OS).
        assert 'href="queries/report_42.sql"' in html
        assert 'href="queries/report_999.sql"' in html
        # The ``download`` attribute triggers browser save vs render.
        assert "download" in html
        # Section heading advertises the SQL block.
        assert "SQL executed" in html

    def test_html_says_not_written_when_write_skipped(self, tmp_path):
        """If add_sql_summary fires but write() is never called, the
        HTML should NOT advertise a broken download link."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_sql_summary("report_42", "SELECT 1")
        # No write() call — sql_files is empty.
        html = rr.to_html()
        assert "queries/" not in html
        assert "not written" in html

    def test_safe_filename_handles_slashes_and_spaces(self, tmp_path):
        from steps.file.run_report import FileRunReport, _safe_filename
        assert _safe_filename("normal_id") == "normal_id"
        assert _safe_filename("with spaces") == "with_spaces"
        assert _safe_filename("a/b/c") == "a_b_c"
        assert _safe_filename("") == "unknown"
        assert _safe_filename(None) == "unknown"  # type: ignore[arg-type]
        # And the write path actually uses the safe form.
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_sql_summary("dag/with/slash", "SELECT 1")
        rr.write()
        assert (tmp_path / "queries" / "dag_with_slash.sql").exists()

    def test_idempotent_rewrite(self, tmp_path):
        """Re-running write() reflects the latest SQL — last add wins."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_sql_summary("rep_x", "SELECT 1")
        rr.write()
        rr.add_sql_summary("rep_x", "SELECT 2 FROM updated")
        rr.write()
        assert (tmp_path / "queries" / "rep_x.sql").read_text() == "SELECT 2 FROM updated"


# ─── 2. Starburst -> Oracle steps push SQL to the report ───────────────


class TestOracleStepsFeedReport:
    """When ``task['_run_report']`` is wired, both the Spark and light
    Starburst→Oracle steps push their parameterised SQL into it so the
    Queries section + download link appear in run_report.html."""

    def test_light_oracle_step_source_calls_add_sql_summary(self):
        src = (Path(ETL_ROOT) / "steps" / "oracle" / "light_starburst_base.py").read_text(encoding="utf-8")
        assert 'task.get("_run_report")' in src
        assert "add_sql_summary" in src

    def test_spark_oracle_step_source_calls_add_sql_summary(self):
        src = (Path(ETL_ROOT) / "steps" / "oracle" / "starburst_base.py").read_text(encoding="utf-8")
        assert 'task.get("_run_report")' in src
        assert "add_sql_summary" in src

    def test_oracle_step_feeds_parameterised_query(self):
        """The SQL pushed to the report must be the FINAL parameterised
        SQL (after {BUSINESSDATE}/{SYSTEM_ENTITY} substitution), not
        the raw template — that's what the user actually ran."""
        # Source-level check: the add_sql_summary call must appear AFTER
        # the trino_query parameterisation, otherwise we'd record the
        # un-substituted template.
        for rel in ("steps/oracle/light_starburst_base.py",
                    "steps/oracle/starburst_base.py"):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            param_idx = src.find("trino_query = self._parameterize_query")
            sql_idx = src.find("add_sql_summary")
            assert 0 < param_idx < sql_idx, (
                f"{rel}: add_sql_summary must follow trino_query "
                f"parameterisation so the report records the resolved SQL"
            )


# ─── 3. No hardcoded write paths — every path overridable ─────────────


class TestWritePathsConfigurable:
    """The FileRunReport module must NOT contain string literals like
    ``"queries"`` / ``"run_report.html"`` / ``".sql"`` baked into
    ``write()`` — these come from operator config (polling row first,
    then ``oracle_config.yaml run_report`` block, then defaults).

    Source-level checks lock the contract so a future patch can't
    silently reintroduce a hardcoded write path.
    """

    def test_write_uses_instance_attrs_not_literals(self):
        from pathlib import Path
        src = (Path(ETL_ROOT) / "steps" / "file" / "run_report.py").read_text(encoding="utf-8")
        # write() must reference the instance attrs, not literal strings.
        write_block_start = src.find("def write(")
        write_block_end = src.find("def ", write_block_start + 1)
        write_block = src[write_block_start:write_block_end]
        assert "self.queries_subdir" in write_block
        assert "self.report_filename_html" in write_block
        assert "self.report_filename_txt" in write_block
        assert "self.sql_file_extension" in write_block
        # And the previously-hardcoded literals are no longer inside write().
        assert 'os.path.join(self.output_dir, "queries")' not in write_block
        assert '"run_report.{ext}"' not in write_block
        assert '"run_report.html"' not in write_block.replace(
            '_DEFAULT_REPORT_HTML = "run_report.html"', "")

    def test_custom_queries_subdir_routes_to_overridden_location(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(
            output_dir=str(tmp_path),
            queries_subdir="my_queries",
            sql_file_extension=".trino.sql",
        )
        rr.add_sql_summary("rep_x", "SELECT 1")
        rr.write()
        # Overridden subdir + extension respected.
        custom = tmp_path / "my_queries" / "rep_x.trino.sql"
        assert custom.exists()
        assert custom.read_text() == "SELECT 1"
        # Default subdir NOT created.
        assert not (tmp_path / "queries").exists()

    def test_custom_report_filenames(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(
            output_dir=str(tmp_path),
            report_filename_html="dashboard.html",
            report_filename_txt="summary.txt",
        )
        paths = rr.write()
        assert (tmp_path / "dashboard.html").exists()
        assert (tmp_path / "summary.txt").exists()
        # Defaults NOT used.
        assert not (tmp_path / "run_report.html").exists()
        assert paths == {"html": str(tmp_path / "dashboard.html"),
                         "txt": str(tmp_path / "summary.txt")}

    def test_standalones_thread_polling_row_overrides(self):
        """file_standalone.py + file_to_oracle_standalone.py must read
        the override knobs from the polling row OR oracle_config.yaml,
        not pass empty strings unconditionally."""
        from pathlib import Path
        for rel in ("file_standalone.py", "file_to_oracle_standalone.py"):
            src = (Path(ETL_ROOT) / rel).read_text(encoding="utf-8")
            assert "queries_subdir" in src, (
                f"{rel}: must thread queries_subdir override to FileRunReport"
            )
            # Polling-row source AND yaml fallback must both be consulted.
            assert 'sample.get("queries_subdir")' in src
            assert '_rr_cfg.get("queries_subdir"' in src


class TestReportFilenameDerivation:
    """2026-06-13 -- operator asked for the HTML / TXT report to be
    uniquely named per deliverable so successive runs in the same
    output_dir don't overwrite each other."""

    def test_default_falls_back_when_no_deliverable(self, tmp_path):
        """No output_files + no consolidated_file in context ->
        original run_report.html name is preserved (back-compat).
        2026-06-22: .txt no longer written by default (user request)."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.mark_success()
        rr.write()
        assert (tmp_path / "run_report.html").exists()
        # .txt is OPT-IN now -- not written by default
        assert not (tmp_path / "run_report.txt").exists()

    def test_derives_from_output_files_basename(self, tmp_path):
        """When a deliverable is registered via add_output_file, the
        HTML name derives from its basename (no extension, no
        _CLOUD/_ONPREM marker, with `.report` suffix).
        2026-06-22: .txt no longer written by default."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        # Create the deliverable so os.path.exists() in to_html passes.
        deliverable = tmp_path / "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.dat"
        deliverable.write_text("x" * 100, encoding="utf-8")
        rr.add_output_file(str(deliverable))
        rr.mark_success()
        rr.write()
        # Default-overwriting run_report.html no longer used.
        assert not (tmp_path / "run_report.html").exists()
        expected_html = tmp_path / "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.report.html"
        assert expected_html.exists()
        # .txt opt-in; not written unless report_filename_txt set
        expected_txt = tmp_path / "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.report.txt"
        assert not expected_txt.exists()

    def test_txt_written_when_explicitly_requested(self, tmp_path):
        """Operator can re-enable .txt by passing report_filename_txt."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(
            output_dir=str(tmp_path),
            report_filename_txt="run_report.txt",
        )
        rr.mark_success()
        rr.write()
        assert (tmp_path / "run_report.txt").exists()

    def test_strips_datasource_marker_from_filename(self, tmp_path):
        """Per-source CLOUD/ONPREM markers must be stripped so the
        report name is canonical across CLOUD/ONPREM dispatches."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        deliverable = tmp_path / "report_20251001_CLOUD.dat"
        deliverable.write_text("x", encoding="utf-8")
        rr.add_output_file(str(deliverable))
        rr.mark_success()
        rr.write()
        # _CLOUD stripped -> canonical name.
        assert (tmp_path / "report_20251001.report.html").exists()

    def test_explicit_override_wins_over_derivation(self, tmp_path):
        """If operator pins an explicit filename via the constructor,
        derivation MUST NOT clobber it."""
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(
            output_dir=str(tmp_path),
            report_filename_html="custom_pinned.html",
        )
        deliverable = tmp_path / "report.dat"
        deliverable.write_text("x", encoding="utf-8")
        rr.add_output_file(str(deliverable))
        rr.mark_success()
        rr.write()
        # Explicit override survived.
        assert (tmp_path / "custom_pinned.html").exists()
        # Derived name NOT also written.
        assert not (tmp_path / "report.report.html").exists()


class TestCompletenessLedgerRenders:
    """G1-G5 ledger must surface verdicts at a glance + carry an
    inline explanation of what each gate proves."""

    def test_chips_render_for_each_recorded_gate(self, tmp_path):
        # 2026-06-20 -- user-facing chip labels are "C1"-"C5" (Control 1-5)
        # for consistency with the "Completeness controls" section heading.
        # Internal dict key stays "G1"-"G5" for back-compat with ledger
        # consumers / log lines.
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_counts(
            expected_total=1000,
            sum_partition_expected=1000,
            sum_chunk_actual=1000,
            consolidated_total=1000,
        )
        html_out = rr.to_html()
        # Top-of-page chip for each control (user-facing C1-C5).
        assert "C1: OK" in html_out
        assert "C2: OK" in html_out
        assert "C3: OK" in html_out
        assert "C5: OK" in html_out
        # Control descriptions render inline so operator knows what each
        # control actually proves.
        assert "Source row count" in html_out
        # And internal control key is still "G1"-"G5" via _ledger_entries.
        ledger = rr._ledger_entries()
        assert {e["control"] for e in ledger} >= {"G1", "G2", "G3", "G5"}
        assert {e["display"] for e in ledger} >= {"C1", "C2", "C3", "C5"}

    def test_chip_flips_fail_on_count_mismatch(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_counts(expected_total=1000, consolidated_total=999)
        html_out = rr.to_html()
        # C5 FAIL chip visible at the top (display label).
        assert "C5: FAIL" in html_out
        # Verdict cell shows the delta.
        assert "delta -1" in html_out


class TestInlineFullSql:
    """Operator's workflow has only 1 query per source -- the full SQL
    should be visible inline (not just behind a download link)."""

    def test_full_sql_renders_in_collapsible_details(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        sql = "SELECT *\nFROM hive.silver.fact_summary\nWHERE business_date = '2025-10-01'"
        rr.add_sql_summary("report_31_CLOUD", sql)
        rr.mark_success()
        html_out = rr.to_html()
        assert "<details class='sql-details'>" in html_out
        # Lines + chars in the summary.
        assert "3 lines" in html_out
        # Inline <pre> contains the full SQL (HTML-escaped).
        assert "fact_summary" in html_out


class TestEmailSubject:
    """Email subject must surface the deliverable + record count so the
    operator can triage from the inbox without opening the message."""

    def test_subject_includes_filename_and_record_count(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_context(report_id=31, business_date="2025-09-30", run_id=874750)
        deliverable = tmp_path / "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001.dat"
        deliverable.write_text("x", encoding="utf-8")
        rr.add_output_file(str(deliverable))
        rr.set_counts(expected_total=446902, consolidated_total=446902)
        rr.mark_success()
        # Force-fake the SMTP path to capture the subject.
        # 2026-06-22: added docmd + ehlo mocks for the new diagnostic
        # NOOP + EHLO calls (bug #17 email-send hardening).
        captured = {}
        class _FakeSMTP:
            def __init__(self, *a, **kw): pass
            def __enter__(self): return self
            def __exit__(self, *a): pass
            def docmd(self, *a, **kw): return (250, b"OK")
            def ehlo(self, *a, **kw): return (250, b"fake Hello\nSIZE 52428800")
            def starttls(self): pass
            def login(self, *a): pass
            def send_message(self, msg):
                captured["subject"] = msg["Subject"]
                return {}  # accept-all
        import smtplib
        orig = smtplib.SMTP
        smtplib.SMTP = _FakeSMTP
        try:
            rr.send_email({
                "send_email": True,
                "smtp_host": "fake", "email_from": "a@x", "email_to": "b@y",
            })
        finally:
            smtplib.SMTP = orig
        subj = captured.get("subject", "")
        assert "SUCCESS" in subj
        assert "FLEX_GSIB_FLEXREP_MONTHEND_20250930_20251001" in subj
        assert "446,902 rows" in subj


class TestPartitionByCrossSourceChunks:
    """For partition-by runs with CLOUD + ONPREM, the per-chunk table
    must distinguish sources by a Source column.  Otherwise CLOUD
    partition_index=0 and ONPREM partition_index=0 look identical in
    the run report and the operator can't tell which shard short-wrote
    when G4 fails."""

    def test_chunk_table_renders_source_column(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_chunk_result({
            "job_id": "31", "datasource": "CLOUD",
            "partition_index": 0, "partition_value": "2025-10-01",
            "expected": 1000000, "actual": 1000000,
            "attempts": 1, "duration_sec": 12.3,
            "file_path": "/data/cloud_0.dat",
        })
        rr.add_chunk_result({
            "job_id": "31", "datasource": "ONPREM",
            "partition_index": 0, "partition_value": "2025-10-01",
            "expected": 500, "actual": 500,
            "attempts": 1, "duration_sec": 1.1,
            "file_path": "/data/onprem_0.dat",
        })
        html_out = rr.to_html()
        # Header now has a Source column.
        assert ">Source<" in html_out
        # Both source labels appear in the body.
        assert ">CLOUD<" in html_out
        assert ">ONPREM<" in html_out
        # Both partition_index=0 entries survived (no collision).
        # Crude: the partition_value '2025-10-01' appears twice.
        assert html_out.count("2025-10-01") >= 2

    def test_starburst_steps_thread_datasource_into_chunk_result(self):
        """Both base classes must pass `self.DATASOURCE_NAME` into the
        run_report.add_chunk_result call so the partition table can
        distinguish sources."""
        from steps.file import starburst_file_base, starburst_file_spark_base
        for mod in (starburst_file_base, starburst_file_spark_base):
            src = Path(mod.__file__).read_text(encoding="utf-8")
            # Both must thread datasource into the add_chunk_result dict.
            assert '"datasource": self.DATASOURCE_NAME' in src, (
                f"{mod.__name__}: add_chunk_result must include datasource"
            )


class TestPlainTextEmailBody:
    """Plain-text fallback (for mail clients that block HTML) must
    surface the deliverable + completeness verdicts upfront."""

    def test_text_body_leads_with_records_and_deliverable(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.set_context(report_id=31, business_date="2025-09-30")
        deliverable = tmp_path / "report_20251001.dat"
        deliverable.write_text("x" * 1024, encoding="utf-8")
        rr.add_output_file(str(deliverable))
        rr.set_counts(expected_total=1000, consolidated_total=1000)
        rr.mark_success()
        text = rr.to_text()
        # TL;DR block at top.
        assert "Records delivered: 1,000" in text
        assert "Deliverable:" in text and "report_20251001.dat" in text
        # Completeness verdicts as one line per gate.
        assert "[OK  ] C1" in text
        assert "[OK  ] C5" in text
