"""Phase F (2026-06-08) — ETL iceberg value coercion tests.

Locks down the type-aware filter-value coercion used by the ETL
supplement-pruning path.  Mirrors what backend's
test_iceberg_brain_partition_aware does for the brain, but using
the ETL-local copy (no backend imports).
"""
from __future__ import annotations

import os
import sys
import unittest
from datetime import date, datetime

# Make sure managers/ is importable when running from repo root
_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from managers.iceberg_value_coercion import (
    ICEBERG_TYPES,
    apply_transform_to_value,
    coerce_value,
)


class TestCoerceValue(unittest.TestCase):
    def test_date_iso_string(self):
        self.assertEqual(coerce_value("2025-09-30", "date"), "2025-09-30")

    def test_date_duckdb_cast(self):
        self.assertEqual(
            coerce_value("DATE '2025-09-30'", "date"),
            "2025-09-30",
        )

    def test_date_quoted(self):
        self.assertEqual(coerce_value("'2025-09-30'", "date"), "2025-09-30")

    def test_date_object_input(self):
        self.assertEqual(
            coerce_value(date(2025, 9, 30), "date"),
            "2025-09-30",
        )

    def test_date_invalid_returns_none(self):
        self.assertIsNone(coerce_value("not-a-date", "date"))

    def test_timestamp_pads_time_when_date_only(self):
        self.assertEqual(
            coerce_value("2025-09-30", "timestamp"),
            "2025-09-30 00:00:00",
        )

    def test_timestamp_t_separator_normalised(self):
        self.assertEqual(
            coerce_value("2025-09-30T13:45:00", "timestamp"),
            "2025-09-30 13:45:00",
        )

    def test_timestamp_with_microseconds_passthrough(self):
        # Already in supplement-shape — pass through (validity check
        # accepts ".microseconds" suffix as long as the date+time
        # prefix is parseable).
        self.assertEqual(
            coerce_value("2025-09-30 13:45:00.123456", "timestamp"),
            "2025-09-30 13:45:00.123456",
        )

    def test_int_coerced(self):
        self.assertEqual(coerce_value("12345", "int"), "12345")
        self.assertEqual(coerce_value(12345, "long"), "12345")

    def test_int_with_garbage_returns_none(self):
        self.assertIsNone(coerce_value("ABC", "int"))

    def test_string_passthrough(self):
        self.assertEqual(coerce_value("AAPL", "string"), "AAPL")

    def test_decimal_via_decimal_normalisation(self):
        # Phase H: scale extracted from "decimal(p,s)" and quantize
        # applied so user filter "123.45" matches supplement "123.4500".
        self.assertEqual(coerce_value("123.4500", "decimal(10,4)"), "123.4500")
        self.assertEqual(coerce_value("123.45", "decimal(10,4)"), "123.4500")
        # Bare "decimal" with no scale -- passes through as-is.
        self.assertEqual(coerce_value("123.45", "decimal"), "123.45")
        # Whitespace-tolerant type string
        self.assertEqual(
            coerce_value("123.45", "decimal( 10 , 4 )"), "123.4500")

    def test_decimal_invalid_returns_none(self):
        self.assertIsNone(coerce_value("not-a-decimal", "decimal(10,4)"))

    def test_boolean(self):
        self.assertEqual(coerce_value("true", "boolean"), "True")
        self.assertEqual(coerce_value("False", "boolean"), "False")
        self.assertEqual(coerce_value("1", "bool"), "True")

    def test_partition_transform_day_treated_as_date(self):
        self.assertEqual(
            coerce_value("2025-09-30", "_transform_day"),
            "2025-09-30",
        )

    def test_unknown_type_passes_through(self):
        self.assertEqual(coerce_value("ABC", "some-weird-type"), "ABC")


class TestApplyTransform(unittest.TestCase):
    def test_identity(self):
        self.assertEqual(
            apply_transform_to_value("abc", "string", "identity"),
            "abc",
        )

    def test_day_from_iso_date(self):
        # 2025-09-30 is 20361 days since 1970-01-01
        self.assertEqual(
            apply_transform_to_value("2025-09-30", "date", "day"),
            (date(2025, 9, 30) - date(1970, 1, 1)).days,
        )

    def test_day_from_timestamp_string(self):
        self.assertEqual(
            apply_transform_to_value("2025-09-30 13:45:00", "timestamp", "day"),
            (date(2025, 9, 30) - date(1970, 1, 1)).days,
        )

    def test_month_from_iso(self):
        # Sep 2025 = (2025-1970)*12 + (9-1) = 660 + 8 = 668
        self.assertEqual(
            apply_transform_to_value("2025-09-30", "date", "month"),
            668,
        )

    def test_year_from_iso(self):
        self.assertEqual(
            apply_transform_to_value("2025-09-30", "date", "year"),
            55,
        )

    def test_hour_from_iso(self):
        self.assertEqual(
            apply_transform_to_value(
                "1970-01-01 05:00:00", "timestamp", "hour"),
            5,
        )

    def test_unsupported_transform_returns_none(self):
        # bucket / truncate not yet supported
        self.assertIsNone(
            apply_transform_to_value("abc", "string", "bucket[16]"))
        self.assertIsNone(
            apply_transform_to_value("abc", "string", "truncate[4]"))

    def test_unparseable_value_returns_none(self):
        self.assertIsNone(
            apply_transform_to_value("garbage", "date", "day"))


if __name__ == "__main__":
    unittest.main()
