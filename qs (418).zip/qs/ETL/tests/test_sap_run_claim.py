"""Phase 134-K — Oracle DBMS_LOCK-based run claim (audit SERIOUS #5).

2026-06-03 update — the claim is now consumed by the polling SERVICE
(ETL/polling_service/poller.py), NOT by sap_odata_standalone.py.  The
standalone follows strict oracle_standalone.py parity: Airflow triggers
ONE pod per RUN_ID, so cross-pod safety is not a standalone concern.

Tests in this file cover:
  * try_claim_run on OracleMetadataManager:
      - Acquired (code 0) / re-acquired (code 4) → True
      - Already-locked (code 1) / deadlock (code 2) → False
      - Unexpected code (5+) → False (safe-skip)
      - No DBMS_LOCK grant / Oracle exception → True (fail-open)
      - Empty/zero run_id → True (no-op)
  * sap_odata_standalone.execute_tasks (strict oracle-parity):
      - All steps dispatched in SEQ order on the happy path
      - Step failure breaks remaining steps within the RUN_ID
      - log_file attached to every task in the batch
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


ETL_ROOT = str(Path(__file__).parent.parent)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ── try_claim_run unit tests ────────────────────────────────────────


def _make_manager_with_lock_code(code):
    """BF-597: build an OracleMetadataManager with a mocked pinned
    connection whose ``cursor.var(int).getvalue()`` returns ``code``.

    Mirrors the new try_claim_run path which uses direct
    ``cursor.execute(sql, {...})`` against the manager's pinned
    ``_claim_connection`` — NOT the legacy ``execute_procedure`` call
    that the old test helper mocked.
    """
    from managers.oracle_metadata_manager import OracleMetadataManager
    m = OracleMetadataManager.__new__(OracleMetadataManager)
    m.oracle_db = MagicMock()
    m.logger = MagicMock()
    # Mock the pinned-connection path.
    mock_var = MagicMock()
    mock_var.getvalue = MagicMock(return_value=code)
    mock_cursor = MagicMock()
    mock_cursor.var = MagicMock(return_value=mock_var)
    mock_cursor.execute = MagicMock()
    mock_cursor.close = MagicMock()
    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)
    mock_conn.ping = MagicMock()  # liveness check passes
    # Pre-populate the pinned connection so _get_or_create_claim_connection
    # returns it immediately without trying to open a real Oracle session.
    m._claim_connection = mock_conn
    import threading as _t
    m._claim_connection_lock = _t.Lock()
    return m


def _make_manager_with_lock_error(exc):
    """Build a manager where the pinned-connection lookup itself raises
    (simulates ORA-01031 missing-grant scenarios)."""
    from managers.oracle_metadata_manager import OracleMetadataManager
    m = OracleMetadataManager.__new__(OracleMetadataManager)
    m.oracle_db = MagicMock()
    m.logger = MagicMock()
    m._claim_connection = None
    import threading as _t
    m._claim_connection_lock = _t.Lock()
    # Force _get_or_create_claim_connection to raise.
    m._get_or_create_claim_connection = MagicMock(side_effect=exc)
    return m


class TestTryClaimRun:
    def test_acquired_returns_true(self):
        m = _make_manager_with_lock_code(0)
        result = asyncio.run(m.try_claim_run(42, "host-1234", "conn-str"))
        assert result is True

    def test_already_own_returns_true(self):
        m = _make_manager_with_lock_code(4)
        result = asyncio.run(m.try_claim_run(42, "host-1234", "conn-str"))
        assert result is True

    def test_already_locked_returns_false(self):
        m = _make_manager_with_lock_code(1)
        result = asyncio.run(m.try_claim_run(42, "host-1234", "conn-str"))
        assert result is False

    def test_deadlock_returns_false(self):
        m = _make_manager_with_lock_code(2)
        result = asyncio.run(m.try_claim_run(42, "host-1234", "conn-str"))
        assert result is False

    def test_oracle_exception_fails_open(self):
        """ORA-04068 / ORA-01031 / etc — log + proceed.  Degraded
        behaviour but no worse than pre-Phase-134-K.
        """
        m = _make_manager_with_lock_error(
            Exception("ORA-01031: insufficient privileges")
        )
        result = asyncio.run(m.try_claim_run(42, "h-1", "conn"))
        assert result is True
        # Loud warning so ops see the DBA-config gap.
        m.logger.warning.assert_called()
        msg = str(m.logger.warning.call_args)
        assert "DBMS_LOCK unavailable" in msg

    def test_empty_run_id_returns_true(self):
        """run_id=0/None is a degenerate input.  Don't try to claim,
        proceed."""
        m = _make_manager_with_lock_code(0)
        assert asyncio.run(m.try_claim_run(0, "h", "conn")) is True
        assert asyncio.run(m.try_claim_run(None, "h", "conn")) is True
        # No cursor.execute attempted for empty run_id.
        m._claim_connection.cursor.assert_not_called()

    def test_none_outparam_returns_true(self):
        """BF-597: defensive — if the OUT var somehow returns None
        (e.g. session was killed mid-bind), treat as fail-open."""
        m = _make_manager_with_lock_code(None)
        result = asyncio.run(m.try_claim_run(42, "h", "conn"))
        assert result is True
        m.logger.warning.assert_called()


# ── execute_tasks dispatcher integration ────────────────────────────
#
# 2026-06-03 — Airflow triggers ONE pod per RUN_ID for SAP, mirror of
# oracle_standalone.py.  The standalone's execute_tasks no longer holds
# claim / runs_seen / skipped_runs bookkeeping; the polling SERVICE
# (poller.py) owns cross-pod safety via its own try_claim_run path.
# Tests below verify the strict oracle-parity behaviour of execute_tasks.


class TestExecuteTasksOracleParity:
    def _make_task(self, run_id: int, seq: int, step_name: str) -> dict:
        return {
            "run_id": run_id, "run_detail_id": run_id * 10 + seq,
            "seq": seq, "task_steps": step_name,
            "fk_report_id": "SAP_MEBAL",
        }

    def test_all_steps_dispatched_when_no_failure(self, tmp_path):
        """Single RUN_ID with 5 steps → all 5 dispatched in SEQ order
        (Airflow guarantees one RUN_ID per pod)."""
        from sap_odata_standalone import execute_tasks
        with patch("sap_odata_standalone.OracleMetadataManager") as MockMgr, \
             patch("sap_odata_standalone.SapOdataWorker") as MockWorker:
            MockMgr.return_value = MagicMock()
            worker = MockWorker.return_value
            worker.execute_step = AsyncMock(return_value=None)
            tasks = [self._make_task(1, s, f"Step{s}") for s in range(1, 6)]
            log = str(tmp_path / "log.txt")
            asyncio.run(execute_tasks(
                tasks, {}, "conn", "dest_conn", log,
            ))
            # All 5 steps dispatched in order.
            assert worker.execute_step.call_count == 5
            for idx, call in enumerate(worker.execute_step.call_args_list, 1):
                assert call[0][0]["seq"] == idx

    def test_step_failure_breaks_remaining_steps(self, tmp_path):
        """Fail-fast within RUN_ID using ``raise`` (oracle-parity).
        A failure on Step1 stops Steps 2-5 from dispatching.

        2026-06-21 -- both oracle_standalone.py and sap_odata_standalone
        .py now ``raise`` instead of ``break`` so the
        StandaloneRunLifecycle context manager catches the failure +
        runs cleanup + sends the failure email.  Old ``break`` left the
        run permanently in 'START' state on result.html.  The
        fail-fast guarantee is unchanged (Steps 2-5 still never run);
        the test now asserts the propagated exception explicitly.
        """
        from sap_odata_standalone import execute_tasks
        with patch("sap_odata_standalone.OracleMetadataManager") as MockMgr, \
             patch("sap_odata_standalone.SapOdataWorker") as MockWorker:
            MockMgr.return_value = MagicMock()
            worker = MockWorker.return_value
            call_log: list = []
            async def execute_side_effect(task, *args, **kw):
                call_log.append(task["task_steps"])
                if task["task_steps"] == "Step1":
                    raise RuntimeError("boom")
                return None
            worker.execute_step = AsyncMock(side_effect=execute_side_effect)
            tasks = [self._make_task(1, s, f"Step{s}") for s in range(1, 6)]
            log = str(tmp_path / "log.txt")
            with pytest.raises(RuntimeError, match="boom"):
                asyncio.run(execute_tasks(
                    tasks, {}, "conn", "dest_conn", log,
                ))
            # Only Step1 was attempted; raise halted the loop AND
            # propagated to the caller (so StandaloneRunLifecycle can
            # mark the run failed).
            assert call_log == ["Step1"]

    def test_log_file_attached_to_every_task(self, tmp_path):
        """Every task in the batch must carry the same log_file path —
        matches oracle_standalone.execute_tasks line 137."""
        from sap_odata_standalone import execute_tasks
        with patch("sap_odata_standalone.OracleMetadataManager") as MockMgr, \
             patch("sap_odata_standalone.SapOdataWorker") as MockWorker:
            MockMgr.return_value = MagicMock()
            worker = MockWorker.return_value
            captured: list = []
            async def execute_side_effect(task, *args, **kw):
                captured.append(task.get("log_file"))
                return None
            worker.execute_step = AsyncMock(side_effect=execute_side_effect)
            tasks = [self._make_task(1, s, f"Step{s}") for s in range(1, 4)]
            log = str(tmp_path / "shared.log")
            asyncio.run(execute_tasks(
                tasks, {}, "conn", "dest_conn", log,
            ))
            assert captured == [log, log, log]
