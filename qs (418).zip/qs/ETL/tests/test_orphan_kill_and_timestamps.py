"""Phase 152 orphan-query cleanup + timestamp unification.

Pilot scenario covered:
  * 8-chunk job, network drops mid-run, 2 Trino queries keep running
    on the cluster.  Operator restarts the workflow -> orphan-killer
    finds those 2 queries by client_tags + kills them via
    system.runtime.kill_query BEFORE new chunks dispatch.

Timestamp scenarios covered:
  * result.html started/finished cards use ISO 8601 + UTC shadow
  * File ctime / mtime in Output files section use SAME format
  * Cross-surface consistency: log timestamps + result.html + email
    body all readable in one mental format
"""
from __future__ import annotations

import logging
import os
import sys
import time
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  Trino query tagging (StarburstConnection sets client_tags)
# ──────────────────────────────────────────────────────────────────────


class TestClientTagsPropagation:
    def test_connection_config_carries_client_tags(self):
        """_execute_one_job stamps connection_config with stable tags
        derived from run_id + report_id + business_date + datasource."""
        # Symbolic check: confirm the tag format is what the orphan-killer
        # queries against.  The actual setting happens in _execute_one_job
        # which we'd need a full async run to exercise.
        run_id = 12345
        report_id = 42
        biz = "2026-06-21"
        ds = "CLOUD"
        expected_tags = [
            "qs_etl",
            f"qs_run:{run_id}",
            f"qs_report:{report_id}",
            f"qs_biz:{biz}",
            f"qs_ds:{ds}",
        ]
        # All tags lowercase + colon-delimited so they're greppable.
        assert all(":" in t or t == "qs_etl" for t in expected_tags)
        assert f"qs_run:{run_id}" in expected_tags  # the orphan-killer's anchor


# ──────────────────────────────────────────────────────────────────────
#  Orphan-query killer
# ──────────────────────────────────────────────────────────────────────


class TestOrphanKill:
    def _stub_step(self):
        from steps.file.starburst_file_base import StarburstFileBase
        cls = type("_StubStep", (StarburstFileBase,), {
            "DATASOURCE_NAME": "CLOUD", "LOG_PREFIX": "stub",
        })
        s = cls.__new__(cls)
        s.logger = logging.getLogger("orphan-kill")
        return s

    @pytest.mark.asyncio
    async def test_no_orphans_returns_zero(self):
        step = self._stub_step()

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql): pass
            async def fetch_chunks(self, bs):
                if False:
                    yield None  # pragma: no cover -- empty result

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            killed = await step._kill_orphan_trino_queries(
                connection_config={}, run_id=12345,
            )
        assert killed == 0

    @pytest.mark.asyncio
    async def test_orphans_found_and_killed(self):
        """Mock Trino returns 2 orphan queries -> helper issues 2 kills
        + returns 2."""
        step = self._stub_step()

        executed_sql: list = []

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql):
                executed_sql.append(sql)
            async def fetch_chunks(self, bs):
                # First call (scan) yields 2 orphans; subsequent calls
                # (kill_query) won't iterate fetch_chunks.
                if "system.runtime.queries" in (executed_sql[-1] if executed_sql else ""):
                    yield [
                        ("trino_q_abc123", "RUNNING", "2026-06-21T10:00:00Z", "etl_user"),
                        ("trino_q_def456", "QUEUED",  "2026-06-21T10:01:00Z", "etl_user"),
                    ]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            killed = await step._kill_orphan_trino_queries(
                connection_config={}, run_id=12345,
            )
        assert killed == 2
        # Scan SQL + 2 kill SQLs were issued.
        assert any("system.runtime.queries" in s for s in executed_sql)
        assert any("kill_query" in s and "trino_q_abc123" in s for s in executed_sql)
        assert any("kill_query" in s and "trino_q_def456" in s for s in executed_sql)

    @pytest.mark.asyncio
    async def test_scan_failure_returns_zero_no_crash(self):
        """Trino restricts system.runtime -> scan raises -> helper
        returns 0 without crashing the pipeline."""
        step = self._stub_step()

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql):
                raise PermissionError("access denied to system.runtime.queries")
            async def fetch_chunks(self, bs):
                if False: yield None

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            killed = await step._kill_orphan_trino_queries(
                connection_config={}, run_id=12345,
            )
        assert killed == 0

    @pytest.mark.asyncio
    async def test_kill_failure_per_query_continues_loop(self):
        """If one kill_query raises (e.g. query already completed),
        the loop continues + remaining kills proceed."""
        step = self._stub_step()
        call_count = {"i": 0}

        class _FakeConn:
            def __init__(self, cfg, logger): self.task = None
            async def __aenter__(self): return self
            async def __aexit__(self, *a): return False
            async def execute(self, sql):
                call_count["i"] += 1
                # Scan = call 1; kills = 2 + 3
                if call_count["i"] == 2:
                    raise RuntimeError("query already completed")
                self._last_sql = sql
            async def fetch_chunks(self, bs):
                if call_count["i"] == 1:
                    yield [
                        ("q1", "RUNNING", "2026", "u"),
                        ("q2", "RUNNING", "2026", "u"),
                    ]

        with patch("steps.file.starburst_file_base.StarburstConnection", _FakeConn):
            killed = await step._kill_orphan_trino_queries(
                connection_config={}, run_id=12345,
            )
        # 1 successful kill (call 3), 1 failed (call 2 raised).
        assert killed == 1

    @pytest.mark.asyncio
    async def test_none_run_id_no_op(self):
        step = self._stub_step()
        killed = await step._kill_orphan_trino_queries(
            connection_config={}, run_id=None,
        )
        assert killed == 0


# ──────────────────────────────────────────────────────────────────────
#  Timestamp unification across surfaces
# ──────────────────────────────────────────────────────────────────────


class TestTimestampUnification:
    def test_local_time_uses_iso8601(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        dt = datetime(2026, 6, 21, 10, 0, 0, tzinfo=timezone.utc)
        rendered = rr._local_time(dt)
        # Both local + UTC components are ISO 8601 format.
        assert "T" in rendered  # ISO 8601 separator
        assert "(UTC:" in rendered
        assert "2026-06-21" in rendered
        # UTC component ends with Z marker.
        assert "Z)" in rendered or "Z " in rendered or rendered.rstrip(")").endswith("Z")

    def test_local_time_none_returns_pending(self):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir="/tmp/x")
        assert rr._local_time(None) == "(pending)"

    def test_fmt_ts_helper_matches_local_time_shape(self):
        from steps.file.run_report import FileRunReport
        epoch = 1718966400  # 2024-06-21 10:40:00 UTC
        rendered = FileRunReport._fmt_ts(epoch)
        # Same shape as _local_time output.
        assert "T" in rendered
        assert "(UTC:" in rendered
        assert "2024" in rendered

    def test_fmt_ts_none_returns_dash(self):
        from steps.file.run_report import FileRunReport
        assert FileRunReport._fmt_ts(None) == "-"


# ──────────────────────────────────────────────────────────────────────
#  Output files section shows ctime + mtime
# ──────────────────────────────────────────────────────────────────────


class TestOutputFileTimestamps:
    def test_output_file_shows_ctime_and_mtime(self, tmp_path):
        from steps.file.run_report import FileRunReport
        f = tmp_path / "deliverable.dat"
        f.write_text("col1|col2\nval1|val2\n")
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_output_file(str(f))
        html = rr.to_html()
        assert "deliverable.dat" in html
        assert "created" in html
        assert "modified" in html
        # Format matches _fmt_ts: ISO + UTC shadow.
        assert "(UTC:" in html

    def test_missing_file_renders_missing_marker(self, tmp_path):
        from steps.file.run_report import FileRunReport
        rr = FileRunReport(output_dir=str(tmp_path))
        rr.add_output_file(str(tmp_path / "doesnt_exist.dat"))
        html = rr.to_html()
        assert "(missing)" in html
