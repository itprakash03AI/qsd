"""Phase H (2026-06-08) — deep-dive gap closure tests.

Locks down:
  * Decimal scale quantize on filter coercion (CORRECTNESS)
  * Decimal format leniency (whitespace, case)
  * Pooled connection nukes entire cache on session death (CORRECTNESS)
  * predicates dict copy (no caller mutation)
  * cascade telemetry inline collection (no double O(N))
"""
from __future__ import annotations

import logging
import os
import sys
import unittest
from unittest.mock import MagicMock, patch

_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from managers.iceberg_file_pruner import prune_files
from managers.iceberg_supplement_reader import IcebergSupplementReader
from managers.iceberg_value_coercion import (
    coerce_value,
    decode_iceberg_bound,
)


# ── H.6 — Decimal scale quantize ────────────────────────────────────────


class TestDecimalScaleQuantize(unittest.TestCase):
    """Pre-Phase-H: user filter '123.45' coerced to '123.45' while
    supplement bound for decimal(10,4) was '123.4500'.  String compare
    'val < low' → '123.45' < '123.4500' = True lexicographically →
    file silently excluded.  Post-Phase-H: filter coerces to '123.4500'.
    """

    def test_scale_4_user_short_input(self):
        self.assertEqual(coerce_value("123.45", "decimal(10,4)"), "123.4500")

    def test_scale_4_user_exact_input(self):
        self.assertEqual(coerce_value("123.4500", "decimal(10,4)"), "123.4500")

    def test_scale_4_user_too_many_digits(self):
        # Phase H: scale quantize uses ROUND_HALF_EVEN — extra digits
        # are rounded.  '123.45001' under scale=4 → '123.4500'.
        self.assertEqual(coerce_value("123.45001", "decimal(10,4)"), "123.4500")

    def test_scale_zero(self):
        self.assertEqual(coerce_value("123", "decimal(10,0)"), "123")

    def test_bare_decimal_passthrough(self):
        self.assertEqual(coerce_value("123.45", "decimal"), "123.45")


# ── H.11 — Decimal format leniency ──────────────────────────────────────


class TestDecimalFormatLeniency(unittest.TestCase):
    def test_uppercase_decimal(self):
        # _normalise_type lowercases input -- DECIMAL(10,4) accepted
        self.assertEqual(coerce_value("123.45", "DECIMAL(10,4)"), "123.4500")

    def test_whitespace_inside_parens(self):
        self.assertEqual(
            coerce_value("123.45", "decimal( 10 , 4 )"),
            "123.4500",
        )

    def test_decode_iceberg_bound_with_spaces(self):
        raw = (1234500).to_bytes(8, byteorder="big", signed=True)
        out = decode_iceberg_bound(raw, "decimal( 10 , 4 )")
        self.assertEqual(out, "123.4500")

    def test_decode_iceberg_bound_uppercase(self):
        raw = (42).to_bytes(4, byteorder="big", signed=True)
        out = decode_iceberg_bound(raw, "DECIMAL(10,0)")
        self.assertEqual(out, "42")


# ── H.5 — Pooled connection session death ───────────────────────────────


class TestPoolSessionDeath(unittest.TestCase):
    """When Oracle drops the session mid-query, prior bounds_for cache
    entries were fetched on the now-dead session.  Subsequent queries
    on a fresh session would see fresh bounds but old cache → mixed
    old/new bounds used for pruning → wrong rows.  Phase H: on any
    execute error, nuke the entire reader cache + pooled connection."""

    def test_session_death_clears_entire_cache(self):
        reader = IcebergSupplementReader(
            connection_string="user/pw@dsn",
            bucket="b", table_prefix="t/", snapshot_id="snap-1",
        )
        # Seed cache for col_a (simulating a successful prior fetch
        # on the now-dead session).
        reader._seed_cache("col_a", {
            "f1.parquet": ("A", "C", 0, 100),
        })
        self.assertEqual(len(reader._cache), 1)

        # Stub a connection that raises on execute (session death).
        bad_cur = MagicMock()
        bad_cur.execute.side_effect = RuntimeError("ORA-02396")
        bad_cur.__enter__ = lambda self: bad_cur
        bad_cur.__exit__ = lambda self, *a: False
        bad_conn = MagicMock()
        bad_conn.cursor.return_value = bad_cur
        bad_conn.ping.return_value = True   # ping succeeded (Oracle quirk)

        with patch.object(reader, "_get_conn", return_value=bad_conn):
            out = reader.bounds_for("col_b")

        # bounds_for returned empty AND wiped the entire cache.
        self.assertEqual(out, {})
        self.assertEqual(len(reader._cache), 0)
        # Pooled connection nulled out so the next call rebuilds.
        self.assertIsNone(reader._pooled_conn)


class TestPoolReuseAcrossCalls(unittest.TestCase):
    """Verify pooled connection is SHARED across is_fresh + bounds_for
    (not opened per-call)."""

    def test_one_connect_across_multiple_calls(self):
        reader = IcebergSupplementReader(
            connection_string="user/pw@dsn",
            bucket="b", table_prefix="t/", snapshot_id="snap-1",
        )

        cur = MagicMock()
        cur.fetchone.return_value = (None,)
        cur.__iter__ = lambda self: iter([])
        cur.__enter__ = lambda self: cur
        cur.__exit__ = lambda self, *a: False
        conn = MagicMock()
        conn.cursor.return_value = cur

        connect_calls = [0]

        def _fake_connect(*a, **kw):
            connect_calls[0] += 1
            return conn

        mod = MagicMock()
        mod.connect.side_effect = _fake_connect

        with patch.dict("sys.modules", {"oracledb": mod}):
            reader.is_fresh()
            reader.bounds_for("col_a")
            reader.bounds_for("col_b")
            reader.bounds_for("col_c")
        self.assertEqual(connect_calls[0], 1,
                          "all calls must share ONE oracledb.connect()")


# ── H.13 — Cascade telemetry inline collection ─────────────────────────


class TestCascadeInlineCollection(unittest.TestCase):
    """Phase H replaced the second O(N) cascade pass with inline
    drop-tracking during the main loop.  Verify cascade entries reflect
    ACTUAL dropped files (the first excluding predicate per file),
    not a per-predicate count of total exclusions."""

    def _b(self, lo, hi):
        return (lo, hi, 0, 0)

    def test_cascade_records_first_dropper_only(self):
        files = ["f1", "f2", "f3"]
        manifest_bounds = {
            "date": {
                "f1": self._b("2025-09-30", "2025-09-30"),
                "f2": self._b("2025-10-01", "2025-10-01"),
                "f3": self._b("2025-10-15", "2025-10-15"),
            },
            "code": {
                "f1": self._b("A", "Z"),
                "f2": self._b("A", "Z"),
                "f3": self._b("D", "Z"),
            },
        }
        predicates = {
            "date":  [("=", "2025-09-30")],
            "code": [("=", "A")],
        }
        with self.assertLogs(
                "managers.iceberg_file_pruner", level=logging.INFO) as cap:
            result = prune_files(
                files, manifest_bounds, {}, predicates,
                iceberg_field_types={"date": "date", "code": "string"},
                partition_columns=["date"],
            )
        # f1 keeps (date matches, code overlaps)
        # f2: date drops it
        # f3: date drops it
        self.assertEqual(result, ["f1"])
        log_text = "\n".join(cap.output)
        # Cascade reports the partition filter as the dropper, not code
        self.assertIn("date", log_text)
        self.assertIn("partition_eq", log_text)
        self.assertIn("'dropped': 2", log_text)


if __name__ == "__main__":
    unittest.main()
