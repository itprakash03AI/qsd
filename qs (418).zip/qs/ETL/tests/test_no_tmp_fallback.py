"""Lock the no-/tmp policy for OpenShift deployment (2026-06-12).

OpenShift pods get tiny ephemeral storage; if any runtime code path
silently falls back to ``/tmp`` (via ``tempfile.gettempdir()`` or a
hardcoded path), production logs / sidecars / intermediates would
disappear into ephemeral storage that gets evicted under pressure.

This module asserts source-level that no file-flow / oracle / polling
runtime module imports ``tempfile`` or hardcodes ``/tmp``.  Tests-only
modules are excluded since they legitimately use tmp_path fixtures.
"""
from __future__ import annotations

import ast
import os
import sys
from pathlib import Path

import pytest


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


def _runtime_module_paths():
    """Yield every Python module that runs in production (steps,
    workers, polling_service, managers, standalones).  Excludes:
      * tests/
      * __pycache__
      * the legacy reference compress file (kept in tree per user
        direction, marked for deletion)
    """
    root = Path(ETL_ROOT)
    runtime_dirs = [
        root / "steps" / "file",
        root / "steps" / "oracle",
        root / "steps" / "sap",
        root / "polling_service",
        root / "workers",
        root / "managers",
    ]
    for d in runtime_dirs:
        if not d.is_dir():
            continue
        for p in d.rglob("*.py"):
            if "__pycache__" in p.parts:
                continue
            if p.name == "refer_compresfile.py":
                continue
            yield p
    # Standalones at repo root.
    for name in ("file_standalone.py", "file_to_oracle_standalone.py",
                 "oracle_standalone.py", "sap_odata_standalone.py",
                 "s3_query_standalone.py"):
        p = root / name
        if p.exists():
            yield p


# ─── 1. No tempfile import in runtime code ──────────────────────────────


class TestNoTempfileInRuntime:
    def test_no_runtime_module_imports_tempfile(self):
        """``tempfile`` import in a runtime module signals a silent
        ``/tmp`` write path -- forbidden on OpenShift."""
        offenders = []
        for p in _runtime_module_paths():
            src = p.read_text(encoding="utf-8")
            try:
                tree = ast.parse(src)
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for n in node.names:
                        if n.name == "tempfile":
                            offenders.append((str(p.relative_to(ETL_ROOT)), node.lineno))
                elif isinstance(node, ast.ImportFrom) and node.module == "tempfile":
                    offenders.append((str(p.relative_to(ETL_ROOT)), node.lineno))
        assert not offenders, (
            f"Runtime modules import tempfile (silent /tmp fallback): "
            f"{offenders}.  Remove the import and route through "
            f"log_config.get_log_dir() instead."
        )


# ─── 2. No hardcoded /tmp string in runtime CODE (comments OK) ──────────


class TestNoHardcodedTmp:
    def test_no_runtime_code_writes_to_slash_tmp(self):
        """A hardcoded ``/tmp`` STRING in runtime code (outside a
        comment) is forbidden.  Walk the AST and inspect string
        literals only -- comments are stripped by the parser, so this
        check naturally ignores the rationale comments left after the
        2026-06-12 removal."""
        offenders = []
        for p in _runtime_module_paths():
            src = p.read_text(encoding="utf-8")
            try:
                tree = ast.parse(src)
            except SyntaxError:
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    v = node.value
                    # Skip module/class docstrings — those are also
                    # ast.Constant but they appear as the first stmt of
                    # the body.  Easier: just check for /tmp/ as a path
                    # fragment vs documentation.  We allow the substring
                    # '/tmp' only when it's part of a longer doc-like
                    # string (so 'silently writing to /tmp.' style
                    # warnings pass).  An exact path like '/tmp/foo' or
                    # '/tmp' standalone fails.
                    if v == "/tmp" or v.startswith("/tmp/"):
                        offenders.append((str(p.relative_to(ETL_ROOT)),
                                          node.lineno, v[:80]))
        assert not offenders, (
            f"Runtime modules contain a hardcoded /tmp path literal: "
            f"{offenders}"
        )


# ─── 3. _setup_logging routes through log_config.get_log_dir() ─────────


class TestSetupLoggingRoutes:
    """Every file-flow step that defines ``_setup_logging`` MUST resolve
    its log path via ``log_config.get_log_dir()`` when the task didn't
    pin one — never via ``tempfile`` or a hardcoded path."""

    @pytest.fixture(scope="class")
    def file_flow_step_modules(self):
        root = Path(ETL_ROOT) / "steps" / "file"
        out = []
        for p in root.glob("*.py"):
            if p.name in ("__init__.py", "run_state.py", "run_report.py",
                          "refer_compresfile.py"):
                continue
            src = p.read_text(encoding="utf-8")
            if "_setup_logging" in src and "task.get(\"log_file\")" in src:
                out.append(p)
        return out

    def test_steps_route_through_log_config(self, file_flow_step_modules):
        assert file_flow_step_modules, "expected at least one step with _setup_logging"
        for p in file_flow_step_modules:
            src = p.read_text(encoding="utf-8")
            assert "from log_config import get_log_dir as _ld" in src, (
                f"{p.name}: must import log_config.get_log_dir in _setup_logging"
            )
            # And the previously-hardcoded silent tempfile path must
            # NOT be reachable.
            assert "tempfile.gettempdir()" not in src, (
                f"{p.name}: silent tempfile.gettempdir() fallback remains"
            )
