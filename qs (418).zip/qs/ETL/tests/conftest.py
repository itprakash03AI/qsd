"""Shared pytest setup for the ETL test tree.

Some ETL managers import production-only drivers (``oracledb`` for
the Oracle metadata manager; ``starbur`` clients, etc.) that aren't
in the test virtualenv.  We stub the bare-minimum surface in
``sys.modules`` BEFORE the test files import the manager so the
test env doesn't need real DB drivers.

Imports here run once per test session — kept lightweight + side-
effect-free except for the sys.modules registrations.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock


# Ensure ETL/ root is on sys.path so test modules can ``import log_config``
# / ``import workers.X`` / ``import managers.Y`` etc.  Equivalent to the
# CWD-on-sys.path behaviour the standalones rely on at runtime.
_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# Stub ``oracledb`` if not installed.  Only registered when the real
# package is absent, so production runs use the real driver.
try:
    import oracledb  # noqa: F401
except ImportError:
    _stub = MagicMock()
    # Common attributes the manager touches at import time.
    _stub.Error = Exception
    _stub.DatabaseError = Exception
    _stub.IntegrityError = Exception
    _stub.OperationalError = Exception
    sys.modules["oracledb"] = _stub


# Stub managers.oracledblib — the production wrapper imports
# pydantic.BaseSettings which moved out of core pydantic in v2.  The
# tests don't exercise the wrapper itself; we just need the module to
# import so OracleMetadataManager can be loaded.
try:
    from managers.oracledblib import OracleDBLib  # noqa: F401
except Exception:
    import types
    _stub_mod = types.ModuleType("managers.oracledblib")

    class _StubOracleDBLib:  # minimal surface used by the manager
        def __init__(self, *args, **kwargs):
            self.connection_string = kwargs.get("connection_string", "")

        def execute_query(self, *args, **kwargs):
            return None

        def execute_procedure(self, *args, **kwargs):
            return {}

    _stub_mod.OracleDBLib = _StubOracleDBLib
    sys.modules["managers.oracledblib"] = _stub_mod


# Stub ``pyspark`` when not installed.  Spark-based step modules
# (s3_base_step, s3_query_base, …) import ``from pyspark.sql import
# SparkSession`` at module top — only the import has to succeed for
# the unit tests to load the step classes; we never actually build a
# SparkSession in tests.
try:
    import pyspark  # noqa: F401
except ImportError:
    import types
    _pyspark = types.ModuleType("pyspark")
    _pyspark_sql = types.ModuleType("pyspark.sql")
    _pyspark_sql.SparkSession = MagicMock()
    _pyspark_sql.functions = types.ModuleType("pyspark.sql.functions")
    _pyspark_sql_window = types.ModuleType("pyspark.sql.window")
    _pyspark_sql_window.Window = MagicMock()
    sys.modules["pyspark"] = _pyspark
    sys.modules["pyspark.sql"] = _pyspark_sql
    sys.modules["pyspark.sql.functions"] = _pyspark_sql.functions
    sys.modules["pyspark.sql.window"] = _pyspark_sql_window
