"""Phase 134-K — audit SERIOUS #4 regression guard.

The pre-Phase-134-K Airflow DAG rendered SAP_USERNAME / SAP_PASSWORD
into the KubernetesPodOperator's ``env_vars`` argument via Jinja:

    env_vars = {
        "SAP_USERNAME": "{{ var.value.sap_username }}",
        "SAP_PASSWORD": "{{ var.value.sap_password }}",
    }

Airflow renders these at scheduler time and bakes the plaintext into
the K8s pod spec YAML — visible to anyone with namespace read.

The fix: source creds from a K8s Secret via the ``secrets=[...]``
arg of KubernetesPodOperator.  This file locks the change with text
assertions over the DAG source (Airflow isn't installed in the test
env, so a runtime DAG-import test isn't viable here; the source-grep
catches reintroduction of the bad pattern).
"""
from __future__ import annotations

from pathlib import Path

import pytest


DAG_FILE = (
    Path(__file__).parent.parent / "airflow_dag" / "sap_mebal_dag.py"
)


@pytest.fixture(scope="module")
def dag_src() -> str:
    return DAG_FILE.read_text(encoding="utf-8")


class TestNoLegacyCredEnvVars:
    """The exact rendered-credential strings that landed in pod specs
    pre-fix.  If anyone reintroduces them, this test catches it."""

    def test_no_jinja_sap_password_in_env_vars(self, dag_src):
        assert "{{ var.value.sap_password }}" not in dag_src, (
            "Reintroduced plaintext SAP_PASSWORD Jinja rendering — "
            "this bakes creds into the pod spec YAML"
        )

    def test_no_jinja_sap_username_in_env_vars(self, dag_src):
        # var.value.sap_username on its own is fine if it's in an
        # arguments arg, but it must NEVER land in env_vars.  Grep
        # for the literal env-key pair shape we used to render.
        assert '"SAP_USERNAME":' not in dag_src or (
            "{{ var.value.sap_username }}" not in dag_src
        ), (
            "env_vars still includes a Jinja-rendered SAP_USERNAME — "
            "switch to Secret(deploy_type='env', ...) instead."
        )


class TestSecretWiring:
    """The fix MUST use the KubernetesPodOperator's secrets= argument
    so creds flow from kubectl-protected storage, not the pod spec."""

    def test_imports_secret_class(self, dag_src):
        assert (
            "from airflow.providers.cncf.kubernetes.secret import Secret"
            in dag_src
        ), "Secret import missing — the K8s Secret mount needs it"

    def test_uses_secrets_argument(self, dag_src):
        assert "secrets=secrets" in dag_src, (
            "KubernetesPodOperator must receive the secrets= argument "
            "for the K8s Secret env mount"
        )

    def test_secret_targets_sap_username_and_password(self, dag_src):
        """Both env-var targets must be wired."""
        assert 'deploy_target="SAP_USERNAME"' in dag_src
        assert 'deploy_target="SAP_PASSWORD"' in dag_src
        # And they MUST be deploy_type="env" (not "volume") so they
        # land in the pod's env at runtime from the K8s API.
        assert dag_src.count('deploy_type="env"') >= 2


class TestSecretNameVariableLookup:
    """The Secret name comes from an Airflow Variable so ops can rotate
    it without code changes."""

    def test_variable_lookup_for_secret_name(self, dag_src):
        assert 'Variable.get(' in dag_src
        assert 'sap_mebal_secret_name' in dag_src

    def test_missing_secret_name_logs_warning_not_raises(self, dag_src):
        """Audit fix: missing config must NOT raise at parse time
        (would break every Airflow DAG scan).  Log warning + let the
        pod fail at runtime (without creds the SAP call will 401).
        """
        assert "logger.warning(" in dag_src, (
            "missing-secret path must log+defer, not raise at parse time"
        )
        # No raise ValueError(... sap_mebal_secret_name ...) — that
        # would kill the scheduler scan.
        bad_pattern = "raise ValueError(\n                \"Legacy"
        assert bad_pattern not in dag_src, (
            "missing-secret raises at parse time — would break DAG scan"
        )


class TestPollingRowDrivenCreds:
    """2026-06-03 — strict oracle_standalone parity.  SAP creds come
    from the polling row's SAPU/SAPP columns.  The Airflow DAG must
    pass ZERO cred env_vars; the optional K8s Secret mount is a
    fallback for rows that leave SAPU/SAPP NULL."""

    def test_no_env_vars_for_creds(self, dag_src):
        """env_vars dict must never carry SAP credentials."""
        # The init "env_vars: dict = {}" line is fine.  Anything that
        # mutates env_vars["SAP_*"] is the bug we're guarding against.
        assert 'env_vars["SAP_USERNAME"]'  not in dag_src
        assert "env_vars['SAP_USERNAME']"  not in dag_src
        assert 'env_vars["SAP_PASSWORD"]'  not in dag_src
        assert "env_vars['SAP_PASSWORD']"  not in dag_src

    def test_polling_row_documented_as_primary_path(self, dag_src):
        """Comment block must call out that SAPU/SAPP on the row are
        the primary credential source so future maintainers don't
        re-introduce env_vars."""
        assert "polling-row SAPU/SAPP" in dag_src or (
            "polling row's SAPU/SAPP" in dag_src
        ), "DAG must document SAPU/SAPP-on-row as the primary path"

    def test_no_legacy_cli_flags(self, dag_src):
        """The standalone no longer accepts --task_id / --period_mode
        / --num_groups / --qs_db_url.  DAG must not pass them."""
        for legacy in ("--task_id", "--period_mode", "--num_groups",
                       "--qs_db_url"):
            assert legacy not in dag_src, (
                f"DAG still passes legacy flag {legacy!r} to the "
                f"standalone — 2026-06-03 refactor removed it."
            )

    def test_passes_three_polling_binds(self, dag_src):
        """DAG MUST pass --report_id + --business_date + --dag_id —
        the three polling-query binds — to the standalone."""
        for arg in ("--report_id", "--business_date", "--dag_id"):
            assert arg in dag_src, (
                f"DAG missing {arg!r} — polling query needs it as "
                f"a bind variable"
            )
