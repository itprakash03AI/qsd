"""ETL AWS credential resolver -- mirrors QS API credential_resolver contract.

Tests the 5 auth modes (keys / env / iam_role / profile / assume_role)
plus the field-name bridging between ETL legacy s3_* fields and the
AWS standard aws_* fields.

Resolver MUST:
  * never mutate input
  * always return a config with BOTH legacy + standard field names
  * never raise; on failure return config unchanged + log WARN
  * preserve auth_mode='keys' on the output once resolved (so downstream
    callers know creds are now embedded)
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
#  auth_mode = "keys" (and default back-compat)
# ──────────────────────────────────────────────────────────────────────


class TestAuthModeKeys:
    def test_legacy_keys_pass_through(self):
        from aws_credentials import resolve_s3_credentials
        out = resolve_s3_credentials({
            "s3_access_key": "AKIA_TEST",
            "s3_secret_key": "secret_test",
            "auth_mode": "keys",
        })
        assert out["s3_access_key"] == "AKIA_TEST"
        assert out["aws_access_key_id"] == "AKIA_TEST"   # bridged
        assert out["aws_secret_access_key"] == "secret_test"
        assert out["auth_mode"] == "keys"

    def test_no_auth_mode_with_keys_still_passes_through(self):
        """Back-compat: pre-Phase-152 configs have no auth_mode field."""
        from aws_credentials import resolve_s3_credentials
        out = resolve_s3_credentials({
            "s3_access_key": "AKIA",
            "s3_secret_key": "secret",
        })
        assert out["aws_access_key_id"] == "AKIA"
        assert out["auth_mode"] == "keys"

    def test_does_not_mutate_input(self):
        from aws_credentials import resolve_s3_credentials
        cfg = {"s3_access_key": "K", "s3_secret_key": "S", "auth_mode": "keys"}
        original = dict(cfg)
        _ = resolve_s3_credentials(cfg)
        assert cfg == original


# ──────────────────────────────────────────────────────────────────────
#  auth_mode = "env" (read from pod env)
# ──────────────────────────────────────────────────────────────────────


class TestAuthModeEnv:
    def test_env_creds_resolved(self):
        from aws_credentials import resolve_s3_credentials
        env_patch = {
            "AWS_ACCESS_KEY_ID": "AKIA_FROM_ENV",
            "AWS_SECRET_ACCESS_KEY": "secret_from_env",
            "AWS_SESSION_TOKEN": "token_from_env",
        }
        with patch.dict(os.environ, env_patch, clear=False):
            out = resolve_s3_credentials({"auth_mode": "env"})
        assert out["aws_access_key_id"] == "AKIA_FROM_ENV"
        assert out["aws_secret_access_key"] == "secret_from_env"
        assert out["aws_session_token"] == "token_from_env"
        # Legacy fields also populated.
        assert out["s3_access_key"] == "AKIA_FROM_ENV"
        assert out["auth_mode"] == "keys"  # downgraded after resolution

    def test_env_missing_returns_empty_creds_with_warning(self):
        from aws_credentials import resolve_s3_credentials
        # Clear AWS env vars
        env_clear = {"AWS_ACCESS_KEY_ID": "", "AWS_SECRET_ACCESS_KEY": ""}
        with patch.dict(os.environ, env_clear, clear=False):
            out = resolve_s3_credentials({"auth_mode": "env"})
        # No crash; empty creds returned (Spark will fail at use time).
        assert out["aws_access_key_id"] == ""
        assert out["aws_secret_access_key"] == ""

    def test_env_token_optional(self):
        from aws_credentials import resolve_s3_credentials
        env = {
            "AWS_ACCESS_KEY_ID": "AKIA",
            "AWS_SECRET_ACCESS_KEY": "secret",
        }
        with patch.dict(os.environ, env, clear=False), \
             patch.dict(os.environ, {"AWS_SESSION_TOKEN": ""}, clear=False):
            out = resolve_s3_credentials({"auth_mode": "env"})
        assert out["aws_access_key_id"] == "AKIA"
        assert out["aws_session_token"] == ""


# ──────────────────────────────────────────────────────────────────────
#  auth_mode = "iam_role" (boto3 default chain)
# ──────────────────────────────────────────────────────────────────────


class TestAuthModeIamRole:
    def test_iam_role_uses_boto3_session(self):
        from aws_credentials import resolve_s3_credentials
        fake_creds = MagicMock()
        fake_frozen = MagicMock(
            access_key="AKIA_IAM",
            secret_key="secret_iam",
            token="token_iam",
        )
        fake_creds.get_frozen_credentials.return_value = fake_frozen
        fake_session = MagicMock()
        fake_session.get_credentials.return_value = fake_creds
        with patch("boto3.Session", return_value=fake_session):
            out = resolve_s3_credentials({"auth_mode": "iam_role"})
        assert out["aws_access_key_id"] == "AKIA_IAM"
        assert out["aws_secret_access_key"] == "secret_iam"
        assert out["aws_session_token"] == "token_iam"
        assert out["auth_mode"] == "keys"

    def test_iam_role_failure_returns_config_with_warning(self):
        """boto3 failure (no IRSA / no instance profile / network issue)
        must NOT crash the planner."""
        from aws_credentials import resolve_s3_credentials
        with patch("boto3.Session", side_effect=Exception("no creds")):
            out = resolve_s3_credentials({"auth_mode": "iam_role"})
        # Returns config unchanged; Spark fails at use site.
        assert out.get("auth_mode") == "iam_role"  # unchanged on failure

    def test_iam_role_no_creds_returned_raises_internally(self):
        from aws_credentials import resolve_s3_credentials
        fake_session = MagicMock()
        fake_session.get_credentials.return_value = None  # boto3 found nothing
        with patch("boto3.Session", return_value=fake_session):
            out = resolve_s3_credentials({"auth_mode": "iam_role"})
        # Caught internally + WARN; returns config unchanged.
        assert "aws_access_key_id" not in out or not out["aws_access_key_id"]


# ──────────────────────────────────────────────────────────────────────
#  auth_mode = "profile"
# ──────────────────────────────────────────────────────────────────────


class TestAuthModeProfile:
    def test_profile_sessions_with_named_profile(self):
        from aws_credentials import resolve_s3_credentials
        fake_creds = MagicMock()
        fake_creds.get_frozen_credentials.return_value = MagicMock(
            access_key="AKIA_PROF", secret_key="sk", token=None,
        )
        fake_session = MagicMock()
        fake_session.get_credentials.return_value = fake_creds
        with patch("boto3.Session", return_value=fake_session) as mock_sess:
            out = resolve_s3_credentials({
                "auth_mode": "profile",
                "aws_profile": "etl-prod",
            })
        # Session called with profile_name.
        _, kw = mock_sess.call_args
        assert kw["profile_name"] == "etl-prod"
        assert out["aws_access_key_id"] == "AKIA_PROF"


# ──────────────────────────────────────────────────────────────────────
#  auth_mode = "assume_role"
# ──────────────────────────────────────────────────────────────────────


class TestAuthModeAssumeRole:
    def test_assume_role_calls_sts(self):
        from aws_credentials import resolve_s3_credentials
        fake_sts = MagicMock()
        fake_sts.assume_role.return_value = {
            "Credentials": {
                "AccessKeyId": "AKIA_STS",
                "SecretAccessKey": "secret_sts",
                "SessionToken": "token_sts",
                "Expiration": "2026-06-20T13:00:00Z",
            }
        }
        fake_session = MagicMock()
        fake_session.client.return_value = fake_sts
        with patch("boto3.Session", return_value=fake_session):
            out = resolve_s3_credentials({
                "auth_mode": "assume_role",
                "role_arn": "arn:aws:iam::1234:role/etl",
            })
        assert out["aws_access_key_id"] == "AKIA_STS"
        assert out["aws_session_token"] == "token_sts"
        assert out["auth_mode"] == "keys"

    def test_assume_role_missing_arn_handled(self):
        from aws_credentials import resolve_s3_credentials
        # Missing role_arn -- helper raises ValueError internally, caught.
        out = resolve_s3_credentials({"auth_mode": "assume_role"})
        # No crash; config returned as-is.
        assert out["auth_mode"] == "assume_role"


# ──────────────────────────────────────────────────────────────────────
#  Field bridging (ETL legacy <-> AWS standard)
# ──────────────────────────────────────────────────────────────────────


class TestFieldBridging:
    def test_endpoint_url_bridged(self):
        from aws_credentials import resolve_s3_credentials
        out = resolve_s3_credentials({
            "s3_access_key": "K", "s3_secret_key": "S",
            "s3_endpoint_url": "https://ecs.corp.local",
            "s3_path_style_access": True,
        })
        assert out["endpoint_url"] == "https://ecs.corp.local"
        assert out["path_style"] is True

    def test_path_style_false_bridged(self):
        from aws_credentials import resolve_s3_credentials
        out = resolve_s3_credentials({
            "s3_access_key": "K", "s3_secret_key": "S",
            "s3_path_style_access": False,
        })
        assert out["path_style"] is False


# ──────────────────────────────────────────────────────────────────────
#  Fallback to default chain when no auth_mode + no keys
# ──────────────────────────────────────────────────────────────────────


class TestDefaultFallback:
    def test_empty_config_attempts_default_chain(self):
        """No auth_mode, no keys -> resolver tries boto3 default chain as
        last resort.  On EKS this picks up IRSA automatically."""
        from aws_credentials import resolve_s3_credentials
        fake_creds = MagicMock()
        fake_creds.get_frozen_credentials.return_value = MagicMock(
            access_key="AKIA_DEFAULT", secret_key="sk", token=None,
        )
        fake_session = MagicMock()
        fake_session.get_credentials.return_value = fake_creds
        with patch("boto3.Session", return_value=fake_session):
            out = resolve_s3_credentials({})
        assert out["aws_access_key_id"] == "AKIA_DEFAULT"

    def test_empty_config_default_chain_failure_returns_empty(self):
        from aws_credentials import resolve_s3_credentials
        with patch("boto3.Session", side_effect=Exception("nothing")):
            out = resolve_s3_credentials({})
        # No crash; empty creds returned.
        assert out.get("aws_access_key_id", "") == ""


# ──────────────────────────────────────────────────────────────────────
#  SMTP env-var fallback (Phase 152 helm support)
# ──────────────────────────────────────────────────────────────────────


class TestSmtpEnvFallback:
    """build_email_config resolution: env < yaml < polling row."""

    def test_env_vars_populate_config(self):
        from standalone_lifecycle import build_email_config
        env = {
            "SMTP_HOST": "smtp.env.local",
            "SMTP_PORT": "587",
            "EMAIL_FROM": "env@from",
            "EMAIL_TO": "env@to",
            "SMTP_PASSWORD": "envpass",
            "SEND_EMAIL": "true",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = build_email_config({}, {})
        assert cfg["smtp_host"] == "smtp.env.local"
        assert cfg["smtp_port"] == "587"
        assert cfg["email_from"] == "env@from"
        assert cfg["smtp_password"] == "envpass"
        assert cfg["send_email"] == "true"

    def test_qs_default_prefix_also_accepted(self):
        """Helm chart writes BOTH plain SMTP_HOST and QS_DEFAULT_SMTP_HOST;
        either should propagate."""
        from standalone_lifecycle import build_email_config
        # Set ONLY the QS_DEFAULT_ prefixed form.
        env = {
            "QS_DEFAULT_SMTP_HOST": "smtp.qs.local",
            "QS_DEFAULT_EMAIL_FROM": "qs@from",
            # Ensure the plain forms are NOT inherited from outer env.
            "SMTP_HOST": "",
            "EMAIL_FROM": "",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = build_email_config({}, {})
        assert cfg["smtp_host"] == "smtp.qs.local"
        assert cfg["email_from"] == "qs@from"

    def test_yaml_overrides_env(self):
        from standalone_lifecycle import build_email_config
        env = {"SMTP_HOST": "smtp.env.local", "EMAIL_FROM": "env@from"}
        yaml_config = {
            "email": {"smtp_host": "smtp.yaml.local", "email_from": "yaml@from"}
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = build_email_config(yaml_config, {})
        assert cfg["smtp_host"] == "smtp.yaml.local"
        assert cfg["email_from"] == "yaml@from"

    def test_polling_row_overrides_yaml_and_env(self):
        from standalone_lifecycle import build_email_config
        env = {"SMTP_HOST": "smtp.env.local"}
        yaml_config = {"email": {"smtp_host": "smtp.yaml.local"}}
        polling_row = {"SMTP_HOST": "smtp.polling.local"}
        with patch.dict(os.environ, env, clear=False):
            cfg = build_email_config(yaml_config, polling_row)
        assert cfg["smtp_host"] == "smtp.polling.local"

    def test_send_email_master_flag_from_env(self):
        from standalone_lifecycle import build_email_config
        env = {"QS_DEFAULT_SEND_EMAIL": "true"}
        with patch.dict(os.environ, env, clear=False):
            cfg = build_email_config({}, {})
        assert cfg["send_email"] == "true"


# ──────────────────────────────────────────────────────────────────────
#  S3A wiring -- _configure_s3a calls the resolver
# ──────────────────────────────────────────────────────────────────────


class TestS3AWiringWithResolver:
    """Verify s3_base_step._configure_s3a routes through aws_credentials
    so IRSA / env / assume_role auth modes all reach Spark cleanly."""

    def test_resolver_invoked_with_iam_role_auth_mode(self):
        """When auth_mode='iam_role', _configure_s3a should call the
        resolver and use whatever creds it returned."""
        from steps.s3 import s3_base_step

        # Build a fake step with the _configure_s3a method.
        class _Stub(s3_base_step.S3BaseStep):
            LOG_PREFIX = "stub"
            def _execute_step(self, *a, **kw): return None
        import logging
        stub = _Stub.__new__(_Stub)
        stub.logger = logging.getLogger("test")

        # Mock the resolver to return a known config.
        with patch("aws_credentials.resolve_s3_credentials") as mock_resolve:
            mock_resolve.return_value = {
                "aws_access_key_id": "AKIA_RESOLVED",
                "aws_secret_access_key": "sk_resolved",
                "aws_session_token": "token_resolved",
                "auth_mode": "keys",
            }
            builder = MagicMock()
            builder.config.return_value = builder
            result = stub._configure_s3a(builder, {"auth_mode": "iam_role"})
        # Resolver was called.
        mock_resolve.assert_called_once()
        # Builder got the resolved creds AND the session-token provider.
        calls = [c.args for c in builder.config.call_args_list]
        flat = [a for c in calls for a in c]
        assert "spark.hadoop.fs.s3a.access.key" in flat
        assert "AKIA_RESOLVED" in flat
        assert "spark.hadoop.fs.s3a.session.token" in flat
        # TemporaryAWSCredentialsProvider configured for STS-issued creds.
        assert any(
            "TemporaryAWSCredentialsProvider" in str(c) for c in calls
        )

    def test_no_creds_falls_back_to_hadoop_default_chain(self):
        """When resolver returns empty creds, _configure_s3a doesn't set
        access.key -- lets Hadoop's default credential chain handle it."""
        from steps.s3 import s3_base_step

        class _Stub(s3_base_step.S3BaseStep):
            LOG_PREFIX = "stub"
            def _execute_step(self, *a, **kw): return None
        import logging
        stub = _Stub.__new__(_Stub)
        stub.logger = logging.getLogger("test")

        with patch("aws_credentials.resolve_s3_credentials") as mock_resolve:
            mock_resolve.return_value = {
                "aws_access_key_id": "",
                "aws_secret_access_key": "",
                "auth_mode": "iam_role",
            }
            builder = MagicMock()
            builder.config.return_value = builder
            stub._configure_s3a(builder, {"auth_mode": "iam_role"})
        # access.key NOT set explicitly -- let Hadoop chain pick.
        calls = [c.args for c in builder.config.call_args_list]
        flat = [a for c in calls for a in c]
        assert "spark.hadoop.fs.s3a.access.key" not in flat
