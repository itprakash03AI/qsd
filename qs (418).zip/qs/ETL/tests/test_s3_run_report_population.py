"""Phase 152 s3_query workflow result.html population.

Pre-2026-06-20 the s3_query pipeline (workflow D in HOW_TO doc) had a
``StandaloneRunLifecycle`` wrapper but the s3 step classes themselves
never populated FileRunReport.  Result: result.html rendered empty for
S3 jobs.

This file pins the new behaviour: every shared S3QueryBase helper
(_read_iceberg_with_query, _read_parquet_with_query, _write_to_file)
populates the FileRunReport hanging on task["_run_report"]:

  * SQL surfaced via add_sql_summary -> shown in HTML report
  * Per-source row count via add_job_result + set_counts ->
    drives C1 / C3 / C5 chips
  * Output file registered with RunArtifacts -> cleanup_on_failure
    wipes it on later step failure
  * Output file added to run_report.output_files -> result.html
    "Output files" section lists it

The s3 helpers do this without leaf steps having to call hooks
themselves -- the contract is: drop a FileRunReport on task[
"_run_report"] and it gets populated automatically through the
shared read/write methods.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


def _bare_s3_base():
    """Build a bare S3QueryBase subclass with hooks reachable but no
    Spark dependency.  Subclass provides a stub _execute_step so the
    abstract-method check passes."""
    from steps.s3.s3_query_base import S3QueryBase
    import logging
    cls = type("_StubS3Step", (S3QueryBase,), {
        "_execute_step": lambda self, *a, **kw: None,
    })
    inst = cls.__new__(cls)
    inst.logger = logging.getLogger("test-s3")
    return inst


def _fresh_run_report(tmp_path):
    from steps.file.run_report import FileRunReport
    return FileRunReport(output_dir=str(tmp_path), logger=None)


def _fresh_artifacts():
    from steps.file.run_state import RunArtifacts
    return RunArtifacts()


# ──────────────────────────────────────────────────────────────────────


class TestS3SourceQueryRecorded:
    """The SQL the engine ran should appear in the run report's SQL
    summary so operators can see it (with download link) in result.html."""

    def test_sql_summary_populated(self, tmp_path):
        rr = _fresh_run_report(tmp_path)
        task = {"_run_report": rr, "fk_report_id": 42}
        s = _bare_s3_base()
        s._record_source_query(task, "SELECT * FROM source", 42)
        assert "42" in rr.sql_summary
        assert "SELECT" in rr.sql_summary["42"]
        assert rr.sql_full["42"] == "SELECT * FROM source"

    def test_no_run_report_no_crash(self):
        s = _bare_s3_base()
        # No _run_report on task -> recorder should silently no-op.
        s._record_source_query({}, "SELECT 1", 42)


class TestS3ExtractCountsRecorded:
    """Per-source row count + per-source consolidated count populated so
    C1 (source count), C3 (download), C5 (consolidated) all anchor on
    the SAME number -- Spark already proved the conservation invariant
    via DataFrame semantics, so we set them identically."""

    def test_counts_populate_ledger(self, tmp_path):
        rr = _fresh_run_report(tmp_path)
        task = {"_run_report": rr, "fk_report_id": 42}
        s = _bare_s3_base()
        s._record_extract_counts(
            task, report_id=42, datasource="ICEBERG", rows=1_234_567,
            output_path=str(tmp_path / "out.csv"),
        )
        ledger = rr._ledger_entries()
        controls = {e["control"]: e for e in ledger}
        assert controls["G1"]["detail"].startswith("1,234,567")
        assert controls["G3"]["ok"] is True
        assert controls["G5"]["ok"] is True

    def test_job_result_carries_consolidated_fields(self, tmp_path):
        rr = _fresh_run_report(tmp_path)
        task = {"_run_report": rr, "fk_report_id": 99}
        s = _bare_s3_base()
        s._record_extract_counts(
            task, report_id=99, datasource="PARQUET", rows=500,
            output_path="/tmp/out.parquet",
        )
        assert len(rr.job_results) == 1
        jr = rr.job_results[0]
        assert jr["report_id"] == 99
        assert jr["datasource"] == "PARQUET"
        assert jr["records"] == 500
        assert jr["expected_total"] == 500
        assert jr["consolidated_rows"] == 500
        assert jr["consolidated_file"] == "/tmp/out.parquet"

    def test_no_run_report_no_crash(self):
        s = _bare_s3_base()
        s._record_extract_counts({}, 1, "X", 100, "")


class TestS3OutputArtifactRegistered:
    """The written file should be tracked by RunArtifacts so
    cleanup_on_failure wipes it AND added to result.html's
    'Output files' list."""

    def test_registers_with_artifacts_and_run_report(self, tmp_path):
        rr = _fresh_run_report(tmp_path)
        artifacts = _fresh_artifacts()
        task = {"_run_report": rr, "_run_artifacts": artifacts}
        s = _bare_s3_base()
        out_file = str(tmp_path / "result.csv")
        s._register_output_artifact(task, out_file)
        assert out_file in [
            p.lower() if False else os.path.abspath(p)
            for p in artifacts.list()
        ] or os.path.abspath(out_file) in artifacts.list()
        assert out_file in rr.output_files

    def test_custom_category_supported(self, tmp_path):
        from steps.file.run_state import RunArtifacts
        artifacts = _fresh_artifacts()
        task = {"_run_artifacts": artifacts}
        s = _bare_s3_base()
        out_file = str(tmp_path / "result.gz")
        s._register_output_artifact(task, out_file, category=RunArtifacts.COMPRESSED)
        # File is in COMPRESSED category
        assert os.path.abspath(out_file) in artifacts.list(RunArtifacts.COMPRESSED)

    def test_no_artifacts_no_crash(self, tmp_path):
        rr = _fresh_run_report(tmp_path)
        task = {"_run_report": rr}
        s = _bare_s3_base()
        s._register_output_artifact(task, "/tmp/x.csv")
        assert "/tmp/x.csv" in rr.output_files


class TestCrossEngineSourcePlaceholder:
    """The {SOURCE} placeholder resolved inside _parameterize_query
    produces the temp view name in s3 path, not the catalog FQN."""

    def test_parameterize_query_substitutes_source(self):
        s = _bare_s3_base()
        # _parameterize_query needs SOURCE_VIEW_NAME -- set explicit
        s.SOURCE_VIEW_NAME = "source"
        out = s._parameterize_query(
            "SELECT * FROM {SOURCE} WHERE biz_date = '{BUSINESSDATE}'",
            {"business_date": "2025-06-19"},
        )
        assert "FROM source" in out
        assert "2025-06-19" in out
        assert "{SOURCE}" not in out
        assert "{BUSINESSDATE}" not in out

    def test_custom_source_view_name(self):
        s = _bare_s3_base()
        s.SOURCE_VIEW_NAME = "iceberg_source"
        out = s._parameterize_query(
            "SELECT * FROM {SOURCE}",
            {},
        )
        assert "FROM iceberg_source" in out

    def test_no_source_placeholder_pass_through(self):
        s = _bare_s3_base()
        s.SOURCE_VIEW_NAME = "source"
        out = s._parameterize_query(
            "SELECT a FROM source WHERE x = 1",
            {},
        )
        assert out == "SELECT a FROM source WHERE x = 1"
