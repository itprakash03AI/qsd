"""Tests for the multi-workflow background service (2026-06-12, revised).

Design under test:
  * Single bg_polling_query (no per-workflow SQL).
  * BackgroundService owns the ONE poll loop and routes each RUN_ID to
    the right WorkflowRunner via _infer_dag_type.
  * WorkflowRunner is a per-workflow capacity gate + dispatcher (no
    own loop, no own polling query).
"""
from __future__ import annotations

import asyncio
import os
import sys
import textwrap
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
import yaml


ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)


# ─── helpers ───────────────────────────────────────────────────────────


def _make_workflow(name: str, **overrides):
    """Build a WorkflowConfig with sensible defaults for unit tests."""
    from polling_service.config import WorkflowConfig

    base = dict(
        name=name,
        enabled=True,
        max_concurrent_runs=2,
        max_run_seconds=30,
    )
    base.update(overrides)
    return WorkflowConfig(**base)


def _make_task_row(run_id: int, seq: int = 1, step: str = "CheckDependencies",
                   otg_dag_id: str = "createJob_x"):
    return {
        "run_id": run_id,
        "run_detail_id": 1000 + run_id,
        "seq": seq,
        "task_steps": step,
        "otg_dag_id": otg_dag_id,
        "fk_dag_id": "DAG_X",
        "fk_report_id": 42,
        "business_date": "2026-06-12",
    }


# ─── 1. WorkflowConfig parsing ─────────────────────────────────────────


class TestWorkflowConfigParsing:
    def test_workflows_section_parsed_into_dataclass_list(self, tmp_path):
        from polling_service.config import load_config

        queries = tmp_path / "queries.yaml"
        queries.write_text(textwrap.dedent("""
            bg_polling_query: |
              SELECT 1 FROM DUAL WHERE ROWNUM <= :row_limit
        """))

        cfg_file = tmp_path / "cfg.yaml"
        cfg_file.write_text(textwrap.dedent(f"""
            polling:
              interval_seconds: 30
              max_concurrent_runs: 5
              worker_id: test_pod
              workflows:
                - name: sap_odata
                  enabled: true
                  max_concurrent_runs: 2
                - name: createJob
                  enabled: true
                  max_concurrent_runs: 4
            oracle:
              queries_path: {queries.as_posix()}
            logging:
              dir: {(tmp_path / "logs").as_posix()}
              level: INFO
        """))

        cfg = load_config(str(cfg_file))
        assert len(cfg.workflows) == 2
        sap, cj = cfg.workflows
        assert sap.name == "sap_odata"
        assert sap.max_concurrent_runs == 2
        assert cj.name == "createJob"
        assert cj.max_concurrent_runs == 4

    def test_workflow_inherits_service_max_run_seconds_when_zero(self, tmp_path):
        from polling_service.config import load_config

        queries = tmp_path / "queries.yaml"
        queries.write_text("bg_polling_query: |\n  SELECT 1 FROM DUAL\n")
        cfg_file = tmp_path / "cfg.yaml"
        cfg_file.write_text(textwrap.dedent(f"""
            polling:
              max_run_seconds: 5400
              workflows:
                - name: createJob
                  enabled: true
            oracle:
              queries_path: {queries.as_posix()}
        """))
        cfg = load_config(str(cfg_file))
        assert cfg.workflows[0].max_run_seconds == 5400  # inherited

    def test_empty_workflows_uses_legacy_single_loop_path(self, tmp_path):
        from polling_service.config import load_config

        queries = tmp_path / "queries.yaml"
        queries.write_text("bg_polling_query: |\n  SELECT 1 FROM DUAL\n")

        cfg_file = tmp_path / "cfg.yaml"
        cfg_file.write_text(textwrap.dedent(f"""
            polling:
              interval_seconds: 30
            oracle:
              queries_path: {queries.as_posix()}
        """))
        cfg = load_config(str(cfg_file))
        assert cfg.workflows == []


# ─── 2. WorkflowRunner.try_dispatch ────────────────────────────────────


class TestTryDispatch:
    @pytest.mark.asyncio
    async def test_dispatches_when_slot_available(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob")
        oracle_mgr = MagicMock()
        oracle_mgr.try_claim_run = AsyncMock(return_value=True)
        dispatcher = MagicMock()
        async def _slow(*a, **kw):
            await asyncio.sleep(0.05)
        dispatcher.execute = AsyncMock(side_effect=_slow)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        outcome = await runner.try_dispatch(
            7, [_make_task_row(7)], "host:1", "x",
        )
        assert outcome == "dispatched"
        assert runner.stats["dispatched"] == 1
        assert 7 in runner.active_runs
        await asyncio.gather(*runner.active_runs.values(), return_exceptions=True)

    @pytest.mark.asyncio
    async def test_at_capacity_skipped(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob", max_concurrent_runs=1)
        oracle_mgr = MagicMock()
        oracle_mgr.try_claim_run = AsyncMock(return_value=True)
        dispatcher = MagicMock()
        async def _slow(*a, **kw):
            await asyncio.sleep(0.2)
        dispatcher.execute = AsyncMock(side_effect=_slow)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        assert await runner.try_dispatch(1, [_make_task_row(1)], "h", "x") == "dispatched"
        assert await runner.try_dispatch(2, [_make_task_row(2)], "h", "x") == "at_capacity"
        assert runner.stats["skipped_at_capacity"] == 1
        await asyncio.gather(*runner.active_runs.values(), return_exceptions=True)

    @pytest.mark.asyncio
    async def test_cross_pod_skip(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("sap_odata")
        oracle_mgr = MagicMock()
        oracle_mgr.try_claim_run = AsyncMock(return_value=False)
        dispatcher = MagicMock()
        dispatcher.execute = AsyncMock()

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        outcome = await runner.try_dispatch(99, [_make_task_row(99)], "h", "x")
        assert outcome == "cross_pod"
        assert runner.stats["skipped_cross_pod"] == 1
        assert runner.active_runs == {}
        dispatcher.execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_already_active_skipped(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob")
        oracle_mgr = MagicMock()
        oracle_mgr.try_claim_run = AsyncMock(return_value=True)
        dispatcher = MagicMock()
        async def _slow(*a, **kw):
            await asyncio.sleep(0.1)
        dispatcher.execute = AsyncMock(side_effect=_slow)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        await runner.try_dispatch(5, [_make_task_row(5)], "h", "x")
        outcome = await runner.try_dispatch(5, [_make_task_row(5)], "h", "x")
        assert outcome == "already_active"
        # Cross-pod claim should NOT have been called the second time.
        assert oracle_mgr.try_claim_run.call_count == 1
        await asyncio.gather(*runner.active_runs.values(), return_exceptions=True)

    @pytest.mark.asyncio
    async def test_paused_runner_refuses_dispatch(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob")
        oracle_mgr = MagicMock()
        oracle_mgr.try_claim_run = AsyncMock(return_value=True)
        dispatcher = MagicMock()
        dispatcher.execute = AsyncMock()

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        runner.pause()
        outcome = await runner.try_dispatch(11, [_make_task_row(11)], "h", "x")
        assert outcome == "paused"
        assert runner.active_runs == {}
        oracle_mgr.try_claim_run.assert_not_called()

    @pytest.mark.asyncio
    async def test_timeout_flips_status_and_counts(self):
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob", max_run_seconds=1)
        oracle_mgr = MagicMock()
        oracle_mgr.update_otg_etl_batch_status = AsyncMock()
        dispatcher = MagicMock()
        async def _hang(*a, **kw):
            await asyncio.sleep(5)
        dispatcher.execute = AsyncMock(side_effect=_hang)

        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        await runner._execute_run(42, [_make_task_row(42)])
        assert runner.stats["timed_out"] == 1
        oracle_mgr.update_otg_etl_batch_status.assert_called_once()


# ─── 3. BackgroundService poll + route ─────────────────────────────────


class TestBackgroundServicePolling:
    def _build_service(self, rows, *, workflows=None,
                       claim_result=True, shutdown_timeout=2):
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService

        wf_list = workflows if workflows is not None else [
            _make_workflow("createJob"),
            _make_workflow("sap_odata"),
            _make_workflow("file"),
        ]
        cfg = PollingServiceConfig(
            etl_connection_string="user/pw@dsn",
            dest_connection_string="user/pw@dsn",
            workflows=wf_list,
            bg_polling_sql="SELECT * FROM Vw_otg_dag_task",
            interval_seconds=30,
            shutdown_timeout_seconds=shutdown_timeout,
            polling_query_limit_multiplier=20,
        )
        oracle_mgr = MagicMock()
        oracle_mgr.get_all_start_tasks = AsyncMock(return_value=rows)
        oracle_mgr.try_claim_run = AsyncMock(return_value=claim_result)
        import logging
        svc = BackgroundService(cfg, oracle_mgr, logging.getLogger("test"))
        return svc, oracle_mgr

    @pytest.mark.asyncio
    async def test_poll_once_routes_by_inferred_dag_type(self):
        """A SAP row goes to sap_odata, a createJob row to createJob, etc."""
        rows = [
            _make_task_row(1, otg_dag_id="SAP_MEBAL"),
            _make_task_row(2, otg_dag_id="createJob_x"),
            _make_task_row(3, otg_dag_id="FILE_SOD_RUNNER"),
        ]
        svc, _ = self._build_service(rows)
        # Inject slow dispatchers so we can observe active_runs per runner.
        for r in svc.runners:
            async def _slow(*a, **kw):
                await asyncio.sleep(0.05)
            r.dispatcher.execute = AsyncMock(side_effect=_slow)
        await svc._poll_once()
        sap = svc.find_runner("sap_odata")
        cj = svc.find_runner("createJob")
        file_r = svc.find_runner("file")
        assert 1 in sap.active_runs, "SAP row not routed to sap_odata"
        assert 2 in cj.active_runs, "createJob row not routed to createJob"
        assert 3 in file_r.active_runs, "FILE row not routed to file"
        await asyncio.gather(
            *sap.active_runs.values(), *cj.active_runs.values(),
            *file_r.active_runs.values(), return_exceptions=True,
        )

    @pytest.mark.asyncio
    async def test_poll_once_unrouted_when_no_matching_runner(self):
        """Row whose dag_type has no enabled runner increments
        service.stats['unrouted'] — locks the requirement that ops
        sees a clear signal instead of silent drop."""
        rows = [_make_task_row(7, otg_dag_id="S3_QUERY_RUNNER")]
        svc, _ = self._build_service(rows, workflows=[
            _make_workflow("createJob"),
            # s3_query intentionally NOT in this service.
        ])
        await svc._poll_once()
        assert svc.stats["unrouted"] == 1

    @pytest.mark.asyncio
    async def test_concurrent_runners_have_independent_slot_pools(self):
        """A SAP backlog filling its max_concurrent_runs must NOT
        prevent createJob rows from being dispatched.  This is THE
        guarantee the multi-runner design provides."""
        rows = [
            _make_task_row(1, otg_dag_id="SAP_X"),
            _make_task_row(2, otg_dag_id="SAP_Y"),
            _make_task_row(3, otg_dag_id="createJob_z"),
        ]
        svc, _ = self._build_service(rows, workflows=[
            _make_workflow("sap_odata", max_concurrent_runs=1),
            _make_workflow("createJob", max_concurrent_runs=1),
        ])
        for r in svc.runners:
            async def _slow(*a, **kw):
                await asyncio.sleep(0.2)
            r.dispatcher.execute = AsyncMock(side_effect=_slow)
        await svc._poll_once()
        sap = svc.find_runner("sap_odata")
        cj = svc.find_runner("createJob")
        # SAP at capacity (1 dispatched, 1 at_capacity); createJob fine.
        assert len(sap.active_runs) == 1
        assert len(cj.active_runs) == 1
        assert sap.stats["skipped_at_capacity"] == 1
        assert cj.stats["skipped_at_capacity"] == 0
        await asyncio.gather(
            *sap.active_runs.values(), *cj.active_runs.values(),
            return_exceptions=True,
        )

    @pytest.mark.asyncio
    async def test_poll_loop_uses_service_interval(self):
        """The polling loop uses service-level interval_seconds — there
        is no per-workflow interval."""
        svc, _ = self._build_service([])
        assert svc.config.interval_seconds == 30
        # Start, briefly run, then stop.
        await svc.start()
        await asyncio.sleep(0.05)
        svc.stop()
        await svc.shutdown()

    @pytest.mark.asyncio
    async def test_paused_service_skips_poll_cycles(self):
        rows = [_make_task_row(1, otg_dag_id="createJob_x")]
        svc, oracle_mgr = self._build_service(rows)
        svc.paused = True
        # Manually invoke _poll_loop body once via _poll_once would
        # bypass the paused check; verify the loop check via run.
        await svc.start()
        await asyncio.sleep(0.05)
        # During the brief run, oracle_mgr.get_all_start_tasks should
        # NOT have been called because paused gated the poll.
        oracle_mgr.get_all_start_tasks.assert_not_called()
        svc.stop()
        await svc.shutdown()


# ─── 4. BackgroundService lifecycle / shutdown ─────────────────────────


class TestServiceLifecycle:
    def _service(self, **overrides):
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService

        cfg = PollingServiceConfig(
            etl_connection_string="x",
            dest_connection_string="y",
            workflows=[_make_workflow("createJob")],
            bg_polling_sql="SELECT 1 FROM DUAL",
            interval_seconds=30,
            shutdown_timeout_seconds=overrides.get("shutdown_timeout", 2),
        )
        oracle_mgr = MagicMock()
        oracle_mgr.get_all_start_tasks = AsyncMock(return_value=[])
        oracle_mgr.try_claim_run = AsyncMock(return_value=True)
        import logging
        return BackgroundService(cfg, oracle_mgr, logging.getLogger("test")), oracle_mgr

    @pytest.mark.asyncio
    async def test_shutdown_drains_in_flight_before_cancel(self):
        svc, _ = self._service()
        await svc.start()
        finished = asyncio.Event()
        async def _ok():
            await asyncio.sleep(0.3)
            finished.set()
        runner = svc.runners[0]
        runner.active_runs[99] = asyncio.create_task(_ok())

        svc.stop()
        await svc.shutdown()
        assert finished.is_set(), "in-flight run was cancelled before its drain window"

    @pytest.mark.asyncio
    async def test_shutdown_cancels_stragglers_after_timeout(self):
        svc, _ = self._service(shutdown_timeout=1)
        await svc.start()
        async def _hang():
            await asyncio.sleep(60)
        runner = svc.runners[0]
        runner.active_runs[7] = asyncio.create_task(_hang())

        svc.stop()
        await svc.shutdown()
        assert runner.active_runs[7].cancelled() or runner.active_runs[7].done()

    @pytest.mark.asyncio
    async def test_wait_for_stop_returns_after_stop(self):
        svc, _ = self._service()
        await svc.start()
        async def _stop_soon():
            await asyncio.sleep(0.05)
            svc.stop()
        asyncio.create_task(_stop_soon())
        t0 = asyncio.get_event_loop().time()
        await asyncio.wait_for(svc.wait_for_stop(), timeout=2.0)
        elapsed = asyncio.get_event_loop().time() - t0
        assert elapsed < 0.5
        await svc.shutdown()

    @pytest.mark.asyncio
    async def test_idempotent_start_and_shutdown(self):
        svc, _ = self._service()
        await svc.start()
        await svc.start()  # no double-spawn
        assert svc._poll_task is not None  # single poll task
        svc.stop()
        svc.stop()  # no crash
        await svc.shutdown()
        await svc.shutdown()  # no crash

    @pytest.mark.asyncio
    async def test_poll_loop_crash_is_logged_loudly(self, caplog):
        """If _poll_loop dies unexpectedly the done_callback must log
        ERROR — the loop's death blinds the whole service."""
        svc, _ = self._service()
        import logging
        caplog.set_level(logging.ERROR, logger="test")

        # Replace _poll_loop with one that crashes immediately.
        async def _bomb():
            raise RuntimeError("poll loop boom")
        svc._poll_loop = _bomb
        await svc.start()
        for _ in range(50):
            await asyncio.sleep(0.02)
            if any("Poll loop CRASHED" in r.message for r in caplog.records):
                break
        assert any("Poll loop CRASHED" in r.message for r in caplog.records), (
            "poll-loop crash must be surfaced via done_callback ERROR"
        )
        svc.stop()
        await svc.shutdown()


# ─── 5. Single-query contract / OG DB stays agnostic ───────────────────


class TestSingleQueryContract:
    """Lock the single-query + Python-routing design."""

    def test_per_workflow_polling_queries_have_been_removed(self):
        """The bg_polling_query_<wf> keys MUST NOT come back to the
        queries YAML — that would re-introduce the discriminator drift."""
        path = Path(ETL_ROOT) / "configs" / "etl_polling_task_query.yaml"
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
        forbidden = [k for k in doc if k.startswith("bg_polling_query_")]
        assert not forbidden, (
            f"per-workflow polling queries reintroduced: {forbidden}. "
            f"Single bg_polling_query + _infer_dag_type routing is the contract."
        )

    def test_bg_polling_query_covers_sap_columns(self):
        """Single query must carry every column the SAP step reads."""
        path = Path(ETL_ROOT) / "configs" / "etl_polling_task_query.yaml"
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
        sql = doc["bg_polling_query"]
        for col in ("SAP_ME_BALANCE_API", "SAP_COMPANY_API", "SAPU", "SAPP",
                    "P_GJAHR", "P_POPER", "RUN_TIMESTAMP",
                    "PAGE_SIZE", "CODES_PER_GROUP", "RATE_LIMIT_RPS"):
            assert col in sql, f"bg_polling_query missing SAP column {col!r}"

    def test_bg_polling_query_has_row_limit_bind(self):
        path = Path(ETL_ROOT) / "configs" / "etl_polling_task_query.yaml"
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert ":row_limit" in doc["bg_polling_query"]

    def test_bg_polling_query_passes_task_type_through(self):
        """OG DB must stay agnostic of lightweight typing.  The shared
        query SELECTs TASK_TYPE AS Task_steps unmodified — no
        CASE WHEN / CONCAT('Light', ...) that puts lightweight
        knowledge into the SQL."""
        path = Path(ETL_ROOT) / "configs" / "etl_polling_task_query.yaml"
        sql = yaml.safe_load(path.read_text(encoding="utf-8"))["bg_polling_query"]
        assert "TASK_TYPE AS Task_steps" in sql
        assert "Light" not in sql, (
            "bg_polling_query references 'Light' — OG DB must stay agnostic "
            "of Spark vs non-Spark step variants"
        )

    def test_workflow_config_has_no_polling_fields(self):
        """WorkflowConfig must NOT carry polling_query_key, polling_sql,
        interval_seconds, polling_query_limit_multiplier, or
        use_lightweight_steps.  All polling decisions are service-level."""
        from polling_service.config import WorkflowConfig
        wf = WorkflowConfig()
        for field in ("polling_query_key", "polling_sql", "interval_seconds",
                      "polling_query_limit_multiplier", "use_lightweight_steps"):
            assert not hasattr(wf, field), (
                f"WorkflowConfig regressed and now carries {field!r} again — "
                f"polling decisions must stay at the service level"
            )

    def test_polling_yaml_has_no_per_workflow_polling_lines(self):
        cfg_path = Path(ETL_ROOT) / "configs" / "polling_service_config.yaml"
        raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        for wf in raw.get("polling", {}).get("workflows", []) or []:
            for forbidden in ("polling_query_key", "interval_seconds",
                              "polling_query_limit_multiplier",
                              "use_lightweight_steps"):
                assert forbidden not in wf, (
                    f"polling.workflows[{wf.get('name')!r}] has {forbidden!r} "
                    f"— polling is service-level now"
                )

    def test_routing_uses_canonical_infer_dag_type(self):
        """BackgroundService routes via polling_service.poller._infer_dag_type
        — the canonical OTG_DAG_ID -> workflow mapping.  Locking this
        prevents future divergence."""
        from polling_service import service as svc_mod
        from polling_service.poller import _infer_dag_type
        assert svc_mod._infer_dag_type is _infer_dag_type


# ─── 6. Health API multi-mode shape ────────────────────────────────────


class TestHealthApiMultiMode:
    @pytest.mark.asyncio
    async def test_status_reports_workflows_list_when_service_wired(self):
        from polling_service import health as health_mod
        from polling_service.workflow_runner import WorkflowRunner
        import logging

        wf = _make_workflow("createJob")
        oracle_mgr = MagicMock()
        dispatcher = MagicMock()
        runner = WorkflowRunner(
            workflow=wf, etl_connection_string="x", dest_connection_string="y",
            oracle_manager=oracle_mgr, dispatcher=dispatcher,
            logger=logging.getLogger("test"),
        )
        service_stub = MagicMock()
        service_stub.runners = [runner]
        service_stub.total_active_runs.return_value = 0
        service_stub.all_active_run_ids.return_value = []
        service_stub.paused = False
        service_stub.config.worker_id = "test_pod"
        service_stub.aggregate_stats.return_value = {
            "polls": 1, "dispatched": 0, "completed": 0,
            "failed": 0, "skipped_cross_pod": 0, "timed_out": 0,
            "skipped_at_capacity": 0, "unrouted": 0,
        }
        service_stub.workflow_snapshots.return_value = [runner.snapshot()]

        health_mod.init_health_service(service_stub, oracle_mgr, "dsn")
        resp = await health_mod.status()
        import json as _json
        body = _json.loads(resp.body)
        assert body["mode"] == "multi"
        assert any(w["name"] == "createJob" for w in body["workflows"])
