"""Shared Oracle credential loader.

2026-06-12 — same pattern as ``starburst_config_loader``:
ONE shared config file is the fallback for both the polling-service
metadata DB connection AND the per-job destination Oracle (used by
``light_starburst_base`` / ``starburst_base`` for Starburst→Oracle
ingest).

Resolution order (per-job destination Oracle credentials):
  1. Per-job JSON (``oracle_url`` / ``oracle_user`` / ``oracle_password``)
  2. Shared ``configs/oracle_config.yaml`` -> ``oracle.dest_connection_string``
  3. ``DEST_ORACLE_CONN`` environment variable (already honoured by
     ``polling_service.config.load_config``)

The connection-string format is the existing one used by the
standalones: ``user/password@host:port/service``.  ``parse_dest_dsn``
splits it into the three fields the per-job JSON uses
(``oracle_url`` / ``oracle_user`` / ``oracle_password``) so the per-job
JSON can drop those keys and inherit them from the shared file.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


_PROD_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_LOCAL_PATH = str(
    Path(__file__).resolve().parent / "configs" / "oracle_config.yaml"
)

_logger = logging.getLogger("oracle_config_loader")


def _load_yaml() -> Dict[str, Any]:
    for path in (_PROD_PATH, _LOCAL_PATH):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except yaml.YAMLError as exc:
                _logger.warning(
                    "oracle_config.yaml at %s is malformed (%s) — "
                    "ignoring file, falling back to DEST_ORACLE_CONN env var.",
                    path, exc,
                )
                return {}
            except OSError as exc:
                _logger.warning(
                    "Cannot read oracle_config.yaml at %s (%s) — "
                    "falling back to env vars.", path, exc,
                )
                return {}
    return {}


@lru_cache(maxsize=1)
def load_shared_oracle_config() -> Dict[str, Any]:
    """Cached parse of the ``oracle`` top-level section."""
    return _load_yaml().get("oracle", {}) or {}


def reset_cache() -> None:
    """Drop the cached parse (test hook)."""
    load_shared_oracle_config.cache_clear()


def parse_dest_dsn(dsn: str) -> Dict[str, str]:
    """Parse a ``user/password@host:port/service`` connection string
    into the three fields the per-job JSON consumes.

    Returns ``{"oracle_user", "oracle_password", "oracle_url"}``.
    The URL is built as ``jdbc:oracle:thin:@host:port/service``
    (the canonical form the existing JDBC + python-oracledb consumers
    accept).  Returns empty strings on any parse failure — the caller's
    missing-field check then fires with a clear message.
    """
    out = {"oracle_user": "", "oracle_password": "", "oracle_url": ""}
    if not dsn:
        return out
    try:
        user, rest = dsn.split("/", 1)
        password, dsn_part = rest.split("@", 1)
        url = f"jdbc:oracle:thin:@{dsn_part}"
        out["oracle_user"] = user.strip()
        out["oracle_password"] = password.strip()
        out["oracle_url"] = url.strip()
    except ValueError:
        _logger.warning(
            "oracle dest connection string %r is not in the expected "
            "'user/password@host:port/service' format — leaving fields empty",
            dsn,
        )
    return out


def shared_dest_oracle_creds() -> Dict[str, str]:
    """Resolve destination Oracle credentials from the shared config.

    Returns ``{"oracle_user", "oracle_password", "oracle_url"}`` — keys
    match the per-job JSON fields exactly so the caller can do a
    setdefault-style merge.

    Resolution:
      1. ``oracle.dest_connection_string`` in oracle_config.yaml
      2. ``oracle.destination.secret_ref`` (vault) via qs_credentials
      3. ``DEST_ORACLE_CONN`` env var

    2026-06-22 -- vault layer added.  When yaml has
    ``destination.secret_ref`` set, fetch (user, password, tns_alias)
    from vault.  oracle_url comes from ``destination.url`` (yaml) or
    is built from tns_alias when present.
    """
    cfg = load_shared_oracle_config()

    # Layer 1: explicit DSN
    dsn = cfg.get("dest_connection_string") or ""
    if dsn:
        return parse_dest_dsn(str(dsn).strip())

    # Layer 2: vault via secret_ref + destination.url
    dest = cfg.get("destination", {}) or {}
    secret_ref = (dest.get("secret_ref") or "").strip()
    if secret_ref:
        try:
            from qs_credentials import resolve_db_account_with_tns
            # Pass the oracle top-level dict so per-workflow
            # ``vault_enabled`` flag is honoured.  In this function
            # ``cfg`` IS the oracle dict (from load_shared_oracle_config).
            user, password, tns_alias = resolve_db_account_with_tns(
                secret_ref, workflow_config=cfg,
            )
            url = dest.get("url") or ""
            if not url and tns_alias:
                url = f"jdbc:oracle:thin:@{tns_alias}"
            if user and password and url:
                return {
                    "oracle_user":     str(user),
                    "oracle_password": str(password),
                    "oracle_url":      str(url),
                }
        except (ImportError, RuntimeError, ValueError) as exc:
            _logger.warning(
                "Oracle dest: vault resolution for secret_ref=%r failed "
                "(%s) -- falling back to env var.", secret_ref, exc,
            )

    # Layer 3: env-var fallback
    dsn = os.environ.get("DEST_ORACLE_CONN") or ""
    return parse_dest_dsn(str(dsn).strip())


def shared_etl_oracle_creds() -> Dict[str, str]:
    """Resolve ETL metadata Oracle DB credentials (the polling-task DB
    every standalone + polling service writes run_id status to).

    Returns ``{"oracle_user", "oracle_password", "oracle_url"}``.

    Resolution order (highest priority wins):
      1. ``oracle.etl_connection_string`` literal DSN in oracle_config.yaml
      2. ``oracle.etl.secret_ref`` (vault) + ``oracle.etl.url`` (2026-06-22)
      3. ``ETL_ORACLE_CONN`` env var

    Mirror of shared_dest_oracle_creds for the ETL metadata DB so
    every workflow's run_id writes can also flow through Vault.
    """
    cfg = load_shared_oracle_config()

    # Layer 1: literal DSN
    dsn = cfg.get("etl_connection_string") or ""
    if dsn:
        return parse_dest_dsn(str(dsn).strip())

    # Layer 2: vault via secret_ref + etl.url
    etl = cfg.get("etl", {}) or {}
    secret_ref = (etl.get("secret_ref") or "").strip()
    if secret_ref:
        try:
            from qs_credentials import resolve_db_account_with_tns
            # Pass the oracle top-level dict so per-workflow
            # ``vault_enabled`` flag is honoured.  In this function
            # ``cfg`` IS the oracle dict (from load_shared_oracle_config).
            user, password, tns_alias = resolve_db_account_with_tns(
                secret_ref, workflow_config=cfg,
            )
            url = etl.get("url") or ""
            if not url and tns_alias:
                url = f"jdbc:oracle:thin:@{tns_alias}"
            if user and password and url:
                return {
                    "oracle_user":     str(user),
                    "oracle_password": str(password),
                    "oracle_url":      str(url),
                }
        except (ImportError, RuntimeError, ValueError) as exc:
            _logger.warning(
                "ETL Oracle: vault resolution for secret_ref=%r failed "
                "(%s) -- falling back to env var.", secret_ref, exc,
            )

    # Layer 3: env-var fallback
    dsn = os.environ.get("ETL_ORACLE_CONN") or ""
    return parse_dest_dsn(str(dsn).strip())


def resolve_etl_connection_string(config: Dict[str, Any]) -> str:
    """Return the ETL Oracle connection string for use by standalones.

    Resolution order:
      1. ``config["oracle"]["etl_connection_string"]`` literal (back-compat)
      2. ``oracle.etl.secret_ref`` + ``oracle.etl.url`` via Vault
      3. ``ETL_ORACLE_CONN`` env var

    Returns ``"user/password@host:port/service"`` format (the legacy DSN
    shape every standalone already understands).  Empty string when
    nothing resolves -- caller should fail loud.

    Args:
      config: full oracle_config.yaml content (the ``{"oracle": {...}}``
        dict the standalones already load).  Used so callers don't
        re-parse the file -- just pass what they already have.
    """
    oracle = (config or {}).get("oracle", {}) or {}

    # Layer 1: literal DSN in the passed config (back-compat with current
    # standalones that read this field directly).
    dsn = (oracle.get("etl_connection_string") or "").strip()
    if dsn:
        return dsn

    # Layer 2: vault via secret_ref + etl.url.
    etl = oracle.get("etl", {}) or {}
    secret_ref = (etl.get("secret_ref") or "").strip()
    if secret_ref:
        try:
            from qs_credentials import resolve_db_account_with_tns
            # Pass the oracle top-level dict so per-workflow
            # ``vault_enabled`` flag is honoured.
            user, password, tns_alias = resolve_db_account_with_tns(
                secret_ref, workflow_config=oracle,
            )
            host_part = etl.get("dsn_host") or tns_alias or ""
            if user and password and host_part:
                _logger.info(
                    "ETL Oracle: fetched schema creds from VAULT "
                    "(secret_ref=%r, user=%r, host=%r)",
                    secret_ref, user, host_part,
                )
                return f"{user}/{password}@{host_part}"
        except (ImportError, RuntimeError, ValueError) as exc:
            _logger.warning(
                "ETL Oracle: vault resolution for secret_ref=%r failed "
                "(%s) -- falling back to env var.", secret_ref, exc,
            )

    # Layer 3: env-var fallback.
    env_dsn = (os.environ.get("ETL_ORACLE_CONN") or "").strip()
    return env_dsn


def resolve_dest_connection_string(config: Dict[str, Any]) -> str:
    """Same shape as ``resolve_etl_connection_string`` but for the
    destination Oracle DB (Starburst->Oracle / file->Oracle / s3->Oracle
    sink targets).

    Resolution order:
      1. ``config["oracle"]["dest_connection_string"]`` literal
      2. ``oracle.destination.secret_ref`` via Vault
      3. ``DEST_ORACLE_CONN`` env var
    """
    oracle = (config or {}).get("oracle", {}) or {}
    dsn = (oracle.get("dest_connection_string") or "").strip()
    if dsn:
        return dsn

    dest = oracle.get("destination", {}) or {}
    secret_ref = (dest.get("secret_ref") or "").strip()
    if secret_ref:
        try:
            from qs_credentials import resolve_db_account_with_tns
            # Pass the oracle top-level dict so per-workflow
            # ``vault_enabled`` flag is honoured.
            user, password, tns_alias = resolve_db_account_with_tns(
                secret_ref, workflow_config=oracle,
            )
            host_part = dest.get("dsn_host") or tns_alias or ""
            if user and password and host_part:
                _logger.info(
                    "Dest Oracle: fetched schema creds from VAULT "
                    "(secret_ref=%r, user=%r, host=%r)",
                    secret_ref, user, host_part,
                )
                return f"{user}/{password}@{host_part}"
        except (ImportError, RuntimeError, ValueError) as exc:
            _logger.warning(
                "Dest Oracle: vault resolution for secret_ref=%r failed "
                "(%s) -- falling back to env var.", secret_ref, exc,
            )

    return (os.environ.get("DEST_ORACLE_CONN") or "").strip()


def merge_shared_into_job_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """In-place merge of the shared destination Oracle creds into a
    per-job JSON config.  Per-job JSON wins; this only fills blanks.

    Used by ``light_starburst_base`` AND ``starburst_base`` so the
    per-job JSON can drop ``oracle_user`` / ``oracle_password`` /
    ``oracle_url`` and inherit them from the shared config.
    """
    try:
        shared = shared_dest_oracle_creds()
        for key in ("oracle_user", "oracle_password", "oracle_url"):
            if shared.get(key) and not config.get(key):
                config[key] = shared[key]
    except Exception:
        # Loader unavailable / shared YAML broken — proceed with
        # per-job JSON only.
        pass
    return config
