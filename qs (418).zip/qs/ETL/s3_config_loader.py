"""Shared S3 / AWS connection-config loader.

2026-06-22 -- environment-aware version.  Mirrors the
starburst_config_loader.shared_creds_for(endpoint) pattern.

Configuration shape in ``configs/s3_config.yaml``::

    s3:
      auth_mode: "iam_role"      # root defaults
      region_name: "us-east-1"
      oncloud:
        bucket: "..."
        endpoint_url: "..."
        iceberg:
          catalog_uri: "..."
          warehouse: "..."
        ...
      onprem:
        bucket: "..."
        hive:
          metastore_uris: "..."
        ...

Resolution order for EACH field (highest priority wins):
  1. Per-job JSON config (s3_bucket, region_name, auth_mode, ...)
  2. Yaml ``s3.<environment>`` subsection (oncloud / onprem)
  3. Yaml root-level ``s3.*`` defaults (auth_mode, region_name only)
  4. AWS_* environment variables
  5. boto3 default chain (when auth_mode='iam_role')

Step classes pick their environment via the ``ENVIRONMENT`` class
attribute (e.g., ``IcebergToFile_OnCloud.ENVIRONMENT = "oncloud"``).
The loader's ``shared_s3_creds(environment)`` returns the merged dict
for that environment.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


_PROD_PATH = "/usr/local/spark/pvc/code/configs/s3_config.yaml"
_LOCAL_PATH = str(
    Path(__file__).resolve().parent / "configs" / "s3_config.yaml"
)

_ENVIRONMENTS = ("oncloud", "onprem")

_logger = logging.getLogger("s3_config_loader")


def _load_yaml() -> Dict[str, Any]:
    """Load the shared YAML.  Returns {} if no file is present anywhere."""
    for path in (_PROD_PATH, _LOCAL_PATH):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except yaml.YAMLError as exc:
                _logger.warning(
                    "s3_config.yaml at %s is malformed (%s) -- ignoring "
                    "file, falling back to AWS_* env vars + boto3 default chain.",
                    path, exc,
                )
                return {}
            except OSError as exc:
                _logger.warning(
                    "Cannot read s3_config.yaml at %s (%s) -- falling back "
                    "to env vars.", path, exc,
                )
                return {}
    return {}


@lru_cache(maxsize=1)
def load_shared_s3_config() -> Dict[str, Any]:
    """Cached parse of the ``s3`` top-level section."""
    return _load_yaml().get("s3", {}) or {}


def reset_cache() -> None:
    """Drop the cached parse (test hook)."""
    load_shared_s3_config.cache_clear()


# ────────────────────────────────────────────────────────────────────────
#  Field mappings (yaml key -> per-job JSON key)
# ────────────────────────────────────────────────────────────────────────


# Direct S3 + AWS fields, applied in both per-environment and root scope.
# Field names mirror QueryStudio's S3 connection record where possible.
_S3_FIELD_MAP = {
    "bucket":             "s3_bucket",
    "endpoint_url":       "s3_endpoint_url",
    "path_style_access":  "s3_path_style_access",
    "ssl_enabled":        "s3_ssl_enabled",
    "access_key":         "s3_access_key",
    "secret_key":         "s3_secret_key",
    # 2026-06-22 -- outbound HTTP proxy (when VPC endpoint not available).
    "proxy_host":         "s3_proxy_host",
    "proxy_port":         "s3_proxy_port",
    "proxy_username":     "s3_proxy_username",
    "proxy_password":     "s3_proxy_password",
}

_AUTH_FIELD_MAP = {
    "auth_mode":                "auth_mode",
    "region_name":              "region_name",
    "region":                   "region_name",            # QS alias
    "role_arn":                 "role_arn",
    "role_session_name":        "role_session_name",
    "session_duration_seconds": "session_duration_seconds",
    "aws_profile":              "aws_profile",
    # 2026-06-22 -- portal auth (QueryStudio's "portal" auth_mode).
    # AD username + password -> corp portal STS -> temporary AWS keys.
    # Resolution handled by ETL/aws_credentials.py at S3A-build time.
    "portal_username":          "portal_username",
    "portal_password":          "portal_password",
    "system_account_id":        "system_account_id",
    # Connection-type tag (mirrors QS; not consumed by ETL today but
    # threaded through for future extensibility).
    "connection_type":          "connection_type",
}

_ICEBERG_FIELD_MAP = {
    "catalog_name": "iceberg_catalog_name",
    "catalog_type": "iceberg_catalog_type",
    "catalog_uri":  "iceberg_catalog_uri",
    "warehouse":    "iceberg_warehouse",
}

_HIVE_FIELD_MAP = {
    "metastore_uris": "hive_metastore_uris",
    "warehouse_dir":  "hive_warehouse_dir",
    "catalog_name":   "hive_catalog_name",
}


# ────────────────────────────────────────────────────────────────────────
#  Public API
# ────────────────────────────────────────────────────────────────────────


def shared_s3_creds(environment: str) -> Dict[str, Any]:
    """Return the merged AWS + S3 + iceberg + hive config for ONE
    environment as a dict keyed by per-job-JSON field names.

    Resolution per field:
      yaml env section > yaml root > AWS_* env vars > empty string

    Args:
      environment: ``"oncloud"`` or ``"onprem"``.

    Returns:
      Dict with keys matching what a per-job JSON would carry
      (s3_bucket, s3_endpoint_url, auth_mode, region_name,
      iceberg_catalog_uri, hive_metastore_uris, ...).  Empty string
      for absent fields.
    """
    if environment not in _ENVIRONMENTS:
        raise ValueError(
            f"environment must be one of {_ENVIRONMENTS}, got {environment!r}"
        )

    cfg = load_shared_s3_config()
    env_cfg = cfg.get(environment, {}) or {}

    def _pick(yaml_key: str) -> Any:
        """Env section first, then root.  Empty string when absent."""
        if env_cfg.get(yaml_key) not in (None, ""):
            return env_cfg[yaml_key]
        if cfg.get(yaml_key) not in (None, ""):
            return cfg[yaml_key]
        return ""

    out: Dict[str, Any] = {}

    # S3 connection fields (env section only -- bucket is per-env by nature).
    for yaml_key, json_key in _S3_FIELD_MAP.items():
        v = env_cfg.get(yaml_key, "")
        out[json_key] = v if v is not None else ""

    # AWS auth fields (env section overrides root).  Multiple yaml keys
    # may map to the same json_key (e.g. region + region_name both ->
    # region_name); only OVERWRITE when the new value is non-blank so
    # a later-iteration blank can't clobber an earlier-iteration value.
    for yaml_key, json_key in _AUTH_FIELD_MAP.items():
        v = _pick(yaml_key)
        if v or json_key not in out:
            out[json_key] = v

    # Iceberg sub-section (env-specific).
    ice = env_cfg.get("iceberg", {}) or {}
    for yaml_key, json_key in _ICEBERG_FIELD_MAP.items():
        v = ice.get(yaml_key, "")
        out[json_key] = v if v is not None else ""

    # Hive sub-section (env-specific; populated for on-prem).
    hive = env_cfg.get("hive", {}) or {}
    for yaml_key, json_key in _HIVE_FIELD_MAP.items():
        v = hive.get(yaml_key, "")
        out[json_key] = v if v is not None else ""

    # Env-var overlay for sensitive creds (last layer before boto3 chain).
    out["s3_access_key"] = out["s3_access_key"] or os.environ.get("AWS_ACCESS_KEY_ID", "") or ""
    out["s3_secret_key"] = out["s3_secret_key"] or os.environ.get("AWS_SECRET_ACCESS_KEY", "") or ""
    out["region_name"]   = out["region_name"]   or os.environ.get("AWS_REGION", "") or os.environ.get("AWS_DEFAULT_REGION", "") or ""

    return out


def merge_shared_into_job_config(
    config: Dict[str, Any],
    *,
    environment: str = "oncloud",
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """In-place fill of AWS / S3 fields from the shared yaml.

    Per-job JSON ALWAYS wins -- this only fills blanks.

    2026-06-22 -- AWS auth is INTENTIONALLY kept separate from the
    vault flow.  Per user direction: AWS reads use IRSA / instance
    profile / assume_role / explicit keys.  System accounts (Starburst,
    Oracle DB) use vault via secret_ref -- see starburst_config_loader
    + oracle_config_loader.  S3 yaml has no secret_ref field.

    Args:
      config: per-job JSON dict (mutated in place).
      environment: ``"oncloud"`` or ``"onprem"`` -- selects yaml section.
      logger: optional logger for INFO lines.
    """
    log = logger or _logger
    try:
        shared = shared_s3_creds(environment)
        for k, v in shared.items():
            if v in (None, ""):
                continue
            if config.get(k) in (None, ""):
                config[k] = v
    except Exception as exc:
        log.warning(
            "s3_config_loader: yaml load failed (%s) for environment=%s "
            "-- using per-job JSON + env vars only.", exc, environment,
        )
    return config


def validate_s3_yaml_for_job(
    config: Dict[str, Any],
    *,
    environment: str = "oncloud",
    requires_iceberg: bool = False,
    requires_hive: bool = False,
    logger: Optional[logging.Logger] = None,
) -> None:
    """Hard-fail with a per-field checklist when required AWS/S3 fields
    are still missing after yaml + env-var merge.

    Args:
      config: per-job JSON (after merge_shared_into_job_config).
      environment: ``"oncloud"`` or ``"onprem"`` -- for error message context.
      requires_iceberg: when True, also validates iceberg catalog URI + warehouse.
      requires_hive: when True, validates hive metastore_uris + warehouse_dir.
    """
    log = logger or _logger
    missing: List[str] = []

    if not config.get("s3_bucket"):
        missing.append(
            f"s3_bucket  (yaml: s3.{environment}.bucket; or per-job JSON)"
        )
    if not config.get("region_name"):
        missing.append(
            f"region_name  (yaml: s3.{environment}.region_name or root s3.region_name; "
            "env: AWS_REGION/AWS_DEFAULT_REGION)"
        )

    auth_mode = (config.get("auth_mode") or "").lower()
    if auth_mode == "keys":
        if not config.get("s3_access_key") or not config.get("s3_secret_key"):
            missing.append(
                f"s3_access_key / s3_secret_key  (yaml: s3.{environment}.access_key/"
                f"secret_key; env: AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY; "
                f"required when auth_mode='keys'.  Switch to auth_mode='iam_role' "
                f"in prod when possible.)"
            )
    elif auth_mode == "assume_role":
        if not config.get("role_arn"):
            missing.append(
                f"role_arn  (yaml: s3.{environment}.role_arn; "
                f"required when auth_mode='assume_role')"
            )
    elif auth_mode == "profile":
        if not config.get("aws_profile"):
            missing.append(
                f"aws_profile  (yaml: s3.{environment}.aws_profile; "
                f"required when auth_mode='profile')"
            )
    elif auth_mode == "portal":
        # AD username/password -> corp portal STS -> temp AWS keys.
        if not config.get("portal_username") or not config.get("portal_password"):
            # Allow system_account_id as an alternative path (QS pattern:
            # one shared system account fetched via portal_password_vault).
            if not config.get("system_account_id"):
                missing.append(
                    f"portal_username + portal_password  (yaml: s3.{environment}."
                    f"portal_username + portal_password; required when "
                    f"auth_mode='portal').  OR set system_account_id to use a "
                    f"shared system account from the portal password vault."
                )
    elif auth_mode == "vault":
        if not config.get("secret_ref"):
            missing.append(
                f"secret_ref  (yaml: s3.{environment}.secret_ref; "
                f"required when auth_mode='vault'.  Add the ref name to "
                f"configs/vault_config.yaml -> secrets.refs)"
            )
    elif auth_mode in ("iam_role", "env", ""):
        pass  # boto3 default chain handles cred resolution
    else:
        missing.append(
            f"auth_mode={auth_mode!r} not recognised.  Use: "
            "portal | iam_role | assume_role | env | profile | keys | vault"
        )

    if requires_iceberg:
        if not config.get("iceberg_catalog_uri"):
            missing.append(
                f"iceberg_catalog_uri  (yaml: s3.{environment}.iceberg.catalog_uri)"
            )
        if not config.get("iceberg_warehouse"):
            missing.append(
                f"iceberg_warehouse  (yaml: s3.{environment}.iceberg.warehouse)"
            )

    # Proxy: when proxy_host is set, proxy_port MUST also be set.
    # Catches operators who fill host but forget port (silent failure --
    # default port=0 would route to nothing).
    proxy_host = (config.get("s3_proxy_host") or "").strip()
    if proxy_host:
        try:
            proxy_port = int(config.get("s3_proxy_port") or 0)
        except (TypeError, ValueError):
            proxy_port = 0
        if proxy_port <= 0:
            missing.append(
                f"s3_proxy_port  (yaml: s3.{environment}.proxy_port; "
                f"required when proxy_host is set.  Common value: 3128 "
                f"for corp proxies, 8080 for tinyproxy/squid defaults)"
            )

    if requires_hive:
        if not config.get("hive_metastore_uris"):
            missing.append(
                f"hive_metastore_uris  (yaml: s3.{environment}.hive.metastore_uris; "
                f"format: thrift://hive-metastore.host:9083)"
            )
        if not config.get("hive_warehouse_dir"):
            missing.append(
                f"hive_warehouse_dir  (yaml: s3.{environment}.hive.warehouse_dir)"
            )

    if missing:
        bullets = "\n".join(f"  * {m}" for m in missing)
        raise ValueError(
            f"S3 / AWS connection ({environment} environment): "
            f"missing required field(s):\n{bullets}\n"
            f"Fill in configs/s3_config.yaml (recommended) OR per-job JSON OR "
            f"matching AWS_* env vars.\n"
            f"Edit one of:\n"
            f"  * (production) /usr/local/spark/pvc/code/configs/s3_config.yaml\n"
            f"  * (local dev ) ETL/configs/s3_config.yaml\n"
            f"and restart the pod / process to pick up changes."
        )
