"""APScheduler-backed cron daemon.

Loads job specs from YAML, registers them with APScheduler, executes via
ProcRunner, optionally fires the AirflowDispatcher based on the per-job
dispatch_rule.  Outcomes are recorded in-memory (last N per job) for a
status endpoint.
"""
from __future__ import annotations

import collections
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional

import yaml
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from .airflow_client import AirflowDispatcher
from .job import CronJob, CronJobOutcome, JobDispatchRule
from .proc_runner import ProcRunner

_log = logging.getLogger(__name__)


class CronScheduler:
    """Reads YAML, schedules jobs, dispatches per-job.

    Construction is dependency-injected so unit tests pass mocks.
    Production wiring lives in ETL/cron/main.py.
    """

    def __init__(
        self,
        proc_runner: ProcRunner,
        airflow: Optional[AirflowDispatcher] = None,
        outcome_history_size: int = 50,
        scheduler_factory: Callable[[], BackgroundScheduler] = BackgroundScheduler,
    ) -> None:
        self._proc_runner = proc_runner
        self._airflow = airflow
        self._scheduler = scheduler_factory()
        self._jobs: Dict[str, CronJob] = {}
        self._outcomes: Dict[str, collections.deque] = {}
        self._history_size = int(outcome_history_size)
        self._lock = threading.Lock()

    # ── Loading ───────────────────────────────────────────────────────

    def load_yaml(self, path: str | Path) -> List[CronJob]:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        jobs = data.get("jobs", [])
        loaded: List[CronJob] = []
        for entry in jobs:
            try:
                job = CronJob(
                    name=entry["name"],
                    schedule=entry["schedule"],
                    proc_name=entry["proc_name"],
                    proc_params=entry.get("proc_params", {}) or {},
                    dispatch_rule=JobDispatchRule(entry.get("dispatch_rule", "proc_only")),
                    airflow_dag_id=entry.get("airflow_dag_id"),
                    airflow_size_threshold=int(entry.get("airflow_size_threshold", 500_000)),
                    timezone=entry.get("timezone", "UTC"),
                    enabled=bool(entry.get("enabled", True)),
                )
            except (KeyError, ValueError) as exc:
                _log.error(
                    "[cron.load] skip invalid job entry %s: %s", entry, exc,
                )
                continue
            self.register(job)
            loaded.append(job)
        _log.info("[cron.load] %d job(s) registered from %s", len(loaded), path)
        return loaded

    # ── Lifecycle ─────────────────────────────────────────────────────

    def add_callback_job(
        self,
        name: str,
        schedule: str,
        callback: Callable[[], None],
        timezone: str = "UTC",
    ) -> None:
        """Register an arbitrary callback on the same APScheduler instance.

        Use this for non-proc jobs (e.g. the SyncOrchestrator cycle) that
        share the cron pod's APScheduler but don't map to one Oracle proc.
        The callback is fired with no args; capture context via closure.
        """
        self._scheduler.add_job(
            callback,
            trigger=CronTrigger.from_crontab(schedule, timezone=timezone),
            id=name,
            replace_existing=True,
            misfire_grace_time=300,
            coalesce=True,
            max_instances=1,
        )
        _log.info(
            "[cron.register-callback] %s schedule=%r tz=%s",
            name, schedule, timezone,
        )

    def register(self, job: CronJob) -> None:
        if not job.enabled:
            _log.info("[cron.register] skip %s (disabled)", job.name)
            return
        with self._lock:
            self._jobs[job.name] = job
            self._outcomes.setdefault(
                job.name, collections.deque(maxlen=self._history_size),
            )
        self._scheduler.add_job(
            self._fire,
            trigger=CronTrigger.from_crontab(job.schedule, timezone=job.timezone),
            args=[job.name],
            id=job.name,
            replace_existing=True,
            misfire_grace_time=300,   # 5 min grace for missed runs
            coalesce=True,            # only run once if multiple missed
            max_instances=1,          # single fire per job at a time
        )
        _log.info(
            "[cron.register] %s schedule=%r tz=%s dispatch=%s",
            job.name, job.schedule, job.timezone, job.dispatch_rule.value,
        )

    def start(self) -> None:
        _log.info("[cron] starting scheduler with %d jobs", len(self._jobs))
        self._scheduler.start()

    def stop(self, wait: bool = True) -> None:
        _log.info("[cron] stopping scheduler (wait=%s)", wait)
        self._scheduler.shutdown(wait=wait)

    # ── Status (for health endpoint) ──────────────────────────────────

    def status(self) -> Dict[str, object]:
        with self._lock:
            return {
                "jobs": [
                    {
                        "name":              job.name,
                        "schedule":          job.schedule,
                        "proc_name":         job.proc_name,
                        "dispatch_rule":     job.dispatch_rule.value,
                        "airflow_dag_id":    job.airflow_dag_id,
                        "recent_outcomes":   [
                            self._outcome_as_dict(o)
                            for o in list(self._outcomes[job.name])[-5:]
                        ],
                    }
                    for job in self._jobs.values()
                ],
                "running": self._scheduler.running,
            }

    # ── Internals ─────────────────────────────────────────────────────

    def _fire(self, job_name: str) -> None:
        with self._lock:
            job = self._jobs.get(job_name)
        if job is None:
            _log.warning("[cron.fire] job=%s gone before fire — skipping", job_name)
            return
        outcome = CronJobOutcome.started(job)
        try:
            result = self._proc_runner.run(job.proc_name, job.proc_params)
            outcome.proc_status = result.status
            outcome.rows_affected = result.rows_affected
            outcome.error = result.error
            if result.status != "ok":
                _log.warning(
                    "[cron.fire] job=%s proc=%s returned status=%s — skip airflow",
                    job.name, job.proc_name, result.status,
                )
            else:
                self._maybe_trigger_airflow(job, result.rows_affected, outcome)
        except Exception as exc:
            _log.error(
                "[cron.fire] job=%s unexpected error: %s", job.name, exc, exc_info=True,
            )
            outcome.proc_status = "error"
            outcome.error = str(exc)
        finally:
            outcome.finished_at = datetime.now(timezone.utc)
            with self._lock:
                self._outcomes[job_name].append(outcome)

    def _maybe_trigger_airflow(
        self,
        job: CronJob,
        rows_affected: int,
        outcome: CronJobOutcome,
    ) -> None:
        rule = job.dispatch_rule
        if rule is JobDispatchRule.PROC_ONLY:
            return
        should_trigger = (
            rule is JobDispatchRule.ALWAYS_AIRFLOW
            or (rule is JobDispatchRule.AIRFLOW_IF_LARGE
                and rows_affected >= job.airflow_size_threshold)
        )
        if not should_trigger:
            _log.info(
                "[cron.fire] job=%s rows=%d < threshold=%d — skip airflow",
                job.name, rows_affected, job.airflow_size_threshold,
            )
            return
        if self._airflow is None:
            _log.error(
                "[cron.fire] job=%s wants airflow but dispatcher not configured",
                job.name,
            )
            return
        try:
            run_id = self._airflow.trigger_for_cron(
                dag_id=job.airflow_dag_id,
                cron_job_name=job.name,
                proc_name=job.proc_name,
                rows_affected=rows_affected,
                extra_conf=job.proc_params,
            )
            outcome.airflow_run_id = run_id
            _log.info(
                "[cron.fire] job=%s triggered airflow dag=%s run_id=%s",
                job.name, job.airflow_dag_id, run_id,
            )
        except Exception as exc:
            _log.error(
                "[cron.fire] job=%s airflow trigger failed: %s",
                job.name, exc, exc_info=True,
            )
            outcome.error = (outcome.error or "") + f" | airflow: {exc}"

    @staticmethod
    def _outcome_as_dict(o: CronJobOutcome) -> Dict[str, object]:
        return {
            "started_at":      o.started_at.isoformat(),
            "finished_at":     o.finished_at.isoformat(),
            "proc_status":     o.proc_status,
            "rows_affected":   o.rows_affected,
            "airflow_run_id":  o.airflow_run_id,
            "error":           o.error,
        }
