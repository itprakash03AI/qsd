"""Daemon entry for the cron scheduler.

  python -m ETL.cron.main --config ETL/configs/cron_jobs.yaml --port 9101

Health/status at :9101/health and /jobs.
"""
from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import threading
from pathlib import Path

from .airflow_client import AirflowConfig, AirflowDispatcher
from .proc_runner import ProcRunner
from .scheduler import CronScheduler

_log = logging.getLogger("etl.cron")


def build_proc_runner() -> ProcRunner:
    from ETL.managers.oracledblib import OracleDBLib   # type: ignore
    return ProcRunner(invoker=OracleDBLib())


def build_airflow() -> AirflowDispatcher | None:
    if "AIRFLOW_BASE_URL" not in os.environ:
        _log.warning(
            "[cron] AIRFLOW_BASE_URL not set — jobs with dispatch_rule != "
            "proc_only will log errors instead of firing.",
        )
        return None
    return AirflowDispatcher(AirflowConfig.from_env())


def main(argv=None) -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )
    p = argparse.ArgumentParser(description="ETL Cron Scheduler")
    p.add_argument("--config", default="ETL/configs/cron_jobs.yaml")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=9101)
    args = p.parse_args(argv)

    sched = CronScheduler(
        proc_runner=build_proc_runner(),
        airflow=build_airflow(),
    )
    sched.load_yaml(Path(args.config))
    sched.start()

    # Minimal status endpoint — keeps the K8s probe happy.
    from fastapi import FastAPI
    import uvicorn
    app = FastAPI(title="ETL Cron Scheduler")

    @app.get("/health")
    def health(): return {"ok": True}

    @app.get("/jobs")
    def jobs(): return sched.status()

    # Graceful shutdown — APScheduler must stop before uvicorn exits or
    # in-flight jobs leak threads.
    def _shutdown(*_):
        _log.info("[cron] received signal — stopping scheduler")
        sched.stop(wait=True)
    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    uvicorn.run(app, host=args.host, port=args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
