"""Execute one Oracle proc, return its (status, rows_affected).

Wraps the existing ETL/managers/oracledblib.py — every proc execution in
the codebase already flows through that, so we reuse rather than
introduce a parallel connection path.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Protocol

_log = logging.getLogger(__name__)


@dataclass
class ProcResult:
    proc_name: str
    status: str                 # "ok" | "error"
    rows_affected: int = 0
    out_bindings: Dict[str, Any] = None  # any OUT params the proc returned
    error: str = None


class OracleProcInvoker(Protocol):
    """The narrow surface we need from oracledblib.

    `execute_procedure(name, params)` is the existing function — same
    signature as ETL/managers/oracle_metadata_manager.py uses today.
    """
    def execute_procedure(
        self,
        procedure_name: str,
        parameters: Dict[str, Any] | list,
    ) -> Any: ...


class ProcRunner:
    """Thin wrapper that normalises the (status, rows_affected) contract
    from any of the many shapes oracledblib returns.

    Why: oracle proc results come back as:
      - bare int (rows_affected)
      - dict {"status": "ok", "rows": 1234}
      - tuple (status, rows)
      - None (proc succeeded, no rows reported)
    The cron scheduler should not care which.  Normalise here.
    """

    ROWS_KEYS = ("rows_affected", "rows", "row_count", "p_rows", "p_count")
    STATUS_KEYS = ("status", "p_status", "result")

    def __init__(self, invoker: OracleProcInvoker) -> None:
        self._invoker = invoker

    def run(self, proc_name: str, params: Dict[str, Any]) -> ProcResult:
        _log.info("[cron.proc] running proc=%s params=%s", proc_name, params)
        try:
            raw = self._invoker.execute_procedure(proc_name, params)
        except Exception as exc:
            _log.error(
                "[cron.proc] proc=%s FAILED: %s", proc_name, exc, exc_info=True,
            )
            return ProcResult(proc_name=proc_name, status="error", error=str(exc))
        result = self._normalise(proc_name, raw)
        _log.info(
            "[cron.proc] proc=%s status=%s rows_affected=%d",
            proc_name, result.status, result.rows_affected,
        )
        return result

    # ── Internals ─────────────────────────────────────────────────────

    def _normalise(self, proc_name: str, raw: Any) -> ProcResult:
        # bare int → row count, success implied
        if isinstance(raw, int):
            return ProcResult(proc_name=proc_name, status="ok", rows_affected=raw)
        # tuple/list (status, rows)
        if isinstance(raw, (tuple, list)) and len(raw) >= 2:
            return ProcResult(
                proc_name=proc_name,
                status=str(raw[0]) or "ok",
                rows_affected=int(raw[1] or 0),
            )
        # dict — look for known keys
        if isinstance(raw, dict):
            status = "ok"
            for key in self.STATUS_KEYS:
                if key in raw and raw[key] is not None:
                    status = str(raw[key])
                    break
            rows = 0
            for key in self.ROWS_KEYS:
                if key in raw and raw[key] is not None:
                    try:
                        rows = int(raw[key])
                    except (TypeError, ValueError):
                        rows = 0
                    break
            return ProcResult(
                proc_name=proc_name, status=status,
                rows_affected=rows, out_bindings=raw,
            )
        # None or unknown — assume success, no rows reported
        return ProcResult(proc_name=proc_name, status="ok", rows_affected=0)
