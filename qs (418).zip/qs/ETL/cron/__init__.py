"""Process 2: Cron scheduler — runs Oracle procs on schedule, optionally
triggers Airflow when the proc says size warrants it.

Public surface:
  - CronJob: declarative job spec (loaded from YAML).
  - CronScheduler: APScheduler-backed daemon that fires jobs on time.
  - ProcRunner: executes one Oracle proc, returns its (status, rows_affected).
  - AirflowDispatcher: thin REST client for the Airflow stable API.
"""
from .job import CronJob, CronJobOutcome, JobDispatchRule
from .proc_runner import ProcRunner, ProcResult
from .airflow_client import AirflowDispatcher
from .scheduler import CronScheduler

__all__ = [
    "CronJob", "CronJobOutcome", "JobDispatchRule",
    "ProcRunner", "ProcResult",
    "AirflowDispatcher",
    "CronScheduler",
]
