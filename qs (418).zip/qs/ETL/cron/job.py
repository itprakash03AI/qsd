"""Declarative cron job spec — driven by YAML, no Python edits to add jobs."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class JobDispatchRule(str, Enum):
    """What to do AFTER the proc completes."""
    # Proc is the whole job — done after it returns.
    PROC_ONLY = "proc_only"
    # Always trigger Airflow regardless of proc output.
    ALWAYS_AIRFLOW = "always_airflow"
    # Trigger Airflow only if the proc returns rows_affected ≥ threshold,
    # otherwise the proc result IS the deliverable.  Mirrors the sync
    # process's polling-vs-airflow split, but driven by the proc's
    # output instead of a comparator pre-pass.
    AIRFLOW_IF_LARGE = "airflow_if_large"


@dataclass
class CronJob:
    """One scheduled job — read from cron_jobs.yaml."""
    name: str                               # human-readable id
    schedule: str                           # cron expression: "0 */4 * * *"
    proc_name: str                          # Oracle proc to call
    proc_params: Dict[str, Any] = field(default_factory=dict)
    dispatch_rule: JobDispatchRule = JobDispatchRule.PROC_ONLY
    airflow_dag_id: Optional[str] = None    # required when rule != PROC_ONLY
    airflow_size_threshold: int = 500_000   # used by AIRFLOW_IF_LARGE
    timezone: str = "UTC"                   # for cron parsing
    enabled: bool = True

    def __post_init__(self) -> None:
        if self.dispatch_rule is not JobDispatchRule.PROC_ONLY and not self.airflow_dag_id:
            raise ValueError(
                f"CronJob {self.name!r} dispatch_rule={self.dispatch_rule.value} "
                f"requires airflow_dag_id"
            )


@dataclass
class CronJobOutcome:
    """One execution result — useful for the cron status endpoint."""
    job: CronJob
    started_at: datetime
    finished_at: datetime
    proc_status: str                        # "ok" | "error"
    rows_affected: int = 0
    airflow_run_id: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def started(cls, job: CronJob) -> "CronJobOutcome":
        now = datetime.now(timezone.utc)
        return cls(
            job=job, started_at=now, finished_at=now,
            proc_status="pending", rows_affected=0,
        )
