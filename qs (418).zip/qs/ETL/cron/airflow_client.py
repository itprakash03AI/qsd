"""Airflow REST API client — POSTs a trigger to the stable v1 API.

Used by BOTH processes (sync + cron) so the trigger contract is identical
regardless of who fires it: same DAG, same conf shape, same retry rules.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests

from ..sync.models import SyncAction

_log = logging.getLogger(__name__)


@dataclass
class AirflowConfig:
    """All Airflow connection details in one place — read from env or
    values.yaml at startup, never hardcoded."""
    base_url: str                           # e.g. https://airflow.np.svc/api/v1
    user: str
    password: str
    request_timeout: float = 30.0
    verify_ssl: bool = True

    @classmethod
    def from_env(cls, *, prefix: str = "AIRFLOW_") -> "AirflowConfig":
        """Read Airflow connection details.

        Phase 158 R4 (2026-06-26) -- credential resolution rules:

          1. If ``{prefix}SECRET_REF`` env var is set, fetch the
             user + password from Vault via ``qs_credentials``.
             This is the production path (no literal creds in env).
          2. Else read ``{prefix}USER`` + ``{prefix}PASS`` env
             vars directly.  This is the dev / pre-vault fallback.

        Either way, the URL + timeout + verify_ssl come from env
        because they are environment-specific, not credentials.
        """
        base_url = os.environ[f"{prefix}BASE_URL"].rstrip("/")
        request_timeout = float(os.environ.get(f"{prefix}TIMEOUT_S", "30"))
        verify_ssl = os.environ.get(
            f"{prefix}VERIFY_SSL", "true",
        ).lower() == "true"

        secret_ref = os.environ.get(f"{prefix}SECRET_REF", "").strip()
        if secret_ref:
            # Lazy import + try/except so unit tests + dev pods
            # without vault available can still construct the
            # config via env-var fallback.
            try:
                try:
                    from qs_credentials import resolve_ad_account  # flat (polling-service)
                except ImportError:
                    from ETL.qs_credentials import resolve_ad_account  # prefixed (sync-cron)
                user, password = resolve_ad_account(secret_ref)
                _log.info(
                    "AirflowConfig: resolved user + password from vault "
                    "(secret_ref=%r).", secret_ref,
                )
                return cls(
                    base_url=base_url,
                    user=user,
                    password=password,
                    request_timeout=request_timeout,
                    verify_ssl=verify_ssl,
                )
            except Exception as exc:
                _log.warning(
                    "AirflowConfig: vault resolution for secret_ref=%r "
                    "failed (%s) -- falling back to %sUSER + %sPASS "
                    "env vars.",
                    secret_ref, exc, prefix, prefix,
                )
                # fall through to env-var path

        return cls(
            base_url=base_url,
            user=os.environ[f"{prefix}USER"],
            password=os.environ[f"{prefix}PASS"],
            request_timeout=request_timeout,
            verify_ssl=verify_ssl,
        )


class AirflowDispatcher:
    """Implements both:
       - sync.dispatcher.AirflowBackend.trigger(SyncAction)
       - cron.scheduler's airflow callback
    via a single _post().
    """

    def __init__(self, cfg: AirflowConfig, session: Optional[requests.Session] = None) -> None:
        self._cfg = cfg
        self._session = session or requests.Session()
        self._session.auth = (cfg.user, cfg.password)

    # ── For the sync process ──────────────────────────────────────────

    def trigger(self, action: SyncAction) -> str:
        """Implements sync.dispatcher.AirflowBackend.trigger.

        The DAG id is encoded into proc_params as `airflow_dag_id` by the
        orchestrator's param builder; if absent, fall back to the
        logical_name (operators typically name DAGs after the table).
        """
        dag_id = action.proc_params.get("airflow_dag_id") or action.logical_name
        conf = {
            "logical_name":        action.logical_name,
            "code":                action.key.code,
            "business_close_date": action.key.business_close_date.isoformat(),
            "business_event":      action.key.business_event,
            "proc_name":           action.proc_name,
            "estimated_rows":      action.estimated_rows,
            "idempotency_key":     action.idempotency_key,
            "trigger_source":      "sync",
        }
        return self._trigger_dag(dag_id, conf, dag_run_id=action.idempotency_key)

    # ── For the cron process ──────────────────────────────────────────

    def trigger_for_cron(
        self,
        dag_id: str,
        cron_job_name: str,
        proc_name: str,
        rows_affected: int,
        extra_conf: Optional[Dict[str, Any]] = None,
    ) -> str:
        conf = {
            "trigger_source":  "cron",
            "cron_job_name":   cron_job_name,
            "proc_name":       proc_name,
            "rows_affected":   rows_affected,
        }
        if extra_conf:
            conf.update(extra_conf)
        # dag_run_id is auto-generated when None — Airflow handles uniqueness
        return self._trigger_dag(dag_id, conf, dag_run_id=None)

    # ── The single network call ───────────────────────────────────────

    def _trigger_dag(
        self,
        dag_id: str,
        conf: Dict[str, Any],
        dag_run_id: Optional[str],
    ) -> str:
        url = f"{self._cfg.base_url}/dags/{dag_id}/dagRuns"
        body: Dict[str, Any] = {"conf": conf}
        if dag_run_id:
            body["dag_run_id"] = dag_run_id
        _log.info(
            "[airflow] POST %s dag_run_id=%s conf_keys=%s",
            url, dag_run_id, list(conf.keys()),
        )
        resp = self._session.post(
            url,
            json=body,
            timeout=self._cfg.request_timeout,
            verify=self._cfg.verify_ssl,
        )
        if resp.status_code == 409:
            # Already running — that's idempotency working as intended.
            # Return the dag_run_id we asked for so the caller can record it.
            _log.info(
                "[airflow] dag=%s dag_run_id=%s already exists — treating as success",
                dag_id, dag_run_id,
            )
            return dag_run_id or "<conflict-already-running>"
        resp.raise_for_status()
        data = resp.json()
        return str(data.get("dag_run_id", dag_run_id or "<unknown>"))
