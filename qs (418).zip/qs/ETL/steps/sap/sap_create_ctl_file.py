"""SAP-flow create-CTL-file step.

Self-contained -- no inheritance from the generic ``CreateCTLFile``.
Inherits only from ``SapOdataBase`` for the SAP-specific config loader
+ logger setup.

Emits the CTL (control) file paired with the gz payload.  The CTL
template lives in the per-task JSON config under ``ctl_template``;
the canonical SAP-balance template is at
``ETL/configs/sap_balance_ctl_template.json``.

Variables substituted into the template:
  * FILENAME / FILEPATH         -- payload file
  * RECORD_COUNT / CHECKSUM     -- from CompressFiles
  * TIMESTAMP / DATE            -- emission time
  * COMPRESSED_SIZE / UNCOMPRESSED_SIZE
  * POPER / GJAHR / PERIOD_MODE -- fiscal period
  * TASK_ID / RUN_ID / RUN_DETAIL_ID / OTG_DAG_ID / BUSINESS_DATE
                                 -- polling-row identifiers (operator-visible)
  * anything under config['ctl_custom_variables']
"""
import os
from datetime import datetime
from typing import Dict, List

from steps.sap.sap_odata_base import SapOdataBase


class SapCreateCTLFile(SapOdataBase):
    """Generate the SAP CTL/control file from a template."""

    LOG_PREFIX = "sap_create_ctl_file"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)
        self._hydrate_from_sidecar(task, config)

        # DB is the workflow source of truth: if the SapCreateCTLFile
        # polling row exists, the step MUST produce a CTL file or
        # FAIL.  No silent skips -- "COMPLETED but no file" was wrong
        # UX.  If you don't want CTL, remove the polling row.
        data_file = task.get('compressed_file', task.get('consolidated_file', ''))
        if not data_file:
            raise ValueError(
                "No data file in task -- SapCompressFiles or "
                "SapConsolidateFiles must run first"
            )

        template = config.get('ctl_template', '')
        ctl_filename_template = config.get('ctl_filename', '')
        # Fall back to the dedicated CTL config file the operator
        # maintains separately.  Search order (first hit wins):
        #   1. ctl_template_config.json  -- preferred 2026-06-07 split
        #   2. sap_balance_ctl_template.json  -- legacy combined file
        # No fallback to hardcoded template in Python.
        if not template:
            from pathlib import Path
            import json as _json
            # 2026-06-21 -- post steps/ split, this module lives at
            # ETL/steps/sap/sap_create_ctl_file.py so the configs/
            # directory is THREE parents up (sap -> steps -> ETL).
            here = Path(__file__).resolve().parent.parent.parent / 'configs'
            for candidate in ('ctl_template_config.json',
                              'sap_balance_ctl_template.json'):
                fp = here / candidate
                if not fp.exists():
                    continue
                try:
                    with open(fp, 'r', encoding='utf-8') as f:
                        ref = _json.load(f)
                    template = ref.get('ctl_template', '')
                    if not ctl_filename_template:
                        ctl_filename_template = ref.get('ctl_filename', '')
                    if template:
                        self.logger.info(
                            "CTL template loaded from %s", fp,
                        )
                        break
                except (OSError, ValueError) as exc:
                    self.logger.warning(
                        "Could not load CTL template %s: %s", fp, exc,
                    )
        if not template:
            raise ValueError(
                "SapCreateCTLFile: ctl_template is required but missing "
                "from JSON config AND from configs/ctl_template_config.json "
                "/ configs/sap_balance_ctl_template.json.  "
                "Either configure the template OR remove the "
                "SapCreateCTLFile polling row from the workflow."
            )
        # Re-thread the loaded filename pattern into config so the
        # downstream filename build picks it up.
        if ctl_filename_template:
            config['ctl_filename'] = ctl_filename_template

        # Build {{FILENAME}} = data file base name WITHOUT extensions.
        # Per user spec 2026-06-07: abc.csv.gz <-> abc.ctl, MEBAL_2026_005.csv.gz <-> MEBAL_2026_005.ctl
        full_basename = os.path.basename(data_file)
        base_name = full_basename
        if base_name.endswith('.gz'):
            base_name = base_name[:-3]
        if base_name.endswith('.csv'):
            base_name = base_name[:-4]
        elif base_name.endswith('.parquet'):
            base_name = base_name[:-8]

        # Build substitution variables -- polling-row identifiers exposed
        # so the SAP balance CTL can carry the operator-visible IDs.
        run_id        = task.get('run_id') or task.get('RUN_ID') or ''
        run_detail_id = task.get('run_detail_id') or task.get('RUN_DETAIL_ID') or ''
        otg_dag_id    = task.get('otg_dag_id') or task.get('OTG_DAG_ID') or ''
        business_date = (
            task.get('business_date') or task.get('BUSINESS_DATE')
            or datetime.now().strftime('%Y-%m-%d')
        )
        task_id = (
            task.get('task_id') or task.get('TASK_ID')
            or run_detail_id or run_id
        )

        variables = {
            'FILENAME':          base_name,
            'FILENAME_FULL':     full_basename,   # for advanced use
            'FILEPATH':          data_file,
            'RECORD_COUNT':      str(task.get('totalcount', 0)),
            'CHECKSUM':          task.get('checksum', ''),
            'TIMESTAMP':         datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
            'DATE':              datetime.now().strftime('%Y-%m-%d'),
            'COMPRESSED_SIZE':   str(task.get('compressed_size', 0)),
            'UNCOMPRESSED_SIZE': str(task.get('uncompressed_size', 0)),
            'POPER':             task.get('p_poper', ''),
            'GJAHR':             task.get('p_gjahr', ''),
            'PERIOD_MODE':       config.get('period_mode', ''),
            'TASK_ID':           str(task_id),
            'RUN_ID':            str(run_id),
            'RUN_DETAIL_ID':     str(run_detail_id),
            'OTG_DAG_ID':        str(otg_dag_id),
            'BUSINESS_DATE':     str(business_date),
        }

        # Operator-defined extras
        variables.update(config.get('ctl_custom_variables', {}) or {})

        def _substitute(s):
            for key, value in variables.items():
                s = s.replace(f"{{{{{key}}}}}", str(value))
            return s

        # Build CTL filename -- substitute placeholders so
        # ``{{FILENAME}}.ctl`` resolves to ``MEBAL_2026_005.ctl``.
        # Without substitution the file was being written as
        # literal ``{{FILENAME}}.ctl`` (caught in smoke test).
        ctl_filename = config.get('ctl_filename', '')
        if ctl_filename:
            ctl_filename = _substitute(ctl_filename)
        if not ctl_filename:
            ctl_filename = f"{base_name}.ctl"

        output_dir = task.get('output_dir', os.path.dirname(data_file))
        ctl_path = os.path.join(output_dir, ctl_filename)

        ctl_content = _substitute(template)

        with open(ctl_path, 'w', encoding='utf-8') as f:
            f.write(ctl_content)

        self.logger.info(f"CTL file created: {ctl_path}")
        task['ctl_file'] = ctl_path

        # Hand off to Deliver / CheckCompleteness via sidecar.
        self._save_sidecar(task, config)

        return task.get('totalcount', 0)
