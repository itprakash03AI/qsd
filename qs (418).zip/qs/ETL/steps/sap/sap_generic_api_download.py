"""
SAP Generic API Download step.

Single-endpoint paginated extract — for SAP APIs (e.g. DocAPI) that:
  * are reachable as ONE URL with optional ``{YEAR}`` / ``{MONTH}`` /
    ``{TIMESTAMP}`` placeholders + arbitrary ``{key}`` substitutions
    from the polling row or JSON config;
  * have NO Companycode / partition column to fan out across;
  * follow standard OData v2 pagination (``$top`` / ``$skip`` or
    ``__next`` link) — exactly what ``_stream_odata_pages`` already
    understands.

The MEBAL-specific ``SapOdataDownload`` step is kept untouched.  This
step is a sibling — same ``SapOdataBase`` plumbing (auth, session,
rate limit, pagination, sink, run report, email) without the company-
code fetch + grouping + auto-discovery probe.

Downstream contract (matches what MEBAL emits):
  task['downloaded_files']   List[str]  — one entry: the single CSV/Parquet
  task['output_dir']          str        — the run subdir
  task['totalcount']          int        — streamed rows
  task['full_count']          int        — expected from $count (or same
                                            as totalcount when reconcile off)
  task['output_format']       str        — 'csv' | 'parquet'
  task['output_formats']      List[str]  — full list for consolidate
  task['p_gjahr']             str        — fiscal year (or '')
  task['p_poper']             str        — fiscal period (or '')
  task['run_subdir']          str        — same as output_dir
  task['completeness_ledger'] Dict       — keys: full_count, sum_expected,
                                            sum_actual, groups_total,
                                            period — so SapCheckCompleteness
                                            sees the same shape MEBAL emits.

The existing downstream steps (SapConsolidateFiles, SapCreateCTLFile,
SapCompressFiles, SapDeliverFiles, SapCheckCompleteness) require NO
changes — they already consume this shape.
"""
import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from steps.sap.sap_odata_base import SapOdataBase
from steps.sap.sap_odata_sinks import make_sink, file_extension_for
from steps.sap.sap_odata_report import RunReport


class SapGenericApiDownload(SapOdataBase):
    """Generic single-endpoint SAP OData/JSON API downloader."""

    LOG_PREFIX = "sap_generic_download"

    # Generic API needs three things on the polling row + an output dir.
    # Period / placeholder substitutions are OPTIONAL.
    REQUIRED_FIELDS = [
        'sap_username', 'sap_password',
        'sap_api_url',
        'output_dir',
    ]

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                             dest_connection_string: str, step_name: str,
                             *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        # Banner so an operator opening the log mid-batch sees the URL +
        # output location without scrolling.
        self.logger.info("=" * 72)
        self.logger.info("SAP Generic API download -- run context")
        self.logger.info("=" * 72)
        self.logger.info(f"  run_id       : {task.get('run_id')}")
        self.logger.info(f"  run_detail_id: {task.get('run_detail_id')}")
        self.logger.info(f"  fk_dag_id    : {task.get('fk_dag_id')}")
        self.logger.info(f"  fk_report_id : {task.get('fk_report_id')}")
        self.logger.info(f"  log_file     : {task.get('log_file', '<console>')}")
        self.logger.info(f"  sap_api_url  : {config.get('sap_api_url', '<unset>')}")
        _effective_top = self._resolve_page_size(config)
        self.logger.info(
            f"  page_size    : {_effective_top} "
            f"(requested {config.get('page_size', self.DEFAULT_TOP)}, "
            f"max {self.MAX_TOP})"
        )
        self.logger.info(
            f"  rate_limit   : {config.get('rate_limit_rps', self.DEFAULT_RATE_LIMIT_RPS)} rps"
        )
        self.logger.info(f"  output_dir   : {config.get('output_dir', '<unset>')}")
        self.logger.info(
            f"  output_format: {(config.get('output_format') or 'csv').lower()}"
        )
        self.logger.info("=" * 72)

        # Output format — same normalisation MEBAL uses.
        raw_fmt = (config.get("output_format") or "csv").strip().lower()
        fmt_parts = [p.strip() for p in raw_fmt.split(",") if p.strip()]
        bad = [p for p in fmt_parts if p not in ("csv", "parquet")]
        if bad:
            raise ValueError(
                f"OUTPUT_FORMAT {raw_fmt!r} contains unsupported values "
                f"{bad} -- expected 'csv', 'parquet', or 'csv,parquet'."
            )
        output_format = fmt_parts[0] if fmt_parts else "csv"
        config["output_format"] = output_format
        config["output_formats"] = fmt_parts

        # Run report — created BEFORE any HTTP work so a mid-fetch
        # exception still leaves a partial report on disk.
        report = RunReport(output_dir="", logger=self.logger)
        report.set_context(
            period="<TBD>",
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
            log_file=task.get("log_file", "<console>"),
        )
        report.set_urls(
            SAP_API_URL_TEMPLATE=config.get("sap_api_url", "<unset>"),
        )
        report.set_runtime_knobs(
            page_size_effective=_effective_top,
            page_size_requested=config.get("page_size", self.DEFAULT_TOP),
            max_top_ceiling=self.MAX_TOP,
            rate_limit_rps=config.get("rate_limit_rps", self.DEFAULT_RATE_LIMIT_RPS),
            output_format=output_format,
            output_formats=fmt_parts,
            verify_ssl=config.get("verify_ssl", True),
            intra_group_parallel=config.get("intra_group_parallel", 1),
        )

        email_cfg = self._extract_email_cfg(config)
        session = self._build_session(config)
        try:
            # 1. Resolve fiscal period (optional — kept for filename
            # templating downstream + the CTL ``POPER``/``GJAHR``
            # placeholders).  An API with no period uses empty strings.
            p_gjahr, p_poper = self._resolve_period(task, config)
            if p_gjahr or p_poper:
                self.logger.info(
                    f"Fiscal period: year={p_gjahr or '<n/a>'}, "
                    f"period={p_poper or '<n/a>'}"
                )

            # 2. Always-fresh cleanup (same posture MEBAL uses).
            self._force_fresh_cleanup(task, config)

            # 3. Create the run subdir.
            run_subdir = self._resolve_output_dir(
                task, config, p_gjahr=p_gjahr, p_poper=p_poper,
            )

            report.output_dir = run_subdir
            report.set_context(
                period=f"{p_gjahr or '-'}/{p_poper or '-'}",
                output_dir=run_subdir,
            )

            # 4. Build the API URL (placeholders substituted in).
            api_url = self._build_api_url(config, p_gjahr, p_poper, task)
            self.logger.info(f"Resolved API URL: {api_url}")
            report.set_urls(RESOLVED_API_URL=api_url)
            report.mark_started()
            report.write()
            report.send_email(email_cfg)

            # Persist sidecar EARLY so downstream steps can hydrate.
            task['run_subdir']    = run_subdir
            task['p_gjahr']       = p_gjahr
            task['p_poper']       = p_poper
            task['output_format'] = output_format
            task['output_formats'] = fmt_parts
            self._save_sidecar(task, config)

            # 5. Pre-flight $count (optional — flag-gated for APIs
            # without ``$count`` support).
            enable_reconcile = bool(config.get(
                'enable_count_reconcile', True,
            ))
            expected_count: Optional[int] = None
            if enable_reconcile:
                try:
                    count_url = self.derive_count_url(
                        api_url, {}, strip_filter=True,
                    )
                    self.logger.info(f"Pre-flight $count URL: {count_url}")
                    expected_count = self._fetch_odata_count(
                        session, count_url, config,
                    )
                    self.logger.info(
                        f"Expected row count from $count: "
                        f"{expected_count:,}"
                    )
                except Exception as exc:
                    self.logger.warning(
                        f"Pre-flight $count failed ({exc}) -- "
                        "continuing without reconcile.  Set "
                        "enable_count_reconcile=false in the JSON "
                        "config to silence this warning when the "
                        "API doesn't expose $count."
                    )
                    expected_count = None
            else:
                self.logger.info(
                    "enable_count_reconcile=false -- skipping $count "
                    "pre-flight"
                )

            # 6. Stream pages -> sink.
            file_root = self._build_file_root(
                task, config, p_gjahr, p_poper,
            )
            ext = file_extension_for(output_format)
            file_path = os.path.join(run_subdir, f"{file_root}.{ext}")
            self.logger.info(f"Streaming pages to: {file_path}")

            intra_parallel = max(1, int(config.get(
                'intra_group_parallel', 1,
            )))

            t0 = time.monotonic()
            sink = make_sink(file_path, output_format, logger=self.logger)
            try:
                if intra_parallel > 1 and expected_count and expected_count > 0:
                    page_iter = self._stream_odata_pages_parallel(
                        session, api_url, {}, config,
                        expected_count=expected_count,
                        parallel=intra_parallel,
                    )
                else:
                    page_iter = self._stream_odata_pages(
                        session, api_url, {}, config,
                        expected_count=expected_count,
                    )
                for _page_idx, results in page_iter:
                    sink.write_page(results)
                actual_count = sink.total_rows
            finally:
                sink.close()
            elapsed = time.monotonic() - t0

            self.logger.info(
                f"Streaming complete: {actual_count:,} rows in "
                f"{elapsed:.1f}s -> {file_path}"
            )

            # 7. Reconcile (when $count was available).
            self._reconcile_single_file(
                expected=expected_count, actual=actual_count,
                config=config,
            )

            # 8. Fail-loud on zero-row extract unless explicitly allowed
            # — matches MEBAL's safety net for masked auth failures.
            if actual_count == 0 and not config.get(
                'allow_empty_extract', False,
            ):
                raise ValueError(
                    "SAP Generic API download: 0 rows returned for "
                    f"URL {api_url}.  Likely an auth / filter / "
                    "wrong-period problem.  Set allow_empty_extract="
                    "true in the JSON config to bypass."
                )

            # 9. Populate the task dict so downstream steps work
            # unchanged.  ``downloaded_files`` is the list Consolidate
            # iterates — single entry for this single-endpoint step.
            task['downloaded_files'] = [file_path]
            task['output_dir']       = run_subdir
            task['totalcount']       = actual_count
            task['full_count']       = (expected_count
                                         if expected_count is not None
                                         else actual_count)
            task['output_format']    = output_format
            task['p_gjahr']          = p_gjahr
            task['p_poper']          = p_poper

            # Same completeness-ledger shape MEBAL emits — re-used by
            # SapCheckCompleteness without modification.
            task['completeness_ledger'] = {
                'full_count':   task['full_count'],
                'sum_expected': task['full_count'],
                'sum_actual':   actual_count,
                'groups_total': 1,
                'period':       f"{p_gjahr or '-'}/{p_poper or '-'}",
            }

            self._log_completeness_ledger_single(
                full_count=task['full_count'],
                actual_count=actual_count,
                file_path=file_path,
                period=f"{p_gjahr or '-'}/{p_poper or '-'}",
            )

            # Persist FINAL sidecar — downstream steps hydrate from it.
            self._save_sidecar(task, config)

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    'UPDATE_TASK_RECORDCOUNT', step_name,
                    actual_count, "", worker_connection_string,
                )

            # Report — single "group" entry so the HTML grid renders
            # the same shape it does for MEBAL.
            report.add_group_result({
                'group_idx':      0,
                'codes':          [],
                'expected_count': task['full_count'],
                'row_count':      actual_count,
                'file_path':      file_path,
                'attempts':       1,
            })
            report.set_counts(
                full_count=task['full_count'],
                sum_expected=task['full_count'],
                sum_actual=actual_count,
            )
            report.add_output_file(file_path)
            if enable_reconcile and expected_count is not None:
                report.set_urls(
                    COUNT_URL=self.derive_count_url(
                        api_url, {}, strip_filter=True,
                    ),
                )
            report.mark_success()
            return actual_count

        except Exception as e:
            self.logger.error(
                f"SAP Generic API download failed: {e}", exc_info=True,
            )
            try:
                report.mark_failed(error_message=f"{type(e).__name__}: {e}")
            except Exception:
                pass
            raise
        finally:
            try:
                report.write()
            except Exception as wexc:
                self.logger.warning(
                    "Could not persist run_report: %s", wexc,
                )
            try:
                report.send_email(email_cfg)
            except Exception as eexc:
                self.logger.warning(
                    "Could not send finish email: %s -- run continues",
                    eexc,
                )
            session.close()

    # ── Helpers ────────────────────────────────────────────────────

    def _extract_email_cfg(self, config: Dict) -> Dict[str, Any]:
        """Same shape MEBAL uses — kept inline so this step doesn't
        depend on importing private helpers from SapOdataDownload."""
        send = config.get("send_email", False)
        if isinstance(send, str):
            send = send.strip().upper() in ("TRUE", "1", "YES", "Y")
        return {
            "send_email":    bool(send),
            "smtp_host":     config.get("smtp_host", ""),
            "smtp_port":     int(config.get("smtp_port", 25) or 25),
            "smtp_user":     config.get("smtp_user", ""),
            "smtp_password": config.get("smtp_password", ""),
            "smtp_use_tls":  bool(config.get("smtp_use_tls", False)),
            "email_from":    config.get("email_from", ""),
            "email_to":      config.get("email_to", ""),
            "email_subject": config.get("email_subject", ""),
        }

    def _resolve_period(
        self, task: Dict, config: Dict,
    ) -> tuple:
        """Resolve (p_gjahr, p_poper) from the polling row or derive
        from ``period_mode``.  Empty strings are valid — many generic
        APIs don't model fiscal periods at all.
        """
        row_year  = task.get('p_gjahr') or task.get('P_GJAHR')
        row_month = task.get('p_poper') or task.get('P_POPER')
        if row_year not in (None, "") and row_month not in (None, ""):
            p_gjahr = str(row_year).strip()
            try:
                p_poper = f"{int(row_month):03d}"
            except (TypeError, ValueError):
                p_poper = str(row_month).strip()
            return p_gjahr, p_poper
        # No row override — derive only when period_mode is configured.
        # Generic APIs without fiscal periods will leave this unset.
        period_mode = config.get('period_mode')
        if period_mode:
            try:
                return self._derive_fiscal_period(period_mode)
            except Exception as exc:
                self.logger.warning(
                    f"Period derivation failed ({exc}) -- continuing "
                    "with empty period (file templates that reference "
                    "{GJAHR}/{POPER} will get '')."
                )
        return "", ""

    def _force_fresh_cleanup(self, task: Dict, config: Dict) -> None:
        """Wipe prior sidecar + run_subdir for this RUN_ID — same
        always-fresh posture MEBAL uses.  Best-effort: log warnings
        on permission errors but never raise."""
        import shutil
        from steps.sap.sap_odata_state import load_state, state_path

        base = config.get('output_dir') or ''
        run_id = task.get('run_id') or task.get('RUN_ID')
        if not base or run_id is None:
            return
        self.logger.info(
            "Always-fresh: wiping any prior state for run_id=%s",
            run_id,
        )
        state = load_state(base, run_id, logger=self.logger)
        if state and state.get('run_subdir'):
            prior = state['run_subdir']
            if os.path.isdir(prior):
                try:
                    shutil.rmtree(prior)
                    self.logger.warning("  removed prior run_subdir: %s", prior)
                except OSError as exc:
                    self.logger.warning(
                        "  could not rmtree %s: %s", prior, exc,
                    )
        sidecar = state_path(base, run_id)
        if os.path.exists(sidecar):
            try:
                os.remove(sidecar)
                self.logger.warning("  removed prior sidecar: %s", sidecar)
            except OSError as exc:
                self.logger.warning(
                    "  could not remove %s: %s", sidecar, exc,
                )

    def _resolve_output_dir(
        self, task: Dict, config: Dict,
        p_gjahr: Optional[str], p_poper: Optional[str],
    ) -> str:
        """Always-fresh: every run creates a NEW timestamped subdir.
        Same shape MEBAL produces so downstream steps see the same
        layout."""
        root = config['output_dir']
        gjahr = p_gjahr or 'NA'
        poper = p_poper or 'NA'
        subdir = os.path.join(
            root,
            f"{gjahr}_{poper}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        )
        os.makedirs(subdir, exist_ok=True)
        return subdir

    def _build_api_url(
        self, config: Dict,
        p_gjahr: str, p_poper: str,
        task: Optional[Dict] = None,
    ) -> str:
        """Substitute placeholders into ``sap_api_url``.

        Honoured placeholders:
          * ``{YEAR}``      → p_gjahr
          * ``{MONTH}``     → p_poper
          * ``{TIMESTAMP}`` → polling-row RUN_TIMESTAMP or live UTC clock
          * ``{<KEY>}``     → any key from ``config['url_substitutions']``
                              (UPPER-CASED) OR from the polling row.

        ``str.replace`` is a no-op on placeholders not in the URL, so
        the simplest case ("URL has no placeholders at all, polling row
        carries the fully-bound URL") works without configuration.
        """
        url = str(config.get('sap_api_url') or '')
        timestamp = (
            (config.get('run_timestamp') or "").strip()
            or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        )
        url = (url
               .replace("{YEAR}",      p_gjahr or "")
               .replace("{MONTH}",     p_poper or "")
               .replace("{TIMESTAMP}", timestamp))

        # Arbitrary substitutions — config-driven first, then anything
        # the polling row carries under task['url_substitutions'].
        extra: Dict[str, Any] = {}
        cfg_subs = config.get('url_substitutions')
        if isinstance(cfg_subs, dict):
            extra.update(cfg_subs)
        if task is not None:
            task_subs = task.get('url_substitutions')
            if isinstance(task_subs, dict):
                extra.update(task_subs)
        for key, val in extra.items():
            placeholder = "{" + str(key).upper() + "}"
            url = url.replace(placeholder, str(val))

        return url

    def _build_file_root(
        self, task: Dict, config: Dict,
        p_gjahr: str, p_poper: str,
    ) -> str:
        """Resolve the consolidated filename root.  Same precedence
        order MEBAL's consolidate step uses — task['file_name'] from
        the polling row wins, else config, else a sensible default.
        """
        cand = (task.get('file_name') or task.get('FILE_NAME')
                or config.get('file_name')
                or config.get('consolidated_filename'))
        if cand:
            return (str(cand)
                    .replace('{GJAHR}', p_gjahr or '')
                    .replace('{POPER}', p_poper or '')
                    .replace('{YEAR}',  p_gjahr or '')
                    .replace('{MONTH}', p_poper or ''))
        # Default — readable name that includes the period when present
        # so re-runs don't clobber each other in the same output_dir.
        if p_gjahr and p_poper:
            return f"sap_extract_{p_gjahr}_{p_poper}"
        return f"sap_extract_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    def _reconcile_single_file(
        self, *, expected: Optional[int], actual: int, config: Dict,
    ) -> None:
        """Same fail-loud semantics MEBAL uses, but on the single file
        (no group sum).  ``allow_count_mismatch=true`` in the JSON
        config bypasses for legitimate cases (late-arriving postings
        between $count and $top fetches)."""
        if expected is None:
            self.logger.info(
                "Reconcile SKIPPED ($count was not available) -- "
                f"actual rows: {actual:,}"
            )
            return
        if actual == expected:
            self.logger.info(
                f"Reconcile OK: expected={expected:,} == actual={actual:,}"
            )
            return
        msg = (
            f"SAP generic API completeness check failed: "
            f"$count={expected:,} != streamed={actual:,} "
            f"(delta {actual - expected:+,})"
        )
        if bool(config.get('allow_count_mismatch', False)):
            self.logger.warning(
                msg + " -- proceeding per allow_count_mismatch=true"
            )
            return
        raise ValueError(msg)

    def _log_completeness_ledger_single(
        self, *, full_count: int, actual_count: int,
        file_path: str, period: str,
    ) -> None:
        """Single-row ledger that mirrors MEBAL's multi-group ledger —
        an operator opening the log sees the same shape regardless of
        which downloader ran."""
        ok = "[OK]   "
        bad = "[FAIL] "
        g1_ok = (actual_count == full_count) or full_count == 0
        self.logger.info("=" * 72)
        self.logger.info(
            "SAP completeness ledger -- period %s (single-endpoint download)",
            period,
        )
        self.logger.info("=" * 72)
        self.logger.info(f"  G1 full $count             : {ok}{full_count:,}")
        self.logger.info(
            f"  G2 actual streamed == G1    : "
            f"{ok if g1_ok else bad}{actual_count:,} vs {full_count:,} "
            f"(delta {actual_count - full_count:+,})"
        )
        self.logger.info(f"  G3 output file              : {ok}{file_path}")
        self.logger.info("=" * 72)
