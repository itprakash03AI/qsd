"""SAP-flow consolidate-files step.

Self-contained -- no inheritance from the generic ``ConsolidateFiles``.
Inherits only from ``SapOdataBase`` for the SAP-specific config loader
+ logger setup.

Merges per-group CSV files (one per company-code group produced by
SapOdataDownload) into a single consolidated CSV.  Honours optional
column-mapping JSON for SAP->target schema rename / drop / reorder.

Default output delimiter is ``|`` (pipe) so the file matches the CTL
template's ``csv-separator:|`` advertisement.
"""
import csv
import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from steps.sap.sap_odata_base import SapOdataBase


def pa_table_from_batch(batch):
    """Adapt a ``pyarrow.RecordBatch`` to a one-batch ``pyarrow.Table``.

    Inline so we don't import pyarrow at module-load time (slow on
    Windows / pod-cold-start where the SAP step may not run).
    """
    import pyarrow as pa
    return pa.Table.from_batches([batch])


class SapConsolidateFiles(SapOdataBase):
    """Merge SAP per-group CSVs into one consolidated CSV / parquet."""

    LOG_PREFIX = "sap_consolidate_files"

    REQUIRED_FIELDS: List[str] = []

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str,
                            *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        # Cross-step state handoff: download wrote its results to a
        # sidecar keyed by run_id; we read it here so the task dict
        # picks up downloaded_files / output_dir / etc. from the
        # PREVIOUS polling row's run.
        self._hydrate_from_sidecar(task, config)

        downloaded_files = task.get('downloaded_files', [])
        if not downloaded_files:
            raise ValueError(
                "No downloaded files in task -- SapOdataDownload must run "
                "first AND must have written its sidecar to OUTPUT_DIR.  "
                f"Sidecar location attempted: "
                f"{config.get('output_dir')}/_sap_state_{task.get('run_id')}.json"
            )

        # Persist consolidate's output back to the sidecar so Compress /
        # CTL / Deliver / CheckCompleteness pick it up on their separate
        # task dicts.  (saved AFTER the merge, below.)

        # Drop empty marker files (zero-expected groups land as 0-byte
        # files so the checkpoint resolves -- see SapOdataDownload).
        non_empty_files = [
            f for f in downloaded_files
            if os.path.exists(f) and os.path.getsize(f) > 0
        ]
        if not non_empty_files:
            self.logger.warning(
                "All downloaded group files are empty (full_count=%s) -- "
                "writing empty consolidated file",
                task.get('full_count', '?'),
            )

        output_dir = task.get('output_dir', config.get('output_dir', ''))
        if not output_dir:
            raise ValueError("output_dir not set in task or config")

        p_gjahr = task.get('p_gjahr', '')
        p_poper = task.get('p_poper', '')
        # Group-file format is what the download step actually wrote.
        group_format = (
            task.get('output_format')
            or config.get('output_format')
            or 'csv'
        ).strip().lower()
        # Consolidated formats: download step may have populated
        # ``output_formats`` (list) from a comma-separated OUTPUT_FORMAT
        # row value ('csv,parquet').  When both are listed we produce
        # ONE consolidated file per format and CTL points at the
        # first listed (CSV is the default contract).
        formats_list = task.get('output_formats') or config.get('output_formats')
        if not formats_list:
            single = (
                config.get('consolidated_format') or group_format
            ).strip().lower()
            formats_list = [single]
        formats_list = [f.strip().lower() for f in formats_list if f.strip()]

        # CTL template advertises csv-separator:| so the data file must
        # match.  Per-group sources come from _paginated_odata_to_csv
        # which writes the standard `,`.
        consolidated_delim = config.get('consolidated_csv_delimiter', '|')
        source_delim = config.get('source_csv_delimiter', ',')

        # 2026-06-07 -- filename source precedence (highest wins):
        #   1. polling-row FILE_NAME column     (operator-controlled via DB)
        #   2. polling-row CTL_FILE_NAME column (back-compat -- some
        #      tenants populate CTL_FILE_NAME only)
        #   3. JSON config ``consolidated_filename`` template (legacy)
        #   4. Default template ``MEBAL_{GJAHR}_{POPER}``
        #
        # Placeholders {GJAHR}/{POPER}/{DATE} substitute in all paths
        # so operators can parameterise via DB.
        #
        # LOUD DIAGNOSTIC: log every candidate value the code saw so a
        # mismatch between "what the operator put in the row" and
        # "what the step picked up" is immediately visible.
        cand_file_name      = task.get('file_name') or task.get('FILE_NAME')
        cand_ctl_file_name  = task.get('ctl_file_name') or task.get('CTL_FILE_NAME')
        cand_config         = config.get('consolidated_filename')
        self.logger.info(
            "Filename candidates seen: task['file_name']=%r, "
            "task['ctl_file_name']=%r, config['consolidated_filename']=%r, "
            "default='MEBAL_{GJAHR}_{POPER}'",
            cand_file_name, cand_ctl_file_name, cand_config,
        )
        # Also dump the polling-row column keys so an operator can
        # confirm FILE_NAME IS in the result set (and not just NULL).
        sap_keys = sorted(
            k for k in task.keys()
            if any(tag in k.lower()
                   for tag in ('file', 'task_steps', 'run_id'))
        )
        self.logger.info(
            "Polling-row task keys (filename / task / id columns): %s",
            {k: task.get(k) for k in sap_keys},
        )

        file_name_from_row = (
            cand_file_name or cand_ctl_file_name or ''
        )
        # Strip blanks / whitespace-only strings -- treat them as NOT set
        file_name_from_row = (
            str(file_name_from_row).strip()
            if file_name_from_row else ''
        )

        if file_name_from_row:
            filename_template = file_name_from_row
            # Strip extension if operator included one (we add the
            # extension per format below).
            for ext in ('.csv.gz', '.csv', '.parquet', '.gz'):
                if filename_template.lower().endswith(ext):
                    filename_template = filename_template[:-len(ext)]
                    break
            self.logger.info(
                "Consolidated filename source: polling-row "
                "FILE_NAME/CTL_FILE_NAME -> %r",
                filename_template,
            )
        else:
            filename_template = (
                cand_config or 'MEBAL_{GJAHR}_{POPER}'
            )
            self.logger.warning(
                "Consolidated filename source: FALLBACK to %r "
                "(NEITHER polling-row FILE_NAME nor CTL_FILE_NAME "
                "carried a value).  Populate FILE_NAME on the polling "
                "row to control the output filename via DB.",
                filename_template,
            )
        # Substitute placeholders (works for both row and template paths)
        filename = (
            filename_template
            .replace('{GJAHR}', str(p_gjahr))
            .replace('{POPER}', str(p_poper))
            .replace('{DATE}', __import__('datetime').datetime.now().strftime('%Y%m%d'))
        )

        mapping_spec = self._load_column_mapping(config.get('column_mapping_path'))
        if mapping_spec:
            self.logger.info(
                "Column mapping loaded: %d renames, %d drops, %s ordering",
                len(mapping_spec.get("column_mapping") or {}),
                len(mapping_spec.get("drop_columns") or []),
                "explicit" if mapping_spec.get("column_order") else "natural",
            )

        # Iterate -- one consolidated file per requested output format.
        # When formats_list == ['csv','parquet'] we get BOTH files in
        # the same output_dir, sharing the same row content but in
        # different physical formats.  The first format wins as
        # ``consolidated_file`` so downstream (Compress, CTL, Deliver)
        # have a single canonical pointer; the additional formats
        # land on ``consolidated_files`` (plural) for ops to ship
        # alongside via the delivery step's multi-file mode.
        consolidated_paths: List[str] = []
        total_rows = 0
        for fmt in formats_list:
            output_path = os.path.join(output_dir, f"{filename}.{fmt}")
            # Pre-flight: writeability + handle stale files.  If a
            # prior failed run left this file on disk and it's locked
            # / read-only / owned by another user, the merge would
            # blow up mid-stream with a cryptic Errno 13.  Catch it
            # NOW with full diagnostic context.
            self._preflight_writeable(output_path)
            self.logger.info(
                "Consolidating %d files (%d non-empty) into %s "
                "(group_format=%s, out_format=%s)",
                len(downloaded_files), len(non_empty_files), output_path,
                group_format, fmt,
            )
            if group_format == 'csv' and fmt == 'csv':
                rows = self._merge_csv_files(
                    non_empty_files, output_path,
                    mapping_spec=mapping_spec,
                    source_delim=source_delim,
                    output_delim=consolidated_delim,
                    # Default WITH BOM (utf-8-sig) -- matches C#
                    # StreamWriter default + helps Excel auto-detect.
                    # Flip to false in JSON config ``csv_write_bom``
                    # to drop the 3-byte BOM if your receiver rejects it.
                    write_bom=bool(config.get('csv_write_bom', True)),
                )
            elif group_format == 'parquet' and fmt == 'parquet':
                rows = self._merge_parquet_files(
                    non_empty_files, output_path, mapping_spec=mapping_spec,
                )
            elif group_format == 'csv' and fmt == 'parquet':
                rows = self._csv_groups_to_parquet(
                    non_empty_files, output_path,
                    mapping_spec=mapping_spec,
                    source_delim=source_delim,
                )
            else:  # parquet -> csv
                rows = self._parquet_groups_to_csv(
                    non_empty_files, output_path,
                    mapping_spec=mapping_spec,
                    output_delim=consolidated_delim,
                )
            consolidated_paths.append(output_path)
            # Each format MUST yield identical row count -- a divergence
            # between csv and parquet outputs would be a serializer bug.
            if total_rows == 0:
                total_rows = rows
            elif rows != total_rows:
                raise ValueError(
                    f"SapConsolidateFiles: format {fmt!r} produced "
                    f"{rows:,} rows but earlier format produced "
                    f"{total_rows:,}.  Serializer / reader bug -- "
                    f"investigate {output_path}."
                )

        # Canonical pointer for downstream (Compress, CTL, Deliver).
        output_path = consolidated_paths[0]

        # -- Consolidation row-count guard --------------------------
        # The download step's per-group reconcile already proved
        # ``Sum(actual rows on disk) == full_count``.  Consolidation
        # here just re-stages those rows into one file -- if its row
        # count diverges from the download-stage total, the merge
        # logic is dropping rows (most commonly: a CSV row with
        # embedded newlines, or a column-mapping config that
        # accidentally filtered out a column the row depended on).
        download_total = task.get('totalcount')
        if download_total is not None:
            try:
                download_total = int(download_total)
            except (TypeError, ValueError):
                download_total = None
        if download_total is not None and total_rows != download_total:
            msg = (
                f"SapConsolidateFiles: merged {total_rows:,} rows but "
                f"download recorded {download_total:,} rows across "
                f"{len(non_empty_files)} group files.  Consolidation "
                f"lost / duplicated rows."
            )
            if not bool(config.get('allow_count_mismatch', False)):
                raise ValueError(msg)
            self.logger.warning(msg + " -- proceeding per allow_count_mismatch=true")

        self.logger.info(
            f"Consolidated {total_rows} rows into {len(consolidated_paths)} "
            f"file(s): {consolidated_paths}"
        )
        task['consolidated_file'] = output_path           # canonical (first)
        task['consolidated_files'] = consolidated_paths    # full list
        task['totalcount'] = total_rows

        # Hand off to the next polling-row's task dict via sidecar.
        self._save_sidecar(task, config)

        if config.get('delete_group_files', True):
            for f in downloaded_files:
                try:
                    os.remove(f)
                except OSError:
                    pass

        return total_rows

    def _preflight_writeable(self, path: str) -> None:
        """Verify ``path`` can be written + diagnose Errno 13 LOUDLY.

        Catches the failure case the operator hit on 2026-06-07
        (``Permission denied: MEBAL_2026_006.csv`` with no detail):

          * Existing file from prior failed run -> attempt to remove
            it.  Log what happened.
          * Existing file locked (Windows) / read-only / wrong owner
            -> raise with full diagnostic: path, size, mtime, owner,
            mode, and the suggested fix (FORCE_FRESH_RUN=true OR
            manual rm of the stale file).
        """
        import stat
        target_dir = os.path.dirname(path) or '.'
        # 1. Directory must exist + be writable
        if not os.path.isdir(target_dir):
            try:
                os.makedirs(target_dir, exist_ok=True)
            except OSError as exc:
                raise ValueError(
                    f"SapConsolidateFiles: output dir {target_dir!r} "
                    f"does not exist and cannot be created: {exc}.  "
                    f"Check OUTPUT_DIR on the polling row."
                )
        if not os.access(target_dir, os.W_OK):
            try:
                st = os.stat(target_dir)
                mode = stat.filemode(st.st_mode)
            except OSError:
                mode = '<unreadable>'
            raise ValueError(
                f"SapConsolidateFiles: output dir {target_dir!r} is NOT "
                f"writable (mode {mode}).  Pod / user lacks write "
                f"permission.  Fix: chmod +w the dir OR change "
                f"OUTPUT_DIR on the polling row to a writable location."
            )

        # 2. If the target file already exists, try to remove it first.
        if not os.path.exists(path):
            return  # nothing in the way
        try:
            st = os.stat(path)
            existing_size = st.st_size
            existing_mtime = datetime.fromtimestamp(st.st_mtime).isoformat()
            existing_mode = stat.filemode(st.st_mode)
            try:
                import pwd
                owner = pwd.getpwuid(st.st_uid).pw_name
            except (ImportError, KeyError, AttributeError):
                owner = f"uid={getattr(st, 'st_uid', '?')}"
        except OSError:
            existing_size = '?'
            existing_mtime = '?'
            existing_mode = '?'
            owner = '?'

        self.logger.warning(
            "Found existing target file from prior run: %s "
            "(size=%s, mtime=%s, mode=%s, owner=%s) -- attempting to remove",
            path, existing_size, existing_mtime, existing_mode, owner,
        )
        try:
            os.remove(path)
            self.logger.info("Stale target file removed; proceeding")
            return
        except OSError as exc:
            # Can't delete it -- file is locked or we don't own it.
            # Raise NOW with the full context instead of letting the
            # subsequent ``open(path, 'w')`` blow up with a cryptic
            # Errno 13.
            import traceback
            raise ValueError(
                f"SapConsolidateFiles: cannot write to {path!r} -- "
                f"a stale file from a prior failed run is in the way "
                f"and CANNOT be removed: {type(exc).__name__}: {exc}.  "
                f"Existing file details: size={existing_size}, "
                f"mtime={existing_mtime}, mode={existing_mode}, "
                f"owner={owner}.  Fixes (try in order):\n"
                f"  1. Set FORCE_FRESH_RUN='TRUE' on the polling row "
                f"-- wipes prior state for this RUN_ID.\n"
                f"  2. Manually delete the file: rm -f {path!r}\n"
                f"  3. Check if another process holds the file "
                f"(Windows: Resource Monitor; Linux: lsof {path!r}).\n"
                f"  4. Confirm pod / user owns the file (chown if "
                f"needed)."
            )

    # -- column-mapping helpers -----------------------------------------

    def _load_column_mapping(self, path: Optional[str]) -> Dict[str, Any]:
        if not path:
            return {}
        if not os.path.exists(path):
            self.logger.warning(
                "column_mapping_path %s does not exist -- using verbatim columns", path,
            )
            return {}
        try:
            with open(path, 'r', encoding='utf-8') as f:
                spec = json.load(f)
            if not isinstance(spec, dict):
                self.logger.warning("column_mapping JSON is not a dict -- ignoring")
                return {}
            return spec
        except Exception as exc:
            self.logger.warning(
                "could not read column_mapping %s: %s -- using verbatim columns",
                path, exc,
            )
            return {}

    def _resolve_header(
        self, source_header: List[str], mapping_spec: Dict[str, Any],
    ) -> tuple:
        if not mapping_spec:
            return source_header, list(range(len(source_header)))

        rename = mapping_spec.get("column_mapping") or {}
        drop_set = set(mapping_spec.get("drop_columns") or [])
        explicit_order = mapping_spec.get("column_order")

        renamed: List[tuple] = []
        for idx, src_name in enumerate(source_header):
            if src_name in drop_set:
                continue
            target_name = rename.get(src_name, src_name)
            if target_name in drop_set:
                continue
            renamed.append((target_name, idx))

        if explicit_order:
            by_target = {t: idx for t, idx in renamed}
            target_header: List[str] = []
            source_index_by_target: List[int] = []
            for t in explicit_order:
                if t in by_target:
                    target_header.append(t)
                    source_index_by_target.append(by_target[t])
                else:
                    self.logger.warning(
                        "column_order references %r but it's not in the "
                        "renamed source columns -- skipped", t,
                    )
            return target_header, source_index_by_target

        target_header = [t for t, _ in renamed]
        source_index_by_target = [idx for _, idx in renamed]
        return target_header, source_index_by_target

    # -- CSV / Parquet merge --------------------------------------------

    def _merge_csv_files(
        self, files: List[str], output_path: str,
        mapping_spec: Optional[Dict[str, Any]] = None,
        source_delim: str = ',',
        output_delim: str = '|',
        write_bom: bool = True,
    ) -> int:
        """Stream-merge per-group CSVs into one consolidated CSV.

        2026-06-07 rewrite -- uses DictReader/DictWriter with a UNION
        master header so cross-group column-order or column-presence
        differences DON'T misalign rows.  Pre-fix positional
        csv.writer trusted the first file's header for every file;
        when group N's CSV had a different column order than group 0,
        rows N's values landed under wrong column names.

        Algorithm:
          1. Scan headers from EVERY input file (cheap, one line each).
          2. Build a sorted UNION master header.  Apply column_mapping
             rename + drop here so the output respects mapping_spec.
          3. Re-open each file as ``csv.DictReader`` and stream rows
             into a ``csv.DictWriter`` keyed on the master header.
             Missing keys land as empty cells (NOT misaligned ones).
        """
        mapping_spec = mapping_spec or {}
        rename = (mapping_spec.get("column_mapping") or {})
        drop_set = set(mapping_spec.get("drop_columns") or [])

        # --- Pass 1: collect master header from every file -----------
        master_keys: Dict[str, None] = {}
        non_empty = []
        for fp in files:
            if not os.path.exists(fp) or os.path.getsize(fp) == 0:
                self.logger.warning(f"File not found / empty, skipping: {fp}")
                continue
            try:
                with open(fp, 'r', newline='', encoding='utf-8') as in_f:
                    reader = csv.reader(in_f, delimiter=source_delim)
                    header = next(reader, None)
                if not header:
                    self.logger.warning(f"No header in {fp}, skipping")
                    continue
                non_empty.append(fp)
                for col in header:
                    target = rename.get(col, col)
                    if col in drop_set or target in drop_set:
                        continue
                    master_keys.setdefault(target, None)
            except Exception as exc:
                self.logger.warning(f"Could not read header from {fp}: {exc}")

        if not non_empty:
            # Empty consolidated file -- header-less, downstream
            # will catch via min_record_count guard.
            open(output_path, 'w', encoding='utf-8').close()
            return 0

        # Respect explicit column_order if mapping_spec carries one
        explicit_order = mapping_spec.get("column_order")
        if explicit_order:
            master_header = [c for c in explicit_order if c in master_keys]
            # Append any master_keys not listed (defensive -- never drop data)
            for k in master_keys:
                if k not in master_header:
                    master_header.append(k)
        else:
            master_header = sorted(master_keys.keys())

        self.logger.info(
            "Consolidate: master header has %d columns (union across "
            "%d non-empty source files): %s",
            len(master_header), len(non_empty),
            ", ".join(master_header[:8])
            + ("..." if len(master_header) > 8 else ""),
        )

        # --- Pass 2: stream rows into the master ---------------------
        # Default to ``utf-8-sig`` (UTF-8 with BOM) -- mirrors C#'s
        # default StreamWriter behavior + lets Excel / Windows tools
        # auto-detect encoding so they don't treat the CSV as a binary
        # "QQ_File".  Operator can disable via config ``csv_write_bom: false``.
        bom_encoding = 'utf-8-sig' if write_bom else 'utf-8'
        total_rows = 0
        try:
            out_f = open(output_path, 'w', newline='', encoding=bom_encoding)
        except PermissionError as exc:
            # Errno 13 here = the preflight passed but the file got
            # locked between then and now (race) OR pre-flight skipped
            # because we hit the legacy code path.  Re-diagnose.
            self._preflight_writeable(output_path)
            # If preflight returns OK, retry once
            try:
                out_f = open(output_path, 'w', newline='', encoding='utf-8')
            except PermissionError as exc2:
                raise ValueError(
                    f"SapConsolidateFiles: PermissionError on "
                    f"{output_path!r} even after preflight removal.  "
                    f"Original: {exc}.  Retry: {exc2}.  "
                    f"File may be held open by another process."
                )
        with out_f:
            writer = csv.DictWriter(
                out_f, fieldnames=master_header,
                delimiter=output_delim, extrasaction='ignore',
            )
            writer.writeheader()
            for fp in non_empty:
                with open(fp, 'r', newline='', encoding='utf-8') as in_f:
                    reader = csv.DictReader(in_f, delimiter=source_delim)
                    file_rows = 0
                    for row in reader:
                        # Apply rename + drop per cell
                        renamed = {}
                        for k, v in row.items():
                            if k in drop_set:
                                continue
                            t = rename.get(k, k)
                            if t in drop_set:
                                continue
                            renamed[t] = v
                        writer.writerow(renamed)
                        file_rows += 1
                    total_rows += file_rows
                self.logger.info(f"Merged {fp} -> {file_rows:,} rows")

        return total_rows

    def _merge_parquet_files(
        self, files: List[str], output_path: str,
        mapping_spec: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Stream-merge parquet groups -> one parquet file.

        Uses ``ParquetWriter`` + per-file row-group writes so peak
        memory is one input file's row-group at a time (not the union).
        ``pa.concat_tables`` on the old path materialised everything;
        avoid for the large-extract case.
        """
        import pyarrow.parquet as pq

        existing = [f for f in files if os.path.exists(f) and os.path.getsize(f) > 0]
        if not existing:
            # Touch an empty file so downstream existence checks pass.
            open(output_path, 'w').close()
            return 0

        writer = None
        schema = None
        total = 0
        try:
            for path in existing:
                pf = pq.ParquetFile(path)
                for batch in pf.iter_batches():
                    table = self._apply_mapping_to_table(
                        batch.to_pandas() if False else pa_table_from_batch(batch),
                        mapping_spec,
                    )
                    if writer is None:
                        schema = table.schema
                        writer = pq.ParquetWriter(output_path, schema)
                    else:
                        if table.schema != schema:
                            table = table.cast(schema)
                    writer.write_table(table)
                    total += table.num_rows
        finally:
            if writer is not None:
                writer.close()
        return total

    @staticmethod
    def _apply_mapping_to_table(table, mapping_spec: Optional[Dict[str, Any]]):
        """Apply rename / drop / reorder to a pyarrow.Table."""
        if not mapping_spec:
            return table
        rename = mapping_spec.get("column_mapping") or {}
        drop_set = set(mapping_spec.get("drop_columns") or [])

        keep_idx = []
        new_names = []
        for i, c in enumerate(table.column_names):
            target = rename.get(c, c)
            if c in drop_set or target in drop_set:
                continue
            keep_idx.append(i)
            new_names.append(target)
        kept = table.select(keep_idx).rename_columns(new_names)

        explicit_order = mapping_spec.get("column_order")
        if explicit_order:
            in_order = [c for c in explicit_order if c in kept.column_names]
            if in_order:
                kept = kept.select(in_order)
        return kept

    def _csv_groups_to_parquet(
        self, files: List[str], output_path: str,
        mapping_spec: Optional[Dict[str, Any]] = None,
        source_delim: str = ',',
    ) -> int:
        """Cross-format: CSV groups -> single Parquet.

        Streams each group via ``csv.DictReader`` -> ``pa.Table`` ->
        ``ParquetWriter.write_table`` so we never load all groups into
        memory simultaneously.
        """
        import pyarrow as pa
        import pyarrow.parquet as pq

        writer = None
        schema = None
        total = 0
        first_header: Optional[List[str]] = None
        try:
            for path in files:
                if not os.path.exists(path) or os.path.getsize(path) == 0:
                    continue
                with open(path, 'r', encoding='utf-8', newline='') as f:
                    reader = csv.DictReader(f, delimiter=source_delim)
                    if first_header is None:
                        first_header = list(reader.fieldnames or [])
                    rows = list(reader)
                if not rows:
                    continue
                # Project + rename via mapping
                if mapping_spec:
                    rename = mapping_spec.get("column_mapping") or {}
                    drop_set = set(mapping_spec.get("drop_columns") or [])
                    projected = []
                    for r in rows:
                        out = {}
                        for k, v in r.items():
                            if k in drop_set:
                                continue
                            t = rename.get(k, k)
                            if t in drop_set:
                                continue
                            out[t] = v
                        projected.append(out)
                    rows = projected
                table = pa.Table.from_pylist(rows)
                if writer is None:
                    schema = table.schema
                    writer = pq.ParquetWriter(output_path, schema)
                else:
                    if table.schema != schema:
                        table = table.cast(schema)
                writer.write_table(table)
                total += table.num_rows
        finally:
            if writer is not None:
                writer.close()
        return total

    def _parquet_groups_to_csv(
        self, files: List[str], output_path: str,
        mapping_spec: Optional[Dict[str, Any]] = None,
        output_delim: str = '|',
    ) -> int:
        """Cross-format: Parquet groups -> single CSV.

        Streams each parquet via row-group iter so we only hold one
        row-group's rows in memory at a time.
        """
        import pyarrow.parquet as pq

        total = 0
        writer = None
        header: Optional[List[str]] = None
        with open(output_path, 'w', newline='', encoding='utf-8') as out_f:
            for path in files:
                if not os.path.exists(path) or os.path.getsize(path) == 0:
                    continue
                pf = pq.ParquetFile(path)
                for batch in pf.iter_batches():
                    table = self._apply_mapping_to_table(
                        pa_table_from_batch(batch), mapping_spec,
                    )
                    if writer is None:
                        header = list(table.column_names)
                        writer = csv.writer(out_f, delimiter=output_delim)
                        writer.writerow(header)
                    rows = table.to_pylist()
                    for r in rows:
                        writer.writerow([r.get(c, "") for c in header])
                    total += len(rows)
        return total
