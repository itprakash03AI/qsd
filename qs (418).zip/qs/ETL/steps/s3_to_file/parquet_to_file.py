"""Plain parquet -> file extract steps, per environment.

2026-06-22 -- per-environment classes mirroring the file-workflow
OnCloud / OnPrem split.  Back-compat path for non-iceberg parquet
reads (e.g., legacy datasets not yet onboarded to a catalog).

  ParquetToFile_OnCloud  -- AWS S3 parquet -> NFS file.
  ParquetToFile_OnPrem   -- On-prem S3 parquet -> NFS file.
"""
from __future__ import annotations

from steps.s3_to_file.s3_parquet_query_extract import S3ParquetQueryExtract


class ParquetToFile_OnCloud(S3ParquetQueryExtract):
    """AWS S3 parquet -> NFS file."""
    ENVIRONMENT = "oncloud"
    LOG_PREFIX = "parquet_to_file_oncloud"


class ParquetToFile_OnPrem(S3ParquetQueryExtract):
    """On-prem S3 parquet -> NFS file."""
    ENVIRONMENT = "onprem"
    LOG_PREFIX = "parquet_to_file_onprem"
