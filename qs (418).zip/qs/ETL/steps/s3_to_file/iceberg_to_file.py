"""Iceberg -> file extract steps, per environment.

2026-06-22 -- per-environment classes mirroring the file-workflow
``StarburstToFile_OnCloud`` / ``_OnPrem`` shape.  Each subclass sets
``ENVIRONMENT`` so ``S3BaseStep._load_and_validate_config`` picks the
right ``s3.<environment>`` section from ``configs/s3_config.yaml``.

  IcebergToFile_OnCloud  -- AWS S3 + REST iceberg catalog.  Today's
                            primary production path.
  IcebergToFile_OnPrem   -- On-prem S3 + iceberg catalog.  Inactive
                            today; activates when on-prem migrates
                            off Hive (see HiveToFile_OnPrem for the
                            current on-prem state).

Implementation inherits from the existing ``S3IcebergQueryExtract``
class -- only the ``ENVIRONMENT`` + ``LOG_PREFIX`` change so the per-
environment config + logs land in the right place.  When the two
environments need genuinely different code paths, override
``_execute_step`` in one of the subclasses below.
"""
from __future__ import annotations

from steps.s3_to_file.s3_iceberg_query_extract import S3IcebergQueryExtract


class IcebergToFile_OnCloud(S3IcebergQueryExtract):
    """AWS S3 iceberg -> NFS file."""
    ENVIRONMENT = "oncloud"
    LOG_PREFIX = "iceberg_to_file_oncloud"


class IcebergToFile_OnPrem(S3IcebergQueryExtract):
    """On-prem S3 iceberg -> NFS file.

    Inactive today; activates when the on-prem cluster migrates from
    Hive to iceberg.  Same Spark+Iceberg reader as OnCloud -- only
    the ``s3.onprem`` yaml section drives connection details.
    """
    ENVIRONMENT = "onprem"
    LOG_PREFIX = "iceberg_to_file_onprem"
