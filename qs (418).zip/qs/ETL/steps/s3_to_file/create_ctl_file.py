"""CreateControlFile — emit the CTL (control) file beside the gz payload.

ONE deliverable artefact per job: a small text file the downstream
consumer (e.g. OTG receiving system) reads to verify the gz payload's
identity / integrity.

Honours per-job ``ctl_file_format`` template strings with the
placeholders:

    {file_name}       — basename of the gz file
    {file_path}       — absolute path of the gz file
    {total_records}   — consolidated row count
    {md5_checksum}    — MD5 of the .gz file
    {sha256_checksum} — SHA256 of the .gz file
    {timestamp}       — current UTC timestamp ("YYYY-MM-DD HH:MM:SS")
    {date}            — current local date ("YYYY-MM-DD")
    {year} {month} {day}

The CTL is also logged to ``OTG_FILE_LOG`` via a stored procedure so
the operator can grep the DB for delivery history.  DB-log failure
does NOT fail the step — the file is on disk and the run report
captures the warning.

Failure mid-CTL leaves the gz payload alone; failure cleanup via
RunArtifacts will drop the CTL file but the operator can re-run the
step manually with the same gz.
"""
from __future__ import annotations

import logging
import os
import sys
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import RunArtifacts, get_or_create_artifacts, save_task_state


DEFAULT_CTL_TEMPLATE = (
    "File_Name,{file_name}\n"
    "Extract_Date,{date}\n"
    "Business_Close_Date,{date}\n"
    "Number_Of_Records,{total_records}\n"
    "MD5,{md5_checksum}\n"
    "SHA256,{sha256_checksum}\n"
)


class CreateControlFile(BaseStep):
    """Emit the CTL file per delivered job."""

    LOG_PREFIX = "create_ctl_file"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.artifacts: Optional[RunArtifacts] = None
        self.run_report: Optional[FileRunReport] = None

    def _setup_logging(self, task: Dict) -> None:
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            try:
                from log_config import get_log_dir as _ld
                base = _ld()
            except Exception:
                import tempfile
                base = tempfile.gettempdir()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log")
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError:
            pass

    @staticmethod
    def _render(template: str, replacements: Dict[str, Any]) -> str:
        out = template
        for k, v in replacements.items():
            out = out.replace("{" + k + "}", str(v))
        # Strip lingering _CLOUD / _ONPREM markers if they snuck through
        out = out.replace("_CLOUD.", ".").replace("_ONPREM.", ".")
        return out

    def _build_ctl_for(
        self, compress_result: Dict[str, Any],
        consolidation_lookup: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Any]:
        report_id = str(compress_result.get("report_id") or "")
        compressed_file = compress_result.get("compressed_file") or ""
        if not compressed_file or not os.path.exists(compressed_file):
            raise ValueError(
                f"CreateControlFile: compressed file not found for report_id={report_id}: "
                f"{compressed_file!r}"
            )

        ctl_dir = os.path.dirname(compressed_file)
        gz_name = os.path.basename(compressed_file)
        # Strip ".gz" then replace the data extension with ".ctl"
        base_no_gz = gz_name[:-3] if gz_name.endswith(".gz") else gz_name
        ctl_name = os.path.splitext(base_no_gz)[0] + ".ctl"
        ctl_path = os.path.join(ctl_dir, ctl_name)

        cr = consolidation_lookup.get(report_id, {})
        total_records = (
            cr.get("consolidated_rows") or compress_result.get("total_records") or 0
        )
        template = compress_result.get("control_template") or cr.get("control_template") or DEFAULT_CTL_TEMPLATE
        template = template or DEFAULT_CTL_TEMPLATE

        now = datetime.now()
        replacements = {
            "file_name": gz_name,
            "file_path": compressed_file,
            "total_records": total_records,
            "md5_checksum": compress_result.get("md5_checksum", ""),
            "sha256_checksum": compress_result.get("sha256_checksum", ""),
            "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "year": now.strftime("%Y"),
            "month": now.strftime("%m"),
            "day": now.strftime("%d"),
        }
        content = self._render(template, replacements)
        if not content.endswith("\n"):
            content += "\n"

        try:
            with open(ctl_path, "w", encoding="utf-8", newline="") as f:
                f.write(content)
        except Exception:
            if os.path.exists(ctl_path):
                try:
                    os.remove(ctl_path)
                except OSError:
                    pass
            raise

        self.logger.info(
            "CTL written: %s (records=%s, gz=%s)",
            ctl_path, total_records, compressed_file,
        )

        return {
            "report_id": report_id,
            "ctl_file": ctl_path,
            "compressed_file": compressed_file,
            "total_records": total_records,
            "status": "success",
        }

    async def _maybe_log_ctl_to_db(
        self, report_id: int, file_name: str, worker_connection_string: str,
    ) -> None:
        if not self.oracle_data_manager:
            return
        try:
            params = [
                {"name": "p_file_name", "value": file_name, "direction": "IN"},
                {"name": "p_report_id", "value": int(report_id), "direction": "IN"},
                {"name": "p_extract_start_date", "value": datetime.now(), "direction": "IN"},
                {"name": "p_extract_end_date", "value": datetime.now(), "direction": "IN"},
            ]
            await self.oracle_data_manager.execute_procedure_async(
                procedure_name="FIRE_DEV.OTG_UPSERT_FILE_LOG_TABLE",
                parameters=params,
                connection_string=worker_connection_string,
            )
            self.logger.info("OTG_FILE_LOG upserted for %s", file_name)
        except Exception as exc:
            self.logger.warning(
                "OTG_FILE_LOG upsert FAILED for %s: %s — continuing", file_name, exc,
            )

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        self.run_report = rr if isinstance(rr, FileRunReport) else None

        compress_results: List[Dict[str, Any]] = task.get("compress_results", []) or []
        if not compress_results:
            single = task.get("compressed_file")
            if not single:
                raise ValueError(
                    "CreateControlFile: no compress_results and no compressed_file "
                    "on task — CompressFile must run first."
                )
            compress_results = [{
                "compressed_file": single,
                "md5_checksum": task.get("md5_checksum", ""),
                "sha256_checksum": task.get("sha256_checksum", ""),
                "report_id": task.get("fk_report_id"),
                "total_records": task.get("totalcount") or task.get("consolidated_total"),
                "control_template": task.get("control_template", ""),
            }]

        # Look up consolidation results by report_id for total_records / template.
        consolidation_lookup: Dict[str, Dict[str, Any]] = {
            str(c.get("report_id")): c
            for c in (task.get("consolidation_results", []) or [])
        }

        results: List[Dict[str, Any]] = []
        for cr in compress_results:
            res = self._build_ctl_for(cr, consolidation_lookup)
            self.artifacts.add(res["ctl_file"], RunArtifacts.CTL)
            if self.run_report:
                self.run_report.add_output_file(res["ctl_file"])
            results.append(res)
            # DB log — best-effort
            try:
                rid = int(cr.get("report_id") or task.get("fk_report_id") or 0)
            except (TypeError, ValueError):
                rid = 0
            if rid:
                gz_name = os.path.basename(res["compressed_file"])
                # Strip suffix markers + the .gz so the DB log carries
                # the canonical file name.
                norm = gz_name.replace("_CLOUD", "").replace("_ONPREM", "")
                await self._maybe_log_ctl_to_db(rid, norm, worker_connection_string)

        task["ctl_results"] = results
        task["ctl_file"] = results[0]["ctl_file"] if results else ""
        task["artifact_paths"] = self.artifacts.snapshot()

        base_dir = task.get("output_dir") or (
            os.path.dirname(results[0]["ctl_file"]) if results else ""
        )
        if base_dir:
            save_task_state(task, base_dir, task.get("run_id"), logger=self.logger)
        if self.run_report:
            self.run_report.write()

        return results
