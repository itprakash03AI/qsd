import os
import time
import shutil
import hashlib
import logging
from typing import Dict, List, Any
from collections import defaultdict
from steps.BaseStep import BaseStep
import json

try:
    from log_config import build_module_logger
    logger = build_module_logger(__name__, "consolidate_files")
except Exception:  # log_config optional in some test envs
    logger = logging.getLogger(__name__)

class ConsolidateFiles(BaseStep):
    """Step to consolidate files from cloud and on-premises datasources."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.query_config = None

    def _load_query_config(self, file_location):
        """Load query configuration from JSON file"""
        query_config_path = file_location
        with open(query_config_path, "r") as f:
            return json.load(f)

    def _get_final_filename(self, original_filename: str) -> str:
        """Remove datasource suffix from filename"""
        if '_CLOUD.' in original_filename:
            return original_filename.replace('_CLOUD.', '.')
        elif '_ONPREM.' in original_filename:
            return original_filename.replace('_ONPREM.', '.')
        return original_filename

    def _merge_datasource_files(self, file_paths: List[str], final_output_path: str) -> int:
        try:
            start_time = time.time()
            total_records = 0
            header_written = False
            # FIX 1: Add progress tracking constant
            PROGRESS_INTERVAL = 10000  # Log every 10k records
            logger.info(f"Starting merge of {len(file_paths)} files into {final_output_path}")

            # 2026-06-18 -- ATOMIC PUBLISH pattern.  Prior code did
            # ``open(final_output_path, "w")`` directly which on Windows
            # truncates the existing file IN PLACE -- preserves its
            # creation time, so a re-run of the same job showed "created
            # yesterday, modified today" instead of being a fresh file.
            #
            # Fix: (1) back up the prior file via backup_if_exists (same
            # plumbing the per-source publish uses), (2) write to a
            # .merging tmp file, (3) os.replace to publish atomically.
            # Net: the published file has TODAY's creation time + the
            # prior run's file is preserved under backup_<ts>/ for
            # auditability.
            try:
                from steps.file.run_state import backup_if_exists as _bif
                _bif(final_output_path, mode="backup", logger=logger)
            except ImportError:
                pass
            except Exception as _bif_exc:
                logger.warning(
                    f"backup_if_exists for {final_output_path} "
                    f"failed (non-fatal): {_bif_exc}"
                )

            tmp_output_path = final_output_path + ".merging"
            if os.path.exists(tmp_output_path):
                try:
                    os.remove(tmp_output_path)
                except OSError:
                    pass
            with open(tmp_output_path, "w", newline="", encoding='utf-8') as outfile:
                for i, file_path in enumerate(file_paths):
                    # Validate file exists
                    if not os.path.exists(file_path):
                        logger.error(f"File not found during merge: {file_path}")
                        continue
                    logger.info(f"Processing file {i + 1}/{len(file_paths)}: {file_path}")
                    file_records = 0
                    # FIX 2: Process line by line instead of readlines()
                    with open(file_path, "r", newline="", encoding='utf-8') as infile:
                        # Read and handle header
                        header = infile.readline()
                        if not header:
                            logger.warning(f"Empty file skipped: {file_path}")
                            continue
                        # Write header only once
                        if not header_written:
                            outfile.write(header)
                            header_written = True
                            logger.info(f"Header written from {file_path}")
                        else:
                            logger.debug(f"Header skipped for {file_path}")

                        # FIX 3: Stream data line by line (memory efficient)
                        for line in infile:
                            outfile.write(line)
                            file_records += 1
                            total_records += 1
                            # FIX 4: Progress logging for large files
                            if total_records % PROGRESS_INTERVAL == 0:
                                logger.info(f"Progress: {total_records:,} records processed...")
                    logger.info(f"File {i + 1} completed: {file_records:,} records")
                    # FIX 5: Clean up source file with error handling
                    try:
                        os.remove(file_path)
                        logger.info(f"Removed source file: {file_path}")
                    except Exception as e:
                        logger.error(f"Could not remove source file {file_path}: {e}")

            # 2026-06-18 -- atomic publish to final path.  Tmp file has
            # TODAY's creation time; os.replace transfers that to the
            # destination so the published file is correctly stamped.
            try:
                os.replace(tmp_output_path, final_output_path)
                # Defeat Windows file-name TUNNELING (see
                # run_state.force_creation_time_now docstring).  NTFS
                # silently inherits the prior file's ctime when the
                # same name is reused within ~15 seconds; SetFileTime
                # explicitly overrides so re-runs show today's ctime.
                try:
                    from steps.file.run_state import (
                        force_creation_time_now as _fct,
                    )
                    _fct(final_output_path, logger=logger)
                except ImportError:
                    pass
                logger.info(
                    f"Atomically published merged file to {final_output_path} "
                    f"(ctime forced to now to defeat Windows tunneling)"
                )
            except Exception as _pub_exc:
                # Best-effort cleanup of the tmp file on publish failure.
                if os.path.exists(tmp_output_path):
                    try:
                        os.remove(tmp_output_path)
                    except OSError:
                        pass
                raise

            end_time = time.time()
            duration = end_time - start_time
            logger.info(
                f"Merge completed successfully | "
                f"Output: {final_output_path} | "
                f"Total records: {total_records:,} | "
                f"Duration: {duration:.2f}s | "
                f"Speed: {total_records/duration:.0f} records/sec"
            )

            return total_records

        except Exception as e:
            logger.error(f"Error merging datasource files: {e}", exc_info=True)
            raise

    def handle_multiple_datasources(self, job_id: str, report_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Handle merging files from multiple datasources"""
        try:
            logger.info(f"Processing multiple datasources for Report ID {job_id}")

            # Validate all results have file_path and files exist
            valid_file_paths = []
            valid_results = []
            valid_filenames = []
            valid_full_path = []
            valid_ctl_format = []

            for result in report_results:
                file_path = result.get('file_path')
                filename = result.get('filename')
                ctl_format = result.get('control_template')
                full_path = os.path.join(os.path.dirname(file_path), filename)
                if file_path and os.path.exists(file_path):
                    valid_file_paths.append(file_path)
                    valid_results.append(result)
                    valid_filenames.append(filename)
                    valid_full_path.append(full_path)
                    valid_ctl_format.append(ctl_format)
                else:
                    logger.error(f"Invalid file path for Report ID {job_id}: {file_path}")

            if not valid_file_paths:
                logger.error(f"No valid files to merge for Report ID {job_id}")
                return {
                    'job_id': job_id,
                    'status': 'failed',
                    'error': 'No valid files found for merging'
                }

            if len(valid_file_paths) < 2:
                logger.info(f"Only one valid file for Report ID {job_id}, treating as single datasource")
                return self._handle_single_datasource(job_id, valid_results[0])

            # Get final filename without datasource suffix
            sample_filename = valid_filenames[0]
            final_filename = self._get_final_filename(sample_filename)
            final_output_path = os.path.join(os.path.dirname(valid_file_paths[0]), final_filename)

            # Merge files and get total record count
            total_records = self._merge_datasource_files(valid_full_path, final_output_path)

            logger.info(f"Report ID {job_id}: Merged {len(valid_file_paths)} datasource files into {final_filename}")

            return {
                'job_id': job_id,
                'final_file_path': final_output_path,
                'total_records': total_records,
                'merged_files': len(valid_file_paths),
                'control_template': valid_ctl_format[0],
                'status': 'success'
            }

        except Exception as e:
            logger.error(f"Error merging files for Report ID {job_id}: {e}")
            return {
                'job_id': job_id,
                'status': 'failed',
                'error': str(e)
            }

    def _handle_single_datasource(self, job_id: str, result: Dict[str, Any]) -> Dict[str, Any]:
        try:
            logger.info(f"Processing single datasource for Report ID {job_id}")

            # FIX 1: Construct proper file path from both file_path and filename
            original_path = os.path.join(result['file_path'], result['filename'])

            # FIX 2: Validate file exists before processing
            if not os.path.exists(original_path):
                logger.error(f"Original file not found: {original_path}")
                return {
                    'job_id': job_id,
                    'status': 'failed',
                    'error': f'File not found: {original_path}'
                }

            # Generate final filename without datasource suffix
            final_filename = self._get_final_filename(result['filename'])
            final_path = os.path.join(result['file_path'], final_filename)

            # FIX 3: Improved file rename with retry logic and cleanup
            if original_path != final_path:
                max_retries = 3
                for attempt in range(max_retries):
                    try:
                        # Remove destination if it exists
                        if os.path.exists(final_path):
                            os.remove(final_path)
                            logger.info(f"Removed existing file: {final_path}")

                        # Rename the file
                        os.rename(original_path, final_path)
                        logger.info(f"Successfully renamed {original_path} to {final_path}")
                        break

                    except (OSError, PermissionError) as e:
                        if attempt == max_retries - 1:
                            logger.error(f"Failed to rename file after {max_retries} attempts: {e}")
                            raise
                        logger.warning(f"Retry {attempt + 1}/{max_retries} for file rename: {e}")
                        time.sleep(2 ** attempt)  # Exponential backoff: 1s, 2s, 4s
            else:
                final_path = original_path
                logger.info(f"No rename needed for {original_path}")

            # FIX 4: Safe access to 'records' field
            return {
                'job_id': job_id,
                'final_file_path': final_path,
                'total_records': result.get('records', 0),  # Use .get() to avoid KeyError
                'merged_files': 1,
                'control_template': result.get('control_template'),
                'status': 'success'
            }

        except Exception as e:
            logger.error(f"Error handling single datasource for Report ID {job_id}: {e}", exc_info=True)
            return {
                'job_id': job_id,
                'status': 'failed',
                'error': str(e)
            }

    def _md5_file(self, file_path: str) -> str:
        """Generate MD5 hash for file"""
        md5_hash = hashlib.md5()
        try:
            with open(file_path, 'rb') as file:
                while chunk := file.read(8192):
                    md5_hash.update(chunk)
            return md5_hash.hexdigest()
        except FileNotFoundError:
            logger.error(f"File not found for MD5 calculation: {file_path}")
            return f"File not found: {file_path}"
        except Exception as e:
            logger.error(f"Error calculating MD5 for {file_path}: {e}")
            return f"MD5 calculation failed: {str(e)}"

    def get_output_files_info(self):
        """Get detailed output file information"""
        output_files = []

        if 'jobs' in self.query_config:
            for job in self.query_config['jobs']:
                file_info = {
                    'filename': job.get('output_file_name'),
                    'file_type': job.get('output_file_type'),
                    'delimiter': job.get('output_file_delimiter'),
                    'file_path': job.get('output_file_location'),
                    'datasource': job.get('datasource_name'),
                    'job_id': job.get('job_id'),
                    'control_template': job.get('ctl_file_format'),
                    'status': 'success'
                }
                output_files.append(file_info)

        return output_files

    # Method to get just the filenames
    def get_output_filenames(self):
        """Get list of output filenames only"""
        filenames = []

        if 'jobs' in self.query_config:
            for job in self.query_config['jobs']:
                if 'output_file_name' in job:
                    filenames.append(job['output_file_name'])

        return filenames

    # Usage examples:

    async def _execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str,
                            step_name: str, *args, **kwargs) -> List[Dict[str, Any]]:
        """Execute file consolidation step."""
        logger.info("Starting ConsolidateFile step execution")

        try:
            sql_file_location = task['sql_query_path']
            self.query_config = self._load_query_config(sql_file_location)

            # Combine all results
            all_results = self.get_output_files_info()

            if not all_results:
                logger.warning("No successful results from cloud or on-premises steps")
                return []

            logger.info(f"Processing {len(all_results)} successful results for consolidation")

            # Group results by job_id for merging
            report_groups = defaultdict(list)
            for result in all_results:
                report_groups[result['job_id']].append(result)

            logger.info(f"Found {len(report_groups)} unique report IDs to process")

            # Process each report group
            consolidation_results = []
            for job_id, report_results in report_groups.items():
                logger.info(f"Processing Report ID {job_id} with {len(report_results)} files")

                if len(report_results) > 1:
                    # Multiple datasources - merge files
                    result = self.handle_multiple_datasources(job_id, report_results)
                else:
                    # Single datasource - rename file
                    result = self._handle_single_datasource(job_id, report_results[0])

                # Add MD5 checksum if file was created successfully
                if result.get('status') == 'success' and result.get('final_file_path'):
                    consolidation_results.append(result)

            # Log summary
            successful_consolidations = [r for r in consolidation_results if r.get('status') == 'success']
            failed_consolidations = [r for r in consolidation_results if r.get('status') == 'failed']

            self.successful_consolidations = successful_consolidations

            kwargs['successful_consolidations'] = successful_consolidations

            logger.info(
                f"File consolidation completed: {len(successful_consolidations)} successful, "
                f"{len(failed_consolidations)} failed out of {len(consolidation_results)} total reports"
            )

            return consolidation_results

        except Exception as e:
            logger.error(f"Error in ConsolidateFile execution: {e}")
            raise