"""Oracle-workflow CheckDependencies step (standalone implementation).

2026-06-22 -- production yaml references ``steps.check_dependencies``;
the oracle workflow needs a SIMPLE pre-flight check for the
``query_fact_table.json`` shape, NOT the Phase 152 file-flow
``{"jobs": [...]}`` shape.

User's direction (2026-06-22):
  "oracle standalone doesn't consolidate files so we can't share
   oracle completeness check with file based workflow"

The same principle applies to CheckDependencies -- the JSON shapes
across workflows are different:

  * Oracle workflow JSON (query_fact_table.json):
      {
        "query_on_cloud": "SELECT ...",
        "query_on_prem":  "SELECT ...",
        "trino_oncloud_url": "...",
        "trino_user": "...",  (or blank, filled by shared yaml)
        "oracle_url": "...",
        "spark_jars": "...",
        ...
      }

  * File workflow JSON (Phase 152 GenerateSQL output):
      {"jobs": [
        {"generated_sql": "...", "datasource_name": "CLOUD", ...},
        {"generated_sql": "...", "datasource_name": "ONPREM", ...}
      ]}

The flat-path ``steps/file/check_dependencies.py`` validates the
file-flow shape (requires ``jobs`` array).  Pointing the oracle
workflow at it would FAIL at the FIRST step with:
  "sql_query_path JSON must be an object with a 'jobs' array"

This standalone implementation validates the oracle-workflow shape:
  * sql_query_path exists on disk + is parseable JSON
  * Has BOTH query_on_cloud + query_on_prem (or at least one if
    polling row marks single-source via a flag)
  * Has either trino_*_url or fields that the shared loader can
    fill (trino_oncloud_url + trino_onprem_url)
  * No file artefact requirement (oracle workflow writes JDBC)

Per-workflow CheckDependencies separation:
  * oracle workflow         -> THIS FILE (validates query_fact_table.json)
  * file workflow           -> steps/file/check_dependencies.py
                                (validates {"jobs": [...]} shape)
  * file_to_oracle workflow -> steps/file_to_oracle/check_dependencies.py
                                (validates file-load source JSON)
"""
import json
import os
from typing import Any, Dict

from steps.BaseStep import BaseStep


# Fields the oracle workflow's per-job JSON MUST have populated either
# inline OR via the shared starburst_config.yaml / oracle_config.yaml
# merge.  Validation happens at extract time inside StarburstBase, but
# CheckDependencies surfaces it at SEQ 1 so operators don't pay the
# pod startup cost just to discover a config gap.
_REQUIRED_QUERY_FIELDS_EITHER_OR = [
    # At least one of these MUST be present; oracle workflow can
    # run single-source (cloud-only or onprem-only).
    "query_on_cloud",
    "query_on_prem",
]


class CheckDependencies(BaseStep):
    """Oracle-workflow pre-flight check.  Validates polling-row inputs
    + per-job JSON shape BEFORE the worker spins up Spark sessions /
    opens Oracle connections.  Pure in-process, no DB writes, no
    external services.

    Fails loud with a descriptive ValueError so the worker halts at
    SEQ 1 instead of paying the cost of later steps when the config
    is broken.
    """

    LOG_PREFIX = "oracle_check_dependencies"

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> Dict[str, Any]:
        self.logger.info(f"{step_name} has been started")
        run_id = task.get("run_id")
        report_id = task.get("fk_report_id")

        # ── 1. Polling-row inputs ────────────────────────────────────
        # dest_table + sql_query_path are absolute essentials for the
        # oracle workflow.  Without them the extract step can't run.
        required_task_fields = ["sql_query_path", "dest_table"]
        missing_task_fields = [
            f for f in required_task_fields if not task.get(f)
        ]
        if missing_task_fields:
            raise ValueError(
                f"CheckDependencies: polling row missing required "
                f"columns {missing_task_fields} for run_id={run_id} "
                f"report_id={report_id}.  Set them in OTG_DAG_TASK + "
                f"re-run the polling query."
            )

        # ── 2. Per-job JSON shape (oracle-flavor, NOT file-flow) ──────
        path = task.get("sql_query_path")
        if not os.path.exists(path):
            raise ValueError(
                f"CheckDependencies: sql_query_path does not exist "
                f"on disk: {path!r} for run_id={run_id}.  Operator "
                f"must pre-stage query_fact_table.json before the "
                f"polling-row run."
            )

        try:
            with open(path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"CheckDependencies: sql_query_path JSON is malformed "
                f"at {path}: {exc}"
            )

        if not isinstance(config, dict):
            raise ValueError(
                f"CheckDependencies: sql_query_path JSON must be an "
                f"object (oracle-workflow flat shape with query_on_cloud "
                f"+ query_on_prem at top level): {path}"
            )

        # At least ONE query field must be present + non-empty.
        present = [
            f for f in _REQUIRED_QUERY_FIELDS_EITHER_OR
            if config.get(f)
        ]
        if not present:
            raise ValueError(
                f"CheckDependencies: sql_query_path JSON has neither "
                f"query_on_cloud nor query_on_prem populated.  Oracle "
                f"workflow needs at least one query.  Path: {path}"
            )

        # ── 3. Surface SQL summary to run_report when wired ───────────
        rr = task.get("_run_report")
        if rr is not None:
            try:
                for key in present:
                    rr.add_sql_summary(f"{report_id}_{key}", config[key])
            except Exception as exc:
                self.logger.warning(
                    f"Could not feed SQL to run_report: {exc}"
                )

        # totalcount = 0 at this stage; extract step sets it.
        task["totalcount"] = 0

        self.logger.info(
            "%s OK: validated query_fact_table.json at %s (%d query "
            "field(s) populated: %s) for run_id=%s report_id=%s",
            step_name, path, len(present), present, run_id, report_id,
        )

        return {
            "status": "SUCCESS",
            "sql_query_path": path,
            "queries_present": present,
        }
