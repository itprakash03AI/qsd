"""ParquetFileToOracle — load a Parquet file (or directory) into Oracle.

Thin subclass of ``FileToOracleBase``.  Spark's parquet reader handles
both a single ``.parquet`` file and a partitioned Parquet directory
(``year=2026/month=06/...``) transparently — same source_file_location
+ source_file_name shape as the delimited variant.

Schema comes from the Parquet metadata; ``source_schema_inference``
is irrelevant (always true for Parquet).
"""
from __future__ import annotations

from steps.file_to_oracle.file_to_oracle_base import FileToOracleBase


class ParquetFileToOracle(FileToOracleBase):
    """Load a Parquet file (or partitioned directory) into Oracle."""

    SOURCE_FORMAT = "parquet"
    LOG_PREFIX = "parquet_file_to_oracle"
