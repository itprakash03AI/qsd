"""Strategic base for File → Oracle steps.

Mirrors the Starburst→Oracle Spark JDBC pattern that
``steps/oracle/starburst_base.py`` established, but the source is a
file on disk (or shared PVC / S3 mount) instead of a Trino query.

Two concrete steps inherit from this base:

  * ``DelimitedFileToOracle`` — csv / txt / pipe / any operator-
    configured delimiter.  Reads via Spark's CSV reader with explicit
    ``sep`` / ``header`` / ``encoding`` options.
  * ``ParquetFileToOracle`` — Parquet (or partitioned Parquet
    directory).  Reads via Spark's Parquet reader.

The "natural" loop-back for this base: take the gz/csv produced by
the Starburst→file workflow, decompress + load to Oracle in one step.

Strategic abstractions reused from the file workflow:

  * ``FileRunReport`` — HTML + text + email run report.
  * ``RunArtifacts`` — register every file we touch so a failure
    cleanup wipes nothing-yet-shipped.
  * Single-file logging via ``log_config.build_module_logger`` (no
    CentralizedLogger).

Completeness ledger (G1-G5 re-purposed for File→Oracle):

  G1 — Source row count via Spark ``df.count()`` after read.
  G2 — N/A (no client-side chunking — Spark handles partitioning).
  G3 — Rows handed to the JDBC writer (same as G1; defensive cross-check).
  G4 — N/A.
  G5 — ``SELECT COUNT(*)`` on the Oracle dest table filtered by
       ``batch_id`` / ``RUN_ID`` if a ``dest_batch_id_column`` is set;
       full-table count otherwise.  Skipped (with a WARN) when
       ``validate_dest_count`` is false.

The G1 == G3 == G5 rule fires before the standalone reports SUCCESS.
A mismatch raises, RunArtifacts cleans up, finish email goes out
FAILED.

Per-job JSON config shape (under ``task['sql_query_path']``):

    {
      "jobs": [
        {
          "report_id": "RPT_010",
          "datasource_name": "FILE_TO_ORACLE",

          "source_file_location": "/data/in/rpt_010",
          "source_file_name": "rpt_010.csv",
          "source_file_format": "csv",
          "source_file_delimiter": "|",
          "source_file_has_header": true,
          "source_file_encoding": "utf-8",
          "source_file_is_gzipped": false,
          "source_schema_inference": true,

          "dest_table": "MY_SCHEMA.MY_TABLE",
          "dest_write_mode": "append",
          "dest_batch_size": 50000,
          "dest_isolation_level": "NONE",
          "dest_batch_id_column": "BATCH_ID",
          "dest_batch_id_value": "{RUN_ID}",
          "validate_dest_count": true,
          "fail_on_mismatch": true,

          "oracle_url": "jdbc:oracle:thin:@host:port:sid",
          "oracle_user": "...",
          "oracle_password": "...",

          "spark_executor_memory": "8g",
          "spark_driver_memory": "3g",
          "num_partitions": 10,
          "spark_jars": "/.../ojdbc11.jar"
        }
      ]
    }

Spark is lazy-imported (same pattern as the Spark variant of the
file workflow) so the module loads on non-Spark pods + fails LOUD
with an operator-readable error only when the step actually runs.
"""
from __future__ import annotations

import asyncio
import configparser
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts,
    get_or_create_artifacts,
    save_task_state,
)


# ──────────────────────────────────────────────────────────────────────
#  LoadPlan
# ──────────────────────────────────────────────────────────────────────

@dataclass
class LoadPlan:
    """Immutable load plan for one File → Oracle job."""
    report_id: str
    source_format: str                                # 'delimited' | 'parquet'
    source_path: str                                  # resolved abs path / URI
    source_delimiter: Optional[str]                   # only for delimited
    source_has_header: bool
    source_encoding: str
    source_is_gzipped: bool
    schema_inference: bool

    dest_table: str
    dest_write_mode: str                              # append | overwrite | truncate_insert
    dest_batch_size: int
    dest_isolation_level: str
    dest_batch_id_column: Optional[str]
    dest_batch_id_value: Any
    validate_dest_count: bool
    fail_on_mismatch: bool

    num_partitions: int


# ──────────────────────────────────────────────────────────────────────
#  Base
# ──────────────────────────────────────────────────────────────────────

class FileToOracleBase(BaseStep):
    """Shared Spark-JDBC load logic for delimited + parquet sources.

    Subclasses provide:
        SOURCE_FORMAT      — 'delimited' or 'parquet'
        LOG_PREFIX         — for the module-level logger name
        DATASOURCE_NAME    — filter from the query JSON's ``datasource_name``
                              (default "FILE_TO_ORACLE" — operator can override
                              on the job dict).
    """

    SOURCE_FORMAT: str = ""
    LOG_PREFIX: str = "file_to_oracle"
    DATASOURCE_NAME: str = "FILE_TO_ORACLE"

    DEFAULT_BATCH_SIZE = 50_000
    DEFAULT_NUM_PARTITIONS = 10
    DEFAULT_EXECUTOR_MEMORY = "8g"
    DEFAULT_DRIVER_MEMORY = "3g"
    DEFAULT_ENCODING = "utf-8"
    DEFAULT_DELIMITER = ","

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ini_config: Optional[configparser.ConfigParser] = None
        self.query_config: Optional[Dict[str, Any]] = None
        self.run_report: Optional[FileRunReport] = None
        self.artifacts: Optional[RunArtifacts] = None

    # ----- Setup ------------------------------------------------------

    def _setup_logging(self, task: Dict) -> None:
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            try:
                from log_config import get_log_dir as _ld
                base = _ld()
            except Exception:
                import tempfile
                base = tempfile.gettempdir()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(
                base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as exc:
            self.logger.warning("Cannot create log file %s: %s — console only", log_path, exc)

    def _load_ini_config(self) -> configparser.ConfigParser:
        cfg = configparser.ConfigParser()
        path = os.getenv(
            "EXPORT_TOOL_CONFIG_PATH",
            "/usr/local/spark/pvc/code/configs/export_tool_config.ini",
        )
        cfg.read(path)
        return cfg

    def _load_query_config(self, json_path: str) -> Dict[str, Any]:
        if not json_path or not os.path.exists(json_path):
            raise ValueError(f"sql_query_path missing or not on disk: {json_path!r}")
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _get_run_report(self, task: Dict) -> FileRunReport:
        rr = task.get("_run_report")
        if isinstance(rr, FileRunReport):
            return rr
        rr = FileRunReport(
            output_dir=task.get("output_dir") or "",
            logger=self.logger,
        )
        rr.set_context(
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
        )
        task["_run_report"] = rr
        return rr

    def _filter_jobs(self) -> List[Dict[str, Any]]:
        if not self.query_config:
            return []
        jobs = self.query_config.get("jobs", []) or []
        # Operator may name the datasource anything they like for
        # File→Oracle work — default DATASOURCE_NAME="FILE_TO_ORACLE",
        # but they can override on the job dict if their JSON already
        # uses a different convention.  Match case-insensitively.
        target = self.DATASOURCE_NAME.upper()
        return [j for j in jobs if str(j.get("datasource_name", "")).upper() == target]

    # ----- LoadPlan construction --------------------------------------

    def _build_load_plan(self, job_config: Dict[str, Any], task: Dict) -> LoadPlan:
        report_id = str(job_config.get("report_id", "?"))
        source_dir = job_config.get("source_file_location") or ""
        source_name = job_config.get("source_file_name") or ""
        if not source_dir or not source_name:
            raise ValueError(
                f"job {report_id}: source_file_location + source_file_name required"
            )
        source_path = os.path.join(source_dir, source_name)
        if not os.path.exists(source_path):
            raise ValueError(
                f"job {report_id}: source file does not exist on disk: {source_path!r}"
            )
        if os.path.getsize(source_path) == 0:
            raise ValueError(f"job {report_id}: source file is empty: {source_path!r}")

        dest_table = job_config.get("dest_table") or ""
        if not dest_table:
            raise ValueError(f"job {report_id}: dest_table is required")
        dest_write_mode = str(job_config.get("dest_write_mode", "append")).lower()
        if dest_write_mode not in ("append", "overwrite", "truncate_insert"):
            raise ValueError(
                f"job {report_id}: dest_write_mode {dest_write_mode!r} not in "
                f"(append, overwrite, truncate_insert)"
            )

        # Substitute {RUN_ID} / {REPORT_ID} / {BUSINESS_DATE} placeholders
        # in batch_id_value (operator convention for tagging the load).
        bid_value = job_config.get("dest_batch_id_value")
        if isinstance(bid_value, str):
            bid_value = (
                bid_value
                .replace("{RUN_ID}", str(task.get("run_id", "")))
                .replace("{REPORT_ID}", str(task.get("fk_report_id", "")))
                .replace("{BUSINESS_DATE}", str(task.get("business_date", "")))
            )

        return LoadPlan(
            report_id=report_id,
            source_format=self.SOURCE_FORMAT,
            source_path=source_path,
            source_delimiter=job_config.get("source_file_delimiter", self.DEFAULT_DELIMITER),
            source_has_header=bool(job_config.get("source_file_has_header", True)),
            source_encoding=str(job_config.get("source_file_encoding", self.DEFAULT_ENCODING)),
            source_is_gzipped=bool(job_config.get("source_file_is_gzipped", False)),
            schema_inference=bool(job_config.get("source_schema_inference", True)),
            dest_table=dest_table,
            dest_write_mode=dest_write_mode,
            dest_batch_size=int(job_config.get("dest_batch_size", self.DEFAULT_BATCH_SIZE)),
            dest_isolation_level=str(job_config.get("dest_isolation_level", "NONE")),
            dest_batch_id_column=job_config.get("dest_batch_id_column"),
            dest_batch_id_value=bid_value,
            validate_dest_count=bool(job_config.get("validate_dest_count", True)),
            fail_on_mismatch=bool(job_config.get("fail_on_mismatch", True)),
            num_partitions=int(job_config.get("num_partitions", self.DEFAULT_NUM_PARTITIONS)),
        )

    # ----- Spark plumbing ---------------------------------------------

    def _build_spark_session(self, job_config: Dict[str, Any], run_id: Any, report_id: str):
        """Build a SparkSession.  Lazy import so non-Spark pods can
        still load the step class (resolves cleanly); the import only
        fires when the step actually executes."""
        try:
            from pyspark.sql import SparkSession
        except ImportError as exc:
            raise RuntimeError(
                "PySpark not installed on this pod — cannot run FileToOracle.  "
                "Deploy on a Spark-enabled pod, or use a non-Spark loader."
            ) from exc

        executor_memory = job_config.get("spark_executor_memory", self.DEFAULT_EXECUTOR_MEMORY)
        driver_memory = job_config.get("spark_driver_memory", self.DEFAULT_DRIVER_MEMORY)
        num_partitions = int(job_config.get("num_partitions", self.DEFAULT_NUM_PARTITIONS))
        spark_jars = job_config.get("spark_jars") or os.environ.get("SPARK_JARS", "")
        app = f"{self.LOG_PREFIX}_{run_id}_{report_id}"
        builder = (
            SparkSession.builder.appName(app)
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
        )
        if spark_jars:
            builder = builder.config("spark.jars", spark_jars)
        return builder.getOrCreate()

    def _oracle_jdbc_props(self, job_config: Dict[str, Any]) -> Dict[str, str]:
        ini = self.ini_config
        section = "Oracle"
        url = (
            job_config.get("oracle_url")
            or (ini.get(section, "url", fallback="") if ini and ini.has_section(section) else "")
        )
        user = (
            job_config.get("oracle_user")
            or (ini.get(section, "username", fallback="") if ini and ini.has_section(section) else "")
        )
        password = (
            job_config.get("oracle_password")
            or (ini.get(section, "password", fallback="") if ini and ini.has_section(section) else "")
        )
        if not url or not user or not password:
            raise ValueError(
                f"FileToOracle: missing Oracle credentials for report_id="
                f"{job_config.get('report_id')} — set oracle_url/user/password "
                f"on the job OR populate [Oracle] in the INI."
            )
        return {"url": url, "user": user, "password": password,
                "driver": "oracle.jdbc.OracleDriver"}

    # ----- Read source ------------------------------------------------

    def _read_source(self, spark, plan: LoadPlan):
        """Build a DataFrame from the source file.  Returns the df.

        Delimited: ``spark.read.csv(...)`` with options.
        Parquet:  ``spark.read.parquet(...)``.

        Both go through Spark, so a Parquet directory + a single CSV
        + a gzipped CSV all work uniformly.
        """
        self.logger.info(
            "Reading source: path=%s format=%s gzipped=%s",
            plan.source_path, plan.source_format, plan.source_is_gzipped,
        )
        if plan.source_format == "delimited":
            reader = (
                spark.read.format("csv")
                .option("header", "true" if plan.source_has_header else "false")
                .option("sep", plan.source_delimiter or self.DEFAULT_DELIMITER)
                .option("encoding", plan.source_encoding)
                .option("inferSchema", "true" if plan.schema_inference else "false")
                .option("multiLine", "false")
                .option("quote", '"')
                .option("escape", '"')
            )
            return reader.load(plan.source_path)
        if plan.source_format == "parquet":
            return spark.read.parquet(plan.source_path)
        raise ValueError(f"Unsupported source_format {plan.source_format!r}")

    # ----- Write dest -------------------------------------------------

    def _write_oracle(self, df, plan: LoadPlan, jdbc_props: Dict[str, str]) -> None:
        """Write df to Oracle via JDBC."""
        write_mode_map = {
            "append": "append",
            "overwrite": "overwrite",
            # Spark's "overwrite" drops + recreates the table — destructive.
            # truncate_insert preserves the table by issuing TRUNCATE then
            # appending; safer for prod schemas with grants / triggers.
            "truncate_insert": "append",
        }
        spark_mode = write_mode_map[plan.dest_write_mode]

        if plan.dest_write_mode == "truncate_insert":
            # Spark's option("truncate", "true") + mode("overwrite")
            # would truncate the table without dropping.  But that's
            # mode=overwrite semantics; we want mode=append with a
            # pre-step TRUNCATE.  Issue the TRUNCATE explicitly via
            # JDBC + then append.
            try:
                import jaydebeapi  # optional
                conn = jaydebeapi.connect(
                    jdbc_props["driver"], jdbc_props["url"],
                    [jdbc_props["user"], jdbc_props["password"]],
                )
                with conn.cursor() as cur:
                    cur.execute(f"TRUNCATE TABLE {plan.dest_table}")
                conn.close()
                self.logger.info("Pre-truncate OK on %s", plan.dest_table)
            except ImportError:
                # Fall back to Spark "truncate" overwrite mode.
                spark_mode = "overwrite"
                self.logger.warning(
                    "jaydebeapi not available — falling back to Spark "
                    "overwrite mode with option('truncate', 'true') for %s",
                    plan.dest_table,
                )

        self.logger.info(
            "Writing to Oracle: table=%s mode=%s batch_size=%d num_partitions=%d",
            plan.dest_table, spark_mode, plan.dest_batch_size, plan.num_partitions,
        )
        df = df.repartition(plan.num_partitions)

        writer = (
            df.write.format("jdbc")
            .option("url", jdbc_props["url"])
            .option("dbtable", plan.dest_table)
            .option("user", jdbc_props["user"])
            .option("password", jdbc_props["password"])
            .option("driver", jdbc_props["driver"])
            .option("batchsize", str(plan.dest_batch_size))
            .option("isolationLevel", plan.dest_isolation_level)
            .option("numPartitions", str(plan.num_partitions))
        )
        if plan.dest_write_mode == "truncate_insert" and spark_mode == "overwrite":
            writer = writer.option("truncate", "true")
        writer.mode(spark_mode).save()

    # ----- Verify dest count ------------------------------------------

    def _verify_oracle_count(
        self, spark, plan: LoadPlan, jdbc_props: Dict[str, str],
    ) -> Optional[int]:
        """Read back ``SELECT COUNT(*) FROM dest_table WHERE batch_id = ?``.

        Returns the int count, or None when validation is disabled.
        """
        if not plan.validate_dest_count:
            self.logger.warning(
                "validate_dest_count=False — skipping G5 dest reconcile.  "
                "Operator can flip the JSON flag to true once a stable "
                "batch_id_column is in place."
            )
            return None
        where = ""
        if plan.dest_batch_id_column and plan.dest_batch_id_value not in (None, ""):
            # Escape per Oracle conventions.
            v = plan.dest_batch_id_value
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                lit = str(v)
            else:
                lit = "'" + str(v).replace("'", "''") + "'"
            where = f" WHERE {plan.dest_batch_id_column} = {lit}"
        count_sql = f"(SELECT COUNT(*) AS CNT FROM {plan.dest_table}{where}) tbl"
        df = (
            spark.read.format("jdbc")
            .option("url", jdbc_props["url"])
            .option("dbtable", count_sql)
            .option("user", jdbc_props["user"])
            .option("password", jdbc_props["password"])
            .option("driver", jdbc_props["driver"])
            .load()
        )
        n = int(df.collect()[0]["CNT"])
        self.logger.info("G5 Oracle COUNT(%s) = %d", plan.dest_table, n)
        return n

    # ----- Per-job execution ------------------------------------------

    async def _execute_one_job(self, job_config: Dict[str, Any], task: Dict) -> Dict[str, Any]:
        report_id = job_config.get("report_id")
        self.logger.info("=" * 72)
        self.logger.info(
            "FileToOracle job start: report_id=%s source_format=%s",
            report_id, self.SOURCE_FORMAT,
        )
        self.logger.info("=" * 72)

        plan = self._build_load_plan(job_config, task)
        self.run_report.set_runtime_knobs(
            source_format=plan.source_format,
            source_path=plan.source_path,
            dest_table=plan.dest_table,
            dest_write_mode=plan.dest_write_mode,
            num_partitions=plan.num_partitions,
            dest_batch_size=plan.dest_batch_size,
        )

        # Register the source file with the artifact registry — but as
        # REPORT category (never touched by cleanup), since we don't
        # own the source.  Operator's expectation: failure should NOT
        # delete their input file.
        self.artifacts.add(plan.source_path, RunArtifacts.REPORT)

        spark = self._build_spark_session(job_config, task.get("run_id", "unknown"), str(report_id))
        jdbc_props = self._oracle_jdbc_props(job_config)
        start = time.time()
        try:
            # G1 — source row count
            df = self._read_source(spark, plan)
            source_count = int(df.count())  # G1
            self.logger.info("G1 source_count=%d", source_count)

            # Empty source → fail loud per default; operator can override
            # via fail_on_mismatch=false to allow no-op loads.
            if source_count == 0 and plan.fail_on_mismatch:
                raise ValueError(
                    f"FileToOracle: source file produced 0 rows ({plan.source_path}). "
                    f"Set fail_on_mismatch=false to permit empty loads."
                )

            # Optional: inject batch_id column on every row so G5 can
            # filter accurately.  Done as a Spark withColumn so it's
            # cheap (no shuffle).
            if plan.dest_batch_id_column and plan.dest_batch_id_value not in (None, ""):
                try:
                    from pyspark.sql.functions import lit
                    df = df.withColumn(plan.dest_batch_id_column, lit(plan.dest_batch_id_value))
                except Exception as exc:
                    self.logger.warning(
                        "Could not inject %s column (assuming source already has it): %s",
                        plan.dest_batch_id_column, exc,
                    )

            # G3 — Spark JDBC write
            self._write_oracle(df, plan, jdbc_props)
            write_time = time.time() - start

            # G5 — verify destination count
            dest_count = self._verify_oracle_count(spark, plan, jdbc_props)

            # Reconcile G1 vs G5 (or G1 vs G3 if G5 disabled)
            if dest_count is not None and dest_count != source_count:
                msg = (
                    f"FileToOracle G5 FAILED: source={source_count:,} != "
                    f"oracle_dest={dest_count:,} (delta {dest_count - source_count:+,})"
                )
                if plan.fail_on_mismatch:
                    raise ValueError(msg)
                self.logger.warning(msg + " — proceeding per fail_on_mismatch=false")

            self.logger.info(
                "FileToOracle job OK: report_id=%s source=%d dest=%s duration=%.1fs",
                report_id, source_count, dest_count, write_time,
            )
            return {
                "report_id": report_id,
                "datasource": "FILE",
                "status": "success",
                "records": source_count,
                "expected_total": source_count,
                "sum_partition_expected": source_count,
                "source_path": plan.source_path,
                "dest_table": plan.dest_table,
                "dest_write_mode": plan.dest_write_mode,
                "dest_count": dest_count,
                "duration_sec": write_time,
                "control_template": job_config.get("ctl_file_format", ""),
                "file_path": plan.source_path,
            }
        finally:
            try:
                spark.stop()
            except Exception:
                pass

    # ----- BaseStep contract ------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.ini_config = self._load_ini_config()
        self.query_config = self._load_query_config(task.get("sql_query_path"))
        self.run_report = self._get_run_report(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)

        jobs = self._filter_jobs()
        if not jobs:
            self.logger.warning(
                "No %s jobs in query config (looking for datasource_name=%s)",
                self.SOURCE_FORMAT, self.DATASOURCE_NAME,
            )
            return []

        self.logger.info(
            "%s: %d job(s) to process (format=%s)",
            self.LOG_PREFIX, len(jobs), self.SOURCE_FORMAT,
        )

        results: List[Dict[str, Any]] = []
        try:
            for job in jobs:
                res = await self._execute_one_job(job, task)
                results.append(res)
                self.run_report.add_job_result({
                    "report_id": res.get("report_id"),
                    "datasource": res.get("datasource"),
                    "status": res.get("status"),
                    "records": res.get("records", 0),
                    "chunks": 1,
                    "file_path": res.get("source_path", ""),
                })
        finally:
            self.run_report.write()

        total = sum(r.get("records", 0) for r in results)
        dest_total = sum(int(r.get("dest_count") or r.get("records", 0)) for r in results)
        self.run_report.set_counts(
            expected_total=total,
            sum_partition_expected=total,
            sum_chunk_actual=total,
            consolidated_total=dest_total,
        )

        task["job_results"] = results
        task["expected_total"] = total
        task["sum_chunk_actual"] = total
        task["consolidated_total"] = dest_total
        task["totalcount"] = total
        task["artifact_paths"] = self.artifacts.snapshot()

        # Persist sidecar for any downstream step (e.g. notify) that
        # runs as a separate polling row.
        base_dir = task.get("output_dir") or (
            os.path.dirname(results[0]["source_path"]) if results else ""
        )
        if base_dir:
            save_task_state(task, base_dir, task.get("run_id"), logger=self.logger)

        # Push record count to Oracle metadata (matches the file workflow's
        # contract — every step ends with an UPDATE_TASK_RECORDCOUNT call
        # so the polling table sees the actual rows moved).
        try:
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"),
                task.get("run_detail_id"),
                "UPDATE_TASK_RECORDCOUNT",
                step_name,
                total,
                "",
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.warning("update_otg_etl_batch_status failed: %s", exc)

        return results
