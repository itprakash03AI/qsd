"""CheckCompleteness — verify the file_to_oracle load was complete.

Validates row counts the upstream Delimited/Parquet FileToOracle step
left on the task dict.  Pure in-process check — no external services
beyond the optional Oracle COUNT(*) post-load verification.

Task-dict inputs (populated by DelimitedFileToOracle / ParquetFileToOracle):
    expected_total     — G1 source row count.
    sum_chunk_actual   — G3 rows handed to the JDBC writer.
    consolidated_total — G5 Oracle COUNT(*) post-load.
    totalcount         — alias of expected_total for BaseStep status update.

Per-task JSON config (optional under ``sql_query_path``):
    min_record_count  — minimum acceptable row count (default 1).
    max_record_count  — upper bound (catches runaway loads).
    fail_on_mismatch  — bool, default True.

Loud-fails with ValueError so downstream ProcessData / SendEmailNotifications
never runs against a partial load.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict

from steps.BaseStep import BaseStep


class CheckCompleteness(BaseStep):
    """Certify the file_to_oracle load before ProcessData / Notify."""

    LOG_PREFIX = "file_to_oracle_check_completeness"

    def _load_optional_config(self, task: Dict) -> Dict[str, Any]:
        """JSON config is optional for this step."""
        path = task.get("sql_query_path")
        if not path or not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception:
            return {}
        return cfg if isinstance(cfg, dict) else {}

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> int:
        config = self._load_optional_config(task)
        self.logger.info(f"{step_name} has been started")

        expected_total = task.get("expected_total")
        if expected_total is None:
            expected_total = task.get("totalcount")
        if expected_total is None:
            raise ValueError(
                "CheckCompleteness: task['expected_total'] / task['totalcount'] is "
                "unset — the upstream DelimitedFileToOracle / ParquetFileToOracle "
                "step did not record a source row count."
            )
        try:
            expected_total = int(expected_total)
        except (TypeError, ValueError):
            raise ValueError(
                f"CheckCompleteness: expected_total {expected_total!r} is not an integer."
            )

        # Bounds check on the source row count.
        min_count = int(config.get("min_record_count", 1))
        max_count = config.get("max_record_count")
        if expected_total < min_count:
            raise ValueError(
                f"CheckCompleteness: source row count {expected_total} is below the "
                f"configured minimum ({min_count}).  Halting before ProcessData."
            )
        if max_count is not None and expected_total > int(max_count):
            raise ValueError(
                f"CheckCompleteness: source row count {expected_total} exceeds the "
                f"configured maximum ({max_count}) — likely a misconfigured filter."
            )

        # G1 == G3 sanity (Spark write should never drop rows on a no-transform load).
        sum_chunk_actual = task.get("sum_chunk_actual")
        if sum_chunk_actual is not None:
            sum_chunk_actual = int(sum_chunk_actual)
            if sum_chunk_actual != expected_total:
                msg = (
                    f"CheckCompleteness G3 FAILED: G1 source={expected_total:,} != "
                    f"G3 written={sum_chunk_actual:,} (delta {sum_chunk_actual - expected_total:+,})"
                )
                if bool(config.get("fail_on_mismatch", True)):
                    raise ValueError(msg)
                self.logger.warning(msg + " — proceeding per fail_on_mismatch=false")

        # G1 == G5 — load arrived in Oracle intact.
        dest_count = task.get("consolidated_total")
        if dest_count is not None:
            dest_count = int(dest_count)
            if dest_count != expected_total:
                msg = (
                    f"CheckCompleteness G5 FAILED: G1 source={expected_total:,} != "
                    f"G5 oracle_dest={dest_count:,} (delta {dest_count - expected_total:+,})"
                )
                if bool(config.get("fail_on_mismatch", True)):
                    raise ValueError(msg)
                self.logger.warning(msg + " — proceeding per fail_on_mismatch=false")
            else:
                self.logger.info(
                    "G5 OK: oracle_dest=%d == source=%d", dest_count, expected_total,
                )
        else:
            self.logger.warning(
                "CheckCompleteness: consolidated_total (G5) not recorded — upstream "
                "DelimitedFileToOracle / ParquetFileToOracle ran with "
                "validate_dest_count=false.  G5 reconcile SKIPPED."
            )

        self.logger.info(
            "CheckCompleteness PASS: source=%d, dest=%s",
            expected_total, dest_count,
        )
        task["totalcount"] = expected_total
        return expected_total
