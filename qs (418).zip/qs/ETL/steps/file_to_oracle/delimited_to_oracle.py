"""DelimitedFileToOracle — load any delimited text file into Oracle.

Thin subclass of ``FileToOracleBase``.  Handles csv / txt / pipe /
tab-separated / any operator-configured delimiter — Spark's CSV
reader does the parsing under a unified ``sep`` option.

Per-job config knobs that drive the read (from the JSON):

    "source_file_format": "csv"         (label only; engine = delimited)
    "source_file_delimiter": "|"        default ","
    "source_file_has_header": true      default true
    "source_file_encoding": "utf-8"     default utf-8
    "source_file_is_gzipped": false     default false
    "source_schema_inference": true     default true

Spark reads ``.gz`` files transparently when the suffix is correct;
if your gzipped source has no suffix, copy it to ``<name>.csv.gz`` so
Spark detects it.
"""
from __future__ import annotations

from steps.file_to_oracle.file_to_oracle_base import FileToOracleBase


class DelimitedFileToOracle(FileToOracleBase):
    """Load a delimited text file (csv / txt / pipe / …) into Oracle."""

    SOURCE_FORMAT = "delimited"
    LOG_PREFIX = "delimited_file_to_oracle"
