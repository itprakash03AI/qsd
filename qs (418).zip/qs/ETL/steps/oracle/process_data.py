from datetime import datetime
from typing import Dict, Any

from steps.BaseStep import BaseStep


class ProcessData(BaseStep):
    """Step to execute a post-load procedure to transfer data from staging to main table."""

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> Dict[str, Any]:
        """Execute the post-load procedure to transfer data from staging to main table."""
        self.logger.info(f"{step_name} has been started")
        proc_id = task.get("postload_task_proc_configid")
        otg_dag_id = task.get('otg_dag_id')
        business_date = task.get('business_date')
        report_id = task.get("fk_report_id")
        run_id = task.get('run_id')
        procname = task.get('postloadprocname')
        run_detail_id = task.get("run_detail_id")

        if not proc_id:
            raise ValueError(f"Post-load task procedure ID not found for task {task.get('task_id')}")

        # Fetch procedure parameters using OracleDataManager
        procedure_params = await self.oracle_data_manager.get_procedure_params_async(
            otg_dag_id, business_date, proc_id, "POSTLOAD", "internal", worker_connection_string
        )
        if not procedure_params:
            raise ValueError(f"No parameters found for procedure ID {proc_id} for task {task.get('task_id')}")

        # Execute the post-load procedure
        self.logger.info(f"Executing POSTLOAD_PROC with params: {procedure_params}")

        df = await self.oracle_data_manager.execute_procedure_with_dataframe(
            procname, procedure_params, dest_connection_string, 'external'
        )

        # Defensive checks on the returned dataframe
        if df is None:
            raise Exception(
                f"Procedure returned None (procname={procname}, run_id={run_id}, run_detail_id={run_detail_id})"
            )

        if "STATUS" not in df.columns:
            raise Exception(
                f"Procedure result missing STATUS column (procname={procname}, columns={list(df.columns)})"
            )

        # Normalize status checks
        status = df["STATUS"].astype(str).str.upper()

        if (status != "SUCCESS").any():
            raise Exception(
                f"PostLoad Proc Failed (procname={procname}, run_id={run_id}, run_detail_id={run_detail_id})"
            )

        self.logger.info(f"{step_name} completed successfully")

        # Return a lightweight result for traceability
        return {
            "status": "SUCCESS",
            "procname": procname,
            "proc_id": proc_id,
            "timestamp": datetime.utcnow().isoformat(),
        }