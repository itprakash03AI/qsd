"""
Shared base class for Starburst/Trino → Oracle Spark JDBC steps.
Subclasses override QUERY_KEY, TRINO_URL_KEY, and default memory settings.
"""
import os
import json
import logging
import sys
from datetime import datetime
from typing import Dict, Any, List

from pyspark.sql import SparkSession, DataFrame
from steps.BaseStep import BaseStep


class StarburstBase(BaseStep):
    """Base class for Starburst→Oracle steps with shared config, Spark, and JDBC logic."""

    # --- Subclass overrides ---
    QUERY_KEY: str = "query_on_cloud"           # config key for SQL query
    TRINO_URL_KEY: str = "trino_oncloud_url"    # config key for Trino JDBC URL
    DEFAULT_EXECUTOR_MEMORY: str = "10g"
    DEFAULT_DRIVER_MEMORY: str = "3g"
    LOG_PREFIX: str = "sb_to_oracle"

    # --- Required config fields (shared across OnPrem/OnCloud) ---
    COMMON_REQUIRED_FIELDS: List[str] = [
        'trino_user', 'trino_password',
        'oracle_url', 'oracle_user', 'oracle_password',
        'spark_jars',
    ]

    def _get_required_fields(self) -> List[str]:
        """Return full list of required config fields including subclass-specific keys."""
        return [self.QUERY_KEY, self.TRINO_URL_KEY] + self.COMMON_REQUIRED_FIELDS

    def _load_and_validate_config(self, task: Dict) -> Dict:
        """Load JSON config from task['sql_query_path'] and validate required fields.

        2026-06-12 — credentials and TRINO_URL fall back to the shared
        ``configs/starburst_config.yaml`` when the per-job JSON omits
        them.  Mirrors the same behaviour the non-Spark
        ``LightStarburstBase`` already implements, so the Spark and
        non-Spark Oracle paths read credentials from the SAME source.
        """
        config_path = task.get('sql_query_path')
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        # ── Shared Starburst credentials -- YAML WINS (2026-06-22) ──
        try:
            from starburst_config_loader import merge_shared_into_job_config as _merge_sb
            _merge_sb(
                config,
                trino_url_key=self.TRINO_URL_KEY,
                logger=getattr(self, "logger", None),
            )
        except Exception as _exc:
            # Loader unavailable -- continue with per-job JSON values.
            # Missing-field check below surfaces actually-missing values.
            if getattr(self, "logger", None):
                self.logger.warning(
                    f"starburst_config_loader unavailable ({_exc}); "
                    f"using per-job JSON Starburst values only."
                )

        # ── Shared destination Oracle credentials fallback ──────────
        try:
            from oracle_config_loader import merge_shared_into_job_config as _merge_ora
            _merge_ora(config)
        except Exception:
            pass

        # Treat empty strings as missing so a blank ``trino_user`` in
        # the per-job JSON falls through to the shared resolver above.
        required = self._get_required_fields()
        missing = [f for f in required if not config.get(f)]
        if missing:
            raise ValueError(
                f"Missing required config fields: {missing}. "
                f"Set them in the per-job JSON ({config_path}) OR in the "
                f"shared configs/starburst_config.yaml + STARBURST_* env vars."
            )

        return config

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Replace template variables in SQL query."""
        replacements = {
            "{BUSINESSDATE}": task.get('business_date', ''),
            "{SYSTEM_ENTITY}": task.get('system_entity', ''),
            "{EventCode}": task.get('eventcode', ''),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        return query

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        Uses shared pipeline log file from ``task['log_file']`` so all
        steps write to a single file.  Falls back to a per-step file.
        """
        self.logger = logging.getLogger(f"etl.{self.LOG_PREFIX}")

        # Avoid adding duplicate handlers if called again
        if self.logger.handlers:
            return

        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)

        # Prefer shared pipeline log file; fall back to per-step file.
        # Log dir resolved via log_config.get_log_dir() — ETL_LOG_DIR
        # env var wins, then polling YAML, then legacy PVC path.
        log_path = task.get('log_file')
        if not log_path:
            run_id = task.get('run_id', 'unknown')
            date_str = datetime.now().strftime('%Y-%m-%d')
            try:
                from log_config import get_log_dir as _resolve_log_dir
                _ld = _resolve_log_dir()
            except Exception:
                _ld = "/usr/local/spark/nfs/bcp/batch/logs"
            log_path = os.path.join(
                _ld, f"etl_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )

        try:
            os.makedirs(os.path.dirname(log_path), exist_ok=True)
            fh = logging.FileHandler(log_path)
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as e:
            self.logger.warning(f"Cannot create log file {log_path}: {e} — console only")

    def _build_spark_session(self, task: Dict, config: Dict) -> SparkSession:
        """Build SparkSession with configurable memory and common settings."""
        run_id = task.get('run_id', 'unknown')
        run_detail_id = task.get('run_detail_id', 'unknown')
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

        executor_memory = config.get('spark_executor_memory', self.DEFAULT_EXECUTOR_MEMORY)
        driver_memory = config.get('spark_driver_memory', self.DEFAULT_DRIVER_MEMORY)
        executor_overhead = config.get('spark_executor_memory_overhead', '1g')
        driver_overhead = config.get('spark_driver_memory_overhead', '1g')
        num_partitions = config.get('num_partitions', 10)
        spark_jars = config['spark_jars']

        try:
            from log_config import get_log_dir as _resolve_log_dir
            _evt_root = _resolve_log_dir()
        except Exception:
            _evt_root = "/usr/local/spark/nfs/bcp/batch/logs"
        event_log_dir = os.path.join(
            _evt_root, "event-logs",
            f"{run_id}_{run_detail_id}_{timestamp}",
        )
        os.makedirs(event_log_dir, exist_ok=True)

        spark = (
            SparkSession.builder
            .appName(f"{self.LOG_PREFIX}_{run_id}-{run_detail_id}")
            .config("spark.executor.cores", "1")
            .config("spark.kubernetes.executor.request.cores", "300m")
            .config("spark.kubernetes.executor.limit.cores", "1")
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.memoryOverhead", executor_overhead)
            .config("spark.driver.memoryOverhead", driver_overhead)
            .config("spark.executor.instances", "1")
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.jars", spark_jars)
            .config("spark.sql.execution.arrow.pyspark.enabled", "true")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
            .config("spark.eventLog.enabled", "true")
            .config("spark.eventLog.dir", event_log_dir)
            .getOrCreate()
        )
        return spark

    def _read_from_trino(
        self, spark: SparkSession, config: Dict, query: str, num_partitions: int = 10
    ) -> tuple:
        """Read data from Trino via JDBC. Returns (df, total_rows, read_time_seconds).

        2026-06-22 -- VISIBILITY OVERHAUL:
          * Log the FULL parameterised SQL before sending to Trino.
          * Warn loud on degenerate parameter substitution (e.g.,
            blank business_date -> ``CAST('' AS DATE)`` returns 0 rows
            silently, or in some Trino versions scans the whole table).
          * Time both COUNT(*) and the actual read.
          * Background heartbeat every 30s so the operator knows we're
            alive (or stuck).
          * Optional parallel read via ``partition_column`` +
            ``lower_bound`` / ``upper_bound`` from per-job JSON --
            without these, JDBC reads in a SINGLE task (slow for >5M rows).
        """
        import threading
        trino_url = config[self.TRINO_URL_KEY]
        trino_user = config['trino_user']
        trino_password = config['trino_password']
        fetchsize = config.get('fetchsize', '70000')

        self.logger.info(
            "Trino JDBC target: url=%s user=%s",
            trino_url, trino_user,
        )

        # ── Degenerate-query guard: if a polling-row substitution left
        #    a quoted empty value in the WHERE clause (e.g., ='' or
        #    =CAST('' AS DATE)), warn LOUD -- this is the #1 cause of
        #    "stuck forever / 0 rows" reports.
        for marker, label in (
            ("=CAST('' AS",  "empty business_date / date column"),
            ("=''",           "empty SYSTEM_ENTITY / EventCode / other param"),
            ("= ''",          "empty SYSTEM_ENTITY / EventCode / other param"),
        ):
            if marker in query:
                self.logger.warning(
                    "Trino query has %s -- the polling row may be "
                    "missing a required value.  Query will likely return "
                    "0 rows.  Marker: %r", label, marker,
                )

        # ── Log the FULL parameterised SQL.  Truncate ONLY if absurd.
        sql_to_log = query if len(query) < 4000 else query[:4000] + f"... (+{len(query) - 4000} chars)"
        self.logger.info("Trino query (parameterised):\n%s", sql_to_log)

        # 2026-06-22 -- TCP pre-flight is OPT-IN.  Operator hit production
        # outage when a strict preflight blocked otherwise-working
        # connects.  Default behaviour: skip the probe entirely -- the
        # JDBC driver does its own connect with its own timeout.  Enable
        # for debugging via env var TRINO_JDBC_ENABLE_PREFLIGHT=1.
        if os.environ.get("TRINO_JDBC_ENABLE_PREFLIGHT", "").lower() in ("1", "true", "yes"):
            try:
                from managers.trino_jdbc_preflight import tcp_preflight
                tcp_preflight(trino_url, timeout=5.0, logger=self.logger)
            except ImportError:
                pass

        # ── COUNT(*) pushdown with timing.
        count_query = f"SELECT COUNT(*) AS CNT FROM ({query}) t"
        self.logger.info("Phase 1/2: COUNT(*) on Trino...")
        count_start = datetime.now()
        cnt_df = (
            spark.read.format("jdbc")
            .option("url", trino_url)
            .option("dbtable", f"({count_query}) as c")
            .option("user", trino_user)
            .option("password", trino_password)
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .load()
        )

        # 2026-06-26 -- defensive extraction (matches light variant
        # tolerance at light_starburst_base.py:239).  Failure modes:
        #   1. ``collect()`` returns ``[]`` -- Trino returned no
        #      result row (very rare; usually means JDBC schema
        #      inference fired but the actual query failed silently)
        #   2. Column case mismatch -- Spark+Trino JDBC sometimes
        #      lowercases the AS alias depending on driver version
        #      (returns ``cnt`` instead of ``CNT``)
        #   3. NULL value in the CNT column -- shouldn't happen for
        #      COUNT(*) but guard anyway
        collected = cnt_df.collect()
        if not collected:
            self.logger.warning(
                "Trino COUNT(*) returned no result row -- treating "
                "as 0 (likely silent inner-query failure).  Inner "
                "query: %s", query[:500],
            )
            total_rows = 0
        else:
            row_dict = collected[0].asDict()
            cnt_val = row_dict.get("CNT")
            if cnt_val is None:
                cnt_val = row_dict.get("cnt")
            total_rows = int(cnt_val) if cnt_val is not None else 0

        count_time = (datetime.now() - count_start).total_seconds()
        self.logger.info(
            "Phase 1/2: COUNT(*) returned %s row(s) in %.1fs%s",
            f"{total_rows:,}", count_time,
            "  -- 0 rows: verify polling-row business_date/system_entity/eventcode"
            if total_rows == 0 else "",
        )

        # ── 0-row short-circuit.
        # Trying to read 0 rows still opens a JDBC connection +
        # ships a schema-inference query; trying to write an empty
        # DataFrame still opens Oracle JDBC connections + commits
        # an empty transaction.  Both are wasted work.  Return
        # (None, 0, 0.0) so the caller can skip both phases AND
        # still report success.  Caller MUST check total_rows == 0
        # before touching the returned DataFrame.
        if total_rows == 0:
            self.logger.info(
                "Trino COUNT(*) = 0 -- skipping read + write phases. "
                "Step succeeds as a no-op."
            )
            return None, 0, 0.0

        # ── Read with optional parallel partitioning.
        #    Per-job JSON can specify:
        #      "partition_column": "BUSINESS_CLOSE_DATE"     (numeric / date col)
        #      "lower_bound":      "2025-09-01"
        #      "upper_bound":      "2025-10-01"
        #    Without these, JDBC uses a single task (serial).
        partition_column = config.get("partition_column") or ""
        lower_bound = str(config.get("lower_bound") or "")
        upper_bound = str(config.get("upper_bound") or "")
        parallel = bool(partition_column and lower_bound and upper_bound)
        if total_rows > 5_000_000 and not parallel:
            self.logger.warning(
                "Trino COUNT = %s rows but no partition_column / "
                "lower_bound / upper_bound in per-job JSON -- read will "
                "use a SINGLE serial JDBC task.  Add those keys to "
                "query_fact_table.json to enable %dx parallel reads.",
                f"{total_rows:,}", num_partitions,
            )

        phase_label = (
            f"PARALLEL ({num_partitions} tasks on {partition_column})"
            if parallel else "SERIAL (single task)"
        )
        self.logger.info("Phase 2/2: READ from Trino [%s]...", phase_label)
        read_start = datetime.now()

        # ── Heartbeat thread: log every 30s so the operator knows we're alive.
        _stop = threading.Event()
        def _heartbeat():
            secs = 0
            while not _stop.is_set():
                if _stop.wait(30):
                    return
                secs += 30
                self.logger.info(
                    "Phase 2/2: still reading from Trino... elapsed=%ds "
                    "(SQL=%s rows expected)",
                    secs, f"{total_rows:,}",
                )
        hb = threading.Thread(target=_heartbeat, daemon=True)
        hb.start()

        try:
            reader = (
                spark.read.format("jdbc")
                .option("url", trino_url)
                .option("dbtable", f"({query}) as subq")
                .option("user", trino_user)
                .option("password", trino_password)
                .option("driver", "io.trino.jdbc.TrinoDriver")
                .option("fetchsize", str(fetchsize))
                .option("numPartitions", str(num_partitions))
            )
            if parallel:
                reader = (
                    reader
                    .option("partitionColumn", partition_column)
                    .option("lowerBound", lower_bound)
                    .option("upperBound", upper_bound)
                )
            df = reader.load()
        finally:
            _stop.set()

        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(
            "Phase 2/2: READ DataFrame ready in %.1fs.  Note: actual "
            "row materialisation happens during the Oracle write.",
            read_time,
        )

        return df, total_rows, read_time

    def _write_to_oracle(
        self, df: DataFrame, config: Dict, table: str,
        batch_size: int = 50000, num_partitions: int = 10
    ) -> float:
        """Write DataFrame to Oracle via JDBC. Returns write_time_seconds."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']

        self.logger.info(f"Repartitioning to {num_partitions} partitions before write...")
        df = df.repartition(num_partitions)

        self.logger.info(f"Writing to {table}")
        write_start = datetime.now()
        (
            df.write.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", table)
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("batchsize", str(batch_size))
            .option("isolationLevel", "NONE")
            .option("numPartitions", str(num_partitions))
            .mode("append")
            .save()
        )
        write_time = (datetime.now() - write_start).total_seconds()
        self.logger.info(f"Write completed in {write_time:.2f}s")
        return write_time

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        """Execute the Starburst→Oracle step: read from Trino, write to Oracle."""
        config = self._load_and_validate_config(task)
        self._setup_logging(task)

        # Parameterize query
        raw_query = config[self.QUERY_KEY]
        trino_query = self._parameterize_query(raw_query, task)

        # 2026-06-12 — feed the parameterised SQL to the run report
        # when one is attached to the task dict.  Same plumbing as the
        # light variant; FileRunReport writes queries/<job_id>.sql + a
        # download link in the HTML.  No-op when no report is wired.
        run_report = task.get("_run_report")
        if run_report is not None:
            try:
                job_id = (
                    task.get("fk_dag_id")
                    or task.get("dag_id")
                    or task.get("run_id")
                    or self.LOG_PREFIX
                )
                run_report.add_sql_summary(str(job_id), trino_query)
            except Exception as exc:
                self.logger.warning(
                    f"Could not feed SQL to run_report: {exc}"
                )

        batch_size = config.get('batch_size', 50000)
        num_partitions = config.get('num_partitions', 10)
        oracle_table = task["dest_table"]

        # Build Spark session
        spark = None
        try:
            spark = self._build_spark_session(task, config)
        except Exception as e:
            self.logger.error(f"Spark session failed: {e}", exc_info=True)
            raise RuntimeError(f"Spark init failed: {e}") from e

        # 2026-06-12 — Spark job group so an outer cancel (polling
        # service timeout / pod shutdown) can stop the in-flight
        # JDBC scan on Starburst.  ``interruptOnCancel=True`` lets
        # SparkContext.cancelJobGroup actually interrupt the executor
        # thread that's blocked on the JDBC fetch.
        from starburst_cancellation import (
            StarburstCancellable, KIND_SPARK_JOB_GROUP,
            register_starburst_cancellable, unregister_starburst_cancellable,
        )
        run_id = task.get("run_id", "x")
        run_detail_id = task.get("run_detail_id", "x")
        sb_group_id = f"{self.LOG_PREFIX}_{run_id}_{run_detail_id}"
        try:
            spark.sparkContext.setJobGroup(
                sb_group_id,
                f"Starburst -> Oracle ({self.LOG_PREFIX}) run_id={run_id}",
                interruptOnCancel=True,
            )
        except Exception as exc:
            self.logger.warning(f"setJobGroup failed (cancel will degrade): {exc}")
        sb_cancellable = StarburstCancellable(
            KIND_SPARK_JOB_GROUP, spark=spark, group_id=sb_group_id,
            label=f"{self.LOG_PREFIX}.spark",
        )
        register_starburst_cancellable(task, sb_cancellable)

        try:
            # Read from Trino.  When COUNT(*) returns 0 rows,
            # _read_from_trino short-circuits: returns (None, 0, 0.0)
            # so the caller can skip the Oracle write entirely.
            df, total_rows, read_time = self._read_from_trino(
                spark, config, trino_query, num_partitions
            )
            task['totalcount'] = total_rows

            # 2026-06-26 -- 0-row short-circuit.  Skip the Oracle JDBC
            # write entirely when there's nothing to write.  Still
            # update OTG_ETL_BATCH_STATUS with totalcount=0 below so
            # downstream steps (CheckDataCompleteness, run report)
            # see the 0 explicitly rather than missing-status.
            if total_rows == 0:
                self.logger.info(
                    "Skipping Oracle write -- 0 rows from source.  "
                    "Step succeeds with totalcount=0."
                )
                write_time = 0.0
            else:
                # Write to Oracle
                write_time = self._write_to_oracle(
                    df, config, oracle_table, batch_size, num_partitions
                )

            total_time = read_time + write_time
            self.logger.info(f"TOTAL TIME: {total_time:.2f}s (read={read_time:.2f}s, write={write_time:.2f}s)")

            # Update record count in Oracle metadata (with 0 when applicable
            # so downstream completeness checks see the 0 explicitly).
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            unregister_starburst_cancellable(task, sb_cancellable)
            if spark:
                try:
                    spark.sparkContext.clearJobGroup()
                except Exception:
                    pass
                try:
                    spark.stop()
                    self.logger.info("Spark session stopped successfully")
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark session: {stop_err}")
