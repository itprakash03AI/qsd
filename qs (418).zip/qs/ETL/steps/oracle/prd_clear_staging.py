from typing import Any, Dict
from core_libs.logger.firelogger import CentralizedLogger
from steps.BaseStep import BaseStep
from datetime import datetime

logger = CentralizedLogger(
    log_file="/usr/local/spark/nfs/bcp/batch/logs/clearstaging_{date_str}.log",
    log_level="INFO",
    backup_count=30,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
).get_logger(__name__)


class ClearStaging(BaseStep):
    """Step to clear the staging table by executing a stored procedure based on procedure ID."""

    async def execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str, step_name: str, *args, **kwargs) -> Dict[str, Any]:
        """Clear the staging table for the task by executing a stored procedure based on procedure ID."""
        logger.info(f"{step_name} has been started")
        # Retrieve procedure ID from task (e.g., PRELOAD_TASK_PROC_CONFIGID for clear staging)
        proc_id = task.get("preload_task_proc_configid")
        otg_dag_id = task.get('otg_dag_id')
        business_date = task.get('business_date')
        report_id = task.get('fk_report_id')
        run_id = task.get('run_id')
        procname = task.get('preloadprocname')
        run_detail_id = task.get("run_detail_id")

        if not proc_id:
            raise ValueError(f"Preload task procedure ID not found for task {task.get('task_id')}")

        # Fetch procedure parameters using OracleDataManager
        procedure_params = await self.oracle_data_manager.get_procedure_params_async(otg_dag_id, business_date, proc_id, "PRELOAD", "internal", worker_connection_string)

        logger.info(f"Clear staging proc name :{procname}")
        logger.info(f"Parameter mappings :{procedure_params}")

        if not procedure_params:
            raise ValueError(f"No parameters found for procedure ID {proc_id} for task {task.get('task_id')}")

        # Execute the stored procedure (assuming a generic name like "CLEAR_STAGING_PROC")
        logger.info(f"Executing CLEAR_STAGING_PROC with params: {procedure_params}")
        df = await self.oracle_data_manager.execute_procedure_with_dataframe(procname, procedure_params, dest_connection_string, 'external')

        # Defensive checks on the returned dataframe
        if df is None:
            raise Exception(f"Procedure returned None (procname={procname}, run_id={run_id}, run_detail_id={run_detail_id})")

        if "STATUS" not in df.columns:
            raise Exception(
                f"Procedure result missing STATUS column (procname={procname}, columns={list(df.columns)})"
            )

        # Normalize status checks
        statuses = df["STATUS"].astype(str).str.upper()

        if (statuses != "SUCCESS").any():
            raise Exception(f"PreLoad Proc Failed (procname={procname}, run_id={run_id}, run_detail_id={run_detail_id})")

        self.logger.info(f"{step_name} completed successfully")

        # Return a lightweight result for traceability
        return {
            "status": "SUCCESS",
            "procname": procname,
            "proc_id": proc_id,
            "timestamp": datetime.utcnow().isoformat()
        }