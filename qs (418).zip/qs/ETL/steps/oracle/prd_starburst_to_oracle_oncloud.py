import os
import time
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, when, to_date, date_format, coalesce, lit
)
from pyspark.sql.functions import col, to_date, coalesce, lit, monotonically_increasing_id
import json
import logging
import sys
from datetime import datetime
from typing import Dict, List, Optional
from steps.BaseStep import BaseStep
from managers.oracle_metadata_manager import OracleMetadataManager


class StarburstToOracle_OnCloud(BaseStep):
    """Spark step to read from Starburst (Trino) and write directly to Oracle, inheriting from BaseStep."""

    async def execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str, step_name: str, *args, **kwargs) -> int:
        """Execute the Spark job to read from Trino and write to Oracle."""
        # config_path = "/usr/local/spark/pvc/code/configs/spark_trino_oracle_fact_tetb.json"
        config_path = task.get('sql_query_path')

        # === 1. Load & Validate Config ===
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            self.logger.error(f"Config file not found: {config_path}")
            return {"status": "FAILED", "rows_inserted": 0, "error_message": f"Config file not found: {config_path}", "errored_rows": []}
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in config file {config_path}: {str(e)}")
            return {"status": "FAILED", "rows_inserted": 0, "error_message": f"Invalid JSON: {str(e)}", "errored_rows": []}

        # Extract and validate config parameters
        # Required fields
        required_fields = [
            'query_on_cloud', 'trino_oncloud_url', 'trino_user', 'trino_password',
            'oracle_url', 'oracle_user', 'oracle_password',
            'spark_jars', 'spark_executor_cores', 'spark_executor_memory',
            'spark_driver_memory', 'spark_shuffle_partitions'
        ]
        for field in required_fields:
            if field not in config:
                self.logger.error(f"Missing required config field: {field}")
                return {"status": "FAILED", "rows_inserted": 0, "error_message": f"Missing config field: {field}", "errored_rows": []}

        # Extract config
        trino_query = config['query_on_cloud'].replace('{BUSINESSDATE}', task.get('business_date')).replace('{SYSTEM_ENTITY}', task.get('system_entity')).replace('{EventCode}', task.get('eventcode'))
        trino_url = config['trino_oncloud_url']
        trino_user = config['trino_user']
        trino_password = config['trino_password']
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']
        batch_size = config.get('batch_size', 50000)
        num_partitions = 10
        log_path = f"/usr/local/spark/nfs/bcp/batch/logs/sb_to_oracle_oncloud_{task.get('run_id')}_{task.get('run_detail_id')}_{datetime.now().strftime('%Y-%m-%d')}.log"

        # Spark config
        spark_jars = config['spark_jars']  # e.g., "/opt/spark/jars/ojdbc8.jar,/opt/spark/jars/trino-jdbc.jar"
        # executor_cores =   task["spark_executor_cores"]
        # executor_memory =  task["spark_executor_memory"]
        # driver_memory =    task["spark_driver_memory"]
        # shuffle_partitions = task["spark_shuffle_partitions"]
        oracle_table = task["dest_table"]

        # === 2. Setup Logging ===
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler(log_path)
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Logging to: {log_path}")

        event_log_dir = f"/usr/local/spark/nfs/bcp/batch/logs/event-logs/{task.get('run_id')}_{task.get('run_detail_id')}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        os.makedirs(event_log_dir, exist_ok=True)

        # === 3. Launch Spark Session (All from Config) ===# .config("spark.sql.shuffle.partitions", str(shuffle_partitions)) \
        try:
            spark = SparkSession.builder \
                .appName(f"starburst_oracle_Oncloud_{task.get('run_id')}-{task.get('run_detail_id')}") \
                .config("spark.kubernetes.executor.request.cores", "1") .config("spark.kubernetes.executor.limit.cores", "1") \
                .config("spark.executor.memory", "10g") .config("spark.driver.memory", "3g") .config("spark.executor.memoryOverhead", "1g") \
                .config("spark.driver.memoryOverhead", "1g") .config("spark.executor.instances", "1") \
                .config("spark.sql.shuffle.partitions", str(num_partitions)) .config("spark.jars", spark_jars) \
                .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
                .config("spark.dynamicAllocation.enabled", "false") .config("spark.sql.adaptive.enabled", "true") \
                .config("spark.eventLog.dir", event_log_dir) .config("spark.eventLog.enabled", "true") \
                .getOrCreate()
        except Exception as e:
            self.logger.error(f"Spark session failed: {e}")
            return {"status": "FAILED", "rows_inserted": 0, "error_message": f"Spark init failed: {e}"}

        try:
            # ---- 1) Get record count using COUNT pushdown (NO df.count()) ----
            count_query = f"SELECT COUNT(*) AS CNT FROM ({trino_query}) t"

            self.logger.info("Fetching recordcount from Starburst/Trino via COUNT(*) pushdown...")
            cnt_df = (spark.read.format("jdbc")
                      .option("url", trino_url) .option("dbtable", f"({count_query}) as c")
                      .option("password", trino_password) .option("driver", "io.trino.jdbc.TrinoDriver")
                      .option("user", trino_user)
                      .load())

            total_rows = int(cnt_df.collect()[0]["CNT"])
            self.logger.info(f"Record count from source = {total_rows}")
            task['totalcount'] = total_rows

            self.logger.info("Reading data...")
            read_start = datetime.now()
            df = (spark.read.format("jdbc")
                  .option("url", trino_url) .option("dbtable", f"({trino_query}) as subq")
                  .option("user", trino_user)
                  .option("password", trino_password) .option("driver", "io.trino.jdbc.TrinoDriver") .option("fetchsize", "70000")
                  .option("numPartitions", str(num_partitions))
                  .load())

            read_time = (datetime.now() - read_start).total_seconds()
            self.logger.info(f"Read all rows in {read_time:.2f}s")

            # === 3. Repartition Before Write ===
            self.logger.info(f"Repartitioning to {num_partitions} partitions before write...")

            df = df.repartition(num_partitions)

            # === 4. Direct Parallel Write (No Streaming) ===
            self.logger.info(f"Writing to {oracle_table}")
            write_start = datetime.now()
            (df.write.format("jdbc") .option("url", oracle_url) .option("dbtable", oracle_table)
                .option("user", oracle_user) .option("password", oracle_password) .option("driver", "oracle.jdbc.OracleDriver")
                .option("batchsize", str(batch_size)) .option("isolationLevel", "NONE") .option("numPartitions", str(num_partitions)) .mode("append")
                .save())

            total_time = (datetime.now() - read_start).total_seconds()
            self.logger.info(f"TOTAL TIME: {total_time:.2f}s")
            await self.oracle_data_manager.update_otg_etl_batch_status(task.get("run_id"), task.get("run_detail_id"), 'UPDATE_TASK_RECORDCOUNT', step_name, total_rows, "", worker_connection_string)
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise