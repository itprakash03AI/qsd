"""
Starburst/Trino (On-Prem) → Oracle step.
Extends StarburstBase — only overrides on-prem-specific config keys and memory defaults.
"""
from steps.oracle.starburst_base import StarburstBase


class StarburstToOracle_OnPrem(StarburstBase):
    """Spark step to read from Starburst On-Prem (Trino) and write to Oracle.

    2026-06-22 -- DEFAULT_*_MEMORY are LAST-RESORT fallbacks only.
    See StarburstToOracle_OnCloud docstring for the full precedence
    chain (polling row > per-job JSON > oracle_config.yaml > these
    class defaults).
    """

    QUERY_KEY = "query_on_prem"
    TRINO_URL_KEY = "trino_onprem_url"
    # Fallback memory only -- ONPREM default higher than ONCLOUD because
    # on-prem Trino tends to return wider rows + more data volume.
    # Override per report via polling-row SPARK_EXECUTOR_MEMORY.
    DEFAULT_EXECUTOR_MEMORY = "15g"
    DEFAULT_DRIVER_MEMORY = "4g"
    LOG_PREFIX = "sb_to_oracle_onprem"
