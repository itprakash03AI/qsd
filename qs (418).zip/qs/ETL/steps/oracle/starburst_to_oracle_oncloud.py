"""
Starburst/Trino (Cloud) → Oracle step.
Extends StarburstBase — only overrides cloud-specific config keys and memory defaults.
"""
from steps.oracle.starburst_base import StarburstBase


class StarburstToOracle_OnCloud(StarburstBase):
    """Spark step to read from Starburst Cloud (Trino) and write to Oracle.

    2026-06-22 -- DEFAULT_*_MEMORY are LAST-RESORT fallbacks only.
    Precedence (highest to lowest):
      1. Polling-row columns (SPARK_EXECUTOR_MEMORY / SPARK_DRIVER_MEMORY
         + _OVERHEAD variants).  Propagated into per-job JSON by
         GenerateSQL._phase152_passthrough; consumed by StarburstBase.
      2. Per-job JSON keys (spark_executor_memory / spark_driver_memory)
         set directly in the metadata file.
      3. oracle_config.yaml spark_defaults section (not yet wired;
         operator can add per-cluster defaults there if needed).
      4. These DEFAULT_* class attrs -- absolute last resort.
    """

    QUERY_KEY = "query_on_cloud"
    TRINO_URL_KEY = "trino_oncloud_url"
    # Fallback memory only -- set SPARK_EXECUTOR_MEMORY on polling row
    # to override per report (e.g., 150M-row jobs may need 20g+).
    DEFAULT_EXECUTOR_MEMORY = "10g"
    DEFAULT_DRIVER_MEMORY = "3g"
    LOG_PREFIX = "sb_to_oracle_oncloud"
