"""BF-595 (2026-05-30) — non-Spark Starburst (On-Prem) → Oracle step.

Drop-in lightweight replacement for ``StarburstToOracle_OnPrem``
used by the polling-service path.  Same config-file format, same
task contract, same STATUS lifecycle — Spark removed.

See ``light_starburst_base.LightStarburstBase`` for the full
rationale and trade-offs.
"""
from steps.oracle.light_starburst_base import LightStarburstBase


class LightStarburstToOracle_OnPrem(LightStarburstBase):
    """Non-Spark step to read from Starburst On-Prem (Trino) and write to Oracle."""
    QUERY_KEY = "query_on_prem"
    TRINO_URL_KEY = "trino_onprem_url"
    LOG_PREFIX = "light_sb_to_oracle_onprem"
