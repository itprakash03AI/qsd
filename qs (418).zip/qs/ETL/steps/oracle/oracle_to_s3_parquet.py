"""
Oracle → S3 Parquet step.
Reads from Oracle via JDBC, writes partitioned parquet to S3.
"""
from typing import Dict, Any
from steps.s3.s3_base_step import S3BaseStep


class OracleToS3Parquet(S3BaseStep):
    """Read from Oracle via JDBC and write partitioned parquet to S3."""

    LOG_PREFIX = "oracle_to_s3_parquet"

    REQUIRED_FIELDS = [
        'oracle_url', 'oracle_user', 'oracle_password',
        's3_access_key', 's3_secret_key', 's3_bucket', 's3_prefix',
        'source_query',
    ]

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                            dest_connection_string: str, step_name: str, *args, **kwargs) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        source_query = self._parameterize_query(config['source_query'], task)
        s3_output_path = f"s3a://{config['s3_bucket']}/{config['s3_prefix']}"
        partition_cols = config.get('s3_partition_columns', [])
        num_partitions = config.get('num_partitions', 10)

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config)

            df, total_rows, _ = self._read_from_oracle(spark, config, source_query, num_partitions)
            task['totalcount'] = total_rows

            self.logger.info(f"Writing to {s3_output_path}")
            writer = df.write.mode(config.get('write_mode', 'overwrite'))
            if partition_cols:
                writer = writer.partitionBy(*partition_cols)
            writer.parquet(s3_output_path)
            self.logger.info("S3 parquet write completed")

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
