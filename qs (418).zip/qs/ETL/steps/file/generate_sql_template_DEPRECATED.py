"""GenerateSQL — TEMPLATE step (operator fills business logic).

Pre-wired with the file-flow conventions (single-file logging, run
report, artifact registry).  Operator drops the actual SQL-templating
rules into ``_generate_sql_for_job``.

Typical responsibilities:

  1. Read the per-job ``query_template`` / parameters from the JSON
     pointed at by ``task['sql_query_path']``.
  2. Substitute placeholders ({BUSINESSDATE}, {SYSTEM_ENTITY},
     {EVENT_CODE}, …) using polling-row values.
  3. Write the resolved ``generated_sql`` back into the SAME JSON so
     the Starburst extract step picks it up unchanged.

The default substitutions below cover the standard
{BUSINESSDATE}/{REPORT_ID}/{RUN_ID}/{DATE} placeholders.  Add tenant-
specific substitutions in ``_extra_substitutions``.

Why we mutate the JSON in-place: every downstream step in this
workflow already reads ``query_config['jobs'][i]['generated_sql']``.
Keeping the substitution at this layer means no other step needs to
know about templates.

Failure is loud — any unresolved placeholder OR missing source
template raises so the pipeline halts before extracting against a
half-formed SQL string.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
from datetime import datetime
from typing import Any, Dict, List

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import get_or_create_artifacts


_PLACEHOLDER_RE = re.compile(r"\{[A-Z][A-Z0-9_]*\}")


class GenerateSQL(BaseStep):
    """Render per-job SQL templates into ``generated_sql`` in the JSON config."""

    LOG_PREFIX = "generate_sql"

    def _setup_logging(self, task: Dict) -> None:
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            # 2026-06-12 -- NO /tmp fallback.  OpenShift pods have tiny
            # ephemeral storage; logs MUST land on the configured NFS
            # path (ETL_LOG_DIR env / YAML / POSIX default).  A missing
            # log_config is a deployment break -- fail loudly here so
            # ops sees it instead of silently writing to /tmp.
            from log_config import get_log_dir as _ld
            base = _ld()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log")
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError:
            pass

    # ----- Substitution hooks ------------------------------------------

    def _base_substitutions(self, task: Dict) -> Dict[str, str]:
        now = datetime.now()
        biz = str(task.get("business_date") or "")
        # Accept dd-MM-yyyy (file-flow convention) and produce a sortable
        # yyyy-MM-dd alias for queries that want ISO format.
        biz_iso = biz
        if re.match(r"^\d{2}-\d{2}-\d{4}$", biz):
            d, m, y = biz.split("-")
            biz_iso = f"{y}-{m}-{d}"
        return {
            "BUSINESSDATE": biz,
            "BUSINESS_DATE_ISO": biz_iso,
            "REPORT_ID": str(task.get("fk_report_id", "")),
            "RUN_ID": str(task.get("run_id", "")),
            "DAG_ID": str(task.get("fk_dag_id", "")),
            "DATE": now.strftime("%Y-%m-%d"),
            "TIMESTAMP": now.strftime("%Y-%m-%d %H:%M:%S"),
            "YEAR": now.strftime("%Y"),
            "MONTH": now.strftime("%m"),
            "DAY": now.strftime("%d"),
        }

    def _extra_substitutions(self, task: Dict, job: Dict[str, Any]) -> Dict[str, str]:
        """Operator extension point.

        Return any tenant-specific {PLACEHOLDER} → value mappings.
        Override in a subclass when the standard set above isn't enough.
        """
        extras: Dict[str, str] = {}
        for src_key, placeholder in (
            ("system_entity", "SYSTEM_ENTITY"),
            ("eventcode", "EVENT_CODE"),
            ("event_code", "EVENT_CODE"),
        ):
            v = task.get(src_key)
            if v not in (None, ""):
                extras[placeholder] = str(v)
        # Job-config values win over task values for repeated keys.
        for k in ("system_entity", "event_code", "eventcode"):
            v = job.get(k)
            if v not in (None, ""):
                placeholder = "EVENT_CODE" if k.endswith("eventcode") or k == "event_code" else "SYSTEM_ENTITY"
                extras[placeholder] = str(v)
        return extras

    def _apply_substitutions(self, template: str, mapping: Dict[str, str]) -> str:
        out = template
        for key, val in mapping.items():
            out = out.replace("{" + key + "}", val)
        return out

    # ----- Per-job rendering -------------------------------------------

    def _generate_sql_for_job(
        self, task: Dict, job: Dict[str, Any],
    ) -> str:
        """Default render: take ``query_template`` (or already-resolved
        ``generated_sql`` if no template present), apply substitutions,
        return the resolved SQL.

        Override in a subclass when the SQL needs to be assembled from
        multiple sub-templates / fragments.
        """
        template = (
            job.get("query_template")
            or job.get("sql_template")
            or job.get("generated_sql")
        )
        if not template:
            raise ValueError(
                f"GenerateSQL: job {job.get('report_id')!r} has no query_template / "
                f"sql_template / generated_sql to render."
            )
        mapping = {**self._base_substitutions(task), **self._extra_substitutions(task, job)}
        sql = self._apply_substitutions(template, mapping)

        unresolved = _PLACEHOLDER_RE.findall(sql)
        if unresolved:
            raise ValueError(
                f"GenerateSQL: job {job.get('report_id')!r} has unresolved placeholder(s) "
                f"after substitution: {sorted(set(unresolved))}.  Either populate the "
                f"corresponding polling-row column or extend _extra_substitutions."
            )
        return sql

    # ----- BaseStep contract -------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> int:
        self._setup_logging(task)
        get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        run_report: FileRunReport = rr if isinstance(rr, FileRunReport) else None

        json_path = task.get("sql_query_path")
        if not json_path or not os.path.exists(json_path):
            raise ValueError(
                f"GenerateSQL: sql_query_path missing or not on disk: {json_path!r}"
            )

        self.logger.info("=" * 72)
        self.logger.info("GenerateSQL for run_id=%s report_id=%s json=%s",
                          task.get("run_id"), task.get("fk_report_id"), json_path)
        self.logger.info("=" * 72)

        with open(json_path, "r", encoding="utf-8") as f:
            query_cfg = json.load(f)
        if not isinstance(query_cfg, dict) or not isinstance(query_cfg.get("jobs"), list):
            raise ValueError(
                f"GenerateSQL: query config at {json_path} must be an object with a 'jobs' list"
            )

        jobs: List[Dict[str, Any]] = query_cfg["jobs"]
        if not jobs:
            raise ValueError(f"GenerateSQL: 'jobs' list is empty in {json_path}")

        rendered = 0
        for job in jobs:
            try:
                sql = self._generate_sql_for_job(task, job)
            except Exception as exc:
                self.logger.error(
                    "GenerateSQL FAILED for job report_id=%s datasource=%s: %s",
                    job.get("report_id"), job.get("datasource_name"), exc,
                )
                raise
            job["generated_sql"] = sql
            rendered += 1
            self.logger.info(
                "Rendered SQL for report_id=%s datasource=%s (%d chars, first line=%r)",
                job.get("report_id"), job.get("datasource_name"),
                len(sql), sql.strip().splitlines()[0][:120] if sql.strip() else "",
            )
            if run_report is not None:
                run_report.add_sql_summary(str(job.get("report_id", "?")), sql)

        # Persist updated JSON back to disk so downstream steps see the
        # resolved SQL.  Atomic write: tmp + os.replace.
        tmp = json_path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(query_cfg, f, indent=2, default=str)
                try:
                    f.flush()
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp, json_path)
        except Exception:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            raise

        self.logger.info("GenerateSQL OK: rendered %d job(s) → %s", rendered, json_path)
        if run_report is not None:
            run_report.runtime_knobs.update({"generate_sql_jobs_rendered": rendered})

        task["totalcount"] = 0
        return 0
