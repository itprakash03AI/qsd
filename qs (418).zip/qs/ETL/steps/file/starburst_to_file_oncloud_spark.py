"""StarburstToFile_OnCloud_Spark — Spark-based cloud variant.

Thin subclass of ``StarburstFileSparkBase``.  Reads from the CLOUD
Starburst catalog via Spark JDBC + writes per-partition CSV files
that the existing ``ConsolidateFiles`` step picks up unchanged.

Credentials: ``[Starburst-Cloud]`` (preferred) → ``[Starburst]``
fallback, mirroring the non-Spark variant.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.file.starburst_file_spark_base import StarburstFileSparkBase


class StarburstToFile_OnCloud_Spark(StarburstFileSparkBase):
    DATASOURCE_NAME = "CLOUD"
    LOG_PREFIX = "starburst_to_file_oncloud_spark"

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """File-workflow cloud connection (2026-06-22 -- creds-from-yaml):

          * user / password    -- YAML (recommended) > INI > per-job JSON.
                                   Validation fails loud if ALL three
                                   sources are empty.
          * host / port        -- per-job JSON ``server_name`` / ``port``
                                   (from OTG_DATA_SOURCE_DETAILS via
                                   GenerateSQL).  Per-job context.
          * catalog / schema   -- YAML > INI > per-job JSON.
        """
        shared = self._shared_starburst_fallback("oncloud")
        ini = self.ini_config
        section = "Starburst-Cloud" if (ini and ini.has_section("Starburst-Cloud")) else "Starburst"
        if ini and ini.has_section(section):
            ini_user = ini.get(section, "username", fallback="")
            ini_password = ini.get(section, "password", fallback="")
            ini_catalog = ini.get(section, "catalog", fallback="")
            ini_schema = ini.get(section, "schema", fallback="")
        else:
            ini_user = ini_password = ini_catalog = ini_schema = ""

        # CREDS: YAML > INI > per-job JSON.
        user = (
            shared.get("user") or ini_user or job_config.get("trino_user", "") or ""
        )
        password = (
            shared.get("password") or ini_password
            or job_config.get("trino_password", "") or ""
        )
        catalog = (
            shared.get("catalog") or ini_catalog or job_config.get("catalog", "") or ""
        )
        schema = (
            shared.get("schema") or ini_schema or job_config.get("schema", "") or ""
        )
        # HOST + PORT: per-job JSON only (GenerateSQL -> OTG_DATA_SOURCE_DETAILS).
        host = job_config["server_name"]
        port = int(job_config["port"])

        # Validate ONLY the fields this code path consumes from yaml/INI
        # /JSON.  host/port already validated by the per-job JSON contract
        # (would have failed earlier with KeyError if missing).
        missing = []
        if not user:
            missing.append("user (yaml: starburst.user / starburst.oncloud.user)")
        if not password:
            missing.append("password (yaml: starburst.password / starburst.oncloud.password)")
        if missing:
            raise ValueError(
                f"Spark cloud connection: missing required credential(s) for "
                f"report_id={job_config.get('report_id')}:\n"
                + "".join(f"  * {m}\n" for m in missing)
                + f"Sources consulted (in priority order):\n"
                f"  1. configs/starburst_config.yaml  -- oncloud or root user/password\n"
                f"  2. INI [{section}] in $EXPORT_TOOL_CONFIG_PATH\n"
                f"  3. per-job JSON trino_user / trino_password\n"
                f"  4. env STARBURST_ONCLOUD_USER / STARBURST_ONCLOUD_PASSWORD\n"
                f"Fill at least one source."
            )

        jdbc_url = f"jdbc:trino://{host}:{port}/{catalog}/{schema}?SSL=true"
        self.logger.info(
            "Spark cloud JDBC URL resolved: %s (user source=%s)",
            jdbc_url,
            "YAML" if shared.get("user") else ("INI" if ini_user else "per-job JSON"),
        )
        return {
            "jdbc_url": jdbc_url,
            "user": user,
            "password": password,
            "fetchsize": int(job_config.get("fetchsize", self.DEFAULT_FETCHSIZE)),
        }
