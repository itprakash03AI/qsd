"""Spark-based base for Starburst → flat-file extract steps.

Sibling to ``starburst_file_base.py`` (pure-Python / trino DBAPI).
Same contracts — FileRunReport, RunArtifacts, completeness ledger
G1-G5 — but the read + write engine is PySpark + JDBC Trino driver
instead of the python trino client.

When to use the Spark variant:
  * Large jobs where Spark's parallel JDBC reader (numPartitions +
    partitionColumn + lowerBound + upperBound) beats single-cursor
    fetchmany.
  * Jobs that already run on a Spark pod (createJob workflow style)
    where bringing Spark up is essentially free.
  * Output volume large enough to benefit from Spark's writer
    parallelism + native gzip/snappy compression.

When NOT to use it:
  * Sub-1M row jobs — Spark startup cost dominates.
  * Pods without the Spark runtime — the import will fail.

This base intentionally mirrors the pure-Python base's CLASS and
INSTANCE attribute names so subclasses can swap their parent class
without touching the rest of the step body.  ScanPlan / mode / artifact
+ run-report integration are identical to the pure-Python flow.

Architecture:

  1. Spark session per job (executor / driver memory tuned via job
     config; same knobs starburst_base.py exposes).
  2. JDBC read using ``io.trino.jdbc.TrinoDriver`` — query wrapped as
     ``"(generated_sql) as subq"``.  COUNT(*) pre-flight pushdown for
     G1 (no full scan).
  3. PARTITION_VALUES mode uses Spark's parallel JDBC partitioner:
     ``partitionColumn`` + ``lowerBound`` + ``upperBound`` +
     ``numPartitions``.  For string-typed partition columns we fall
     back to ``predicates=[col='v1', col='v2', ...]`` which emits one
     concurrent JDBC query per value — same shape as the pure-Python
     PARTITION_VALUES path, just parallel-fetched by Spark.
  4. Write: ``df.write.option("header", true).csv(<chunk_dir>)`` —
     Spark produces one ``part-*.csv`` per task.  We rename them into
     ``<base>.part_NNNN_<value>.<ext>`` so the existing ConsolidateFiles
     step picks them up unchanged.
  5. Completeness: ``df.count()`` after write equals the expected G1.

Subclasses provide DATASOURCE_NAME + LOG_PREFIX + the
``_build_connection_config`` override (cloud vs on-prem ini section).
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import sys
import time
import configparser
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts,
    get_or_create_artifacts,
    load_state,
    save_task_state,
)


# ──────────────────────────────────────────────────────────────────────
#  Base step
# ──────────────────────────────────────────────────────────────────────

class StarburstFileSparkBase(BaseStep):
    """Spark-based Starburst → file shared logic.

    Subclasses provide:
        DATASOURCE_NAME    — "CLOUD" or "ONPREM"
        LOG_PREFIX         — module-level logger name
        FORCE_PARTITIONED  — bool, when True every job uses the
                             parallel-partitioned JDBC reader even
                             without partition_config.enabled.

    Subclasses can override ``_build_connection_config`` to pick a
    different ini section for credentials.
    """

    DATASOURCE_NAME: str = ""
    LOG_PREFIX: str = "starburst_to_file_spark"
    FORCE_PARTITIONED: bool = False

    DEFAULT_EXECUTOR_MEMORY = "8g"
    DEFAULT_DRIVER_MEMORY = "3g"
    DEFAULT_NUM_PARTITIONS = 8
    DEFAULT_FETCHSIZE = 50_000

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ini_config: Optional[configparser.ConfigParser] = None
        self.query_config: Optional[Dict[str, Any]] = None
        self.run_report: Optional[FileRunReport] = None
        self.artifacts: Optional[RunArtifacts] = None

    # ----- Setup ------------------------------------------------------

    def _setup_logging(self, task: Dict) -> None:
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            # 2026-06-12 -- NO /tmp fallback.  OpenShift pods have tiny
            # ephemeral storage; logs MUST land on the configured NFS
            # path (ETL_LOG_DIR env / YAML / POSIX default).  A missing
            # log_config is a deployment break -- fail loudly here so
            # ops sees it instead of silently writing to /tmp.
            from log_config import get_log_dir as _ld
            base = _ld()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(
                base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as exc:
            self.logger.warning("Cannot create log file %s: %s — console only", log_path, exc)

    def _load_ini_config(self) -> configparser.ConfigParser:
        cfg = configparser.ConfigParser()
        path = os.getenv(
            "EXPORT_TOOL_CONFIG_PATH",
            "/usr/local/spark/pvc/code/configs/export_tool_config.ini",
        )
        cfg.read(path)
        return cfg

    def _load_query_config(self, json_path: str) -> Dict[str, Any]:
        if not json_path or not os.path.exists(json_path):
            raise ValueError(f"sql_query_path missing or not on disk: {json_path!r}")
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _get_run_report(self, task: Dict) -> FileRunReport:
        rr = task.get("_run_report")
        if isinstance(rr, FileRunReport):
            return rr
        rr = FileRunReport(
            output_dir=task.get("output_dir") or "",
            logger=self.logger,
        )
        rr.set_context(
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
        )
        task["_run_report"] = rr
        return rr

    def _shared_starburst_fallback(self, endpoint: str) -> Dict[str, str]:
        """2026-06-12 — return creds from configs/starburst_config.yaml.

        Mirrors ``StarburstFileBase._shared_starburst_fallback`` so the
        Spark inheritance chain has the same fallback chain.  See that
        method for full rationale.
        """
        try:
            from starburst_config_loader import shared_creds_for
            return shared_creds_for(endpoint)
        except Exception:
            return {"user": "", "password": "", "url": "",
                    "host": "", "port": "443", "catalog": "", "schema": ""}

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """Credentials + JDBC URL for the job's Starburst endpoint.

        Returns a dict with keys: jdbc_url, user, password, fetchsize.
        Subclasses override to pick the right ini section.
        """
        ini = self.ini_config or configparser.ConfigParser()
        section = "Starburst"
        host = job_config["server_name"]
        port = int(job_config["port"])
        user = ini.get(section, "username", fallback="") if ini.has_section(section) else ""
        password = ini.get(section, "password", fallback="") if ini.has_section(section) else ""
        catalog = ini.get(section, "catalog", fallback="") if ini.has_section(section) else ""
        schema = ini.get(section, "schema", fallback="") if ini.has_section(section) else ""
        user = user or job_config.get("trino_user", "")
        password = password or job_config.get("trino_password", "")
        catalog = catalog or job_config.get("catalog", "")
        schema = schema or job_config.get("schema", "")
        # 2026-06-12 — shared configs/starburst_config.yaml fallback.
        # Default base section is "Starburst" (generic); subclasses pass
        # cloud/onprem via their override.  The unqualified path defaults
        # to oncloud for a sane single-endpoint deployment.
        shared = self._shared_starburst_fallback("oncloud")
        user = user or shared["user"]
        password = password or shared["password"]
        catalog = catalog or shared["catalog"]
        schema = schema or shared["schema"]
        if not user or not password:
            raise ValueError(
                f"Spark JDBC: credentials missing for report_id={job_config.get('report_id')} — "
                f"set [{section}] in $EXPORT_TOOL_CONFIG_PATH OR the shared "
                f"configs/starburst_config.yaml + STARBURST_* env vars."
            )
        jdbc_url = f"jdbc:trino://{host}:{port}/{catalog}/{schema}?SSL=true"
        return {
            "jdbc_url": jdbc_url,
            "user": user,
            "password": password,
            "fetchsize": int(job_config.get("fetchsize", self.DEFAULT_FETCHSIZE)),
        }

    def _filter_jobs(self) -> List[Dict[str, Any]]:
        if not self.query_config:
            return []
        jobs = self.query_config.get("jobs", []) or []
        return [j for j in jobs if str(j.get("datasource_name", "")).upper() == self.DATASOURCE_NAME]

    @staticmethod
    def _strip_semicolon(sql: str) -> str:
        return sql.rstrip().rstrip(";").rstrip()

    @staticmethod
    def _safe_partition_label(value: Any) -> str:
        s = str(value) if value is not None else "NULL"
        return re.sub(r"[^A-Za-z0-9_\-]+", "_", s)[:60] or "NULL"

    def _resolve_output_paths(self, job_config: Dict[str, Any]) -> Tuple[str, str, str, str]:
        output_dir = job_config.get("output_file_location") or ""
        if not output_dir:
            raise ValueError(
                f"job {job_config.get('report_id')}: output_file_location is empty"
            )
        os.makedirs(output_dir, exist_ok=True)
        full_name = job_config.get("output_file_name") or f"report_{job_config.get('report_id')}.csv"
        base, ext = (full_name.rsplit(".", 1) if "." in full_name else (full_name, "csv"))
        delimiter = job_config.get("output_file_delimiter", "|")
        return output_dir, base, ext, delimiter

    # ----- Spark session ------------------------------------------------

    def _build_spark_session(self, job_config: Dict[str, Any]):
        """Build a SparkSession.  Lazy import so non-Spark pods can
        still load the step class (resolves cleanly), only failing
        on first ``_execute_step`` call."""
        try:
            from pyspark.sql import SparkSession
        except ImportError as exc:
            raise RuntimeError(
                "PySpark not installed on this pod — cannot run Spark "
                "variant.  Use the non-Spark StarburstToFile_OnCloud / "
                "_OnPrem instead, or deploy on a Spark-enabled pod."
            ) from exc

        executor_memory = job_config.get("spark_executor_memory", self.DEFAULT_EXECUTOR_MEMORY)
        driver_memory = job_config.get("spark_driver_memory", self.DEFAULT_DRIVER_MEMORY)
        num_partitions = int(job_config.get("num_partitions", self.DEFAULT_NUM_PARTITIONS))
        spark_jars = job_config.get("spark_jars") or os.environ.get("SPARK_JARS", "")
        run_id = self.run_report.context.get("run_id") if self.run_report else "unknown"
        report_id = job_config.get("report_id", "unknown")
        app = f"{self.LOG_PREFIX}_{run_id}_{report_id}"
        builder = (
            SparkSession.builder.appName(app)
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
        )
        if spark_jars:
            builder = builder.config("spark.jars", spark_jars)
        return builder.getOrCreate()

    # ----- JDBC reader --------------------------------------------------

    def _tcp_preflight_once(self, conn: Dict[str, Any]) -> None:
        """2026-06-22 -- TCP preflight is OPT-IN (caused production
        outages when probe failed but JDBC could connect).  Skip by
        default; enable via TRINO_JDBC_ENABLE_PREFLIGHT=1 for debugging."""
        if os.environ.get("TRINO_JDBC_ENABLE_PREFLIGHT", "").lower() not in ("1", "true", "yes"):
            return
        if getattr(self, "_preflight_done_for", None) == conn.get("jdbc_url"):
            return
        try:
            from managers.trino_jdbc_preflight import tcp_preflight
            tcp_preflight(conn["jdbc_url"], timeout=5.0, logger=self.logger)
            self._preflight_done_for = conn["jdbc_url"]
        except ImportError:
            pass

    def _read_count(self, spark, conn: Dict[str, Any], sql: str) -> int:
        """Return Trino COUNT(*) over ``sql``.

        2026-06-26 -- defensive extraction matching
        ``starburst_file_base.fetch_scalar`` + Oracle Spark variant
        (``starburst_base.py``).  Tolerates:
          * empty ``collect()`` (Trino returned no result row)
          * column case mismatch (``CNT`` vs ``cnt`` -- Spark+Trino
            JDBC version-dependent)
          * NULL value
        All three map to ``0`` so the caller's downstream logic
        (which expects an int) doesn't blow up on edge cases.
        """
        self._tcp_preflight_once(conn)
        count_query = f"SELECT COUNT(*) AS CNT FROM ({self._strip_semicolon(sql)}) t"
        df = (
            spark.read.format("jdbc")
            .option("url", conn["jdbc_url"])
            .option("dbtable", f"({count_query}) as c")
            .option("user", conn["user"])
            .option("password", conn["password"])
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .load()
        )
        collected = df.collect()
        if not collected:
            self.logger.warning(
                "Trino COUNT(*) returned no result row -- treating as 0."
            )
            return 0
        row_dict = collected[0].asDict()
        cnt_val = row_dict.get("CNT")
        if cnt_val is None:
            cnt_val = row_dict.get("cnt")
        return int(cnt_val) if cnt_val is not None else 0

    def _read_query(self, spark, conn: Dict[str, Any], sql: str, num_partitions: int):
        return (
            spark.read.format("jdbc")
            .option("url", conn["jdbc_url"])
            .option("dbtable", f"({self._strip_semicolon(sql)}) as subq")
            .option("user", conn["user"])
            .option("password", conn["password"])
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .option("fetchsize", str(conn["fetchsize"]))
            .option("numPartitions", str(num_partitions))
            .load()
        )

    def _read_query_with_predicates(
        self, spark, conn: Dict[str, Any], sql: str, predicates: List[str],
    ):
        """JDBC read sharded across `predicates` — each predicate
        becomes a parallel JDBC query.  Lets Spark fan-out exactly
        N concurrent reads matching the N partition values."""
        return (
            spark.read.format("jdbc")
            .option("url", conn["jdbc_url"])
            .option("user", conn["user"])
            .option("password", conn["password"])
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .option("fetchsize", str(conn["fetchsize"]))
            .jdbc(
                url=conn["jdbc_url"],
                table=f"({self._strip_semicolon(sql)}) as subq",
                predicates=predicates,
                properties={
                    "user": conn["user"],
                    "password": conn["password"],
                    "driver": "io.trino.jdbc.TrinoDriver",
                    "fetchsize": str(conn["fetchsize"]),
                },
            )
        )

    # ----- Writer + rename ----------------------------------------------

    def _write_dataframe_as_chunks(
        self, df, chunks_dir: str, delimiter: str,
        num_partitions: int,
    ) -> List[str]:
        """Write DF to ``chunks_dir`` as N CSV files (one per Spark task).

        Spark writes ``part-00000-*.csv`` files; we rename each to
        ``<base>.part_NNNN_spark.<ext>`` shape so ConsolidateFiles
        picks them up.  Returns the list of final chunk file paths.
        """
        # Clean target before write
        if os.path.exists(chunks_dir):
            shutil.rmtree(chunks_dir, ignore_errors=True)
        os.makedirs(chunks_dir, exist_ok=True)

        df = df.repartition(num_partitions)
        (
            df.write
            .option("header", "true")
            .option("delimiter", delimiter)
            .option("quote", '"')
            .option("escape", '"')
            .mode("overwrite")
            .csv(chunks_dir)
        )

        # Spark writes part-NNNNN-<uuid>-c000.csv — rename to our shape
        part_re = re.compile(r"^part-(\d+)-.*\.csv$")
        chunk_paths: List[str] = []
        for name in sorted(os.listdir(chunks_dir)):
            m = part_re.match(name)
            if not m:
                continue
            idx = int(m.group(1))
            target = os.path.join(chunks_dir, f"chunk_{idx:04d}.csv")
            os.replace(os.path.join(chunks_dir, name), target)
            chunk_paths.append(target)
        # Remove Spark _SUCCESS / CRC sidecars
        for name in os.listdir(chunks_dir):
            if name == "_SUCCESS" or name.endswith(".crc"):
                try:
                    os.remove(os.path.join(chunks_dir, name))
                except OSError:
                    pass
        return chunk_paths

    # ----- Per-job execution -------------------------------------------

    def _execute_one_job(
        self, job_config: Dict[str, Any], task: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        report_id = job_config.get("report_id")
        self.logger.info("=" * 72)
        self.logger.info(
            "Spark job start: report_id=%s datasource=%s force_partitioned=%s",
            report_id, self.DATASOURCE_NAME, self.FORCE_PARTITIONED,
        )
        self.logger.info("=" * 72)

        connection = self._build_connection_config(job_config)
        # 2026-06-13 -- Polling-row overlay parity with non-spark base.
        # Operator can drive every per-job knob from the Oracle polling
        # row without editing the per-query JSON.
        from steps.file.starburst_file_base import _overlay_polling_row_onto_job_config
        _overlay_polling_row_onto_job_config(job_config, task, logger=self.logger)
        output_dir, base_filename, ext, delimiter = self._resolve_output_paths(job_config)
        chunks_dir = os.path.join(output_dir, f"{base_filename}.spark_chunks")
        base_sql = job_config["generated_sql"]
        num_partitions = int(job_config.get("num_partitions", self.DEFAULT_NUM_PARTITIONS))

        partition_cfg = job_config.get("partition_config", {}) or {}
        partition_col = partition_cfg.get("partition_column")
        use_partitions = self.FORCE_PARTITIONED or (
            bool(partition_cfg.get("enabled", False)) and bool(partition_col)
        )

        spark = self._build_spark_session(job_config)
        start = time.time()
        try:
            # G1 — source COUNT(*) pre-flight
            self.logger.info("Pre-flight COUNT(*) via JDBC pushdown")
            expected_total = self._read_count(spark, connection, base_sql)
            self.logger.info("  G1 expected_total = %s", expected_total)

            # 2026-06-26 -- 0-row short-circuit.
            # When Trino has 0 rows for this query, skip the entire
            # read+write pipeline.  Reading + writing 0 rows still
            # opens JDBC connections + ships schema-inference queries
            # + creates an empty chunks directory.  All wasted work.
            # ``finally`` block below still fires (Spark stop) so no
            # resource leak.
            if expected_total == 0:
                duration = time.time() - start
                self.logger.info(
                    "Pre-flight COUNT(*) = 0 -- skipping read + write "
                    "phases.  Step succeeds as no-op.  Verify "
                    "polling-row business_date / system_entity / "
                    "eventcode if this is unexpected."
                )
                return {
                    "report_id": report_id,
                    "datasource": self.DATASOURCE_NAME,
                    "status": "success",
                    "records": 0,
                    "expected_total": 0,
                    "sum_partition_expected": 0,
                    "chunks": 0,
                    "scan_mode": "spark_partitioned" if use_partitions else "spark_single",
                    "partition_column": partition_col if use_partitions else None,
                    "chunk_files": [],
                    "output_dir": output_dir,
                    "output_filename": f"{base_filename}.{ext}",
                    "delimiter": delimiter,
                    "control_template": job_config.get("ctl_file_format", ""),
                    "zip_format": job_config.get("zip_format"),
                }

            if use_partitions:
                # Discover predicates from distinct values.
                max_partitions = int(partition_cfg.get("max_partitions", 500))
                self.logger.info(
                    "PARTITION mode (col=%s) — discovering distinct values",
                    partition_col,
                )
                values = self._discover_partition_values(
                    spark, connection, base_sql, partition_col, max_partitions,
                )
                self.logger.info("  %d distinct values discovered", len(values))
                predicates = [self._predicate_for(partition_col, v) for v in values]
                df = self._read_query_with_predicates(spark, connection, base_sql, predicates)
                num_partitions = len(predicates) or num_partitions
            else:
                df = self._read_query(spark, connection, base_sql, num_partitions)

            # Write chunks
            self.logger.info("Writing %d Spark partitions to %s", num_partitions, chunks_dir)
            chunk_paths = self._write_dataframe_as_chunks(
                df, chunks_dir, delimiter, num_partitions,
            )

            # G3 — re-read written files row count vs expected (cheap via DF reload)
            written_count = sum(
                max(0, self._count_lines(p) - 1)  # subtract header
                for p in chunk_paths
            )
            if written_count != expected_total:
                raise ValueError(
                    f"Spark G3 reconcile FAILED: rows written {written_count:,} "
                    f"!= expected_total {expected_total:,} (delta "
                    f"{written_count - expected_total:+,})"
                )

            duration = time.time() - start
            self.logger.info(
                "Spark job OK: report_id=%s rows=%s chunks=%d duration=%.1fs",
                report_id, written_count, len(chunk_paths), duration,
            )

            # Register chunks with the artifact registry
            for p in chunk_paths:
                self.artifacts.add(p, RunArtifacts.CHUNK)
                self.run_report.add_chunk_result({
                    "job_id": str(report_id),
                    # 2026-06-13 -- datasource distinguishes CLOUD vs
                    # ONPREM partitions of the same report_id in the
                    # run report's per-chunk table.
                    "datasource": self.DATASOURCE_NAME,
                    "partition_index": int(re.search(r"chunk_(\d+)", p).group(1)),
                    "partition_value": "",
                    "expected": None,
                    "actual": max(0, self._count_lines(p) - 1),
                    "attempts": 1,
                    "duration_sec": duration / max(1, len(chunk_paths)),
                    "file_path": p,
                })

            return {
                "report_id": report_id,
                "datasource": self.DATASOURCE_NAME,
                "status": "success",
                "records": written_count,
                "expected_total": expected_total,
                "sum_partition_expected": expected_total,
                "chunks": len(chunk_paths),
                "scan_mode": "spark_partitioned" if use_partitions else "spark_single",
                "partition_column": partition_col if use_partitions else None,
                "chunk_files": chunk_paths,
                "output_dir": output_dir,
                "output_filename": f"{base_filename}.{ext}",
                "delimiter": delimiter,
                "control_template": job_config.get("ctl_file_format", ""),
                "zip_format": job_config.get("zip_format"),
            }
        finally:
            try:
                spark.stop()
            except Exception:
                pass

    @staticmethod
    def _predicate_for(column: str, value: Any) -> str:
        if value is None or str(value).upper() == "NULL":
            return f"{column} IS NULL"
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return f"{column} = {value}"
        escaped = str(value).replace("'", "''")
        return f"{column} = '{escaped}'"

    def _discover_partition_values(
        self, spark, conn: Dict[str, Any], base_sql: str,
        partition_col: str, max_partitions: int,
    ) -> List[Any]:
        distinct_sql = (
            f"SELECT DISTINCT {partition_col} AS pv FROM "
            f"({self._strip_semicolon(base_sql)}) t ORDER BY {partition_col}"
        )
        df = (
            spark.read.format("jdbc")
            .option("url", conn["jdbc_url"])
            .option("dbtable", f"({distinct_sql}) as dvq")
            .option("user", conn["user"])
            .option("password", conn["password"])
            .option("driver", "io.trino.jdbc.TrinoDriver")
            .load()
        )
        values = [row["pv"] for row in df.collect()]
        if len(values) > max_partitions:
            raise ValueError(
                f"Partition column {partition_col!r} has {len(values)} distinct values "
                f"which exceeds max_partitions={max_partitions}."
            )
        return values

    @staticmethod
    def _count_lines(path: str) -> int:
        try:
            with open(path, "rb") as f:
                return sum(1 for _ in f)
        except OSError:
            return 0

    # ----- BaseStep contract ------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.ini_config = self._load_ini_config()
        self.query_config = self._load_query_config(task.get("sql_query_path"))
        self.run_report = self._get_run_report(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        # 2026-06-13 -- prior-output handling parity with non-spark base.
        self._backup_ts = task.get("backup_ts") or None
        self._prior_output_mode = task.get("prior_output_mode") or "backup"

        jobs = self._filter_jobs()
        if not jobs:
            self.logger.warning("No %s jobs in query config", self.DATASOURCE_NAME)
            return []

        # 2026-06-12 — set a Spark job group per task so an outer
        # asyncio cancel can stop every JDBC read on the executors via
        # cancelJobGroup.  Set ONCE for the whole step; the group spans
        # every per-job ``_execute_one_job`` call.
        sb_cancellable = None
        sb_group_id = None
        try:
            from pyspark.sql import SparkSession
            spark_session = SparkSession.builder.getOrCreate()
            run_id = task.get("run_id", "x")
            sb_group_id = f"{self.LOG_PREFIX}_{run_id}_{step_name}"
            spark_session.sparkContext.setJobGroup(
                sb_group_id,
                f"Starburst -> File ({self.LOG_PREFIX}) run_id={run_id}",
                interruptOnCancel=True,
            )
            from starburst_cancellation import (
                StarburstCancellable, KIND_SPARK_JOB_GROUP,
                register_starburst_cancellable,
            )
            sb_cancellable = StarburstCancellable(
                KIND_SPARK_JOB_GROUP, spark=spark_session, group_id=sb_group_id,
                label=f"{self.LOG_PREFIX}.spark",
            )
            register_starburst_cancellable(task, sb_cancellable)
        except Exception as exc:
            self.logger.warning(
                "Spark job-group setup failed (cancel will degrade): %s", exc,
            )

        results: List[Dict[str, Any]] = []
        try:
            for job in jobs:
                res = self._execute_one_job(job, task=task)
                results.append(res)
                self.run_report.add_job_result({
                    "report_id": res.get("report_id"),
                    "datasource": res.get("datasource"),
                    "status": res.get("status"),
                    "records": res.get("records", 0),
                    "chunks": res.get("chunks", 0),
                    "file_path": os.path.join(
                        res.get("output_dir", ""),
                        res.get("output_filename", ""),
                    ),
                })
        finally:
            self.run_report.write()
            if sb_cancellable is not None:
                try:
                    from starburst_cancellation import unregister_starburst_cancellable
                    unregister_starburst_cancellable(task, sb_cancellable)
                except Exception:
                    pass

        total_expected = sum(r["expected_total"] for r in results)
        total_actual = sum(r["records"] for r in results)
        self.run_report.set_counts(
            expected_total=total_expected,
            sum_partition_expected=total_expected,
            sum_chunk_actual=total_actual,
        )

        all_chunks: List[str] = []
        for r in results:
            all_chunks.extend(r.get("chunk_files", []))

        # 2026-06-12 — MERGE with any prior step's sidecar state.  See
        # starburst_file_base.py for rationale.  Without this,
        # CLOUD-then-ONPREM (or vice versa) loses the first source's
        # chunk_files + job_results when the second source's
        # save_task_state overwrites the sidecar.
        _existing_state = load_state(
            task.get("sidecar_dir") or task.get("output_dir") or "",
            task.get("run_id"),
            logger=self.logger,
        ) or {}
        prior_chunks = list(_existing_state.get("chunk_files") or [])
        prior_jobs = list(_existing_state.get("job_results") or [])
        _this_keys = {(r.get("report_id"), r.get("datasource")) for r in results}
        prior_jobs = [
            j for j in prior_jobs
            if (j.get("report_id"), j.get("datasource")) not in _this_keys
        ]
        _this_chunks_set = set(all_chunks)
        prior_chunks = [p for p in prior_chunks if p not in _this_chunks_set]

        task["chunk_files"] = prior_chunks + all_chunks
        task["job_results"] = prior_jobs + results
        merged_expected = total_expected + sum(
            int(j.get("expected_total") or 0) for j in prior_jobs
        )
        merged_partition_expected = total_expected + sum(
            int(j.get("sum_partition_expected") or 0) for j in prior_jobs
        )
        merged_actual = total_actual + sum(
            int(j.get("records") or 0) for j in prior_jobs
        )
        task["expected_total"] = merged_expected
        task["sum_partition_expected"] = merged_partition_expected
        task["sum_chunk_actual"] = merged_actual
        task["totalcount"] = merged_actual
        task["artifact_paths"] = self.artifacts.snapshot()

        # Re-publish merged counts to run_report (parity with
        # starburst_file_base.py -- see comment there for rationale).
        if prior_jobs:
            self.run_report.set_counts(
                expected_total=merged_expected,
                sum_partition_expected=merged_partition_expected,
                sum_chunk_actual=merged_actual,
            )

        if results:
            base_dir = results[0].get("output_dir", "")
            if base_dir:
                save_task_state(task, base_dir, task.get("run_id"), logger=self.logger)

        try:
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"),
                task.get("run_detail_id"),
                "UPDATE_TASK_RECORDCOUNT",
                step_name,
                total_actual,
                "",
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.warning("update_otg_etl_batch_status failed: %s", exc)

        return results
