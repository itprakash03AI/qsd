import os
import time
import hashlib
import zipfile
import pandas as pd
from typing import Dict, List, Any, Set, Optional
from core_libs.logger.firelogger import CentralizedLogger
from .BaseStep import BaseStep
import json
import gzip

logger = CentralizedLogger(
    log_file="/usr/local/spark/nfs/bcp/batch/logs/create_control_file_{date_str}.log",
    log_level="INFO",
    backup_count=30,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
).get_logger(__name__)


class CreateControlFile(BaseStep):
    """Step to create control files for individual data files."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.query_config = None
        self.processed_report_ids: Set[str] = set()  # Track processed report IDs

    def _load_query_config(self, file_location):
        """Load query configuration from JSON file"""
        query_config_path = file_location
        with open(query_config_path, "r") as f:
            return json.load(f)

    def _get_control_filename(self, data_filename: str) -> str:
        """Generate control file name from data file name"""
        base_name = os.path.splitext(data_filename)[0]
        return f"{base_name}.ctl"

    def _normalize_filename(self, filename: str) -> str:
        """Remove _CLOUD and _ONPREM from filename"""
        return filename.replace('_CLOUD', '').replace('_ONPREM', '')

    def _find_data_file(self, base_path: str, filename: str) -> str:
        """Find actual data file, checking for variations without _CLOUD/_ONPREM"""
        # First try the exact path
        full_path = os.path.join(base_path, filename)
        if os.path.exists(full_path):
            return full_path

        # Try normalized filename (remove _CLOUD/_ONPREM from filename)
        normalized_filename = self._normalize_filename(filename)
        normalized_path = os.path.join(base_path, normalized_filename)
        if os.path.exists(normalized_path):
            return normalized_path

        # Try searching in the directory for similar files
        if os.path.exists(base_path):
            for file in os.listdir(base_path):
                if self._normalize_filename(file) == normalized_filename:
                    return os.path.join(base_path, file)

        return None

    def _is_report_already_processed(self, report_id: str) -> bool:
        """Check if report ID has already been processed"""
        if report_id in self.processed_report_ids:
            logger.info(f"Report ID {report_id} already processed, skipping duplicate")
            return True
        return False

    def _mark_report_as_processed(self, report_id: str):
        """Mark report ID as processed"""
        self.processed_report_ids.add(report_id)
        logger.debug(f"Marked Report ID {report_id} as processed")

    def _zip_file_and_calculate_metrics(
            self,
            file_path: str,
            zip_format: Any = True  # True|False|'zip'|'gzip' (True == 'zip')
    ) -> Dict[str, Any]:
        """
        Calculate MD5 checksum and total records from the original file, and optionally archive it.

        zip_format:
        - True   -> default to 'zip'
        - 'zip'  -> create <original_name>.zip (ZIP_DEFLATED)
        - 'gzip' -> create <original_name>.gz (GZIP)
        - False  -> no archive

        Steps:
            1) Validate file existence.
            2) Calculate MD5 of the original file (chunked).
            3) Count total records (number of lines excluding the first header line, if any).
            4) If archiving is enabled per `zip_format`:
                - Create the archive in the same directory
                  * zip:  write file into a .zip
                  * gzip: write raw bytes to .gz (single-file stream)
                - Calculate SHA-256 of the archive (FIPS-compliant)
                - Delete the original file after successful archive creation

        Returns:
            {
                'original_file_path': <str>,
                'total_records': <int>,
                'file_md5_checksum': <str>,        # MD5 of original file (always present)
                'archive_format': <'zip'|'gzip'|None>,
                'archive_path': <str or None>,
                'archive_sha256_checksum': <str or None>
            }
        """
        try:
            # --- Normalize zip_format argument ---
            if isinstance(zip_format, bool):
                archive_format: Optional[str] = 'zip' if zip_format else None
            elif isinstance(zip_format, str):
                zf = zip_format.strip().lower()
                if zf in ('zip', 'gzip'):
                    archive_format = zf
                elif zf in ('true', 'yes', '1'):
                    archive_format = 'zip'
                elif zf in ('false', 'no', '0', ''):
                    archive_format = None
                else:
                    raise ValueError(
                        f"Invalid zip_format value: {zip_format}. "
                        f"Allowed: True, False, 'zip', 'gzip'."
                    )
            else:
                raise ValueError(
                    f"Invalid zip_format type: {type(zip_format).__name__}. "
                    f"Allowed: bool or str ('zip'|'gzip')."
                )

            # --- 1) Validate file existence ---
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")

            # --- Helper: chunked hashing ---
            def _hash_file(path: str, algo: str = 'md5', chunk_size: int = 1024 * 1024) -> str:
                h = hashlib.new(algo)
                with open(path, 'rb') as fh:
                    for chunk in iter(lambda: fh.read(chunk_size), b""):
                        h.update(chunk)
                return h.hexdigest()

            # # --- 2) MD5 of the ORIGINAL file ---
            # md5_checksum = _hash_file(file_path, 'md5')
            # logger.info(f"Calculated MD5 for original file: {file_path} -> {md5_checksum}")

            # --- 3) Total records (exclude header) ---
            # If encoding variance is possible, you could parametrize encoding/errors.
            with open(file_path, 'r', encoding='utf-8', errors='replace') as fh:
                total_records = sum(1 for _ in fh)
            if total_records > 0:
                total_records -= 1
            logger.info(f"Total records (excluding header) for {file_path}: {total_records}")

            archive_path = None
            # archive_sha256_checksum = None

            # --- 4) Optional archiving ---
            if archive_format == 'zip':
                archive_path = f"{os.path.splitext(file_path)[0]}.zip"
                # Create ZIP and store the file within it
                with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    zipf.write(file_path, arcname=os.path.basename(file_path))
                logger.info(f"File zipped successfully: {archive_path}")
                try:
                    os.remove(file_path)
                    logger.info(f"Original data file deleted: {file_path}")
                except Exception as delete_error:
                    logger.warning(f"Failed to delete original data file {file_path}: {delete_error}")

            elif archive_format == 'gzip':
                archive_path = f"{file_path}.gz" if not file_path.lower().endswith('.gz') \
                    else file_path  # safety; but normally we append .gz
                if archive_path == file_path:
                    # If input already ends with .gz, create a parallel <base>.gz2 to avoid overwrite
                    base, ext = os.path.splitext(file_path)
                    archive_path = f"{base}.gzip"

                # Create GZIP (single stream of the file bytes)
                with open(file_path, 'rb') as src, gzip.open(archive_path, 'wb') as dst:
                    for chunk in iter(lambda: src.read(1024 * 1024), b""):
                        dst.write(chunk)
                logger.info(f"File gzipped successfully: {archive_path}")

                # # SHA-256 of the archive
                # archive_sha256_checksum = _hash_file(archive_path, 'md5')
                # logger.info(f"SHA-256 for archive: {archive_path} -> {archive_sha256_checksum}")

                # Delete original
                try:
                    os.remove(file_path)
                    logger.info(f"Original data file deleted: {file_path}")
                except Exception as delete_error:
                    logger.warning(f"Failed to delete original data file {file_path}: {delete_error}")

            else:
                logger.info("Archiving skipped (zip_format=False or equivalent).")

            return {
                'original_file_path': file_path,
                'total_records': total_records,
                # 'file_md5_checksum': md5_checksum,
                'zip_file_path': archive_path,
                # 'zip_sha256_checksum': archive_sha256_checksum
            }

        except Exception as e:
            logger.error(
                f"Error processing file for metrics (file={file_path}, zip_format={zip_format}): {e}"
            )
            raise

    def _process_control_template(self, template: str, total_records: int,
                                   file_path: str, zip_file_path: str) -> str:
        """Process control file template with actual values"""
        try:
            processed_template = template

            # Replace placeholders with actual values
            replacements = {
                '{total_records}': str(total_records),
                # '{sha256_checksum}': sha256_checksum,
                '{md5_checksum}': '{md5_checksum}',  # Backward compatibility
                '{file_name}': os.path.basename(zip_file_path),
                '{file_path}': zip_file_path,
                '{timestamp}': time.strftime("%Y-%m-%d %H:%M:%S"),
                '{date}': time.strftime("%Y-%m-%d"),
                '{year}': time.strftime("%Y"),
                '{month}': time.strftime("%m"),
                '{day}': time.strftime("%d")
            }

            for placeholder, value in replacements.items():
                if placeholder in processed_template:
                    processed_template = processed_template.replace(placeholder, value)
                    logger.debug(f"Replaced {placeholder} with {value}")

            # Clean up _CLOUD and _ONPREM references in template
            processed_template = processed_template.replace('_CLOUD.', '.').replace('_ONPREM.', '.')

            return processed_template

        except Exception as e:
            logger.error(f"Error processing control template: {e}")
            raise

    def _zip_control_file(self, control_file_path: str) -> str:
        """Zip the control file"""
        try:
            if not os.path.exists(control_file_path):
                raise FileNotFoundError(f"Control file not found: {control_file_path}")

            # Create zip file path for control file
            control_zip_path = f"{os.path.splitext(control_file_path)[0]}_ctl.zip"

            # Zip the control file
            with zipfile.ZipFile(control_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(control_file_path, os.path.basename(control_file_path))

            logger.info(f"Control file zipped successfully: {control_zip_path}")

            # Delete the original control file after successful zipping
            try:
                os.remove(control_file_path)
                logger.info(f"Original control file deleted: {control_file_path}")
            except Exception as delete_error:
                logger.warning(f"Failed to delete original control file {control_file_path}: {delete_error}")

            return control_zip_path

        except Exception as e:
            logger.error(f"Error zipping control file {control_file_path}: {e}")
            raise

    def _create_control_file(self, file_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create control file for a single data file"""
        try:
            job_id = file_info['job_id']
            zip_format = file_info['zip_format']
            report_id = str(file_info.get('report_id', job_id))  # Use job_id as fallback if report_id not available

            logger.info(f"Creating control file for Job ID {job_id}, Report ID {report_id}")

            # Check if this report ID has already been processed
            if self._is_report_already_processed(report_id):
                return {
                    'job_id': job_id,
                    'report_id': report_id,
                    'status': 'skipped',
                    'message': f'Report ID {report_id} already processed'
                }

            # Mark report as being processed
            self._mark_report_as_processed(report_id)

            # Validate required fields
            if file_info.get('status') != 'success':
                logger.error(f"Cannot create control file for failed job: Job ID {job_id}, Report ID {report_id}")
                return {
                    'job_id': job_id,
                    'report_id': report_id,
                    'status': 'failed',
                    'error': 'Job failed, cannot create control file'
                }

            # Get file information
            file_path = file_info.get('file_path')
            filename = file_info.get('filename')

            if not file_path or not filename:
                logger.error(f"Missing file path or filename for Job ID {job_id}, Report ID {report_id}")
                return {
                    'job_id': job_id,
                    'report_id': report_id,
                    'status': 'failed',
                    'error': 'Missing file path or filename'
                }

            # Find the actual data file (should be the merged file)
            actual_file_path = self._find_data_file(file_path, filename)
            if not actual_file_path:
                logger.error(
                    f"Data file not found for Job ID {job_id}, Report ID {report_id}: {os.path.join(file_path, filename)}")
                return {
                    'job_id': job_id,
                    'report_id': report_id,
                    'status': 'failed',
                    'error': f'Data file not found: {os.path.join(file_path, filename)}'
                }

            # Zip data file and calculate metrics
            file_metrics = self._zip_file_and_calculate_metrics(actual_file_path, zip_format)

            total_records = file_metrics['total_records']

            def _normalize_zip_format(zip_format) -> bool:
                """Return True if archiving is requested (zip or gzip), else False."""
                if isinstance(zip_format, bool):
                    return zip_format  # True -> archive, False -> no archive
                if isinstance(zip_format, str):
                    zf = zip_format.strip().lower()
                    if zf in ('zip', 'gzip', 'true', 'yes', '1'):
                        return True
                    if zf in ('false', 'no', '0', ''):
                        return False
                # Unknown input -> treat as no archive (or raise if you prefer strictness)
                return False

            if _normalize_zip_format(zip_format):
                # sha256_checksum = file_metrics['zip_sha256_checksum']
                final_file_path = file_metrics['zip_file_path']
            else:
                # sha256_checksum = file_metrics['file_md5_checksum']
                final_file_path = file_metrics['original_file_path']

            # Get control template
            control_template = file_info.get('control_template', '')
            if not control_template:
                logger.warning(f"No control template found for Job ID {job_id}, Report ID {report_id}, using default")
                control_template = "File_Name,{file_name}\nExtract_Date,{date}\nBusiness_Close_Date,{date}\nNumber_Of_Records,{total_records}\nMD5,{md5_checksum}"

            # Generate control file path (same directory as zip file)
            zip_filename = os.path.basename(final_file_path)
            control_filename = self._get_control_filename(zip_filename)
            control_file_path = os.path.join(os.path.dirname(final_file_path), control_filename)

            # Process template with actual values
            processed_content = self._process_control_template(
                control_template,
                total_records,
                actual_file_path,
                final_file_path
            )

            # Write control file
            start_time = time.time()
            with open(control_file_path, "w", encoding='utf-8') as f:
                f.write(processed_content)
                if not processed_content.endswith('\n'):
                    f.write('\n')  # Ensure file ends with newline

            # Zip the control file
            if _normalize_zip_format(zip_format):
                control_zip_path = self._zip_control_file(control_file_path)
            else:
                control_zip_path = control_file_path

            end_time = time.time()

            logger.info(
                f"Control file created and zipped for Job ID {job_id}, Report ID {report_id}: {control_file_path} | "
                f"Records: {total_records} | Time: {end_time - start_time:.3f}s"
            )

            return {
                'job_id': job_id,
                'report_id': report_id,
                'control_file_path': control_file_path,
                'control_zip_path': control_zip_path,
                'data_file_path': actual_file_path,
                'data_zip_path': final_file_path,
                'total_records': total_records,
                'status': 'success'
            }

        except Exception as e:
            logger.error(
                f"Error creating control file for Job ID {file_info.get('job_id', 'Unknown')}, "
                f"Report ID {file_info.get('report_id', 'Unknown')}: {e}"
            )
            return {
                'job_id': file_info.get('job_id', 'Unknown'),
                'report_id': file_info.get('report_id', 'Unknown'),
                'status': 'failed',
                'error': str(e)
            }

    def _validate_control_file(self, control_file_path: str) -> bool:
        """Validate that control file was created successfully"""
        try:
            if not os.path.exists(control_file_path):
                logger.error(f"Control file does not exist: {control_file_path}")
                return False

            # Check if file has content
            file_size = os.path.getsize(control_file_path)
            if file_size == 0:
                logger.error(f"Control file is empty: {control_file_path}")
                return False

            # Try to read the file to ensure it's not corrupted
            with open(control_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip():
                    logger.error(f"Control file has no content: {control_file_path}")
                    return False

            logger.debug(f"Control file validation passed: {control_file_path}")
            return True

        except Exception as e:
            logger.error(f"Error validating control file {control_file_path}: {e}")
            return False

    def get_output_files_info(self):
        """Get detailed output file information from query config"""
        output_files = []

        if 'jobs' in self.query_config:
            for job in self.query_config['jobs']:
                file_info = {
                    'filename': job.get('output_file_name'),
                    'file_type': job.get('output_file_type'),
                    'delimiter': job.get('output_file_delimiter'),
                    'file_path': job.get('output_file_location'),
                    'datasource': job.get('datasource_name'),
                    'job_id': job.get('job_id'),
                    'report_id': job.get('report_id', job.get('job_id')),  # Use job_id as fallback
                    'control_template': job.get('ctl_file_format'),
                    'zip_format': job.get('zip_format'),
                    'status': 'success'
                }
                output_files.append(file_info)

        return output_files

    def reset_processed_reports(self):
        """Reset the processed report IDs set - useful for testing or reprocessing"""
        self.processed_report_ids.clear()
        logger.info("Reset processed report IDs tracking")

    async def upsert_otg_log_file_table(self, file_name: str, report_id: int, worker_connection_string: str) -> Dict:
        """Log file information to database using stored procedure"""
        try:
            from datetime import datetime

            # Use NONE for first time inserting, hardcoded to datetime.now() for now
            parameters = [
                {'name': 'p_file_name', 'value': file_name, 'direction': 'IN'},
                {'name': 'p_report_id', 'value': report_id, 'direction': 'IN'},
                {'name': 'p_extract_start_date', 'value': datetime.now(), 'direction': 'IN'},
                {'name': 'p_extract_end_date', 'value': datetime.now(), 'direction': 'IN'}
            ]

            result = await self.oracle_data_manager.execute_procedure_async(
                procedure_name='FIRE_DEV.OTG_UPSERT_FILE_LOG_TABLE',
                parameters=parameters,
                connection_string=worker_connection_string
            )

            logger.info(f"File log inserted/updated for {file_name}")
            return result

        except Exception as e:
            logger.error(f"Error inserting/updating records to OTG_FILE_LOG table: {e}")
            # Don't raise - log the error but continue processing
            return {'status': 'failed', 'error': str(e)}

    async def _execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str,
                             step_name: str, *args, **kwargs) -> List[Dict[str, Any]]:
        """Execute control file creation step."""
        logger.info("Starting CreateControlFile step execution")

        try:
            sql_file_location = task["sql_query_path"]
            self.query_config = self._load_query_config(sql_file_location)

            # Get all file information
            all_files = self.get_output_files_info()

            if not all_files:
                logger.warning("No files found to process")
                return []

            # Log unique report IDs for tracking
            unique_report_ids = set(str(file_info.get('report_id', file_info.get('job_id'))) for file_info in all_files)
            logger.info(f"Found {len(unique_report_ids)} unique report IDs to process: {sorted(unique_report_ids)}")

            control_file_results = []

            for file_info in all_files:
                job_id = file_info.get('job_id')
                report_id = str(file_info.get('report_id', job_id))
                logger.info(f"Processing Job ID {job_id}, Report ID {report_id}")
                logger.info(f"Incoming file type: {file_info.get('file_type')}")
                # Create control file for this individual file
                result = self._create_control_file(file_info)

                if result.get('status') == 'success':
                    control_zip_path = result.get('control_zip_path')
                    if control_zip_path and os.path.exists(control_zip_path):
                        result['validation_passed'] = True
                        logger.info(
                            f"Control file validation passed for Job ID {result['job_id']}, Report ID {result['report_id']}")
                        # Insert into OTG_FILE_LOG Table
                        normalized_filename = self._normalize_filename(file_info.get('filename'))
                        await self.upsert_otg_log_file_table(normalized_filename, int(file_info.get('report_id')), worker_connection_string)
                        # SSH
                        # self.trigger_ssh_script()
                    else:
                        result['validation_passed'] = False
                        result['status'] = 'failed'
                        result['error'] = 'Control file zip validation failed'
                        logger.error(
                            f"Control file zip validation failed for Job ID {result['job_id']}, Report ID {result['report_id']}")
                elif result.get('status') == 'skipped':
                    result['validation_passed'] = None  # Not applicable for skipped files

                control_file_results.append(result)

            # Log summary
            successful_control_files = [r for r in control_file_results if r.get('status') == 'success']
            failed_control_files = [r for r in control_file_results if r.get('status') == 'failed']
            skipped_control_files = [r for r in control_file_results if r.get('status') == 'skipped']

            logger.info(
                f"Control file creation completed: {len(successful_control_files)} successful, "
                f"{len(failed_control_files)} failed, {len(skipped_control_files)} skipped "
                f"out of {len(control_file_results)} total jobs"
            )

            # Log details of created files
            for result in successful_control_files:
                logger.info(
                    f"Created: {result['control_file_path']} (zipped: {result['control_zip_path']}) "
                    f"for Job ID {result['job_id']}, Report ID {result['report_id']} "
                    f"{result['total_records']} records, Data ZIP: {result.get('data_zip_path', 'N/A')}"
                )

            # Log skipped files
            for result in skipped_control_files:
                logger.info(f"Skipped duplicate Report ID {result['report_id']} for Job ID {result['job_id']}")

            # Log failed files
            for result in failed_control_files:
                logger.error(
                    f"Failed Report ID {result['report_id']} for Job ID {result['job_id']}: {result.get('error', 'Unknown error')}")

            return control_file_results

        except Exception as e:
            logger.error(f"Error in CreateControlFile execution: {e}")
            raise