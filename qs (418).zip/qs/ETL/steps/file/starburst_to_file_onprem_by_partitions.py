"""StarburstToFile_OnPrem_ByPartitions — forced PARTITION_VALUES variant.

Identical to ``StarburstToFile_OnPrem`` EXCEPT ``FORCE_MODE`` pins
the ScanPlan to PARTITION_VALUES regardless of the per-job
``partition_config.enabled`` flag.

The 120-million-row escape hatch for the on-prem catalog: use this
when the operator KNOWS the SINGLE-mode plan would OOM Trino and
wants to guarantee partition fan-out without editing the JSON
config.  All other on-prem-credential routing + DATASOURCE filtering
is inherited unchanged from the parent.
"""
from __future__ import annotations

from steps.file.starburst_file_base import ScanMode
from steps.file.starburst_to_file_onprem import StarburstToFile_OnPrem


class StarburstToFile_OnPrem_ByPartitions(StarburstToFile_OnPrem):
    """Force PARTITION_VALUES mode against the ONPREM datasource."""

    LOG_PREFIX = "starburst_to_file_onprem_by_partitions"
    FORCE_MODE = ScanMode.PARTITION_VALUES
