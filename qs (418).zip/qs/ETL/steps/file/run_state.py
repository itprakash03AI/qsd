"""File-flow run-state sidecar + RunArtifacts registry.

TWO co-located primitives the file flow needs and that don't belong
inside any one step class:

  1. ``save_state`` / ``load_state``
       Cross-step state handoff.  Each polling row in the file workflow
       is dispatched to its OWN step class with its OWN task dict —
       state stashed on ``task['chunk_files']`` by
       StarburstToFile_OnCloud is INVISIBLE to ConsolidateFiles unless
       it lives on disk.  Sidecar JSON keyed by run_id bridges the gap.

  2. ``RunArtifacts``
       Append-only registry of every file written during the run
       (chunk files, consolidated file, compressed file, ctl file,
       report files).  On ANY failure we walk the registry and delete
       everything so we never leave half-completed deliverables behind.

       The user's #2 requirement (catch starburst failures and delete
       all chunks) is owned by this class.  Every step appends to it;
       the standalone calls ``cleanup_on_failure()`` in its except
       branch.

Atomic write (``.tmp`` + ``os.replace``) so a crash mid-write leaves
the OLD state intact.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time as _time_mod
from datetime import datetime as _datetime
from typing import Any, Dict, List, Optional


# ── Windows file-name tunneling defeat ────────────────────────────────────


def force_creation_time_now(path: str, logger: Optional[Any] = None) -> bool:
    """Set ``path``'s creation time to NOW.

    Windows-specific fix for NTFS **file-name tunneling** (TPSN): when a
    file is deleted/renamed and another created with the same name
    within ~15 seconds, the new file silently INHERITS the old file's
    creation timestamp.  Net effect: a daily extract that publishes the
    same filename shows "created yesterday, modified today" -- backup
    folders + os.replace don't fix it because tunneling is name-keyed,
    not inode-keyed.

    The only reliable defeat is to explicitly call SetFileTime after
    the new file lands, overriding whatever ctime the OS inherited.

    POSIX has no equivalent settable ctime AND no equivalent tunneling
    behaviour -- this is a Windows-only correction.  Returns True on
    POSIX as a no-op (no-fix-needed signal), True/False on Windows
    indicating whether SetFileTime succeeded.  Best-effort: any error
    logs WARN and returns False; the caller's atomic publish is still
    correct, only the creation-time stamp is wrong.
    """
    if os.name != "nt":
        return True  # POSIX -- ctime isn't user-settable AND tunneling doesn't apply.
    try:
        import ctypes
        from ctypes import wintypes
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

        GENERIC_WRITE = 0x40000000
        FILE_SHARE_READ = 0x00000001
        FILE_SHARE_WRITE = 0x00000002
        FILE_SHARE_DELETE = 0x00000004
        OPEN_EXISTING = 3
        FILE_ATTRIBUTE_NORMAL = 0x80
        FILE_FLAG_BACKUP_SEMANTICS = 0x02000000  # needed for SetFileTime in some cases
        INVALID_HANDLE_VALUE = -1

        CreateFileW = kernel32.CreateFileW
        CreateFileW.argtypes = [
            wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
            ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
            wintypes.HANDLE,
        ]
        CreateFileW.restype = wintypes.HANDLE

        SetFileTime = kernel32.SetFileTime
        SetFileTime.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(wintypes.FILETIME),
            ctypes.POINTER(wintypes.FILETIME),
            ctypes.POINTER(wintypes.FILETIME),
        ]
        SetFileTime.restype = wintypes.BOOL

        CloseHandle = kernel32.CloseHandle
        CloseHandle.argtypes = [wintypes.HANDLE]
        CloseHandle.restype = wintypes.BOOL

        share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE
        handle = CreateFileW(
            path, GENERIC_WRITE, share_mode, None,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_BACKUP_SEMANTICS,
            None,
        )
        if not handle or handle == INVALID_HANDLE_VALUE:
            err = ctypes.get_last_error()
            if logger:
                logger.warning(
                    "force_creation_time_now: CreateFileW(%s) failed err=%s "
                    "(ctime not corrected; published file still valid)",
                    path, err,
                )
            return False
        try:
            # FILETIME = 100-ns intervals since 1601-01-01 UTC.
            # time.time() = seconds since 1970-01-01 UTC.
            # Offset between epochs: 11644473600 seconds.
            now_unix = _time_mod.time()
            ft_value = int((now_unix + 11644473600.0) * 10_000_000)
            ft = wintypes.FILETIME(
                dwLowDateTime=ft_value & 0xFFFFFFFF,
                dwHighDateTime=(ft_value >> 32) & 0xFFFFFFFF,
            )
            # SetFileTime(handle, lpCreationTime, lpLastAccessTime,
            #              lpLastWriteTime).  Pass NULL for the two
            #              times we don't want to touch.
            ok = SetFileTime(handle, ctypes.byref(ft), None, None)
            if not ok:
                err = ctypes.get_last_error()
                if logger:
                    logger.warning(
                        "force_creation_time_now: SetFileTime(%s) failed err=%s",
                        path, err,
                    )
                return False
            return True
        finally:
            CloseHandle(handle)
    except Exception as exc:
        if logger:
            logger.warning(
                "force_creation_time_now(%s) raised (non-fatal -- file "
                "still valid, only ctime stamp wrong): %s",
                path, exc,
            )
        return False


# ──────────────────────────────────────────────────────────────────────
#  Sidecar JSON (cross-step state)
# ──────────────────────────────────────────────────────────────────────

# Keys downstream file-flow steps need lifted from the sidecar.
# Extending this list when a new shared field appears is the SINGLE
# point of maintenance for cross-step state.
_SIDECAR_KEYS = (
    "run_subdir",
    "output_dir",
    "chunk_files",          # list of per-partition chunk files written
    "consolidated_file",
    "compressed_file",
    "ctl_file",
    "expected_total",       # G1 source COUNT(*)
    "sum_partition_expected",  # G2
    "sum_chunk_actual",     # G3
    "consolidated_total",   # G5
    "totalcount",           # backward-compat alias
    "job_results",          # list of per-report job summaries
    "chunk_results",        # list of per-chunk reconcile records
    "artifact_paths",       # RunArtifacts.snapshot() for cleanup
    # 2026-06-12 — per-step result lists must round-trip too.
    # CompressFile + CreateControlFile both fall back to the singleton
    # if their result list is empty, but the list also carries
    # per-file checksums (md5_checksum / sha256_checksum) that the
    # CTL render needs.  Without these in the sidecar the CTL had
    # blank hash cells when the chain ran across separate task dicts.
    "consolidation_results",
    "compress_results",
    "md5_checksum",
    "sha256_checksum",
    # 2026-06-18 -- staging dir from the current step.  Carried so a
    # resumer / cross-step coordinator can locate the per-extract
    # scratch space (preserved on failure when preserve_chunks_on_failure
    # is TRUE).  Optional; absent on legacy steps.
    "_staging_dir",
)


def state_path(base_output_dir: str, run_id: Any) -> str:
    """Path of the sidecar state file for a given run_id.

    ``run_id`` is coerced to str so an Oracle NUMBER doesn't produce a
    weird ``_file_state_42.0.json`` filename.
    """
    safe_run = str(run_id).strip().replace(os.sep, "_").replace("/", "_")
    return os.path.join(base_output_dir, f"_file_state_{safe_run}.json")


def save_state(
    state: Dict[str, Any],
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> Optional[str]:
    """Atomically persist ``state`` to the sidecar.

    Returns the file path on success or None on failure (never raises
    — the sidecar is a debugging / handoff aid, not critical path).
    """
    if run_id is None:
        if logger:
            logger.warning("save_state: run_id is None — skipping sidecar persist")
        return None
    try:
        os.makedirs(base_output_dir, exist_ok=True)
    except OSError as exc:
        if logger:
            logger.warning("save_state: could not create %s: %s", base_output_dir, exc)
        return None

    target = state_path(base_output_dir, run_id)
    tmp = target + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, default=str)
            try:
                f.flush()
                os.fsync(f.fileno())
            except (AttributeError, OSError):
                pass
        os.replace(tmp, target)
        if logger:
            logger.info(
                "Persisted file-run sidecar to %s (chunk_files=%d, totalcount=%s)",
                target,
                len(state.get("chunk_files", []) or []),
                state.get("totalcount") or state.get("expected_total"),
            )
        return target
    except OSError as exc:
        if logger:
            logger.warning("save_state: write to %s failed: %s", target, exc)
        try:
            os.remove(tmp)
        except OSError:
            pass
        return None


def load_state(
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> Optional[Dict[str, Any]]:
    """Load the sidecar; return None on missing / corrupt."""
    if run_id is None or not base_output_dir:
        return None
    path = state_path(base_output_dir, run_id)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return data
    except (json.JSONDecodeError, OSError) as exc:
        if logger:
            logger.warning(
                "load_state: %s unreadable (%s) — treating as missing", path, exc,
            )
        return None


def delete_sidecar(
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> bool:
    """Delete the sidecar at ``<base_output_dir>/_file_state_<run_id>.json``.

    Returns True if a file was removed.  Best-effort -- a missing
    sidecar OR an OS error is logged at INFO/WARN but never raised
    (deletion is hygiene, not critical path).

    Called from the standalones' SUCCESS branch -- the sidecar is a
    handoff aid between steps; once the run is complete it's just
    clutter on NFS, AND if a future re-run with the same run_id
    starts, a leftover sidecar would seed it with stale state.

    On FAILURE the sidecar is intentionally NOT deleted -- the
    standalone's except branch leaves it for forensics so the
    operator can inspect what ran and what didn't.
    """
    if run_id is None or not base_output_dir:
        return False
    path = state_path(base_output_dir, run_id)
    if not os.path.exists(path):
        if logger:
            logger.debug(
                "delete_sidecar: no sidecar at %s -- nothing to do", path,
            )
        return False
    try:
        os.remove(path)
        if logger:
            logger.info("delete_sidecar: removed %s", path)
        return True
    except OSError as exc:
        if logger:
            logger.warning(
                "delete_sidecar: could not remove %s (%s)", path, exc,
            )
        return False


def backup_stale_sidecar(
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> Optional[str]:
    """Atomically rename any existing sidecar to a ``.bak_<ts>`` sibling.

    Called from the standalones at run START so a fresh run begins with
    a clean slate -- a sidecar left over from a prior FAILED run with
    the same run_id would otherwise seed the new run with stale
    references to files that ``cleanup_on_failure`` already removed.

    The prior state is preserved as a backup for forensics, NOT deleted.
    Returns the backup path on success, ``None`` when nothing needed
    backing up.

    Idempotent: a second call on the same run_id (after the first
    backup completed) is a no-op.
    """
    if run_id is None or not base_output_dir:
        return None
    path = state_path(base_output_dir, run_id)
    if not os.path.exists(path):
        return None
    ts = _datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{path}.bak_{ts}"
    # In the (extremely unlikely) sub-second collision case, append a
    # counter so we never overwrite a prior backup.
    counter = 0
    final_backup = backup
    while os.path.exists(final_backup):
        counter += 1
        final_backup = f"{backup}.{counter}"
    try:
        os.replace(path, final_backup)
        if logger:
            logger.info(
                "backup_stale_sidecar: pre-existing sidecar at %s renamed to %s",
                path, final_backup,
            )
        return final_backup
    except OSError as exc:
        if logger:
            logger.warning(
                "backup_stale_sidecar: could not back up %s (%s) -- "
                "leaving in place; downstream hydrate may see stale state",
                path, exc,
            )
        return None


def check_disk_space(
    output_dir: str,
    expected_rows: int,
    avg_row_bytes: int = 200,
    safety_factor: float = 4.0,
    label: str = "",
    logger=None,
) -> Optional[Dict[str, int]]:
    """Pre-flight disk-space check for the file workflow.

    Operator's 170M concern: silent disk-fill at hour 5 of an 8-hour
    extract is the worst-case failure (the extract halts mid-write,
    cleanup_on_failure wipes the chunks already on disk, and the
    operator finds out only via the run report).  This guard fires
    BEFORE any extract starts so the failure is upfront and obvious.

    Calculation:
      need = expected_rows * avg_row_bytes * safety_factor
    The factor accounts for:
      1x -- per-source chunk files
      1x -- per-source self-consolidated .dat
      1x -- cross-source merged .dat
      1x -- headroom (compress / Spark spill / OS reserve)
    Default ``avg_row_bytes=200``: a reasonable middle for typical
    fact-table rows.  Bump to 500-1000 for very wide tables in the
    polling row / yaml.

    Returns:
      None when the check PASSES (enough free space).
      A dict ``{"free": ..., "need": ..., "shortage": ...}`` when the
      check FAILS -- caller decides whether to raise or log+continue.

    Best-effort: if ``shutil.disk_usage`` fails (unusual on some NFS
    mounts or UNC paths), the helper logs a WARN and returns None
    rather than blocking the run on a false negative.
    """
    if not output_dir or expected_rows is None or expected_rows <= 0:
        return None
    import shutil
    try:
        usage = shutil.disk_usage(output_dir)
        free = int(usage.free)
    except (OSError, ValueError) as exc:
        if logger:
            logger.warning(
                "check_disk_space: could not measure %s (%s) -- "
                "skipping pre-flight check%s",
                output_dir, exc, f" [{label}]" if label else "",
            )
        return None
    need = int(expected_rows * max(1, int(avg_row_bytes)) * max(1.0, float(safety_factor)))
    if free >= need:
        if logger:
            logger.info(
                "Disk-space pre-flight OK%s: %d GB free, need ~%d GB "
                "(%d rows * %d B * %.1fx safety)",
                f" [{label}]" if label else "",
                free // (1024 ** 3), need // (1024 ** 3),
                expected_rows, avg_row_bytes, safety_factor,
            )
        return None
    return {
        "free": free,
        "need": need,
        "shortage": need - free,
    }


def backup_if_exists(
    path: str,
    backup_dir: Optional[str] = None,
    backup_ts: Optional[str] = None,
    mode: str = "backup",
    logger=None,
) -> Optional[str]:
    """Handle a prior-run file at ``path`` before this run overwrites it.

    Operator asked (2026-06-13): "when we rerun, if previous run's file
    available then rename and move in backup folder ... keep 1 flag in
    config to backup or delete."

    Behaviour switches on ``mode`` (default "backup"):

      * ``"backup"``  -- move to ``<dirname(path)>/backup_<ts>/`` sibling
                         folder.  Prior run preserved for forensics.
                         Same-filesystem rename = atomic.
      * ``"delete"``  -- just ``os.remove(path)``.  Prior run is GONE.
                         For operators who don't want NFS bloat from a
                         backup folder accumulating over time.
      * Any other value falls back to ``"backup"``.

    Resolution order for the backup folder (mode="backup" only):
      1. ``backup_dir`` argument wins when explicitly provided.
      2. ``backup_ts`` produces ``<dirname(path)>/backup_<ts>/``.
      3. Default: ``<dirname(path)>/backup_<YYYYMMDD_HHMMSS>/``.

    Best-effort: missing source returns None silently; OS errors are
    logged at WARN but never raised (the run continues; the new write
    will then clobber the prior file).

    Returns the backup path on a successful backup, ``None`` for
    delete-mode OR when nothing was moved.
    """
    if not path or not os.path.exists(path):
        return None

    # DELETE mode -- straight os.remove, no backup folder, no rename.
    if str(mode or "backup").strip().lower() == "delete":
        try:
            os.remove(path)
            if logger:
                logger.info(
                    "backup_if_exists(mode=delete): removed prior-run file %s",
                    path,
                )
        except OSError as exc:
            if logger:
                logger.warning(
                    "backup_if_exists(mode=delete): could not remove %s (%s) "
                    "-- the new run will overwrite it instead", path, exc,
                )
        return None

    # BACKUP mode (default) -- move to <dirname>/backup_<ts>/.
    import shutil
    src_dir = os.path.dirname(path) or "."
    src_name = os.path.basename(path)
    if not backup_dir:
        ts = backup_ts or _datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(src_dir, f"backup_{ts}")
    try:
        os.makedirs(backup_dir, exist_ok=True)
    except OSError as exc:
        if logger:
            logger.warning(
                "backup_if_exists: could not create %s (%s) -- "
                "skipping backup, original will be overwritten",
                backup_dir, exc,
            )
        return None
    target = os.path.join(backup_dir, src_name)
    # If a backup with the same name already exists in this folder
    # (rare -- same-second retry from another caller), append a counter.
    counter = 0
    final_target = target
    while os.path.exists(final_target):
        counter += 1
        final_target = f"{target}.{counter}"
    try:
        shutil.move(path, final_target)
        if logger:
            logger.info(
                "backup_if_exists: moved prior-run file %s -> %s",
                path, final_target,
            )
        return final_target
    except OSError as exc:
        if logger:
            logger.warning(
                "backup_if_exists: could not move %s -> %s (%s) -- "
                "the new run will overwrite the prior file",
                path, final_target, exc,
            )
        return None


def hydrate_task_from_sidecar(
    task: Dict[str, Any],
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> bool:
    """Populate ``task`` with state persisted by a prior step's run.

    Returns True if hydration happened.  Sidecar values are authoritative
    over polling-row defaults (e.g. polling default ``totalcount=0``
    must NOT shadow the real value the prior step recorded).

    Sidecar lookup honors ``task["sidecar_dir"]`` if set (injected by the
    standalone as a per-run stable path -- decouples sidecar location
    from per-task ``file_location`` which can vary across polling rows
    and otherwise causes state to be invisible to downstream steps).
    """
    if task.get("chunk_files") or task.get("consolidated_file"):
        return False  # in-process predecessor already populated
    base = task.get("sidecar_dir") or base_output_dir
    state = load_state(base, run_id, logger=logger)
    if state is None:
        if logger:
            logger.warning(
                "hydrate_task_from_sidecar: no sidecar at %s for run_id=%s "
                "— downstream step may fail its 'must run first' check.",
                base_output_dir, run_id,
            )
        return False
    hydrated = []
    for k in _SIDECAR_KEYS:
        if k in state:
            task[k] = state[k]
            hydrated.append(k)
    # Override base output_dir with the actual run subdir if recorded.
    if state.get("run_subdir"):
        task["output_dir"] = state["run_subdir"]
    if logger:
        logger.info(
            "hydrate_task_from_sidecar: lifted %d keys from sidecar (%s) — "
            "chunk_files=%d, totalcount=%s, output_dir=%s",
            len(hydrated), ",".join(hydrated),
            len(task.get("chunk_files") or []),
            task.get("totalcount"),
            task.get("output_dir"),
        )
    return True


def save_task_state(
    task: Dict[str, Any],
    base_output_dir: str,
    run_id: Any,
    logger=None,
) -> Optional[str]:
    """Persist every shared task-state key to the sidecar.  Returns the
    path written (or None on best-effort failure).

    Honors ``task["sidecar_dir"]`` over ``base_output_dir`` -- the
    standalone injects a per-run stable sidecar path so every step
    reads/writes the SAME sidecar regardless of per-row file_location
    (different polling rows for CLOUD vs ONPREM vs ConsolidateFiles vs
    CompressFile vs CreateControlFile all carry different file write
    locations; sidecar must live in one place across them)."""
    state = {k: task[k] for k in _SIDECAR_KEYS if k in task}
    base = task.get("sidecar_dir") or base_output_dir
    return save_state(state, base, run_id, logger=logger)


# ──────────────────────────────────────────────────────────────────────
#  RunArtifacts — cleanup-on-failure registry
# ──────────────────────────────────────────────────────────────────────

class RunArtifacts:
    """Append-only registry of every file written during a run.

    Every step that produces a file registers its path.  When the
    standalone catches an exception, it calls ``cleanup_on_failure()``
    which walks the registry and deletes everything so we never ship
    half-completed deliverables.

    Thread-safe — chunks are downloaded concurrently and each writer
    appends its path from a worker thread.

    State persistence: snapshot() / restore() lets the sidecar carry
    the artifact list across steps that run in separate pods or
    separate task dicts.  Hydrate at the start of every step, save at
    the end.
    """

    # Categories — let cleanup_on_failure decide what to keep.  CTL +
    # consolidated + compressed get removed on failure.  Run-report +
    # sidecar are debug aids and stay.
    CHUNK = "chunk"
    CONSOLIDATED = "consolidated"
    COMPRESSED = "compressed"
    CTL = "ctl"
    REPORT = "report"

    def __init__(self, logger=None, preserve_chunks_on_failure: bool = False):
        self.logger = logger
        self._lock = threading.Lock()
        self._items: List[Dict[str, str]] = []
        # 2026-06-13 -- 170M-record concern: a single late-partition
        # failure on a 170-partition extract would, by default, trigger
        # cleanup_on_failure and DELETE all 169 successful chunk files.
        # 8 hours of work gone.  When `preserve_chunks_on_failure` is
        # True the chunk category is SKIPPED on failure cleanup so the
        # successful work survives for an operator-driven re-run / resume.
        # Consolidated / compressed / CTL are STILL wiped (they're
        # incomplete deliverables masquerading as success otherwise).
        self.preserve_chunks_on_failure = bool(preserve_chunks_on_failure)

    def add(self, path: str, category: str) -> None:
        """Register a file.  Idempotent — duplicates ignored."""
        if not path:
            return
        abs_path = os.path.abspath(path)
        with self._lock:
            for item in self._items:
                if item["path"] == abs_path:
                    return
            self._items.append({"path": abs_path, "category": category})
        if self.logger:
            self.logger.debug("RunArtifacts: registered %s (%s)", abs_path, category)

    def add_many(self, paths: List[str], category: str) -> None:
        for p in paths:
            self.add(p, category)

    def list(self, category: Optional[str] = None) -> List[str]:
        with self._lock:
            if category is None:
                return [it["path"] for it in self._items]
            return [it["path"] for it in self._items if it["category"] == category]

    def snapshot(self) -> List[Dict[str, str]]:
        """Serializable copy of the registry — stash in sidecar."""
        with self._lock:
            return list(self._items)

    def restore(self, items: List[Dict[str, str]]) -> None:
        """Re-hydrate from a sidecar snapshot."""
        if not items:
            return
        with self._lock:
            for it in items:
                p = it.get("path")
                c = it.get("category", "unknown")
                if p and not any(existing["path"] == p for existing in self._items):
                    self._items.append({"path": p, "category": c})

    def cleanup_on_failure(self) -> int:
        """Delete every chunk / consolidated / compressed / ctl file.

        Returns the number of files removed.  Report files (HTML /
        text) and the sidecar are deliberately retained so the operator
        can inspect what happened.

        2026-06-13 -- when ``preserve_chunks_on_failure`` was set on
        the constructor, CHUNK category files are SKIPPED so a 170-
        partition extract that fails on partition #170 doesn't wipe
        partitions #1-169.  Operator can re-run with the surviving
        chunks intact (combined with the prior_output_mode=backup
        sidecar lifecycle).

        Called from the standalone's except branch.  Never raises --
        failure to remove an individual file is logged at WARN and the
        loop continues.
        """
        # 170M concern: preserve chunks on failure when operator opted in.
        skip_categories = set()
        if self.preserve_chunks_on_failure:
            skip_categories.add(self.CHUNK)
        targets = []
        preserved_count = 0
        with self._lock:
            for item in self._items:
                cat = item["category"]
                if cat not in (
                    self.CHUNK, self.CONSOLIDATED, self.COMPRESSED, self.CTL,
                ):
                    continue
                if cat in skip_categories:
                    preserved_count += 1
                    continue
                targets.append(item["path"])
        if preserved_count and self.logger:
            self.logger.warning(
                "RunArtifacts.cleanup_on_failure: PRESERVED %d chunk file(s) "
                "(preserve_chunks_on_failure=true) -- operator can re-run "
                "with surviving chunks intact",
                preserved_count,
            )

        removed = 0
        for path in targets:
            if not os.path.exists(path):
                continue
            try:
                os.remove(path)
                removed += 1
                if self.logger:
                    self.logger.info("Cleanup: removed %s", path)
            except OSError as exc:
                if self.logger:
                    self.logger.warning("Cleanup: could not remove %s: %s", path, exc)
        if self.logger:
            self.logger.warning(
                "RunArtifacts.cleanup_on_failure: removed %d of %d registered files",
                removed, len(targets),
            )
        return removed

    def cleanup_chunks_only(self) -> int:
        """Remove only chunk files — used after a successful consolidation
        if we want to free the per-partition intermediates.

        The consolidator usually deletes its own inputs as it merges
        them; this is a defensive backstop.
        """
        targets = self.list(self.CHUNK)
        removed = 0
        for path in targets:
            if not os.path.exists(path):
                continue
            try:
                os.remove(path)
                removed += 1
            except OSError:
                pass
        if self.logger and removed:
            self.logger.info("Cleanup-chunks: removed %d chunk files", removed)
        return removed


def get_or_create_artifacts(task: Dict[str, Any], logger=None) -> RunArtifacts:
    """Convenience: lift a RunArtifacts instance off the task dict or
    create a new one.  Steps call this on entry, register their files,
    and the standalone reads it back on exit."""
    art = task.get("_run_artifacts")
    if isinstance(art, RunArtifacts):
        return art
    art = RunArtifacts(logger=logger)
    # Re-hydrate from sidecar snapshot if one is on the task dict.
    snap = task.get("artifact_paths")
    if isinstance(snap, list):
        art.restore(snap)
    task["_run_artifacts"] = art
    return art
