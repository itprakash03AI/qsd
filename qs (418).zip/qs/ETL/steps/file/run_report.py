"""File-flow run report — HTML + plain text + optional email.

ONE deliverable per run, ALWAYS written to ``<output_dir>/run_report.html``
regardless of success / failure, so an operator opening the output dir
after a crash sees the full picture without grepping logs.

Designed for the Starburst-to-file pipeline (file_standalone.py).
Three artefacts, all gated on flags so local dev doesn't accidentally
mail prod:

  * ``run_report.html`` — always written.  Self-contained, no external
                          CSS/JS, opens in any browser.
  * Start email         — ``send_email=true`` AND status == "START".
  * Finish email        — ``send_email=true`` AND status in {SUCCESS, FAILED};
                          inlines the HTML body.

Tracks the file-flow completeness ledger (G1-G5):

  G1 — Source pre-flight COUNT(*)               (expected_total)
  G2 — Sum(per-partition COUNT(*)) == G1        (partition plan coverage)
  G3 — Sum(actual rows written to chunks) == G1 (streaming integrity)
  G4 — per-partition actual == per-partition expected
  G5 — Consolidated file rows == G1             (merge integrity)
"""
from __future__ import annotations

import html
import os
import smtplib
from datetime import datetime, timezone
from email.message import EmailMessage
from typing import Any, Dict, List, Optional


# Sentinel defaults — the constructor expects these to flow in from
# the polling row / per-job JSON / oracle_config.yaml (operators steer
# every write artefact via config).  Defaults exist ONLY as a last-
# resort fallback when nothing else is provided.
_DEFAULT_QUERIES_SUBDIR = "queries"
_DEFAULT_REPORT_HTML = "run_report.html"
# 2026-06-22 -- .txt file disabled by default (user request: "we don't
# need report.txt").  HTML is the operator-facing artefact; the .txt
# was a noisy duplicate.  Operators can re-enable per-run by setting
# polling-row column report_filename_txt="run_report.txt" or via
# oracle_config.yaml run_report.report_filename_txt.
# Note: to_text() output is STILL used as the multipart/alternative
# text fallback in send_email() -- that path is unchanged.
_DEFAULT_REPORT_TXT = ""
_DEFAULT_SQL_EXT = ".sql"


# 2026-06-20 -- inline operator help for every runtime knob the planner
# emits.  Rendered as a small italic note under each knob name in the
# HTML "Runtime knobs" table so operators don't have to read the
# codebase to understand what AutoPlan picked + why.  Auto-derived
# means no polling-row column is needed; operator override is OPTIONAL.
_KNOB_DOCS = {
    # Plan + execution knobs (set by _build_scan_plan / ScanPlan)
    "scan_mode": (
        "SINGLE = one Trino query streams the whole result.  "
        "PARTITION_VALUES = N parallel queries split by a column.  "
        "Auto-derived; override per-job with FORCE_SINGLE / FORCE_PARTITION."
    ),
    "partition_column": (
        "Column used to split work in PARTITION_VALUES mode.  Set on "
        "polling row's partition_column or in per-job JSON.  Empty when "
        "scan_mode == SINGLE."
    ),
    "chunk_count": "Number of parallel Trino queries dispatched for this job.",
    "batch_size": (
        "Rows per Trino fetchmany() call.  Larger = fewer network round "
        "trips but bigger Python memory peak per chunk.  Auto-derived by "
        "AutoPlan to target ~20 MB per batch (floor 100K, ceiling 500K)."
    ),
    "max_concurrent_chunks": (
        "Parallel chunks running at once.  Auto-derived by AutoPlan as "
        "min(cpu_cores/2, available_memory*0.4/per_chunk_bytes, ceiling=8).  "
        "Per-job override: MAX_CONCURRENT_CHUNKS column on polling row."
    ),
    "max_chunk_retries": "Soft-retry budget per chunk before bucket-fails the run.",
    # AutoPlan explanations (set by _build_scan_plan after autoplan() runs)
    "autoplan_mode": (
        "AutoPlan-derived scan mode + why.  Format: '<chosen> -- <reason>'.  "
        "When this disagrees with scan_mode, operator override won."
    ),
    "autoplan_batch_size": (
        "AutoPlan-derived batch_size + why.  Considers row width + 20 MB "
        "target.  Operator can override via BATCH_SIZE on polling row."
    ),
    "autoplan_max_concurrent_chunks": (
        "AutoPlan-derived parallelism + why.  Capped by CPU cores, "
        "available memory, and MAX_CONCURRENT_CHUNKS_CEILING (default 8)."
    ),
    "autoplan_queue_maxsize": (
        "AutoPlan-derived ChunkWriter back-pressure depth.  Narrow rows "
        "get deeper queue (4); wide rows get shallow (2) so per-chunk "
        "memory stays bounded."
    ),
    "autoplan_auto_bucket_size": (
        "AutoPlan-derived bucket size for PARTITION_VALUES.  1 = no "
        "bucketing.  >1 means N adjacent partition values grouped into "
        "one Trino query for parallelism efficiency."
    ),
    "autoplan_target_chunk_rows": (
        "AutoPlan's per-chunk row target.  Drives the bucketing math + "
        "memory budget calculations."
    ),
    "autoplan_verify_strategy": (
        "AutoPlan-derived sink-verify strategy (S3 path only).  full = "
        "re-read whole file; sample = sample-based check for very large "
        "outputs to bound verify cost."
    ),
}


class FileRunReport:
    """Accumulates run state, renders HTML + text, optionally emails."""

    def __init__(
        self,
        *,
        output_dir: str,
        logger=None,
        queries_subdir: str = "",
        report_filename_html: str = "",
        report_filename_txt: str = "",
        sql_file_extension: str = "",
        backup_ts: str = "",
        prior_output_mode: str = "backup",
        c2_advisory_drift_pct: Optional[float] = None,
        c2_advisory_max_rows: Optional[int] = None,
        c4_advisory_net_delta_max: Optional[int] = None,
        filename_priority: Optional[str] = None,
    ):
        """Write paths are layered DB row -> config -> sensible default
        so nothing is hard-coded in this module.

        Args:
          output_dir: ALWAYS supplied by the caller — typically
            ``job_config['output_file_location']`` from the polling
            row's per-job JSON, OR the standalone's resolved log dir.
          queries_subdir: directory under ``output_dir`` where per-job
            ``.sql`` files land.  Empty -> falls back to default.
          report_filename_html / report_filename_txt: filenames for the
            ``run_report.html`` / ``run_report.txt`` artefacts.
            Empty -> default.
          sql_file_extension: file extension (with dot) for the per-job
            SQL files.  Empty -> default ``.sql``.

        2026-06-12 — these knobs replace hard-coded path fragments
        (``queries``, ``run_report.html``, ``.sql``) so operators can
        steer every artefact via the polling row / config file.
        """
        self.output_dir = output_dir
        self.logger = logger
        # Apply defaults LAZILY in write() rather than in __init__ so
        # operators can still pass empty strings to opt out of writing
        # a particular artefact category later.
        self.queries_subdir = queries_subdir or _DEFAULT_QUERIES_SUBDIR
        self.report_filename_html = report_filename_html or _DEFAULT_REPORT_HTML
        self.report_filename_txt = report_filename_txt or _DEFAULT_REPORT_TXT
        self.sql_file_extension = sql_file_extension or _DEFAULT_SQL_EXT
        # 2026-06-13 -- prior-output handling for the HTML / TXT reports
        # when a same-named report from a prior run already exists in
        # output_dir.  "backup" (default) moves to backup_<ts>/;
        # "delete" just unlinks.
        self.backup_ts = backup_ts or ""
        self.prior_output_mode = prior_output_mode or "backup"
        self.started_at: datetime = datetime.now(timezone.utc)
        self.finished_at: Optional[datetime] = None
        self.context: Dict[str, Any] = {}
        self.runtime_knobs: Dict[str, Any] = {}
        self.job_results: List[Dict[str, Any]] = []      # one entry per report_id / datasource
        self.chunk_results: List[Dict[str, Any]] = []    # one entry per partition / chunk
        self.expected_total: Optional[int] = None        # G1
        # 2026-06-13 -- where G1 came from so the operator can see
        # whether the anchor is a Trino COUNT(*), a discovery sum, or
        # was measured from the extract itself.  Set by the Starburst
        # step's set_counts pass.
        self.g1_source: str = ""
        self.sum_partition_expected: Optional[int] = None  # G2 (Sum of per-partition COUNT(*))
        self.sum_chunk_actual: Optional[int] = None      # G3 (Sum of actual rows written)
        self.consolidated_total: Optional[int] = None    # G5
        self.output_files: List[str] = []
        self.status: str = "START"
        self.error_message: Optional[str] = None
        # 2026-06-21 -- failure email richness fields.  Populated by
        # mark_failed(error, step_name=..., log_file_path=...) so the
        # email body tells operators WHICH step crashed + WHERE to grep.
        self.failed_step_name: Optional[str] = None
        self.failed_step_seq: Optional[int] = None
        self.log_file_path: Optional[str] = None
        self.pod_hostname: Optional[str] = None
        self.sql_summary: Dict[str, str] = {}            # job_id -> sql first line (debug)
        # 2026-06-12 — full SQL per job, written to queries/<job>.sql
        # alongside the report so end-users can download from the HTML.
        # Spans the file workflow AND the Starburst -> Oracle steps that
        # push their SQL into ``task["_run_report"]``.
        self.sql_full: Dict[str, str] = {}               # job_id -> complete SQL text
        self.sql_files: Dict[str, str] = {}              # job_id -> absolute .sql path (post-write)
        # 2026-06-17 -- track previously-written report paths so the
        # final write() can clean up the orphan "in progress" HTML left
        # by the start-of-run write().  Without this, the start write
        # resolves to `run_report.html` (no deliverable yet known) and
        # the final write resolves to `<deliverable>.report.html` (after
        # steps populate output_files) -- two DIFFERENT paths.  Operators
        # opening `run_report.html` see permanent "in progress" because
        # nothing ever overwrote it.
        self._last_written_paths: List[str] = []
        # 2026-06-20 -- operator-tunable advisory verdict thresholds.  None
        # means "use class default".  Passed in by the standalone (which
        # reads them off polling row / oracle_config.yaml).
        self.c2_advisory_drift_pct = (
            self.DEFAULT_C2_ADVISORY_DRIFT_PCT
            if c2_advisory_drift_pct is None else float(c2_advisory_drift_pct)
        )
        self.c2_advisory_max_rows = (
            self.DEFAULT_C2_ADVISORY_MAX_ROWS
            if c2_advisory_max_rows is None else int(c2_advisory_max_rows)
        )
        self.c4_advisory_net_delta_max = (
            self.DEFAULT_C4_ADVISORY_NET_DELTA_MAX
            if c4_advisory_net_delta_max is None else int(c4_advisory_net_delta_max)
        )
        # filename_priority: "polling_row" (new 2026-06-20 default --
        # FILE_NAME hint wins) or "output_files" (legacy -- consolidated
        # file basename wins).  Operators who relied on legacy behaviour
        # set this to "output_files" to preserve old report filenames.
        self.filename_priority = (filename_priority or "polling_row").lower()
        if self.filename_priority not in ("polling_row", "output_files"):
            self.filename_priority = "polling_row"
        # 2026-06-20 -- "multiple result.html" fix.  Before this set, every
        # successive write() through the run called backup_if_exists on the
        # SAME path because the prior write left a file there.  With 6
        # write() sites (standalone start, starburst step, merge, compress,
        # ctl, standalone finish) operators ended up with 5+ stale copies
        # in backup_<ts>/<name>.html.1, .2, .3, ... and ONE live file.
        # This set records every path THIS run already wrote to; the
        # write() path-loop only invokes backup_if_exists for paths NOT in
        # it -- i.e. the FIRST encounter of each resolved filename.
        # Re-overwrites within the same run go through as plain writes.
        self._paths_written_this_run: set = set()

    # -- Setters --------------------------------------------------------

    def set_context(self, **kwargs) -> None:
        self.context.update({k: v for k, v in kwargs.items() if v is not None})

    def set_runtime_knobs(self, **kwargs) -> None:
        self.runtime_knobs.update({k: v for k, v in kwargs.items() if v is not None})

    def set_counts(
        self,
        expected_total: Optional[int] = None,
        sum_partition_expected: Optional[int] = None,
        sum_chunk_actual: Optional[int] = None,
        consolidated_total: Optional[int] = None,
        g1_source: Optional[str] = None,
    ) -> None:
        if expected_total is not None:
            self.expected_total = expected_total
        if sum_partition_expected is not None:
            self.sum_partition_expected = sum_partition_expected
        if sum_chunk_actual is not None:
            self.sum_chunk_actual = sum_chunk_actual
        if consolidated_total is not None:
            self.consolidated_total = consolidated_total
        if g1_source:
            self.g1_source = g1_source

    def add_job_result(self, result: Dict[str, Any]) -> None:
        self.job_results.append(result)

    def add_chunk_result(self, result: Dict[str, Any]) -> None:
        self.chunk_results.append(result)

    def add_output_file(self, path: str) -> None:
        if path and path not in self.output_files:
            self.output_files.append(path)

    def add_sql_summary(self, job_id: str, sql: str) -> None:
        """Record a job's SQL.  Stores BOTH:
          * first-line abbrev in ``sql_summary`` (inline HTML cell).
          * full text in ``sql_full`` -> written as ``queries/<job>.sql``
            on ``write()`` and linked from the HTML so end-users can
            download.
        Idempotent on the same job_id; last write wins.
        """
        job_key = str(job_id)
        sql_text = sql or ""
        first = sql_text.strip().splitlines()[0] if sql_text.strip() else ""
        self.sql_summary[job_key] = first[:200]
        if sql_text.strip():
            self.sql_full[job_key] = sql_text

    def mark_started(self) -> None:
        self.status = "START"
        self.started_at = datetime.now(timezone.utc)

    def mark_success(self) -> None:
        self.status = "SUCCESS"
        self.finished_at = datetime.now(timezone.utc)

    def mark_failed(
        self,
        error_message: str,
        step_name: Optional[str] = None,
        step_seq: Optional[int] = None,
        log_file_path: Optional[str] = None,
    ) -> None:
        """Mark the run failed.  2026-06-21 enhanced signature so the
        failure email tells operators WHICH step failed + WHERE the
        log file lives (for grep-able post-mortem).  Older callers
        passing just error_message still work."""
        self.status = "FAILED"
        self.error_message = error_message
        self.finished_at = datetime.now(timezone.utc)
        if step_name is not None:
            self.failed_step_name = step_name
        if step_seq is not None:
            self.failed_step_seq = step_seq
        if log_file_path is not None:
            self.log_file_path = log_file_path
        # Capture pod hostname for the failure email -- operators can
        # correlate K8s pod logs with the email + identify which replica.
        if self.pod_hostname is None:
            try:
                import socket as _sock
                self.pod_hostname = _sock.gethostname()
            except Exception:
                pass

    # -- Rendering helpers ---------------------------------------------

    def _duration_str(self) -> str:
        if self.finished_at is None:
            return "(in progress)"
        secs = int((self.finished_at - self.started_at).total_seconds())
        h, rem = divmod(secs, 3600)
        m, s = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _duration_human(self) -> str:
        if self.finished_at is None:
            return "in progress"
        secs = int((self.finished_at - self.started_at).total_seconds())
        h, rem = divmod(secs, 3600)
        m, s = divmod(rem, 60)
        if h:
            return f"{h}h {m:02d}m {s:02d}s"
        if m:
            return f"{m}m {s:02d}s"
        return f"{s}s"

    def _local_time(self, dt) -> str:
        """ISO 8601 with explicit local TZ + UTC shadow.

        2026-06-21 -- normalised to ISO 8601 so the format is identical
        across log lines, result.html, sidecar JSON, and email body.
        Operators reading multiple surfaces see the SAME timestamp shape.

        Format: ``YYYY-MM-DDTHH:MM:SS+HH:MM (UTC: YYYY-MM-DDTHH:MM:SSZ)``
        """
        if dt is None:
            return "(pending)"
        try:
            local = dt.astimezone()
            utc = dt.astimezone(timezone.utc)
            return (
                f"{local.strftime('%Y-%m-%dT%H:%M:%S%z')} "
                f"(UTC: {utc.strftime('%Y-%m-%dT%H:%M:%SZ')})"
            )
        except Exception:
            return dt.isoformat()

    @staticmethod
    def _fmt_ts(epoch_seconds: Optional[float]) -> str:
        """Format an epoch timestamp (e.g. os.path.getctime/getmtime
        return value) in the SAME shape as _local_time so file
        timestamps align with the run timestamps in result.html."""
        if epoch_seconds is None:
            return "-"
        try:
            local = datetime.fromtimestamp(epoch_seconds).astimezone()
            utc = datetime.fromtimestamp(epoch_seconds, tz=timezone.utc)
            return (
                f"{local.strftime('%Y-%m-%dT%H:%M:%S%z')} "
                f"(UTC: {utc.strftime('%Y-%m-%dT%H:%M:%SZ')})"
            )
        except Exception:
            return str(epoch_seconds)

    def _verdict_cell(self, ok: bool, detail: str) -> str:
        cls = "ok" if ok else "fail"
        label = "OK" if ok else "FAIL"
        e = html.escape
        return f"<td class='{cls}'>{label}</td><td>{e(detail)}</td>"

    # -- Completeness ledger helpers -----------------------------------

    _LEDGER_DESCRIPTIONS = {
        "G1": "Source row count -- the authoritative `expected_total` all downstream controls compare against.  May come from a pre-flight COUNT(*), from partition discovery sum, or measured from extract (see Source column).",
        "G2": "Sum of per-partition COUNT(*) values equals G1 -- proves the partition plan covers every row (no shard skipped).  By-construction-OK when G1 was derived from discovery (same source).  Control is SKIPPED in SINGLE mode and in distinct-discovery mode (per-partition counts not collected).",
        "G3": "Sum of rows actually written to chunk files equals G1 -- proves the streaming extract didn't drop any row.",
        "G4": "Per-partition: rows actually written == expected for that partition -- proves no single shard short-wrote.",
        "G5": "Consolidated file row count equals G1 -- proves the cross-source / cross-chunk merge produced one byte-correct deliverable.",
    }

    # ── Cumulative cross-source totals (2026-06-18) ────────────────────
    # set_counts was last-writer-wins: cloud step set expected_total=3M,
    # onprem step overwrote it with 2.6M, result.html showed 2.6M as if
    # CLOUD never extracted.  Fix: sum across self.job_results (one entry
    # per source) at render time.  set_counts callers stay unchanged --
    # they keep updating self.expected_total etc. for back-compat, but
    # render uses the cumulative when job_results has data.

    def _cum_source_count(self) -> Optional[int]:
        """Sum of per-source ``expected_total`` from job_results.
        Falls back to self.expected_total when job_results is empty
        (single-source / pre-set-counts cases)."""
        vals = [int(j.get("expected_total") or 0)
                 for j in self.job_results
                 if j.get("expected_total") is not None]
        if vals:
            return sum(vals)
        return self.expected_total

    def _cum_downloaded(self) -> Optional[int]:
        """Sum of per-source ``records`` (= chunk-writer actuals)."""
        vals = [int(j.get("records") or 0)
                 for j in self.job_results
                 if j.get("records") is not None]
        if vals:
            return sum(vals)
        return self.sum_chunk_actual

    def _cum_partition_expected(self) -> Optional[int]:
        """Sum of per-source ``sum_partition_expected``.  None when any
        source reported None (chip becomes 'SKIPPED' rather than a
        meaningless partial sum)."""
        if not self.job_results:
            return self.sum_partition_expected
        vals = [j.get("sum_partition_expected") for j in self.job_results]
        if any(v is None for v in vals) or not vals:
            return None
        return sum(int(v or 0) for v in vals)

    def _cum_per_source_consolidated(self) -> Optional[int]:
        """Sum of per-source ``consolidated_rows`` (file-row count of
        each per-source consolidated file BEFORE the cross-source
        merge).  Used to render the per-source 'file rows' column."""
        vals = [int(j.get("consolidated_rows") or 0)
                 for j in self.job_results
                 if j.get("consolidated_rows") is not None]
        if vals:
            return sum(vals)
        return None

    # 2026-06-20 -- USER-FACING NAMING: the internal dict key stays "G1"-"G5"
    # for back-compat (tests + log lines reference these tokens), but every
    # render path (HTML chip, HTML table tag, plain-text rendering, email
    # subject) reads from the "display" field below.  Result: result.html
    # shows "C1: OK" / "C5: FAIL" -- consistent with the "Completeness
    # controls" section heading and avoids the "gates" jargon.
    _DISPLAY_LABELS = {
        "G1": "C1",
        "G2": "C2",
        "G3": "C3",
        "G4": "C4",
        "G5": "C5",
    }

    # 2026-06-20 -- ADVISORY-VERDICT THRESHOLDS (operator-tunable).
    # Pre-2026-06-20-evening these were hardcoded constants in
    # _ledger_entries (drift_pct < 0.01 for C2, net_delta == 0 for C4).
    # Hardcoded 1% on a 150M-row table = 1.5M rows of "advisory" -- way
    # too permissive.  Defaults below are now MUCH tighter; operators
    # can raise per-pipeline via constructor args (sourced from polling
    # row / oracle_config.yaml in the standalone).
    #
    # C2 (Sum(per-partition COUNT(*)) == G1):
    #   advisory_OK iff C3 anchor passed AND
    #     |delta| / G1 <= C2_advisory_drift_pct  AND
    #     |delta|       <= C2_advisory_max_rows
    #   Both conditions must hold so very large tables don't quietly
    #   eat thousands of "advisory" rows.
    # C4 (per-partition actual == expected):
    #   advisory_OK iff C3 anchor passed AND
    #     |net_delta_across_chunks| <= C4_advisory_net_delta_max
    DEFAULT_C2_ADVISORY_DRIFT_PCT = 0.001   # 0.1% (was 1%)
    DEFAULT_C2_ADVISORY_MAX_ROWS = 1000     # absolute cap regardless of size
    # 2026-06-20 deep-dive fix: default -1 (UNLIMITED) -- when C3
    # cumulative matches G1, C4 is informational only.  Per-chunk
    # discovery vs extract differences are common + benign (source
    # snapshot drift, shape-affected SQL).  Operators with strict
    # per-shard correctness needs set this to 0 to restore hard FAIL.
    DEFAULT_C4_ADVISORY_NET_DELTA_MAX = -1

    def _ledger_entries(self) -> List[Dict[str, Any]]:
        """Build the G1-G5 control ledger as a list of {control, display,
        ok, detail, why} dicts -- consumed by both the HTML render AND the
        email plain-text fallback so they stay in lockstep.

        Reads cumulative totals across self.job_results so multi-source
        jobs render correctly (cloud + onprem totals summed, not just
        last-source).

        2026-06-20 -- ``display`` is the USER-FACING label ("C1"-"C5");
        ``control`` is the internal key ("G1"-"G5") retained for back-compat
        with existing test assertions and log lines.
        """
        def _disp(key: str) -> str:
            return self._DISPLAY_LABELS.get(key, key)
        out: List[Dict[str, Any]] = []
        g1 = self._cum_source_count()
        g3 = self._cum_downloaded()
        g2 = self._cum_partition_expected()
        if g1 is not None:
            src = f" ({self.g1_source})" if self.g1_source else ""
            out.append({
                "control": "G1",
                "display": _disp("G1"),
                "label": f"Source row count{src}",
                "ok": True,
                "detail": f"{g1:,}",
                "why": self._LEDGER_DESCRIPTIONS["G1"],
            })
        if g2 is not None and g1 is not None:
            # 2026-06-20 -- ADVISORY-OK on drift.  When C2 (sum-of-partition
            # COUNT(*)) differs from G1 by a small amount AND C3 anchor
            # passed (sum of chunk actuals == G1 -- rows ACTUALLY shipped),
            # the drift is benign source-snapshot motion between scans.
            # BOTH conditions must hold for advisory-OK:
            #   * relative drift <= c2_advisory_drift_pct (default 0.1%)
            #   * absolute drift <= c2_advisory_max_rows (default 1000)
            # Operator can raise either via constructor args (sourced
            # from polling-row C2_ADVISORY_DRIFT_PCT / C2_ADVISORY_MAX_ROWS
            # columns in the standalone).  Hardcoded 1% removed.
            ok = g2 == g1
            advisory = False
            if not ok and g3 is not None and g3 == g1:
                abs_delta = abs(g2 - g1)
                drift_pct = abs_delta / g1 if g1 else 0.0
                if (drift_pct <= self.c2_advisory_drift_pct
                    and abs_delta <= self.c2_advisory_max_rows):
                    ok = True
                    advisory = True
            delta = g2 - g1
            detail = f"{g2:,} (delta {delta:+,})"
            if advisory:
                detail = (
                    f"{g2:,} (delta {delta:+,} -- ADVISORY: drift "
                    f"<={self.c2_advisory_drift_pct * 100:.2f}% AND "
                    f"<={self.c2_advisory_max_rows:,} rows; C3 proved "
                    f"no data loss)"
                )
            out.append({
                "control": "G2",
                "display": _disp("G2"),
                "label": f"Sum(per-partition COUNT(*)) == {_disp('G1')}",
                "ok": ok,
                "detail": detail,
                "why": self._LEDGER_DESCRIPTIONS["G2"],
            })
        if g3 is not None and g1 is not None:
            ok = g3 == g1
            delta = g3 - g1
            out.append({
                "control": "G3",
                "display": _disp("G3"),
                "label": f"Sum(rows written to chunks) == {_disp('G1')}",
                "ok": ok,
                "detail": f"{g3:,} (delta {delta:+,})",
                "why": self._LEDGER_DESCRIPTIONS["G3"],
            })
        if self.chunk_results:
            mism = [
                c for c in self.chunk_results
                if c.get("expected") is not None
                and c.get("actual") is not None
                and c["actual"] != c["expected"]
            ]
            # 2026-06-20 -- ADVISORY-OK when C3 anchor reconciled at job
            # level (cumulative count IS the truth).  Per-chunk expected
            # comes from discovery (group_by COUNT on source) -- the
            # extract's per-chunk actual can legitimately differ when:
            #   * source drifted between discovery + extract
            #   * base_sql has DISTINCT/GROUP BY (discovery counts source
            #     rows pre-agg; chunk extract returns post-agg rows)
            # If the SHARDS rolled up to the right TOTAL (C3 == G1), the
            # run produced correct data -- C4 chip is informational, not
            # a fail signal.  ``c4_advisory_net_delta_max`` is the *hard*
            # cap above which we still FAIL even when C3 passes (operator
            # protection against pathological row-shuffling that nets out
            # but means data moved between partitions in a way they care
            # about).  Default unlimited (-1) since C3 is the real anchor.
            ok = not mism
            advisory_g4 = False
            if mism and g3 is not None and g1 is not None and g3 == g1:
                net_delta = sum(
                    (c["actual"] - c["expected"]) for c in mism
                    if c.get("expected") is not None and c.get("actual") is not None
                )
                # -1 sentinel = unlimited tolerance (operator trusts C3).
                cap = self.c4_advisory_net_delta_max
                if cap < 0 or abs(net_delta) <= cap:
                    ok = True
                    advisory_g4 = True
            detail = (
                f"{len(self.chunk_results) - len(mism)} of "
                f"{len(self.chunk_results)} chunks match"
            )
            if advisory_g4:
                detail += (
                    " (ADVISORY: C3 cumulative count == G1 -- per-chunk "
                    "drift expected when discovery + extract see different "
                    "source snapshots OR base_sql has DISTINCT/GROUP BY)"
                )
            out.append({
                "control": "G4",
                "display": _disp("G4"),
                "label": "Per-partition actual == expected",
                "ok": ok,
                "detail": detail,
                "why": self._LEDGER_DESCRIPTIONS["G4"],
            })
        if self.consolidated_total is not None and g1 is not None:
            ok = self.consolidated_total == g1
            delta = self.consolidated_total - g1
            out.append({
                "control": "G5",
                "display": _disp("G5"),
                "label": f"Consolidated file rows == {_disp('G1')}",
                "ok": ok,
                "detail": f"{self.consolidated_total:,} (delta {delta:+,})",
                "why": self._LEDGER_DESCRIPTIONS["G5"],
            })
        return out

    def _overall_ok(self) -> bool:
        """True iff every recorded control verdict is OK."""
        return all(entry["ok"] for entry in self._ledger_entries())

    def to_html(self) -> str:
        e = html.escape
        ledger = self._ledger_entries()

        # --- Completeness controls rows ---
        # 2026-06-20 -- entry["display"] (C1-C5) is the user-facing label;
        # entry["control"] (G1-G5) stays as the internal key for back-compat.
        ledger_rows = ""
        for entry in ledger:
            ledger_rows += (
                f"<tr><td><span class='control-tag'>{entry['display']}</span> "
                f"{e(entry['label'])}<div class='control-why'>{e(entry['why'])}</div></td>"
                f"{self._verdict_cell(entry['ok'], entry['detail'])}</tr>"
            )

        # --- Top-of-page summary verdict chips (C1-C5 at a glance) ---
        verdict_chips = ""
        for entry in ledger:
            chip_cls = "ok" if entry["ok"] else "fail"
            verdict_chips += (
                f"<span class='chip {chip_cls}' title='{e(entry['why'])}'>"
                f"{entry['display']}: {'OK' if entry['ok'] else 'FAIL'}</span>"
            )

        # --- Headline metrics ---
        deliverable_name = ""
        deliverable_bytes = 0
        for p in self.output_files:
            if p and os.path.exists(p) and p.lower().endswith(
                (".dat", ".csv", ".gz", ".zip", ".tar")
            ):
                deliverable_name = os.path.basename(p)
                try:
                    deliverable_bytes = os.path.getsize(p)
                except OSError:
                    deliverable_bytes = 0
                break

        # --- Per-chunk rows ---
        # 2026-06-13 -- sort by (job_id, datasource, partition_index)
        # so CLOUD and ONPREM partitions of the same report_id sit
        # together but don't collide on partition_index (both have
        # partition_index 0, 1, 2... for cross-source partition-by).
        rows_chunks = ""
        for c in sorted(
            self.chunk_results,
            key=lambda x: (
                x.get("job_id", ""),
                x.get("datasource", ""),
                x.get("partition_index", 0),
            ),
        ):
            expected = c.get("expected")
            actual = c.get("actual")
            verdict = "ok" if (expected is None or actual == expected) else "fail"
            # 2026-06-21 -- queue_wait + stream timing diagnostic.
            # When queue_wait > stream, the Trino coordinator queued
            # this chunk -- operator should lower trino_profile or
            # raise MAX_CONCURRENT_CHUNKS_CEILING.  Highlight that row.
            _qw = c.get("queue_wait_sec")
            _st = c.get("stream_sec")
            _qw_html = f"{_qw:.1f}s" if _qw is not None else "-"
            _st_html = f"{_st:.1f}s" if _st is not None else "-"
            _slow_class = ""
            if _qw is not None and _st is not None and _qw > _st and _qw > 10:
                _slow_class = " queue-pressure"
                _qw_html = (
                    f"<span title='queue_wait > stream -- Trino "
                    f"coordinator queued this chunk'>{_qw_html}</span>"
                )
            rows_chunks += (
                f"<tr class='{verdict}{_slow_class}'>"
                f"<td>{e(str(c.get('job_id', '?')))}</td>"
                f"<td>{e(str(c.get('datasource', '')))}</td>"
                f"<td>{e(str(c.get('partition_index', '?')))}</td>"
                f"<td>{e(str(c.get('partition_value', '')))}</td>"
                f"<td class='right-aligned'>{expected if expected is not None else '?'}</td>"
                f"<td class='right-aligned'>{actual if actual is not None else '?'}</td>"
                f"<td class='right-aligned'>{c.get('attempts', 1)}</td>"
                f"<td class='right-aligned'>{c.get('duration_sec', 0):.1f}s</td>"
                f"<td class='right-aligned'>{_qw_html}</td>"
                f"<td class='right-aligned'>{_st_html}</td>"
                f"<td><code>{e(str(c.get('file_path', '')))}</code></td>"
                f"</tr>"
            )

        # --- Per-job summary rows ---
        # 2026-06-18 -- columns expanded so the operator sees ALL three
        # counts side-by-side, per source:
        #   Source  = G1 for that source (expected_total from job_result)
        #   Download= chunk-writer actuals (records)
        #   File    = per-source consolidated file row count (when present)
        # A TOTAL row at the bottom sums each column across sources --
        # this is what makes "cloud + onprem == final file" visible.
        rows_jobs = ""
        tot_source = 0
        tot_download = 0
        tot_file = 0
        any_source = any_download = any_file = False
        def _cell(v):
            return f"{int(v):,}" if v is not None else "—"
        for j in self.job_results:
            status = j.get("status", "?")
            cls = {"success": "ok", "failed": "fail", "partial_success": "warn"}.get(status, "warn")
            src_v = j.get("expected_total")
            dl_v = j.get("records")
            file_v = j.get("consolidated_rows")
            if src_v is not None:
                tot_source += int(src_v)
                any_source = True
            if dl_v is not None:
                tot_download += int(dl_v)
                any_download = True
            if file_v is not None:
                tot_file += int(file_v)
                any_file = True
            # Mismatch flag: delta between source / download for THIS
            # row -- helps the operator spot which source diverged.
            row_mismatch = ""
            if src_v is not None and dl_v is not None and int(src_v) != int(dl_v):
                row_mismatch = (
                    f" <span title='download vs source delta'>"
                    f"(Δ {int(dl_v) - int(src_v):+,})</span>"
                )
            rows_jobs += (
                f"<tr class='{cls}'>"
                f"<td>{e(str(j.get('report_id', '?')))}</td>"
                f"<td>{e(str(j.get('datasource', '?')))}</td>"
                f"<td>{e(status.upper())}</td>"
                f"<td class='right-aligned'>{_cell(src_v)}</td>"
                f"<td class='right-aligned'>{_cell(dl_v)}{row_mismatch}</td>"
                f"<td class='right-aligned'>{_cell(file_v)}</td>"
                f"<td class='right-aligned'>{j.get('chunks', 0)}</td>"
                f"<td><code>{e(str(j.get('file_path', '')))}</code></td>"
                f"</tr>"
            )
        # TOTAL row -- "cloud + onprem source == cloud_file + onprem_file"
        # made visible.  Only emit when there's at least one job_result;
        # color the totals row green when all three columns agree
        # element-wise (true completeness across sources).
        if self.job_results:
            totals_ok = (
                (not any_source or not any_download or tot_source == tot_download)
                and (not any_source or not any_file or tot_source == tot_file)
            )
            tot_cls = "ok" if totals_ok else "fail"
            rows_jobs += (
                f"<tr class='{tot_cls}' style='font-weight:bold'>"
                f"<td colspan='2'>TOTAL (sum across sources)</td>"
                f"<td>—</td>"
                f"<td class='right-aligned'>" + (f"{tot_source:,}" if any_source else "—") + "</td>"
                f"<td class='right-aligned'>" + (f"{tot_download:,}" if any_download else "—") + "</td>"
                f"<td class='right-aligned'>" + (f"{tot_file:,}" if any_file else "—") + "</td>"
                f"<td colspan='2'>"
            )
            # Annotate mismatch on the TOTAL row so the operator can
            # see at a glance: "source 5,624,546 vs download 5,634,098
            # (Δ +9,552)".
            if any_source and any_download and tot_source != tot_download:
                rows_jobs += (
                    f"<span title='cumulative download vs source delta'>"
                    f"download Δ {tot_download - tot_source:+,}</span>"
                )
            if any_source and any_file and tot_source != tot_file:
                if "Δ" in rows_jobs[-200:]:
                    rows_jobs += " · "
                rows_jobs += (
                    f"<span title='cumulative file vs source delta'>"
                    f"file Δ {tot_file - tot_source:+,}</span>"
                )
            rows_jobs += "</td></tr>"

        rows_context = "".join(
            f"<tr><td><b>{e(k)}</b></td><td>{e(str(v))}</td></tr>"
            for k, v in self.context.items()
        )
        # 2026-06-20 -- inline docs for the runtime knobs so operators
        # reading result.html know what each one means without grep-
        # ping the codebase.  Doc lookup is best-effort: an unknown
        # knob just renders without a tooltip.
        rows_knobs = "".join(
            f"<tr><td><b>{e(k)}</b>"
            + (f"<div class='control-why'>{e(_KNOB_DOCS[k])}</div>"
               if k in _KNOB_DOCS else "")
            + f"</td><td>{e(str(v))}</td></tr>"
            for k, v in self.runtime_knobs.items()
        )
        # 2026-06-12 -- each SQL row gains a Download link when the
        # ``.sql`` file has been materialised by ``write()``.  Link
        # is a relative URL (``queries/<job>.sql``) so the HTML works
        # whether viewed from the report dir or sent via email.
        # 2026-06-13 -- operator asked for the full SQL inline (the
        # workflow has only 1 query per source so the table cell is
        # awkward).  We now emit an additional <details> block per job
        # AFTER the table with the full SQL in a syntax-highlighted
        # <pre> block.  Both the summary row + the inline block are
        # collapsible so the report stays scannable.
        def _sql_row(job_key: str, summary: str) -> str:
            sql_path = self.sql_files.get(job_key)
            if sql_path:
                rel = os.path.relpath(sql_path, self.output_dir or os.path.dirname(sql_path))
                rel_href = rel.replace(os.sep, "/")
                link = (
                    f"<a href=\"{e(rel_href)}\" download "
                    f"title=\"Download full SQL for job {e(job_key)}\""
                    f">download .sql</a>"
                )
            else:
                link = "<em>not written</em>"
            return (
                f"<tr><td><b>{e(job_key)}</b></td>"
                f"<td><code>{e(summary)}</code></td>"
                f"<td class='right-aligned'>{link}</td></tr>"
            )
        rows_sql = "".join(
            _sql_row(k, v) for k, v in self.sql_summary.items()
        )

        # Inline full-SQL blocks (collapsible, one per job).  Operator
        # asked: "full sql has only 1 query ... give some css" --
        # show the actual query right in the report instead of forcing
        # a click-through to a .sql download.
        full_sql_blocks = ""
        for job_key, full_text in self.sql_full.items():
            if not full_text.strip():
                continue
            full_sql_blocks += (
                f"<details class='sql-details'>"
                f"<summary>{e(job_key)} -- full SQL ({len(full_text.splitlines())} lines, "
                f"{len(full_text):,} chars)</summary>"
                f"<pre class='sql-pre'>{e(full_text)}</pre>"
                f"</details>"
            )
        # 2026-06-21 -- show creation + modification time per file so
        # operators see EXACTLY when each file was written.  Pre-fix the
        # bare "(N bytes)" line left operators guessing whether the file
        # was THIS run or a stale leftover -- log timestamps and file
        # ctime were on different formats so mental cross-reference
        # was painful.  Both timestamps now use the SAME ISO 8601 +
        # UTC-shadow shape as the run's Started / Finished cards.
        def _file_row(p: str) -> str:
            if not os.path.exists(p):
                return f"<li><code>{e(p)}</code> <em>(missing)</em></li>"
            try:
                size = os.path.getsize(p)
                ctime = self._fmt_ts(os.path.getctime(p))
                mtime = self._fmt_ts(os.path.getmtime(p))
            except OSError as _osx:
                return (
                    f"<li><code>{e(p)}</code> "
                    f"<em>(stat failed: {e(str(_osx))})</em></li>"
                )
            return (
                f"<li><code>{e(p)}</code> "
                f"<span style='color:#475569;font-size:11px;'>"
                f"({size:,} bytes &middot; created {ctime} &middot; "
                f"modified {mtime})</span></li>"
            )
        rows_files = "".join(_file_row(p) for p in self.output_files)

        status_class = {"START": "warn", "SUCCESS": "ok", "FAILED": "fail"}.get(self.status, "warn")
        # Overall completeness verdict feeds the banner too: a "SUCCESS"
        # run with a control failure still gets a warn-colored banner so
        # operator can't miss it.
        overall_class = status_class
        if self.status == "SUCCESS" and ledger and not self._overall_ok():
            overall_class = "warn"
        # 2026-06-21 -- richer failure email block.  Always shows the
        # exception + traceback; conditionally includes which step
        # failed, log file path with grep hints, pod hostname, and
        # quick-action commands operators can copy/paste.
        error_block = ""
        if self.error_message:
            failed_step_html = ""
            if self.failed_step_name:
                seq_str = f" (SEQ {self.failed_step_seq})" if self.failed_step_seq is not None else ""
                failed_step_html = (
                    f"<p><b>Failed step:</b> <code>{e(self.failed_step_name)}</code>{e(seq_str)}</p>"
                )
            pod_html = ""
            if self.pod_hostname:
                pod_html = f"<p><b>Pod:</b> <code>{e(self.pod_hostname)}</code></p>"
            log_html = ""
            if self.log_file_path:
                log_html = (
                    f"<p><b>Log file:</b> <code>{e(self.log_file_path)}</code></p>"
                    f"<details><summary>Quick-action grep commands</summary>"
                    f"<pre class='fail'># Full traceback:\n"
                    f"grep -A 50 'RUN FAILED' {e(self.log_file_path)}\n\n"
                    f"# Step transitions:\n"
                    f"grep -E 'Step.*started|Step.*completed|Step.*failed' {e(self.log_file_path)}\n\n"
                    f"# SQL executed against Starburst (with hash):\n"
                    f"grep -E 'Executing Starburst SQL|sql_hash_' {e(self.log_file_path)}\n\n"
                    f"# Trino query IDs (kill them via system.runtime.kill_query if stuck):\n"
                    f"grep -E 'qs_run:|trino query id' {e(self.log_file_path)}</pre>"
                    f"</details>"
                )
            error_block = (
                f"<h2 class='fail'>&#10060; Failure details</h2>"
                f"{failed_step_html}{pod_html}{log_html}"
                f"<h3>Exception + traceback</h3>"
                f"<pre class='fail'>{e(self.error_message)}</pre>"
            )

        report_id = e(str(self.context.get("report_id", "?")))
        business_date = e(str(self.context.get("business_date", "")))
        # Headline metrics for the top-of-page deliverable card.
        deliverable_html = ""
        if deliverable_name:
            deliverable_html = (
                f"<div class='deliverable-card'>"
                f"<div class='label'>Deliverable</div>"
                f"<div class='value'><code>{e(deliverable_name)}</code></div>"
                f"<div class='label'>Size</div>"
                f"<div class='value'>{_human_bytes(deliverable_bytes)}</div>"
                f"</div>"
            )
        records_html = ""
        if self.consolidated_total is not None or self.expected_total is not None:
            records = self.consolidated_total if self.consolidated_total is not None else self.expected_total
            records_html = (
                f"<div class='deliverable-card'>"
                f"<div class='label'>Records delivered</div>"
                f"<div class='value records'>{records:,}</div>"
                f"</div>"
            )

        return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset='utf-8'>
<title>Starburst-to-File run -- {report_id} -- {business_date} [{e(self.status)}]</title>
<style>
* {{ box-sizing: border-box; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
               "Helvetica Neue", Arial, sans-serif;
  margin: 0; padding: 24px; color: #0f172a; background: #f1f5f9;
  font-size: 14px; line-height: 1.55;
}}
.container {{ max-width: 1400px; margin: 0 auto; }}
h1 {{ font-size: 26px; margin: 0 0 8px 0; color: #0f172a; font-weight: 700;
      letter-spacing: -0.01em; }}
.subtitle {{ color: #475569; font-size: 13px; margin-bottom: 20px; }}
h2 {{
  font-size: 15px; margin: 28px 0 12px 0;
  padding-bottom: 6px; border-bottom: 2px solid #cbd5e1;
  color: #0f172a; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.04em;
}}
.banner {{
  background: white; border-radius: 10px; padding: 24px;
  margin-bottom: 16px;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.08);
  border-left: 6px solid #64748b;
}}
.banner.ok   {{ border-left-color: #16a34a; }}
.banner.warn {{ border-left-color: #d97706; }}
.banner.fail {{ border-left-color: #dc2626; }}
.status {{
  display: inline-block; padding: 6px 14px; border-radius: 999px;
  font-weight: 700; font-size: 12px; color: white;
  letter-spacing: 0.5px; vertical-align: middle;
}}
.status.ok   {{ background: #16a34a; }}
.status.warn {{ background: #d97706; }}
.status.fail {{ background: #dc2626; }}
.chips {{ margin-top: 14px; display: flex; flex-wrap: wrap; gap: 6px; }}
.chip {{
  display: inline-block; padding: 4px 10px; border-radius: 999px;
  font-size: 11px; font-weight: 700; letter-spacing: 0.04em;
  background: #e2e8f0; color: #334155; cursor: help;
}}
.chip.ok   {{ background: #dcfce7; color: #166534; }}
.chip.fail {{ background: #fee2e2; color: #991b1b; }}
.timing {{
  display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 16px; margin-top: 16px;
}}
.timing .card {{
  background: #f8fafc; padding: 12px 16px; border-radius: 8px;
  border: 1px solid #e2e8f0;
}}
.timing .card .label, .deliverable-card .label {{
  font-size: 10px; color: #475569; text-transform: uppercase;
  letter-spacing: 0.06em; font-weight: 700;
}}
.timing .card .value, .deliverable-card .value {{
  font-size: 18px; color: #0f172a; font-weight: 700; margin-top: 4px;
  font-variant-numeric: tabular-nums; word-break: break-all;
}}
.timing .card .value.duration {{ color: #2563eb; font-size: 22px; }}
.deliverable-row {{
  display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px; margin-top: 16px;
}}
.deliverable-card {{
  background: #eff6ff; padding: 12px 16px; border-radius: 8px;
  border: 1px solid #bfdbfe;
}}
.deliverable-card .value.records {{ color: #1d4ed8; font-size: 26px; }}
.section {{
  background: white; border-radius: 10px; padding: 20px 24px;
  margin-bottom: 16px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
}}
table {{ border-collapse: collapse; width: 100%; margin: 0; }}
th, td {{
  padding: 9px 12px; text-align: left;
  border-bottom: 1px solid #e2e8f0; vertical-align: top;
}}
th {{
  background: #f8fafc; font-weight: 700; color: #334155;
  font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em;
}}
tr:last-child td {{ border-bottom: none; }}
code {{
  font-family: "SF Mono", "Consolas", "Monaco", "Cascadia Mono", monospace;
  font-size: 12px; word-break: break-all; color: #334155;
  background: #f1f5f9; padding: 2px 6px; border-radius: 4px;
}}
td.ok   {{ color: #15803d; font-weight: 700; }}
td.fail {{ color: #b91c1c; font-weight: 700; }}
tr.fail {{ background: #fef2f2; }}
tr.fail td {{ color: #991b1b; }}
tr.warn {{ background: #fffbeb; }}
tr.queue-pressure {{ background: #fef9c3; }}
tr.queue-pressure td {{ color: #854d0e; }}
.control-tag {{
  display: inline-block; padding: 2px 8px; border-radius: 4px;
  background: #1e293b; color: white; font-weight: 700;
  font-size: 11px; letter-spacing: 0.04em; margin-right: 6px;
  font-family: "SF Mono", Consolas, Monaco, monospace;
}}
.control-why {{
  margin-top: 4px; color: #64748b; font-size: 12px; font-weight: 400;
  font-style: italic;
}}
pre.fail {{
  background: #fef2f2; color: #991b1b; padding: 16px;
  border-radius: 8px; overflow-x: auto;
  border-left: 4px solid #dc2626;
  font-family: "SF Mono", Consolas, monospace; font-size: 12px;
}}
pre.sql-pre {{
  background: #0f172a; color: #e2e8f0; padding: 14px 16px;
  border-radius: 8px; overflow-x: auto;
  font-family: "SF Mono", Consolas, Monaco, monospace; font-size: 12px;
  line-height: 1.5; margin: 8px 0 4px 0;
  white-space: pre; max-height: 480px;
}}
details.sql-details {{
  margin: 12px 0 4px 0; padding: 8px 0 0 0;
}}
details.sql-details > summary {{
  cursor: pointer; font-weight: 600; color: #1e293b; padding: 4px 0;
  list-style: none; user-select: none;
}}
details.sql-details > summary::before {{
  content: "\\25b8  "; font-size: 11px; color: #94a3b8;
}}
details.sql-details[open] > summary::before {{ content: "\\25be  "; }}
ul {{ font-family: "SF Mono", Consolas, monospace; font-size: 13px;
      padding-left: 24px; }}
ul li {{ margin: 4px 0; }}
.right-aligned {{ text-align: right; font-variant-numeric: tabular-nums; }}
@media print {{
  body {{ background: white; padding: 0; font-size: 11px; }}
  .section, .banner {{ box-shadow: none; border: 1px solid #cbd5e1;
                       break-inside: avoid; page-break-inside: avoid; }}
  .chip {{ border: 1px solid currentColor; }}
  details.sql-details {{ break-inside: avoid; }}
  pre.sql-pre {{ background: #f1f5f9; color: #0f172a;
                 border: 1px solid #cbd5e1; }}
}}
@media (max-width: 720px) {{
  body {{ padding: 12px; font-size: 13px; }}
  h1 {{ font-size: 20px; }}
  .banner, .section {{ padding: 16px; }}
}}
</style></head>
<body>
<div class="container">

<div class="banner {overall_class}">
  <h1>Starburst &rarr; File extract
    <span class='status {status_class}'>{e(self.status)}</span></h1>
  <div class="subtitle">
    Report <strong>{report_id}</strong>
    &middot; business_date <strong>{business_date}</strong>
    &middot; run_id <strong>{e(str(self.context.get('run_id', '?')))}</strong>
    &middot; dag_id <strong>{e(str(self.context.get('dag_id', '?')))}</strong>
  </div>
  <div class="chips">{verdict_chips or '<span class="chip">no controls recorded yet</span>'}</div>
  <div class="deliverable-row">{deliverable_html}{records_html}</div>
  <div class="timing">
    <div class="card">
      <div class="label">Started</div>
      <div class="value">{e(self._local_time(self.started_at))}</div>
    </div>
    <div class="card">
      <div class="label">Finished</div>
      <div class="value">{e(self._local_time(self.finished_at))}</div>
    </div>
    <div class="card">
      <div class="label">Total time</div>
      <div class="value duration">{e(self._duration_human())}</div>
    </div>
  </div>
</div>

<div class="section">
<h2>Context</h2>
<table>{rows_context}</table>
</div>

<div class="section">
<h2>Runtime knobs</h2>
<table>{rows_knobs}</table>
</div>

<div class="section">
<h2>Completeness controls</h2>
<table>
  <tr><th>Control</th><th>Verdict</th><th>Detail</th></tr>
  {ledger_rows or '<tr><td colspan="3"><em>No counts recorded yet.</em></td></tr>'}
</table>
</div>

<div class="section">
<h2>Job summary</h2>
<table>
  <tr><th>Report ID</th><th>Source</th><th>Status</th>
      <th class="right-aligned" title="Source row count (G1) for this datasource">Source rows</th>
      <th class="right-aligned" title="Rows extracted (chunk-writer actuals) for this datasource">Downloaded</th>
      <th class="right-aligned" title="Per-source consolidated file row count">File rows</th>
      <th class="right-aligned">Chunks</th><th>File</th></tr>
  {rows_jobs or '<tr><td colspan="8"><em>No jobs recorded.</em></td></tr>'}
</table>
</div>

<div class="section">
<h2>Per-chunk results</h2>
<table>
  <tr><th>Job</th><th>Source</th><th>#</th><th>Partition value</th>
      <th class="right-aligned">Expected</th>
      <th class="right-aligned">Actual</th>
      <th class="right-aligned">Attempts</th>
      <th class="right-aligned">Duration</th>
      <th class="right-aligned" title="Time waiting in Trino coordinator queue + plan phase BEFORE first row arrived. Large value = cluster is busy / queueing.">Queue wait</th>
      <th class="right-aligned" title="Active row-streaming time AFTER first row. queue_wait > stream means Trino queued you.">Stream</th>
      <th>File</th></tr>
  {rows_chunks or '<tr><td colspan="11"><em>No chunks recorded.</em></td></tr>'}
</table>
</div>

<div class="section">
<h2>SQL executed</h2>
<table>
  <tr><th>Job</th><th>First line</th><th class='right-aligned'>Download</th></tr>
  {rows_sql or '<tr><td colspan="3"><em>None recorded.</em></td></tr>'}
</table>
{full_sql_blocks or ''}
</div>

<div class="section">
<h2>Output files</h2>
<ul>{rows_files or '<li><em>None.</em></li>'}</ul>
</div>

{error_block}

</div>
</body></html>"""

    def to_text(self) -> str:
        """Plain-text rendering -- doubles as the email fallback body so
        operators on mail clients that block HTML still get every G1-G5
        verdict, the deliverable name + size, and the file list."""
        lines = []
        ledger = self._ledger_entries()
        # ── TL;DR at the very top -- what operator wants first.
        deliverable_name = ""
        deliverable_size = 0
        for p in self.output_files:
            if p and os.path.exists(p) and p.lower().endswith(
                (".dat", ".csv", ".gz", ".zip", ".tar")
            ):
                deliverable_name = os.path.basename(p)
                try:
                    deliverable_size = os.path.getsize(p)
                except OSError:
                    deliverable_size = 0
                break

        lines.append("=" * 72)
        lines.append(f"Starburst-to-File run -- {self.status}")
        lines.append("=" * 72)
        records = self.consolidated_total if self.consolidated_total is not None else self.expected_total
        if records is not None:
            lines.append(f"Records delivered: {records:,}")
        if deliverable_name:
            lines.append(f"Deliverable:       {deliverable_name} ({_human_bytes(deliverable_size)})")
        lines.append(f"Started:           {self.started_at.isoformat()}")
        if self.finished_at:
            lines.append(f"Finished:          {self.finished_at.isoformat()}")
            lines.append(f"Duration:          {self._duration_str()} ({self._duration_human()})")

        # ── Completeness controls summary upfront (one line per control).
        if ledger:
            lines.append("")
            lines.append("COMPLETENESS CONTROLS:")
            for entry in ledger:
                verdict = "OK  " if entry["ok"] else "FAIL"
                lines.append(
                    f"  [{verdict}] {entry['display']} {entry['label']}: {entry['detail']}"
                )

        lines.append("")
        lines.append("CONTEXT:")
        for k, v in self.context.items():
            lines.append(f"  {k}: {v}")
        if self.runtime_knobs:
            lines.append("")
            lines.append("RUNTIME KNOBS:")
            for k, v in self.runtime_knobs.items():
                lines.append(f"  {k}: {v}")
        if self.job_results:
            lines.append("")
            lines.append("JOBS:")
            for j in self.job_results:
                lines.append(
                    f"  report_id={j.get('report_id')} src={j.get('datasource')} "
                    f"status={j.get('status')} records={j.get('records', 0):,} "
                    f"chunks={j.get('chunks', 0)} file={j.get('file_path', '')}"
                )
        if self.chunk_results:
            lines.append("")
            lines.append("CHUNKS:")
            for c in self.chunk_results:
                lines.append(
                    f"  job={c.get('job_id')} #{c.get('partition_index')} "
                    f"value={c.get('partition_value')} expected={c.get('expected')} "
                    f"actual={c.get('actual')} attempts={c.get('attempts', 1)} "
                    f"-> {c.get('file_path')}"
                )
        if self.output_files:
            lines.append("")
            lines.append("OUTPUT FILES:")
            for p in self.output_files:
                size = _human_bytes(os.path.getsize(p)) if os.path.exists(p) else "MISSING"
                lines.append(f"  {p}  ({size})")
        if self.sql_summary:
            lines.append("")
            lines.append("SQL (first line per job):")
            for k, v in self.sql_summary.items():
                lines.append(f"  {k}: {v}")
        if self.error_message:
            lines.append("")
            lines.append("ERROR:")
            lines.append(self.error_message)
        return "\n".join(lines)

    # -- Persistence ----------------------------------------------------

    # -- Deliverable-derived report filename --------------------------

    def _deliverable_basename(self) -> str:
        """Return the canonical deliverable basename (NO extension, NO
        ``_CLOUD``/``_ONPREM`` per-source marker) for use in the HTML /
        TXT filename when the caller didn't override it.

        2026-06-13 -- operator asked for a per-run unique report
        filename so successive runs in the same output_dir don't
        overwrite each other.

        2026-06-17 -- operator asked that the report name MATCH the
        deliverable AND carry ``business_date`` so the same filename
        is used for the START-of-run write AND the FINAL write (no
        orphan "in progress" report).  Polling-row ``FILE_NAME`` is
        threaded via ``set_context(file_name=...)`` and used as a
        primary fallback when ``output_files`` is still empty (at
        start of run).  business_date is appended when the chosen
        basename doesn't already carry it.

        Order of preference:
          1. ``output_files[0]``  (the consolidated / compressed
                                   deliverable registered by the steps).
          2. ``context['consolidated_file']``.
          3. ``context['compressed_file']``.
          4. ``context['file_name']``  (polling-row FILE_NAME hint -- the
                                       start-of-run write uses this so
                                       the first + final write paths
                                       agree).
          5. Empty -> caller falls back to legacy ``run_report.html``.

        When the chosen basename does NOT already contain the
        ``business_date`` (case-insensitive substring check), the date
        is appended as ``<base>_<YYYY-MM-DD>`` so successive
        business_date runs against the same FILE_NAME template don't
        collide.
        """
        # 2026-06-20 -- FILENAME PRIORITY (operator-tunable).
        #
        #   "polling_row" (default, new behaviour):
        #     polling-row FILE_NAME hint -> output_files[0] ->
        #     consolidated_file -> compressed_file.  Start-of-run and
        #     post-step writes resolve to the SAME path so no orphan
        #     "in progress" report is left behind.
        #
        #   "output_files" (legacy):
        #     output_files[0] -> consolidated_file -> compressed_file
        #     -> FILE_NAME hint.  Pre-2026-06-20 behaviour preserved
        #     for operators who relied on the consolidated basename
        #     deciding the report name.
        #
        # Operator picks via the polling row FILENAME_PRIORITY column or
        # oracle_config.yaml's run_report.filename_priority.  Standalones
        # thread it into the FileRunReport constructor.
        if self.filename_priority == "output_files":
            candidate = ""
            if self.output_files:
                candidate = self.output_files[0]
            if not candidate:
                candidate = self.context.get("consolidated_file") or ""
            if not candidate:
                candidate = self.context.get("compressed_file") or ""
            if not candidate:
                candidate = self.context.get("file_name") or ""
        else:
            candidate = self.context.get("file_name") or ""
            if not candidate and self.output_files:
                candidate = self.output_files[0]
            if not candidate:
                candidate = self.context.get("consolidated_file") or ""
            if not candidate:
                candidate = self.context.get("compressed_file") or ""
        if not candidate:
            return ""
        base = os.path.basename(str(candidate))
        # Strip ONE extension (.dat / .gz / .zip / .ctl ...).
        base, _ = os.path.splitext(base)
        # If still has .dat after .gz strip, strip again so .dat.gz ->
        # base, not base.dat.  Mirrors the CTL filename derivation.
        if base.endswith(".dat") or base.endswith(".csv") or base.endswith(".tar"):
            base, _ = os.path.splitext(base)
        # Strip per-source markers so the report name is canonical
        # across CLOUD/ONPREM dispatches.
        base = base.replace("_CLOUD", "").replace("_ONPREM", "")
        # 2026-06-17 -- append business_date when the basename doesn't
        # already carry it.  Avoids collisions across successive
        # business_date runs that share the same FILE_NAME template.
        bdate = str(self.context.get("business_date") or "").strip()
        if bdate and bdate.lower() not in base.lower():
            # Normalise "DD-MM-YYYY" / "DD/MM/YYYY" forms to the
            # filename-safe "YYYY-MM-DD" so the report name sorts
            # naturally in directory listings.
            normalised = bdate.replace("/", "-")
            base = f"{base}_{normalised}"
        return base

    def _resolve_report_filename(self, configured: str, default: str, suffix: str) -> str:
        """Pick the actual HTML/TXT filename.

        Precedence:
          1. ``configured`` is set AND not the module default -> use it
             verbatim (operator override wins).
          2. ``configured == "" AND default == ""`` -> return "" to
             SKIP this artefact entirely (2026-06-22: .txt is now
             opt-in by default).
          3. Otherwise, if a deliverable basename is available, derive
             ``<basename>.report<suffix>`` so the report is uniquely
             named per run and survives multiple runs in the same
             output_dir.
          4. Otherwise, fall back to the module default
             (``run_report.html`` for HTML).
        """
        # Operator explicitly overrode -> respect it.
        if configured and configured != default:
            return configured
        # 2026-06-22 -- both empty = explicit opt-out (e.g., .txt
        # disabled by default per user request).  Return "" so the
        # write loop's `if not filename: continue` skips this artefact.
        if not configured and not default:
            return ""
        # Default-or-empty + deliverable available -> derive.
        deliverable = self._deliverable_basename()
        if deliverable:
            return f"{deliverable}.report{suffix}"
        # Last resort.
        return configured or default

    def write(self) -> Dict[str, str]:
        """Write run_report.html + run_report.txt + per-job .sql files
        to ``output_dir``.

        Per-job SQL files land in ``<output_dir>/queries/<job_id>.sql``
        so the end-user can click the download link in the HTML report.
        Job IDs are sanitised to a safe-on-disk filename.  Idempotent:
        re-running rewrites all artefacts.

        2026-06-13 -- HTML / TXT filenames default to
        ``<deliverable-basename>.report.html/.txt`` so successive runs
        in the same output_dir don't overwrite each other.  Operator
        can still pin explicit filenames via the constructor or
        polling-row overrides.

        Errors logged but never raised -- the report is a debug aid,
        not critical path.
        """
        paths: Dict[str, str] = {}
        if not self.output_dir:
            return paths
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as exc:
            if self.logger:
                self.logger.warning("Could not create report dir %s: %s", self.output_dir, exc)
            return paths

        # ── 1. Per-job .sql files BEFORE the HTML render so the
        # download-link table can reference them.  Subdir name + file
        # extension come from operator config (DB row / job JSON /
        # oracle_config.yaml) — fall back to the module defaults only
        # when the caller didn't provide either.
        if self.sql_full and self.queries_subdir:
            queries_dir = os.path.join(self.output_dir, self.queries_subdir)
            try:
                os.makedirs(queries_dir, exist_ok=True)
            except OSError as exc:
                if self.logger:
                    self.logger.warning(
                        "Could not create queries dir %s: %s", queries_dir, exc,
                    )
                queries_dir = None
            if queries_dir:
                self.sql_files = {}
                for job_id, sql_text in self.sql_full.items():
                    safe = _safe_filename(job_id)
                    sql_path = os.path.join(
                        queries_dir, f"{safe}{self.sql_file_extension}",
                    )
                    try:
                        with open(sql_path, "w", encoding="utf-8") as f:
                            f.write(sql_text)
                        self.sql_files[job_id] = sql_path
                        # 2026-06-21 audit bug #12: defeat NTFS tunneling
                        # so .sql files' ctime matches THIS run, not the
                        # first-ever creation.  No-op on POSIX.
                        try:
                            from steps.file.run_state import (
                                force_creation_time_now as _fct,
                            )
                            _fct(sql_path, logger=self.logger)
                        except Exception:
                            pass
                    except OSError as exc:
                        if self.logger:
                            self.logger.warning(
                                "Could not write %s: %s", sql_path, exc,
                            )

        # ── 2. HTML + TXT.  Filenames come from operator config when
        # explicitly overridden; otherwise derive from the deliverable
        # so successive runs don't overwrite each other.  The
        # to_html() pass reads self.sql_files set above so the download
        # links land in the right relative place regardless of subdir.
        resolved_html = self._resolve_report_filename(
            self.report_filename_html, _DEFAULT_REPORT_HTML, ".html",
        )
        resolved_txt = self._resolve_report_filename(
            self.report_filename_txt, _DEFAULT_REPORT_TXT, ".txt",
        )

        # 2026-06-17 -- per-write resolved paths so we can clean up
        # orphans below.  Built BEFORE the write so the cleanup pass
        # has a target list to compare against.
        current_paths = [
            os.path.join(self.output_dir, resolved_html) if resolved_html else None,
            os.path.join(self.output_dir, resolved_txt)  if resolved_txt  else None,
        ]
        current_paths = [p for p in current_paths if p]

        # 2026-06-17 -- orphan cleanup.  The first write() at run start
        # resolves to run_report.html / .txt (no deliverable known yet).
        # Once steps populate output_files, _resolve_report_filename
        # switches to <deliverable>.report.html / .txt -- a DIFFERENT
        # path.  Without this pass, the first-write file is orphaned
        # and forever shows status "in progress" because the final
        # status writes elsewhere.  Back up (or delete per the operator
        # flag) every prior-write path that's no longer in current_paths.
        for prior in self._last_written_paths:
            if not prior or prior in current_paths or not os.path.exists(prior):
                continue
            try:
                from steps.file.run_state import backup_if_exists as _bif
                _bif(
                    prior,
                    backup_ts=self.backup_ts or None,
                    mode=self.prior_output_mode,
                    logger=self.logger,
                )
                if self.logger:
                    self.logger.info(
                        "Cleaned up stale start-of-run report (renamed to %s mode): %s",
                        self.prior_output_mode, prior,
                    )
            except Exception as exc:  # noqa: BLE001 -- last-resort cleanup
                # Fall back to outright delete -- the file is stale
                # by definition; don't let a cleanup failure leave the
                # orphan in place.
                try:
                    os.remove(prior)
                    if self.logger:
                        self.logger.info(
                            "Removed stale start-of-run report: %s (%s)",
                            prior, exc,
                        )
                except OSError:
                    pass

        for label, filename, content in (
            ("html", resolved_html, self.to_html()),
            ("txt",  resolved_txt,  self.to_text()),
        ):
            if not filename:
                continue  # opt out: empty filename skips this artefact
            path = os.path.join(self.output_dir, filename)
            # 2026-06-13 -- back up (or delete) any prior-run report at
            # this path before we overwrite it.  Inline import keeps
            # the cold-path helper out of the module load surface.
            # 2026-06-20 -- ONLY backup on the FIRST encounter of this
            # path.  Successive writes within the same run overwrite
            # directly.  Without this gate every step's write() call
            # cloned the prior-write file into backup_<ts>/ and the
            # operator drowned in stale copies (5+ per run).
            if path not in self._paths_written_this_run:
                try:
                    from steps.file.run_state import backup_if_exists as _bif
                    _bif(
                        path,
                        backup_ts=self.backup_ts or None,
                        mode=self.prior_output_mode,
                        logger=self.logger,
                    )
                except ImportError:
                    pass
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                # 2026-06-21 audit bug #12: defeat NTFS tunneling so
                # result.html + run_report.txt show TODAY's ctime
                # (matches the .dat file's ctime) instead of the
                # first-ever-creation ctime.  Without this, operators
                # opening output_dir see .dat created today but
                # result.html "created last month" -- jarring.
                # No-op on POSIX.
                try:
                    from steps.file.run_state import (
                        force_creation_time_now as _fct,
                    )
                    _fct(path, logger=self.logger)
                except Exception:
                    pass
                paths[label] = path
                self._paths_written_this_run.add(path)
                if self.logger:
                    self.logger.info(
                        "Wrote %s (%s) to %s (%d bytes)",
                        label, filename, path, os.path.getsize(path),
                    )
            except OSError as exc:
                if self.logger:
                    self.logger.warning("Could not write %s (%s): %s",
                                          label, filename, exc)

        # 2026-06-17 -- remember what we wrote so the NEXT write() can
        # detect orphans (see orphan cleanup pass above).
        self._last_written_paths = list(current_paths)
        return paths

    # -- Email ----------------------------------------------------------

    def send_email(self, email_cfg: Dict[str, Any]) -> bool:
        """Send the report as an HTML email.

        Returns True if mail sent, False if skipped (flag off or config
        missing).  Errors logged at WARN — never raises (a mail failure
        must not kill the pipeline).
        """
        if not _truthy(email_cfg.get("send_email")):
            if self.logger:
                self.logger.info("send_email=False -- skipping %s notification", self.status)
            return False
        smtp_host = email_cfg.get("smtp_host", "")
        email_from = email_cfg.get("email_from", "")
        email_to = email_cfg.get("email_to", "")
        if not smtp_host or not email_from or not email_to:
            if self.logger:
                self.logger.warning(
                    "send_email=True but smtp_host / email_from / email_to "
                    "missing -- skipping email"
                )
            return False
        if isinstance(email_to, str):
            email_to = [t.strip() for t in email_to.split(",") if t.strip()]

        report_id = self.context.get("report_id", "?")
        business_date = self.context.get("business_date", "")
        run_id = self.context.get("run_id", "")
        # 2026-06-13 -- subject now leads with filename + record count
        # so the operator can triage from the inbox without opening the
        # mail.  Falls back to the pre-2026 shape when nothing's
        # delivered yet (START / early-FAILED).
        deliverable_base = self._deliverable_basename()
        records = self.consolidated_total if self.consolidated_total is not None else self.expected_total
        headline_parts = [f"[Starburst-to-File] {self.status}"]
        if deliverable_base:
            headline_parts.append(deliverable_base)
        if records is not None:
            headline_parts.append(f"{records:,} rows")
        headline_parts.append(f"report {report_id}")
        headline_parts.append(f"{business_date}")
        if run_id:
            headline_parts.append(f"run {run_id}")
        default_subject = " -- ".join(headline_parts)
        subject = email_cfg.get("email_subject") or default_subject

        # 2026-06-22 -- explicit Message-ID + Date so operators can grep
        # corporate mail relay logs by message-id when emails go missing.
        import uuid
        from email.utils import formatdate, make_msgid
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = email_from
        msg["To"] = ", ".join(email_to)
        msg["Date"] = formatdate(localtime=True)
        msg_id = make_msgid(domain="qs-etl")
        msg["Message-ID"] = msg_id
        msg.set_content(self.to_text())  # plain-text fallback
        msg.add_alternative(self.to_html(), subtype="html")

        smtp_port = int(email_cfg.get("smtp_port", 25))
        html_size = len(self.to_html())
        text_size = len(self.to_text())

        # 2026-06-22 -- log everything we KNOW about the send BEFORE
        # invoking smtplib, so a hang / silent drop leaves audit trail.
        if self.logger:
            self.logger.info(
                "Email PRE-SEND: host=%s:%d from=%s to=%s subject=%r "
                "msg_id=%s html_bytes=%d text_bytes=%d tls=%s auth=%s",
                smtp_host, smtp_port, email_from, email_to, subject,
                msg_id, html_size, text_size,
                bool(_truthy(email_cfg.get("smtp_use_tls"))),
                bool(email_cfg.get("smtp_user")),
            )

        try:
            with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as s:
                # 2026-06-22 -- log SMTP server greeting + EHLO response.
                # Proves we're talking to the EXPECTED relay (not a
                # firewall-injected fake) + surfaces server capabilities
                # so operator can debug TLS / AUTH issues.
                greeting = s.docmd("NOOP")
                if self.logger:
                    self.logger.info(
                        "SMTP NOOP response from %s: %s", smtp_host, greeting,
                    )
                ehlo_code, ehlo_response = s.ehlo()
                if self.logger:
                    ehlo_decoded = (
                        ehlo_response.decode("utf-8", errors="replace")
                        if isinstance(ehlo_response, bytes) else str(ehlo_response)
                    )
                    self.logger.info(
                        "SMTP EHLO from %s (code=%d): %s",
                        smtp_host, ehlo_code,
                        ehlo_decoded.replace("\n", " | "),
                    )

                if _truthy(email_cfg.get("smtp_use_tls")):
                    s.starttls()
                    s.ehlo()  # RFC requires re-EHLO after STARTTLS
                    if self.logger:
                        self.logger.info("SMTP STARTTLS OK with %s", smtp_host)

                if email_cfg.get("smtp_user"):
                    s.login(email_cfg["smtp_user"], email_cfg.get("smtp_password", ""))
                    if self.logger:
                        self.logger.info(
                            "SMTP AUTH OK as user=%s", email_cfg["smtp_user"],
                        )

                # 2026-06-22 -- send_message() returns a dict of
                # {refused_recipient: (code, msg)}.  Empty dict = ALL
                # recipients accepted at SMTP level.  Pre-fix, this
                # return value was discarded -- partial refusals went
                # silent and operators saw "Sent" while half the
                # recipients never got it.
                refused = s.send_message(msg)

                if refused:
                    if self.logger:
                        self.logger.error(
                            "SMTP refused %d of %d recipients (msg_id=%s): %s. "
                            "Other recipients MAY have received the email; "
                            "check with mail admin.",
                            len(refused), len(email_to), msg_id, refused,
                        )
                    # Partial failure: some recipients accepted, some refused.
                    # Return True since SOME went out, but loud WARN above.
                    return True

            # All recipients accepted at SMTP level.
            if self.logger:
                self.logger.info(
                    "Email ACCEPTED by SMTP relay %s for %d recipient(s) "
                    "(msg_id=%s).  Note: SMTP acceptance != delivery.  "
                    "If not in inbox within 5min: (1) check spam/junk, "
                    "(2) grep mail relay logs for msg_id=%s, (3) verify "
                    "From address %s isn't rejected by DMARC/SPF.",
                    smtp_host, len(email_to), msg_id, msg_id, email_from,
                )
            return True
        except smtplib.SMTPRecipientsRefused as exc:
            # ALL recipients refused -- send_message would raise this.
            if self.logger:
                self.logger.error(
                    "SMTP refused ALL recipients (msg_id=%s): %s. "
                    "Common causes: invalid email_to address, From "
                    "rejected by DMARC, IP blocklisted by relay.",
                    msg_id, exc.recipients,
                )
            return False
        except smtplib.SMTPAuthenticationError as exc:
            if self.logger:
                self.logger.error(
                    "SMTP AUTH failed for user=%s (msg_id=%s): %s. "
                    "Check smtp_user / smtp_password OR set smtp_use_tls=true "
                    "if relay requires STARTTLS before AUTH.",
                    email_cfg.get("smtp_user"), msg_id, exc,
                )
            return False
        except smtplib.SMTPConnectError as exc:
            if self.logger:
                self.logger.error(
                    "SMTP connect failed to %s:%d (msg_id=%s): %s. "
                    "Check pod has network access to the relay + the "
                    "relay accepts connections on this port (try 587 "
                    "for submission with TLS, 25 for relay).",
                    smtp_host, smtp_port, msg_id, exc,
                )
            return False
        except (TimeoutError, OSError) as exc:
            if self.logger:
                self.logger.error(
                    "SMTP timeout / network error for %s:%d (msg_id=%s): %s. "
                    "Mail relay unreachable or blocking the pod's IP.",
                    smtp_host, smtp_port, msg_id, exc,
                )
            return False
        except Exception as exc:
            if self.logger:
                self.logger.warning(
                    "Email send FAILED (msg_id=%s, %s) -- run continues, "
                    "report still on disk at %s",
                    msg_id, exc, self.output_dir,
                )
            return False


def _truthy(v: Any) -> bool:
    """Treat the usual Oracle/YAML string values as bool."""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    s = str(v).strip().upper()
    return s in {"TRUE", "1", "YES", "Y", "T"}


def _human_bytes(n: int) -> str:
    """Render a byte count as KB/MB/GB.  Mirrors compress_file._human_bytes
    so the run report and the compression log line speak the same units."""
    if n is None:
        return "?"
    try:
        n = float(n)
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _safe_filename(value: str) -> str:
    """Sanitise a job_id into a filename-safe token.

    Keeps alphanumerics + ``-`` + ``_``; collapses everything else to
    ``_``; truncates to 80 chars; empty input becomes ``unknown``.
    """
    import re as _re
    s = _re.sub(r"[^A-Za-z0-9_\-]+", "_", str(value or ""))
    s = s.strip("_") or "unknown"
    return s[:80]
