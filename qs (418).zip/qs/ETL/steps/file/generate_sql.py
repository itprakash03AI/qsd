"""GenerateSQL -- DB-driven SQL composition for the file workflow.

Production logic (from Prd_generate_sql.py) preserved end-to-end.
Cleaned 2026-06-21:
  * CentralizedLogger removed -- replaced with the standard file_flow
    ``_setup_logging`` pattern so every log line lands in the run's
    pinned log file (single-file-per-execution contract).
  * task["_run_report"] integration -- each generated SQL pushed into
    FileRunReport.add_sql_summary so result.html "SQL executed"
    table populates per data-source.
  * task["_run_artifacts"] integration -- output JSON registered with
    RunArtifacts so cleanup-on-failure tracks it.
  * Atomic JSON write -- tmp + os.replace so a mid-write crash
    leaves the OLD JSON intact (downstream parse never sees half-
    written content).
  * All Phase 152 placeholder passthrough -- when the polling row
    carries CHECKSUM_COLUMNS / PARTITION_CONFIG, they're written
    into each job entry so the extract step picks them up.

WHAT THIS STEP DOES (unchanged from prod):
  1. Reads 7 Oracle metadata tables to compose the SQL per data source:
       OTG_AIRFLOW_DAG_RUN              -- run_date
       OTG_REPORT_CONFIG                -- file_format / name / delim / ...
       OTG_REPORT_DATA_SOURCE_MAPPING   -- which data sources to extract
       OTG_DATA_SOURCE_DETAILS          -- server_name + port per source
       OTG_DATA_SOURCE_TABLE_MAPPING    -- table_name + table_alias
       OTG_REPORT_COLUMN_MAPPING        -- SELECT cols + GROUP BY auto-detect
       OTG_REPORT_PARAM_CONFIG          -- JOIN / WHERE / FROM_TABLE params
       OTG_CONTROL_TEMPLATE             -- CTL file format
  2. Resolves ``{{table_alias}}`` and ``{from_table} <alias>`` patterns
     in WHEREs / JOINs using the data source's table-alias mapping.
  3. Substitutes ``{business_date}``, ``{system_entity}``,
     ``${COB_PREV_EOQ(YYYYMMDD)}``, ``{run_date}``,
     ``{me_business_date}``, ``{file_name}`` in WHERE clauses + file
     names + CTL templates.
  4. Writes ``{"jobs": [...]}`` to ``task["sql_query_path"]`` with
     ONE entry per data source.  Each entry has: generated_sql,
     server_name, port, output_file_name, output_file_location,
     ctl_file_format, zip_format, etc.
  5. Mutates task[generated_sql] (first datasource) + task[
     generated_sql_<datasource_name>] (per-datasource) for back-compat
     with steps that read from task directly.

DOWNSTREAM CONTRACT (what starburst_file_base.py reads):
  * jobs[i]["generated_sql"]               -- the composed SELECT
  * jobs[i]["report_id"]                   -- per-job key
  * jobs[i]["server_name"], jobs[i]["port"]
  * jobs[i]["output_file_name"], ..."output_file_location",
    ..."output_file_delimiter"
  * jobs[i]["ctl_file_format"], jobs[i]["zip_format"]
  * jobs[i]["checksum_columns"]            -- Phase 152 (optional)
  * jobs[i]["partition_config"]            -- Phase 152 (optional)
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import oracledb
import yaml

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import RunArtifacts, get_or_create_artifacts


# Optional dialect-aware SQL parser.  Used for the post-compose
# validation pass (catches a malformed OTG_REPORT_PARAM_CONFIG row
# at compose time instead of at Trino-execute time).  Optional
# everywhere -- if sqlglot isn't installed, the validation is a no-op
# (logs a single DEBUG line per run).  Listed under WORKFLOW_
# REQUIREMENTS["file"]["optional"] in preflight.py.
try:
    import sqlglot
    from sqlglot.errors import ParseError as _SqlglotParseError
    _SQLGLOT_AVAILABLE = True
except ImportError:  # pragma: no cover
    sqlglot = None  # type: ignore[assignment]
    _SqlglotParseError = Exception  # type: ignore[assignment,misc]
    _SQLGLOT_AVAILABLE = False


# 2026-06-21 -- module-level compile.  Previously this was inlined in
# _replace_table_placeholders, recompiling on every call.  Pure
# hygiene; perf delta is microseconds but the pattern lives at the
# module level so it's reviewable + grep-able.
_FROM_TABLE_RE = re.compile(r"\{from_table\}\s+(\w+)")


def _truthy(v: Any) -> bool:
    """Coerce a polling-row cell to bool.  Accepts True / 1 / "1" /
    "true" / "TRUE" / "yes" / "Y".  Everything else (including None,
    "", "0", "false", "no", "N") is False."""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    return str(v).strip().lower() in {"1", "true", "yes", "y", "t"}


class GenerateSQL(BaseStep):
    """Step to generate SQL query from Oracle metadata + store JSON in task path."""

    LOG_PREFIX = "generate_sql"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Initialize database configuration from config
        self.db_config = self.load_oracle_config()
        # Phase 152 fail-loud opt-ins.  Both default to False so a
        # missing OTG_AIRFLOW_DAG_RUN row OR a per-data-source failure
        # raises instead of silently fabricating run_date / emitting a
        # partial jobs[] JSON.  Flipped per-task via the polling row.
        self._allow_missing_run_date: bool = False
        self._allow_partial_datasources: bool = False
        # SQL optimization is ON by default (free perf win for both
        # Starburst + S3+Iceberg).  Opt-OUT via polling row when an
        # operator needs the raw composed SQL for debugging.
        self._disable_sql_optimization: bool = False
        # Pushdown_predicates is OPT-IN (2026-06-21 audit found it can
        # rewrite WHERE clauses with outer-alias references into invalid
        # subquery-scope references on certain SQL shapes).  Operators
        # enable via polling row when SQL is known-safe.
        self._enable_sql_pushdown_optimization: bool = False
        # Per-data-source optimization info -- populated during
        # compose, surfaced to FileRunReport runtime_knobs at the end
        # of _execute_step.
        self._opt_info_by_source: Dict[str, Dict[str, Any]] = {}
        # Currently-executing task dict.  Set in _execute_step so the
        # fetch path can populate the cross-step metadata cache without
        # threading task through every fetcher signature.
        self._current_task: Optional[Dict] = None

    # ── Logger setup (file_flow pattern, replaces CentralizedLogger) ──────

    def _setup_logging(self, task: Dict) -> None:
        """Pin to the run-log file from task['log_file'] so this step's
        output lands in the SAME file as every other step's output for
        this run (single-file-per-execution contract).  No hardcoded
        /usr/local/spark/nfs/.../generate_sql.log path."""
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            # NO /tmp fallback -- pods have tiny ephemeral storage; logs
            # MUST land on the configured NFS path.  Missing log_config
            # is a deployment break -- fail loudly via WARN.
            from log_config import get_log_dir as _ld
            base = _ld()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(
                base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log",
            )
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as exc:
            self.logger.warning(
                "Cannot attach file handler %s (%s) -- console only",
                log_path, exc,
            )

    # ── Oracle config loader (unchanged from production) ──────────────────

    def load_oracle_config(
        self,
        config_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Load the ``oracle`` section from oracle_config.yaml.

        2026-06-21 audit bug #11: original Prd_generate_sql.py hardcoded
        ``/usr/local/spark/pvc/code/configs/oracle_config.yaml`` as the
        default path -- works in the prod Spark pod (path is mounted),
        BROKEN on every other env (Windows dev, CI, Airflow pods that
        don't mount /usr/local/spark, local pytest, etc.).

        Fix: delegate to the canonical ``oracle_config_loader`` which
        already handles prod -> local fallback (same pattern
        file_standalone.py uses).  Explicit ``config_path`` argument
        still honoured for back-compat with any direct callers.
        """
        if config_path is not None:
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            return config.get("oracle", {})
        # Canonical loader: tries _PROD_PATH then _LOCAL_PATH, returns
        # the ``oracle`` section directly.  Cached (lru_cache).
        from oracle_config_loader import load_shared_oracle_config
        return load_shared_oracle_config()

    def _validate_db_config(self) -> bool:
        """Validate database configuration."""
        required_fields = ["user", "password", "dsn"]
        if not self.db_config:
            self.logger.error("Database configuration is missing.")
            return False
        for field in required_fields:
            if field not in self.db_config:
                self.logger.error(
                    f"Database configuration is missing required field: {field}"
                )
                return False
        return True

    def _get_database_connection(self) -> oracledb.Connection:
        """Get database connection with decrypted password."""
        decrypted_password = self.db_config["password"]
        return oracledb.connect(
            user=self.db_config["user"],
            password=decrypted_password,
            dsn=self.db_config["dsn"],
        )

    # ── COB / quarter-end helper (unchanged) ──────────────────────────────

    def _get_previous_quarter_end(self, business_date: str) -> str:
        """Calculate the end date of the previous quarter based on business_date.

        business_date is in YYYYMMDD format; returns YYYYMMDD.
        """
        try:
            date_obj = datetime.strptime(business_date, "%Y%m%d")
            current_month = date_obj.month
            current_year = date_obj.year
            if current_month <= 3:      # Q1 -> Previous Q4
                prev_quarter_end = datetime(current_year - 1, 12, 31)
            elif current_month <= 6:    # Q2 -> Previous Q1
                prev_quarter_end = datetime(current_year, 3, 31)
            elif current_month <= 9:    # Q3 -> Previous Q2
                prev_quarter_end = datetime(current_year, 6, 30)
            else:                       # Q4 -> Previous Q3
                prev_quarter_end = datetime(current_year, 9, 30)
            return prev_quarter_end.strftime("%Y%m%d")
        except ValueError as e:
            self.logger.error(
                f"Invalid business_date format: {business_date}. Error: {e}"
            )
            return business_date

    # ── Oracle metadata fetchers (unchanged from production) ──────────────

    def _fetch_run_date(
        self, cursor: oracledb.Cursor, dag_run_id: str, dag_id: str, business_date: str,
    ) -> Optional[str]:
        """Fetch run_date from OTG_AIRFLOW_DAG_RUN table."""
        try:
            date_obj = datetime.strptime(business_date, "%Y%m%d")
            oracle_date = date_obj.strftime("%d %b %Y").upper()
        except ValueError as e:
            self.logger.error(
                f"Invalid business_date format: {business_date}. "
                f"Expected YYYYMMDD. Error: {e}"
            )
            return None

        run_date_query = """
            SELECT RUN_DATE
            FROM OTG_AIRFLOW_DAG_RUN
            WHERE FK_DAG_ID = :dag_id
              AND BUSINESS_DATE = TO_DATE(:business_date, 'DD MON YYYY')
              AND RUN_ID = :dag_run_id
        """
        try:
            cursor.execute(
                run_date_query,
                {"dag_run_id": dag_run_id, "dag_id": dag_id, "business_date": oracle_date},
            )
            result = cursor.fetchone()
            if result and result[0]:
                if isinstance(result[0], datetime):
                    return result[0].strftime("%Y%m%d")
                return str(result[0])
            self.logger.warning(
                f"No run_date found for DAG_ID: {dag_id}, "
                f"BUSINESS_DATE: {oracle_date}, DAG_RUN_ID: {dag_run_id}"
            )
            return None
        except oracledb.DatabaseError as e:
            self.logger.error(f"Database error fetching run_date: {e}")
            return None

    def _fetch_report_details(
        self, cursor: oracledb.Cursor, report_id: str,
    ) -> Optional[Tuple]:
        """Fetch report details from OTG_REPORT_CONFIG table."""
        report_query = """
            SELECT Reportid, FILE_FORMAT, FILE_NAME, DELIMITER,
                   FILE_LOCATION, CONTROL_TEMPLATE_ID, ZIP_FORMAT
            FROM OTG_REPORT_CONFIG
            WHERE Reportid = :report_id
        """
        cursor.execute(report_query, {"report_id": report_id})
        return cursor.fetchone()

    def _fetch_data_source_mapping(
        self, cursor: oracledb.Cursor, report_id: str,
    ) -> List[Tuple]:
        """Fetch data source mappings for a report."""
        data_source_query = """
            SELECT REPORTID, DATA_SOURCE_ID
            FROM OTG_REPORT_DATA_SOURCE_MAPPING
            WHERE REPORTID = :report_id AND ACTIVE = 'Y'
        """
        cursor.execute(data_source_query, {"report_id": report_id})
        return cursor.fetchall()

    def _fetch_data_source_details(
        self, cursor: oracledb.Cursor, data_source_id: str,
    ) -> Optional[Tuple]:
        """Fetch data source details (single-row, legacy API)."""
        data_source_details_query = """
            SELECT DATASOURCE_ID, DATASOURCE_NAME, SERVER_NAME, PORT
            FROM OTG_DATA_SOURCE_DETAILS
            WHERE DATASOURCE_ID = :data_source_id AND ACTIVE = 'Y'
        """
        cursor.execute(data_source_details_query, {"data_source_id": data_source_id})
        return cursor.fetchone()

    def _fetch_table_mapping(
        self, cursor: oracledb.Cursor, data_source_id: str,
    ) -> List[Tuple]:
        """Fetch table mappings for a data source (single-source, legacy API)."""
        table_mapping_query = """
            SELECT DATA_SOURCE_ID, TABLE_NAME, TABLE_ALIAS
            FROM OTG_DATA_SOURCE_TABLE_MAPPING
            WHERE DATA_SOURCE_ID = :data_source_id AND ACTIVE = 'Y'
        """
        cursor.execute(table_mapping_query, {"data_source_id": data_source_id})
        return cursor.fetchall()

    # ── Batched per-source fetchers (2026-06-21 perf win) ─────────────────
    # Replaces N+1 round trips with 2 (one IN-list query each).  For K
    # data sources, drops `2K` round trips to 2.  Identical results; only
    # the network pattern changes.

    def _fetch_data_source_details_batch(
        self, cursor: oracledb.Cursor, data_source_ids: List[Any],
    ) -> Dict[Any, Tuple]:
        """Batch-fetch all data source details via IN-list.  Returns
        dict keyed by data_source_id for O(1) lookup."""
        if not data_source_ids:
            return {}
        # Bind names :id0, :id1, ... (oracledb requires named binds; IN
        # with positional list isn't safe across all Oracle versions).
        bind_names = [f"id{i}" for i in range(len(data_source_ids))]
        in_list = ", ".join(f":{n}" for n in bind_names)
        sql = (
            f"SELECT DATASOURCE_ID, DATASOURCE_NAME, SERVER_NAME, PORT "
            f"FROM OTG_DATA_SOURCE_DETAILS "
            f"WHERE DATASOURCE_ID IN ({in_list}) AND ACTIVE = 'Y'"
        )
        binds = dict(zip(bind_names, data_source_ids))
        cursor.execute(sql, binds)
        out: Dict[Any, Tuple] = {}
        for row in cursor.fetchall():
            out[row[0]] = row
        return out

    def _fetch_table_mapping_batch(
        self, cursor: oracledb.Cursor, data_source_ids: List[Any],
    ) -> Dict[Any, List[Tuple]]:
        """Batch-fetch table mappings via IN-list.  Returns dict
        keyed by data_source_id -> list of (ds_id, table_name, alias)."""
        if not data_source_ids:
            return {}
        bind_names = [f"id{i}" for i in range(len(data_source_ids))]
        in_list = ", ".join(f":{n}" for n in bind_names)
        sql = (
            f"SELECT DATA_SOURCE_ID, TABLE_NAME, TABLE_ALIAS "
            f"FROM OTG_DATA_SOURCE_TABLE_MAPPING "
            f"WHERE DATA_SOURCE_ID IN ({in_list}) AND ACTIVE = 'Y'"
        )
        binds = dict(zip(bind_names, data_source_ids))
        cursor.execute(sql, binds)
        out: Dict[Any, List[Tuple]] = {}
        for row in cursor.fetchall():
            ds_id = row[0]
            out.setdefault(ds_id, []).append(row)
        return out

    def _fetch_column_mappings(
        self, cursor: oracledb.Cursor, report_id: str,
    ) -> List[Tuple]:
        """Fetch column mappings for a report.

        2026-06-21 -- selects AGG_FLAG when the column exists in
        OTG_REPORT_COLUMN_MAPPING (added in Phase 152 schema migration).
        Falls back gracefully to the legacy 4-column shape when AGG_FLAG
        doesn't exist yet (zero-break upgrade).  The composer reads
        AGG_FLAG first, falls back to ``"AGG" in source_table`` when
        AGG_FLAG is NULL / missing (legacy substring detection)."""
        column_query_with_flag = """
            SELECT COLUMN_MAPPING, TARGET_COLUMN, SEQ, SOURCE_TABLE, AGG_FLAG
            FROM OTG_REPORT_COLUMN_MAPPING
            WHERE ACTIVE = 'Y' AND FK_REPORTID = :report_id
            ORDER BY SEQ ASC
        """
        column_query_legacy = """
            SELECT COLUMN_MAPPING, TARGET_COLUMN, SEQ, SOURCE_TABLE
            FROM OTG_REPORT_COLUMN_MAPPING
            WHERE ACTIVE = 'Y' AND FK_REPORTID = :report_id
            ORDER BY SEQ ASC
        """
        try:
            cursor.execute(column_query_with_flag, {"report_id": report_id})
            return cursor.fetchall()
        except oracledb.DatabaseError as exc:
            # ORA-00904 ("invalid identifier") when AGG_FLAG column
            # doesn't exist yet -- fall back to legacy 4-column shape.
            if "ORA-00904" in str(exc) or "invalid identifier" in str(exc).lower():
                self.logger.debug(
                    "AGG_FLAG column not present in OTG_REPORT_COLUMN_MAPPING "
                    "-- using legacy substring detection (add column for "
                    "Phase 152 explicit AGG flagging)."
                )
                cursor.execute(column_query_legacy, {"report_id": report_id})
                return cursor.fetchall()
            raise

    def _fetch_param_config(
        self, cursor: oracledb.Cursor, report_id: str,
    ) -> List[Tuple]:
        """Fetch parameter configuration for a report."""
        param_query = """
            SELECT OPERATION_KEY, OPERATION_VALUE
            FROM OTG_REPORT_PARAM_CONFIG
            WHERE FK_REPORTID = :report_id AND ACTIVE = 'Y'
        """
        cursor.execute(param_query, {"report_id": report_id})
        return cursor.fetchall()

    def _fetch_control_template(
        self, cursor: oracledb.Cursor, control_template_id: str,
    ) -> List[Tuple]:
        """Fetch control template information."""
        control_template_query = """
            SELECT CONTROL_TEMPLATE_ID, CONTROL_TEMPLATE_FORMAT
            FROM OTG_CONTROL_TEMPLATE
            WHERE CONTROL_TEMPLATE_ID = :control_template_id
        """
        cursor.execute(control_template_query, {"control_template_id": control_template_id})
        return cursor.fetchall()

    # ── SQL composition helpers (unchanged from production) ───────────────

    def _create_table_alias_mapping(
        self, table_mappings: List[Tuple],
    ) -> Dict[str, str]:
        """Create a mapping from table alias to table name."""
        return {table_alias: table_name for _, table_name, table_alias in table_mappings}

    def _replace_table_placeholders(
        self, params: List[Tuple], table_alias_mapping: Dict[str, str],
    ) -> List[Tuple]:
        """Replace ``{{alias}}`` and ``{from_table} <alias>`` patterns in
        parameter values with the actual table name."""
        updated_params = []
        for operation_key, operation_value in params:
            updated_value = operation_value

            # Replace {{alias}} -> table_name
            for table_alias, table_name in table_alias_mapping.items():
                placeholder = f"{{{{{table_alias}}}}}"
                if placeholder in updated_value:
                    updated_value = updated_value.replace(placeholder, table_name)

            # Replace {from_table} <alias> -> <table_name> <alias>
            if "{from_table}" in updated_value:
                matches = _FROM_TABLE_RE.finditer(updated_value)
                for match in reversed(list(matches)):
                    table_alias = match.group(1)
                    if table_alias in table_alias_mapping:
                        actual_table_name = table_alias_mapping[table_alias]
                        replacement = f"{actual_table_name} {table_alias}"
                        updated_value = (
                            updated_value[: match.start()]
                            + replacement
                            + updated_value[match.end() :]
                        )
                    else:
                        raise ValueError(
                            f"Table alias '{table_alias}' not found in "
                            f"table_alias_mapping.  Available aliases: "
                            f"{list(table_alias_mapping.keys())}"
                        )

            updated_params.append((operation_key, updated_value))
        return updated_params

    def _build_sql_components(
        self,
        columns: List[Tuple],
        params: List[Tuple],
        business_date_formatted: str,
        system_entity: str,
        job_type: str = None,
    ) -> Dict[str, Any]:
        """Build SQL components from column mappings and parameters.

        Auto-detects GROUP BY from AGG columns; assembles SELECT,
        WHERE, JOIN, FROM, GROUP BY.
        """
        select_columns = []
        where_clauses = []
        group_by_columns = []
        join_clauses = []
        from_table_name = ""
        group_by_flag = "N"

        # Process columns.
        # 2026-06-21 -- AGG_FLAG column (5th tuple position) is the
        # explicit Phase 152 signal.  Falls back to the legacy
        # ``"AGG" in source_table`` substring match when AGG_FLAG is
        # NULL / missing (e.g. row predates the migration, or the
        # whole AGG_FLAG column doesn't exist yet -- in which case
        # the fetcher returns 4-tuples).
        for row in columns:
            # Tuple may be 4-wide (legacy) or 5-wide (with AGG_FLAG).
            column_mapping = row[0]
            target_column = row[1]
            seq = row[2]
            source_table = row[3]
            agg_flag = row[4] if len(row) >= 5 else None
            # 2026-06-21 deep-dive bug #3: empty / whitespace / literal-
            # 'NULL' AGG_FLAG values (common on a fresh column migration
            # with DEFAULT '') silently dropped the legacy substring
            # fallback -- a source_table named 'AGG_*' that USED to
            # trigger GROUP BY would silently regress.
            # Fix: any "not-actionable" AGG_FLAG (None, empty, whitespace,
            # literal 'NULL') routes through the legacy substring check.
            agg_norm = (str(agg_flag).strip().upper()
                        if agg_flag is not None else "")
            agg_is_actionable = agg_norm in {"Y", "N"}
            is_agg = (
                (agg_is_actionable and agg_norm == "Y")
                or (not agg_is_actionable and "AGG" in (source_table or ""))
            )
            if is_agg:
                select_columns.append((seq, f'{column_mapping} AS "{target_column}"'))
                group_by_flag = "Y"
            elif "EXPRESSION" in (source_table or ""):
                select_columns.append((seq, f'{column_mapping} AS "{target_column}"'))
                group_by_columns.append(column_mapping)
            else:
                # 2026-06-21 audit bug #9: NULL SOURCE_TABLE on a
                # non-AGG / non-EXPRESSION column used to compose
                # ``None.col`` (literal "None" as schema) which Trino
                # rejects with a confusing "schema 'None' not found"
                # error.  Fail-loud at compose time pointing at the
                # misconfigured Oracle row.
                if not source_table:
                    raise RuntimeError(
                        f"OTG_REPORT_COLUMN_MAPPING row SEQ={seq} "
                        f"(target_column={target_column!r}) has NULL "
                        f"SOURCE_TABLE.  Composer cannot qualify the "
                        f"column reference.  Set SOURCE_TABLE to the "
                        f"table alias, or use SOURCE_TABLE='EXPRESSION' "
                        f"for a literal/computed column."
                    )
                select_columns.append(
                    (seq, f'{source_table}.{column_mapping} AS "{target_column}"')
                )
                group_by_columns.append(f"{source_table}.{column_mapping}")

        # Process parameters.
        # 2026-06-21 audit bug #8: NULL OPERATION_VALUE in
        # OTG_REPORT_PARAM_CONFIG used to crash mid-compose with a
        # cryptic AttributeError ("NoneType has no attribute 'replace'").
        # Now: skip NULL values with a WARN -- other params still process.
        for operation_key, operation_value in params:
            if operation_value is None:
                self.logger.warning(
                    "Skipping OTG_REPORT_PARAM_CONFIG row with NULL "
                    "OPERATION_VALUE for OPERATION_KEY=%s -- fix the "
                    "Oracle metadata row.", operation_key,
                )
                continue
            if "JOIN" in operation_key:
                join_clauses.append(operation_value)
            elif "FILTER" in operation_key:
                filter_value = operation_value.replace(
                    "{business_date}", business_date_formatted
                )
                if job_type == "SBTOORACLE":
                    filter_value = filter_value.replace(
                        "{system_entity}", f"'{system_entity}'"
                    )
                where_clauses.append(filter_value)
            elif "FROM_TABLE" in operation_key:
                from_table_name = operation_value

        # 2026-06-21 audit bug #7: missing FROM_TABLE param (or all
        # FROM_TABLE rows had NULL OPERATION_VALUE) used to silently
        # emit ``SELECT ... FROM`` (dangling), which Trino rejects with
        # a confusing parse error mentioning column not found.  Now:
        # fail-loud at compose time with a clear message pointing at
        # the misconfigured Oracle row.
        if not from_table_name:
            raise RuntimeError(
                "OTG_REPORT_PARAM_CONFIG has no FROM_TABLE row (or all "
                "FROM_TABLE rows have NULL OPERATION_VALUE).  Composer "
                "cannot emit a valid SELECT.  Fix the metadata row "
                "with OPERATION_KEY containing 'FROM_TABLE'."
            )

        return {
            "select_columns": select_columns,
            "where_clauses": where_clauses,
            "group_by_columns": group_by_columns,
            "join_clauses": join_clauses,
            "from_table_name": from_table_name,
            "group_by_flag": group_by_flag,
        }

    def _generate_sql(self, sql_components: Dict[str, Any]) -> str:
        """Compose the final SQL string from components."""
        select_columns = sql_components["select_columns"]
        select_columns.sort(key=lambda x: x[0])
        select_clause = (
            ", ".join(col[1] for col in select_columns) if select_columns else "*"
        )

        join_clause = " ".join(sql_components["join_clauses"])
        where_clause = (
            f"WHERE {' AND '.join(sql_components['where_clauses'])}"
            if sql_components["where_clauses"]
            else ""
        )

        group_by_clause = ""
        # 2026-06-21 audit bug #6: when ALL columns are AGG (no plain
        # columns), group_by_columns stays empty but group_by_flag='Y'
        # used to emit ``GROUP BY `` (dangling) which Trino rejects.
        # Fix: only emit GROUP BY when there are actual columns to group
        # by; pure-aggregation queries skip GROUP BY entirely (Trino /
        # Spark both correctly aggregate the whole result set).
        if (sql_components["group_by_flag"] == "Y"
                and sql_components["group_by_columns"]):
            group_by_clause = (
                f"GROUP BY {', '.join(sql_components['group_by_columns'])}"
            )

        sql_parts = [
            f"SELECT {select_clause}",
            f"FROM {sql_components['from_table_name']}",
            join_clause,
            where_clause,
            group_by_clause,
        ]
        return " ".join(part for part in sql_parts if part.strip()).strip()

    # ── File-name + CTL formatting (unchanged) ────────────────────────────

    def _format_file_names(
        self,
        file_name: str,
        file_format: str,
        ctl_file_format: str,
        business_date: str,
        run_date: str,
        datasource_name: str,
    ) -> Tuple[str, str]:
        """Format file names with date placeholders + datasource suffix.

        2026-06-21 audit bug #5 fix: ``${COB_PREV_EOQ(YYYYMMDD)}`` was
        DEAD CODE in the inherited Prd_generate_sql.py -- the chain
        ``.replace("${COB_PREV_EOQ(YYYYMMDD)}", business_date)`` ran
        BEFORE the ``if "${COB_PREV_EOQ..." in cleaned:`` check, so
        the conditional prev-quarter-end substitution never fired.
        Operators using the placeholder were silently getting
        ``business_date`` instead of the actual previous quarter end.
        Fix: compute prev_quarter_end FIRST and use it directly in the
        chain replace.  Both file name + CTL template now resolve the
        placeholder correctly.
        """
        # Compute prev-quarter-end UPFRONT so the placeholder substitution
        # in the chain below sees the right value.
        business_date_yyyymmdd = business_date.replace("-", "")
        prev_quarter_end = self._get_previous_quarter_end(business_date_yyyymmdd)

        cleaned_file_name = re.sub(
            r"\.(csv|txt|dat|parquet|psv)$", "", file_name, flags=re.IGNORECASE,
        )
        cleaned_file_name = (
            cleaned_file_name.replace("{business_date}", business_date)
            .replace("${COB_PREV_EOQ(YYYYMMDD)}", prev_quarter_end)
            .replace("{run_date}", run_date)
            .replace("{me_business_date}", business_date)
        )

        cleaned_file_name = f"{cleaned_file_name}_{datasource_name}"

        formatted_ctl = (
            ctl_file_format.replace("{business_date}", business_date)
            .replace("${COB_PREV_EOQ(YYYYMMDD)}", prev_quarter_end)
            .replace("{run_date}", run_date)
            .replace("{file_name}", f"{cleaned_file_name}.{file_format}")
        )
        formatted_ctl = formatted_ctl.replace("\r\n", "\n").replace("\r", "\n")

        return cleaned_file_name, formatted_ctl

    # ── SQL post-compose helpers (2026-06-21 safety + observability) ──────

    @staticmethod
    def _sql_hash(sql: str) -> str:
        """Stable 12-char sha256 of the composed SQL.  Operators see this
        in result.html runtime_knobs as ``sql_hash_<datasource>`` so a
        SQL diff across runs (someone edited OTG_REPORT_PARAM_CONFIG)
        is detectable at-a-glance instead of by diffing log lines."""
        if not sql:
            return ""
        return hashlib.sha256(sql.encode("utf-8")).hexdigest()[:12]

    def _validate_composed_sql(self, sql: str, datasource_name: str) -> None:
        """Parse the composed SQL with sqlglot to catch SOME malformed
        OTG_REPORT_PARAM_CONFIG rows at compose time (~5ms).

        2026-06-21 audit honesty note: sqlglot is permissive on a few
        shapes Trino rejects (bare ``SELECT``, ``SELECT * FROM`` -- it
        catches; ``SELECT FROM t``, missing-subquery-alias, dangling
        ``GROUP BY`` -- it accepts but Trino later rejects).  Useful
        guardrail for ``WHERE x =``, ``SELECT * FROM`` (no table), etc.
        Not a substitute for execute-time validation.

        No-op when sqlglot isn't installed (optional dependency).
        Raises RuntimeError with the offending SQL when parse fails."""
        if not _SQLGLOT_AVAILABLE or not sql:
            return
        try:
            # Trino dialect covers Starburst on-prem + cloud + Athena.
            # Spark / Snowflake later-stage targets parse the same
            # ANSI-SELECT shape; using "trino" as the strictest works.
            sqlglot.parse_one(sql, dialect="trino")
        except _SqlglotParseError as exc:
            raise RuntimeError(
                f"Composed SQL failed sqlglot parse for datasource "
                f"'{datasource_name}'.  Likely a malformed FILTER / JOIN "
                f"row in OTG_REPORT_PARAM_CONFIG.\n  Parse error: {exc}\n"
                f"  SQL: {sql[:500]}{'...' if len(sql) > 500 else ''}"
            ) from exc
        except Exception as exc:
            # Defensive: don't fail composition on a sqlglot internal
            # bug.  Log + continue -- worst case, error surfaces at
            # extract time (the legacy behavior).
            self.logger.debug(
                "sqlglot validation skipped for %s (non-parse error): %s",
                datasource_name, exc,
            )

    def _optimize_composed_sql(
        self, sql: str, datasource_name: str,
    ) -> Tuple[str, Dict[str, Any]]:
        """Light-touch composer-side optimization to help BOTH Starburst
        and Spark (S3+Iceberg) planners produce a faster plan.

        DEFAULT PIPELINE (safe -- no semantic change):
          * ``simplify`` -- collapses ``WHERE TRUE`` / ``x AND TRUE``,
            constant-folds literals, removes redundant parens.
          * ``normalize`` -- canonical CNF form so AND/OR predicates
            are in a form both Trino + Spark planners reorder cleanly.

        OPT-IN PUSHDOWN (unsafe by default -- explicit polling-row flag
        ``enable_sql_pushdown_optimization=true`` to engage):
          * ``pushdown_predicates`` -- moves WHERE conditions into
            subqueries.  GREAT for Iceberg partition pruning on S3 when
            the predicate is on a partition column buried under a
            ``FROM (SELECT ...) sub`` wrapper.
            **2026-06-21 audit caught**: when the outer WHERE references
            ``sub.col``, sqlglot pushes ``sub.col`` literally into the
            subquery scope where ``sub`` is undefined -- Trino rejects.
            Composer-built SQL doesn't typically wrap in subqueries
            (FROM_TABLE = ``actual_table alias``), but operator-written
            FILTER rows that reference an outer alias can trigger this.
            Operator must verify their SQL shape is safe before enabling.

        SKIPPED (intentional):
          * ``qualify_columns`` -- requires a schema (sqlglot can't
            see Oracle metadata or Iceberg catalog); safer to let the
            engine planner qualify.
          * ``eliminate_subqueries`` / ``merge_subqueries`` -- can
            change correlated-subquery semantics; not safe for
            arbitrary user FILTER rows.
          * ``annotate_types`` -- needs a schema.

        Returns (optimized_sql, info_dict).  info_dict carries:
          * ``optimized``: bool -- did the SQL actually change?
          * ``passes_applied``: list[str] -- names of applied passes.
          * ``original_len``, ``optimized_len`` -- char counts.

        Falls back to the original SQL on any sqlglot error -- never
        breaks composition.  No-op when sqlglot isn't installed."""
        info: Dict[str, Any] = {
            "optimized": False,
            "passes_applied": [],
            "original_len": len(sql or ""),
            "optimized_len": len(sql or ""),
        }
        if not _SQLGLOT_AVAILABLE or not sql:
            return sql, info
        try:
            # Lazy import -- only loaded when optimization is engaged.
            from sqlglot.optimizer.simplify import simplify
            from sqlglot.optimizer.normalize import normalize

            tree = sqlglot.parse_one(sql, dialect="trino")
            applied: List[str] = []

            # Pass 1: simplify (constant fold + remove WHERE TRUE).
            tree = simplify(tree)
            applied.append("simplify")

            # Pass 2 (OPT-IN): pushdown_predicates.  Default OFF because
            # it can rewrite WHERE clauses with outer-alias references
            # into invalid subquery-scope references (caught in 2026-06-21
            # audit).  Operator enables via polling row when SQL shape
            # is known-safe (no subquery wrapper in FROM).
            if self._enable_sql_pushdown_optimization:
                from sqlglot.optimizer.pushdown_predicates import (
                    pushdown_predicates,
                )
                tree = pushdown_predicates(tree)
                applied.append("pushdown_predicates")

            # Pass 3: normalize to CNF (canonical form helps planner
            # reorder JOIN predicates).
            tree = normalize(tree)
            applied.append("normalize")

            optimized = tree.sql(dialect="trino")
            info["passes_applied"] = applied
            info["optimized_len"] = len(optimized)
            info["optimized"] = optimized.strip() != sql.strip()
            return optimized, info
        except Exception as exc:
            # Optimization failure is never fatal -- log + return
            # original.  Worst case = same SQL as before optimization
            # was introduced.
            self.logger.warning(
                "SQL optimization skipped for %s (%s); using composed SQL "
                "as-is.", datasource_name, exc,
            )
            return sql, info

    # ── Phase 152 polling-row passthrough ─────────────────────────────────

    @staticmethod
    def _phase152_passthrough(task: Dict) -> Dict[str, Any]:
        """Pull Phase 152 polling-row knobs into per-job metadata so the
        extract step picks them up.  All optional; missing == no-op."""
        out: Dict[str, Any] = {}
        # CHECKSUM_COLUMNS -- activates ProbeQuery + C5 SUM gate
        ck = task.get("checksum_columns") or task.get("CHECKSUM_COLUMNS")
        if ck:
            if isinstance(ck, str):
                ck = [c.strip() for c in ck.split(",") if c.strip()]
            out["checksum_columns"] = list(ck)
        # Partition config -- column + bucketing/discovery knobs
        pcol = (
            task.get("partition_column")
            or task.get("PARTITION_COLUMN")
        )
        if pcol:
            pcfg: Dict[str, Any] = {"partition_column": pcol}
            for src, dst in (
                ("partition_enabled", "enabled"),
                ("PARTITION_ENABLED", "enabled"),
                ("discovery_mode", "discovery_mode"),
                ("DISCOVERY_MODE", "discovery_mode"),
                ("max_partitions", "max_partitions"),
                ("MAX_PARTITIONS", "max_partitions"),
                ("bucket_strategy", "bucket_strategy"),
                ("BUCKET_STRATEGY", "bucket_strategy"),
                ("bucket_size", "bucket_size"),
                ("BUCKET_SIZE", "bucket_size"),
            ):
                v = task.get(src)
                if v not in (None, ""):
                    pcfg[dst] = v
            out["partition_config"] = pcfg
        # 2026-06-22 -- Spark memory knobs passthrough.  StarburstBase
        # already reads `config.get('spark_executor_memory', ...)` etc.
        # at _build_spark_session time, so any polling-row value lands
        # in the per-job JSON and overrides the hardcoded subclass
        # DEFAULT_EXECUTOR_MEMORY / DEFAULT_DRIVER_MEMORY fallbacks.
        # Operators set these per report when 10g/3g (oncloud) or
        # 15g/4g (onprem) defaults aren't right for the data volume.
        for src, dst in (
            ("spark_executor_memory", "spark_executor_memory"),
            ("SPARK_EXECUTOR_MEMORY", "spark_executor_memory"),
            ("spark_driver_memory", "spark_driver_memory"),
            ("SPARK_DRIVER_MEMORY", "spark_driver_memory"),
            ("spark_executor_memory_overhead", "spark_executor_memory_overhead"),
            ("SPARK_EXECUTOR_MEMORY_OVERHEAD", "spark_executor_memory_overhead"),
            ("spark_driver_memory_overhead", "spark_driver_memory_overhead"),
            ("SPARK_DRIVER_MEMORY_OVERHEAD", "spark_driver_memory_overhead"),
            ("num_partitions", "num_partitions"),
            ("NUM_PARTITIONS", "num_partitions"),
        ):
            v = task.get(src)
            if v not in (None, ""):
                out[dst] = v
        return out

    # ── Async orchestration ───────────────────────────────────────────────

    async def fetch_report_metadata(
        self,
        report_id: str,
        business_date: str,
        dag_run_id: str,
        dag_id: str,
        job_type: str = None,
        system_entity: str = "",
    ) -> Optional[List[Dict[str, Any]]]:
        """Fetch report metadata + generate SQL for the specified report.

        2026-06-21 -- dropped the ``loop.run_in_executor`` wrap.  The
        underlying ``oracledb`` calls are sync; the executor gave us
        async-shape with ZERO actual parallelism (one report per task).
        Callers (``BaseStep.execute`` etc.) still await this coroutine
        unchanged; the body is now a direct sync call.

        Also: only ``oracledb.DatabaseError`` is swallowed-and-Noned.
        Phase 152 fail-loud RuntimeError (landmines #2 + #3) propagates
        with its rich message so operators see WHICH source / WHICH
        metadata table is the problem instead of a generic "Failed to
        generate SQL"."""
        if not self._validate_db_config():
            return None
        try:
            with self._get_database_connection() as connection:
                with connection.cursor() as cursor:
                    result = self._process_single_report(
                        cursor, report_id, business_date, dag_run_id, dag_id,
                        job_type, system_entity,
                    )
            # 2026-06-21 -- expose the report row + control template
            # on the task-scoped metadata cache so RowCountCheck,
            # CTL writer, send_email, etc. don't re-fetch the same
            # OTG_REPORT_CONFIG row.  Cache is opt-in: consumer steps
            # call _metadata_cache_get(task, key); cache miss = same
            # behavior as today (re-fetch).
            self._publish_metadata_cache(result)
            return result
        except oracledb.DatabaseError as e:
            self.logger.error(f"Oracle metadata fetch failed: {e}")
            return None

    def _publish_metadata_cache(
        self, report_data: Optional[List[Dict[str, Any]]],
    ) -> None:
        """Stash the per-data-source metadata onto the run-scoped
        cache (``task["_metadata_cache"]``) so downstream steps
        can read the same OTG_REPORT_CONFIG row + control template
        + per-source server/port without a fresh Oracle hit.

        Cache keys (one dict per data source):
          * ``report:<report_id>:<datasource>`` -> full metadata dict

        Consumers call ``GenerateSQL.metadata_cache_get(task, key)``
        as a defensive lookup; missing key = no-op (re-fetch is fine).
        """
        if not report_data or not isinstance(self._current_task, dict):
            return
        cache = self._current_task.setdefault("_metadata_cache", {})
        if not isinstance(cache, dict):
            return  # someone else overloaded the key -- don't clobber
        for entry in report_data:
            ds = entry.get("datasource_name", "?")
            rid = entry.get("report_id", "?")
            cache[f"report:{rid}:{ds}"] = dict(entry)  # shallow copy

    @staticmethod
    def metadata_cache_get(task: Dict, key: str) -> Optional[Dict[str, Any]]:
        """Public lookup helper for downstream steps.  Returns the
        cached metadata entry or None on miss (caller should re-fetch
        from Oracle).  Defensive: never raises."""
        cache = task.get("_metadata_cache")
        if not isinstance(cache, dict):
            return None
        v = cache.get(key)
        return v if isinstance(v, dict) else None

    def _fetch_report_metadata_sync(
        self,
        report_id: str,
        business_date: str,
        dag_run_id: str,
        dag_id: str,
        job_type: str = None,
        system_entity: str = "",
    ) -> Optional[List[Dict[str, Any]]]:
        """DEPRECATED 2026-06-21 -- kept only for back-compat with any
        external caller that imported the sync helper directly.  The
        async ``fetch_report_metadata`` is now also sync-bodied so this
        wrapper is redundant.  New code should call
        ``fetch_report_metadata`` and await it (or run inside an
        already-running event loop)."""
        try:
            with self._get_database_connection() as connection:
                with connection.cursor() as cursor:
                    return self._process_single_report(
                        cursor, report_id, business_date, dag_run_id, dag_id,
                        job_type, system_entity,
                    )
        except oracledb.DatabaseError as e:
            self.logger.error(f"Database error: {e}")
            return None

    def _process_single_report(
        self,
        cursor: oracledb.Cursor,
        report_id: str,
        business_date: str,
        dag_run_id: str,
        dag_id: str,
        job_type: str = None,
        system_entity: str = "",
    ) -> Optional[List[Dict[str, Any]]]:
        """Build the per-data-source metadata list for one report."""
        business_date_formatted = datetime.strptime(
            business_date, "%Y%m%d",
        ).strftime("%Y-%m-%d")

        run_date = self._fetch_run_date(cursor, dag_run_id, dag_id, business_date)
        if not run_date:
            # 2026-06-21 -- Phase 152 landmine #3: silent now() fallback
            # baked TODAY's date into file names + WHERE filters on manual
            # reruns where OTG_AIRFLOW_DAG_RUN had no matching row.
            # Fail-loud by default; explicit opt-in for the legacy
            # behavior (dev/local only).
            if not self._allow_missing_run_date:
                raise RuntimeError(
                    f"Cannot resolve run_date from OTG_AIRFLOW_DAG_RUN for "
                    f"dag_id={dag_id} dag_run_id={dag_run_id} "
                    f"business_date={business_date}.  Polling row can opt "
                    f"into legacy now()-fallback by setting "
                    f"allow_missing_run_date=true."
                )
            self.logger.warning(
                "run_date missing in OTG_AIRFLOW_DAG_RUN; opt-in fallback "
                "to datetime.now() (allow_missing_run_date=true on polling row)."
            )
            run_date = datetime.now().strftime("%Y%m%d")
        self.logger.info(f"Using run_date: {run_date} for report {report_id}")

        report = self._fetch_report_details(cursor, report_id)
        if not report:
            self.logger.error(f"No report found for Report ID {report_id}")
            return None

        data_source_mappings = self._fetch_data_source_mapping(cursor, report_id)
        if not data_source_mappings:
            self.logger.error(
                f"No data source mappings found for Report ID {report_id}"
            )
            return None

        # 2026-06-21 audit bug #10: duplicate rows in
        # OTG_REPORT_DATA_SOURCE_MAPPING (e.g. accidental double-insert,
        # or a JOIN multiplier in a future schema change) used to produce
        # multiple identical job entries with the SAME output_file_name
        # -- extract step would run N times writing to the same file =
        # last-writer-wins corruption + racing I/O.  Dedup by
        # data_source_id (preserve first-seen order) + WARN once.
        seen_ds_ids = set()
        deduped: List[Tuple] = []
        for row in data_source_mappings:
            ds_id = row[1]
            if ds_id in seen_ds_ids:
                continue
            seen_ds_ids.add(ds_id)
            deduped.append(row)
        if len(deduped) < len(data_source_mappings):
            dup_count = len(data_source_mappings) - len(deduped)
            self.logger.warning(
                "OTG_REPORT_DATA_SOURCE_MAPPING has %d duplicate "
                "DATA_SOURCE_ID rows for REPORTID=%s (active='Y').  "
                "Composer deduped -- recommend cleaning Oracle metadata. "
                "Kept %d unique sources.",
                dup_count, report_id, len(deduped),
            )
        data_source_mappings = deduped

        columns = self._fetch_column_mappings(cursor, report_id)
        if not columns:
            self.logger.error(
                f"No column mappings found for Report ID {report_id}"
            )
            return None

        base_params = self._fetch_param_config(cursor, report_id)
        if not base_params:
            self.logger.error(
                f"No parameter mappings found for Report ID {report_id}"
            )
            return None

        (
            report_id_val, file_format, file_name, delimiter, file_location,
            control_template_id, zip_format,
        ) = report

        templates = self._fetch_control_template(cursor, control_template_id)
        if not templates:
            self.logger.error(
                f"No control template found for Template ID {control_template_id}"
            )
            return None

        # 2026-06-21 -- batched per-source fetch.  Was 2K round trips
        # (one for details, one for table_mapping, per data source).
        # Now 2 IN-list queries total, regardless of K.
        all_ds_ids = [ds_id for _, ds_id in data_source_mappings]
        details_by_id = self._fetch_data_source_details_batch(cursor, all_ds_ids)
        table_map_by_id = self._fetch_table_mapping_batch(cursor, all_ds_ids)

        report_metadata_list: List[Dict[str, Any]] = []
        failed_sources: List[Tuple[Any, str]] = []
        for _, data_source_id in data_source_mappings:
            try:
                data_source_details = details_by_id.get(data_source_id)
                if not data_source_details:
                    msg = (
                        f"No data source details found for Data Source ID "
                        f"{data_source_id}"
                    )
                    self.logger.error(msg)
                    failed_sources.append((data_source_id, msg))
                    continue
                _, datasource_name, server_name, port = data_source_details

                table_mappings = table_map_by_id.get(data_source_id, [])
                if not table_mappings:
                    msg = (
                        f"No table mappings found for Data Source ID "
                        f"{data_source_id}"
                    )
                    self.logger.error(msg)
                    failed_sources.append((data_source_id, msg))
                    continue

                table_alias_mapping = self._create_table_alias_mapping(table_mappings)
                updated_params = self._replace_table_placeholders(
                    base_params, table_alias_mapping,
                )

                sql_components = self._build_sql_components(
                    columns, updated_params, business_date_formatted,
                    system_entity, job_type,
                )
                generated_sql = self._generate_sql(sql_components)

                # 2026-06-21 -- sqlglot post-compose validation (no-op
                # without sqlglot).  Catches malformed FILTER / JOIN
                # rows at compose time instead of at Trino-extract time.
                self._validate_composed_sql(generated_sql, datasource_name)

                # 2026-06-21 -- light-touch composer-side optimization
                # (simplify + pushdown_predicates + normalize) so BOTH
                # Starburst and Spark (S3+Iceberg) planners get a
                # cleaner tree to work with.  Helps Iceberg partition-
                # prune on S3 when predicates were buried in subqueries.
                # Opt-out per polling row.
                if not self._disable_sql_optimization:
                    optimized_sql, opt_info = self._optimize_composed_sql(
                        generated_sql, datasource_name,
                    )
                    if opt_info.get("optimized"):
                        self.logger.info(
                            "SQL optimized for %s: %d -> %d chars, "
                            "passes=%s",
                            datasource_name,
                            opt_info["original_len"],
                            opt_info["optimized_len"],
                            ",".join(opt_info["passes_applied"]),
                        )
                    generated_sql = optimized_sql
                    self._opt_info_by_source[datasource_name] = opt_info

                cleaned_file_name, formatted_ctl = self._format_file_names(
                    file_name, file_format, templates[0][1],
                    business_date, run_date, datasource_name,
                )

                metadata = {
                    "job_id": f"job_{report_id}",
                    "report_id": report_id_val,
                    "datasource_name": datasource_name,
                    "business_date": business_date,
                    "run_date": run_date,
                    "generated_sql": generated_sql,
                    "output_file_name": f"{cleaned_file_name}.{file_format}",
                    "output_file_type": file_format,
                    "output_file_delimiter": delimiter,
                    "output_file_location": file_location,
                    "ctl_file_format": formatted_ctl,
                    "system_entity": system_entity,
                    "server_name": server_name,
                    "port": port,
                    "zip_format": zip_format,
                }
                report_metadata_list.append(metadata)
                self.logger.info(
                    f"Successfully processed report {report_id} for data source "
                    f"{datasource_name}"
                )
            except Exception as e:
                self.logger.error(
                    f"Error processing data source {data_source_id} for "
                    f"report {report_id}: {e}"
                )
                failed_sources.append((data_source_id, str(e)))
                continue

        # 2026-06-21 -- Phase 152 landmine #2: silent `continue` on a
        # per-data-source failure used to emit a half-populated jobs[]
        # JSON.  Downstream extracts ran with only the surviving sources
        # and no FAIL gate tripped -- silent partial success.  Fail-loud
        # by default; explicit opt-in keeps the legacy partial behavior.
        if failed_sources:
            if not self._allow_partial_datasources:
                raise RuntimeError(
                    f"Failed to compose SQL for {len(failed_sources)} of "
                    f"{len(data_source_mappings)} data source(s) under "
                    f"report {report_id}: {failed_sources}.  Polling row "
                    f"can opt into partial JSON by setting "
                    f"allow_partial_datasources=true."
                )
            self.logger.warning(
                "Emitting PARTIAL jobs[] JSON for report %s: %d of %d sources "
                "succeeded (failed: %s)",
                report_id, len(report_metadata_list),
                len(data_source_mappings), failed_sources,
            )

        return report_metadata_list if report_metadata_list else None

    # ── BaseStep contract ─────────────────────────────────────────────────

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> str:
        """Generate SQL via DB metadata and write per-data-source JSON
        to task['sql_query_path'].  Integrates with the file_flow run-
        report + artifacts registry."""
        self._setup_logging(task)
        artifacts = get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        run_report: Optional[FileRunReport] = (
            rr if isinstance(rr, FileRunReport) else None
        )

        # 2026-06-21 -- Phase 152 fail-loud opt-ins (default OFF).
        # Polling row sets these to 'true'/'1' to keep legacy silent
        # behavior on the rare manual-replay / partial-source cases.
        self._allow_missing_run_date = _truthy(
            task.get("allow_missing_run_date")
        )
        self._allow_partial_datasources = _truthy(
            task.get("allow_partial_datasources")
        )
        self._disable_sql_optimization = _truthy(
            task.get("disable_sql_optimization")
        )
        self._enable_sql_pushdown_optimization = _truthy(
            task.get("enable_sql_pushdown_optimization")
        )
        self._opt_info_by_source = {}  # reset per task
        self._current_task = task  # exposed for _publish_metadata_cache

        report_id = str(task.get("fk_report_id", 0))
        business_date = task["business_date"].replace("-", "")
        dag_run_id = str(task.get("run_id", 0))
        dag_id = task.get("fk_dag_id", "")

        if not dag_id:
            self.logger.error(f"dag_id not found in task {task.get('task_id')}")
            raise Exception("dag_id is required but not found in task")

        sql_file_location = task["sql_query_path"]

        # Get job type + system entity from task or step config
        job_type = task.get("job_type", self.config.get("job_type", ""))
        system_entity = task.get(
            "system_entity", self.config.get("system_entity", ""),
        )

        self.logger.info("=" * 72)
        self.logger.info(
            "GenerateSQL for run_id=%s report_id=%s dag_id=%s biz_date=%s "
            "out=%s",
            dag_run_id, report_id, dag_id, business_date, sql_file_location,
        )
        self.logger.info("=" * 72)

        # Build per-data-source metadata via DB
        report_data = await self.fetch_report_metadata(
            report_id, business_date, dag_run_id, dag_id, job_type, system_entity,
        )
        if not report_data:
            raise Exception(
                f"Failed to generate SQL for task {task.get('task_id')}"
            )

        # 2026-06-21 -- thread Phase 152 polling-row knobs into each job
        # entry so the extract step picks them up (CHECKSUM_COLUMNS,
        # PARTITION_COLUMN, etc.).
        phase152_extras = self._phase152_passthrough(task)
        for entry in report_data:
            for k, v in phase152_extras.items():
                entry.setdefault(k, v)

        # Back-compat task mutations (some step paths read these directly)
        task["generated_sql"] = report_data[0]["generated_sql"]
        for data in report_data:
            task[f"generated_sql_{data['datasource_name']}"] = data["generated_sql"]

        # 2026-06-22 -- REVERTED dual-shape output (commit f10c6c5).
        # User clarified: "we are not using GenerateSQL in
        # oracle_standalone.py".  The oracle workflow reads operator-
        # curated query_fact_table.json directly, NOT a GenerateSQL
        # output.  So the top-level prd keys (query_on_cloud, oracle_url,
        # spark_*, etc.) would have been:
        #   - unnecessary (no oracle consumer reads them)
        #   - a security smell (oracle creds in file-flow JSON)
        # Reverting to Phase 152 jobs[] format only.

        # 2026-06-21 -- atomic JSON write (tmp + os.replace) so a mid-
        # write crash leaves the OLD JSON intact (downstream parse
        # never sees half-written content).
        #
        # 2026-06-22 -- ensure the parent directory exists before
        # opening the .tmp file.  Polling-row column ``sql_query_path``
        # may point at a fresh queryjson/ folder that hasn't been
        # created on this pod yet (fresh PVC mount / new dag_id /
        # operator typo of an unprovisioned path).  Without
        # ``makedirs``, the .tmp open raised ENOENT mid-step and
        # killed the run with a confusing error.
        output_file = sql_file_location
        output_dir = os.path.dirname(output_file)
        if output_dir:
            try:
                os.makedirs(output_dir, exist_ok=True)
            except OSError as mk_exc:
                # Fail loud with a path-specific error -- much clearer
                # than the downstream ENOENT on .tmp open.
                raise RuntimeError(
                    f"GenerateSql: cannot create parent directory for "
                    f"output JSON.\n  Path: {output_dir!r}\n"
                    f"  OS error: {mk_exc}\n"
                    f"  Operator action: verify the polling-row "
                    f"sql_query_path points at a writable NFS / PVC "
                    f"location on this pod, or create the directory "
                    f"manually with the correct permissions."
                ) from mk_exc

        tmp = output_file + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"jobs": report_data}, f, indent=4, ensure_ascii=False)
                try:
                    f.flush()
                    os.fsync(f.fileno())
                except OSError:
                    pass
            os.replace(tmp, output_file)
            self.logger.info(f"Metadata written to {output_file}")
        except Exception as e:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            self.logger.error(f"Error writing metadata to JSON: {e}")
            raise

        # 2026-06-21 -- run-report integration.  Each generated SQL goes
        # into the report's "SQL executed" table so operators see the
        # actual SQL per data source in result.html.
        if run_report is not None:
            for entry in report_data:
                try:
                    run_report.add_sql_summary(
                        str(entry.get("report_id", "?")),
                        entry.get("generated_sql", ""),
                    )
                except Exception:
                    pass
            try:
                run_report.runtime_knobs["generate_sql_datasources"] = ", ".join(
                    d["datasource_name"] for d in report_data
                )
            except Exception:
                pass
            # 2026-06-21 -- stable SQL hash per data source.  Surfaces
            # in result.html "Runtime knobs" table so operators see at-
            # a-glance whether the SQL changed since the last run
            # (someone edited OTG_REPORT_PARAM_CONFIG, an OG-ETL
            # backfill changed a FILTER row, etc.).
            for entry in report_data:
                try:
                    ds = entry.get("datasource_name", "?")
                    sql = entry.get("generated_sql", "")
                    run_report.runtime_knobs[f"sql_hash_{ds}"] = self._sql_hash(sql)
                except Exception:
                    pass
            # 2026-06-21 -- per-source SQL optimization summary surfaces
            # in result.html so operators see whether the optimizer
            # touched the SQL and by how much.  Helps validate the
            # optimizer didn't accidentally over-rewrite.
            for ds, info in self._opt_info_by_source.items():
                try:
                    if info.get("optimized"):
                        run_report.runtime_knobs[f"sql_optimized_{ds}"] = (
                            f"{info['original_len']}->{info['optimized_len']} "
                            f"chars via {','.join(info['passes_applied'])}"
                        )
                    elif _SQLGLOT_AVAILABLE:
                        run_report.runtime_knobs[f"sql_optimized_{ds}"] = (
                            "no-change (already optimal)"
                        )
                except Exception:
                    pass

        # 2026-06-21 -- register output JSON with RunArtifacts so failure
        # cleanup tracks it as a step output (kept on success; wiped on
        # downstream failure via cleanup_on_failure).
        try:
            artifacts.add(output_file, RunArtifacts.CONSOLIDATED)
        except Exception:
            pass

        generated_sql = report_data[0]["generated_sql"]
        self.logger.info(
            "Generated SQL for task %s across %d data source(s): "
            "first datasource SQL (%d chars) first line: %r",
            task.get("task_id"), len(report_data), len(generated_sql),
            generated_sql.strip().splitlines()[0][:120] if generated_sql.strip() else "",
        )
        return generated_sql
