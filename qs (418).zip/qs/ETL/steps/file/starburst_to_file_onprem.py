"""StarburstToFile_OnPrem — Starburst (on-prem catalog) → flat file.

Thin subclass of ``StarburstFileBase``.  Inherits the same extract
strategy as the cloud variant; only the credential sourcing differs:

  * ``[Starburst-OnPrem]`` ini section if present.
  * Falls back to ``[Starburst]`` (legacy / shared).

See ``starburst_to_file_oncloud.py`` for the full per-job config
contract — they're identical apart from ``datasource_name == "ONPREM"``.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.file.starburst_file_base import StarburstFileBase


class StarburstToFile_OnPrem(StarburstFileBase):
    """Starburst → file for the ONPREM datasource."""

    DATASOURCE_NAME = "ONPREM"
    LOG_PREFIX = "starburst_to_file_onprem"

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """File-workflow on-prem connection -- creds-from-yaml.
        See ``starburst_to_file_oncloud_spark`` for the full
        precedence + validation contract."""
        shared = self._shared_starburst_fallback("onprem")
        ini = self.ini_config
        onprem_section = "Starburst-OnPrem"
        fallback = "Starburst"
        section = onprem_section if (ini and ini.has_section(onprem_section)) else fallback

        if ini and ini.has_section(section):
            ini_user = ini.get(section, "username", fallback="")
            ini_password = ini.get(section, "password", fallback="")
            ini_catalog = ini.get(section, "catalog", fallback="")
            ini_schema = ini.get(section, "schema", fallback="")
        else:
            ini_user = ini_password = ini_catalog = ini_schema = ""

        user = (
            shared.get("user") or ini_user or job_config.get("trino_user", "") or ""
        )
        password = (
            shared.get("password") or ini_password
            or job_config.get("trino_password", "") or ""
        )
        catalog = (
            shared.get("catalog") or ini_catalog or job_config.get("catalog", "") or ""
        )
        schema = (
            shared.get("schema") or ini_schema or job_config.get("schema", "") or ""
        )

        missing = []
        if not user:
            missing.append("user (yaml: starburst.user / starburst.onprem.user)")
        if not password:
            missing.append("password (yaml: starburst.password / starburst.onprem.password)")
        if missing:
            raise ValueError(
                f"Starburst on-prem connection: missing required credential(s) for "
                f"report_id={job_config.get('report_id')}:\n"
                + "".join(f"  * {m}\n" for m in missing)
                + f"Sources consulted (in priority order):\n"
                f"  1. configs/starburst_config.yaml  -- onprem or root user/password\n"
                f"  2. INI [{section}] in $EXPORT_TOOL_CONFIG_PATH\n"
                f"  3. per-job JSON trino_user / trino_password\n"
                f"  4. env STARBURST_ONPREM_USER / STARBURST_ONPREM_PASSWORD\n"
                f"Fill at least one source."
            )

        self.logger.info(
            "Starburst on-prem connection resolved: host=%s:%s user=%s (user source=%s)",
            job_config["server_name"], job_config["port"], user,
            "YAML" if shared.get("user") else ("INI" if ini_user else "per-job JSON"),
        )
        return {
            "host": job_config["server_name"],
            "port": int(job_config["port"]),
            "user": user,
            "password": password,
            "catalog": catalog,
            "schema": schema,
            "use_ssl": True,
            "verify": False,
            "request_timeout": int(job_config.get("request_timeout", 600)),
        }
