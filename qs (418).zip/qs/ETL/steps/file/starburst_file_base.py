"""Strategic base for Starburst → flat-file extract steps.

One unifying abstraction owns the whole extract:

    ScanPlan(mode, partition_column, partition_values, expected_total,
             expected_per_partition, batch_size, max_concurrent)

   ScanPlan.mode ∈ {SINGLE, PARTITION_VALUES}

   * SINGLE          — one query, one chunk file, cursor-streamed.
                       Good for jobs < ~5 M rows.
   * PARTITION_VALUES — fan-out by a configured column's distinct
                       values.  Each value becomes ONE small query +
                       ONE chunk file.  Concurrent (capped).  This is
                       how we extract 120 M rows without OOM at the
                       Starburst coordinator: the coordinator never
                       holds the full result set; it only ships one
                       partition's rows per cursor.

OOM avoidance contract:
  * NEVER use LIMIT N OFFSET M for chunking — Trino can't push OFFSET
    so the coordinator scans-then-discards.  We always use
    ``WHERE col = 'value'`` chunking instead.
  * The Trino DB cursor ALWAYS uses ``fetchmany(batch_size)``; peak
    memory per stream is one batch (~2-5 MB for batch_size=50_000).
  * Per-partition concurrency cap (default 2-4) keeps the in-flight
    cursors bounded so Trino sees N small queries, not one huge one.

Completeness ledger (G1-G5) owned by this base — every subclass
reports into ``FileRunReport``:

  G1 — source pre-flight COUNT(*)                  -> expected_total
  G2 — Sum(per-partition COUNT(*)) == G1           (plan coverage)
  G3 — Sum(actual rows written to chunks) == G1    (stream integrity)
  G4 — per-partition actual == per-partition expected
  G5 — Consolidated file rows == G1                (merge integrity — owned by ConsolidateFiles)

ANY failure (connection, query, fetch, write) raises after the step
populates the failure path on the run report and registers no further
artifacts.  The standalone's except branch calls
``RunArtifacts.cleanup_on_failure()`` which removes every chunk +
consolidated + compressed + ctl file written by this run.
"""
from __future__ import annotations

import asyncio
import configparser
import csv
import hashlib
import json
import logging
import os
import queue
import re
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from queue import Queue
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts,
    get_or_create_artifacts,
    hydrate_task_from_sidecar,
    save_task_state,
)


# ──────────────────────────────────────────────────────────────────────
#  Error categorization
# ──────────────────────────────────────────────────────────────────────

class StarburstErrorType(Enum):
    FATAL = "fatal"          # connection / auth / catalog missing — stop entire run
    RETRYABLE = "retryable"  # timeout / 503 / memory — retry chunk
    SKIPPABLE = "skippable"  # bad row data — log + continue


@dataclass
class StarburstError:
    error_type: StarburstErrorType
    message: str
    original_error: BaseException
    is_retryable: bool
    should_stop_process: bool


class StarburstErrorClassifier:
    """Categorize Starburst / Trino exceptions into actionable types."""

    FATAL_PATTERNS = [
        r"permission denied",
        r"access denied",
        r"authentication failed",
        r"invalid credentials",
        r"catalog .* not found",
        r"schema .* not found",
        r"connection refused",
        r"name or service not known",
        r"ssl.*error",
        r"certificate verify failed",
    ]
    RETRYABLE_PATTERNS = [
        r"timeout",
        r"timed out",
        r"temporary failure",
        r"service unavailable",
        r"too many requests",
        r"query exceeded .* memory",
        r"exceeded .* limit",
        r"server overloaded",
        r"connection reset",
        r"broken pipe",
    ]
    SKIPPABLE_PATTERNS = [
        r"division by zero",
    ]

    @classmethod
    def classify(cls, error: BaseException) -> StarburstError:
        msg = str(error).lower()
        for pat in cls.FATAL_PATTERNS:
            if re.search(pat, msg, re.IGNORECASE):
                return StarburstError(
                    StarburstErrorType.FATAL,
                    f"Fatal Starburst error: {error}",
                    error, False, True,
                )
        for pat in cls.RETRYABLE_PATTERNS:
            if re.search(pat, msg, re.IGNORECASE):
                return StarburstError(
                    StarburstErrorType.RETRYABLE,
                    f"Retryable Starburst error: {error}",
                    error, True, False,
                )
        for pat in cls.SKIPPABLE_PATTERNS:
            if re.search(pat, msg, re.IGNORECASE):
                return StarburstError(
                    StarburstErrorType.SKIPPABLE,
                    f"Skippable error: {error}",
                    error, False, False,
                )
        # Unknown — treat as retryable once; the chunk-level retry policy
        # decides whether to keep trying.
        return StarburstError(
            StarburstErrorType.RETRYABLE,
            f"Unknown error: {error}",
            error, True, False,
        )


# ──────────────────────────────────────────────────────────────────────
#  ScanPlan — the unifying abstraction
# ──────────────────────────────────────────────────────────────────────

class ScanMode(Enum):
    SINGLE = "single"
    PARTITION_VALUES = "partition_values"


# 2026-06-13 -- POLLING-ROW OVERLAY KEYS.
# Each tuple is (polling_row_column_name, path_in_job_config, coerce_type).
# `coerce_type` is one of: int, float, str, "bool", "literal" (no coerce).
# Path uses dots for nested dicts (e.g. "partition_config.enabled" creates
# job_config["partition_config"]["enabled"]).
#
# Operator adds these as columns to the polling query / Oracle table.
# Case-insensitive lookup -- both LOWER_CASE and UPPER_CASE column names
# work (Oracle drivers vary).  Empty / NULL columns are silently skipped
# so partial overrides work.
#
# Adding a new knob here: append the tuple.  Tests in
# test_sidecar_lifecycle.py::TestPollingRowOverlay lock the contract.
_POLLING_ROW_OVERLAYS: List[Tuple[str, str, Any]] = [
    # Partition mode (Fix D scope).
    ("partition_column",                  "partition_config.partition_column",   str),
    ("partition_enabled",                 "partition_config.enabled",            "bool"),
    ("partition_config_enabled",          "partition_config.enabled",            "bool"),
    ("max_partitions",                    "partition_config.max_partitions",     int),
    ("discovery_mode",                    "partition_config.discovery_mode",     str),
    # 2026-06-17 bucketing knobs -- group N adjacent values into one
    # chunk via WHERE col IN (...).  bucket_strategy='auto' converts
    # over-cap discovery into <= max_partitions chunks instead of
    # raising.  bucket_size overrides auto-computed size.
    ("bucket_strategy",                   "partition_config.bucket_strategy",    str),
    ("bucket_size",                       "partition_config.bucket_size",        int),
    # 2026-06-18 -- auto-skip partitioning for small datasets.  Trino
    # per-query overhead (~5-15s) dominates actual scan time for
    # tables below this many rows.  Default 10M; set 0 to disable.
    ("partition_min_rows",                "partition_config.partition_min_rows", int),
    # Escape hatch for OOM-prone queries: when TRUE, auto-skip is
    # bypassed -- partitioning runs regardless of discovery row count.
    # Use when query plan OOMs Trino in SINGLE mode (huge JOIN
    # intermediate, wide window function, etc) even though final row
    # count is small.
    ("force_partition",                   "partition_config.force_partition",    "bool"),
    # G1 acquisition (Fix E scope).
    ("derive_g1_from_discovery",          "derive_g1_from_discovery",            "bool"),
    ("skip_pre_flight_count",             "skip_pre_flight_count",               "bool"),
    # Disk-space pre-flight (Fix A scope).
    ("avg_row_bytes",                     "avg_row_bytes",                       int),
    ("disk_safety_factor",                "disk_safety_factor",                  float),
    ("skip_disk_check",                   "skip_disk_check",                     "bool"),
    # Streaming / retry / timeout knobs.
    ("writer_idle_timeout_seconds",       "writer_idle_timeout_seconds",         int),
    ("max_chunk_retries",                 "max_chunk_retries",                   int),
    ("batch_size",                        "batch_size",                          int),
    ("queue_maxsize",                     "queue_maxsize",                       int),
    ("max_concurrent_chunks",             "max_concurrent_chunks",               int),
    ("count_timeout_seconds",             "count_timeout_seconds",               int),
    ("fail_on_mismatch",                  "fail_on_mismatch",                    "bool"),
    # 2026-06-18 -- VarianceCheckAgainstPreviousCobRun step knobs.
    # Threshold + email targeting are flat keys (the variance step reads
    # them off task directly, no nested config_dict).
    ("variance_threshold_pct",            "variance_threshold_pct",              float),
    ("variance_email_to",                 "variance_email_to",                   str),
    ("email_on_variance_pass",            "email_on_variance_pass",              "bool"),
    ("fail_on_variance_breach",           "fail_on_variance_breach",             "bool"),
    # 2026-06-18 -- log relocation from polling row.  When LOGFILEPATH
    # is set, file_standalone moves the run log there at startup.  When
    # absent, the log goes under <OUTPUT_FILE_LOCATION>/_runtime/logs/
    # (if output_file_location is set) or the default ETL_LOG_DIR.
    ("log_file_path",                     "log_file_path",                       str),
]


def _coerce_polling_value(value: Any, coerce_type: Any) -> Any:
    """Type-coerce an Oracle polling-row value to the per-job JSON shape.

    Oracle returns strings / numbers / NULLs; YAML truthy strings
    ("TRUE", "Y", "1") must become Python booleans for the planner.
    """
    if value is None:
        return None
    if coerce_type == "bool":
        if isinstance(value, bool):
            return value
        s = str(value).strip().upper()
        if s in {"TRUE", "1", "YES", "Y", "T"}:
            return True
        if s in {"FALSE", "0", "NO", "N", "F"}:
            return False
        return None
    if coerce_type == "literal" or coerce_type is None:
        return value
    try:
        return coerce_type(value)
    except (TypeError, ValueError):
        return None


def _overlay_polling_row_onto_job_config(
    job_config: Dict[str, Any],
    task: Optional[Dict[str, Any]],
    logger=None,
) -> None:
    """Lift polling-row columns onto the per-job JSON config in place.

    Per knob, the polling row's value wins over the per-query JSON if
    set; otherwise the JSON's value stays.  Both UPPERCASE and lowercase
    column names are checked because Oracle drivers vary in how they
    surface column names.

    The polling row is the per-RUN task dict from the standalone; per-
    job JSON is the per-QUERY config the step loaded from
    ``task['sql_query_path']``.  Operator's request 2026-06-13: "I will
    add in polling query, can't modify queryjson" -- so the polling row
    now is the source-of-truth knob layer.
    """
    if not isinstance(task, dict):
        return
    applied: List[str] = []
    for polling_key, json_path, coerce_type in _POLLING_ROW_OVERLAYS:
        # Case-insensitive lookup -- check lower, UPPER, and the raw
        # field as-given (some Oracle drivers preserve mixed case).
        raw = (
            task.get(polling_key)
            if polling_key in task
            else (
                task.get(polling_key.upper())
                if polling_key.upper() in task
                else None
            )
        )
        if raw is None or raw == "":
            continue
        value = _coerce_polling_value(raw, coerce_type)
        if value is None:
            continue
        # Walk the dotted path, creating intermediate dicts as needed.
        parts = json_path.split(".")
        cursor = job_config
        for part in parts[:-1]:
            existing = cursor.get(part)
            if not isinstance(existing, dict):
                existing = {}
                cursor[part] = existing
            cursor = existing
        cursor[parts[-1]] = value
        applied.append(f"{polling_key}={value!r}")
    if applied and logger:
        logger.info(
            "Polling-row overlay applied %d knob(s) onto job_config: %s",
            len(applied), ", ".join(applied),
        )


@dataclass
class ScanPlan:
    """Immutable extract plan for one job (one report_id).

    DETERMINISM CONTRACT (audit #17): the same ``base_sql`` runs THREE
    times against Trino — once for G1 ``COUNT(*)`` pre-flight, once for
    per-partition ``COUNT(*)`` discovery, and N times for the per-value
    extracts.  If the SQL contains non-deterministic operands (``now()``,
    ``random()``, ``current_date``, a JOIN to a live-updating table, …)
    each invocation sees a different snapshot — G3 / G4 / G5 reconciles
    fire false-positive mismatches on otherwise-correct data.

    Operator responsibility: pin the snapshot in the source SQL — fix
    the business date, materialise a snapshot table, or freeze a Trino
    session property — BEFORE handing the SQL to this step.
    """
    mode: ScanMode
    base_sql: str
    expected_total: Optional[int]                    # G1 -- may be None when deferred (measured from extract)
    partition_column: Optional[str] = None
    partition_values: List[Any] = field(default_factory=list)
    expected_per_partition: Dict[Any, int] = field(default_factory=dict)
    batch_size: int = 100_000
    max_concurrent_chunks: int = 2
    max_chunk_retries: int = 2
    fail_on_mismatch: bool = True
    # CWriter back-pressure (fix #4) — operator can shrink for wide rows.
    queue_maxsize: int = 4
    # CWriter idle alarm (fix #8) — false-positive cap raised + tunable.
    writer_idle_timeout_seconds: int = 600
    # Per-job COUNT(*) timeout (fix #6) — Trino 120 M-row counts can
    # exceed the default request_timeout of 600 s on a busy cluster.
    count_timeout_seconds: int = 1800
    # 2026-06-13 -- where G1 came from for run-report transparency.
    # "pre-flight COUNT(*) [N.Ns]" / "partition discovery sum [N.Ns]" /
    # "deferred (measured from extract)" / "unmeasured".
    g1_source: str = "unknown"
    # 2026-06-18 -- VALUE-COLUMN CHECKSUM (CompletenessProbe).
    # Operator names numeric columns; ONE aggregate query against
    # ``base_sql`` produces ``source_checksums = {col: Decimal(sum)}``.
    # ChunkWriter + consolidate steps re-sum the SAME columns while
    # streaming through their own files.  G5 then compares the source
    # sums against the consolidated sums -- catches silent row drop /
    # row duplication that row-count G1 cannot see when ``base_sql``
    # has shape-affecting DISTINCT / GROUP BY.
    #
    # Why this is robust under shape-effects: the SUM runs over
    # ``(base_sql) AS t`` -- post-aggregation, exactly the same rows
    # the extract emits.  Apples to apples by construction.
    # Empty list (default) = checksum check disabled (existing
    # behaviour).
    checksum_columns: List[str] = field(default_factory=list)
    source_checksums: Dict[str, Any] = field(default_factory=dict)
    # 2026-06-20 -- ProbeQuery output: per-partition column SUMs.
    # Populated when the planner used the strategic ProbeQuery primitive
    # (one GROUP BY shuffle for count + sums) instead of three separate
    # full-table scans.  Shape: {partition_value: {col_name: Decimal}}.
    # ChunkWriter accumulates the SAME columns while streaming each chunk;
    # per-chunk gate compares against expected_per_partition_sums[v] for
    # early-detection of source drift at chunk close (vs current
    # end-of-job-only G5 SUM gate).  Empty when ProbeQuery skipped
    # (shape-affecting base_sql) or when checksum_columns not requested.
    expected_per_partition_sums: Dict[Any, Dict[str, Any]] = field(default_factory=dict)

    @property
    def chunk_count(self) -> int:
        return 1 if self.mode == ScanMode.SINGLE else len(self.partition_values)

    @property
    def sum_partition_expected(self) -> Optional[int]:
        """G2 anchor -- sum of per-partition expected counts.

        2026-06-17 -- returns ``None`` (NOT 0) when no per-partition
        counts are available, so the run-report G2 chip is SKIPPED
        rather than FAILED.  Returning 0 used to fire a permanent
        "G2 FAIL: 0 != G1" in two legitimate cases:

          * SINGLE mode -- there's no partition plan to validate.
          * PARTITION_VALUES + distinct discovery -- values are known
            but per-partition COUNT(*) was deferred to chunk-execution
            (G2 is advisory-only in distinct mode, per the docstring
            on _discover_partition_values).

        Aggregators (file_base, spark_base) propagate None correctly:
        if ANY job's value is None, the aggregate is None -- mixed
        means the chip is meaningless.
        """
        return sum(self.expected_per_partition.values()) if self.expected_per_partition else None


# ──────────────────────────────────────────────────────────────────────
#  ChunkResult
# ──────────────────────────────────────────────────────────────────────

@dataclass
class ChunkResult:
    partition_index: int
    partition_value: Any
    file_path: str
    expected: Optional[int]
    actual: int
    attempts: int
    duration_sec: float
    success: bool
    error: Optional[str] = None
    error_type: Optional[StarburstErrorType] = None
    should_stop_process: bool = False
    # 2026-06-21 -- Trino-pressure diagnostic.  queue_wait_sec is the
    # time spent in Trino's coordinator queue + plan phase BEFORE the
    # first row arrived; stream_sec is the active row-streaming time
    # after first batch.  A chunk where queue_wait >> stream tells the
    # operator the cluster is queueing -- lower trino_profile or raise
    # MAX_CONCURRENT_CHUNKS_CEILING.
    queue_wait_sec: Optional[float] = None
    stream_sec: Optional[float] = None


# ──────────────────────────────────────────────────────────────────────
#  StarburstConnection — thin trino.dbapi wrapper, fail-loud
# ──────────────────────────────────────────────────────────────────────

class StarburstConnection:
    """Minimal Trino cursor wrapper used by the file extract.

    Single responsibility: open a cursor, execute a query, expose
    ``fetchmany`` streaming.  Error categorization happens at the
    caller so we don't muddle the abstraction.
    """

    def __init__(self, config: Dict[str, Any], logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.connection = None
        self.cursor = None
        # 2026-06-12 — when populated by the step, ``execute()`` registers
        # the trino cursor on this task's _starburst_resources list so an
        # outer asyncio cancel can call cursor.cancel() from a different
        # thread (the cursor.execute one is blocked in fetchmany).
        self.task: Optional[Dict[str, Any]] = None
        self._cancellable = None

    async def connect(self) -> None:
        # Fix #16 — TCP + SSL + auth on the Trino DBAPI is fully sync.
        # Without to_thread, every concurrent partition's connect
        # serialised the event loop.
        import trino

        # 2026-06-22 -- TCP preflight is OPT-IN (was causing prod outages
        # when probe failed in environments where the JDBC driver could
        # otherwise connect).  Skip by default; enable via
        # TRINO_JDBC_ENABLE_PREFLIGHT=1 for debugging.
        if os.environ.get("TRINO_JDBC_ENABLE_PREFLIGHT", "").lower() in ("1", "true", "yes"):
            try:
                from managers.trino_jdbc_preflight import tcp_preflight
                fake_url = (
                    f"jdbc:trino://{self.config['host']}:{self.config['port']}/"
                    f"{self.config.get('catalog', '')}/{self.config.get('schema', '')}"
                    f"?SSL={'true' if self.config.get('use_ssl', True) else 'false'}"
                )
                tcp_preflight(fake_url, timeout=5.0, logger=self.logger)
            except ImportError:
                pass

        try:
            auth = trino.auth.BasicAuthentication(
                self.config["user"], self.config["password"],
            )
            # 2026-06-21 -- ORPHAN-QUERY DETECTION TAGS.  Every Trino
            # query this session runs gets stamped with client_tags so
            # a future startup of the same RUN_ID can find + kill leftover
            # queries from a crashed prior run.  Tag format is stable
            # across releases so cleanup queries are forward-compatible.
            #
            # Tags built from self.config['client_tags'] (set by the
            # step from task['run_id'] / fk_report_id / business_date).
            # Empty default keeps back-compat for callers who don't set them.
            _client_tags = self.config.get("client_tags") or []
            _connect_kwargs = dict(
                host=self.config["host"],
                port=self.config["port"],
                user=self.config["user"],
                catalog=self.config["catalog"],
                schema=self.config["schema"],
                http_scheme="https" if self.config.get("use_ssl", True) else "http",
                auth=auth,
                verify=self.config.get("verify", False),
                request_timeout=self.config.get("request_timeout", 600),
            )
            if _client_tags:
                # trino.dbapi.connect accepts client_tags as a list/set
                # of strings (renders into X-Trino-Client-Tags header).
                _connect_kwargs["client_tags"] = list(_client_tags)
            self.connection = await asyncio.to_thread(
                trino.dbapi.connect, **_connect_kwargs,
            )
            self.cursor = self.connection.cursor()
            self.logger.info(
                "Starburst connected: host=%s catalog=%s schema=%s "
                "client_tags=%s",
                self.config["host"], self.config["catalog"],
                self.config["schema"], _client_tags or "(none)",
            )
        except Exception as exc:
            err = StarburstErrorClassifier.classify(exc)
            self.logger.error("Starburst connect failed (%s): %s", err.error_type.value, exc)
            raise

    async def execute(self, sql: str) -> None:
        if not self.cursor:
            raise RuntimeError("StarburstConnection.execute called before connect()")
        # 2026-06-17 -- log the FULL SQL Trino sees, on its own block.
        # Pre-fix this was truncated to 200 chars which hid the AST-injected
        # partition predicate (typically near the END of a long JOIN+WHERE
        # query).  Operators couldn't tell which chunk was running, or
        # whether the rewrite produced what they expected.
        #
        # The compact one-line snippet stays for quick grep / triage; the
        # full block follows, framed with `<<<SQL>>>` markers so log
        # post-processors can extract it without false-positives.
        compact = " ".join(sql.split())
        compact_snip = compact[:200]
        size_note = f" ({len(sql)} chars)" if len(sql) > 200 else ""
        self.logger.info(
            "Executing Starburst SQL%s: %s%s",
            size_note, compact_snip, "..." if len(sql) > 200 else "",
        )
        self.logger.info("<<<SQL>>>\n%s\n<<<END_SQL>>>", sql)

        # 2026-06-22 -- DEGENERATE-SUBSTITUTION GUARD.  Operator hit
        # "connect to starburst but don't see any query running" because
        # the SQL had ``=CAST('' AS DATE)`` or ``=''`` -- Trino runs
        # these in microseconds returning 0 rows.  Query appears in
        # COMPLETED history, never in RUNNING.  Warn LOUD so the
        # operator knows to check the polling-row inputs.
        _degenerate_markers = (
            ("=CAST('' AS",  "empty business_date/date column (CAST('') in WHERE)"),
            ("= CAST('' AS", "empty business_date/date column (CAST('') in WHERE)"),
            ("=''",           "empty parameter (= '' in WHERE)"),
            ("= ''",          "empty parameter (= '' in WHERE)"),
        )
        for marker, label in _degenerate_markers:
            if marker in sql:
                self.logger.warning(
                    "Starburst SQL has DEGENERATE substitution: %s.\n"
                    "  Marker found: %r\n"
                    "  Trino will run this in <1s returning 0 rows -- "
                    "the query will appear in Trino's COMPLETED history, "
                    "NOT in RUNNING queries.\n"
                    "  Operator action: verify the polling-row "
                    "BUSINESS_DATE / SYSTEM_ENTITY / EventCode (or "
                    "equivalent placeholder source) is non-empty.",
                    label, marker,
                )
                break
        # 2026-06-12 — register the cursor so the workflow runner can
        # cancel server-side if the outer asyncio context times out.
        # Idempotent: re-execute on the same connection updates the
        # handle in place.
        if self.task is not None and self._cancellable is None:
            try:
                from starburst_cancellation import (
                    StarburstCancellable, KIND_TRINO_CURSOR,
                    register_starburst_cancellable,
                )
                self._cancellable = StarburstCancellable(
                    KIND_TRINO_CURSOR, cursor=self.cursor,
                    label="StarburstConnection",
                )
                register_starburst_cancellable(self.task, self._cancellable)
            except Exception as exc:
                self.logger.warning(
                    "Could not register Starburst cancellable: %s", exc,
                )
        try:
            # Fix #16 — execute submits the query + waits for the first
            # response from the coordinator.  Wrap in to_thread so other
            # partitions can submit + fetch in parallel.
            await asyncio.to_thread(self.cursor.execute, sql)
            # 2026-06-22 -- surface the Trino-assigned query_id so the
            # operator can find this exact query in the Trino UI's
            # COMPLETED history (when "no query running" is reported,
            # the query usually completed in <1s and shows up there).
            try:
                qid = getattr(self.cursor, "query_id", None) or "?"
                stats = getattr(self.cursor, "stats", None) or {}
                state = stats.get("state") if isinstance(stats, dict) else None
                self.logger.info(
                    "Trino accepted query: query_id=%s state=%s.  "
                    "Look up in Trino UI -> Query History -> "
                    "Query ID = %s",
                    qid, state or "(unknown)", qid,
                )
            except Exception:
                pass
        except Exception as exc:
            err = StarburstErrorClassifier.classify(exc)
            self.logger.error("Starburst execute failed (%s): %s", err.error_type.value, exc)
            raise

    async def fetch_scalar(self, sql: str) -> Optional[Any]:
        """Run a single-row single-column query (e.g. COUNT(*))."""
        await self.execute(sql)
        # Fix #16 — fetchone is also blocking; even though scalar
        # results are tiny, we don't want the event loop stalling.
        row = await asyncio.to_thread(self.cursor.fetchone)
        return row[0] if row else None

    def get_columns(self) -> List[str]:
        if not self.cursor or not self.cursor.description:
            raise RuntimeError("get_columns called before execute()")
        return [d[0] for d in self.cursor.description]

    async def fetch_chunks(self, batch_size: int) -> AsyncGenerator[List[Tuple], None]:
        """Stream the result set in fetchmany(batch_size) batches.

        Yields raw row tuples — no DataFrame intermediate so we don't
        pay pandas overhead on every batch.  Caller writes directly to
        the chunk file.

        Fix #7 — ``cursor.fetchmany`` is SYNC + blocking.  Without the
        ``asyncio.to_thread`` wrap the entire event loop stalls for
        every fetch, defeating ``max_concurrent_chunks``.  With the
        wrap, the fetch happens on a worker thread + the event loop is
        free to drive other concurrent chunks' fetches in parallel.
        """
        if not self.cursor:
            raise RuntimeError("fetch_chunks called before execute()")
        while True:
            rows = await asyncio.to_thread(self.cursor.fetchmany, batch_size)
            if not rows:
                return
            yield rows

    async def close(self) -> None:
        # Fix #16 — both cursor.close() and connection.close() are
        # blocking (cursor sends a DELETE to the Trino coordinator).
        # 2026-06-12 — unregister the cancel handle FIRST so the runner
        # doesn't try to cancel a cursor we're about to close cleanly.
        if self.task is not None and self._cancellable is not None:
            try:
                from starburst_cancellation import unregister_starburst_cancellable
                unregister_starburst_cancellable(self.task, self._cancellable)
            except Exception:
                pass
            self._cancellable = None
        try:
            if self.cursor:
                await asyncio.to_thread(self.cursor.close)
        except Exception:
            pass
        try:
            if self.connection:
                await asyncio.to_thread(self.connection.close)
        except Exception:
            pass

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.close()


# ──────────────────────────────────────────────────────────────────────
#  Chunk writer — single producer / single consumer queue
# ──────────────────────────────────────────────────────────────────────

# Fix #2 — strip embedded \n / \r from every cell BEFORE writing.
# Why: ConsolidateFiles' G5 reconcile counts physical lines.  A cell
# with embedded \n produces extra physical lines without producing
# extra rows -> false G5 mismatch.  Even a csv.writer with QUOTE_MINIMAL
# would write the literal \n inside quotes, defeating line-count-based
# reconcile.  Stripping at the source keeps the contract simple:
# row_count == physical_line_count - 1 (header).
def _convert_cell(val: Any) -> str:
    """Canonical string conversion for a row cell.

    Critical contract:
      * None         -> empty string
      * float NaN    -> empty string (pandas-style 'nan' literal banned)
      * Embedded \\n / \\r / \\t -> single space (preserves cell count)
      * everything else -> str(val)
    """
    if val is None:
        return ""
    if isinstance(val, float) and val != val:  # NaN check w/o pandas import
        return ""
    s = str(val)
    if s == "nan":
        return ""
    # Strip line-end + tab so downstream line-counting reconcile holds.
    if "\r" in s or "\n" in s or "\t" in s:
        s = s.replace("\r\n", " ").replace("\r", " ").replace("\n", " ").replace("\t", " ")
    return s


class ChunkWriter:
    """Writes a single chunk file using a bounded queue.

    Memory bound: queue holds at most ``maxsize`` batches.  At
    ``batch_size=100k`` and ~150 bytes/row that's ~15 MB per queued
    batch; maxsize=4 caps at 60 MB.  For wide tables (200+ cols, ~2 KB/row)
    drop ``queue_maxsize`` to 2 + ``batch_size`` to 25_000 to keep the
    peak under 100 MB per chunk.

    Writes header on first batch, fsync on close.  Returns the row
    count actually written.

    Fix #1 — uses csv.writer with QUOTE_MINIMAL so cells containing the
    output delimiter are properly quoted.  Combined with the embedded
    newline strip in ``_convert_cell``, the output is BOTH a
    well-formed CSV AND has one physical line per data row (so the
    cheap line-count reconcile downstream works).

    Fix #4 — ``queue_maxsize`` is now operator-configurable per job.
    Fix #8 — ``idle_timeout_seconds`` raised from 180 s to a tunable
    default 600 s.  Slow Trino renders on 120 M-row partitions can
    legitimately gap 3-5 min between fetchmany returns.
    """

    def __init__(
        self,
        file_path: str,
        columns: List[str],
        delimiter: str,
        logger: logging.Logger,
        write_bom: bool = False,
        queue_maxsize: int = 4,
        idle_timeout_seconds: int = 600,
        sum_columns: Optional[List[str]] = None,
        first_batch_timeout_seconds: int = 1800,
    ):
        self.file_path = file_path
        self.columns = columns
        self.delimiter = delimiter
        self.logger = logger
        self.write_bom = write_bom
        self.idle_timeout = max(60, int(idle_timeout_seconds))
        # 2026-06-20 deep-dive (post-pilot): pre-first-batch wait is
        # DIFFERENT from idle-after-first-batch.  Pre-first-batch is
        # Trino COORDINATOR QUEUEING (legitimate -- a busy cluster can
        # queue a query for 5-10+ minutes before scheduling it).  Idle
        # after first-batch is lost connection / Trino crash / network
        # drop.  Two thresholds with different semantics:
        #   * first_batch_timeout: how long to wait for the very first
        #     batch (default 30 min -- accommodates busy cluster queueing)
        #   * idle_timeout: how long between subsequent batches (default
        #     10 min -- once data flows, gaps shouldn't be that long)
        self.first_batch_timeout = max(60, int(first_batch_timeout_seconds))
        self.records_written = 0
        self._queue: Queue = Queue(maxsize=max(1, int(queue_maxsize)))
        self._thread: Optional[threading.Thread] = None
        self._error: Optional[BaseException] = None
        # 2026-06-20 -- per-column SUM accumulators for the per-chunk
        # completeness gate.  Resolved against the SELECT projection at
        # _run time: each named column's index is computed from
        # ``self.columns`` and rows' values are added as Decimal.
        # Empty / None / non-numeric cells skip silently (first non-numeric
        # cell on a column drops that column from the accumulator so
        # subsequent rows don't poison the sum).  Caller reads
        # ``self.sums`` at chunk close and compares against
        # ``plan.expected_per_partition_sums[v]``.
        from decimal import Decimal as _Dec
        self._sum_column_names: List[str] = list(sum_columns or [])
        self.sums: Dict[str, Any] = {c: _Dec(0) for c in self._sum_column_names}
        # Phase 152 observability: timing markers for the slowest-chunk
        # diagnostic.  Set by _run() as the writer transitions through
        # phases.  Caller reads these post-join to surface in result.html.
        self.time_started: Optional[float] = None       # writer thread start
        self.time_first_batch: Optional[float] = None   # first non-None batch arrived
        self.time_completed: Optional[float] = None     # signal_end seen + file flushed

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._run, name=f"chunk-writer-{os.path.basename(self.file_path)}",
            daemon=False,
        )
        self._thread.start()

    def put_batch(self, batch: List[Tuple], timeout: float = 120.0) -> None:
        """Push a batch — blocks if the queue is full (back-pressure)."""
        self._queue.put(batch, timeout=timeout)

    def signal_end(self, timeout: float = 60.0) -> None:
        for _ in range(5):
            try:
                self._queue.put(None, timeout=timeout)
                return
            except queue.Full:
                time.sleep(1)
        raise RuntimeError(f"ChunkWriter: could not signal end-of-stream for {self.file_path}")

    def join(self, timeout: float = 1800.0) -> None:
        if self._thread:
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                raise RuntimeError(f"ChunkWriter: writer thread timed out for {self.file_path}")
        if self._error is not None:
            raise self._error

    def _run(self) -> None:
        try:
            encoding = "utf-8-sig" if self.write_bom else "utf-8"
            os.makedirs(os.path.dirname(self.file_path) or ".", exist_ok=True)
            # 2026-06-20 -- resolve sum-column indices from the projection
            # column names.  Missing-from-projection columns warn once and
            # drop out of self.sums so the caller sees the gap.
            from decimal import Decimal as _Dec, InvalidOperation as _InvOp
            sum_indices: Dict[str, int] = {}
            if self._sum_column_names:
                _by_name = {n: idx for idx, n in enumerate(self.columns)}
                missing = [c for c in self._sum_column_names if c not in _by_name]
                if missing:
                    self.logger.warning(
                        "ChunkWriter %s: checksum_columns %s missing from "
                        "projection %s -- dropping from per-chunk sum "
                        "accumulator.",
                        os.path.basename(self.file_path), missing,
                        self.columns,
                    )
                    for c in missing:
                        self.sums.pop(c, None)
                sum_indices = {
                    c: _by_name[c]
                    for c in self._sum_column_names if c in _by_name
                }
            self.time_started = time.time()
            with open(self.file_path, "w", encoding=encoding, buffering=4 * 1024 * 1024, newline="") as f:
                writer = csv.writer(
                    f, delimiter=self.delimiter,
                    quoting=csv.QUOTE_MINIMAL, lineterminator="\n",
                )
                writer.writerow(self.columns)
                while True:
                    # 2026-06-20 deep-dive: use the longer first_batch_timeout
                    # BEFORE the first batch arrives (Trino coordinator
                    # queueing is normal on busy clusters and can take
                    # 5-30 min); switch to the shorter idle_timeout AFTER
                    # data starts flowing (gaps in active stream signal
                    # network / cluster issues).
                    _eff_timeout = (
                        self.first_batch_timeout
                        if self.time_first_batch is None
                        else self.idle_timeout
                    )
                    try:
                        batch = self._queue.get(timeout=_eff_timeout)
                    except queue.Empty:
                        _phase = (
                            "PRE-FIRST-BATCH (Trino likely still queueing "
                            "or planning the query)"
                            if self.time_first_batch is None
                            else "MID-STREAM (Trino likely lost connection)"
                        )
                        self._error = TimeoutError(
                            f"ChunkWriter timeout {_eff_timeout}s for "
                            f"{self.file_path} ({_phase}).  Rows written "
                            f"before timeout: {self.records_written:,}"
                        )
                        return
                    if batch is None:
                        self._queue.task_done()
                        break
                    # 2026-06-20 -- timing marker: first batch arrived.
                    # Captures the COORDINATOR QUEUE + PLAN time so the
                    # slowest-chunk diagnostic can show operators where
                    # the time went (queue-wait vs actual stream time).
                    if self.time_first_batch is None:
                        self.time_first_batch = time.time()
                        _queue_wait = self.time_first_batch - (self.time_started or self.time_first_batch)
                        self.logger.info(
                            "ChunkWriter %s: FIRST BATCH after %.1fs "
                            "(Trino queue/plan + first-batch fetch)",
                            os.path.basename(self.file_path), _queue_wait,
                        )
                    # csv.writer writes one CSV-escaped row per writerow,
                    # delimiter-aware (Fix #1).  Cells already had \n /
                    # \r stripped by _convert_cell (Fix #2), so the
                    # output is also free of embedded line breaks.
                    for row in batch:
                        writer.writerow([_convert_cell(c) for c in row])
                        self.records_written += 1
                        # 2026-06-20 -- accumulate per-column SUMs for the
                        # per-chunk completeness gate.  RAW row values
                        # (pre-_convert_cell) used so numeric types come
                        # through unmangled.  Skipping rules:
                        #   * None / NaN -> skip
                        #   * non-numeric cell -> warn once + drop column
                        for col, idx in list(sum_indices.items()):
                            if idx >= len(row):
                                continue
                            v = row[idx]
                            if v is None:
                                continue
                            if isinstance(v, float) and v != v:  # NaN
                                continue
                            try:
                                self.sums[col] = self.sums.get(col, _Dec(0)) + _Dec(str(v))
                            except (_InvOp, ValueError):
                                self.logger.warning(
                                    "ChunkWriter %s: column %r row %d "
                                    "value %r is non-numeric -- dropping "
                                    "column from per-chunk sum accumulator.",
                                    os.path.basename(self.file_path),
                                    col, self.records_written, v,
                                )
                                sum_indices.pop(col, None)
                                self.sums.pop(col, None)
                    self._queue.task_done()
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
            self.time_completed = time.time()
        except Exception as exc:
            self._error = exc
            self.time_completed = time.time()


# ──────────────────────────────────────────────────────────────────────
#  Orphan-query cleanup -- module-level so callers without a step
#  instance (file_standalone.main) can invoke without constructing a
#  temporary StarburstToFileOnCloud (audit-flagged anti-pattern,
#  2026-06-21).  The StarburstFileBase method below is a thin shim.
# ──────────────────────────────────────────────────────────────────────


async def kill_orphan_trino_queries(
    connection_config: Dict[str, Any],
    run_id: Any,
    logger: logging.Logger,
    task: Optional[Dict] = None,
) -> int:
    """Find + kill leftover Trino queries from a crashed prior run.

    2026-06-21 -- post-pilot fix for the network-disconnect scenario:
    operator runs file_standalone, downloads 6 of 8 chunks, network
    drops, the 2 in-flight Trino queries KEEP RUNNING on the cluster
    because no client cancelled them.  Operator restarts the workflow
    -> 2 new chunks contend with 2 orphan chunks writing to the same
    staging dir.  Files collide, completeness gates fail.

    Fix: every Trino query is tagged with ``qs_run:<run_id>`` (see
    StarburstConnection.connect).  This helper scans the cluster for
    queries with that tag in RUNNING / QUEUED / PLANNING state, kills
    them via ``CALL system.runtime.kill_query``, and returns the count
    killed.

    SAFETY GUARANTEES:
      * Only kills queries with the SAME run_id tag -- never touches
        another run's work.
      * KILL is best-effort: a query that finishes naturally between
        scan + KILL is fine.
      * Returns 0 + logs INFO when system.runtime is restricted (older
        Trino, role doesn't have system.runtime privileges).
      * Bounded 30s total runtime.  Never blocks the main run.
      * Single Trino connection reused for scan + all kills (~1s
        total vs N seconds when opening connection per kill).
    """
    if run_id is None:
        return 0
    find_sql = (
        "SELECT query_id, state, started, user FROM system.runtime.queries "
        "WHERE state IN ('RUNNING', 'QUEUED', 'PLANNING') "
        f"AND contains(client_tags, 'qs_run:{run_id}')"
    )
    cfg = dict(connection_config)
    cfg["request_timeout"] = 30
    cfg.pop("client_tags", None)  # cleanup scan shouldn't tag itself
    killed = 0
    orphans: List[Dict[str, Any]] = []
    try:
        async with StarburstConnection(cfg, logger) as conn:
            conn.task = task
            await conn.execute(find_sql)
            async for batch in conn.fetch_chunks(100):
                for row in batch:
                    try:
                        orphans.append({
                            "query_id": str(row[0]),
                            "state":    str(row[1]),
                            "started":  str(row[2]),
                            "user":     str(row[3]),
                        })
                    except (IndexError, TypeError):
                        continue
    except Exception as exc:
        logger.info(
            "Orphan-query scan failed (%s) -- skipping cleanup.  If your "
            "Trino role lacks system.runtime access, set skip_orphan_kill="
            "true on the polling row to silence.", exc,
        )
        return 0

    if not orphans:
        logger.info(
            "Orphan-query scan: no leftover queries from prior runs of "
            "run_id=%s found.  Clean startup.", run_id,
        )
        return 0

    logger.warning(
        "Orphan-query scan: %d leftover Trino quer%s from prior run_id=%s "
        "-- KILLING via system.runtime.kill_query:\n%s",
        len(orphans), "y" if len(orphans) == 1 else "ies", run_id,
        "\n".join(
            f"  query_id={o['query_id']} state={o['state']} "
            f"started={o['started']} user={o['user']}"
            for o in orphans
        ),
    )
    # Single connection for ALL kills -- TLS handshake amortised.
    try:
        async with StarburstConnection(cfg, logger) as conn:
            conn.task = task
            for o in orphans:
                kill_sql = (
                    f"CALL system.runtime.kill_query("
                    f"query_id => '{o['query_id']}', "
                    f"message => 'Killed by qs ETL restart cleanup (run_id={run_id})'"
                    f")"
                )
                try:
                    await conn.execute(kill_sql)
                    killed += 1
                    logger.info(
                        "Killed orphan query %s (was %s)",
                        o["query_id"], o["state"],
                    )
                except Exception as exc:
                    logger.warning(
                        "kill_query for %s raised (%s) -- query may have "
                        "completed naturally before kill landed, or role "
                        "lacks kill privilege.", o["query_id"], exc,
                    )
    except Exception as exc:
        logger.warning(
            "Could not open Trino connection for orphan kills (%s) -- "
            "skipping cleanup; orphans will run to natural completion.",
            exc,
        )
    logger.warning(
        "Orphan-query cleanup: killed %d of %d leftover queries for "
        "run_id=%s.  Safe to proceed with new run.",
        killed, len(orphans), run_id,
    )
    return killed


# ──────────────────────────────────────────────────────────────────────
#  Base step
# ──────────────────────────────────────────────────────────────────────

class StarburstFileBase(BaseStep):
    """Shared extract logic for cloud / onprem / by-partitions variants.

    Subclasses provide:
        DATASOURCE_NAME  — "CLOUD" or "ONPREM" (filters jobs from query_config)
        LOG_PREFIX       — for the per-step logger name
        FORCE_MODE       — Optional[ScanMode]; when set, every job uses it
                           regardless of per-job config.  Used by the
                           ``by_partitions`` step to force PARTITION_VALUES.

    Subclasses can override ``_build_connection_config`` if their cred
    sourcing diverges (the default reads cloud-vs-onprem credentials
    from the ini file).
    """

    DATASOURCE_NAME: str = ""
    LOG_PREFIX: str = "starburst_file"
    FORCE_MODE: Optional[ScanMode] = None

    DEFAULT_BATCH_SIZE = 100_000
    DEFAULT_MAX_CONCURRENT = 2
    DEFAULT_MAX_RETRIES = 2

    # ----- Setup & config ------------------------------------------------

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ini_config: Optional[configparser.ConfigParser] = None
        self.query_config: Optional[Dict[str, Any]] = None
        self.run_report: Optional[FileRunReport] = None
        self.artifacts: Optional[RunArtifacts] = None

    def _load_ini_config(self) -> configparser.ConfigParser:
        cfg = configparser.ConfigParser()
        path = os.getenv(
            "EXPORT_TOOL_CONFIG_PATH",
            "/usr/local/spark/pvc/code/configs/export_tool_config.ini",
        )
        cfg.read(path)
        return cfg

    def _load_query_config(self, json_path: str) -> Dict[str, Any]:
        if not json_path:
            raise ValueError("task['sql_query_path'] is required to load query config")
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"Query config JSON not found: {json_path}")
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _setup_logging(self, task: Dict) -> None:
        """Pin to the run-log file from task['log_file'] so the entire
        run lands in one file end-to-end."""
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)

        log_path = task.get("log_file")
        if not log_path:
            # 2026-06-12 -- NO /tmp fallback.  OpenShift pods have tiny
            # ephemeral storage; logs MUST land on the configured NFS
            # path (ETL_LOG_DIR env / YAML / POSIX default).  A missing
            # log_config is a deployment break -- fail loudly here so
            # ops sees it instead of silently writing to /tmp.
            from log_config import get_log_dir as _ld
            base = _ld()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log")
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError as exc:
            self.logger.warning("Cannot create log file %s: %s — console only", log_path, exc)

    def _get_run_report(self, task: Dict) -> FileRunReport:
        rr = task.get("_run_report")
        if isinstance(rr, FileRunReport):
            return rr
        output_dir = task.get("output_dir") or task.get("OUTPUT_DIR") or ""
        rr = FileRunReport(output_dir=output_dir, logger=self.logger)
        rr.set_context(
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
        )
        task["_run_report"] = rr
        return rr

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """Default cred sourcing: ini[Starburst] user/password + per-job server/port.

        Override per subclass when cloud/onprem credentials live in
        different ini sections.
        """
        ini = self.ini_config or configparser.ConfigParser()
        section = "Starburst"
        return {
            "host": job_config["server_name"],
            "port": int(job_config["port"]),
            "user": ini.get(section, "username", fallback="") if ini.has_section(section) else "",
            "password": ini.get(section, "password", fallback="") if ini.has_section(section) else "",
            "catalog": ini.get(section, "catalog", fallback="") if ini.has_section(section) else "",
            "schema": ini.get(section, "schema", fallback="") if ini.has_section(section) else "",
            "use_ssl": True,
            "verify": False,
            "request_timeout": int(job_config.get("request_timeout", 600)),
        }

    def _shared_starburst_fallback(self, endpoint: str) -> Dict[str, str]:
        """2026-06-12 — return creds from configs/starburst_config.yaml.

        ``endpoint`` is ``"oncloud"`` or ``"onprem"``.  Returns a dict
        with ``user``, ``password``, ``catalog``, ``schema`` keys
        (empty strings when absent).  Used by subclass
        ``_build_connection_config`` methods as the FINAL fallback
        after the INI file and per-job JSON have been consulted —
        callers OR on each field so this only fills blanks.

        Silently no-ops when the loader isn't importable (older Spark
        images without the loader baked in) — degraded back-compat,
        existing INI / JSON paths still work.
        """
        try:
            from starburst_config_loader import shared_creds_for
            return shared_creds_for(endpoint)
        except Exception:
            return {"user": "", "password": "", "url": "",
                    "host": "", "port": "443", "catalog": "", "schema": ""}

    def _filter_jobs(self) -> List[Dict[str, Any]]:
        if not self.query_config:
            return []
        jobs = self.query_config.get("jobs", []) or []
        return [j for j in jobs if str(j.get("datasource_name", "")).upper() == self.DATASOURCE_NAME]

    # ----- Output file plumbing ----------------------------------------

    @staticmethod
    def _safe_partition_label(value: Any) -> str:
        # 2026-06-17 -- bucketing: when ``value`` is a tuple/list (bucket
        # of N partition values), render compactly as
        # ``<first>_to_<last>_<N>v`` so chunk filenames stay readable
        # AND unique.  ``str((v1,v2,...))`` would produce
        # ``__v1___v2___v3__...`` truncated to 60 chars -- risk of
        # collision between buckets sharing a common prefix.
        if isinstance(value, (list, tuple)) and len(value) > 1:
            members = list(value)
            first = str(members[0]) if members[0] is not None else "NULL"
            last = str(members[-1]) if members[-1] is not None else "NULL"
            raw = f"{first}_to_{last}_{len(members)}v"
        else:
            # Single-value bucket OR scalar -- unwrap one-element list/tuple.
            if isinstance(value, (list, tuple)):
                value = value[0] if value else None
            raw = str(value) if value is not None else "NULL"
        return re.sub(r"[^A-Za-z0-9_\-]+", "_", raw)[:60] or "NULL"

    def _resolve_output_paths(
        self, job_config: Dict[str, Any], run_id: Any = None,
    ) -> Tuple[str, str, str, str, str]:
        """Returns (output_dir, staging_dir, base_filename, output_ext, delimiter).

        2026-06-18 -- STAGING DIR per extract.  Chunks land under a
        sub-directory of the polling-row's ``output_file_location`` so
        the mapped folder stays clean (only final consolidated files
        visible to end-users / downstream consumers).

        Path: ``<output_dir>/.staging_<run_id>_<DATASOURCE>_<YYYYMMDD_HHMMSS>``

        Run_id + datasource keeps it unique even when CLOUD + ONPREM
        share the same mapped dir.  Timestamp suffix prevents collision
        if the same run_id is replayed (sticky run ids in dev).
        Dot-prefix hides it from default ``ls`` listings on POSIX +
        marks it as "internal" so operators don't ship it by mistake.

        Same volume as output_dir -> ``os.replace`` of the per-source
        consolidated file from staging to mapped is atomic + instant
        (no cross-volume byte copy).
        """
        output_dir = job_config.get("output_file_location") or ""
        if not output_dir:
            raise ValueError(
                f"job {job_config.get('report_id')}: output_file_location is empty"
            )
        os.makedirs(output_dir, exist_ok=True)
        full_name = job_config.get("output_file_name") or f"report_{job_config.get('report_id')}.csv"
        # Split last extension only — supports filenames with dots in the stem
        if "." in full_name:
            base, ext = full_name.rsplit(".", 1)
        else:
            base, ext = full_name, "csv"
        delimiter = job_config.get("output_file_delimiter", "|")

        # Build staging path.  run_id may be None (legacy callers); fall
        # back to the report_id + pid + timestamp to keep uniqueness.
        # Fix A (2026-06-18) -- microsecond + pid in timestamp so two
        # invocations within the same wall-clock second don't collide
        # (matters in dev replays of sticky run-ids).
        _now = datetime.now()
        _ts = _now.strftime("%Y%m%d_%H%M%S") + f"_{_now.microsecond:06d}_p{os.getpid()}"
        _run_tag = str(run_id) if run_id is not None else (
            f"{job_config.get('report_id', 'noid')}_p{os.getpid()}"
        )
        _ds_tag = (self.DATASOURCE_NAME or "EXTRACT").upper()

        # 2026-06-18 -- TWO-LAYER auto cleanup (user policy: no manual
        # intervention ever).
        #
        #   LAYER 1: end-of-process cleanup in _execute_step's try/
        #            finally.  Normal success/failure exit -> staging
        #            rmtree'd.  Honours preserve_chunks_on_failure.
        #
        #   LAYER 2: startup scan HERE.  Handles the orphan case where
        #            LAYER 1 never ran -- SIGKILL / OOM-killer / power
        #            loss / machine restart.  Without this scan, those
        #            orphans accumulate forever in the mapped folder.
        #            Bounded scope: ONLY touches dirs that match the
        #            CURRENT run_id + DATASOURCE prefix (never deletes
        #            another run's work).  Best-effort: any failure is
        #            WARN-logged + the new staging dir is still created.
        try:
            import re as _re
            import shutil as _shutil
            # Staging dir name always ends with _p<PID>.  Orphan = PID
            # no longer alive (crashed run never reached finally
            # cleanup).  PID alive = another concurrent extract sharing
            # this mapped folder -- leave its staging alone.
            _pid_pattern = _re.compile(r"^\.staging_.+_p(\d+)$")
            for _entry in os.listdir(output_dir):
                _stale_path = os.path.join(output_dir, _entry)
                if not os.path.isdir(_stale_path):
                    continue
                _m = _pid_pattern.match(_entry)
                if _m is None:
                    # Pre-2026-06-18 naming without pid suffix:
                    # restrict cleanup to current run_id + DATASOURCE
                    # to stay conservative.
                    if not _entry.startswith(f".staging_{_run_tag}_{_ds_tag}_"):
                        continue
                else:
                    _stale_pid = int(_m.group(1))
                    if _stale_pid == os.getpid():
                        # Our own (impossibly old) prior dir -- safe to clean.
                        pass
                    elif _is_pid_alive(_stale_pid):
                        # Another live process owns it -- skip.
                        continue
                _shutil.rmtree(_stale_path, ignore_errors=True)
                self.logger.info(
                    "Auto-cleaned stale staging dir (orphan from "
                    "crashed prior run): %s", _stale_path,
                )
        except Exception as _exc:
            self.logger.warning(
                "Layer-2 stale-staging scan in %s failed (non-fatal -- "
                "the new staging dir is still created cleanly): %s",
                output_dir, _exc,
            )

        staging_dir = os.path.join(
            output_dir, f".staging_{_run_tag}_{_ds_tag}_{_ts}",
        )
        os.makedirs(staging_dir, exist_ok=True)
        return output_dir, staging_dir, base, ext, delimiter

    def _chunk_file_path(
        self, staging_dir: str, base_filename: str, ext: str,
        partition_index: int, partition_value: Any,
    ) -> str:
        """Chunk lives in the per-extract staging dir, NOT in the mapped
        output_dir.  Self-consolidation moves the final per-source file
        from staging to mapped at the end."""
        label = self._safe_partition_label(partition_value)
        return os.path.join(
            staging_dir,
            f"{base_filename}.part_{partition_index:04d}_{label}.{ext}",
        )

    def _single_chunk_path(self, staging_dir: str, base_filename: str, ext: str) -> str:
        return os.path.join(staging_dir, f"{base_filename}.part_0000.{ext}")

    # ----- ScanPlan construction --------------------------------------

    async def _build_scan_plan(
        self, job_config: Dict[str, Any], connection_config: Dict[str, Any],
        task: Optional[Dict] = None,
    ) -> ScanPlan:
        """Decide SINGLE vs PARTITION_VALUES, prefetch counts (G1 + G2)."""
        # 2026-06-13 -- POLLING ROW OVERLAY.
        # Operator can drive every per-job knob from the Oracle polling
        # row WITHOUT editing the per-query JSON.  Polling-row values
        # (case-insensitive column names) overlay onto job_config at
        # this single point so the rest of the planner reads the merged
        # view via the existing job_config.get(...) calls.
        # The overlay covers BOTH flat keys and nested partition_config.*
        # paths; any column that's empty/null in the polling row is
        # silently ignored so partial overrides work.
        _overlay_polling_row_onto_job_config(job_config, task, logger=self.logger)

        base_sql = job_config["generated_sql"]
        # 2026-06-20 -- AUTOPLAN integration.  Strategic shift: the
        # planner now measures the source via probe (or cheap count),
        # measures the system (CPU + memory), and DECIDES every knob
        # (mode, concurrency, batch_size, queue_maxsize, bucketing,
        # verify strategy) instead of relying on operator-tunable
        # size thresholds.  Operator overrides are still honoured but
        # NOT required -- one process, any scale.
        #
        # AutoPlan runs AFTER the probe (or its fallback discovery)
        # below, so the implementation is split:
        #   * gather inputs here (system measurements + job_config overrides)
        #   * call autoplan() after probe populates total_rows + cardinality
        #   * push decisions into run_report.runtime_knobs for visibility
        # 2026-06-20 -- CROSS-ENGINE SQL.  When base_sql carries the
        # ``{SOURCE}`` placeholder, render it against the polling row's
        # catalog / schema / table_fqn so the SAME query can also run on
        # the Spark-S3 engine (which renders ``{SOURCE}`` -> "source"
        # temp view).  Operator authors ONE query; both pipelines run it.
        # No-op when {SOURCE} is absent -- legacy queries unchanged.
        try:
            from engine_sql_adapter import (
                has_source_placeholder as _has_src,
                render_for_starburst as _render_sb,
                validate_cross_engine_safe as _xeng_lint,
            )
            if _has_src(base_sql):
                _table_hint = (
                    job_config.get("table_fqn")
                    or job_config.get("source_table")
                    or job_config.get("table_name")
                )
                _catalog = (
                    job_config.get("source_catalog")
                    or job_config.get("c_catalog")
                    or job_config.get("p_catalog")
                )
                _schema = (
                    job_config.get("source_schema")
                    or job_config.get("c_schemainfo")
                    or job_config.get("p_schemainfo")
                )
                base_sql = _render_sb(
                    base_sql,
                    catalog=_catalog, schema=_schema, table=_table_hint,
                    fully_qualified=job_config.get("source_fqn"),
                    logger=self.logger,
                )
                job_config["generated_sql"] = base_sql  # downstream sites see resolved SQL
                # Lint -- cross-engine warnings are advisory, not blocking.
                _xeng_lint(base_sql, logger=self.logger)
        except ImportError:
            pass  # adapter unavailable -- legacy path
        batch_size = int(job_config.get("batch_size", self.DEFAULT_BATCH_SIZE))
        # 2026-06-20 -- AdaptiveConcurrency.  Operator override
        # (job_config["max_concurrent_chunks"]) wins as before.  When unset,
        # _compute_adaptive_concurrency scales with system CPU + available
        # memory so a 16-core / 64 GB pod runs 6-8 chunks in parallel while
        # a 2-core dev box still runs 2.  Hard ceiling via
        # max_concurrent_chunks_ceiling (default 8) protects Trino.
        max_concurrent = _compute_adaptive_concurrency(
            job_config, logger=self.logger,
        )
        max_retries = int(job_config.get("max_chunk_retries", self.DEFAULT_MAX_RETRIES))

        # 2026-06-17 deep-dive #3: bool knobs from per-job JSON MUST go
        # through _coerce_polling_value so quoted "false" / "FALSE" / "0"
        # honour the operator's opt-out.  Plain `bool("false")` is True
        # in Python -- so the previous `bool(job_config.get(...))` reads
        # silently inverted operator intent on `fail_on_mismatch`,
        # `derive_g1_from_discovery`, `skip_pre_flight_count`, and
        # `skip_disk_check`.  Polling-row paths already coerce via the
        # overlay; this closes the JSON-side gap.
        def _job_bool(key: str, default: bool) -> bool:
            coerced = _coerce_polling_value(job_config.get(key), "bool")
            return default if coerced is None else coerced

        fail_on_mismatch = _job_bool("fail_on_mismatch", True)

        # 2026-06-18 -- ICEBERG SNAPSHOT PIN (opt-in).
        # Operator-reported: source=5,624,546 vs downloaded=5,634,098
        # on single-SELECT iceberg+partitioned base_sql (delta +0.17%).
        # Root cause: each Trino query (G1, discovery, per-chunk extract)
        # sees its OWN iceberg snapshot.  If the source table receives
        # ANY writes during the run, extracts pull rows G1 didn't count.
        # We pin it: at job start, query each iceberg table's current
        # snapshot_id once, rewrite base_sql with ``FOR VERSION AS OF``,
        # use the frozen SQL for G1 + discovery + every chunk extract.
        # Non-iceberg tables in the SQL are silently skipped (the
        # snapshot probe query fails fast for them).
        #
        # Opt-in via job_config["pin_iceberg_snapshot"]=true (default
        # false; pre-existing pipelines that manually pin or don't
        # care about drift run unchanged).
        if _job_bool("pin_iceberg_snapshot", False):
            try:
                base_sql_pinned = await self._pin_iceberg_snapshots(
                    base_sql, connection_config, task=task,
                )
                if base_sql_pinned and base_sql_pinned != base_sql:
                    self.logger.info(
                        "Iceberg snapshot pin: base_sql rewritten with "
                        "FOR VERSION AS OF -- all G1 / discovery / "
                        "extract queries will see the same snapshot."
                    )
                    base_sql = base_sql_pinned
                    # Mutate so downstream sites (sidecar, run_report,
                    # sql_summary) also see the pinned SQL.
                    job_config["generated_sql"] = base_sql
            except Exception as _pin_exc:
                self.logger.warning(
                    "Iceberg snapshot pin FAILED (continuing without pin "
                    "-- snapshot drift remains possible): %s", _pin_exc,
                )
        # Memory-control knobs — operator override per job (Fix #4, #6, #8).
        queue_maxsize = int(job_config.get("queue_maxsize", 4))
        writer_idle = int(job_config.get("writer_idle_timeout_seconds", 600))
        count_timeout = int(job_config.get("count_timeout_seconds", 1800))

        # 2026-06-17 -- RESOLVE partition_column / cfg_enabled FIRST.
        # Pre-fix this block sat AFTER the AST-safety scan that read both
        # variables, producing UnboundLocalError on every call.  The
        # resolution is order-independent of the AST scan, so we just hoist
        # it; mode-decision still lives below.
        #
        # partition-by-default semantics: when a partition_column is
        # configured we ASSUME the operator wants partitioned extract
        # unless they EXPLICITLY set enabled=false.  Rationale: SINGLE
        # mode on a 170M+ row job will OOM the Trino coordinator; the
        # only safe default for large jobs is PARTITION_VALUES.  Small
        # jobs without a partition_column silently fall through to
        # SINGLE (no-fail contract).  Operator can still opt out per-job
        # by setting partition_config.enabled=false in the JSON.
        partition_cfg = job_config.get("partition_config", {}) or {}
        _raw_column = partition_cfg.get("partition_column")
        # Defensive coercion: strip whitespace, treat empty / whitespace-only
        # as "not set".  Operators occasionally hand-edit YAML with trailing
        # whitespace; we don't want that to bypass the "not set" branch.
        partition_column = (
            _raw_column.strip() if isinstance(_raw_column, str) else _raw_column
        ) or None
        _enabled_raw = partition_cfg.get("enabled")
        # Coerce via the polling-overlay helper so the JSON path treats
        # quoted "false" / "FALSE" / "0" / "no" the same way the polling
        # row does.  Plain `bool("false")` returns True in Python -- an
        # operator who quotes the YAML value would silently bypass their
        # own opt-out.  _coerce_polling_value returns None for unspecified
        # (None) AND for unrecognized strings; in both cases we default
        # via partition_column presence.
        _enabled_coerced = _coerce_polling_value(_enabled_raw, "bool")
        if _enabled_coerced is None:
            cfg_enabled = bool(partition_column)
        else:
            cfg_enabled = _enabled_coerced

        # 2026-06-17 deep-dive: surface the silent no-op when operator
        # explicitly enables partitioning but forgets the column.  Old
        # code dropped to SINGLE mode without telling them their setting
        # was ignored.  Honour their intent by WARNING; runtime still
        # degrades to SINGLE per the no-fail contract.  Uses the coerced
        # bool so `"FALSE"` doesn't trigger a false-positive WARN.
        if _enabled_coerced is True and not partition_column:
            self.logger.warning(
                "Job %s: partition_config.enabled=%r but partition_column is "
                "not set -- partitioning request IGNORED, running in SINGLE mode. "
                "Set partition_config.partition_column (or polling-row "
                "partition_column) to activate partitioned extract.",
                job_config.get("report_id"), _enabled_raw,
            )

        # 2026-06-17 -- pre-flight AST safety scan when partition mode is
        # selected.  Catches window functions / INTERSECT / EXCEPT /
        # projection-missing-the-partition-column shapes that AST WHERE-
        # injection could distort semantically.  Warnings are NOT errors:
        # the run proceeds and G3 reconcile (sum(chunk rows) == G1) catches
        # any actual row-count drift.  The right fix when this fires is to
        # rewrite the SQL, not add an operator-facing planner toggle.
        if partition_column and (
            self.FORCE_MODE == ScanMode.PARTITION_VALUES
            or (cfg_enabled and partition_column)
        ):
            _is_safe, _warnings = _validate_base_sql_ast_safe(
                base_sql, partition_column,
                dialect="trino", logger=self.logger,
            )
            # 2026-06-17 Gap 1 -- AMBIGUOUS partition column is a hard
            # error: neither AST inject nor wrap can resolve it, both
            # produce runtime "Column ambiguous" errors.  Fail fast at
            # planning with the operator fix hint so they don't waste
            # cycles on a doomed run.
            _ambiguous = [w for w in _warnings if "AMBIGUOUS" in w]
            if _ambiguous:
                raise ValueError(
                    f"Job {job_config.get('report_id')}: {_ambiguous[0]}"
                )
            if not _is_safe:
                self.logger.warning(
                    "Job %s: %d AST-safety warning(s) raised against base_sql. "
                    "G3 reconcile (sum(chunk rows) == G1) will catch any drift "
                    "and fail the run loudly -- fix the SQL if any are real.",
                    job_config.get("report_id"), len(_warnings),
                )

            # 2026-06-18 -- STRATEGIC PLANNING-TIME WARN.  When base_sql
            # has a row-count-affecting shape (DISTINCT / outer GROUP BY
            # / HAVING / QUALIFY / LIMIT) AND fail_on_mismatch=TRUE
            # (default), every chunk + the job-level G3 will fire false
            # mismatches because discovery counts SOURCE rows and the
            # chunk produces aggregated rows.  Without this warning
            # operator only discovers this AFTER burning 5-15 min of
            # Trino time.  Surface it at planning so they can stop the
            # run and set FAIL_ON_MISMATCH=FALSE before the chunks fire.
            try:
                import sqlglot
                _shape_check = _row_count_affecting_shape(
                    sqlglot.parse_one(
                        _strip_trailing_semicolon(base_sql), dialect="trino",
                    )
                )
            except Exception:
                _shape_check = None
            _fail_mismatch_raw = _job_bool("fail_on_mismatch", True)
            if _shape_check and _fail_mismatch_raw:
                self.logger.warning(
                    "Job %s: base_sql has top-level %s.  Discovery will "
                    "count SOURCE rows per partition value (pre-aggregation); "
                    "chunks will produce AGGREGATED rows (post-DISTINCT / "
                    "post-GROUP BY).  Per-chunk + job-level G3 checks will "
                    "compare DIFFERENT UNITS and fire false mismatches.  "
                    "Recommended: set FAIL_ON_MISMATCH='FALSE' in the polling "
                    "row.  Completeness anchors: G5 (consolidated file rows "
                    "== sum-of-chunks) + variance check vs previous COB run "
                    "stay meaningful.",
                    job_config.get("report_id"), _shape_check,
                )

        if self.FORCE_MODE == ScanMode.PARTITION_VALUES or (cfg_enabled and partition_column):
            mode = ScanMode.PARTITION_VALUES
        else:
            mode = ScanMode.SINGLE

        # G1 — source pre-flight COUNT(*).  Fix #6: pass the dedicated
        # count_timeout (default 1800 s) so a 120 M-row COUNT(*) doesn't
        # trip the 10-min request_timeout that fits ordinary queries.
        #
        # 2026-06-13 -- G1 ACQUISITION POLICY for 170M-record runs.
        # `SELECT COUNT(*) FROM (base)` is a full-result-set scan that
        # doubles the Trino work (we ALSO run `... GROUP BY col` for
        # partition discovery on the same base_sql).  For the
        # PARTITION_VALUES + group_by-discovery path, we can DERIVE G1
        # from the discovery sum -- by construction they query the same
        # plan and produce the same total.
        #
        # Knobs:
        #   * derive_g1_from_discovery (default true)  -- when true,
        #     partition+group_by skips the separate COUNT(*) and uses
        #     sum(discovery counts) for G1.  Saves one full Trino scan
        #     per source on 170M -- typically 5-15 minutes saved.
        #   * skip_pre_flight_count   (default false) -- forces NO
        #     separate COUNT regardless of mode.  G1 becomes "deferred,
        #     measured from extract" -- ScanPlan.expected_total set to
        #     sum(chunk actuals) at the end of the run.  G3 then becomes
        #     identity-true (no anchor to compare against), but G5
        #     (consolidated == sum(actuals)) still meaningfully proves
        #     the merge didn't drop rows.  Use this when COUNT(*) itself
        #     times out / OOMs on >200M tables with arbitrary base_sql.
        derive_g1 = _job_bool("derive_g1_from_discovery", True)
        skip_count = _job_bool("skip_pre_flight_count", False)
        # In PARTITION_VALUES + group_by, defer COUNT until after discovery.
        # In SINGLE mode or distinct mode, COUNT is the only G1 source
        # (unless operator opted into skip_pre_flight_count).
        #
        # 2026-06-17 deep-dive #3: case-insensitive normalise.  Polling
        # rows from Oracle commonly arrive UPPERCASE ("DISTINCT" /
        # "GROUP_BY") and would otherwise miss the lowercase comparisons
        # at the discovery call sites, silently falling through to the
        # default group_by branch and ignoring operator intent.
        _raw_disc_mode = partition_cfg.get("discovery_mode")
        if mode == ScanMode.PARTITION_VALUES:
            discovery_mode = (str(_raw_disc_mode).strip().lower() if _raw_disc_mode else "group_by")
        else:
            discovery_mode = None
        defer_count_to_discovery = (
            mode == ScanMode.PARTITION_VALUES
            and discovery_mode == "group_by"
            and derive_g1
        )

        # 2026-06-20 -- PROBE QUERY (strategic, replaces three full scans).
        # When checksum_columns is set AND we're in PARTITION_VALUES +
        # group_by mode, fire ONE GROUP BY scan that produces per-partition
        # counts AND per-partition column SUMs.  This single Trino shuffle
        # replaces:
        #   * _fetch_count           (pre-flight COUNT(*))
        #   * _discover_partition_values (group_by GROUP BY count)
        #   * _fetch_source_checksums (source-side SUM scan)
        # Saves 2 full-table scans on 150M+ row jobs (~3-6 min planning
        # overhead).  Per-partition sums also anchor an early-detection
        # C5_sum gate at chunk close, instead of waiting for end-of-job
        # aggregate reconcile.
        #
        # Probe-or-skip: when base_sql has shape-affecting clauses
        # (DISTINCT, HAVING, QUALIFY, top GROUP BY, LIMIT) the helper
        # returns None and we fall through to legacy primitives.
        _ck_cols_raw = job_config.get("checksum_columns", []) or []
        if isinstance(_ck_cols_raw, str):
            _ck_cols_for_probe = [c.strip() for c in _ck_cols_raw.split(",") if c.strip()]
        else:
            _ck_cols_for_probe = [str(c).strip() for c in _ck_cols_raw if str(c).strip()]
        _probe_result: Optional[Dict[str, Any]] = None
        _probe_t0 = 0.0
        _probe_dt = 0.0
        if (
            _ck_cols_for_probe
            and mode == ScanMode.PARTITION_VALUES
            and partition_column
            and discovery_mode == "group_by"
        ):
            # 2026-06-20 -- ALIAS COLLISION GUARD.  Probe SQL aliases use
            # the _qs_ prefix.  If an operator names a checksum column
            # _qs_pv / _qs_cnt / _qs_sum_<n> the GROUP BY rewrite would
            # produce ambiguous references.  Fail loudly here so the
            # operator renames OR drop the probe and fall back to legacy
            # primitives.
            _reserved = {"_qs_pv", "_qs_cnt"} | {
                f"_qs_sum_{i}" for i in range(len(_ck_cols_for_probe))
            }
            _collisions = [
                c for c in _ck_cols_for_probe if c.lower() in _reserved
            ]
            if _collisions or partition_column.lower() in _reserved:
                self.logger.warning(
                    "ProbeQuery: column name(s) %s collide with reserved "
                    "alias prefix _qs_ -- falling back to legacy "
                    "primitives.  Rename the checksum_columns to avoid "
                    "the prefix to enable the probe.",
                    _collisions or [partition_column],
                )
            else:
                _probe_t0 = time.time()
                # NOTE: _run_probe_query already classifies exceptions
                # internally (fatal -> raise, retryable -> None).  Don't
                # add a no-op try/except wrapper here.
                _probe_result = await self._run_probe_query(
                    base_sql, partition_column, _ck_cols_for_probe,
                    connection_config, timeout=count_timeout, task=task,
                )
                _probe_dt = time.time() - _probe_t0
                if _probe_result is None:
                    self.logger.info(
                        "ProbeQuery skipped/failed for job %s -- falling "
                        "back to legacy primitives (separate COUNT + "
                        "discovery + source-sum scans).",
                        job_config.get("report_id"),
                    )

        expected_total: Optional[int] = None
        g1_source = "unmeasured"
        # 2026-06-20 -- When probe ran, G1 and discovery come for FREE
        # from the probe result.  Skip the separate _fetch_count call.
        if _probe_result is not None:
            expected_total = int(_probe_result["total_count"])
            g1_source = f"ProbeQuery (single scan) [{_probe_dt:.1f}s]"
            self.logger.info(
                "G1 acquisition: ProbeQuery for job %s -- total_count=%s "
                "(one GROUP BY scan replaced COUNT + discovery + source-sum)",
                job_config.get("report_id"), f"{expected_total:,}",
            )
        elif defer_count_to_discovery:
            self.logger.info(
                "G1 acquisition: DEFERRED to partition discovery for job %s "
                "(derive_g1_from_discovery=true, mode=group_by) -- saves "
                "one full Trino scan on large tables",
                job_config.get("report_id"),
            )
            g1_source = "partition discovery sum (deferred)"
        elif skip_count:
            self.logger.info(
                "G1 acquisition: SKIPPED for job %s (skip_pre_flight_count=true) "
                "-- G1 will be measured from extracted chunks at run end",
                job_config.get("report_id"),
            )
            g1_source = "deferred (measured from extract)"
        else:
            self.logger.info(
                "Pre-flight COUNT(*) for job %s (timeout=%ds)",
                job_config.get("report_id"), count_timeout,
            )
            _t0 = time.time()
            expected_total = await self._fetch_count(
                base_sql, connection_config, count_timeout, task=task,
            )
            _t1 = time.time()
            g1_source = f"pre-flight COUNT(*) [{_t1 - _t0:.1f}s]"
            self.logger.info(
                "  G1 expected_total = %s (source: %s)",
                expected_total, g1_source,
            )

        # 2026-06-13 -- pre-flight disk-space guard for the 170M case.
        # Fail UPFRONT instead of mid-extract.  Operator can override
        # via per-job JSON knobs:
        #   - avg_row_bytes:  estimated bytes per row (default 200)
        #   - disk_safety_factor:  multiplier for headroom (default 4)
        #   - skip_disk_check:  set true to bypass (e.g. exotic NFS)
        # NOTE: when G1 was deferred (above), we can't disk-check at
        # this point because expected_total is None.  The check fires
        # again AFTER discovery (in the partition branch below).
        async def _disk_check(rows: int) -> None:
            if _job_bool("skip_disk_check", False):
                return
            output_dir = (task.get("output_dir") if isinstance(task, dict) else "") or ""
            if not (output_dir and rows and rows > 0):
                return
            from steps.file.run_state import check_disk_space as _cds
            shortage = _cds(
                output_dir,
                expected_rows=rows,
                avg_row_bytes=int(job_config.get("avg_row_bytes", 200)),
                safety_factor=float(job_config.get("disk_safety_factor", 4.0)),
                label=f"job_{job_config.get('report_id')}_{self.DATASOURCE_NAME}",
                logger=self.logger,
            )
            if shortage:
                free_gb = shortage["free"] // (1024 ** 3)
                need_gb = shortage["need"] // (1024 ** 3)
                short_gb = shortage["shortage"] // (1024 ** 3)
                raise OSError(
                    f"Pre-flight disk-space check FAILED at {output_dir}: "
                    f"need ~{need_gb} GB for {rows:,} rows "
                    f"(avg_row_bytes x safety_factor), but only {free_gb} GB "
                    f"free (short {short_gb} GB).  Free up space, point "
                    f"output_dir at a larger volume, or bump avg_row_bytes "
                    f"/ disk_safety_factor / set skip_disk_check=true in "
                    f"the per-job JSON if you know better."
                )

        if expected_total is not None:
            await _disk_check(expected_total)

        if mode == ScanMode.SINGLE:
            # G1 in SINGLE mode: either COUNT(*) above, or None (deferred).
            return ScanPlan(
                mode=mode,
                base_sql=base_sql,
                expected_total=expected_total,
                batch_size=batch_size,
                max_concurrent_chunks=1,
                max_chunk_retries=max_retries,
                fail_on_mismatch=fail_on_mismatch and expected_total is not None,
                queue_maxsize=queue_maxsize,
                writer_idle_timeout_seconds=writer_idle,
                count_timeout_seconds=count_timeout,
                g1_source=g1_source,
            )

        # PARTITION_VALUES — discover values + per-value counts (G2 input)
        # 2026-06-17 -- no-fail contract: if PARTITION_VALUES was chosen
        # but partition_column ended up None (only path now is FORCE_MODE
        # against a job that didn't name a column), degrade silently to
        # SINGLE.  Previously raised; user explicitly asked for "go with
        # normal" in this case.
        if not partition_column:
            self.logger.warning(
                "Job %s: FORCE_MODE=PARTITION_VALUES but partition_column not "
                "set -- falling back to SINGLE mode",
                job_config.get("report_id"),
            )
            # Truthful g1_source: we never DID partition discovery, so
            # the "partition discovery sum (deferred)" label that was
            # set above is a lie at this point.  Re-anchor:
            _fallback_g1_source = (
                "deferred (measured from extract)"
                if expected_total is None
                else g1_source
            )
            return ScanPlan(
                mode=ScanMode.SINGLE,
                base_sql=base_sql,
                expected_total=expected_total,
                batch_size=batch_size,
                max_concurrent_chunks=1,
                max_chunk_retries=max_retries,
                fail_on_mismatch=fail_on_mismatch and expected_total is not None,
                queue_maxsize=queue_maxsize,
                writer_idle_timeout_seconds=writer_idle,
                count_timeout_seconds=count_timeout,
                g1_source=_fallback_g1_source,
            )
        max_partitions = int(partition_cfg.get("max_partitions", 500))
        # 2026-06-13 -- partition_config.discovery_mode controls which
        # SQL shape we use for partition enumeration.  See
        # _discover_partition_values for rationale.
        self._partition_discovery_mode = discovery_mode or "group_by"
        # 2026-06-20 -- when ProbeQuery already populated values + counts,
        # skip the redundant _discover_partition_values scan entirely.
        # The probe ran ONE GROUP BY scan and already returned both the
        # values list AND the per-partition counts -- there's nothing
        # left to discover.  expected_per_partition_sums is also carried
        # forward to the ScanPlan for the per-chunk SUM gate.
        _probe_per_partition_sums: Dict[Any, Dict[str, Any]] = {}
        if _probe_result is not None and _probe_result.get("values") is not None:
            partition_values = list(_probe_result["values"])
            expected_per_partition = dict(_probe_result["counts"])
            _probe_per_partition_sums = dict(_probe_result["sums"])
            _disc_t0 = _probe_t0  # for log continuity
            _disc_t1 = _probe_t0 + _probe_dt
            self.logger.info(
                "Partition discovery: ProbeQuery already produced "
                "values=%d + per-partition counts + sums in one scan "
                "(skipping redundant _discover_partition_values).",
                len(partition_values),
            )
        else:
            _disc_t0 = time.time()
            partition_values, expected_per_partition = await self._discover_partition_values(
                base_sql, partition_column, connection_config, max_partitions, count_timeout,
                task=task,
            )
            _disc_t1 = time.time()
        if not partition_values:
            self.logger.warning(
                "No partition values for column %s — falling back to SINGLE mode",
                partition_column,
            )
            # If we deferred COUNT, we still need G1 for SINGLE-mode fallback.
            # Falling through with expected_total=None is acceptable; G3/G5
            # become identity-true; G5 still anchors against sum(actuals).
            return ScanPlan(
                mode=ScanMode.SINGLE,
                base_sql=base_sql,
                expected_total=expected_total,
                batch_size=batch_size,
                max_concurrent_chunks=1,
                max_chunk_retries=max_retries,
                fail_on_mismatch=fail_on_mismatch and expected_total is not None,
                queue_maxsize=queue_maxsize,
                writer_idle_timeout_seconds=writer_idle,
                count_timeout_seconds=count_timeout,
                g1_source=g1_source,
            )

        # 2026-06-18 -- AUTO-SKIP PARTITIONING for small datasets.
        # Trino per-query planning overhead is ~5-15s; for tables under
        # ~10M rows, partitioning's per-chunk overhead dominates the
        # actual scan time and the run is SLOWER than a single SELECT.
        # User-reported case: 1M rows + 136 buckets = 10+ min vs 3 min
        # for SINGLE mode.
        #
        # Threshold knob: ``partition_min_rows`` (default 10_000_000).
        # When the discovery sum is BELOW this, fall back to SINGLE
        # mode automatically.  Only fires when discovery actually
        # collected per-value counts (group_by mode); distinct mode
        # has no count available so operator judgement applies.
        #
        # ESCAPE HATCH for OOM-prone queries: when ``force_partition``
        # is set (operator knows their query plan will OOM Trino in
        # SINGLE mode -- e.g. wide JOIN with huge intermediate, window
        # function over large input), the auto-skip is bypassed and
        # partitioning runs regardless of discovery sum.  Distinct mode
        # is also a safe escape (no count -> auto-skip can't fire).
        partition_min_rows = int(partition_cfg.get("partition_min_rows", 10_000_000))
        force_partition_raw = partition_cfg.get("force_partition")
        if isinstance(force_partition_raw, bool):
            force_partition = force_partition_raw
        else:
            force_partition = str(force_partition_raw or "").strip().upper() in {
                "TRUE", "Y", "YES", "1", "T",
            }
        _discovery_sum_preview = (
            sum(expected_per_partition.values())
            if expected_per_partition else None
        )
        if (
            _discovery_sum_preview is not None
            and _discovery_sum_preview < partition_min_rows
            and not force_partition
        ):
            self.logger.warning(
                "Partitioning auto-skip: discovery sum=%s rows is below "
                "partition_min_rows=%s -- partitioning's per-chunk overhead "
                "(~5-15s per Trino query) would dominate the actual scan time. "
                "Falling back to SINGLE mode (1 query, no bucketing).  Override: "
                "(a) set FORCE_PARTITION='TRUE' in polling row if your query "
                "OOMs Trino in SINGLE mode (JOIN/window/aggregation explodes "
                "intermediate); (b) set PARTITION_MIN_ROWS=0 to disable this "
                "auto-skip entirely; (c) use DISCOVERY_MODE='distinct' "
                "(no count -> auto-skip never fires).",
                f"{_discovery_sum_preview:,}", f"{partition_min_rows:,}",
            )
            return ScanPlan(
                mode=ScanMode.SINGLE,
                base_sql=base_sql,
                expected_total=_discovery_sum_preview,
                batch_size=batch_size,
                max_concurrent_chunks=1,
                max_chunk_retries=max_retries,
                fail_on_mismatch=fail_on_mismatch,
                queue_maxsize=queue_maxsize,
                writer_idle_timeout_seconds=writer_idle,
                count_timeout_seconds=count_timeout,
                g1_source=f"discovery sum (auto-skip below {partition_min_rows:,} rows)",
            )

        # 2026-06-17 -- BUCKETING (single-column).  For high-cardinality
        # partition columns (1139 distinct SAP_COMPANY_IDs in the user's
        # case), running one Trino query per value means 1139 round-trips
        # and 1139 query-planning overheads.  Bucketing groups adjacent
        # discovered values into N buckets of size ~K each; each bucket
        # runs as ONE query using ``WHERE col IN (v1, v2, ..., vK)``.
        #
        # Knobs (under ``partition_config``):
        #   bucket_strategy : "refuse" (default) | "auto"
        #       refuse -> raise when len(values) > max_partitions (today's
        #                 behaviour; preserves back-compat).
        #       auto   -> auto-bucket so len(buckets) <= max_partitions.
        #   bucket_size     : explicit values-per-bucket (overrides auto-
        #       computed when > 1).  Skipped when 0/None.
        #
        # Semantics preserved:
        #   * G1 still = sum of per-bucket counts.
        #   * G3 reconcile (sum of chunk actuals == G1) unchanged.
        #   * Discovery query unchanged -- bucketing happens on the
        #     returned (values, counts) only, not on the discovery SQL.
        #
        # 2026-06-17 deep-dive caveat (data completeness): bucketing
        # groups values in DISCOVERY ORDER (which is ORDER BY col).  Even
        # buckets means the planner cost is balanced under cardinality;
        # data-volume balance depends on per-value count uniformity.
        # When per-value counts are highly skewed, operator can shrink
        # bucket_size manually.
        bucket_strategy = (
            str(partition_cfg.get("bucket_strategy") or "refuse").strip().lower()
        )
        bucket_size_cfg = int(partition_cfg.get("bucket_size") or 0)
        if bucket_strategy == "auto" and partition_values:
            import math as _math
            if bucket_size_cfg > 1:
                effective_size = bucket_size_cfg
                _why = f"bucket_size={bucket_size_cfg} (explicit)"
            elif len(partition_values) > max_partitions:
                effective_size = _math.ceil(len(partition_values) / max_partitions)
                _why = (
                    f"auto-computed from {len(partition_values)} values / "
                    f"max_partitions={max_partitions}"
                )
            else:
                effective_size = 1  # within budget; no bucketing needed
                _why = "no-op (within max_partitions)"
            if effective_size > 1:
                bucketed_values = [
                    tuple(partition_values[i:i + effective_size])
                    for i in range(0, len(partition_values), effective_size)
                ]
                # 2026-06-17 deep-dive fix (defect B): when discovery_mode
                # is 'distinct', expected_per_partition is {} by design --
                # per-value counts were not collected.  Synthesising
                # ``{bucket: 0, bucket: 0, ...}`` from .get(v, 0) would
                # produce a non-empty dict of zeros, which makes
                # sum_partition_expected return 0 instead of None and
                # fires a false G2 FAIL chip on the run report.  Keep
                # bucketed_counts EMPTY when source is empty so G2 stays
                # advisory-only (matches discovery_mode='distinct'
                # contract).
                if expected_per_partition:
                    bucketed_counts = {
                        bv: sum(expected_per_partition.get(v, 0) for v in bv)
                        for bv in bucketed_values
                    }
                else:
                    bucketed_counts = {}
                # 2026-06-20 -- roll up probe sums to bucket granularity
                # too so the per-chunk SUM gate stays correct when
                # bucketing is active (chunk corresponds to a bucket of
                # adjacent values).
                if _probe_per_partition_sums:
                    from decimal import Decimal as _Dec
                    bucketed_sums: Dict[Any, Dict[str, Any]] = {}
                    for bv in bucketed_values:
                        col_acc: Dict[str, Any] = {}
                        for v in bv:
                            for col, s in (_probe_per_partition_sums.get(v) or {}).items():
                                col_acc[col] = col_acc.get(col, _Dec(0)) + s
                        bucketed_sums[bv] = col_acc
                    _probe_per_partition_sums = bucketed_sums
                self.logger.info(
                    "Partition bucketing (auto): grouped %d distinct values "
                    "into %d buckets of size ~%d -- %s.  Each bucket runs as "
                    "ONE Trino query via WHERE col IN (...) instead of one "
                    "query per value.  G3/G5 reconcile unchanged "
                    "(sum-of-bucket-actuals == G1).",
                    len(partition_values), len(bucketed_values),
                    effective_size, _why,
                )
                partition_values = bucketed_values
                expected_per_partition = bucketed_counts

        # 2026-06-17 -- max_partitions cap fires AFTER bucketing so an
        # over-cap discovery can be auto-recovered.  When operator chose
        # refuse / no bucketing, original behaviour kicks in (raise on
        # over-cap).  Error message points the operator at the bucketing
        # knob so the fix is one-line.
        if len(partition_values) > max_partitions:
            raise ValueError(
                f"Partition plan has {len(partition_values)} chunks which "
                f"exceeds max_partitions={max_partitions}.  Options: "
                f"(a) set partition_config.bucket_strategy='auto' to "
                f"group adjacent values into ~{max_partitions} buckets "
                f"of size ~{(len(partition_values) + max_partitions - 1) // max_partitions} "
                f"each (one Trino query per bucket, total chunks <= "
                f"max_partitions); (b) raise max_partitions; (c) pick a "
                f"lower-cardinality partition column."
            )

        # 2026-06-13 -- G1 derivation from discovery (group_by mode only).
        # Per-partition counts are by-construction-summed to the same row
        # count `SELECT COUNT(*) FROM (base)` would return (same Trino
        # plan, same base_sql, same time window).  We bypass the
        # redundant scan and adopt this as authoritative G1.
        discovery_sum = sum(expected_per_partition.values()) if expected_per_partition else None
        if defer_count_to_discovery and discovery_sum is not None:
            expected_total = discovery_sum
            g1_source = f"partition discovery sum [{_disc_t1 - _disc_t0:.1f}s]"
            self.logger.info(
                "  G1 derived from discovery: %s rows (from %d partitions, "
                "saved one full Trino scan)",
                f"{expected_total:,}", len(partition_values),
            )
            await _disk_check(expected_total)
        elif expected_total is not None and discovery_sum is not None:
            # Both anchors exist; sanity-check agreement.  Mismatch means
            # source changed mid-run -- WARN but trust COUNT (the
            # contractual G1) over discovery (likely-later snapshot).
            if expected_total != discovery_sum:
                self.logger.warning(
                    "G1 source-drift detected: COUNT(*)=%s != discovery sum=%s "
                    "(delta %+d).  Source data likely changed between queries.  "
                    "Trusting COUNT(*) as authoritative G1.",
                    f"{expected_total:,}", f"{discovery_sum:,}",
                    discovery_sum - expected_total,
                )

        self.logger.info(
            "PARTITION_VALUES plan: column=%s values=%d sum=%s expected_total=%s",
            partition_column, len(partition_values),
            sum(expected_per_partition.values()) if expected_per_partition else "(unknown)",
            expected_total,
        )
        # 2026-06-20 -- when ProbeQuery ran, source-side per-partition
        # column SUMs are already populated; pre-seed the plan so the
        # per-chunk gate can compare on-the-fly chunk sums against the
        # per-partition anchor (early-detection vs end-of-job-only).
        # Also pre-populate plan.source_checksums + plan.checksum_columns
        # so _execute_one_job skips the redundant _fetch_source_checksums
        # call (saves another full-table scan).
        _plan_source_checksums: Dict[str, Any] = {}
        _plan_checksum_columns: List[str] = []
        if _probe_result is not None:
            _plan_source_checksums = dict(_probe_result.get("total_sums") or {})
            _plan_checksum_columns = list(_ck_cols_for_probe)

        # 2026-06-20 -- AUTOPLAN final pass.  Now that we have measured:
        #   * total_rows                  (from probe or COUNT or discovery)
        #   * partition cardinality       (from probe or discovery values)
        #   * row-byte estimate           (from job_config or default)
        # We let AutoPlan re-derive every numeric knob from the measurements.
        # Operator overrides (max_concurrent_chunks, batch_size, etc. on
        # job_config) STILL WIN -- AutoPlan only fires when the operator
        # left a knob unset.  The decisions get pushed to runtime_knobs
        # in _execute_one_job so result.html shows WHY each knob was
        # picked.
        try:
            from steps.file.autoplan import autoplan, build_inputs_from_probe
            _ap_total_rows = (
                expected_total if expected_total is not None
                else (sum(expected_per_partition.values()) if expected_per_partition else 0)
            )
            # 2026-06-21 -- when trino_profile='auto', fire ONE quick
            # Trino capacity probe (~100ms, 10s timeout) so AutoPlan
            # can size concurrency from live cluster state instead of
            # a static profile.  Skipped entirely for other profiles
            # (zero overhead in default mode).
            _trino_state = None
            _profile_check = str(
                job_config.get("trino_profile")
                or job_config.get("TRINO_PROFILE")
                or os.environ.get("QS_DEFAULT_TRINO_PROFILE")
                or ""
            ).strip().lower()
            if _profile_check == "auto":
                try:
                    _trino_state = await self._probe_trino_capacity(
                        connection_config, task=task,
                    )
                except Exception as exc:
                    self.logger.info(
                        "Trino capacity probe raised (%s) -- AutoPlan "
                        "falls back to shared_normal", exc,
                    )
            _ap_inputs = build_inputs_from_probe(
                probe_result=_probe_result,
                total_rows=_ap_total_rows,
                job_config=job_config,
                trino_state_hint=_trino_state,
            )
            _ap_outputs = autoplan(_ap_inputs, logger=self.logger)
            # Stash on the task so _execute_one_job surfaces them.
            if isinstance(task, dict):
                task["_autoplan_decisions"] = _ap_outputs.explain()
            # Adopt AutoPlan's choices when operator didn't pin them
            # explicitly (we already coalesced operator overrides into
            # the inputs; AutoPlan's output respects those).
            if not job_config.get("max_concurrent_chunks"):
                max_concurrent = _ap_outputs.max_concurrent_chunks
            if not job_config.get("batch_size"):
                batch_size = _ap_outputs.batch_size
            if not job_config.get("queue_maxsize"):
                queue_maxsize = _ap_outputs.queue_maxsize
        except Exception as _ap_exc:
            # AutoPlan is observability + adaptive tuning; never block
            # the run on its failure.  Legacy decisions still execute.
            self.logger.warning(
                "AutoPlan derivation failed (%s) -- continuing with "
                "legacy + operator-override knobs.",
                _ap_exc,
            )

        return ScanPlan(
            mode=mode,
            base_sql=base_sql,
            expected_total=expected_total,
            partition_column=partition_column,
            partition_values=partition_values,
            expected_per_partition=expected_per_partition,
            batch_size=batch_size,
            max_concurrent_chunks=max_concurrent,
            max_chunk_retries=max_retries,
            fail_on_mismatch=fail_on_mismatch and expected_total is not None,
            queue_maxsize=queue_maxsize,
            writer_idle_timeout_seconds=writer_idle,
            count_timeout_seconds=count_timeout,
            g1_source=g1_source,
            checksum_columns=_plan_checksum_columns,
            source_checksums=_plan_source_checksums,
            expected_per_partition_sums=_probe_per_partition_sums,
        )

    async def _fetch_count(
        self, base_sql: str, connection_config: Dict[str, Any],
        count_timeout: int = 1800, task: Optional[Dict] = None,
    ) -> int:
        # 2026-06-17 -- AST-derive COUNT(*) over source FROM/JOIN/WHERE
        # instead of wrapping the full base_sql in a subquery.  Trino
        # then prunes the scan natively; legacy wrap forced a full
        # result-set materialisation before counting.  Falls back to
        # the legacy wrap on sqlglot parse failure.
        #
        # Fix #3 retained inside _wrap_count -- newline BEFORE the
        # closing paren so a trailing ``-- comment`` in base_sql can't
        # swallow the wrap's ``)``.
        count_sql, used_mode = _derive_count_sql(
            base_sql, dialect="trino", logger=self.logger,
        )
        # 2026-06-18 -- "skip" mode (new): when base_sql has DISTINCT /
        # outer GROUP BY / HAVING / etc, wrapping the whole base_sql
        # in COUNT(*) would force Trino to materialise the entire
        # result first (OOM on 170M+ rows).  _derive_count_sql signals
        # "skip" instead.  Return 0 here; G1 is measured from extract
        # at end-of-job (sum of chunk actuals).
        if used_mode == "skip":
            self.logger.info(
                "Pre-flight COUNT(*) SKIPPED -- base_sql has row-count-"
                "affecting clause; wrap would OOM on large tables.  G1 "
                "will be measured from extract at end-of-job."
            )
            return 0
        if used_mode == "ast":
            self.logger.info(
                "Pre-flight COUNT(*) (AST rewrite): COUNT over source "
                "FROM/JOIN/WHERE -- no subquery wrap"
            )
        else:
            self.logger.info(
                "Pre-flight COUNT(*) (wrap fallback): AST rewrite "
                "unavailable, using legacy subquery wrap"
            )
        # Per-job override of the connection's request_timeout for the
        # count phase only (Fix #6).
        cfg = dict(connection_config)
        cfg["request_timeout"] = count_timeout
        # 2026-06-17 -- log the FULL count SQL so the next time someone
        # says "I still see count on full wrapper" they can grep this
        # line and confirm which mode actually ran.
        self.logger.info("Pre-flight COUNT(*) SQL:\n%s", count_sql)
        async with StarburstConnection(cfg, self.logger) as conn:
            conn.task = task  # cancellation propagation (2026-06-12)
            val = await conn.fetch_scalar(count_sql)
            if val is None:
                return 0
            return int(val)

    async def _fetch_source_checksums(
        self, base_sql: str, columns: List[str],
        connection_config: Dict[str, Any],
        timeout: int = 1800, task: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Compute ``SUM(col)`` over base_sql's source FROM/JOIN/WHERE
        for each requested column.  Returns ``{col_name: Decimal(sum)}``.

        Strategy: AST-strip projection / GROUP BY / ORDER BY / LIMIT /
        DISTINCT / HAVING / QUALIFY from base_sql and emit
            ``SELECT SUM(c1), SUM(c2), ... FROM <source FROM/JOIN/WHERE>``
        Same OOM-safe pattern as ``_derive_count_sql`` -- no subquery
        wrap, Trino prunes source scan natively.

        When base_sql has shape-affecting clauses, the AST strip would
        change semantics so we SKIP and return ``{}``.  Caller falls
        back to internal consistency only and logs that source-side
        checksum was unavailable.

        Operator constraint (cannot be auto-detected): the named
        columns must be EITHER unaggregated in base_sql's projection
        OR SUM-aggregated.  AVG / MAX / MIN / STDDEV projections of
        the same column DO NOT preserve the SUM-of-sums equivalence;
        operator must pick additive columns for the checksum to be
        meaningful.
        """
        from decimal import Decimal
        if not columns:
            return {}
        sum_sql, used_mode = _derive_sum_sql(
            base_sql, list(columns), dialect="trino", logger=self.logger,
        )
        if used_mode == "skip":
            # Already-logged inside the helper.  Return empty so
            # checksum_columns gets cleared on the plan and the
            # cross-source step skips its sum check cleanly.
            return {}
        if used_mode == "wrap":
            self.logger.warning(
                "Source-checksum SUM: sqlglot unavailable -- falling "
                "back to subquery wrap.  This is OOM-UNSAFE on large "
                "tables (forces Trino to materialise base_sql first); "
                "consider installing sqlglot or unsetting "
                "checksum_columns for jobs > 10M rows."
            )
        cfg = dict(connection_config)
        cfg["request_timeout"] = timeout
        self.logger.info("Source-checksum SUM SQL (%s mode):\n%s", used_mode, sum_sql)
        out: Dict[str, Any] = {}
        async with StarburstConnection(cfg, self.logger) as conn:
            conn.task = task
            await conn.execute(sum_sql)
            async for batch in conn.fetch_chunks(1):
                if not batch:
                    continue
                row = batch[0]
                for i, col in enumerate(columns):
                    v = row[i]
                    out[col] = Decimal(0) if v is None else Decimal(str(v))
                break
        return out

    async def _pin_iceberg_snapshots(
        self, base_sql: str, connection_config: Dict[str, Any],
        task: Optional[Dict] = None,
    ) -> str:
        """Rewrite ``base_sql`` to pin each iceberg table reference to
        its CURRENT snapshot via ``FOR VERSION AS OF <snapshot_id>``.

        Walks every Table node in the AST.  For each, probes Trino
        with ``SELECT max(snapshot_id) FROM "<catalog.schema.table>$snapshots"``
        -- iceberg's hidden metadata table.  If the probe returns an
        id, injects FOR VERSION AS OF into the table reference (a
        Trino feature; Iceberg connector honours it).  If the probe
        fails (table is not iceberg, or operator lacks
        permission on $snapshots), the table is left UNPINNED -- pin
        only what we can prove is iceberg.  Non-Trino dialects and
        sqlglot parse failures return base_sql unchanged.

        Returns the rewritten SQL.  Never raises -- caller's try/except
        downgrades to a warning if needed.
        """
        try:
            import sqlglot
            from sqlglot import expressions as exp
        except ImportError:
            return base_sql
        try:
            tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql),
                                       dialect="trino")
        except Exception as exc:
            self.logger.warning(
                "Iceberg pin: sqlglot parse failed (%s) -- "
                "leaving base_sql unpinned.", exc,
            )
            return base_sql

        # Find every table reference in the AST.  Dedupe by fully-
        # qualified name so we probe each iceberg table ONCE even when
        # it appears in multiple JOINs.
        tables = list(tree.find_all(exp.Table))
        if not tables:
            return base_sql
        seen: Dict[str, Optional[int]] = {}  # fq_name -> snapshot_id or None
        for t in tables:
            cat = t.args.get("catalog")
            sch = t.args.get("db")
            name = t.this
            cat_s = cat.name if cat else None
            sch_s = sch.name if sch else None
            tbl_s = name.name if name else None
            if not tbl_s:
                continue
            fq = ".".join(p for p in (cat_s, sch_s, tbl_s) if p)
            if fq in seen:
                continue
            # Probe the snapshot metadata table.  The double-quote
            # form `"<table>$snapshots"` is Trino's iceberg syntax.
            inner = f'"{tbl_s}$snapshots"'
            qualifier = ".".join(p for p in (cat_s, sch_s) if p)
            probe_sql = (
                f"SELECT max(snapshot_id) FROM "
                f"{qualifier + '.' if qualifier else ''}{inner}"
            )
            try:
                cfg = dict(connection_config)
                cfg["request_timeout"] = 60  # snapshot probe is small
                async with StarburstConnection(cfg, self.logger) as conn:
                    conn.task = task
                    val = await conn.fetch_scalar(probe_sql)
                if val is None:
                    seen[fq] = None
                    self.logger.info(
                        "Iceberg pin: %s -- probe returned NULL "
                        "(table exists but has no snapshots? skipping)",
                        fq,
                    )
                else:
                    snap = int(val)
                    seen[fq] = snap
                    self.logger.info(
                        "Iceberg pin: %s -> snapshot_id=%d", fq, snap,
                    )
            except Exception as exc:
                # Not iceberg, or probe failed for any reason.  Leave
                # this table unpinned and continue.
                seen[fq] = None
                self.logger.debug(
                    "Iceberg pin: %s -- probe failed (likely "
                    "non-iceberg): %s", fq, exc,
                )

        if not any(v is not None for v in seen.values()):
            self.logger.info(
                "Iceberg pin: no iceberg tables detected in base_sql -- "
                "no rewrite performed."
            )
            return base_sql

        # Re-walk the AST and inject FOR VERSION AS OF on each iceberg
        # table reference.  sqlglot represents this as `Version` on
        # Table.this in some dialects; for Trino we use a literal
        # `Version` node attached as table arg `version`.
        for t in tree.find_all(exp.Table):
            cat = t.args.get("catalog")
            sch = t.args.get("db")
            name = t.this
            cat_s = cat.name if cat else None
            sch_s = sch.name if sch else None
            tbl_s = name.name if name else None
            if not tbl_s:
                continue
            fq = ".".join(p for p in (cat_s, sch_s, tbl_s) if p)
            snap = seen.get(fq)
            if snap is None:
                continue
            try:
                # Trino syntax via sqlglot: TableSample / Version.
                # Simplest reliable approach: serialize to SQL string,
                # let regex-free string interpolation add the clause.
                # Mark the AST-level table so we know to inject post-serialize.
                t.set("_qs_pin_snapshot_id", snap)
            except Exception as exc:
                self.logger.debug(
                    "Iceberg pin: could not mark %s for snapshot %d: %s",
                    fq, snap, exc,
                )

        # Serialize the AST first, then string-replace each marked
        # table reference with `<table> FOR VERSION AS OF <snap_id>`.
        # We mark via a unique sentinel comment that sqlglot preserves,
        # then post-process.  Why: sqlglot's Trino dialect may not
        # render an arbitrary node we attach; the safe path is
        # string-level injection of a well-known SQL keyword phrase.
        rewritten = base_sql
        try:
            sql_dialect_rendered = tree.sql(dialect="trino")
            # For each table that we marked, find its rendering and
            # append the version clause.  We match the fully-qualified
            # form first (most specific) and fall back to bare table
            # name only if FQ is absent.
            for t in tree.find_all(exp.Table):
                snap = t.args.get("_qs_pin_snapshot_id")
                if snap is None:
                    continue
                cat_s = (t.args.get("catalog").name
                          if t.args.get("catalog") else None)
                sch_s = (t.args.get("db").name if t.args.get("db") else None)
                tbl_s = t.this.name if t.this else None
                if not tbl_s:
                    continue
                # Strip the marker before serializing.
                t.args.pop("_qs_pin_snapshot_id", None)
                fq_forms = []
                if cat_s and sch_s:
                    fq_forms.append(f"{cat_s}.{sch_s}.{tbl_s}")
                if sch_s:
                    fq_forms.append(f"{sch_s}.{tbl_s}")
                fq_forms.append(tbl_s)
                # Find the first form that appears in the rendered SQL
                # and append the version clause AFTER it.  Use a regex
                # with word boundaries to avoid mid-token matches.
                import re as _r
                injected = False
                for form in fq_forms:
                    # Escape dots; \b for word boundary on each side.
                    pat = r"\b" + _r.escape(form) + r"\b(?!\s*FOR\s+VERSION)"
                    new_sql, n = _r.subn(
                        pat, f"{form} FOR VERSION AS OF {snap}",
                        sql_dialect_rendered, count=1,
                    )
                    if n > 0:
                        sql_dialect_rendered = new_sql
                        injected = True
                        break
                if not injected:
                    self.logger.warning(
                        "Iceberg pin: could not inject snapshot_id=%d "
                        "for %s -- table not found in serialized SQL.",
                        snap, ".".join(p for p in (cat_s, sch_s, tbl_s) if p),
                    )
            rewritten = sql_dialect_rendered
        except Exception as exc:
            self.logger.warning(
                "Iceberg pin: serialize-and-inject failed (%s) -- "
                "returning original SQL.", exc,
            )
            return base_sql

        return rewritten

    async def _kill_orphan_trino_queries(
        self,
        connection_config: Dict[str, Any],
        run_id: Any,
        task: Optional[Dict] = None,
    ) -> int:
        """Instance-method shim -- delegates to the module-level
        ``kill_orphan_trino_queries`` so callers without a step
        instance (file_standalone.main) can invoke cleanup without
        constructing a temporary StarburstToFileOnCloud just for the
        method access (audit-flagged anti-pattern, 2026-06-21)."""
        return await kill_orphan_trino_queries(
            connection_config, run_id, logger=self.logger, task=task,
        )

    async def _probe_trino_capacity(
        self,
        connection_config: Dict[str, Any],
        task: Optional[Dict] = None,
    ) -> Optional[Dict[str, Any]]:
        """One-query probe of Trino cluster capacity (~100ms typical).

        2026-06-21 (post-pilot Trino-pressure feedback): when operator
        sets trino_profile='auto', this probe runs ONCE at plan time
        and feeds the live cluster state into AutoPlan's ceiling
        decision.  Profile != 'auto' skips this probe entirely (zero
        overhead in default mode).

        Returns:
          {"queued": int, "running": int, "active_workers": int}
          OR None on any failure (AutoPlan falls back to shared_normal).

        Query: ``SELECT state, COUNT(*) FROM system.runtime.queries
        WHERE created > current_timestamp - interval '5' minute
        GROUP BY state``.  Cheap (Trino's coordinator-local view) and
        bounded (timeout 10s).  Falls back silently if Trino doesn't
        expose system.runtime (e.g. older Trino, restricted role).
        """
        sql = (
            "SELECT state, COUNT(*) AS cnt "
            "FROM system.runtime.queries "
            "WHERE created > current_timestamp - interval '5' minute "
            "GROUP BY state"
        )
        cfg = dict(connection_config)
        cfg["request_timeout"] = 10  # bounded; never blocks the planner
        try:
            state_counts: Dict[str, int] = {}
            async with StarburstConnection(cfg, self.logger) as conn:
                conn.task = task
                await conn.execute(sql)
                async for batch in conn.fetch_chunks(1000):
                    for row in batch:
                        try:
                            state_counts[str(row[0])] = int(row[1])
                        except (TypeError, ValueError, IndexError):
                            continue
            workers_count = 0
            try:
                async with StarburstConnection(cfg, self.logger) as conn2:
                    conn2.task = task
                    val = await conn2.fetch_scalar(
                        "SELECT COUNT(*) FROM system.runtime.nodes "
                        "WHERE state = 'active'"
                    )
                    if val is not None:
                        workers_count = int(val)
            except Exception:
                pass  # nodes table optional
            result = {
                "queued":         state_counts.get("QUEUED", 0),
                "running":        state_counts.get("RUNNING", 0),
                "planning":       state_counts.get("PLANNING", 0),
                "active_workers": workers_count,
            }
            self.logger.info(
                "Trino capacity probe: queued=%d running=%d planning=%d "
                "active_workers=%d",
                result["queued"], result["running"],
                result["planning"], result["active_workers"],
            )
            return result
        except Exception as exc:
            self.logger.info(
                "Trino capacity probe failed (%s) -- AutoPlan falls back "
                "to shared_normal ceiling.  Set trino_profile='shared_normal' "
                "or 'shared_busy' explicitly to silence the probe.",
                exc,
            )
            return None

    async def _run_probe_query(
        self,
        base_sql: str,
        partition_column: Optional[str],
        checksum_columns: List[str],
        connection_config: Dict[str, Any],
        timeout: int = 1800,
        task: Optional[Dict] = None,
    ) -> Optional[Dict[str, Any]]:
        """Execute ProbeQuery -- ONE Trino scan replacing pre-flight COUNT,
        partition discovery, and source-side SUM for the planner.

        2026-06-20 -- STRATEGIC: the planner needs three anchors before
        chunks can run --
          * G1 / partition counts (anchors G2 / G4)
          * per-partition row counts (sized the per-chunk gate)
          * per-partition column SUMs (anchors C5_sum gate)
        Today these come from three independent queries (each a full
        scan of base_sql).  Trino's GROUP BY shuffle can emit all three
        in one pass; ``_derive_probe_sql`` builds the combined SQL and
        this helper runs it.

        Returns:
          On AST success:
            {
              "mode": "ast",
              "values": [v1, v2, ...] | None  (None when SINGLE-mode probe),
              "counts": {v: int}              (or {None: total_count} when SINGLE),
              "sums":   {v: {col: Decimal}}   (or {None: {...}} when SINGLE),
              "total_count": int,
              "total_sums":  {col: Decimal},
            }
          On skip (shape-affecting base_sql, sqlglot missing/failed,
          qualifier mismatch, computed-alias partition col, etc.):
            ``None`` -- caller falls back to legacy primitives
            (separate ``_fetch_count`` / ``_discover_partition_values`` /
            ``_fetch_source_checksums``).

        Never raises: probe-query execution failures classified as
        retryable are downgraded to None (caller falls back).  Fatal
        Trino errors (auth / catalog) propagate -- the run can't
        proceed anyway.
        """
        from decimal import Decimal, InvalidOperation
        import time as _time
        probe_sql, mode = _derive_probe_sql(
            base_sql, partition_column, checksum_columns,
            dialect="trino", logger=self.logger,
        )
        if mode == "skip":
            return None  # caller falls back

        # 2026-06-20 deep-dive -- HARD CAP on probe result row count to
        # protect the Python process from a runaway partition cardinality
        # discovery (e.g. operator pointed partition_column at a
        # high-cardinality dimension by mistake).  Default 100k rows
        # bounds memory to ~50 MB even with wide sums + Decimals.
        # Operator override via probe_max_partitions on the task /
        # config.  When the probe exceeds this cap, we abandon the
        # probe result, log loudly, and return None so the caller falls
        # back to the legacy path (which has its own partition cap
        # via max_partitions).
        _probe_max = int(
            (task or {}).get("probe_max_partitions")
            or (task or {}).get("PROBE_MAX_PARTITIONS")
            or 100_000
        )

        self.logger.info(
            "ProbeQuery (ast, partition_col=%r, sum_cols=%s, "
            "row_cap=%s, timeout=%ds):\n%s",
            partition_column, list(checksum_columns),
            f"{_probe_max:,}", timeout, probe_sql,
        )
        cfg = dict(connection_config)
        cfg["request_timeout"] = timeout

        values: List[Any] = []
        counts: Dict[Any, int] = {}
        sums: Dict[Any, Dict[str, Any]] = {}
        total_count = 0
        total_sums: Dict[str, Any] = {c: Decimal(0) for c in checksum_columns}
        null_pv_seen = False  # 2026-06-20 -- track NULL partition values explicitly
        _t0 = _time.time()
        try:
            async with StarburstConnection(cfg, self.logger) as conn:
                conn.task = task
                await conn.execute(probe_sql)
                async for batch in conn.fetch_chunks(10_000):
                    for row in batch:
                        idx = 0
                        if partition_column:
                            pv = row[idx]; idx += 1
                        else:
                            pv = None
                        # cnt: defensive int() guard against Trino returning
                        # bigint as Decimal in some driver builds
                        try:
                            cnt = int(row[idx])
                        except (TypeError, ValueError) as cnt_exc:
                            self.logger.warning(
                                "ProbeQuery row had non-int count %r (%s) "
                                "-- coercing to 0", row[idx], cnt_exc,
                            )
                            cnt = 0
                        idx += 1
                        col_sums: Dict[str, Any] = {}
                        for col in checksum_columns:
                            v = row[idx]; idx += 1
                            if v is None:
                                col_sums[col] = Decimal(0)
                            else:
                                try:
                                    col_sums[col] = Decimal(str(v))
                                except (InvalidOperation, ValueError) as sv_exc:
                                    self.logger.warning(
                                        "ProbeQuery SUM(%s) returned "
                                        "non-numeric %r (%s) -- "
                                        "treating as 0 for this partition",
                                        col, v, sv_exc,
                                    )
                                    col_sums[col] = Decimal(0)
                            total_sums[col] += col_sums[col]
                        if partition_column:
                            if pv is None:
                                null_pv_seen = True
                            values.append(pv)
                        counts[pv] = cnt
                        sums[pv] = col_sums
                        total_count += cnt
                        # CAP -- abandon probe if cardinality explodes.
                        if partition_column and len(values) > _probe_max:
                            _t1 = _time.time()
                            self.logger.warning(
                                "ProbeQuery ABANDONED -- discovery "
                                "returned > %s partitions (read %s rows "
                                "in %.1fs).  Falling back to legacy "
                                "primitives; pick a lower-cardinality "
                                "partition column OR raise "
                                "probe_max_partitions on the polling row.",
                                f"{_probe_max:,}", f"{len(values):,}",
                                _t1 - _t0,
                            )
                            return None
        except Exception as exc:
            # Classify -- fatal propagates, anything retryable falls back
            # to legacy primitives.  Skip-on-failure keeps the caller
            # safe even when the probe is the bottleneck.
            err = StarburstErrorClassifier.classify(exc)
            if err.error_type == StarburstErrorType.FATAL:
                raise
            self.logger.warning(
                "ProbeQuery execution failed (%s) -- falling back to "
                "legacy primitives (separate COUNT + discovery + "
                "source-sum scans).  Original error: %s",
                err.error_type.value, exc,
            )
            return None
        _t1 = _time.time()

        # 2026-06-20 deep-dive -- NULL partition value is legal in Trino
        # but the downstream chunk SQL builder uses `col IS NULL` which
        # is correct; just log it so operators know what's happening.
        if null_pv_seen:
            self.logger.info(
                "ProbeQuery: partition column has NULL values -- "
                "downstream chunk will execute `WHERE col IS NULL` for "
                "that bucket (Trino-correct, just FYI for the operator)."
            )

        self.logger.info(
            "ProbeQuery result in %.1fs: partitions=%d total_rows=%s "
            "total_sums={%s}",
            _t1 - _t0,
            len(values) if partition_column else 1,
            f"{total_count:,}",
            ", ".join(f"{c}={total_sums[c]}" for c in checksum_columns),
        )
        return {
            "mode": "ast",
            "values": values if partition_column else None,
            "counts": counts,
            "sums": sums,
            "total_count": total_count,
            "total_sums": total_sums,
            "had_null_partition": null_pv_seen,
            "elapsed_seconds": _t1 - _t0,
        }

    async def _discover_partition_values(
        self, base_sql: str, partition_column: str,
        connection_config: Dict[str, Any], max_partitions: int,
        count_timeout: int = 1800, task: Optional[Dict] = None,
    ) -> Tuple[List[Any], Dict[Any, int]]:
        """Returns (sorted_distinct_values, value -> count map).

        Default mode ``group_by`` uses ONE query:
          ``SELECT col, COUNT(*) FROM (base) GROUP BY col``
        Both the values and per-value counts in a single Trino round trip.
        Fast, but the GROUP BY shuffle can OOM Trino on a 170M+ row
        table with a high-cardinality partition column.

        2026-06-13 -- 170M concern: alternate mode ``distinct`` issues:
          ``SELECT DISTINCT col FROM (base)``
        to enumerate values (cheaper shuffle), then DEFERS the per-value
        count to chunk-execution time (G4 expected values come back
        empty so the G4 ledger drops to advisory; G3 and G5 still hold).
        Set via per-job JSON's ``partition_config.discovery_mode``.

        On a GROUP BY failure classified as RETRYABLE (typically Trino
        OOM / memory exceeded), the default group_by mode now FALLS
        BACK to distinct mode automatically rather than failing the
        whole run.

        Fix #3 -- trailing-comment-safe wrap as ``_fetch_count``.
        Fix #6 -- honours ``count_timeout`` (default 1800 s).
        """
        # Read mode from the call's caller chain (task -> partition_cfg).
        # Default "group_by" preserves prior behavior.
        discovery_mode = "group_by"
        # The mode lives in partition_cfg in _build_scan_plan -- pass via
        # an instance attribute set by the caller.
        discovery_mode = getattr(self, "_partition_discovery_mode", None) or discovery_mode

        async def _try_group_by() -> Tuple[List[Any], Dict[Any, int]]:
            # 2026-06-17 -- AST-derive ``col AS pv, COUNT(*) GROUP BY col``
            # over source FROM/JOIN/WHERE instead of wrapping the full
            # base_sql in a subquery.  The legacy wrap broke on qualified
            # partition columns (``FACT_TABLE.SAP_COMPANY_ID``) because
            # ``FACT_TABLE`` is not in scope after the subquery alias --
            # Trino raised "Column not resolved".  AST mode emits
            # ``GROUP BY FACT_TABLE.SAP_COMPANY_ID`` against the source
            # SELECT where the qualifier resolves natively.  Falls back
            # to legacy wrap on sqlglot parse failure (bare column name
            # used in the wrap so the outer SELECT's ``plan_q`` alias
            # doesn't conflict with the original table qualifier).
            sql, used_mode = _derive_group_by_count_sql(
                base_sql, partition_column,
                dialect="trino", logger=self.logger,
            )
            if used_mode == "ast":
                self.logger.info(
                    "Partition discovery (group_by, AST rewrite) for column %r: "
                    "GROUP BY over source FROM/JOIN/WHERE -- no subquery wrap",
                    partition_column,
                )
            else:
                self.logger.info(
                    "Partition discovery (group_by, wrap fallback) for column %r: "
                    "AST rewrite unavailable, using legacy subquery wrap with "
                    "bare column name (table qualifier stripped)",
                    partition_column,
                )
            self.logger.info("Partition discovery SQL:\n%s", sql)
            values: List[Any] = []
            counts: Dict[Any, int] = {}
            cfg = dict(connection_config)
            cfg["request_timeout"] = count_timeout
            async with StarburstConnection(cfg, self.logger) as conn:
                conn.task = task
                await conn.execute(sql)
                async for batch in conn.fetch_chunks(10_000):
                    for row in batch:
                        v, c = row[0], int(row[1])
                        values.append(v)
                        counts[v] = c
            return values, counts

        async def _try_distinct() -> Tuple[List[Any], Dict[Any, int]]:
            # 2026-06-17 -- AST-derive distinct from base_sql: strip
            # projection + GROUP BY + ORDER BY, keep FROM/JOIN/WHERE,
            # add SELECT DISTINCT col.  Trino sees a cheap source-only
            # probe instead of a wrap of the full transformation.
            # Falls back to subquery wrap on sqlglot parse failure.
            sql, used_mode = _derive_distinct_partition_sql(
                base_sql, partition_column,
                dialect="trino", logger=self.logger,
            )
            if used_mode == "ast":
                self.logger.info(
                    "Partition discovery (distinct mode, AST rewrite): probing "
                    "source FROM/JOIN/WHERE directly -- no subquery wrap"
                )
            else:
                self.logger.info(
                    "Partition discovery (distinct mode, wrap fallback): "
                    "AST rewrite unavailable, using legacy subquery wrap"
                )
            values: List[Any] = []
            cfg = dict(connection_config)
            cfg["request_timeout"] = count_timeout
            async with StarburstConnection(cfg, self.logger) as conn:
                conn.task = task
                await conn.execute(sql)
                async for batch in conn.fetch_chunks(10_000):
                    for row in batch:
                        values.append(row[0])
            # Empty counts dict -- expected_per_partition unknown until
            # the chunk runs.  G4 ledger entry will note unknowns.
            self.logger.info(
                "Partition discovery (distinct mode): %d distinct values; "
                "per-value counts will be measured at chunk-execution time "
                "(G4 ledger advisory only)",
                len(values),
            )
            return values, {}

        if discovery_mode == "distinct":
            values, counts = await _try_distinct()
        else:
            try:
                values, counts = await _try_group_by()
            except Exception as exc:
                err = StarburstErrorClassifier.classify(exc)
                if err.is_retryable:
                    self.logger.warning(
                        "Partition discovery GROUP BY failed (retryable: %s) -- "
                        "falling back to DISTINCT mode without per-partition counts: %s",
                        err.error_type.value, exc,
                    )
                    values, counts = await _try_distinct()
                else:
                    raise
        # 2026-06-17 -- the max_partitions check moved to _build_scan_plan
        # so bucketing (which groups N adjacent values into one chunk) can
        # bring an over-cap discovery within budget BEFORE the refusal
        # fires.  Discovery itself stays cap-agnostic.
        return values, counts

    # ----- Partition SQL rewriting ------------------------------------

    def _add_partition_predicate(
        self,
        base_sql: str,
        column: str,
        value: Any,
    ) -> str:
        """Build the per-chunk SQL with a partition predicate.

        2026-06-17 -- strategic rewrite.  User feedback: "starburst going
        to execute same query 100 times".  The legacy subquery wrap
        forces Trino to (often) re-execute the entire base_sql per
        chunk because predicate pushdown through wraps is best-effort.

        sqlglot AST-injects the predicate INTO base_sql's top-level
        WHERE (and into every UNION branch / CTE body).  Trino sees the
        predicate ON the source SELECT, prunes partitions natively on
        Iceberg, and pushes the filter through the JOIN.  Per-chunk
        work shrinks to just the matching partition's rows.

        Auto-falls-back to legacy subquery wrap when sqlglot can't parse
        the SQL (logged at WARN).  No operator-facing toggle: the
        auto-fallback handles parse failures, G3 reconcile (sum(chunk
        rows) == G1) catches any semantic drift downstream, and
        pre-flight AST-safety WARNs name the risky shapes (window
        functions etc.) before the run starts.
        """
        rewritten, _ = _inject_where_into_base_sql(
            base_sql, column, value, dialect="trino", logger=self.logger,
        )
        return rewritten

    # ----- Chunk execution --------------------------------------------

    async def _execute_chunk_with_retry(
        self,
        plan: ScanPlan,
        connection_config: Dict[str, Any],
        partition_index: int,
        partition_value: Any,
        chunk_file_path: str,
        delimiter: str,
        attempt_signal: threading.Event,
        task: Optional[Dict] = None,
    ) -> ChunkResult:
        """Execute one chunk with bounded retries.

        Each attempt re-opens the connection, re-issues the query, and
        re-writes the file from scratch.  We never append within a
        retry — half-written rows would silently inflate the count.
        """
        attempt = 0
        start = time.time()
        last_error: Optional[StarburstError] = None
        while attempt < plan.max_chunk_retries + 1:
            attempt += 1
            try:
                _chunk_ret = await self._execute_one_chunk(
                    plan, connection_config, partition_index, partition_value,
                    chunk_file_path, delimiter, task=task,
                )
                # _execute_one_chunk returns (rows, sums) on legacy path or
                # (rows, sums, timing) post-2026-06-21.  Tuple-len check is
                # the safest way to stay compatible with both shapes.
                if len(_chunk_ret) == 3:
                    actual, actual_sums, _chunk_timing = _chunk_ret
                else:
                    actual, actual_sums = _chunk_ret
                    _chunk_timing = {}
                expected = (
                    plan.expected_per_partition.get(partition_value)
                    if plan.mode == ScanMode.PARTITION_VALUES else plan.expected_total
                )
                # 2026-06-20 -- PER-CHUNK SUM GATE (early-detection of
                # source drift).  When ProbeQuery populated
                # plan.expected_per_partition_sums, the writer's per-
                # column running sums must match the per-partition anchor
                # at chunk close.  Mismatch = real data drift between
                # probe scan and chunk extract -- usually iceberg
                # snapshot drift, occasionally row-count-conserving
                # corruption (rows transposed).  We treat this the same
                # as a row-count mismatch: soft retries (writer race /
                # transient Trino disconnect) then fail this bucket
                # without halting the run.
                expected_sums = (
                    plan.expected_per_partition_sums.get(partition_value)
                    if plan.mode == ScanMode.PARTITION_VALUES
                    else None
                )
                sum_mismatches: List[str] = []
                if expected_sums and actual_sums:
                    for _col, _exp_v in expected_sums.items():
                        _act_v = actual_sums.get(_col)
                        if _act_v is None:
                            continue  # column dropped by writer (non-numeric)
                        if _act_v != _exp_v:
                            sum_mismatches.append(
                                f"{_col}: expected={_exp_v} actual={_act_v} "
                                f"(delta {_act_v - _exp_v:+})"
                            )
                if sum_mismatches and plan.fail_on_mismatch and attempt <= plan.max_chunk_retries:
                    self.logger.warning(
                        "Chunk %d/%d value=%s SUM mismatch on attempt %d/%d: %s "
                        "-- retrying (writer race / iceberg snapshot drift). "
                        "After retries exhausted, bucket fails without "
                        "halting the run.",
                        partition_index, plan.chunk_count, partition_value,
                        attempt, plan.max_chunk_retries + 1,
                        "; ".join(sum_mismatches),
                    )
                    if os.path.exists(chunk_file_path):
                        try:
                            os.remove(chunk_file_path)
                        except OSError:
                            pass
                    last_error = StarburstError(
                        error_type=StarburstErrorType.RETRYABLE,
                        message=f"chunk #{partition_index}: per-chunk SUM mismatch -- {sum_mismatches[0]}",
                        original_error=ValueError("per-chunk SUM mismatch"),
                        is_retryable=True,
                        should_stop_process=False,
                    )
                    await asyncio.sleep(min(2 ** attempt, 30))
                    continue  # next attempt
                if sum_mismatches and plan.fail_on_mismatch:
                    diag_sum = (
                        f"chunk #{partition_index} value={partition_value!r}: "
                        f"per-chunk SUM mismatch (rows={actual:,} matched expected, "
                        f"but column sums diverged): {'; '.join(sum_mismatches)}. "
                        f"This is row-count-conserving data drift -- likely "
                        f"iceberg snapshot drift between probe scan and chunk "
                        f"extract.  Bucket marked FAILED; run continues."
                    )
                    self.logger.error(diag_sum)
                    if os.path.exists(chunk_file_path):
                        try:
                            os.remove(chunk_file_path)
                        except OSError:
                            pass
                    return ChunkResult(
                        partition_index=partition_index,
                        partition_value=partition_value,
                        file_path=chunk_file_path,
                        expected=expected,
                        actual=actual,
                        attempts=attempt,
                        duration_sec=time.time() - start,
                        success=False,
                        error=diag_sum,
                        error_type=None,
                        should_stop_process=False,
                    )
                if sum_mismatches:  # fail_on_mismatch=False -- just warn
                    self.logger.warning(
                        "Chunk %d/%d value=%s SUM mismatch (fail_on_mismatch=False): %s "
                        "-- continuing.  End-of-job G5 SUM reconcile will "
                        "still surface this.",
                        partition_index, plan.chunk_count, partition_value,
                        "; ".join(sum_mismatches),
                    )
                if expected is not None and actual != expected:
                    # 2026-06-18 -- HYBRID retry-then-isolate policy.
                    # Soft on first max_chunk_retries attempts (mismatch
                    # MAY be transient -- ChunkWriter race, partial Trino
                    # disconnect, etc).  If persistent across all
                    # retries, mark THIS bucket failed but DO NOT halt
                    # the run.  Other buckets continue; operator
                    # re-runs just the failed buckets at end.
                    #
                    # When fail_on_mismatch=False, downgrade unconditionally
                    # to WARN+success (operator owns the cumulative G3
                    # reconcile at end-of-job).
                    if not plan.fail_on_mismatch:
                        self.logger.warning(
                            "Chunk %d/%d value=%s mismatch: actual=%s "
                            "expected=%s (delta %+d) -- fail_on_mismatch=False, "
                            "treating as success.  Job-level G3 reconcile will "
                            "anchor cumulative completeness at end-of-job.",
                            partition_index, plan.chunk_count, partition_value,
                            f"{actual:,}", f"{expected:,}", actual - expected,
                        )
                    elif attempt <= plan.max_chunk_retries:
                        # SOFT phase: log WARN, remove partial chunk,
                        # let the retry loop spin.  Mismatch may be
                        # transient -- give it another N-1 attempts.
                        self.logger.warning(
                            "Chunk %d/%d value=%s mismatch on attempt %d/%d: "
                            "actual=%s expected=%s (delta %+d) -- retrying "
                            "in case mismatch is transient (writer race / "
                            "partial Trino disconnect).  After all retries "
                            "exhausted: this bucket will fail but the run "
                            "continues with remaining buckets so operator "
                            "can re-run just the failed bucket(s).",
                            partition_index, plan.chunk_count, partition_value,
                            attempt, plan.max_chunk_retries + 1,
                            f"{actual:,}", f"{expected:,}", actual - expected,
                        )
                        last_error = StarburstError(
                            error_type=StarburstErrorType.RETRYABLE,
                            message=(
                                f"chunk #{partition_index} value="
                                f"{partition_value!r}: actual {actual:,} "
                                f"!= expected {expected:,} "
                                f"(delta {actual - expected:+,})"
                            ),
                            original_error=ValueError(
                                "per-chunk completeness mismatch (soft retry)"
                            ),
                            is_retryable=True,
                            should_stop_process=False,
                        )
                        # Remove the partial chunk so the retry starts
                        # from a clean slate.
                        if os.path.exists(chunk_file_path):
                            try:
                                os.remove(chunk_file_path)
                            except OSError:
                                pass
                        await asyncio.sleep(min(2 ** attempt, 30))
                        continue  # next attempt
                    else:
                        # HARD phase: retries exhausted, mismatch is
                        # persistent.  Mark THIS bucket failed but DO
                        # NOT halt the run -- other buckets keep going,
                        # we'll list the failed value at end-of-job so
                        # operator re-runs just it.
                        diag = (
                            f"chunk #{partition_index} value={partition_value!r}: "
                            f"actual rows {actual:,} != expected {expected:,} "
                            f"(delta {actual - expected:+,}) -- persistent "
                            f"across {plan.max_chunk_retries + 1} attempts.  "
                            f"This bucket is marked FAILED; run continues "
                            f"with remaining buckets.  Likely causes: "
                            f"(1) iceberg snapshot drift since discovery; "
                            f"(2) base_sql has DISTINCT / outer GROUP BY / "
                            f"window function -- discovery strips them so "
                            f"its sum differs from chunk's IN-clause result. "
                            f" Operator: at end-of-run, the run-report lists "
                            f"failed buckets; re-trigger the polling row "
                            f"with PARTITION_VALUES filtered to those "
                            f"values to retry just them.  Set "
                            f"FAIL_ON_MISMATCH=FALSE to bypass this check "
                            f"entirely (G3 still anchors at job level)."
                        )
                        self.logger.error(diag)
                        if os.path.exists(chunk_file_path):
                            try:
                                os.remove(chunk_file_path)
                            except OSError:
                                pass
                        # NOTE: should_stop_process=False -- this is the
                        # key change vs the prior policy.  Failure is
                        # ISOLATED to this bucket; sibling buckets keep
                        # going.  Operator re-runs failed ones manually.
                        return ChunkResult(
                            partition_index=partition_index,
                            partition_value=partition_value,
                            file_path=chunk_file_path,
                            expected=expected,
                            actual=actual,
                            attempts=attempt,
                            duration_sec=time.time() - start,
                            success=False,
                            error=diag,
                            error_type=None,
                            should_stop_process=False,
                        )
                duration = time.time() - start
                self.logger.info(
                    "Chunk %d/%d value=%s OK: rows=%s expected=%s attempts=%d duration=%.1fs",
                    partition_index, plan.chunk_count, partition_value,
                    actual, expected, attempt, duration,
                )
                return ChunkResult(
                    partition_index=partition_index,
                    partition_value=partition_value,
                    file_path=chunk_file_path,
                    expected=expected,
                    actual=actual,
                    attempts=attempt,
                    duration_sec=duration,
                    success=True,
                    queue_wait_sec=_chunk_timing.get("queue_wait_sec"),
                    stream_sec=_chunk_timing.get("stream_sec"),
                )
            except Exception as exc:
                err = StarburstErrorClassifier.classify(exc)
                last_error = err
                self.logger.error(
                    "Chunk %d/%d value=%s FAILED (attempt %d/%d, type=%s): %s",
                    partition_index, plan.chunk_count, partition_value,
                    attempt, plan.max_chunk_retries + 1, err.error_type.value, exc,
                )
                # Remove partial chunk file so the retry starts fresh.
                if os.path.exists(chunk_file_path):
                    try:
                        os.remove(chunk_file_path)
                    except OSError:
                        pass
                if err.should_stop_process:
                    attempt_signal.set()
                    return ChunkResult(
                        partition_index=partition_index,
                        partition_value=partition_value,
                        file_path=chunk_file_path,
                        expected=plan.expected_per_partition.get(partition_value),
                        actual=0,
                        attempts=attempt,
                        duration_sec=time.time() - start,
                        success=False,
                        error=err.message,
                        error_type=err.error_type,
                        should_stop_process=True,
                    )
                if not err.is_retryable or attempt > plan.max_chunk_retries:
                    return ChunkResult(
                        partition_index=partition_index,
                        partition_value=partition_value,
                        file_path=chunk_file_path,
                        expected=plan.expected_per_partition.get(partition_value),
                        actual=0,
                        attempts=attempt,
                        duration_sec=time.time() - start,
                        success=False,
                        error=err.message,
                        error_type=err.error_type,
                    )
                await asyncio.sleep(min(2 ** attempt, 30))
        return ChunkResult(
            partition_index=partition_index,
            partition_value=partition_value,
            file_path=chunk_file_path,
            expected=plan.expected_per_partition.get(partition_value),
            actual=0,
            attempts=attempt,
            duration_sec=time.time() - start,
            success=False,
            error=last_error.message if last_error else "max retries exceeded",
            error_type=last_error.error_type if last_error else None,
        )

    async def _execute_one_chunk(
        self,
        plan: ScanPlan,
        connection_config: Dict[str, Any],
        partition_index: int,
        partition_value: Any,
        chunk_file_path: str,
        delimiter: str,
        task: Optional[Dict] = None,
    ) -> Tuple[int, Dict[str, Any], Dict[str, Any]]:
        """Single attempt: stream + write.  Returns:
        ``(actual_rows_written, per_column_sums, timing)``

        2026-06-21 -- added third element ``timing`` dict carrying:
          * queue_wait_sec -- time from query submit to first batch
            (Trino coordinator queue + plan time)
          * stream_sec     -- time from first batch to last row written
        Used by the per-chunk diagnostic in result.html so operators
        can see where the time went on slow chunks.  Either value is
        None when not measurable (test mocks / very short chunks)."""
        if plan.mode == ScanMode.SINGLE:
            sql = plan.base_sql
        else:
            # 2026-06-17 -- AST-inject WHERE into base_sql (sqlglot)
            # is the new default).  Trino sees the predicate ON the source
            # SELECT instead of an outer wrap -- partition pruning fires on
            # Iceberg, JOIN filter pushes through, per-chunk work shrinks
            # to just the matching partition's rows.
            sql = self._add_partition_predicate(
                plan.base_sql, plan.partition_column, partition_value,
            )

        # 2026-06-17 -- log the per-chunk context BEFORE executing so the
        # operator can correlate the upcoming SQL with the partition value
        # it's serving.  StarburstConnection.execute() then dumps the full
        # SQL between <<<SQL>>> markers.
        if plan.mode == ScanMode.SINGLE:
            self.logger.info(
                "Chunk SQL [SINGLE mode, file=%s]:",
                os.path.basename(chunk_file_path),
            )
        else:
            # 2026-06-17 -- bucketing-aware log.  When partition_value is
            # a tuple/list, render as a bucket: "(v1, v2, ..., vN) [N
            # values]" rather than splat the full tuple, so the log line
            # stays scannable for buckets of 11+ values.
            if isinstance(partition_value, (list, tuple)):
                _members = list(partition_value)
                if len(_members) <= 4:
                    _label = f"bucket=({', '.join(repr(v) for v in _members)})"
                else:
                    _label = (
                        f"bucket=({repr(_members[0])}, {repr(_members[1])}, "
                        f"..., {repr(_members[-1])}) "
                        f"[{len(_members)} values]"
                    )
            else:
                _label = f"{plan.partition_column}={partition_value!r}"
            self.logger.info(
                "Chunk SQL [partition #%d, %s, file=%s]:",
                partition_index, _label, os.path.basename(chunk_file_path),
            )

        async with StarburstConnection(connection_config, self.logger) as conn:
            conn.task = task  # cancellation propagation (2026-06-12)
            await conn.execute(sql)
            columns = conn.get_columns()
            # Fix #4 + #8 — thread the ScanPlan's per-job knobs into
            # the writer.  Operator can shrink ``queue_maxsize`` for
            # wide tables (200+ cols) to keep peak memory bounded
            # AND raise ``writer_idle_timeout_seconds`` for slow Trino
            # renders that legitimately gap 3-5 min between fetches.
            writer = ChunkWriter(
                chunk_file_path, columns, delimiter, self.logger,
                queue_maxsize=plan.queue_maxsize,
                idle_timeout_seconds=plan.writer_idle_timeout_seconds,
                # 2026-06-20 -- per-chunk SUM accumulation.  When the
                # plan carries checksum_columns (set by ProbeQuery), the
                # writer sums those columns as it streams; per-chunk
                # gate compares the on-the-fly sums against
                # plan.expected_per_partition_sums[v] at chunk close.
                sum_columns=list(plan.checksum_columns or []),
            )
            writer.start()
            try:
                async for batch in conn.fetch_chunks(plan.batch_size):
                    # Fix #7 — ``put_batch`` is blocking when the queue
                    # is full.  Without the ``to_thread`` wrap, the
                    # whole event loop pauses on every full queue,
                    # serialising concurrent chunks.  With the wrap,
                    # back-pressure stays at the writer thread + the
                    # event loop is free to drive other partitions'
                    # fetches.
                    await asyncio.to_thread(writer.put_batch, batch)
            finally:
                await asyncio.to_thread(writer.signal_end)
                await asyncio.to_thread(writer.join)
        # 2026-06-21 -- log this chunk's queue-wait vs stream-time so
        # operators can see WHERE the time went on a slow chunk.  The
        # ChunkResult dict carries the same info into result.html via
        # the per-chunk row (added in _execute_chunk_with_retry below).
        if writer.time_first_batch and writer.time_started:
            _qw = writer.time_first_batch - writer.time_started
            _stream = (writer.time_completed or writer.time_first_batch) - writer.time_first_batch
            self.logger.info(
                "ChunkWriter %s timing: queue_wait=%.1fs stream=%.1fs "
                "rows=%s (queue_wait > stream signals Trino coordinator "
                "queueing -- consider lowering trino_profile or raising "
                "concurrency ceiling)",
                os.path.basename(chunk_file_path), _qw, _stream,
                f"{writer.records_written:,}",
            )
        return writer.records_written, dict(writer.sums), {
            "queue_wait_sec": (
                (writer.time_first_batch - writer.time_started)
                if writer.time_first_batch and writer.time_started else None
            ),
            "stream_sec": (
                (writer.time_completed - writer.time_first_batch)
                if writer.time_completed and writer.time_first_batch else None
            ),
        }

    # ----- Query-plan capture (OPT-IN, default OFF) --------------------

    async def _capture_query_plan_if_enabled(
        self,
        connection_config: Dict[str, Any],
        job_config: Dict[str, Any],
        task: Dict,
    ) -> None:
        """OPT-IN: run EXPLAIN (TYPE DISTRIBUTED) on the composed SQL and
        surface a one-line summary (stage count, partition count
        estimate, broadcast/partitioned join shape) into
        ``FileRunReport.runtime_knobs[f"query_plan_{datasource}"]``.

        Gated by ``task["capture_query_plan"] == truthy`` (polling row
        flag).  Default OFF -- steady-state has ZERO perf impact.
        Adds ~50ms-2s per source against Trino when ON.

        Failure-safe by design: any exception from EXPLAIN (catalog
        permission, network blip, malformed SQL after optimization)
        is caught + logged, NEVER fails the extract.  Worst case =
        same as if the flag was never set.
        """
        flag = task.get("capture_query_plan") if isinstance(task, dict) else None
        truthy = (
            flag is True
            or (isinstance(flag, str) and flag.strip().lower() in
                {"1", "true", "yes", "y", "t"})
            or flag == 1
        )
        if not truthy:
            return  # default path, zero cost

        sql = job_config.get("generated_sql") or ""
        if not sql:
            return
        # 2026-06-21 deep-dive bug #4: Trino rejects trailing semicolons
        # in DBAPI cursor.execute.  The optimizer strips them BUT when
        # operator disables optimization (disable_sql_optimization=true)
        # the raw composer SQL may still have one.  Defensive strip so
        # EXPLAIN doesn't fail on a malformed PREFIX.
        sql = sql.rstrip().rstrip(";").rstrip()
        ds_name = self.DATASOURCE_NAME or "EXTRACT"

        # Use a transient connection so the plan capture doesn't share
        # cursor state with the scan-plan + extract paths.  Tags the
        # session so any leftover EXPLAIN query is killable via the
        # same orphan-cleanup path as real extracts.
        con: Optional["StarburstConnection"] = None
        try:
            import time as _time
            t0 = _time.monotonic()
            cfg = dict(connection_config)
            tags = list(cfg.get("client_tags") or [])
            tags.append("qs_explain")
            cfg["client_tags"] = tags
            con = StarburstConnection(cfg, self.logger)
            await con.connect()
            explain_sql = f"EXPLAIN (TYPE DISTRIBUTED) {sql}"
            await con.execute(explain_sql)
            rows = await asyncio.to_thread(con.cursor.fetchall)
            plan_text = "\n".join(str(r[0]) if isinstance(r, (list, tuple)) else str(r)
                                  for r in rows)
            elapsed_ms = int((_time.monotonic() - t0) * 1000)
            summary = self._summarize_query_plan(plan_text, elapsed_ms)
            if self.run_report is not None:
                try:
                    self.run_report.runtime_knobs[
                        f"query_plan_{ds_name}"
                    ] = summary
                except Exception:
                    pass
            self.logger.info(
                "Query plan captured for %s (%dms): %s",
                ds_name, elapsed_ms, summary,
            )
        except Exception as exc:
            # NEVER fail extract because of EXPLAIN.  Log + carry on.
            self.logger.warning(
                "Query-plan capture skipped for %s (%s); extract "
                "continues unaffected.", ds_name, exc,
            )
        finally:
            # 2026-06-21 audit fix -- close the transient connection in
            # an OUTER finally so a connect() failure can't leak the
            # half-allocated TCP socket.  con.close() is no-op safe when
            # connect never completed.
            if con is not None:
                try:
                    await con.close()
                except Exception:
                    pass

    @staticmethod
    def _summarize_query_plan(plan_text: str, elapsed_ms: int) -> str:
        """Boil a multi-stage EXPLAIN output down to ONE line for the
        result.html runtime_knobs table.  Captures:
          * stage count
          * partition count estimate (if Iceberg + manifest pruning fired)
          * broadcast vs partitioned join distribution
          * scan filter pushdown indicator

        Robust to plan format variation -- missing markers just drop
        from the summary, never raise."""
        import re as _re
        stages = len(_re.findall(r"Fragment\s+\d+", plan_text))
        # Iceberg / Hive partition count hints appear as
        # "splits: <N>" or "partitionCount = <N>" depending on connector.
        m_splits = _re.search(r"splits[:=]\s*(\d+)", plan_text)
        m_parts = _re.search(r"partitionCount\s*=\s*(\d+)", plan_text)
        partitions = m_parts.group(1) if m_parts else (
            m_splits.group(1) if m_splits else "n/a"
        )
        # Join distribution tag (Trino EXPLAIN labels these).
        has_broadcast = "REPLICATED" in plan_text or "Broadcast" in plan_text
        has_partitioned = "Partitioned" in plan_text or "HASH" in plan_text
        join_shape = "broadcast" if has_broadcast and not has_partitioned else (
            "partitioned" if has_partitioned and not has_broadcast else (
                "mixed" if has_broadcast and has_partitioned else "n/a"
            )
        )
        # Filter pushdown indicator -- "ScanFilter" / "FilterScan" /
        # "predicate = ..." inside a table-scan node = pushdown fired.
        pushdown_fired = bool(_re.search(
            r"(ScanFilter|FilterScan|predicate\s*=\s*\[)", plan_text,
        ))
        return (
            f"{stages} stages | {partitions} splits/partitions | "
            f"join={join_shape} | filter_pushdown="
            f"{'YES' if pushdown_fired else 'no'} | EXPLAIN took {elapsed_ms}ms"
        )

    # ----- Job execution ----------------------------------------------

    async def _execute_one_job(
        self, job_config: Dict[str, Any], task: Dict, step_name: str,
    ) -> Dict[str, Any]:
        report_id = job_config.get("report_id")
        self.logger.info("=" * 72)
        self.logger.info("Job start: report_id=%s datasource=%s", report_id, self.DATASOURCE_NAME)
        self.logger.info("=" * 72)

        connection_config = self._build_connection_config(job_config)
        # 2026-06-21 -- ORPHAN-QUERY DETECTION: stamp every Trino query
        # this job runs with stable client_tags so a future restart of
        # the same RUN_ID can find + kill orphan queries from a crashed
        # prior run.  The tags are read by _kill_orphan_trino_queries
        # at startup of the next run.
        _task = task if isinstance(task, dict) else {}
        connection_config["client_tags"] = [
            "qs_etl",
            f"qs_run:{_task.get('run_id', 'unknown')}",
            f"qs_report:{report_id}",
            f"qs_biz:{_task.get('business_date', '')}",
            f"qs_ds:{self.DATASOURCE_NAME}",
        ]
        # 2026-06-18 STAGING DIR -- chunks land under a per-extract
        # sub-directory of the polling-row mapped folder.  Self-consolidate
        # moves the final per-source file to the mapped folder, then we
        # rmtree the staging dir.  Cleanup runs in the try/finally below
        # so staging is gone on success AND failure (unless
        # PRESERVE_CHUNKS_ON_FAILURE=True keeps it for partial-recovery).
        output_dir, staging_dir, base_filename, ext, delimiter = \
            self._resolve_output_paths(job_config, run_id=task.get("run_id"))
        # Register the staging dir for end-of-step cleanup.  Stashed on
        # task too so cross-step / sidecar passes can clean stale ones.
        task["_staging_dir"] = staging_dir
        self.logger.info(
            "Staging dir created at %s (mapped output_dir=%s) -- "
            "chunks land here, final per-source file moved to mapped "
            "at end-of-job.",
            staging_dir, output_dir,
        )

        # 2026-06-21 -- OPT-IN query-plan capture (capture_query_plan=true
        # on polling row).  Default OFF so steady-state has ZERO perf
        # impact (EXPLAIN adds ~50ms-2s per source against Trino).  When
        # ON, runs EXPLAIN (TYPE DISTRIBUTED) on the composed SQL +
        # surfaces a one-line summary (stage count, partition count
        # estimate) into FileRunReport.runtime_knobs so an operator
        # debugging a slow report sees what the planner actually picked.
        await self._capture_query_plan_if_enabled(
            connection_config, job_config, task,
        )

        # 1. Plan + G1 + G2
        plan = await self._build_scan_plan(job_config, connection_config, task=task)

        # 1b. SOURCE-SIDE VALUE-COLUMN CHECKSUM (CompletenessProbe).
        # Opt-in via job_config["checksum_columns"] = ["col1", "col2", ...].
        # Runs ONE aggregate query against ``(base_sql) AS t`` -- post-
        # aggregation, exactly the row set the extract emits.  Result
        # is compared against the sums computed during consolidation
        # (per-source + cross-source).  Catches silent row drop /
        # row duplication that row-count G1 cannot detect when
        # base_sql has shape-affecting DISTINCT / GROUP BY.
        _ck_cols_raw = job_config.get("checksum_columns", []) or []
        if isinstance(_ck_cols_raw, str):
            _ck_cols = [c.strip() for c in _ck_cols_raw.split(",") if c.strip()]
        else:
            _ck_cols = [str(c).strip() for c in _ck_cols_raw if str(c).strip()]
        # 2026-06-20 -- when _build_scan_plan already populated source
        # checksums via the ProbeQuery primitive, skip the redundant
        # _fetch_source_checksums full-table scan entirely.  This is the
        # second of three scans that the strategic ProbeQuery collapsed
        # into one.
        if _ck_cols and plan.source_checksums:
            self.logger.info(
                "G5 checksum source sums for job %s (from ProbeQuery): %s",
                report_id,
                ", ".join(f"SUM({c})={v}" for c, v in plan.source_checksums.items()),
            )
        elif _ck_cols:
            try:
                _src_sums = await self._fetch_source_checksums(
                    plan.base_sql, _ck_cols, connection_config,
                    timeout=plan.count_timeout_seconds, task=task,
                )
                if _src_sums:
                    plan.checksum_columns = list(_ck_cols)
                    plan.source_checksums = _src_sums
                    self.logger.info(
                        "G5 checksum source sums for job %s: %s",
                        report_id,
                        ", ".join(f"SUM({c})={v}" for c, v in _src_sums.items()),
                    )
                else:
                    # Helper SKIPPED (shape-affecting clauses).  Don't
                    # propagate checksum_columns -- per-source +
                    # cross-source steps need a matching source anchor.
                    # Internal-consistency checks (chunk -> per-source
                    # -> cross-source) still run for row count.
                    self.logger.warning(
                        "Job %s: source-side checksum unavailable for "
                        "shape-affected base_sql.  Cross-source value "
                        "checksum disabled; row-count G5 still runs.",
                        report_id,
                    )
            except Exception as _ck_exc:
                # Source-side query failure should NOT abort the run --
                # row-count G5 still fires.  Log loudly so the
                # operator notices the checksum check was skipped.
                self.logger.warning(
                    "Job %s: source-side checksum query FAILED (%s) -- "
                    "row-count G5 will still run, but value-column "
                    "cross-check is disabled for this job.",
                    report_id, _ck_exc,
                )

        self.run_report.add_sql_summary(str(report_id), plan.base_sql)
        self.run_report.set_runtime_knobs(
            batch_size=plan.batch_size,
            max_concurrent_chunks=plan.max_concurrent_chunks,
            max_chunk_retries=plan.max_chunk_retries,
            partition_column=plan.partition_column,
            chunk_count=plan.chunk_count,
            scan_mode=plan.mode.value,
        )
        # 2026-06-20 -- AUTOPLAN explanations in runtime_knobs so result.html
        # shows operator WHY each knob was picked.  No-op when AutoPlan
        # didn't run (legacy path).
        _ap_decisions = task.get("_autoplan_decisions") if isinstance(task, dict) else None
        if isinstance(_ap_decisions, dict):
            self.run_report.set_runtime_knobs(**{
                f"autoplan_{k}": v for k, v in _ap_decisions.items()
            })

        # 2. Plan chunks -- live in staging_dir, NOT mapped output_dir.
        if plan.mode == ScanMode.SINGLE:
            chunk_plans = [(0, None, self._single_chunk_path(staging_dir, base_filename, ext))]
        else:
            chunk_plans = [
                (idx + 1, value, self._chunk_file_path(staging_dir, base_filename, ext, idx + 1, value))
                for idx, value in enumerate(plan.partition_values)
            ]

        # Fix #15 — register every PLANNED chunk path with the artifact
        # registry BEFORE the chunk starts.  Otherwise a chunk that
        # gets cancelled (asyncio.CancelledError) or interrupted mid-
        # write never reaches the success branch that registers it —
        # the partial file then survives the standalone's cleanup pass
        # and leaks onto disk.  Up-front registration guarantees
        # ``RunArtifacts.cleanup_on_failure`` finds it regardless of how
        # the chunk ended (success / failure / cancellation).
        for _, _, p in chunk_plans:
            self.artifacts.add(p, RunArtifacts.CHUNK)

        # 3. Execute chunks with bounded concurrency
        semaphore = asyncio.Semaphore(plan.max_concurrent_chunks)
        stop_signal = threading.Event()

        async def run_one(idx, value, path):
            async with semaphore:
                if stop_signal.is_set():
                    return ChunkResult(
                        partition_index=idx, partition_value=value, file_path=path,
                        expected=plan.expected_per_partition.get(value),
                        actual=0, attempts=0, duration_sec=0.0,
                        success=False, error="skipped after fatal error",
                    )
                return await self._execute_chunk_with_retry(
                    plan, connection_config, idx, value, path, delimiter, stop_signal,
                    task=task,
                )

        coros = [run_one(idx, value, path) for idx, value, path in chunk_plans]
        chunk_results: List[ChunkResult] = await asyncio.gather(*coros, return_exceptions=False)

        # 4. Reconcile (G2 / G3 / G4)
        sum_actual = sum(r.actual for r in chunk_results if r.success)
        successful = [r for r in chunk_results if r.success]
        failed = [r for r in chunk_results if not r.success]
        fatal = [r for r in chunk_results if r.should_stop_process]

        # Register chunk artifacts (for cleanup on failure)
        for r in chunk_results:
            if r.success and os.path.exists(r.file_path):
                self.artifacts.add(r.file_path, RunArtifacts.CHUNK)
            self.run_report.add_chunk_result({
                "job_id": str(report_id),
                # 2026-06-13 -- datasource so the per-chunk run-report
                # table distinguishes CLOUD vs ONPREM partitions of the
                # same report_id (partition_index 0/1/2... collides
                # across sources for cross-source partition-by runs).
                "datasource": self.DATASOURCE_NAME,
                "partition_index": r.partition_index,
                "partition_value": r.partition_value,
                "expected": r.expected,
                "actual": r.actual,
                "attempts": r.attempts,
                "duration_sec": r.duration_sec,
                "file_path": r.file_path if r.success else "",
                # 2026-06-21 -- Trino-pressure diagnostic timings.
                "queue_wait_sec": r.queue_wait_sec,
                "stream_sec": r.stream_sec,
            })

        # Fail-fast on fatal
        if fatal:
            for r in fatal:
                self.logger.error("FATAL chunk: report_id=%s idx=%d err=%s",
                                   report_id, r.partition_index, r.error)
            raise RuntimeError(
                f"Job {report_id}: fatal Starburst error in chunk(s) "
                f"{[r.partition_index for r in fatal]}: {fatal[0].error}"
            )

        if failed:
            # 2026-06-13 -- 170M concern: structured failure summary so
            # the operator can see EXACTLY which partitions failed
            # without parsing the log.  Surface BOTH the success count
            # and the failed partition values so a re-run knows which
            # partitions to target (combined with preserve_chunks_on_failure,
            # the successful chunks survive cleanup).
            successful_count = len(chunk_results) - len(failed)
            # Cap the error detail at 5 failures per type so the message
            # stays readable when many partitions failed simultaneously
            # (e.g. Trino in degraded state).
            details_head = ", ".join(
                f"#{r.partition_index}({r.partition_value})={r.error}"
                for r in failed[:5]
            )
            details_tail = f"... +{len(failed) - 5} more" if len(failed) > 5 else ""
            self.logger.error(
                "Job %s: %d of %d chunks FAILED, %d succeeded.  "
                "Failed partition values: %s",
                report_id, len(failed), len(chunk_results),
                successful_count,
                [r.partition_value for r in failed],
            )
            # Push a structured run-report entry so the HTML report
            # surfaces the partial-completion state.
            if self.run_report:
                self.run_report.add_job_result({
                    "report_id": report_id,
                    "datasource": self.DATASOURCE_NAME,
                    "status": "partial_failure",
                    "records": sum_actual,
                    "chunks": successful_count,
                    "failed_partitions": len(failed),
                    "file_path": "",
                })
            raise RuntimeError(
                f"Job {report_id}: {len(failed)} of {len(chunk_results)} "
                f"chunks FAILED ({successful_count} succeeded, {sum_actual:,} rows "
                f"extracted before halt) -- {details_head}{details_tail}"
            )

        # G3 sanity check.  When G1 was deferred (expected_total is None
        # because we skipped the pre-flight COUNT), G3 has no anchor to
        # compare against -- adopt sum_actual as the measured G1.  G5
        # (consolidated vs sum_actual) still meaningfully proves the
        # merge didn't drop rows.
        if plan.expected_total is None:
            self.logger.info(
                "Job %s: G3 reconcile DEFERRED -- G1 measured from "
                "extract: %s rows (no separate COUNT(*) was run)",
                report_id, f"{sum_actual:,}",
            )
            measured_g1 = sum_actual
        elif plan.fail_on_mismatch and sum_actual != plan.expected_total:
            raise ValueError(
                f"Job {report_id}: G3 reconcile FAILED -- Sum(chunk actual)={sum_actual:,} "
                f"!= expected_total={plan.expected_total:,} (delta {sum_actual - plan.expected_total:+,})"
            )
        elif sum_actual != plan.expected_total:
            # 2026-06-18 -- fail_on_mismatch=False AND G1 != sum_actual.
            # The operator opted out of G3 (typical for shape-affected
            # base_sql -- DISTINCT / GROUP BY / HAVING / QUALIFY /
            # LIMIT -- where G1 counts SOURCE rows but chunks produce
            # AGGREGATED rows, so a mismatch is EXPECTED).
            #
            # CRITICAL: in this branch, the extract row count is the
            # authoritative G1.  Surfacing plan.expected_total here
            # would land the WRONG count on the job result, which
            # ConsolidateFiles then uses for G5 -- producing a false
            # "rows lost or duplicated" failure at the merge step
            # even though every chunk consolidated correctly.
            self.logger.warning(
                "Job %s: G3 mismatch tolerated (fail_on_mismatch=False) -- "
                "G1 source count=%s, extract sum=%s (delta %+d).  "
                "Adopting extract count as measured G1 so downstream "
                "G5 (consolidated rows == measured G1) reconciles "
                "against the same unit.",
                report_id, f"{plan.expected_total:,}", f"{sum_actual:,}",
                sum_actual - plan.expected_total,
            )
            measured_g1 = sum_actual
        else:
            measured_g1 = plan.expected_total

        self.logger.info(
            "Job %s OK: chunks=%d rows=%s expected=%s",
            report_id, len(successful), sum_actual, measured_g1,
        )

        # 2026-06-12 — self-consolidation per source.
        # Merge every successful chunk into ONE per-source file
        # (``CLOUD.dat`` / ``ONPREM.dat``) and run a per-source
        # completeness check (sum(chunk rows) == consolidated rows).
        # ConsolidateFiles downstream then cross-merges N source files
        # (not N*M chunk files), and its G5 check becomes
        # ``sum(per-source consolidated counts) == final file count``.
        chunk_files = [r.file_path for r in successful]
        # 2026-06-18 -- per-source completeness signals.  Defaults so the
        # result dict construction below always has these fields, even
        # in the no-chunks (0-row scan) branch.
        _per_source_md5 = ""
        _per_source_sha256 = ""
        _per_source_bytes = 0
        _per_source_sums: Dict[str, Any] = {}  # CompletenessProbe: {col: Decimal}
        if chunk_files:
            # 2026-06-18 -- self-consolidate INSIDE staging_dir, then
            # ``os.replace`` the per-source file into the mapped
            # output_dir.  Same volume -> atomic + instant publish.
            consolidated_staged, consolidated_rows, _per_source_sums = (
                self._self_consolidate_chunks(
                    staging_dir, base_filename, ext, chunk_files, delimiter,
                    checksum_columns=plan.checksum_columns,
                )
            )
            if consolidated_rows != sum_actual:
                raise ValueError(
                    f"Job {report_id} per-source completeness FAILED: "
                    f"sum(chunk rows)={sum_actual:,} != consolidated rows="
                    f"{consolidated_rows:,} (delta {consolidated_rows - sum_actual:+,}). "
                    f"chunks merged into {consolidated_staged}"
                )
            # 2026-06-18 -- per-source VALUE-COLUMN CHECKSUM gate.
            # source_checksums was computed against (base_sql) AS t at
            # planning time; _self_consolidate_chunks just summed the
            # SAME columns from the consolidated file as we streamed.
            # If they diverge, rows were dropped or duplicated between
            # Trino's aggregate and the on-disk consolidated output.
            if plan.source_checksums and _per_source_sums:
                for _col, _src_v in plan.source_checksums.items():
                    _dst_v = _per_source_sums.get(_col)
                    if _dst_v is None:
                        continue  # column was skipped (missing / non-numeric)
                    if _src_v != _dst_v:
                        raise ValueError(
                            f"Job {report_id} per-source CHECKSUM "
                            f"FAILED on column {_col!r}: source SUM "
                            f"({_src_v}) != consolidated SUM ({_dst_v}) "
                            f"(delta {_dst_v - _src_v:+}).  Rows were "
                            f"lost or duplicated between Trino aggregate "
                            f"and on-disk consolidation."
                        )
                self.logger.info(
                    "Job %s per-source CHECKSUM OK on columns %s",
                    report_id, list(plan.source_checksums.keys()),
                )
            # Publish to mapped output_dir.
            consolidated_file = os.path.join(
                output_dir, os.path.basename(consolidated_staged),
            )
            # Back up / delete prior-run published file before overwrite
            # (mirrors what _self_consolidate_chunks does for the staged
            # path; the mapped path needs the same hygiene).
            try:
                from steps.file.run_state import backup_if_exists as _bif
                _bif(
                    consolidated_file,
                    backup_ts=getattr(self, "_backup_ts", None),
                    mode=getattr(self, "_prior_output_mode", "backup"),
                    logger=self.logger,
                )
            except ImportError:
                pass
            os.replace(consolidated_staged, consolidated_file)
            # 2026-06-18 -- defeat Windows file-name TUNNELING.  Even
            # with backup_if_exists + os.replace, NTFS silently
            # inherits the prior file's creation timestamp when the
            # same name is reused within ~15 seconds.  Explicit
            # SetFileTime override so the published file's ctime matches
            # TODAY's run.  No-op on POSIX.
            try:
                from steps.file.run_state import force_creation_time_now as _fct
                _fct(consolidated_file, logger=self.logger)
            except ImportError:
                pass
            self.logger.info(
                "Published per-source file to mapped output: %s "
                "(atomic rename from staging + ctime forced to now)",
                consolidated_file,
            )

            # 2026-06-18 -- PER-SOURCE COMPLETENESS CHECK at end of step.
            # User asked for "value check or checksum data completeness
            # check at the end of oncloud n onprem".  Three layers:
            #   (1) ROW-COUNT verification: re-read consolidated file and
            #       count data rows -- must match sum_actual.  G5-equivalent
            #       for the per-source file (the cross-source ConsolidateFiles
            #       step has its own G5; this is the per-source guarantee).
            #   (2) FILE-SIZE record so downstream consumers can verify
            #       transfer integrity.
            #   (3) MD5 + SHA256 CHECKSUMS for end-to-end byte integrity
            #       (CTL step will also include these in the manifest).
            # All best-effort -- a checksum failure logs WARN but doesn't
            # fail the step (the row-count check above is the hard guard).
            try:
                _per_source_bytes = os.path.getsize(consolidated_file)
                import hashlib as _hashlib
                _h_md5 = _hashlib.md5()
                _h_sha = _hashlib.sha256()
                # Stream in 4 MB blocks so we don't load 170M-row files
                # into memory.
                with open(consolidated_file, "rb") as _f:
                    for _block in iter(lambda: _f.read(4 * 1024 * 1024), b""):
                        _h_md5.update(_block)
                        _h_sha.update(_block)
                _per_source_md5 = _h_md5.hexdigest()
                _per_source_sha256 = _h_sha.hexdigest()
                self.logger.info(
                    "Per-source completeness: file=%s rows=%s bytes=%s "
                    "md5=%s sha256=%s",
                    os.path.basename(consolidated_file),
                    f"{consolidated_rows:,}",
                    f"{_per_source_bytes:,}",
                    _per_source_md5[:16] + "...",
                    _per_source_sha256[:16] + "...",
                )
            except Exception as _ck_exc:
                self.logger.warning(
                    "Per-source checksum compute failed (non-fatal -- "
                    "row-count G5 already verified): %s", _ck_exc,
                )
            # Register the consolidated file so cleanup-on-failure tracks it.
            if self.artifacts is not None:
                self.artifacts.add(consolidated_file, RunArtifacts.CONSOLIDATED)
        else:
            # No chunks were produced — legitimate 0-result scan (the
            # plan + reconcile already verified sum_actual==0==expected).
            # No per-source consolidated file; ConsolidateFiles will see
            # empty chunk_files for this job and the downstream cross-
            # source path handles that.
            consolidated_file = ""
            consolidated_rows = 0
            self.logger.info(
                "Job %s: no chunks to self-consolidate (0-row result) — "
                "skipping per-source merge", report_id,
            )

        return {
            "report_id": report_id,
            "datasource": self.DATASOURCE_NAME,
            "status": "success",
            "records": sum_actual,
            # Surface the MEASURED G1 (sum_actual when COUNT was deferred)
            # so downstream ConsolidateFiles' G5 still has a coherent
            # expected_total to reconcile against.
            "expected_total": measured_g1,
            "sum_partition_expected": plan.sum_partition_expected,
            "g1_source": plan.g1_source,
            "chunks": len(successful),
            "scan_mode": plan.mode.value,
            "partition_column": plan.partition_column,
            "chunk_files": chunk_files,
            # 2026-06-12 — single per-source file post self-consolidation.
            # ConsolidateFiles prefers this over chunk_files for the
            # cross-source merge.
            "consolidated_file": consolidated_file,
            "consolidated_rows": consolidated_rows,
            # 2026-06-18 -- per-source completeness signals (best-effort).
            "consolidated_file_bytes": _per_source_bytes,
            "consolidated_md5": _per_source_md5,
            "consolidated_sha256": _per_source_sha256,
            # 2026-06-18 -- VALUE-COLUMN CHECKSUM hand-off to ConsolidateFiles.
            # Cross-source step adds them across sources and compares
            # final consolidated file's per-column sums.
            "checksum_columns": list(plan.checksum_columns),
            "source_checksums": {k: str(v) for k, v in plan.source_checksums.items()},
            "per_source_checksums": {k: str(v) for k, v in _per_source_sums.items()},
            "output_dir": output_dir,
            "output_filename": f"{base_filename}.{ext}",
            "delimiter": delimiter,
            "control_template": job_config.get("ctl_file_format", ""),
            "zip_format": job_config.get("zip_format"),
        }

    def _self_consolidate_chunks(
        self, output_dir: str, base_filename: str, ext: str,
        chunk_files: List[str], delimiter: str,
        checksum_columns: Optional[List[str]] = None,
    ) -> Tuple[str, int, Dict[str, Any]]:
        """Merge per-source chunks into a single per-source file.

        Mirrors ConsolidateFiles._merge_chunks_for_job byte-for-byte
        on the I/O contract (write header once, skip subsequent
        headers, count data rows) so the cross-source step downstream
        sees a uniform "1 file per source" input regardless of how
        many chunks the source step produced.

        When ``checksum_columns`` is non-empty: also sums each named
        column from the CSV cells as we stream through.  Returned
        dict is ``{col_name: Decimal(sum)}``; empty when no columns
        requested.  These get verified against ``plan.source_checksums``
        at the caller, then surfaced to ConsolidateFiles for the
        cross-source check.

        Returns ``(consolidated_path, data_row_count, sums)``.
        """
        consolidated_path = os.path.join(output_dir, f"{base_filename}.{ext}")
        # Caller-side guard: empty list means _execute_one_job invoked
        # us when it shouldn't have (0-row scan should skip the call).
        if not chunk_files:
            raise ValueError(
                f"Self-consolidation: no non-empty chunk files for "
                f"{consolidated_path} (caller passed an empty list)"
            )
        # Reject missing/empty chunks HARD to match the contract
        # ConsolidateFiles enforces — silent skip masks upstream races.
        missing = [c for c in chunk_files if not os.path.exists(c)]
        if missing:
            raise ValueError(
                f"Self-consolidation: {len(missing)} chunk file(s) missing on disk: "
                f"{missing[:5]}{'...' if len(missing) > 5 else ''}.  "
                f"Refusing to consolidate a partial input set."
            )
        non_empty = [c for c in chunk_files if os.path.getsize(c) > 0]
        if not non_empty:
            raise ValueError(
                f"Self-consolidation: every chunk file is empty for "
                f"{consolidated_path}.  Upstream Starburst read produced "
                f"no header (writer never ran?)."
            )

        os.makedirs(output_dir, exist_ok=True)

        # 2026-06-13 -- back up (or delete) any prior-run per-source
        # consolidated file at this path before we overwrite it.
        # Skip when consolidated_path IS one of this run's chunk files
        # (single-chunk source's chunk path can equal the consolidated
        # path); the .merging tmp + os.replace handles that overlap.
        _cp_abs = os.path.abspath(consolidated_path)
        _chunk_abspaths = {os.path.abspath(c) for c in chunk_files}
        if _cp_abs not in _chunk_abspaths:
            try:
                from steps.file.run_state import backup_if_exists as _bif
                _bif(
                    consolidated_path,
                    backup_ts=getattr(self, "_backup_ts", None),
                    mode=getattr(self, "_prior_output_mode", "backup"),
                    logger=self.logger,
                )
            except ImportError:
                pass

        # Atomic write: .merging tmp + os.replace.  Mirrors the
        # merge_files fix so a chunk path equal to the target path
        # (no _CLOUD/_ONPREM suffix to differentiate) cannot truncate
        # its own source.
        tmp_path = consolidated_path + ".merging"
        if os.path.exists(tmp_path):
            self.logger.info(
                "Removing stale tmp %s before self-consolidate", tmp_path,
            )
            os.remove(tmp_path)

        rows_written = 0
        header_written = False
        self.logger.info(
            "Self-consolidating %d chunk file(s) -> %s",
            len(non_empty), consolidated_path,
        )
        # CompletenessProbe (2026-06-18) -- running sums per column.
        from decimal import Decimal, InvalidOperation
        _ck_cols = list(checksum_columns or [])
        _ck_sums: Dict[str, Any] = {c: Decimal(0) for c in _ck_cols}
        _ck_indices: Dict[str, int] = {}  # populated from header
        try:
            with open(tmp_path, "w", encoding="utf-8", newline="",
                       buffering=4 * 1024 * 1024) as out:
                for i, chunk_path in enumerate(non_empty, start=1):
                    chunk_rows = 0
                    with open(chunk_path, "r", encoding="utf-8", newline="") as src:
                        header = src.readline()
                        if not header:
                            # non_empty filter passed (size > 0) but no
                            # readable line — concurrent truncation.
                            raise ValueError(
                                f"Self-consolidation: chunk {chunk_path} "
                                f"reported non-empty but yielded no header "
                                f"— concurrent truncation?"
                            )
                        if not header_written:
                            out.write(header)
                            header_written = True
                            # Resolve checksum column indices once.
                            if _ck_cols:
                                header_cells = next(
                                    csv.reader(
                                        [header.rstrip("\r\n")],
                                        delimiter=delimiter,
                                    )
                                )
                                _by_name = {name: idx for idx, name in enumerate(header_cells)}
                                missing = [c for c in _ck_cols if c not in _by_name]
                                if missing:
                                    self.logger.warning(
                                        "Checksum columns %s not present in CSV header %s "
                                        "-- skipping checksum for those columns.",
                                        missing, header_cells,
                                    )
                                _ck_indices = {
                                    c: _by_name[c] for c in _ck_cols if c in _by_name
                                }
                                for c in list(_ck_sums.keys()):
                                    if c not in _ck_indices:
                                        _ck_sums.pop(c, None)
                        for line in src:
                            out.write(line)
                            rows_written += 1
                            chunk_rows += 1
                            # Accumulate sums.  Cheap per row; skip if no cols.
                            if _ck_indices:
                                try:
                                    row_cells = next(
                                        csv.reader(
                                            [line.rstrip("\r\n")],
                                            delimiter=delimiter,
                                        )
                                    )
                                except (csv.Error, StopIteration):
                                    continue
                                for col, idx in _ck_indices.items():
                                    if idx >= len(row_cells):
                                        continue
                                    cell = row_cells[idx].strip()
                                    if not cell:
                                        continue  # NULL / empty -> 0
                                    try:
                                        _ck_sums[col] += Decimal(cell)
                                    except (InvalidOperation, ValueError):
                                        # Non-numeric -- log once per col + skip.
                                        if _ck_sums[col] == Decimal(0):
                                            self.logger.warning(
                                                "Checksum column %r has non-numeric "
                                                "cell %r at row %d -- aborting "
                                                "checksum for this column.",
                                                col, cell, rows_written,
                                            )
                                        _ck_indices.pop(col, None)
                                        _ck_sums.pop(col, None)
                    self.logger.info(
                        "  per-source chunk %d/%d done: %s rows",
                        i, len(non_empty), f"{chunk_rows:,}",
                    )
                out.flush()
                try:
                    os.fsync(out.fileno())
                except OSError:
                    pass
            # Atomic publish.
            os.replace(tmp_path, consolidated_path)
        except Exception:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            raise
        if _ck_sums:
            self.logger.info(
                "Self-consolidate checksum sums: %s",
                ", ".join(f"SUM({c})={v}" for c, v in _ck_sums.items()),
            )
        self.logger.info(
            "Self-consolidation done: %s rows in %s",
            f"{rows_written:,}", consolidated_path,
        )
        return consolidated_path, rows_written, _ck_sums

    # ----- _execute_step  ------------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.ini_config = self._load_ini_config()
        self.query_config = self._load_query_config(task.get("sql_query_path"))
        self.run_report = self._get_run_report(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        # 2026-06-13 -- prior-output handling threaded from standalone
        # so _self_consolidate_chunks can back up an existing per-source
        # consolidated .dat before overwriting on a re-run.
        self._backup_ts = task.get("backup_ts") or None
        self._prior_output_mode = task.get("prior_output_mode") or "backup"

        jobs = self._filter_jobs()
        if not jobs:
            self.logger.warning("No %s jobs in query config", self.DATASOURCE_NAME)
            return []

        self.logger.info(
            "%s: %d job(s) to process (datasource=%s, force_mode=%s)",
            self.LOG_PREFIX, len(jobs), self.DATASOURCE_NAME,
            self.FORCE_MODE.value if self.FORCE_MODE else "none",
        )

        results: List[Dict[str, Any]] = []
        # 2026-06-18 -- staging dirs created per job.  Track them so
        # try/finally below can rmtree them on success AND failure
        # (unless preserve_chunks_on_failure -- partial-recovery flag).
        staging_dirs: List[str] = []
        # 2026-06-18 -- distinguish OPERATOR-INITIATED CANCEL (Ctrl+C /
        # SIGINT / SIGTERM / asyncio.CancelledError) from real failure.
        # Cancel = "I want to abort cleanly, not preserve scraps."  Real
        # failure (network drop, Trino error, mismatch) = "preserve so
        # operator can investigate".  Honoring preserve_chunks_on_failure
        # on Ctrl+C would leave staging files everywhere after every
        # test-loop interruption -- exactly the symptom user reported.
        user_cancelled = False
        # Honor PRESERVE_CHUNKS_ON_FAILURE from polling row.  Accept the
        # usual string-bool spellings (TRUE/Y/1/...) -- Oracle drivers
        # return strings even for boolean-shaped columns.
        _preserve_raw = task.get("preserve_chunks_on_failure")
        if isinstance(_preserve_raw, bool):
            preserve_on_failure = _preserve_raw
        else:
            preserve_on_failure = str(_preserve_raw or "").strip().upper() in {
                "TRUE", "Y", "YES", "1", "T",
            }
        step_failed = False
        try:
            for job in jobs:
                result = await self._execute_one_job(job, task, step_name)
                results.append(result)
                # Capture per-job staging dir (set by _execute_one_job
                # via task["_staging_dir"]).  Reset between jobs in case
                # a later job overwrites it.
                _sd = task.pop("_staging_dir", None)
                if _sd:
                    staging_dirs.append(_sd)
                self.run_report.add_job_result({
                    "report_id": result.get("report_id"),
                    "datasource": result.get("datasource"),
                    "status": result.get("status"),
                    "records": result.get("records", 0),
                    "chunks": result.get("chunks", 0),
                    "file_path": os.path.join(
                        result.get("output_dir", ""),
                        result.get("output_filename", ""),
                    ),
                    # 2026-06-18 -- per-source completeness signals so the
                    # report.html shows the same byte-level guarantee that
                    # the CTL step will use for its manifest.
                    "consolidated_file_bytes": result.get("consolidated_file_bytes", 0),
                    "consolidated_md5": result.get("consolidated_md5", ""),
                    "consolidated_sha256": result.get("consolidated_sha256", ""),
                })
        except (KeyboardInterrupt, asyncio.CancelledError, SystemExit) as cancel_exc:
            # 2026-06-18 -- USER-INITIATED CANCEL.  Ctrl+C (SIGINT) /
            # SIGTERM / asyncio.CancelledError / sys.exit() all land
            # here.  These are NOT data-loss scenarios -- operator is
            # asking to abort cleanly.  ALWAYS clean staging, override
            # preserve_chunks_on_failure (which exists for data-failure
            # recovery, not for cancel-leftovers).  Without this branch,
            # a Ctrl+C in a test loop leaves staging dirs everywhere.
            user_cancelled = True
            self.logger.warning(
                "%s -- staging dir cleanup will run, preserve_chunks_on_failure "
                "is ignored on cancel.",
                type(cancel_exc).__name__,
            )
            _sd = task.pop("_staging_dir", None)
            if _sd:
                staging_dirs.append(_sd)
            raise
        except Exception:
            step_failed = True
            # Still capture any staging dir created by the failing job.
            _sd = task.pop("_staging_dir", None)
            if _sd:
                staging_dirs.append(_sd)
            raise
        finally:
            # 2026-06-18 -- USER REPORT: "why expected count is not in
            # report.html file".  Root cause: set_counts() was called
            # AFTER this finally block, so the report rendered in the
            # finally never had expected_total populated.  Fix: compute
            # the aggregates from whatever results we DO have at this
            # point (partial on cancel/failure; complete on success) and
            # call set_counts BEFORE write().  Defensive try/except so
            # the aggregate compute never blocks staging cleanup.
            try:
                _partial_results = results or []
                if _partial_results:
                    _exp = sum(
                        r.get("expected_total") or 0 for r in _partial_results
                    )
                    _g2_per = [r.get("sum_partition_expected") for r in _partial_results]
                    _g2_total = (
                        sum(_g2_per) if all(p is not None for p in _g2_per) else None
                    )
                    _act = sum(r.get("records", 0) for r in _partial_results)
                    _g1_src = next(
                        (r.get("g1_source") for r in _partial_results if r.get("g1_source")),
                        "",
                    )
                    self.run_report.set_counts(
                        expected_total=_exp if _exp > 0 else None,
                        sum_partition_expected=_g2_total,
                        sum_chunk_actual=_act,
                        g1_source=_g1_src,
                    )
            except Exception:
                pass
            # Always write the run report — success or fail.
            try:
                self.run_report.write()
            except Exception:
                # Don't let report-write failure mask the original error
                # OR prevent staging cleanup below.
                pass
            # Staging dir cleanup -- success OR cancel OR failure.
            # PRESERVE only when (a) it was a real failure, NOT a cancel,
            # AND (b) preserve_chunks_on_failure is set.  Cancel ALWAYS
            # cleans (operator chose to abort; scraps are unwanted).
            _should_preserve = (
                step_failed
                and not user_cancelled
                and preserve_on_failure
            )
            for sd in staging_dirs:
                if _should_preserve:
                    self.logger.info(
                        "Preserving staging dir %s "
                        "(preserve_chunks_on_failure=TRUE + step failed + NOT cancelled)",
                        sd,
                    )
                    continue
                try:
                    if os.path.isdir(sd):
                        import shutil
                        shutil.rmtree(sd, ignore_errors=True)
                        if user_cancelled:
                            _reason = "CANCELLED by operator"
                        elif step_failed:
                            _reason = "FAILED"
                        else:
                            _reason = "SUCCESS"
                        self.logger.info(
                            "Removed staging dir %s (step %s)", sd, _reason,
                        )
                except Exception as exc:
                    self.logger.warning(
                        "Failed to remove staging dir %s: %s "
                        "(non-fatal; next run's startup orphan scan will clean it)",
                        sd, exc,
                    )

        # Aggregate G1 / G2 / G3 across jobs (file flow usually has 1 job
        # per source; this is defensive when 2+ reports share a step).
        total_expected = sum(r["expected_total"] for r in results)
        # 2026-06-17 -- G2 propagation rule: per-partition counts are
        # only available when discovery_mode=group_by SUCCEEDS.  SINGLE
        # mode + distinct discovery + fall-back-to-distinct all leave
        # sum_partition_expected=None on the result dict.  If ANY job
        # is None, the aggregate MUST be None so the run-report G2
        # chip is SKIPPED -- a mixed sum is meaningless and used to
        # render permanent FAIL.
        _g2_per_job = [r.get("sum_partition_expected") for r in results]
        total_partition_expected = (
            sum(_g2_per_job) if all(p is not None for p in _g2_per_job) else None
        )
        total_actual = sum(r["records"] for r in results)
        # 2026-06-13 -- thread G1 source string from any result that has
        # one (all results in a step share the same plan and source).
        _g1_src = next(
            (r["g1_source"] for r in results if r.get("g1_source")),
            "",
        )
        self.run_report.set_counts(
            expected_total=total_expected,
            sum_partition_expected=total_partition_expected,
            sum_chunk_actual=total_actual,
            g1_source=_g1_src,
        )

        # Persist task state for downstream steps.
        all_chunk_files: List[str] = []
        for r in results:
            all_chunk_files.extend(r.get("chunk_files", []))

        # 2026-06-12 — MERGE with any prior step's sidecar state so a
        # CLOUD-then-ONPREM (or ONPREM-then-CLOUD) sequence accumulates
        # BOTH sources' chunk_files + job_results + counts.  Without
        # this, the second step's save_task_state would OVERWRITE the
        # sidecar with only its own datasource's results and
        # ConsolidateFiles downstream would see only one source --
        # CLOUD+ONPREM never merge.  Hydrate first (using the same
        # per-run sidecar_dir the standalone injected, decoupled from
        # per-row output_dir), then extend with this step's results.
        _existing_state = None
        try:
            from steps.file.run_state import load_state as _ls
            _existing_state = _ls(
                task.get("sidecar_dir") or task.get("output_dir") or "",
                task.get("run_id"),
                logger=self.logger,
            ) or {}
        except Exception:
            _existing_state = {}

        prior_chunks = list(_existing_state.get("chunk_files") or [])
        prior_jobs = list(_existing_state.get("job_results") or [])

        # Dedup by report_id+datasource so re-runs of the same step
        # don't duplicate -- this step's results REPLACE any prior
        # entry for the same (report_id, datasource), other sources stay.
        _this_keys = {(r.get("report_id"), r.get("datasource")) for r in results}
        prior_jobs = [
            j for j in prior_jobs
            if (j.get("report_id"), j.get("datasource")) not in _this_keys
        ]
        # Same dedup for chunks: drop any prior chunk path that this
        # step is re-producing (rare in normal flow; defensive for reruns).
        _this_chunks_set = set(all_chunk_files)
        prior_chunks = [p for p in prior_chunks if p not in _this_chunks_set]

        merged_chunks = prior_chunks + all_chunk_files
        merged_jobs = prior_jobs + results

        # Aggregate G1/G2/G3 ACROSS all sources, not just this step's.
        merged_expected = total_expected + sum(
            int(j.get("expected_total") or 0) for j in prior_jobs
        )
        # 2026-06-17 -- G2 cross-source merge: if EITHER side is None
        # (this step OR any prior job), the merged G2 is None too --
        # otherwise the chip renders a meaningless partial sum.
        _prior_g2 = [j.get("sum_partition_expected") for j in prior_jobs]
        if total_partition_expected is None or any(p is None for p in _prior_g2):
            merged_partition_expected = None
        else:
            merged_partition_expected = total_partition_expected + sum(
                int(p or 0) for p in _prior_g2
            )
        merged_actual = total_actual + sum(
            int(j.get("records") or 0) for j in prior_jobs
        )

        task["chunk_files"] = merged_chunks
        task["job_results"] = merged_jobs
        task["expected_total"] = merged_expected
        task["sum_partition_expected"] = merged_partition_expected
        task["sum_chunk_actual"] = merged_actual
        task["totalcount"] = merged_actual  # BaseStep reads this for status update
        task["artifact_paths"] = self.artifacts.snapshot()

        # 2026-06-12 — re-publish counts to run_report using MERGED
        # cross-source totals (the earlier set_counts above only had
        # this step's local results).  Without this re-publish, the
        # HTML run report shows only the LAST source's totals during
        # a run -- if the run fails before the standalone's final
        # set_counts, the report is forensically wrong (operator sees
        # 2878 ONPREM rows expected when 3878 CLOUD+ONPREM were).
        if prior_jobs:  # only when actually merging across sources
            self.run_report.set_counts(
                expected_total=merged_expected,
                sum_partition_expected=merged_partition_expected,
                sum_chunk_actual=merged_actual,
                g1_source=_g1_src,
            )

        # Sidecar persistence — prefer the canonical task["output_dir"]
        # (injected by the standalone, equal to the run report's
        # output_dir) so the downstream ConsolidateFiles step finds
        # the sidecar where it looks for it (it hydrates from
        # task.get("output_dir")).  Fall back to the first job's
        # per-job output_dir for back-compat with callers that don't
        # set task["output_dir"].
        sidecar_dir = task.get("output_dir") or (
            results[0].get("output_dir", "") if results else ""
        )
        if sidecar_dir:
            save_task_state(task, sidecar_dir, task.get("run_id"), logger=self.logger)

        # Push record count to Oracle metadata.
        try:
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"),
                task.get("run_detail_id"),
                "UPDATE_TASK_RECORDCOUNT",
                step_name,
                total_actual,
                "",
                worker_connection_string,
            )
        except Exception as exc:
            self.logger.warning("update_otg_etl_batch_status failed: %s", exc)

        return results


def _strip_trailing_semicolon(sql: str) -> str:
    return sql.rstrip().rstrip(";").rstrip()


def _is_pid_alive(pid: int) -> bool:
    """Cross-platform "is this process still running?" check.

    Used by the staging-dir orphan-cleanup scan to decide whether a
    stale ``.staging_*_p<PID>`` dir's owner is still alive or crashed.
    Conservative on errors: when we can't tell (PermissionError on
    POSIX, ambiguous WinError), assume ALIVE so we don't accidentally
    rmtree a dir that's actively being written.
    """
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # POSIX: process exists but not ours -- conservatively alive.
        return True
    except OSError as exc:
        # Windows: ERROR_INVALID_PARAMETER (87) when pid doesn't exist;
        # other errnos = exists.  Fall back conservatively.
        if getattr(exc, "winerror", None) == 87:
            return False
        return True


# ──────────────────────────────────────────────────────────────────────
#  SQL rewriter -- AST-level partition predicate injection (2026-06-17)
# ──────────────────────────────────────────────────────────────────────
#
# User feedback 2026-06-17: "starburst going to execute same query 100
# times".  The legacy approach wrapped the operator's base_sql in a
# subquery for every metadata + chunk operation:
#
#     SELECT ... FROM ( <full base_sql> ) AS pv WHERE pv.col = 'X'
#
# Trino's predicate pushdown is best-effort through subquery wraps -- it
# DOESN'T always push the outer WHERE through complex inner shapes
# (JOIN + GROUP BY + projection).  Result: the full source-side work
# (JOIN, GROUP BY, scan) repeats per chunk.  On 170M-row sources with
# 100 partitions, that's 100x the work.
#
# The AST rewriter (uses sqlglot, already a QS-wide dependency from
# Phase 133-G's filter pushdown work) AST-modifies base_sql IN PLACE:
#
#   * inject_where_into_base_sql(base, col, value)
#       AST-add `col = value` to the top-level WHERE.  Trino sees the
#       predicate ON the source SELECT, not on an outer wrap, and can
#       push down natively to the source table (e.g. partition prune
#       on Iceberg).
#
#   * derive_distinct_partition_sql(base, col)
#       Strip projection + GROUP BY + ORDER BY from base, replace with
#       `SELECT DISTINCT col`.  FROM/JOIN/WHERE preserved.  Cheap probe
#       for partition value enumeration.
#
#   * derive_count_sql(base)
#       Strip projection + GROUP BY + ORDER BY + LIMIT + DISTINCT, set
#       projection to `COUNT(*)`.  Pre-flight COUNT without subquery wrap.
#
#   * derive_group_by_count_sql(base, col)
#       Strip projection + GROUP BY + ORDER BY + LIMIT + DISTINCT, set
#       projection to `col AS pv, COUNT(*) AS cnt`, add `GROUP BY col
#       ORDER BY col`.  Partition discovery without subquery wrap.
#
# All four have a `wrap` fallback: if sqlglot parse fails (exotic SQL,
# operator-specific syntax we don't recognise), we log a WARN and return
# the legacy wrapped SQL.  No operator-facing toggle: the auto-fallback
# handles parse failures, G3 reconcile (sum(chunk rows) == G1) catches
# any semantic drift, and the pre-flight AST-safety scan WARNs name the
# risky shapes (window functions etc.) before the run starts.
#
# QUALIFIED COLUMN NAMES (2026-06-17 follow-up): operators routinely pass
# the partition column as ``TABLE.COL`` so it's unambiguous in JOINs
# (e.g. ``FACT_TABLE.SAP_COMPANY_ID``).  ``exp.to_identifier`` does NOT
# split on dots -- it treats the whole string as one identifier.  Result:
# AST emits ``"FACT_TABLE.SAP_COMPANY_ID"`` (one column literally named
# with a dot) and Trino can't resolve it.  ``_build_column_expr`` is the
# single bottleneck that splits qualified names into ``(table, column)``
# parts and builds a real two-part Column node.  Every AST site that
# materialises the partition column as a sqlglot expression MUST route
# through it.  Wrap fallbacks strip the table qualifier instead because
# the wrap loses the source FROM scope -- ``pv.FACT_TABLE.col`` would be
# a 3-part name Trino rejects.


def _parse_qualified_column(s: str) -> Tuple[Optional[str], str]:
    """Split ``TABLE.COL`` (or quoted variants) into ``(table_or_None, column)``.

    Strips ``"`` and `` ` `` quotes from each part.  Bare ``COL`` returns
    ``(None, "COL")``.  Anything with more than one dot is split on the
    LAST dot (schema.table.col -> ("schema.table", "col")) since the
    common QS shape is single-qualifier and ``rsplit`` keeps that safe.

    Single source of truth for every AST helper -- if this lies, every
    AST site is broken in the same way.
    """
    s = (s or "").strip()
    if not s:
        return None, ""
    # Quick strip of outer quotes for the whole string (rare but harmless).
    if "." in s:
        tbl, col = s.rsplit(".", 1)
        tbl = tbl.strip().strip('"').strip("`")
        col = col.strip().strip('"').strip("`")
        return (tbl or None), col
    return None, s.strip().strip('"').strip("`")


def _bare_column_name(s: str) -> str:
    """Return just the column part of ``TABLE.COL`` -- used by name-only
    comparisons (projection-has, alias-of-computed, ambiguity check) and
    by wrap fallbacks that lose the source-FROM scope."""
    _, col = _parse_qualified_column(s)
    return col


def _literal_for(value):
    """Build a sqlglot literal node for a Python value.

    Strings are escaped via ``Literal.string`` (sqlglot doubles embedded
    single quotes).  None is NOT handled here -- the caller hoists NULL
    out into ``col IS NULL`` since IN-lists can't contain NULL.
    """
    from sqlglot import expressions as exp
    if isinstance(value, bool):
        return exp.Boolean(this=value)
    if isinstance(value, (int, float)):
        return exp.Literal.number(value)
    return exp.Literal.string(str(value))


def _build_predicate(col_expr, value):
    """Build a WHERE predicate node for a single value or a bucket.

    Single value:
      None        -> ``col IS NULL``
      anything    -> ``col = literal``

    Bucket (list/tuple/set/frozenset):
      empty       -> ``1 = 0`` (false; defensive -- shouldn't happen)
      one value   -> degrades to single-value form for readable SQL
      all NULLs   -> ``col IS NULL``
      mixed       -> ``col IN (non-null literals) OR col IS NULL``
      no NULLs    -> ``col IN (literals)``

    The IN-clause path is what lets a bucket of 11 partition values run
    as ONE Trino query (instead of 11 separate per-value queries).  Sum
    of bucket-actuals still equals G1, so G3/G5 reconcile is unchanged.
    """
    from sqlglot import expressions as exp

    if not isinstance(value, (list, tuple, set, frozenset)):
        if value is None:
            return exp.Is(this=col_expr.copy(), expression=exp.Null())
        return exp.EQ(this=col_expr.copy(), expression=_literal_for(value))

    members = list(value)
    if not members:
        return exp.EQ(this=exp.Literal.number(1), expression=exp.Literal.number(0))
    has_null = any(v is None for v in members)
    non_nulls = [v for v in members if v is not None]
    if len(members) == 1:
        return _build_predicate(col_expr, members[0])
    if not non_nulls:
        return exp.Is(this=col_expr.copy(), expression=exp.Null())
    in_expr = exp.In(
        this=col_expr.copy(),
        expressions=[_literal_for(v) for v in non_nulls],
    )
    if not has_null:
        return in_expr
    return exp.Or(
        this=in_expr,
        expression=exp.Is(this=col_expr.copy(), expression=exp.Null()),
    )


def _row_count_affecting_shape(tree) -> Optional[str]:
    """Return the name of a top-level row-count-affecting clause if
    base_sql has one (DISTINCT / outer GROUP BY / HAVING / QUALIFY /
    LIMIT).  Returns None when base_sql is a 'plain SELECT projection
    FROM ... WHERE ...' shape that AST stripping is safe for.

    2026-06-18 -- bucketing-induced false-mismatch root cause.  When
    base_sql has any of these clauses, my AST rewrite for discovery
    (_derive_group_by_count_sql / _derive_count_sql) strips them, then
    emits ``SELECT col, COUNT(*) ... GROUP BY col``.  But the CHUNK
    query preserves them via _inject_where_into_base_sql.  Result:
    discovery counts MORE rows than the chunk's preserved query
    produces -- per-chunk completeness check fires with a small
    consistent positive delta (discovery_sum - chunk_actual > 0).

    Fix: when this returns non-None, the discovery helpers must
    auto-fallback to WRAP mode.  Wrap counts whatever rows the
    ORIGINAL query produces (inner materialisation), so it matches
    the chunk exactly.  Slower but mathematically correct.

    User-confirmed at source 2026-06-18: 49,959 actual vs 49,973
    discovery-expected (delta -14) on a frozen iceberg snapshot ->
    discovery overcount, NOT data drift.  This helper closes that.
    """
    try:
        from sqlglot import expressions as exp
    except ImportError:
        return None
    if not isinstance(tree, exp.Select):
        return None
    if tree.args.get("distinct"):
        return "DISTINCT"
    if tree.args.get("group"):
        return "outer GROUP BY"
    if tree.args.get("having"):
        return "HAVING"
    if tree.args.get("qualify"):
        return "QUALIFY"
    if tree.args.get("limit"):
        return "LIMIT"
    return None


def _collect_from_qualifiers(tree) -> set:
    """Return the set of valid table qualifiers (lowercased) in scope at
    the outermost SELECT: each table's alias if aliased, the table name
    if not.

    Used to detect when the operator's ``partition_column = TABLE.COL``
    references a table that's been *aliased* in base_sql (``FROM TABLE
    AS T``).  Trino does NOT keep the original table name in scope when
    aliased -- ``WHERE TABLE.col`` raises 'Column not resolved'.  AST
    helpers that reference the partition column must auto-fallback to
    wrap mode when the qualifier doesn't match anything in scope.
    """
    try:
        from sqlglot import expressions as exp
    except ImportError:
        return set()
    qualifiers: set = set()
    if not isinstance(tree, exp.Select):
        # UNION / Intersect / Except -- union the branches' qualifiers
        for s in tree.find_all(exp.Select):
            qualifiers |= _collect_from_qualifiers(s)
        return qualifiers

    def _add_source(src) -> None:
        # ``Table.alias`` returns the alias string ("" when not aliased).
        # ``Table.alias_or_name`` returns the alias when aliased, else
        # the table name -- exactly the handle Trino expects in scope.
        # For Subquery in FROM, ``alias`` is the only valid handle.
        if isinstance(src, exp.Table):
            handle = (src.alias or src.name or "").strip().lower()
            if handle:
                qualifiers.add(handle)
            # When NOT aliased, the table name is the handle (handled
            # above by alias_or_name fallback).  When ALIASED, the
            # original table name is NOT in scope per Trino -- intentional.
        elif isinstance(src, exp.Subquery):
            alias = (src.alias or "").strip().lower()
            if alias:
                qualifiers.add(alias)

    # Outermost FROM source(s) + JOINs only.  Subqueries in FROM expose
    # their own alias to the outer scope; CTE bodies don't (their alias
    # is exposed at the WITH level which the outer Select consults via
    # the args["with"] node -- handled below).
    from_clause = tree.args.get("from_") or tree.args.get("from")
    if from_clause is not None:
        # From.this is the (single) source -- Table or Subquery
        _add_source(from_clause.this)
        # Older sqlglot variants nested multiple in expressions; be safe.
        for src in (from_clause.args.get("expressions") or []):
            _add_source(src)
    for join in tree.args.get("joins") or []:
        _add_source(join.this)

    # CTE names are valid qualifiers for references in the outer SELECT.
    with_node = tree.args.get("with")
    if with_node is not None:
        for cte in (with_node.args.get("expressions") or []):
            alias_node = cte.args.get("alias")
            if alias_node and getattr(alias_node, "name", None):
                qualifiers.add(alias_node.name.lower())

    return qualifiers


def _qualifier_in_scope(tree, qualified_column: str) -> bool:
    """True if ``qualified_column``'s table qualifier matches a valid
    handle in tree's outermost FROM scope.

    Returns True when:
      * The column is unqualified (no table prefix), OR
      * The qualifier (case-insensitive) matches a table alias or
        un-aliased table name in scope.

    Returns False when the qualifier names a table that's been aliased
    OR doesn't exist at all -- both produce 'Column not resolved' from
    Trino on AST emit.
    """
    tbl, _ = _parse_qualified_column(qualified_column)
    if not tbl:
        return True
    # Multi-part qualifier (schema.table.col) -- check the *table* level
    # (the LAST segment of the qualifier), not the schema.
    table_handle = tbl.rsplit(".", 1)[-1].strip().strip('"').strip("`").lower()
    return table_handle in _collect_from_qualifiers(tree)


def _build_column_expr(qualified: str):
    """Build a sqlglot ``Column`` expression that correctly emits
    ``CATALOG.SCHEMA.TABLE.COL`` (4-part), ``SCHEMA.TABLE.COL`` (3-part),
    ``TABLE.COL`` (2-part), or ``COL`` (1-part).  Replaces every inline
    ``exp.Column(this=exp.to_identifier(column))`` that broke on
    qualified names.

    Delegates to ``sqlglot.exp.to_column`` which handles N-part
    identifiers (this / table / db / catalog slots) natively.  Falls
    back to the rsplit pair for the rare case where to_column refuses
    the input -- preserves backward compat for the common 2-part shape.
    """
    from sqlglot import expressions as exp
    qualified = (qualified or "").strip()
    if not qualified:
        return exp.Column(this=exp.to_identifier(""))
    try:
        return exp.to_column(qualified)
    except Exception:
        tbl, col = _parse_qualified_column(qualified)
        if tbl:
            return exp.Column(
                this=exp.to_identifier(col),
                table=exp.to_identifier(tbl),
            )
        return exp.Column(this=exp.to_identifier(col))


def _inject_where_into_base_sql(
    base_sql: str,
    column: str,
    value: Any,
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """AST-inject ``column = value`` into the top-level WHERE of base_sql.

    Returns ``(rewritten_sql, mode)`` where mode is ``"ast"`` (rewrite
    succeeded) or ``"wrap"`` (parse failed; fell back to legacy wrap).

    Handles common SQL shapes that QS jobs actually use:

      * Top-level SELECT       -- WHERE injected directly
      * SELECT with CTE / WITH -- WHERE injected on the top SELECT
      * UNION / UNION ALL      -- WHERE injected on EACH branch
      * Subselects in FROM     -- WHERE injected at the outermost SELECT
                                  (sufficient -- Trino handles inner pushdown)

    NULL values become ``column IS NULL``.  String values are escaped
    with sqlglot's literal builder (safer than f-string concat).

    Fallback path returns the legacy wrap form so the run continues even
    when AST rewrite isn't possible.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return _wrap_with_where(base_sql, column, value), "wrap"

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.warning(
                "AST parse failed for partition rewrite (falling back to subquery wrap): %s",
                exc,
            )
        return _wrap_with_where(base_sql, column, value), "wrap"

    # 2026-06-17 -- "query extraction should never fail".  If the
    # partition column is an alias of a computed expression (e.g.
    # `a||b AS col`), Trino CANNOT filter on it in WHERE -- AST
    # inject would produce a runtime "Column not resolved" error.
    # Auto-fallback to wrap (where the outer SELECT references the
    # inner-projected alias, which Trino DOES support).
    if _is_alias_of_computed_expr(tree, column):
        if logger:
            logger.info(
                "AST inject: partition column '%s' is an alias of a computed "
                "expression -- using wrap fallback (Trino can't filter on "
                "aliases in WHERE).  G3 reconcile still applies.",
                column,
            )
        return _wrap_with_where(base_sql, column, value), "wrap"

    # 2026-06-17 -- "alias mismatch" guard.  If the operator pre-qualified
    # the partition column with the FULL table name (``FACT_TABLE.col``)
    # but base_sql aliased that table (``FROM FACT_TABLE FT``), Trino
    # only keeps FT in scope -- AST WHERE ``FACT_TABLE.col`` raises
    # 'Column not resolved'.  Wrap fallback uses bare column name and
    # the inner alias ``pv`` exposes the projection cleanly, so it
    # works.  This is auto-recovery, not a failure path.
    if not _qualifier_in_scope(tree, column):
        if logger:
            logger.info(
                "AST inject: partition column qualifier in '%s' is NOT in "
                "the FROM scope (valid handles: %s) -- using wrap fallback "
                "(operator pre-qualified with a table name that base_sql "
                "has aliased; wrap drops the qualifier and references the "
                "inner projection alias).",
                column, sorted(_collect_from_qualifiers(tree)),
            )
        return _wrap_with_where(base_sql, column, value), "wrap"

    # Build the predicate as a sqlglot expression.
    # 2026-06-17 fix: _build_column_expr correctly splits ``TABLE.COL``
    # into a two-part Column node.  Prior code's
    # ``exp.to_identifier(column)`` emitted ``"TABLE.COL"`` as one
    # identifier and Trino raised "Column not resolved".
    #
    # 2026-06-17 bucketing: ``value`` can be a list/tuple of partition
    # values (bucket of N values into one chunk -- reduces 1139 Trino
    # round-trips to ~100 for high-cardinality partition columns).
    # NULL-aware: NULL members become ``col IS NULL`` joined by OR.
    _col_expr = _build_column_expr(column)
    predicate = _build_predicate(_col_expr, value)

    # 2026-06-17 -- inject ONLY into the OUTERMOST SELECT (and UNION
    # branches' outermost SELECTs).  Pre-fix this used tree.transform
    # which recurses into EVERY Select node, including correlated
    # subqueries in WHERE clauses where the partition column doesn't
    # exist -- produced "Column not resolved" errors at runtime, or
    # worse, silently filtered subquery results.
    #
    # Subqueries in FROM (derived tables) and CTE bodies are also
    # excluded: the predicate belongs on the FINAL result, not on
    # intermediate computations.  Trino's optimizer pushes the outer
    # predicate down through derived tables / CTEs natively.
    def _inject_outermost(node):
        if isinstance(node, exp.Select):
            node.where(predicate.copy(), append=True, dialect=dialect, copy=False)
        elif isinstance(node, (exp.Union, exp.Intersect, exp.Except)):
            # Set-op at the top -- inject into each branch's outermost.
            if node.this is not None:
                _inject_outermost(node.this)
            if node.expression is not None:
                _inject_outermost(node.expression)
        # All other root types (raw expressions etc.) -> wrap fallback.

    try:
        _inject_outermost(tree)
        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.warning(
                "AST inject failed (falling back to subquery wrap): %s", exc,
            )
        return _wrap_with_where(base_sql, column, value), "wrap"


def _derive_distinct_partition_sql(
    base_sql: str,
    column: str,
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """Derive a cheap discovery SQL: ``SELECT DISTINCT column`` over the
    same FROM/JOIN/WHERE as base_sql, with projection + GROUP BY +
    ORDER BY stripped.

    Returns ``(discovery_sql, mode)`` -- mode is ``"ast"`` or ``"wrap"``.

    For a base_sql like::

        SELECT a.x, b.y, b.col FROM A JOIN B ON ... WHERE ... GROUP BY ...

    returns::

        SELECT DISTINCT col FROM A JOIN B ON ... WHERE ...

    Massively cheaper than ``SELECT DISTINCT col FROM (full base_sql)``
    -- Trino doesn't have to materialise the inner result first.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return _wrap_distinct(base_sql, column), "wrap"

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.warning(
                "AST parse failed for partition discovery (falling back to wrap): %s",
                exc,
            )
        return _wrap_distinct(base_sql, column), "wrap"

    if not isinstance(tree, exp.Select):
        # UNION / CTE-at-top etc. -- safer to wrap.
        return _wrap_distinct(base_sql, column), "wrap"

    # 2026-06-17 -- same alias gotcha as inject: if the partition column
    # is an alias of a computed expression, `SELECT DISTINCT col` on the
    # source FROM/JOIN/WHERE would refer to a column that doesn't exist
    # at the source level.  Wrap fallback is safe (it SELECTs DISTINCT
    # from the inner-projected alias).
    if _is_alias_of_computed_expr(tree, column):
        if logger:
            logger.info(
                "AST derive_distinct: partition column '%s' is an alias of a "
                "computed expression -- using wrap fallback for discovery",
                column,
            )
        return _wrap_distinct(base_sql, column), "wrap"

    # 2026-06-17 -- alias mismatch guard (see _inject_where comment).
    if not _qualifier_in_scope(tree, column):
        if logger:
            logger.info(
                "AST derive_distinct: partition column qualifier in '%s' is "
                "NOT in the FROM scope (valid handles: %s) -- using wrap "
                "fallback (qualifier dropped, inner projection alias used).",
                column, sorted(_collect_from_qualifiers(tree)),
            )
        return _wrap_distinct(base_sql, column), "wrap"

    try:
        # Strip GROUP BY, ORDER BY, LIMIT, HAVING -- they distort distinct.
        # WITH (CTE) at the top STAYS; FROM/JOIN/WHERE stay.
        for k in ("group", "order", "limit", "offset", "having", "qualify"):
            tree.args.pop(k, None)
        # Replace projection with the single column.  2026-06-17 fix:
        # _build_column_expr splits ``TABLE.COL`` properly so the emitted
        # SELECT references the qualified column as Trino expects.
        tree.set("expressions", [_build_column_expr(column)])
        tree.set("distinct", exp.Distinct())
        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.warning(
                "AST derive_distinct failed (falling back to wrap): %s", exc,
            )
        return _wrap_distinct(base_sql, column), "wrap"


def _derive_count_sql(
    base_sql: str,
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """Derive a cheap ``SELECT COUNT(*)`` over the same FROM/JOIN/WHERE
    as base_sql, with projection + GROUP BY + ORDER BY + LIMIT + DISTINCT
    stripped.  Returns ``(count_sql, mode)`` -- mode is ``"ast"`` or
    ``"wrap"``.

    2026-06-17 -- pre-flight COUNT(*) was wrapping the entire base_sql
    in ``SELECT COUNT(*) FROM (base) AS q``.  Trino dutifully materialised
    the full result set first (including the operator's SELECT list,
    JOINs, GROUP BY) then counted -- doubling the source-side work versus
    a plain ``SELECT COUNT(*) FROM source WHERE ...``.  AST mode strips
    everything that doesn't affect the row count and emits the cheap
    shape; Trino's pushdown then prunes the source scan natively.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return _wrap_count(base_sql), "wrap"

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.warning(
                "AST parse failed for pre-flight COUNT (falling back to wrap): %s",
                exc,
            )
        return _wrap_count(base_sql), "wrap"

    # UNION / CTE-at-top: COUNT(*) of the wrap is the same as sum of
    # branch COUNTs, but rewriting the union to a single COUNT is
    # invasive.  Wrap fallback is safe and produces the same number.
    if not isinstance(tree, exp.Select):
        return _wrap_count(base_sql), "wrap"

    # 2026-06-18 -- STRATEGIC CORRECTION (user reported OOM concern).
    # Prior policy: when base_sql had DISTINCT / outer GROUP BY /
    # HAVING / QUALIFY / LIMIT, wrap the WHOLE base_sql with COUNT(*).
    # On a 170M-row table with DISTINCT JOIN, that forces Trino to
    # materialise the entire DISTINCT JOIN result THEN COUNT -> OOM.
    # AND it doesn't help operator anyway -- we can't use the count for
    # auto-skip because the chunk semantics differ from the count.
    #
    # New policy: when shape detected, RETURN ("", "skip").  Caller
    # (_fetch_count) treats this as "no pre-flight COUNT possible".
    # G1 is then measured from the extract (sum of chunk actuals);
    # G3 anchors against itself (always passes).  Operator must set
    # FAIL_ON_MISMATCH=FALSE for safe operation on these shapes.
    shape = _row_count_affecting_shape(tree)
    if shape:
        if logger:
            logger.info(
                "AST derive_count: base_sql has top-level %s -- "
                "skipping pre-flight COUNT (wrap would force Trino to "
                "materialise the whole result -> OOM on large tables).  "
                "G1 will be measured from extract at end-of-job.",
                shape,
            )
        return "", "skip"

    try:
        for k in ("group", "order", "limit", "offset", "having", "qualify"):
            tree.args.pop(k, None)
        tree.args.pop("distinct", None)
        # COUNT(*) -- the * star is the standard sqlglot shape here.
        tree.set("expressions", [exp.Count(this=exp.Star())])
        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.warning(
                "AST derive_count failed (falling back to wrap): %s", exc,
            )
        return _wrap_count(base_sql), "wrap"


def _derive_sum_sql(
    base_sql: str,
    columns: List[str],
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """Derive a cheap ``SELECT SUM(c1) AS s_0, SUM(c2) AS s_1, ...
    FROM <source FROM/JOIN/WHERE>`` by AST-stripping the projection +
    GROUP BY + ORDER BY + LIMIT + DISTINCT + HAVING + QUALIFY from
    base_sql.  Returns ``(sum_sql, mode)`` -- mode is ``"ast"``,
    ``"wrap"`` (sqlglot unavailable, small-job safe), or ``"skip"``
    (shape-affecting clauses present; source-side checksum cannot be
    derived without OOM-unsafe full materialisation).

    Why we MUST NOT wrap (operator-confirmed 2026-06-18):
      ``SELECT SUM(c) FROM (base_sql) AS t`` forces Trino to
      materialise the full base_sql result THEN sum -- on a 170M-row
      table with DISTINCT JOIN this OOMs the coordinator.  Same trap
      ``_derive_count_sql`` removed for COUNT(*); apply it here too.

    Math contract for ``ast`` mode:
      ``SUM(c) over source FROM/JOIN/WHERE`` equals
      ``SUM(c) over (base_sql) AS t`` iff:
        * base_sql has NO row-count-affecting clauses, OR
        * base_sql GROUP-BYs and ``c`` is SUM-aggregated in the
          projection -- additive aggregation passes through (sum-of-
          sums == grand sum).
      For DISTINCT / HAVING / QUALIFY / LIMIT / AVG-MAX-MIN-STDDEV
      projections, the equality breaks.  We conservatively SKIP when
      any shape-affecting clause is present -- caller logs a clear
      "source-side checksum unavailable" warning and falls back to
      internal consistency (chunk -> per-source -> cross-source).
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        # No sqlglot -- the wrap fallback is OOM-unsafe at scale but
        # the SINGLE-mode small-job case usually still fits.  Caller
        # decides whether to actually run it; we just signal the mode.
        _safe = lambda c: '"' + c.replace('"', '""') + '"'
        proj = ", ".join(f"SUM({_safe(c)}) AS s_{i}" for i, c in enumerate(columns))
        return (f"SELECT {proj} FROM ({_strip_trailing_semicolon(base_sql)}) AS t",
                "wrap")

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.warning(
                "AST parse failed for source-checksum SUM (skipping checksum): %s",
                exc,
            )
        return "", "skip"

    if not isinstance(tree, exp.Select):
        # UNION / CTE-at-top -- the AST strip path doesn't apply
        # cleanly.  Skip rather than emit an OOM-unsafe wrap.
        if logger:
            logger.info(
                "Source-checksum SUM: base_sql is not a plain SELECT "
                "(likely UNION / WITH-at-top) -- skipping source-side "
                "checksum.  Internal consistency checks still run."
            )
        return "", "skip"

    shape = _row_count_affecting_shape(tree)
    if shape:
        if logger:
            logger.info(
                "Source-checksum SUM: base_sql has top-level %s -- "
                "skipping source-side checksum.  Wrap would force "
                "Trino to materialise the whole result -> OOM on "
                "large tables.  Internal consistency checks (chunk "
                "-> per-source -> cross-source) still run.",
                shape,
            )
        return "", "skip"

    # AST strip the optional clauses; keep FROM / JOIN / WHERE / WITH.
    try:
        for k in ("group", "order", "limit", "offset", "having", "qualify"):
            tree.args.pop(k, None)
        tree.args.pop("distinct", None)
        # Build SUM(col) AS s_<i> projection for each column.
        new_exprs = []
        for i, c in enumerate(columns):
            col_expr = _build_column_expr(c)
            new_exprs.append(exp.Alias(
                this=exp.Sum(this=col_expr.copy()),
                alias=exp.to_identifier(f"s_{i}"),
            ))
        tree.set("expressions", new_exprs)
        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.warning(
                "AST derive_sum failed (skipping source-side checksum): %s",
                exc,
            )
        return "", "skip"


def _derive_group_by_count_sql(
    base_sql: str,
    column: str,
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """Derive a cheap ``SELECT col AS pv, COUNT(*) AS cnt FROM source
    WHERE ... GROUP BY col ORDER BY col`` over the same FROM/JOIN/WHERE
    as base_sql, with projection + outer GROUP BY + ORDER BY + LIMIT +
    DISTINCT stripped.  Returns ``(group_by_sql, mode)``.

    2026-06-17 -- the legacy partition-discovery wrap

        SELECT {col} AS pv, COUNT(*) FROM ({base}) AS plan_q
        GROUP BY {col} ORDER BY {col}

    fails on TWO counts when the operator passes a qualified column like
    ``FACT_TABLE.SAP_COMPANY_ID``:

      1. Trino can't resolve ``FACT_TABLE`` at the outer scope -- the
         subquery is aliased ``plan_q``, the original table is invisible.
      2. Even if it could, the inner query materialises the full join +
         projection before the outer GROUP BY runs -- doubling source-side
         work.

    AST mode emits the cheap shape directly against the source FROM,
    where the qualified column resolves natively.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return _wrap_group_by_count(base_sql, column), "wrap"

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.warning(
                "AST parse failed for group_by discovery (falling back to wrap): %s",
                exc,
            )
        return _wrap_group_by_count(base_sql, column), "wrap"

    if not isinstance(tree, exp.Select):
        return _wrap_group_by_count(base_sql, column), "wrap"

    # If the partition column is an alias of a computed expression (e.g.
    # ``a||b AS col``), the underlying source FROM doesn't have a column
    # called ``col`` -- AST GROUP BY {col} fails.  Wrap fallback is safe
    # because the outer references the inner-projected alias.
    if _is_alias_of_computed_expr(tree, column):
        if logger:
            logger.info(
                "AST derive_group_by_count: partition column '%s' is an alias "
                "of a computed expression -- using wrap fallback",
                column,
            )
        return _wrap_group_by_count(base_sql, column), "wrap"

    # 2026-06-18 -- STRATEGIC CORRECTION (user reported wrap-mode OOM).
    # Discovery now ALWAYS uses AST strip (source-only) regardless of
    # base_sql shape.  Two reasons:
    #
    #  1. Wrap forces Trino to materialise the entire base_sql first
    #     (DISTINCT JOIN over 170M rows -> OOM).  Discovery has to be
    #     cheap.
    #
    #  2. The discovery's column reference (``col``) is interpreted at
    #     SOURCE level, not at the user's projection-alias level.  When
    #     base_sql aliases ``FACT_table.SAP_COMPANY_ID AS "Sap Company
    #     Code"``, the wrap path tried to reference "SAP_COMPANY_ID" at
    #     the outer wrap level -> COLUMN_NOT_FOUND.  Source-level emit
    #     uses the operator-supplied qualified column directly.
    #
    # Trade-off accepted: when base_sql has DISTINCT / outer GROUP BY /
    # HAVING / etc, the AST-stripped discovery counts SOURCE rows
    # (pre-aggregation), which differ from what the chunk's full
    # base_sql will produce.  Operator must set FAIL_ON_MISMATCH=FALSE
    # in this case -- the per-chunk completeness check (which compares
    # discovery-derived expected to chunk actual) is no longer
    # meaningful, but G3 (sum-of-chunks == itself, derived from
    # extract) still anchors at end-of-job.
    #
    # The alias-mismatch case (operator's qualifier not in FROM scope):
    # AST emits the qualifier as-is.  If invalid, Trino reports the
    # error to the operator with line/column info; we don't paper over
    # it with a costly wrap.

    try:
        for k in ("group", "order", "limit", "offset", "having", "qualify"):
            tree.args.pop(k, None)
        tree.args.pop("distinct", None)
        col_expr = _build_column_expr(column)
        # Projection: col AS pv, COUNT(*) AS cnt
        tree.set("expressions", [
            exp.Alias(this=col_expr.copy(), alias=exp.to_identifier("pv")),
            exp.Alias(this=exp.Count(this=exp.Star()), alias=exp.to_identifier("cnt")),
        ])
        # GROUP BY col
        tree.set("group", exp.Group(expressions=[col_expr.copy()]))
        # ORDER BY col
        tree.set("order", exp.Order(expressions=[exp.Ordered(this=col_expr.copy())]))
        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.warning(
                "AST derive_group_by_count failed (falling back to wrap): %s", exc,
            )
        return _wrap_group_by_count(base_sql, column), "wrap"


def _derive_probe_sql(
    base_sql: str,
    partition_column: Optional[str],
    sum_columns: Optional[List[str]],
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[str, str]:
    """Emit ONE 'probe' query that anchors the entire planning phase.

    2026-06-20 -- STRATEGIC: replaces three independent full-table scans
    (pre-flight COUNT, group_by discovery, source-side SUM) with ONE
    GROUP BY shuffle that produces every anchor downstream needs:

        SELECT partition_column         AS _qs_pv,
               COUNT(*)                 AS _qs_cnt,
               SUM(c1)                  AS _qs_sum_c1,
               SUM(c2)                  AS _qs_sum_c2,
               ...
        FROM <source FROM/JOIN/WHERE>
        GROUP BY partition_column
        ORDER BY partition_column

    Trino executes the GROUP BY shuffle once and emits all aggregates
    in one pass.  Three independent scans collapse into one -- saves
    ~3-6 min of planning overhead on a 150M-row table.

    Modes:
      * partition_column is not None, sum_columns is non-empty:
          full probe -- per-partition count + per-partition sums.
      * partition_column is not None, sum_columns is empty:
          per-partition count only (matches _derive_group_by_count_sql).
      * partition_column is None, sum_columns is non-empty:
          SINGLE-mode probe -- total count + total sums (no GROUP BY).
      * partition_column is None, sum_columns is empty:
          degenerate -- count only (matches _derive_count_sql).

    Returns:
      ("...", "ast")  -- AST rewrite succeeded.  Caller executes it.
      ("",    "skip") -- base_sql has shape-affecting clauses (DISTINCT,
                         HAVING, QUALIFY, top GROUP BY, LIMIT, etc.)
                         that break SUM-over-source equivalence with
                         SUM-over-(base_sql).  Caller falls back to
                         legacy primitives (separate COUNT + discovery,
                         no source-checksum anchor).

    No "wrap" fallback: wrapping ``(base_sql)`` forces Trino to
    materialise the full result first -- on 150M rows that OOMs the
    coordinator (same trap _derive_count_sql / _derive_sum_sql already
    avoid via the skip mode).  Operator must install sqlglot or accept
    legacy two-scan planning.

    Math contract for the SUM portion (mirrors _derive_sum_sql):
      ``SUM(c) over (source FROM/JOIN/WHERE)`` equals
      ``SUM(c) over (base_sql) AS t`` iff:
        * base_sql has NO row-count-affecting clauses, OR
        * base_sql GROUP-BYs and ``c`` is SUM-aggregated in the
          projection (additive sum-of-sums == grand sum).
      For DISTINCT / HAVING / QUALIFY / LIMIT / AVG-MAX-MIN-STDDEV
      projections the equality breaks -- we SKIP.

    Column-disambiguation rules (per _derive_group_by_count_sql /
    _derive_sum_sql notes):
      * Computed-alias partition column -> skip (Trino can't GROUP BY
        an unevaluated alias from the source-level SELECT).
      * Qualifier-not-in-scope -> skip (operator pre-qualified with a
        table name base_sql has aliased).  Caller logs and falls back.
    """
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        if logger:
            logger.info(
                "ProbeQuery: sqlglot unavailable -- skip (caller falls "
                "back to legacy primitives)."
            )
        return "", "skip"

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception as exc:
        if logger:
            logger.info(
                "ProbeQuery: sqlglot parse failed (%s) -- skip (caller "
                "falls back to legacy primitives).", exc,
            )
        return "", "skip"

    if not isinstance(tree, exp.Select):
        # UNION / CTE-at-top: emit-against-source rewrites are too risky
        # without rebuilding each branch.  Caller falls back.
        if logger:
            logger.info(
                "ProbeQuery: base_sql is not a plain SELECT (UNION/CTE/etc.) "
                "-- skip (caller falls back to legacy primitives)."
            )
        return "", "skip"

    # Shape-affecting clauses break SUM-over-source equivalence.
    shape = _row_count_affecting_shape(tree)
    if shape:
        if logger:
            logger.info(
                "ProbeQuery: base_sql has top-level %s -- skip "
                "(SUM-over-source != SUM-over-base_sql; caller falls "
                "back to legacy primitives).", shape,
            )
        return "", "skip"

    sum_cols = list(sum_columns or [])
    # Column-resolvability checks for partition_column.
    if partition_column:
        if _is_alias_of_computed_expr(tree, partition_column):
            if logger:
                logger.info(
                    "ProbeQuery: partition column '%s' is an alias of a "
                    "computed expression -- skip (caller uses legacy "
                    "discovery with wrap, which handles aliases).",
                    partition_column,
                )
            return "", "skip"
        if not _qualifier_in_scope(tree, partition_column):
            if logger:
                logger.info(
                    "ProbeQuery: partition column qualifier in '%s' is "
                    "NOT in FROM scope -- skip (caller uses legacy "
                    "discovery with wrap, which drops the qualifier).",
                    partition_column,
                )
            return "", "skip"

    try:
        # Strip shape-affecting clauses + outer DISTINCT.
        for k in ("group", "order", "limit", "offset", "having", "qualify"):
            tree.args.pop(k, None)
        tree.args.pop("distinct", None)

        # Build the projection.
        projections: List[Any] = []
        if partition_column:
            pv_expr = _build_column_expr(partition_column)
            projections.append(
                exp.Alias(this=pv_expr.copy(), alias=exp.to_identifier("_qs_pv"))
            )
        projections.append(
            exp.Alias(this=exp.Count(this=exp.Star()), alias=exp.to_identifier("_qs_cnt"))
        )
        for idx, col in enumerate(sum_cols):
            col_expr = _build_column_expr(col)
            # Anonymous Sum(this=col_expr) is the standard sqlglot shape.
            sum_node = exp.Sum(this=col_expr)
            projections.append(
                exp.Alias(this=sum_node, alias=exp.to_identifier(f"_qs_sum_{idx}"))
            )
        tree.set("expressions", projections)

        # GROUP BY + ORDER BY when partition_column is supplied.
        if partition_column:
            pv_expr2 = _build_column_expr(partition_column)
            tree.set("group", exp.Group(expressions=[pv_expr2.copy()]))
            tree.set("order", exp.Order(expressions=[exp.Ordered(this=pv_expr2.copy())]))

        return tree.sql(dialect=dialect), "ast"
    except Exception as exc:
        if logger:
            logger.info(
                "ProbeQuery: AST emit failed (%s) -- skip (caller falls "
                "back to legacy primitives).", exc,
            )
        return "", "skip"


def _compute_adaptive_concurrency(
    job_config: Dict[str, Any],
    logger: Optional[logging.Logger] = None,
) -> int:
    """Compute ``max_concurrent_chunks`` from system resources.

    2026-06-20 -- STRATEGIC: replaces the fixed ``max_concurrent_chunks=2``
    default.  Concurrency now scales with CPU + memory headroom so a
    16-core / 64 GB pod runs 6-8 chunks in parallel while a 2-core / 8 GB
    dev box still runs 2.  Operator override (explicit
    ``max_concurrent_chunks`` in job_config) always wins -- this helper
    only fires when the operator left the knob unset.

    Inputs (all from job_config; safe defaults):
      max_concurrent_chunks         -- operator override.  When set + > 0,
                                       this helper is bypassed entirely.
      max_concurrent_chunks_ceiling -- hard upper bound (default 8) to
                                       protect Trino from per-pod
                                       hammering.
      batch_size                    -- rows per fetchmany batch.
      avg_row_bytes                 -- per-row size estimate.
      queue_maxsize                 -- batches buffered in ChunkWriter.

    Memory model per concurrent chunk:
        peak_bytes = batch_size * avg_row_bytes * queue_maxsize

    Returns max(2, min(cpu_cap, mem_cap, ceiling)).  Floor of 2 keeps
    SINGLE-mode pods from serializing.
    """
    # Operator override wins -- this helper never overrides explicit setting.
    explicit = job_config.get("max_concurrent_chunks")
    if explicit is not None:
        try:
            v = int(explicit)
            if v > 0:
                return v
        except (TypeError, ValueError):
            pass

    ceiling = int(job_config.get("max_concurrent_chunks_ceiling") or 8)
    floor = 2

    # CPU cap: at most half the cores so writer threads + asyncio loop
    # still have room to schedule.
    try:
        cpu_count = os.cpu_count() or 4
    except Exception:
        cpu_count = 4
    cpu_cap = max(floor, cpu_count // 2)

    # Memory cap: half of available RAM for chunk buffers.
    batch_size = int(job_config.get("batch_size") or 100_000)
    avg_row_bytes = int(job_config.get("avg_row_bytes") or 200)
    queue_maxsize = int(job_config.get("queue_maxsize") or 4)
    per_chunk_bytes = max(1, batch_size * avg_row_bytes * queue_maxsize)
    try:
        import psutil  # type: ignore
        avail_bytes = int(psutil.virtual_memory().available)
        mem_cap = max(floor, int(avail_bytes * 0.5 // per_chunk_bytes))
    except ImportError:
        # No psutil -- be conservative and trust CPU cap only.
        mem_cap = cpu_cap
    except Exception:
        mem_cap = cpu_cap

    chosen = max(floor, min(cpu_cap, mem_cap, ceiling))
    if logger:
        logger.info(
            "AdaptiveConcurrency: cpu_count=%d cpu_cap=%d mem_cap=%d "
            "ceiling=%d -> max_concurrent_chunks=%d (per_chunk_bytes=%s)",
            cpu_count, cpu_cap, mem_cap, ceiling, chosen,
            f"{per_chunk_bytes:,}",
        )
    return chosen


def _format_wrap_literal(value) -> str:
    """Format a single non-NULL value as a SQL literal for the wrap path.
    NULL is handled by the caller (becomes ``IS NULL`` outside any IN).
    """
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def _wrap_with_where(base_sql: str, column: str, value: Any) -> str:
    """Legacy wrap fallback -- subquery with outer WHERE.  Kept as the
    safety net when sqlglot can't parse the base_sql.

    2026-06-17 fix: strip any ``TABLE.`` qualifier from the column -- the
    subquery alias ``pv`` means the original table is no longer in
    scope.  ``pv.FACT_TABLE.col`` would be a 3-part name Trino rejects.

    2026-06-17 bucketing: when ``value`` is a list/tuple, emit IN-clause
    so a bucket of N values runs as one query instead of N.  NULL-aware.
    """
    bare = _bare_column_name(column)
    col_ref = f"pv.{bare}"

    def _single_predicate(v) -> str:
        if v is None:
            return f"{col_ref} IS NULL"
        return f"{col_ref} = {_format_wrap_literal(v)}"

    if isinstance(value, (list, tuple, set, frozenset)):
        members = list(value)
        if not members:
            predicate = "1 = 0"
        elif len(members) == 1:
            predicate = _single_predicate(members[0])
        else:
            has_null = any(v is None for v in members)
            non_nulls = [v for v in members if v is not None]
            if not non_nulls:
                predicate = f"{col_ref} IS NULL"
            else:
                in_list = ", ".join(_format_wrap_literal(v) for v in non_nulls)
                in_clause = f"{col_ref} IN ({in_list})"
                predicate = f"({in_clause} OR {col_ref} IS NULL)" if has_null else in_clause
    else:
        predicate = _single_predicate(value)

    return (
        f"SELECT * FROM (\n"
        f"{_strip_trailing_semicolon(base_sql)}\n"
        f") AS pv WHERE {predicate}"
    )


def _wrap_distinct(base_sql: str, column: str) -> str:
    """Legacy wrap fallback for distinct discovery.

    2026-06-17 fix: strip ``TABLE.`` qualifier -- the wrap alias means
    the source table is no longer in scope at the outer SELECT.
    """
    bare = _bare_column_name(column)
    return (
        f"SELECT DISTINCT {bare} FROM (\n"
        f"{_strip_trailing_semicolon(base_sql)}\n"
        f") AS plan_q "
        f"ORDER BY {bare}"
    )


def _wrap_count(base_sql: str) -> str:
    """Legacy wrap fallback for pre-flight COUNT(*).  Identical to the
    original ``_fetch_count`` shape -- referenced columns don't matter
    because COUNT(*) doesn't read any column."""
    return (
        f"SELECT COUNT(*) FROM (\n"
        f"{_strip_trailing_semicolon(base_sql)}\n"
        f") AS pre_flight_q"
    )


def _wrap_group_by_count(base_sql: str, column: str) -> str:
    """Legacy wrap fallback for partition discovery group_by.

    2026-06-17 fix: strip ``TABLE.`` qualifier -- the wrap alias means
    the source table is no longer in scope at the outer SELECT /
    GROUP BY / ORDER BY.
    """
    bare = _bare_column_name(column)
    return (
        f"SELECT {bare} AS pv, COUNT(*) AS cnt FROM (\n"
        f"{_strip_trailing_semicolon(base_sql)}\n"
        f") AS plan_q "
        f"GROUP BY {bare} "
        f"ORDER BY {bare}"
    )


def _is_alias_of_computed_expr(tree: Any, column_name: str) -> bool:
    """Returns True if ``column_name`` is an outer-SELECT alias of a
    computed (non-direct-column) expression -- e.g. ``a||b AS col`` or
    ``CASE WHEN x THEN 1 END AS col``.

    Critical for AST mode: Trino CANNOT filter on aliases in WHERE
    (``WHERE col = 'X'`` against ``SELECT a||b AS col`` raises
    'Column not resolved').  Discovery derives ``SELECT DISTINCT col``
    against the same alias -- also fails.

    When this returns True, the AST helpers MUST auto-fallback to wrap
    mode (where the outer SELECT references the inner-projected alias,
    which Trino DOES support).
    """
    try:
        from sqlglot import expressions as exp
    except ImportError:
        return False
    # 2026-06-17 -- compare against the BARE column name.  Operator may
    # pass ``TABLE.COL``; aliases are always unqualified (``foo AS col``),
    # so qualified-vs-bare would never match without this strip.
    bare_name = _bare_column_name(column_name)
    if not isinstance(tree, exp.Select):
        # For UNION branches, check each branch's outermost.
        if isinstance(tree, (exp.Union, exp.Intersect, exp.Except)):
            return (
                _is_alias_of_computed_expr(tree.this, column_name)
                or _is_alias_of_computed_expr(tree.expression, column_name)
            )
        return False
    for proj in tree.args.get("expressions") or []:
        if not isinstance(proj, exp.Alias):
            continue
        alias = getattr(proj, "alias", None)
        if not alias or alias.lower() != bare_name.lower():
            continue
        # Found `... AS col`.  Trino does NOT expose SELECT-level
        # aliases in the WHERE clause (only in HAVING / ORDER BY).
        # Three sub-cases:
        aliased = proj.this
        if isinstance(aliased, exp.Column):
            inner_name = getattr(aliased, "name", None)
            if inner_name and inner_name.lower() == bare_name.lower():
                # `t.col AS col` or `col AS col` -- redundant rename.
                # The underlying column has the same name as the alias,
                # so AST `WHERE col` resolves natively to the real
                # column.  Safe.
                return False
            # `t.other AS col` -- alias name DIFFERS from the underlying
            # column.  AST `WHERE col` would refer to the alias which
            # Trino can't see in WHERE.  Fall back to wrap.
            return True
        # Computed alias (Concat, Func, Case, Cast, Subquery, ...).
        # AST `WHERE col` definitely fails.
        return True
    return False


def _validate_base_sql_ast_safe(
    base_sql: str,
    partition_column: str,
    dialect: str = "trino",
    logger: Optional[logging.Logger] = None,
) -> Tuple[bool, List[str]]:
    """Scan base_sql for shapes where AST WHERE-injection could change
    semantics vs the wrapped query.  Returns (is_safe, list_of_warnings).

    2026-06-17 -- data completeness is the priority.  When we inject
    ``col = value`` into base_sql's top-level WHERE, the result is
    semantically equivalent to a wrap ONLY if:

      * The query has no window functions (``OVER(...)``).  A window
        over a different partition column would compute different
        values per-chunk vs over the full result.
      * The partition column appears in the projection (so chunk
        consumers can read it back and so the discovery query can
        SELECT DISTINCT it).
      * No INTERSECT / EXCEPT (set difference depends on the full
        comparison set; per-chunk would change the result).

    Warnings are NOT errors -- AST mode still runs.  G3 reconcile
    (sum(chunk rows) == expected_total) catches drift downstream.
    The right fix when this fires is to rewrite the SQL (remove the
    window function, materialise a snapshot, etc.) -- not to add an
    operator-facing planner toggle.
    """
    warnings: List[str] = []
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return True, []  # no sqlglot -> we'll wrap-fallback anyway

    try:
        tree = sqlglot.parse_one(_strip_trailing_semicolon(base_sql), dialect=dialect)
    except Exception:
        return True, []  # parse will fail later, wrap-fallback handles it

    # Check 1: window functions.
    windows = list(tree.find_all(exp.Window))
    if windows:
        warnings.append(
            f"base_sql contains {len(windows)} window function(s) "
            f"(OVER ... clause).  Per-chunk WHERE-injection may compute "
            f"window values over a SUBSET of rows -- the per-chunk window "
            f"result will differ from the full-query window result.  "
            f"Fix the SQL: drop the OVER clause, materialise a snapshot, "
            f"or move window computation downstream of the file write."
        )

    # Check 2: INTERSECT / EXCEPT.
    set_ops = list(tree.find_all(exp.Intersect, exp.Except))
    if set_ops:
        warnings.append(
            f"base_sql contains INTERSECT/EXCEPT.  Per-chunk WHERE-injection "
            f"changes the comparison set, potentially producing different "
            f"rows than the full query.  Materialise the set comparison "
            f"into a temp/snapshot table and SELECT from it instead."
        )

    # Check 2b: top-level LIMIT.  AST WHERE-inject pushes the filter
    # BEFORE the LIMIT (per-chunk: at most LIMIT rows that match), whereas
    # wrap behaviour applied LIMIT BEFORE the filter (per-chunk: subset of
    # the SAME limited sample).  Operators using LIMIT in base_sql are
    # usually testing / sampling and partition mode is for scale --
    # combination is rare but the semantic divergence is real.
    if isinstance(tree, exp.Select) and tree.args.get("limit") is not None:
        warnings.append(
            "base_sql contains a top-level LIMIT clause.  Per-chunk AST "
            "inject applies the partition filter BEFORE the LIMIT; the "
            "legacy wrap applied LIMIT first then filtered -- different "
            "total row counts.  If LIMIT is for sampling, run the sample "
            "separately from the partitioned extract."
        )

    # Check 2c (Gap 1): ambiguous partition column in JOIN.
    # SELECT a.col, b.col FROM A JOIN B  -- both AST `WHERE col` and
    # wrap `WHERE pv.col` are ambiguous.  Trino can't pick a side.
    # Operator MUST qualify (e.g. partition on a.col explicitly,
    # rename one with an alias, or drop the duplicate from SELECT).
    #
    # 2026-06-17 -- if the operator ALREADY qualified the partition
    # column (``TABLE.COL``), ambiguity is resolved by the qualifier.
    # Skip the warning in that case; we still compare against the bare
    # name when searching the projection because aliases / unqualified
    # column refs in the SELECT list use the bare form.
    _bare_partition_col = _bare_column_name(partition_column)
    _operator_qualifier = _parse_qualified_column(partition_column)[0]
    if isinstance(tree, exp.Select):
        # Walk projection's Column nodes that match partition_column name.
        matching_tables = set()
        for proj in tree.args.get("expressions") or []:
            # SELECT * doesn't help us reason about ambiguity here -- the
            # underlying tables might or might not have the column.  Skip.
            if isinstance(proj, exp.Star):
                continue
            for c in proj.find_all(exp.Column):
                if c.name and c.name.lower() == _bare_partition_col.lower():
                    # Track table qualifier (alias / table name) or "" for unqualified.
                    matching_tables.add((c.table or "").lower())
        # 2+ DIFFERENT qualifiers means ambiguous (e.g. {"a", "b"} or
        # {"", "a"} -- the unqualified one could resolve to either).
        # When the operator pre-qualified the partition column, the
        # AST emit explicitly references ``TABLE.COL`` so Trino picks
        # the right side -- no ambiguity warning needed.
        if len(matching_tables) > 1 and not _operator_qualifier:
            warnings.append(
                f"AMBIGUOUS partition column '{partition_column}': appears "
                f"with multiple table qualifiers in the SELECT projection "
                f"({sorted(matching_tables)!r}).  Both AST inject and wrap "
                f"would produce a runtime 'Column ambiguous' error.  "
                f"Qualify the partition column upstream (e.g. partition on "
                f"'a.{_bare_partition_col}' explicitly, or rename one "
                f"duplicate in the SELECT)."
            )

    # Check 3: partition column NOT in projection.
    # Walk top-level SELECT projection + UNION branches' projections.
    # 2026-06-17 -- compare against the BARE column name.  ``c.name`` and
    # alias names are always unqualified in sqlglot's tree even when the
    # source SQL wrote ``T.col``; ``c.table`` carries the qualifier.
    def _projection_has(node, col_name) -> bool:
        if not isinstance(node, exp.Select):
            return False
        bare = _bare_column_name(col_name)
        for proj in node.args.get("expressions") or []:
            # SELECT *  -- column is implicitly available
            if isinstance(proj, exp.Star):
                return True
            # Direct column reference (qualified or unqualified)
            for c in proj.find_all(exp.Column):
                if c.name and c.name.lower() == bare.lower():
                    return True
            # Aliased expression: SELECT foo AS col_name
            if isinstance(proj, exp.Alias) and proj.alias \
                    and proj.alias.lower() == bare.lower():
                return True
        return False

    selects = [tree] if isinstance(tree, exp.Select) else list(tree.find_all(exp.Select))
    if not any(_projection_has(s, partition_column) for s in selects):
        warnings.append(
            f"partition_column '{partition_column}' does NOT appear in the "
            f"base_sql SELECT projection.  AST inject will still WHERE on it, "
            f"but downstream consumers (and the discovery DISTINCT probe) "
            f"can't read the value.  Add '{partition_column}' to your SELECT."
        )

    if warnings and logger:
        for w in warnings:
            logger.warning("AST safety check: %s", w)

    return (not warnings), warnings
