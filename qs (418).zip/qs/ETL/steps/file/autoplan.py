"""AutoPlan -- the smart planner that makes record-count irrelevant.

2026-06-20 -- STRATEGIC: operators were tuning many size-aware knobs
(partition_min_rows, verify_max_rows, max_concurrent_chunks, bucket_size,
batch_size, queue_maxsize...) per job.  Each knob was a chance to get
it wrong on the next job that didn't match yesterday's profile.

AutoPlan replaces all of that with ONE measure-then-decide flow:

  1. **Probe** the source -- learn actual row count, per-partition
     cardinality, per-partition distribution skew.
  2. **Inspect** the system -- learn CPU cores, available memory, the
     row-byte estimate from the schema width.
  3. **Decide** the execution plan -- mode (SINGLE vs PARTITION_VALUES),
     concurrency, batch size, queue depth, bucketing, verify strategy.
     Each decision is derived from MEASUREMENTS, not from operator
     hardcoded thresholds.
  4. **Explain** each decision in the run-report so the operator can
     see WHY this run picked the strategy it did.

Operator surface shrinks to just:
  * generated_sql  (with {SOURCE} placeholder)
  * source_fqn OR catalog/schema/table
  * (optional) checksum_columns for SUM gate

Everything else is computed.  Operator can still override (any decision
is overrideable by setting the explicit knob on the polling row) but
none of them are REQUIRED.

Pipeline behaviour is the SAME whether the job is 1K rows or 1B rows.
The plan adapts to the actual data shape.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# Row-byte estimate when we can't infer from the schema.  Average across
# the 50+ jobs in production today; a wider row triggers PARTITION_VALUES
# sooner via the memory check below.
DEFAULT_AVG_ROW_BYTES = 200

# Safety multiplier on memory usage estimates.  At 0.4 we use at most
# 40% of available RAM for chunk buffers, leaving 60% headroom for
# Spark spill / OS reserve / writer buffering / etc.
MEMORY_SAFETY_FACTOR = 0.4

# Hard ceiling on parallel chunks regardless of resources -- protects
# the SHARED TRINO COORDINATOR from per-pod hammering.
#
# 2026-06-20 deep-dive (post-pilot): default lowered 8 -> 4 because
# user pilot showed 8 concurrent chunks queue on a busy Trino: 5 run
# immediately, 3 wait 5-6 min in coordinator queue, total job time
# REGRESSES (9 min vs pre-Phase-152 7 min on max_concurrent=2).
#
# 4 is the empirical sweet spot for a typical shared Trino:
#   * Enough parallelism for per-pod throughput
#   * Few enough queries that the coordinator runs them in one wave
#     instead of queueing
# Operators on a DEDICATED Trino can raise to 8 via:
#   * polling row: MAX_CONCURRENT_CHUNKS_CEILING
#   * helm cluster-wide: config.autoplan.concurrency_ceiling
#
# Operators who KNOW their data + Trino can also pin
# MAX_CONCURRENT_CHUNKS directly per-job (bypasses AutoPlan entirely).
DEFAULT_CONCURRENCY_CEILING = 4

# Floor: even on tiny pods we keep at least 2 concurrent chunks so
# SINGLE-mode fallback doesn't serialise N jobs in sequence.
CONCURRENCY_FLOOR = 2

# Trino-pressure profiles -- operator picks ONE per-job (or cluster-wide
# via helm).  Each profile maps to a concurrency ceiling tuned for that
# cluster shape.  ALL profiles are zero-overhead (just a constant);
# "auto" is the ONLY one that fires the Trino capacity probe at plan
# time (one quick query, <1s).
TRINO_PROFILES = {
    "low":           1,   # serial, useful for debug / very busy clusters
    "shared_busy":   2,   # heavily shared cluster with constant queueing
    "shared_normal": 4,   # default -- typical shared Trino
    "dedicated":     8,   # dedicated cluster, more parallelism OK
    "high":         12,   # large dedicated cluster, very high throughput
}
DEFAULT_TRINO_PROFILE = "shared_normal"


@dataclass
class AutoPlanDecision:
    """A single decision the planner made + the reason for it.

    Pushed into FileRunReport.runtime_knobs so operators can see WHY
    the plan picked what it picked.  Decision rules are explicit,
    measurement-driven, and not hardcoded thresholds operators must
    maintain.
    """
    knob: str           # e.g. "mode", "max_concurrent_chunks"
    chosen: Any         # the value AutoPlan picked
    reason: str         # human-readable derivation


@dataclass
class AutoPlanInputs:
    """Everything AutoPlan needs to decide.

    Source measurements come from the ProbeQuery result (or a cheaper
    COUNT when checksum_columns isn't set).  System measurements come
    from psutil/os.  History measurements come from prior-run timing
    (optional; AutoPlan works without).
    """
    # Source-shape measurements (from probe).
    total_rows: int
    partition_cardinality: int = 0  # 0 means single-partition / no partition
    max_partition_rows: int = 0     # peak row count among partitions
    avg_partition_rows: int = 0     # mean row count -- skew = max/avg
    null_partition_present: bool = False
    # Schema / row-byte estimate.
    avg_row_bytes: int = DEFAULT_AVG_ROW_BYTES
    # System measurements.
    cpu_cores: int = 4
    available_memory_bytes: int = 8 * 1024 * 1024 * 1024  # 8 GB default
    # Operator overrides (None -> AutoPlan decides).
    override_max_concurrent: Optional[int] = None
    override_batch_size: Optional[int] = None
    override_queue_maxsize: Optional[int] = None
    override_mode: Optional[str] = None        # "single" | "partition_values"
    override_concurrency_ceiling: Optional[int] = None
    # 2026-06-20 deep-dive fix: even when the PROBE didn't fire (no
    # checksum_columns set, partition_cardinality=0), the operator may
    # have configured a partition_column on the polling row.  AutoPlan
    # needs to know about it so the mode-decision message doesn't lie
    # ("no partition_column configured" when one WAS configured) and so
    # the planner uses PARTITION_VALUES mode when the operator asked.
    partition_column_configured: bool = False
    # 2026-06-21 (post-pilot Trino-pressure feedback): operator-chosen
    # cluster profile drives the concurrency ceiling.  Default
    # "shared_normal" matches the post-pilot ceiling=4 choice.  When
    # set to "auto", caller fires a Trino capacity probe and passes
    # the live cluster state via trino_state_hint below.
    trino_profile: str = DEFAULT_TRINO_PROFILE
    # When trino_profile="auto", caller may set this with a Trino
    # capacity-probe result so AutoPlan picks the right ceiling.
    # Shape: {"queued": int, "running": int, "active_workers": int}.
    # None = no probe ran; fall back to shared_normal ceiling.
    trino_state_hint: Optional[Dict[str, Any]] = None


@dataclass
class AutoPlanOutputs:
    """Complete execution plan the planner derived.

    Each numeric knob is paired with an AutoPlanDecision explaining
    the derivation.  ScanPlan + ChunkWriter consume these values
    directly; the decisions get logged AND pushed into the run-report
    so operators see them.
    """
    mode: str                     # "single" | "partition_values"
    max_concurrent_chunks: int
    batch_size: int
    queue_maxsize: int
    target_chunk_rows: int        # how big each chunk should aim to be
    auto_bucket_size: int         # 1 means no bucketing
    verify_strategy: str          # "full" | "sample" | "skip"
    verify_sample_pct: float = 0.0  # only set when strategy == "sample"
    decisions: List[AutoPlanDecision] = field(default_factory=list)

    def explain(self) -> Dict[str, str]:
        """Flat dict for FileRunReport.set_runtime_knobs -- each entry
        is a one-line "chose X because Y" string."""
        return {
            d.knob: f"{d.chosen} -- {d.reason}"
            for d in self.decisions
        }


def _ceiling_from_auto_probe(
    state: Optional[Dict[str, Any]],
) -> tuple:
    """Map a Trino capacity-probe result to a concurrency ceiling.

    Heuristic (single source of truth so operators see consistent
    behaviour across runs):
      * No probe data           -> shared_normal (4)
      * queued > 10             -> shared_busy (2)   [coordinator backed up]
      * queued > 3 OR running > 30 -> shared_normal (4)
      * active_workers >= 10 AND queued == 0 AND running < 10 -> dedicated (8)
      * Otherwise               -> shared_normal (4)

    Returns ``(ceiling, reason)`` so AutoPlan can surface WHY this
    number was picked.
    """
    if not state:
        return TRINO_PROFILES["shared_normal"], (
            "trino_profile='auto' but no capacity probe result -- "
            "falling back to shared_normal ceiling"
        )
    queued = int(state.get("queued") or 0)
    running = int(state.get("running") or 0)
    workers = int(state.get("active_workers") or 0)
    if queued > 10:
        return TRINO_PROFILES["shared_busy"], (
            f"trino_profile='auto': queued={queued} (>10) -> "
            f"cluster backed up, using shared_busy ceiling"
        )
    if queued > 3 or running > 30:
        return TRINO_PROFILES["shared_normal"], (
            f"trino_profile='auto': queued={queued}, running={running} "
            f"-> moderate load, using shared_normal ceiling"
        )
    if workers >= 10 and queued == 0 and running < 10:
        return TRINO_PROFILES["dedicated"], (
            f"trino_profile='auto': workers={workers}, queued=0, "
            f"running={running} -> capacity available, using dedicated ceiling"
        )
    return TRINO_PROFILES["shared_normal"], (
        f"trino_profile='auto': workers={workers}, queued={queued}, "
        f"running={running} -> default shared_normal ceiling"
    )


def measure_system_resources() -> Dict[str, int]:
    """Measure cpu cores + available memory.  Returns the values
    AutoPlan will use; falls back safely when psutil isn't installed."""
    try:
        cpu = os.cpu_count() or 4
    except Exception:
        cpu = 4
    try:
        import psutil  # type: ignore
        mem = int(psutil.virtual_memory().available)
    except ImportError:
        mem = 8 * 1024 * 1024 * 1024  # 8 GB fallback
    except Exception:
        mem = 8 * 1024 * 1024 * 1024
    return {"cpu_cores": cpu, "available_memory_bytes": mem}


def autoplan(
    inputs: AutoPlanInputs,
    logger: Optional[logging.Logger] = None,
) -> AutoPlanOutputs:
    """Run the full planner from inputs -> outputs.  Each decision is
    derived from the measurements supplied; no hidden hardcoded
    thresholds escape this function.

    Decision order matters: mode is decided first, then batch + queue
    sizes (which feed concurrency calculation), then concurrency,
    then bucketing, then verify strategy.
    """
    decisions: List[AutoPlanDecision] = []

    # ── 1. MODE: SINGLE vs PARTITION_VALUES ───────────────────────────
    if inputs.override_mode in ("single", "partition_values"):
        mode = inputs.override_mode
        decisions.append(AutoPlanDecision(
            knob="mode",
            chosen=mode,
            reason="operator override",
        ))
    elif inputs.partition_cardinality == 0 and not inputs.partition_column_configured:
        # Truly no partition info available.
        mode = "single"
        decisions.append(AutoPlanDecision(
            knob="mode",
            chosen=mode,
            reason="no partition_column configured on job",
        ))
    elif inputs.partition_cardinality == 0 and inputs.partition_column_configured:
        # 2026-06-20 deep-dive fix: probe didn't fire (no checksum_columns)
        # but operator DID configure a partition column.  Honour their
        # intent -- PARTITION_VALUES mode, legacy discovery path handles
        # the cardinality / bucketing decisions.  Without this branch
        # AutoPlan said "no partition_column configured" which contradicted
        # the polling row + confused operators reading result.html.
        mode = "partition_values"
        decisions.append(AutoPlanDecision(
            knob="mode",
            chosen=mode,
            reason=(
                "partition_column configured on job (probe didn't run to "
                "measure cardinality -- legacy discovery handles it)"
            ),
        ))
    else:
        # Will the source fit in a single SQL fetch without busting
        # Trino's coordinator memory?  Estimate:
        #   peak_bytes_single = total_rows * avg_row_bytes
        # vs the available pod memory headroom.
        peak_single = inputs.total_rows * max(1, inputs.avg_row_bytes)
        budget = int(inputs.available_memory_bytes * MEMORY_SAFETY_FACTOR)
        if peak_single <= budget:
            mode = "single"
            decisions.append(AutoPlanDecision(
                knob="mode",
                chosen=mode,
                reason=(
                    f"{inputs.total_rows:,} rows x {inputs.avg_row_bytes} B = "
                    f"{peak_single // (1024**2):,} MB fits in {budget // (1024**2):,} MB "
                    f"budget ({MEMORY_SAFETY_FACTOR*100:.0f}% of available memory)"
                ),
            ))
        else:
            mode = "partition_values"
            decisions.append(AutoPlanDecision(
                knob="mode",
                chosen=mode,
                reason=(
                    f"{inputs.total_rows:,} rows x {inputs.avg_row_bytes} B = "
                    f"{peak_single // (1024**2):,} MB exceeds {budget // (1024**2):,} MB "
                    f"budget -- splitting via partition_values to keep "
                    f"per-chunk memory bounded"
                ),
            ))

    # ── 2. BATCH SIZE: rows per fetchmany ─────────────────────────────
    # Goal: each batch large enough to amortise network round-trips without
    # buffering too much per chunk.  Target ~20 MB per batch (matches
    # what Trino cursors stream efficiently on a 1 GbE link).
    #
    # 2026-06-20 deep-dive fix: pre-fix targeted 5 MB which produced
    # 26K rows for 200-byte rows -- SMALLER than the legacy 100K default
    # and caused a measurable regression on jobs that were fine with the
    # higher batch size (test: 5.6M rows 7 min -> 9 min).  Raised to
    # 20 MB target + floor 100K so we never go below the legacy default.
    if inputs.override_batch_size:
        batch_size = inputs.override_batch_size
        decisions.append(AutoPlanDecision(
            knob="batch_size",
            chosen=batch_size,
            reason="operator override",
        ))
    else:
        target_bytes_per_batch = 20 * 1024 * 1024  # 20 MB
        derived = max(
            100_000,  # floor = legacy default; never regress below it
            min(500_000, target_bytes_per_batch // max(1, inputs.avg_row_bytes)),
        )
        batch_size = int(derived)
        decisions.append(AutoPlanDecision(
            knob="batch_size",
            chosen=batch_size,
            reason=(
                f"target ~20 MB per batch / {inputs.avg_row_bytes} B per row "
                f"clamped to [100K, 500K] (100K floor matches legacy default)"
            ),
        ))

    # ── 3. QUEUE MAXSIZE: batches buffered in ChunkWriter ─────────────
    # Smaller for wide rows (avg_row_bytes large), larger for narrow.
    # Keeps per-chunk peak memory predictable.
    if inputs.override_queue_maxsize:
        queue_maxsize = inputs.override_queue_maxsize
        decisions.append(AutoPlanDecision(
            knob="queue_maxsize",
            chosen=queue_maxsize,
            reason="operator override",
        ))
    else:
        if inputs.avg_row_bytes >= 2000:    # wide rows -> shallow queue
            queue_maxsize = 2
        elif inputs.avg_row_bytes >= 500:
            queue_maxsize = 3
        else:
            queue_maxsize = 4
        decisions.append(AutoPlanDecision(
            knob="queue_maxsize",
            chosen=queue_maxsize,
            reason=(
                f"row width {inputs.avg_row_bytes} B -> "
                f"queue depth {queue_maxsize}"
            ),
        ))

    # ── 4. CONCURRENCY ───────────────────────────────────────────────
    if inputs.override_max_concurrent is not None and inputs.override_max_concurrent > 0:
        max_concurrent = inputs.override_max_concurrent
        decisions.append(AutoPlanDecision(
            knob="max_concurrent_chunks",
            chosen=max_concurrent,
            reason="operator override (MAX_CONCURRENT_CHUNKS on polling row)",
        ))
    else:
        per_chunk_bytes = batch_size * inputs.avg_row_bytes * queue_maxsize
        cpu_cap = max(CONCURRENCY_FLOOR, inputs.cpu_cores // 2)
        mem_cap = max(
            CONCURRENCY_FLOOR,
            int(inputs.available_memory_bytes * MEMORY_SAFETY_FACTOR / max(1, per_chunk_bytes)),
        )

        # 2026-06-21 -- profile-driven ceiling.  Operator picks the
        # cluster shape ONCE via trino_profile; ceiling derives from
        # the profile lookup.  Explicit override_concurrency_ceiling
        # still wins.  "auto" profile consults trino_state_hint to pick
        # a profile dynamically based on the live capacity probe.
        profile_name = (inputs.trino_profile or DEFAULT_TRINO_PROFILE).lower()
        if inputs.override_concurrency_ceiling:
            ceiling = inputs.override_concurrency_ceiling
            ceiling_reason = (
                f"operator ceiling override "
                f"(MAX_CONCURRENT_CHUNKS_CEILING={ceiling})"
            )
        elif profile_name == "auto":
            ceiling, ceiling_reason = _ceiling_from_auto_probe(
                inputs.trino_state_hint
            )
        elif profile_name in TRINO_PROFILES:
            ceiling = TRINO_PROFILES[profile_name]
            ceiling_reason = (
                f"trino_profile='{profile_name}' -> ceiling {ceiling}"
            )
        else:
            ceiling = TRINO_PROFILES[DEFAULT_TRINO_PROFILE]
            ceiling_reason = (
                f"unknown trino_profile={profile_name!r} -> "
                f"default '{DEFAULT_TRINO_PROFILE}' (ceiling {ceiling})"
            )

        max_concurrent = max(CONCURRENCY_FLOOR, min(cpu_cap, mem_cap, ceiling))
        decisions.append(AutoPlanDecision(
            knob="max_concurrent_chunks",
            chosen=max_concurrent,
            reason=(
                f"min(cpu_cap={cpu_cap}, mem_cap={mem_cap}, "
                f"ceiling={ceiling}) with floor {CONCURRENCY_FLOOR}.  "
                f"Ceiling source: {ceiling_reason}"
            ),
        ))

    # ── 5. TARGET CHUNK ROWS + AUTO-BUCKETING ─────────────────────────
    # If we're in PARTITION_VALUES mode AND the per-partition row
    # distribution is highly skewed OR cardinality is huge, bucket
    # adjacent values together so each chunk has predictable size.
    target_chunk_rows = max(
        100_000,
        int(inputs.available_memory_bytes * MEMORY_SAFETY_FACTOR / max(1, inputs.avg_row_bytes) // max_concurrent),
    )
    auto_bucket_size = 1
    if mode == "partition_values" and inputs.partition_cardinality > 0:
        # Target ~max_concurrent * 4 chunks (4 waves of work) for good
        # parallelism without too-fine-grained bucketing overhead.
        target_chunks = max(max_concurrent * 4, max_concurrent * 2)
        if inputs.partition_cardinality > target_chunks:
            auto_bucket_size = max(
                1, (inputs.partition_cardinality + target_chunks - 1) // target_chunks,
            )
            decisions.append(AutoPlanDecision(
                knob="auto_bucket_size",
                chosen=auto_bucket_size,
                reason=(
                    f"{inputs.partition_cardinality} partitions / "
                    f"{target_chunks} target chunks -> bucket size "
                    f"{auto_bucket_size}"
                ),
            ))
        else:
            decisions.append(AutoPlanDecision(
                knob="auto_bucket_size",
                chosen=1,
                reason=(
                    f"{inputs.partition_cardinality} partitions fits in "
                    f"{target_chunks} chunks budget -- no bucketing needed"
                ),
            ))
    decisions.append(AutoPlanDecision(
        knob="target_chunk_rows",
        chosen=target_chunk_rows,
        reason=(
            f"({inputs.available_memory_bytes // (1024**2):,} MB * "
            f"{MEMORY_SAFETY_FACTOR}) / {inputs.avg_row_bytes} B / "
            f"{max_concurrent} concurrent"
        ),
    ))

    # ── 6. VERIFY STRATEGY ────────────────────────────────────────────
    # The sink-verify cost grows with rows.  At very large scales the
    # extra Spark read can match the write time.  Pick:
    #   * full sample at any size IF mem allows the re-read DataFrame
    #     to fit comfortably
    #   * sample (read 1% of files via Spark.sample) for huge files
    #   * skip when operator explicitly bypassed
    verify_threshold = max(
        100_000_000,  # 100M absolute minimum -- below this always full
        int(inputs.available_memory_bytes * MEMORY_SAFETY_FACTOR / max(1, inputs.avg_row_bytes)),
    )
    if inputs.total_rows <= verify_threshold:
        verify_strategy = "full"
        verify_sample_pct = 0.0
        decisions.append(AutoPlanDecision(
            knob="verify_strategy",
            chosen="full",
            reason=(
                f"{inputs.total_rows:,} rows fits memory budget "
                f"({verify_threshold:,}) -- full re-read"
            ),
        ))
    else:
        # Adaptive sample: smaller pct for larger row counts so the
        # absolute sample size stays bounded.
        verify_sample_pct = min(0.05, max(0.001, verify_threshold / inputs.total_rows))
        verify_strategy = "sample"
        decisions.append(AutoPlanDecision(
            knob="verify_strategy",
            chosen=f"sample({verify_sample_pct:.3%})",
            reason=(
                f"{inputs.total_rows:,} rows exceeds memory budget "
                f"({verify_threshold:,}) -- {verify_sample_pct:.3%} sample"
            ),
        ))

    if logger:
        for d in decisions:
            logger.info(
                "AutoPlan: %s = %r (because: %s)",
                d.knob, d.chosen, d.reason,
            )

    return AutoPlanOutputs(
        mode=mode,
        max_concurrent_chunks=max_concurrent,
        batch_size=batch_size,
        queue_maxsize=queue_maxsize,
        target_chunk_rows=target_chunk_rows,
        auto_bucket_size=auto_bucket_size,
        verify_strategy=verify_strategy,
        verify_sample_pct=verify_sample_pct,
        decisions=decisions,
    )


def build_inputs_from_probe(
    probe_result: Optional[Dict[str, Any]],
    total_rows: int,
    job_config: Dict[str, Any],
    avg_row_bytes_hint: Optional[int] = None,
    trino_state_hint: Optional[Dict[str, Any]] = None,
) -> AutoPlanInputs:
    """Convenience: build an AutoPlanInputs from the probe result + job
    config + system measurements.

    Pulls operator overrides from job_config so the planner sees them.
    All overrides are OPTIONAL; default None means "AutoPlan decides".
    """
    cardinality = 0
    max_part = 0
    avg_part = 0
    null_pv = False
    if probe_result and probe_result.get("counts"):
        counts = probe_result["counts"]
        cardinality = len(counts)
        if cardinality:
            vals = list(counts.values())
            max_part = max(vals)
            avg_part = sum(vals) // cardinality
        null_pv = probe_result.get("had_null_partition", False)

    sysm = measure_system_resources()
    avg_row_bytes = int(
        avg_row_bytes_hint
        or job_config.get("avg_row_bytes")
        or DEFAULT_AVG_ROW_BYTES
    )

    # 2026-06-20 deep-dive fix: thread partition_column awareness even
    # when probe didn't fire.  Otherwise AutoPlan says "no partition_column
    # configured" when operator DID configure it on the polling row.
    _pcfg = job_config.get("partition_config") or {}
    _pcol = (
        (_pcfg.get("partition_column") if isinstance(_pcfg, dict) else None)
        or job_config.get("partition_column")
        or ""
    )
    _pcol_set = bool(str(_pcol).strip())

    # 2026-06-21 -- trino_profile from polling row or job_config.
    # Accept TRINO_PROFILE (polling row), trino_profile (job json),
    # or env var QS_DEFAULT_TRINO_PROFILE (cluster-wide via helm).
    _profile = (
        job_config.get("trino_profile")
        or job_config.get("TRINO_PROFILE")
        or os.environ.get("QS_DEFAULT_TRINO_PROFILE")
        or DEFAULT_TRINO_PROFILE
    )

    return AutoPlanInputs(
        total_rows=total_rows,
        partition_cardinality=cardinality,
        max_partition_rows=max_part,
        avg_partition_rows=avg_part,
        null_partition_present=null_pv,
        avg_row_bytes=avg_row_bytes,
        cpu_cores=sysm["cpu_cores"],
        available_memory_bytes=sysm["available_memory_bytes"],
        override_max_concurrent=job_config.get("max_concurrent_chunks"),
        override_batch_size=job_config.get("batch_size"),
        override_queue_maxsize=job_config.get("queue_maxsize"),
        override_mode=(
            "single" if str(job_config.get("force_single", "")).strip().upper()
            in {"TRUE", "1", "YES", "Y", "T"}
            else "partition_values" if str(job_config.get("force_partition", "")).strip().upper()
            in {"TRUE", "1", "YES", "Y", "T"}
            else None
        ),
        override_concurrency_ceiling=job_config.get("max_concurrent_chunks_ceiling"),
        partition_column_configured=_pcol_set,
        trino_profile=str(_profile).strip().lower(),
        trino_state_hint=trino_state_hint,
    )
