"""StarburstToFile_OnPrem_Spark — Spark-based on-prem variant.

Thin subclass of ``StarburstFileSparkBase``.  Same shape as the cloud
sibling; credentials come from ``[Starburst-OnPrem]`` (preferred) →
``[Starburst]`` fallback.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.file.starburst_file_spark_base import StarburstFileSparkBase


class StarburstToFile_OnPrem_Spark(StarburstFileSparkBase):
    DATASOURCE_NAME = "ONPREM"
    LOG_PREFIX = "starburst_to_file_onprem_spark"

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """File-workflow on-prem connection -- creds-from-yaml.
        See oncloud_spark sibling for full rationale + precedence."""
        shared = self._shared_starburst_fallback("onprem")
        ini = self.ini_config
        section = "Starburst-OnPrem" if (ini and ini.has_section("Starburst-OnPrem")) else "Starburst"
        if ini and ini.has_section(section):
            ini_user = ini.get(section, "username", fallback="")
            ini_password = ini.get(section, "password", fallback="")
            ini_catalog = ini.get(section, "catalog", fallback="")
            ini_schema = ini.get(section, "schema", fallback="")
        else:
            ini_user = ini_password = ini_catalog = ini_schema = ""

        user = (
            shared.get("user") or ini_user or job_config.get("trino_user", "") or ""
        )
        password = (
            shared.get("password") or ini_password
            or job_config.get("trino_password", "") or ""
        )
        catalog = (
            shared.get("catalog") or ini_catalog or job_config.get("catalog", "") or ""
        )
        schema = (
            shared.get("schema") or ini_schema or job_config.get("schema", "") or ""
        )
        host = job_config["server_name"]
        port = int(job_config["port"])

        missing = []
        if not user:
            missing.append("user (yaml: starburst.user / starburst.onprem.user)")
        if not password:
            missing.append("password (yaml: starburst.password / starburst.onprem.password)")
        if missing:
            raise ValueError(
                f"Spark on-prem connection: missing required credential(s) for "
                f"report_id={job_config.get('report_id')}:\n"
                + "".join(f"  * {m}\n" for m in missing)
                + f"Sources consulted (in priority order):\n"
                f"  1. configs/starburst_config.yaml  -- onprem or root user/password\n"
                f"  2. INI [{section}] in $EXPORT_TOOL_CONFIG_PATH\n"
                f"  3. per-job JSON trino_user / trino_password\n"
                f"  4. env STARBURST_ONPREM_USER / STARBURST_ONPREM_PASSWORD\n"
                f"Fill at least one source."
            )

        jdbc_url = f"jdbc:trino://{host}:{port}/{catalog}/{schema}?SSL=true"
        self.logger.info(
            "Spark on-prem JDBC URL resolved: %s (user source=%s)",
            jdbc_url,
            "YAML" if shared.get("user") else ("INI" if ini_user else "per-job JSON"),
        )
        return {
            "jdbc_url": jdbc_url,
            "user": user,
            "password": password,
            "fetchsize": int(job_config.get("fetchsize", self.DEFAULT_FETCHSIZE)),
        }
