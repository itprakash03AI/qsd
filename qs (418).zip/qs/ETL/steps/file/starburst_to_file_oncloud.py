"""StarburstToFile_OnCloud — Starburst (cloud catalog) → flat file.

Thin subclass of ``StarburstFileBase``.  Inherits the entire extract
strategy:

  * ScanPlan (SINGLE vs PARTITION_VALUES — driven by per-job
    ``partition_config.enabled``).
  * Pre-flight COUNT(*) (G1) and per-partition COUNT(*) (G2) for the
    completeness ledger.
  * Cursor-streamed fetchmany() — peak memory bound to one batch.
  * Bounded concurrency over per-partition chunks (default 2).
  * Per-chunk retry with error categorization.
  * Run-report (HTML + text + email) + RunArtifacts registry so any
    failure leaves a complete forensics file AND wipes all chunks.

Per-job config keys (from the JSON loaded via ``task['sql_query_path']``):

  Required:
      report_id          : str / int
      server_name        : Trino host
      port               : Trino port
      datasource_name    : "CLOUD"  (this class only consumes CLOUD jobs)
      generated_sql      : the SELECT to execute
      output_file_location : output directory
      output_file_name   : output filename (e.g. "report.csv")

  Optional:
      output_file_delimiter : default "|"
      batch_size            : default 100_000
      max_concurrent_chunks : default 2
      max_chunk_retries     : default 2
      fail_on_mismatch      : default True
      ctl_file_format       : passed downstream to CreateControlFile
      zip_format            : passed downstream to CompressFile
      partition_config:
        enabled            : bool (default INFERRED — True iff
                             ``partition_column`` is set; False otherwise.
                             Operator can force-disable by setting False
                             explicitly).
        partition_column   : column to split by (PARTITION_VALUES mode).
                             When unset, the step falls back to SINGLE
                             mode silently -- no failure.
        max_partitions     : safety cap (default 500)

Credentials come from the INI file pointed at by env var
``EXPORT_TOOL_CONFIG_PATH`` (default
``/usr/local/spark/pvc/code/configs/export_tool_config.ini``), section
``[Starburst-Cloud]`` (with fallback to ``[Starburst]`` for back-compat).
"""
from __future__ import annotations

from typing import Any, Dict

from steps.file.starburst_file_base import StarburstFileBase


class StarburstToFile_OnCloud(StarburstFileBase):
    """Starburst → file for the CLOUD datasource."""

    DATASOURCE_NAME = "CLOUD"
    LOG_PREFIX = "starburst_to_file_oncloud"

    def _build_connection_config(self, job_config: Dict[str, Any]) -> Dict[str, Any]:
        """File-workflow cloud connection -- creds-from-yaml.
        See ``starburst_to_file_oncloud_spark`` for the full
        precedence + validation contract."""
        shared = self._shared_starburst_fallback("oncloud")
        ini = self.ini_config
        cloud_section = "Starburst-Cloud"
        fallback = "Starburst"
        section = cloud_section if (ini and ini.has_section(cloud_section)) else fallback

        if ini and ini.has_section(section):
            ini_user = ini.get(section, "username", fallback="")
            ini_password = ini.get(section, "password", fallback="")
            ini_catalog = ini.get(section, "catalog", fallback="")
            ini_schema = ini.get(section, "schema", fallback="")
        else:
            ini_user = ini_password = ini_catalog = ini_schema = ""

        user = (
            shared.get("user") or ini_user or job_config.get("trino_user", "") or ""
        )
        password = (
            shared.get("password") or ini_password
            or job_config.get("trino_password", "") or ""
        )
        catalog = (
            shared.get("catalog") or ini_catalog or job_config.get("catalog", "") or ""
        )
        schema = (
            shared.get("schema") or ini_schema or job_config.get("schema", "") or ""
        )

        missing = []
        if not user:
            missing.append("user (yaml: starburst.user / starburst.oncloud.user)")
        if not password:
            missing.append("password (yaml: starburst.password / starburst.oncloud.password)")
        if missing:
            raise ValueError(
                f"Starburst cloud connection: missing required credential(s) for "
                f"report_id={job_config.get('report_id')}:\n"
                + "".join(f"  * {m}\n" for m in missing)
                + f"Sources consulted (in priority order):\n"
                f"  1. configs/starburst_config.yaml  -- oncloud or root user/password\n"
                f"  2. INI [{section}] in $EXPORT_TOOL_CONFIG_PATH\n"
                f"  3. per-job JSON trino_user / trino_password\n"
                f"  4. env STARBURST_ONCLOUD_USER / STARBURST_ONCLOUD_PASSWORD\n"
                f"Fill at least one source."
            )

        self.logger.info(
            "Starburst cloud connection resolved: host=%s:%s user=%s (user source=%s)",
            job_config["server_name"], job_config["port"], user,
            "YAML" if shared.get("user") else ("INI" if ini_user else "per-job JSON"),
        )
        return {
            "host": job_config["server_name"],
            "port": int(job_config["port"]),
            "user": user,
            "password": password,
            "catalog": catalog,
            "schema": schema,
            "use_ssl": True,
            "verify": False,
            "request_timeout": int(job_config.get("request_timeout", 600)),
        }
