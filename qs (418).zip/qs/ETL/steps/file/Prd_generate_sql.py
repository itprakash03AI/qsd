
import asyncio
import json
import re
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import oracledb
from core_libs.logger.firelogger import CentralizedLogger
from .BaseStep import BaseStep
import yaml
from pathlib import Path

logger = CentralizedLogger(
    log_file="/usr/local/spark/nfs/bcp/batch/logs/generate_sql.log",
    log_level="INFO",
    backup_count=30,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
).get_logger(__name__)


class GenerateSQL(BaseStep):
    """Step to generate SQL query using SQLReportGenerator logic and store it in task."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Initialize database configuration from config
        self.db_config = self.load_oracle_config()

    def load_oracle_config(self, config_path="/usr/local/spark/pvc/code/configs/oracle_config.yaml"):
        # the self was not getting passed here, which caused an error hard to debug.
        # The error was expected str, byte, or PathLike object, not GenerateSQL
        with open(config_path, 'r') as file:
            config = yaml.safe_load(file)
        return config['oracle']

    def _validate_db_config(self) -> bool:
        """Validate database configuration."""
        required_fields = ["user", "password", "dsn"]
        if not self.db_config:
            logger.error("Database configuration is missing.")
            return False
        for field in required_fields:
            if field not in self.db_config:
                logger.error(f"Database configuration is missing required field: {field}")
                return False
        return True

    def _get_database_connection(self) -> oracledb.Connection:
        """Get database connection with decrypted password."""
        decrypted_password = self.db_config["password"]
        return oracledb.connect(
            user=self.db_config["user"],
            password=decrypted_password,
            dsn=self.db_config["dsn"]
        )

    def _get_previous_quarter_end(self, business_date: str) -> str:
        """
        Calculate the end date of the previous quarter based on business_date.

        Args:
            business_date: Date in YYYYMMDD format

        Returns:
            Previous quarter end date in YYYYMMDD format
        """
        try:
            date_obj = datetime.strptime(business_date, "%Y%m%d")

            # Determine current quarter
            current_month = date_obj.month
            current_year = date_obj.year

            # Calculate previous quarter end date
            if current_month <= 3:   # Q1 -> Previous Q4
                prev_quarter_end = datetime(current_year - 1, 12, 31)
            elif current_month <= 6:  # Q2 -> Previous Q1
                prev_quarter_end = datetime(current_year, 3, 31)
            elif current_month <= 9:  # Q3 -> Previous Q2
                prev_quarter_end = datetime(current_year, 6, 30)
            else:  # Q4 -> Previous Q3
                prev_quarter_end = datetime(current_year, 9, 30)

            return prev_quarter_end.strftime("%Y%m%d")
        except ValueError as e:
            logger.error(f"Invalid business_date format: {business_date}. Error: {e}")
            return business_date  # Return original if parsing fails

    def _fetch_run_date(self, cursor: oracledb.Cursor, dag_run_id: str, dag_id: str, business_date: str) -> Optional[str]:
        """Fetch run_date from OTG_AIRFLOW_DAG_RUN table."""
        # Convert business_date from YYYYMMDD to DD-MON-YYYY format for Oracle
        try:
            date_obj = datetime.strptime(business_date, "%Y%m%d")
            oracle_date = date_obj.strftime("%d %b %Y").upper()
        except ValueError as e:
            logger.error(f"Invalid business_date format: {business_date}. Expected YYYYMMDD. Error: {e}")
            return None

        run_date_query = """
            SELECT RUN_DATE
            FROM OTG_AIRFLOW_DAG_RUN
            WHERE FK_DAG_ID = :dag_id
            AND BUSINESS_DATE = TO_DATE(:business_date, 'DD MON YYYY') AND RUN_ID = :dag_run_id
        """
        try:
            cursor.execute(run_date_query, {"dag_run_id": dag_run_id, "dag_id": dag_id, "business_date": oracle_date})
            result = cursor.fetchone()
            if result and result[0]:
                # Convert run_date to YYYYMMDD format if it's a datetime object
                if isinstance(result[0], datetime):
                    return result[0].strftime("%Y%m%d")
                return str(result[0])
            else:
                logger.warning(f"No run_date found for DAG_ID: {dag_id}, BUSINESS_DATE: {oracle_date}, DAG_RUN_ID: {dag_run_id}")
                return None
        except oracledb.DatabaseError as e:
            logger.error(f"Database error fetching run_date: {e}")
            return None

    def _fetch_report_details(self, cursor: oracledb.Cursor, report_id: str) -> Optional[Tuple]:
        """Fetch report details from OTG_REPORT_CONFIG table."""
        report_query = """
            SELECT Reportid, FILE_FORMAT, FILE_NAME, DELIMITER, FILE_LOCATION, CONTROL_TEMPLATE_ID, ZIP_FORMAT
            FROM OTG_REPORT_CONFIG
            WHERE Reportid = :report_id
        """
        cursor.execute(report_query, {"report_id": report_id})
        return cursor.fetchone()

    def _fetch_data_source_mapping(self, cursor: oracledb.Cursor, report_id: str) -> List[Tuple]:
        """Fetch data source mappings for a report."""
        data_source_query = """
            SELECT REPORTID, DATA_SOURCE_ID
            FROM OTG_REPORT_DATA_SOURCE_MAPPING
            WHERE REPORTID = :report_id AND ACTIVE = 'Y'
        """
        cursor.execute(data_source_query, {"report_id": report_id})
        return cursor.fetchall()

    def _fetch_data_source_details(self, cursor: oracledb.Cursor, data_source_id: str) -> Optional[Tuple]:
        """Fetch data source details."""
        data_source_details_query = """
            SELECT DATASOURCE_ID, DATASOURCE_NAME, SERVER_NAME, PORT
            FROM OTG_DATA_SOURCE_DETAILS
            WHERE DATASOURCE_ID = :data_source_id AND ACTIVE = 'Y'
        """
        cursor.execute(data_source_details_query, {"data_source_id": data_source_id})
        return cursor.fetchone()

    def _fetch_table_mapping(self, cursor: oracledb.Cursor, data_source_id: str) -> List[Tuple]:
        """Fetch table mappings for a data source."""
        table_mapping_query = """
            SELECT DATA_SOURCE_ID, TABLE_NAME, TABLE_ALIAS
            FROM OTG_DATA_SOURCE_TABLE_MAPPING
            WHERE DATA_SOURCE_ID = :data_source_id AND ACTIVE = 'Y'
        """
        cursor.execute(table_mapping_query, {"data_source_id": data_source_id})
        return cursor.fetchall()

    def _fetch_column_mappings(self, cursor: oracledb.Cursor, report_id: str) -> List[Tuple]:
        """Fetch column mappings for a report."""
        column_query = """
            SELECT COLUMN_MAPPING, TARGET_COLUMN, SEQ, SOURCE_TABLE
            FROM OTG_REPORT_COLUMN_MAPPING
            WHERE ACTIVE = 'Y' AND FK_REPORTID = :report_id
            ORDER BY SEQ ASC
        """
        cursor.execute(column_query, {"report_id": report_id})
        return cursor.fetchall()

    def _fetch_param_config(self, cursor: oracledb.Cursor, report_id: str) -> List[Tuple]:
        """Fetch parameter configuration for a report."""
        param_query = """
            SELECT OPERATION_KEY, OPERATION_VALUE
            FROM OTG_REPORT_PARAM_CONFIG
            WHERE FK_REPORTID = :report_id AND ACTIVE = 'Y'
        """
        cursor.execute(param_query, {"report_id": report_id})
        return cursor.fetchall()

    def _fetch_control_template(self, cursor: oracledb.Cursor, control_template_id: str) -> List[Tuple]:
        """Fetch control template information."""
        control_template_query = """
            SELECT CONTROL_TEMPLATE_ID, CONTROL_TEMPLATE_FORMAT
            FROM OTG_CONTROL_TEMPLATE
            WHERE CONTROL_TEMPLATE_ID = :control_template_id
        """
        cursor.execute(control_template_query, {"control_template_id": control_template_id})
        return cursor.fetchall()

    def _create_table_alias_mapping(self, table_mappings: List[Tuple]) -> Dict[str, str]:
        """Create a mapping from table alias to table name."""
        return {table_alias: table_name for _, table_name, table_alias in table_mappings}

    def _replace_table_placeholders(self, params: List[Tuple], table_alias_mapping: Dict[str, str]) -> List[Tuple]:
        """Replace {from_table} placeholders in parameter values with actual table names."""
        updated_params = []
        for operation_key, operation_value in params:
            updated_value = operation_value

            # Replace {from_table} with actual table names based on alias mapping
            for table_alias, table_name in table_alias_mapping.items():
                placeholder = f"{{{{{table_alias}}}}}"
                if placeholder in updated_value:
                    updated_value = updated_value.replace(placeholder, table_name)

            # Handle {from_table} placeholder by checking the following table alias
            if "{from_table}" in updated_value:
                pattern = r'\{from_table\}\s+(\w+)'
                matches = re.finditer(pattern, updated_value)

                for match in reversed(list(matches)):
                    table_alias = match.group(1)
                    if table_alias in table_alias_mapping:
                        actual_table_name = table_alias_mapping[table_alias]
                        replacement = f"{actual_table_name} {table_alias}"
                        updated_value = updated_value[:match.start()] + replacement + updated_value[match.end():]
                    else:
                        raise ValueError(
                            f"Table alias '{table_alias}' not found in table_alias_mapping. "
                            f"Available aliases: {list(table_alias_mapping.keys())}"
                        )

            updated_params.append((operation_key, updated_value))
        return updated_params

    def _build_sql_components(self, columns: List[Tuple], params: List[Tuple],
                               business_date_formatted: str, system_entity: str, job_type: str = None) -> Dict[str, Any]:
        """Build SQL components from column mappings and parameters."""
        select_columns = []
        where_clauses = []
        group_by_columns = []
        join_clauses = []
        from_table_name = ""
        group_by_flag = "N"

        # Process columns
        for column_mapping, target_column, seq, source_table in columns:
            if "AGG" in source_table:
                select_columns.append((seq, f'{column_mapping} AS "{target_column}"'))
                group_by_flag = "Y"
            elif "EXPRESSION" in source_table:
                select_columns.append((seq, f'{column_mapping} AS "{target_column}"'))
                group_by_columns.append(column_mapping)
            else:
                select_columns.append((seq, f'{source_table}.{column_mapping} AS "{target_column}"'))
                group_by_columns.append(f'{source_table}.{column_mapping}')

        # Process parameters
        for operation_key, operation_value in params:
            if "JOIN" in operation_key:
                join_clauses.append(operation_value)
            elif "FILTER" in operation_key:
                filter_value = operation_value.replace("{business_date}", business_date_formatted)
                if job_type == "SBTOORACLE":
                    filter_value = filter_value.replace("{system_entity}", f"'{system_entity}'")
                where_clauses.append(filter_value)
            elif "FROM_TABLE" in operation_key:
                from_table_name = operation_value

        return {
            "select_columns": select_columns,
            "where_clauses": where_clauses,
            "group_by_columns": group_by_columns,
            "join_clauses": join_clauses,
            "from_table_name": from_table_name,
            "group_by_flag": group_by_flag
        }

    def _generate_sql(self, sql_components: Dict[str, Any]) -> str:
        """Generate the final SQL query from components."""
        select_columns = sql_components["select_columns"]
        select_columns.sort(key=lambda x: x[0])
        select_clause = ", ".join(col[1] for col in select_columns) if select_columns else "*"

        join_clause = " ".join(sql_components["join_clauses"])
        where_clause = f"WHERE {' AND '.join(sql_components['where_clauses'])}" if sql_components["where_clauses"] else ""

        group_by_clause = ""
        if sql_components["group_by_flag"] == "Y":
            group_by_clause = f"GROUP BY {', '.join(sql_components['group_by_columns'])}"

        sql_parts = [
            f"SELECT {select_clause}",
            f"FROM {sql_components['from_table_name']}",
            join_clause,
            where_clause,
            group_by_clause
        ]

        return " ".join(part for part in sql_parts if part.strip()).strip()

    def _format_file_names(self, file_name: str, file_format: str, ctl_file_format: str,
                            business_date: str, run_date: str, datasource_name: str) -> Tuple[str, str]:
        """Format file names with date placeholders and data source name."""
        cleaned_file_name = re.sub(r"\.(csv|txt|dat|parquet|psv)$", "", file_name, flags=re.IGNORECASE)
        cleaned_file_name = (cleaned_file_name
                             .replace("{business_date}", business_date)
                             .replace("${COB_PREV_EOQ(YYYYMMDD)}", business_date)
                             .replace("{run_date}", run_date)
                             .replace("{me_business_date}", business_date))

        # Replace COB_PREV_EOQ placeholder
        if "${COB_PREV_EOQ(YYYYMMDD)}" in cleaned_file_name:
            # Convert business_date from YYYY-MM-DD to YYYYMMDD for calculation
            business_date_yyyymmdd = business_date.replace('-', '')
            prev_quarter_end = self._get_previous_quarter_end(business_date_yyyymmdd)
            cleaned_file_name = cleaned_file_name.replace("${COB_PREV_EOQ(YYYYMMDD)}", prev_quarter_end)

        cleaned_file_name = f"{cleaned_file_name}_{datasource_name}"

        formatted_ctl = (ctl_file_format
                         .replace("{business_date}", business_date)
                         .replace("${COB_PREV_EOQ(YYYYMMDD)}", business_date)
                         .replace("{run_date}", run_date)
                         .replace("{file_name}", f"{cleaned_file_name}.{file_format}"))

        formatted_ctl = formatted_ctl.replace('\r\n', '\n').replace('\r', '\n')

        return cleaned_file_name, formatted_ctl

    async def fetch_report_metadata(self, report_id: str, business_date: str, dag_run_id: str, dag_id: str,
                                     job_type: str = None, system_entity: str = "") -> Optional[List[Dict[str, Any]]]:
        """Fetch report metadata and generate SQL for the specified report."""
        if not self._validate_db_config():
            return None

        try:
            # Run database operations in executor to avoid blocking
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self._fetch_report_metadata_sync,
                                               report_id, business_date, dag_run_id, dag_id, job_type, system_entity)
        except Exception as e:
            logger.error(f"Error in fetch_report_metadata: {e}")
            return None

    def _fetch_report_metadata_sync(self, report_id: str, business_date: str, dag_run_id: str, dag_id: str,
                                     job_type: str = None, system_entity: str = "") -> Optional[List[Dict[str, Any]]]:
        """Synchronous version of fetch_report_metadata for executor."""
        try:
            with self._get_database_connection() as connection:
                with connection.cursor() as cursor:
                    return self._process_single_report(cursor, report_id, business_date, dag_run_id, dag_id, job_type,
                                                       system_entity)
        except oracledb.DatabaseError as e:
            logger.error(f"Database error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return None

    def _process_single_report(self, cursor: oracledb.Cursor, report_id: str, business_date: str, dag_run_id: str,
                                dag_id: str, job_type: str = None, system_entity: str = "") -> Optional[
        List[Dict[str, Any]]]:

        business_date_formatted = datetime.strptime(business_date, "%Y%m%d").strftime("%Y-%m-%d")

        # Fetch run_date from database
        run_date = self._fetch_run_date(cursor, dag_run_id, dag_id, business_date)
        if not run_date:
            logger.warning(f"Could not fetch run_date from database, using current date as fallback")
            run_date = datetime.now().strftime("%Y%m%d")

        logger.info(f"Using run_date: {run_date} for report {report_id}")

        # Fetch basic report details
        report = self._fetch_report_details(cursor, report_id)
        if not report:
            logger.error(f"No report found for Report ID {report_id}")
            return None

        # Fetch data source mappings
        data_source_mappings = self._fetch_data_source_mapping(cursor, report_id)
        if not data_source_mappings:
            logger.error(f"No data source mappings found for Report ID {report_id}")
            return None

        # Fetch common data
        columns = self._fetch_column_mappings(cursor, report_id)
        if not columns:
            logger.error(f"No column mappings found for Report ID {report_id}")
            return None

        base_params = self._fetch_param_config(cursor, report_id)
        if not base_params:
            logger.error(f"No parameter mappings found for Report ID {report_id}")
            return None

        report_id_val, file_format, file_name, delimiter, file_location, control_template_id, zip_format = report

        templates = self._fetch_control_template(cursor, control_template_id)
        if not templates:
            logger.error(f"No control template found for Template ID {control_template_id}")
            return None

        # Process each data source
        report_metadata_list = []

        for _, data_source_id in data_source_mappings:
            try:
                # Fetch data source details
                data_source_details = self._fetch_data_source_details(cursor, data_source_id)
                if not data_source_details:
                    logger.error(f"No data source details found for Data Source ID {data_source_id}")
                    continue

                _, datasource_name, server_name, port = data_source_details

                # Fetch table mappings for this data source
                table_mappings = self._fetch_table_mapping(cursor, data_source_id)
                if not table_mappings:
                    logger.error(f"No table mappings found for Data Source ID {data_source_id}")
                    continue

                # Create table alias mapping
                table_alias_mapping = self._create_table_alias_mapping(table_mappings)

                # Replace table placeholders in parameters
                updated_params = self._replace_table_placeholders(base_params, table_alias_mapping)

                # Build SQL components and generate SQL
                sql_components = self._build_sql_components(columns, updated_params,
                                                             business_date_formatted, system_entity, job_type)
                generated_sql = self._generate_sql(sql_components)

                # Format file names with data source suffix
                cleaned_file_name, formatted_ctl = self._format_file_names(
                    file_name, file_format, templates[0][1], business_date, run_date, datasource_name
                )

                # Create metadata for this data source
                metadata = {
                    "job_id": f"job_{report_id}",
                    "report_id": report_id_val,
                    "datasource_name": datasource_name,
                    "business_date": business_date,
                    "run_date": run_date,
                    "generated_sql": generated_sql,
                    "output_file_name": f"{cleaned_file_name}.{file_format}",
                    "output_file_type": file_format,
                    "output_file_delimiter": delimiter,
                    "output_file_location": file_location,
                    "ctl_file_format": formatted_ctl,
                    "system_entity": system_entity,
                    "server_name": server_name,
                    "port": port,
                    "zip_format": zip_format
                }

                report_metadata_list.append(metadata)
                logger.info(f"Successfully processed report {report_id} for data source {datasource_name}")

            except Exception as e:
                logger.error(f"Error processing data source {data_source_id} for report {report_id}: {e}")
                continue

        return report_metadata_list if report_metadata_list else None

    async def _execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str,
                             step_name: str, *args, **kwargs) -> str:
        """Generate SQL query using SQLReportGenerator logic and store it in task."""
        report_id = str(task.get("fk_report_id", 0))
        business_date = task["business_date"].replace('-', '')
        dag_run_id = str(task.get("run_id", 0))
        dag_id = task.get("fk_dag_id", "")

        if not dag_id:
            logger.error(f"dag_id not found in task {task.get('task_id')}")
            raise Exception(f"dag_id is required but not found in task")

        run_date = datetime.now().strftime("%Y%m%d")
        file_location = task["file_location"]
        sql_file_location = task["sql_query_path"]

        # Get job type and system entity from task or config
        job_type = task.get("job_type", self.config.get("job_type", ""))
        system_entity = task.get("system_entity", self.config.get("system_entity", ""))

        # Fetch report metadata using the integrated SQLReportGenerator logic
        report_data = await self.fetch_report_metadata(report_id, business_date, dag_run_id, dag_id, job_type, system_entity)

        if not report_data:
            raise Exception(f"Failed to generate SQL for task {task.get('task_id')}")

        # Store the first data source's SQL in task (or handle multiple data sources as needed)
        generated_sql = report_data[0]["generated_sql"]
        task["generated_sql"] = generated_sql

        # Store all data source SQLs in task for later use
        for data in report_data:
            datasource_name = data["datasource_name"]
            task[f"generated_sql_{datasource_name}"] = data["generated_sql"]

        # Write metadata to JSON file
        output_file = sql_file_location
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump({"jobs": report_data}, f, indent=4, ensure_ascii=False)
            logger.info(f"Metadata written to {output_file}")
        except Exception as e:
            logger.error(f"Error writing metadata to JSON: {e}")

        logger.info(f"Generated SQL for task {task.get('task_id')}: {generated_sql}")
        return generated_sql