"""CreateControlFile — emit the CTL (control) file beside the gz payload.

DELIVERY HANDOFF CONTRACT (OpenShift -> Linux Autosys / SFTP)

  OpenShift pods cannot make outbound SFTP connections in this
  deployment.  SFTP is owned by an external Linux host running
  Autosys jobs that invoke existing shell scripts.  The handoff:

    1. This step writes the compressed payload + CTL to the
       configured NFS path (operator's polling row file_location).
    2. The Autosys polling script picks the pair up.
    3. The polling script RECOMPUTES the MD5 of the .gz payload
       and FILLS THE ``{md5_checksum}`` PLACEHOLDER IN THE CTL
       before SFTPing.

  This step therefore writes the CTL with the literal
  ``{md5_checksum}`` placeholder LEFT IN PLACE -- not the
  CompressFile-computed hash -- so the shell script's
  search-and-replace finds it.  The reference's
  ``_process_control_template`` mapped ``'{md5_checksum}'`` to
  itself for exactly this reason.

  Operators who deliver from inside the pod (no Autosys handoff)
  can pass ``inline_checksums=True`` on the task to fill the
  placeholders inline at write-time.

2026-06-12 — merged with the user-supplied refer_createctl.py reference.

FROM THE REFERENCE

  * Per-report deduplication (``processed_report_ids`` set) so a
    repeat polling row doesn't double-write the CTL.
  * Filename normalisation: strip ``_CLOUD`` / ``_ONPREM`` markers
    when looking up the data file on disk OR rendering the CTL.
  * ``_find_data_file`` fallback: try the exact path, the normalised
    path, then scan the directory for any file whose normalised name
    matches — guards against operator naming drift.
  * ``_validate_control_file`` post-write integrity check (file
    exists, non-zero, has content).  Raises on validation failure so
    the standalone's cleanup-on-failure drops the half-baked CTL.
  * Optional CTL zipping (``zip_format`` task knob) via
    ``_zip_control_file`` — the reference's per-job per-CTL archive.

PRESERVED FROM THE EXISTING PIPELINE CONTRACT

  * Reads ``task['compress_results']`` / ``task['compressed_file']``
    (left by CompressFile, hydrated from the sidecar on a fresh
    polling-row task dict).  The reference's "load query JSON and
    iterate jobs[]" path is provided as a FALLBACK when no upstream
    compress_results exist.
  * Returns ``task['ctl_results']`` + ``task['ctl_file']`` for any
    downstream delivery step.
  * Sidecar hydration on entry + persistence at end.
  * ``RunArtifacts.add(CTL)`` for cleanup-on-failure.
  * ``FileRunReport.add_output_file`` integration.
  * ``build_module_logger`` (NEVER ``CentralizedLogger`` per the
    file-flow architecture rule).
  * NO ``/tmp`` fallback in ``_setup_logging`` -- OpenShift pods get
    tiny ephemeral storage; logs MUST land on NFS.
  * Best-effort ``OTG_UPSERT_FILE_LOG_TABLE`` Oracle proc call --
    DB-log failure does NOT fail the step.

CTL TEMPLATE PLACEHOLDERS

    {file_name}       — basename of the gz file
    {file_path}       — absolute path of the gz file
    {total_records}   — consolidated row count
    {md5_checksum}    — MD5 of the .gz file
    {sha256_checksum} — SHA256 of the .gz file
    {timestamp}       — current local timestamp ("YYYY-MM-DD HH:MM:SS")
    {date}            — current local date ("YYYY-MM-DD")
    {year} {month} {day}
"""
from __future__ import annotations

import logging
import os
import sys
import time
import zipfile
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts, backup_if_exists, get_or_create_artifacts,
    save_task_state, hydrate_task_from_sidecar,
)


DEFAULT_CTL_TEMPLATE = (
    "File_Name,{file_name}\n"
    "Extract_Date,{date}\n"
    "Business_Close_Date,{date}\n"
    "Number_Of_Records,{total_records}\n"
    "MD5,{md5_checksum}\n"
    # SHA256 line is intentionally omitted from the default so the
    # Autosys polling script's expected layout (matching the
    # reference's commented-out sha256 line) is preserved.  Operators
    # who need SHA256 emit a custom template via the polling row's
    # ``ctl_file_format`` column.
)


def _normalize_zip_format(zip_format: Any) -> bool:
    """Return True when archiving is requested (zip / gzip / truthy).
    Mirrors the reference's _normalize_zip_format helper."""
    if isinstance(zip_format, bool):
        return zip_format
    if isinstance(zip_format, str):
        zf = zip_format.strip().lower()
        if zf in ("zip", "gzip", "true", "yes", "1"):
            return True
        if zf in ("false", "no", "0", ""):
            return False
    return False


class CreateControlFile(BaseStep):
    """Emit the CTL file per delivered job."""

    LOG_PREFIX = "create_ctl_file"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.artifacts: Optional[RunArtifacts] = None
        self.run_report: Optional[FileRunReport] = None
        # 2026-06-12 — per-report dedup from the reference.  Two polling
        # rows that resolve to the same report_id (e.g. CLOUD + ONPREM
        # for the same canonical deliverable) skip the second CTL
        # emission instead of overwriting.
        self.processed_report_ids: Set[str] = set()

    # ---------- logging (NO /tmp fallback) --------------------------------

    def _setup_logging(self, task: Dict) -> None:
        self.logger = logging.getLogger(f"file_flow.{self.LOG_PREFIX}")
        if self.logger.handlers:
            return
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        self.logger.addHandler(sh)
        log_path = task.get("log_file")
        if not log_path:
            # NO /tmp fallback.  OpenShift pods have tiny ephemeral
            # storage; logs MUST land on the configured NFS path
            # (ETL_LOG_DIR env / YAML / POSIX default).  Missing
            # log_config is a deployment break -- fail loudly so ops
            # sees it instead of silently writing to /tmp.
            from log_config import get_log_dir as _ld
            base = _ld()
            run_id = task.get("run_id", "unknown")
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_path = os.path.join(base, f"file_flow_{self.LOG_PREFIX}_{run_id}_{date_str}.log")
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            self.logger.addHandler(fh)
        except OSError:
            pass

    # ---------- reference helpers -----------------------------------------

    @staticmethod
    def _normalize_filename(filename: str) -> str:
        """Strip ``_CLOUD`` / ``_ONPREM`` markers so multi-source
        deliverables collapse to one canonical name.  Mirrors the
        reference helper."""
        if not filename:
            return ""
        return filename.replace("_CLOUD", "").replace("_ONPREM", "")

    def _find_data_file(self, base_path: str, filename: str) -> Optional[str]:
        """Resolve the actual data file -- try exact path, then the
        normalised variant, then scan the directory for any file whose
        normalised basename matches.  Returns None when nothing matches.

        Mirrors the reference helper -- guards against operator naming
        drift between the source step's output and what CreateControlFile
        receives.
        """
        if not base_path or not filename:
            return None
        full_path = os.path.join(base_path, filename)
        if os.path.exists(full_path):
            return full_path
        normalised = self._normalize_filename(filename)
        nor_path = os.path.join(base_path, normalised)
        if os.path.exists(nor_path):
            return nor_path
        if os.path.isdir(base_path):
            for fname in os.listdir(base_path):
                if self._normalize_filename(fname) == normalised:
                    return os.path.join(base_path, fname)
        return None

    def _is_report_already_processed(self, report_id: str) -> bool:
        """Per-report dedup from the reference."""
        if report_id and report_id in self.processed_report_ids:
            self.logger.info(
                "Report ID %s already processed -- skipping duplicate CTL emit",
                report_id,
            )
            return True
        return False

    def _mark_report_as_processed(self, report_id: str) -> None:
        if report_id:
            self.processed_report_ids.add(report_id)

    @staticmethod
    def _ctl_filename_for(data_filename: str) -> str:
        """Swap the LAST extension for ``.ctl``.

        Mirrors the reference's ``_get_control_filename`` byte-for-byte
        so the Autosys polling shell's file-pair lookup
        (``<base>.gz`` <-> ``<base>.ctl``) still matches.  Examples:

          report.dat.gz   -> report.dat.ctl
          report.zip      -> report.ctl
          report.tar.gz   -> report.tar.ctl

        DO NOT add a second ``splitext`` here -- it would produce
        ``report.ctl`` from ``report.dat.gz`` and break the pair match
        on the Linux side.
        """
        if not data_filename:
            return "report.ctl"
        base, _ = os.path.splitext(data_filename)
        return f"{base}.ctl"

    @staticmethod
    def _render(template: str, replacements: Dict[str, Any]) -> str:
        out = template
        for k, v in replacements.items():
            out = out.replace("{" + k + "}", str(v))
        # Strip lingering _CLOUD / _ONPREM markers if they snuck through
        # the template OR the filename placeholder.
        out = out.replace("_CLOUD.", ".").replace("_ONPREM.", ".")
        return out

    def _validate_control_file(self, ctl_path: str) -> bool:
        """Post-write integrity check from the reference.  File exists,
        non-zero, has readable content."""
        if not os.path.exists(ctl_path):
            self.logger.error("CTL missing on disk: %s", ctl_path)
            return False
        if os.path.getsize(ctl_path) == 0:
            self.logger.error("CTL is empty: %s", ctl_path)
            return False
        try:
            with open(ctl_path, "r", encoding="utf-8") as f:
                if not f.read().strip():
                    self.logger.error("CTL has no content: %s", ctl_path)
                    return False
        except OSError as exc:
            self.logger.error("CTL read failed for %s: %s", ctl_path, exc)
            return False
        return True

    def _zip_control_file(self, ctl_path: str) -> str:
        """Zip the CTL into a sibling ``<base>_ctl.zip``.  Deletes the
        original CTL on success.  Mirrors the reference helper.
        Returns the zip path."""
        if not os.path.exists(ctl_path):
            raise FileNotFoundError(f"CTL not found for zipping: {ctl_path}")
        base, _ = os.path.splitext(ctl_path)
        ctl_zip = f"{base}_ctl.zip"
        with zipfile.ZipFile(ctl_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(ctl_path, arcname=os.path.basename(ctl_path))
        self.logger.info("CTL zipped: %s", ctl_zip)
        try:
            os.remove(ctl_path)
            self.logger.info("Original CTL removed after zip: %s", ctl_path)
        except OSError as exc:
            self.logger.warning(
                "Could not remove original CTL %s: %s", ctl_path, exc,
            )
        return ctl_zip

    # ---------- per-result CTL emission -----------------------------------

    def _build_ctl_for(
        self,
        compress_result: Dict[str, Any],
        consolidation_lookup: Dict[str, Dict[str, Any]],
        task: Dict,
    ) -> Optional[Dict[str, Any]]:
        """Emit the CTL for one compress_result.  Returns the result dict
        or None when the report_id was a duplicate (dedup'd)."""
        report_id = str(compress_result.get("report_id") or "")

        if self._is_report_already_processed(report_id):
            return {
                "report_id": report_id,
                "status": "skipped",
                "message": f"Report ID {report_id} already processed",
            }
        self._mark_report_as_processed(report_id)

        compressed_file = compress_result.get("compressed_file") or ""
        if not compressed_file:
            raise ValueError(
                f"CreateControlFile: report_id={report_id} has empty "
                f"compressed_file"
            )

        # _find_data_file fallback: split into dir + name so the
        # reference's normalisation walk has a chance to find the file
        # even when its name drifted.
        cf_dir = os.path.dirname(compressed_file) or "."
        cf_name = os.path.basename(compressed_file)
        resolved = self._find_data_file(cf_dir, cf_name)
        if not resolved:
            raise ValueError(
                f"CreateControlFile: compressed file not found for "
                f"report_id={report_id}: {compressed_file!r} "
                f"(also checked normalised variant)"
            )
        compressed_file = resolved
        gz_name = os.path.basename(compressed_file)

        # CTL filename derivation matches refer_createctl.py BYTE-FOR-BYTE:
        # use the .gz basename as-is (no pre-normalisation).  The
        # ``_CLOUD`` / ``_ONPREM`` marker -- if present -- carries
        # through to the CTL filename so the Autosys file-pair match
        # still works.  The marker IS stripped from the CTL CONTENT by
        # ``_render`` (mirroring the reference's
        # ``_process_control_template`` ``_CLOUD.`` -> ``.`` pass), so
        # the {file_name} placeholder still renders cleanly.  Pre-
        # normalising the filename here would diverge from the
        # reference's behaviour and could decouple the .gz / .ctl
        # basenames if upstream ever left a marker in.
        ctl_name = self._ctl_filename_for(gz_name)
        ctl_path = os.path.join(os.path.dirname(compressed_file), ctl_name)
        # 2026-06-13 -- back up (or delete) any prior-run CTL at this
        # path before we write the new one.
        backup_if_exists(
            ctl_path,
            backup_ts=getattr(self, "_backup_ts", None),
            mode=getattr(self, "_prior_output_mode", "backup"),
            logger=self.logger,
        )

        cr = consolidation_lookup.get(report_id, {})
        total_records = (
            cr.get("consolidated_rows")
            or compress_result.get("total_records")
            or task.get("totalcount")
            or task.get("consolidated_total")
            or 0
        )
        template = (
            compress_result.get("control_template")
            or cr.get("control_template")
            or DEFAULT_CTL_TEMPLATE
        )

        now = datetime.now()
        replacements = {
            "file_name": gz_name,
            "file_path": compressed_file,
            "total_records": total_records,
            "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
            "date": now.strftime("%Y-%m-%d"),
            "year": now.strftime("%Y"),
            "month": now.strftime("%m"),
            "day": now.strftime("%d"),
        }
        # 2026-06-12 -- {md5_checksum} / {sha256_checksum} are LEFT AS
        # LITERAL PLACEHOLDERS by default so the Autosys / Linux polling
        # script that picks up the file pair can fill them in via its
        # own search-and-replace before the SFTP step.  This mirrors
        # the reference's ``'{md5_checksum}': '{md5_checksum}'`` no-op
        # mapping.  Operators who deliver from inside the pod (no
        # external handoff) can opt into inline fill via
        # ``task['inline_checksums']`` OR per-job ``inline_checksums``.
        inline = bool(
            task.get("inline_checksums")
            or compress_result.get("inline_checksums")
        )
        if inline:
            replacements["md5_checksum"] = compress_result.get("md5_checksum", "")
            replacements["sha256_checksum"] = compress_result.get("sha256_checksum", "")
        content = self._render(template, replacements)
        if not content.endswith("\n"):
            content += "\n"

        start = time.time()
        try:
            with open(ctl_path, "w", encoding="utf-8", newline="") as f:
                f.write(content)
            # 2026-06-21 audit bug #12: defeat NTFS file-name TUNNELING
            # so the .ctl file's creation-time matches THIS run, not the
            # first-ever run.  Without this, operators on Windows see
            # the .dat file with today's ctime + the .ctl file with the
            # FIRST run's ctime -- confusing audit + breaking "is this
            # file fresh?" sanity checks.  Same fix as merge_files +
            # starburst_file_base + consolidate_files.  No-op on POSIX.
            try:
                from steps.file.run_state import force_creation_time_now as _fct
                _fct(ctl_path, logger=self.logger if hasattr(self, "logger") else None)
            except ImportError:
                pass
            except Exception:
                pass  # best-effort, never break the write
        except Exception:
            if os.path.exists(ctl_path):
                try:
                    os.remove(ctl_path)
                except OSError:
                    pass
            raise

        # Reference's post-write integrity check.  Fail HARD on bad CTL
        # so cleanup_on_failure drops the half-baked file -- a downstream
        # delivery step shipping a broken CTL is worse than failing now.
        if not self._validate_control_file(ctl_path):
            try:
                os.remove(ctl_path)
            except OSError:
                pass
            raise ValueError(
                f"CreateControlFile: integrity validation FAILED for {ctl_path}"
            )

        # Optional zip of the CTL (operator can opt in via task['zip_ctl']
        # OR per-job control_template's zip_format).
        zip_request = task.get("zip_ctl") or compress_result.get("zip_format")
        ctl_zip_path = None
        if _normalize_zip_format(zip_request):
            ctl_zip_path = self._zip_control_file(ctl_path)

        duration = time.time() - start
        final_ctl = ctl_zip_path or ctl_path
        self.logger.info(
            "CTL written for report_id=%s: %s | records=%s | %.3fs",
            report_id, final_ctl, total_records, duration,
        )

        return {
            "report_id": report_id,
            "ctl_file": ctl_path,
            "ctl_zip_path": ctl_zip_path,
            "compressed_file": compressed_file,
            "total_records": total_records,
            "validation_passed": True,
            "status": "success",
            "duration_sec": duration,
        }

    # ---------- best-effort DB log (preserved from current) ---------------

    async def _maybe_log_ctl_to_db(
        self, report_id: int, file_name: str, worker_connection_string: str,
    ) -> None:
        if not self.oracle_data_manager:
            return
        try:
            params = [
                {"name": "p_file_name", "value": file_name, "direction": "IN"},
                {"name": "p_report_id", "value": int(report_id), "direction": "IN"},
                {"name": "p_extract_start_date", "value": datetime.now(), "direction": "IN"},
                {"name": "p_extract_end_date", "value": datetime.now(), "direction": "IN"},
            ]
            await self.oracle_data_manager.execute_procedure_async(
                procedure_name="FIRE_DEV.OTG_UPSERT_FILE_LOG_TABLE",
                parameters=params,
                connection_string=worker_connection_string,
            )
            self.logger.info("OTG_FILE_LOG upserted for %s", file_name)
        except Exception as exc:
            self.logger.warning(
                "OTG_FILE_LOG upsert FAILED for %s: %s — continuing", file_name, exc,
            )

    # ---------- step entry ------------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        self.run_report = rr if isinstance(rr, FileRunReport) else None
        # 2026-06-13 -- prior-output handling threaded from standalone.
        self._backup_ts = task.get("backup_ts") or None
        self._prior_output_mode = task.get("prior_output_mode") or "backup"

        # Hydrate from the sidecar so upstream CompressFile state
        # (compress_results / compressed_file / md5_checksum / sha256_checksum)
        # is visible on a fresh polling-row task dict.  Without this the
        # next check raises "CompressFile must run first" even when it did.
        base_dir = task.get("output_dir") or ""
        if not task.get("compress_results") and not task.get("compressed_file"):
            hydrate_task_from_sidecar(task, base_dir, task.get("run_id"), logger=self.logger)

        compress_results: List[Dict[str, Any]] = task.get("compress_results", []) or []
        if not compress_results:
            single = task.get("compressed_file")
            if single:
                compress_results = [{
                    "compressed_file": single,
                    "md5_checksum": task.get("md5_checksum", ""),
                    "sha256_checksum": task.get("sha256_checksum", ""),
                    "report_id": task.get("fk_report_id"),
                    "total_records": task.get("totalcount") or task.get("consolidated_total"),
                    "control_template": task.get("control_template", ""),
                }]
            else:
                # 2026-06-13 — UNCOMPRESSED workflow fallback.
                # The user's existing OG ETL flow doesn't run CompressFile
                # for some reports: the polling rows only include the
                # extract steps + ConsolidateFiles + CreateControlFile,
                # and the control_template references `.dat` directly
                # (no `.gz` / `.zip`).  refer_createctl.py builds the
                # CTL straight off the original .dat in this mode --
                # MD5 is of the .dat, no archive is produced.
                #
                # Fall back to consolidation_results / consolidated_file
                # so CreateControlFile produces a usable CTL when no
                # compression was wanted; the {md5_checksum} placeholder
                # in the template stays LITERAL for the downstream
                # Autosys SFTP shell to fill (the existing contract).
                consolidation_results = task.get("consolidation_results", []) or []
                if consolidation_results:
                    compress_results = []
                    for cr in consolidation_results:
                        compress_results.append({
                            "compressed_file": cr.get("consolidated_file") or "",
                            "md5_checksum": "",
                            "sha256_checksum": "",
                            "report_id": cr.get("report_id") or task.get("fk_report_id"),
                            "total_records": cr.get("consolidated_rows")
                                or task.get("consolidated_total"),
                            "control_template": cr.get("control_template")
                                or task.get("control_template", ""),
                        })
                    self.logger.info(
                        "CreateControlFile: no compress_results -- falling back "
                        "to consolidation_results (UNCOMPRESSED workflow; CTL "
                        "will reference .dat directly).  %d entries.",
                        len(compress_results),
                    )
                else:
                    single_dat = task.get("consolidated_file")
                    if single_dat:
                        # Last-resort fallback: job_results may carry the
                        # per-job control_template (the polling row's
                        # ctl_file_format).  Pull from the first job that
                        # matches our report_id, otherwise the task root.
                        jrs = task.get("job_results", []) or []
                        rid = task.get("fk_report_id")
                        tmpl = task.get("control_template", "")
                        for jr in jrs:
                            if jr.get("report_id") == rid and jr.get("control_template"):
                                tmpl = jr["control_template"]
                                break
                        if not tmpl and jrs and jrs[0].get("control_template"):
                            tmpl = jrs[0]["control_template"]
                        compress_results = [{
                            "compressed_file": single_dat,
                            "md5_checksum": "",
                            "sha256_checksum": "",
                            "report_id": rid,
                            "total_records": task.get("totalcount")
                                or task.get("consolidated_total"),
                            "control_template": tmpl,
                        }]
                        self.logger.info(
                            "CreateControlFile: no compress_results, no "
                            "consolidation_results -- falling back to "
                            "task['consolidated_file'] (UNCOMPRESSED workflow)."
                        )
                    else:
                        raise ValueError(
                            "CreateControlFile: no compress_results, no "
                            "compressed_file, no consolidation_results, AND "
                            "no consolidated_file on task -- nothing to "
                            "build a CTL for.  At least one of CompressFile "
                            "or ConsolidateFiles must have produced an output."
                        )

        # Look up consolidation results by report_id for total_records / template.
        consolidation_lookup: Dict[str, Dict[str, Any]] = {
            str(c.get("report_id")): c
            for c in (task.get("consolidation_results", []) or [])
        }

        results: List[Dict[str, Any]] = []
        unique_report_ids = sorted({
            str(cr.get("report_id") or "")
            for cr in compress_results
        })
        self.logger.info(
            "CreateControlFile: %d compress_result(s) covering %d unique report_id(s): %s",
            len(compress_results), len(unique_report_ids), unique_report_ids,
        )

        for cr in compress_results:
            res = self._build_ctl_for(cr, consolidation_lookup, task)
            if not res:
                continue
            if res.get("status") == "skipped":
                results.append(res)
                continue
            ctl_target = res.get("ctl_zip_path") or res.get("ctl_file")
            if ctl_target:
                self.artifacts.add(ctl_target, RunArtifacts.CTL)
                if self.run_report:
                    self.run_report.add_output_file(ctl_target)
            results.append(res)

            # DB log — best-effort
            try:
                rid = int(cr.get("report_id") or task.get("fk_report_id") or 0)
            except (TypeError, ValueError):
                rid = 0
            if rid:
                gz_name = os.path.basename(res["compressed_file"])
                norm = self._normalize_filename(gz_name)
                await self._maybe_log_ctl_to_db(rid, norm, worker_connection_string)

        # Run summary (mirrors the reference's three-bucket log line).
        succeeded = [r for r in results if r.get("status") == "success"]
        skipped = [r for r in results if r.get("status") == "skipped"]
        failed = [r for r in results if r.get("status") == "failed"]
        self.logger.info(
            "CreateControlFile complete: %d succeeded, %d skipped, %d failed",
            len(succeeded), len(skipped), len(failed),
        )

        task["ctl_results"] = results
        task["ctl_file"] = succeeded[0]["ctl_file"] if succeeded else ""
        task["artifact_paths"] = self.artifacts.snapshot()

        sidecar_dir = task.get("output_dir") or (
            os.path.dirname(succeeded[0]["ctl_file"]) if succeeded else ""
        )
        if sidecar_dir:
            save_task_state(task, sidecar_dir, task.get("run_id"), logger=self.logger)
        if self.run_report:
            self.run_report.write()

        return results
