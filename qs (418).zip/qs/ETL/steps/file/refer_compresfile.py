import os
import gzip
import zipfile
import tarfile
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from core_libs.logger.firelogger import CentralizedLogger
from steps.BaseStep import BaseStep

logger = CentralizedLogger(
    log_file="/usr/local/spark/nfs/bcp/batch/logs/compress_file_{date_str}.log",
    log_level="INFO",
    backup_count=30,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
).get_logger(__name__)

class CompressFile(BaseStep):
    """Step to compress data files and control files."""
    def __init__(self):
        super().__init__()
        self.supported_formats = ['gzip', 'zip', 'tar', 'tar.gz']

    def _get_compression_format(self, task: Dict) -> str:
        """Get compression format from task configuration"""
        return task.get('compression_format', 'gzip').lower()

    def _compress_with_gzip(self, source_file: str, compressed_file: str) -> Dict[str, Any]:
        """Compress file using gzip"""
        try:
            start_time = time.time()
            original_size = os.path.getsize(source_file)

            with open(source_file, 'rb') as f_in:
                with gzip.open(compressed_file, 'wb') as f_out:
                    f_out.writelines(f_in)

            compressed_size = os.path.getsize(compressed_file)
            compression_ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
            end_time = time.time()

            logger.info(
                f"GZIP compression completed: {source_file} -> {compressed_file} | "
                f"Original: {original_size:,} bytes | Compressed: {compressed_size:,} bytes | "
                f"Ratio: {compression_ratio:.1f}% | Time: {end_time - start_time:.2f}s"
            )
            return {
                'method': 'gzip',
                'original_size': original_size,
                'compressed_size': compressed_size,
                'compression_ratio': compression_ratio,
                'time_taken': end_time - start_time
            }

        except Exception as e:
            logger.error(f"GZIP compression failed for {source_file}: {e}")
            raise

    def _compress_with_zip(self, source_files: List[str], compressed_file: str) -> Dict[str, Any]:
        """Compress files using ZIP"""
        try:
            start_time = time.time()
            total_original_size = 0

            with zipfile.ZipFile(compressed_file, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
                for source_file in source_files:
                    if os.path.exists(source_file):
                        file_size = os.path.getsize(source_file)
                        total_original_size += file_size

                        # Add file to zip with just the filename (not full path)
                        arcname = os.path.basename(source_file)
                        zipf.write(source_file, arcname)
                        logger.debug(f"Added {source_file} to ZIP as {arcname}")
                    else:
                        logger.warning(f"File not found for ZIP compression: {source_file}")

            compressed_size = os.path.getsize(compressed_file)
            compression_ratio = (1 - compressed_size / total_original_size) * 100 if total_original_size > 0 else 0
            end_time = time.time()

            logger.info(
                f"ZIP compression completed: {len(source_files)} files -> {compressed_file} | "
                f"Original: {total_original_size:,} bytes | Compressed: {compressed_size:,} bytes | "
                f"Ratio: {compression_ratio:.1f}% | Time: {end_time - start_time:.2f}s"
            )
            return {
                'method': 'zip',
                'files_compressed': len(source_files),
                'original_size': total_original_size,
                'compressed_size': compressed_size,
                'compression_ratio': compression_ratio,
                'time_taken': end_time - start_time
            }

        except Exception as e:
            logger.error(f"ZIP compression failed: {e}")
            raise

    def _compress_with_tar(self, source_files: List[str], compressed_file: str, use_gzip: bool = False) -> Dict[str, Any]:
        """Compress files using TAR (optionally with gzip)"""
        try:
            start_time = time.time()
            total_original_size = 0
            mode = 'w:gz' if use_gzip else 'w'

            with tarfile.open(compressed_file, mode) as tar:
                for source_file in source_files:
                    if os.path.exists(source_file):
                        file_size = os.path.getsize(source_file)
                        total_original_size += file_size

                        # Add file to tar with just the filename (not full path)
                        arcname = os.path.basename(source_file)
                        tar.add(source_file, arcname=arcname)
                        logger.debug(f"Added {source_file} to TAR as {arcname}")
                    else:
                        logger.warning(f"File not found for TAR compression: {source_file}")

            compressed_size = os.path.getsize(compressed_file)
            compression_ratio = (1 - compressed_size / total_original_size) * 100 if total_original_size > 0 else 0
            end_time = time.time()

            method = 'tar.gz' if use_gzip else 'tar'
            logger.info(
                f"{method.upper()} compression completed: {len(source_files)} files -> {compressed_file} | "
                f"Original: {total_original_size:,} bytes | Compressed: {compressed_size:,} bytes | "
                f"Ratio: {compression_ratio:.1f}% | Time: {end_time - start_time:.2f}s"
            )
            return {
                'method': method,
                'files_compressed': len(source_files),
                'original_size': total_original_size,
                'compressed_size': compressed_size,
                'compression_ratio': compression_ratio,
                'time_taken': end_time - start_time
            }

        except Exception as e:
            logger.error(f"TAR compression failed: {e}")
            raise

    def _get_compressed_filename(self, base_filename: str, compression_format: str) -> str:
        """Generate compressed filename based on format"""
        base_path = Path(base_filename)
        base_name = base_path.stem

        if compression_format == 'gzip':
            return f"{base_filename}.gz"
        elif compression_format == 'zip':
            return f"{base_name}.zip"
        elif compression_format == 'tar':
            return f"{base_name}.tar"
        elif compression_format == 'tar.gz':
            return f"{base_name}.tar.gz"
        else:
            return f"{base_filename}.gz"  # Default to gzip

    def _compress_single_report(self, control_file_result: Dict[str, Any], compression_format: str) -> Dict[str, Any]:
        """Compress files for a single report"""
        try:
            report_id = control_file_result['report_id']
            logger.info(f"Compressing files for Report ID {report_id} using {compression_format}")

            # Validate input
            if control_file_result.get('status') != 'success':
                logger.error(f"Cannot compress files for failed control file creation: Report ID {report_id}")
                return {
                    'report_id': report_id,
                    'status': 'failed',
                    'error': 'Control file creation failed, cannot compress'
                }

            # Get file paths
            data_file_path = control_file_result.get('data_file_path')
            control_file_path = control_file_result.get('control_file_path')

            # Validate files exist
            files_to_compress = []
            if data_file_path and os.path.exists(data_file_path):
                files_to_compress.append(data_file_path)
            else:
                logger.error(f"Data file not found for Report ID {report_id}: {data_file_path}")

            if control_file_path and os.path.exists(control_file_path):
                files_to_compress.append(control_file_path)
            else:
                logger.warning(f"Control file not found for Report ID {report_id}: {control_file_path}")

            if not files_to_compress:
                return {
                    'report_id': report_id,
                    'status': 'failed',
                    'error': 'No files found to compress'
                }

            # Generate compressed filename
            base_filename = os.path.splitext(data_file_path)[0] if data_file_path else f"report_{report_id}"
            compressed_filename = self._get_compressed_filename(base_filename, compression_format)
            compressed_file_path = os.path.join(os.path.dirname(files_to_compress[0]),
                                                  os.path.basename(compressed_filename))

            # Perform compression based on format
            compression_stats = {}

            if compression_format == 'gzip' and len(files_to_compress) == 1:
                # GZIP can only compress single files
                compression_stats = self._compress_with_gzip(files_to_compress[0], compressed_file_path)
            elif compression_format == 'zip':
                compression_stats = self._compress_with_zip(files_to_compress, compressed_file_path)
            elif compression_format == 'tar':
                compression_stats = self._compress_with_tar(files_to_compress, compressed_file_path, use_gzip=False)
            elif compression_format == 'tar.gz':
                compression_stats = self._compress_with_tar(files_to_compress, compressed_file_path, use_gzip=True)
            else:
                raise ValueError(f"Unsupported compression format: {compression_format}")

            # Remove original files after successful compression (optional)
            cleanup_enabled = True  # This could be configurable
            if cleanup_enabled:
                for file_path in files_to_compress:
                    try:
                        os.remove(file_path)
                        logger.info(f"Removed original file: {file_path}")
                    except Exception as e:
                        logger.warning(f"Could not remove original file {file_path}: {e}")

            return {
                'report_id': report_id,
                'compressed_file_path': compressed_file_path,
                'original_files': files_to_compress,
                'compression_stats': compression_stats,
                'status': 'success'
            }

        except Exception as e:
            logger.error(f"Error compressing files for Report ID {control_file_result.get('report_id', 'Unknown')}: {e}")
            return {
                'report_id': control_file_result.get('report_id', 'Unknown'),
                'status': 'failed',
                'error': str(e)
            }

    def validate_compressed_file(self, compressed_file_path: str, compression_format: str) -> bool:
        """Validate compressed file integrity"""
        try:
            if not os.path.exists(compressed_file_path):
                logger.error(f"Compressed file does not exist: {compressed_file_path}")
                return False

            # Check file size
            file_size = os.path.getsize(compressed_file_path)
            if file_size == 0:
                logger.error(f"Compressed file is empty: {compressed_file_path}")
                return False

            # Test file integrity based on format
            if compression_format == 'gzip':
                with gzip.open(compressed_file_path, 'rb') as f:
                    f.read(1)  # Try to read first byte
            elif compression_format == 'zip':
                with zipfile.ZipFile(compressed_file_path, 'r') as zipf:
                    zipf.testzip()  # Test ZIP integrity
            elif compression_format in ['tar', 'tar.gz']:
                mode = 'r:gz' if compression_format == 'tar.gz' else 'r'
                with tarfile.open(compressed_file_path, mode) as tar:
                    tar.getnames()  # Try to read file list

            logger.debug(f"Compressed file validation passed: {compressed_file_path}")
            return True

        except Exception as e:
            logger.error(f"Compressed file validation failed for {compressed_file_path}: {e}")
            return False

    async def _execute_step(self, task: Dict, worker_connection_string: str,
                             step_name: str, *args, dest_connection_string: str,
                             **kwargs) -> List[Dict[str, Any]]:
        """Execute file compression step."""
        logger.info("Starting CompressFile step execution")

        try:
            # Get control file results from previous step
            control_file_results = kwargs.get('control_file_results', [])

            if not control_file_results:
                logger.warning("No control file results provided for compression")
                return []

            # Get compression format from task
            compression_format = self._get_compression_format(task)

            if compression_format not in self.supported_formats:
                logger.error(f"Unsupported compression format: {compression_format}")
                raise ValueError(f"Unsupported compression format: {compression_format}")

            logger.info(f"Compressing files using {compression_format} format")

            # Filter successful control file results
            successful_control_files = [r for r in control_file_results if r.get('status') == 'success']

            if not successful_control_files:
                logger.warning("No successful control file results found for compression")
                return []

            logger.info(f"Processing {len(successful_control_files)} successful control file results")

            # Compress files for each report
            compression_results = []
            for control_file_result in successful_control_files:
                result = self._compress_single_report(control_file_result, compression_format)

                # Validate compressed file
                if result.get('status') == 'success':
                    compressed_file_path = result.get('compressed_file_path')
                    if compressed_file_path and self.validate_compressed_file(compressed_file_path,
                                                                               compression_format):
                        result['validation_passed'] = True
                        logger.info(f"Compression validation passed for Report ID {result['report_id']}")
                    else:
                        result['validation_passed'] = False
                        result['status'] = 'failed'
                        result['error'] = 'Compressed file validation failed'
                        logger.error(f"Compression validation failed for Report ID {result['report_id']}")

                compression_results.append(result)

            # Log summary
            successful_compressions = [r for r in compression_results if r.get('status') == 'success']
            failed_compressions = [r for r in compression_results if r.get('status') == 'failed']

            logger.info(
                f"File compression completed: {len(successful_compressions)} successful, "
                f"{len(failed_compressions)} failed out of {len(compression_results)} total files"
            )

            # Log compression statistics
            total_original_size = 0
            total_compressed_size = 0

            for result in successful_compressions:
                stats = result.get('compression_stats', {})
                total_original_size += stats.get('original_size', 0)
                total_compressed_size += stats.get('compressed_size', 0)

                logger.info(
                    f"Compressed: {result['compressed_file_path']} for Report ID {result['report_id']} "
                    f"(Ratio: {stats.get('compression_ratio', 0):.1f}%)"
                )

            if total_original_size > 0:
                overall_ratio = (1 - total_compressed_size / total_original_size) * 100
                logger.info(
                    f"Overall compression: {total_original_size:,} -> {total_compressed_size:,} bytes "
                    f"({overall_ratio:.1f}% reduction)"
                )

            return compression_results

        except Exception as e:
            logger.error(f"Error in CompressFile execution: {e}")
            raise