"""Variance check vs previous COB run — alert support team on row-count drift.

2026-06-18 -- new step ``VarianceCheckAgainstPreviousCobRun`` for the
file workflow.  Strategic placement: BETWEEN ``ConsolidateFiles`` (so
the total row count is final, cross-source merged) and
``CreateControlFile`` (so the alert / breach status is captured in the
run-report before the CTL is published).

Contract
--------
1. Pull current run's total row count from ``task["totalcount"]`` (set
   by the upstream ConsolidateFiles step) -- single source of truth.
2. Call ``PKG_OTG_VARIANCE.CHECK_VARIANCE`` to find the most recent
   COMPLETED run for the same FK_DAG_ID + FK_REPORT_ID BEFORE today's
   business_date, compute variance %, and classify the status.
3. Route on status:
     UNDER_THRESHOLD  -> log OK, optionally email when
                         EMAIL_ON_VARIANCE_PASS=TRUE.
     BREACHED         -> log WARN + alert email to support team.
                         Hard-fail the workflow IFF
                         FAIL_ON_VARIANCE_BREACH=TRUE.
     NO_PREVIOUS_RUN  -> log INFO, optional baseline-established email.
     PREV_ZERO        -> log WARN, info email (variance % undefined).
4. Stash status on the task so downstream steps + the run-report HTML
   render it.

Polling-row knobs (added to _POLLING_ROW_OVERLAYS in starburst_file_base):
  VARIANCE_THRESHOLD_PCT       float, default 5.0  (alert threshold)
  VARIANCE_EMAIL_TO            str,  default = EMAIL_TO (alert recipients)
  EMAIL_ON_VARIANCE_PASS       bool, default FALSE (info email on success)
  FAIL_ON_VARIANCE_BREACH      bool, default FALSE (alert-only; workflow continues)

This is alert tooling, not data-completeness enforcement.  The default is
"continue the workflow + tell humans."  Operators set FAIL_ON_VARIANCE_BREACH
when they want variance to gate downstream (e.g. published-API freshness).
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from steps.BaseStep import BaseStep


class VarianceCheckAgainstPreviousCobRun(BaseStep):
    """ETL step: compare current row count against the previous COB run."""

    STATUS_UNDER = "UNDER_THRESHOLD"
    STATUS_BREACH = "BREACHED"
    STATUS_NO_PREV = "NO_PREVIOUS_RUN"
    STATUS_PREV_ZERO = "PREV_ZERO"

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> Any:
        run_id = task.get("run_id")
        run_detail_id = task.get("run_detail_id")
        dag_id = task.get("fk_dag_id") or task.get("dag_id")
        report_id = task.get("fk_report_id") or task.get("report_id")
        business_date = task.get("business_date") or task.get("BUSINESS_DATE")
        curr_count = self._coerce_int(task.get("totalcount"))

        threshold = float(task.get("variance_threshold_pct") or 5.0)

        self.logger.info(
            "VarianceCheck start: run_id=%s dag=%s report=%s "
            "business_date=%s curr_count=%s threshold=%s%%",
            run_id, dag_id, report_id, business_date, curr_count, threshold,
        )

        # Call the stored proc.  Worker connection string is the Oracle
        # metadata DB -- same connection that PKG_OTG_BATCH_CONTROL.ETL_Batch_UPDATE
        # uses everywhere else in this codebase.
        proc_result = await self.oracle_data_manager.execute_procedure_async(
            procedure_name="PKG_OTG_VARIANCE.CHECK_VARIANCE",
            parameters=[
                {"name": "p_run_id",       "value": run_id,             "direction": "IN",  "type_hint": "NUMBER"},
                {"name": "p_dag_id",       "value": str(dag_id or ""),  "direction": "IN",  "type_hint": "VARCHAR2"},
                {"name": "p_report_id",    "value": report_id,          "direction": "IN",  "type_hint": "NUMBER"},
                {"name": "p_business_date","value": str(business_date or ""), "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_variance_threshold_pct", "value": threshold, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_curr_count",   "value": None, "direction": "OUT", "type_hint": "NUMBER"},
                {"name": "p_prev_count",   "value": None, "direction": "OUT", "type_hint": "NUMBER"},
                {"name": "p_prev_business_date", "value": None, "direction": "OUT", "type_hint": "VARCHAR2"},
                {"name": "p_variance_pct", "value": None, "direction": "OUT", "type_hint": "NUMBER"},
                {"name": "p_status",       "value": None, "direction": "OUT", "type_hint": "VARCHAR2"},
                {"name": "p_message",      "value": None, "direction": "OUT", "type_hint": "VARCHAR2"},
            ],
            connection_string=worker_connection_string,
        )
        out = (proc_result or {}).get("out_parameters", {}) or {}

        status = (out.get("p_status") or "").upper().strip() or self.STATUS_NO_PREV
        message = out.get("p_message") or ""
        prev_count = self._coerce_int(out.get("p_prev_count"))
        prev_date = out.get("p_prev_business_date") or ""
        variance_pct = out.get("p_variance_pct")
        # Proc may return curr_count too; prefer task's value (single source).
        proc_curr = self._coerce_int(out.get("p_curr_count"))
        if proc_curr is not None and curr_count is None:
            curr_count = proc_curr

        # Stash for run-report + downstream.
        task["variance_status"] = status
        task["variance_pct"] = variance_pct
        task["variance_prev_count"] = prev_count
        task["variance_prev_business_date"] = prev_date
        task["variance_threshold_pct"] = threshold

        # Route by status.
        breach = (status == self.STATUS_BREACH)
        ok = (status == self.STATUS_UNDER)
        no_prev = (status == self.STATUS_NO_PREV)
        prev_zero = (status == self.STATUS_PREV_ZERO)
        email_on_pass = self._coerce_bool(task.get("email_on_variance_pass"), default=False)
        fail_on_breach = self._coerce_bool(task.get("fail_on_variance_breach"), default=False)

        if breach:
            self.logger.warning(
                "VarianceCheck BREACHED: curr=%s prev=%s (date=%s) "
                "variance=%s%% > threshold=%s%% -- alerting support team.  %s",
                curr_count, prev_count, prev_date, variance_pct, threshold, message,
            )
            self._send_variance_email(
                task, subject_tag="ALERT",
                status=status, curr_count=curr_count, prev_count=prev_count,
                prev_date=prev_date, variance_pct=variance_pct,
                threshold=threshold, message=message,
            )
            if fail_on_breach:
                raise RuntimeError(
                    f"Variance breach: {variance_pct}% > threshold {threshold}% "
                    f"(curr={curr_count} vs prev={prev_count} on {prev_date}).  "
                    f"FAIL_ON_VARIANCE_BREACH=TRUE -> halting workflow."
                )
        elif ok:
            self.logger.info(
                "VarianceCheck OK: curr=%s prev=%s (date=%s) variance=%s%% "
                "within threshold=%s%%",
                curr_count, prev_count, prev_date, variance_pct, threshold,
            )
            if email_on_pass:
                self._send_variance_email(
                    task, subject_tag="OK",
                    status=status, curr_count=curr_count, prev_count=prev_count,
                    prev_date=prev_date, variance_pct=variance_pct,
                    threshold=threshold, message=message,
                )
        elif no_prev:
            self.logger.info(
                "VarianceCheck NO_PREVIOUS_RUN: baseline established at "
                "curr_count=%s for dag=%s report=%s -- no prior COB to "
                "compare", curr_count, dag_id, report_id,
            )
            if email_on_pass:
                self._send_variance_email(
                    task, subject_tag="BASELINE",
                    status=status, curr_count=curr_count, prev_count=None,
                    prev_date="", variance_pct=None, threshold=threshold,
                    message=message or "First run -- baseline established",
                )
        elif prev_zero:
            self.logger.warning(
                "VarianceCheck PREV_ZERO: previous COB count was 0 -- "
                "variance %% undefined.  curr=%s prev=%s (date=%s).  %s",
                curr_count, prev_count, prev_date, message,
            )
            self._send_variance_email(
                task, subject_tag="INFO",
                status=status, curr_count=curr_count, prev_count=prev_count,
                prev_date=prev_date, variance_pct=None, threshold=threshold,
                message=message,
            )
        else:
            self.logger.warning(
                "VarianceCheck UNKNOWN status %r -- treating as advisory.  %s",
                status, message,
            )

        return {
            "status": status,
            "curr_count": curr_count,
            "prev_count": prev_count,
            "prev_business_date": prev_date,
            "variance_pct": variance_pct,
            "threshold_pct": threshold,
            "message": message,
        }

    # ── Helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _coerce_int(v: Any) -> Optional[int]:
        if v is None or v == "":
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _coerce_bool(v: Any, default: bool = False) -> bool:
        if isinstance(v, bool):
            return v
        if v is None:
            return default
        s = str(v).strip().upper()
        if s in {"TRUE", "Y", "YES", "1", "T"}:
            return True
        if s in {"FALSE", "N", "NO", "0", "F"}:
            return False
        return default

    def _send_variance_email(
        self, task: Dict, *,
        subject_tag: str, status: str,
        curr_count: Optional[int], prev_count: Optional[int],
        prev_date: str, variance_pct: Any, threshold: float, message: str,
    ) -> None:
        """Send a variance email using the file_run_report mailer + the
        polling-row SMTP config.  Falls back to a no-op WARN if SMTP
        isn't configured (operator chose not to wire it)."""
        try:
            recipients = (
                task.get("variance_email_to")
                or task.get("VARIANCE_EMAIL_TO")
                or task.get("email_to")
                or task.get("EMAIL_TO")
            )
            if not recipients:
                self.logger.warning(
                    "VarianceCheck: no recipients configured "
                    "(VARIANCE_EMAIL_TO or EMAIL_TO in polling row) "
                    "-- skipping email; status=%s", status,
                )
                return

            dag_id = task.get("fk_dag_id") or task.get("dag_id") or "?"
            report_id = task.get("fk_report_id") or task.get("report_id") or "?"
            business_date = task.get("business_date") or "?"

            subject = (
                f"[QS Variance {subject_tag}] {dag_id} report_id={report_id} "
                f"{business_date}: {status}"
            )
            body_lines = [
                f"DAG_ID:        {dag_id}",
                f"REPORT_ID:     {report_id}",
                f"BUSINESS_DATE: {business_date}",
                f"STATUS:        {status}",
                f"",
                f"Current count:  {self._fmt_int(curr_count)}",
                f"Previous count: {self._fmt_int(prev_count)} "
                f"(business_date={prev_date or 'n/a'})",
                f"Variance:       {self._fmt_pct(variance_pct)} "
                f"(threshold = {threshold}%)",
                f"",
                f"Message: {message}",
                f"",
                f"-- QueryStudio file flow (auto-generated)",
            ]
            body = "\n".join(body_lines)

            # Delegate to FileRunReport.send_email so we share the same
            # SMTP plumbing as the upstream START/FINISH emails.
            from steps.file.run_report import FileRunReport
            rr = FileRunReport(
                output_dir=task.get("output_dir") or "", logger=self.logger,
            )
            email_cfg = self._build_email_config(task)
            email_cfg["email_to"] = recipients
            email_cfg["email_subject"] = subject
            rr.send_email(email_cfg, body)
            self.logger.info(
                "VarianceCheck email sent to %s (subject=%s)",
                recipients, subject,
            )
        except Exception as exc:
            # Email failure is never fatal -- the workflow still ran.
            self.logger.warning(
                "VarianceCheck email failed (non-fatal): %s", exc,
            )

    @staticmethod
    def _fmt_int(v: Optional[int]) -> str:
        return f"{v:,}" if isinstance(v, int) else "n/a"

    @staticmethod
    def _fmt_pct(v: Any) -> str:
        if v is None:
            return "n/a"
        try:
            return f"{float(v):.2f}%"
        except (TypeError, ValueError):
            return str(v)

    @staticmethod
    def _build_email_config(task: Dict) -> Dict[str, Any]:
        """Pull SMTP knobs out of the polling row (same pattern as
        send_email_notifications.py)."""
        cfg: Dict[str, Any] = {}
        for src, dst in (
            ("SEND_EMAIL", "send_email"),
            ("SMTP_HOST", "smtp_host"),
            ("SMTP_PORT", "smtp_port"),
            ("SMTP_USER", "smtp_user"),
            ("SMTP_PASSWORD", "smtp_password"),
            ("SMTP_USE_TLS", "smtp_use_tls"),
            ("EMAIL_FROM", "email_from"),
        ):
            v = task.get(src) or task.get(src.lower())
            if v not in (None, "", 0):
                cfg[dst] = v
        return cfg
