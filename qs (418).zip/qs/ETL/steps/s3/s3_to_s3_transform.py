"""
S3 → S3 Transform step.
Reads from source S3 (parquet or Iceberg), applies transform rules
(WHERE, SELECT, CAST, DEDUP), writes to destination S3.
Transform rules mirror QueryStudio's generic_etl.py pattern.
"""
from datetime import datetime
from typing import Dict, Any, List
from steps.s3.s3_base_step import S3BaseStep


class S3ToS3Transform(S3BaseStep):
    """Read from S3, apply transforms, write to S3."""

    LOG_PREFIX = "s3_to_s3_transform"

    REQUIRED_FIELDS = [
        's3_access_key', 's3_secret_key',
        'source_bucket', 'source_prefix',
        'dest_bucket', 'dest_prefix',
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        source_path = f"s3a://{config['source_bucket']}/{config['source_prefix']}"
        dest_path = f"s3a://{config['dest_bucket']}/{config['dest_prefix']}"
        source_format = config.get('source_format', 'parquet')
        dest_format = config.get('dest_format', 'parquet')
        partition_cols = config.get('s3_partition_columns', [])
        write_mode = config.get('write_mode', 'overwrite')

        # Transform rules (all optional)
        transform_rules = config.get('transform_rules', {})
        where_filter = transform_rules.get('where', '')
        select_columns = transform_rules.get('select', [])
        cast_rules = transform_rules.get('cast', {})  # {"col": "target_type"}
        dedup_config = transform_rules.get('dedup', {})  # {"columns": [...], "order_by": "col DESC"}
        custom_sql = transform_rules.get('custom_sql', '')

        use_iceberg = source_format == 'iceberg' or dest_format == 'iceberg'

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=use_iceberg)

            # Read source
            self.logger.info(f"Reading from {source_path} (format={source_format})")
            read_start = datetime.now()

            if source_format == 'iceberg':
                catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')
                source_table = config.get('iceberg_source_table', '')
                df = spark.read.format("iceberg").load(f"{catalog_name}.{source_table}")
            elif source_format == 'csv':
                df = spark.read.csv(source_path, header=True, inferSchema=True)
            else:
                df = spark.read.parquet(source_path)

            initial_count = df.count()
            read_time = (datetime.now() - read_start).total_seconds()
            self.logger.info(f"Read {initial_count} rows in {read_time:.2f}s")

            # Apply transforms
            if where_filter:
                filter_sql = self._parameterize_query(where_filter, task)
                self.logger.info(f"Applying WHERE filter: {filter_sql}")
                df = df.where(filter_sql)

            if select_columns:
                self.logger.info(f"Selecting columns: {select_columns}")
                df = df.select(*select_columns)

            if cast_rules:
                from pyspark.sql.functions import col
                for col_name, target_type in cast_rules.items():
                    self.logger.info(f"Casting {col_name} → {target_type}")
                    df = df.withColumn(col_name, col(col_name).cast(target_type))

            if dedup_config:
                dedup_cols = dedup_config.get('columns', [])
                order_by = dedup_config.get('order_by', '')
                if dedup_cols:
                    self.logger.info(f"Deduplicating by {dedup_cols}")
                    if order_by:
                        from pyspark.sql import Window
                        from pyspark.sql.functions import row_number, col as spark_col
                        # Parse "col DESC" → col.desc()
                        order_parts = order_by.split()
                        order_col = order_parts[0]
                        order_dir = order_parts[1].upper() if len(order_parts) > 1 else "ASC"
                        order_expr = spark_col(order_col).desc() if order_dir == "DESC" else spark_col(order_col).asc()

                        w = Window.partitionBy(*dedup_cols).orderBy(order_expr)
                        df = df.withColumn("_rn", row_number().over(w)).where("_rn = 1").drop("_rn")
                    else:
                        df = df.dropDuplicates(dedup_cols)

            if custom_sql:
                sql = self._parameterize_query(custom_sql, task)
                self.logger.info(f"Applying custom SQL: {sql[:200]}...")
                df.createOrReplaceTempView("source_data")
                df = spark.sql(sql)

            total_rows = df.count()
            self.logger.info(f"After transforms: {total_rows} rows (from {initial_count})")
            task['totalcount'] = total_rows

            # Write destination
            self.logger.info(f"Writing to {dest_path} (format={dest_format})")
            write_start = datetime.now()

            if dest_format == 'iceberg':
                catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')
                dest_table = config.get('iceberg_dest_table', '')
                writer = df.writeTo(f"{catalog_name}.{dest_table}")
                if write_mode == 'overwrite':
                    writer.createOrReplace()
                else:
                    writer.append()
            else:
                writer = df.write.mode(write_mode)
                if partition_cols:
                    writer = writer.partitionBy(*partition_cols)
                if dest_format == 'csv':
                    writer.csv(dest_path, header=True)
                else:
                    writer.parquet(dest_path)

            write_time = (datetime.now() - write_start).total_seconds()
            self.logger.info(f"Write completed in {write_time:.2f}s")

            total_time = read_time + write_time
            self.logger.info(f"TOTAL TIME: {total_time:.2f}s")

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
