"""Phase 134-P (2026-06-02) — S3 query base step.

Shared base for the new ``s3_query`` workflow that lets users execute a
SQL query directly against S3-resident Parquet OR Iceberg sources, then
sink the result to a file (NFS) or Oracle (JDBC).

Architecture
============

::

   S3BaseStep                            (existing — Spark + S3A + Iceberg + Oracle JDBC helpers)
   └── S3QueryBase                       (THIS FILE — shared read + write-to-file helpers)
       ├── S3IcebergQueryExtract          (sink: file)
       ├── S3ParquetQueryExtract          (sink: file)
       ├── S3IcebergQueryToOracle         (sink: Oracle JDBC, via _write_to_oracle)
       └── S3ParquetQueryToOracle         (sink: Oracle JDBC, via _write_to_oracle)

Each leaf is intentionally thin: source-side reader + sink-side writer
swap, no other behaviour.  All four share the per-task JSON config
shape (single ``query`` field with ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``
placeholders that the existing ``_parameterize_query`` resolves at run
time).

Pushdown
========

For Iceberg, Spark's catalyst optimiser pushes ``WHERE`` predicates
into the iceberg scanner — pruning data files via manifest stats
before any S3 read.  For Parquet, the same optimiser pushes filters
into the parquet reader's row-group filter (when the WHERE columns
have min/max stats).  Both are zero extra code on our side: emit the
DataFrame via ``spark.sql(...)`` and Spark does the rest.

Why this isn't shared with backend/core/dataflow/stages/sql_query_stage.py
==========================================================================

That stage runs inside the QueryStudio backend pod and uses DuckDB —
it cannot pull in Spark / Iceberg / Glue / Hive.  This file's steps
run inside the Spark container (image built from
``Dockerfile.polling-service``) and use Spark exclusively.  The
backend DuckDB path's pruning is BF-498..505 + Phase 134-O; this
Spark path's pruning is whatever Spark+Iceberg gives us natively.
The two are intentionally orthogonal.
"""
from __future__ import annotations

import os
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from steps.s3.s3_base_step import S3BaseStep


class S3QueryBase(S3BaseStep):
    """Common helpers for the s3_query workflow.

    Subclasses pick the SOURCE (iceberg / parquet) and SINK (file /
    oracle) and stitch them together inside ``_execute_step``.

    2026-06-20 -- Phase 152: every shared read/write method now pushes
    progress into the FileRunReport / RunArtifacts that the standalone's
    StandaloneRunLifecycle hangs on task["_run_report"] /
    task["_run_artifacts"].  Leaf steps don't need to call those
    hooks themselves; just calling _read_*_with_query + _write_to_file
    yields a fully-populated result.html with C1 (source count) + C3
    (downloaded count) + C5 (consolidated count) all anchored.
    """

    # Per-step fields every leaf needs.  AWS credentials are NO LONGER
    # required here -- s3_config_loader.validate_s3_yaml_for_job
    # validates them auth_mode-aware (only required when
    # auth_mode='keys'; iam_role / assume_role / env / profile don't
    # need static keys).  s3_bucket and query are still mandatory per
    # job.
    BASE_REQUIRED_FIELDS = [
        "s3_bucket",
        "query",
    ]

    SOURCE_VIEW_NAME = "source"

    # ── FileRunReport / RunArtifacts integration (Phase 152) ─────────────

    def _record_source_query(self, task: Dict, sql: str, report_id: Any) -> None:
        """Push the SQL the engine actually ran into the run report's
        per-job SQL summary so result.html shows it (with download link)."""
        rr = task.get("_run_report")
        if rr is None:
            return
        try:
            rr.add_sql_summary(str(report_id), sql)
        except Exception:
            pass

    def _record_extract_counts(
        self,
        task: Dict,
        report_id: Any,
        datasource: str,
        rows: int,
        output_path: str = "",
    ) -> None:
        """Add a per-source job_result so the cumulative C1/C3 chips
        render on the run-report.  Called from _read_*_with_query +
        _write_to_file (so the per-source row count anchors C1 AND C3
        identically -- Spark already proved the rows-out == rows-in
        invariant via DataFrame semantics)."""
        rr = task.get("_run_report")
        if rr is None:
            return
        try:
            rr.add_job_result({
                "report_id": report_id,
                "datasource": datasource,
                "status": "success",
                "records": int(rows),
                "expected_total": int(rows),
                "consolidated_rows": int(rows),
                "consolidated_file": output_path,
                "chunks": 1,
                "file_path": output_path,
            })
            # Also push the cumulative anchor so C5 renders when the
            # delivery chain doesn't run ConsolidateFiles.
            rr.set_counts(
                expected_total=int(rows),
                sum_chunk_actual=int(rows),
                consolidated_total=int(rows),
                g1_source="Spark dataframe count",
            )
        except Exception:
            pass

    def _register_output_artifact(self, task: Dict, path: str, category: str = None) -> None:
        """Register a written file with RunArtifacts so failure cleanup
        wipes it AND add it to the run report's output_files list."""
        from steps.file.run_state import RunArtifacts
        artifacts = task.get("_run_artifacts")
        if artifacts is not None:
            try:
                artifacts.add(path, category or RunArtifacts.CONSOLIDATED)
            except Exception:
                pass
        rr = task.get("_run_report")
        if rr is not None:
            try:
                rr.add_output_file(path)
            except Exception:
                pass

    # ── Spark-native completeness primitives (Phase 152 parity) ──────────
    # The S3 pipeline now has the SAME C1-C5 anchors as the file-flow
    # pipeline, expressed in Spark idioms:
    #   * source COUNT + SUMs computed via ONE df.agg() pass (the Spark
    #     equivalent of starburst_file_base._derive_probe_sql -- one
    #     scan, many anchors)
    #   * sink COUNT + SUMs computed by re-reading the written file
    #     (Spark.read + agg) and verifying against source

    def _compute_source_anchors(
        self, df, checksum_columns: List[str],
    ) -> Tuple[int, Dict[str, Any]]:
        """One Spark agg pass: COUNT(*) + SUM(c) per checksum column.

        Returns ``(row_count, {col: Decimal})``.  When ``checksum_columns``
        is empty, returns ``(row_count, {})`` and only the COUNT
        triggers a scan.

        Mirrors the Starburst ProbeQuery primitive: planner asks for
        anchors ONCE, gets count + sums in a single shuffle.  Spark's
        catalyst optimiser fuses the aggregates into one stage.
        """
        from decimal import Decimal
        if not checksum_columns:
            return df.count(), {}
        # Defensive: only use pyspark.sql.functions when ALL needed
        # attrs are present.  Test envs sometimes stub the module without
        # populating it -- catch AttributeError + ImportError.
        try:
            from pyspark.sql import functions as _F
            _count = _F.count
            _sum = _F.sum
            _lit = _F.lit
            _col = _F.col
        except (ImportError, AttributeError):
            # Not a real Spark context -- fall back to count-only.
            return df.count(), {}
        # 2026-06-20 deep-dive -- wrap the agg in try/except so a mocked
        # or malformed DataFrame falls back to count-only INSTEAD of
        # crashing the pipeline.  Real Spark DataFrames work; test
        # MagicMocks fall back cleanly.
        try:
            aggs = [_count(_lit(1)).alias("_qs_cnt")]
            for col in checksum_columns:
                aggs.append(_sum(_col(col)).alias(f"_qs_sum_{col}"))
            row = df.agg(*aggs).collect()[0]
            cnt = int(row["_qs_cnt"])
            sums: Dict[str, Any] = {}
            for col in checksum_columns:
                v = row[f"_qs_sum_{col}"]
                sums[col] = Decimal(0) if v is None else Decimal(str(v))
            return cnt, sums
        except Exception as exc:
            # Fall back to count-only so the pipeline keeps going.  Log
            # at WARN so the operator sees the checksum check was
            # skipped (NOT silent).
            self.logger.warning(
                "Spark agg() failed (%s) -- falling back to count-only. "
                "Per-column SUM checksums are SKIPPED for this run.",
                exc,
            )
            try:
                return df.count(), {}
            except Exception:
                return 0, {}

    def _verify_output_completeness(
        self,
        spark,
        output_path: str,
        output_format: str,
        expected_rows: int,
        expected_sums: Dict[str, Any],
        delimiter: str = ",",
        header: bool = True,
        fail_on_mismatch: bool = True,
    ) -> Tuple[int, Dict[str, Any], List[str]]:
        """Re-read the written file via Spark and verify counts + sums.

        Returns ``(actual_rows, {col: Decimal}, mismatch_messages)``.

        When ``fail_on_mismatch`` is True (default) AND any mismatch
        was detected, raises ValueError BEFORE returning -- partial
        output never ships.  Set False to log+continue (operator owns
        the end-of-job reconcile via result.html).

        This is the S3 equivalent of the file-flow's G5 (consolidated
        file rows == G1) + G5 SUM (consolidated column sums == source
        column sums).  Re-reading the file proves what Spark actually
        wrote to disk, not just what was in the DataFrame.
        """
        from decimal import Decimal
        if output_format == "csv":
            reader = (
                spark.read
                .option("header", str(header).lower())
                .option("sep", delimiter)
                .csv(output_path)
            )
        elif output_format == "parquet":
            reader = spark.read.parquet(output_path)
        elif output_format == "json":
            reader = spark.read.json(output_path)
        else:
            raise ValueError(
                f"Cannot verify completeness for output_format={output_format!r}"
            )
        actual_rows, actual_sums = self._compute_source_anchors(
            reader, list(expected_sums.keys()),
        )
        mismatches: List[str] = []
        if int(actual_rows) != int(expected_rows):
            mismatches.append(
                f"row count: expected={expected_rows:,} actual={actual_rows:,} "
                f"(delta {actual_rows - expected_rows:+,})"
            )
        for col, exp_v in expected_sums.items():
            act_v = actual_sums.get(col)
            if act_v is None:
                continue
            if act_v != exp_v:
                mismatches.append(
                    f"SUM({col}): expected={exp_v} actual={act_v} "
                    f"(delta {act_v - exp_v:+})"
                )
        if mismatches and fail_on_mismatch:
            raise ValueError(
                f"S3 output completeness check FAILED on "
                f"{output_path}: {'; '.join(mismatches)}.  "
                f"Rows / sums differ between Spark DataFrame and on-disk "
                f"output -- partial write or filter mis-application."
            )
        return actual_rows, actual_sums, mismatches

    @staticmethod
    def _resolve_spark_session_from_df(df) -> Any:
        """Return the SparkSession that OWNS this DataFrame, or None.

        2026-06-20 -- deep-dive: PySpark API variance across 3.x versions
        breaks the naive ``df.sparkSession`` lookup.  Probe in order:

          1. ``df.sparkSession``  (Spark >= 3.1; the canonical attr)
          2. ``df.sql_ctx.sparkSession``  (Spark 3.0 / 2.x compat)
          3. ``df._jdf.sparkSession``  (JVM-side fallback for exotic builds)

        Returns None when none of these resolve.  Caller MUST NOT fall
        back to ``SparkSession.builder.getOrCreate()`` -- on a fresh
        runner that would CONSTRUCT a new session with no S3 creds and
        the re-read would fail noisily mid-pipeline.  Returning None
        lets the caller skip cleanly with a loud WARN.
        """
        for attr in ("sparkSession",):
            sess = getattr(df, attr, None)
            if sess is not None:
                return sess
        sql_ctx = getattr(df, "sql_ctx", None)
        if sql_ctx is not None:
            sess = getattr(sql_ctx, "sparkSession", None)
            if sess is not None:
                return sess
        jdf = getattr(df, "_jdf", None)
        if jdf is not None:
            sess = getattr(jdf, "sparkSession", None)
            if sess is not None:
                return sess
        return None

    def _resolve_checksum_columns(self, config: Dict, task: Dict) -> List[str]:
        """Pull checksum_columns from per-job JSON OR polling row.
        Accepts list-of-str OR comma-separated string.  Empty -> [].
        Polling-row CHECKSUM_COLUMNS column wins over JSON when both set."""
        # Polling row wins (operator can override per-run).
        raw = (
            task.get("checksum_columns")
            or task.get("CHECKSUM_COLUMNS")
            or config.get("checksum_columns", [])
        )
        if not raw:
            return []
        if isinstance(raw, str):
            return [c.strip() for c in raw.split(",") if c.strip()]
        return [str(c).strip() for c in raw if str(c).strip()]

    # ── Source readers ──────────────────────────────────────────────────

    @staticmethod
    def _resolve_iceberg_full_table(table_fqn: str, catalog_name: str) -> str:
        """Resolve the fully-qualified iceberg table name.

        Rules:
          * If ``table_fqn`` is already ``{catalog_name}.…`` (exact
            first segment match), return it verbatim.
          * Otherwise prepend ``catalog_name.`` so Spark routes the
            read through the configured Iceberg catalog.

        Audit fix: previously used ``startswith(catalog_name + ".")``
        which silently accepted ``iceberg_catalog2.db.tbl`` as already
        prefixed when ``catalog_name=iceberg_catalog`` (matches by
        prefix, not by segment).  Now splits on the first ``.`` and
        compares the first segment exactly.
        """
        if "." in table_fqn:
            first_segment = table_fqn.split(".", 1)[0]
            if first_segment == catalog_name:
                return table_fqn
        return f"{catalog_name}.{table_fqn}"

    def _read_iceberg_with_query(
        self, spark, config: Dict, task: Dict,
    ) -> Tuple[Any, int, float]:
        """Read an Iceberg table and run the user's SQL against it.

        Returns ``(dataframe, total_rows, read_time_seconds)``.

        The Iceberg table is exposed as a temp view named
        ``source`` so the user's ``query`` reads naturally as
        ``SELECT ... FROM source WHERE ...``.

        Validates that the catalog wiring is complete before kicking
        off Spark — without this, missing ``iceberg_catalog_uri`` /
        ``iceberg_warehouse`` produces a confusing AnalysisException
        deep inside Spark instead of a clear config error here.
        """
        table_fqn = config.get("iceberg_table") or config.get("table_fqn")
        if not table_fqn:
            raise ValueError(
                "iceberg_table is required for iceberg-source steps"
            )
        catalog_type = (config.get("iceberg_catalog_type") or "rest").lower()
        if catalog_type in ("rest", "hive") and not config.get("iceberg_catalog_uri"):
            raise ValueError(
                f"iceberg_catalog_uri is required for "
                f"iceberg_catalog_type={catalog_type!r} — without it "
                f"Spark cannot connect to the catalog"
            )
        if catalog_type == "rest" and not config.get("iceberg_warehouse"):
            raise ValueError(
                "iceberg_warehouse is required for REST catalogues so "
                "Spark knows where to resolve table locations"
            )
        # Phase 134-P — validate time-travel config BEFORE touching
        # spark so a misconfigured task fails fast with a clear error
        # instead of an AttributeError mid-read.
        snapshot_id = config.get("snapshot_id")
        as_of_ts_ms = config.get("as_of_timestamp_ms")
        if snapshot_id is not None and as_of_ts_ms is not None:
            raise ValueError(
                "snapshot_id and as_of_timestamp_ms are mutually "
                "exclusive — set at most one"
            )
        catalog_name = config.get("iceberg_catalog_name", "iceberg_catalog")
        full_table = self._resolve_iceberg_full_table(table_fqn, catalog_name)
        self.logger.info(f"Iceberg source: {full_table}")
        read_start = datetime.now()

        # Phase 134-P (supplement pruning) — optional QS-supplement-
        # aware file-level pruning.  When enabled AND the table has
        # no partition transforms / delete files (we detect both and
        # refuse the pruned path to avoid correctness bugs), we
        # bypass Spark+Iceberg's reader, hand-pick the data files
        # via manifest+supplement bounds, and feed the surviving file
        # list directly to ``spark.read.parquet([files])``.
        df = self._supplement_pruned_read(
            spark, config, full_table, snapshot_id, as_of_ts_ms,
        )
        if df is None:
            # Standard path — Spark+Iceberg reader handles everything
            # (manifest pruning, deletes, transforms, schema evo).
            reader = spark.read.format("iceberg")
            if snapshot_id is not None:
                self.logger.info(
                    f"Iceberg time-travel: snapshot-id={snapshot_id}"
                )
                reader = reader.option("snapshot-id", str(snapshot_id))
            elif as_of_ts_ms is not None:
                self.logger.info(
                    f"Iceberg time-travel: as-of-timestamp={as_of_ts_ms} (ms)"
                )
                reader = reader.option("as-of-timestamp", str(as_of_ts_ms))
            df = reader.load(full_table)
        df.createOrReplaceTempView(self.SOURCE_VIEW_NAME)
        query = self._parameterize_query(config["query"], task)
        self.logger.info(
            f"Running user query against iceberg source "
            f"(length={len(query)}):\n{query}"
        )
        result_df = spark.sql(query)
        # 2026-06-20 -- Phase 152: one agg pass yields COUNT + SUMs
        # (the Spark equivalent of ProbeQuery's single GROUP BY scan).
        # Source SUMs are stashed on the task for the sink-side gate
        # in _write_to_file.
        ck_cols = self._resolve_checksum_columns(config, task)
        total_rows, source_sums = self._compute_source_anchors(
            result_df, ck_cols,
        )
        task["_source_row_count"] = total_rows
        task["_source_checksums"] = source_sums
        task["_checksum_columns"] = ck_cols
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(
            "Iceberg query produced %s rows in %.2fs (checksum_columns=%s, source_sums=%s)",
            f"{total_rows:,}", read_time, ck_cols,
            ", ".join(f"SUM({c})={v}" for c, v in source_sums.items()) or "(none)",
        )
        # 2026-06-20 -- Phase 152: surface SQL + row count in result.html
        self._record_source_query(task, query, task.get("fk_report_id") or task.get("report_id"))
        self._record_extract_counts(
            task,
            report_id=task.get("fk_report_id") or task.get("report_id"),
            datasource="ICEBERG",
            rows=total_rows,
        )
        return result_df, total_rows, read_time

    def _read_parquet_with_query(
        self, spark, config: Dict, task: Dict,
    ) -> Tuple[Any, int, float]:
        """Read parquet files from ``s3a://bucket/prefix`` and run the
        user's SQL against them.

        ``s3_prefix`` may include ``{BUSINESSDATE}`` / ``{SYSTEM_ENTITY}``
        placeholders so the same config can drive different partitions
        across runs.
        """
        prefix_raw = config.get("s3_prefix", "")
        if not prefix_raw:
            raise ValueError(
                "s3_prefix is required for parquet-source steps"
            )
        prefix = self._parameterize_query(prefix_raw, task)
        bucket = config["s3_bucket"]
        s3_input_path = f"s3a://{bucket}/{prefix}"
        self.logger.info(f"Parquet source: {s3_input_path}")
        read_start = datetime.now()
        df = spark.read.parquet(s3_input_path)
        df.createOrReplaceTempView(self.SOURCE_VIEW_NAME)
        query = self._parameterize_query(config["query"], task)
        self.logger.info(
            f"Running user query against parquet source "
            f"(length={len(query)}):\n{query}"
        )
        result_df = spark.sql(query)
        # 2026-06-20 -- Phase 152: one agg pass yields COUNT + SUMs.
        ck_cols = self._resolve_checksum_columns(config, task)
        total_rows, source_sums = self._compute_source_anchors(
            result_df, ck_cols,
        )
        task["_source_row_count"] = total_rows
        task["_source_checksums"] = source_sums
        task["_checksum_columns"] = ck_cols
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(
            "Parquet query produced %s rows in %.2fs (checksum_columns=%s, source_sums=%s)",
            f"{total_rows:,}", read_time, ck_cols,
            ", ".join(f"SUM({c})={v}" for c, v in source_sums.items()) or "(none)",
        )
        # 2026-06-20 -- Phase 152: surface SQL + row count in result.html
        self._record_source_query(task, query, task.get("fk_report_id") or task.get("report_id"))
        self._record_extract_counts(
            task,
            report_id=task.get("fk_report_id") or task.get("report_id"),
            datasource="PARQUET",
            rows=total_rows,
        )
        return result_df, total_rows, read_time

    # ── Supplement-pruning path (Phase 134-P) ─────────────────────────

    def _supplement_pruned_read(
        self, spark, config: Dict,
        full_table: str,
        snapshot_id: Any,
        as_of_ts_ms: Any,
    ):
        """Try the supplement-pruned read path.  Returns a Spark
        DataFrame when the pruned path applies, else ``None`` (caller
        falls back to the standard Spark+Iceberg reader).

        REFUSES (returns None) when ANY of these hold:

          * ``config['use_supplement_pruning']`` is not truthy
          * ``config['querystudio_db_connection_string']`` is missing
          * Required Python deps (pyiceberg, sqlglot, oracledb) aren't
            installed
          * The user's WHERE has no extractable predicates
          * The iceberg table uses partition transforms (bucket /
            truncate / year / month / day / hour) — pruned path
            can't reproduce those without re-implementing iceberg's
            ``Transform.project()``
          * The snapshot has equality or position delete files —
            pruned path's ``read.parquet([files])`` doesn't apply
            deletes; results would be wrong

        Every refusal logs the reason at INFO so operators can debug
        why supplement pruning isn't kicking in.

        Phase 134-P scope note
        ----------------------
        This is intentionally conservative.  Later sessions can
        narrow the refusal set (e.g. handle position deletes by
        excluding their target rows, handle date transforms by
        translating the predicate).
        """
        if not config.get("use_supplement_pruning"):
            return None
        qs_db = config.get("querystudio_db_connection_string")
        if not qs_db:
            self.logger.info(
                "supplement pruning enabled but querystudio_db_"
                "connection_string is empty — falling back to standard "
                "iceberg path"
            )
            return None

        try:
            from managers.sql_filter_extractor import extract_predicates
            from managers.iceberg_supplement_reader import (
                IcebergSupplementReader,
                DEFAULT_MAX_AGE_SECONDS as IcebergSupplementReader_DEFAULT_MAX_AGE,
            )
            from managers.iceberg_file_pruner import prune_files
        except ImportError as exc:
            self.logger.warning(
                f"supplement pruning deps missing ({exc}) — falling "
                f"back to standard iceberg path"
            )
            return None

        try:
            import pyiceberg.catalog as _pc  # noqa: F401
        except ImportError:
            self.logger.warning(
                "pyiceberg not installed — supplement pruning needs "
                "manifest reads; falling back to standard iceberg path"
            )
            return None

        query = self._parameterize_query(config["query"], config)
        # Phase H (2026-06-08) — defensive copy so the later
        # transformed_predicates merge doesn't mutate a dict the
        # caller may hold (or that we cache in a future refactor).
        predicates = {k: list(v) for k, v in extract_predicates(query).items()}
        if not predicates:
            self.logger.info(
                "WHERE has no extractable predicates — supplement "
                "pruning would be a no-op; using standard path"
            )
            return None

        # Resolve snapshot + manifest + reject delete-files /
        # transforms.  This block is the one that goes deepest into
        # pyiceberg territory; failures here log and fall back rather
        # than raising — supplement pruning is OPT-IN, mustn't break
        # a working baseline.
        try:
            scan_info = self._scan_iceberg_for_pruning(
                config, full_table, snapshot_id, as_of_ts_ms,
                predicates=predicates,
            )
        except Exception as exc:
            self.logger.warning(
                f"supplement-pruning scan failed ({exc}) — falling "
                f"back to standard iceberg path"
            )
            return None
        if scan_info is None:
            return None  # _scan_iceberg_for_pruning already logged

        (files, manifest_bounds, snap_id_str,
         iceberg_field_types, partition_columns,
         transformed_predicates) = scan_info

        # Phase F (2026-06-08) — apply pre-transformed predicates so
        # partition columns under day()/month()/year()/hour() transforms
        # can be compared against manifest bounds (which store the
        # transformed value, not the source column's value).
        if transformed_predicates:
            for col, ops in transformed_predicates.items():
                predicates.setdefault(col, []).extend(ops)

        # Supplement lookup keyed on bucket + table_prefix + snapshot.
        supp_reader = IcebergSupplementReader(
            connection_string=qs_db,
            bucket=config.get("s3_bucket", ""),
            table_prefix=config.get("table_prefix") or self._infer_prefix_from_table(full_table),
            snapshot_id=snap_id_str,
        )

        # Phase F freshness gate — when supplement is stale, fall back
        # to standard Spark+Iceberg.  Honours max_age via config; default
        # 3600s matches QS backend's iceberg_db_first.max_age_seconds.
        _max_age = int(config.get(
            "supplement_max_age_seconds",
            IcebergSupplementReader_DEFAULT_MAX_AGE,
        ))
        if not supp_reader.is_fresh(max_age_seconds=_max_age):
            self.logger.info(
                "supplement pruning refused: supplement is STALE for "
                "%s/%s snapshot=%s (max_age=%ds) — falling back to "
                "standard iceberg path",
                config.get("s3_bucket", ""),
                config.get("table_prefix")
                    or self._infer_prefix_from_table(full_table),
                snap_id_str, _max_age,
            )
            return None

        supplement_bounds: Dict[str, Dict[str, Any]] = {}
        for col in predicates:
            supplement_bounds[col] = supp_reader.bounds_for(col)

        # 2026-06-22 bug #29 -- Gap 3: huge-table manifest observability.
        # When manifest grows past N files, supplement pruning's
        # sequential read path becomes a bottleneck (vs Spark+Iceberg's
        # parallel scan).  Operators see WARN + can override the
        # threshold or opt out entirely.  Soft warning -- doesn't
        # refuse the pruned path because operator's already opted in.
        total = len(files)
        _huge_manifest_threshold = int(
            config.get('supplement_pruning_huge_manifest_warn', 5000)
        )
        if total >= _huge_manifest_threshold:
            self.logger.warning(
                "supplement pruning on LARGE manifest: %d files "
                "(>= %d threshold).  Sequential manifest scan may be "
                "slow; Spark+Iceberg's parallel scan can be faster "
                "for tables this size.  Set "
                "use_supplement_pruning=false OR raise "
                "supplement_pruning_huge_manifest_warn to silence.",
                total, _huge_manifest_threshold,
            )

        _prune_start = datetime.now()
        pruned_files = prune_files(
            files, manifest_bounds, supplement_bounds, predicates,
            iceberg_field_types=iceberg_field_types,
            partition_columns=partition_columns,
        )
        _prune_dur = (datetime.now() - _prune_start).total_seconds()
        kept = len(pruned_files)
        self.logger.info(
            f"supplement pruning: kept {kept}/{total} files "
            f"({total - kept} pruned) in {_prune_dur:.2f}s "
            f"[partition_cols={sorted(partition_columns)}, "
            f"types={sorted(iceberg_field_types.keys())[:8]}…]"
        )

        # 2026-06-22 -- surface pruning effectiveness to FileRunReport so
        # operators see "kept N/M files via supplement pruning" + scan
        # time in result.html runtime_knobs.  No-op when run_report
        # absent (tests, ad-hoc CLI runs).
        try:
            rr = config.get("_run_report") or getattr(self, "_run_report", None)
            if rr is not None:
                rr.runtime_knobs[f"supplement_pruning_{full_table}"] = (
                    f"kept {kept}/{total} files ({(100*kept/max(total,1)):.1f}%) "
                    f"in {_prune_dur:.2f}s"
                )
        except Exception:
            pass

        if not pruned_files:
            # Empty result — return an empty DF with the table's schema
            # so downstream count() / spark.sql() don't crash.  Use the
            # standard reader with a 0-row predicate so Iceberg's
            # delete-file / transform handling stays intact for the
            # schema source.
            #
            # Phase H (2026-06-08) — when the query is time-travel
            # (snapshot_id / as_of_timestamp_ms), the empty DF must use
            # the SAME snapshot so its schema matches.  Pre-Phase-H
            # this called .load(full_table).limit(0) which read the
            # CURRENT snapshot's schema, crashing later if the user's
            # query referenced columns added AFTER the time-travel
            # snapshot.
            _empty_reader = spark.read.format("iceberg")
            if snapshot_id is not None:
                _empty_reader = _empty_reader.option(
                    "snapshot-id", str(snapshot_id))
            elif as_of_ts_ms is not None:
                _empty_reader = _empty_reader.option(
                    "as-of-timestamp", str(as_of_ts_ms))
            return _empty_reader.load(full_table).limit(0)
        return spark.read.parquet(*pruned_files)

    def _scan_iceberg_for_pruning(
        self, config: Dict, full_table: str,
        snapshot_id: Any, as_of_ts_ms: Any,
        predicates: Optional[Dict[str, List[Tuple[str, Any]]]] = None,
    ):
        """Resolve the snapshot's data files + manifest bounds via
        pyiceberg.

        Phase F return shape:
          ``(file_paths,
             manifest_bounds,
             snapshot_id_str,
             iceberg_field_types,
             partition_columns,
             transformed_predicates)``

        Or ``None`` when the table has unsupported features (delete
        files or NON-supported partition transforms).

          * ``iceberg_field_types`` maps lowercased column name to its
            iceberg type string ("date", "timestamp", "decimal(10,4)"...).
            Drives the pruner's type-aware coercion.

          * ``partition_columns`` is the set of partition column names
            (lowercased) — drives the pruner's cascade telemetry.

          * ``transformed_predicates`` is a per-column dict of
            ``[(op, transformed_value)]`` tuples for partition columns
            whose transform != identity.  Caller MERGES these into
            ``predicates`` before calling ``prune_files`` so the
            partition bound (stored as int days/months/etc) gets
            compared against the right value.

        Raises only on infrastructural failure (pyiceberg can't
        connect to the catalog); semantic refusals return None +
        log.
        """
        from pyiceberg.catalog import load_catalog
        from pyiceberg.transforms import IdentityTransform
        from managers.iceberg_value_coercion import (
            apply_transform_to_value,
            decode_iceberg_bound as _decode_iceberg_bound,
        )

        catalog_name = config.get("iceberg_catalog_name", "iceberg_catalog")
        catalog_props = self._build_pyiceberg_catalog_props(config)
        catalog = load_catalog(catalog_name, **catalog_props)

        if full_table.startswith(catalog_name + "."):
            tbl_ident = full_table[len(catalog_name) + 1:]
        else:
            tbl_ident = full_table
        tbl = catalog.load_table(tbl_ident)

        # Phase F: support day/month/year/hour transforms in addition
        # to identity.  Anything else (bucket/truncate) still refuses
        # because we can't safely transform the user's filter value
        # without re-implementing iceberg's full Transform.project().
        spec = tbl.spec()
        schema = tbl.schema()

        # Phase G (2026-06-08) — defensive pyiceberg accessors.  Field /
        # transform attribute names changed across 0.5 / 0.6 / 0.11; wrap
        # every access so a single attribute-rename in a future version
        # downgrades us gracefully to "supplement pruning refused" instead
        # of crashing.
        field_id_to_name: Dict[int, str] = {}
        iceberg_field_types: Dict[str, str] = {}
        try:
            for fld in getattr(schema, "fields", []) or []:
                fid = (getattr(fld, "field_id", None)
                       or getattr(fld, "id", None))
                fname = getattr(fld, "name", None)
                ftype = getattr(fld, "field_type", None) \
                        or getattr(fld, "type", None)
                if fid is None or not fname:
                    continue
                field_id_to_name[int(fid)] = fname
                iceberg_field_types[fname.lower()] = (
                    str(ftype).lower() if ftype is not None else "string"
                )
        except Exception as _sf_exc:
            self.logger.info(
                "supplement pruning refused: pyiceberg schema shape "
                "unexpected (%s) — falling back", _sf_exc,
            )
            return None
        if not field_id_to_name:
            self.logger.info(
                "supplement pruning refused: empty schema fields list "
                "from pyiceberg — falling back",
            )
            return None

        # Build partition-column set and per-partition transform info
        partition_columns: set = set()
        partition_transforms: Dict[str, Tuple[str, str]] = {}
        _SUPPORTED_NON_ID_TRANSFORMS = {"day", "month", "year", "hour"}
        try:
            spec_fields = getattr(spec, "fields", []) or []
            for field in spec_fields:
                src_id = (getattr(field, "source_id", None)
                          or getattr(field, "source-id", None))
                if src_id is None:
                    continue
                source_name = field_id_to_name.get(int(src_id))
                if source_name is None:
                    continue
                partition_columns.add(source_name.lower())
                transform = getattr(field, "transform", None)
                if transform is None:
                    continue
                if isinstance(transform, IdentityTransform):
                    continue
                # Transform class name -> "day" / "month" / "year" /
                # "hour" / "bucket[N]" / "truncate[W]".
                tname = type(transform).__name__.lower().replace(
                    "transform", "")
                if tname not in _SUPPORTED_NON_ID_TRANSFORMS:
                    self.logger.info(
                        "supplement pruning refused: partition transform "
                        "%r on column %r is unsupported (only identity / "
                        "day / month / year / hour) — falling back",
                        tname, source_name,
                    )
                    return None
                partition_transforms[source_name.lower()] = (
                    tname,
                    iceberg_field_types.get(source_name.lower(), "string"),
                )
        except Exception as _sp_exc:
            self.logger.info(
                "supplement pruning refused: pyiceberg partition-spec "
                "shape unexpected (%s) — falling back", _sp_exc,
            )
            return None

        # Resolve the snapshot we want.  Phase G — wrap pyiceberg API
        # calls so a renamed method downgrades gracefully.
        try:
            if snapshot_id is not None:
                snap = tbl.snapshot_by_id(int(snapshot_id))
            elif as_of_ts_ms is not None:
                snap = tbl.snapshot_as_of_timestamp(int(as_of_ts_ms))
            else:
                snap = tbl.current_snapshot()
        except Exception as _sn_exc:
            self.logger.info(
                "supplement pruning refused: pyiceberg snapshot lookup "
                "failed (%s) — falling back", _sn_exc,
            )
            return None
        if snap is None:
            self.logger.info(
                "supplement pruning refused: no snapshot resolved "
                "(empty table?) — falling back"
            )
            return None
        snap_id_str = str(getattr(snap, "snapshot_id", "") or "")
        if not snap_id_str:
            self.logger.info(
                "supplement pruning refused: snapshot has no id "
                "attribute — falling back"
            )
            return None

        # Walk data files.  Refuse if any have delete files attached
        # — the pruned path can't apply deletes.
        files: List[str] = []
        manifest_bounds: Dict[str, Dict[str, Any]] = {}
        try:
            scan = tbl.scan(snapshot_id=int(snap_id_str))
            plan_files_iter = scan.plan_files()
        except Exception as _ps_exc:
            self.logger.info(
                "supplement pruning refused: pyiceberg scan.plan_files() "
                "failed (%s) — falling back", _ps_exc,
            )
            return None
        for task in plan_files_iter:
            df = getattr(task, "file", None)
            if df is None:
                self.logger.info(
                    "supplement pruning refused: plan_files task has "
                    "no .file attribute — falling back",
                )
                return None
            if getattr(task, "delete_files", None):
                self.logger.info(
                    "supplement pruning refused: snapshot has delete "
                    "files — falling back"
                )
                return None
            fp = getattr(df, "file_path", None)
            if not fp:
                continue
            files.append(fp)
            # Phase G (2026-06-08) — decode bounds via the iceberg-type-
            # aware decoder so int32 day counts (e.g. 20361) become
            # "2025-09-30" instead of garbage hex.  The supplement scanner
            # stores the SAME format (via str(pyarrow_stat)), so the
            # pruner can compare directly.  All getattr() wrapped so a
            # renamed attribute downgrades to no-bounds rather than
            # crashes.
            lower_bounds_map = getattr(df, "lower_bounds", None) or {}
            upper_bounds_map = getattr(df, "upper_bounds", None) or {}
            null_counts_map = getattr(df, "null_value_counts", None) or {}
            record_count = getattr(df, "record_count", None) or 0
            for col_id, lower in lower_bounds_map.items():
                col_name = field_id_to_name.get(int(col_id)) \
                           if isinstance(col_id, int) \
                           else field_id_to_name.get(col_id)
                if col_name is None:
                    continue
                col_lower = col_name.lower()
                col_type = iceberg_field_types.get(col_lower, "string")
                upper = upper_bounds_map.get(col_id)
                manifest_bounds.setdefault(col_lower, {})[fp] = (
                    _decode_iceberg_bound(lower, col_type),
                    _decode_iceberg_bound(upper, col_type),
                    int(null_counts_map.get(col_id, 0) or 0),
                    int(record_count),
                )

        # Phase F: build transformed predicates so day(ts_col)/month(...)
        # partition cols can be pruned via their transformed manifest
        # bound.  Caller (the _supplement_pruned_read orchestrator)
        # merges these into the original predicates dict.
        transformed_predicates: Dict[str, List[Tuple[str, Any]]] = {}
        if predicates and partition_transforms:
            for col_lower, (tname, source_type) in partition_transforms.items():
                col_preds = predicates.get(col_lower) or predicates.get(
                    col_lower.upper())
                if not col_preds:
                    continue
                t_ops: List[Tuple[str, Any]] = []
                for op, val in col_preds:
                    if op == "in" and isinstance(val, list):
                        tvals = []
                        for v in val:
                            tv = apply_transform_to_value(v, source_type, tname)
                            if tv is None:
                                tvals = None
                                break
                            tvals.append(tv)
                        if tvals is not None:
                            t_ops.append(("in", tvals))
                    else:
                        tv = apply_transform_to_value(val, source_type, tname)
                        if tv is not None:
                            t_ops.append((op, tv))
                if t_ops:
                    transformed_predicates[col_lower] = t_ops
                    self.logger.info(
                        "supplement pruning: transformed %d predicate(s) "
                        "on partition column %r via %s()",
                        len(t_ops), col_lower, tname,
                    )

        return (
            files, manifest_bounds, snap_id_str,
            iceberg_field_types, partition_columns, transformed_predicates,
        )

    @staticmethod
    def _build_pyiceberg_catalog_props(config: Dict) -> Dict[str, Any]:
        """Convert ETL config's iceberg_* keys to pyiceberg's catalog
        properties dict.  Mirrors what _configure_iceberg_catalog
        passes to Spark, but in pyiceberg's vocabulary.
        """
        catalog_type = (config.get("iceberg_catalog_type") or "rest").lower()
        props: Dict[str, Any] = {"type": catalog_type}
        if catalog_type in ("rest", "hive"):
            props["uri"] = config.get("iceberg_catalog_uri", "")
        if config.get("iceberg_warehouse"):
            props["warehouse"] = config["iceberg_warehouse"]
        # S3A creds for the catalog's FileIO.
        if config.get("s3_access_key"):
            props["s3.access-key-id"] = config["s3_access_key"]
        if config.get("s3_secret_key"):
            props["s3.secret-access-key"] = config["s3_secret_key"]
        if config.get("s3_endpoint_url"):
            props["s3.endpoint"] = config["s3_endpoint_url"]
        return props

    @staticmethod
    def _field_id_to_name(tbl, col_id: int) -> Optional[str]:
        """Resolve a pyiceberg field id to its column name."""
        try:
            return tbl.schema().find_column_name(col_id)
        except Exception:
            return None

    @staticmethod
    def _bytes_to_str(b) -> Optional[str]:
        """Decode pyiceberg's bytes bound to a Python string.
        Numeric bounds come back as variable-length big-endian bytes
        — we let pyiceberg decode them upstream when possible, and
        fall back to repr() on unknown types here."""
        if b is None:
            return None
        if isinstance(b, bytes):
            try:
                return b.decode("utf-8")
            except UnicodeDecodeError:
                return b.hex()
        return str(b)

    @staticmethod
    def _infer_prefix_from_table(full_table: str) -> str:
        """When ``table_prefix`` isn't set in config, derive a
        best-effort prefix from the table FQN — fine for matching
        the supplement's keyed entries because QS writes the same
        prefix.  Falls back to the bare table name.
        """
        parts = full_table.split(".")
        return parts[-1] if parts else full_table

    # ── File sink ──────────────────────────────────────────────────────

    # Suffix used for the per-format Spark "part" files Spark drops
    # into its output directory.  We use the same naming Spark uses so
    # the move + cleanup logic finds the file without globbing.
    _SPARK_PART_GLOBS = {
        "csv":     "part-*.csv",
        "parquet": "part-*.parquet",
        "json":    "part-*.json",
    }

    def _write_to_file(
        self, df, config: Dict, task: Dict,
    ) -> Tuple[str, float]:
        """Write the DataFrame to a SINGLE local NFS file.

        Returns ``(resolved_output_path, write_time_seconds)``.

        Config keys honoured:
          * ``output_format``  — csv (default) | parquet | json
          * ``output_path``    — destination file (supports placeholders).
                                  MUST be a file path, not a directory —
                                  Spark's native ``write.csv(path)``
                                  produces ``path/`` as a directory of
                                  part files; we explicitly land a
                                  single file at this path so downstream
                                  consumers (CompressFiles / CreateCTLFile /
                                  DeliverFiles) can read it directly.
          * ``num_partitions`` — Spark output partitions (default 1
                                  so the consumer sees a single file
                                  per run).  Values > 1 are rejected —
                                  the file sink consolidates to one
                                  file by contract; use a downstream
                                  consolidator if you need partitioned
                                  output.
          * ``write_mode``     — overwrite (default) | append
          * ``header``         — bool, csv only (default True)
          * ``delimiter``      — csv only (default ',')
        """
        output_path_raw = config.get("output_path")
        if not output_path_raw:
            raise ValueError(
                "output_path is required for file-sink steps"
            )
        output_path = self._parameterize_query(output_path_raw, task)
        fmt = (config.get("output_format") or "csv").lower().strip()
        if fmt not in ("csv", "parquet", "json"):
            raise ValueError(
                f"output_format must be csv|parquet|json, got {fmt!r}"
            )
        write_mode = (config.get("write_mode") or "overwrite").lower().strip()
        num_partitions = int(config.get("num_partitions", 1))
        if num_partitions != 1:
            raise ValueError(
                f"num_partitions must be 1 for s3_query file-sink steps "
                f"(the sink consolidates to a single file by contract); "
                f"got {num_partitions}.  Use a downstream consolidator "
                f"step if you need partitioned output."
            )

        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        # Spark writes a DIRECTORY of part files, not a single file.
        # Write to a staging directory next to the requested output,
        # then move the lone part file to ``output_path``.  Done this
        # way (vs ``write.option('path', tempdir)`` then rename) so a
        # crash mid-write doesn't leave a half-written ``output_path``.
        staging_dir = output_path + ".__staging__"
        if os.path.exists(staging_dir):
            import shutil as _shutil
            _shutil.rmtree(staging_dir, ignore_errors=True)

        self.logger.info(
            f"Writing {fmt} to {output_path} "
            f"(mode={write_mode}, staging={staging_dir})"
        )
        write_start = datetime.now()
        out = df.coalesce(1)
        writer = out.write.mode(write_mode)
        if fmt == "csv":
            writer = (
                writer
                .option("header", str(config.get("header", True)).lower())
                .option("sep", config.get("delimiter", ","))
            )
            writer.csv(staging_dir)
        elif fmt == "parquet":
            writer.parquet(staging_dir)
        else:
            writer.json(staging_dir)
        write_time = (datetime.now() - write_start).total_seconds()

        # 2026-06-20 -- Phase 152: BACKUP-ON-RERUN.  If a prior run left
        # a file at output_path, move it to <dirname>/backup_<ts>/
        # (or delete -- operator's prior_output_mode flag) BEFORE we
        # overwrite.  Mirrors the file-flow's backup_if_exists pattern.
        try:
            from steps.file.run_state import backup_if_exists as _bif
            _bif(
                output_path,
                backup_ts=task.get("backup_ts") or None,
                mode=task.get("prior_output_mode") or "backup",
                logger=self.logger,
            )
        except ImportError:
            pass
        # Move the single part file out of staging into ``output_path``.
        self._materialise_single_part_file(staging_dir, output_path, fmt)
        self.logger.info(
            f"Wrote file in {write_time:.2f}s "
            f"(materialised single file at {output_path})"
        )
        # 2026-06-20 -- Phase 152: SINK-SIDE COMPLETENESS CHECK.
        # Re-read the file and verify row count + per-column sums match
        # what the source DataFrame computed pre-write.  This is the
        # S3 equivalent of the file-flow's C5 (consolidated rows == G1)
        # + C5 SUM (consolidated column sums == source column sums).
        #
        # SAFETY KNOBS (operator-tunable, no hardcoded thresholds):
        #   * skip_sink_verify     -- bypass entirely (correctness off)
        #   * verify_max_rows      -- auto-skip when expected_rows > N
        #                             (default 0 = no auto-skip).  Use
        #                             this for 150M+ jobs where the
        #                             extra Spark stage is too costly.
        #
        # SPARK SESSION RESOLUTION (deep-dive 2026-06-20):
        #   Spark API for "get my owning session" diverges across 3.x
        #   versions.  We try in order:
        #     (a) df.sparkSession     (Spark >= 3.1)
        #     (b) df.sql_ctx.sparkSession  (older 3.0 / 2.x)
        #     (c) df._jdf.sparkSession  (PySpark JVM fallback)
        #   We REFUSE to fall back to SparkSession.builder.getOrCreate()
        #   -- that would either reuse the active session (OK) OR
        #   construct a NEW one (wrong: different conf, no S3 creds,
        #   the re-read fails noisily).  When we can't resolve the
        #   session from the DataFrame, the verify is SKIPPED with a
        #   loud WARN instead of risking a broken re-read.
        expected_rows = task.get("_source_row_count")
        expected_sums = task.get("_source_checksums") or {}
        skip_verify = str(
            config.get("skip_sink_verify")
            or task.get("skip_sink_verify")
            or task.get("SKIP_SINK_VERIFY")
            or ""
        ).strip().upper() in {"TRUE", "1", "YES", "Y", "T"}
        verify_max_rows = int(
            config.get("verify_max_rows")
            or task.get("verify_max_rows")
            or task.get("VERIFY_MAX_ROWS")
            or 0
        )
        if (
            expected_rows is not None
            and not skip_verify
            and (verify_max_rows == 0 or expected_rows <= verify_max_rows)
        ):
            spark = self._resolve_spark_session_from_df(df)
            if spark is None:
                self.logger.warning(
                    "Sink verify SKIPPED -- could not resolve Spark "
                    "session from DataFrame (Spark API variance).  "
                    "Output written but NOT re-read-verified.  Set "
                    "skip_sink_verify=true on this job to silence "
                    "this warning."
                )
            else:
                fail_on_mismatch = (
                    str(config.get("fail_on_mismatch", True))
                    .strip().lower() not in {"false", "0", "no", "n", "f"}
                )
                _vt0 = datetime.now()
                actual_rows, actual_sums, mismatches = self._verify_output_completeness(
                    spark, output_path, fmt,
                    expected_rows=expected_rows,
                    expected_sums=expected_sums,
                    delimiter=config.get("delimiter", ","),
                    header=config.get("header", True),
                    fail_on_mismatch=fail_on_mismatch,
                )
                _vdt = (datetime.now() - _vt0).total_seconds()
                if mismatches:
                    self.logger.warning(
                        "Sink verify mismatches (fail_on_mismatch=%s, "
                        "took=%.1fs): %s",
                        fail_on_mismatch, _vdt, mismatches,
                    )
                else:
                    self.logger.info(
                        "Sink verify OK in %.1fs: %s rows + %d checksum cols matched.",
                        _vdt, f"{actual_rows:,}", len(expected_sums),
                    )
        elif expected_rows is not None and verify_max_rows and expected_rows > verify_max_rows:
            self.logger.info(
                "Sink verify AUTO-SKIPPED: expected_rows=%s exceeds "
                "verify_max_rows=%s.  Set verify_max_rows=0 to force "
                "verify regardless of size (costs an extra full Spark "
                "read).",
                f"{expected_rows:,}", f"{verify_max_rows:,}",
            )
        # 2026-06-20 -- Phase 152: register output for cleanup-on-failure
        # AND surface it in result.html's output_files list.
        self._register_output_artifact(task, output_path)
        return output_path, write_time

    @staticmethod
    def _materialise_single_part_file(
        staging_dir: str, output_path: str, fmt: str,
    ) -> None:
        """Move the lone ``part-*.{fmt}`` file out of ``staging_dir`` to
        ``output_path`` and remove the staging directory.

        Raises if Spark wrote zero or multiple part files (shouldn't
        happen with ``coalesce(1)`` but we'd rather fail loudly than
        produce a half-extracted result).
        """
        import glob as _glob
        import shutil as _shutil

        if not os.path.isdir(staging_dir):
            raise RuntimeError(
                f"Spark output staging directory {staging_dir} does not "
                f"exist — write step did not produce output"
            )
        pattern = os.path.join(staging_dir, S3QueryBase._SPARK_PART_GLOBS[fmt])
        part_files = _glob.glob(pattern)
        if not part_files:
            raise RuntimeError(
                f"No {fmt} part file in {staging_dir} — Spark wrote "
                f"nothing or wrote a different format than requested"
            )
        if len(part_files) > 1:
            raise RuntimeError(
                f"Multiple part files in {staging_dir} ({len(part_files)}) "
                f"— expected exactly one (coalesce(1) failed?)"
            )
        # Atomic rename when source + destination are on the same
        # filesystem (typical for NFS scratch dirs).  Pre-clear the
        # destination if a stale leftover sits there — handle BOTH
        # file and directory leftovers (a previous run that crashed
        # mid-write might have left ``output_path`` as a half-written
        # directory; ``os.remove`` would raise IsADirectoryError).
        if os.path.exists(output_path):
            if os.path.isdir(output_path):
                _shutil.rmtree(output_path)
            else:
                os.remove(output_path)
        _shutil.move(part_files[0], output_path)
        # Clean up the staging directory + its sidecar files (_SUCCESS
        # marker, .crc checksums).
        _shutil.rmtree(staging_dir, ignore_errors=True)

    @staticmethod
    def _set_delivery_chain_aliases(task: Dict, output_path: str) -> None:
        """Set every task-dict key the existing delivery steps look
        for so the s3_query Extract step can chain into ANY of them
        without contract-mismatch glue:

          * ``output_file``        — the s3_query Extract step's own key
          * ``consolidated_file``  — read by CompressFiles + CreateCTLFile
                                     so an Extract → Compress → CTL chain
                                     skips the unnecessary ConsolidateFiles
                                     (Spark already wrote a single file)
          * ``downloaded_files``   — read by ConsolidateFiles, so users
                                     who insist on a 5-step pipeline
                                     (Extract → Consolidate → Compress →
                                     CTL → Deliver) don't crash; the
                                     single-file consolidation is a
                                     no-op pass-through
        """
        task["output_file"]       = output_path
        task["consolidated_file"] = output_path
        task["downloaded_files"]  = [output_path]
