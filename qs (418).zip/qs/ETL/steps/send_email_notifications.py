"""Back-compat shim -- production yaml references
``steps.send_email_notifications``; real module at
``steps/file_to_oracle/send_email_notifications.py`` after Phase 150 reorg.
"""
from steps.file_to_oracle.send_email_notifications import *  # noqa: F401,F403
from steps.file_to_oracle.send_email_notifications import SendEmailNotifications  # noqa: F401
