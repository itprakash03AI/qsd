"""Back-compat shim -- production yaml references
``steps.starburst_to_oracle_onprem``; real module at
``steps/oracle/starburst_to_oracle_onprem.py`` after 3217462 refactor.
"""
from steps.oracle.starburst_to_oracle_onprem import *  # noqa: F401,F403
from steps.oracle.starburst_to_oracle_onprem import StarburstToOracle_OnPrem  # noqa: F401
