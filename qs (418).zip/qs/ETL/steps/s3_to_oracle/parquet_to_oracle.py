"""Plain parquet -> Oracle extract+load steps, per environment.

2026-06-22 -- back-compat path for non-iceberg parquet -> Oracle.

  ParquetToOracle_OnCloud  -- AWS S3 parquet -> Oracle via Spark JDBC.
  ParquetToOracle_OnPrem   -- On-prem S3 parquet -> Oracle.
"""
from __future__ import annotations

from steps.s3_to_oracle.s3_parquet_query_to_oracle import S3ParquetQueryToOracle


class ParquetToOracle_OnCloud(S3ParquetQueryToOracle):
    """AWS S3 parquet -> Oracle via Spark JDBC."""
    ENVIRONMENT = "oncloud"
    LOG_PREFIX = "parquet_to_oracle_oncloud"


class ParquetToOracle_OnPrem(S3ParquetQueryToOracle):
    """On-prem S3 parquet -> Oracle via Spark JDBC."""
    ENVIRONMENT = "onprem"
    LOG_PREFIX = "parquet_to_oracle_onprem"
