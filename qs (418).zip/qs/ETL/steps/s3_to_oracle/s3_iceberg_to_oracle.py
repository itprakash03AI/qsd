"""
S3 Iceberg → Oracle step.
Reads from an Iceberg table and writes to Oracle via JDBC.
Supports REST, Glue, and Hive Iceberg catalogs.
"""
from datetime import datetime
from typing import Dict, Any
from steps.s3.s3_base_step import S3BaseStep


class S3IcebergToOracle(S3BaseStep):
    """Read from Iceberg table and write to Oracle via JDBC."""

    LOG_PREFIX = "s3_iceberg_to_oracle"

    REQUIRED_FIELDS = [
        'oracle_url', 'oracle_user', 'oracle_password',
        's3_access_key', 's3_secret_key',
        'iceberg_table',
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        oracle_table = self._get_dest_table(task, config)
        iceberg_table = config['iceberg_table']
        catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')
        num_partitions = config.get('num_partitions', 10)
        batch_size = config.get('batch_size', 50000)
        where_filter = config.get('where_filter', '')

        full_table = f"{catalog_name}.{iceberg_table}"

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=True)

            # Read from Iceberg
            self.logger.info(f"Reading from Iceberg table: {full_table}")
            read_start = datetime.now()

            if where_filter:
                filter_sql = self._parameterize_query(where_filter, task)
                df = spark.read.format("iceberg").load(full_table).where(filter_sql)
            else:
                df = spark.read.format("iceberg").load(full_table)

            total_rows = df.count()
            read_time = (datetime.now() - read_start).total_seconds()
            self.logger.info(f"Read {total_rows} rows in {read_time:.2f}s")
            task['totalcount'] = total_rows

            # Write to Oracle via shared base method
            write_time = self._write_to_oracle(df, config, oracle_table, batch_size, num_partitions)

            self.logger.info(f"TOTAL TIME: {read_time + write_time:.2f}s")

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    spark.stop()
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
