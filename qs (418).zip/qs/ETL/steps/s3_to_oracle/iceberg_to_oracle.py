"""Iceberg -> Oracle extract+load steps, per environment.

2026-06-22 -- per-environment classes mirroring file-workflow shape.

  IcebergToOracle_OnCloud  -- AWS S3 iceberg -> Oracle via Spark JDBC.
                              Today's production path.
  IcebergToOracle_OnPrem   -- On-prem S3 iceberg -> Oracle.  Inactive
                              today; activates post-Hive-migration.
"""
from __future__ import annotations

from steps.s3_to_oracle.s3_iceberg_query_to_oracle import S3IcebergQueryToOracle


class IcebergToOracle_OnCloud(S3IcebergQueryToOracle):
    """AWS S3 iceberg -> Oracle via Spark JDBC."""
    ENVIRONMENT = "oncloud"
    LOG_PREFIX = "iceberg_to_oracle_oncloud"


class IcebergToOracle_OnPrem(S3IcebergQueryToOracle):
    """On-prem S3 iceberg -> Oracle (inactive today; awaiting on-prem
    migration off Hive)."""
    ENVIRONMENT = "onprem"
    LOG_PREFIX = "iceberg_to_oracle_onprem"
