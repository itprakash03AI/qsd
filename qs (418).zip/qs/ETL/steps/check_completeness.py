"""Oracle-workflow CheckDataCompleteness step.

2026-06-22 -- production yaml references ``steps.check_completeness``;
the oracle workflow needs a SIMPLE row-count check.  The oracle
workflow extract step (StarburstToOracle_OnCloud / _OnPrem) writes
data directly to Oracle JDBC -- no consolidated_file or compressed_file
artefacts to verify.

User's direction (2026-06-22):
  "oracle standalone doesn't consolidate files so we can't share oracle
   completeness check with file based workflow"

Per-workflow completeness checks are SEPARATE:
  * oracle workflow         -> steps/check_completeness.py (THIS FILE):
                                pure row-count check, no files
  * file_to_oracle workflow -> steps/file_to_oracle/check_completeness.py:
                                file row count == Oracle dest row count

This implementation:
  * Reads ``totalcount`` from task (set by the prior StarburstToOracle_*
    extract step via task['totalcount'] = total_rows)
  * Validates totalcount >= min_record_count (default 1)
  * Optionally caps at max_record_count
  * NO file artefact requirement
  * NO SAP base class

Matches the contract production CheckDataCompleteness expects -- row-only
verification with no file dependencies.
"""
from typing import Any, Dict

from steps.BaseStep import BaseStep


class CheckCompleteness(BaseStep):
    """Oracle-workflow row-count completeness check.  Pure in-process,
    no DB query, no file check.  Fails loud if extract step didn't
    populate totalcount or if count is below threshold."""

    LOG_PREFIX = "check_data_completeness"

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> Dict[str, Any]:
        self.logger.info(f"{step_name} has been started")
        run_id = task.get("run_id")
        report_id = task.get("fk_report_id")

        # Required: prior extract step set this.
        totalcount = task.get("totalcount")
        if totalcount is None:
            raise ValueError(
                f"CheckDataCompleteness: task['totalcount'] is unset for "
                f"run_id={run_id} report_id={report_id} -- the upstream "
                f"StarburstToOracle_OnCloud / _OnPrem extract step did "
                f"not record a row count.  Cannot certify completeness."
            )

        try:
            totalcount = int(totalcount)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"CheckDataCompleteness: task['totalcount']={totalcount!r} "
                f"is not an integer ({exc})."
            )

        # Optional thresholds from per-job config OR task fields.
        # 2026-06-22 -- read from task dict only (no JSON parse) since
        # per-job JSON shape varies across workflows.  Operators can
        # set MIN_RECORD_COUNT / MAX_RECORD_COUNT on the polling row.
        min_count = int(
            task.get("min_record_count")
            or task.get("MIN_RECORD_COUNT")
            or 1
        )
        max_raw = (
            task.get("max_record_count")
            or task.get("MAX_RECORD_COUNT")
        )

        if totalcount < min_count:
            raise ValueError(
                f"CheckDataCompleteness: row count {totalcount} is below "
                f"the configured minimum ({min_count}) for "
                f"run_id={run_id} report_id={report_id}.  Halting before "
                f"post-load processing so partial data does not advance."
            )

        if max_raw not in (None, ""):
            try:
                max_count = int(max_raw)
                if totalcount > max_count:
                    raise ValueError(
                        f"CheckDataCompleteness: row count {totalcount} "
                        f"exceeds the configured maximum ({max_count}) "
                        f"for run_id={run_id} report_id={report_id}.  "
                        f"Likely a misconfigured filter producing a "
                        f"runaway extract."
                    )
            except (TypeError, ValueError) as exc:
                self.logger.warning(
                    "CheckDataCompleteness: max_record_count=%r is not "
                    "parseable (%s); skipping upper-bound check.",
                    max_raw, exc,
                )

        self.logger.info(
            "%s OK: totalcount=%s passed thresholds (min=%s, max=%s) "
            "for run_id=%s report_id=%s",
            step_name, totalcount, min_count, max_raw, run_id, report_id,
        )

        return {
            "status": "SUCCESS",
            "totalcount": totalcount,
            "min_record_count": min_count,
            "max_record_count": max_raw,
        }
