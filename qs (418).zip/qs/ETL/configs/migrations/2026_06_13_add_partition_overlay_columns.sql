-- ============================================================================
--  Migration: ADD polling-row overlay columns for the file workflow's
--             partition-by / 170M-record hardening knobs.
--
--  Date:      2026-06-13
--  Purpose:   Let the operator drive every per-job extraction knob from the
--             Oracle polling table WITHOUT editing the per-query JSON file.
--
--  Background:
--    The file-flow Starburst step calls `_overlay_polling_row_onto_job_config`
--    at the top of `_build_scan_plan`.  Polling-row values overlay onto the
--    per-query JSON (path in `sql_query_path`) so operators with 100+ feeds
--    can tune per report_id by UPDATE-ing a single row instead of editing
--    JSON files.
--
--    Precedence:  polling row > per-query JSON > built-in default.
--    Empty / NULL polling-row values fall through to the JSON.
--
--  Sections:
--    1) ALTER TABLE  -- add the 10 most useful columns to OTG_DAG_TASK
--                       (the table behind Vw_otg_dag_task view).
--    2) ALTER VIEW   -- surface the new columns through Vw_otg_dag_task.
--    3) Sample UPDATE statements to populate the 170M report.
--    4) Verify queries.
--
--  Rollback at the very bottom (DROP COLUMNS) -- comment-blocked for safety.
--
--  IMPORTANT: Run AS the schema owner.  Connect to the OTG/ETL schema first.
--             If your table name is NOT `OTG_DAG_TASK`, search-and-replace
--             the table name throughout this file before running.
-- ============================================================================


-- ============================================================================
-- SECTION 1: ALTER TABLE -- add the 10 polling-overlay columns
-- ============================================================================
--
-- Only the columns most useful for 170M-record partition-by runs.  See the
-- full overlay table in steps/file/starburst_file_base.py
-- (_POLLING_ROW_OVERLAYS) for ALL 17 supported columns -- add others as
-- needed using the same pattern.
--
-- All columns NULLable so existing rows keep working (overlay skips NULLs).
-- Booleans stored as VARCHAR2(5) so 'TRUE' / 'FALSE' / 'Y' / 'N' all work.
-- ============================================================================

ALTER TABLE OTG_DAG_TASK ADD (
    -- ── Partition mode (drives Trino into PARTITION_VALUES scan) ──────
    PARTITION_COLUMN              VARCHAR2(60)  NULL,
    PARTITION_ENABLED             VARCHAR2(5)   NULL,
    MAX_PARTITIONS                NUMBER        NULL,
    DISCOVERY_MODE                VARCHAR2(20)  NULL,

    -- ── G1 acquisition (170M COUNT(*) avoidance) ──────────────────────
    DERIVE_G1_FROM_DISCOVERY      VARCHAR2(5)   NULL,
    SKIP_PRE_FLIGHT_COUNT         VARCHAR2(5)   NULL,

    -- ── Disk-space pre-flight (avoid 8-hour run that runs out at hour 5) ─
    AVG_ROW_BYTES                 NUMBER        NULL,
    DISK_SAFETY_FACTOR            NUMBER(5, 2)  NULL,

    -- ── Streaming / retry timeouts ────────────────────────────────────
    WRITER_IDLE_TIMEOUT_SECONDS   NUMBER        NULL,
    MAX_CHUNK_RETRIES             NUMBER        NULL
);


-- Column comments for the DBA crowd reading the data dictionary.

COMMENT ON COLUMN OTG_DAG_TASK.PARTITION_COLUMN IS
'Trino column to slice the extract on (e.g. ''business_date'', ''region'').  When set AND partition mode is enabled, the Starburst step decomposes ONE 170M-row query into N small per-partition queries.  NULL = inherit from per-query JSON partition_config.partition_column.';

COMMENT ON COLUMN OTG_DAG_TASK.PARTITION_ENABLED IS
'Force PARTITION_VALUES mode regardless of per-query JSON.  TRUE/Y/1 = enabled.  Use when the polling row routes to a non-_ByPartitions class but the operator wants partition mode anyway.  NULL = inherit from per-query JSON.';

COMMENT ON COLUMN OTG_DAG_TASK.MAX_PARTITIONS IS
'Safety cap on partition discovery.  Trino discovery raises if the partition_column has more than this many distinct values.  Default 500 in per-query JSON; bump only after verifying the column is low-cardinality.';

COMMENT ON COLUMN OTG_DAG_TASK.DISCOVERY_MODE IS
'How partition values are enumerated.  ''group_by'' (default) = one query with COUNT(*) per partition.  ''distinct'' = SELECT DISTINCT only -- avoids GROUP BY shuffle on high-cardinality columns at the cost of dropping per-partition counts (G4 ledger becomes advisory).';

COMMENT ON COLUMN OTG_DAG_TASK.DERIVE_G1_FROM_DISCOVERY IS
'When TRUE (default for partition mode), skip the separate SELECT COUNT(*) pre-flight and derive G1 from the partition discovery sum.  Saves one full Trino scan (~5-15 min on 170M).  Set FALSE only if you need the COUNT(*) cross-check.';

COMMENT ON COLUMN OTG_DAG_TASK.SKIP_PRE_FLIGHT_COUNT IS
'Force NO pre-flight COUNT(*) regardless of mode.  G1 becomes ''measured from extract'' -- expected_total = sum(chunk actuals) at run end.  G3 becomes identity-true; G5 (consolidated == sum_actuals) still proves merge integrity.  Use ONLY when COUNT(*) itself times out / OOMs on >200M tables with arbitrary base_sql.';

COMMENT ON COLUMN OTG_DAG_TASK.AVG_ROW_BYTES IS
'Estimated bytes per row, used to size the pre-flight disk-space check (need = expected_rows * avg_row_bytes * disk_safety_factor).  Default 200 (typical fact-table row).  Bump to 500-1000 for very wide tables (200+ columns) so the disk guard reflects actual footprint.';

COMMENT ON COLUMN OTG_DAG_TASK.DISK_SAFETY_FACTOR IS
'Multiplier on the disk-space estimate to cover chunks + per-source consolidated + final merged + headroom.  Default 4.0.  Drop to 2.5-3.0 for uncompressed-only workflows; raise to 5-6 for compress + multiple deliverable copies.';

COMMENT ON COLUMN OTG_DAG_TASK.WRITER_IDLE_TIMEOUT_SECONDS IS
'How long the ChunkWriter waits between Trino fetchmany() returns before raising idle-timeout.  Default 600 (10 min).  Bump to 1800 (30 min) for 170M+ runs where huge partitions can gap >10 min between fetches on slow Trino clusters / slow NFS.';

COMMENT ON COLUMN OTG_DAG_TASK.MAX_CHUNK_RETRIES IS
'Per-chunk retry budget when a partition hits a RETRYABLE Trino error (timeout / OOM / 503 / connection reset).  Default 2 (so 3 total attempts).  Bump to 3 for 170M runs where Trino transient errors are more likely.';


-- ============================================================================
-- SECTION 2: ALTER VIEW Vw_otg_dag_task -- surface the new columns
-- ============================================================================
--
-- The file-flow polling YAML (etl_polling_task_query.yaml) reads from
-- Vw_otg_dag_task.  If the view explicitly lists columns (most common
-- pattern), add the new ones to the SELECT.
--
-- Customize the view DDL below to match your environment.  If the view is
-- defined as `SELECT * FROM OTG_DAG_TASK`, you can skip this section --
-- the new columns flow through automatically.
-- ============================================================================

-- Uncomment + adjust to match the actual existing view definition.
-- Run `SELECT TEXT FROM USER_VIEWS WHERE VIEW_NAME = 'VW_OTG_DAG_TASK';`
-- first to capture the current shape.
--
-- CREATE OR REPLACE VIEW Vw_otg_dag_task AS
-- SELECT
--     <existing columns ...>,
--     PARTITION_COLUMN,
--     PARTITION_ENABLED,
--     MAX_PARTITIONS,
--     DISCOVERY_MODE,
--     DERIVE_G1_FROM_DISCOVERY,
--     SKIP_PRE_FLIGHT_COUNT,
--     AVG_ROW_BYTES,
--     DISK_SAFETY_FACTOR,
--     WRITER_IDLE_TIMEOUT_SECONDS,
--     MAX_CHUNK_RETRIES
--   FROM OTG_DAG_TASK
--   WHERE <existing predicates ...>;


-- ============================================================================
-- SECTION 3: Sample UPDATE -- populate the 170M report
-- ============================================================================
--
-- Adjust the WHERE clause to match the operator's actual report.  This is
-- the example for the FLEX_GSIB_FLEXREP_MONTHEND_V4 report at 170M:
-- ============================================================================

UPDATE OTG_DAG_TASK
   SET PARTITION_COLUMN             = 'business_date'  -- low-cardinality slice
     , PARTITION_ENABLED            = 'TRUE'
     , MAX_PARTITIONS               = 500
     , DERIVE_G1_FROM_DISCOVERY     = 'TRUE'           -- skip redundant COUNT(*)
     , WRITER_IDLE_TIMEOUT_SECONDS  = 1800             -- 30-min idle tolerance
     , MAX_CHUNK_RETRIES            = 3                -- 4 total attempts
     , AVG_ROW_BYTES                = 200              -- estimate for disk guard
     , DISK_SAFETY_FACTOR           = 4.0
 WHERE FK_DAG_ID    = 'FLEX_GSIB_FLEXREP_MONTHEND_V4'
   AND FK_REPORT_ID = 31
   AND TASK_TYPE IN (
       'StarburstToFile_OnCloud'                -- non-by-partitions class:
     , 'StarburstToFile_OnPrem'                 -- the overlay forces partition mode
     , 'StarburstToFile_OnCloud_ByPartitions'   -- by-partitions class: still benefits
     , 'StarburstToFile_OnPrem_ByPartitions'    --   from the tuning knobs
   );

COMMIT;


-- ============================================================================
-- SECTION 4: Verify -- confirm columns are there and populated
-- ============================================================================

-- 1) Confirm columns exist on the table.
SELECT COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NULLABLE
  FROM USER_TAB_COLUMNS
 WHERE TABLE_NAME = 'OTG_DAG_TASK'
   AND COLUMN_NAME IN (
       'PARTITION_COLUMN', 'PARTITION_ENABLED', 'MAX_PARTITIONS',
       'DISCOVERY_MODE', 'DERIVE_G1_FROM_DISCOVERY',
       'SKIP_PRE_FLIGHT_COUNT', 'AVG_ROW_BYTES', 'DISK_SAFETY_FACTOR',
       'WRITER_IDLE_TIMEOUT_SECONDS', 'MAX_CHUNK_RETRIES'
   )
 ORDER BY COLUMN_NAME;

-- 2) Confirm the UPDATE landed on the rows you expected.
SELECT FK_DAG_ID, FK_REPORT_ID, TASK_TYPE, SEQ,
       PARTITION_COLUMN, PARTITION_ENABLED, MAX_PARTITIONS,
       DERIVE_G1_FROM_DISCOVERY, WRITER_IDLE_TIMEOUT_SECONDS,
       MAX_CHUNK_RETRIES, AVG_ROW_BYTES, DISK_SAFETY_FACTOR
  FROM OTG_DAG_TASK
 WHERE FK_DAG_ID    = 'FLEX_GSIB_FLEXREP_MONTHEND_V4'
   AND FK_REPORT_ID = 31
 ORDER BY SEQ;

-- 3) Confirm the polling view surfaces them.  Adjust :bd / :dag as needed.
-- SELECT FK_DAG_ID, FK_REPORT_ID, TASK_TYPE,
--        PARTITION_COLUMN, PARTITION_ENABLED, MAX_PARTITIONS
--   FROM Vw_otg_dag_task
--  WHERE FK_DAG_ID    = 'FLEX_GSIB_FLEXREP_MONTHEND_V4'
--    AND FK_REPORT_ID = 31;


-- ============================================================================
-- ROLLBACK (commented for safety -- uncomment + run ONLY to undo)
-- ============================================================================
--
-- ALTER TABLE OTG_DAG_TASK DROP (
--     PARTITION_COLUMN,
--     PARTITION_ENABLED,
--     MAX_PARTITIONS,
--     DISCOVERY_MODE,
--     DERIVE_G1_FROM_DISCOVERY,
--     SKIP_PRE_FLIGHT_COUNT,
--     AVG_ROW_BYTES,
--     DISK_SAFETY_FACTOR,
--     WRITER_IDLE_TIMEOUT_SECONDS,
--     MAX_CHUNK_RETRIES
-- );
--
-- After rollback, re-run section 2 to restore the original view DDL.

-- ============================================================================
-- END OF MIGRATION
-- ============================================================================
