"""SAP OData polling-driven entry point.

Structural clone of ``oracle_standalone.py`` / ``s3_query_standalone.py``.
Airflow triggers ONE pod per RUN_ID (--report_id + --business_date +
--dag_id); cross-pod safety is owned by the polling SERVICE (poller.py),
not the standalone — Airflow already guarantees one invocation per
RUN_ID.

Differences vs Oracle:
  * Loads ``polling_query_sap`` instead of ``polling_query_sb_to_oracle``.
  * Uses ``SapOdataWorker`` (no Starburst clients — SAP OData is the source).
  * No ``cleanup_old_spark_uploads()`` — SAP runs via KubernetesPodOperator
    in a lightweight Python pod (HTTP download), not spark-submit.

All per-row knobs (SAPU / SAPP / SAP_*_API URLs / P_GJAHR / P_POPER /
RUN_TIMESTAMP / NUM_GROUPS) live on the polling row.  The standalone
takes only the three polling-query bind values plus the oracle-config
YAML path.
"""
from __future__ import annotations

# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
# 2026-06-21 bug #13.  See file_standalone.py for full explanation.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="sap_odata",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    pass
# === END PREFLIGHT BOOTSTRAP ===

import argparse
import asyncio
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import yaml

# Make the ETL tree importable when run as a script.  Probe well-known
# roots for the log_config sentinel -- spark-submit / KubernetesPod
# uploads can land the script in a temp dir without the rest of the
# package.  See file_standalone.py for the full rationale.
_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",
    "/usr/local/spark/pvc/code/etl",
    "/usr/local/spark/pvc",
    str(Path(__file__).resolve().parent),
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from log_config import get_log_dir as _get_log_dir, set_run_log_file
from managers.oracle_metadata_manager import OracleMetadataManager
from workers.sap_odata_worker import SapOdataWorker


LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Default paths.  Prod (pod) layout first; falls back to the in-repo
# ``config/`` folder so local Windows runs work without a /usr/local/...
# mount.  CLI flags still override.
_PROD_CONFIG_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_PROD_QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
_LOCAL_CONFIG_PATH = os.path.join(ETL_ROOT, "configs", "oracle_config.yaml")
_LOCAL_QUERIES_PATH = os.path.join(ETL_ROOT, "configs", "etl_polling_task_query.yaml")


def _resolve_path(prod: str, local: str) -> str:
    """Return prod path if it exists, otherwise the in-repo local path."""
    return prod if os.path.exists(prod) else local

# Console-only logger at startup (file handler added after args parsed).
logger = logging.getLogger("sap_odata_standalone")
logger.setLevel(logging.INFO)
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter(LOG_FMT))
logger.addHandler(_sh)


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that identifies this batch execution.

    Format: ``sap_odata_{dag_id}_{report_id}_{business_date}_{HHMMSS}.log``
    """
    safe_dag = str(dag_id).replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"sap_odata_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    return os.path.join(LOG_DIR, filename)


def _attach_file_handler(log_file: str) -> None:
    """Add file handler to the module logger after we know the batch context."""
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.FileHandler(log_file)
        fh.setFormatter(logging.Formatter(LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} — console only")


async def execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    run_report=None,
    artifacts=None,
) -> None:
    """Execute all SAP OData task steps for one RUN_ID based on dynamic sequence.

    2026-06-20 -- accepts optional ``run_report`` + ``artifacts`` from the
    StandaloneRunLifecycle so this pipeline has the SAME operator-facing
    visibility as the file flow (result.html, start/finish email,
    cleanup-on-failure).
    """
    if not tasks or not worker_connection_string:
        raise ValueError("Tasks and worker_connection_string are required")

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Create SapOdataWorker ONCE — reused for all steps in this run.
    worker = SapOdataWorker(oracle_data_manager, logger)

    for task in tasks:
        task["log_file"] = log_file
        if run_report is not None:
            task["_run_report"] = run_report
        if artifacts is not None:
            task["_run_artifacts"] = artifacts

        logger.info(
            f"Executing task {task.get('run_id')} with DAG_ID: {task.get('fk_dag_id')} "
            f"and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} "
            f"(SEQ: {task.get('seq')})"
        )

        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}"
            )
            # 2026-06-20 -- propagate so StandaloneRunLifecycle catches
            # the failure, runs cleanup, sends the failure email.
            raise


async def main() -> None:
    """Main function — mirrors ``oracle_standalone.main`` exactly."""
    parser = argparse.ArgumentParser(
        description="Execute a SAP OData task for a specific report ID and business date.",
    )
    parser.add_argument(
        "--report_id", type=int, required=True,
        help="The report ID to process.",
    )
    parser.add_argument(
        "--business_date", type=str, required=True,
        help='The business date to process (e.g., "2025-07-10").',
    )
    parser.add_argument(
        "--dag_id", type=str, required=True,
        help="The DAG ID to process.",
    )
    parser.add_argument(
        "--config_path", type=str,
        default=_resolve_path(_PROD_CONFIG_PATH, _LOCAL_CONFIG_PATH),
        help="Path to the configuration file.",
    )
    parser.add_argument(
        "--queries_path", type=str,
        default=_resolve_path(_PROD_QUERIES_PATH, _LOCAL_QUERIES_PATH),
        help="Path to etl_polling_task_query.yaml.",
    )
    parser.add_argument("--no-auto-install", action="store_true",
                          help="Skip auto-install of missing REQUIRED packages")
    parser.add_argument("--no-install-optional", action="store_true",
                          help="Skip auto-install of OPTIONAL packages")

    args = parser.parse_args()

    # 2026-06-21 -- preflight already ran at top-of-file bootstrap.
    # Honour CLI opt-outs for explicit re-check.
    if args.no_auto_install or args.no_install_optional:
        try:
            from preflight import preflight_check
            preflight_check(
                workflow="sap_odata",
                auto_install=not args.no_auto_install,
                install_optional=not args.no_install_optional,
            )
        except ImportError:
            pass

    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    # Pin EVERY build_module_logger() call (oracle_metadata_manager,
    # step_executor, …) to this exact file so the whole run lives in
    # one log file end-to-end.
    set_run_log_file(log_file)

    logger.info(
        f"Starting SAP OData batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    # Load queries from YAML
    queries_path = args.queries_path
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")

    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)

    if "polling_query_sap" not in queries:
        raise ValueError(
            "polling_query_sap not found in etl_polling_task_query.yaml"
        )

    # Establish database connections.  dest_connection_string is optional
    # for SAP (no SAP step writes to a destination Oracle); kept as a
    # positional arg for interface parity with OracleWorker.execute_step.
    # 2026-06-22 -- routes through oracle_config_loader so vault-based
    # secret_ref resolution fires when ETL_USE_VAULT=1.
    from oracle_config_loader import (
        resolve_etl_connection_string,
        resolve_dest_connection_string,
    )
    worker_connection_string = resolve_etl_connection_string(config)
    dest_connection_string = resolve_dest_connection_string(config)
    if not worker_connection_string:
        raise ValueError(
            "ETL Oracle connection string unresolved.  Set yaml literal, "
            "oracle.etl.secret_ref (vault), or ETL_ORACLE_CONN env var."
        )

    # Fetch all tasks from database using OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # execute_query_asynch returns a DataFrame — convert to list of dicts
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_sap"],
        {
            "1": args.report_id,
            "2": args.business_date,
            "3": args.dag_id,
        },
        worker_connection_string,
    )

    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    # Convert DataFrame rows to list of dicts for downstream consumption
    tasks = tasks_df.to_dict(orient='records')

    # Normalize column names to lowercase for consistent access
    tasks = [{k.lower(): v for k, v in row.items()} for row in tasks]

    # Normalize tasks
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    # 2026-06-20 -- StandaloneRunLifecycle gives this pipeline operator-
    # facing parity with the file flow: result.html, start/finish email,
    # cleanup-on-failure registry.
    from standalone_lifecycle import StandaloneRunLifecycle
    async with StandaloneRunLifecycle(
        pipeline="sap_odata",
        dag_id=args.dag_id,
        report_id=args.report_id,
        business_date=args.business_date,
        log_file=log_file,
        config=config,
        sample=tasks[0],
        logger=logger,
    ) as lc:
        await execute_tasks(
            tasks, config, worker_connection_string, dest_connection_string,
            log_file, run_report=lc.run_report, artifacts=lc.artifacts,
        )


if __name__ == "__main__":
    asyncio.run(main())
