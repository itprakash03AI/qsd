"""Shared Starburst (Trino) credential loader.

2026-06-12 — collapses the three duplicated credential sources into
one fallback chain that every Starburst code path consults.

Resolution order (highest priority wins):
  1. Per-job JSON config (``trino_user``, ``trino_password``,
     ``trino_oncloud_url``, ``trino_onprem_url`` keys).  Already
     respected by ``light_starburst_base`` and the file workflow
     steps.
  2. Polling-row ``C_USERNAME`` / ``C_PWD`` / ``P_USERNAME`` /
     ``P_PWD`` columns.  Already respected by
     ``dispatcher._build_starburst_clients``.
  3. ``$EXPORT_TOOL_CONFIG_PATH`` INI ``[Starburst]`` / ``[Starburst-Cloud]``.
     Already respected by the file workflow steps.
  4. THIS FILE — ``configs/starburst_config.yaml``.
  5. Environment variables: ``STARBURST_USER``, ``STARBURST_PASSWORD``,
     ``STARBURST_ONCLOUD_URL``, ``STARBURST_ONPREM_URL``,
     ``STARBURST_ONCLOUD_USER``, ``STARBURST_ONPREM_USER``,
     ``STARBURST_ONCLOUD_PASSWORD``, ``STARBURST_ONPREM_PASSWORD``.

The loader itself exposes one knob: ``shared_creds_for(endpoint)``
returning a dict with keys user, password, url, host, port, catalog,
schema.  Empty strings for unset fields — callers decide whether a
missing value is fatal at their site.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


_PROD_PATH = "/usr/local/spark/pvc/code/configs/starburst_config.yaml"
_LOCAL_PATH = str(
    Path(__file__).resolve().parent / "configs" / "starburst_config.yaml"
)

_ENDPOINTS = ("oncloud", "onprem")

# Per-process logger so the warning shows up wherever the host
# already configured logging (standalones, polling-service main).
_logger = logging.getLogger("starburst_config_loader")


def _load_yaml() -> Dict[str, Any]:
    """Load the shared YAML.  Returns {} if no file is present anywhere.

    A YAML parse error logs a WARNING and falls through to env vars —
    silent swallow was the prior behaviour and made typos in
    starburst_config.yaml produce confusing 'missing credentials'
    errors at the call site instead of a clear 'config is malformed'.
    """
    for path in (_PROD_PATH, _LOCAL_PATH):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except yaml.YAMLError as exc:
                _logger.warning(
                    "starburst_config.yaml at %s is malformed (%s) — "
                    "ignoring file, falling back to STARBURST_* env vars. "
                    "Fix the YAML and restart the pod to pick up changes.",
                    path, exc,
                )
                return {}
            except OSError as exc:
                _logger.warning(
                    "Cannot read starburst_config.yaml at %s (%s) — "
                    "falling back to STARBURST_* env vars.",
                    path, exc,
                )
                return {}
    return {}


@lru_cache(maxsize=1)
def load_shared_starburst_config() -> Dict[str, Any]:
    """Cached parse of the ``starburst`` top-level section.

    Cache scope is per-process; tests call ``reset_cache()`` to
    re-read after writing temp files.
    """
    return _load_yaml().get("starburst", {}) or {}


def reset_cache() -> None:
    """Drop the cached parse (test hook)."""
    load_shared_starburst_config.cache_clear()


_FIELD_LABELS = {
    "host": "starburst.{ep}.host       (Trino coordinator hostname)",
    "port": "starburst.{ep}.port       (Trino coordinator port, e.g. 443)",
    "user": "starburst.{ep}.user       (or root starburst.user)",
    "password": "starburst.{ep}.password   (or root starburst.password)",
    "catalog": "starburst.{ep}.catalog    (Trino catalog name)",
    "schema": "starburst.{ep}.schema     (Trino schema name)",
}


def validate_starburst_yaml(
    endpoint: str,
    required_fields: List[str],
    yaml_path_hint: Optional[str] = None,
) -> None:
    """Hard-fail when any required field in ``shared_creds_for(endpoint)``
    is empty / zero / whitespace.  Used by file-workflow code paths that
    treat yaml as the authoritative source for connection details.

    Raises ``ValueError`` with a field-by-field checklist so the operator
    can fix the yaml in one edit.

    Args:
      endpoint: ``"oncloud"`` or ``"onprem"``.
      required_fields: subset of ``("host", "port", "user", "password",
        "catalog", "schema")`` to validate.
      yaml_path_hint: extra hint string appended to the error (e.g.,
        the file path the loader probed).  Useful when multiple yaml
        paths exist on the same host.
    """
    shared = shared_creds_for(endpoint)
    missing = []
    for f in required_fields:
        val = shared.get(f, "")
        if val is None:
            missing.append(f)
            continue
        s = str(val).strip()
        if not s or s in ("0",):
            missing.append(f)
    if not missing:
        return

    bullets = "\n".join(
        f"  * {_FIELD_LABELS.get(f, f).format(ep=endpoint)}"
        for f in missing
    )
    hint = f"\nYAML path probed: {yaml_path_hint}\n" if yaml_path_hint else ""
    raise ValueError(
        f"starburst_config.yaml -> '{endpoint}' section has EMPTY required "
        f"field(s).  Fill ALL of these in the yaml (or set the matching "
        f"STARBURST_* env vars):\n{bullets}\n"
        f"Missing values cause silent TCP connect timeouts at extract "
        f"time -- validate early to fail loud instead.{hint}\n"
        f"Edit one of:\n"
        f"  * (production) /usr/local/spark/pvc/code/configs/starburst_config.yaml\n"
        f"  * (local dev ) ETL/configs/starburst_config.yaml\n"
        f"and restart the pod / process to pick up changes."
    )


def shared_creds_for(endpoint: str) -> Dict[str, str]:
    """Resolve credentials + URL + host/port + catalog/schema for ONE endpoint.

    Resolution order (highest priority wins per field):
      1. yaml endpoint section (user / password / url / host / ...)
      2. yaml root-level user / password (for shared creds)
      3. vault via secret_ref (when user OR password is yaml-blank
         AND ep_cfg has secret_ref set)
      4. STARBURST_* environment variables

    Args:
      endpoint: ``"oncloud"`` or ``"onprem"``.

    Returns: dict with keys ``user``, ``password``, ``url``, ``host``,
    ``port``, ``catalog``, ``schema``.
    """
    if endpoint not in _ENDPOINTS:
        raise ValueError(
            f"endpoint must be one of {_ENDPOINTS}, got {endpoint!r}"
        )

    cfg = load_shared_starburst_config()
    ep_cfg = cfg.get(endpoint, {}) or {}

    suffix = endpoint.upper()
    user = (
        ep_cfg.get("user")
        or cfg.get("user")
        or ""
    )
    password = (
        ep_cfg.get("password")
        or cfg.get("password")
        or ""
    )

    # 2026-06-22 -- vault resolution.  When yaml user/password is blank
    # AND ep_cfg has secret_ref, fetch from vault via qs_credentials.
    # See ETL/qs_credentials/resolver.py for the contract.
    secret_ref = (ep_cfg.get("secret_ref") or "").strip()
    if secret_ref and (not user or not password):
        try:
            from qs_credentials import resolve_ad_account
            # Pass the starburst top-level dict so per-workflow
            # ``vault_enabled`` flag is honoured by is_vault_enabled().
            v_user, v_pass = resolve_ad_account(secret_ref, workflow_config=cfg)
            if not user:
                user = v_user
            if not password:
                password = v_pass
            _logger.info(
                "Starburst %s: fetched user/password from VAULT "
                "(secret_ref=%r, user=%r)",
                endpoint, secret_ref, user,
            )
        except (ImportError, RuntimeError, ValueError) as exc:
            _logger.warning(
                "Starburst %s: vault resolution for secret_ref=%r failed "
                "(%s) -- falling back to env vars.", endpoint, secret_ref, exc,
            )

    # Env-var fallback (last layer).
    user = user or os.environ.get(f"STARBURST_{suffix}_USER") \
        or os.environ.get("STARBURST_USER") or ""
    password = password or os.environ.get(f"STARBURST_{suffix}_PASSWORD") \
        or os.environ.get("STARBURST_PASSWORD") or ""

    url = (
        ep_cfg.get("url")
        or os.environ.get(f"STARBURST_{suffix}_URL")
        or ""
    )
    return {
        "user": str(user),
        "password": str(password),
        "url": str(url),
        "host": str(ep_cfg.get("host") or ""),
        "port": str(ep_cfg.get("port") or "443"),
        "catalog": str(ep_cfg.get("catalog") or ""),
        "schema": str(ep_cfg.get("schema") or ""),
    }


def build_starburst_clients_from_row(
    first_task: Dict[str, Any],
    starburst_datasource_cls: Any,
    *,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Build the ``{cloud, pres, use_99}`` Starburst-clients dict that
    every Spark-Oracle code path expects.

    Single source of truth for the polling-row -> shared-YAML
    fallback chain.  Called from BOTH
    ``polling_service.dispatcher._build_starburst_clients`` AND
    ``oracle_standalone.execute_tasks`` so the two paths can't drift.

    Resolution per field:
      polling-row column > shared starburst_config.yaml > STARBURST_* env vars

    Args:
      first_task: lowercase-keyed task dict from the polling query.
      starburst_datasource_cls: the StarburstDataSource class injected
        by the caller (avoids a hard import here so this module stays
        importable in pods that don't ship starburst_datasource).
      logger: optional logger for the warning when the loader can't
        find a shared YAML.

    Returns:
      ``{"cloud": StarburstDataSource(cfg), "pres": StarburstDataSource(cfg),
         "use_99": True}``
    """
    log = logger or _logger
    try:
        cloud_shared = shared_creds_for("oncloud")
        prem_shared = shared_creds_for("onprem")
    except Exception as exc:  # pragma: no cover — defensive
        log.warning(
            "shared Starburst loader failed (%s) — polling row is the "
            "only credential source for this dispatch", exc,
        )
        cloud_shared = {"user": "", "password": "", "host": "",
                        "port": "443", "catalog": "", "schema": ""}
        prem_shared = dict(cloud_shared)

    def _port(row_val: Any, shared_val: str) -> int:
        if row_val:
            try:
                return int(row_val)
            except (TypeError, ValueError):
                pass
        try:
            return int(shared_val or "443")
        except (TypeError, ValueError):
            return 443

    cloud_config = {
        "host":     first_task.get("c_hostname")  or cloud_shared["host"],
        "port":     _port(first_task.get("c_port"), cloud_shared["port"]),
        "user":     first_task.get("c_username")  or cloud_shared["user"],
        "password": first_task.get("c_pwd")       or cloud_shared["password"],
        "catalog":  first_task.get("c_catalog")   or cloud_shared["catalog"],
        "schema":   first_task.get("c_schemainfo") or cloud_shared["schema"],
    }
    pres_config = {
        "host":     first_task.get("p_hostname")  or prem_shared["host"],
        "port":     _port(first_task.get("p_port"), prem_shared["port"]),
        "user":     first_task.get("p_username")  or prem_shared["user"],
        "password": first_task.get("p_pwd")       or prem_shared["password"],
        "catalog":  first_task.get("p_catalog")   or prem_shared["catalog"],
        "schema":   first_task.get("p_schemainfo") or prem_shared["schema"],
    }

    # 2026-06-22 -- validate per-endpoint CREDENTIALS only.  Host /
    # port / catalog / schema are per-job and may travel via per-job
    # JSON or polling row -- the dispatcher does NOT enforce them here.
    # If user OR password is missing AND the endpoint has any other
    # field set (i.e., consumer intends to USE this endpoint), fail
    # loud with a clear cred-source checklist.
    _validate_resolved_creds(
        cloud_config, label="oncloud (polling-row C_* + yaml oncloud)",
        logger=log, env_prefix="STARBURST_ONCLOUD_",
    )
    _validate_resolved_creds(
        pres_config, label="onprem (polling-row P_* + yaml onprem)",
        logger=log, env_prefix="STARBURST_ONPREM_",
    )
    return {
        "cloud":  starburst_datasource_cls(cloud_config),
        "pres":   starburst_datasource_cls(pres_config),
        "use_99": True,
    }


def _validate_resolved_creds(
    cfg: Dict[str, Any],
    label: str,
    logger: logging.Logger,
    env_prefix: str = "STARBURST_",
) -> None:
    """Validate that a resolved Starburst endpoint config has user +
    password set (when the endpoint is intended for use).

    Detection: an endpoint is "intended for use" when host OR user OR
    any other field is non-blank.  Fully-blank endpoint means
    single-source job -- caller branches.

    Cred-only validation (host/port/catalog/schema not checked here)
    because those are per-job and travel via per-job JSON.
    """
    if not any(_is_filled(cfg.get(k)) for k in ("host", "user", "password", "catalog", "schema")):
        # Fully blank endpoint -- e.g., job has CLOUD source only.
        logger.info(
            "Starburst endpoint %s is fully blank -- treating as "
            "'not configured' (single-source job).", label,
        )
        return
    missing = []
    if not _is_filled(cfg.get("user")):
        missing.append(f"user (yaml: starburst.user; env: {env_prefix}USER)")
    if not _is_filled(cfg.get("password")):
        missing.append(f"password (yaml: starburst.password; env: {env_prefix}PASSWORD)")
    if missing:
        raise ValueError(
            f"Starburst endpoint {label}: missing required credential(s):\n"
            + "".join(f"  * {m}\n" for m in missing)
            + "Fill the credentials in configs/starburst_config.yaml "
            "OR set the env vars OR populate the polling-row "
            "C_USERNAME/C_PWD (cloud) / P_USERNAME/P_PWD (on-prem) columns."
        )


def _is_filled(v: Any) -> bool:
    """A field is 'filled' when it's not None / not empty-string /
    not whitespace-only / not the literal '0'.  Used by partial-config
    validation."""
    if v is None:
        return False
    s = str(v).strip()
    return bool(s) and s != "0"


def merge_shared_into_job_config(
    config: Dict[str, Any],
    *,
    trino_url_key: str,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """In-place merge of the shared YAML into a per-job JSON config.

    Used by ``light_starburst_base`` AND ``starburst_base`` (Spark)
    to provide ``trino_user`` / ``trino_password``.

    2026-06-22 -- SCOPE NARROWED to CREDENTIALS ONLY (user + password).

    User direction:
      "starburst to file referring [that] only starburst related
       credentials will come from starburst_config.yaml"
      "oracle has oracle config across workflows"
      "fact_query.json per job is diff ... comes via polling query
       in case of oracle standalone"

    Rationale: ``trino_*_url`` is per-job (different host/catalog/
    schema per source) and arrives via polling query -> per-job JSON.
    Pulling URLs from yaml would force one yaml per source, defeating
    the centralisation goal.  Credentials, in contrast, are typically
    shared across all jobs in a cluster -- those belong in yaml.

    Precedence:
      * user / password    -> YAML wins (when set) over per-job JSON,
                              then env STARBURST_* via shared_creds_for
      * trino_*_url        -> per-job JSON ONLY (this function does
                              NOT touch URLs; caller reads the JSON
                              key directly)

    Args:
      config: the loaded per-job JSON dict (mutated in place).
      trino_url_key: ``"trino_oncloud_url"`` or ``"trino_onprem_url"``
        -- used solely to derive the endpoint (oncloud / onprem)
        for picking the right yaml section.
      logger: optional logger to receive INFO lines about overrides.

    Returns: the same config dict (for chaining).
    """
    log = logger or _logger
    try:
        endpoint = "oncloud" if "oncloud" in trino_url_key else "onprem"
        shared = shared_creds_for(endpoint)

        def _apply_cred(yaml_key: str, json_key: str) -> None:
            yaml_val = shared.get(yaml_key) or ""
            if not yaml_val:
                # YAML blank -- leave per-job JSON value (or absence) alone.
                return
            json_val = config.get(json_key) or ""
            if json_val and json_val != yaml_val:
                log.info(
                    "Starburst %s: YAML override active "
                    "(per-job JSON %s ignored in favour of shared YAML)",
                    json_key,
                    "***" if "password" in json_key else repr(json_val),
                )
            config[json_key] = yaml_val

        _apply_cred("user", "trino_user")
        _apply_cred("password", "trino_password")
        # URLs (trino_oncloud_url / trino_onprem_url) intentionally
        # NOT touched -- they're per-job, come from the polling-query
        # output JSON.  Caller reads config[trino_url_key] directly.

        # Validate final state: AFTER yaml merge + env fill, trino_user
        # AND trino_password MUST be non-empty.  Empty creds cause
        # 401 / silent timeout at extract -- fail loud here instead.
        for cred_key in ("trino_user", "trino_password"):
            v = config.get(cred_key, "")
            if not v or not str(v).strip():
                raise ValueError(
                    f"Starburst {cred_key} is EMPTY after merge of:\n"
                    f"  * per-job JSON (no {cred_key} key, or blank)\n"
                    f"  * configs/starburst_config.yaml -> '{endpoint}' section "
                    f"(no '{cred_key.replace('trino_', '')}' value, or blank)\n"
                    f"  * STARBURST_{endpoint.upper()}_{cred_key.replace('trino_', '').upper()} "
                    f"env var (not set)\n"
                    f"Fill at least one source.  The recommended fix is to "
                    f"populate ALL Starburst creds in starburst_config.yaml "
                    f"(single source of truth)."
                )
    except Exception as exc:
        # Loader unavailable / shared YAML broken -- proceed with
        # per-job JSON only.  The caller's missing-field check
        # surfaces actually-missing credentials clearly.
        log.warning(
            "merge_shared_into_job_config: YAML loader failed (%s) -- "
            "falling back to per-job JSON values only", exc,
        )
    return config
