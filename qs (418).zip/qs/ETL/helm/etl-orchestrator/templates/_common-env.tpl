{{/*
Common env block for both sync-service and cron-scheduler deployments.

Includes Oracle conn parts, Starburst conn parts, Airflow conn parts,
and the QS_BOOTSTRAP-style two-credential split if you ever need it
(currently disabled — single-creds suffice for ETL).
*/}}
{{- define "etl-orch.commonEnv" -}}
# ── Oracle (used by ProcRunner, PollingBackend, IdempotencyStore) ─
- name: ETL_ORACLE_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: ETL_ORACLE_USER
- name: ETL_ORACLE_PASS
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: ETL_ORACLE_PASS
- name: ORACLE_HOST
  value: "{{ .Values.oracle.host }}"
- name: ORACLE_PORT
  value: "{{ .Values.oracle.port }}"
- name: ORACLE_SERVICE
  value: "{{ .Values.oracle.service }}"

# ── Airflow REST (used by AirflowDispatcher) ─────────────────────
{{- if .Values.airflow.enabled }}
- name: AIRFLOW_BASE_URL
  value: "{{ .Values.airflow.baseUrl }}"
- name: AIRFLOW_TIMEOUT_S
  value: "{{ .Values.airflow.timeoutSeconds }}"
- name: AIRFLOW_VERIFY_SSL
  value: "{{ .Values.airflow.verifySsl }}"
- name: AIRFLOW_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: AIRFLOW_USER
- name: AIRFLOW_PASS
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: AIRFLOW_PASS
{{- end }}

# ── Vault / secret-resolver (2026-06-22) ─────────────────────────
# ETL_USE_VAULT=1 turns ON the cloudeclient-based password resolver.
# When OFF (or unset), literal yaml passwords are used (dev / local).
# ETL_SECRETS_KEY is the Fernet key for the shared-PVC disk cache --
# MUST be the SAME on every pod sharing the cache (PVC location), so
# pod B can decrypt what pod A wrote.  Set it ONCE in the Helm secret
# and reuse here in all ETL deployments.
- name: ETL_USE_VAULT
  value: "{{ .Values.vault.enabled | default \"0\" }}"
- name: ETL_SECRETS_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: ETL_SECRETS_KEY
      optional: true

# ── Environment label (for log enrichment / config disambiguation) ──
- name: APP_ENVIRONMENT
  value: {{ .Values.application.environment | quote }}

# ── Pass-through extras (values.application.configEnv) ───────────
{{- range $key, $value := .Values.application.configEnv }}
- name: {{ $key | upper }}
  value: "{{ $value }}"
{{- end }}
{{- end }}


{{/*
Sync-only extra env — Starburst connection parts.
*/}}
{{- define "etl-orch.syncEnv" -}}
- name: STARBURST_CLOUD_HOST
  value: "{{ .Values.starburst.cloud.host }}"
- name: STARBURST_CLOUD_PORT
  value: "{{ .Values.starburst.cloud.port }}"
- name: STARBURST_CLOUD_CATALOG
  value: "{{ .Values.starburst.cloud.catalog }}"
- name: STARBURST_CLOUD_SCHEMA
  value: "{{ .Values.starburst.cloud.schema }}"
- name: STARBURST_ONPREM_HOST
  value: "{{ .Values.starburst.onprem.host }}"
- name: STARBURST_ONPREM_PORT
  value: "{{ .Values.starburst.onprem.port }}"
- name: STARBURST_ONPREM_CATALOG
  value: "{{ .Values.starburst.onprem.catalog }}"
- name: STARBURST_ONPREM_SCHEMA
  value: "{{ .Values.starburst.onprem.schema }}"
- name: STARBURST_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: STARBURST_USER
      optional: true
- name: STARBURST_PASS
  valueFrom:
    secretKeyRef:
      name: {{ .Values.app.name }}-{{ .Values.app.env }}-secret
      key: STARBURST_PASS
      optional: true
{{- end }}


{{/*
Common volumeMounts.
*/}}
{{- define "etl-orch.volumeMounts" -}}
{{- if .Values.persistence.configs.enabled }}
- name: etl-configs
  mountPath: {{ .Values.persistence.configs.mountPath }}
  readOnly: {{ .Values.persistence.configs.readOnly }}
{{- end }}
{{- if .Values.persistence.logs.enabled }}
- name: etl-logs
  mountPath: {{ .Values.persistence.logs.mountPath }}
{{- end }}
{{- end }}


{{/*
Common volumes.
*/}}
{{- define "etl-orch.volumes" -}}
{{- if .Values.persistence.configs.enabled }}
- name: etl-configs
  persistentVolumeClaim:
    claimName: {{ .Values.persistence.configs.claimName }}
    readOnly: {{ .Values.persistence.configs.readOnly }}
{{- end }}
{{- if .Values.persistence.logs.enabled }}
- name: etl-logs
  persistentVolumeClaim:
    claimName: {{ .Values.persistence.logs.claimName }}
{{- end }}
{{- end }}


{{/*
Common securityContext.
*/}}
{{- define "etl-orch.securityContext" -}}
allowPrivilegeEscalation: false
runAsNonRoot: true
runAsUser: {{ .Values.app.userId }}
seccompProfile:
  type: RuntimeDefault
capabilities:
  drop:
    - ALL
{{- end }}
