"""Write rig/generated/config.json for the test rig (2026-10-16).

config.json is git-ignored (it can carry credential hashes), so a fresh
clone has none -- and the backend fails auth CLOSED without one.  This builds
it the documented way: the code defaults (backend/scripts/init_config.py
--stdout), then rig/config.overlay.json (the rig's committed, secret-free
differences), then the ONE secret the rig needs, the feed webhook secret:
QS_WEBHOOK_SECRET from rig/rig.env, else a random one generated ONCE and kept
in rig/generated/webhook_secret (so a re-run never changes it under running
Spark jobs).  Never prints a secret.

    python rig/make_config.py            # called by rig.ps1 up
"""
from __future__ import annotations

import json
import os
import pathlib
import secrets
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
GEN = ROOT / "rig" / "generated"


def merge(base: dict, over: dict) -> dict:
    for k, v in over.items():
        if k.startswith("_comment"):
            continue
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            merge(base[k], v)
        else:
            base[k] = v
    return base


def main() -> int:
    GEN.mkdir(parents=True, exist_ok=True)
    out = subprocess.run([sys.executable, "scripts/init_config.py", "--stdout"], cwd=ROOT / "backend",
                         capture_output=True, text=True)
    if out.returncode != 0:
        print("init_config.py failed:", out.stderr[-600:], file=sys.stderr)
        return 1
    cfg = merge(json.loads(out.stdout), json.loads((ROOT / "rig" / "config.overlay.json").read_text(encoding="utf-8")))
    secret = os.environ.get("QS_WEBHOOK_SECRET", "").strip()
    kept = GEN / "webhook_secret"
    if not secret:
        if kept.exists():
            secret = kept.read_text(encoding="ascii").strip()
        else:
            secret = secrets.token_hex(32)
            kept.write_text(secret, encoding="ascii")
    cfg.setdefault("feed_generation", {})["webhook_secret"] = secret
    (GEN / "config.json").write_bytes((json.dumps(cfg, indent=2) + "\n").encode("utf-8"))
    print(f"wrote {GEN / 'config.json'} (defaults + {len(json.loads((ROOT / 'rig' / 'config.overlay.json').read_text(encoding='utf-8'))) - 1} overlay sections; webhook secret {'from rig.env' if os.environ.get('QS_WEBHOOK_SECRET') else 'kept in rig/generated'})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
