"""A stand-in Netcool REST gateway for the Docker rig.
POST /events  -> 200 and the body is recorded (or 503 while failing)
GET  /events  -> every body received, as JSON
POST /fail?on=1|0 -> make POST /events answer 503 (outage) or recover
POST /reset   -> forget what was received"""
import json, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
RECEIVED, STATE, LOCK = [], {"fail": False, "refused": 0}, threading.Lock()
class H(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        with LOCK:
            self._send(200, {"events": RECEIVED, "refused": STATE["refused"], "failing": STATE["fail"]})
    def do_POST(self):
        u = urlparse(self.path); n = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(n) if n else b""
        with LOCK:
            if u.path == "/fail":
                STATE["fail"] = parse_qs(u.query).get("on", ["1"])[0] == "1"; return self._send(200, STATE)
            if u.path == "/reset":
                RECEIVED.clear(); STATE["refused"] = 0; return self._send(200, {"ok": True})
            if STATE["fail"]:
                STATE["refused"] += 1; return self._send(503, {"error": "outage"})
            try: RECEIVED.append(json.loads(body or b"null"))
            except ValueError: RECEIVED.append({"raw": body.decode(errors="replace")})
            return self._send(200, {"accepted": True})
    def log_message(self, *a): pass
ThreadingHTTPServer(("0.0.0.0", 9000), H).serve_forever()
