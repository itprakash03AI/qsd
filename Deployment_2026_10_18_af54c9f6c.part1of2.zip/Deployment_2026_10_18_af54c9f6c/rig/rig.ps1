<#
  The QueryStudio test rig on a Windows machine with Docker Desktop (2026-10-16).
  ONE compose file (docker-compose.rig.yml) holds every component; this script
  builds it, starts it, seeds it, checks it and tests it.

    .\rig\rig.ps1 up                 build every image, start all components, seed, check
    .\rig\rig.ps1 up -Spark          ... plus the Spark job image and a Kubernetes cluster for Spark pods
    .\rig\rig.ps1 up -Starburst      ... plus the Starburst-shaped Trino (TLS, users)
    .\rig\rig.ps1 up -NoBuild        start without rebuilding the images
    .\rig\rig.ps1 status             one line per component, and the addresses
    .\rig\rig.ps1 test all           every component's proofs (or: test feeds reports ...)
    .\rig\rig.ps1 test -List         the test groups and what each proves
    .\rig\rig.ps1 logs api           follow one component's log
    .\rig\rig.ps1 down               stop everything (data kept)
    .\rig\rig.ps1 reset              stop and DELETE the rig's data (asks first; -Yes skips)
    .\rig\rig.ps1 release-check      THE release gate: delete the rig's data, build every image,
                                     start everything (-Spark -Starburst), seed, run EVERY group in
                                     one sequence; exit 0 only when all pass (-Yes skips the question)

  Needs: Docker Desktop (WSL 2, 16-20 GB memory for Docker), Python 3.11+ on PATH,
  and rig\rig.env (copy rig\rig.env.example and fill it in).
  Record: docs\DOCKER_RIG_SETUP_AND_TEST_2026_10_16.html
#>
param(
  [Parameter(Position = 0)] [string] $Command = "status",
  [Parameter(Position = 1, ValueFromRemainingArguments = $true)] [string[]] $Rest = @(),
  [switch] $Spark,
  [switch] $Starburst,
  [switch] $NoBuild,
  [switch] $List,
  [switch] $Yes
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Compose = @("compose", "-f", "docker-compose.rig.yml", "--env-file", "rig\rig.env")
$AllProfiles = @("--profile", "spark-build", "--profile", "starburst", "--profile", "polling")

function Say([string] $text, [string] $color = "Gray") { Write-Host $text -ForegroundColor $color }
function Fail([string] $text) { Write-Host "ERROR: $text" -ForegroundColor Red; exit 1 }

# Windows PowerShell 5.1: with ErrorActionPreference=Stop, ANY line a native
# program writes to stderr (docker's "Pulling ..." progress) becomes a
# terminating error.  A native program is judged by its EXIT CODE only.
function Invoke-Native([string] $exe, [string[]] $argv) {
  $prev = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    & $exe @argv 2>&1 | ForEach-Object { Write-Host "$_" }
    $code = $LASTEXITCODE
  } finally { $ErrorActionPreference = $prev }
  return $code
}
function Invoke-Checked([string] $exe, [string[]] $argv, [string] $what) {
  $code = Invoke-Native $exe $argv
  if ($code -ne 0) { Fail "$what failed (exit $code)" }
}

function Import-RigEnv {
  $file = Join-Path $Root "rig\rig.env"
  if (-not (Test-Path $file)) { Fail "rig\rig.env is missing -- copy rig\rig.env.example to rig\rig.env and fill it in." }
  foreach ($line in Get-Content $file) {
    $t = $line.Trim()
    if ($t -eq "" -or $t.StartsWith("#") -or -not $t.Contains("=")) { continue }
    $i = $t.IndexOf("=")
    [Environment]::SetEnvironmentVariable($t.Substring(0, $i).Trim(), $t.Substring($i + 1).Trim(), "Process")
  }
  # the Starburst-shaped Trino's users: generated ONCE by make_certs.sh (rig.ps1 up -Starburst)
  $sb = Join-Path $env:USERPROFILE ".qs_keys\starburst_like.env"
  if (Test-Path $sb) {
    foreach ($line in Get-Content $sb) {
      $t = $line.Trim() -replace "^export\s+", ""
      if ($t -eq "" -or $t.StartsWith("#") -or -not $t.Contains("=")) { continue }
      $i = $t.IndexOf("=")
      [Environment]::SetEnvironmentVariable($t.Substring(0, $i).Trim(), $t.Substring($i + 1).Trim().Trim('"').Trim("'"), "Process")
    }
  }
  foreach ($need in @("QS_RIG_ADMIN_PW", "QS_RIG_ANALYST_PW", "QS_RIG_VIEWER_PW", "QS_LOAD_PW", "QS_ORACLE_SYS_PASSWORD", "QS_ORACLE_PW")) {
    if (-not [Environment]::GetEnvironmentVariable($need, "Process")) { Fail "$need is empty in rig\rig.env" }
  }
}

# Git Bash, never the `bash` on PATH: on Windows that is often WSL's
# (C:\Windows\System32\bash.exe), a Linux with none of this machine's tools.
function Get-GitBash {
  $cands = @()
  $git = Get-Command git -ErrorAction SilentlyContinue
  if ($git) { $cands += (Join-Path (Split-Path (Split-Path $git.Source)) "bin\bash.exe") }
  $cands += @("$env:ProgramFiles\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")
  foreach ($c in $cands) { if (Test-Path $c) { return $c } }
  Fail "Git Bash is not installed (winget install Git.Git) -- the Spark / Starburst steps need it."
}

# 2026-10-16: Docker Desktop's backend (com.docker.backend) LEAKS a bound TCP
# socket per forwarded connection and never frees them while it runs; after two
# days it held 15,709 of the 16,384 dynamic ports and every proof failed in 0 s
# with WinError 10048 -- the rig was healthy, the HOST had no ports left.
function Assert-HostPorts {
  try {
    $dyn = 16384
    $m = (netsh int ipv4 show dynamicport tcp | Select-String "Number of Ports\s*:\s*(\d+)")
    if ($m) { $dyn = [int]$m.Matches[0].Groups[1].Value }
    $bound = @(Get-NetTCPConnection -State Bound -ErrorAction Stop)
    $docker = @(Get-Process -Name "com.docker.backend" -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
    $held = @($bound | Where-Object { $docker -contains $_.OwningProcess }).Count
    if ($held -gt [int]($dyn * 0.5)) {
      Fail ("Docker Desktop holds $held of this PC's $dyn client ports (a Docker Desktop leak); the tests " +
            "would fail with WinError 10048.  Restart Docker Desktop (whale icon -> Restart), then " +
            ".\rig\rig.ps1 up -NoBuild [-Spark -Starburst] and test again.")
    }
    if ($held -gt [int]($dyn * 0.25)) {
      Say "NOTE Docker Desktop holds $held of $dyn client ports; a long run may exhaust them -- restart Docker Desktop first." "Yellow"
    }
  } catch {
    Say "NOTE could not count this PC's client ports ($($_.Exception.Message)); continuing" "DarkGray"
  }
}

function Assert-Tools {
  if ((Invoke-Native "docker" @("info", "--format", "{{.ServerVersion}}")) -ne 0) { Fail "Docker is not running -- start Docker Desktop first." }
  if ($null -eq (Get-Command python -ErrorAction SilentlyContinue)) { Fail "Python 3.11+ is not on PATH (needed by the seed and the tests)." }
}

# what `up` STARTS (the Spark job image is build-only: see Get-BuildProfiles)
function Get-Profiles {
  $p = @()
  if ($Starburst) { $p += @("--profile", "starburst") }
  return $p
}
function Get-BuildProfiles {
  $p = Get-Profiles
  if ($Spark) { $p += @("--profile", "spark-build") }
  return $p
}

function Show-Status {
  Invoke-Native "docker" ($Compose + $AllProfiles + @("ps", "--format", "table {{.Name}}`t{{.Status}}`t{{.Ports}}")) | Out-Null
  Say ""
  Say "QueryStudio UI      http://localhost:3000   (rig_admin / rig_analyst / rig_viewer)" "Cyan"
  Say "API                 http://localhost:8000/docs" "Cyan"
  Say "Published API       http://localhost:8003" "Cyan"
  Say "Mail (every e-mail) http://localhost:8025      MinIO console http://localhost:9001" "Cyan"
  Say "Trino               http://localhost:8088      SFTP localhost:2222      Oracle localhost:1521" "Cyan"
}

switch ($Command.ToLower()) {
  "up" {
    Import-RigEnv; Assert-Tools
    Say "[1/5] config.json from the code defaults + rig\config.overlay.json" "Yellow"
    Invoke-Checked "python" @("rig/make_config.py") "make_config"
    if ($Starburst -and -not (Test-Path "scripts\docker_proof\starburst_like\generated\trino-sb.env")) {
      Say "      Starburst-shaped Trino: generating its certificates and users once" "Yellow"
      Invoke-Checked (Get-GitBash) @("scripts/docker_proof/starburst_like/make_certs.sh") "make_certs.sh (needs Git Bash)"
    }
    $prof = Get-Profiles
    if (-not $NoBuild) {
      # the API image bakes in the DuckDB extensions of the PINNED version; a
      # deployment bundle does not ship the binaries (~82 MB), so fetch them once
      $ver = (Select-String -Path "backend\requirements.txt" -Pattern "^duckdb==([0-9.]+)").Matches[0].Groups[1].Value
      if (-not (Test-Path "duckdb_extensions\v$ver\linux_amd64\httpfs.duckdb_extension")) {
        Say "      DuckDB $ver extensions are not here yet: downloading them once (needs internet)" "Yellow"
        Invoke-Checked "python" @("duckdb_extensions/download_extensions.py", "--version", $ver) "DuckDB extension download"
      }
      Say "[2/5] building every image from this folder (first time: 10-20 minutes)" "Yellow"
      Invoke-Checked "docker" ($Compose + (Get-BuildProfiles) + @("build")) "docker compose build"
    } else {
      Say "[2/5] build skipped (-NoBuild)" "DarkGray"
    }
    Say "[3/5] starting every component and waiting until each is healthy" "Yellow"
    Invoke-Checked "docker" ($Compose + $prof + @("up", "-d", "--wait", "--wait-timeout", "900")) "docker compose up"
    Say "[4/5] seeding the connections the proofs expect" "Yellow"
    Invoke-Checked "python" @("rig/seed_rig.py") "seed (see the FAIL lines above)"
    if ($Spark) {
      Say "[5/5] Spark: a Kubernetes cluster (kind) with the job image loaded" "Yellow"
      Invoke-Checked (Get-GitBash) @("rig/spark_cluster.sh") "Spark cluster setup"
    } else {
      Say "[5/5] Spark skipped (add -Spark for the Spark lane)" "DarkGray"
    }
    Show-Status
    Say "`nRig is up. Next: .\rig\rig.ps1 test all" "Green"
  }
  "status" { Show-Status }
  "test" {
    Import-RigEnv; Assert-Tools
    if ($List) { exit (Invoke-Native "python" @("rig/run_tests.py", "--list")) }
    Assert-HostPorts
    if ($Rest.Count -eq 0) { $Rest = @("all") }
    exit (Invoke-Native "python" (@("rig/run_tests.py") + $Rest))
  }
  "logs" {
    if ($Rest.Count -eq 0) { Fail "which component? e.g. .\rig\rig.ps1 logs api" }
    Invoke-Native "docker" ($Compose + $AllProfiles + @("logs", "-f", "--tail", "200", $Rest[0])) | Out-Null
  }
  "down" {
    Import-RigEnv
    Invoke-Checked "docker" ($Compose + $AllProfiles + @("down")) "docker compose down"
    Say "Stopped. Data kept (.\rig\rig.ps1 up brings it back)." "Green"
  }
  "reset" {
    Import-RigEnv
    if (-not $Yes) {
      $ans = Read-Host "Delete ALL rig data (database, MinIO, Oracle, feeds)? Type YES"
      if ($ans -ne "YES") { Say "Nothing deleted."; exit 0 }
    }
    Invoke-Checked "docker" ($Compose + $AllProfiles + @("down", "-v")) "docker compose down -v"
    Remove-Item -Recurse -Force "rig\generated" -ErrorAction SilentlyContinue
    Say "Rig data deleted. .\rig\rig.ps1 up starts a fresh one." "Green"
  }
  "release-check" {
    # 2026-10-16, the owner: "100% prod ready".  A rig with history hid ~25 issues that
    # only a rig built from EMPTY, running every group in ONE sequence, showed.
    Import-RigEnv; Assert-Tools
    if (-not $Yes) {
      $ans = Read-Host "release-check DELETES the rig's data and rebuilds it (5-6 hours with every group). Type YES"
      if ($ans -ne "YES") { Say "Nothing done."; exit 0 }
    }
    $self = $PSCommandPath
    $t0 = Get-Date
    Say "== release-check 1/3: delete the rig's data" "Yellow"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $self reset -Yes
    if ($LASTEXITCODE -ne 0) { Fail "reset failed" }
    Say "== release-check 2/3: build every image, start every component, seed" "Yellow"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $self up -Spark -Starburst
    if ($LASTEXITCODE -ne 0) { Fail "up failed -- the rig does not build or seed from empty" }
    Say "== release-check 3/3: every group, one sequence" "Yellow"
    & powershell -NoProfile -ExecutionPolicy Bypass -File $self test all spark spark-reads starburst aws
    $code = $LASTEXITCODE
    $mins = [int]((Get-Date) - $t0).TotalMinutes
    if ($code -eq 0) { Say "`nRELEASE CHECK PASSED in $mins minutes (proof-runs\<latest>\SUMMARY.txt)" "Green" }
    else { Say "`nRELEASE CHECK FAILED after $mins minutes -- see proof-runs\<latest>\SUMMARY.txt" "Red" }
    exit $code
  }
  default { Fail "unknown command '$Command' -- up | status | test | logs | down | reset | release-check" }
}
