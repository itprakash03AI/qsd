"""Test every QueryStudio component on the rig, grouped by component
(2026-10-16).  The ONE list of which proof harness belongs to which
component (scripts/docker_proof/run_all.sh's list had gone stale).

    python rig/run_tests.py all                 # every LOCAL group
    python rig/run_tests.py feeds reports       # some groups
    python rig/run_tests.py --list              # the groups and their proofs

Harnesses run ONE AT A TIME (two load proofs at once measure each other).
Each prints its checks; its EXIT STATUS decides PASS / FAIL (a harness that
printed nothing is a FAIL).  Logs: proof-runs/<timestamp>/<harness>.log and
SUMMARY.txt.  Needs the rig's passwords in the environment (rig.ps1 test
loads rig/rig.env).

"all" = every group that needs nothing outside the rig.  Groups needing an
outside account (aws, starburst, spark) are run by name and are SKIPPED --
said, never failed -- when what they need is absent.
"""
from __future__ import annotations

import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
PROOFS = ROOT / "scripts" / "docker_proof"

#: component -> [(harness, extra args)]; "needs" names what must exist first
GROUPS = {
    "security": {"what": "login, roles, row security, connection secrets, the encryption keys",
                 "proofs": [("auth_rls_proof", []), ("connections_admin_only_proof", []),
                            ("connection_secret_blank_proof", []),
                            ("envelope_keys_proof", [])]},
    "datasets": {"what": "datasets built as an analyst builds them; filter values",
                 "proofs": [("role_dataset_journey_proof", []), ("s3_sql_dataset_journey", []),
                            ("date_lov_roundtrip", [])]},
    "reports": {"what": "reports and publishing them",
                "proofs": [("publish_report_connections_proof", [])]},
    "published-api": {"what": "the published API: filters, paging, capacity slots; the inventory, dashboard numbers "
                              "vs the call record by SQL, thresholds + alerts through the road, lifecycle (2026-10-17)",
                      "proofs": [("pv_date_filter_proof", []), ("pv_paged_ceiling_proof", []),
                                 ("published_api_inventory_proof", [])]},
    "feeds": {"what": "feed generation: create, triggers, dependencies, month end, checksums, delivery",
              "proofs": [("feed_triggers_proof", []), ("feed_dependencies_proof", []),
                         ("feed_on_completion_proof", []),
                         ("checksum_covers_proof", []), ("month_end_wd_eod_proof", []),
                         ("feed_board_truth_proof", [])]},
    "background": {"what": "background jobs, proven by what they produce; component health, one place "
                           "(stop Trino, SFTP unreachable, pause, kill the scheduler, drain, breaker reset, "
                           "support read-only, 100 users, a hung probe)",
                   "proofs": [("background_jobs_proof", []), ("jobs_by_output_proof", []),
                              ("component_health_proof", [])]},
    # starts a PROD twin (qs-prod-api :8010, database querystudio_prod) from
    # scripts/docker_proof/compose/config_release.override.yml and stops it after
    "config-release": {"what": "configuration release UAT -> PROD: export, diff per field, mapping, four-eyes, "
                               "one-transaction apply, identical file, rollback, no secret in the package",
                       "proofs": [("config_release_proof", []), ("schema_upgrade_proof", [])]},
    "load": {"what": "many users at once, capacity waits",
             "proofs": [("multiuser_load", []), ("capacity_wait_proof", [])]},
    # ── need something outside the rig: run by name ──────────────────────
    "spark": {"what": "feeds on Spark pods (needs: rig.ps1 up -Spark)", "needs": "spark",
              "proofs": [("spark_pods_proof", []), ("partitioned_spark_proof", []),
                         ("run_progress_proof", [])]},
    # the read plan on pods reads the owner's JOIN tables on AWS (cloud) AND on
    # the Starburst-shaped cluster (on-prem); the setup makes + registers them
    "spark-reads": {"what": "the read plan on Spark pods: Iceberg with deletes, the owner's JOIN on AWS + on-prem Hive "
                            "(needs: rig.ps1 up -Spark -Starburst, AWS keys)",
                    "needs": "spark starburst aws",
                    "proofs": [("read_plan_pod_setup", []), ("read_plan_pod_proof", [])]},
    "aws": {"what": "REAL AWS S3 / Iceberg: data products, pruning, cross-source, S3-direct feeds (needs AWS keys)",
            "needs": "aws",
            "proofs": [("aws_tb_proof", []), ("aws_cross_source_proof", []), ("aws_pruning_proof", []),
                       ("aws_s3_worst_queries_proof", []), ("s3_background_proof", []), ("s3_to_s3_proof", []),
                       ("new_feed_e2e_proof", []), ("restatement_proof", [])]},
    "snowflake": {"what": "Snowflake on a REAL account incl. a view whose credentials cannot be obtained (needs: a Snowflake account -- the trial is gone)",
                  "needs": "snowflake",
                  "proofs": [("credentials_unavailable_proof", []), ("snowflake_real_account_proof", []),
                             ("snowflake_journey_proof", []), ("cross_source_proof", [])]},
    "starburst": {"what": "the Starburst-shaped Trino: TLS, users, every surface (needs: rig.ps1 up -Starburst)",
                  "needs": "starburst", "proofs": [("starburst_like_proof", []),
                                                   ("feed_second_side_bindings_proof", []),
                                                   ("partition_by_key_proof", [])]},
}
LOCAL = [g for g, v in GROUPS.items() if not v.get("needs")]


def docker_ports_held():
    """(held, total): client ports Docker Desktop's backend holds on this Windows PC.
    It LEAKS one per forwarded connection (2026-10-16: 15,709 of 16,384 after two
    days; every proof then failed in 0 s with WinError 10048).  None off Windows."""
    if os.name != "nt":
        return None
    ps = ("$d=@(Get-Process -Name com.docker.backend -EA SilentlyContinue|%{$_.Id});"
          "@(Get-NetTCPConnection -State Bound -EA SilentlyContinue|?{$d -contains $_.OwningProcess}).Count")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60)
        return int(r.stdout.strip() or 0), 16384
    except Exception:                                        # noqa: BLE001
        return None


def available(need: str) -> str:
    """'' when the group's outside dependencies (space-separated) are there, else why not."""
    if " " in need.strip():
        return "; ".join(w for w in (available(n) for n in need.split()) if w)
    def running(name):
        r = subprocess.run(["docker", "inspect", "-f", "{{.State.Running}}", name], capture_output=True, text=True)
        return r.stdout.strip() == "true"
    if need == "aws":
        return "" if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("QS_AWS_BUCKET") else \
            "no AWS keys in rig/rig.env"
    if need == "starburst":
        return "" if running("qs-trino-sb") else "qs-trino-sb is not running (rig.ps1 up -Starburst)"
    if need == "snowflake":
        return "" if os.environ.get("QS_SF_ACCOUNT") else "no Snowflake account (QS_SF_ACCOUNT unset; the trial is gone)"
    if need == "spark":
        return "" if running("qs-spark-control-plane") else "no Spark cluster (rig.ps1 up -Spark)"
    return ""


def main(argv) -> int:
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 2
    if argv[0] == "--list":
        for g, v in GROUPS.items():
            print(f"{g:<14} {v['what']}")
            for h, a in v["proofs"]:
                print(f"{'':<14}   {h} {' '.join(a)}")
        return 0
    # "all" expands to the local groups and combines with others (`all spark aws`)
    groups = []
    for g in argv:
        for x in (LOCAL if g == "all" else [g]):
            if x not in groups:
                groups.append(x)
    unknown = [g for g in groups if g not in GROUPS]
    if unknown:
        print(f"unknown group(s) {unknown}; known: {list(GROUPS)}")
        return 2
    out = ROOT / "proof-runs" / time.strftime("%Y%m%d_%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, MSYS_NO_PATHCONV="1", PYTHONUNBUFFERED="1")
    if not available("spark"):
        # the Starburst proof's Spark-lane case (S1) is opt-in; with the cluster up, run it
        env.setdefault("QS_SB_SPARK", "1")
    lines, fails = [], 0
    for g in groups:
        why = available(GROUPS[g].get("needs", ""))
        if why:
            lines.append(f"SKIP {g:<14} -- {why}")
            print(lines[-1], flush=True)
            continue
        for h, args in GROUPS[g]["proofs"]:
            held = docker_ports_held()
            if held and held[0] > held[1] * 0.8:
                lines.append(f"FAIL {g:<14} {h:<36} NOT RUN -- Docker Desktop holds {held[0]} of {held[1]} client "
                             f"ports (its leak); restart Docker Desktop and run again")
                print(lines[-1], flush=True)
                fails += 1
                (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
                print("\nstopped: this PC has no client ports left -- every further proof would fail in 0 s")
                return 1
            t0 = time.time()
            log = out / f"{h}.log"
            with open(log, "wb") as fh:
                try:
                    rc = subprocess.run([sys.executable, f"{h}.py", *args], cwd=PROOFS, env=env, stdout=fh,
                                        stderr=subprocess.STDOUT, timeout=int(os.environ.get("QS_PROOF_TIMEOUT", "5400"))).returncode
                except subprocess.TimeoutExpired:
                    rc = 124
            text = log.read_text(encoding="utf-8", errors="replace")
            tally = [ln.strip() for ln in text.splitlines() if "checks passed" in ln or "passed" in ln.lower()][-1:] or [""]
            ok = rc == 0 and text.strip() != ""
            fails += 0 if ok else 1
            lines.append(f"{'PASS' if ok else 'FAIL'} {g:<14} {h:<36} rc={rc:<4} {round(time.time() - t0):>5}s  {tally[0][:90]}")
            print(lines[-1], flush=True)
    (out / "SUMMARY.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\n{sum(1 for l in lines if l.startswith('PASS'))} passed, {fails} failed, "
          f"{sum(1 for l in lines if l.startswith('SKIP'))} groups skipped -- logs in {out}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
