"""Seed a FRESH test rig with what every proof harness assumes exists
(2026-10-16).  Idempotent: an object that exists by name is left alone.

  id 1  minio-rig        S3 on the rig's MinIO (bucket qs-data)    -- QS proofs use id 1
  id 2  trino-rig        the cloud Trino, catalog tpch            -- QS_TRINO_CONN default "2"
  id 3  oracle-otg       Oracle otg schema (the OG side)          -- by name
        aws-real         the REAL AWS bucket -- only when AWS keys are in rig/rig.env
        onprem-starburst the Starburst-shaped Trino -- only when it runs (rig.ps1 up -Starburst)
        trino-podreach, oracle-otg-podreach   what a Spark pod can reach -- only with the Spark cluster

Each connection is TESTED after it is saved; a failed test is said, never
hidden.  Then the data the proofs read (rig/seed_data.py).  Run by rig.ps1 up after the API is healthy (needs only the Python
standard library):

    python rig/seed_rig.py
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request

BASE = os.environ.get("QS_API_BASE", "http://127.0.0.1:8000")


def call(method, path, body=None, token=None, timeout=120):
    req = urllib.request.Request(BASE + path, method=method,
                                 data=None if body is None else json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json",
                                          **({"Authorization": f"Bearer {token}"} if token else {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw)
        except ValueError:
            return e.code, {"detail": raw[:300].decode(errors="replace")}


def _running(container: str) -> bool:
    import subprocess
    r = subprocess.run(["docker", "inspect", "-f", "{{.State.Running}}", container],
                       capture_output=True, text=True)
    return r.returncode == 0 and r.stdout.strip() == "true"


def env(name, default=None, required=False):
    v = os.environ.get(name, default)
    if required and not v:
        sys.exit(f"{name} is not set -- put it in rig/rig.env")
    return v


def main() -> int:
    t0 = time.time()
    while time.time() - t0 < 300:
        try:
            if call("GET", "/health/ready", timeout=5)[0] == 200:
                break
        except OSError:
            pass
        time.sleep(3)
    else:
        sys.exit("the API did not become ready in 5 minutes")
    s, b = call("POST", "/auth/login", {"username": "rig_admin", "password": env("QS_RIG_ADMIN_PW", required=True)})
    if s != 200:
        sys.exit(f"login as rig_admin failed: HTTP {s} {b}")
    tok = b.get("session_token")
    if not tok:
        sys.exit(f"login answered without a session token: {b}")
    _, conns = call("GET", "/api/connections?limit=1000", token=tok)
    items = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
    have = {c["name"]: c for c in items}

    wanted = [
        ("minio-rig", "s3", {
            "bucket_name": "qs-data", "region_name": "us-east-1", "auth_mode": "keys",
            "aws_access_key_id": env("QS_MINIO_USER", "qsadmin"),
            "aws_secret_access_key": env("QS_MINIO_PASSWORD", "QsMinio_12345"),
            "endpoint_url": "http://qs-minio:9000", "path_style": True, "ssl_verify": True}),
        ("trino-rig", "trino", {"host": "qs-trino", "port": 8080, "user": "rig", "http_scheme": "http",
                                "catalog": "tpch"}),
        ("oracle-otg", "oracle", {"host": "oracle-db", "port": 1521, "service_name": "freepdb1", "user": "otg",
                                  "password": env("QS_ORACLE_PW", required=True)}),
    ]
    if env("AWS_ACCESS_KEY_ID") and env("QS_AWS_BUCKET"):
        wanted.append(("aws-real", "s3", {
            "bucket_name": env("QS_AWS_BUCKET"), "region_name": env("AWS_DEFAULT_REGION", "us-east-2"),
            "auth_mode": "keys", "aws_access_key_id": env("AWS_ACCESS_KEY_ID"),
            "aws_secret_access_key": env("AWS_SECRET_ACCESS_KEY"), "path_style": False, "ssl_verify": True}))
    if _running("qs-spark-control-plane"):
        # what a Spark POD can reach (rig.ps1 up -Spark): the published ports on the
        # host by host.docker.internal -- the API containers resolve it too (extra_hosts)
        wanted += [
            ("trino-podreach", "trino", {"host": "host.docker.internal", "port": 8088, "user": "rig",
                                         "http_scheme": "http", "catalog": "iceberg"}),
            ("oracle-otg-podreach", "oracle", {"host": "host.docker.internal", "port": 1521,
                                               "service_name": "freepdb1", "user": "otg",
                                               "password": env("QS_ORACLE_PW", required=True)}),
        ]
    if env("QS_SB_ANALYST_PW") and _running("qs-trino-sb"):
        # the on-prem side the JOIN / read-plan / month-end proofs name (rig.ps1 up -Starburst)
        wanted.append(("onprem-starburst", "starburst", {
            "host": "qs-trino-sb", "port": 8443, "user": "qs_analyst", "auth_type": "basic",
            "password": env("QS_SB_ANALYST_PW"), "http_scheme": "https", "verify_ssl": False,
            "catalog": "iceberg", "schema": "qs"}))

    bad = 0
    for name, ctype, cfg in wanted:
        if name in have:
            cid, how = have[name]["id"], "exists"
        else:
            s, b = call("POST", "/api/connections", {"name": name, "connection_type": ctype, "config": cfg}, token=tok)
            if s not in (200, 201):
                print(f"FAIL {name}: create HTTP {s} {str(b)[:300]}")
                bad += 1
                continue
            cid, how = b.get("id"), "created"
        s, b = call("POST", f"/api/connections/{cid}/test", token=tok, timeout=180)
        ok = s == 200 and (b.get("success") is not False) and b.get("status") not in ("error", "failed")
        if not ok and how == "exists":
            # 2026-10-17: rig.env and the generated passwords are the truth.  A
            # connection seeded before they changed (make_certs.sh on a machine
            # with no generated/ folder writes NEW Starburst passwords) failed
            # its test forever.  MERGE our keys into the stored config -- never
            # replace it: minio-rig / aws-real carry their registered tables
            # there (a replacing PUT once wiped fact_tetb_month_end).
            _, full = call("GET", f"/api/connections/{cid}", token=tok)
            merged = {**((full or {}).get("config") or {}), **cfg}
            s2, b2 = call("PUT", f"/api/connections/{cid}",
                          {"name": name, "connection_type": ctype, "config": merged}, token=tok)
            if s2 == 200:
                how = "updated"
                s, b = call("POST", f"/api/connections/{cid}/test", token=tok, timeout=180)
                ok = s == 200 and (b.get("success") is not False) and b.get("status") not in ("error", "failed")
        bad += 0 if ok else 1
        print(f"{'PASS' if ok else 'FAIL'} {name:<12} id={cid:<4} {how:<8} test: HTTP {s} "
              f"{'' if ok else str(b.get('detail') or b.get('message') or b)[:200]}")
    ids = {c["name"]: c["id"] for c in (lambda r: r if isinstance(r, list) else
                                        (r.get('items') or r.get('connections') or []))(call("GET", "/api/connections?limit=1000", token=tok)[1])}
    if ids.get("minio-rig") != 1 or ids.get("trino-rig") != 2:
        print(f"NOTE the proofs assume MinIO = id 1 and Trino = id 2; here they are "
              f"{ids.get('minio-rig')} / {ids.get('trino-rig')} -- set QS_TRINO_CONN={ids.get('trino-rig')} "
              f"(a rig seeded on a FRESH database always gets 1 / 2)")
    print(f"seed: {len(wanted) - bad}/{len(wanted)} connections ready")
    # the DATA the proofs read (rig/seed_data.py): the Iceberg catalog tables,
    # iceberg.qs.trades, the S3 trades corpus, the real AWS tables
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from seed_data import seed
    bad += seed(call, tok)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
