#!/bin/sh
# The Spark lane's Kubernetes cluster for the test rig (2026-10-16).  Called by
# `rig.ps1 up -Spark` after the compose stack is up and the spark-image built.
#
# Kubernetes is the one piece that is not a compose service: Spark asks a
# Kubernetes API for driver / executor pods, and kind runs that cluster as a
# Docker container of its own (qs-spark-control-plane).  This is the setup the
# dev rig proved (docs/READ_PLAN_ALL_ENGINES_2026_10_14.html, 40M rows on pods).
# No spark-operator is needed: spark_k8s.submit_mode=auto posts the driver
# pod itself when the operator's CRD is absent.
# Idempotent.  Needs kind + kubectl on PATH (winget install Kubernetes.kind
# Kubernetes.kubectl).
set -eu
cd "$(dirname "$0")/.."
# bash started from PowerShell does not read the login profile: look where
# winget, a hand install (~/bin) and Docker Desktop put the two tools
for d in "$HOME/bin" "$HOME/.local/bin" "${LOCALAPPDATA:-}/Microsoft/WinGet/Links"          "/c/Program Files/Docker/Docker/resources/bin"; do
  [ -d "$d" ] && PATH="$PATH:$d"
done
export PATH
command -v kind >/dev/null || { echo "kind is not on PATH (winget install Kubernetes.kind)"; exit 1; }
command -v kubectl >/dev/null || { echo "kubectl is not on PATH (winget install Kubernetes.kubectl)"; exit 1; }
if ! kind get clusters 2>/dev/null | grep -qx qs-spark; then
  echo "creating the kind cluster qs-spark"
  kind create cluster --name qs-spark --wait 180s
fi
kubectl --context kind-qs-spark get ns spark >/dev/null 2>&1 || kubectl --context kind-qs-spark create namespace spark
kubectl --context kind-qs-spark apply -f k8s/spark-k8s/driver-rbac.yaml
# load the job image built by the compose "spark" profile and PROVE the cluster runs that build
QS_SPARK_IMAGE=querystudio/spark-etl:local bash scripts/spark_kind_attach_docker.sh --load-image
# join the QueryStudio containers (and the sources the pods read) to the cluster's network
bash scripts/spark_kind_attach_docker.sh
echo "Spark cluster ready: kubectl --context kind-qs-spark -n spark get pods -w"
