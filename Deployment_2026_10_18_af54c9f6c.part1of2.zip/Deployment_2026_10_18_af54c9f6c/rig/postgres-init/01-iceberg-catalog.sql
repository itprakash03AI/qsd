-- First start of a fresh Postgres volume only: the database Trino keeps its
-- Iceberg catalogs in (rig/trino/catalog/iceberg*.properties).
CREATE DATABASE iceberg_catalog OWNER querystudio;
