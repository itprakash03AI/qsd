"""The DATA a fresh test rig needs before the proofs can run (2026-10-16).
Called by rig/seed_rig.py after the connections are in.  Idempotent: each
step checks first and builds only what is missing.

Found by the first from-scratch run (1 of 23 proofs passed):
  * Trino's Iceberg JDBC catalog does not create its own tables ("relation
    iceberg_tables does not exist") -- rig/postgres-init/02 creates them on
    a fresh volume; this re-applies the same file to an existing one.
  * iceberg.qs.trades (read by 10+ proofs) and iceberg.qs.region_lookup were
    built BY HAND on the dev rig -- no script made them.  Now they are built
    here in Trino by SQL, deterministically, in the shape the proofs assume:
    TPC-H orders with the TPC-H REGION names (EUROPE, ASIA, ... -- the row
    security proofs filter on them) and the order date as ``dt`` (1992-1998:
    the date-filter proofs ask for 1995-03-15).  region_lookup keeps the S3
    corpus's regions (AMER, EMEA, ...).  Every proof computes its truth
    through Trino, so it checks against whatever these hold.
  * the dataset NAMED bqb_trades over iceberg.qs.trades (the dev rig's
    dataset 13, which the proofs now look up by name).
  * the S3 "trades" corpus (7,300 parquet files, region=/dt=) that
    s3_sql_dataset_journey reads: scripts/seed_s3_rig.py --keys-in-path-only
    (the PRODUCTION shape: the partition keys only in the path, so dt is a
    DATE), run inside the API container (it has pyarrow / boto3), then
    registered on minio-rig.
  * with AWS keys: the owner's REAL Iceberg tables (rig/aws_tables.json)
    registered into iceberg_aws from their S3 location -- no data copied.
"""
from __future__ import annotations

import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")

REGION_LOOKUP = ("CREATE TABLE IF NOT EXISTS iceberg.qs.region_lookup AS SELECT * FROM (VALUES "
                 "('AMER', 'Americas Desk', 'America/New_York'), ('APAC', 'Asia Pacific Desk', 'Asia/Singapore'), "
                 "('EMEA', 'Europe Desk', 'Europe/London'), ('LATAM', 'Latin America Desk', 'America/Sao_Paulo'), "
                 "('UK', 'UK Desk', 'Europe/London')) AS t (region, desk, tz)")

TRADES = """CREATE TABLE IF NOT EXISTS iceberg.qs.trades WITH (partitioning = ARRAY['region']) AS
SELECT CAST(o.orderkey AS bigint) AS id,
       date_add('second', o.orderkey % 86400, CAST(o.orderdate AS timestamp(6))) AS trade_ts,
       'BK' || lpad(CAST(o.custkey % 240 + 1 AS varchar), 4, '0') AS book,
       element_at(ARRAY['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'SGD'], CAST(o.orderkey % 6 AS integer) + 1) AS ccy,
       CAST(o.totalprice AS double) AS amt,
       CAST(o.orderkey % 4999 + 1 AS bigint) AS qty,
       'CP' || lpad(CAST(o.custkey % 9000 + 1 AS varchar), 5, '0') AS counterparty,
       element_at(ARRAY['NEW', 'AMENDED', 'CANCELLED', 'SETTLED'], CAST(o.orderkey % 4 AS integer) + 1) AS status,
       r.name AS region,
       o.orderdate AS dt,
       r.name || ' Desk' AS desk
FROM tpch.sf1.orders o
JOIN tpch.sf1.customer c ON c.custkey = o.custkey
JOIN tpch.sf1.nation n ON n.nationkey = c.nationkey
JOIN tpch.sf1.region r ON r.regionkey = n.regionkey"""


def run(args, *, stdin=None, timeout=1800):
    return subprocess.run(args, input=stdin, capture_output=True, text=True, env=ENV, timeout=timeout)


def trino(sql, timeout=1800):
    r = run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql], timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(f"trino: {(r.stderr or r.stdout).strip()[-400:]}")
    return r.stdout.strip()


def step(name, fn):
    try:
        print(f"PASS {name}: {fn()}", flush=True)
        return True
    except Exception as exc:                                     # noqa: BLE001 -- said, never hidden
        print(f"FAIL {name}: {exc}", flush=True)
        return False


def catalog_tables():
    sql = (ROOT / "rig" / "postgres-init" / "02-iceberg-catalog-tables.sql").read_text(encoding="utf-8")
    r = run(["docker", "exec", "-i", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
             "-v", "ON_ERROR_STOP=1", "-q"], stdin=sql)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip()[-300:])
    return "iceberg_tables + iceberg_namespace_properties present"


def iceberg_qs():
    trino("CREATE SCHEMA IF NOT EXISTS iceberg.qs")
    trino(REGION_LOOKUP)
    trino(TRADES, timeout=3600)
    n = int(trino("SELECT count(*) FROM iceberg.qs.trades"))
    if n <= 0:
        raise RuntimeError("iceberg.qs.trades is empty")
    return f"iceberg.qs.trades {n:,} rows, region_lookup {trino('SELECT count(*) FROM iceberg.qs.region_lookup')} rows"


def s3_trades(call, tok):
    r = run(["docker", "exec", "qs-minio", "sh", "-c",
             "mc alias set l http://localhost:9000 \"$MINIO_ROOT_USER\" \"$MINIO_ROOT_PASSWORD\" >/dev/null "
             "&& mc ls --recursive l/qs-data/trades/ | head -1"])
    if not r.stdout.strip():
        cp = run(["docker", "cp", str(ROOT / "scripts" / "seed_s3_rig.py"), "qs-local-api:/tmp/seed_s3_rig.py"])
        if cp.returncode != 0:
            raise RuntimeError(f"docker cp: {cp.stderr.strip()[-200:]}")
        g = run(["docker", "exec", "-e", f"QS_S3_KEY={os.environ.get('QS_MINIO_USER', 'qsadmin')}",
                 "-e", f"QS_S3_SECRET={os.environ.get('QS_MINIO_PASSWORD', 'QsMinio_12345')}",
                 "qs-local-api", "python", "/tmp/seed_s3_rig.py", "--files", "7300", "--keys-in-path-only"],
                timeout=3600)
        if g.returncode != 0:
            raise RuntimeError(f"seed_s3_rig: {(g.stderr or g.stdout).strip()[-300:]}")
        made = "built 7,300 files"
    else:
        made = "already in MinIO"
    s, conns = call("GET", "/api/connections?limit=1000", token=tok)
    items = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
    cid = next((c["id"] for c in items if c["name"] == "minio-rig"), None)
    s, tabs = call("GET", f"/api/connections/{cid}/tables", token=tok)
    if not any(t.get("name") == "trades" for t in (tabs or {}).get("tables") or []):
        s, b = call("POST", f"/api/connections/{cid}/tables",
                    {"name": "trades", "s3_prefix": "trades/", "format": "parquet",
                     "description": "hive-partitioned trades (scripts/seed_s3_rig.py)",
                     "partition_columns": ["region", "dt"]}, token=tok, timeout=600)
        if s not in (200, 201):
            raise RuntimeError(f"register trades on minio-rig: HTTP {s} {str(b)[:200]}")
        made += ", registered on minio-rig"
    return "s3://qs-data/trades/ " + made


def aws_tables():
    bucket = os.environ.get("QS_AWS_BUCKET")
    spec = json.loads((ROOT / "rig" / "aws_tables.json").read_text(encoding="utf-8"))["tables"]
    done, new = 0, 0
    for t in spec:
        trino(f"CREATE SCHEMA IF NOT EXISTS iceberg_aws.{t['schema']} WITH (location = 's3://{bucket}/iceberg/{t['schema']}')")
        have = trino(f"SHOW TABLES FROM iceberg_aws.{t['schema']}").split()
        if t["table"] not in have:
            trino(f"CALL iceberg_aws.system.register_table(schema_name => '{t['schema']}', "
                  f"table_name => '{t['table']}', table_location => 's3://{bucket}/{t['location']}')")
            new += 1
        done += 1
    n = trino("SELECT count(*) FROM iceberg_aws.fin.fact_tetb")
    return f"{done} tables in iceberg_aws ({new} registered now); fin.fact_tetb {int(n):,} rows"


def bqb_trades(call, tok):
    s, b = call("GET", "/api/datasets?limit=1000", token=tok)
    items = b if isinstance(b, list) else ((b or {}).get("items") or (b or {}).get("datasets") or [])
    ds = next((d for d in items if isinstance(d, dict) and d.get("name") == "bqb_trades"), None)
    made = "exists"
    if ds is None:
        s, conns = call("GET", "/api/connections?limit=1000", token=tok)
        citems = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
        tid = next(c["id"] for c in citems if c["name"] == "trino-rig")
        s, ds = call("POST", "/api/datasets", {"name": "bqb_trades", "subject": "trades", "connection_ids": [tid],
                                               "source_tables": [{"connection_id": tid, "table": "iceberg.qs.trades"}]},
                     token=tok, timeout=300)
        if s not in (200, 201):
            raise RuntimeError(f"create bqb_trades: HTTP {s} {str(ds)[:200]}")
        made = "created"
    s, d = call("GET", f"/api/datasets/{ds['id']}", token=tok)
    if not (d or {}).get("columns"):
        s, b = call("POST", f"/api/datasets/{ds['id']}/auto-detect", {}, token=tok, timeout=600)
        if s not in (200, 201):
            raise RuntimeError(f"auto-detect bqb_trades: HTTP {s} {str(b)[:200]}")
        s, d = call("GET", f"/api/datasets/{ds['id']}", token=tok)
    names = sorted(str(c.get("physical_name") or "").lower() for c in (d or {}).get("columns") or [])
    want = ["amt", "book", "ccy", "counterparty", "desk", "dt", "id", "qty", "region", "status", "trade_ts"]
    if names != want:
        raise RuntimeError(f"bqb_trades columns {names} != {want}")
    return f"dataset bqb_trades id={ds['id']} ({made}), 11 columns"


def aws_connection_tables(call, tok):
    spec = json.loads((ROOT / "rig" / "aws_tables.json").read_text(encoding="utf-8"))["connection_tables"]
    s, conns = call("GET", "/api/connections?limit=1000", token=tok)
    items = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
    cid = next((c["id"] for c in items if c["name"] == "aws-real"), None)
    if cid is None:
        raise RuntimeError("no aws-real connection")
    s, tabs = call("GET", f"/api/connections/{cid}/tables", token=tok)
    have = {t.get("name") for t in (tabs or {}).get("tables") or []}
    new = 0
    for t in spec:
        if t["name"] in have:
            continue
        body = {"name": t["name"], "s3_prefix": t["s3_prefix"], "format": t["format"],
                "partition_columns": t.get("partition_columns", [])}
        s, b = call("POST", f"/api/connections/{cid}/tables", body, token=tok, timeout=600)
        if s not in (200, 201):
            raise RuntimeError(f"register {t['name']} on aws-real: HTTP {s} {str(b)[:200]}")
        new += 1
    return f"{len(spec)} tables on aws-real ({new} registered now)"


def watcher_interval():
    # a DATABASE setting on the dev rig (system_settings, set from the Admin screen): the
    # Iceberg watcher checks every 60 s instead of the 30-minute default, so the S3
    # background proofs see a commit inside their window
    sql = ("INSERT INTO system_settings (key, value, description, updated_by, updated_at) VALUES "
           "('iceberg_watcher.interval_seconds', '60', 'test rig: watcher every 60 s (rig/seed_data.py)', "
           "'rig-seed', now()) ON CONFLICT (key) DO NOTHING")
    r = run(["docker", "exec", "-i", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
             "-v", "ON_ERROR_STOP=1", "-q", "-c", sql])
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip()[-300:])
    return "iceberg_watcher.interval_seconds = 60"


#: the topics the dependency rules listen on (docker-compose.rig.yml ->
#: QUERYSTUDIO_FEED_GENERATION_DEPENDENCY_KAFKA).  A fresh broker has none and
#: refuses a produce to an unknown topic (found 2026-10-16).
KAFKA_TOPICS = ("qs.dep.t1", "qs.dep.t2", "tetb.partition.ready", "qs.kafka.message")


def kafka_topics():
    r = run(["docker", "exec", "qs-kafka", "rpk", "topic", "list"])
    have = {ln.split()[0] for ln in r.stdout.splitlines()[1:] if ln.strip()}
    new = [t for t in KAFKA_TOPICS if t not in have]
    for t in new:
        c = run(["docker", "exec", "qs-kafka", "rpk", "topic", "create", t, "-p", "1", "-r", "1"])
        if c.returncode != 0 and "TOPIC_ALREADY_EXISTS" not in (c.stdout + c.stderr):
            raise RuntimeError(f"create topic {t}: {(c.stderr or c.stdout).strip()[-200:]}")
    return f"{len(KAFKA_TOPICS)} topics ({len(new)} created now)"


def seed(call, tok) -> int:
    ok = [step("Kafka topics", kafka_topics),
          step("Iceberg catalog tables", catalog_tables),
          step("iceberg.qs (trades, region_lookup)", iceberg_qs),
          step("dataset bqb_trades", lambda: bqb_trades(call, tok)),
          step("S3 trades corpus", lambda: s3_trades(call, tok)),
          step("Iceberg watcher interval", watcher_interval)]
    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("QS_AWS_BUCKET"):
        ok.append(step("REAL AWS Iceberg tables", aws_tables))
        ok.append(step("REAL AWS tables on aws-real", lambda: aws_connection_tables(call, tok)))
    else:
        print("SKIP REAL AWS Iceberg tables: no AWS keys in rig/rig.env")
    return sum(1 for x in ok if not x)
