"""Published API: a DATE / TIMESTAMP filter on a SQL-sourced view over Trino
(the Starburst engine) answers the SOURCE's rows -- live on Docker (2026-10-05).

Owner: "starburst based api never works if where clause has date type columns
and we are just passing plain text".  Reproduced: every date/timestamp filter
on a view published from a SQL query answered 500 (Trino TYPE_MISMATCH,
`date = varchar`), while a REPORT-sourced view over the same table worked.

Truth comes from Trino itself, never from the thing under test.  Checks:
  * SQL view: =, eq:, between:, gte:, bare IN list on DATE; gte: on TIMESTAMP
    -> totals == Trino's counts;
  * a value that is not a date -> 400 naming the column (never 500, never
    silently dropped -- a dropped filter returns MORE rows);
  * a VARCHAR column still compares as text;
  * the REPORT view over the same table still answers the same totals.

    python scripts/docker_proof/pv_date_filter_proof.py      # QS_TRINO_CONN=2
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

TR = int(os.environ.get("QS_TRINO_CONN", "2"))
TAG = str(int(time.time()))[-6:]
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"{'PASS' if ok else 'FAIL'} {name} -- {str(detail)[:260]}", flush=True)


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV",
                          "--execute", sql], capture_output=True, text=True)
    return [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]


def total(slug, query, key):
    """Rows the view RETURNS for the filter.  A SQL-sourced view reports
    total_mode=at_least (it does not count the whole result), so the check is
    the returned rows themselves, on a page larger than every truth here."""
    s, b, _ = c.call("GET", f"/api/v1/views/{slug}/data?limit=50000&{query}",
                     headers={"X-API-Key": key})
    return s, (len(b.get("data") or []) if isinstance(b, dict) and s == 200 else None), b


def main():
    T = "iceberg.qs.trades"
    cases = [  # (label, query string, truth SQL predicate)
        ("DATE bare =", "dt=1995-03-15", "dt = date '1995-03-15'"),
        ("DATE eq:", "filter.dt=eq:1995-03-15", "dt = date '1995-03-15'"),
        ("DATE between:", "filter.dt=between:1995-03-01,1995-03-05",
         "dt between date '1995-03-01' and date '1995-03-05'"),
        ("DATE gte:", "filter.dt=gte:1998-08-01", "dt >= date '1998-08-01'"),
        ("DATE bare IN list", "dt=1995-03-15,1995-03-16",
         "dt in (date '1995-03-15', date '1995-03-16')"),
        ("TIMESTAMP gte:", "filter.trade_ts=" + urllib.parse.quote("gte:1998-08-01 00:00:00"),
         "trade_ts >= timestamp '1998-08-01 00:00:00'"),
        ("VARCHAR still text (with a DATE)", "region=ASIA&dt=1995-03-15",
         "region = 'ASIA' and dt = date '1995-03-15'"),
    ]
    truth = {}
    for label, _, pred in cases:
        truth[label] = int(trino(f"select count(*) from {T} where {pred}")[0][0])
    check("truth: Trino answered every case, and the date cases are non-empty",
          all(truth[l] > 0 for l in truth), truth)

    undo = []
    try:
        s, sq, _ = c.call("POST", "/api/sql/queries", {
            "name": f"dtp_sq_{TAG}", "primary_connection_id": TR,
            "primary_sql": f"select id, dt, trade_ts, region, amt from {T}"})
        undo.append(f"/api/sql/queries/{sq['id']}")
        s, pv, _ = c.call("POST", "/api/published-views", {
            "name": f"dtp-sql-{TAG}", "slug": f"dtp-sql-{TAG}", "source_type": "sql_query",
            "sql_query_id": sq["id"], "credential_mode": "publisher",
            "allowed_filters": ["dt", "trade_ts", "region"]})
        undo.insert(0, f"/api/published-views/{pv['id']}")
        s, k, _ = c.call("POST", "/api/api-keys", {"name": f"dtp-key-{TAG}",
                                                     "scoped_view_ids": [pv["id"]]})
        undo.append(f"/api/api-keys/{k['id']}")
        key, slug = k["raw_key"], f"dtp-sql-{TAG}"

        for label, q, _ in cases:
            s, tot, b = total(slug, q, key)
            check(f"SQL view {label}: rows returned == Trino ({truth[label]:,})",
                  s == 200 and tot == truth[label],
                  {"status": s, "rows": tot, "body": "" if s == 200 else str(b)[:200]})

        s, tot, b = total(slug, "dt=not-a-date", key)
        detail = str((b or {}).get("detail", "")) if isinstance(b, dict) else str(b)
        check("a value that is not a date -> 400 naming the column (never 500, never dropped)",
              s == 400 and "dt" in detail, {"status": s, "detail": detail[:200]})
    finally:
        for u in undo:
            c.call("DELETE", u)
    print(f"{sum(res)}/{len(res)} PASSED" if all(res) else f"{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
