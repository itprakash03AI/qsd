"""The WORST queries a user can send at S3 -- on REAL AWS, live on Docker (2026-10-06).

Owner: "test all edge cases, what worst or complex query can run on s3 ...
should not crash, follow island rules, never crash ... small chunking is ok ...
s3 is bread and butter of this tool".

Data: the Trial Balance data products on the owner's bucket (see aws_tb_proof.py).
The bar for EVERY query, through QueryStudio's S3 engine (POST /api/execute):
  * the answer equals Trino's on the same tables, OR
  * it is REFUSED with a reason the user can act on (4xx, or 503 + Retry-After) --
    never a 500 "contact support", never a hang past the timeout;
  * NO container restarted or was OOM-killed, and /health/live still answers;
  * a partition-filtered query reads its ISLAND (the files-after-prune in the log),
    never the ocean.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/aws_s3_worst_queries_proof.py [--only W1,W2] [--timeout 1800]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from aws_tb_proof import CAT, K5, string_type_violations, summarise, truth_of  # noqa: E402

S3_CONN_NAME = os.environ.get("QS_AWS_CONN_NAME", "aws-real")
CONTAINERS = ["qs-local-api", "qs-local-executor", "qs-local-reports", "qs-local-published-api", "qs-local-postgres"]
res, rows_out = [], []

# Truth computed without materialising the explosion (same answer, by algebra):
# |A join B on k| = sum over k of count_A(k) * count_B(k).
TRUTH_SQL = {
    "W4": "select sum(c * c) as n from (select system_id, count(*) as c from iceberg_aws.fin.fact_tetb "
          "where business_close_date = DATE '2025-09-30' group by system_id) t",
    # Trino's grammar is OFFSET ... LIMIT (it refuses LIMIT ... OFFSET); same rows.
    "W18": "select source_data_row, code, business_event, gbp_currency_amount from iceberg_aws.fin.fact_tetb "
           "where business_close_date = DATE '2025-09-30' "
           "order by gbp_currency_amount desc, code, business_event, source_data_row offset 150000 limit 50",
}

F = "{p}fact_tetb"
E = "{p}fact_tetb_ext"
# (id, what, SQL, compare mode, expected island files or None -- the post-prune
#  TOTAL across every table the query reads, which is what the engine logs)
WORST = [
    ("W1", "no partition filter: SELECT * the whole fact (806k rows, 2,688 files)",
     "select * from {p}fact_tetb", "rows+sum:gbp_currency_amount", None),
    ("W2", "5-key join over ALL COBs (no partition filter)",
     "select count(*) as n, sum(f.gbp_currency_amount) as gbp, sum(e.ext_002) as x from {p}fact_tetb f join {p}fact_tetb_ext e on " + K5, "exact", None),
    ("W3", "4-table join: fact x ext x GL dim x entity dim, one COB, grouped",
     "select g.category, l.region, f.business_event, count(*) as n, sum(f.gbp_currency_amount) as gbp from {p}fact_tetb f join {p}fact_tetb_ext e on " + K5 +
     " join {p}dim_gl_account g on f.gl_account = g.gl_account join {p}dim_legal_entity l on f.sap_company_id = l.sap_company_id "
     "where f.business_close_date = DATE '2025-09-30' group by 1,2,3", "exact", 672 + 673 + 2),
    ("W4", "many-to-many join on a NON-key column (system_id) -- explosive",
     "select count(*) as n from {p}fact_tetb a join {p}fact_tetb b on a.system_id = b.system_id "
     "where a.business_close_date = DATE '2025-09-30' and b.business_close_date = DATE '2025-09-30'", "exact", 672 * 2),
    ("W5", "cross join of three dims (10.8M rows), aggregated",
     "select count(*) as n, count(distinct g.category) as c from {p}dim_gl_account g cross join {p}dim_legal_entity l cross join {p}dim_cost_centre cc", "exact", None),
    ("W6", "filter on a NON-partition column only (system_id = 'SAP')",
     "select business_close_date, count(*) as n, sum(gbp_currency_amount) as gbp from {p}fact_tetb where system_id = 'SAP' group by 1", "exact", None),
    ("W7", "function on the partition column: date_trunc('month', business_close_date)",
     "select count(*) as n, sum(gbp_currency_amount) as gbp from {p}fact_tetb where date_trunc('month', business_close_date) = DATE '2025-10-01'", "exact", None),
    ("W8", "CAST(code AS integer) > 50 -- numeric compare on a string partition",
     "select count(*) as n from {p}fact_tetb where business_close_date = DATE '2025-09-29' and try_cast(code as integer) > 50", "exact", None),
    ("W9", "code LIKE '1%' on a partition column",
     "select code, count(*) as n from {p}fact_tetb where business_close_date = DATE '2025-09-29' and code like '1%' group by code", "exact", None),
    ("W10", "OR across partitions: (COB A and event X) OR (COB B and code Y)",
     "select count(*) as n, sum(gbp_currency_amount) as gbp from {p}fact_tetb where (business_close_date = DATE '2025-09-29' and business_event = 'BOOKING') "
     "or (business_close_date = DATE '2025-10-01' and code = '1000')", "exact", None),
    ("W11", "NOT IN on partition columns",
     "select count(*) as n from {p}fact_tetb where business_close_date = DATE '2025-09-30' and code not in ('SAP','ORACLE','1000') "
     "and business_event not in ('CANCEL')", "exact", None),
    ("W12", "IS NULL on the evolved column across old + new files",
     "select count(*) as n from {p}fact_tetb where reporting_basis is null", "exact", None),
    ("W13", "window function over a whole COB: ROW_NUMBER / running SUM per code",
     "select count(*) as n, sum(rk) as s from (select code, row_number() over (partition by code order by gbp_currency_amount desc, source_data_row) as rk, "
     "sum(gbp_currency_amount) over (partition by code order by source_data_row rows unbounded preceding) as run from {p}fact_tetb "
     "where business_close_date = DATE '2025-09-30') t where rk <= 10", "exact", 672),
    ("W14", "GROUP BY 806k groups (every row its own group), all COBs",
     "select count(*) as groups, sum(n) as n from (select business_close_date, business_event, code, source_data_row, count(*) as n "
     "from {p}fact_tetb group by 1,2,3,4) t", "exact", None),
    ("W15", "COUNT DISTINCT on high-cardinality columns",
     "select count(distinct source_data_row) as d1, count(distinct gl_account || cost_centre) as d2, count(distinct load_ts) as d3 from {p}fact_tetb "
     "where business_close_date = DATE '2025-09-30'", "exact", 672),
    ("W16", "IN (subquery) + EXISTS + CTE",
     "with sap as (select distinct source_data_row from {p}fact_tetb where business_close_date = DATE '2025-09-30' and system_id = 'SAP') "
     "select count(*) as n from {p}fact_tetb_ext e where e.business_close_date = DATE '2025-09-30' and e.source_data_row in (select source_data_row from sap) "
     "and exists (select 1 from {p}dim_fx_rate x where x.business_close_date = e.business_close_date)", "exact", None),
    ("W17", "UNION ALL of two COBs + nested aggregate",
     "select max(n) as mx, min(n) as mn, count(*) as k from (select code, count(*) as n from (select code from {p}fact_tetb where business_close_date = DATE '2025-09-29' "
     "union all select code from {p}fact_tetb where business_close_date = DATE '2025-10-01') u group by code) t", "exact", None),
    ("W18", "big ORDER BY + LIMIT/OFFSET deep page",
     "select source_data_row, code, business_event, gbp_currency_amount from {p}fact_tetb where business_close_date = DATE '2025-09-30' "
     "order by gbp_currency_amount desc, code, business_event, source_data_row limit 50 offset 150000", "exact", 672),
    ("W19", "1,000-column table, NO filter, SELECT *",
     "select * from {p}fact_tetb_wide", "rows+cols+sum:w_0001", None),
    ("W21", "TOP-N: ORDER BY amount DESC LIMIT 10 over one COB (the commonest report shape)",
     "select source_data_row, code, business_event, gbp_currency_amount from {p}fact_tetb where business_close_date = DATE '2025-09-30' "
     "order by gbp_currency_amount desc, code, business_event, source_data_row limit 10", "exact", 672),
    ("W20", "journal x TB x 3 dims, all COBs, grouped by GL hierarchy",
     "select g.account_group, g.category, cc.division, count(*) as n, sum(j.gbp_amount) as gbp from {p}fact_journal j "
     "join {p}fact_tetb f on f.business_close_date = j.business_close_date and f.code = j.code and f.business_event = j.business_event "
     "and f.source_data_set = j.source_data_set and f.source_data_row = j.source_data_row "
     "join {p}dim_gl_account g on j.gl_account = g.gl_account join {p}dim_cost_centre cc on j.cost_centre = cc.cost_centre group by 1,2,3", "exact", None),
]


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"{'PASS' if ok else 'FAIL'} {name} -- {str(detail)[:420]}", flush=True)
    return ok


def container_state():
    out = {}
    for n in CONTAINERS:
        r = subprocess.run(["docker", "inspect", n, "--format", "{{.RestartCount}} {{.State.OOMKilled}} {{.State.StartedAt}}"],
                           capture_output=True, text=True)
        out[n] = r.stdout.strip()
    return out


def health():
    """/health/live probed from INSIDE the api container, 3 tries.  A single
    probe through Docker Desktop's Windows port forwarding (which drops ~13% of
    connections on this host) measured the laptop, not the product; a real
    hang still fails all three."""
    for _ in range(3):
        r = subprocess.run(["docker", "exec", "qs-local-api", "curl", "-s", "-o", "/dev/null", "-m", "10",
                            "-w", "%{http_code}", "http://localhost:8000/health/live"], capture_output=True, text=True)
        if r.stdout.strip() == "200":
            return 200
        time.sleep(3)
    return int(r.stdout.strip() or 0)


def run(sql, conn, timeout):
    t0 = time.time()
    s, b, h = c.call("POST", "/api/execute", {"connection_id": conn, "cache_strategy": "bypass", "raw_sql": sql}, timeout=120)
    if s != 200 or not (b or {}).get("execution_id"):
        return {"refused": s, "detail": str((b or {}).get("detail") if isinstance(b, dict) else b)[:300],
                "retry_after": (h or {}).get("Retry-After"), "secs": round(time.time() - t0, 1)}
    eid = b["execution_id"]
    while time.time() - t0 < timeout:
        s, st, _ = c.call("GET", f"/api/executions/{eid}/status")
        stt = (st or {}).get("status") if isinstance(st, dict) else None
        if stt in ("completed", "success", "finished"):
            break
        if stt in ("failed", "error", "cancelled"):
            return {"failed": str((st or {}).get("error_message"))[:400], "secs": round(time.time() - t0, 1), "eid": eid}
        time.sleep(2)
    else:
        c.call("POST", f"/api/executions/{eid}/cancel")
        return {"timeout": timeout, "eid": eid}
    # 2026-10-06 -- the status said completed with total_rows; a results page
    # that FAILED (the server died mid-request: connection reset, 5xx, 404)
    # used to read as "no more rows" and was reported as completed with 0
    # rows x 0 columns -- the execution's artifact was on disk with 160 rows.
    # Unknown is not empty: a non-200 page, a pending / failed page, or a row
    # count that disagrees with the status is a FAILED run here.
    expected_rows = (st or {}).get("total_rows") if isinstance(st, dict) else None
    out, cols, n = [], None, 1
    while True:
        s, rb, _ = c.call("GET", f"/api/executions/{eid}/results?page={n}&page_size=5000")
        if s != 200 or not isinstance(rb, dict):
            return {"failed": f"results page {n} answered HTTP {s} "
                              f"({str(rb)[:200]}) -- the rows are UNKNOWN, not empty",
                    "secs": round(time.time() - t0, 1), "eid": eid}
        if str(rb.get("status") or "") in ("pending", "failed", "cancelled", "error"):
            return {"failed": f"results page {n} says status={rb.get('status')} "
                              f"({str(rb.get('error') or '')[:200]})",
                    "secs": round(time.time() - t0, 1), "eid": eid}
        names = [x["name"] if isinstance(x, dict) else x for x in (rb or {}).get("columns") or []]
        cols = cols or names
        rows = [(r if isinstance(r, dict) else dict(zip(names, r))) for r in (rb or {}).get("rows") or []]
        if not rows:
            break
        out += rows
        if len(rows) < 5000:
            break
        n += 1
    if isinstance(expected_rows, int) and expected_rows != len(out):
        return {"failed": f"status said total_rows={expected_rows}, the results "
                          f"pages held {len(out)}", "secs": round(time.time() - t0, 1),
                "eid": eid}
    return {"cols": cols or [], "rows": out, "secs": round(time.time() - t0, 1), "eid": eid}


def island_files(eid):
    """files-after-prune the engine logged for this execution (None = not logged)."""
    r = subprocess.run(["docker", "logs", "--since", "60m", "qs-local-api"], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    best = None
    for ln in ((r.stdout or "") + (r.stderr or "")).splitlines():
        if eid in ln and "post-prune scan total" in ln:
            try:
                best = int(ln.split("post-prune scan total:")[1].split("file")[0].strip())
            except Exception:
                pass
    return best


ACTIONABLE = ("refused", "scan budget", "too many", "narrow", "capacity", "memory", "limit", "retry", "exceed", "not supported", "cannot")


def verdict(qid, what, out, truth, mode, island, before):
    after = container_state()
    h = health()
    stable = all(after[n] == before[n] for n in CONTAINERS) and h == 200
    if "rows" in out:
        got = summarise(out["cols"], out["rows"], mode)
        bad_types = string_type_violations(out["rows"])
        ok = got == truth and not bad_types
        isl = island_files(out["eid"]) if island else None
        island_ok = island is None or isl is None or isl <= island + 2
        check(f"{qid} {what} ({out['secs']}s)", ok and stable and island_ok,
              {"correct": ok, "string_type_violations": bad_types, "stable": stable, "island_files": isl, "expected_island": island,
               "got": (got if mode != "exact" else got[:4]), "truth": (truth if mode != "exact" else truth[:4]),
               "containers": None if stable else {"before": before, "after": after, "health": h}})
    elif "refused" in out:
        s = out["refused"]
        ok = (400 <= s < 500 or (s == 503 and out.get("retry_after"))) and any(w in out["detail"].lower() for w in ACTIONABLE)
        check(f"{qid} {what} -> REFUSED with a reason ({s})", ok and stable, {"detail": out["detail"], "stable": stable})
    elif "failed" in out:
        msg = out["failed"].lower()
        ok = any(w in msg for w in ACTIONABLE) and "internal" not in msg and "contact support" not in msg
        check(f"{qid} {what} -> FAILED ({out['secs']}s)", ok and stable,
              {"reason": out["failed"], "actionable": ok, "stable": stable})
    else:
        check(f"{qid} {what} -> TIMED OUT after {out.get('timeout')}s (cancelled)", False, {"stable": stable})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--concurrent", action="store_true", help="also run 5 heavy queries at once")
    a = ap.parse_args()
    only = set(filter(None, a.only.split(",")))
    s, b, _ = c.call("GET", "/api/connections")
    items = b if isinstance(b, list) else (b.get("items") or b.get("connections") or [])
    conn = next(x["id"] for x in items if x.get("name") == S3_CONN_NAME)
    for qid, what, tmpl, mode, island in WORST:
        if only and qid not in only:
            continue
        try:
            truth = truth_of(TRUTH_SQL.get(qid) or tmpl.format(p=CAT), mode)
        except Exception as exc:  # noqa: BLE001
            check(f"{qid} truth", False, f"Trino could not answer: {exc}")
            continue
        before = container_state()
        out = run(tmpl.format(p=""), conn, a.timeout)
        verdict(qid, what, out, truth, mode, island, before)
    if a.concurrent and (not only or "C1" in only):
        heavy = [WORST[1], WORST[2], WORST[12], WORST[13], WORST[19]]
        before = container_state()
        t0 = time.time()
        with cf.ThreadPoolExecutor(5) as ex:
            outs = list(ex.map(lambda q: run(q[2].format(p=""), conn, a.timeout), heavy))
        after = container_state()
        kinds = [("ok" if "rows" in o else "refused" if "refused" in o else "failed" if "failed" in o else "timeout") for o in outs]
        stable = all(after[n] == before[n] for n in CONTAINERS) and health() == 200
        check(f"C1 five heavy queries at once ({round(time.time() - t0)}s wall): each answered or shed, nothing crashed",
              stable and "timeout" not in kinds, {"outcomes": kinds, "stable": stable,
                                                  "failed": [o.get("failed") for o in outs if "failed" in o]})
    print(f"\n{sum(res)}/{len(res)} PASSED" if all(res) else f"\n{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
