"""A feed declared "on completion of X" STARTS BY ITSELF when X completes and
delivers -- live on Docker, login ON.  Written 2026-10-03 against the real
Snowflake account; since 2026-10-05 (that account was decommissioned) it runs
on the on-prem Trino/Iceberg source -- the trigger does not depend on the
engine, and a proof must keep running after a trial ends.

Owner: "yes it's common sense".  Feeds A and B on the source connection,
B declared on_completion_of A; F a feed whose SQL fails, G on_completion_of F.

  1. a cycle (A on_completion_of B) is refused, naming it;
  2. Run Now on A -> A completes AND delivers -> a run of B appears for the
     same business date, triggered_by upstream_completion, naming A and A's
     execution -> the queue worker runs it -> B completes, its file has the
     rows the source has;
  3. A again for the same date -> still exactly ONE run of B, and A's run
     events say already_exists;
  4. F fails -> G gets NO run, and F's events say why.

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/feed_on_completion_proof.py      # QS_SOURCE_CONN=2 (Trino)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

CID = int(os.environ.get("QS_SOURCE_CONN", "2"))
TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:320], flush=True)
    return bool(ok)


def pg(sql):
    out = subprocess.run(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
                          "-tA", "-F", "|", "-c", sql], capture_output=True, text=True, env=DENV)
    return [line.split("|") for line in out.stdout.strip().splitlines() if line.strip()]


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    made = []

    def feed(name, sql, decl=None):
        body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": CID,
                "output_format": "csv", "destination_type": "local",
                "destination_config": {"path": "/app/data/feeds"}, "query_params": {"sql": sql}}
        if decl:
            body["schedule_declaration"] = decl
        s, b, _ = admin.call("POST", "/api/feeds", body)
        if s == 200:
            made.append(b["id"])
        return s, b

    def run_now(fid):
        s, ex, _ = admin.call("POST", f"/api/feeds/{fid}/execute", {"trigger_type": "manual"})
        dbid = (ex or {}).get("execution_db_id")
        e, t0 = {}, time.time()
        while dbid and time.time() - t0 < 300:
            _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
            if (e or {}).get("status") in ("completed", "failed", "error", "cancelled", "skipped"):
                break
            time.sleep(2)
        return s, ex, e

    try:
        A, B, F, G = (f"OC_A_{TAG}", f"OC_B_{TAG}", f"OC_F_{TAG}", f"OC_G_{TAG}")
        s, a = feed(A, "select region as REGION, count(*) as N from iceberg.qs.trades group by region")
        s2, b = feed(B, "select region as REGION, sum(amt) as AMT from iceberg.qs.trades group by region",
                     {"kind": "on_completion_of", "feed": A})
        check("A, and B on_completion_of A, created", s == 200 and s2 == 200, (s, s2, str(b)[:200]))

        print("\n== 1 . a cycle is refused")
        s, cyc, _ = admin.call("PUT", f"/api/feeds/{a['id']}", {"schedule_declaration": {"kind": "on_completion_of", "feed": B}})
        check("A on_completion_of B -> 422 naming the cycle", s == 422 and A in str(cyc) and B in str(cyc), (s, str(cyc)[:240]))

        print("\n== 2 . A completes and delivers -> B starts by itself")
        s, ex, e = run_now(a["id"])
        check("A completed (Run Now)", (e or {}).get("status") == "completed", (s, (e or {}).get("status"), str((e or {}).get("error_message"))[:200]))
        a_exec = (e or {}).get("execution_id") or (ex or {}).get("execution_id")
        t0, rows = time.time(), []
        while time.time() - t0 < 240:
            rows = pg(f"select id, status, triggered_by, upstream_feed_name, upstream_execution_id, business_date "
                      f"from feed_runs where feed_config_id = {b['id']} order by id")
            if rows and rows[-1][1] in ("completed", "failed", "skipped"):
                break
            time.sleep(5)
        waited = round(time.time() - t0)
        check("exactly one run of B, triggered by A's completion, naming A and A's execution",
              len(rows) == 1 and rows[0][2] == "upstream_completion" and rows[0][3].upper() == A
              and (not a_exec or rows[0][4] == str(a_exec)), (rows, a_exec))
        check(f"the queue worker ran B to completion ({waited}s after A)", rows and rows[-1][1] == "completed", rows)
        bex = pg(f"select status, destination_path, total_rows from feed_executions where feed_config_id = {b['id']} order by id desc limit 1")
        body = ""
        if bex and bex[0][1]:
            body = subprocess.run(["docker", "exec", "qs-local-api", "cat", bex[0][1]], capture_output=True,
                                  text=True, env=DENV).stdout
            subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", bex[0][1]], env=DENV)
        lines = [ln for ln in body.splitlines()[1:] if ln.strip()]
        check("B's file has the source's 5 regions", len(lines) == 5 and {ln.split(",")[0].strip('"') for ln in lines} == {"AFRICA", "AMERICA", "ASIA", "EUROPE", "MIDDLE EAST"}, (bex, lines))
        ev = pg(f"select event_type, payload from run_events where feed_config_id = {a['id']} and event_type like 'downstream_%' order by id")
        check("A's run events record the downstream run it created", ev and ev[0][0] == "downstream_triggered", ev)

        print("\n== 3 . A again for the same date -> still ONE run of B")
        run_now(a["id"])
        time.sleep(10)
        rows2 = pg(f"select id from feed_runs where feed_config_id = {b['id']}")
        ev2 = pg(f"select event_type, payload from run_events where feed_config_id = {a['id']} and event_type like 'downstream_%' order by id")
        check("one run of B, and A's events say already_exists", len(rows2) == 1 and any("already" in (p or "") for _, p in ev2), (rows2, ev2[-1:]))

        print("\n== 4 . a FAILED upstream starts nothing, and says why")
        s, f = feed(F, "select * from iceberg.qs.no_such_table")
        s2, g = feed(G, "select 1 as X", {"kind": "on_completion_of", "feed": F})
        _, _, fe = run_now(f["id"])
        time.sleep(10)
        grows = pg(f"select id from feed_runs where feed_config_id = {g['id']}")
        fev = pg(f"select event_type, payload from run_events where feed_config_id = {f['id']} and event_type like 'downstream_%' order by id")
        check("F failed; G has NO run", (fe or {}).get("status") in ("failed", "error") and not grows, ((fe or {}).get("status"), grows))
        check("F's events say why G was not started", fev and fev[-1][0] == "downstream_not_triggered", fev)
    finally:
        for fid in reversed(made):
            admin.call("DELETE", f"/api/feeds/{fid}")
        print(f"\ncleanup: {len(made)} feeds removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
