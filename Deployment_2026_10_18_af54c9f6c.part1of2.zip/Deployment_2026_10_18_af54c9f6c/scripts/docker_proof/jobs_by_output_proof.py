"""Every NON-S3 background job proven on the live Docker rig BY WHAT IT PRODUCED (2026-10-08).

Part C of s3_background_proof.py proved status + an honest run-now for every
declared job.  "It ticked" is not "it did its job": this harness PLANTS each
job's input (through the product's own routes where one exists, else a row in
the metadata DB / a file on the owner's disk), lets the job FIRE where it
really runs, and judges the OUTPUT against an independent truth -- the
metadata DB, files in the container, mailpit's inbox, the Netcool stub's
received log, the Clockwork ledger.  A check that measured nothing FAILS: every
plant is counted before the job runs, and "the old row is gone" is only a pass
when "the fresh row is still there" also holds.

WHO FIRES IT.  The owner is the scheduler pod (the ``scheduler_lock`` holder;
its control API is on 127.0.0.1:8001).  On this rig the api container is
``hybrid`` + ``scheduler.mode=embedded``, so ``POST /api/admin/background-jobs/
{name}/run-now`` on :8000 runs the tick on the API POD (a hybrid pod counts
itself an owner) and a ``job_id``-shaped job answers ``skipped: not registered
in this process`` there.  So every "run-now on the owner" below goes to the
owner's own control route, ``POST :8001/control/background-job/{name}/
run-now``, and the tick's ``pod_id`` is asserted to be the lock holder.
A job whose interval is short enough (<= 5 min) is left to fire BY ITSELF and
the judge waits for its output; APScheduler intervals are read ONCE at
registration (``register_retention_daemons``), so the hour-scale sweeps cannot
be shortened without a restart and are run-now on the owner, and the table
says so.

THE JOB TABLE (job -> planted input -> expected output -> how it fires)

  S  fires BY ITSELF on the scheduler pod
  S1 feed_netcool_sender       a pending_notifications netcool_event row    -> row delivered=true; the stub holds EXACTLY ONE event with that Identifier      thread, poll 5 s
  S2 feed_sla_watcher          a feed (sla_to 00:01 UTC) + a never-arriving  -> a BREACHED netcool event for that dependency+date enqueued, then at the stub    thread, 60 s
                               dependency + a WAIT run for today (DB row)
  S3 feed_consumer_late_watch  a `late` subscription (route) on that feed     -> ONE feed_consumer_notices row, ONE mail "[QueryStudio] <feed> is LATE",     APScheduler, 300 s
                                                                                 ONE bell row; a second pass adds nothing
  S4 feed_close_out_digest     a feed group with notification_email (route)   -> ONE mail "[QueryStudio] Close-out <group> <date>" naming the feed, the sent   APScheduler, 300 s
                               holding that feed; due time overlaid to 00:00     marker holds (date, group); a second pass adds nothing
  S5 clockwork_alert_notifier  a Clockwork job owned by an e-mail (route) +   -> ledger row sent/attempts=1, ONE mail, ONE notification_log row; a second     APScheduler, 60 s
                               a clockwork_alerts fact (DB row)                  pass says repeated, still one mail
  S6 sla_scanner (DataFlow)    a dataflow (route) + a running run past its    -> dataflow_runs.sla_breached flips true; the scheduled tick's counts.flagged>=1  APScheduler, 60 s
                               expected_completion_at (DB row)
  S7 spark_k8s_reconciler      a running spark_k8s feed_executions row whose  -> the row is FAILED with "not found on the cluster", failed_stage query_spark_k8s  thread, 15 s
                               workload does not exist on the kind cluster
  S8 brain_coordinator_daemon  (its input is the sync's latency ring)          -> a scheduled ledger tick carrying pressure + decisions (NO durable record      APScheduler, 5 min
                                                                                 of its own: declared)
  S9 feed queue worker         a backfill run (route)                          -> claimed + completed by the worker; the downloaded file == the source rows     APScheduler, 30 s

  R  run-now ON THE OWNER (interval fixed at registration, >= 1 h)
  R1 etl_cleanup               etl_pipeline_executions: old / fresh /         -> old deleted, fresh kept, stale -> failed/error_stage=timeout, fresh-running kept
                               stale-running / fresh-running
  R2 feed_cleanup              feed_executions, same four                     -> same four outcomes
  R3 dq_cleanup                dq_results old / fresh                         -> old gone, fresh kept
  R4 agent_log_cleanup         agent_decisions old / fresh                    -> old gone, fresh kept
  R5 pv_cleanup                api_access_log old / fresh + two cache files   -> old row + old file gone, fresh row + fresh file kept
  R6 rls_audit_cleanup         row_security_audit old / fresh                 -> old gone, fresh kept
  R7 delivery_history_cleanup  delivery_history old / fresh                   -> old gone, fresh kept
  R8 query_log_cleanup         two query log files on the owner's disk        -> old file gone, fresh file kept
  R9 rate_limit_window_cleanup rate_limit_windows expired / live              -> expired gone, live kept
  R10 brain_cleanup_daemon     brain_pruning_memo + brain_route_outcome       -> old gone, fresh kept; counts memo_evicted / route_history_evicted
  R11 output_gateway_cleanup   (S3 feature, off on the rig)                   -> DECLARED: the tick says why it did nothing
  R12 dq_scheduled_loop        a custom_sql rule on the Trino connection      -> exactly one new dq_results row, passed/outcome=passed
  R13 reconciliation_scheduler an entity (source==dest, row_count)            -> one reconciliation_runs row completed, 5 == 5, no break; entity last_status ok
  R14 custom_jobs_scheduler    a webhook custom job due now                   -> the stub received EXACTLY ONE body carrying the tag; row last_status ok, run_count 1
                                                                                 (the loop is not autostarted: custom_jobs.autostart=false -> run-now, said so)
  R15 SOD generator            an active feed, a date every other active      -> created == 1, ONE feed_runs row triggered_by=sod; the second call creates 0
                               feed already has a run for                        (the cron job is not registered: feed_generation.sod_enabled=false; see OVERLAYS)
  R16 dataflow_scheduler       a promoted dataflow + a due schedule           -> a run row carrying trigger_payload.schedule_id, succeeded   (the poll loop is off:
                                                                                 dataflows.scheduler_autostart=false -> the tick route, said so)
  R17 etl_pipelines            (etl_pipelines.enabled=false on the rig)       -> DECLARED skipped with the reason
  R18 lake_formation_sync      flag ON for one tick                           -> DECLARED: enabled, 0 connections carry LF policies; no LF endpoint on the rig
  R19 kafka_cache_consumer     (Kafka is covered by another agent)            -> DECLARED: status shape only

  F  opt-in flags ON for the run, restored after
  F1 pruning_alerts_daemon     10 query_pruning_history rows (99 % -> 0 %)    -> ONE pruning_alert_events row table_degradation delivery_status=delivered; the
                                                                                 stub received ONE body with that bucket
  F2 writer_advisor_shadow_auto_apply  20 history rows with an unsupported   -> ONE writer_advisor_decisions row status=shadow for that table
                               filter on customer_id
  F3 iceberg_mirror_daemon     DECLARED: `iceberg.mirror.enabled` lives in a dotted section the DB overlay cannot address -> needs config.json / env + restart
  F4 plain_parquet_mirror      DECLARED: nested-dict overlay possible, but a built mirror records 0 files and never serves (found, not fixed here)
  F5 materialized islands / fleet syncer  DECLARED: boot-only executor threads; overlay + restart

OVERLAYS the lead must apply (+ a scheduler restart) for the declared ones are
printed by ``--plan``.

Login rig.  Everything created is removed in a ``finally``, by count.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/jobs_by_output_proof.py [--only S,R,F | --only S3,R12] [--plan]
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from auth_rls_proof import Session  # noqa: E402  (logs in through qs_docker_client)
from proof_cleanup import Ledger  # noqa: E402

TAG = str(int(time.time()))[-6:]
SCHED = "http://127.0.0.1:8001"
MAILPIT = "http://127.0.0.1:8025"
NETCOOL = "http://127.0.0.1:9099"
NETCOOL_IN_NET = "http://qs-netcool-stub:9000/events"     # the stub's name on the compose network
PG = ["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
      "-v", "ON_ERROR_STOP=1", "-qtA"]   # -q: no "INSERT 0 1" tag after a RETURNING value
SRC_SQL = "select name as region, regionkey from tpch.tiny.region"
TODAY = dt.datetime.now(dt.timezone.utc).date()
res: list = []
os.environ.setdefault("MSYS_NO_PATHCONV", "1")

OVERLAYS_FOR_DECLARED = {
    "SOD cron job (R15)": "config.feed_generation.sod_enabled = true  (+ restart the scheduler: the job registers in init_scheduler)",
    "DataFlow poll loop (R16)": "config.dataflows.scheduler_autostart = true  (+ restart: the loop starts in the registry's boot pass)",
    "ETL scheduler (R17)": "config.etl_pipelines.enabled = true  (+ restart: _reg_etl_pipelines runs at boot; the tick itself re-reads the flag)",
    "custom-jobs loop (R14)": "config.custom_jobs.autostart = true  (+ restart) -- or POST /api/admin/background-jobs/custom_jobs_scheduler/start on the OWNER",
    "iceberg mirror (F3)": "config.json: {\"iceberg.mirror\": {\"enabled\": true, \"routing_enabled\": true}} or env QUERYSTUDIO_ICEBERG.MIRROR_ENABLED=true (+ restart); "
                           "the DB overlay splits keys at the first dot and cannot address the section 'iceberg.mirror'",
    "plain-parquet mirror (F4)": "config.plain_parquet.mirror = {<the WHOLE mirror dict> with enabled: true, routing_enabled: true} (overlay replaces the dict)",
    "materialized islands / fleet syncer (F5)": "config.industrialization.enabled = true, .queue_mode = true, .materialized_islands = true, .fleet_syncer_enabled = true (+ restart: the executor thread starts only at boot)",
    "output gateway (R11)": "config.output_gateway.enabled = true (an S3 feature: the internal bucket must exist)",
}


# ── plumbing ───────────────────────────────────────────────────────────────

def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:700], flush=True)
    return bool(ok)


def declare(name, detail=""):
    """A job this rig cannot make produce something: PASS as a DECLARATION
    with the reason (the status it answered with), never a silent skip."""
    res.append(True)
    print("DECL", name, "--", str(detail)[:700], flush=True)


def psql(sql: str) -> str:
    r = subprocess.run(PG + ["-c", sql], capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"psql failed: {r.stderr.strip()[:300]} :: {sql[:200]}")
    return (r.stdout or "").strip()


def psql_n(sql: str) -> int:
    out = psql(sql)
    return int(out) if out else 0


def dexec(container: str, *argv: str) -> str:
    r = subprocess.run(["docker", "exec", container, *argv], capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"docker exec {container} failed: {r.stderr.strip()[:300]}")
    return (r.stdout or "").strip()


def http(url, method="GET", body=None, timeout=60):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, method=method, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw or b"null")
            except ValueError:
                return r.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"null")
        except ValueError:
            return e.code, raw[:300]


def wait_until(fn, timeout, every=5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v, round(time.time() - t0)
        time.sleep(every)
    return None, round(time.time() - t0)


def owner_run_now(name, timeout=900):
    """ONE tick on the scheduler pod (the lock holder) through its own control
    route -- never the api pod's copy."""
    s, rec = http(f"{SCHED}/control/background-job/{name}/run-now", "POST", timeout=timeout)
    return s, (rec if isinstance(rec, dict) else {"raw": str(rec)[:300]})


def owner_status(name):
    s, st = http(f"{SCHED}/control/background-job/{name}/status")
    return st if isinstance(st, dict) else {}


def scheduled_ticks_since(name, since_iso):
    """Durable ledger rows the OWNER wrote for a SCHEDULED fire after ``since``."""
    rows = psql(f"select record::text from background_job_ticks where name='{name}' and trigger='scheduled' "
                f"and at > '{since_iso}' order by at desc")
    return [json.loads(ln) for ln in rows.splitlines() if ln.strip()]


def mail_to(addr):
    s, m = http(f"{MAILPIT}/api/v1/search?query=to:{addr}")
    return (m or {}).get("messages") or [] if isinstance(m, dict) else []


def mail_body(mid):
    _, full = http(f"{MAILPIT}/api/v1/message/{mid}")
    return full if isinstance(full, dict) else {}


def mail_delete(ids):
    if ids:
        http(f"{MAILPIT}/api/v1/messages", "DELETE", {"IDs": list(ids)})


def stub_events():
    s, b = http(f"{NETCOOL}/events")
    return (b or {}).get("events") or [] if isinstance(b, dict) else []


class Overlay:
    """DB config overlay rows (``system_settings`` ``config.<section>.<key>``,
    the layer every pod re-reads within 5 s).  Restored by value in ``restore``:
    a row that did not exist is deleted, one that did gets its old value back."""

    def __init__(self):
        self.saved = {}

    def set(self, key, value):
        if key not in self.saved:
            prior = psql(f"select value::text from system_settings where key='{key}'")
            self.saved[key] = prior if prior else None
        psql(f"insert into system_settings(key, value, description, updated_at) values ('{key}', "
             f"$j${json.dumps(value)}$j$::json, 'jobs_by_output_proof overlay (restored by the harness)', now()) "
             f"on conflict (key) do update set value = excluded.value, updated_at = now()")

    def restore(self):
        for key, prior in self.saved.items():
            if prior is None:
                psql(f"delete from system_settings where key='{key}'")
            else:
                psql(f"update system_settings set value = $j${prior}$j$::json where key='{key}'")
        n = len(self.saved)
        self.saved = {}
        return n


class Rig:
    def __init__(self):
        self.a = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
        self.ledger = Ledger(self.call)
        self.truth = {}

    def call(self, method, path, body=None, **kw):
        s, b, _ = self.a.call(method, path, body, **kw)
        return s, b

    def feed(self, name, **extra):
        s, q = self.call("POST", "/api/queries", {"name": f"{name}_q", "query_config": {
            "files": [], "raw_sql": SRC_SQL, "connection_id": 2}})
        if s not in (200, 201):
            raise RuntimeError(f"saved query {name}: {s} {str(q)[:200]}")
        self.ledger.add("saved query", f"{name}_q", path=f"/api/queries/{q['id']}")
        body = {"name": name, "source_type": "saved_query", "source_id": q["id"], "connection_id": 2,
                "output_format": "csv", "destination_type": "local", "destination_config": {},
                "execution_backend": "native", **extra}
        s, f = self.call("POST", "/api/feeds", body)
        if s != 200:
            raise RuntimeError(f"feed {name}: {s} {str(f)[:300]}")
        self.ledger.add("feed", name, path=f"/api/feeds/{f['id']}")
        return f["id"]

    def download_rows(self, exec_db_id):
        req = urllib.request.Request(f"http://127.0.0.1:8000/api/feed-executions/{exec_db_id}/download",
                                     headers={"Authorization": f"Bearer {self.a.token}"})
        with urllib.request.urlopen(req, timeout=60) as r:
            body = r.read().decode("utf-8-sig")
        rows = {}
        for row in csv.DictReader(io.StringIO(body)):
            low = {k.lower().strip(): v for k, v in row.items()}
            rows[low["region"]] = int(float(low["regionkey"]))
        return rows


def sql_remover(sql):
    def _rm():
        try:
            return True, psql(sql)
        except Exception as exc:                              # noqa: BLE001
            return False, str(exc)[:200]
    return _rm


def file_remover(container, *paths):
    def _rm():
        try:
            dexec(container, "rm", "-f", *paths)
            return True, ""
        except Exception as exc:                              # noqa: BLE001
            return False, str(exc)[:200]
    return _rm


def mail_remover(addr):
    def _rm():
        try:
            ids = [m["ID"] for m in mail_to(addr)]
            mail_delete(ids)
            return True, f"{len(ids)} mail(s)"
        except Exception as exc:                              # noqa: BLE001
            return False, str(exc)[:200]
    return _rm


# ── S0: who owns the jobs ──────────────────────────────────────────────────

def owner_pod():
    holder = psql("select worker_id from scheduler_lock order by id desc limit 1")
    host = holder.split(":")[0] if holder else ""
    s, st = http(f"{SCHED}/control/status")
    running = isinstance(st, dict) and st.get("running")
    check(f"S0 the scheduler pod holds the lock ({holder!r}) and its control API answers on :8001",
          bool(host) and running, {"holder": holder, "control_running": running})
    return host


# ══ S: jobs that fire by themselves ═══════════════════════════════════════

def part_s(rig: Rig, owner: str, ov: Overlay, only, sweep_fid):
    print("\n== S  Fires BY ITSELF on the scheduler pod -- judged by the output")
    want = lambda k: not only or k in only                    # noqa: E731
    led = rig.ledger
    t0 = dt.datetime.now(dt.timezone.utc)
    t0_iso = t0.isoformat()
    env = (owner_status("feed_sla_watcher").get("status") or {}).get("environment") or "UAT"
    plants = {}

    # ── plant everything first, so the waits overlap ──────────────────────
    if want("S1"):
        ident = f"QS:{env}:JOBSPROOF:jp-{TAG}:{TODAY}"
        payload = {"kind": "netcool_event", "event": {
            "Identifier": ident, "Node": env, "AlertGroup": "FEED_SLA", "AlertKey": f"jp-{TAG}",
            "Severity": 3, "Summary": f"jobs_by_output_proof {TAG} planted event", "Type": 1}}
        nid = psql(f"insert into pending_notifications(payload, created_at, delivered) values "
                   f"($j${json.dumps(payload)}$j$::json, now(), false) returning id")
        led.add("pending_notification", nid, remover=sql_remover(f"delete from pending_notifications where id={nid}"))
        plants["S1"] = (nid, ident)

    watch_fid = None
    if want("S2") or want("S3") or want("S4"):
        watch_fid = rig.feed(f"JP_WATCH_{TAG}", sla_from="00:00", sla_to="00:01", sla_timezone="UTC")
        _, types = rig.call("GET", "/api/feed-dependency-types")
        titems = types if isinstance(types, list) else (types or {}).get("items") or (types or {}).get("types") or []
        by_name = {str(x.get("dependency_type") or x.get("name") or "").upper(): x.get("id") for x in titems if isinstance(x, dict)}
        dep_tid = by_name.get("API") or by_name.get("ORACLE_TABLE") or next(iter(by_name.values()), None)
        s, b = rig.call("PUT", f"/api/feeds/{watch_fid}/dependencies", {"dependencies": [
            {"dependency_type_id": dep_tid, "dependency_key": f"JP_DEP_{TAG}",
             "description": "never arrives (planted by jobs_by_output_proof)"}]})
        check("S2 a dependency that never arrives is declared on the feed (kind API, no arrival source)", s == 200, str(b)[:200])
        rid = psql(f"insert into feed_runs(feed_config_id, business_date, run_date, scheduled_time, status, priority, "
                   f"sla_from, sla_to, action_decision, action_reason, triggered_by, run_type, retry_count, suppress_delivery, created_at) "
                   f"values ({watch_fid}, '{TODAY}', '{TODAY}', '{TODAY} 00:00:00', 'pending', 0, '00:00', '00:01', 'WAIT', "
                   f"'waiting on JP_DEP_{TAG} (planted by jobs_by_output_proof)', 'sod', 'scheduled', 0, false, now()) returning id")
        led.add("feed_run (WAIT)", rid, remover=sql_remover(f"delete from feed_runs where id={rid}"))
        plants["S2"] = (watch_fid, rid)

    if want("S3"):
        late_addr = f"jp-late-{TAG}@rig.local"
        s, b = rig.call("PUT", f"/api/my-feeds/{watch_fid}/subscription", {"events": ["late"], "email": late_addr})
        check("S3 a `late` subscription with an e-mail is created through the consumer route", s in (200, 201), str(b)[:200])
        led.add("consumer subscription", late_addr, path=f"/api/my-feeds/{watch_fid}/subscription")
        led.add("consumer notices", f"feed {watch_fid}", remover=sql_remover(
            f"delete from feed_consumer_notices where feed_config_id={watch_fid}"))
        led.add("bell rows", late_addr, remover=sql_remover(
            f"delete from notification_log where event_type='feed_consumer_late' and created_at > '{t0_iso}' and recipient='rig_admin'"))
        plants["S3"] = late_addr

    if want("S4"):
        dig_addr = f"jp-digest-{TAG}@rig.local"
        gname = f"jp_grp_{TAG}"
        s, g = rig.call("POST", "/api/feed-groups", {"name": gname, "display_label": "jobs proof", "notification_email": dig_addr})
        gid = (g or {}).get("id") if isinstance(g, dict) else None
        check("S4 a feed group with a notification_email is created through the route", s in (200, 201) and gid, str(g)[:200])
        if gid:
            led.add("feed group", gname, path=f"/api/feed-groups/{gid}")
            s, b = rig.call("PUT", f"/api/feed-groups/{gid}/feeds", {"assign": [watch_fid], "unassign": []})
            check("S4 the feed is assigned to the group", s in (200, 201), str(b)[:200])
            # the route refuses to delete a group that still holds a feed, and
            # the ledger removes newest first: take the feed OUT before the group goes
            def _unassign(gid=gid, fid=watch_fid):
                st, body = rig.call("PUT", f"/api/feed-groups/{gid}/feeds", {"assign": [], "unassign": [fid]})
                return st in (200, 201), f"HTTP {st}: {str(body)[:120]}"
            led.add("group membership", f"{gid}/{watch_fid}", remover=_unassign)
            led.add("digest marker", f"{TODAY}/{gid}", remover=sql_remover(
                f"update system_settings set value = (value::jsonb #- '{{{TODAY},{gid}}}')::json where key='feed_close_out_digest.sent'"))
        ov.set("config.feed_generation.close_out_digest_time_utc", "00:00")
        plants["S4"] = (gid, gname, dig_addr)

    if want("S5"):
        cw_addr = f"jp-cw-{TAG}@rig.local"
        s, job = rig.call("POST", "/api/clockwork/jobs", {
            "name": f"jp_cw_{TAG}", "description": "jobs_by_output_proof: owner is an address", "enabled": False,
            "tenant": "querystudio", "owner": cw_addr, "cron": "0 0 1 1 *", "timezone": "UTC",
            "calendar_id": None, "weekend_days": [6, 7], "misfire_grace_seconds": 300, "idempotent": True,
            "authority": "clockwork-dev-1", "connection_id": None,
            "access": {"edit": [], "enable": [], "fire": []},
            "steps": [{"name": "only", "task_type": "journal", "params": {}, "when": None}]})
        jid = (job or {}).get("id") or ((job or {}).get("job") or {}).get("id") if isinstance(job, dict) else None
        check("S5 a Clockwork job whose owner is an e-mail address is created through the route", s in (200, 201) and jid, (s, str(job)[:200]))
        if jid:
            led.add("clockwork job", f"jp_cw_{TAG}", path=f"/api/clockwork/jobs/{jid}")
            aid = psql(f"insert into clockwork_alerts(job_id, deployment_id, kind, message, first_seen_at, last_seen_at, count) values "
                       f"({jid}, 'clockwork-dev-1', 'clockwork_task_failed', 'JOBSPROOF {TAG}: planted task failure', now(), now(), 1) returning id")
            led.add("clockwork alert", aid, remover=sql_remover(
                f"delete from clockwork_alert_notifications where alert_id={aid}; delete from clockwork_alerts where id={aid}"))
            led.add("clockwork mail log", cw_addr, remover=sql_remover(
                f"delete from notification_log where event_type='clockwork_alert' and recipient='{cw_addr}'"))
            plants["S5"] = (jid, aid, cw_addr)

    if want("S6"):
        s, flow = rig.call("POST", "/api/dataflows", {"name": f"jp_flow_{TAG}", "description": "jobs proof",
                                                      "trigger_type": "manual",
                                                      "stages": [{"stage_alias": "say", "stage_type": "log", "seq": 1,
                                                                  "config": {"message": f"jobs proof {TAG}"}}]})
        fid = (flow or {}).get("id") if isinstance(flow, dict) else None
        check("S6 a dataflow is created through the route", s in (200, 201) and fid, (s, str(flow)[:200]))
        if fid:
            led.add("dataflow (archived)", f"jp_flow_{TAG}", path=f"/api/dataflows/{fid}/archive", method="POST")
            run_id = psql(f"insert into dataflow_runs(dataflow_id, dataflow_version, dataflow_name, status, triggered_by, sla_breached, "
                          f"expected_completion_at, started_at, created_at) values ({fid}, 1, 'jp_flow_{TAG}', 'running', "
                          f"'jobs_by_output_proof', false, now() - interval '10 minutes', now() - interval '11 minutes', now()) returning id")
            led.add("dataflow run", run_id, remover=sql_remover(f"delete from dataflow_runs where id={run_id}"))
            plants["S6"] = (fid, run_id)

    if want("S7") and sweep_fid:
        bd = TODAY - dt.timedelta(days=10)
        xid = f"jp-spark-{TAG}"
        psql(f"insert into feed_executions(feed_config_id, execution_id, status, execution_backend, trigger_type, triggered_by, "
             f"started_at, business_date, external_job_id, submit_mode, retry_count) values ({sweep_fid}, '{xid}', 'running', 'spark_k8s', "
             f"'manual', 'jobs_by_output_proof', now() - interval '5 minutes', '{bd}', '{xid}-r99', 'driver_pod', 0)")
        led.add("spark execution row", xid, remover=sql_remover(f"delete from feed_executions where execution_id='{xid}'"))
        plants["S7"] = xid

    run_fid = rig.feed(f"JP_RUN_{TAG}") if want("S9") else None
    if want("S9"):
        d = (TODAY - dt.timedelta(days=1)).isoformat()
        s, bf = rig.call("POST", f"/api/feeds/{run_fid}/backfill", {"start_date": d, "end_date": d})
        check("S9 a backfill run is created (nothing executes it but the queue worker)", s == 200, (s, str(bf)[:200]))
        plants["S9"] = (run_fid, d)

    # ── judge, in the order the outputs should appear ─────────────────────
    if "S1" in plants:
        nid, ident = plants["S1"]
        done, secs = wait_until(lambda: psql(f"select delivered_at::text from pending_notifications where id={nid} and delivered"), 60, 3)
        check(f"S1 the Netcool sender marked the planted row delivered BY ITSELF ({secs}s)", bool(done), {"delivered_at": done})
        got = [e for e in stub_events() if isinstance(e, dict) and e.get("Identifier") == ident]
        check("S1 the stub received EXACTLY ONE event with that Identifier, carrying the planted Summary",
              len(got) == 1 and "planted event" in str(got[0].get("Summary")), {"n": len(got), "first": str(got[:1])[:200]})

    if "S7" in plants:
        xid = plants["S7"]
        row, secs = wait_until(lambda: psql(f"select status || '|' || coalesce(failed_stage,'') || '|' || coalesce(error_message,'') "
                                            f"from feed_executions where execution_id='{xid}' and status <> 'running'"), 120, 5)
        p = (row or "||").split("|", 2)
        check(f"S7 the Spark reconciler FAILED the orphan row by itself ({secs}s): not found on the cluster, failed_stage query_spark_k8s",
              p[0] == "failed" and "not found on the cluster" in p[2] and p[1] == "query_spark_k8s", row or "still running")

    if "S6" in plants:
        fid, run_id = plants["S6"]
        flagged, secs = wait_until(lambda: psql(f"select sla_breached from dataflow_runs where id={run_id} and sla_breached"), 120, 5)
        check(f"S6 the DataFlow SLA scanner flagged the overdue run BY ITSELF ({secs}s): sla_breached=true", flagged == "t", flagged)
        ticks = scheduled_ticks_since("sla_scanner", t0_iso)
        # the registered job IS _scan_once, which returns the flagged count as an int -> ledger counts {"n": k}
        n = [int((t.get("counts") or {}).get("flagged") or (t.get("counts") or {}).get("n") or 0) for t in ticks]
        check("S6 its scheduled ledger tick on the owner counts flagged >= 1", any(x >= 1 for x in n),
              {"scheduled_ticks": len(ticks), "flagged": n[:5], "pods": sorted({t.get("pod_id") for t in ticks})})

    if "S2" in plants:
        watch_fid, rid = plants["S2"]
        like = f"QS:{env}:%:JP_DEP_{TAG}:{TODAY}"
        ev, secs = wait_until(lambda: psql(
            f"select string_agg(distinct payload->'event'->>'Identifier', ',') from pending_notifications "
            f"where payload->>'kind'='netcool_event' and payload->'event'->>'Identifier' like '{like}'"), 150, 5)
        idents = [x for x in (ev or "").split(",") if x]
        check(f"S2 the SLA watcher raised a BREACHED Netcool event for the dependency+date BY ITSELF ({secs}s)",
              any("BREACHED" in x for x in idents), {"identifiers": idents})
        led.add("sla events", like, remover=sql_remover(
            f"delete from pending_notifications where payload->'event'->>'Identifier' like '{like}'"))
        at_stub, secs2 = wait_until(lambda: [e for e in stub_events() if isinstance(e, dict)
                                            and "BREACHED" in str(e.get("Identifier")) and f"JP_DEP_{TAG}" in str(e.get("Identifier"))], 60, 3)
        e0 = (at_stub or [{}])[0]
        check(f"S2 ...and the sender forwarded it to the stub ({secs2}s): Type 1, Severity > 0, QSBusinessDate = today",
              bool(at_stub) and e0.get("Type") == 1 and int(e0.get("Severity") or 0) > 0 and str(e0.get("QSBusinessDate")) == str(TODAY),
              {"n": len(at_stub or []), "first": str(e0)[:300]})

    if "S3" in plants:
        late_addr = plants["S3"]
        watch_fid, rid = plants["S2"]
        nxt = (owner_status("feed_consumer_late_watch").get("scheduled") or {}).get("next_run_at")
        # count(*) answers the STRING "0", which is truthy: waiting on it returned at
        # once and the "second pass" below raised the FIRST notice (2026-10-10).
        notice, secs = wait_until(lambda: (lambda c: c if c not in ("", "0") else None)(psql(
            f"select count(*) from feed_consumer_notices where feed_config_id={watch_fid} "
            f"and business_date='{TODAY}' and event='late'")), 340, 10)
        check(f"S3 the late watcher raised ONE notice for (feed, today) BY ITSELF ({secs}s; next scheduled fire was {nxt})",
              notice == "1", {"notices": notice})
        msgs, _ = wait_until(lambda: mail_to(late_addr) or None, 60, 3)
        msgs = msgs or []
        subj = (msgs[0].get("Subject") if msgs else "") or ""
        check("S3 EXACTLY ONE mail reached the subscriber, saying the feed is LATE for today",
              len(msgs) == 1 and "LATE" in subj and str(TODAY) in subj and f"JP_WATCH_{TAG}" in subj, {"n": len(msgs), "subject": subj})
        bell = psql_n(f"select count(*) from notification_log where event_type='feed_consumer_late' and recipient='rig_admin' and created_at > '{t0_iso}'")
        check("S3 ONE bell row (notification_log feed_consumer_late) for the subscriber", bell == 1, bell)
        s, rec = owner_run_now("feed_consumer_late_watch")
        already = [x for x in ((rec.get("result") or {}).get("already") or []) if x.get("feed_config_id") == watch_fid]
        check("S3 a second pass on the owner adds NOTHING: the ledger says already, still one notice, still one mail",
              s == 200 and already and len(mail_to(late_addr)) == 1
              and psql(f"select count(*) from feed_consumer_notices where feed_config_id={watch_fid} and event='late'") == "1",
              {"http": s, "outcome": rec.get("outcome"), "already": already[:1]})
        led.add("mail", late_addr, remover=mail_remover(late_addr))

    if "S4" in plants and plants["S4"][0]:
        gid, gname, dig_addr = plants["S4"]
        msgs, secs = wait_until(lambda: mail_to(dig_addr), 340, 10)
        msgs = msgs or []
        subj = (msgs[0].get("Subject") if msgs else "") or ""
        body = mail_body(msgs[0]["ID"]) if msgs else {}
        html = (body.get("HTML") or "") + (body.get("Text") or "")
        check(f"S4 the close-out digest for the group was MAILED BY ITSELF ({secs}s): subject names the group and today",
              len(msgs) >= 1 and gname in subj and str(TODAY) in subj, {"n": len(msgs), "subject": subj})
        check("S4 EXACTLY ONE digest mail (two pods tick this job; the marker must make them send once), naming the feed held at WAIT",
              len(msgs) == 1 and f"JP_WATCH_{TAG}" in html and ("waiting" in subj.lower() or "waiting" in html.lower()),
              {"n": len(msgs), "feed_named": f"JP_WATCH_{TAG}" in html, "subject": subj})
        marker = psql(f"select value::jsonb -> '{TODAY}' ->> '{gid}' from system_settings where key='feed_close_out_digest.sent'")
        check("S4 the sent marker holds (today, group)", bool(marker), {"marked_at": marker})
        s, rec = owner_run_now("feed_close_out_digest")
        skipped = [x for x in ((rec.get("result") or {}).get("skipped") or []) if x.get("group") == gname]
        check("S4 a second pass on the owner SKIPS the group as already sent; still one mail",
              s == 200 and skipped and "already sent" in str(skipped[0].get("reason")) and len(mail_to(dig_addr)) == 1,
              {"http": s, "outcome": rec.get("outcome"), "skipped": skipped[:1], "mails": len(mail_to(dig_addr))})
        led.add("mail", dig_addr, remover=mail_remover(dig_addr))

    if "S5" in plants:
        jid, aid, cw_addr = plants["S5"]
        row, secs = wait_until(lambda: psql(f"select status || '|' || attempts || '|' || coalesce(recipients::text,'') "
                                            f"from clockwork_alert_notifications where alert_id={aid} and status <> 'failed'"), 150, 5)
        p = (row or "||").split("|", 2)
        check(f"S5 the Clockwork notifier delivered the planted alert BY ITSELF ({secs}s): ledger sent, attempts=1, the owner address delivered",
              p[0] == "sent" and p[1] == "1" and cw_addr in p[2] and '"delivered"' in p[2], row or "no ledger row")
        msgs = mail_to(cw_addr)
        subj = (msgs[0].get("Subject") if msgs else "") or ""
        check("S5 EXACTLY ONE mail to the owner, naming the kind and the job",
              len(msgs) == 1 and "clockwork_task_failed" in subj and f"jp_cw_{TAG}" in subj, {"n": len(msgs), "subject": subj})
        nlog = psql_n(f"select count(*) from notification_log where event_type='clockwork_alert' and recipient='{cw_addr}'")
        check("S5 ONE notification_log row (channel email) for that recipient", nlog == 1, nlog)
        s, rec = owner_run_now("clockwork_alert_notifier")
        cnt = (rec.get("result") or {})
        check("S5 a second pass on the owner counts it REPEATED and sends nothing more (attempts stays 1, one mail)",
              s == 200 and int(cnt.get("repeated") or 0) >= 1 and len(mail_to(cw_addr)) == 1
              and psql(f"select attempts from clockwork_alert_notifications where alert_id={aid}") == "1",
              {"http": s, "counters": {k: cnt.get(k) for k in ("seen", "notified", "repeated", "unrouted", "failed", "errors")}})
        led.add("mail", cw_addr, remover=mail_remover(cw_addr))

    if "S9" in plants:
        run_fid, d = plants["S9"]
        def _done():
            st = psql(f"select status from feed_runs where feed_config_id={run_fid} and business_date='{d}' order by id desc limit 1")
            return st if st in ("completed", "failed") else None
        st, secs = wait_until(_done, 300, 5)
        check(f"S9 the queue worker claimed and finished the backfill BY ITSELF ({secs}s)", st == "completed",
              {"status": st, "claimed_by": psql(f"select claimed_by from feed_runs where feed_config_id={run_fid} order by id desc limit 1")})
        ex = psql(f"select id from feed_executions where feed_config_id={run_fid} and status='completed' order by id desc limit 1")
        rows = rig.download_rows(int(ex)) if ex else {}
        check("S9 the downloaded feed file == the source (5 regions from Trino)", rows == rig.truth and len(rows) == 5, {"rows": rows})
        led.add("feed runs/executions", f"feed {run_fid}", remover=sql_remover(
            f"delete from feed_executions where feed_config_id={run_fid}; delete from feed_runs where feed_config_id={run_fid}"))

    if want("S8"):
        nxt = (owner_status("brain_coordinator_daemon").get("scheduled") or {}).get("next_run_at")
        ticks, secs = wait_until(lambda: scheduled_ticks_since("brain_coordinator_daemon", t0_iso), 340, 10)
        t = (ticks or [{}])[0]
        r = t.get("result") or {}
        check(f"S8 the brain coordinator ticked BY ITSELF ({secs}s; next fire was {nxt}) and its record carries pressure + decisions",
              bool(ticks) and t.get("outcome") == "ok" and r.get("pressure") in ("low", "high")
              and isinstance(r.get("decisions"), list) and t.get("pod_id") == owner,
              {"outcome": t.get("outcome"), "pressure": r.get("pressure"), "decisions": len(r.get("decisions") or []), "pod": t.get("pod_id")})
        declare("S8 the coordinator keeps NO durable record of its own (pressure + reports are process memory); the durable "
                "background_job_ticks row is the only evidence -- judged above")


# ══ R: run-now on the owner ═══════════════════════════════════════════════

def _old_fresh(label, name, table, where_old, where_fresh, counts_key, *, expect_min=1, pre=None):
    """The retention shape: both planted rows exist, the tick runs on the owner,
    the old one is gone, the fresh one survives, the tick's count names it."""
    before_old, before_fresh = psql_n(f"select count(*) from {table} where {where_old}"), psql_n(f"select count(*) from {table} where {where_fresh}")
    if not check(f"{label} planted: old={before_old} fresh={before_fresh} rows in {table}", before_old >= 1 and before_fresh >= 1):
        return None
    if pre:
        pre()
    s, rec = owner_run_now(name)
    after_old, after_fresh = psql_n(f"select count(*) from {table} where {where_old}"), psql_n(f"select count(*) from {table} where {where_fresh}")
    counts = rec.get("counts") or {}
    n = counts.get(counts_key)
    check(f"{label} run-now on the OWNER (pod {rec.get('pod_id')}): the old row is GONE and the fresh row SURVIVES; "
          f"counts[{counts_key!r}]={n} outcome={rec.get('outcome')}",
          s == 200 and after_old == 0 and after_fresh == before_fresh and rec.get("outcome") == "ok" and (n or 0) >= expect_min,
          {"http": s, "old_after": after_old, "fresh_after": after_fresh, "counts": counts, "reason": rec.get("reason"), "error": rec.get("error")})
    return rec


def part_r(rig: Rig, owner: str, ov: Overlay, only, sweep_fid):
    print("\n== R  Run-now ON THE OWNER (interval fixed at registration) -- judged by the output")
    want = lambda k: not only or k in only                    # noqa: E731
    led = rig.ledger
    t0_iso = dt.datetime.now(dt.timezone.utc).isoformat()

    if want("R1"):
        pfx = f"jp-etl-{TAG}"
        for sfx, age, st in (("old", "100 days", "completed"), ("fresh", "1 day", "completed"),
                             ("stale", "3 hours", "running"), ("live", "5 minutes", "running")):
            psql(f"insert into etl_pipeline_executions(pipeline_id, execution_id, trigger_type, status, started_at) "
                 f"values (999999, '{pfx}-{sfx}', 'manual', '{st}', now() - interval '{age}')")
        led.add("etl executions", pfx, remover=sql_remover(f"delete from etl_pipeline_executions where execution_id like '{pfx}-%'"))
        rec = _old_fresh("R1 etl_cleanup", "etl_cleanup", "etl_pipeline_executions",
                         f"execution_id='{pfx}-old'", f"execution_id in ('{pfx}-fresh','{pfx}-live')", "etl executions")
        if rec:
            st = psql(f"select status || '|' || coalesce(error_stage,'') from etl_pipeline_executions where execution_id='{pfx}-stale'")
            live = psql(f"select status from etl_pipeline_executions where execution_id='{pfx}-live'")
            check("R1 the stale running row was RESET to failed/timeout and the live running row was left alone",
                  st == "failed|timeout" and live == "running" and (rec.get("counts") or {}).get("etl stale-reset", 0) >= 1,
                  {"stale": st, "live": live, "counts": rec.get("counts")})

    if want("R2") and sweep_fid:
        pfx = f"jp-fx-{TAG}"
        for sfx, age, st, dd in (("old", "100 days", "completed", 100), ("fresh", "1 day", "completed", 1),
                                 ("stale", "3 hours", "running", 20), ("live", "5 minutes", "running", 21)):
            psql(f"insert into feed_executions(feed_config_id, execution_id, status, execution_backend, trigger_type, triggered_by, "
                 f"started_at, business_date, retry_count) values ({sweep_fid}, '{pfx}-{sfx}', '{st}', 'native', 'manual', "
                 f"'jobs_by_output_proof', now() - interval '{age}', '{TODAY - dt.timedelta(days=dd)}', 0)")
        led.add("feed executions", pfx, remover=sql_remover(f"delete from feed_executions where execution_id like '{pfx}-%'"))
        rec = _old_fresh("R2 feed_cleanup", "feed_cleanup", "feed_executions",
                         f"execution_id='{pfx}-old'", f"execution_id in ('{pfx}-fresh','{pfx}-live')", "feed executions")
        if rec:
            st = psql(f"select status || '|' || coalesce(error_message,'') from feed_executions where execution_id='{pfx}-stale'")
            live = psql(f"select status from feed_executions where execution_id='{pfx}-live'")
            check("R2 the stale running row (no heartbeat, 3 h old) was RESET to failed and the live one left alone",
                  st.startswith("failed|") and "timed out" in st and live == "running" and (rec.get("counts") or {}).get("feed stale-reset", 0) >= 1,
                  {"stale": st, "live": live, "counts": rec.get("counts")})

    rule_id = None
    if want("R3") or want("R12"):
        s, rule = rig.call("POST", "/api/data-quality/rules", {
            "name": f"jp_dq_{TAG}", "description": "jobs proof", "rule_type": "custom_sql", "target_type": "connection",
            "target_id": 2, "config": {"connection_id": 2, "sql": "select 1"}, "enabled": True, "severity": "info"})
        rule_id = (rule or {}).get("id") if isinstance(rule, dict) else None
        check("R  a data-quality rule (custom_sql on the Trino connection) is created through the route", s in (200, 201) and rule_id, (s, str(rule)[:200]))
        if rule_id:
            led.add("dq rule", f"jp_dq_{TAG}", path=f"/api/data-quality/rules/{rule_id}")
            led.add("dq results", f"rule {rule_id}", remover=sql_remover(f"delete from dq_results where rule_id={rule_id}"))

    if want("R3") and rule_id:
        for sfx, age in (("old", "100 days"), ("fresh", "1 day")):
            psql(f"insert into dq_results(rule_id, passed, severity, details, checked_at, outcome) values "
                 f"({rule_id}, true, 'info', $j${json.dumps({'jp': sfx})}$j$::json, now() - interval '{age}', 'passed')")
        _old_fresh("R3 dq_cleanup", "dq_cleanup", "dq_results",
                   f"rule_id={rule_id} and details::text like '%\"old\"%'", f"rule_id={rule_id} and details::text like '%\"fresh\"%'", "dq results")

    if want("R4"):
        for sfx, age in (("old", "40 days"), ("fresh", "1 day")):
            psql(f"insert into agent_decisions(agent_name, event_type, execution_id, action, reason, created_at) values "
                 f"('jobs_proof', 'planted', 'jp-{TAG}-{sfx}', 'noop', 'planted by jobs_by_output_proof', now() - interval '{age}')")
        led.add("agent decisions", f"jp-{TAG}", remover=sql_remover(f"delete from agent_decisions where execution_id like 'jp-{TAG}-%'"))
        _old_fresh("R4 agent_log_cleanup", "agent_log_cleanup", "agent_decisions",
                   f"execution_id='jp-{TAG}-old'", f"execution_id='jp-{TAG}-fresh'", "agent decision log")

    if want("R5"):
        for sfx, age in (("old", "100 days"), ("fresh", "1 day")):
            psql(f"insert into api_access_log(view_id, execution_id, status_code, created_at) values (999999, 'jp-{TAG}-{sfx}', 200, now() - interval '{age}')")
        led.add("api access log", f"jp-{TAG}", remover=sql_remover(f"delete from api_access_log where execution_id like 'jp-{TAG}-%'"))
        cdir = "/app/data/published_cache"
        old_f, fresh_f = f"{cdir}/v999999_jp{TAG}_old.parquet", f"{cdir}/v999999_jp{TAG}_fresh.parquet"
        dexec("qs-local-scheduler", "sh", "-c", f"mkdir -p {cdir} && touch -d '3 hours ago' {old_f} && touch {fresh_f}")
        led.add("pv cache files", f"jp{TAG}", remover=file_remover("qs-local-scheduler", old_f, fresh_f))
        rec = _old_fresh("R5 pv_cleanup", "pv_cleanup", "api_access_log",
                         f"execution_id='jp-{TAG}-old'", f"execution_id='jp-{TAG}-fresh'", "pv access logs")
        if rec:
            left = dexec("qs-local-scheduler", "sh", "-c", f"ls {cdir} | grep jp{TAG} || true")
            check("R5 the 3-hour-old cache file is gone from the owner's disk and the fresh one is still there",
                  "_old.parquet" not in left and "_fresh.parquet" in left and (rec.get("counts") or {}).get("pv cache files", 0) >= 1,
                  {"left": left, "counts": rec.get("counts")})

    if want("R6"):
        for sfx, age in (("old", "40 days"), ("fresh", "1 day")):
            psql(f"insert into row_security_audit(ts, username, role, table_ref, row_policies, column_policies, mode, request_id) values "
                 f"(now() - interval '{age}', 'jobs_proof', 'analyst', 'jp.table', '[]'::json, '[]'::json, 'enforce', 'jp-{TAG}-{sfx}')")
        led.add("rls audit", f"jp-{TAG}", remover=sql_remover(f"delete from row_security_audit where request_id like 'jp-{TAG}-%'"))
        _old_fresh("R6 rls_audit_cleanup", "rls_audit_cleanup", "row_security_audit",
                   f"request_id='jp-{TAG}-old'", f"request_id='jp-{TAG}-fresh'", "row security audit")

    if want("R7"):
        for sfx, age in (("old", "100 days"), ("fresh", "1 day")):
            psql(f"insert into delivery_history(execution_id, delivery_type, destination, status, attempted_at) values "
                 f"('jp-{TAG}-{sfx}', 'email', 'jp@rig.local', 'delivered', now() - interval '{age}')")
        led.add("delivery history", f"jp-{TAG}", remover=sql_remover(f"delete from delivery_history where execution_id like 'jp-{TAG}-%'"))
        _old_fresh("R7 delivery_history_cleanup", "delivery_history_cleanup", "delivery_history",
                   f"execution_id='jp-{TAG}-old'", f"execution_id='jp-{TAG}-fresh'", "delivery history")

    if want("R8"):
        qdir = "/app/data/logs/queries"
        old_f, fresh_f = f"{qdir}/jp_{TAG}_old.log", f"{qdir}/jp_{TAG}_fresh.log"
        dexec("qs-local-scheduler", "sh", "-c", f"mkdir -p {qdir} && touch -d '10 days ago' {old_f} && touch {fresh_f}")
        led.add("query log files", f"jp_{TAG}", remover=file_remover("qs-local-scheduler", old_f, fresh_f))
        before = dexec("qs-local-scheduler", "sh", "-c", f"ls {qdir} | grep jp_{TAG} || true")
        if check("R8 planted: two query log files on the owner's disk (one 10 days old)", "_old.log" in before and "_fresh.log" in before, before):
            s, rec = owner_run_now("query_log_cleanup")
            left = dexec("qs-local-scheduler", "sh", "-c", f"ls {qdir} | grep jp_{TAG} || true")
            check(f"R8 run-now on the OWNER (pod {rec.get('pod_id')}): the old file is GONE and the fresh file SURVIVES; counts={rec.get('counts')}",
                  s == 200 and "_old.log" not in left and "_fresh.log" in left and (rec.get("counts") or {}).get("query logs", 0) >= 1
                  and rec.get("outcome") == "ok", {"left": left, "outcome": rec.get("outcome"), "reason": rec.get("reason")})

    if want("R9"):
        psql(f"insert into rate_limit_windows(action, identity, window_seconds, window_start, n, expires_at) values "
             f"('jp-{TAG}', 'old', 60, extract(epoch from now())::bigint - 7400, 1, extract(epoch from now())::bigint - 7300), "
             f"('jp-{TAG}', 'live', 60, extract(epoch from now())::bigint, 1, extract(epoch from now())::bigint + 600)")
        led.add("rate limit windows", f"jp-{TAG}", remover=sql_remover(f"delete from rate_limit_windows where action='jp-{TAG}'"))
        _old_fresh("R9 rate_limit_window_cleanup", "rate_limit_window_cleanup", "rate_limit_windows",
                   f"action='jp-{TAG}' and identity='old'", f"action='jp-{TAG}' and identity='live'", "rate limit windows")

    if want("R10"):
        for sfx, age in (("old", "100 hours"), ("fresh", "1 hour")):
            psql(f"insert into brain_pruning_memo(sql_hash, snapshot_id, bucket, table_prefix, surviving_files, surviving_count, created_at, hit_count, last_hit_at) "
                 f"values ('jp{TAG}{sfx}', 'snap', 'jp-bucket', 'jp/t', '', 0, now() - interval '{age}', 0, now() - interval '{age}')")
            psql(f"insert into brain_route_outcome(sql_hash, bucket, table_prefix, engine, ema_seconds, sample_count, first_seen_at, last_seen_at) "
                 f"values ('jp{TAG}{sfx}', 'jp-bucket', 'jp/t', 'duckdb', 1.0, 1, now() - interval '{age}', now() - interval '{'40 days' if sfx == 'old' else '1 hour'}')")
        led.add("brain rows", f"jp{TAG}", remover=sql_remover(
            f"delete from brain_pruning_memo where sql_hash like 'jp{TAG}%'; delete from brain_route_outcome where sql_hash like 'jp{TAG}%'"))
        rec = _old_fresh("R10 brain_cleanup_daemon (memo)", "brain_cleanup_daemon", "brain_pruning_memo",
                         f"sql_hash='jp{TAG}old'", f"sql_hash='jp{TAG}fresh'", "memo_evicted")
        if rec:
            o, f = psql_n(f"select count(*) from brain_route_outcome where sql_hash='jp{TAG}old'"), psql_n(f"select count(*) from brain_route_outcome where sql_hash='jp{TAG}fresh'")
            check("R10 ...the same tick evicted the 40-day-old route outcome and kept the fresh one",
                  o == 0 and f == 1 and (rec.get("counts") or {}).get("route_history_evicted", 0) >= 1, {"old": o, "fresh": f, "counts": rec.get("counts")})

    if want("R11"):
        s, rec = owner_run_now("output_gateway_cleanup")
        r = rec.get("result") or {}
        declare(f"R11 output_gateway_cleanup (S3 feature): the owner's tick says outcome={rec.get('outcome')} reason={rec.get('reason')!r} "
                f"skipped_reason={r.get('skipped_reason')!r} -- turn it on with {OVERLAYS_FOR_DECLARED['output gateway (R11)']}")
        honest = (rec.get("outcome") == "skipped" and bool(rec.get("reason"))) if r.get("skipped_reason") else rec.get("outcome") in ("ok", "no_input")
        check("R11 a disabled gateway tick is RECORDED as skipped WITH its reason (never as no_input over nothing)", s == 200 and honest,
              {"outcome": rec.get("outcome"), "reason": rec.get("reason"), "skipped_reason": r.get("skipped_reason")})

    if want("R12") and rule_id:
        before = psql_n(f"select count(*) from dq_results where rule_id={rule_id}")
        s, rec = owner_run_now("dq_scheduled_loop")
        rows = psql(f"select passed::text || '|' || coalesce(outcome,'') || '|' || coalesce(severity,'') from dq_results where rule_id={rule_id} "
                    f"and checked_at > '{t0_iso}' order by id")
        new = [ln for ln in rows.splitlines() if ln]
        check(f"R12 dq_scheduled_run on the OWNER (pod {rec.get('pod_id')}) executed the rule: EXACTLY ONE new dq_results row, passed, outcome=passed",
              s == 200 and len(new) == 1 and new[0].startswith("true|passed") and (rec.get("counts") or {}).get("rules", 0) >= 1,
              {"http": s, "outcome": rec.get("outcome"), "counts": rec.get("counts"), "new_rows": new, "before": before, "reason": rec.get("reason")})

    if want("R13"):
        s, ent = rig.call("POST", "/api/reconciliation/entities", {
            "name": f"jp_recon_{TAG}", "source_connection_id": 2, "dest_connection_id": 2,
            "query": "select count(*) as row_count from tpch.tiny.region", "comparison_mode": "row_count",
            "schedule_enabled": True, "check_interval_hours": 1, "is_active": True})
        eid = (ent or {}).get("id") if isinstance(ent, dict) else None
        if check("R13 a reconciliation entity (source == dest, row_count) is created through the route", s in (200, 201) and eid, (s, str(ent)[:200])):
            led.add("reconciliation runs", f"entity {eid}", remover=sql_remover(f"delete from reconciliation_runs where entity_id={eid}"))
            led.add("reconciliation entity", f"jp_recon_{TAG}", path=f"/api/reconciliation/entities/{eid}")
            s, rec = owner_run_now("reconciliation_scheduler", timeout=600)
            runs = psql(f"select status || '|' || coalesce(source_row_count::text,'') || '|' || coalesce(dest_row_count::text,'') || '|' || "
                        f"coalesce(break_detected::text,'') || '|' || coalesce(triggered_by,'') from reconciliation_runs where entity_id={eid}").splitlines()
            last = psql(f"select coalesce(last_status,'') from reconciliation_entities where id={eid}")
            check(f"R13 the owner's tick (pod {rec.get('pod_id')}) checked the due entity: ONE run row completed, 5 == 5, no break; entity last_status=ok",
                  s == 200 and len(runs) == 1 and runs[0].startswith("completed|5|5|false") and last == "ok" and (rec.get("counts") or {}).get("checked", 0) >= 1,
                  {"http": s, "outcome": rec.get("outcome"), "counts": rec.get("counts"), "runs": runs, "last_status": last, "reason": rec.get("reason")})

    if want("R14"):
        marker = {"jp": TAG, "kind": "custom_job_webhook"}
        s, job = rig.call("POST", "/api/admin/custom-jobs", {
            "name": f"jp_job_{TAG}", "job_type": "webhook", "cron_expression": "* * * * *", "enabled": True,
            "parameters": {"url": NETCOOL_IN_NET, "method": "POST", "body": marker, "timeout_seconds": 10, "retries": 1}})
        jid = (job or {}).get("id") if isinstance(job, dict) else None
        if check("R14 a webhook custom job (POST to the stub) is created through the admin route", s in (200, 201) and jid, (s, str(job)[:200])):
            led.add("custom job", f"jp_job_{TAG}", path=f"/api/admin/custom-jobs/{jid}")
            psql(f"update custom_background_jobs set next_run_at = now() - interval '1 minute' where id={jid}")
            loop = owner_status("custom_jobs_scheduler")
            declare(f"R14 the custom-jobs LOOP is not running on the owner (custom_jobs.autostart=false; last_summary="
                    f"{(loop.get('status') or {}).get('last_summary')}) -> run-now on the owner; to let it fire by itself: "
                    f"{OVERLAYS_FOR_DECLARED['custom-jobs loop (R14)']}")
            s, rec = owner_run_now("custom_jobs_scheduler")
            got = [e for e in stub_events() if isinstance(e, dict) and e.get("jp") == TAG]
            row = psql(f"select coalesce(last_status,'') || '|' || run_count || '|' || error_count from custom_background_jobs where id={jid}")
            check(f"R14 the owner's tick (pod {rec.get('pod_id')}) ran the due job: the stub received EXACTLY ONE body carrying the tag; row last_status=ok, run_count=1",
                  s == 200 and len(got) == 1 and row == "ok|1|0" and (rec.get("counts") or {}).get("ran", 0) >= 1,
                  {"http": s, "outcome": rec.get("outcome"), "counts": rec.get("counts"), "stub_hits": len(got), "row": row, "reason": rec.get("reason")})

    if want("R15"):
        sod_fid = rig.feed(f"JP_SOD_{TAG}")
        safe = None
        for back in range(1, 40):
            d = TODAY - dt.timedelta(days=back)
            missing = psql_n(f"select count(*) from feed_configs f where f.is_active and f.id <> {sod_fid} "
                             f"and (f.valid_from is null or f.valid_from <= '{d}') and (f.valid_until is null or f.valid_until >= '{d}') "
                             f"and not exists (select 1 from feed_runs r where r.feed_config_id=f.id and r.business_date='{d}')")
            if missing == 0:
                safe = d
                break
        declare(f"R15 the SOD cron job is NOT registered on the owner (feed_generation.sod_enabled=false) -> the product's run-now route; "
                f"to let it fire by itself: {OVERLAYS_FOR_DECLARED['SOD cron job (R15)']}")
        if safe is None:
            # SOD creates a run for EVERY active feed lacking one (no feed filter on
            # the route or the generator): with no isolating date, proving it would
            # create -- and the queue worker would EXECUTE and deliver -- runs of
            # feeds this proof does not own.  Say which, never fail or skip silently.
            blockers = psql(f"select string_agg(f.id || ':' || f.name, ', ') from feed_configs f where f.is_active and f.id <> {sod_fid} "
                            f"and not exists (select 1 from feed_runs r where r.feed_config_id=f.id and r.business_date='{TODAY - dt.timedelta(days=1)}')")
            declare(f"R15 NOT run live: no business date in the last 39 days on which every other active feed already has a run, so SOD "
                    f"would create (and the worker execute) runs of feeds this proof does not own -- e.g. for yesterday: {blockers}. "
                    f"Covered in CI by the SOD generator tests; run R15 on a rig whose active feeds are the proof's own.")
        elif check("R15 a business date exists for which every OTHER active feed already has a run (so SOD creates only the planted feed's)",
                 safe is not None, {"searched_days": 39, "date": str(safe)}):
            led.add("sod runs", f"feed {sod_fid}", remover=sql_remover(
                f"delete from feed_executions where feed_config_id={sod_fid}; delete from feed_runs where feed_config_id={sod_fid}"))
            s, r1 = rig.call("POST", f"/api/admin/feeds/sod/run-now?business_date={safe}")
            rows = psql(f"select triggered_by || '|' || status || '|' || coalesce(action_decision,'') from feed_runs where feed_config_id={sod_fid} and business_date='{safe}'").splitlines()
            check(f"R15 SOD for {safe}: created == 1, errors == 0; ONE feed_runs row for the planted feed, triggered_by=sod",
                  s == 200 and (r1 or {}).get("created") == 1 and (r1 or {}).get("errors") == 0 and len(rows) == 1 and rows[0].startswith("sod|"),
                  {"http": s, "result": {k: (r1 or {}).get(k) for k in ("created", "already_existed", "skipped_window", "skipped_by_condition", "errors", "error_details")}, "rows": rows})
            s, r2 = rig.call("POST", f"/api/admin/feeds/sod/run-now?business_date={safe}")
            rows2 = psql(f"select count(*) from feed_runs where feed_config_id={sod_fid} and business_date='{safe}'")
            check("R15 a second SOD call for the same date is IDEMPOTENT: created == 0, the row count is still 1",
                  s == 200 and (r2 or {}).get("created") == 0 and (r2 or {}).get("already_existed", 0) >= 1 and rows2 == "1",
                  {"http": s, "created": (r2 or {}).get("created"), "already": (r2 or {}).get("already_existed"), "rows": rows2})

    if want("R16"):
        st = owner_status("dataflow_scheduler_autostart").get("status") or {}
        # 2026-10-18: the rig runs the DataFlow poll loop (rig/config.overlay.json) and R16 proves
        # THE production road -- the lock holder (the scheduler pod) fires a due schedule BY ITSELF.
        # The api pod's tick route correctly refuses there (it does not hold the role since the one
        # election), so it is no substitute any more.
        check("R16 the DataFlow poll loop runs on the owner (dataflows.scheduler_autostart)",
              bool(st.get("scheduler_autostart")), st)
        s, flow = rig.call("POST", "/api/dataflows", {"name": f"jp_sched_{TAG}", "trigger_type": "manual",
                                                      "stages": [{"stage_alias": "say", "stage_type": "log", "seq": 1, "config": {"message": f"jp {TAG}"}}]})
        fid = (flow or {}).get("id") if isinstance(flow, dict) else None
        if check("R16 a cron dataflow with one native `log` stage is created", s in (200, 201) and fid, (s, str(flow)[:200])):
            led.add("dataflow (archived)", f"jp_sched_{TAG}", path=f"/api/dataflows/{fid}/archive", method="POST")
            s, pr = rig.call("POST", f"/api/dataflows/{fid}/promote")
            check("R16 ...and promoted (a draft is skipped by the scheduler)", s in (200, 201), (s, str(pr)[:160]))
            s, sc = rig.call("POST", "/api/dataflows/schedules", {"dataflow_id": fid, "name": f"jp_sched_{TAG}", "cron_expression": "* * * * *", "timezone": "UTC"})
            sid = (sc or {}).get("id") if isinstance(sc, dict) else None
            if check("R16 a schedule is created through the route", s in (200, 201) and sid, (s, str(sc)[:200])):
                led.add("dataflow schedule", f"jp_sched_{TAG}", path=f"/api/dataflows/schedules/{sid}")
                psql(f"update dataflow_schedules set next_run_at = now() - interval '1 minute' where id={sid}")
                s, tk = rig.call("POST", "/api/dataflows/scheduler/tick")
                check("R16 the api pod's tick route refuses (409): it does not hold the scheduler role",
                      s == 409 and "singleton role" in str(tk), (s, str(tk)[:160]))
                led.add("dataflow runs", f"flow {fid}", remover=sql_remover(f"delete from dataflow_run_stages where run_id in (select id from dataflow_runs where dataflow_id={fid}); delete from dataflow_runs where dataflow_id={fid}"))
                def _run():
                    r = psql(f"select id || '|' || status from dataflow_runs where dataflow_id={fid} and trigger_payload->>'schedule_id'='{sid}' "
                             f"and status in ('succeeded','failed','partial') order by id desc limit 1")
                    return r or None
                r, secs = wait_until(_run, 150, 3)
                check(f"R16 the scheduler pod's poll loop fired the due schedule BY ITSELF: a run row carrying "
                      f"trigger_payload.schedule_id={sid} reached succeeded ({secs}s)",
                      bool(r) and r.endswith("|succeeded"), {"run": r})

    if want("R17"):
        s, rec = owner_run_now("etl_pipelines")
        declare(f"R17 etl_pipelines on the owner: outcome={rec.get('outcome')} reason={rec.get('reason')!r} (etl_pipelines.enabled is false on the rig; "
                f"to prove a scheduled pipeline: {OVERLAYS_FOR_DECLARED['ETL scheduler (R17)']} -- the scheduler tick itself is proven by "
                f"backend/tests/test_etl_scheduler_tick_fires_2026_10_08.py)")
        check("R17 a disabled ETL scheduler tick is recorded as skipped WITH its reason", s == 200 and rec.get("outcome") == "skipped" and rec.get("reason"),
              {"outcome": rec.get("outcome"), "reason": rec.get("reason")})

    if want("R18"):
        s, rec = owner_run_now("lake_formation_sync")
        r = rec.get("result") or {}
        check("R18 lake_formation_sync OFF: the tick is recorded as skipped with the flag named",
              s == 200 and rec.get("outcome") == "skipped" and "lake_formation_sync_enabled" in str(rec.get("reason")), {"outcome": rec.get("outcome"), "reason": rec.get("reason")})
        ov.set("config.row_security.lake_formation_sync_enabled", True)
        time.sleep(6)
        s, rec = owner_run_now("lake_formation_sync")
        r = rec.get("result") or {}
        check("R18 lake_formation_sync ON for one tick: enabled, 0 connections carry Lake Formation policies -> recorded skipped WITH that reason",
              s == 200 and r.get("enabled") is True and r.get("connections") == 0 and rec.get("outcome") == "skipped" and "no connection" in str(rec.get("reason")),
              {"outcome": rec.get("outcome"), "reason": rec.get("reason"), "result": r})
        declare("R18 not provable further on this rig: there is no Lake Formation endpoint (a policy row with source='lake_formation' needs a real AWS LF client)")

    if want("R19"):
        st = owner_status("kafka_cache_consumer")
        declare(f"R19 kafka_cache_consumer (Kafka is covered by another agent): owner status {json.dumps(st.get('status'))[:200]}; run-now declared unavailable: "
                f"{(st.get('run_now') or {}).get('reason')!r}")


# ══ F: opt-in flags ON for the run ════════════════════════════════════════

def part_f(rig: Rig, owner: str, ov: Overlay, only):
    print("\n== F  Opt-in flags ON for the run (restored after)")
    want = lambda k: not only or k in only                    # noqa: E731
    led = rig.ledger

    if want("F1"):
        bucket, prefix = f"jp-bucket-{TAG}", f"jp/tbl_{TAG}"
        s, prior = rig.call("GET", "/api/admin/rest-api/config")
        prior_private = (prior or {}).get("allow_private_ips") if isinstance(prior, dict) else None
        rig.call("PUT", "/api/admin/rest-api/config", {"allow_private_ips": True})
        led.add("rest-api allow_private_ips", str(prior_private), remover=lambda: (rig.call("PUT", "/api/admin/rest-api/config",
                                                                                            {"allow_private_ips": bool(prior_private)})[0] in (200, 201), ""))
        ov.set("config.pruning_health.alerts", {
            "enabled": True, "webhook_url": NETCOOL_IN_NET, "slack_webhook_url": "", "dedup_window_hours": 24,
            "max_alerts_per_tick": 10, "cron_interval_minutes": 30, "event_retention_days": 30, "webhook_timeout_seconds": 5.0})
        for i in range(5):
            psql(f"insert into query_pruning_history(execution_id, created_at, bucket, table_prefix, snapshot_id, files_before_prune, files_after_prune, format) "
                 f"values ('jp-ph-{TAG}-prev{i}', now() - interval '30 hours', '{bucket}', '{prefix}', 's1', 1000, 10, 'iceberg')")
            psql(f"insert into query_pruning_history(execution_id, created_at, bucket, table_prefix, snapshot_id, files_before_prune, files_after_prune, format) "
                 f"values ('jp-ph-{TAG}-now{i}', now() - interval '1 hour', '{bucket}', '{prefix}', 's1', 1000, 1000, 'iceberg')")
        led.add("pruning history", f"jp-ph-{TAG}", remover=sql_remover(f"delete from query_pruning_history where execution_id like 'jp-ph-{TAG}-%'"))
        led.add("pruning alert events", bucket, remover=sql_remover(f"delete from pruning_alert_events where bucket='{bucket}'"))
        planted = psql_n(f"select count(*) from query_pruning_history where bucket='{bucket}'")
        check("F1 planted: 10 history rows for one table (5 at 99 % pruned 30 h ago, 5 at 0 % an hour ago)", planted == 10, planted)
        print("   waiting 65 s: the owner's per-pod snapshot cache is 60 s", flush=True)
        time.sleep(65)
        s, rec = owner_run_now("pruning_alerts_daemon")
        ev = psql(f"select kind || '|' || delivery_status || '|' || delivered::text || '|' || coalesce(delta_pct_points::text,'') from pruning_alert_events where bucket='{bucket}'").splitlines()
        hits = [e for e in stub_events() if isinstance(e, dict) and str(e.get("bucket")) == bucket]
        check(f"F1 flag ON, run-now on the OWNER (pod {rec.get('pod_id')}): ONE pruning_alert_events row table_degradation, delivery_status=delivered, delta >= 20 pts",
              s == 200 and len(ev) == 1 and ev[0].startswith("table_degradation|delivered|true|") and float(ev[0].rsplit("|", 1)[-1] or 0) >= 20,
              {"http": s, "outcome": rec.get("outcome"), "reason": rec.get("reason"), "events": ev, "result": str((rec.get("result") or {}).get("result"))[:300]})
        check("F1 the webhook stub received EXACTLY ONE alert body for that bucket", len(hits) == 1 and hits[0].get("kind") == "table_degradation",
              {"n": len(hits), "first": str(hits[:1])[:200]})

    if want("F2"):
        bucket, prefix = f"jp-wa-{TAG}", f"jp/wa_{TAG}"
        ov.set("config.writer_advisor.auto_apply_enabled", True)
        fb = json.dumps([{"column": "customer_id", "operator": "eq", "value": "C1", "support": "unsupported"}])
        for i in range(20):
            psql(f"insert into query_pruning_history(execution_id, created_at, bucket, table_prefix, snapshot_id, files_before_prune, files_after_prune, filter_breakdown, format) "
                 f"values ('jp-wa-{TAG}-{i}', now() - interval '1 hour', '{bucket}', '{prefix}', 's1', 1000, 1000, $j${fb}$j$::json, 'iceberg')")
        led.add("advisor history", f"jp-wa-{TAG}", remover=sql_remover(f"delete from query_pruning_history where execution_id like 'jp-wa-{TAG}-%'"))
        led.add("advisor decisions", bucket, remover=sql_remover(f"delete from writer_advisor_decisions where bucket='{bucket}'"))
        time.sleep(6)
        s, rec = owner_run_now("writer_advisor_shadow_auto_apply")
        rows = psql(f"select column_name || '|' || kind || '|' || status || '|' || coalesce(decided_by,'') from writer_advisor_decisions where bucket='{bucket}'").splitlines()
        check(f"F2 flag ON, run-now on the OWNER (pod {rec.get('pod_id')}): ONE shadow decision for customer_id on that table, decided_by brain.shadow_auto_apply",
              s == 200 and len(rows) == 1 and rows[0].startswith("customer_id|") and "|shadow|brain.shadow_auto_apply" in rows[0]
              and (rec.get("counts") or {}).get("shadow_marked", 0) >= 1,
              {"http": s, "outcome": rec.get("outcome"), "counts": rec.get("counts"), "rows": rows, "reason": rec.get("reason")})

    if want("F3"):
        st = owner_status("iceberg_mirror_daemon")
        declare(f"F3 iceberg_mirror_daemon: {OVERLAYS_FOR_DECLARED['iceberg mirror (F3)']}; owner ticks: {json.dumps(st.get('status'))[:160]}")
    if want("F4"):
        declare(f"F4 plain_parquet_mirror_daemon: {OVERLAYS_FOR_DECLARED['plain-parquet mirror (F4)']}; FOUND (not fixed here): "
                "core/plain_parquet_mirror.py::_safe_paginator returns [] so a built mirror records mirror_file_count=0 and route_files never serves it")
    if want("F5"):
        declare(f"F5 materialized islands / fleet syncer: {OVERLAYS_FOR_DECLARED['materialized islands / fleet syncer (F5)']}")


def plan():
    print(__doc__)
    print("OVERLAYS for the declared jobs (DB rows config.<section>.<key>; '+ restart' = read once at boot):")
    for k, v in OVERLAYS_FOR_DECLARED.items():
        print(f"  - {k}: {v}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="", help="S,R,F or S3,R12,...")
    ap.add_argument("--plan", action="store_true")
    a = ap.parse_args()
    if a.plan:
        plan()
        return 0
    only = set(filter(None, a.only.split(",")))
    parts = {p for p in ("S", "R", "F") if not only or p in only or any(k.startswith(p) and len(k) > 1 for k in only)}
    sub = {k for k in only if len(k) > 1}
    rig = Rig()
    rig.truth = {r.split("\t")[0]: int(r.split("\t")[1]) for r in subprocess.run(
        ["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", SRC_SQL],
        capture_output=True, text=True).stdout.strip().splitlines()}
    check("truth: 5 regions from Trino", len(rig.truth) == 5, rig.truth)
    ov = Overlay()
    owner = owner_pod()
    sweep_fid = None
    try:
        if (("S" in parts and (not sub or "S7" in sub)) or ("R" in parts and (not sub or "R2" in sub))):
            sweep_fid = rig.feed(f"JP_SWEEP_{TAG}")
        if "S" in parts:
            try:
                part_s(rig, owner, ov, {k for k in sub if k.startswith("S")}, sweep_fid)
            except Exception as exc:                          # noqa: BLE001
                check("S ran to the end", False, f"{type(exc).__name__}: {exc}")
        if "R" in parts:
            try:
                part_r(rig, owner, ov, {k for k in sub if k.startswith("R")}, sweep_fid)
            except Exception as exc:                          # noqa: BLE001
                check("R ran to the end", False, f"{type(exc).__name__}: {exc}")
        if "F" in parts:
            try:
                part_f(rig, owner, ov, {k for k in sub if k.startswith("F")})
            except Exception as exc:                          # noqa: BLE001
                check("F ran to the end", False, f"{type(exc).__name__}: {exc}")
    finally:
        n = ov.restore()
        print(f"\noverlays restored: {n}")
        removed, failures = rig.ledger.cleanup()
        if failures:
            res.append(False)
    print(f"\n{sum(res)}/{len(res)} PASSED" if all(res) else f"\n{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
