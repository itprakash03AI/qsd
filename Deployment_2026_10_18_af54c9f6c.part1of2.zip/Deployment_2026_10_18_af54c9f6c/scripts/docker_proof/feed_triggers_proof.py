"""How a feed gets TRIGGERED -- dependencies and data arrival, proven on the
live Docker rig with the scheduler doing the work (2026-10-07).

Owner: "dependencies ... how a file gets triggered based on Iceberg, how all
the other background jobs are watching ... websocket".  The model the code
implements (core/feed/etl_dependency.py, arrival_sources.py): a run is CREATED
by a schedule / backfill / upstream completion / external trigger; if its
dependencies are not met it is held at WAIT; a watcher records the ARRIVAL;
the dependency poller flips WAIT -> RUN; the queue worker runs it.  Every case
below proves the hold (it does NOT run early), then the release, and judges
the delivered file by value.

  T1 ETL dependency    -- held until the upstream ETL reports COMPLETE for that date
  T2 Iceberg commit    -- held until a NEW SNAPSHOT proving the business date
                          lands in the (real AWS) Iceberg table; the metadata
                          sync daemon notices it by itself
  T3 upstream feed     -- a feed declared `on_completion_of` another runs by
                          itself when the upstream delivers
  T4 never met         -- a held run does NOT run, and says what it waits for
  WS                   -- the browser's socket hears the hold and the release

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/feed_triggers_proof.py [--only T1,T2]
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from auth_rls_proof import Session  # noqa: E402

TAG = str(int(time.time()))[-6:]
HERE = os.path.dirname(os.path.abspath(__file__))
SQL = "select name as region, regionkey from tpch.tiny.region"
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:400], flush=True)
    return bool(ok)


def psql(sql):
    # A failed statement RAISES: returning "" for an error let a check
    # compare a broken query against "no rows" and pass (2026-10-10, K1).
    r = subprocess.run(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
                        "-v", "ON_ERROR_STOP=1", "-tAc", sql], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"psql failed ({r.returncode}): {r.stderr.strip()[-400:]} -- {sql[:200]}")
    return r.stdout.strip()


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True)
    return out.stdout.strip() or out.stderr.strip()[-300:]


T2_DATE = [None]


def wait_until(fn, timeout, every=3):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v, round(time.time() - t0)
        time.sleep(every)
    return None, round(time.time() - t0)


class Rig:
    def __init__(self):
        self.a = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
        self.undo = []
        self.truth = {r.split("\t")[0]: int(r.split("\t")[1]) for r in trino(
            "select name, regionkey from tpch.tiny.region").splitlines()}

    def call(self, *a, **k):
        s, b, _ = self.a.call(*a, **k)
        return s, b

    def feed(self, name, **extra):
        s, q = self.call("POST", "/api/queries", {"name": f"{name}_q", "query_config": {
            "files": [], "raw_sql": SQL, "connection_id": 2}})
        self.undo.append(f"/api/queries/{q['id']}")
        body = {"name": name, "source_type": "saved_query", "source_id": q["id"], "connection_id": 2,
                "output_format": "csv", "destination_type": "local", "destination_config": {},
                "execution_backend": "native", **extra}
        s, f = self.call("POST", "/api/feeds", body)
        if s != 200:
            raise SystemExit(f"feed {name}: {s} {str(f)[:300]}")
        self.undo.insert(0, f"/api/feeds/{f['id']}")
        return f["id"]

    def run_row(self, fid, date):
        r = psql(f"select id, status, action_decision, coalesce(action_reason,'') from feed_runs "
                 f"where feed_config_id={fid} and business_date='{date}' order by id desc limit 1")
        if not r:
            return None
        p = r.split("|")
        return {"id": int(p[0]), "status": p[1], "decision": p[2], "reason": p[3]}

    def file_of(self, fid):
        _, ex = self.call("GET", f"/api/feeds/{fid}/executions")
        items = ex if isinstance(ex, list) else (ex or {}).get("items") or (ex or {}).get("executions") or []
        done = [e for e in items if e.get("status") == "completed"]
        if not done:
            return None, None
        e = done[0]
        req = urllib.request.Request(f"http://127.0.0.1:8000/api/feed-executions/{e['id']}/download",
                                     headers={"Authorization": f"Bearer {self.a.token}"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                body = r.read().decode("utf-8-sig")
        except Exception as exc:                              # noqa: BLE001
            return e, f"download failed: {exc}"
        rows = {}
        for row in csv.DictReader(io.StringIO(body)):
            low = {k.lower().strip(): v for k, v in row.items()}
            rows[low["region"]] = int(float(low["regionkey"]))
        return e, rows


def dep_types(r):
    _, t = r.call("GET", "/api/feed-dependency-types")
    items = t if isinstance(t, list) else (t or {}).get("items") or (t or {}).get("types") or []
    return {str(x.get("name") or x.get("type_name")).upper(): x.get("id") for x in items}


def held_then_released(r, case, fid, date, satisfy, hold_for=45, release_timeout=420):
    s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": date, "end_date": date, "deliver": True,
                                                    "reason": "triggers proof on the Docker rig, signed off by rig_admin (test data only)"})
    check(f"{case} a run is created for {date}", s == 200, str(b)[:160])
    row, _ = wait_until(lambda: (lambda x: x if x and x["decision"] == "WAIT" else None)(r.run_row(fid, date)), 90)
    check(f"{case} the run is HELD at WAIT (dependency not met)", bool(row), r.run_row(fid, date))
    time.sleep(hold_for)
    still = r.run_row(fid, date)
    check(f"{case} after {hold_for}s it has NOT run (still WAIT, status pending)",
          still and still["decision"] == "WAIT" and still["status"] == "pending", still)
    t0 = time.time()
    satisfy()
    rel, secs = wait_until(lambda: (lambda x: x if x and x["decision"] == "RUN" else None)(r.run_row(fid, date)), release_timeout, 3)
    check(f"{case} the dependency was met -> the poller RELEASED it ({secs}s after the event)", bool(rel),
          {"row": r.run_row(fid, date)})
    done, secs2 = wait_until(lambda: (lambda x: x if x and x["status"] in ("completed", "failed") else None)(r.run_row(fid, date)), 300, 3)
    e, rows = r.file_of(fid)
    check(f"{case} the queue worker ran it by itself ({round(time.time() - t0)}s from event to file) and the file == source",
          done and done["status"] == "completed" and rows == r.truth, {"run": done, "rows": rows})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    only = set(filter(None, ap.parse_args().only.split(",")))
    want = lambda c: not only or c in only                 # noqa: E731
    r = Rig()
    check("truth: 5 regions", len(r.truth) == 5, r.truth)
    types = dep_types(r)
    check("dependency types are served", bool(types), types)
    stop = tempfile.mktemp(prefix="wsstop_")
    wsout = os.path.join(tempfile.gettempdir(), f"trig_ws_{TAG}.jsonl")
    rec = subprocess.Popen(["node", os.path.join(HERE, "ws_recorder.mjs"), wsout, stop],
                           env=dict(os.environ, QS_WS_TOKEN=r.a.token, QS_WS_USER="rig_admin"))
    s3 = None
    try:
        if want("T1"):
            print("\n== T1 ETL dependency -- held until the upstream ETL reports COMPLETE")
            fid = r.feed(f"TRG_T1_{TAG}")
            key = f"GL_LOAD_{TAG}"
            tid = types.get("ORACLE_TABLE") or next(iter(types.values()))
            s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [{
                "dependency_type_id": tid, "dependency_key": key, "description": "upstream GL load (ETL)",
                "arrival_sources": [{"kind": "etl"}]}]})
            check("T1 dependency declared (kind etl)", s == 200, str(b)[:200])
            held_then_released(r, "T1", fid, "2026-10-05", lambda: r.call("POST", "/api/admin/etl-dependencies/tracking", {
                "dependency_type_id": tid, "dependency_key": key, "business_date": "2026-10-05", "action": "COMPLETE"}))

        if want("T2"):
            print("\n== T2 Iceberg commit -- held until a new snapshot proves the business date (real AWS)")
            _, cl = r.call("GET", "/api/connections")
            items = cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []
            s3 = next((x["id"] for x in items if x.get("name") == "aws-real"), None)
            fid = r.feed(f"TRG_T2_{TAG}")
            tid = types.get("ICEBERG_TABLE") or next(iter(types.values()))
            # Inside the Iceberg-commit look-back window (14 days): a date outside
            # it is never recorded, by design, and the hold says so.  The row is
            # tagged with the sentinel currency QSP so cleanup removes only it.
            import datetime as _dt
            date = (_dt.date.today() - _dt.timedelta(days=5)).isoformat()
            T2_DATE[0] = date
            trino(f"delete from iceberg_aws.fin.dim_fx_rate where business_close_date = DATE '{date}' and currency = 'QSP'")
            s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [{
                "dependency_type_id": tid, "dependency_key": f"dim_fx_rate_{TAG}", "description": "FX rates for the day",
                "arrival_sources": [{"kind": "iceberg_commit", "connection_id": s3, "table": "dim_fx_rate",
                                     "date_column": "business_close_date"}]}]})
            check("T2 dependency declared (kind iceberg_commit on the real AWS table)", s == 200, str(b)[:200])
            held_then_released(r, "T2", fid, date, lambda: print("   committing:", trino(
                f"insert into iceberg_aws.fin.dim_fx_rate values (DATE '{date}', 'QSP', 1.0)")),
                hold_for=45, release_timeout=600)

        if want("T3"):
            print("\n== T3 upstream feed -- a downstream feed runs by itself when the upstream delivers")
            up = r.feed(f"TRG_T3UP_{TAG}")
            down = r.feed(f"TRG_T3DN_{TAG}", schedule_declaration={"kind": "on_completion_of", "feed": f"TRG_T3UP_{TAG}"})
            date = "2026-10-04"
            r.call("POST", f"/api/feeds/{up}/backfill", {"start_date": date, "end_date": date, "deliver": True,
                                                    "reason": "triggers proof on the Docker rig, signed off by rig_admin (test data only)"})
            dn, secs = wait_until(lambda: (lambda x: x if x and x["status"] == "completed" else None)(r.run_row(down, date)), 420, 3)
            trig = psql(f"select coalesce(triggered_by,'') from feed_runs where feed_config_id={down} and business_date='{date}' order by id desc limit 1")
            e, rows = r.file_of(down)
            check(f"T3 the downstream ran BY ITSELF after the upstream ({secs}s), triggered_by upstream_completion, file == source",
                  bool(dn) and "upstream" in trig and rows == r.truth, {"run": dn, "triggered_by": trig, "rows": rows})

        if want("T4"):
            print("\n== T4 never met -- a held run does not run, and says what it waits for")
            fid = r.feed(f"TRG_T4_{TAG}")
            tid = types.get("KAFKA") or next(iter(types.values()))
            r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [{
                "dependency_type_id": tid, "dependency_key": f"NEVER_{TAG}", "description": "a message that never comes",
                "arrival_sources": [{"kind": "etl"}]}]})
            date = "2026-10-03"
            r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": date, "end_date": date, "deliver": True,
                                                    "reason": "triggers proof on the Docker rig, signed off by rig_admin (test data only)"})
            time.sleep(60)
            row = r.run_row(fid, date)
            _, deps = r.call("GET", f"/api/feed-runs/{row['id']}/steps") if row else (None, None)
            check("T4 after 60 s the run is still WAIT and never ran", row and row["decision"] == "WAIT" and row["status"] == "pending", row)
            check("T4 the hold says WHAT it is waiting for", row and (f"NEVER_{TAG}" in row["reason"] or f"NEVER_{TAG}" in json.dumps(deps or {})),
                  {"reason": row and row["reason"]})
    finally:
        open(stop, "w").close()
        try:
            rec.wait(timeout=20)
        except Exception:                                      # noqa: BLE001
            rec.kill()
        if want("T2"):
            if T2_DATE[0]:
                trino(f"delete from iceberg_aws.fin.dim_fx_rate where business_close_date = DATE '{T2_DATE[0]}' and currency = 'QSP'")
                # a merge-on-read DELETE leaves the data file live, and the
                # iceberg_commit source proves a date from live file bounds:
                # compact so the shared table stops "covering" proof dates (2026-10-16)
                trino("ALTER TABLE iceberg_aws.fin.dim_fx_rate EXECUTE optimize")
        evs = []
        try:
            evs = [json.loads(l) for l in open(wsout, encoding="utf-8") if l.strip()]
        except OSError:
            pass
        kinds = {}
        for ev in evs:
            t = str(ev["msg"].get("type") or ev["msg"].get("event"))
            kinds[t] = kinds.get(t, 0) + 1
        print("\n== WS event types:", json.dumps(kinds, sort_keys=True))
        check("WS the browser heard the dependency hold/release and the runs (feed_dep_* / feed_* events)",
              any(k.startswith("feed_dep") for k in kinds) and any(k.startswith("feed_") and not k.startswith("feed_dep") for k in kinds),
              sorted(kinds))
        for p in r.undo:
            r.call("DELETE", p)
        print(f"\ncleanup: {len(r.undo)} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
