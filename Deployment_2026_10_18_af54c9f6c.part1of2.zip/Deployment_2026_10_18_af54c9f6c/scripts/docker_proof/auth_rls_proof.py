"""LOGIN + ROW SECURITY proof against the live Docker rig, as REAL, DIFFERENT users.

The base rig runs auth.type=none: everyone is the same guest admin, so owner and
role checks are inert and row security cannot be observed.  Run this against the
rig started with ``docker-compose.auth-rls.yml`` (three local users, row
security on, rewrite mode).

Every check asserts a NUMBER or a NAMED REFUSAL against truth computed on the
SOURCE (Trino, outside QueryStudio), never against the thing under test.

    . <file exporting QS_RIG_ADMIN_PW / QS_RIG_ANALYST_PW / QS_RIG_VIEWER_PW>
    python scripts/docker_proof/auth_rls_proof.py

The rig is SHARED: every policy this script disables is re-enabled, and every
policy / binding / report / published view it creates is recorded in a ledger
and removed in a ``finally``, with one ``cleanup: N objects removed, M could
not be`` line.  Exit status: 0 only when every check passed AND M == 0.

Leftovers from earlier runs (the rig needs the same login)::

    python scripts/docker_proof/auth_rls_proof.py --sweep-leftovers            # dry run
    python scripts/docker_proof/auth_rls_proof.py --sweep-leftovers --execute  # delete

matched only by this file's own name templates with the run-id shape in
place of the tag: policies ``rig-(eu|asia)-\\d{6}``, reports
``rls-rep(-v)?-\\d{6}``, published views ``rls-pv-\\d{6}`` (still active).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from proof_cleanup import (  # noqa: E402
    RUN_ID, Ledger, Rule, sweep_flags, sweep_leftovers,
)

DS = c.DS                       # bqb_trades over iceberg.qs.trades
COL = c.COL
TABLE = "iceberg.qs.trades"
PUB = "http://localhost:8003"   # the published-API tier (docker-compose.local.yml)
TAG = str(int(time.time()))[-6:]
USERS = {
    "rig_admin": os.environ.get("QS_RIG_ADMIN_PW"),
    "rig_analyst": os.environ.get("QS_RIG_ANALYST_PW"),
    "rig_viewer": os.environ.get("QS_RIG_VIEWER_PW"),
}
RESULTS: list[tuple[str, bool, str]] = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  -- {detail}" if detail else ""),
          flush=True)
    return ok


def section(title):
    print(f"\n== {title}", flush=True)


class Session:
    def __init__(self, username, password):
        self.username = username
        s, b, _ = c.call("POST", "/auth/login", {"username": username, "password": password})
        if s != 200 or not (b or {}).get("session_token"):
            raise SystemExit(f"login failed for {username}: {s} {b}")
        self.token = b["session_token"]
        self.role = b.get("role")

    def call(self, method, path, body=None, **kw):
        h = dict(kw.pop("headers", {}) or {})
        h["Authorization"] = f"Bearer {self.token}"
        # Admin routes are rate-limited (30/min).  A 429 is waited out, never
        # treated as an answer: a CLEANUP call refused by the limiter once left
        # six shared policies disabled on the rig.
        for _ in range(12):
            s, b, hd = c.call(method, path, body, headers=h, **kw)
            if s != 429:
                return s, b, hd
            time.sleep(float((hd or {}).get("Retry-After") or 5) + 0.5)
        return s, b, hd


def pub_call(method, path, headers):
    """A call against the published-API tier instead of the main API."""
    saved = c.BASE
    c.BASE = PUB
    try:
        return c.call(method, path, None, headers=headers)
    finally:
        c.BASE = saved


def trino_truth(sql):
    """Truth from Trino itself -- no QueryStudio code on the path."""
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV",
                          "--execute", sql], capture_output=True, text=True, timeout=300)
    rows = [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]
    if out.returncode != 0 or not rows:
        raise SystemExit(f"trino truth failed: {out.returncode} {out.stderr[-300:]}")
    return rows


def sql_region_counts(sess):
    """Run GROUP BY region through the SQL editor path as ``sess``."""
    s, b, _ = sess.call("POST", "/api/sql/execute", {
        "primary_connection_id": 2,
        "primary_sql": f"SELECT region, count(*) AS n FROM {TABLE} GROUP BY region",
        "row_limit": 50})
    if s != 200 or not (b or {}).get("execution_id"):
        return s, b
    eid = b["execution_id"]
    t0 = time.time()
    while time.time() - t0 < 300:
        _, st, _ = sess.call("GET", f"/api/executions/{eid}/status")
        status = (st or {}).get("status")
        if status in ("completed", "success", "finished"):
            _, rb, _ = sess.call("GET", f"/api/executions/{eid}/results?page_size=50")
            names = [x["name"] if isinstance(x, dict) else x for x in (rb.get("columns") or [])]
            rows = [r if isinstance(r, dict) else dict(zip(names, r)) for r in rb.get("rows") or []]
            return 200, {str(r.get("region")): int(r.get("n")) for r in rows}
        if status in ("failed", "error", "cancelled"):
            return 500, {"failed": (st or {}).get("error_message")}
        time.sleep(0.5)
    return -1, {"timeout": eid}


def sweep_rules():
    return [
        Rule("row-security policy", rf"rig-(eu|asia)-{RUN_ID}",
             list_path="/api/admin/row-security/policies",
             delete_path="/api/admin/row-security/policies/{id}"),
        # A view goes BEFORE the report it serves (report delete refuses 409
        # while an active view serves it -- the old order left orphans).
        Rule("published view (deactivated)", rf"rls-pv-{RUN_ID}",
             list_path="/api/published-views",
             delete_path="/api/published-views/{id}",
             where=lambda r: r.get("is_active") is not False),
        Rule("business report", rf"rls-rep(-v)?-{RUN_ID}",
             list_path="/api/business-reports",
             delete_path="/api/business-reports/{id}"),
    ]


def main(argv=None):
    sweep, execute, _rest = sweep_flags((argv or sys.argv)[1:])
    missing = [u for u, p in USERS.items() if not p]
    if sweep and not USERS["rig_admin"]:
        raise SystemExit("the sweep needs QS_RIG_ADMIN_PW (the rig needs login)")
    if sweep:
        admin = Session("rig_admin", USERS["rig_admin"])
        return sweep_leftovers(admin.call, sweep_rules(), execute=execute)
    if missing:
        raise SystemExit(f"set the rig passwords first (missing for {missing})")

    section("0 . the rig must be the LOGIN rig")
    s, _, _ = c.call("GET", "/api/datasets", headers={"Authorization": ""})  # explicitly ANONYMOUS
    if not check("an anonymous request is refused", s == 401, f"http={s}"):
        raise SystemExit("the rig is not running with login -- start it with "
                         "docker-compose.auth-rls.yml")
    S = {u: Session(u, p) for u, p in USERS.items()}
    check("each user signs in with their own role",
          [S[u].role for u in USERS] == ["admin", "analyst", "viewer"],
          str({u: S[u].role for u in USERS}))
    s, b, _ = c.call("POST", "/auth/login", {"username": "rig_admin", "password": "not-it"})
    check("a wrong password is refused", s == 401, f"http={s}")

    truth = {r[0]: int(r[1]) for r in trino_truth(
        f"SELECT region, count(*) FROM {TABLE} GROUP BY region")}
    total = sum(truth.values())
    check("truth is non-trivial", total > 0 and len(truth) >= 3, json.dumps(truth))

    admin = S["rig_admin"]
    _, before, _ = admin.call("GET", "/api/admin/row-security/policies")
    before = before if isinstance(before, list) else (before or {}).get("policies") or []
    enabled_before = sorted(p["id"] for p in before if p.get("enabled"))
    created_policies, created_bindings, disabled, created_reports = [], [], [], []
    created_views: list = []
    shared_conn = False
    # Everything this run CREATES goes in the ledger as the admin (the
    # bindings first, then policies -- the ledger removes newest first).
    ledger = Ledger(admin.call)
    left: list = []
    try:
        section("1a . a connection nobody shared is invisible to a non-owner")
        s, conn, _ = admin.call("GET", "/api/connections/2")
        was_shared = bool((conn or {}).get("is_shared"))
        if not was_shared:
            s, b = sql_region_counts(S["rig_analyst"])
            check("rig_analyst on an unshared connection: 404, not an existence oracle",
                  s == 404, f"http={s} {json.dumps(b)[:120]}")
            s, _, _ = S["rig_analyst"].call("GET", "/api/connections/2")
            check("rig_analyst cannot read the connection itself", s == 404, f"http={s}")
            share_body = {k: conn[k] for k in ("name", "connection_type", "config")}
            s, _, _ = admin.call("PUT", "/api/connections/2", {**share_body, "is_shared": True})
            shared_conn = s == 200
            check("the admin shares it (restored at the end)", shared_conn, f"http={s}")

        section("1 . row security -- policies bound to real users")
        s, pols, _ = admin.call("GET", "/api/admin/row-security/policies")
        pols = pols if isinstance(pols, list) else (pols or {}).get("policies") or []
        # The rig is shared: earlier audits left enabled probe policies (one bound
        # to EVERY principal).  Park them for the run; restored in ``finally``.
        for p in pols:
            if p.get("enabled"):
                s2, _, _ = admin.call("PUT", f"/api/admin/row-security/policies/{p['id']}",
                                      {"enabled": False})
                if s2 == 200:
                    disabled.append(p["id"])
        if not check("pre-existing policies parked for the run",
                     sorted(disabled) == enabled_before, f"parked ids={sorted(disabled)}"):
            raise SystemExit("could not park every enabled policy -- results would be confounded")

        def policy(name, region):
            s, b, _ = admin.call("POST", "/api/admin/row-security/policies", {
                "name": f"{name}-{TAG}", "table_pattern": TABLE,
                "filter_sql": f"region = '{region}'", "enforcement": "rewrite",
                "policy_class": "permissive"})
            if s == 200 and (b or {}).get("id"):
                created_policies.append(b["id"])
                ledger.add("row-security policy", f"{name}-{TAG}",
                           path=f"/api/admin/row-security/policies/{b['id']}")
                return b["id"]
            raise SystemExit(f"policy create failed: {s} {b}")

        def bind(pid, ptype, principal):
            s, b, _ = admin.call("POST", "/api/admin/row-security/bindings", {
                "policy_kind": "row", "policy_id": pid,
                "principal_type": ptype, "principal_id": principal})
            if s == 200 and (b or {}).get("id"):
                created_bindings.append(b["id"])
                ledger.add("row-security binding", f"policy {pid} -> {ptype} {principal}",
                           path=f"/api/admin/row-security/bindings/{b['id']}")
                return b["id"]
            raise SystemExit(f"binding create failed: {s} {b}")

        eu = policy("rig-eu", "EUROPE")
        asia = policy("rig-asia", "ASIA")
        b_an = bind(eu, "user", "rig_analyst")
        bind(asia, "user", "rig_viewer")
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})

        section("2 . the SQL editor path, as each user")
        for u, expect in (("rig_admin", truth),
                          ("rig_analyst", {"EUROPE": truth["EUROPE"]}),
                          ("rig_viewer", {"ASIA": truth["ASIA"]})):
            s, got = sql_region_counts(S[u])
            if u == "rig_viewer" and s in (401, 403):
                check(f"{u}: the SQL editor is refused for a viewer", True, f"http={s}")
                continue
            check(f"{u}: sees exactly {sorted(expect)}", s == 200 and got == expect,
                  f"http={s} got={json.dumps(got)[:300]}")

        section("3 . a principal with NO grant on a table that HAS grants")
        admin.call("DELETE", f"/api/admin/row-security/bindings/{b_an}")
        created_bindings.remove(b_an)
        ledger.forget(f"/api/admin/row-security/bindings/{b_an}")
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        s, got = sql_region_counts(S["rig_analyst"])
        check("rig_analyst unbound: sees NO rows (not every row)",
              s == 200 and sum(got.values()) == 0 if isinstance(got, dict) else False,
              f"http={s} got={json.dumps(got)[:300]}")
        bind(eu, "user", "rig_analyst")
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})

        section("4 . cache identity -- same query, different people, back to back")
        _, a1 = sql_region_counts(admin)
        _, n1 = sql_region_counts(S["rig_analyst"])
        _, a2 = sql_region_counts(admin)
        check("admin -> analyst -> admin: nobody is served another's rows",
              a1 == truth and n1 == {"EUROPE": truth["EUROPE"]} and a2 == truth,
              f"admin={sum((a1 or {}).values())} analyst={json.dumps(n1)} "
              f"admin again={sum((a2 or {}).values())}")

        section("5 . reports -- authoring, visibility, and row security per reader")
        sums = {r[0]: round(float(r[1]), 2) for r in trino_truth(
            f"SELECT region, sum(amt) FROM {TABLE} GROUP BY region")}
        s, rep, _ = admin.call("POST", "/api/business-reports", {
            "name": f"rls-rep-{TAG}", "dataset_id": DS, "data_source_type": "dataset",
            "column_ids": [COL["region"], COL["amt"]]})
        rid = (rep or {}).get("id")
        if rid:
            created_reports.append(rid)
            ledger.add("business report", f"rls-rep-{TAG}",
                       path=f"/api/business-reports/{rid}")
        check("the admin authors a report", s == 200 and rid, f"http={s} id={rid}")
        s, vr, _ = S["rig_viewer"].call("POST", "/api/business-reports", {
            "name": f"rls-rep-v-{TAG}", "dataset_id": DS, "data_source_type": "dataset",
            "column_ids": [COL["region"]]})
        if s == 200 and (vr or {}).get("id"):
            created_reports.append(vr["id"])
            ledger.add("business report", f"rls-rep-v-{TAG}",
                       path=f"/api/business-reports/{vr['id']}")
        check("a viewer may NOT author a report", s == 403, f"http={s}")
        for verb, meth, path, body in (
                ("view", "GET", f"/api/business-reports/{rid}", None),
                ("run", "POST", f"/api/business-reports/{rid}/execute", {"parameter_values": {}}),
                ("edit", "PUT", f"/api/business-reports/{rid}", {"name": "hijack"}),
                ("delete", "DELETE", f"/api/business-reports/{rid}", None)):
            s, _, _ = S["rig_analyst"].call(meth, path, body)
            check(f"an analyst may not {verb} someone else's UNPUBLISHED report",
                  s in (403, 404), f"http={s}")
        s, _, _ = admin.call("POST", f"/api/business-reports/{rid}/publish", {})
        check("the owner publishes it", s == 200, f"http={s}")

        def report_rows(sess):
            s, run, _ = sess.call("POST", f"/api/business-reports/{rid}/execute",
                                  {"parameter_values": {}})
            eid = (run or {}).get("execution_id")
            if s != 200 or not eid:
                return s, run
            s, res, _ = sess.call("GET", f"/api/business-reports/{rid}/results/{eid}?page_size=50")
            rows = (res or {}).get("rows") or []
            return s, {str(r.get("region")): round(float(r.get("amt")), 2) for r in rows}

        for u, want in (("rig_admin", sums),
                        ("rig_analyst", {"EUROPE": sums["EUROPE"]}),
                        ("rig_viewer", {"ASIA": sums["ASIA"]})):
            s, got = report_rows(S[u])
            check(f"report run as {u}: exactly {sorted(want)} with the source's sums",
                  s == 200 and got == want, f"http={s} got={json.dumps(got)[:260]}")

        s, body, _ = S["rig_analyst"].call("GET", f"/api/business-reports/{rid}/download-csv",
                                           raw=True)
        text = bytes(body).decode("utf-8-sig") if isinstance(body, (bytes, bytearray)) else ""
        regions = sorted({ln.split(",")[0] for ln in text.splitlines()[1:] if ln.strip()})
        check("the analyst's CSV EXPORT carries only their rows", s == 200 and regions == ["EUROPE"],
              f"http={s} regions={regions}")

        section("6 . the PUBLISHED API over that report (tier :8003)")
        slug = f"rls-pv-{TAG}"
        s, pv, _ = admin.call("POST", "/api/published-views", {
            "name": slug, "slug": slug, "source_type": "business_report",
            "business_report_id": rid, "credential_mode": "publisher"})
        pv_id = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
        if pv_id:
            created_views.append(pv_id)
            ledger.add("published view (deactivated)", slug,
                       path=f"/api/published-views/{pv_id}")
        key = (pv or {}).get("test_api_key") or ""
        check("the owner publishes it as an API, with a test key",
              s in (200, 201) and pv_id and key, f"http={s} id={pv_id} key={'yes' if key else 'no'}")
        print(f"    publish response keys: {sorted((pv or {}).keys())[:20]}")

        def pv_rows(headers):
            s, b, _ = pub_call("GET", f"/api/v1/views/{slug}/data?limit=50", headers)
            rows = (b or {}).get("data") or (b or {}).get("rows") or [] if isinstance(b, dict) else []
            got = {str(r.get("region")): round(float(r.get("amt")), 2)
                   for r in rows if isinstance(r, dict) and r.get("region") is not None}
            return s, got, b

        s, got, raw = pv_rows({"X-API-Key": key})
        # 403 AND the reason -- a bare 500 is a crash that happens to return no
        # rows; accepting "any >= 400" once passed exactly that.
        detail = str((raw or {}).get("detail", "")) if isinstance(raw, dict) else ""
        check("an API KEY on a governed table is REFUSED (403, naming row security)",
              s == 403 and "row-security" in detail.lower() and not got,
              f"http={s} detail={detail[:160]}")
        for u, want in (("rig_admin", sums), ("rig_analyst", {"EUROPE": sums["EUROPE"]})):
            s, got, raw = pv_rows({"Authorization": f"Bearer {S[u].token}"})
            check(f"the API called with {u}'s session: exactly {sorted(want)}",
                  s == 200 and got == want, f"http={s} got={json.dumps(got)[:200]} "
                  f"body={json.dumps(raw)[:160] if s != 200 else ''}")
    finally:
        section("cleanup")
        # Everything CREATED leaves through the ledger, newest first
        # (published view, reports, bindings, policies) -- and what could
        # not be removed is said, by count, and fails the run.
        _removed, left = ledger.cleanup(echo=lambda s: print("  " + s))
        # DELETE on a published view DEACTIVATES it (the UI's own word; usage
        # history is kept).  What must hold is that it can no longer be called.
        for vid in created_views:
            _, vv, _ = admin.call("GET", f"/api/published-views/{vid}")
            check(f"cleanup: published view {vid} is deactivated",
                  isinstance(vv, dict) and vv.get("is_active") is False,
                  f"is_active={(vv or {}).get('is_active') if isinstance(vv, dict) else vv}")
        # What was CHANGED (not created) is put back as found.
        if shared_conn:
            s, _, _ = admin.call("PUT", "/api/connections/2", {**share_body, "is_shared": False})
            print(f"  connection 2 unshared again: http={s}")
        for pid in disabled:
            admin.call("PUT", f"/api/admin/row-security/policies/{pid}", {"enabled": True})
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        _, after, _ = admin.call("GET", "/api/admin/row-security/policies")
        after = after if isinstance(after, list) else (after or {}).get("policies") or []
        check("cleanup: the rig's policies are exactly as found",
              sorted(p["id"] for p in after if p.get("enabled")) == enabled_before
              and not {p["id"] for p in after} & set(created_policies),
              f"enabled before={enabled_before} after="
              f"{sorted(p['id'] for p in after if p.get('enabled'))}")
        if shared_conn:
            _, cn, _ = admin.call("GET", "/api/connections/2")
            check("cleanup: connection 2 is unshared again", not (cn or {}).get("is_shared"))

    failed = [r for r in RESULTS if not r[1]]
    print(f"\n=== {len(RESULTS)} checks, {len(failed)} failed"
          + (f", cleanup left {len(left)} object(s) on the rig" if left else "")
          + " ===")
    return 1 if (failed or left) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
