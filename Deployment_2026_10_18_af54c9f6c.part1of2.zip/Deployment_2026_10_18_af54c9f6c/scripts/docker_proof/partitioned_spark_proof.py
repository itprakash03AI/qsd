"""A declared partition key on the SPARK pods, proven live (2026-10-14; the
owner: "are you not using the partitioned query? ... please fix it").

One query on the rig's Trino (``tpch.sf1.orders``, 1.5M rows), declared
``partition_config = {column: orderpriority, order_within: [orderpriority,
orderkey]}``, run as two feeds: QueryStudio's engine and a Spark pod.

  S1  both complete; the Spark run's record says it read by BUCKETS
      (files_metadata.partitioned_read: partition_values, 5 buckets) and the
      driver log shows one JDBC partition per bucket
  S2  rows == Trino's count
  S3  the two delivered files are BYTE-IDENTICAL (sha256 inside qs-sftp):
      same rows, same order -- the value order of the buckets, the
      order_within inside each

    python partitioned_spark_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key       # noqa: E402
from tetb_real_e2e_proof import SFTP                            # noqa: E402

SQL = ("SELECT orderkey, custkey, orderstatus, totalprice, orderdate, orderpriority, clerk "
       "FROM tpch.sf1.orders")
PC = {"column": "orderpriority", "order_within": ["orderpriority", "orderkey"]}
BD = os.environ.get("QS_PROOF_BD", "2026-09-30")
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:600]}" if detail else ""), flush=True)


def run(r, name, lane, conn_id):
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": conn_id,
            "query_params": {"sql": SQL}, "backend_config": {"partition_config": PC},
            "output_format": "csv", "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
            "execution_backend": lane, "is_active": True, "schedule_enabled": False,
            "notify_on_failure": False, "description": "Proof: a partition key on " + lane}
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    f = next((x for x in feeds if x["name"] == name), None)
    s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
    if s not in (200, 201):
        raise SystemExit(f"{name}: {s} {str(b)[:400]}")
    fid = f["id"] if f else b["id"]
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": BD, "end_date": BD, "deliver": True,
                                                   "reason": "partition key proof"})
    t0 = time.time()
    while time.time() - t0 < 3600:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                   f"and business_date='{BD}' order by id desc limit 1")
        if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
            break
        time.sleep(10)
    eid, status = row.split("|")
    s, ex = r.call("GET", f"/api/feed-executions/{eid}")
    r.call("PUT", f"/api/feeds/{fid}", {"is_active": False})          # no SOD run tomorrow
    return eid, status, ex or {}, round(time.time() - t0)


def sha(name):
    out = subprocess.run(["docker", "exec", "qs-sftp", "sha256sum", f"{SFTP['home']}/{name}"],
                         capture_output=True, text=True)
    return out.stdout.split()[0] if out.returncode == 0 and out.stdout else None


def main():
    r = Rig()
    conn = int(os.environ.get("QS_PROOF_TRINO_CONN", "2"))
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute",
                          f"SELECT count(*) FROM ({SQL})"], capture_output=True, text=True,
                         env=dict(os.environ, MSYS_NO_PATHCONV="1"))
    truth = int(out.stdout.strip().strip('"'))
    res = {}
    for lane, name in (("native", "PK_PROOF_NATIVE"), ("spark_k8s", "PK_PROOF_SPARK")):
        eid, status, ex, secs = run(r, name, lane, conn)
        res[lane] = (eid, status, ex)
        check(f"S1 {name} completed on {lane}", status == "completed",
              f"{status} {secs}s {ex.get('error_message') or ''}")
        check(f"S2 {name}: rows == Trino's count", int(ex.get("total_rows") or -1) == truth,
              f"{ex.get('total_rows')} vs {truth}")
    pr = ((res["spark_k8s"][2].get("files_metadata") or {}).get("partitioned_read") or {}).get("primary") or {}
    check("S1 the Spark run read BY BUCKETS (recorded)", pr.get("mode") == "partition_values"
          and int(pr.get("bucket_count") or 0) == 5, {k: pr.get(k) for k in
                                                       ("mode", "partition_column", "bucket_count",
                                                        "sum_bucket_expected", "lane")})
    s, lg = r.call("GET", f"/api/feed-executions/{res['spark_k8s'][0]}/driver-log")
    text = json.dumps(lg)
    check("S1 the driver read one JDBC partition per bucket", "in 5 bucket(s) on" in text,
          "" if "in 5 bucket(s) on" in text else text[:300])
    a = sha(f"PK_PROOF_NATIVE_{BD.replace('-', '')}.csv")
    b = sha(f"PK_PROOF_SPARK_{BD.replace('-', '')}.csv")
    check("S3 the native file and the Spark file are BYTE-IDENTICAL", a and a == b, f"{a} vs {b}")
    path = os.path.join(HERE, "partitioned-spark-results.json")
    json.dump({"checks": CHECKS}, open(path, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
