"""Build a REAL Iceberg table on AWS S3 carrying BOTH kinds of deletes
(2026-10-14, step 4 of docs/READ_PLAN_ALL_ENGINES_2026_10_14.html).

Runs INSIDE the Spark job image (local mode) -- invoked by
``iceberg_deletes_proof.py``, which mounts this file and passes the location:

* 20,000 rows (id INT 0..19999), Iceberg format v2, merge-on-read deletes,
  written as several files;
* POSITION deletes: Spark SQL ``DELETE ... WHERE id % 10 = 0`` (2,000 rows);
* EQUALITY deletes: an equality-delete file on ``id`` for ids 1, 3, 5, ... 299
  written through Iceberg's own writer (``GenericAppenderFactory``) and
  committed as a row delta -- the kind Flink / CDC writers produce;

then prints ``EXPECTED <rows>`` (computed from what was written and deleted,
independently of any reader) and the metadata file + snapshot to read.
"""
import sys

from pyspark.sql import SparkSession

location = sys.argv[1]                      # s3a://bucket/prefix/mor_<tag>
spark = (SparkSession.builder.appName("iceberg-deletes-table")
         .config("spark.sql.extensions",
                 "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
         .config("spark.sql.catalog.mor", "org.apache.iceberg.spark.SparkCatalog")
         .config("spark.sql.catalog.mor.type", "hadoop")
         .config("spark.sql.catalog.mor.warehouse", location.rsplit("/", 1)[0])
         .getOrCreate())
spark.sparkContext.setLogLevel("ERROR")
name = location.rsplit("/", 1)[1]
spark.sql(f"DROP TABLE IF EXISTS mor.{name}")
spark.sql(f"""CREATE TABLE mor.{name} (id INT, code STRING, amt DOUBLE) USING iceberg
              TBLPROPERTIES ('format-version'='2', 'write.delete.mode'='merge-on-read',
                             'write.update.mode'='merge-on-read', 'write.merge.mode'='merge-on-read')""")
(spark.range(0, 20000).selectExpr("cast(id as int) as id", "concat('E', cast(id % 3 as string)) as code",
                                  "cast(id as double) + 0.25 as amt")
 .repartition(4).writeTo(f"mor.{name}").append())
spark.sql(f"DELETE FROM mor.{name} WHERE id % 10 = 0")              # position deletes

jvm = spark._jvm
table = jvm.org.apache.iceberg.hadoop.HadoopTables(
    spark._jsc.hadoopConfiguration()).load(location)
schema = table.schema()
id_field = schema.findField("id").fieldId()
eq_schema = schema.select(["id"])
gw = spark.sparkContext._gateway
ids = gw.new_array(gw.jvm.int, 1)
ids[0] = id_field
factory = jvm.org.apache.iceberg.data.GenericAppenderFactory(schema, table.spec(), ids, eq_schema, None)
out = table.io().newOutputFile(f"{location}/data/eq-delete-00001.parquet")
enc = jvm.org.apache.iceberg.encryption.EncryptedFiles.plainAsEncryptedOutput(out)
writer = factory.newEqDeleteWriter(enc, jvm.org.apache.iceberg.FileFormat.PARQUET, None)
rec = jvm.org.apache.iceberg.data.GenericRecord.create(eq_schema)
eq_ids = list(range(1, 300, 2))                                     # odd ids 1..299
for i in eq_ids:
    r = rec.copy()
    r.setField("id", int(i))      # an INT column: Py4J passes a Java Integer
    writer.write(r)
writer.close()
table.newRowDelta().addDeletes(writer.toDeleteFile()).commit()      # equality deletes

pos_deleted = {i for i in range(20000) if i % 10 == 0}
expected = 20000 - len(pos_deleted | set(eq_ids))
table.refresh()
snap = table.currentSnapshot()
summary = dict(snap.summary())
print("EXPECTED", expected)
print("SNAPSHOT", snap.snapshotId())
print("METADATA", table.operations().current().metadataFileLocation())
print("SUMMARY", {k: summary.get(k) for k in ("total-records", "total-position-deletes",
                                                 "total-equality-deletes", "total-delete-files",
                                                 "total-data-files")})
print("SPARK_COUNT", spark.read.format("iceberg").load(location).count())
