"""Configuration release UAT -> PROD, live on the rig (2026-10-17,
docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §5, the proof plan).

Two QueryStudios: the rig's api (UAT, :8000, database ``querystudio``) and a
twin (PROD, :8010, database ``querystudio_prod``, started from
scripts/docker_proof/compose/config_release.override.yml with governance
ENABLED, git-truth and four-eyes).  Everything goes through the routes --
the same ones the UI and the pipeline CLI call.

  P1  a feed estate is built in UAT through the authoring routes (user group,
      calendar + holiday, dependency type, control-file format, feed group,
      SQL file, an SFTP feed, a restatement policy, an alert route, a hold
      approver, a template with 2 members); the feed runs; the file's sha256
  P2  export of the feed group = exactly the closure; checksum verifies;
      re-export byte-identical
  P3  no secret in the package (the SFTP password, every credential-shaped key)
  P4  PROD preview: everything new; BLOCKED on the unmapped connection /
      host / user / path / e-mail, and the attached rows cascade
  P5  mappings set -> preview ready
  P6  approve by the uploader REFUSED (four-eyes); approve by a second admin
      with a ticket; apply -> every object created, one ledger row each, the
      template's 2 members rendered in PROD, verification verdicts
  P7  the PROD feed runs for the same date: the file is byte-identical
  P8  one field changed in UAT -> exactly one changed field in the preview
  P9  a hand edit in PROD on another field -> prod_edited, KEPT by the apply
  P10 the same field edited in PROD -> conflict; apply refused; decided
      take_release -> applied, decision recorded
  P11 rollback -> PROD returns to the snapshot; the rolled-back release says so
  P12 the audit log holds export / upload / approve / apply / rollback
  P13 negatives: an injected password, an altered checksum, an unknown kind
      are each refused on upload
  P14 a used UAT has stale objects: a plan of 'everything' names every
      problem in ONE answer; the group export is refused with BOTH its
      problems; excluding the stale query alone refuses the feed that reads
      it; three recorded exclusions -> the rest of the group is released and
      PROD's preview shows what was left out

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/config_release_proof.py [--keep]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")

UAT = "http://localhost:8000"
PROD = "http://localhost:8010"
TAG = str(int(time.time()))[-6:]
BD = "2026-10-15"
SQL = "SELECT name AS region, regionkey FROM tpch.tiny.region ORDER BY regionkey"
SFTP = {"container": "qs-sftp", "host": "qs-sftp", "port": 22, "username": "feeduser",
        "password": os.environ.get("QS_SFTP_PASSWORD", "FeedPass_123"), "remote_dir": "/inbox",
        "home": "/home/feeduser/inbox"}
APPROVER = "rig_release_approver"
APPROVER_PW = os.environ.get("QS_RIG_RELEASE_APPROVER_PW") or ("Rel-" + os.environ.get("QS_RIG_ADMIN_PW", "x") + "-2026")

res: list[bool] = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:500], flush=True)
    return bool(ok)


def docker(*args, timeout=120):
    r = subprocess.run(["docker", *args], capture_output=True, text=True, env=DENV, timeout=timeout)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def psql(db, sql):
    rc, out, err = docker("exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", db, "-v",
                          "ON_ERROR_STOP=1", "-tAc", sql)
    if rc != 0:
        raise RuntimeError(f"psql({db}) failed: {err[-300:]} -- {sql[:200]}")
    return out


def http(base, method, path, body=None, token=None, timeout=300):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(base + path, data=data, method=method)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    for _ in range(12):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8")
                return resp.status, (json.loads(raw) if raw else None)
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                time.sleep(float(exc.headers.get("Retry-After") or 5) + 0.5)
                continue
            raw = exc.read().decode("utf-8", "replace")
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, {"detail": raw}
    return 429, {"detail": "rate limited"}


class Env:
    def __init__(self, base, username, password):
        self.base = base
        s, b = http(base, "POST", "/auth/login", {"username": username, "password": password})
        if s != 200 or not (b or {}).get("session_token"):
            raise SystemExit(f"login {username} on {base} failed: {s} {str(b)[:200]}")
        self.token = b["session_token"]
        self.username = username

    def call(self, method, path, body=None, **kw):
        return http(self.base, method, path, body, token=self.token, **kw)

    def connection_id(self, name):
        s, b = self.call("GET", "/api/connections?limit=1000")
        items = b if isinstance(b, list) else (b or {}).get("items") or (b or {}).get("connections") or []
        for c in items:
            if c.get("name") == name:
                return c["id"]
        return None

    def feed_by_name(self, name):
        s, b = self.call("GET", f"/api/feeds?limit=2000&search={name}")
        items = b if isinstance(b, list) else (b or {}).get("items") or (b or {}).get("feeds") or []
        for f in items:
            if f.get("name") == name:
                return f
        return None

    def run_feed(self, fid, timeout=420):
        s, b = self.call("POST", f"/api/feeds/{fid}/backfill",
                         {"start_date": BD, "end_date": BD, "deliver": True,
                          "reason": "config release proof on the Docker rig (test data only)"})
        if s != 200:
            return None, f"backfill: {s} {str(b)[:300]}"
        t0 = time.time()
        while time.time() - t0 < timeout:
            s, ex = self.call("GET", f"/api/feeds/{fid}/executions")
            items = ex if isinstance(ex, list) else (ex or {}).get("items") or (ex or {}).get("executions") or []
            done = [e for e in items if e.get("status") in ("completed", "failed")]
            if done:
                return done[0], None
            time.sleep(4)
        return None, "the run did not finish in time"


def sftp_host_key():
    rc, out, err = docker("exec", SFTP["container"], "cat", "/etc/ssh/ssh_host_ed25519_key.pub")
    if rc != 0 or not out:
        raise SystemExit(f"could not read qs-sftp's host key: {err[-200:]}")
    return out.split()[1]


def sftp_sha(name):
    r = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{name}"],
                       capture_output=True, env=DENV)
    return hashlib.sha256(r.stdout).hexdigest() if r.returncode == 0 else None


def wait_ready(base, timeout=300):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            if http(base, "GET", "/health/ready", timeout=5)[0] == 200:
                return True
        except OSError:
            pass
        time.sleep(3)
    return False


def start_prod_twin():
    # a CLEAN "PROD" every run (the lead's rig run, 2026-10-17): PROD's database
    # persisted between runs, so mappings stored by an earlier run made P4's
    # "names the unmapped connection / host / user / path" pass or fail by history
    subprocess.run(["docker", "compose", "-f", "docker-compose.rig.yml", "-f",
                    "scripts/docker_proof/compose/config_release.override.yml", "rm", "-sf", "prod-api"],
                   capture_output=True, text=True, env=DENV, cwd=ROOT, timeout=300)
    psql("querystudio", "drop database if exists querystudio_prod with (force)")
    psql("querystudio", "create database querystudio_prod")
    print("created a clean database querystudio_prod", flush=True)
    rc, out, err = subprocess.run(
        ["docker", "compose", "-f", "docker-compose.rig.yml", "-f",
         "scripts/docker_proof/compose/config_release.override.yml", "up", "-d", "prod-api"],
        capture_output=True, text=True, env=DENV, cwd=ROOT, timeout=600).returncode, "", ""
    if rc != 0:
        raise SystemExit("docker compose up prod-api failed")
    if not wait_ready(PROD):
        raise SystemExit("the PROD twin did not become ready on :8010")
    # a SECOND admin for four-eyes: a break-glass super admin in PROD's database
    s, b = http(PROD, "POST", "/auth/login", {"username": APPROVER, "password": APPROVER_PW})
    if s != 200:
        rc, out, err = docker("exec", "qs-prod-api", "python", "-m", "querystudio", "super-admin", "create",
                              "--username", APPROVER, "--password", APPROVER_PW, "--notes", "config release proof")
        if rc != 0 and "exists" not in (out + err).lower():
            raise SystemExit(f"could not create the approver: {out[-200:]} {err[-200:]}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true", help="leave the PROD twin running")
    args = ap.parse_args()
    pw = os.environ.get("QS_RIG_ADMIN_PW")
    if not pw:
        raise SystemExit("QS_RIG_ADMIN_PW is unset (. ~/.qs_keys/rigpw.sh)")
    start_prod_twin()
    uat = Env(UAT, "rig_admin", pw)
    prod = Env(PROD, "rig_admin", pw)
    approver = Env(PROD, APPROVER, APPROVER_PW)
    trino = uat.connection_id("trino-rig")
    if not trino:
        raise SystemExit("UAT has no connection 'trino-rig' (rig/seed_rig.py)")

    # ── P1: the UAT estate ──────────────────────────────────────────────
    names = {k: f"REL_{k.upper()}_{TAG}" for k in ("grp", "cal", "dep", "ctl", "ops", "feed", "tpl")}
    s, ug = uat.call("POST", "/api/admin/user-groups", {"name": names["ops"], "description": "release proof"})
    check("P1 user group created", s in (200, 201), (s, str(ug)[:200]))
    s, cal = uat.call("POST", "/api/admin/feed-calendars", {"name": names["cal"], "weekend_days": [6, 7]})
    check("P1 calendar created", s in (200, 201), (s, str(cal)[:200]))
    s, hol = uat.call("POST", f"/api/admin/feed-calendars/{cal['id']}/holidays",
                      {"holiday_date": "2026-12-25", "holiday_name": "Christmas", "recurring": True})
    check("P1 holiday added", s in (200, 201), (s, str(hol)[:200]))
    s, dep = uat.call("POST", "/api/admin/etl-dependencies/types",
                      {"dependency_type": names["dep"], "description": "release proof", "server": "kafka.uat:9092"})
    check("P1 dependency type created", s in (200, 201), (s, str(dep)[:200]))
    s, ctl = uat.call("POST", "/api/admin/feed-control-file-formats",
                      {"name": names["ctl"], "style": "key_value", "fields": ["file_name", "row_count", "checksum_sha256"],
                       "checksum_algorithms": ["sha256"]})
    check("P1 control-file format created", s in (200, 201), (s, str(ctl)[:200]))
    s, grp = uat.call("POST", "/api/feed-groups", {"name": names["grp"], "notification_email": f"team-{TAG}@uat.example"})
    check("P1 feed group created", s in (200, 201), (s, str(grp)[:200]))
    s, sf = uat.call("POST", "/api/sql-files", {"name": f"rel_q_{TAG}", "sql": SQL, "connection_id": trino, "is_shared": True})
    check("P1 SQL file created", s in (200, 201), (s, str(sf)[:200]))
    dest = {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"], "password": SFTP["password"],
            "remote_dir": SFTP["remote_dir"], "host_key_b64": sftp_host_key()}
    fname = f"rel_feed_{TAG}_{{business_date:YYYYMMDD}}.csv"
    s, feed = uat.call("POST", "/api/feeds", {
        "name": names["feed"], "source_type": "sql_file", "source_id": sf["id"], "connection_id": trino,
        "output_format": "csv", "output_options": {"delimiter": ","}, "output_filename_template": fname,
        "destination_type": "sftp", "destination_config": dest, "execution_backend": "native",
        "schedule_enabled": False, "calendar_name": names["cal"], "control_file_format_id": ctl["id"],
        "feed_group_id": grp["id"], "owner_group_id": ug["id"], "notify_emails": f"owner-{TAG}@uat.example"})
    if not check("P1 SFTP feed created", s == 200 and (feed or {}).get("id"), (s, str(feed)[:300])):
        return finish()
    fid = feed["id"]
    s, pol = uat.call("PUT", "/api/admin/feed-restatement-policies",
                      {"scope": "feed", "scope_id": fid, "name": "proof", "on_new_message": "rerun",
                       "same_run_date": "hold", "window": "open"})
    check("P1 restatement policy at feed scope", s in (200, 201), (s, str(pol)[:200]))
    s, route = uat.call("POST", "/api/admin/feed-alert-routes",
                        {"scope": "feed_group", "scope_id": grp["id"], "channel": "email", "target": f"ops-{TAG}@uat.example"})
    check("P1 alert route at group scope", s in (200, 201), (s, str(route)[:200]))
    s, appr = uat.call("POST", "/api/feed-hold-approvers", {"scope": "feed", "scope_id": fid, "user_group_id": ug["id"]})
    check("P1 hold approver at feed scope", s in (200, 201), (s, str(appr)[:200]))
    s, tpl = uat.call("POST", "/api/feed-templates", {
        "name": names["tpl"], "parameters": ["ENTITY"],
        "feed": {"name": f"{names['tpl']}_{{ENTITY}}", "source_type": "sql_file", "source_id": sf["id"],
                 "connection_id": trino, "output_format": "csv", "output_filename_template": f"rel_tpl_{TAG}_{{ENTITY}}_{{business_date:YYYYMMDD}}.csv",
                 "destination_type": "sftp", "destination_config": dest, "execution_backend": "native",
                 "schedule_enabled": False, "calendar_name": names["cal"], "feed_group_id": grp["id"]},
        "dependencies": [{"dependency_type": names["dep"], "dependency_key": "{ENTITY}_EOM"}],
        "matrix": [{"ENTITY": "GB01"}, {"ENTITY": "DE01"}]})
    # POST /api/feed-templates creates AND applies (201 {"template", "report"}); a
    # second /apply would only report "unchanged" (the lead's rig run, 2026-10-17)
    created = tpl or {}
    tpl = created.get("template") or created
    check("P1 template created", s in (200, 201) and tpl.get("id"), (s, str(created)[:300]))
    ap_ = created if created.get("report") else uat.call(
        "POST", f"/api/feed-templates/{tpl['id']}/apply", {"background": False})[1]
    counts = ((ap_ or {}).get("report") or {}).get("counts") or {}
    check("P1 template applied in UAT: 2 members", counts.get("created") == 2, (s, counts))
    ex, err = uat.run_feed(fid)
    uat_file = f"rel_feed_{TAG}_{BD.replace('-', '')}.csv"
    uat_sha = sftp_sha(uat_file)
    check("P1 the UAT feed ran and delivered to SFTP", ex and ex.get("status") == "completed" and uat_sha,
          (err or ex, uat_file, uat_sha))

    # ── P2 / P3: export ──────────────────────────────────────────────────
    scope = {"kind": "feed_group", "keys": [names["grp"]], "with_dependencies": True}
    s, pkg = uat.call("POST", "/api/governance/release/export", {"scope": scope, "source_commit": f"proof-{TAG}"})
    if not check("P2 export answered a package", s == 200 and (pkg or {}).get("items"), (s, str(pkg)[:300])):
        return finish()
    got = {(i["kind"], i["key"]) for i in pkg["items"]}
    want = {("user_group", names["ops"]), ("calendar", names["cal"]), ("dependency_type", names["dep"]),
            ("control_file_format", names["ctl"]), ("sql_file", sf.get("file_path")), ("feed_group", names["grp"]),
            ("feed", names["feed"]), ("feed_template", names["tpl"]),
            ("restatement_policy", f"feed|{names['feed']}"), ("hold_approver", f"feed|{names['feed']}|{names['ops']}"),
            ("alert_route", f"feed_group|{names['grp']}|None|email|ops-{TAG}@uat.example")}
    check("P2 the closure is exactly the group, its feed, template, dependencies and attachments",
          got == want, {"missing": sorted(want - got), "extra": sorted(got - want)})
    check("P2 no template MEMBER travels (derived)", not any(k.startswith(names["tpl"] + "_") for _, k in got), sorted(got))
    sys.path.insert(0, os.path.join(ROOT, "backend"))
    from core.release.package import checksum as _checksum
    check("P2 checksum verifies", pkg["checksum"] == _checksum(pkg["items"]), pkg["checksum"])
    s, pkg2 = uat.call("POST", "/api/governance/release/export", {"scope": scope, "source_commit": f"proof-{TAG}"})
    check("P2 re-export is byte-identical (checksum)", pkg2 and pkg2["checksum"] == pkg["checksum"], (pkg["checksum"], (pkg2 or {}).get("checksum")))
    text = json.dumps(pkg)
    from core.feed.governance import find_secret_paths
    hits = {i["key"]: [p for p in find_secret_paths(i["definition"]) if not p.endswith("token_bindings")] for i in pkg["items"]}
    hits = {k: v for k, v in hits.items() if v}
    check("P3 no secret in the package: the SFTP password, no credential-shaped key",
          SFTP["password"] not in text and '"password"' not in text and not hits, {"hits": hits})
    feed_item = next(i for i in pkg["items"] if i["kind"] == "feed")
    check("P3 names not ids; the host/user/path/e-mail are environment fields apart from the definition",
          feed_item["definition"].get("connection") == "trino-rig" and "connection_id" not in feed_item["definition"]
          and set(feed_item["environment_fields"]) >= {"destination_config.host", "destination_config.username",
                                                        "destination_config.remote_dir", "notify_emails"},
          feed_item["environment_fields"])

    # ── P4 / P5: upload, preview, mapping ──────────────────────────────
    pconn_name = f"trino-prod-{TAG}"
    s, pconn = prod.call("POST", "/api/connections", {"name": pconn_name, "connection_type": "trino",
                                                      "config": {"host": "qs-trino", "port": 8080, "user": "rig",
                                                                 "http_scheme": "http", "catalog": "tpch"}})
    check("P4 PROD has its own connection", s in (200, 201), (s, str(pconn)[:200]))
    # NO ticket at upload: P6 proves an approval without one is refused (a ticket
    # given at upload is inherited by the approval -- that is the engine's rule, so
    # uploading WITH one made the refusal check impossible; the lead's run 2026-10-17)
    s, rel = prod.call("POST", "/api/governance/release/upload", {"package": pkg})
    if not check("P4 upload accepted (state uploaded)", s in (200, 201) and (rel or {}).get("state") == "uploaded", (s, str(rel)[:300])):
        return finish()
    rid = rel["id"]
    s, pv = prod.call("POST", f"/api/governance/release/{rid}/preview")
    p = (pv or {}).get("preview") or {}
    needed = {(m["kind"], m["from_value"]) for m in p.get("mappings_needed") or []}
    check("P4 preview: every object new, NOT ready, names the unmapped connection / host / user / path / e-mail",
          s == 200 and p.get("ready") is False and p["counts"]["new"] == len(pkg["items"])
          and {("connection", "trino-rig"), ("sftp_host", SFTP["host"]), ("user", SFTP["username"]),
               ("path", SFTP["remote_dir"]), ("email", f"owner-{TAG}@uat.example")} <= needed,
          {"counts": p.get("counts"), "needed": sorted(needed)})
    by = {(e["kind"], e["key"]): e for e in p.get("items") or []}
    check("P4 the policy attached to the blocked feed is blocked BY it (cascade)",
          by.get(("restatement_policy", f"feed|{names['feed']}"), {}).get("blocked_by") == [["feed", names["feed"]]],
          by.get(("restatement_policy", f"feed|{names['feed']}"), {}).get("blocked_by"))
    mappings = [{"kind": "connection", "from_value": "trino-rig", "to_value": pconn_name},
                {"kind": "sftp_host", "from_value": SFTP["host"], "to_value": SFTP["host"]},
                {"kind": "user", "from_value": SFTP["username"], "to_value": SFTP["username"]},
                {"kind": "path", "from_value": SFTP["remote_dir"], "to_value": SFTP["remote_dir"]},
                {"kind": "email", "from_value": f"owner-{TAG}@uat.example", "to_value": f"owner-{TAG}@prod.example"},
                {"kind": "email", "from_value": f"team-{TAG}@uat.example", "to_value": f"team-{TAG}@prod.example"},
                {"kind": "email", "from_value": f"ops-{TAG}@uat.example", "to_value": f"ops-{TAG}@prod.example"},
                {"kind": "url", "from_value": "kafka.uat:9092", "to_value": "kafka.prod:9092"}]
    s, mp = prod.call("PUT", "/api/governance/release/mappings", {"mappings": mappings})
    check("P5 mappings stored in PROD", s == 200 and len((mp or {}).get("mappings") or []) >= len(mappings), (s, str(mp)[:200]))
    s, pv = prod.call("POST", f"/api/governance/release/{rid}/preview")
    p = (pv or {}).get("preview") or {}
    check("P5 preview ready: nothing blocked, nothing undecided", s == 200 and p.get("ready") is True, p.get("counts"))

    # ── P6: approve + apply ─────────────────────────────────────────────
    s, b = prod.call("POST", f"/api/governance/release/{rid}/approve", {"ticket": f"REL-{TAG}"})
    check("P6 the UPLOADER may not approve in PROD (four-eyes refused)", s == 422 and "four-eyes" in str(b), (s, str(b)[:200]))
    s, b = approver.call("POST", f"/api/governance/release/{rid}/approve", {})
    check("P6 approving without a ticket is refused in PROD", s == 422 and "ticket" in str(b).lower(), (s, str(b)[:200]))
    s, b = approver.call("POST", f"/api/governance/release/{rid}/approve", {"ticket": f"REL-{TAG}"})
    check("P6 approved by a second admin with a ticket", s == 200 and (b or {}).get("state") == "approved", (s, str(b)[:200]))
    # in PROD an alert route's identity carries its MAPPED target (uat -> prod e-mail)
    want_prod = {(k, key.replace(f"ops-{TAG}@uat.example", f"ops-{TAG}@prod.example")) for k, key in want}
    s, ap1 = approver.call("POST", f"/api/governance/release/{rid}/apply", timeout=900)
    ledger = {(l["kind"], l["key"]): l["action"] for l in (ap1 or {}).get("ledger") or []}
    check("P6 applied: every object created, one ledger row each",
          s == 200 and (ap1 or {}).get("state") in ("applied", "verified", "applied_unverified")
          and set(ledger) == want_prod and set(ledger.values()) == {"created"}, (s, (ap1 or {}).get("state"), ledger))
    members = (ap1 or {}).get("members") or []
    mcounts = ((members[0].get("report") or {}).get("counts") if members else None) or {}
    check("P6 the template's 2 members were rendered in PROD", mcounts.get("created") == 2, members)
    v = (ap1 or {}).get("verification") or {}
    check("P6 verification ran and says what it could not prove", v.get("state") in ("ok", "unknown", "failed")
          and (v.get("counts") or {}).get("failed", 0) == 0, v.get("counts"))
    pfeed = prod.feed_by_name(names["feed"])
    check("P6 PROD feed carries the MAPPED connection and destination, and no password from UAT",
          pfeed and pfeed.get("connection_id") == pconn["id"] and (pfeed.get("destination_config") or {}).get("host") == SFTP["host"]
          and pfeed.get("notify_emails") == f"owner-{TAG}@prod.example"
          and (pfeed.get("destination_config") or {}).get("password") in (None, ""),
          {k: pfeed.get(k) for k in ("connection_id", "destination_config", "notify_emails")} if pfeed else pfeed)

    # ── P7: the feed runs in PROD, identical file ───────────────────────
    # The destination has no password in PROD (never carried): give PROD its own
    # credential the way an operator would, then run.
    s, b = prod.call("PUT", f"/api/feeds/{pfeed['id']}", {"destination_config": dict(dest)})
    check("P7 PROD's own SFTP credential set on the feed (environment data, by hand)", s == 200, (s, str(b)[:200]))
    ex, err = prod.run_feed(pfeed["id"])
    prod_sha = sftp_sha(uat_file)
    check("P7 the PROD feed ran and the delivered file is byte-identical to UAT's",
          ex and ex.get("status") == "completed" and prod_sha == uat_sha, (err or (ex or {}).get("status"), uat_sha, prod_sha))

    # ── P8: one field ───────────────────────────────────────────────────
    s, b = uat.call("PUT", f"/api/feeds/{fid}", {"output_options": {"delimiter": "|"}})
    check("P8 one field changed in UAT", s == 200, (s, str(b)[:200]))
    s, pkg3 = uat.call("POST", "/api/governance/release/export", {"scope": scope, "source_commit": f"proof-{TAG}-2"})
    s, rel3 = prod.call("POST", "/api/governance/release/upload", {"package": pkg3, "ticket": f"REL-{TAG}"})
    s, pv3 = prod.call("POST", f"/api/governance/release/{rel3['id']}/preview")
    p3 = (pv3 or {}).get("preview") or {}
    fe = next((e for e in p3.get("items") or [] if e["kind"] == "feed"), {})
    check("P8 the preview shows exactly ONE changed object and ONE changed field",
          p3.get("counts", {}).get("changed") == 1 and p3["counts"].get("unchanged") == len(pkg3["items"]) - 1
          and [(f["path"], f["state"], f["theirs"], f["ours"]) for f in fe.get("fields") or []] == [("output_options.delimiter", "changed", ",", "|")],
          {"counts": p3.get("counts"), "fields": fe.get("fields")})

    # ── P9: a hand edit in PROD on another field is kept ──────────────────
    s, b = prod.call("PUT", f"/api/feeds/{pfeed['id']}", {"description": "break-glass edit in PROD"})
    s, pv3 = prod.call("POST", f"/api/governance/release/{rel3['id']}/preview")
    fe = next((e for e in ((pv3 or {}).get("preview") or {}).get("items") or [] if e["kind"] == "feed"), {})
    states = {(f["path"], f["state"]) for f in fe.get("fields") or []}
    check("P9 the hand edit shows as prod_edited beside the one changed field",
          states == {("output_options.delimiter", "changed"), ("description", "prod_edited")}, states)
    approver.call("POST", f"/api/governance/release/{rel3['id']}/approve", {"ticket": f"REL-{TAG}"})
    s, ap3 = approver.call("POST", f"/api/governance/release/{rel3['id']}/apply", timeout=900)
    pfeed = prod.feed_by_name(names["feed"])
    check("P9 applied: the delimiter moved, the hand edit is KEPT, the ledger says which field was kept",
          s == 200 and (pfeed.get("output_options") or {}).get("delimiter") == "|" and pfeed.get("description") == "break-glass edit in PROD"
          and next((l for l in (ap3 or {}).get("ledger") or [] if l["kind"] == "feed"), {}).get("kept_fields") == ["description"],
          {"output_options": pfeed.get("output_options"), "description": pfeed.get("description"), "ledger": (ap3 or {}).get("ledger")})

    # ── P10: a conflict needs a decision ───────────────────────────────
    s, b = prod.call("PUT", f"/api/feeds/{pfeed['id']}", {"output_options": {"delimiter": ";"}})
    s, b = uat.call("PUT", f"/api/feeds/{fid}", {"output_options": {"delimiter": "\t"}})
    s, pkg4 = uat.call("POST", "/api/governance/release/export", {"scope": scope, "source_commit": f"proof-{TAG}-3"})
    s, rel4 = prod.call("POST", "/api/governance/release/upload", {"package": pkg4, "ticket": f"REL-{TAG}"})
    s, pv4 = prod.call("POST", f"/api/governance/release/{rel4['id']}/preview")
    p4 = (pv4 or {}).get("preview") or {}
    fe = next((e for e in p4.get("items") or [] if e["kind"] == "feed"), {})
    check("P10 both sides moved the same field -> conflict, undecided, not ready",
          fe.get("state") == "conflict" and fe.get("undecided") == ["output_options.delimiter"] and p4.get("ready") is False,
          {"state": fe.get("state"), "undecided": fe.get("undecided")})
    approver.call("POST", f"/api/governance/release/{rel4['id']}/approve", {"ticket": f"REL-{TAG}"})
    s, b = approver.call("POST", f"/api/governance/release/{rel4['id']}/apply", timeout=900)
    check("P10 apply refused while the conflict is undecided", s == 422 and "undecided" in str(b), (s, str(b)[:200]))
    s, b = approver.call("PUT", f"/api/governance/release/{rel4['id']}/decisions",
                         {"decisions": {f"feed|{names['feed']}": {"output_options.delimiter": "take_release"}}})
    approver.call("POST", f"/api/governance/release/{rel4['id']}/approve", {"ticket": f"REL-{TAG}"})
    s, ap4 = approver.call("POST", f"/api/governance/release/{rel4['id']}/apply", timeout=900)
    pfeed = prod.feed_by_name(names["feed"])
    s2, shown = prod.call("GET", f"/api/governance/release/{rel4['id']}")
    check("P10 decided take_release: applied, PROD carries the release's value, the decision is recorded",
          s == 200 and (pfeed.get("output_options") or {}).get("delimiter") == "\t"
          and (shown or {}).get("decisions") == {f"feed|{names['feed']}": {"output_options.delimiter": "take_release"}},
          {"delimiter": (pfeed.get("output_options") or {}).get("delimiter"), "decisions": (shown or {}).get("decisions")})

    # ── P11: rollback ──────────────────────────────────────────────────
    s, rb = approver.call("POST", f"/api/governance/release/{rel4['id']}/rollback", timeout=900)
    pfeed = prod.feed_by_name(names["feed"])
    s2, old = prod.call("GET", f"/api/governance/release/{rel4['id']}")
    check("P11 rollback: PROD returns to the snapshot (delimiter ';'), the release is rolled_back, the rollback names it",
          s == 200 and (pfeed.get("output_options") or {}).get("delimiter") == ";" and (old or {}).get("state") == "rolled_back"
          and (rb or {}).get("rollback_of") == rel4["id"], {"delimiter": (pfeed.get("output_options") or {}).get("delimiter"),
                                                               "state": (old or {}).get("state"), "rb": (rb or {}).get("state")})

    # ── P12: audit ─────────────────────────────────────────────────────
    actions = psql("querystudio_prod", "select string_agg(distinct action, ',') from audit_log where action like 'release.%'")
    have = set((actions or "").split(","))
    check("P12 the PROD audit log holds upload, preview, approve, apply, decide, rollback",
          {"release.upload", "release.preview", "release.approve", "release.apply", "release.decide", "release.rollback"} <= have, sorted(have))
    uat_actions = psql("querystudio", "select count(*) from audit_log where action = 'release.export'")
    check("P12 the UAT audit log holds the exports", int(uat_actions or 0) >= 3, uat_actions)

    # ── P13: negatives ─────────────────────────────────────────────────
    from core.release.package import checksum as _ck
    bad = json.loads(json.dumps(pkg))
    bad["items"][0]["definition"]["password"] = "leaked"
    bad["checksum"] = _ck(bad["items"])
    s1, b1 = prod.call("POST", "/api/governance/release/upload", {"package": bad})
    alt = json.loads(json.dumps(pkg))
    alt["items"][0]["definition"]["description"] = "tampered"
    s2, b2 = prod.call("POST", "/api/governance/release/upload", {"package": alt})
    unk = json.loads(json.dumps(pkg))
    unk["items"][0]["kind"] = "size_class"
    unk["checksum"] = _ck(unk["items"])
    s3, b3 = prod.call("POST", "/api/governance/release/upload", {"package": unk})
    check("P13 an injected password, an altered checksum and an unknown kind are each refused on upload",
          s1 == 422 and "credential" in str(b1) and s2 == 422 and "checksum" in str(b2) and s3 == 422 and "unknown object type" in str(b3),
          {"password": (s1, str(b1)[:120]), "checksum": (s2, str(b2)[:120]), "kind": (s3, str(b3)[:120])})

    # ── P14: a realistically used UAT has stale objects -- every problem in ONE
    # answer, an explicit exclusion, the rest released ─────────────────────
    sq_id = psql("querystudio", f"insert into saved_queries (name, query_config, created_by, is_active) values "
                                f"('REL_STALE_Q_{TAG}', '{{\"raw_sql\": \"SELECT 1\", \"connection_id\": 999999}}', 'rig_admin', true) returning id").splitlines()[0].strip()   # psql -tA prints the INSERT tag after the id
    psql("querystudio", f"insert into published_views (slug, name, query_config, source_type, business_report_id, is_active) values "
                        f"('rel-stale-view-{TAG}', 'REL stale view {TAG}', '{{}}', 'business_report', 999999, true)")
    s, f_stale = uat.call("POST", "/api/feeds", {
        "name": f"REL_FEED_ON_STALE_{TAG}", "source_type": "saved_query", "source_id": int(sq_id), "connection_id": trino,
        "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
        "execution_backend": "native", "schedule_enabled": False, "feed_group_id": grp["id"]})
    check("P14 planted: a saved query on a connection that is gone, a feed reading it, a published view on a report that is gone",
          s == 200 and (f_stale or {}).get("id"), (s, str(f_stale)[:200]))
    psql("querystudio", f"update feed_configs set secondary_connection_id = 999999 where id = {fid}")
    s, plan = uat.call("POST", "/api/governance/release/export", {"scope": {"kind": "everything", "plan": True}})
    probs = {(p_["kind"], p_["key"]) for p_ in (plan or {}).get("problems") or []}
    stale_key = next((k for kd, k in probs if kd == "saved_query" and k.startswith(f"REL_STALE_Q_{TAG}")), None)
    check("P14 ONE plan of 'everything' names the stale saved query, the dangling feed AND the stale published view together",
          s == 200 and plan.get("plan") is True and stale_key and ("feed", names["feed"]) in probs
          and ("published_view", f"rel-stale-view-{TAG}") in probs,
          {"status": s, "problems": [p_ for p_ in (plan or {}).get("problems") or [] if TAG in str(p_)]})
    scope14 = {"kind": "feed_group", "keys": [names["grp"]]}
    s, refused = uat.call("POST", "/api/governance/release/export", {"scope": scope14, "source_commit": f"proof-{TAG}-4"})
    rprobs = {(p_["kind"], p_["key"]) for p_ in ((refused or {}).get("detail") or {}).get("problems") or []}
    check("P14 the export of the group is refused WHOLE with BOTH of its problems listed (not the first alone)",
          s == 422 and ("saved_query", stale_key) in rprobs and ("feed", names["feed"]) in rprobs, (s, sorted(rprobs)))
    exclude = [{"kind": "saved_query", "key": stale_key, "reason": "stale: its connection is gone"},
               {"kind": "feed", "key": f"REL_FEED_ON_STALE_{TAG}", "reason": "reads the stale query"},
               {"kind": "feed", "key": names["feed"], "reason": "dangling secondary connection"}]
    s, plan2 = uat.call("POST", "/api/governance/release/export", {"scope": dict(scope14, plan=True, exclude=exclude[:1])})
    dep_probs = [p_ for p_ in (plan2 or {}).get("problems") or [] if p_["key"] == f"REL_FEED_ON_STALE_{TAG}"]
    check("P14 excluding the stale query alone: the feed that reads it is refused WITH that reason (no silent hole)",
          dep_probs and "excluded" in dep_probs[0]["reason"], dep_probs)
    # the operator's loop (the lead's rig run, 2026-10-17): excluding the group's feed
    # makes its ATTACHMENTS (restatement policy, hold approver) refuse "depends on feed
    # ..., which is excluded" -- rightly, never an orphan in PROD.  The plan names them
    # all in ONE answer; the operator excludes them too, then exports.
    s, plan3 = uat.call("POST", "/api/governance/release/export", {"scope": dict(scope14, plan=True, exclude=exclude)})
    cascade = [p_ for p_ in (plan3 or {}).get("problems") or [] if "which is excluded" in p_.get("reason", "")]
    check("P14 the plan names, in ONE answer, every attachment of an excluded feed (policy, hold approver)",
          {p_["kind"] for p_ in cascade} >= {"restatement_policy", "hold_approver"}
          and len(cascade) == len((plan3 or {}).get("problems") or []), [(p_["kind"], p_["key"]) for p_ in cascade])
    exclude = exclude + [{"kind": p_["kind"], "key": p_["key"], "reason": "attached to an excluded feed"} for p_ in cascade]
    s, pkg14 = uat.call("POST", "/api/governance/release/export", {"scope": dict(scope14, exclude=exclude), "source_commit": f"proof-{TAG}-4"})
    check("P14 with the exclusions the export succeeds and the package RECORDS them with their reasons",
          s == 200 and {(e["kind"], e["key"]) for e in (pkg14 or {}).get("excluded") or []} == {(e["kind"], e["key"]) for e in exclude}
          and ("feed", names["feed"]) not in {(i["kind"], i["key"]) for i in (pkg14 or {}).get("items") or []},
          (s, (pkg14 or {}).get("excluded")))
    s, rel14 = prod.call("POST", "/api/governance/release/upload", {"package": pkg14, "ticket": f"REL-{TAG}"})
    s, pv14 = prod.call("POST", f"/api/governance/release/{rel14['id']}/preview")
    p14 = (pv14 or {}).get("preview") or {}
    check("P14 PROD's preview shows what was deliberately left out, and is ready",
          {(e["kind"], e["key"]) for e in p14.get("excluded") or []} == {(e["kind"], e["key"]) for e in exclude} and p14.get("ready") is True,
          {"excluded": p14.get("excluded"), "blocked": [(e["key"], e["missing"]) for e in p14.get("items") or [] if e["blocked"]]})
    approver.call("POST", f"/api/governance/release/{rel14['id']}/approve", {"ticket": f"REL-{TAG}"})
    s, ap14 = approver.call("POST", f"/api/governance/release/{rel14['id']}/apply", timeout=900)
    check("P14 the rest of the group is released; nothing excluded landed",
          s == 200 and (ap14 or {}).get("state") in ("applied", "verified", "applied_unverified")
          and not {l["key"] for l in (ap14 or {}).get("ledger") or []} & {names["feed"], f"REL_FEED_ON_STALE_{TAG}", stale_key},
          (s, (ap14 or {}).get("state"), [(l["kind"], l["key"], l["action"]) for l in (ap14 or {}).get("ledger") or []]))
    psql("querystudio", f"update feed_configs set secondary_connection_id = NULL where id = {fid}")

    if not args.keep:
        subprocess.run(["docker", "compose", "-f", "docker-compose.rig.yml", "-f",
                        "scripts/docker_proof/compose/config_release.override.yml", "stop", "prod-api"],
                       capture_output=True, env=DENV, cwd=ROOT, timeout=300)
    return finish()


def finish():
    n, ok = len(res), sum(res)
    print(f"\n{ok}/{n} checks passed", flush=True)
    out = os.path.join(HERE, "config-release-results.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"tag": TAG, "passed": ok, "total": n, "at": time.strftime("%Y-%m-%dT%H:%M:%S")}, fh, indent=1)
    return 0 if ok == n and n else 1


if __name__ == "__main__":
    sys.exit(main())
