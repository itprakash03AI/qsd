"""A date column's filter values, picked and used -- live on Docker (2026-10-02).

Reported: "when clicked on saved datasets filter... what would be the values if
it's a business date".  The value list for a DATE column must (a) offer the
NEWEST dates first -- a business-date filter is almost always about recent
days, and the list is capped -- (b) say when it was cut, and (c) offer values
that, PICKED, filter on the source: a DATE spelled as a timestamp string is
refused by Trino.  Judged by value: the picked value's rows == the source's
own count for that day.  Runs on the login-OFF rig; cleans up.

    python date_lov_roundtrip.py [--cap 5]
"""
from __future__ import annotations

import argparse
import time
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)


CASES = [
    # (connection, base query, date column, key column, truth SQL template)
    (2, "select orderkey, orderdate, totalprice from tpch.tiny.orders", "orderdate", "totalprice",
     "select sum(totalprice) n from tpch.tiny.orders where orderdate = date '{d}'",
     "select cast(max(orderdate) as varchar) m, count(distinct orderdate) n from tpch.tiny.orders"),
    (1, "select id, dt, amt from trades", "dt", "amt",
     "select sum(amt) n from trades where dt = date '{d}'",
     "select cast(max(dt) as varchar) m, count(distinct dt) n from trades"),
]


def one(conn, base, dcol, kcol, truth_sql, top_sql, cap):
    tag = f"[conn {conn}]"
    s, ds, _ = c.call("POST", "/api/datasets", {
        "name": f"date_lov_proof_{conn}_{int(time.time())}", "subject": "proof", "connection_ids": [conn], "base_query": base})
    did = ds["id"]
    try:
        c.call("POST", f"/api/datasets/{did}/auto-detect", {})
        s, d, _ = c.call("GET", f"/api/datasets/{did}")
        cols = {x["physical_name"]: x for x in d["columns"]}
        od, key = cols[dcol], cols[kcol]
        check(f"{tag} {dcol} is typed a date", od["data_type"] == "date", od["data_type"])
        s, lov, _ = c.call("POST", f"/api/datasets/{did}/column-values",
                           {"column_id": od["id"], "parent_filters": [], "limit": cap})
        vals = (lov or {}).get("values") or []
        check(f"{tag} the value list answers", s == 200 and vals, (s, str(lov)[:200]))
        if not vals:
            return
        check(f"{tag} values are plain dates (YYYY-MM-DD)", all(len(str(v)) == 10 for v in vals), vals[:3])
        check(f"{tag} newest first", vals == sorted(vals, reverse=True), vals[:3])
        s, mx, _ = c.call("POST", "/api/datasets/preview", {"connection_id": conn, "limit": 1, "sql": top_sql})
        top, n = str(mx["rows"][0]["m"])[:10], int(mx["rows"][0]["n"])
        check(f"{tag} the first value is the source's latest date", str(vals[0]) == top, (vals[0], top))
        check(f"{tag} the list says whether it was cut ({n} distinct, cap {cap})",
              lov.get("truncated") is (n > cap), (lov.get("truncated"), n))
        picked = vals[0]
        s, run, _ = c.call("POST", f"/api/datasets/{did}/execute", {
            "column_ids": [key["id"]],
            "filters": [{"column_id": od["id"], "operator": "eq", "value": picked}]})
        got = None
        if s == 200 and run.get("execution_id"):
            _, page, _ = c.call("GET", f"/api/datasets/executions/{run['execution_id']}/results?offset=0&limit=10")
            rows = (page or {}).get("rows") or []
            got = round(float(list(rows[0].values())[0] if isinstance(rows[0], dict) else rows[0][0]), 2) if rows else None
        s2, tr, _ = c.call("POST", "/api/datasets/preview",
                           {"connection_id": conn, "limit": 1, "sql": truth_sql.format(d=str(picked)[:10])})
        if s2 != 200 or not (tr or {}).get("rows"):
            # Unknown is not empty: a truth we could not read fails the check
            # by name instead of crashing the run or comparing against 0.
            check(f"{tag} the source's own SUM for that day could be read", False,
                  (s2, (tr or {}).get("rows_unavailable") or str(tr)[:200]))
            return
        truth = round(float(tr["rows"][0]["n"] or 0), 2)
        check(f"{tag} the PICKED value filters: SUM == the source's own SUM for that day (non-zero)",
              s == 200 and got == truth and truth > 0, (s, got, truth, "" if s == 200 else str(run)[:200]))
    finally:
        c.call("DELETE", f"/api/datasets/{did}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cap", type=int, default=5)
    a = ap.parse_args()
    for case in CASES:
        one(*case, cap=a.cap)
    print()
    print(f"{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
