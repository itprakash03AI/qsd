"""A feed read BY PARTITION KEY, proven on the rig (2026-10-14).

The owner: "rather than running the full query we should partition the query
based on defined columns in config ... first pull the SAP_COMPANY_CODE values
for that query, then grouping and streaming back" -- and "it should not
return in a different order" without an ORDER BY that slows the query.

The owner's fact_tetb ON-PREM query (460 columns, no wrapper), on Starburst
(qs-trino-sb), month-end partition of the journey harness, as three feeds:

  WHOLE    one query (the behaviour before)
  KEY      backend_config.partition_config = SAP_COMPANY_CODE
  ORDERED  the same + order_within (the key, then SOURCE_DATA_ROW, unique)

Every file is checked INSIDE the scheduler container (a 460-column file is
~1.4 GB; it is not copied out): its row count against Starburst's own count
of the same SQL, distinct SOURCE_DATA_ROW == rows (no duplicate, none
missing), the key's rows contiguous (KEY / ORDERED), and its sha256 across
runs -- ORDERED must be byte-identical every run.  The plan (or why it ran
whole) is read from the execution record, files_metadata.partitioned_read.

    python partition_by_key_proof.py [--runs 3]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from tetb_real_e2e_proof import sb_cli                          # noqa: E402
import month_end_journey as mj                                  # noqa: E402

SB_CONNECTION = "starburst"          # the rig's Starburst-shaped connection type
KEY = "FACT_TETB.SAP_COMPANY_CODE"
ORDER = ["FACT_TETB.SAP_COMPANY_CODE", "FACT_TETB.SOURCE_DATA_ROW"]
FEEDS = {
    "PART_KEY_PROOF_WHOLE": None,
    "PART_KEY_PROOF_KEY": {"column": KEY, "max_buckets": 32, "max_concurrent": 2},
    "PART_KEY_PROOF_ORDERED": {"column": KEY, "max_buckets": 32, "max_concurrent": 2,
                               "order_within": ORDER},
}
RESULTS = {"checks": [], "runs": []}


def check(name, ok, detail=""):
    RESULTS["checks"].append({"check": name, "ok": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


def owner_sql() -> str:
    _, p_sql = mj.load_queries(mj.SPEC)
    p_sql = p_sql.replace(mj.SPEC["from_onprem"], mj.PREM_TABLE)
    return (p_sql.replace("{BUSINESSDATE}", mj.BD.isoformat())
                 .replace("{SYSTEM_ENTITY}", mj.ENTITY).replace("{EventCode}", mj.EVENT))


def ensure_prem_table() -> None:
    """The on-prem month-end table this proof reads, made when absent
    (2026-10-16).  The dev rig had it from month_end_journey ``prepare`` +
    ``volume``; a rig built from scratch answered "Table
    iceberg.qs.fact_tetb_month_end does not exist".  Only the ON-PREM table is
    made here -- ``prepare`` also DROPS and recreates the cloud table on AWS,
    whose location the aws-real registration (rig/aws_tables.json) names.
    Same DDL and the same generated VOLUME rows (400,000) as the journey."""
    if mj.PREM_TABLE.rsplit(".", 1)[1] in sb_cli("SHOW TABLES FROM iceberg.qs").replace('"', "").split():
        return
    t0 = time.time()
    _, _, _, p_raw = mj._sqls()
    _, p_types = mj.parse_query(p_raw, mj.SPEC["alias"])
    mj.cloud_cli(mj.ddl(mj.PREM_TABLE, p_types, hive=False) + ";\n", stdin=True)
    ver, n = mj.VOLUME["onprem"]
    chunk = max(10_000, mj.SEED_CELLS_PER_INSERT // max(1, len(p_types)))
    done = 0
    while done < n:
        k = min(chunk, n - done)
        mj.cloud_cli(mj._volume_sql(mj.PREM_TABLE, p_types, "onprem", ver, k, offset=done) + ";\n", stdin=True)
        done += k
    print(f"   made {mj.PREM_TABLE}: {n:,} rows, {len(p_types)} columns ({round(time.time() - t0)} s)", flush=True)


def sb_connection_id(r: Rig) -> int:
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    hit = [c for c in conns if c.get("connection_type") == SB_CONNECTION]
    if not hit:
        raise SystemExit("no Starburst connection on the rig")
    return int(sorted(hit, key=lambda c: c["id"])[0]["id"])


def ensure_feed(r: Rig, name: str, sql: str, conn_id: int, pc) -> int:
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": conn_id,
            "query_params": {"sql": sql}, "output_format": "csv", "destination_type": "local",
            "destination_config": {}, "execution_backend": "native", "is_active": True,
            "schedule_enabled": False,
            "output_filename_template": name + "_{business_date:YYYYMMDD}_{run_id}.csv",
            "description": "Proof: the owner's on-prem fact_tetb query read "
                           + ("whole" if not pc else "by SAP_COMPANY_CODE"),
            "backend_config": ({"partition_config": pc} if pc else None)}
    f = next((x for x in feeds if x["name"] == name), None)
    if f:
        s, b = r.call("PUT", f"/api/feeds/{f['id']}", body)
        assert s == 200, (s, str(b)[:300])
        return f["id"]
    s, b = r.call("POST", "/api/feeds", body)
    assert s in (200, 201), (s, str(b)[:300])
    return b["id"]


def run_once(r: Rig, fid: int, label: str) -> dict:
    """One run of the feed for the month end: a backfill the first time, a
    re-run of that date afterwards.  Returns the finished execution row."""
    before = psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}")
    run = r.run_row(fid, mj.BD.isoformat())
    if run is None:
        s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {
            "start_date": mj.BD.isoformat(), "end_date": mj.BD.isoformat(), "deliver": True,
            "reason": f"partition-by-key proof ({label})"})
        assert s in (200, 201, 202), (s, str(b)[:300])
    else:
        s, b = r.call("POST", f"/api/feed-runs/{run['id']}/rerun",
                      {"reason": f"partition-by-key proof ({label})"})
        assert s in (200, 201, 202), (s, str(b)[:300])
    t0 = time.time()
    while time.time() - t0 < 3600:
        row = psql(f"select id, execution_id, status, coalesce(total_rows,0) from feed_executions "
                   f"where feed_config_id={fid} and id>{before} order by id desc limit 1")
        if row and row.split("|")[2] in ("completed", "failed", "cancelled"):
            p = row.split("|")
            return {"id": int(p[0]), "execution_id": p[1], "status": p[2], "rows": int(p[3]),
                    "seconds": round(time.time() - t0, 1)}
        time.sleep(10)
    raise SystemExit(f"{label}: no finished execution within an hour")


INSPECT = r'''
import csv, hashlib, json, sys
path, key = sys.argv[1], sys.argv[2]
h = hashlib.sha256(); n = 0; ids = set(); runs = []; last = object()
with open(path, "rb") as fb:
    for chunk in iter(lambda: fb.read(1 << 20), b""):
        h.update(chunk)
csv.field_size_limit(1 << 30)
with open(path, newline="", encoding="utf-8-sig") as f:
    rd = csv.reader(f)
    head = [c.strip().upper() for c in next(rd)]
    ki, ri = head.index(key), head.index("SOURCE_DATA_ROW")
    for row in rd:
        n += 1
        ids.add(row[ri])
        if row[ki] != last:
            runs.append(row[ki]); last = row[ki]
print(json.dumps({"sha256": h.hexdigest(), "rows": n, "distinct": len(ids),
                  "key_values": len(set(runs)), "key_runs": len(runs)}))
'''


def inspect(execution_db_id: int) -> dict:
    fm = psql(f"select files_metadata from feed_executions where id={execution_db_id}")
    meta = json.loads(fm) if fm else {}
    # artifact_path = the file the run wrote, inside the worker container
    path = psql(f"select coalesce(artifact_path,'') from feed_executions where id={execution_db_id}")
    out = subprocess.run(["docker", "exec", "-i", "qs-local-scheduler", "python", "-", path,
                          "SAP_COMPANY_CODE"], input=INSPECT, capture_output=True, text=True,
                         timeout=1800)
    if out.returncode != 0:
        return {"error": (out.stderr or out.stdout)[-400:], "path": path}
    res = json.loads(out.stdout.strip().splitlines()[-1])
    res["partitioned_read"] = meta.get("partitioned_read")
    res["path"] = path
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--only", choices=sorted(FEEDS))
    a = ap.parse_args()
    r = Rig()
    ensure_prem_table()
    sql = owner_sql()
    truth = int(sb_cli("SELECT count(*) FROM (" + sql + ") t").strip().strip('"'))
    codes = int(sb_cli("SELECT count(DISTINCT SAP_COMPANY_CODE) FROM (" + sql + ") t").strip().strip('"'))
    check("Starburst's own count is non-zero", truth > 0, f"{truth:,} rows, {codes} codes")
    conn = sb_connection_id(r)
    for name, pc in FEEDS.items():
        if a.only and name != a.only:
            continue
        fid = ensure_feed(r, name, sql, conn, pc)
        # a run left pending by an interrupted proof is cancelled first (its
        # connection slot is released with it -- mixin_feeds.update_feed_run)
        for rid in psql(f"select id from feed_runs where feed_config_id={fid} "
                        f"and status='pending'").split():
            s, _ = r.call("POST", f"/api/feed-runs/{rid}/cancel", {"reason": "proof restart"})
            held = psql(f"select count(*) from connection_claims where run_kind='feed_run' "
                        f"and run_id={rid}")
            check(f"{name}: the interrupted run {rid} cancelled and holds no slot",
                  s == 200 and held == "0", f"cancel {s}, slots held {held}")
        shas = []
        for k in range(a.runs):
            ex = run_once(r, fid, f"{name} run {k + 1}")
            got = inspect(ex["id"]) if ex["status"] == "completed" else {}
            RESULTS["runs"].append({"feed": name, "run": k + 1, **ex, **got})
            print(json.dumps(RESULTS["runs"][-1], default=str)[:900], flush=True)
            check(f"{name} run {k + 1} completed", ex["status"] == "completed", ex["status"])
            if ex["status"] != "completed" or "error" in got:
                check(f"{name} run {k + 1} file readable", False, got.get("error", ""))
                continue
            check(f"{name} run {k + 1}: rows == Starburst", got["rows"] == truth,
                  f"{got['rows']:,} vs {truth:,}")
            check(f"{name} run {k + 1}: no duplicate, none missing",
                  got["distinct"] == got["rows"] == truth, f"distinct {got['distinct']:,}")
            pr = (got.get("partitioned_read") or {}).get("single") or {}
            if pc:
                check(f"{name} run {k + 1}: read by key", pr.get("mode") == "partition_values",
                      f"{pr.get('bucket_count')} parts, {pr.get('max_concurrent')} at a time, "
                      f"ledger {pr.get('ledger_verdict')}")
                if pc.get("order_within"):
                    check(f"{name} run {k + 1}: each code's rows together",
                          got["key_runs"] == got["key_values"] == codes,
                          f"{got['key_runs']} runs of {got['key_values']} codes")
            else:
                check(f"{name} run {k + 1}: read whole", not pr, json.dumps(pr)[:200])
            shas.append(got["sha256"])
        if pc and pc.get("order_within") and len(shas) >= 2:
            check(f"{name}: the SAME file every run (sha256)", len(set(shas)) == 1,
                  f"{len(set(shas))} distinct of {len(shas)}")
        elif len(shas) >= 2:
            print(f"INFO {name}: {len(set(shas))} distinct file hash(es) over {len(shas)} runs")
    out = os.path.join(HERE, "partition-by-key-results.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, indent=1, default=str)
    bad = [c for c in RESULTS["checks"] if not c["ok"]]
    print(f"\n{len(RESULTS['checks']) - len(bad)}/{len(RESULTS['checks'])} checks passed -> {out}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
