"""Docker proof: a published view whose source credentials cannot be OBTAINED
answers 503 + Retry-After with a caller-safe reason, and recovers by itself
once the secret store is reachable again.

2026-10-04.  Found live: with the published-API pod's Vault token missing, a
Snowflake view (System Account, key pair from Vault) answered 500 "Query
execution failed -- contact administrator".  Fixed in d0b320fa.

The rig: login ON, connection 239 = the real Snowflake account through System
Account 'snowflake-qs-svc' (Vault kv).  The proof REMOVES the published-API
container's Vault token and its encrypted credential cache, restarts it (so no
in-memory credential survives), asks for the view, then puts the token back
and asks again.  The token is always restored, even when a check fails.

    . ~/.qs_keys/rigpw.sh && python scripts/docker_proof/credentials_unavailable_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
PUB = "http://localhost:8003"
PV_C = "qs-local-published-api"
TOKEN = "/var/run/secrets/token/vault-token"
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
TAG = str(int(time.time()))[-6:]
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"{'PASS' if ok else 'FAIL'} {name} -- {detail}", flush=True)


def sh(*args):
    return subprocess.run(list(args), capture_output=True, text=True, env=DENV)


def get(path, key):
    req = urllib.request.Request(PUB + path, headers={"X-API-Key": key})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            return r.status, json.loads(r.read() or b"{}"), dict(r.headers)
    except urllib.error.HTTPError as e:
        body = e.read()
        try:
            body = json.loads(body)
        except Exception:  # noqa: BLE001
            pass
        return e.code, body, dict(e.headers)


def wait_healthy(timeout=180):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(PUB + "/health", timeout=5) as r:
                if r.status == 200:
                    return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(2)
    return False


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    undo = []
    saved = sh("docker", "exec", "-u", "0", PV_C, "cat", TOKEN).stdout
    if not saved.strip():
        print("the published-API container has no Vault token -- run rig_restore.sh first")
        return 2
    try:
        s, ds, _ = admin.call("POST", "/api/datasets", {
            "name": f"cred_{TAG}", "subject": "cred", "connection_ids": [CID],
            "base_query": "select REGION, count(*) as N from QS_DEMO.FIN.TRADES group by REGION"})
        undo.insert(0, f"/api/datasets/{ds['id']}")
        admin.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
        cols = admin.call("GET", f"/api/datasets/{ds['id']}")[1]["columns"]
        s, rep, _ = admin.call("POST", "/api/business-reports", {
            "name": f"cred-{TAG}", "dataset_id": ds["id"], "data_source_type": "dataset",
            "column_ids": [c["id"] for c in cols], "row_limit": 0})
        undo.insert(0, f"/api/business-reports/{rep['id']}")
        admin.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
        slug = f"cred-{TAG}"
        s, pv, _ = admin.call("POST", "/api/published-views", {
            "name": slug, "slug": slug, "source_type": "business_report",
            "business_report_id": rep["id"], "credential_mode": "publisher"})
        undo.insert(0, f"/api/published-views/{pv['id']}")
        _, k, _ = admin.call("POST", "/api/api-keys", {"name": f"cred-{TAG}", "scoped_view_ids": [pv["id"]]})
        undo.append(f"/api/api-keys/{k['id']}")
        key = k["raw_key"]
        path = f"/api/v1/views/{slug}/data?limit=100&cache=bypass"

        st, b, _ = get(path, key)
        truth = len((b or {}).get("data") or []) if isinstance(b, dict) else 0
        check("baseline: token present -> 200 with rows", st == 200 and truth > 0, {"status": st, "rows": truth})

        # ── take the credentials away ───────────────────────────────────────
        sh("docker", "exec", "-u", "0", PV_C, "rm", "-f", TOKEN, "/tmp/.qs_secrets.enc")
        sh("docker", "restart", PV_C)
        healthy = wait_healthy()
        gone = sh("docker", "exec", "-u", "0", PV_C, "sh", "-c", f"test -e {TOKEN} && echo present || echo absent").stdout.strip()
        check("setup: token and credential cache removed, pod healthy again", healthy and gone == "absent", {"healthy": healthy, "token": gone})

        st, b, hd = get(path, key)
        detail = (b or {}).get("detail", "") if isinstance(b, dict) else str(b)
        retry = hd.get("Retry-After") or hd.get("retry-after")
        check("no credentials -> 503 (not 500) with Retry-After", st == 503 and retry is not None, {"status": st, "retry_after": retry})
        check("the reason says what happened and what to do",
              "could not be obtained" in detail and "snowflake" in detail and "contact administrator" not in detail,
              {"detail": detail[:220]})
        leaks = [w for w in ("snowflake-qs-svc", "vault", "8200", "qs-snowflake", "secret/") if w in detail.lower()]
        check("the reason leaks no account, Vault path or role to the API consumer", not leaks, {"leaks": leaks})
    finally:
        # ── always put the credentials back ─────────────────────────────────
        tmp = os.path.join(os.environ.get("TEMP", "/tmp"), f"vt-{TAG}.jwt")
        with open(tmp, "w", newline="\n") as fh:
            fh.write(saved)
        sh("docker", "exec", "-u", "0", PV_C, "mkdir", "-p", os.path.dirname(TOKEN))
        sh("docker", "cp", tmp, f"{PV_C}:{TOKEN}")
        sh("docker", "exec", "-u", "0", PV_C, "chmod", "644", TOKEN)
        os.remove(tmp)
    try:
        st, b, _ = get(path, key)
        rows = len((b or {}).get("data") or []) if isinstance(b, dict) else 0
        check("token restored -> the SAME call recovers by itself: 200, same rows", st == 200 and rows == truth,
              {"status": st, "rows": rows, "truth": truth})
    finally:
        for u in undo:
            admin.call("DELETE", u)
    print(f"{sum(res)}/{len(res)} PASSED" if all(res) else f"{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
