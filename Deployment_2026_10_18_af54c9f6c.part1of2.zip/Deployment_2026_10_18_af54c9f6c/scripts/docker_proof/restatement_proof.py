"""RESTATEMENT + the ONE alert road + "apply from", live on the rig
(2026-10-12 night, the owner: "Kafka message will come on daily basis ... on
same day ... came multiple times then we have to hold rerun and raise alert to
RTB", "where is netcool/email alert", "if query changes ... applicable from",
"config should say everything").

Run the way production runs: a business calendar, SOD makes the month-end TASK,
the Kafka message releases it, the queue worker runs it, SFTP receives a file
named ``..._{business_date}_{run_date}.csv``.  Every behaviour below is a ROW
(a restatement policy mapped to the feed, the alert kinds, an e-mail route) set
through the admin routes -- nothing in code.

  R0  the policy row: a later run date re-runs, the SAME run date HOLDS, open
  C1  the message announces S1 -> delivered, the file == the S1 rows
  C2  the upstream re-sends (S2) the same run date -> a RE-RUN HOLD: the task
      is HELD on the board ("Re-run hold"), nothing re-ran, ONE alert with each
      channel's OUTCOME (bell sent, e-mail sent / failed with why, Netcool
      queued / refused with why)
  C3  an approver answers Re-run (ONE action) -> the S2 file, the decision
      resolved, the alert CLEARED, two deliveries of the date
  C4  "apply from" the business date: the feed's file name changes; the policy
      row now re-runs a same-day re-send -> S3 re-runs BY ITSELF with the NEW
      definition (the new file name), three deliveries
  C5  the window row closes the date (days=1, a past month end) -> S4 is
      recorded and alerted ("after close"), nothing re-runs

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/restatement_proof.py [--keep]
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import io
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, SFTP, TABLES, TOPIC, cloud_cli, ddl, drop_schema_cascade, insert_rows,
    load_queries, message, parse_query, produce_kafka, row_values,
)

TAG = str(int(time.time()))[-6:]
SPEC = TABLES["ext"]
DS = SPEC["data_source"]
ENT, EV = f"RS{TAG}", "EOD"
BD = dt.date(2026, 6, 30)            # a PAST month end (C5 closes it) nothing else uses
SNAPS = {k: int(f"{TAG}{k}") for k in (1, 2, 3, 4)}
COUNTS = {1: 3, 2: 5, 3: 4, 4: 2}
CLOUD_SCHEMA = f"iceberg_aws.rs_{TAG}"
CAL = f"RS_{TAG}"
NAME = f"RS_{TAG}_SAP_2920_ME"
FILE1 = f"sap_2920_{TAG}_{{business_date:YYYYMMDD}}_{{run_date:YYYYMMDD}}.csv"
FILE2 = f"sap_2920_{TAG}_v2_{{business_date:YYYYMMDD}}_{{run_date:YYYYMMDD}}.csv"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    r = Rig()
    cloud_id, _ = pick_cloud(r, "")
    c_tab = f"{CLOUD_SCHEMA}.fact_tetb_ext"
    c_sql, _ = load_queries(SPEC)
    c_sql = c_sql.replace(SPEC["from_cloud"], c_tab)
    _, c_types = parse_query(c_sql, SPEC["alias"])
    feed_sql = f"SELECT * FROM ({c_sql}) q WHERE q.snap_version = {{snapshot}}"
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    seq = [int(TAG) * 100]
    today = dt.datetime.now(dt.timezone.utc).date()

    def rows(snap, n):
        out = []
        for i in range(n):
            v = row_values("cloud", c_types, BD, ENT, EV, i)
            for k, c in enumerate(c_types):
                if c == "SNAP_VERSION":
                    v[k] = snap
                if c == "SOURCE_DATA_ROW":
                    v[k] = f"cloud:{snap}:{i}"
            out.append(v)
        return out

    def announce(k):
        seq[0] += 1
        produce_kafka([{**message(DS, ENT, EV, BD, True, "COMPLETE", COUNTS[k], seq[0]),
                        "SNAP_VERSION": str(SNAPS[k]), "VERSION_NUMBER": str(SNAPS[k])}])

    def task():
        s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={NAME}")
        ts = [x for g in (d or {}).get("groups") or [] for x in g["tasks"]]
        return ts[0] if ts else {}

    def wait(pred, timeout=600, every=5):
        t0 = time.time()
        while time.time() - t0 < timeout:
            got = pred()
            if got:
                return got
            time.sleep(every)
        return None

    def sftp_file(name):
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{name}"],
                              capture_output=True, text=True, env=DENV).stdout
        ledger.add("sftp file", name, remover=lambda n=name: (subprocess.run(
            ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{n}"], env=DENV).returncode == 0, "rm"))
        return collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                   for rec in csv.DictReader(io.StringIO(text.lstrip("﻿"))))

    def want(k):
        return collections.Counter(f"cloud:{SNAPS[k]}:{i}" for i in range(COUNTS[k]))

    def decisions(status=None):
        q = f"&status={status}" if status else "&status="
        s, d = r.call("GET", f"/api/feed-regeneration-decisions?business_date={BD.isoformat()}{q}&limit=50")
        return [x for x in (d or {}).get("decisions") or [] if x.get("feed_config_id") == fid]

    def put_policy(**p):
        s, b = r.call("PUT", "/api/admin/feed-restatement-policies",
                      {"scope": "feed", "scope_id": fid, "name": f"month end {TAG}", **p})
        return s, b

    def completed_count():
        t = task()
        return len(t.get("deliveries") or []), t

    try:
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/rs_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        cloud_cli(ddl(c_tab, c_types, hive=False) + ";\n", stdin=True)
        insert_rows(cloud_cli, c_tab, c_types, [x for k in SNAPS for x in rows(SNAPS[k], COUNTS[k])])
        print(f"== RESTATEMENT tag {TAG}: {BD} holds snapshots {SNAPS} ({COUNTS}); run date today = {today}")

        s, _ = r.call("POST", "/api/admin/feed-calendars", {"name": CAL, "weekend_days": [6, 7], "holidays": []})
        ledger.add("calendar", CAL, path=f"/api/admin/feed-calendars/{CAL}")
        s, q = r.call("POST", "/api/queries", {"name": f"rs_cloud_{TAG}",
                                               "query_config": {"files": [], "raw_sql": feed_sql, "connection_id": cloud_id}})
        ledger.add("saved query", f"rs_cloud_{TAG}", path=f"/api/queries/{(q or {}).get('id')}")
        s, feed = r.call("POST", "/api/feeds", {
            "name": NAME, "source_type": "saved_query", "source_id": q["id"], "connection_id": cloud_id,
            "output_format": "csv", "output_filename_template": FILE1,
            "query_params": {"SYSTEM_ENTITY": ENT, "EventCode": EV},
            "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "notify_emails": f"rtb.{TAG}@example.test",
            "schedule_declaration": {"kind": "month_end", "calendar_name": CAL}, "calendar_name": CAL,
            "execution_backend": "native"})
        if not check("P1 the month-end feed is created (file name carries business date AND run date)",
                     s == 200 and (feed or {}).get("id"), (s, str(feed)[:300])):
            return 1
        fid = feed["id"]
        ledger.add("feed", NAME, path=f"/api/feeds/{fid}")
        s, types = r.call("GET", "/api/feed-dependency-types")
        kafka_t = next(t["id"] for t in (types or {}).get("items") or [] if str(t.get("dependency_type")).upper() == "KAFKA")
        s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [
            {"dependency_type_id": kafka_t, "dependency_key": f"{DS}_{ENT}_{EV}_CLOUD",
             "arrival_sources": [{"kind": "kafka", "topic": TOPIC}], "require_mode": "any"}]})
        check("P2 its CLOUD dependency, met by the Kafka message", s == 200, (s, str(b)[:200]))

        s, pol = put_policy(on_new_message="rerun", same_run_date="hold", window="open")
        ledger.add("restatement policy", f"feed {fid}", path=f"/api/admin/feed-restatement-policies/{(pol or {}).get('id')}")
        check("R0 the policy is a ROW: later run date -> re-run, SAME run date -> HOLD, always open",
              s == 200 and (pol or {}).get("same_run_date") == "hold", (s, pol))

        # C1 -- SOD makes the task; S1 releases it
        s, b = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={BD.isoformat()}&feed_ids={fid}", timeout=600)
        t = wait(lambda: task() or None, 60, 3) or {}
        check(f"C1 SOD made the month-end task for {BD}", t.get("run_id") is not None, (s, str(b)[:200], t.get("status")))
        announce(1)
        t = wait(lambda: (lambda x: x if x.get("run_status") in ("completed", "failed") else None)(task()), 600) or {}
        f1 = (t.get("deliveries") or [{}])[0].get("file")
        check(f"C1 delivered; the file is named with the business date AND today's run date and == the S1 rows",
              t.get("run_status") == "completed" and f1 == FILE1.replace("{business_date:YYYYMMDD}", f"{BD:%Y%m%d}")
              .replace("{run_date:YYYYMMDD}", f"{today:%Y%m%d}") and sftp_file(f1) == want(1),
              {"status": t.get("run_status"), "file": f1, "reason": t.get("action_reason")})

        # C2 -- the upstream re-sends S2 the SAME run date: a RE-RUN HOLD
        announce(2)
        t = wait(lambda: (lambda x: x if x.get("status") == "held" else None)(task()), 180, 4) or {}
        rs = (t.get("superseded") or {}).get("restatement") or {}
        check("C2 the task is HELD on the board: 'Re-run hold', the run date said, nothing re-ran",
              t.get("status") == "held" and rs.get("action") == "hold" and rs.get("run_date") == today.isoformat()
              and len(t.get("deliveries") or []) == 1,
              {"status": t.get("status"), "restatement": rs, "deliveries": len(t.get("deliveries") or [])})
        alerts = wait(lambda: (lambda al: al if al and all(d.get("status") != "pending" for d in al[0]["deliveries"]) else None)(
            [x for x in (task().get("alerts") or []) if x["kind"] == "restatement_hold"]), 60, 3) or []
        ch = {d["channel"]: (d["status"], d.get("reason") or "", d.get("to") or d.get("identifier")) for d in (alerts[0]["deliveries"] if alerts else [])}
        print("   alert channels:", ch)
        check("C2 ONE alert, raised to RTB, each channel's OUTCOME on the record (never pending, never silent)",
              len(alerts) == 1 and alerts[0]["status"] == "open" and set(ch) == {"bell", "email", "netcool"}
              and ch["bell"][0] == "sent" and ch["email"][0] in ("sent", "failed")
              and (ch["email"][0] == "sent" or ch["email"][1]) and ch["netcool"][0] in ("queued", "refused")
              and f"rtb.{TAG}@example.test" in (ch["email"][2] or []),
              {"alerts": [(x["kind"], x["status"]) for x in alerts], "channels": ch})

        # C3 -- an approver answers Re-run: ONE action
        dec = decisions("open")
        s, b = r.call("POST", f"/api/feed-regeneration-decisions/{dec[-1]['id']}/answer",
                      {"action": "rerun", "reason": "upstream corrected the month end, re-send approved"})
        check("C3 the answer: re-run, by an authorised person, with the reason", s == 200, (s, str(b)[:300]))
        t = wait(lambda: (lambda x: x if len(x.get("deliveries") or []) >= 2 and x.get("run_status") == "completed" else None)(task()), 600) or {}
        f2 = (t.get("deliveries") or [{}])[0].get("file")
        al = [x for x in (t.get("alerts") or []) if x["kind"] == "restatement_hold"]
        check("C3 re-delivered: the S2 rows, two deliveries of the date, the hold's alert CLEARED, nothing open",
              t.get("run_status") == "completed" and sftp_file(f2) == want(2) and len(t["deliveries"]) == 2
              and al and al[0]["status"] == "cleared" and not decisions("open") and t.get("status") == "completed",
              {"status": t.get("status"), "deliveries": [(d["run_date"], d["rows"], d["trigger"]) for d in t.get("deliveries") or []],
               "alert": [(x["status"], x["cleared_by"]) for x in al], "open": len(decisions("open"))})

        # C4 -- "apply from" the business date + the policy re-runs a same-day re-send
        s, cur = r.call("GET", f"/api/feeds/{fid}")
        s, b = r.call("PUT", f"/api/feeds/{fid}?apply_from={BD.isoformat()}", {"output_filename_template": FILE2})
        s2, tl = r.call("GET", f"/api/feeds/{fid}/definition-timeline")
        check("C4 the change is saved to apply from the business date (the timeline says so)",
              s == 200 and (b or {}).get("definition_applies", {}).get("applies_from") == BD.isoformat()
              and len((tl or {}).get("timeline") or []) == 2, (s, (b or {}).get("definition_applies"), tl))
        s, _ = put_policy(on_new_message="rerun", same_run_date="rerun", window="open")
        announce(3)
        t = wait(lambda: (lambda x: x if len(x.get("deliveries") or []) >= 3 and x.get("run_status") == "completed" else None)(task()), 600) or {}
        d3 = (t.get("deliveries") or [{}])[0]
        check("C4 S3 re-ran BY ITSELF (policy row: re-run) with the NEW definition -- the v2 file name -- the S3 rows",
              d3.get("trigger") == "restatement" and "_v2_" in str(d3.get("file")) and sftp_file(d3["file"]) == want(3)
              and d3.get("definition_version_id") != (t["deliveries"][1] or {}).get("definition_version_id"),
              {"delivery": d3, "previous_version": (t.get("deliveries") or [{}, {}])[1].get("definition_version_id")})

        # C5 -- the window closes the date
        s, _ = put_policy(on_new_message="rerun", same_run_date="rerun", window="days", window_days=1)
        announce(4)
        t = wait(lambda: (lambda x: x if (x.get("superseded") or {}).get("restatement", {}).get("action") == "closed" else None)(task()), 180, 4) or {}
        al = [x for x in (t.get("alerts") or []) if x["kind"] == "restatement_closed"]
        check("C5 after the window: recorded + alerted ('after close'), held for a person, NOTHING re-ran",
              (t.get("superseded") or {}).get("restatement", {}).get("action") == "closed" and t.get("status") == "held"
              and len(t.get("deliveries") or []) == 3 and al and al[0]["status"] == "open",
              {"restatement": (t.get("superseded") or {}).get("restatement"), "deliveries": len(t.get("deliveries") or []),
               "alerts": [(x["kind"], x["status"]) for x in al]})
    finally:
        if a.keep:
            print(f"\n== KEPT (tag {TAG}): {NAME} on {BD} -- Feed Run Status, business date {BD}, search {NAME}")
        else:
            print("\n== cleanup")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
