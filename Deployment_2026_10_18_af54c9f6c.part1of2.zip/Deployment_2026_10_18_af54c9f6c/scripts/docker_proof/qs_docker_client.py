"""Full REPORTING sweep against the live Docker stack.

Every check asserts a NUMBER or a NAMED REFUSAL.  A 200 proves nothing; the
whole point of this session was that a well-formed wrong answer is the
dangerous case.  Truth is computed independently on the source through
/api/sql/execute (Trino -> Iceberg), never from the thing under test.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request

BASE = "http://localhost:8000"
# bqb_trades over iceberg.qs.trades.  13 / 41..51 are the DEV rig's ids; on any other
# rig (a fresh database numbers differently) _resolve_bqb() below replaces them BY NAME.
DS = 13
COL = {"id": 41, "trade_ts": 42, "book": 43, "ccy": 44, "amt": 45, "qty": 46,
       "counterparty": 47, "status": 48, "region": 49, "dt": 50, "desk": 51}

RESULTS: list[tuple[str, str, str]] = []
TAG = str(int(time.time()))[-6:]


#: Rig admin session for harnesses written for the login-OFF rig (2026-10-04).
#: On the login-ON rig every unauthenticated call answered 401, so a dozen
#: harnesses failed in 0 s without exercising anything.  When the rig admin's
#: password is in the environment (``. ~/.qs_keys/rigpw.sh``), a call that
#: carries NO credential of its own is sent as the rig admin.  A call that
#: passes its own Authorization / X-API-Key (Session, API-key consumers) is
#: untouched, as is an explicit ``headers={"Authorization": ""}`` (anonymous).
_ADMIN = {"token": None}


def _admin_token(refresh=False):
    pw = os.environ.get("QS_RIG_ADMIN_PW")
    if not pw or os.environ.get("QS_DOCKER_CLIENT_ANON"):
        return None
    if _ADMIN["token"] is None or refresh:
        s, b, _ = call("POST", "/auth/login",
                       {"username": os.environ.get("QS_RIG_ADMIN_USER", "rig_admin"), "password": pw},
                       headers={"Authorization": ""})
        _ADMIN["token"] = (b or {}).get("session_token") if s == 200 and isinstance(b, dict) else None
    return _ADMIN["token"]


def call(method, path, body=None, timeout=600, headers=None, raw=False):
    hdrs = dict(headers or {})
    own = {k.lower() for k in hdrs}
    if not path.startswith("/auth/") and not ({"authorization", "x-api-key"} & own):
        tok = _admin_token()
        if tok:
            hdrs["Authorization"] = f"Bearer {tok}"
            out = _raw_call(method, path, body, timeout, hdrs, raw)
            if out[0] == 401 and _admin_token(refresh=True):
                hdrs["Authorization"] = f"Bearer {_ADMIN['token']}"
                out = _raw_call(method, path, body, timeout, hdrs, raw)
            return out
    hdrs = {k: v for k, v in hdrs.items() if v != ""}
    return _raw_call(method, path, body, timeout, hdrs, raw)


def _raw_call(method, path, body, timeout, headers, raw):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body_bytes = r.read()
            if raw:
                return r.status, body_bytes, dict(r.headers)
            try:
                return r.status, json.loads(body_bytes), dict(r.headers)
            except Exception:
                return r.status, body_bytes[:400], dict(r.headers)
    except urllib.error.HTTPError as e:
        payload = e.read()
        try:
            return e.code, json.loads(payload), dict(e.headers)
        except Exception:
            return e.code, payload[:400].decode("utf-8", "replace"), dict(e.headers)
    except Exception as e:                                      # noqa: BLE001
        return -1, {"transport_error": f"{type(e).__name__}: {e}"}, {}


def record(name, ok, detail=""):
    RESULTS.append((name, "PASS" if ok else "FAIL", detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f"  -- {detail}" if detail else ""), flush=True)
    return ok


def truth(sql, limit=200):
    """Ground truth, computed on the SOURCE, through the product's SQL path."""
    s, b, _ = call("POST", "/api/sql/execute",
                   {"primary_connection_id": 2, "primary_sql": sql,
                    "row_limit": limit})
    if s != 200 or not isinstance(b, dict) or not b.get("execution_id"):
        raise RuntimeError(f"truth submit failed: {s} {str(b)[:200]}")
    eid = b["execution_id"]
    t0 = time.time()
    while time.time() - t0 < 300:
        _, st, _ = call("GET", f"/api/executions/{eid}/status")
        status = (st or {}).get("status")
        if status in ("completed", "success", "finished"):
            _, rb, _ = call("GET", f"/api/executions/{eid}/results?page_size={limit}")
            return rb.get("rows") or []
        if status in ("failed", "error", "cancelled"):
            raise RuntimeError(f"truth query failed: {(st or {}).get('error_message')}")
        time.sleep(0.4)
    raise RuntimeError("truth query timed out")


def rows_of(execution_id, page_size=2000):
    s, rb, _ = call("GET",
                    f"/api/executions/{execution_id}/results?page_size={page_size}")
    if s != 200:
        return [], []
    names = [c["name"] if isinstance(c, dict) else c
             for c in (rb.get("columns") or [])]
    out = [r if isinstance(r, dict) else dict(zip(names, r))
           for r in (rb.get("rows") or [])]
    return out, names


def br_rows(report_id, exec_id, page_size=2000):
    s, b, _ = call("GET", f"/api/business-reports/{report_id}/results/{exec_id}"
                          f"?page_size={page_size}")
    if s != 200:
        return [], s, b
    names = [c["name"] if isinstance(c, dict) else c
             for c in (b.get("columns") or [])]
    data = [r if isinstance(r, dict) else dict(zip(names, r))
            for r in (b.get("rows") or b.get("data") or [])]
    return data, s, b


def money(x):
    return f"{float(x):,.2f}"


def assert_serving_container(expected="qs-local-api"):
    r"""Refuse to run unless the thing answering BASE is the CONTAINER.

    2026-09-17 -- two leftover host processes were running
    ``backend\venv\Scripts\python.exe main.py``, and on Windows one of
    them held 0.0.0.0:8000 (IPv4) while Docker's relay held ::1 (IPv6).  So
    ``localhost`` reached the container and ``127.0.0.1`` reached the HOST --
    and "fixing" the harness by switching to 127.0.0.1 silently moved every
    test onto a different backend with a different config.  It showed up as a
    wall of 401s; it could just as easily have shown up as plausible numbers.

    A sweep that cannot say WHICH instance answered is not evidence.
    """
    import subprocess
    s, b, hdrs = call("GET", "/health/live")
    if s != 200:
        raise SystemExit(f"nothing healthy on {BASE}: HTTP {s}")
    rid = hdrs.get("x-request-id", "")
    try:
        r = subprocess.run(["docker", "logs", expected, "--since", "30s"],
                           capture_output=True, timeout=60)
        out = (r.stdout or b"").decode("utf-8", "replace") +               (r.stderr or b"").decode("utf-8", "replace")
    except Exception as exc:
        raise SystemExit(f"cannot read {expected}'s logs to confirm: {exc}")
    if rid and rid not in out:
        raise SystemExit(
            f"REFUSING TO RUN: {BASE} answered request-id {rid}, which does "
            f"NOT appear in {expected}'s logs -- something other than the "
            f"container is serving this port.")
    print(f"[rig] {BASE} is {expected} (correlated request-id {rid})")


def _resolve_bqb():
    """DS / COL for the dataset NAMED ``bqb_trades`` (2026-10-16).  The ids
    above were the dev rig's history: on a rig built from scratch
    (docker-compose.rig.yml, rig/seed_data.py creates bqb_trades) every proof
    importing them asked for "Dataset 13 not found".  Resolved once, by name;
    when the lookup cannot be made the old ids stay and that is SAID."""
    global DS, COL
    try:
        s, b, _ = call("GET", "/api/datasets?limit=1000", timeout=30)
        items = b if isinstance(b, list) else ((b or {}).get("items") or (b or {}).get("datasets") or [])
        ds = next((d for d in items if isinstance(d, dict) and d.get("name") == "bqb_trades"), None)
        if ds is None:
            print(f"[qs_docker_client] no dataset named bqb_trades (HTTP {s}) -- keeping ids {DS}", file=sys.stderr)
            return
        s, d, _ = call("GET", f"/api/datasets/{ds['id']}", timeout=30)
        cols = {str(x.get("physical_name") or "").lower(): x["id"] for x in (d or {}).get("columns") or []}
        missing = [k for k in COL if k not in cols]
        if missing:
            print(f"[qs_docker_client] bqb_trades lacks columns {missing} -- keeping ids {DS}", file=sys.stderr)
            return
        DS, COL = int(ds["id"]), {k: cols[k] for k in COL}
    except Exception as exc:  # noqa: BLE001 -- said, never silent
        print(f"[qs_docker_client] bqb_trades lookup failed ({exc}) -- keeping ids {DS}", file=sys.stderr)


_resolve_bqb()
