# Docker proof harnesses

Reproducible versions of the numbers this project quotes. They talk to the
**running containers** and refuse to run against anything else.

    cd scripts/docker_proof && python fd_proof.py

`fd_proof.py` exercises the FD-01..FD-10 report cases and prints a per-case
tally (31 assertions). Two of those assertions are the proof chain rather than
a feature:

* the response's `x-request-id` is correlated into `qs-local-api`'s own logs,
  so the answer provably came from the container and not a host process;
* a unique marker is planted as a filter VALUE, rendered verbatim into the
  generated SQL, and then found in `qs-trino`'s query history with the row
  count it scanned.

That matters because of a trap this rig has sprung before: `localhost` reached
the CONTAINER while `127.0.0.1` reached a leftover HOST process, and a suite
can pass beautifully against the wrong thing. `assert_serving_container()` in
`qs_docker_client.py` refuses to proceed unless the correlation succeeds.

These were kept in a scratchpad for two sessions, which meant the 31/31 figure
could be quoted but not re-run by anyone else. A number nobody can reproduce
is not evidence.

**Prerequisite:** the stack up, and the images rebuilt to HEAD. A container
older than the commit you are testing answers about the past.

## feed_board_truth_proof.py — Feed Run Status against SQL (2026-10-17)

Every value on the board (`GET /api/feed-dashboard`, every page) against the
database: the status word per task from the raw columns, the run id, the KPI
tiles, each group's whole-group counts, the step counts, the deliveries
(DELIVERED = `destination_path`), the SLA verdict from the same deadline rule,
`variance_held`, the feeds due with no task; by run date each daily /
month-end feed's business date derived from its calendar; roles (`--analyst`,
`--support`: sees but may not act, 403 on a re-run); the live board watch
(`--live-feed-id N --live-as u:p`: a socket as rig_admin hears another user's
Run Now); latency of both views.  The COUNT of values compared is asserted
and the truth must be non-zero.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/feed_board_truth_proof.py --business-date 2026-09-30

## capability_coverage.py — the audit that walks the other way

    docker cp scripts/docker_proof/capability_coverage.py qs-local-api:/tmp/cov.py
    docker exec qs-local-api python /tmp/cov.py

Every audit in this project walks INSTANCES: list the feeds, the reports, the
connections, drive what you find. **A capability with zero instances is
invisible to all of them** — and advertises itself as available the whole
time. The cross-source combine (FB-58) sat in that hole for over a month with
`cross_source=True` on every backend lane and not one feed using it.

This starts from the DECLARED vocabulary instead — read out of the shipped
registries, so it cannot drift from them — and asks which members nothing has
ever instantiated. First run, 2026-09-21: **23 across 7 vocabularies.**

`USED` means an instance exists, **not** that it works. This finds what no
audit can see; proving those work is the audit's job afterwards.

### ...and three of those seven were the WRONG registry (2026-09-21)

Reading a registry means you cannot drift from it. It does not mean you read
the right one, and being systematic about the wrong set still leaves the gap
open. Corrected, with the reason in the source:

| was | is | why it mattered |
|---|---|---|
| `core.file_formats` (8 READ adapters) compared with a feed's `output_format` | `core.feed.renderers` (4 renderers) | `get_renderer` raises on anything but parquet/csv/json/excel, so "6 unused formats" named five things a feed *cannot be* — and MISSED `excel`, which really had never rendered |
| an invented `report_type` of {tabular, pivot, raw_sql, parametric} | `core.reports.sources` (4 registered executors) | `report_type` is DERIVED as pivot-or-tabular, a binary that can never hold the other two. The real vocabulary had THREE unused members it could not see |
| file formats measured against feed output | measured against what a REGISTERED TABLE declares | two unrelated things |

Also: `auto` is the `execution_backend` column DEFAULT, so reading feed rows
alone reports it used the moment anyone saves a feed without choosing. USED
now means the ROUTER decided — its own `auto_route…` reason on an execution.

After the corrections and the exercise below: **9 unused**, all of them
declared with a reason.

## capability_exercise.py — the other half

    python scripts/docker_proof/capability_exercise.py            # all
    python scripts/docker_proof/capability_exercise.py auto formats

Makes an instance of every unused member that CAN run here and proves it end
to end. 66 checks, and the rule is the whole point: **never a row count.**
FB-58 closed on exactly that — 35 rows is also what the "both sides ran the
primary SQL" bug produces. So the proof is a value only the path under test
produces: the router's own `auto_route_large_spark_k8s(rows=5000000>threshold=500000)`,
a cell only that source has, a file PARSED by its own format's reader.

Suites: `auto formats saved_query landed_file api starburst reports dataflow
readers`. Exits non-zero on any failure, and treats an empty run as a failure
— a loop over nothing is vacuously true.

**A terminal STATUS is not a complete RECORD.** On spark_k8s the job's webhook
flips `status` to completed and the engine finishes its bookkeeping a second
or two later (watched against postgres: status t+18s, `backend_choice` t+20s).
`run_feed()` waits for the status and then for the record. Reading at the
transition made this harness report a missing routing decision as a product
defect — twice, before the row was watched.

## What a run leaves behind: nothing (2026-09-26)

GET /api/connections on the rig listed ~24 `cap-*-<runid>` connections from
repeated `capability_exercise.py` runs, plus the saved queries, reports,
views, local tables, feeds and delivered files those runs made. A person
opening the Connections screen saw test clutter. `proof_cleanup.py` now gives
every harness here a **ledger**: each object is recorded the moment its create
succeeds and removed in a `finally` — on success, on a failed check, on a
crash, on Ctrl-C — newest first, with one report line

    cleanup: N objects removed, M could not be (<what>: <reason>; ...)

and M > 0 exits non-zero. Per harness:

| harness | ledgered | "removed" means |
|---|---|---|
| `capability_exercise.py` | feeds, connections, builder + SQL saved queries, business reports, federation views, published views, the dataflow, local tables, the Oracle table the auto/large feed wrote, the files it placed in the container (landed csv, `/app/data/fvcap`, `dfcap_<tag>`, `/tmp/cap_reader.xlsx`) and every delivered feed file | DELETE; a dataflow has no DELETE, so `POST .../archive`; a published view's DELETE deactivates it (usage history kept, by design) |
| `fd_proof.py` | the hierarchy, the report, its duplicate | DELETE — and the cleanup is now a `finally` (it used to run only when every case got through) |
| `auth_rls_proof.py` | policies, bindings, reports, the published view | DELETE through the admin session; parked policies are re-enabled and the shared connection unshared as before |
| `fb59_acceptance.py` | the two feeds and the two Oracle tables they wrote | DELETE / `DROP TABLE ... PURGE` proven against `user_tables` |

Leftovers from runs BEFORE this (or a run killed before its `finally`):

    python scripts/docker_proof/<harness>.py --sweep-leftovers            # dry run, the default
    python scripts/docker_proof/<harness>.py --sweep-leftovers --execute  # delete

The matching rule is deliberately narrow and it is the whole of the rule: a
record is a candidate ONLY when its name matches one of that harness's own
name templates with the run-id shape (`\d{6}` — the last six digits of the
epoch second) in place of the tag, anchored at both ends. `cap-local-prod`,
`cap-local-12345`, `xcap-local-123456` never match; `cap-local-123456` does.
A kind whose listing cannot be read is reported and exits 2 — a sweep that
cannot see a kind must not call it clean.
`backend/tests/test_docker_proof_cleanup_2026_09_26.py` proves the ledger,
the dry-run gate and every rule by value, and fails when a harness grows a
new `f"..._{TAG}"` template with no rule.

## Kafka on the rig: `compose/kafka.override.yml` + `feed_dependencies_proof.py` (2026-10-08)

The base stack has no broker, so the feed-dependency Kafka consumer had never
run live and "a feed on several Kafka messages / several Iceberg tables" had
never been proven. The override adds a one-core Redpanda (`qs-kafka`, 512 MB,
dev-container mode) on the stack's network and gives api AND scheduler the
consumer block as ONE JSON env var (the config resolver is two levels deep;
the nested `..._ENABLED` spelling reaches nothing):

    . ~/.qs_keys/rigpw.sh
    docker compose -f docker-compose.local.yml \
                   -f scripts/docker_proof/compose/kafka.override.yml \
                   --profile workers up -d kafka api scheduler
    python scripts/docker_proof/feed_dependencies_proof.py [--only M1,K1]

The rules route two topics (`qs.dep.t1`, `qs.dep.t2`) to ONE dependency name,
`QS_KAFKA_MULTI`; the harness declares `{"kind": "kafka", "topic": ...}` per
topic. Cases: M1/M2 two real AWS Iceberg tables in one dependency (ALL / ANY),
M3 an Iceberg commit AND a file in the real bucket, K1/K2 two topics (ALL /
ANY), K3 a replayed message (exactly one run; the replay is a regeneration
decision), K4 the broker stopped (the hold reads "cannot be satisfied", then
clears by itself), K5 Kafka + Iceberg in one dependency. Every case proves the
hold NAMES the missing source before the release, and the delivered file
equals the source. One business date per case (the ledger is keyed by
dependency + date and `QS_KAFKA_MULTI` is a fixed name); sentinel rows
(`QSD`), ledger rows, inspections and landed messages are removed in `finally`.

## Keeping the class closed

`backend/tests/test_capability_vocabularies_are_covered_2026_09_21.py` fails
when a NEW declared member appears with no answer. Three answers, and they
lead to different places: EXERCISED naming a suite that must still exist,
UNREACHABLE with a dated sentence, or exempt because the CLASS declares an
external dependency by overriding `BaseStage.runnability()` — the override,
never the probe, because in a checkout `find_etl_root()` finds the sibling
`ETL/` and all 19 bridges probe runnable while in the image they do not.
