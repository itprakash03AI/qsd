"""Published API, reports, and EVERY connection's saved password -- on Docker (2026-10-02).

Asked: "make sure publish API and report works, and whatever connection is
selected the password doesn't get blanked -- works without entering passwords".
Judged by VALUE, never by a status code alone:

A. EVERY connection on the rig, the way the edit dialog uses it, without ever
   typing a secret:
     * the saved connection's own test  -> the reference verdict;
     * "Test" in the dialog: the MASKED config ("***") + connection_id
       -> must give the SAME verdict (the saved secret was used, not "***");
     * "Save" untouched -> same verdict, no credential_problems, and the
       DECRYPTED secret is byte-for-byte what it was (fingerprinted inside
       the API container -- the plaintext never leaves it);
     * clone -> the copy gives the same verdict.
B. A REPORT over Trino (region, SUM(amt)): run it, export CSV / Excel / PDF;
   the run and the CSV and the Excel all equal Trino's own totals.
C. The PUBLISHED API over that report and over a saved S3 query, called on
   the published tier (:8003) with the issued key: rows == the truth; a wrong
   key is refused.

Login-OFF rig.  Everything created is removed in a finally.

    python scripts/docker_proof/publish_report_connections_proof.py
"""
from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

PUB = "http://localhost:8003"
# bqb_trades over iceberg.qs.trades, resolved BY NAME by qs_docker_client (2026-10-16)
DS, COL = c.DS, {"region": c.COL["region"], "amt": c.COL["amt"]}
TAG = str(int(time.time()))[-6:]
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:260], flush=True)
    return bool(ok)


def call(m, p, b=None, **kw):
    s, body, _ = c.call(m, p, b, **kw)
    return s, body


def pub(path, key):
    saved = c.BASE
    c.BASE = PUB
    try:
        return c.call("GET", path, None, headers={"X-API-Key": key})[:2]
    finally:
        c.BASE = saved


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True, timeout=300, env=ENV)
    return [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]


def fingerprints():
    """sha256 of each connection's DECRYPTED secrets, computed INSIDE the API
    container from the stored rows -- the plaintext never leaves it."""
    code = r'''
import json, hashlib
from core.crypto import SENSITIVE_FIELDS, decrypt_value
from core.database import DatabaseManager
db = DatabaseManager()
out = {}
for conn in db.list_connections(active_only=True):
    stored = db.get_connection_stored_config(conn["id"]) or {}
    sec = {f: decrypt_value(stored[f]) for f in sorted(SENSITIVE_FIELDS) if stored.get(f)}
    out[conn["id"]] = hashlib.sha256(json.dumps(sec, sort_keys=True).encode()).hexdigest()[:16] if sec else None
print(json.dumps(out))
'''
    r = subprocess.run(["docker", "exec", "-i", "qs-local-api", "python", "-"], input=code,
                       capture_output=True, text=True, env=ENV)
    if r.returncode != 0:
        raise SystemExit(f"fingerprint failed: {r.stderr[-400:]}")
    return {int(k): v for k, v in json.loads(r.stdout.strip().splitlines()[-1]).items()}


def verdict(body):
    return bool((body or {}).get("success"))


def section_connections(undo):
    print("\n== A . every connection: test, save, clone -- never typing a secret")
    _, conns = call("GET", "/api/connections")
    before = fingerprints()
    for conn in conns:
        cid, name, ctype = conn["id"], conn["name"], conn["connection_type"]
        if ctype in ("upload", "local"):
            continue
        has_secret = any(v == "***" for v in (conn.get("config") or {}).values())
        _, ref = call("POST", f"/api/connections/{cid}/test")
        want = verdict(ref)
        _, g = call("GET", f"/api/connections/{cid}")
        masked = g["config"]
        _, dlg = call("POST", "/api/connections/test", {"connection_type": ctype, "config": masked,
                                                        "connection_id": cid})
        tag = f"[{cid} {ctype} {name}{'' if has_secret else ', no secret'}]"
        check(f"{tag} Test in the dialog (masked) == the saved test ({'connects' if want else 'fails as before'})",
              verdict(dlg) == want, {"saved": (ref or {}).get("message", "")[:80], "dialog": (dlg or {}).get("message", "")[:80]})
        s, _ = call("PUT", f"/api/connections/{cid}", {"name": g["name"], "connection_type": ctype,
                                                      "config": masked, "is_shared": g.get("is_shared")})
        _, after = call("POST", f"/api/connections/{cid}/test")
        _, g2 = call("GET", f"/api/connections/{cid}")
        check(f"{tag} Save untouched keeps it working", s == 200 and verdict(after) == want
              and not g2.get("credential_problems"), (s, (after or {}).get("message", "")[:80], g2.get("credential_problems")))
        s, cl = call("POST", f"/api/connections/{cid}/clone", {"name": f"pwproof-{cid}-{TAG}"})
        if ctype == "s3":
            # 2026-10-07 owner rule: one connection per S3 bucket -- a clone of
            # an S3 connection is refused, naming the connection that holds it.
            det = (cl or {}).get("detail") if isinstance(cl, dict) else None
            check(f"{tag} an S3 clone is REFUSED (one connection per bucket), naming the holder",
                  s == 409 and isinstance(det, dict) and det.get("code") == "duplicate_s3_bucket"
                  and str(cid) in str(det.get("message", "")), (s, str(cl)[:200]))
        elif s in (200, 201):
            undo.append(f"/api/connections/{cl['id']}")
            _, ct = call("POST", f"/api/connections/{cl['id']}/test")
            check(f"{tag} its clone works the same", verdict(ct) == want, (ct or {}).get("message", "")[:80])
        else:
            check(f"{tag} clone", False, (s, str(cl)[:160]))
    after = fingerprints()
    same = {k: before.get(k) == after.get(k) for k in before}
    check("every saved secret is byte-for-byte what it was (decrypted fingerprints)",
          before and all(same.values()) and any(v for v in before.values()),
          {k: ("same" if v else "CHANGED") for k, v in same.items()})


def section_report(undo, truth):
    print("\n== B . a report over Trino: run + exports == Trino")
    s, rep = call("POST", "/api/business-reports", {"name": f"prc-rep-{TAG}", "dataset_id": DS,
                                                    "data_source_type": "dataset",
                                                    "column_ids": [COL["region"], COL["amt"]]})
    if not check("the report is created", s == 200 and rep.get("id"), (s, str(rep)[:160])):
        return None
    rid = rep["id"]
    undo.append(f"/api/business-reports/{rid}")
    s, ex = call("POST", f"/api/business-reports/{rid}/execute", {"parameter_values": {}, "force_refresh": True})
    eid = (ex or {}).get("execution_id")
    _, rb = call("GET", f"/api/business-reports/{rid}/results/{eid}?page_size=100")
    names = [x["name"] if isinstance(x, dict) else x for x in (rb or {}).get("columns") or []]
    rows = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (rb or {}).get("rows") or []]
    got = {str(r["region"]): round(float(r["amt"]), 2) for r in rows}
    check("the run == Trino, region by region", got == truth and len(truth) > 1, {"got": got, "truth": truth})
    s, body, _ = c.call("GET", f"/api/business-reports/{rid}/download-csv", raw=True)
    text = bytes(body).decode("utf-8-sig") if isinstance(body, (bytes, bytearray)) else ""
    rdr = list(csv.reader(io.StringIO(text)))
    csv_got = {r[0]: round(float(r[1]), 2) for r in rdr[1:] if len(r) >= 2 and r[0]}
    check("the CSV export == Trino", s == 200 and csv_got == truth, {"http": s, "csv": csv_got})
    s, body, _ = c.call("GET", f"/api/business-reports/{rid}/download-excel", raw=True)
    xl_got = {}
    if s == 200 and isinstance(body, (bytes, bytearray)):
        import openpyxl
        ws = openpyxl.load_workbook(io.BytesIO(bytes(body)), read_only=True).worksheets[0]
        vals = [r for r in ws.iter_rows(values_only=True)]
        hdr = next(i for i, r in enumerate(vals) if r and any(str(x).lower() == "region" for x in r if x))
        h = [str(x).lower() if x else "" for x in vals[hdr]]
        ri, ai = h.index("region"), next(i for i, x in enumerate(h) if "amt" in x)
        xl_got = {str(r[ri]): round(float(r[ai]), 2) for r in vals[hdr + 1:] if r and r[ri] not in (None, "")}
    check("the Excel export == Trino", s == 200 and xl_got == truth, {"http": s, "xlsx": xl_got})
    s, body, _ = c.call("GET", f"/api/business-reports/{rid}/download-pdf", raw=True)
    # a failed call answers TEXT (an error dict / transport error), not bytes: say it, never crash
    head = body[:8] if isinstance(body, (bytes, bytearray)) else str(body)[:200]
    check("the PDF export is a PDF", s == 200 and isinstance(body, (bytes, bytearray)) and body[:4] == b"%PDF",
          {"http": s, "head": head})
    return rid


def section_published(undo, rid, truth):
    print("\n== C . the PUBLISHED API (tier :8003)")
    slug = f"prc-pv-{TAG}"
    # an UNPUBLISHED report is refused at creation (it used to be a 200 with
    # a key whose every call answered 410) -- for the API, embed and link
    for path, body in (("/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                  "business_report_id": rid, "credential_mode": "publisher"}),
                       (f"/api/business-reports/{rid}/embed-tokens", {}),
                       (f"/api/business-reports/{rid}/share", {})):
        s, b = call("POST", path, body)
        check(f"unpublished report: {path.split('/')[-1]} is refused with the fix",
              s == 409 and "Publish the report first" in str(b), (s, str(b)[:160]))
    s, _ = call("POST", f"/api/business-reports/{rid}/publish", {"action": "publish"})
    check("the report is published", s == 200, s)
    s, pv = call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                  "business_report_id": rid, "credential_mode": "publisher"})
    pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
    key = (pv or {}).get("test_api_key") or ""
    if not check("the report is published as an API with a key", s in (200, 201) and pid and key, (s, str(pv)[:200])):
        return
    undo.append(f"/api/published-views/{pid}")
    s, b = pub(f"/api/v1/views/{slug}/data?limit=100", key)
    rows = (b or {}).get("data") or (b or {}).get("rows") or []
    got = {str(r.get("region")): round(float(r.get("amt")), 2) for r in rows if isinstance(r, dict)}
    check("the published API over the report == Trino", s == 200 and got == truth, {"http": s, "got": got})
    s, _ = pub(f"/api/v1/views/{slug}/data?limit=5", "qs_wrong_key_" + TAG)
    check("a wrong key is refused", s in (401, 403), s)

    # a saved S3 query, published
    sql = "select region, round(sum(amt), 2) as amt from trades where dt = '2026-01-03' group by region"
    s, q = call("POST", "/api/queries", {"name": f"prc-q-{TAG}",
                                         "query_config": {"files": ["trades"], "raw_sql": sql, "connection_id": 1}})
    if not check("a saved S3 query", s in (200, 201) and q.get("id"), (s, str(q)[:160])):
        return
    undo.append(f"/api/queries/{q['id']}")
    _, tb = call("POST", "/api/datasets/preview", {"connection_id": 1, "sql": sql, "limit": 100})
    s3_truth = {str(r["region"]): round(float(r["amt"]), 2) for r in (tb or {}).get("rows") or []}
    slug2 = f"prc-pvq-{TAG}"
    s, pv2 = call("POST", "/api/published-views", {"name": slug2, "slug": slug2, "source_type": "saved_query",
                                                   "query_id": q["id"]})
    pid2 = (pv2 or {}).get("id") or ((pv2 or {}).get("view") or {}).get("id")
    key2 = (pv2 or {}).get("test_api_key") or ""
    if not check("the saved S3 query is published as an API", s in (200, 201) and pid2 and key2, (s, str(pv2)[:200])):
        return
    undo.append(f"/api/published-views/{pid2}")
    s, b = pub(f"/api/v1/views/{slug2}/data?limit=100", key2)
    rows = (b or {}).get("data") or (b or {}).get("rows") or []
    got = {str(r.get("region")): round(float(r.get("amt")), 2) for r in rows if isinstance(r, dict)}
    check("the published API over the S3 query == the source (non-empty)", s == 200 and got == s3_truth and s3_truth,
          {"http": s, "got": got, "truth": s3_truth})


def main():
    s, _ = call("GET", "/api/datasets")
    if s != 200:
        raise SystemExit(f"run on the login-OFF rig (anonymous /api/datasets answered {s})")
    truth = {r[0]: round(float(r[1]), 2) for r in
             trino("select region, cast(round(sum(amt), 2) as decimal(24,2)) from iceberg.qs.trades group by region")}
    undo = []
    try:
        section_connections(undo)
        rid = section_report(undo, truth)
        if rid:
            section_published(undo, rid, truth)
    finally:
        for p in reversed(undo):
            call("DELETE", p)
        print(f"\ncleanup: {len(undo)} objects removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
