"""A checksum of the file BEFORE compression, declared per feed, live on the
rig (2026-10-15).

The owner: "some extract creates MD5 or SHA checksum of file NOT on
compressed file".  Two twin feeds (Trino tpch.tiny.orders, 15,000 rows) are
created through the routes, both gzip with an ``.md5`` sidecar and a control
file, delivered by SFTP; one declares ``checksum_covers = uncompressed``, the
other leaves it (``sent``).  What the counterparty receives is read back from
the SFTP server and checked:

  K1  uncompressed: the .md5 sidecar holds md5(gunzip(file)) and names the
      .csv; the control file holds sha256(gunzip(file)); the .gz itself is
      the source's rows
  K2  sent (the default, every feed before): the .md5 holds md5(the .gz)
      and names the .gz; the control file sha256(the .gz)
  K3  both deliveries verified on the SENT bytes (the transfer check is
      unchanged by the term)

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/checksum_covers_proof.py
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, psql, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key  # noqa: E402
from tetb_real_e2e_proof import DENV, SFTP  # noqa: E402

TAG = str(int(time.time()))[-6:]
BD = "2026-10-15"
SQL = "SELECT orderkey, custkey, orderstatus, totalprice, orderdate FROM tpch.tiny.orders"


def sftp_bytes(name):
    r = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{name}"],
                       capture_output=True, env=DENV)
    return r.stdout if r.returncode == 0 else None


def run_feed(r, name, covers):
    opts = {"compression": "gzip", "checksum": "md5", "sidecar": "per_file"}
    if covers:
        opts["checksum_covers"] = covers
    s, f = r.call("POST", "/api/feeds", {
        "name": name, "source_type": "raw_sql", "source_id": 0,
        "connection_id": int(os.environ.get("QS_TRINO_CONN", "2")), "query_params": {"sql": SQL},
        "output_format": "csv", "output_options": opts,
        "output_filename_template": name.lower() + "_{business_date:YYYYMMDD}.csv",
        "control_file_template": name.lower() + "_{business_date:YYYYMMDD}.ctl",
        "destination_type": "sftp",
        "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                               "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                               "host_key_b64": sftp_host_key()},
        "execution_backend": "native", "schedule_enabled": False})
    if not check(f"{name}: created (gzip, md5 sidecar, control file, checksum_covers={covers or 'unset'})",
                 s == 200 and (f or {}).get("id"), (s, str(f)[:300])):
        return None
    fid = f["id"]
    r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": BD, "end_date": BD, "deliver": True,
                                                  "reason": "checksum_covers proof"})
    t0, row = time.time(), ""
    while time.time() - t0 < 900:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and business_date='{BD}' "
                   f"order by started_at desc nulls last limit 1")
        if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
            break
        time.sleep(5)
    r.call("PUT", f"/api/feeds/{fid}", {"is_active": False})
    eid, status = row.split("|") if row else ("", "none")
    _, ex = r.call("GET", f"/api/feed-executions/{eid}") if eid else (0, {})
    check(f"{name}: delivered", status == "completed", f"{status} {(ex or {}).get('error_message') or ''}")
    da = psql(f"select status, verification from delivery_attempts where feed_config_id={fid} "
              f"order by id desc limit 1")
    return {"fid": fid, "base": name.lower() + "_" + BD.replace("-", ""), "attempt": da}


def main():
    r = Rig()
    truth = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute",
                            f"SELECT count(*) FROM ({SQL})"], capture_output=True, text=True, env=DENV)
    n_truth = int(truth.stdout.strip())
    out = {}
    for covers, label in (("uncompressed", "K1"), (None, "K2")):
        name = f"CC_{TAG}_{(covers or 'sent').upper()}"
        got = run_feed(r, name, covers)
        if not got:
            continue
        gz, side, ctl = (sftp_bytes(f"{got['base']}.csv.gz"), sftp_bytes(f"{got['base']}.csv.gz.md5"),
                         sftp_bytes(f"{got['base']}.ctl"))
        check(f"{label} the .gz, its .md5 and the .ctl are ON the SFTP server",
              gz and side and ctl, {"gz": len(gz or b""), "md5": len(side or b""), "ctl": len(ctl or b"")})
        if not (gz and side and ctl):
            continue
        data = gzip.decompress(gz)
        rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig"))))
        check(f"{label} the file is the source: {n_truth:,} rows", len(rows) - 1 == n_truth > 0, len(rows) - 1)
        digest, named = side.decode().split()
        ctl_text = ctl.decode()
        if covers == "uncompressed":
            check("K1 the .md5 holds md5 of the UNCOMPRESSED file and names the .csv (md5sum -c after gunzip)",
                  digest == hashlib.md5(data).hexdigest() and named == f"{got['base']}.csv"
                  and digest != hashlib.md5(gz).hexdigest(), {"md5": digest, "names": named})
            check("K1 the control file holds sha256 of the UNCOMPRESSED file",
                  hashlib.sha256(data).hexdigest() in ctl_text and hashlib.sha256(gz).hexdigest() not in ctl_text,
                  ctl_text[:300])
        else:
            check("K2 unset = the behaviour before: the .md5 holds md5 of the .gz SENT and names it",
                  digest == hashlib.md5(gz).hexdigest() and named == f"{got['base']}.csv.gz", {"md5": digest, "names": named})
            check("K2 the control file holds sha256 of the .gz sent",
                  hashlib.sha256(gz).hexdigest() in ctl_text, ctl_text[:300])
        check(f"{label} K3 the transfer itself was verified on the sent bytes",
              (got["attempt"] or "").startswith("succeeded|verified"), got["attempt"])
        out[label] = got["base"]
    passed = sum(res)
    json.dump({"tag": TAG, "passed": passed, "total": len(res), "files": out},
              open(os.path.join(HERE, "checksum-covers-results.json"), "w"), indent=1)
    print(f"\n{passed}/{len(res)} checks passed")
    return 0 if passed == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
