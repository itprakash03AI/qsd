"""100 unpaced consumers for 30 s against a published view, run from INSIDE
the docker network (2026-10-04).  From Windows, Docker Desktop's port
forwarding resets ~1-20% of connections under this load (WinError 10054)
while the same load from inside the network gets 0 errors -- so the server is
judged from inside.  Usage (in a python:3.11 container on
querystudio-local-net): python _inner_load.py <base> <slug> <key1,key2,...>
"""
import json, os, sys, time, threading, collections, urllib.request, urllib.error, concurrent.futures as cf
base, slug, keys = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
codes = collections.Counter(); errs = collections.Counter(); lock = threading.Lock(); lat = []
stop = time.time() + 30
def hammer(i):
    while time.time() < stop:
        t0 = time.time()
        try:
            req = urllib.request.Request(f"{base}/api/v1/views/{slug}/data?limit=100&REGION={['EMEA','APAC','AMER','LATAM'][i%4]}", headers={"X-API-Key": keys[i % len(keys)]})
            with urllib.request.urlopen(req, timeout=120) as r: r.read(); c = r.status
        except urllib.error.HTTPError as e: c = e.code
        except Exception as e:
            c = -1
            with lock: errs[f"{type(e).__name__}: {str(e)[:80]}"] += 1
        with lock: codes[c] += 1; lat.append(time.time() - t0)
with cf.ThreadPoolExecutor(100) as ex: list(ex.map(hammer, range(100)))
lat.sort()
print(json.dumps({"codes": codes, "errors": errs, "ok_per_s": round(codes.get(200, 0) / 30, 1), "p50_ms": round(lat[len(lat)//2]*1000), "p99_ms": round(lat[int(len(lat)*.99)]*1000)}))
