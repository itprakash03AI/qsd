"""The published-API INVENTORY + DASHBOARD + ALERTS, live on the Docker rig
(2026-10-17; docs/PUBLISHED_API_INVENTORY_DASHBOARD_DESIGN_2026_10_17.html §9,
A1-A4 / B1-B8).  REAL: calls go through the published-api pod
(qs-local-published-api, http://127.0.0.1:8003) with two real API keys for two
consumers over a view that reads real parquet; every dashboard number is
compared to WHAT THIS HARNESS SENT and to api_access_log / the rollup rows
read by SQL (psql through docker exec qs-local-postgres); the broken-dependency
check deactivates the view's REAL source connection (its ``connections`` row --
no admin route flips ``is_active``; the row is what the inventory's dependency
resolver reads); the alert checks read the
Netcool stub and the bell table.  The COUNT of values compared is asserted and
every truth compared against is non-zero -- a loop over nothing is vacuously
true, and "ALL MATCH" over zero values has happened here twice.

  A1  the inventory lists the two views as published_view rows: lifecycle,
      health, endpoints, the two keys as consumers with their identity
  A2  the connection deactivated -> both APIs BROKEN naming it; the impact
      route names them with their consumers; ONE api_dependency_broken alert
      per API (bell row, Netcool event AlertGroup PUBLISHED_API); re-activated
      -> active again, alerts cleared, Netcool resolution with the raise's
      Identifier
  A3  lifecycle: deprecated with a sunset + successor -> the consumer's call
      carries Deprecation / Sunset / Link and the envelope's deprecation
      block; api_sunset_due raised once; retired -> 410 + X-QS-Refused:
      retired, the refusal a row in the call record
  A4  DELETE the connection is refused (409) naming both APIs and their
      consumers
  B1  the load: K1 and K2 call A and B through the published-api pod with a
      known mix incl. forced 4xx; what came back is the truth
  B2  the call record (SQL) == what was sent, per (API, consumer, status)
  B3  threshold error_rate > 3 % (global, min_calls 50): exactly ONE
      api_error_rate alert for A (B is clean); a second tick raises nothing
      new; 500 clean calls, one window later -> cleared, the Netcool
      resolution carries the raise's Identifier
  B4  the rollup rows (SQL) == the call record, and GET /metrics (by API,
      by consumer, one API) == both; one API's percentiles are EXACT and
      equal SQL's nearest-rank percentiles
  B5  /metrics/top names A busiest with the sent count
  B6  /idle lists the never-called view C and not A / B
  B7  /health: watermark ok, the daemon's ledger, ingest with 0 lost rows,
      the raw record at least what was sent
  B8  the CSV export carries both APIs and as many rows as the JSON total

    python scripts/docker_proof/published_api_inventory_proof.py
    (rig up; login ON or OFF -- the admin session comes from qs_docker_client;
     rig/run_tests.py published-api runs it)
"""
from __future__ import annotations

import csv
import io
import json
import math
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(__file__))
import pv_slot_proof as P  # noqa: E402  (http/call/check helpers on the API pod :8000)
from proof_cleanup import Ledger  # noqa: E402

PUB = os.environ.get("QS_PUBLISHED_API_URL", "http://127.0.0.1:8003")
NETCOOL = os.environ.get("QS_NETCOOL_STUB_URL", "http://127.0.0.1:9099")
MAILPIT = os.environ.get("QS_MAILPIT_URL", "http://127.0.0.1:8025")
TAG = str(int(time.time()))[-6:]
N_ROWS = 20_000
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")
COMPARED: list = []          # every (name, got, want) this run compared -- its COUNT is asserted


def psql(sql: str) -> str:
    r = subprocess.run(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
                        "-tAc", sql], capture_output=True, text=True, env=ENV)
    if r.returncode != 0:
        raise RuntimeError(f"psql failed: {r.stderr.strip()[:300]}")
    return r.stdout.strip()


def psql_rows(sql: str):
    out = psql(sql)
    return [ln.split("|") for ln in out.splitlines() if ln.strip()]


def cmp(name: str, got, want, *, allow_zero: bool = False) -> bool:
    """A compared value: recorded, and the TRUTH must be non-zero unless said."""
    COMPARED.append((name, got, want))
    if not allow_zero and (want in (0, None, "", [], {}) or want is False):
        return P.check(name, False, f"the truth to compare against is empty ({want!r}) -- the proof proves nothing here")
    return P.check(name, got == want, f"got {got!r}, sent/SQL {want!r}")


#: raw key -> {"limit", "window", "calls": {window_index: n}} -- the EFFECTIVE limit the
#: key's face states (core/published_api/rate_limits.py), read from GET /api/api-keys.
#: Every call through pub() is paced under it, in the limiter's own fixed, epoch-
#: aligned window, with one call of headroom (the window clock is the pod's).  The
#: second rig run fired 500 calls in 3 s against a 300/minute cap nobody could see.
PACER: Dict[str, dict] = {}


def pace(key: str) -> None:
    p = PACER.get(key)
    if not p:
        return
    while True:
        now = time.time()
        w = int(now // p["window"])
        n = p["calls"].get(w, 0)
        if n < p["limit"] - 1:
            p["calls"] = {w: n + 1}
            return
        time.sleep(max(0.05, (w + 1) * p["window"] - now + 0.25))


def pub(method, path, key, timeout=120):
    pace(key)
    req = urllib.request.Request(PUB + path, method=method, headers={"X-API-Key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw), {k.lower(): v for k, v in r.headers.items()}
            except ValueError:
                return r.status, raw, {k.lower(): v for k, v in r.headers.items()}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            b = json.loads(raw)
        except Exception:                                    # noqa: BLE001
            b = raw[:300]
        return e.code, b, {k.lower(): v for k, v in e.headers.items()}


def raw_get(path: str):
    """The API pod's answer as FULL bytes (P.http keeps 200 bytes of a non-JSON body)."""
    req = urllib.request.Request(P.API + path)
    try:
        import qs_docker_client as _c
        t = _c._admin_token()
        if t:
            req.add_header("Authorization", f"Bearer {t}")
    except Exception:                                        # noqa: BLE001 -- login-OFF rig
        pass
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.status, r.read()


def set_connection_active(cid: int, active: bool) -> None:
    """Flip the connection's active flag in the database -- the row the
    inventory's dependency resolver reads (there is no admin route for it)."""
    psql(f"UPDATE connections SET is_active = {'true' if active else 'false'} WHERE id = {int(cid)}")


def stub(method="GET", path="/events"):
    req = urllib.request.Request(NETCOOL + path, method=method)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read() or b"{}")


def run_now():
    """ONE rollup + alert tick in the owning process (the scheduler pod)."""
    s, b = P.call("POST", "/api/admin/background-jobs/published_api_rollup/run-now")
    if s != 200:
        raise RuntimeError(f"run-now answered {s}: {str(b)[:300]}")
    return b


def flush_and_roll():
    """The access-log batcher flushes within its interval; then the roll."""
    time.sleep(float(os.environ.get("QS_PROOF_FLUSH_WAIT", "6")))
    return run_now()


def wait_until(fn, *, seconds=90, every=3):
    deadline = time.time() + seconds
    last = None
    while time.time() < deadline:
        last = fn()
        if last:
            return last
        time.sleep(every)
    return last


def nearest_rank(values, p):
    vals = sorted(values)
    if not vals:
        return None
    k = max(1, math.ceil(len(vals) * p / 100.0)) - 1
    return float(vals[min(k, len(vals) - 1)])


def main() -> int:
    s, who = P.call("GET", "/api/auth/me")
    if s != 200:
        s, _ = P.call("GET", "/api/datasets")
        if s != 200:
            raise SystemExit(f"no admin session on the rig (/api/datasets answered {s}); set rig/rig.env")
    s, _, _, _ = P.http("GET", "/health/live")
    s2, _, _ = pub("GET", "/health/live", "")
    if s != 200 or s2 != 200:
        raise SystemExit(f"API pod {s} / published-api pod {s2} not live")
    stub("POST", "/reset")

    # a PREVIOUS run that died before its finally leaves pubapi* objects behind --
    # on the second rig run a leftover threshold would have fired beside this one.
    # Remove them by this harness's own name templates (anchored, run-id shaped).
    from proof_cleanup import Rule, sweep_leftovers
    rc = sweep_leftovers(lambda m, p, b=None, **k: P.call(m, p, b), [
        Rule("alert threshold", r"pubapi error rate \d{6}", list_path="/api/published-apis/alert-thresholds",
             delete_path="/api/published-apis/alert-thresholds/{id}"),
        Rule("api key", r"pubapi-k[12]-\d{6}", list_path="/api/api-keys", delete_path="/api/api-keys/{id}"),
        Rule("published view", r"PubAPI [ABC] \d{6}", list_path="/api/published-views",
             delete_path="/api/published-views/{id}"),
        Rule("saved query", r"pubapi_[abc]_\d{6}", list_path="/api/queries",
             delete_path="/api/queries/{id}?acknowledge_dependents=true"),
        Rule("connection", r"pubapi-\d{6}", list_path="/api/connections",
             delete_path="/api/connections/{id}?acknowledge_dependents=true"),
    ], execute=True, echo=lambda s: print("  " + s))
    P.check("leftovers of a previous run swept (every kind listed; every delete answered)", rc == 0, f"sweep rc={rc}")

    d = f"/app/data/pubapi_{TAG}"
    code = "\n".join([
        "import pyarrow as pa, pyarrow.parquet as pq, os",
        f"d='{d}'; os.makedirs(d, exist_ok=True); n={N_ROWS}",
        "regions=['EMEA','APAC','AMER','LATAM']",
        "pq.write_table(pa.table({'k': pa.array(range(n)), 'region': pa.array([regions[i%4] for i in range(n)]),"
        " 'amount': pa.array([float(i%997) for i in range(n)])}), d+'/orders.parquet')",
        "print('ok')"])
    r = subprocess.run(["docker", "exec", "-i", "qs-local-api", "python", "-c", code], capture_output=True, text=True, env=ENV)
    P.check(f"{N_ROWS:,} real rows written in the container", r.returncode == 0, (r.stdout or r.stderr)[-120:])

    ledger = Ledger(lambda m, p, b=None, **k: P.call(m, p, b))
    thr_id = None
    started = datetime.now(timezone.utc)
    try:
        # ── the estate: one connection, two saved queries, three views, two keys ──
        s, conn = P.call("POST", "/api/connections", {"name": f"pubapi-{TAG}", "connection_type": "local",
                                                      "config": {"base_path": d}})
        P.check("connection created", s == 200 and conn.get("id"), (s, str(conn)[:120]))
        cid = conn["id"]
        ledger.add("connection", cid, path=f"/api/connections/{cid}?acknowledge_dependents=true")
        slugs = {}
        for letter in ("a", "b", "c"):
            # the recipe pv_slot_proof proved: files + columns on the connection
            s, q = P.call("POST", "/api/queries", {"name": f"pubapi_{letter}_{TAG}", "query_config": {
                "files": ["orders.parquet"], "columns": ["k", "region", "amount"], "connection_id": cid}})
            P.check(f"saved query {letter} created", s in (200, 201) and (q or {}).get("id"), (s, str(q)[:120]))
            ledger.add(f"saved query {letter}", q["id"], path=f"/api/queries/{q['id']}?acknowledge_dependents=true")
            slug = f"pubapi-{letter}-{TAG}"
            s, pv = P.call("POST", "/api/published-views", {"slug": slug, "name": f"PubAPI {letter.upper()} {TAG}",
                           "source_type": "saved_query", "query_id": q["id"],
                           "allowed_filters": ["region"], "default_limit": 50, "max_limit": 500,
                           "cache_ttl_seconds": 0})
            pv = pv if isinstance(pv, dict) and pv.get("id") else ((pv or {}).get("view") or pv or {})
            P.check(f"view {letter} published", s in (200, 201) and pv.get("id"), (s, str(pv)[:160]))
            ledger.add(f"published view {letter}", slug, path=f"/api/published-views/{pv['id']}")
            slugs[letter] = (slug, pv["id"])
        A, B, C = slugs["a"], slugs["b"], slugs["c"]
        keys = {}
        for name, consumer, owner, mail in (("k1", "Risk Reporting", "risk_anna", f"risk-{TAG}@example.test"),
                                            ("k2", "Murex feed", "murex_ops", f"murex-{TAG}@example.test")):
            s, k = P.call("POST", "/api/api-keys", {"name": f"pubapi-{name}-{TAG}", "scoped_view_ids": [A[1], B[1], C[1]],
                          "rate_limit": "100000/minute", "consumer": consumer, "owner_username": owner,
                          "contact_email": mail})
            P.check(f"API key {name} created with its identity", s == 200 and k.get("raw_key") and k.get("id"),
                    (s, {x: k.get(x) for x in ("id", "consumer", "owner_username")} if isinstance(k, dict) else k))
            ledger.add(f"api key {name}", k["id"], path=f"/api/api-keys/{k['id']}")
            keys[name] = (k["raw_key"], k["id"], consumer)
        K1, K2 = keys["k1"], keys["k2"]
        # the limit each key is HELD to, from its face -- never the declared 100000/minute
        s, faces, _, _ = P.http("GET", "/api/api-keys")
        by_id = {k.get("id"): k for k in (faces if isinstance(faces, list) else [])}
        for name, (raw, kid, _c) in keys.items():
            face = by_id.get(kid) or {}
            det = face.get("effective_rate_limit_detail") or {}
            cmp(f"A1 key {name}'s face states the EFFECTIVE limit it is held to (declared {face.get('rate_limit')})",
                bool(det.get("limit")) and det.get("limit") <= 100000 and face.get("effective_rate_limit") == f"{det.get('limit')}/minute",
                True)
            cmp(f"A1 key {name} says WHY when the declared limit is capped",
                bool(face.get("rate_limit_cap_reason")) if face.get("rate_limit_capped") else True, True)
            PACER[raw] = {"limit": int(det.get("limit") or 60), "window": int(det.get("window_seconds") or 60), "calls": {}}
        print(f"  pacing: " + ", ".join(f"{n} at {PACER[r]['limit']}/{PACER[r]['window']}s" for n, (r, _k, _c) in keys.items()), flush=True)

        # ── A1: the inventory ─────────────────────────────────────────────
        s, inv, _, _ = P.http("GET", "/api/published-apis?q=pubapi-&page_size=500")
        items = {i["key"]: i for i in (inv.get("items") or [])} if isinstance(inv, dict) else {}
        P.check("A1 the inventory lists the three views as published_view rows", s == 200 and all(x[0] in items for x in (A, B, C)),
                (s, sorted(items)))
        a = items.get(A[0]) or {}
        cmp("A1 lifecycle of a fresh view is active (derived from its flag)", (a.get("lifecycle") or {}).get("status"), "active")
        cmp("A1 health of a view whose source stands is active", (a.get("health") or {}).get("state"), "active")
        cmp("A1 endpoints listed", len(a.get("endpoints") or []) > 0, True)
        cons = {c["id"]: c for c in (a.get("consumers") or [])}
        cmp("A1 both keys are consumers of A, with their identity",
            [(cons.get(f"apikey:{K1[1]}") or {}).get("consumer"), (cons.get(f"apikey:{K2[1]}") or {}).get("consumer")],
            ["Risk Reporting", "Murex feed"])
        cmp("A1 the source names the saved query", (a.get("source") or {}).get("kind"), "saved_query")
        cmp("A1 a never-called view has no last call and 0 calls", ((items.get(C[0]) or {}).get("last_call") or {}).get("at"), None, allow_zero=True)

        # ── B1: the load through the published-api pod ────────────────────
        sent: Counter = Counter()           # (slug, consumer identity, status) -> n
        latencies = {A[0]: [], B[0]: []}
        rows_served: Counter = Counter()
        regions = ["EMEA", "APAC", "AMER", "LATAM"]
        plan = ([(A, K1, "ok")] * 120 + [(A, K2, "ok")] * 60 + [(B, K2, "ok")] * 90 + [(B, K1, "ok")] * 30
                + [(A, K1, "bad")] * 12)      # 12 forced 4xx on A: 12 / 192 = 6.25 % > 3 %
        for i, (view, key, mode) in enumerate(plan):
            slug = view[0]
            path = (f"/api/v1/views/{slug}/data?limit=50&region={regions[i % 4]}" if mode == "ok"
                    else f"/api/v1/views/{slug}/data?limit=50&no_such_column={i}")
            st, body, hdr = pub("GET", path, key[0])
            sent[(slug, f"apikey:{key[1]}", st)] += 1
            if st == 200 and isinstance(body, dict):
                rows_served[(slug, f"apikey:{key[1]}")] += int(body.get("returned_rows") or len(body.get("data") or body.get("rows") or []))
        ok_calls = sum(n for (sl, c, st), n in sent.items() if st == 200)
        bad_calls = sum(n for (sl, c, st), n in sent.items() if 400 <= st < 500)
        P.check("B1 the load went through the published-api pod: 300 x 200, 12 x 4xx (forced)",
                ok_calls == 300 and bad_calls == 12, dict((f"{sl}/{c}/{st}", n) for (sl, c, st), n in sent.items()))
        if bad_calls != 12:
            raise SystemExit("the forced errors did not come back as 4xx -- the rest of the proof would compare the wrong truth")
        tick = flush_and_roll()
        P.check("B1 one rollup + alert tick ran (run-now in the owning process)", tick.get("status") in ("ran", "ok", "completed") or "rolled_through" in json.dumps(tick),
                str(tick)[:200])

        # ── B2: the call record == what was sent ──────────────────────────
        since = started.strftime("%Y-%m-%d %H:%M:%S")
        rec = psql_rows(f"SELECT api_slug, consumer, status_code, COUNT(*) FROM api_access_log "
                        f"WHERE api_slug IN ('{A[0]}','{B[0]}') AND created_at >= '{since}' GROUP BY 1,2,3 ORDER BY 1,2,3")
        got = {(r[0], r[1], int(r[2])): int(r[3]) for r in rec}
        cmp("B2 the call record has every (API, consumer, status) count this harness sent", got, dict(sent))
        n_pairs = len(sent)
        cmp("B2 pairs compared", n_pairs >= 5, True)
        rows_sql = psql_rows(f"SELECT api_slug, consumer, SUM(response_rows) FROM api_access_log WHERE api_slug IN ('{A[0]}','{B[0]}') "
                             f"AND status_code = 200 AND created_at >= '{since}' GROUP BY 1,2 ORDER BY 1,2")
        cmp("B2 rows served per (API, consumer) == the rows the responses carried",
            {(r[0], r[1]): int(r[2]) for r in rows_sql}, dict(rows_served))
        kinds = psql_rows(f"SELECT DISTINCT api_kind, auth_method FROM api_access_log WHERE api_slug IN ('{A[0]}','{B[0]}') AND created_at >= '{since}'")
        cmp("B2 every row names its kind and the auth method", sorted(tuple(r) for r in kinds), [("published_view", "api_key")])

        # ── B4: the rollup rows == the call record; the metrics route == both ──
        roll = psql_rows(f"SELECT api_slug, consumer, SUM(calls), SUM(ok_2xx), SUM(client_4xx), SUM(rows_sum) FROM published_api_call_rollups "
                         f"WHERE grain='hour' AND api_slug IN ('{A[0]}','{B[0]}') AND bucket_start >= '{since[:13]}:00:00' GROUP BY 1,2 ORDER BY 1,2")
        want_roll = {}
        for (sl, c, st), n in sent.items():
            w = want_roll.setdefault((sl, c), [0, 0, 0])
            w[0] += n
            if st == 200:
                w[1] += n
            elif 400 <= st < 500:
                w[2] += n
        cmp("B4 the hourly rollup rows == the call record per (API, consumer): calls / 2xx / 4xx",
            {(r[0], r[1]): [int(r[2]), int(r[3]), int(r[4])] for r in roll}, want_roll)
        cmp("B4 the rollup's rows_sum == the rows served", {(r[0], r[1]): int(r[5]) for r in roll}, dict(rows_served))
        frm = urllib.parse.quote((started - timedelta(hours=1)).isoformat())      # '+00:00' must not read as a space
        to = urllib.parse.quote((datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat())
        s, m, _, _ = P.http("GET", f"/api/published-apis/metrics?from={frm}&to={to}&grain=hour&group_by=api&kind=published_view")
        by_api = Counter()
        for c in (m.get("cells") or []) if isinstance(m, dict) else []:
            by_api[c["group"]] += int(c["calls"])
        want_api = Counter()
        for (sl, c, st), n in sent.items():
            want_api[f"published_view:{sl}"] += n
        cmp("B4 /metrics by API == what was sent per API (the dashboard's calls tile)", {k: by_api.get(k, 0) for k in want_api}, dict(want_api))
        s, mc, _, _ = P.http("GET", f"/api/published-apis/metrics?from={frm}&to={to}&grain=hour&group_by=consumer&kind=published_view")
        by_cons = Counter()
        for c in (mc.get("cells") or []):
            by_cons[c["group"]] += int(c["calls"])
        want_cons = Counter()
        for (sl, c, st), n in sent.items():
            want_cons[c] += n
        cmp("B4 /metrics by consumer == what each key sent", {k: by_cons.get(k, 0) for k in want_cons}, dict(want_cons))
        s, ma, _, _ = P.http("GET", f"/api/published-apis/metrics?from={frm}&to={to}&grain=hour&group_by=none&kind=published_view&api={A[0]}")
        tot = (ma or {}).get("totals") or {}
        a_calls = sum(n for (sl, c, st), n in sent.items() if sl == A[0])
        a_err = sum(n for (sl, c, st), n in sent.items() if sl == A[0] and 400 <= st < 600)
        cmp("B4 one API's totals: calls", tot.get("calls"), a_calls)
        cmp("B4 one API's totals: 4xx", tot.get("client_4xx"), a_err)
        cmp("B4 one API's error rate == 4xx / calls", round(float(tot.get("error_rate") or 0), 4), round(a_err / a_calls, 4))
        cmp("B4 one small API's percentiles are EXACT (the method is stated)", tot.get("method"), "exact")
        lat_sql = [int(r[0]) for r in psql_rows(f"SELECT response_ms FROM api_access_log WHERE api_slug='{A[0]}' AND created_at >= '{since}' AND response_ms IS NOT NULL")]
        cmp("B4 p50 == SQL's nearest-rank p50 over the same rows", (tot.get("p50") or {}).get("value_ms"), nearest_rank(lat_sql, 50))
        cmp("B4 p95 == SQL's nearest-rank p95", (tot.get("p95") or {}).get("value_ms"), nearest_rank(lat_sql, 95))
        cmp("B4 the watermark is on every answer", bool((ma or {}).get("watermark", {}).get("rolled_through")), True)

        # ── B5 / B6 / B7 / B8 ─────────────────────────────────────────────
        s, top, _, _ = P.http("GET", "/api/published-apis/metrics/top?window=24h&by=calls&n=50")
        top_a = next((x for x in (top.get("apis") or []) if x.get("api_slug") == A[0]), {})
        cmp("B5 /metrics/top names A with the sent count", top_a.get("calls"), a_calls)
        s, idle, _, _ = P.http("GET", "/api/published-apis/idle?days=1")
        idle_keys = {x["key"] for x in (idle.get("items") or [])}
        cmp("B6 /idle lists the never-called view C and neither A nor B (called within the day)",
            (C[0] in idle_keys, A[0] in idle_keys, B[0] in idle_keys), (True, False, False))
        s, h, _, _ = P.http("GET", "/api/published-apis/health")
        cmp("B7 /health: the rollup watermark is ok", (h.get("rollup") or {}).get("state"), "ok")
        # the verdict is the LIVE writers' (second rig run: 29 rows of processes
        # REPLACED with the containers were summed in); stale ones are listed
        cmp("B7 /health: no row lost by the LIVE writers", (h.get("ingest") or {}).get("rows_lost_write_failed"), 0, allow_zero=True)
        cmp("B7 /health: the verdict says which writers it judged", "reported within" in str((h.get("ingest") or {}).get("judged")), True)
        cmp("B7 /health: at least one writer reporting", ((h.get("ingest") or {}).get("writers_reporting") or 0) >= 1, True)
        cmp("B7 /health: the raw record holds at least what was sent", ((h.get("call_record") or {}).get("rows") or 0) >= sum(sent.values()), True)
        s, b_csv = raw_get("/api/published-apis?format=csv&q=pubapi-&page_size=500")
        text = b_csv.decode("utf-8-sig")
        rows_csv = list(csv.DictReader(io.StringIO(text)))
        cmp("B8 the CSV has as many rows as the JSON inventory for the same filter", len(rows_csv), len(items))
        cmp("B8 the CSV export carries the three APIs with their calls", {r.get("key"): int(r.get("calls_7d") or 0) for r in rows_csv if r.get("key") in (A[0], B[0], C[0])},
            {A[0]: a_calls, B[0]: sum(n for (sl, c, st), n in sent.items() if sl == B[0]), C[0]: 0})

        # ── B3: the threshold -> exactly ONE alert PER (API, threshold); recovery clears it ──
        # The seeded default "Error rate over 5 %" (threshold #1, active on every
        # rig) fires at 6.25 % too, legitimately: the rule is one alert per (API,
        # threshold), never "one per API" -- the second run's "two alerts" was two
        # thresholds, not one raised twice.  The proof's own threshold is judged by
        # its dedupe suffix; the rule is proven over every open alert.
        s, t = P.call("POST", "/api/published-apis/alert-thresholds", {
            "name": f"pubapi error rate {TAG}", "scope": "global", "api_kind": "", "scope_key": "", "metric": "error_rate",
            "operator": ">", "value": 3.0, "window_minutes": 1, "min_calls": 50, "clear_after_windows": 1,
            "alert_kind": "api_error_rate"})
        P.check("B3 threshold error_rate > 3 % created (window 1 min, clear after 1 healthy window)", s == 200 and t.get("id"), (s, str(t)[:200]))
        thr_id = t.get("id")
        ledger.add("alert threshold", thr_id, path=f"/api/published-apis/alert-thresholds/{thr_id}")   # a failed run removes it too
        suffix = f":threshold:{thr_id}"
        since_naive = started.replace(tzinfo=None).isoformat()

        def alerts_of(slug, status="all"):
            s_, body, _, _ = P.http("GET", f"/api/published-apis/alerts?status={status}&kind=published_view&api={slug}&limit=2000")
            return [x for x in ((body or {}).get("alerts") or []) if isinstance(x, dict)]

        def raised_this_run(rows):
            return [x for x in rows if str(x.get("raised_at") or "") >= since_naive]

        run_now()
        # the alert row is FOUND ONCE by its (API, threshold) dedupe suffix -- in any status,
        # so the check never depends on WHEN it is read -- and followed by its id from here
        a_all = raised_this_run(alerts_of(A[0]))
        mine = [x for x in a_all if x["kind"] == "api_error_rate" and str(x.get("dedupe_key") or "").endswith(suffix)]
        cmp("B3 exactly ONE alert for (A, the proof's threshold) at 6.25 % > 3 %", len(mine), 1)
        keys_run = [x.get("dedupe_key") for x in a_all]
        cmp("B3 no (API, threshold) pair was raised twice this run (every alert raised since the start has its own dedupe key)",
            len(keys_run) == len(set(keys_run)) and all(keys_run) and len(keys_run) >= 1, True)
        cmp("B3 none for B (0 %)", len([x for x in raised_this_run(alerts_of(B[0])) if x["kind"] == "api_error_rate"]), 0, allow_zero=True)
        alert = mine[0] if mine else {}
        aid = alert.get("id")
        chans = {d["channel"]: d for d in alert.get("deliveries", [])}
        cmp("B3 the bell was delivered to the API's owner", chans.get("bell", {}).get("status"), "sent")
        cmp("B3 the Netcool event was queued", chans.get("netcool", {}).get("status"), "queued")
        bell_rows = int(psql(f"SELECT COUNT(*) FROM notification_log WHERE event_type='feed_alert_api_error_rate' "
                             f"AND created_at >= '{since}' AND payload::text LIKE '%published_view:{A[0]}%'") or 0)
        cmp("B3 the bell row exists in notification_log", bell_rows >= 1, True)
        identifier = alert.get("netcool_identifier")
        cmp("B3 the alert row names its Netcool Identifier", bool(identifier), True)
        ev = wait_until(lambda: [e for e in (stub().get("events") or []) if isinstance(e, dict) and e.get("Type") == 1
                                 and e.get("Identifier") == identifier], seconds=90) if identifier else []
        cmp("B3 the Netcool stub received THAT event under AlertGroup PUBLISHED_API",
            len(ev or []) == 1 and (ev or [{}])[0].get("AlertGroup") == "PUBLISHED_API"
            and (ev or [{}])[0].get("AlertKey") == f"published_view:{A[0]}", True)
        run_now()
        again = raised_this_run(alerts_of(A[0]))
        cmp("B3 a second tick raises nothing new for (A, the proof's threshold): still the one row, by id",
            [x["id"] for x in again if str(x.get("dedupe_key") or "").endswith(suffix)], [aid])
        # recovery: 400 clean calls -> 12 / 592 = 2.0 % < 3 %, paced by pub() under the
        # EFFECTIVE limit the key's face states (the second run fired 500 in 3 s against
        # a 300/minute cap that no screen showed: 170 x 429, and the rate never fell).
        # A refused "clean" call is a finding, not a silent degradation.
        recovery: Counter = Counter()
        for i in range(400):
            st, _, _ = pub("GET", f"/api/v1/views/{A[0]}/data?limit=5&region={regions[i % 4]}", K1[0])
            sent[(A[0], f"apikey:{K1[1]}", st)] += 1
            recovery[st] += 1
        cmp("B3 every recovery call was served (paced under the key's EFFECTIVE limit: no 429)",
            dict(recovery), {200: 400})
        flush_and_roll()                                       # the first healthy window: the streak starts
        time.sleep(65)                                         # clear_after_windows (1) x window_minutes (1)
        flush_and_roll()
        row = next((x for x in alerts_of(A[0]) if x.get("id") == aid), {})
        cmp("B3 400 clean calls and one window later: THE alert row (by id) is cleared", row.get("status"), "cleared")
        cmp("B3 the cleared alert names who cleared it (the daemon)", row.get("cleared_by"), "published_api_rollup")
        cmp("B3 the cleared alert keeps its raise time and gains a clear time",
            bool(row.get("raised_at")) and bool(row.get("cleared_at")), True)
        res = wait_until(lambda: [e for e in (stub().get("events") or []) if isinstance(e, dict) and e.get("Type") == 2
                                  and e.get("Identifier") == identifier], seconds=90) if identifier else []
        cmp("B3 the Netcool RESOLUTION carries the raise's Identifier", len(res or []), 1)

        # ── A2: the real source connection deactivated ────────────────────
        set_connection_active(cid, False)
        P.check("A2 the view's source connection deactivated (its connections row, as the inventory reads it)",
                psql(f"SELECT is_active FROM connections WHERE id = {cid}") in ("f", "false", "0"), "flag read back")
        run_now()
        s, inv2, _, _ = P.http("GET", "/api/published-apis?q=pubapi-&page_size=500")
        it2 = {i["key"]: i for i in (inv2.get("items") or [])}
        cmp("A2 both APIs on it read BROKEN", tuple((it2.get(x[0]) or {}).get("health", {}).get("state") for x in (A, B)), ("broken", "broken"))
        cmp("A2 the reason names the connection", (it2.get(A[0]) or {}).get("health", {}).get("reasons"),
            [f"the connection it runs on (#{cid}) is inactive"])
        s, imp, _, _ = P.http("GET", f"/api/published-apis/impact?connection_id={cid}")
        dep_keys = sorted(x["key"] for x in (imp.get("dependents") or []))
        cmp("A2 the impact route names the three APIs", dep_keys, sorted([A[0], B[0], C[0]]))
        dep_a = next((x for x in (imp.get("dependents") or []) if x["key"] == A[0]), {})
        cmp("A2 the impact names A's consumers (both keys)", sorted(c["id"] for c in dep_a.get("consumers", []) if c["id"].startswith("apikey:") and c["id"] in (f"apikey:{K1[1]}", f"apikey:{K2[1]}")),
            sorted([f"apikey:{K1[1]}", f"apikey:{K2[1]}"]))
        s, ald, _, _ = P.http("GET", f"/api/published-apis/alerts?status=open&kind=published_view&api={A[0]}")
        dep_alerts = [x for x in (ald.get("alerts") or []) if x["kind"] == "api_dependency_broken"]
        cmp("A2 ONE api_dependency_broken alert for A", len(dep_alerts), 1)
        cmp("A2 its message is the inventory's sentence", (dep_alerts[0] if dep_alerts else {}).get("message"), f"the connection it runs on (#{cid}) is inactive")
        evd = wait_until(lambda: [e for e in (stub().get("events") or []) if isinstance(e, dict) and e.get("Type") == 1
                                  and e.get("AlertKey") == f"published_view:{A[0]}" and "DEPENDENCY" in str(e.get("Identifier", "")).upper()], seconds=90)
        cmp("A2 the Netcool event for the broken dependency arrived", len(evd or []), 1)
        run_now()
        s, ald2, _, _ = P.http("GET", f"/api/published-apis/alerts?status=open&kind=published_view&api={A[0]}")
        cmp("A2 a second tick does not raise it again", len([x for x in (ald2.get("alerts") or []) if x["kind"] == "api_dependency_broken"]), 1)
        set_connection_active(cid, True)
        run_now()
        s, inv3, _, _ = P.http("GET", "/api/published-apis?q=pubapi-&page_size=500")
        cmp("A2 re-activated: active again", {i["key"]: i["health"]["state"] for i in (inv3.get("items") or []) if i["key"] in (A[0], B[0])}, {A[0]: "active", B[0]: "active"})
        s, ald3, _, _ = P.http("GET", f"/api/published-apis/alerts?status=open&kind=published_view&api={A[0]}")
        cmp("A2 the dependency alert is cleared", len([x for x in (ald3.get("alerts") or []) if x["kind"] == "api_dependency_broken"]), 0, allow_zero=True)
        resd = wait_until(lambda: [e for e in (stub().get("events") or []) if isinstance(e, dict) and e.get("Type") == 2
                                   and e.get("Identifier") == (evd or [{}])[0].get("Identifier")], seconds=90)
        cmp("A2 the Netcool resolution carries the raise's Identifier", len(resd or []), 1)

        # ── A3: the lifecycle ─────────────────────────────────────────────
        sunset = (datetime.now(timezone.utc) + timedelta(days=2)).replace(microsecond=0)
        s, lc = P.call("PUT", f"/api/published-apis/published_view/{A[1]}/lifecycle",
                       {"status": "deprecated", "sunset_at": sunset.isoformat(), "successor": B[0], "deprecation_note": "use B"})
        P.check("A3 A deprecated with a sunset and a successor", s == 200 and (lc.get("lifecycle") or {}).get("status") == "deprecated", (s, str(lc)[:200]))
        st, body, hdr = pub("GET", f"/api/v1/views/{A[0]}/data?limit=5", K1[0])
        cmp("A3 a consumer's call still answers 200", st, 200)
        cmp("A3 ...with the Deprecation header", bool(hdr.get("deprecation")), True)
        cmp("A3 ...with the Sunset header", bool(hdr.get("sunset")), True)
        cmp("A3 ...with the Link successor-version header naming B", hdr.get("link"), f'</api/v1/views/{B[0]}>; rel="successor-version"')
        cmp("A3 ...and the envelope's deprecation block", ((body or {}).get("deprecation") or {}).get("successor") if isinstance(body, dict) else None, B[0])
        run_now()
        s, als, _, _ = P.http("GET", f"/api/published-apis/alerts?status=open&kind=published_view&api={A[0]}")
        cmp("A3 api_sunset_due raised once (sunset inside the notice period)", len([x for x in (als.get("alerts") or []) if x["kind"] == "api_sunset_due"]), 1)
        notified = (lc.get("notified") or {})
        told = set(notified.get("emails") or [])
        cmp("A3 the consumers were told at their contact addresses (both keys')",
            {f"risk-{TAG}@example.test", f"murex-{TAG}@example.test"} <= told, True)
        cmp("A3 ...and the mail was sent", notified.get("sent"), True)
        s, lc2 = P.call("PUT", f"/api/published-apis/published_view/{A[1]}/lifecycle", {"status": "retired", "successor": B[0]})
        P.check("A3 A retired", s == 200, (s, str(lc2)[:160]))
        st, body, hdr = pub("GET", f"/api/v1/views/{A[0]}/data?limit=5", K1[0])
        cmp("A3 a retired API answers 410 Gone with X-QS-Refused: retired", (st, hdr.get("x-qs-refused")), (410, "retired"))
        cmp("A3 ...naming the successor", B[0] in json.dumps(body), True)
        time.sleep(float(os.environ.get("QS_PROOF_FLUSH_WAIT", "6")))
        n410 = int(psql(f"SELECT COUNT(*) FROM api_access_log WHERE api_slug='{A[0]}' AND status_code=410 AND refusal='retired' AND created_at >= '{since}'") or 0)
        cmp("A3 the refusal is a row in the call record (status 410, refusal retired)", n410, 1)
        s, inv4, _, _ = P.http("GET", "/api/published-apis?q=pubapi-&page_size=500")
        cmp("A3 the inventory shows A retired", {i["key"]: i["lifecycle"]["status"] for i in (inv4.get("items") or []) if i["key"] == A[0]}, {A[0]: "retired"})

        # ── A4: the delete is refused naming the APIs ─────────────────────
        s, body, _, _ = P.http("DELETE", f"/api/connections/{cid}")
        cmp("A4 DELETE connection is refused (409) while APIs rest on it", s, 409)
        cmp("A4 ...naming the APIs and their consumers", all(x in json.dumps(body) for x in (B[0], C[0], "consumer")), True)
    finally:
        # the threshold is in the ledger (its delete clears the alerts it raised)
        _, left = ledger.cleanup(echo=lambda s: print("  " + s))
        subprocess.run(["docker", "exec", "qs-local-api", "rm", "-rf", d], env=ENV)
    n_cmp = len(COMPARED)
    P.check(f"the proof COMPARED {n_cmp} values (the count is asserted, not assumed)", n_cmp >= 45, n_cmp)
    # every phase was paced under the limit the keys' faces state: a 429 anywhere
    # means the face and the enforcement disagree (or the pacer does not pace)
    drew_429 = sum(n for (sl, c, st), n in sent.items() if st == 429)
    P.check("the proof drew NO 429 anywhere (every phase paced under the EFFECTIVE limit the key's face states)",
            drew_429 == 0, {"429s": drew_429, "pacing": {n: PACER[r]["limit"] for n, (r, _k, _c) in keys.items()} if PACER else "none"})
    print(f"\n{sum(P.res)}/{len(P.res)} PASSED -- {n_cmp} values compared against what was sent / SQL")
    return 0 if all(P.res) and not left else 1


if __name__ == "__main__":
    sys.exit(main())
