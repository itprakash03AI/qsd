"""Re-run ONLY the failed side -- LIVE on the rig (2026-10-12, the owner: "if
on-cloud completed with 40 million and on-prem fails, how will you rerun only
on-prem -- or rerun from start again?").

On the kept owner's month end (entity_groups_proof.py --keep), one
fact_tetb_ext feed (cloud AWS S3 UNION ALL on-prem Starburst):

  S1  the on-prem table is taken away; a full re-run FAILS -- on the ON-PREM
      side (failed_side = secondary), the CLOUD side's rows KEPT
  S2  the board says so: "Failed on ON-PREM", the offer = re-run ON-PREM only
  S3  the table is restored; POST rerun-failed-side -> the run COMPLETES,
      the execution records the CLOUD side as REUSED (not read again), the
      ON-PREM side read, certified against both messages
  S4  the SFTP file == cloud truth + on-prem truth BY VALUE

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/side_rerun_proof.py [--tag 809906] [--date 2026-12-31]
"""
from __future__ import annotations

import argparse
import collections
import csv
import io
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from tetb_real_e2e_proof import DENV, SFTP, TABLES, cloud_cli, load_queries, sb_cli  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="809906")
    ap.add_argument("--date", default="2026-12-31")
    ap.add_argument("--entity", default="2300_EMEA")
    a = ap.parse_args()
    r = Rig()
    ent = f"E{a.tag}_{a.entity}"
    name = f"{ent}_FINANCE_SL_BALANCE_EXT_EOD"
    prem = f"iceberg.qs.fact_tetb_ext_eg{a.tag}"
    s, d = r.call("GET", f"/api/feed-dashboard?business_date={a.date}&search={name}")
    tasks = [t for g in (d or {}).get("groups") or [] for t in g["tasks"] if t["feed_name"] == name]
    if not check(f"P0 the kept month end has {name}", len(tasks) == 1, s):
        return 2
    t = tasks[0]
    run_id, fid = t["run_id"], t["feed_id"]

    def wait_done(timeout=600):
        t0 = time.time()
        while time.time() - t0 < timeout:
            s, b = r.call("GET", f"/api/feed-runs?business_date={a.date}&limit=1000")
            row = next((x for x in (b or {}).get("items") or [] if x["id"] == run_id), None)
            if row and row["status"] in ("completed", "failed", "cancelled"):
                return row
            time.sleep(5)
        return None

    def execution():
        s, st = r.call("GET", f"/api/feed-runs/{run_id}/steps")
        eid = ((st or {}).get("execution") or {}).get("id")
        s, ex = r.call("GET", f"/api/feed-executions/{eid}")
        return ex or {}

    moved = False
    try:
        # S1 -- take the on-prem table away, re-run in full
        cloud_cli(f"ALTER TABLE {prem} RENAME TO {prem}_away")
        moved = True
        s, b = r.call("POST", f"/api/feed-runs/{run_id}/rerun")
        check("S1 a full re-run is queued", s == 200, (s, str(b)[:200]))
        row = wait_done()
        ex = execution()
        st = ex.get("stage_timings") or {}
        kept = st.get("kept_side") or {}
        check("S1 it FAILED on the ON-PREM side; the CLOUD side's rows were KEPT",
              row and row["status"] == "failed" and st.get("failed_side") == "secondary"
              and kept.get("side") == "primary" and (kept.get("rows") or 0) > 0,
              {"status": (row or {}).get("status"), "failed_side": st.get("failed_side"),
               "kept": {k: kept.get(k) for k in ("side", "rows")}, "error": str(ex.get("error_message"))[:200]})
        # S2 -- the board and the offer
        s, d = r.call("GET", f"/api/feed-dashboard?business_date={a.date}&search={name}")
        bt = [x for g in d["groups"] for x in g["tasks"]][0]
        check("S2 the board: Failed on ON-PREM, the offer = re-run ON-PREM only (reusing the cloud rows)",
              (bt.get("sides") or {}).get("failed_side") == "secondary"
              and (bt.get("side_rerun") or {}).get("ok") is True
              and bt["side_rerun"]["rerun_side"] == "secondary",
              {"sides.failed_side": (bt.get("sides") or {}).get("failed_side"), "offer": bt.get("side_rerun")})
        # S3 -- restore, re-run ONLY the failed side
        cloud_cli(f"ALTER TABLE {prem}_away RENAME TO {prem}")
        moved = False
        s, b = r.call("POST", f"/api/feed-runs/{run_id}/rerun-failed-side")
        check("S3 re-run ON-PREM only is queued", s == 200, (s, str(b)[:300]))
        row = wait_done()
        ex = execution()
        st = ex.get("stage_timings") or {}
        reused = st.get("reused_side") or {}
        cert = (st.get("reported_rows_certification") or {})
        check("S3 COMPLETED; the CLOUD side REUSED (not read again), on-prem read, both sides certified",
              row and row["status"] == "completed" and reused.get("side") == "primary"
              and reused.get("rows") == kept.get("rows") and cert.get("verdict") == "certified",
              {"status": (row or {}).get("status"), "reused": {k: reused.get(k) for k in ("side", "rows", "execution_id")},
               "certification": cert.get("verdict"), "refused": st.get("reuse_refused")})
        # S4 -- the file by value
        spec = TABLES["ext"]
        c_sql, p_sql = load_queries(spec)
        c_sql = c_sql.replace(spec["from_cloud"], f"iceberg_aws.eg_{a.tag}.fact_tetb_ext")
        p_sql = p_sql.replace(spec["from_onprem"], prem)

        def truth(sql, cli):
            sql = sql.replace("{BUSINESSDATE}", a.date).replace("{SYSTEM_ENTITY}", ent).replace("{EventCode}", "EOD")
            out = cli(f"SELECT source_data_row FROM ({sql}) q;\n", stdin=True)
            return collections.Counter(x.strip().strip('"') for x in out.splitlines() if x.strip())
        want = truth(c_sql, cloud_cli) + truth(p_sql, sb_cli)
        fn = f"{name}_{a.date.replace('-', '')}.csv"
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fn}"],
                              capture_output=True, text=True, env=DENV).stdout
        got = collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                  for rec in csv.DictReader(io.StringIO(text.lstrip("﻿"))))
        check(f"S4 the SFTP file == cloud truth + on-prem truth BY VALUE ({sum(want.values())} rows)",
              got == want and sum(want.values()) > 0, {"got": sum(got.values()), "want": sum(want.values())})
    finally:
        if moved:
            cloud_cli(f"ALTER TABLE {prem}_away RENAME TO {prem}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
