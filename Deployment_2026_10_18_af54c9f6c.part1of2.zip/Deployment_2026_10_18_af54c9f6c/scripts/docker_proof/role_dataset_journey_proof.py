"""The dataset journey as REAL users with login + row security ON (2026-10-02).

Everything fixed today was first proven on the login-OFF rig, where every
visitor is the guest admin and row security cannot be observed.  This walks
the same surfaces as rig_analyst and rig_viewer, with a row policy bound to
each, and judges every answer against what the QUERY BUILDER (the reference
road) shows the same user for the same table -- and the region set against
Trino's own truth:

  * the dataset wizard's preview (POST /api/datasets/preview) -- Trino AND S3;
  * a custom-SQL dataset over S3: its business-date filter values (LOV) and
    a filtered run;
  * the connection read (password masked, never blank; a viewer refused).

Run on the rig started with docker-compose.auth-rls.yml:

    . rigpw.sh   # QS_RIG_ADMIN_PW / QS_RIG_ANALYST_PW / QS_RIG_VIEWER_PW
    python scripts/docker_proof/role_dataset_journey_proof.py

Every policy enabled before the run is parked and re-enabled; everything
created is removed in a finally.
"""
from __future__ import annotations

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from auth_rls_proof import Session, trino_truth  # noqa: E402

TRINO_TABLE = "iceberg.qs.trades"
S3_TABLE = "trades"
TAG = str(int(time.time()))[-6:]
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return bool(ok)


def regions_of(body, key="region"):
    names = [x["name"] if isinstance(x, dict) else x for x in (body or {}).get("columns") or []]
    rows = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (body or {}).get("rows") or []]
    return {str(r.get(key)) for r in rows}


def region_sql(conn, table):
    """S3 is asked for ONE day: the query builder's pre-download path caps a
    whole-table read at 200 files (a refusal with a remedy, not a defect)."""
    where = " where dt = '2026-01-03'" if conn == 1 else ""
    return f"select distinct region from {table}{where}"


def qb_regions(sess, conn, table):
    """The QUERY BUILDER's answer for this user (the reference road)."""
    s, b, _ = sess.call("POST", "/api/execute", {
        "connection_id": conn, "cache_strategy": "bypass",
        "raw_sql": region_sql(conn, table)})
    eid = (b or {}).get("execution_id")
    if not eid:
        return s, b
    t0 = time.time()
    while time.time() - t0 < 300:
        _, st, _ = sess.call("GET", f"/api/executions/{eid}/status")
        if (st or {}).get("status") in ("completed", "success", "finished"):
            _, rb, _ = sess.call("GET", f"/api/executions/{eid}/results?page_size=100")
            return 200, regions_of(rb)
        if (st or {}).get("status") in ("failed", "error", "cancelled"):
            return 500, (st or {}).get("error_message")
        time.sleep(0.5)
    return -1, "timeout"


def main():
    S = {u: Session(u, os.environ[k]) for u, k in (("rig_admin", "QS_RIG_ADMIN_PW"),
                                                   ("rig_analyst", "QS_RIG_ANALYST_PW"),
                                                   ("rig_viewer", "QS_RIG_VIEWER_PW"))}
    admin, an, vw = S["rig_admin"], S["rig_analyst"], S["rig_viewer"]
    parked, made = [], []          # (path) of things to delete
    shared_before = {}
    try:
        # ── setup: park existing policies; share the two connections ─────────
        _, pols, _ = admin.call("GET", "/api/admin/row-security/policies")
        pols = pols if isinstance(pols, list) else (pols or {}).get("policies") or []
        for p in pols:
            if p.get("enabled") and admin.call("PUT", f"/api/admin/row-security/policies/{p['id']}",
                                               {"enabled": False})[0] == 200:
                parked.append(p["id"])
        for cid in (1, 2):
            _, conn, _ = admin.call("GET", f"/api/connections/{cid}")
            shared_before[cid] = bool(conn.get("is_shared"))
            if not shared_before[cid]:
                admin.call("PUT", f"/api/connections/{cid}", {k: conn[k] for k in ("name", "connection_type", "config")} | {"is_shared": True})

        def policy(table, region, user):
            s, p, _ = admin.call("POST", "/api/admin/row-security/policies", {
                "name": f"rolej-{user}-{TAG}-{len(made)}", "table_pattern": table,
                "filter_sql": f"region = '{region}'", "enforcement": "rewrite", "policy_class": "permissive"})
            assert s == 200, (s, p)
            made.append(f"/api/admin/row-security/policies/{p['id']}")
            s, bnd, _ = admin.call("POST", "/api/admin/row-security/bindings", {
                "policy_kind": "row", "policy_id": p["id"], "principal_type": "user", "principal_id": user})
            assert s == 200, (s, bnd)
            made.insert(0, f"/api/admin/row-security/bindings/{bnd['id']}")

        policy(TRINO_TABLE, "EUROPE", "rig_analyst")
        policy(TRINO_TABLE, "ASIA", "rig_viewer")
        policy(S3_TABLE, "EMEA", "rig_analyst")
        policy(S3_TABLE, "APAC", "rig_viewer")
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        all_trino = {r[0] for r in trino_truth(f"select distinct region from {TRINO_TABLE}")}

        # ── 1. the reference road, per user ──────────────────────────────────
        print("\n== 1 . the query builder (reference)")
        ref = {}
        for u, sess in (("rig_analyst", an), ("rig_viewer", vw)):
            for conn, table in ((2, TRINO_TABLE), (1, S3_TABLE)):
                s, got = qb_regions(sess, conn, table)
                ref[(u, conn)] = got if s == 200 else None
                print(f"   {u} conn {conn}: http={s} {got}")
        check("the reference road filters the analyst on Trino", ref[("rig_analyst", 2)] == {"EUROPE"},
              ref[("rig_analyst", 2)])

        # ── 2. the dataset wizard's preview, per user ───────────────────────
        print("\n== 2 . the dataset wizard's preview")
        for u, sess in (("rig_analyst", an), ("rig_viewer", vw)):
            for conn, table in ((2, TRINO_TABLE), (1, S3_TABLE)):
                t0 = time.time()
                s, b, _ = sess.call("POST", "/api/datasets/preview", {
                    "connection_id": conn, "limit": 100, "sql": region_sql(conn, table)})
                print(f"   {u} conn {conn}: preview http={s} in {time.time() - t0:.1f}s")
                got = regions_of(b) if s == 200 else None
                expect = ref[(u, conn)]
                if expect is None:
                    check(f"{u} conn {conn}: the preview refuses what the query builder refuses",
                          s in (401, 403, 404), f"http={s} {str(b)[:160]}")
                else:
                    check(f"{u} conn {conn}: the preview shows exactly what the query builder shows ({sorted(expect)})",
                          s == 200 and got == expect and got != all_trino,
                          f"http={s} got={sorted(got) if got else b}")

        # ── 3. a custom-SQL dataset over S3, as the analyst ──────────────────
        print("\n== 3 . a dataset over S3, as the analyst")
        s, ds, _ = an.call("POST", "/api/datasets", {
            "name": f"rolej_ds_{TAG}", "subject": "proof", "connection_ids": [1],
            "base_query": f"select id, dt, region, amt from {S3_TABLE} where dt = '2026-01-03'"})
        if check("the analyst creates the dataset", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:200])):
            did = ds["id"]
            made.insert(0, f"/api/datasets/{did}")
            an.call("POST", f"/api/datasets/{did}/auto-detect", {})
            _, d, _ = an.call("GET", f"/api/datasets/{did}")
            cols = {x["physical_name"]: x for x in (d or {}).get("columns") or []}
            s, lov, _ = an.call("POST", f"/api/datasets/{did}/column-values",
                                {"column_id": cols["region"]["id"], "parent_filters": []})
            check("its region filter offers only the analyst's rows",
                  s == 200 and set(map(str, lov.get("values") or [])) == ref[("rig_analyst", 1)],
                  (s, lov.get("values") if isinstance(lov, dict) else lov))
            s, run, _ = an.call("POST", f"/api/datasets/{did}/execute",
                                {"column_ids": [cols["region"]["id"], cols["amt"]["id"]]})
            rows = []
            if s == 200 and run.get("execution_id"):
                _, page, _ = an.call("GET", f"/api/datasets/executions/{run['execution_id']}/results?offset=0&limit=50")
                rows = page.get("rows") or []
            got = {str((r if isinstance(r, dict) else {"region": r[0]}).get("region")) for r in rows}
            check("its run returns only the analyst's rows", s == 200 and got == ref[("rig_analyst", 1)],
                  (s, sorted(got)))

        # ── 4. the connection read ──────────────────────────────────────────
        print("\n== 4 . the connection read")
        s, g, _ = an.call("GET", "/api/connections/3")
        check("analyst: a shared/owned connection's password is masked, never blank, never plaintext",
              s in (200, 404) and (s == 404 or g["config"].get("password") == "***"), (s, (g or {}).get("config", {}).get("password")))
        s, g, _ = vw.call("GET", "/api/connections/1")
        check("viewer: connection details are not readable or carry no plaintext secret",
              s in (401, 403, 404) or (g.get("config", {}).get("aws_secret_access_key") in ("***", None)), (s,))
    finally:
        for path in made:
            admin.call("DELETE", path)
        for pid in parked:
            admin.call("PUT", f"/api/admin/row-security/policies/{pid}", {"enabled": True})
        for cid, was in shared_before.items():
            if not was:
                _, conn, _ = admin.call("GET", f"/api/connections/{cid}")
                admin.call("PUT", f"/api/connections/{cid}", {k: conn[k] for k in ("name", "connection_type", "config")} | {"is_shared": False})
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        print(f"\ncleanup: {len(made)} objects removed, {len(parked)} policies re-enabled")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
