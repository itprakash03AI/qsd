"""CROSS-SOURCE: cloud (REAL AWS S3, Iceberg) x on-prem (Trino/Starburst
Iceberg) through every QueryStudio surface, on Docker (2026-10-06, login ON).

The Snowflake twin (cross_source_proof.py) lost its account on 2026-10-05; S3
is the product's bread and butter, so the cloud side is now the owner's AWS
bucket read by QueryStudio's OWN S3 engine (connection `aws-real`).

Cloud:   fact_tetb (Iceberg, partitioned business_close_date / business_event /
         code; 201,600 rows per COB) and dim_legal_entity on real S3.
On-prem: iceberg.qs.entity_risk (one row per legal entity -> RISK_TIER,
         DESK_OWNER) on the rig's Trino, created here.
Truth:   the Trino CLI joining iceberg_aws.fin.* to iceberg.qs.* directly.

  X1 query builder (/api/execute): S3 primary JOIN Trino secondary;
  X2 query builder (/api/execute): Trino primary UNION S3 secondary;
  X3 SQL page (/api/sql/execute): S3 detail rows JOIN Trino, + UNION;
  X4 federation view over S3 + Trino;
  X5 report on MERGED datasets (S3 dataset x Trino dataset), > 10k rows;
  X6 feed: S3 primary + Trino secondary, JOIN -> file.

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/aws_cross_source_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from cross_source_proof import check, low, poll, res, results, rows, trino  # noqa: E402

TR = int(os.environ.get("QS_TRINO_CONN", "2"))
S3_NAME = os.environ.get("QS_AWS_CONN_NAME", "aws-real")
COB = os.environ.get("QS_XS_COB", "2025-09-30")
TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
ONPREM = "iceberg.qs.entity_risk"

S3_AGG = (f"select sap_company_id, sum(gbp_currency_amount) as gbp from fact_tetb "
          f"where business_close_date = DATE '{COB}' group by sap_company_id")
TR_DIM = f"select sap_company_id as ent_key, risk_tier, desk_owner from {ONPREM}"


def money(v):
    return Decimal(str(v)).quantize(Decimal("0.01"))


def total_of(meta):
    return int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0)


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    _, conns, _ = admin.call("GET", "/api/connections")
    items = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
    S3 = next((x["id"] for x in items if x.get("name") == S3_NAME), None)
    if not S3:
        raise SystemExit(f"no connection named {S3_NAME} -- run aws_tb_proof.py first (it registers the tables)")

    # ── the on-prem dimension, built on the rig's Trino ───────────────────
    trino(f"drop table if exists {ONPREM}")
    trino(f"create table {ONPREM} as select sap_company_id, "
          "case region when 'EMEA' then 'T1' when 'AMER' then 'T2' else 'T3' end as risk_tier, "
          "'DESK_' || country as desk_owner from iceberg_aws.fin.dim_legal_entity")
    dim = {r[0]: (r[1], r[2]) for r in trino(f"select sap_company_id, risk_tier, desk_owner from {ONPREM}")}
    by_ent = {r[0]: money(r[1]) for r in trino(
        f"select sap_company_id, sum(gbp_currency_amount) from iceberg_aws.fin.fact_tetb "
        f"where business_close_date = DATE '{COB}' group by 1")}
    n_cob = int(trino(f"select count(*) from iceberg_aws.fin.fact_tetb where business_close_date = DATE '{COB}'")[0][0])
    n_cob_mapped = int(trino(f"select count(*) from iceberg_aws.fin.fact_tetb f join {ONPREM} r on f.sap_company_id = r.sap_company_id "
                             f"where f.business_close_date = DATE '{COB}'")[0][0])
    n_book = int(trino(f"select count(*) from iceberg_aws.fin.fact_tetb where business_close_date = DATE '{COB}' "
                       "and business_event = 'BOOKING'")[0][0])
    check("setup", f"truth: on-prem dim built ({len(dim)} entities); the cloud COB has {n_cob:,} rows over {len(by_ent)} entities, all mapped",
          dim and by_ent and set(by_ent) <= set(dim) and n_cob_mapped == n_cob and n_book > 10_000,
          {"dim": len(dim), "entities": len(by_ent), "cob_rows": n_cob, "mapped": n_cob_mapped, "booking": n_book})
    undo = []
    try:
        # ── X1 query builder: S3 primary JOIN Trino secondary ─────────────
        body = {"connection_id": S3, "output_format": "json", "cache_strategy": "bypass", "raw_sql": S3_AGG,
                "secondary_connection_id": TR, "secondary_raw_sql": TR_DIM,
                "combine_mode": "join", "join_config": {"how": "inner", "left_on": ["sap_company_id"], "right_on": ["ent_key"]}}
        s, r, _ = admin.call("POST", "/api/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        got = [low(x) for x in rows(admin, r["execution_id"])] if st == 200 else []
        ok = (len(got) == len(by_ent) and all(
            dim[g["sap_company_id"]][0] == g.get("risk_tier") and money(g["gbp"]) == by_ent[g["sap_company_id"]] for g in got))
        check("X1", f"query builder: S3 primary JOIN on-prem secondary -> {len(by_ent)} entities WITH the on-prem tier, amounts == truth",
              ok, {"status": st, "rows": len(got), "cols": sorted(got[0]) if got else None, "err": str(meta)[:300] if st != 200 else ""})

        # ── X2 query builder: Trino primary UNION S3 secondary ────────────
        body = {"connection_id": TR, "output_format": "json", "cache_strategy": "bypass",
                "raw_sql": f"select sap_company_id, 'ONPREM' as src from {ONPREM}",
                "secondary_connection_id": S3,
                "secondary_raw_sql": (f"select sap_company_id, 'CLOUD' as src from fact_tetb where business_close_date = DATE '{COB}' "
                                      "and business_event = 'BOOKING'"),
                "combine_mode": "union"}
        s, r, _ = admin.call("POST", "/api/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        check("X2", f"query builder: on-prem primary UNION S3 secondary -> {len(dim)} + {n_book:,} rows",
              st == 200 and total_of(meta) == len(dim) + n_book,
              {"status": st, "total": total_of(meta), "want": len(dim) + n_book, "err": str(meta)[:300] if st != 200 else ""})

        # ── X3 SQL page: S3 detail rows JOIN Trino; and UNION ─────────────
        body = {"primary_connection_id": S3, "secondary_connection_id": TR,
                "primary_sql": (f"select source_data_row, sap_company_id, gbp_currency_amount from fact_tetb "
                                f"where business_close_date = DATE '{COB}'"),
                "secondary_sql": f"select sap_company_id, risk_tier from {ONPREM}",
                "join_config": {"how": "inner", "left_on": "sap_company_id", "right_on": "sap_company_id"}}
        t0 = time.time()
        s, r, _ = admin.call("POST", "/api/sql/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        dt = round(time.time() - t0, 1)
        sample = [low(x) for x in rows(admin, r["execution_id"], want=200, size=200)] if st == 200 else []
        tiers_ok = bool(sample) and all(dim[x["sap_company_id"]][0] == x.get("risk_tier") for x in sample)
        check("X3", f"SQL page: S3 {n_cob:,} detail rows JOIN on-prem dim -> {n_cob:,} rows with the tier ({dt}s)",
              st == 200 and total_of(meta) == n_cob and tiers_ok,
              {"status": st, "total": total_of(meta), "want": n_cob, "s": dt, "err": str(meta)[:300] if st != 200 else ""})
        ubody = {"primary_connection_id": S3, "secondary_connection_id": TR, "combine_mode": "union",
                 "primary_sql": (f"select sap_company_id, 'CLOUD' as src from fact_tetb where business_close_date = DATE '{COB}' "
                                 "and business_event = 'BOOKING'"),
                 "secondary_sql": f"select sap_company_id, 'ONPREM' as src from {ONPREM}"}
        s, r, _ = admin.call("POST", "/api/sql/execute", ubody)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        check("X3", f"SQL page: S3 UNION ALL on-prem -> {n_book:,} + {len(dim)} rows",
              st == 200 and total_of(meta) == n_book + len(dim),
              {"status": st, "total": total_of(meta), "want": n_book + len(dim), "err": str(meta)[:300] if st != 200 else ""})

        # ── X4 federation view over S3 + Trino ────────────────────────────
        s, fv, _ = admin.call("POST", "/api/federation-views", {
            "name": f"xs_fed_{TAG}", "primary_conn_id": S3, "primary_query": {"raw_sql": S3_AGG},
            "secondary_conn_id": TR, "secondary_query": {"raw_sql": TR_DIM},
            "combine_mode": "join", "join_on": [{"left": "sap_company_id", "right": "ent_key"}], "join_how": "inner"})
        if s in (200, 201) and (fv or {}).get("id"):
            undo.insert(0, f"/api/federation-views/{fv['id']}")
            s2, pv, _ = admin.call("POST", f"/api/federation-views/{fv['id']}/preview")
            prev = [low(x) for x in ((pv or {}).get("rows") or (pv or {}).get("data") or [])] if isinstance(pv, dict) else []
            ok = (s2 == 200 and len(prev) == len(by_ent) and all(
                dim[x["sap_company_id"]][0] == x.get("risk_tier") and money(x["gbp"]) == by_ent[x["sap_company_id"]] for x in prev))
            check("X4", f"federation view: S3 JOIN on-prem -> {len(by_ent)} rows with the tier, amounts == truth", ok,
                  {"status": s2, "rows": len(prev), "body": str(pv)[:300]})
        else:
            check("X4", "federation view over S3 + Trino can be CREATED", False, {"status": s, "body": str(fv)[:300]})

        # ── X5 report on MERGED datasets (> 10k rows) ─────────────────────
        s, d1, _ = admin.call("POST", "/api/datasets", {
            "name": f"xs_cloud_{TAG}", "subject": "x", "connection_ids": [S3],
            "base_query": (f"select source_data_row, sap_company_id, gbp_currency_amount from fact_tetb "
                           f"where business_close_date = DATE '{COB}' and business_event = 'BOOKING'")})
        s2, d2, _ = admin.call("POST", "/api/datasets", {"name": f"xs_onprem_{TAG}", "subject": "x", "connection_ids": [TR],
                                                         "base_query": f"select sap_company_id, risk_tier from {ONPREM}"})
        if check("X5", "S3 dataset and on-prem dataset created", s in (200, 201) and s2 in (200, 201), (s, s2, str(d1)[:200], str(d2)[:200])):
            undo.insert(0, f"/api/datasets/{d1['id']}")
            undo.insert(0, f"/api/datasets/{d2['id']}")
            for d in (d1, d2):
                admin.call("POST", f"/api/datasets/{d['id']}/auto-detect", {})
            c1 = {x["physical_name"].lower(): x for x in admin.call("GET", f"/api/datasets/{d1['id']}")[1]["columns"]}
            c2 = {x["physical_name"].lower(): x for x in admin.call("GET", f"/api/datasets/{d2['id']}")[1]["columns"]}
            for col in c1.values():
                admin.call("PUT", f"/api/datasets/columns/{col['id']}", {"column_type": "dimension"})
            if check("X5", "auto-detect found the columns on both sides",
                     {"source_data_row", "sap_company_id", "gbp_currency_amount"} <= set(c1) and {"sap_company_id", "risk_tier"} <= set(c2),
                     (sorted(c1), sorted(c2))):
                s, rep, _ = admin.call("POST", "/api/business-reports", {
                    "name": f"xs-merged-{TAG}", "dataset_id": d1["id"], "data_source_type": "dataset",
                    "column_ids": [c1["source_data_row"]["id"], c1["sap_company_id"]["id"], c1["gbp_currency_amount"]["id"]],
                    "merged_dataset_id": d2["id"], "merged_dataset_column_ids": [c2["sap_company_id"]["id"], c2["risk_tier"]["id"]],
                    "merge_config": {"merge_keys": [{"left": "sap_company_id", "right": "sap_company_id"}], "merge_type": "inner"}})
                if check("X5", "merged report created (S3 dataset x on-prem dataset)", s == 200, (s, str(rep)[:240])):
                    undo.insert(0, f"/api/business-reports/{rep['id']}")
                    s, ex, _ = admin.call("POST", f"/api/business-reports/{rep['id']}/execute",
                                          {"parameter_values": {}, "force_refresh": True})
                    tot = int((ex or {}).get("total_rows") or 0) if isinstance(ex, dict) else 0
                    check("X5", f"merged report: all {n_book:,} S3 rows carry the on-prem tier (no silent per-side cap)",
                          s == 200 and tot == n_book, {"status": s, "total": tot, "want": n_book,
                                                       "truncated": (ex or {}).get("truncated") if isinstance(ex, dict) else None,
                                                       "body": str(ex)[:300] if s != 200 else ""})

        # ── X6 feed: S3 primary + Trino secondary JOIN -> file ────────────
        def saved(name, conn, sql):
            s, q, _ = admin.call("POST", "/api/queries", {"name": name, "query_config": {"files": [], "raw_sql": sql, "connection_id": conn}})
            if s in (200, 201):
                undo.append(f"/api/queries/{q['id']}")
            return s, q
        s1, q1 = saved(f"xs_sq_cloud_{TAG}", S3, S3_AGG)
        s2, q2 = saved(f"xs_sq_onprem_{TAG}", TR, TR_DIM)
        if check("X6", "two saved queries (S3, on-prem) created", s1 in (200, 201) and s2 in (200, 201), (s1, s2, str(q1)[:160], str(q2)[:160])):
            s, fb, _ = admin.call("POST", "/api/feeds", {
                "name": f"XS_FEED_{TAG}", "source_type": "saved_query", "source_id": q1["id"], "connection_id": S3,
                "secondary_connection_id": TR, "secondary_source_type": "saved_query", "secondary_source_id": q2["id"],
                "combine_mode": "join", "join_config": {"how": "inner", "left_on": ["sap_company_id"], "right_on": ["ent_key"]},
                "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
                "execution_backend": "native"})
            if check("X6", "cross-source feed created", s == 200, (s, str(fb)[:300])):
                undo.insert(0, f"/api/feeds/{fb['id']}")
                s, ex, _ = admin.call("POST", f"/api/feeds/{fb['id']}/execute", {"trigger_type": "manual"})
                dbid = (ex or {}).get("execution_db_id")
                e, t0 = {}, time.time()
                while dbid and time.time() - t0 < 1200:
                    _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                    if (e or {}).get("status") in ("completed", "failed", "error", "cancelled"):
                        break
                    time.sleep(2)
                e = e or {}
                body_txt = ""
                if e.get("destination_path"):
                    body_txt = subprocess.run(["docker", "exec", "qs-local-api", "cat", e["destination_path"]], capture_output=True,
                                              text=True, env=DENV).stdout
                    subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", e["destination_path"]], env=DENV)
                lines = body_txt.splitlines()
                hdr = [h.strip().strip('"').lower() for h in lines[0].split(",")] if lines else []
                rows_ = [dict(zip(hdr, [v.strip('"') for v in ln.split(",")])) for ln in lines[1:] if ln.strip()]
                ok = (e.get("status") == "completed" and len(rows_) == len(by_ent) and all(
                    dim[r_["sap_company_id"]][0] == r_.get("risk_tier") and money(r_["gbp"]) == by_ent[r_["sap_company_id"]] for r_ in rows_))
                check("X6", "cross-source feed: the delivered file JOINs S3 amounts to the on-prem tier, == truth",
                      ok, {"status": e.get("status"), "rows": len(rows_), "hdr": hdr, "err": str(e.get("error_message"))[:300]})
    finally:
        for p in undo:
            admin.call("DELETE", p)
        print(f"\ncleanup: {len(undo)} removed")
    with open(os.environ.get("QS_PERF_OUT", "aws-cross-source-results.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1, default=str)
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
