"""FD-01..FD-10 in ONE pass, with Docker proof.

Proof chain, per run:
  * the HTTP endpoint's request-id is correlated into qs-local-api's logs
  * a UNIQUE marker is embedded in the generated SQL and found in the
    qs-trino container's query history, with the row count it scanned

What it leaves behind: nothing (2026-09-26).  The hierarchy, the report
and its duplicate are recorded in a ledger as they are created and removed
in a ``finally`` -- on a failed case, on a crash, on Ctrl-C -- with one
report line; a cleanup that could not remove something exits non-zero, as
does a failed assertion.  Leftovers from runs before this::

    python scripts/docker_proof/fd_proof.py --sweep-leftovers            # dry run
    python scripts/docker_proof/fd_proof.py --sweep-leftovers --execute  # delete

matched only by this file's own name templates with the run-id shape in
place of the tag (``fd10-\\d{6}``, its ``(Copy)``, ``fdp-\\d{6}``).
"""
from qs_docker_client import *      # noqa: F403
import csv
import io
import os
import subprocess
import sys
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from proof_cleanup import (                                  # noqa: E402
    RUN_ID, Ledger, Rule, sweep_flags, sweep_leftovers,
)

MARK = f"FDPROOF_{TAG}"
R = []
GAPS = []
LEDGER = Ledger(call)


def rec(code, name, ok, detail=""):
    R.append((code, name, bool(ok)))
    print(f"  [{'PASS' if ok else 'FAIL'}] {code} {name}"
          + (f"  -- {detail}" if detail else ""), flush=True)


def gap(code, text):
    GAPS.append((code, text))
    print(f"      >> GAP [{code}] {text}", flush=True)


def head(code, title):
    print(f"\n{'='*76}\n{code}  {title}\n{'='*76}", flush=True)


def dk(*args, timeout=90):
    r = subprocess.run(["docker", *args], capture_output=True, timeout=timeout)
    return (r.stdout or b"").decode("utf-8", "replace") + \
           (r.stderr or b"").decode("utf-8", "replace")


def ds(body, timeout=900):
    s, b, _ = call("POST", f"/api/datasets/{DS}/execute", body, timeout=timeout)
    if s != 200:
        return s, b, [], []
    d, n = rows_of(b.get("execution_id", ""), page_size=5000)
    return s, b, d, n


def col(dte):
    return "amt__" + dte.replace("-", "_")


RULES = [
    Rule("business report", rf"fd10-{RUN_ID}( \(Copy\))?",
         list_path="/api/business-reports",
         delete_path="/api/business-reports/{id}"),
    Rule("hierarchy", rf"fdp-{RUN_ID}",
         list_path=f"/api/datasets/{DS}/hierarchies",
         delete_path="/api/datasets/hierarchies/{id}"),
]


def proof():
    # ═══ DOCKER PROOF 1: who is answering ════════════════════════════════
    print("=" * 76)
    print("DOCKER PROOF — the endpoint under test")
    print("=" * 76)
    print(dk("port", "qs-local-api").strip())
    print("container:", dk("inspect", "qs-local-api", "-f",
                           "{{.Name}} {{slice .Id 0 12}} {{.Config.Image}}").strip())
    assert_serving_container()

    # ═══ FD-01 ═══════════════════════════════════════════════════════════
    head("FD-01", "Dynamic pivoting — Rows / Columns / Filters / Values")
    s, b, d, _ = ds({"column_ids": [COL["region"], COL["ccy"], COL["status"],
                                    COL["amt"]], "limit": 20000})
    EX = (b or {}).get("execution_id")
    rec("FD-01", "a grid to pivot from", s == 200 and d, f"{len(d)} rows")
    V = urllib.parse.quote(json.dumps([{"column": "amt", "function": "sum"}]))

    def piv(rows_, colf):
        return call("GET", f"/api/executions/{EX}/pivot-data"
                           f"?row_fields={rows_}&col_field={colf}&values={V}&top_n=500")

    s1, p1, _ = piv("region", "status")
    rec("FD-01", "ROWS=region COLS=status VALUES=SUM(amt)", s1 == 200,
        f"{len((p1 or {}).get('rows') or (p1 or {}).get('data') or [])} rows")
    s2, _p, _ = piv("status", "region")
    rec("FD-01", "axes SWAP, same execution, no re-query", s2 == 200)
    s3, p3, _ = piv("region,ccy", "status")
    rec("FD-01", "MULTI-LEVEL rows (region,ccy)", s3 == 200,
        f"{len((p3 or {}).get('rows') or (p3 or {}).get('data') or [])} rows")
    s4, _b, d4, _ = ds({"column_ids": [COL["region"], COL["status"], COL["amt"]],
                        "filters": [{"column_id": COL["ccy"], "operator": "eq",
                                     "value": "USD"}], "limit": 5000})
    rec("FD-01", "a FILTER on a column that is not displayed still applies",
        s4 == 200 and d4, f"{len(d4)} rows, ccy=USD not displayed")

    # ═══ FD-02 ═══════════════════════════════════════════════════════════
    head("FD-02", "Filter-First Data Loading — filter BEFORE the data loads")
    s, d8, _ = call("GET", "/api/datasets/8")
    c8 = {c["physical_name"]: c["id"] for c in d8["columns"]}
    t0 = time.time()
    s, b, _ = call("POST", "/api/datasets/8/execute",
                   {"column_ids": [c8["region"], c8["amt"]],
                    "filters": [{"column_id": c8["region"], "operator": "eq",
                                 "value": "AMER"},
                                {"column_id": c8["dt"], "operator": "eq",
                                 "value": "2026-03-05"}], "limit": 50}, timeout=900)
    w = time.time() - t0
    rec("FD-02", "filters choose the FILES, before loading", s == 200 and w < 5,
        f"{w:.2f}s over a 7,300-file table")

    # ═══ FD-04 ═══════════════════════════════════════════════════════════
    head("FD-04", "Multiple COB dates — MoM / YoY")
    ME = ["1998-01-31", "1998-02-28", "1998-03-31"]
    base = {"axis": "dt", "axis_data_type": "date", "on_missing": "zero",
            "measures": [{"column": "amt", "aggregation": "SUM", "label": "amt"}],
            "derived": ["variance", "variance_pct"]}
    spec = dict(base, buckets=[{"kind": "point", "value": x, "label": x} for x in ME])
    s, b, d, n = ds({"column_ids": [COL["region"]], "comparison": spec, "limit": 50})
    rec("FD-04", "three COB dates side by side", s == 200 and len(d) == 5, f"{n}")
    tr = {}
    for r in truth(f"""SELECT region, dt, SUM(amt) FROM iceberg.qs.trades
      WHERE dt IN ({','.join(f"DATE '{x}'" for x in ME)}) GROUP BY region, dt"""):
        v = list(r.values())
        tr[(str(v[0]), str(v[1])[:10])] = float(v[2])
    bad = [(r["region"], x) for r in d for x in ME
           if abs(float(r[col(x)]) - tr.get((str(r["region"]), x), 0)) > 0.01]
    rec("FD-04", "every COB value matches source truth", not bad,
        f"{len(d)*len(ME)} values, mismatched={bad}")
    YOY = ["1996-03-31", "1997-03-31", "1998-03-31"]
    s, b, dy, ny = ds({"column_ids": [COL["region"]],
                       "comparison": dict(base, buckets=[
                           {"kind": "point", "value": x, "label": x} for x in YOY]),
                       "limit": 50})
    rec("FD-04", "YoY — same month-end across three years", s == 200 and dy,
        f"{[c for c in ny if c != 'region'][:3]}")

    # ═══ FD-05 ═══════════════════════════════════════════════════════════
    head("FD-05", "Two COB dates -> Variance and % Variance")
    A, B = "1998-02-28", "1998-03-31"
    s, b, d2, n2 = ds({"column_ids": [COL["region"]],
                       "comparison": dict(base, buckets=[
                           {"kind": "point", "value": A, "label": A},
                           {"kind": "point", "value": B, "label": B}]), "limit": 50})
    rec("FD-05", "Variance AND % Variance produced",
        any("variance" in c for c in n2) and any("variance_pct" in c for c in n2), f"{n2}")
    okv = all(
        abs(float(r["amt__variance"]) - (float(r[col(B)]) - float(r[col(A)]))) < 0.01
        for r in d2)
    rec("FD-05", "the variance arithmetic is correct", okv, f"{len(d2)} rows")
    e = d2[0]
    print(f"      {e['region']}: {A}={money(e[col(A)])}  {B}={money(e[col(B)])}  "
          f"var={money(e['amt__variance'])}  {e['amt__variance_pct']}%")
    s, b, dn, nn = ds({"column_ids": [COL["region"]], "comparison": {
        "axis": "dt", "axis_data_type": "date", "on_missing": "zero",
        "buckets": [{"kind": "point", "value": x, "label": x} for x in
                    ["1998-01-31", "1998-02-28", "1998-03-31", "1998-04-30",
                     "1998-05-29"]],
        "measures": [{"column": "amt", "aggregation": "SUM", "label": "amt"}]},
        "limit": 50})
    rec("FD-05", "N dates side-by-side WITHOUT variance",
        s == 200 and not any("variance" in c for c in nn),
        f"{len([c for c in nn if c != 'region'])} date columns, 0 variance columns")

    # ═══ FD-06 ═══════════════════════════════════════════════════════════
    head("FD-06", "Variance across ALL measures, incl. an Average-Balance measure")
    s, b, d6, n6 = ds({"column_ids": [COL["region"]], "comparison": {
        "axis": "dt", "axis_data_type": "date", "on_missing": "zero",
        "buckets": [{"kind": "point", "value": A, "label": A},
                    {"kind": "point", "value": B, "label": B}],
        "measures": [{"column": "amt", "aggregation": "SUM", "label": "func_ccy"},
                     {"column": "qty", "aggregation": "SUM", "label": "txn_ccy"},
                     {"column": "amt", "aggregation": "AVG", "label": "avg_bal"},
                     {"column": "qty", "aggregation": "AVG", "label": "avg_qty"}],
        "derived": ["variance", "variance_pct"]}, "limit": 50})
    want = ["func_ccy", "txn_ccy", "avg_bal", "avg_qty"]
    have = [m for m in want if f"{m}__variance" in n6 and f"{m}__variance_pct" in n6]
    rec("FD-06", "variance + % for EVERY measure", have == want, f"{have}")
    rec("FD-06", "an AVERAGE-BALANCE measure is supported", "avg_bal__variance" in n6)
    r0 = d6[0]
    print(f"      {r0['region']}: func_ccy var={money(r0['func_ccy__variance'])} "
          f"({r0['func_ccy__variance_pct']}%)   "
          f"avg_bal var={money(r0['avg_bal__variance'])} "
          f"({r0['avg_bal__variance_pct']}%)")

    # ═══ FD-07 ═══════════════════════════════════════════════════════════
    head("FD-07", "MTD and YTD")
    for lbl, rule, lo in [("MTD", "mtd", "1998-03-01"), ("YTD", "ytd", "1998-01-01")]:
        s, b, d7, n7 = ds({"column_ids": [COL["region"]], "comparison": {
            "axis": "dt", "axis_data_type": "date", "on_missing": "zero",
            "buckets": [{"kind": "rule", "rule": rule, "anchor": "1998-03-31",
                         "label": lbl}],
            "measures": [{"column": "amt", "aggregation": "SUM", "label": "amt"}]},
            "limit": 50})
        t = truth(f"SELECT region, SUM(amt) FROM iceberg.qs.trades WHERE dt >= "
                  f"DATE '{lo}' AND dt <= DATE '1998-03-31' GROUP BY region")
        w7 = {str(list(r.values())[0]): float(list(r.values())[1]) for r in t}
        c7 = [c for c in n7 if c != "region"][0]
        bad7 = [r["region"] for r in d7
                if abs(float(r[c7]) - w7.get(str(r["region"]), 0)) > 0.01]
        rec("FD-07", f"{lbl} window exact ({lo} .. 1998-03-31)", not bad7,
            f"{len(d7)} regions, mismatched={bad7}")

    # ═══ FD-08 ═══════════════════════════════════════════════════════════
    head("FD-08", "Trend — a month of daily / 12 month-ends / 3 year-ends")
    for lbl, rule, anchor, n, exp in [
            ("(a) daily for a full month", "daily_in_month", "1998-03-31", 1, 31),
            ("(b) twelve month-ends", "last_n_month_ends", "1998-03-31", 12, 12),
            ("(c) three year-ends", "last_n_year_ends", "1997-12-31", 3, 3)]:
        s, b, _d, n8 = ds({"column_ids": [COL["region"]], "comparison": {
            "axis": "dt", "axis_data_type": "date", "on_missing": "zero",
            "buckets": [{"kind": "rule", "rule": rule, "anchor": anchor, "n": n}],
            "measures": [{"column": "amt", "aggregation": "SUM", "label": "amt"}]},
            "limit": 100})
        cs = [c for c in n8 if c != "region"]
        rec("FD-08", lbl, s == 200 and len(cs) == exp,
            f"{len(cs)} columns (expected {exp})"
            + (f"   {cs[0]} .. {cs[-1]}" if cs else ""))

    # ═══ FD-09 ═══════════════════════════════════════════════════════════
    head("FD-09", "Drill-down bringing in additional approved attributes")
    s, h, _ = call("POST", f"/api/datasets/{DS}/hierarchies",
                   {"name": f"fdp-{TAG}", "levels": [
                       {"column_id": COL["region"], "label": "Region"},
                       {"column_id": COL["ccy"], "label": "Currency"},
                       {"column_id": COL["book"], "label": "Book"},
                       {"column_id": COL["desk"], "label": "Desk"}]})
    HID = (h or {}).get("id")
    if HID:
        LEDGER.add("hierarchy", f"fdp-{TAG}", path=f"/api/datasets/hierarchies/{HID}")
    tots = {}
    for lvl in range(4):
        s, b, d9, _ = ds({"column_ids": [COL["region"], COL["amt"]],
                          "drill": {"hierarchy_id": HID, "level": lvl},
                          "limit": 20000})
        tots[lvl] = sum(float(r["amt"]) for r in d9)
        gb = ((b or {}).get("sql_executed") or "").split("GROUP BY")[-1]\
            .split("LIMIT")[0].strip()
        print(f"      level {lvl}: {len(d9):>6} rows   GROUP BY {gb}", flush=True)
    rec("FD-09", "each level adds an attribute, total invariant",
        len({round(v, 2) for v in tots.values()}) == 1,
        f"{money(list(tots.values())[0])} at every level")

    # ═══ FD-10 ═══════════════════════════════════════════════════════════
    head("FD-10", "Save AND export a customised layout + its filters")
    s, rep, _ = call("POST", "/api/business-reports", {
        "name": f"fd10-{TAG}", "dataset_id": DS, "data_source_type": "dataset",
        "column_ids": [COL["region"], COL["ccy"], COL["status"], COL["amt"]],
        "layout_config": {"report_type": "pivot", "pivot_config": {
            "row_field_ids": [COL["region"], COL["ccy"]],
            "col_field_ids": [COL["status"]],
            "value_fields": [{"column_id": COL["amt"], "aggregation": "sum"}],
            "show_grand_total": True}}})
    RID = (rep or {}).get("id")
    if RID:
        LEDGER.add("business report", f"fd10-{TAG}", path=f"/api/business-reports/{RID}")
    rec("FD-10", "a customised pivot LAYOUT is saved", s == 200 and RID, f"id={RID}")
    s, got, _ = call("GET", f"/api/business-reports/{RID}")
    pc = ((got or {}).get("layout_config") or {}).get("pivot_config") or {}
    rec("FD-10", "the layout survives a reload intact",
        pc.get("row_field_ids") == [COL["region"], COL["ccy"]],
        f"rows={pc.get('row_field_ids')} cols={pc.get('col_field_ids')} "
        f"values={json.dumps(pc.get('value_fields'))}")
    F = [{"column_id": COL["status"], "operator": "eq", "value": "SETTLED"}]
    s, run, _ = call("POST", f"/api/business-reports/{RID}/execute",
                     {"parameter_values": {}, "extra_filters": F})
    rws, _, _ = br_rows(RID, (run or {}).get("execution_id", ""))
    if not rws and (run or {}).get("execution_id"):
        rws, _ = rows_of(run["execution_id"])
    scr = sum(float(x.get("amt") or 0) for x in rws)
    qs = urllib.parse.quote(json.dumps(F))
    s, body, _ = call("GET", f"/api/business-reports/{RID}/download-csv?filters={qs}",
                      raw=True)
    rdr = list(csv.DictReader(io.StringIO(bytes(body).decode("utf-8-sig")))) \
        if isinstance(body, (bytes, bytearray)) else []
    filed = sum(float(x["amt"]) for x in rdr) if rdr else -1
    rec("FD-10", "the EXPORT carries the layout AND its filters",
        s == 200 and abs(filed - scr) < 0.01,
        f"screen={money(scr)}  file={money(filed)}")
    for fmt in ("excel", "pdf"):
        s, bb, _ = call("GET", f"/api/business-reports/{RID}/download-{fmt}?limit=50",
                        raw=True)
        rec("FD-10", f"export as {fmt.upper()}", s == 200,
            f"{len(bb) if isinstance(bb,(bytes,bytearray)) else 0} bytes")
    s, dup, _ = call("POST", f"/api/business-reports/{RID}/duplicate", {})
    if (dup or {}).get("id"):
        LEDGER.add("business report", f"fd10-{TAG} (Copy)",
                   path=f"/api/business-reports/{dup['id']}")
    rec("FD-10", "a saved layout is re-usable (duplicate)",
        s == 200 and (dup or {}).get("id") != RID, f"new id={(dup or {}).get('id')}")

    # ═══ FD-03 ═══════════════════════════════════════════════════════════
    head("FD-03", "Any approved column — report / pivot / filter")
    s, dsf, _ = call("GET", f"/api/datasets/{DS}")
    allc = [(c["id"], c["physical_name"]) for c in dsf["columns"]]
    rec("FD-03", "the approved column list is published", bool(allc),
        f"{len(allc)}: {[c[1] for c in allc]}")
    seln, filn = [], []
    for cid, nm in allc:
        s, _b, _ = call("POST", f"/api/datasets/{DS}/execute",
                        {"column_ids": [cid, COL["amt"]], "limit": 10}, timeout=600)
        if s != 200:
            seln.append(nm)
        s, _b, _ = call("POST", f"/api/datasets/{DS}/execute",
                        {"column_ids": [COL["region"], COL["amt"]],
                         "filters": [{"column_id": cid, "operator": "is_not_null",
                                      "value": None}], "limit": 10}, timeout=600)
        if s != 200:
            filn.append(nm)
    rec("FD-03", "every approved column is SELECTABLE", not seln,
        f"{len(allc)-len(seln)}/{len(allc)}" + (f"  failed: {seln}" if seln else ""))
    rec("FD-03", "every approved column is FILTERABLE", not filn,
        f"{len(allc)-len(filn)}/{len(allc)}")
    if seln:
        gap("FD-03", f"{seln} typed as a MEASURE in the dataset but VARCHAR in the "
                     f"source -> SUM(varchar) is FUNCTION_NOT_FOUND on Trino. "
                     f"A column-typing defect, not a pivoting one.")

    # ═══ DOCKER PROOF 2: trace one query into the Trino container ════════
    head("PROOF", "a marked query traced from this process into TWO containers")
    for _ in range(60):
        _s, _b, _ = call("POST", f"/api/datasets/{DS}/execute",
                         {"column_ids": [COL["region"], COL["amt"]], "limit": 2})
        if _s == 200: break
        time.sleep(5)
    s, b, _ = call("POST", f"/api/datasets/{DS}/execute",
                   {"column_ids": [COL["region"], COL["amt"]],
                    "filters": [{"column_id": COL["book"], "operator": "neq",
                                 "value": MARK}], "limit": 10}, timeout=900)
    EID = (b or {}).get("execution_id")
    print(f"      marker      : {MARK}")
    print(f"      execution   : {EID}")
    print(f"      SQL         : {((b or {}).get('sql_executed') or '')[:150]}")
    logs = dk("logs", "qs-local-api", "--since", "180s")
    rec("PROOF", "the execution appears in qs-local-api's own logs",
        EID and EID in logs, f"/app/... paths, container filesystem")
    dk("exec", "qs-trino", "sh", "-c",
       "curl -s -H 'X-Trino-User: p' http://localhost:8080/v1/query > /tmp/p.json")
    hit = dk("exec", "qs-trino", "sh", "-c",
             f"sed 's/}},{{/}}\\n{{/g' /tmp/p.json | grep '{MARK}' | "
             f"grep -o '\"state\":\"[A-Z]*\"\\|\"remoteUserAddress\":\"[0-9.]*\"\\|"
             f"\"processedInputPositions\":[0-9]*\\|\"elapsedTime\":\"[^\"]*\"'")
    print("      qs-trino saw :")
    for line in hit.strip().splitlines():
        print(f"        {line}")
    rec("PROOF", "the SAME marker is in the qs-trino container's query history",
        "FINISHED" in hit, "scanned the Iceberg table and finished")


def main(argv):
    sweep, execute, _rest = sweep_flags(argv[1:])
    if sweep:
        return sweep_leftovers(call, RULES, execute=execute)
    try:
        proof()
    finally:
        # ═══ CLEANUP ═════════════════════════════════════════════════════
        # 2026-09-25: every run used to leave its report, its copy and its
        # hierarchy on the rig (the audit found fd10-* reports from each
        # run).  2026-09-26: and the cleanup ran only when every case got
        # through -- a d2[0] on an empty answer skipped it.  Now it is a
        # ``finally`` over a ledger, and what it could not remove is said.
        head("CLEANUP", "what this run created, removed")
        _removed, left = LEDGER.cleanup(echo=lambda s: print("      " + s))

    # ═══ RESULT ══════════════════════════════════════════════════════════
    print(f"\n{'='*76}")
    by = {}
    for code, _n, ok in R:
        a, b_ = by.get(code, (0, 0))
        by[code] = (a + (1 if ok else 0), b_ + 1)
    print("FD-01 .. FD-10, via Docker\n")
    for code in sorted(by):
        p_, t_ = by[code]
        print(f"   {code:<7} {p_}/{t_} {'PASS' if p_ == t_ else 'PARTIAL'}")
    P = sum(1 for _, _, o in R if o)
    T = len(R)
    print(f"\n   TOTAL   {P}/{T}")
    if GAPS:
        print("\n   GAPS:")
        for c, t in GAPS:
            print(f"     [{c}] {t}")
    if left:
        print(f"\n   CLEANUP LEFT {len(left)} OBJECT(S) ON THE RIG")
    print("=" * 76)
    if not R:
        return 2
    return 1 if (P != T or left) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
