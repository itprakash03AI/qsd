"""THE read plan on the rig's Spark PODS (2026-10-14, steps 3-4 of
docs/READ_PLAN_ALL_ENGINES_2026_10_14.html).

Every case runs a feed pinned to ``spark_k8s`` (a SparkApplication on the
kind cluster): the backend plans each table (Iceberg: the planner's pinned
snapshot + the metadata file it read; Parquet: Hive-rule files and decided
partition types), the pod executes that plan, the file is delivered by SFTP
and read back from the SFTP server.

  mor          the Spark-written v2 table on AWS with 2,000 position + 150
               equality deletes: rows, sum(amt) and the EXACT id set against
               what was written and deleted (computed here, no reader involved)
  iceberg      the owner's JOIN query over the AWS Iceberg tables: the pod's
               file == QueryStudio's engine's file, value by value
  hive         the owner's JOIN query over the on-prem Hive tables (MinIO):
               the same comparison

  two_sides    cloud (AWS Iceberg) + on-prem (Hive) merged on ONE pod == native
  snapshot     a commit lands after the plan pinned the snapshot: the pod
               delivers the pinned answer (rolled back afterwards)
  file_appears a Hive file lands after planning: the job REFUSES
  refusals     no data files / an unregistered table: refused before a pod
  retry        a commit after the pin, then the driver pod KILLED: attempt -r1
               delivers the pinned answer (QueryStudio-delivered parquet)
  schema       a column renamed + a column added, rows written after both:
               native and the pod each == Trino (restored afterwards)

    python read_plan_pod_proof.py [mor iceberg hive two_sides snapshot file_appears refusals schema retry]
"""
from __future__ import annotations

import collections
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from join_query_proof import JOIN_SQL, SFTP_DEST, STATE, _sftp_rows  # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key  # noqa: E402

CHECKS = []
def _state_mor():
    try:
        return json.load(open(STATE)).get("mor_table")
    except (OSError, ValueError):
        return None


#: made + registered by read_plan_pod_setup.py (2026-10-16; was a hand-made leftover)
MOR_TABLE = os.environ.get("QS_MOR_TABLE") or _state_mor() or "mor_170400"


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


def _conn(r, pred):
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    return next(c for c in conns if pred(c))


def run_feed(r, name, conn_id, sql, table_map, lane, bd, *, extra=None, on_submitted=None,
             expect_refusal=None):
    """Create/update and run one feed; returns (execution id, status, rows-file).

    ``on_submitted(eid)`` runs once the execution carries its workload name
    (the plan is built and pinned by then, the pod not yet reading);
    ``expect_refusal`` = a phrase the FAILED run's error must carry."""
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    qp = {"sql": sql}
    if table_map:
        qp["table_map"] = table_map
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": conn_id,
            "query_params": qp, "output_format": "csv", "output_options": {"delimiter": "|"},
            "destination_type": "sftp",
            "destination_config": dict(SFTP_DEST, host_key_b64=sftp_host_key()),
            "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
            "execution_backend": lane, "is_active": True, "schedule_enabled": False,
            "description": f"Proof: the read plan on {lane}"}
    body.update(extra or {})
    f = next((x for x in feeds if x["name"] == name), None)
    s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
    if s not in (200, 201):
        raise SystemExit(f"{name}: {s} {str(b)[:500]}")
    fid = f["id"] if f else b["id"]
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    run = r.run_row(fid, bd)
    if run is None:
        r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": bd, "end_date": bd, "deliver": True,
                                                       "reason": f"read-plan pod proof ({lane})"})
    else:
        r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": f"read-plan pod proof ({lane})"})
    t0, row, hooked = time.time(), "", on_submitted is None
    while time.time() - t0 < 3000:
        row = psql(f"select id, status, coalesce(external_job_id,'') from feed_executions "
                   f"where feed_config_id={fid} and id>{before} and business_date='{bd}' "
                   f"order by id desc limit 1")
        if row and not hooked and row.split("|")[2]:
            hooked = True
            on_submitted(row.split("|")[0])
        if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
            break
        time.sleep(2 if not hooked else 10)
    row = "|".join(row.split("|")[:2])
    eid, status = row.split("|")
    backend = psql(f"select coalesce(execution_backend,'') from feed_executions where id={eid}")
    err = psql(f"select coalesce(error_message,'') from feed_executions where id={eid}")
    secs = round(time.time() - t0)
    if expect_refusal:
        check(f"{name} REFUSED on {lane}: {expect_refusal!r}",
              status == "failed" and expect_refusal.lower() in err.lower(),
              f"{status} {secs}s {err[:400]}")
        return eid, status, None, None
    check(f"{name} completed on {lane}", status == "completed" and backend == lane,
          f"{status} backend={backend} {secs}s {err[:400]}")
    if status != "completed":
        return eid, status, None, None
    head, rows = _sftp_rows(name + "_" + bd.replace("-", "") + ".csv")
    return eid, status, head, rows


def case_mor(r, bd):
    s3c = _conn(r, lambda c: c["name"] == "aws-real")
    keep = [i for i in range(20000) if i % 10 != 0 and not (i % 2 == 1 and i < 300)]
    eid, status, head, rows = run_feed(r, "RP_POD_MOR", s3c["id"],
                                       f"SELECT id, code, amt FROM {MOR_TABLE}", None, "spark_k8s", bd)
    if not rows:
        return
    hi = [h.lower() for h in head]
    ids = sorted(int(x[hi.index("id")]) for x in rows.elements())
    amt = sum(float(x[hi.index("amt")]) for x in rows.elements())
    check("pod: rows == written - position deletes - equality deletes", len(ids) == len(keep),
          f"{len(ids)} vs {len(keep)}")
    check("pod: the EXACT surviving ids", ids == keep,
          "" if ids == keep else f"{len(set(ids) - set(keep))} unexpected, {len(set(keep) - set(ids))} missing")
    want = sum(i + 0.25 for i in keep)
    check("pod: sum(amt) == expected", abs(amt - want) < 1e-6, f"{amt} vs {want}")
    s, lg = r.call("GET", f"/api/feed-executions/{eid}/driver-log")
    text = json.dumps(lg)
    check("pod: read through Iceberg at the PLANNED snapshot", "at snapshot" in text and MOR_TABLE in text,
          "" if "at snapshot" in text else text[:300])


def case_join(r, bd, label, conn_pred, table_map, want_rows):
    conn = _conn(r, conn_pred)
    sql = open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")
    out = {}
    for lane in ("native", "spark_k8s"):
        name = f"RP_POD_{label.upper()}_{'SPARK' if lane == 'spark_k8s' else 'NATIVE'}"
        _eid, _st, head, rows = run_feed(r, name, conn["id"], sql, table_map, lane, bd)
        if rows is not None:
            out[lane] = (head, rows)
            n = sum(rows.values())
            check(f"{label} {lane}: rows == truth", n == want_rows, f"{n} vs {want_rows}")
    if len(out) == 2:
        (h1, r1), (h2, r2) = out["native"], out["spark_k8s"]
        check(f"{label}: same header on both engines", h1 == h2,
              "" if h1 == h2 else str([(a, b) for a, b in zip(h1, h2) if a != b][:4]))
        a, b = r1 - r2, r2 - r1
        check(f"{label}: Spark pod file == QueryStudio file, value by value",
              not a and not b and sum(r1.values()) > 0,
              "" if not a and not b else f"{sum(a.values())} only native, {sum(b.values())} only spark; "
              f"native e.g. {list(a)[:1]} spark e.g. {list(b)[:1]}")


ICE_MAP = lambda tag: {"icbg.fins.fact_tetb": f"jq_tetb_{tag}",            # noqa: E731
                       "icbg.fins.fact_tetb_ext": f"jq_ext_{tag}"}
HIVE_MAP = lambda tag: {"icbg.fins.fact_tetb": f"hv_fact_tetb_{tag}",         # noqa: E731
                        "icbg.fins.fact_tetb_ext": f"hv_fact_tetb_ext_{tag}"}


#: The table's CURRENT snapshot -- the newest CURRENT ANCESTOR in $history,
#: never the newest commit (after a rollback that is the one rolled away
#: from) nor the newest history row (a rollback adds none).
CURRENT_SNAPSHOT = ('SELECT snapshot_id FROM {schema}."fact_tetb$history" '
                    "WHERE is_current_ancestor ORDER BY made_current_at DESC LIMIT 1")


def _minio():
    import boto3
    import subprocess
    env = subprocess.run(["docker", "inspect", "qs-minio", "--format",
                          "{{range .Config.Env}}{{println .}}{{end}}"],
                         capture_output=True, text=True).stdout.splitlines()
    pw = next(x.split("=", 1)[1] for x in env if x.startswith("MINIO_ROOT_PASSWORD="))
    return boto3.client("s3", endpoint_url="http://localhost:9000", aws_access_key_id="qsadmin",
                        aws_secret_access_key=pw, region_name="us-east-1")


def _join_sql():
    return open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")


def _minio_conn(r):
    return _conn(r, lambda c: c["connection_type"] == "s3"
                 and (c.get("config") or {}).get("bucket_name") == "qs-data")


def case_two_sides(r, st):
    """The owner's real shape on ONE pod: the cloud side (AWS Iceberg) and the
    on-prem side (Hive on MinIO), both "tables" sides, merged by column name.
    The pod's file == the same feed on QueryStudio's engine, value by value."""
    tag, bd = st["tag"], st["bd"]
    aws = _conn(r, lambda c: c["name"] == "aws-real")
    minio = _minio_conn(r)
    want = st["truth"]["cloud"]["rows"] + st["truth"]["prem"]["rows"]
    out = {}
    for lane in ("native", "spark_k8s"):
        name = f"RP_POD_TWO_SIDES_{'SPARK' if lane == 'spark_k8s' else 'NATIVE'}"
        eid, _st, head, rows = run_feed(
            r, name, aws["id"], _join_sql(),
            {"primary": ICE_MAP(tag), "secondary": HIVE_MAP(tag)}, lane, bd,
            extra={"secondary_connection_id": minio["id"], "secondary_source_type": None,
                   "secondary_source_id": None, "combine_mode": "union"})
        if rows is None:
            continue
        out[lane] = (head, rows)
        check(f"two sides {lane}: rows == cloud truth + on-prem truth", sum(rows.values()) == want,
              f"{sum(rows.values())} vs {want}")
        fm = psql(f"select coalesce(files_metadata::text,'') from feed_executions where id={eid}")
        cs = (json.loads(fm or "{}") or {}).get("cross_source") or {}
        check(f"two sides {lane}: the run records both sides' rows",
              cs.get("primary_rows") == st["truth"]["cloud"]["rows"]
              and cs.get("secondary_rows") == st["truth"]["prem"]["rows"],
              {k: cs.get(k) for k in ("primary_rows", "secondary_rows", "combined_rows", "combine", "lane")})
    if len(out) == 2:
        (h1, r1), (h2, r2) = out["native"], out["spark_k8s"]
        a, b = r1 - r2, r2 - r1
        check("two sides: Spark pod file == QueryStudio file, value by value",
              h1 == h2 and not a and not b and sum(r1.values()) > 0,
              "" if not a and not b else f"{sum(a.values())} only native, {sum(b.values())} only spark")


def case_snapshot_moves(r, st):
    """The Iceberg table gains a commit AFTER the plan pinned its snapshot and
    before the pod reads: the pod must deliver the PINNED snapshot's answer
    (== the native file delivered before the commit), and the table's answer
    must really have changed (else the case proves nothing).  The commit is
    rolled back afterwards."""
    tag, bd = st["tag"], st["bd"]
    schema = st["cloud"]["schema"]                       # iceberg_aws.jq_<tag>
    from tetb_real_e2e_proof import cloud_cli
    last = CURRENT_SNAPSHOT.format(schema=schema)
    sid0 = cloud_cli(last).strip().strip('"')
    aws = _conn(r, lambda c: c["name"] == "aws-real")
    head0, rows0 = _sftp_rows("RP_POD_ICEBERG_NATIVE_" + bd.replace("-", "") + ".csv")
    if rows0 is None:
        check("snapshot moves: the pre-commit native file exists (run 'iceberg' first)", False)
        return
    moved = {}

    def commit(_eid):
        cloud_cli(f"INSERT INTO {schema}.fact_tetb SELECT * FROM {schema}.fact_tetb "
                  f"WHERE business_close_date = DATE '{bd}' AND system_id = 'SAPADB'")
        moved["sid"] = cloud_cli(last).strip().strip('"')
        print(f"   committed snapshot {moved['sid']} after the plan pinned {sid0}", flush=True)
    try:
        _eid, _status, head, rows = run_feed(r, "RP_POD_SNAPSHOT_MOVES", aws["id"], _join_sql(),
                                             {"primary": ICE_MAP(tag)}, "spark_k8s", bd,
                                             on_submitted=commit)
        now = cloud_cli('SELECT count(*), sum("Transactional Currency Amount") FROM (\n'
                        + _join_sql().replace("icbg.fins.", schema + ".") + "\n) t",
                        stdin=True).strip().replace('"', "").split("\t")
        check("snapshot moves: the table's answer CHANGED after the commit (the case is real)",
              bool(moved.get("sid")) and moved["sid"] != sid0
              and abs(float(now[1]) - st["truth"]["cloud"]["amount"]) > 1,
              f"now {now} vs truth amount {st['truth']['cloud']['amount']}")
        if rows is not None:
            a, b = rows0 - rows, rows - rows0
            check("snapshot moves: the pod delivered the PINNED snapshot (== the pre-commit file)",
                  head == head0 and not a and not b, f"{sum(a.values())} / {sum(b.values())} differ")
    finally:
        cloud_cli(f"CALL iceberg_aws.system.rollback_to_snapshot('{schema.split('.', 1)[1]}', "
                  f"'fact_tetb', {sid0})")
        back = cloud_cli(f"SELECT count(*) FROM {schema}.fact_tetb").strip().strip('"')
        check("snapshot moves: rolled back to the original snapshot",
              int(back) == st["cloud"]["fact_tetb"]["rows"],
              f"{back} vs {st['cloud']['fact_tetb']['rows']}")


def case_file_appears(r, st):
    """A data file lands in a Hive table AFTER the backend planned it: the
    pod's reader would see a different table than the plan -- the job must
    REFUSE, never read the extra rows."""
    tag, bd = st["tag"], st["bd"]
    minio = _minio_conn(r)
    s3 = _minio()
    hive_schema = st["prem"]["schema"].split(".", 1)[1]
    prefix = f"hive-metastore/{hive_schema}/fact_tetb/business_close_date={bd}/"
    keys = [o["Key"] for o in s3.list_objects_v2(Bucket="qs-data", Prefix=prefix)["Contents"]
            if not any(p.startswith((".", "_")) for p in o["Key"].split("/"))]
    extra_key = keys[0].rsplit("/", 1)[0] + "/zz_landed_after_the_plan"
    try:
        run_feed(r, "RP_POD_FILE_APPEARS", minio["id"], _join_sql(), {"primary": HIVE_MAP(tag)},
                 "spark_k8s", bd,
                 on_submitted=lambda _e: s3.copy_object(Bucket="qs-data", Key=extra_key,
                                                        CopySource={"Bucket": "qs-data", "Key": keys[0]}),
                 expect_refusal="the two readers disagree")
    finally:
        s3.delete_object(Bucket="qs-data", Key=extra_key)


def case_refusals(r, st):
    """Refused at PLAN time, before any pod exists, naming the cause."""
    bd = st["bd"]
    minio = _minio_conn(r)
    r.call("DELETE", f"/api/connections/{minio['id']}/tables/rp_empty_table")
    _minio().put_object(Bucket="qs-data", Key="rp-empty-table/_SUCCESS", Body=b"")
    r.call("POST", f"/api/connections/{minio['id']}/tables", {
        "name": "rp_empty_table", "s3_prefix": "rp-empty-table/", "format": "parquet",
        "description": "read-plan proof: a folder with no data files"})
    eid, *_ = run_feed(r, "RP_POD_NO_FILES", minio["id"], "SELECT * FROM rp_empty_table", None,
                       "spark_k8s", bd, expect_refusal="no data files")
    job = psql(f"select coalesce(external_job_id,'') from feed_executions where id={eid}")
    check("no data files: refused before a pod was created", job == "", job)
    eid, *_ = run_feed(r, "RP_POD_UNREGISTERED", minio["id"], "SELECT * FROM rp_not_a_table", None,
                       "spark_k8s", bd, expect_refusal="not a table registered")
    job = psql(f"select coalesce(external_job_id,'') from feed_executions where id={eid}")
    check("unregistered table: refused before a pod was created", job == "", job)


def case_schema_evolves(r, st):
    """Iceberg schema evolution, the two kinds a writer does: a column the
    query reads is RENAMED (old files carry the old physical name, new files
    the new one -- Iceberg binds by field id), and a column is ADDED (old
    files lack it -> NULL).  Rows are written after both, so every file kind
    is in the answer.  QueryStudio's engine and the pod must each equal
    Trino's own answer on the same table.  Restored afterwards (data rolled
    back, the column dropped, the rename undone)."""
    tag, bd = st["tag"], st["bd"]
    schema = st["cloud"]["schema"]
    table = f"{schema}.fact_tetb"
    from tetb_real_e2e_proof import cloud_cli
    last = CURRENT_SNAPSHOT.format(schema=schema)
    sid0 = cloud_cli(last).strip().strip('"')
    cols = [ln.split("\t")[0].strip('"') for ln in cloud_cli(f"SHOW COLUMNS FROM {table}").splitlines()
            if ln.strip()]
    aws = _conn(r, lambda c: c["name"] == "aws-real")
    sql = ("SELECT system_id_v2 AS sid, coalesce(ev_added, '-') AS e, count(*) AS n, "
           "CAST(sum(transactional_currency_amount) AS DOUBLE) AS s FROM {t} "
           f"WHERE business_close_date = DATE '{bd}' GROUP BY system_id_v2, coalesce(ev_added, '-')")
    try:
        cloud_cli(f"ALTER TABLE {table} RENAME COLUMN system_id TO system_id_v2")
        cloud_cli(f"ALTER TABLE {table} ADD COLUMN ev_added varchar")
        names = ["system_id_v2" if c == "system_id" else c for c in cols]
        cloud_cli(f"INSERT INTO {table} ({', '.join(names)}, ev_added) SELECT {', '.join(names)}, 'NEW' "
                  f"FROM {table} WHERE business_close_date = DATE '{bd}' AND code = 'E0'")
        truth = {}
        for ln in cloud_cli(sql.format(t=table)).splitlines():
            sid_, e, n, s = [x.strip('"') for x in ln.split("\t")]
            truth[(sid_, e)] = (int(n), float(s))
        check("schema evolves: Trino's answer reads both file kinds (NEW rows + renamed column)",
              any(k[1] == "NEW" for k in truth) and len(truth) >= 4, truth)
        for lane in ("native", "spark_k8s"):
            name = f"RP_POD_SCHEMA_{'SPARK' if lane == 'spark_k8s' else 'NATIVE'}"
            _eid, _s, head, rows = run_feed(r, name, aws["id"], sql.format(t=f"jq_tetb_{tag}"),
                                            None, lane, bd)
            if rows is None:
                continue
            hi = [h.lower() for h in head]
            got = {(x[hi.index("sid")], x[hi.index("e")]): (int(x[hi.index("n")]), float(x[hi.index("s")]))
                   for x in rows.elements()}
            same = got.keys() == truth.keys() and all(
                got[k][0] == truth[k][0] and abs(got[k][1] - truth[k][1]) < 1e-6 * max(1, abs(truth[k][1]))
                for k in truth)
            check(f"schema evolves {lane}: == Trino on the evolved table, group by group", same,
                  "" if same else f"got {got} truth {truth}")
    finally:
        cloud_cli(f"CALL iceberg_aws.system.rollback_to_snapshot('{schema.split('.', 1)[1]}', "
                  f"'fact_tetb', {sid0})")
        if "ev_added" in cloud_cli(f"SHOW COLUMNS FROM {table}"):
            cloud_cli(f"ALTER TABLE {table} DROP COLUMN ev_added")
        if "system_id_v2" in cloud_cli(f"SHOW COLUMNS FROM {table}"):
            cloud_cli(f"ALTER TABLE {table} RENAME COLUMN system_id_v2 TO system_id")
        back = cloud_cli(f"SELECT count(*) FROM {table}").strip().strip('"')
        now_cols = [ln.split("\t")[0].strip('"') for ln in
                    cloud_cli(f"SHOW COLUMNS FROM {table}").splitlines() if ln.strip()]
        check("schema evolves: table restored (rows, columns)",
              int(back) == st["cloud"]["fact_tetb"]["rows"] and now_cols == cols,
              f"{back} rows, columns same={now_cols == cols}")


def case_retry_reads_the_pinned_plan(r, st):
    """The driver pod is KILLED mid-run after a commit landed on the table:
    the reconciler's next attempt (-r1) must read the SAME pinned plan (it
    reuses the first attempt's conf from its Secret), so the file holds the
    pinned snapshot's answer, not the table's new one.  Parquet over SFTP:
    QueryStudio delivers (the job writes artifacts only), the case a retry is
    allowed for -- a job that delivers itself is never retried (it may have
    delivered already).  Rolled back afterwards."""
    import io
    import subprocess
    import pyarrow.parquet as pq
    tag, bd = st["tag"], st["bd"]
    schema = st["cloud"]["schema"]
    from tetb_real_e2e_proof import cloud_cli
    last = CURRENT_SNAPSHOT.format(schema=schema)
    sid0 = cloud_cli(last).strip().strip('"')
    aws = _conn(r, lambda c: c["name"] == "aws-real")
    killed = {}

    def commit_then_kill(eid):
        cloud_cli(f"INSERT INTO {schema}.fact_tetb SELECT * FROM {schema}.fact_tetb "
                  f"WHERE business_close_date = DATE '{bd}' AND system_id = 'SAPADB'")
        job = psql(f"select external_job_id from feed_executions where id={eid}")
        pod = job + "-driver"
        kc = ["kubectl", "--context", "kind-qs-spark", "-n", "spark"]
        for _ in range(120):
            ph = subprocess.run(kc + ["get", "pod", pod, "-o", "jsonpath={.status.phase}"],
                                capture_output=True, text=True).stdout.strip()
            if ph == "Running":
                break
            time.sleep(2)
        time.sleep(8)                                   # the job is past START, reading
        out = subprocess.run(kc + ["delete", "pod", pod, "--wait=false"], capture_output=True, text=True)
        killed.update(pod=pod, phase=ph, rc=out.returncode)
        print(f"   committed after the pin, then killed {pod} ({ph})", flush=True)
    try:
        eid, status, _h, _r = run_feed(
            r, "RP_POD_RETRY", aws["id"], _join_sql(), {"primary": ICE_MAP(tag)}, "spark_k8s", bd,
            extra={"output_format": "parquet",
                   "output_filename_template": "RP_POD_RETRY_{business_date:YYYYMMDD}.parquet"},
            on_submitted=commit_then_kill)
    finally:
        cloud_cli(f"CALL iceberg_aws.system.rollback_to_snapshot('{schema.split('.', 1)[1]}', "
                  f"'fact_tetb', {sid0})")
    check("retry: the driver was killed mid-run", killed.get("rc") == 0 and killed.get("phase") == "Running",
          killed)
    job = psql(f"select coalesce(external_job_id,'') from feed_executions where id={eid}")
    check("retry: the run completed on a NEW attempt (-r1)", status == "completed" and job.endswith("-r1"), job)
    if status != "completed":
        return
    raw = subprocess.run(["docker", "exec", "qs-sftp", "cat",
                          f"/home/feeduser/inbox/RP_POD_RETRY_{bd.replace('-', '')}.parquet"],
                         capture_output=True).stdout
    tbl = pq.read_table(io.BytesIO(raw))
    amt = sum(v for v in tbl.column("Transactional Currency Amount").to_pylist() if v is not None)
    want = st["truth"]["cloud"]
    check("retry: the delivered file is the PINNED snapshot's answer (rows + amount == pre-commit truth)",
          tbl.num_rows == want["rows"] and abs(amt - want["amount"]) < 1e-3,
          f"{tbl.num_rows} rows, amount {amt} vs {want['rows']} / {want['amount']}")
    back = cloud_cli(f"SELECT count(*) FROM {schema}.fact_tetb").strip().strip('"')
    check("retry: rolled back to the original snapshot", int(back) == st["cloud"]["fact_tetb"]["rows"], back)


def main():
    which = sys.argv[1:] or ["mor", "iceberg", "hive"]
    st = json.load(open(STATE))
    tag, truth = st["tag"], st["truth"]
    r = Rig()
    if "mor" in which:
        case_mor(r, st["bd"])
    if "iceberg" in which:
        case_join(r, st["bd"], "iceberg", lambda c: c["name"] == "aws-real",
                  {"primary": {"icbg.fins.fact_tetb": f"jq_tetb_{tag}",
                               "icbg.fins.fact_tetb_ext": f"jq_ext_{tag}"}}, truth["cloud"]["rows"])
    if "hive" in which:
        case_join(r, st["bd"], "hive", lambda c: c["connection_type"] == "s3"
                  and (c.get("config") or {}).get("bucket_name") == "qs-data",
                  {"primary": {"icbg.fins.fact_tetb": f"hv_fact_tetb_{tag}",
                               "icbg.fins.fact_tetb_ext": f"hv_fact_tetb_ext_{tag}"}}, truth["prem"]["rows"])
    for case, fn in (("two_sides", case_two_sides), ("snapshot", case_snapshot_moves),
                     ("schema", case_schema_evolves), ("retry", case_retry_reads_the_pinned_plan),
                     ("file_appears", case_file_appears), ("refusals", case_refusals)):
        if case in which:
            fn(r, st)
    path = os.path.join(HERE, f"read-plan-pod-results.{'-'.join(which)}.json")
    json.dump({"checks": CHECKS}, open(path, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
