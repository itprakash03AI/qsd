"""The report page says "Waiting for server capacity" while the cap is full -- live (2026-09-29).

Login rig with docker-compose.load-users.yml.  While the API's global query cap
is PROVABLY full, the browser spec docker-capacity-wait.spec.ts signs in as
rig_analyst, runs a report, and must show ``data-testid=capacity-wait``
("Waiting for server capacity"), then the rows once the slots are released.

DETERMINISTIC SATURATION (2026-10-04).  The first version kept the cap busy
with eight loops of short Trino scans: between one scan ending and the next
being admitted there were gaps (102 scans, only 11 refusals), the analyst's
report got a slot in one of them and ran without waiting, and the spec failed
although the product behaved correctly.  Now:

1. the cap is read from the server (the API process's own config), and
   ``cap`` HOLDERS are submitted -- one per load user through the SQL editor
   lane (``/api/sql/execute``, which takes a slot in the global cap) -- each a
   Trino statement that never finishes on its own (a count over a
   10,000 x 10,000 x 10,000 UNNEST cross join, ~1 core each, single split);
2. BEFORE the browser starts, the server must show in-use == cap, all of it
   held by the holders, on several consecutive samples of
   ``/api/admin/user-stats`` (the process's own counter, read under its lock),
   AND a probe from another user must WAIT in the server's pod-wide fair
   queue -- no answer, counted by the server as ``waiting_now`` -- and be
   served once the cap frees (2026-10-07: an interactive run at the global
   cap queues fairly instead of being refused at once);
3. a sampler keeps reading in-use while the browser runs; from "full" until
   the release every sample must still be == cap (the window had no gap);
4. the spec writes a signal file when the page shows the wait; only then
   does the harness RELEASE (the product's cancel route, per holder), then
   checks every holder's slot is back and that Trino has no holder left
   running.  The spec then needs the rows to render.

Everything the run creates is removed in a ``finally`` (report via the
ledger; holders cancelled, and any holder still running on Trino killed at
the coordinator as a backstop).

    python capacity_wait_proof.py [--runs 3]      # QS_RIG_*_PW and QS_LOAD_PW in the env
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
import threading
import time

sys.path.insert(0, os.path.dirname(__file__))
import multiuser_load as m  # noqa: E402
import qs_docker_client as c  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402

TRINO_CONN = 2
#: A Trino statement that occupies its slot until it is cancelled: one split,
#: ~1 core, 10^12 rows to count.  The tag lets the harness find it on Trino.
HOLD_SQL = ("SELECT count(*) AS n, max('{tag}') AS tag FROM UNNEST(sequence(1, 10000)) a(x) "
            "CROSS JOIN UNNEST(sequence(1, 10000)) b(y) CROSS JOIN UNNEST(sequence(1, 10000)) c(z)")
FRONTEND = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "frontend")
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")

res: list = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  -- {str(detail)[:300]}" if detail != "" else ""))
    return bool(ok)


def cap_of():
    """The API process's global cap, read from its own config."""
    p = subprocess.run(["docker", "exec", "qs-local-api", "python", "-c",
                        "from core.config import query_engine as q; "
                        "print(q.max_concurrent_global, q.max_concurrent_per_user)"],
                       capture_output=True, text=True, env=DENV)
    if p.returncode != 0:
        raise SystemExit(f"could not read the cap from qs-local-api: {p.stderr[-300:]}")
    cap, per_user = (int(x) for x in p.stdout.strip().splitlines()[-1].split())
    return cap, per_user


def trino(sql):
    p = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                       capture_output=True, text=True, timeout=120, env=DENV)
    return p.returncode, [ln.split("\t") for ln in p.stdout.strip().splitlines() if ln.strip()]


def trino_holders(tag):
    """query ids of holder statements still RUNNING/QUEUED on Trino."""
    rc, rows = trino("SELECT query_id FROM system.runtime.queries WHERE state IN ('RUNNING','QUEUED','PLANNING',"
                     f"'STARTING','DISPATCHING','WAITING_FOR_RESOURCES') AND query LIKE '%{tag}%' "
                     "AND query NOT LIKE '%system.runtime%'")
    return [r[0] for r in rows] if rc == 0 else None


def waiting(admin):
    """{username: waiting_now} -- runs waiting for a slot, from the API process
    (its per-user queue + the pod-wide fair queue, 2026-10-07)."""
    s, b, _ = admin.call("GET", "/api/admin/user-stats")
    if s != 200 or not isinstance(b, list):
        return None
    return {r["username"]: int(r.get("waiting_now") or 0) for r in b if r.get("waiting_now")}


def in_use(admin):
    """{username: active_now} for every non-zero counter, from the API process."""
    s, b, _ = admin.call("GET", "/api/admin/user-stats")
    if s != 200 or not isinstance(b, list):
        return None
    return {r["username"]: int(r.get("active_now") or 0) for r in b if r.get("active_now")}


class Sampler:
    """Reads in-use every 0.25 s; keeps (t, total, holders' total)."""

    def __init__(self, admin, holder_users):
        self.admin, self.users = admin, set(holder_users)
        self.samples: list = []
        self.stop = threading.Event()

    def run(self):
        while not self.stop.is_set():
            u = in_use(self.admin)
            if u is not None:
                self.samples.append((time.time(), sum(u.values()),
                                     sum(n for k, n in u.items() if k in self.users)))
            time.sleep(0.25)

    def __enter__(self):
        self.t = threading.Thread(target=self.run, daemon=True)
        self.t.start()
        return self

    def __exit__(self, *a):
        self.stop.set()
        self.t.join(timeout=30)


class Holders:
    """``n`` statements that each hold one slot of the global cap until released.

    The SQL editor lane takes its global slot at ADMISSION, then awaits a
    worker of the INTERACTIVE pool (3 on the rig) inside the request: the
    first ``pool`` holders run on Trino and answer with their execution id,
    the rest stay ADMITTED -- slot held, execution row ``pending`` -- in the
    pool's queue with their request open.  Both kinds count in the global cap
    exactly as the product counts them; ``ids()`` finds every holder's
    execution through its owner's ``/api/executions/active``.
    """

    def __init__(self, tokens, tag):
        self.tokens, self.tag = tokens, tag     # {user: token}, one holder per user
        self.answers: dict = {}                 # user -> (status, body) once the POST returns
        self.threads: list = []
        # an execution these users already had in flight is NOT a holder (a
        # run killed mid-way leaves rows 'pending'): counted, never cancelled
        self.preexisting = set(self.ids())

    def submit_all(self):
        def one(user, k):
            s, b, h, _ = m.http("POST", m.API, "/api/sql/execute", {
                "primary_connection_id": TRINO_CONN, "row_limit": 5,
                "primary_sql": HOLD_SQL.format(tag=f"{self.tag}-{k}")}, self.tokens[user], timeout=1200)
            self.answers[user] = (s, b)
        for k, user in enumerate(self.tokens, 1):
            t = threading.Thread(target=one, args=(user, k), daemon=True)
            t.start()
            self.threads.append(t)
            time.sleep(0.1)

    def refused(self):
        return {u: a for u, a in self.answers.items() if a[0] != 200}

    def ids(self):
        """{execution_id: (user, status)} for every holder still in flight."""
        out = {}
        for user, tok in self.tokens.items():
            s, b, _, _ = m.http("GET", m.API, "/api/executions/active", token=tok, timeout=30)
            for r in (b or {}).get("executions") or [] if isinstance(b, dict) else []:
                if r["execution_id"] not in getattr(self, "preexisting", ()):
                    out[r["execution_id"]] = (user, r.get("status"))
        return out

    def release(self):
        """Cancel every holder through the product's cancel route, as its owner:
        the QUEUED ones first (so a worker freed by a running one never starts
        another holder), then the running ones.  Repeats until none is in
        flight.  Returns the cancel routes' statuses."""
        codes = []
        for _ in range(10):
            live = self.ids()
            if not live:
                break
            order = sorted(live.items(), key=lambda kv: kv[1][1] != "pending")
            for eid, (user, _st) in order:
                s, _, _, _ = m.http("POST", m.API, f"/api/executions/{eid}/cancel", {}, self.tokens[user],
                                    timeout=60)
                codes.append(s)
            time.sleep(1.0)
        return codes

    def join(self, timeout=60):
        for t in self.threads:
            t.join(timeout=timeout)
        return [t for t in self.threads if t.is_alive()]


def run_once(n, admin, an_pw, load_pw, cap, per_user):
    tag = f"capwait-hold-{m.TAG}-{n}"
    print(f"\n== run {n}: cap {cap} (per user {per_user}), holders tagged {tag}")
    ledger = Ledger(admin.call)
    holders = None
    proc = None
    sig_dir = tempfile.mkdtemp(prefix="capwait_")
    signal = os.path.join(sig_dir, "waiting.txt")
    try:
        # the analyst's report: a filter unique to this run so no result
        # cache or stored instance can answer it -- it must take a slot
        an = m.login("rig_analyst", an_pw)[0]
        s, rep, _, _ = m.http("POST", m.API, "/api/business-reports", {
            "name": f"capwait-{m.TAG}-{n}", "dataset_id": c.DS, "data_source_type": "dataset",
            "column_ids": [c.COL["region"], c.COL["amt"]],
            "filter_specs": [{"column_id": c.COL["region"], "operator": "neq", "value": f"none-{tag}"}]}, an)
        if not check("the analyst creates the report", s == 200 and (rep or {}).get("id"), (s, str(rep)[:160])):
            return False
        rid = rep["id"]
        ledger.add("business report", rid, path=f"/api/business-reports/{rid}")

        if cap > 25:
            raise SystemExit(f"cap {cap} > 25 load users -- one holder per user is the design")
        tokens = {f"lt_{k:02d}": m.login(f"lt_{k:02d}", load_pw)[0] for k in range(1, cap + 2)}
        probe_user = f"lt_{cap + 1:02d}"
        holder_tokens = {u: t for u, t in tokens.items() if u != probe_user}
        holders = Holders(holder_tokens, tag)
        if holders.preexisting:
            print(f"   note: {len(holders.preexisting)} execution(s) already in flight for the holder users "
                  f"before this run -- excluded")
        holders.submit_all()

        # ── the cap is FULL, proven by the server, before the browser starts ──
        full_since, streak, last = None, 0, None
        for _ in range(240):
            if holders.refused():
                break
            last = in_use(admin)
            held = sum(v for k, v in (last or {}).items() if k in holder_tokens)
            if last is not None and sum(last.values()) == cap and held == cap:
                streak += 1
                if streak >= 4:
                    full_since = time.time()
                    break
            else:
                streak = 0
            time.sleep(0.25)
        check(f"{cap} holders admitted (none refused)", not holders.refused(),
              {u: (s, str(b)[:120]) for u, (s, b) in holders.refused().items()})
        if not check(f"the server's in-use == cap ({cap}), all of it held by the holders, 4 samples in a row",
                     full_since is not None, last):
            return False
        s, wp, _ = admin.call("GET", "/api/admin/worker-pool")
        inter = ((wp or {}).get("by_type") or {}).get("INTERACTIVE") or {}
        print(f"   worker pool INTERACTIVE: running {inter.get('running')}, queued {inter.get('queued')} "
              f"(max {inter.get('max_concurrent')}) -- every one holds its slot in the global cap")
        # 2026-10-07: at the global cap an interactive run WAITS in the
        # pod-wide fair queue (it used to be refused at once) -- the probe
        # must get NO answer while the cap is full and be counted by the
        # server as waiting; it is served after the release (checked below).
        sql = f"SELECT count(*) FROM {m.TABLE} WHERE region = 'probe-{tag}'"
        probe_out: dict = {}

        def _probe():
            probe_out["r"] = m.http("POST", m.API, "/api/sql/execute",
                                    {"primary_connection_id": TRINO_CONN, "primary_sql": sql,
                                     "row_limit": 5}, tokens[probe_user], timeout=600)
        probe_t = threading.Thread(target=_probe, daemon=True)
        probe_t.start()
        seen_waiting = None
        for _ in range(60):
            if "r" in probe_out:
                break
            w = waiting(admin) or {}
            if w.get(probe_user):
                seen_waiting = w
                break
            time.sleep(0.25)
        if not check(f"a probe from {probe_user} WAITS in the server's fair queue (no answer, waiting_now >= 1)",
                     seen_waiting is not None and "r" not in probe_out,
                     probe_out.get("r", (None,))[0] if "r" in probe_out else seen_waiting):
            return False
        st = holders.ids()
        check(f"every holder is in flight on the server ({cap} executions pending/processing)",
              len(st) == cap and all(v[1] in ("pending", "processing", "running") for v in st.values()),
              sorted(v[1] for v in st.values()))

        # ── the browser run, while the cap stays full ──
        env = dict(os.environ, QS_WALK_USER="rig_analyst", QS_WALK_PASS=an_pw,
                   QS_CAPWAIT_REPORT_ID=str(rid), QS_CAPWAIT_SIGNAL=signal)
        released_at = None
        with Sampler(admin, holder_tokens) as smp:
            proc = subprocess.Popen("npx playwright test -c playwright.docker.config.ts docker-capacity-wait",
                                    cwd=FRONTEND, env=env, shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
            lines: list = []
            reader = threading.Thread(target=lambda: lines.extend(proc.stdout), daemon=True)
            reader.start()
            end = time.time() + 180
            while time.time() < end and proc.poll() is None and not os.path.exists(signal):
                time.sleep(0.2)
            saw_wait = os.path.exists(signal)
            # what the server said while the page showed the wait
            during = in_use(admin)
            st_during = holders.ids()
            released_at = time.time()
            codes = holders.release()
            s_live, _, _, dt_live = m.http("GET", m.API, "/health/live", timeout=15)
            if s_live != 200:
                # 2026-10-04: a cancel of a pool task whose future had not
                # started self-deadlocked the API's event loop (worker_pool
                # _cancel_record).  Say so at once instead of hanging on it.
                holders.tokens = {}              # nothing more to cancel through a dead API
                raise SystemExit(f"the API stopped answering after the holders' cancels "
                                 f"(/health/live -> {s_live} in {dt_live:.0f}s; cancel statuses {codes}) "
                                 f"-- see backend/tests/test_worker_pool_cancel_pending_future_2026_10_04.py")
            check("the page showed the wait while the cap was full (signal from the spec)", saw_wait,
                  "" if saw_wait else "the spec ended or timed out without seeing data-testid=capacity-wait")
            check(f"at that moment the server still had {cap}/{cap} in use, all holders",
                  during is not None and sum(during.values()) == cap
                  and sum(v for k, v in during.items() if k in holder_tokens) == cap, during)
            check("...and every holder was still in flight", len(st_during) == cap and all(
                v[1] in ("pending", "processing", "running") for v in st_during.values()),
                sorted(v[1] for v in st_during.values()))
            check("every holder released through the product's cancel route (200)",
                  len(codes) >= cap and all(x == 200 for x in codes), codes)
            # the holders' slots come back
            back = None
            for _ in range(120):
                back = in_use(admin)
                if back is not None and not any(k in holder_tokens for k in back):
                    break
                time.sleep(0.25)
            check("every holder's slot is back (the server's counters for the holders are 0)",
                  back is not None and not any(k in holder_tokens for k in back), back)
            left = None
            for _ in range(40):
                left = trino_holders(tag)
                if left == []:
                    break
                time.sleep(0.5)
            check("no holder statement is still running on Trino (the cancel reached the coordinator)",
                  left == [], left)
            stuck = holders.join(timeout=60)
            check("every holder's request returned after its cancel", not stuck, f"{len(stuck)} still open")
            probe_t.join(timeout=120)
            ps, pb = (probe_out.get("r") or (None, None))[:2]
            check("the waiting probe was SERVED once the cap freed (200 + an execution id)",
                  ps == 200 and isinstance(pb, dict) and pb.get("execution_id"), (ps, str(pb)[:160]))
            rc = proc.wait(timeout=300)
            reader.join(timeout=10)
        window = [x for x in smp.samples if full_since <= x[0] <= released_at - 0.3]
        check(f"from 'full' to the release the cap never had a gap: every sample in-use == {cap}",
              len(window) >= 4 and all(t == cap and hd == cap for _, t, hd in window),
              f"{len(window)} samples over {released_at - full_since:.1f}s, "
              f"min total {min((t for _, t, _ in window), default=None)}, "
              f"min held {min((hd for _, _, hd in window), default=None)}")
        for ln in lines:
            if any(k in ln for k in ("CAPACITY_WAIT_TEXT", "passed", "failed", "Error:", "Expected", "Received",
                                     "Timeout", "timed out")):
                print("   " + ln.strip()[:260])
        check("the browser spec passed (wait shown, then the rows)", rc == 0, f"exit {rc}")
        return True
    finally:
        if holders:
            holders.release()                    # no-op when nothing is in flight
            for qid in (trino_holders(tag) or []):
                trino(f"CALL system.runtime.kill_query(query_id => '{qid}', message => 'capacity_wait_proof cleanup')")
        if proc and proc.poll() is None:
            proc.kill()
        ledger.cleanup(echo=lambda s: print("  " + s))
        try:
            if os.path.exists(signal):
                os.remove(signal)
            os.rmdir(sig_dir)
        except OSError:
            pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=1, help="consecutive runs; every one must pass")
    a = ap.parse_args()
    load_pw, admin_pw, an_pw = (os.environ["QS_LOAD_PW"], os.environ["QS_RIG_ADMIN_PW"],
                                os.environ["QS_RIG_ANALYST_PW"])
    s, _, _, _ = m.http("GET", m.API, "/api/datasets")
    if s != 401:
        raise SystemExit(f"not the LOGIN rig (anonymous /api/datasets answered {s})")
    cap, per_user = cap_of()
    admin = m.Admin("rig_admin", admin_pw)
    shared = False
    try:
        _, conn, _ = admin.call("GET", f"/api/connections/{TRINO_CONN}")
        if not (conn or {}).get("is_shared"):
            body = {k: conn[k] for k in ("name", "connection_type", "config")}
            shared = admin.call("PUT", f"/api/connections/{TRINO_CONN}", {**body, "is_shared": True})[0] == 200
        per_run = []
        for n in range(1, a.runs + 1):
            before = len(res)
            run_once(n, admin, an_pw, load_pw, cap, per_user)
            per_run.append(all(res[before:]) and len(res) > before)
            time.sleep(3)
    finally:
        if shared:
            _, conn, _ = admin.call("GET", f"/api/connections/{TRINO_CONN}")
            body = {k: conn[k] for k in ("name", "connection_type", "config")}
            admin.call("PUT", f"/api/connections/{TRINO_CONN}", {**body, "is_shared": False})
    print(f"\nruns: {['PASS' if x else 'FAIL' for x in per_run]} -- {sum(res)}/{len(res)} checks passed")
    return 0 if per_run and all(per_run) else 1


if __name__ == "__main__":
    sys.exit(main())
