"""CROSS-SOURCE: cloud (Snowflake) x on-prem (Trino/Starburst Iceberg) through
every QueryStudio surface, on Docker (2026-10-04, login ON).

Owner: "we have data on-prem and in cloud, so we need to test the same cases
across sources -- real test via docker".

Cloud:   QS_DEMO.FIN.FACT_TRADES (10M rows, COUNTRY, AMOUNT, ...) on the real
         Snowflake account (connection snowflake-real).
On-prem: iceberg.qs.dim_country_risk (16 countries -> REGION, RISK_TIER,
         DESK_OWNER) and iceberg.qs.trades (1,499,672 rows: region, amt) on
         the rig's Trino.
Truth:   each side computed on its OWN engine and combined here in Python.

  X1 query builder (/api/execute): Snowflake primary JOIN Trino secondary;
  X2 query builder (/api/execute): Trino primary UNION Snowflake secondary;
  X3 SQL page (/api/sql/execute): Snowflake JOIN Trino, 1,000,000 detail rows;
  X4 federation view over Snowflake + Trino (and published as an API);
  X5 report on MERGED datasets (Snowflake dataset x Trino dataset), > 10k rows;
  X6 feed: Snowflake primary + Trino secondary, JOIN -> file.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 QS_TRINO_CONN=2 python scripts/docker_proof/cross_source_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from snowflake_wide_table_proof import sf  # noqa: E402

SF = int(os.environ.get("QS_SF_CONN", "239"))
TR = int(os.environ.get("QS_TRINO_CONN", "2"))
TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
res, results = [], {"checks": []}


def check(case, name, ok, detail=""):
    res.append(bool(ok))
    results["checks"].append({"case": case, "name": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS" if ok else "FAIL"), f"[{case}]", name, "--", str(detail)[:320], flush=True)
    return bool(ok)


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True)
    return [line.split("\t") for line in out.stdout.strip().splitlines() if line.strip()]


def poll(admin, eid, timeout=1800):
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st, _ = admin.call("GET", f"/api/executions/{eid}/status")
        s = (st or {}).get("status")
        if s in ("completed", "success", "finished"):
            return 200, st
        if s in ("failed", "error", "cancelled"):
            return 500, st
        time.sleep(1)
    return -1, {}


def rows(admin, eid, want=None, size=5000):
    out, n = [], 1
    while n < 1000:
        _, b, _ = admin.call("GET", f"/api/executions/{eid}/results?page={n}&page_size={size}")
        names = [x["name"] if isinstance(x, dict) else x for x in (b or {}).get("columns") or []]
        pr = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (b or {}).get("rows") or []]
        if not pr:
            break
        out += pr
        if want is not None and len(out) >= want:
            break
        n += 1
    return out


def low(r):
    return {str(k).lower(): v for k, v in r.items()}


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    con = sf()
    cur = con.cursor()
    cur.execute("alter session set USE_CACHED_RESULT = FALSE")
    dim = {r[0]: (r[1], r[2], r[3]) for r in trino("select country, region, risk_tier, desk_owner from iceberg.qs.dim_country_risk")}
    sf_by_country = {r[0]: Decimal(str(r[1])) for r in cur.execute(
        "select COUNTRY, sum(AMOUNT) from QS_DEMO.FIN.FACT_TRADES group by 1").fetchall()}
    tier_truth = {}
    for c, amt in sf_by_country.items():
        tier_truth[dim[c][1]] = tier_truth.get(dim[c][1], Decimal(0)) + amt
    check("setup", "truth: 16 cloud countries all mapped by the on-prem dim", len(sf_by_country) == 16 and set(sf_by_country) == set(dim),
          (len(sf_by_country), len(dim)))
    undo = []
    try:
        # ── X1 query builder: Snowflake primary JOIN Trino secondary ──────
        body = {"connection_id": SF, "output_format": "json", "cache_strategy": "bypass",
                "raw_sql": "select COUNTRY, sum(AMOUNT) as AMT from QS_DEMO.FIN.FACT_TRADES group by COUNTRY",
                "secondary_connection_id": TR,
                "secondary_raw_sql": "select country as COUNTRY_KEY, risk_tier as RISK_TIER, desk_owner as DESK_OWNER from iceberg.qs.dim_country_risk",
                "combine_mode": "join", "join_config": {"how": "inner", "left_on": ["COUNTRY"], "right_on": ["COUNTRY_KEY"]}}
        s, r, _ = admin.call("POST", "/api/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        got = [low(x) for x in rows(admin, r["execution_id"])] if st == 200 else []
        ok = (len(got) == 16 and all("risk_tier" in g for g in got)
              and all(dim[g["country"]][1] == g["risk_tier"] and Decimal(str(g["amt"])).quantize(Decimal("0.01")) == sf_by_country[g["country"]] for g in got))
        check("X1", "query builder: cloud primary JOIN on-prem secondary -> 16 countries WITH the on-prem risk tier, amounts == Snowflake",
              ok, {"status": st, "rows": len(got), "cols": sorted(got[0]) if got else None, "err": str(meta)[:200] if st != 200 else ""})

        # ── X2 query builder: Trino primary UNION Snowflake secondary ─────
        tr_reg = {r[0]: Decimal(r[1]) for r in trino("select region, sum(amt) from iceberg.qs.trades group by 1")}
        sf_reg = {r[0]: Decimal(str(r[1])) for r in cur.execute("select REGION, sum(AMT) from QS_DEMO.FIN.TRADES group by 1").fetchall()}
        body = {"connection_id": TR, "output_format": "json", "cache_strategy": "bypass",
                "raw_sql": "select region as REGION, amt as AMT, 'ONPREM' as SRC from iceberg.qs.trades",
                "secondary_connection_id": SF,
                "secondary_raw_sql": "select REGION, AMT, 'CLOUD' as SRC from QS_DEMO.FIN.TRADES",
                "combine_mode": "union"}
        s, r, _ = admin.call("POST", "/api/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        total = int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0) if st == 200 else 0
        n_tr = int(trino("select count(*) from iceberg.qs.trades")[0][0])
        check("X2", f"query builder: on-prem primary UNION cloud secondary -> {n_tr:,} + 10,000 rows",
              st == 200 and total == n_tr + 10_000, {"status": st, "total": total, "want": n_tr + 10_000, "err": str(meta)[:200] if st != 200 else ""})

        # ── X3 SQL page: Snowflake JOIN Trino, 1M detail rows ─────────────
        body = {"primary_connection_id": SF, "secondary_connection_id": TR,
                "primary_sql": "select TRADE_ID, COUNTRY, AMOUNT from QS_DEMO.FIN.FACT_TRADES where TRADE_ID <= 1000000",
                "secondary_sql": "select country, risk_tier from iceberg.qs.dim_country_risk",
                "join_config": {"how": "inner", "left_on": "COUNTRY", "right_on": "country"}}
        t0 = time.time()
        s, r, _ = admin.call("POST", "/api/sql/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        dt = round(time.time() - t0, 1)
        total = int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0) if st == 200 else 0
        sample = [low(x) for x in rows(admin, r["execution_id"], want=100, size=100)] if st == 200 else []
        tiers_ok = all(dim[x["country"]][1] == x.get("risk_tier") for x in sample) and sample
        check("X3", f"SQL page: cloud 1,000,000 rows JOIN on-prem dim -> 1,000,000 rows with the tier ({dt}s)",
              st == 200 and total == 1_000_000 and tiers_ok, {"status": st, "total": total, "s": dt, "err": str(meta)[:200] if st != 200 else ""})
        # A union spelled as a JOIN TYPE is refused with the vocabulary ...
        s, r, _ = admin.call("POST", "/api/sql/execute", dict(body, join_config={"how": "union"}))
        check("X3", "SQL page: 'union' as a JOIN type is refused naming the vocabulary -- never a silent join/primary-only",
              s in (400, 422), {"status": s, "body": str(r)[:200]})
        # ... and a real UNION (combine_mode) COMBINES: 1,000 cloud + 16 on-prem rows.
        ubody = {"primary_connection_id": SF, "secondary_connection_id": TR, "combine_mode": "union",
                 "primary_sql": "select COUNTRY, AMOUNT from QS_DEMO.FIN.FACT_TRADES where TRADE_ID <= 1000",
                 "secondary_sql": "select country as COUNTRY, cast(0 as decimal(18,2)) as AMOUNT from iceberg.qs.dim_country_risk"}
        s, r, _ = admin.call("POST", "/api/sql/execute", ubody)
        st, meta = poll(admin, (r or {}).get("execution_id")) if s == 200 else (s, r)
        total = int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0) if st == 200 else 0
        check("X3", "SQL page: cloud UNION ALL on-prem -> 1,000 + 16 rows",
              st == 200 and total == 1016, {"status": st, "total": total, "err": str(meta)[:200] if st != 200 else ""})

        # ── X4 federation view over Snowflake + Trino ─────────────────────
        s, fv, _ = admin.call("POST", "/api/federation-views", {
            "name": f"x_fed_{TAG}", "primary_conn_id": SF,
            "primary_query": {"raw_sql": "select COUNTRY, sum(AMOUNT) as AMT from QS_DEMO.FIN.FACT_TRADES group by COUNTRY"},
            "secondary_conn_id": TR,
            "secondary_query": {"raw_sql": "select country as COUNTRY_KEY, risk_tier as RISK_TIER from iceberg.qs.dim_country_risk"},
            "combine_mode": "join", "join_on": [{"left": "COUNTRY", "right": "COUNTRY_KEY"}], "join_how": "inner"})
        if s in (200, 201) and (fv or {}).get("id"):
            undo.insert(0, f"/api/federation-views/{fv['id']}")
            s2, pv, _ = admin.call("POST", f"/api/federation-views/{fv['id']}/preview")
            prev = [low(x) for x in ((pv or {}).get("rows") or (pv or {}).get("data") or [])] if isinstance(pv, dict) else []
            check("X4", "federation view: cloud JOIN on-prem -> 16 rows with the tier", s2 == 200 and len(prev) == 16 and all("risk_tier" in x for x in prev),
                  {"status": s2, "rows": len(prev), "body": str(pv)[:200]})
        else:
            check("X4", "federation view over Snowflake + Trino can be CREATED (cloud + on-prem federation)", False, {"status": s, "body": str(fv)[:300]})

        # ── X5 report on MERGED datasets (> 10k rows) ─────────────────────
        s, d1, _ = admin.call("POST", "/api/datasets", {"name": f"x_cloud_{TAG}", "subject": "x", "connection_ids": [SF],
                                                        "base_query": "select TRADE_ID, COUNTRY, AMOUNT from QS_DEMO.FIN.FACT_TRADES where TRADE_ID <= 50000"})
        s2, d2, _ = admin.call("POST", "/api/datasets", {"name": f"x_onprem_{TAG}", "subject": "x", "connection_ids": [TR],
                                                         "base_query": "select country, risk_tier from iceberg.qs.dim_country_risk"})
        if s in (200, 201) and s2 in (200, 201):
            undo.insert(0, f"/api/datasets/{d1['id']}")
            undo.insert(0, f"/api/datasets/{d2['id']}")
            for d in (d1, d2):
                admin.call("POST", f"/api/datasets/{d['id']}/auto-detect", {})
            c1 = {x["physical_name"].upper(): x for x in admin.call("GET", f"/api/datasets/{d1['id']}")[1]["columns"]}
            c2 = {x["physical_name"].upper(): x for x in admin.call("GET", f"/api/datasets/{d2['id']}")[1]["columns"]}
            for c in c1.values():
                admin.call("PUT", f"/api/datasets/columns/{c['id']}", {"column_type": "dimension"})
            s, rep, _ = admin.call("POST", "/api/business-reports", {
                "name": f"x-merged-{TAG}", "dataset_id": d1["id"], "data_source_type": "dataset",
                "column_ids": [c1["TRADE_ID"]["id"], c1["COUNTRY"]["id"], c1["AMOUNT"]["id"]],
                "merged_dataset_id": d2["id"], "merged_dataset_column_ids": [c2["COUNTRY"]["id"], c2["RISK_TIER"]["id"]],
                "merge_config": {"merge_keys": [{"left": "COUNTRY", "right": "country"}], "merge_type": "inner"}})
            if check("X5", "merged report created (cloud dataset x on-prem dataset)", s == 200, (s, str(rep)[:240])):
                undo.insert(0, f"/api/business-reports/{rep['id']}")
                s, ex, _ = admin.call("POST", f"/api/business-reports/{rep['id']}/execute", {"parameter_values": {}, "force_refresh": True})
                tot = int((ex or {}).get("total_rows") or 0) if isinstance(ex, dict) else 0
                check("X5", "merged report: all 50,000 cloud rows carry the on-prem tier (no silent per-side cap)",
                      s == 200 and tot == 50_000, {"status": s, "total": tot, "truncated": (ex or {}).get("truncated") if isinstance(ex, dict) else None,
                                                   "body": str(ex)[:240] if s != 200 else ""})

        # ── X6 feed: Snowflake primary + Trino secondary JOIN -> file ─────
        def saved(name, conn, sql):
            s, q, _ = admin.call("POST", "/api/queries", {"name": name, "query_config": {"files": [], "raw_sql": sql, "connection_id": conn}})
            if s in (200, 201):
                undo.append(f"/api/queries/{q['id']}")
            return s, q
        s1, q1 = saved(f"x_sq_cloud_{TAG}", SF, "select COUNTRY, sum(AMOUNT) as AMT from QS_DEMO.FIN.FACT_TRADES group by COUNTRY")
        s2, q2 = saved(f"x_sq_onprem_{TAG}", TR, "select country as COUNTRY_KEY, risk_tier as RISK_TIER from iceberg.qs.dim_country_risk")
        if check("X6", "two saved queries (cloud, on-prem) created", s1 in (200, 201) and s2 in (200, 201), (s1, s2, str(q1)[:160], str(q2)[:160])):
            s, fb, _ = admin.call("POST", "/api/feeds", {
                "name": f"X_FEED_{TAG}", "source_type": "saved_query", "source_id": q1["id"], "connection_id": SF,
                "secondary_connection_id": TR, "secondary_source_type": "saved_query", "secondary_source_id": q2["id"],
                "combine_mode": "join", "join_config": {"how": "inner", "left_on": ["COUNTRY"], "right_on": ["COUNTRY_KEY"]},
                "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
                "execution_backend": "native"})
            if check("X6", "cross-source feed created", s == 200, (s, str(fb)[:300])):
                undo.insert(0, f"/api/feeds/{fb['id']}")
                s, ex, _ = admin.call("POST", f"/api/feeds/{fb['id']}/execute", {"trigger_type": "manual"})
                dbid = (ex or {}).get("execution_db_id")
                e, t0 = {}, time.time()
                while dbid and time.time() - t0 < 600:
                    _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                    if (e or {}).get("status") in ("completed", "failed", "error", "cancelled"):
                        break
                    time.sleep(2)
                body_txt = ""
                if e.get("destination_path"):
                    body_txt = subprocess.run(["docker", "exec", "qs-local-api", "cat", e["destination_path"]], capture_output=True,
                                              text=True, env=DENV).stdout
                    subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", e["destination_path"]], env=DENV)
                lines = body_txt.splitlines()
                hdr = [h.strip().upper() for h in lines[0].split(",")] if lines else []
                rows_ = [dict(zip(hdr, ln.split(","))) for ln in lines[1:] if ln.strip()]
                ok = (e.get("status") == "completed" and len(rows_) == 16
                      and all(dim[r_["COUNTRY"]][1] == r_.get("RISK_TIER") and Decimal(r_["AMT"]).quantize(Decimal("0.01")) == sf_by_country[r_["COUNTRY"]] for r_ in rows_))
                check("X6", "cross-source feed: the delivered file JOINs cloud amounts to the on-prem tier, == both sources",
                      ok, {"status": e.get("status"), "rows": len(rows_), "hdr": hdr, "err": str(e.get("error_message"))[:240]})
    finally:
        for p in undo:
            admin.call("DELETE", p)
        con.close()
        print(f"\ncleanup: {len(undo)} removed")
    with open(os.environ.get("QS_PERF_OUT", "cross-source-results.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1, default=str)
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
