"""The owner's REAL case on the live Docker rig: N monthly feeds, one per
(SYSTEM_ENTITY, EventCode), each held on a Kafka "partition ready" message,
each running the owner's CLOUD query and ON-PREM query (two DIFFERENT
connections), merging them BY COLUMN NAME and delivering ONE file by SFTP
(2026-10-10; record docs/MONTHLY_KAFKA_MERGE_FEEDS_2026_10_10.html).

Stand-ins on the rig (two different clusters, one lake):
  cloud    qs-trino      (the rig's Trino, connection TRINO_LOCAL / --cloud-conn)
  on-prem  qs-trino-sb   (the Starburst-SHAPED second Trino of
                          scripts/docker_proof/starburst_like/: HTTPS, password
                          login; a connection is created for this run, or
                          --onprem-conn names an existing one)
Both see iceberg.qs.* on qs-minio, so the harness creates the owner's two
tables there from scripts/docker_proof/fixtures/test_query_001.json -- the
cloud table with every column the cloud query reads (75 projected), the
on-prem table with every column the on-prem query reads (73, a different
physical order) -- partitioned by (business_close_date, code, businessevent),
and runs the owner's SQL VERBATIM but for the table names.  The truth is the
Trino CLI inside qs-trino, no QueryStudio code on the path.

What is proven, per run:
  A  bulk authoring: POST /api/feed-templates with an N-row matrix -> N feeds,
     each with its own TETB_<entity>_<event> Kafka dependency; a second apply
     creates nothing (N unchanged); timings.
  B  the HOLD: a backfill run per member is born WAIT; after 30 s nothing ran.
  C  an UNKNOWN combination's message is recorded as unmatched (the admin
     route lists it), never dropped, and releases nothing.
  D  the RELEASE: one message per island (plus a duplicate of the first at a
     new offset) -> every run flips to RUN (the poller), runs (the queue
     worker), delivers; timings from the first produce to the last file.
  E  every file: the header is the cloud query's 75 columns in its order;
     rows == cloud island UNION ALL on-prem island (count AND multiset on the
     identity columns, vs Trino; the compared count is asserted NON-ZERO);
     no row from another island or another date (one island per side);
     files_metadata.cross_source says primary + secondary == expected ==
     delivered; the certificate reconciles source == dest; the SFTP file is
     read ON the server (docker exec qs-sftp).
  F  the duplicate message: feed 0 has exactly one run and one completed
     execution; the replay is a regeneration decision.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    docker compose -f docker-compose.local.yml \\
                   -f scripts/docker_proof/compose/monthly_kafka_merge.override.yml \\
                   --profile workers up -d kafka api scheduler
    python scripts/docker_proof/monthly_kafka_merge_feeds_proof.py --plan
    python scripts/docker_proof/monthly_kafka_merge_feeds_proof.py --n 50
    python scripts/docker_proof/monthly_kafka_merge_feeds_proof.py --n 400

Everything this run creates is removed in a finally (proof_cleanup Ledger);
``--sweep-leftovers [--execute]`` finds a killed run's objects by name.
"""
from __future__ import annotations

import argparse
import base64
import collections
import csv
import datetime as dt
import io
import json
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feed_dependencies_proof import (  # noqa: E402
    broker_healthy, broker_running, docker, rpk,
)
from feed_triggers_proof import Rig, check, psql, res, trino, wait_until  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402

os.environ.setdefault("MSYS_NO_PATHCONV", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "test_query_001.json")
TAG = str(int(time.time()))[-6:]
TOPIC = "tetb.partition.ready"
TEMPLATE_NAME = f"TETB_MONTHLY_{TAG}"
CLOUD_TABLE = f"iceberg.qs.fact_tetb_ext_{TAG}"


def await_template_apply(r, s, body, timeout=7200):
    """A template apply answers 201 / 200 with the report inline, or 202
    with a JOB (2026-10-10: a matrix over SYNC_APPLY_MAX_ROWS rows runs in
    the background) -- poll ``GET /api/feed-templates/{id}/apply-status``
    to the report.  Returns ``(effective status, report, mode)`` where the
    effective status is what the inline answer would have been."""
    if s != 202:
        return s, (body or {}).get("report") or {}, "inline"
    tid = ((body or {}).get("template") or {}).get("id") or (body or {}).get("template_id")

    def _done():
        st, js = r.call("GET", f"/api/feed-templates/{tid}/apply-status")
        job = (js or {}).get("job") or {}
        return job if st == 200 and job.get("state") in ("completed", "failed") else None
    job, waited = wait_until(_done, timeout, every=2)
    if not job:
        return 504, {"error": f"apply job did not finish in {waited}s"}, "background"
    if job["state"] == "failed":
        return 500, {"error": job.get("error")}, "background"
    inline_status = 201 if "template" in (body or {}) else 200
    return inline_status, job.get("report") or {}, f"background job {job['job_id']}, {waited}s"
ONPREM_TABLE = f"iceberg.qs.fact_tetb_ext_onprem_{TAG}"
SFTP = {"container": "qs-sftp", "host": "qs-sftp", "port": 22, "username": "feeduser",
        "password": "FeedPass_123", "remote_dir": "/inbox", "home": "/home/feeduser/inbox"}
SB_HOST, SB_PORT = "qs-trino-sb", 8443
EVENTS = ("EOM", "MTD")
DATE_COLS = {"BUSINESS_CLOSE_DATE", "INITIAL_POSTING_DT", "ADJ_ENRICH_CREATED"}
BIGINT_COLS = {"SNAP_VERSION"}
#: the columns the file is compared on (identity + a text + a number)
COMPARE = ("BUSINESS_CLOSE_DATE", "SOURCE_DATA_ROW", "USERNAME", "PARTITION_KEY",
           "TRAN_CURRENCY_NAME", "SNAP_VERSION")


# ── the owner's queries, read from the fixture ───────────────────────────

_CAST_RE = re.compile(r'CAST\((?:FACT_TETB_EXT\.)?([A-Z0-9_]+)\s+AS\s+(VARCHAR|DATE)\)\s+AS\s+"([A-Z0-9_]+)"')
_BARE_RE = re.compile(r'^\s*FACT_TETB_EXT\.([A-Z0-9_]+)\s*$')


def _select_items(select: str):
    """The SELECT list split on top-level commas (a CAST holds none, the
    PARTITION_KEY concatenation holds quoted ones)."""
    depth, buf, quote = 0, "", ""
    for ch in select:
        if quote:
            buf += ch
            if ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            yield buf
            buf = ""
            continue
        buf += ch
    if buf.strip():
        yield buf


def parse_query(sql: str):
    """``(projected aliases in order, base columns referenced in order)``
    from the owner's SELECT: ``CAST(x AS T) AS "ALIAS"`` items, the
    ``PARTITION_KEY`` concatenation, and the two bare trailing columns
    (unquoted, so Trino folds their names to lower case)."""
    select = sql.split(" FROM ")[0]
    select = select[len("SELECT "):] if select.upper().startswith("SELECT ") else select
    aliases, bases = [], []
    for item in _select_items(select):
        m = _CAST_RE.search(item)
        if m:
            aliases.append(m.group(3))
            bases.append(m.group(1))
            continue
        if "PARTITION_KEY" in item:
            aliases.append("PARTITION_KEY")
            bases.extend(["CODE", "BUSINESSEVENT"])
            continue
        b = _BARE_RE.match(item)
        if b:
            aliases.append(b.group(1).lower())
            bases.append(b.group(1))
            continue
        raise SystemExit(f"fixture SELECT item not understood: {item[:80]!r}")
    for b in ("CODE", "BUSINESSEVENT"):
        if b not in bases:
            bases.append(b)
    seen, uniq = set(), []
    for b in bases:
        if b not in seen:
            seen.add(b)
            uniq.append(b)
    return aliases, uniq


def ddl(table: str, cols) -> str:
    def typ(c):
        if c in DATE_COLS:
            return "DATE"
        if c in BIGINT_COLS:
            return "BIGINT"
        return "VARCHAR"
    body = ", ".join(f"{c.lower()} {typ(c)}" for c in cols)
    return (f"CREATE TABLE {table} ({body}) WITH (partitioning = ARRAY["
            f"'business_close_date', 'code', 'businessevent'])")


def trino_stdin(sql: str) -> str:
    """A statement too long for a command line goes in on stdin."""
    # --file needs a TERMINATED statement ("Non-terminated statement: SELECT"):
    # the owner's SQL carries none, and must not have to.
    sql = sql.rstrip().rstrip(";") + ";"
    r = subprocess.run(["docker", "exec", "-i", "qs-trino", "trino", "--output-format", "TSV",
                        "--file", "/dev/stdin"], input=sql, capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        # the CLI echoes the statement around its verdict: lead with the
        # "Query ... failed:" / "LINE n:" lines, never the echo's tail
        out = (r.stderr or "") + (r.stdout or "")
        verdict = [ln for ln in out.splitlines()
                   if "failed:" in ln or ln.startswith("LINE ") or "Error" in ln][:4]
        raise RuntimeError(f"trino stdin failed (exit {r.returncode}): " + (" | ".join(verdict) or ("HEAD: " + out[:500] + " ... TAIL: " + out[-200:])))
    return r.stdout


def lit(v) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, dt.date):
        return f"DATE '{v.isoformat()}'"
    return "'" + str(v).replace("'", "''") + "'"


def row_values(side: str, cols, date: dt.date, entity: str, event: str, i: int):
    out = []
    for c in cols:
        if c == "BUSINESS_CLOSE_DATE":
            out.append(date)
        elif c == "CODE":
            out.append(entity)
        elif c == "BUSINESSEVENT":
            out.append(event)
        elif c == "SOURCE_DATA_ROW":
            out.append(f"{side}:{entity}:{event}:{i}")
        elif c == "USERNAME":
            out.append(f"user_{side}")
        elif c == "TRAN_CURRENCY_NAME":
            out.append("GBP" if side == "cloud" else "USD")
        elif c in DATE_COLS:
            out.append(date)
        elif c in BIGINT_COLS:
            out.append(i)
        else:
            out.append(f"{c[:12].lower()}{i}")
    return out


def insert_rows(table: str, cols, rows) -> int:
    n = 0
    for k in range(0, len(rows), 50):
        batch = rows[k:k + 50]
        values = ",\n".join("(" + ", ".join(lit(v) for v in r) + ")" for r in batch)
        trino_stdin(f"INSERT INTO {table} ({', '.join(c.lower() for c in cols)}) VALUES\n{values};\n")
        n += len(batch)
    return n


# ── the rig ──────────────────────────────────────────────────────────────

def connections(r: Rig):
    _, cl = r.call("GET", "/api/connections")
    return cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []


def pick_cloud(r: Rig, want):
    items = connections(r)
    if want:
        hit = next((x for x in items if str(x.get("id")) == str(want) or x.get("name") == want), None)
        if not hit:
            raise SystemExit(f"--cloud-conn {want!r}: no such connection")
        return hit["id"], hit["name"]
    for x in items:
        cfg = x.get("config") or {}
        if str(x.get("connection_type")).lower() in ("trino", "starburst") and \
                str(cfg.get("host") or "") in ("qs-trino", "trino"):
            return x["id"], x["name"]
    raise SystemExit("no Trino connection on qs-trino found; pass --cloud-conn")


def sftp_host_key() -> str:
    rc, out, err = docker("exec", SFTP["container"], "cat", "/etc/ssh/ssh_host_ed25519_key.pub")
    if rc != 0 or not out:
        raise SystemExit(f"could not read qs-sftp's host key: {err[-200:]}")
    return out.split()[1]


def sftp_ls(name: str) -> int | None:
    rc, out, _ = docker("exec", SFTP["container"], "stat", "-c", "%s", f"{SFTP['home']}/{name}")
    return int(out) if rc == 0 and out.strip().isdigit() else None


def sftp_read(name: str) -> str:
    rc, out, err = docker("exec", SFTP["container"], "cat", f"{SFTP['home']}/{name}")
    if rc != 0:
        raise RuntimeError(f"cat {name}: {err[-200:]}")
    return out


def produce_many(lines) -> int:
    rc, out = rpk("topic", "produce", TOPIC, "-f", "%v\\n", stdin="".join(l + "\n" for l in lines))
    if rc != 0:
        raise RuntimeError(f"produce failed: {out[-300:]}")
    return out.count("Produced")


def day(n: int) -> dt.date:
    return dt.date.today() - dt.timedelta(days=n)


# ── plan ─────────────────────────────────────────────────────────────────

def plan(args):
    print(__doc__)
    print("NEEDS")
    print("  containers : qs-local-api, qs-local-scheduler (profile workers), qs-local-postgres,")
    print("               qs-kafka (the override), qs-trino + qs-minio, qs-trino-sb (starburst_like), qs-sftp")
    print("  env        : QS_RIG_ADMIN_PW (. ~/.qs_keys/rigpw.sh), QS_SB_ANALYST_PW (. ~/.qs_keys/starburst_like.env)")
    print("  compose    : docker compose -f docker-compose.local.yml \\")
    print("                 -f scripts/docker_proof/compose/monthly_kafka_merge.override.yml --profile workers up -d kafka api scheduler")
    print("  sb         : sh scripts/docker_proof/starburst_like/make_certs.sh && docker compose -f docker-compose.local.yml \\")
    print("                 -f scripts/docker_proof/compose/starburst_like.override.yml up -d qs-trino-sb")
    print(f"  this run   : --n {args.n} feeds, {args.rows} cloud rows + {args.rows + 1} on-prem rows per island,"
          f" business date {args.date}, backend {args.backend}")
    print("  creates    : 2 Iceberg tables in iceberg.qs, 2 saved queries, 1 Starburst-shaped connection,")
    print(f"               1 feed template + {args.n} feeds + {args.n} runs, {args.n} SFTP files -- all removed in finally")
    print("  expect     : release -> delivered bounded by the queue worker's slots (max_concurrent_native, 3/pod)")


# ── main ─────────────────────────────────────────────────────────────────

def main(argv=None):
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--rows", type=int, default=3, help="cloud rows per island (on-prem gets rows+1)")
    # the template is month_end (schedule_declaration): any other date is a
    # correct ACTION_CONDITION SKIP, so the default is the LAST month-end
    ap.add_argument("--date", default=(dt.date.today().replace(day=1) - dt.timedelta(days=1)).isoformat())
    ap.add_argument("--cloud-conn", default="")
    ap.add_argument("--onprem-conn", default="", help="an existing connection to use as on-prem (default: create one on qs-trino-sb)")
    ap.add_argument("--backend", default="native", choices=["native", "auto", "spark_k8s"])
    ap.add_argument("--hold", type=int, default=30, help="seconds the hold is watched before the release")
    ap.add_argument("--plan", action="store_true")
    args = ap.parse_args(rest)
    if args.plan:
        plan(args)
        return 0

    fx = json.load(open(FIXTURE, encoding="utf-8"))
    cloud_aliases, cloud_cols = parse_query(fx["query_on_cloud"])
    prem_aliases, prem_cols = parse_query(fx["query_on_prem"])
    check("fixture: the cloud query projects 75 columns and the on-prem 73, in different orders",
          len(cloud_aliases) == 75 and len(prem_aliases) == 73 and cloud_aliases != prem_aliases,
          {"cloud": len(cloud_aliases), "onprem": len(prem_aliases)})
    cloud_sql = fx["query_on_cloud"].replace("qs_icbg.fins.fact_tetb_ext", CLOUD_TABLE)
    prem_sql = fx["query_on_prem"].replace("qs_store_ro.fact_tetb_ext", ONPREM_TABLE)
    date = dt.date.fromisoformat(args.date)
    n = args.n
    r = Rig()
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))

    if sweep:
        rules = [Rule("feed template", rf"TETB_MONTHLY_\d{{6}}", list_path="/api/feed-templates",
                      delete_path="/api/feed-templates/{id}?delete_members=true"),
                 Rule("saved query", rf"tetb_(cloud|onprem)_\d{{6}}", list_path="/api/queries",
                      delete_path="/api/queries/{id}"),
                 Rule("connection", rf"sb-onprem-\d{{6}}", list_path="/api/connections",
                      delete_path="/api/connections/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        # the two lake tables are not HTTP objects: a killed run left them (2026-10-10)
        import re as _re
        out = trino("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb_ext%'")
        for t in [x.strip().strip('"') for x in out.splitlines()]:
            if _re.fullmatch(r"fact_tetb_ext(_onprem)?_\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    trino(f"DROP TABLE iceberg.qs.{t}")
        return rc

    # ── preflight ───────────────────────────────────────────────────────
    print(f"\n== preflight (tag {TAG}, n={n}, date {date})")
    check("P0 qs-kafka is running", broker_running())
    if not broker_running():
        return 2
    healthy, secs = wait_until(broker_healthy, 120, 5)
    check(f"P0 the broker is healthy ({secs}s)", healthy)
    rc, out = rpk("topic", "create", TOPIC, "-p", "1", "-r", "1")
    check("P0 the owner's topic exists", rc == 0 or "already exists" in out or "ALREADY_EXISTS" in out, out[-120:])
    s, st = r.call("GET", "/api/admin/background-jobs/feed_kafka_arrivals/status")
    text = json.dumps(st) if isinstance(st, dict) else str(st)
    check("P1 the dependency consumer is RUNNING with the owner's topic subscribed",
          s == 200 and '"running": true' in text and TOPIC in text, text[:300])
    check("P2 qs-sftp is running", docker("inspect", "-f", "{{.State.Running}}", SFTP["container"])[1] == "true")
    host_key = sftp_host_key()
    cloud_id, cloud_name = pick_cloud(r, args.cloud_conn)
    check(f"P3 cloud connection: {cloud_name} (id {cloud_id})", True)
    if args.onprem_conn:
        items = connections(r)
        hit = next((x for x in items if str(x.get("id")) == args.onprem_conn or x.get("name") == args.onprem_conn), None)
        if not hit:
            raise SystemExit(f"--onprem-conn {args.onprem_conn!r}: no such connection")
        prem_id, prem_name = hit["id"], hit["name"]
    else:
        pw = os.environ.get("QS_SB_ANALYST_PW")
        if not pw:
            raise SystemExit("QS_SB_ANALYST_PW is not set: . ~/.qs_keys/starburst_like.env (or pass --onprem-conn)")
        sb_running = docker("inspect", "-f", "{{.State.Running}}", SB_HOST)[1] == "true"
        check("P4 qs-trino-sb (the on-prem stand-in) is running", sb_running)
        if not sb_running:
            return 2
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False,
                       "catalog": "iceberg", "schema": "qs"}})
        if s not in (200, 201) or not (b or {}).get("id"):
            raise SystemExit(f"on-prem connection: {s} {str(b)[:300]}")
        prem_id, prem_name = b["id"], f"sb-onprem-{TAG}"
        ledger.add("connection", prem_name, path=f"/api/connections/{prem_id}")
    check(f"P4 on-prem connection: {prem_name} (id {prem_id}) differs from the cloud one", prem_id != cloud_id)
    _, types = r.call("GET", "/api/feed-dependency-types")
    titems = types if isinstance(types, list) else (types or {}).get("items") or []
    check("P5 the KAFKA dependency type is in the catalogue",
          any(str(t.get("dependency_type")).upper() == "KAFKA" for t in titems))

    timings = {}
    entities = [f"E{TAG}{i:04d}" for i in range(n)]
    islands = [(entities[i], EVENTS[i % 2]) for i in range(n)]
    feeds = {}
    try:
        # ── seed both sides ─────────────────────────────────────────────
        print("\n== seeding the two tables on the lake (truth = Trino)")
        t0 = time.time()
        trino_stdin(ddl(CLOUD_TABLE, cloud_cols) + ";\n")
        trino_stdin(ddl(ONPREM_TABLE, prem_cols) + ";\n")
        ledger.add("table", CLOUD_TABLE, remover=lambda: (bool(trino(f"DROP TABLE {CLOUD_TABLE}")), "dropped"))
        ledger.add("table", ONPREM_TABLE, remover=lambda: (bool(trino(f"DROP TABLE {ONPREM_TABLE}")), "dropped"))
        cloud_rows, prem_rows = [], []
        other_event = {"EOM": "MTD", "MTD": "EOM"}
        for ent, ev in islands:
            for i in range(args.rows):
                cloud_rows.append(row_values("cloud", cloud_cols, date, ent, ev, i))
            for i in range(args.rows + 1):
                prem_rows.append(row_values("prem", prem_cols, date, ent, ev, i))
            # decoys: same entity, OTHER event; same island, OTHER date
            cloud_rows.append(row_values("cloud", cloud_cols, date, ent, other_event[ev], 900))
            prem_rows.append(row_values("prem", prem_cols, date - dt.timedelta(days=1), ent, ev, 901))
        nc = insert_rows(CLOUD_TABLE, cloud_cols, cloud_rows)
        np_ = insert_rows(ONPREM_TABLE, prem_cols, prem_rows)
        timings["seed_s"] = round(time.time() - t0, 1)
        check(f"seeded {nc} cloud + {np_} on-prem rows incl. decoys ({timings['seed_s']}s)",
              nc == len(cloud_rows) and np_ == len(prem_rows))

        def truth(table, side):
            out = trino(f"SELECT code, businessevent, source_data_row, username, tran_currency_name, "
                        f"CAST(snap_version AS VARCHAR) FROM {table} WHERE business_close_date = DATE '{date}' "
                        f"AND code LIKE 'E{TAG}%'")
            by = collections.defaultdict(list)
            for line in out.splitlines():
                code, ev, sdr, user, ccy, snap = line.split("\t")
                pk = f"{code}_{ev}" if side == "cloud" else None
                by[(code, ev)].append((date.isoformat(), sdr, user, pk, ccy, snap))
            return by
        truth_cloud, truth_prem = truth(CLOUD_TABLE, "cloud"), truth(ONPREM_TABLE, "prem")
        check("truth: every island has cloud rows and on-prem rows (Trino)",
              all(len(truth_cloud[k]) == args.rows and len(truth_prem[k]) == args.rows + 1 for k in islands),
              {"islands": len(islands)})

        # ── the two saved queries ───────────────────────────────────────
        s, q1 = r.call("POST", "/api/queries", {"name": f"tetb_cloud_{TAG}", "query_config": {
            "files": [], "raw_sql": cloud_sql, "connection_id": cloud_id}})
        s2, q2 = r.call("POST", "/api/queries", {"name": f"tetb_onprem_{TAG}", "query_config": {
            "files": [], "raw_sql": prem_sql, "connection_id": prem_id}})
        check("the owner's two queries are saved verbatim (table names swapped)",
              s in (200, 201) and s2 in (200, 201), (s, s2))
        ledger.add("saved query", q1["name"], path=f"/api/queries/{q1['id']}")
        ledger.add("saved query", q2["name"], path=f"/api/queries/{q2['id']}")

        # ── A: bulk authoring ───────────────────────────────────────────
        print(f"\n== A bulk authoring: {n} feeds from ONE template")
        template = {
            "name": TEMPLATE_NAME,
            "description": "owner case: cloud + on-prem fact_tetb_ext per entity x event, monthly",
            "parameters": ["SYSTEM_ENTITY", "EventCode"],
            "feed": {
                "name": f"TETB_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}",
                "display_name": "TETB {SYSTEM_ENTITY} / {EventCode}",
                "source_type": "saved_query", "source_id": q1["id"], "connection_id": cloud_id,
                "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
                "secondary_source_id": q2["id"], "combine_mode": "union",
                "output_format": "csv",
                "output_filename_template": f"TETB_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}_{{business_date:YYYYMMDD}}.csv",
                "destination_type": "sftp",
                "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                       "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                       "host_key_b64": host_key},
                "schedule_declaration": {"kind": "month_end"},
                "execution_backend": args.backend,
                "notify_on_failure": False,
            },
            "dependencies": [{"dependency_type": "KAFKA",
                              "dependency_key": "TETB_{SYSTEM_ENTITY}_{EventCode}",
                              "description": "partition ready for {SYSTEM_ENTITY}/{EventCode}",
                              "arrival_sources": [{"kind": "kafka", "topic": TOPIC}],
                              "require_mode": "all"}],
            "matrix": [{"SYSTEM_ENTITY": e, "EventCode": v} for e, v in islands],
        }
        t0 = time.time()
        s, body = r.call("POST", "/api/feed-templates", template)
        s, rep, mode = await_template_apply(r, s, body)
        timings["bulk_create_s"] = round(time.time() - t0, 1)
        timings["bulk_create_mode"] = mode
        counts = rep.get("counts") or {}
        check(f"A1 POST /api/feed-templates created {n} feeds ({timings['bulk_create_s']}s, {mode}): {counts}",
              s == 201 and counts.get("created") == n and not counts.get("refused") and not counts.get("conflicts"),
              {"status": s, "refused": (rep.get("refused") or [])[:3], "conflicts": (rep.get("conflicts") or [])[:2]})
        if s != 201:
            raise SystemExit(f"template: {s} {str(body)[:400]} {str(rep)[:400]}")
        tid = body["template"]["id"]
        ledger.add("feed template", TEMPLATE_NAME, path=f"/api/feed-templates/{tid}?delete_members=true")
        for c in rep.get("created") or []:
            feeds[(c["values"]["SYSTEM_ENTITY"], c["values"]["EventCode"])] = c["feed_id"]
        t0 = time.time()
        s, body = r.call("POST", f"/api/feed-templates/{tid}/apply", {"matrix": template["matrix"]})
        s, rep2, mode2 = await_template_apply(r, s, body)
        c2 = rep2.get("counts") or {}
        check(f"A2 re-applying the same matrix creates nothing: {c2} ({round(time.time() - t0, 1)}s, {mode2})",
              s == 200 and c2.get("unchanged") == n and c2.get("created") == 0)
        fid0 = feeds[islands[0]]
        _, deps = r.call("GET", f"/api/feeds/{fid0}/dependencies")
        check("A3 a member declares ONE Kafka dependency keyed by its own entity/event",
              len((deps or {}).get("items") or []) == 1
              and deps["items"][0]["dependency_key"] == f"TETB_{islands[0][0]}_{islands[0][1]}"
              and deps["items"][0]["arrival_sources"] == [{"kind": "kafka", "topic": TOPIC}], deps)

        # ── B: the hold ─────────────────────────────────────────────────
        print(f"\n== B {n} runs are born WAIT")
        t0 = time.time()
        ok_runs = 0
        for key, fid in feeds.items():
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {
                "start_date": date.isoformat(), "end_date": date.isoformat(), "deliver": True,
                "reason": "monthly merge proof on the Docker rig, signed off by rig_admin (test data only)"})
            # a 200 is not a run: count what the route says it CREATED (a SKIP
            # answers 200 with created 0 -- that passed as "50/50" on 2026-10-10)
            created = ((b or {}).get("summary") or {}).get("created") if isinstance(b, dict) else None
            ok_runs += int(s == 200 and created == 1)
            if s != 200 or created != 1:
                print(f"   backfill {key}: {s} {str(b)[:240]}")
        timings["runs_created_s"] = round(time.time() - t0, 1)
        fids = ",".join(str(f) for f in feeds.values())
        waiting = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                           f"and action_decision = 'WAIT' and status = 'pending'") or 0)
        check(f"B1 {ok_runs}/{n} backfill runs created ({timings['runs_created_s']}s), all {waiting} held at WAIT",
              ok_runs == n and waiting == n)
        time.sleep(args.hold)
        still = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                         f"and action_decision = 'WAIT' and status = 'pending'") or 0)
        ran = int(psql(f"select count(*) from feed_executions where feed_config_id in ({fids})") or 0)
        check(f"B2 after {args.hold}s nothing ran: {still} still WAIT, {ran} executions", still == n and ran == 0)
        # the poller rewrites the backfill's generic reason on its own pass: wait for it
        # (read once, it raced the poller -- 2026-10-10)
        row0, secs_b3 = wait_until(lambda: (lambda x: x if x and TOPIC in (x.get("reason") or "") else None)(
            r.run_row(fid0, date.isoformat())), 90, 3)
        check(f"B3 the hold names the topic it waits on ({secs_b3}s after the hold)", bool(row0), row0 or r.run_row(fid0, date.isoformat()))

        # ── C: an unknown combination ───────────────────────────────────
        print("\n== C a message for a combination no feed declares")
        stray_entity = f"ZZ{TAG}"
        produce_many([json.dumps({"business_date": date.isoformat(), "SYSTEM_ENTITY": stray_entity,
                                  "EventCode": "EOM", "status": "COMPLETE"})])
        found, secs = wait_until(lambda: (lambda b: b if any(
            i.get("dependency_name") == f"TETB_{stray_entity}_EOM" for i in (b or {}).get("items") or []) else None)(
            r.call("GET", "/api/admin/feeds/kafka-arrivals/unmatched?days=1")[1]), 120, 5)
        check(f"C1 recorded as UNMATCHED and listed by the admin route ({secs}s), never dropped", bool(found))
        check("C1 ...and on the ledger under its rendered name",
              int(psql(f"select count(*) from dependency_events where dependency_name = 'TETB_{stray_entity}_EOM'") or 0) == 1)
        still = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and action_decision = 'WAIT'") or 0)
        check("C2 it released nothing", still == n, still)

        # ── D: the release ──────────────────────────────────────────────
        print(f"\n== D one message per island (+ a duplicate of the first) releases {n} runs")
        lines = [json.dumps({"business_date": date.isoformat(), "SYSTEM_ENTITY": e, "EventCode": v,
                             "status": "COMPLETE", "sent_by": f"monthly_kafka_merge_feeds_proof {TAG}"})
                 for e, v in islands]
        lines.append(lines[0])                                    # the duplicate, at a new offset
        t_release = time.time()
        produced = produce_many(lines)
        check(f"D0 {produced} messages produced through the broker", produced == n + 1, produced)

        def released():
            v = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                         f"and action_decision = 'RUN'") or 0)
            return v if v >= n else None
        rel, secs = wait_until(released, 300 + n, 5)
        timings["release_all_s"] = secs
        check(f"D1 the poller released all {n} runs ({secs}s after the first produce)", rel == n,
              psql(f"select action_decision, count(*) from feed_runs where feed_config_id in ({fids}) group by 1"))

        def done():
            v = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                         f"and status in ('completed','failed','cancelled')") or 0)
            if v and v % 25 == 0:
                print(f"   ... {v}/{n} runs finished at +{round(time.time() - t_release)}s", flush=True)
            return v if v >= n else None
        fin, secs = wait_until(done, 600 + n * 20, 10)
        timings["all_finished_s"] = round(time.time() - t_release)
        completed = int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                             f"and status = 'completed'") or 0)
        check(f"D2 all {n} runs finished ({timings['all_finished_s']}s from the first produce; "
              f"{round(n / max(1, timings['all_finished_s']) * 60, 1)} feeds/min), {completed} completed",
              fin == n and completed == n,
              psql(f"select status, count(*) from feed_runs where feed_config_id in ({fids}) group by 1"))

        # ── E: every file ───────────────────────────────────────────────
        print(f"\n== E every delivered file == cloud island UNION ALL on-prem island (vs Trino)")
        compared, bad = 0, []
        expected_header = [a.upper() for a in cloud_aliases]
        for key, fid in feeds.items():
            ent, ev = key
            _, ex = r.call("GET", f"/api/feeds/{fid}/executions")
            exs = ex if isinstance(ex, list) else (ex or {}).get("items") or []
            e = next((x for x in exs if x.get("status") == "completed"), None)
            if not e:
                bad.append((key, "no completed execution"))
                continue
            fm = e.get("files_metadata") or {}
            xs = fm.get("cross_source") or {}
            fname = f"TETB_{TAG}_{ent}_{ev}_{date.strftime('%Y%m%d')}.csv"
            size = sftp_ls(fname)
            if size is None:
                bad.append((key, f"{fname} not on the SFTP server"))
                continue
            body = sftp_read(fname)
            reader = csv.reader(io.StringIO(body))
            header = next(reader)
            rows = list(reader)
            hdr_up = [h.upper() for h in header]
            if hdr_up != expected_header:
                bad.append((key, f"header differs from the cloud order: {hdr_up[:5]}... ({len(hdr_up)} cols)"))
                continue
            idx = {h: i for i, h in enumerate(hdr_up)}
            # the on-prem side has no PARTITION_KEY: the file carries an empty
            # cell there, the truth None (a typed NULL, by the merge plan)
            got = collections.Counter(
                tuple((row[idx[c]] or None) if c == "PARTITION_KEY" else row[idx[c]] for c in COMPARE)
                for row in rows)
            want = collections.Counter(truth_cloud[key] + truth_prem[key])
            if got != want:
                bad.append((key, f"rows differ: file {sum(got.values())} vs truth {sum(want.values())}; "
                                 f"e.g. {list((got - want).elements())[:1]} / {list((want - got).elements())[:1]}"))
                continue
            purity = all(row[idx["SOURCE_DATA_ROW"]].split(":")[1:3] == [ent, ev] for row in rows)
            if not purity:
                bad.append((key, "a row from another island or date is in the file"))
                continue
            p, s_, exp = xs.get("primary_rows"), xs.get("secondary_rows"), xs.get("expected_rows")
            if not (p == args.rows and s_ == args.rows + 1 and exp == p + s_ == len(rows)):
                bad.append((key, f"files_metadata.cross_source {xs} vs {len(rows)} rows"))
                continue
            cert = json.dumps(fm.get("completeness_certificate") or {})
            m = re.search(r'"source_rows":\s*(\d+).*?"dest_rows":\s*(\d+)', cert)
            if not m or int(m.group(1)) != len(rows) or int(m.group(2)) != len(rows):
                bad.append((key, f"certificate does not reconcile {len(rows)} rows: {cert[:200]}"))
                continue
            if (e.get("total_rows") or 0) != len(rows):
                bad.append((key, f"execution total_rows {e.get('total_rows')} != {len(rows)}"))
                continue
            compared += len(rows)
        check(f"E1 {len(feeds) - len(bad)}/{n} files: header = the cloud query's 75 columns in its order; rows == cloud "
              f"UNION ALL on-prem (count + multiset vs Trino); one island per side; cross_source primary+secondary "
              f"== expected == delivered; certificate source == dest",
              not bad and compared > 0, bad[:5])
        check(f"E2 the compared row count is NON-ZERO ({compared} rows across {n} files)", compared > 0)
        one = next(iter(feeds.values()))
        _, ex = r.call("GET", f"/api/feeds/{one}/executions")
        e = next((x for x in (ex if isinstance(ex, list) else []) if x.get("status") == "completed"), {})
        merge = ((e.get("files_metadata") or {}).get("cross_source") or {}).get("merge") or {}
        check("E3 the merge disclosure names the on-prem side's missing columns and the case renames",
              sorted(merge.get("primary_only") or []) == ["PARTITION_KEY", "SOURCE_DATA_SET"]
              and merge.get("rule") == "union_all_by_name", merge)

        # ── F: the duplicate ────────────────────────────────────────────
        print("\n== F the duplicate message is one run")
        runs0 = psql(f"select count(*) from feed_runs where feed_config_id = {fid0} and business_date = '{date}'")
        execs0 = psql(f"select count(*) from feed_executions where feed_config_id = {fid0} and status = 'completed'")
        arrivals0 = int(psql(f"select count(*) from dependency_events where dependency_name = "
                             f"'TETB_{islands[0][0]}_{islands[0][1]}' and business_date = '{date}'") or 0)
        decisions0 = psql(f"select count(*) from feed_regeneration_decisions where dependency_name = "
                          f"'TETB_{islands[0][0]}_{islands[0][1]}' and business_date = '{date}'")
        # A regeneration DECISION is raised only for a replay that lands AFTER the run
        # completed (dependency proof K3); a duplicate published in the same batch lands
        # before the run executes and has nothing to regenerate.  Expect what the order says.
        dup_after = psql(f"select (max(e.arrived_at) > (select max(x.completed_at) from feed_executions x "
                         f"where x.feed_config_id = {fid0} and x.status = 'completed'))::text from dependency_events e "
                         f"where e.dependency_name = 'TETB_{islands[0][0]}_{islands[0][1]}' and e.business_date = '{date}'")
        want_dec = "1" if dup_after == "true" else "0"
        check(f"F1 feed 0: {arrivals0} arrivals (the duplicate landed), {runs0} run, {execs0} completed execution, "
              f"{decisions0} regeneration decision (expected {want_dec}: duplicate after completion = {dup_after}) -- never a second run",
              arrivals0 == 2 and runs0 == "1" and execs0 == "1" and decisions0 == want_dec, None)

        print("\n== timings", json.dumps(timings))
    finally:
        print("\n== cleanup")
        for key, fid in feeds.items():
            fname = f"TETB_{TAG}_{key[0]}_{key[1]}_{date.strftime('%Y%m%d')}.csv"
            docker("exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fname}")
        psql(f"delete from kafka_messages where topic = '{TOPIC}' and payload like '%{TAG}%'")
        psql(f"delete from dependency_events where dependency_name like 'TETB_E{TAG}%' or dependency_name like 'TETB_ZZ{TAG}%'")
        psql(f"delete from feed_regeneration_decisions where dependency_name like 'TETB_E{TAG}%'")
        removed, failures = ledger.cleanup()

    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if all(res) and not failures else 1


if __name__ == "__main__":
    sys.exit(main())
