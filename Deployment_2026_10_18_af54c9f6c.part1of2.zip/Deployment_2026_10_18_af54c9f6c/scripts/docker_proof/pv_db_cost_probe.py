"""How much METADATA-DATABASE work one CACHED published-API call costs (2026-10-03).

Found live: under 50 paced consumers Postgres sat at ~100% CPU and the
published API plateaued at ~55 req/s whatever its worker count -- a cached
/data call cost ~19-30 transactions and ~1,400+ tuples scanned.  Creates a
report-backed view on the Snowflake connection, warms it, then reads
pg_stat_database before / after 50 cached calls.  Background daemons add a
little noise; compare runs, not absolutes.

    . ~/.qs_keys/rigpw.sh && python scripts/docker_proof/pv_db_cost_probe.py
"""
import os, sys, time, subprocess, urllib.request
sys.path.insert(0, r"C:\DEV\outputs\scripts\docker_proof")
from auth_rls_proof import Session
a = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"]); TAG = str(int(time.time()))[-6:]; undo = []
def pg(q):
    return subprocess.run(["docker","exec","qs-local-postgres","psql","-U","querystudio","-d","querystudio","-tAc",q],capture_output=True,text=True).stdout.strip()
try:
    s, ds, _ = a.call("POST", "/api/datasets", {"name": f"dbc_{TAG}", "subject": "p", "connection_ids": [239], "base_query": "select REGION, sum(AMT) AMT from QS_DEMO.FIN.TRADES group by 1"})
    undo.insert(0, f"/api/datasets/{ds['id']}"); a.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
    cols = [c["id"] for c in a.call("GET", f"/api/datasets/{ds['id']}")[1]["columns"]]
    _, rep, _ = a.call("POST", "/api/business-reports", {"name": f"dbc-{TAG}", "dataset_id": ds["id"], "data_source_type": "dataset", "column_ids": cols})
    undo.insert(0, f"/api/business-reports/{rep['id']}"); a.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
    slug = f"dbc-{TAG}"
    _, pv, _ = a.call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report", "business_report_id": rep["id"], "credential_mode": "publisher"})
    undo.insert(0, f"/api/published-views/{pv['id']}")
    _, k, _ = a.call("POST", "/api/api-keys", {"name": f"dbc-{TAG}", "scoped_view_ids": [pv["id"]], "rate_limit": "300/minute"}); undo.append(f"/api/api-keys/{k['id']}")
    call = lambda: urllib.request.urlopen(urllib.request.Request(f"http://localhost:8003/api/v1/views/{slug}/data?limit=10", headers={"X-API-Key": k["raw_key"]}), timeout=60).read()
    call(); call()   # warm: cache + key
    q = "select xact_commit+xact_rollback, tup_returned, tup_fetched, tup_inserted+tup_updated+tup_deleted from pg_stat_database where datname='querystudio'"
    time.sleep(2); b = [int(x) for x in pg(q).split("|")]
    N = 50
    for _ in range(N): call()
    time.sleep(2); e = [int(x) for x in pg(q).split("|")]
    d = [(y - x) / N for x, y in zip(b, e)]
    print(f"per cached API call: {d[0]:.1f} transactions, {d[1]:.0f} tuples returned, {d[2]:.0f} fetched, {d[3]:.1f} written")
finally:
    for p in undo: a.call("DELETE", p)
