"""MANY REAL USERS AT ONCE against the live Docker rig -- login + row security on.

Twenty-five local users (``lt_01`` .. ``lt_25``), each bound to ONE region of
``iceberg.qs.trades`` by a row-security policy, sign in and run the product's
three consumer surfaces concurrently:

* the SQL editor (``/api/sql/execute`` -> Trino), analysts only;
* a published finance report, sync (``/execute``) and async
  (``/execute-async`` + status + results);
* the published API over that report (tier :8003) with the user's session.

The question is not "does it answer" but "does EVERY answer belong to the
person who asked".  Truth per user is computed on the SOURCE (Trino, outside
QueryStudio) before the load starts, and every response is compared with that
user's truth by value: a response carrying another region's rows is a LEAK
and fails the run; a wrong number is WRONG and fails the run.  An honest
refusal (429/503 with Retry-After) is counted, never failed -- a cap must
throttle.  Anything else (500, transport error, a hang past the timeout) is an
ERROR.  ``/health/live`` is probed every half second throughout: the API must
stay answerable while it is saturated.

Levels ramp 10 -> 25 -> 50 concurrent workers (two workers per user at 50),
``--seconds`` each.  Results: one table per level, per operation (n, ok,
refused, errors, wrong, leaks, p50/p95/max), and JSON at ``--out``.

WHERE THE LOAD RUNS (2026-10-04).  From this Windows host, Docker Desktop's
port forwarding resets connections under many concurrent sockets
(``ConnectionResetError [WinError 10054]``) while the server's own
``/health/live`` answers 100% -- seven such "errors" in ~4,100 ops were the
HOST, not the product.  So the levels run, by default, in a throwaway
``python:3.11-slim`` container on ``querystudio-local-net`` against
``http://api:8000`` / ``http://published-api:8000`` (this same file, in
``--inner-plan`` mode).  The container gets a plan (bases, report, slug, the
users' session tokens -- never the truth) and returns RAW observations; the
host computes the truth, judges every answer, runs the baseline and owns the
cleanup ledger.  A transport error inside the network is still an ERROR.
``--host-load`` keeps the old host-side mode.

The users come from ``docker-compose.load-users.yml`` layered AFTER
``docker-compose.auth-rls.yml``; their password is ``QS_LOAD_PW``.  Everything
this run creates (policies, bindings, report, published view) is removed in a
``finally`` through the ledger; pre-existing enabled policies are parked for
the run and re-enabled.  Exit 0 only when there are no leaks, no wrong
answers, no errors, and the cleanup left nothing behind.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402

API = "http://localhost:8000"
PUB = "http://localhost:8003"
RPT = API          # --reports: the reports pod, as the production ingress routes report traffic
TABLE = "iceberg.qs.trades"
TAG = str(int(time.time()))[-6:]
N_USERS = 25
N_VIEWERS = 5            # lt_21..lt_25 are viewers: reports + published API only


# ── HTTP: explicit base, no shared state (the shared client swaps a global) ──

def http(method, base, path, body=None, token=None, timeout=300):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                b = json.loads(raw) if raw else None
            except ValueError:
                b = raw[:300]
            return r.status, b, dict(r.headers), time.perf_counter() - t0
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            b = json.loads(raw)
        except Exception:
            b = raw[:300].decode("utf-8", "replace")
        return e.code, b, dict(e.headers), time.perf_counter() - t0
    except Exception as e:                                          # noqa: BLE001
        return -1, {"transport_error": f"{type(e).__name__}: {e}"}, {}, time.perf_counter() - t0


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV",
                          "--execute", sql], capture_output=True, text=True, timeout=300)
    rows = [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]
    if out.returncode != 0 or not rows:
        raise SystemExit(f"trino truth failed: {out.returncode} {out.stderr[-300:]}")
    return rows


class Admin:
    """The admin's calls wait out a 429 -- setup and cleanup must not be refused."""

    def __init__(self, user, pw):
        self.token = login(user, pw)[0]

    def call(self, method, path, body=None, **_kw):
        for _ in range(12):
            s, b, h, _ = http(method, API, path, body, self.token)
            if s != 429:
                return s, b, h
            time.sleep(float(h.get("Retry-After") or 5) + 0.5)
        return s, b, h


def login(user, pw):
    """Sign in, honouring the login limiter's Retry-After.  Returns
    (token, role, number of 429s met)."""
    refused = 0
    for _ in range(40):
        s, b, h, _ = http("POST", API, "/auth/login", {"username": user, "password": pw})
        if s == 200 and (b or {}).get("session_token"):
            return b["session_token"], b.get("role"), refused
        if s == 429:
            refused += 1
            time.sleep(float(h.get("Retry-After") or 5) + 0.2)
            continue
        raise SystemExit(f"login failed for {user}: {s} {str(b)[:200]}")
    raise SystemExit(f"login for {user} refused 40 times")


# ── the three surfaces ───────────────────────────────────────────────────────
#
# An operation OBSERVES; it never judges.  Each returns
# ``(kind, latency, detail, got)``: ``kind`` is "answered" (``got`` is the
# per-region answer the server gave), "refused" (an honest 429/503 with
# Retry-After, or the async contract's refusal) or "error".  Whether an
# answer belongs to the person who asked is decided in ONE place, ``judge``,
# by the HOST against the truth it computed on the source -- the load may run
# inside the docker network (``--inner-plan``) and the truth never leaves the
# host.

def _rows(body):
    body = body or {}
    names = [x["name"] if isinstance(x, dict) else x for x in (body.get("columns") or [])]
    rows = body.get("rows") or body.get("data") or []
    return [r if isinstance(r, dict) else dict(zip(names, r)) for r in rows]


def judge(got: dict, want: dict):
    foreign = sorted(set(got) - set(want))
    if foreign:
        return "leak", f"got regions {foreign} (theirs: {sorted(want)})"
    if got != want:
        return "wrong", f"got {got} want {want}"
    return "ok", ""


def refused(s, h):
    return s in (429, 503) and bool(h.get("Retry-After") or h.get("retry-after"))


def op_sql(u, i):
    # A distinct, always-true predicate per call: a real Trino run, not a cache hit.
    sql = (f"SELECT region, count(*) AS n FROM {TABLE} WHERE {i} = {i} GROUP BY region")
    t0 = time.perf_counter()
    s, b, h, _ = http("POST", API, "/api/sql/execute",
                      {"primary_connection_id": 2, "primary_sql": sql, "row_limit": 50}, u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    if s != 200 or not (b or {}).get("execution_id"):
        return "error", time.perf_counter() - t0, f"submit {s} {str(b)[:160]}", None
    eid = b["execution_id"]
    while time.perf_counter() - t0 < 300:
        s, st, h, _ = http("GET", API, f"/api/executions/{eid}/status", token=u["token"])
        status = (st or {}).get("status") if isinstance(st, dict) else None
        if status in ("completed", "success", "finished"):
            s, rb, h, _ = http("GET", API, f"/api/executions/{eid}/results?page_size=50", token=u["token"])
            if refused(s, h):
                return "refused", time.perf_counter() - t0, f"results {s}", None
            if s != 200:
                return "error", time.perf_counter() - t0, f"results {s} {str(rb)[:160]}", None
            got = {str(r.get("region")): int(r.get("n")) for r in _rows(rb)}
            d = ""
            if not got:
                # an EMPTY page for a completed run: say everything the server said
                d = (f" | exec={eid} status_total={(st or {}).get('total_rows')} "
                     f"results_total={(rb or {}).get('total_rows') if isinstance(rb, dict) else None} "
                     f"keys={sorted(rb.keys())[:14] if isinstance(rb, dict) else str(rb)[:80]}")
            return "answered", time.perf_counter() - t0, d, got
        if status in ("failed", "error", "cancelled"):
            return "error", time.perf_counter() - t0, f"{status}: {str((st or {}).get('error_message'))[:160]}", None
        if s not in (200,) and not refused(s, h):
            return "error", time.perf_counter() - t0, f"status poll {s} {str(st)[:120]}", None
        time.sleep(0.3)
    return "error", time.perf_counter() - t0, f"timeout {eid}", None


def _run_and_read(u, path, body, t0):
    """Submit, poll, read page 1 -- the builder's own sequence."""
    s, b, h, _ = http("POST", API, path, body, u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    if s != 200 or not (b or {}).get("execution_id"):
        return "error", time.perf_counter() - t0, f"submit {s} {str(b)[:160]}", None
    eid = b["execution_id"]
    while time.perf_counter() - t0 < 300:
        s, st, h, _ = http("GET", API, f"/api/executions/{eid}/status", token=u["token"])
        status = (st or {}).get("status") if isinstance(st, dict) else None
        if status in ("completed", "success", "finished"):
            s, rb, h, _ = http("GET", API, f"/api/executions/{eid}/results?page_size=50", token=u["token"])
            if refused(s, h):
                return "refused", time.perf_counter() - t0, f"results {s}", None
            if s != 200:
                return "error", time.perf_counter() - t0, f"results {s} {str(rb)[:160]}", None
            return "answered", time.perf_counter() - t0, "", {str(r.get("region")): int(r.get("n")) for r in _rows(rb)}
        if status in ("failed", "error", "cancelled"):
            err = str((st or {}).get("error_message") or "")
            if "busy" in err.lower() or "capacity" in err.lower():
                return "refused", time.perf_counter() - t0, f"run refused: {err[:120]}", None
            return "error", time.perf_counter() - t0, f"{status}: {err[:160]}", None
        if s != 200 and not refused(s, h):
            return "error", time.perf_counter() - t0, f"status poll {s} {str(st)[:120]}", None
        time.sleep(0.3)
    return "error", time.perf_counter() - t0, f"timeout {eid}", None


def op_bqb_trino(u, i):
    """The QUERY BUILDER run route (/api/execute) on Trino -- row security
    must apply here exactly as on the SQL page (2026-10-07)."""
    sql = f"SELECT region, count(*) AS n FROM {TABLE} WHERE {i} = {i} GROUP BY region"
    return _run_and_read(u, "/api/execute", {"connection_id": 2, "raw_sql": sql,
                                             "cache_strategy": "bypass"}, time.perf_counter())


def op_bqb_s3(u, i):
    """The builder on the owner REAL AWS bucket (Iceberg dim) -- no row
    policy there, so every user truth is the whole table."""
    sql = f"select region, count(*) as n from dim_legal_entity where {i} = {i} group by region"
    return _run_and_read(u, "/api/execute", {"connection_id": S3_CONN, "raw_sql": sql,
                                             "cache_strategy": "bypass"}, time.perf_counter())


def op_draft(u, i):
    """The builder server draft: write MY statement, read it back -- a draft
    carrying another user name is a LEAK."""
    t0 = time.perf_counter()
    key = "bqb.sql.loadtest"
    s, b, h, _ = http("PUT", API, f"/api/user/drafts/{key}", {"content": f"{u['name']}:{i}"}, u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    if s not in (200, 204):
        return "error", time.perf_counter() - t0, f"put {s} {str(b)[:120]}", None
    s, b, h, _ = http("GET", API, f"/api/user/drafts/{key}", token=u["token"])
    if s != 200:
        return "error", time.perf_counter() - t0, f"get {s} {str(b)[:120]}", None
    owner = str((b or {}).get("content") or "").split(":")[0]
    return "answered", time.perf_counter() - t0, "", {owner: 1}


def op_report_sync(u, i):
    t0 = time.perf_counter()
    body = {"parameter_values": {}}
    if i % 2:
        body["force_refresh"] = True          # half the runs must reach the source
    s, run, h, _ = http("POST", RPT, f"/api/business-reports/{RID}/execute", body, u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    eid = (run or {}).get("execution_id") if isinstance(run, dict) else None
    if s != 200 or not eid:
        return "error", time.perf_counter() - t0, f"{s} {str(run)[:160]}", None
    s, res, h, _ = http("GET", RPT, f"/api/business-reports/{RID}/results/{eid}?page_size=50", token=u["token"])
    if s != 200:
        return "error", time.perf_counter() - t0, f"results {s} {str(res)[:120]}", None
    got = {str(r.get("region")): round(float(r.get("amt")), 2) for r in _rows(res)}
    return "answered", time.perf_counter() - t0, "", got


def op_report_async(u, i):
    t0 = time.perf_counter()
    s, st, h, _ = http("POST", RPT, f"/api/business-reports/{RID}/execute-async",
                       {"parameter_values": {}, "force_refresh": bool(i % 2)}, u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    eid = (st or {}).get("execution_id") if isinstance(st, dict) else None
    if s != 200 or not eid:
        return "error", time.perf_counter() - t0, f"{s} {str(st)[:160]}", None
    status = (st or {}).get("status")
    while status not in ("completed", "failed", "cancelled") and time.perf_counter() - t0 < 300:
        time.sleep(0.3)
        s, st, h, _ = http("GET", RPT, f"/api/business-reports/{RID}/execution/{eid}/status", token=u["token"])
        status = (st or {}).get("status") if isinstance(st, dict) else None
    if status != "completed":
        err = str((st or {}).get("error") or "") if isinstance(st, dict) else str(st)[:160]
        # The async contract (qs-reports): a load-shed refusal is a FAILED job
        # carrying the reason and when to retry -- an honest refusal, counted,
        # never failed.  Anything else is an error.
        if status == "failed" and ("Try again" in err or "Waited" in err) and (
                "busy" in err.lower() or "capacity" in err.lower()):
            return "refused", time.perf_counter() - t0, f"async refused: {err[:120]}", None
        return "error", time.perf_counter() - t0, f"async {status} (http {s}): {err[:160]}", None
    s, res, h, _ = http("GET", RPT, f"/api/business-reports/{RID}/results/{eid}?page_size=50", token=u["token"])
    if s != 200:
        return "error", time.perf_counter() - t0, f"results {s}", None
    got = {str(r.get("region")): round(float(r.get("amt")), 2) for r in _rows(res)}
    return "answered", time.perf_counter() - t0, "", got


def op_pv(u, i):
    t0 = time.perf_counter()
    s, b, h, _ = http("GET", PUB, f"/api/v1/views/{SLUG}/data?limit=50", token=u["token"])
    if refused(s, h):
        return "refused", time.perf_counter() - t0, f"{s}", None
    if s != 200:
        return "error", time.perf_counter() - t0, f"{s} {str(b)[:160]}", None
    got = {str(r.get("region")): round(float(r.get("amt")), 2)
           for r in _rows(b) if r.get("region") is not None}
    return "answered", time.perf_counter() - t0, "", got


#: name -> (operation, weight in a worker's bag, which truth judges its answer)
OPS = {"sql": (op_sql, 3, "want_n"), "report_sync": (op_report_sync, 3, "want_amt"),
       "report_async": (op_report_async, 2, "want_amt"), "published_api": (op_pv, 3, "want_amt"),
       # the query builder (2026-10-07): its run route on Trino and on real S3, and its drafts
       "bqb_trino": (op_bqb_trino, 3, "want_n"), "bqb_s3": (op_bqb_s3, 2, "want_s3"),
       "bqb_draft": (op_draft, 2, "want_draft")}
OPS_ANALYST = ("sql", "report_sync", "report_async", "published_api", "bqb_trino", "bqb_s3", "bqb_draft")
OPS_VIEWER = ("report_sync", "report_async", "published_api")


def ops_for(u):
    return OPS_VIEWER if u["viewer"] else OPS_ANALYST


def verdict(u, obs):
    """(op, kind, latency, user, detail, got) -> (op, verdict, latency, user, detail).
    The ONE place an answer is judged against the host's truth."""
    op, kind, dt, user, detail, got = obs
    if kind != "answered":
        return op, kind, dt, user, detail
    v, d = judge(got, u[OPS[op][2]])
    return op, v, dt, user, (d + detail) if v != "ok" else d


# ── one level ────────────────────────────────────────────────────────────────

def run_level(users, workers, seconds):
    """Drive ``workers`` concurrent workers for ``seconds``.  Returns the RAW
    observations ``(op, kind, latency, user, detail, got)`` and the health
    probes ``(status, latency)`` -- no verdicts (the host judges)."""
    samples = []
    lock = threading.Lock()
    stop = time.time() + seconds
    health = []

    def prober():
        while time.time() < stop:
            s, _, _, dt = http("GET", API, "/health/live", timeout=30)
            health.append((s, dt))
            time.sleep(0.5)

    def worker(k):
        u = users[k % len(users)]
        bag = [name for name in ops_for(u) for _ in range(OPS[name][1])]
        rnd = random.Random(k)
        i = k * 100000
        while time.time() < stop:
            name = rnd.choice(bag)
            i += 1
            try:
                kind, dt, d, got = OPS[name][0](u, i)
            except Exception as e:                                  # noqa: BLE001
                kind, dt, d, got = "error", 0.0, f"harness: {type(e).__name__}: {e}", None
            with lock:
                samples.append((name, kind, dt, u["name"], d, got))

    hp = threading.Thread(target=prober, daemon=True)
    hp.start()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(worker, range(workers)))
    hp.join(timeout=35)
    return samples, health


# ── the load INSIDE the docker network (2026-10-04) ─────────────────────────
#
# From Windows, Docker Desktop's port forwarding resets connections under many
# concurrent sockets (ConnectionResetError, WinError 10054) while the server's
# own /health/live answers 100% -- an artefact of the HOST, not the product
# (snowflake_threshold_proof.py measured the same and moved its overload test
# inside the network).  So by default the load generator runs in a throwaway
# python:3.11-slim container on the rig's network against http://api:8000 /
# http://published-api:8000; the host keeps the truth, the judging, the
# baseline and the cleanup ledger.  The container is handed a PLAN (bases,
# report id, slug, users with their session tokens -- no truth) and returns
# raw observations.  A transport error inside the network is still an ERROR.

INNER_NET = "querystudio-local-net"
INNER_IMAGE = "python:3.11-slim"
INNER_API, INNER_PUB = "http://api:8000", "http://published-api:8000"


def run_levels_inside(users, levels, seconds, *, reports_base=None):
    """Run every level in a container on the rig's network.  Returns
    ``[(workers, samples, health), ...]`` exactly as :func:`run_level` would."""
    here = os.path.dirname(os.path.abspath(__file__))
    work = tempfile.mkdtemp(prefix="mu_inner_")
    try:
        plan = {"api": INNER_API, "pub": INNER_PUB, "rpt": reports_base or INNER_API,
                "rid": RID, "slug": SLUG, "s3": S3_CONN, "levels": levels, "seconds": seconds,
                "users": [{"name": u["name"], "viewer": u["viewer"], "token": u["token"]} for u in users]}
        with open(os.path.join(work, "plan.json"), "w", encoding="utf-8") as f:
            json.dump(plan, f)
        budget = len(levels) * (seconds + 330) + 120     # a level ends <= 300 s after its stop
        out = subprocess.run(
            ["docker", "run", "--rm", "--network", INNER_NET, "-v", f"{here}:/s:ro", "-v", f"{work}:/w",
             INNER_IMAGE, "python", "-u", "/s/multiuser_load.py", "--inner-plan", "/w/plan.json",
             "--inner-out", "/w/out.json"],
            capture_output=True, text=True, timeout=budget, env=dict(os.environ, MSYS_NO_PATHCONV="1"))
        for ln in (out.stdout or "").splitlines():
            print("   [inner] " + ln)
        res_path = os.path.join(work, "out.json")
        if out.returncode != 0 or not os.path.exists(res_path):
            raise SystemExit(f"the in-network load generator failed (exit {out.returncode}): "
                             f"{(out.stderr or '')[-600:]}")
        with open(res_path, encoding="utf-8") as f:
            got = json.load(f)
    finally:
        shutil.rmtree(work, ignore_errors=True)       # the plan holds session tokens
    levels_out = [(lv["workers"], [tuple(s) for s in lv["samples"]], [tuple(h) for h in lv["health"]])
                  for lv in got["levels"]]
    if [w for w, _, _ in levels_out] != list(levels):
        raise SystemExit(f"the in-network run returned levels {[w for w, _, _ in levels_out]}, asked {levels}")
    return levels_out


def inner_main(plan_path, out_path):
    """The container side: run the plan's levels, write raw observations."""
    global API, PUB, RPT, RID, SLUG, S3_CONN
    with open(plan_path, encoding="utf-8") as f:
        plan = json.load(f)
    API, PUB, RPT = plan["api"], plan["pub"], plan["rpt"]
    RID, SLUG, S3_CONN = plan["rid"], plan["slug"], plan.get("s3")
    s, _, _, _ = http("GET", API, "/health/live", timeout=30)
    if s != 200:
        print(f"{API}/health/live answered {s} from inside the network")
        return 2
    levels = []
    for n, lvl in enumerate(plan["levels"]):
        if n:
            time.sleep(10)
        samples, health = run_level(plan["users"], lvl, plan["seconds"])
        print(f"level {lvl}: {len(samples)} observations, {len(health)} health probes")
        levels.append({"workers": lvl, "samples": samples, "health": health})
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"levels": levels}, f)
    return 0


def pct(xs, p):
    if not xs:
        return None
    xs = sorted(xs)
    return round(xs[min(len(xs) - 1, int(round(p / 100 * (len(xs) - 1))))], 2)


def summarise(level, samples, health):
    by = defaultdict(list)
    for s in samples:
        by[s[0]].append(s)
    out = {"workers": level, "ops": {}, "health": {}}
    print(f"\n== {level} concurrent workers: {len(samples)} operations")
    print(f"   {'operation':<14}{'n':>6}{'ok':>6}{'refused':>9}{'errors':>8}{'wrong':>7}{'leaks':>7}"
          f"{'p50 s':>8}{'p95 s':>8}{'max s':>8}")
    for op, ss in sorted(by.items()):
        cnt = defaultdict(int)
        for s in ss:
            cnt[s[1]] += 1
        lat = [s[2] for s in ss if s[1] == "ok"]
        row = {"n": len(ss), **{k: cnt[k] for k in ("ok", "refused", "error", "wrong", "leak")},
               "p50": pct(lat, 50), "p95": pct(lat, 95), "max": round(max(lat), 2) if lat else None}
        out["ops"][op] = row
        print(f"   {op:<14}{row['n']:>6}{row['ok']:>6}{row['refused']:>9}{row['error']:>8}"
              f"{row['wrong']:>7}{row['leak']:>7}{str(row['p50']):>8}{str(row['p95']):>8}{str(row['max']):>8}")
    hl = [dt for s, dt in health if s == 200]
    out["health"] = {"probes": len(health), "ok": len(hl), "p95": pct(hl, 95),
                     "max": round(max(hl), 2) if hl else None}
    print(f"   /health/live: {len(hl)}/{len(health)} answered, p95 {out['health']['p95']}s, "
          f"max {out['health']['max']}s")
    bad = [s for s in samples if s[1] in ("leak", "wrong", "error")]
    for s in bad[:12]:
        print(f"   ! {s[1].upper():<6} {s[0]:<14} {s[3]}: {s[4][:200]}")
    if len(bad) > 12:
        print(f"   ! ... and {len(bad) - 12} more")
    out["bad"] = [{"op": s[0], "verdict": s[1], "user": s[3], "detail": s[4][:300]} for s in bad]
    return out


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    global RID, SLUG, API, PUB, RPT, S3_CONN
    ap = argparse.ArgumentParser()
    ap.add_argument("--levels", default="10,25,50")
    ap.add_argument("--seconds", type=int, default=90)
    ap.add_argument("--out", default="multiuser_load_results.json")
    ap.add_argument("--api", default=API, help="main API base for setup, truth, baseline (and the load with --host-load)")
    ap.add_argument("--pub", default=PUB, help="published-API tier base")
    ap.add_argument("--reports", default=None, help="send report traffic to this base (the reports pod)")
    ap.add_argument("--truth", default=None, help="JSON {counts, sums} instead of asking Trino (no docker CLI)")
    ap.add_argument("--dump-truth", default=None, help="write the Trino truth to this JSON and exit")
    ap.add_argument("--host-load", action="store_true",
                    help="drive the load levels from THIS host through Docker Desktop's port forwarding "
                         "(the pre-2026-10-04 mode; it resets connections under load -- WinError 10054). "
                         "Default: the levels run inside the docker network.")
    ap.add_argument("--inner-plan", default=None, help=argparse.SUPPRESS)   # the container side
    ap.add_argument("--inner-out", default=None, help=argparse.SUPPRESS)
    a = ap.parse_args()
    if a.inner_plan:
        return inner_main(a.inner_plan, a.inner_out)
    API, PUB = a.api.rstrip("/"), a.pub.rstrip("/")
    RPT = (a.reports or API).rstrip("/")
    print(f"api={API} published={PUB} reports={RPT}  load: "
          + ("from the HOST (--host-load)" if a.host_load
             else f"inside {INNER_NET} -> {INNER_API}, {INNER_PUB}"
                  + (", reports http://reports:8000" if a.reports else "")))
    pw, admin_pw = os.environ.get("QS_LOAD_PW"), os.environ.get("QS_RIG_ADMIN_PW")
    if not pw or not admin_pw:
        raise SystemExit("set QS_LOAD_PW and QS_RIG_ADMIN_PW")
    s, _, _, _ = http("GET", API, "/api/datasets")
    if s != 401:
        raise SystemExit(f"not the LOGIN rig (anonymous /api/datasets answered {s})")

    if a.truth:
        _t = json.load(open(a.truth, encoding="utf-8"))
        counts, sums = _t["counts"], _t["sums"]
    else:
        counts = {r[0]: int(r[1]) for r in trino(f"SELECT region, count(*) FROM {TABLE} GROUP BY region")}
        sums = {r[0]: round(float(r[1]), 2) for r in trino(f"SELECT region, sum(amt) FROM {TABLE} GROUP BY region")}
    if a.dump_truth:
        json.dump({"counts": counts, "sums": sums}, open(a.dump_truth, "w", encoding="utf-8"))
        print(f"truth written to {a.dump_truth}")
        return 0
    regions = sorted(counts)
    if len(regions) < 3 or sum(counts.values()) == 0:
        raise SystemExit(f"truth is trivial: {counts}")
    print(f"truth (Trino): {len(regions)} regions, {sum(counts.values()):,} rows: {counts}")

    admin = Admin("rig_admin", admin_pw)
    ledger = Ledger(admin.call)
    parked, shared_conn, results, left = [], False, {}, []
    shared_s3, s3full = False, None
    try:
        _, pols, _ = admin.call("GET", "/api/admin/row-security/policies")
        pols = pols if isinstance(pols, list) else (pols or {}).get("policies") or []
        for p in pols:
            if p.get("enabled"):
                if admin.call("PUT", f"/api/admin/row-security/policies/{p['id']}", {"enabled": False})[0] == 200:
                    parked.append(p["id"])
        _, conn, _ = admin.call("GET", "/api/connections/2")
        if not (conn or {}).get("is_shared"):
            body = {k: conn[k] for k in ("name", "connection_type", "config")}
            shared_conn = admin.call("PUT", "/api/connections/2", {**body, "is_shared": True})[0] == 200
        # the builder S3 road: the owner real AWS connection, shared for the run
        _, cl, _ = admin.call("GET", "/api/connections")
        cl = cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []
        s3c = next((x for x in cl if x.get("name") == "aws-real"), None)
        if not s3c:
            raise SystemExit("no aws-real connection -- the builder S3 road cannot be loaded")
        S3_CONN = s3c["id"]
        _, s3full, _ = admin.call("GET", f"/api/connections/{S3_CONN}")
        if not (s3full or {}).get("is_shared"):
            shared_s3 = admin.call("PUT", f"/api/connections/{S3_CONN}", {
                "is_shared": True, "name": s3full["name"], "connection_type": s3full["connection_type"], "config": s3full["config"]})[0] == 200
        want_s3 = {r[0]: int(r[1]) for r in trino(
            "select region, count(*) from iceberg_aws.fin.dim_legal_entity group by region")}
        if len(want_s3) < 2:
            raise SystemExit(f"S3 truth is trivial: {want_s3}")
        pol = {}
        for r in regions:
            s, b, _ = admin.call("POST", "/api/admin/row-security/policies", {
                "name": f"lt-{r.lower().replace(' ', '-')}-{TAG}", "table_pattern": TABLE,
                "filter_sql": f"region = '{r}'", "enforcement": "rewrite", "policy_class": "permissive"})
            if s != 200:
                raise SystemExit(f"policy for {r}: {s} {b}")
            pol[r] = b["id"]
            ledger.add("row-security policy", r, path=f"/api/admin/row-security/policies/{b['id']}")
        users = []
        for k in range(1, N_USERS + 1):
            name = f"lt_{k:02d}"
            region = regions[(k - 1) % len(regions)]
            s, b, _ = admin.call("POST", "/api/admin/row-security/bindings", {
                "policy_kind": "row", "policy_id": pol[region], "principal_type": "user",
                "principal_id": name})
            if s != 200:
                raise SystemExit(f"bind {name}: {s} {b}")
            ledger.add("row-security binding", name, path=f"/api/admin/row-security/bindings/{b['id']}")
            users.append({"name": name, "region": region, "viewer": k > N_USERS - N_VIEWERS,
                          "want_n": {region: counts[region]}, "want_amt": {region: sums[region]},
                          "want_s3": want_s3, "want_draft": {name: 1}})
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})

        s, rep, _ = admin.call("POST", "/api/business-reports", {
            "name": f"lt-rep-{TAG}", "dataset_id": c.DS, "data_source_type": "dataset",
            "column_ids": [c.COL["region"], c.COL["amt"]]})
        RID = rep["id"]
        ledger.add("business report", f"lt-rep-{TAG}", path=f"/api/business-reports/{RID}")
        assert admin.call("POST", f"/api/business-reports/{RID}/publish", {})[0] == 200
        SLUG = f"lt-pv-{TAG}"
        s, pv, _ = admin.call("POST", "/api/published-views", {
            "name": SLUG, "slug": SLUG, "source_type": "business_report",
            "business_report_id": RID, "credential_mode": "publisher"})
        pv_id = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
        if not pv_id:
            raise SystemExit(f"published view: {s} {str(pv)[:200]}")
        ledger.add("published view", SLUG, path=f"/api/published-views/{pv_id}")

        # ── sign-in wave: every user from ONE address, as behind an ingress ──
        t0 = time.time()
        wave_refusals = 0
        for u in users:
            u["token"], u["role"], r = login(u["name"], pw)
            wave_refusals += r
        wave = round(time.time() - t0, 1)
        roles = defaultdict(int)
        for u in users:
            roles[u["role"]] += 1
        print(f"sign-in wave: {len(users)} users from one address in {wave}s, "
              f"{wave_refusals} refused by the login limiter; roles {dict(roles)}")
        results["sign_in_wave"] = {"users": len(users), "seconds": wave, "refused_429": wave_refusals,
                                   "roles": dict(roles)}

        # ── single-user baseline: every user's answer, alone, must be theirs ──
        base_bad = []
        for u in users:
            for name in ops_for(u):
                kind, dt, d, got = OPS[name][0](u, 1)
                _, v, _, _, d = verdict(u, (name, kind, dt, u["name"], d, got))
                if v != "ok":
                    base_bad.append((u["name"], name, v, d))
        print(f"baseline (one at a time): {len(base_bad)} not-ok")
        for b in base_bad[:10]:
            print("   !", b)
        results["baseline_not_ok"] = base_bad
        if base_bad:
            raise SystemExit("the single-user baseline is not clean -- load results would be meaningless")

        results["levels"] = []
        results["load_from"] = "host" if a.host_load else f"inside {INNER_NET}"
        levels = [int(x) for x in a.levels.split(",")]
        if a.host_load:
            observed = []
            for lvl in levels:
                observed.append((lvl, *run_level(users, lvl, a.seconds)))
                time.sleep(10)
        else:
            observed = run_levels_inside(users, levels, a.seconds,
                                         reports_base="http://reports:8000" if a.reports else None)
        by_name = {u["name"]: u for u in users}
        for lvl, raw, health in observed:
            # the truth stays HERE: every answer is judged against the host's Trino truth
            samples = [verdict(by_name[o[3]], o) for o in raw]
            if not samples:
                raise SystemExit(f"level {lvl} produced no operations -- nothing was measured")
            results["levels"].append(summarise(lvl, samples, health))

        # ── recovery: after the load, a single call is as fast as before ──
        rec = [op_report_sync(users[0], 1)[1] for _ in range(3)]
        _, _, _, h = http("GET", API, "/health/live")
        results["recovery"] = {"report_sync_s": [round(x, 2) for x in rec], "health_s": round(h, 3)}
        print(f"recovery: report {results['recovery']['report_sync_s']}s, health {round(h, 3)}s")
    finally:
        removed, left = ledger.cleanup(echo=lambda s: print("  " + s))
        for pid in parked:
            admin.call("PUT", f"/api/admin/row-security/policies/{pid}", {"enabled": True})
        if shared_s3:
            admin.call("PUT", f"/api/connections/{S3_CONN}", {
                "is_shared": False, "name": s3full["name"], "connection_type": s3full["connection_type"], "config": s3full["config"]})
        if shared_conn:
            _, conn, _ = admin.call("GET", "/api/connections/2")
            body = {k: conn[k] for k in ("name", "connection_type", "config")}
            admin.call("PUT", "/api/connections/2", {**body, "is_shared": False})
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        results["cleanup_left"] = left
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=1)
    bad = sum(len(l["bad"]) for l in results.get("levels", []))
    leaks = sum(l["ops"][o]["leak"] for l in results.get("levels", []) for o in l["ops"])
    print(f"\nLEAKS {leaks} · leaks+wrong+errors {bad} · cleanup left {len(left)}")
    return 1 if (bad or left) else 0


RID = SLUG = None
S3_CONN = None

if __name__ == "__main__":
    sys.exit(main())
