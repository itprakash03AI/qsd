"""Only an ADMIN configures a connection; others SELECT one (2026-10-03).

The owner's rule: "only admin allowed to create connections ... other users
just select whatever connection is available, they can't see anything;
connections are also based on group policies".

As the REAL rig users (login ON, docker-compose.auth-rls.yml):
  1. the admin creates a connection (shared), tests it, reads its whole
     (masked) config;
  2. the analyst and the viewer are REFUSED: create, test-a-config (the
     probe that could carry a System Account's secret to any host), edit,
     delete, clone, register a table;
  3. the analyst still SELECTS it: listed, opened, its tables browsed and a
     query RUN on it -- but its config reads as nothing but its table list
     (no host, no user, no password marker);
  4. a connection NOT shared with the analyst stays invisible (404).

    . rigpw.sh
    python scripts/docker_proof/connections_admin_only_proof.py
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

TAG = str(int(time.time()))[-6:]
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:240], flush=True)
    return bool(ok)


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    analyst = Session("rig_analyst", os.environ["QS_RIG_ANALYST_PW"])
    viewer = Session("rig_viewer", os.environ["QS_RIG_VIEWER_PW"])
    undo = []
    try:
        print("\n== 1 . the admin configures")
        trino_cfg = {"host": "qs-trino", "port": 8080, "user": "admin", "catalog": "iceberg",
                     "schema": "qs", "http_scheme": "http"}
        s, conn, _ = admin.call("POST", "/api/connections", {
            "name": f"admin-only-{TAG}", "connection_type": "trino", "config": trino_cfg, "is_shared": True})
        if not check("the admin creates a connection", s in (200, 201) and (conn or {}).get("id"), (s, conn)):
            return 1
        cid = conn["id"]
        undo.append(f"/api/connections/{cid}")
        s, t, _ = admin.call("POST", f"/api/connections/{cid}/test")
        check("the admin's test connects", (t or {}).get("success") is True, (t or {}).get("message"))
        _, full, _ = admin.call("GET", f"/api/connections/{cid}")
        check("the admin reads the whole config", (full or {}).get("config", {}).get("host") == "qs-trino",
              (full or {}).get("config"))
        s, priv, _ = admin.call("POST", "/api/connections", {
            "name": f"admin-private-{TAG}", "connection_type": "trino", "config": trino_cfg, "is_shared": False})
        pid = (priv or {}).get("id")
        if pid:
            undo.append(f"/api/connections/{pid}")

        print("\n== 2 . nobody else configures")
        for who in (analyst, viewer):
            n = who.username
            s, _, _ = who.call("POST", "/api/connections", {
                "name": f"x-{n}-{TAG}", "connection_type": "trino", "config": trino_cfg})
            check(f"{n}: create refused", s == 403, s)
            s, _, _ = who.call("POST", "/api/connections/test", {
                "connection_type": "trino", "config": {**trino_cfg, "host": "attacker.example.com",
                                                        "system_account_id": 1}})
            check(f"{n}: test-an-arbitrary-config refused", s == 403, s)
            s, _, _ = who.call("PUT", f"/api/connections/{cid}", {
                "name": "hijacked", "connection_type": "trino", "config": {**trino_cfg, "host": "attacker.example.com"}})
            check(f"{n}: edit refused", s == 403, s)
            s, _, _ = who.call("DELETE", f"/api/connections/{cid}")
            check(f"{n}: delete refused", s == 403, s)
            s, _, _ = who.call("POST", f"/api/connections/{cid}/clone", {"name": f"cl-{n}-{TAG}"})
            check(f"{n}: clone refused", s == 403, s)
            s, _, _ = who.call("POST", f"/api/connections/{cid}/tables",
                               {"name": "x", "s3_prefix": "x/", "format": "parquet"})
            check(f"{n}: register a table refused", s == 403, s)
        _, after, _ = admin.call("GET", f"/api/connections/{cid}")
        check("the connection is untouched", after.get("name") == f"admin-only-{TAG}"
              and after["config"].get("host") == "qs-trino", (after.get("name"), after["config"].get("host")))

        print("\n== 3 . the analyst SELECTS it and sees nothing of how it is configured")
        _, lst, _ = analyst.call("GET", "/api/connections")
        mine = {x["id"]: x for x in (lst or [])}
        check("listed for the analyst", cid in mine, sorted(mine)[:20])
        seen = mine.get(cid) or {}
        _, one, _ = analyst.call("GET", f"/api/connections/{cid}")
        for label, obj in (("list", seen), ("get", one or {})):
            cfg = obj.get("config") or {}
            check(f"{label}: config carries no host / user / port / catalog",
                  not ({"host", "user", "port", "catalog", "password"} & set(cfg))
                  and "qs-trino" not in str(obj), cfg)
        s, cats, _ = analyst.call("GET", f"/api/sql/connections/{cid}/schemas?catalog=iceberg")
        check("the analyst browses its schemas", s == 200 and "qs" in (cats or []), (s, cats))
        s, run, _ = analyst.call("POST", "/api/sql/execute", {
            "primary_connection_id": cid, "primary_sql": "select count(*) as n from iceberg.qs.trades",
            "row_limit": 5})
        check("the analyst runs a query on it", s == 200 and (run or {}).get("execution_id"), (s, str(run)[:200]))

        print("\n== 4 . a connection not shared with them stays invisible")
        if pid:
            s, _, _ = analyst.call("GET", f"/api/connections/{pid}")
            check("the admin's private connection is a 404 to the analyst", s == 404, s)
            check("and not listed", pid not in mine, pid)
    finally:
        for p in undo:
            admin.call("DELETE", p)
        print(f"\ncleanup: {len(undo)} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
