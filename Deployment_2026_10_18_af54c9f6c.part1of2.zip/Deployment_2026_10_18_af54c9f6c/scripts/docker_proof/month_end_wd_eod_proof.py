"""The month end from WD1 -- ALL THREE messages on WD1, then EOD ONLY for N
work days -- live on the rig with real Kafka messages (2026-10-15).

The owner: "month end file will be generated from WD1, example 30 Sep 2026,
first run date 1st Oct 2026, T+1.  On work day 1 if we have 3 Kafka
messages as SOD, ITD and EOD then we have to wait for all 3, but after WD1
we have to wait for EOD only ... N work days, configurable ... should be
configurable all".

Everything is a ROW set through the routes: a business calendar, the feed
(schedule WD1, business date = the previous month end), its THREE Kafka
dependencies (the message's BUSINESS_EVENT = SOD / ITD / EOD routes each to
its own key) -- each dependency CONFIGURED on the feed: SOD and ITD "a new
message re-runs a delivered date" = no, EOD = yes -- and the feed's re-send
POLICY: re-run on a later run date, hold a same-day re-send, window =
WD1..WDn on the calendar.  No dependency name is matched anywhere.

  W1  WD1 rule: the task WAITS after SOD, still after ITD, and runs only when
      EOD arrives; the file on SFTP == the source, value by value
  W2  after WD1 a new SOD and a new ITD re-run NOTHING: recorded, answered by
      the policy (no open question, no alert), still one delivery
  W3  after WD1 a new EOD re-runs the month end BY ITSELF: a second file,
      named with today's run date, == the source
  W3b and the NEXT new EOD re-runs it AGAIN (found live: the delivered
      re-run never closed its EOD decision, so every later EOD was
      swallowed as "the same open question")
  W4  past WDn (N set one below today's work day) a new EOD is CLOSED:
      alerted, nothing re-runs

The rig cannot wait for real work days: today is WDk of the month end (k
from the calendar), and the delivery's run date is moved to WD1 (1 Oct) in
the database before W2..W4 -- what a delivery made on WD1 looks like.  Said
in every check that depends on it.

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/month_end_wd_eod_proof.py [--keep]
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import os
import subprocess
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, psql, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402
from tetb_real_e2e_proof import DENV, SFTP, TABLES, TOPIC, message, produce_kafka  # noqa: E402

TAG = str(int(time.time()))[-6:]
DS = TABLES["ext"]["data_source"]
ENT = f"WD{TAG}"
BD = dt.date(2026, 9, 30)
WD1 = dt.date(2026, 10, 1)
CAL = f"WD_{TAG}"
NAME = f"WD_{TAG}_MONTH_END"
FILE = f"wd_{TAG}_{{business_date:YYYYMMDD}}_{{run_date:YYYYMMDD}}.csv"
SQL = "SELECT regionkey, name FROM tpch.tiny.region"
DEP = {ev: f"{DS}_{ENT}_{ev}_CLOUD" for ev in ("SOD", "ITD", "EOD")}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    r = Rig()
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    seq = [int(TAG) * 1000]
    today = dt.datetime.now(dt.timezone.utc).date()
    truth = Counter((int(x.split("\t")[0]), x.split("\t")[1].strip('"')) for x in subprocess.run(
        ["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", SQL],
        capture_output=True, text=True, env=DENV, check=True).stdout.splitlines() if x.strip())
    trino_conn = int(os.environ.get("QS_TRINO_CONN", "2"))

    def send(ev):
        seq[0] += 1
        produce_kafka([message(DS, ENT, ev, BD, True, "COMPLETE", 5, seq[0])])

    def arrivals(ev):
        return int(psql(f"select count(*) from dependency_events where dependency_name='{DEP[ev]}' "
                        f"and business_date='{BD}'") or 0)

    def run_row():
        row = psql(f"select id, status, coalesce(action_decision,''), coalesce(action_reason,''), "
                   f"coalesce(triggered_by,'') from feed_runs where feed_config_id={fid} and business_date='{BD}' "
                   f"order by id desc limit 1")
        if not row:
            return {}
        p = row.split("|")
        return {"id": int(p[0]), "status": p[1], "decision": p[2], "reason": p[3], "triggered_by": p[4]}

    def executions():
        rows = psql(f"select id, status, coalesce(output_filename,''), coalesce(total_rows,0) from feed_executions "
                    f"where feed_config_id={fid} and business_date='{BD}' order by started_at")
        return [dict(zip(("id", "status", "file", "rows"), x.split("|"))) for x in rows.splitlines() if x]

    def decisions(ev):
        rows = psql(f"select id, status, coalesce(resolution,''), coalesce(resolved_by,''), evidence::text "
                    f"from feed_regeneration_decisions where feed_config_id={fid} and dependency_name='{DEP[ev]}' "
                    f"order by id")
        out = []
        for x in rows.splitlines():
            i, st, reso, by, ev_ = x.split("|", 4)
            out.append({"id": int(i), "status": st, "resolution": reso, "by": by,
                        "rs": (json.loads(ev_) or {}).get("restatement") or {}})
        return out

    def wait(pred, timeout=300, every=3):
        t0 = time.time()
        while time.time() - t0 < timeout:
            got = pred()
            if got:
                return got
            time.sleep(every)
        return None

    def sftp_rows(name):
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{name}"],
                              capture_output=True, text=True, env=DENV).stdout
        ledger.add("sftp file", name, remover=lambda n=name: (subprocess.run(
            ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{n}"], env=DENV).returncode == 0, "rm"))
        return Counter((int(float(d["regionkey"])), d["name"]) for d in csv.DictReader(io.StringIO(text.lstrip("﻿"))))

    def as_if_delivered_on_wd1():
        psql(f"update feed_runs set completed_at = '{WD1} 12:00:00' where feed_config_id={fid} "
             f"and business_date='{BD}'")

    def open_alerts(kind):
        return int(psql(f"select count(*) from feed_alerts where feed_config_id={fid} and business_date='{BD}' "
                        f"and kind='{kind}' and status='open'") or 0)

    fid = None
    try:
        s, b = r.call("POST", "/api/admin/feed-calendars", {"name": CAL, "weekend_days": [6, 7], "holidays": []})
        ledger.add("calendar", CAL, path=f"/api/admin/feed-calendars/{(b or {}).get('id')}")
        wd_today, d = 0, BD
        while d < today:
            d += dt.timedelta(days=1)
            wd_today += d.isoweekday() < 6
        print(f"== tag {TAG}: business date {BD}; today {today} is WD{wd_today}; truth {sum(truth.values())} rows")
        s, feed = r.call("POST", "/api/feeds", {
            "name": NAME, "source_type": "raw_sql", "source_id": 0, "connection_id": trino_conn,
            "query_params": {"sql": SQL}, "output_format": "csv", "output_filename_template": FILE,
            "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "notify_emails": f"rtb.{TAG}@example.test", "calendar_name": CAL,
            "schedule_declaration": {"kind": "workday_n", "n": 1, "calendar_name": CAL,
                                     "business_date": "previous_month_end"},
            "execution_backend": "native"})
        if not check("P1 the feed: WD1 schedule, business date = the previous month end",
                     s == 200 and (feed or {}).get("id"), (s, str(feed)[:300])):
            return 1
        fid = feed["id"]
        ledger.add("feed", NAME, path=f"/api/feeds/{fid}")
        s, types = r.call("GET", "/api/feed-dependency-types")
        kafka_t = next(t["id"] for t in (types or {}).get("items") or [] if str(t.get("dependency_type")).upper() == "KAFKA")
        s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [
            {"dependency_type_id": kafka_t, "dependency_key": DEP[ev],
             "arrival_sources": [{"kind": "kafka", "topic": TOPIC}], "require_mode": "any",
             "reruns_delivered": ev == "EOD"} for ev in DEP]})
        stored = {x["dependency_key"]: x.get("reruns_delivered") for x in (b or {}).get("items") or []}
        check("P2 three Kafka dependencies, CONFIGURED on the feed: SOD / ITD re-run nothing, EOD re-runs",
              s == 200 and stored == {DEP["SOD"]: False, DEP["ITD"]: False, DEP["EOD"]: True}, (s, stored))
        n_open = wd_today
        s, pol = r.call("PUT", "/api/admin/feed-restatement-policies", {
            "scope": "feed", "scope_id": fid, "name": f"month end WD1..WDn EOD {TAG}",
            "on_new_message": "rerun", "same_run_date": "hold", "window": "workdays",
            "window_workdays": n_open})
        ledger.add("restatement policy", f"feed {fid}",
                   path=f"/api/admin/feed-restatement-policies/{(pol or {}).get('id')}")
        check(f"P3 the policy is a ROW: later run date re-runs, window WD1..WD{n_open}",
              s == 200 and pol.get("window") == "workdays" and pol.get("window_workdays") == n_open, (s, pol))

        # ── W1 -- WD1: all three ───────────────────────────────────────────
        # SOD runs ON the run day: WD1 (1 Oct) makes the task whose DATA date is
        # the previous month end (30 Sep) -- the feed's schedule says so
        s, b = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={WD1.isoformat()}&feed_ids={fid}", timeout=600)
        t = wait(lambda: run_row() or None, 60) or {}
        if not check(f"W1 SOD on WD1 ({WD1}) made the task for business date {BD}, WAITING on its dependencies",
                     t.get("decision") == "WAIT", {**t, "sod": str(b)[:300]}):
            return 1
        for ev in ("SOD", "ITD"):
            send(ev)
            wait(lambda e=ev: arrivals(e) >= 1, 120)
            time.sleep(35)                           # > one dependency-poller tick
            t = run_row()
            check(f"W1 after {ev}: still WAITING (not all three yet)", t.get("decision") == "WAIT" and
                  t.get("status") == "pending" and not executions(), {**t, "arrivals": arrivals(ev)})
        send("EOD")
        t = wait(lambda: (lambda x: x if x.get("status") in ("completed", "failed") else None)(run_row()), 600) or {}
        ex = executions()
        f1 = ex[0]["file"] if ex else ""
        if not check("W1 EOD (the third) releases it: delivered, the file == the source value by value",
              t.get("status") == "completed" and len(ex) == 1 and sftp_rows(f1) == truth and sum(truth.values()) > 0,
              {"run": t, "file": f1}):
            return 1

        # ── W2 -- after WD1: a new SOD / ITD re-runs nothing ───────────────
        as_if_delivered_on_wd1()
        for ev in ("SOD", "ITD"):
            send(ev)
            got = wait(lambda e=ev: decisions(e) or None, 120) or []
            rs = got[-1]["rs"] if got else {}
            check(f"W2 a new {ev} after WD1 (delivery moved to WD1): NOTED, answered by the policy, nothing re-runs",
                  rs.get("action") == "noted" and got[-1]["status"] == "resolved"
                  and got[-1]["by"] == "restatement-policy" and run_row().get("status") == "completed"
                  and len(executions()) == 1,
                  {"action": rs.get("action"), "why": rs.get("why"), "decision": got[-1] if got else None})
        check("W2 no alert for a non-trigger message", open_alerts("restatement_hold") == 0
              and open_alerts("restatement_closed") == 0)

        # ── W3 -- after WD1: a new EOD re-runs by itself ───────────────────
        send("EOD")
        got = wait(lambda: decisions("EOD") or None, 120) or []
        rs = got[-1]["rs"] if got else {}
        t = wait(lambda: (lambda x: x if len(executions()) >= 2 and x.get("status") == "completed" else None)(run_row()), 600) or {}
        ex = executions()
        f2 = ex[-1]["file"] if ex else ""
        check(f"W3 a new EOD on WD{wd_today} (inside WD1..WD{n_open}): RE-RUN by itself, a second file named "
              f"with today's run date == the source",
              rs.get("action") == "rerun" and t.get("triggered_by") == "restatement" and len(ex) == 2
              and f2.endswith(f"_{today:%Y%m%d}.csv") and sftp_rows(f2) == truth,
              {"action": rs.get("action"), "window_closes": rs.get("window_closes"), "files": [x["file"] for x in ex]})

        # ── W3b -- the NEXT new EOD re-runs it again ───────────────────────
        as_if_delivered_on_wd1()
        send("EOD")
        got = wait(lambda: (lambda d: d if len(d) >= 2 else None)(decisions("EOD")), 120) or []
        rs = got[-1]["rs"] if got else {}
        t = wait(lambda: (lambda x: x if len(executions()) >= 3 and x.get("status") == "completed" else None)(run_row()), 600) or {}
        prev = decisions("EOD")[0] if decisions("EOD") else {}
        check("W3b the NEXT new EOD re-runs it AGAIN (the delivered re-run closed its EOD decision)",
              prev.get("status") == "resolved" and prev.get("by") == "engine" and rs.get("action") == "rerun"
              and len(executions()) == 3 and sftp_rows(executions()[-1]["file"]) == truth,
              {"first": (prev.get("status"), prev.get("by")), "second": rs.get("action"),
               "executions": len(executions())})

        # ── W4 -- past WDn: closed ─────────────────────────────────────────
        s, pol = r.call("PUT", "/api/admin/feed-restatement-policies", {
            "scope": "feed", "scope_id": fid, "name": f"month end WD1..WDn EOD {TAG}",
            "on_new_message": "rerun", "same_run_date": "hold", "window": "workdays",
            "window_workdays": n_open - 1})
        as_if_delivered_on_wd1()
        before = len(executions())
        send("EOD")
        got = wait(lambda: (lambda d: d if len(d) >= 3 else None)(decisions("EOD")), 120) or []
        rs = got[-1]["rs"] if got else {}
        time.sleep(20)
        # the window closes on the work day AFTER WDn = WD{wd_today}: the latest work day on
        # or before today -- today on a weekday, Friday on a weekend (2026-10-16: the release
        # check crossed into Saturday UTC and "closes == today" could never hold)
        closes_on = today
        while closes_on.isoweekday() > 5:
            closes_on -= dt.timedelta(days=1)
        check(f"W4 N = {n_open - 1}: on WD{wd_today} the month end is CLOSED -- alerted, nothing re-runs",
              rs.get("action") == "closed" and rs.get("window_closes") == closes_on.isoformat()
              and open_alerts("restatement_closed") == 1 and len(executions()) == before
              and run_row().get("status") == "completed",
              {"action": rs.get("action"), "closes": rs.get("window_closes"), "executions": len(executions())})
    finally:
        if not a.keep:
            if fid:
                psql(f"delete from dependency_events where dependency_name like '%{ENT}%'")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} removed, {len(failed)} failed {failed}")
    passed = sum(res)
    json.dump({"tag": TAG, "business_date": BD.isoformat(), "passed": passed, "total": len(res)},
              open(os.path.join(HERE, "month-end-wd-eod-results.json"), "w"), indent=1)
    print(f"\n{passed}/{len(res)} checks passed")
    return 0 if passed == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
