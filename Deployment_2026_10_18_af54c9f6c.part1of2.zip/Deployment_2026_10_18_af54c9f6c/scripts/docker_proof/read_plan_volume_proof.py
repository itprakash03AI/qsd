"""40 MILLION rows of the owner's shared one-table query on the rig's Spark
PODS through the read plan (2026-10-14, step 5 of
docs/READ_PLAN_ALL_ENGINES_2026_10_14.html).

The table: an Iceberg ``fact_tetb`` (460 columns) on the on-prem object store
(MinIO), written by Trino the way production writes it -- the shared query's
month-end partition holds 40,000,000 rows (10 rounds of 4,000,000, each its
own ``snap_version``) and a DECOY partition holds 4,000,000 more that the
query's WHERE must not return.  The truth is Trino's own count and control
totals over the same query.

The feed: the shared query AS WRITTEN (Trino SQL, the table name mapped to the
registered table), ``spark_k8s``, CSV to SFTP.  The backend plans the table
(pinned snapshot, the exact metadata file), the pod executes the plan.

  V1  the run completes on spark_k8s; wall time and the run's stage times
  V2  the delivered file (awk inside qs-sftp, nothing copied out): rows,
      sum(snap_version), sum(row id in SOURCE_DATA_ROW) == Trino's
  V3  the run record: total_rows == the truth

    python read_plan_volume_proof.py setup     # builds the table (idempotent)
    python read_plan_volume_proof.py run
"""
from __future__ import annotations

import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key       # noqa: E402
from s3_to_s3_proof import one_table_sql                        # noqa: E402
from tetb_real_e2e_proof import SFTP, sb_cli                    # noqa: E402
from volume_feed_proof import file_totals                       # noqa: E402
import month_end_journey as mj                                  # noqa: E402

SOURCE = "iceberg.qs.fact_tetb_vol779318"                      # 4,000,000 rows, 460 columns
TABLE = "iceberg.qs.fact_tetb_rp40m"
REG = "rp40m_fact_tetb"
ROUNDS, DECOY_CODE = 10, "DECOY-RP40M"
STATE = os.path.join(HERE, ".read_plan_volume_state.json")
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


def _cols():
    return [ln.split("\t")[0].strip('"') for ln in sb_cli(f"SHOW COLUMNS FROM {SOURCE}").splitlines()
            if ln.strip()]


def _select(code: str, version: int) -> str:
    out = []
    for c in _cols():
        if c == "code":
            out.append(f"'{code}' AS code")
        elif c == "snap_version":
            out.append(f"CAST({version} AS BIGINT) AS snap_version")
        else:
            out.append(c)
    return f"SELECT {', '.join(out)} FROM {SOURCE}"


def truth_of(sql: str) -> dict:
    res = sb_cli("SELECT count(*), sum(snap_version), "
                 "sum(coalesce(try_cast(split_part(source_data_row, ':', 2) AS BIGINT), 0)) FROM (\n"
                 + sql + "\n) q;\n", stdin=True).strip().replace('"', "").split("\t")
    return {"rows": int(res[0]), "sum_snap": int(res[1]), "sum_id": int(res[2])}


#: One INSERT writes a quarter of a round (1,000,000 rows x 460 columns): the
#: rig's 6 GB Trino was OOM-killed writing a whole round in one statement.
SLICES = 4


def setup():
    built = (int(sb_cli(f"SELECT count(*) FROM {TABLE}").strip().strip('"'))
             if TABLE.split(".")[-1] in sb_cli("SHOW TABLES FROM iceberg.qs") else -1)
    want = (ROUNDS + 1) * 4_000_000
    if built != want:
        t0 = time.time()
        sb_cli(f"DROP TABLE IF EXISTS {TABLE}")
        sb_cli(f"CREATE TABLE {TABLE} WITH (format = 'PARQUET', format_version = 2, "
               f"partitioning = ARRAY['business_close_date','code','businessevent']) AS "
               + _select(mj.ENTITY, 1) + " WITH NO DATA;\n", stdin=True)
        for v, code in [(v, mj.ENTITY) for v in range(1, ROUNDS + 1)] + [(99, DECOY_CODE)]:
            for k in range(SLICES):
                sb_cli(f"INSERT INTO {TABLE} " + _select(code, v)
                       + f" WHERE mod(try_cast(split_part(source_data_row, ':', 2) AS BIGINT), {SLICES}) = {k}"
                       + ";\n", stdin=True)
            print(f"  round {v} ({code}) written ({round(time.time() - t0)} s)", flush=True)
        print(f"  built in {round(time.time() - t0)} s", flush=True)
    loc = [ln for ln in sb_cli(f"SHOW CREATE TABLE {TABLE}").replace("\\n", "\n").splitlines()
           if "location" in ln][0].split("'")[1]
    files = sb_cli(f'SELECT count(*), sum(file_size_in_bytes) FROM iceberg.qs."{TABLE.split(".")[-1]}$files"')
    t0 = time.time()
    truth = truth_of(one_table_sql(TABLE))
    total = int(sb_cli(f"SELECT count(*) FROM {TABLE}").strip().strip('"'))
    st = {"location": loc, "truth": truth, "table_rows": total, "files": files.strip(),
          "truth_seconds": round(time.time() - t0, 1)}
    json.dump(st, open(STATE, "w"), indent=1)
    print(json.dumps(st, indent=1))
    return st


def run():
    st = json.load(open(STATE))
    truth = st["truth"]
    check("the table holds the query's 40,000,000 rows plus a decoy partition",
          truth["rows"] == 40_000_000 and st["table_rows"] > truth["rows"], st)
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    minio = next(c for c in conns if c["connection_type"] == "s3"
                 and (c.get("config") or {}).get("bucket_name") == "qs-data")
    prefix = st["location"].split("qs-data/", 1)[1].rstrip("/") + "/"
    r.call("DELETE", f"/api/connections/{minio['id']}/tables/{REG}")
    s, b = r.call("POST", f"/api/connections/{minio['id']}/tables", {
        "name": REG, "s3_prefix": prefix, "format": "iceberg",
        "description": "read-plan 40M proof: fact_tetb on the on-prem store"})
    check("the 40M table registered on the on-prem connection", s in (200, 201), f"{s} {str(b)[:200]}")
    name = "RP_POD_40M"
    sql = one_table_sql("icbg.fins.fact_tetb")
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": minio["id"],
            "query_params": {"sql": sql, "table_map": {"primary": {"icbg.fins.fact_tetb": REG}}},
            "output_format": "csv", "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
            "execution_backend": "spark_k8s", "is_active": True, "schedule_enabled": False,
            "notify_on_failure": False, "description": "Proof: 40M rows through the read plan on Spark pods"}
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    f = next((x for x in feeds if x["name"] == name), None)
    s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
    if s not in (200, 201):
        raise SystemExit(f"{name}: {s} {str(b)[:500]}")
    fid = f["id"] if f else b["id"]
    bd = mj.BD.isoformat()
    fname = f"{name}_{mj.BD:%Y%m%d}.csv"
    import subprocess
    subprocess.run(["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fname}"])
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    run_row = r.run_row(fid, bd)
    if run_row is None:
        r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": bd, "end_date": bd, "deliver": True,
                                                       "reason": "read-plan 40M proof"})
    else:
        r.call("POST", f"/api/feed-runs/{run_row['id']}/rerun", {"reason": "read-plan 40M proof"})
    t0, row = time.time(), ""
    while time.time() - t0 < 6 * 3600:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                   f"and business_date='{bd}' order by id desc limit 1")
        if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
            break
        time.sleep(30)
    wall = round(time.time() - t0)
    eid, status = row.split("|")
    info = psql(f"select coalesce(execution_backend,''), coalesce(total_rows,0), coalesce(error_message,''), "
                f"coalesce(stage_timings::text,'{{}}') from feed_executions where id={eid}").split("|", 3)
    check(f"V1 {name} completed on spark_k8s", status == "completed" and info[0] == "spark_k8s",
          f"{status} backend={info[0]} wall={wall}s {info[2][:400]}")
    stages = json.loads(info[3] or "{}")
    print("   stage timings:", json.dumps(stages)[:1500], flush=True)
    check("V3 the run record: total_rows == Trino", int(info[1]) == truth["rows"], f"{info[1]} vs {truth['rows']}")
    if status == "completed":
        got = file_totals(fname, 460)
        check("V2 the delivered file == Trino (rows, sum snap_version, sum row id)",
              got.get("rows") == truth["rows"] and got.get("sum_snap") == truth["sum_snap"]
              and got.get("sum_id") == truth["sum_id"], f"file {got} truth {truth}")
    out = os.path.join(HERE, "read-plan-volume-results.json")
    json.dump({"checks": CHECKS, "wall_seconds": wall, "stage_timings": stages, "truth": truth,
               "table": st}, open(out, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {out}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(setup() and 0 if sys.argv[1:] == ["setup"] else run())
