"""The owner's two feed-form bugs, proven on the live rig through the routes
the form calls (2026-10-11): "no query selection in cross source" and "where
clause not getting generic once we have saved queries".

Two saved queries carry LITERAL filters (orderdate = DATE '1995-01-01',
orderpriority = '1-URGENT') on two DIFFERENT connections (qs-trino = cloud,
qs-trino-sb = the Starburst-shaped on-prem).  A feed takes the first as its
source and the second as its SECOND SIDE (a saved query on the second
connection, UNION ALL by name), and BINDS each literal on both sides:
orderdate -> {BUSINESSDATE}, orderpriority -> a new parameter PRIORITY.

  B1  resolve-draft lists both sides' literal predicates and the merge plan
  B2  run for business date 1995-03-15 with PRIORITY = 2-HIGH: the file ==
      cloud rows UNION ALL on-prem rows for THAT date and priority (vs the
      two Trino CLIs; the literal values would have given other rows)
  B3  the on-prem saved query is edited (its literal changes): the next run
      FAILS naming the stale binding -- it never runs the old literal

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/feed_second_side_bindings_proof.py
"""
from __future__ import annotations

import collections
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402

TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
CA = os.path.join(HERE, "starburst_like", "generated", "ca.pem")
LIT_DATE, LIT_PRIO = "1995-01-01", "1-URGENT"
RUN_DATE, RUN_PRIO = "1995-03-15", "2-HIGH"


def sql_for(date_lit: str, prio: str) -> str:
    return ("select orderkey, orderstatus, orderpriority, orderdate from tpch.tiny.orders "
            f"where orderdate = DATE '{date_lit}' and orderpriority = '{prio}'")


def trino_rows(container_cmd: list, sql: str) -> list:
    out = subprocess.run(container_cmd + ["--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True, env=DENV, timeout=300)
    if out.returncode != 0:
        raise RuntimeError(out.stderr[-300:])
    return [tuple(l.split("\t")) for l in out.stdout.replace("\r", "").splitlines() if l.strip()]


def main() -> int:
    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit("source ~/.qs_keys/starburst_like.env")
    r = Rig()
    undo: list = []
    cloud_cli = ["docker", "exec", "qs-trino", "trino"]
    prem_cli = ["docker", "exec", "-e", f"TRINO_PASSWORD={pw}", "qs-trino-sb", "trino", "--server",
                "https://localhost:8443", "--insecure", "--user", "qs_analyst", "--password"]
    try:
        # ── connections + the two saved queries with LITERAL filters ────────
        _, conns = r.call("GET", "/api/connections")
        conns = conns if isinstance(conns, list) else (conns or {}).get("items") or (conns or {}).get("connections") or []
        cloud = next((c["id"] for c in conns if c.get("connection_type") in ("trino", "starburst")
                      and "qs-trino" == str((c.get("config") or {}).get("host"))), None)
        s, sb = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-bind-{TAG}", "connection_type": "starburst",
            "config": {"host": "qs-trino-sb", "port": 8443, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": True,
                       "ca_cert_pem": open(CA, encoding="utf-8").read(), "catalog": "tpch", "schema": "tiny"}})
        prem = (sb or {}).get("id")
        if prem:
            undo.insert(0, f"/api/connections/{prem}")
        check("P cloud (qs-trino) and on-prem (qs-trino-sb) connections", bool(cloud and prem), {"cloud": cloud, "prem": prem})
        qids = {}
        for side, cid in (("cloud", cloud), ("prem", prem)):
            s, q = r.call("POST", "/api/queries", {"name": f"bind_{side}_{TAG}",
                                                  "query_config": {"files": [], "raw_sql": sql_for(LIT_DATE, LIT_PRIO), "connection_id": cid}})
            qids[side] = (q or {}).get("id")
            if qids[side]:
                undo.append(f"/api/queries/{qids[side]}")
        check("P two saved queries with LITERAL filters, one per connection", all(qids.values()), qids)

        # ── B1 the draft the form resolves ──────────────────────────────────
        draft = {"name": f"BIND_{TAG}", "source_type": "saved_query", "source_id": qids["cloud"], "connection_id": cloud,
                 "secondary_connection_id": prem, "secondary_source_type": "saved_query",
                 "secondary_source_id": qids["prem"], "combine_mode": "union"}
        s, d = r.call("POST", "/api/feeds/resolve-draft", draft)
        txt = str(d)
        check("B1 resolve-draft lists both sides' literal predicates (orderdate, orderpriority) and the merge plan",
              s == 200 and "orderpriority" in txt.lower() and LIT_PRIO in txt and LIT_DATE in txt,
              {"status": s, "excerpt": txt[:400]})

        bindings = []
        for side in ("primary", "secondary"):
            bindings.append({"side": side, "column": "orderdate", "literal": LIT_DATE, "token": "BUSINESSDATE"})
            bindings.append({"side": side, "column": "orderpriority", "literal": LIT_PRIO, "token": "PRIORITY"})
        s, fb = r.call("POST", "/api/feeds", {**draft, "output_format": "csv", "destination_type": "local",
                                              "destination_config": {"path": "/app/data/feeds"},
                                              "execution_backend": "native",
                                              "query_params": {"PRIORITY": RUN_PRIO},
                                              "token_bindings": bindings})
        fid = (fb or {}).get("id")
        if fid:
            undo.insert(0, f"/api/feeds/{fid}")
        check("B1 the feed is saved with a saved-query SECOND SIDE and four token bindings",
              s == 200 and fid and len((fb or {}).get("token_bindings") or []) == 4
              and (fb or {}).get("secondary_source_id") == qids["prem"], (s, str(fb)[:300]))
        if not fid:
            return 1

        def run(date_s: str):
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": date_s, "end_date": date_s, "deliver": True,
                                                                "reason": "binding proof (test data only)"})
            t0 = time.time()
            while time.time() - t0 < 600:
                _, ex = r.call("GET", f"/api/feeds/{fid}/executions")
                ex = ex if isinstance(ex, list) else (ex or {}).get("items") or []
                done = [e for e in ex if str(e.get("business_date") or "")[:10] == date_s
                        and e.get("status") in ("completed", "failed", "error")]
                if done:
                    return done[0]
                time.sleep(3)
            return {}

        # ── B2 the bound values run, not the literals ───────────────────────
        e = run(RUN_DATE)
        body = ""
        if e.get("destination_path"):
            body = subprocess.run(["docker", "exec", "qs-local-api", "cat", e["destination_path"]],
                                  capture_output=True, text=True, env=DENV).stdout
        lines = [l for l in body.replace("\r", "").splitlines() if l.strip()]
        hdr = [h.strip('"').lower() for h in lines[0].split(",")] if lines else []
        got = collections.Counter(tuple(dict(zip(hdr, [v.strip('"') for v in l.split(",")]))[k]
                                        for k in ("orderkey", "orderpriority", "orderdate")) for l in lines[1:])
        want = collections.Counter()
        for cli in (cloud_cli, prem_cli):
            for row in trino_rows(cli, sql_for(RUN_DATE, RUN_PRIO)):
                want[(row[0], row[2], row[3])] += 1
        lit = len(trino_rows(cloud_cli, sql_for(LIT_DATE, LIT_PRIO)))
        check(f"B2 run for {RUN_DATE} / PRIORITY={RUN_PRIO}: the file == cloud UNION ALL on-prem for the BOUND values "
              f"({sum(want.values())} rows; the literals would select {lit} per side)",
              e.get("status") == "completed" and got == want and sum(want.values()) > 0,
              {"status": e.get("status"), "rows": sum(got.values()), "want": sum(want.values()), "err": str(e.get("error_message"))[:300]})

        # ── B3 a stale binding refuses ──────────────────────────────────────
        s, _ = r.call("PUT", f"/api/queries/{qids['prem']}", {"query_config": {"files": [], "raw_sql": sql_for(LIT_DATE, "3-MEDIUM"),
                                                                              "connection_id": prem}})
        check("B3 the on-prem saved query is edited (its priority literal changes)", s == 200, s)
        e2 = run("1995-03-16")
        msg = str(e2.get("error_message") or "")
        check("B3 the next run FAILS naming the stale binding -- it never runs the old literal",
              e2.get("status") in ("failed", "error") and ("binding" in msg.lower() or "orderpriority" in msg.lower()),
              {"status": e2.get("status"), "error": msg[:300]})
    finally:
        for path in undo:
            try:
                r.call("DELETE", path)
            except Exception:  # noqa: BLE001
                pass
        print(f"\ncleanup: {len(undo)} objects removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
