"""A brand-new feed, created the way a user creates one, on the rig rebuilt
from the release ZIP -- delivered by SFTP and compared VALUE BY VALUE with
the source (2026-10-15).

The owner, after the git history was rewritten and the bundle repacked:
"try to create new feed via Docker to prove 100%".  The rig's api /
scheduler / executor / reports / published-api / ui run images built FROM
the extracted Deployment_2026_10_15_a8259913.zip (the DuckDB extensions
copied in, as the owner's build does).  Two feeds are created through
POST /api/feeds, run for a business date through the backfill route (the
run-now road), delivered to qs-sftp, and the delivered CSV is read back
from the SFTP server and compared ROW BY ROW with the truth Trino reads:

  F1  Trino (tpch.tiny.orders, 15,000 rows) -> CSV -> SFTP
  F2  AWS S3 read DIRECTLY by QueryStudio (connection aws-real, the
      primary read path) -> CSV -> SFTP; truth = the same Iceberg table
      through Trino's iceberg_aws catalog

Every comparison asserts its own COUNT and a non-zero truth (a loop over
nothing must not pass).  The feeds are deactivated afterwards (no SOD run).
"""
from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import time
from collections import Counter
from decimal import Decimal, InvalidOperation

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key       # noqa: E402
from tetb_real_e2e_proof import SFTP                            # noqa: E402

BD = os.environ.get("QS_PROOF_BD", "2026-10-15")
COB = os.environ.get("QS_XS_COB", "2025-09-30")
TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
CHECKS = []

FEEDS = {
    "F1": {"conn": "trino", "cols": ["orderkey", "custkey", "orderstatus", "totalprice", "orderdate"],
           "feed_sql": "SELECT orderkey, custkey, orderstatus, totalprice, orderdate FROM tpch.tiny.orders",
           "truth_sql": "SELECT orderkey, custkey, orderstatus, totalprice, orderdate FROM tpch.tiny.orders"},
    "F2": {"conn": "aws-real", "cols": ["sap_company_id", "business_event", "business_close_date", "gbp_currency_amount"],
           "feed_sql": ("SELECT sap_company_id, business_event, business_close_date, gbp_currency_amount FROM fact_tetb "
                        f"WHERE business_close_date = DATE '{COB}' AND business_event = 'BOOKING'"),
           "truth_sql": ("SELECT sap_company_id, business_event, business_close_date, gbp_currency_amount "
                         f"FROM iceberg_aws.fin.fact_tetb WHERE business_close_date = DATE '{COB}' "
                         "AND business_event = 'BOOKING'")},
}


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:600]}" if detail else ""), flush=True)


def trino_rows(sql):
    """Strict: a failed query RAISES (never compares an error text)."""
    r = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                       capture_output=True, text=True, env=DENV)
    if r.returncode != 0:
        raise SystemExit(f"truth query failed: {r.stderr.strip()[-400:]}")
    return [line.split("\t") for line in r.stdout.splitlines() if line.strip()]


def norm(v):
    v = (v or "").strip().strip('"')
    try:
        d = Decimal(v)
        return format(d.normalize(), "f") if d == d.to_integral_value() or "." in v else v
    except InvalidOperation:
        return v[:10] if len(v) >= 10 and v[4:5] == "-" and v[7:8] == "-" else v


def norm_row(vals):
    out = []
    for v in vals:
        n = norm(v)
        try:
            n = format(Decimal(n).normalize(), "f")
        except InvalidOperation:
            pass
        out.append(n)
    return tuple(out)


def conn_id(r, name):
    _, conns = r.call("GET", "/api/connections")
    items = conns if isinstance(conns, list) else (conns.get("items") or conns.get("connections") or [])
    if name == "trino":
        hit = next((c for c in items if c.get("id") == int(os.environ.get("QS_TRINO_CONN", "2"))), None)
    else:
        hit = next((c for c in items if c.get("name") == name), None)
    if not hit:
        raise SystemExit(f"no connection {name}")
    return hit["id"]


def create_and_run(r, key, spec):
    name = f"NEW_FEED_PROOF_{key}_{TAG}"
    cid = conn_id(r, spec["conn"])
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": cid,
            "query_params": {"sql": spec["feed_sql"]}, "output_format": "csv", "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
            "execution_backend": "native", "is_active": True, "schedule_enabled": False,
            "notify_on_failure": False, "description": "Proof: a new feed on the rig rebuilt from the release zip"}
    s, b = r.call("POST", "/api/feeds", body)
    check(f"{key} feed CREATED through POST /api/feeds (connection {spec['conn']} id {cid})",
          s in (200, 201) and b.get("id"), f"HTTP {s} {str(b)[:200] if s not in (200, 201) else 'id ' + str(b.get('id'))}")
    if s not in (200, 201):
        return None
    fid = b["id"]
    stored = psql(f"select destination_config::text from feed_configs where id={fid}")
    check(f"{key} the SFTP password is stored ENCRYPTED, never in clear",
          '"password": "enc::' in stored and SFTP["password"] not in stored, "enc:: prefix" if "enc::" in stored else stored[:80])
    s, bf = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": BD, "end_date": BD, "deliver": True,
                                                         "reason": "new feed proof on the zip-built rig"})
    check(f"{key} run requested for business date {BD}", s in (200, 201, 202), f"HTTP {s} {str(bf)[:200]}")
    t0, row = time.time(), ""
    while time.time() - t0 < 1800:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} "
                   f"and business_date='{BD}' order by started_at desc nulls last limit 1")
        if row and row.split("|")[1] in ("completed", "failed", "cancelled", "partial_failure"):
            break
        time.sleep(5)
    if not row:
        check(f"{key} an execution was created", False, "no feed_executions row in 30 min")
        return None
    eid, status = row.split("|")
    _, ex = r.call("GET", f"/api/feed-executions/{eid}")
    ex = ex or {}
    check(f"{key} execution COMPLETED ({round(time.time() - t0)} s)", status == "completed",
          f"{status} {ex.get('error_message') or ''}")
    r.call("PUT", f"/api/feeds/{fid}", {"is_active": False})          # no SOD run tomorrow
    return {"fid": fid, "eid": eid, "name": name, "ex": ex,
            "file": f"{name}_{BD.replace('-', '')}.csv"}


def sftp_file(fname):
    r = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fname}"],
                       capture_output=True, env=DENV)
    return r.stdout.decode("utf-8-sig") if r.returncode == 0 else None


def main():
    r = Rig()
    imgs = {c: subprocess.run(["docker", "inspect", c, "--format", "{{.Image}}"], capture_output=True,
                              text=True).stdout.strip()[7:19]
            for c in ("qs-local-api", "qs-local-scheduler")}
    check("the rig runs the images built from the release zip",
          all(v == os.environ.get("QS_ZIP_API_IMAGE", v) for v in imgs.values()), imgs)
    for key, spec in FEEDS.items():
        truth = Counter(norm_row(x) for x in trino_rows(spec["truth_sql"]))
        n_truth = sum(truth.values())
        check(f"{key} truth read by Trino: {n_truth:,} rows (non-zero)", n_truth > 0, n_truth)
        run = create_and_run(r, key, spec)
        if not run:
            continue
        ex = run["ex"]
        check(f"{key} the execution's row count == the truth", int(ex.get("total_rows") or -1) == n_truth,
              f"{ex.get('total_rows')} vs {n_truth}")
        body = sftp_file(run["file"])
        check(f"{key} the file is ON the SFTP server ({run['file']})", body is not None and len(body) > 0,
              f"{len(body or '')} bytes")
        if not body:
            continue
        rd = csv.DictReader(io.StringIO(body))
        hdr = [h.lower().strip() for h in (rd.fieldnames or [])]
        check(f"{key} the file's columns are the feed's, in order", hdr == spec["cols"], hdr)
        got = Counter(norm_row([row.get(k) or row.get(k.upper()) or "" for k in (rd.fieldnames or [])]) for row in rd)
        n_got = sum(got.values())
        miss, extra = truth - got, got - truth
        # negative control: ONE changed value must be seen, or this check cannot fail
        if got:
            k0 = next(iter(got))
            bent = got.copy()
            bent[k0] -= 1
            bent[k0[:-1] + (k0[-1] + "1",)] += 1
            check(f"{key} negative control: one changed value IS detected", (truth - bent) or (bent - truth))
        check(f"{key} VALUE BY VALUE: every one of the {n_truth:,} rows in the file == the source, nothing extra",
              n_got == n_truth and not miss and not extra and n_got > 0,
              {"file_rows": n_got, "truth_rows": n_truth, "compared_values": n_got * len(spec["cols"]),
               "missing_eg": list(miss.items())[:2], "extra_eg": list(extra.items())[:2]})
        da = psql(f"select status, verification, destination_uri from delivery_attempts "
                  f"where feed_config_id={run['fid']} and business_date='{BD}' order by id desc limit 1")
        check(f"{key} delivery attempt SUCCEEDED and was VERIFIED on the server",
              da.startswith("succeeded|verified|") and run["file"] in da, da)
        st = psql(f"select stage_timings::text from feed_executions where id={run['eid']}")
        check(f"{key} read by QueryStudio's OWN engine (native lane, query_native stage)",
              ex.get("execution_backend") == "native" and '"query_native"' in st,
              {"backend": ex.get("execution_backend"), "query_native" : '"query_native"' in st})
    path = os.path.join(HERE, "new-feed-e2e-results.json")
    json.dump({"business_date": BD, "checks": CHECKS}, open(path, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
