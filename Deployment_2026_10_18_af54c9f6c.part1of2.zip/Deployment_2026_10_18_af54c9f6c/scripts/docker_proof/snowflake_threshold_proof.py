"""BEYOND THE THRESHOLD -- query builder, published API, reports on the REAL
Snowflake account through Docker (2026-10-04, login ON).

Owner: "all three features -- BQB, API, Reports -- 1 million records with
possible complex cases ... go beyond the threshold where it can fail".

Data: QS_DEMO.FIN.FACT_TRADES (10,000,000 rows) joined to DIM_COUNTRY /
DIM_PRODUCT.  Every answer is checked against Snowflake (direct session,
result cache off).  Every limit is pushed PAST: the pass condition for an
over-the-limit case is a GRACEFUL answer -- a 4xx / 503 naming the limit, or
a disclosed truncation -- never a 500, a hang, a crash, or a silent short
answer.  docker stats sampled every 2 s; container restarts / OOM checked at
the end.

  Q  query builder (/api/execute): complex SQL (CTE + window + QUALIFY,
     COUNT DISTINCT, HAVING, UNION ALL, CASE, NULL / unicode literals, a
     1,000-value IN list), the structured (visual) config path, result sizes
     5k -> 50k -> 500k -> 1M -> 10M rows, deep paging, 15 concurrent users,
     cancel mid-query.
  R  reports: multi-measure / multi-filter / parameter / sections, a
     high-cardinality grouping (client x day, millions of groups), CSV /
     Excel past Excel's 1,048,576-row sheet limit, PDF of a large report,
     12 concurrent uncached runs.
  A  published API: page size at / past max_limit, malformed requests,
     injection-shaped filter values, 100 unpaced consumers (overload), the
     whole 10M-row fact through /bulk, 3 bulk pulls at once.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_threshold_proof.py
"""
from __future__ import annotations

import concurrent.futures as cf
import csv
import io
import json
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from snowflake_wide_table_proof import sf  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
OUT = os.environ.get("QS_PERF_OUT", "threshold-results.json")
ONLY = set(filter(None, os.environ.get("QS_ONLY", "").split(",")))   # e.g. Q,R,A
TAG = str(int(time.time()))[-6:]
API = "http://localhost:8000"
PUB = "http://localhost:8003"
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
F = "QS_DEMO.FIN.FACT_TRADES"
JOIN = (f"from {F} f join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY = c.COUNTRY "
        "join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID = p.PRODUCT_ID")
CONTAINERS = ["qs-local-api", "qs-local-published-api", "qs-local-reports", "qs-local-postgres"]
res, results = [], {"checks": [], "timings": [], "resources": {}}
T_START = time.time()


def check(area, name, ok, detail=""):
    res.append(bool(ok))
    results["checks"].append({"area": area, "name": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS" if ok else "FAIL"), f"[{area}]", name, "--", str(detail)[:300], flush=True)
    return bool(ok)


def graceful(status):
    """An over-the-limit answer that is a refusal with a reason, not a crash."""
    return status in (400, 403, 404, 409, 413, 416, 422, 429, 503)


class Sampler(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.phase, self.peaks, self.stop_ev = "setup", {}, threading.Event()

    def run(self):
        while not self.stop_ev.is_set():
            out = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"]
                                 + CONTAINERS, capture_output=True, text=True).stdout
            for line in out.splitlines():
                try:
                    n, cpu, mem = line.split("|")
                    m = mem.split("/")[0].strip()
                    mib = float(m[:-3]) * (1024 if m.endswith("GiB") else 1)
                    p = self.peaks.setdefault(f"{self.phase} | {n}", {"cpu_pct": 0.0, "mem_mib": 0.0})
                    p["cpu_pct"] = max(p["cpu_pct"], float(cpu.strip("%")))
                    p["mem_mib"] = max(p["mem_mib"], mib)
                except Exception:  # noqa: BLE001
                    pass
            self.stop_ev.wait(2)


S = Sampler()


def http(base, method, path, token=None, key=None, body=None, timeout=1800, raw=False):
    h = {"Content-Type": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    if key:
        h["X-API-Key"] = key
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, headers=h, method=method)
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            b, st, hd = r.read(), r.status, dict(r.headers)
    except urllib.error.HTTPError as e:
        b, st, hd = e.read(), e.code, dict(e.headers)
    except Exception as e:  # noqa: BLE001
        return -1, f"{type(e).__name__}: {e}", {}, round(time.time() - t0, 2)
    dt = round(time.time() - t0, 2)
    if raw:
        return st, b, hd, dt
    try:
        return st, json.loads(b or b"{}"), hd, dt
    except Exception:  # noqa: BLE001
        return st, b[:400], hd, dt


def timed(label, fn):
    t0 = time.time()
    out = fn()
    results["timings"].append({"case": label, "s": round(time.time() - t0, 2), "phase": S.phase})
    return out


def run_exec(tok, body, timeout=1800):
    """/api/execute (the query builder's run) -> (status, rows|error, meta)."""
    st, r, _, _ = http(API, "POST", "/api/execute", tok, body=body, timeout=120)
    if st != 200 or not isinstance(r, dict) or not r.get("execution_id"):
        return st, r, {}
    eid = r["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, s, _, _ = http(API, "GET", f"/api/executions/{eid}/status", tok)
        status = (s or {}).get("status") if isinstance(s, dict) else None
        if status in ("completed", "success", "finished"):
            return 200, eid, s
        if status in ("failed", "error", "cancelled"):
            return 500, (s or {}).get("error_message") or s, s
        time.sleep(1)
    return -1, "timeout", {}


def page(tok, eid, n=1, size=1000):
    st, b, _, _ = http(API, "GET", f"/api/executions/{eid}/results?page={n}&page_size={size}", tok)
    if st != 200 or not isinstance(b, dict):
        return st, [], b
    names = [x["name"] if isinstance(x, dict) else x for x in b.get("columns") or []]
    return st, [r if isinstance(r, dict) else dict(zip(names, r)) for r in b.get("rows") or []], b


def norm(v):
    if isinstance(v, (Decimal, float)):
        return round(float(v), 2)
    t = str(v)
    if len(t) >= 10 and t[4:5] == "-" and t[7:8] == "-":
        return t[:10]
    try:
        return round(float(t), 2)
    except ValueError:
        return t


def as_set(rows, keys):
    return {tuple(norm(r.get(k) if isinstance(r, dict) else r[i]) for i, k in enumerate(keys)) for r in rows}


def main():
    def container_state():
        st = {}
        for cname in CONTAINERS:
            out = subprocess.run(["docker", "inspect", cname, "--format", "{{.State.OOMKilled}} {{.RestartCount}} {{.State.Status}}"],
                                 capture_output=True, text=True).stdout.strip()
            st[cname] = out
        return st

    def worker_deaths():
        out = subprocess.run(["docker", "logs", "qs-local-published-api", "--since", f"{int(time.time() - T_START) + 5}s"],
                             capture_output=True, text=True, encoding="utf-8", errors="replace")
        return (out.stdout or "").count("died") + (out.stderr or "").count("died")

    global T_START
    T_START = time.time()
    before = container_state()
    results["containers_before"] = before
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    tok = admin.token
    con = sf()
    cur = con.cursor()
    cur.execute("alter session set USE_CACHED_RESULT = FALSE")
    sfq = lambda q: cur.execute(q).fetchall()  # noqa: E731
    S.start()
    undo = []
    try:
        # ════════════════════════════ Q . query builder ═══════════════════
        if not ONLY or "Q" in ONLY:
            S.phase = "Q complex"
            cases = [
                ("CTE + window RANK + QUALIFY: top desk per region by amount",
                 f"with d as (select c.REGION, f.DESK, sum(f.AMOUNT) amt {JOIN} group by 1,2) "
                 "select REGION, DESK, amt from d qualify rank() over (partition by REGION order by amt desc) = 1",
                 ("REGION", "DESK", "AMT")),
                ("COUNT DISTINCT + HAVING + CASE bucket",
                 f"select case when f.AMOUNT >= 1000000 then 'BIG' when f.AMOUNT >= 100000 then 'MID' else 'SMALL' end as BUCKET, "
                 f"count(distinct f.CLIENT_ID) as CLIENTS, count(*) as N {JOIN} group by 1 having count(*) > 10",
                 ("BUCKET", "CLIENTS", "N")),
                ("UNION ALL of two filtered aggregates + NULL and unicode literals",
                 f"select 'BUY' as SIDE, sum(f.QUANTITY) as Q, null as NOTE, 'Zürich ✓' as LBL {JOIN} where f.SIDE='BUY' "
                 f"union all select 'SELL', sum(f.QUANTITY), null, 'Zürich ✓' {JOIN} where f.SIDE='SELL'",
                 ("SIDE", "Q", "LBL")),
                ("a 1,000-value IN list",
                 f"select count(*) as N, sum(f.AMOUNT) as S from {F} f where f.CLIENT_ID in ("
                 + ",".join(f"'CLIENT_{i}'" for i in range(1, 1001)) + ")",
                 ("N", "S")),
                ("window running total over 365 days",
                 f"select TRADE_DATE, sum(sum(AMOUNT)) over (order by TRADE_DATE) as RUN from {F} group by TRADE_DATE",
                 ("TRADE_DATE", "RUN")),
            ]
            for label, sql, keys in cases:
                truth = sfq(sql)
                st, eid, meta = timed(f"Q {label}", lambda: run_exec(tok, {"connection_id": CID, "raw_sql": sql,
                                                                           "output_format": "json", "cache_strategy": "bypass"}))
                rows = []
                if st == 200:
                    n = 1
                    while len(rows) < len(truth) and n < 50:
                        _, pr, _ = page(tok, eid, n, 1000)
                        if not pr:
                            break
                        rows += pr
                        n += 1
                got = as_set([{k: r.get(k) for k in keys} for r in rows], keys)
                want = {tuple(norm(x) for x in t[:len(keys)]) if keys != ("SIDE", "Q", "LBL")
                        else (norm(t[0]), norm(t[1]), norm(t[3])) for t in truth}
                check("Q", f"{label}: == Snowflake", st == 200 and got == want and want,
                      {"status": st, "rows": len(rows), "truth": len(truth), "diff": list(want ^ got)[:3], "err": str(eid)[:200] if st != 200 else ""})

            S.phase = "Q visual"
            qc = {"files": [F], "columns": ["COUNTRY", "SIDE"], "group_by": ["COUNTRY", "SIDE"],
                  "aggregations": [{"column": "AMOUNT", "function": "SUM", "alias": "AMT"},
                                   {"column": "CLIENT_ID", "function": "COUNT", "alias": "CLIENTS", "distinct": True}],
                  "filters": [{"column": "TRADE_DATE", "operator": "between", "value": ["2026-01-01", "2026-03-31"]},
                              {"column": "COUNTRY", "operator": "in", "value": ["GB", "DE", "FR", "US", "JP"]}],
                  "connection_id": CID}
            truth = sfq(f"select COUNTRY, SIDE, sum(AMOUNT), count(distinct CLIENT_ID) from {F} "
                        "where TRADE_DATE between '2026-01-01' and '2026-03-31' and COUNTRY in ('GB','DE','FR','US','JP') group by 1,2")
            st, eid, _ = run_exec(tok, {"connection_id": CID, "query_config": qc, "output_format": "json", "cache_strategy": "bypass"})
            _, rows, _ = page(tok, eid, 1, 1000) if st == 200 else (0, [], None)
            got = as_set([{k: r.get(k) for k in ("COUNTRY", "SIDE", "AMT", "CLIENTS")} for r in rows], ("COUNTRY", "SIDE", "AMT", "CLIENTS"))
            check("Q", "STRUCTURED (visual) config: SUM + COUNT DISTINCT, BETWEEN + IN == Snowflake",
                  st == 200 and got == {tuple(norm(x) for x in t) for t in truth} and truth,
                  {"status": st, "rows": len(rows), "truth": len(truth), "err": str(eid)[:300] if st != 200 else ""})

            S.phase = "Q sizes"
            for lim in (5_000, 50_000, 500_000, 1_000_000, 0):
                label = f"{lim:,} rows" if lim else "ALL 10,000,000 rows (limit 0)"
                sql = f"select TRADE_ID, TRADE_DATE, COUNTRY, DESK, CLIENT_ID, SIDE, AMOUNT from {F} order by TRADE_ID"
                t0 = time.time()
                body = {"connection_id": CID, "raw_sql": sql + (f" limit {lim}" if lim else ""), "output_format": "json",
                        "cache_strategy": "bypass"}
                st, eid, meta = run_exec(tok, body, timeout=2400)
                dt = round(time.time() - t0, 1)
                total = int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0) if st == 200 else 0
                ok_page, deep = None, None
                if st == 200:
                    _, first, b = page(tok, eid, 1, 100)
                    total = total or int((b or {}).get("total_rows") or 0)
                    last_page = max(1, (total + 999) // 1000)
                    _, deep, _ = page(tok, eid, last_page, 1000)
                    ok_page = bool(first) and int(first[0]["TRADE_ID"]) == 1
                expect = lim or 10_000_000
                results["timings"].append({"case": f"Q result {label}", "s": dt, "rows": total})
                if total == expect:
                    check("Q", f"{label}: every row arrived ({dt}s), page 1 and the LAST page served",
                          ok_page and deep and int(deep[-1]["TRADE_ID"]) == expect, {"total": total, "s": dt})
                else:
                    # past a threshold: must be a disclosed cap or a graceful refusal
                    disclosed = isinstance(meta, dict) and (meta.get("truncated") or meta.get("row_cap") or meta.get("limit_applied"))
                    check("Q", f"{label}: past the threshold -> graceful (refusal or DISCLOSED cap), never silent",
                          (st != 200 and (graceful(st) or (st == 500 and "limit" in str(eid).lower()))) or (st == 200 and disclosed),
                          {"status": st, "total": total, "s": dt, "meta": str(meta)[:300], "err": str(eid)[:300]})

            S.phase = "Q concurrency"
            sqls = [f"select c.REGION, p.ASSET_CLASS, f.SIDE, sum(f.AMOUNT) A, count(*) N {JOIN} "
                    f"where f.TRADE_DATE >= '2026-0{m}-01' and f.TRADE_DATE < '2026-0{m+1}-01' group by 1,2,3" for m in range(1, 9)]
            sqls = (sqls * 2)[:15]

            def one(sql):
                st, eid, meta = run_exec(tok, {"connection_id": CID, "raw_sql": sql, "output_format": "json", "cache_strategy": "bypass"})
                if st != 200:
                    return st, None
                _, rows, _ = page(tok, eid, 1, 1000)
                return st, sum(Decimal(str(r["A"])) for r in rows)
            t0 = time.time()
            with cf.ThreadPoolExecutor(15) as ex:
                outs = list(ex.map(one, sqls))
            dt = round(time.time() - t0, 1)
            truths = {s: Decimal(str(sfq(f"select sum(A) from ({s})")[0][0])) for s in set(sqls)}
            bad = [i for i, (s, (st, tot)) in enumerate(zip(sqls, outs)) if st != 200 or abs(tot - truths[s]) > Decimal("0.01")]
            check("Q", f"15 users at once, uncached: every result == Snowflake ({dt}s wall)", not bad,
                  {"bad": bad, "statuses": [o[0] for o in outs]})

            S.phase = "Q cancel"
            long_sql = f"select count(distinct ss_customer_sk, ss_item_sk) /* qs-thr-{TAG} */ from SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.STORE_SALES"
            st, r, _, _ = http(API, "POST", "/api/execute", tok, body={"connection_id": CID, "raw_sql": long_sql,
                                                                       "output_format": "json", "cache_strategy": "bypass"})
            eid = (r or {}).get("execution_id") if isinstance(r, dict) else None
            time.sleep(6)
            cs, _, _, _ = http(API, "POST", f"/api/executions/{eid}/cancel", tok)
            t0, hist = time.time(), None
            while time.time() - t0 < 60:
                h = sfq("select execution_status, error_message from table(SNOWFLAKE_SAMPLE_DATA.information_schema."
                        f"query_history_by_user(user_name=>'QS_SVC', result_limit=>300)) where query_text ilike '%qs-thr-{TAG}%' "
                        "and query_text not ilike '%query_history%'")
                if h and h[0][0] not in ("RUNNING", "QUEUED", "RESUMING_WAREHOUSE"):
                    hist = h[0]
                    break
                time.sleep(2)
            check("Q", f"cancel mid-query stops it IN Snowflake ({round(time.time()-t0,1)}s after the click)",
                  cs == 200 and hist and "cancel" in str(hist[1]).lower(), {"cancel": cs, "history": hist})

        # ════════════════════════════ R . reports ═════════════════════════
        if not ONLY or "R" in ONLY:
            S.phase = "R setup"
            base = ("select f.TRADE_ID, f.TRADE_DATE, c.REGION, f.COUNTRY, p.ASSET_CLASS, f.DESK, f.CLIENT_ID, "
                    "f.SIDE, f.QUANTITY, f.PRICE, f.AMOUNT, f.FEES " + JOIN)
            s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"thr_{TAG}", "subject": "thr", "connection_ids": [CID], "base_query": base})
            did = ds["id"]
            undo.insert(0, f"/api/datasets/{did}")
            admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
            col = {x["physical_name"].upper(): x for x in admin.call("GET", f"/api/datasets/{did}")[1]["columns"]}
            for n in ("TRADE_ID", "TRADE_DATE", "REGION", "COUNTRY", "ASSET_CLASS", "DESK", "CLIENT_ID", "SIDE"):
                admin.call("PUT", f"/api/datasets/columns/{col[n]['id']}", {"column_type": "dimension"})
            for n, agg in (("AMOUNT", "sum"), ("QUANTITY", "sum"), ("FEES", "sum"), ("PRICE", "avg")):
                admin.call("PUT", f"/api/datasets/columns/{col[n]['id']}", {"column_type": "measure", "aggregation": agg})

            def report(name, cols, filters=None, row_limit=0, sections=None):
                s, rep, _ = admin.call("POST", "/api/business-reports", {
                    "name": f"{name}-{TAG}", "dataset_id": did, "data_source_type": "dataset",
                    "column_ids": [col[c]["id"] for c in cols], "filter_specs": filters or [], "row_limit": row_limit,
                    "section_definitions": sections or []})
                assert s == 200, (s, rep)
                undo.insert(0, f"/api/business-reports/{rep['id']}")
                return rep["id"]

            def run_report(rid, params=None, fresh=True):
                st, ex, _, dt = http(API, "POST", f"/api/business-reports/{rid}/execute", tok,
                                     body={"parameter_values": params or {}, "force_refresh": fresh}, timeout=2400)
                return st, ex, dt

            def report_rows(rid, eid, total, size=2000):
                rows, n = [], 1
                while len(rows) < total and n < 2000:
                    st, b, _, _ = http(API, "GET", f"/api/business-reports/{rid}/results/{eid}?page={n}&page_size={size}", tok)
                    names = [x["name"] if isinstance(x, dict) else x for x in (b or {}).get("columns") or []] if isinstance(b, dict) else []
                    pr = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (b or {}).get("rows") or []] if isinstance(b, dict) else []
                    if not pr:
                        break
                    rows += pr
                    n += 1
                return rows

            S.phase = "R complex"
            rid = report("thr-complex", ["REGION", "ASSET_CLASS", "SIDE", "AMOUNT", "QUANTITY", "FEES", "PRICE"],
                         [{"column_id": col["TRADE_DATE"]["id"], "operator": "between", "value": ["2025-11-01", "2026-04-30"]},
                          {"column_id": col["COUNTRY"]["id"], "operator": "not_in", "value": ["ZA", "AR"]},
                          {"column_id": col["QUANTITY"]["id"], "operator": "gt", "value": 100}],
                         sections=[{"name": "Region", "break_column_id": col["REGION"]["id"],
                                    "subtotal_measure_ids": [col["AMOUNT"]["id"]], "show_count": True}])
            truth = sfq(f"select c.REGION, p.ASSET_CLASS, f.SIDE, sum(f.AMOUNT), sum(f.QUANTITY), sum(f.FEES), avg(f.PRICE) {JOIN} "
                        "where f.TRADE_DATE between '2025-11-01' and '2026-04-30' and f.COUNTRY not in ('ZA','AR') and f.QUANTITY > 100 group by 1,2,3")
            st, ex, dt = run_report(rid)
            rows = report_rows(rid, (ex or {}).get("execution_id"), int((ex or {}).get("total_rows") or 0)) if st == 200 else []
            keys = ("REGION", "ASSET_CLASS", "SIDE", "AMOUNT", "QUANTITY", "FEES", "PRICE")
            got = as_set([{k: r.get(k) for k in keys} for r in rows], keys)
            want = {tuple(norm(x) for x in t) for t in truth}
            near = st == 200 and len(got) == len(want) and all(
                any(g[:3] == w[:3] and all(abs(float(a) - float(b)) <= max(0.01, abs(float(b)) * 1e-9) for a, b in zip(g[3:], w[3:])) for g in got)
                for w in want)
            check("R", f"7 columns / 4 measures (SUM x3 + AVG) / BETWEEN + NOT IN + > filters / sections: == Snowflake ({dt}s)",
                  near, {"status": st, "rows": len(rows), "truth": len(truth), "err": str(ex)[:200] if st != 200 else ""})

            S.phase = "R high cardinality"
            rid_hc = report("thr-hc", ["CLIENT_ID", "TRADE_DATE", "AMOUNT"])
            (n_groups,), = sfq(f"select count(*) from (select CLIENT_ID, TRADE_DATE from {F} group by 1,2)")
            st, ex, dt = run_report(rid_hc)
            total = int((ex or {}).get("total_rows") or 0) if isinstance(ex, dict) else 0
            results["timings"].append({"case": "R high-cardinality client x day", "s": dt, "rows": total, "groups": n_groups})
            if st == 200 and total == n_groups:
                check("R", f"client x day = {n_groups:,} groups: every group arrived ({dt}s)", True, total)
            else:
                check("R", f"client x day = {n_groups:,} groups: past the threshold -> graceful / disclosed",
                      (graceful(st)) or (st == 200 and (ex or {}).get("truncated")),
                      {"status": st, "total": total, "s": dt, "body": str(ex)[:300]})

            S.phase = "R exports"
            rid_big = report("thr-big", ["TRADE_ID", "TRADE_DATE", "COUNTRY", "CLIENT_ID", "AMOUNT"],
                             [{"column_id": col["TRADE_DATE"]["id"], "operator": "between", "value": ["2025-10-01", "2026-03-31"]}])
            (n_big,), = sfq(f"select count(*) from {F} where TRADE_DATE between '2025-10-01' and '2026-03-31'")
            st, ex, dt = run_report(rid_big)
            check("R", f"detail report of {n_big:,} rows (half the year) runs ({dt}s)", st == 200 and int((ex or {}).get("total_rows") or 0) == n_big,
                  {"status": st, "total": (ex or {}).get("total_rows") if isinstance(ex, dict) else None, "err": str(ex)[:200]})
            st, body, hd, dt = http(API, "GET", f"/api/business-reports/{rid_big}/download-csv", tok, timeout=2400, raw=True)
            lines = body.count(b"\n") - 1 if st == 200 and isinstance(body, bytes) else 0
            results["timings"].append({"case": "R CSV export", "s": dt, "rows": lines, "mb": round(len(body or b"") / 1e6, 1)})
            check("R", f"CSV export of {n_big:,} rows: every row ({dt}s, {len(body or b'')/1e6:.0f} MB)",
                  st == 200 and lines == n_big, {"status": st, "lines": lines})
            st, body, hd, dt = http(API, "GET", f"/api/business-reports/{rid_big}/download-excel", tok, timeout=2400, raw=True)
            results["timings"].append({"case": "R Excel export", "s": dt, "status": st})
            hdl = {k.lower(): v for k, v in (hd or {}).items()}
            xl_rows = None
            if st == 200 and isinstance(body, bytes) and body[:2] == b"PK":
                import openpyxl
                wb = openpyxl.load_workbook(io.BytesIO(body), read_only=True)
                xl_rows = sum(max(0, (ws.max_row or 0) - 1) for ws in wb.worksheets if ws.title != "Export Info")
                complete = xl_rows >= n_big
                disclosed = (hdl.get("x-qs-truncated", "").lower() == "true" and "download-csv" in hdl.get("x-qs-continue-with", "")
                             and "Export Info" in wb.sheetnames)
                check("R", f"Excel of {n_big:,} rows: complete, or a DISCLOSED cap pointing at CSV ({dt}s)",
                      complete or disclosed, {"rows": xl_rows, "sheets": wb.sheetnames[:4], "truncated": hdl.get("x-qs-truncated"),
                                              "continue_with": hdl.get("x-qs-continue-with")})
            else:
                check("R", f"Excel of {n_big:,} rows: refused gracefully ({dt}s)", graceful(st), {"status": st, "body": str(body)[:300]})
            st, body, hd, dt = http(API, "GET", f"/api/business-reports/{rid_big}/download-pdf", tok, timeout=1800, raw=True)
            results["timings"].append({"case": "R PDF export (big)", "s": dt, "status": st})
            hdl = {k.lower(): v for k, v in (hd or {}).items()}
            check("R", f"PDF of a {n_big:,}-row report: a DISCLOSED capped PDF or a graceful refusal -- never a crash ({dt}s)",
                  (st == 200 and bytes(body or b"")[:4] == b"%PDF" and hdl.get("x-qs-truncated", "").lower() == "true") or graceful(st),
                  {"status": st, "rows": hdl.get("x-qs-rows"), "truncated": hdl.get("x-qs-truncated"), "body": str(body)[:200] if st != 200 else ""})

            S.phase = "R concurrency"
            rids = [report(f"thr-c{i}", ["REGION", "DESK", "AMOUNT"],
                           [{"column_id": col["TRADE_DATE"]["id"], "operator": "between",
                             "value": [f"2026-0{1 + i % 8}-01", f"2026-0{1 + i % 8}-28"]}]) for i in range(12)]
            t0 = time.time()
            with cf.ThreadPoolExecutor(12) as ex_:
                outs = list(ex_.map(lambda r: run_report(r), rids))
            dt = round(time.time() - t0, 1)
            sts = [o[0] for o in outs]
            check("R", f"12 uncached report runs at once: each answered or shed gracefully ({dt}s wall)",
                  all(s == 200 or s == 503 for s in sts) and sts.count(200) >= 1,
                  {"statuses": sts, "times": [o[2] for o in outs]})

        # ════════════════════════════ A . published API ═══════════════════
        if not ONLY or "A" in ONLY:
            S.phase = "A setup"
            base = "select f.TRADE_ID, f.TRADE_DATE, c.REGION, f.COUNTRY, f.CLIENT_ID, f.SIDE, f.AMOUNT " + JOIN
            s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"thra_{TAG}", "subject": "thr", "connection_ids": [CID], "base_query": base})
            did = ds["id"]
            undo.insert(0, f"/api/datasets/{did}")
            admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
            col = {x["physical_name"].upper(): x for x in admin.call("GET", f"/api/datasets/{did}")[1]["columns"]}
            for n in col:
                admin.call("PUT", f"/api/datasets/columns/{col[n]['id']}", {"column_type": "dimension"})
            s, rep, _ = admin.call("POST", "/api/business-reports", {"name": f"thr-all-{TAG}", "dataset_id": did,
                                                                     "data_source_type": "dataset", "column_ids": [c["id"] for c in col.values()],
                                                                     "row_limit": 0})
            undo.insert(0, f"/api/business-reports/{rep['id']}")
            admin.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
            slug = f"thr-all-{TAG}"
            s, pv, _ = admin.call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                                   "business_report_id": rep["id"], "credential_mode": "publisher",
                                                                   "allowed_filters": ["REGION", "COUNTRY", "SIDE"]})
            undo.insert(0, f"/api/published-views/{pv['id']}")
            keys = []
            for i in range(104):
                _, k, _ = admin.call("POST", "/api/api-keys", {"name": f"thr-{TAG}-{i}", "scoped_view_ids": [pv["id"]], "rate_limit": "300/minute"})
                keys.append(k["raw_key"])
                undo.append(f"/api/api-keys/{k['id']}")
            K = keys[0]

            S.phase = "A limits"
            st, b, _, dt = http(PUB, "GET", f"/api/v1/views/{slug}/data?limit=50000", key=K, timeout=1800)
            check("A", f"page at max_limit (50,000 rows) served ({dt}s; first call materialises the 10M-row view)",
                  st == 200 and len((b or {}).get("data") or []) == 50000, {"status": st, "rows": len((b or {}).get("data") or []) if isinstance(b, dict) else None, "body": str(b)[:200] if st != 200 else ""})
            st, b, _, _ = http(PUB, "GET", f"/api/v1/views/{slug}/data?limit=50001", key=K)
            check("A", "page past max_limit (50,001) -> graceful (refused or clamped, never 500)",
                  graceful(st) or (st == 200 and len((b or {}).get("data") or []) <= 50000), {"status": st, "body": str(b)[:200]})
            for q, label in (("limit=-1", "negative limit"), ("offset=abc", "non-numeric offset"),
                             ("NO_SUCH=1", "unknown filter"), ("REGION=EMEA&sort=NO_SUCH_COL", "sort by an unknown column")):
                st, b, _, _ = http(PUB, "GET", f"/api/v1/views/{slug}/data?limit=5&{q}", key=K)
                check("A", f"malformed ({label}) -> a 4xx naming it, never 500", graceful(st) and st != 503, {"status": st, "body": str(b)[:200]})
            inj = urllib.parse.quote("EMEA' OR '1'='1")
            st, b, _, _ = http(PUB, "GET", f"/api/v1/views/{slug}/data?limit=5&REGION={inj}", key=K)
            check("A", "an injection-shaped filter value is DATA (0 rows), not SQL", st == 200 and not (b or {}).get("data"),
                  {"status": st, "rows": len((b or {}).get("data") or []) if isinstance(b, dict) else None})
            (n_emea,), = sfq(f"select count(*) {JOIN} where c.REGION = 'EMEA'")
            st, b, _, _ = http(PUB, "GET", f"/api/v1/views/{slug}/data?limit=1&REGION=EMEA", key=K)
            tot = (b or {}).get("total_rows") if isinstance(b, dict) else None
            check("A", f"?REGION=EMEA total == Snowflake ({n_emea:,}) or disclosed at_least past the 1M ceiling",
                  st == 200 and (tot == n_emea or (n_emea > 1_000_000 and ((b.get("meta") or {}).get("total_mode") == "at_least" or b.get("truncated")))),
                  {"status": st, "total_rows": tot, "meta": str((b or {}).get("meta"))[:200] if isinstance(b, dict) else ""})

            S.phase = "A overload"
            # Run from INSIDE the docker network: Docker Desktop's Windows port
            # forwarding resets connections under 100 concurrent sockets
            # (WinError 10054) -- an environment limit, measured, not the server.
            here = os.path.dirname(os.path.abspath(__file__))
            out = subprocess.run(["docker", "run", "--rm", "--network", "querystudio-local-net", "-v", f"{here}:/s",
                                  "python:3.11-slim", "python", "/s/_inner_load.py", "http://published-api:8000", slug,
                                  ",".join(keys[1:101])], capture_output=True, text=True, env=DENV)
            try:
                ov = json.loads(out.stdout.strip().splitlines()[-1])
            except Exception:  # noqa: BLE001
                ov = {"codes": {}, "errors": {"harness": out.stderr[-300:]}}
            codes = {int(k): v for k, v in ov.get("codes", {}).items()}
            five = sum(v for k, v in codes.items() if k >= 500 and k != 503)
            check("A", "100 unpaced consumers for 30 s (inside the network): only 200 / 429 / 503, no 5xx, no transport error",
                  five == 0 and not ov.get("errors") and codes.get(200, 0) > 0, ov)

            S.phase = "A bulk 10M"
            (n_all, s_all), = sfq(f"select count(*), sum(f.AMOUNT) {JOIN}")

            def bulk(k):
                st, body, hd, dt = http(PUB, "GET", f"/api/v1/views/{slug}/bulk?format=csv", key=k, timeout=3600, raw=True)
                n, s = 0, Decimal(0)
                if st == 200:
                    rdr = csv.reader(io.StringIO(body.decode("utf-8-sig")))
                    i = next(rdr).index("AMOUNT")
                    for row in rdr:
                        n += 1
                        s += Decimal(row[i])
                return st, n, s, dt, len(body or b"") if isinstance(body, bytes) else 0
            st, n, s_, dt, size = bulk(keys[101])
            results["timings"].append({"case": "A bulk 10M csv", "s": dt, "rows": n, "mb": round(size / 1e6)})
            check("A", f"LOAD ALL of the 10M-row view: {n:,} rows, {size/1e6:.0f} MB in {dt}s, SUM == Snowflake",
                  st == 200 and n == n_all and s_ == s_all, {"status": st, "rows": n, "truth": n_all, "sum": str(s_), "sf": str(s_all)})
            S.phase = "A bulk x3"
            t0 = time.time()
            with cf.ThreadPoolExecutor(3) as ex_:
                outs3 = list(ex_.map(bulk, keys[101:104]))
            dt = round(time.time() - t0, 1)
            check("A", f"3 load-alls at once: each complete or refused gracefully ({dt}s wall)",
                  all((o[0] == 200 and o[1] == n_all) or graceful(o[0]) for o in outs3),
                  [(o[0], o[1], o[3]) for o in outs3])
    finally:
        S.phase = "cleanup"
        for p in undo:
            admin.call("DELETE", p)
        S.stop_ev.set()
        con.close()
        inspect = container_state()
        results["worker_deaths"] = worker_deaths()
        results["containers_after"] = inspect
        results["resources"] = S.peaks
        with open(OUT, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=1, default=str)
        print(f"\ncleanup: {len(undo)} removed; containers after: {inspect}; results -> {OUT}")
    survived = results["containers_after"] == results["containers_before"] and results["worker_deaths"] == 0
    check("ALL", "no container restarted / was OOM-killed, and no published-API WORKER died, during the run", survived,
          {"before": results["containers_before"], "after": results["containers_after"], "worker_deaths": results["worker_deaths"]})
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
