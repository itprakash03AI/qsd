"""A run whose worker process was KILLED is freed by the pod's next process
(2026-10-14): start a feed run, SIGKILL the scheduler container mid-run (what
the kernel's OOM kill does), start the SAME container (same hostname), and
expect -- within the beat interval x 1.5 + 30 s -- the execution FAILED with
the stated reason, the run back on the queue, no connection slot held, and
the run executed again to completion by itself."""
import os, subprocess, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feed_triggers_proof import Rig, psql

FEED = "PART_KEY_PROOF_KEY"
r = Rig()
fid = int(psql(f"select id from feed_configs where name='{FEED}'"))
run = int(psql(f"select id from feed_runs where feed_config_id={fid} order by id desc limit 1"))
before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
s, _ = r.call("POST", f"/api/feed-runs/{run}/rerun", {"reason": "restart-reap proof"})
print("rerun", s, flush=True)
t0 = time.time()
while True:
    ex = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} order by id desc limit 1")
    if ex and ex.split("|")[1] == "running" and time.time() - t0 > 60:
        break
    time.sleep(5)
victim = int(ex.split("|")[0])
host = subprocess.run(["docker", "exec", "qs-local-scheduler", "hostname"], capture_output=True, text=True).stdout.strip()
subprocess.run(["docker", "kill", "qs-local-scheduler"], check=True, capture_output=True)
killed = time.time()
print(f"killed the scheduler ({host}) while execution {victim} ran", flush=True)
subprocess.run(["docker", "start", "qs-local-scheduler"], check=True, capture_output=True)
host2 = subprocess.run(["docker", "exec", "qs-local-scheduler", "hostname"], capture_output=True, text=True).stdout.strip()
ok = []
def check(name, cond, detail=""):
    ok.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)
check("same pod name after the restart", host == host2, f"{host} / {host2}")
while time.time() - killed < 900:
    st = psql(f"select status, coalesce(error_message,'') from feed_executions where id={victim}")
    if st.split("|")[0] != "running":
        break
    time.sleep(10)
freed_after = round(time.time() - killed)
st, err = psql(f"select status, coalesce(error_message,'') from feed_executions where id={victim}").split("|", 1)
check("the killed attempt is FAILED, saying why", st == "failed" and "stopped" in err, f"{st}: {err[:120]}")
check("freed within 15 minutes, not the hour", freed_after < 900, f"{freed_after} s after the kill")
while time.time() - killed < 2400:
    nx = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{victim} order by id desc limit 1")
    if nx and nx.split("|")[1] in ("completed", "failed"):
        break
    time.sleep(15)
check("the run executed again by itself and completed", nx and nx.split("|")[1] == "completed", nx)
rows = psql(f"select total_rows from feed_executions where id={nx.split('|')[0]}") if nx else ""
check("with every row", rows == "400036", rows)
check("no connection slot left behind", psql(f"select count(*) from connection_claims where run_id={run}") == "0")
print(f"{sum(ok)}/{len(ok)} checks passed")
sys.exit(0 if all(ok) else 1)
