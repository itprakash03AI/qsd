"""The BACKGROUND side of the product, proven on the live Docker rig (2026-10-07).

Owner: "did you test all background processes?"  Every check below waits for
the SCHEDULER to do the work on its own -- no poll-now, no run-now -- and
judges the result by value:

  B1 the scheduler pod is the one running the jobs (54 registered, ticking);
  B2 Clockwork fires a */1 job by itself, exactly once per occurrence;
  B3 a report SUBSCRIPTION is delivered by the scheduler to the mail catcher
     (mailpit) with its attachment, and the attachment == the source;
  B4 Netcool events reach the stub (the sender's heartbeat);
  B5 a feed run created by BACKFILL is claimed by the queue worker by itself,
     produces its file, and the file downloads == the source;
  B6 the Iceberg watcher ticks over the real AWS tables with no errors.

Login rig.  Everything created is removed in a finally.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/background_jobs_proof.py
"""
from __future__ import annotations

import base64
import csv
import io
import json
import os
import subprocess
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

TAG = str(int(time.time()))[-6:]
MAILPIT = "http://127.0.0.1:8025"
NETCOOL = "http://127.0.0.1:9099"
SCHED = "http://127.0.0.1:8001"
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:400], flush=True)
    return bool(ok)


def get(url, method="GET", body=None):
    req = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        raw = r.read()
        try:
            return r.status, json.loads(raw or b"null")
        except ValueError:
            return r.status, raw


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True)
    return [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]


def wait_until(fn, timeout, every=5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v, round(time.time() - t0)
        time.sleep(every)
    return None, round(time.time() - t0)


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    truth = {r[0]: int(r[1]) for r in trino("select name, regionkey from tpch.tiny.region")}
    check("truth: 5 regions from Trino", len(truth) == 5, truth)
    undo = []
    try:
        # ── B1 the scheduler pod runs the jobs ─────────────────────────────
        s, h = get(f"{SCHED}/health")
        ids = {j["id"] for j in (h or {}).get("jobs", [])}
        need = {"__feed_queue_worker__", "__subscription_delivery__", "__feed_etl_dep_poller__",
                "iceberg_mirror_daemon", "__scheduler_heartbeat__"}
        check(f"B1 scheduler pod running with {len(ids)} jobs incl. queue worker, subscriptions, heartbeat",
              s == 200 and h.get("running") and need <= ids, {"missing": sorted(need - ids)})

        # ── B2 Clockwork fires by itself, once per occurrence ──────────────
        s, job, _ = admin.call("POST", "/api/clockwork/jobs", {
            "name": f"bg_proof_{TAG}", "description": "background proof", "enabled": True,
            "tenant": "querystudio", "owner": "rig_admin", "cron": "* * * * *", "timezone": "UTC",
            "calendar_id": None, "weekend_days": [6, 7], "misfire_grace_seconds": 300, "idempotent": True,
            "authority": "clockwork-dev-1", "connection_id": None,
            "access": {"edit": [], "enable": [], "fire": []},
            "steps": [{"name": "only", "task_type": "journal", "params": {}, "when": None}]})
        jid = (job or {}).get("id") or ((job or {}).get("job") or {}).get("id")
        if check("B2 a */1 Clockwork job is created", s in (200, 201) and jid, (s, str(job)[:200])):
            undo.append(f"/api/clockwork/jobs/{jid}")

            def fires():
                _, f, _ = admin.call("GET", f"/api/clockwork/jobs/{jid}/fires?limit=50&offset=0")
                done = [x for x in (f or {}).get("fires", []) if str(x.get("status") or x.get("resolution") or "").upper() == "SUCCESS"]
                return f if len(done) >= 2 else None
            f, waited = wait_until(fires, 200, 10)
            fl = (f or {}).get("fires", []) if f else []
            sched = [x.get("scheduled_fire") or x.get("fire_key") for x in fl]
            check(f"B2 Clockwork fired it BY ITSELF, twice, SUCCESS ({waited}s)", len(fl) >= 2, {"fires": len(fl), "sample": str(fl[:1])[:200]})
            check("B2 exactly once per occurrence (no duplicate scheduled time)", len(sched) == len(set(sched)), sched[:6])

        # ── B3 subscription delivered by the scheduler, attachment == source ─
        s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"bg_ds_{TAG}", "subject": "bg", "connection_ids": [2],
                                                     "base_query": "select name as region, regionkey from tpch.tiny.region"})
        if check("B3 dataset created", s in (200, 201), (s, str(ds)[:200])):
            undo.insert(0, f"/api/datasets/{ds['id']}")
            admin.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
            cols = admin.call("GET", f"/api/datasets/{ds['id']}")[1]["columns"]
            s, rep, _ = admin.call("POST", "/api/business-reports", {"name": f"bg-rep-{TAG}", "dataset_id": ds["id"],
                                                                     "data_source_type": "dataset", "column_ids": [c["id"] for c in cols]})
            if check("B3 report created", s == 200, (s, str(rep)[:200])):
                undo.insert(0, f"/api/business-reports/{rep['id']}")
                admin.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
                get(f"{MAILPIT}/api/v1/messages", "DELETE")
                rcpt = f"bg-proof-{TAG}@rig.local"
                s, sub, _ = admin.call("POST", "/api/subscriptions", {
                    "report_id": rep["id"], "name": f"bg-sub-{TAG}", "recipient_emails": [rcpt],
                    "frequency": "* * * * *", "output_format": "csv"})
                if check("B3 subscription every minute created", s in (200, 201), (s, str(sub)[:200])):
                    undo.insert(0, f"/api/subscriptions/{sub['id']}")

                    def mail():
                        _, m = get(f"{MAILPIT}/api/v1/search?query=to:{rcpt}")
                        return m if (m or {}).get("messages") else None
                    m, waited = wait_until(mail, 420, 15)       # the delivery tick is 5 min
                    msgs = (m or {}).get("messages") or []
                    if check(f"B3 the SCHEDULER delivered it to the mailbox ({waited}s)", msgs, {"found": len(msgs)}):
                        _, full = get(f"{MAILPIT}/api/v1/message/{msgs[0]['ID']}")
                        atts = (full or {}).get("Attachments") or []
                        rows = {}
                        if atts:
                            _, raw = get(f"{MAILPIT}/api/v1/message/{msgs[0]['ID']}/part/{atts[0]['PartID']}")
                            text = raw.decode("utf-8-sig") if isinstance(raw, bytes) else json.dumps(raw)
                            for r in csv.DictReader(io.StringIO(text)):
                                low = {k.lower().strip(): v for k, v in r.items()}
                                if low.get("region"):
                                    rows[low["region"]] = int(float(low.get("regionkey") or -1))
                        check("B3 the attachment == the source (5 regions)", rows == truth, {"attachments": len(atts), "rows": rows})
                    _, hist, _ = admin.call("GET", f"/api/subscriptions/{sub['id']}/history")
                    check("B3 the delivery is recorded in the subscription history", bool(hist), str(hist)[:200])

        # ── B4 Netcool events reach the stub ───────────────────────────────
        get(f"{NETCOOL}/reset", "POST")
        ev, waited = wait_until(lambda: (get(f"{NETCOOL}/events")[1] or {}).get("events"), 90, 5)
        check(f"B4 the Netcool sender delivered events to the stub ({waited}s)", bool(ev),
              {"n": len(ev or []), "first": str((ev or [None])[0])[:200]})

        # ── B5 backfill -> queue worker claims BY ITSELF -> download == source ─
        s, q, _ = admin.call("POST", "/api/queries", {"name": f"bg_q_{TAG}", "query_config": {
            "files": [], "raw_sql": "select name as region, regionkey from tpch.tiny.region", "connection_id": 2}})
        if check("B5 saved query", s in (200, 201), (s, str(q)[:160])):
            undo.append(f"/api/queries/{q['id']}")
            s, fd, _ = admin.call("POST", "/api/feeds", {"name": f"BG_FEED_{TAG}", "source_type": "saved_query",
                                                          "source_id": q["id"], "connection_id": 2, "output_format": "csv",
                                                          "destination_type": "local", "destination_config": {},
                                                          "execution_backend": "native"})
            if check("B5 feed created", s == 200, (s, str(fd)[:200])):
                undo.insert(0, f"/api/feeds/{fd['id']}")
                s, bf, _ = admin.call("POST", f"/api/feeds/{fd['id']}/backfill", {"start_date": "2026-10-06", "end_date": "2026-10-06"})
                check("B5 backfill created a pending run (nothing executes it but the queue worker)", s == 200, (s, str(bf)[:200]))

                def run_done():
                    _, ex, _ = admin.call("GET", f"/api/feeds/{fd['id']}/executions")
                    items = ex if isinstance(ex, list) else (ex or {}).get("items") or (ex or {}).get("executions") or []
                    return items if items and items[0].get("status") in ("completed", "failed") else None
                exs, waited = wait_until(run_done, 240, 5)
                st = (exs or [{}])[0].get("status")
                check(f"B5 the queue worker claimed and finished it BY ITSELF ({waited}s)", st == "completed", (st, str(exs)[:200]))
                exs = exs or []
                if exs:
                    req = urllib.request.Request(f"http://127.0.0.1:8000/api/feed-executions/{exs[0]['id']}/download",
                                                 headers={"Authorization": f"Bearer {admin.token}"})
                    with urllib.request.urlopen(req, timeout=60) as r:
                        s, body = r.status, r.read()
                    rows = {}
                    for r in csv.DictReader(io.StringIO(body.decode("utf-8-sig"))):
                        low = {k.lower().strip(): v for k, v in r.items()}
                        rows[low.get("region")] = int(float(low.get("regionkey")))
                    check("B5 the downloaded feed file == the source", s == 200 and rows == truth, {"status": s, "rows": rows})
                else:
                    check("B5 the run has an execution to download", False, str(ex)[:200])

        # ── B6 the Iceberg watcher over the real AWS tables ────────────────
        s, w, _ = admin.call("POST", "/api/admin/iceberg-watcher/run", {})
        summ = (w or {}).get("summary") or {}
        check("B6 the Iceberg watcher polls the real tables with no errors",
              s == 200 and (summ.get("tables_polled") or 0) > 0 and not summ.get("errors"), summ)
    finally:
        for p in undo:
            admin.call("DELETE", p)
        print(f"\ncleanup: {len(undo)} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
