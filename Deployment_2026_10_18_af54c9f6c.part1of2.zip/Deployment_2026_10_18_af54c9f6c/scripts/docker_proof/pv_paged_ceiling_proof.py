"""The paged published-view API never ends silently at its ceiling -- live on Docker (2026-09-29).

A federation view UNIONs two 3,000,000-row parquet sides (6,000,000 rows); the
paged /data route materialises at most published_views.dataset_row_cap
(1,000,000) rows.  Proves, on the running rig (login OFF, the view's API key):

  * page 1 discloses the ceiling: total_rows 1,000,000, total_mode at_least,
    pagination.truncated_at 1,000,000, pagination.continue_with = the bulk path;
  * a client that follows ONLY next_offset from just below the ceiling ends in a
    416 naming the ceiling and the bulk path -- never an empty 200, never a
    silent has_more=false stop;
  * an offset far past the ceiling is a 416 with Content-Range, not an empty 200;
  * the csv page carries X-QS-Truncated-At and X-QS-Continue-With;
  * the bulk path still returns every one of the 6,000,000 rows, total exact,
    including all 3,000,000 of the second side.
"""
from __future__ import annotations

import io
import os
import subprocess
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
import pv_slot_proof as P  # noqa: E402  (http/call/check helpers)
from proof_cleanup import Ledger  # noqa: E402

TAG = str(int(time.time()))[-6:]
N_SIDE = 3_000_000


def main():
    s, _ = P.call("GET", "/api/datasets")
    if s != 200:
        raise SystemExit(f"run on the login-OFF rig (anonymous /api/datasets answered {s})")
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    d = f"/app/data/pvceil_{TAG}"
    code = "\n".join([
        "import os, pyarrow as pa, pyarrow.parquet as pq",
        f"d='{d}'; os.makedirs(d, exist_ok=True); n={N_SIDE}",
        "pq.write_table(pa.table({'k': pa.array(range(n)), 'src': pa.array(['ALPHA']*n)}), d+'/alpha.parquet')",
        "pq.write_table(pa.table({'k': pa.array(range(n)), 'src': pa.array(['BETA']*n)}), d+'/beta.parquet')",
        "print('ok')"])
    r = subprocess.run(["docker", "exec", "-i", "qs-local-api", "python", "-c", code], capture_output=True, text=True, env=env)
    P.check("two 3,000,000-row sides written in the container", r.returncode == 0, (r.stdout or r.stderr)[-120:])
    ledger = Ledger(lambda m, p, b=None, **k: P.call(m, p, b))
    try:
        s, c = P.call("POST", "/api/connections", {"name": f"pvceil-{TAG}", "connection_type": "local",
                                                   "config": {"base_path": d}})
        ledger.add("connection", c["id"], path=f"/api/connections/{c['id']}")
        s, f = P.call("POST", "/api/federation-views", {"name": f"pvceil_{TAG}", "primary_conn_id": c["id"],
                      "primary_query": {"files": ["alpha.parquet"]}, "secondary_conn_id": c["id"],
                      "secondary_query": {"files": ["beta.parquet"]}, "combine_mode": "union"})
        ledger.add("federation view", f["id"], path=f"/api/federation-views/{f['id']}")
        s, pr = P.call("POST", f"/api/federation-views/{f['id']}/preview", {})
        P.check("the federation view itself holds 6,000,000 rows", (pr or {}).get("total_rows") == 2 * N_SIDE,
                (pr or {}).get("total_rows"))
        slug = f"pvceil-{TAG}"
        s, pv = P.call("POST", "/api/published-views", {"slug": slug, "name": slug, "source_type": "federation",
                       "federation_view_id": f["id"], "default_limit": 5, "max_limit": 50})
        ledger.add("published view", slug, path=f"/api/published-views/{pv['id']}")
        key = {"X-API-Key": pv["test_api_key"]}

        s, b, h, _ = P.http("GET", f"/api/v1/views/{slug}/data?limit=5", headers=key)
        pag = (b or {}).get("pagination") or {}
        ceiling = pag.get("truncated_at")
        P.check("page 1 discloses the ceiling (total_rows = truncated_at, at_least, continue_with = bulk)",
                s == 200 and ceiling and b.get("total_rows") == ceiling
                and (b.get("meta") or {}).get("total_mode") == "at_least"
                and str(pag.get("continue_with", "")).endswith(f"/api/v1/views/{slug}/bulk"),
                {k: pag.get(k) for k in ("truncated_at", "truncated_by", "continue_with", "total_pages_scope", "has_more")})

        # a client that follows ONLY next_offset, starting just below the ceiling
        offset, walked, end = ceiling - 12, [], None
        for _ in range(10):
            s, b, h, _ = P.http("GET", f"/api/v1/views/{slug}/data?limit=5&offset={offset}", headers=key)
            if s != 200:
                end = (s, b, h)
                break
            pag = b.get("pagination") or {}
            walked.append((offset, b.get("returned_rows"), pag.get("has_more"), pag.get("next_offset")))
            if not pag.get("has_more") or pag.get("next_offset") is None:
                end = ("silent-stop", pag, h)
                break
            offset = pag["next_offset"]
        P.check("every page walked before the ceiling was full (no empty 200)",
                walked and all(w[1] and w[1] > 0 for w in walked), walked)
        det = (end[1] or {}).get("detail") if end and isinstance(end[1], dict) else None
        P.check("following next_offset ends in a LOUD 416 at the ceiling, naming the bulk path -- not a silent stop",
                end and end[0] == 416 and isinstance(det, dict) and det.get("ceiling") == ceiling
                and str(det.get("continue_with", "")).endswith("/bulk"),
                {"walked": walked, "end": end[0] if end else None, "detail": det})

        s, b, h, _ = P.http("GET", f"/api/v1/views/{slug}/data?limit=5&offset=2999998", headers=key)
        cr = h.get("Content-Range") or h.get("content-range")
        P.check("an offset far past the ceiling is a 416 with Content-Range (not an empty 200)",
                s == 416 and cr and str(ceiling) in cr, (s, cr, str(b)[:200]))

        s, _, h, _ = P.http("GET", f"/api/v1/views/{slug}/data?limit=5&format=csv", headers=key)
        hl = {k.lower(): v for k, v in h.items()}
        P.check("the csv page carries X-QS-Truncated-At and X-QS-Continue-With",
                s == 200 and hl.get("x-qs-truncated-at") == str(ceiling)
                and str(hl.get("x-qs-continue-with", "")).endswith("/bulk"),
                {k: hl.get(k) for k in ("x-qs-truncated-at", "x-qs-continue-with", "x-querystudio-truncated")})

        req = urllib.request.Request(f"{P.API}/api/v1/views/{slug}/bulk.arrow", headers=key)
        with urllib.request.urlopen(req, timeout=900) as r:
            data, bh = r.read(), {k.lower(): v for k, v in r.headers.items()}
        import pyarrow.ipc as ipc
        t = ipc.open_stream(io.BytesIO(data)).read_all()
        beta = t.column("src").to_pylist().count("BETA")
        P.check("bulk returns every row: 6,000,000 exact, all 3,000,000 of the second side",
                t.num_rows == 2 * N_SIDE and beta == N_SIDE and bh.get("x-qs-total-mode") == "exact",
                (t.num_rows, beta, bh.get("x-qs-total-mode")))
    finally:
        _, left = ledger.cleanup(echo=lambda s: print("  " + s))
        subprocess.run(["docker", "exec", "qs-local-api", "rm", "-rf", d], env=env)
    print(f"\n{sum(P.res)}/{len(P.res)} PASSED")
    return 0 if all(P.res) and not left else 1


if __name__ == "__main__":
    sys.exit(main())
