"""The PUBLISHED API under load, paging and load-all -- REAL Snowflake, Docker
(2026-10-03, login ON).  Owner: "how the published api handles pagination
and load all ... we did not test"; "do real test via docker".

Two views over the 10M-row QS_DEMO.FIN.FACT_TRADES join:
  SUM  -- region x asset class (20 rows), filterable by REGION / ASSET_CLASS;
  BIG  -- every Q1-2026 trade (~2.47M rows, 7 columns), no aggregation.
Every number is checked against Snowflake (direct session, result cache off).

  1. correctness: each filter == Snowflake;
  2. latency: one key, 30 sequential calls (cold, then cached);
  3. concurrency: 1 / 5 / 10 / 25 clients, EACH with its own key (the way
     real consumers arrive), 20 s each: throughput, p50/p95/p99, 200s vs
     429s vs errors; published-api CPU/memory;
  4. the rate limiter: ONE key at 300/minute hammered by 10 threads for 30 s
     -- accepted ~= the limit, the rest 429 WITH Retry-After;
  5. PAGINATION: BIG paged end to end with limit=50000 via next_offset --
     row count, distinct TRADE_IDs (no duplicate / missing row across pages)
     and SUM(AMOUNT) == Snowflake; time per page;
  6. LOAD ALL: /bulk?format=csv and ?format=jsonl streamed whole -- rows,
     SUM(AMOUNT) == Snowflake; MB/s; then the async /bulk/prepare job ->
     download -- same checks.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_api_load_proof.py
"""
from __future__ import annotations

import concurrent.futures as cf
import csv
import io
import json
import os
import statistics
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from snowflake_wide_table_proof import sf  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
OUT = os.environ.get("QS_PERF_OUT", "api-load-results.json")
TAG = str(int(time.time()))[-6:]
PUB = "http://localhost:8003"
JOIN = ("from QS_DEMO.FIN.FACT_TRADES f join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY = c.COUNTRY "
        "join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID = p.PRODUCT_ID")
BASE = ("select f.TRADE_ID, f.TRADE_DATE, c.REGION, f.COUNTRY, p.ASSET_CLASS, f.DESK, f.CLIENT_ID, f.SIDE, "
        "f.QUANTITY, f.AMOUNT " + JOIN)
Q1 = "f.TRADE_DATE between '2026-01-01' and '2026-03-31'"
res, results = [], {"checks": [], "api": {}, "resources": {}}


def check(name, ok, detail=""):
    res.append(bool(ok))
    results["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)[:500]})
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:320], flush=True)
    return bool(ok)


def pub(path, key, timeout=600, raw=False):
    """One call to the published-API tier -- its own request, no shared state."""
    req = urllib.request.Request(PUB + path, headers={"X-API-Key": key})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
            st, hdr = r.status, dict(r.headers)
    except urllib.error.HTTPError as e:
        body, st, hdr = e.read(), e.code, dict(e.headers)
    except Exception as e:  # noqa: BLE001
        return -1, str(e), {}, round((time.time() - t0) * 1000, 1)
    ms = round((time.time() - t0) * 1000, 1)
    if raw:
        return st, body, hdr, ms
    try:
        return st, json.loads(body or b"{}"), hdr, ms
    except Exception:  # noqa: BLE001
        return st, body[:300], hdr, ms


class Sampler:
    def __init__(self):
        self.phase, self.peaks, self._stop = "idle", {}, threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            out = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}",
                                  "qs-local-published-api", "qs-local-api"], capture_output=True, text=True).stdout
            for line in out.splitlines():
                try:
                    n, cpu, mem = line.split("|")
                    m = mem.split("/")[0].strip()
                    mib = float(m[:-3]) * (1024 if m.endswith("GiB") else 1)
                    p = self.peaks.setdefault(f"{self.phase} | {n}", {"cpu_pct": 0.0, "mem_mib": 0.0})
                    p["cpu_pct"] = max(p["cpu_pct"], float(cpu.strip("%")))
                    p["mem_mib"] = max(p["mem_mib"], mib)
                except Exception:  # noqa: BLE001
                    pass
            self._stop.wait(2)


S = Sampler()


def pct(xs, q):
    xs = sorted(xs)
    return xs[max(0, int(q * len(xs)) - 1)] if xs else None


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    con = sf()
    cur = con.cursor()
    cur.execute("alter session set USE_CACHED_RESULT = FALSE")
    S._t.start()
    undo, keys = [], []
    try:
        # ── setup: dataset, two reports, two views, keys ─────────────────
        S.phase = "setup"
        s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"api_load_{TAG}", "subject": "perf",
                                                        "connection_ids": [CID], "base_query": BASE})
        did = ds["id"]
        undo.insert(0, ("DELETE", f"/api/datasets/{did}"))
        admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
        _, d, _ = admin.call("GET", f"/api/datasets/{did}")
        col = {x["physical_name"].upper(): x for x in d["columns"]}

        def mk_report(name, ids, filters, row_limit):
            s, rep, _ = admin.call("POST", "/api/business-reports", {
                "name": f"{name}-{TAG}", "dataset_id": did, "data_source_type": "dataset",
                "column_ids": ids, "filter_specs": filters, "row_limit": row_limit})
            assert s == 200, (s, rep)
            undo.insert(0, ("DELETE", f"/api/business-reports/{rep['id']}"))
            admin.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
            return rep["id"]

        for n in ("TRADE_ID", "TRADE_DATE", "REGION", "COUNTRY", "ASSET_CLASS", "DESK", "CLIENT_ID", "SIDE"):
            admin.call("PUT", f"/api/datasets/columns/{col[n]['id']}", {"column_type": "dimension"})
        admin.call("PUT", f"/api/datasets/columns/{col['AMOUNT']['id']}", {"column_type": "measure", "aggregation": "sum"})
        r_sum = mk_report("api-sum", [col[n]["id"] for n in ("REGION", "ASSET_CLASS", "AMOUNT")], [], 0)
        # BIG: no aggregation -- AMOUNT read as a detail column
        admin.call("PUT", f"/api/datasets/columns/{col['AMOUNT']['id']}", {"column_type": "dimension"})
        r_big = mk_report("api-big", [col[n]["id"] for n in ("TRADE_ID", "TRADE_DATE", "COUNTRY", "DESK", "CLIENT_ID", "SIDE", "AMOUNT")],
                          [{"column_id": col["TRADE_DATE"]["id"], "operator": "between", "value": ["2026-01-01", "2026-03-31"]}], 0)
        admin.call("PUT", f"/api/datasets/columns/{col['AMOUNT']['id']}", {"column_type": "measure", "aggregation": "sum"})

        def mk_view(slug, rid, filters):
            s, pv, _ = admin.call("POST", "/api/published-views", {
                "name": slug, "slug": slug, "source_type": "business_report", "business_report_id": rid,
                "credential_mode": "publisher", "allowed_filters": filters})
            assert s == 200, (s, pv)
            undo.insert(0, ("DELETE", f"/api/published-views/{pv['id']}"))
            return pv
        v_sum = mk_view(f"api-sum-{TAG}", r_sum, ["REGION", "ASSET_CLASS"])
        v_big = mk_view(f"api-big-{TAG}", r_big, [])
        for i in range(53):
            s, k, _ = admin.call("POST", "/api/api-keys", {"name": f"load-{TAG}-{i}", "scoped_view_ids": [v_sum["id"], v_big["id"]],
                                                           "rate_limit": "300/minute"})
            assert s == 200 and k.get("raw_key"), (s, k)
            keys.append(k["raw_key"])
            undo.append(("DELETE", f"/api/api-keys/{k['id']}"))
        check("setup: 2 reports, 2 views, 53 keys (300/minute each)", len(keys) == 53, (r_sum, r_big))

        # ── 1. correctness through the API ───────────────────────────────
        S.phase = "correctness"
        tsum = {}
        for r in cur.execute(f"select c.REGION, p.ASSET_CLASS, sum(f.AMOUNT) {JOIN} group by 1,2").fetchall():
            tsum[(r[0], r[1])] = round(float(r[2]), 2)
        st, b, _, ms = pub(f"/api/v1/views/{v_sum['slug']}/data?limit=100", keys[0])
        got = {(x["REGION"], x["ASSET_CLASS"]): round(float(x["AMOUNT"]), 2) for x in (b or {}).get("data") or []}
        check(f"SUM view == Snowflake (20 rows, cold {ms} ms)", st == 200 and got == tsum, (st, len(got)))
        for q, want in (("REGION=EMEA", {k: v for k, v in tsum.items() if k[0] == "EMEA"}),
                        ("ASSET_CLASS=FX", {k: v for k, v in tsum.items() if k[1] == "FX"})):
            st, b, _, ms = pub(f"/api/v1/views/{v_sum['slug']}/data?limit=100&{q}", keys[0])
            got = {(x["REGION"], x["ASSET_CLASS"]): round(float(x["AMOUNT"]), 2) for x in (b or {}).get("data") or []}
            check(f"?{q} == Snowflake ({ms} ms)", st == 200 and got == want and want, (st, len(got)))

        # ── 2. sequential latency ────────────────────────────────────────
        S.phase = "sequential"
        filters = ["", "REGION=EMEA", "REGION=APAC", "REGION=AMER", "REGION=LATAM",
                   "ASSET_CLASS=Equity", "ASSET_CLASS=Bond", "ASSET_CLASS=FX", "ASSET_CLASS=Commodity", "ASSET_CLASS=Derivative"]
        seq = []
        for i in range(30):
            st, b, _, ms = pub(f"/api/v1/views/{v_sum['slug']}/data?limit=100&{filters[i % 10]}", keys[1])
            seq.append((st, ms, bool(((b or {}).get("meta") or {}).get("cached")) if isinstance(b, dict) else False))
        first10 = [x[1] for x in seq[:10]]
        rest = [x[1] for x in seq[10:]]
        results["api"]["sequential"] = {"first_pass_p50_ms": statistics.median(first10), "first_pass_max_ms": max(first10),
                                        "repeat_p50_ms": statistics.median(rest), "repeat_p95_ms": pct(rest, .95),
                                        "cached_share_repeat": round(sum(1 for x in seq[10:] if x[2]) / 20, 2),
                                        "errors": sum(1 for x in seq if x[0] != 200)}
        check("sequential: 30 calls, all 200", all(x[0] == 200 for x in seq), results["api"]["sequential"])

        # ── 3. concurrency, one key per client ───────────────────────────
        # Each consumer is PACED at 4 requests/s on its own key -- under the
        # key's 300/minute, the way a real integration behaves -- so the curve
        # measures the SERVER as consumers are added, not the limiter.
        for conc in (1, 5, 10, 25, 50):
            S.phase = f"concurrent x{conc}"
            stop_at, out, lock = time.time() + 20, [], threading.Lock()

            def client(n):
                i, nxt = n, time.time()
                while time.time() < stop_at:
                    st, b, h, ms = pub(f"/api/v1/views/{v_sum['slug']}/data?limit=100&{filters[i % 10]}", keys[2 + n], timeout=120)
                    with lock:
                        out.append((st, ms))
                    i += 1
                    nxt += 0.25
                    time.sleep(max(0.0, nxt - time.time()))
            with cf.ThreadPoolExecutor(conc) as ex:
                list(ex.map(client, range(conc)))
            ok = [ms for st, ms in out if st == 200]
            r = {"requests": len(out), "ok": len(ok), "ok_per_s": round(len(ok) / 20, 1),
                 "p50_ms": pct(ok, .5), "p95_ms": pct(ok, .95), "p99_ms": pct(ok, .99),
                 "rate_limited_429": sum(1 for st, _ in out if st == 429),
                 "errors": sorted({st for st, _ in out if st not in (200, 429)})}
            results["api"][f"x{conc}"] = r
            print(f"   x{conc}: {r}", flush=True)
            check(f"x{conc} paced consumers: every call answered, none rate-limited, no error",
                  not r["errors"] and r["rate_limited_429"] == 0 and r["ok"] == r["requests"], r)

        # ── 4. the rate limiter on ONE hot key ───────────────────────────
        S.phase = "hot key"
        # start 1 s into a fresh minute so the 30 s run sits inside ONE fixed
        # window (a run straddling a boundary may legitimately see 2 x limit)
        time.sleep(60 - (time.time() % 60) + 1)
        stop_at, out, lock = time.time() + 30, [], threading.Lock()

        def hammer(_):
            while time.time() < stop_at:
                st, b, h, ms = pub(f"/api/v1/views/{v_sum['slug']}/data?limit=100", keys[-1], timeout=60)
                with lock:
                    out.append((st, h.get("Retry-After") or h.get("retry-after")))
        with cf.ThreadPoolExecutor(10) as ex:
            list(ex.map(hammer, range(10)))
        okn = sum(1 for st, _ in out if st == 200)
        lim = [x for x in out if x[0] == 429]
        results["api"]["hot_key_300_per_min_30s"] = {"requests": len(out), "accepted": okn, "429": len(lim),
                                                     "429_with_retry_after": sum(1 for _, ra in lim if ra)}
        # a FIXED one-minute window: up to 300 in the window, then 429 until it rolls
        check(f"hot key: {okn} accepted in 30 s at 300/minute (never more than 300), every 429 carries Retry-After",
              0 < okn <= 300 and lim and all(ra for _, ra in lim), results["api"]["hot_key_300_per_min_30s"])

        # ── 5. PAGINATION over ~2.47M rows ───────────────────────────────
        S.phase = "pagination"
        (sf_n, sf_d, sf_amt), = cur.execute(f"select count(*), count(distinct f.TRADE_ID), sum(f.AMOUNT) {JOIN} where {Q1}").fetchall()
        total, pages, off, ids_seen, amt, t0, page_ms = 0, 0, 0, set(), 0.0, time.time(), []
        stop_reason = ""
        while pages < 200:
            st, b, h, ms = pub(f"/api/v1/views/{v_big['slug']}/data?limit=50000&offset={off}", keys[0], timeout=900)
            if st != 200:
                stop_reason = f"HTTP {st}: {str(b)[:200]}"
                break
            data = b.get("data") or []
            page_ms.append(ms)
            pages += 1
            total += len(data)
            for r in data:
                ids_seen.add(r["TRADE_ID"])
                amt += float(r["AMOUNT"])
            nxt = (b.get("pagination") or {}).get("next_offset")
            if nxt is None or not data:
                stop_reason = f"last page (has_more={(b.get('pagination') or {}).get('has_more')})"
                break
            off = nxt
        t_page = round(time.time() - t0, 1)
        results["api"]["pagination"] = {"rows": total, "distinct_ids": len(ids_seen), "pages": pages, "s": t_page,
                                        "first_page_ms": page_ms[0] if page_ms else None,
                                        "later_page_p50_ms": pct(page_ms[1:], .5), "stop": stop_reason,
                                        "truth_rows": sf_n}
        # The paged API serves the first published_views.dataset_row_cap rows
        # (1,000,000) and REFUSES page past it with a 416 that names /bulk --
        # by design; the whole view is the load-all lane's job (section 6).
        _cap = 1_000_000
        if sf_n <= _cap:
            check(f"PAGINATION: all {total:,} rows in {pages} pages / {t_page}s, no duplicate, SUM == Snowflake",
                  total == sf_n and len(ids_seen) == sf_d and abs(amt - float(sf_amt)) < 1.0, results["api"]["pagination"])
        else:
            check(f"PAGINATION: the first {_cap:,} of {sf_n:,} rows in {pages} pages / {t_page}s, no duplicate, "
                  f"then a 416 naming the ceiling and /bulk",
                  total == _cap and len(ids_seen) == _cap and "past_ceiling" in stop_reason and "416" in stop_reason,
                  results["api"]["pagination"])

        # ── 6. LOAD ALL: streamed bulk + async job ───────────────────────
        for fmt in ("csv", "jsonl"):
            S.phase = f"bulk {fmt}"
            st, body, h, ms = pub(f"/api/v1/views/{v_big['slug']}/bulk?format={fmt}", keys[0], timeout=1800, raw=True)
            n, a = 0, 0.0
            if st == 200:
                if fmt == "csv":
                    rdr = csv.reader(io.StringIO(body.decode("utf-8-sig")))
                    hdr = next(rdr)
                    ai = hdr.index("AMOUNT")
                    for row in rdr:
                        n += 1
                        a += float(row[ai])
                else:
                    for line in body.splitlines():
                        if line.strip():
                            n += 1
                            a += float(json.loads(line)["AMOUNT"])
            mb = len(body) / 1e6 if isinstance(body, (bytes, bytearray)) else 0
            results["api"][f"bulk_{fmt}"] = {"rows": n, "s": round(ms / 1000, 1), "mb": round(mb, 1),
                                             "mb_per_s": round(mb / max(ms / 1000, 0.01), 1),
                                             "expected_rows_header": h.get("X-QS-Expected-Rows")}
            check(f"LOAD ALL /bulk?format={fmt}: {n:,} rows, {mb:.0f} MB in {ms/1000:.1f}s == Snowflake",
                  st == 200 and n == sf_n and abs(a - float(sf_amt)) < 1.0, (st, results["api"][f"bulk_{fmt}"], str(body)[:150] if st != 200 else ""))

        S.phase = "bulk job"
        t0 = time.time()
        req = urllib.request.Request(f"{PUB}/api/v1/views/{v_big['slug']}/bulk/prepare?format=csv", method="POST",
                                     headers={"X-API-Key": keys[0]})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                job = json.loads(r.read())
                st = r.status
        except urllib.error.HTTPError as e:
            st, job = e.code, {"error": e.read()[:300]}
        job_id = (job or {}).get("job_id") or (job or {}).get("id")
        state = {}
        while job_id and time.time() - t0 < 1800:
            _, state, _, _ = pub(f"/api/v1/views/{v_big['slug']}/bulk/jobs/{job_id}", keys[0])
            if str((state or {}).get("status")).lower() in ("ready", "completed", "done", "failed", "error"):
                break
            time.sleep(3)
        t_prep = round(time.time() - t0, 1)
        n, a, mb = 0, 0.0, 0.0
        if str((state or {}).get("status")).lower() in ("ready", "completed", "done"):
            # ready -> stream from stream_url (the /bulk lane, now served from
            # the prepared build)
            surl = (state or {}).get("stream_url") or f"/api/v1/views/{v_big['slug']}/bulk"
            st2, body, h, ms = pub(f"{surl}?format=csv", keys[0], timeout=1800, raw=True)
            if st2 == 200:
                mb = len(body) / 1e6
                rdr = csv.reader(io.StringIO(body.decode("utf-8-sig")))
                hdr = next(rdr)
                ai = hdr.index("AMOUNT")
                for row in rdr:
                    n += 1
                    a += float(row[ai])
        results["api"]["bulk_job"] = {"prepare_status": st, "job": str(job)[:200], "state": str(state)[:300],
                                      "prepare_s": t_prep, "rows": n, "mb": round(mb, 1)}
        check(f"LOAD ALL async /bulk/prepare -> download: {n:,} rows == Snowflake (prepared in {t_prep}s)",
              n == sf_n and abs(a - float(sf_amt)) < 1.0, results["api"]["bulk_job"])
    finally:
        S.phase = "cleanup"
        for m, p in undo:
            admin.call(m, p)
        S._stop.set()
        results["resources"] = S.peaks
        con.close()
        with open(OUT, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=1, default=str)
        print(f"\ncleanup: {len(undo)} removed; results -> {OUT}")
    print("\nPEAK RESOURCES (phase | container): cpu% / MiB")
    for k, v in sorted(S.peaks.items()):
        print(f"  {k:55s} {v['cpu_pct']:7.1f}% {v['mem_mib']:9.0f}")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
