"""FB-61 -- does the partition predicate decide WHICH manifests are opened?

    python scripts/docker_proof/fb61_ocean.py <output_dir>

Requires the local stack up (docker-compose.local.yml) plus MinIO, and an
Iceberg table registered on connection 1 as ``ice_trades``.  Stop
qs-local-scheduler and qs-local-executor first so the API pod is the only S3
client, and start them again afterwards -- this script does not touch them.

Record of what it found on 2026-09-22: docs/FB61_OCEAN_MEASURED_2026_09_22.html

Three filter shapes against the same Iceberg table, each measured with a
server-side tap (mc admin trace inside the MinIO container).  The daemon pods
are stopped by the caller, so the API pod is the only S3 client and everything
between the two control events belongs to the request under test.

The table's six manifests and their region partition summaries (decoded from
the current snapshot's manifest-list, snapshot 1987099907652689318):

    b279c501-...-m0   AFRICA..MIDDLE EAST   400 files   spans every region
    fe480edc-...-m0   ASIA..ASIA             46 files
    fe480edc-...-m1   ASIA..ASIA             46 files
    dfed25fb-...-m0   MIDDLE EAST only        2 files
    dfed25fb-...-m1   MIDDLE EAST only        2 files
    ce6ba453-...-m0   EUROPE only            40 files

So for region='ASIA' a reader that honours the manifest-list summaries must
open at most {fe480edc-m0, fe480edc-m1, b279c501-m0} and must NOT open the
MIDDLE EAST or EUROPE manifests.  For region='NOWHERE' it need open none.
That makes the three runs discriminating rather than merely different.
"""
import json
import subprocess
import sys
import time

OUT = sys.argv[1] if len(sys.argv) > 1 else "."
API = "http://localhost:8000/api/admin/queries/pruning-probe"
BUCKET = "qs-data"
PREFIX = "iceberg/qs/trades-507b36bec2e74cf9af4166caca82ddb4/"
CONTROL = "/qs-data/trades/_manifest.json"

# Keyed by the FULL basename: a commit writes its DATA manifest as -m0 and its
# DELETE manifest as -m1 under the same uuid, so an 8-character prefix named
# two different files.  2026-09-25: the three bodies this harness saw fetched
# on every query were the DELETE manifests (content=1, per Trino's
# "trades$manifests"), read uncached by core/iceberg_mor.py -- the prefix key
# labelled them as the data manifests and the diagnosis followed the label.
SUMMARY = {
    "b279c501-82c0-41e4-a8c4-864969a16b45-m0.avro": "DATA   AFRICA..MIDDLE EAST (400 files)",
    "dfed25fb-3fdd-440a-81c8-796dd11a60f9-m0.avro": "DATA   MIDDLE EAST only (2 files)",
    "fe480edc-8836-47ab-b67d-b9554626d739-m0.avro": "DATA   ASIA only (46 files)",
    "dfed25fb-3fdd-440a-81c8-796dd11a60f9-m1.avro": "DELETE MIDDLE EAST only (2 delete files)",
    "fe480edc-8836-47ab-b67d-b9554626d739-m1.avro": "DELETE ASIA only (46 delete files)",
    "ce6ba453-55d9-4744-95a6-44925222e3b7-m0.avro": "DELETE EUROPE only (40 delete files)",
}
CACHED_AT_START = {"b279c501-82c0-41e4-a8c4-864969a16b45-m0.avro",
                   "dfed25fb-3fdd-440a-81c8-796dd11a60f9-m0.avro",
                   "fe480edc-8836-47ab-b67d-b9554626d739-m0.avro"}


# No shell: subprocess with an argument LIST.  Going through the shell on this
# host cost a whole run -- cmd.exe does not understand a `VAR=x cmd` prefix, so
# every `MSYS_NO_PATHCONV=1 docker exec ...` failed silently and the tap saw
# nothing.  Calling docker directly also means MSYS never rewrites /tmp into a
# Windows path, so the prefix is not needed at all.
def sh(args, **kw):
    return subprocess.run(args, shell=False, capture_output=True, text=True, **kw)


def dexec(inner):
    return sh(["docker", "exec", "qs-minio", "sh", "-c", inner])


def run_case(label, filters):
    # Arm the tap and REMEMBER ITS PID.  The MinIO image has no pkill, so the
    # original disarm silently did nothing and stale trace subscribers piled up
    # until new ones captured nothing at all -- four runs reported as failures
    # by the control guard, correctly.
    dexec("rm -f /tmp/trace.jsonl /tmp/trace.pid; "
          "mc admin trace --json --verbose loc > /tmp/trace.jsonl 2>/dev/null & "
          "echo $! > /tmp/trace.pid; sleep 2")
    dexec(f"mc stat loc{CONTROL} >/dev/null 2>&1")
    time.sleep(1)
    body = {"connection_id": 1, "bucket": BUCKET, "table_prefix": PREFIX,
            "table_name": "ice_trades", "filters": filters, "force_fresh": False}
    bf = f"{OUT}/ab_body_{label}.json"
    with open(bf, "w", encoding="utf-8") as fh:
        json.dump(body, fh)
    t0 = time.time()
    r = sh(["curl", "-s", "-o", f"{OUT}/ab_probe_{label}.json", "-w", "%{http_code}",
            "-X", "POST", API, "-H", "Content-Type: application/json",
            "--data-binary", f"@{bf}"])
    elapsed = time.time() - t0
    code = (r.stdout or "").strip()
    time.sleep(1)
    dexec(f"mc stat loc{CONTROL} >/dev/null 2>&1")
    time.sleep(2)
    cap = dexec("kill $(cat /tmp/trace.pid) 2>/dev/null; sleep 1; cat /tmp/trace.jsonl")
    with open(f"{OUT}/ab_trace_{label}.jsonl", "w", encoding="utf-8") as fh:
        fh.write(cap.stdout)

    if code != "200":
        print(f"  [{label}] FAIL http={code} -- not a measurement")
        return None

    controls, events = [], []
    for line in cap.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if ev.get("type") != "S3":
            continue
        path = ev.get("path") or ""
        t = ev.get("time") or ""
        if CONTROL in path:
            controls.append(t)
            continue
        events.append((t, ev.get("api") or "?", path))
    if len(controls) < 2:
        print(f"  [{label}] FAIL: {len(controls)}/2 controls -- the tap, not the product")
        return None
    lo, hi = min(controls), max(controls)
    manifests, meta_other, data = [], [], 0
    for t, api, path in events:
        if not (lo <= t <= hi):
            continue
        base = path.rsplit("/", 1)[-1]
        if base.endswith(".avro") and "-m" in base and not base.startswith("snap-"):
            manifests.append(base)
        elif "/metadata/" in path:
            meta_other.append(f"{base}({api.replace('s3.','')})")
        elif "/data/" in path:
            data += 1
    probe = json.load(open(f"{OUT}/ab_probe_{label}.json", encoding="utf-8"))
    return {"label": label, "elapsed": elapsed, "probe": probe,
            "manifests": manifests, "meta_other": meta_other, "data": data}


CASES = [
    ("asia", [{"column": "region", "operator": "equals", "value": "ASIA"}]),
    ("nowhere", [{"column": "region", "operator": "equals", "value": "NOWHERE"}]),
    ("nofilter", []),
    ("qualified", [{"column": "ice_trades.region", "operator": "equals", "value": "ASIA"}]),
]

# FB61_ONLY=<label>: run one case, so the caller can cold-start the manifest
# cache (DELETE its rows + restart the API) before EACH case -- the cache is
# permanent, so a warm run shows 0 fetches whatever the filter (2026-09-26).
import os as _os
_only = _os.environ.get("FB61_ONLY")
if _only:
    CASES = [c for c in CASES if c[0] == _only]

results = []
for label, filters in CASES:
    res = run_case(label, filters)
    if res:
        results.append(res)

print()
print("=" * 92)
print("  FB-61 -- which manifests does the reader OPEN, per filter shape")
print("  (daemon pods stopped; 3 of 6 manifests were already cached at start)")
print("=" * 92)
for r in results:
    p = r["probe"]
    print(f"\n  {r['label']:<10} filter -> before={p.get('files_before_prune')} "
          f"after={p.get('files_after_prune')} pruned={p.get('pct_pruned')}%  "
          f"source={p.get('source')}  {r['elapsed']:.2f}s")
    print(f"     app counter manifests_attempted = {p.get('manifests_attempted')}")
    print(f"     manifest bodies FETCHED from S3  = {len(r['manifests'])}")
    for m in sorted(set(r["manifests"])):
        tag = SUMMARY.get(m, "?")
        cached = " [was cached at start]" if m in CACHED_AT_START else ""
        print(f"        {m}   {tag}{cached}")
    if r["meta_other"]:
        print(f"     other metadata objects: {', '.join(sorted(set(r['meta_other'])))}")
    print(f"     data-file requests: {r['data']}")
print()
print("=" * 92)
print("  Reading the result: for region='ASIA' the MIDDLE EAST and EUROPE manifests")
print("  cannot contain a matching row. If they were fetched, the manifest-list")
print("  partition summary did not gate the fetch. If 'nowhere' fetches the same")
print("  set as 'asia', the filter VALUE is not deciding anything at this level.")
print("=" * 92)
