"""EXERCISE the capabilities ``capability_coverage.py`` found unused.

``capability_coverage.py`` walks the shipped REGISTRIES and reports which
declared members nothing on this rig has ever instantiated.  This is the
other half: it MAKES an instance of each one that can run here and proves
it end to end against the live Docker stack.

THE ASSERTION RULE, and it is the whole point.  Never a row count.  FB-58
closed on exactly this: 35 rows is also what the "both sides ran the
primary SQL" bug produces, so the proof has to be a VALUE that could only
come from the path under test --

  * ``auto`` proves itself with the router's own reason string
    (``auto_route_small`` / ``auto_route_large_spark_k8s(rows=...)``).
    A bare ``backend=native`` is also what a per-feed pin produces.
  * a feed source proves itself with a cell from ITS source, in a file
    the feed delivered.
  * an output format proves itself by being PARSED by that format's
    reader and yielding the source's values -- a renderer that writes a
    corrupt file still writes a file of plausible size.

Run from the HOST (the API is published on :8000)::

    python scripts/docker_proof/capability_exercise.py            # all
    python scripts/docker_proof/capability_exercise.py auto formats

Every check prints PASS/FAIL with the value it compared, and the process
exits non-zero if anything failed -- a harness whose output nobody can
fail is not evidence.

WHAT IT LEAVES BEHIND: nothing (2026-09-26).  Every object a run creates --
feeds, connections, saved queries, reports, federation and published views,
the dataflow (archived: there is no DELETE for one), local tables, the
files it placed in the container, the delivered feed files, the Oracle
table the auto/large feed wrote -- is recorded in a ledger the moment the
create succeeds and removed in a ``finally``, with one report line
(``cleanup: N objects removed, M could not be (...)``); M > 0 exits
non-zero.  Leftovers from runs before this::

    python scripts/docker_proof/capability_exercise.py --sweep-leftovers            # dry run
    python scripts/docker_proof/capability_exercise.py --sweep-leftovers --execute  # delete

matched ONLY by this harness's own name templates with the run-id shape
(``\\d{6}``) in place of the tag -- see RULES below and proof_cleanup.py.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from proof_cleanup import (                                  # noqa: E402
    RUN_ID, Ledger, Rule, container_find, container_rm, oracle_table_remover,
    oracle_tables_like, sweep_flags, sweep_leftovers,
)

BASE = "http://127.0.0.1:8000"
API_CONTAINER = "qs-local-api"

TAG = str(int(time.time()))[-6:]
RESULTS: list[tuple[str, bool, str]] = []


# ── plumbing ───────────────────────────────────────────────────────────

def _auth(req, path):
    """Login-ON rig (2026-10-04): send the rig admin's session."""
    import qs_docker_client as _c
    t = None if path.startswith("/auth/") else _c._admin_token()
    if t:
        req.add_header("Authorization", f"Bearer {t}")


def call(method, path, body=None, timeout=900):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    _auth(req, path)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw)
            except Exception:
                return r.status, raw[:600].decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        payload = e.read()
        try:
            return e.code, json.loads(payload)
        except Exception:
            return e.code, payload[:600].decode("utf-8", "replace")
    except Exception as e:                                   # noqa: BLE001
        return -1, {"transport_error": f"{type(e).__name__}: {e}"}


def rows_of(body, *keys):
    if isinstance(body, list):
        return body
    for k in keys:
        v = (body or {}).get(k)
        if isinstance(v, list):
            return v
    return (body or {}).get("items") or []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f"  -- {detail}" if detail else ""), flush=True)
    return bool(ok)


def indocker(*argv, stdin=None):
    """Run a command inside the api container.  MSYS_NO_PATHCONV keeps
    Git Bash from rewriting /app/... into a Windows path."""
    import os
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    p = subprocess.run(["docker", "exec", "-i", API_CONTAINER, *argv],
                       input=stdin, capture_output=True, env=env)
    return p.returncode, p.stdout.decode("utf-8", "replace"), \
        p.stderr.decode("utf-8", "replace")


def section(title):
    print(f"\n{'=' * 74}\n{title}\n{'=' * 74}", flush=True)


# ── the ledger: what this run created, removed in ``finally`` ──────────

LEDGER = Ledger(call)


def created(kind, label, path=None, **kw):
    """Record an object the moment its create succeeded."""
    LEDGER.add(kind, str(label), path=path, **kw)


def placed(path):
    """Record a file/dir this run put inside the api container."""
    LEDGER.add("container path", path,
               remover=lambda p=path: container_rm(API_CONTAINER, p), key=path)


# ── feed helpers ───────────────────────────────────────────────────────

def make_feed(**body):
    body.setdefault("source_id", 0)
    body.setdefault("destination_type", "local")
    body.setdefault("destination_config", {"path": "/app/data/feeds"})
    s, b = call("POST", "/api/feeds", body)
    if s != 200 or not isinstance(b, dict):
        check(f"create feed {body.get('name')}", False, f"HTTP {s}: {str(b)[:200]}")
        return None
    fid = b.get("id")
    if fid:
        created("feed", body.get("name"), f"/api/feeds/{fid}")
        dc = body.get("destination_config") or {}
        if body.get("destination_type") == "oracle" and dc.get("table"):
            # The feed WRITES this table; it exists once the run completes.
            LEDGER.add("oracle table", dc["table"],
                       remover=oracle_table_remover(dc["table"],
                                                    container=API_CONTAINER),
                       key=dc["table"])
    return fid


def run_feed(feed_id, timeout=900):
    """Run a feed and return its execution row ONCE THE ROW IS SETTLED.

    A terminal STATUS is not a complete RECORD on the detached lanes.
    On spark_k8s the job's webhook flips ``status`` to ``completed``, and
    the engine -- which is awaiting that very callback -- finishes its own
    bookkeeping a second or two later: ``duration_seconds`` and
    ``files_metadata.backend_choice`` land AFTER the status does (watched
    row-by-row against postgres, 2026-09-21: status at t+18s, the
    decision at t+20s).

    A harness that reads at the status transition sees a half-written row
    and reports a missing routing decision as a product defect.  This one
    did, twice, before the row was watched.  So: wait for the status,
    then wait for the record.
    """
    s, b = call("POST", f"/api/feeds/{feed_id}/execute", {"trigger_type": "manual"})
    if s != 200:
        return {"status": f"execute_refused_{s}", "error_message": str(b)[:300]}
    dbid = b.get("execution_db_id")
    t0 = time.time()
    e = {}
    while time.time() - t0 < timeout:
        _, e = call("GET", f"/api/feed-executions/{dbid}")
        if isinstance(e, dict) and (e.get("status") or "") in (
                "completed", "failed", "error", "cancelled", "skipped"):
            break
        time.sleep(2)
    else:
        return {"status": "TIMEOUT"}
    # Bounded settle: give the lane's own write a chance to land, and
    # stop as soon as it has.  Never an unconditional sleep -- that would
    # pass on a row that is still missing the field.
    t1 = time.time()
    while time.time() - t1 < 30:
        if e.get("duration_seconds") is not None:
            break
        time.sleep(1)
        _, e = call("GET", f"/api/feed-executions/{dbid}")
    if isinstance(e, dict) and e.get("destination_path"):
        placed(str(e["destination_path"]))          # the delivered file
    return e


def cat(path, binary=False):
    rc, out, err = indocker("cat", path)
    return (rc, out, err)


# ── 1. the AUTO execution backend (the size-based router) ──────────────

NATION = "SELECT nationkey, name FROM tpch.tiny.nation"
TRADES = ("SELECT id, region, amt, qty, dt FROM iceberg.qs.trades "
          "WHERE region = 'ASIA'")
TRINO_LOCAL, TRINO_POD, ORACLE = 2, 9, 8


def ex_auto():
    section("auto -- the SIZE-BASED router.  Never had one instance.")
    # (a) below the threshold: native, and the reason says it was SIZE.
    fid = make_feed(name=f"CAP_AUTO_SMALL_{TAG}", source_type="raw_sql",
                    connection_id=TRINO_LOCAL, output_format="csv",
                    query_params={"sql": NATION}, execution_backend="auto",
                    estimated_row_count=100)
    if fid:
        e = run_feed(fid)
        bc = ((e.get("files_metadata") or {}).get("backend_choice") or {})
        check("auto/small routed native BY SIZE",
              bc.get("backend") == "native"
              and bc.get("reason") == "auto_route_small",
              f"backend_choice={json.dumps(bc)}")
        path = e.get("destination_path")
        rc, out, _ = cat(path) if path else (1, "", "")
        check("auto/small delivered the PRIMARY source's rows",
              rc == 0 and "ALGERIA" in out and "UNITED STATES" in out
              and out.splitlines()[0].strip() == "nationkey,name",
              f"{path} header={out.splitlines()[0] if out else '-'!r} "
              f"ALGERIA={'ALGERIA' in out}")

    # (b) no estimate at all: the router must SAY so, not pretend small.
    fid = make_feed(name=f"CAP_AUTO_NOEST_{TAG}", source_type="raw_sql",
                    connection_id=TRINO_LOCAL, output_format="csv",
                    query_params={"sql": NATION}, execution_backend="auto")
    if fid:
        e = run_feed(fid)
        bc = ((e.get("files_metadata") or {}).get("backend_choice") or {})
        check("auto/no-estimate is REPORTED, not silently 'small'",
              bc.get("reason") == "auto_route_no_estimate",
              f"reason={bc.get('reason')!r}")

    # (c) above the threshold: the router hands it to spark_k8s, and the
    #     feed actually runs there.  The reason carries the ROW NUMBER
    #     that drove the decision -- a value only this branch produces.
    fid = make_feed(name=f"CAP_AUTO_LARGE_{TAG}", source_type="raw_sql",
                    connection_id=TRINO_POD, output_format="parquet",
                    destination_type="oracle",
                    destination_config={"connection_id": ORACLE,
                                        "table": f"OTG.QS_CAP_AUTO_{TAG}",
                                        "mode": "append"},
                    query_params={"sql": TRADES},
                    execution_backend="auto",
                    estimated_row_count=5_000_000)
    if fid:
        e = run_feed(fid, timeout=1800)
        bc = ((e.get("files_metadata") or {}).get("backend_choice") or {})
        check("auto/large routed to spark_k8s BY SIZE",
              e.get("execution_backend") == "spark_k8s"
              and "auto_route_large_spark_k8s" in str(bc.get("reason"))
              and "rows=5000000" in str(bc.get("reason")),
              f"backend={e.get('execution_backend')} "
              f"reason={bc.get('reason')!r}")
        check("auto/large completed on the Spark lane",
              e.get("status") == "completed",
              f"status={e.get('status')} "
              f"err={str(e.get('error_message'))[:160]}")
        # CONTENT: the WHERE clause held on the far lane.  A count of
        # 301,740 would also be produced by a query that ignored it.
        #
        # UNQUOTED, and that is now part of what this proves (FB-59,
        # 2026-09-21).  This used to read `SELECT "region"` because the
        # Spark JDBC writer created lower-case QUOTED Oracle identifiers,
        # so an ordinary SELECT REGION raised ORA-00904 against a table
        # this lane had written -- a workaround written into the proof
        # instead of a defect written into the brief.  The identifier rule
        # (core/feed/oracle_identifiers.py, mirrored into the job image)
        # now creates the identifier Oracle itself would, so the statement
        # a consumer would actually write is the statement that runs here.
        s, b = call("POST", "/api/sql/execute", {
            "primary_connection_id": ORACLE,
            "primary_sql": f'SELECT REGION R, COUNT(*) C FROM '
                           f'OTG.QS_CAP_AUTO_{TAG} GROUP BY REGION',
            "row_limit": 20})
        groups = _await_sql(b) or []
        got = {str(r.get("r")): int(r.get("c")) for r in groups
               if isinstance(r, dict)}
        check("auto/large wrote ONLY the region the SQL selected",
              got == {"ASIA": 301740},
              f"SELECT REGION, COUNT(*) FROM OTG.QS_CAP_AUTO_{TAG} "
              f"GROUP BY = {got}")


def _await_sql(submit_body, timeout=300):
    if not isinstance(submit_body, dict) or not submit_body.get("execution_id"):
        return None
    eid = submit_body["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st = call("GET", f"/api/executions/{eid}/status")
        s = (st or {}).get("status")
        if s in ("completed", "success", "finished"):
            _, rb = call("GET", f"/api/executions/{eid}/results?page_size=100")
            return (rb or {}).get("rows") or []
        if s in ("failed", "error", "cancelled"):
            return None
        time.sleep(0.5)
    return None


# ── 2. feed OUTPUT FORMATS json + excel ────────────────────────────────

def ex_formats():
    section("feed output formats -- json and excel, never rendered")
    # json writes JSON LINES and names the file .jsonl -- checked here
    # because a harness that expected ".json" would have filed the
    # product's correct behaviour as a defect.
    for fmt, ext in (("json", "jsonl"), ("excel", "xlsx")):
        fid = make_feed(name=f"CAP_FMT_{fmt.upper()}_{TAG}",
                        source_type="raw_sql", connection_id=TRINO_LOCAL,
                        output_format=fmt, query_params={"sql": NATION})
        if not fid:
            continue
        e = run_feed(fid)
        path = e.get("destination_path")
        if not check(f"{fmt}: the run completed and named a file",
                     e.get("status") == "completed" and bool(path),
                     f"status={e.get('status')} path={path} "
                     f"err={str(e.get('error_message'))[:160]}"):
            continue
        check(f"{fmt}: the file carries this format's extension",
              str(path).endswith("." + ext), f"path={path}")
        # PARSE it with that format's own reader, in the container.
        if fmt == "json":
            rc, out, err = indocker("python", "-c", (
                "import json,sys\n"
                "rows=[json.loads(l) for l in open(sys.argv[1]) if l.strip()]\n"
                "print(len(rows), rows[0].get('name'), "
                "[r['name'] for r in rows if r['nationkey']==24])"
            ), path)
        else:
            rc, out, err = indocker("python", "-c", (
                "import sys\nimport openpyxl\n"
                "ws=openpyxl.load_workbook(sys.argv[1]).active\n"
                "rows=list(ws.values)\n"
                "print(len(rows)-1, rows[1][1], "
                "[r[1] for r in rows[1:] if r[0]==24])"
            ), path)
        check(f"{fmt}: the file PARSES as {fmt} and holds the source values",
              rc == 0 and "ALGERIA" in out and "UNITED STATES" in out,
              (out or err).strip()[:180])


# ── 3. feed source types ───────────────────────────────────────────────

def ex_saved_query():
    section("feed source 'saved_query' -- the most natural way to build one")
    # TRAP, cost one run: there are TWO saved-query tables.  ``source_id``
    # on a saved_query feed resolves through ``db.get_query`` -- the
    # BUILDER-mode ``saved_queries`` behind /api/queries, NOT the
    # ``sql_saved_queries`` behind /api/sql/queries.  Pointing it at the
    # latter picks up whatever row holds that id in the former.
    s, b = call("POST", "/api/queries", {
        "name": f"cap_sq_{TAG}",
        "query_config": {
            "files": ["tpch.tiny.nation"],
            "columns": ["nationkey", "name"],
            # regionkey 1 is AMERICA: 5 of the 25 nations.  The filter is
            # the assertion -- a builder that dumped the table would also
            # produce a plausible CSV full of nation names.
            "filters": [{"column": "regionkey", "operator": "eq",
                         "value": 1}],
            "connection_id": TRINO_LOCAL,
        }})
    sq_id = b.get("id") if isinstance(b, dict) else None
    if not check("a builder-mode saved query exists to build the feed on",
                 s in (200, 201) and sq_id, f"HTTP {s}: {str(b)[:200]}"):
        return
    created("saved query", f"cap_sq_{TAG}", f"/api/queries/{sq_id}")
    fid = make_feed(name=f"CAP_SRC_SAVEDQ_{TAG}", source_type="saved_query",
                    source_id=sq_id, connection_id=TRINO_LOCAL,
                    output_format="csv", query_params={})
    if not fid:
        return
    s, b = call("GET", f"/api/feeds/{fid}/preview-sql")
    check("the feed's resolved SQL IS built from the saved query",
          isinstance(b, dict) and "tpch.tiny.nation" in str(b.get("sql"))
          and "regionkey" in str(b.get("sql")),
          f"sql={str((b or {}).get('sql'))[:150]!r}")
    e = run_feed(fid)
    path = e.get("destination_path")
    rc, out, _ = cat(path) if path else (1, "", "")
    americas = ["ARGENTINA", "BRAZIL", "CANADA", "PERU", "UNITED STATES"]
    check("saved_query delivered the rows ITS OWN filter selects",
          e.get("status") == "completed" and rc == 0
          and all(n in out for n in americas)
          and "ALGERIA" not in out and "JAPAN" not in out,
          f"status={e.get('status')} path={path} "
          f"AMERICAS={[n for n in americas if n in out]} "
          f"ALGERIA_leaked={'ALGERIA' in out} "
          f"err={str(e.get('error_message'))[:200]}")


def ex_landed_file():
    section("feed source 'landed_file' -- a file already on disk as the rows")
    base = "/app/data/landed"
    body = ("code,label\n" + "\n".join(f"L{i},LANDED_ROW_{i}"
                                       for i in range(1, 8)) + "\n")
    indocker("mkdir", "-p", base)
    rc, _, err = indocker("sh", "-c", f"cat > {base}/cap_{TAG}.csv",
                          stdin=body.encode())
    if not check("the landed file was placed inside the container",
                 rc == 0, err[:160]):
        return
    placed(f"{base}/cap_{TAG}.csv")
    s, b = call("POST", "/api/connections", {
        "name": f"cap-local-{TAG}", "connection_type": "local",
        "config": {"base_path": base}})
    conn = b.get("id") if isinstance(b, dict) else None
    if not check("a 'local' connection declares the landing base_path",
                 s == 200 and conn, f"HTTP {s}: {str(b)[:200]}"):
        return
    created("connection", f"cap-local-{TAG}", f"/api/connections/{conn}")
    fid = make_feed(name=f"CAP_SRC_LANDED_{TAG}", source_type="landed_file",
                    connection_id=conn, output_format="csv",
                    query_params={"source": {
                        "path": f"cap_{TAG}.csv", "format": "csv",
                        "has_header": True, "expected_rows": 7}})
    if not fid:
        return
    e = run_feed(fid)
    path = e.get("destination_path")
    rc, out, _ = cat(path) if path else (1, "", "")
    check("landed_file delivered the LANDED file's own cells",
          e.get("status") == "completed" and rc == 0
          and "LANDED_ROW_1" in out and "LANDED_ROW_7" in out,
          f"status={e.get('status')} path={path} "
          f"err={str(e.get('error_message'))[:200]}")

    # The count reconciliation is the reason this step exists: declare a
    # count the file does not have and the run must REFUSE, not ship.
    fid2 = make_feed(name=f"CAP_SRC_LANDED_MISMATCH_{TAG}",
                     source_type="landed_file", connection_id=conn,
                     output_format="csv",
                     query_params={"source": {
                         "path": f"cap_{TAG}.csv", "format": "csv",
                         "has_header": True, "expected_rows": 999}})
    if fid2:
        e2 = run_feed(fid2)
        check("a declared count the file contradicts REFUSES the run",
              e2.get("status") in ("failed", "error")
              and "999" in str(e2.get("error_message")),
              f"status={e2.get('status')} "
              f"err={str(e2.get('error_message'))[:200]}")


def ex_api_source():
    section("feed source 'api' + the 'rest_api' CONNECTOR -- one journey")
    # The rig's own API is a live HTTP source: /api/feeds returns a JSON
    # list, which is exactly the shape the step reads.
    # On the login-ON rig the API answers 401 without a session, so the
    # connection carries the rig admin's token as bearer auth (2026-10-04).
    import qs_docker_client as _c
    _tok = _c._admin_token()
    _auth = ({"auth_type": "bearer", "token": _tok} if _tok else {"auth_type": "none"})
    s, b = call("POST", "/api/connections", {
        "name": f"cap-rest-{TAG}", "connection_type": "rest_api",
        "config": {"base_url": "http://localhost:8000", **_auth,
                   "verify_ssl": False, "timeout_seconds": 60}})
    conn = b.get("id") if isinstance(b, dict) else None
    if not check("a rest_api connection was created", s == 200 and conn,
                 f"HTTP {s}: {str(b)[:200]}"):
        return
    created("connection", f"cap-rest-{TAG}", f"/api/connections/{conn}")
    s, b = call("POST", f"/api/connections/{conn}/test")
    check("rest_api test_connection actually dialled the base_url",
          isinstance(b, dict) and b.get("success") is True
          and "HTTP 2" in str(b.get("message")),
          f"HTTP {s}: {json.dumps(b)[:180]}")
    # The connector must REFUSE SQL rather than answer empty-and-happy.
    # The submit is ACCEPTED (202-shaped) and the refusal lands on the
    # execution -- checking only the POST status reports a defect that
    # is not there, which is what the first version of this did.
    s, b = call("POST", "/api/sql/execute", {
        "primary_connection_id": conn, "primary_sql": "SELECT 1",
        "row_limit": 1})
    eid = (b or {}).get("execution_id") if isinstance(b, dict) else None
    err = ""
    if eid:
        for _ in range(60):
            _, st = call("GET", f"/api/executions/{eid}/status")
            if (st or {}).get("status") in ("failed", "error", "completed",
                                            "success", "finished"):
                err = f"{(st or {}).get('status')}: " \
                      f"{(st or {}).get('error_message')}"
                break
            time.sleep(0.5)
    check("rest_api REFUSES SQL instead of succeeding permanently EMPTY",
          "cannot execute SQL" in err and "permanently EMPTY" in err,
          err[:200] or f"HTTP {s}: {json.dumps(b)[:160]}")

    # /api/feeds answers with a BARE JSON ARRAY, so rows_path is "".
    fid = make_feed(name=f"CAP_SRC_API_{TAG}", source_type="api",
                    connection_id=conn, output_format="csv",
                    query_params={"source": {
                        "url": "/api/feeds", "rows_path": "",
                        "count_mode": "none", "page_size": 500,
                        "max_pages": 1, "rate_limit_rps": 5.0}})
    if not fid:
        return
    e = run_feed(fid)
    path = e.get("destination_path")
    rc, out, _ = cat(path) if path else (1, "", "")
    check("the api source paged an HTTP endpoint into a delivered file",
          e.get("status") == "completed" and rc == 0
          and "CAP_SRC_API_" in out and "CAP_SRC_LANDED" in out,
          f"status={e.get('status')} path={path} "
          f"err={str(e.get('error_message'))[:240]}")

    # The defect this exercise found: a rows_path that describes nothing
    # used to deliver a 0-byte file and report SUCCESS.
    fid = make_feed(name=f"CAP_SRC_API_BADPATH_{TAG}", source_type="api",
                    connection_id=conn, output_format="csv",
                    query_params={"source": {
                        "url": "/api/feeds", "rows_path": "no_such_key",
                        "count_mode": "none", "page_size": 50,
                        "max_pages": 1, "rate_limit_rps": 5.0,
                        "allow_empty_extract": True}})
    if fid:
        e = run_feed(fid)
        msg = str(e.get("error_message"))
        check("a rows_path describing nothing REFUSES, even with "
              "allow_empty_extract=true",
              e.get("status") in ("failed", "error")
              and "carries NOTHING at rows_path" in msg
              and "bare JSON array" in msg,
              f"status={e.get('status')} size={e.get('file_size_bytes')} "
              f"err={msg[:220]}")


# ── 4. the 'starburst' connector slug ──────────────────────────────────

def ex_starburst():
    section("connector type 'starburst' -- the alias nobody had ever saved")
    _, tr = call("GET", f"/api/connections/{TRINO_LOCAL}")
    cfg = dict((tr or {}).get("config") or {})
    cfg.pop("password", None)
    s, b = call("POST", "/api/connections", {
        "name": f"cap-starburst-{TAG}", "connection_type": "starburst",
        "config": cfg})
    conn = b.get("id") if isinstance(b, dict) else None
    if not check("a connection typed 'starburst' can be saved",
                 s == 200 and conn, f"HTTP {s}: {str(b)[:200]}"):
        return
    created("connection", f"cap-starburst-{TAG}", f"/api/connections/{conn}")
    s, b = call("POST", f"/api/connections/{conn}/test")
    check("the starburst slug resolves to a working connector",
          isinstance(b, dict) and b.get("success") is True,
          json.dumps(b)[:180])
    s, b = call("POST", "/api/sql/execute", {
        "primary_connection_id": conn, "primary_sql": NATION,
        "row_limit": 30})
    rows = _await_sql(b)
    names = [(r[1] if isinstance(r, (list, tuple)) else r.get("name"))
             for r in (rows or [])]
    check("a query on the starburst slug returns the ENGINE's own rows",
          "ALGERIA" in names and "UNITED STATES" in names,
          f"{len(names)} names, first={names[:2]}")


# ── 5. business-report SOURCE types ────────────────────────────────────

def ex_report_sources():
    section("business report data_source_type -- raw_sql / federation_view "
            "/ published_view")
    s, b = call("POST", "/api/sql/queries", {
        "name": f"cap_rep_sq_{TAG}", "primary_connection_id": TRINO_LOCAL,
        "primary_sql": NATION})
    sq = b.get("id") if isinstance(b, dict) else None
    if check("a SQL saved query backs the raw_sql report",
             s in (200, 201) and sq, f"HTTP {s}: {str(b)[:180]}"):
        created("sql saved query", f"cap_rep_sq_{TAG}", f"/api/sql/queries/{sq}")
        s, b = call("POST", "/api/business-reports", {
            "name": f"cap_raw_sql_{TAG}", "data_source_type": "raw_sql",
            "raw_sql_saved_query_id": sq, "raw_parameters_schema": []})
        rid = b.get("id") if isinstance(b, dict) else None
        if check("a raw_sql business report was created",
                 s in (200, 201) and rid, f"HTTP {s}: {str(b)[:200]}"):
            created("business report", f"cap_raw_sql_{TAG}",
                    f"/api/business-reports/{rid}")
            s, b = call("POST", f"/api/business-reports/{rid}/execute",
                        {"force_refresh": True})
            check("the raw_sql report ran on the raw-SQL engine",
                  s == 200 and str((b or {}).get("source_type")) == "raw_sql",
                  f"HTTP {s} source_type={(b or {}).get('source_type')!r} "
                  f"exec={(b or {}).get('execution_id')}")
            eid = (b or {}).get("execution_id")
            if eid:
                s, rb = call("GET", f"/api/business-reports/{rid}/results/"
                                    f"{eid}?page_size=50")
                cells = json.dumps((rb or {}).get("rows") or [])
                check("its result rows carry the SOURCE's own values",
                      "ALGERIA" in cells and "UNITED STATES" in cells,
                      f"{len((rb or {}).get('rows') or [])} rows")

    # 2026-10-04: a federation view reads ANY connection type (one
    # cross-source engine for every surface).  Until then a view over a SQL
    # connector was refused at save (2026-09-21: before THAT it saved and
    # died at execute).  Now: it saves, and its preview carries the rows
    # both sides really have -- 25 nations UNION 5 regions = 30.
    s, b = call("POST", "/api/federation-views", {
        "name": f"cap_fv_sql_{TAG}", "primary_conn_id": TRINO_LOCAL,
        "primary_query": {"raw_sql": "select name as NAME from tpch.tiny.nation"},
        "secondary_conn_id": TRINO_LOCAL,
        "secondary_query": {"raw_sql": "select name as NAME from tpch.tiny.region"},
        "combine_mode": "union"})
    if s in (200, 201) and isinstance(b, dict) and b.get("id"):
        created("federation view", f"cap_fv_sql_{TAG}",
                f"/api/federation-views/{b['id']}")
        s2, pv = call("POST", f"/api/federation-views/{b['id']}/preview")
        rows = ((pv or {}).get("rows") or (pv or {}).get("data") or []) if isinstance(pv, dict) else []
        names = {str((r.get("NAME") or r.get("name")) if isinstance(r, dict) else r[0]) for r in rows}
        check("a federation view over a SQL connector SAVES and previews both sides' rows",
              s2 == 200 and len(rows) == 30 and "GERMANY" in names and "EUROPE" in names,
              f"HTTP {s2}: rows={len(rows)} body={str(pv)[:200]}")
    else:
        check("a federation view over a SQL connector SAVES and previews both sides' rows",
              False, f"HTTP {s}: {str((b or {}).get('detail') if isinstance(b, dict) else b)[:220]}")

    # The real one: two parquet sides on a local connection, each
    # carrying a marker only it has.
    indocker("mkdir", "-p", "/app/data/fvcap")
    placed("/app/data/fvcap")
    rc, out, err = indocker("python", "-c", "\n".join([
        "import pyarrow as pa, pyarrow.parquet as pq",
        "pq.write_table(pa.table({'k':['A1','A2','A3'],"
        "'src':['SIDE_ALPHA']*3}), '/app/data/fvcap/alpha.parquet')",
        "pq.write_table(pa.table({'k':['B1','B2'],"
        "'src':['SIDE_BETA']*2}), '/app/data/fvcap/beta.parquet')",
        "print('written')"]))
    if not check("two parquet sides were written in the container",
                 rc == 0, (out or err)[:160]):
        return
    s, b = call("POST", "/api/connections", {
        "name": f"cap-fvlocal-{TAG}", "connection_type": "local",
        "config": {"base_path": "/app/data/fvcap"}})
    lconn = b.get("id") if isinstance(b, dict) else None
    if not check("a local connection points at them", s == 200 and lconn,
                 f"HTTP {s}: {str(b)[:180]}"):
        return
    created("connection", f"cap-fvlocal-{TAG}", f"/api/connections/{lconn}")
    s, b = call("POST", "/api/federation-views", {
        "name": f"cap_fv_{TAG}",
        "primary_conn_id": lconn,
        "primary_query": {"files": ["alpha.parquet"]},
        "secondary_conn_id": lconn,
        "secondary_query": {"files": ["beta.parquet"]},
        "combine_mode": "union"})
    fv = b.get("id") if isinstance(b, dict) else None
    if check("a federation view over supported connections exists",
             s in (200, 201) and fv, f"HTTP {s}: {str(b)[:220]}"):
        created("federation view", f"cap_fv_{TAG}", f"/api/federation-views/{fv}")
        s, b = call("POST", "/api/business-reports", {
            "name": f"cap_fv_rep_{TAG}", "data_source_type": "federation_view",
            "federation_view_id": fv})
        rid = b.get("id") if isinstance(b, dict) else None
        if check("a federation_view business report was created",
                 s in (200, 201) and rid, f"HTTP {s}: {str(b)[:200]}"):
            created("business report", f"cap_fv_rep_{TAG}",
                    f"/api/business-reports/{rid}")
            s, b = call("POST", f"/api/business-reports/{rid}/execute",
                        {"force_refresh": True})
            cells = json.dumps((b or {}).get("data")
                               or (b or {}).get("rows") or [])
            check("the report returned BOTH sides' rows in one result",
                  "SIDE_ALPHA" in cells and "SIDE_BETA" in cells
                  and "A3" in cells and "B2" in cells,
                  f"HTTP {s} -- {cells[:220]}")

    # published_view over that same federation view.
    if fv:
        s, b = call("POST", "/api/published-views", {
            "slug": f"cap-pv-{TAG}", "name": f"cap_pv_{TAG}",
            "source_type": "federation", "federation_view_id": fv,
            "default_limit": 50, "max_limit": 100})
        pv = b.get("id") if isinstance(b, dict) else None
        if check("a published view exists", s in (200, 201) and pv,
                 f"HTTP {s}: {str(b)[:220]}"):
            # DELETE on a published view DEACTIVATES it (usage history is
            # kept, by design) -- that is what "removed" means for one.
            created("published view (deactivated)", f"cap_pv_{TAG}",
                    f"/api/published-views/{pv}")
            s, b = call("POST", "/api/business-reports", {
                "name": f"cap_pv_rep_{TAG}",
                "data_source_type": "published_view",
                "published_view_id": pv})
            rid = b.get("id") if isinstance(b, dict) else None
            if check("a published_view business report was created",
                     s in (200, 201) and rid, f"HTTP {s}: {str(b)[:200]}"):
                created("business report", f"cap_pv_rep_{TAG}",
                        f"/api/business-reports/{rid}")
                s, b = call("POST", f"/api/business-reports/{rid}/execute",
                            {"force_refresh": True})
                cells = json.dumps((b or {}).get("data")
                                   or (b or {}).get("rows") or [])
                check("the published_view report returned the view's rows",
                      "SIDE_ALPHA" in cells and "SIDE_BETA" in cells,
                      f"HTTP {s} -- {cells[:220]}")


# ── 6. DataFlow stage types ────────────────────────────────────────────

def ex_dataflow():
    section("dataflow stages -- read_file, split_records, merge_records, "
            "sleep, mock")
    d = f"/app/data/dfcap_{TAG}"
    csv = ("k,v\n" + "\n".join(f"{i},DF_CELL_{i}" for i in range(1, 7)) + "\n")
    indocker("mkdir", "-p", d)
    placed(d)
    rc, _, err = indocker("sh", "-c", f"cat > {d}/in.csv", stdin=csv.encode())
    if not check("the input file was placed in the container", rc == 0,
                 err[:160]):
        return
    name = f"cap_flow_{TAG}"
    stages = [
        {"stage_alias": "ctx", "stage_type": "set_context", "seq": 0,
         "config": {"values": {"label": f"CAP_{TAG}"}}},
        {"stage_alias": "say", "stage_type": "log", "seq": 1,
         "predecessors": ["ctx"],
         "config": {"message": "flow {label} running", "level": "info"}},
        {"stage_alias": "fake", "stage_type": "mock", "seq": 2,
         "predecessors": ["say"],
         "config": {"result": "succeeded", "outputs": {"answer": 42},
                    "context_updates": {"from_mock": "MOCK_RAN"}}},
        {"stage_alias": "wait", "stage_type": "sleep", "seq": 3,
         "predecessors": ["fake"], "config": {"seconds": 1}},
        {"stage_alias": "read", "stage_type": "read_file", "seq": 4,
         "predecessors": ["wait"], "config": {"path": f"{d}/in.csv"}},
        {"stage_alias": "split", "stage_type": "split_records", "seq": 5,
         "predecessors": ["read"],
         "config": {"input_path": f"{d}/in.csv", "output_dir": f"{d}/parts",
                    "mode": "rows", "rows_per_part": 2,
                    "input_format": "csv", "output_format": "csv"}},
        {"stage_alias": "merge", "stage_type": "merge_records", "seq": 6,
         "predecessors": ["split"],
         "config": {"input_glob": f"{d}/parts/*.csv",
                    "output_path": f"{d}/merged.csv",
                    "input_format": "csv", "output_format": "csv"}},
    ]
    s, b = call("POST", "/api/dataflows", {
        "name": name, "description": "declared-but-never-instantiated stages",
        "trigger_type": "manual", "stages": stages})
    did = b.get("id") if isinstance(b, dict) else None
    if not check("a dataflow using 7 stage types was accepted",
                 s in (200, 201) and did, f"HTTP {s}: {str(b)[:280]}"):
        return
    # A dataflow has no DELETE route; archive is its removal from the
    # catalogue (the run records it produced stay, by design).
    created("dataflow (archived)", name, f"/api/dataflows/{did}/archive",
            method="POST")
    s, _ = call("POST", f"/api/dataflows/{did}/promote")
    check("the dataflow was promoted out of draft", s in (200, 201), f"HTTP {s}")
    s, b = call("POST", f"/api/dataflows/{name}/runs", {"context": {}})
    rid = b.get("id") if isinstance(b, dict) else None
    if not check("a run started", s in (200, 201) and rid,
                 f"HTTP {s}: {str(b)[:220]}"):
        return
    t0 = time.time()
    run = {}
    while time.time() - t0 < 300:
        _, run = call("GET", f"/api/dataflow-runs/{rid}")
        if (run or {}).get("status") in ("succeeded", "failed", "cancelled",
                                         "partial"):
            break
        time.sleep(2)
    st = {s["stage_alias"]: s for s in (run.get("stages") or [])}
    check("every stage succeeded",
          run.get("status") == "succeeded",
          "status=%s  %s" % (run.get("status"),
                             {k: v.get("status") for k, v in st.items()}))
    # CONTENT per stage -- a value only that stage produces.
    check("mock emitted the outputs its CONFIG declared",
          (st.get("fake") or {}).get("outputs") == {"answer": 42},
          f"outputs={(st.get('fake') or {}).get('outputs')}")
    check("mock's context_updates reached the run context",
          (run.get("context") or {}).get("from_mock") == "MOCK_RAN",
          f"context.from_mock={(run.get('context') or {}).get('from_mock')!r}")
    check("set_context reported the KEYS it set",
          (st.get("ctx") or {}).get("outputs", {}).get("set_keys") == ["label"],
          f"outputs={(st.get('ctx') or {}).get('outputs')}")
    check("log rendered the template against the run context",
          (st.get("say") or {}).get("outputs", {}).get("message")
          == f"flow CAP_{TAG} running",
          f"message={(st.get('say') or {}).get('outputs', {}).get('message')!r}")
    check("sleep actually waited",
          float((st.get("wait") or {}).get("outputs", {})
                .get("slept_seconds") or 0) >= 1.0,
          f"slept={(st.get('wait') or {}).get('outputs')}")
    read_out = (st.get("read") or {}).get("outputs") or {}
    check("read_file read THIS file's bytes",
          "DF_CELL_1" in str(read_out.get("content"))
          and read_out.get("bytes") == len(csv),
          f"bytes={read_out.get('bytes')} (file is {len(csv)})")
    split_out = (st.get("split") or {}).get("outputs") or {}
    check("split_records made 3 parts of 2 rows from 6",
          split_out.get("parts") == 3 and split_out.get("rows") == 6,
          f"outputs={json.dumps(split_out)[:200]}")
    merge_out = (st.get("merge") or {}).get("outputs") or {}
    check("merge_records consumed exactly those 3 parts",
          merge_out.get("input_count") == 3,
          f"outputs={json.dumps(merge_out)[:200]}")
    rc, out, _ = cat(f"{d}/merged.csv")
    check("the merged file holds EVERY source cell, once",
          rc == 0 and all(f"DF_CELL_{i}" in out for i in range(1, 7))
          and out.count("DF_CELL_3") == 1,
          f"{len(out.splitlines())} lines; DF_CELL_3 x{out.count('DF_CELL_3')}")


# ── main ───────────────────────────────────────────────────────────────

def ex_readers():
    section("file READ adapters -- core/file_formats, the vocabulary the "
            "first instrument measured against feed OUTPUT formats")
    # POST /api/local-tables/upload is the user-facing door into
    # ``get_format_adapter``: it converts the uploaded file to parquet
    # through the adapter for its extension.  Three DISTINCT adapter
    # classes (CsvAdapter, JsonAdapter, ExcelAdapter) -- the eight
    # registry keys are only six extensions more.
    import io
    import urllib.request as _u

    def upload(filename, payload, label):
        boundary = "----capbound" + TAG
        body = b"".join([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="name"\r\n\r\n'.encode(),
            f"cap_read_{label}_{TAG}\r\n".encode(),
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="file"; '
            f'filename="{filename}"\r\n'.encode(),
            b"Content-Type: application/octet-stream\r\n\r\n",
            payload, b"\r\n", f"--{boundary}--\r\n".encode(),
        ])
        req = _u.Request(BASE + "/api/local-tables/upload", data=body,
                         method="POST")
        req.add_header("Content-Type",
                       f"multipart/form-data; boundary={boundary}")
        _auth(req, "/api/local-tables/upload")
        try:
            with _u.urlopen(req, timeout=300) as r:
                return r.status, json.loads(r.read())
        except Exception as e:                               # noqa: BLE001
            payload = getattr(e, "read", lambda: b"")()
            return getattr(e, "code", -1), \
                payload[:400].decode("utf-8", "replace")

    rows = [("R1", "READ_CELL_ONE"), ("R2", "READ_CELL_TWO"),
            ("R3", "READ_CELL_THREE")]

    csv_bytes = ("k,v\n" + "\n".join(f"{a},{b}" for a, b in rows)
                 + "\n").encode()
    json_bytes = ("\n".join(json.dumps({"k": a, "v": b})
                            for a, b in rows) + "\n").encode()
    rc, out, err = indocker("python", "-c", "\n".join([
        "import openpyxl, io, sys",
        "wb = openpyxl.Workbook(); ws = wb.active",
        "ws.append(['k','v'])",
        "for a,b in [('R1','READ_CELL_ONE'),('R2','READ_CELL_TWO'),"
        "('R3','READ_CELL_THREE')]: ws.append([a,b])",
        "wb.save('/tmp/cap_reader.xlsx')",
        "sys.stdout.write(open('/tmp/cap_reader.xlsx','rb')"
        ".read().hex())"]))
    if rc == 0:
        placed("/tmp/cap_reader.xlsx")
    xlsx_bytes = bytes.fromhex(out.strip()) if rc == 0 else b""

    cases = [("csv", "cap_reader.csv", csv_bytes, "CsvAdapter"),
             ("json", "cap_reader.json", json_bytes, "JsonAdapter"),
             ("xlsx", "cap_reader.xlsx", xlsx_bytes, "ExcelAdapter")]
    for label, fname, payload, cls in cases:
        if not payload:
            check(f"{label}: the fixture was built", False, err[:160])
            continue
        s, b = upload(fname, payload, label)
        lt_id = b.get("id") if isinstance(b, dict) else None
        if not check(f"{label}: uploaded through {cls}",
                     s in (200, 201) and lt_id, f"HTTP {s}: {str(b)[:220]}"):
            continue
        created("local table", f"cap_read_{label}_{TAG}",
                f"/api/local-tables/{lt_id}")
        ready = {}
        t0 = time.time()
        while time.time() - t0 < 120:
            _, ready = call("GET", f"/api/local-tables/{lt_id}")
            if (ready or {}).get("status") in ("ready", "failed"):
                break
            time.sleep(1)
        if not check(f"{label}: the adapter converted it to parquet",
                     (ready or {}).get("status") == "ready",
                     f"status={(ready or {}).get('status')} "
                     f"err={str((ready or {}).get('last_error'))[:160]}"):
            continue
        s, sch = call("GET", f"/api/local-tables/{lt_id}/schema")
        names = [c.get("name") or c.get("column_name")
                 for c in ((sch or {}).get("columns") or [])]
        check(f"{label}: the source's OWN column names survived",
              [str(n).lower() for n in names] == ["k", "v"],
              f"columns={names}")
        # CONTENT: read the converted parquet back in the container.
        rc2, out2, err2 = indocker("python", "-c", "\n".join([
            "import glob, sys, pyarrow.parquet as pq",
            f"f = sorted(glob.glob('/app/data/local_tables/{lt_id}/"
            "*.parquet'))",
            "t = pq.read_table(f[0]).to_pydict() if f else {}",
            "print(sorted(str(x) for x in (t.get('v') or [])))"]))
        check(f"{label}: every source CELL is in the converted parquet",
              rc2 == 0 and "READ_CELL_ONE" in out2
              and "READ_CELL_THREE" in out2,
              (out2 or err2).strip()[:180])


SUITES = {
    "auto": ex_auto,
    "formats": ex_formats,
    "saved_query": ex_saved_query,
    "landed_file": ex_landed_file,
    "api": ex_api_source,
    "starburst": ex_starburst,
    "reports": ex_report_sources,
    "dataflow": ex_dataflow,
    "readers": ex_readers,
}


# ── leftovers from EARLIER runs: --sweep-leftovers [--execute] ──────────
#
# The matching rule, kind by kind: the exact name template this file uses,
# with the run tag replaced by the run-id shape (six digits), anchored at
# both ends.  Nothing else is a candidate.

_FEED_NAMES = ("AUTO_SMALL|AUTO_NOEST|AUTO_LARGE|FMT_JSON|FMT_EXCEL|"
               "SRC_SAVEDQ|SRC_LANDED|SRC_LANDED_MISMATCH|SRC_API|SRC_API_BADPATH")


def _container_paths():
    """(path, basename) for every candidate this harness places by tag:
    the landed csv, the dataflow work dir and the delivered feed files."""
    out = []
    for root, depth in (("/app/data/landed", 1), ("/app/data", 1),
                        ("/app/data/feeds", 2)):
        for p in container_find(API_CONTAINER, root, depth):
            out.append((p, p.rsplit("/", 1)[-1]))
    return out


RULES = [
    Rule("feed", rf"CAP_({_FEED_NAMES})_{RUN_ID}",
         list_path="/api/feeds", delete_path="/api/feeds/{id}"),
    # A view goes BEFORE the report it serves: the report delete refuses
    # (409) while an active view serves it -- the old order left orphans.
    Rule("published view (deactivated)", rf"cap_pv_{RUN_ID}",
         list_path="/api/published-views",
         delete_path="/api/published-views/{id}",
         where=lambda r: r.get("is_active") is not False),
    Rule("business report", rf"cap_(raw_sql|fv_rep|pv_rep)_{RUN_ID}",
         list_path="/api/business-reports",
         delete_path="/api/business-reports/{id}"),
    Rule("federation view", rf"cap_fv(_bad|_sql)?_{RUN_ID}",
         list_path="/api/federation-views",
         delete_path="/api/federation-views/{id}"),
    Rule("saved query", rf"cap_sq_{RUN_ID}",
         list_path="/api/queries", delete_path="/api/queries/{id}"),
    Rule("sql saved query", rf"cap_rep_sq_{RUN_ID}",
         list_path="/api/sql/queries", delete_path="/api/sql/queries/{id}"),
    Rule("dataflow (archived)", rf"cap_flow_{RUN_ID}",
         list_path="/api/dataflows", delete_path="/api/dataflows/{id}/archive",
         delete_method="POST", where=lambda r: r.get("status") != "archived"),
    Rule("local table", rf"cap_read_(csv|json|xlsx)_{RUN_ID}",
         list_path="/api/local-tables", delete_path="/api/local-tables/{id}"),
    Rule("connection", rf"cap-(local|rest|starburst|fvlocal)-{RUN_ID}",
         list_path="/api/connections", delete_path="/api/connections/{id}"),
    Rule("container path",
         rf"cap_{RUN_ID}\.csv|dfcap_{RUN_ID}|"
         rf"CAP_({_FEED_NAMES})_{RUN_ID}_\d{{8}}\.(csv|jsonl|xlsx|parquet)",
         lister=_container_paths,
         remover=lambda p: container_rm(API_CONTAINER, p)),
    Rule("oracle table", rf"QS_CAP_AUTO_{RUN_ID}",
         lister=lambda: oracle_tables_like("QS_CAP_AUTO_",
                                           container=API_CONTAINER),
         remover=lambda t: oracle_table_remover(f"OTG.{t}",
                                                container=API_CONTAINER)()),
]


def main(argv):
    sweep, execute, rest = sweep_flags(argv[1:])
    if sweep:
        return sweep_leftovers(call, RULES, execute=execute)
    wanted = [a for a in rest if a in SUITES] or list(SUITES)
    print(f"Exercising: {', '.join(wanted)}   (tag {TAG})")
    try:
        for k in wanted:
            try:
                SUITES[k]()
            except Exception as exc:                         # noqa: BLE001
                check(f"suite {k} raised", False, f"{type(exc).__name__}: {exc}")
    finally:
        # On success, on a failed check, on a crash, on Ctrl-C: what this
        # run created leaves with it, and the report says by count.
        print(f"\n{'=' * 74}")
        removed, left = LEDGER.cleanup()
        print("=" * 74)
    failed = [r for r in RESULTS if not r[1]]
    print(f"\n{'=' * 74}")
    print(f"  {len(RESULTS) - len(failed)}/{len(RESULTS)} checks PASSED")
    for name, _, detail in failed:
        print(f"  FAIL  {name}  -- {detail}")
    if left:
        print(f"  CLEANUP LEFT {len(left)} OBJECT(S) ON THE RIG (see above)")
    print("=" * 74)
    # A harness that always exits 0 is not evidence.  So is one that
    # compared nothing: an empty run is a failure, not a clean sheet.
    if not RESULTS:
        print("  NOTHING WAS CHECKED -- that is a failure, not a pass.")
        return 2
    return 1 if (failed or left) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
