"""PERFORMANCE on the REAL Snowflake account, through Docker (2026-10-03).

Owner: "large volume test both api, report, feed... create complex report with
aggregation, api and feeds... evaluate the performance, how the api behaves".

Data: QS_DEMO.FIN.FACT_TRADES (10,000,000 rows, 148 MB in Snowflake) joined to
DIM_COUNTRY (16) and DIM_PRODUCT (2,000) -- one dataset over the join.

Every answer is checked against Snowflake itself (the same aggregate run on a
direct session with USE_CACHED_RESULT=FALSE, timed: that is the source's own
cost, so QueryStudio's overhead is visible).  Measures, with docker stats
sampled every 2 s:

  A. four complex reports (group by 1-2 dims; SUM / AVG / COUNT DISTINCT;
     date-range + IN filters), each run FRESH and then REPEATED;
  B. exports (CSV / Excel) of the daily x region report;
  C. (the published API: snowflake_api_load_proof.py)
  D. feeds: the full 10M-row fact -> CSV (row count + SUM(AMOUNT) checked in
     the file), then three 1-quarter feeds at once.

Writes the measurements to perf-results.json (path: QS_PERF_OUT).

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_perf_proof.py
"""
from __future__ import annotations

import concurrent.futures as cf
import csv
import io
import json
import os
import statistics
import subprocess
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from auth_rls_proof import Session  # noqa: E402
from snowflake_wide_table_proof import sf  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
OUT = os.environ.get("QS_PERF_OUT", "perf-results.json")
TAG = str(int(time.time()))[-6:]
PUB = "http://localhost:8003"
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
CONTAINERS = ["qs-local-api", "qs-local-published-api", "qs-local-reports", "qs-local-executor"]
BASE = ("select f.TRADE_DATE, c.REGION, f.COUNTRY, c.COUNTRY_NAME, p.ASSET_CLASS, f.DESK, f.CLIENT_ID, "
        "f.SIDE, f.QUANTITY, f.PRICE, f.AMOUNT, f.FEES "
        "from QS_DEMO.FIN.FACT_TRADES f "
        "join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY = c.COUNTRY "
        "join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID = p.PRODUCT_ID")
res, results = [], {"checks": [], "reports": [], "exports": [], "api": {}, "feeds": [], "resources": {}}


def check(name, ok, detail=""):
    res.append(bool(ok))
    results["checks"].append({"name": name, "ok": bool(ok), "detail": str(detail)[:400]})
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return bool(ok)


# ── resource sampler ────────────────────────────────────────────────────────
class Sampler:
    def __init__(self):
        self.phase = "idle"
        self.peaks = {}
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.is_set():
            out = subprocess.run(["docker", "stats", "--no-stream", "--format",
                                  "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"] + CONTAINERS,
                                 capture_output=True, text=True).stdout
            for line in out.splitlines():
                try:
                    name, cpu, mem = line.split("|")
                    cpu = float(cpu.strip("%"))
                    m = mem.split("/")[0].strip()
                    mib = float(m[:-3]) * (1024 if m.endswith("GiB") else 1) if m[-3:] in ("GiB", "MiB") else 0.0
                except Exception:  # noqa: BLE001
                    continue
                key = (self.phase, name)
                p = self.peaks.setdefault(key, {"cpu_pct": 0.0, "mem_mib": 0.0})
                p["cpu_pct"] = max(p["cpu_pct"], cpu)
                p["mem_mib"] = max(p["mem_mib"], mib)
            self._stop.wait(2)

    def start(self):
        self._t.start()

    def stop(self):
        self._stop.set()
        results["resources"] = {f"{ph} | {n}": v for (ph, n), v in sorted(self.peaks.items())}


SAMPLER = Sampler()


def timed(fn):
    t0 = time.time()
    out = fn()
    return out, round(time.time() - t0, 2)


def _key(v):
    """A group key compared across the two sides: a date / timestamp as YYYY-MM-DD."""
    t = str(v)
    return t[:10] if len(t) >= 10 and t[4] == "-" and t[7] == "-" else t


def rows_of(b):
    names = [x["name"] if isinstance(x, dict) else x for x in (b or {}).get("columns") or []]
    return [r if isinstance(r, dict) else dict(zip(names, r)) for r in (b or {}).get("rows") or []]


def report_rows(admin, rid, eid, total):
    out, page = [], 1
    while len(out) < total and page < 200:
        _, rb, _ = admin.call("GET", f"/api/business-reports/{rid}/results/{eid}?page={page}&page_size=1000")
        r = rows_of(rb)
        if not r:
            break
        out.extend(r)
        page += 1
    return out


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    con = sf()
    cur = con.cursor()
    cur.execute("alter session set USE_CACHED_RESULT = FALSE")

    def truth(sql):
        t0 = time.time()
        rows = cur.execute(sql).fetchall()
        return rows, round(time.time() - t0, 2)

    SAMPLER.start()
    undo = []
    try:
        # ── setup ────────────────────────────────────────────────────────
        SAMPLER.phase = "setup"
        s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"perf_fact_{TAG}", "subject": "perf",
                                                        "connection_ids": [CID], "base_query": BASE})
        if not check("dataset over the 10M-row join", s in (200, 201), (s, str(ds)[:160])):
            return 1
        did = ds["id"]
        undo.insert(0, f"/api/datasets/{did}")
        (_, t_ad) = timed(lambda: admin.call("POST", f"/api/datasets/{did}/auto-detect", {}))
        _, d, _ = admin.call("GET", f"/api/datasets/{did}")
        col = {x["physical_name"].upper(): x for x in d["columns"]}
        for name, agg in (("AMOUNT", "sum"), ("QUANTITY", "sum"), ("FEES", "sum"), ("PRICE", "avg"),
                          ("CLIENT_ID", "count_distinct")):
            admin.call("PUT", f"/api/datasets/columns/{col[name]['id']}", {"column_type": "measure", "aggregation": agg})
        for name in ("TRADE_DATE", "REGION", "COUNTRY", "COUNTRY_NAME", "ASSET_CLASS", "DESK", "SIDE"):
            admin.call("PUT", f"/api/datasets/columns/{col[name]['id']}", {"column_type": "dimension"})
        check("auto-detect + measure aggregations set", len(col) == 12, (t_ad, sorted(col)))
        cid = lambda n: col[n]["id"]  # noqa: E731

        # ── A. complex reports ───────────────────────────────────────────
        specs = [
            ("R1 region x asset class: SUM amt, SUM qty, AVG price, COUNT DISTINCT clients",
             ["REGION", "ASSET_CLASS", "AMOUNT", "QUANTITY", "PRICE", "CLIENT_ID"], [],
             "select c.REGION, p.ASSET_CLASS, sum(f.AMOUNT), sum(f.QUANTITY), avg(f.PRICE), count(distinct f.CLIENT_ID) "
             "from QS_DEMO.FIN.FACT_TRADES f join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY=c.COUNTRY "
             "join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID=p.PRODUCT_ID group by 1,2",
             ("REGION", "ASSET_CLASS"), ("AMOUNT", "QUANTITY", "PRICE", "CLIENT_ID")),
            ("R2 country x desk, Q1-2026 BUYs only: SUM amt, SUM fees",
             ["COUNTRY", "DESK", "AMOUNT", "FEES"],
             [{"column_id": "TRADE_DATE", "operator": "between", "value": ["2026-01-01", "2026-03-31"]},
              {"column_id": "SIDE", "operator": "eq", "value": "BUY"}],
             "select f.COUNTRY, f.DESK, sum(f.AMOUNT), sum(f.FEES) from QS_DEMO.FIN.FACT_TRADES f "
             "join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY=c.COUNTRY join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID=p.PRODUCT_ID "
             "where f.TRADE_DATE between '2026-01-01' and '2026-03-31' and f.SIDE='BUY' group by 1,2",
             ("COUNTRY", "DESK"), ("AMOUNT", "FEES")),
            ("R3 daily x region: SUM amt, SUM fees (1,460 rows)",
             ["TRADE_DATE", "REGION", "AMOUNT", "FEES"], [],
             "select f.TRADE_DATE, c.REGION, sum(f.AMOUNT), sum(f.FEES) from QS_DEMO.FIN.FACT_TRADES f "
             "join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY=c.COUNTRY join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID=p.PRODUCT_ID group by 1,2",
             ("TRADE_DATE", "REGION"), ("AMOUNT", "FEES")),
            ("R4 client-level, EMEA equities in Mar-2026: SUM amt per client x country",
             ["CLIENT_ID_DIM", "COUNTRY", "AMOUNT"],
             [{"column_id": "REGION", "operator": "in", "value": ["EMEA"]},
              {"column_id": "ASSET_CLASS", "operator": "eq", "value": "Equity"},
              {"column_id": "TRADE_DATE", "operator": "between", "value": ["2026-03-01", "2026-03-31"]}],
             "select f.CLIENT_ID, f.COUNTRY, sum(f.AMOUNT) from QS_DEMO.FIN.FACT_TRADES f "
             "join QS_DEMO.FIN.DIM_COUNTRY c on f.COUNTRY=c.COUNTRY join QS_DEMO.FIN.DIM_PRODUCT p on f.PRODUCT_ID=p.PRODUCT_ID "
             "where c.REGION in ('EMEA') and p.ASSET_CLASS='Equity' and f.TRADE_DATE between '2026-03-01' and '2026-03-31' group by 1,2",
             ("CLIENT_ID", "COUNTRY"), ("AMOUNT",)),
        ]
        # R4 needs CLIENT_ID as a DIMENSION: a second column on the same expression is not
        # possible, so R4 runs on a twin dataset where CLIENT_ID stays a dimension.
        s, ds2, _ = admin.call("POST", "/api/datasets", {"name": f"perf_fact_cli_{TAG}", "subject": "perf",
                                                         "connection_ids": [CID], "base_query": BASE})
        did2 = ds2["id"]
        undo.insert(0, f"/api/datasets/{did2}")
        admin.call("POST", f"/api/datasets/{did2}/auto-detect", {})
        _, d2, _ = admin.call("GET", f"/api/datasets/{did2}")
        col2 = {x["physical_name"].upper(): x for x in d2["columns"]}
        admin.call("PUT", f"/api/datasets/columns/{col2['AMOUNT']['id']}", {"column_type": "measure", "aggregation": "sum"})
        for name in ("CLIENT_ID", "COUNTRY", "REGION", "ASSET_CLASS", "TRADE_DATE"):
            admin.call("PUT", f"/api/datasets/columns/{col2[name]['id']}", {"column_type": "dimension"})

        report_ids = {}
        for label, cols, filters, sql, keys, measures in specs:
            SAMPLER.phase = f"report {label[:2]}"
            on2 = label.startswith("R4")
            cmap = col2 if on2 else col
            ids = [cmap["CLIENT_ID" if n == "CLIENT_ID_DIM" else n]["id"] for n in cols]
            fs = [dict(f, column_id=cmap[f["column_id"]]["id"]) for f in filters]
            s, rep, _ = admin.call("POST", "/api/business-reports", {
                "name": f"perf-{label[:2].lower()}-{TAG}", "dataset_id": did2 if on2 else did,
                "data_source_type": "dataset", "column_ids": ids, "filter_specs": fs, "row_limit": 0})
            if not check(f"{label}: created", s == 200, (s, str(rep)[:200])):
                continue
            rid = rep["id"]
            report_ids[label[:2]] = rid
            undo.insert(0, f"/api/business-reports/{rid}")
            truth_rows, t_sf = truth(sql)
            want = {tuple(_key(x) for x in r[:len(keys)]): [float(v) for v in r[len(keys):]] for r in truth_rows}
            runs = []
            for attempt, fresh in (("fresh", True), ("repeat", False)):
                (ex, t_run) = timed(lambda: admin.call("POST", f"/api/business-reports/{rid}/execute",
                                                       {"parameter_values": {}, "force_refresh": fresh})[1])
                total = int((ex or {}).get("total_rows") or 0)
                (rows, t_fetch) = timed(lambda: report_rows(admin, rid, (ex or {}).get("execution_id"), total))
                runs.append({"attempt": attempt, "run_s": t_run, "fetch_all_s": t_fetch, "rows": total})
            got = {}
            for r in rows:
                kk = tuple(_key(r.get(k)) for k in keys)
                got[kk] = [float(r.get(m) or 0) for m in measures]
            bad = [k for k in want if k not in got or any(abs(a - b) > max(0.01, abs(b) * 1e-9)
                                                       for a, b in zip(got[k], want[k]))]
            results["reports"].append({"report": label, "rows": len(want), "snowflake_s": t_sf, "runs": runs,
                                       "mismatches": len(bad)})
            check(f"{label}: {len(want)} rows == Snowflake (SF {t_sf}s; QS fresh {runs[0]['run_s']}s, "
                  f"repeat {runs[1]['run_s']}s)", len(got) == len(want) and not bad and want,
                  {"bad": bad[:3], "sample": list(want.items())[:1]})

        # ── B. exports ───────────────────────────────────────────────────
        SAMPLER.phase = "exports"
        r3 = report_ids.get("R3")
        if r3:
            for kind in ("csv", "excel"):
                (out, t) = timed(lambda: admin.call("GET", f"/api/business-reports/{r3}/download-{kind}", raw=True))
                s, body, _ = out
                size = len(body) if isinstance(body, (bytes, bytearray)) else 0
                lines = None
                if kind == "csv" and size:
                    lines = len(list(csv.reader(io.StringIO(bytes(body).decode("utf-8-sig"))))) - 1
                results["exports"].append({"report": "R3", "kind": kind, "s": t, "bytes": size, "lines": lines})
                check(f"R3 export {kind}: {size:,} bytes in {t}s", s == 200 and size > 0
                      and (lines is None or lines == 1460), (s, lines))

        # C. the published API under load / paging / load-all: snowflake_api_load_proof.py

        # ── D. feeds ─────────────────────────────────────────────────────
        def feed(name, sql):
            s, fb, _ = admin.call("POST", "/api/feeds", {
                "name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": CID,
                "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
                "query_params": {"sql": sql}})
            if s != 200:
                return None, (s, fb)
            undo.insert(0, f"/api/feeds/{fb['id']}")
            return fb["id"], None

        def run_feed(fid):
            t0 = time.time()
            s, ex, _ = admin.call("POST", f"/api/feeds/{fid}/execute", {"trigger_type": "manual"})
            dbid = (ex or {}).get("execution_db_id")
            e = {}
            while dbid and time.time() - t0 < 3600:
                _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                if (e or {}).get("status") in ("completed", "failed", "error", "cancelled", "skipped"):
                    break
                time.sleep(3)
            return e, round(time.time() - t0, 1)

        def file_stats(path):
            # EXACT decimal sum: 10M binary floats drift ~1 unit in 1e13, a
            # checker error that would read as a data defect.
            py = """import csv, sys
from decimal import Decimal
r = csv.reader(open(sys.argv[1], newline=''))
h = next(r)
i = h.index('AMOUNT')
n = 0
s = Decimal(0)
for row in r:
    n += 1
    s += Decimal(row[i])
print(n, s)"""
            out = subprocess.run(["docker", "exec", "qs-local-api", "python3", "-c", py, path],
                                 capture_output=True, text=True, env=DENV).stdout.split()
            size = subprocess.run(["docker", "exec", "qs-local-api", "stat", "-c", "%s", path],
                                  capture_output=True, text=True, env=DENV).stdout.strip()
            subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", path], env=DENV)
            from decimal import Decimal
            return (int(out[0]), Decimal(out[1]), int(size or 0)) if len(out) == 2 else (None, None, 0)

        SAMPLER.phase = "feed 10M"
        fsql = ("select TRADE_ID, TRADE_DATE, COUNTRY, PRODUCT_ID, DESK, CLIENT_ID, SIDE, QUANTITY, PRICE, AMOUNT, FEES "
                "from QS_DEMO.FIN.FACT_TRADES")
        fid, err = feed(f"PERF_FULL_{TAG}", fsql)
        if check("full-extract feed created", fid, err):
            e, t = run_feed(fid)
            n, s_amt, size = file_stats(e.get("destination_path")) if e.get("destination_path") else (None, None, 0)
            (sf_row,), _ = truth("select count(*), sum(AMOUNT) from QS_DEMO.FIN.FACT_TRADES")
            results["feeds"].append({"feed": "full 10M x 11", "s": t, "status": e.get("status"), "rows": n,
                                     "bytes": size, "rows_per_s": round((n or 0) / max(t, 0.01))})
            check(f"feed 10M rows -> CSV: {t}s, {size/1e6:.0f} MB, every row + SUM(AMOUNT) == Snowflake",
                  e.get("status") == "completed" and n == sf_row[0] and s_amt == sf_row[1],
                  {"status": e.get("status"), "rows": n, "sum": s_amt, "truth": sf_row,
                   "err": str(e.get("error_message"))[:200]})

        SAMPLER.phase = "feeds x3 concurrent"
        quarters = [("2025-10-01", "2025-12-31"), ("2026-01-01", "2026-03-31"), ("2026-04-01", "2026-06-30")]
        fids = []
        for i, (lo, hi) in enumerate(quarters):
            f_, _ = feed(f"PERF_Q{i+1}_{TAG}", fsql + f" where TRADE_DATE between '{lo}' and '{hi}'")
            fids.append((f_, lo, hi))
        t0 = time.time()
        with cf.ThreadPoolExecutor(3) as ex:
            outs = list(ex.map(lambda x: run_feed(x[0]), fids))
        t_all = round(time.time() - t0, 1)
        ok_all = True
        for (f_, lo, hi), (e, t) in zip(fids, outs):
            n, s_amt, size = file_stats(e.get("destination_path")) if e.get("destination_path") else (None, None, 0)
            (sf_row,), _ = truth(f"select count(*), sum(AMOUNT) from QS_DEMO.FIN.FACT_TRADES where TRADE_DATE between '{lo}' and '{hi}'")
            good = e.get("status") == "completed" and n == sf_row[0] and s_amt == sf_row[1]
            ok_all &= good
            results["feeds"].append({"feed": f"quarter {lo}..{hi} (concurrent)", "s": t, "status": e.get("status"),
                                     "rows": n, "bytes": size, "rows_per_s": round((n or 0) / max(t, 0.01))})
        check(f"three quarterly feeds at once: {t_all}s wall, each file == Snowflake", ok_all,
              [x for x in results["feeds"][-3:]])
    finally:
        SAMPLER.phase = "cleanup"
        for p in undo:
            admin.call("DELETE", p)
        SAMPLER.stop()
        con.close()
        with open(OUT, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=1, default=str)
        print(f"\ncleanup: {len(undo)} removed; results -> {OUT}")
    print("\nPEAK RESOURCES (phase | container): cpu% / MiB")
    for k, v in results["resources"].items():
        print(f"  {k:60s} {v['cpu_pct']:7.1f}% {v['mem_mib']:9.0f}")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
