"""What read_plan_pod_proof reads, made on THIS rig (2026-10-16).

read_plan_pod_proof ran on the dev rig against objects earlier sessions had
made by hand or as leftovers of other proofs; on a rig built from scratch its
five cases failed with "not a table registered on connection ...".  This
step makes each one, idempotently, through the same routes and SQL those
proofs used:

  join tables   the owner's fact_tetb / fact_tetb_ext (join_query_proof setup +
                truth): cloud as Iceberg on AWS (iceberg_aws.jq_<tag>), on-prem as
                Hive on the Starburst-shaped cluster (hive.jq_<tag>) -- REUSED
                when the state file's schemas still exist on both clusters
  registered    jq_tetb_<tag> / jq_ext_<tag> on aws-real (Iceberg, read directly
                from S3); hv_fact_tetb_<tag> / hv_fact_tetb_ext_<tag> on minio-rig
                (the Hive files); both connections declare sql_dialect=trino
  mor           a v2 Iceberg table on AWS with 2,000 position + 150 equality
                deletes (iceberg_deletes_table.py, run in the Spark job image in
                local mode) -- an existing iceberg_mor/mor_<tag>/ is reused
                unless --rebuild-mor; registered on aws-real; its name is kept in
                the state file for the proof

Needs: rig.ps1 up -Spark -Starburst, AWS keys (rig/rig.env).

    python scripts/docker_proof/read_plan_pod_setup.py [--rebuild-mor]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import join_query_proof as jq                                    # noqa: E402
from feed_triggers_proof import Rig                              # noqa: E402
from tetb_real_e2e_proof import AWS_BUCKET, cloud_cli, sb_cli    # noqa: E402

SPARK_IMAGE = os.environ.get("QS_SPARK_IMAGE", "querystudio/spark-etl:local")
MOR_PREFIX = "iceberg_mor"


def _conns(r):
    _, conns = r.call("GET", "/api/connections")
    return conns if isinstance(conns, list) else conns.get("items", [])


def _registered(r, cid, name) -> bool:
    return r.call("GET", f"/api/connections/{cid}/tables/{name}/schema")[0] == 200


def _register(r, cid, name, prefix, fmt, what):
    if _registered(r, cid, name):
        print(f"   {name}: registered already")
        return
    s, b = r.call("POST", f"/api/connections/{cid}/tables",
                  {"name": name, "s3_prefix": prefix, "format": fmt, "description": what})
    if s not in (200, 201):
        raise SystemExit(f"register {name}: HTTP {s} {str(b)[:300]}")
    print(f"   {name}: registered ({fmt}, {prefix})")


def _declare_trino_dialect(r, c):
    s, full = r.call("GET", f"/api/connections/{c['id']}")
    cfg = dict((full or {}).get("config") or {})
    if cfg.get("sql_dialect") == "trino":
        return
    cfg["sql_dialect"] = "trino"
    s, b = r.call("PUT", f"/api/connections/{c['id']}",
                  {"name": full["name"], "connection_type": full["connection_type"], "config": cfg})
    if s != 200:
        raise SystemExit(f"declare sql_dialect on {full['name']}: HTTP {s} {str(b)[:300]}")


def _schema_exists(cli, catalog_schema: str) -> bool:
    cat, sch = catalog_schema.split(".", 1)
    try:
        return sch in cli(f"SHOW SCHEMAS FROM {cat}").replace('"', "").split()
    except RuntimeError:
        return False


def join_tables() -> dict:
    st = json.load(open(jq.STATE)) if os.path.exists(jq.STATE) else None
    if st and "truth" in st and _schema_exists(cloud_cli, st["cloud"]["schema"]) \
            and _schema_exists(sb_cli, st["prem"]["schema"]):
        print(f"join tables: reusing tag {st['tag']} ({st['cloud']['schema']}, {st['prem']['schema']})")
        return st
    print("join tables: building both sides (join_query_proof setup + truth)")
    jq.setup(20_000)
    jq.truth()
    return json.load(open(jq.STATE))


def register_join(r, st):
    conns = _conns(r)
    s3c = next(c for c in conns if c["name"] == "aws-real")
    minio = next(c for c in conns if c["name"] == "minio-rig")
    _declare_trino_dialect(r, s3c)
    _declare_trino_dialect(r, minio)
    tag = st["tag"]
    for name in ("fact_tetb", "fact_tetb_ext"):
        loc = cloud_cli(f'SELECT file_path FROM {st["cloud"]["schema"]}."{name}$files" LIMIT 1').strip().strip('"')
        prefix = loc.split(f"s3://{AWS_BUCKET}/", 1)[1].split("/data/", 1)[0] + "/"
        _register(r, s3c["id"], f"jq_{'ext' if name.endswith('ext') else 'tetb'}_{tag}", prefix, "iceberg",
                  f"read-plan pod proof {tag}: {name} read directly from AWS S3")
        hive_schema = st["prem"]["schema"].split(".", 1)[1]
        _register(r, minio["id"], f"hv_{name}_{tag}", f"hive-metastore/{hive_schema}/{name}/", "parquet",
                  f"read-plan pod proof {tag}: on-prem Hive {name} read directly by QueryStudio")


def _existing_mor() -> str | None:
    import boto3
    s3 = boto3.client("s3", region_name=os.environ.get("AWS_DEFAULT_REGION", "us-east-2"))
    got = s3.list_objects_v2(Bucket=AWS_BUCKET, Prefix=f"{MOR_PREFIX}/", Delimiter="/")
    names = sorted(p["Prefix"].rstrip("/").split("/")[-1] for p in got.get("CommonPrefixes", []))
    for name in reversed(names):          # newest tag first; a COMPLETE table has a version hint
        key = f"{MOR_PREFIX}/{name}/metadata/version-hint.text"
        if s3.list_objects_v2(Bucket=AWS_BUCKET, Prefix=key).get("KeyCount"):
            return name
    return None


def build_mor() -> str:
    name = f"mor_{str(int(time.time()))[-6:]}"
    location = f"s3a://{AWS_BUCKET}/{MOR_PREFIX}/{name}"
    for k in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY"):
        if not os.environ.get(k):
            raise SystemExit(f"{k} is not set (rig/rig.env)")
    region = os.environ.get("AWS_DEFAULT_REGION", "us-east-2")
    script = os.path.join(HERE, "iceberg_deletes_table.py")
    cmd = ["docker", "run", "--rm", "-e", "AWS_ACCESS_KEY_ID", "-e", "AWS_SECRET_ACCESS_KEY",
           "-e", f"AWS_REGION={region}", "-v", f"{script}:/tmp/iceberg_deletes_table.py:ro",
           "--entrypoint", "/opt/spark/bin/spark-submit", SPARK_IMAGE, "--master", "local[2]",
           "--conf", "spark.hadoop.fs.s3a.aws.credentials.provider="
                     "com.amazonaws.auth.EnvironmentVariableCredentialsProvider",
           "--conf", f"spark.hadoop.fs.s3a.endpoint=s3.{region}.amazonaws.com",
           "/tmp/iceberg_deletes_table.py", location]
    print(f"mor: building {location} in {SPARK_IMAGE} (local mode)", flush=True)
    out = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "MSYS_NO_PATHCONV": "1"})
    lines = [ln for ln in out.stdout.splitlines()
             if ln.split(" ", 1)[0] in ("EXPECTED", "SNAPSHOT", "METADATA", "SUMMARY", "SPARK_COUNT")]
    print("\n".join("   " + ln for ln in lines))
    expected = next((int(ln.split()[1]) for ln in lines if ln.startswith("EXPECTED")), None)
    counted = next((int(ln.split()[1]) for ln in lines if ln.startswith("SPARK_COUNT")), None)
    if out.returncode != 0 or expected is None or counted != expected:
        raise SystemExit(f"mor build failed (exit {out.returncode}, expected {expected}, Spark counted "
                         f"{counted}): {out.stderr.strip()[-800:]}")
    return name


def mor(r, rebuild: bool) -> str:
    s3c = next(c for c in _conns(r) if c["name"] == "aws-real")
    name = None if rebuild else _existing_mor()
    if name:
        print(f"mor: reusing {MOR_PREFIX}/{name}/ on AWS")
    else:
        name = build_mor()
    _register(r, s3c["id"], name, f"{MOR_PREFIX}/{name}/", "iceberg",
              "read-plan pod proof: v2 Iceberg with position + equality deletes")
    return name


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--rebuild-mor", action="store_true", help="build a NEW MoR table even if one exists")
    a = ap.parse_args(argv)
    r = Rig()
    st = join_tables()
    register_join(r, st)
    st = json.load(open(jq.STATE))
    st["mor_table"] = mor(r, a.rebuild_mor)
    json.dump(st, open(jq.STATE, "w"), indent=1)
    print(f"ready: tag {st['tag']}, mor {st['mor_table']} -> {jq.STATE}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
