#!/bin/sh
# Run EVERY Docker proof harness and every browser spec against the running rig,
# one after another, and print one status line per harness.
#
#   . ~/.qs_keys/rigpw.sh && sh scripts/docker_proof/run_all.sh [harness ...]
#
# Prerequisites: the stack is up on images built from HEAD, rig_restore has run.
# Harnesses run SEQUENTIALLY on purpose -- two load proofs at once measure each
# other, not the product.  A harness that prints nothing is a FAILURE (exit
# status is what counts, not the absence of "FAIL").  Logs: $OUT/<name>.log.
set -u
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
OUT=${QS_PROOF_OUT:-$ROOT/proof-runs/$(date +%Y%m%d_%H%M%S)}
mkdir -p "$OUT"
PER_HARNESS_TIMEOUT=${QS_PROOF_TIMEOUT:-5400}

# Order: Vault seeding first (snowflake_real_account re-seeds the Snowflake
# key), load proofs last so a slow one cannot starve a correctness proof.
DEFAULT="snowflake_real_account_proof connections_admin_only_proof
connection_secret_blank_proof auth_rls_proof role_dataset_journey_proof
s3_sql_dataset_journey publish_report_connections_proof date_lov_roundtrip
fd_proof snowflake_journey_proof snowflake_typed_sql_context_proof
snowflake_report_params_proof feed_on_completion_proof cross_source_proof
credentials_unavailable_proof pv_paged_ceiling_proof pv_slot_proof
capacity_wait_proof fb59_acceptance fb61_ocean capability_exercise
snowflake_wide_table_proof snowflake_perf_proof snowflake_api_load_proof
snowflake_threshold_proof multiuser_load"
LIST=${*:-$DEFAULT}

SUMMARY="$OUT/SUMMARY.txt"
: > "$SUMMARY"
cd "$ROOT/scripts/docker_proof" || exit 2
# The 25 load users' password (capacity_wait, multiuser_load) lives beside
# the rig passwords, never in the repo.
[ -z "${QS_LOAD_PW:-}" ] && [ -f "$HOME/.qs_keys/loadpw.sh" ] && . "$HOME/.qs_keys/loadpw.sh"
fails=0
for h in $LIST; do
  t0=$(date +%s)
  args=""
  # pv_slot_proof phase A runs on the rig as-is; phase B needs the global cap
  # raised by hand (see its docstring), so the full run takes A only.
  [ "$h" = pv_slot_proof ] && args="--phase A"
  timeout "$PER_HARNESS_TIMEOUT" python "$h.py" $args > "$OUT/$h.log" 2>&1
  rc=$?
  dt=$(( $(date +%s) - t0 ))
  tally=$(grep -E "[0-9]+/[0-9]+ (PASSED|passed)|FAILED of|cleanup:" "$OUT/$h.log" | tail -2 | tr '\n' ' ')
  if [ "$rc" -eq 0 ] && [ -s "$OUT/$h.log" ]; then st=PASS; else st=FAIL; fails=$((fails+1)); fi
  line=$(printf '%-4s %-40s rc=%-3s %5ss  %s' "$st" "$h" "$rc" "$dt" "$tally")
  echo "$line" | tee -a "$SUMMARY"
done

if [ -z "${QS_SKIP_BROWSER:-}" ] && { [ $# -eq 0 ] || [ -n "${QS_BROWSER:-}" ]; }; then
  t0=$(date +%s)
  # The login rig: specs sign in as the rig admin unless told otherwise.
  [ -z "${QS_WALK_USER:-}" ] && [ -n "${QS_RIG_ADMIN_PW:-}" ] && export QS_WALK_USER=rig_admin QS_WALK_PASS="$QS_RIG_ADMIN_PW"
  (cd "$ROOT/frontend" && npx playwright test -c playwright.docker.config.ts --reporter=line) > "$OUT/browser.log" 2>&1
  rc=$?
  dt=$(( $(date +%s) - t0 ))
  tally=$(grep -E "[0-9]+ (passed|failed|flaky|skipped)" "$OUT/browser.log" | tr '\n' ' ')
  if [ "$rc" -eq 0 ]; then st=PASS; else st=FAIL; fails=$((fails+1)); fi
  printf '%-4s %-40s rc=%-3s %5ss  %s\n' "$st" "browser specs (playwright docker)" "$rc" "$dt" "$tally" | tee -a "$SUMMARY"
fi
echo "-- $fails harness(es) failed; logs in $OUT" | tee -a "$SUMMARY"
[ "$fails" -eq 0 ]
