"""The owner's JOIN query (temp/QUERY_WITH_JOIN.SQL) on the rig, both roads.

2026-10-14, the owner: the cloud data (AWS S3) and the on-prem data (Hive)
hold the same two tables; ONE query, the on-prem copy reached "by changing
the schema"; the cloud side may be read from S3 and its result written to S3
(config), validated, brought local and merged with on-prem.

    python join_query_proof.py setup [--rows 20000]     # tables + data, both sides
    python join_query_proof.py truth                    # the query on each cluster

``setup`` creates fact_tetb (487 columns) and fact_tetb_ext (76), the
definitions DERIVED from every query the owner shared (owner_table_defs.py),
as Iceberg on AWS S3 (cloud, ``iceberg_aws.jq_<tag>``) and as Hive on the
Starburst-shaped cluster (on-prem, ``hive.jq_<tag>``), and fills them ON the
clusters with SQL generated from the definitions, so the data exercises what
the query does:

* ``SYSTEM_ID``: SAPADB / MOTIFADJ / SAPADB / OTHER by row -- the WHERE keeps 3 of 4;
* the 5-key JOIN: fact rows past ``match`` have no ext row (the inner join drops them);
* the GROUP BY: rows 2k and 2k+1 share every text / date value, so groups of
  two SUM their amounts (and a pair split by the WHERE is a group of one);
* every 7th pair's free-text columns hold ``|``, ``"`` and ``'`` -- the
  query's own quoting (``'"' || REPLACE(...)``) is exercised.

State (the tag, table names, row counts) is kept in ``.join_query_state.json``.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from owner_table_defs import JOIN_SQL, owner_definitions          # noqa: E402
from tetb_real_e2e_proof import AWS_BUCKET, cloud_cli, ddl, sb_cli  # noqa: E402

STATE = os.path.join(HERE, ".join_query_state.json")
BD = dt.date(2025, 9, 30)                  # the date the owner's query names
DECOY = dt.date(2025, 8, 31)
FREE_TEXT = {"TRADE_COMMENTS", "ADB_ADJUSTMENT_TEXT", "ADJUSTMENT_ID", "USERNAME",
             "PRIMARY_REASON_CODE", "SOURCE_ADJUSTMENT_COMMENT"}
CELLS_PER_INSERT = 12_000_000


def abbr(c: str) -> str:
    return hashlib.sha1(c.encode()).hexdigest()[:3]


def col_expr(c: str, t: str, *, side: str, table: str) -> str:
    """One column of row ``n`` (a BIGINT), as SQL on the cluster."""
    g = "(n / 2)"                                            # the pair: rows 2k, 2k+1
    if c == "BUSINESS_CLOSE_DATE":
        return f"CASE WHEN n % 10 = 9 THEN DATE '{DECOY}' ELSE DATE '{BD}' END"
    if c == "CODE":
        return "'E' || CAST(n % 3 AS VARCHAR)"
    if c == "BUSINESSEVENT":
        return "'EOD'"
    if c == "SOURCE_DATA_SET":
        return "'SDS1'"
    if c == "SOURCE_DATA_ROW":
        return f"'{side}:' || CAST(n AS VARCHAR)"
    if c == "SYSTEM_ID":
        return ("CASE n % 4 WHEN 0 THEN 'SAPADB' WHEN 1 THEN 'MOTIFADJ' "
                "WHEN 2 THEN 'SAPADB' ELSE 'OTHER' END")
    if t == "DOUBLE":
        return "CAST(n AS DOUBLE) + 0.25"
    if t == "TIMESTAMP":
        return f"TIMESTAMP '2025-01-01 00:00:00' + {g} % 365 * INTERVAL '1' DAY + {g} % 86400 * INTERVAL '1' SECOND"
    if t == "DATE":
        return f"DATE '2025-01-01' + {g} % 365 * INTERVAL '1' DAY"
    base = f"'{abbr(c)}{side[0]}' || CAST({g} AS VARCHAR)"
    if c in FREE_TEXT:
        return (f"CASE WHEN {g} % 7 = 0 THEN 'x|y \"q\" it''s ' || CAST({g} AS VARCHAR) "
                f"ELSE {base} END")
    return base


def insert_sql(table: str, types: dict, side: str, lo: int, hi: int) -> str:
    """Rows ``n`` in [lo, hi) generated ON the cluster (sequence() caps at
    10,000, so n = a * 10000 + b)."""
    n_rows = hi - lo
    a_hi = (n_rows + 9999) // 10000
    exprs = ",\n  ".join(f"{col_expr(c, t, side=side, table=table)} AS {c.lower()}"
                         for c, t in types.items())
    return (f"INSERT INTO {table} ({', '.join(c.lower() for c in types)})\n"
            f"SELECT {', '.join(c.lower() for c in types)} FROM (SELECT\n  {exprs}\n"
            f"FROM (SELECT {lo} + a * 10000 + b AS n FROM UNNEST(sequence(0, {a_hi - 1})) AS x(a) "
            f"CROSS JOIN UNNEST(sequence(0, 9999)) AS y(b)) WHERE n < {hi})")


def ordered(types: dict, hive: bool) -> dict:
    """Hive partition columns go LAST (ddl does that); inserts must name the
    columns in the same order -- they name them explicitly, so any order works."""
    return types


def setup(rows: int) -> dict:
    fact, ext = owner_definitions()
    tag = str(int(time.time()))[-6:]
    match = int(rows * 0.9)                 # fact rows past this have no ext row
    st = {"tag": tag, "rows": rows, "match": match, "bd": BD.isoformat(),
          "cloud": {"schema": f"iceberg_aws.jq_{tag}"}, "prem": {"schema": f"hive.jq_{tag}"},
          "fact_cols": len(fact), "ext_cols": len(ext)}
    cloud_cli(f"CREATE SCHEMA {st['cloud']['schema']} WITH (location = "
              f"'s3://{AWS_BUCKET}/iceberg/jq_{tag}')")
    sb_cli(f"CREATE SCHEMA {st['prem']['schema']}")
    for side, cli, hive in (("cloud", cloud_cli, False), ("prem", sb_cli, True)):
        for name, types, n in (("fact_tetb", fact, rows), ("fact_tetb_ext", ext, match)):
            table = f"{st[side]['schema']}.{name}"
            cli(ddl(table, types, hive=hive) + ";\n", stdin=True)
            step = max(1000, CELLS_PER_INSERT // max(1, len(types)))
            t0 = time.time()
            for lo in range(0, n, step):
                cli(insert_sql(table, types, side, lo, min(n, lo + step)) + ";\n", stdin=True)
            got = int(cli(f"SELECT count(*) FROM {table}").strip().strip('"'))
            st[side][name] = {"table": table, "rows": got, "seconds": round(time.time() - t0, 1)}
            print(f"{side:5s} {table}: {got:,} rows, {len(types)} columns "
                  f"({st[side][name]['seconds']} s)", flush=True)
    json.dump(st, open(STATE, "w"), indent=1)
    return st


def owner_sql(schema: str) -> str:
    """The owner's query as written, its tables in ``schema``."""
    sql = open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")
    return sql.replace("icbg.fins.", schema + ".")


def truth() -> dict:
    st = json.load(open(STATE))
    out = {}
    for side, cli in (("cloud", cloud_cli), ("prem", sb_cli)):
        sql = owner_sql(st[side]["schema"])
        t0 = time.time()
        res = cli('SELECT count(*), sum("Transactional Currency Amount") FROM (\n' + sql + "\n) t;\n",
                  stdin=True).strip().replace('"', "").split("\t")
        n, amt = int(res[0]), float(res[1])
        out[side] = {"rows": n, "amount": amt, "seconds": round(time.time() - t0, 1)}
        print(f"{side:5s} the owner's JOIN query: {n:,} rows ({out[side]['seconds']} s)", flush=True)
    st["truth"] = out
    json.dump(st, open(STATE, "w"), indent=1)
    return out


RUN_CHECKS = []


def check(name, ok, detail=""):
    RUN_CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


INSPECT = r'''
import csv, json, sys
csv.field_size_limit(1 << 30)
n = 0; amt = 0.0
with open(sys.argv[1], newline="", encoding="utf-8-sig") as f:
    rd = csv.reader(f, delimiter="|")
    head = next(rd)
    i = head.index("Transactional Currency Amount")
    for row in rd:
        n += 1
        amt += float(row[i]) if row[i] not in ("", None) else 0.0
print(json.dumps({"rows": n, "amount": amt, "columns": len(head)}))
'''


def run_feeds() -> int:
    """Two feeds, ONE query each (the owner's, as written): cloud side by
    QueryStudio's S3 engine on the registered tables, on-prem side on Hive via
    Starburst -- both reached through query_params.table_map; the second feed
    also stages the cloud result on S3 (backend_config.stage_to_s3)."""
    import subprocess
    from feed_triggers_proof import Rig, psql
    st = json.load(open(STATE))
    tag, truth_ = st["tag"], st["truth"]
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    s3c = next(c for c in conns if c["name"] == "aws-real")
    sb = next(c for c in conns if c["name"] == "onprem-starburst")
    # the S3 connection DECLARES the dialect its SQL is written in: nothing is
    # guessed (core/sql_dialect_translator.source_dialect_for)
    s, full = r.call("GET", f"/api/connections/{s3c['id']}")
    cfg = dict((full or {}).get("config") or {})
    if cfg.get("sql_dialect") != "trino":
        cfg["sql_dialect"] = "trino"
        s, b = r.call("PUT", f"/api/connections/{s3c['id']}", {
            "name": full["name"], "connection_type": full["connection_type"], "config": cfg})
        if s != 200:
            raise SystemExit(f"declare sql_dialect: {s} {str(b)[:300]}")
    reg = {}
    for name in ("fact_tetb", "fact_tetb_ext"):
        rname = f"jq_{'ext' if name.endswith('ext') else 'tetb'}_{tag}"
        sch = st["cloud"]["schema"]
        loc = cloud_cli(f'SELECT file_path FROM {sch}."{name}$files" LIMIT 1').strip().strip('"')
        prefix = loc.split(f"s3://{AWS_BUCKET}/", 1)[1].split("/data/", 1)[0] + "/"
        s, b = r.call("POST", f"/api/connections/{s3c['id']}/tables", {
            "name": rname, "s3_prefix": prefix, "format": "iceberg",
            "description": f"join-query proof {tag}: {name} read directly from AWS S3"})
        if s not in (200, 201) and "already" not in str(b).lower():
            raise SystemExit(f"register {rname}: {s} {str(b)[:300]}")
        reg[name] = rname
    sql = open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")
    table_map = {"primary": {"icbg.fins.fact_tetb": reg["fact_tetb"],
                             "icbg.fins.fact_tetb_ext": reg["fact_tetb_ext"]},
                 "secondary": {"icbg.fins": st["prem"]["schema"]}}
    want_rows = truth_["cloud"]["rows"] + truth_["prem"]["rows"]
    want_amt = truth_["cloud"]["amount"] + truth_["prem"]["amount"]
    check("the truth is non-zero on both sides", truth_["cloud"]["rows"] > 0 and truth_["prem"]["rows"] > 0,
          f"cloud {truth_['cloud']['rows']:,} + on-prem {truth_['prem']['rows']:,}")
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    results = []
    for staged in (False, True):
        name = f"JQ_JOIN_{'STAGED_' if staged else ''}{tag}"
        bc = ({"stage_to_s3": {"side": "primary", "connection_id": s3c["id"], "bucket": AWS_BUCKET,
                               "prefix": "qs-stage/"}} if staged else None)
        body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": s3c["id"],
                "query_params": {"sql": sql, "table_map": table_map},
                "secondary_connection_id": sb["id"], "secondary_source_type": None,
                "combine_mode": "union", "output_format": "csv",
                "output_options": {"delimiter": "|"}, "destination_type": "local",
                "destination_config": {}, "execution_backend": "native", "is_active": True,
                "schedule_enabled": False, "backend_config": bc,
                "description": "Proof: the owner's JOIN query, ONE text; cloud = S3 engine, "
                               "on-prem = Hive (schema mapped)"
                               + ("; cloud result staged on S3" if staged else "")}
        f = next((x for x in feeds if x["name"] == name), None)
        s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
        if s not in (200, 201):
            raise SystemExit(f"{name}: {s} {str(b)[:600]}")
        fid = f["id"] if f else b["id"]
        before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
        run = r.run_row(fid, st["bd"])
        if run is None:
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": st["bd"], "end_date": st["bd"],
                          "deliver": True, "reason": "join-query proof"})
        else:
            s, b = r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": "join-query proof"})
        if s not in (200, 201, 202):
            raise SystemExit(f"{name} start: {s} {str(b)[:300]}")
        t0 = time.time()
        row = ""
        while time.time() - t0 < 2400:
            row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                       f"order by id desc limit 1")
            if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
                break
            time.sleep(10)
        eid, status = row.split("|")
        err = psql(f"select coalesce(error_message,'') from feed_executions where id={eid}")
        fm = json.loads(psql(f"select files_metadata from feed_executions where id={eid}") or "{}")
        xs = fm.get("cross_source") or {}
        stages = {s_["stage"]: s_.get("duration_seconds")
                  for s_ in (fm.get("stage_history") or {}).get("stages") or []}
        check(f"{name} completed", status == "completed", status + (f": {err[:400]}" if err else ""))
        res = {"feed": name, "status": status, "stages": stages, "cross_source": xs, "error": err[:600]}
        if status == "completed":
            art = psql(f"select coalesce(artifact_path,'') from feed_executions where id={eid}")
            out = subprocess.run(["docker", "exec", "-i", "qs-local-scheduler", "python", "-", art],
                                 input=INSPECT, capture_output=True, text=True, timeout=900)
            got = json.loads(out.stdout.strip().splitlines()[-1]) if out.returncode == 0 else {}
            res["file"] = got
            check(f"{name}: cloud side rows == Trino on AWS", xs.get("primary_rows") == truth_["cloud"]["rows"],
                  f"{xs.get('primary_rows')} vs {truth_['cloud']['rows']}")
            check(f"{name}: on-prem side rows == Starburst on Hive",
                  xs.get("secondary_rows") == truth_["prem"]["rows"],
                  f"{xs.get('secondary_rows')} vs {truth_['prem']['rows']}")
            check(f"{name}: file rows == both sides", got.get("rows") == want_rows,
                  f"{got.get('rows')} vs {want_rows}")
            check(f"{name}: amount total == both sides' SUM",
                  abs((got.get("amount") or 0) - want_amt) < 1e-6 * max(1.0, want_amt),
                  f"{got.get('amount')} vs {want_amt}")
            check(f"{name}: 173 columns as the query names them", got.get("columns") == 173, got.get("columns"))
            tr = fm.get("sql_translation") or {}
            check(f"{name}: the cloud SQL read as Trino because the connection DECLARES it",
                  tr.get("from") == "trino" and tr.get("how") == "declared", tr)
            if staged:
                stg = (xs.get("staged") or [{}])[0]
                check(f"{name}: cloud result staged on S3, validated, brought back",
                      stg.get("rows") == truth_["cloud"]["rows"] and bool(stg.get("validated")),
                      json.dumps(stg)[:300])
        results.append(res)
        print(json.dumps(res, default=str)[:1500], flush=True)
    path = os.path.join(HERE, "join-query-results.json")
    json.dump({"checks": RUN_CHECKS, "runs": results}, open(path, "w"), indent=1, default=str)
    bad = [c for c in RUN_CHECKS if not c["ok"]]
    print(f"\n{len(RUN_CHECKS) - len(bad)}/{len(RUN_CHECKS)} checks passed -> {path}")
    return 1 if bad else 0


def run_hive_direct() -> int:
    """Step 1 of docs/READ_PLAN_ALL_ENGINES_2026_10_14.html: the ON-PREM Hive
    tables read by QueryStudio DIRECTLY from their files on the on-prem object
    store (MinIO) -- no Starburst anywhere in the feed.  Checks QueryStudio's
    count of each Hive table against Starburst's, an empty folder REFUSED (not
    an empty answer), and the owner's JOIN query with BOTH sides read by
    QueryStudio (cloud: AWS S3, on-prem: Hive on MinIO)."""
    import subprocess
    from feed_triggers_proof import Rig, psql
    st = json.load(open(STATE))
    tag, truth_ = st["tag"], st["truth"]
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    s3c = next(c for c in conns if c["name"] == "aws-real")
    minio = next(c for c in conns if c["connection_type"] == "s3"
                 and (c.get("config") or {}).get("bucket_name") == "qs-data")
    # the on-prem connection declares its SQL's dialect too
    s, full = r.call("GET", f"/api/connections/{minio['id']}")
    cfg = dict((full or {}).get("config") or {})
    if cfg.get("sql_dialect") != "trino":
        cfg["sql_dialect"] = "trino"
        s, b = r.call("PUT", f"/api/connections/{minio['id']}", {
            "name": full["name"], "connection_type": full["connection_type"], "config": cfg})
        if s != 200:
            raise SystemExit(f"declare sql_dialect on {full['name']}: {s} {str(b)[:300]}")
    hv = {}
    hive_schema = st["prem"]["schema"].split(".", 1)[1]            # hive.jq_<tag> -> jq_<tag>
    for name in ("fact_tetb", "fact_tetb_ext"):
        rname = f"hv_{name}_{tag}"
        r.call("DELETE", f"/api/connections/{minio['id']}/tables/{rname}")
        s, b = r.call("POST", f"/api/connections/{minio['id']}/tables", {
            "name": rname, "s3_prefix": f"hive-metastore/{hive_schema}/{name}/", "format": "parquet",
            "description": f"join-query proof {tag}: on-prem Hive {name} read directly by QueryStudio"})
        check(f"Hive {name} registered on the on-prem object store", s in (200, 201), s)
        s2, pb = r.call("GET", f"/api/connections/{minio['id']}/tables/{rname}/partitions")
        cols = sorted((c.get("name") if isinstance(c, dict) else str(c))
                      for c in ((pb or {}).get("partition_columns") or []))
        check(f"Hive {name}: its partition folders are detected (files with no extension counted)",
              s2 == 200 and cols == ["business_close_date", "businessevent", "code"]
              and int((pb or {}).get("total_files") or 0) > 0,
              f"{s2} partitions={cols} files={(pb or {}).get('total_files')}")
        hv[name] = rname

    def qs_count(conn_id, sql):
        s, b = r.call("POST", "/api/sql/execute", {"primary_connection_id": conn_id, "primary_sql": sql})
        eid = (b or {}).get("execution_id")
        for _ in range(150):
            s, stt = r.call("GET", f"/api/executions/{eid}/status")
            if (stt or {}).get("status") in ("completed", "failed", "cancelled"):
                break
            time.sleep(2)
        s, res = r.call("GET", f"/api/executions/{eid}/results?page=1&page_size=5")
        rows = (res or {}).get("rows") or []
        v = rows[0] if rows else None
        v = (list(v.values())[0] if isinstance(v, dict) else v[0]) if v else None
        return (stt or {}).get("status"), v, (stt or {}).get("error_message")

    for name in ("fact_tetb", "fact_tetb_ext"):
        want = st["prem"][name]["rows"]
        status, got, err = qs_count(minio["id"], f"select count(*) as n from {hv[name]}")
        check(f"QueryStudio's count of Hive {name} == Starburst's", status == "completed" and int(got or -1) == want,
              f"{status} {got} vs {want} {err or ''}")
    # an EMPTY folder is refused with the folder named -- never an empty answer
    empty = f"hv_empty_{tag}"
    r.call("DELETE", f"/api/connections/{minio['id']}/tables/{empty}")
    r.call("POST", f"/api/connections/{minio['id']}/tables", {
        "name": empty, "s3_prefix": f"hive-metastore/{hive_schema}/no_such_table/", "format": "parquet",
        "description": "join-query proof: a folder with no data files"})
    status, got, err = qs_count(minio["id"], f"select count(*) as n from {empty}")
    check("a table with no data files is REFUSED, naming the folder (not answered as empty)",
          status == "failed" and "no data files" in str(err or "").lower(), f"{status}: {str(err)[:200]}")
    r.call("DELETE", f"/api/connections/{minio['id']}/tables/{empty}")

    # the owner's JOIN query, BOTH sides by QueryStudio: cloud from AWS S3,
    # on-prem from the Hive files -- one text, each side's tables mapped
    sql = open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")
    table_map = {"primary": {"icbg.fins.fact_tetb": f"jq_tetb_{tag}",
                             "icbg.fins.fact_tetb_ext": f"jq_ext_{tag}"},
                 "secondary": {"icbg.fins.fact_tetb": hv["fact_tetb"],
                               "icbg.fins.fact_tetb_ext": hv["fact_tetb_ext"]}}
    name = f"JQ_JOIN_HIVE_{tag}"
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": s3c["id"],
            "query_params": {"sql": sql, "table_map": table_map},
            "secondary_connection_id": minio["id"], "secondary_source_type": None,
            "combine_mode": "union", "output_format": "csv", "output_options": {"delimiter": "|"},
            "destination_type": "local", "destination_config": {}, "execution_backend": "native",
            "is_active": True, "schedule_enabled": False, "backend_config": None,
            "description": "Proof: the owner's JOIN query, ONE text; cloud = AWS S3, on-prem = Hive "
                           "files read by QueryStudio (no Starburst)"}
    f = next((x for x in feeds if x["name"] == name), None)
    s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
    if s not in (200, 201):
        raise SystemExit(f"{name}: {s} {str(b)[:500]}")
    fid = f["id"] if f else b["id"]
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    run = r.run_row(fid, st["bd"])
    if run is None:
        s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": st["bd"], "end_date": st["bd"],
                      "deliver": True, "reason": "join-query proof (Hive direct)"})
    else:
        s, b = r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": "join-query proof (Hive direct)"})
    t0, row = time.time(), ""
    while time.time() - t0 < 2400:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                   f"order by id desc limit 1")
        if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
            break
        time.sleep(10)
    eid, status = row.split("|")
    err = psql(f"select coalesce(error_message,'') from feed_executions where id={eid}")
    fm = json.loads(psql(f"select files_metadata from feed_executions where id={eid}") or "{}")
    xs = fm.get("cross_source") or {}
    check(f"{name} completed", status == "completed", status + (f": {err[:300]}" if err else ""))
    if status == "completed":
        art = psql(f"select coalesce(artifact_path,'') from feed_executions where id={eid}")
        out = subprocess.run(["docker", "exec", "-i", "qs-local-scheduler", "python", "-", art],
                             input=INSPECT, capture_output=True, text=True, timeout=900)
        got = json.loads(out.stdout.strip().splitlines()[-1]) if out.returncode == 0 else {}
        check(f"{name}: cloud side (AWS S3, QueryStudio) == Trino", xs.get("primary_rows") == truth_["cloud"]["rows"],
              f"{xs.get('primary_rows')} vs {truth_['cloud']['rows']}")
        check(f"{name}: on-prem side (Hive files, QueryStudio) == Starburst on Hive",
              xs.get("secondary_rows") == truth_["prem"]["rows"],
              f"{xs.get('secondary_rows')} vs {truth_['prem']['rows']}")
        want_rows = truth_["cloud"]["rows"] + truth_["prem"]["rows"]
        want_amt = truth_["cloud"]["amount"] + truth_["prem"]["amount"]
        check(f"{name}: file rows == both sides", got.get("rows") == want_rows, f"{got.get('rows')} vs {want_rows}")
        check(f"{name}: amount total == both sides' SUM",
              abs((got.get("amount") or 0) - want_amt) < 1e-6 * max(1.0, want_amt),
              f"{got.get('amount')} vs {want_amt}")
    path = os.path.join(HERE, "join-query-hive-results.json")
    json.dump({"checks": RUN_CHECKS}, open(path, "w"), indent=1, default=str)
    bad = [c for c in RUN_CHECKS if not c["ok"]]
    print(f"\n{len(RUN_CHECKS) - len(bad)}/{len(RUN_CHECKS)} checks passed -> {path}")
    return 1 if bad else 0


SFTP_DEST = {"host": "qs-sftp", "port": 22, "username": "feeduser", "password": "FeedPass_123",
             "remote_dir": "/inbox"}


def _sftp_rows(filename: str):
    """The delivered file, copied out of qs-sftp and parsed as the counterparty would."""
    import collections
    import csv
    import io
    import subprocess
    out = subprocess.run(["docker", "exec", "qs-sftp", "cat", f"/home/feeduser/inbox/{filename}"],
                         capture_output=True, timeout=600)
    if out.returncode != 0:
        return None, None
    rd = csv.reader(io.StringIO(out.stdout.decode("utf-8-sig")), delimiter="|")
    head = next(rd)
    return head, collections.Counter(tuple(r) for r in rd)


def run_spark_tables() -> int:
    """Step 3 of docs/READ_PLAN_ALL_ENGINES_2026_10_14.html, on the rig's Spark
    pods: the owner's JOIN query over the on-prem Hive tables (Parquet on MinIO)
    as a "tables" side -- the backend plans each table, the job reads exactly
    that and runs the SQL converted to Spark.  The SAME feed on QueryStudio's
    engine is the twin: both files must hold the same rows, value by value."""
    from feed_triggers_proof import Rig, psql
    st = json.load(open(STATE))
    tag, truth_ = st["tag"], st["truth"]
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    minio = next(c for c in conns if c["connection_type"] == "s3"
                 and (c.get("config") or {}).get("bucket_name") == "qs-data")
    sql = open(JOIN_SQL, encoding="utf-8").read().strip().rstrip(";")
    table_map = {"primary": {"icbg.fins.fact_tetb": f"hv_fact_tetb_{tag}",
                             "icbg.fins.fact_tetb_ext": f"hv_fact_tetb_ext_{tag}"}}
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    files = {}
    for lane in ("native", "spark_k8s"):
        name = f"JQ_HIVE_{'SPARK' if lane == 'spark_k8s' else 'NATIVE'}_{tag}"
        body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": minio["id"],
                "query_params": {"sql": sql, "table_map": table_map}, "output_format": "csv",
                "output_options": {"delimiter": "|"}, "destination_type": "sftp",
                "destination_config": dict(SFTP_DEST),
                "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
                "execution_backend": lane, "is_active": True, "schedule_enabled": False,
                "description": f"Proof: the owner's JOIN query over the on-prem Hive tables on {lane}"}
        f = next((x for x in feeds if x["name"] == name), None)
        s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
        if s not in (200, 201):
            raise SystemExit(f"{name}: {s} {str(b)[:500]}")
        fid = f["id"] if f else b["id"]
        before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
        run = r.run_row(fid, st["bd"])
        if run is None:
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": st["bd"], "end_date": st["bd"],
                          "deliver": True, "reason": f"read-plan proof ({lane})"})
        else:
            s, b = r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": f"read-plan proof ({lane})"})
        t0, row = time.time(), ""
        while time.time() - t0 < 3000:
            row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                       f"order by id desc limit 1")
            if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
                break
            time.sleep(10)
        eid, status = row.split("|")
        err = psql(f"select coalesce(error_message,'') from feed_executions where id={eid}")
        backend = psql(f"select coalesce(execution_backend,'') from feed_executions where id={eid}")
        total = psql(f"select coalesce(total_rows,0) from feed_executions where id={eid}")
        check(f"{name} completed on {lane}", status == "completed" and backend == lane,
              f"{status} backend={backend} rows={total} {err[:300]}")
        if status != "completed":
            continue
        fn = name + "_" + st["bd"].replace("-", "") + ".csv"
        head, rows = _sftp_rows(fn)
        files[lane] = (head, rows)
        n = sum(rows.values()) if rows else 0
        check(f"{name}: delivered file rows == Starburst on Hive", n == truth_["prem"]["rows"],
              f"{n} vs {truth_['prem']['rows']}")
        if lane == "spark_k8s":
            s, lg = r.call("GET", f"/api/feed-executions/{eid}/driver-log")
            text = json.dumps(lg)
            check(f"{name}: the job read each table as the backend planned it",
                  "(= planned)" in text and f"hv_fact_tetb_{tag}" in text, text[:300] if "(= planned)" not in text else "")
    if "native" in files and "spark_k8s" in files:
        (h1, r1), (h2, r2) = files["native"], files["spark_k8s"]
        check("the Spark file and QueryStudio's file have the same header", h1 == h2,
              "" if h1 == h2 else f"{len(h1)} vs {len(h2)}: {[a for a, b in zip(h1, h2) if a != b][:5]}")
        diff_a, diff_b = r1 - r2, r2 - r1
        check("the Spark file and QueryStudio's file hold the same rows, value by value",
              not diff_a and not diff_b and sum(r1.values()) > 0,
              "" if not diff_a and not diff_b else
              f"{sum(diff_a.values())} only in native, {sum(diff_b.values())} only in spark; e.g. "
              f"native {list(diff_a)[:1]} spark {list(diff_b)[:1]}")
    path = os.path.join(HERE, "read-plan-spark-results.json")
    json.dump({"checks": RUN_CHECKS}, open(path, "w"), indent=1, default=str)
    bad = [c for c in RUN_CHECKS if not c["ok"]]
    print(f"\n{len(RUN_CHECKS) - len(bad)}/{len(RUN_CHECKS)} checks passed -> {path}")
    return 1 if bad else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("setup")
    s.add_argument("--rows", type=int, default=20_000)
    sub.add_parser("truth")
    sub.add_parser("run")
    sub.add_parser("hive")
    sub.add_parser("spark")
    a = ap.parse_args()
    if a.cmd == "setup":
        setup(a.rows)
    elif a.cmd == "truth":
        truth()
    elif a.cmd == "hive":
        sys.exit(run_hive_direct())
    elif a.cmd == "spark":
        sys.exit(run_spark_tables())
    else:
        sys.exit(run_feeds())
