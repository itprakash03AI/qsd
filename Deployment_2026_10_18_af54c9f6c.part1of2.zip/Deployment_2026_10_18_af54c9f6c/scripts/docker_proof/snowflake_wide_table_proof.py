"""1,000 columns x 1,000,000 rows on the REAL Snowflake account, through
QueryStudio, timed and judged against Snowflake (2026-10-03, login ON).

Table QS_DEMO.FIN.WIDE_1000 (created by scratch DDL, kept): ID 1..1e6,
REGION = ID % 4 -> EMEA/APAC/AMER/LATAM, DT = 2026-07-01 + ID % 90, and
C0004..C1000 with k % 10 in 0..6 NUMBER ((ID*k) % 1000), 7..8 VARCHAR
('v' || (ID*k) % 50), 9 DATE (2025-01-01 + (ID*k) % 365) -- every cell is
computable, so answers are checked, not eyeballed.

Measures each step's wall time and the API container's memory, and checks:
  1. browse: 1,000 columns listed, with their types;
  2. SQL editor: aggregates over 1M rows == Snowflake;
  3. SQL editor: SELECT * at 5,000 rows (5M cells) -- shape + cells exact;
  4. SQL editor: 1M rows x 5 columns -- every row arrives, sums exact;
  5. dataset over SELECT *: auto-detect 1,000 typed columns;
  6. report by REGION (sums of 3 columns) == Snowflake;
  7. detail report, all 1,000 columns at its 50,000-row limit;
  8. the summary report published: :8003 == Snowflake;
  9. a feed: 1M rows x 10 columns -> CSV, line count and sums exact.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_wide_table_proof.py
"""
from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
T = "QS_DEMO.FIN.WIDE_1000"
TAG = str(int(time.time()))[-6:]
PUB = "http://localhost:8003"
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
res, timings = [], []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return bool(ok)


def mem(container="qs-local-api"):
    out = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{.MemUsage}}", container],
                         capture_output=True, text=True).stdout.strip()
    return out.split("/")[0].strip()


class Timer:
    def __init__(self, label):
        self.label = label

    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, *a):
        self.s = round(time.time() - self.t0, 1)
        timings.append((self.label, self.s, mem()))
        print(f"   [{self.label}] {self.s}s  api mem {timings[-1][2]}", flush=True)


def sf():
    import snowflake.connector
    from cryptography.hazmat.primitives import serialization
    key = os.path.expanduser(os.environ.get("QS_SF_KEY_FILE", "~/.qs_keys/qs_svc_key.p8"))
    pk = serialization.load_pem_private_key(open(key, "rb").read(), password=None)
    der = pk.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8,
                           serialization.NoEncryption())
    return snowflake.connector.connect(account=os.environ.get("QS_SF_ACCOUNT", "IRFJALM-NZC41769"),
                                       user="QS_SVC", private_key=der, warehouse="COMPUTE_WH")


def rows_of(b):
    names = [x["name"] if isinstance(x, dict) else x for x in (b or {}).get("columns") or []]
    return names, [r if isinstance(r, dict) else dict(zip(names, r)) for r in (b or {}).get("rows") or []]


def sql_run(sess, sql, limit, page_size=100, timeout=1800):
    s, r, _ = sess.call("POST", "/api/sql/execute", {"primary_connection_id": CID, "primary_sql": sql,
                                                     "row_limit": limit})
    if s != 200 or not (r or {}).get("execution_id"):
        return s, r, None
    eid = r["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st, _ = sess.call("GET", f"/api/executions/{eid}/status")
        if (st or {}).get("status") in ("completed", "success", "finished"):
            _, rb, _ = sess.call("GET", f"/api/executions/{eid}/results?page_size={page_size}")
            return 200, rb, st
        if (st or {}).get("status") in ("failed", "error", "cancelled"):
            return 500, (st or {}).get("error_message") or st, st
        time.sleep(1)
    return -1, "timeout", None


def cell(k, i):
    """The value of column C{k} in row ID=i (see the module docstring)."""
    m = k % 10
    if m < 7:
        return (i * k) % 1000
    if m < 9:
        return f"v{(i * k) % 50}"
    return None  # a date -- compared separately


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    con = sf()
    cur = con.cursor()
    undo = []
    print("api mem at start", mem())
    try:
        print("\n== 1 . browse 1,000 columns")
        with Timer("columns endpoint"):
            s, cols, _ = admin.call("GET", f"/api/sql/connections/{CID}/columns?catalog=QS_DEMO&schema=FIN&table=WIDE_1000")
        cl = cols if isinstance(cols, list) else (cols or {}).get("columns") or []
        kinds = {}
        for c in cl:
            kinds[str(c.get("type")).split("(")[0]] = kinds.get(str(c.get("type")).split("(")[0], 0) + 1
        check("1,000 columns listed with types", s == 200 and len(cl) == 1000, (len(cl), kinds))

        print("\n== 2 . aggregates over 1M rows")
        truth = cur.execute(f"select count(*), sum(C0004), sum(C0500), count(distinct C0007), max(C0009) from {T}").fetchone()
        with Timer("aggregate query"):
            s, rb, _ = sql_run(admin, f"select count(*) as N, sum(C0004) as S4, sum(C0500) as S500, "
                                      f"count(distinct C0007) as D7, max(C0009) as M9 from {T}", 10)
        _, r = rows_of(rb if s == 200 else {})
        got = r[0] if r else {}
        check("count / sums / distinct / max == Snowflake",
              s == 200 and int(got.get("N", -1)) == truth[0] and int(got.get("S4", -1)) == int(truth[1])
              and int(got.get("S500", -1)) == int(truth[2]) and int(got.get("D7", -1)) == truth[3]
              and str(got.get("M9"))[:10] == str(truth[4]), (got, truth))

        print("\n== 3 . SELECT * at 5,000 rows (5M cells)")
        with Timer("select * 5000 rows"):
            s, rb, st = sql_run(admin, f"select * from {T} order by ID", 5000, page_size=50)
        names, r = rows_of(rb if s == 200 else {})
        ok_shape = s == 200 and len(names) == 1000 and int((rb or {}).get("total_rows") or (st or {}).get("total_rows") or 0) == 5000
        bad = []
        for row in r[:50]:
            i = int(row["ID"])
            for k in (4, 7, 8, 500, 999, 1000):
                want = cell(k, i)
                if want is not None and str(row.get(f"C{k:04d}")) != str(want):
                    bad.append((i, k, row.get(f"C{k:04d}"), want))
        check("1,000 columns x 5,000 rows, and every sampled cell == its formula",
              ok_shape and r and not bad, {"cols": len(names), "total": (rb or {}).get("total_rows"),
                                           "first_page": len(r), "bad": bad[:5]})

        print("\n== 4 . 1M rows x 5 columns, all of them")
        with Timer("1M x 5 cols"):
            s, rb, st = sql_run(admin, f"select ID, REGION, DT, C0004, C0010 from {T}", 0, page_size=10)
        total = int((rb or {}).get("total_rows") or (st or {}).get("total_rows") or 0) if s == 200 else 0
        check("every one of the 1,000,000 rows arrived", s == 200 and total == 1_000_000, (s, total, str(rb)[:160]))

        print("\n== 5 . a dataset over SELECT * (1,000 columns)")
        # A dataset holds at most semantic_layer.max_columns_per_dataset
        # (default 500) -- a 1,000-column dataset needs it raised, which an
        # admin does at runtime; restored in the finally.
        _, slc, _ = admin.call("GET", "/api/admin/semantic-layer/config")
        old_limit = int((slc or {}).get("max_columns_per_dataset") or 500)
        s, _, _ = admin.call("PUT", "/api/admin/semantic-layer/config", {"max_columns_per_dataset": 1500})
        check("the admin raises the dataset column limit to 1,500", s == 200, s)
        undo.append(("limit", old_limit))
        with Timer("dataset create"):
            s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"wide_1000_{TAG}", "subject": "stress",
                                                            "connection_ids": [CID], "base_query": f"select * from {T}"})
        if not check("dataset created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:200])):
            return 1
        did = ds["id"]
        undo.insert(0, f"/api/datasets/{did}")
        with Timer("dataset auto-detect"):
            s_ad, ad, _ = admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
        _, d, _ = admin.call("GET", f"/api/datasets/{did}")
        dcols = {c["physical_name"]: c for c in d.get("columns") or []}
        types = {}
        for c in dcols.values():
            types[c.get("data_type")] = types.get(c.get("data_type"), 0) + 1
        want_types = {"C0004": "number", "C0007": "string", "C0009": "date", "DT": "date", "REGION": "string"}
        check("auto-detect: 1,000 typed columns, each kind right",
              s_ad == 200 and len(dcols) == 1000
              and all(dcols.get(k, {}).get("data_type") == v for k, v in want_types.items()),
              (s_ad, len(dcols), types, {k: dcols.get(k, {}).get("data_type") for k in want_types},
               str(ad)[:200] if s_ad != 200 else ""))
        if len(dcols) != 1000:
            return 1

        print("\n== 6 . a report by REGION")
        rtruth = {r_[0]: (int(r_[1]), int(r_[2]), int(r_[3])) for r_ in cur.execute(
            f"select REGION, sum(C0004), sum(C0100), sum(C0995) from {T} group by 1").fetchall()}
        ids = [dcols[n]["id"] for n in ("REGION", "C0004", "C0100", "C0995")]
        s, rep, _ = admin.call("POST", "/api/business-reports", {"name": f"wide-sum-{TAG}", "dataset_id": did,
                                                                 "data_source_type": "dataset", "column_ids": ids})
        if check("summary report created", s == 200 and (rep or {}).get("id"), (s, str(rep)[:200])):
            rid = rep["id"]
            undo.insert(0, f"/api/business-reports/{rid}")
            with Timer("summary report run"):
                _, ex, _ = admin.call("POST", f"/api/business-reports/{rid}/execute",
                                      {"parameter_values": {}, "force_refresh": True})
                _, rb, _ = admin.call("GET", f"/api/business-reports/{rid}/results/{(ex or {}).get('execution_id')}?page_size=50")
            _, r = rows_of(rb)
            got = {x["REGION"]: (int(x["C0004"]), int(x["C0100"]), int(x["C0995"])) for x in r if x.get("REGION")}
            check("summary report == Snowflake, region by region", got == rtruth and len(got) == 4, (got, rtruth))

            print("\n== 8 . that report as a published API")
            admin.call("POST", f"/api/business-reports/{rid}/publish", {"action": "publish"})
            slug = f"wide-sum-{TAG}"
            s, pv, _ = admin.call("POST", "/api/published-views", {"name": slug, "slug": slug,
                                                                   "source_type": "business_report",
                                                                   "business_report_id": rid,
                                                                   "credential_mode": "publisher"})
            if (pv or {}).get("id"):
                undo.insert(0, f"/api/published-views/{pv['id']}")
            import qs_docker_client as c
            saved = c.BASE
            c.BASE = PUB
            try:
                with Timer("published API call"):
                    s, b, _ = c.call("GET", f"/api/v1/views/{slug}/data?limit=10", None,
                                     headers={"X-API-Key": (pv or {}).get("test_api_key", "")})
            finally:
                c.BASE = saved
            got = {x["REGION"]: (int(x["C0004"]), int(x["C0100"]), int(x["C0995"])) for x in (b or {}).get("data") or []}
            check("published API == Snowflake", s == 200 and got == rtruth, (s, got))

        print("\n== 7 . a detail report: all 1,000 columns at its 50,000-row limit")
        s, rep2, _ = admin.call("POST", "/api/business-reports", {"name": f"wide-detail-{TAG}", "dataset_id": did,
                                                                  "data_source_type": "dataset",
                                                                  "column_ids": [c["id"] for c in dcols.values()]})
        if check("detail report created", s == 200 and (rep2 or {}).get("id"), (s, str(rep2)[:200])):
            rid2 = rep2["id"]
            undo.insert(0, f"/api/business-reports/{rid2}")
            with Timer("detail report run (50M cells)"):
                s, ex, _ = admin.call("POST", f"/api/business-reports/{rid2}/execute",
                                      {"parameter_values": {}, "force_refresh": True})
            eid = (ex or {}).get("execution_id")
            with Timer("detail report first page"):
                s2, rb, _ = admin.call("GET", f"/api/business-reports/{rid2}/results/{eid}?page_size=100")
            names, r = rows_of(rb)
            check("detail report: 50,000 rows x 1,000 columns, page 1 served",
                  s == 200 and int((ex or {}).get("total_rows") or 0) == 50_000 and len(names) == 1000 and len(r) == 100,
                  {"http": s, "total": (ex or {}).get("total_rows"), "cols": len(names), "page": len(r),
                   "err": str(ex)[:200] if s != 200 else ""})

        print("\n== 9 . a feed: 1M rows x 10 columns -> CSV")
        fcols = "ID, REGION, DT, C0004, C0005, C0007, C0009, C0100, C0500, C1000"
        ftruth = cur.execute(f"select count(*), sum(C0004), sum(C0100), sum(C0500), sum(C1000) from {T}").fetchone()
        s, fb, _ = admin.call("POST", "/api/feeds", {
            "name": f"WIDE_FEED_{TAG}", "source_type": "raw_sql", "source_id": 0, "connection_id": CID,
            "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
            "query_params": {"sql": f"select {fcols} from {T}"}})
        fid = (fb or {}).get("id") if isinstance(fb, dict) else None
        if check("feed created", s == 200 and fid, (s, str(fb)[:200])):
            undo.insert(0, f"/api/feeds/{fid}")
            with Timer("feed 1M x 10 -> CSV"):
                s, ex, _ = admin.call("POST", f"/api/feeds/{fid}/execute", {"trigger_type": "manual"})
                dbid = (ex or {}).get("execution_db_id")
                e, t0 = {}, time.time()
                while dbid and time.time() - t0 < 1800:
                    _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                    if (e or {}).get("status") in ("completed", "failed", "error", "cancelled", "skipped"):
                        break
                    time.sleep(3)
            path = (e or {}).get("destination_path")
            sums = None
            if path:
                py = ("import csv,sys\nr=csv.reader(open(sys.argv[1],newline=''))\nh=next(r)\n"
                      "ix=[h.index(c) for c in ('C0004','C0100','C0500','C1000')]\nn=0;s=[0,0,0,0]\n"
                      "for row in r:\n n+=1\n for j,i in enumerate(ix): s[j]+=int(float(row[i]))\n"
                      "print(n,*s)")
                out = subprocess.run(["docker", "exec", "qs-local-api", "python3", "-c", py, path],
                                     capture_output=True, text=True, env=DENV).stdout.split()
                sums = [int(x) for x in out] if len(out) == 5 else out
                size = subprocess.run(["docker", "exec", "qs-local-api", "stat", "-c", "%s", path],
                                      capture_output=True, text=True, env=DENV).stdout.strip()
                subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", path], env=DENV)
            check("the feed's CSV: 1,000,000 lines and every sum == Snowflake",
                  (e or {}).get("status") == "completed" and sums == [int(x) for x in ftruth],
                  {"status": (e or {}).get("status"), "file": sums, "truth": [int(x) for x in ftruth],
                   "bytes": size if path else None, "err": str((e or {}).get("error_message"))[:200]})
    finally:
        for p in undo:
            if isinstance(p, tuple):
                admin.call("PUT", "/api/admin/semantic-layer/config", {"max_columns_per_dataset": p[1]})
            else:
                admin.call("DELETE", p)
        con.close()
        print(f"\ncleanup: {len(undo)} QueryStudio objects removed (the Snowflake table is kept)")
    print("\nTIMINGS")
    for label, s, m in timings:
        print(f"  {label:34s} {s:8.1f}s   api mem {m}")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
