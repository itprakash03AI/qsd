@echo off
rem The owner's month-end daily re-send test (2026-10-13), run once a day by
rem Windows Task Scheduler ("QueryStudio month-end daily re-send") until the
rem October month end.  Needs Docker Desktop and the rig running.
rem Remove the schedule:  schtasks /Delete /TN "QueryStudio month-end daily re-send" /F
"C:\Program Files\Git\bin\bash.exe" -lc "cd /c/DEV/outputs && . ~/.qs_keys/rigpw.sh && . ~/.qs_keys/starburst_like.env && export MSYS_NO_PATHCONV=1 && /c/Python314/python scripts/docker_proof/month_end_journey.py daily >> /c/tmp/month_end_daily.log 2>&1"
