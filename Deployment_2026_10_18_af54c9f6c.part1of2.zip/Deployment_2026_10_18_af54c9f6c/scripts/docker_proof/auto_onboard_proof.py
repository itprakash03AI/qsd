"""A NEW system entity onboards itself -- LIVE on the Docker rig (2026-10-11).

The owner: "if a new system entity comes via a Kafka message which is
month-end business data, how will it be automated to set up config and create
the SOD task?" -- and "we also need a skip option per dependency for that
business date if the message does not come (holiday)".

One template for fact_tetb_ext built on the OWNER'S OWN queries (cloud on the
REAL AWS bucket through qs-trino, on-prem through the Starburst-shaped
qs-trino-sb; verbatim but the FROM), a month_end schedule on a business
calendar made through the product's calendar API, two dependencies (CLOUD and
ONPREM, each met by the Kafka topic OR a QS_KAFKA_MESSAGE row), and an
``auto_onboard`` declaration keyed on DATA_SOURCE.  Its matrix holds ONE
existing entity; the two entities below are NEW.

  O1  NEW_A's CLOUD message on the Kafka topic -> the request appears, the
      feed is created from the template, SOD makes its month-end task, and
      the run WAITS (ONPREM not met).
  O2  NEW_A's ONPREM message as an Oracle QS_KAFKA_MESSAGE row -> the SAME
      request (no second feed), the run is released, runs, and the SFTP file
      == cloud truth + on-prem truth BY VALUE (the owner's SQL on each Trino).
  O3  NEW_B: CLOUD message only (a holiday on-prem); the run WAITS; the
      operator SKIPS the ONPREM dependency for that business date with a
      reason -> released, runs, delivers the cloud rows.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/auto_onboard_proof.py [--keep]
    python scripts/docker_proof/auto_onboard_proof.py --sweep-leftovers [--execute]
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import io
import itertools
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import connections, pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, ORA_TABLE, SB_HOST, SB_PORT, SFTP, TABLES, TOPIC, cloud_cli, ddl,
    drop_schema_cascade, ensure_oracle_table, insert_rows, load_queries, message, ora_rows,
    parse_query, produce_kafka, row_values, sb_cli,
)

TAG = str(int(time.time()))[-6:]
SPEC = TABLES["ext"]
DS = SPEC["data_source"]                          # finance_sl_balance_ext
CLOUD_SCHEMA = f"iceberg_aws.ao_{TAG}"
CLOUD_TABLE = f"{CLOUD_SCHEMA}.fact_tetb_ext"
PREM_TABLE = f"iceberg.qs.fact_tetb_ext_ao{TAG}"
BD = dt.date(2026, 9, 30)                         # a month-end (Wednesday)
EVENT = "ME5"
OLD, NEW_A, NEW_B = f"O{TAG}", f"A{TAG}", f"B{TAG}"
NEW_C = f"C{TAG}"   # --keep: left WAITING on its ON-PREM side for the dashboard spec
CAL = f"AO_{TAG}"
ROWS = 4


def wait_for(fn, timeout=240, every=3):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(every)
    return None


def requests_for(r, entity):
    s, b = r.call("GET", "/api/feed-templates/onboarding")
    return [q for q in (b or {}).get("requests", []) if (q.get("values") or {}).get("SYSTEM_ENTITY") == entity]


def run_row(r, fid):
    s, b = r.call("GET", f"/api/feed-runs?business_date={BD.isoformat()}&limit=1000")
    items = b if isinstance(b, list) else (b or {}).get("items") or (b or {}).get("runs") or []
    return next((x for x in items if int(x.get("feed_config_id") or 0) == int(fid)), None)


def dashboard_task(r, group_name, feed_name):
    """The dashboard's answer for one task: (group, task, kpis), or None."""
    s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={group_name}&page_size=200")
    for g in (d or {}).get("groups") or []:
        for t in g.get("tasks") or []:
            if t.get("feed_name") == feed_name:
                return {"group": g["name"], "task": t, "kpis": d.get("kpis")}
    return None


def _drop_group(r, name):
    s, gs = r.call("GET", "/api/feed-groups")
    items = gs if isinstance(gs, list) else (gs or {}).get("items") or []
    g = next((x for x in items if x.get("name") == name), None)
    if g is None:
        return True, "absent"
    s, _ = r.call("DELETE", f"/api/feed-groups/{g['id']}?detach_feeds=true")
    return s in (200, 204), f"HTTP {s}"


def main(argv=None) -> int:
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--timeout", type=int, default=900)
    args = ap.parse_args(rest)
    r = Rig()
    if sweep:
        rules = [Rule("feed template", r"AO_EXT_\d{6}", list_path="/api/feed-templates",
                      delete_path="/api/feed-templates/{id}?delete_members=true"),
                 Rule("saved query", r"ao_(cloud|prem)_\d{6}", list_path="/api/queries", delete_path="/api/queries/{id}"),
                 Rule("connection", r"sb-onprem-ao-\d{6}", list_path="/api/connections", delete_path="/api/connections/{id}"),
                 # the Feed Groups the template's group rule created (OLD / NEW_A / NEW_B)
                 Rule("feed group", r"[OABC]\d{6}", list_path="/api/feed-groups",
                      delete_path="/api/feed-groups/{id}?detach_feeds=true")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for line in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'ao_%'").splitlines():
            s = line.strip().strip('"')
            if re.fullmatch(r"ao_\d{6}", s):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{s}")
                if execute:
                    print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{s}"))
        for line in cloud_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb_ext_ao%'").splitlines():
            t = line.strip().strip('"')
            if re.fullmatch(r"fact_tetb_ext_ao\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    cloud_cli(f"DROP TABLE iceberg.qs.{t}")
        return rc

    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    items = connections(r)
    cloud_id, _ = pick_cloud(r, "")
    ora_id = next((x["id"] for x in items if x.get("name") == "oracle-otg"), None)
    if not check("P0 connections: cloud Trino + oracle-otg (the QS_KAFKA_MESSAGE road)", cloud_id and ora_id,
                 (cloud_id, ora_id)):
        return 2
    # another template that auto-onboards this DATA_SOURCE makes every message
    # AMBIGUOUS -- the product refuses it (correctly); say so here, up front
    s, tl = r.call("GET", "/api/feed-templates")
    tl_items = tl if isinstance(tl, list) else (tl or {}).get("items") or (tl or {}).get("templates") or []
    others = [t.get("name") for t in tl_items
              if ((t.get("auto_onboard") or {}).get("match") or {}).get("DATA_SOURCE") == DS]
    if not check(f"P0 no other template auto-onboards DATA_SOURCE={DS} (else every message is ambiguous)",
                 not others, others or "none -- run --sweep-leftovers --execute to remove kept runs"):
        return 2
    ensure_oracle_table(ora_id)
    cloud_sql, prem_sql = load_queries(SPEC)
    cloud_sql = cloud_sql.replace(SPEC["from_cloud"], CLOUD_TABLE)
    prem_sql = prem_sql.replace(SPEC["from_onprem"], PREM_TABLE)
    _, c_types = parse_query(cloud_sql, SPEC["alias"])
    _, p_types = parse_query(prem_sql, SPEC["alias"])
    print(f"== AUTO-ONBOARD tag {TAG}: template on the owner's {SPEC['table']} queries "
          f"({len(c_types)} / {len(p_types)} columns), month-end {BD}, event {EVENT}; new entities {NEW_A}, {NEW_B}")
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    seq = itertools.count(int(TAG) * 10)
    try:
        # ── data: OLD + NEW_A both sides, NEW_B cloud only (on-prem holiday) ──
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/ao_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        cloud_cli(ddl(CLOUD_TABLE, c_types, hive=False) + ";\n", stdin=True)
        cloud_cli(ddl(PREM_TABLE, p_types, hive=False) + ";\n", stdin=True)
        ledger.add("on-prem table", PREM_TABLE,
                   remover=lambda: (bool(cloud_cli(f"DROP TABLE {PREM_TABLE}") is not None), "dropped"))
        c_rows = [row_values("cloud", c_types, BD, e, EVENT, i) for e in (OLD, NEW_A, NEW_B) for i in range(ROWS)]
        p_rows = [row_values("prem", p_types, BD, e, EVENT, i) for e in (OLD, NEW_A) for i in range(ROWS + 1)]
        insert_rows(cloud_cli, CLOUD_TABLE, c_types, c_rows)
        insert_rows(cloud_cli, PREM_TABLE, p_types, p_rows)

        def truth(side, ent):
            sql = (cloud_sql if side == "cloud" else prem_sql).replace("{BUSINESSDATE}", BD.isoformat()) \
                .replace("{SYSTEM_ENTITY}", ent).replace("{EventCode}", EVENT)
            cli = cloud_cli if side == "cloud" else sb_cli
            out = cli(f"SELECT source_data_row FROM ({sql}) q;\n", stdin=True)
            return collections.Counter(x.strip().strip('"') for x in out.splitlines() if x.strip())
        want = {(s, e): truth(s, e) for s in ("cloud", "prem") for e in (NEW_A, NEW_B)}
        check("S0 seeded: NEW_A has rows on both sides, NEW_B on cloud only (the owner's SQL on each Trino)",
              sum(want[("cloud", NEW_A)].values()) == ROWS and sum(want[("prem", NEW_A)].values()) == ROWS + 1
              and sum(want[("cloud", NEW_B)].values()) == ROWS and not want[("prem", NEW_B)],
              {k: sum(v.values()) for k, v in want.items()})

        # ── the on-prem connection, saved queries, calendar, template ─────
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-ao-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False, "catalog": "iceberg", "schema": "qs"}})
        prem_id = (b or {}).get("id")
        ledger.add("connection", f"sb-onprem-ao-{TAG}", path=f"/api/connections/{prem_id}")
        q = {}
        for side, cid, sql in (("cloud", cloud_id, cloud_sql), ("prem", prem_id, prem_sql)):
            s, qq = r.call("POST", "/api/queries", {"name": f"ao_{side}_{TAG}",
                                                   "query_config": {"files": [], "raw_sql": sql, "connection_id": cid}})
            q[side] = (qq or {}).get("id")
            ledger.add("saved query", f"ao_{side}_{TAG}", path=f"/api/queries/{q[side]}")
        s, cal = r.call("POST", "/api/admin/feed-calendars", {"name": CAL, "weekend_days": [6, 7], "holidays": []})
        check(f"P1 business calendar {CAL} created through the product's calendar API", s in (200, 201), (s, str(cal)[:200]))
        both_roads = [{"kind": "kafka", "topic": TOPIC},
                      {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
        template = {
            "name": f"AO_EXT_{TAG}", "parameters": ["SYSTEM_ENTITY", "EventCode"],
            "feed": {"name": f"AO_EXT_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}",
                     "source_type": "saved_query", "source_id": q["cloud"], "connection_id": cloud_id,
                     "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
                     "secondary_source_id": q["prem"], "combine_mode": "union", "output_format": "csv",
                     "output_filename_template": f"AO_EXT_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}_{{business_date:YYYYMMDD}}.csv",
                     "destination_type": "sftp",
                     "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                            "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                            "host_key_b64": sftp_host_key()},
                     "schedule_declaration": {"kind": "month_end", "calendar_name": CAL}, "calendar_name": CAL,
                     "execution_backend": "native", "notify_on_failure": False,
                     # 2026-10-12 (owner R1) -- the GROUP RULE: every member,
                     # auto-onboarded ones included, joins its entity's Feed Group
                     "feed_group_name": "{SYSTEM_ENTITY}"},
            "dependencies": [
                {"dependency_type": "KAFKA", "dependency_key": f"{DS}_{{SYSTEM_ENTITY}}_{{EventCode}}_{side}",
                 "arrival_sources": both_roads, "require_mode": "any"} for side in ("CLOUD", "ONPREM")],
            "matrix": [{"SYSTEM_ENTITY": OLD, "EventCode": EVENT}],
            "auto_onboard": {"match": {"DATA_SOURCE": DS},
                             "params": {"SYSTEM_ENTITY": "CODE", "EventCode": "BUSINESS_EVENT"}},
        }
        s, body = r.call("POST", "/api/feed-templates", template)
        tid = ((body or {}).get("template") or {}).get("id")
        if not check("P2 template created with auto_onboard (DATA_SOURCE -> this template), 1 existing member",
                     s == 201 and tid and (body["template"].get("auto_onboard") or {}).get("match") == {"DATA_SOURCE": DS},
                     (s, str(body)[:400])):
            return 1
        ledger.add("feed template", template["name"], path=f"/api/feed-templates/{tid}?delete_members=true")
        for ent in (OLD, NEW_A, NEW_B):
            ledger.add("feed group", ent, remover=lambda ent=ent: _drop_group(r, ent))
        ledger.add("calendar", CAL, path=f"/api/admin/feed-calendars/{CAL}")

        # ── O1: NEW_A's CLOUD message on Kafka -> feed + task, WAITING ────
        produce_kafka([message(DS, NEW_A, EVENT, BD, True, "COMPLETE", ROWS, next(seq))])
        req = wait_for(lambda: [x for x in requests_for(r, NEW_A) if x["status"] != "pending"] or None)
        req = (req or requests_for(r, NEW_A) or [{}])[0]
        check(f"O1 NEW_A's CLOUD Kafka message -> onboarded from template AO_EXT_{TAG}: feed {req.get('feed_config_id')}, "
              f"SOD for {BD}: {req.get('run')}",
              req.get("status") == "onboarded" and req.get("feed_config_id") and req.get("run") == "created", req)
        fid_a = req.get("feed_config_id")
        if fid_a:
            s, f = r.call("GET", f"/api/feeds/{fid_a}")
            check("O1 the new feed is the template's member, same query / calendar / dependencies",
                  s == 200 and f.get("template_id") == tid and f.get("source_id") == q["cloud"]
                  and f.get("calendar_name") == CAL, {k: f.get(k) for k in ("name", "template_id", "source_id", "calendar_name")})
            run = wait_for(lambda: run_row(r, fid_a), 60)
            check("O1 its month-end task exists and WAITS (ONPREM not arrived)",
                  run and run.get("action_decision") == "WAIT" and run.get("status") == "pending",
                  {k: (run or {}).get(k) for k in ("status", "action_decision", "action_reason")})

        # ── G1: the dashboard groups NEW_A's task under its OWN Feed Group ──
        dash = dashboard_task(r, NEW_A, f"AO_EXT_{TAG}_{NEW_A}_{EVENT}")
        check(f"G1 the dashboard lists NEW_A's task under Feed Group {NEW_A} (created by the template's rule), NOT STARTED",
              dash and dash["group"] == NEW_A and dash["task"]["status"] == "not_started",
              dash and {"group": dash["group"], "status": dash["task"]["status"], "kpis": dash["kpis"]})
        if dash:
            s, det = r.call("GET", f"/api/feed-dashboard/task?feed_id={fid_a}&business_date={BD.isoformat()}")
            sides = {c["side"]: c for c in (det or {}).get("dependencies") or []}
            cl, op = sides.get("CLOUD") or {}, sides.get("ON-PREM") or {}
            check("G1 its cards: CLOUD arrived with the Kafka message's fields, ON-PREM WAITING",
                  cl.get("satisfies") and (cl.get("messages") or [{}])[-1].get("fields", {}).get("CODE") == NEW_A
                  and op and not op.get("satisfies"),
                  {"cloud": (cl.get("verdict"), len(cl.get("messages") or [])),
                   "onprem": (op.get("verdict"), op.get("reason"))})

        # ── O2: NEW_A's ONPREM message as an Oracle row -> released, delivered ─
        ora_rows(ora_id, [message(DS, NEW_A, EVENT, BD, False, "COMPLETE", ROWS + 1, next(seq))])
        def done(fid):
            def _f():
                rr = run_row(r, fid)
                return rr if rr and rr.get("status") in ("completed", "failed", "skipped", "cancelled") else None
            return _f
        run = wait_for(done(fid_a), args.timeout, 5) if fid_a else None
        check("O2 NEW_A's ONPREM Oracle row -> the SAME request (no second feed), the run released and COMPLETED",
              run and run.get("status") == "completed" and len(requests_for(r, NEW_A)) == 1,
              {"run": {k: (run or {}).get(k) for k in ("status", "error")}, "requests": len(requests_for(r, NEW_A))})
        fname = f"AO_EXT_{TAG}_{NEW_A}_{EVENT}_{BD:%Y%m%d}.csv"
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fname}"],
                              capture_output=True, text=True, env=DENV).stdout
        got = collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                  for rec in csv.DictReader(io.StringIO(text.lstrip("﻿"))))
        exp = want[("cloud", NEW_A)] + want[("prem", NEW_A)]
        check(f"O2 the SFTP file {fname} == cloud truth + on-prem truth BY VALUE ({sum(exp.values())} rows)",
              got == exp and sum(exp.values()) > 0, {"got": sum(got.values()), "want": sum(exp.values())})

        # ── O3: NEW_B: CLOUD only; the operator SKIPS ONPREM for the date ──
        produce_kafka([message(DS, NEW_B, EVENT, BD, True, "COMPLETE", ROWS, next(seq))])
        req_b = wait_for(lambda: [x for x in requests_for(r, NEW_B) if x["status"] != "pending"] or None)
        req_b = (req_b or requests_for(r, NEW_B) or [{}])[0]
        fid_b = req_b.get("feed_config_id")
        run = wait_for(lambda: run_row(r, fid_b), 60) if fid_b else None
        check("O3 NEW_B onboarded from its CLOUD message; its task WAITS on ONPREM (no on-prem load: a holiday)",
              req_b.get("status") == "onboarded" and run and run.get("action_decision") == "WAIT",
              {"request": req_b.get("status"), "run": {k: (run or {}).get(k) for k in ("status", "action_decision")}})
        key = f"{DS}_{NEW_B}_{EVENT}_ONPREM"
        s, sk = r.call("POST", f"/api/feed-dependencies/{key}/skip", {
            "business_date": BD.isoformat(), "reason_category": "upstream_holiday",
            "reason": "on-prem load not published for this month end, holiday upstream"})
        check(f"O3 SKIP {key} for {BD} (reason: upstream holiday)", s in (200, 201), (s, str(sk)[:300]))
        run = wait_for(done(fid_b), args.timeout, 5) if fid_b else None
        fname_b = f"AO_EXT_{TAG}_{NEW_B}_{EVENT}_{BD:%Y%m%d}.csv"
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fname_b}"],
                              capture_output=True, text=True, env=DENV).stdout
        got_b = collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                    for rec in csv.DictReader(io.StringIO(text.lstrip("﻿"))))
        check(f"O3 released by the skip, COMPLETED, the file carries NEW_B's cloud rows ({sum(want[('cloud', NEW_B)].values())})",
              run and run.get("status") == "completed" and got_b == want[("cloud", NEW_B)],
              {"run": {k: (run or {}).get(k) for k in ("status", "error")}, "got": sum(got_b.values())})
        dash_b = dashboard_task(r, NEW_B, f"AO_EXT_{TAG}_{NEW_B}_{EVENT}")
        dash_a = dashboard_task(r, NEW_A, f"AO_EXT_{TAG}_{NEW_A}_{EVENT}")
        check("G2 after the run: NEW_A COMPLETED under group NEW_A, NEW_B COMPLETED under its own group NEW_B",
              dash_a and dash_a["task"]["status"] == "completed" and dash_b and dash_b["group"] == NEW_B
              and dash_b["task"]["status"] == "completed",
              {"a": dash_a and (dash_a["group"], dash_a["task"]["status"]),
               "b": dash_b and (dash_b["group"], dash_b["task"]["status"])})
        for n in (fname, fname_b):
            ledger.add("sftp file", n, remover=lambda n=n: (subprocess.run(
                ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{n}"], env=DENV).returncode == 0, "rm"))
        if args.keep:
            # NEW_C: its CLOUD message only -> onboarded, its task WAITS on
            # ONPREM; frontend/e2e/docker-feed-dashboard.spec.ts skips it BY CLICKS
            produce_kafka([message(DS, NEW_C, EVENT, BD, True, "COMPLETE", 0, next(seq))])
            req_c = wait_for(lambda: [x for x in requests_for(r, NEW_C) if x["status"] != "pending"] or None)
            req_c = (req_c or [{}])[0]
            run_c = wait_for(lambda: run_row(r, req_c.get("feed_config_id")), 60) if req_c.get("feed_config_id") else None
            check(f"G3 NEW_C left WAITING on ONPREM under group {NEW_C} for the by-clicks spec",
                  run_c and run_c.get("action_decision") == "WAIT"
                  and (dashboard_task(r, NEW_C, f"AO_EXT_{TAG}_{NEW_C}_{EVENT}") or {}).get("group") == NEW_C,
                  {"request": req_c.get("status"), "run": run_c})
            print(f"LEFT_WAITING group={NEW_C} feed=AO_EXT_{TAG}_{NEW_C}_{EVENT} date={BD}", flush=True)
    finally:
        if args.keep:
            print(f"\n== KEPT (tag {TAG}): template AO_EXT_{TAG}, feeds AO_EXT_{TAG}_*; --sweep-leftovers --execute removes")
        else:
            print("\n== cleanup")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
