"""What a proof harness created, it removes -- and it says so, by count.

2026-09-26: GET /api/connections on the rig listed ~24 ``cap-*-<runid>``
connections (local, starburst, rest_api, fvlocal) from repeated
``capability_exercise.py`` runs, plus the saved queries, datasets, local
tables, feeds and reports those runs made.  A person opening the
Connections screen saw test clutter.  Every harness under this directory now
records each object it creates in a :class:`Ledger` the moment the create
succeeds and removes them all in a ``finally`` -- on success, on a failed
check, on a crash -- reporting ONE line::

    cleanup: N objects removed, M could not be (<label>: <reason>; ...)

and the harness exits non-zero when M > 0.  A cleanup that fails silently is
how the clutter got there.

Leftovers from runs that predate this (or that were killed before their
``finally``) are handled by an opt-in sweep::

    python capability_exercise.py --sweep-leftovers            # dry run
    python capability_exercise.py --sweep-leftovers --execute  # delete

The sweep's matching rule is deliberately narrow: an object is a candidate
ONLY when its name matches one of the harness's OWN name templates with the
run-id shape in place of the tag (:data:`RUN_ID` -- the last six digits of
the epoch second the run started, so ``\\d{6}``), anchored at both ends.  A
connection called ``cap-local-prod`` or ``cap-local-12345`` never matches;
``cap-local-123456`` does.  Nothing outside the rule is ever listed, let
alone deleted, and the dry run is the default.
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

#: The run-id shape every harness uses: ``str(int(time.time()))[-6:]``.
RUN_ID = r"\d{6}"

# A call returns (status, body) or (status, body, headers); only the first
# two matter here.
Call = Callable[..., Sequence[Any]]


def _status_body(result: Sequence[Any]) -> Tuple[int, Any]:
    try:
        return int(result[0]), result[1]
    except Exception:                                        # noqa: BLE001
        return -1, result


def rows_of(body: Any) -> List[Dict[str, Any]]:
    """The list of records in a list-route body, whatever envelope the
    route uses: a bare list, or a dict whose first list-of-dicts value is
    the collection (``items`` / ``policies`` / ``connections`` ...)."""
    if isinstance(body, list):
        return [r for r in body if isinstance(r, dict)]
    if isinstance(body, dict):
        for key in ("items", "data", "rows", "results"):
            v = body.get(key)
            if isinstance(v, list):
                return [r for r in v if isinstance(r, dict)]
        for v in body.values():
            if isinstance(v, list) and v and all(isinstance(r, dict) for r in v):
                return v
    return []


# ── the ledger ─────────────────────────────────────────────────────────


class Ledger:
    """Every object a run created, in creation order; removed in reverse.

    ``add`` records an HTTP-removable object (``method`` + ``path``) or one
    with its own ``remover`` callable returning ``(ok, reason)`` -- a
    container file, an Oracle table.  ``forget`` drops an entry the script
    removed itself mid-run, so the final pass does not report it missing.
    """

    def __init__(self, call: Call, *, ok_statuses: Iterable[int] = (200, 202, 204)):
        self._call = call
        self._ok = set(ok_statuses)
        self.items: List[Dict[str, Any]] = []
        self.report: Optional[Tuple[int, List[str]]] = None

    def add(self, kind: str, label: str, *, path: Optional[str] = None,
            method: str = "DELETE",
            remover: Optional[Callable[[], Tuple[bool, str]]] = None,
            key: Any = None) -> None:
        if path is None and remover is None:
            raise ValueError(f"{kind} {label!r}: a path or a remover is required")
        self.items.append({"kind": kind, "label": label, "path": path,
                           "method": method, "remover": remover,
                           "key": key if key is not None else path})

    def forget(self, key: Any) -> None:
        self.items = [it for it in self.items if it["key"] != key]

    def __len__(self) -> int:
        return len(self.items)

    def cleanup(self, echo: Callable[[str], None] = print) -> Tuple[int, List[str]]:
        """Remove everything, newest first.  Returns ``(removed, failures)``
        and prints the one-line report.  Never raises: a remover that
        raises is a failure with the exception as its reason."""
        removed, failures = 0, []
        for it in reversed(self.items):
            what = f"{it['kind']} {it['label']}"
            try:
                if it["remover"] is not None:
                    ok, reason = it["remover"]()
                else:
                    status, body = _status_body(self._call(it["method"], it["path"]))
                    ok = status in self._ok
                    reason = f"HTTP {status}: {str(body)[:120]}"
            except Exception as exc:                          # noqa: BLE001
                ok, reason = False, f"{type(exc).__name__}: {exc}"
            if ok:
                removed += 1
            else:
                failures.append(f"{what}: {reason}")
        self.report = (removed, failures)
        echo(format_report(removed, failures))
        return removed, failures


def format_report(removed: int, failures: List[str]) -> str:
    if failures:
        return (f"cleanup: {removed} objects removed, {len(failures)} could "
                f"not be ({'; '.join(failures)})")
    return f"cleanup: {removed} objects removed, 0 could not be"


# ── the sweep ──────────────────────────────────────────────────────────


class Rule:
    """One kind of leftover: how to LIST candidates and how to REMOVE one.

    ``pattern`` is anchored (``fullmatch``) against the record's name.  For
    HTTP kinds give ``list_path`` + ``delete_path`` (``{id}`` is filled in);
    for anything else give ``lister()`` -> ``[(id, name), ...]`` and
    ``remover(id)`` -> ``(ok, reason)``.
    """

    def __init__(self, kind: str, pattern: str, *,
                 list_path: Optional[str] = None,
                 delete_path: Optional[str] = None,
                 delete_method: str = "DELETE",
                 name_key: str = "name", id_key: str = "id",
                 where: Optional[Callable[[Dict[str, Any]], bool]] = None,
                 lister: Optional[Callable[[], List[Tuple[Any, str]]]] = None,
                 remover: Optional[Callable[[Any], Tuple[bool, str]]] = None):
        self.kind = kind
        self.pattern = re.compile(pattern)
        self.list_path = list_path
        self.delete_path = delete_path
        self.delete_method = delete_method
        self.name_key = name_key
        self.id_key = id_key
        #: extra row predicate for HTTP kinds (e.g. skip an already
        #: archived dataflow, which the list route still returns).
        self.where = where
        self.lister = lister
        self.remover = remover
        if (list_path is None) == (lister is None):
            raise ValueError(f"rule {kind}: exactly one of list_path / lister")
        if (delete_path is None) == (remover is None):
            raise ValueError(f"rule {kind}: exactly one of delete_path / remover")

    def matches(self, name: Any) -> bool:
        return isinstance(name, str) and self.pattern.fullmatch(name) is not None


def sweep_leftovers(call: Call, rules: Sequence[Rule], *, execute: bool = False,
                    ok_statuses: Iterable[int] = (200, 202, 204),
                    echo: Callable[[str], None] = print) -> int:
    """List every rule's candidates; delete them only with ``execute``.

    Exit code: 0 when every listing succeeded and (in execute mode) every
    delete succeeded; 1 when a delete failed; 2 when a listing could not be
    read -- a sweep that cannot see a kind must not report it clean.
    """
    ok_set = set(ok_statuses)
    mode = "EXECUTE" if execute else "DRY RUN (pass --execute to delete)"
    echo(f"sweep-leftovers [{mode}]: {len(rules)} kinds, match = own name "
         f"template + run id {RUN_ID}")
    unreadable: List[str] = []
    failures: List[str] = []
    found = deleted = 0
    for rule in rules:
        try:
            if rule.lister is not None:
                candidates = [(i, n) for i, n in rule.lister() if rule.matches(n)]
            else:
                status, body = _status_body(call("GET", rule.list_path))
                if status not in ok_set:
                    unreadable.append(f"{rule.kind}: GET {rule.list_path} -> HTTP {status}")
                    continue
                candidates = [(r.get(rule.id_key), r.get(rule.name_key))
                              for r in rows_of(body)
                              if rule.matches(r.get(rule.name_key))
                              and (rule.where is None or rule.where(r))]
        except Exception as exc:                              # noqa: BLE001
            unreadable.append(f"{rule.kind}: {type(exc).__name__}: {exc}")
            continue
        for ident, name in candidates:
            found += 1
            if not execute:
                echo(f"  would delete {rule.kind} {ident} {name!r}")
                continue
            try:
                if rule.remover is not None:
                    ok, reason = rule.remover(ident)
                else:
                    status, body = _status_body(call(
                        rule.delete_method, rule.delete_path.format(id=ident)))
                    ok = status in ok_set
                    reason = f"HTTP {status}: {str(body)[:120]}"
            except Exception as exc:                          # noqa: BLE001
                ok, reason = False, f"{type(exc).__name__}: {exc}"
            if ok:
                deleted += 1
                echo(f"  deleted {rule.kind} {ident} {name!r}")
            else:
                failures.append(f"{rule.kind} {ident} {name!r}: {reason}")
                echo(f"  FAILED  {rule.kind} {ident} {name!r} -- {reason}")
    if execute:
        echo(f"sweep-leftovers: {found} matched, {deleted} deleted, "
             f"{len(failures)} failed, {len(unreadable)} kinds unreadable")
    else:
        echo(f"sweep-leftovers: {found} would be deleted, "
             f"{len(unreadable)} kinds unreadable")
    for u in unreadable:
        echo(f"  UNREADABLE {u}")
    if unreadable:
        return 2
    return 1 if failures else 0


def sweep_flags(argv: Sequence[str]) -> Tuple[bool, bool, List[str]]:
    """``(sweep_requested, execute, remaining_argv)`` from a harness's argv."""
    args = list(argv)
    sweep = "--sweep-leftovers" in args
    execute = "--execute" in args
    rest = [a for a in args if a not in ("--sweep-leftovers", "--execute")]
    return sweep, execute, rest


# ── rig housekeeping the harnesses share ───────────────────────────────


def container_rm(container: str, path: str) -> Tuple[bool, str]:
    """``rm -rf <path>`` inside a container -- the remover for files a
    harness placed there.  MSYS_NO_PATHCONV keeps Git Bash from rewriting
    /app/... into a Windows path."""
    import os
    import subprocess
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    p = subprocess.run(["docker", "exec", container, "rm", "-rf", path],
                       capture_output=True, env=env)
    return p.returncode == 0, p.stderr.decode("utf-8", "replace")[:160]


def container_find(container: str, root: str, maxdepth: int = 1) -> List[str]:
    """Paths under ``root`` inside a container (``find``), for a sweep's
    lister.  An absent root is an empty list, not an error."""
    import os
    import subprocess
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    p = subprocess.run(["docker", "exec", container, "sh", "-c",
                        f"[ -e '{root}' ] && find '{root}' -mindepth 1 "
                        f"-maxdepth {int(maxdepth)} || true"],
                       capture_output=True, env=env)
    return [ln.strip() for ln in p.stdout.decode("utf-8", "replace").splitlines()
            if ln.strip()]


_ORA_ADMIN = '''
import json, os, sys
sys.path.insert(0, "/app")
from core.database import get_db_manager
from core.crypto import decrypt_config
from sqlalchemy import text
import oracledb

with get_db_manager().get_session() as s:
    raw = s.execute(text("select config from connections where id=%d")).scalar()
cfg = decrypt_config(json.loads(raw) if isinstance(raw, str) else dict(raw))
conn = oracledb.connect(user=cfg["user"], password=cfg["password"],
                        dsn="oracle-db:%%s/%%s" %% (cfg.get("port", 1521),
                                                   cfg.get("service_name", "freepdb1")))
cur = conn.cursor()
for sql in json.loads(os.environ["QS_ORA_SQL"]):
    try:
        cur.execute(sql)
        if cur.description:
            for row in cur:
                print(" | ".join("" if v is None else str(v) for v in row))
        else:
            conn.commit()
            print("ok: " + sql[:60])
    except Exception as e:
        print("ERROR: " + str(e).splitlines()[0])
'''


def oracle_admin(statements: Sequence[str], *, container: str = "qs-local-api",
                 connection_id: int = 3) -> str:
    """DDL / catalog reads through the api container's own oracle client.

    /api/sql/execute is a query path; dropping a table and reading
    USER_TABLES is rig housekeeping, not part of what is under test.  The
    script goes in on STDIN so this carries no state on the container -- a
    restart must not quietly turn a check into a no-op.  Connection 3 is the
    in-network oracle-otg record (fb59_acceptance's convention)."""
    import json
    import os
    import subprocess
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    p = subprocess.run(["docker", "exec", "-i",
                        "-e", "QS_ORA_SQL=" + json.dumps(list(statements)),
                        container, "python", "-"],
                       input=(_ORA_ADMIN % int(connection_id)).encode(),
                       capture_output=True, env=env)
    return p.stdout.decode("utf-8", "replace") + p.stderr.decode("utf-8", "replace")


def oracle_table_remover(qualified: str, **kw) -> Callable[[], Tuple[bool, str]]:
    """A ledger remover that drops ``OWNER.TABLE`` and proves it is gone."""
    owner, _, table = qualified.partition(".")

    def _drop() -> Tuple[bool, str]:
        out = oracle_admin([f"DROP TABLE {qualified} PURGE",
                            "SELECT table_name FROM user_tables WHERE "
                            f"table_name = '{table}'"], **kw)
        gone = table not in out.replace(f"DROP TABLE {qualified}", "")
        return gone, out.strip().splitlines()[-1][:160] if out.strip() else "no output"
    return _drop


def oracle_tables_like(prefix: str, **kw) -> List[Tuple[str, str]]:
    """``[(name, name), ...]`` of the caller's tables whose name starts with
    ``prefix`` -- a sweep lister; the rule's pattern does the real match."""
    out = oracle_admin(["SELECT table_name FROM user_tables WHERE table_name "
                        f"LIKE '{prefix}%' ORDER BY table_name"], **kw)
    names = [ln.strip() for ln in out.splitlines()
             if ln.strip() and not ln.startswith(("ok:", "ERROR:"))]
    return [(n, n) for n in names]


__all__ = ["Ledger", "Rule", "RUN_ID", "container_find", "container_rm",
           "format_report", "oracle_admin", "oracle_table_remover",
           "oracle_tables_like", "rows_of", "sweep_flags", "sweep_leftovers"]
