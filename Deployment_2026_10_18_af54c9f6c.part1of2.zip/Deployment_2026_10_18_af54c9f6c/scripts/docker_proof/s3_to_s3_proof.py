"""The owner's ONE-TABLE shared query, read straight from AWS S3 by
QueryStudio's S3 engine, the file written straight to the SAME bucket
(2026-10-14: "if we create the file directly on S3 then?  the shared query
is on just 1 table").

Two feeds on the month-end partition of fact_tetb (460 columns): plain CSV
and gzip CSV.  Each run's stage times come from the execution record
(files_metadata.stage_history); the file is checked INSIDE the worker against
Trino's own count of the same Iceberg table (rows, distinct SOURCE_DATA_ROW),
and the S3 object's size was verified by the run itself (HEAD after upload).

    python s3_to_s3_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from tetb_real_e2e_proof import AWS_BUCKET, cloud_cli           # noqa: E402
import month_end_journey as mj                                  # noqa: E402

ALL_FEEDS = {"FACT_TETB_ONE_TABLE_S3_TO_S3": None, "FACT_TETB_ONE_TABLE_S3_TO_S3_GZ": "gzip"}
#: --only NAME runs one of them
FEEDS = ({k: v for k, v in ALL_FEEDS.items() if k == sys.argv[sys.argv.index("--only") + 1]}
         if "--only" in sys.argv else ALL_FEEDS)
OUT = {"checks": [], "runs": []}


def check(name, ok, detail=""):
    OUT["checks"].append({"check": name, "ok": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


def one_table_sql(table: str) -> str:
    c_sql, _ = mj.load_queries(mj.SPEC)
    c_sql = c_sql.replace(mj.SPEC["from_cloud"], table)
    return (c_sql.replace("{BUSINESSDATE}", mj.BD.isoformat())
                 .replace("{SYSTEM_ENTITY}", mj.ENTITY).replace("{EventCode}", mj.EVENT))


INSPECT = r'''
import csv, gzip, json, sys
path = sys.argv[1]
op = gzip.open if path.endswith(".gz") else open
csv.field_size_limit(1 << 30)
n = 0; ids = set()
with op(path, "rt", newline="", encoding="utf-8-sig") as f:
    rd = csv.reader(f)
    head = [c.strip().upper() for c in next(rd)]
    ri = head.index("SOURCE_DATA_ROW")
    for row in rd:
        n += 1; ids.add(row[ri])
import os
print(json.dumps({"rows": n, "distinct": len(ids), "bytes": os.path.getsize(path)}))
'''


def main():
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    s3 = next(c for c in conns if c["name"] == mj.S3_CONN_NAME)
    sql = one_table_sql(mj.S3_TABLE)
    truth = int(cloud_cli("SELECT count(*) FROM (" + one_table_sql(mj.CLOUD_TABLE) + ") t")
                .strip().strip('"'))
    check("Trino's own count of the same Iceberg table is non-zero", truth > 0, f"{truth:,} rows")
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    for name, codec in FEEDS.items():
        body = {"name": name, "source_type": "raw_sql", "source_id": 0, "connection_id": s3["id"],
                "query_params": {"sql": sql}, "output_format": "csv",
                "output_options": ({"compression": codec} if codec else {}),
                "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
                "destination_type": "s3",
                "destination_config": {"connection_id": s3["id"], "bucket": AWS_BUCKET,
                                       "prefix": "qs-feed-proof/"},
                "execution_backend": "native", "is_active": True, "schedule_enabled": False,
                "description": "Proof: the one-table fact_tetb query, read from AWS S3, "
                               "written to AWS S3" + (" (gzip)" if codec else "")}
        f = next((x for x in feeds if x["name"] == name), None)
        if f:
            s, b = r.call("PUT", f"/api/feeds/{f['id']}", body)
            fid = f["id"]
        else:
            s, b = r.call("POST", "/api/feeds", body)
            fid = (b or {}).get("id")
        assert s in (200, 201), (name, s, str(b)[:400])
        before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
        run = r.run_row(fid, mj.BD.isoformat())
        if run is None:
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {
                "start_date": mj.BD.isoformat(), "end_date": mj.BD.isoformat(), "deliver": True,
                "reason": "S3 -> S3 timing (test data only)"})
        else:
            s, b = r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": "S3 -> S3 timing"})
        assert s in (200, 201, 202), (s, str(b)[:300])
        t0 = time.time()
        while time.time() - t0 < 3600:
            row = psql(f"select id, status from feed_executions where feed_config_id={fid} "
                       f"and id>{before} order by id desc limit 1")
            if row and row.split("|")[1] in ("completed", "failed", "cancelled"):
                break
            time.sleep(10)
        eid, status = row.split("|")
        fm = json.loads(psql(f"select files_metadata from feed_executions where id={eid}") or "{}")
        stages = {s_["stage"]: s_.get("duration_seconds")
                  for s_ in (fm.get("stage_history") or {}).get("stages") or []}
        err = psql(f"select coalesce(error_message,'') from feed_executions where id={eid}")
        dest = psql(f"select coalesce(destination_path,'') from feed_executions where id={eid}")
        art = psql(f"select coalesce(artifact_path,'') from feed_executions where id={eid}")
        dur = psql(f"select coalesce(duration_seconds,0) from feed_executions where id={eid}")
        res = {"feed": name, "status": status, "seconds": float(dur or 0), "stages": stages,
               "destination": dest, "error": err[:300]}
        check(f"{name} completed", status == "completed", status + (f": {err[:200]}" if err else ""))
        if status == "completed":
            out = subprocess.run(["docker", "exec", "-i", "qs-local-scheduler", "python", "-", art],
                                 input=INSPECT, capture_output=True, text=True, timeout=1800)
            got = json.loads(out.stdout.strip().splitlines()[-1]) if out.returncode == 0 else {}
            res.update(got)
            check(f"{name}: rows == Trino", got.get("rows") == truth, f"{got.get('rows')} vs {truth}")
            check(f"{name}: no duplicate, none missing", got.get("distinct") == got.get("rows") == truth)
            check(f"{name}: written to S3", dest.startswith("s3://"), dest)
        OUT["runs"].append(res)
        # 2026-10-18: the feed stays INACTIVE between proofs -- start of day creates a run
        # for every ACTIVE feed (schedule_enabled is only the old cron), so a left-active
        # proof feed re-read the real AWS table every day (~7 min each) and held both of a
        # pod's slots while the next proof's run waited; the next run of this proof
        # re-activates it above.
        s_off, b_off = r.call("PUT", f"/api/feeds/{fid}", {**body, "is_active": False})
        check(f"{name} left inactive after the proof", s_off == 200, (s_off, str(b_off)[:200]))
        print(json.dumps(res), flush=True)
    path = os.path.join(HERE, "s3-to-s3-results.json")
    json.dump(OUT, open(path, "w", encoding="utf-8"), indent=1)
    bad = [c for c in OUT["checks"] if not c["ok"]]
    print(f"\n{len(OUT['checks']) - len(bad)}/{len(OUT['checks'])} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
