"""WHERE A RUNNING FEED IS, proven live (2026-10-14).

The owner, an hour into a 40M-row pod run: "we don't know where it is ...
nothing on the UI ... why can't we have logs on the UI or websocket".  One
Spark feed (the proof's own ~18M-row table, built once on the rig's Trino; read
through the read plan) runs on the rig's pods while this harness watches it
as a user would -- through the API and a browser WebSocket, never kubectl:

  P1  the execution carries a progress record WHILE it runs, and it MOVES:
      several reports, Spark's own task counters, the render phase
  P2  the run-log view says ``live`` for the Spark run
  P3  the WebSocket (identified as rig_admin, the feed's owner) receives
      feed_progress events carrying the counters AND feed_run_log lines
      from the job (PHASE / PROGRESS), for THIS execution
  P4  after: the stored log holds the job's story (PHASE read ... deliver,
      PROGRESS lines); the last record says the run finished
  P5  the file: total_rows == Trino's own count of the rows the query keeps

    python run_progress_proof.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import subprocess
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402
from monthly_kafka_merge_feeds_proof import sftp_host_key       # noqa: E402
from tetb_real_e2e_proof import SFTP                            # noqa: E402

NAME = "RP_POD_PROGRESS"
#: a fresh business date makes a fresh run, pinned to the CURRENT definition (a re-run of
#: an existing run executes the definition it was created with)
BD = os.environ.get("QS_PROOF_BD", "2026-09-30")
#: The table the run reads (2026-10-16).  It was the 40M volume table, which only
#: a hand-kept rig had (built from another proof's leftovers): a rig built from
#: scratch failed P1-P5 on "not a table registered".  The proof now BUILDS its own
#: long-running table once, on the rig's Trino (Iceberg on MinIO): TPC-H sf3
#: lineitem (~18M rows) under the code the query keeps, plus a decoy partition the
#: WHERE must drop; QS_PROGRESS_TABLE names another registered table instead.
REG = os.environ.get("QS_PROGRESS_TABLE", "rp_progress")
TRINO_TABLE = "iceberg.qs.rp_progress"
SQL = f"SELECT * FROM {REG} WHERE code = 'SAP-2920-EMEA' AND snap_version = 1"
WANT_ROWS = None                     # Trino's own count of what SQL keeps (ensure_table)


def _trino(sql: str) -> str:
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True)
    if out.returncode != 0:
        raise RuntimeError(f"qs-trino: {out.stderr.strip()[-300:]} -- {sql[:160]}")
    return out.stdout.strip()


def ensure_table(r, minio) -> int:
    """The table registered on minio-rig, and the row count the run must deliver."""
    s, _ = r.call("GET", f"/api/connections/{minio['id']}/tables/{REG}/schema")   # 200 = registered
    if REG == "rp_progress":
        if "rp_progress" not in _trino("SHOW TABLES FROM iceberg.qs").split():
            t0 = time.time()
            _trino(f"CREATE TABLE {TRINO_TABLE} WITH (format = 'PARQUET', partitioning = ARRAY['code']) AS "
                   "SELECT 'SAP-2920-EMEA' AS code, CAST(1 AS BIGINT) AS snap_version, l.* FROM tpch.sf3.lineitem l "
                   "UNION ALL SELECT 'DECOY-RP' AS code, CAST(99 AS BIGINT) AS snap_version, l.* FROM tpch.tiny.lineitem l")
            print(f"   built {TRINO_TABLE} ({round(time.time() - t0)} s)", flush=True)
        if s != 200:
            loc = [ln for ln in _trino(f"SHOW CREATE TABLE {TRINO_TABLE}").replace("\\n", "\n").splitlines()
                   if "location" in ln][0].split("'")[1]
            prefix = loc.split("qs-data/", 1)[1].rstrip("/") + "/"
            s, b = r.call("POST", f"/api/connections/{minio['id']}/tables", {
                "name": REG, "s3_prefix": prefix, "format": "iceberg",
                "description": "run progress proof: a long Spark run (TPC-H sf3 lineitem + a decoy partition)"})
            if s not in (200, 201):
                raise SystemExit(f"register {REG}: {s} {str(b)[:300]}")
        n = int(_trino(f"SELECT count(*) FROM {TRINO_TABLE} WHERE code = 'SAP-2920-EMEA' AND snap_version = 1"))
    else:
        if s != 200:
            raise SystemExit(f"QS_PROGRESS_TABLE={REG} is not registered on {minio['name']}")
        n = int(os.environ.get("QS_PROGRESS_ROWS", "4000000"))
    if n <= 0:
        raise SystemExit(f"{REG}: the query keeps no rows -- nothing to watch")
    return n
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:600]}" if detail else ""), flush=True)


class Socket(threading.Thread):
    """A browser's WebSocket, identified with rig_admin's session token."""

    def __init__(self, token):
        super().__init__(daemon=True)
        self.token, self.got, self.opened, self.stop = token, [], False, False

    def run(self):
        asyncio.run(self._main())

    async def _main(self):
        import websockets
        async with websockets.connect(f"ws://localhost:8000/ws/progress-proof-{int(time.time())}",
                                      max_size=None) as ws:
            await ws.send(json.dumps({"type": "identify", "username": "rig_admin", "token": self.token}))
            self.opened = True
            while not self.stop:
                try:
                    m = await asyncio.wait_for(ws.recv(), timeout=2)
                except asyncio.TimeoutError:
                    continue
                try:
                    msg = json.loads(m)
                except ValueError:
                    continue
                self.got.append(msg)
                if msg.get("type") == "ping":           # as the browser does: the server
                    await ws.send(json.dumps({"type": "pong"}))   # prunes a socket idle 300 s


def main():
    r = Rig()
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    minio = next(c for c in conns if c["connection_type"] == "s3"
                 and (c.get("config") or {}).get("bucket_name") == "qs-data")
    global WANT_ROWS
    WANT_ROWS = ensure_table(r, minio)
    print(f"   {REG}: the run must deliver {WANT_ROWS:,} rows", flush=True)
    sock = Socket(r.a.token)
    sock.start()
    for _ in range(50):
        if sock.opened:
            break
        time.sleep(0.2)
    check("a browser WebSocket is open as rig_admin", sock.opened)

    body = {"name": NAME, "source_type": "raw_sql", "source_id": 0, "connection_id": minio["id"],
            "query_params": {"sql": SQL}, "output_format": "csv", "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "output_filename_template": NAME + "_{business_date:YYYYMMDD}.csv",
            "execution_backend": "spark_k8s", "is_active": True, "schedule_enabled": False,
            "notify_on_failure": False, "description": "Proof: where a running Spark feed is"}
    if os.environ.get("QS_PROOF_EXEC_MEM"):                  # measure a sizing
        body["backend_config"] = {"spark_executor_memory": os.environ["QS_PROOF_EXEC_MEM"]}
    if os.environ.get("QS_PROOF_EXEC_OVERHEAD"):
        body.setdefault("backend_config", {})["spark_extra_conf"] = {
            "spark.executor.memoryOverhead": os.environ["QS_PROOF_EXEC_OVERHEAD"]}
    if not os.environ.get("QS_PROOF_EXEC_MEM") and not os.environ.get("QS_PROOF_EXEC_OVERHEAD"):
        body["backend_config"] = {}
    _, feeds = r.call("GET", "/api/feeds?limit=5000")
    feeds = feeds if isinstance(feeds, list) else feeds.get("items")
    f = next((x for x in feeds if x["name"] == NAME), None)
    s, b = (r.call("PUT", f"/api/feeds/{f['id']}", body) if f else r.call("POST", "/api/feeds", body))
    if s not in (200, 201):
        raise SystemExit(f"{NAME}: {s} {str(b)[:400]}")
    fid = f["id"] if f else b["id"]
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    run = r.run_row(fid, BD)
    if run is None:
        r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": BD, "end_date": BD, "deliver": True,
                                                       "reason": "progress proof"})
    else:
        r.call("POST", f"/api/feed-runs/{run['id']}/rerun", {"reason": "progress proof"})

    seen, modes, eid, status = [], set(), None, ""
    t0 = time.time()
    while time.time() - t0 < 4 * 3600:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                   f"and business_date='{BD}' order by id desc limit 1")
        if row:
            eid, status = row.split("|")
            s, ex = r.call("GET", f"/api/feed-executions/{eid}")
            p = (ex or {}).get("progress")
            if status == "running":
                modes.add(((ex or {}).get("run_log") or {}).get("mode"))
                if p and (not seen or p.get("reported_at") != seen[-1].get("reported_at")):
                    seen.append(p)
                    print(f"   {round(time.time() - t0)}s phase={p.get('phase')} "
                          f"{p.get('tasks_done')}/{p.get('tasks_total')} {p.get('percent')}% "
                          f"eta={p.get('eta_seconds')} rows={p.get('rows_written')} "
                          f"age={p.get('seconds_since_report')}s", flush=True)
            if status in ("completed", "failed", "cancelled"):
                break
        time.sleep(10)
    sock.stop = True
    wall = round(time.time() - t0)

    moved = len({(p.get("phase"), p.get("tasks_done")) for p in seen})
    check("P1 the record exists while running and MOVES (several distinct reports)",
          len(seen) >= 3 and moved >= 3, f"{len(seen)} reports, {moved} distinct (phase, done)")
    renders = [p for p in seen if p.get("phase") == "render" and (p.get("tasks_total") or 0) > 0]
    check("P1 the render phase reports Spark's own task counters",
          bool(renders), renders[-1] if renders else seen[-3:])
    check("P1 the record carries an estimate once tasks finish",
          any(p.get("eta_seconds") is not None for p in renders), [p.get("eta_seconds") for p in renders][-5:])
    check("P2 the run-log view tails the Spark run LIVE", "live" in modes, modes)
    exec_id = psql(f"select execution_id from feed_executions where id={eid}")
    mine = [m for m in sock.got if str(m.get("execution_id") or m.get("exec_id")) == exec_id]
    prog = [m for m in mine if (m.get("type") or m.get("event")) == "feed_progress" and m.get("progress")]
    lines = [m.get("line", "") for m in mine if (m.get("type") or m.get("event")) == "feed_run_log"]
    check("P3 the WebSocket received feed_progress with the counters for THIS run",
          len(prog) >= 2, f"{len(prog)} events; last {prog[-1]['progress'] if prog else None}")
    check("P3 the WebSocket received the job's own log lines (PHASE / PROGRESS)",
          any("PROGRESS phase=" in ln for ln in lines) and any("PHASE " in ln for ln in lines),
          f"{len(lines)} lines; e.g. {[ln for ln in lines if 'PROGRESS' in ln][:2]}")
    s, ex = r.call("GET", f"/api/feed-executions/{eid}")
    stored = ((ex or {}).get("files_metadata") or {}).get("log_lines") or []
    phases = [ln.split("PHASE ", 1)[1].strip() for ln in stored if "PHASE " in ln]
    check("P4 the stored log holds the job's story", {"read", "render", "deliver"} <= set(phases),
          f"phases {phases}; {len(stored)} lines")
    last = (ex or {}).get("progress") or {}
    check("P4 the last record says the run finished", last.get("phase") == "done", last.get("phase"))
    check(f"P5 {NAME} completed on spark_k8s with the round's rows",
          status == "completed" and int((ex or {}).get("total_rows") or 0) == WANT_ROWS,
          f"{status} rows={(ex or {}).get('total_rows')} wall={wall}s {(ex or {}).get('error_message') or ''}")
    out = os.path.join(HERE, "run-progress-results.json")
    json.dump({"checks": CHECKS, "reports": seen, "wall_seconds": wall}, open(out, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {out}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
