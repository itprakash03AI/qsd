"""Every table and column change reaches an EXISTING PostgreSQL (2026-10-18).

The owner: "make sure latest table changes are getting deployed to postgresql".
QueryStudio changes its schema at start-up: a new TABLE creates itself
(create_all); a new COLUMN arrives only through core/database.py's
``_MIGRATIONS`` (alembic is never run).  A column without an entry exists in a
fresh database and is MISSING from every upgraded one -- the classic way a
release breaks only in production.

The proof, on the rig's real PostgreSQL:
  1. database A built by the DEPLOYED release's code (``--deployed`` worktree:
     the commit the last bundle shipped, docs/DEPLOYMENT_BASE.txt), with a row
     in a few tables so the upgrade runs against data;
  2. A upgraded by THIS code (DatabaseManager init -- exactly what a pod start
     does on OpenShift);
  3. database B built FRESH by this code;
  4. every (table, column, type, nullable) of A == B, compared by SQL.  The
     COUNT of columns compared is asserted (no vacuous pass).

    python scripts/docker_proof/schema_upgrade_proof.py --deployed C:/DEV/qs-deployed-<sha>
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parent.parent
RES = []


def check(name, ok, detail=""):
    RES.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:700]}" if detail else ""), flush=True)
    return ok


def psql(db, sql):
    r = subprocess.run(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", db, "-tAc", sql],
                       capture_output=True, text=True, timeout=300)
    if r.returncode != 0:
        raise SystemExit(f"psql {db}: {r.stderr.strip()[:400]}")
    return r.stdout.strip()


def url(db):
    pw = os.environ.get("QS_PG_PASSWORD", "querystudio")
    return f"postgresql://querystudio:{pw}@127.0.0.1:5433/{db}"


INIT = r'''
import os, sys
os.environ.setdefault("QUERYSTUDIO_AUTH_TYPE", "none")
from core.database import DatabaseManager
db = DatabaseManager(db_url=sys.argv[1])
print("INIT-OK")
'''


def init(backend_dir, db):
    """DatabaseManager(db) from ``backend_dir`` -- what a pod start runs."""
    env = dict(os.environ, PYTHONPATH=str(backend_dir), PYTHONIOENCODING="utf-8")
    env.pop("QS_DATA_KEYS_IN_DB", None)
    r = subprocess.run([sys.executable, "-c", INIT, url(db)], cwd=str(backend_dir), env=env,
                       capture_output=True, text=True, timeout=900)
    return r.returncode == 0 and "INIT-OK" in r.stdout, (r.stderr or r.stdout)[-900:]


COLS = ("select table_name || '.' || column_name || ' ' || data_type || ' ' || is_nullable "
        "from information_schema.columns where table_schema = 'public' order by 1")
TABLES = ("select table_name from information_schema.tables where table_schema = 'public' "
          "and table_type = 'BASE TABLE' order by 1")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--deployed", default=None,
                    help="a worktree of the DEPLOYED release; default: made from docs/DEPLOYMENT_BASE.txt")
    a = ap.parse_args()
    made = None
    if a.deployed is None:
        # the last DELIVERED bundle (docs/DEPLOYMENT_BASE.txt: Deployment_<date>_<sha>) -> a
        # throw-away worktree of that commit, removed at the end
        base = (REPO / "docs" / "DEPLOYMENT_BASE.txt").read_text(encoding="utf-8").split()[0].strip()
        sha = base.rsplit("_", 1)[-1]
        target = REPO.parent / f"qs-deployed-{sha}"          # beside the repo, never inside it
        if not target.exists():
            made = target
            r = subprocess.run(["git", "-C", str(REPO), "worktree", "add", "--detach", str(target), sha],
                               capture_output=True, text=True)
            if not check(f"the deployed release {base} is checked out ({sha})", r.returncode == 0, r.stderr[-300:]):
                sys.exit(1)
        a.deployed = str(target)
    old_backend = pathlib.Path(a.deployed) / "backend"
    new_backend = REPO / "backend"
    check("the deployed release's code is present", (old_backend / "core" / "database.py").exists(), old_backend)
    up, fresh = "qs_schema_upgraded", "qs_schema_fresh"
    for d in (up, fresh):
        psql("postgres", f"drop database if exists {d}")
        psql("postgres", f"create database {d}")
    try:
        ok, out = init(old_backend, up)
        if not check("1. the DEPLOYED release builds its schema on PostgreSQL", ok, out):
            return
        n_old_tables = len(psql(up, TABLES).splitlines())
        # data in a few tables, so the upgrade runs against rows, not an empty shell
        psql(up, "insert into connections (name, connection_type, config, is_active) "
                 "values ('upgrade_probe', 'trino', '{\"host\": \"x\"}', true)")
        before_cols = set(psql(up, COLS).splitlines())
        ok, out = init(new_backend, up)
        check("2. THIS release upgrades that database at start-up (as a pod does)", ok, out)
        ok, out = init(new_backend, fresh)
        check("3. THIS release builds a fresh database", ok, out)
        a_cols, b_cols = set(psql(up, COLS).splitlines()), set(psql(fresh, COLS).splitlines())
        a_tabs, b_tabs = set(psql(up, TABLES).splitlines()), set(psql(fresh, TABLES).splitlines())
        check(f"the comparison is not vacuous ({len(b_cols)} columns in {len(b_tabs)} tables; "
              f"the deployed release had {n_old_tables} tables)", len(b_cols) > 1000 and len(b_tabs) > 100)
        new_tables = sorted(b_tabs - set(t.split(".")[0] for t in before_cols))
        added_cols = sorted(c for c in a_cols - before_cols if c.split(".")[0] not in new_tables)
        print(f"   new tables this release: {len(new_tables)}; columns added to EXISTING tables: {len(added_cols)}")
        check("4a. every table of a fresh database exists in the upgraded one", b_tabs <= a_tabs, sorted(b_tabs - a_tabs))
        missing = sorted(b_cols - a_cols)
        check("4b. every column (name, type, nullability) of a fresh database exists in the upgraded one",
              not missing, missing[:40])
        survived = psql(up, "select count(*) from connections where name = 'upgrade_probe'")
        check("4c. the existing rows survived the upgrade", survived == "1", survived)
        out_path = HERE / "schema-upgrade-results.json"
        out_path.write_text(json.dumps({"new_tables": new_tables, "columns_added_to_existing_tables": added_cols,
                                        "missing_in_upgraded": missing, "columns_compared": len(b_cols)}, indent=1),
                            encoding="utf-8")
        print(f"   details -> {out_path}")
    finally:
        for d in (up, fresh):
            try:
                psql("postgres", f"drop database if exists {d}")
            except SystemExit:
                pass
        if made is not None:
            subprocess.run(["git", "-C", str(REPO), "worktree", "remove", "--force", str(made)], capture_output=True)
    print(f"\n{sum(RES)}/{len(RES)} checks passed")
    sys.exit(0 if RES and all(RES) else 1)


if __name__ == "__main__":
    main()
