"""Feed Run Status against the DATABASE TRUTH, on the live Docker rig
(2026-10-17; the owner: "check the feedgen dashboard the way an operations
user relies on it at month end").

Every number and state on the board (``GET /api/feed-dashboard``, every
page) is compared with what SQL says -- never with the thing under test:

  G1  by business date: one task per active feed (the latest non-manual run),
      the status word per task from the raw columns (run status / decision,
      an open variance hold, a held re-send decision), the KPI tiles, each
      group's whole-group counts, the step counts (latest attempt per step),
      the deliveries (completed executions, DELIVERED = destination_path),
      the SLA verdict from the same deadline rule, ``variance_held``, and the
      feeds due with no task (the date's open SOD gaps);
  G2  by run date: each daily / month-end feed's business date derived HERE
      from its calendar (weekend days + holidays), the rows exist for that
      (feed, date), and every such feed is either a task or ``missing``;
  G3  roles: an analyst sees only feeds it may view; ``can_act`` is False on
      a feed it does not own and the server answers 403 to a re-run of it
      (no mutation); a viewer / support role sees but may act on nothing;
  G4  live (``--live-feed-id``): a WebSocket as rig_admin watching the board
      receives the ``feed_progress`` of a Run Now made by ANOTHER user;
  G5  latency: both views at page_size 50, reported, failed above 10 s.

The COUNT of values compared is asserted and the truth must be NON-ZERO:
a loop over an empty set is vacuously true.

    . ~/.qs_keys/rigpw.sh
    python scripts/docker_proof/feed_board_truth_proof.py --business-date 2026-09-30 \
        [--run-date 2026-10-13] [--analyst rig_analyst:$QS_RIG_ANALYST_PW] \
        [--live-feed-id 123 --live-as rig_analyst:$QS_RIG_ANALYST_PW]
Read-only against the rig except G4 (one Run Now of the named feed).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import date, datetime, time as dtime, timedelta, timezone
from zoneinfo import ZoneInfo

sys.path.insert(0, __file__.rsplit("/", 1)[0].rsplit("\\", 1)[0])
from feed_triggers_proof import check, psql, res  # noqa: E402
from qs_docker_client import call  # noqa: E402

COMPARED = {"n": 0}


def cmp(name, got, want, detail=""):
    COMPARED["n"] += 1
    return check(name, got == want, f"got={got!r} want={want!r} {detail}")


def rows(sql):
    out = psql(sql)
    return [r.split("\t") for r in out.splitlines() if r != ""]


def jrows(sql):
    """``select row_to_json(t) from (...) t`` -> list of dicts."""
    return [json.loads(r[0]) for r in rows(f"select row_to_json(t) from ({sql}) t")]


def board_pages(params, token=None):
    tasks, groups, body = [], [], None
    page = 1
    while True:
        q = "&".join(f"{k}={v}" for k, v in {**params, "page": page, "page_size": 500}.items())
        s, b, _ = call("GET", f"/api/feed-dashboard?{q}", timeout=120,
                       headers={"Authorization": f"Bearer {token}"} if token else None)
        assert s == 200, (s, str(b)[:300])
        body = body or b
        for g in b["groups"]:
            groups.append(g)
            tasks.extend(g["tasks"])
        if page >= b["pages"]:
            break
        page += 1
    return body, tasks, groups


# ── the truth, from raw columns ────────────────────────────────────────

OPEN_HOLD = ("held", "release_failed", "releasing")


def task_status_truth(run, hold, restated):
    st, dec = (run["status"] or "").lower(), (run["action_decision"] or "").upper()
    if hold is not None:
        if hold in OPEN_HOLD:
            return "held"
        if hold == "rejected":
            return "failed"
    if st == "completed" and restated:
        return "held"
    if st == "running":
        return "in_progress"
    if st == "completed":
        return "completed"
    if st in ("failed", "cancelled", "error"):
        return "failed"
    if dec == "SKIP" or st == "skipped":
        return "skipped"
    if st == "pending":
        return "not_started" if dec == "WAIT" else "queued"
    return "not_started"


def latest_runs(bd):
    return jrows(f"""
        select r.* from feed_runs r
        join feed_configs f on f.id = r.feed_config_id
        where r.business_date = '{bd}' and f.is_active
          and (r.run_type is null or r.run_type not in ('manual', 'dry_run'))
          and r.id = (select max(r2.id) from feed_runs r2
                      where r2.feed_config_id = r.feed_config_id and r2.business_date = r.business_date
                        and (r2.run_type is null or r2.run_type not in ('manual', 'dry_run')))""")


def holds_of(bd):
    out = {}
    for h in jrows(f"select feed_run_id, status, id from feed_variance_holds where business_date = '{bd}' "
                   f"and status <> 'superseded' order by id desc"):
        out.setdefault(int(h["feed_run_id"]), h["status"])
    return out


def restated_feeds(bd):
    out = set()
    for d in jrows(f"select feed_config_id, evidence from feed_regeneration_decisions "
                   f"where business_date = '{bd}' and status = 'open'"):
        ev = (d.get("evidence") or {}).get("restatement") or {}
        if ev.get("action") in ("hold", "closed"):
            out.add(int(d["feed_config_id"]))
    return out


def sla_truth(run, tz_name, now):
    st = (run["status"] or "").lower()
    if st in ("skipped", "cancelled") or (run["action_decision"] or "").upper() == "SKIP":
        return "not_due"
    if not run.get("sla_to"):
        return "no_sla"
    m = re.match(r"^\+?(\d{1,2}):(\d{2})(?::(\d{2}))?$", str(run["sla_to"]).strip())
    if not m:
        return "invalid_sla"
    bd = date.fromisoformat(run["business_date"][:10])
    t = dtime(int(m.group(1)), int(m.group(2)), int(m.group(3) or 0))
    if tz_name:
        try:
            deadline = datetime.combine(bd, t, tzinfo=ZoneInfo(tz_name)).astimezone(timezone.utc)
        except Exception:
            return "invalid_sla"
    else:
        deadline = datetime.combine(bd, t, tzinfo=timezone.utc)
    delivered = bool(run.get("output_path"))
    done = run.get("completed_at")
    done_at = datetime.fromisoformat(done.replace("Z", "+00:00")) if done else None
    if done_at is not None and done_at.tzinfo is None:
        done_at = done_at.replace(tzinfo=timezone.utc)
    if delivered and done_at is not None:
        return "met" if done_at <= deadline else "late"
    if run.get("sla_breached") or now > deadline:
        return "breached"
    return "at_risk" if (deadline - now).total_seconds() <= 30 * 60 else "on_track"


# ── G1: by business date ───────────────────────────────────────────────

def g1(bd):
    print(f"\n== G1 by business date {bd}")
    now = datetime.now(timezone.utc)
    truth = latest_runs(bd)
    check("G1.0 the truth is non-zero (runs for the date exist)", len(truth) > 0, f"{len(truth)} runs")
    if not truth:
        return
    holds, restated = holds_of(bd), restated_feeds(bd)
    feeds = {int(f["id"]): f for f in jrows(
        "select id, name, feed_group_id, sla_timezone, is_active from feed_configs")}
    groups = {int(g["id"]): g for g in jrows("select id, name, display_label from feed_groups")}
    want = {}
    for r in truth:
        fid = int(r["feed_config_id"])
        want[fid] = {"run_id": int(r["id"]),
                     "status": task_status_truth(r, holds.get(int(r["id"])), fid in restated),
                     "sla": sla_truth(r, feeds[fid].get("sla_timezone"), now),
                     "group": (groups.get(feeds[fid]["feed_group_id"]) or {}).get("name", "No group")
                     if feeds[fid].get("feed_group_id") else "No group",
                     "vh_open": holds.get(int(r["id"])) in OPEN_HOLD}
    body, tasks, groups_api = board_pages({"business_date": bd})
    cmp("G1.1 total_tasks == feeds with a run", body["total_tasks"], len(want))
    got = {int(t["feed_id"]): t for t in tasks}
    cmp("G1.2 every feed is on the board once", sorted(got), sorted(want))
    n_state = n_run = n_sla = 0
    bad = []
    for fid, w in want.items():
        t = got.get(fid)
        if not t:
            continue
        n_run += 1
        if int(t["run_id"]) != w["run_id"]:
            bad.append((fid, "run_id", t["run_id"], w["run_id"]))
        n_state += 1
        if t["status"] != w["status"]:
            bad.append((fid, "status", t["status"], w["status"]))
        # the SLA verdict may legitimately move between the two reads (now);
        # at_risk/on_track/breached boundaries are compared loosely
        n_sla += 1
        a, b = t["sla"]["verdict"], w["sla"]
        if a != b and not ({a, b} <= {"at_risk", "on_track", "breached"}):
            bad.append((fid, "sla", a, b))
    check(f"G1.3 run id per feed is the latest non-manual run ({n_run} compared)",
          n_run > 0 and not [x for x in bad if x[1] == "run_id"], bad[:5])
    check(f"G1.4 status word per task from the raw columns ({n_state} compared)",
          n_state > 0 and not [x for x in bad if x[1] == "status"], [x for x in bad if x[1] == "status"][:8])
    check(f"G1.5 SLA verdict per task from the same deadline rule ({n_sla} compared)",
          n_sla > 0 and not [x for x in bad if x[1] == "sla"], [x for x in bad if x[1] == "sla"][:8])
    # KPIs
    from collections import Counter
    c = Counter(w["status"] for w in want.values())
    for k in ("completed", "held", "in_progress", "failed", "not_started", "queued", "skipped"):
        cmp(f"G1.6 kpi {k}", body["kpis"].get(k, 0), c.get(k, 0))
    cmp("G1.6 kpi all", body["kpis"]["all"], len(want))
    sl = Counter(w["sla"] for w in want.values())
    cmp("G1.7 kpi sla_breached (breached + late)", body["kpis"]["sla_breached"], sl["breached"] + sl["late"],
        "(a boundary move between the two reads shows as 1 off)")
    cmp("G1.8 kpi variance_held == open variance holds", body["kpis"]["variance_held"],
        sum(1 for w in want.values() if w["vh_open"]))
    cmp("G1.8b kpi held >= variance_held", body["kpis"]["held"] >= body["kpis"]["variance_held"], True)
    # groups: whole-group counts
    gc = {}
    for w in want.values():
        gc.setdefault(w["group"], Counter())[w["status"]] += 1
    n_g = 0
    bad = []
    seen = set()
    for g in groups_api:
        if g["name"] in seen:
            continue                      # a group spanning two pages repeats its header
        seen.add(g["name"])
        n_g += 1
        wc = gc.get(g["name"], Counter())
        if g["counts"].get("all", 0) != sum(wc.values()):
            bad.append((g["name"], "all", g["counts"].get("all"), sum(wc.values())))
        for k, v in wc.items():
            if g["counts"].get(k, 0) != v:
                bad.append((g["name"], k, g["counts"].get(k), v))
    check(f"G1.9 group counts are the whole group ({n_g} groups compared)", n_g > 0 and not bad, bad[:6])
    # steps: latest attempt per alias
    ids = ",".join(str(w["run_id"]) for w in want.values())
    steps = {}
    for s in jrows(f"""select s.feed_run_id, s.status from feed_run_steps s
                       join (select feed_run_id, alias, max(attempt) att from feed_run_steps
                             where feed_run_id in ({ids}) group by feed_run_id, alias) l
                         on l.feed_run_id = s.feed_run_id and l.alias = s.alias and l.att = s.attempt"""):
        d = steps.setdefault(int(s["feed_run_id"]), Counter())
        d[s["status"]] += 1
    n_s = 0
    bad = []
    for t in tasks:
        c = steps.get(int(t["run_id"]), Counter())
        want_steps = {"total": sum(c.values()), "completed": c["completed"],
                      "failed": c["failed"] + c["refused"], "running": c["running"],
                      "not_started": c["not_started"], "skipped": c["skipped"]}
        n_s += 1
        if t["steps"] != want_steps:
            bad.append((t["feed_name"], t["steps"], want_steps))
    check(f"G1.10 step counts per run == latest attempt per step ({n_s} runs, "
          f"{sum(sum(c.values()) for c in steps.values())} step rows)", n_s > 0 and not bad, bad[:4])
    # deliveries
    dels = {}
    for e in jrows(f"select feed_config_id, execution_id, destination_path from feed_executions "
                   f"where business_date = '{bd}' and status = 'completed'"):
        dels.setdefault(int(e["feed_config_id"]), {})[e["execution_id"]] = bool(e["destination_path"])
    n_d = 0
    bad = []
    for t in tasks:
        w = dels.get(int(t["feed_id"]), {})
        g = {d["execution_id"]: d["delivered"] for d in (t["deliveries"] or [])}
        n_d += len(w)
        if g != w:
            bad.append((t["feed_name"], g, w))
    check(f"G1.11 deliveries == completed executions, DELIVERED = destination_path ({n_d} compared)",
          n_d > 0 and not bad, bad[:4] if bad else (f"{n_d} deliveries compared" if n_d else "no completed execution for the date -- nothing compared"))
    # missing: the date's open SOD gaps of active feeds
    gaps = jrows(f"select g.feed_config_id from feed_sod_gaps g join feed_configs f on f.id = g.feed_config_id "
                 f"where g.business_date = '{bd}' and g.resolved_at is null and f.is_active")
    cmp("G1.12 missing_count == the date's open SOD gaps", body["missing_count"], len(gaps))
    cmp("G1.13 can_act is on every task", all("can_act" in t for t in tasks), True)
    cmp("G1.14 sod state is said", body["sod"].get("enabled") in (True, False), True, body["sod"])


# ── G2: by run date ────────────────────────────────────────────────────

def _calendar(name):
    cal = jrows(f"select id, weekend_days from feed_calendars where name = '{name}'")
    if not cal:
        return None
    hol = {date.fromisoformat(h["holiday_date"][:10]) for h in jrows(
        f"select holiday_date from feed_holidays where calendar_id = {cal[0]['id']}")}
    wk = cal[0].get("weekend_days")
    wk = [6, 7] if wk is None else wk
    return {"weekend": set(int(x) for x in wk), "holidays": hol}


def _is_bd(cal, d):
    return d.isoweekday() not in cal["weekend"] and d not in cal["holidays"]


def _prev_or_same_bd(cal, d):
    while not _is_bd(cal, d):
        d -= timedelta(days=1)
    return d


def derive(kind, decl, cal, run_d):
    """daily / month_end, as the schedule rule reads: the latest due day on
    or before the run day (on the calendar), then the date its data is for."""
    start = _prev_or_same_bd(cal, run_d)
    if kind == "daily":
        return start
    if kind == "month_end":
        d = start
        for _ in range(400):
            nxt = d + timedelta(days=1)
            last_bd_of_month = _prev_or_same_bd(cal, (d.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1))
            if d == last_bd_of_month:
                return d
            d = _prev_or_same_bd(cal, d - timedelta(days=1))
            del nxt
    return None


def g2(rd, default_cal):
    print(f"\n== G2 by run date {rd}")
    feeds = jrows("select id, name, calendar_name, schedule_declaration from feed_configs where is_active")
    body, tasks, _ = board_pages({"run_date": rd})
    got = {int(t["feed_id"]): t for t in tasks}
    missing = {int(m["feed_id"]) for m in (body.get("missing") or [])}
    n = 0
    bad = []
    uncheckable = 0
    for f in feeds:
        decl = f.get("schedule_declaration") or {}
        if isinstance(decl, str):
            decl = json.loads(decl or "{}")
        kind = decl.get("kind") or "daily"
        if kind not in ("daily", "month_end") or decl.get("business_date") not in (None, "", "run_day"):
            uncheckable += 1
            continue
        cal = _calendar(f.get("calendar_name") or decl.get("calendar_name") or default_cal or "")
        if cal is None:
            uncheckable += 1
            continue
        bd = derive(kind, decl, cal, date.fromisoformat(rd))
        n += 1
        t = got.get(int(f["id"]))
        if t is not None:
            if t["business_date"] != bd.isoformat():
                bad.append((f["name"], "business_date", t["business_date"], bd.isoformat()))
            if not rows(f"select 1 from feed_runs where feed_config_id = {f['id']} and business_date = '{bd}' limit 1"):
                bad.append((f["name"], "no run row for the derived date", bd.isoformat()))
        elif int(f["id"]) not in missing:
            bad.append((f["name"], "neither a task nor missing", bd.isoformat()))
    check(f"G2.1 every daily / month-end feed is on its derived date or SAID missing "
          f"({n} derived here, {uncheckable} not independently derivable, {body['missing_count']} missing)",
          n > 0 and not bad, bad[:8])
    cmp("G2.2 date_kind", body["date_kind"], "run_date")
    cmp("G2.3 the date summary counts the tasks", sum(x["feeds"] for x in body["date_summary"] or []), len(tasks))


# ── G3: roles ──────────────────────────────────────────────────────────

def _login(spec):
    user, pw = spec.split(":", 1)
    s, b, _ = call("POST", "/auth/login", {"username": user, "password": pw}, headers={"Authorization": ""})
    assert s == 200, (user, s, str(b)[:200])
    return user, b["session_token"], b.get("role")


def g3(bd, analyst, support):
    print("\n== G3 roles")
    for spec, kind in ((analyst, "analyst"), (support, "support")):
        if not spec:
            continue
        user, tok, role = _login(spec)
        h = {"Authorization": f"Bearer {tok}"}
        s, feeds, _ = call("GET", "/api/feeds?limit=10000", headers=h)
        visible = {int(f["id"]) for f in (feeds.get("items") if isinstance(feeds, dict) else feeds) or []}
        body, tasks, _ = board_pages({"business_date": bd}, token=tok)
        cmp(f"G3.{kind} every task's feed is one {user} may view ({len(tasks)} tasks)",
            len(tasks) > 0 and all(int(t["feed_id"]) in visible for t in tasks), True,
            "an empty board compares nothing" if not tasks else "")
        if kind == "support":
            cmp(f"G3.support sees the estate and may act on nothing ({len(tasks)} tasks)",
                len(tasks) > 0 and all(t["can_act"] is False for t in tasks), True)
        owned = {int(f["id"]) for f in jrows(f"select id from feed_configs where created_by = '{user}'")}
        others = [t for t in tasks if int(t["feed_id"]) not in owned and t["can_act"] is False]
        mine = [t for t in tasks if int(t["feed_id"]) in owned]
        if kind == "analyst":
            check(f"G3.analyst owns at least one task, and can_act is True on every one it owns ({len(mine)})",
                  len(mine) > 0 and all(t["can_act"] for t in mine),
                  ([t["feed_name"] for t in mine if not t["can_act"]][:5] if mine else "the analyst owns no task on this date"))
        if others:
            s, b, _ = call("POST", f"/api/feed-runs/{others[0]['run_id']}/rerun", headers=h)
            cmp(f"G3.{kind} the server refuses a re-run where can_act is False (no mutation)", s, 403, str(b)[:120])


# ── G4: live, as the operations user ───────────────────────────────────

def g4(feed_id, live_as, bd):
    print("\n== G4 live board watch")
    import websockets.sync.client as wsc
    admin_tok = _login(f"{os.environ.get('QS_RIG_ADMIN_USER', 'rig_admin')}:{os.environ['QS_RIG_ADMIN_PW']}")[1]
    other, other_tok, _ = _login(live_as)
    url = "ws://localhost:8000/ws/proof-board-%d" % int(time.time())
    with wsc.connect(url, open_timeout=30) as ws:
        ws.send(json.dumps({"type": "identify", "username": "rig_admin", "token": admin_tok}))
        ws.send(json.dumps({"type": "watch", "scope": "feed_board"}))
        ack = None
        t0 = time.time()
        while time.time() - t0 < 30:
            m = json.loads(ws.recv(timeout=30))
            if m.get("type") == "watching":
                ack = m
                break
        cmp("G4.1 the watch is accepted for the admin", (ack or {}).get("ok"), True, ack)
        s, b, _ = call("POST", f"/api/feeds/{feed_id}/execute", {"business_date": bd},
                       headers={"Authorization": f"Bearer {other_tok}"})
        check("G4.2 another user's Run Now is accepted", s in (200, 202), f"{s} {str(b)[:160]}")
        seen = []
        t0 = time.time()
        while time.time() - t0 < 120:
            try:
                m = json.loads(ws.recv(timeout=10))
            except TimeoutError:
                continue
            if str(m.get("type", "")).startswith("feed_") and int(m.get("feed_id") or 0) == int(feed_id):
                seen.append((m["type"], m.get("via"), m.get("username")))
                if m["type"] in ("feed_completed", "feed_failed"):
                    break
        check(f"G4.3 the admin's board socket heard the other user's run ({len(seen)} events)",
              any(v == "feed_board_watch" and u == "rig_admin" for _, v, u in seen), seen[:6])


# ── G5: latency ────────────────────────────────────────────────────────

def g5(bd, rd):
    print("\n== G5 latency")
    for path in (f"/api/feed-dashboard?business_date={bd}&page_size=50",
                 f"/api/feed-dashboard?run_date={rd}&page_size=50"):
        t0 = time.perf_counter()
        s, b, _ = call("GET", path, timeout=120)
        dt = time.perf_counter() - t0
        check(f"G5 {path} answers in {dt * 1000:.0f} ms (rows={b.get('total_tasks') if isinstance(b, dict) else '?'})",
              s == 200 and dt < 10, "")


# ── unattended (the release check runs this with no arguments) ─────────

def _unattended_defaults(a):
    """Every check must RUN in the release check: a role or live check that is
    silently skipped when an argument is missing is a fake pass (2026-10-18).
    Anything that cannot be set up here FAILS with the reason."""
    if a.business_date is None:
        # TODAY: the fixture below makes a daily feed whose run COMPLETES today, so the
        # board has a real delivery to compare and a derivable feed for G2 -- a rig
        # rebuilt from EMPTY has neither (the release check, 2026-10-18: 0 compared)
        a.business_date = date.today().isoformat()
        print(f"[unattended] business date {a.business_date} (today; the fixture runs on it)")
    if a.analyst is None and os.environ.get("QS_RIG_ANALYST_PW"):
        a.analyst = f"rig_analyst:{os.environ['QS_RIG_ANALYST_PW']}"
    if a.support is None:
        tag = int(time.time())
        user, pw = f"board_support_{tag}", f"Sup-{tag}-pass!"
        s, b, _ = call("POST", "/api/admin/users", {"username": user, "password": pw, "role": "support"})
        if check("[unattended] a support user is created for G3", s in (200, 201), (s, str(b)[:200])):
            a.support = f"{user}:{pw}"
    if a.live_feed_id is None and a.analyst:
        user, tok, _ = _login(a.analyst)
        h = {"Authorization": f"Bearer {tok}"}
        name = f"BOARD_LIVE_{int(time.time())}"
        s, q, _ = call("POST", "/api/queries", {"name": f"{name}_q", "query_config": {
            "files": [], "raw_sql": "select name, regionkey from tpch.tiny.region", "connection_id": 2}}, headers=h)
        if not check(f"[unattended] {user} saves the live feed's query", s in (200, 201), (s, str(q)[:200])):
            return
        # a calendar on which TODAY is a business day (its one weekend day is never today)
        wk = (date.today().isoweekday() + 2) % 7 + 1
        cal_name = f"BOARD_CAL_{int(time.time())}"
        s, cal, _ = call("POST", "/api/admin/feed-calendars", {"name": cal_name, "weekend_days": [wk]})
        if not check("[unattended] the fixture's calendar is created", s == 201, (s, str(cal)[:200])):
            return
        a.made_calendar = int(cal["id"])
        s, f, _ = call("POST", "/api/feeds", {
            "name": name, "source_type": "saved_query", "source_id": q["id"], "connection_id": 2,
            "output_format": "csv", "destination_type": "local", "destination_config": {},
            "execution_backend": "native", "calendar_name": cal_name,
            "schedule_declaration": {"kind": "daily"}}, headers=h)
        if check(f"[unattended] {user} creates the live feed (not admin-owned)", s in (200, 201), (s, str(f)[:200])):
            a.live_feed_id, a.live_as = int(f["id"]), a.analyst
            a.made_feed, a.made_query = int(f["id"]), int(q["id"])
            # a BACKFILL run on the date: the board lists non-manual runs, so without one the
            # analyst's G3 checks compared an EMPTY board (a vacuous pass, 2026-10-18)
            s, b, _ = call("POST", f"/api/feeds/{f['id']}/backfill", {
                "start_date": a.business_date, "end_date": a.business_date, "deliver": False,
                "reason": "board proof: the analyst's own task on the board"}, headers=h)
            check(f"[unattended] {user}'s feed has a run on {a.business_date}", s in (200, 201, 202), (s, str(b)[:200]))
            done = None
            for _ in range(60):          # the run COMPLETES: G1.11 compares a real delivery
                r = rows(f"select status from feed_executions where feed_config_id = {f['id']} order by id desc limit 1")
                if r and r[0][0] in ("completed", "failed", "cancelled"):
                    done = r[0][0]
                    break
                time.sleep(5)
            check(f"[unattended] the fixture's run completed (a delivery to compare)", done == "completed", done)


def _cleanup(a):
    """The unattended live feed is DELETED afterwards: an active feed gets a start-of-day
    run every day (2026-10-18), and a proof must leave nothing running."""
    if not getattr(a, "made_feed", None):
        return
    user, tok, _ = _login(a.analyst)
    h = {"Authorization": f"Bearer {tok}"}
    s, _b, _ = call("DELETE", f"/api/feeds/{a.made_feed}", headers=h)
    s2, _b2, _ = call("DELETE", f"/api/queries/{a.made_query}", headers=h)
    check("the proof's own feed and query are removed afterwards", s in (200, 204) and s2 in (200, 204), (s, s2))
    if getattr(a, "made_calendar", None):
        s3, _b3, _ = call("DELETE", f"/api/admin/feed-calendars/{a.made_calendar}")
        check("the fixture's calendar is removed afterwards", s3 in (200, 204), s3)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--business-date", default=None,
                    help="default: the business date with the MOST runs on this rig (the richest truth)")
    ap.add_argument("--run-date", default=date.today().isoformat())
    ap.add_argument("--default-calendar", default="")
    ap.add_argument("--analyst", default=None, help="user:pass of an analyst")
    ap.add_argument("--support", default=None, help="user:pass of a support user")
    ap.add_argument("--live-feed-id", type=int, default=None)
    ap.add_argument("--live-as", default=None, help="user:pass that presses Run Now")
    a = ap.parse_args()
    _unattended_defaults(a)
    g1(a.business_date)
    g2(a.run_date, a.default_calendar)
    g3(a.business_date, a.analyst, a.support)
    if a.live_feed_id and a.live_as:
        g4(a.live_feed_id, a.live_as, a.business_date)
    else:
        check("G4 the live check ran (a non-admin's feed and its user)", False,
              "no --live-feed-id/--live-as and none could be made unattended -- a skipped check is a failed one")
    g5(a.business_date, a.run_date)
    _cleanup(a)
    ok = sum(res)
    print(f"\n{ok}/{len(res)} checks passed; {COMPARED['n']} values compared")
    check("values compared is non-zero", COMPARED["n"] > 20, COMPARED["n"])
    sys.exit(0 if all(res) else 1)


if __name__ == "__main__":
    main()
