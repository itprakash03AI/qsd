#!/bin/sh
# Add a HIVE catalog `hive_aws` to qs-trino (the cloud Trino) on the REAL AWS
# bucket (2026-10-11) -- the write-ladder's rung 1 (engine_write) needs a
# Hive connector that accepts `external_location` CTAS: the CLUSTER writes a
# big feed's parquet parts straight to S3 and no row transits a QueryStudio
# process.  The owner's cloud side is Iceberg on S3 (catalog iceberg_aws);
# this catalog is only the SCRATCH the unload writes through.
#
#     sh scripts/docker_proof/make_hive_aws_catalog.sh     # writes + restarts qs-trino
#
# Credentials and region are copied INSIDE the container from qs-trino's own
# iceberg_aws.properties -- one set of lake credentials, never typed twice and
# never printed.  The file metastore lives beside the Iceberg warehouse.
# `docker restart` (not recreate) keeps qs-trino's networks, the kind one too.
set -eu
C="${QS_CLOUD_TRINO:-qs-trino}"
docker exec "$C" sh -c '
set -eu
SRC=/etc/trino/catalog/iceberg_aws.properties
OUT=/etc/trino/catalog/hive_aws.properties
[ -f "$SRC" ] || { echo "no $SRC in the container" >&2; exit 1; }
WH=$(sed -n "s#^iceberg.jdbc-catalog.default-warehouse-dir=s3://\([^/]*\)/.*#\1#p" "$SRC" | tr -d "\r")
[ -n "$WH" ] || { echo "no warehouse bucket in $SRC" >&2; exit 1; }
{
  echo "# qs-trino HIVE scratch catalog on the real AWS bucket (make_hive_aws_catalog.sh)"
  echo "connector.name=hive"
  echo "hive.metastore=file"
  echo "hive.metastore.catalog.dir=s3://$WH/hive-metastore/"
  echo "hive.storage-format=PARQUET"
  echo "hive.compression-codec=SNAPPY"
  echo "hive.non-managed-table-writes-enabled=true"
  grep -E "^(fs\.native-s3\.enabled|s3\.)" "$SRC" | tr -d "\r"
} > "$OUT"
grep -q "^s3.aws-access-key=" "$OUT" || { echo "no lake credentials copied" >&2; exit 1; }
echo "wrote $OUT ($(grep -c . "$OUT") lines) -- bucket $WH"
'
docker restart "$C" >/dev/null
i=0; until docker exec "$C" trino --execute "SHOW SCHEMAS FROM hive_aws" >/dev/null 2>&1; do
  i=$((i + 1)); [ $i -gt 60 ] && { echo "hive_aws not answering after restart" >&2; exit 1; }; sleep 3; done
echo "hive_aws is up on $C"
