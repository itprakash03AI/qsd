"""Time the Feed Run Status board's calls on the live rig (2026-10-12, the
owner: "dashboard seems slow").  Prints the median of N calls per route, the
row count each answered with, and the API's loop-stall warnings since start.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/board_latency.py [DATE] [N]
"""
from __future__ import annotations

import statistics
import sys
import time
from datetime import date

sys.path.insert(0, __file__.rsplit("/", 1)[0].rsplit("\\", 1)[0])
from qs_docker_client import call  # noqa: E402

D = sys.argv[1] if len(sys.argv) > 1 else date.today().isoformat()
N = int(sys.argv[2]) if len(sys.argv) > 2 else 5
ROUTES = [
    f"/api/feed-runs?business_date={D}&limit=1000",
    f"/api/feed-dashboard?business_date={D}&page_size=50",
    f"/api/feed-dashboard?business_date={D}&page_size=50&group_by=template",
    f"/api/feed-sla-board?business_date={D}",
    # 2026-10-17 -- the run-date view walks EVERY active config's rule
    # (core/feed/dashboard.py build(run_date=)): timed too
    f"/api/feed-dashboard?run_date={D}&page_size=50",
]
for path in ROUTES:
    times, size = [], None
    for _ in range(N):
        t0 = time.perf_counter()
        s, b, _ = call("GET", path, timeout=120)
        times.append(time.perf_counter() - t0)
        assert s == 200, (path, s, str(b)[:200])
        size = (b.get("count") if "count" in b else b.get("total_tasks", len(b.get("rows", []) or [])))
    print(f"{statistics.median(times)*1000:8.0f} ms median  max {max(times)*1000:6.0f} ms"
          f"  rows={size}  {path}")
