"""The owner's MONTH-END journey on the rig -- the operator's manual steps
(2026-10-12; the screens are driven by frontend/e2e/docker-month-end-journey.spec.ts,
which calls this helper for what an operator does OUTSIDE QueryStudio).

  prepare   the data an upstream would have loaded: the owner's fact_tetb
            (460 columns per side, the shared query fact_tetb.json) on AWS S3
            Iceberg (cloud) and Starburst (on-prem) for SYSTEM_ENTITY
            SAP-2920-EMEA, event EOD, business date 2026-09-30 -- one row set
            per upstream VERSION (each side its own version numbers), the two
            connections with meaningful names, the business calendar, and the
            shared query's two SQL texts (printed as JSON for the screens)
  send      the operator inserts ONE upstream message by hand: CLOUD on the
            Kafka topic, ON-PREM as a row of the QS_KAFKA_MESSAGE table --
            the version and its row count
  status    the task on Feed Run Status (JSON), for the screens' checks
  volume    a VOLUME version (2026-10-13, the owner: "you are testing with 11
            rows? test at least 1 million"): --cloud N rows on AWS S3 and
            --onprem M rows on Starburst, generated ON the clusters, as ONE new
            upstream version per side (cloud 7100, on-prem 9100); its truth
            (count, sum of the version, sum of the row id) is kept.  Then
            ``send --side cloud --volume`` / ``--side onprem --volume``
            announce it with its exact row count
  verify    the delivered file on the SFTP server against that truth, value
            by value (awk inside qs-sftp -- nothing multi-GB crosses the host)
  road      the SAME month-end feed on another ROAD to the cloud data
            (2026-10-13, the owner: "keep all options -- one feed via trino,
            another directly S3, another Starburst ... I will get Snowflake
            again"; "AWS S3 is primary"): a CLONE of the month-end feed (same
            calendar, schedule, SLA, dependencies, SFTP, alerts, re-send
            policy) whose cloud side reads through ``--road``:
              s3        QueryStudio's OWN S3 engine, the Iceberg table registered
                        on the direct AWS S3 connection (no Trino)
              starburst both sides on Starburst: a copy of the journey's
                        shared .sql file with BOTH connections the on-prem
                        Starburst (its iceberg_aws catalog reads the cloud
                        table from the same bucket); each side keeps its own
                        environment's {version}
            then start of day for the month end, for that feed
  daily     ONE day of the owner's daily re-send test until the October month
            end (2026-10-13, the owner: "this feed I want to test on a daily
            basis till the October month end starts"): a NEW upstream version
            on both sides (its own rows), CLOUD by Kafka then ON-PREM as a
            QS_KAFKA_MESSAGE row a minute later, then waits for the delivery
            the re-send policy makes on this new run date and checks it (rows
            == cloud + on-prem of that version, each side read its version).
            Appends to .month_end_daily_log.jsonl and rewrites
            docs/MONTH_END_DAILY_RESENDS.html.  From the October month end on
            it records "stopped" and does nothing (the September business date
            is then closed to re-sends; the October task takes over).

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/month_end_journey.py prepare
    python scripts/docker_proof/month_end_journey.py send --side cloud --n 1
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql  # noqa: E402
from monthly_kafka_merge_feeds_proof import connections  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, SB_HOST, SB_PORT, TABLES, abbr, cloud_cli, ddl, ensure_oracle_table, insert_rows,
    load_queries, message, ora_rows, oracle_admin, ORA_TABLE, parse_query, produce_kafka, row_values,
)

SPEC = TABLES["tetb"]                      # the owner's fact_tetb shared query (460 columns)
DS = SPEC["data_source"]
ENTITY, EVENT = "SAP-2920-EMEA", "EOD"
BD = dt.date(2026, 9, 30)                  # the September month end
CLOUD_CONN, PREM_CONN = "cloud-aws-s3-iceberg", "onprem-starburst"
CLOUD_SCHEMA = "iceberg_aws.month_end"
CLOUD_TABLE = f"{CLOUD_SCHEMA}.fact_tetb"
PREM_TABLE = "iceberg.qs.fact_tetb_month_end"
CALENDAR = "BUSINESS_DAYS_MON_FRI"
#: per upstream VERSION: (cloud version, cloud rows, on-prem version, on-prem rows)
#: -- the environments number their versions independently
VERSIONS = {1: (7001, 3, 9001, 4), 2: (7002, 5, 9002, 6), 3: (7003, 4, 9003, 5),
            4: (7004, 6, 9004, 7), 5: (7005, 2, 9005, 3)}
STATE = os.path.join(HERE, ".month_end_journey.json")
#: the VOLUME version per side: (version, default rows)
VOLUME = {"cloud": (7100, 600_000), "onprem": (9100, 400_000)}


def _sqls():
    c_sql, p_sql = load_queries(SPEC)
    c_sql = c_sql.replace(SPEC["from_cloud"], CLOUD_TABLE)
    p_sql = p_sql.replace(SPEC["from_onprem"], PREM_TABLE)
    # the version filter: each side reads the version ITS environment's
    # message announced (the Upstream Contract's {version})
    wrap = "SELECT * FROM (\n{}\n) q WHERE q.snap_version = {{version}}"
    return wrap.format(c_sql), wrap.format(p_sql), c_sql, p_sql


def _rows(side, types, version, n):
    out = []
    for i in range(n):
        v = row_values(side, types, BD, ENTITY, EVENT, i)
        for k, c in enumerate(types):
            if c == "SNAP_VERSION":
                v[k] = version
            if c == "SOURCE_DATA_ROW":
                v[k] = f"{side}:v{version}:{i}"
        out.append(v)
    return out


#: cells (rows x columns) per seeding INSERT: one 600,000-row x 460-column
#: INSERT (276M cells) OOM-killed the 6 GB qs-trino on 2026-10-13; the 40M
#: proof's 500,000 x 75 chunk was 37.5M.  Sized by CELLS, not rows.
SEED_CELLS_PER_INSERT = 30_000_000


def _volume_sql(table: str, types: dict, side: str, version: int, n: int, offset: int = 0) -> str:
    """N rows of ONE upstream version for the month-end partition, generated
    ON the cluster (sequence() caps at 10,000, so the row id is a x b).  The
    same values ``_rows`` writes, as SQL; SOURCE_DATA_ROW is
    ``<side>:<row id>:v<version>`` so the file's control totals can be
    recomputed from the file itself."""
    a = min(n, 10000)
    b = (n + a - 1) // a
    exprs = []
    for c, t in types.items():
        if c == "SNAP_VERSION":
            e = f"CAST({version} AS {t})"
        elif c == "SOURCE_DATA_ROW":
            e = f"concat('{side}:', CAST(id AS VARCHAR), ':v{version}')"
        elif c == "CODE":
            e = f"'{ENTITY}'"
        elif c == "BUSINESSEVENT":
            e = f"'{EVENT}'"
        elif t == "DATE":
            e = f"DATE '{BD.isoformat()}'"
        elif t == "BIGINT":
            e = "CAST(id AS BIGINT)"
        elif t == "DOUBLE":
            e = "CAST(id AS DOUBLE) + 0.5"
        else:
            e = f"concat('{abbr(c)}{side[0]}', CAST(id % 997 AS VARCHAR))"
        exprs.append(f"{e} AS {c.lower()}")
    return (f"INSERT INTO {table} ({', '.join(c.lower() for c in types)}) "
            f"SELECT {', '.join(exprs)} FROM (SELECT (x - 1) * {b} + y + {offset} AS id "
            f"FROM UNNEST(sequence(1, {a})) t1(x) CROSS JOIN UNNEST(sequence(1, {b})) t2(y)) "
            f"WHERE id <= {n + offset}")


def _truth(table: str, version: int) -> dict:
    out = cloud_cli(f"SELECT count(*), sum(snap_version), "
                    f"sum(CAST(split_part(source_data_row, ':', 2) AS BIGINT)) FROM {table} "
                    f"WHERE snap_version = {version}").strip().replace('"', "")
    n, s1, s2 = out.split("\t")
    return {"rows": int(n), "sum_snap": int(s1 or 0), "sum_id": int(s2 or 0)}


def volume(cloud_rows: int, prem_rows: int) -> dict:
    """Load the VOLUME version on both sides (replacing an earlier load of
    the same version), timed, and keep its truth for ``verify``."""
    import time
    _, _, c_raw, p_raw = _sqls()
    _, c_types = parse_query(c_raw, SPEC["alias"])
    _, p_types = parse_query(p_raw, SPEC["alias"])
    st = json.load(open(STATE, encoding="utf-8"))
    out = {}
    for side, table, types, n in (("cloud", CLOUD_TABLE, c_types, cloud_rows),
                                  ("onprem", PREM_TABLE, p_types, prem_rows)):
        ver = VOLUME[side][0]
        t0 = time.time()
        cloud_cli(f"DELETE FROM {table} WHERE snap_version = {ver}")
        chunk = max(10_000, SEED_CELLS_PER_INSERT // max(1, len(types)))
        done = 0
        while done < n:
            k = min(chunk, n - done)
            cloud_cli(_volume_sql(table, types, side, ver, k, offset=done) + ";\n", stdin=True)
            done += k
        tr = _truth(table, ver)
        if tr["rows"] != n:
            raise SystemExit(f"{side}: loaded {tr['rows']} rows, asked for {n}")
        out[side] = {"version": ver, "table": table, "columns": len(types),
                     "seconds": round(time.time() - t0, 1), **tr}
    st["volume"] = out
    with open(STATE, "w", encoding="utf-8") as f:
        json.dump(st, f, indent=1)
    return out


def verify(r: Rig, feed: str) -> dict:
    """The newest delivered file of the month-end task against the VOLUME
    truth: lines, the sum of the version column and the sum of the row ids,
    recomputed FROM THE FILE on the SFTP server; and the run's own record."""
    from volume_feed_proof import file_totals
    st = json.load(open(STATE, encoding="utf-8"))
    vol = st.get("volume") or {}
    if not vol:
        raise SystemExit("no volume version loaded: run `volume` first")
    t = status(r, feed)
    dels = t.get("deliveries") or []
    if not dels:
        return {"verdict": "NOT DELIVERED", "task": t.get("status")}
    d = dels[0]
    # a Spark-delivered run before 2026-10-13 recorded no file NAME (fixed in
    # core/spark_k8s/completion.py) -- read the file its destination names
    fname = d.get("file") or str(d.get("destination") or "").rsplit("/", 1)[-1]
    got = file_totals(fname, 0)
    want = {"rows": sum(v["rows"] for v in vol.values()),
            "sum_snap": sum(v["sum_snap"] for v in vol.values()),
            "sum_id": sum(v["sum_id"] for v in vol.values())}
    checks = {k: (got.get(k), want[k], got.get(k) == want[k]) for k in want}
    checks["run total_rows"] = (d.get("rows"), want["rows"], d.get("rows") == want["rows"])
    sides = t.get("sides") or {}
    for side, key in (("cloud", "primary"), ("onprem", "secondary")):
        s = sides.get(key) or {}
        checks[f"{side} rows read"] = (s.get("rows"), vol[side]["rows"], s.get("rows") == vol[side]["rows"])
        checks[f"{side} rows reported"] = (s.get("reported"), vol[side]["rows"], s.get("reported") == vol[side]["rows"])
    ok = all(v[2] for v in checks.values()) and want["rows"] > 0
    return {"verdict": "PASS" if ok else "FAIL", "file": fname, "file_named_by_record": bool(d.get("file")),
            "bytes": got.get("bytes"),
            "run_date": d.get("run_date"), "checks": checks}


def _ensure_connection(r: Rig, name: str, body: dict) -> int:
    hit = next((x for x in connections(r) if x.get("name") == name), None)
    if hit:
        return int(hit["id"])
    s, b = r.call("POST", "/api/connections", {"name": name, **body})
    if s not in (200, 201):
        raise SystemExit(f"connection {name}: {s} {str(b)[:200]}")
    return int(b["id"])


def prepare(r: Rig) -> dict:
    # connections, named for what they are.  The cloud one copies the
    # non-secret fields of the rig's Trino on the iceberg_aws catalog (the
    # catalog itself holds the AWS credentials -- the connection needs none)
    src = next((x for x in connections(r) if str((x.get("config") or {}).get("catalog")) == "iceberg_aws"), None)
    if not src:
        raise SystemExit("no Trino connection on the iceberg_aws catalog to copy")
    cloud_cfg = {k: v for k, v in (src.get("config") or {}).items()
                 if k in ("host", "port", "user", "http_scheme", "catalog")}
    cloud_cfg = {**cloud_cfg, "schema": "month_end"}
    cloud_id = _ensure_connection(r, CLOUD_CONN, {"connection_type": "trino", "config": cloud_cfg})
    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    prem_id = _ensure_connection(r, PREM_CONN, {"connection_type": "starburst", "config": {
        "host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic", "password": pw,
        "http_scheme": "https", "verify_ssl": False, "catalog": "iceberg", "schema": "qs"}})
    ora_id = next(x["id"] for x in connections(r) if x.get("name") == "oracle-otg")
    ensure_oracle_table(ora_id)
    oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE CODE = '{ENTITY}'"], connection_id=ora_id)

    # the data: every version's rows on both sides (fresh tables each prepare)
    _, _, c_raw, p_raw = _sqls()
    _, c_types = parse_query(c_raw, SPEC["alias"])
    _, p_types = parse_query(p_raw, SPEC["alias"])
    cloud_cli(f"CREATE SCHEMA IF NOT EXISTS {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/month_end')")
    for t in (CLOUD_TABLE, PREM_TABLE):
        cloud_cli(f"DROP TABLE IF EXISTS {t}")
    cloud_cli(ddl(CLOUD_TABLE, c_types, hive=False) + ";\n", stdin=True)
    cloud_cli(ddl(PREM_TABLE, p_types, hive=False) + ";\n", stdin=True)
    insert_rows(cloud_cli, CLOUD_TABLE, c_types, [x for cv, cn, _, _ in VERSIONS.values()
                                                  for x in _rows("cloud", c_types, cv, cn)])
    insert_rows(cloud_cli, PREM_TABLE, p_types, [x for _, _, pv, pn in VERSIONS.values()
                                                 for x in _rows("prem", p_types, pv, pn)])

    s, cals = r.call("GET", "/api/admin/feed-calendars")
    names = {c.get("name") for c in ((cals or {}).get("items") if isinstance(cals, dict) else cals) or []}
    if CALENDAR not in names:
        r.call("POST", "/api/admin/feed-calendars", {"name": CALENDAR, "weekend_days": [6, 7], "holidays": []})

    cloud_sql, prem_sql, _, _ = _sqls()
    out = {"business_date": BD.isoformat(), "entity": ENTITY, "event": EVENT, "data_source": DS,
           "cloud_connection": CLOUD_CONN, "cloud_connection_id": cloud_id,
           "prem_connection": PREM_CONN, "prem_connection_id": prem_id,
           "cloud_table": CLOUD_TABLE, "prem_table": PREM_TABLE, "calendar": CALENDAR,
           "columns": {"cloud": len(c_types), "on_prem": len(p_types)},
           "dependency_cloud": f"{DS}_{ENTITY}_{EVENT}_CLOUD",
           "dependency_onprem": f"{DS}_{ENTITY}_{EVENT}_ONPREM",
           "kafka_topic": "qs.kafka.message", "oracle_table": ORA_TABLE, "oracle_connection_id": ora_id,
           "versions": {str(k): {"cloud_version": v[0], "cloud_rows": v[1],
                                 "onprem_version": v[2], "onprem_rows": v[3]} for k, v in VERSIONS.items()},
           "cloud_sql": cloud_sql, "prem_sql": prem_sql}
    with open(STATE, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    return out


def send(side: str, n: int, use_volume: bool = False) -> dict:
    """ONE message by hand: CLOUD on the Kafka topic, ON-PREM as a row of the
    QS_KAFKA_MESSAGE table -- the version's number and its row count.
    ``use_volume``: the loaded VOLUME version and its exact count."""
    if use_volume:
        vol = json.load(open(STATE, encoding="utf-8")).get("volume") or {}
        if side not in vol:
            raise SystemExit("no volume version loaded: run `volume` first")
        cv = pv = vol[side]["version"]
        cn = pn = vol[side]["rows"]
    else:
        cv, cn, pv, pn = VERSIONS[n]
    seq = int(dt.datetime.now().timestamp()) % 10_000_000
    if side == "cloud":
        m = {**message(DS, ENTITY, EVENT, BD, True, "COMPLETE", cn, seq),
             "SNAP_VERSION": str(cv), "VERSION_NUMBER": str(cv)}
        produce_kafka([m])
        return {"side": "CLOUD", "road": "Kafka topic qs.kafka.message", "version": cv, "rows": cn}
    st = json.load(open(STATE, encoding="utf-8"))
    m = {**message(DS, ENTITY, EVENT, BD, False, "COMPLETE", pn, seq),
         "SNAP_VERSION": str(pv), "VERSION_NUMBER": str(pv)}
    ora_rows(int(st["oracle_connection_id"]), [m])
    return {"side": "ON-PREM", "road": f"a row of {ORA_TABLE}", "version": pv, "rows": pn}


DAILY_LOG = os.path.join(HERE, ".month_end_daily_log.jsonl")
DAILY_DOC = os.path.join(os.path.dirname(os.path.dirname(HERE)), "docs", "MONTH_END_DAILY_RESENDS.html")
#: the October month end on BUSINESS_DAYS_MON_FRI (Sat 31 Oct rolls back)
OCTOBER_MONTH_END = dt.date(2026, 10, 30)


def _announce(side: str, version: int, rows: int) -> dict:
    """ONE upstream message: CLOUD on the Kafka topic, ON-PREM as a row of
    QS_KAFKA_MESSAGE -- the version and its exact row count."""
    seq = int(dt.datetime.now().timestamp()) % 10_000_000
    m = {**message(DS, ENTITY, EVENT, BD, side == "cloud", "COMPLETE", rows, seq),
         "SNAP_VERSION": str(version), "VERSION_NUMBER": str(version)}
    if side == "cloud":
        produce_kafka([m])
        return {"side": "CLOUD", "road": "Kafka topic qs.kafka.message", "version": version, "rows": rows}
    st = json.load(open(STATE, encoding="utf-8"))
    ora_rows(int(st["oracle_connection_id"]), [m])
    return {"side": "ON-PREM", "road": f"a row of {ORA_TABLE}", "version": version, "rows": rows}


def _daily_report() -> None:
    """docs/MONTH_END_DAILY_RESENDS.html from the log, newest first."""
    import html as _h
    rows = []
    if os.path.exists(DAILY_LOG):
        rows = [json.loads(x) for x in open(DAILY_LOG, encoding="utf-8") if x.strip()]
    tr = []
    for r in reversed(rows):
        ok = r.get("verdict") == "PASS"
        cls = "ok" if ok else ("" if r.get("verdict") in ("stopped", "held") else "bad")
        tr.append("<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td class='{}'>{}</td><td>{}</td></tr>".format(
            _h.escape(str(r.get("run_date"))), _h.escape(str(r.get("cloud", ""))), _h.escape(str(r.get("onprem", ""))),
            _h.escape(str(r.get("delivered_rows", ""))), _h.escape(str(r.get("file", ""))), cls,
            _h.escape(str(r.get("verdict"))), _h.escape(str(r.get("note", "")))))
    page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Month-end daily re-sends</title>
<style>:root{{--fg:#1f2328;--muted:#59636e;--line:#d1d9e0;--bg:#fff;--code:#f6f8fa}}
@media (prefers-color-scheme:dark){{:root{{--fg:#e6edf3;--muted:#9198a1;--line:#3d444d;--bg:#0d1117;--code:#161b22}}}}
body{{font:15px/1.55 system-ui,sans-serif;color:var(--fg);background:var(--bg);max-width:1180px;margin:0 auto;padding:24px 16px}}
table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid var(--line);padding:6px 8px;text-align:left}}th{{background:var(--code)}}
.ok{{color:#1a7f37;font-weight:700}}.bad{{color:#cf222e;font-weight:700}}.sub{{color:var(--muted)}}</style></head><body>
<h1>Month-end daily re-sends</h1>
<p class="sub">Feed <b>{FEED}</b> · business date <b>{BD.isoformat()}</b> (the September month end) · one new upstream version a day on
CLOUD (Kafka) and ON-PREM (QS_KAFKA_MESSAGE) until the October month end ({OCTOBER_MONTH_END.isoformat()}).
Each day the re-send policy re-runs the feed by itself and the file is named with that day's run date.
Run by <code>scripts/docker_proof/month_end_journey.py daily</code> (Windows Task Scheduler, "QueryStudio month-end daily re-send").</p>
<table><tr><th>Run date</th><th>CLOUD version / rows</th><th>ON-PREM version / rows</th><th>Delivered rows</th><th>File</th><th>Result</th><th>Note</th></tr>
{''.join(tr) or '<tr><td colspan=7>No day has run yet.</td></tr>'}
</table></body></html>
"""
    with open(DAILY_DOC, "w", encoding="utf-8", newline="\n") as f:
        f.write(page)


def daily(r: Rig, feed: str, approve_held: bool = False, wait_s: int = 1500) -> dict:
    """One day of the daily re-send test (see the module docstring)."""
    import time
    today = dt.datetime.now(dt.timezone.utc).date()
    out: dict = {"run_date": today.isoformat(), "at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}

    def _log(rec: dict) -> dict:
        with open(DAILY_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")
        _daily_report()
        return rec

    if today >= OCTOBER_MONTH_END:
        return _log({**out, "verdict": "stopped",
                     "note": "the October month end has come: September is closed to re-sends"})
    st = json.load(open(STATE, encoding="utf-8"))
    k = int(st.get("daily_next") or 1)
    cv, pv = 7200 + k, 9200 + k                    # each environment numbers its own versions
    cn, pn = 3 + k % 4, 4 + k % 3
    _, _, c_raw, p_raw = _sqls()
    _, c_types = parse_query(c_raw, SPEC["alias"])
    _, p_types = parse_query(p_raw, SPEC["alias"])
    for table, types, side, ver, n in ((CLOUD_TABLE, c_types, "cloud", cv, cn), (PREM_TABLE, p_types, "prem", pv, pn)):
        cloud_cli(f"DELETE FROM {table} WHERE snap_version = {ver}")
        insert_rows(cloud_cli, table, types, _rows(side, types, ver, n))
    st["daily_next"] = k + 1
    with open(STATE, "w", encoding="utf-8") as f:
        json.dump(st, f, indent=1)
    out.update({"cloud": f"{cv} / {cn}", "onprem": f"{pv} / {pn}"})

    before = len(status(r, feed).get("deliveries") or [])
    _announce("cloud", cv, cn)
    time.sleep(60)                                 # the two sides arrive apart, as upstream does
    _announce("onprem", pv, pn)

    t0 = time.time()
    task: dict = {}
    while time.time() - t0 < wait_s:
        time.sleep(20)
        task = status(r, feed)
        dels = task.get("deliveries") or []
        if len(dels) > before and dels[0].get("run_date") == today.isoformat():
            break
        held = [i for i in ((task.get("superseded") or {}).get("decision_ids") or [])]
        rs = (task.get("superseded") or {}).get("restatement") or {}
        if approve_held and held and rs.get("action") == "hold":
            r.call("POST", f"/api/feed-regeneration-decisions/{held[-1]}/answer",
                   {"action": "rerun", "reason": "daily re-send test: approved by the harness"})
    dels = task.get("deliveries") or []
    if not dels or len(dels) <= before or dels[0].get("run_date") != today.isoformat():
        rs = (task.get("superseded") or {}).get("restatement") or {}
        verdict = "held" if rs.get("action") == "hold" else "FAIL"
        return _log({**out, "verdict": verdict, "task": task.get("status"),
                     "note": rs.get("why") or f"no delivery on {today} within {wait_s} s"})
    d = dels[0]
    read = {v.get("environment"): v.get("version") for v in d.get("versions") or []}
    checks = {"rows": d.get("rows") == cn + pn,
              "cloud version read": str(read.get("CLOUD")) == str(cv),
              "on-prem version read": str(read.get("ON-PREM")) == str(pv)}
    return _log({**out, "verdict": "PASS" if all(checks.values()) else "FAIL",
                 "delivered_rows": d.get("rows"), "file": d.get("file"), "why": d.get("why"),
                 "minutes": round((time.time() - t0) / 60, 1),
                 "note": "; ".join(k for k, v in checks.items() if not v) or d.get("why")})


#: the cloud table on the DIRECT AWS S3 connection (registered there by
#: ``road --road s3``; QueryStudio's S3 engine reads it, Iceberg-correct)
S3_CONN_NAME, S3_TABLE = "aws-real", "fact_tetb_month_end"
ROADS = {"s3": "FACT_TETB_SAP_2920_EMEA_MONTH_END_S3",
         "starburst": "FACT_TETB_SAP_2920_EMEA_MONTH_END_SB"}
ROAD_WORDS = {"s3": "Month end. Cloud data read straight from AWS S3; on-prem data from Starburst.",
              "starburst": "Month end. Cloud and on-prem data both read through Starburst."}


def _feed_by_name(r: Rig, name: str):
    s, items = r.call("GET", "/api/feeds?limit=5000")
    rows = items if isinstance(items, list) else (items or {}).get("items") or []
    return next((x for x in rows if x.get("name") == name), None)


def road(r: Rig, which: str) -> dict:
    """The month-end feed cloned onto another road (module docstring)."""
    st = json.load(open(STATE, encoding="utf-8"))
    base = _feed_by_name(r, FEED)
    if not base:
        raise SystemExit(f"{FEED} not found -- run the journey first")
    name = ROADS[which]
    conns = {c["name"]: c for c in connections(r)}
    cloud_sql = st["cloud_sql"]
    if which == "s3":
        s3 = conns[S3_CONN_NAME]
        loc = cloud_cli(f'SELECT file_path FROM {CLOUD_SCHEMA}."fact_tetb$files" LIMIT 1').strip().strip('"')
        prefix = loc.split(f"s3://{AWS_BUCKET}/", 1)[1].split("/data/", 1)[0] + "/"
        reg = {t["name"] for t in (s3.get("config") or {}).get("registered_tables") or []}
        if S3_TABLE not in reg:
            s_, b_ = r.call("POST", f"/api/connections/{s3['id']}/tables", {
                "name": S3_TABLE, "s3_prefix": prefix, "format": "iceberg",
                "description": "the owner's month-end fact_tetb (460 columns), read DIRECTLY from AWS S3",
                "partition_columns": ["business_close_date", "code", "businessevent"]})
            if s_ not in (200, 201):
                raise RuntimeError(f"register {S3_TABLE} refused: {s_} {str(b_)[:200]}")
        cloud_conn, cloud_sql = s3["id"], cloud_sql.replace(CLOUD_TABLE, S3_TABLE)
    else:
        # 2026-10-13 -- the first cut ran the ON-PREM SQL alone on Starburst
        # (no cloud side; refused by the engine: its {version} had no
        # environment).  Both sides, the journey's own file, on Starburst.
        sb = st["prem_connection_id"]
        s_, src = r.call("GET", f"/api/sql-files/{base['source_id']}")
        files_ = r.call("GET", "/api/sql-files")[1]
        files_ = files_ if isinstance(files_, list) else (files_ or {}).get("items") or (files_ or {}).get("files") or []
        sb_name = f"{src['name']}_starburst"
        sb_file = next((x for x in files_ if x.get("name") == sb_name), None)
        if not sb_file:
            s_, sb_file = r.call("POST", "/api/sql-files", {
                "name": sb_name, "sql": src.get("content") or src.get("sql"), "secondary_sql": src["secondary_content"],
                "connection_id": sb, "secondary_connection_id": sb, "combine_mode": "union",
                "description": "the month-end fact_tetb query, BOTH sides run by Starburst"})
            if s_ not in (200, 201):
                raise SystemExit(f"sql file: {s_} {str(sb_file)[:300]}")
        cloud_conn = sb
    out = {"road": which, "feed": name, "cloud_connection_id": cloud_conn}
    feed = _feed_by_name(r, name)
    if not feed:
        # the clone gets its OWN file name (two feeds, one SFTP folder)
        s_, b_ = r.call("POST", f"/api/feeds/{base['id']}/clone", {
            "name": name,
            "output_filename_template": f"fact_tetb_sap_2920_emea_{which}_{{business_date:YYYYMMDD}}_{{run_date:YYYYMMDD}}.csv"})
        if s_ not in (200, 201):
            raise RuntimeError(f"clone refused: {s_} {str(b_)[:300]}")
        feed = b_.get("feed") or b_
    fid = int(feed["id"])
    qp = {"sql": cloud_sql, "SYSTEM_ENTITY": ENTITY, "EventCode": EVENT}
    if which == "starburst":
        qp = {"SYSTEM_ENTITY": ENTITY, "EventCode": EVENT}
    body = {"source_type": "raw_sql" if which == "s3" else "sql_file",
            "source_id": 0 if which == "s3" else int(sb_file["id"]),
            "connection_id": cloud_conn, "query_params": qp,
            "output_filename_template": f"fact_tetb_sap_2920_emea_{which}_{{business_date:YYYYMMDD}}_{{run_date:YYYYMMDD}}.csv",
            "description": ROAD_WORDS[which], "is_active": True}
    if which == "s3":
        qp["secondary_raw_sql"] = st["prem_sql"]
        body.update({"secondary_connection_id": st["prem_connection_id"], "secondary_source_type": "raw_sql",
                     "combine_mode": "union"})
    s_, b_ = r.call("PUT", f"/api/feeds/{fid}", body)
    if s_ != 200:
        raise RuntimeError(f"update {name} refused: {s_} {str(b_)[:400]}")
    s_, pol = r.call("GET", "/api/admin/feed-restatement-policies")
    base_pol = next((x for x in pol["policies"] if x.get("scope") == "feed" and x.get("scope_id") == base["id"]), None)
    if base_pol and not any(x.get("scope") == "feed" and x.get("scope_id") == fid for x in pol["policies"]):
        r.call("PUT", "/api/admin/feed-restatement-policies", {
            "scope": "feed", "scope_id": fid, "name": base_pol["name"], "on_new_message": base_pol["on_new_message"],
            "same_run_date": base_pol["same_run_date"], "window": base_pol["window"], "window_days": base_pol["window_days"]})
    out.update({"feed_id": fid, "sod": sod(r, name)})
    return out


def sod(r: Rig, feed: str) -> dict:
    """Start of day for the month end, for THIS feed (what the scheduler's
    00:00 pass does; the screen's Run SOD Now would run it for every feed
    on the rig).  The task it makes waits on the feed's dependencies."""
    s, items = r.call("GET", "/api/feeds?limit=5000")
    rows = items if isinstance(items, list) else (items or {}).get("items") or []
    fid = next(int(x["id"]) for x in rows if x.get("name") == feed)
    s, b = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={BD.isoformat()}&feed_ids={fid}",
                  timeout=600)
    return {"feed_id": fid, "status": s, "sod": b}


FEED = "FACT_TETB_SAP_2920_EMEA_MONTH_END_EOD"
SQL_FILE = "fact_tetb_month_end"


def reset(r: Rig, feed: str) -> dict:
    """Before a fresh run of the journey: the previous attempt's feed is
    RETIRED (renamed + deactivated -- a feed name stays reserved, and one that
    never ran may be renamed), its .sql file removed, and THIS entity's
    month-end messages and ledger rows cleared, so the new feed waits for
    both messages from nothing.  Touches only SAP-2920-EMEA / 2026-09-30."""
    done = {"retired": [], "sql_files": 0}
    s, items = r.call("GET", "/api/feeds?limit=5000")
    rows = items if isinstance(items, list) else (items or {}).get("items") or []
    stamp = dt.datetime.now().strftime("%H%M%S")
    for f in rows:
        if str(f.get("name") or "").upper() == feed.upper() and f.get("is_active", True):
            # a name that has had a task stays reserved: retire it, never rename
            s, b = r.call("PUT", f"/api/feeds/{f['id']}", {"is_active": False,
                                                          "display_name": f"retired attempt {stamp}"})
            done["retired"].append((f["id"], s))
    s, files = r.call("GET", "/api/sql-files?limit=500")
    for f in (files.get("items") if isinstance(files, dict) else files) or []:
        if str(f.get("name") or "").replace(".sql", "") == SQL_FILE:
            r.call("DELETE", f"/api/sql-files/{f['id']}")
            done["sql_files"] += 1
    deps = (f"'{DS}_{ENTITY}_{EVENT}_CLOUD'", f"'{DS}_{ENTITY}_{EVENT}_ONPREM'")
    psql(f"delete from dependency_events where business_date = '{BD}' and dependency_name in ({', '.join(deps)})")
    psql(f"delete from feed_regeneration_decisions where business_date = '{BD}' and dependency_name in ({', '.join(deps)})")
    psql(f"delete from kafka_messages where payload like '%{ENTITY}%' and payload like '%{BD}%'")
    st = json.load(open(STATE, encoding="utf-8"))
    oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE CODE = '{ENTITY}'"], connection_id=int(st["oracle_connection_id"]))
    return done


def hostkey() -> dict:
    from monthly_kafka_merge_feeds_proof import sftp_host_key
    return {"host_key": sftp_host_key()}


def status(r: Rig, feed: str) -> dict:
    s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={feed}")
    tasks = [x for g in (d or {}).get("groups") or [] for x in g["tasks"]]
    return tasks[0] if tasks else {}


def _with_retry(fn, *a, tries: int = 6):
    """The rig's Docker Desktop resets connections for ~30 s now and then:
    retry a transport failure, never a real answer."""
    import time
    last = None
    for _ in range(tries):
        try:
            return fn(*a)
        except (SystemExit, ConnectionError, OSError) as exc:     # login failed: transport reset
            last = exc
            time.sleep(8)
    raise RuntimeError(f"rig unreachable after {tries} tries: {last}")


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("prepare")
    s = sub.add_parser("send")
    s.add_argument("--side", choices=["cloud", "onprem"], required=True)
    s.add_argument("--n", type=int, default=1)
    s.add_argument("--volume", action="store_true", help="announce the loaded VOLUME version")
    v = sub.add_parser("volume")
    v.add_argument("--cloud", type=int, default=VOLUME["cloud"][1])
    v.add_argument("--onprem", type=int, default=VOLUME["onprem"][1])
    vf = sub.add_parser("verify")
    vf.add_argument("--feed", default=FEED)
    rd = sub.add_parser("road")
    rd.add_argument("--road", choices=sorted(ROADS), required=True)
    dy = sub.add_parser("daily")
    dy.add_argument("--feed", default=FEED)
    dy.add_argument("--approve-held", action="store_true",
                    help="approve a same-day re-run hold (a second run on one day)")
    t = sub.add_parser("status")
    t.add_argument("--feed", required=True)
    o = sub.add_parser("sod")
    o.add_argument("--feed", required=True)
    sub.add_parser("hostkey")
    rs = sub.add_parser("reset")
    rs.add_argument("--feed", required=True)
    a = ap.parse_args()
    if a.cmd == "prepare":
        out = prepare(Rig())
    elif a.cmd == "send":
        out = send(a.side, a.n, a.volume)
    elif a.cmd == "volume":
        out = volume(a.cloud, a.onprem)
    elif a.cmd == "verify":
        out = _with_retry(lambda: verify(Rig(), a.feed))
    elif a.cmd == "road":
        out = _with_retry(lambda: road(Rig(), a.road))
    elif a.cmd == "daily":
        out = daily(_with_retry(Rig), a.feed, approve_held=a.approve_held)
    elif a.cmd == "sod":
        out = _with_retry(lambda: sod(Rig(), a.feed))
    elif a.cmd == "hostkey":
        out = hostkey()
    elif a.cmd == "reset":
        out = _with_retry(lambda: reset(Rig(), a.feed))
    else:
        out = _with_retry(lambda: status(Rig(), a.feed))
    print(json.dumps(out, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
