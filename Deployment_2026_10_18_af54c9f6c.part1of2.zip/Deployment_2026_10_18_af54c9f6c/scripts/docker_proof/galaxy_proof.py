"""The owner's REAL Starburst Galaxy account, through every QueryStudio road
(2026-10-11).  What only a real Galaxy proves (docs/STARBURST_READINESS_2026_10_08.html
section 4): a PUBLIC CA chain validated with nothing pasted, a service-account
login, the account's role, cluster wake-up -- and then the ordinary journeys
(browse, SQL editor, dataset -> report uncapped, saved query -> feed) judged
against Galaxy's OWN answer (the trino client from this host, no QueryStudio
code on the path).

    . ~/.qs_keys/rigpw.sh
    . ~/.qs_keys/starburst.env      # STARBURST_HOST / _PORT / _HTTP_SCHEME / _USER / _PASSWORD
    python scripts/docker_proof/galaxy_proof.py [--role accountadmin] [--catalog tpch --schema sf1]

Everything created (connection, dataset, report, saved query, feed) is removed
in a finally.  Credentials are read from the environment and never printed.
"""
from __future__ import annotations

import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from auth_rls_proof import Session  # noqa: E402
from cross_source_proof import check, low, poll, res, rows  # noqa: E402

TAG = str(int(time.time()))[-6:]


def galaxy_truth(sql: str, role: str | None):
    import trino
    from trino.auth import BasicAuthentication
    e = os.environ
    kw = {"roles": {"system": role}} if role else {}
    c = trino.dbapi.connect(host=e["STARBURST_HOST"], port=int(e.get("STARBURST_PORT", 443)),
                            http_scheme=e.get("STARBURST_HTTP_SCHEME", "https"), user=e["STARBURST_USER"],
                            auth=BasicAuthentication(e["STARBURST_USER"], e["STARBURST_PASSWORD"]),
                            request_timeout=600, **kw)
    cur = c.cursor()
    cur.execute(sql)
    return cur.fetchall()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--role", default=os.environ.get("STARBURST_ROLE", "accountadmin"))
    ap.add_argument("--catalog", default="tpch")
    ap.add_argument("--schema", default="sf1")
    args = ap.parse_args(argv)
    e = os.environ
    for k in ("STARBURST_HOST", "STARBURST_USER", "STARBURST_PASSWORD", "QS_RIG_ADMIN_PW"):
        if not e.get(k):
            raise SystemExit(f"{k} is not set -- source ~/.qs_keys/starburst.env and ~/.qs_keys/rigpw.sh")
    CAT, SCH, ROLE = args.catalog, args.schema, args.role
    admin = Session("rig_admin", e["QS_RIG_ADMIN_PW"])
    undo: list[str] = []

    def cfg(**over):
        c = {"host": e["STARBURST_HOST"], "port": int(e.get("STARBURST_PORT", 443)), "user": e["STARBURST_USER"],
             "auth_type": "basic", "password": e["STARBURST_PASSWORD"],
             "http_scheme": e.get("STARBURST_HTTP_SCHEME", "https"), "verify_ssl": True,
             "catalog": CAT, "schema": SCH, "role": ROLE}
        c.update(over)
        return c

    def connection(name, c):
        s, b, _ = admin.call("POST", "/api/connections", {"name": f"{name}-{TAG}", "connection_type": "starburst", "config": c})
        cid = (b or {}).get("id") if isinstance(b, dict) else None
        if cid:
            undo.insert(0, f"/api/connections/{cid}")
        return s, cid, b

    def sql_run(cid, sql):
        s, r, _ = admin.call("POST", "/api/sql/execute", {"primary_connection_id": cid, "primary_sql": sql, "row_limit": 1000})
        if s != 200 or not (r or {}).get("execution_id"):
            return s, (r or {}), []
        st, meta = poll(admin, r["execution_id"], timeout=1200)
        got = [low(x) for x in rows(admin, r["execution_id"], want=1000, size=1000)] if st == 200 else []
        return st, meta, got

    try:
        # ── truth from Galaxy itself (also wakes the cluster) ───────────────
        t0 = time.time()
        who = galaxy_truth("select current_user", ROLE)[0][0]
        wake = round(time.time() - t0, 1)
        t_cat = sorted(r[0] for r in galaxy_truth("show catalogs", ROLE))
        t_sch = sorted(r[0] for r in galaxy_truth(f"show schemas from {CAT}", ROLE))
        t_tab = sorted(r[0] for r in galaxy_truth(f"show tables from {CAT}.{SCH}", ROLE))
        t_grp = {r[0]: int(r[1]) for r in galaxy_truth(
            f"select returnflag, count(*) from {CAT}.{SCH}.lineitem group by 1", ROLE)}
        t_n_orders = int(galaxy_truth(f"select count(*) from {CAT}.{SCH}.orders", ROLE)[0][0])
        check("truth", f"Galaxy answers as the service account with role {ROLE} (first query {wake}s): "
              f"{len(t_cat)} catalogs, {len(t_tab)} tables in {CAT}.{SCH}, lineitem groups {sum(t_grp.values()):,} rows",
              bool(who) and t_cat and t_tab and sum(t_grp.values()) > 0, {"user_is_service_account": who == e["STARBURST_USER"]})

        # ── G1 the connection: public CA, nothing pasted, verify on ─────────
        s, G, b = connection("galaxy", cfg())
        check("G1", "a Starburst connection to Galaxy is created (HTTPS 443, verify_ssl on, NO CA pasted, role set)",
              bool(G), (s, str(b)[:200]))
        if not G:
            return 1
        s, b, _ = admin.call("POST", f"/api/connections/{G}/test")
        ok = s == 200 and (b or {}).get("success") is not False and "fail" not in str(b).lower()
        check("G1", "the connection TEST passes: the public chain validates from the default trust store", ok, str(b)[:300])

        # ── G2 browse == Galaxy ─────────────────────────────────────────────
        s, b, _ = admin.call("GET", f"/api/sql/connections/{G}/catalogs")
        got = sorted(x if isinstance(x, str) else (x.get("name") or x.get("catalog")) for x in
                     ((b or {}).get("catalogs") if isinstance(b, dict) else b) or [])
        check("G2", f"browse catalogs == Galaxy's SHOW CATALOGS ({len(t_cat)})", s == 200 and got == t_cat, {"got": got, "want": t_cat})
        s, b, _ = admin.call("GET", f"/api/sql/connections/{G}/schemas?catalog={CAT}")
        got = sorted(x if isinstance(x, str) else (x.get("name") or x.get("schema")) for x in
                     ((b or {}).get("schemas") if isinstance(b, dict) else b) or [])
        check("G2", f"browse schemas of {CAT} == Galaxy", s == 200 and got == t_sch, {"got": got[:12], "want": t_sch[:12]})
        s, b, _ = admin.call("GET", f"/api/sql/connections/{G}/tables?catalog={CAT}&schema={SCH}")
        got = sorted(x if isinstance(x, str) else (x.get("name") or x.get("table")) for x in
                     ((b or {}).get("tables") if isinstance(b, dict) else b) or [])
        check("G2", f"browse tables of {CAT}.{SCH} == Galaxy", s == 200 and got == t_tab, {"got": got, "want": t_tab})

        # ── G3 SQL editor: a GROUP BY over 6M rows == Galaxy ────────────────
        st, meta, got = sql_run(G, f"select returnflag, count(*) as n from {CAT}.{SCH}.lineitem group by 1")
        g = {r["returnflag"]: int(r["n"]) for r in got}
        check("G3", f"SQL editor GROUP BY over lineitem == Galaxy ({sum(t_grp.values()):,} rows, {len(t_grp)} groups)",
              st == 200 and g == t_grp and sum(g.values()) > 0, {"status": st, "got": g, "want": t_grp, "err": str(meta)[:200] if st != 200 else ""})

        # ── G4 dataset -> report, uncapped == Galaxy ────────────────────────
        s, ds, _ = admin.call("POST", "/api/datasets", {
            "name": f"galaxy_ds_{TAG}", "subject": "galaxy", "connection_ids": [G],
            "base_query": f"select orderkey, orderstatus, orderpriority from {CAT}.{SCH}.orders"})
        if check("G4", "dataset on Galaxy created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:200])):
            undo.insert(0, f"/api/datasets/{ds['id']}")
            s, b, _ = admin.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
            cols = {c["physical_name"].lower(): c for c in admin.call("GET", f"/api/datasets/{ds['id']}")[1]["columns"]}
            check("G4", "auto-detect read the three columns from Galaxy", {"orderkey", "orderstatus", "orderpriority"} <= set(cols), sorted(cols))
            for col in cols.values():
                admin.call("PUT", f"/api/datasets/columns/{col['id']}", {"column_type": "dimension"})
            s, rep, _ = admin.call("POST", "/api/business-reports", {
                "name": f"galaxy-rep-{TAG}", "dataset_id": ds["id"], "data_source_type": "dataset",
                "column_ids": [cols[k]["id"] for k in ("orderkey", "orderstatus", "orderpriority") if k in cols]})
            if check("G4", "report on it created", s == 200 and (rep or {}).get("id"), (s, str(rep)[:200])):
                undo.insert(0, f"/api/business-reports/{rep['id']}")
                s, ex, _ = admin.call("POST", f"/api/business-reports/{rep['id']}/execute",
                                      {"parameter_values": {}, "force_refresh": True, "limit_override": 0})
                ex = ex if isinstance(ex, dict) else {}
                tot = int(ex.get("total_rows") or 0)
                check("G4", f"report run UNCAPPED: {t_n_orders:,} rows == Galaxy's count(*), truncated is False",
                      s == 200 and tot == t_n_orders and ex.get("truncated") is False,
                      {"status": s, "total": tot, "want": t_n_orders, "body": str(ex)[:200] if s != 200 else ""})

        # ── G5 saved query -> feed (native) == Galaxy ───────────────────────
        agg = f"select returnflag, count(*) as n from {CAT}.{SCH}.lineitem group by returnflag"
        s, q, _ = admin.call("POST", "/api/queries", {"name": f"galaxy_sq_{TAG}", "query_config": {"files": [], "raw_sql": agg, "connection_id": G}})
        if check("G5", "saved query on Galaxy created", s in (200, 201) and (q or {}).get("id"), (s, str(q)[:160])):
            undo.append(f"/api/queries/{q['id']}")
            s, fb, _ = admin.call("POST", "/api/feeds", {
                "name": f"GALAXY_FEED_{TAG}", "source_type": "saved_query", "source_id": q["id"], "connection_id": G,
                "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
                "execution_backend": "native"})
            if check("G5", "feed on the native lane created", s == 200 and (fb or {}).get("id"), (s, str(fb)[:300])):
                undo.insert(0, f"/api/feeds/{fb['id']}")
                s, ex, _ = admin.call("POST", f"/api/feeds/{fb['id']}/execute", {"trigger_type": "manual"})
                dbid = (ex or {}).get("execution_db_id")
                ev, t1 = {}, time.time()
                while dbid and time.time() - t1 < 1200:
                    _, ev, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                    if (ev or {}).get("status") in ("completed", "failed", "error", "cancelled"):
                        break
                    time.sleep(2)
                ev = ev or {}
                import subprocess
                env = dict(os.environ, MSYS_NO_PATHCONV="1")
                body = ""
                if ev.get("destination_path"):
                    body = subprocess.run(["docker", "exec", "qs-local-api", "cat", ev["destination_path"]],
                                          capture_output=True, text=True, env=env).stdout
                    subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", ev["destination_path"]], env=env)
                lines = body.splitlines()
                hdr = [h.strip().strip('"').lower() for h in lines[0].split(",")] if lines else []
                got = {}
                for ln in lines[1:]:
                    if ln.strip():
                        rec = dict(zip(hdr, [v.strip('"') for v in ln.split(",")]))
                        got[rec.get("returnflag")] = int(float(rec.get("n") or 0))
                check("G5", "the delivered feed file == Galaxy's GROUP BY", ev.get("status") == "completed" and got == t_grp,
                      {"status": ev.get("status"), "got": got, "want": t_grp, "err": str(ev.get("error_message"))[:300]})

        # ── G6 a wrong password is the connection's fault, in words ─────────
        s, W, b = connection("galaxy-badpw", cfg(password="not-the-password"))
        if W:
            s, b, _ = admin.call("POST", f"/api/connections/{W}/test")
            msg = str(b)
            check("G6", "a wrong password: the test says the source rejected the login (401), no stack, no 'contact support'",
                  "401" in msg or "rejected the user name or password" in msg, msg[:300])
            s, b, _ = admin.call("GET", f"/api/sql/connections/{W}/catalogs")
            check("G6", "browse with the wrong password is a 4xx carrying that sentence (never 500 / 503)",
                  400 <= s < 500 and "Traceback" not in str(b), {"status": s, "detail": str(b)[:240]})
    finally:
        for path in undo:
            try:
                admin.call("DELETE", path)
            except Exception:  # noqa: BLE001
                pass
        print(f"\ncleanup: {len(undo)} objects removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
