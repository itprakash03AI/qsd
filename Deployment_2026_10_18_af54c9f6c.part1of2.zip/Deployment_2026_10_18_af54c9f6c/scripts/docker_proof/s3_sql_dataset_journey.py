"""An S3 custom-SQL dataset, built the way an analyst builds it -- live on Docker (2026-10-02).

The reported journey: write ``SELECT * FROM <registered S3 table> WHERE <date> = ...``
(it runs in the query builder), start a dataset from it, preview 10 rows -- refused
with "a 's3' connection cannot run SQL ... nothing is cached for this source".

This walks the whole journey on the running rig (login OFF) and judges by VALUE:
  1. the preview of that SQL returns rows and columns, every row inside the filter;
  2. a dataset is created from the SQL with the previewed columns, and auto-detect
     agrees with them;
  3. a report on the dataset (region, SUM(amt)) runs;
  4. its numbers equal the same aggregation run by the QUERY BUILDER's own path
     (POST /api/execute, raw SQL on the S3 connection) -- a separate code path,
     the one the user ran -- region by region, with a non-zero total.
Everything created is removed in a finally.

    python s3_sql_dataset_journey.py [--connection 1] [--table trades] [--date-col dt] [--date 2026-01-03]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402

res: list = []


def check(name, ok, detail=""):
    ok = bool(ok)
    res.append(ok)
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return ok


def call(m, p, b=None):
    s, body, _ = c.call(m, p, b)
    return s, body


def wait_execution(eid, timeout=300):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s, st = call("GET", f"/api/executions/{eid}/status")
        status = (st or {}).get("status") if isinstance(st, dict) else None
        if status in ("completed", "success", "finished"):
            s, rb = call("GET", f"/api/executions/{eid}/results?page_size=1000")
            return rb
        if status in ("failed", "error", "cancelled"):
            return {"failed": (st or {}).get("error_message")}
        time.sleep(0.5)
    return {"timeout": eid}


def rows_of(body):
    body = body or {}
    names = [x["name"] if isinstance(x, dict) else x for x in (body.get("columns") or [])]
    return [r if isinstance(r, dict) else dict(zip(names, r)) for r in (body.get("rows") or body.get("data") or [])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--connection", type=int, default=1)
    ap.add_argument("--table", default="trades")
    ap.add_argument("--date-col", default="dt")
    ap.add_argument("--date", default="2026-01-03")
    a = ap.parse_args()
    s, _ = call("GET", "/api/datasets")
    if s != 200:
        raise SystemExit(f"run on the login-OFF rig (anonymous /api/datasets answered {s})")
    tag = str(int(time.time()))[-6:]
    sql = f"select * from {a.table} where {a.date_col} = '{a.date}'"
    ledger = Ledger(lambda m, p, b=None, **k: call(m, p, b))
    try:
        # 1. preview -- the step that was refused
        s, pv = call("POST", "/api/datasets/preview", {"connection_id": a.connection, "sql": sql, "limit": 10})
        cols = [x["name"] if isinstance(x, dict) else x for x in (pv or {}).get("columns", [])] if s == 200 else []
        prow = rows_of(pv) if s == 200 else []
        check("preview of SELECT * on the S3 table returns rows and columns", s == 200 and cols and prow,
              (s, cols, len(prow)) if s == 200 else (s, pv))
        check(f"every previewed row is inside the filter ({a.date_col} = {a.date})",
              prow and all(str(r.get(a.date_col))[:10] == a.date for r in prow), [str(r.get(a.date_col))[:10] for r in prow][:5])
        if not (s == 200 and cols):
            return 1
        # 2. create the dataset from the SQL with the previewed columns
        s, ds = call("POST", "/api/datasets", {"name": f"s3sql_{tag}", "subject": "proof", "connection_ids": [a.connection],
                                              "base_query": sql})
        did = (ds or {}).get("id")
        if not check("a dataset is created from the SQL", s in (200, 201) and did, (s, str(ds)[:200])):
            return 1
        ledger.add("dataset", did, path=f"/api/datasets/{did}")
        s, det = call("POST", f"/api/datasets/{did}/auto-detect", {})
        s2, dcols = call("GET", f"/api/datasets/{did}/columns")
        dcols = dcols if isinstance(dcols, list) else (dcols or {}).get("columns") or []
        names = {(x.get("physical_name") or "").lower(): x for x in dcols}
        check("auto-detect gives the dataset the previewed columns", s == 200 and set(n.lower() for n in cols) <= set(names),
              (s, sorted(names)))
        region, amt = names.get("region"), names.get("amt")
        if not (region and amt):
            check("the dataset has region and amt to report on", False, sorted(names))
            return 1
        # 3. a report on the dataset
        s, rep = call("POST", "/api/business-reports", {"name": f"s3sql_rep_{tag}", "dataset_id": did,
                                                        "data_source_type": "dataset",
                                                        "column_ids": [region["id"], amt["id"]]})
        rid = (rep or {}).get("id")
        if not check("a report is built on the dataset", s == 200 and rid, (s, str(rep)[:200])):
            return 1
        ledger.add("business report", rid, path=f"/api/business-reports/{rid}")
        s, ex = call("POST", f"/api/business-reports/{rid}/execute", {"parameter_values": {}, "force_refresh": True})
        eid = (ex or {}).get("execution_id")
        s, res_body = call("GET", f"/api/business-reports/{rid}/results/{eid}?page_size=1000")
        report = {str(r.get("region")): round(float(r.get("amt") or 0), 2) for r in rows_of(res_body)}
        check("the report runs and returns region totals", report, report)
        # 4. the same numbers through the query builder's own path
        s, b = call("POST", "/api/execute", {"connection_id": a.connection, "cache_strategy": "bypass",
                                            "raw_sql": f"select region, sum(amt) as amt from {a.table} "
                                                       f"where {a.date_col} = '{a.date}' group by region"})
        eid2 = (b or {}).get("execution_id")
        qb = rows_of(wait_execution(eid2)) if eid2 else []
        truth = {str(r.get("region")): round(float(r.get("amt") or 0), 2) for r in qb}
        check("the query builder's path computes the same aggregation (non-zero)",
              truth and sum(truth.values()) != 0, (s, truth or b))
        check("report == query builder, region by region", report == truth and len(truth) > 0,
              {"report": report, "query_builder": truth})
    finally:
        ledger.cleanup(echo=lambda m: print("  " + m))
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
