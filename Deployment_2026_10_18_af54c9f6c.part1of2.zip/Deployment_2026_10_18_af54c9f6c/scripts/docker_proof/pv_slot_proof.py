"""Published views hold a slot in the process's global query cap -- live on Docker (2026-09-29).

Proves on the running rig (login OFF, API keys authenticate on their own):

  phase A  (the rig's global cap, e.g. 8; published-API pool raised above it)
    * a published view over a SAVED QUERY, flooded by one API key, is refused at
      the GLOBAL cap with the one wire shape (503 + Retry-After + "Server is at
      capacity (N/M concurrent queries)") -- before 2026-09-29 these calls held no
      slot and could never be refused by it;
    * the same for a published view over a FEDERATION view;
    * no caller's live count ever exceeds the cap, and every count returns to 0.

  phase B  (global cap raised above 10)
    * ONE API key never holds more than published_views.max_concurrent_per_key
      (10) at once, its extra calls wait for a slot (they are not refused at once);
    * a SECOND key running at the same time is not starved.

The live counts come from GET /api/admin/user-stats (``active_now``, read from
the process's own counter under its lock), sampled every 0.2 s.  Everything the
run creates is removed in a finally through the ledger.

    python pv_slot_proof.py --phase A      # rig as-is (global 8), pool raised
    python pv_slot_proof.py --phase B      # global raised to 40
"""
from __future__ import annotations

import argparse
import json
import re
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, os.path.dirname(__file__))
from proof_cleanup import Ledger  # noqa: E402

API = "http://localhost:8000"
TRINO_LOCAL = 2
TAG = str(int(time.time()))[-6:]
res: list = []


def http(method, path, body=None, headers=None, timeout=300):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    headers = dict(headers or {})
    if not path.startswith("/auth/") and not ({"authorization", "x-api-key"} & {k.lower() for k in headers}):
        import qs_docker_client as _c   # login-ON rig: the rig admin's session (2026-10-04)
        _t = _c._admin_token()
        if _t:
            headers["Authorization"] = f"Bearer {_t}"
    for k, v in headers.items():
        req.add_header(k, v)
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw), dict(r.headers), time.perf_counter() - t0
            except ValueError:
                return r.status, raw[:200], dict(r.headers), time.perf_counter() - t0
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            b = json.loads(raw)
        except Exception:
            b = raw[:300].decode("utf-8", "replace")
        return e.code, b, dict(e.headers), time.perf_counter() - t0
    except Exception as e:                                               # noqa: BLE001
        return -1, {"transport_error": str(e)}, {}, time.perf_counter() - t0


def call(method, path, body=None):
    s, b, h, _ = http(method, path, body)
    return s, b


def check(name, ok, detail=""):
    ok = bool(ok)
    res.append(ok)
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return ok


def indocker(*argv):
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    p = subprocess.run(["docker", "exec", "-i", "qs-local-api", *argv], capture_output=True, env=env)
    return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")


class Sampler:
    """Samples /api/admin/user-stats -> {username: active_now} every 0.2 s."""

    def __init__(self):
        self.peak: dict = {}
        self.total_peak = 0
        self.stop = threading.Event()
        self.samples = 0
        self.health_max = 0.0
        self.health_fail = 0

    def _health(self):
        while not self.stop.is_set():
            s, _, _, dt = http("GET", "/health/live", timeout=60)
            if s != 200:
                self.health_fail += 1
            self.health_max = max(self.health_max, dt)
            time.sleep(0.25)

    def run(self):
        threading.Thread(target=self._health, daemon=True).start()
        while not self.stop.is_set():
            s, b, _, _ = http("GET", "/api/admin/user-stats", timeout=30)
            if s == 200 and isinstance(b, list):
                self.samples += 1
                tot = 0
                for row in b:
                    n = int(row.get("active_now") or 0)
                    tot += n
                    u = row.get("username")
                    self.peak[u] = max(self.peak.get(u, 0), n)
                self.total_peak = max(self.total_peak, tot)
            time.sleep(0.2)

    def __enter__(self):
        self.t = threading.Thread(target=self.run, daemon=True)
        self.t.start()
        return self

    def __exit__(self, *a):
        self.stop.set()
        self.t.join(timeout=35)


def refusal_counts(out):
    """The live (active, cap) each refusal reported: 'Server is at capacity (N/M ...'."""
    got = []
    for o in out:
        m = re.search(r"at capacity \((\d+)/(\d+) concurrent", o[1])
        if o[0] == 503 and m:
            got.append((int(m.group(1)), int(m.group(2))))
    return got


def live_counts():
    s, b, _, _ = http("GET", "/api/admin/user-stats")
    return {r["username"]: r.get("active_now") for r in (b or []) if r.get("active_now")} if s == 200 else {"?": s}


def flood(slug, key, n):
    """n concurrent calls to one view with one key -> list of (status, detail, retry_after, seconds)."""
    def one(_):
        s, b, h, dt = http("GET", f"/api/v1/views/{slug}/data?limit=5&cache=bypass", headers={"X-API-Key": key})
        detail = b.get("detail") if isinstance(b, dict) else str(b)[:120]
        return s, str(detail or "")[:160], h.get("Retry-After") or h.get("retry-after"), round(dt, 2)
    with ThreadPoolExecutor(max_workers=n) as ex:
        return list(ex.map(one, range(n)))


def cap_of():
    rc, out, _ = indocker("python", "-c", "from core.config import query_engine as q; print(q.max_concurrent_global)")
    return int(out.strip().splitlines()[-1]) if rc == 0 else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", choices=["A", "B"], required=True)
    a = ap.parse_args()
    s, _ = call("GET", "/api/datasets")
    if s != 200:
        raise SystemExit(f"run on the login-OFF rig (anonymous /api/datasets answered {s})")
    cap = cap_of()
    print(f"phase {a.phase}: the api process's global cap = {cap}")
    ledger = Ledger(lambda m, p, b=None, **k: call(m, p, b))
    try:
        # a saved query that makes Trino scan all 6M rows of lineitem and match none
        s, b = call("POST", "/api/queries", {"name": f"pvslot_sq_{TAG}", "query_config": {
            "files": ["tpch.sf1.lineitem"], "columns": ["orderkey", "comment"],
            "filters": [{"column": "comment", "operator": "eq", "value": f"no-such-comment-{TAG}"}],
            "connection_id": TRINO_LOCAL}})
        sq = (b or {}).get("id")
        if not check("a saved query over tpch.sf1.lineitem (a full scan)", s in (200, 201) and sq, (s, str(b)[:150])):
            return 1
        ledger.add("saved query", sq, path=f"/api/queries/{sq}")
        keys, slugs = [], []
        for i in (1, 2):
            slug = f"pvslot-sq{i}-{TAG}"
            s, pv = call("POST", "/api/published-views", {"slug": slug, "name": slug, "source_type": "saved_query",
                                                          "query_id": sq, "default_limit": 5, "max_limit": 50})
            pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
            key = (pv or {}).get("test_api_key")
            if not check(f"published view {i} over the saved query, with its own API key", pid and key, (s, str(pv)[:150])):
                return 1
            ledger.add("published view", slug, path=f"/api/published-views/{pid}")
            keys.append(key)
            slugs.append(slug)
        s, b, _, dt = http("GET", f"/api/v1/views/{slugs[0]}/data?limit=5", headers={"X-API-Key": keys[0]})
        check("one call alone answers 200 (0 rows, a full scan)", s == 200, (s, round(dt, 2), str(b)[:120]))

        if a.phase == "A":
            n = cap * 3
            with Sampler() as smp:
                out = flood(slugs[0], keys[0], n)
            refused = [o for o in out if o[0] == 503]
            shape = [o for o in refused if o[1].startswith("Server is at capacity (") and o[2] == "5"]
            ok = [o for o in out if o[0] == 200]
            check(f"{n} concurrent calls on a saved-query view: some refused at the GLOBAL cap",
                  refused and len(ok) >= 1, f"200={len(ok)} 503={len(refused)} other={[o for o in out if o[0] not in (200, 503)][:3]}")
            check("every refusal is the one wire shape (503, Retry-After 5, 'Server is at capacity (N/M ...')",
                  refused and len(shape) == len(refused), refused[:2])
            rc = refusal_counts(out)
            check(f"every refusal reported a live count at or under the cap ({cap})",
                  rc and all(a <= c == cap for a, c in rc), f"{len(rc)} refusals, counts {sorted(set(rc))}")
            check(f"the sampled live total never exceeded the cap ({cap})", smp.samples > 5 and smp.total_peak <= cap,
                  f"peak total {smp.total_peak}, peaks { {k: v for k, v in smp.peak.items() if v} }, samples {smp.samples}")
            check("the API stayed answerable during the saved-query flood (/health/live max < 2 s)",
                  smp.health_max < 2.0 and smp.health_fail == 0, f"max {smp.health_max:.2f}s, failures {smp.health_fail}")
            time.sleep(3)
            check("every count is back to 0 afterwards", live_counts() == {}, live_counts())

            # federation view: two big local parquet sides, UNION
            rc, o, e = indocker("python", "-c", "\n".join([
                "import os, pyarrow as pa, pyarrow.parquet as pq",
                f"d='/app/data/pvslot_{TAG}'; os.makedirs(d, exist_ok=True)",
                "n=3_000_000",
                "pq.write_table(pa.table({'k': pa.array(range(n)), 'src': pa.array(['ALPHA']*n)}), d+'/alpha.parquet')",
                "pq.write_table(pa.table({'k': pa.array(range(n)), 'src': pa.array(['BETA']*n)}), d+'/beta.parquet')",
                "print('ok')"]))
            if not check("two 3M-row parquet sides written in the container", rc == 0, (o or e)[:120]):
                return 1
            s, c = call("POST", "/api/connections", {"name": f"pvslot-local-{TAG}", "connection_type": "local",
                                                     "config": {"base_path": f"/app/data/pvslot_{TAG}"}})
            lconn = (c or {}).get("id")
            ledger.add("connection", lconn, path=f"/api/connections/{lconn}")
            s, f = call("POST", "/api/federation-views", {"name": f"pvslot_fv_{TAG}", "primary_conn_id": lconn,
                        "primary_query": {"files": ["alpha.parquet"]}, "secondary_conn_id": lconn,
                        "secondary_query": {"files": ["beta.parquet"]}, "combine_mode": "union"})
            fv = (f or {}).get("id")
            if not check("a federation view over the two sides", s in (200, 201) and fv, (s, str(f)[:150])):
                return 1
            ledger.add("federation view", fv, path=f"/api/federation-views/{fv}")
            slug = f"pvslot-fv-{TAG}"
            s, pv = call("POST", "/api/published-views", {"slug": slug, "name": slug, "source_type": "federation",
                                                          "federation_view_id": fv, "default_limit": 5, "max_limit": 50})
            pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
            fkey = (pv or {}).get("test_api_key")
            ledger.add("published view", slug, path=f"/api/published-views/{pid}")
            s, b, _, dt = http("GET", f"/api/v1/views/{slug}/data?limit=5", headers={"X-API-Key": fkey})
            check("the federation view answers alone", s == 200, (s, round(dt, 2), str(b)[:120]))
            n = cap * 8   # a federation call is ~1 s: enough calls to outlast several samples
            with Sampler() as smp:
                out = flood(slug, fkey, n)
            refused = [o for o in out if o[0] == 503]
            check(f"{n} concurrent calls on a FEDERATION view: refusals at the global cap, in the one shape",
                  refused and all(o[1].startswith("Server is at capacity (") and o[2] == "5" for o in refused),
                  f"200={sum(1 for o in out if o[0] == 200)} 503={len(refused)} other={[o for o in out if o[0] not in (200, 503)][:3]}")
            rc = refusal_counts(out)
            check(f"every refusal reported a live count at or under the cap ({cap}) -- the process's own counter, read under its lock",
                  rc and all(a <= c == cap for a, c in rc) and smp.total_peak <= cap,
                  f"{len(rc)} refusals, counts {sorted(set(rc))}; sampled peak {smp.total_peak} over {smp.samples} samples")
            check("the API stayed answerable during the federation flood (/health/live max < 2 s)",
                  smp.health_max < 2.0 and smp.health_fail == 0, f"max {smp.health_max:.2f}s, failures {smp.health_fail}")
            time.sleep(3)
            check("every count is back to 0 after the federation flood", live_counts() == {}, live_counts())
            indocker("rm", "-rf", f"/app/data/pvslot_{TAG}")
        else:
            with Sampler() as smp:
                with ThreadPoolExecutor(max_workers=2) as ex:
                    f1 = ex.submit(flood, slugs[0], keys[0], 25)
                    time.sleep(1.0)
                    f2 = ex.submit(flood, slugs[1], keys[1], 4)
                    out1, out2 = f1.result(), f2.result()
            key_peaks = {u: n for u, n in smp.peak.items() if str(u).startswith("apikey:")}
            print("   per-key peaks:", key_peaks, "samples", smp.samples)
            check("key 1 (25 concurrent calls) never held more than 10 at once",
                  key_peaks and max(key_peaks.values()) <= 10 and max(key_peaks.values()) >= 8,
                  key_peaks)
            check("key 1's extra calls WAITED for a slot (all answered 200, none refused at once)",
                  all(o[0] == 200 for o in out1), [o for o in out1 if o[0] != 200][:3])
            check("some of key 1's calls took visibly longer than one run (they queued)",
                  max(o[3] for o in out1) > 2 * min(o[3] for o in out1), sorted(o[3] for o in out1)[::6])
            check("key 2, running at the same time, was not starved (all 4 answered 200)",
                  all(o[0] == 200 for o in out2), out2)
            time.sleep(3)
            check("every count is back to 0 afterwards", live_counts() == {}, live_counts())
    finally:
        removed, left = ledger.cleanup(echo=lambda s: print("  " + s))
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) and not left else 1


if __name__ == "__main__":
    sys.exit(main())
