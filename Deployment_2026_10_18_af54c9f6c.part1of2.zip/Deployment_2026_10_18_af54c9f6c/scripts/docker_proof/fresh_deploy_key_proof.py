"""A FRESH deployment with NO QUERY_STUDIO_SECRET_KEY anywhere, proven on the
rig (2026-10-15).  The owner: "if the key is not available at all ... the key
will be created once the UI and API are deployed, and then connections are
saved or updated -- how will the other components behave?"

  F1 the non-API components start FIRST (scheduler, executor, reports,
     published-api): every one UP, NONE creates a key file, each says it is
     WAITING for the API's key
  F2 the API starts: it creates the key file -- once
  F3 a connection is SAVED through the API (a real MinIO credential)
  F4 the RUNNING scheduler -- never restarted -- executes a feed on that
     connection: it picked the API's key up by itself
  F5 the API with an unwritable key folder and no key: NO KEY, saving a
     password REFUSED with the fix (never a throw-away key)
  F6 the rig restored on its own key, every stored credential readable

The rig's own key file is set aside first (QS_RIG_KEY_BACKUP) and put back
at the end.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
REPO = os.path.dirname(os.path.dirname(HERE))
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")
F = ["-f", "docker-compose.local.yml", "-f", "C:/tmp/a1.override.yml", "-f", "docker-compose.auth-rls.yml",
     "-f", "docker-compose.load-users.yml", "-f", "C:/tmp/pv2.override.yml", "-f",
     "C:/tmp/artifact.override.yml", "-f", "scripts/docker_proof/compose/tetb_real_e2e.override.yml"]
NON_API = {"scheduler": "qs-local-scheduler", "executor": "qs-local-executor",
           "reports": "qs-local-reports", "published-api": "qs-local-published-api"}
KEY = "/app/data/secret.key"
STATUS = ("import json; from core import crypto; s = crypto.key_status(); "
          "print(json.dumps({k: s.get(k) for k in ('source','available','waiting','owner','fingerprint')}))")
CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:500]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:500]}" if detail else ""), flush=True)


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, env=ENV, cwd=REPO, **kw)


def compose(*args, previous=None):
    """``previous`` = run with that key as QUERY_STUDIO_SECRET_KEY_PREVIOUS
    (the overlay the encryption-key proof uses) -- the operator's way to bring
    what was saved under another key back."""
    files, env = list(F), dict(ENV)
    if previous:
        files += ["-f", "C:/tmp/keyproof.override.yml"]
        env.update(QS_PROOF_KEY="", QS_PROOF_KEY_PREVIOUS=previous)
    r = subprocess.run(["docker", "compose", "-p", "querystudio-local", *files, "--profile", "all", *args],
                       capture_output=True, text=True, env=env, cwd=REPO)
    if r.returncode != 0:
        raise SystemExit("compose failed: " + (r.stderr or r.stdout)[-600:])


def healthy(containers, timeout=600):
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = {c: sh(["docker", "inspect", c, "--format", "{{.State.Health.Status}}"]).stdout.strip()
              for c in containers}
        if all(s == "healthy" for s in st.values()):
            return st
        time.sleep(5)
    return st


def key_file_exists():
    return sh(["docker", "run", "--rm", "-v", "querystudio-local_qs-data:/d", "alpine", "test", "-f",
               "/d/secret.key"]).returncode == 0


def main():
    backup = os.environ["QS_RIG_KEY_BACKUP"]
    sh(["docker", "cp", f"qs-local-api:{KEY}", backup])
    rig_key = open(backup).read().strip()
    assert len(rig_key) == 44, "the rig key was not backed up"

    # ── fresh deployment: no key file, no variable ────────────────────────
    compose("stop", "api", *NON_API)
    sh(["docker", "run", "--rm", "-v", "querystudio-local_qs-data:/d", "alpine", "rm", "-f", "/d/secret.key"])
    check("setup: no key file on the shared volume", not key_file_exists())

    # F1 -- the non-API components first
    compose("up", "-d", "--no-deps", "--force-recreate", *NON_API)
    st = healthy(list(NON_API.values()))
    check("F1 every non-API component is UP without a key", all(s == "healthy" for s in st.values()), st)
    check("F1 none of them created a key file", not key_file_exists())
    waits = {c: json.loads(sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", c, "python", "-c",
                               STATUS]).stdout.strip().splitlines()[-1]) for c in NON_API.values()}
    check("F1 each one says it is WAITING for the API's key",
          all(w["waiting"] and not w["available"] and not w["owner"] for w in waits.values()),
          {c: w["source"][:70] for c, w in waits.items()})
    sched_logs_before = sh(["docker", "logs", "qs-local-scheduler"]).stderr + sh(
        ["docker", "logs", "qs-local-scheduler"]).stdout
    check("F1 the scheduler said it once (WAITING), not per use",
          0 < sched_logs_before.count("WAITING for the key the API creates") <= 4,
          sched_logs_before.count("WAITING for the key the API creates"))

    # F2 -- the API starts and creates the key, once
    compose("up", "-d", "--no-deps", "--force-recreate", "api")
    st = healthy(["qs-local-api"])
    check("F2 the API is UP and CREATED the key file", st["qs-local-api"] == "healthy" and key_file_exists(), st)
    api = json.loads(sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", "qs-local-api", "python",
                         "-c", STATUS]).stdout.strip().splitlines()[-1])
    check("F2 the API is the key owner, key from the file it created", api["owner"] and api["available"], api)

    # F3 -- a connection is saved through the API (the UI's route)
    for f in ("~/.qs_keys/rigpw.sh",):
        pass
    from feed_triggers_proof import Rig, psql
    from monthly_kafka_merge_feeds_proof import sftp_host_key
    from tetb_real_e2e_proof import SFTP
    r = Rig()
    pw = [x.split("=", 1)[1] for x in sh(["docker", "inspect", "qs-minio", "--format",
                                          "{{range .Config.Env}}{{println .}}{{end}}"]).stdout.splitlines()
          if x.startswith("MINIO_ROOT_PASSWORD=")][0]
    # the existing MinIO connection (one connection per bucket): its password
    # RE-ENTERED through the API -- the "update connections" road
    def reenter(cid):
        s, cur = r.call("GET", f"/api/connections/{cid}")
        cfg = dict((cur or {}).get("config") or {})
        cfg["aws_secret_access_key"] = pw
        return r.call("PUT", f"/api/connections/{cid}", {"name": cur["name"],
                                                         "connection_type": cur["connection_type"],
                                                         "config": cfg})
    _, conns = r.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else conns.get("items", [])
    cid = next(c["id"] for c in conns if c["connection_type"] == "s3"
               and (c.get("config") or {}).get("bucket_name") == "qs-data")
    s, b = reenter(cid)
    check("F3 a connection's password is SAVED (re-entered) through the API", s == 200, f"{s} {str(b)[:200]}")
    stored = psql(f"select config::text from connections where id={cid}")
    check("F3 the password is stored ENCRYPTED", '"aws_secret_access_key": "enc::' in stored)

    # F4 -- the RUNNING scheduler (never restarted) runs a feed on it
    started_before = sh(["docker", "inspect", "qs-local-scheduler", "--format", "{{.State.StartedAt}}"]).stdout
    fname = f"FRESH_DEPLOY_KEY_PROOF_{int(time.time())}"
    fbody = {"name": fname, "source_type": "raw_sql", "source_id": 0, "connection_id": cid,
             "query_params": {"sql": "SELECT count(*) AS n FROM hv_fact_tetb_ext_006439"}, "output_format": "csv",
             "destination_type": "sftp",
             "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                    "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                    "host_key_b64": sftp_host_key()},
             "output_filename_template": fname + "_{business_date:YYYYMMDD}.csv",
             "execution_backend": "native", "is_active": True, "schedule_enabled": False}
    s, fb = r.call("POST", "/api/feeds", fbody)
    fid = (fb or {}).get("id")
    if not fid:
        raise SystemExit(f"feed not created: {s} {str(fb)[:300]}")
    r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": "2026-09-30", "end_date": "2026-09-30",
                                                  "deliver": True, "reason": "fresh deployment key proof"})
    row, t0 = "", time.time()
    while time.time() - t0 < 600:
        row = psql(f"select status, coalesce(total_rows,0), coalesce(error_message,'') from feed_executions "
                   f"where feed_config_id={fid} order by id desc limit 1")
        if row and row.split("|")[0] in ("completed", "failed"):
            break
        time.sleep(5)
    started_after = sh(["docker", "inspect", "qs-local-scheduler", "--format", "{{.State.StartedAt}}"]).stdout
    check("F4 the RUNNING scheduler executed a feed on the new connection (its credential decrypted)",
          row.startswith("completed") and started_before == started_after,
          f"{row[:300]} (scheduler not restarted: {started_before == started_after})")
    logs = sh(["docker", "logs", "--since", "15m", "qs-local-scheduler"])
    picked = "[encryption-key] key from key file" in (logs.stdout + logs.stderr)
    check("F4 the scheduler logged picking the API's key up", picked)

    # F5 -- the API with an unwritable key folder and no key
    sh(["docker", "volume", "rm", "-f", "qs-unwritable-key"])
    sh(["docker", "volume", "create", "qs-unwritable-key"])
    out = sh(["docker", "run", "--rm", "--user", "1000700000:0", "-e", "QUERY_STUDIO_SECRET_KEY=",
              "-e", "QS_ENCRYPTION_KEY_OWNER=true", "-v", "qs-unwritable-key:/app/data", "--entrypoint", "python",
              "querystudio-local-api:latest", "-c",
              "from core import crypto\nprint(crypto.key_status())\ntry:\n    crypto.encrypt_value('pw')\n"
              "    print('SAVED')\nexcept crypto.EncryptionKeyUnavailable as e:\n    print('REFUSED', e)"])
    check("F5 no key possible: NO KEY said, saving a password REFUSED with the fix",
          "'available': False" in out.stdout and "REFUSED" in out.stdout
          and "QUERY_STUDIO_SECRET_KEY" in out.stdout and "SAVED" not in out.stdout,
          out.stdout[-400:])

    # F6 -- restore the rig
    r.call("DELETE", f"/api/feeds/{fid}")
    fresh_key = sh(["docker", "exec", "qs-local-api", "cat", KEY]).stdout.strip()
    compose("stop", "api", *NON_API)
    sh(["docker", "cp", backup, f"qs-local-scheduler:{KEY}"])
    # what was saved under the fresh deployment's key (the proof feed, its
    # snapshot) is brought back the operator's way: that key as PREVIOUS once
    compose("up", "-d", "--no-deps", "--force-recreate", "api", *NON_API, previous=fresh_key)
    healthy(["qs-local-api", *NON_API.values()])
    compose("up", "-d", "--no-deps", "--force-recreate", "api", *NON_API)
    st = healthy(["qs-local-api", *NON_API.values()])
    r = Rig()
    s, _b = reenter(cid)                 # saved under the fresh key a moment ago: re-entered
    check("F6 the MinIO password re-entered under the rig's own key", s == 200, s)
    chk = sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", "qs-local-api", "python", "-c",
              "from core.database import DatabaseManager\nfrom core.encryption_key_rotation import sweep\n"
              "r = sweep(DatabaseManager(), write=False)\nprint(len(r['unreadable']), r['current'])"])
    n_bad = chk.stdout.strip().splitlines()[-1].split() if chk.stdout.strip() else ["?"]
    check("F6 rig restored on its own key, every stored credential readable",
          all(s == "healthy" for s in st.values()) and n_bad[0] == "0", f"{st} unreadable/current={n_bad}")
    path = os.path.join(HERE, "fresh-deploy-key-results.json")
    json.dump({"checks": CHECKS}, open(path, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
