"""Every S3 / Iceberg BACKGROUND JOB proven on the live Docker rig, on REAL AWS (2026-10-08).

Owner: "all background jobs should be tested via docker ... a real test";
"columns stats, iceberg watcher, blooming filter, island finder ... how feed
gets triggered once it sees new metadata ... all other background jobs which
run against s3".

The rule for every check: the job FIRES BY ITSELF where it really runs (the
scheduler pod), and its OUTPUT is judged against an independent truth -- Trino
on the same Iceberg table, the S3 bucket itself, the metadata DB -- never
against "it ticked".  A job that did nothing must not read healthy.

  A  a real Iceberg COMMIT on AWS (dim_fx_rate, sentinel currency QSB):
     A1 the manifest WATCHER sees the new snapshot by itself (certificate ==
        Trino's newest snapshot id; a change row)
     A2 the METADATA SYNC records it (watched_iceberg_tables.last_snapshot_id)
     A3 COLUMN STATS for the new snapshot: iceberg_file_stats_v3 rows == the
        snapshot's data files in Trino "$files"
     A4 WARM-ON-COMMIT ran for that snapshot (the job's status, no error)
     A5 a query sees the committed row within the freshness bound (60 s)
  B  FILE ARRIVAL: a feed waiting on a file in the real bucket is HELD, stays
     held with the data file but no READY, and is RELEASED by the watcher +
     poller when READY lands; the delivered file == the source
  C  EVERY declared background job (core/background_job_contract.py): status
     answered by the OWNER; run-now on the owner returns an honest outcome
     (never error / unknown; skipped carries a reason); short-interval jobs
     have a SCHEDULED tick of their own
  D  BLOOM: adaptive prefetch ranks real query history and builds bloom
     sidecars; the bloom rows cover every data file of the table

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/s3_background_proof.py [--only A,B,C,D]
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import qs_docker_client as c  # noqa: E402

TAG = str(int(time.time()))[-6:]
CAT = "iceberg_aws.fin."
res = []
os.environ.setdefault("MSYS_NO_PATHCONV", "1")


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:600], flush=True)
    return bool(ok)


def psql(sql):
    r = subprocess.run(["docker", "exec", "qs-local-postgres", "sh", "-c",
                        f'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -tAc "{sql}"'],
                       capture_output=True, text=True)
    return (r.stdout or "").strip()


def trino(sql):
    r = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                       capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-400:])
    return r.stdout.strip()


def wait_until(fn, timeout, every=5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v, round(time.time() - t0)
        time.sleep(every)
    return None, round(time.time() - t0)


def aws_env():
    """The AWS keys: ~/.qs_keys/aws.env when present, the environment (rig/rig.env,
    loaded by rig.ps1 on any machine) over it (2026-10-16)."""
    env = {}
    path = os.path.expanduser("~/.qs_keys/aws.env")
    if os.path.exists(path):
        for ln in open(path, encoding="utf-8"):
            if "=" in ln and not ln.strip().startswith("#"):
                k, v = ln.strip().replace("export ", "").split("=", 1)
                env[k] = v.strip().strip("'\"")
    env.update({k: v for k, v in os.environ.items() if k.startswith("AWS_") and v})
    if "AWS_REGION" not in env and env.get("AWS_DEFAULT_REGION"):
        env["AWS_REGION"] = env["AWS_DEFAULT_REGION"]
    return env


_S3_CODE = """
import boto3, json, os, sys
s = boto3.client("s3", region_name=os.environ["AWS_REGION"])
b = os.environ["QS_S3_BUCKET"]
op, k, body = sys.argv[1], sys.argv[2], sys.argv[3]
if op == "put":
    print(s.put_object(Bucket=b, Key=k, Body=body.encode())["ResponseMetadata"]["HTTPStatusCode"])
elif op == "delete":
    print(s.delete_object(Bucket=b, Key=k)["ResponseMetadata"]["HTTPStatusCode"])
else:
    print(json.dumps([o["Key"] for o in s.list_objects_v2(Bucket=b, Prefix=k).get("Contents", [])]))
"""


def s3(op, key, body=""):
    """put / delete / list one key in the owner's bucket, through boto3 in the
    api container (the host has none); the keys ride the exec env only.  A put
    or delete that does not answer 200/204 RAISES: a check that passes because
    the file never landed proves nothing."""
    e = aws_env()
    args = ["docker", "exec"] + sum([["-e", f"{k}={v}"] for k, v in e.items()], []) +         ["qs-local-api", "python3", "-c", _S3_CODE, op, key, body]
    r = subprocess.run(args, capture_output=True, text=True)
    out = (r.stdout or "").strip()
    if op in ("put", "delete") and out not in ("200", "204"):
        raise RuntimeError(f"s3 {op} {key} failed: {(r.stderr or out)[-300:]}")
    return out


def newest_snapshot(table):
    return trino(f'select snapshot_id from {CAT}"{table}$snapshots" order by committed_at desc limit 1')


def prefix_of(table):
    loc = trino(f'select "$path" from {CAT}{table} limit 1')
    # s3://bucket/<prefix>/data/... -> <prefix>
    p = loc.split("://", 1)[1].split("/", 1)[1]
    return p.split("/data/")[0]


# ── A: a real Iceberg commit, noticed by the jobs themselves ─────────────────

def part_a():
    table = "dim_fx_rate"
    prefix = prefix_of(table)
    print(f"\n== A  Iceberg commit on real AWS: {CAT}{table} (prefix {prefix})")
    s, b, _ = c.call("GET", "/api/admin/iceberg-watcher/settings")
    old_interval = None
    for it in (b if isinstance(b, list) else (b or {}).get("settings") or []):
        if isinstance(it, dict) and it.get("key") == "iceberg_watcher.interval_seconds":
            old_interval = it.get("value")
    s, b, _ = c.call("PATCH", "/api/admin/iceberg-watcher/settings/iceberg_watcher.interval_seconds", {"value": 60})
    check("A0 the watcher's own interval setting lowered to 60 s (the product's setting, not a hack)",
          s == 200, f"HTTP {s} {str(b)[:160]} (was {old_interval})")
    date = (dt.date.today() - dt.timedelta(days=3)).isoformat()
    try:
        trino(f"delete from {CAT}{table} where currency = 'QSB'")
        before = newest_snapshot(table)
        trino(f"insert into {CAT}{table} values (DATE '{date}', 'QSB', 1.2345)")
        snap = newest_snapshot(table)
        files_now = int(trino(f'select count(*) from {CAT}"{table}$files" where content = 0'))
        check("A  committed one row; Trino reports a NEW snapshot", snap and snap != before,
              {"before": before, "after": snap, "data_files": files_now})
        t_commit = time.time()

        cert, secs = wait_until(lambda: psql(
            f"select observed_snapshot_id from iceberg_watcher_certificate where table_prefix like '%{prefix.split('/')[-1]}%' "
            f"and observed_snapshot_id = '{snap}' limit 1"), 420, 10)
        chg = psql(f"select count(*) from iceberg_watcher_changes where table_prefix like '%{prefix.split('/')[-1]}%' "
                   f"and snap_new = '{snap}'") if cert else ""
        check(f"A1 the manifest WATCHER saw snapshot {snap} by itself ({secs}s after the commit)",
              bool(cert), {"certificate": cert, "change_rows": chg})

        synced, secs = wait_until(lambda: psql(
            f"select last_snapshot_id || '|' || coalesce(last_sync_status,'') from watched_iceberg_tables "
            f"where table_prefix like '%{prefix.split('/')[-1]}%' and last_snapshot_id = '{snap}' limit 1"), 600, 10)
        check(f"A2 the METADATA SYNC recorded the snapshot ({round(time.time() - t_commit)}s after the commit)",
              bool(synced), synced or psql(f"select last_snapshot_id, last_sync_status, last_synced_at from watched_iceberg_tables "
                                            f"where table_prefix like '%{prefix.split('/')[-1]}%'"))

        stats, _ = wait_until(lambda: (lambda n: n if n and int(n) > 0 else None)(psql(
            f"select count(distinct file_path) from iceberg_file_stats_v3 where table_prefix like '%{prefix.split('/')[-1]}%' "
            f"and snapshot_id = '{snap}'")), 300, 10)
        check("A3 COLUMN STATS cover every DATA file of the new snapshot (v3 rows == Trino $files content=0; delete files carry no stats)",
              stats is not None and int(stats) == files_now, {"v3_files": stats, "trino_files": files_now})

        s, st, _ = c.call("GET", "/api/admin/background-jobs/iceberg_warm_on_commit/status")
        warms = json.dumps(st)[:4000] if isinstance(st, dict) else str(st)
        check("A4 WARM-ON-COMMIT ran for the new snapshot, without error",
              s == 200 and snap in warms and '"error": "' not in warms.split(snap)[1][:400],
              {"status": s, "answered_by": (st or {}).get("answered_by") if isinstance(st, dict) else None,
               "excerpt": warms[:300]})

        _, conns, _ = c.call("GET", "/api/connections")
        items = conns if isinstance(conns, list) else (conns or {}).get("items") or (conns or {}).get("connections") or []
        aws = next(x["id"] for x in items if x.get("name") == "aws-real")
        s, b, _ = c.call("POST", "/api/execute", {"connection_id": aws, "cache_strategy": "auto",
                                                   "raw_sql": f"select currency, rate_to_gbp from {table} where currency = 'QSB'"})
        rows, state = [], f"submit HTTP {s}: {str(b)[:200]}"
        if s == 200 and (b or {}).get("execution_id"):
            eid = b["execution_id"]
            st, _ = wait_until(lambda: (lambda x: x if (x or {}).get("status") in ("completed", "failed", "cancelled") else None)(
                c.call("GET", f"/api/executions/{eid}/status")[1]), 300, 2)
            state = (st or {}).get("status"), (st or {}).get("error_message")
            if (st or {}).get("status") == "completed":
                _, rb, _ = c.call("GET", f"/api/executions/{eid}/results?page=1&page_size=100")
                rows = (rb or {}).get("rows") or []
        check("A5 a query (cache auto) sees the committed row (freshness bound)", len(rows) == 1, {"rows": rows, "run": state})
    finally:
        try:
            trino(f"delete from {CAT}{table} where currency = 'QSB'")
            print("   cleanup: sentinel row removed")
        except Exception as exc:  # noqa: BLE001
            print("   cleanup FAILED:", exc)
        if old_interval is not None:
            c.call("PATCH", "/api/admin/iceberg-watcher/settings/iceberg_watcher.interval_seconds", {"value": old_interval})


# ── B: a feed released by a FILE landing in the real bucket ──────────────────

def part_b():
    from feed_triggers_proof import Rig, dep_types, held_then_released, wait_until as wu  # noqa: F401
    print("\n== B  File arrival on real AWS: held until the file AND its READY land")
    r = Rig()
    _, cl = r.call("GET", "/api/connections")
    items = cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []
    aws = next(x["id"] for x in items if x.get("name") == "aws-real")
    types = dep_types(r)
    tid = types.get("FILE") or types.get("FILE_ARRIVAL") or next(iter(types.values()))
    date = (dt.date.today() - dt.timedelta(days=2)).isoformat()
    ymd = date.replace("-", "")
    folder = f"qs-proof/landing/{TAG}/{ymd}/"
    try:
        fid = r.feed(f"TRG_FILE_{TAG}")
        s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [{
            "dependency_type_id": tid, "dependency_key": f"gl_landing_{TAG}", "description": "GL extract lands",
            "arrival_sources": [{"kind": "file", "connection_id": aws,
                                 "path": f"qs-proof/landing/{TAG}/{{business_date:YYYYMMDD}}/",
                                 "pattern": "*.csv", "control_file": "READY"}]}]})
        check("B0 dependency declared (kind file, data *.csv + control file READY, on the real bucket)",
              s == 200, str(b)[:200])

        def satisfy():
            print("   data file:", s3("put", folder + "gl.csv", "a,b\n1,2\n"))
            time.sleep(90)
            row = r.run_row(fid, date)
            check("B1 the DATA file alone does not release it (READY not there): still WAIT after 90 s",
                  row and row["decision"] == "WAIT", row)
            print("   READY:", s3("put", folder + "READY", ""))

        held_then_released(r, "B", fid, date, satisfy, hold_for=45, release_timeout=420)
        ev = psql(f"select count(*) from dependency_events where source = 'file' and created_at > now() - interval '30 minutes'")
        check("B2 the watcher recorded the ARRIVAL (dependency_events source=file)", ev not in ("", "0"), ev)
    finally:
        for k in (folder + "gl.csv", folder + "READY"):
            s3("delete", k)
        for path in r.undo:
            r.call("DELETE", path)
        print("   cleanup: objects + feed removed")


# ── C: every declared job, by its owner ──────────────────────────────────────

SHORT = 300   # a job scheduled at least this often must have fired by itself during the run


def part_c(started_at):
    print("\n== C  Every declared background job: status by the owner, run-now honest, scheduled ticks")
    s, ticks, _ = c.call("GET", "/api/admin/background-jobs/ticks")
    check("C0 the fleet ledger answers", s == 200 and isinstance(ticks, dict), str(ticks)[:200])
    names = sorted(((ticks or {}).get("jobs") or ticks or {}).keys()) if isinstance(ticks, dict) else []
    from_contract = subprocess.run([sys.executable, "-c",
        "import sys;sys.path.insert(0,'backend');from core.background_job_contract import CONTRACTS;print(' '.join(sorted(CONTRACTS)))"],
        capture_output=True, text=True, cwd=os.path.join(os.path.dirname(__file__), "..", "..")).stdout.split()
    jobs = from_contract or names
    check("C0 the declared job list is read from the contract (48 expected)", len(jobs) >= 40, len(jobs))
    for name in jobs:
        s, st, _ = c.call("GET", f"/api/admin/background-jobs/{name}/status")
        if s != 200 or not isinstance(st, dict):
            check(f"C1 {name}: status", False, f"HTTP {s} {str(st)[:200]}")
            continue
        avail = ((st.get("run_now") or {}).get("available"))
        reason = (st.get("run_now") or {}).get("reason")
        if not avail:
            check(f"C1 {name}: status by {st.get('answered_by') or st.get('pod_id') or '?'}; run-now declared unavailable WITH a reason",
                  bool(reason), reason)
            continue
        s2, tick, _ = c.call("POST", f"/api/admin/background-jobs/{name}/run-now", None, timeout=900)
        out = (tick or {}).get("outcome") if isinstance(tick, dict) else None
        honest = out in ("ok", "no_input", "skipped", "unreadable") and (out != "skipped" or (tick or {}).get("reason"))
        check(f"C1 {name}: run-now on the owner -> {out}", s2 == 200 and honest,
              {"http": s2, "outcome": out, "reason": (tick or {}).get("reason") if isinstance(tick, dict) else str(tick)[:200],
               "counts": (tick or {}).get("counts") if isinstance(tick, dict) else None,
               "answered_by": (tick or {}).get("answered_by") if isinstance(tick, dict) else None})
    # scheduled fires during this run: each job's own status carries its
    # recent ticks (the fleet route carries only the last one)
    scheduled = {}
    for name in jobs:
        s, st, _ = c.call("GET", f"/api/admin/background-jobs/{name}/status")
        ticks = (st or {}).get("recent_ticks") if isinstance(st, dict) else None
        scheduled[name] = [t for t in (ticks or []) if isinstance(t, dict) and t.get("trigger") == "scheduled"]
    fired = sorted(n for n, t in scheduled.items() if t)
    check("C2 jobs fired BY THEMSELVES on their schedule (a 'scheduled' tick in their own ledger)",
          len(fired) > 0, fired)
    bad = {n: t[0] for n, t in scheduled.items() if t and t[0].get("outcome") in ("error", "unknown")}
    check("C3 no job's latest scheduled tick ended in error / unknown", not bad, bad)


# ── D: bloom filters from real query history ─────────────────────────────────

def part_d():
    print("\n== D  Bloom: ranked from real query history, built over every file")
    _, conns, _ = c.call("GET", "/api/connections")
    items = conns if isinstance(conns, list) else (conns or {}).get("items") or (conns or {}).get("connections") or []
    aws = next(x["id"] for x in items if x.get("name") == "aws-real")
    for v in ("SAP", "ORACLE", "SAP"):
        s, b, _ = c.call("POST", "/api/execute", {"connection_id": aws, "cache_strategy": "bypass",
                                                   "raw_sql": f"select count(*) from fact_tetb where business_close_date = DATE '2025-09-30' and system_id = '{v}'"})
        if s == 200:
            eid = b["execution_id"]
            wait_until(lambda: (c.call("GET", f"/api/executions/{eid}/status")[1] or {}).get("status") in ("completed", "failed"), 600, 3)
    hist = psql("select count(*) from query_pruning_history where table_prefix like '%fact_tetb-%' and created_at > now() - interval '30 minutes'")
    check("D1 the queries were RECORDED as history (the brain's input)", hist not in ("", "0"), hist)
    s, tick, _ = c.call("POST", "/api/admin/background-jobs/adaptive_prefetch/run-now", None, timeout=1800)
    check("D2 adaptive prefetch on the owner ranked the history and built blooms",
          s == 200 and isinstance(tick, dict) and tick.get("outcome") == "ok", tick if not isinstance(tick, dict) else
          {k: tick.get(k) for k in ("outcome", "reason", "counts", "answered_by")})
    files = int(trino(f'select count(*) from {CAT}"fact_tetb$files" where content = 0'))
    # max_files_per_target THROTTLES (never refuses): a big gap completes over
    # a few ticks, each building only the files still missing
    for _ in range(4):
        cov = psql("select max(n) from (select count(distinct file_path) n from iceberg_bloom_sidecar_v1 "
                   "where table_prefix like '%fact_tetb-%' group by column_name) t")
        if cov and int(cov) >= files:
            break
        c.call("POST", "/api/admin/background-jobs/adaptive_prefetch/run-now", None, timeout=1800)
    blooms = psql("select column_name || ':' || count(distinct file_path) from iceberg_bloom_sidecar_v1 "
                  "where table_prefix like '%fact_tetb-%' group by column_name")
    check("D3 a bloom column covers EVERY data file of fact_tetb",
          any(x.split(":")[1] == str(files) for x in blooms.splitlines() if ":" in x), {"blooms": blooms, "files": files})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="A,B,C,D")
    parts = set(ap.parse_args().only.split(","))
    t0 = time.time()
    for p, fn in (("A", part_a), ("B", part_b), ("D", part_d)):
        if p in parts:
            try:
                fn()
            except Exception as exc:  # noqa: BLE001
                check(f"{p} ran to the end", False, f"{type(exc).__name__}: {exc}")
    if "C" in parts:
        part_c(t0)
    print(f"\n{sum(res)}/{len(res)} PASSED" if all(res) else f"\n{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
