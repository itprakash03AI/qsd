"""A feed run survives a deploy -- proven on Docker (2026-10-14).

``docker stop`` sends the scheduler SIGTERM (the compose grace is 30 s), the
same signal a Kubernetes rollout sends.  The worker drains for
``feed_generation.shutdown_drain_seconds``, closes the publish gate and hands
the unfinished run back (core/feed/run_lifecycle.py).  Checked:

* the attempt is FAILED with the hand-back reason, within the grace period;
* the run is back on the queue (pending), no connection slot is held;
* no file was published for that attempt;
* after ``docker start`` the run executes again BY ITSELF and completes with
  every row (Starburst's own count).

    python deploy_survival_proof.py [--feed PART_KEY_PROOF_WHOLE]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, psql                       # noqa: E402

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {detail}" if detail else ""), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feed", default="PART_KEY_PROOF_WHOLE")
    ap.add_argument("--rows", type=int, default=400036)
    a = ap.parse_args()
    r = Rig()
    fid = int(psql(f"select id from feed_configs where name='{a.feed}'"))
    run = int(psql(f"select id from feed_runs where feed_config_id={fid} order by id desc limit 1"))
    before = int(psql(f"select coalesce(max(id),0) from feed_executions where feed_config_id={fid}"))
    s, b = r.call("POST", f"/api/feed-runs/{run}/rerun", {"reason": "deploy-survival proof"})
    check("the run is started", s in (200, 201, 202), s)
    t0 = time.time()
    victim = None
    while time.time() - t0 < 600:
        row = psql(f"select id, status from feed_executions where feed_config_id={fid} and id>{before} "
                   f"order by id desc limit 1")
        if row and row.split("|")[1] == "running" and time.time() - t0 > 45:
            victim = int(row.split("|")[0])
            break
        time.sleep(3)
    if victim is None:
        raise SystemExit("the run never reached 'running'")
    host = subprocess.run(["docker", "exec", "qs-local-scheduler", "hostname"],
                          capture_output=True, text=True).stdout.strip()
    ts = time.time()
    subprocess.run(["docker", "stop", "qs-local-scheduler"], check=True, capture_output=True)
    stop_s = round(time.time() - ts, 1)
    st, err = psql(f"select status, coalesce(error_message,'') from feed_executions where id={victim}").split("|", 1)
    rstat = psql(f"select status from feed_runs where id={run}")
    slots = psql(f"select count(*) from connection_claims where run_kind='feed_run' and run_id={run}")
    code = subprocess.run(["docker", "inspect", "qs-local-scheduler", "--format", "{{.State.ExitCode}}"],
                          capture_output=True, text=True).stdout.strip()
    check("the worker EXITED by itself inside the grace period (not killed)", code == "0",
          f"exit code {code} after {stop_s} s (137 = killed at the grace limit)")
    check("the attempt is FAILED with the hand-back reason", st == "failed" and "shut down during the run" in err,
          f"{st}: {err[:160]}")
    check("the run is back on the queue", rstat == "pending", rstat)
    check("no connection slot is held", slots == "0", slots)
    art = psql(f"select coalesce(artifact_path,'') from feed_executions where id={victim}")
    check("no file was published for the stopped attempt", not art, art or "(none)")
    logs = subprocess.run(["docker", "logs", "--since", "2m", "qs-local-scheduler"],
                          capture_output=True, text=True)
    said = [ln for ln in (logs.stdout + logs.stderr).splitlines() if "[run-lifecycle]" in ln]
    check("the worker said what it handed back", bool(said), said[-1][:200] if said else "")
    subprocess.run(["docker", "start", "qs-local-scheduler"], check=True, capture_output=True)
    host2 = subprocess.run(["docker", "exec", "qs-local-scheduler", "hostname"],
                           capture_output=True, text=True).stdout.strip()
    t1 = time.time()
    nxt = ""
    while time.time() - t1 < 1800:
        nxt = psql(f"select id, status, coalesce(total_rows,0) from feed_executions where feed_config_id={fid} "
                   f"and id>{victim} order by id desc limit 1")
        if nxt and nxt.split("|")[1] in ("completed", "failed"):
            break
        time.sleep(10)
    parts = nxt.split("|") if nxt else ["", "", "0"]
    check("after restart the run executed again by itself and completed", parts[1] == "completed",
          f"execution {parts[0]} {parts[1]} ({round(time.time() - t1)} s after start; host {host} -> {host2})")
    check("with every row", parts[2] == str(a.rows), f"{parts[2]} vs {a.rows}")
    out = os.path.join(HERE, "deploy-survival-results.json")
    json.dump({"checks": CHECKS, "victim_execution": victim, "run": run}, open(out, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {out}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
