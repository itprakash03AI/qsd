"""Snowflake on a REAL account, end to end on Docker, key from VAULT (2026-10-03).

fakesnow (snowflake_journey_proof.py) is DuckDB underneath; this asks the
questions only Snowflake can answer, against the owner's account, as the real
rig users (login ON, docker-compose.auth-rls.yml):

  A. the login: a snowflake_keypair System Account whose key lives ONLY in
     Vault (kv secret/qs/snowflake-svc) -> its Test opens the key; a
     connection that names the account and carries NO key connects; edit
     dialog Test with the masked config; Save untouched -> still connects.
     And the attach/paste path: the .p8 text in the config connects and
     reads back as "***".
  B. browsing a seeded database: the database, schema, TABLE and VIEW, the
     view's columns.
  C. case folding -- a quoted mixed-case table and column next to unquoted
     ones (Snowflake folds unquoted to UPPER; quoted is exact).
  D. the dataset wizard preview == truth; types are Snowflake NAMES.
  E. a dataset over SQL: auto-detect types; run == truth; the case-folding
     dataset runs and returns the quoted column's values.
  F. a report == truth; CSV / Excel / PDF; published API on :8003 == truth.
  G. 1.5M rows of TPCH_SF1.ORDERS counted through QueryStudio == Snowflake.
  H. the analyst: the admin shares the connection; the analyst lists it with
     NO configuration and runs a query on it; cannot edit it.
  I. CANCEL: a long scan cancelled from QueryStudio stops in Snowflake (its
     QUERY_HISTORY row ends "canceled" within seconds -- the warehouse stops
     paying).
  J. SESSION EXPIRY: QueryStudio's reused session is aborted server-side;
     the next query still answers, on a NEW session.

Seeding / truth / cleanup go through the snowflake driver from the HOST with
the same key file (QS_SF_KEY_FILE) -- never printed, never sent anywhere but
Snowflake and the rig's Vault.

    . rigpw.sh
    QS_SF_ACCOUNT=IRFJALM-NZC41769 QS_SF_USER=QS_SVC \\
      QS_SF_KEY_FILE=~/.qs_keys/qs_svc_key.p8 \\
      python scripts/docker_proof/snowflake_real_account_proof.py

Keeps the System Account "snowflake-qs-svc" and the connection
"snowflake-real" (the owner tests with them); removes everything else,
including the seeded database.
"""
from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import sys
import threading
import time
import warnings

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

warnings.filterwarnings("ignore")
ACCOUNT = os.environ.get("QS_SF_ACCOUNT", "IRFJALM-NZC41769")
SF_USER = os.environ.get("QS_SF_USER", "QS_SVC")
KEY_FILE = os.path.expanduser(os.environ.get("QS_SF_KEY_FILE", "~/.qs_keys/qs_svc_key.p8"))
VAULT = "http://vault:8200"
KV_PATH = "secret/data/qs/snowflake-svc"
PUB = "http://localhost:8003"
TAG = str(int(time.time()))[-6:]
DB = f"QS_PROOF_{TAG}"
ROWS = [(1, "EMEA", 10.5, "2026-01-03"), (2, "APAC", 20.0, "2026-01-03"),
        (3, "EMEA", 5.0, "2026-01-04"), (4, "AMER", 7.25, "2026-01-04")]
TRUTH = {}
for _, _r, _a, _ in ROWS:
    TRUTH[_r] = round(TRUTH.get(_r, 0) + _a, 2)
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:260], flush=True)
    return bool(ok)


def key_text():
    with open(KEY_FILE, encoding="utf-8") as fh:
        return fh.read()


def host_conn():
    """The driver from the host, same key -- the TRUTH side."""
    import snowflake.connector
    from cryptography.hazmat.primitives import serialization
    pk = serialization.load_pem_private_key(key_text().encode(), password=None)
    der = pk.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8,
                           serialization.NoEncryption())
    return snowflake.connector.connect(account=ACCOUNT, user=SF_USER, private_key=der,
                                       warehouse="COMPUTE_WH")


def host_sql(con, sql):
    cur = con.cursor()
    cur.execute(sql)
    try:
        return cur.fetchall()
    except Exception:
        return []


def ensure_vault():
    """Policy, JWT role and the kv entry -- the key piped from the file into
    the API container's python, which writes it to Vault.  Idempotent."""
    script = r'''
import json, sys, urllib.request
key = sys.stdin.read()
V = "http://vault:8200"; H = {"X-Vault-Token": "root", "Content-Type": "application/json"}
def call(m, p, b):
    r = urllib.request.Request(V + p, method=m, headers=H, data=json.dumps(b).encode())
    return urllib.request.urlopen(r, timeout=10).status
call("PUT", "/v1/sys/policies/acl/qs-snowflake-read",
     {"policy": 'path "%s" { capabilities = ["read"] }'})
call("POST", "/v1/auth/jwt/role/qs-snowflake", {"role_type": "jwt", "user_claim": "sub",
     "bound_audiences": ["vault"], "token_policies": ["qs-snowflake-read"], "token_ttl": "10m"})
call("POST", "/v1/%s", {"data": {"username": "%s", "private_key": key}})
print("vault ok")
''' % (KV_PATH, KV_PATH, SF_USER)
    env = dict(os.environ, MSYS_NO_PATHCONV="1")
    out = subprocess.run(["docker", "exec", "-i", "qs-local-api", "python3", "-c", script],
                         input=key_text(), capture_output=True, text=True, env=env)
    return "vault ok" in out.stdout, (out.stdout + out.stderr)[-200:]


def rows_of(body):
    names = [x["name"] if isinstance(x, dict) else x for x in (body or {}).get("columns") or []]
    return [r if isinstance(r, dict) else dict(zip(names, r)) for r in (body or {}).get("rows") or []]


def by_region(rows):
    out = {}
    for r in rows or []:
        r = {str(k).lower(): v for k, v in r.items()}
        out[str(r["region"])] = round(float(r["amt"]), 2)
    return out


def run_sql(sess, cid, sql, limit=100, timeout=300):
    """The SQL editor road: start, poll, read.  Returns (status, rows|error, execution_id)."""
    s, r, _ = sess.call("POST", "/api/sql/execute", {"primary_connection_id": cid, "primary_sql": sql,
                                                    "row_limit": limit})
    if s != 200 or not (r or {}).get("execution_id"):
        return s, r, None
    eid = r["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st, _ = sess.call("GET", f"/api/executions/{eid}/status")
        status = (st or {}).get("status")
        if status in ("completed", "success", "finished"):
            _, rb, _ = sess.call("GET", f"/api/executions/{eid}/results?page_size={limit}")
            return 200, rows_of(rb), eid
        if status in ("failed", "error", "cancelled"):
            return 500, (st or {}).get("error_message") or st, eid
        time.sleep(0.5)
    return -1, "timeout", eid


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    analyst = Session("rig_analyst", os.environ["QS_RIG_ANALYST_PW"])
    con = host_conn()
    undo = []
    try:
        print("\n== 0 . seed a database on the real account (host driver)")
        for sql in (f"create database {DB}", f"create schema {DB}.FIN",
                    f"create table {DB}.FIN.TRADES (ID int, REGION varchar, AMT number(18,2), DT date)",
                    f"insert into {DB}.FIN.TRADES values " + ",".join(f"({i},'{r}',{a},'{d}')" for i, r, a, d in ROWS),
                    f"create view {DB}.FIN.TRADES_EMEA as select * from {DB}.FIN.TRADES where REGION='EMEA'",
                    f'create table {DB}.FIN."MixedCase" ("lowerCol" int, UPPERCOL int)',
                    f'insert into {DB}.FIN."MixedCase" values (1, 10), (2, 20)'):
            host_sql(con, sql)
        check("seeded", host_sql(con, f"select count(*) from {DB}.FIN.TRADES")[0][0] == len(ROWS), DB)

        print("\n== A . the login: key from Vault, no key on the connection")
        ok, why = ensure_vault()
        check("the key is in Vault (kv secret/qs/snowflake-svc)", ok, why)
        _, sas, _ = admin.call("GET", "/api/admin/system-accounts")
        sas = sas if isinstance(sas, list) else (sas or {}).get("accounts", [])
        sa = next((x for x in sas if x.get("name") == "snowflake-qs-svc"), None)
        if not sa:
            _, sa, _ = admin.call("POST", "/api/admin/system-accounts", {
                "name": "snowflake-qs-svc", "account_type": "snowflake_keypair", "username": "-",
                "password": "-", "use_vault": True, "secret_type": "kv_secrets",
                "vault_auth_url": VAULT + "/v1/auth/jwt/login", "vault_role_name": "qs-snowflake",
                "vault_role_type": "jwt", "vault_secret_url": f"{VAULT}/v1/{KV_PATH}"})
        said = sa["id"]
        _, t, _ = admin.call("POST", f"/api/admin/system-accounts/{said}/test")
        check("the System Account's Test opens the Vault key", (t or {}).get("success") is True, t)
        _, conns, _ = admin.call("GET", "/api/connections")
        conn = next((x for x in conns or [] if x.get("name") == "snowflake-real"), None)
        cfg = {"account": ACCOUNT, "auth_type": "key_pair", "system_account_id": said, "warehouse": "COMPUTE_WH"}
        if not conn:
            _, conn, _ = admin.call("POST", "/api/connections", {"name": "snowflake-real",
                                                                 "connection_type": "snowflake", "config": cfg})
        cid = conn["id"]
        _, g, _ = admin.call("GET", f"/api/connections/{cid}")
        check("the connection stores NO key -- only the account reference",
              not (g["config"].get("private_key")) and g["config"].get("system_account_id") == said, g["config"])
        _, t, _ = admin.call("POST", f"/api/connections/{cid}/test")
        check("Test connects AS the Vault account's user", (t or {}).get("success") is True
              and SF_USER in str((t or {}).get("message")), (t or {}).get("message"))
        _, dt, _ = admin.call("POST", "/api/connections/test", {"connection_type": "snowflake",
                                                                "config": g["config"], "connection_id": cid})
        check("Test in the edit dialog connects", (dt or {}).get("success") is True, (dt or {}).get("message"))
        s, _, _ = admin.call("PUT", f"/api/connections/{cid}", {"name": g["name"], "connection_type": "snowflake",
                                                                "config": g["config"]})
        _, t2, _ = admin.call("POST", f"/api/connections/{cid}/test")
        check("Save untouched -> still connects", s == 200 and (t2 or {}).get("success") is True, (s, t2))

        s, pc, _ = admin.call("POST", "/api/connections", {"name": f"sf-pasted-{TAG}", "connection_type": "snowflake",
            "config": {"account": ACCOUNT, "user": SF_USER, "auth_type": "key_pair", "private_key": key_text(),
                       "warehouse": "COMPUTE_WH"}})
        if pc and pc.get("id"):
            undo.append(f"/api/connections/{pc['id']}")
            _, pt, _ = admin.call("POST", f"/api/connections/{pc['id']}/test")
            _, pg, _ = admin.call("GET", f"/api/connections/{pc['id']}")
            check("the attached/pasted .p8 connects and reads back masked",
                  (pt or {}).get("success") is True and pg["config"].get("private_key") == "***",
                  ((pt or {}).get("message"), pg["config"].get("private_key")))

        print("\n== B . browsing")
        _, cats, _ = admin.call("GET", f"/api/sql/connections/{cid}/catalogs")
        check("the database is listed", DB in (cats or []), [x for x in cats or [] if "QS_" in x])
        _, sch, _ = admin.call("GET", f"/api/sql/connections/{cid}/schemas?catalog={DB}")
        check("the schema is listed", "FIN" in (sch or []), sch)
        _, tabs, _ = admin.call("GET", f"/api/sql/connections/{cid}/tables?catalog={DB}&schema=FIN")
        kinds = {t.get("name"): t.get("type") for t in (tabs or []) if isinstance(t, dict)}
        check("TABLE, VIEW and the quoted MixedCase table are listed with their kinds",
              kinds.get("TRADES") == "TABLE" and kinds.get("TRADES_EMEA") == "VIEW" and "MixedCase" in kinds, kinds)
        s, vc, _ = admin.call("GET", f"/api/sql/connections/{cid}/columns?catalog={DB}&schema=FIN&table=TRADES_EMEA")
        names = [x.get("name") for x in (vc if isinstance(vc, list) else (vc or {}).get("columns") or [])]
        check("the view's columns", {"REGION", "AMT"} <= set(names), (s, names))
        s, mc, _ = admin.call("GET", f"/api/sql/connections/{cid}/columns?catalog={DB}&schema=FIN&table=MixedCase")
        names = [x.get("name") for x in (mc if isinstance(mc, list) else (mc or {}).get("columns") or [])]
        check("C. the quoted table's columns keep their case", set(names) == {"lowerCol", "UPPERCOL"}, (s, names))

        print("\n== D . the dataset wizard preview")
        sql = f"select REGION, sum(AMT) as AMT from {DB}.FIN.TRADES group by REGION"
        s, pv, _ = admin.call("POST", "/api/datasets/preview", {"connection_id": cid, "sql": sql, "limit": 50})
        check("rows == truth", s == 200 and by_region((pv or {}).get("rows")) == TRUTH, (s, str(pv)[:200]))
        types = (pv or {}).get("column_types") or {k.get("name"): k.get("type") for k in (pv or {}).get("columns") or []
                                                   if isinstance(k, dict)}
        check("types are Snowflake NAMES", types and all(str(v)[:1].isalpha() for v in types.values()), types)

        print("\n== E . datasets")
        s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"sf_real_{TAG}", "subject": "proof",
                                                        "connection_ids": [cid],
                                                        "base_query": f"select REGION, AMT, DT from {DB}.FIN.TRADES"})
        if not check("dataset created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:200])):
            return 1
        did = ds["id"]
        undo.insert(0, f"/api/datasets/{did}")
        admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
        _, d, _ = admin.call("GET", f"/api/datasets/{did}")
        cols = {x["physical_name"].lower(): x for x in d["columns"]}
        check("auto-detect: AMT number, DT date, REGION string",
              cols.get("amt", {}).get("data_type") == "number" and cols.get("dt", {}).get("data_type") == "date"
              and cols.get("region", {}).get("data_type") == "string",
              {k: v.get("data_type") for k, v in cols.items()})
        s, run, _ = admin.call("POST", f"/api/datasets/{did}/execute",
                               {"column_ids": [cols["region"]["id"], cols["amt"]["id"]]})
        _, page, _ = admin.call("GET", f"/api/datasets/executions/{(run or {}).get('execution_id')}/results?offset=0&limit=50")
        check("its run == truth", by_region((page or {}).get("rows")) == TRUTH, by_region((page or {}).get("rows")))

        s, ds2, _ = admin.call("POST", "/api/datasets", {"name": f"sf_case_{TAG}", "subject": "proof",
                                                         "connection_ids": [cid],
                                                         "base_query": f'select "lowerCol", UPPERCOL from {DB}.FIN."MixedCase"'})
        if check("C. a dataset over the quoted table is created", s in (200, 201) and (ds2 or {}).get("id"), (s, str(ds2)[:200])):
            did2 = ds2["id"]
            undo.insert(0, f"/api/datasets/{did2}")
            admin.call("POST", f"/api/datasets/{did2}/auto-detect", {})
            _, d2, _ = admin.call("GET", f"/api/datasets/{did2}")
            phys = [x["physical_name"] for x in d2["columns"]]
            check("C. auto-detect keeps the quoted spelling", set(phys) == {"lowerCol", "UPPERCOL"}, phys)
            s, r2, _ = admin.call("POST", f"/api/datasets/{did2}/execute", {"column_ids": [x["id"] for x in d2["columns"]]})
            _, p2, _ = admin.call("GET", f"/api/datasets/executions/{(r2 or {}).get('execution_id')}/results?offset=0&limit=50")
            # both columns are numbers, so the dataset sums them as measures
            got = [(int(r.get("lowerCol")), int(r.get("UPPERCOL"))) for r in (p2 or {}).get("rows") or []
                   if isinstance(r, dict) and r.get("lowerCol") is not None]
            check("C. it runs on the quoted column (measures summed: 1+2, 10+20)", got == [(3, 30)], (s, str(p2)[:240]))

        print("\n== F . a report, its exports, its published API")
        s, rep, _ = admin.call("POST", "/api/business-reports", {"name": f"sf-real-rep-{TAG}", "dataset_id": did,
                                                                 "data_source_type": "dataset",
                                                                 "column_ids": [cols["region"]["id"], cols["amt"]["id"]]})
        if check("report created", s == 200 and (rep or {}).get("id"), (s, str(rep)[:160])):
            rid = rep["id"]
            undo.insert(0, f"/api/business-reports/{rid}")
            _, ex, _ = admin.call("POST", f"/api/business-reports/{rid}/execute", {"parameter_values": {}, "force_refresh": True})
            _, rb, _ = admin.call("GET", f"/api/business-reports/{rid}/results/{(ex or {}).get('execution_id')}?page_size=50")
            check("the report == truth", by_region(rows_of(rb)) == TRUTH, by_region(rows_of(rb)))
            s, body, _ = admin.call("GET", f"/api/business-reports/{rid}/download-csv", raw=True)
            text = bytes(body).decode("utf-8-sig") if isinstance(body, (bytes, bytearray)) else ""
            got = {r[0]: round(float(r[1]), 2) for r in list(csv.reader(io.StringIO(text)))[1:] if len(r) >= 2 and r[0]}
            check("CSV == truth", s == 200 and got == TRUTH, (s, got))
            s, body, _ = admin.call("GET", f"/api/business-reports/{rid}/download-excel", raw=True)
            check("Excel is a workbook", s == 200 and bytes(body or b"")[:2] == b"PK", s)
            s, body, _ = admin.call("GET", f"/api/business-reports/{rid}/download-pdf", raw=True)
            check("PDF is a PDF", s == 200 and bytes(body or b"")[:4] == b"%PDF", s)
            admin.call("POST", f"/api/business-reports/{rid}/publish", {"action": "publish"})
            slug = f"sf-real-pv-{TAG}"
            s, pv, _ = admin.call("POST", "/api/published-views", {"name": slug, "slug": slug,
                                                                   "source_type": "business_report",
                                                                   "business_report_id": rid,
                                                                   "credential_mode": "publisher"})
            if (pv or {}).get("id"):
                undo.insert(0, f"/api/published-views/{pv['id']}")
            import qs_docker_client as c
            saved = c.BASE
            c.BASE = PUB
            try:
                s, b, _ = c.call("GET", f"/api/v1/views/{slug}/data?limit=50", None,
                                 headers={"X-API-Key": (pv or {}).get("test_api_key", "")})
            finally:
                c.BASE = saved
            check("the published API (:8003) == truth", s == 200 and by_region((b or {}).get("data")) == TRUTH,
                  (s, str(b)[:200]))

        print("\n== K . a FEED from Snowflake: SQL -> CSV file, delivered")
        s, fb, _ = admin.call("POST", "/api/feeds", {
            "name": f"SF_REAL_FEED_{TAG}", "source_type": "raw_sql", "source_id": 0, "connection_id": cid,
            "output_format": "csv", "destination_type": "local",
            "destination_config": {"path": "/app/data/feeds"},
            "query_params": {"sql": f"select REGION, sum(AMT) as AMT from {DB}.FIN.TRADES group by REGION"}})
        fid = (fb or {}).get("id") if isinstance(fb, dict) else None
        if check("feed created", s == 200 and fid, (s, str(fb)[:200])):
            undo.insert(0, f"/api/feeds/{fid}")
            s, ex, _ = admin.call("POST", f"/api/feeds/{fid}/execute", {"trigger_type": "manual"})
            dbid = (ex or {}).get("execution_db_id")
            e, t0 = {}, time.time()
            while dbid and time.time() - t0 < 300:
                _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                if (e or {}).get("status") in ("completed", "failed", "error", "cancelled", "skipped"):
                    break
                time.sleep(2)
            path = (e or {}).get("destination_path")
            body = ""
            denv = dict(os.environ, MSYS_NO_PATHCONV="1")
            if path:
                body = subprocess.run(["docker", "exec", "qs-local-api", "cat", path],
                                      capture_output=True, text=True, env=denv).stdout
                subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", path], env=denv)
            got = {}
            for r in list(csv.reader(io.StringIO(body)))[1:]:
                if len(r) >= 2 and r[0]:
                    got[r[0]] = round(float(r[1]), 2)
            check("the feed completed and its delivered file == Snowflake",
                  (e or {}).get("status") == "completed" and got == TRUTH,
                  {"status": (e or {}).get("status"), "file": got, "path": path,
                   "err": str((e or {}).get("error_message"))[:200]})

        print("\n== G . a big table: TPCH_SF1.ORDERS")
        truth_n = host_sql(con, "select count(*), sum(o_totalprice) from SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS")[0]
        s, rows, _ = run_sql(admin, cid, "select count(*) as N, sum(o_totalprice) as S from SNOWFLAKE_SAMPLE_DATA.TPCH_SF1.ORDERS")
        r0 = {str(k).upper(): v for k, v in (rows[0].items() if s == 200 and rows else {}.items())}
        check("count and sum over 1.5M rows == Snowflake", s == 200 and int(r0.get("N", -1)) == int(truth_n[0])
              and abs(float(r0.get("S", 0)) - float(truth_n[1])) < 0.01 and truth_n[0] > 1_000_000,
              (r0, truth_n))

        print("\n== H . the analyst selects it, sees nothing of it")
        admin.call("PUT", f"/api/connections/{cid}", {"name": g["name"], "connection_type": "snowflake",
                                                      "config": g["config"], "is_shared": True})
        _, lst, _ = analyst.call("GET", "/api/connections")
        mine = {x["id"]: x for x in lst or []}
        check("listed for the analyst, with no configuration", cid in mine
              and not ({"account", "user", "system_account_id", "private_key"} & set(mine[cid].get("config") or {})),
              (mine.get(cid) or {}).get("config"))
        s, rows, _ = run_sql(analyst, cid, f"select REGION, sum(AMT) as AMT from {DB}.FIN.TRADES group by REGION")
        check("the analyst's query on it == truth", s == 200 and by_region(rows) == TRUTH, (s, str(rows)[:200]))
        s, _, _ = analyst.call("PUT", f"/api/connections/{cid}", {"name": "x", "connection_type": "snowflake",
                                                                  "config": {"account": "attacker"}})
        check("the analyst cannot edit it", s == 403, s)

        print("\n== I . cancel stops the query IN Snowflake")
        marker = f"qs-cancel-proof-{TAG}"
        long_sql = (f"select /* {marker} */ count(distinct ss_customer_sk, ss_item_sk) "
                    "from SNOWFLAKE_SAMPLE_DATA.TPCDS_SF10TCL.STORE_SALES")
        s, r, _ = admin.call("POST", "/api/sql/execute", {"primary_connection_id": cid, "primary_sql": long_sql,
                                                          "row_limit": 10})
        eid = (r or {}).get("execution_id")
        time.sleep(8)
        s_c, cb, _ = admin.call("POST", f"/api/executions/{eid}/cancel")
        t_cancel = time.time()
        verdict = None
        while time.time() - t_cancel < 90:
            hist = host_sql(con, "select execution_status, error_message, total_elapsed_time "
                                 "from table(SNOWFLAKE_SAMPLE_DATA.information_schema.query_history_by_user("
                                 f"user_name=>'{SF_USER}', result_limit=>200)) "
                                 f"where query_text ilike '%{marker}%' and query_text not ilike '%query_history%'")
            if hist and hist[0][0] not in ("RUNNING", "QUEUED", "RESUMING_WAREHOUSE"):
                verdict = hist[0]
                break
            time.sleep(3)
        waited = round(time.time() - t_cancel, 1)
        check("the Snowflake query ENDS as canceled within seconds of the Cancel click",
              s_c == 200 and verdict is not None and "cancel" in str(verdict[1]).lower() and waited < 25,
              {"cancel_http": s_c, "history": verdict, "seconds_after_cancel": waited})

        print("\n== J . session expiry: QueryStudio's session is killed server-side")
        s, r1, _ = run_sql(admin, cid, "select current_session() as SID")
        s2, r2, _ = run_sql(admin, cid, "select current_session() as SID")
        sid1 = str((r1 or [{}])[0].get("SID")) if s == 200 else None
        sid2 = str((r2 or [{}])[0].get("SID")) if s2 == 200 else None
        reused = sid1 and sid1 == sid2
        print("   session reused across executions:", reused, sid1, sid2)
        if sid1:
            host_sql(con, f"select system$abort_session({sid2 or sid1})")
        s3, r3, _ = run_sql(admin, cid, "select current_session() as SID")
        sid3 = str((r3 or [{}])[0].get("SID")) if s3 == 200 else None
        check("after the session is aborted the next query still answers, on a NEW session",
              s3 == 200 and sid3 and sid3 != (sid2 or sid1), {"before": sid2 or sid1, "after": sid3, "http": s3, "body": str(r3)[:200]})
    finally:
        for p in undo:
            admin.call("DELETE", p)
        try:
            host_sql(con, f"drop database if exists {DB}")
        finally:
            con.close()
        print(f"\ncleanup: {len(undo)} objects + database {DB} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED  (truth: {TRUTH})")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
