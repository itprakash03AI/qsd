"""Data PRUNING proven on REAL AWS, live on Docker (2026-10-07).

Owner: "data pruning too on docker" -- "100% prod ready".

The risk is one-directional: pruning too much is ROW LOSS behind a 200,
pruning too little is slow and correct.  So every shape is judged three ways,
each against an INDEPENDENT truth (Trino on the same Iceberg tables), never
against QueryStudio's own counters alone:

  1. ROWS     -- the answer's multiset equals Trino's (count, per-partition
                 groups and the money sum; a lost row and a duplicate cannot
                 cancel out).
  2. FLOOR    -- QueryStudio READ at least the files that hold a matching row
                 (Trino ``count(distinct "$path")`` under the same WHERE).
                 Fewer = files dropped that held answers.
  3. CEILING  -- it read no more than the files the PARTITIONS allow (Trino
                 ``"<t>$files"`` under the partition-only predicate a correct
                 pruner may use; for a predicate the product deliberately
                 refuses -- a wrapped column, a range on a STRING partition --
                 the ceiling is the refusal's scope, documented per shape).
                 More = the ocean, not the island.

The files-read number comes from ``GET /api/admin/queries/pruning-history
?execution_id=`` (one row per reader call).  NO ROW FOR THE EXECUTION IS A
FAILURE, never a pass: a check that passes when it measured nothing is how
this rig has fooled itself before.

Each shape runs COLD (cache bypass) and then WARM (auto: the caches the cold
run filled) and both must give Trino's answer.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/aws_pruning_proof.py [--only P1,P2] [--timeout 1800]
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from aws_tb_proof import CAT, string_type_violations, summarise, trino  # noqa: E402

S3_CONN_NAME = os.environ.get("QS_AWS_CONN_NAME", "aws-real")
res = []

D1, D2, D3 = "2025-09-29", "2025-09-30", "2025-10-01"
COB = f"business_close_date = DATE '{D2}'"
PCOB = f"partition.business_close_date = DATE '{D2}'"
GROUPED = ("select business_close_date, business_event, code, count(*) as n, "
           "sum(gbp_currency_amount) as gbp from {t} where {w} group by 1,2,3")
# fact_tetb_ext (merge-on-read) carries no amount; its rows are judged by the
# per-partition COUNT, which is exactly what a missed delete would change
GROUPED_EXT = ("select business_close_date, business_event, code, count(*) as n "
               "from {t} where {w} group by 1,2,3")

# (id, what, table, WHERE (column names as the user writes them),
#  ceiling = Trino $files predicate a correct pruner may reach (None = every
#  file of the table), why the ceiling is that)
SHAPES = [
    ("P1", "one COB", "fact_tetb", COB, PCOB, "identity partition equality"),
    ("P2", "COB + code '1000'", "fact_tetb", f"{COB} and code = '1000'",
     f"{PCOB} and partition.code = '1000'", "two identity equalities"),
    ("P3", "COB + event + code", "fact_tetb",
     f"{COB} and business_event = 'BOOKING' and code = '1000'",
     f"{PCOB} and partition.business_event = 'BOOKING' and partition.code = '1000'", "three equalities: one file"),
    ("P4", "IN with members missing from the tree ('100', 'NOPE')", "fact_tetb",
     f"{COB} and code in ('51', '83', '1000', '100', 'NOPE')",
     f"{PCOB} and partition.code in ('51', '83', '1000', '100', 'NOPE')", "IN is membership, exact"),
    ("P5", "try_cast(code AS integer) > 50 -- numeric compare on a STRING partition", "fact_tetb",
     f"{COB} and try_cast(code as integer) > 50", PCOB,
     "a wrapped column is REFUSED (declared): only the COB prunes"),
    ("P6", "lower(code) = 'sap' -- case-folded partition", "fact_tetb",
     f"{COB} and lower(code) = 'sap'", PCOB, "wrapped column refused; 'SAP' must not be lost"),
    ("P7", "code > '50' -- quoted range on a STRING partition", "fact_tetb",
     f"{COB} and code > '50'",
     # every reading must agree before a code is dropped: '6'..'9x' are > '50'
     # lexically AND numerically-or-not; keep the ceiling at the COB (exact
     # drops are allowed, a wrong drop is caught by FLOOR + ROWS)
     PCOB, "string range: drop only when lexical/numeric/temporal all say fail"),
    ("P8", "COB BETWEEN two dates", "fact_tetb",
     f"business_close_date between DATE '{D1}' and DATE '{D2}'",
     f"partition.business_close_date between DATE '{D1}' and DATE '{D2}'", "date range on a DATE partition"),
    ("P9", "COB >= a date", "fact_tetb", f"business_close_date >= DATE '{D3}'",
     f"partition.business_close_date >= DATE '{D3}'", "open range"),
    ("P10", "code LIKE '1%'", "fact_tetb", f"{COB} and code like '1%'", PCOB, "LIKE is not a partition prune"),
    ("P11", "NOT IN on partition columns", "fact_tetb",
     f"{COB} and code not in ('SAP', '1000') and business_event not in ('CANCEL')",
     f"{PCOB} and partition.code not in ('SAP', '1000') and partition.business_event not in ('CANCEL')",
     "NOT IN may prune exactly"),
    ("P12", "same-column OR (code = '5' OR code = 'SAP')", "fact_tetb",
     f"{COB} and (code = '5' or code = 'SAP')", f"{PCOB} and partition.code in ('5', 'SAP')", "collapses to IN"),
    ("P13", "cross-column OR across partitions", "fact_tetb",
     f"(business_close_date = DATE '{D1}' and business_event = 'BOOKING') or "
     f"(business_close_date = DATE '{D3}' and code = '1000')",
     f"(partition.business_close_date = DATE '{D1}' and partition.business_event = 'BOOKING') or "
     f"(partition.business_close_date = DATE '{D3}' and partition.code = '1000')", "OR of AND groups"),
    ("P14", "non-partition column only (system_id = 'SAP')", "fact_tetb", "system_id = 'SAP'", None,
     "no partition predicate: stats may prune, never required"),
    ("P15", "function on the partition: date_trunc('month', COB)", "fact_tetb",
     "date_trunc('month', business_close_date) = DATE '2025-10-01'", None, "wrapped: refused"),
    ("P16", "the EVOLVED column: reporting_basis IS NULL", "fact_tetb", "reporting_basis is null", None,
     "schema evolution: old files have no such column"),
    ("P17", "table-qualified columns (t.code, t.business_close_date)", "fact_tetb t",
     f"t.business_close_date = DATE '{D2}' and t.code = '1000'",
     f"{PCOB} and partition.code = '1000'", "qualifier stripped like the bare name"),
    ("P18", "a value in NO partition -> 0 rows, PROVEN (not an error)", "fact_tetb",
     f"{COB} and code = 'NOPE'", f"{PCOB} and partition.code = 'NOPE'", "empty island must be proven"),
    ("P19", "merge-on-read table (position deletes) one COB", "fact_tetb_ext", COB, PCOB,
     "deletes applied: the ROWS check is the delete check"),
]


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"{'PASS' if ok else 'FAIL'} {name} -- {str(detail)[:600]}", flush=True)
    return ok


def run_s3(sql, conn, strategy, timeout):
    t0 = time.time()
    s, b, _ = c.call("POST", "/api/execute", {"connection_id": conn, "cache_strategy": strategy,
                                              "raw_sql": sql}, timeout=120)
    if s != 200 or not (b or {}).get("execution_id"):
        return {"error": f"submit HTTP {s}: {str(b)[:300]}"}
    eid = b["execution_id"]
    st = None
    while time.time() - t0 < timeout:
        _, st, _ = c.call("GET", f"/api/executions/{eid}/status")
        stt = (st or {}).get("status") if isinstance(st, dict) else None
        if stt in ("completed", "success", "finished"):
            break
        if stt in ("failed", "error", "cancelled"):
            return {"error": f"run {stt}: {str((st or {}).get('error_message'))[:400]}", "eid": eid}
        time.sleep(1.5)
    else:
        c.call("POST", f"/api/executions/{eid}/cancel")
        return {"error": f"timed out after {timeout}s", "eid": eid}
    expected = (st or {}).get("total_rows") if isinstance(st, dict) else None
    out, cols, n = [], None, 1
    while True:
        s, rb, _ = c.call("GET", f"/api/executions/{eid}/results?page={n}&page_size=5000")
        if s != 200 or not isinstance(rb, dict) or str(rb.get("status") or "") in ("pending", "failed", "error"):
            return {"error": f"results page {n}: HTTP {s} {str(rb)[:200]} -- rows UNKNOWN", "eid": eid}
        names = [x["name"] if isinstance(x, dict) else x for x in rb.get("columns") or []]
        cols = cols or names
        rows = [(r if isinstance(r, dict) else dict(zip(names, r))) for r in rb.get("rows") or []]
        out += rows
        if len(rows) < 5000:
            break
        n += 1
    if isinstance(expected, int) and expected != len(out):
        return {"error": f"status total_rows={expected} but pages held {len(out)}", "eid": eid}
    return {"cols": cols or [], "rows": out, "eid": eid, "secs": round(time.time() - t0, 1)}


def _from_log(eid, base):
    """The engine's own per-execution line, written by the query path:
    ``[execute_query_background <eid>] post-prune scan total: N file(s)
    across K table(s) [fact_tetb=N, ...]``.  None when not logged."""
    r = subprocess.run(["docker", "logs", "--since", "90m", "qs-local-api"], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    found = None
    for ln in ((r.stdout or "") + (r.stderr or "")).splitlines():
        if eid in ln and "post-prune scan total" in ln:
            m = re.search(rf"[\[ ,]{re.escape(base)}=(\d+)", ln)
            if m:
                found = int(m.group(1))
    return found


def files_read(eid, table):
    """(files_before, files_after) for ``table`` in this execution.

    Source 1: ``GET /api/admin/queries/pruning-history?execution_id=``
    (the brain's record; files_before_prune / files_after_prune).
    Source 2: the engine's per-execution ``post-prune scan total`` log line
    (files_after only).  NEITHER = None: a failure, never a pass."""
    base = table.split()[0].lower()
    s, b, _ = c.call("GET", f"/api/admin/queries/pruning-history?execution_id={eid}&limit=50")
    rows = (b or {}).get("rows") if isinstance(b, dict) else None
    # Trino lays a table out at <schema>/<name>-<uuid>/ (or <name>/): the last
    # path segment IS the name, exactly -- fact_tetb must not match fact_tetb_ext
    seg = re.compile(rf"^{re.escape(base)}(-[0-9a-f]{{32}})?$")
    mine = [r for r in (rows or [])
            if seg.match(str(r.get("table_prefix") or "").lower().rstrip("/").split("/")[-1])]
    if mine:
        r = mine[-1]
        # files_read = what the ENGINE was handed (after a LIMIT trim / mirror /
        # island); files_after_prune = the pruner's verdict.  Judge the read.
        read = r.get("files_read") if isinstance(r.get("files_read"), int) else r.get("files_after_prune")
        if isinstance(read, int):
            src = "pruning-history" + (f" ({r.get('read_reason')})" if r.get("read_reason") else "")
            return (r.get("files_before_prune"), read, src), None
    logged = _from_log(eid, base)
    if logged is not None:
        return (None, logged, "engine log"), None
    return None, f"no pruning-history row (HTTP {s}, rows={len(rows or [])}) and no post-prune log line"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--timeout", type=int, default=1800)
    a = ap.parse_args()
    only = set(filter(None, a.only.split(",")))
    _, b, _ = c.call("GET", "/api/connections")
    items = b if isinstance(b, list) else (b.get("items") or b.get("connections") or [])
    conn = next(x["id"] for x in items if x.get("name") == S3_CONN_NAME)

    # the dates the shapes name must exist, or a shape proves nothing
    cobs = {r["business_close_date"][:10] for r in trino(f"select distinct business_close_date from {CAT}fact_tetb")}
    check("the COBs the shapes use exist in fact_tetb", {D1, D2, D3} <= cobs, sorted(cobs))

    for pid, what, table, where, ceiling, why in SHAPES:
        if only and pid not in only:
            continue
        base = table.split()[0]
        alias = table[len(base):]
        tmpl = GROUPED_EXT if base.endswith("_ext") else GROUPED
        sql_trino = tmpl.format(t=f"{CAT}{base}{alias}", w=where)
        sql_qs = tmpl.format(t=f"{base}{alias}", w=where)
        try:
            truth = summarise(None, trino(sql_trino), "exact")
            floor = int(trino(f'select count(distinct "$path") as n from {CAT}{base}{alias} where {where}')[0]["n"])
            ceil_n = int(trino(f'select count(*) as n from {CAT}"{base}$files"'
                               + (f" where {ceiling}" if ceiling else ""))[0]["n"])
        except Exception as exc:  # noqa: BLE001
            check(f"{pid} truth from Trino", False, exc)
            continue
        for strategy in ("bypass", "auto"):
            out = run_s3(sql_qs, conn, strategy, a.timeout)
            tag = f"{pid} [{'cold' if strategy == 'bypass' else 'warm'}] {what}"
            if "error" in out:
                check(tag, False, out)
                continue
            got = summarise(out["cols"], out["rows"], "exact")
            rows_ok = got == truth and not string_type_violations(out["rows"])
            fr, why_none = files_read(out["eid"], base)
            if fr is None and strategy == "auto":
                # the warm run may be answered by a result cache with no
                # reader call -- judged on its rows only; the COLD run above
                # always has its files measured
                check(f"{tag} ({out['secs']}s, served without a file read)", rows_ok,
                      {"rows": rows_ok, "files": why_none})
                continue
            if fr is None:
                check(tag, False, {"rows_ok": rows_ok, "files": f"NOT MEASURED -- {why_none}"})
                continue
            before, after, src = fr
            floor_ok = after >= floor
            # a warm run may be served from a cache with no reader call; that
            # is fine only when its rows are right (no files to judge)
            ceil_ok = after <= ceil_n
            check(f"{tag} ({out['secs']}s)", rows_ok and floor_ok and ceil_ok,
                  {"rows": rows_ok, "groups": len(got), "truth_groups": len(truth),
                   "files_read": after, "of": before, "measured_by": src, "floor(hold rows)": floor,
                   "ceiling(partitions allow)": ceil_n, "ceiling_rule": why,
                   "got": got[:2] if not rows_ok else "", "truth": truth[:2] if not rows_ok else ""})

    # a bare LIMIT reads only the leading files (limit early stop)
    if not only or "P20" in only:
        out = run_s3("select * from fact_tetb limit 100", conn, "bypass", a.timeout)
        total = int(trino(f'select count(*) as n from {CAT}"fact_tetb$files"')[0]["n"])
        fr, why_none = files_read(out.get("eid", ""), "fact_tetb") if "error" not in out else (None, out["error"])
        check("P20 bare LIMIT 100: exactly 100 rows, reads a few files not the table",
              "rows" in out and len(out["rows"]) == 100 and fr is not None and fr[1] < total / 10,
              {"rows": len(out.get("rows") or []), "files_read": fr, "table_files": total, "why": why_none})

    print(f"\n{sum(res)}/{len(res)} PASSED" if all(res) else f"\n{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
