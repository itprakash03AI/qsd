"""Report filter / parameter values come FROM THE DATA -- distinct values,
dates that exist, cascading -- on the REAL Snowflake account (2026-10-03,
login ON).

Owner: "filter value should popup n fill dropdown....cant hardcoded";
"report parameter should be generic n should come from table distinct
values"; "if its date should come whatever data available in table";
"even same ways cascading dropdown".

Dataset over QS_DEMO.FIN.TRADES joined to REGIONS (REGION, MANAGER, DT,
AMT); every list is judged against Snowflake's own DISTINCT:
  1. a column's values: REGION == Snowflake's 4, MANAGER == its 4;
  2. a DATE column: exactly the dates that exist, newest first, YYYY-MM-DD;
     cut at 10 -> says so and gives the data's MIN..MAX;
  3. cascading: MANAGER under REGION=EMEA -> only EMEA's manager; DT under
     REGION=EMEA -> only dates with EMEA trades;
  4. a report with three column-bound parameters (REGION; MANAGER depends
     on REGION; DT): each parameter's values come from its column (none
     hand-typed), the child's from the parent's pick, and a run with
     REGION=EMEA, DT=<a real date> == Snowflake.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_report_params_proof.py
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from snowflake_wide_table_proof import sf  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
TAG = str(int(time.time()))[-6:]
BASE = ("select t.REGION, r.MANAGER, t.DT, t.AMT from QS_DEMO.FIN.TRADES t "
        "join QS_DEMO.FIN.REGIONS r on t.REGION = r.REGION")
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return bool(ok)


def vals(body):
    out = (body or {}).get("values") or []
    return [str(v.get("value") if isinstance(v, dict) else v) for v in out]


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    con = sf()
    cur = con.cursor()
    q = lambda s: [r[0] for r in cur.execute(s).fetchall()]  # noqa: E731
    t_regions = sorted(q("select distinct REGION from QS_DEMO.FIN.TRADES"))
    t_managers = sorted(q("select distinct MANAGER from QS_DEMO.FIN.REGIONS"))
    t_dates = [str(d) for d in q("select distinct DT from QS_DEMO.FIN.TRADES order by DT desc")]
    t_emea_mgr = q("select MANAGER from QS_DEMO.FIN.REGIONS where REGION='EMEA'")
    t_emea_dates = [str(d) for d in q("select distinct DT from QS_DEMO.FIN.TRADES where REGION='EMEA' order by DT desc")]
    check("truth is non-trivial", len(t_regions) == 4 and len(t_dates) > 30 and t_emea_mgr,
          (t_regions, len(t_dates), t_emea_mgr))
    undo = []
    try:
        s, ds, _ = admin.call("POST", "/api/datasets", {"name": f"sf_params_{TAG}", "subject": "proof",
                                                        "connection_ids": [CID], "base_query": BASE})
        if not check("dataset created", s in (200, 201), (s, str(ds)[:200])):
            return 1
        did = ds["id"]
        undo.insert(0, f"/api/datasets/{did}")
        admin.call("POST", f"/api/datasets/{did}/auto-detect", {})
        _, d, _ = admin.call("GET", f"/api/datasets/{did}")
        col = {c["physical_name"].upper(): c for c in d["columns"]}
        check("columns typed (DT a date)", col.get("DT", {}).get("data_type") == "date",
              {k: v.get("data_type") for k, v in col.items()})

        def lov(name, parent=None, **kw):
            body = {"column_id": col[name]["id"], "parent_filters": parent or []}
            body.update(kw)
            return admin.call("POST", f"/api/datasets/{did}/column-values", body)

        print("\n== 1 . distinct values")
        s, b, _ = lov("REGION")
        check("REGION values == Snowflake's DISTINCT", s == 200 and sorted(vals(b)) == t_regions, (s, vals(b)))
        s, b, _ = lov("MANAGER")
        check("MANAGER values == Snowflake's DISTINCT", s == 200 and sorted(vals(b)) == t_managers, (s, vals(b)))

        print("\n== 2 . dates that exist")
        s, b, _ = lov("DT")
        check("DT: exactly the dates in the data, newest first, YYYY-MM-DD",
              s == 200 and vals(b) == t_dates and not b.get("truncated"),
              (s, vals(b)[:3], len(vals(b)), len(t_dates), b.get("truncated")))
        s, b, _ = lov("DT", limit=10, include_range=True)
        rng = (b or {}).get("range") or {}
        check("cut at 10: says truncated, gives the data's MIN..MAX",
              s == 200 and len(vals(b)) == 10 and b.get("truncated") is True
              and str(rng.get("min"))[:10] == t_dates[-1] and str(rng.get("max"))[:10] == t_dates[0],
              (s, len(vals(b)), b.get("truncated"), rng))

        print("\n== 3 . cascading")
        emea = [{"column_id": col["REGION"]["id"], "operator": "eq", "value": "EMEA"}]
        s, b, _ = lov("MANAGER", emea)
        check("MANAGER under REGION=EMEA == only EMEA's manager", s == 200 and vals(b) == t_emea_mgr, (s, vals(b)))
        s, b, _ = lov("DT", emea)
        check("DT under REGION=EMEA == only dates with EMEA trades", s == 200 and vals(b) == t_emea_dates,
              (s, len(vals(b)), len(t_emea_dates)))

        print("\n== 4 . a report with column-bound, cascading parameters")
        s, rep, _ = admin.call("POST", "/api/business-reports", {
            "name": f"sf-params-{TAG}", "dataset_id": did, "data_source_type": "dataset",
            "column_ids": [col["REGION"]["id"], col["MANAGER"]["id"], col["AMT"]["id"]]})
        if not check("report created", s == 200, (s, str(rep)[:200])):
            return 1
        rid = rep["id"]
        undo.insert(0, f"/api/business-reports/{rid}")
        s, p_reg, _ = admin.call("POST", f"/api/business-reports/{rid}/parameters", {
            "name": "REGION", "label": "Region", "parameter_type": "dropdown",
            "lov_column_id": col["REGION"]["id"], "is_required": False})
        s2, p_mgr, _ = admin.call("POST", f"/api/business-reports/{rid}/parameters", {
            "name": "MANAGER", "label": "Manager", "parameter_type": "dropdown",
            "lov_column_id": col["MANAGER"]["id"], "depends_on_param_id": (p_reg or {}).get("id"),
            "cascade_filter_column_id": col["REGION"]["id"], "is_required": False, "sort_order": 1})
        s3, p_dt, _ = admin.call("POST", f"/api/business-reports/{rid}/parameters", {
            "name": "DT", "label": "Trade date", "parameter_type": "date",
            "lov_column_id": col["DT"]["id"], "depends_on_param_id": (p_reg or {}).get("id"),
            "cascade_filter_column_id": col["REGION"]["id"], "is_required": False, "sort_order": 2})
        check("three column-bound parameters created", (s, s2, s3) == (200, 200, 200),
              (s, s2, s3, str(p_dt)[:160]))

        def pv(param, parent=None):
            return admin.call("POST", f"/api/business-reports/{rid}/parameter-values",
                              {"parameter_id": param["id"], "parent_values": parent or {}})
        s, b, _ = pv(p_reg)
        check("REGION parameter offers Snowflake's regions", s == 200 and sorted(vals(b)) == t_regions, (s, vals(b)))
        s, b, _ = pv(p_mgr, {"REGION": "EMEA"})
        check("MANAGER parameter under REGION=EMEA offers only EMEA's", s == 200 and vals(b) == t_emea_mgr, (s, vals(b)))
        s, b, _ = pv(p_dt, {"REGION": "EMEA"})
        check("DT parameter under REGION=EMEA offers EMEA's dates, newest first",
              s == 200 and vals(b) == t_emea_dates, (s, vals(b)[:3], len(vals(b))))
        s, b, _ = pv(p_mgr, {"REGION": ""})
        check("a cleared parent means NO filter (all managers), not ''",
              s == 200 and sorted(vals(b)) == t_managers, (s, vals(b)))

        day = t_emea_dates[0]
        truth = cur.execute("select r.MANAGER, sum(t.AMT) from QS_DEMO.FIN.TRADES t join QS_DEMO.FIN.REGIONS r "
                            f"on t.REGION=r.REGION where t.REGION='EMEA' and t.DT='{day}' group by 1").fetchall()
        s, ex, _ = admin.call("POST", f"/api/business-reports/{rid}/execute", {
            "parameter_values": {"REGION": "EMEA", "DT": day}, "force_refresh": True})
        _, rb, _ = admin.call("GET", f"/api/business-reports/{rid}/results/{(ex or {}).get('execution_id')}?page_size=50")
        names = [x["name"] if isinstance(x, dict) else x for x in (rb or {}).get("columns") or []]
        rows = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (rb or {}).get("rows") or []]
        got = {(str(r.get("REGION")), str(r.get("MANAGER"))): round(float(r.get("AMT") or 0), 2) for r in rows}
        want = {("EMEA", truth[0][0]): round(float(truth[0][1]), 2)} if truth else {}
        check(f"the run with REGION=EMEA, DT={day} == Snowflake", s == 200 and got == want and want, (s, got, want))
    finally:
        for p in undo:
            admin.call("DELETE", p)
        con.close()
        print(f"\ncleanup: {len(undo)} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
