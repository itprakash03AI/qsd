"""'Why is the password getting blanked on connections?' -- proven on Docker (2026-10-02).

A saved secret this server cannot DECRYPT (its encryption key changed since the
save -- e.g. pods that each generated their own key) used to come back "" and
show BLANK, and an untouched Save then wrote "" over it.  This puts a REAL
connection in that state on the rig and walks what a user does:

  1. clone the working Oracle connection (a real password, it connects);
  2. in Postgres, replace its stored password with one encrypted under
     ANOTHER key -- exactly what a key change leaves behind;
  3. GET: the password reads as SAVED ("***") and credential_problems names it;
  4. an untouched Save (another field edited) KEEPS the stored value, byte for byte;
  5. clone refuses, naming the field;
  6. re-entering the password heals it: the problem clears and Test connects;
  7. the key file: 8 processes racing to create it in the API container all
     end up with the ONE key on disk.
Cleans up.  Login-OFF rig.

    python connection_secret_blank_proof.py [--source 3] [--password <oracle pw>]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

res = []
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:300], flush=True)
    return bool(ok)


def psql(sql):
    out = subprocess.run(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio",
                          "-d", "querystudio", "-tAc", sql], capture_output=True, text=True, env=ENV)
    return out.stdout.strip()


def stored_password(cid):
    return json.loads(psql(f"select config::text from connections where id={cid}") or "{}").get("password")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=int, default=3)
    ap.add_argument("--password", default=os.environ.get("QS_ORACLE_PW", ""))
    a = ap.parse_args()
    s, cl, _ = c.call("POST", f"/api/connections/{a.source}/clone", {"name": f"pw_blank_proof_{os.getpid()}"})
    if not check("clone the working connection", s in (200, 201) and cl.get("id"), (s, str(cl)[:200])):
        return 1
    cid = cl["id"]
    try:
        foreign = subprocess.run(["docker", "exec", "qs-local-api", "python", "-c",
                                  "from cryptography.fernet import Fernet as F;"
                                  "print('enc::'+F(F.generate_key()).encrypt(b'x').decode())"],
                                 capture_output=True, text=True, env=ENV).stdout.strip()
        psql(f"update connections set config = (config::jsonb || jsonb_build_object('password','{foreign}'))::json where id={cid}")
        check("its stored password is now under ANOTHER key", stored_password(cid) == foreign)

        s, g, _ = c.call("GET", f"/api/connections/{cid}")
        check("GET: the password reads as SAVED, not blank", g["config"].get("password") == "***", g["config"].get("password"))
        check("GET: credential_problems names it", g.get("credential_problems") == ["password"], g.get("credential_problems"))

        cfg = dict(g["config"])
        cfg["port"] = int(cfg.get("port") or 1521)
        s, u, _ = c.call("PUT", f"/api/connections/{cid}", {"name": cl["name"], "connection_type": "oracle", "config": cfg})
        check("an untouched Save succeeds", s == 200, (s, str(u)[:200]))
        check("...and KEEPS the stored value byte for byte", stored_password(cid) == foreign)

        s, k, _ = c.call("POST", f"/api/connections/{cid}/clone", {})
        check("clone refuses, naming the field", s == 422 and "password" in str(k), (s, str(k)[:200]))

        if a.password:
            cfg["password"] = a.password
            c.call("PUT", f"/api/connections/{cid}", {"name": cl["name"], "connection_type": "oracle", "config": cfg})
            s, g2, _ = c.call("GET", f"/api/connections/{cid}")
            check("re-entering it clears the problem", g2.get("credential_problems") == [], g2.get("credential_problems"))
            s, t, _ = c.call("POST", f"/api/connections/{cid}/test")
            check("...and the connection connects again", (t or {}).get("success") is True, (t or {}).get("message"))

        race = subprocess.run(["docker", "exec", "qs-local-api", "python", "-c", r'''
import multiprocessing as mp, tempfile, os
from cryptography.fernet import Fernet
from core.crypto import _publish_key_file_once
d = tempfile.mkdtemp(); kf = os.path.join(d, "secret.key")
def pod(q, b):
    b.wait(); q.put(_publish_key_file_once(kf, Fernet.generate_key().decode()))
if __name__ == "__main__":
    q = mp.Queue(); b = mp.Barrier(8)
    ps = [mp.Process(target=pod, args=(q, b)) for _ in range(8)]
    [p.start() for p in ps]; [p.join() for p in ps]
    keys = {q.get() for _ in ps}; disk = open(kf).read().strip()
    print(len(keys), keys == {disk})
'''], capture_output=True, text=True, env=ENV).stdout.split()
        check("8 processes racing for the key file all use the ONE key on disk", race == ["1", "True"], race)
    finally:
        c.call("DELETE", f"/api/connections/{cid}")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
