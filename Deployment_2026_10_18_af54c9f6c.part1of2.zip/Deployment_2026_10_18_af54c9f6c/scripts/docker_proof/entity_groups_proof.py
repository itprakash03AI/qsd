"""THE OWNER'S MONTH-END BOARD, BUILT AS THE OWNER RUNS IT -- live (2026-10-12).

The owner: "why it say no group ... create system entity level group n arrange
feed gen task for both table n all other combination ... u did not prove use
case what i shared".  The reference (temp/dash_v1.jpeg): a group per SYSTEM
ENTITY (ACBS_2300_EMEA, "6 DAGs") holding that entity's feeds for BOTH tables
(finance_sl_balance + finance_sl_balance_ext) x every business event.

Built here through the product only, on the OWNER'S OWN queries
(fixtures/fact_tetb.json, fixtures/test_query_001.json; verbatim but the FROM):

* TWO templates -- one per DATA_SOURCE (fact_tetb -> finance_sl_balance,
  fact_tetb_ext -> finance_sl_balance_ext), each cloud (Iceberg on the REAL AWS
  bucket through qs-trino) UNION ALL on-prem (the Starburst-shaped
  qs-trino-sb), CSV to SFTP, a month_end schedule on a business calendar, two
  dependencies (CLOUD, ONPREM) each met by the Kafka topic OR a
  QS_KAFKA_MESSAGE row, and the group rule ``feed_group_name: "{SYSTEM_ENTITY}"``;
* matrix = 3 entities x 3 events (EOD, INTRADAY, SOD) -> 18 feeds, 3 Feed
  Groups of 6 -- every (table, event) combination of every entity;
* SOD for the month end (the scoped run-now, as the scheduler runs it) -> 18
  tasks, every one WAITING on its upstream;
* then the month end as it really goes, per entity:
    EMEA  every message arrives (Kafka for CLOUD, the Oracle table for ONPREM)
          -> 6 delivered, each file == cloud truth + on-prem truth BY VALUE
    APAC  fact_tetb: all 3 delivered; ext EOD delivered; ext INTRADAY's
          ON-PREM never arrives (left WAITING); ext SOD's ON-PREM is a
          holiday -> SKIPPED for the date by the operator -> delivered with
          the cloud rows only
    AMER  fact_tetb EOD: the CLOUD message reports 99 rows, the source has 3
          -> FAILED by the per-side ROW_COUNT certification (no file);
          fact_tetb INTRADAY: nothing arrives (WAITING); the rest delivered
* the BOARD (GET /api/feed-dashboard): 3 groups named by entity, 6 feeds
  each, both tables in each, and each group's counts EXACTLY the scenario's.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/entity_groups_proof.py [--keep]
    python scripts/docker_proof/entity_groups_proof.py --sweep-leftovers [--execute]

``--keep`` leaves everything on the rig for the owner (business date 2026-12-31
on Feed Run Status); the sweep removes it.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import io
import itertools
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import connections, pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_month_end_sod_proof import await_sod  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, ORA_TABLE, SB_HOST, SB_PORT, SFTP, TABLES, TOPIC, cloud_cli, ddl,
    drop_schema_cascade, ensure_oracle_table, insert_rows, load_queries, message, ora_rows,
    parse_query, produce_kafka, row_values, sb_cli,
)

TAG = str(int(time.time()))[-6:]
#: a month end with nothing else on it (--business-date); a swept run's
#: DELIVERED tasks stay on their date's board as the deleted feeds' history
BD = dt.date(2026, 12, 31)
EVENTS = ("EOD", "INTRADAY", "SOD")
EMEA, APAC, AMER = f"E{TAG}_2300_EMEA", f"E{TAG}_4100_APAC", f"E{TAG}_5200_AMER"
ENTITIES = (EMEA, APAC, AMER)
ROWS = 3                                 # cloud rows per (entity, event); on-prem has ROWS + 1
CAL = f"EG_{TAG}"
CLOUD_SCHEMA = f"iceberg_aws.eg_{TAG}"
LABEL = {"tetb": "FINANCE_SL_BALANCE", "ext": "FINANCE_SL_BALANCE_EXT"}


def feed_name(t, ent, ev):
    return f"{ent}_{LABEL[t]}_{ev}"


def file_name(t, ent, ev):
    return f"{feed_name(t, ent, ev)}_{BD:%Y%m%d}.csv"


def wait_for(fn, timeout=240, every=3):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(every)
    return None


# ── the scenario: what each (table, entity, event) receives, and its fate ──
#: messages: (side, road, reported rows | None = the truth) ; fate: the board word
def scenario():
    plan = {}
    for t in ("tetb", "ext"):
        for ent in ENTITIES:
            for ev in EVENTS:
                plan[(t, ent, ev)] = {"msgs": [("CLOUD", "kafka", None), ("ONPREM", "oracle", None)],
                                      "skip": None, "fate": "completed"}
    plan[("ext", APAC, "INTRADAY")] = {"msgs": [("CLOUD", "kafka", None)], "skip": None, "fate": "not_started"}
    plan[("ext", APAC, "SOD")] = {"msgs": [("CLOUD", "kafka", None)], "skip": "ONPREM", "fate": "completed"}
    plan[("tetb", AMER, "EOD")] = {"msgs": [("CLOUD", "kafka", 99), ("ONPREM", "oracle", None)],
                                   "skip": None, "fate": "failed"}
    plan[("tetb", AMER, "INTRADAY")] = {"msgs": [], "skip": None, "fate": "not_started"}
    return plan


def _drop_group(r, name):
    s, gs = r.call("GET", "/api/feed-groups")
    items = gs if isinstance(gs, list) else (gs or {}).get("items") or []
    g = next((x for x in items if x.get("name") == name), None)
    if g is None:
        return True, "absent"
    s, _ = r.call("DELETE", f"/api/feed-groups/{g['id']}?detach_feeds=true")
    return s in (200, 204), f"HTTP {s}"


def board(r, search):
    s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={search}&page_size=500")
    return d if s == 200 and isinstance(d, dict) else {}


def runs_by_feed(r):
    s, b = r.call("GET", f"/api/feed-runs?business_date={BD.isoformat()}&limit=1000")
    items = (b or {}).get("items") or []
    out = {}
    for x in sorted(items, key=lambda x: int(x.get("id") or 0)):
        out[int(x.get("feed_config_id") or 0)] = x
    return out


def sweep(r, execute):
    rules = [Rule("feed template", r"EG_(TETB|EXT)_\d{6}", list_path="/api/feed-templates",
                  delete_path="/api/feed-templates/{id}?delete_members=true"),
             Rule("saved query", r"eg_(tetb|ext)_(cloud|prem)_\d{6}", list_path="/api/queries",
                  delete_path="/api/queries/{id}"),
             Rule("connection", r"sb-onprem-eg-\d{6}", list_path="/api/connections", delete_path="/api/connections/{id}"),
             Rule("feed group", r"E\d{6}_\d{4}_(EMEA|APAC|AMER)", list_path="/api/feed-groups",
                  delete_path="/api/feed-groups/{id}?detach_feeds=true")]
    rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
    for line in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'eg_%'").splitlines():
        s = line.strip().strip('"')
        if re.fullmatch(r"eg_\d{6}", s):
            print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{s}")
            if execute:
                print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{s}"))
    for line in cloud_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%_eg%'").splitlines():
        t = line.strip().strip('"')
        if re.fullmatch(r"fact_tetb(_ext)?_eg\d{6}", t):
            print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
            if execute:
                cloud_cli(f"DROP TABLE iceberg.qs.{t}")
    rc2 = subprocess.run(["docker", "exec", SFTP["container"], "sh", "-c",
                          f"ls {SFTP['home']} | grep -E '^E[0-9]{{6}}_[0-9]{{4}}_(EMEA|APAC|AMER)_' || true"],
                         capture_output=True, text=True, env=DENV).stdout.split()
    for n in rc2:
        print(f"  {'rm' if execute else 'would rm'} sftp {n}")
        if execute:
            subprocess.run(["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{n}"], env=DENV)
    return rc


def main(argv=None) -> int:
    sweep_mode, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--business-date", default=None, help="a month-end business day, YYYY-MM-DD")
    args = ap.parse_args(rest)
    global BD
    if args.business_date:
        BD = dt.date.fromisoformat(args.business_date)
    r = Rig()
    if sweep_mode:
        return sweep(r, execute)

    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    items = connections(r)
    cloud_id, _ = pick_cloud(r, "")
    ora_id = next((x["id"] for x in items if x.get("name") == "oracle-otg"), None)
    if not check("P0 connections: cloud Trino (AWS S3 Iceberg) + oracle-otg (the QS_KAFKA_MESSAGE road)",
                 cloud_id and ora_id, (cloud_id, ora_id)):
        return 2
    # a template that AUTO-ONBOARDS one of these DATA_SOURCEs would claim every
    # message of an entity it does not know -- refuse to run beside one
    s, tl = r.call("GET", "/api/feed-templates")
    tl_items = tl if isinstance(tl, list) else (tl or {}).get("items") or (tl or {}).get("templates") or []
    dss = {TABLES[t]["data_source"] for t in ("tetb", "ext")}
    others = [t.get("name") for t in tl_items
              if ((t.get("auto_onboard") or {}).get("match") or {}).get("DATA_SOURCE") in dss]
    if not check("P0 no auto-onboarding template claims these DATA_SOURCEs", not others,
                 others or "none -- sweep the kept auto_onboard_proof run first"):
        return 2
    ensure_oracle_table(ora_id)
    plan = scenario()
    print(f"== ENTITY GROUPS tag {TAG}: month end {BD}; entities {', '.join(ENTITIES)}; "
          f"2 tables x {len(EVENTS)} events -> {len(plan)} feeds")
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    seq = itertools.count(int(TAG) * 100)
    sides = {}
    try:
        # ── data on BOTH sides, both tables, every (entity, event) ─────────
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/eg_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        for t in ("tetb", "ext"):
            spec = TABLES[t]
            c_tab, p_tab = f"{CLOUD_SCHEMA}.{spec['table']}", f"iceberg.qs.{spec['table']}_eg{TAG}"
            c_sql, p_sql = load_queries(spec)
            c_sql, p_sql = c_sql.replace(spec["from_cloud"], c_tab), p_sql.replace(spec["from_onprem"], p_tab)
            _, c_types = parse_query(c_sql, spec["alias"])
            _, p_types = parse_query(p_sql, spec["alias"])
            cloud_cli(ddl(c_tab, c_types, hive=False) + ";\n", stdin=True)
            cloud_cli(ddl(p_tab, p_types, hive=False) + ";\n", stdin=True)
            ledger.add("on-prem table", p_tab,
                       remover=lambda p_tab=p_tab: (bool(cloud_cli(f"DROP TABLE {p_tab}") is not None), "dropped"))
            insert_rows(cloud_cli, c_tab, c_types,
                        [row_values("cloud", c_types, BD, e, ev, i) for e in ENTITIES for ev in EVENTS for i in range(ROWS)])
            # a HOLIDAY on-prem loads nothing: no on-prem rows where the plan skips ONPREM
            holiday = {(e, ev) for (tt, e, ev), p in scenario().items() if tt == t and p["skip"] == "ONPREM"}
            insert_rows(cloud_cli, p_tab, p_types,
                        [row_values("prem", p_types, BD, e, ev, i) for e in ENTITIES for ev in EVENTS
                         if (e, ev) not in holiday for i in range(ROWS + 1)])
            sides[t] = {"cloud_sql": c_sql, "prem_sql": p_sql, "cols": (len(c_types), len(p_types))}
            print(f"   {spec['table']}: the owner's queries, {len(c_types)} cloud / {len(p_types)} on-prem columns")

        def truth(t, side, ent, ev):
            sql = sides[t]["cloud_sql" if side == "cloud" else "prem_sql"].replace("{BUSINESSDATE}", BD.isoformat()) \
                .replace("{SYSTEM_ENTITY}", ent).replace("{EventCode}", ev)
            cli = cloud_cli if side == "cloud" else sb_cli
            out = cli(f"SELECT source_data_row FROM ({sql}) q;\n", stdin=True)
            return collections.Counter(x.strip().strip('"') for x in out.splitlines() if x.strip())
        want = {(t, side, e, ev): truth(t, side, e, ev)
                for t in ("tetb", "ext") for side in ("cloud", "prem") for e in ENTITIES for ev in EVENTS}
        plan_skips = {(t, e, ev) for (t, e, ev), p in plan.items() if p["skip"] == "ONPREM"}

        def seeded(k):
            t, side, e, ev = k
            return ROWS if side == "cloud" else (0 if (t, e, ev) in plan_skips else ROWS + 1)
        check(f"S0 seeded and read back through each Trino with the owner's SQL: every (table, entity, event) has "
              f"{ROWS} cloud + {ROWS + 1} on-prem rows (none on-prem on the holiday)",
              all(sum(v.values()) == seeded(k) for k, v in want.items()),
              collections.Counter(sum(v.values()) for v in want.values()))

        # ── connection, saved queries, calendar, the TWO templates ─────────
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-eg-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False, "catalog": "iceberg", "schema": "qs"}})
        prem_id = (b or {}).get("id")
        ledger.add("connection", f"sb-onprem-eg-{TAG}", path=f"/api/connections/{prem_id}")
        s, cal = r.call("POST", "/api/admin/feed-calendars", {"name": CAL, "weekend_days": [6, 7], "holidays": []})
        check(f"P1 business calendar {CAL} (Sat/Sun weekend) created", s in (200, 201), (s, str(cal)[:200]))
        ledger.add("calendar", CAL, path=f"/api/admin/feed-calendars/{CAL}")
        both_roads = [{"kind": "kafka", "topic": TOPIC},
                      {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
        tids = {}
        for t in ("tetb", "ext"):
            ds = TABLES[t]["data_source"]
            q = {}
            for side, cid, key in (("cloud", cloud_id, "cloud_sql"), ("prem", prem_id, "prem_sql")):
                s, qq = r.call("POST", "/api/queries", {"name": f"eg_{t}_{side}_{TAG}",
                                                       "query_config": {"files": [], "raw_sql": sides[t][key],
                                                                        "connection_id": cid}})
                q[side] = (qq or {}).get("id")
                ledger.add("saved query", f"eg_{t}_{side}_{TAG}", path=f"/api/queries/{q[side]}")
            name = f"EG_{t.upper()}_{TAG}"
            body = {
                "name": name, "parameters": ["SYSTEM_ENTITY", "EventCode"],
                "feed": {"name": f"{{SYSTEM_ENTITY}}_{LABEL[t]}_{{EventCode}}",
                         "source_type": "saved_query", "source_id": q["cloud"], "connection_id": cloud_id,
                         "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
                         "secondary_source_id": q["prem"], "combine_mode": "union", "output_format": "csv",
                         "output_filename_template": f"{{SYSTEM_ENTITY}}_{LABEL[t]}_{{EventCode}}_{{business_date:YYYYMMDD}}.csv",
                         "destination_type": "sftp",
                         "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                                "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                                "host_key_b64": sftp_host_key()},
                         "schedule_declaration": {"kind": "month_end", "calendar_name": CAL}, "calendar_name": CAL,
                         "execution_backend": "native", "notify_on_failure": False,
                         "sla_to": "+23:30", "sla_timezone": "Europe/London",
                         "feed_group_name": "{SYSTEM_ENTITY}"},
                "dependencies": [
                    {"dependency_type": "KAFKA", "dependency_key": f"{ds}_{{SYSTEM_ENTITY}}_{{EventCode}}_{side}",
                     "arrival_sources": both_roads, "require_mode": "any",
                     # each side's message vouches for that side's ROW_COUNT
                     "certifies_side": "primary" if side == "CLOUD" else "secondary"}
                    for side in ("CLOUD", "ONPREM")],
                "matrix": [{"SYSTEM_ENTITY": e, "EventCode": ev} for e in ENTITIES for ev in EVENTS],
            }
            s, out = r.call("POST", "/api/feed-templates", body, timeout=900)
            tid = ((out or {}).get("template") or {}).get("id")
            rep = (out or {}).get("report") or {}
            check(f"P2 template {name} ({TABLES[t]['table']} -> {ds}): {len(ENTITIES) * len(EVENTS)} members created",
                  s == 201 and tid and len(rep.get("created") or []) == len(ENTITIES) * len(EVENTS),
                  (s, {k: (len(v) if isinstance(v, list) else v) for k, v in rep.items()} if rep else str(out)[:400]))
            if not tid:
                return 1
            tids[t] = tid
            ledger.add("feed template", name, path=f"/api/feed-templates/{tid}?delete_members=true")
        for ent in ENTITIES:
            ledger.add("feed group", ent, remover=lambda ent=ent: _drop_group(r, ent))

        # ── the groups: one per entity, BOTH tables x every event in each ──
        s, fl = r.call("GET", "/api/feeds?limit=5000")
        feeds = fl if isinstance(fl, list) else (fl or {}).get("items") or (fl or {}).get("feeds") or []
        fid = {f["name"]: f["id"] for f in feeds if str(f.get("name", "")).startswith(f"E{TAG}_")}
        s, gl = r.call("GET", "/api/feed-groups")
        groups = {g["name"]: g for g in (gl if isinstance(gl, list) else (gl or {}).get("items") or [])}
        by_group = collections.defaultdict(set)
        for f in feeds:
            if f.get("name") in fid and f.get("feed_group_id"):
                by_group[f["feed_group_id"]].add(f["name"])
        ok = all(ent in groups and by_group[groups[ent]["id"]] ==
                 {feed_name(t, ent, ev) for t in ("tetb", "ext") for ev in EVENTS} for ent in ENTITIES)
        check("G0 the group rule made ONE Feed Group per system entity, each holding its 6 feeds: "
              "finance_sl_balance + finance_sl_balance_ext x EOD / INTRADAY / SOD",
              ok and len(fid) == len(plan),
              {ent: sorted(n.replace(ent + "_", "") for n in by_group.get((groups.get(ent) or {}).get("id"), []))
               for ent in ENTITIES})
        if len(fid) != len(plan):
            missing = sorted({feed_name(t, e, ev) for (t, e, ev) in plan} - set(fid))
            check("G0 every (table, entity, event) member exists", False, missing)
            return 1

        # ── SOD for the month end: 18 tasks, all WAITING ──────────────────
        for t, tid in tids.items():
            s, ans = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={BD.isoformat()}&template_id={tid}",
                            timeout=900)
            s, ans = await_sod(r, s, ans)
            check(f"SOD {BD} for template {t}: {len(ENTITIES) * len(EVENTS)} month-end tasks created",
                  s in (200, 202) and int((ans or {}).get("created") or 0) == len(ENTITIES) * len(EVENTS),
                  (s, {k: (ans or {}).get(k) for k in ("created", "skipped_by_condition", "errors", "business_date")}))
        runs = wait_for(lambda: (lambda m: m if all(fid[n] in m for n in fid) else None)(runs_by_feed(r)), 60)
        check("SOD every task WAITS on its upstream (nothing has arrived)",
              runs and all(runs[fid[n]].get("action_decision") == "WAIT" for n in fid),
              runs and collections.Counter(runs[fid[n]].get("action_decision") for n in fid if fid[n] in runs))
        d = board(r, f"E{TAG}_")
        check("B0 the BOARD before any message: 3 groups named by entity, 6 feeds each, all Waiting",
              [g["name"] for g in d.get("groups") or []] == sorted(ENTITIES)
              and all(g["counts"].get("all") == 6 and g["counts"].get("not_started") == 6 for g in d.get("groups") or []),
              [(g["name"], g["counts"]) for g in d.get("groups") or []])

        # ── the month end as it goes: messages on both roads, a skip ─────
        kafka, oracle = [], []
        for (t, ent, ev), p in plan.items():
            ds = TABLES[t]["data_source"]
            for side, road, reported in p["msgs"]:
                rows = ROWS if side == "CLOUD" else ROWS + 1
                m = message(ds, ent, ev, BD, side == "CLOUD", "COMPLETE",
                            rows if reported is None else reported, next(seq))
                (kafka if road == "kafka" else oracle).append(m)
        produce_kafka(kafka)
        ora_rows(ora_id, oracle)
        print(f"   sent {len(kafka)} CLOUD messages on Kafka topic {TOPIC}, {len(oracle)} ONPREM rows into {ORA_TABLE}")
        for (t, ent, ev), p in plan.items():
            if p["skip"]:
                key = f"{TABLES[t]['data_source']}_{ent}_{ev}_{p['skip']}"
                s, sk = r.call("POST", f"/api/feed-dependencies/{key}/skip", {
                    "business_date": BD.isoformat(), "reason_category": "upstream_holiday",
                    "reason": "on-prem load not published for this month end -- holiday upstream"})
                check(f"K1 operator SKIPS {key} for {BD} (upstream holiday)", s in (200, 201), (s, str(sk)[:300]))

        terminal = {fid[feed_name(t, e, ev)]: p["fate"] for (t, e, ev), p in plan.items() if p["fate"] != "not_started"}

        def settled():
            m = runs_by_feed(r)
            return m if all((m.get(f) or {}).get("status") in ("completed", "failed", "skipped", "cancelled")
                            for f in terminal) else None
        runs = wait_for(settled, args.timeout, 10) or runs_by_feed(r)
        got_fate = {}
        for (t, e, ev), p in plan.items():
            rr = runs.get(fid[feed_name(t, e, ev)]) or {}
            got_fate[(t, e, ev)] = ("not_started" if rr.get("status") == "pending" and rr.get("action_decision") == "WAIT"
                                    else rr.get("status"))
        wrong = {f"{t}/{e}/{ev}": (got_fate[(t, e, ev)], p["fate"]) for (t, e, ev), p in plan.items()
                 if got_fate[(t, e, ev)] != p["fate"]}
        check(f"R1 every task reached the scenario's fate ({collections.Counter(p['fate'] for p in plan.values())})",
              not wrong, wrong or "all as planned")

        # ── every delivered file BY VALUE ─────────────────────────────────
        bad = {}
        n_files = 0
        for (t, e, ev), p in plan.items():
            if p["fate"] != "completed":
                continue
            fn = file_name(t, e, ev)
            text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fn}"],
                                  capture_output=True, text=True, env=DENV).stdout
            got = collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                      for rec in csv.DictReader(io.StringIO(text.lstrip("﻿"))))
            exp = want[(t, "cloud", e, ev)] + want[(t, "prem", e, ev)]
            n_files += 1
            if got != exp or not sum(exp.values()):
                bad[fn] = (sum(got.values()), sum(exp.values()))
            ledger.add("sftp file", fn, remover=lambda fn=fn: (subprocess.run(
                ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fn}"], env=DENV).returncode == 0, "rm"))
        check(f"F1 all {n_files} delivered files == cloud truth + on-prem truth BY VALUE "
              f"(the holiday-skipped one == cloud truth only)", n_files and not bad, bad or "all exact")
        failed = runs.get(fid[feed_name("tetb", AMER, "EOD")]) or {}
        err = str(failed.get("error") or "")
        check("F2 the lying CLOUD message (99 reported, 3 at the source) FAILED its run before any file, and says why",
              failed.get("status") == "failed" and "99" in err
              and subprocess.run(["docker", "exec", SFTP["container"], "test", "-e",
                                  f"{SFTP['home']}/{file_name('tetb', AMER, 'EOD')}"], env=DENV).returncode != 0,
              err[:300])

        # ── the BOARD: what the owner sees ────────────────────────────────
        d = board(r, f"E{TAG}_")
        exp_counts = {e: collections.Counter(p["fate"] for (t, ee, ev), p in plan.items() if ee == e) for e in ENTITIES}
        got_groups = {g["name"]: g for g in d.get("groups") or []}
        ok = set(got_groups) == set(ENTITIES) and all(
            {k: v for k, v in got_groups[e]["counts"].items() if v and k != "all"} == dict(exp_counts[e])
            and got_groups[e]["counts"].get("all") == 6
            and {x["feed_name"] for x in got_groups[e]["tasks"]} == {feed_name(t, e, ev) for t in ("tetb", "ext") for ev in EVENTS}
            for e in ENTITIES)
        check("B1 the BOARD after the month end: each entity's group holds both tables x 3 events, its counts exactly "
              "the scenario's", ok,
              {e: {"board": {k: v for k, v in (got_groups.get(e) or {}).get("counts", {}).items() if v},
                   "want": dict(exp_counts[e])} for e in ENTITIES})
        k = d.get("kpis") or {}
        want_k = collections.Counter(p["fate"] for p in plan.values())
        check("B2 the status pills over the three groups: Completed / Failed / Waiting / All",
              (k.get("completed"), k.get("failed"), k.get("not_started"), k.get("all"))
              == (want_k["completed"], want_k["failed"], want_k["not_started"], len(plan)),
              {x: k.get(x) for x in ("completed", "failed", "not_started", "all")})
        s, det = r.call("GET", f"/api/feed-dashboard/task?feed_id={fid[feed_name('ext', APAC, 'INTRADAY')]}"
                               f"&business_date={BD.isoformat()}")
        cards = {c["side"]: c for c in (det or {}).get("dependencies") or []}
        check("B3 APAC ext INTRADAY's tiles: CLOUD ARRIVED with the Kafka message's fields, ON-PREM WAITING",
              (cards.get("CLOUD") or {}).get("satisfies")
              and ((cards.get("CLOUD") or {}).get("messages") or [{}])[-1].get("fields", {}).get("CODE") == APAC
              and cards.get("ON-PREM") and not cards["ON-PREM"].get("satisfies"),
              {side: (c.get("verdict"), len(c.get("messages") or [])) for side, c in cards.items()})
    finally:
        if args.keep:
            print(f"\n== KEPT (tag {TAG}): Feed Run Status, business date {BD}, groups {', '.join(ENTITIES)}; "
                  f"--sweep-leftovers --execute removes it")
        else:
            print("\n== cleanup")
            ok_n, failed_l = ledger.cleanup()
            print(f"cleanup: {ok_n} removed, {len(failed_l)} could not be {failed_l[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
