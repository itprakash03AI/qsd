"""The query agent on BROKEN SQL, on real AWS S3 and on Trino (2026-10-06).

Owner: "does the agent fix automatically if query syntax is wrong in BQB?"
The answer the code gives -- and this proves on the live stack:

  * a plain SYNTAX error is EXPLAINED, never guessed at: the run is refused
    with the engine's own message, the suggestion is `check_sql_syntax`
    (no button), and /api/sql/auto-fix answers fixed=false;
  * a missing GROUP BY and an ambiguous column ARE fixed: /api/sql/auto-fix
    returns a rewrite, and the rewrite's ANSWER equals the Trino CLI truth
    on BOTH the S3 engine and the Trino connection (a fix that runs on one
    engine and not the other is not a fix);
  * a misspelled column names the column and is not guessed at;
  * a VALID statement is never rewritten.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/aws_agent_autofix_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

TRINO_CONN = int(os.environ.get("QS_TRINO_CONN", "2"))
S3_NAME = os.environ.get("QS_AWS_CONN_NAME", "aws-real")
CAT = "iceberg_aws.fin."
COB = "2025-09-30"
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:400], flush=True)
    return bool(ok)


def trino_cli(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True)
    return [ln.split("\t") for ln in out.stdout.strip().splitlines() if ln.strip()]


def submit(route, sql, conn):
    """Run a statement the way the BQB does.  Returns (outcome, error_text,
    suggestion, rows): outcome 'ok' | 'refused' (a 4xx at submit, e.g.
    pre-validation) | 'failed' (the run failed)."""
    if route == "s3":
        s, b, _ = c.call("POST", "/api/execute", {"connection_id": conn, "cache_strategy": "bypass", "raw_sql": sql})
    else:
        s, b, _ = c.call("POST", "/api/sql/execute", {"primary_connection_id": conn, "primary_sql": sql})
    if s != 200 or not (b or {}).get("execution_id"):
        det = (b or {}).get("detail") if isinstance(b, dict) else b
        sug = det.get("agent_suggestion") if isinstance(det, dict) else None
        err = (det.get("error") or det.get("message") or json.dumps(det)) if isinstance(det, dict) else str(det)
        return "refused", f"{s}: {err}", sug, []
    eid = b["execution_id"]
    t0 = time.time()
    st = {}
    while time.time() - t0 < 900:
        _, st, _ = c.call("GET", f"/api/executions/{eid}/status")
        if (st or {}).get("status") in ("completed", "failed", "error", "cancelled"):
            break
        time.sleep(1)
    if (st or {}).get("status") != "completed":
        return "failed", str((st or {}).get("error_message") or (st or {}).get("error") or st), (st or {}).get("agent_suggestion"), []
    _, r, _ = c.call("GET", f"/api/executions/{eid}/results?page=1&page_size=1000")
    names = [x["name"] if isinstance(x, dict) else x for x in (r or {}).get("columns") or []]
    rows = [x if isinstance(x, dict) else dict(zip(names, x)) for x in (r or {}).get("rows") or []]
    return "ok", "", None, [{str(k).lower(): v for k, v in x.items()} for x in rows]


def autofix(sql, conn):
    s, b, _ = c.call("POST", "/api/sql/auto-fix", {"raw_sql": sql, "connection_id": conn})
    return s, (b or {})


def by_event(rows, key="business_event", val="gbp"):
    return {str(r[key]): str(Decimal(str(r[val])).quantize(Decimal("0.01"))) for r in rows if r.get(val) is not None}


def main():
    s, b, _ = c.call("GET", "/api/connections")
    items = b if isinstance(b, list) else (b.get("items") or b.get("connections") or [])
    s3 = next((x["id"] for x in items if x.get("name") == S3_NAME), None)
    if not s3:
        raise SystemExit(f"no connection named {S3_NAME}")
    truth = {r[0]: str(Decimal(r[1]).quantize(Decimal("0.01"))) for r in trino_cli(
        f"select business_event, sum(gbp_currency_amount) from {CAT}fact_tetb "
        f"where business_close_date = DATE '{COB}' group by 1")}
    truth_ent = {r[0]: str(Decimal(r[1]).quantize(Decimal("0.01"))) for r in trino_cli(
        f"select f.sap_company_id, sum(f.gbp_currency_amount) from {CAT}fact_tetb f join {CAT}dim_legal_entity l "
        f"on f.sap_company_id = l.sap_company_id where f.business_close_date = DATE '{COB}' group by 1")}
    check("truth is non-empty (events, entities)", len(truth) >= 4 and len(truth_ent) >= 10, (len(truth), len(truth_ent)))

    for route, conn, p in (("s3", s3, ""), ("trino", TRINO_CONN, CAT)):
        # ── A: plain syntax error -- explained, never guessed ───────────
        bad = f"selec business_event from {p}fact_tetb where business_close_date = DATE '{COB}'"
        out, err, sug, _ = submit(route, bad, conn)
        check(f"A [{route}] a syntax error is REFUSED with the engine's own words, not a 200",
              out in ("refused", "failed") and err, {"outcome": out, "err": err[:240]})
        if sug is not None:
            check(f"A [{route}] its suggestion is check_sql_syntax (explain, no auto-fix button)",
                  sug.get("strategy") == "check_sql_syntax", sug)
        fs, fx = autofix(bad, conn)
        check(f"A [{route}] /api/sql/auto-fix does NOT guess at a syntax error", fs == 200 and fx.get("fixed") is False,
              {"status": fs, "body": str(fx)[:240]})

        # ── B: missing GROUP BY -- fixed, and the fix is RIGHT ──────────
        nogb = (f"select business_event, sum(gbp_currency_amount) as gbp from {p}fact_tetb "
                f"where business_close_date = DATE '{COB}'")
        out, err, sug, _ = submit(route, nogb, conn)
        check(f"B [{route}] a missing GROUP BY fails (never a silent wrong answer)", out in ("refused", "failed"),
              {"outcome": out, "err": err[:240]})
        if sug is not None:
            check(f"B [{route}] its suggestion is add_group_by", sug.get("strategy") == "add_group_by", sug)
        fs, fx = autofix(nogb, conn)
        ok_fix = fs == 200 and fx.get("fixed") is True and "group by" in str(fx.get("fixed_sql", "")).lower()
        check(f"B [{route}] auto-fix adds the GROUP BY", ok_fix, {"status": fs, "fixes": fx.get("applied_fixes"),
                                                                   "sql": str(fx.get("fixed_sql"))[:240]})
        if ok_fix:
            out, err, _, rows = submit(route, fx["fixed_sql"], conn)
            got = by_event(rows)
            check(f"B [{route}] the FIXED statement runs here and its answer == Trino truth ({len(truth)} events)",
                  out == "ok" and got == truth, {"outcome": out, "err": err[:240], "got": got, "truth": truth})

        # ── C: ambiguous column in a join -- qualified, and RIGHT ───────
        amb = (f"select sap_company_id, sum(gbp_currency_amount) as gbp from {p}fact_tetb f "
               f"join {p}dim_legal_entity l on f.sap_company_id = l.sap_company_id "
               f"where business_close_date = DATE '{COB}' group by sap_company_id")
        out, err, sug, _ = submit(route, amb, conn)
        check(f"C [{route}] an ambiguous column fails (never picks a side silently)", out in ("refused", "failed"),
              {"outcome": out, "err": err[:240]})
        if sug is not None:
            check(f"C [{route}] its suggestion is qualify_ambiguous_columns",
                  sug.get("strategy") == "qualify_ambiguous_columns", sug)
        fs, fx = autofix(amb, conn)
        ok_fix = fs == 200 and fx.get("fixed") is True
        check(f"C [{route}] auto-fix qualifies the column", ok_fix,
              {"status": fs, "fixes": fx.get("applied_fixes"), "sql": str(fx.get("fixed_sql"))[:300], "why": fx.get("explanation")})
        if ok_fix:
            out, err, _, rows = submit(route, fx["fixed_sql"], conn)
            got = by_event(rows, key="sap_company_id")
            check(f"C [{route}] the FIXED join runs here and its answer == Trino truth ({len(truth_ent)} entities)",
                  out == "ok" and got == truth_ent, {"outcome": out, "err": err[:240], "n": len(got)})

        # ── D: misspelled column -- named, not guessed ──────────────────
        typo = f"select gbp_curency_amount from {p}fact_tetb where business_close_date = DATE '{COB}'"
        out, err, sug, _ = submit(route, typo, conn)
        check(f"D [{route}] a misspelled column fails NAMING the column", out in ("refused", "failed")
              and "gbp_curency_amount" in err.lower(), {"outcome": out, "err": err[:300], "sug": sug})
        fs, fx = autofix(typo, conn)
        check(f"D [{route}] auto-fix does not invent a column", fs == 200 and fx.get("fixed") is False, str(fx)[:200])

        # ── E: a valid statement is never rewritten ─────────────────────
        good = (f"select business_event, sum(gbp_currency_amount) as gbp from {p}fact_tetb "
                f"where business_close_date = DATE '{COB}' group by business_event")
        fs, fx = autofix(good, conn)
        check(f"E [{route}] a VALID statement is left alone", fs == 200 and fx.get("fixed") is False, str(fx)[:200])

    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
