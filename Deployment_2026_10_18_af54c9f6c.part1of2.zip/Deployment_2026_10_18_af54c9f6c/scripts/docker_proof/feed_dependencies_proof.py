"""A feed that depends on SEVERAL Iceberg tables, SEVERAL Kafka messages, or
a mix -- proven on the live Docker rig with the scheduler doing the work
(2026-10-08).

Owner: "how does a feed depend on multiple iceberg metadata or multiple
kafka messages".  The model (core/feed/etl_dependency.py, arrival_sources.py):
a feed has N dependencies and ALL must be met; each dependency declares
arrival sources combined by require_mode (all | any).  Until this file it had
only ever been proven live with ONE dependency carrying ONE source, and Kafka
never at all (no broker on the rig).  Every case proves the HOLD (the run does
NOT run early, and the hold says what is missing), then the RELEASE by the
poller, and judges the delivered file by value against the source.

  M1 two Iceberg tables in ONE dependency, ALL  -- a commit to A alone holds
     (the hold names B); a commit to B releases.  Real AWS tables through
     connection aws-real: iceberg_aws.fin.dim_fx_rate + fact_journal, one
     sentinel row each, removed in finally.
  M2 the same, ANY                               -- A alone releases.
  M3 TWO dependencies (Iceberg commit + a file in the real bucket): one met,
     still held; both met, released.
  K1 ONE dependency, TWO Kafka topics, ALL        -- message on t1 holds
     (names t2); t2 releases.
  K2 the same, ANY                               -- t2 alone releases.
  K3 a REPLAYED message (same payload, new offset) after the run completed:
     exactly one run, one execution; the replay is a regeneration DECISION.
  K4 broker DOWN: the hold reads "cannot be satisfied" (never "not met"),
     and after the broker is back a message releases it.
  K5 Kafka + Iceberg commit in one dependency, ALL.

Messages are produced through the broker (rpk in the qs-kafka container);
nothing here writes a ledger row or flips a run.  The broker and the
consumer configuration come from scripts/docker_proof/compose/kafka.override.yml:

    . ~/.qs_keys/rigpw.sh
    docker compose -f docker-compose.local.yml \\
                   -f scripts/docker_proof/compose/kafka.override.yml \\
                   --profile workers up -d kafka api scheduler
    python scripts/docker_proof/feed_dependencies_proof.py [--only M1,K1]

K4 stops and restarts the qs-kafka container (and restarts it in finally).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feed_triggers_proof import (  # noqa: E402
    Rig, check, dep_types, held_then_released, psql, res, trino, wait_until,
)
from s3_background_proof import s3  # noqa: E402

TAG = str(int(time.time()))[-6:]
CAT = "iceberg_aws.fin."
KAFKA = "qs-kafka"
T1, T2 = "qs.dep.t1", "qs.dep.t2"
KDEP = "QS_KAFKA_MULTI"             # the dependency the override's rules route both topics to
SENTINEL = "QSD"                     # dim_fx_rate.currency / fact_journal.journal_id prefix
os.environ.setdefault("MSYS_NO_PATHCONV", "1")


def day(n: int) -> str:
    return (dt.date.today() - dt.timedelta(days=n)).isoformat()


# one business date per case: the ledger is keyed by (dependency, date) and
# KDEP is a FIXED name, so two Kafka cases on one date would see each
# other's messages.  All inside the Iceberg (14 d) and file (7 d) windows
# where those sources are involved.
DATES = {"M1": day(2), "M2": day(3), "M3": day(4), "K1": day(5),
         "K2": day(6), "K3": day(7), "K4": day(8), "K5": day(9)}


# ── the broker ───────────────────────────────────────────────────────────

def docker(*args, stdin=None, timeout=120):
    r = subprocess.run(["docker", *args], capture_output=True, text=True,
                       input=stdin, timeout=timeout)
    return r.returncode, (r.stdout or "").strip(), (r.stderr or "").strip()


def rpk(*args, stdin=None):
    rc, out, err = docker("exec", *(["-i"] if stdin is not None else []), KAFKA,
                          "rpk", *args, stdin=stdin)
    return rc, out or err


def broker_running() -> bool:
    rc, out, _ = docker("inspect", "-f", "{{.State.Running}}", KAFKA)
    return rc == 0 and out == "true"


def broker_healthy() -> bool:
    rc, out = rpk("cluster", "health")
    # rpk pads the value ("Healthy:                          true"): read the
    # first WORD after the label, not a fixed-width window
    if rc != 0 or "Healthy:" not in out:
        return False
    rest = out.split("Healthy:", 1)[1].split()
    return bool(rest) and rest[0] == "true"


def ensure_topics():
    for t in (T1, T2):
        rc, out = rpk("topic", "create", t, "-p", "1", "-r", "1")
        if rc != 0 and "already exists" not in out and "TOPIC_ALREADY_EXISTS" not in out:
            raise SystemExit(f"rpk topic create {t}: {out[-300:]}")


def produce(topic: str, business_date: str, status: str = "COMPLETE") -> str:
    """One message through the broker.  Returns rpk's receipt (partition /
    offset) -- a produce that did not land RAISES: a check that passes
    because no message was sent proves nothing."""
    line = json.dumps({"business_date": business_date, "status": status,
                       "sent_by": f"feed_dependencies_proof {TAG}"})
    rc, out = rpk("topic", "produce", topic, "-f", "%v\\n", stdin=line + "\n")
    if rc != 0 or "Produced" not in out:
        raise RuntimeError(f"produce to {topic} failed: {out[-300:]}")
    return out.splitlines()[-1]


def arrivals(dep: str, date: str, source_key: str | None = None) -> int:
    where = f"dependency_name = '{dep}' and business_date = '{date}'"
    if source_key:
        # a key with % is a pattern (the table part of an Iceberg key carries
        # the bucket and a uuid suffix): LIKE, never '=' against a pattern
        op = "like" if "%" in source_key else "="
        where += f" and source_key {op} '{source_key}'"
    out = psql(f"select count(*) from dependency_events where {where}")
    return int(out or 0)


def cleanup_db(deps: list[str]):
    names = ", ".join(f"'{d}'" for d in deps)
    for sql in (
        f"delete from feed_regeneration_decisions where dependency_name in ({names})",
        f"delete from dependency_events where dependency_name in ({names})",
        f"delete from iceberg_commit_inspections where dependency_name in ({names})",
        f"delete from kafka_messages where topic in ('{T1}', '{T2}')",
    ):
        psql(sql)


def cleanup_trino():
    # the DELETEs are merge-on-read: the data files stay live and the
    # iceberg_commit source proves a date from live file bounds -- after a few
    # weeks of runs every date in the window was "covered" and quiet_date found
    # none (2026-10-16).  Compacting applies the deletes and drops the residue.
    for sql in (f"delete from {CAT}dim_fx_rate where currency = '{SENTINEL}'",
                f"delete from {CAT}fact_journal where journal_id like '{SENTINEL}-%'",
                f"ALTER TABLE {CAT}dim_fx_rate EXECUTE optimize",
                f"ALTER TABLE {CAT}fact_journal EXECUTE optimize"):
        try:
            trino(sql)
        except Exception as exc:  # noqa: BLE001
            print("   trino cleanup FAILED:", exc)


# ── the rig ──────────────────────────────────────────────────────────────

def aws_connection(r: Rig) -> int:
    _, cl = r.call("GET", "/api/connections")
    items = cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []
    cid = next((x["id"] for x in items if x.get("name") == "aws-real"), None)
    if cid is None:
        raise SystemExit("connection 'aws-real' is not on the rig")
    return cid


def ice(cid: int, table: str) -> dict:
    return {"kind": "iceberg_commit", "connection_id": cid, "table": table,
            "date_column": "business_close_date"}


def commit(table: str, date: str) -> str:
    """One sentinel row = one new data file whose business_close_date bounds
    are [date, date], which is what the Iceberg-commit source PROVES from."""
    if table == "dim_fx_rate":
        trino(f"insert into {CAT}dim_fx_rate values (DATE '{date}', '{SENTINEL}', 1.0)")
    elif table == "fact_journal":
        trino(f"insert into {CAT}fact_journal (business_close_date, business_event, code, "
              f"source_data_set, source_data_row, journal_line, dr_cr, gbp_amount, gl_account, "
              f"sap_company_id, cost_centre, currency, posting_date, journal_id) values "
              f"(DATE '{date}', 'PROOF', 'QS', 'feed_dependencies_proof', 0, 1, 'DR', 0.00, "
              f"'000000', 'QS', 'QS', 'GBP', DATE '{date}', '{SENTINEL}-{TAG}-{date}')")
    else:
        raise ValueError(table)
    snap = trino(f'select snapshot_id from {CAT}"{table}$snapshots" order by committed_at desc limit 1')
    print(f"   committed {table} for {date}: snapshot {snap}")
    return snap


def declare(r: Rig, fid: int, tid: int, deps: list[dict]) -> tuple:
    return r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": deps})


def still_held_naming(r: Rig, case: str, fid: int, date: str, *fragments: str, after: int = 0):
    if after:
        time.sleep(after)
    row = r.run_row(fid, date)
    ok = bool(row) and row["decision"] == "WAIT" and all(f in row["reason"] for f in fragments)
    check(f"{case} still HELD, and the hold names what is missing ({', '.join(fragments)})",
          ok, row)
    return ok


def wait_arrival(case: str, dep: str, date: str, key: str, timeout: int, what: str):
    n, secs = wait_until(lambda: arrivals(dep, date, key) or None, timeout, 5)
    check(f"{case} the {what} was RECORDED by the producer itself (source_key {key}, {secs}s)",
          bool(n), {"arrivals": n, "dependency": dep, "date": date})
    return bool(n)


# ── preflight ────────────────────────────────────────────────────────────

def preflight(r: Rig):
    print("\n== preflight: the broker, the consumer, the vocabulary")
    check("P0 qs-kafka is running (scripts/docker_proof/compose/kafka.override.yml)",
          broker_running(), "docker compose -f docker-compose.local.yml -f "
          "scripts/docker_proof/compose/kafka.override.yml --profile workers up -d kafka api scheduler")
    if not broker_running():
        raise SystemExit(2)
    healthy, secs = wait_until(broker_healthy, 120, 5)
    check(f"P0 the broker reports healthy ({secs}s)", healthy)
    ensure_topics()
    s, st = r.call("GET", "/api/admin/background-jobs/feed_kafka_arrivals/status")
    text = json.dumps(st) if isinstance(st, dict) else str(st)
    check("P1 the dependency consumer is RUNNING on its owner with the rig's topics and 2 rules",
          s == 200 and '"running": true' in text and T1 in text and T2 in text
          and '"refusal": null' in text,
          {"http": s, "answered_by": (st or {}).get("answered_by") if isinstance(st, dict) else None,
           "excerpt": text[:400]})
    s, v = r.call("GET", "/api/feed-arrival-sources")
    kinds = {k["kind"]: k for k in ((v or {}).get("kinds") or [])} if isinstance(v, dict) else {}
    health = (kinds.get("kafka") or {}).get("producer_health") or {}
    check("P2 the vocabulary says the Kafka producer is UP on the api pod (its config carries the block)",
          health.get("state") == "up", health)
    check("P2 the Kafka kind offers an optional topic",
          any(p.get("name") == "topic" for p in (kinds.get("kafka") or {}).get("params") or []),
          (kinds.get("kafka") or {}).get("params"))


_TAKEN: set = set()


def covered(table: str, d: str) -> int:
    """How many LIVE data files of the real table cover business date ``d``
    -- exactly what the iceberg_commit source proves a date from (each data
    file's min / max of the date column).  Merge-on-read deletes leave the
    rows' data files in place, so a date whose test rows were deleted long
    ago still counts."""
    sql = (f"select count(*) from {CAT}\"{table}$files\" where content = 0 "
           f"and cast(json_extract_scalar(readable_metrics, '$.business_close_date.lower_bound') as date) <= date '{d}' "
           f"and cast(json_extract_scalar(readable_metrics, '$.business_close_date.upper_bound') as date) >= date '{d}'")
    return int(trino(sql).strip() or 0)


def quiet_date(key: str, preferred: str, tables=("dim_fx_rate", "fact_journal")) -> str:
    """A business date NO live data file of the gated tables covers yet
    (2026-10-16).  The tables are the REAL AWS ones, shared by every rig and
    every run: on its first look the watcher proves a date from every live
    file -- including files earlier runs wrote (and deleted from, which leaves
    the file) for these very dates -- so a fixed "today minus n" could
    already be MET and the "still held" premise was false (found on the test
    rig built from scratch).  Asks the table itself, in the window."""
    for d in [preferred] + [day(n) for n in range(1, 14)]:
        if d in _TAKEN:
            continue
        hits = {t: covered(t, d) for t in tables}
        if not any(hits.values()):
            _TAKEN.add(d)
            if d != preferred:
                print(f"   {key}: {preferred} is already covered by live data files (shared AWS tables) -- using {d}")
            return d
    raise SystemExit(f"{key}: every date in the window is covered by live data files -- nothing to prove on")


# ── cases ────────────────────────────────────────────────────────────────

def case_m1(r, types, aws):
    print(f"\n== M1 two Iceberg tables in ONE dependency, ALL")
    fid = r.feed(f"DEP_M1_{TAG}")
    key = f"two_tables_{TAG}"
    tid = types.get("ICEBERG_TABLE") or next(iter(types.values()))
    s, b = declare(r, fid, tid, [{"dependency_type_id": tid, "dependency_key": key,
                                  "description": "FX rates AND journals for the day",
                                  "arrival_sources": [ice(aws, "dim_fx_rate"), ice(aws, "fact_journal")],
                                  "require_mode": "all"}])
    check("M1 dependency declared: iceberg_commit on dim_fx_rate + fact_journal, ALL", s == 200, str(b)[:200])
    date = quiet_date(key, DATES["M1"])
    print(f"   M1 business date {date}")

    def satisfy():
        commit("dim_fx_rate", date)
        if wait_arrival("M1", key, date, "iceberg:%dim_fx_rate%", 600, "dim_fx_rate commit"):
            pass
        still_held_naming(r, "M1 after table A", fid, date, "fact_journal", after=20)
        commit("fact_journal", date)

    held_then_released(r, "M1", fid, date, satisfy, hold_for=30, release_timeout=900)
    keys = psql(f"select string_agg(source_key, ',' order by source_key) from dependency_events "
                f"where dependency_name = '{key}' and business_date = '{date}'")
    check("M1 the ledger holds ONE arrival per TABLE (source_key names each)",
          "dim_fx_rate" in keys and "fact_journal" in keys, keys)


def case_m2(r, types, aws):
    print(f"\n== M2 two Iceberg tables in ONE dependency, ANY")
    fid = r.feed(f"DEP_M2_{TAG}")
    key = f"either_table_{TAG}"
    tid = types.get("ICEBERG_TABLE") or next(iter(types.values()))
    s, b = declare(r, fid, tid, [{"dependency_type_id": tid, "dependency_key": key,
                                  "arrival_sources": [ice(aws, "dim_fx_rate"), ice(aws, "fact_journal")],
                                  "require_mode": "any"}])
    check("M2 dependency declared: the same two tables, ANY", s == 200, str(b)[:200])
    date = quiet_date(key, DATES["M2"])
    print(f"   M2 business date {date}")
    held_then_released(r, "M2", fid, date, lambda: commit("dim_fx_rate", date),
                       hold_for=30, release_timeout=900)
    check("M2 released by table A alone: no fact_journal arrival exists",
          arrivals(key, date, "iceberg:%fact_journal%") == 0 and arrivals(key, date) >= 1,
          {"arrivals": arrivals(key, date)})


def case_m3(r, types, aws):
    date = DATES["M3"]
    ymd = date.replace("-", "")
    folder = f"qs-proof/deps/{TAG}/{ymd}/"
    print(f"\n== M3 TWO dependencies: an Iceberg commit AND a file in the real bucket -- {date}")
    fid = r.feed(f"DEP_M3_{TAG}")
    ikey, fkey = f"fx_{TAG}", f"gl_file_{TAG}"
    itid = types.get("ICEBERG_TABLE") or next(iter(types.values()))
    ftid = types.get("FILE") or types.get("FILE_ARRIVAL") or itid
    s, b = declare(r, fid, itid, [
        {"dependency_type_id": itid, "dependency_key": ikey,
         "arrival_sources": [ice(aws, "dim_fx_rate")]},
        {"dependency_type_id": ftid, "dependency_key": fkey,
         "arrival_sources": [{"kind": "file", "connection_id": aws,
                              "path": f"qs-proof/deps/{TAG}/{{business_date:YYYYMMDD}}/",
                              "pattern": "*.csv"}]}])
    check("M3 TWO dependencies declared (iceberg_commit; file in the real bucket)", s == 200, str(b)[:200])

    def satisfy():
        commit("dim_fx_rate", date)
        wait_arrival("M3", ikey, date, "iceberg:%dim_fx_rate%", 600, "dim_fx_rate commit")
        still_held_naming(r, "M3 with one of two met", fid, date, fkey, after=20)
        print("   data file:", s3("put", folder + "gl.csv", "a,b\n1,2\n"))

    try:
        held_then_released(r, "M3", fid, date, satisfy, hold_for=30, release_timeout=900)
    finally:
        s3("delete", folder + "gl.csv")


def kafka_feed(r, types, case, sources, mode):
    fid = r.feed(f"DEP_{case}_{TAG}")
    tid = types.get("KAFKA") or next(iter(types.values()))
    s, b = declare(r, fid, tid, [{"dependency_type_id": tid, "dependency_key": KDEP,
                                  "arrival_sources": sources, "require_mode": mode}])
    check(f"{case} dependency {KDEP} declared: {json.dumps(sources)} ({mode.upper()})",
          s == 200, str(b)[:200])
    return fid


def case_k1(r, types):
    date = DATES["K1"]
    print(f"\n== K1 ONE dependency, TWO Kafka topics, ALL -- {date}")
    fid = kafka_feed(r, types, "K1", [{"kind": "kafka", "topic": T1}, {"kind": "kafka", "topic": T2}], "all")

    def satisfy():
        print("   produce t1:", produce(T1, date))
        wait_arrival("K1", KDEP, date, f"kafka:{T1}", 120, "t1 message")
        still_held_naming(r, "K1 after t1", fid, date, T2, after=20)
        print("   produce t2:", produce(T2, date))

    held_then_released(r, "K1", fid, date, satisfy, hold_for=30, release_timeout=180)
    check("K1 the second topic's message was recorded as its OWN arrival (not a replay of t1's)",
          arrivals(KDEP, date, f"kafka:{T2}") == 1 and psql(
              f"select count(*) from feed_regeneration_decisions where dependency_name = '{KDEP}' "
              f"and business_date = '{date}'") == "0",
          {"t2": arrivals(KDEP, date, f"kafka:{T2}")})


def case_k2(r, types):
    date = DATES["K2"]
    print(f"\n== K2 ONE dependency, TWO Kafka topics, ANY -- {date}")
    fid = kafka_feed(r, types, "K2", [{"kind": "kafka", "topic": T1}, {"kind": "kafka", "topic": T2}], "any")
    held_then_released(r, "K2", fid, date, lambda: print("   produce t2:", produce(T2, date)),
                       hold_for=30, release_timeout=180)
    check("K2 released by t2 alone (no t1 arrival)", arrivals(KDEP, date, f"kafka:{T1}") == 0)


def case_k3(r, types):
    date = DATES["K3"]
    print(f"\n== K3 a REPLAYED message does not double-run -- {date}")
    fid = kafka_feed(r, types, "K3", [{"kind": "kafka", "topic": T1}], "all")
    held_then_released(r, "K3", fid, date, lambda: print("   produce t1:", produce(T1, date)),
                       hold_for=30, release_timeout=180)
    print("   produce t1 AGAIN (same payload, new offset):", produce(T1, date))
    n, secs = wait_until(lambda: (lambda c: c if c >= 2 else None)(arrivals(KDEP, date, f"kafka:{T1}")), 120, 5)
    check(f"K3 the replay landed in the ledger as a second arrival ({secs}s)", n == 2, n)
    time.sleep(60)
    runs = psql(f"select count(*) from feed_runs where feed_config_id = {fid} and business_date = '{date}'")
    done = psql(f"select count(*) from feed_executions where feed_config_id = {fid} and status = 'completed'")
    decisions = psql(f"select count(*) from feed_regeneration_decisions where dependency_name = '{KDEP}' "
                     f"and business_date = '{date}' and feed_config_id = {fid}")
    check("K3 EXACTLY ONE run and one completed execution after the replay; the replay is a regeneration "
          "DECISION, not a run", runs == "1" and done == "1" and decisions == "1",
          {"runs": runs, "completed_executions": done, "decisions": decisions})


def case_k4(r, types):
    date = DATES["K4"]
    print(f"\n== K4 broker DOWN: the hold says it cannot be satisfied -- {date}")
    fid = kafka_feed(r, types, "K4", [{"kind": "kafka", "topic": T1}], "all")

    def satisfy():
        print("   stopping the broker")
        docker("stop", KAFKA)
        row, secs = wait_until(lambda: (lambda x: x if x and "cannot be satisfied" in x["reason"] else None)(
            r.run_row(fid, date)), 240, 5)
        check(f"K4 with the broker down the hold reads 'cannot be satisfied' ({secs}s), naming the producer "
              f"and the broker fault", bool(row) and "feed_kafka_arrivals" in row["reason"]
              and "broker" in row["reason"].lower(), row)
        check("K4 ... and never 'not met'", bool(row) and "not met" not in row["reason"].lower(), row)
        print("   starting the broker")
        docker("start", KAFKA)
        healthy, secs = wait_until(broker_healthy, 180, 5)
        check(f"K4 the broker is back ({secs}s)", healthy)
        row, secs = wait_until(lambda: (lambda x: x if x and "cannot be satisfied" not in x["reason"] else None)(
            r.run_row(fid, date)), 240, 5)
        check(f"K4 the fault CLEARED by itself: the hold is an ordinary 'not met' again ({secs}s)",
              bool(row) and row["decision"] == "WAIT", row)
        print("   produce t1:", produce(T1, date))

    held_then_released(r, "K4", fid, date, satisfy, hold_for=30, release_timeout=240)


def case_k5(r, types, aws):
    # the Iceberg half must NOT be met yet: a date no live file of the SHARED
    # real table covers (a fixed day(n) was already covered on a fresh rig)
    date = quiet_date("K5", DATES["K5"], tables=("dim_fx_rate",))
    print(f"\n== K5 Kafka + Iceberg commit in ONE dependency, ALL -- {date}")
    fid = kafka_feed(r, types, "K5", [{"kind": "kafka", "topic": T1}, ice(aws, "dim_fx_rate")], "all")

    def satisfy():
        print("   produce t1:", produce(T1, date))
        wait_arrival("K5", KDEP, date, f"kafka:{T1}", 120, "t1 message")
        still_held_naming(r, "K5 after the message", fid, date, "dim_fx_rate", after=20)
        commit("dim_fx_rate", date)

    held_then_released(r, "K5", fid, date, satisfy, hold_for=30, release_timeout=900)


# ── main ─────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    only = set(filter(None, ap.parse_args().only.split(",")))
    want = lambda c: not only or c in only                 # noqa: E731
    r = Rig()
    check("truth: 5 regions", len(r.truth) == 5, r.truth)
    types = dep_types(r)
    check("dependency types are served", bool(types), types)
    aws = aws_connection(r)
    preflight(r)
    tag_deps = []
    cleanup_db([KDEP])            # a same-day re-run must not inherit yesterday's arrivals
    cleanup_trino()
    try:
        if want("M1"):
            tag_deps.append(f"two_tables_{TAG}")
            case_m1(r, types, aws)
        if want("M2"):
            tag_deps.append(f"either_table_{TAG}")
            case_m2(r, types, aws)
        if want("M3"):
            tag_deps += [f"fx_{TAG}", f"gl_file_{TAG}"]
            case_m3(r, types, aws)
        if want("K1"):
            case_k1(r, types)
        if want("K2"):
            case_k2(r, types)
        if want("K3"):
            case_k3(r, types)
        if want("K4"):
            case_k4(r, types)
        if want("K5"):
            case_k5(r, types, aws)
    finally:
        if not broker_running():
            docker("start", KAFKA)
        for p in r.undo:
            r.call("DELETE", p)
        cleanup_db([KDEP] + tag_deps)
        cleanup_trino()
        print(f"\ncleanup: {len(r.undo)} objects removed; sentinel rows, ledger rows and "
              f"landed messages for {KDEP} + {len(tag_deps)} tagged dependencies removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
