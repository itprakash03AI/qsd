"""Snowflake, end to end on Docker, over the WIRE (2026-10-03).

There is no Snowflake on the rig, so a fakesnow SERVER runs as a container on
the rig's network (qs-fakesnow:8888, http) and the REAL snowflake driver in
the REAL API / published-API containers talks to it -- the connector's
`host` / `port` / `protocol` keys (PrivateLink-style endpoint).  fakesnow is
DuckDB underneath: what it cannot prove (identifier case folding, real SHOW
layouts, warehouse cancel / credits, session expiry, auth flows) needs a real
account -- see qs-connections.

Seeded through the driver from the host, then judged by VALUE:
  1. connection: create, test, edit-dialog test with the MASKED password,
     save untouched -> still connects;
  2. browse: database, schema, the TABLE and the VIEW (views used to be
     missing), the view's columns;
  3. dataset wizard preview of SQL: rows == truth, column types are Snowflake
     NAMES (they used to be driver codes);
  4. a dataset over SQL: auto-detect types amt as a number; run == truth;
  5. the query builder's column map for the table;
  6. a report on the dataset == truth; published as an API on :8003 == truth.

    docker run -d --name qs-fakesnow --network querystudio-local-net -p 8888:8888 python:3.11-slim \\
      sh -c "pip install 'fakesnow[server]==0.11.19' && python -m fakesnow -s -p 8888 --host 0.0.0.0 -d /data"
    python scripts/docker_proof/snowflake_journey_proof.py
"""
from __future__ import annotations

import os
import sys
import time
import warnings

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

warnings.filterwarnings("ignore")
TAG = str(int(time.time()))[-6:]
PUB = "http://localhost:8003"
ROWS = [(1, "EMEA", 10.5, "2026-01-03"), (2, "APAC", 20.0, "2026-01-03"),
        (3, "EMEA", 5.0, "2026-01-04"), (4, "AMER", 7.25, "2026-01-04")]
TRUTH = {}
for _, r, a, _ in ROWS:
    TRUTH[r] = round(TRUTH.get(r, 0) + a, 2)
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:240], flush=True)
    return bool(ok)


def call(m, p, b=None):
    s, body, _ = c.call(m, p, b)
    return s, body


def seed():
    import snowflake.connector
    con = snowflake.connector.connect(account="acct", user="u", password="p", host="localhost",
                                      port=8888, protocol="http")
    cur = con.cursor()
    for sql in ("create database if not exists SALESDB", "create schema if not exists SALESDB.FIN",
                "create or replace table SALESDB.FIN.TRADES (ID int, REGION varchar, AMT number(18,2), DT date)",
                "insert into SALESDB.FIN.TRADES values " + ",".join(f"({i},'{r}',{a},'{d}')" for i, r, a, d in ROWS),
                "create or replace view SALESDB.FIN.TRADES_EMEA as select * from SALESDB.FIN.TRADES where REGION='EMEA'"):
        cur.execute(sql)
    con.close()


def by_region(rows):
    out = {}
    for r in rows or []:
        r = {k.lower(): v for k, v in r.items()} if isinstance(r, dict) else r
        out[str(r["region"])] = round(float(r["amt"]), 2)
    return out


def main():
    seed()
    undo = []
    try:
        print("\n== 1 . the connection")
        s, conn = call("POST", "/api/connections", {"name": f"sf-{TAG}", "connection_type": "snowflake", "config": {
            "account": "acct", "user": "u", "password": "p", "auth_type": "password", "host": "qs-fakesnow",
            "port": 8888, "protocol": "http", "database": "SALESDB", "schema": "FIN"}})
        if not check("created", s in (200, 201) and conn.get("id"), (s, str(conn)[:160])):
            return 1
        cid = conn["id"]
        undo.append(f"/api/connections/{cid}")
        s, t = call("POST", f"/api/connections/{cid}/test")
        check("its test connects", (t or {}).get("success") is True, (t or {}).get("message"))
        _, g = call("GET", f"/api/connections/{cid}")
        check("the password reads as saved, not blank", g["config"].get("password") == "***", g["config"].get("password"))
        _, dt = call("POST", "/api/connections/test", {"connection_type": "snowflake", "config": g["config"], "connection_id": cid})
        check("Test in the edit dialog (masked password) connects", (dt or {}).get("success") is True, (dt or {}).get("message"))
        s, _ = call("PUT", f"/api/connections/{cid}", {"name": g["name"], "connection_type": "snowflake", "config": g["config"]})
        _, t2 = call("POST", f"/api/connections/{cid}/test")
        check("Save untouched -> still connects", s == 200 and (t2 or {}).get("success") is True, (s, (t2 or {}).get("message")))

        print("\n== 2 . browsing")
        _, cats = call("GET", f"/api/sql/connections/{cid}/catalogs")
        check("the database is listed", "SALESDB" in (cats or []), cats)
        _, sch = call("GET", f"/api/sql/connections/{cid}/schemas?catalog=SALESDB")
        check("the schema is listed", "FIN" in (sch or []), sch)
        _, tabs = call("GET", f"/api/sql/connections/{cid}/tables?catalog=SALESDB&schema=FIN")
        kinds = {t.get("name"): t.get("type") for t in (tabs or []) if isinstance(t, dict)}
        check("the TABLE and the VIEW are both listed, each with its kind",
              kinds.get("TRADES") == "TABLE" and kinds.get("TRADES_EMEA") == "VIEW", kinds)
        s, vcols = call("GET", f"/api/sql/connections/{cid}/columns?catalog=SALESDB&schema=FIN&table=TRADES_EMEA")
        names = [x.get("name") for x in (vcols if isinstance(vcols, list) else (vcols or {}).get("columns") or [])]
        check("the view's columns are read", {"REGION", "AMT"} <= set(names), (s, names))

        print("\n== 3 . the dataset wizard's preview")
        sql = "select REGION, sum(AMT) as AMT from SALESDB.FIN.TRADES group by REGION"
        s, pv = call("POST", "/api/datasets/preview", {"connection_id": cid, "sql": sql, "limit": 50})
        check("rows == truth", s == 200 and by_region(pv.get("rows")) == TRUTH, (s, by_region((pv or {}).get("rows"))))
        types = (pv or {}).get("column_types") or {k.get("name"): k.get("type") for k in (pv or {}).get("columns") or [] if isinstance(k, dict)}
        check("column types are Snowflake NAMES, not driver codes",
              types and all(str(v)[:1].isalpha() for v in types.values()), types)

        print("\n== 4 . a dataset over SQL")
        s, ds = call("POST", "/api/datasets", {"name": f"sf_ds_{TAG}", "subject": "proof", "connection_ids": [cid],
                                               "base_query": "select REGION, AMT, DT from SALESDB.FIN.TRADES"})
        if not check("created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:160])):
            return 1
        did = ds["id"]
        undo.insert(0, f"/api/datasets/{did}")
        s, _ = call("POST", f"/api/datasets/{did}/auto-detect", {})
        _, d = call("GET", f"/api/datasets/{did}")
        cols = {x["physical_name"].lower(): x for x in d["columns"]}
        check("auto-detect types AMT a number, DT a date",
              cols.get("amt", {}).get("data_type") == "number" and cols.get("dt", {}).get("data_type") == "date",
              {k: v.get("data_type") for k, v in cols.items()})
        s, run = call("POST", f"/api/datasets/{did}/execute", {"column_ids": [cols["region"]["id"], cols["amt"]["id"]]})
        rows = []
        if s == 200 and run.get("execution_id"):
            _, page = call("GET", f"/api/datasets/executions/{run['execution_id']}/results?offset=0&limit=50")
            rows = page.get("rows") or []
        check("its run == truth", s == 200 and by_region(rows) == TRUTH, (s, by_region(rows)))

        print("\n== 5 . the query builder's column map")
        s, am = call("POST", "/api/columns/auto-map", {"connection_id": cid, "table_paths": ["SALESDB.FIN.TRADES"]})
        amt = {x["physical_name"].lower(): x.get("data_type") for x in (am or {}).get("columns") or []}
        check("columns with types", s == 200 and amt.get("amt") == "number" and amt.get("region") == "string", (s, amt))

        print("\n== 6 . a report and its published API")
        s, rep = call("POST", "/api/business-reports", {"name": f"sf-rep-{TAG}", "dataset_id": did, "data_source_type": "dataset",
                                                        "column_ids": [cols["region"]["id"], cols["amt"]["id"]]})
        if check("report created", s == 200 and rep.get("id"), (s, str(rep)[:160])):
            rid = rep["id"]
            undo.insert(0, f"/api/business-reports/{rid}")
            _, ex = call("POST", f"/api/business-reports/{rid}/execute", {"parameter_values": {}, "force_refresh": True})
            _, rb = call("GET", f"/api/business-reports/{rid}/results/{ex.get('execution_id')}?page_size=50")
            names = [x["name"] if isinstance(x, dict) else x for x in (rb or {}).get("columns") or []]
            rrows = [r if isinstance(r, dict) else dict(zip(names, r)) for r in (rb or {}).get("rows") or []]
            check("the report == truth", by_region(rrows) == TRUTH, by_region(rrows))
            call("POST", f"/api/business-reports/{rid}/publish", {"action": "publish"})
            slug = f"sf-pv-{TAG}"
            s, pv = call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                          "business_report_id": rid, "credential_mode": "publisher"})
            pid = (pv or {}).get("id")
            if pid:
                undo.insert(0, f"/api/published-views/{pid}")
            saved = c.BASE
            c.BASE = PUB
            try:
                s, b, _ = c.call("GET", f"/api/v1/views/{slug}/data?limit=50", None, headers={"X-API-Key": (pv or {}).get("test_api_key", "")})
            finally:
                c.BASE = saved
            check("the published API == truth", s == 200 and by_region((b or {}).get("data")) == TRUTH, (s, str(b)[:200]))
    finally:
        for p in undo:
            call("DELETE", p)
        print(f"\ncleanup: {len(undo)} objects removed")
    print(f"\n{sum(res)}/{len(res)} PASSED  (truth: {TRUTH})")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
