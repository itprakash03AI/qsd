"""Envelope encryption on the rig: several API containers on ONE database,
nothing blocks, nothing is rewritten (2026-10-17).

The owner: "query_studio_secret_key is mess ... if api deployed on two
container and its updated in values in db ... its completely blocking".
Every component now unwraps the SAME data keys (``encryption_data_keys``)
with the master key (QUERY_STUDIO_SECRET_KEY from Vault; on the rig the key
file) -- core/crypto.py, core/data_key_store.py.  Checked by execution:

  E1 a restart of every component rewrites NO stored secret (the start-up
     sweep that made two containers block each other is gone); the data keys
     are one active + the earlier key(s) retired
  E2 two MORE API containers on the same database: all three report the
     same active data key; a secret saved through any one is read by the
     others; 3 x 10 concurrent saves of one connection finish, none waits
  E3 a container with a WRONG master key: MISMATCH said with both
     fingerprints, a save refused, the data-key rows and the stored secrets
     unchanged
  E4 a Vault master rotation (a new master + the old one as PREVIOUS)
     re-wraps the data-key rows ONLY -- no stored secret changes; the running
     components keep working on the keys they hold; rotated back the same way
  E5 a data-key rotation through the admin route: a value saved under the new
     key by one container is read by another at once; the explicit re-encrypt
     job runs once (a second call while it runs is told so)

Extra containers are removed at the end; the rig is left on its key file.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")
IMAGE = "querystudio-local-api:latest"
API = "qs-local-api"
COMPONENTS = ["qs-local-api", "qs-local-scheduler", "qs-local-executor", "qs-local-reports",
              "qs-local-published-api"]
EXTRA = {"qs-envproof-api2": 8012, "qs-envproof-api3": 8013}
WRONG = "qs-envproof-wrong"
ROTATE = "qs-envproof-rotate"
CHECKS = []

CHECK = r'''
import json
from sqlalchemy import text
from core import crypto
from core.database import DatabaseManager
from core.data_key_store import DataKeyStore
from core.encryption_key_rotation import sweep
db = DatabaseManager()
if crypto._DATA_KEY_STORE is None:
    crypto.bind_data_key_store(DataKeyStore(db))
rep = sweep(db, write=False)
with db.engine.connect() as c:
    row = c.execute(text("select config from connections where name = :n"), {"n": "ENVPROOF_SECRET"}).fetchone()
cfg = (json.loads(row[0]) if isinstance(row[0], str) else row[0]) if row else {}
pw = crypto.decrypt_value(str((cfg or {}).get("password") or "")) if row else None
st = crypto.key_status()
print(json.dumps({"available": st.get("available"), "fingerprint": st.get("fingerprint"),
                  "mode": st.get("mode"), "mismatch": st.get("mismatch"), "source": st.get("source"),
                  "refresh_error": st.get("refresh_error"),
                  "unreadable": len(rep["unreadable"]), "password": pw}))
'''


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:600]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:600]}" if detail else ""), flush=True)


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, env=ENV, **kw)


def psql(sql):
    return sh(["docker", "exec", "qs-local-postgres", "psql", "-U", "querystudio", "-d", "querystudio",
               "-tAc", sql]).stdout.strip()


def secrets_hash():
    """One hash over every stored secret-bearing column -- a rewrite changes it."""
    return psql("select md5(coalesce((select string_agg(id::text || config::text, '|' order by id) from connections), '')"
                " || coalesce((select string_agg(id::text || coalesce(destination_config::text, ''), '|' order by id)"
                " from feed_configs), ''))")


def key_rows():
    return psql("select key_id || ':' || state || ':' || origin || ':' || wrapped_by from encryption_data_keys "
                "order by id").splitlines()


def wrapped_hash():
    return psql("select md5(string_agg(key_id || wrapped, '|' order by id)) from encryption_data_keys")


class Api:
    def __init__(self, port):
        self.base = f"http://127.0.0.1:{port}"
        s, b = self._raw("POST", "/auth/login", {"username": "rig_admin", "password": os.environ["QS_RIG_ADMIN_PW"]})
        if s != 200:
            raise SystemExit(f"login on :{port} failed: {s} {str(b)[:200]}")
        self.token = b["session_token"]

    def _raw(self, method, path, body=None, token=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={"Content-Type": "application/json",
                                              **({"Authorization": f"Bearer {token}"} if token else {})})
        for _ in range(12):
            try:
                with urllib.request.urlopen(req, timeout=300) as r:
                    raw = r.read()
                    return r.status, json.loads(raw) if raw else {}
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    time.sleep(float(e.headers.get("Retry-After") or 5) + 0.5)
                    continue
                raw = e.read()
                try:
                    return e.code, json.loads(raw)
                except ValueError:
                    return e.code, raw.decode(errors="replace")
        return 429, {}

    def call(self, method, path, body=None):
        return self._raw(method, path, body, self.token)


def in_container(name):
    sh(["docker", "cp", os.path.join(HERE, ".envelope_check.py"), f"{name}:/tmp/envelope_check.py"])
    r = sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", name, "python", "/tmp/envelope_check.py"])
    line = [ln for ln in r.stdout.splitlines() if ln.startswith("{")]
    return json.loads(line[-1]) if line else {"error": (r.stderr or r.stdout)[-400:]}


def api_env():
    """The rig API's environment (names + values), to start a twin of it."""
    env = json.loads(sh(["docker", "inspect", API, "--format", "{{json .Config.Env}}"]).stdout)
    return [e for e in env if not e.startswith(("PATH=", "HOSTNAME="))]


def start(name, port=None, extra_env=(), volume="qs-rig_qs-data", wait=True):
    sh(["docker", "rm", "-f", name])
    cmd = ["docker", "run", "-d", "--name", name, "--network", "querystudio-local-net"]
    for e in api_env():
        if not e.startswith(("QUERY_STUDIO_SECRET_KEY=", "QUERY_STUDIO_SECRET_KEY_PREVIOUS=",
                             "QUERYSTUDIO_SERVER_PORT=")):
            cmd += ["-e", e]
    cmd += ["-e", "QUERYSTUDIO_SERVER_PORT=8000", "-e", "QS_ENCRYPTION_KEY_OWNER=true"]
    for e in extra_env:
        cmd += ["-e", e]
    if port:
        cmd += ["-p", f"{port}:8000"]
    cmd += ["-v", f"{volume}:/app/data", IMAGE, "python", "-m", "querystudio", "webserver"]
    r = sh(cmd)
    if r.returncode != 0:
        raise SystemExit(f"start {name}: {r.stderr[-400:]}")
    if not wait:
        return True
    t0 = time.time()
    while time.time() - t0 < 300:
        h = sh(["docker", "exec", name, "curl", "-sf", "http://localhost:8000/health/live"])
        if h.returncode == 0:
            return round(time.time() - t0)
        if sh(["docker", "inspect", name, "--format", "{{.State.Running}}"]).stdout.strip() != "true":
            raise SystemExit(f"{name} exited: {sh(['docker', 'logs', '--tail', '30', name]).stdout[-800:]}")
        time.sleep(3)
    raise SystemExit(f"{name} not live in 300 s")


def restart_components():
    sh(["docker", "restart", *COMPONENTS], timeout=600)
    t0 = time.time()
    while time.time() - t0 < 600:
        st = {c: sh(["docker", "inspect", c, "--format", "{{.State.Health.Status}}"]).stdout.strip()
              for c in COMPONENTS}
        if all(s == "healthy" for s in st.values()):
            return st, round(time.time() - t0)
        time.sleep(5)
    return st, round(time.time() - t0)


def new_key():
    from cryptography.fernet import Fernet
    return Fernet.generate_key().decode()


CONN_CONFIG = {"host": "envproof-nowhere", "port": 8080, "catalog": "tpch", "schema": "tiny",
               "username": "envproof"}


def save_secret(api, conn_id, pw):
    return api.call("PUT", f"/api/connections/{conn_id}", {
        "name": "ENVPROOF_SECRET", "connection_type": "trino", "config": {**CONN_CONFIG, "password": pw}})


def main():
    with open(os.path.join(HERE, ".envelope_check.py"), "w") as fh:
        fh.write(CHECK)
    if psql("select to_regclass('encryption_data_keys') is not null") != "t":
        raise SystemExit("encryption_data_keys does not exist: the rig runs an image older than envelope "
                         "encryption -- rebuild it (rig.ps1 up)")
    a1 = Api(8000)
    # the proof's own connection: a local one, so nothing is reached when it is saved
    s, b = a1.call("GET", "/api/connections")
    rows = b if isinstance(b, list) else (b or {}).get("connections", [])
    mine = [r for r in rows if r.get("name") == "ENVPROOF_SECRET"]
    if mine:
        conn_id = mine[0]["id"]
    else:
        s, b = a1.call("POST", "/api/connections", {"name": "ENVPROOF_SECRET", "connection_type": "trino",
                                                    "config": {**CONN_CONFIG, "password": "first-value"}})
        if s not in (200, 201):
            raise SystemExit(f"create connection: {s} {str(b)[:300]}")
        conn_id = b["id"]

    # ── E1: a restart of every component rewrites nothing ────────────────
    before_secrets, before_rows = secrets_hash(), key_rows()
    st, secs = restart_components()
    after_secrets, after_rows = secrets_hash(), key_rows()
    check("E1 every component healthy after a restart", all(s == "healthy" for s in st.values()), f"{st} in {secs}s")
    check("E1 the restart rewrote NO stored secret (no start-up sweep)", before_secrets == after_secrets,
          f"{before_secrets} -> {after_secrets}")
    check("E1 the data keys: ONE active (generated) + the earlier key(s) retired, unchanged by the restart",
          before_rows == after_rows and sum(":active:" in r for r in after_rows) == 1
          and any(":retired:legacy:" in r for r in after_rows), after_rows)
    comp = {c: in_container(c) for c in COMPONENTS}
    check("E1 every component: envelope mode, the SAME active data key, nothing unreadable",
          len({v.get("fingerprint") for v in comp.values()}) == 1
          and all(v.get("mode") == "envelope" and v.get("available") and v.get("unreadable") == 0
                  for v in comp.values()),
          {c: (v.get("mode"), v.get("fingerprint"), v.get("unreadable"), v.get("error")) for c, v in comp.items()})

    # ── E2: three API containers on one database ─────────────────────────
    up = {n: start(n, p) for n, p in EXTRA.items()}
    check("E2 two more API containers start on the same database", all(up.values()), up)
    apis = {API: a1, **{n: Api(p) for n, p in EXTRA.items()}}
    seen = {}
    for name, api in apis.items():
        pw = f"saved-through-{name}"
        s, _ = save_secret(api, conn_id, pw)
        readers = {o: in_container(o).get("password") for o in apis if o != name}
        seen[name] = (s, all(v == pw for v in readers.values()))
    check("E2 a secret saved through ANY container is read by the others", all(s == 200 and ok for s, ok in seen.values()),
          seen)
    fps = {n: in_container(n).get("fingerprint") for n in apis}
    check("E2 all three report the SAME active data key", len(set(fps.values())) == 1 and None not in fps.values(), fps)
    rows_before = key_rows()
    t0 = time.time()
    with cf.ThreadPoolExecutor(30) as ex:
        futs = [ex.submit(save_secret, api, conn_id, f"concurrent-{n}-{i}") for n, api in apis.items() for i in range(10)]
        statuses = [f.result()[0] for f in futs]
    took = round(time.time() - t0, 1)
    check("E2 3 x 10 concurrent saves of ONE connection all finish, none blocked", statuses.count(200) == 30 and took < 120,
          f"{statuses.count(200)}/30 x 200 in {took}s")
    final = {n: in_container(n).get("password") for n in apis}
    check("E2 afterwards every container reads the SAME last value",
          len(set(final.values())) == 1 and str(next(iter(final.values()))).startswith("concurrent-"), final)
    check("E2 the saves created no data key", key_rows() == rows_before, key_rows())

    # ── E3: a wrong master key never writes ──────────────────────────────
    rows_w, secrets_w = wrapped_hash(), secrets_hash()
    sh(["docker", "volume", "create", "qs-envproof-empty"])
    start(WRONG, None, [f"QUERY_STUDIO_SECRET_KEY={new_key()}"], volume="qs-envproof-empty", wait=False)
    time.sleep(20)
    w = in_container(WRONG)
    check("E3 a wrong master key: MISMATCH said, with both fingerprints",
          w.get("available") is False and w.get("mismatch") is True and "wrapped by" in str(w.get("source")),
          str(w.get("source"))[:300])
    r = sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", WRONG, "python", "-c",
            "from core import crypto\nfrom core.database import DatabaseManager\nfrom core.data_key_store import DataKeyStore\n"
            "crypto.bind_data_key_store(DataKeyStore(DatabaseManager()))\n"
            "try:\n    crypto.encrypt_value('x'); print('SAVED')\nexcept crypto.EncryptionKeyUnavailable as e:\n    print('REFUSED')"])
    check("E3 a save there is refused", "REFUSED" in r.stdout, (r.stdout or r.stderr)[-200:])
    check("E3 nothing was written: data keys and stored secrets unchanged",
          wrapped_hash() == rows_w and secrets_hash() == secrets_w, f"{rows_w}/{wrapped_hash()}")
    sh(["docker", "rm", "-f", WRONG])

    # ── E4: a Vault master rotation re-wraps the data-key rows only ──────
    secrets_r, rows_r = secrets_hash(), key_rows()
    file_fp = rows_r[0].split(":")[-1]
    new_master = new_key()
    start(ROTATE, None, [f"QUERY_STUDIO_SECRET_KEY={new_master}"])    # the key file is read as PREVIOUS
    rot = key_rows()
    check("E4 the new master re-wrapped every data-key row", {r.split(":")[-1] for r in rot} != {file_fp}
          and len({r.split(":")[-1] for r in rot}) == 1 and [r.rsplit(":", 1)[0] for r in rot] ==
          [r.rsplit(":", 1)[0] for r in rows_r], rot)
    check("E4 NO stored secret changed in the rotation", secrets_hash() == secrets_r)
    s, _ = save_secret(a1, conn_id, "after-master-rotation")
    st_a1 = a1.call("GET", "/api/admin/encryption-key")[1].get("this_pod", {})
    on_new = in_container(ROTATE)                               # a process on the NEW master
    check("E4 the running API (still on the old master) keeps saving -- under the SHARED data key",
          s == 200 and st_a1.get("available") is True and on_new.get("password") == "after-master-rotation",
          (s, st_a1.get("available"), on_new.get("password")))
    old_fresh = in_container(API)                               # a NEW process on the old master
    check("E4 a process STARTING on the old master after the rotation is told MISMATCH (by design)",
          old_fresh.get("mismatch") is True, str(old_fresh.get("source"))[:160])
    sh(["docker", "rm", "-f", ROTATE])
    # rotate back: the key file is the master again, the rotated one PREVIOUS
    start(ROTATE, None, [f"QUERY_STUDIO_SECRET_KEY_PREVIOUS={new_master}"])
    back = key_rows()
    check("E4 rotated back the same way: rows wrapped by the key file again, secrets untouched",
          {r.split(":")[-1] for r in back} == {file_fp} and secrets_hash() != "" , back)
    sh(["docker", "rm", "-f", ROTATE])

    # ── E5: a data-key rotation + the explicit re-encrypt job ────────────
    s, b = a1.call("POST", "/api/admin/encryption-key/rotate-data-key")
    actives = [r for r in key_rows() if ":active:" in r]
    check("E5 rotate-data-key: a NEW active data key, the old one retired", s == 200 and len(actives) == 1
          and actives[0].split(":")[0] not in "".join(r for r in rows_r if ":active:" in r), (s, key_rows()))
    s, _ = save_secret(a1, conn_id, "under-the-new-data-key")
    other = in_container("qs-envproof-api2")
    check("E5 a value saved under the new data key is read by another container at once",
          s == 200 and other.get("password") == "under-the-new-data-key", other.get("password"))
    with cf.ThreadPoolExecutor(2) as ex:
        res = list(ex.map(lambda api: api.call("POST", "/api/admin/encryption-key/reencrypt"),
                          [a1, apis["qs-envproof-api2"]]))
    bodies = [b for _, b in res]
    check("E5 the re-encrypt job ran ONCE; a second call while it ran was told so",
          all(s == 200 for s, _ in res) and sum(bool((b or {}).get("running_elsewhere")) for b in bodies) <= 1
          and any(not (b or {}).get("running_elsewhere") for b in bodies), bodies)
    st = a1.call("GET", "/api/admin/encryption-key")[1].get("stored", {})
    check("E5 after the job nothing is left under an older key and nothing is unreadable",
          st.get("needs_rotation") == 0 and not st.get("unreadable"),
          (st.get("current"), st.get("needs_rotation"), st.get("unreadable")))
    comp = {c: in_container(c) for c in COMPONENTS}
    check("E5 afterwards every component reads every stored secret",
          all(v.get("available") and v.get("unreadable") == 0 for v in comp.values()),
          {c: (v.get("fingerprint"), v.get("unreadable")) for c, v in comp.items()})

    for n in EXTRA:
        sh(["docker", "rm", "-f", n])
    sh(["docker", "volume", "rm", "qs-envproof-empty"])
    # 2026-10-18: the proof's connection points at a host that does not exist; left behind it
    # reads as an "unknown" dependency on Component Health forever
    s, _ = a1.call("DELETE", f"/api/connections/{conn_id}")
    check("the proof's own connection is removed afterwards", s in (200, 204), s)
    path = os.path.join(HERE, "envelope-keys-results.json")
    with open(path, "w") as fh:
        json.dump({"checks": CHECKS}, fh, indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad or not CHECKS else 0)


if __name__ == "__main__":
    try:
        main()
    finally:
        for n in [*EXTRA, WRONG, ROTATE]:
            sh(["docker", "rm", "-f", n])
