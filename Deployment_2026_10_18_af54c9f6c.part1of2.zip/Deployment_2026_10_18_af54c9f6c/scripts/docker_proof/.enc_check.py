
import json, sys
from sqlalchemy import text
from core import crypto
from core.database import DatabaseManager
from core.encryption_key_rotation import sweep
db = DatabaseManager()
rep = sweep(db, write=False)
with db.engine.connect() as c:
    rows = c.execute(text("select name, config from connections")).fetchall()
plain_ok = 0
for name, cfg in rows:
    cfg = json.loads(cfg) if isinstance(cfg, str) else (cfg or {})
    if any(str(v).startswith("enc::") for _, v in crypto._sensitive_paths(cfg)) and not crypto.undecryptable_fields(cfg):
        plain_ok += 1
print(json.dumps({"key": crypto.key_status(), "unreadable": len(rep["unreadable"]),
                  "needs_rotation": rep["rotated"], "current": rep["current"],
                  "connections_readable": plain_ok}))
