"""The owner's fact_tetb JOIN fact_tetb_ext AT VOLUME (2026-10-11).

The month-end feeds' 54-column FULL OUTER JOIN (tetb_month_end_sod_proof.JoinSpec,
the same query) over millions of rows: fact_tetb and fact_tetb_ext seeded ON
the clusters for one (entity, event, business date) island per side --
fact_tetb row ids 1..N, fact_tetb_ext ids N/4+1..N/4+N -- so each side's JOIN
is 1.25N rows (0.75N MATCHED, 0.25N TETB_ONLY, 0.25N EXT_ONLY) and the file is
2.5N rows, cloud (REAL AWS) UNION ALL on-prem, CSV to SFTP.  The file's
control totals (row count, sum of the row id in SOURCE_DATA_ROW, sum of
X_SNAP_VERSION) are recomputed IN the SFTP container and compared with each
Trino's own answer to the same JOIN.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/join_volume_proof.py --rows 5000000 [--engine-write]
    python scripts/docker_proof/join_volume_proof.py --sweep-leftovers [--execute]
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import volume_feed_proof as V  # noqa: E402  (BD / ENTITY / EVENT / seed_sql / sampler / helpers)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, SB_HOST, SB_PORT, SFTP, TABLES, cloud_cli, ddl, drop_schema_cascade,
    load_queries, parse_query, sb_cli,
)
from tetb_month_end_sod_proof import T_COLS, JoinSpec, narrow_types, pick_text_columns  # noqa: E402

TAG = V.TAG
CLOUD_SCHEMA = f"iceberg_aws.jv_{TAG}"
TBL = {"cloud": {"t": f"{CLOUD_SCHEMA}.fact_tetb", "x": f"{CLOUD_SCHEMA}.fact_tetb_ext"},
       "prem": {"t": f"iceberg.qs.fact_tetb_jv{TAG}", "x": f"iceberg.qs.fact_tetb_ext_jv{TAG}"}}


def join_truth(cli, spec: JoinSpec) -> dict:
    sql = (spec.feed_sql().replace("{BUSINESSDATE}", V.BD.isoformat())
           .replace("{SYSTEM_ENTITY}", V.ENTITY).replace("{EventCode}", V.EVENT))
    out = cli(f'SELECT count(*), sum("X_SNAP_VERSION"), '
              f'sum(CAST(split_part("SOURCE_DATA_ROW", \':\', 2) AS BIGINT)), '
              f'count_if("MATCH_STATE" = \'MATCHED\') FROM ({sql}) q;\n', stdin=True).strip().replace('"', "")
    n, sx, si, m = re.split(r"[,\t]", out)
    return {"rows": int(n), "sum_x_snap": int(sx or 0), "sum_id": int(si or 0), "matched": int(m)}


def join_file_totals(name: str) -> dict:
    path = f"{SFTP['home']}/{name}"
    awk = ("{sub(/\r$/,\"\")} NR==1{sub(/^\xef\xbb\xbf/,\"\");for(i=1;i<=NF;i++){h=tolower($i);gsub(/\"/,\"\",h);"
           "if(h==\"x_snap_version\")s=i;if(h==\"source_data_row\")r=i;if(h==\"match_state\")m=i};next}"
           "{n++;gsub(/\"/,\"\",$s);ss+=$s;v=$r;gsub(/\"/,\"\",v);split(v,p,\":\");si+=p[2];"
           "w=$m;gsub(/\"/,\"\",w);if(w==\"MATCHED\")mm++}"
           "END{printf \"%d %.0f %.0f %d\\n\",n,ss,si,mm}")
    r = subprocess.run(["docker", "exec", SFTP["container"], "awk", "-F", ",", awk, path],
                       capture_output=True, text=True, env=DENV, timeout=7200)
    sz = subprocess.run(["docker", "exec", SFTP["container"], "stat", "-c", "%s", path],
                        capture_output=True, text=True, env=DENV).stdout.strip()
    p = r.stdout.split()
    if len(p) != 4:
        return {"error": (r.stderr or r.stdout)[-300:]}
    return {"rows": int(p[0]), "sum_x_snap": int(p[1]), "sum_id": int(p[2]), "matched": int(p[3]),
            "bytes": int(sz) if sz.isdigit() else None}


def main(argv=None) -> int:
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=2_500_000, help="TOTAL output rows (2.5 x N)")
    ap.add_argument("--chunk", type=int, default=500_000)
    ap.add_argument("--engine-write", action="store_true")
    ap.add_argument("--prem-n", type=int, default=None,
                    help="rows per table on-prem (default: the same N as cloud); the rig's 4.6 GB on-prem "
                         "Trino was OOM-killed joining 4M x 4M while AWS joined it in a minute")
    ap.add_argument("--timeout", type=int, default=10800)
    args = ap.parse_args(rest)
    r = Rig()
    if sweep:
        rules = [Rule("feed", r"JV_\d{6}", list_path="/api/feeds", delete_path="/api/feeds/{id}"),
                 Rule("saved query", r"jv_(cloud|prem)_\d{6}", list_path="/api/queries", delete_path="/api/queries/{id}"),
                 Rule("connection", r"(sb-onprem|trino-cloud-ew)-jv-\d{6}", list_path="/api/connections",
                      delete_path="/api/connections/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for line in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'jv_%'").splitlines():
            s = line.strip().strip('"')
            if re.fullmatch(r"jv_\d{6}", s):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{s}")
                if execute:
                    print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{s}"))
        for line in sb_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%_jv%'").splitlines():
            t = line.strip().strip('"')
            if re.fullmatch(r"fact_tetb(_ext)?_jv\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    sb_cli(f"DROP TABLE iceberg.qs.{t}")
        return rc

    pw = os.environ.get("QS_SB_ANALYST_PW") or ""
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    # output = 1.25 x (N_cloud + N_prem); --rows is the total
    n_prem = args.prem_n
    n = int(args.rows / 1.25) - n_prem if n_prem is not None else int(args.rows / 2.5)
    N = {"cloud": n, "prem": n_prem if n_prem is not None else n}
    t_sql, _ = load_queries(TABLES["tetb"])
    x_sql, _ = load_queries(TABLES["ext"])
    _, t_parsed = parse_query(t_sql, TABLES["tetb"]["alias"])
    _, x_parsed = parse_query(x_sql, TABLES["ext"]["alias"])
    t_cols, x_cols = pick_text_columns(t_parsed, T_COLS), pick_text_columns(x_parsed, T_COLS)
    t_types = narrow_types(t_parsed, t_cols, with_rate=True)
    x_types = narrow_types(x_parsed, x_cols, with_rate=False)
    specs = {s: JoinSpec(TBL[s]["t"], TBL[s]["x"], t_cols, x_cols) for s in TBL}
    print(f"== JOIN VOLUME tag {TAG}: {len(specs['cloud'].aliases())}-column FULL OUTER JOIN, N={n:,} per table (cloud) "
          f"-> {args.rows:,} output rows{' (engine_write)' if args.engine_write else ''}")
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    fid = None
    t_start = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    sampler = V.Sampler()
    sampler.start()
    try:
        t0 = time.time()
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/jv_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        for side, cli in (("cloud", cloud_cli), ("prem", sb_cli)):
            ns = N[side]
            for which, types, base in (("t", t_types, 0), ("x", x_types, ns // 4)):
                table = TBL[side][which]
                cli(ddl(table, types, hive=False) + ";\n", stdin=True)
                if side == "prem":
                    ledger.add("on-prem table", table,
                               remover=lambda tb=table: (bool(sb_cli(f"DROP TABLE {tb}") is not None), "dropped"))
                done = 0
                while done < ns:
                    k = min(args.chunk, ns - done)
                    cli(V.seed_sql(table, types, side, k, offset=base + done) + ";\n", stdin=True)
                    done += k
        truth = {s: join_truth(cloud_cli if s == "cloud" else sb_cli, specs[s]) for s in TBL}
        exp = {s: {"rows": int(1.25 * N[s]), "matched": N[s] - N[s] // 4} for s in TBL}
        check(f"V0 seeded 2 tables per side (cloud {N['cloud']:,}, on-prem {N['prem']:,} rows per table) in "
              f"{round(time.time() - t0)}s; each side's JOIN (Trino) == expected rows and MATCHED",
              all(truth[s]["rows"] == exp[s]["rows"] and truth[s]["matched"] == exp[s]["matched"] for s in TBL),
              {"truth": truth, "expected": exp})

        cloud_id, _ = pick_cloud(r, "")
        prem_cfg = {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic", "password": pw,
                    "http_scheme": "https", "verify_ssl": False, "catalog": "iceberg", "schema": "qs"}
        if args.engine_write:
            cloud_cli(f"CREATE SCHEMA IF NOT EXISTS hive_aws.qs_unload WITH (location = 's3://{AWS_BUCKET}/qs-unload/')")
            sb_cli("CREATE SCHEMA IF NOT EXISTS hive.qs_unload WITH (location = 's3://qs-data/qs-unload/')")
            aws = V.read_env_file(os.path.expanduser("~/.qs_keys/aws.env"))
            s, b = r.call("POST", "/api/connections", {"name": f"trino-cloud-ew-jv-{TAG}", "connection_type": "trino",
                "config": {"host": "qs-trino", "port": 8080, "user": "sweep", "http_scheme": "http",
                           "catalog": "iceberg_aws", "schema": "fin", "unload_scratch_catalog": "hive_aws",
                           "unload_scratch_schema": "qs_unload", "unload_s3_location": f"s3://{AWS_BUCKET}/qs-unload",
                           "unload_s3_access": {"auth_mode": "keys", "region_name": aws["AWS_REGION"],
                                                "aws_access_key_id": aws["AWS_ACCESS_KEY_ID"],
                                                "aws_secret_access_key": aws["AWS_SECRET_ACCESS_KEY"]}}})
            cloud_id = (b or {}).get("id")
            ledger.add("connection", f"trino-cloud-ew-jv-{TAG}", path=f"/api/connections/{cloud_id}")
            minio = V.read_props(os.path.join(HERE, "starburst_like", "generated", "catalog", "iceberg.properties"))
            prem_cfg.update({"unload_scratch_catalog": "hive", "unload_scratch_schema": "qs_unload",
                             "unload_s3_location": "s3://qs-data/qs-unload",
                             "unload_s3_access": {"auth_mode": "keys", "region_name": minio["s3.region"],
                                                  "endpoint_url": minio["s3.endpoint"], "path_style": True,
                                                  "addressing_style": "path",
                                                  "aws_access_key_id": minio["s3.aws-access-key"],
                                                  "aws_secret_access_key": minio["s3.aws-secret-key"]}})
        s, b = r.call("POST", "/api/connections", {"name": f"sb-onprem-jv-{TAG}", "connection_type": "starburst",
                                                  "config": prem_cfg})
        prem_id = (b or {}).get("id")
        ledger.add("connection", f"sb-onprem-jv-{TAG}", path=f"/api/connections/{prem_id}")
        q = {}
        for side, cid in (("cloud", cloud_id), ("prem", prem_id)):
            s, qq = r.call("POST", "/api/queries", {"name": f"jv_{side}_{TAG}", "query_config": {
                "files": [], "raw_sql": specs[side].feed_sql(), "connection_id": cid}})
            q[side] = (qq or {}).get("id")
            ledger.add("saved query", f"jv_{side}_{TAG}", path=f"/api/queries/{q[side]}")
        fname = f"JV_{TAG}_{V.BD:%Y%m%d}.csv"
        s, fb = r.call("POST", "/api/feeds", {
            "name": f"JV_{TAG}", "source_type": "saved_query", "source_id": q["cloud"], "connection_id": cloud_id,
            "secondary_connection_id": prem_id, "secondary_source_type": "saved_query", "secondary_source_id": q["prem"],
            "combine_mode": "union", "output_format": "csv",
            "output_filename_template": f"JV_{TAG}_{{business_date:YYYYMMDD}}.csv", "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "execution_backend": "native", "notify_on_failure": False,
            "query_params": {"SYSTEM_ENTITY": V.ENTITY, "EventCode": V.EVENT}})
        fid = (fb or {}).get("id")
        if not check(f"V1 the JOIN feed JV_{TAG} is created", s == 200 and fid, str(fb)[:300]):
            return 1
        ledger.add("feed", f"JV_{TAG}", path=f"/api/feeds/{fid}")
        ledger.add("sftp file", fname, remover=lambda: (subprocess.run(
            ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fname}"], env=DENV).returncode == 0, "rm"))
        t1 = time.time()
        r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": V.BD.isoformat(), "end_date": V.BD.isoformat(),
                                                    "deliver": True, "reason": "join volume proof (test data only)"})
        e = {}
        while time.time() - t1 < args.timeout:
            _, ex = r.call("GET", f"/api/feeds/{fid}/executions")
            ex = ex if isinstance(ex, list) else (ex or {}).get("items") or []
            if ex and ex[0].get("status") in ("completed", "failed", "error"):
                e = ex[0]
                break
            time.sleep(15)
        run_s = round(time.time() - t1, 1)
        total = int(1.25 * N["cloud"]) + int(1.25 * N["prem"])
        check(f"V1 the JOIN feed COMPLETED in {run_s}s ({round(total / run_s) if run_s else 0:,} rows/s)",
              e.get("status") == "completed",
              {"status": e.get("status"), "stage": e.get("failed_stage"), "error": str(e.get("error_message"))[:400]})
        if e.get("status") == "completed":
            ft = join_file_totals(fname)
            want = {k: truth["cloud"][k] + truth["prem"][k] for k in ("rows", "sum_x_snap", "sum_id", "matched")}
            check(f"V2 the SFTP file: {ft.get('rows', 0):,} rows; count, MATCHED, sum(row id), sum(X_SNAP_VERSION) == "
                  f"cloud JOIN + on-prem JOIN (Trino); {round((ft.get('bytes') or 0) / 1e9, 2)} GB",
                  all(ft.get(k) == want[k] for k in want) and want["rows"] == total, {"file": ft, "truth": want})
            _, full = r.call("GET", f"/api/feed-executions/{e.get('id')}")
            st = (full or {}).get("stage_timings") or {}
            print("   stage timings:", {k: v for k, v in st.items() if isinstance(v, (int, float))})
    finally:
        sampler.stop_.set()
        sampler.join(15)
        print("   peak memory:", {k: f"{round(v)} MiB" for k, v in sorted(sampler.peak.items())})
        if fid:
            print("   executed in:", V.executed_in(fid, t_start))
        print("\n== cleanup")
        ok, failed = ledger.cleanup()
        print(f"cleanup: {ok} removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
