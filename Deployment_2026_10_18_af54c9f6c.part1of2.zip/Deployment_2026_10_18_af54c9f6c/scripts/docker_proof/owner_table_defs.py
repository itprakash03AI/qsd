"""The rig's fact_tetb / fact_tetb_ext DEFINITIONS, derived from EVERY query
the owner shared -- nothing listed by hand (2026-10-14: "update the definition
of both tables if something is missing").

Sources: the two 460-column fact_tetb queries (``fact_tetb.json``), the
fact_tetb_ext queries (``test_query_001.json``) and the JOIN query
(``temp/QUERY_WITH_JOIN.SQL``).  Every column any of them reads belongs to the
table its qualifier names (an unqualified column to the table that already
has it, else to fact_tetb, the fact table).  Its TYPE is the strongest one any
query needs it to have:

    SUM / AVG / arithmetic / CAST(x AS DOUBLE|DECIMAL|BIGINT)   -> DOUBLE
    date_format / CAST(x AS TIMESTAMP)                          -> TIMESTAMP
    CAST(x AS DATE) / BUSINESS_CLOSE_DATE                       -> DATE
    anything else (CAST AS VARCHAR, REGEXP_LIKE, ...)           -> VARCHAR

The earlier queries CAST everything to VARCHAR, which works from any type, so
a stronger type never breaks them; the JOIN query's SUM(x) does not work on
VARCHAR, so the weaker type would.

    python owner_table_defs.py          # prints both definitions
"""
from __future__ import annotations

import os
import sys
from typing import Dict, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
JOIN_SQL = os.path.join(ROOT, "temp", "QUERY_WITH_JOIN.SQL")

KEYS = {"BUSINESS_CLOSE_DATE": "DATE", "CODE": "VARCHAR", "BUSINESSEVENT": "VARCHAR",
        "SOURCE_DATA_SET": "VARCHAR", "SOURCE_DATA_ROW": "VARCHAR"}
RANK = {"VARCHAR": 0, "DATE": 1, "TIMESTAMP": 2, "DOUBLE": 3}
_NUMERIC_CASTS = ("DOUBLE", "DECIMAL", "BIGINT", "INT", "INTEGER", "REAL")


def _stronger(a: str, b: str) -> str:
    return a if RANK.get(a, 0) >= RANK.get(b, 0) else b


def usage_types(sql: str, dialect: str = "trino") -> Dict[Tuple[str, str], str]:
    """``{(QUALIFIER, COLUMN): type}`` for every column ``sql`` reads, typed by
    how it is used (module docstring).  QUALIFIER is '' when unqualified."""
    import sqlglot
    from sqlglot import exp
    tree = sqlglot.parse_one(sql.strip().rstrip(";"), dialect=dialect)
    out: Dict[Tuple[str, str], str] = {}
    for col in tree.find_all(exp.Column):
        key = ((col.table or "").upper(), col.name.upper())
        want = "VARCHAR"
        node = col.parent
        while node is not None and not isinstance(node, (exp.Select, exp.Where, exp.Join)):
            if isinstance(node, (exp.Sum, exp.Avg, exp.Add, exp.Sub, exp.Mul, exp.Div)):
                want = "DOUBLE"
                break
            if isinstance(node, exp.Cast):
                to = node.to.sql(dialect=dialect).upper()
                if to.startswith(_NUMERIC_CASTS):
                    want = "DOUBLE"
                elif to.startswith("TIMESTAMP"):
                    want = "TIMESTAMP"
                elif to == "DATE":
                    want = "DATE"
                break
            fname = (node.sql_name() if isinstance(node, exp.Func) else "").upper()
            if fname in ("DATE_FORMAT", "TIME_TO_STR", "STRFTIME", "FORMAT_DATETIME") or \
                    isinstance(node, (exp.TimeToStr,)):
                want = "TIMESTAMP"
                break
            if isinstance(node, (exp.Func, exp.Case, exp.If, exp.Coalesce)) and \
                    not isinstance(node, exp.Cast):
                node = node.parent
                continue
            node = node.parent
        out[key] = _stronger(out.get(key, want), want)
    return out


def derive(*, fact_sql_list, ext_sql_list, join_sql: str):
    """``(fact_tetb {col: type}, fact_tetb_ext {col: type})`` from all queries."""
    fact: Dict[str, str] = dict(KEYS)
    ext: Dict[str, str] = dict(KEYS)

    def add(table: Dict[str, str], col: str, typ: str) -> None:
        if col == "BUSINESS_CLOSE_DATE":
            typ = "DATE"
        table[col] = _stronger(table.get(col, typ), typ)

    for sql in fact_sql_list:
        for (_q, c), t in usage_types(sql).items():
            add(fact, c, t)
    for sql in ext_sql_list:
        for (_q, c), t in usage_types(sql).items():
            add(ext, c, t)
    unq = {}
    for (q, c), t in usage_types(join_sql).items():
        if q == "FACT_TETB_EXT":
            add(ext, c, t)
        elif q == "FACT_TETB":
            add(fact, c, t)
        else:
            unq[c] = t
    for c, t in unq.items():          # after the qualified ones: who has it?
        if c in fact and c not in ext:
            add(fact, c, t)
        elif c in ext and c not in fact:
            add(ext, c, t)
        elif c in fact and c in ext:
            raise SystemExit(f"{c} is unqualified and in BOTH tables: the JOIN query is ambiguous")
        else:
            add(fact, c, t)
    return fact, ext


def owner_definitions():
    sys.path.insert(0, HERE)
    from tetb_real_e2e_proof import TABLES, load_queries
    t_cloud, t_prem = load_queries(TABLES["tetb"])
    x_cloud, x_prem = load_queries(TABLES["ext"])
    join_sql = open(JOIN_SQL, encoding="utf-8").read()
    return derive(fact_sql_list=[t_cloud, t_prem], ext_sql_list=[x_cloud, x_prem],
                  join_sql=join_sql)


if __name__ == "__main__":
    import collections
    f, x = owner_definitions()
    for name, d in (("fact_tetb", f), ("fact_tetb_ext", x)):
        print(name, len(d), "columns", dict(collections.Counter(d.values())))
        print("  non-text:", {c: t for c, t in d.items() if t != "VARCHAR"})
