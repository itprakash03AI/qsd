"""Typed SQL in the query builder runs IN the browsed catalog / schema, row
security still applies to it, and SQL mistakes never pause the connection
(2026-10-03, REAL Snowflake, login ON).

The owner picked QS_DEMO / FIN in the query builder and typed
``select * from TRADES``: "Object 'TRADES' does not exist" -- and three such
mistakes OPENED the connection's circuit breaker, refusing every later query.

  1. the admin's bare statement WITH the browsed context == Snowflake's own
     answer; the same statement WITHOUT it still fails (the context is what
     made it work, not something else);
  2. a row policy on QS_DEMO.FIN.TRADES (REGION = 'EMEA') bound to
     rig_analyst: the analyst's BARE statement returns EMEA only -- the
     qualification happens before row security reads the text;
  3. six "does not exist" mistakes in a row, then a correct query: it runs.

    . ~/.qs_keys/rigpw.sh
    QS_SF_CONN=239 python scripts/docker_proof/snowflake_typed_sql_context_proof.py
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402

CID = int(os.environ.get("QS_SF_CONN", "239"))
CTX = {"default_catalog": "QS_DEMO", "default_schema": "FIN"}
BARE = "select REGION, count(*) as N from TRADES group by REGION"
TAG = str(int(time.time()))[-6:]
res = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:260], flush=True)
    return bool(ok)


def run(sess, sql, ctx=None, timeout=180):
    body = {"connection_id": CID, "raw_sql": sql, "output_format": "json", "cache_strategy": "bypass"}
    body.update(ctx or {})
    s, r, _ = sess.call("POST", "/api/execute", body)
    if s != 200 or not (r or {}).get("execution_id"):
        return s, r
    eid = r["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st, _ = sess.call("GET", f"/api/executions/{eid}/status")
        status = (st or {}).get("status")
        if status in ("completed", "success", "finished"):
            _, rb, _ = sess.call("GET", f"/api/executions/{eid}/results?page_size=100")
            names = [x["name"] if isinstance(x, dict) else x for x in (rb or {}).get("columns") or []]
            rows = [x if isinstance(x, dict) else dict(zip(names, x)) for x in (rb or {}).get("rows") or []]
            return 200, {str(x.get("REGION")): int(x.get("N")) for x in rows}
        if status in ("failed", "error", "cancelled"):
            return 500, (st or {}).get("error_message") or st
        time.sleep(0.5)
    return -1, "timeout"


def truth():
    import snowflake.connector
    from cryptography.hazmat.primitives import serialization
    key = os.path.expanduser(os.environ.get("QS_SF_KEY_FILE", "~/.qs_keys/qs_svc_key.p8"))
    pk = serialization.load_pem_private_key(open(key, "rb").read(), password=None)
    der = pk.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8,
                           serialization.NoEncryption())
    con = snowflake.connector.connect(account=os.environ.get("QS_SF_ACCOUNT", "IRFJALM-NZC41769"),
                                      user="QS_SVC", private_key=der, warehouse="COMPUTE_WH")
    try:
        return {r[0]: int(r[1]) for r in con.cursor().execute(
            "select REGION, count(*) from QS_DEMO.FIN.TRADES group by 1").fetchall()}
    finally:
        con.close()


def main():
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    analyst = Session("rig_analyst", os.environ["QS_RIG_ANALYST_PW"])
    want = truth()
    check("truth read from Snowflake", len(want) == 4 and sum(want.values()) == 10_000, want)
    made = []
    try:
        print("\n== 1 . the browsed context")
        s, got = run(admin, BARE, CTX)
        check("bare TRADES under QS_DEMO / FIN == Snowflake", s == 200 and got == want, (s, got))
        s, got = run(admin, BARE)
        check("the same statement WITHOUT the context still fails (does not exist)",
              s == 500 and "does not exist" in str(got), (s, str(got)[:160]))

        print("\n== 2 . row security still applies to the bare name")
        s, p, _ = admin.call("POST", "/api/admin/row-security/policies", {
            "name": f"sf-ctx-{TAG}", "table_pattern": "QS_DEMO.FIN.TRADES",
            "filter_sql": "REGION = 'EMEA'", "enforcement": "rewrite", "policy_class": "permissive"})
        if check("policy on QS_DEMO.FIN.TRADES created", s == 200, (s, p)):
            made.append(f"/api/admin/row-security/policies/{p['id']}")
            s, b, _ = admin.call("POST", "/api/admin/row-security/bindings", {
                "policy_kind": "row", "policy_id": p["id"], "principal_type": "user", "principal_id": "rig_analyst"})
            if s == 200:
                made.insert(0, f"/api/admin/row-security/bindings/{b['id']}")
            admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
            s, got = run(analyst, BARE, CTX)
            check("the analyst's BARE statement returns EMEA only", s == 200 and got == {"EMEA": want["EMEA"]},
                  (s, got))
            s, got = run(analyst, BARE.replace("from TRADES", "from QS_DEMO.FIN.TRADES"))
            check("and the qualified one the same", s == 200 and got == {"EMEA": want["EMEA"]}, (s, got))
            s, got = run(admin, BARE, CTX)
            check("the admin (unbound) still sees every region", s == 200 and got == want, (s, got))

        print("\n== 3 . SQL mistakes never pause the connection")
        errs = [run(admin, f"select * from NOPE_{TAG}_{i}", CTX)[0] for i in range(6)]
        check("six 'does not exist' mistakes fail as mistakes", errs == [500] * 6, errs)
        s, got = run(admin, BARE, CTX)
        check("the next correct query RUNS (the breaker stayed closed)", s == 200 and got == want, (s, str(got)[:200]))
    finally:
        for path in made:
            admin.call("DELETE", path)
        admin.call("POST", "/api/admin/row-security/cache/invalidate", {})
        print(f"\ncleanup: {len(made)} removed")
    print(f"\n{sum(res)}/{len(res)} PASSED")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
