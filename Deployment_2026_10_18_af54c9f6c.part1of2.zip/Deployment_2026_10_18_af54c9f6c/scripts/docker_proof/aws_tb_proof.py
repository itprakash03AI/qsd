"""Investment-bank TRIAL BALANCE data products on REAL AWS S3 -- the owner's
exact query shapes, live on Docker (2026-10-05).

Data (Iceberg on the owner's bucket, built by scripts/aws_s3/*.py through the
Trino catalog iceberg_aws): FACT_TETB (partitioned business_close_date,
business_event, code; ~2,700 files; schema-evolved), FACT_TETB_EXT (merge-on-
read DELETE + UPDATE files), FACT_TETB_WIDE (1,000 columns), FACT_JOURNAL
(debit/credit lines that sum to the TB), DIM_GL_ACCOUNT, DIM_LEGAL_ENTITY,
DIM_COST_CENTRE, DIM_FX_RATE.  Plus FACT_TETB_PQ: the same data files read as
plain hive parquet (3-level paths).

Every query runs THREE ways and must agree:
  s3     QueryStudio's own S3 engine (POST /api/execute on the S3 connection):
         the pruning brain over Iceberg manifests / hive paths, deletes, joins;
  trino  QueryStudio through the Trino connection (POST /api/sql/execute) --
         the Starburst route;
  truth  the Trino CLI directly.

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/aws_tb_proof.py [--only Q1,Q2]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402

TRINO_CONN = int(os.environ.get("QS_TRINO_CONN", "2"))
S3_CONN_NAME = os.environ.get("QS_AWS_CONN_NAME", "aws-real")
CAT = "iceberg_aws.fin."
res, timings = [], []

TABLES_ICEBERG = ["fact_tetb", "fact_tetb_ext", "fact_tetb_wide", "fact_journal",
                  "dim_gl_account", "dim_legal_entity", "dim_cost_centre", "dim_fx_rate"]
PART3 = ["business_close_date", "business_event", "code"]

K5 = ("f.business_close_date = e.business_close_date AND f.code = e.code AND "
      "f.business_event = e.business_event AND f.source_data_set = e.source_data_set AND "
      "f.source_data_row = e.source_data_row")

# (id, what it is, SQL with {p} = table prefix, how to compare)
QUERIES = [
    ("Q1", "SELECT * one COB (the commonest raw-SQL view)",
     "select * from {p}fact_tetb where business_close_date = DATE '2025-09-30'", "rows+sum:gbp_currency_amount"),
    ("Q2", "5-key JOIN FACT x FACT_EXT, COB + system_id='SAP'",
     "select f.business_close_date, f.code, f.business_event, f.source_data_set, f.source_data_row, "
     "f.gbp_currency_amount, e.ext_002 from {p}fact_tetb f join {p}fact_tetb_ext e on " + K5 +
     " where f.business_close_date = DATE '2025-09-30' and f.system_id = 'SAP'", "rows+sum:gbp_currency_amount+sum:ext_002"),
    ("Q3", "heavy GROUP BY 6 keys SUM(gbp) over the JOIN, one COB",
     "select f.sap_company_id, f.gl_account, f.cost_centre, f.currency, f.business_event, f.code, "
     "sum(f.gbp_currency_amount) as gbp, count(*) as n from {p}fact_tetb f join {p}fact_tetb_ext e on " + K5 +
     " where f.business_close_date = DATE '2025-09-29' group by 1,2,3,4,5,6", "rows+sum:gbp+sum:n"),
    ("Q4", "numeric-string codes ('5','25','1000') + 'SAP' -- the lexicographic hazard",
     "select code, count(*) as n, sum(gbp_currency_amount) as gbp from {p}fact_tetb "
     "where business_close_date = DATE '2025-10-01' and code in ('5','25','1000','SAP') group by code", "exact"),
    ("Q5", "COB BETWEEN + business_event IN",
     "select business_close_date, business_event, count(*) as n, sum(gbp_currency_amount) as gbp from {p}fact_tetb "
     "where business_close_date between DATE '2025-09-29' and DATE '2025-09-30' and business_event in ('BOOKING','REVAL') "
     "group by 1,2", "exact"),
    ("Q6", "TB by GL category x entity region (dims)",
     "select g.category, l.region, sum(f.gbp_currency_amount) as gbp, count(*) as n from {p}fact_tetb f "
     "join {p}dim_gl_account g on f.gl_account = g.gl_account join {p}dim_legal_entity l on f.sap_company_id = l.sap_company_id "
     "where f.business_close_date = DATE '2025-09-30' group by 1,2", "exact"),
    ("Q7", "journal reconciles to TB (mismatching keys must be 0)",
     "select count(*) as mismatches from (select business_close_date, code, business_event, source_data_set, source_data_row, "
     "sum(gbp_amount) as ja from {p}fact_journal where business_close_date = DATE '2025-09-30' group by 1,2,3,4,5) j "
     "join {p}fact_tetb f on f.business_close_date = j.business_close_date and f.code = j.code and f.business_event = j.business_event "
     "and f.source_data_set = j.source_data_set and f.source_data_row = j.source_data_row where f.gbp_currency_amount <> j.ja", "exact"),
    ("Q8", "merge-on-read DELETEs honoured (COB 09-30, code 1000)",
     "select count(*) as n, sum(ext_002) as x from {p}fact_tetb_ext where business_close_date = DATE '2025-09-30' and code = '1000'", "exact"),
    ("Q9", "merge-on-read UPDATE honoured (ext_002 set to 0)",
     "select count(*) as n, sum(ext_002) as x from {p}fact_tetb_ext where business_close_date = DATE '2025-09-29' "
     "and code = 'SAP' and business_event = 'BOOKING'", "exact"),
    ("Q10", "schema evolution: reporting_basis NULL before, set on the new COB",
     "select business_close_date, reporting_basis, count(*) as n from {p}fact_tetb where business_close_date >= DATE '2025-10-01' "
     "group by 1,2", "exact"),
    ("Q11", "1,000-column table: all columns, one partition",
     "select * from {p}fact_tetb_wide where business_close_date = DATE '2025-09-30' and code = 'SAP'", "rows+cols+sum:w_0001"),
]
# The same files as plain hive parquet (3-level paths), S3 engine only vs truth.
PQ_QUERIES = [
    ("P1", "plain hive parquet, 3-level paths: one COB + code",
     "select count(*) as n, sum(gbp_currency_amount) as gbp from {pq} where business_close_date = '2025-09-30' and code = '1000'",
     "select count(*) as n, sum(gbp_currency_amount) as gbp from iceberg_aws.fin.fact_tetb where business_close_date = DATE '2025-09-30' and code = '1000'"),
]


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(f"{'PASS' if ok else 'FAIL'} {name} -- {str(detail)[:400]}", flush=True)
    return ok


def trino(sql):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "CSV_HEADER_UNQUOTED",
                          "--execute", sql], capture_output=True, text=True, timeout=1800)
    if out.returncode != 0:
        raise RuntimeError(out.stderr[-500:])
    lines = [ln for ln in out.stdout.splitlines() if ln.strip()]
    hdr = lines[0].split(",")
    return [dict(zip(hdr, ln.split(","))) for ln in lines[1:]]


def norm(v):
    if v is None or v == "" or v == "NULL":
        return None
    s = str(v)
    try:
        d = Decimal(s)
        return str(d.quantize(Decimal("0.01"))) if d != d.to_integral() else str(int(d))
    except Exception:
        return s[:10] if re.match(r"^\d{4}-\d{2}-\d{2}", s) else s


def wait(eid, timeout=1800):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s, st, _ = c.call("GET", f"/api/executions/{eid}/status")
        stt = (st or {}).get("status") if isinstance(st, dict) else None
        if stt in ("completed", "success", "finished"):
            return st
        if stt in ("failed", "error", "cancelled"):
            raise RuntimeError(str((st or {}).get("error_message") or st)[:500])
        time.sleep(1)
    raise TimeoutError(eid)


def all_rows(eid, page=5000):
    out, cols, n = [], None, 1
    while True:
        s, b, _ = c.call("GET", f"/api/executions/{eid}/results?page={n}&page_size={page}")
        # 2026-10-06 -- a failed page (server died mid-request, 404, 5xx) or
        # a pending/failed sentinel is UNKNOWN rows, never "no more rows".
        if s != 200 or not isinstance(b, dict):
            raise RuntimeError(f"results page {n} answered HTTP {s}: {str(b)[:300]}")
        if str(b.get("status") or "") in ("pending", "failed", "cancelled", "error"):
            raise RuntimeError(f"results page {n} says status={b.get('status')}: "
                               f"{str(b.get('error') or '')[:300]}")
        names = [x["name"] if isinstance(x, dict) else x for x in (b or {}).get("columns") or []]
        cols = cols or names
        rows = [(r if isinstance(r, dict) else dict(zip(names, r))) for r in (b or {}).get("rows") or []]
        if not rows:
            break
        out += rows
        if len(rows) < page:
            break
        n += 1
    return cols or [], out


def run_qs(route, sql, s3_conn):
    t0 = time.time()
    if route == "s3":
        s, b, _ = c.call("POST", "/api/execute", {"connection_id": s3_conn, "cache_strategy": "bypass", "raw_sql": sql})
    else:
        s, b, _ = c.call("POST", "/api/sql/execute", {"primary_connection_id": TRINO_CONN, "primary_sql": sql})
    if s != 200 or not (b or {}).get("execution_id"):
        raise RuntimeError(f"submit {s}: {str(b)[:400]}")
    wait(b["execution_id"])
    cols, rows = all_rows(b["execution_id"])
    return cols, rows, round(time.time() - t0, 1)


#: Columns that are VARCHAR in every source table.  2026-10-06: the S3 engine
#: returned the string partition `code` as the integer 83 -- a zero-padded
#: code ('007') would read as 7.  Value-normalised comparison hid it, so the
#: TYPE of these columns is checked on their own.
STRING_COLS = {"code", "business_event", "system_id", "sap_company_id", "source_data_set",
               "currency", "gl_account", "cost_centre", "profit_centre", "category", "region",
               "account_group", "division", "reporting_basis"}


def string_type_violations(rows):
    bad = []
    for r in rows:
        for k, v in r.items():
            if str(k).lower() in STRING_COLS and v is not None and not isinstance(v, str):
                bad.append((k, v))
    return bad[:5]


def summarise(cols, rows, mode):
    low = [{str(k).lower(): v for k, v in r.items()} for r in rows]
    if mode == "exact":
        return sorted(tuple((k, norm(v)) for k, v in sorted(r.items())) for r in low)
    out = {"rows": len(low)}
    for part in mode.split("+"):
        if part.startswith("sum:"):
            col = part[4:]
            out[col] = str(sum((Decimal(str(r[col])) for r in low if r.get(col) not in (None, "")), Decimal(0)).quantize(Decimal("0.01")))
        if part == "cols":
            out["cols"] = len(cols)
    return out


def truth_of(sql, mode):
    rows = trino(sql)
    cols = list(rows[0].keys()) if rows else []
    return summarise(cols, rows, mode)


def iceberg_location(table):
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--execute", f"show create table {CAT}{table}"],
                         capture_output=True, text=True).stdout
    m = re.search(r"location = 's3://[^/]+/([^']+)'", out)
    return m.group(1).rstrip("/") + "/" if m else None


def ensure_registered(bucket):
    """The aws-real S3 connection carries every table as a registered table."""
    s, b, _ = c.call("GET", "/api/connections")
    items = b if isinstance(b, list) else (b.get("items") or b.get("connections") or [])
    conn = next((x for x in items if x.get("name") == S3_CONN_NAME), None)
    if not conn:
        raise SystemExit(f"no connection named {S3_CONN_NAME}")
    reg = []
    for t in TABLES_ICEBERG:
        loc = iceberg_location(t)
        if not loc:
            raise SystemExit(f"no location for {t}")
        reg.append({"name": t, "s3_prefix": loc, "format": "iceberg", "description": f"Iceberg {t} (Trial Balance data product)",
                    "partition_columns": PART3 if t.startswith("fact_") else []})
        if t == "fact_tetb":
            reg.append({"name": "fact_tetb_pq", "s3_prefix": loc + "data/", "format": "parquet",
                        "description": "FACT_TETB data files as plain hive parquet (3-level paths)", "partition_columns": PART3})
    # the keys: the environment first (rig/rig.env on any machine), else ~/.qs_keys/aws.env
    env = {k: os.environ[k] for k in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION",
                                      "AWS_DEFAULT_REGION") if os.environ.get(k)}
    keys_file = os.path.expanduser("~/.qs_keys/aws.env")
    if not env.get("AWS_ACCESS_KEY_ID") and os.path.exists(keys_file):
        for line in open(keys_file, encoding="utf-8"):
            if "=" in line:
                k, v = line.strip().removeprefix("export ").split("=", 1)
                env[k] = v.strip().strip("'\"")
    region = env.get("AWS_REGION") or env.get("AWS_DEFAULT_REGION") or "us-east-2"
    # 2026-10-16: MERGE, never replace.  This PUT carried only this proof's
    # nine tables, so every other registration on the shared connection
    # (fact_tetb_month_end, which s3_to_s3 reads next) was wiped -- found when
    # the proofs ran in one sequence on a rig built from scratch.
    _, full, _ = c.call("GET", f"/api/connections/{conn['id']}")
    mine = {t["name"] for t in reg}
    kept = [t for t in (((full or {}).get("config") or {}).get("registered_tables") or [])
            if isinstance(t, dict) and t.get("name") not in mine]
    cfg = {"bucket_name": bucket, "region_name": region, "auth_mode": "keys",
           "aws_access_key_id": env["AWS_ACCESS_KEY_ID"], "aws_secret_access_key": env["AWS_SECRET_ACCESS_KEY"],
           "endpoint_url": "", "path_style": False, "ssl_verify": True, "registered_tables": kept + reg}
    s, b, _ = c.call("PUT", f"/api/connections/{conn['id']}", {"name": conn["name"], "connection_type": "s3", "config": cfg})
    check("the aws-real connection carries every table (Iceberg + the hive-parquet view)", s == 200,
          {"status": s, "tables": [r["name"] for r in reg], "body": "" if s == 200 else str(b)[:200]})
    return conn["id"]


def pruning(conn, bucket):
    loc = iceberg_location("fact_tetb")
    total = int(trino(f'select count(*) as n from {CAT}"fact_tetb$files"')[0]["n"])
    for label, flt, want in (
        ("COB", [{"column": "business_close_date", "operator": "=", "value": "2025-09-30"}], "files of that COB"),
        ("COB + code", [{"column": "business_close_date", "operator": "=", "value": "2025-09-30"},
                        {"column": "code", "operator": "=", "value": "1000"}], "8 (one per event)"),
        ("COB + event + code", [{"column": "business_close_date", "operator": "=", "value": "2025-09-30"},
                                {"column": "business_event", "operator": "=", "value": "BOOKING"},
                                {"column": "code", "operator": "=", "value": "1000"}], "1"),
    ):
        truth = int(trino(f'select count(*) as n from {CAT}"fact_tetb$files" where '
                          + " and ".join(f"partition.{f['column']} = " + (f"DATE '{f['value']}'" if f['column'] == 'business_close_date' else f"'{f['value']}'") for f in flt))[0]["n"])
        s, b, _ = c.call("POST", "/api/admin/queries/pruning-probe", {"connection_id": conn, "bucket": bucket,
                         "table_prefix": loc, "table_name": "fact_tetb", "filters": flt, "force_fresh": True})
        after = (b or {}).get("files_after_prune") if isinstance(b, dict) else None
        before = (b or {}).get("files_before_prune") if isinstance(b, dict) else None
        check(f"pruning on real S3, Iceberg FACT_TETB, {label}: files kept == the files that hold it ({truth} of {total})",
              s == 200 and after == truth and before == total, {"status": s, "before": before, "after": after, "truth": truth, "want": want,
                                                                 "body": "" if s == 200 else str(b)[:200]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--skip", default="")
    a = ap.parse_args()
    only = set(filter(None, a.only.split(",")))
    skip = set(filter(None, a.skip.split(",")))
    bucket = open(os.path.expanduser("~/.qs_keys/aws.env"), encoding="utf-8").read().split("QS_S3_BUCKET=")[1].split()[0].strip()
    if not only:
        conn = ensure_registered(bucket)
        pruning(conn, bucket)
    else:
        s, b, _ = c.call("GET", "/api/connections")
        items = b if isinstance(b, list) else (b.get("items") or b.get("connections") or [])
        conn = next(x["id"] for x in items if x.get("name") == S3_CONN_NAME)
    for qid, what, tmpl, mode in QUERIES:
        if (only and qid not in only) or qid in skip:
            continue
        truth = truth_of(tmpl.format(p=CAT), mode)
        for route, prefix in (("s3", ""), ("trino", CAT)):
            try:
                cols, rows, secs = run_qs(route, tmpl.format(p=prefix), conn)
                got = summarise(cols, rows, mode)
                timings.append((qid, route, secs))
                bad_types = string_type_violations(rows)
                check(f"{qid} [{route:<5}] {what} ({secs}s)", got == truth and not bad_types,
                      {"got": got if mode != "exact" else got[:6], "truth": truth if mode != "exact" else truth[:6],
                       "string_columns_returned_as_non_strings": bad_types})
            except Exception as exc:  # noqa: BLE001
                check(f"{qid} [{route:<5}] {what}", False, f"{type(exc).__name__}: {exc}")
    for qid, what, sql, tsql in PQ_QUERIES:
        if only and qid not in only:
            continue
        truth = truth_of(tsql, "exact")
        try:
            cols, rows, secs = run_qs("s3", sql.format(pq="fact_tetb_pq"), conn)
            check(f"{qid} [s3   ] {what} ({secs}s)", summarise(cols, rows, "exact") == truth,
                  {"got": summarise(cols, rows, "exact"), "truth": truth})
        except Exception as exc:  # noqa: BLE001
            check(f"{qid} [s3   ] {what}", False, f"{type(exc).__name__}: {exc}")
    print("\ntimings:", json.dumps(timings))
    print(f"{sum(res)}/{len(res)} PASSED" if all(res) else f"{res.count(False)} FAILED of {len(res)}")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
