"""FB-59 acceptance -- ONE ordinary SELECT against BOTH Spark-written tables.

The defect: the Spark JDBC writer handed Oracle the DataFrame's own column
names, and Spark's Oracle dialect QUOTES every identifier it is given, so a
table the job CREATED came out `"id","region",...` -- permanently
case-sensitive, and `SELECT REGION` raised ORA-00904 against it forever.

What this proves, and why it is shaped this way:

  * BOTH feeds write a table that DID NOT EXIST.  Table existence was the
    real variable (Spark adopts an existing target's spelling
    case-insensitively), so a proof into a pre-created table proves nothing.
    The tables are dropped first and their absence ASSERTED.
  * One feed reaches spark_k8s through the SIZE ROUTER, the other through a
    PER-FEED PIN, and each is required to carry ITS OWN reason string --
    `backend=spark_k8s` alone is produced by both, so it distinguishes
    nothing.
  * The acceptance query is ONE statement, textually identical apart from
    the table name, every identifier UNQUOTED -- the statement a consumer
    would actually write.  It must succeed against both and return the
    SAME VALUES, computed independently from the source.
  * Values, never row counts: region, distinct ids, the amount sum and the
    date range.  301,740 rows is also what a query that dropped the WHERE
    clause would produce on this source.
  * The comparison COUNT is asserted non-zero.  A loop over an empty set is
    vacuously true and this rig has printed "ALL MATCH" having compared
    nothing, twice.

Run from the HOST (the API is published on :8000)::

    python scripts/docker_proof/fb59_acceptance.py

What it leaves behind: nothing (2026-09-26).  The two feeds and the two
Oracle tables they wrote are recorded in a ledger and removed in a
``finally`` (a table that could not be dropped fails the run).  Leftovers
from runs before this::

    python scripts/docker_proof/fb59_acceptance.py --sweep-leftovers            # dry run
    python scripts/docker_proof/fb59_acceptance.py --sweep-leftovers --execute  # delete

matched only by this file's own name templates with the run-id shape in
place of the tag: feeds ``FB59A_(AUTO|PIN)_\\d{6}``, Oracle tables
``QS_FB59A_(AUTO|PIN)_\\d{6}``.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from proof_cleanup import (                                  # noqa: E402
    RUN_ID, Ledger, Rule, oracle_admin as _oracle_admin, oracle_table_remover,
    oracle_tables_like, sweep_flags, sweep_leftovers,
)

BASE = "http://127.0.0.1:8000"
API_CONTAINER = "qs-local-api"
TRINO_POD, ORACLE = 9, 8
TAG = str(int(time.time()))[-6:]
TRADES = ("SELECT id, region, amt, qty, dt FROM iceberg.qs.trades "
          "WHERE region = 'ASIA'")

RESULTS: list = []


def call(method, path, body=None, timeout=1800):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    import qs_docker_client as _c   # login-ON rig: the rig admin's session (2026-10-04)
    _t = None if path.startswith("/auth/") else _c._admin_token()
    if _t:
        req.add_header("Authorization", f"Bearer {_t}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw)
            except Exception:
                return r.status, raw[:600].decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        payload = e.read()
        try:
            return e.code, json.loads(payload)
        except Exception:
            return e.code, payload[:600].decode("utf-8", "replace")
    except Exception as e:                                   # noqa: BLE001
        return -1, {"transport_error": f"{type(e).__name__}: {e}"}


def _resolve_podreach():
    """TRINO_POD / ORACLE for the connections NAMED ``trino-podreach`` /
    ``oracle-otg-podreach`` (2026-10-16): the copies a Spark POD can reach
    (host.docker.internal + the published ports; rig/seed_rig.py makes them
    when the Spark cluster runs).  9 / 8 were the dev rig's ids; a rig built
    from scratch answered "Connection 8 not found".  Said when not found."""
    global TRINO_POD, ORACLE
    try:
        s, b = call("GET", "/api/connections?limit=1000", timeout=30)
        items = b if isinstance(b, list) else ((b or {}).get("items") or []) if isinstance(b, dict) else []
        ids = {c.get("name"): c.get("id") for c in items if isinstance(c, dict)}
        if ids.get("trino-podreach") and ids.get("oracle-otg-podreach"):
            TRINO_POD, ORACLE = int(ids["trino-podreach"]), int(ids["oracle-otg-podreach"])
        else:
            print(f"[fb59] no trino-podreach / oracle-otg-podreach connection (HTTP {s}) -- keeping ids "
                  f"{TRINO_POD} / {ORACLE}", file=sys.stderr)
    except Exception as exc:  # noqa: BLE001 -- said, never silent
        print(f"[fb59] podreach lookup failed ({exc}) -- keeping ids {TRINO_POD} / {ORACLE}", file=sys.stderr)


_resolve_podreach()


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + (f"\n        {detail}" if detail else ""), flush=True)
    return bool(ok)


def section(t):
    print("\n" + "=" * 78 + "\n" + t + "\n" + "=" * 78, flush=True)


def oracle_admin(statements):
    """DDL / catalog reads through the api container's own oracle client
    (proof_cleanup.oracle_admin).  /api/sql/execute is a query path;
    dropping a table and reading USER_TAB_COLUMNS is rig housekeeping, not
    part of what is under test.  Connection 3 is the in-network oracle-otg
    record; connection 8 is the same database under the name a POD can
    reach."""
    return _oracle_admin(statements, container=API_CONTAINER, connection_id=3)


def await_sql(submit_body, timeout=600):
    """Returns (rows, error).  `error` is the engine's own message, kept
    because ORA-00904 IS the defect's signature -- swallowing it would turn
    it into an empty result set, which reads as 'no data'."""
    if not isinstance(submit_body, dict) or not submit_body.get("execution_id"):
        return None, f"submit failed: {str(submit_body)[:300]}"
    eid = submit_body["execution_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        _, st = call("GET", f"/api/executions/{eid}/status")
        s = (st or {}).get("status")
        if s in ("completed", "success", "finished"):
            _, rb = call("GET", f"/api/executions/{eid}/results?page_size=100")
            return ((rb or {}).get("rows") or []), None
        if s in ("failed", "error", "cancelled"):
            return None, str((st or {}).get("error_message"))[:300]
        time.sleep(0.5)
    return None, "timed out"


ACCEPT_SQL = (
    "SELECT REGION, COUNT(DISTINCT ID) IDS, "
    "TO_CHAR(ROUND(SUM(AMT), 2), 'FM99999999999990.00') AMT_SUM, "
    "TO_CHAR(MIN(DT), 'YYYY-MM-DD') DT_MIN, "
    "TO_CHAR(MAX(DT), 'YYYY-MM-DD') DT_MAX "
    "FROM OTG.{table} GROUP BY REGION"
)


def accept(table):
    _, b = call("POST", "/api/sql/execute",
                {"primary_connection_id": ORACLE,
                 "primary_sql": ACCEPT_SQL.format(table=table),
                 "row_limit": 20})
    rows, err = await_sql(b)
    if err:
        return None, err
    out = {}
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        low = {str(k).lower(): v for k, v in r.items()}
        out[str(low.get("region"))] = (
            int(low.get("ids")), str(low.get("amt_sum")),
            str(low.get("dt_min")), str(low.get("dt_max")))
    return out, None


LEDGER = Ledger(call)


def make_feed(**body):
    body.setdefault("source_id", 0)
    s, b = call("POST", "/api/feeds", body)
    if s != 200 or not isinstance(b, dict):
        check(f"create feed {body.get('name')}", False, f"HTTP {s}: {str(b)[:300]}")
        return None
    fid = b.get("id")
    if fid:
        LEDGER.add("feed", str(body.get("name")), path=f"/api/feeds/{fid}")
        table = (body.get("destination_config") or {}).get("table")
        if table:
            # The feed WRITES this table -- it is this run's to drop.
            LEDGER.add("oracle table", table,
                       remover=oracle_table_remover(table, container=API_CONTAINER,
                                                    connection_id=3),
                       key=table)
    return fid


RULES = [
    Rule("feed", rf"FB59A_(AUTO|PIN)_{RUN_ID}",
         list_path="/api/feeds", delete_path="/api/feeds/{id}"),
    Rule("oracle table", rf"QS_FB59A_(AUTO|PIN)_{RUN_ID}",
         lister=lambda: oracle_tables_like("QS_FB59A_", container=API_CONTAINER,
                                           connection_id=3),
         remover=lambda t: oracle_table_remover(f"OTG.{t}", container=API_CONTAINER,
                                                connection_id=3)()),
]


def run_feed(feed_id, timeout=1800):
    s, b = call("POST", f"/api/feeds/{feed_id}/execute", {"trigger_type": "manual"})
    if s != 200:
        return {"status": f"execute_refused_{s}", "error_message": str(b)[:300]}
    dbid = b.get("execution_db_id")
    t0 = time.time()
    e = {}
    while time.time() - t0 < timeout:
        _, e = call("GET", f"/api/feed-executions/{dbid}")
        if isinstance(e, dict) and (e.get("status") or "") in (
                "completed", "failed", "cancelled", "error"):
            break
        time.sleep(2)
    # The row settles AFTER the status on the detached lanes -- the engine is
    # awaiting the job's own webhook and writes backend_choice a second or two
    # later.  Reading at the transition sees a half-written row and reports a
    # missing routing decision as a product defect.
    t1 = time.time()
    while time.time() - t1 < 60:
        _, e2 = call("GET", f"/api/feed-executions/{dbid}")
        if isinstance(e2, dict) and (e2.get("files_metadata") or {}).get("backend_choice"):
            return e2
        time.sleep(1)
    return e


def main(argv=None):
    sweep, execute, _rest = sweep_flags((argv or sys.argv)[1:])
    if sweep:
        return sweep_leftovers(call, RULES, execute=execute)
    try:
        proof()
    finally:
        section("CLEANUP -- what this run created, removed")
        _removed, left = LEDGER.cleanup(echo=lambda s: print("  " + s))
    bad = [n for n, ok, _ in RESULTS if not ok]
    if left:
        print(f"  CLEANUP LEFT {len(left)} OBJECT(S) ON THE RIG")
    return 1 if (bad or left) else 0


def proof():
    auto_t = f"QS_FB59A_AUTO_{TAG}"
    pin_t = f"QS_FB59A_PIN_{TAG}"

    section("0. both destination tables must NOT exist -- that is the variable")
    oracle_admin([f"DROP TABLE OTG.{auto_t} PURGE", f"DROP TABLE OTG.{pin_t} PURGE"])
    out = oracle_admin(["SELECT table_name FROM user_tables WHERE table_name IN "
                        f"('{auto_t}', '{pin_t}')"])
    check("neither table exists before the runs",
          auto_t not in out and pin_t not in out,
          f"{auto_t} / {pin_t} absent from user_tables")

    section("1. AUTO-routed -- the router chooses spark_k8s BY SIZE")
    fid = make_feed(name=f"FB59A_AUTO_{TAG}", source_type="raw_sql",
                    connection_id=TRINO_POD, output_format="parquet",
                    destination_type="oracle",
                    destination_config={"connection_id": ORACLE,
                                        "table": f"OTG.{auto_t}",
                                        "mode": "append"},
                    query_params={"sql": TRADES},
                    execution_backend="auto",
                    estimated_row_count=5_000_000)
    auto_e = run_feed(fid) if fid else {}
    auto_bc = ((auto_e.get("files_metadata") or {}).get("backend_choice") or {})
    check("AUTO reached spark_k8s, and the reason names the SIZE decision",
          auto_e.get("execution_backend") == "spark_k8s"
          and "auto_route_large_spark_k8s" in str(auto_bc.get("reason")),
          f"backend={auto_e.get('execution_backend')} reason={auto_bc.get('reason')!r}")
    check("AUTO run completed",
          auto_e.get("status") == "completed",
          f"status={auto_e.get('status')} err={str(auto_e.get('error_message'))[:200]}")

    section("2. PINNED -- the same lane reached by a per-feed pin")
    fid = make_feed(name=f"FB59A_PIN_{TAG}", source_type="raw_sql",
                    connection_id=TRINO_POD, output_format="parquet",
                    destination_type="oracle",
                    destination_config={"connection_id": ORACLE,
                                        "table": f"OTG.{pin_t}",
                                        "mode": "append"},
                    query_params={"sql": TRADES},
                    execution_backend="spark_k8s")
    pin_e = run_feed(fid) if fid else {}
    pin_bc = ((pin_e.get("files_metadata") or {}).get("backend_choice") or {})
    check("PINNED reached spark_k8s, and the reason names the PIN",
          pin_e.get("execution_backend") == "spark_k8s"
          and "per_feed" in str(pin_bc.get("reason")),
          f"backend={pin_e.get('execution_backend')} reason={pin_bc.get('reason')!r}")
    check("PINNED run completed",
          pin_e.get("status") == "completed",
          f"status={pin_e.get('status')} err={str(pin_e.get('error_message'))[:200]}")
    check("the two runs reached the lane by DIFFERENT routes",
          str(auto_bc.get("reason")) != str(pin_bc.get("reason"))
          and bool(auto_bc.get("reason")) and bool(pin_bc.get("reason")),
          f"auto={auto_bc.get('reason')!r}  pinned={pin_bc.get('reason')!r}")

    section("3. the identifiers Oracle actually holds")
    cols = oracle_admin(["SELECT table_name, column_id, column_name "
                         "FROM user_tab_columns WHERE table_name IN "
                         f"('{auto_t}', '{pin_t}') "
                         "ORDER BY table_name, column_id"])
    print(cols)
    want = ["ID", "REGION", "AMT", "QTY", "DT"]
    for t in (auto_t, pin_t):
        got = [ln.split("|")[-1].strip() for ln in cols.splitlines()
               if t in ln and "|" in ln]
        check(f"{t} carries canonical identifiers", got == want, f"columns={got}")

    section("4. ONE ordinary statement, every identifier UNQUOTED, against BOTH")
    print("  " + ACCEPT_SQL.format(table="<table>") + "\n")
    a_rows, a_err = accept(auto_t)
    p_rows, p_err = accept(pin_t)
    check(f"it runs against the AUTO-routed table {auto_t}",
          a_err is None and bool(a_rows), f"{a_err or a_rows}")
    check(f"it runs against the PINNED table {pin_t}",
          p_err is None and bool(p_rows), f"{p_err or p_rows}")

    section("5. and both answer with the SOURCE's own values")
    # Truth from the source itself, through Trino -- never from Oracle.
    _, b = call("POST", "/api/sql/execute", {
        "primary_connection_id": TRINO_POD,
        "primary_sql":
            "SELECT region, COUNT(DISTINCT id) ids, "
            "CAST(ROUND(SUM(amt), 2) AS VARCHAR) amt_sum, "
            "CAST(MIN(dt) AS VARCHAR) dt_min, CAST(MAX(dt) AS VARCHAR) dt_max "
            "FROM iceberg.qs.trades WHERE region = 'ASIA' GROUP BY region",
        "row_limit": 20})
    t_rows, t_err = await_sql(b)
    truth = {}
    for r in (t_rows or []):
        if not isinstance(r, dict):
            continue
        low = {str(k).lower(): v for k, v in r.items()}
        truth[str(low.get("region"))] = (
            int(low.get("ids")),
            f"{float(low.get('amt_sum')):.2f}",
            str(low.get("dt_min"))[:10], str(low.get("dt_max"))[:10])
    check("truth computed on the SOURCE is non-empty", bool(truth),
          f"{truth or t_err}")

    compared = 0
    agree = True
    for region, tval in truth.items():
        for label, got in (("auto", a_rows or {}), ("pinned", p_rows or {})):
            if region not in got:
                agree = False
                print(f"        {label}: region {region} MISSING")
                continue
            compared += 1
            if got[region] != tval:
                agree = False
                print(f"        {label} {region}: {got[region]} != source {tval}")
    check("every compared value agrees with the source",
          agree and compared >= 2,
          f"comparisons={compared} (must be >= 2)  source={truth}\n"
          f"        auto  ={a_rows}\n        pinned={p_rows}")

    section("RESULT")
    bad = [n for n, ok, _ in RESULTS if not ok]
    print(f"  {len(RESULTS) - len(bad)}/{len(RESULTS)} passed")
    for n in bad:
        print(f"  FAILED: {n}")


if __name__ == "__main__":
    sys.exit(main(sys.argv))
