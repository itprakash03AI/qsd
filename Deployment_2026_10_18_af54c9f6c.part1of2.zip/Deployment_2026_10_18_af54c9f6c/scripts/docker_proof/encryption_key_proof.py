"""ONE encryption key for every component -- a NEW SERVER with connections
already in the database, proven on the rig (2026-10-15).

The owner: "every component is searching the encryption key when we deploy
first time on a new server ... component pods are not getting up if some
connection is already created".  The database holds the rig's connections
and feeds, their credentials encrypted under the OLD server's key (kept off
the volume by the caller, path in QS_OLD_KEY_FILE).  Each scenario restarts
api, scheduler, executor, reports and published-api with the keys the api
chart's Secret would give them (compose overlay C:/tmp/keyproof.override.yml),
then checks FROM INSIDE EVERY COMPONENT:

  S1 new server, nothing supplied: every component UP, all on ONE key, the
     admin status names what cannot be read and the fix
  S2 the chart's way: a new key + the old server's key as PREVIOUS -> every
     component reads every stored credential; the start re-encrypted them
  S3 PREVIOUS removed: still every credential readable (rotated for good)
  S4 an upgrade from the file-based release: the old key FILE + a new key in
     the variable -> readable with no operator action, rotated
  S5 a share the pod cannot write, no key: NO KEY (status + log), never a
     throw-away key

The rig is left on the file-based key holding the last primary.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
REPO = os.path.dirname(os.path.dirname(HERE))
F = ["-f", "docker-compose.local.yml", "-f", "C:/tmp/a1.override.yml", "-f", "docker-compose.auth-rls.yml",
     "-f", "docker-compose.load-users.yml", "-f", "C:/tmp/pv2.override.yml", "-f",
     "C:/tmp/artifact.override.yml", "-f", "scripts/docker_proof/compose/tetb_real_e2e.override.yml",
     "-f", "C:/tmp/keyproof.override.yml"]
SERVICES = ["api", "scheduler", "executor", "reports", "published-api"]
CONTAINERS = ["qs-local-api", "qs-local-scheduler", "qs-local-executor", "qs-local-reports",
              "qs-local-published-api"]
CHECK = r'''
import json, sys
from sqlalchemy import text
from core import crypto
from core.database import DatabaseManager
from core.encryption_key_rotation import sweep
db = DatabaseManager()
rep = sweep(db, write=False)
with db.engine.connect() as c:
    rows = c.execute(text("select name, config from connections")).fetchall()
plain_ok = 0
for name, cfg in rows:
    cfg = json.loads(cfg) if isinstance(cfg, str) else (cfg or {})
    if any(str(v).startswith("enc::") for _, v in crypto._sensitive_paths(cfg)) and not crypto.undecryptable_fields(cfg):
        plain_ok += 1
print(json.dumps({"key": crypto.key_status(), "unreadable": len(rep["unreadable"]),
                  "needs_rotation": rep["rotated"], "current": rep["current"],
                  "connections_readable": plain_ok}))
'''
CHECKS = []
ENV = dict(os.environ, MSYS_NO_PATHCONV="1")


def check(name, ok, detail=""):
    CHECKS.append({"check": name, "ok": bool(ok), "detail": str(detail)[:500]})
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:500]}" if detail else ""), flush=True)


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, env=ENV, cwd=REPO, **kw)


def new_key():
    from cryptography.fernet import Fernet
    return Fernet.generate_key().decode()


def restart(primary="", previous=""):
    env = dict(ENV, QS_PROOF_KEY=primary, QS_PROOF_KEY_PREVIOUS=previous)
    for f in ("~/.qs_keys/rigpw.sh",):
        pass
    r = subprocess.run(["docker", "compose", "-p", "querystudio-local", *F, "--profile", "all", "up", "-d",
                        "--no-deps", "--force-recreate", *SERVICES], capture_output=True, text=True,
                       env=env, cwd=REPO)
    if r.returncode != 0:
        raise SystemExit("compose up failed: " + (r.stderr or r.stdout)[-800:])
    t0 = time.time()
    while time.time() - t0 < 600:
        st = {c: sh(["docker", "inspect", c, "--format", "{{.State.Health.Status}}"]).stdout.strip()
              for c in CONTAINERS}
        if all(s == "healthy" for s in st.values()):
            return st, round(time.time() - t0)
        time.sleep(5)
    return st, round(time.time() - t0)


def per_component():
    out = {}
    for c in CONTAINERS:
        sh(["docker", "cp", os.path.join(HERE, ".enc_check.py"), f"{c}:/tmp/enc_check.py"])
        r = sh(["docker", "exec", "-w", "/app", "-e", "PYTHONPATH=/app", c, "python", "/tmp/enc_check.py"])
        line = [ln for ln in r.stdout.splitlines() if ln.startswith("{")]
        out[c] = json.loads(line[-1]) if line else {"error": (r.stderr or r.stdout)[-300:]}
    return out


def status(token):
    import urllib.request
    req = urllib.request.Request("http://127.0.0.1:8000/api/admin/encryption-key",
                                 headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=300) as r:
        return json.loads(r.read())


def login():
    from auth_rls_proof import Session
    return Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"]).token


def file_key(value=None):
    """Read (or write) the shared key file through the api container."""
    if value is None:
        return sh(["docker", "exec", "qs-local-api", "cat", "/app/data/secret.key"]).stdout.strip()
    sh(["docker", "exec", "qs-local-api", "sh", "-c", f"printf %s '{value}' > /app/data/secret.key"])


def main():
    open(os.path.join(HERE, ".enc_check.py"), "w").write(CHECK)
    old = open(os.environ["QS_OLD_KEY_FILE"]).read().strip()

    # ── S1: new server, nothing supplied ─────────────────────────────────
    st, secs = restart()
    check("S1 every component is UP on a new server with connections already stored",
          all(s == "healthy" for s in st.values()), f"{st} in {secs}s")
    comp = per_component()
    fps = {c: v.get("key", {}).get("fingerprint") for c, v in comp.items()}
    check("S1 every component holds the SAME key", len(set(fps.values())) == 1 and None not in fps.values(), fps)
    s1 = status(login())
    check("S1 the admin status NAMES what cannot be read, with the fix",
          len(s1["stored"]["unreadable"]) > 0 and "QUERY_STUDIO_SECRET_KEY_PREVIOUS" in s1["stored"]["fix"],
          f"{len(s1['stored']['unreadable'])} records, e.g. "
          f"{[u.get('name') for u in s1['stored']['unreadable'][:3]]}")

    # ── S2: the chart's way -- a new key + the old server's key as previous ──
    chart_key = new_key()
    st, secs = restart(chart_key, old)
    check("S2 every component UP with the chart key + the old key as previous",
          all(s == "healthy" for s in st.values()), f"{st} in {secs}s")
    comp = per_component()
    check("S2 EVERY component reads EVERY stored credential",
          all(v.get("unreadable") == 0 for v in comp.values()),
          {c: (v.get("unreadable"), v.get("connections_readable")) for c, v in comp.items()})
    check("S2 the start re-encrypted them under the chart key (nothing left to rotate)",
          all(v.get("needs_rotation") == 0 for v in comp.values()),
          {c: v.get("needs_rotation") for c, v in comp.items()})
    check("S2 every component reports the chart key",
          {v["key"]["fingerprint"] for v in comp.values()} == {__import__("core.crypto", fromlist=["x"]).key_fingerprint(chart_key)},
          {c: v["key"]["source"] for c, v in comp.items()})

    # ── S3: previous removed -- still readable ─────────────────────────────
    st, secs = restart(chart_key, "")
    comp = per_component()
    check("S3 the old key removed: every component still reads every credential",
          all(s == "healthy" for s in st.values()) and all(v.get("unreadable") == 0 for v in comp.values()),
          {c: (v.get("unreadable"), v.get("connections_readable")) for c, v in comp.items()})

    # ── S4: an upgrade from the file-based release ─────────────────────────
    file_key(chart_key)                            # the release before: the key lived in the file
    upgraded = new_key()
    st, secs = restart(upgraded, "")              # the new chart brings a key in the variable
    comp = per_component()
    check("S4 an upgrade: the old key FILE is read with no operator action, and rotated",
          all(s == "healthy" for s in st.values())
          and all(v.get("unreadable") == 0 and v.get("needs_rotation") == 0 for v in comp.values())
          and all(any("key file" in p["source"] for p in v["key"]["previous"]) for v in comp.values()),
          {c: (v.get("unreadable"), [p["source"] for p in v["key"]["previous"]]) for c, v in comp.items()})

    # ── S5: a share the pod cannot write, no key -- ephemeral is SAID ──────
    r = sh(["docker", "run", "--rm", "--user", "1000700000:0", "-e", "QUERY_STUDIO_SECRET_KEY=",
            "-v", "qs-newserver-nfs:/app/data", "--entrypoint", "python", "querystudio-local-api:latest", "-c",
            "from core import crypto; print(crypto.key_status())"])
    # 2026-10-15 (later): never a throw-away key -- NO KEY, and a save refused
    check("S5 an unwritable share with no key: NO KEY said (never a throw-away key)",
          "'available': False" in r.stdout and "NO KEY" in r.stdout, (r.stdout or r.stderr)[-300:])

    # ── leave the rig on the file-based key, holding the current primary ──
    file_key(upgraded)
    st, secs = restart("", "")
    comp = per_component()
    check("rig restored: file-based key, every credential readable",
          all(v.get("unreadable") == 0 for v in comp.values()),
          {c: (v["key"]["source"], v.get("unreadable")) for c, v in comp.items()})
    path = os.path.join(HERE, "encryption-key-results.json")
    json.dump({"checks": CHECKS}, open(path, "w"), indent=1)
    bad = [c for c in CHECKS if not c["ok"]]
    print(f"\n{len(CHECKS) - len(bad)}/{len(CHECKS)} checks passed -> {path}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
