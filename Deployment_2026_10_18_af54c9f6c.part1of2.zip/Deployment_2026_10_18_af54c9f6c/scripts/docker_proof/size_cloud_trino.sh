#!/bin/sh
# Bound qs-trino's memory so the JVM fits its container (2026-10-11).
#
# qs-trino (the cloud Trino, trinodb/trino:latest, 5 GB cap) runs the image's
# default jvm.config: heap = 70% of the container and NO bound on direct
# (off-heap) memory, which the parquet reader and writer use.  A rung-1 CTAS
# of the owner's 75-column fact_tetb_ext at 20M rows took it past 5 GB and the
# kernel OOM-killed it.  This applies, idempotently:
#   jvm.config         -XX:MaxRAMPercentage=65 + -XX:MaxDirectMemorySize=512m
#   config.properties  task.concurrency=4  (fewer parallel row-group buffers)
#                      query.max-memory(-per-node)=$QS_CLOUD_TRINO_QUERY_MEM
#                      (default 1800MB; 2026-10-12: 2800MB in a 6 GB container
#                      for the owner's 460-column fact_tetb CTAS at 36M rows,
#                      which exceeded 1.76 GB per node)
#                      task.concurrency=$QS_CLOUD_TRINO_TASK_CONCURRENCY (4;
#                      1 for the 460-column scan: each parallel split holds a
#                      wide row group, 2.73 GB was still exceeded at 4)
#                      task.max-drivers-per-task=$QS_CLOUD_TRINO_MAX_DRIVERS
#                      (unset = engine default; 4 for the 460-column scan:
#                      the READER held 2.37 GB = one page source per parallel
#                      split; task.concurrency does not bound scan drivers)
# then restarts qs-trino (a restart, not a recreate: its networks, the
# hive_aws catalog and everything else in the container stay).
#
#     sh scripts/docker_proof/size_cloud_trino.sh
set -eu
C="${QS_CLOUD_TRINO:-qs-trino}"
QM="${QS_CLOUD_TRINO_QUERY_MEM:-1800MB}"
TC="${QS_CLOUD_TRINO_TASK_CONCURRENCY:-4}"
MD="${QS_CLOUD_TRINO_MAX_DRIVERS:-}"
docker exec -u root -e QM="$QM" -e TC="$TC" -e MD="$MD" "$C" sh -c '
set -eu
J=/etc/trino/jvm.config; P=/etc/trino/config.properties
sed -i "s/^-XX:MaxRAMPercentage=.*/-XX:MaxRAMPercentage=65/" "$J"
grep -q "^-XX:MaxDirectMemorySize=" "$J" || echo "-XX:MaxDirectMemorySize=512m" >> "$J"
if grep -q "^task.concurrency=" "$P"; then sed -i "s/^task.concurrency=.*/task.concurrency=$TC/" "$P"; else echo "task.concurrency=$TC" >> "$P"; fi
if [ -n "$MD" ]; then
  if grep -q "^task.max-drivers-per-task=" "$P"; then sed -i "s/^task.max-drivers-per-task=.*/task.max-drivers-per-task=$MD/" "$P"; else echo "task.max-drivers-per-task=$MD" >> "$P"; fi
fi
for k in query.max-memory query.max-memory-per-node; do
  if grep -q "^$k=" "$P"; then sed -i "s/^$k=.*/$k=$QM/" "$P"; else echo "$k=$QM" >> "$P"; fi
done
grep -E "MaxRAMPercentage|MaxDirectMemorySize" "$J"; grep -E "^task.concurrency|^task.max-drivers|^query.max-memory" "$P"
'
docker restart "$C" >/dev/null
i=0; until [ "$(docker inspect "$C" --format '{{.State.Health.Status}}')" = healthy ]; do
  i=$((i + 1)); [ $i -gt 60 ] && { echo "$C not healthy after restart" >&2; exit 1; }; sleep 5; done
echo "$C sized and healthy"
