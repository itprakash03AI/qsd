"""DECLARED vs EXERCISED -- the blind spot FB-58 came out of.

Every audit this project has run walks INSTANCES: it lists feeds, reports,
connections and drives what it finds.  A capability with ZERO instances is
invisible to all of them, and advertises itself as available the whole time.
The cross-source combine sat in exactly that hole for over a month.

So this walks the other way: start from the DECLARED vocabulary (the
registries the product ships) and ask, for each member, whether anything on
this rig has ever used it.

It reports three states, and the distinction matters:
  USED      an instance exists -- an audit that walks instances can see it
  UNUSED    declared, zero instances -- INVISIBLE to every existing sweep
  N/A       declared unavailable here by configuration, which is a decision

WHAT THIS DOES NOT MEASURE, and it matters: "USED" means an INSTANCE EXISTS,
not that the capability works.  A probe connection row makes its connector
type read USED while a real query against it may still be impossible.  This
tool finds the things no audit can SEE; proving they work is the audit's job
afterwards.

Run inside the api container -- it reads the shipped registries directly, so
it cannot drift from them the way a hand-maintained list would:

    docker cp scripts/docker_proof/capability_coverage.py qs-local-api:/tmp/cov.py
    docker exec qs-local-api python /tmp/cov.py
"""
import sys
sys.path.insert(0, "/app")
import json
import urllib.request

API = "http://localhost:8000"


def get(path):
    try:
        with urllib.request.urlopen(f"{API}{path}", timeout=120) as r:
            return json.load(r)
    except Exception:
        return None


def rows_of(body, *keys):
    if isinstance(body, list):
        return body
    for k in keys:
        v = (body or {}).get(k)
        if isinstance(v, list):
            return v
    return (body or {}).get("items") or []


REPORT = []


def _norm(x):
    """Compare vocabularies, not spellings.

    The file-format registry declares ".csv" while a feed stores "csv", and a
    naive compare reported 0/8 formats exercised -- my own instrument
    inventing a catastrophe. Normalise the leading dot and the case.
    """
    return str(x).strip().lower().lstrip(".")


def section(name, declared, used, na=()):
    declared = sorted({_norm(d) for d in declared if d})
    used = {_norm(u) for u in used if u}
    na = {_norm(n) for n in na if n}
    REPORT.append((name, declared, used, na))


# 2026-09-21 -- THREE OF THE SEVEN VOCABULARIES BELOW WERE THE WRONG
# REGISTRY.  An instrument that reads a registry cannot drift from it; one
# that reads the WRONG registry is confidently precise about something
# else.  What changed, and why each is the registry the PRODUCT uses:
#
#   feed output format  was core.file_formats (8 READ adapters: .parquet
#       .csv .tsv .txt .dat .xlsx .xls .json).  A feed's output_format is
#       resolved by core.feed.renderers.get_renderer, which knows FOUR
#       names (parquet csv json excel) and raises UnsupportedOutputFormat
#       on anything else.  So "6 unused formats" named five things a feed
#       cannot be, and MISSED `excel`, which really was never rendered.
#   report type         was a made-up {tabular, pivot, raw_sql,
#       parametric}.  `report_type` on /api/business-reports is DERIVED in
#       BusinessReport.to_list_dict as "pivot if layout_config says so
#       else tabular" -- a BINARY that can never hold the other two.  The
#       real per-report vocabulary is data_source_type, backed by the
#       registry in core/reports/sources.py, and it had THREE unused
#       members the old list could not see.
#   file read format    is now reported in its own right, against the
#       file-backed CONNECTIONS that use it, instead of being compared
#       with a feed's output.
#
# The lesson is the same one this whole instrument exists for: being
# systematic about the wrong set still leaves the gap open.

# ── 1. feed SOURCE types ───────────────────────────────────
try:
    from core.feed.steps import registered_names
    declared_src = list(registered_names("source"))
except Exception:
    declared_src = ["api", "landed_file", "published_view", "raw_sql",
                    "saved_query", "sql_file"]
feeds = rows_of(get("/api/feeds"), "feeds")
section("feed source type", declared_src,
        [f.get("source_type") for f in feeds]
        + [f.get("secondary_source_type") for f in feeds])

# ── 2. combine modes ────────────────────────────────────
section("feed combine mode", ["union", "join"],
        [f.get("combine_mode") for f in feeds])

# ── 3. execution backends ───────────────────────────────
# USED here means the EXECUTION ran on that backend, not that a feed row
# names it: `auto` is the column DEFAULT, so reading feed_configs alone
# would report it used the moment anyone saved a feed without choosing.
opts = get("/api/feeds/backend-options") or {}
declared_backends, na_backends = [], []
for o in (opts.get("options") or []):
    declared_backends.append(o.get("value"))
    if not o.get("available"):
        na_backends.append(o.get("value"))
used_backends = []
for f in feeds:
    used_backends.append(f.get("execution_backend"))
    for ex in rows_of(get(f"/api/feeds/{f.get('id')}/executions?limit=50"),
                      "executions"):
        used_backends.append(ex.get("execution_backend"))
        # the ROUTER's own reason is the only evidence `auto` decided
        _bc = ((ex.get("files_metadata") or {}).get("backend_choice") or {})
        if str(_bc.get("reason", "")).startswith("auto_route"):
            used_backends.append("auto")
section("feed execution backend", declared_backends, used_backends,
        na_backends)

# ── 4. feed OUTPUT formats -- core.feed.renderers, the registry
#    get_renderer() actually resolves against ─────────────────────
try:
    from core.feed.renderers import known_formats
    declared_fmt = list(known_formats())
except Exception:
    declared_fmt = ["csv", "parquet", "json", "excel"]
section("feed output format", declared_fmt,
        [f.get("output_format") for f in feeds])

# ── 5. connector types ─────────────────────────────────
try:
    from core.connectors import _REGISTRY as CONN
    declared_conn = list(CONN)
except Exception:
    declared_conn = []
conns = rows_of(get("/api/connections"), "connections")
section("connector type", declared_conn,
        [c.get("connection_type") for c in conns])

# ── 6. FILE READ formats -- core.file_formats, a SEPARATE vocabulary
#    from a feed's output: these adapters decide how a file-backed
#    connection's tables are READ ──────────────────────────────
try:
    from core.file_formats import _REGISTRY as FILEFMT
    declared_read = list(FILEFMT)
except Exception:
    declared_read = []
# The signal is the registered table's OWN `format` declaration (that is
# what the schema reader dispatches on), falling back to the extension of
# a declared path.  Stated plainly because it is narrower than the others:
# an adapter also serves file PREVIEWS and ad-hoc reads, which leave no
# row anywhere, so UNUSED here means "no registered table declares it",
# not "no code path ever opened one".
used_read = []
for c in conns:
    if str(c.get("connection_type")) not in ("s3", "local", "upload"):
        continue
    for t in ((c.get("config") or {}).get("registered_tables") or []):
        fmt = str(t.get("format") or "").strip()
        if fmt:
            used_read.append(fmt)
            continue
        path = str(t.get("path") or t.get("file")
                   or t.get("s3_prefix") or t.get("prefix") or "")
        if "." in path.rsplit("/", 1)[-1]:
            used_read.append(path.rsplit(".", 1)[-1])
section("file read format (as a REGISTERED TABLE declares it)",
        declared_read, used_read)

# ── 7. dataflow stage types ─────────────────────────────
# The catalogue already reports each stage's OWN runnable verdict, so a
# stage the product says cannot run in this image is N/A, not UNUSED --
# restating that judgement here would be the same decision made twice.
stage_types = rows_of(get("/api/dataflows/stage-types"), "stage_types", "types")
declared_stage, na_stage = [], []
for s_ in (stage_types or []):
    nm = s_.get("name") or s_.get("type") or s_.get("stage_type")
    if not nm:
        continue
    declared_stage.append(nm)
    if s_.get("runnable") is False:
        na_stage.append(nm)
flows = rows_of(get("/api/dataflows"), "dataflows")
used_stage = []
for fl in flows:
    detail = get(f"/api/dataflows/{fl.get('id')}") or fl
    for st in (detail.get("stages") or fl.get("stages") or []):
        used_stage.append(st.get("stage_type") or st.get("type"))
section("dataflow stage type", declared_stage, used_stage, na_stage)

# ── 8. business report SOURCE types ────────────────────────
# NOT `report_type`: that field is DERIVED as pivot-or-tabular and can
# never hold anything else.  This is the registry the executors are
# registered in, and "dataset" is an ALIAS that canonicalises to
# saved_query (core/reports/sources.py SOURCE_TYPE_ALIASES).
try:
    from core.reports.sources import _SOURCE_EXECUTORS, canonical_source_type
    declared_rep = list(_SOURCE_EXECUTORS)
except Exception:
    declared_rep = ["raw_sql", "saved_query", "federation_view",
                    "published_view"]

    def canonical_source_type(x):                    # noqa: F811
        return "saved_query" if x == "dataset" else x
reps = rows_of(get("/api/business-reports?limit=300"), "reports")
section("report source type", declared_rep,
        [canonical_source_type(r.get("data_source_type")) for r in reps])

# ── report ──────────────────────────────────────────────────────────────
print("=" * 78)
print("DECLARED vs EXERCISED on this rig")
print("=" * 78)
total_unused = 0
for name, declared, used, na in REPORT:
    if not declared:
        print(f"\n{name}: (could not read the declared set)")
        continue
    unused = [d for d in declared if d not in used and d not in na]
    na_only = [d for d in declared if d in na and d not in used]
    total_unused += len(unused)
    print(f"\n{name}  --  {len(declared) - len(unused) - len(na_only)}"
          f"/{len(declared)} exercised")
    for dcl in declared:
        low = _norm(dcl)
        state = ("USED  " if low in used else
                 "N/A   " if low in na else "UNUSED")
        flag = "" if state != "UNUSED" else "   <-- invisible to instance-walking audits"
        print(f"    {state}  {dcl}{flag}")

print("\n" + "=" * 78)
print(f"  TOTAL declared-but-never-instantiated: {total_unused}")
print("=" * 78)
