"""★ THE one place a connector failure becomes an HTTP answer.

2026-09-17.  ``main.py``'s CWE-209 chokepoint rewrites any 5xx that is not
explicitly shaped into *"Internal server error. Please contact support."*
That is correct -- leaking internals is the bug it exists to prevent -- but it
means a route that raises a bare 500 DESTROYS whatever the connector was
trying to say.  Three surfaces were measured doing exactly that on the same
day:

    GET /api/connections/5/tables        501  "...databricks-sql-connector is
                                               not installed..."
    GET /api/sql/connections/5/catalogs  500  "Internal server error. Please
                                               contact support."

Same connection, same missing driver, two answers, one of them useless.  The
second is the CQB schema browser, so in CQB an operator is told to contact
support about something they could fix with one ``pip install``, while the
other browser names the package.  ``DriverNotInstalled``'s own docstring says
this split is why the class exists -- and then only one of the two callers
was given the mapping.

The circuit breaker was the same shape with a worse ending.  It says, in the
log, *"This clears ITSELF: just run the query again in 45s; no admin action
is needed."*  The caller got "contact support" -- an actionable,
self-resolving condition rendered unactionable, and a support ticket for a
system that was about to fix itself.

So this module is not three patches; it is the answer to "what HTTP status
does this connector exception mean", asked once.  A route that grows a fourth
hand-written ``except Exception -> 500`` is the defect coming back.
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import HTTPException

logger = logging.getLogger(__name__)


def driver_not_installed_501(exc: BaseException, conn_type: str) -> HTTPException:
    """A missing driver is a CAPABILITY statement about this server.

    Not a fault in the request (4xx) and not an internal error (500): the
    server is fine and the request was reasonable, this deployment simply
    cannot do it.  501 is the precedent PDF export already set
    (``PdfRendererUnavailable`` -> 501) and the chokepoint lets it through
    with its detail, which is the whole point -- the detail names the pip
    package the operator installs.
    """
    return HTTPException(
        status_code=501,
        detail=f"This server cannot browse {conn_type} connections: {exc}",
    )


def circuit_open_503(exc: BaseException) -> HTTPException:
    """An open breaker is TEMPORARY and self-clearing -- 503 + Retry-After.

    The exception already carries ``retry_after`` and already explains that
    no admin action is needed.  Rendering that as a 500 threw away both the
    explanation and the machine-readable header a client would back off on.
    """
    retry = getattr(exc, "retry_after", None)
    headers = None
    try:
        if retry is not None and float(retry) >= 0:
            # Retry-After is an integer number of seconds; round UP so a
            # compliant client never retries a fraction of a second early
            # and trips the breaker again.
            headers = {"Retry-After": str(int(float(retry)) + 1)}
    except (TypeError, ValueError):
        headers = None
    return HTTPException(status_code=503, detail=str(exc), headers=headers)


def source_unavailable_503(exc: BaseException) -> HTTPException:
    """A source that could not be REACHED is a 503 with a Retry-After.

    FB-39 (2026-09-19): the breaker's sentence reached the caller as a 400
    (see ``core.connectors.base.SourceUnavailableError``).  Same shape as
    ``circuit_open_503``; the header is always present -- a machine client
    with a retry loop backs off on it, and the chokepoint keys on it to let
    the sentence through.
    """
    retry = getattr(exc, "retry_after", None)
    try:
        secs = int(float(retry)) + 1 if retry is not None and float(retry) >= 0 else 5
    except (TypeError, ValueError):
        secs = 5
    return HTTPException(status_code=503, detail=str(exc),
                         headers={"Retry-After": str(secs)})


def connector_http_error(exc: BaseException, conn_type: str = "",
                         *, context: str = "",
                         subject: str = "Browsing the {conn_type} source"
                         ) -> HTTPException:
    """Map a connector exception to the status that DESCRIBES it.

    Returns an ``HTTPException`` for the caller to ``raise``.  Anything this
    module has no opinion about becomes a 500 carrying ``context`` -- the
    behaviour those routes already had, so adopting this helper can only
    widen what survives the chokepoint, never narrow it.
    """
    # Imported lazily: this module is pulled in by API routers at import
    # time, and core.connectors drags in driver packages.
    try:
        from core.connectors.base import DriverNotInstalled
        if isinstance(exc, DriverNotInstalled):
            return driver_not_installed_501(exc, conn_type or "this")
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from core.circuit_breaker import CircuitOpenError
        if isinstance(exc, CircuitOpenError):
            return circuit_open_503(exc)
    except Exception:                                       # noqa: BLE001
        pass
    if _is_source_unavailable(exc):
        return source_unavailable_503(exc)
    # FB-40 (2026-09-19): the browse routes have no engine wrap site -- they
    # hand the RAW driver exception here.  A driver transient (Trino's
    # SERVER_STARTING_UP after a restart, a refused connect) fell through
    # to the 500 below and the chokepoint erased the sentence: six seconds
    # of "contact support" for a condition that clears itself.  ONE
    # classifier (core.connectors.base.is_transient_source_failure -- the
    # same one the execute path's wrap sites use) decides here too; only
    # the transient half is taken, so an internal fault (a TypeError in our
    # code) stays a 500 rather than becoming a 4xx carrying its text.
    try:
        from core.connectors.base import (
            is_source_verdict, is_transient_source_failure, source_verdict_status,
            wrap_source_failure,
        )
        if is_transient_source_failure(exc):
            return source_unavailable_503(wrap_source_failure(exc, conn_type or "sql"))
        if is_source_verdict(exc):
            # FB-40b: the DRIVER judged the statement (SCHEMA_NOT_FOUND,
            # ORA-00942) -- the request was unprocessable at the source, so
            # a 400 carrying the source's sentence (the FB-29 browse and the
            # execute path's SourceStatementError already answer this way)
            # instead of a 500 the chokepoint erases.  Our own faults do not
            # take this branch: a TypeError is no PEP-249 class.
            # 2026-10-10: a verdict on the caller's RIGHT (Trino "Access
            # Denied: Cannot set role ...") is 403 -- the ONE status rule,
            # ``source_verdict_status``; 400 stands for every other verdict.
            return HTTPException(
                status_code=source_verdict_status(exc) or 400,
                detail=str(wrap_source_failure(
                    exc, conn_type or "sql", subject=subject)))
    except Exception:                                       # noqa: BLE001
        pass
    prefix = f"{context}: " if context else ""
    return HTTPException(status_code=500, detail=f"{prefix}{exc}")


def refusal_status(exc: BaseException, default: int) -> int:
    """The status a route that answers a ``ValueError`` itself (422 on an
    execute, 400 on the report route) gives ``exc``: the verdict's own
    status when the source judged the caller's RIGHT (403, carried on
    ``SourceStatementError.http_status`` -- or decided here for a raw
    exception), else the route's ``default``.  Same decision as
    ``connector_http_error``'s verdict branch: ``source_verdict_status``."""
    own = getattr(exc, "http_status", None)
    if isinstance(own, int) and own:
        return own
    try:
        from core.connectors.base import source_verdict_status
        return source_verdict_status(exc) or default
    except Exception:                                       # noqa: BLE001
        return default


def _is_circuit_open(exc: BaseException) -> bool:
    try:
        from core.circuit_breaker import CircuitOpenError
        return isinstance(exc, CircuitOpenError)
    except Exception:                                       # noqa: BLE001
        return False


def _is_source_unavailable(exc: BaseException) -> bool:
    try:
        from core.connectors.base import SourceUnavailableError
        return isinstance(exc, SourceUnavailableError)
    except Exception:                                       # noqa: BLE001
        return False



def raise_if_source_error(exc: BaseException, conn_type: str = "",
                          *, context: str = "",
                          subject: str = "Browsing the {conn_type} source") -> None:
    """Consult the seam FIRST; raise when it has an opinion, return otherwise.

    FB-41 (2026-09-19) -- closing the CLASS.  FB-39 (execute), FB-40 (browse
    transients) and FB-41 (browse refusals) were three findings in a row
    on routes the previous fix did not claim, because every route that
    calls a connector and catches ``Exception`` wrote its own answer.  The
    one classifier (core.connectors.base: transient -> 503 + Retry-After;
    the driver's verdict -> 400 with its sentence; a missing driver ->
    501; an open breaker -> 503) is asked here first, and a route keeps
    its own 500 only for the residue the classifier has no opinion about
    -- which is the honest residue.  ``tests/test_fb41_...`` walks every
    connector-calling handler in api/ and fails when one raises a 5xx
    without consulting the seam.

    ``subject`` names what failed in the 400's sentence (2026-10-05: an
    EXECUTE path says "The statement sent to the trino source failed: ...",
    not "Browsing ...").
    """
    raise_if_caller_filter_error(exc)
    compile_error = _query_compile_error(exc)
    if compile_error is not None:
        # Edge-case sweep 2026-09-24: the compiler REFUSES a filter it cannot
        # render (an empty IN list, reversed BETWEEN bounds, ...) with a
        # sentence written for the person who sent it -- QueryCompileError's
        # own docstring says "surfaced to the UI".  Nothing mapped it: routes
        # wrapped it in a 500 and the global sanitizer replaced the sentence
        # with "Internal server error".  Failing closed was right; hiding WHY
        # was not.  It is the caller's input, so it is a 400 with the sentence.
        raise HTTPException(status_code=400, detail=str(compile_error))
    h = connector_http_error(exc, conn_type, context=context, subject=subject)
    if h.status_code != 500:
        raise h


def _query_compile_error(exc: BaseException):
    """The QueryCompileError in ``exc``'s cause chain, or None."""
    from core.query_compiler import QueryCompileError
    seen = set()
    cur: Optional[BaseException] = exc
    while cur is not None and id(cur) not in seen:
        if isinstance(cur, QueryCompileError):
            return cur
        seen.add(id(cur))
        cur = cur.__cause__ or cur.__context__
    return None


#: The scan REFUSALS a caller can act on: the server declined to read this
#: much, and the sentence names how many, the ceiling and the remedy.  By
#: (module, class) NAME so this module imports nothing heavy at load time.
SCAN_REFUSAL_TYPES = (
    ("core.duckdb_subprocess", "PresignedDownloadRefusal"),
    ("core.scan_truncation", "ScanBudgetRefusal"),
    ("core.scan_truncation", "TruncatedScanRefusal"),
    # 2026-10-25 -- an Iceberg merge-on-read refusal: the table has delete
    # files this road could not apply (unreadable delete manifest, a delete
    # file that could not be resolved, MoR disabled).  Serving the rows would
    # be the DELETED rows as data; the sentence names the table, the count
    # and the knob (iceberg_mor.enabled / allow_stale_reads).  422, as every
    # other "well-formed request the server refuses to carry out as stated".
    ("core.iceberg_mor", "MorDeletesUnresolvableError"),
    ("core.iceberg_mor", "MorDeleteCollectionError"),
    ("core.iceberg_mor", "MorDisabledWithDeletesError"),
    # 2026-10-29 -- a typed s3:// path on an on-prem (presigned) connection: the
    # path cannot be read there; the sentence names the registered table to use.
    ("core.s3_access", "S3PathOnPresignedRefusal"),
)

#: The status a scan refusal answers with.  422, not 413 and not 400:
#: 413 is "Content Too Large" -- the request CONTENT (RFC 9110 §15.5.14),
#: and the request here is a GET with no body; a proxy or client reads 413
#: as "your upload is too big".  400 says the request is malformed, and it
#: is not.  422 (§15.5.21) is a well-formed request whose instructions the
#: server cannot carry out as stated -- exactly "this query would read N
#: files over the cap of M; narrow it".  Not 5xx: nothing is broken, and a
#: retry of the same request refuses again (so no Retry-After either).
SCAN_REFUSAL_STATUS = 422


def scan_refusal_in(exc: Optional[BaseException]) -> Optional[BaseException]:
    """The declared scan refusal in ``exc``'s cause chain, or None.

    Walks ``__cause__`` / ``__context__``: the executors wrap engine
    failures (``raise RuntimeError(f"S3 query failed: {e}") from e``), and a
    refusal found only at the top would be lost by the first wrap.
    """
    import sys as _sys
    classes = []
    for mod_name, cls_name in SCAN_REFUSAL_TYPES:
        mod = _sys.modules.get(mod_name)
        cls = getattr(mod, cls_name, None) if mod is not None else None
        if isinstance(cls, type):
            classes.append(cls)
    if not classes:
        return None                 # no refusal type was ever loaded -> none raised
    seen = set()
    cur = exc
    while cur is not None and id(cur) not in seen:
        if isinstance(cur, tuple(classes)):
            return cur
        seen.add(id(cur))
        cur = cur.__cause__ or cur.__context__
    return None


def scan_refusal_http_error(exc: BaseException) -> Optional[HTTPException]:
    """THE HTTP answer to a scan refusal: 422 carrying its sentence.

    2026-10-02.  ``Presigned pre-download would fetch 7308 files; cap is
    200.  Narrow the query ...`` reached a published-API consumer as ``500
    "Internal server error ... contact support"`` -- a remedy the caller
    could apply, replaced by a support ticket.  The sentence holds counts,
    the ceiling and the name of the knob; nothing of the query's internals.
    """
    refusal = scan_refusal_in(exc)
    if refusal is None:
        return None
    return HTTPException(status_code=SCAN_REFUSAL_STATUS, detail=str(refusal))


def raise_if_refused(exc: BaseException) -> None:
    """Raise the 422 when ``exc`` carries a scan refusal; return otherwise."""
    h = scan_refusal_http_error(exc)
    if h is not None:
        logger.warning("Scan refused -- answering %d with its remedy: %s",
                       h.status_code, h.detail)
        raise h


def caller_filter_error_in(exc: Optional[BaseException]) -> Optional[BaseException]:
    """The ``core.sql_filter_wrapper.FilterWrapError`` in ``exc``'s cause
    chain, or None.

    2026-10-05.  A filter that cannot be rendered into SQL -- a value that is
    not of its column's type (``FilterValueRefused``: ``?dt=15/03/1995`` on a
    DATE column), an empty IN list, an unsupported operator -- REFUSES rather
    than being dropped (a dropped filter returns MORE rows).  The refusal is
    the caller's to fix and its sentence names the column, the type and the
    accepted formats; nothing mapped it, so on the published API it reached
    the consumer as 500 "Query execution failed".
    """
    import sys as _sys
    mod = _sys.modules.get("core.sql_filter_wrapper")
    cls = getattr(mod, "FilterWrapError", None) if mod is not None else None
    if not isinstance(cls, type):
        return None                 # never imported -> never raised
    seen = set()
    cur = exc
    while cur is not None and id(cur) not in seen:
        if isinstance(cur, cls):
            return cur
        seen.add(id(cur))
        cur = cur.__cause__ or cur.__context__
    return None


def raise_if_caller_filter_error(exc: BaseException) -> None:
    """Raise 400 with the sentence when ``exc`` carries a filter refusal."""
    refusal = caller_filter_error_in(exc)
    if refusal is not None:
        raise HTTPException(status_code=400, detail=str(refusal))


def failure_status(exc: BaseException) -> int:
    """The status a generic-500 lane answers ``exc`` with: 400 for a filter
    that cannot be rendered, 422 for a scan refusal, 503 for a self-clearing
    condition, else 500.  For the caller that must record the status BEFORE
    it raises (the published-view access log) -- one decision, so the log
    and the response cannot disagree."""
    if caller_filter_error_in(exc) is not None:
        return 400
    if scan_refusal_in(exc) is not None:
        return SCAN_REFUSAL_STATUS
    if is_self_clearing(exc):
        return 503
    return 500


def raise_if_self_clearing(exc: BaseException) -> None:
    """Re-raise as 503 when ``exc`` is a TEMPORARY, self-resolving condition.

    2026-10-02 -- and as 422 when it is a SCAN REFUSAL (``raise_if_refused``),
    checked first.  Both are conditions the CALLER can act on (wait; narrow
    the query), and every lane that answers a deliberately generic 500 calls
    this one function before it, so a refusal is mapped once, here, rather
    than at each of those routes.

    For the routes that deliberately answer a generic 500 -- the published-view
    execute paths, where leaking a query's internals to an external consumer
    IS the thing CWE-209 is about.  That default is right, and an open circuit
    breaker is the exception to it: it is not an internal detail, it is an
    operational state with a known duration, and its message was written for
    the person who sees it ("This clears ITSELF: just run the query again in
    45s; no admin action is needed").

    Measured 2026-09-17: that sentence was in the log and the caller got
    "Internal server error. Please contact support." -- a support ticket for
    a system that was about to fix itself.

    Returns (does nothing) for anything else, so the caller's generic answer
    still applies.

    2026-10-05 -- a filter that cannot be rendered (``caller_filter_error_in``)
    is a 400 with its sentence, checked first: the request named a value the
    column cannot hold, and every generic-500 lane reaches this function.
    """
    raise_if_caller_filter_error(exc)
    raise_if_refused(exc)
    if _is_source_unavailable(exc):
        # FB-39: a source that could not be reached, classified at the wrap
        # site -- the breaker's countdown or the default back-off.
        logger.warning("Source unavailable — answering 503 with Retry-After: %s", exc)
        raise source_unavailable_503(exc)
    try:
        from core.connectors.base import is_transient_source_failure, wrap_source_failure
        if is_transient_source_failure(exc) and not _is_circuit_open(exc):
            # FB-40: a raw driver transient reaching a lane with no wrap site.
            logger.warning("Source transient — answering 503 with Retry-After: %s", exc)
            raise source_unavailable_503(wrap_source_failure(exc, "sql"))
    except HTTPException:
        raise
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from core.circuit_breaker import CircuitOpenError
    except Exception:                                       # noqa: BLE001
        return
    if isinstance(exc, CircuitOpenError):
        logger.warning("Circuit open — answering 503 with Retry-After: %s", exc)
        raise circuit_open_503(exc)
def is_self_clearing(exc: BaseException) -> bool:
    """True when ``exc`` is a temporary condition that resolves on its own.

    Split out from :func:`raise_if_self_clearing` for the one caller that must
    DECIDE the status before it acts on it -- the published-view access log is
    written before the response is raised, and a log saying 500 next to a
    response saying 503 is two answers to one question.
    """
    if _is_source_unavailable(exc):
        return True
    try:
        from core.circuit_breaker import CircuitOpenError
        if isinstance(exc, CircuitOpenError):
            return True
    except Exception:                                       # noqa: BLE001
        pass
    # FB-40: a RAW driver transient (no wrap site on the browse routes) is
    # self-clearing too -- the same classifier, not a second list.
    try:
        from core.connectors.base import is_transient_source_failure
        return bool(is_transient_source_failure(exc))
    except Exception:                                       # noqa: BLE001
        return False
