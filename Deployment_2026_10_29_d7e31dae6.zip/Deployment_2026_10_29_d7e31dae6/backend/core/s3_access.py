"""ONE resolver for how QueryStudio reaches an S3 object store.

Every question of the form "given THIS connection, how do we read THAT
s3:// URL" is answered here and nowhere else:

  * which ENDPOINT (host for DuckDB, URL for boto3), VPCE-normalised;
  * whether the endpoint is plain HTTP (``s3_use_ssl``);
  * PATH or virtual-hosted addressing (``s3_url_style``);
  * which REGION the requests are signed for;
  * NATIVE (DuckDB httpfs signs each request itself) or PRESIGNED (the
    parent signs URLs with boto3 and DuckDB reads plain HTTPS / the child
    pre-downloads them);
  * which CREDENTIALS travel with the read;
  * whether the corporate PROXY applies to this endpoint.

Why this exists -- F2 of ``docs/FABLE_BRIEF_2026_09_26.html``, found live on
the Docker rig 2026-09-25.  ``files=["__registered__:big"]`` on the MinIO
connection (``http://qs-minio:9000``, path-style) reached MinIO.  The same
data as ``files=["s3://qs-data/big/region=AMER/data.parquet"]`` passed
validation (which is endpoint-aware) and ran on the GENERIC branch of
``api/execute_api.py`` (``BRANCH=0_other``), whose DuckDB child read
``https://qs-data.s3.amazonaws.com/...`` -- real AWS -- and failed 403 after
~30 s, twice, tripping the connection's circuit breaker for every user.

The mechanism: a path-style connection resolves to ``access_mode=presigned``,
so the child takes the LOCAL_FILES plan (``core/duckdb_s3_plan.py``): no
httpfs configuration, no endpoint, on the promise that the PARENT presigned
every URL.  The registered branch keeps that promise; the generic branch
shipped raw ``s3://`` in ``copy_sql``, DuckDB autoloaded httpfs and signed
for its DEFAULT host.  Ten modules each re-derived some part of the endpoint
decision (``SET s3_endpoint`` / ``s3_url_style`` / ``USE_SSL`` /
``ENDPOINT`` in a SECRET / a settings dict for remote workers), all with
slightly different rules -- one forced path-style on every custom endpoint,
one only on ``http://``, one never.  A decision made ten times is ten
answers.  Now there is one ``S3Access`` and every site consumes its fields.

WHAT THIS MODULE DOES NOT DO.  It does not ACQUIRE credentials: the
credential chokepoint is ``core/credential_resolver.resolve_s3_credentials``
(portal / assume_role / profile / system account), and a caller that has to
run STS in its own process (the DuckDB child) hands the result in through
``credentials=``.  It does not decide the pre-download / VPC-rewrite
STRATEGY once the SQL exists: that remains ``core/duckdb_s3_plan.py``, which
reads the SQL for already-presigned URLs.  The two compose: this module
decides the connection's shape, the planner decides what the SQL already
carries.

Guarded by ``tests/test_one_s3_access_resolver_2026_09_26.py``: no other
production module may emit ``SET s3_endpoint`` / ``s3_url_style`` /
``s3_use_ssl`` / ``URL_STYLE`` / ``ENDPOINT '`` or read
``default_onprem_access_mode``.
"""
from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

NATIVE = "native"
PRESIGNED = "presigned"
PATH_STYLE = "path"
VIRTUAL_STYLE = "virtual"

#: File extensions the generic branch treats as ONE file; anything else
#: named by an ``s3://`` URL is a PREFIX to be listed.
_FILE_EXTENSIONS = (".parquet", ".csv", ".json", ".jsonl", ".xlsx", ".xls", ".tsv")


def access_mode_for(conn_config: dict) -> str:
    """NATIVE or PRESIGNED for this connection -- the presign-vs-native decision.

    * an explicit ``s3_access_mode`` on the connection wins;
    * an AWS VPC interface endpoint is forced NATIVE -- a URL presigned for
      ``s3.amazonaws.com`` and sent to a ``vpce-*`` host fails the Host
      check (403 SignatureDoesNotMatch), so the boto3 pre-download path,
      which signs for the real host, is the one that works (2026-06-18);
    * AWS S3 (no path-style) is NATIVE: httpfs works;
    * on-prem S3 (path-style) defaults to ``s3.default_onprem_access_mode``
      (``presigned``): boto3 pre-signs, which sidesteps httpfs URL-encoding
      ``=`` to ``%3D`` in hive partition paths (SignatureDoesNotMatch).

    ``core.s3_utilities.get_s3_access_mode`` is an alias of this function
    kept for its callers and patch targets.
    """
    conn_config = conn_config or {}
    explicit = conn_config.get("s3_access_mode")
    if explicit in (NATIVE, PRESIGNED):
        return explicit
    try:
        from core.ssl_config import is_vpc_endpoint_url
        if is_vpc_endpoint_url(conn_config.get("endpoint_url")
                               or conn_config.get("endpoint")):
            return NATIVE
    except Exception:
        pass
    if not conn_config.get("path_style", False):
        return NATIVE
    try:
        from core.config import s3 as _s3_cfg
        mode = str(_s3_cfg.default_onprem_access_mode or "").strip().lower()
        return mode if mode in (NATIVE, PRESIGNED) else PRESIGNED
    except Exception:
        return PRESIGNED


def _esc(v: Any) -> str:
    return str(v).replace("'", "''")


@dataclass(frozen=True)
class S3Access:
    """The resolved shape of one S3 connection.  Fields are orthogonal:
    a consumer reads the ones it needs and never re-derives another."""

    connection_id: Optional[int]
    #: VPCE-normalised endpoint WITH scheme; "" for AWS's default endpoint.
    endpoint_url: str
    #: ``host[:port]`` for DuckDB ``SET s3_endpoint`` / ``ENDPOINT``; "" for AWS.
    endpoint_host: str
    #: True when no custom endpoint is configured, or it is AWS-owned.
    is_aws: bool
    use_ssl: bool
    url_style: str          # PATH_STYLE | VIRTUAL_STYLE
    region: str
    access_mode: str        # NATIVE | PRESIGNED
    key: str
    secret: str
    token: str
    #: DuckDB ``SET http_proxy*`` statements for THIS endpoint ([] = direct).
    proxy_statements: Tuple[str, ...]
    reason: str

    # ── properties ────────────────────────────────────────────────────
    @property
    def presigns(self) -> bool:
        return self.access_mode == PRESIGNED

    @property
    def has_custom_endpoint(self) -> bool:
        return bool(self.endpoint_host)

    # ── DuckDB: SET statements ────────────────────────────────────────
    def duckdb_statements(self, *, credentials: bool = True,
                          endpoint: bool = True, proxy: bool = False) -> List[str]:
        """The ``SET`` statements that point a DuckDB httpfs session at this
        connection.  Region is always set (an omitted region made DuckDB
        default to us-east-1 -- the AuthorizationHeaderMalformed class).
        ``credentials=False`` for a session that must not sign (presigned
        URLs already in the SQL); ``endpoint=False`` likewise."""
        stmts: List[str] = []
        if proxy:
            stmts.extend(self.proxy_statements)
        if credentials:
            if self.key:
                stmts.append(f"SET s3_access_key_id='{_esc(self.key)}';")
            if self.secret:
                stmts.append(f"SET s3_secret_access_key='{_esc(self.secret)}';")
            if self.token:
                stmts.append(f"SET s3_session_token='{_esc(self.token)}';")
        stmts.append(f"SET s3_region='{_esc(self.region)}';")
        if endpoint and self.endpoint_host:
            stmts.append(f"SET s3_endpoint='{_esc(self.endpoint_host)}';")
            if not self.use_ssl:
                stmts.append("SET s3_use_ssl=false;")
            if self.url_style == PATH_STYLE:
                stmts.append("SET s3_url_style='path';")
        return stmts

    def apply_to_duckdb(self, con, *, credentials: bool = True,
                        endpoint: bool = True, proxy: bool = False) -> List[str]:
        """Execute :meth:`duckdb_statements` on ``con`` (httpfs must already
        be loaded -- the ``s3_*`` settings do not exist before it).  Returns
        the statements executed."""
        stmts = self.duckdb_statements(credentials=credentials,
                                       endpoint=endpoint, proxy=proxy)
        for s in stmts:
            con.execute(s)
        return stmts

    # ── DuckDB: CREATE SECRET parameters ──────────────────────────────
    def duckdb_secret_params(self, *, scope_bucket: Optional[str] = None,
                             credentials: bool = True) -> List[str]:
        """Parameter list for ``CREATE SECRET <name> (<params>)`` -- the
        multi-endpoint form federation uses so two S3 connections can live
        in one session."""
        params = ["TYPE S3"]
        if credentials:
            if self.key:
                params.append(f"KEY_ID '{_esc(self.key)}'")
            if self.secret:
                params.append(f"SECRET '{_esc(self.secret)}'")
            if self.token:
                params.append(f"SESSION_TOKEN '{_esc(self.token)}'")
        params.append(f"REGION '{_esc(self.region)}'")
        if self.endpoint_host:
            params.append(f"ENDPOINT '{_esc(self.endpoint_host)}'")
            if not self.use_ssl:
                params.append("USE_SSL false")
            if self.url_style == PATH_STYLE:
                params.append("URL_STYLE 'path'")
        if scope_bucket:
            params.append(f"SCOPE 's3://{_esc(scope_bucket)}'")
        return params

    # ── remote workers: a settings dict ───────────────────────────────
    def duckdb_settings(self, *, credentials: bool = True,
                        endpoint: bool = True) -> Dict[str, Any]:
        """The same decision as a ``{setting: value}`` dict for the
        multi-worker dispatcher (strings are quoted by the executor,
        booleans emitted bare -- DuckDB rejects ``SET s3_use_ssl='false'``)."""
        out: Dict[str, Any] = {"s3_region": self.region}
        if credentials:
            if self.key:
                out["s3_access_key_id"] = self.key
            if self.secret:
                out["s3_secret_access_key"] = self.secret
            if self.token:
                out["s3_session_token"] = self.token
        if endpoint and self.endpoint_host:
            out["s3_endpoint"] = self.endpoint_host
            if not self.use_ssl:
                out["s3_use_ssl"] = False
            if self.url_style == PATH_STYLE:
                out["s3_url_style"] = "path"
        return out

    # ── Spark: the s3a identity of ONE bucket ─────────────────────────
    def s3a_identity(self) -> Dict[str, Any]:
        """The block a Spark lane sets as ``fs.s3a.bucket.<bucket>.*`` (the
        spark_k8s read plan and artifact store, the Spark Connect session):
        the VPCE-normalised endpoint URL, THE region, path-style as decided
        here, and the keys that travel.  2026-10-26: the Spark sites read
        ``region_name or region`` off the config (so a saved Region that
        contradicts the endpoint reached the pod while DuckDB signed with
        the endpoint's) and took "any endpoint = path-style" as their own
        rule."""
        return {
            "endpoint": self.endpoint_url,
            "region": self.region,
            "path_style": self.url_style == PATH_STYLE,
            "access_key_id": self.key,
            "secret_access_key": self.secret,
            "session_token": self.token,
        }

    # ── boto3: client kwargs ──────────────────────────────────────────
    def boto3_client_kwargs(self, conn_config: Optional[dict] = None, *,
                            credentials: bool = True,
                            config_kwargs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """``boto3.client(**kwargs)`` for THIS connection: region, the
        VPCE-normalised endpoint, the keys, TLS verify from the ONE ssl
        resolver, and a ``botocore.config.Config`` carrying SigV4 + the
        addressing style (``build_boto3_s3_config_kwargs``) merged with the
        caller's ``config_kwargs`` (timeouts, pool size, retries).  For the
        boto3 sites that cannot use the cached handler (a worker's listing
        with its own timeouts, the footer prewarm with its own pool)."""
        from botocore.config import Config as BotoConfig
        from core.s3_storage import build_boto3_s3_config_kwargs
        from core.ssl_config import as_boto3_verify, resolve_ssl
        cfg = dict(conn_config or {})
        merged: Dict[str, Any] = dict(config_kwargs or {})
        merged.update(build_boto3_s3_config_kwargs({
            "addressing_style": cfg.get("addressing_style"),
            "path_style": cfg.get("path_style", False),
            "endpoint_url": self.endpoint_url or cfg.get("endpoint_url") or cfg.get("endpoint"),
        }))
        out: Dict[str, Any] = {
            "service_name": "s3",
            "region_name": self.region,
            "verify": as_boto3_verify(resolve_ssl(cfg.get("ssl_verify", True))),
            "config": BotoConfig(**merged),
        }
        if self.endpoint_url:
            out["endpoint_url"] = self.endpoint_url
        if credentials:
            if self.key:
                out["aws_access_key_id"] = self.key
            if self.secret:
                out["aws_secret_access_key"] = self.secret
            if self.token:
                out["aws_session_token"] = self.token
        return out

    # ── URLs ──────────────────────────────────────────────────────────
    def urls_for_duckdb(self, s3_client, urls: Sequence[str],
                        conn_config: Optional[dict] = None) -> List[str]:
        """The URLs DuckDB should be handed for these ``s3://`` URLs:
        presigned HTTPS when this connection PRESIGNS (or needs the VPC
        rewrite), the ``s3://`` URLs unchanged when it is NATIVE.  The
        signing mechanics stay in ``core.s3_utilities.s3_urls_to_presigned``;
        the DECISION it consults is :func:`access_mode_for`."""
        urls = list(urls)
        if not urls:
            return urls
        import core.s3_utilities as _s3u
        cfg = dict(conn_config or {})
        # The mode this resolver decided travels explicitly, so a config that
        # lacks the field (or was edited after resolution) cannot re-decide.
        cfg["s3_access_mode"] = self.access_mode
        return list(_s3u.s3_urls_to_presigned(s3_client, urls, cfg))


def _parse_credentials(conn_config: dict) -> Tuple[str, str, str]:
    key = (conn_config.get("aws_access_key_id")
           or conn_config.get("access_key_id") or "")
    secret = (conn_config.get("aws_secret_access_key")
              or conn_config.get("secret_access_key") or "")
    token = (conn_config.get("aws_session_token")
             or conn_config.get("session_token") or "")
    return str(key or ""), str(secret or ""), str(token or "")


def resolve_s3_access(conn_config: Optional[dict], *,
                      connection_id: Optional[int] = None,
                      credentials: Optional[Tuple[str, str, str]] = None,
                      region: Optional[str] = None,
                      proxy: bool = True) -> S3Access:
    """Resolve the S3 access shape for ``conn_config`` (the connection's
    ``config`` dict, credentials already resolved by the credential
    chokepoint where the auth mode needs it).

    ``credentials=(key, secret, token)`` overrides the config's literal keys
    (the DuckDB child and federation run STS themselves).  ``region=``
    skips a second ``resolve_s3_region`` when the caller already has it.
    ``proxy=False`` skips the proxy lookup (it can read config / DB for a
    system-account proxy) for callers that apply the proxy separately.
    """
    from core.ssl_config import (
        normalize_vpce_endpoint_for_s3_data, s3_endpoint_host_for_duckdb,
        s3_endpoint_uses_ssl,
    )
    from core.s3_storage import effective_addressing_style, resolve_s3_region

    cfg = dict(conn_config or {})
    raw_ep = str(cfg.get("endpoint_url") or cfg.get("endpoint") or "").strip()
    endpoint_url = (normalize_vpce_endpoint_for_s3_data(raw_ep) or raw_ep) if raw_ep else ""
    endpoint_host = s3_endpoint_host_for_duckdb(cfg) if raw_ep else ""
    use_ssl = s3_endpoint_uses_ssl(cfg)

    try:
        from core.proxy_utils import is_aws_s3_endpoint
        is_aws = (not endpoint_host) or is_aws_s3_endpoint(endpoint_host.split(":")[0])
    except Exception:
        is_aws = not endpoint_host

    # ONE addressing rule, in ``core.s3_storage.effective_addressing_style``
    # (a plain-HTTP custom endpoint is path-style; then the operator's
    # declared style; then VPCE auto-detect).  2026-10-26: the plain-HTTP
    # half used to live HERE, so DuckDB applied it and the boto3 client did
    # not -- the presigner and the lister then addressed the same MinIO
    # virtual-hosted.  boto3 (``build_boto3_s3_config_kwargs``) and this
    # resolver now read the same function.
    style = effective_addressing_style(cfg)
    url_style = PATH_STYLE if style == PATH_STYLE else VIRTUAL_STYLE

    if region is None:
        region = resolve_s3_region(cfg)
    region = str(region or "").strip() or "us-east-1"

    mode = access_mode_for(cfg)

    if credentials is not None:
        key, secret, token = (str(credentials[0] or ""), str(credentials[1] or ""),
                              str(credentials[2] or "") if len(credentials) > 2 else "")
    else:
        key, secret, token = _parse_credentials(cfg)

    proxy_stmts: Tuple[str, ...] = ()
    if proxy:
        try:
            from core.proxy_utils import get_duckdb_proxy_stmts
            proxy_stmts = tuple(get_duckdb_proxy_stmts(endpoint_url=endpoint_url))
        except Exception as exc:                          # pragma: no cover
            logger.debug("[s3-access] proxy statements unavailable: %s", exc)

    reason = (
        f"endpoint={'aws-default' if not endpoint_host else endpoint_host} "
        f"ssl={'on' if use_ssl else 'off'} style={url_style} region={region} "
        f"mode={mode} creds={'yes' if key else 'none'} "
        f"proxy={'yes' if proxy_stmts else 'direct'}"
    )
    cid = None
    try:
        cid = int(connection_id) if connection_id is not None else None
    except (TypeError, ValueError):
        cid = None
    return S3Access(
        connection_id=cid, endpoint_url=endpoint_url, endpoint_host=endpoint_host,
        is_aws=bool(is_aws), use_ssl=bool(use_ssl), url_style=url_style,
        region=region, access_mode=mode, key=key, secret=secret, token=token,
        proxy_statements=proxy_stmts, reason=reason,
    )


# ═══════════════════════════════════════════════════════════════════════════
# The generic execution branch: raw s3:// files become VIEWS in setup_sql
# ═══════════════════════════════════════════════════════════════════════════

def looks_like_s3_file(url: str) -> bool:
    """A URL naming ONE object (by extension) rather than a prefix."""
    return str(url).lower().rstrip("/").endswith(_FILE_EXTENSIONS)


def split_s3_url(url: str) -> Tuple[str, str]:
    """``s3://bucket/key`` -> ``(bucket, key)``."""
    rest = str(url)[len("s3://"):]
    bucket, _, key = rest.partition("/")
    return bucket, key


def prepare_s3_reads(access: S3Access, s3_client, urls: Iterable[str], *,
                     lister: Callable[[str, str], Sequence[str]],
                     conn_config: Optional[dict] = None,
                     objects_out: Optional[Dict[str, List[str]]] = None) -> Dict[str, List[str]]:
    """For each raw ``s3://`` URL, the list of URLs DuckDB reads for it.

    A URL with a file extension is one object; anything else is a PREFIX
    and ``lister(bucket, key)`` enumerates its parquet files (the caller
    supplies the product's own listing, so its truncation REFUSAL passes
    straight through -- this function never narrows a listing).  Every URL
    then goes through :meth:`S3Access.urls_for_duckdb`, which presigns when
    this connection presigns.  An empty listing is an error naming the
    prefix: "no files" and "could not read" must not both look like an
    empty view.

    ``objects_out`` (2026-09-26, F3 round 4): when given, receives the RAW
    ``s3://`` objects behind each URL, before presigning -- what a boto3
    pre-download (the proxy / on-prem fallback) reads.  One listing serves
    both the DuckDB view and the pre-download, so they cannot disagree.
    """
    out: Dict[str, List[str]] = {}
    for url in urls:
        url = str(url)
        if looks_like_s3_file(url):
            objects = [url]
        else:
            bucket, key = split_s3_url(url)
            objects = [str(u) for u in (lister(bucket, key.rstrip("/")) or [])]
            if not objects:
                raise ValueError(
                    f"No parquet files found under {url} on connection "
                    f"{access.connection_id}: nothing to read.")
        if objects_out is not None:
            objects_out[url] = list(objects)
        out[url] = access.urls_for_duckdb(s3_client, objects, conn_config)
    return out


def _reader_for(files: Sequence[str]) -> str:
    """The DuckDB reader for a homogeneous file group: parquet unless every
    file (before any ``?`` query string) is CSV / JSON."""
    def _ext(u: str) -> str:
        base = str(u).split("?", 1)[0].lower()
        return os.path.splitext(base)[1]
    exts = {_ext(f) for f in files}
    if exts and exts <= {".csv", ".tsv"}:
        return "read_csv_auto"
    if exts and exts <= {".json", ".jsonl"}:
        return "read_json_auto"
    return "read_parquet"


_READ_CALL_RE = re.compile(
    r"read_(?:parquet|csv_auto|json_auto)\(\s*(\[[^\]]*\]|'(?:[^']|'')*')\s*(?:,[^)]*)?\)",
    re.IGNORECASE,
)
_LITERAL_RE = re.compile(r"'((?:[^']|'')*)'")


def s3_reads_as_views(sql: str, prepared: Dict[str, List[str]], *,
                      view_prefix: str = "__qs_s3") -> Tuple[str, List[str]]:
    """Rewrite every ``read_*('s3://…')`` / ``read_*(['s3://…', …])`` call in
    ``sql`` whose literals are all keys of ``prepared`` into a VIEW
    reference, and return ``(rewritten_sql, view_statements)``.

    The views go in ``setup_sql`` because that is the only text the DuckDB
    child's fallbacks rewrite -- presigned pre-download, the VPC rewrite and
    the proxy pre-download all operate on ``setup_sql`` and never on
    ``copy_sql``.  A raw ``s3://`` left inside the COPY statement was outside
    every one of them, which is how the generic branch read AWS.  Views are
    also what the registered-table and raw-SQL branches emit, so the three
    branches now hand the child the same shape.

    ``hive_partitioning=true`` so a partition directory in the path
    (``region=AMER/``) materialises as a column exactly as it does on the
    registered branch; ``union_by_name=true`` when a view spans several
    files.  A call whose literals are not all known is left untouched.
    """
    views: List[str] = []
    seen: Dict[Tuple[str, ...], str] = {}

    def _replace(m: "re.Match") -> str:
        body = m.group(1)
        literals = [lit.replace("''", "'") for lit in _LITERAL_RE.findall(body)]
        if not literals or any(lit not in prepared for lit in literals):
            return m.group(0)
        key = tuple(literals)
        name = seen.get(key)
        if name is None:
            name = f"{view_prefix}_{len(seen)}"
            seen[key] = name
            files: List[str] = []
            for lit in literals:
                files.extend(prepared[lit])
            paths = ", ".join(f"'{_esc(f)}'" for f in files)
            reader = _reader_for(files)
            opts = "union_by_name=true" if len(files) > 1 else ""
            if reader == "read_parquet":
                # 2026-10-06 -- an undeclared partition key keeps the
                # literal string (core.hive_partition_types).
                opts = ("hive_partitioning=true, hive_types_autocast=false"
                        + (", " + opts if opts else ""))
            views.append(
                f'CREATE VIEW "{name}" AS SELECT * FROM {reader}([{paths}]'
                f'{", " + opts if opts else ""})')
        return f'"{name}"'

    rewritten = _READ_CALL_RE.sub(_replace, sql)
    return rewritten, views


__all__ = [
    "NATIVE", "PRESIGNED", "PATH_STYLE", "VIRTUAL_STYLE",
    "S3Access", "access_mode_for", "resolve_s3_access",
    "looks_like_s3_file", "split_s3_url", "prepare_s3_reads", "s3_reads_as_views",
]


# ═══════════════════════════════════════════════════════════════════════════
# A typed s3:// path on a PRESIGNED connection is refused in words (2026-10-29)
# ═══════════════════════════════════════════════════════════════════════════

class S3PathOnPresignedRefusal(ValueError):
    """A typed ``s3://`` path in raw SQL on a connection that PRESIGNS.

    Found on the rig 2026-10-29: the raw-SQL branch binds REGISTERED tables as
    views (presigned, pre-downloaded); a path typed in the statement was rewritten
    by nothing, so the DuckDB child -- correctly given no endpoint and no
    credentials on-prem -- sent it to real AWS: "AWS access denied ... your
    credentials may have expired" for a MinIO bucket whose keys were fine.  Never
    an answer from the wrong place: the statement is refused naming the
    registered table that covers the path, or how to register one."""


_TYPED_S3_RE = re.compile(r"'(s3://(?:[^']|'')+)'", re.IGNORECASE)


def refuse_typed_s3_paths_on_presigned(sql: str, conn_config: Optional[dict],
                                       registered_tables: Optional[Sequence[dict]] = None) -> None:
    """Raise :class:`S3PathOnPresignedRefusal` when ``sql`` names an ``s3://`` path
    and this connection presigns.  A native (AWS) connection reads such a path
    itself and is never refused here."""
    paths = list(dict.fromkeys(_TYPED_S3_RE.findall(sql or "")))
    if not paths or access_mode_for(conn_config or {}) != PRESIGNED:
        return
    bucket_cfg = str((conn_config or {}).get("bucket") or "").strip()
    hints = []
    for p in paths:
        bucket, key = split_s3_url(p)
        best = None
        for t in registered_tables or []:
            prefix = str(t.get("s3_prefix") or "").strip("/")
            t_bucket = str(t.get("bucket") or bucket_cfg or bucket)
            if prefix and t_bucket == bucket and (key == prefix or key.startswith(prefix + "/")):
                if best is None or len(prefix) > len(str(best.get("s3_prefix") or "").strip("/")):
                    best = t
        if best is not None:
            hints.append(f"'{p}' is the registered table {best.get('name')} -- write "
                         f"FROM {best.get('name')} (add a WHERE on its partition columns "
                         f"to read only part of it)")
        else:
            hints.append(f"'{p}' is not under any registered table -- register its folder "
                         f"as a table on this connection, then query it by name")
    raise S3PathOnPresignedRefusal(
        "This connection reads on-premise S3 through its registered tables, so a "
        "path typed in the SQL cannot be read directly. " + "; ".join(hints) + ".")
