/**
 * A run stopped because its SERVER restarted (a deployment, a pod restart) --
 * not because the query is wrong and not because the user cancelled it
 * (2026-10-29).  The backend's sentence is core/checkpoint.py RESTART_MESSAGE;
 * the older boot-recovery sentence ("Server restarted while query was ...")
 * counts too.  The screen offers "Run again" on exactly these.
 */
export function stoppedByServerRestart(message: string | null | undefined): boolean {
  const m = String(message || '').toLowerCase();
  return m.includes('server running this query restarted') || m.includes('server restarted while query was');
}
