"""Per-side REPORTED-ROWS certification (2026-10-11): a run's rows on each
side must equal the ROW_COUNT the upstream's own message said -- the ONE rule
both lanes apply, so a mismatch FAILS the run with the numbers, never passes.

The owner's QS_KAFKA_MESSAGE carries ``ROW_COUNT`` for every (DATA_SOURCE,
CODE, BUSINESS_EVENT, CLOUD_COMPLIANT) load.  A feed declares TWO
dependencies -- the cloud side's message and the on-prem side's -- and may
say on each which SIDE of the feed it vouches for
(``etl_dependency_mappings.certifies_side`` = ``primary`` / ``secondary``).
The resolver (``core/feed/etl_dependency.py::resolve_reported_side_rows``)
reads the ledger ONCE at execution start and stores what every side is
expected to count; each lane counts its sides (native: the parquet
metadata; the Spark job: ``_combine_cross_source``'s counts) and asks
:func:`judge` here, before any file is written.

MIRRORED into the Spark job image as ``spark/jobs/qs_reported_rows_
certification.py`` (byte-identical; ``tests/_mirrors.py``): the job cannot
import ``backend/core``, and a rule both lanes apply lives in one module.
This module imports NOTHING of ours and nothing beyond the standard library.

The verdicts, and why each is what it is:

* ``not_declared``  -- no dependency certifies a side: nothing to judge.
* ``certified``     -- every declared side's count == its reported count.
* ``mismatch``      -- a declared side's count != the reported count (the
                       numbers are in the sentence), OR the arrival carried
                       NO count (the author asked for a check the message
                       cannot satisfy -- a gate that cannot evaluate refuses,
                       it does not pass), OR the lane could not count the
                       side (unknown is not equal).
* ``uncertified``   -- a declared side whose dependency has NO arrival at
                       all: the run was released by an operator's skip or
                       the legacy rule, a recorded human decision; the run
                       proceeds and the record says the side is uncertified.
* ``unreadable``    -- the mappings or the ledger could not be read at
                       execution start: the check cannot be evaluated, the
                       run refuses (the numbers would be invented).

Expected shape (what the resolver stores, per side)::

    {"primary":   {"dependency": "finance_sl_balance_SAP-2504_EOD_CLOUD",
                   "status": "reported" | "no_count" | "no_arrival",
                   "reported_rows": 4321 | None},
     "secondary": {...}}
    or {"_unreadable": "<why>"}
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

MIRROR_PATHS = (
    "backend/core/feed/reported_rows_certification.py",
    "spark/jobs/qs_reported_rows_certification.py",
)

SIDES = ("primary", "secondary")

#: Where the record lands on the execution row (``stage_timings``; the
#: failure path persists stage_timings, so a FAILED run shows the numbers).
RECORD_KEY = "reported_rows_certification"

VERDICT_NOT_DECLARED = "not_declared"
VERDICT_CERTIFIED = "certified"
VERDICT_MISMATCH = "mismatch"
VERDICT_UNCERTIFIED = "uncertified"
VERDICT_UNREADABLE = "unreadable"

STATUS_REPORTED = "reported"
STATUS_NO_COUNT = "no_count"
STATUS_NO_ARRIVAL = "no_arrival"


def _int(v: Any) -> Optional[int]:
    if isinstance(v, bool) or v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def judge(expected: Optional[Mapping[str, Any]],
          actual: Mapping[str, Any]) -> Dict[str, Any]:
    """The verdict over what every side was expected to count and what the
    lane counted.  ``actual`` is ``{"primary": n | None, "secondary": n |
    None}`` (None = the lane could not count that side).  Returns the record
    (``verdict``, per-side ``sides``, ``failures`` sentences); never raises.
    """
    if isinstance(expected, Mapping) and expected.get("_unreadable"):
        why = str(expected.get("_unreadable"))
        return {"verdict": VERDICT_UNREADABLE, "sides": {},
                "failures": [f"reported-rows certification could not be evaluated: "
                             f"{why} -- the run refuses rather than certify on "
                             f"nothing"]}
    declared = {s: dict(expected[s]) for s in SIDES
                if isinstance(expected, Mapping) and isinstance(expected.get(s), Mapping)}
    if not declared:
        return {"verdict": VERDICT_NOT_DECLARED, "sides": {}, "failures": []}
    sides: Dict[str, Any] = {}
    failures = []
    uncertified = False
    for side, exp in declared.items():
        dep = str(exp.get("dependency") or "?")
        status = str(exp.get("status") or STATUS_NO_ARRIVAL)
        reported = _int(exp.get("reported_rows"))
        counted = _int(actual.get(side)) if isinstance(actual, Mapping) else None
        row: Dict[str, Any] = {"dependency": dep, "status": status,
                               "reported_rows": reported, "actual_rows": counted}
        if status == STATUS_NO_ARRIVAL:
            row["verdict"] = VERDICT_UNCERTIFIED
            row["reason"] = (f"{dep} has no arrival on the ledger for this date "
                             f"(released by a skip or the legacy rule) -- the "
                             f"{side} side's {counted if counted is not None else '?'} "
                             f"row(s) are NOT certified against an upstream count")
            uncertified = True
        elif (status == STATUS_NO_COUNT or reported is None) and exp.get("inferred"):
            # 2026-10-16 -- the author declared NO certifies_side: the side was
            # INFERRED (a single-source feed's one dependency, or the
            # environment its name declares).  An arrival that carries no count
            # (an Iceberg commit, a file, an ETL status) is then not a contract
            # broken but no count to certify against -- UNCERTIFIED and said,
            # like a missing arrival.  Every single-dependency feed on such a
            # source FAILED here since 2026-10-12 (found by the fresh test rig).
            row["verdict"] = VERDICT_UNCERTIFIED
            row["reason"] = (f"{side} side: {dep} carries no row count and certifies_side "
                             f"was not declared (inferred) -- the "
                             f"{counted if counted is not None else '?'} row(s) are NOT "
                             f"certified against an upstream count")
            uncertified = True
        elif status == STATUS_NO_COUNT or reported is None:
            row["verdict"] = VERDICT_MISMATCH
            row["reason"] = (f"{side} side: the arrival of {dep} carried NO row count, "
                             f"but the dependency declares it certifies this side "
                             f"({counted if counted is not None else '?'} row(s) read)")
            failures.append(row["reason"])
        elif counted is None:
            row["verdict"] = VERDICT_MISMATCH
            row["reason"] = (f"{side} side: {dep} reported {reported} row(s) but this "
                             f"lane could not count the side -- unknown is not equal")
            failures.append(row["reason"])
        elif counted != reported:
            row["verdict"] = VERDICT_MISMATCH
            row["reason"] = (f"{side} side: read {counted} row(s) but {dep} reported "
                             f"{reported} (difference {counted - reported:+d})")
            failures.append(row["reason"])
        else:
            row["verdict"] = VERDICT_CERTIFIED
            row["reason"] = f"{side} side: {counted} row(s) == {dep}'s reported {reported}"
        sides[side] = row
    if failures:
        verdict = VERDICT_MISMATCH
    elif uncertified:
        verdict = VERDICT_UNCERTIFIED
    else:
        verdict = VERDICT_CERTIFIED
    return {"verdict": verdict, "sides": sides, "failures": failures}


def failure_sentence(record: Mapping[str, Any]) -> Optional[str]:
    """The ONE sentence a lane fails the run with, or None when the run may
    proceed (certified / uncertified / not declared)."""
    failures = list((record or {}).get("failures") or [])
    if not failures:
        return None
    return "reported-rows certification FAILED: " + "; ".join(str(f) for f in failures)


__all__ = ["MIRROR_PATHS", "SIDES", "RECORD_KEY", "judge", "failure_sentence",
           "VERDICT_NOT_DECLARED", "VERDICT_CERTIFIED", "VERDICT_MISMATCH",
           "VERDICT_UNCERTIFIED", "VERDICT_UNREADABLE",
           "STATUS_REPORTED", "STATUS_NO_COUNT", "STATUS_NO_ARRIVAL"]
