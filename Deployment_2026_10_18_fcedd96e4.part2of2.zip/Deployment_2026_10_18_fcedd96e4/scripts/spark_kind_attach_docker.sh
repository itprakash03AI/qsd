#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Make the DOCKER rig's backend containers reach the kind Spark cluster.
#
#   usage:  bash scripts/spark_kind_attach_docker.sh            # attach + verify
#           bash scripts/spark_kind_attach_docker.sh --detach   # undo
#           bash scripts/spark_kind_attach_docker.sh --verify-image
#           bash scripts/spark_kind_attach_docker.sh --load-image
#
# WHY THIS EXISTS (2026-09-20)
#   FeedGen once opened Spark pods from this machine -- but the API that did
#   it ran ON THE HOST (`uvicorn --host 0.0.0.0`; see
#   scripts/demo_feedgen_spark_docker.sh: "the API is on the host").  The
#   Docker rig's containers never could: qs-spark-control-plane sits ALONE
#   on the `kind` docker network (no DNS from querystudio-local-net), and no
#   container carries a kubeconfig.  With spark_k8s.enabled=false on top,
#   /api/feeds/backend-options said "disabled_by_config" -- true, but the
#   real blocker was topology, and a flag does not fix topology.
#
# WHAT IT DOES (all reversible, no image rebuild, no container recreate)
#   1. `docker network connect kind <container>` for api, executor and
#      scheduler -- a container may sit on two networks.  DNS for
#      qs-spark-control-plane then resolves inside them.
#   2. Rewrites the host's kind kubeconfig (context kind-qs-spark, server
#      127.0.0.1:<port>) to server https://qs-spark-control-plane:6443 and
#      copies it to /home/querystudio/.kube/config in each container
#      (core/spark_k8s/client.py: in-cluster first, then load_kube_config()).
#   3. Verifies from INSIDE the api container: the CRD is served, the spark
#      ServiceAccount exists, pods can be listed.
#
# WHAT IT DOES NOT DO -- you do these, they are config and cluster state:
#   * config.json (bind-mounted, git-ignored) needs, then `docker compose
#     -f docker-compose.local.yml restart api executor scheduler`:
#       spark_k8s.enabled=true  namespace=spark  service_account=spark
#       image=querystudio/spark-etl:local  image_pull_policy=IfNotPresent
#       callback_base_url=http://host.docker.internal:8000   (pods reach the
#         host by that name; the API's :8000 is published)
#       driver_memory=1g executor_memory=1g executor_cores=1 num_executors=2
#       feed_generation.webhook_secret=<random hex>  (empty -> the job's
#         callback is refused 503; the reconciler still closes the row)
#   * (the job image IS handled here now -- `--load-image`, see below)
#   * source/destination connections the POD can reach: host.docker.internal
#     with the PUBLISHED port (Oracle :1521, Trino :8088, MinIO :9000), not
#     the compose service names (oracle-db, qs-trino) the containers use.
#
# A `docker compose up --force-recreate` DROPS steps 1 and 2 (they live on
# the container, not the image).  Re-run this script afterwards.
#
# THE IMAGE IDENTITY CHECK (2026-09-21, FB-59a)
#   `spark/jobs/generic_feed.py` is a SEPARATE deployable: rolling out the API
#   does not carry it, and the ONLY thing that puts it in front of a driver pod
#   is the image inside the cluster.  A fix can be committed, the tree clean,
#   the API image rebuilt -- and every pod still run the old code.  Nothing in
#   the Docker protocol looked at that, because it compares CONTAINER
#   timestamps against HEAD and a kind node runs no container of ours.
#
#   So step 4 compares the image on the HOST with the image IN THE CLUSTER and
#   exits NON-ZERO when they differ, naming both.  `--load-image` loads first
#   and then runs exactly the same check, so "I rebuilt the Spark image" stops
#   being a claim and becomes an exit status.
#
#   WHAT IT COMPARES, AND WHY NOT "THE IMAGE ID".  The two sides spell the id
#   differently BY CONSTRUCTION and comparing those two strings is how this
#   was misdiagnosed once already:
#
#     docker images        d816f405aba7   <- OCI index digest (docker's .Id
#                                            under the containerd image store)
#     crictl images        5b3b68061c61a  <- the platform manifest's CONFIG
#                                            digest, a different blob
#     ctr -n k8s.io images ls
#                          d816f405aba7   <- the same index digest as docker
#
#   All three can name ONE image.  A `kind load` that genuinely worked will
#   still leave `docker images` and `crictl images` disagreeing forever, and
#   reading that as "the tag never moved" sends you hunting a loader bug that
#   is not there.  The check therefore compares what actually RUNS and cannot
#   be spelled two ways: the image config's `created` stamp plus every layer
#   diffID, read from `docker image inspect` on the host and from `crictl
#   inspecti`'s imageSpec in the node.  Identical layers + identical build
#   stamp = the same bytes reach the driver.  Both native ids are printed
#   alongside so the difference above is visible rather than alarming.
# ---------------------------------------------------------------------------
set -uo pipefail

CONTAINERS=(qs-local-api qs-local-executor qs-local-scheduler)
SOURCES=(qs-minio qs-trino qs-trino-sb qs-sftp)
NODE="${KIND_NODE:-qs-spark-control-plane}"
NET="${KIND_NET:-kind}"
CTX="${KIND_CTX:-kind-qs-spark}"
CLUSTER="${KIND_CLUSTER:-qs-spark}"
HOME_IN="${QS_HOME_IN:-/home/querystudio}"
SPARK_IMAGE="${QS_SPARK_IMAGE:-querystudio/spark-etl:local}"
export MSYS_NO_PATHCONV=1

# containerd namespaces an image by its FULLY qualified ref; docker does not.
case "$SPARK_IMAGE" in
  */*/*) CLUSTER_REF="$SPARK_IMAGE" ;;
  */*)   CLUSTER_REF="docker.io/$SPARK_IMAGE" ;;
  *)     CLUSTER_REF="docker.io/library/$SPARK_IMAGE" ;;
esac

# A python that cannot RUN is not a python.  Probing beats `command -v`:
# QS_PYTHON pointing at a missing or broken interpreter used to leave every
# read empty, which the check then reported as "the image is ABSENT from the
# node" -- a wrong answer that sends you to reload an image that is already
# there.  Unknown and empty are different findings.
PY_BIN=""
for _cand in "${QS_PYTHON:-}" python python3; do
  [ -n "$_cand" ] || continue
  if "$_cand" -c 'pass' >/dev/null 2>&1; then PY_BIN="$_cand"; break; fi
done
unset _cand

# Every reader below is piped through `tr -d` of a CARRIAGE RETURN, written as
# the two-character escape and never as a literal CR: this bash strips a raw CR
# out of its own script text, so `tr -d '<CR>'` silently becomes `tr -d ''` and
# deletes nothing.  On Windows the python that parses the node's JSON writes
# CRLF to stdout, so without this the two sides differ by one byte per line and
# the check FAILS on a correctly loaded image.  A verifier that cries wolf gets
# switched off, which is the same outcome as having no verifier at all.
CR="$(printf '\015')"

# --- the two sides of the identity -----------------------------------------
# What RUNS, spelled the one way both sides agree on: the image config's build
# stamp followed by every layer diffID.  Never "the image id" -- see the header.
host_fingerprint() {
  docker image inspect "$SPARK_IMAGE" --format '{{.Created}}{{range .RootFS.Layers}}
{{.}}{{end}}' 2>/dev/null | tr -d "$CR"
}

# "could not read it" and "it is not there" lead to opposite investigations,
# so this says UNREADABLE rather than returning the empty string that ABSENT
# also produces.  Both still FAIL -- an unknown cluster image is not a pass.
cluster_fingerprint() {
  [ -n "$PY_BIN" ] || { echo "NO-PYTHON"; return 0; }
  local raw
  raw="$(docker exec "$NODE" crictl inspecti "$CLUSTER_REF" 2>/dev/null)" || return 0
  [ -n "$raw" ] || return 0
  printf '%s' "$raw" | "$PY_BIN" -c 'import sys, json
try:
    spec = json.load(sys.stdin)["info"]["imageSpec"]
    out = [spec["created"]] + list(spec["rootfs"]["diff_ids"])
except Exception as exc:
    print("UNREADABLE %s: %s" % (type(exc).__name__, exc))
    raise SystemExit(0)
for line in out:
    print(line)' | tr -d "$CR"
}

host_id() { docker image inspect "$SPARK_IMAGE" --format '{{.Id}}' 2>/dev/null | tr -d "$CR"; }

cluster_id() {
  docker exec "$NODE" ctr -n k8s.io images ls "name==$CLUSTER_REF" 2>/dev/null     | tr -d "$CR" | awk 'NR>1 {print $3; exit}'
}

cluster_config_id() {
  docker exec "$NODE" crictl images 2>/dev/null     | tr -d "$CR" | awk -v r="${CLUSTER_REF%:*}" '$1==r {print $3; exit}'
}

# Exits NON-ZERO when the cluster is not running the host's bytes.  That is the
# whole point: a load that reports success and changes nothing must not be
# indistinguishable from a load that worked.
verify_image() {
  echo "== 4. spark job image identity ($SPARK_IMAGE)"
  local hfp cfp hid cid ccid
  hfp="$(host_fingerprint)"
  if [ -z "$hfp" ]; then
    echo "  FAIL: $SPARK_IMAGE is not on the HOST -- build it first:"
    echo "          docker build -t $SPARK_IMAGE spark/"
    return 1
  fi
  if [ "$(cluster_fingerprint)" = "NO-PYTHON" ]; then
    echo "  FAIL: no WORKING python, so the cluster image cannot be read."
    echo "        QS_PYTHON=${QS_PYTHON:-<unset>}; neither it nor python/python3"
    echo "        on PATH would run.  That is UNKNOWN, not a pass -- this"
    echo "        refuses to report a comparison it did not make."
    return 1
  fi
  cfp="$(cluster_fingerprint)"
  hid="$(host_id)"; cid="$(cluster_id)"; ccid="$(cluster_config_id)"
  case "$cfp" in
    UNREADABLE*)
      echo "  FAIL: node $NODE describes $CLUSTER_REF in a shape this cannot read."
      echo "        $cfp"
      echo "        That is UNKNOWN, not absent and not a match -- check"
      echo "        'docker exec $NODE crictl inspecti $CLUSTER_REF' by hand."
      return 1 ;;
  esac
  if [ -z "$cfp" ]; then
    echo "  FAIL: $CLUSTER_REF is ABSENT from node $NODE."
    echo "        host    id $hid"
    echo "        cluster (none)"
    echo "        load it:  bash scripts/spark_kind_attach_docker.sh --load-image"
    return 1
  fi
  if [ "$hfp" != "$cfp" ]; then
    echo "  FAIL: the cluster is running DIFFERENT BYTES from the host."
    echo "        host    id $hid"
    echo "        cluster id $cid   (crictl config id $ccid)"
    echo "        host    built $(printf '%s' "$hfp" | head -1)   layers $(printf '%s' "$hfp" | grep -c '^sha256:')"
    echo "        cluster built $(printf '%s' "$cfp" | head -1)   layers $(printf '%s' "$cfp" | grep -c '^sha256:')"
    echo "        driver pods run the CLUSTER one.  Reload:"
    echo "          bash scripts/spark_kind_attach_docker.sh --load-image"
    return 1
  fi
  echo "  OK: host and cluster are the same image"
  echo "      built  $(printf '%s' "$hfp" | head -1)   layers $(printf '%s' "$hfp" | grep -c '^sha256:')"
  echo "      host    id        $hid"
  echo "      cluster id        $cid   <- ctr index digest, equal to docker's"
  echo "      cluster crictl id $ccid   <- the CONFIG digest; differs BY DESIGN"
  return 0
}

# `kind load` is the mechanism; verify_image is what makes it a fact.  The
# fallback exists because the two obvious hand-rolled routes both fail on this
# box: piping `docker save` into `ctr images import` through Git Bash mangles
# the image ref, and `docker cp` cannot see an MSYS /tmp path.  Staging the tar
# at a REPO-relative path and handing `docker cp` its cygpath -w spelling --
# the same trick step 2 already uses for the kubeconfig -- avoids both.
load_image() {
  echo "== load $SPARK_IMAGE into kind cluster $CLUSTER"
  if [ -z "$(host_fingerprint)" ]; then
    echo "  $SPARK_IMAGE is not on the host -- build it first:"
    echo "    docker build -t $SPARK_IMAGE spark/"
    return 1
  fi
  if command -v kind >/dev/null 2>&1; then
    kind load docker-image "$SPARK_IMAGE" --name "$CLUSTER"       || echo "  kind load returned non-zero -- trying the tar route"
  else
    echo "  kind not on PATH -- using the tar route"
  fi
  if verify_image >/dev/null 2>&1; then
    verify_image
    return 0
  fi
  echo "  -- the cluster image did not move; falling back to docker save + ctr import"
  local TAR TAR_HOST rc
  TAR="$PWD/.spark-image-load.$$.tar"
  docker save -o "$TAR" "$SPARK_IMAGE" || { rm -f "$TAR"; echo "  docker save failed"; return 1; }
  TAR_HOST="$(cygpath -w "$TAR" 2>/dev/null || echo "$TAR")"
  docker exec "$NODE" mkdir -p /qs-image-load     && docker cp "$TAR_HOST" "$NODE:/qs-image-load/image.tar"     && docker exec "$NODE" ctr -n k8s.io images import /qs-image-load/image.tar
  rc=$?
  docker exec "$NODE" rm -rf /qs-image-load >/dev/null 2>&1
  rm -f "$TAR"
  [ $rc -eq 0 ] || { echo "  ctr import failed"; return 1; }
  verify_image
}

if [ "${1:-}" = "--verify-image" ] || [ "${1:-}" = "--load-image" ]; then
  docker inspect "$NODE" >/dev/null 2>&1     || { echo "kind node container $NODE not found -- is the cluster up?"; exit 1; }
  if [ "${1:-}" = "--verify-image" ]; then verify_image; else load_image; fi
  exit $?
fi

if [ "${1:-}" = "--detach" ]; then
  for c in "${CONTAINERS[@]}"; do
    docker network disconnect "$NET" "$c" 2>/dev/null && echo "  $c: left network $NET"
    docker exec -u root "$c" rm -f "$HOME_IN/.kube/config" 2>/dev/null && echo "  $c: kubeconfig removed"
  done
  exit 0
fi

docker inspect "$NODE" >/dev/null 2>&1 || { echo "kind node container $NODE not found -- is the cluster up?"; exit 1; }

echo "== 0. the node must be RUNNING before anything joins $NET"
# 2026-10-06 -- a stopped node does not hold its address.  Attaching the rig
# containers while it was down let qs-local-api take 172.21.0.2, and the node
# then refused to start ("Address already in use") even with its static pin.
# So: if the node is down, take the rig containers OFF the network, start the
# node, and only then attach them again below.
if [ "$(docker inspect -f '{{.State.Running}}' "$NODE" 2>/dev/null)" != "true" ]; then
  echo "  $NODE is not running -- detaching rig containers from $NET, then starting it"
  for c in "${CONTAINERS[@]}"; do
    docker network disconnect "$NET" "$c" >/dev/null 2>&1 && echo "  $c: left $NET"
  done
  # 2026-10-12 -- ANY container may hold the node's address, not only the
  # ones this script attaches (qs-trino joins kind on its own and took
  # 172.21.0.2 while the node was stopped).  Free whoever holds it, start the
  # node, and give that container its network back.
  _want=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{if .IPAMConfig}}{{.IPAMConfig.IPv4Address}}{{end}}{{end}}' "$NODE" 2>/dev/null)
  _holder=""
  if [ -n "$_want" ]; then
    _holder=$(docker network inspect "$NET" -f '{{range .Containers}}{{.Name}} {{.IPv4Address}}{{"\n"}}{{end}}' \
              | awk -v ip="$_want/" 'index($2, ip) == 1 {print $1}')
    if [ -n "$_holder" ] && [ "$_holder" != "$NODE" ]; then
      docker network disconnect "$NET" "$_holder" >/dev/null 2>&1 \
        && echo "  $_holder held $_want -- left $NET until $NODE is up"
    fi
  fi
  docker start "$NODE" >/dev/null \
    || { echo "  could not start $NODE -- refusing to attach"; exit 1; }
  if [ -n "$_holder" ] && [ "$_holder" != "$NODE" ]; then
    docker network connect "$NET" "$_holder" >/dev/null 2>&1 && echo "  $_holder: back on $NET"
  fi
  _up=""
  for _i in $(seq 1 30); do
    [ "$(docker inspect -f '{{.State.Running}}' "$NODE" 2>/dev/null)" = "true" ] && { _up=1; break; }
    sleep 2
  done
  [ -n "$_up" ] || { echo "  $NODE did not stay running -- refusing to attach"; exit 1; }
  echo "  $NODE: running"
fi

echo "== 1. networks"
# 2026-09-24 -- PIN the node's address before anything else joins its network.
# A kind node's certificates and kubelet config name the IP it had when the
# cluster was created; docker hands out addresses DYNAMICALLY.  The rig
# containers this script attaches took addresses on the same network, so when
# the node next restarted (host sleep / Windows Update) one of THEM held the
# node's old IP: the kubelet dialled 172.21.0.2:6443, reached qs-local-api,
# was refused, never registered -- and the spark-operator webhook had no
# endpoints, so every SparkApplication submit failed with "context deadline
# exceeded" while `kubectl get pods` still showed stale Running rows.
# Reconnecting the node with --ip records a STATIC assignment that survives
# restarts and that no later joiner can take.
_node_ip=$(docker inspect -f "{{(index .NetworkSettings.Networks \"$NET\").IPAddress}}" "$NODE" 2>/dev/null)
_node_static=$(docker inspect -f "{{with (index .NetworkSettings.Networks \"$NET\").IPAMConfig}}{{.IPv4Address}}{{end}}" "$NODE" 2>/dev/null)
if [ -n "$_node_ip" ] && [ -z "$_node_static" ]; then
  echo "  $NODE: pinning $_node_ip as a static address on $NET (restarts the node)"
  docker network disconnect "$NET" "$NODE" \
    && docker network connect --ip "$_node_ip" "$NET" "$NODE" \
    && docker restart "$NODE" >/dev/null \
    || { echo "  could not pin $NODE's address -- refusing to attach"; exit 1; }
elif [ -n "$_node_static" ]; then
  echo "  $NODE: static address $_node_static on $NET"
fi
for c in "${CONTAINERS[@]}"; do
  if docker network inspect "$NET" --format '{{range .Containers}}{{.Name}} {{end}}' | tr ' ' '
' | grep -qx "$c"; then
    echo "  $c: already on $NET"
  else
    docker network connect "$NET" "$c" && echo "  $c: joined $NET"
  fi
done
# The SOURCES the driver/executor pods read or deliver to must be resolvable
# from inside kind too (2026-10-10: every spark_k8s merge feed failed with
# "UnknownHostException: qs-trino" -- only qs-minio had been joined, by hand).
# Joined when running; an optional one that is down is said, never fatal.
for c in "${SOURCES[@]}"; do
  if ! docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null | grep -q true; then
    echo "  $c: not running -- not joined (start it, then re-run this script)"
  elif docker network inspect "$NET" --format '{{range .Containers}}{{.Name}} {{end}}' | tr ' ' '
' | grep -qx "$c"; then
    echo "  $c: already on $NET"
  else
    docker network connect "$NET" "$c" && echo "  $c: joined $NET"
  fi
done

echo "== 2. kubeconfig (host context $CTX -> server https://$NODE:6443)"
# A repo-relative temp file: on this rig `docker cp` is a Windows binary and
# cannot see Git Bash's /tmp, so mktemp's default location is invisible to it.
TMP="$PWD/.kubeconfig-kind.$$"
trap 'rm -f "$TMP"' EXIT
kubectl config view --context "$CTX" --minify --raw -o yaml \
  | sed -E "s#server: https://127[.]0[.]0[.]1:[0-9]+#server: https://$NODE:6443#" > "$TMP"
grep -q "server: https://$NODE:6443" "$TMP" || { echo "  could not rewrite the server URL"; exit 1; }
# `docker cp` needs the HOST spelling of the source path (C:\... on Windows,
# where MSYS path conversion is off so container paths survive intact).
TMP_HOST="$(cygpath -w "$TMP" 2>/dev/null || echo "$TMP")"
for c in "${CONTAINERS[@]}"; do
  docker exec -u root "$c" mkdir -p "$HOME_IN/.kube"
  docker cp "$TMP_HOST" "$c:$HOME_IN/.kube/config" || { echo "  $c: docker cp failed"; exit 1; }
  docker exec -u root "$c" sh -c "chmod 644 $HOME_IN/.kube/config" && echo "  $c: kubeconfig installed"
done

echo "== 3. verify from inside qs-local-api"
docker exec -i qs-local-api python - <<'PY'
from kubernetes import config, client
config.load_kube_config()
v1 = client.CoreV1Api()
ext = client.ApiextensionsV1Api()
crd = any(c.metadata.name == "sparkapplications.sparkoperator.k8s.io"
          for c in ext.list_custom_resource_definition().items)
sa = v1.read_namespaced_service_account("spark", "spark").metadata.name
pods = [p.metadata.name for p in v1.list_namespaced_pod("spark").items]
print(f"  CRD served={crd}  serviceaccount={sa}  pods in spark ns={len(pods)}")
PY

verify_image || {
  echo
  echo "== ATTACHED, BUT THE CLUSTER IS NOT RUNNING THE HOST'''S SPARK JOB IMAGE."
  echo "   Every driver pod would execute the image named above, not spark/jobs/"
  echo "   as it stands in this working tree.  Fix that before believing a run."
  exit 1
}

echo "== done.  Now set the spark_k8s keys in backend/config.json and restart api/executor/scheduler;"
echo "   then GET /api/feeds/backend-options must say spark_k8s available=true (spark_application:ok)."
