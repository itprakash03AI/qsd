#!/usr/bin/env python
"""Build a partitioned parquet corpus in MinIO shaped like the live estate.

WHY THIS SHAPE.  ``docs/S3_ROUTE_LATENCY_AUDIT_2026_09_06.html`` measured the
real thing: a hive tree of ``region=<R>/dt=<D>/`` with **4 parts per
partition**, and ``docs/data_pruning_capability_slide.html`` states the live
target as "typically scans ~12 of 4,000+ files".  A 240-file toy cannot
reproduce either number -- at that size every pruning strategy looks the
same, because opening all of them is cheap.  So the default here is a FULL
YEAR:

    5 regions x 365 dates x 4 parts = 7,300 files

Three properties matter more than the row count, and each exists to make one
pruning stage MEASURABLE rather than merely enabled:

  partition pruning   region= and dt= are directory keys, so a predicate on
                      either should cut the file list before a single byte of
                      parquet is read.

  footer min/max      ``id`` is globally monotonic across files, so every
                      file owns a DISJOINT id range.  A predicate like
                      ``id BETWEEN x AND y`` is therefore satisfiable by a
                      handful of files and by no others -- if the engine
                      still opens 7,300 footers, min/max pruning is not
                      working, and that is visible instead of arguable.

  bloom filters       ``book`` is high-cardinality and each value appears in
                      FEW files.  ``docs/bloom_filter_case_note.html`` records
                      a bloom probed against the wrong physical encoding
                      skipping 63% of matching files, so ``book`` is written
                      as a plain string and the expected row count for every
                      probe value is recorded in the manifest below -- a
                      bloom that over-prunes shows up as MISSING ROWS, not as
                      a faster query.

Run it inside the API container (it already has pyarrow + boto3 and sits on
the MinIO network):

    docker exec qs-local-api python /app/scripts/seed_s3_rig.py --files 7300

Idempotent: it refuses to overwrite a populated prefix unless --force.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import io
import json
import os
import sys
import time

import boto3
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from botocore.client import Config as _BotoConfig

DEFAULT_ENDPOINT = os.environ.get("QS_S3_ENDPOINT", "http://qs-minio:9000")
DEFAULT_KEY = os.environ.get("QS_S3_KEY", "qsadmin")
DEFAULT_SECRET = os.environ.get("QS_S3_SECRET", "QsMinio_12345")
DEFAULT_BUCKET = os.environ.get("QS_S3_BUCKET", "qs-data")

REGIONS = ["AMER", "APAC", "EMEA", "LATAM", "UK"]
PARTS = 4
BOOKS = [f"BK{n:04d}" for n in range(1, 241)]      # 240 books
CCY = ["USD", "EUR", "GBP", "JPY", "CHF", "SGD"]


def s3_client(endpoint, key, secret, region="us-east-1"):
    # 2026-10-05: the REGION is a parameter -- real AWS signs per region, and
    # a us-east-2 bucket signed for us-east-1 is refused (MinIO accepts any).
    return boto3.client(
        "s3", endpoint_url=endpoint,
        aws_access_key_id=key, aws_secret_access_key=secret,
        region_name=region,
        config=_BotoConfig(signature_version="s3v4",
                           s3={"addressing_style": "path"},
                           max_pool_connections=32),
    )


def build_table(first_id, n_rows, region, dt_str, part, rng):
    """One part file.  ``id`` is a contiguous block -> disjoint per file."""
    ids = np.arange(first_id, first_id + n_rows, dtype=np.int64)
    # amt correlates with id so min/max pruning on amt is also meaningful,
    # with noise so it is not a trivial linear index.
    amt = (ids % 100_000) * 0.37 + rng.random(n_rows) * 25.0
    # Few books per file: that is what makes a bloom probe selective.
    book_pool = rng.choice(BOOKS, size=6, replace=False)
    books = rng.choice(book_pool, size=n_rows)
    return pa.table({
        "id": pa.array(ids, pa.int64()),
        "trade_ts": pa.array(
            [f"{dt_str}T{(i % 24):02d}:{(i % 60):02d}:00" for i in range(n_rows)],
            pa.string()),
        "book": pa.array(books, pa.string()),
        "ccy": pa.array(rng.choice(CCY, size=n_rows), pa.string()),
        "amt": pa.array(amt, pa.float64()),
        "qty": pa.array(rng.integers(1, 5000, size=n_rows), pa.int64()),
        "counterparty": pa.array(
            [f"CP{v:05d}" for v in rng.integers(1, 9000, size=n_rows)],
            pa.string()),
        "status": pa.array(
            rng.choice(["NEW", "AMENDED", "CANCELLED", "SETTLED"],
                       size=n_rows, p=[0.55, 0.2, 0.05, 0.20]),
            pa.string()),
        # The partition keys are ALSO stored as columns.  Hive pruning uses
        # the directory, but a reader that ignores hive_partitioning still
        # returns correct answers -- and a mismatch between the two is a
        # defect worth being able to see.
        "region": pa.array([region] * n_rows, pa.string()),
        "dt": pa.array([dt_str] * n_rows, pa.string()),
        "part": pa.array([part] * n_rows, pa.int32()),
    })


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", type=int, default=7300,
                    help="target file count (rounded to region*date*parts)")
    ap.add_argument("--rows-per-file", type=int, default=2000)
    ap.add_argument("--prefix", default="trades")
    ap.add_argument("--bucket", default=DEFAULT_BUCKET)
    ap.add_argument("--endpoint", default=DEFAULT_ENDPOINT)
    ap.add_argument("--key", default=DEFAULT_KEY)
    ap.add_argument("--secret", default=DEFAULT_SECRET)
    ap.add_argument("--start-date", default="2026-01-01")
    ap.add_argument("--force", action="store_true")
    # 2026-10-16 -- the PRODUCTION shape: the partition keys live ONLY in the
    # path (region=/dt=), as in the owner's tables (business_close_date=YYYY-MM-DD/
    # ...).  A key that is also a column inside the file is typed by the FILE
    # (core/hive_partition_types.py), so dt written as text inside the files
    # made the date column a string.  The test rig seeds with this flag.
    ap.add_argument("--keys-in-path-only", action="store_true")
    ap.add_argument("--compression", default="snappy")
    ap.add_argument("--region", default=os.environ.get("QS_S3_REGION", "us-east-1"))
    args = ap.parse_args()

    n_dates = max(1, round(args.files / (len(REGIONS) * PARTS)))
    total_files = len(REGIONS) * n_dates * PARTS

    s3 = s3_client(args.endpoint, args.key, args.secret, args.region)
    try:
        s3.head_bucket(Bucket=args.bucket)
    except Exception:
        s3.create_bucket(Bucket=args.bucket)
        print(f"created bucket {args.bucket}")

    existing = s3.list_objects_v2(Bucket=args.bucket,
                                  Prefix=f"{args.prefix}/", MaxKeys=2)
    if existing.get("KeyCount") and not args.force:
        print(f"REFUSING: s3://{args.bucket}/{args.prefix}/ already has "
              f"objects. Re-run with --force to overwrite.")
        return 2

    start = _dt.date.fromisoformat(args.start_date)
    rng = np.random.default_rng(20260917)
    first_id = 1
    written = 0
    total_rows = 0
    total_bytes = 0
    t0 = time.time()
    manifest = {
        "prefix": args.prefix, "bucket": args.bucket,
        "regions": REGIONS, "parts": PARTS, "dates": n_dates,
        "start_date": args.start_date, "rows_per_file": args.rows_per_file,
        "layout": "region=<R>/dt=<YYYY-MM-DD>/part-<n>.parquet",
    }

    for d in range(n_dates):
        dt_str = (start + _dt.timedelta(days=d)).isoformat()
        for region in REGIONS:
            for part in range(PARTS):
                tbl = build_table(first_id, args.rows_per_file, region,
                                  dt_str, part, rng)
                if args.keys_in_path_only:
                    tbl = tbl.drop(["region", "dt"])
                buf = io.BytesIO()
                pq.write_table(
                    tbl, buf, compression=args.compression,
                    # Row-group + statistics settings are the point: footer
                    # min/max and bloom filters only exist if written.
                    write_statistics=True,
                    row_group_size=args.rows_per_file,
                )
                body = buf.getvalue()
                key = (f"{args.prefix}/region={region}/dt={dt_str}/"
                       f"part-{part:03d}.parquet")
                s3.put_object(Bucket=args.bucket, Key=key, Body=body)
                first_id += args.rows_per_file
                written += 1
                total_rows += args.rows_per_file
                total_bytes += len(body)
        if (d + 1) % 20 == 0 or d == n_dates - 1:
            el = time.time() - t0
            print(f"  {written}/{total_files} files  "
                  f"{total_rows:,} rows  {total_bytes/1e6:.0f} MB  "
                  f"{el:.0f}s ({written/max(el,0.01):.0f} files/s)",
                  flush=True)

    manifest.update({
        "files": written, "rows": total_rows,
        "bytes": total_bytes,
        "id_min": 1, "id_max": first_id - 1,
        "built_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
    })
    s3.put_object(Bucket=args.bucket, Key=f"{args.prefix}/_manifest.json",
                  Body=json.dumps(manifest, indent=1).encode())
    print(json.dumps(manifest, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
