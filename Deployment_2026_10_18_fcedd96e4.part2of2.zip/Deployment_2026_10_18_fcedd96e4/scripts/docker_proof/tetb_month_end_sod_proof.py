"""THE OWNER'S NEXT ASK on the live Docker rig (2026-10-11; record
docs/TETB_MONTH_END_SOD_2026_10_11.html): "join fact_tetb and fact_tetb_ext
and create a complex query with 50+ columns; create feedgen tasks for 2-3
month ends; how is it running by itself; how will SOD be scheduled; if these
jobs are month end how will tasks be created by themselves -- all tested";
then "create 1000 system entity, 2-3 business date, n events".

The case
  ONE feed template -> N entities x E events JOIN feeds (default 1 x 1; the
  owner's scale run is --entities 1000 --events SOD,EOD,ME5), each running the
  SAME complex query on CLOUD (qs-trino, iceberg_aws on the REAL AWS bucket)
  and ON-PREM (qs-trino-sb: --onprem iceberg on MinIO, or --onprem hive), the
  two sides merged UNION ALL BY NAME and delivered as ONE CSV per
  (business date, entity, event) by SFTP.
  The query (build_join: a CTE per table pruned by the three partition
  columns through the OG tokens {BUSINESSDATE} / {SYSTEM_ENTITY} /
  {EventCode}, FULL OUTER JOIN on (business_close_date, code, businessevent,
  source_data_row), 50+ projected columns from BOTH tables: COALESCEd keys,
  CODE || '_' || BUSINESSEVENT, a CASE match state, CASTs, date_format,
  COALESCE(x.col, 'n/a')) is seeded so that per island some rows match and
  some do not: rows only in fact_tetb, rows only in fact_tetb_ext.
  Truth = the two Trino CLIs running the same join, never QueryStudio.

Month ends, BY SOD ITSELF
  A business calendar is created through the product's calendar API
  (ME_<tag>: Sat/Sun weekends + one holiday, 2026-08-03) and the template's
  schedule is {"kind": "month_end", "calendar_name": ME_<tag>}, so the feeds
  are DUE only on the last business day of a month: 2026-07-31 (Fri),
  2026-08-31 (Mon), 2026-09-30 (Wed).  Each day of the walk is driven through
  the SCOPED SOD run-now  POST /api/admin/feeds/sod/run-now?business_date=D
  &template_id=T  (-> {created, already_existed, skipped_by_condition,
  errors, scope, considered}; 202 + a pollable status is handled): a
  month-end creates exactly N*E runs (born WAIT on the message
  dependencies), every other day creates 0 -- an ordinary day is
  skipped_by_condition, a weekend / the holiday ROLLS to the previous
  business day (the product's rule) and reads already_existed -- and a second
  call on a month-end creates 0 (idempotent).  Without the scoped route on the
  build under test the harness SAYS so and refuses to drive the whole estate
  unless --allow-unscoped (then the judge is the DB: this template's rows).

Release and files
  Per month-end: the upstream's COMPLETE messages for every (entity, event,
  table, side) -- half the islands as JSON on the Kafka topic qs.kafka.message
  (rpk, many lines per call), the other half as rows INSERTED into the OG
  QS_KAFKA_MESSAGE table in oracle-db (executemany, never one exec per row)
  -- resolved by the ONE rule of tetb_real_e2e.override.yml; the poller
  releases the runs, the queue worker runs them; every file is read back from
  qs-sftp (ONE docker cp) and judged against the truth: header = the query's
  columns in order, row count and a sorted-rows digest == cloud UNION ALL
  on-prem per island (ONE grouped query per side per date on each Trino), a
  full-row multiset on a random sample, the compared count NON-ZERO, files for
  the three dates distinct.  Throughput per month-end (first message -> last
  file, feeds/min), the queue backlog and the containers' memory peaks are
  reported; an OOM-kill or restart is SAID, never hidden.

"By itself" (--cron)
  The harness prints the operator overlay, sets feed_generation.sod_enabled
  + sod_cron through PUT /api/admin/feeds/config (persisted; the route says
  restart_required), asks the lead to restart the scheduler-lock holder,
  waits for that container's restart, then for the scheduler's OWN SOD fire
  (the boot fire 120 s after start) in the job ledger
  (GET /api/admin/background-jobs/feed_sod_generator/status): a scheduled
  tick whose result is for today -- not a month-end -- so the template's
  feeds read skipped_by_condition and no run row exists for them.  Catch-up
  (feed_generation.sod_catchup_days): if the build exposes it, the pending
  2026-09-30 runs are deleted before the restart and must be re-created by
  the boot pass; else DECLARED.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    docker compose -f docker-compose.local.yml \\
                   -f scripts/docker_proof/compose/tetb_real_e2e.override.yml \\
                   --profile workers up -d kafka api scheduler
    python scripts/docker_proof/tetb_month_end_sod_proof.py --plan
    python scripts/docker_proof/tetb_month_end_sod_proof.py                       # 1 entity x EOD
    python scripts/docker_proof/tetb_month_end_sod_proof.py --entities 5 --events SOD,EOD
    python scripts/docker_proof/tetb_month_end_sod_proof.py --entities 1000 --events SOD,EOD,ME5 \\
        --days sample --finish-timeout 21600                                      # the owner's scale
    python scripts/docker_proof/tetb_month_end_sod_proof.py --cron               # + the scheduler's own fire
    python scripts/docker_proof/tetb_month_end_sod_proof.py --sweep-leftovers [--execute]

Everything this run creates is removed in a finally (proof_cleanup Ledger +
the run rows, the ledger rows, the Oracle rows, the SFTP files);
``--sweep-leftovers`` finds a killed run's objects by name.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feed_dependencies_proof import broker_healthy, broker_running, docker, rpk  # noqa: E402
from feed_triggers_proof import Rig, check, psql, res, wait_until  # noqa: E402
from monthly_kafka_merge_feeds_proof import (  # noqa: E402
    await_template_apply, connections, pick_cloud, sftp_host_key,
)
from proof_cleanup import Ledger, Rule, oracle_admin, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, ORA_SEQ, ORA_TABLE, SB_HOST, SB_PORT, SFTP, TABLES, TOPIC, abbr, cloud_cli, ddl,
    drop_schema_cascade, ensure_oracle_table, load_queries, message, parse_query, sb_cli,
)

os.environ.setdefault("MSYS_NO_PATHCONV", "1")
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
TAG = str(int(time.time()))[-6:]
MONTH_ENDS = (dt.date(2026, 7, 31), dt.date(2026, 8, 31), dt.date(2026, 9, 30))
HOLIDAY = dt.date(2026, 8, 3)                     # a Monday: rolls to Fri 2026-07-31
WALK_FROM, WALK_TO = dt.date(2026, 7, 27), dt.date(2026, 10, 2)
DECOY_DATE = dt.date(2026, 7, 30)                 # an on-prem island on a NON month-end date
WEEKEND = (6, 7)
CLOUD_SCHEMA = f"iceberg_aws.finsme_{TAG}"
CAL_NAME = f"ME_{TAG}"
FEED_PREFIX = "TETBJ"
T_COLS = 22                                       # columns taken from EACH table (+ keys + derived = 54)
MAX_PARTITIONS_PER_INSERT = 90                    # Trino's max-partitions-per-writer is 100
SENT_BY = f"tetb_month_end_sod_proof {TAG}"
CONTAINERS = ("qs-local-scheduler", "qs-local-api", "qs-trino-sb", "qs-trino")


# ── pure parts (unit-tested offline: backend/tests/test_tetb_month_end_sod_harness_2026_10_11.py)

def entity_code(i: int, tag: str = TAG) -> str:
    return f"E{tag}{i:04d}"


def pick_text_columns(types: dict, n: int, exclude=()) -> list:
    """The first ``n`` VARCHAR columns of a parsed owner query, in the
    owner's order, minus the keys and anything in ``exclude``."""
    skip = {"BUSINESS_CLOSE_DATE", "CODE", "BUSINESSEVENT", "SOURCE_DATA_ROW", *exclude}
    out = [c for c, t in types.items() if t == "VARCHAR" and c not in skip]
    if len(out) < n:
        raise SystemExit(f"only {len(out)} text columns to choose from, wanted {n}")
    return out[:n]


class JoinSpec:
    """The complex query: ONE projection shared by the feed SQL (tokens) and
    the bulk truth SQL (one date, every island), so the two cannot drift."""

    def __init__(self, t_table: str, x_table: str, t_cols: list, x_cols: list,
                 x_has_rate: bool = False):
        self.t_table, self.x_table = t_table, x_table
        self.t_cols, self.x_cols = list(t_cols), list(x_cols)
        self.x_has_rate = x_has_rate

    JOIN_ON = ("t.business_close_date = x.business_close_date AND t.code = x.code "
               "AND t.businessevent = x.businessevent AND t.source_data_row = x.source_data_row")

    def projection(self) -> list:
        """``[(alias, expression)]`` -- 10 keys/derived + T_COLS from each side."""
        p = [
            ("BUSINESS_CLOSE_DATE", "COALESCE(t.business_close_date, x.business_close_date)"),
            ("CODE", "COALESCE(t.code, x.code)"),
            ("BUSINESSEVENT", "COALESCE(t.businessevent, x.businessevent)"),
            ("SOURCE_DATA_ROW", "COALESCE(t.source_data_row, x.source_data_row)"),
            ("PARTITION_KEY", "COALESCE(t.code, x.code) || '_' || COALESCE(t.businessevent, x.businessevent)"),
            ("MATCH_STATE", "CASE WHEN t.source_data_row IS NULL THEN 'EXT_ONLY' "
                            "WHEN x.source_data_row IS NULL THEN 'TETB_ONLY' ELSE 'MATCHED' END"),
            ("YYYYMM", "date_format(COALESCE(t.business_close_date, x.business_close_date), '%Y%m')"),
            ("T_SNAP_VERSION_TXT", "CAST(COALESCE(t.snap_version, -1) AS VARCHAR)"),
            ("T_RATE_PCT", "CAST(CAST(COALESCE(t.position_interest_rate, 0) * 100 AS DECIMAL(18, 2)) AS VARCHAR)"),
            ("X_SNAP_VERSION", "COALESCE(x.snap_version, -1)"),
        ]
        p += [(f"T_{c}", f"COALESCE(t.{c.lower()}, 'n/a')") for c in self.t_cols]
        p += [(f"X_{c}", f"COALESCE(x.{c.lower()}, 'n/a')") for c in self.x_cols]
        return p

    def aliases(self) -> list:
        return [a for a, _ in self.projection()]

    def _select(self) -> str:
        return ",\n  ".join(f'{e} AS "{a}"' for a, e in self.projection())

    def feed_sql(self) -> str:
        where = ("business_close_date = CAST('{BUSINESSDATE}' AS DATE) "
                 "AND code = '{SYSTEM_ENTITY}' AND businessevent = '{EventCode}'")
        return (f"WITH t AS (SELECT * FROM {self.t_table} WHERE {where}),\n"
                f"     x AS (SELECT * FROM {self.x_table} WHERE {where})\n"
                f"SELECT\n  {self._select()}\nFROM t FULL OUTER JOIN x ON {self.JOIN_ON}")

    def truth_sql(self, d: dt.date) -> str:
        """ONE grouped query for a date: per (code, event) the row count and
        the rows as canonical text (the CSV cell text joined by ',') sorted
        and joined by chr(30) -- never one query per island."""
        where = f"business_close_date = DATE '{d.isoformat()}'"
        row_text = "concat_ws(',', " + ", ".join(
            f"coalesce(CAST(\"{a}\" AS VARCHAR), '')" for a in self.aliases()) + ")"
        return (f"WITH t AS (SELECT * FROM {self.t_table} WHERE {where}),\n"
                f"     x AS (SELECT * FROM {self.x_table} WHERE {where}),\n"
                f"     j AS (SELECT\n  {self._select()}\nFROM t FULL OUTER JOIN x ON {self.JOIN_ON})\n"
                f"SELECT \"CODE\", \"BUSINESSEVENT\", count(*), "
                f"array_join(array_sort(array_agg({row_text})), chr(30)) FROM j GROUP BY 1, 2")


def narrow_types(parsed_types: dict, cols: list, with_rate: bool) -> dict:
    """The table shape this proof creates: the three partition columns, the
    join key, the two numeric columns and the chosen text columns."""
    t = {"BUSINESS_CLOSE_DATE": "DATE", "CODE": "VARCHAR", "BUSINESSEVENT": "VARCHAR",
         "SOURCE_DATA_ROW": "VARCHAR", "SNAP_VERSION": "BIGINT"}
    if with_rate:
        t["POSITION_INTEREST_RATE"] = "DOUBLE"
    for c in cols:
        t[c] = parsed_types.get(c, "VARCHAR")
    return t


def seed_statements(table: str, types: dict, side: str, entities: range, events, dates,
                    k_lo: int, k_hi: int, tag: str = TAG, per_stmt: int = MAX_PARTITIONS_PER_INSERT):
    """INSERT ... SELECT statements generating the rows ON the cluster (no
    literal rows): per (date, event) and at most ``per_stmt`` entities --
    one Iceberg/Hive partition per entity, under Trino's open-writers cap.
    Row k of entity i: SOURCE_DATA_ROW = '<side>:<code>:<event>:<k>', text
    columns '<abbr><side[0]><k>', BIGINT k, DOUBLE k + 0.5 (the same
    vocabulary tetb_real_e2e_proof.row_values uses)."""
    cols = list(types)
    code = f"'E{tag}' || lpad(CAST(e.i AS VARCHAR), 4, '0')"
    ents = list(entities)
    for d in dates:
        for ev in events:
            for s in range(0, len(ents), per_stmt):
                chunk = ents[s:s + per_stmt]
                exprs = []
                for c in cols:
                    t = types[c]
                    if c == "BUSINESS_CLOSE_DATE":
                        exprs.append(f"DATE '{d.isoformat()}'")
                    elif c == "CODE":
                        exprs.append(code)
                    elif c == "BUSINESSEVENT":
                        exprs.append(f"'{ev}'")
                    elif c == "SOURCE_DATA_ROW":
                        exprs.append(f"'{side}:' || {code} || ':{ev}:' || CAST(r.k AS VARCHAR)")
                    elif t == "DATE":
                        exprs.append(f"DATE '{d.isoformat()}'")
                    elif t == "BIGINT":
                        exprs.append("CAST(r.k AS BIGINT)")
                    elif t == "DOUBLE":
                        exprs.append("CAST(r.k AS DOUBLE) + 0.5")
                    else:
                        exprs.append(f"'{abbr(c)}{side[0]}' || CAST(r.k AS VARCHAR)")
                yield (f"INSERT INTO {table} ({', '.join(c.lower() for c in cols)})\n"
                       f"SELECT {', '.join(exprs)}\n"
                       f"FROM UNNEST(sequence({chunk[0]}, {chunk[-1]})) AS e(i) "
                       f"CROSS JOIN UNNEST(sequence({k_lo}, {k_hi})) AS r(k)")


def previous_business_day_or_today(d: dt.date, weekend=WEEKEND, holidays=(HOLIDAY,)) -> dt.date:
    while d.isoweekday() in weekend or d in holidays:
        d -= dt.timedelta(days=1)
    return d


def sod_expectations(days, month_ends=MONTH_ENDS, weekend=WEEKEND, holidays=(HOLIDAY,)):
    """What the SOD generator must answer for each day of a CHRONOLOGICAL
    walk, mirroring the product's rule (``SodTaskGenerator._process_one``):
    the business date is the day itself or the previous business day; a row
    that exists is ``already``; a month-end (the last business day of its
    month) is ``created``; anything else is ``skipped`` (NOT_DUE).  Returns
    ``[(day, business_date, kind)]`` with kind in created / already /
    skipped."""
    generated = set()
    out = []
    for day in sorted(days):
        bd = previous_business_day_or_today(day, weekend, holidays)
        if bd in generated:
            kind = "already"
        elif bd in month_ends:
            kind = "created"
            generated.add(bd)
        else:
            kind = "skipped"
        out.append((day, bd, kind))
    return out


def sample_days(month_ends=MONTH_ENDS, holiday=HOLIDAY):
    """The representative walk: each month-end with the business day before
    and after, a weekend after one, the holiday, the walk's two ends."""
    days = {WALK_FROM, WALK_TO, holiday, dt.date(2026, 8, 1), dt.date(2026, 8, 2)}
    for me in month_ends:
        days.add(me)
        days.add(previous_business_day_or_today(me - dt.timedelta(days=1), holidays=(holiday,)))
        nxt = me + dt.timedelta(days=1)
        while nxt.isoweekday() in WEEKEND or nxt == holiday:
            nxt += dt.timedelta(days=1)
        days.add(nxt)
    return sorted(days)


def all_days(start=WALK_FROM, end=WALK_TO):
    d, out = start, []
    while d <= end:
        out.append(d)
        d += dt.timedelta(days=1)
    return out


def judge_sod_answer(answer: dict, kind: str, n: int):
    """``(ok, scoped, detail)`` for one run-now answer against the expected
    kind.  A SCOPED answer (it carries ``scope`` / ``considered``) must be
    EXACT: the template's n members, counted once; an UNSCOPED answer is the
    whole estate's, so it can only be a lower bound -- the caller then judges
    by the DB."""
    if not isinstance(answer, dict):
        return False, False, f"not a dict: {str(answer)[:120]}"
    scoped = "scope" in answer or "considered" in answer
    got = tuple(int(answer.get(k) or 0) for k in ("created", "already_existed", "skipped_by_condition"))
    want = {"created": (n, 0, 0), "already": (0, n, 0), "skipped": (0, 0, n)}[kind]
    errors = int(answer.get("errors") or 0)
    if scoped:
        considered = answer.get("considered")
        ok = got == want and errors == 0 and (considered is None or int(considered) == n)
    else:
        ok = all(g >= w for g, w in zip(got, want)) and errors == 0
    detail = (f"{'scoped' if scoped else 'UNSCOPED'} created/already/skipped={got} want {want}"
              f" errors={errors}" + (f" considered={answer.get('considered')}" if scoped else ""))
    return ok, scoped, detail


def canonical(cells) -> str:
    return ",".join("" if c is None else str(c) for c in cells)


def union_digest(row_texts) -> str:
    """md5 of the sorted canonical rows joined by newline -- the same digest
    for a multiset wherever it was read from."""
    return hashlib.md5(("\n".join(sorted(row_texts)) + "\n").encode("utf-8")).hexdigest()


def parse_bulk_truth(tsv: str) -> dict:
    """``{(code, event): (count, [row_text, ...])}`` from truth_sql's TSV."""
    out = {}
    # NOT str.splitlines(): it treats chr(30) (the record separator inside
    # the fourth cell) as a line break -- caught by the offline test
    for line in tsv.replace("\r", "").split("\n"):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) != 4:
            raise RuntimeError(f"truth line has {len(parts)} cells: {line[:120]!r}")
        code, ev, n, joined = parts
        rows = joined.split("\x1e") if joined else []
        if len(rows) != int(n):
            raise RuntimeError(f"truth {code}/{ev}: count {n} but {len(rows)} rows")
        out[(code, ev)] = (int(n), rows)
    return out


def file_name(entity: str, ev: str, d: dt.date, tag: str = TAG) -> str:
    return f"{FEED_PREFIX}_{tag}_{entity}_{ev}_{d.strftime('%Y%m%d')}.csv"


def tick_after(at: str | None, epoch: float) -> bool:
    """Was a ledger tick (``at``, an ISO timestamp) recorded after ``epoch``?"""
    try:
        t = dt.datetime.fromisoformat(str(at).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return False
    if t.tzinfo is None:
        t = t.replace(tzinfo=dt.timezone.utc)
    return t.timestamp() >= epoch


def parse_mem(s: str) -> float:
    """'1.234GiB / 2GiB' -> MiB used."""
    m = re.match(r"\s*([\d.]+)\s*([KMG]i?B)", s or "")
    if not m:
        return 0.0
    v, u = float(m.group(1)), m.group(2)[0]
    return v * {"K": 1 / 1024, "M": 1, "G": 1024}[u]


# ── the rig ───────────────────────────────────────────────────────────────

def await_sod(r: Rig, s: int, body, timeout: int = 3600):
    """A scoped run-now may answer 202 with something to poll (a
    ``status_url``, or a ``job`` / ``job_id``).  Returns ``(status, answer)``
    where the answer is the SodResult-shaped dict."""
    if s != 202:
        return s, body
    body = body or {}
    url = body.get("status_url") or body.get("poll")
    jid = body.get("job_id") or (body.get("job") or {}).get("id") or (body.get("job") or {}).get("job_id")
    if not url and jid:
        url = f"/api/admin/feeds/sod/run-now/{jid}"
    if not url:
        return 202, {"error": f"202 with nothing to poll: {str(body)[:200]}"}

    def _done():
        st, js = r.call("GET", url)
        if st != 200 or not isinstance(js, dict):
            return None
        state = (js.get("state") or js.get("status") or (js.get("job") or {}).get("state") or "").lower()
        if state in ("completed", "done", "finished", "failed", "error"):
            return js
        if "created" in js and "skipped_by_condition" in js and not state:
            return js
        return None
    js, waited = wait_until(_done, timeout, every=3)
    if not js:
        return 504, {"error": f"the SOD job did not finish in {waited}s"}
    result = js.get("result") or (js.get("job") or {}).get("result") or js
    return 200, result


def my_run_rows(tag: str, d: dt.date, where: str = "") -> int:
    return int(psql(f"select count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id "
                    f"where f.name like '{FEED_PREFIX}\\_{tag}\\_%' and r.business_date = '{d}' {where}") or 0)


def ora_bulk_insert(messages, connection_id: int, container: str = "qs-local-api", chunk: int = 1000) -> int:
    """Every message as ONE executemany per chunk through the api container's
    own oracle client (the rows go in on STDIN as JSON; a 36,000-row run
    cannot ride an environment variable)."""
    script = r'''
import json, sys
sys.path.insert(0, "/app")
from core.database import get_db_manager
from core.crypto import decrypt_config
from sqlalchemy import text
import oracledb
cid = int(sys.argv[1]); table = sys.argv[2]; seq = sys.argv[3]; chunk = int(sys.argv[4])
with get_db_manager().get_session() as s:
    raw = s.execute(text("select config from connections where id=%d" % cid)).scalar()
cfg = decrypt_config(json.loads(raw) if isinstance(raw, str) else dict(raw))
conn = oracledb.connect(user=cfg["user"], password=cfg["password"],
                        dsn="oracle-db:%s/%s" % (cfg.get("port", 1521), cfg.get("service_name", "freepdb1")))
cur = conn.cursor()
sql = ("INSERT INTO " + table + " (ID, DATA_STORE, DATA_SOURCE, SOURCE_SYSTEM_NAME, SOURCE_SYSTEM_INSTANCE, "
       "BUSINESS_DATE, CODE, BUSINESS_EVENT, CLOUD_COMPLIANT, \"ORDER\", SNAP_VERSION, VERSION_NUMBER, VERSION, "
       "CATALOGUE_REGISTRATION_TIME, VERSION_STATE, ROW_COUNT, PROCESSED, FK_DEPENDENCY_ID, DATA_LOAD_STATUS) "
       "VALUES (" + seq + ".NEXTVAL, :1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, :7, :8, :9, :10, :11, :12, "
       ":13, :14, :15, 'Y', NULL, :16)")
rows = json.load(sys.stdin)
n = 0
try:
    for i in range(0, len(rows), chunk):
        cur.executemany(sql, rows[i:i + chunk])
        n += len(rows[i:i + chunk])
    conn.commit()
    print("inserted: %d" % n)
except Exception as e:
    conn.rollback()
    print("ERROR: " + str(e).splitlines()[0])
'''
    rows = [[m["DATA_STORE"], m["DATA_SOURCE"], m["SOURCE_SYSTEM_NAME"], m["SOURCE_SYSTEM_INSTANCE"],
             m["BUSINESS_DATE"], m["CODE"], m["BUSINESS_EVENT"], m["CLOUD_COMPLIANT"], m["ORDER"],
             m["SNAP_VERSION"], m["VERSION_NUMBER"], int(m["VERSION"]), m["CATALOGUE_REGISTRATION_TIME"],
             m["VERSION_STATE"], int(m["ROW_COUNT"]), m["DATA_LOAD_STATUS"]] for m in messages]
    p = subprocess.run(["docker", "exec", "-i", container, "python", "-c", script, str(connection_id),
                        ORA_TABLE, ORA_SEQ, str(int(chunk))], input=json.dumps(rows).encode(),
                       capture_output=True, env=DENV, timeout=1800)
    out = p.stdout.decode("utf-8", "replace") + p.stderr.decode("utf-8", "replace")
    m = re.search(r"inserted: (\d+)", out)
    if not m:
        raise RuntimeError(f"oracle bulk insert: {out[-400:]}")
    return int(m.group(1))


def produce_kafka_bulk(messages, per_call: int = 2000) -> int:
    n = 0
    for i in range(0, len(messages), per_call):
        chunk = messages[i:i + per_call]
        rc, out = rpk("topic", "produce", TOPIC, "-f", "%v\\n",
                      stdin="".join(json.dumps(m) + "\n" for m in chunk))
        if rc != 0:
            raise RuntimeError(f"produce failed: {out[-300:]}")
        n += out.count("Produced")
    return n


def run_statements(cli, statements, per_call: int = 12) -> int:
    """Many statements, few CLI calls (the CLI's --file runs them in order
    and stops at the first error)."""
    n = 0
    for i in range(0, len(statements), per_call):
        chunk = statements[i:i + per_call]
        cli(";\n".join(chunk) + ";\n", stdin=True)
        n += len(chunk)
    return n


class Sampler(threading.Thread):
    """docker stats + the queue backlog every ``every`` s; peaks reported."""

    def __init__(self, tag: str, every: int = 20):
        super().__init__(daemon=True)
        self.tag, self.every, self.stop = tag, every, threading.Event()
        self.peak_mib = collections.defaultdict(float)
        self.peak_backlog = 0
        self.samples = 0
        self.errors = 0

    def run(self):
        while not self.stop.is_set():
            try:
                p = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{.Name}}|{{.MemUsage}}",
                                    *CONTAINERS], capture_output=True, text=True, env=DENV, timeout=60)
                for line in p.stdout.splitlines():
                    name, _, mem = line.partition("|")
                    self.peak_mib[name] = max(self.peak_mib[name], parse_mem(mem))
                b = int(psql(f"select count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id "
                             f"where f.name like '{FEED_PREFIX}\\_{self.tag}\\_%' and r.status = 'pending' "
                             f"and r.action_decision = 'RUN'") or 0)
                self.peak_backlog = max(self.peak_backlog, b)
                self.samples += 1
            except Exception:  # noqa: BLE001
                self.errors += 1
            self.stop.wait(self.every)

    def report(self) -> dict:
        return {"samples": self.samples, "errors": self.errors, "peak_backlog_runs": self.peak_backlog,
                "peak_mem_mib": {k: round(v) for k, v in sorted(self.peak_mib.items())}}


def container_health() -> dict:
    out = {}
    for c in CONTAINERS:
        rc, s, _ = docker("inspect", "-f", "{{.RestartCount}} {{.State.OOMKilled}} {{.State.StartedAt}}", c)
        out[c] = s if rc == 0 else "absent"
    return out


def started_at(container: str) -> str:
    return docker("inspect", "-f", "{{.State.StartedAt}}", container)[1]


# ── plan ─────────────────────────────────────────────────────────────────

def plan(args):
    print(__doc__)
    events = [e for e in args.events.split(",") if e.strip()]
    n = args.entities * len(events)
    print("NEEDS")
    print("  containers : qs-local-api, qs-local-scheduler (profile workers), qs-local-postgres, qs-kafka,")
    print("               qs-trino (+ real AWS creds in iceberg_aws), qs-minio, qs-trino-sb, qs-sftp, oracle-db")
    print("  env        : QS_RIG_ADMIN_PW (. ~/.qs_keys/rigpw.sh), QS_SB_ANALYST_PW (. ~/.qs_keys/starburst_like.env)")
    print("  compose    : docker compose -f docker-compose.local.yml \\")
    print("                 -f scripts/docker_proof/compose/tetb_real_e2e.override.yml --profile workers up -d kafka api scheduler")
    print("  connections: a Trino connection on qs-trino (cloud), 'oracle-otg' (the Oracle road)")
    print("  the route  : POST /api/admin/feeds/sod/run-now?business_date=&template_id=  (SCOPED; without it pass --allow-unscoped)")
    print(f"  this run   : {args.entities} entities x {events} = {n} JOIN feeds from ONE template; 3 month-ends -> {3 * n} runs;")
    print(f"               {4 * 3 * n} upstream messages (half Kafka, half Oracle rows); {3 * n} SFTP files; on-prem {args.onprem}; backend {args.backend}")
    print(f"  SOD walk   : {'every day ' + WALK_FROM.isoformat() + '..' + WALK_TO.isoformat() if args.days == 'all' else 'sample ' + ', '.join(d.isoformat() for d in sample_days())}")
    print(f"               + a second call on each month-end (idempotent); calendar {CAL_NAME}: weekends Sat/Sun, holiday {HOLIDAY}")
    print(f"  creates    : schema {CLOUD_SCHEMA} (2 tables, REAL AWS), 2 on-prem tables, 2 saved queries, 1 on-prem connection, 1 calendar,")
    print("               1 feed template + its feeds + runs, SFTP files, Kafka messages, Oracle rows -- all removed in finally")
    print("  --cron     : PUT /api/admin/feeds/config {sod_enabled, sod_cron}; YOU restart the scheduler-lock holder when asked;")
    print("               the harness waits for the restart and the boot fire (120 s) in GET /api/admin/background-jobs/feed_sod_generator/status")
    print("  scale      : --entities 1000 --events SOD,EOD,ME5 --days sample --finish-timeout 21600; seeding is INSERT..SELECT on the")
    print(f"               cluster ({MAX_PARTITIONS_PER_INSERT} partitions per statement), truth is one grouped query per side per date,")
    print("               files come back with ONE docker cp; the queue worker's slots (feed_generation.max_concurrent_native) are the throttle")


# ── main ─────────────────────────────────────────────────────────────────

def main(argv=None):
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--entities", type=int, default=1)
    ap.add_argument("--events", default="EOD")
    ap.add_argument("--rows", type=int, default=2, help="matched rows per island per side (+1 tetb-only, +1 ext-only)")
    ap.add_argument("--onprem", default="iceberg", choices=["iceberg", "hive"])
    ap.add_argument("--backend", default="native", choices=["native", "auto", "spark_k8s"])
    ap.add_argument("--cloud-conn", default="")
    ap.add_argument("--onprem-conn", default="")
    ap.add_argument("--days", default="sample", choices=["sample", "all"])
    ap.add_argument("--hold", type=int, default=30)
    ap.add_argument("--finish-timeout", type=int, default=0, help="s to wait for a month-end's runs (0 = 900 + 20 per run)")
    ap.add_argument("--sample-files", type=int, default=30, help="files compared row by row (the rest by count + digest)")
    ap.add_argument("--allow-unscoped", action="store_true", help="drive the UNSCOPED run-now (the whole estate) when the scoped one is absent")
    ap.add_argument("--cron", action="store_true")
    ap.add_argument("--sod-cron", default="0 0 * * *")
    ap.add_argument("--restart-wait", type=int, default=900)
    ap.add_argument("--keep-rows", action="store_true", help="keep the run / execution rows for inspection")
    ap.add_argument("--plan", action="store_true")
    args = ap.parse_args(rest)
    if args.plan:
        plan(args)
        return 0

    events = [e.strip() for e in args.events.split(",") if e.strip()]
    hive = args.onprem == "hive"
    onprem_schema = f"hive.qsme_{TAG}" if hive else "iceberg.qs"
    onprem_cli = sb_cli if hive else cloud_cli
    r = Rig()
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))

    if sweep:
        rules = [Rule("feed template", rf"{FEED_PREFIX}_\d{{6}}", list_path="/api/feed-templates",
                      delete_path="/api/feed-templates/{id}?delete_members=true"),
                 Rule("feed", rf"{FEED_PREFIX}_\d{{6}}_E\d{{10}}_[A-Za-z0-9]+", list_path="/api/feeds",
                      delete_path="/api/feeds/{id}"),
                 Rule("saved query", r"tetbj_(cloud|onprem)_\d{6}", list_path="/api/queries", delete_path="/api/queries/{id}"),
                 Rule("connection", r"sb-onprem-tetbj-\d{6}", list_path="/api/connections", delete_path="/api/connections/{id}"),
                 Rule("calendar", r"ME_\d{6}", list_path="/api/admin/feed-calendars", delete_path="/api/admin/feed-calendars/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for t in [x.strip().strip('"') for x in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'finsme_%'").splitlines()]:
            if re.fullmatch(r"finsme_\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{t} (cascade)")
                if execute:
                    print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{t}"))
        for t in [x.strip().strip('"') for x in cloud_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%me%'").splitlines()]:
            if re.fullmatch(r"fact_tetb(_ext)?_me\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    cloud_cli(f"DROP TABLE iceberg.qs.{t}")
        try:
            for t in [x.strip().strip('"') for x in sb_cli("SHOW SCHEMAS FROM hive LIKE 'qsme_%'").splitlines()]:
                if re.fullmatch(r"qsme_\d{6}", t):
                    print(f"  {'drop' if execute else 'would drop'} hive schema {t}")
                    if execute:
                        print("   ", drop_schema_cascade(sb_cli, f"hive.{t}"))
        except Exception as exc:  # noqa: BLE001
            print(f"  (hive catalog not swept: {str(exc)[:120]})")
        print(f"  {'delete' if execute else 'would delete'} run / execution / ledger rows of feeds {FEED_PREFIX}_<tag>_*")
        if execute:
            psql(f"delete from feed_runs where feed_config_id in (select id from feed_configs where name like '{FEED_PREFIX}\\_______\\_%')")
            psql(f"delete from feed_executions where feed_config_id in (select id from feed_configs where name like '{FEED_PREFIX}\\_______\\_%')")
            psql("delete from kafka_messages where payload like '%tetb_month_end_sod_proof%'")
            psql("delete from dependency_events where dependency_name ~ '^finance_sl_balance(_ext)?_E[0-9]{10}_'")
            docker("exec", SFTP["container"], "sh", "-c", f"rm -f {SFTP['home']}/{FEED_PREFIX}_*.csv")
        ora = next((x["id"] for x in connections(r) if x.get("name") == "oracle-otg"), None)
        if ora:
            print(f"  {'delete' if execute else 'would delete'} {ORA_TABLE} rows with CODE ~ ^E[0-9]{{10}}$")
            if execute:
                oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE REGEXP_LIKE(CODE, '^E[0-9]{{10}}$')"], connection_id=ora)
        return rc

    # ── preflight ───────────────────────────────────────────────────────
    n = args.entities * len(events)
    print(f"\n== preflight (tag {TAG}, {args.entities} x {events} = {n} join feeds, 3 month-ends, on-prem {args.onprem}, backend {args.backend})")
    check("P0 qs-kafka is running", broker_running())
    if not broker_running():
        return 2
    healthy, secs = wait_until(broker_healthy, 120, 5)
    check(f"P0 the broker is healthy ({secs}s)", healthy)
    rc, out = rpk("topic", "create", TOPIC, "-p", "1", "-r", "1")
    check("P0 the owner's topic exists", rc == 0 or "already exists" in out or "ALREADY_EXISTS" in out, out[-120:])
    s, st = r.call("GET", "/api/admin/background-jobs/feed_kafka_arrivals/status")
    text = json.dumps(st) if isinstance(st, dict) else str(st)
    check("P1 the Kafka consumer is RUNNING with the owner's topic subscribed", s == 200 and '"running": true' in text and TOPIC in text, text[:300])
    s, v = r.call("GET", "/api/feed-arrival-sources")
    kinds = {k["kind"]: k for k in ((v or {}).get("kinds") or [])} if isinstance(v, dict) else {}
    check("P1 kafka and oracle_table producers are UP",
          all(k in kinds and (kinds[k].get("producer_health") or {}).get("state") == "up" for k in ("oracle_table", "kafka")),
          {k: (kinds.get(k) or {}).get("producer_health") for k in ("oracle_table", "kafka")})
    for c in (SFTP["container"], SB_HOST, "oracle-db", "qs-trino", "qs-local-scheduler"):
        check(f"P2 {c} is running", docker("inspect", "-f", "{{.State.Running}}", c)[1] == "true")
    s, sodst = r.call("GET", "/api/admin/background-jobs/feed_sod_generator/status")
    check("P2 the SOD generator is a ledgered background job (GET .../feed_sod_generator/status)",
          s == 200 and isinstance(sodst, dict) and "sod_enabled" in json.dumps(sodst), str(sodst)[:300])
    s, fcfg = r.call("GET", "/api/admin/feeds/config")
    print(f"   operator overlay as the api reads it: sod_enabled={ (fcfg or {}).get('sod_enabled')} sod_cron={(fcfg or {}).get('sod_cron')!r} "
          f"max_concurrent_native={(fcfg or {}).get('max_concurrent_native')} queue_worker_enabled={(fcfg or {}).get('queue_worker_enabled')}")
    host_key = sftp_host_key()
    items = connections(r)
    cloud_id, cloud_name = pick_cloud(r, args.cloud_conn)
    ora_id = next((x["id"] for x in items if x.get("name") == "oracle-otg"), None)
    check(f"P3 connections: cloud {cloud_name} (id {cloud_id}), oracle-otg (id {ora_id})", ora_id is not None)
    if ora_id is None:
        return 2
    if hive:
        cats = sb_cli("SHOW CATALOGS")
        check("P4 qs-trino-sb has the hive catalog", "hive" in cats.split(), cats)
        if "hive" not in cats.split():
            return 2
    check(f"P5 the OG table {ORA_TABLE} is in the rig's Oracle ({ensure_oracle_table(ora_id)})", True)
    if args.onprem_conn:
        hit = next((x for x in items if str(x.get("id")) == args.onprem_conn or x.get("name") == args.onprem_conn), None)
        if not hit:
            raise SystemExit(f"--onprem-conn {args.onprem_conn!r}: no such connection")
        prem_id, prem_name = hit["id"], hit["name"]
    else:
        pw = os.environ.get("QS_SB_ANALYST_PW")
        if not pw:
            raise SystemExit("QS_SB_ANALYST_PW is not set: . ~/.qs_keys/starburst_like.env")
        catalog, schema = ("hive", f"qsme_{TAG}") if hive else ("iceberg", "qs")
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-tetbj-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic", "password": pw,
                       "http_scheme": "https", "verify_ssl": False, "catalog": catalog, "schema": schema}})
        if s not in (200, 201) or not (b or {}).get("id"):
            raise SystemExit(f"on-prem connection: {s} {str(b)[:300]}")
        prem_id, prem_name = b["id"], f"sb-onprem-tetbj-{TAG}"
        ledger.add("connection", prem_name, path=f"/api/connections/{prem_id}")
    check(f"P6 on-prem connection {prem_name} (id {prem_id}) differs from the cloud one", prem_id != cloud_id)

    # ── the query, from the owner's two fixtures ────────────────────────
    t_cloud_sql, _ = load_queries(TABLES["tetb"])
    x_cloud_sql, x_prem_sql = load_queries(TABLES["ext"])
    _, t_types = parse_query(t_cloud_sql, "FACT_TETB")
    _, xc_types = parse_query(x_cloud_sql, "FACT_TETB_EXT")
    _, xp_types = parse_query(x_prem_sql, "FACT_TETB_EXT")
    x_common = {c: t for c, t in xc_types.items() if c in xp_types}
    t_cols = pick_text_columns(t_types, T_COLS)
    x_cols = pick_text_columns(x_common, T_COLS)
    t_shape = narrow_types(t_types, t_cols, with_rate=True)
    x_shape = narrow_types(x_common, x_cols, with_rate=False)
    cloud_t, cloud_x = f"{CLOUD_SCHEMA}.fact_tetb", f"{CLOUD_SCHEMA}.fact_tetb_ext"
    prem_t = f"{onprem_schema}.fact_tetb" if hive else f"{onprem_schema}.fact_tetb_me{TAG}"
    prem_x = f"{onprem_schema}.fact_tetb_ext" if hive else f"{onprem_schema}.fact_tetb_ext_me{TAG}"
    cloud_spec = JoinSpec(cloud_t, cloud_x, t_cols, x_cols)
    prem_spec = JoinSpec(prem_t, prem_x, t_cols, x_cols)
    aliases = cloud_spec.aliases()
    check(f"Q1 the join query projects {len(aliases)} columns from BOTH tables ({T_COLS} text columns each + keys + derived), "
          f"the same list on both sides, every column name unique",
          len(aliases) >= 50 and len(set(aliases)) == len(aliases) and prem_spec.aliases() == aliases
          and sum(a.startswith("T_") for a in aliases) >= T_COLS and sum(a.startswith("X_") for a in aliases) >= T_COLS)
    check("Q1 ...with the three OG tokens in BOTH pruned CTEs and a FULL OUTER JOIN on the four-column key",
          cloud_spec.feed_sql().count("{BUSINESSDATE}") == 2 and cloud_spec.feed_sql().count("{SYSTEM_ENTITY}") == 2
          and cloud_spec.feed_sql().count("{EventCode}") == 2 and "FULL OUTER JOIN" in cloud_spec.feed_sql())

    entities = [entity_code(i) for i in range(args.entities)]
    islands = [(e, ev) for e in entities for ev in events]
    R = args.rows
    timings, feeds, template_id, cal_id = {}, {}, None, None
    sampler = Sampler(TAG)
    cfg_before = {}
    inbox = None
    health0 = container_health()

    try:
        # ── the calendar ────────────────────────────────────────────────
        print(f"\n== the business calendar {CAL_NAME} (Sat/Sun + holiday {HOLIDAY}) through the product's calendar API")
        s, cal = r.call("POST", "/api/admin/feed-calendars", {"name": CAL_NAME, "weekend_days": [6, 7],
                                                              "description": SENT_BY})
        check(f"CAL1 POST /api/admin/feed-calendars -> {s}", s == 201 and (cal or {}).get("id"), str(cal)[:200])
        if s != 201:
            raise SystemExit("no calendar")
        cal_id = cal["id"]
        def _drop_calendar(cid=cal_id):
            # The product refuses to delete a calendar any feed still names --
            # a RETIRED feed included (re-activating it would otherwise run it on
            # "every day is a business day").  Detach first, as its 409 says.
            _, feeds = r.call("GET", "/api/feeds?include_inactive=true")
            feeds = feeds if isinstance(feeds, list) else (feeds or {}).get("items") or (feeds or {}).get("feeds") or []
            for f in feeds:
                if (f.get("calendar_name") or "") == CAL_NAME:
                    r.call("PUT", f"/api/feeds/{f['id']}", {"calendar_name": None})
            s_, b_ = r.call("DELETE", f"/api/admin/feed-calendars/{cid}")
            return (s_ in (200, 204, 404), f"HTTP {s_}: {str(b_)[:160]}")
        ledger.add("calendar", CAL_NAME, remover=_drop_calendar)
        s, h = r.call("POST", f"/api/admin/feed-calendars/{cal_id}/holidays",
                      {"holiday_date": HOLIDAY.isoformat(), "holiday_name": "proof holiday (rolls to the month-end)"})
        check(f"CAL2 holiday {HOLIDAY} added -> {s}", s == 201, str(h)[:200])

        # ── seed both sides, both tables, all three dates ───────────────
        print(f"\n== seeding: cloud = REAL AWS ({CLOUD_SCHEMA}), on-prem = {onprem_schema} on qs-trino-sb; {len(islands)} islands x 3 dates, generated ON the clusters")
        t0 = time.time()
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/finsme_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        if hive:
            sb_cli(f"CREATE SCHEMA {onprem_schema}")
            ledger.add("hive schema", onprem_schema, remover=lambda: drop_schema_cascade(sb_cli, onprem_schema))
        for table, shape in ((cloud_t, t_shape), (cloud_x, x_shape)):
            loc = f"s3://{AWS_BUCKET}/iceberg/finsme_{TAG}/{table.rsplit('.', 1)[1]}"
            cloud_cli(ddl(table, shape, hive=False, location=loc) + ";\n", stdin=True)
        for table, shape in ((prem_t, t_shape), (prem_x, x_shape)):
            onprem_cli(ddl(table, shape, hive=hive) + ";\n", stdin=True)
            if not hive:
                ledger.add("on-prem table", table, remover=lambda t=table: (bool(onprem_cli(f"DROP TABLE {t}") is not None), "dropped"))
        ents = range(0, args.entities)
        decoy_ents = range(0, min(3, args.entities))
        decoy_events = [f"X{ev}" for ev in events]
        # the join: cloud tetb k in [0, R], ext k in [1, R+1]  -> k=0 tetb-only, k=R+1 ext-only
        #           on-prem tetb k in [0, R+1], ext k in [2, R+2] -> two tetb-only, one ext-only
        jobs = [
            ("cloud", cloud_cli, [*seed_statements(cloud_t, t_shape, "cloud", ents, events, MONTH_ENDS, 0, R),
                                  *seed_statements(cloud_x, x_shape, "cloud", ents, events, MONTH_ENDS, 1, R + 1),
                                  *seed_statements(cloud_t, t_shape, "cloud", decoy_ents, decoy_events, MONTH_ENDS, 0, 0)]),
            ("onprem", onprem_cli, [*seed_statements(prem_t, t_shape, "prem", ents, events, MONTH_ENDS, 0, R + 1),
                                    *seed_statements(prem_x, x_shape, "prem", ents, events, MONTH_ENDS, 2, R + 2),
                                    *seed_statements(prem_t, t_shape, "prem", decoy_ents, events, (DECOY_DATE,), 0, 0)]),
        ]
        results, errors = {}, {}

        def _seed(name, cli, stmts):
            try:
                results[name] = run_statements(cli, stmts)
            except Exception as exc:  # noqa: BLE001
                errors[name] = str(exc)[:400]
        threads = [threading.Thread(target=_seed, args=j) for j in jobs]
        [t.start() for t in threads]
        [t.join() for t in threads]
        timings["seed_s"] = round(time.time() - t0, 1)
        check(f"S1 seeded both sides in {timings['seed_s']}s: {results} statements ran, no errors", not errors and len(results) == 2, errors)
        if errors:
            raise SystemExit("seeding failed")
        expect_cloud = {(e, ev): R + 2 for e, ev in islands}          # keys 0..R+1
        expect_prem = {(e, ev): R + 3 for e, ev in islands}           # keys 0..R+2

        # ── the truth: one grouped query per side per date ─────────────
        t0 = time.time()
        truths = {}                                                   # (date, side) -> {(code, ev): (count, rows)}
        for d in MONTH_ENDS:
            truths[(d, "cloud")] = parse_bulk_truth(cloud_cli(cloud_spec.truth_sql(d) + "\n", stdin=True))
            truths[(d, "prem")] = parse_bulk_truth(sb_cli(prem_spec.truth_sql(d) + "\n", stdin=True))
        timings["truth_s"] = round(time.time() - t0, 1)
        ms_idx = aliases.index("MATCH_STATE")
        off = []
        states_seen = set()
        for d in MONTH_ENDS:
            for isl in islands:
                c = truths[(d, "cloud")].get(isl)
                p = truths[(d, "prem")].get(isl)
                if not c or not p or c[0] != expect_cloud[isl] or p[0] != expect_prem[isl]:
                    off.append((d.isoformat(), isl, c and c[0], p and p[0]))
                    continue
                for row in c[1] + p[1]:
                    states_seen.add(row.split(",")[ms_idx])
        check(f"T1 the truth ({timings['truth_s']}s, 6 grouped queries): every island on every date has {R + 2} cloud + {R + 3} on-prem "
              f"join rows on the two CLIs, and the join MATCHED some rows and NOT others: {sorted(states_seen)}",
              not off and states_seen == {"MATCHED", "TETB_ONLY", "EXT_ONLY"}, off[:5])
        check(f"T1 ...a non-empty truth: {sum(c for c, _ in truths[(MONTH_ENDS[0], 'cloud')].values())} cloud join rows on {MONTH_ENDS[0]}",
              sum(c for c, _ in truths[(MONTH_ENDS[0], "cloud")].values()) > 0)

        # ── the saved queries + the template ───────────────────────────
        s, q1 = r.call("POST", "/api/queries", {"name": f"tetbj_cloud_{TAG}", "query_config": {"files": [], "raw_sql": cloud_spec.feed_sql(), "connection_id": cloud_id}})
        s2, q2 = r.call("POST", "/api/queries", {"name": f"tetbj_onprem_{TAG}", "query_config": {"files": [], "raw_sql": prem_spec.feed_sql(), "connection_id": prem_id}})
        check(f"A0 the join query is saved for both sides ({s}, {s2})", s in (200, 201) and s2 in (200, 201), (str(q1)[:200], str(q2)[:200]))
        ledger.add("saved query", q1["name"], path=f"/api/queries/{q1['id']}")
        ledger.add("saved query", q2["name"], path=f"/api/queries/{q2['id']}")
        both_roads = [{"kind": "kafka", "topic": TOPIC}, {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
        deps = []
        for ds in ("finance_sl_balance", "finance_sl_balance_ext"):
            for side in ("CLOUD", "ONPREM"):
                deps.append({"dependency_type": "KAFKA", "dependency_key": f"{ds}_{{SYSTEM_ENTITY}}_{{EventCode}}_{side}",
                             "description": f"{ds} {side.lower()} load COMPLETE (either road)",
                             "arrival_sources": both_roads, "require_mode": "any"})
        template = {
            "name": f"{FEED_PREFIX}_{TAG}", "description": f"{SENT_BY}: fact_tetb JOIN fact_tetb_ext, cloud + on-prem, month-end by SOD",
            "parameters": ["SYSTEM_ENTITY", "EventCode"],
            "feed": {
                "name": f"{FEED_PREFIX}_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}",
                "display_name": f"{FEED_PREFIX} {{SYSTEM_ENTITY}} / {{EventCode}}",
                "source_type": "saved_query", "source_id": q1["id"], "connection_id": cloud_id,
                "secondary_connection_id": prem_id, "secondary_source_type": "saved_query", "secondary_source_id": q2["id"],
                "combine_mode": "union", "output_format": "csv",
                "output_filename_template": f"{FEED_PREFIX}_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}_{{business_date:YYYYMMDD}}.csv",
                "destination_type": "sftp",
                "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                       "password": SFTP["password"], "remote_dir": SFTP["remote_dir"], "host_key_b64": host_key},
                "schedule_declaration": {"kind": "month_end", "calendar_name": CAL_NAME},
                "calendar_name": CAL_NAME,
                "execution_backend": args.backend, "notify_on_failure": False,
            },
            "dependencies": deps,
            "matrix": [{"SYSTEM_ENTITY": e, "EventCode": v} for e, v in islands],
        }
        print(f"\n== A one template -> {n} month-end JOIN feeds, four dependencies each (2 tables x 2 sides, either road)")
        t0 = time.time()
        s, body = r.call("POST", "/api/feed-templates", template, timeout=3600)
        s, rep, mode = await_template_apply(r, s, body)
        counts = rep.get("counts") or {}
        timings["bulk_create_s"] = round(time.time() - t0, 1)
        check(f"A1 POST /api/feed-templates created {n} feeds in {timings['bulk_create_s']}s ({mode}; {round(timings['bulk_create_s'] / max(1, n) * 1000)} ms/feed): {counts}",
              s == 201 and counts.get("created") == n and not counts.get("refused") and not counts.get("conflicts"),
              {"status": s, "refused": (rep.get("refused") or [])[:3], "body": str(body)[:300] if s != 201 else ""})
        if s != 201:
            raise SystemExit(f"template: {s} {str(body)[:400]} {str(rep)[:400]}")
        template_id = body["template"]["id"]
        ledger.add("feed template", template["name"], path=f"/api/feed-templates/{template_id}?delete_members=true")
        for c in rep.get("created") or []:
            feeds[(c["values"]["SYSTEM_ENTITY"], c["values"]["EventCode"])] = c["feed_id"]
        fid0 = feeds[islands[0]]
        _, f0 = r.call("GET", f"/api/feeds/{fid0}")
        _, d0 = r.call("GET", f"/api/feeds/{fid0}/dependencies")
        dkeys = sorted(x["dependency_key"] for x in ((d0 or {}).get("items") or []))
        check("A2 a member is month_end on the calendar and declares the four dependencies",
              (f0 or {}).get("schedule_declaration", {}).get("kind") == "month_end" and (f0 or {}).get("calendar_name") == CAL_NAME
              and dkeys == sorted(f"{ds}_{islands[0][0]}_{islands[0][1]}_{sd}" for ds in ("finance_sl_balance", "finance_sl_balance_ext") for sd in ("CLOUD", "ONPREM")),
              {"sched": (f0 or {}).get("schedule_declaration"), "cal": (f0 or {}).get("calendar_name"), "deps": dkeys})

        # ── B: SOD, day by day ──────────────────────────────────────────
        days = all_days() if args.days == "all" else sample_days()
        walk = sod_expectations(days)
        print(f"\n== B SOD by itself: {len(walk)} days {walk[0][0]}..{walk[-1][0]} through the scoped run-now (template {template_id})")
        scoped_seen = None
        bad, generated_dates = [], []
        t0 = time.time()
        for day, bd, kind in walk:
            s, body = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={day.isoformat()}&template_id={template_id}", timeout=3600)
            s, ans = await_sod(r, s, body)
            ok, scoped, detail = judge_sod_answer(ans if isinstance(ans, dict) else {}, kind, n)
            if scoped_seen is None:
                scoped_seen = scoped
                if not scoped:
                    check("B0 the SCOPED run-now (template_id -> scope/considered) is on this build",
                          False, f"the answer has no scope: {str(ans)[:200]} -- the route ran the WHOLE estate "
                                 f"({'continuing unscoped, the DB judges' if args.allow_unscoped else 'SOD NOT PROVEN: falling back to a per-date backfill so the rest can run'})")
                    if not args.allow_unscoped:
                        # the first UNSCOPED call already created every active feed's
                        # row for this day; the fallback creates THIS template's
                        # month-end runs the only other way the product offers
                        made = 0
                        for me in MONTH_ENDS:
                            for fid in feeds.values():
                                if my_run_rows(TAG, me) >= n:
                                    break
                                sb, bb = r.call("POST", f"/api/feeds/{fid}/backfill", {
                                    "start_date": me.isoformat(), "end_date": me.isoformat(), "deliver": True,
                                    "reason": f"{SENT_BY}: SOD fallback (the scoped run-now is not on this build), test data only"})
                                made += int(sb == 200 and (((bb or {}).get("summary") or {}).get("created") == 1))
                        print(f"DECL B1/B2 NOT PROVEN on this build (no scoped run-now): {made} month-end runs created by backfill instead; "
                              f"the walk's expectations stand in sod_expectations() and the offline test")
                        generated_dates = list(MONTH_ENDS)
                        break
                else:
                    check("B0 the SCOPED run-now (template_id -> scope/considered) is on this build", True, detail)
            rows_now = my_run_rows(TAG, bd)
            want_rows = n if kind in ("created", "already") else 0
            waiting = my_run_rows(TAG, bd, "and r.action_decision = 'WAIT' and r.status = 'pending'")
            db_ok = rows_now == want_rows and (kind != "created" or waiting == n)
            if not (s == 200 and ok and db_ok):
                bad.append((day.isoformat(), bd.isoformat(), kind, s, detail, f"rows={rows_now} waiting={waiting}"))
            if kind == "created":
                generated_dates.append(bd)
                s2, body2 = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={day.isoformat()}&template_id={template_id}", timeout=3600)
                s2, ans2 = await_sod(r, s2, body2)
                ok2, _, detail2 = judge_sod_answer(ans2 if isinstance(ans2, dict) else {}, "already", n)
                if not (s2 == 200 and ok2 and my_run_rows(TAG, bd) == n):
                    bad.append((day.isoformat(), bd.isoformat(), "idempotent", s2, detail2, f"rows={my_run_rows(TAG, bd)}"))
        timings["sod_walk_s"] = round(time.time() - t0, 1)
        kinds = collections.Counter(k for _, _, k in walk)
        if scoped_seen or args.allow_unscoped:
            check(f"B1 {len(walk)} days in {timings['sod_walk_s']}s: {kinds['created']} month-ends created exactly {n} runs each (born WAIT), "
                  f"{kinds['skipped']} ordinary days skipped_by_condition, {kinds['already']} weekend/holiday days rolled to a generated "
                  f"business day (already_existed), 3 second calls created 0 (idempotent)",
                  not bad and generated_dates == list(MONTH_ENDS), bad[:6])
        check(f"B2 exactly {3 * n} runs exist for this template, all for the three month-ends, all WAIT",
              my_run_rows(TAG, MONTH_ENDS[0]) + my_run_rows(TAG, MONTH_ENDS[1]) + my_run_rows(TAG, MONTH_ENDS[2]) == 3 * n
              and int(psql(f"select count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id where f.name like '{FEED_PREFIX}\\_{TAG}\\_%'") or 0) == 3 * n
              and int(psql(f"select count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id where f.name like '{FEED_PREFIX}\\_{TAG}\\_%' and r.action_decision = 'WAIT'") or 0) == 3 * n)
        time.sleep(args.hold)
        ran = int(psql(f"select count(*) from feed_executions e join feed_configs f on f.id = e.feed_config_id where f.name like '{FEED_PREFIX}\\_{TAG}\\_%'") or 0)
        row0 = r.run_row(fid0, MONTH_ENDS[0].isoformat())
        # the hold names at most THREE keys and says "(+1 more)" for the fourth
        reason0 = (row0 or {}).get("reason") or ""
        check(f"B3 after {args.hold}s nothing ran ({ran} executions); the hold names the dependencies (3 + '+1 more')",
              ran == 0 and row0 and reason0.startswith("waiting on") and reason0.count("finance_sl_balance") >= 3
              and ("+1 more" in reason0 or reason0.count("finance_sl_balance") == 4), row0)

        # ── C: --cron, the scheduler's own fire ────────────────────────
        if args.cron:
            print("\n== C 'by itself': the scheduler's OWN SOD fire after a restart")
            cfg_before = {k: (fcfg or {}).get(k) for k in ("sod_enabled", "sod_cron")}
            catchup_key = "sod_catchup_days" if "sod_catchup_days" in (fcfg or {}) else None
            payload = {"sod_enabled": True, "sod_cron": args.sod_cron}
            if catchup_key:
                cfg_before[catchup_key] = fcfg.get(catchup_key)
                payload[catchup_key] = (dt.date.today() - MONTH_ENDS[-1]).days + 1
                deleted = psql(f"with d as (delete from feed_runs where id in (select r.id from feed_runs r join feed_configs f on f.id = r.feed_config_id "
                               f"where f.name like '{FEED_PREFIX}\\_{TAG}\\_%' and r.business_date = '{MONTH_ENDS[-1]}') returning 1) select count(*) from d")
                print(f"   catch-up: {catchup_key} exposed -> set to {payload[catchup_key]}; deleted the {deleted} pending {MONTH_ENDS[-1]} runs for the boot pass to re-create")
            else:
                print("DECL C-catchup feed_generation.sod_catchup_days is not exposed by GET /api/admin/feeds/config on this build -- not proven here")
            s, pb = r.call("PUT", "/api/admin/feeds/config", payload)
            check(f"C1 PUT /api/admin/feeds/config {payload} -> {s}; restart_required said", s == 200 and "sod_enabled" in ((pb or {}).get("restart_required") or []), str(pb)[:300])
            s, g = r.call("GET", "/api/admin/feeds/config")
            check("C1 ...GET shows the overlay persisted", (g or {}).get("sod_enabled") is True and (g or {}).get("sod_cron") == args.sod_cron, str(g)[:200])
            holder = "qs-local-scheduler"
            try:
                lock = psql("select instance_id from scheduler_lock limit 1")
                print(f"   scheduler lock holder: {lock!r}")
                if lock and "api" in lock.lower() and "scheduler" not in lock.lower():
                    holder = "qs-local-api"
            except Exception as exc:  # noqa: BLE001
                print(f"   (scheduler_lock not readable: {str(exc)[:120]})")
            before = started_at(holder)
            print(f"\n   LEAD: please restart the scheduler-lock holder now ({holder}); the harness waits up to {args.restart_wait}s:\n"
                  f"     docker compose -f docker-compose.local.yml -f scripts/docker_proof/compose/tetb_real_e2e.override.yml --profile workers restart {holder.replace('qs-local-', '')}\n", flush=True)
            restarted, secs = wait_until(lambda: started_at(holder) != before, args.restart_wait, 5)
            check(f"C2 {holder} was restarted ({secs}s)", bool(restarted))
            if restarted:
                t_restart = time.time()

                def _fired():
                    st, js = r.call("GET", "/api/admin/background-jobs/feed_sod_generator/status")
                    if st != 200:
                        return None
                    for t in (js or {}).get("recent_ticks") or []:
                        if t.get("trigger") == "scheduled" and tick_after(t.get("at"), t_restart - 60):
                            return {"tick": t, "scheduled": (js or {}).get("scheduled"), "answered_by": (js or {}).get("answered_by")}
                    return None
                fired, secs = wait_until(_fired, 420, 10)
                today = dt.datetime.now(dt.timezone.utc).date()
                res_ = ((fired or {}).get("tick") or {}).get("result") or {}
                check(f"C3 the scheduler's OWN SOD fire (boot fire 120 s after start) is in the job ledger ({secs}s): "
                      f"outcome={((fired or {}).get('tick') or {}).get('outcome')} reason={((fired or {}).get('tick') or {}).get('reason')!r}",
                      bool(fired) and res_.get("business_date") == today.isoformat() and int(res_.get("errors") or 0) == 0, fired)
                check(f"C4 today ({today}, business day {previous_business_day_or_today(today)}) is not a month-end: the template's feeds were "
                      f"skipped_by_condition (>= {n}) and have no run row for it",
                      int(res_.get("skipped_by_condition") or 0) >= n and my_run_rows(TAG, previous_business_day_or_today(today)) == 0, res_)
                check(f"C5 the job is registered on the owner with the cron {args.sod_cron!r}",
                      ((fired or {}).get("scheduled") or {}).get("registered") is True, (fired or {}).get("scheduled"))
                if catchup_key:
                    rows_c, secs = wait_until(lambda: (lambda v: v if v == n else None)(my_run_rows(TAG, MONTH_ENDS[-1])), 300, 10)
                    check(f"C6 catch-up: the missed {MONTH_ENDS[-1]} (within {payload[catchup_key]} days) was re-created by the boot pass ({secs}s): {my_run_rows(TAG, MONTH_ENDS[-1])}/{n}",
                          rows_c == n)

        # ── D/E/F: per month-end, release, run, judge the files ─────────
        sampler.start()
        kafka_islands = set(islands[0::2])
        seq = 1
        per_date = {}
        inbox = tempfile.mkdtemp(prefix=f"tetbj_{TAG}_")
        rng = random.Random(TAG)
        sample_keys = set(rng.sample([(d, isl) for d in MONTH_ENDS for isl in islands], min(args.sample_files, 3 * len(islands))))
        compared_rows, bad_files, digests = 0, [], {}
        for d in MONTH_ENDS:
            print(f"\n== D {d}: the upstream's COMPLETE messages ({4 * len(islands)}: half Kafka, half Oracle rows) release {n} runs")
            msgs = {"kafka": [], "oracle_table": []}
            for isl in islands:
                e, ev = isl
                road = "kafka" if isl in kafka_islands else "oracle_table"
                for ds, cnt_c, cnt_p in (("finance_sl_balance", R + 1, R + 2), ("finance_sl_balance_ext", R + 1, R + 1)):
                    m1 = message(ds, e, ev, d, True, "COMPLETE", cnt_c, seq); m1["sent_by"] = SENT_BY; seq += 1
                    m2 = message(ds, e, ev, d, False, "COMPLETE", cnt_p, seq); m2["sent_by"] = SENT_BY; seq += 1
                    msgs[road] += [m1, m2]
            t_send = time.time()
            nk = produce_kafka_bulk(msgs["kafka"]) if msgs["kafka"] else 0
            no = ora_bulk_insert(msgs["oracle_table"], ora_id) if msgs["oracle_table"] else 0
            check(f"D1 sent {nk} Kafka messages + {no} Oracle rows in {round(time.time() - t_send, 1)}s", nk + no == 4 * len(islands))

            def released():
                v = my_run_rows(TAG, d, "and r.action_decision = 'RUN'")
                return v if v >= n else None
            rel, secs = wait_until(released, 600 + n, 5)
            check(f"D2 the poller released all {n} runs of {d} ({secs}s after the send)", rel == n,
                  psql(f"select r.action_decision, r.status, count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id where f.name like '{FEED_PREFIX}\\_{TAG}\\_%' and r.business_date = '{d}' group by 1, 2"))

            def done():
                v = my_run_rows(TAG, d, "and r.status in ('completed', 'failed', 'cancelled')")
                return v if v >= n else None
            budget = args.finish_timeout or (900 + n * 20)
            last_print = time.time()
            t_wait0 = time.time()
            fin = None
            while time.time() - t_wait0 < budget:
                fin = done()
                if fin:
                    break
                if time.time() - last_print > 60:
                    print(f"   ... {my_run_rows(TAG, d, 'and r.status = ' + chr(39) + 'completed' + chr(39))}/{n} completed, "
                          f"{my_run_rows(TAG, d, 'and r.status = ' + chr(39) + 'running' + chr(39))} running, {round(time.time() - t_send)}s", flush=True)
                    last_print = time.time()
                time.sleep(10)
            elapsed = round(time.time() - t_send)
            completed = my_run_rows(TAG, d, "and r.status = 'completed'")
            failed = my_run_rows(TAG, d, "and r.status = 'failed'")
            per_date[d.isoformat()] = {"first_message_to_last_run_s": elapsed, "completed": completed, "failed": failed,
                                       "feeds_per_min": round(n / max(1, elapsed) * 60, 1)}
            check(f"E1 {d}: all {n} finished in {elapsed}s ({per_date[d.isoformat()]['feeds_per_min']} feeds/min): {completed} completed, {failed} failed",
                  fin == n and completed == n,
                  psql(f"select r.status, count(*) from feed_runs r join feed_configs f on f.id = r.feed_config_id where f.name like '{FEED_PREFIX}\\_{TAG}\\_%' and r.business_date = '{d}' group by 1"))
            hb = container_health()
            oom = {c: (h0, h1) for c, (h0, h1) in ((c, (health0.get(c), hb.get(c))) for c in CONTAINERS)
                   if h0 and h1 and h0.split()[:2] != h1.split()[:2]}
            check(f"E2 no container restarted or was OOM-killed during {d}", not oom, oom or hb)

        timings["per_month_end"] = per_date
        sampler.stop.set()
        # ── F: every file, from ONE docker cp ───────────────────────────
        print(f"\n== F every delivered file (ONE docker cp of the inbox) == cloud UNION ALL on-prem per island: count + digest for all, full rows for {len(sample_keys)}")
        t0 = time.time()
        rc, _, err = docker("cp", f"{SFTP['container']}:{SFTP['home']}", inbox, timeout=1800)
        check(f"F0 docker cp of the inbox ({rc}, {round(time.time() - t0, 1)}s)", rc == 0, err[-200:])
        local_dir = os.path.join(inbox, os.path.basename(SFTP["home"])) if os.path.isdir(os.path.join(inbox, os.path.basename(SFTP["home"]))) else inbox
        for d in MONTH_ENDS:
            for isl in islands:
                e, ev = isl
                fname = file_name(e, ev, d)
                path = os.path.join(local_dir, fname)
                if not os.path.exists(path):
                    bad_files.append((d.isoformat(), isl, "file absent on the SFTP server"))
                    continue
                with open(path, newline="", encoding="utf-8-sig") as fh:
                    reader = csv.reader(fh)
                    header = next(reader, [])
                    rows = list(reader)
                if [h.upper() for h in header] != [a.upper() for a in aliases]:
                    bad_files.append((d.isoformat(), isl, f"header differs ({len(header)} cols): {header[:4]}..."))
                    continue
                c = truths[(d, "cloud")].get(isl) or (0, [])
                p = truths[(d, "prem")].get(isl) or (0, [])
                want_rows = c[1] + p[1]
                got_texts = [canonical(row) for row in rows]
                dg = union_digest(got_texts)
                digests[(d, isl)] = dg
                if len(rows) != len(want_rows) or dg != union_digest(want_rows):
                    bad_files.append((d.isoformat(), isl, f"rows {len(rows)} vs truth {len(want_rows)}; digest {'equal' if dg == union_digest(want_rows) else 'differs'}"))
                    continue
                if (d, isl) in sample_keys:
                    got = collections.Counter(tuple(row) for row in rows)
                    want = collections.Counter(tuple(t.split(",")) for t in want_rows)
                    if got != want:
                        bad_files.append((d.isoformat(), isl, f"full-row multiset differs: file-only {list((got - want).elements())[:1]} truth-only {list((want - got).elements())[:1]}"))
                        continue
                    compared_rows += len(rows)
                if not all(row[aliases.index("BUSINESS_CLOSE_DATE")] == d.isoformat() and row[aliases.index("CODE")] == e
                           and row[aliases.index("BUSINESSEVENT")] == ev for row in rows):
                    bad_files.append((d.isoformat(), isl, "a row of another island or date is in the file"))
        total_files = 3 * len(islands)
        check(f"F1 {total_files - len(bad_files)}/{total_files} files: header = the query's {len(aliases)} columns in order; row count AND sorted-rows digest "
              f"== cloud UNION ALL on-prem (the two CLIs' grouped truth); only the island's own rows; {len(sample_keys)} files compared as full-row multisets",
              not bad_files and len(digests) == total_files, bad_files[:6])
        check(f"F2 the compared count is NON-ZERO: {compared_rows} rows in {len(sample_keys)} sampled files; {len(digests)} digests",
              compared_rows > 0 and len(digests) == total_files)
        by_island = collections.defaultdict(set)
        for (d, isl), dg in digests.items():
            by_island[isl].add(dg)
        check("F3 the three month-ends' files are DISTINCT per island (a different date = a different file)",
              digests and all(len(v) == 3 for v in by_island.values()), {k: len(v) for k, v in list(by_island.items())[:3]})
        fid1 = feeds[islands[0]]
        _, ex = r.call("GET", f"/api/feeds/{fid1}/executions")
        exs = ex if isinstance(ex, list) else (ex or {}).get("items") or []
        xs = [((x.get("files_metadata") or {}).get("cross_source") or {}) for x in exs if x.get("status") == "completed"]
        check(f"F4 the first feed's {len(xs)} executions record cross_source primary + secondary == expected (the merge BY NAME decided once)",
              len(xs) == 3 and all(x.get("primary_rows") == R + 2 and x.get("secondary_rows") == R + 3 and x.get("expected_rows") == 2 * R + 5 for x in xs), xs[:1])

        # ── H: the ledger + the throughput report ──────────────────────
        arr = psql(f"select source, count(*), count(reported_rows) from dependency_events where dependency_name ~ '^finance_sl_balance(_ext)?_E{TAG}' group by 1 order by 1")
        got_roads = {ln.split("|")[0]: (int(ln.split("|")[1]), int(ln.split("|")[2])) for ln in arr.splitlines() if ln.strip()}
        want_roads = {road: (3 * 4 * cnt, 3 * 4 * cnt) for road, cnt in
                      (("kafka", len(kafka_islands)), ("oracle_table", len(islands) - len(kafka_islands))) if cnt}
        check(f"H1 every arrival carries reported_rows, split by road as sent: {got_roads} (a 1-island run has one road)",
              got_roads == want_roads and sum(c for c, _ in got_roads.values()) == 3 * 4 * len(islands), want_roads)
        unm = int(psql(f"select count(*) from kafka_messages where resolution in ('unmatched', 'unresolvable') and payload like '%{SENT_BY}%'") or 0)
        check(f"H2 no message of this run was unmatched or unresolvable ({unm})", unm == 0)
        timings["sampler"] = sampler.report()
        print("\n== timings / throughput", json.dumps(timings, indent=1))
        print("   containers after:", json.dumps(container_health()))
    finally:
        print("\n== cleanup")
        sampler.stop.set()
        if args.cron and cfg_before:
            restore = {k: v for k, v in cfg_before.items() if v is not None}
            if "sod_enabled" in cfg_before:
                restore["sod_enabled"] = bool(cfg_before["sod_enabled"])
            if "sod_cron" in cfg_before:
                restore["sod_cron"] = str(cfg_before["sod_cron"] or "0 0 * * *")
            s, _ = r.call("PUT", "/api/admin/feeds/config", restore)
            print(f"   config restored to {restore} ({s}); a scheduler restart returns the rig to that posture")
        docker("exec", SFTP["container"], "sh", "-c", f"rm -f {SFTP['home']}/{FEED_PREFIX}_{TAG}_*.csv", timeout=600)
        if not args.keep_rows:
            try:
                psql(f"delete from feed_runs where feed_config_id in (select id from feed_configs where name like '{FEED_PREFIX}\\_{TAG}\\_%')")
                psql(f"delete from feed_executions where feed_config_id in (select id from feed_configs where name like '{FEED_PREFIX}\\_{TAG}\\_%')")
                psql(f"delete from kafka_messages where payload like '%{SENT_BY}%'")
                psql(f"delete from dependency_events where dependency_name ~ '^finance_sl_balance(_ext)?_E{TAG}'")
                psql(f"delete from feed_regeneration_decisions where dependency_name ~ '^finance_sl_balance(_ext)?_E{TAG}'")
            except Exception as exc:  # noqa: BLE001
                print("   ledger cleanup FAILED:", exc)
        try:
            oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE CODE LIKE 'E{TAG}%'"], connection_id=ora_id)
        except Exception as exc:  # noqa: BLE001
            print("   oracle cleanup FAILED:", exc)
        removed, failures = ledger.cleanup()
        if inbox:
            shutil.rmtree(inbox, ignore_errors=True)

    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if all(res) and not failures else 1


if __name__ == "__main__":
    sys.exit(main())
