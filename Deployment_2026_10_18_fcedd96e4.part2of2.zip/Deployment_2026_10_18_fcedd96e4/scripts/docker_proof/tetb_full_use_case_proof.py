"""THE OWNER'S FULL USE CASE on the live Docker rig, in ONE run (2026-10-11).

The owner asked: per table AND joining the two, through FeedGen, Reports and
the published API -- all of it.  Earlier proofs covered pieces on different
data (tetb_real_e2e: per-table feeds; tetb_month_end_sod: the JOIN as SOD
feeds; aws_tb: ad-hoc JOIN queries; starburst_like T10: report -> API on
another table).  This harness runs every surface over the SAME seeded
fact_tetb + fact_tetb_ext, on cloud (Iceberg on the REAL AWS bucket, qs-trino)
and on-prem (the Starburst-shaped qs-trino-sb), and judges every answer BY
VALUE against the Trino CLIs (no QueryStudio code on the truth path).

Subjects: TETB (fact_tetb), EXT (fact_tetb_ext), JOIN (the 54-column FULL
OUTER JOIN of the two -- tetb_month_end_sod_proof.JoinSpec, the same query
the month-end feeds run).  Seed per side: 2 entities x 2 business dates x
EOD; fact_tetb rows k=1..200, fact_tetb_ext rows k=51..250 -- so one island's
JOIN is 250 rows: 150 MATCHED, 50 TETB_ONLY, 50 EXT_ONLY.  The asked island
is (entity 1, 2026-09-30); the other entity and the other date are DECOYS
that every answer must exclude.

Per side x subject:
  R1 dataset over the subject (connection stored), columns auto-detected
  R2 report with TWO parameters (p_code -> CODE, p_date ->
     BUSINESS_CLOSE_DATE); run for the island: the exact SOURCE_DATA_ROW set
     == Trino's, total_rows == truth, not truncated; JOIN: MATCH_STATE counts
  R3 the report published as an API; GET /api/v1/views/{slug}/data with
     ?p_code=&p_date= and the key: the same exact set
Per subject:
  F1 a FEED, cloud UNION ALL on-prem (merge by name), OG tokens
     {BUSINESSDATE}/{SYSTEM_ENTITY}/{EventCode}, CSV to SFTP: the delivered
     file's SOURCE_DATA_ROW multiset == cloud truth + on-prem truth

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/tetb_full_use_case_proof.py
    python scripts/docker_proof/tetb_full_use_case_proof.py --sweep-leftovers [--execute]

Everything created is removed in a finally (proof_cleanup Ledger).
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import io
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import connections, pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, SB_HOST, SB_PORT, SFTP, TABLES, cloud_cli, ddl,
    drop_schema_cascade, load_queries, parse_query, sb_cli,
)
from tetb_month_end_sod_proof import (  # noqa: E402
    T_COLS, JoinSpec, narrow_types, pick_text_columns, seed_statements,
)

TAG = str(int(time.time()))[-6:]
PUB = os.environ.get("QS_PUB_BASE", "http://localhost:8003")
CLOUD_SCHEMA = f"iceberg_aws.fu_{TAG}"
TBL = {"cloud": {"t": f"{CLOUD_SCHEMA}.fact_tetb", "x": f"{CLOUD_SCHEMA}.fact_tetb_ext"},
       "prem": {"t": f"iceberg.qs.fact_tetb_fu{TAG}", "x": f"iceberg.qs.fact_tetb_ext_fu{TAG}"}}
EVENT = "EOD"
DATES = (dt.date(2026, 9, 30), dt.date(2026, 8, 31))
ASK_DATE = DATES[0]
ENTITIES = range(1, 3)
ASK_ENTITY = f"E{TAG}0001"
T_K, X_K = (1, 200), (51, 250)
SUBJECTS = ("TETB", "EXT", "JOIN")


def low(rec: dict) -> dict:
    return {str(k).lower(): v for k, v in (rec or {}).items()}


def records(body) -> list:
    """Row dicts from a report envelope / published-API body, whatever shape."""
    if not isinstance(body, dict):
        return []
    data = body.get("data")
    if isinstance(data, list) and (not data or isinstance(data[0], dict)):
        return [low(r) for r in data]
    rows, cols = body.get("rows"), body.get("columns") or []
    names = [c.get("name") if isinstance(c, dict) else c for c in cols]
    if isinstance(rows, list) and rows and isinstance(rows[0], dict):
        return [low(r) for r in rows]
    if isinstance(rows, list) and names:
        return [low(dict(zip(names, r))) for r in rows]
    return []


#: --owner-sql: fact_tetb and fact_tetb_ext are queried with the OWNER'S OWN
#: SQL (fixtures fact_tetb.json / test_query_001.json), the cloud query on cloud
#: and the on-prem query on-prem, verbatim but the FROM, OG tokens intact --
#: ONE saved query per side serves the feed AND the report.
OWNER = {"on": False}


def owner_sql(side: str, subject: str) -> str:
    spec_ = TABLES["tetb" if subject == "TETB" else "ext"]
    cloud, onprem = load_queries(spec_)
    which = "t" if subject == "TETB" else "x"
    if side == "cloud":
        return cloud.replace(spec_["from_cloud"], TBL[side][which])
    return onprem.replace(spec_["from_onprem"], TBL[side][which])


def fill_tokens(sql: str) -> str:
    return (sql.replace("{BUSINESSDATE}", ASK_DATE.isoformat()).replace("{SYSTEM_ENTITY}", ASK_ENTITY)
            .replace("{EventCode}", EVENT))


def subject_sql(side: str, subject: str, spec: JoinSpec, cols_t: list, cols_x: list, *, where: str = "") -> str:
    if OWNER["on"] and subject != "JOIN":
        return owner_sql(side, subject)
    t, x = TBL[side]["t"], TBL[side]["x"]
    if subject == "TETB":
        return f"SELECT {', '.join(c.lower() for c in cols_t)} FROM {t}" + (f" WHERE {where}" if where else "")
    if subject == "EXT":
        return f"SELECT {', '.join(c.lower() for c in cols_x)} FROM {x}" + (f" WHERE {where}" if where else "")
    j = JoinSpec(t, x, spec.t_cols, spec.x_cols, x_has_rate=spec.x_has_rate)
    w = f" WHERE {where}" if where else ""
    return (f"WITH t AS (SELECT * FROM {t}{w}),\n     x AS (SELECT * FROM {x}{w})\n"
            f"SELECT\n  {j._select()}\nFROM t FULL OUTER JOIN x ON {j.JOIN_ON}")


def truth(side: str, subject: str, spec, cols_t, cols_x) -> collections.Counter:
    """The island's rows as Trino returns them: SOURCE_DATA_ROW (+ MATCH_STATE
    for the JOIN), as a multiset."""
    where = (f"business_close_date = DATE '{ASK_DATE.isoformat()}' AND code = '{ASK_ENTITY}' "
             f"AND businessevent = '{EVENT}'")
    inner = (fill_tokens(owner_sql(side, subject)) if OWNER["on"] and subject != "JOIN"
             else subject_sql(side, subject, spec, cols_t, cols_x, where=where))
    pick = ('"SOURCE_DATA_ROW" || \'|\' || "MATCH_STATE"' if subject == "JOIN" else "source_data_row")
    cli = cloud_cli if side == "cloud" else sb_cli
    out = cli(f"SELECT {pick} FROM ({inner}) q;" + chr(10), stdin=True)   # a 533-column JOIN exceeds a command line
    return collections.Counter(line.strip().strip('"') for line in out.splitlines() if line.strip())


def key_of(rec: dict, subject: str) -> str:
    sdr = rec.get("source_data_row")
    return f"{sdr}|{rec.get('match_state')}" if subject == "JOIN" else str(sdr)


def fetch_all(r, report_id, exec_id, total: int, page_size: int = 1000) -> list:
    """Every row of a report execution through /results, page by page."""
    out, page = [], 1
    while exec_id and len(out) < total and page <= 1000:
        s, b = r.call("GET", f"/api/business-reports/{report_id}/results/{exec_id}"
                             f"?page={page}&page_size={page_size}")
        got = records(b) if s == 200 else []
        if not got:
            break
        out += got
        page += 1
    return out


def owner_report(r, ledger, subj, sql_file_id, truth_c):
    """R2/R3 on the owner's SQL: a raw-SQL report ON the shared SQL file
    (cloud + on-prem, UNION), parameters named after the query's own tokens,
    then its published API."""
    side = "cloud+prem"
    tag = f"{side}/{subj}"
    rname = f"FU {subj} {TAG}"
    s, rep = r.call("POST", "/api/business-reports", {
        "name": rname, "data_source_type": "raw_sql", "raw_sql_file_id": sql_file_id, "row_limit": 100000})
    if not check(f"R2 {tag}: report ON the shared SQL file created", s == 200 and (rep or {}).get("id"),
                 (s, str(rep)[:300])):
        return
    ledger.add("report", rname, path=f"/api/business-reports/{rep['id']}")
    for name, label, ptype in (("SYSTEM_ENTITY", "System entity", "string"),
                               ("BUSINESSDATE", "Business date", "date"), ("EventCode", "Business event", "string")):
        s, p = r.call("POST", f"/api/business-reports/{rep['id']}/parameters", {
            "name": name, "label": label, "parameter_type": ptype, "is_required": True})
        check(f"R2 {tag}: parameter {name} (the query's own token)", s in (200, 201), (s, str(p)[:200]))
    params = {"SYSTEM_ENTITY": ASK_ENTITY, "BUSINESSDATE": ASK_DATE.isoformat(), "EventCode": EVENT}
    s, ex = r.call("POST", f"/api/business-reports/{rep['id']}/execute",
                   {"parameter_values": params, "force_refresh": True, "limit_override": 0})
    ex = ex if isinstance(ex, dict) else {}
    total = int(ex.get("total_rows") or 0)
    inline = records(ex)
    got = fetch_all(r, rep["id"], ex.get("execution_id"), total) if len(inline) < total else inline
    got_c = collections.Counter(key_of(x, subj) for x in got)
    ncols = len(got[0]) if got else 0
    check(f"R2 {tag}: the owner-SQL report for ({ASK_ENTITY}, {ASK_DATE}, {EVENT}) == Trino BY VALUE "
          f"({sum(truth_c.values())} rows, {ncols} columns)",
          s == 200 and got_c == truth_c and sum(truth_c.values()) > 0 and total == sum(truth_c.values()),
          {"status": s, "got": sum(got_c.values()), "want": sum(truth_c.values()), "total_rows": total,
           "missing": list((truth_c - got_c).elements())[:3], "extra": list((got_c - truth_c).elements())[:3],
           "body": str(ex)[:400] if s != 200 else ""})
    r.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
    slug = f"fu-{subj.lower()}-{TAG}"
    s, pv = r.call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                    "business_report_id": rep["id"], "credential_mode": "publisher"})
    pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
    key = (pv or {}).get("test_api_key") or ""
    if not check(f"R3 {tag}: published as an API with a key", s in (200, 201) and pid and key, (s, str(pv)[:300])):
        return
    ledger.add("published view", slug, path=f"/api/published-views/{pid}")
    s, b = pub_get(f"/api/v1/views/{slug}/data?SYSTEM_ENTITY={ASK_ENTITY}&BUSINESSDATE={ASK_DATE.isoformat()}"
                   f"&EventCode={EVENT}&limit=0", key)
    api_c = collections.Counter(key_of(x, subj) for x in records(b))
    check(f"R3 {tag}: the API with ?SYSTEM_ENTITY=&BUSINESSDATE=&EventCode= == Trino BY VALUE",
          s == 200 and api_c == truth_c,
          {"status": s, "got": sum(api_c.values()), "want": sum(truth_c.values()),
           "missing": list((truth_c - api_c).elements())[:3], "extra": list((api_c - truth_c).elements())[:3],
           "body": str(b)[:300] if s != 200 else ""})


def pub_get(path: str, key: str):
    import qs_docker_client as c
    saved = c.BASE
    c.BASE = PUB
    try:
        s, b, _ = c.call("GET", path, None, headers={"X-API-Key": key})
    finally:
        c.BASE = saved
    return s, b


def main(argv=None) -> int:
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--keep", action="store_true",
                    help="leave every dataset / report / API / saved query / feed and the tables in place to open in the UI")
    ap.add_argument("--owner-sql", action="store_true",
                    help="fact_tetb / fact_tetb_ext through the OWNER'S OWN queries (implies --full)")
    ap.add_argument("--cloud-road", choices=("trino", "s3"), default="trino",
                    help="s3 = the CLOUD side of every surface (dataset, report, API, feed) "
                         "is read by QueryStudio's OWN S3 engine from the seeded Iceberg tables "
                         "on the direct AWS S3 connection -- no Trino (2026-10-14, the owner: "
                         "AWS S3 is primary); the truth is still Trino's CLI")
    ap.add_argument("--full", action="store_true",
                    help="every column of the owner's two queries (460 + 76), the JOIN over all of them")
    args = ap.parse_args(rest)
    if args.owner_sql:
        OWNER["on"], args.full = True, True     # the owner's SQL reads every column
    r = Rig()
    if sweep:
        rules = [Rule("published view", r"fu-\w+-\w+-\d{6}", list_path="/api/published-views",
                      delete_path="/api/published-views/{id}"),
                 Rule("report", r"FU \w+ \w+ \d{6}", list_path="/api/business-reports",
                      delete_path="/api/business-reports/{id}"),
                 Rule("dataset", r"fu_\w+_\w+_\d{6}", list_path="/api/datasets", delete_path="/api/datasets/{id}"),
                 Rule("feed", r"FU_\w+_\d{6}", list_path="/api/feeds", delete_path="/api/feeds/{id}"),
                 Rule("saved query", r"fu_\w+_\w+_q_\d{6}", list_path="/api/queries", delete_path="/api/queries/{id}"),
                 Rule("connection", r"sb-onprem-fu-\d{6}", list_path="/api/connections",
                      delete_path="/api/connections/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for line in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'fu_%'").splitlines():
            s = line.strip().strip('"')
            if re.fullmatch(r"fu_\d{6}", s):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{s} (cascade)")
                if execute:
                    print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{s}"))
        for line in sb_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%_fu%'").splitlines():
            t = line.strip().strip('"')
            if re.fullmatch(r"fact_tetb(_ext)?_fu\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    sb_cli(f"DROP TABLE iceberg.qs.{t}")
        return rc

    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    # The owner's two queries give the column vocabulary; the JOIN takes
    # T_COLS text columns from each (54 columns, the month-end feed's shape).
    t_sql, _ = load_queries(TABLES["tetb"])
    x_sql, _ = load_queries(TABLES["ext"])
    _, t_parsed = parse_query(t_sql, TABLES["tetb"]["alias"])
    _, x_parsed = parse_query(x_sql, TABLES["ext"]["alias"])
    if args.full:
        # Every column the owner's queries read, typed from their CASTs.
        t_types, x_types = dict(t_parsed), dict(x_parsed)
        keys = {"BUSINESS_CLOSE_DATE", "CODE", "BUSINESSEVENT", "SOURCE_DATA_ROW"}
        t_cols = [c for c, v in t_types.items() if v == "VARCHAR" and c not in keys]
        x_cols = [c for c, v in x_types.items() if v == "VARCHAR" and c not in keys]
    else:
        t_cols = pick_text_columns(t_parsed, T_COLS)
        x_cols = pick_text_columns(x_parsed, T_COLS)
        t_types = narrow_types(t_parsed, t_cols, with_rate=True)
        x_types = narrow_types(x_parsed, x_cols, with_rate=False)
    spec = JoinSpec("t", "x", t_cols, x_cols, x_has_rate=False)
    cols_t, cols_x = list(t_types), list(x_types)
    print(f"== FULL USE CASE tag {TAG}: TETB {len(cols_t)} cols, EXT {len(cols_x)} cols, "
          f"JOIN {len(spec.aliases())} cols; island ({ASK_ENTITY}, {ASK_DATE}, {EVENT}) + decoys")
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    try:
        # ── seed ON the clusters ────────────────────────────────────────
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/fu_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        for side, cli in (("cloud", cloud_cli), ("prem", sb_cli)):
            for which, types, (k_lo, k_hi) in (("t", t_types, T_K), ("x", x_types, X_K)):
                table = TBL[side][which]
                cli(ddl(table, types, hive=False) + ";\n", stdin=True)
                if side == "prem":
                    ledger.add("on-prem table", table,
                               remover=lambda tb=table: (bool(sb_cli(f"DROP TABLE {tb}") is not None), "dropped"))
                for stmt in seed_statements(table, types, side, ENTITIES, [EVENT], DATES, k_lo, k_hi, tag=TAG):
                    cli(stmt + ";\n", stdin=True)
        want = {(side, subj): truth(side, subj, spec, cols_t, cols_x) for side in TBL for subj in SUBJECTS}
        sizes = {f"{s}/{j}": sum(c.values()) for (s, j), c in want.items()}
        join_states = collections.Counter(k.split("|")[1] for k in want[("cloud", "JOIN")].elements())
        check("S0 seeded both clusters; the island's truth per side x subject (Trino CLI)",
              all(sizes[f"{s}/TETB"] == 200 and sizes[f"{s}/EXT"] == 200 and sizes[f"{s}/JOIN"] == 250 for s in TBL)
              and join_states == {"MATCHED": 150, "TETB_ONLY": 50, "EXT_ONLY": 50},
              {"sizes": sizes, "join_states": dict(join_states)})

        # ── connections ─────────────────────────────────────────────────
        conn = {"cloud": pick_cloud(r, "")[0]}
        if args.cloud_road == "s3":
            # the seeded tables registered on the DIRECT S3 connection; from
            # here every cloud SQL names them (the truth above was Trino's)
            s3c = next(x for x in connections(r) if x.get("name") == "aws-real")
            for which, label in (("t", "tetb"), ("x", "ext")):
                tbl = TBL["cloud"][which]
                sch, name = tbl.rsplit(".", 1)
                loc = cloud_cli(f'SELECT file_path FROM {sch}."{name}$files" LIMIT 1').strip().strip('"')
                prefix = loc.split(f"s3://{AWS_BUCKET}/", 1)[1].split("/data/", 1)[0] + "/"
                reg = f"fu_{label}_{TAG}"
                s_, b_ = r.call("POST", f"/api/connections/{s3c['id']}/tables", {
                    "name": reg, "s3_prefix": prefix, "format": "iceberg",
                    "description": f"full use case {TAG}: {name} read directly from AWS S3"})
                if not check(f"S1 {reg} registered on the direct AWS S3 connection", s_ in (200, 201), (s_, str(b_)[:200])):
                    return 1
                ledger.add("s3 registered table", reg,
                           path=f"/api/connections/{s3c['id']}/tables/{reg}")
                TBL["cloud"][which] = reg
            conn["cloud"] = s3c["id"]
            print(f"   cloud road: QueryStudio's S3 engine on aws-real ({conn['cloud']}): "
                  f"{TBL['cloud']['t']}, {TBL['cloud']['x']}")
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-fu-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False,
                       "catalog": "iceberg", "schema": "qs"}})
        conn["prem"] = (b or {}).get("id")
        if not check("S1 the on-prem connection is created", s in (200, 201) and conn["prem"], (s, str(b)[:200])):
            return 1
        ledger.add("connection", f"sb-onprem-fu-{TAG}", path=f"/api/connections/{conn['prem']}")

        # ── saved queries: ONE per side x subject, shared by report + feed ─
        where_tok = ("business_close_date = CAST('{BUSINESSDATE}' AS DATE) AND code = '{SYSTEM_ENTITY}' "
                     "AND businessevent = '{EventCode}'")
        qids = {}
        for subj in SUBJECTS:
            for side in TBL:
                qname = f"fu_{side}_{subj.lower()}_q_{TAG}"
                s, qq = r.call("POST", "/api/queries", {"name": qname, "query_config": {
                    "files": [], "connection_id": conn[side],
                    "raw_sql": subject_sql(side, subj, spec, cols_t, cols_x, where=where_tok)}})
                qids[(side, subj)] = (qq or {}).get("id")
                if check(f"Q {side}/{subj}: saved query created"
                         f"{' (the OWNER SQL, verbatim but the FROM)' if OWNER['on'] and subj != 'JOIN' else ''}",
                         s in (200, 201) and qids[(side, subj)], (s, str(qq)[:200])):
                    ledger.add("saved query", qname, path=f"/api/queries/{qids[(side, subj)]}")

        # ── --owner-sql: ONE SQL FILE per table = the owner's cloud SQL on the
        # cloud connection + the owner's on-prem SQL on the on-prem one,
        # combined UNION ALL.  The feed AND the report read this ONE object.
        sqlfiles = {}
        if OWNER["on"]:
            for subj in ("TETB", "EXT"):
                fname_ = f"fu_{subj.lower()}_{TAG}"
                s, sf = r.call("POST", "/api/sql-files", {
                    "name": fname_, "sql": owner_sql("cloud", subj), "connection_id": conn["cloud"],
                    "secondary_sql": owner_sql("prem", subj), "secondary_connection_id": conn["prem"],
                    "combine_mode": "union", "is_shared": True})
                sqlfiles[subj] = (sf or {}).get("id")
                if check(f"SF {subj}: ONE shared SQL file = the owner's cloud + on-prem queries, UNION",
                         s in (200, 201) and sqlfiles[subj], (s, str(sf)[:300])):
                    ledger.add("sql file", fname_, path=f"/api/sql-files/{sqlfiles[subj]}")

        # ── R1-R3 per side x subject: dataset -> report -> published API ──
        for side in TBL:
            for subj in SUBJECTS:
                tag = f"{side}/{subj}"
                truth_c = want[(side, subj)]
                if OWNER["on"] and subj != "JOIN":
                    # one report per TABLE on the shared SQL file (both sides)
                    if side == "cloud":
                        owner_report(r, ledger, subj, sqlfiles.get(subj),
                                     want[("cloud", subj)] + want[("prem", subj)])
                    continue
                dsname = f"fu_{side}_{subj.lower()}_{TAG}"
                s, ds = r.call("POST", "/api/datasets", {
                    "name": dsname, "subject": "fu", "connection_ids": [conn[side]],
                    "base_query": subject_sql(side, subj, spec, cols_t, cols_x)})
                if not check(f"R1 {tag}: dataset created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:300])):
                    continue
                ledger.add("dataset", dsname, path=f"/api/datasets/{ds['id']}")
                s, ad = r.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
                if not check(f"R1 {tag}: columns auto-detected", s == 200, (s, str(ad)[:400])):
                    continue
                cols = {c["physical_name"].lower(): c for c in (r.call("GET", f"/api/datasets/{ds['id']}")[1] or {}).get("columns", [])}
                need = {"source_data_row", "code", "business_close_date"} | ({"match_state"} if subj == "JOIN" else set())
                if not check(f"R1 {tag}: columns detected ({len(cols)}), keys present", need <= set(cols),
                             sorted(cols)[:12]):
                    continue
                for c in cols.values():
                    r.call("PUT", f"/api/datasets/columns/{c['id']}", {"column_type": "dimension"})
                rname = f"FU {side} {subj} {TAG}"
                s, rep = r.call("POST", "/api/business-reports", {
                    "name": rname, "dataset_id": ds["id"], "data_source_type": "dataset",
                    "column_ids": [c["id"] for c in cols.values()], "row_limit": 100000})
                if not check(f"R2 {tag}: report created", s == 200 and (rep or {}).get("id"), (s, str(rep)[:300])):
                    continue
                ledger.add("report", rname, path=f"/api/business-reports/{rep['id']}")
                for pname, label, col in (("p_code", "System entity", "code"),
                                          ("p_date", "Business date", "business_close_date")):
                    s, p = r.call("POST", f"/api/business-reports/{rep['id']}/parameters", {
                        "name": pname, "label": label, "parameter_type": "dropdown",
                        "lov_column_id": cols[col]["id"], "is_required": True})
                    check(f"R2 {tag}: parameter {pname} -> {col}", s in (200, 201), (s, str(p)[:200]))
                params = {"p_code": ASK_ENTITY, "p_date": ASK_DATE.isoformat()}
                s, ex = r.call("POST", f"/api/business-reports/{rep['id']}/execute",
                               {"parameter_values": params, "force_refresh": True, "limit_override": 0})
                ex = ex if isinstance(ex, dict) else {}
                inline = records(ex)
                total = int(ex.get("total_rows") or 0)
                if len(inline) < total:
                    # The execute answer carries the FIRST PAGE inline
                    # (business_reports.page_size); the viewer pages through
                    # /results.  Record what the answer says about that, then
                    # read the whole result the way the viewer does.
                    marks = {k: ex.get(k) for k in ("page", "page_size", "total_pages", "has_more", "engine",
                                                    "truncated") if k in ex}
                    print(f"   {tag}: execute carried {len(inline)} of {total} rows inline; page markers {marks}; "
                          f"keys {sorted(ex)[:24]}")
                got = fetch_all(r, rep["id"], ex.get("execution_id"), total) if len(inline) < total else inline
                got_c = collections.Counter(key_of(x, subj) for x in got)
                check(f"R2 {tag}: the report for ({ASK_ENTITY}, {ASK_DATE}) == Trino BY VALUE "
                      f"({sum(truth_c.values())} rows{', MATCHED/TETB_ONLY/EXT_ONLY' if subj == 'JOIN' else ''}), decoys excluded",
                      s == 200 and got_c == truth_c and sum(truth_c.values()) > 0
                      and ex.get("total_rows") == sum(truth_c.values()) and not ex.get("truncated"),
                      {"status": s, "got": sum(got_c.values()), "want": sum(truth_c.values()),
                       "total_rows": ex.get("total_rows"), "truncated": ex.get("truncated"),
                       "missing": list((truth_c - got_c).elements())[:3], "extra": list((got_c - truth_c).elements())[:3],
                       "body": str(ex)[:300] if s != 200 else ""})
                # R3: published as an API, called with the same parameters
                r.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
                slug = f"fu-{side}-{subj.lower()}-{TAG}"
                s, pv = r.call("POST", "/api/published-views", {
                    "name": slug, "slug": slug, "source_type": "business_report",
                    "business_report_id": rep["id"], "credential_mode": "publisher"})
                pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
                key = (pv or {}).get("test_api_key") or ""
                if not check(f"R3 {tag}: published as an API with a key", s in (200, 201) and pid and key, (s, str(pv)[:300])):
                    continue
                ledger.add("published view", slug, path=f"/api/published-views/{pid}")
                s, b = pub_get(f"/api/v1/views/{slug}/data?p_code={ASK_ENTITY}&p_date={ASK_DATE.isoformat()}&limit=0", key)
                api_c = collections.Counter(key_of(x, subj) for x in records(b))
                check(f"R3 {tag}: the API with ?p_code=&p_date= == Trino BY VALUE ({sum(truth_c.values())} rows)",
                      s == 200 and api_c == truth_c,
                      {"status": s, "got": sum(api_c.values()), "want": sum(truth_c.values()),
                       "missing": list((truth_c - api_c).elements())[:3], "extra": list((api_c - truth_c).elements())[:3],
                       "body": str(b)[:300] if s != 200 else ""})

        # ── F1 per subject: a feed, cloud UNION ALL on-prem, to SFTP ──────
        host_key = sftp_host_key()
        feeds = {}
        for subj in SUBJECTS:
            q = {side: qids[(side, subj)] for side in TBL}       # the SAME saved queries the reports run
            src = ({"source_type": "sql_file", "source_id": sqlfiles[subj], "connection_id": conn["cloud"]}
                   if OWNER["on"] and subj != "JOIN" and sqlfiles.get(subj) else
                   {"source_type": "saved_query", "source_id": q["cloud"], "connection_id": conn["cloud"],
                    "secondary_connection_id": conn["prem"], "secondary_source_type": "saved_query",
                    "secondary_source_id": q["prem"], "combine_mode": "union"})
            fname = f"FU_{subj}_{TAG}_{ASK_DATE:%Y%m%d}.csv"
            s, fb = r.call("POST", "/api/feeds", {
                "name": f"FU_{subj}_{TAG}", **src, "output_format": "csv",
                "output_filename_template": f"FU_{subj}_{TAG}_{{business_date:YYYYMMDD}}.csv",
                "destination_type": "sftp",
                "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                       "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                       "host_key_b64": host_key},
                "execution_backend": "native", "notify_on_failure": False,
                "query_params": {"SYSTEM_ENTITY": ASK_ENTITY, "EventCode": EVENT}})
            fid = (fb or {}).get("id")
            if not check(f"F1 {subj}: cross-source feed created", s == 200 and fid, (s, str(fb)[:300])):
                continue
            ledger.add("feed", f"FU_{subj}_{TAG}", path=f"/api/feeds/{fid}")
            ledger.add("sftp file", fname, remover=lambda n=fname: (subprocess.run(
                ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{n}"], env=DENV).returncode == 0, "rm"))
            r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": ASK_DATE.isoformat(),
                                                         "end_date": ASK_DATE.isoformat(), "deliver": True,
                                                         "reason": "full use case proof (test data only)"})
            feeds[subj] = (fid, fname)
        t0 = time.time()
        done = {}
        while len(done) < len(feeds) and time.time() - t0 < args.timeout:
            for subj, (fid, _) in feeds.items():
                if subj in done:
                    continue
                _, ex = r.call("GET", f"/api/feeds/{fid}/executions")
                ex = ex if isinstance(ex, list) else (ex or {}).get("items") or []
                if ex and ex[0].get("status") in ("completed", "failed", "error", "cancelled"):
                    done[subj] = ex[0]
            time.sleep(10)
        for subj, (fid, fname) in feeds.items():
            e = done.get(subj) or {}
            want_c = want[("cloud", subj)] + want[("prem", subj)]
            text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fname}"],
                                  capture_output=True, text=True, env=DENV).stdout
            rows_ = [low(x) for x in csv.DictReader(io.StringIO(text.lstrip("﻿")))]
            got_c = collections.Counter(key_of(x, subj) for x in rows_)
            check(f"F1 {subj}: the delivered file == cloud truth + on-prem truth BY VALUE ({sum(want_c.values())} rows)",
                  e.get("status") == "completed" and got_c == want_c and sum(want_c.values()) > 0,
                  {"status": e.get("status"), "error": str(e.get("error_message"))[:300], "got": sum(got_c.values()),
                   "want": sum(want_c.values()), "missing": list((want_c - got_c).elements())[:3],
                   "extra": list((got_c - want_c).elements())[:3]})
    finally:
        if args.keep:
            print(f"\n== KEPT for the UI (tag {TAG}); remove later with --sweep-leftovers --execute")
            for it in ledger.items:
                print(f"   {it['kind']:15} {it['label']}  {it.get('path') or ''}")
        else:
            print("\n== cleanup")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} objects removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
