"""THE UPSTREAM CONTRACT, live on the rig (2026-10-12, the owner: "the same
version number also needs to apply in the queries ... {version}", "we can
write empty files if the Kafka message says 0 rows on both", "but the variance
check will be applied", "no patching").

Run the way production runs: a month-end business calendar, SOD creates the
TASK, the two messages release it, the queue worker runs it.  One combined
feed on the owner's fact_tetb_ext queries -- cloud (AWS S3
Iceberg via qs-trino) UNION ALL on-prem (Starburst-shaped qs-trino-sb) --
whose EACH side's SQL reads ``{snapshot}``: the snapshot ITS environment's
message announced.  Dependencies the owner's way: CLOUD + ON-PREM, each met
by Kafka OR the QS_KAFKA_MESSAGE table, each certifying its count.

  C1  rows for snapshots S1 AND S2 exist on both sides; the messages announce
      S1 (3 cloud / 4 on-prem) -> the file == exactly the S1 rows, certified
      per side, the execution's contract names S1 per environment
  C2  the upstream RESTATES: S2 messages (5 / 6) -> the ledger's replay
      raises a regeneration decision; the board: SUPERSEDED, read S1 now S2
  C3  Regenerate (the decision + a re-run, as the board's button does) ->
      the file == exactly the S2 rows (11), certified
  C4  another date: both messages say 0 rows (snapshot S0, nothing loaded)
      -> an EMPTY file is delivered (the upstream vouched for it) and the
      variance check still ran
  C5  (2026-10-12, the owner: "if the query has {version} it is resolved from
      the Kafka messages ... on-prem and on-cloud can have different version
      numbers") a third month end where CLOUD announces version V1 and ON-PREM
      announces V2, rows of BOTH versions sitting on BOTH sides -> the file ==
      the cloud V1 rows + the on-prem V2 rows: each side's {version} is ITS
      environment's message, never the other's

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/upstream_contract_proof.py [--keep]
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import io
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import connections, pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, ORA_TABLE, SB_HOST, SB_PORT, SFTP, TABLES, TOPIC, cloud_cli, ddl,
    drop_schema_cascade, ensure_oracle_table, insert_rows, load_queries, message, ora_rows,
    parse_query, produce_kafka, row_values,
)

TAG = str(int(time.time()))[-6:]
SPEC = TABLES["ext"]
DS = SPEC["data_source"]
ENT, EV = f"UC{TAG}", "EOD"
BD, BD0 = dt.date(2027, 1, 29), dt.date(2027, 2, 26)        # two month ends with nothing else on them
BD3 = dt.date(2027, 3, 31)                                   # the per-environment version month end
S0, S1, S2 = int(f"{TAG}0"), int(f"{TAG}1"), int(f"{TAG}2")
CLOUD_SCHEMA = f"iceberg_aws.uc_{TAG}"
CAL = f"UC_{TAG}"
NAME = f"UC_{TAG}_FINANCE_SL_BALANCE_EXT_{EV}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", action="store_true")
    a = ap.parse_args()
    r = Rig()
    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    items = connections(r)
    cloud_id, _ = pick_cloud(r, "")
    ora_id = next((x["id"] for x in items if x.get("name") == "oracle-otg"), None)
    ensure_oracle_table(ora_id)
    c_tab, p_tab = f"{CLOUD_SCHEMA}.fact_tetb_ext", f"iceberg.qs.fact_tetb_ext_uc{TAG}"
    c_sql, p_sql = load_queries(SPEC)
    c_sql, p_sql = c_sql.replace(SPEC["from_cloud"], c_tab), p_sql.replace(SPEC["from_onprem"], p_tab)
    _, c_types = parse_query(c_sql, SPEC["alias"])
    _, p_types = parse_query(p_sql, SPEC["alias"])
    # THE CONTRACT IN THE QUERY: each side reads the snapshot ITS message announced
    feed_c = f"SELECT * FROM ({c_sql}) q WHERE q.snap_version = {{version}}"
    feed_p = f"SELECT * FROM ({p_sql}) q WHERE q.snap_version = {{version}}"
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    seq = [int(TAG) * 100]

    def rows(side, types, bd, snap, n):
        out = []
        for i in range(n):
            v = row_values(side, types, bd, ENT, EV, i)
            for k, c in enumerate(types):
                if c == "SNAP_VERSION":
                    v[k] = snap
                if c == "SOURCE_DATA_ROW":
                    v[k] = f"{side}:{snap}:{i}"
            out.append(v)
        return out

    def announce(bd, snap, nc, np_, snap_p=None):
        """CLOUD announces ``snap``; ON-PREM ``snap_p`` (default the same)."""
        snap_p = snap if snap_p is None else snap_p
        seq[0] += 2
        mc = {**message(DS, ENT, EV, bd, True, "COMPLETE", nc, seq[0]), "SNAP_VERSION": str(snap),
              "VERSION_NUMBER": str(snap)}
        mp = {**message(DS, ENT, EV, bd, False, "COMPLETE", np_, seq[0] + 1), "SNAP_VERSION": str(snap_p),
              "VERSION_NUMBER": str(snap_p)}
        produce_kafka([mc])
        ora_rows(ora_id, [mp])

    def admitted(fid, bd, want_snap, timeout=180):
        t0 = time.time()
        while time.time() - t0 < timeout:
            s, pre = r.call("GET", f"/api/feeds/{fid}/run-preflight?business_date={bd.isoformat()}")
            if s == 200 and (pre or {}).get("admitted"):
                s, det = r.call("GET", f"/api/feed-dashboard/task?feed_id={fid}&business_date={bd.isoformat()}")
                snaps = {str((c.get("messages") or [{}])[-1].get("fields", {}).get("SNAP_VERSION"))
                         for c in (det or {}).get("dependencies") or []}
                if snaps == {str(want_snap)}:
                    return True
            time.sleep(3)
        return False

    def sod_task(fid, bd):
        """SOD for the month end, scoped to this feed: its TASK, waiting."""
        s, b = r.call("POST", f"/api/admin/feeds/sod/run-now?business_date={bd.isoformat()}&feed_ids={fid}",
                      timeout=600)
        s2, rr = r.call("GET", f"/api/feed-runs?business_date={bd.isoformat()}&limit=1000")
        row = next((x for x in (rr or {}).get("items") or [] if x["feed_config_id"] == fid), None)
        return row, (s, str(b)[:200])

    def task_done(fid, bd, run_id, timeout=600):
        t0 = time.time()
        while time.time() - t0 < timeout:
            s, rr = r.call("GET", f"/api/feed-runs?business_date={bd.isoformat()}&limit=1000")
            row = next((x for x in (rr or {}).get("items") or [] if x["id"] == run_id), None)
            if row and row.get("status") in ("completed", "failed", "cancelled") and row.get("completed_at"):
                s, st = r.call("GET", f"/api/feed-runs/{run_id}/steps")
                eid = ((st or {}).get("execution") or {}).get("id")
                s, ex = r.call("GET", f"/api/feed-executions/{eid}") if eid else (0, {})
                return row, (ex or {})
            time.sleep(5)
        return None, {}

    def execute(fid, bd):
        s, b = r.call("POST", f"/api/feeds/{fid}/execute", {"business_date": bd.isoformat()})
        eid = (b or {}).get("execution_db_id") or (b or {}).get("id")
        t0 = time.time()
        while eid and time.time() - t0 < 600:
            s, ex = r.call("GET", f"/api/feed-executions/{eid}")
            if (ex or {}).get("status") in ("completed", "failed", "cancelled"):
                return ex
            time.sleep(3)
        return {"status": "no execution", "answer": (s, str(b)[:300])}

    def sftp_rows(bd):
        fn = f"{NAME}_{bd:%Y%m%d}.csv"
        text = subprocess.run(["docker", "exec", SFTP["container"], "cat", f"{SFTP['home']}/{fn}"],
                              capture_output=True, text=True, env=DENV).stdout
        ledger.add("sftp file", fn, remover=lambda fn=fn: (subprocess.run(
            ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fn}"], env=DENV).returncode == 0, "rm"))
        return collections.Counter({k.lower(): v for k, v in rec.items()}.get("source_data_row")
                                   for rec in csv.DictReader(io.StringIO(text.lstrip("﻿")))), text

    try:
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/uc_{TAG}')")
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        cloud_cli(ddl(c_tab, c_types, hive=False) + ";\n", stdin=True)
        cloud_cli(ddl(p_tab, p_types, hive=False) + ";\n", stdin=True)
        ledger.add("on-prem table", p_tab, remover=lambda: (bool(cloud_cli(f"DROP TABLE {p_tab}") is not None), "dropped"))
        insert_rows(cloud_cli, c_tab, c_types, rows("cloud", c_types, BD, S1, 3) + rows("cloud", c_types, BD, S2, 5)
                    + rows("cloud", c_types, BD3, S1, 3) + rows("cloud", c_types, BD3, S2, 5))
        insert_rows(cloud_cli, p_tab, p_types, rows("prem", p_types, BD, S1, 4) + rows("prem", p_types, BD, S2, 6)
                    + rows("prem", p_types, BD3, S1, 4) + rows("prem", p_types, BD3, S2, 6))
        print(f"== UPSTREAM CONTRACT tag {TAG}: {BD} holds snapshots S1={S1} (3+4) and S2={S2} (5+6)")

        s, cal = r.call("POST", "/api/admin/feed-calendars", {"name": CAL, "weekend_days": [6, 7], "holidays": []})
        ledger.add("calendar", CAL, path=f"/api/admin/feed-calendars/{CAL}")
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-uc-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False, "catalog": "iceberg", "schema": "qs"}})
        prem_id = (b or {}).get("id")
        ledger.add("connection", f"sb-onprem-uc-{TAG}", path=f"/api/connections/{prem_id}")
        q = {}
        for side, cid, sql in (("cloud", cloud_id, feed_c), ("prem", prem_id, feed_p)):
            s, qq = r.call("POST", "/api/queries", {"name": f"uc_{side}_{TAG}",
                                                   "query_config": {"files": [], "raw_sql": sql, "connection_id": cid}})
            q[side] = (qq or {}).get("id")
            ledger.add("saved query", f"uc_{side}_{TAG}", path=f"/api/queries/{q[side]}")
        s, feed = r.call("POST", "/api/feeds", {
            "name": NAME, "source_type": "saved_query", "source_id": q["cloud"], "connection_id": cloud_id,
            "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
            "secondary_source_id": q["prem"], "combine_mode": "union", "output_format": "csv",
            "output_filename_template": f"{NAME}_{{business_date:YYYYMMDD}}.csv",
            "query_params": {"SYSTEM_ENTITY": ENT, "EventCode": EV},
            "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                   "host_key_b64": sftp_host_key()},
            "schedule_declaration": {"kind": "month_end", "calendar_name": CAL}, "calendar_name": CAL,
            "execution_backend": "native", "row_count_action": "warn", "row_count_compare_to": "previous",
            "row_count_threshold_pct_up": 50, "row_count_threshold_pct_down": 50})
        if not check("P1 the combined feed is created", s == 200 and (feed or {}).get("id"), (s, str(feed)[:300])):
            return 1
        fid = feed["id"]
        ledger.add("feed", NAME, path=f"/api/feeds/{fid}")
        s, types = r.call("GET", "/api/feed-dependency-types")
        kafka_t = next(t["id"] for t in (types or {}).get("items") or [] if str(t.get("dependency_type")).upper() == "KAFKA")
        roads = [{"kind": "kafka", "topic": TOPIC}, {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
        s, b = r.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [
            {"dependency_type_id": kafka_t, "dependency_key": f"{DS}_{ENT}_{EV}_{side}",
             "arrival_sources": roads, "require_mode": "any"} for side in ("CLOUD", "ONPREM")]})
        check("P2 CLOUD + ON-PREM dependencies, each Kafka OR QS_KAFKA_MESSAGE (no side declared: the contract infers it)",
              s == 200, (s, str(b)[:200]))

        # C1 -- SOD makes the month-end task; the messages announce S1 and release it
        task, sod = sod_task(fid, BD)
        check(f"C1 SOD made the month-end task for {BD}, WAITING on CLOUD + ON-PREM",
              task and task.get("action_decision") == "WAIT", {"sod": sod, "task": task and
                                                                 {k: task.get(k) for k in ("status", "action_decision")}})
        if not task:
            return 1
        announce(BD, S1, 3, 4)
        row, ex = task_done(fid, BD, task["id"])
        st = ex.get("stage_timings") or {}
        con = st.get("upstream_contract") or {}
        got, _ = sftp_rows(BD)
        want1 = collections.Counter([f"cloud:{S1}:{i}" for i in range(3)] + [f"prem:{S1}:{i}" for i in range(4)])
        check("C1 COMPLETED; the file == exactly the S1 rows (7), NOT the S2 rows sitting beside them",
              ex.get("status") == "completed" and got == want1, {"status": ex.get("status"), "got": dict(got),
                                                                   "error": str(ex.get("error_message"))[:300]})
        check("C1 the contract on the execution: each environment read S1, its count certified",
              {s_: (c.get("environment"), str((c.get("tokens") or {}).get("snapshot")), c.get("expected_rows"))
               for s_, c in con.items() if not s_.startswith("_")}
              == {"primary": ("CLOUD", str(S1), 3), "secondary": ("ON-PREM", str(S1), 4)}
              and (st.get("reported_rows_certification") or {}).get("verdict") == "certified",
              {"contract": {k: (v.get("environment"), (v.get("tokens") or {}).get("snapshot"), v.get("expected_rows"))
                            for k, v in con.items() if isinstance(v, dict)},
               "cert": (st.get("reported_rows_certification") or {}).get("verdict")})

        # C2 -- the upstream restates: S2
        announce(BD, S2, 5, 6)
        sup, t0 = None, time.time()
        while time.time() - t0 < 120 and not sup:
            s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={NAME}")
            tasks = [x for g in (d or {}).get("groups") or [] for x in g["tasks"]]
            sup = (tasks[0] if tasks else {}).get("superseded")
            if sup and len(sup.get("changes") or []) < 2:
                sup = None
            time.sleep(4)
        ch = {c["environment"]: (str(c["was"].get("snapshot")), str(c["now"].get("snapshot"))) for c in (sup or {}).get("changes") or []}
        check("C2 the board: SUPERSEDED with a decision -- each environment read S1, now S2",
              bool(sup and sup.get("decision_id")) and ch == {"CLOUD": (str(S1), str(S2)), "ON-PREM": (str(S1), str(S2))},
              {"decision": (sup or {}).get("decision_id"), "changes": ch})

        # C3 -- Regenerate: the decision (with the reason) + the re-run
        s, b = r.call("POST", f"/api/feed-regeneration-decisions/{sup['decision_id']}/resolve",
                      {"resolution": "regenerate", "reason": "upstream restated the month end to S2"})
        check("C3 the decision is recorded: regenerate, with the reason", s == 200, (s, str(b)[:200]))
        run_id = tasks[0]["run_id"]
        s, b = r.call("POST", f"/api/feed-runs/{run_id}/rerun")
        t0, row = time.time(), None
        while time.time() - t0 < 600:
            s, rr = r.call("GET", f"/api/feed-runs?business_date={BD.isoformat()}&limit=1000")
            row = next((x for x in (rr or {}).get("items") or [] if x["id"] == run_id), None)
            if row and row.get("status") in ("completed", "failed") and row.get("completed_at"):
                break
            time.sleep(5)
        got, _ = sftp_rows(BD)
        want2 = collections.Counter([f"cloud:{S2}:{i}" for i in range(5)] + [f"prem:{S2}:{i}" for i in range(6)])
        check("C3 regenerated: the file == exactly the S2 rows (11), certified",
              (row or {}).get("status") == "completed" and got == want2,
              {"status": (row or {}).get("status"), "got": sum(got.values()), "error": (row or {}).get("error")})

        s, d = r.call("GET", f"/api/feed-dashboard?business_date={BD.isoformat()}&search={NAME}")
        after = [x for g in (d or {}).get("groups") or [] for x in g["tasks"]]
        s, ds = r.call("GET", f"/api/feed-regeneration-decisions?business_date={BD.isoformat()}&status=open&feed_config_id={fid}")
        check("C3 after regenerating, nothing is left superseded: the delivery of the current version answered "
              "BOTH environments' decisions",
              after and after[0].get("superseded") is None and not (ds or {}).get("decisions"),
              {"superseded": after and after[0].get("superseded"), "open": (ds or {}).get("decisions")})

        # C4 -- a month end the upstream says is EMPTY on both environments
        task0, _ = sod_task(fid, BD0)
        announce(BD0, S0, 0, 0)
        row0, ex = task_done(fid, BD0, task0["id"]) if task0 else (None, {})
        st = ex.get("stage_timings") or {}
        _, text = sftp_rows(BD0)
        check("C4 an EMPTY file is delivered because every message reported 0 -- and the variance check still ran",
              ex.get("status") == "completed" and "reported 0 rows" in str((st.get("empty_result") or {}).get("reason"))
              and "row_count_check" in st and text.strip() != "" and len(text.strip().splitlines()) == 1,
              {"status": ex.get("status"), "empty": st.get("empty_result"), "rc": st.get("row_count_check"),
               "lines": len(text.strip().splitlines()), "error": str(ex.get("error_message"))[:300]})
        # C5 -- the two environments announce DIFFERENT versions
        task3, _ = sod_task(fid, BD3)
        announce(BD3, S1, 3, 6, snap_p=S2)
        row3, ex = task_done(fid, BD3, task3["id"]) if task3 else (None, {})
        st = ex.get("stage_timings") or {}
        con = st.get("upstream_contract") or {}
        got, _ = sftp_rows(BD3)
        want3 = collections.Counter([f"cloud:{S1}:{i}" for i in range(3)] + [f"prem:{S2}:{i}" for i in range(6)])
        check("C5 CLOUD announced version S1, ON-PREM version S2: each side's {version} is its OWN message's -- "
              "the file == cloud S1 rows (3) + on-prem S2 rows (6), certified per side",
              ex.get("status") == "completed" and got == want3 and sum(want3.values()) == 9
              and {s_: str((c.get("tokens") or {}).get("version")) for s_, c in con.items() if not s_.startswith("_")}
              == {"primary": str(S1), "secondary": str(S2)}
              and (st.get("reported_rows_certification") or {}).get("verdict") == "certified",
              {"status": ex.get("status"), "got": dict(got), "want": dict(want3),
               "versions": {s_: (c.get("tokens") or {}).get("version") for s_, c in con.items() if isinstance(c, dict)},
               "error": str(ex.get("error_message"))[:300]})
    finally:
        if a.keep:
            print(f"\n== KEPT (tag {TAG}): {NAME} on {BD}, {BD0} and {BD3}")
        else:
            print("\n== cleanup")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
