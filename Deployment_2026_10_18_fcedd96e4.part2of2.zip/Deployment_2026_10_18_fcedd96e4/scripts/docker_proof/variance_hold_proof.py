"""Variance HOLD, live on the Docker rig (2026-10-12, owner request R2).

The owner: "if the count moved between today and yesterday beyond the
threshold we should not send files downstream via SFTP -- hold it for RTB
support to verify, and only then send".

The owner's fact_tetb_ext feed as built (``FU_EXT_761699``: ONE shared SQL
file, the cloud query on AWS S3 through Trino ``iceberg_aws`` and the on-prem
query on the Starburst stand-in, UNION ALL by column name) cloned for a NEW
entity whose rows are seeded per business date on BOTH sides -- the data
moves, the feed does not -- delivered to the rig's real SFTP server with
``row_count_action = hold`` against the PREVIOUS business date's delivery,
threshold 50%.  Rows per date (cloud + on-prem): D1 60+40, D2 200+100,
D3 20+10, D4 600+300.

  V1  D1 (100 rows, nothing delivered before)   -> delivered to SFTP
  V2  D2 (300 rows, +200%)                      -> HELD: completed, verdict
      held, NO file on SFTP, the hold row lists 300 vs 100 (D1)
  V3  (2026-10-12: approvers are a MAPPING) RTB_SUPPORT is mapped as the
      approver for THIS feed through /api/feed-hold-approvers; rig_viewer --
      not an admin, not the owner, not mapped -- cannot release (the hold is
      not even visible: 404, the same answer as absent); the server names
      WHY each other principal may (admin / member of RTB_SUPPORT);
      nothing on SFTP
  V4  rig_analyst (a member of the release group) releases -> the SAME bytes
      (sha256 of the kept file == the SFTP file) land; verdict delivered
  V5  D3 (30 rows, -90% against D2's RELEASED 300) -> held -> rejected ->
      nothing ever on SFTP; a release after the reject is 409
  V6  --leave-held: D4 (900 rows) is left HELD for the by-clicks spec
      (frontend/e2e/docker-variance-holds.spec.ts), which releases it

  QS_RIG_ADMIN_PW=... QS_RIG_ANALYST_PW=... python variance_hold_proof.py [--leave-held]
"""
from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys
import time
import uuid

sys.path.insert(0, os.path.dirname(__file__))
import qs_docker_client as c  # noqa: E402
from auth_rls_proof import Session  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    ORA_TABLE, TOPIC, ensure_oracle_table, message, ora_rows, produce_kafka, sb_cli,
)

#: the owner's dependency shape (2026-10-12): one dependency per environment,
#: each met by the Kafka topic OR the QS_KAFKA_MESSAGE table, each carrying
#: the count that environment must certify
DATA_SOURCE = "finance_sl_balance_ext"

TEMPLATE_FEED = int(os.environ.get("QS_VH_TEMPLATE_FEED", "5055"))   # FU_EXT_761699
CLOUD_T = "iceberg_aws.fu_761699.fact_tetb_ext"
ONPREM_T = "iceberg.qs.fact_tetb_ext_fu761699"
SEED_FROM = "E7616990001"
ROWS = {"2026-09-28": (60, 40), "2026-09-29": (200, 100), "2026-09-30": (20, 10),
        "2026-10-01": (600, 300)}
GROUP = "RTB_SUPPORT"
SFTP_HOME = "/home/feeduser/inbox"
TAG = uuid.uuid4().hex[:6].upper()
res: list = []


def check(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS" if ok else "FAIL"), name, "--", str(detail)[:400], flush=True)
    return bool(ok)


def sh(*args) -> tuple:
    p = subprocess.run(list(args), capture_output=True, text=True, timeout=120)
    return p.returncode, p.stdout, p.stderr


def sftp_files(prefix: str) -> dict:
    rc, out, _ = sh("docker", "exec", "qs-sftp", "sh", "-c",
                    f"cd {SFTP_HOME} && for f in {prefix}*; do [ -f \"$f\" ] && "
                    f"echo \"$f $(sha256sum \"$f\" | cut -d' ' -f1)\"; done; true")
    return dict(line.split() for line in out.splitlines() if line.strip())


def kept_sha(path: str) -> str:
    for ctr in ("qs-local-scheduler", "qs-local-executor", "qs-local-api"):
        rc, out, _ = sh("docker", "exec", ctr, "sha256sum", path)
        if rc == 0 and out.strip():
            return out.split()[0]
    return ""


def cloud_cli(sql_text: str) -> str:
    sql_text = sql_text.rstrip().rstrip(";") + ";"
    r = subprocess.run(["docker", "exec", "-i", "qs-trino", "trino", "--output-format", "TSV",
                        "--file", "/dev/stdin"], input=sql_text, capture_output=True, text=True,
                       timeout=900)
    if r.returncode != 0:
        raise RuntimeError(f"qs-trino: {(r.stderr or r.stdout)[-400:]}")
    return r.stdout.replace(chr(13), "")


def seed(cli, table: str, code: str, bd: str, n: int) -> int:
    """n copies of one existing row, re-keyed to (code, bd, EOD) -- generated
    ON the cluster, then counted back from the cluster itself."""
    cols = [ln.split(chr(9))[0] for ln in cli(f"SHOW COLUMNS FROM {table}").splitlines() if ln.strip()]
    sel = ", ".join(
        f"'{code}'" if c_.lower() == "code" else
        f"DATE '{bd}'" if c_.lower() == "business_close_date" else
        "'EOD'" if c_.lower() == "businessevent" else f"t.{c_}" for c_ in cols)
    cli(f"INSERT INTO {table} ({', '.join(cols)}) SELECT {sel} FROM "
        f"(SELECT * FROM {table} WHERE code = '{SEED_FROM}' LIMIT 1) t "
        f"CROSS JOIN UNNEST(sequence(1, {n})) AS s(i)")
    return int(cli(f"SELECT count(*) FROM {table} WHERE code = '{code}' AND "
                   f"business_close_date = DATE '{bd}' AND businessevent = 'EOD'").split()[0])


def ensure_group(admin: Session, member: str) -> int:
    s, groups, _ = admin.call("GET", "/api/admin/user-groups")
    items = groups if isinstance(groups, list) else (groups or {}).get("items") or (groups or {}).get("groups") or []
    g = next((x for x in items if x.get("name") == GROUP), None)
    if g is None:
        s, g, _ = admin.call("POST", "/api/admin/user-groups", {"name": GROUP,
                             "description": "verifies files held by the row-count check"})
        assert s == 201, (s, g)
    gid = int(g["id"])
    s, members, _ = admin.call("GET", f"/api/admin/user-groups/{gid}/members")
    names = {m.get("username") for m in (members if isinstance(members, list) else
                                         (members or {}).get("members") or [])}
    if member not in names:
        s, b, _ = admin.call("POST", f"/api/admin/user-groups/{gid}/members", {"username": member})
        assert s in (200, 201), (s, b)
    return gid


_SEQ = [int(time.time()) % 100000 * 100]


def announce(admin: Session, fid: int, code: str, bd: str) -> None:
    """The upstream's two messages for ``bd``: CLOUD on Kafka, ON-PREM in
    the QS_KAFKA_MESSAGE table, each with the rows that environment loaded
    -- then wait until the feed's gate sees both."""
    import datetime as _dt
    nc, np_ = ROWS[bd]
    d = _dt.date.fromisoformat(bd)
    _SEQ[0] += 2
    produce_kafka([message(DATA_SOURCE, code, "EOD", d, True, "COMPLETE", nc, _SEQ[0])])
    s, conns, _ = admin.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else (conns or {}).get("items") or []
    ora_id = next(x["id"] for x in conns if x.get("name") == "oracle-otg")
    ora_rows(ora_id, [message(DATA_SOURCE, code, "EOD", d, False, "COMPLETE", np_, _SEQ[0] + 1)])
    t0 = time.time()
    while time.time() - t0 < 180:
        s, pre, _ = admin.call("GET", f"/api/feeds/{fid}/run-preflight?business_date={bd}")
        if s == 200 and (pre or {}).get("admitted"):
            return
        time.sleep(3)
    raise SystemExit(f"{bd}: the two messages were not seen by the gate in 180 s ({str(pre)[:300]})")


def run(admin: Session, fid: int, bd: str, code: str = "") -> dict:
    if code:
        announce(admin, fid, code, bd)
    s, b, _ = admin.call("POST", f"/api/feeds/{fid}/execute", {"business_date": bd})
    if s not in (200, 202):
        raise SystemExit(f"execute {bd}: {s} {b}")
    eid = b.get("execution_db_id") or b.get("id")
    t0 = time.time()
    while time.time() - t0 < 300:
        s, ex, _ = admin.call("GET", f"/api/feed-executions/{eid}")
        if (ex or {}).get("status") in ("completed", "failed", "cancelled"):
            return ex
        time.sleep(2)
    raise SystemExit(f"execution {eid} did not finish")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--leave-held", action="store_true")
    a = ap.parse_args()
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    rtb = Session("rig_analyst", os.environ["QS_RIG_ANALYST_PW"])
    stranger = Session("rig_viewer", os.environ["QS_RIG_VIEWER_PW"])
    gid = ensure_group(admin, rtb.username)
    code = f"EVH{TAG}"
    for bd, (nc, np_) in ROWS.items():
        got = (seed(cloud_cli, CLOUD_T, code, bd, nc), seed(sb_cli, ONPREM_T, code, bd, np_))
        if got != (nc, np_):
            raise SystemExit(f"seed {bd}: wanted {(nc, np_)}, the clusters count {got}")
    print(f"seeded {code} on AWS S3 (cloud) + Starburst (on-prem): {ROWS}", flush=True)
    s, tpl, _ = admin.call("GET", f"/api/feeds/{TEMPLATE_FEED}")
    if s != 200:
        raise SystemExit(f"template feed {TEMPLATE_FEED}: {s} {tpl}")
    name = f"VH_PROOF_{TAG}"
    body = {"name": name, "source_type": tpl["source_type"], "source_id": tpl["source_id"],
            "connection_id": tpl["connection_id"],
            "query_params": {**(tpl.get("query_params") or {}), "SYSTEM_ENTITY": code,
                             "EventCode": "EOD"},
            "output_format": "csv",
            "output_filename_template": name + "_{business_date:YYYYMMDD}.csv",
            # the template's password comes back MASKED ('***'): never echo it
            "destination_type": "sftp",
            "destination_config": {"host": "qs-sftp", "port": 22, "username": "feeduser",
                                   "password": "FeedPass_123", "remote_dir": "/inbox",
                                   "host_key_b64": sh("docker", "exec", "qs-sftp", "cat",
                                                      "/etc/ssh/ssh_host_ed25519_key.pub")[1].split()[1]},
            "execution_backend": "native", "row_count_action": "hold",
            "row_count_compare_to": "previous", "row_count_threshold_pct": 50}
    s, feed, _ = admin.call("POST", "/api/feeds", body)
    if s != 200:
        raise SystemExit(f"create feed: {s} {feed}")
    fid = feed["id"]
    print(f"feed {fid} {name}", flush=True)
    # ── the dependencies, the owner's way: CLOUD + ON-PREM, both roads ──
    s, conns, _ = admin.call("GET", "/api/connections")
    conns = conns if isinstance(conns, list) else (conns or {}).get("items") or []
    ora_id = next(x["id"] for x in conns if x.get("name") == "oracle-otg")
    ensure_oracle_table(ora_id)
    s, types, _ = admin.call("GET", "/api/feed-dependency-types")
    kafka_t = next(t["id"] for t in (types or {}).get("items") or [] if str(t.get("dependency_type")).upper() == "KAFKA")
    roads = [{"kind": "kafka", "topic": TOPIC}, {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
    # ... and it belongs to its SYSTEM_ENTITY's Feed Group, like every month-end feed
    s, grp, _ = admin.call("POST", "/api/feed-groups", {"name": code})
    gid_fg = (grp or {}).get("id")
    if gid_fg:
        admin.call("PUT", f"/api/feed-groups/{gid_fg}/feeds", {"assign": [fid], "unassign": []})
    s, deps_b, _ = admin.call("PUT", f"/api/feeds/{fid}/dependencies", {"dependencies": [
        {"dependency_type_id": kafka_t, "dependency_key": f"{DATA_SOURCE}_{code}_EOD_{side}",
         "arrival_sources": roads, "require_mode": "any"} for side in ("CLOUD", "ONPREM")]})
    check("V0 the feed depends on its CLOUD and ON-PREM messages (Kafka OR QS_KAFKA_MESSAGE)",
          s == 200, f"{s} {str(deps_b)[:200]}")
    s, appr, _ = admin.call("POST", "/api/feed-hold-approvers",
                            {"scope": "feed", "scope_id": fid, "user_group_id": gid})
    check(f"V0 {GROUP} mapped as the approver for {name} (a mapping, not a constant)",
          s == 201 and appr.get("applies_to") == f"feed {name}", f"{s} {appr}")

    def holds(status=None):
        q = f"/api/feed-variance-holds?feed_config_id={fid}" + (f"&status={status}" if status else "")
        return rtb.call("GET", q)[1]

    # V1
    ex1 = run(admin, fid, "2026-09-28", code)
    files = sftp_files(name)
    check("V1 D1 delivered (nothing to compare with)",
          ex1["status"] == "completed" and len(files) == 1
          and (ex1.get("stage_timings") or {}).get("row_count_check", {}).get("skipped_reason")
          == "no_previous_delivery", f"{ex1['status']} files={list(files)}")

    # V2
    ex2 = run(admin, fid, "2026-09-29", code)
    st2 = ex2.get("stage_timings") or {}
    h = (holds("held") or {}).get("holds") or []
    check("V2 D2 HELD: completed, verdict held, no SFTP file",
          ex2["status"] == "completed" and st2.get("delivery_chain", {}).get("verdict") == "held"
          and len(sftp_files(name)) == 1 and not ex2.get("destination_path"),
          f"{ex2['status']} {st2.get('delivery_chain')} files={list(sftp_files(name))}")
    check("V2 the hold says 300 vs 100 delivered on 2026-09-28 (+200%)",
          len(h) == 1 and (h[0]["actual_rows"], h[0]["baseline_rows"], h[0]["baseline_business_date"])
          == (300, 100, "2026-09-28") and round(h[0]["delta_pct"]) == 200, h[:1])
    hold = h[0]

    # V3
    s, b, _ = stranger.call("POST", f"/api/feed-variance-holds/{hold['id']}/release",
                            {"reason": "a stranger tries to send it anyway"})
    check("V3 rig_viewer (not admin, not owner, not mapped) cannot release: 404, nothing sent",
          s == 404 and len(sftp_files(name)) == 1, f"{s} {b}")
    who = {n: sess.call("GET", f"/api/feed-variance-holds/{hold['id']}")[1].get("decision_authority")
           for n, sess in (("admin", admin), ("rtb", rtb))}
    check("V3 the server names why each may decide: admin / member of the mapped group",
          who["admin"] == "admin" and who["rtb"] == f"member of {GROUP} (approver for this feed)", who)

    # V4
    sha_kept = kept_sha(hold["artifact_path"])
    s, b, _ = rtb.call("POST", f"/api/feed-variance-holds/{hold['id']}/release",
                       {"reason": "month-end volume confirmed with the upstream desk"})
    files = sftp_files(name)
    d2 = [f for f in files if "20260929" in f]
    check("V4 a group member releases: the SAME bytes land on SFTP",
          s == 200 and b.get("status") == "released" and len(d2) == 1
          and sha_kept and files[d2[0]] == sha_kept,
          f"{s} {b.get('status')} {b.get('delivered_uri')} kept={sha_kept[:12]} sftp={files}")
    s, ex2b, _ = admin.call("GET", f"/api/feed-executions/{ex2['id']}")
    check("V4 the execution now says delivered, by whom",
          (ex2b.get("stage_timings") or {}).get("delivery_chain", {}).get("verdict") == "delivered"
          and (ex2b.get("stage_timings") or {}).get("delivery_chain", {}).get("released_by") == rtb.username
          and ex2b.get("destination_path"), (ex2b.get("stage_timings") or {}).get("delivery_chain"))

    # V5
    ex3 = run(admin, fid, "2026-09-30", code)
    h3 = ((holds("held") or {}).get("holds") or [None])[0]
    check("V5 D3 compared with D2's RELEASED 300 -> held",
          h3 is not None and (h3["actual_rows"], h3["baseline_rows"], h3["direction"]) == (30, 300, "down"), h3)
    s, b, _ = rtb.call("POST", f"/api/feed-variance-holds/{h3['id']}/reject",
                       {"reason": "upstream sent a partial extract"})
    s2, b2, _ = rtb.call("POST", f"/api/feed-variance-holds/{h3['id']}/release",
                         {"reason": "changed my mind about this one"})
    check("V5 rejected: nothing on SFTP for D3, a later release is 409",
          s == 200 and b.get("status") == "rejected" and s2 == 409
          and not [f for f in sftp_files(name) if "20260930" in f], f"{s} {b.get('status')} {s2}")

    if a.leave_held:
        run(admin, fid, "2026-10-01", code)
        h4 = ((holds("held") or {}).get("holds") or [None])[0]
        check("V6 D4 left HELD for the by-clicks spec", h4 is not None, h4 and h4["id"])
        print(f"LEFT_HELD feed={fid} name={name} hold={h4 and h4['id']}", flush=True)

    print(f"\n{sum(res)}/{len(res)} passed", flush=True)
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
