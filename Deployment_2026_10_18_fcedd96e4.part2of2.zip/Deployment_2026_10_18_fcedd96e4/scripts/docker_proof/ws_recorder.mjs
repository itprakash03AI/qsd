// Records every WebSocket event a signed-in browser would receive, one JSON
// line per event with its arrival time, until the stop file appears
// (2026-10-07).  The proof harness starts it, drives the product, then reads
// the file and checks the events against what happened on the cluster.
//
//   node ws_recorder.mjs <out.jsonl> <stopfile>      (env QS_WS_TOKEN, QS_WS_USER)
import { appendFileSync, existsSync, writeFileSync } from 'fs';

const [out, stop] = process.argv.slice(2);
const token = process.env.QS_WS_TOKEN || '';
const user = process.env.QS_WS_USER || 'rig_admin';
const base = process.env.QS_WS_BASE || 'ws://127.0.0.1:8000';
writeFileSync(out, '');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let ws;
let opened = false;

function connect() {
  ws = new WebSocket(`${base}/ws/proof-${Date.now()}`);
  ws.onopen = () => {
    opened = true;
    ws.send(JSON.stringify({ type: 'identify', username: user, token }));
    appendFileSync(out, JSON.stringify({ t: Date.now() / 1000, msg: { type: '__recorder_open__' } }) + '\n');
  };
  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { msg = { raw: String(ev.data).slice(0, 400) }; }
    appendFileSync(out, JSON.stringify({ t: Date.now() / 1000, msg }) + '\n');
  };
  ws.onclose = () => { opened = false; };
  ws.onerror = () => {};
}

connect();
while (!existsSync(stop)) {
  await sleep(500);
  if (!opened && ws.readyState === WebSocket.CLOSED) connect();   // reconnect like the app does
}
try { ws.close(); } catch {}
process.exit(0);
