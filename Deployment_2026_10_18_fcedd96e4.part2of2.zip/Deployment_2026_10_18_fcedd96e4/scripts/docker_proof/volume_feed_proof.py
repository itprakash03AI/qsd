"""VOLUME: one feed of the owner's real query at millions of rows (2026-10-11).

The owner: "8 rows per feed u tested? ... some feed will have 40 million rows".
Every earlier proof checked correctness and orchestration with a handful of
rows per file.  This one runs ONE feed -- the owner's 75-column
fact_tetb_ext query (scripts/docker_proof/fixtures/test_query_001.json), cloud
side on REAL AWS S3 (Iceberg via qs-trino catalog iceberg_aws) + on-prem side
on qs-trino-sb, UNION ALL by name, CSV to SFTP -- at a chosen total row count,
and measures what volume does:

  V0  seeding: N/2 rows per side for ONE (date, entity, event) partition,
      generated ON the clusters (INSERT .. SELECT over UNNEST(sequence())),
      timed; truth = Trino's own count + control totals per side
  V1  the feed runs (backfill for the date, delivered) and COMPLETES within
      --timeout; wall time, rows/s
  V2  the delivered file on the SFTP server: data lines == cloud + on-prem
      rows; control totals recomputed FROM THE FILE (awk inside qs-sftp, no
      copy of a multi-GB file) == the clusters' (count, sum of SNAP_VERSION,
      sum of the row-id embedded in SOURCE_DATA_ROW)
  V3  the run record: total_rows == N, cross_source primary/secondary ==
      the per-side truth, the certificate reconciles
  V4  peak memory of api / scheduler / executor / both Trinos (docker stats
      every 10 s), any OOM-kill or restart is a FAIL with its name
  V5  output file size, DuckDB spill seen in the logs (said, not judged)

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    python scripts/docker_proof/volume_feed_proof.py --rows 1000000
    python scripts/docker_proof/volume_feed_proof.py --rows 10000000
    python scripts/docker_proof/volume_feed_proof.py --rows 40000000 --timeout 14400
    python scripts/docker_proof/volume_feed_proof.py --rows 1000000 --backend spark_k8s
    python scripts/docker_proof/volume_feed_proof.py --sweep-leftovers [--execute]

Everything created is removed in a finally (the AWS schema CASCADE, the
on-prem table, the queries, the connection, the feed, the SFTP file).
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from feed_triggers_proof import Rig, check, psql, res  # noqa: E402
from monthly_kafka_merge_feeds_proof import pick_cloud, sftp_host_key  # noqa: E402
from proof_cleanup import Ledger, Rule, sweep_flags, sweep_leftovers  # noqa: E402
from tetb_real_e2e_proof import (  # noqa: E402
    AWS_BUCKET, DENV, SB_HOST, SB_PORT, SFTP, TABLES, cloud_cli, ddl,
    drop_schema_cascade, load_queries, parse_query, sb_cli,
)

TAG = str(int(time.time()))[-6:]
SPEC = TABLES["ext"]
CLOUD_SCHEMA = f"iceberg_aws.vol_{TAG}"
CLOUD_TABLE = f"{CLOUD_SCHEMA}.fact_tetb_ext"
PREM_TABLE = f"iceberg.qs.fact_tetb_ext_vol{TAG}"


def configure(table: str, reuse_tag: str | None = None) -> None:
    """--table ext (fact_tetb_ext, 75 output columns) or tetb (fact_tetb,
    ALL 460 output columns of the owner's query); --reuse TAG adopts a kept
    run's tables and feed instead of seeding new ones."""
    global SPEC, CLOUD_TABLE, PREM_TABLE, TAG, CLOUD_SCHEMA, ENTITY
    if reuse_tag:
        TAG = reuse_tag
        CLOUD_SCHEMA = f"iceberg_aws.vol_{TAG}"
        ENTITY = f"V{TAG}"
    SPEC = TABLES[table]
    CLOUD_TABLE = f"{CLOUD_SCHEMA}.{SPEC['table']}"
    PREM_TABLE = f"iceberg.qs.{SPEC['table']}_vol{TAG}"
ENTITY, EVENT = f"V{TAG}", "EOD"
BD = dt.date(2026, 9, 30)
WATCH = ("qs-local-api", "qs-local-scheduler", "qs-local-executor", "qs-trino", "qs-trino-sb")


def seed_sql(table: str, types: dict, side: str, n: int, offset: int = 0) -> str:
    """N rows for ONE partition, generated on the cluster.  sequence() caps
    at 10,000 elements, so the row id is a cross product a x b."""
    a = min(n, 10000)
    b = (n + a - 1) // a
    exprs = []
    for c, t in types.items():
        if c == "BUSINESS_CLOSE_DATE":
            e = f"DATE '{BD.isoformat()}'"
        elif c == "CODE":
            e = f"'{ENTITY}'"
        elif c == "BUSINESSEVENT":
            e = f"'{EVENT}'"
        elif c == "SOURCE_DATA_ROW":
            e = f"concat('{side}:', CAST(id AS VARCHAR))"
        elif t == "DATE":
            e = f"DATE '{BD.isoformat()}'"
        elif t == "BIGINT":
            e = "CAST(id AS BIGINT)"
        elif t == "DOUBLE":
            e = "CAST(id AS DOUBLE) + 0.5"
        else:
            e = f"concat('{c[:3].lower()}{side[0]}', CAST(id % 997 AS VARCHAR))"
        exprs.append(f"{e} AS {c.lower()}")
    return (f"INSERT INTO {table} ({', '.join(c.lower() for c in types)}) "
            f"SELECT {', '.join(exprs)} FROM (SELECT (x - 1) * {b} + y + {offset} AS id "
            f"FROM UNNEST(sequence(1, {a})) t1(x) CROSS JOIN UNNEST(sequence(1, {b})) t2(y)) "
            f"WHERE id <= {n + offset}")


def truth(cli, table: str) -> dict:
    """count, sum(snap_version), sum of the row id inside source_data_row --
    the control totals the file must reproduce."""
    out = cli(f"SELECT count(*), sum(snap_version), "
              f"sum(CAST(split_part(source_data_row, ':', 2) AS BIGINT)) FROM {table} "
              f"WHERE business_close_date = DATE '{BD.isoformat()}' AND code = '{ENTITY}' "
              f"AND businessevent = '{EVENT}'").strip().replace('"', "")
    n, s1, s2 = out.split(",") if "," in out else out.split("\t")
    return {"rows": int(n), "sum_snap": int(s1 or 0), "sum_id": int(s2 or 0)}


APP_CONTAINERS = ("qs-local-api", "qs-local-scheduler", "qs-local-executor")
HERE = os.path.dirname(os.path.abspath(__file__))


def read_env_file(path: str) -> dict:
    out = {}
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            out[k.replace("export ", "").strip()] = v.strip().strip('"').strip("'")
    return out


def read_props(path: str) -> dict:
    return read_env_file(path)


def anon_mib(container: str):
    st = subprocess.run(["docker", "exec", container, "sh", "-c",
                         "grep -E '^anon ' /sys/fs/cgroup/memory.stat"],
                        capture_output=True, text=True, env=DENV).stdout.split()
    return int(st[1]) / 1048576 if len(st) == 2 and st[1].isdigit() else None


def executed_in(fid, since: str) -> list:
    """The app container(s) whose engine logged this feed's execution start."""
    return [c for c in APP_CONTAINERS
            if f"Feed {fid} execution started" in _logs(c, since)]


def _logs(container: str, since: str) -> str:
    p = subprocess.run(["docker", "logs", "--since", since, container], capture_output=True, text=True,
                       env=DENV, errors="replace")
    return (p.stdout or "") + (p.stderr or "")


class Sampler(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.peak: dict = {}
        self.stop_ = threading.Event()

    def run(self):
        while not self.stop_.is_set():
            out = subprocess.run(["docker", "stats", "--no-stream", "--format", "{{.Name}} {{.MemUsage}}", *WATCH],
                                 capture_output=True, text=True, env=DENV).stdout
            for line in out.splitlines():
                name, use = line.split(" ", 1)
                m = re.match(r"([\d.]+)(\w+)", use)
                if m:
                    v = float(m.group(1)) * {"KiB": 1 / 1024, "MiB": 1, "GiB": 1024}.get(m.group(2), 1)
                    self.peak[name] = max(self.peak.get(name, 0), v)
            # ANONYMOUS memory (real, not page cache -- docker stats counts the
            # file cache a multi-GB CSV write leaves behind) of EVERY app
            # container: a run executes wherever the scheduler lease is, and
            # measuring only the scheduler printed PASS while the API that
            # actually ran the feed sat at its limit (2026-10-11).
            for c in APP_CONTAINERS:
                v = anon_mib(c)
                if v is not None:
                    k = c.replace("qs-local-", "") + "_anon"
                    self.peak[k] = max(self.peak.get(k, 0), v)
            self.stop_.wait(2)


def health() -> dict:
    out = {}
    for c in WATCH:
        r = subprocess.run(["docker", "inspect", c, "--format", "{{.RestartCount}} {{.State.OOMKilled}} {{.State.Running}}"],
                           capture_output=True, text=True, env=DENV)
        out[c] = r.stdout.strip()
    return out


def file_totals(name: str, ncols: int) -> dict:
    """Recompute the control totals FROM THE DELIVERED FILE inside qs-sftp
    (awk streams it; nothing multi-GB crosses the host).  Columns located by
    the header: snap_version and SOURCE_DATA_ROW."""
    path = f"{SFTP['home']}/{name}"
    awk = ("{sub(/\r$/,\"\")} NR==1{sub(/^\xef\xbb\xbf/,\"\");for(i=1;i<=NF;i++){h=tolower($i);gsub(/\"/,\"\",h);"
           "if(h==\"snap_version\")s=i;if(h==\"source_data_row\")r=i};next}"
           "{n++;gsub(/\"/,\"\",$s);ss+=$s;v=$r;gsub(/\"/,\"\",v);split(v,p,\":\");si+=p[2]}"
           "END{printf \"%d %.0f %.0f\\n\",n,ss,si}")
    r = subprocess.run(["docker", "exec", SFTP["container"], "awk", "-F", ",", awk, path],
                       capture_output=True, text=True, env=DENV, timeout=7200)
    sz = subprocess.run(["docker", "exec", SFTP["container"], "stat", "-c", "%s", path],
                        capture_output=True, text=True, env=DENV).stdout.strip()
    parts = r.stdout.split()
    if len(parts) != 3:
        return {"error": (r.stderr or r.stdout)[-300:]}
    return {"rows": int(parts[0]), "sum_snap": int(parts[1]), "sum_id": int(parts[2]),
            "bytes": int(sz) if sz.isdigit() else None}


def main(argv=None) -> int:
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=1_000_000, help="TOTAL output rows (half per side)")
    ap.add_argument("--backend", default="native", choices=["native", "spark_k8s", "auto"])
    ap.add_argument("--timeout", type=int, default=7200)
    ap.add_argument("--chunk", type=int, default=500_000, help="rows per seeding INSERT")
    ap.add_argument("--prem-rows", type=int, default=None,
                    help="rows on the on-prem side (default: half); the cloud side gets the rest")
    ap.add_argument("--table", default="ext", choices=["ext", "tetb"],
                    help="ext = fact_tetb_ext (75 cols); tetb = fact_tetb (ALL 460 cols)")
    ap.add_argument("--shared-sql", action="store_true",
                    help="the feed's source is ONE shared SQL file (the owner's cloud query on the "
                         "cloud connection + '-- ===SECONDARY===' + the on-prem query), as reports use")
    ap.add_argument("--keep", action="store_true", help="keep the feed, tables and file for inspection")
    ap.add_argument("--reuse", default=None, metavar="TAG",
                    help="re-run the feed of a KEPT run (its seeded tables + feed) without reseeding")
    ap.add_argument("--engine-write", action="store_true",
                    help="rung 1: each cluster writes its side's parquet to S3 (Hive scratch schemas)")
    args = ap.parse_args(rest)
    configure(args.table, args.reuse)
    r = Rig()
    if sweep:
        rules = [Rule("feed", r"VOL_\d{6}", list_path="/api/feeds", delete_path="/api/feeds/{id}"),
                 Rule("saved query", r"vol_(cloud|prem)_\d{6}", list_path="/api/queries", delete_path="/api/queries/{id}"),
                 Rule("connection", r"sb-onprem-vol-\d{6}", list_path="/api/connections", delete_path="/api/connections/{id}"),
                 Rule("sql file", r"vol_shared_\d{6}", list_path="/api/sql-files", delete_path="/api/sql-files/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for line in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'vol_%'").splitlines():
            s = line.strip().strip('"')
            if re.fullmatch(r"vol_\d{6}", s):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{s} (cascade)")
                if execute:
                    print("   ", drop_schema_cascade(cloud_cli, f"iceberg_aws.{s}"))
        for line in sb_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%_vol%'").splitlines():
            t = line.strip().strip('"')
            if re.fullmatch(r"fact_tetb(_ext)?_vol\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    sb_cli(f"DROP TABLE iceberg.qs.{t}")
        return rc

    # --prem-rows splits unevenly (the rig's 4.6 GB on-prem Trino cannot CTAS
    # 20M rows of 75 columns -- OOM-killed three times; a real Starburst can).
    prem_n = args.prem_rows if args.prem_rows is not None else args.rows // 2
    side_n = {"cloud": args.rows - prem_n, "prem": prem_n}
    cloud_sql, prem_sql = load_queries(SPEC)
    cloud_sql = cloud_sql.replace(SPEC["from_cloud"], CLOUD_TABLE)
    prem_sql = prem_sql.replace(SPEC["from_onprem"], PREM_TABLE)
    _, c_types = parse_query(cloud_sql, SPEC["alias"])
    _, p_types = parse_query(prem_sql, SPEC["alias"])
    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit(". ~/.qs_keys/starburst_like.env")
    print(f"== VOLUME {args.rows:,} rows of {SPEC['table']} ({len(c_types)} columns in the owner's query) "
          f"(cloud {side_n['cloud']:,} + on-prem {side_n['prem']:,}), backend {args.backend}"
          f"{' + engine_write' if args.engine_write else ''}{' + SHARED SQL FILE' if args.shared_sql else ''}, tag {TAG}")
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))
    print("   anonymous memory BEFORE the run: "
          + ", ".join(f"{c.replace('qs-local-', '')} {round(anon_mib(c) or 0)} MiB" for c in APP_CONTAINERS))
    t_start = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    fid = None
    sampler = Sampler()
    sampler.start()
    h0 = health()
    try:
        if not args.reuse:
            # ── V0 seed ON the clusters ─────────────────────────────────────
            t0 = time.time()
            cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/vol_{TAG}')")
            ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
            cloud_cli(ddl(CLOUD_TABLE, c_types, hive=False) + ";\n", stdin=True)
            sb_cli(ddl(PREM_TABLE, p_types, hive=False) + ";\n", stdin=True)
            ledger.add("on-prem table", PREM_TABLE, remover=lambda: (bool(sb_cli(f"DROP TABLE {PREM_TABLE}") is not None), "dropped"))
            errs = []

            def _seed(cli, table, types, side):
                # In CHUNKS of --chunk rows (ids offset per chunk): one 5M-row,
                # 75-column INSERT OOM-killed the 3 GB on-prem stand-in (2026-10-11).
                try:
                    done = 0
                    while done < side_n[side]:
                        k = min(args.chunk, side_n[side] - done)
                        cli(seed_sql(table, types, side, k, offset=done) + ";\n", stdin=True)
                        done += k
                except Exception as exc:  # noqa: BLE001
                    errs.append(f"{side}: {exc}")
            th = [threading.Thread(target=_seed, args=(cloud_cli, CLOUD_TABLE, c_types, "cloud")),
                  threading.Thread(target=_seed, args=(sb_cli, PREM_TABLE, p_types, "prem"))]
            [x.start() for x in th]
            [x.join() for x in th]
            seed_s = round(time.time() - t0, 1)
            tc, tp = truth(cloud_cli, CLOUD_TABLE), truth(sb_cli, PREM_TABLE)
            check(f"V0 seeded cloud {side_n['cloud']:,} + on-prem {side_n['prem']:,} rows in {seed_s}s (cloud on REAL "
                  f"AWS S3 + on-prem); truth: cloud {tc['rows']:,}, on-prem {tp['rows']:,}",
                  not errs and tc["rows"] == side_n["cloud"] and tp["rows"] == side_n["prem"],
                  {"errors": errs, "cloud": tc, "prem": tp})
            if errs:
                return 1

            # ── the feed: owner's query both sides, UNION ALL by name, SFTP ──
            cloud_id, _ = pick_cloud(r, "")
            prem_unload = {}
            if args.engine_write:
                # Rung 1: each CLUSTER writes its side's parquet through a Hive
                # scratch schema with external_location; QueryStudio only lists,
                # footer-checks and byte-copies the parts.  Both connections
                # DECLARE it (unload_scratch_* + unload_s3_location + the S3
                # identity QueryStudio reads the parts with).
                cloud_cli(f"CREATE SCHEMA IF NOT EXISTS hive_aws.qs_unload "
                          f"WITH (location = 's3://{AWS_BUCKET}/qs-unload/')")
                sb_cli("CREATE SCHEMA IF NOT EXISTS hive.qs_unload WITH (location = 's3://qs-data/qs-unload/')")
                aws = read_env_file(os.path.expanduser("~/.qs_keys/aws.env"))
                s, b = r.call("POST", "/api/connections", {
                    "name": f"trino-cloud-ew-{TAG}", "connection_type": "trino",
                    "config": {"host": "qs-trino", "port": 8080, "user": "sweep", "http_scheme": "http",
                               "catalog": "iceberg_aws", "schema": "fin",
                               "unload_scratch_catalog": "hive_aws", "unload_scratch_schema": "qs_unload",
                               "unload_s3_location": f"s3://{AWS_BUCKET}/qs-unload",
                               "unload_s3_access": {"auth_mode": "keys", "region_name": aws["AWS_REGION"],
                                                    "aws_access_key_id": aws["AWS_ACCESS_KEY_ID"],
                                                    "aws_secret_access_key": aws["AWS_SECRET_ACCESS_KEY"]}}})
                cloud_id = (b or {}).get("id")
                if not cloud_id:
                    raise SystemExit(f"engine-write cloud connection refused: {s} {str(b)[:300]}")
                ledger.add("connection", f"trino-cloud-ew-{TAG}", path=f"/api/connections/{cloud_id}")
                minio = read_props(os.path.join(HERE, "starburst_like", "generated", "catalog", "iceberg.properties"))
                prem_unload = {"unload_scratch_catalog": "hive", "unload_scratch_schema": "qs_unload",
                               "unload_s3_location": "s3://qs-data/qs-unload",
                               "unload_s3_access": {"auth_mode": "keys", "region_name": minio["s3.region"],
                                                    "endpoint_url": minio["s3.endpoint"], "path_style": True,
                                                    "addressing_style": "path",
                                                    "aws_access_key_id": minio["s3.aws-access-key"],
                                                    "aws_secret_access_key": minio["s3.aws-secret-key"]}}
            s, b = r.call("POST", "/api/connections", {
                "name": f"sb-onprem-vol-{TAG}", "connection_type": "starburst",
                "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                           "password": pw, "http_scheme": "https", "verify_ssl": False,
                           "catalog": "iceberg", "schema": "qs", **prem_unload}})
            prem_id = (b or {}).get("id")
            ledger.add("connection", f"sb-onprem-vol-{TAG}", path=f"/api/connections/{prem_id}")
            if args.shared_sql:
                # ONE shared SQL file: the owner's cloud query on the cloud
                # connection, the on-prem query after -- ===SECONDARY=== on the
                # on-prem connection, UNION -- the object a report runs too.
                s, sf = r.call("POST", "/api/sql-files", {
                    "name": f"vol_shared_{TAG}", "sql": cloud_sql, "connection_id": cloud_id,
                    "secondary_sql": prem_sql, "secondary_connection_id": prem_id,
                    "combine_mode": "union", "is_shared": True})
                sql_file_id = (sf or {}).get("id")
                check(f"V1 ONE shared SQL file holds the owner's cloud + on-prem {SPEC['table']} queries ({s})",
                      bool(sql_file_id), str(sf)[:300])
                if not sql_file_id:
                    return 1
                ledger.add("sql file", f"vol_shared_{TAG}", path=f"/api/sql-files/{sql_file_id}")
                source = {"source_type": "sql_file", "source_id": sql_file_id, "connection_id": cloud_id}
            else:
                q = {}
                for side, cid, sql in (("cloud", cloud_id, cloud_sql), ("prem", prem_id, prem_sql)):
                    s, qq = r.call("POST", "/api/queries", {"name": f"vol_{side}_{TAG}",
                                                           "query_config": {"files": [], "raw_sql": sql, "connection_id": cid}})
                    q[side] = (qq or {}).get("id")
                    ledger.add("saved query", f"vol_{side}_{TAG}", path=f"/api/queries/{q[side]}")
                source = {"source_type": "saved_query", "source_id": q["cloud"], "connection_id": cloud_id,
                          "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
                          "secondary_source_id": q["prem"]}
            fname = f"VOL_{TAG}_{BD:%Y%m%d}.csv"
            s, fb = r.call("POST", "/api/feeds", {
                "name": f"VOL_{TAG}", **source,
                # a shared SQL file carries its OWN second side and combine mode
                **({} if args.shared_sql else {"combine_mode": "union"}),
                "output_format": "csv", "output_filename_template": f"VOL_{TAG}_{{business_date:YYYYMMDD}}.csv",
                "destination_type": "sftp",
                "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                       "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                       "host_key_b64": sftp_host_key()},
                "execution_backend": args.backend, "notify_on_failure": False,
                "query_params": {"SYSTEM_ENTITY": ENTITY, "EventCode": EVENT}})
            fid = (fb or {}).get("id")
            check(f"V1 the feed VOL_{TAG} is created ({s})", bool(fid), str(fb)[:300])
            if not fid:
                return 1
            ledger.add("feed", f"VOL_{TAG}", path=f"/api/feeds/{fid}")
            ledger.add("sftp file", fname, remover=lambda: (subprocess.run(
                ["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fname}"], env=DENV).returncode == 0, "rm"))

        else:
            # ── --reuse: the kept run's tables and feed, the truth re-read ──
            tc, tp = truth(cloud_cli, CLOUD_TABLE), truth(sb_cli, PREM_TABLE)
            check(f"V0 reused tag {TAG}: cloud {tc['rows']:,} + on-prem {tp['rows']:,} rows already seeded",
                  tc["rows"] == side_n["cloud"] and tp["rows"] == side_n["prem"], {"cloud": tc, "prem": tp})
            _, feeds = r.call("GET", "/api/feeds")
            feeds = feeds if isinstance(feeds, list) else (feeds or {}).get("items") or []
            fid = next((f["id"] for f in feeds if f.get("name") == f"VOL_{TAG}"), None)
            fname = f"VOL_{TAG}_{BD:%Y%m%d}.csv"
            if not check(f"V1 the kept feed VOL_{TAG} exists", bool(fid), fid):
                return 1
            subprocess.run(["docker", "exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{fname}"], env=DENV)

        # ── V1 run it ──────────────────────────────────────────────────
        def _execs():
            _, ex_ = r.call("GET", f"/api/feeds/{fid}/executions")
            return ex_ if isinstance(ex_, list) else (ex_ or {}).get("items") or []
        # only an execution that did NOT exist before this run is its answer
        # (a kept feed's earlier failed execution must not be read as it)
        before = {x.get("id") for x in _execs()}
        t1 = time.time()
        if args.reuse:
            run_id = psql(f"select id from feed_runs where feed_config_id={fid} and business_date='{BD}' "
                          f"order by id desc limit 1").strip()
            s, b = r.call("POST", f"/api/feed-runs/{run_id}/rerun")
            check(f"V1 the kept run {run_id} is re-run ({s})", s in (200, 202), str(b)[:300])
        else:
            r.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": BD.isoformat(), "end_date": BD.isoformat(),
                                                        "deliver": True, "reason": "volume proof (test data only)"})
        e = {}
        while time.time() - t1 < args.timeout:
            new = [x for x in _execs() if x.get("id") not in before]
            if new and new[0].get("status") in ("completed", "failed", "error"):
                e = new[0]
                break
            time.sleep(15)
        run_s = round(time.time() - t1, 1)
        rate = round(args.rows / run_s) if run_s else 0
        check(f"V1 the feed COMPLETED in {run_s}s ({rate:,} rows/s end to end)", e.get("status") == "completed",
              {"status": e.get("status"), "stage": e.get("failed_stage"), "error": str(e.get("error_message"))[:400]})

        # ── V2 the delivered file vs the clusters' control totals ───────
        if e.get("status") == "completed":
            ft = file_totals(fname, len(c_types))
            hdr = subprocess.run(["docker", "exec", SFTP["container"], "sh", "-c",
                                  f"head -1 {SFTP['home']}/{fname} | tr ',' '\n' | wc -l"],
                                 capture_output=True, text=True, env=DENV).stdout.strip()
            want_cols = len(parse_query(cloud_sql, SPEC["alias"])[0])
            check(f"V2 the SFTP file carries EVERY column of the owner's query: {hdr} == {want_cols}",
                  hdr.isdigit() and int(hdr) == want_cols, {"file_columns": hdr, "query_columns": want_cols})
            want = {k: tc[k] + tp[k] for k in ("rows", "sum_snap", "sum_id")}
            check(f"V2 the SFTP file: {ft.get('rows', 0):,} data rows, control totals == cloud + on-prem "
                  f"(count, sum snap_version, sum row-id); {round((ft.get('bytes') or 0) / 1e9, 2)} GB",
                  all(ft.get(k) == want[k] for k in want) and want["rows"] > 0, {"file": ft, "truth": want})
            _, full = r.call("GET", f"/api/feed-executions/{e.get('id')}")
            st = (full or {}).get("stage_timings") or {}
            print("   stage timings:", {k: v for k, v in st.items() if isinstance(v, (int, float))})
            fm = (full or {}).get("files_metadata") or {}
            xs = fm.get("cross_source") or {}
            check("V3 the run record: total_rows == N and cross_source primary/secondary == each side's truth",
                  (full or {}).get("total_rows") == args.rows and xs.get("primary_rows") == tc["rows"]
                  and xs.get("secondary_rows") == tp["rows"],
                  {"total_rows": (full or {}).get("total_rows"), "cross_source": {k: xs.get(k) for k in
                   ("primary_rows", "secondary_rows", "expected_rows")}})
            if args.engine_write:
                lg = subprocess.run(["docker", "logs", "--since", t_start, "qs-local-scheduler"],
                                    capture_output=True, text=True, env=DENV, errors="replace")
                rungs = re.findall(rf"\[write-ladder\] feed={fid} rung=(\S+) reason=(\S+)",
                                   (lg.stdout or "") + (lg.stderr or ""))
                print("   write-ladder decisions:", rungs, "| files_metadata.write_ladder:",
                      fm.get("write_ladder"))
                check("V3b BOTH sides took rung 1 (engine_write): the clusters wrote the parquet",
                      len(rungs) >= 2 and all(r_[0] == "engine_write" for r_ in rungs), rungs)
    finally:
        sampler.stop_.set()
        sampler.join(15)
        h1 = health()
        # "RestartCount OOMKilled Running": a restart or an OOM kill is a failure
        broken = {c: (h0.get(c), h1.get(c)) for c in WATCH
                  if (h0.get(c) or "").split()[:2] != (h1.get(c) or "").split()[:2]
                  or (h1.get(c) or "").split()[1:2] == ["true"]}
        peaks = {k: f"{round(v)} MiB" for k, v in sorted(sampler.peak.items())}
        check(f"V4 no container restarted or was OOM-killed; peak memory {peaks}", not broken, broken)
        if fid:
            where = executed_in(fid, t_start)
            # Production shape: the API is a webserver and the SCHEDULER pod's
            # queue worker runs feeds.  A run anywhere else means the rig is
            # mis-shaped (two schedulers) and the memory above measured the
            # wrong process -- fail rather than report a number about nothing.
            check(f"V4b the run executed in the scheduler container (production shape): {where}",
                  where == ["qs-local-scheduler"], where)
        spill = subprocess.run(["docker", "logs", "--since", "3h", "qs-local-scheduler"], capture_output=True,
                               text=True, env=DENV)
        spills = len(re.findall(r"spill", (spill.stdout or "") + (spill.stderr or ""), re.I))
        print(f"V5 DuckDB spill mentions in the scheduler log (3 h): {spills}")
        if args.keep:
            print(f"\n== KEPT (tag {TAG}): feed VOL_{TAG}, {CLOUD_TABLE}, {PREM_TABLE}, the SFTP file; "
                  f"--sweep-leftovers --execute removes")
        else:
            print("\n== cleanup")
            ok, failed = ledger.cleanup()
            print(f"cleanup: {ok} objects removed, {len(failed)} could not be {failed[:3]}")
    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
