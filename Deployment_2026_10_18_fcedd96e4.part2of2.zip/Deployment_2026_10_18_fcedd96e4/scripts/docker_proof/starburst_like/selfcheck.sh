#!/bin/sh
# Is qs-trino-sb up and Starburst-shaped?  Asked of TRINO ITSELF, before any
# QueryStudio code is involved (2026-10-08).  Non-zero exit on any failure.
#
#     . ~/.qs_keys/starburst_like.env
#     sh scripts/docker_proof/starburst_like/selfcheck.sh
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
CA="$HERE/generated/ca.pem"
# Git Bash: the native curl.exe cannot open /c/... under MSYS_NO_PATHCONV=1
command -v cygpath >/dev/null 2>&1 && CA=$(cygpath -m "$CA")
# ...and its schannel curl demands a revocation answer a test CA (no CRL) cannot
# give; the CHAIN is what is checked here, so skip revocation there only.
REVOKE=""
curl -V 2>/dev/null | grep -qi schannel && REVOKE="--ssl-no-revoke"
HOSTPORT="${QS_SB_HOSTPORT:-8445}"
export MSYS_NO_PATHCONV=1
fail=0
ok()   { echo "  [PASS] $1"; }
bad()  { echo "  [FAIL] $1"; fail=1; }

[ -f "$CA" ] || { echo "no $CA -- run make_certs.sh first" >&2; exit 1; }
[ -n "${QS_SB_ANALYST_PW:-}" ] && [ -n "${QS_SB_RESTRICTED_PW:-}" ] || {
    echo "source ~/.qs_keys/starburst_like.env first" >&2; exit 1; }

echo "== qs-trino-sb: waiting for SERVER STARTED (up to 240 s)"
i=0
while [ $i -lt 48 ]; do
    if docker logs qs-trino-sb 2>&1 | grep -q "SERVER STARTED"; then break; fi
    i=$((i + 1)); sleep 5
done
docker logs qs-trino-sb 2>&1 | grep -q "SERVER STARTED" && ok "SERVER STARTED" || {
    bad "no SERVER STARTED in the log"; docker logs --tail 40 qs-trino-sb 2>&1; exit 1; }

echo "== TLS: the server certificate chains to the rig's CA"
if curl -sS $REVOKE --cacert "$CA" "https://localhost:$HOSTPORT/v1/info" | grep -q '"starting":false'; then
    ok "https://localhost:$HOSTPORT/v1/info verifies against generated/ca.pem"
else
    bad "/v1/info did not verify against the CA (or the server is still starting)"
fi
if curl -sS "https://localhost:$HOSTPORT/v1/info" >/dev/null 2>&1; then
    bad "the certificate was accepted WITHOUT the CA -- it is not self-issued?"
else
    ok "without the CA, curl refuses the certificate (untrusted issuer)"
fi

echo "== password login"
code=$(curl -s -o /dev/null -w '%{http_code}' $REVOKE --cacert "$CA" -u "qs_analyst:not-the-password" \
       -H 'X-Trino-User: qs_analyst' -d 'select 1' "https://localhost:$HOSTPORT/v1/statement")
[ "$code" = "401" ] && ok "a wrong password is 401" || bad "a wrong password answered $code (expected 401)"
code=$(curl -s -o /dev/null -w '%{http_code}' -H 'X-Trino-User: qs_analyst' -d 'select 1' \
       "http://localhost:$HOSTPORT/v1/statement" 2>/dev/null || echo "no-http")
ok "plain HTTP on the TLS port answers $code (the HTTP port 8080 is not published)"

truth() {   # user password sql
    docker exec -e "TRINO_PASSWORD=$2" qs-trino-sb trino --server https://localhost:8443 --insecure \
        --user "$1" --password --output-format TSV --execute "$3" 2>&1
}
echo "== access control, as Trino itself sees it"
a=$(truth qs_analyst "$QS_SB_ANALYST_PW" "SHOW TABLES FROM iceberg_aws.fin" | tr -d '\r' | sort | tr '\n' ' ')
r=$(truth qs_restricted "$QS_SB_RESTRICTED_PW" "SHOW TABLES FROM iceberg_aws.fin" | tr -d '\r' | sort | tr '\n' ' ')
echo "     analyst    sees: $a"
echo "     restricted sees: $r"
case "$a" in *dim_legal_entity*) ok "analyst sees dim_legal_entity";; *) bad "analyst does not see dim_legal_entity: $a";; esac
case "$r" in *dim_legal_entity*) bad "restricted SEES dim_legal_entity";; *) ok "restricted does not see dim_legal_entity";; esac
case "$r" in *fact_tetb*) ok "restricted sees fact_tetb";; *) bad "restricted does not see fact_tetb: $r";; esac
cols=$(truth qs_restricted "$QS_SB_RESTRICTED_PW" "DESCRIBE iceberg_aws.fin.fact_tetb" | cut -f1 | tr '\n' ' ')
case "$cols" in *gbp_currency_amount*) bad "restricted DESCRIBE shows gbp_currency_amount";; *) ok "restricted DESCRIBE hides gbp_currency_amount";; esac
denied=$(truth qs_restricted "$QS_SB_RESTRICTED_PW" "SELECT gbp_currency_amount FROM iceberg_aws.fin.fact_tetb LIMIT 1")
case "$denied" in *"Access Denied"*|*"does not exist"*|*"Column"*) ok "restricted SELECT of the hidden column is refused: $(echo "$denied" | head -1 | cut -c1-120)";; *) bad "hidden column SELECT was not refused: $(echo "$denied" | head -1)";; esac
galaxy=$(truth "analyst@example.com/accountadmin" "$QS_SB_ANALYST_PW" "SELECT current_user" | tr -d '\r')
[ "$galaxy" = "analyst@example.com/accountadmin" ] && ok "a Galaxy-format user name (email/role) logs in and is current_user" || bad "Galaxy-format user: $galaxy"

[ $fail -eq 0 ] && echo "selfcheck: OK" || echo "selfcheck: FAILED"
exit $fail
