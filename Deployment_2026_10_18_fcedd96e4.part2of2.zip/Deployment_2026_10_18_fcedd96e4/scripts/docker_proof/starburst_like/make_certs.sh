#!/bin/sh
# Generate everything qs-trino-sb needs that must NOT be committed
# (2026-10-08): a test CA + server certificate, the two users' passwords
# (bcrypt in password.db, plain in ~/.qs_keys/starburst_like.env for the
# harness), the internal shared secret, and the catalog files copied
# VERBATIM from the running qs-trino (same iceberg_aws / iceberg / tpch,
# same credentials -- so the Starburst-shaped Trino reads the SAME tables).
#
#     sh scripts/docker_proof/starburst_like/make_certs.sh            # once
#     sh scripts/docker_proof/starburst_like/make_certs.sh --force    # regenerate
#
# Writes (all gitignored):
#     scripts/docker_proof/starburst_like/generated/
#         ca.pem              the CA the backend/harness trusts (no key)
#         trino-sb.env        QS_SB_SHARED_SECRET (compose env_file)
#         secrets/            ca.key, server.pem (key+cert), password.db
#         catalog/            *.properties copied from qs-trino
#     ~/.qs_keys/starburst_like.env   QS_SB_ANALYST_PW / QS_SB_RESTRICTED_PW
#
# Reads the running qs-trino's catalog files (docker exec ... cat): read
# only, nothing on the rig is started, stopped or changed.
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
GEN="$HERE/generated"
SEC="$GEN/secrets"
CAT="$GEN/catalog"
KEYS="${QS_KEYS_DIR:-$HOME/.qs_keys}"
ENVF="$KEYS/starburst_like.env"
export MSYS_NO_PATHCONV=1      # Git Bash would rewrite "/CN=..." into a Windows path
# ...which also stops it translating /c/... for the NATIVE openssl.exe, so on
# Git Bash hand every path over in mixed form (C:/...), valid for both.
if command -v cygpath >/dev/null 2>&1; then
    GEN=$(cygpath -m "$GEN"); SEC=$(cygpath -m "$SEC"); CAT=$(cygpath -m "$CAT")
    KEYS=$(cygpath -m "$KEYS"); ENVF=$(cygpath -m "$ENVF")
fi

if [ -f "$ENVF" ] && [ -f "$SEC/server.pem" ] && [ "${1:-}" != "--force" ]; then
    echo "already generated: $ENVF and $SEC/server.pem exist (use --force to regenerate)"
    exit 0
fi
command -v openssl >/dev/null || { echo "openssl is required" >&2; exit 1; }
PY=$(command -v python3 || command -v python)
[ -n "$PY" ] || { echo "python is required (bcrypt for password.db)" >&2; exit 1; }
docker inspect qs-trino >/dev/null 2>&1 || { echo "qs-trino is not running: the catalogs are copied from it" >&2; exit 1; }

mkdir -p "$SEC" "$CAT" "$KEYS"
umask 077

# ── 1. a CA and a server certificate for qs-trino-sb ────────────────────────
openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
    -keyout "$SEC/ca.key" -out "$SEC/ca.pem" \
    -subj "/CN=QueryStudio Starburst-like test CA" \
    -addext "basicConstraints=critical,CA:TRUE" \
    -addext "keyUsage=critical,keyCertSign,cRLSign" >/dev/null 2>&1
openssl req -newkey rsa:2048 -nodes -keyout "$SEC/server.key" -out "$SEC/server.csr" \
    -subj "/CN=qs-trino-sb" >/dev/null 2>&1
printf 'subjectAltName=DNS:qs-trino-sb,DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\nbasicConstraints=CA:FALSE\n' > "$SEC/server.ext"
openssl x509 -req -days 825 -in "$SEC/server.csr" -CA "$SEC/ca.pem" -CAkey "$SEC/ca.key" \
    -CAcreateserial -out "$SEC/server.crt" -extfile "$SEC/server.ext" >/dev/null 2>&1
# Trino's PEM keystore: private key + certificate in ONE file, no password.
cat "$SEC/server.key" "$SEC/server.crt" > "$SEC/server.pem"
cp "$SEC/ca.pem" "$GEN/ca.pem"
rm -f "$SEC/server.csr" "$SEC/server.ext"
# Trino runs as uid 1000 inside the container: the mounted files must be
# readable by it.  They live in a gitignored directory on a dev box.
chmod 644 "$SEC/server.pem" "$SEC/ca.pem" "$GEN/ca.pem"

# ── 2. users, passwords, bcrypt password.db ─────────────────────────────────
"$PY" - "$SEC/password.db" "$ENVF" "$GEN/trino-sb.env" <<'EOF'
import secrets, sys
import bcrypt
db, envf, cenv = sys.argv[1:4]
pw = {"qs_analyst": secrets.token_urlsafe(18), "qs_restricted": secrets.token_urlsafe(18)}
# the Galaxy-FORMAT user (email/role) shares the analyst's password
users = {"qs_analyst": pw["qs_analyst"], "qs_restricted": pw["qs_restricted"],
         "analyst@example.com/accountadmin": pw["qs_analyst"]}
with open(db, "w", encoding="utf-8", newline="\n") as fh:
    for user, plain in users.items():
        # Trino's file authenticator documents the $2y$ bcrypt prefix (cost >= 8).
        h = bcrypt.hashpw(plain.encode(), bcrypt.gensalt(10)).decode()
        fh.write(f"{user}:{h.replace('$2b$', '$2y$', 1)}\n")
with open(envf, "w", encoding="utf-8", newline="\n") as fh:
    fh.write(f"export QS_SB_ANALYST_PW='{pw['qs_analyst']}'\n")
    fh.write(f"export QS_SB_RESTRICTED_PW='{pw['qs_restricted']}'\n")
with open(cenv, "w", encoding="utf-8", newline="\n") as fh:
    fh.write(f"QS_SB_SHARED_SECRET={secrets.token_hex(32)}\n")
print(f"password.db: {len(users)} users")
EOF
chmod 644 "$SEC/password.db"

# ── 3. the catalogs, verbatim from the running qs-trino ─────────────────────
n=0
for f in $(docker exec qs-trino ls /etc/trino/catalog); do
    docker exec qs-trino cat "/etc/trino/catalog/$f" | tr -d '\r' > "$CAT/$f"
    chmod 644 "$CAT/$f"
    n=$((n + 1))
done
[ "$n" -gt 0 ] || { echo "no catalog files copied from qs-trino" >&2; exit 1; }
grep -q '^connector.name=iceberg' "$CAT/iceberg_aws.properties" || {
    echo "qs-trino has no iceberg_aws catalog -- the proof reads iceberg_aws.fin.*" >&2; exit 1; }

# ── 3b. a HIVE catalog qs-trino lacks (2026-10-11) ──────────────────────────
# The owner's on-prem may be Hive-based: tetb_real_e2e_proof.py --onprem hive
# reads hive.qs_<tag>.* on this cluster.  Generated beside the copied catalogs
# from the same MinIO credentials (make_hive_catalog.sh is also runnable alone).
sh "$HERE/make_hive_catalog.sh"

echo "generated:"
echo "  CA           $GEN/ca.pem"
echo "  server cert  $SEC/server.pem  (CN=qs-trino-sb, SAN qs-trino-sb/localhost/127.0.0.1)"
echo "  passwords    $ENVF  (source it:  . $ENVF)"
echo "  catalogs     $CAT  ($n files copied from qs-trino)"
echo "next:  docker compose -f docker-compose.local.yml -f scripts/docker_proof/compose/starburst_like.override.yml up -d qs-trino-sb"
echo "       sh scripts/docker_proof/starburst_like/selfcheck.sh"
