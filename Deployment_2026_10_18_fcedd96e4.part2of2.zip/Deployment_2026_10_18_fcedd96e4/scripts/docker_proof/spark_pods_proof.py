"""Does a LARGE feed open new pods?  Every routing case and every failure path,
observed ON THE CLUSTER (2026-10-07).

Owner: "demo how a large feed creates new pods ... think it as an enterprise
product ... think all cases".  A watcher thread lists the `spark` namespace
(pods, Secrets, SparkApplications) every 1.5 s through the kind node's own
kubectl, so every claim below is something the CLUSTER saw, not something
QueryStudio said about itself.  Data written by Spark is judged against the
Trino CLI's own answer.  A WebSocket recorder (ws_recorder.mjs) captures what a
signed-in browser would have been told.

  S1  small feed, auto       -> native, NO pod, reason recorded
  S2  large feed, auto       -> driver pod CREATED by QueryStudio, executors
                                created by the driver, data == source, the
                                credential travels in a Secret (never inline),
                                Secret and pods cleaned up afterwards
  S3  small feed PINNED      -> a pod anyway
  S4  per-run override       -> a pod for THAT run only; the next run native
  S5  global native_only     -> a large feed stays native, reason says why
  S6  Iceberg source, large  -> a pod through the read plan; rows == the table (2026-10-14 lift)
  S7  two large feeds at once-> two independent drivers, both correct
  S8  driver killed mid-run  -> a terminal state with a reason, never a hang
  S9  user cancels           -> the pods are deleted
  S10 backfill deliver=false -> the job runs, the destination gets NOTHING
  S12 cluster down           -> no hang: refused or native, with a reason

    . ~/.qs_keys/rigpw.sh; python scripts/docker_proof/spark_pods_proof.py [--only S1,S2]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fb59_acceptance as fb  # noqa: E402  (call, check, section, await_sql, make_feed, LEDGER, oracle_admin)

KIND = "qs-spark-control-plane"
NS = "spark"
TAG = fb.TAG
ASIA = fb.TRADES                                   # 301,740 rows of iceberg.qs.trades
SMALL = fb.TRADES + " AND id <= 2000"
HERE = os.path.dirname(os.path.abspath(__file__))


# ── the cluster's own view ───────────────────────────────────────────────────
class ClusterWatch:
    def __init__(self):
        self.seen = {}           # (kind, name) -> {first, last, phases[], labels, owners, spec}
        self.stop = threading.Event()
        self.t = threading.Thread(target=self._loop, daemon=True)

    def _list(self):
        out = subprocess.run(["docker", "exec", KIND, "kubectl", "--kubeconfig", "/etc/kubernetes/admin.conf",
                              "get", "pods,secrets,sparkapplications", "-n", NS, "-o", "json"],
                             capture_output=True, text=True, timeout=30)
        try:
            return json.loads(out.stdout).get("items", [])
        except ValueError:
            return []

    def _loop(self):
        while not self.stop.is_set():
            now = time.time()
            try:
                for it in self._list():
                    kind, md = it.get("kind"), it.get("metadata", {})
                    if kind == "Secret" and md.get("name", "").startswith("default-token"):
                        continue
                    key = (kind, md.get("name"))
                    rec = self.seen.setdefault(key, {"first": now, "phases": [], "labels": md.get("labels") or {},
                                                     "owners": [o.get("name") for o in md.get("ownerReferences") or []],
                                                     "spec": it.get("spec") if kind == "Pod" else None})
                    rec["last"] = now
                    ph = (it.get("status") or {}).get("phase") if kind == "Pod" else None
                    if ph and (not rec["phases"] or rec["phases"][-1] != ph):
                        rec["phases"].append(ph)
            except Exception:                                   # noqa: BLE001
                pass
            self.stop.wait(1.5)

    def start(self):
        self.t.start()
        return self

    def matching(self, kind, needle, since=0.0):
        return {n: r for (k, n), r in self.seen.items() if k == kind and needle in (n or "") and r["first"] >= since - 2}

    def present_now(self, kind, needle):
        return [it.get("metadata", {}).get("name") for it in self._list()
                if it.get("kind") == kind and needle in it.get("metadata", {}).get("name", "")]


def kname(feed_name):
    return feed_name.lower().replace("_", "-")


def _money(v):
    from decimal import Decimal
    return str(Decimal(str(v)).quantize(Decimal("0.01")))


def trino_truth(sql):
    q = f"select count(*), cast(round(sum(amt), 2) as decimal(38, 2)) from ({sql})"
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute", q],
                         capture_output=True, text=True).stdout.strip().split("\t")
    return int(out[0]), _money(out[1])


def oracle_truth(table):
    _, b = fb.call("POST", "/api/sql/execute", {"primary_connection_id": fb.ORACLE, "row_limit": 5,
                   "primary_sql": f"SELECT COUNT(*) N, TO_CHAR(ROUND(SUM(AMT),2),'FM99999999999990.00') S FROM OTG.{table}"})
    rows, err = fb.await_sql(b)
    if err or not rows:
        return None, err
    r = {str(k).lower(): v for k, v in rows[0].items()}
    # an EMPTY table sums to NULL -- what S8 asserts after a failed run (all or nothing)
    return (int(r["n"]), _money(r["s"]) if r["s"] is not None else None), None


def feed(case, sql, backend="auto", est=None, name=None):
    name = name or f"SPX_{case}_{TAG}"
    table = f"QS_SPX_{case}_{TAG}"
    fb.oracle_admin([f"DROP TABLE OTG.{table} PURGE"])
    body = dict(name=name, source_type="raw_sql", connection_id=fb.TRINO_POD, output_format="parquet",
                destination_type="oracle", destination_config={"connection_id": fb.ORACLE, "table": f"OTG.{table}", "mode": "append"},
                query_params={"sql": sql}, execution_backend=backend)
    if est:
        body["estimated_row_count"] = est
    return fb.make_feed(**body), name, table


def start(fid, backend=None):
    q = f"?backend={backend}" if backend else ""
    s, b = fb.call("POST", f"/api/feeds/{fid}/execute{q}", {"trigger_type": "manual"})
    return (b or {}).get("execution_db_id") if s == 200 else None, (s, b)


def wait_exec(dbid, timeout=1500):
    t0, e = time.time(), {}
    while time.time() - t0 < timeout:
        _, e = fb.call("GET", f"/api/feed-executions/{dbid}")
        if isinstance(e, dict) and e.get("status") in ("completed", "failed", "cancelled", "error"):
            break
        time.sleep(2)
    t1 = time.time()
    while time.time() - t1 < 60:                              # backend_choice settles after the status
        _, e2 = fb.call("GET", f"/api/feed-executions/{dbid}")
        if isinstance(e2, dict) and (e2.get("files_metadata") or {}).get("backend_choice"):
            return e2, round(time.time() - t0)
        time.sleep(1)
    return e, round(time.time() - t0)


def reason(e):
    return str(((e.get("files_metadata") or {}).get("backend_choice") or {}).get("reason"))


def wait_for(fn, timeout, every=1.5):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(every)
    return None


def secret_inline(spec):
    """Credential-looking env vars carried as LITERAL values in the pod spec."""
    bad = []
    for c in (spec or {}).get("containers", []) + (spec or {}).get("initContainers", []):
        for env in c.get("env") or []:
            n = str(env.get("name", "")).upper()
            if any(w in n for w in ("PASSWORD", "SECRET", "TOKEN", "PRIVATE_KEY")) and "value" in env and env.get("value"):
                bad.append(n)
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    only = set(filter(None, ap.parse_args().only.split(",")))
    want = lambda c: not only or c in only              # noqa: E731
    W = ClusterWatch().start()
    stopfile = tempfile.mktemp(prefix="wsstop_")
    wsout = os.path.join(tempfile.gettempdir(), f"spx_ws_{TAG}.jsonl")
    import qs_docker_client as qc
    rec = subprocess.Popen(["node", os.path.join(HERE, "ws_recorder.mjs"), wsout, stopfile],
                           env=dict(os.environ, QS_WS_TOKEN=qc._admin_token() or "", QS_WS_USER="rig_admin"))
    asia_truth = trino_truth(ASIA)
    small_truth = trino_truth(SMALL)
    fb.check("truth from Trino: ASIA trades and the small slice", asia_truth[0] > 100_000 and 0 < small_truth[0] < 5000,
             {"asia": asia_truth, "small": small_truth})
    timeline = []
    try:
        if want("S1"):
            fb.section("S1 small feed, auto -> native, no pod")
            fid, name, table = feed("S1", SMALL, est=2000)
            t0 = time.time()
            dbid, _ = start(fid)
            e, secs = wait_exec(dbid)
            pods = W.matching("Pod", kname(name), t0)
            fb.check("S1 ran NATIVE and the router says why", e.get("execution_backend") == "native", reason(e))
            fb.check("S1 the cluster saw NO pod for it", not pods, list(pods))
            fb.check("S1 the run completed", e.get("status") == "completed", str(e.get("error_message"))[:300])
            got, err = oracle_truth(table)
            fb.check(f"S1 data == source ({secs}s)", got == small_truth, (got, small_truth, err))

        if want("S2"):
            fb.section("S2 LARGE feed, auto -> QueryStudio creates the driver pod, the driver creates executors")
            fid, name, table = feed("S2", ASIA, est=5_000_000)
            t0 = time.time()
            dbid, _ = start(fid)
            drv = wait_for(lambda: [n for n, r in W.matching("Pod", kname(name), t0).items() if n.endswith("-driver")], 300)
            secret_seen = wait_for(lambda: W.matching("Secret", kname(name), t0) or None, 120)
            spec = (W.seen.get(("Pod", drv[0])) or {}).get("spec") if drv else None
            e, secs = wait_exec(dbid)
            pods = W.matching("Pod", kname(name), t0)
            execs = {n: r for n, r in pods.items() if (r["labels"].get("spark-role") == "executor") or "-exec-" in n}
            timeline.append(("S2", {n: (round(r["first"] - t0), round(r.get("last", r["first"]) - t0), r["phases"]) for n, r in pods.items()}))
            fb.check("S2 routed to spark_k8s BY SIZE (reason names the size tier)",
                     e.get("execution_backend") == "spark_k8s" and "auto_route_large" in reason(e), reason(e))
            fb.check("S2 the cluster saw the DRIVER pod QueryStudio created", bool(drv), sorted(pods))
            fb.check("S2 the cluster saw EXECUTOR pods, owned by the driver (Spark created them, not QueryStudio)",
                     bool(execs) and all(any(o.endswith("-driver") for o in r["owners"]) for r in execs.values()),
                     {n: r["owners"] for n, r in execs.items()})
            # the job's LAST act is the completion webhook, sent before spark.stop():
            # the row reads completed while the driver is still exiting -- wait for it
            if drv:
                wait_for(lambda: "Succeeded" in W.seen[("Pod", drv[0])]["phases"], 180, 2)
            fb.check("S2 the driver went Running -> Succeeded", drv and "Succeeded" in W.seen[("Pod", drv[0])]["phases"],
                     drv and W.seen[("Pod", drv[0])]["phases"])
            fb.check("S2 the credential travelled in a Kubernetes SECRET for the run", bool(secret_seen), list(secret_seen or []))
            fb.check("S2 no credential is inline in the pod spec (env uses secretKeyRef)", spec is not None and not secret_inline(spec),
                     secret_inline(spec) if spec else "no spec captured")
            got, err = oracle_truth(table)
            fb.check(f"S2 the data Spark wrote == the source ({secs}s end to end)", e.get("status") == "completed" and got == asia_truth,
                     (e.get("status"), got, asia_truth, err))
            # 2026-10-07 (D1): a terminal run's credential Secret is released AT ONCE;
            # its driver pod is KEPT for spark_k8s.completed_cr_ttl_seconds (3600 s)
            # so the driver log survives (reconciler._release_terminal_credentials).
            # This check predated D1 and expected both gone within 300 s.
            gone = wait_for(lambda: not W.present_now("Secret", kname(name)), 120, 5)
            kept = [p for p in W.present_now("Pod", kname(name)) if p.endswith("-driver")]
            fb.check("S2 afterwards: the run's Secret is gone at once; its finished driver is kept for the log",
                     bool(gone) and (not kept or "Succeeded" in W.seen[("Pod", kept[0])]["phases"]),
                     {"secrets": W.present_now("Secret", kname(name)), "driver_kept": kept})
            _, st = fb.call("GET", f"/api/feed-executions/{dbid}/steps")
            sp = ((st or {}).get("execution") or {}).get("spark") or {}
            fb.check("S2 the run screen says where it ran (driver pod named)", bool(sp.get("driver_pod")), str(sp)[:200])

        if want("S3"):
            fb.section("S3 small feed PINNED to Spark -> a pod anyway")
            fid, name, table = feed("S3", SMALL, backend="spark_k8s")
            t0 = time.time()
            dbid, _ = start(fid)
            e, secs = wait_exec(dbid)
            pods = W.matching("Pod", kname(name), t0)
            fb.check("S3 pinned -> spark_k8s, reason names the pin", e.get("execution_backend") == "spark_k8s" and "per_feed" in reason(e), reason(e))
            fb.check("S3 the cluster saw a driver pod", any(n.endswith("-driver") for n in pods), sorted(pods))
            got, err = oracle_truth(table)
            fb.check(f"S3 data == source ({secs}s)", got == small_truth, (got, small_truth, err))

        if want("S4"):
            fb.section("S4 a NATIVE feed run once on Spark (?backend=spark_k8s), then normally")
            fid, name, table = feed("S4", SMALL, backend="native")
            t0 = time.time()
            dbid, resp = start(fid, backend="spark_k8s")
            if dbid:
                e, _ = wait_exec(dbid)
                pods = W.matching("Pod", kname(name), t0)
                fb.check("S4 that run went to spark_k8s and the reason names the override",
                         e.get("execution_backend") == "spark_k8s" and "override" in reason(e).lower(), reason(e))
                fb.check("S4 the cluster saw a pod for it", any(n.endswith("-driver") for n in pods), sorted(pods))
                t1 = time.time()
                dbid2, _ = start(fid)
                e2, _ = wait_exec(dbid2)
                fb.check("S4 the NEXT run (no override) is native, no new pod",
                         e2.get("execution_backend") == "native" and not W.matching("Pod", kname(name), t1), reason(e2))
            else:
                fb.check("S4 the per-run override is accepted", False, str(resp)[:200])

        if want("S5"):
            fb.section("S5 admin global switch native_only -> a LARGE feed stays native")
            _, cur = fb.call("GET", "/api/admin/feed-generation/backend-override")
            before = (cur or {}).get("value") or "auto"
            s, _ = fb.call("POST", "/api/admin/feed-generation/backend-override", {"value": "native_only", "reason": "spark pods proof S5"})
            try:
                fid, name, table = feed("S5", ASIA, est=5_000_000)
                t0 = time.time()
                dbid, _ = start(fid)
                e, secs = wait_exec(dbid)
                fb.check("S5 native, and the reason names the global override",
                         e.get("execution_backend") == "native" and "override" in reason(e).lower(), reason(e))
                fb.check("S5 the cluster saw NO pod", not W.matching("Pod", kname(name), t0), sorted(W.matching("Pod", kname(name), t0)))
                got, err = oracle_truth(table)
                fb.check(f"S5 data == source on the native lane ({secs}s)", got == asia_truth, (got, asia_truth, err))
            finally:
                fb.call("POST", "/api/admin/feed-generation/backend-override", {"value": before, "reason": "restore after S5"})

        if want("S6"):
            fb.section("S6 an ICEBERG source on S3, large -> a Spark pod through the read plan (deletes honoured)")
            _, cl = fb.call("GET", "/api/connections")
            items = cl if isinstance(cl, list) else (cl or {}).get("items") or (cl or {}).get("connections") or []
            s3 = next((x["id"] for x in items if x.get("name") == "aws-real"), None)
            table = f"QS_SPX_S6_{TAG}"
            fb.oracle_admin([f"DROP TABLE OTG.{table} PURGE"])
            fid = fb.make_feed(name=f"SPX_S6_{TAG}", source_type="raw_sql", connection_id=s3, output_format="parquet",
                               destination_type="oracle", destination_config={"connection_id": fb.ORACLE, "table": f"OTG.{table}", "mode": "append"},
                               query_params={"sql": "select sap_company_id, region from dim_legal_entity"},
                               execution_backend="auto", estimated_row_count=5_000_000)
            t0 = time.time()
            dbid, _ = start(fid)
            e, secs = wait_exec(dbid)
            # 2026-10-16: the Iceberg floor this case asserted was LIFTED on 2026-10-14 --
            # the Spark lanes read an Iceberg table through the read plan (the
            # planner's pinned snapshot + metadata file, read by Iceberg's own
            # reader, deletes honoured; source_plan.BACKEND_CAPABILITIES
            # iceberg_source=True, the MoR tripwire 17,850 rows exact).  What
            # is true now: a LARGE Iceberg feed goes to a pod and the rows it
            # writes == the table's own count (Trino on the same snapshot).
            truth_rows = int(subprocess.run(
                ["docker", "exec", "qs-trino", "trino", "--output-format", "TSV", "--execute",
                 "select count(*) from iceberg_aws.fin.dim_legal_entity"],
                capture_output=True, text=True).stdout.strip() or 0)
            fb.check("S6 an Iceberg source on S3, large -> a Spark pod (the read plan, not the old floor)",
                     e.get("execution_backend") == "spark_k8s" and e.get("status") == "completed",
                     (e.get("execution_backend"), e.get("status"), reason(e), str(e.get("error_message"))[:200]))
            fb.check("S6 the cluster saw its pod", bool(W.matching("Pod", f"spx-s6-{TAG}", t0)), [])
            _, b6 = fb.call("POST", "/api/sql/execute", {"primary_connection_id": fb.ORACLE, "row_limit": 5,
                            "primary_sql": f"SELECT COUNT(*) N FROM OTG.{table}"})
            rows6, err6 = fb.await_sql(b6)
            got6 = int({str(k).lower(): v for k, v in rows6[0].items()}["n"]) if rows6 and not err6 else None
            fb.check("S6 the rows the pod wrote == the Iceberg table's own count (non-zero)",
                     truth_rows > 0 and got6 == truth_rows, {"truth": truth_rows, "written": got6, "err": err6})

        if want("S7"):
            fb.section("S7 two LARGE feeds at once -> two independent drivers")
            a = feed("S7A", ASIA, est=5_000_000)
            b_ = feed("S7B", ASIA, est=5_000_000)
            t0 = time.time()
            ida, _ = start(a[0])
            idb, _ = start(b_[0])
            ea, sa = wait_exec(ida)
            eb, sb = wait_exec(idb)
            da = W.matching("Pod", kname(a[1]), t0)
            db_ = W.matching("Pod", kname(b_[1]), t0)
            dra = [r for n, r in da.items() if n.endswith("-driver")]
            drb = [r for n, r in db_.items() if n.endswith("-driver")]
            overlap = dra and drb and dra[0]["first"] < drb[0].get("last", 0) and drb[0]["first"] < dra[0].get("last", 0)
            fb.check("S7 each run had ITS OWN driver pod", bool(dra) and bool(drb), (sorted(da), sorted(db_)))
            fb.check("S7 the two drivers were alive AT THE SAME TIME", bool(overlap), "")
            ga, _ = oracle_truth(a[2])
            gb, _ = oracle_truth(b_[2])
            fb.check(f"S7 both destinations == source ({sa}s / {sb}s)", ga == asia_truth and gb == asia_truth, (ga, gb, asia_truth))

        if want("S8"):
            fb.section("S8 the driver pod is KILLED mid-run -> a terminal state with a reason, never a hang")
            fid, name, table = feed("S8", ASIA, est=5_000_000)
            t0 = time.time()
            dbid, _ = start(fid)
            drv = wait_for(lambda: [n for n, r in W.matching("Pod", kname(name), t0).items()
                                    if n.endswith("-driver") and "Running" in r["phases"]], 300)
            # kill DURING the write: once executors are running, plus a few seconds
            wait_for(lambda: [n for n, r in W.matching("Pod", kname(name), t0).items()
                              if "-exec-" in n and "Running" in r["phases"]], 120)
            time.sleep(float(os.environ.get("QS_S8_KILL_AFTER", "8")))
            if drv:
                subprocess.run(["docker", "exec", KIND, "kubectl", "--kubeconfig", "/etc/kubernetes/admin.conf",
                                "delete", "pod", drv[0], "-n", NS, "--wait=false"], capture_output=True)
            e, secs = wait_exec(dbid, timeout=1500)
            retry = [n for n in W.matching("Pod", kname(name), t0) if "-r1-driver" in n]
            fb.check("S8 the driver was running when it was killed", bool(drv), drv)
            fb.check(f"S8 the run reached a TERMINAL state ({secs}s) -- retried or failed, never stuck",
                     e.get("status") in ("completed", "failed", "cancelled"),
                     {"status": e.get("status"), "retry_pod": retry, "err": str(e.get("error_message"))[:200]})
            if e.get("status") == "completed":
                got, _ = oracle_truth(table)
                fb.check("S8 the retry's data == source, no duplicates", got == asia_truth, (got, asia_truth))
            else:
                fb.check("S8 the failure SAYS why", bool(e.get("error_message")), str(e.get("error_message"))[:200])
                got, err = oracle_truth(table)
                fb.check("S8 a FAILED run left NO partial rows in the destination (all or nothing)",
                         got is None or got[0] in (0, asia_truth[0]), {"rows_left": got, "truth": asia_truth, "err": err})

        if want("S9"):
            fb.section("S9 the user CANCELS a running Spark feed -> the pods are deleted")
            fid, name, table = feed("S9", ASIA, est=5_000_000)
            t0 = time.time()
            dbid, _ = start(fid)
            drv = wait_for(lambda: [n for n, r in W.matching("Pod", kname(name), t0).items()
                                    if n.endswith("-driver") and "Running" in r["phases"]], 300)
            s, cb = fb.call("POST", f"/api/feed-executions/{dbid}/cancel", {})
            e, secs = wait_exec(dbid, timeout=300)
            gone = wait_for(lambda: not W.present_now("Pod", kname(name)), 180, 3)
            fb.check("S9 cancel accepted and the run reads cancelled", s == 200 and e.get("status") == "cancelled",
                     (s, e.get("status"), str(cb)[:150]))
            fb.check("S9 the driver and executors are GONE from the cluster", bool(drv) and bool(gone),
                     {"driver_seen": drv, "left": W.present_now("Pod", kname(name))})

        if want("S10"):
            fb.section("S10 a Spark backfill with deliver=false -> the job runs, the destination gets NOTHING")
            fid, name, table = feed("S10", SMALL, backend="spark_k8s")
            t0 = time.time()
            s, bf = fb.call("POST", f"/api/feeds/{fid}/backfill", {"start_date": "2026-10-06", "end_date": "2026-10-06", "deliver": False})

            def done():
                _, ex = fb.call("GET", f"/api/feeds/{fid}/executions")
                items = ex if isinstance(ex, list) else (ex or {}).get("items") or (ex or {}).get("executions") or []
                return items if items and items[0].get("status") in ("completed", "failed", "cancelled") else None
            ex = wait_for(done, 900, 5)
            e = (ex or [{}])[0]
            got, err = oracle_truth(table)
            fb.check("S10 the queue worker ran it on Spark (a pod)", any(n.endswith("-driver") for n in W.matching("Pod", kname(name), t0)),
                     sorted(W.matching("Pod", kname(name), t0)))
            fb.check("S10 the run finished and is recorded as NOT delivered",
                     e.get("status") == "completed" and (e.get("delivery_suppressed") or "suppress" in json.dumps(e).lower()),
                     {k: e.get(k) for k in ("status", "delivery_suppressed", "delivery_verdict", "destination_path")})
            fb.check("S10 the destination table received NOTHING", got is None or got[0] == 0, (got, err))

        if want("S12"):
            fb.section("S12 the Spark cluster is DOWN -> no hang: refused or native, with a reason")
            subprocess.run(["docker", "stop", KIND], capture_output=True)
            try:
                fid, name, table = feed("S12", SMALL, est=5_000_000)
                t0 = time.time()
                dbid, resp = start(fid)
                e, secs = wait_exec(dbid, timeout=600) if dbid else ({}, 0)
                fb.check(f"S12 the run ENDS within 10 min with a reason ({secs}s) -- native fallback or an explicit refusal",
                         e.get("status") in ("completed", "failed") and (reason(e) not in ("", "None") or e.get("error_message")),
                         {"status": e.get("status"), "backend": e.get("execution_backend"), "reason": reason(e),
                          "err": str(e.get("error_message"))[:200], "resp": str(resp)[:120]})
            finally:
                subprocess.run(["docker", "start", KIND], capture_output=True)
                subprocess.run(["bash", os.path.join(HERE, "..", "spark_kind_attach_docker.sh")], capture_output=True)
                ok = wait_for(lambda: "Ready" in subprocess.run(["docker", "exec", KIND, "kubectl", "--kubeconfig",
                              "/etc/kubernetes/admin.conf", "get", "nodes"], capture_output=True, text=True).stdout, 240, 5)
                fb.check("S12 the cluster is back and Ready afterwards", bool(ok), "")
    finally:
        open(stopfile, "w").close()
        try:
            rec.wait(timeout=20)
        except Exception:                                     # noqa: BLE001
            rec.kill()
        W.stop.set()
        fb.section("WEBSOCKET -- what a signed-in browser was told during the run")
        evs = []
        try:
            evs = [json.loads(l) for l in open(wsout, encoding="utf-8") if l.strip()]
        except OSError:
            pass
        kinds = {}
        for ev in evs:
            t = str(ev["msg"].get("type") or ev["msg"].get("event"))
            kinds[t] = kinds.get(t, 0) + 1
        print("  event types:", json.dumps(kinds, sort_keys=True))
        feedish = [k for k in kinds if "feed" in k.lower() or "execution" in k.lower() or "spark" in k.lower()]
        fb.check("WS the browser socket received live feed / execution events during the runs", bool(feedish), feedish)
        for case, tl in timeline:
            print(f"  {case} pod timeline (seconds from Execute: first seen, last seen, phases):")
            for n, v in sorted(tl.items(), key=lambda x: x[1][0]):
                print(f"     {n}: {v}")
        fb.section("CLEANUP")
        fb.LEDGER.cleanup(echo=lambda s: print("  " + s))
    bad = [n for n, ok, _ in fb.RESULTS if not ok]
    print(f"\n{len(fb.RESULTS) - len(bad)}/{len(fb.RESULTS)} PASSED")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
