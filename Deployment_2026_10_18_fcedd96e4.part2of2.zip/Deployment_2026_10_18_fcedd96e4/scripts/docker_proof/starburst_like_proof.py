"""STARBURST-SHAPED Trino (qs-trino-sb) through every QueryStudio surface, on
Docker (2026-10-08, login ON).  The owner's production source is Starburst
(Galaxy / Enterprise): HTTPS on a real CA, password login, ROLE-based access
control that HIDES tables and columns.  The rig's qs-trino has none of that,
so this runs against ``qs-trino-sb`` (scripts/docker_proof/starburst_like/):
the SAME catalogs, behind TLS + password + file-based access control.

Truth: Trino's OWN CLI inside qs-trino-sb, logged in as the SAME user --
``SHOW TABLES`` / ``DESCRIBE`` / counts as qs_restricted are what the rig
may show that user.  Every check asserts a value, a named refusal, or a
sentence; a measured-nothing is a FAIL (a hidden thing must be SEEN by the
analyst for its absence from the restricted view to mean anything).

  T1  connection over HTTPS with the rig CA pasted (ca_cert_pem): test = version
  T2  the Galaxy-FORMAT user name (email/role) logs in intact
  T3  a wrong password: a plain sentence (401), and a 400 on browse -- never a 503
  T4  the CA NOT given: "not trusted" + the remedy; a 400 on browse, no Retry-After
  T5  verify_ssl=false still connects (an opt-out, said out loud in the log)
  T6  a configured role REACHES the cluster: Trino's own verdict, in plain words
  T7  catalog / schema / table browse as each user == Trino's own listing as that user
  T8  columns as the restricted user hide the hidden column (CQB browser + BQB
      browser + dataset auto-detect); the analyst sees it
  T9  a query on a visible table == truth, as each user; a hidden column / table
      -> a clear refusal (no stack trace)
  T10 dataset -> report -> published API, as the restricted user: rows == truth
  T11 feed (native lane) as the restricted user: file rows == truth
  T12 cross-source: restricted primary UNION analyst secondary (two logins, one query)
  S1  (QS_SB_SPARK=1) the same feed on the spark_k8s lane -- needs the kind cluster
      and a job image carrying the Trino JDBC jar; reported SKIPPED otherwise

    sh scripts/docker_proof/starburst_like/make_certs.sh
    docker compose -f docker-compose.local.yml -f scripts/docker_proof/compose/starburst_like.override.yml up -d qs-trino-sb
    . ~/.qs_keys/rigpw.sh && . ~/.qs_keys/starburst_like.env
    sh scripts/docker_proof/starburst_like/selfcheck.sh
    python scripts/docker_proof/starburst_like_proof.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from auth_rls_proof import Session  # noqa: E402
from cross_source_proof import check, low, poll, res, results, rows  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
CA_PATH = os.path.join(HERE, "starburst_like", "generated", "ca.pem")
SB_HOST = os.environ.get("QS_SB_HOST", "qs-trino-sb")      # as the API container sees it
SB_PORT = int(os.environ.get("QS_SB_PORT", "8443"))
COB = os.environ.get("QS_XS_COB", "2025-09-30")
PUB = os.environ.get("QS_PUB_BASE", "http://localhost:8003")
TAG = str(int(time.time()))[-6:]
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")
CAT, SCH = "iceberg_aws", "fin"
VISIBLE = "fact_tetb"
HIDDEN_TABLE = "dim_legal_entity"
HIDDEN_COL = "gbp_currency_amount"
ROLE_TABLE = "fact_journal"
GALAXY_USER = "analyst@example.com/accountadmin"
SPARK = os.environ.get("QS_SB_SPARK") == "1"

USERS = {"qs_analyst": os.environ.get("QS_SB_ANALYST_PW"), "qs_restricted": os.environ.get("QS_SB_RESTRICTED_PW")}


def truth(user, sql):
    """Trino's own answer, as ``user``, through its CLI inside qs-trino-sb --
    no QueryStudio code on the path.  Raises on a CLI failure so a truth that
    could not be measured never reads as an empty truth."""
    pw = USERS["qs_analyst"] if user == GALAXY_USER else USERS[user]
    out = subprocess.run(["docker", "exec", "-e", f"TRINO_PASSWORD={pw}", "qs-trino-sb", "trino",
                          "--server", "https://localhost:8443", "--insecure", "--user", user, "--password",
                          "--output-format", "TSV", "--execute", sql],
                         capture_output=True, text=True, env=DENV, timeout=600)
    if out.returncode != 0:
        raise SystemExit(f"truth as {user} failed: {sql!r}: {(out.stderr or out.stdout)[-400:]}")
    return [line.split("\t") for line in out.stdout.replace("\r", "").strip().splitlines() if line.strip()]


def truth_error(user, sql):
    """The CLI's error text for a statement Trino refuses as ``user``."""
    pw = USERS[user]
    out = subprocess.run(["docker", "exec", "-e", f"TRINO_PASSWORD={pw}", "qs-trino-sb", "trino",
                          "--server", "https://localhost:8443", "--insecure", "--user", user, "--password",
                          "--execute", sql], capture_output=True, text=True, env=DENV, timeout=300)
    return (out.stderr + out.stdout).strip()


def has_retry_after(headers):
    """uvicorn emits header names in lower case; a case-sensitive lookup
    would have called every answer 'no Retry-After'."""
    return any(str(k).lower() == "retry-after" for k in (headers or {}))


def sb_config(user, password, **over):
    cfg = {"host": SB_HOST, "port": SB_PORT, "user": user, "auth_type": "basic", "password": password,
           "http_scheme": "https", "verify_ssl": True, "catalog": CAT, "schema": SCH}
    cfg.update(over)
    return cfg


def main():
    if not (USERS["qs_analyst"] and USERS["qs_restricted"]):
        raise SystemExit("source ~/.qs_keys/starburst_like.env (make_certs.sh writes it)")
    if not os.path.isfile(CA_PATH):
        raise SystemExit(f"no {CA_PATH}: run make_certs.sh")
    ca_pem = open(CA_PATH, encoding="utf-8").read()
    admin = Session("rig_admin", os.environ["QS_RIG_ADMIN_PW"])
    undo = []

    def connection(name, cfg):
        s, b, _ = admin.call("POST", "/api/connections", {"name": f"{name}-{TAG}", "connection_type": "starburst", "config": cfg})
        cid = (b or {}).get("id") if isinstance(b, dict) else None
        if not cid:
            raise SystemExit(f"could not create connection {name}: {s} {str(b)[:300]}")
        undo.insert(0, f"/api/connections/{cid}")
        return cid

    def test_conn(cid):
        s, b, _ = admin.call("POST", f"/api/connections/{cid}/test")
        return s, (b or {}) if isinstance(b, dict) else {"raw": b}

    def sql_run(cid, sql, who=admin):
        s, r, _ = who.call("POST", "/api/sql/execute", {"primary_connection_id": cid, "primary_sql": sql, "row_limit": 1000})
        if s != 200 or not (r or {}).get("execution_id"):
            return s, (r or {}), []
        st, meta = poll(who, r["execution_id"], timeout=900)
        got = [low(x) for x in rows(who, r["execution_id"], want=1000, size=1000)] if st == 200 else []
        return st, meta, got

    # ── truth, as Trino sees each user ──────────────────────────────────────
    t_cat = {u: sorted(r[0] for r in truth(u, "SHOW CATALOGS")) for u in USERS}
    t_tab = {u: sorted(r[0] for r in truth(u, f"SHOW TABLES FROM {CAT}.{SCH}")) for u in USERS}
    t_col = {u: [r[0] for r in truth(u, f"DESCRIBE {CAT}.{SCH}.{VISIBLE}")] for u in USERS}
    n_cob = {u: int(truth(u, f"SELECT count(*) FROM {CAT}.{SCH}.{VISIBLE} WHERE business_close_date = DATE '{COB}'")[0][0]) for u in USERS}
    by_ev = {r[0]: int(r[1]) for r in truth("qs_restricted", f"SELECT business_event, count(*) FROM {CAT}.{SCH}.{VISIBLE} "
                                                             f"WHERE business_close_date = DATE '{COB}' GROUP BY 1")}
    denied_col = truth_error("qs_restricted", f"SELECT {HIDDEN_COL} FROM {CAT}.{SCH}.{VISIBLE} LIMIT 1")
    check("truth", "Trino itself: the analyst sees the hidden table, the column and the role-gated table; the restricted user sees none",
          HIDDEN_TABLE in t_tab["qs_analyst"] and HIDDEN_TABLE not in t_tab["qs_restricted"]
          and HIDDEN_COL in t_col["qs_analyst"] and HIDDEN_COL not in t_col["qs_restricted"]
          and ROLE_TABLE in t_tab["qs_analyst"] and ROLE_TABLE not in t_tab["qs_restricted"]
          and VISIBLE in t_tab["qs_restricted"] and "iceberg" in t_cat["qs_analyst"] and "iceberg" not in t_cat["qs_restricted"]
          and n_cob["qs_restricted"] == n_cob["qs_analyst"] > 10_000 and "Access Denied" in denied_col,
          {"analyst_tables": t_tab["qs_analyst"], "restricted_tables": t_tab["qs_restricted"], "cob_rows": n_cob,
           "restricted_catalogs": t_cat["qs_restricted"], "denied": denied_col[:160]})
    try:
        # ── T1 HTTPS + pasted CA ────────────────────────────────────────────
        A = connection("sb-analyst", sb_config("qs_analyst", USERS["qs_analyst"], ca_cert_pem=ca_pem))
        R = connection("sb-restricted", sb_config("qs_restricted", USERS["qs_restricted"], ca_cert_pem=ca_pem))
        for cid, who in ((A, "analyst"), (R, "restricted")):
            s, b = test_conn(cid)
            check("T1", f"{who}: HTTPS with the rig CA pasted on the connection -> test succeeds and names the version",
                  s == 200 and b.get("success") is True and "version" in str(b.get("message", "")).lower(),
                  {"status": s, "msg": str(b.get("message"))[:160]})

        # ── T2 the Galaxy-format user ───────────────────────────────────────
        G = connection("sb-galaxy-user", sb_config(GALAXY_USER, USERS["qs_analyst"], ca_cert_pem=ca_pem))
        s, b = test_conn(G)
        st, meta, got = sql_run(G, "SELECT current_user AS u")
        check("T2", f"a Galaxy-format user name ({GALAXY_USER}) logs in and Trino's current_user is the whole string",
              s == 200 and b.get("success") is True and st == 200 and got and got[0].get("u") == GALAXY_USER,
              {"test": str(b.get("message"))[:120], "current_user": got[0] if got else meta})

        # ── T3 wrong password ───────────────────────────────────────────────
        W = connection("sb-wrong-pw", sb_config("qs_analyst", "not-the-password", ca_cert_pem=ca_pem))
        s, b = test_conn(W)
        msg = str(b.get("message", ""))
        check("T3", "a wrong password: the test says the source REJECTED the user name or password (401), in plain words",
              s == 200 and b.get("success") is False and "rejected the user name or password" in msg and "401" in msg
              and "b'" not in msg and "Traceback" not in msg, {"msg": msg[:200]})
        s, b, hd = admin.call("GET", f"/api/sql/connections/{W}/catalogs")
        check("T3", "browse with a wrong password is a 400 carrying that sentence -- not a 503 'try again', not a 500",
              s == 400 and "rejected the user name or password" in str((b or {}).get("detail")) and not has_retry_after(hd),
              {"status": s, "detail": str(b)[:200]})
        s, b, hd = admin.call("GET", f"/api/connections/{W}/tables")
        check("T3", "the BQB table browser answers the same 400 with the same sentence",
              s == 400 and "rejected the user name or password" in str((b or {}).get("detail")), {"status": s, "detail": str(b)[:200]})

        # ── T4 the CA not given: untrusted, said so ─────────────────────────
        U = connection("sb-untrusted", sb_config("qs_analyst", USERS["qs_analyst"]))     # verify on, no CA
        s, b = test_conn(U)
        msg = str(b.get("message", ""))
        check("T4", "without the CA the certificate is NOT silently trusted: the test fails and names the remedy (ca_cert_pem / QS_CA_BUNDLE_PATH)",
              s == 200 and b.get("success") is False and "not trusted" in msg and "ca_cert_pem" in msg
              and "HTTPSConnectionPool" not in msg, {"msg": msg[:220]})
        s, b, hd = admin.call("GET", f"/api/sql/connections/{U}/schemas?catalog={CAT}")
        check("T4", "browse on the untrusted certificate is a 400 with the sentence, no Retry-After (a retry never clears it)",
              s == 400 and "not trusted" in str((b or {}).get("detail")) and not has_retry_after(hd),
              {"status": s, "detail": str(b)[:200], "retry_after": has_retry_after(hd)})
        s, r, _ = admin.call("POST", "/api/sql/execute", {"primary_connection_id": U, "primary_sql": "SELECT 1 AS one", "row_limit": 10})
        st, meta = poll(admin, (r or {}).get("execution_id"), timeout=300) if s == 200 and (r or {}).get("execution_id") else (s, r)
        text = json.dumps(meta or r or {})
        # 2026-10-10 (first live run): the run's error_message was the TRANSPORT's
        # text, "HTTPSConnectionPool(host=..., port=8443): Max retries exceeded ...",
        # while the test and browse roads said "not trusted ... ca_cert_pem".
        check("T4", "a query on the untrusted certificate fails with the same sentence (no retry loop, no stack, no urllib3 text)",
              st != 200 and "not trusted" in text and "ca_cert_pem" in text and "Traceback" not in text
              and "HTTPSConnectionPool" not in text and "Max retries" not in text, {"status": st, "body": text[:220]})

        # ── T5 verify off: the opt-out still works ──────────────────────────
        V = connection("sb-verify-off", sb_config("qs_analyst", USERS["qs_analyst"], verify_ssl=False))
        s, b = test_conn(V)
        check("T5", "verify_ssl=false (no CA) connects -- the explicit opt-out for a known internal endpoint",
              s == 200 and b.get("success") is True, {"msg": str(b.get("message"))[:120]})

        # ── T6 the role reaches the cluster ─────────────────────────────────
        RO = connection("sb-role", sb_config("qs_restricted", USERS["qs_restricted"], ca_cert_pem=ca_pem, role="sb_auditor"))
        s, b = test_conn(RO)
        msg = str(b.get("message", ""))
        check("T6", "role=sb_auditor is SENT (X-Trino-Role) and judged by the cluster: its verdict names the role, in plain words",
              s == 200 and b.get("success") is False and "sb_auditor" in msg and ("set role" in msg.lower() or "access denied" in msg.lower())
              and "Traceback" not in msg, {"msg": msg[:220]})
        s, b, hd = admin.call("GET", f"/api/sql/connections/{RO}/tables?catalog={CAT}&schema={SCH}")
        # 2026-10-10 (first live run): Trino answers a refused X-Trino-Role with HTTP 500
        # and a Java body (io.trino.spi.security.AccessDeniedException ... \n\tat ...);
        # the product answered 500 "contact support".  A refused RIGHT is the source's
        # verdict: 403 carrying the cluster's sentence, no Java frame, no Retry-After.
        detail = str((b or {}).get("detail"))
        check("T6", "browse with the refused role is a 403 carrying the cluster's verdict (not 500, not 503, no Java stack)",
              s == 403 and "Access Denied" in detail and "sb_auditor" in detail and "io.trino" not in detail
              and "\\tat" not in detail and not has_retry_after(hd), {"status": s, "detail": detail[:200]})

        # ── T7 browse == Trino's own listing, per user ──────────────────────
        for cid, user in ((A, "qs_analyst"), (R, "qs_restricted")):
            s, cats, _ = admin.call("GET", f"/api/sql/connections/{cid}/catalogs")
            got = sorted(cats) if isinstance(cats, list) else []
            check("T7", f"{user}: SHOW CATALOGS through QueryStudio == Trino's own list for that user ({len(t_cat[user])})",
                  s == 200 and got == t_cat[user], {"got": got, "want": t_cat[user]})
            s, tabs, _ = admin.call("GET", f"/api/sql/connections/{cid}/tables?catalog={CAT}&schema={SCH}")
            got = sorted(t["name"] for t in tabs) if isinstance(tabs, list) else []
            check("T7", f"{user}: table browse == Trino's SHOW TABLES as that user ({len(t_tab[user])} tables)",
                  s == 200 and got == t_tab[user], {"got": got, "want": t_tab[user]})
            s, files, _ = admin.call("GET", f"/api/connections/{cid}/files")
            got = sorted(f.get("path", "").split(".")[-1] for f in files if f.get("path", "").startswith(f"{CAT}.{SCH}.")) if isinstance(files, list) else []
            check("T7", f"{user}: the BQB browser (files) lists the same {len(t_tab[user])} tables",
                  s == 200 and got == t_tab[user], {"got": got[:12], "want": t_tab[user][:12]})
        check("T7", "the hidden and the role-gated tables are in the analyst's browse and absent from the restricted user's (non-vacuous)",
              HIDDEN_TABLE in t_tab["qs_analyst"] and ROLE_TABLE in t_tab["qs_analyst"]
              and HIDDEN_TABLE not in t_tab["qs_restricted"] and ROLE_TABLE not in t_tab["qs_restricted"])

        # ── T8 columns per user; dataset auto-detect ────────────────────────
        for cid, user in ((A, "qs_analyst"), (R, "qs_restricted")):
            s, cols, _ = admin.call("GET", f"/api/sql/connections/{cid}/columns?catalog={CAT}&schema={SCH}&table={VISIBLE}")
            got = [c["name"] for c in cols] if isinstance(cols, list) else []
            check("T8", f"{user}: CQB columns of {VISIBLE} == Trino's DESCRIBE as that user ({len(t_col[user])} columns)",
                  s == 200 and got == t_col[user], {"got": got, "want": t_col[user]})
            s, sch, _ = admin.call("GET", f"/api/connections/{cid}/files/{CAT}.{SCH}.{VISIBLE}/schema")
            got = sorted((c.get("name") or c.get("column") or "") for c in ((sch or {}).get("columns") or [])) if s == 200 else []
            check("T8", f"{user}: the BQB table schema (files/.../schema, saved to the local column catalog) has the same columns",
                  s == 200 and got == sorted(t_col[user]), {"status": s, "got": got[:20], "body": str(sch)[:160] if s != 200 else ""})
        check("T8", f"{HIDDEN_COL} is in the analyst's columns and absent from the restricted user's (non-vacuous)",
              HIDDEN_COL in t_col["qs_analyst"] and HIDDEN_COL not in t_col["qs_restricted"])
        s, d_star, _ = admin.call("POST", "/api/datasets", {
            "name": f"sb_star_{TAG}", "subject": "sb", "connection_ids": [R],
            "base_query": f"select * from {CAT}.{SCH}.{VISIBLE} where business_close_date = DATE '{COB}'"})
        if check("T8", "a SELECT * dataset as the restricted user is created", s in (200, 201) and (d_star or {}).get("id"), (s, str(d_star)[:200])):
            undo.insert(0, f"/api/datasets/{d_star['id']}")
            # 2026-10-10 (lead's decision after the first live run).  With Trino's
            # defaults (hide_inaccessible_columns=false) a SELECT * over a table holding
            # a column the user may not read is REFUSED by the cluster -- "Access Denied:
            # Cannot select from columns [gbp_currency_amount] ..." -- it does not quietly
            # return the readable columns.  DESCRIBE hides the column (the browse checks
            # above); SELECT * names it.  So auto-detect, which runs the statement to
            # learn its shape, is correctly refused with the cluster's sentence, and must
            # store NO columns (a partial guess would be a dataset the run can never
            # serve).  The earlier expectation "auto-detect == DESCRIBE" was wrong.
            s, b, _ = admin.call("POST", f"/api/datasets/{d_star['id']}/auto-detect", {})
            detail = str((b or {}).get("detail") if isinstance(b, dict) else b)
            check("T8", "auto-detect on SELECT * as the restricted user is REFUSED (4xx) with the cluster's Access Denied sentence (no repr, no stack)",
                  400 <= s < 500 and "Access Denied" in detail and "Cannot select" in detail and VISIBLE in detail
                  and "TrinoUserError(" not in detail and "Traceback" not in detail, {"status": s, "detail": detail[:240]})
            s, d_after, _ = admin.call("GET", f"/api/datasets/{d_star['id']}")
            cols_after = (d_after or {}).get("columns") if isinstance(d_after, dict) else None
            check("T8", "... and the refused auto-detect stored NO columns (read back through the API, non-vacuous: the row answers 200 with a columns list)",
                  s == 200 and isinstance(cols_after, list) and len(cols_after) == 0, {"status": s, "columns": str(cols_after)[:160]})

        # ── T9 queries: visible == truth; hidden -> clear refusal ──────────
        for cid, user in ((A, "qs_analyst"), (R, "qs_restricted")):
            st, meta, got = sql_run(cid, f"SELECT business_event, count(*) AS n FROM {CAT}.{SCH}.{VISIBLE} "
                                         f"WHERE business_close_date = DATE '{COB}' GROUP BY 1")
            g = {x["business_event"]: int(x["n"]) for x in got}
            check("T9", f"{user}: GROUP BY on the visible table == Trino ({sum(by_ev.values()):,} rows over {len(by_ev)} events)",
                  st == 200 and g == by_ev, {"status": st, "got": g, "err": str(meta)[:200] if st != 200 else ""})
        st, meta, got = sql_run(R, f"SELECT {HIDDEN_COL} FROM {CAT}.{SCH}.{VISIBLE} LIMIT 1")
        text = json.dumps(meta)
        # 2026-10-10 (first live run): the error_message was the DRIVER's repr,
        # TrinoUserError(type=USER_ERROR, name=PERMISSION_DENIED, message="...", query_id=...)
        check("T9", f"restricted: selecting the hidden column {HIDDEN_COL} is REFUSED with the cluster's sentence (names the table, no stack, no driver repr)",
              # Trino 483 file access control words a denied COLUMN as "Access Denied:
              # Cannot select from table <t>" (selfcheck.sh shows the CLI saying exactly
              # that): the product relays the cluster's sentence and must not invent a
              # column name the cluster did not give (2026-10-10 live re-run).
              st != 200 and "Access Denied" in text and "Cannot select" in text and VISIBLE in text and "Traceback" not in text
              and "TrinoUserError(" not in text and "query_id" not in text and not got,
              {"status": st, "body": text[:240]})
        st, meta, got = sql_run(R, f"SELECT count(*) FROM {CAT}.{SCH}.{HIDDEN_TABLE}")
        text = json.dumps(meta)
        check("T9", f"restricted: the hidden table {HIDDEN_TABLE} is refused (not an empty success)",
              st != 200 and HIDDEN_TABLE in text and "Traceback" not in text and not got, {"status": st, "body": text[:240]})
        st, meta, got = sql_run(A, f"SELECT count(*) AS n FROM {CAT}.{SCH}.{HIDDEN_TABLE}")
        check("T9", "analyst: the same hidden table answers a count (the refusal above was the ROLE, not the table)",
              st == 200 and got and int(got[0]["n"]) > 0, {"status": st, "got": got[:1]})

        # ── T10 dataset -> report -> published API, as the restricted user ─
        s, ds, _ = admin.call("POST", "/api/datasets", {
            "name": f"sb_rep_{TAG}", "subject": "sb", "connection_ids": [R],
            "base_query": (f"select source_data_row, sap_company_id, business_event from {CAT}.{SCH}.{VISIBLE} "
                           f"where business_close_date = DATE '{COB}'")})
        if check("T10", "dataset as the restricted user created", s in (200, 201) and (ds or {}).get("id"), (s, str(ds)[:200])):
            undo.insert(0, f"/api/datasets/{ds['id']}")
            admin.call("POST", f"/api/datasets/{ds['id']}/auto-detect", {})
            cols = {c["physical_name"].lower(): c for c in admin.call("GET", f"/api/datasets/{ds['id']}")[1]["columns"]}
            for col in cols.values():
                admin.call("PUT", f"/api/datasets/columns/{col['id']}", {"column_type": "dimension"})
            s, rep, _ = admin.call("POST", "/api/business-reports", {
                "name": f"sb-rep-{TAG}", "dataset_id": ds["id"], "data_source_type": "dataset",
                "column_ids": [cols["source_data_row"]["id"], cols["sap_company_id"]["id"], cols["business_event"]["id"]]})
            if check("T10", "report on it created", s == 200 and (rep or {}).get("id"), (s, str(rep)[:200])):
                undo.insert(0, f"/api/business-reports/{rep['id']}")
                # 2026-10-10 (first live run): this returned total_rows=50000 against a
                # truth of 201,600 -- not a short read: a report created without a
                # row_limit stores the model's default (50,000) and the run is CAPPED at
                # it.  A cap must throttle AND be visible: the envelope's ``truncated``
                # (core.reports.contract.truncation_verdict) must be True at the cap and
                # ``row_limit`` must name it -- a capped count is never served as a
                # silent total.  Then the truth comparison runs UNCAPPED
                # (limit_override=0 == unlimited, the published API's own posture).
                s, ex, _ = admin.call("POST", f"/api/business-reports/{rep['id']}/execute", {"parameter_values": {}, "force_refresh": True})
                ex = ex if isinstance(ex, dict) else {}
                tot = int(ex.get("total_rows") or 0)
                cap = ex.get("row_limit")
                check("T10", f"report run at its default cap SAYS so: total_rows == row_limit ({cap}) < truth {n_cob['qs_restricted']:,}, truncated is True",
                      s == 200 and isinstance(cap, int) and 0 < cap < n_cob["qs_restricted"] and tot == cap and ex.get("truncated") is True,
                      {"status": s, "total": tot, "row_limit": cap, "truncated": ex.get("truncated"), "body": str(ex)[:200] if s != 200 else ""})
                s, ex, _ = admin.call("POST", f"/api/business-reports/{rep['id']}/execute",
                                      {"parameter_values": {}, "force_refresh": True, "limit_override": 0})
                ex = ex if isinstance(ex, dict) else {}
                tot = int(ex.get("total_rows") or 0)
                check("T10", f"report run UNCAPPED as the restricted user: {n_cob['qs_restricted']:,} rows == Trino as that user, truncated is False",
                      s == 200 and tot == n_cob["qs_restricted"] and ex.get("truncated") is False,
                      {"status": s, "total": tot, "truncated": ex.get("truncated"), "body": str(ex)[:200] if s != 200 else ""})
                slug = f"sb-pv-{TAG}"
                admin.call("POST", f"/api/business-reports/{rep['id']}/publish", {"action": "publish"})
                s, pv, _ = admin.call("POST", "/api/published-views", {"name": slug, "slug": slug, "source_type": "business_report",
                                                                       "business_report_id": rep["id"], "credential_mode": "publisher"})
                pid = (pv or {}).get("id") or ((pv or {}).get("view") or {}).get("id")
                key = (pv or {}).get("test_api_key") or ""
                if check("T10", "the report is published as an API with a key", s in (200, 201) and pid and key, (s, str(pv)[:200])):
                    undo.insert(0, f"/api/published-views/{pid}")
                    import qs_docker_client as c
                    saved = c.BASE
                    c.BASE = PUB
                    try:
                        s, b, _ = c.call("GET", f"/api/v1/views/{slug}/data?limit=50", None, headers={"X-API-Key": key})
                    finally:
                        c.BASE = saved
                    data = (b or {}).get("data") or (b or {}).get("rows") or [] if isinstance(b, dict) else []
                    total = (b or {}).get("total_rows") or (b or {}).get("total") or ((b or {}).get("meta") or {}).get("total_rows") if isinstance(b, dict) else None
                    check("T10", "the published API serves the restricted user's report rows (the connection's own login, over TLS)",
                          s == 200 and len(data) == 50 and all("sap_company_id" in low(r) for r in data[:5]),
                          {"status": s, "rows": len(data), "total": total, "body": str(b)[:160] if s != 200 else ""})

        # ── T11 feed on the native lane, as the restricted user ────────────
        agg_sql = (f"select business_event, count(*) as n from {CAT}.{SCH}.{VISIBLE} "
                   f"where business_close_date = DATE '{COB}' group by business_event")
        s, q, _ = admin.call("POST", "/api/queries", {"name": f"sb_sq_{TAG}", "query_config": {"files": [], "raw_sql": agg_sql, "connection_id": R}})
        if check("T11", "saved query as the restricted user created", s in (200, 201) and (q or {}).get("id"), (s, str(q)[:160])):
            undo.append(f"/api/queries/{q['id']}")

            def run_feed(backend, label):
                s, fb, _ = admin.call("POST", "/api/feeds", {
                    "name": f"SB_FEED_{backend.upper()}_{TAG}", "source_type": "saved_query", "source_id": q["id"], "connection_id": R,
                    "output_format": "csv", "destination_type": "local", "destination_config": {"path": "/app/data/feeds"},
                    "execution_backend": backend})
                if not check(label, f"feed on the {backend} lane created", s == 200 and (fb or {}).get("id"), (s, str(fb)[:300])):
                    return
                undo.insert(0, f"/api/feeds/{fb['id']}")
                s, ex, _ = admin.call("POST", f"/api/feeds/{fb['id']}/execute", {"trigger_type": "manual"})
                dbid = (ex or {}).get("execution_db_id")
                e, t0 = {}, time.time()
                while dbid and time.time() - t0 < 1500:
                    _, e, _ = admin.call("GET", f"/api/feed-executions/{dbid}")
                    if (e or {}).get("status") in ("completed", "failed", "error", "cancelled"):
                        break
                    time.sleep(2)
                e = e or {}
                body_txt = ""
                if e.get("destination_path"):
                    body_txt = subprocess.run(["docker", "exec", "qs-local-api", "cat", e["destination_path"]],
                                              capture_output=True, text=True, env=DENV).stdout
                    subprocess.run(["docker", "exec", "-u", "0", "qs-local-api", "rm", "-f", e["destination_path"]], env=DENV)
                lines = body_txt.splitlines()
                hdr = [h.strip().strip('"').lower() for h in lines[0].split(",")] if lines else []
                got = {}
                for ln in lines[1:]:
                    if ln.strip():
                        rec = dict(zip(hdr, [v.strip('"') for v in ln.split(",")]))
                        got[rec.get("business_event")] = int(float(rec.get("n") or 0))
                check(label, f"feed on the {backend} lane as the restricted user: the delivered file == Trino's GROUP BY as that user",
                      e.get("status") == "completed" and got == by_ev,
                      {"status": e.get("status"), "got": got, "want": by_ev, "err": str(e.get("error_message"))[:300]})

            run_feed("native", "T11")
            if SPARK:
                run_feed("spark_k8s", "S1")
            else:
                print("SKIP [S1] feed on the spark_k8s lane: set QS_SB_SPARK=1 with the kind cluster attached and a job image "
                      "that carries the Trino JDBC jar (the lane carries role, verify_ssl and ca_cert_pem; proven by unit test only)", flush=True)
                results.setdefault("skipped", []).append("S1 spark_k8s lane")

        # ── T12 cross-source: two logins on one host, one query ────────────
        body = {"connection_id": R, "output_format": "json", "cache_strategy": "bypass",
                "raw_sql": f"select sap_company_id, 'RESTRICTED' as who from {CAT}.{SCH}.{VISIBLE} where business_close_date = DATE '{COB}' and business_event = 'BOOKING'",
                "secondary_connection_id": A,
                "secondary_raw_sql": f"select sap_company_id, 'ANALYST' as who from {CAT}.{SCH}.{HIDDEN_TABLE}",
                "combine_mode": "union"}
        n_hidden = int(truth("qs_analyst", f"SELECT count(*) FROM {CAT}.{SCH}.{HIDDEN_TABLE}")[0][0])
        n_book = by_ev.get("BOOKING", 0)
        s, r, _ = admin.call("POST", "/api/execute", body)
        st, meta = poll(admin, (r or {}).get("execution_id"), timeout=900) if s == 200 and (r or {}).get("execution_id") else (s, r)
        total = int((meta or {}).get("total_rows") or (meta or {}).get("row_count") or 0) if st == 200 else 0
        check("T12", f"cross-source UNION: the restricted login's {n_book:,} rows + the analyst login's {n_hidden} hidden-table rows (each leg its OWN login, both over TLS)",
              st == 200 and total == n_book + n_hidden and n_hidden > 0, {"status": st, "total": total, "want": n_book + n_hidden, "err": str(meta)[:200] if st != 200 else ""})
    finally:
        for p in undo:
            admin.call("DELETE", p)
        print(f"\ncleanup: {len(undo)} removed")
    with open(os.environ.get("QS_PERF_OUT", "starburst-like-results.json"), "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1, default=str)
    print(f"\n{sum(res)}/{len(res)} PASSED" + ("" if SPARK else "  (S1 spark lane SKIPPED: QS_SB_SPARK=1 to run)"))
    return 0 if res and all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
