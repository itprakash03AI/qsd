"""THE OWNER'S REAL END-TO-END CASE on the live Docker rig (2026-10-11; record
docs/TETB_REAL_E2E_2026_10_11.html): fact_tetb + fact_tetb_ext, ~4,000
SYSTEM_ENTITY codes x several business events, every entity on CLOUD and
ON-PREM in both tables, combined UNION ALL by name, delivered by SFTP -- each
feed held until BOTH sides' COMPLETE message has arrived, and each side's rows
CERTIFIED against the ROW_COUNT that message carried.

Stand-ins on the rig:
  cloud     qs-trino, catalog iceberg_aws on the REAL AWS bucket
            (qs-732159826119-us-east-2-an), schema fins_<tag> created here
  on-prem   qs-trino-sb (the Starburst-shaped second Trino):
              --onprem iceberg   catalog iceberg on MinIO (schema qs)
              --onprem hive      catalog hive, a file metastore on MinIO
                                 (starburst_like/make_hive_catalog.sh)
  upstream  the OG QS_KAFKA_MESSAGE row, arriving TWO ways:
              (a) as JSON on the Kafka topic qs.kafka.message   (half the islands)
              (b) as a ROW INSERTED into QS_KAFKA_MESSAGE in the rig's Oracle
                  (container oracle-db, connection oracle-otg)   (the other half)
            -- both resolved by ONE rule (tetb_real_e2e.override.yml):
            {DATA_SOURCE}_{CODE}_{BUSINESS_EVENT}_{CLOUD_COMPLIANT->CLOUD|ONPREM},
            VERSION_STATE must be COMPLETE, ROW_COUNT recorded.
  delivery  qs-sftp; truth = the two Trino CLIs, no QueryStudio code on the path.

The owner's SQL (scripts/docker_proof/fixtures/fact_tetb.json -- NOT strict
JSON, parsed tolerantly -- and test_query_001.json) runs VERBATIM except the
FROM catalog.schema.table.  Every column the queries read is created, typed
from the CASTs (DATE / VARCHAR; the raw trailing columns get sensible types),
partitioned by (business_close_date, code, businessevent).

What is proven, per run (N entities x E events, default 5 x 3, both tables):
  A  TWO templates -> 2*N*E feeds, each with TWO dependencies (CLOUD certifies
     the primary side, ONPREM the secondary), each met by EITHER road
     (arrival_sources kafka + oracle_table, require_mode any); re-apply = unchanged.
  B  the HOLD: every run born WAIT; after --hold s nothing ran; the hold names both.
  C  ONE side's COMPLETE message alone does NOT release (Kafka road for half
     the islands, the Oracle row for the other half); the hold names ONPREM.
  D  a non-COMPLETE message (VERSION_STATE IN_PROGRESS) does NOT count: still
     held; the rows are 'filtered' on both roads, never an arrival.
  E  both COMPLETE -> the poller releases every run; the queue worker runs them;
     every run completes -- except the island whose ONPREM message LIED about
     its ROW_COUNT: that run FAILS at certify_reported_rows with the numbers.
  F  every delivered file, read ON the SFTP server: header = the cloud query's
     columns in its order; rows == cloud island UNION ALL on-prem island (count
     AND full-row multiset vs the two Trino CLIs; the compared count asserted
     NON-ZERO); one island per side (decoys absent); files_metadata.cross_source
     primary + secondary == expected == delivered; the certificate reconciles;
     stage_timings.reported_rows_certification is 'certified' per side with
     reported == actual.
  G  the ALTERNATIVE trigger: a feed declared on iceberg_commit of the cloud
     table (registered on connection aws-real) is held until its island's rows
     are INSERTED (a new snapshot proving the date), then runs and delivers.
  H  the ledger: every dependency's arrival carries reported_rows; the arrivals
     are split between source kafka and source oracle_table as sent.

    . ~/.qs_keys/rigpw.sh; . ~/.qs_keys/starburst_like.env
    docker compose -f docker-compose.local.yml \\
                   -f scripts/docker_proof/compose/tetb_real_e2e.override.yml \\
                   --profile workers up -d kafka api scheduler
    python scripts/docker_proof/tetb_real_e2e_proof.py --plan
    python scripts/docker_proof/tetb_real_e2e_proof.py --onprem iceberg
    python scripts/docker_proof/tetb_real_e2e_proof.py --onprem hive
    python scripts/docker_proof/tetb_real_e2e_proof.py --backend spark_k8s

Everything this run creates is removed in a finally (proof_cleanup Ledger);
``--sweep-leftovers [--execute]`` finds a killed run's objects by name --
templates, saved queries, connections, feeds, the AWS schema, the on-prem
tables, the Oracle rows.
"""
from __future__ import annotations

import argparse
import collections
import itertools
import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from feed_dependencies_proof import (  # noqa: E402
    broker_healthy, broker_running, docker, rpk,
)
from feed_triggers_proof import Rig, check, psql, res, trino, wait_until  # noqa: E402
from monthly_kafka_merge_feeds_proof import (  # noqa: E402
    await_template_apply, connections, pick_cloud, sftp_host_key, sftp_ls,
    sftp_read, trino_stdin,
)
from proof_cleanup import Ledger, Rule, oracle_admin, sweep_flags, sweep_leftovers  # noqa: E402

os.environ.setdefault("MSYS_NO_PATHCONV", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
FIX_TETB = os.path.join(HERE, "fixtures", "fact_tetb.json")
FIX_EXT = os.path.join(HERE, "fixtures", "test_query_001.json")
TAG = str(int(time.time()))[-6:]
TOPIC = "qs.kafka.message"
ORA_TABLE = "QS_KAFKA_MESSAGE"
ORA_SEQ = "QS_KAFKA_MESSAGE_SEQ"
AWS_BUCKET = "qs-732159826119-us-east-2-an"
CLOUD_SCHEMA = f"iceberg_aws.fins_{TAG}"
SFTP = {"container": "qs-sftp", "host": "qs-sftp", "port": 22, "username": "feeduser",
        "password": "FeedPass_123", "remote_dir": "/inbox", "home": "/home/feeduser/inbox"}
SB_HOST, SB_PORT = "qs-trino-sb", 8443
DENV = dict(os.environ, MSYS_NO_PATHCONV="1")

#: the two tables: (label, DATA_SOURCE the message names, fixture, cloud key,
#: on-prem key, the alias token in the SQL, the FROM to replace per side)
TABLES = {
    "tetb": {"data_source": "finance_sl_balance", "fixture": FIX_TETB,
             "cloud_key": "query_cloud", "onprem_key": "query_onprem", "alias": "FACT_TETB",
             "from_cloud": "icbg.fins.fact_tetb", "from_onprem": "onprem.fins.fact_tetb",
             "table": "fact_tetb"},
    "ext": {"data_source": "finance_sl_balance_ext", "fixture": FIX_EXT,
            "cloud_key": "query_on_cloud", "onprem_key": "query_on_prem", "alias": "FACT_TETB_EXT",
            "from_cloud": "qs_icbg.fins.fact_tetb_ext", "from_onprem": "qs_store_ro.fact_tetb_ext",
            "table": "fact_tetb_ext"},
}
#: raw (un-CAST) columns the owner's queries read, and the type each gets
RAW_TYPES = {"SNAP_VERSION": "BIGINT", "POSITION_INTEREST_RATE": "DOUBLE"}
DATE_COLS = {"BUSINESS_CLOSE_DATE", "INITIAL_POSTING_DT", "ADJ_ENRICH_CREATED"}


# ── the owner's queries, read tolerantly ─────────────────────────────────

def load_queries(spec: dict) -> tuple[str, str]:
    """``(cloud_sql, onprem_sql)``.  fact_tetb.json is NOT strict JSON: two
    ``"key": "<SQL with unescaped quotes and newlines>"`` members with no
    outer braces.  test_query_001.json IS JSON.  Both read the same way:
    find each key, take the text between its opening quote and the closing
    quote that ends the member."""
    text = open(spec["fixture"], encoding="utf-8").read()
    try:
        doc = json.loads(text)
        return doc[spec["cloud_key"]], doc[spec["onprem_key"]]
    except ValueError:
        pass

    def member(key: str) -> str:
        m = re.search(r'"%s"\s*:\s*"' % re.escape(key), text)
        if not m:
            raise SystemExit(f"{spec['fixture']}: no member {key!r}")
        start = m.end()
        # the member ends at a quote followed by (optional comma) and a line
        # break / end of text / the next member's key
        end = re.compile(r'"\s*,?\s*(?:\n\s*"[A-Za-z_]+"\s*:|\s*$)').search(text, start)
        if not end:
            raise SystemExit(f"{spec['fixture']}: member {key!r} never closes")
        return text[start:end.start()]
    return member(spec["cloud_key"]), member(spec["onprem_key"])


_CAST_RE = re.compile(r'CAST\(\s*(?:[A-Z_]+\.)?([A-Za-z0-9_]+)\s+AS\s+(VARCHAR|DATE)\s*\)\s+AS\s+"([A-Za-z0-9_]+)"', re.I)


def _items(select: str):
    depth, buf, quote = 0, "", ""
    for ch in select:
        if quote:
            buf += ch
            if ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            yield buf
            buf = ""
            continue
        buf += ch
    if buf.strip():
        yield buf


def parse_query(sql: str, alias: str):
    """``(projected aliases in order, {base column: type})`` from the owner's
    SELECT: ``CAST(x AS T) AS "ALIAS"`` items, the PARTITION_KEY concatenation
    and the bare trailing ``ALIAS.COLUMN`` items (unquoted: Trino folds their
    names to lower case in the result)."""
    head = re.split(r'\sFROM\s', sql, maxsplit=1, flags=re.I)[0]
    head = re.sub(r'^\s*SELECT\s+', '', head, flags=re.I)
    aliases, types = [], {}
    bare = re.compile(r'^\s*%s\.([A-Za-z0-9_]+)\s*$' % re.escape(alias), re.I)
    for item in _items(head):
        m = _CAST_RE.search(item)
        if m:
            base, typ, al = m.group(1).upper(), m.group(2).upper(), m.group(3)
            aliases.append(al)
            types.setdefault(base, "DATE" if typ == "DATE" else "VARCHAR")
            continue
        if "PARTITION_KEY" in item.upper():
            aliases.append("PARTITION_KEY")
            types.setdefault("CODE", "VARCHAR")
            types.setdefault("BUSINESSEVENT", "VARCHAR")
            continue
        b = bare.match(item)
        if b:
            col = b.group(1).upper()
            aliases.append(col.lower())
            types.setdefault(col, RAW_TYPES.get(col, "VARCHAR"))
            continue
        raise SystemExit(f"SELECT item not understood: {item.strip()[:100]!r}")
    for c in ("BUSINESS_CLOSE_DATE", "CODE", "BUSINESSEVENT"):
        types.setdefault(c, "DATE" if c == "BUSINESS_CLOSE_DATE" else "VARCHAR")
    types["BUSINESS_CLOSE_DATE"] = "DATE"
    for c in DATE_COLS:
        if c in types:
            types[c] = "DATE"
    return aliases, types


PARTITION = ("BUSINESS_CLOSE_DATE", "CODE", "BUSINESSEVENT")


def ddl(table: str, types: dict, *, hive: bool, location: str | None = None) -> str:
    cols = list(types)
    if hive:
        # Hive: partition columns LAST, declared through partitioned_by
        cols = [c for c in cols if c not in PARTITION] + list(PARTITION)
        body = ", ".join(f"{c.lower()} {types[c]}" for c in cols)
        return (f"CREATE TABLE {table} ({body}) WITH (format = 'PARQUET', "
                f"partitioned_by = ARRAY['business_close_date', 'code', 'businessevent'])")
    body = ", ".join(f"{c.lower()} {types[c]}" for c in cols)
    props = ["partitioning = ARRAY['business_close_date', 'code', 'businessevent']",
             "format = 'PARQUET'"]
    if location:
        props.append(f"location = '{location}'")
    return f"CREATE TABLE {table} ({body}) WITH ({', '.join(props)})"


def abbr(col: str) -> str:
    return hashlib.sha1(col.encode()).hexdigest()[:3]


def row_values(side: str, types: dict, date: dt.date, entity: str, event: str, i: int):
    out = []
    for c, t in types.items():
        if c == "BUSINESS_CLOSE_DATE":
            out.append(date)
        elif c == "CODE":
            out.append(entity)
        elif c == "BUSINESSEVENT":
            out.append(event)
        elif c == "SOURCE_DATA_ROW":
            out.append(f"{side}:{entity}:{event}:{i}")
        elif t == "DATE":
            out.append(date)
        elif t == "BIGINT":
            out.append(i)
        elif t == "DOUBLE":
            out.append(i + 0.5)
        else:
            out.append(f"{abbr(c)}{side[0]}{i}")
    return out


def lit(v) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(v) if isinstance(v, float) else str(v)
    if isinstance(v, dt.date):
        return f"DATE '{v.isoformat()}'"
    return "'" + str(v).replace("'", "''") + "'"


# ── the two clusters' CLIs ───────────────────────────────────────────────

def sb_cli(sql: str, *, stdin: bool = False) -> str:
    """Trino's own answer on qs-trino-sb as qs_analyst (the on-prem truth)."""
    pw = os.environ.get("QS_SB_ANALYST_PW")
    if not pw:
        raise SystemExit("QS_SB_ANALYST_PW is not set: . ~/.qs_keys/starburst_like.env")
    cmd = ["docker", "exec", "-i", "-e", f"TRINO_PASSWORD={pw}", SB_HOST, "trino",
           "--server", "https://localhost:8443", "--insecure", "--user", "qs_analyst", "--password",
           "--output-format", "TSV"]
    if stdin:
        # --file needs a TERMINATED statement (the owner's SQL carries none)
        sql = sql.rstrip().rstrip(";") + ";"
        r = subprocess.run(cmd + ["--file", "/dev/stdin"], input=sql, capture_output=True,
                           text=True, env=DENV, timeout=900)
    else:
        r = subprocess.run(cmd + ["--execute", sql], capture_output=True, text=True, env=DENV, timeout=900)
    if r.returncode != 0:
        _out = (r.stderr or "") + (r.stdout or "")
        _v = [ln for ln in _out.splitlines() if "failed:" in ln or ln.startswith("LINE ") or "Non-terminated" in ln][:4]
        raise RuntimeError(f"qs-trino-sb: {' | '.join(_v) or _out[:400]} -- {sql[:160]}")
    return r.stdout.replace("\r", "")


def cloud_cli(sql: str, *, stdin: bool = False) -> str:
    if stdin:
        return trino_stdin(sql).replace("\r", "")
    out = subprocess.run(["docker", "exec", "qs-trino", "trino", "--output-format", "TSV",
                          "--execute", sql], capture_output=True, text=True, env=DENV, timeout=900)
    if out.returncode != 0:
        raise RuntimeError(f"qs-trino: {(out.stderr or out.stdout)[-500:]} -- {sql[:160]}")
    return out.stdout.replace("\r", "")


def insert_rows(cli, table: str, types: dict, rows, batch: int = 20) -> int:
    n = 0
    cols = ", ".join(c.lower() for c in types)
    for k in range(0, len(rows), batch):
        chunk = rows[k:k + batch]
        values = ",\n".join("(" + ", ".join(lit(v) for v in r) + ")" for r in chunk)
        cli(f"INSERT INTO {table} ({cols}) VALUES\n{values};\n", stdin=True)
        n += len(chunk)
    return n


def drop_schema_cascade(cli, schema: str):
    """Drop every table of ``schema`` (SHOW TABLES on the cluster that owns
    it) and then the schema -- the Ledger's remover contract ``(ok, reason)``."""
    failures = []
    try:
        tables = [t.strip().strip('"') for t in cli(f"SHOW TABLES FROM {schema}").splitlines() if t.strip()]
    except Exception as exc:  # noqa: BLE001
        return False, f"could not list {schema}: {str(exc)[:200]}"
    for t in tables:
        try:
            cli(f"DROP TABLE {schema}.{t}")
        except Exception as exc:  # noqa: BLE001
            failures.append(f"{t}: {str(exc)[:120]}")
    try:
        cli(f"DROP SCHEMA {schema}")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"schema: {str(exc)[:120]}")
    if failures:
        return False, "; ".join(failures)
    return True, f"dropped {len(tables)} table(s) + schema"


def tsv_rows(text: str, ncols: int):
    out = []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) != ncols:
            raise RuntimeError(f"truth row has {len(parts)} cells, expected {ncols}: {line[:120]!r}")
        out.append(parts)
    return out


# ── the message, two roads ───────────────────────────────────────────────

def message(data_source: str, entity: str, event: str, date: dt.date, cloud: bool,
            state: str, row_count: int, seq: int) -> dict:
    stamp = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    return {"ID": seq, "DATA_STORE": "QS", "DATA_SOURCE": data_source, "SOURCE_SYSTEM_NAME": "WS_STORE",
            "SOURCE_SYSTEM_INSTANCE": "uat", "BUSINESS_DATE": date.isoformat(), "CODE": entity,
            "BUSINESS_EVENT": event, "CLOUD_COMPLIANT": "true" if cloud else "false", "ORDER": "NA",
            "SNAP_VERSION": f"{TAG}{seq:08d}", "VERSION_NUMBER": f"{TAG}{seq:08d}", "VERSION": seq,
            "CATALOGUE_REGISTRATION_TIME": stamp, "VERSION_STATE": state, "ROW_COUNT": int(row_count),
            "PROCESSED": "Y", "CREATED_AT": stamp, "FK_DEPENDENCY_ID": None,
            "DATA_LOAD_STATUS": "PENDING", "sent_by": f"tetb_real_e2e_proof {TAG}"}


def produce_kafka(messages) -> int:
    rc, out = rpk("topic", "produce", TOPIC, "-f", "%v\\n",
                  stdin="".join(json.dumps(m) + "\n" for m in messages))
    if rc != 0:
        raise RuntimeError(f"produce failed: {out[-300:]}")
    return out.count("Produced")


def ora_insert_sql(m: dict) -> str:
    def q(v):
        return "NULL" if v is None else "'" + str(v).replace("'", "''") + "'"
    return (f"INSERT INTO {ORA_TABLE} (ID, DATA_STORE, DATA_SOURCE, SOURCE_SYSTEM_NAME, SOURCE_SYSTEM_INSTANCE, "
            f"BUSINESS_DATE, CODE, BUSINESS_EVENT, CLOUD_COMPLIANT, \"ORDER\", SNAP_VERSION, VERSION_NUMBER, VERSION, "
            f"CATALOGUE_REGISTRATION_TIME, VERSION_STATE, ROW_COUNT, PROCESSED, FK_DEPENDENCY_ID, DATA_LOAD_STATUS) "
            f"VALUES ({ORA_SEQ}.NEXTVAL, {q(m['DATA_STORE'])}, {q(m['DATA_SOURCE'])}, {q(m['SOURCE_SYSTEM_NAME'])}, "
            f"{q(m['SOURCE_SYSTEM_INSTANCE'])}, TO_DATE('{m['BUSINESS_DATE']}', 'YYYY-MM-DD'), {q(m['CODE'])}, "
            f"{q(m['BUSINESS_EVENT'])}, {q(m['CLOUD_COMPLIANT'])}, {q(m['ORDER'])}, {q(m['SNAP_VERSION'])}, "
            f"{q(m['VERSION_NUMBER'])}, {int(m['VERSION'])}, {q(m['CATALOGUE_REGISTRATION_TIME'])}, "
            f"{q(m['VERSION_STATE'])}, {int(m['ROW_COUNT'])}, 'Y', NULL, {q(m['DATA_LOAD_STATUS'])})")


ORA_DDL = (f"CREATE TABLE {ORA_TABLE} (ID NUMBER NOT NULL PRIMARY KEY, DATA_STORE VARCHAR2(100) NOT NULL, "
           f"DATA_SOURCE VARCHAR2(100) NOT NULL, SOURCE_SYSTEM_NAME VARCHAR2(100) NOT NULL, "
           f"SOURCE_SYSTEM_INSTANCE VARCHAR2(100) NOT NULL, BUSINESS_DATE DATE NOT NULL, CODE VARCHAR2(100) NOT NULL, "
           f"BUSINESS_EVENT VARCHAR2(100) NOT NULL, CLOUD_COMPLIANT VARCHAR2(100) NOT NULL, \"ORDER\" VARCHAR2(100) NOT NULL, "
           f"SNAP_VERSION VARCHAR2(100) NOT NULL, VERSION_NUMBER VARCHAR2(100) NOT NULL, VERSION NUMBER NOT NULL, "
           f"CATALOGUE_REGISTRATION_TIME VARCHAR2(100) NOT NULL, VERSION_STATE VARCHAR2(100) NOT NULL, "
           f"ROW_COUNT NUMBER NOT NULL, PROCESSED VARCHAR2(10) NOT NULL, "
           f"CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL, FK_DEPENDENCY_ID NUMBER, "
           f"DATA_LOAD_STATUS VARCHAR2(30 CHAR) DEFAULT 'PENDING')")


def ensure_oracle_table(ora_conn_id: int) -> str:
    """The OG table in the rig's Oracle (the owner's DDL, from
    fixtures/QS_KAFKA_MESSAGE.sql) and its sequence, created once; never
    dropped by the proof (other runs share it; rows are removed by CODE)."""
    out = oracle_admin([f"SELECT table_name FROM user_tables WHERE table_name = '{ORA_TABLE}'",
                        f"SELECT sequence_name FROM user_sequences WHERE sequence_name = '{ORA_SEQ}'"],
                       connection_id=ora_conn_id)
    stmts = []
    if ORA_TABLE not in out:
        stmts.append(ORA_DDL)
    if ORA_SEQ not in out:
        stmts.append(f"CREATE SEQUENCE {ORA_SEQ} START WITH 100000 INCREMENT BY 1 NOCACHE")
    if stmts:
        out2 = oracle_admin(stmts, connection_id=ora_conn_id)
        if "ERROR" in out2:
            raise SystemExit(f"could not create {ORA_TABLE}: {out2[-400:]}")
        return "created"
    return "present"


def ora_rows(ora_conn_id: int, messages) -> int:
    out = oracle_admin([ora_insert_sql(m) for m in messages], connection_id=ora_conn_id)
    if "ERROR" in out:
        raise RuntimeError(f"oracle insert: {out[-400:]}")
    return out.count("ok:")


# ── plan ─────────────────────────────────────────────────────────────────

def plan(args):
    print(__doc__)
    print("NEEDS")
    print("  containers : qs-local-api, qs-local-scheduler (profile workers), qs-local-postgres, qs-kafka,")
    print("               qs-trino (+ real AWS creds in iceberg_aws), qs-minio, qs-trino-sb, qs-sftp, oracle-db")
    print("  env        : QS_RIG_ADMIN_PW (. ~/.qs_keys/rigpw.sh), QS_SB_ANALYST_PW (. ~/.qs_keys/starburst_like.env)")
    print("  compose    : docker compose -f docker-compose.local.yml \\")
    print("                 -f scripts/docker_proof/compose/tetb_real_e2e.override.yml --profile workers up -d kafka api scheduler")
    print("  sb         : sh scripts/docker_proof/starburst_like/make_certs.sh   (now also writes generated/catalog/hive.properties)")
    print("               docker compose -f docker-compose.local.yml -f scripts/docker_proof/compose/starburst_like.override.yml up -d --force-recreate qs-trino-sb")
    print("  --onprem hive additionally needs the hive catalog visible: SHOW CATALOGS on qs-trino-sb;")
    print("               the hive schema is created WITHOUT a location (the file metastore owns managed-table dirs)")
    print("  iceberg feed: its dependency is iceberg_commit FOR THE PARTITION code={SYSTEM_ENTITY}, businessevent={EventCode}")
    print("               (rendered from the feed's query_params) -- other islands' commits must NOT release it (G1)")
    print("  connections: a Trino connection on qs-trino (cloud), 'aws-real' (the iceberg_commit trigger), 'oracle-otg' (the Oracle road)")
    print(f"  this run   : {args.entities} entities x {len(args.events.split(','))} events x 2 tables = "
          f"{2 * args.entities * len(args.events.split(','))} feeds + 1 iceberg_commit feed; {args.rows} cloud rows + "
          f"{args.rows + 1} on-prem rows per island; business date {args.date}; on-prem {args.onprem}; backend {args.backend}")
    print(f"  creates    : schema {CLOUD_SCHEMA} (2 tables, REAL AWS), 2 on-prem tables, 4 saved queries, 1 on-prem connection,")
    print("               2 feed templates + their feeds + runs, 1 iceberg feed, SFTP files, Kafka messages, Oracle rows -- all removed in finally")
    print(f"  the OG table: {ORA_TABLE} in the otg schema is CREATED if absent (owner's DDL) and kept; its rows for this tag are deleted")


# ── main ─────────────────────────────────────────────────────────────────

def last_weekday() -> dt.date:
    d = dt.date.today() - dt.timedelta(days=1)
    while d.weekday() >= 5:
        d -= dt.timedelta(days=1)
    return d


def main(argv=None):
    sweep, execute, rest = sweep_flags(argv if argv is not None else sys.argv[1:])
    ap = argparse.ArgumentParser()
    ap.add_argument("--entities", type=int, default=5)
    ap.add_argument("--events", default="EOD,ME5,SOD")
    ap.add_argument("--rows", type=int, default=3, help="cloud rows per island (on-prem gets rows+1)")
    ap.add_argument("--date", default=last_weekday().isoformat(),
                    help="the business date (a weekday: the feeds are daily; default = the last weekday)")
    ap.add_argument("--onprem", default="iceberg", choices=["iceberg", "hive"])
    ap.add_argument("--backend", default="native", choices=["native", "auto", "spark_k8s"])
    ap.add_argument("--cloud-conn", default="")
    ap.add_argument("--onprem-conn", default="", help="an existing connection to use as on-prem (default: create one on qs-trino-sb)")
    ap.add_argument("--hold", type=int, default=30)
    ap.add_argument("--plan", action="store_true")
    args = ap.parse_args(rest)
    if args.plan:
        plan(args)
        return 0

    events = [e.strip() for e in args.events.split(",") if e.strip()]
    date = dt.date.fromisoformat(args.date)
    hive = args.onprem == "hive"
    onprem_schema = f"hive.qs_{TAG}" if hive else "iceberg.qs"
    onprem_cli = sb_cli if hive else cloud_cli        # the on-prem iceberg tables live on the shared lake
    r = Rig()
    ledger = Ledger(lambda m, p, b=None: r.call(m, p, b))

    if sweep:
        rules = [Rule("feed template", r"TETB(_EXT)?_\d{6}", list_path="/api/feed-templates",
                      delete_path="/api/feed-templates/{id}?delete_members=true"),
                 Rule("feed", r"TETB_ICE_\d{6}", list_path="/api/feeds", delete_path="/api/feeds/{id}"),
                 Rule("saved query", r"tetb(_ext)?_(cloud|onprem)_\d{6}|tetb_ice_\d{6}_q", list_path="/api/queries",
                      delete_path="/api/queries/{id}"),
                 Rule("connection", r"sb-onprem-tetb-\d{6}", list_path="/api/connections",
                      delete_path="/api/connections/{id}")]
        rc = sweep_leftovers(lambda m, p, b=None: r.call(m, p, b), rules, execute=execute)
        for t in [x.strip().strip('"') for x in cloud_cli("SHOW SCHEMAS FROM iceberg_aws LIKE 'fins_%'").splitlines()]:
            if re.fullmatch(r"fins_\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} schema iceberg_aws.{t} (cascade)")
                if execute:
                    for tb in cloud_cli(f"SHOW TABLES FROM iceberg_aws.{t}").splitlines():
                        cloud_cli(f"DROP TABLE iceberg_aws.{t}.{tb.strip()}")
                    cloud_cli(f"DROP SCHEMA iceberg_aws.{t}")
        for t in [x.strip().strip('"') for x in cloud_cli("SHOW TABLES FROM iceberg.qs LIKE 'fact_tetb%'").splitlines()]:
            if re.fullmatch(r"fact_tetb(_ext)?_\d{6}", t):
                print(f"  {'drop' if execute else 'would drop'} table iceberg.qs.{t}")
                if execute:
                    cloud_cli(f"DROP TABLE iceberg.qs.{t}")
        try:
            for t in [x.strip().strip('"') for x in sb_cli("SHOW SCHEMAS FROM hive LIKE 'qs_%'").splitlines()]:
                if re.fullmatch(r"qs_\d{6}", t):
                    print(f"  {'drop' if execute else 'would drop'} hive schema {t}")
                    if execute:
                        for tb in sb_cli(f"SHOW TABLES FROM hive.{t}").splitlines():
                            sb_cli(f"DROP TABLE hive.{t}.{tb.strip()}")
                        sb_cli(f"DROP SCHEMA hive.{t}")
        except Exception as exc:  # noqa: BLE001 -- no hive catalog = nothing to sweep there
            print(f"  (hive catalog not swept: {str(exc)[:120]})")
        ora = next((x["id"] for x in connections(r) if x.get("name") == "oracle-otg"), None)
        if ora:
            print(f"  {'delete' if execute else 'would delete'} {ORA_TABLE} rows with CODE LIKE 'E______0___' / 'I______'")
            if execute:
                oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE REGEXP_LIKE(CODE, '^[EI][0-9]{{6}}')"], connection_id=ora)
        return rc

    # ── preflight ───────────────────────────────────────────────────────
    print(f"\n== preflight (tag {TAG}, {args.entities} x {events} x 2 tables, date {date}, on-prem {args.onprem}, backend {args.backend})")
    check("P0 qs-kafka is running", broker_running())
    if not broker_running():
        return 2
    healthy, secs = wait_until(broker_healthy, 120, 5)
    check(f"P0 the broker is healthy ({secs}s)", healthy)
    rc, out = rpk("topic", "create", TOPIC, "-p", "1", "-r", "1")
    check("P0 the owner's topic exists", rc == 0 or "already exists" in out or "ALREADY_EXISTS" in out, out[-120:])
    s, st = r.call("GET", "/api/admin/background-jobs/feed_kafka_arrivals/status")
    text = json.dumps(st) if isinstance(st, dict) else str(st)
    check("P1 the Kafka consumer is RUNNING with the owner's topic subscribed",
          s == 200 and '"running": true' in text and TOPIC in text, text[:300])
    s, v = r.call("GET", "/api/feed-arrival-sources")
    kinds = {k["kind"]: k for k in ((v or {}).get("kinds") or [])} if isinstance(v, dict) else {}
    check("P1 the vocabulary offers oracle_table, kafka and iceberg_commit, each with its producer UP",
          all(k in kinds and (kinds[k].get("producer_health") or {}).get("state") == "up"
              for k in ("oracle_table", "kafka", "iceberg_commit")),
          {k: (kinds.get(k) or {}).get("producer_health") for k in ("oracle_table", "kafka", "iceberg_commit")})
    s, st = r.call("GET", "/api/admin/background-jobs/feed_dependency_oracle_table_watch/status")
    text = json.dumps(st) if isinstance(st, dict) else str(st)
    check("P1 the Oracle-table watcher's status names QS_KAFKA_MESSAGE on oracle-otg",
          s == 200 and ORA_TABLE in text and "oracle-otg" in text, text[:400])
    for c in (SFTP["container"], SB_HOST, "oracle-db", "qs-trino"):
        check(f"P2 {c} is running", docker("inspect", "-f", "{{.State.Running}}", c)[1] == "true")
    host_key = sftp_host_key()
    items = connections(r)
    cloud_id, cloud_name = pick_cloud(r, args.cloud_conn)
    aws_id = next((x["id"] for x in items if x.get("name") == "aws-real"), None)
    ora_id = next((x["id"] for x in items if x.get("name") == "oracle-otg"), None)
    check(f"P3 connections: cloud {cloud_name} (id {cloud_id}), aws-real (id {aws_id}), oracle-otg (id {ora_id})",
          aws_id is not None and ora_id is not None)
    if aws_id is None or ora_id is None:
        return 2
    if hive:
        cats = sb_cli("SHOW CATALOGS")
        check("P4 qs-trino-sb has the hive catalog (starburst_like/make_hive_catalog.sh applied)", "hive" in cats.split(), cats)
        if "hive" not in cats.split():
            return 2
    state = ensure_oracle_table(ora_id)
    check(f"P5 the OG table {ORA_TABLE} is in the rig's Oracle ({state})", True)
    if args.onprem_conn:
        hit = next((x for x in items if str(x.get("id")) == args.onprem_conn or x.get("name") == args.onprem_conn), None)
        if not hit:
            raise SystemExit(f"--onprem-conn {args.onprem_conn!r}: no such connection")
        prem_id, prem_name = hit["id"], hit["name"]
    else:
        pw = os.environ.get("QS_SB_ANALYST_PW")
        if not pw:
            raise SystemExit("QS_SB_ANALYST_PW is not set: . ~/.qs_keys/starburst_like.env")
        catalog, schema = ("hive", f"qs_{TAG}") if hive else ("iceberg", "qs")
        s, b = r.call("POST", "/api/connections", {
            "name": f"sb-onprem-tetb-{TAG}", "connection_type": "starburst",
            "config": {"host": SB_HOST, "port": SB_PORT, "user": "qs_analyst", "auth_type": "basic",
                       "password": pw, "http_scheme": "https", "verify_ssl": False,
                       "catalog": catalog, "schema": schema}})
        if s not in (200, 201) or not (b or {}).get("id"):
            raise SystemExit(f"on-prem connection: {s} {str(b)[:300]}")
        prem_id, prem_name = b["id"], f"sb-onprem-tetb-{TAG}"
        ledger.add("connection", prem_name, path=f"/api/connections/{prem_id}")
    check(f"P6 on-prem connection {prem_name} (id {prem_id}) differs from the cloud one", prem_id != cloud_id)

    # ── the owner's SQL ─────────────────────────────────────────────────
    specs = {}
    for label, spec in TABLES.items():
        cloud_sql, prem_sql = load_queries(spec)
        c_aliases, c_types = parse_query(cloud_sql, spec["alias"])
        p_aliases, p_types = parse_query(prem_sql, spec["alias"])
        cloud_table = f"{CLOUD_SCHEMA}.{spec['table']}"
        prem_table = f"{onprem_schema}.{spec['table']}" if hive else f"{onprem_schema}.{spec['table']}_{TAG}"
        specs[label] = dict(spec, cloud_sql=cloud_sql.replace(spec["from_cloud"], cloud_table),
                            prem_sql=prem_sql.replace(spec["from_onprem"], prem_table),
                            c_aliases=c_aliases, c_types=c_types, p_aliases=p_aliases, p_types=p_types,
                            cloud_table=cloud_table, prem_table=prem_table)
        check(f"fixture {label}: the owner's cloud query projects {len(c_aliases)} columns, the on-prem {len(p_aliases)}; "
              f"the FROM is the only edit",
              len(c_aliases) > 50 and spec["from_cloud"] in cloud_sql and spec["from_onprem"] in prem_sql
              and specs[label]["cloud_sql"].count(cloud_table) == 1 and specs[label]["prem_sql"].count(prem_table) == 1)
    check(f"fixture tetb: both sides project the SAME {len(specs['tetb']['c_aliases'])} columns in the same order "
          f"(only the FROM differs); ext projects {len(specs['ext']['c_aliases'])} cloud / {len(specs['ext']['p_aliases'])} on-prem",
          len(specs["tetb"]["c_aliases"]) >= 450 and specs["tetb"]["c_aliases"] == specs["tetb"]["p_aliases"]
          and len(specs["ext"]["c_aliases"]) == 75 and len(specs["ext"]["p_aliases"]) == 73,
          (len(specs["tetb"]["c_aliases"]), len(specs["tetb"]["p_aliases"])))

    entities = [f"E{TAG}{i:04d}" for i in range(args.entities)]
    islands = [(e, ev) for e in entities for ev in events]
    ice_entity = f"I{TAG}"
    liar = islands[-1]                                     # its tetb ONPREM message lies about ROW_COUNT
    timings = {}
    feeds: dict = {}                                       # (label, entity, event) -> feed id
    ice_feed = None
    seq = itertools.count(1)

    def cloud_rows_for(spec, ent, ev, n):
        return [row_values("cloud", spec["c_types"], date, ent, ev, i) for i in range(n)]

    def prem_rows_for(spec, ent, ev, n):
        return [row_values("prem", spec["p_types"], date, ent, ev, i) for i in range(n)]

    try:
        # ── seed both sides ─────────────────────────────────────────────
        print(f"\n== seeding: cloud = REAL AWS ({CLOUD_SCHEMA}), on-prem = {onprem_schema} on qs-trino-sb")
        t0 = time.time()
        cloud_cli(f"CREATE SCHEMA {CLOUD_SCHEMA} WITH (location = 's3://{AWS_BUCKET}/iceberg/fins_{TAG}')")
        # the schema remover CASCADES (every table first, then the schema): a
        # crashed run must never leave tables on the REAL bucket (2026-10-11,
        # live: "Cannot drop non-empty schema" after a table drop had failed)
        ledger.add("aws schema", CLOUD_SCHEMA, remover=lambda: drop_schema_cascade(cloud_cli, CLOUD_SCHEMA))
        if hive:
            # NO location: the FILE metastore requires a managed table's
            # directory under ITS schema directory (hive.metastore.catalog.dir/
            # <schema>/<table>); a schema created with its own location made
            # every CREATE TABLE fail "Table directory must be s3://qs-data/
            # hive-metastore/qs_<tag>/fact_tetb" (live, 2026-10-11).  A real
            # Hive on-prem (an HMS) takes its own warehouse location the same
            # way -- the metastore owns managed-table directories.
            sb_cli(f"CREATE SCHEMA {onprem_schema}")
            ledger.add("hive schema", onprem_schema, remover=lambda: drop_schema_cascade(sb_cli, onprem_schema))
        other_event = {ev: events[(i + 1) % len(events)] for i, ev in enumerate(events)}
        for label, spec in specs.items():
            loc = f"s3://{AWS_BUCKET}/iceberg/fins_{TAG}/{spec['table']}"
            cloud_cli(ddl(spec["cloud_table"], spec["c_types"], hive=False, location=loc) + ";\n", stdin=True)
            spec["cloud_prefix"] = f"iceberg/fins_{TAG}/{spec['table']}/"
            onprem_cli(ddl(spec["prem_table"], spec["p_types"], hive=hive) + ";\n", stdin=True)
            ct, pt = spec["cloud_table"], spec["prem_table"]
            ledger.add("cloud table", ct, remover=lambda ct=ct: (bool(cloud_cli(f"DROP TABLE {ct}") is not None), "dropped"))
            ledger.add("on-prem table", pt, remover=lambda pt=pt: (bool(onprem_cli(f"DROP TABLE {pt}") is not None), "dropped"))
            c_rows, p_rows = [], []
            for ent, ev in islands:
                c_rows += cloud_rows_for(spec, ent, ev, args.rows)
                p_rows += prem_rows_for(spec, ent, ev, args.rows + 1)
                # decoys: same entity, OTHER event (cloud); same island, OTHER date (on-prem)
                # (an event NO island has: other_event[ev] is a real island of the same
                # entity, so the "decoy" landed inside it -- 4 rows where 3 were meant,
                # and "decoys absent" could not fail; live 2026-10-11)
                c_rows += cloud_rows_for(spec, ent, f"X{ev}", 1)
                p_rows += [row_values("prem", spec["p_types"], date - dt.timedelta(days=1), ent, ev, 901)]
            # the iceberg-trigger island: on-prem rows now, cloud rows at the trigger (G)
            if label == "tetb":
                p_rows += prem_rows_for(spec, ice_entity, "EOD", args.rows + 1)
            nc = insert_rows(cloud_cli, spec["cloud_table"], spec["c_types"], c_rows)
            np_ = insert_rows(onprem_cli, spec["prem_table"], spec["p_types"], p_rows)
            check(f"seeded {label}: {nc} cloud rows (AWS) + {np_} on-prem rows incl. decoys",
                  nc == len(c_rows) and np_ == len(p_rows))
        timings["seed_s"] = round(time.time() - t0, 1)

        def truth(spec, side, ent, ev):
            """The owner's SQL, tokens filled, on the side's own cluster -- rows
            as lists of text cells in the query's column order."""
            sql = (spec["cloud_sql"] if side == "cloud" else spec["prem_sql"])
            sql = sql.replace("{BUSINESSDATE}", date.isoformat()).replace("{SYSTEM_ENTITY}", ent).replace("{EventCode}", ev)
            out = (cloud_cli if side == "cloud" else sb_cli)(sql + "\n", stdin=True)
            return tsv_rows(out, len(spec["c_aliases"] if side == "cloud" else spec["p_aliases"]))

        truths = {}
        for label, spec in specs.items():
            for ent, ev in islands:
                truths[(label, ent, ev)] = (truth(spec, "cloud", ent, ev), truth(spec, "prem", ent, ev))
        check("truth: every island has rows cloud rows and rows+1 on-prem rows on each table (the two Trino CLIs)",
              all(len(c) == args.rows and len(p) == args.rows + 1 for c, p in truths.values()),
              {"islands": len(islands), "tables": len(specs),
               "off": [(k, len(c), len(p)) for k, (c, p) in truths.items()
                       if not (len(c) == args.rows and len(p) == args.rows + 1)][:6]})

        # ── the saved queries ───────────────────────────────────────────
        for label, spec in specs.items():
            s, q1 = r.call("POST", "/api/queries", {"name": f"{'tetb' if label == 'tetb' else 'tetb_ext'}_cloud_{TAG}",
                                                   "query_config": {"files": [], "raw_sql": spec["cloud_sql"], "connection_id": cloud_id}})
            s2, q2 = r.call("POST", "/api/queries", {"name": f"{'tetb' if label == 'tetb' else 'tetb_ext'}_onprem_{TAG}",
                                                    "query_config": {"files": [], "raw_sql": spec["prem_sql"], "connection_id": prem_id}})
            check(f"the owner's {label} queries are saved verbatim (FROM swapped)", s in (200, 201) and s2 in (200, 201), (s, s2))
            ledger.add("saved query", q1["name"], path=f"/api/queries/{q1['id']}")
            ledger.add("saved query", q2["name"], path=f"/api/queries/{q2['id']}")
            spec["q_cloud"], spec["q_prem"] = q1["id"], q2["id"]

        # ── A: two templates ────────────────────────────────────────────
        print(f"\n== A two templates -> {2 * len(islands)} feeds, two dependencies each, either road")
        both_roads = [{"kind": "kafka", "topic": TOPIC},
                      {"kind": "oracle_table", "connection_id": ora_id, "table": ORA_TABLE}]
        t0 = time.time()
        for label, spec in specs.items():
            prefix = "TETB" if label == "tetb" else "TETB_EXT"
            template = {
                "name": f"{prefix}_{TAG}",
                "description": f"owner case: {spec['table']} cloud (AWS) + on-prem ({args.onprem}) per entity x event",
                "parameters": ["SYSTEM_ENTITY", "EventCode"],
                "feed": {
                    "name": f"{prefix}_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}",
                    "display_name": f"{prefix} {{SYSTEM_ENTITY}} / {{EventCode}}",
                    "source_type": "saved_query", "source_id": spec["q_cloud"], "connection_id": cloud_id,
                    "secondary_connection_id": prem_id, "secondary_source_type": "saved_query",
                    "secondary_source_id": spec["q_prem"], "combine_mode": "union",
                    "output_format": "csv",
                    "output_filename_template": f"{prefix}_{TAG}_{{SYSTEM_ENTITY}}_{{EventCode}}_{{business_date:YYYYMMDD}}.csv",
                    "destination_type": "sftp",
                    "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                           "password": SFTP["password"], "remote_dir": SFTP["remote_dir"],
                                           "host_key_b64": host_key},
                    "schedule_declaration": {"kind": "daily"},
                    "execution_backend": args.backend,
                    "notify_on_failure": False,
                },
                "dependencies": [
                    {"dependency_type": "KAFKA",
                     "dependency_key": f"{spec['data_source']}_{{SYSTEM_ENTITY}}_{{EventCode}}_CLOUD",
                     "description": "the cloud load's COMPLETE message (either road); certifies the primary side",
                     "arrival_sources": both_roads, "require_mode": "any", "certifies_side": "primary"},
                    {"dependency_type": "KAFKA",
                     "dependency_key": f"{spec['data_source']}_{{SYSTEM_ENTITY}}_{{EventCode}}_ONPREM",
                     "description": "the on-prem load's COMPLETE message (either road); certifies the secondary side",
                     "arrival_sources": both_roads, "require_mode": "any", "certifies_side": "secondary"},
                ],
                "matrix": [{"SYSTEM_ENTITY": e, "EventCode": v} for e, v in islands],
            }
            s, body = r.call("POST", "/api/feed-templates", template)
            s, rep, mode = await_template_apply(r, s, body)
            counts = rep.get("counts") or {}
            check(f"A1 {prefix}: POST /api/feed-templates created {len(islands)} feeds ({mode}): {counts}",
                  s == 201 and counts.get("created") == len(islands) and not counts.get("refused") and not counts.get("conflicts"),
                  {"status": s, "refused": (rep.get("refused") or [])[:3], "body": str(body)[:300] if s != 201 else ""})
            if s != 201:
                raise SystemExit(f"template {prefix}: {s} {str(body)[:400]} {str(rep)[:400]}")
            tid = body["template"]["id"]
            ledger.add("feed template", template["name"], path=f"/api/feed-templates/{tid}?delete_members=true")
            for c in rep.get("created") or []:
                feeds[(label, c["values"]["SYSTEM_ENTITY"], c["values"]["EventCode"])] = c["feed_id"]
            spec["template_id"] = tid
        timings["bulk_create_s"] = round(time.time() - t0, 1)
        s, body = r.call("POST", f"/api/feed-templates/{specs['tetb']['template_id']}/apply", {"matrix": [{"SYSTEM_ENTITY": e, "EventCode": v} for e, v in islands]})
        s, rep2, _mode2 = await_template_apply(r, s, body)
        c2 = rep2.get("counts") or {}
        check(f"A2 re-applying the TETB matrix creates nothing: {c2}", s == 200 and c2.get("unchanged") == len(islands) and c2.get("created") == 0)
        fid0 = feeds[("tetb", *islands[0])]
        _, deps = r.call("GET", f"/api/feeds/{fid0}/dependencies")
        ditems = sorted((deps or {}).get("items") or [], key=lambda d: d["dependency_key"])
        check("A3 a member declares CLOUD (certifies primary) + ONPREM (certifies secondary), each met by kafka OR oracle_table",
              [d["dependency_key"] for d in ditems] == [f"finance_sl_balance_{islands[0][0]}_{islands[0][1]}_CLOUD",
                                                        f"finance_sl_balance_{islands[0][0]}_{islands[0][1]}_ONPREM"]
              and [d["certifies_side"] for d in ditems] == ["primary", "secondary"]
              and all(d["require_mode"] == "any" and [x["kind"] for x in d["arrival_sources"]] == ["kafka", "oracle_table"]
                      for d in ditems), ditems)

        # ── G (declare): the iceberg_commit feed ────────────────────────
        print("\n== G (declare) a feed held on an iceberg_commit of the REAL AWS table")
        spec = specs["tetb"]
        s, b = r.call("POST", f"/api/connections/{aws_id}/tables", {
            "name": f"fact_tetb_{TAG}", "s3_prefix": spec["cloud_prefix"], "format": "iceberg",
            "description": f"tetb_real_e2e_proof {TAG}", "partition_columns": ["business_close_date", "code", "businessevent"]})
        check(f"G0 the cloud table is registered on aws-real as fact_tetb_{TAG} ({s})", s in (200, 201), str(b)[:300])
        ledger.add("registered table", f"fact_tetb_{TAG}", path=f"/api/connections/{aws_id}/tables/fact_tetb_{TAG}")
        s, qi = r.call("POST", "/api/queries", {"name": f"tetb_ice_{TAG}_q", "query_config": {
            "files": [], "raw_sql": spec["cloud_sql"], "connection_id": cloud_id}})
        ledger.add("saved query", qi["name"], path=f"/api/queries/{qi['id']}")
        s, fb = r.call("POST", "/api/feeds", {
            "name": f"TETB_ICE_{TAG}", "source_type": "saved_query", "source_id": qi["id"], "connection_id": cloud_id,
            "secondary_connection_id": prem_id, "secondary_source_type": "saved_query", "secondary_source_id": spec["q_prem"],
            "combine_mode": "union", "output_format": "csv",
            "output_filename_template": f"TETB_ICE_{TAG}_{{business_date:YYYYMMDD}}.csv",
            "destination_type": "sftp",
            "destination_config": {"host": SFTP["host"], "port": SFTP["port"], "username": SFTP["username"],
                                   "password": SFTP["password"], "remote_dir": SFTP["remote_dir"], "host_key_b64": host_key},
            "schedule_declaration": {"kind": "daily"}, "execution_backend": args.backend, "notify_on_failure": False,
            "query_params": {"SYSTEM_ENTITY": ice_entity, "EventCode": "EOD"}})
        check(f"G0 the iceberg feed TETB_ICE_{TAG} is created ({s})", s == 200 and (fb or {}).get("id"), str(fb)[:300])
        ice_feed = fb["id"]
        ledger.add("feed", f"TETB_ICE_{TAG}", path=f"/api/feeds/{ice_feed}")
        _, types = r.call("GET", "/api/feed-dependency-types")
        titems = types if isinstance(types, list) else (types or {}).get("items") or []
        ice_tid = next((t["id"] for t in titems if str(t.get("dependency_type")).upper() == "ICEBERG_TABLE"), titems[0]["id"])
        s, b = r.call("PUT", f"/api/feeds/{ice_feed}/dependencies", {"dependencies": [{
            "dependency_type_id": ice_tid, "dependency_key": f"fact_tetb_{TAG}_commit",
            "description": "the cloud table committed data for the date",
            # the PARTITION, as {TOKEN}s the feed's query_params render at
            # evaluation (a template member would carry the literals): with
            # 4,000 per-(entity, event) feeds on ONE fact_tetb, "a commit
            # contains the date" was true for all of them the moment the first
            # island loaded (live, run 1747, 2026-10-11)
            "arrival_sources": [{"kind": "iceberg_commit", "connection_id": aws_id, "table": f"fact_tetb_{TAG}",
                                 "date_column": "business_close_date",
                                 "partition_values": {"code": "{SYSTEM_ENTITY}", "businessevent": "{EventCode}"}}]}]})
        check(f"G0 its dependency is iceberg_commit on fact_tetb_{TAG}.business_close_date FOR THE PARTITION "
              f"code={{SYSTEM_ENTITY}}, businessevent={{EventCode}} ({s})", s == 200, str(b)[:300])
        _, gd = r.call("GET", f"/api/feeds/{ice_feed}/dependencies")
        check("G0 ...stored with the partition tokens (lower-cased columns)",
              ((gd or {}).get("items") or [{}])[0].get("arrival_sources", [{}])[0].get("partition_values")
              == {"code": "{SYSTEM_ENTITY}", "businessevent": "{EventCode}"}, gd)

        # ── B: the hold ─────────────────────────────────────────────────
        n = len(feeds)
        print(f"\n== B {n} runs (+ the iceberg feed's) are born WAIT")
        t0 = time.time()
        ok_runs = 0
        all_fids = list(feeds.values()) + [ice_feed]
        for fid in all_fids:
            s, b = r.call("POST", f"/api/feeds/{fid}/backfill", {
                "start_date": date.isoformat(), "end_date": date.isoformat(), "deliver": True,
                "reason": "tetb real e2e proof on the Docker rig, signed off by rig_admin (test data only)"})
            created = ((b or {}).get("summary") or {}).get("created") if isinstance(b, dict) else None
            ok_runs += int(s == 200 and created == 1)
            if s != 200 or created != 1:
                print(f"   backfill feed {fid}: {s} {str(b)[:240]}")
        timings["runs_created_s"] = round(time.time() - t0, 1)
        fids = ",".join(str(f) for f in all_fids)

        def waiting():
            return int(psql(f"select count(*) from feed_runs where feed_config_id in ({fids}) and business_date = '{date}' "
                            f"and action_decision = 'WAIT' and status = 'pending'") or 0)
        check(f"B1 {ok_runs}/{n + 1} backfill runs created ({timings['runs_created_s']}s), {waiting()} held at WAIT",
              ok_runs == n + 1 and waiting() == n + 1)
        time.sleep(args.hold)
        ran = int(psql(f"select count(*) from feed_executions where feed_config_id in ({fids})") or 0)
        check(f"B2 after {args.hold}s nothing ran: {waiting()} still WAIT, {ran} executions", waiting() == n + 1 and ran == 0)
        row0, secs_b3 = wait_until(lambda: (lambda x: x if x and "_CLOUD" in (x.get("reason") or "")
                                            and "_ONPREM" in (x.get("reason") or "") else None)(
            r.run_row(fid0, date.isoformat())), 120, 5)
        check(f"B3 the hold names BOTH dependencies ({secs_b3}s)", bool(row0), row0 or r.run_row(fid0, date.isoformat()))

        # ── the roads ───────────────────────────────────────────────────
        kafka_islands = islands[: (len(islands) + 1) // 2]
        oracle_islands = islands[(len(islands) + 1) // 2:]
        road_of = {isl: "kafka" for isl in kafka_islands}
        road_of.update({isl: "oracle_table" for isl in oracle_islands})

        def send(msgs_by_road):
            sent = {"kafka": 0, "oracle_table": 0}
            if msgs_by_road["kafka"]:
                sent["kafka"] = produce_kafka(msgs_by_road["kafka"])
            if msgs_by_road["oracle_table"]:
                sent["oracle_table"] = ora_rows(ora_id, msgs_by_road["oracle_table"])
            return sent

        def messages_for(side: str, state: str, lie_on=None):
            out = {"kafka": [], "oracle_table": []}
            for label, spec in specs.items():
                for isl in islands:
                    ent, ev = isl
                    c, p = truths[(label, ent, ev)]
                    count = len(c) if side == "cloud" else len(p)
                    if lie_on and (label, isl) == lie_on:
                        count += 7
                    out[road_of[isl]].append(message(spec["data_source"], ent, ev, date, side == "cloud",
                                                     state, count, next(seq)))
            return out

        # ── C: one side alone ───────────────────────────────────────────
        print(f"\n== C the CLOUD side's COMPLETE alone ({len(kafka_islands)} islands by Kafka, {len(oracle_islands)} by an Oracle row) releases nothing")
        sent = send(messages_for("cloud", "COMPLETE"))
        check(f"C0 sent: {sent['kafka']} Kafka messages, {sent['oracle_table']} Oracle rows", sum(sent.values()) == 2 * len(islands))
        cloud_dep0 = f"finance_sl_balance_{islands[0][0]}_{islands[0][1]}_CLOUD"
        cloud_depN = f"finance_sl_balance_{islands[-1][0]}_{islands[-1][1]}_CLOUD"
        arr, secs = wait_until(lambda: (lambda a, b: (a, b) if a and b else None)(
            int(psql(f"select count(*) from dependency_events where dependency_name = '{cloud_dep0}' and business_date = '{date}'") or 0),
            int(psql(f"select count(*) from dependency_events where dependency_name = '{cloud_depN}' and business_date = '{date}'") or 0)), 180, 5)
        check(f"C1 the CLOUD arrivals are on the ledger from BOTH roads ({secs}s)", bool(arr), arr)
        src = psql(f"select source, count(*) from dependency_events where business_date = '{date}' and dependency_name like 'finance_sl_balance%E{TAG}%_CLOUD' group by 1 order by 1")
        check(f"C1 ...split between source kafka and source oracle_table as sent: {src.replace(chr(10), ' / ')}",
              # a road is expected only when islands were SENT by it (one
              # island at --entities 1 --events X goes by Kafka alone)
              (not kafka_islands or f"kafka|{2 * len(kafka_islands)}" in src)
              and (not oracle_islands or f"oracle_table|{2 * len(oracle_islands)}" in src)
              and ("oracle_table" in src) == bool(oracle_islands))
        # the poller ticks every 60 s: wait one full tick before judging the hold
        time.sleep(75)
        check(f"C2 still held: {waiting()} WAIT (the on-prem side has not arrived)", waiting() == n + 1)
        row0 = r.run_row(fid0, date.isoformat())
        check("C3 the hold now names only the ONPREM dependency",
              row0 and "_ONPREM" in (row0.get("reason") or "") and "_CLOUD" not in (row0.get("reason") or "").split("waiting on")[-1], row0)

        # ── D: a non-COMPLETE message does not count ────────────────────
        print("\n== D the ON-PREM side's IN_PROGRESS message does not count")
        sent = send(messages_for("onprem", "IN_PROGRESS"))
        filt, secs = wait_until(lambda: (lambda k: k if k >= sent["kafka"] + sent["oracle_table"] else None)(
            int(psql(f"select count(*) from kafka_messages where resolution = 'filtered' and payload like '%{TAG}%'") or 0)), 180, 5)
        check(f"D1 {filt} messages/rows are 'filtered' on the two roads ({secs}s), no alert, no arrival",
              filt == sent["kafka"] + sent["oracle_table"]
              and int(psql(f"select count(*) from dependency_events where business_date = '{date}' and dependency_name like 'finance_sl_balance%E{TAG}%_ONPREM'") or 0) == 0)
        check(f"D2 still held: {waiting()} WAIT", waiting() == n + 1)

        # ── E: both COMPLETE -> release; one liar fails ─────────────────
        print(f"\n== E the ON-PREM COMPLETE messages release {n} runs (one lies about ROW_COUNT: TETB {liar})")
        t_release = time.time()
        sent = send(messages_for("onprem", "COMPLETE", lie_on=("tetb", liar)))
        check(f"E0 sent: {sent['kafka']} Kafka messages, {sent['oracle_table']} Oracle rows", sum(sent.values()) == 2 * len(islands))
        member_fids = ",".join(str(f) for f in feeds.values())

        def released():
            v = int(psql(f"select count(*) from feed_runs where feed_config_id in ({member_fids}) and business_date = '{date}' "
                         f"and action_decision = 'RUN'") or 0)
            return v if v >= n else None
        rel, secs = wait_until(released, 300 + n, 5)
        timings["release_all_s"] = secs
        check(f"E1 the poller released all {n} member runs ({secs}s after the send); the iceberg feed stays held", rel == n
              and r.run_row(ice_feed, date.isoformat())["decision"] == "WAIT",
              psql(f"select action_decision, count(*) from feed_runs where feed_config_id in ({fids}) group by 1"))

        def done():
            v = int(psql(f"select count(*) from feed_runs where feed_config_id in ({member_fids}) and business_date = '{date}' "
                         f"and status in ('completed','failed','cancelled')") or 0)
            return v if v >= n else None
        fin, secs = wait_until(done, 900 + n * 20, 10)
        timings["all_finished_s"] = round(time.time() - t_release)
        completed = int(psql(f"select count(*) from feed_runs where feed_config_id in ({member_fids}) and business_date = '{date}' and status = 'completed'") or 0)
        failed = int(psql(f"select count(*) from feed_runs where feed_config_id in ({member_fids}) and business_date = '{date}' and status = 'failed'") or 0)
        check(f"E2 all {n} finished ({timings['all_finished_s']}s; {round(n / max(1, timings['all_finished_s']) * 60, 1)} feeds/min): "
              f"{completed} completed, {failed} failed (the liar)", fin == n and completed == n - 1 and failed == 1,
              psql(f"select status, count(*) from feed_runs where feed_config_id in ({member_fids}) group by 1"))
        liar_fid = feeds[("tetb", *liar)]
        _, ex = r.call("GET", f"/api/feeds/{liar_fid}/executions")
        exs = ex if isinstance(ex, list) else (ex or {}).get("items") or []
        e_liar = next((x for x in exs if x.get("status") == "failed"), {})
        c_truth, p_truth = truths[("tetb", *liar)]
        want = f"secondary side: read {len(p_truth)} row(s) but finance_sl_balance_{liar[0]}_{liar[1]}_ONPREM reported {len(p_truth) + 7} (difference -7)"
        rr = (e_liar.get("stage_timings") or {}).get("reported_rows_certification") or {}
        check(f"E3 the liar's run FAILED at certify_reported_rows with the numbers: {want!r}",
              want in (e_liar.get("error_message") or "") and e_liar.get("failed_stage") == "certify_reported_rows"
              and rr.get("verdict") == "mismatch" and (rr.get("sides") or {}).get("primary", {}).get("verdict") == "certified",
              {"error": (e_liar.get("error_message") or "")[:300], "stage": e_liar.get("failed_stage"), "rr": rr})
        check("E3 ...and nothing was delivered for it",
              sftp_ls(f"TETB_{TAG}_{liar[0]}_{liar[1]}_{date.strftime('%Y%m%d')}.csv") is None and not e_liar.get("destination_path"))

        # ── F: every file ───────────────────────────────────────────────
        print("\n== F every delivered file == cloud island UNION ALL on-prem island (full rows vs the two Trino CLIs)")
        compared, bad = 0, []
        for key, fid in feeds.items():
            label, ent, ev = key
            if key == ("tetb", *liar):
                continue
            spec = specs[label]
            prefix = "TETB" if label == "tetb" else "TETB_EXT"
            _, ex = r.call("GET", f"/api/feeds/{fid}/executions")
            exs = ex if isinstance(ex, list) else (ex or {}).get("items") or []
            e = next((x for x in exs if x.get("status") == "completed"), None)
            if not e:
                bad.append((key, "no completed execution"))
                continue
            fname = f"{prefix}_{TAG}_{ent}_{ev}_{date.strftime('%Y%m%d')}.csv"
            if sftp_ls(fname) is None:
                bad.append((key, f"{fname} not on the SFTP server"))
                continue
            reader = csv.reader(io.StringIO(sftp_read(fname)))
            header = next(reader)
            rows = list(reader)
            hdr_up = [h.upper() for h in header]
            if hdr_up != [a.upper() for a in spec["c_aliases"]]:
                bad.append((key, f"header differs from the cloud query's order ({len(hdr_up)} cols): {hdr_up[:4]}..."))
                continue
            c_truth, p_truth = truths[key]
            c_idx = {a.upper(): i for i, a in enumerate(spec["c_aliases"])}
            p_idx = {a.upper(): i for i, a in enumerate(spec["p_aliases"])}
            want = collections.Counter()
            for trow in c_truth:
                want[tuple(trow[c_idx[h]] for h in hdr_up)] += 1
            for trow in p_truth:
                want[tuple(trow[p_idx[h]] if h in p_idx else "" for h in hdr_up)] += 1
            got = collections.Counter(tuple(row) for row in rows)
            if got != want:
                diff_g, diff_w = list((got - want).elements())[:1], list((want - got).elements())[:1]
                bad.append((key, f"rows differ: file {sum(got.values())} vs truth {sum(want.values())}; "
                                 f"file-only {[(c[:3]) for c in diff_g]} truth-only {[(c[:3]) for c in diff_w]}"))
                continue
            sdr = hdr_up.index("SOURCE_DATA_ROW")
            if not all(row[sdr].split(":")[1:3] == [ent, ev] for row in rows):
                bad.append((key, "a row from another island or date is in the file"))
                continue
            fm = e.get("files_metadata") or {}
            xs = fm.get("cross_source") or {}
            if not (xs.get("primary_rows") == len(c_truth) and xs.get("secondary_rows") == len(p_truth)
                    and xs.get("expected_rows") == len(rows) == len(c_truth) + len(p_truth)):
                bad.append((key, f"files_metadata.cross_source {xs} vs {len(rows)} rows"))
                continue
            cert = json.dumps(fm.get("completeness_certificate") or {})
            m = re.search(r'"source_rows":\s*(\d+).*?"dest_rows":\s*(\d+)', cert)
            if not m or int(m.group(1)) != len(rows) or int(m.group(2)) != len(rows):
                bad.append((key, f"certificate does not reconcile {len(rows)} rows: {cert[:200]}"))
                continue
            rr = (e.get("stage_timings") or {}).get("reported_rows_certification") or {}
            sides = rr.get("sides") or {}
            if not (rr.get("verdict") == "certified"
                    and sides.get("primary", {}).get("reported_rows") == sides.get("primary", {}).get("actual_rows") == len(c_truth)
                    and sides.get("secondary", {}).get("reported_rows") == sides.get("secondary", {}).get("actual_rows") == len(p_truth)):
                bad.append((key, f"reported-rows certification {rr or 'ABSENT (an image that predates it?)'}"))
                continue
            compared += len(rows)
        check(f"F1 {n - 1 - len(bad)}/{n - 1} files: header = the cloud query's columns in its order; rows == cloud UNION ALL on-prem "
              f"(full-row multiset vs the two CLIs); one island per side; cross_source primary+secondary == expected == delivered; "
              f"certificate reconciles; reported-rows certification CERTIFIED per side (reported == actual)",
              not bad and compared > 0, bad[:5])
        check(f"F2 the compared row count is NON-ZERO ({compared} rows across {n - 1} files)", compared > 0)

        # ── G: the iceberg_commit trigger ───────────────────────────────
        print(f"\n== G the iceberg_commit feed: held, then released by the COMMIT of its island's cloud rows")
        row_i = r.run_row(ice_feed, date.isoformat())
        # every OTHER island's rows for this date have been in the table since the
        # seed, and the member runs' commits happened in E: the hold must have
        # survived all of them (defect 1) and must name THIS island's partition
        check(f"G1 held through every other island's commit, and the hold names the partition code={ice_entity}, businessevent=EOD",
              bool(row_i) and row_i["decision"] == "WAIT" and "iceberg" in (row_i.get("reason") or "").lower()
              and f"code={ice_entity}" in (row_i.get("reason") or ""), row_i)
        check("G1 ...no arrival was recorded for it before its own commit",
              int(psql(f"select count(*) from dependency_events where dependency_name = 'fact_tetb_{TAG}_commit'") or 0) == 0)
        t0 = time.time()
        spec = specs["tetb"]
        nc = insert_rows(cloud_cli, spec["cloud_table"], spec["c_types"], cloud_rows_for(spec, ice_entity, "EOD", args.rows))
        snap = cloud_cli(f'select snapshot_id from {CLOUD_SCHEMA}."fact_tetb$snapshots" order by committed_at desc limit 1').strip()
        check(f"G2 committed {nc} cloud rows for {ice_entity}/EOD: snapshot {snap}", nc == args.rows)
        rel, secs = wait_until(lambda: (lambda x: x if x and x["decision"] == "RUN" else None)(r.run_row(ice_feed, date.isoformat())), 900, 5)
        timings["iceberg_release_s"] = secs
        check(f"G3 the snapshot listener recorded the arrival and the poller released it ({secs}s after the commit)", bool(rel),
              {"row": r.run_row(ice_feed, date.isoformat()),
               "arrivals": psql(f"select source, message_identity from dependency_events where dependency_name = 'fact_tetb_{TAG}_commit'")})
        done_i, secs = wait_until(lambda: (lambda x: x if x and x["status"] in ("completed", "failed") else None)(
            r.run_row(ice_feed, date.isoformat())), 600, 5)
        ice_c = truth(spec, "cloud", ice_entity, "EOD")
        ice_p = truth(spec, "prem", ice_entity, "EOD")
        fname = f"TETB_ICE_{TAG}_{date.strftime('%Y%m%d')}.csv"
        body = sftp_read(fname) if sftp_ls(fname) is not None else ""
        nrows = max(0, len(body.splitlines()) - 1)
        check(f"G4 it ran and delivered ({round(time.time() - t0)}s from the commit): {nrows} rows == {len(ice_c)} cloud + {len(ice_p)} on-prem",
              bool(done_i) and done_i["status"] == "completed" and nrows == len(ice_c) + len(ice_p) > 0, done_i)
        # 2026-10-12 (the owner: "why doesn't iceberg say which table, COB,
        # business event, system entity"): the Iceberg monitor's record of
        # the commit names the TABLE, the PARTITION and the data it saw there
        s_, mon = r.call("GET", "/api/admin/feeds/iceberg-commits?days=1")
        insp = [i for t in (mon or {}).get("tables") or [] for i in t.get("inspections") or []
                if i.get("dependency_name") == f"fact_tetb_{TAG}_commit" and i.get("status") == "proved"]
        mine = insp[0] if insp else {}
        check(f"G5 the Iceberg monitor names the table, the partition (code / business event) and the data it saw",
              mine.get("table_name") == f"fact_tetb_{TAG}"
              and mine.get("partition_values") == {"code": ice_entity, "businessevent": "EOD"}
              and date.isoformat() in (mine.get("dates_proved") or [])
              and (mine.get("files_matched") or 0) >= 1 and mine.get("rows_matched") == len(ice_c),
              {k: mine.get(k) for k in ("table_name", "partition_values", "dates_proved", "files_matched", "rows_matched")})

        # ── H: the ledger ───────────────────────────────────────────────
        print("\n== H the ledger")
        rows_h = psql(f"select source, count(*), count(reported_rows) from dependency_events where business_date = '{date}' "
                      f"and dependency_name like 'finance_sl_balance%E{TAG}%' group by 1 order by 1")
        check(f"H1 every member arrival carries reported_rows; sources split as sent: {rows_h.replace(chr(10), ' / ')}",
              (not kafka_islands or f"kafka|{4 * len(kafka_islands)}|{4 * len(kafka_islands)}" in rows_h)
              and (not oracle_islands or f"oracle_table|{4 * len(oracle_islands)}|{4 * len(oracle_islands)}" in rows_h)
              and ("oracle_table" in rows_h) == bool(oracle_islands))
        unm = int(psql(f"select count(*) from kafka_messages where resolution = 'unmatched' and payload like '%{TAG}%'") or 0)
        unr = int(psql(f"select count(*) from kafka_messages where resolution = 'unresolvable' and payload like '%{TAG}%'") or 0)
        check(f"H2 no message of this run was unmatched ({unm}) or unresolvable ({unr})", unm == 0 and unr == 0)

        print("\n== timings", json.dumps(timings))
    finally:
        print("\n== cleanup")
        for key, fid in feeds.items():
            label, ent, ev = key
            prefix = "TETB" if label == "tetb" else "TETB_EXT"
            docker("exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/{prefix}_{TAG}_{ent}_{ev}_{date.strftime('%Y%m%d')}.csv")
        docker("exec", SFTP["container"], "rm", "-f", f"{SFTP['home']}/TETB_ICE_{TAG}_{date.strftime('%Y%m%d')}.csv")
        try:
            psql(f"delete from kafka_messages where payload like '%{TAG}%'")
            psql(f"delete from dependency_events where dependency_name like 'finance_sl_balance%{TAG}%' or dependency_name = 'fact_tetb_{TAG}_commit'")
            psql(f"delete from feed_regeneration_decisions where dependency_name like 'finance_sl_balance%{TAG}%'")
            psql(f"delete from iceberg_commit_inspections where dependency_name = 'fact_tetb_{TAG}_commit'")
            psql(f"delete from system_settings where key like 'feed_oracle_table_source.watermark.%' and false")
        except Exception as exc:  # noqa: BLE001
            print("   ledger cleanup FAILED:", exc)
        try:
            oracle_admin([f"DELETE FROM {ORA_TABLE} WHERE CODE LIKE 'E{TAG}%' OR CODE = '{ice_entity}'"], connection_id=ora_id)
        except Exception as exc:  # noqa: BLE001
            print("   oracle cleanup FAILED:", exc)
        removed, failures = ledger.cleanup()

    print(f"\n{sum(res)}/{len(res)} checks passed")
    return 0 if all(res) and not failures else 1


if __name__ == "__main__":
    sys.exit(main())
