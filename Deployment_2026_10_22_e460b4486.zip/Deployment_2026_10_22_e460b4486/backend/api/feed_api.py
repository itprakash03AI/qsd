"""Feed File Generation API — CRUD, execution, scheduling, webhooks (Phase 76)."""
import asyncio
import hashlib
import hmac
import logging
import os
import uuid
from contextvars import ContextVar
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator

from api.deps import get_current_user, require_admin, require_admin_read
from api.strict_request import StrictRequestModel
from core.db_async import adb
from core.where_clause_mapping import WhereClauseMapping

logger = logging.getLogger(__name__)
router = APIRouter(tags=["feeds"])

# Module-level dependencies
_db_manager = None
_auth_cfg = None
_broadcast_fn = None


def set_feed_dependencies(db_manager, auth_cfg, broadcast_fn=None):
    global _db_manager, _auth_cfg, _broadcast_fn
    _db_manager = db_manager
    _auth_cfg = auth_cfg
    _broadcast_fn = broadcast_fn
    # Feed identity (2026-09-02, BRD §14.3 / D5): the live DB may already
    # hold duplicate or non-conforming names from before the uniqueness
    # gate existed.  REPORT them at wiring time (WARNING log), never refuse
    # to start on them and never rewrite them — existing feeds keep
    # working.  Guarded: a stub/mock db (tests) or a DB error must not
    # break wiring; the report method itself is also non-raising.
    try:
        db_manager.report_feed_identity_issues()
    except Exception:
        logger.debug("feed identity startup report unavailable", exc_info=True)


# ── A batch of saves shares ONE snapshot of the estate (2026-10-10) ─────────
#
# ``_refuse_filename_collision`` (FR-ART-10) and ``_refuse_dependency_cycle``
# (FR-DEP-22) each need "every feed" to judge one save.  For a hand-authored
# feed that is one listing per save; for a feed TEMPLATE applying a 4,000-row
# matrix through create_feed it was 4,000 listings (and 4,000 x 4,000 mapping
# queries), i.e. quadratic -- 0.56 s/feed at N=50, 0.98 s/feed at N=400, ~3 h
# at 4,000, found live.  The apply sets this ContextVar to a
# ``core.feed.authoring_index.AuthoringIndex`` for the duration of its
# matrix; the checks read it when present and list the database when not,
# so the single-feed routes keep their exact behaviour and messages.  The
# routes tell the index what they COMMITTED (``_note_authored_feed`` /
# ``_note_dependency_keys``) so a collision INSIDE the batch -- member 2
# against member 1, saved a moment ago -- is still refused, naming member 1.
_authoring_index: ContextVar = ContextVar("feed_authoring_index", default=None)


def _note_authored_feed(row) -> None:
    """A feed row as committed (create / update / clone): the batch
    snapshot, if one is in force, compares the next save against it."""
    idx = _authoring_index.get()
    if idx is not None and row:
        try:
            idx.upsert_feed(row)
        except Exception:  # noqa: BLE001 -- the index is an accelerator, never a gate
            logger.warning("[feed_api] authoring index could not take feed %s",
                           (row or {}).get("id"), exc_info=True)


def _note_dependency_rows(etl_id: int, rows) -> None:
    """The ACTIVE mapping rows now stored under ``etl_id`` (as the
    dependency route just wrote them)."""
    idx = _authoring_index.get()
    if idx is not None:
        try:
            idx.set_dependency_rows(int(etl_id), rows)
        except Exception:  # noqa: BLE001
            logger.warning("[feed_api] authoring index could not take the "
                           "dependency rows of etl_id %s", etl_id, exc_info=True)


def _authoring_snapshot():
    """The batch snapshot in force, else one loaded now (two queries) --
    for the sync helpers that run off the loop under ``adb``."""
    idx = _authoring_index.get()
    if idx is None:
        from core.feed.authoring_index import AuthoringIndex
        idx = AuthoringIndex.load(_db_manager)
    return idx


# ── Authorization + secret masking (Phase 130 hotfix — wire the feed
#    permission gates that were only ever applied to the rerun path) ──────────

def _auth_on() -> bool:
    """True when authentication is enabled.  When auth is 'none' every feed
    authz check is a NO-OP (allow) so no-auth deployments are never locked
    out — the same posture the connections/reports RLS uses."""
    try:
        return bool(_auth_cfg) and getattr(_auth_cfg, "type", "none") != "none"
    except Exception:
        return False


# destination_config secret keys — masked in list/get responses so a user who
# can read a feed can NOT read its delivery credentials.  Matched EITHER as an
# exact key OR by substring (so ``session_token`` / ``aws_session_token`` /
# ``x_api_secret`` etc. are caught without enumerating every vendor variant).
# The secret-key rule lives in core/secrets_at_rest.py (2026-10-13): the SAME
# rule masks a value on screen and encrypts it at rest.
from core.secrets_at_rest import SECRET_KEYS as _FEED_SECRET_KEYS          # noqa: E402
from core.secrets_at_rest import SECRET_SUBSTR as _FEED_SECRET_SUBSTR      # noqa: E402,F401


def _is_secret_key(k) -> bool:
    # ONE rule for "is this a secret": masked here, ENCRYPTED at rest by the
    # same function (core/secrets_at_rest.py, 2026-10-13)
    from core.secrets_at_rest import is_secret_key
    return is_secret_key(k)


def _mask_secret_tree(obj):
    """Recursively mask secret VALUES in a dict/list tree, returning a masked
    COPY (never mutates the input).  Non-empty values under a secret-looking
    key become '***'; nested dicts/lists (e.g. destination_config.credentials.
    password) are walked too."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if _is_secret_key(k) and v not in (None, "", {}, []):
                out[k] = "***"
            else:
                out[k] = _mask_secret_tree(v)
        return out
    if isinstance(obj, list):
        return [_mask_secret_tree(x) for x in obj]
    return obj


def _mask_feed_secrets(feed: Optional[dict]) -> Optional[dict]:
    """Return a shallow copy of a feed dict with secret VALUES in
    destination_config / backend_config masked to '***' (recursively).
    Non-dict / no-secret inputs pass through unchanged (same object)."""
    if not isinstance(feed, dict):
        return feed
    out = None
    # ``delivery_chain`` (BRD §11/§14.2) rides along: each hop's
    # ``config`` carries the same credential class as destination_config
    # (an SFTP hop has a password), and _mask_secret_tree already walks
    # lists.  PUT round-trips are restored by _unmask_delivery_chain.
    for field in ("destination_config", "backend_config", "delivery_chain"):
        sub = feed.get(field)
        if isinstance(sub, (dict, list)) and sub:
            masked = _mask_secret_tree(sub)
            if masked != sub:
                if out is None:
                    out = dict(feed)
                out[field] = masked
    return out if out is not None else feed


def _unmask_secret_tree(submitted, stored):
    """SECURITY AUDIT 2026-08-03 (S4 companion): replace '***' placeholders in
    a submitted config tree with the stored real values at the same path.

    GET/list responses mask delivery credentials, so a client that round-trips
    a feed config back through PUT would otherwise STORE the literal '***' and
    destroy the real credential (the exact failure mode the connections layer
    already guards against).  Recursive; returns a copy, never mutates."""
    if isinstance(submitted, dict):
        stored = stored if isinstance(stored, dict) else {}
        out = {}
        for k, v in submitted.items():
            if v == "***" and _is_secret_key(k) and stored.get(k) not in (None, ""):
                out[k] = stored[k]
            else:
                out[k] = _unmask_secret_tree(v, stored.get(k))
        return out
    if isinstance(submitted, list):
        stored = stored if isinstance(stored, list) else []
        return [
            _unmask_secret_tree(x, stored[i] if i < len(stored) else None)
            for i, x in enumerate(submitted)
        ]
    return submitted


def _chain_hop_label(entry) -> str:
    """The hop's identity, resolved EXACTLY as build_hop_plan resolves it:
    explicit ``label`` (case preserved), else the lowercased target type."""
    if not isinstance(entry, dict):
        return ""
    return str(entry.get("label")
               or str(entry.get("target")
                      or entry.get("target_type") or "").lower())


def _unmask_delivery_chain(submitted, stored):
    """S4 companion for the delivery chain (BRD §11/§14.2): GET masks hop
    credentials to '***'; a client round-tripping that chain through PUT
    must get the stored REAL value back, not store the placeholder.

    Hops are matched by LABEL — the identity a DeliveryAttempt is keyed
    by — never by list position: an author who reorders or inserts hops
    must not inherit another hop's credential."""
    if not isinstance(submitted, list):
        return submitted
    stored_by_label: dict = {}
    for entry in (stored if isinstance(stored, list) else []):
        lbl = _chain_hop_label(entry)
        if lbl and lbl not in stored_by_label:
            stored_by_label[lbl] = entry
    out = []
    for entry in submitted:
        match = stored_by_label.get(_chain_hop_label(entry))
        if isinstance(entry, dict) and isinstance(match, dict):
            out.append(_unmask_secret_tree(entry, match))
        else:
            out.append(entry)
    return out


async def _require_feed(feed_id: int, user: dict, *, write: bool) -> dict:
    """Fetch the feed by id and enforce view/edit authorization.

    Returns the feed dict; raises 404 (not found) or 403 (denied).  When auth
    is DISABLED the check is a no-op (allow).  The permission resolution (incl.
    its group-membership DB lookup) runs OFF the event loop via ``adb``.
    Defensive: if the resolver errors, fall back to owner/admin so the feed's
    own owner can never be locked out by a resolver hiccup."""
    feed = await adb(_db_manager.get_feed_config, feed_id)
    if not feed:
        raise HTTPException(status_code=404, detail=f"Feed config {feed_id} not found")
    if not _auth_on():
        return feed
    # ACCESS STRATEGY — owned = private, UNCLAIMED = org-shared, admin = always.
    # A feed with no created_by AND no owner_group_id is an UNCLAIMED org
    # resource: privacy is opt-in via ownership, so an unclaimed feed is shared
    # (any authenticated user can view/act) until someone claims it by setting
    # an owner or group.  This is the same default-visibility model the
    # connections layer uses, and it means new feeds (which always stamp
    # created_by on create) are private by default, while shared/unowned feeds
    # stay usable by the whole org.  Admins/support always pass via the gates
    # below regardless.
    if not str(feed.get("created_by") or "").strip() and not feed.get("owner_group_id"):
        return feed
    try:
        from core.feed.permissions import can_view_feed, can_edit_feed
        _gate = can_edit_feed if write else can_view_feed
        ok = await adb(_gate, feed, user, _db_manager)
    except Exception:
        _u = str((user or {}).get("username", "") or "").lower()
        _owner = str(feed.get("created_by") or "").lower()
        try:
            from core.roles import is_admin_like as _adm
            ok = bool(_adm(user) or (_owner and _owner == _u))
        except Exception:
            ok = False
    if not ok:
        raise HTTPException(
            status_code=403,
            detail=("You do not have permission to modify this feed."
                    if write else "You do not have permission to view this feed."),
        )
    return feed


async def _require_feed_for_execution(execution_id: int, user: dict, *, write: bool):
    """Resolve an execution's feed_config_id, then enforce feed authz.  Returns
    (execution_dict, feed_dict).  Raises 404/403.  Used by the execution
    read/retry/cancel/download endpoints which key on execution_id."""
    ex = await adb(_db_manager.get_feed_execution, execution_id)
    if not ex:
        raise HTTPException(status_code=404, detail=f"Feed execution {execution_id} not found")
    fid = ex.get("feed_config_id")
    if fid is None:
        # Orphan execution with no feed — admins only when auth is on.
        if _auth_on():
            from core.roles import is_admin_like as _adm
            if not _adm(user):
                raise HTTPException(status_code=403, detail="Not authorised for this execution")
        return ex, None
    feed = await _require_feed(int(fid), user, write=write)
    return ex, feed


def _sees_every_feed(user) -> bool:
    """No-auth, admin-like or support: every feed is visible, no filtering.
    THE rule lives in ``core.feed.permissions.sees_every_feed`` (2026-10-17:
    the WebSocket board watch asks it too); this keeps the injected auth
    config's say on whether auth is on at all."""
    if not _auth_on():
        return True
    from core.feed.permissions import sees_every_feed
    return sees_every_feed(user)


def _visible_feed_ids(user) -> set:
    """The ids of the feeds ``user`` may VIEW -- THE list rule
    (``_filter_visible_feeds``), so a run is listed exactly when its feed is.
    Runs SYNC (``adb``)."""
    configs = _db_manager.list_feed_configs() or []
    return {int(c["id"]) for c in _filter_visible_feeds(configs, user)
            if isinstance(c, dict) and c.get("id") is not None}


def _filter_visible_feeds(rows, user) -> list:
    """Filter a feed-config list to the rows the user may VIEW — the list
    counterpart of ``_require_feed`` (which only gates single-object routes).
    Honours the same strategy: auth-off → all; admin/support → all; UNCLAIMED
    (no created_by AND no owner_group_id) → shared; else owner/group view gate.

    Runs SYNC in a worker thread (``adb``): group-membership lookups are
    memoized per group_id so a list sharing a group does one DB read per
    group, not per feed.  Fail-closed per row (a row whose gate errors is
    dropped unless the caller is its owner)."""
    rows = list(rows or [])
    if not rows or not _auth_on():
        return rows
    try:
        from core.roles import is_admin_like as _adm
        if _adm(user):
            return rows
    except Exception:
        pass
    try:
        from core.entitlements import is_support as _is_support
        if _is_support(user):
            return rows
    except Exception:
        pass
    from core.feed.permissions import can_view_feed
    _member_memo: dict = {}

    class _MemoDB:
        # Proxy to the real db_manager but memoize the group-member read that
        # the entitlements resolver calls once per feed.
        def __getattr__(self, name):
            return getattr(_db_manager, name)

        def list_user_group_members(self, group_id):
            try:
                gid = int(group_id)
            except Exception:
                return []
            if gid not in _member_memo:
                try:
                    _member_memo[gid] = _db_manager.list_user_group_members(gid)
                except Exception:
                    _member_memo[gid] = []
            return _member_memo[gid]

    mdb = _MemoDB()
    uname = str((user or {}).get("username", "") or "").lower()
    out = []
    for r in rows:
        if not str(r.get("created_by") or "").strip() and not r.get("owner_group_id"):
            out.append(r)          # unclaimed = org-shared
            continue
        try:
            if can_view_feed(r, user, mdb):
                out.append(r)
        except Exception:
            if uname and str(r.get("created_by") or "").lower() == uname:
                out.append(r)      # fail-closed except keep the owner
    return out


async def _run_cross_source_preflight(feed_shape: dict):
    """Run the cross-source config preflight off the event loop.

    Returns the PreflightResult (or None for plain single-source feeds).
    The checker itself is fail-open — a crash inside it must never block
    a save — but real verdicts (missing secondary connection, half-built
    cross config, invalid join keys) are the caller's to enforce.
    """
    try:
        from core.feed.cross_source_preflight import preflight_feed_cross_source
        return await adb(preflight_feed_cross_source, _db_manager, feed_shape)
    except Exception as exc:
        logger.warning(
            "[feed-crosssource] save-time preflight crashed (%s: %s) — "
            "saving without preflight", type(exc).__name__, exc,
        )
        return None


# ── Pydantic Models ──────────────────────────────────────────────────────────

def _validate_execution_backend_value(v):
    """Membership check against the ROUTER's own registry (2026-08-22).

    The old spelling was a literal regex ``^(auto|native|airflow)$`` on
    Create — a SECOND source of truth that silently fell out of date:
    per-feed ``spark_k8s`` (a backend that exists) was unreachable from
    the create surface, and the UI's ``spark_connect`` option 422'd.
    Update validated NOTHING, the opposite failure.  Both now check the
    same set: ``auto`` + ``backend_router.VALID_BACKENDS``.

    ``spark_connect`` is deliberately NOT accepted as a per-feed pin: the
    router's decision tree has no per-feed branch for it (a stored
    ``spark_connect`` pin silently behaves as ``auto``), and a pin that
    is silently ignored is a lying knob.  It remains reachable where it
    is real: the auto tier and the per-execution override.
    """
    if v is None:
        return v
    from core.feed.backend_router import VALID_BACKENDS
    allowed = ("auto",) + tuple(VALID_BACKENDS)
    val = str(v).strip().lower()
    if val not in allowed:
        raise ValueError(
            f"execution_backend must be one of {list(allowed)}; got {v!r}")
    return val


class FeedConfigCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    # 2026-09-02 (FR-ID-01..03) — ``name`` is identity: bounded charset,
    # unique, immutable once the feed has run.  ``display_name`` is the
    # editable label, and it is what makes the rename refusal acceptable
    # rather than obstructive: people can still relabel.
    display_name: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    # BF-415 / Phase 122-C — sql_file is a first-class feed source.  Reads the
    # SQL from a stored .sql file (SqlFile model) and runs it against the
    # file's connection_id (with optional secondary_connection_id for
    # cross-connection combine — same shape as PVs).
    # 2026-09-03 — NO FROZEN REGEX.  Source kinds are discovered STEPS
    # (core/feed/steps): the four SQL kinds are builtins and an operator
    # may drop in more.  A regex here would reject a step the engine can
    # actually run — the API refusing what the platform supports — so the
    # vocabulary is checked against the REGISTRY in
    # _refuse_unknown_source_type, whose refusal lists what IS
    # registered instead of an opaque pattern mismatch.
    source_type: str
    source_id: int
    connection_id: Optional[int] = None
    query_params: Optional[dict] = None
    # Phase 132.38 — per-feed Static / Dynamic WHERE-clause mapping.  Same
    # primitive as published views (api param concept).  Static rows are
    # locked at config-save time; Dynamic rows let the external-trigger
    # caller override the value via ExternalTriggerRequest.query_params.
    # Persisted inside ``query_params._where_clauses_mapping`` so the
    # existing feed_configs table is unchanged.
    where_clauses: List["WhereClauseMapping"] = Field(default_factory=list)
    output_format: str = Field(default="csv", pattern="^(csv|parquet|json|excel)$")
    output_filename_template: Optional[str] = None
    output_options: Optional[dict] = None
    destination_type: str = Field(default="local", pattern="^(local|s3|sftp|oracle)$")
    destination_config: dict = Field(default_factory=dict)
    # 2026-09-02 (BRD §11 / §14.2) — ordered multi-hop delivery chain,
    # the input core/feed/delivery_hops.build_hop_plan reads: a list of
    # {"target": ..., "label": ..., "config": {...}, "requires": ...,
    # "max_attempts": n}.  None (the default) = no chain = the legacy
    # single-hop destination_type/destination_config path, unchanged.
    # Validated at authoring by _refuse_invalid_delivery_chain.
    delivery_chain: Optional[List[dict]] = None
    execution_backend: str = Field(default="auto")

    @field_validator("execution_backend")
    @classmethod
    def _check_execution_backend(cls, v):
        return _validate_execution_backend_value(v)
    backend_config: Optional[dict] = None
    size_threshold_rows: Optional[int] = None
    schedule_enabled: bool = False
    cron_expression: Optional[str] = None
    # BRD 2.1 — the declared schedule (vocabulary in core/feed/schedule.py).
    # On BOTH twin models deliberately: this file has shipped a bug from a
    # field that existed on only one of them.
    schedule_declaration: Optional[dict] = None
    timezone: str = "UTC"

    # Phase 4 (2026-08-23): validate cron + timezone AT THE API.  A typo'd
    # cron used to be accepted with 201 (schedule_enabled=true in the DB)
    # and then swallowed by _register_schedule's catch-all — the feed
    # simply never fired, with nothing anywhere saying why.
    @field_validator("cron_expression")
    @classmethod
    def _check_cron_expression(cls, v):
        if v:
            from core.feed.schedule_reconciler import validate_cron_and_tz
            validate_cron_and_tz(v, "UTC")
        return v

    @field_validator("timezone")
    @classmethod
    def _check_timezone(cls, v):
        if v:
            from core.feed.schedule_reconciler import validate_cron_and_tz
            # Same acceptance the scheduler applies at registration time.
            validate_cron_and_tz("0 0 * * *", v)
        return v
    notify_on_success: bool = False
    notify_on_failure: bool = True
    notify_emails: Optional[str] = None
    notify_webhook: Optional[str] = Field(default=None, min_length=8)
    # 2026-09-24: blank = INHERIT the deployment default, the same contract as
    # the update model and the authoring UI (which sends null for blank).  This
    # was ``int = 2`` / ``int = 60``: every feed created in the UI with the
    # fields left blank -- their default -- was refused with a 422, and one
    # created by API silently pinned 2/60 instead of inheriting.  Found by
    # creating a feed from scratch in a real browser.
    max_retries: Optional[int] = Field(default=None, ge=0)
    retry_delay_seconds: Optional[int] = Field(default=None, ge=0)
    # Phase 130 — enterprise feed knobs
    file_type_code:        Optional[str] = None
    # BF-473 — operator-facing category.  Suggested values exposed
    # via /api/feed-configs/frequency-categories but the field is a
    # free string so admins can add new categories without code.
    frequency_category:    Optional[str] = Field(default=None, max_length=50)
    priority:              Optional[int] = Field(default=None, ge=1, le=9)
    valid_from:            Optional[str] = None
    valid_until:           Optional[str] = None
    sla_from:              Optional[str] = None
    sla_to:                Optional[str] = None
    # ── 2026-09-03 audit: columns the DB has, the clone allowlist copies
    # and BOTH models silently DROPPED.  pydantic ignores unknown input,
    # so an author (or the UI) sending these got a 200, no error, and no
    # stored value -- the same twin-model shape that once lost every BQB
    # query its raw_sql.  Each one gates a feature that was otherwise
    # unreachable:
    #   sla_timezone            -- the CONSUMER deadline zone; without it
    #                              the SLA ladder silently treats every
    #                              feed as UTC
    #   expected_runtime_seconds -- the declared runtime the decision
    #                              deadline is computed back from
    #   row_count_* / expect_zero -- the FR-DEP-16 variance check
    #   skip_requires_second_approver -- the FR-DEP-14 maker/checker gate
    #   estimated_row_count     -- the router's size hint
    sla_timezone:          Optional[str] = None
    expected_runtime_seconds: Optional[int] = Field(default=None, ge=0)
    estimated_row_count:   Optional[int] = Field(default=None, ge=0)
    row_count_expect_zero: Optional[bool] = None
    # 2026-10-12 (owner R2) -- what today's count is compared with:
    # the rolling baseline, or the previous business date's DELIVERED rows.
    row_count_compare_to: Optional[str] = Field(default=None, pattern="^(baseline|previous)$")
    row_count_min_rows:    Optional[int] = Field(default=None, ge=0)
    row_count_threshold_pct_down: Optional[float] = Field(default=None, ge=0)
    row_count_threshold_pct_up:   Optional[float] = Field(default=None, ge=0)
    skip_requires_second_approver: Optional[bool] = None
    calendar_name:         Optional[str] = None
    # 2026-09-05 -- the STEP MODEL's flow assignment.  ``feed_configs``
    # gained ``flow_id`` and the clone allowlist copies it, which makes it
    # AUTHORED config; a request model that does not declare it means
    # pydantic drops it silently and a save returns 200 having stored
    # nothing.  NULL is the migration default and means "plan the engine
    # spine", so the field is optional in both directions.
    flow_id:               Optional[int] = None
    action_condition_sql:  Optional[str] = None
    control_file_template: Optional[str] = None
    # Cross-source combine — when secondary_connection_id is set the
    # feed pulls primary + secondary sides separately and combines.
    secondary_connection_id: Optional[int] = None
    # Registry-checked, not regex-pinned — see source_type above.
    secondary_source_type:   Optional[str] = None
    secondary_source_id:     Optional[int] = None
    combine_mode:            Optional[str] = Field(
        default=None, pattern="^(union|join)$",
    )
    join_config:             Optional[dict] = None
    # 2026-10-11 -- token BINDINGS: a saved query's literal predicate
    # (CODE = 'SAP-2504') bound to a token ({SYSTEM_ENTITY}) per side; see
    # core/feed/sql_tokens.py.  Validated by _refuse_invalid_token_bindings
    # against the SQL that resolves NOW; on BOTH twins, forwarded by both
    # handlers, copied by clone, cleared by an explicit null.
    token_bindings:          Optional[List[dict]] = None
    # Phase 130 hotfix-4 — DB-driven CTL format
    control_file_format_id:  Optional[int] = None
    # Phase 130 hotfix-7 — group ownership
    owner_group_id:          Optional[int] = None
    # 2026-09-28 -- the feed's CONSUMER groups (user_groups ids): members
    # read its delivery receipts on My Feeds and may subscribe to notices.
    # NOT a view grant (core/feed/consumer_receipts.py).  Validated against
    # existing groups by _require_valid_consumer_group_ids; on BOTH twin
    # models, forwarded by both handlers, copied by clone.
    consumer_group_ids:      Optional[List[int]] = None
    # 2026-09-02 — operational feed group (feed_groups.id), the axis the
    # dashboard groups by and group actions act on.  DISTINCT from
    # owner_group_id (ACL).  On BOTH twin models AND forwarded by BOTH
    # handlers deliberately: this file has shipped a bug from a field
    # existing on one twin, and another from a field no handler forwarded
    # (accepted, silently dropped, 200).  Validated against an existing
    # ACTIVE group by _require_valid_feed_group_id.
    feed_group_id:           Optional[int] = None
    # Phase 131 — production controls (opt-in per feed)
    etl_id:                  Optional[int] = None
    row_count_threshold_pct: Optional[float] = Field(default=None, ge=0, le=100)
    row_count_action:        Optional[str] = Field(default=None, pattern="^(off|warn|fail|hold)$")
    integrity_check_enabled: Optional[bool] = None
    # Generic task_type — file_feed (legacy default) | oracle_push |
    # api_push | custom.  Branch point for future non-file task types.
    task_type:               Optional[str] = Field(
        default=None, pattern="^(file_feed|oracle_push|api_push|custom)$",
    )


class FeedConfigUpdate(BaseModel):
    name: Optional[str] = None
    display_name: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    source_type: Optional[str] = None
    source_id: Optional[int] = None
    connection_id: Optional[int] = None
    query_params: Optional[dict] = None
    # Phase 132.38 — re-apply WHERE mapping on update.  ``None`` leaves the
    # existing mapping untouched; an empty list clears it.
    where_clauses: Optional[List["WhereClauseMapping"]] = None
    output_format: Optional[str] = None
    output_filename_template: Optional[str] = None
    output_options: Optional[dict] = None
    destination_type: Optional[str] = None
    destination_config: Optional[dict] = None
    # 2026-09-02 (BRD §11 / §14.2) — same field as FeedConfigCreate (a
    # field Create accepts but Update omits is silently unchangeable —
    # that exact bug has shipped here before).  Omitted = keep the
    # stored chain; explicit null CLEARS it back to single-hop (listed
    # in _CLEARABLE_NULL_FIELDS); a list replaces it wholesale after
    # _refuse_invalid_delivery_chain.
    delivery_chain: Optional[List[dict]] = None
    execution_backend: Optional[str] = None
    backend_config: Optional[dict] = None

    @field_validator("execution_backend")
    @classmethod
    def _check_execution_backend(cls, v):
        return _validate_execution_backend_value(v)
    size_threshold_rows: Optional[int] = None
    schedule_enabled: Optional[bool] = None
    cron_expression: Optional[str] = None
    # BRD 2.1 — the declared schedule (vocabulary in core/feed/schedule.py).
    # On BOTH twin models deliberately: this file has shipped a bug from a
    # field that existed on only one of them.
    schedule_declaration: Optional[dict] = None
    timezone: Optional[str] = None

    # Phase 4 (2026-08-23): same cron/timezone validation as create.
    @field_validator("cron_expression")
    @classmethod
    def _check_cron_expression(cls, v):
        if v:
            from core.feed.schedule_reconciler import validate_cron_and_tz
            validate_cron_and_tz(v, "UTC")
        return v

    @field_validator("timezone")
    @classmethod
    def _check_timezone(cls, v):
        if v:
            from core.feed.schedule_reconciler import validate_cron_and_tz
            validate_cron_and_tz("0 0 * * *", v)
        return v
    notify_on_success: Optional[bool] = None
    notify_on_failure: Optional[bool] = None
    notify_emails: Optional[str] = None
    notify_webhook: Optional[str] = Field(default=None, min_length=8)
    max_retries: Optional[int] = Field(default=None, ge=0)
    retry_delay_seconds: Optional[int] = Field(default=None, ge=0)
    # Phase 130 — enterprise feed knobs
    file_type_code:        Optional[str] = None
    # BF-473 — operator-facing category.  Suggested values exposed
    # via /api/feed-configs/frequency-categories but the field is a
    # free string so admins can add new categories without code.
    frequency_category:    Optional[str] = Field(default=None, max_length=50)
    priority:              Optional[int] = Field(default=None, ge=1, le=9)
    valid_from:            Optional[str] = None
    valid_until:           Optional[str] = None
    sla_from:              Optional[str] = None
    sla_to:                Optional[str] = None
    # ── 2026-09-03 audit: columns the DB has, the clone allowlist copies
    # and BOTH models silently DROPPED.  pydantic ignores unknown input,
    # so an author (or the UI) sending these got a 200, no error, and no
    # stored value -- the same twin-model shape that once lost every BQB
    # query its raw_sql.  Each one gates a feature that was otherwise
    # unreachable:
    #   sla_timezone            -- the CONSUMER deadline zone; without it
    #                              the SLA ladder silently treats every
    #                              feed as UTC
    #   expected_runtime_seconds -- the declared runtime the decision
    #                              deadline is computed back from
    #   row_count_* / expect_zero -- the FR-DEP-16 variance check
    #   skip_requires_second_approver -- the FR-DEP-14 maker/checker gate
    #   estimated_row_count     -- the router's size hint
    sla_timezone:          Optional[str] = None
    expected_runtime_seconds: Optional[int] = Field(default=None, ge=0)
    estimated_row_count:   Optional[int] = Field(default=None, ge=0)
    row_count_expect_zero: Optional[bool] = None
    # 2026-10-12 (owner R2) -- what today's count is compared with:
    # the rolling baseline, or the previous business date's DELIVERED rows.
    row_count_compare_to: Optional[str] = Field(default=None, pattern="^(baseline|previous)$")
    row_count_min_rows:    Optional[int] = Field(default=None, ge=0)
    row_count_threshold_pct_down: Optional[float] = Field(default=None, ge=0)
    row_count_threshold_pct_up:   Optional[float] = Field(default=None, ge=0)
    skip_requires_second_approver: Optional[bool] = None
    calendar_name:         Optional[str] = None
    # 2026-09-05 -- the STEP MODEL's flow assignment.  ``feed_configs``
    # gained ``flow_id`` and the clone allowlist copies it, which makes it
    # AUTHORED config; a request model that does not declare it means
    # pydantic drops it silently and a save returns 200 having stored
    # nothing.  NULL is the migration default and means "plan the engine
    # spine", so the field is optional in both directions.
    flow_id:               Optional[int] = None
    action_condition_sql:  Optional[str] = None
    control_file_template: Optional[str] = None
    # Cross-source combine
    secondary_connection_id: Optional[int] = None
    # Registry-checked, not regex-pinned — see source_type above.
    secondary_source_type:   Optional[str] = None
    secondary_source_id:     Optional[int] = None
    combine_mode:            Optional[str] = Field(
        default=None, pattern="^(union|join)$",
    )
    join_config:             Optional[dict] = None
    # 2026-10-11 -- token BINDINGS: a saved query's literal predicate
    # (CODE = 'SAP-2504') bound to a token ({SYSTEM_ENTITY}) per side; see
    # core/feed/sql_tokens.py.  Validated by _refuse_invalid_token_bindings
    # against the SQL that resolves NOW; on BOTH twins, forwarded by both
    # handlers, copied by clone, cleared by an explicit null.
    token_bindings:          Optional[List[dict]] = None
    # Phase 130 hotfix-4 — DB-driven CTL format
    control_file_format_id:  Optional[int] = None
    # Phase 130 hotfix-7 — group ownership
    owner_group_id:          Optional[int] = None
    # 2026-09-28 -- twin of FeedConfigCreate.consumer_group_ids.  Omitted =
    # keep; explicit null / [] CLEARS the declaration (_CLEARABLE_NULL_FIELDS).
    consumer_group_ids:      Optional[List[int]] = None
    # 2026-09-02 — same field as FeedConfigCreate (twin-parity rule: a
    # field Create accepts but Update omits is silently unchangeable).
    # Omitted = keep; explicit null UN-GROUPS the feed (listed in
    # _CLEARABLE_NULL_FIELDS); an id re-groups after validation.
    feed_group_id:           Optional[int] = None
    # Phase 131 — production controls (opt-in per feed)
    etl_id:                  Optional[int] = None
    row_count_threshold_pct: Optional[float] = Field(default=None, ge=0, le=100)
    row_count_action:        Optional[str] = Field(default=None, pattern="^(off|warn|fail|hold)$")
    integrity_check_enabled: Optional[bool] = None
    task_type:               Optional[str] = Field(
        default=None, pattern="^(file_feed|oracle_push|api_push|custom)$",
    )


class QuickCreateFeed(BaseModel):
    # 2026-09-03 — NO FROZEN REGEX.  Source kinds are discovered STEPS
    # (core/feed/steps): the four SQL kinds are builtins and an operator
    # may drop in more.  A regex here would reject a step the engine can
    # actually run — the API refusing what the platform supports — so the
    # vocabulary is checked against the REGISTRY in
    # _refuse_unknown_source_type, whose refusal lists what IS
    # registered instead of an opaque pattern mismatch.
    source_type: str
    source_id: int
    connection_id: Optional[int] = None
    output_format: str = Field(default="csv", pattern="^(csv|parquet|json|excel)$")
    destination_type: str = Field(default="local", pattern="^(local|s3|sftp|oracle)$")
    destination_config: dict = Field(default_factory=dict)
    execute_now: bool = False


class WebhookPayload(BaseModel):
    dag_id: Optional[str] = None
    state: str
    execution_id: str
    error: Optional[str] = None
    output_path: Optional[str] = None
    output_row_count: Optional[int] = None
    output_file_count: Optional[int] = None
    output_size_bytes: Optional[int] = None
    # H1 (2026-09-02) — did the JOB deliver, or did it write artifacts
    # only?  Reported by the thing that would have delivered, which is
    # the only source that cannot be wrong.  ABSENT means an image that
    # predates the flag: assume it DID deliver, so QueryStudio does
    # nothing and today's behaviour is preserved.  The fail-safe
    # direction is deliberate — a missed delivery is visible and
    # re-runnable; a double delivery reaches the counterparty.
    delivered: Optional[bool] = None
    # 2026-10-07 -- DESTINATION-side row accounting from a job that
    # delivered into Oracle itself: rows that reached the table, and rows
    # the table rejected under the destination's max_error_percent (the
    # Spark lane now honours the same tolerance as native).  The
    # certificate reconciles against ``delivered_rows`` -- without it a
    # tolerated rejection would certify COMPLETE while the table is short.
    # ABSENT (any other destination, or an older image) = not reported.
    delivered_rows: Optional[int] = None
    dropped_rows: Optional[int] = None
    # 2026-10-07 (feed lane contract, D1/K5) -- what the job's transport
    # did, in the SAME shape native's transports report
    # (core/feed/delivery_protocol.receipt): uri, verification (the
    # .part->rename->size check / the S3 size check), the rows its renderer
    # wrote and its own recount of the file.  The certificate's destination
    # evidence is chosen from it by the one rule both lanes use
    # (core/feed/delivery_verdict.certified_dest_rows).  ABSENT = an image
    # from before the contract: the run stays UNVERIFIED, as before.
    delivery_receipt: Optional[Dict[str, Any]] = None
    lane_output_version: Optional[int] = None
    # 2026-10-10 -- the MERGE record of a cross-source run, built by the job
    # through the mirror of core/feed/merge_by_name.py (cross_source_record:
    # combine_mode / primary_rows / secondary_rows / expected_rows / merge /
    # combine / combined_rows / lane).  Stored under
    # files_metadata.cross_source VERBATIM -- the native lane's slot and
    # shape -- so an auditor reads primary + secondary == delivered the same
    # way on both lanes.  ABSENT: a single-source run, or an older image.
    cross_source: Optional[Dict[str, Any]] = None
    # 2026-10-11 -- the job's per-side REPORTED-ROWS certification record
    # (the mirror of core/feed/reported_rows_certification.py: verdict /
    # sides / failures), stored under stage_timings.reported_rows_certification
    # like the native lane's.  ABSENT: no side declared, or an older image.
    reported_rows_certification: Optional[Dict[str, Any]] = None
    # 2026-10-14 -- the executors Spark removed while the job ran, with
    # Spark's own reason ([{id, reason}], from the driver's status store).
    # A failed run's headline LEADS with it (core/spark_k8s/failure_text.py
    # executors_lost_sentence): "Job 1 cancelled because SparkContext was
    # shut down" alone hid four OOM-killed executors.  Undeclared, the model
    # dropped it here while the reconciler's road (the pod's termination
    # message, raw) kept it -- two answers to one question.
    executors_lost: Optional[List[Dict[str, Any]]] = None
    # 2026-10-14 -- how each side was read by partition key (the buckets'
    # plan, the by-files decision, or why the query ran whole); stored as
    # files_metadata.partitioned_read, the native lane's slot.
    partitioned_read: Optional[Dict[str, Any]] = None


# ── CRUD Endpoints ───────────────────────────────────────────────────────────

def _embed_where_mapping_in_query_params(
    data: Dict[str, Any],
    where_clauses: Optional[List["WhereClauseMapping"]],
    *,
    clear_when_empty: bool = False,
) -> None:
    """Phase 132.38 — stash the publisher's WHERE-mapping inside
    ``query_params._where_clauses_mapping`` so feed_configs requires
    no DB migration to gain the new field.  The runtime path in
    ``core.feed_where_apply`` reads from the same sentinel key.

    ``where_clauses=None`` is a no-op (preserves existing mapping on
    update).  ``where_clauses=[]`` with ``clear_when_empty=True``
    explicitly removes the mapping — used by the update path so a
    publisher can clear all WHERE rows.
    """
    # ``data`` was produced by ``model_dump(exclude_none=True)`` which
    # already dropped the field when it was None on update.  When the
    # field was supplied (even as []), we get a serialised list here.
    submitted = data.pop("where_clauses", None)
    if submitted is None and where_clauses is not None:
        # exclude_none=True ate an empty list — re-resolve from the model.
        submitted = [w.model_dump() if hasattr(w, "model_dump") else dict(w)
                     for w in where_clauses]
    if submitted is None:
        return
    qp = dict(data.get("query_params") or {})
    if not submitted:
        if clear_when_empty:
            qp.pop("_where_clauses_mapping", None)
    else:
        qp["_where_clauses_mapping"] = submitted
    data["query_params"] = qp


async def _require_valid_calendar_name(name) -> None:
    """Phase 4 (2026-08-23): a feed's calendar_name was stored UNVALIDATED.
    A typo (or a later-deactivated calendar) got a 200 and permanently
    silent no-calendar behaviour -- the feed ran on weekends/holidays while
    the UI showed a calendar attached.  Existence check against ACTIVE
    calendars; the classic "200 with nothing useful" closed."""
    if not name:
        return
    row = await adb(_db_manager.get_feed_calendar_by_name, str(name))
    if not row:
        raise HTTPException(
            status_code=400,
            detail=f"calendar_name {name!r} does not match any ACTIVE "
                   f"business calendar. Create or reactivate it under "
                   f"/feeds/calendars first.")


async def _require_valid_feed_group_id(group_id) -> None:
    """2026-09-02 — same lesson as _require_valid_calendar_name above: a
    reference stored UNVALIDATED is a 200 today and silently-broken
    grouping forever (the feed never shows in its group, group actions
    never touch it).  Refuse a feed_group_id that names no ACTIVE
    group, at authoring, with the fix spelled out."""
    if group_id is None:
        return
    row = await adb(_db_manager.get_feed_group, int(group_id))
    if not row or not row.get("is_active"):
        raise HTTPException(
            status_code=400,
            detail=f"feed_group_id {group_id} does not match any ACTIVE "
                   f"feed group. GET /api/feed-groups lists the groups "
                   f"that exist; create or reactivate one first (POST "
                   f"/api/feed-groups), or send null to leave the feed "
                   f"ungrouped.")


async def _require_valid_consumer_group_ids(group_ids) -> None:
    """2026-09-28 -- a consumer group that names no user_group is a
    declaration nobody can ever satisfy (no member, no receipt audience,
    and the author believes the team is served).  Refuse at authoring,
    naming the ids; null / [] is the documented "no consumers"."""
    if group_ids is None:
        return
    if not isinstance(group_ids, (list, tuple)):
        raise HTTPException(
            status_code=422,
            detail="consumer_group_ids must be a list of user group ids")
    bad = []
    for gid in group_ids:
        try:
            row = await adb(_db_manager.get_user_group, int(gid))
        except Exception:
            row = None
        if not row or not row.get("is_active", True):
            bad.append(gid)
    if bad:
        raise HTTPException(
            status_code=400,
            detail=f"consumer_group_ids {bad} match no ACTIVE user group. "
                   f"GET /api/admin/user-groups lists the entitlement groups "
                   f"that exist; create one first, or send null / [] to "
                   f"declare no consumers.")


#: A feed stores its output contract as ``output_format`` plus a nested
#: ``output_options`` bag; the validator takes the terms FLAT.  The map
#: is explicit and one-directional so a term can never be silently
#: dropped: an unmapped key would make the validator refuse the whole
#: config as "unknown term", which degrades to saving every feed
#: UNVALIDATED — the failure this mapping exists to prevent.
FEED_OPTION_TO_CONTRACT_TERM = {
    "delimiter":          "delimiter",
    "header":             "header",
    "na_rep":             "null_marker",
    "compression":        "codec",
    "codec":              "codec",
    "packaging":          "packaging",
    "encoding":           "encoding",
    "quoting":            "quoting",
    "quotechar":          "quotechar",
    "escapechar":         "escapechar",
    "line_terminator":    "line_terminator",
    "trailing_delimiter": "trailing_delimiter",
    "empty_string_marker": "empty_string_marker",
    "checksum":           "checksum_algorithm",
    "checksum_algorithm": "checksum_algorithm",
    "checksum_scope":     "checksum_scope",
    "checksum_covers":    "checksum_covers",
    "control_file_compression": "control_file_compression",
    "sidecar":            "sidecar",
    "digest_line":        "digest_line",
    "encryption":         "encryption",
    "pgp_recipient":      "pgp_recipient",
    "sequencing":         "sequencing",
    "multipart_naming":   "multipart_naming",
    "redelivery_naming":  "redelivery_naming",
}


def _contract_terms_from_feed(config: dict) -> dict:
    """Flatten a feed row into the contract terms the validator takes.

    Unmapped ``output_options`` keys are DROPPED, not passed through:
    that bag also carries engine knobs which are not contract terms,
    and passing one would make the validator refuse the whole config
    and fall back to saving the feed unvalidated.
    """
    terms: dict = {}
    if config.get("output_format"):
        terms["output_format"] = config["output_format"]
    if config.get("output_filename_template"):
        terms["filename_template"] = config["output_filename_template"]
    # NOT mapped: ``control_file_format_id``.  It names a FORMAT RECORD
    # that carries its own spec — including which digest the control
    # record uses — so mapping it to the contract's
    # ``control_file_required`` conflates two different things and
    # INVENTS a declaration the author never made, which the validator
    # then (correctly) demands a checksum term for.  An adapter that
    # invents a declaration is as wrong as one that drops one.
    for key, value in (config.get("output_options") or {}).items():
        term = FEED_OPTION_TO_CONTRACT_TERM.get(key)
        if term is not None and value is not None:
            terms[term] = value
    # FR-ACC-01 (2026-09-03) — three consumer terms the BRD requires
    # that the contract vocabulary does not carry yet: column_order,
    # expected_row_range, acknowledgment.  The moment contract.py gains
    # the fields, this maps them and validate_contract governs them.
    # Until then a DECLARED term is REFUSED loudly — the author typing
    # one believes it is in force, and a term silently riding an
    # options bag nothing reads is the exact defect contract.py's own
    # unknown-key refusal exists to prevent.  (Raised HERE, outside
    # _refuse_invalid_contract's catch-all, so it cannot be downgraded
    # to "saved unvalidated".)
    try:
        from dataclasses import fields as _dc_fields2
        from core.feed.contract import FeedContract as _FC
        _supported_terms = {f.name for f in _dc_fields2(_FC)}
    except ImportError:
        _supported_terms = set()
    for _gterm in ("column_order", "expected_row_range", "acknowledgment"):
        _gval = (config.get("output_options") or {}).get(_gterm)
        if _gval is None:
            continue
        if _gterm in _supported_terms:
            terms[_gterm] = _gval
        else:
            raise HTTPException(
                status_code=422,
                detail=f"output_options.{_gterm} is a consumer contract "
                       f"term (FR-ACC-01) this build cannot yet enforce "
                       f"— storing it would make the author believe it "
                       f"is in force while nothing reads it.  Remove it "
                       f"for now, or record it in the feed description; "
                       f"it becomes enforceable when the contract "
                       f"vocabulary (core/feed/contract.py) gains the "
                       f"{_gterm!r} field.")
    return terms


def _refuse_invalid_filename_template(config: dict) -> None:
    """2026-09-13 -- a filename template is refused at AUTHORING when it
    names a token no renderer can resolve.  Found firing the seam through
    Docker: ``balances_{business_date}.csv`` was accepted with 201 and the
    run then died with the whole reason ``'business_date'`` (a bare
    ``KeyError`` from the legacy expander the router had picked by
    syntax).  The vocabulary check is the renderer's own
    (``filename_renderer.unknown_template_tokens``), so this route and
    the engine cannot disagree about what a template may say."""
    tpl = config.get("output_filename_template")
    if not tpl:
        return
    from core.feed.filename_renderer import template_vocabulary, unknown_template_tokens
    unknown = unknown_template_tokens(str(tpl))
    if unknown:
        raise HTTPException(
            status_code=422,
            detail=f"output_filename_template {str(tpl)!r} names token(s) no renderer can "
                   f"resolve: {', '.join(unknown)}.  {template_vocabulary()}.  The template "
                   f"is NOT rewritten for you; fix the token so the run does not fail at "
                   f"3am with a bare KeyError.")


def _refuse_invalid_shape(config: dict) -> None:
    """FR-CMP-04 / §9.3 — refuse a malformed SHAPE when it is TYPED.

    ``read_shape`` already refuses an empty declaration, a ``max_parts`` of 0
    ("0 does NOT mean unlimited"), a shape declaring BOTH values and
    values_sql, and an unknown ``on_empty``.  Until now those refusals fired
    only at ADMISSION — so a feed could be saved with a shape that would
    reliably fail every night, and a caller going straight to the API (or the
    UI's own client being out of step) could store one with no signal at all.
    A refusal at authoring costs a form submission; the same refusal at 03:00
    costs the run.

    Fails OPEN if the module is absent — an older build must not lose the
    ability to save a feed — but never silently: a shape saved unvalidated is
    a feed that will fail at 3am for a reason nobody was told about.
    """
    try:
        from core.feed.partition_shape import ShapeError, read_shape
    except ImportError:
        return
    try:
        read_shape(config)
    except ShapeError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.error("[feed_api] partition shape could not be validated (%s) "
                     "— the feed is saved with its shape UNVALIDATED", exc)


def _partition_drift_advice(config: dict):
    """FR-CMP-06 — surface declared-vs-source partition drift at
    AUTHORING, as a proposal the author reads, never a decision.

    "Under a declared rule it must not decide — but it may propose."
    So this returns advice and changes nothing: the declaration stays
    authoritative, and a partition the source has but the feed does not
    declare is still not produced.  The point is that the gap stops
    being invisible — today the run certifies COMPLETE against the
    DECLARED set, which is correct and is exactly why nobody would
    otherwise find out.

    Only ever compares what is already in hand: a declaration listing
    explicit VALUES against a discovered set the caller supplies.  It
    deliberately does NOT open a connection or run the shape's
    ``values_sql`` — an authoring save must not depend on the source
    being reachable, and a validator that sometimes hangs is a
    validator someone turns off.
    """
    try:
        from core.feed.completeness import propose_partition_drift
        from core.feed.partition_shape import read_shape
    except ImportError:
        return None
    try:
        shape = read_shape(config)
    except Exception:
        # A malformed shape is _refuse_invalid_shape's business; this is
        # advisory and must never be the thing that fails a save.
        return None
    if shape is None or not getattr(shape, "values", None):
        return None
    discovered = ((config.get("output_options") or {})
                  .get("discovered_partitions"))
    if discovered is None:
        discovered = config.get("_discovered_partitions")
    if discovered is None:
        return None
    try:
        return propose_partition_drift(list(shape.values), discovered)
    except Exception as exc:
        logger.debug("[feed_api] partition drift advice skipped: %s", exc)
        return None


def _refuse_empty_destination_config(config: dict) -> None:
    """A non-local destination with an EMPTY config saves, and then fails at
    delivery hours later.

    2026-09-14 -- this gate existed on POST /api/feeds and NOT on
    PUT /api/feeds/{feed_id}.  So a feed authored as ``local`` and later
    EDITED to ``oracle`` stored ``destination_config = {}``, returned 200,
    and refused at the delivery step on the next run.  That is the shape
    CLAUDE.md calls out twice: a decision made twice is a bug, and a 200
    with nothing useful in it is a defect.  One rule, one function, both
    call sites.

    The PUT side applies this only when the patch actually TOUCHES the
    destination, deliberately.  Enforcing it on every update would make an
    unrelated edit (a description, an SLA) fail on legacy rows that predate
    the POST gate -- punishing the editor for someone else's old row.  You
    may not SET a broken destination; you are not blocked from fixing a
    typo on a feed that already has one.
    """
    if (config.get("destination_type") or "local") == "local":
        return
    if not config.get("destination_config"):
        raise HTTPException(
            status_code=400,
            detail="destination_config is required for non-local destinations",
        )

#: Destinations that can only LOAD one output format, and which.
#:
#: 2026-09-15 -- ``_deliver_oracle`` reads parquet and only parquet
#: (``pyarrow.parquet`` is the only reader it has).  A feed authored with
#: ``destination_type='oracle'`` and ``output_format='csv'`` saved happily,
#: queried 500,000 rows, formatted a 24MB CSV, passed the local integrity
#: check, and THEN failed at the last hop -- with pyarrow's "the file is
#: corrupted", which it was not.  The combination is knowable at authoring
#: time and costs nothing to refuse there.
#:
#: Declared as a mapping rather than an ``if``, because the next destination
#: with a format constraint must be added HERE and not discovered at 3am by
#: whoever is on call.  local / s3 / sftp move the file as-is and constrain
#: nothing, so they are deliberately absent.
_DESTINATION_REQUIRED_FORMATS: dict = {
    "oracle": {"parquet"},
}


def _refuse_output_format_destination_mismatch(config: dict) -> None:
    """Refuse an output format the chosen destination cannot load.

    Fails at ADMISSION, where the author can act on it, instead of after the
    query and the format step.  The runtime check in ``_deliver_oracle``
    stays: this gate only covers feeds authored THROUGH the API, and a feed
    row that predates it must still fail with a message that makes sense.
    """
    dest = (config.get("destination_type") or "local")
    required = _DESTINATION_REQUIRED_FORMATS.get(dest)
    if not required:
        return
    fmt = (config.get("output_format") or "csv")
    if fmt in required:
        return
    _wanted = " or ".join(sorted(required))
    raise HTTPException(
        status_code=422,
        detail=(
            f"A {dest!r} destination can only load {_wanted}, and this feed's "
            f"output_format is {fmt!r}. The delivery would fail AFTER the "
            f"query and the format step. Set output_format to {_wanted}, or "
            f"choose a destination that accepts {fmt}."),
    )


def _refuse_unknown_source_type(config: dict) -> None:
    """Refuse a source kind no registered STEP answers to.

    Replaces a frozen four-way regex.  Source kinds are discovered steps,
    so the authorable vocabulary is whatever is REGISTERED on this
    deployment — builtins plus anything dropped into the steps root.  A
    regex could only ever reject a step the engine can genuinely run.

    The refusal LISTS what is registered, because "unknown source type"
    with no list sends an author to read code.  Fails OPEN if the steps
    module is absent (an older build must not lose the ability to save a
    feed) but never silently.
    """
    try:
        from core.feed.steps import registered_names
    except ImportError:
        logger.error("[feed_api] step registry unavailable — the feed is "
                     "saved with its source_type UNVALIDATED")
        return
    known = registered_names("source")
    for field in ("source_type", "secondary_source_type"):
        value = (config or {}).get(field)
        if value in (None, ""):
            continue
        if str(value) not in known:
            raise HTTPException(status_code=422, detail=(
                f"{field}={value!r} is not a registered source step on this "
                f"deployment. Registered: {known}. A source kind is a STEP "
                f"(core/feed/steps) -- if you dropped one in, check the boot "
                f"log for '[feed_steps]': it names every step it refused and "
                f"why."))


def _refuse_incomplete_second_side(config: dict) -> None:
    """A SECOND SIDE is declared whole or not at all (2026-10-11, the feed
    form's "Second side (cross-source)").

    * a secondary source (type / id / SQL) with no secondary connection is
      half a declaration -- the engine keys cross-source-ness on
      ``secondary_connection_id`` alone and would run SINGLE-source;
    * ``secondary_source_type = saved_query`` (or published_view / sql_file)
      needs ``secondary_source_id``;
    * ``secondary_source_type = raw_sql`` needs ``query_params.secondary_raw_sql``
      (the SQL the second side runs -- source_plan.secondary_side_config);
    * ``combine_mode`` with no second connection names a combine of one side.

    422 naming the missing half.  The preflight (cross_source_preflight)
    judges what the declared sides RESOLVE to; this is the shape.
    """
    cfg = config or {}
    sec_cid = cfg.get("secondary_connection_id")
    sec_type = (cfg.get("secondary_source_type") or "").strip().lower()
    sec_id = cfg.get("secondary_source_id")
    qp = cfg.get("query_params") or {}
    sec_sql = qp.get("secondary_raw_sql") if isinstance(qp, dict) else None
    if not sec_cid:
        declared = [k for k, v in (("secondary_source_type", sec_type),
                                   ("secondary_source_id", sec_id),
                                   ("combine_mode", cfg.get("combine_mode")),
                                   ("query_params.secondary_raw_sql", sec_sql))
                    if v not in (None, "", 0)]
        if declared:
            raise HTTPException(status_code=422, detail=(
                f"Second side incomplete: {', '.join(declared)} declared but no "
                f"secondary_connection_id. A cross-source feed is keyed on the "
                f"second CONNECTION; without it the feed runs single-source and "
                f"these fields do nothing. Pick the second connection, or clear "
                f"them."))
        return
    if sec_type in ("saved_query", "published_view", "sql_file") and not sec_id:
        raise HTTPException(status_code=422, detail=(
            f"Second side incomplete: secondary_source_type={sec_type!r} needs "
            f"secondary_source_id (which {sec_type.replace('_', ' ')} runs on the "
            f"second connection)."))
    if sec_type == "raw_sql" and not (isinstance(sec_sql, str) and sec_sql.strip()):
        raise HTTPException(status_code=422, detail=(
            "Second side incomplete: secondary_source_type='raw_sql' needs the SQL "
            "in query_params.secondary_raw_sql."))


async def _refuse_invalid_token_bindings(config: dict, target: Optional[dict] = None) -> None:
    """``token_bindings`` are validated at SAVE against the SQL each side
    resolves to NOW (core/feed/authoring_draft.py::bindings_problem): a
    malformed binding, a token nothing declares, or a literal predicate the
    saved query no longer holds is a 422 naming it.  The run applies the
    same gate (sql_tokens.BindingRefused on every lane).  What is STORED is
    the NORMALISED list (``sql_tokens.validate_token_bindings``: side,
    column, literal, token, format) -- written into ``target`` (the dict
    that is persisted; defaults to ``config``)."""
    raw = (config or {}).get("token_bindings")
    if not raw:
        return
    from core.feed.authoring_draft import bindings_problem, declared_parameters
    from core.feed.sql_tokens import BindingRefused, validate_token_bindings
    try:
        normalised = validate_token_bindings(raw, declared=declared_parameters(config))
    except BindingRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    problem = await adb(bindings_problem, _db_manager,
                        {**config, "token_bindings": normalised})
    if problem:
        raise HTTPException(status_code=422, detail=problem)
    (target if target is not None else config)["token_bindings"] = normalised


async def _refuse_unvalued_parameters(config: dict) -> None:
    """A query's PARAMETER token with no value is a 422 naming it
    (core/feed/authoring_draft.py::missing_parameters_problem, 2026-10-12)."""
    from core.feed.authoring_draft import missing_parameters_problem
    problem = await adb(missing_parameters_problem, _db_manager, dict(config or {}))
    if problem:
        raise HTTPException(status_code=422, detail=problem)


def _refuse_filename_collision(config: dict, *, exclude_id=None) -> None:
    """FR-ART-10 — refuse a feed whose rendered filename collides.

    Two feeds rendering the same name at the same destination silently
    OVERWRITE each other: the second delivery of the night replaces the
    first, both runs report success, and the counterparty receives one
    file where they were promised two.  Nothing downstream can detect
    that, which is why it has to be an authoring refusal.

    Wired 2026-09-03.  ``find_filename_collisions`` was written, tested
    and called by NOTHING.  Checked on create, UPDATE and CLONE — a
    clone is the likeliest thing of all to collide, since it starts as a
    copy of another feed's template.

    Fails OPEN if the module or the feed list is unavailable — an older
    build must not lose the ability to save a feed — but never silently.
    """
    try:
        from core.feed.filename_collision import find_filename_collisions
    except ImportError:
        return
    # 2026-10-10 -- a batch of saves (the feed template apply) holds ONE
    # snapshot of every feed, kept current as its members land; the single
    # routes list the database as they always did.  Same rule either way:
    # ``find_filename_collisions`` IS ``CollisionIndex(...).collisions``.
    idx = _authoring_index.get()
    if idx is None:
        try:
            others = [f for f in (_db_manager.list_feed_configs() or [])
                      if exclude_id is None
                      or int(f.get("id") or 0) != int(exclude_id)]
        except Exception as exc:
            logger.error("[feed_api] filename-collision check could not read the "
                         "feed list (%s) — saved with its filename UNCHECKED", exc)
            return
    try:
        if idx is not None:
            collisions = idx.collisions(config, exclude_id=exclude_id)
        else:
            collisions = find_filename_collisions(config, others)
    except Exception as exc:
        logger.error("[feed_api] filename-collision check failed (%s) — "
                     "saved with its filename UNCHECKED", exc)
        return
    if collisions:
        raise HTTPException(status_code=422, detail=(
            "; ".join(getattr(c, "message", str(c)) for c in collisions)))


def _refuse_invalid_schedule(config: dict) -> None:
    """BRD §2.1 — refuse a malformed SCHEDULE when it is TYPED.

    ``parse_schedule`` refuses an unknown kind, a ``workday_n`` of 0 ("0 does
    NOT mean every day"), an out-of-range N, an empty upstream feed name and a
    cron with the wrong field count.  Every one of those is a feed that either
    never runs or runs on the wrong days — and both are discovered weeks later,
    by the consumer, not by us.

    ABSENCE is not an error: ``parse_schedule(None) is None``, and the
    overwhelming majority of feeds carry no declaration and keep their existing
    cron/condition path untouched.

    Fails OPEN if the module is absent, but never silently.
    """
    try:
        from core.feed.schedule import ScheduleError, parse_schedule
    except ImportError:
        return
    try:
        parse_schedule(config.get("schedule_declaration"))
    except ScheduleError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.error("[feed_api] schedule declaration could not be validated "
                     "(%s) — the feed is saved with its schedule UNVALIDATED",
                     exc)


def _refuse_invalid_sla(config: dict) -> None:
    """2026-10-03 -- refuse an SLA value the SLA machinery cannot evaluate.

    ``sla_from`` / ``sla_to`` / ``sla_timezone`` were stored as any string:
    ``"6pm"`` saved with 200, the breach sweep counted it ``invalid_sla``
    and the alert ladder logged "this feed has NO breach clock" -- a feed
    whose consumer promise could never alert, discovered by nobody.  The
    rule is ``acting_time.feed_sla_field_problem`` (what BOTH readers can
    read); only the keys PRESENT in ``config`` are judged, so an update
    that does not touch the SLA is never refused over a legacy value.
    ``None`` (no SLA / legacy UTC) is always accepted.
    """
    from core.feed.acting_time import feed_sla_field_problem
    for fld in ("sla_from", "sla_to", "sla_timezone"):
        if fld not in config:
            continue
        problem = feed_sla_field_problem(fld, config.get(fld))
        if problem:
            raise HTTPException(status_code=422, detail=problem)


async def _refuse_unknown_upstream_feed(config: dict,
                                        self_name: Optional[str] = None) -> None:
    """2026-10-03 -- an ``on_completion_of`` declaration must name a feed
    that EXISTS (and not the feed itself).

    ``parse_schedule`` refuses only an EMPTY upstream name, and the form
    offered a free-text box, so a typo saved cleanly and the feed waited
    for a completion that could never happen.  Judged only when the
    declaration is in ``config`` (create, clone, or an update that sends
    it); matched case-insensitively, as feed names are unique that way.
    """
    decl = config.get("schedule_declaration")
    if not isinstance(decl, dict) or decl.get("kind") != "on_completion_of":
        return
    upstream = str(decl.get("feed") or "").strip()
    if not upstream:
        return  # parse_schedule already refused it, naming the field
    if self_name and upstream.upper() == str(self_name).strip().upper():
        raise HTTPException(status_code=422, detail=(
            f"schedule_declaration.feed={upstream!r} names this feed itself "
            f"-- a feed cannot run on its own completion.  Name the "
            f"upstream feed whose completion should fire it."))
    ids = await adb(_db_manager.get_feed_ids_by_name, upstream)
    if not ids:
        raise HTTPException(status_code=422, detail=(
            f"schedule_declaration.feed={upstream!r} names no existing "
            f"feed, so nothing could ever fire this one.  Pick the "
            f"upstream from the existing feeds (names are matched "
            f"case-insensitively)."))
    if self_name:
        cycle = await adb(_on_completion_cycle, str(self_name).strip(), upstream)
        if cycle:
            raise HTTPException(status_code=422, detail=(
                f"schedule_declaration.feed={upstream!r} would make a CYCLE "
                f"of on_completion_of feeds: {' -> '.join(cycle)} (each runs "
                f"when the one after it completes).  Since 2026-10-03 a "
                f"completion STARTS the feeds declared on it, so a cycle "
                f"would start itself again; break it by choosing another "
                f"upstream or changing one of: {', '.join(cycle[1:-1])}."))


def _on_completion_cycle(self_name: str, upstream: str) -> Optional[list]:
    """The cycle ``self_name -> upstream -> ... -> self_name`` that saving
    ``self_name`` ON COMPLETION OF ``upstream`` would close, as the list of
    names, or None.  Walks the STORED declarations of every feed (inactive
    ones too -- reactivating one must not arm a loop), matching names
    case-insensitively, the edge rule the trigger itself uses
    (core/feed/upstream_completion.py).  The feed being saved is matched by
    name, so its own stored declaration is never followed: the new one
    replaces it."""
    from core.feed.upstream_completion import declared_upstream, same_feed_name
    idx = _authoring_index.get()
    rows = (idx.schedule_declarations(active_only=False) if idx is not None
            else _db_manager.list_feed_schedule_declarations(active_only=False) or [])
    by_name = {}
    for r in rows:
        by_name.setdefault(str(r.get("name") or "").strip().upper(), r)
    chain = [self_name]
    current = upstream
    seen = {self_name.upper()}
    while current:
        if same_feed_name(current, self_name):
            return chain + [self_name]
        if current.strip().upper() in seen:
            return None          # a loop that does not pass through this feed
        seen.add(current.strip().upper())
        row = by_name.get(current.strip().upper())
        chain.append(str((row or {}).get("name") or current))
        current = declared_upstream((row or {}).get("schedule_declaration"))
    return None


def _sync_legacy_schedule_fields(config: dict,
                                 effective: dict = None) -> None:
    """Keep the DECLARATION and the legacy cron columns from disagreeing.

    A feed can carry both ``schedule_declaration`` (the vocabulary the
    author actually types: daily, month_end, workday_n, workdays,
    on_completion_of) and the pre-existing ``cron_expression`` /
    ``timezone`` / ``calendar_name`` / ``action_condition_sql``.  The SOD
    generator decides due-ness from the DECLARATION via ``due_on``, so
    when the two disagree the declaration silently wins and the cron
    shown in the UI is simply a lie -- an operator reading "0 2 * * *"
    on a month-end feed has no way to know it does not run daily.

    ``to_legacy_fields`` has always been able to translate one into the
    other, and had no caller.  Three rules, at the one point the
    declaration is written:

    * no declaration -> nothing happens.  This is the overwhelming
      majority of feeds and their behaviour is byte-for-byte unchanged.
    * declaration, no cron -> derive and store, so the two vocabularies
      agree instead of one being blank.
    * declaration AND a contradicting cron -> REFUSE.  Overwriting the
      author's typed cron would be a silent surprise; keeping both is
      the lie above.  Two schedules on one feed is a mistake to fix at
      authoring, not a precedence rule to memorise.

    Advisory note: a translation that is not ``fully_expressed`` (a
    NEGATIVE workday_n, which the legacy ACTION_CONDITION vocabulary
    cannot say) still saves -- ``due_on`` implements it correctly -- and
    the reason is attached so nobody assumes the cron tells the whole
    story.
    """
    # READ the effective feed (stored + this edit), WRITE into the
    # payload.  On update ``config`` is the PATCH: reading it alone
    # sees an absent action_condition_sql where the stored feed has a
    # hand-written one, concludes "nothing to preserve", and
    # OVERWRITES it -- and misses a stored cron contradicting a newly
    # declared schedule, which is the one thing this exists to catch.
    # Every sibling refusal on that path already validates the merged
    # view, and the comment above them says why: an edit that is fine
    # in isolation can combine with a stored value into something
    # nothing honours.  I wrote this one against the patch anyway.
    view = effective if effective is not None else config
    decl = view.get("schedule_declaration")
    if not decl:
        return
    try:
        from core.feed.schedule import parse_schedule, to_legacy_fields
        schedule = parse_schedule(decl)
    except Exception as exc:
        # _refuse_invalid_schedule already 422s a malformed declaration;
        # reaching here means the module is absent or something new
        # broke, and losing the ability to save is the worse outcome.
        logger.error("[feed_api] schedule declaration could not be "
                     "translated to the legacy columns (%s) — cron fields "
                     "left as typed", exc)
        return
    if schedule is None:
        return
    try:
        legacy = to_legacy_fields(schedule)
    except Exception as exc:
        logger.error("[feed_api] to_legacy_fields failed for %r (%s) — "
                     "cron fields left as typed", decl, exc)
        return

    typed_cron = (view.get("cron_expression") or "").strip()
    derived_cron = (legacy.cron_expression or "").strip()
    if typed_cron and derived_cron and typed_cron != derived_cron:
        raise HTTPException(
            status_code=422,
            detail=(f"this feed declares a schedule ({schedule.kind}) AND a "
                    f"cron_expression {typed_cron!r} that does not match it "
                    f"(the declaration means {derived_cron!r}).  The "
                    f"declaration is what actually decides whether the feed "
                    f"runs, so the cron would be shown to operators and "
                    f"never consulted.  Remove one of the two."))
    if derived_cron and not typed_cron:
        config["cron_expression"] = derived_cron
    if legacy.timezone and not (view.get("timezone") or "").strip():
        config["timezone"] = legacy.timezone
    if legacy.calendar_name and not (view.get("calendar_name") or "").strip():
        config["calendar_name"] = legacy.calendar_name
    if legacy.action_condition and not (
            view.get("action_condition_sql") or "").strip():
        config["action_condition_sql"] = legacy.action_condition
    elif not legacy.action_condition and getattr(schedule, "business_date", "run_day") != "run_day":
        # 2026-10-13 -- the data's date is not the run day: a condition this
        # declaration GENERATED earlier (for the run day) would judge the
        # wrong date and skip every run.  Only the generated text is cleared;
        # a hand-written condition stays the author's.
        import dataclasses as _dc
        generated = to_legacy_fields(_dc.replace(schedule, business_date="run_day")).action_condition
        if generated and (view.get("action_condition_sql") or "").strip() == generated:
            config["action_condition_sql"] = None
    if not legacy.fully_expressed:
        logger.info(
            "[feed_api] feed %r: the legacy columns cannot fully express "
            "its schedule (%s) — due_on decides it, and that is correct; "
            "the cron shown is an approximation",
            view.get("name"), legacy.note)
        # Deliberately NOT stashed on ``config``: this dict goes
        # straight to the DAO, and an unknown key riding into a column
        # write is its own defect.  The author sees it through
        # _annotate_contract, which recomputes it for the response.


async def _refuse_dependency_cycle(feed: dict, etl_id: int,
                                   new_keys: list) -> None:
    """FR-DEP-22 — refuse a dependency CYCLE when it is TYPED, not at 3am.

    ``find_dependency_cycle`` has been written and tested since Foundation;
    until now its only callers were tests, so A-waits-on-B-waits-on-A was
    accepted at authoring and discovered as two feeds waiting forever, with
    the stale-run escalation reporting two unrelated failures hours later.

    The graph is built over feed identities: each feed with dependencies is
    a node (reachable by its NAME or its etl_id), its edges are its
    dependency keys, and a key that names another feed closes the loop.  A
    key naming no feed (an external upstream like APAC_POSITIONS) is a leaf
    and can never cycle.  The SAVING feed contributes the keys being saved,
    not its stored ones — the check answers "would this save create a
    cycle", before anything is written.

    Fails OPEN on ImportError (an older build must not lose the ability to
    save) and on any read error — but never silently: a dependency list
    saved unvalidated is a 3am page nobody was warned about.
    """
    try:
        from core.feed.dependency_gate import find_dependency_cycle
    except ImportError:
        logger.error("[feed_api] dependency_gate unavailable — feed %s "
                     "dependencies saved with cycles UNVALIDATED",
                     feed.get("id"))
        return
    cycle = None
    try:
        from core.feed.authoring_index import AuthoringIndex, dependency_graph
        this_id = int(feed["id"])
        # 2026-09-27 — every feed is a node under its EFFECTIVE etl_id
        # (explicit, else its own id).  This used to skip a feed whose
        # etl_id was NULL as "never saved dependencies", but mappings
        # can exist under the feed's id (the admin mappings route and
        # a save whose etl_id persist failed both leave it NULL), and
        # a cycle through such a feed was invisible here.
        # 2026-10-10 — the keys come from ONE query over every active
        # mapping (``AuthoringIndex.load``), not one query per feed: that
        # made a save O(N) queries and a template apply O(N^2).  A batch
        # in force (the template apply) supplies its own snapshot.
        idx = _authoring_index.get()
        if idx is None:
            idx = await adb(AuthoringIndex.load, _db_manager)
        graph = dependency_graph(
            idx.feeds(), idx.dependency_keys, this_id=this_id,
            this_etl_id=int(etl_id), new_keys=new_keys,
            effective_etl_id=_resolve_etl_id_for_feed)
        cycle = find_dependency_cycle(graph)
    except Exception as exc:
        # Deliberately outside this handler: the refusal below must never
        # be swallowed by the fail-open path.
        logger.error("[feed_api] dependency cycle check could not run (%s) "
                     "— feed %s dependencies saved UNVALIDATED", exc,
                     feed.get("id"))
        return
    if cycle:
        raise HTTPException(
            status_code=422,
            detail=f"these dependencies close a cycle: "
                   f"{' -> '.join(cycle)} — each feed in it would wait on "
                   f"the other(s) forever, surfacing at 3am as unrelated "
                   f"stale-run alerts.  Nothing was saved.  Remove one of "
                   f"the cycle's dependencies, or re-point it at the true "
                   f"upstream (an external key that names no feed is "
                   f"always safe).")


def _refuse_invalid_contract(config: dict) -> list:
    """FR-ART-01 — refuse an unsupported OUTPUT CONTRACT when it is
    TYPED, not when it is delivered.

    Encoding, quoting, terminator, packaging, checksum scope and PGP
    are CONTRACT TERMS, not preferences: a counterparty specifying
    latin-1, QUOTE_ALL and LF terminators is not negotiating.
    Discovering the renderer cannot honour that during the cutover of
    a live feed is the worst possible moment.

    Returns the UNSUPPORTED findings — things the platform cannot do
    yet — as warnings to surface on the response; raises 422 on real
    ERRORS (a checksum declared over pre-compression bytes, ZIP typed
    on the codec axis, an author-declared step order).  The split
    matters: refusing everything unbuilt would make the validator
    unusable, and warning about a checksum over bytes nobody receives
    would make it useless.

    Fails OPEN if the module is absent — an older build must not lose
    the ability to save a feed.
    """
    try:
        from core.feed.contract import (
            ContractRefused, contract_from_config, require_valid,
        )
    except ImportError:
        return []
    # Term extraction runs OUTSIDE the try: its own refusals
    # (HTTPException) must reach the caller, not be downgraded by the
    # catch-all below into "saved unvalidated".
    _terms = _contract_terms_from_feed(config)
    try:
        # ``require_valid`` IS the FR-ART-01 posture — validate, then
        # raise on every error AND every unsupported finding.  Calling
        # it rather than re-deriving the rule here is the point: this
        # function used to run validate_contract and apply its own
        # narrower rule, and the two drifted, which is how warn-and-save
        # survived a docstring that forbade it.  One implementation.
        result = require_valid(contract_from_config(_terms))
    except ContractRefused as exc:
        raise HTTPException(
            status_code=422,
            detail={"message": "output contract refused",
                    "findings": [f.to_dict() for f in exc.findings]})
    except Exception as exc:
        # A validator that cannot run must not block authoring, but a
        # silent skip is how an unvalidated contract reaches a
        # counterparty.
        logger.error("[feed_api] output-contract validation could not "
                     "run (%s) — the feed is saved UNVALIDATED", exc)
        return []
    # Only WARNINGS reach the caller — a key expiring in 30 days is
    # advisory by design and must not block a save.  Everything that
    # refuses came out of require_valid above as a 422.
    return [f.to_dict() for f in result.warnings]


def _contract_summary(config: dict) -> dict:
    """What this contract MEANS, in the validator's own words.

    ``describe_pipeline`` and ``deliverable_count`` both existed and
    were called by nothing, so an author declaring packaging + a codec +
    a checksum got a 200 and no way to see what they had actually asked
    for -- and the §10.2 trap (a stream codec never merges: gzip over
    1,000 parts is 1,000 .gz files, not the archive the counterparty
    wanted) stayed invisible until delivery.

    Advisory only.  A summary that cannot be built returns empty rather
    than blocking a save: the refusals are the validator's job, and this
    is the sentence explaining what SURVIVED them.
    """
    try:
        from core.feed.contract import (
            contract_from_config, deliverable_count, describe_pipeline,
        )
        contract = contract_from_config(_contract_terms_from_feed(config))
    except Exception as exc:
        # Including HTTPException: this is advisory and runs after the
        # write.  The extractor's own refusals reach the caller through
        # _refuse_invalid_contract, BEFORE anything is stored.
        logger.debug("[feed_api] contract summary unavailable: %s", exc)
        return {}
    try:
        return {
            "pipeline": list(describe_pipeline(contract)),
            # The order is the engine's, never the author's -- stated so
            # a counterparty's "unzip then decrypt" runbook can be
            # checked against it rather than assumed.
            "pipeline_order": "package -> compress -> encrypt -> checksum",
            "deliverables_from_1000_parts": deliverable_count(contract, 1000),
            "deliverables_from_1_part": deliverable_count(contract, 1),
        }
    except Exception as exc:
        logger.debug("[feed_api] contract summary could not be built: %s", exc)
        return {}


def _priority_advice(config: dict):
    """The reversed-priority nudge, non-refusing.

    1 = highest here (the OG-ETL convention the column itself
    documents), so 8 and 9 read as "most important" to anyone assuming
    higher-wins and are in fact the LOWEST tier.  A feed authored that
    way runs last on the worst morning -- exactly when its author
    believed it would run first.  The nudge existed with no caller.
    """
    if config.get("priority") is None:
        return None
    try:
        from core.feed.claims import priority_direction_warning
        return priority_direction_warning(config.get("priority"))
    except Exception:
        return None


def _schedule_expressiveness_note(config: dict):
    """What the legacy cron columns CANNOT say about this schedule.

    ``due_on`` implements the rule correctly either way; this exists so
    an operator reading the cron does not assume it tells the whole
    story.  A negative ``workday_n`` (third-last business day) is the
    case today's ACTION_CONDITION vocabulary cannot express.
    """
    decl = config.get("schedule_declaration")
    if not decl:
        return None
    try:
        from core.feed.schedule import parse_schedule, to_legacy_fields
        schedule = parse_schedule(decl)
        if schedule is None:
            return None
        legacy = to_legacy_fields(schedule)
        return None if legacy.fully_expressed else legacy.note
    except Exception:
        return None


def _annotate_contract(payload: dict, config: dict) -> dict:
    """Attach the advisory summary + nudge to a create/update response.

    One helper, three routes: create, quick-create and update each used
    to grow their own copy of this block, and a fourth route would have
    grown a fourth.
    """
    # NOTHING here may raise, HTTPException included.  This runs AFTER
    # the row is written, so an exception would hand the caller a 4xx
    # for a feed that WAS created — and the client's retry would create
    # a second one.  The refusals all fired before the write; this is
    # only the sentence explaining what survived them, and a missing
    # advisory field is a far smaller loss than a duplicate feed.
    #
    # (The first version re-raised HTTPException, which
    # _contract_terms_from_feed can throw for an FR-ACC-01 term.  It was
    # unreachable only because _refuse_invalid_contract normally calls
    # that same extractor first — unless the contract module is
    # unimportable, in which case it returns early and this became the
    # first caller.  A guard whose safety depends on an unrelated
    # function's happy path is not a guard.)
    try:
        summary = _contract_summary(config)
        if summary:
            payload["contract_summary"] = summary
    except Exception as exc:
        logger.debug("[feed_api] contract summary skipped: %s", exc)
    try:
        note = _priority_advice(config)
        if note:
            payload["priority_advice"] = note
        sched_note = _schedule_expressiveness_note(config)
        if sched_note:
            payload["schedule_note"] = sched_note
        drift = _partition_drift_advice(config)
        if drift:
            payload["partition_drift"] = drift
    except Exception as exc:
        logger.debug("[feed_api] advisory notes skipped: %s", exc)
    return payload


async def _hold_until_accepted(feed_id, feed: dict, data: dict) -> str:
    """FR-ACC-02 on EVERY door to live, not only the one named for it.

    The acceptance gate lived on POST /api/feeds/{id}/enable-schedule
    alone — and BOTH POST /api/feeds and PUT /api/feeds/{id} register the
    schedule themselves when ``schedule_enabled`` is true.  The editor
    sends that field on every save, so ticking the box went live without
    acceptance, straight past the control the BRD calls non-negotiable:

        "A feed goes live because its output was proved against its
         contract and a consumer signed it off — never because the
         platform produced a file without erroring."

    A control with two doors and a guard on one is not a control.  It is
    worse than none, because the audit trail says a gate exists.

    The feed LANDS DISABLED rather than the save being refused — the
    same posture a clone already takes ("the clone lands DISABLED"), and
    for the same reason: the author's work is legitimate and should be
    saved; what must not happen is the feed starting to RUN.  Returns a
    note for the response, or "" when nothing was held: an author who
    ticked the box and finds it unticked needs to know why, or it reads
    as the product losing their input.

    Scope and posture match the enable-schedule gate exactly, so a
    pre-existing estate is never bricked.
    """
    if not data.get("schedule_enabled"):
        return ""
    from core.feed import lifecycle as _lifecycle
    refusals = await adb(_lifecycle.acceptance_gate_refusals,
                         _db_manager, {**feed, "id": int(feed_id)})
    if not refusals:
        return ""
    data["schedule_enabled"] = False
    await adb(_db_manager.update_feed_config, int(feed_id),
              {"schedule_enabled": False})
    logger.info(
        "[feed_api] feed %s saved with schedule_enabled=false — "
        "acceptance not yet recorded (%d refusal(s))",
        feed_id, len(refusals))
    return ("Saved, but NOT scheduled: this feed has not completed "
            "acceptance. " + " ".join(refusals))


def _refuse_invalid_delivery_chain(chain) -> None:
    """BRD §11 / §14.2 — refuse a malformed delivery CHAIN when it is TYPED.

    ``core/feed/delivery_hops.build_hop_plan`` reads ``delivery_chain`` at
    delivery time; every refusal below is one that would otherwise fire —
    or worse, silently dead-end a hop — at 03:00 inside the engine.  A
    refusal at authoring costs a form submission; the same refusal at
    delivery costs the run.

    ABSENT (None) is the overwhelming majority of feeds and keeps the
    legacy single-hop path byte-for-byte unchanged — it returns
    immediately here.  PRESENT-but-empty is refused: an author who typed
    ``[]`` either meant "no chain" (spell that by omitting the field, or
    null on update) or lost their hops to a client bug; build_hop_plan
    would silently treat ``[]`` as the legacy path, and that ambiguity
    must not be stored.

    Fails OPEN if the delivery_hops module is absent — an older build
    must not lose the ability to save a feed — but never silently.
    """
    if chain is None:
        return
    try:
        from core.feed.delivery_hops import DEFAULT_TARGET_TRAITS
    except ImportError:
        logger.error(
            "[feed_api] delivery_hops module absent — the delivery_chain "
            "is saved UNVALIDATED and a malformed hop will surface at "
            "delivery time, not at authoring")
        return
    known = sorted(DEFAULT_TARGET_TRAITS)
    # `control_file` is a declared TRAIT (it is idempotent, it needs no
    # ack) but it is NOT a transport: the engine's hop transport routes on
    # target type through _deliver_to_destination, which knows
    # local/s3/sftp/oracle and nothing else.  A hop declaring it would be
    # accepted here, stored, and then hand the DATA FILE to a target with
    # no implementation at 03:00.  The control file already ships
    # alongside its data on every data hop, so the right spelling is a
    # real transport -- refusing is cheap, and a wrong file at a
    # counterparty is not.
    # A hop is authorable only if BOTH halves agree it exists: the
    # traits table (transport SEMANTICS — idempotent? needs an ack?) and
    # the live step REGISTRY the engine actually dispatches through.
    # These were two vocabularies free to drift, and this refusal read
    # only the first: a delivery step registered without traits was
    # accepted here and had no declared semantics at 03:00, while a
    # traits entry with no adapter was accepted here and hit
    # UnsupportedDeliveryTarget mid-delivery.  ``known_targets()`` is
    # the registry's own accessor and had no caller.
    #
    # `control_file` is a declared TRAIT (it is idempotent, it needs no
    # ack) but it is NOT a transport: a hop declaring it would be
    # accepted, stored, and then hand the DATA FILE to a target with no
    # implementation.  The control file already ships alongside its data
    # on every data hop, so the right spelling is a real transport.
    try:
        from core.feed.delivery_targets import known_targets
        registered = set(known_targets())
    except Exception as exc:
        # Fail OPEN to the traits table alone — the pre-2026-09-03
        # behaviour — rather than losing the ability to save a chain.
        logger.error("[feed_api] the delivery registry could not be read "
                     "(%s) — the chain is validated against the traits "
                     "table only", exc)
        registered = set(known)
    authorable = [t for t in known
                  if t != "control_file" and t in registered]
    _traits_only = sorted(set(known) - registered - {"control_file"})
    if _traits_only:
        logger.warning(
            "[feed_api] delivery targets declared in the traits table but "
            "NOT registered as steps: %s — unauthorable until an adapter "
            "registers them", ", ".join(_traits_only))
    if not isinstance(chain, list):
        raise HTTPException(status_code=422, detail=(
            f"delivery_chain must be a LIST of hop objects (got "
            f"{type(chain).__name__}) — e.g. "
            f'[{{"target": "local"}}, {{"target": "sftp", "label": '
            f'"counterparty", "config": {{"host": "..."}}}}]'))
    if len(chain) == 0:
        raise HTTPException(status_code=422, detail=(
            "delivery_chain is present but EMPTY.  An empty chain is "
            "ambiguous (the engine would silently fall back to single-hop "
            "destination_type delivery) — omit the field (or send null on "
            "update) to keep single-hop delivery, or declare at least one "
            "hop"))
    labels: list = []
    for i, entry in enumerate(chain):
        if not isinstance(entry, dict):
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}] must be a hop OBJECT like "
                f'{{"target": "sftp", "label": "...", "config": '
                f'{{...}}}} (got {type(entry).__name__})'))
        # EXACTLY the reader's resolution (build_hop_plan): "target"
        # first, then "target_type", lowercased.
        target_type = str(entry.get("target")
                          or entry.get("target_type") or "").lower()
        if not target_type:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}] declares no target — every hop "
                f'needs a "target", one of {authorable}'))
        if target_type == "control_file":
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}]: {target_type!r} is not a transport — "
                f"it describes WHAT is sent, not WHERE.  The control file "
                f"already ships alongside its data on every data hop, so "
                f"declare the real destination instead: one of "
                f"{authorable}"))
        if target_type not in known:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}]: unknown target {target_type!r} — "
                f"declared targets: {authorable}.  Idempotency is declared, "
                f"never assumed (FR-DEL-05), so an undeclared target "
                f"cannot be delivered to; pick a declared target"))
        label = str(entry.get("label") or target_type)
        if label in labels:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}]: duplicate hop label {label!r} — "
                f"delivery attempts are keyed (manifest_version, target, "
                f"attempt), so two hops sharing a label make their "
                f"attempt rows unattributable (§14.2).  Give each hop a "
                f'distinct "label"'))
        labels.append(label)
        cfg = entry.get("config")
        if cfg is not None and not isinstance(cfg, dict):
            raise HTTPException(status_code=422, detail=(
                f'delivery_chain[{i}] ({label!r}): "config" must be an '
                f"object of hop settings (got {type(cfg).__name__})"))
        # The key names below are the ones the DELIVERY ADAPTERS actually
        # read -- _deliver_sftp (host, remote_dir), _deliver_s3 (bucket,
        # prefix), _deliver_oracle (connection_id, table).  An earlier
        # wording named three keys no adapter looks at, so an author who
        # followed the refusal built a hop that saved happily and failed at
        # 03:00.  A refusal that names the wrong fix is worse than a terse
        # one; keep this message and those functions in step.
        if target_type in ("sftp", "s3", "oracle") and not cfg:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}] ({label!r}): a {target_type!r} hop "
                f'has NO destination — declare where it lands in "config": '
                f"host + remote_dir for sftp, bucket + prefix for s3, "
                f"connection_id + table for oracle.  A destination-less hop "
                f"can only fail at delivery time"))
        ma = entry.get("max_attempts")
        if ma is not None:
            try:
                int(ma)
            except (TypeError, ValueError):
                raise HTTPException(status_code=422, detail=(
                    f"delivery_chain[{i}] ({label!r}): max_attempts must "
                    f"be an integer (got {ma!r}) — the plan builder would "
                    f"crash on it at delivery time"))
    # ``requires`` names the hop whose success this one consumes.  A
    # reference to a label not in THIS chain — or to itself — can never
    # be satisfied on a fresh manifest version: the hop would be SKIPPED
    # on every run, silently, forever.  ``"requires": null`` (explicit
    # independence) is valid and passes through.
    for i, entry in enumerate(chain):
        req = entry.get("requires")
        if req is None:
            continue
        label = str(entry.get("label")
                    or str(entry.get("target")
                           or entry.get("target_type") or "").lower())
        if str(req) == label:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}] ({label!r}) requires ITSELF — it "
                f'would be skipped on every run.  Drop "requires" (or '
                f"set it null) or name another hop's label"))
        if str(req) not in labels:
            raise HTTPException(status_code=422, detail=(
                f"delivery_chain[{i}] ({label!r}) requires {str(req)!r}, "
                f"which is not a hop label in this chain (labels: "
                f"{labels}) — it would be skipped on every run.  Name "
                f"another hop's label, or null for independence"))


@router.post("/api/feeds")
async def create_feed(body: FeedConfigCreate, user: dict = Depends(get_current_user),
                      clone_of: Optional[int] = None):
    """Create a new feed configuration.

    ``?clone_of=<id>`` (2026-10-13): this new feed is a CLONE of that feed,
    made in the full form (every field may differ).  Used ONLY to fill a
    secret the form shows as ``***`` (an SFTP password ...) from the
    SOURCE's stored value -- secrets never travel to the browser.  The caller
    must be allowed to edit the source.  An instruction for this request,
    not a property of the feed: it is in the URL, never in the body, and
    never stored."""
    # ── Feed identity (2026-09-02, BRD §14.3 / D5 / FR-ID-01..02) ────────
    # Shape is validated HERE, at authoring — never sanitised silently and
    # never left to fail at 3am inside the engine.  Uniqueness is enforced
    # here too because feed_configs.name has an index but no unique
    # constraint (models.py owned by in-flight work): the name feeds the
    # Netcool AlertKey, output filenames, archive keys and git filenames,
    # all of which assume it is unique.
    from core.feed.identity import validate_feed_name, name_advice
    try:
        validate_feed_name(body.name)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    _dup_ids = await adb(_db_manager.get_feed_ids_by_name, body.name)
    if _dup_ids:
        raise HTTPException(
            status_code=409,
            detail=f"Feed name {body.name!r} is already used by feed id "
                   f"{_dup_ids[0]} (names are unique per environment: "
                   f"alert keys, filenames and archive keys are built "
                   f"from them). Choose a different name.")
    _identity_warnings = name_advice(body.name)
    data = body.model_dump(exclude_none=True)
    _clone_of = clone_of
    if _clone_of is not None:
        _src = await _require_feed(int(_clone_of), user, write=True)
        for _fld in ("destination_config", "backend_config", "delivery_chain"):
            if data.get(_fld) is not None and _src.get(_fld) is not None:
                data[_fld] = _unmask_secret_tree(data[_fld], _src.get(_fld))
    # FR-ART-01 — the output contract is validated HERE, at authoring.
    _contract_warnings = _refuse_invalid_contract(data)
    _refuse_invalid_shape(data)
    _refuse_invalid_filename_template(data)
    _refuse_unknown_source_type(data)
    _refuse_incomplete_second_side(data)
    await _refuse_invalid_token_bindings(data)
    # 2026-10-12 -- every PARAMETER token the query uses has a value
    await _refuse_unvalued_parameters(data)
    _refuse_filename_collision(data)
    _refuse_invalid_schedule(data)
    await _refuse_unknown_upstream_feed(data, body.name)
    _refuse_invalid_sla(data)
    _sync_legacy_schedule_fields(data)
    # BRD §11 / §14.2 — a malformed delivery chain is refused when the
    # author SAVES it, not discovered when the 03:00 delivery fails.
    _refuse_invalid_delivery_chain(data.get("delivery_chain"))
    data["created_by"] = user.get("username", "unknown")
    # Phase 132.38 — embed the WHERE-mapping inside query_params before
    # the row hits the DB.  Static rows freeze; Dynamic rows declare
    # override slots for the external trigger.
    _embed_where_mapping_in_query_params(data, body.where_clauses,
                                          clear_when_empty=True)

    # SSRF validation on webhook URL (Phase 132-A)
    if body.notify_webhook:
        try:
            from core.url_safety import validate_url_safety
            validate_url_safety(body.notify_webhook)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"Webhook URL blocked: {exc}")

    # Validate destination_config is not empty for non-local.
    # Same rule as PUT -- see _refuse_empty_destination_config.
    _refuse_empty_destination_config(
        {"destination_type": body.destination_type,
         "destination_config": body.destination_config})
    _refuse_output_format_destination_mismatch(
        {"destination_type": body.destination_type,
         "output_format": body.output_format})

    # ── Cross-source preflight (2026-08-04) ──────────────────────────────
    # A cross-connection feed that cannot work must be refused HERE, with
    # the fix named, not at 3 AM when the scheduled run fires.  ERROR
    # verdicts block the save; warnings ride along in the response.  A
    # crash inside the checker itself never blocks a save (fail-open for
    # the probe, fail-closed for real verdicts).
    _cross_pf = await _run_cross_source_preflight(data)
    if _cross_pf is not None and not _cross_pf.ok:
        raise HTTPException(status_code=400, detail=_cross_pf.format_report())

    await _require_valid_calendar_name(data.get("calendar_name"))
    # 2026-09-02 — the operational group must EXIST and be active, same
    # as the calendar reference two lines up.
    await _require_valid_feed_group_id(data.get("feed_group_id"))
    # 2026-09-28 -- and every declared consumer group.
    await _require_valid_consumer_group_ids(data.get("consumer_group_ids"))

    result = await adb(_db_manager.create_feed_config, data)
    logger.info("Feed config created: id=%d name=%s by=%s", result["id"], result["name"], data["created_by"])

    # FR-ACC-02 / FR-SEC-10 (2026-09-03) — every NEWLY onboarded feed is
    # stamped as requiring acceptance sign-off + a PII declaration
    # before its schedule can be enabled.  Feeds existing before this
    # stamp carry no record and are exempt (stated posture: shipping the
    # gate must not brick the running estate).
    from core.feed import lifecycle as _lifecycle
    await adb(_lifecycle.stamp_onboarding, _db_manager, result["id"],
              data["created_by"])

    # Auto-register schedule if enabled — unless acceptance holds it.
    # stamp_onboarding above marks a NEW feed acceptance-required, so a
    # feed created five seconds ago is always held: it has never run, so
    # nothing can have been proved against its contract and no consumer
    # can have signed anything off.
    _accept_note = await _hold_until_accepted(
        result["id"], result, {"schedule_enabled": bool(body.schedule_enabled)})
    if _accept_note:
        result["schedule_enabled"] = False
    elif body.schedule_enabled and body.cron_expression:
        _register_schedule(result["id"], body.cron_expression, body.timezone, result["name"])
    _note_authored_feed(result)
    # 2026-10-13 -- version 1 is the CREATION, saved by its author (the
    # owner: "who modified config when ... versions").  Only edits recorded a
    # version, so a feed's first version appeared when it first RAN, with no
    # author.  Same writer as an edit (deduplicated by hash), fail-open.
    from core.feed.definition_history import record_version as _record_version
    await adb(_record_version, _db_manager, result["id"],
              created_by=user.get("username"), feed_config=result)

    # SECURITY AUDIT 2026-08-03 (S4): POST skipped the credential masking the
    # GET routes apply, echoing SFTP passwords / aws_secret_access_key back
    # to the browser (and into proxies/log capture).  The client just TYPED
    # these values — it never needs them echoed.
    masked = _mask_feed_secrets(result)
    if _accept_note:
        masked["acceptance_hold"] = _accept_note
    # Surface cross-source preflight warnings (dialect mismatch, on-prem
    # access-mode context) so the UI can show them next to the saved feed.
    if _cross_pf is not None and _cross_pf.issues:
        masked["cross_source_preflight"] = _cross_pf.to_dict()
    # FR-ID-03 — ADVISORY naming warnings (mutable facts in the name).
    # Never blocks: such names are already in live use elsewhere.
    if _identity_warnings:
        masked["name_advice"] = _identity_warnings
        logger.warning("Feed %d name %r: %s", result["id"],
                       result["name"], "; ".join(_identity_warnings))
    _annotate_contract(masked, data)
    if _contract_warnings:
        masked["contract_unsupported"] = _contract_warnings
        logger.warning(
            "Feed %d output contract has %d unsupported term(s): %s",
            result["id"], len(_contract_warnings),
            "; ".join(f.get("message", "") for f in _contract_warnings))
    return masked


#: Clone whitelist (2026-09-03) — EXPLICIT so every exclusion is a
#: decision, not an accident.  Copied: everything that makes the feed
#: what it is (source, shape/contract via query_params + output_options,
#: schedule DECLARATION, delivery, ownership, SLA, controls).
#: NOT copied, each for a stated reason (see clone_feed docstring):
#: name/display_name (identity), schedule_enabled/apscheduler_job_id
#: (a clone lands DISABLED), etl_id (dependency rows are RE-KEYED to the
#: clone's own id), run history/stats (last_execution_id, next_run_at,
#: run_count, last_row_count), created_by/at (the cloner's).
#: NOTE for future columns: a NEW authored column on FeedConfig must be
#: added here to be cloned — the twin-list hazard is accepted and pinned
#: by test_clone_whitelist_covers_authorable_columns.
#: The patch keys that re-judge the SECOND SIDE / the TOKEN BINDINGS on update.
_SECOND_SIDE_KEYS = ("secondary_connection_id", "secondary_source_type",
                     "secondary_source_id", "combine_mode", "query_params")
_TOKEN_BINDING_KEYS = ("token_bindings", "query_params", "source_type", "source_id",
                       "connection_id") + _SECOND_SIDE_KEYS

_CLONE_COPY_FIELDS = (
    "description", "source_type", "source_id", "connection_id",
    "query_params", "output_format", "output_filename_template",
    "output_options", "destination_type", "destination_config",
    "delivery_chain", "execution_backend", "backend_config",
    "size_threshold_rows", "estimated_row_count",
    "cron_expression", "schedule_declaration", "timezone",
    "frequency_category",
    "notify_on_success", "notify_on_failure", "notify_emails",
    "notify_webhook", "max_retries", "retry_delay_seconds",
    "file_type_code", "priority", "valid_from", "valid_until",
    "sla_from", "sla_to", "calendar_name", "action_condition_sql",
    "control_file_template", "control_file_format_id",
    "secondary_connection_id", "secondary_source_type",
    "secondary_source_id", "combine_mode", "join_config",
    "token_bindings",
    "owner_group_id", "feed_group_id", "task_type",
    "row_count_threshold_pct", "row_count_action",
    "integrity_check_enabled",
    # 2026-09-28 -- the consumer declaration is part of what the feed IS
    # (its audience); a clone serves the same consumers until re-declared.
    "consumer_group_ids",
    # 2026-09-03 — columns the schema workstream added the same day
    # (caught by test_clone_whitelist_covers_authorable_columns, which
    # is the tripwire doing its job): all authored config, all copied.
    "expected_runtime_seconds", "row_count_expect_zero",
    "row_count_min_rows", "row_count_threshold_pct_down",
    "row_count_threshold_pct_up", "skip_requires_second_approver",
    "row_count_compare_to",
    "sla_timezone",
    # 2026-09-05 — the step FLOW mapping.  COPIED, deliberately: a
    # clone is the same shape of feed, so it runs the same steps.
    # Dropping it would give the clone a silently SHORTER pipeline
    # than the feed it was cloned from — a missing quality gate that
    # looks like a feed which never had one.
    "flow_id",
)


def _scrub_mask_literals(tree, _path=""):
    """Drop any credential-shaped key whose value is the literal '***'
    mask.  The clone copies the STORED row (never a masked response), so
    this should find nothing — but a mask that leaked into storage
    through an old round-trip bug must not be perpetuated as a
    "password".  Returns (clean_copy, dropped_paths)."""
    dropped: list = []
    if isinstance(tree, dict):
        out = {}
        for k, v in tree.items():
            child = f"{_path}.{k}" if _path else str(k)
            if v == "***" and _is_secret_key(k):
                dropped.append(child)
                continue
            clean, sub = _scrub_mask_literals(v, child)
            out[k] = clean
            dropped.extend(sub)
        return out, dropped
    if isinstance(tree, list):
        out_l = []
        for i, item in enumerate(tree):
            clean, sub = _scrub_mask_literals(item, f"{_path}[{i}]")
            out_l.append(clean)
            dropped.extend(sub)
        return out_l, dropped
    return tree, dropped


def _copy_dependency_mappings(source_etl_id: int, new_etl_id: int) -> int:
    """Copy EVERY dependency mapping row (active AND inactive — an
    inactive row is authored config too) from the source's etl scope to
    the clone's.  Reads raw because list_etl_dependency_mappings
    hard-filters active rows and a clone silently losing half its gate
    is the failure this copy exists to prevent."""
    from core.db.models import EtlDependencyMapping
    rows: list = []
    with _db_manager.get_session(read_only=True) as session:
        for m in (session.query(EtlDependencyMapping)
                  .filter(EtlDependencyMapping.etl_id == int(source_etl_id))
                  .all()):
            rows.append({
                "dependency_type_id": m.dependency_type_id,
                "dependency_key": m.dependency_key,
                "description": m.description,
                "calendar_name": m.calendar_name,
                "expected_rows": m.expected_rows,
                "is_active": bool(m.is_active),
            })
    for r in rows:
        _db_manager.create_etl_dependency_mapping({
            "etl_id": int(new_etl_id), **r})
    return len(rows)


class CloneFeedRequest(BaseModel):
    """Body of POST /api/feeds/{feed_id}/clone."""
    name: str = Field(..., min_length=1, max_length=255)
    display_name: Optional[str] = Field(default=None, max_length=255)
    #: Omitted = copy the source's group; explicit null = ungrouped.
    feed_group_id: Optional[int] = None
    #: 2026-10-13 -- the clone's OWN file name.  A clone delivering to the
    #: same destination with the source's name is refused (FR-ART-10: one
    #: would overwrite the other), so without this a delivering feed could
    #: never be cloned at all.  Omitted = the source's (refused if it collides).
    output_filename_template: Optional[str] = Field(default=None, min_length=1, max_length=500)


@router.post("/api/feeds/{feed_id}/clone", status_code=201)
async def clone_feed(feed_id: int, body: CloneFeedRequest,
                     user: dict = Depends(get_current_user)):
    """Clone a feed: same configuration, NEW identity, landing DISABLED.

    Copied: source + query_params (partition shape, WHERE mapping,
    source blocks — the bag is copied whole), schedule DECLARATION and
    cron text, calendar, contract/output options, delivery chain +
    legacy destination, ownership groups, SLA fields, control-file
    config, cross-source config, run controls — and the DEPENDENCY
    MAPPINGS, re-keyed to the clone's own id (a clone without its gate
    would ship on mornings its inputs never arrived).

    NOT copied, deliberately:
    * ``name`` — identity (unique, immutable once run); the new one is
      validated by the SAME rules as create and a duplicate 409s;
    * ``schedule_enabled`` — the clone lands DISABLED.  Going live is
      the same explicit act as for any new feed: acceptance run →
      sign-off → enable-schedule (the clone is stamped with the
      FR-ACC-02 acceptance requirement like every new feed);
    * run history / executions / build ids / pinned versions / etl_id /
      run stats — a clone is a new feed, not a fork of a run;
    * lifecycle state except PII: the PII declaration IS copied (same
      source data, provenance recorded); acceptance and legal hold are
      not — a clone earns its own sign-off and carries no hold.

    Credentials: the clone copies the source's STORED destination /
    backend / hop configs verbatim (the caller holds edit rights on the
    source, which is what those configs belong to).  Any literal '***'
    mask found in storage is DROPPED, never persisted as a password,
    and the response names what was dropped.
    """
    source = await _require_feed(feed_id, user, write=True)
    username = user.get("username", "unknown")

    # Identity — the SAME rules as create, not a second spelling.
    from core.feed.identity import validate_feed_name, name_advice
    try:
        validate_feed_name(body.name)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    _dup_ids = await adb(_db_manager.get_feed_ids_by_name, body.name)
    if _dup_ids:
        raise HTTPException(
            status_code=409,
            detail=f"Feed name {body.name!r} is already used by feed id "
                   f"{_dup_ids[0]} (names are unique per environment). "
                   f"Choose a different name.")
    _identity_warnings = name_advice(body.name)

    data: Dict[str, Any] = {}
    for fld in _CLONE_COPY_FIELDS:
        val = source.get(fld)
        if val is not None:
            data[fld] = val
    # to_dict() serialised Date columns to ISO strings; the DAO does raw
    # FeedConfig(**data), so hand real dates back or the clone row (and
    # its later to_dict) breaks on the string.
    for _dfld in ("valid_from", "valid_until"):
        if isinstance(data.get(_dfld), str):
            try:
                data[_dfld] = datetime.fromisoformat(
                    data[_dfld][:10]).date()
            except ValueError:
                data.pop(_dfld, None)
    data["name"] = body.name
    if body.display_name is not None:
        data["display_name"] = body.display_name
    if body.output_filename_template is not None:
        data["output_filename_template"] = body.output_filename_template
    if "feed_group_id" in body.model_fields_set:
        if body.feed_group_id is None:
            data.pop("feed_group_id", None)
        else:
            data["feed_group_id"] = int(body.feed_group_id)
    # A clone lands DISABLED.  There is deliberately NO assignment here:
    # ``schedule_enabled`` is excluded from _CLONE_COPY_FIELDS (pinned by
    # test_clone_whitelist_covers_authorable_columns) and the column
    # default is False — a redundant second write survived mutation
    # testing (it could not fail observably), so it was removed rather
    # than kept as a guard that cannot fail.
    data["is_active"] = True
    data["created_by"] = username

    # Never persist a mask literal as a credential.
    _dropped_masks: List[str] = []
    for _fld in ("destination_config", "backend_config", "delivery_chain"):
        if _fld in data:
            data[_fld], _d = _scrub_mask_literals(data[_fld], _fld)
            _dropped_masks.extend(_d)

    # The clone is judged by the SAME authoring validators as create —
    # a legacy config that predates a validator is refused with the fix
    # named, not silently propagated into a second feed.
    _contract_warnings = _refuse_invalid_contract(data)
    _refuse_invalid_shape(data)
    _refuse_invalid_filename_template(data)
    _refuse_unknown_source_type(data)
    _refuse_incomplete_second_side(data)
    await _refuse_invalid_token_bindings(data)
    _refuse_filename_collision(data)
    _refuse_invalid_schedule(data)
    await _refuse_unknown_upstream_feed(data, body.name)
    _refuse_invalid_sla(data)
    _sync_legacy_schedule_fields(data)
    _refuse_invalid_delivery_chain(data.get("delivery_chain"))
    await _require_valid_calendar_name(data.get("calendar_name"))
    await _require_valid_feed_group_id(data.get("feed_group_id"))

    result = await adb(_db_manager.create_feed_config, data)
    new_id = int(result["id"])
    _note_authored_feed(result)

    # Dependency mappings — re-keyed to the clone's own id.  A failure
    # here must be LOUD: the clone exists but its gate does not, which
    # is exactly the silent loss the copy exists to prevent.
    copied_deps = 0
    dep_copy_error: Optional[str] = None
    source_etl_id = _resolve_etl_id_for_feed(source)
    try:
        copied_deps = await adb(_copy_dependency_mappings,
                                source_etl_id, new_id)
        if copied_deps:
            # Same as replace_feed_dependencies (Phase 131-A): persist
            # etl_id so the dependency poller's filter catches the clone.
            await adb(_db_manager.update_feed_config, new_id,
                      {"etl_id": new_id})
            result["etl_id"] = new_id
    except Exception as exc:
        dep_copy_error = (
            f"clone created but its dependency mappings could NOT be "
            f"copied ({exc}) — the clone currently has NO dependency "
            f"gate.  Re-add them via PUT /api/feeds/{new_id}/dependencies "
            f"before enabling the schedule.")
        logger.error("[feed_api] clone %d of feed %d: dependency copy "
                     "failed", new_id, feed_id, exc_info=True)

    # Onboarding stamp (FR-ACC-02 / FR-SEC-10) — the clone must earn its
    # own acceptance; the PII declaration travels with the data.
    from core.feed import lifecycle as _lifecycle
    _src_pii = await adb(_lifecycle.get_aspect, _db_manager, feed_id,
                         "pii")
    await adb(_lifecycle.stamp_onboarding, _db_manager, new_id, username,
              cloned_from=feed_id, copy_pii_from=_src_pii)

    _audit("feed_cloned", user, {
        "source_feed_id": feed_id, "new_feed_id": new_id,
        "name": body.name, "copied_dependencies": copied_deps,
        "dropped_mask_literals": _dropped_masks,
    })
    logger.info("Feed %d cloned to %d (%r) by %s: %d dependency row(s) "
                "copied", feed_id, new_id, body.name, username,
                copied_deps)

    masked = _mask_feed_secrets(result)
    response = {
        "detail": "Feed cloned — it lands DISABLED; run the acceptance "
                  "run, record the sign-off, then enable the schedule.",
        "feed": masked,
        "cloned_from": {"feed_id": feed_id, "name": source.get("name")},
        "copied_dependencies": copied_deps,
        "schedule_enabled": False,
        "next_steps": [
            f"PUT /api/feeds/{new_id}/pii-declaration (copied from the "
            f"source when the source had one)",
            f"POST /api/feeds/{new_id}/execute — the acceptance run",
            f"POST /api/feeds/{new_id}/acceptance/sign-off",
            f"POST /api/feeds/{new_id}/enable-schedule",
        ],
    }
    if dep_copy_error:
        response["dependency_copy_error"] = dep_copy_error
    if _dropped_masks:
        response["dropped_mask_literals"] = _dropped_masks
        response["credentials_note"] = (
            "the source row carried literal '***' placeholders for these "
            "keys; they were NOT copied — set real credentials on the "
            "clone before its first delivery")
    if _identity_warnings:
        response["name_advice"] = _identity_warnings
    _annotate_contract(response, data)
    if _contract_warnings:
        response["contract_unsupported"] = _contract_warnings
    return response


@router.get("/api/feeds")
async def list_feeds(
    source_type: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    user: dict = Depends(get_current_user),
):
    """List feed configurations with optional filters.

    Filtered to the feeds the caller may VIEW (owner / group / admin / support,
    with unclaimed feeds org-shared) so the list route can't be used to
    enumerate other users' private feeds — the same gate ``get_feed`` applies
    to the single-object route.  Delivery credentials are then masked."""
    rows = await adb(_db_manager.list_feed_configs, source_type=source_type, is_active=is_active)
    visible = await adb(_filter_visible_feeds, rows, user)
    # Mask delivery credentials so a reader can't harvest S3/SFTP secrets.
    return [_mask_feed_secrets(r) for r in visible]


@router.get("/api/feeds/frequency-categories")
async def list_frequency_categories(user: dict = Depends(get_current_user)):
    """BF-473 — suggested vocabulary for the frequency_category field.

    The field itself is an open string column on FeedConfig, so admins
    can add new categories without a code change.  This endpoint
    powers the admin UI dropdown with the suggestions baseline +
    any custom values already in use in the database (so a category
    typed by one admin is offered to the next).
    """
    suggested = [
        {"value": "sod",       "label": "SOD — Start of Day"},
        {"value": "intraday",  "label": "Intraday — periodic refresh"},
        {"value": "eod",       "label": "EOD — End of Day"},
        {"value": "daily",     "label": "Daily — generic daily feed"},
        {"value": "monthly",   "label": "Monthly — month-end / workday-N"},
        {"value": "custom",    "label": "Custom — schedule via ACTION_CONDITION"},
    ]
    # Pull any custom categories already in use so admins see what
    # their team has chosen previously.  Cheap — feed_configs is
    # small (<10k rows in practice).
    try:
        in_use = _db_manager.list_distinct_frequency_categories() or []
    except Exception:
        in_use = []
    seen = {s["value"] for s in suggested}
    for cat in in_use:
        if cat and cat not in seen:
            suggested.append({"value": cat, "label": cat})
            seen.add(cat)
    return {"categories": suggested}


@router.get("/api/feeds/defaults")
async def get_feed_defaults(user: dict = Depends(get_current_user)):
    """2026-07-22 — sensible defaults for the feed-config form.

    Surfaces the platform's configured DEFAULT output directory (the NFS
    ``feed_generation.output_dir``) so the "Output Directory" field can be
    PRE-FILLED with the real path instead of a hardcoded ``data/feeds`` literal.
    The user can still type any path they want (that is the override); a local
    destination left blank falls back to this same default on the server, and
    the directory is created (``mkdir -p``) at delivery if it does not yet exist.
    Also returns the allowed roots so the UI can hint where local delivery is
    permitted.  Fail-open: any resolution error yields the documented fallback.
    """
    default_output_dir = "/usr/local/querystudioapi/nfs/data/feeds"
    allowed_roots: list = []
    try:
        from core.config import feed_generation as _fg
        default_output_dir = str(_fg.output_dir) or default_output_dir
        try:
            allowed_roots = list(_fg.local_destination_allowed_roots or [])
        except Exception:
            allowed_roots = []
    except Exception:
        pass
    return {
        "default_output_dir": default_output_dir,
        "local_destination_allowed_roots": allowed_roots,
    }


@router.get("/api/feeds/backend-options")
async def get_backend_options(user: dict = Depends(get_current_user)):
    """The execution-backend picker, REGISTRY-DRIVEN (2026-08-22).

    One entry per ``backend_router.VALID_BACKENDS`` (plus ``auto``
    first), with label/capabilities from the ONE capability registry
    (``source_plan.BACKEND_CAPABILITIES``) and availability from the
    same probes the router itself uses — so the UI can never offer a
    backend the router does not know, nor carry its own hardcoded list
    (the second-source-of-truth defect class).

    Registered BEFORE ``GET /api/feeds/{feed_id}`` — the path parameter
    would otherwise swallow this route (an ordering trap that is live in
    this file).

    Availability is FAIL-OPEN with the reason surfaced: a broken probe
    reports ``available=false`` + its describe()/error text rather than
    500ing the picker.
    """
    from core.feed.backend_router import VALID_BACKENDS
    from core.feed.source_plan import BACKEND_CAPABILITIES

    options = [{
        "value": "auto",
        "label": "Auto (size-based routing)",
        "available": True,
        "availability_detail": "",
        "capabilities": {},
    }]
    from core.feed.backend_router import lane_availability
    for name in VALID_BACKENDS:
        caps = dict(BACKEND_CAPABILITIES.get(name) or {})
        label = caps.pop("label", None) or name
        # 2026-10-07 -- THE availability decision the router uses
        # (backend_router.lane_availability), never a second probe here.
        # ``airflow_breaker_open`` is the engine's breaker, read as it
        # reads it.
        try:
            from core import feed_engine as _fe_bo
            _brk = getattr(_fe_bo, "_airflow_breaker", None)
            _av = lane_availability(
                name, airflow_breaker_open=bool(_brk and _brk.is_open))
            available = bool(_av.available)
            detail = ("" if (available and name != "spark_k8s")
                      else str(_av.describe()))
        except Exception as _av_exc:
            available = False
            detail = f"probe failed: {type(_av_exc).__name__}"
        options.append({
            "value": name,
            "label": label,
            "available": available,
            "availability_detail": detail,
            "capabilities": caps,
        })
    return {"options": options}


@router.get("/api/feeds/{feed_id}")
async def get_feed(feed_id: int, user: dict = Depends(get_current_user)):
    """Get a single feed configuration."""
    feed = await _require_feed(feed_id, user, write=False)
    return _mask_feed_secrets(feed)


@router.get("/api/feeds/{feed_id}/summary")
async def get_feed_summary(feed_id: int, user: dict = Depends(get_current_user)):
    """The feed's WHOLE configuration in words (core/feed/summary.py) -- the
    board's "Configuration" view (2026-10-13).  Same view rule as the feed;
    secrets never leave (the destination is read masked)."""
    from core.feed import summary
    feed = await _require_feed(feed_id, user, write=False)
    return await adb(summary.describe, _db_manager, feed, masked=_mask_feed_secrets(feed))


class FeedDraftResolveRequest(BaseModel):
    """A feed DRAFT as the authoring form holds it (2026-10-11): the fields
    that decide what runs.  Everything else the form knows is irrelevant to
    the answer and not accepted here."""
    model_config = {"extra": "ignore"}
    id: Optional[int] = None
    source_type: Optional[str] = None
    source_id: Optional[int] = None
    connection_id: Optional[int] = None
    query_params: Optional[dict] = None
    secondary_connection_id: Optional[int] = None
    secondary_source_type: Optional[str] = None
    secondary_source_id: Optional[int] = None
    combine_mode: Optional[str] = None
    join_config: Optional[dict] = None
    token_bindings: Optional[List[dict]] = None


def _draft_saved_query_visible(user: dict, source_type: Any, source_id: Any) -> None:
    """A draft may name a saved query only if the caller may READ it (the
    saved-query routes' own rule, api.deps.is_owner_or_shared); 404 so the
    route is not an existence oracle."""
    if not _auth_on() or str(source_type or "") != "saved_query" or not source_id:
        return
    from api.deps import is_owner_or_shared
    try:
        row = _db_manager.get_query(int(source_id))
    except Exception:
        row = None
    if row is None or not is_owner_or_shared(row, user):
        raise HTTPException(status_code=404, detail=f"Saved query {source_id} not found")


@router.post("/api/feeds/resolve-draft")
async def resolve_feed_draft(body: FeedDraftResolveRequest,
                             user: dict = Depends(get_current_user)):
    """What this feed DRAFT would run -- read-only, for the authoring form
    (2026-10-11; core/feed/authoring_draft.py).  Each side's SQL through the
    run's own resolver, its LITERAL predicates (to bind to tokens), the
    merge-by-name disclosure, whether the primary saved query already carries
    its own second side, and every binding's verdict.  Nothing executes."""
    from core.feed.authoring_draft import resolve_draft
    from core.roles import is_admin_like as _adm
    if _auth_on() and not _adm(user) and (user or {}).get("role") not in ("analyst", "admin"):
        raise HTTPException(status_code=403, detail="Feed authoring requires the analyst or admin role")
    draft = body.model_dump(exclude_none=True)
    _draft_saved_query_visible(user, draft.get("source_type"), draft.get("source_id"))
    if draft.get("secondary_connection_id"):
        _draft_saved_query_visible(
            user, draft.get("secondary_source_type") or draft.get("source_type"),
            draft.get("secondary_source_id") or draft.get("source_id"))
    try:
        return await adb(resolve_draft, _db_manager, draft)
    except Exception as exc:  # noqa: BLE001 -- the form must hear WHY, never a 500
        logger.warning("resolve_feed_draft failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=422, detail=f"The draft could not be resolved: {exc}")


@router.get("/api/feeds/{feed_id}/preview-sql")
async def preview_feed_sql(feed_id: int, user: dict = Depends(get_current_user)):
    """Return the SQL this feed would execute — without running it.

    Resolves the feed's source (saved_query / sql_file / published_view /
    raw_sql) and any cross-connection secondary side to the actual SQL
    strings.  Read-only: no DuckDB connection, no S3 access, no DB write.
    Surfaces structured ``source_status`` ("ok" | "not_found" | "inactive"
    | "missing_file" | "empty") instead of raising so the UI can show
    *why* a feed won't run.
    """
    feed = await _require_feed(feed_id, user, write=False)
    try:
        from core.feed_sql_resolver import resolve_feed_sql
        preview = await adb(resolve_feed_sql, _db_manager, feed)
        return {
            "feed_id": feed_id,
            "feed_name": feed.get("name"),
            **preview,
        }
    except Exception as exc:
        logger.warning("preview_feed_sql failed for feed %d: %s", feed_id, exc, exc_info=True)
        # Don't echo the raw internal exception to the caller (leaks internals).
        raise HTTPException(status_code=500, detail="Could not resolve feed SQL for this feed.")


@router.get("/api/feeds/{feed_id}/source-plan")
async def get_feed_source_plan(feed_id: int, user: dict = Depends(get_current_user)):
    """Serialized source plan for the Airflow/Spark-batch backend (2026-08-04).

    Resolves the feed's source shape through the SAME chokepoint every
    backend uses (``core.feed.source_plan``) and returns the serialized
    plan the detached Spark job executes — the DAG factory
    (``airflow/dags/querystudio_feed_factory.py``) calls this at spec-build
    time so ``generic_feed.py`` executes a resolved plan instead of
    re-resolving sources with its own parallel logic.

    Responses:
      * 200 ``{"source_plan": {...}}``  — plan for the job to execute.
      * 200 ``{"source_plan": null}``   — out-of-vocabulary / pre-extracted
        config; the caller ships the legacy conf unchanged.
      * 422 — the feed's source shape is REFUSED fail-closed (partial cross
        config, unsplit-marker sql_file on a single-source feed, ...).  The
        detail names the fix; the caller must NOT fall back to the legacy
        conf (that would silently run the defective shape).
    """
    feed = await _require_feed(feed_id, user, write=False)
    from core.feed.airflow_plan import build_serialized_plan
    try:
        plan = await adb(build_serialized_plan, _db_manager, feed)
    except ValueError as exc:
        # Deliberate fail-closed refusal — the message already names the fix.
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        logger.warning("get_feed_source_plan failed for feed %d: %s",
                       feed_id, exc, exc_info=True)
        raise HTTPException(status_code=500,
                            detail="Could not resolve the feed's source plan.")
    return {"feed_id": feed_id, "feed_name": feed.get("name"),
            "source_plan": plan}


@router.get("/api/feeds/{feed_id}/dataflow-preview")
async def feed_dataflow_preview(feed_id: int, user: dict = Depends(get_current_user)):
    """Read-only — render this feed as its equivalent DataFlow stage sequence
    (calendar trigger → query → apply WHERE → convert format → deliver →
    control-file → notify).  Executes NOTHING; a visualization + blueprint for
    the eventual feed→DataFlow auto-map.  Secrets are masked in the details."""
    feed = await _require_feed(feed_id, user, write=False)
    from core.feed_to_dataflow import feed_to_dataflow_steps
    result = feed_to_dataflow_steps(_mask_feed_secrets(feed))
    return {"feed_id": feed_id, "feed_name": feed.get("name"), **result}


@router.put("/api/feeds/{feed_id}")
async def update_feed(feed_id: int, body: FeedConfigUpdate, user: dict = Depends(get_current_user),
                      apply_from: Optional[str] = None):
    """Update feed configuration.

    ``apply_from`` (2026-10-12): WHEN a definition change applies --
    ``next_run`` or a business date (every run of that date or later,
    re-runs and restatements included).  Recorded on the definition
    timeline (core/feed/definition_timeline.py); absent with no timeline =
    the pinned-for-date rule, unchanged."""
    stored_feed = await _require_feed(feed_id, user, write=True)
    from core.feed import definition_timeline as _dtl
    try:
        _applies_from = _dtl.parse_applies_from(apply_from)
    except ValueError:
        raise HTTPException(status_code=422, detail=f"apply_from must be 'next_run' or a business "
                                                    f"date (YYYY-MM-DD), not {apply_from!r}")
    # Phase 4 (2026-08-23): honour EXPLICIT nulls for clearable fields.
    # ``exclude_none=True`` silently ATE every ``field: null`` the UI sends
    # to clear an association — the comments in FeedConfigsPage ("Pass null
    # explicitly so editing can CLEAR these") described behaviour that
    # never existed: removing a calendar, un-grouping a feed, or reverting
    # cross-source to single-source kept the old values while the UI said
    # saved.  ``exclude_unset`` distinguishes "not sent" from "sent null";
    # only the declared clearable set may be nulled (everything else keeps
    # the old drop-None semantics so partial updates stay partial).
    _raw = body.model_dump(exclude_unset=True)
    data = {k: v for k, v in _raw.items() if v is not None}
    _CLEARABLE_NULL_FIELDS = {
        "calendar_name", "owner_group_id", "frequency_category",
        # 2026-09-28 -- explicit null clears the consumer declaration.
        "consumer_group_ids",
        # 2026-09-02 — explicit null UN-GROUPS the feed (operational
        # feed group).  Without this the only way out of a group would
        # be the bulk-membership route.
        "feed_group_id",
        "secondary_connection_id", "secondary_source_type",
        "secondary_source_id", "combine_mode", "join_config",
        "token_bindings",
        "control_file_template", "control_file_format_id",
        "size_threshold_rows", "row_count_threshold_pct",
        "integrity_check_enabled", "row_count_action", "etl_id",
        "row_count_compare_to",
        "sla_from", "sla_to", "valid_from", "valid_until",
        # 2026-10-03 -- the form's "Blank = UTC" sends null; without this
        # the stored zone survived every attempt to clear it.
        "sla_timezone",
        "description", "notify_emails", "notify_webhook",
        "output_filename_template",
        # BRD §2.1 — explicit null reverts the feed to its legacy
        # cron-only schedule.  Without this the only way back from a
        # declared schedule would be to delete the feed.
        "schedule_declaration",
        # BRD §11 / §14.2 — explicit null reverts the feed to legacy
        # single-hop delivery (destination_type + destination_config).
        # Present-but-EMPTY ([]) is refused by
        # _refuse_invalid_delivery_chain, so null is the one honest
        # spelling of "remove the chain".
        "delivery_chain",
    }
    for _k, _v in _raw.items():
        if _v is None and _k in _CLEARABLE_NULL_FIELDS:
            data[_k] = None
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update")

    # ── Feed identity (2026-09-02, BRD §14.3 / D5 / FR-ID-01..02) ────────
    # A RENAME (name present AND different from the stored one) is gated:
    #   - the new name must conform (existing rows keep working untouched —
    #     validation fires only on the name actually being changed);
    #   - a feed that has EVER run cannot be renamed: the old name is
    #     burned into archives, alert keys, filenames and audit history.
    #     BRD §14.3: renaming should mean "create new, retire old".
    #     A feed that has never run may be renamed freely.
    #   - the new name must be unique (same gate as create).
    # Round-tripping the SAME name through PUT is not a rename.
    _identity_warnings: list = []
    # FR-ART-01 — validate the EFFECTIVE contract: the stored feed with
    # this edit applied.  Validating only the patch would let an edit
    # that is fine in isolation combine with a stored value into a
    # contract nothing can honour.
    _contract_warnings = _refuse_invalid_contract(
        {**(stored_feed or {}), **data})
    _refuse_invalid_shape({**(stored_feed or {}), **data})
    _refuse_invalid_filename_template({**(stored_feed or {}), **data})
    _refuse_unknown_source_type({**(stored_feed or {}), **data})
    # 2026-10-11 -- the second side and the token bindings are judged on
    # the MERGED shape, only when the patch touches them (a legacy row
    # never blocks an unrelated edit).
    if any(k in data for k in _SECOND_SIDE_KEYS):
        _refuse_incomplete_second_side({**(stored_feed or {}), **data})
    if any(k in data for k in _TOKEN_BINDING_KEYS):
        await _refuse_invalid_token_bindings({**(stored_feed or {}), **data}, target=data)
    # 2026-10-12 -- a source / parameter edit is judged for the query's
    # PARAMETER tokens on the merged shape (an unrelated edit never blocks)
    if any(k in data for k in ("source_type", "source_id", "query_params", "connection_id",
                               "secondary_source_type", "secondary_source_id")):
        await _refuse_unvalued_parameters({**(stored_feed or {}), **data})
    if "destination_type" in data or "destination_config" in data:
        _refuse_empty_destination_config({**(stored_feed or {}), **data})
    # Same "only when the patch TOUCHES it" rule as the gate above, and for
    # the same reason: an unrelated edit must not fail on a legacy row that
    # predates this check.  You may not SET the broken combination; you are
    # not blocked from fixing a description on a feed that already has one.
    if "destination_type" in data or "output_format" in data:
        _refuse_output_format_destination_mismatch(
            {**(stored_feed or {}), **data})
    _refuse_filename_collision({**(stored_feed or {}), **data},
                               exclude_id=feed_id)
    _refuse_invalid_schedule({**(stored_feed or {}), **data})
    # Only what the patch TOUCHES -- a legacy stored value never blocks
    # an unrelated edit (the same rule as the destination checks above).
    await _refuse_unknown_upstream_feed(
        data, data.get("name") or (stored_feed or {}).get("name"))
    _refuse_invalid_sla(data)
    _sync_legacy_schedule_fields(data, {**(stored_feed or {}), **data})
    # BRD §11 / §14.2 — the chain is replaced WHOLESALE (a JSON column),
    # so the patch value alone is the effective value.  Absent → the
    # stored chain survives; explicit null → cleared (see
    # _CLEARABLE_NULL_FIELDS) and the validator passes None through.
    _refuse_invalid_delivery_chain(data.get("delivery_chain"))
    if "name" in data and str(data["name"]) != str((stored_feed or {}).get("name")):
        from core.feed.identity import validate_feed_name, name_advice
        try:
            validate_feed_name(data["name"])
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
        if await adb(_db_manager.feed_has_ever_run, feed_id):
            raise HTTPException(
                status_code=409,
                detail=f"Feed {feed_id} has already run under the name "
                       f"{(stored_feed or {}).get('name')!r}; renaming it "
                       f"would break every historical reference (archives, "
                       f"alerts, filenames, audit). Create a new feed with "
                       f"the new name and retire this one. To change "
                       f"only how it is LABELLED, set display_name "
                       f"instead — that is free text and always "
                       f"editable.")
        _dup_ids = await adb(_db_manager.get_feed_ids_by_name, data["name"],
                             exclude_feed_id=feed_id)
        if _dup_ids:
            raise HTTPException(
                status_code=409,
                detail=f"Feed name {data['name']!r} is already used by feed "
                       f"id {_dup_ids[0]} (names are unique per "
                       f"environment). Choose a different name.")
        _identity_warnings = name_advice(data["name"])

    # SECURITY AUDIT 2026-08-03 (S4 companion): GET responses mask delivery
    # credentials to '***'.  A client that round-trips that config through
    # PUT must NOT overwrite the stored real credential with the literal
    # placeholder — substitute the stored value back in before persisting.
    for _cfg_field in ("destination_config", "backend_config"):
        if isinstance(data.get(_cfg_field), dict):
            data[_cfg_field] = _unmask_secret_tree(
                data[_cfg_field], (stored_feed or {}).get(_cfg_field) or {})
    # Same guard for the delivery chain — hop configs are masked in GET
    # responses, and hops are matched back by LABEL, not list position.
    if isinstance(data.get("delivery_chain"), list):
        data["delivery_chain"] = _unmask_delivery_chain(
            data["delivery_chain"], (stored_feed or {}).get("delivery_chain"))

    # Claiming a feed for a group requires the claimer to actually be a
    # read-write member of that group (else anyone could grab an unclaimed
    # org-shared feed into a group they have no part in and lock others out).
    # Admins bypass.  Resolved via the same entitlements gate used everywhere.
    if data.get("owner_group_id") is not None and _auth_on():
        from core.roles import is_admin_like as _adm
        if not _adm(user):
            from core.feed.permissions import can_edit_feed as _cef
            _probe = {"owner_group_id": data["owner_group_id"], "created_by": None}
            if not await adb(_cef, _probe, user, _db_manager):
                raise HTTPException(
                    status_code=403,
                    detail="You can only assign a feed to a group you are a "
                           "read-write member of.")

    # SSRF validation on webhook URL (Phase 132-A)
    if body.notify_webhook:
        try:
            from core.url_safety import validate_url_safety
            validate_url_safety(body.notify_webhook)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"Webhook URL blocked: {exc}")

    # Phase 132.38 — re-apply WHERE mapping on update.  When ``where_clauses``
    # is omitted entirely the existing mapping in query_params survives
    # untouched.  Passing an empty list explicitly clears the mapping.
    if "where_clauses" in data or body.where_clauses is not None:
        # Need the existing query_params off the DB row when the caller
        # didn't supply a new one — otherwise we'd clobber any unrelated
        # keys the publisher set previously (e.g. ``{{name}}`` defaults).
        if "query_params" not in data:
            try:
                _existing = await adb(_db_manager.get_feed_config, feed_id)
                if _existing:
                    data["query_params"] = dict(_existing.get("query_params") or {})
            except Exception:
                logger.debug("update_feed: could not pre-fetch existing query_params",
                             exc_info=True)
        _embed_where_mapping_in_query_params(data, body.where_clauses,
                                              clear_when_empty=True)

    # ── Cross-source preflight (2026-08-04) ──────────────────────────────
    # Validate the MERGED shape (stored row + this update) so a PUT that
    # breaks the cross-source config — or completes one — is judged on
    # what would actually run.  Same policy as create: ERROR verdicts
    # refuse the save with the fix named; checker crashes never block.
    # 2026-10-12 -- a feed being switched OFF delivers nothing: the checks
    # that guard a delivery never block its retirement (found live: a feed
    # whose .sql file was removed could not be deactivated -- the preflight
    # refused the very save that takes it out of service).
    _turning_off = (data.get("is_active") is False)
    _cross_pf = None if _turning_off else await _run_cross_source_preflight(
        {**(stored_feed or {}), **data})
    if _cross_pf is not None and not _cross_pf.ok:
        raise HTTPException(status_code=400, detail=_cross_pf.format_report())

    if "calendar_name" in data:
        await _require_valid_calendar_name(data.get("calendar_name"))
    elif data.get("is_active") is True and not (stored_feed or {}).get("is_active", True):
        # 2026-10-11: re-activating a feed re-checks the calendar it names
        # (it may have been deleted while the feed was inactive).
        await _require_valid_calendar_name((stored_feed or {}).get("calendar_name"))
    # 2026-09-02 — validate a (re)grouping; null passes through untouched
    # (it is the documented un-group spelling in _CLEARABLE_NULL_FIELDS).
    if "feed_group_id" in data:
        await _require_valid_feed_group_id(data.get("feed_group_id"))
    # 2026-09-28 -- a (re)declared consumer audience; null / [] clears it.
    if "consumer_group_ids" in data:
        await _require_valid_consumer_group_ids(data.get("consumer_group_ids"))

    result = await adb(_db_manager.update_feed_config, feed_id, data)
    if not result:
        raise HTTPException(status_code=404, detail=f"Feed config {feed_id} not found")
    # 2026-09-27 -- the SAVE half of the version history: pin what was just
    # written through the claim-time writer (deduplicated by hash, so an
    # unchanged save mints nothing).  Fail-open, logged; see
    # core/feed/definition_history.py and api/feed_versions_api.py.
    from core.feed.definition_history import record_version as _record_version
    await adb(_record_version, _db_manager, feed_id,
              created_by=user.get("username"), feed_config=result)
    # WHEN it applies: the author's answer, on the timeline (asked, or kept
    # on once a feed has one -- its later saves must say when they apply)
    _timeline_entry = None
    if apply_from is not None or await adb(_db_manager.list_definition_timeline, feed_id):
        _timeline_entry = await adb(_dtl.record_save, _db_manager, stored_feed, result,
                                    applies_from=_applies_from, user=user.get("username"))

    # Re-register schedule if cron changed — unless acceptance holds it.
    _accept_note = await _hold_until_accepted(feed_id, result, result)
    if _accept_note:
        result["schedule_enabled"] = False
    _note_authored_feed(result)
    if "cron_expression" in data or "schedule_enabled" in data:
        if result.get("schedule_enabled") and result.get("cron_expression"):
            _register_schedule(feed_id, result["cron_expression"],
                             result.get("timezone", "UTC"), result["name"])
        else:
            _unregister_schedule(feed_id)

    username = user.get("username", "unknown")
    logger.info("Feed config %d updated by %s: %s", feed_id, username, list(data.keys()))
    # SECURITY AUDIT 2026-08-03 (S4): PUT skipped the credential masking the
    # GET routes apply — same leak as POST /api/feeds.
    masked = _mask_feed_secrets(result)
    if _accept_note:
        masked["acceptance_hold"] = _accept_note
    if _cross_pf is not None and _cross_pf.issues:
        masked["cross_source_preflight"] = _cross_pf.to_dict()
    # FR-ID-03 — ADVISORY naming warnings for a rename (never blocks).
    if _identity_warnings:
        masked["name_advice"] = _identity_warnings
        logger.warning("Feed %d renamed to %r: %s", feed_id,
                       result["name"], "; ".join(_identity_warnings))
    if _timeline_entry:
        masked["definition_applies"] = _timeline_entry
    _annotate_contract(masked, data)
    if _contract_warnings:
        masked["contract_unsupported"] = _contract_warnings
        logger.warning(
            "Feed %d output contract has %d unsupported term(s): %s",
            feed_id, len(_contract_warnings),
            "; ".join(f.get("message", "") for f in _contract_warnings))
    return masked


async def _refuse_if_deployment_window(feed: dict, user: dict,
                                        override: bool,
                                        action: str) -> None:
    """FR-OPS-04 — refuse STARTING a run while a deployment window
    matching this feed is active.  Blocks starts ONLY: nothing here (or
    anywhere) touches a run already in flight — killing a run mid-SFTP
    is hazard H1, and the cancel endpoints remain the human's tool.

    ``override=true`` lets an ADMIN start anyway (audited); a non-admin
    passing it gets a 403 naming who can.

    An UNREADABLE window store fails OPEN — loudly.  "No window" and
    "could not read the windows" stay opposite findings (the second is
    ERROR-logged and audited as ``deployment_window_unenforced``), but
    the run PROCEEDS: a deployment window is an operational convenience
    at EXECUTION time, and a settings blip that stops every feed at
    03:00 is a self-inflicted outage, while a missed window is an
    inconvenience someone notices.  This is deliberately the OPPOSITE
    posture from the authoring validators (_refuse_invalid_shape, the
    contract validator), which fail closed because a refusal there
    costs a form submission, not the night's runs.  A genuine ACTIVE
    window still blocks.
    """
    from core.feed.deployment_window import (
        blocking_window_for_feed, record_refusal, refusal_detail,
    )
    try:
        win = await adb(blocking_window_for_feed, _db_manager, feed)
    except Exception as exc:
        logger.error(
            "[feed_api] deployment windows could not be read before "
            "starting feed %s (%s: %s) — window NOT ENFORCED for this "
            "run (fail-open: an unreadable settings row must not stop "
            "the estate)", feed.get("id"), type(exc).__name__, exc)
        _audit("deployment_window_unenforced", user, {
            "feed_id": feed.get("id"), "action": action,
            "error": f"{type(exc).__name__}: {exc}",
        })
        return
    if win is None:
        return
    if override:
        from core.roles import is_admin_like
        if is_admin_like(user):
            _audit("deployment_window_overridden", user, {
                "window_id": win.get("id"),
                "feed_id": feed.get("id"), "action": action,
            })
            logger.warning(
                "[feed_api] deployment window %s OVERRIDDEN by %s for "
                "feed %s (%s)", win.get("id"), user.get("username"),
                feed.get("id"), action)
            return
        raise HTTPException(
            status_code=403,
            detail="Only an admin may override a deployment window.  "
                   + refusal_detail(win, feed=feed))
    try:
        await adb(record_refusal, _db_manager, win.get("id"),
                  feed_id=int(feed.get("id") or 0),
                  actor=str(user.get("username") or "unknown"),
                  action=action)
    except Exception:
        logger.warning("[feed_api] could not record window refusal",
                       exc_info=True)
    _audit("deployment_window_refusal", user, {
        "window_id": win.get("id"), "feed_id": feed.get("id"),
        "action": action,
    })
    raise HTTPException(status_code=409,
                        detail=refusal_detail(win, feed=feed))


def _find_downstream_feeds(feed: dict) -> list:
    """Feeds that DEPEND ON this one (FR-OPS-14) — the check that stops
    "deactivate the upstream, downstream waits forever at 3am".

    Two edge sources, both REAL (each is authored data something reads):

    1. ``etl_dependency_mappings`` rows whose ``dependency_key`` names
       this feed — by NAME or by etl_id — exactly the convention
       ``_refuse_dependency_cycle`` above already treats as a
       feed-to-feed edge.  Active mappings only: an inactive dependency
       does not gate, so it cannot strand anyone.
    2. ``schedule_declaration`` of kind ``on_completion_of`` naming this
       feed (BRD §6) — declared even though the runtime trigger for it
       is not wired yet; an authored edge is an authored edge.

    What is deliberately NOT matched: FILE-type dependency keys against
    this feed's ``output_filename_template``.  Nothing anywhere reads a
    FILE key as a filename pattern (it is a logical name satisfied by a
    tracking row), so matching templates would invent a semantic the
    platform does not have and produce false refusals.

    Returns ``[{"feed_id", "feed_name", "via", "detail"}, ...]`` for
    ACTIVE downstream feeds.  Raises on a read failure — "no dependents"
    and "could not check dependents" are opposite findings, and the
    caller must refuse on the second, not proceed.
    """
    this_id = int(feed["id"])
    aliases = {str(feed.get("name") or "")}
    aliases.add(str(this_id))
    aliases.add(str(_resolve_etl_id_for_feed(feed)))
    aliases.discard("")

    out: list = []
    # 2026-10-10 -- every active feed and every active mapping from ONE
    # snapshot (two queries, or the batch's own): this used to list every
    # feed and query each one's mappings, so retiring N template members
    # was N^2 queries.
    snapshot = _authoring_snapshot()
    feeds = [f for f in snapshot.feeds() if f.get("is_active", True)]
    for f in feeds:
        fid = int(f["id"])
        if fid == this_id:
            continue
        # Edge source 2 — declared on_completion_of upstream.
        decl = f.get("schedule_declaration")
        if (isinstance(decl, dict)
                and decl.get("kind") == "on_completion_of"
                and str(decl.get("feed") or "") in aliases):
            out.append({
                "feed_id": fid, "feed_name": f.get("name"),
                "via": "schedule_declaration",
                "detail": f"schedule_declaration.on_completion_of names "
                          f"{decl.get('feed')!r}",
            })
            continue
        # Edge source 1 — active dependency mappings keyed on this feed,
        # read under the other feed's EFFECTIVE etl_id (2026-09-27: a
        # NULL etl_id no longer means "no mappings can exist").
        eid = _resolve_etl_id_for_feed(f)
        for row in snapshot.dependency_rows(int(eid)):
            key = str(row.get("dependency_key") or "")
            if key in aliases:
                out.append({
                    "feed_id": fid, "feed_name": f.get("name"),
                    "via": "dependency_mapping",
                    "detail": f"dependency_key {key!r} "
                              f"(mapping id {row.get('id')})",
                })
                break
    return out


async def _refuse_if_downstream(feed: dict, user: dict, *,
                                acknowledged: bool, action: str) -> list:
    """FR-OPS-14 — refuse (409) when active feeds depend on this one,
    unless the caller explicitly acknowledged the named dependents.
    Returns the dependents list (possibly empty) for the audit trail."""
    try:
        downstream = await adb(_find_downstream_feeds, feed)
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Could not verify downstream dependents before "
                   f"{action} ({exc}) — refusing rather than risking a "
                   f"downstream feed waiting forever on this one.  Retry, "
                   f"or investigate the dependency store.")
    if downstream and not acknowledged:
        names = ", ".join(
            f"{d['feed_name']} (id {d['feed_id']}, via {d['via']})"
            for d in downstream)
        raise HTTPException(
            status_code=409,
            detail=f"Refusing to {action} feed "
                   f"{feed.get('name')!r}: {len(downstream)} active "
                   f"feed(s) depend on it — {names}.  Each would wait on "
                   f"it forever (surfacing at 3am as a stale-run alert). "
                   f"Re-point or deactivate those dependencies first, or "
                   f"repeat this call with acknowledge_dependents=true "
                   f"to proceed anyway (audited).")
    return downstream


@router.delete("/api/feeds/{feed_id}")
async def delete_feed(feed_id: int,
                      acknowledge_dependents: bool = Query(default=False),
                      user: dict = Depends(get_current_user)):
    """Deactivate feed configuration (soft delete).

    2026-09-03 (FR-OPS-14 / FR-SEC-11):
    * refuses while active downstream feeds depend on this one, naming
      them — ``acknowledge_dependents=true`` proceeds anyway, audited;
    * refuses outright (423) under an ACTIVE legal hold — a hold is not
      a flag, it prevents the deletion it exists to prevent.

    Delete stays SOFT (is_active=false): run_events / delivery_attempts
    deliberately survive (their feed ids are not FKs — FR-OPS-16).
    """
    feed = await _require_feed(feed_id, user, write=True)
    from core.feed import lifecycle as _lifecycle
    _hold = await adb(_lifecycle.legal_hold_active, _db_manager, feed_id)
    if _hold:
        raise HTTPException(
            status_code=423,
            detail=f"Feed {feed.get('name')!r} is under an active legal "
                   f"hold placed by {_hold.get('placed_by')} at "
                   f"{_hold.get('placed_at')} "
                   f"(ref {_hold.get('reference') or 'n/a'}): "
                   f"{_hold.get('reason')}.  Deletion is blocked while "
                   f"the hold stands — an admin must release it first "
                   f"via PUT /api/feeds/{feed_id}/legal-hold with "
                   f"active=false.")
    _downstream = await _refuse_if_downstream(
        feed, user, acknowledged=acknowledge_dependents, action="delete")
    _unregister_schedule(feed_id)
    ok = await adb(_db_manager.deactivate_feed_config, feed_id)
    _note_authored_feed({**feed, "is_active": False})
    if not ok:
        raise HTTPException(status_code=404, detail=f"Feed config {feed_id} not found")
    username = user.get("username", "unknown")
    logger.info("Feed config %d deactivated by %s", feed_id, username)
    if _downstream:
        _audit("feed_deleted_with_acknowledged_dependents", user, {
            "feed_id": feed_id,
            "dependents": _downstream,
        })
    return {"detail": "Feed deactivated", "id": feed_id,
            "acknowledged_dependents": _downstream}


# ── Lifecycle governance (2026-09-03) ────────────────────────────────────
# Retirement (FR-OPS-15/16), acceptance sign-off (FR-ACC-02), PII
# declaration (FR-SEC-10), legal hold (FR-SEC-11).  State lives in
# core/feed/lifecycle.py (system_settings-backed — no schema change).

class RetireFeedRequest(BaseModel):
    reason: str
    quarantine_days: Optional[int] = Field(default=None, ge=1, le=365)
    acknowledge_dependents: bool = False


@router.post("/api/feeds/{feed_id}/retire")
async def retire_feed(feed_id: int, body: RetireFeedRequest,
                      user: dict = Depends(get_current_user)):
    """FR-OPS-15 — retirement is a STATED state, not a plain disable:
    the feed is deactivated, its schedule removed, and a quarantine
    period recorded ("disabled pending deletion").  Within quarantine
    POST /api/feeds/{id}/unretire restores it.  The audit ledger
    (run_events / delivery_attempts) outlives the feed by design
    (FR-OPS-16) and the retirement record says so explicitly."""
    feed = await _require_feed(feed_id, user, write=True)
    if not str(body.reason or "").strip():
        raise HTTPException(
            status_code=422,
            detail="reason is required: a year on, 'why was this feed "
                   "retired' must be answerable from the record.")
    from core.feed import lifecycle as _lifecycle
    _existing = await adb(_lifecycle.retirement_active, _db_manager,
                          feed_id)
    if _existing:
        raise HTTPException(
            status_code=409,
            detail=f"Feed {feed.get('name')!r} is already retiring "
                   f"(requested by {_existing.get('requested_by')} at "
                   f"{_existing.get('requested_at')}, quarantine until "
                   f"{_existing.get('quarantine_until')}).  To restore "
                   f"it, POST /api/feeds/{feed_id}/unretire.")
    _downstream = await _refuse_if_downstream(
        feed, user, acknowledged=body.acknowledge_dependents,
        action="retire")
    username = user.get("username", "unknown")
    try:
        rec = await adb(_lifecycle.start_retirement, _db_manager, feed_id,
                        reason=body.reason.strip(), requested_by=username,
                        quarantine_days=body.quarantine_days)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    _unregister_schedule(feed_id)
    await adb(_db_manager.deactivate_feed_config, feed_id)
    _note_authored_feed({**feed, "is_active": False})
    _hold = await adb(_lifecycle.legal_hold_active, _db_manager, feed_id)
    _audit("feed_retired", user, {
        "feed_id": feed_id, "reason": rec.get("reason"),
        "quarantine_until": rec.get("quarantine_until"),
        "acknowledged_dependents": _downstream,
    })
    logger.info("Feed %d retired by %s (quarantine until %s)", feed_id,
                username, rec.get("quarantine_until"))
    return {
        "detail": "Feed retired: deactivated and quarantined pending "
                  "deletion",
        "feed_id": feed_id,
        "retirement": rec,
        "legal_hold": _hold,
        "audit_retention": "run_events and delivery_attempts for this "
                           "feed are retained regardless of retirement "
                           "(FR-OPS-16; their feed ids are deliberately "
                           "not foreign keys)",
        "acknowledged_dependents": _downstream,
    }


@router.post("/api/feeds/{feed_id}/unretire")
async def unretire_feed(feed_id: int,
                        user: dict = Depends(get_current_user)):
    """Cancel a retirement (the point of the quarantine): clears the
    retirement record and reactivates the feed.  The schedule is NOT
    re-enabled — re-enabling a cron that was deliberately stopped is a
    separate, explicit act (POST /api/feeds/{id}/enable-schedule)."""
    feed = await _require_feed(feed_id, user, write=True)
    from core.feed import lifecycle as _lifecycle
    username = user.get("username", "unknown")
    was = await adb(_lifecycle.cancel_retirement, _db_manager, feed_id,
                    cancelled_by=username)
    if not was:
        raise HTTPException(
            status_code=409,
            detail=f"Feed {feed.get('name')!r} is not retiring — nothing "
                   f"to unretire.  GET /api/feeds/{feed_id}/lifecycle "
                   f"shows its lifecycle state.")
    # 2026-10-11: the calendar it names may have been deleted while retired
    # (calendar deletion counts active feeds only) -- refuse, never run it on
    # "every day is a business day".
    if feed.get("calendar_name"):
        _cal_row = await adb(_db_manager.get_feed_calendar_by_name, str(feed["calendar_name"]))
        if not _cal_row:
            raise HTTPException(status_code=409, detail=(
                f"Feed {feed.get('name')!r} names calendar {feed['calendar_name']!r}, "
                f"which no longer exists. Create it again (or clear the feed's "
                f"calendar) before un-retiring."))
    await adb(_db_manager.update_feed_config, feed_id, {"is_active": True})
    _audit("feed_unretired", user, {"feed_id": feed_id})
    return {"detail": "Retirement cancelled; feed reactivated (schedule "
                      "stays disabled until explicitly re-enabled)",
            "feed_id": feed_id}


@router.get("/api/feeds/{feed_id}/lifecycle")
async def get_feed_lifecycle(feed_id: int,
                             user: dict = Depends(get_current_user)):
    """The feed's governance state in one read: retirement (with
    quarantine countdown), acceptance, PII declaration, legal hold."""
    await _require_feed(feed_id, user, write=False)
    from core.feed import lifecycle as _lifecycle
    state = await adb(_lifecycle.get_lifecycle, _db_manager, feed_id)
    ret = state.get("retirement")
    if ret:
        rem = _lifecycle.quarantine_remaining(ret)
        ret = dict(ret)
        ret["quarantine_remaining_days"] = (
            round(rem, 2) if rem is not None else None)
        state["retirement"] = ret
    return {"feed_id": feed_id, "lifecycle": state}


class PiiDeclarationRequest(BaseModel):
    contains_pii: bool
    categories: Optional[List[str]] = None
    notes: Optional[str] = None


@router.put("/api/feeds/{feed_id}/pii-declaration")
async def declare_feed_pii(feed_id: int, body: PiiDeclarationRequest,
                           user: dict = Depends(get_current_user)):
    """FR-SEC-10 — the per-feed PII declaration.  Declaring is what is
    required (the acceptance gate refuses an UNDECLARED new feed):
    contains_pii=false is as valid a declaration as naming categories.
    contains_pii=true with no categories is refused — 'PII, somewhere'
    is not a declaration anyone can act on."""
    await _require_feed(feed_id, user, write=True)
    cats = [str(c).strip() for c in (body.categories or []) if str(c).strip()]
    if body.contains_pii and not cats:
        raise HTTPException(
            status_code=422,
            detail="contains_pii=true needs categories naming WHAT (e.g. "
                   "['name', 'account_number', 'email']) — an unnamed "
                   "PII declaration cannot drive handling or review.")
    from core.feed import lifecycle as _lifecycle
    username = user.get("username", "unknown")
    rec = {
        "contains_pii": bool(body.contains_pii),
        "categories": cats or None,
        "notes": (body.notes or "").strip() or None,
        "declared_by": username,
        "declared_at": datetime.now(timezone.utc).isoformat(),
    }
    await adb(_lifecycle.set_aspect, _db_manager, feed_id, "pii", rec,
              username)
    _audit("feed_pii_declared", user, {"feed_id": feed_id, **rec})
    return {"detail": "PII declaration recorded", "feed_id": feed_id,
            "pii": rec}


class LegalHoldRequest(BaseModel):
    active: bool
    reason: Optional[str] = None
    reference: Optional[str] = None


@router.put("/api/feeds/{feed_id}/legal-hold")
async def set_feed_legal_hold(feed_id: int, body: LegalHoldRequest,
                              user: dict = Depends(require_admin)):
    """FR-SEC-11 — place or release a legal hold.  Admin-only in BOTH
    directions: a hold exists to bind the owner too.

    What the hold ENFORCES today: DELETE /api/feeds/{id} refuses (423)
    while it stands, and ``core.feed.lifecycle.legal_hold_feed_ids`` is
    the exclusion set retention reapers must consult.  The reaper
    (cleanup_old_feed_executions and its caller) is owned by another
    workstream — until it consults that set, history reaping is NOT yet
    blocked; that anchor is reported, not silently assumed."""
    feed = await adb(_db_manager.get_feed_config, feed_id)
    if not feed:
        raise HTTPException(status_code=404,
                            detail=f"Feed config {feed_id} not found")
    from core.feed import lifecycle as _lifecycle
    username = user.get("username", "unknown")
    now_iso = datetime.now(timezone.utc).isoformat()
    if body.active:
        if not str(body.reason or "").strip():
            raise HTTPException(
                status_code=422,
                detail="Placing a legal hold requires a reason (the "
                       "matter it relates to) — an unexplained hold "
                       "cannot be reviewed or released responsibly.")
        rec = {
            "active": True,
            "reason": body.reason.strip(),
            "reference": (body.reference or "").strip() or None,
            "placed_by": username,
            "placed_at": now_iso,
        }
    else:
        prior = await adb(_lifecycle.get_aspect, _db_manager, feed_id,
                          "legal_hold")
        if not prior or not prior.get("active"):
            raise HTTPException(
                status_code=409,
                detail=f"Feed {feed.get('name')!r} has no active legal "
                       f"hold to release.")
        rec = dict(prior)
        rec.update({"active": False, "released_by": username,
                    "released_at": now_iso,
                    "release_reason": (body.reason or "").strip() or None})
    await adb(_lifecycle.set_aspect, _db_manager, feed_id, "legal_hold",
              rec, username)
    _audit("feed_legal_hold_" + ("placed" if body.active else "released"),
           user, {"feed_id": feed_id, **rec})
    return {"detail": ("Legal hold placed — deletion is now blocked"
                       if body.active else "Legal hold released"),
            "feed_id": feed_id, "legal_hold": rec}


class AcceptanceSignOffRequest(StrictRequestModel):
    """FB-32 (2026-09-19): a SIGN-OFF is an attestation.  Of 303 probed
    write routes this was the one that accepted an unknown field and
    dropped it -- a dropped field on the surface where a person records
    that they accepted a feed is a dropped attestation.  ``extra="forbid"``
    (StrictRequestModel) makes a misspelt or unknown key a 422 that NAMES
    it, the same posture as the execute bodies (FB-22)."""
    contract_confirmed: bool = False
    notes: Optional[str] = None
    ticket: Optional[str] = None


@router.post("/api/feeds/{feed_id}/acceptance/sign-off")
async def sign_off_feed_acceptance(feed_id: int,
                                   body: AcceptanceSignOffRequest,
                                   user: dict = Depends(get_current_user)):
    """FR-ACC-02 — record the consumer sign-off that lets a NEW feed go
    live.  Refuses until (a) an acceptance run has actually COMPLETED
    (a failed attempt is not an acceptance run) and (b) the caller
    confirms the output matched the agreed contract — a feed does not
    go live because the platform produced a file without erroring."""
    feed = await _require_feed(feed_id, user, write=True)
    from core.feed import lifecycle as _lifecycle
    if not await adb(_lifecycle.has_successful_run, _db_manager, feed_id):
        raise HTTPException(
            status_code=409,
            detail=f"Feed {feed.get('name')!r} has no COMPLETED run — "
                   f"there is nothing to sign off.  Run the acceptance "
                   f"run first (POST /api/feeds/{feed_id}/execute), have "
                   f"the consumer verify the output, then sign off.")
    if not body.contract_confirmed:
        raise HTTPException(
            status_code=422,
            detail="contract_confirmed=true is required: the sign-off "
                   "asserts the acceptance output matched the agreed "
                   "contract terms (format, naming, checksum, column "
                   "order, expected volume, acknowledgment path) — not "
                   "merely that a file appeared.")
    username = user.get("username", "unknown")
    rec = await adb(_lifecycle.record_sign_off, _db_manager, feed_id,
                    accepted_by=username,
                    contract_confirmed=True,
                    notes=body.notes, ticket=body.ticket)
    _audit("feed_acceptance_signed_off", user,
           {"feed_id": feed_id, "acceptance": rec})
    return {"detail": "Acceptance recorded — the schedule can now be "
                      "enabled (POST /api/feeds/{id}/enable-schedule)",
            "feed_id": feed_id, "acceptance": rec}


# ── Execution Endpoints ──────────────────────────────────────────────────────

# 2026-08-22 — DERIVED from the router's registry instead of a hand-kept
# twin (this literal set was {"native", "airflow"} while the router already
# accepted more — the exact one-of-two-twins defect class).  spark_connect
# stays deliberately excluded from the USER-facing override: it is an
# interactive S3 tier, not a feed backend an admin should pin a run to.
from core.feed.backend_router import (
    VALID_PER_EXECUTION_OVERRIDES as _ROUTER_PER_EXECUTION_OVERRIDES,
)

_VALID_PER_EXECUTION_OVERRIDES = (
    set(_ROUTER_PER_EXECUTION_OVERRIDES) - {"spark_connect"}
)


def _validate_per_execution_override(value: Optional[str]) -> Optional[str]:
    """Validate the optional ``?backend=`` query param used to flip
    backend on a single trigger.  Returns the lower-cased value or
    ``None``; raises 400 on invalid input."""
    if value is None or value == "":
        return None
    v = value.lower()
    if v not in _VALID_PER_EXECUTION_OVERRIDES:
        raise HTTPException(
            status_code=400,
            detail=f"backend must be one of {sorted(_VALID_PER_EXECUTION_OVERRIDES)}; got {value!r}",
        )
    return v


@router.get("/api/feed-dependency-types")
async def list_feed_dependency_types(user: dict = Depends(get_current_user)):
    """Non-admin types catalogue lookup.  Powers the dep-editor dropdown
    in the Feed config dialog (end users picking KAFKA / ORACLE_TABLE /
    FILE / API / custom).  Read-only — admin endpoints handle CUD."""
    rows = await adb(_db_manager.list_etl_dependency_types, True)
    return {"items": rows}


@router.get("/api/feed-arrival-sources")
async def list_feed_arrival_sources(user: dict = Depends(get_current_user)):
    """The DECLARED arrival-source vocabulary (2026-09-27) — what a
    dependency may name as where its evidence comes from, with the
    parameters each kind needs and the two combination modes.  Read-only;
    the registry in core/feed/arrival_sources.py is the single source."""
    from core.feed.arrival_sources import describe_kinds, producer_health
    from core.feed.dependency_gate import REQUIRE_ALL, REQUIRE_MODES
    kinds = describe_kinds()
    # 2026-10-07 -- each kind's PRODUCER health, so the form can say "this
    # source cannot be satisfied right now" before an author relies on it.
    for k in kinds:
        k["producer_health"] = await adb(producer_health, _db_manager, k["kind"])
        if k["kind"] == "oracle_table":
            # 2026-10-12 -- the (connection, table) pairs the watcher reads:
            # the form offers exactly these (any other can never be met)
            from core.feed.oracle_table_source import watched_pairs
            try:
                k["watched"] = await adb(watched_pairs, _db_manager)
            except Exception as exc:                    # noqa: BLE001 -- said, not hidden
                k["watched"], k["watched_error"] = [], str(exc)
    return {"kinds": kinds,
            "require_modes": list(REQUIRE_MODES),
            "default_require_mode": REQUIRE_ALL}


class FeedDependencyRow(BaseModel):
    """One dependency entry on a feed (Phase 131-A).  ``id`` is present
    on existing rows; new rows omit it."""
    id:                Optional[int] = None
    dependency_type_id: int
    dependency_key:    str
    description:       Optional[str] = None
    # FR-DEP-08 — WHOSE CALENDAR governs this dependency: the
    # upstream's, not ours.  The column has existed since 2026-09-02
    # and the gate reads it; without this field nobody could SET it,
    # so the not-expected verdict was unreachable in practice and
    # every upstream holiday still paged someone at 04:19.
    # NULL means "expected every run day" — inferring not-expected
    # from a missing calendar would silence a broken upstream.
    calendar_name:     Optional[str] = None
    # FR-DEP-24 / BRD 2.1 — the OPTIONAL expected row count.  The gate has
    # always compared expected vs reported to catch "the message says
    # COMPLETE but upstream loaded 60% of its rows"; until 2026-09-02
    # NEITHER SIDE HAD A PRODUCER, so that comparison could not fire on any
    # row ever written.  None means NO CHECK.
    expected_rows:     Optional[int] = None
    # 2026-09-27 — the DECLARED arrival sources (core/feed/arrival_sources.py)
    # and how they combine.  None / [] = no declaration = the legacy
    # any-evidence rule.  Validated against the vocabulary at save time
    # (400 with the fault) — a kind outside it would be a dependency that
    # reports COULD NOT TELL every night for ever.
    arrival_sources:   Optional[List[Dict[str, Any]]] = None
    require_mode:      Optional[str] = None
    # 2026-10-11 -- which SIDE of the feed this dependency's reported row
    # count certifies ('primary' / 'secondary'; None = no certification).
    # Validated at save: a vocabulary word, 'secondary' only on a feed with a
    # secondary connection, at most one dependency per side.
    certifies_side:    Optional[str] = None
    # 2026-10-15 -- a NEW message of this dependency for a date already
    # delivered re-runs it: None / True = yes (as before), False = recorded
    # only (core/feed/restatement.py).  The month end: SOD / ITD False, EOD
    # True -- WD1 waits for all three, WD2..WDn re-run on EOD.
    reruns_delivered:  Optional[bool] = None
    is_active:         bool = True


class FeedDependenciesReplace(BaseModel):
    """Bulk replace — the entire dependency list for a feed.  Atomic on
    the QS side (DELETE old + INSERT new in one transaction).  Empty
    list = remove all dependencies."""
    dependencies: List[FeedDependencyRow] = Field(default_factory=list)


async def _validated_arrival_sources(rows: List["FeedDependencyRow"],
                                     user: dict) -> List[tuple]:
    """Per row: ``(normalised sources, require_mode)``; a 400 names the
    first fault.  An ``iceberg_commit`` declaration must name a connection
    the caller may read and a table registered on it as Iceberg; a ``file``
    declaration (2026-10-07) a connection the caller may read that is S3
    (an ``s3://`` path naming ITS bucket) or local with a base_path."""
    from core.feed.arrival_sources import (
        ArrivalSourceRefused, parse_arrival_sources, parse_require_mode,
    )
    out: List[tuple] = []
    for row in rows:
        try:
            sources = parse_arrival_sources(row.arrival_sources)
            mode = parse_require_mode(row.require_mode)
        except ArrivalSourceRefused as exc:
            raise HTTPException(
                status_code=400,
                detail=f"dependency {row.dependency_key!r}: {exc}")
        for spec in sources:
            await _refuse_unusable_source_connection(row.dependency_key, spec, user)
        out.append((sources, mode))
    return out


async def _refuse_unusable_source_connection(dependency_key: str, spec: dict,
                                             user: dict) -> None:
    """The database half of a declared source's authoring check: the
    caller may read the connection, and it can carry the source (an
    Iceberg-registered table / an S3 bucket or local base_path).  A 400
    naming the dependency, never a bare 403/404 the form cannot place."""
    from core.feed.arrival_sources import (
        KIND_FILE, KIND_ICEBERG_COMMIT, KIND_ORACLE_TABLE,
    )
    from core.feed.file_arrival_source import validate_against_connection
    from core.feed.oracle_table_source import (
        validate_against_connection as _validate_oracle_table,
    )
    from core.iceberg_watch_registry import resolve_registered_iceberg_table
    kind = spec.get("kind")
    if kind not in (KIND_ICEBERG_COMMIT, KIND_FILE, KIND_ORACLE_TABLE):
        return
    conn_id = int(spec["connection_id"])
    try:
        from api.connections_api import _require_connection_access
        await _require_connection_access(conn_id, user)
    except HTTPException as exc:
        raise HTTPException(
            status_code=400,
            detail=f"dependency {dependency_key!r}: connection "
                   f"{conn_id} is not available to you "
                   f"({exc.detail})")
    if kind == KIND_FILE:
        reason = await adb(validate_against_connection, _db_manager, spec)
    elif kind == KIND_ORACLE_TABLE:
        # 2026-10-11 -- an Oracle connection; the table's rules are config.
        reason = await adb(_validate_oracle_table, _db_manager, spec)
    else:
        entry, reason = await adb(resolve_registered_iceberg_table,
                                  _db_manager, conn_id, spec["table"])
        reason = None if entry is not None else reason
    if reason:
        raise HTTPException(
            status_code=400,
            detail=f"dependency {dependency_key!r}: {reason}")


def _validated_certifies_sides(feed: dict, rows: List["FeedDependencyRow"]) -> List[Optional[str]]:
    """Per row: the normalised ``certifies_side`` or None; a 400 naming the
    dependency for a word outside primary/secondary, for 'secondary' on a feed
    with no secondary connection, and for two rows certifying one side (the
    judge would have to pick one -- ambiguity is refused, not resolved)."""
    from core.feed.reported_rows_certification import SIDES
    out: List[Optional[str]] = []
    seen: Dict[str, str] = {}
    for row in rows:
        raw = str(row.certifies_side or "").strip().lower() or None
        if raw is None:
            out.append(None)
            continue
        if raw not in SIDES:
            raise HTTPException(
                status_code=400,
                detail=f"dependency {row.dependency_key!r}: certifies_side="
                       f"{row.certifies_side!r} is not one of {list(SIDES)}")
        # THE answer to "has this feed a second side": explicit, or inherited
        # from its saved query / shared SQL file (source_plan.detect_cross_source)
        from core.feed.source_plan import detect_cross_source as _is_cross
        if raw == "secondary" and not _is_cross(_db_manager, dict(feed or {})):
            raise HTTPException(
                status_code=400,
                detail=f"dependency {row.dependency_key!r}: certifies_side="
                       f"'secondary' but the feed has no secondary connection")
        if raw in seen:
            raise HTTPException(
                status_code=400,
                detail=f"dependency {row.dependency_key!r}: certifies_side="
                       f"{raw!r} is already certified by {seen[raw]!r} -- one "
                       f"dependency per side")
        seen[raw] = row.dependency_key
        out.append(raw)
    return out


async def _watch_declared_iceberg_tables(declared: List[tuple]) -> None:
    from core.feed.arrival_sources import KIND_ICEBERG_COMMIT
    from core.iceberg_watch_registry import (
        ensure_watched, resolve_registered_iceberg_table,
    )
    for sources, _mode in declared:
        for spec in sources:
            if spec.get("kind") != KIND_ICEBERG_COMMIT:
                continue
            try:
                entry, _reason = await adb(resolve_registered_iceberg_table,
                                           _db_manager, int(spec["connection_id"]),
                                           spec["table"])
                if entry is not None:
                    await adb(ensure_watched, _db_manager,
                              int(spec["connection_id"]), entry["bucket"],
                              entry["table_prefix"])
            except Exception as exc:
                logger.warning("[feed_api] could not watch %s on connection %s "
                               "for a declared dependency (non-fatal): %s",
                               spec.get("table"), spec.get("connection_id"), exc)


def _resolve_etl_id_for_feed(feed: dict) -> int:
    """Phase 131 simplification: when the user hasn't set an explicit
    ``etl_id``, default to the feed's own primary key so dep mappings
    are keyed by feed_id transparently.  This keeps the simple case
    (single QS-only feed) frictionless while still letting admins
    override etl_id to align with the OTG side later.

    2026-09-27 — delegates to THE resolver
    (``core.feed.etl_dependency.effective_etl_id``) that SOD, the
    backfill launcher, the poller's query, the cron fire and every
    blocking surface now read, so the key a mapping is WRITTEN under here
    is the key it is ENFORCED under there.  Until then this rule lived
    only on the authoring side and the enforcers keyed on the explicit
    column alone."""
    from core.feed.etl_dependency import effective_etl_id
    return effective_etl_id(feed)


@router.get("/api/feeds/{feed_id}/dependencies")
async def list_feed_dependencies(feed_id: int,
                                   user: dict = Depends(get_current_user)):
    """List the upstream dependencies attached to this feed (Phase 131-A).
    Anyone who can view the feed can read its deps."""
    feed = await _require_feed(feed_id, user, write=False)
    etl_id = _resolve_etl_id_for_feed(feed)
    rows = await adb(_db_manager.list_etl_dependency_mappings, etl_id)
    types = await adb(_db_manager.list_etl_dependency_types, None)
    # Decorate each row with its human-readable type name so the UI
    # doesn't need a second round-trip.
    types_by_id = {int(t["id"]): t for t in types}
    for r in rows:
        t = types_by_id.get(int(r.get("dependency_type_id", 0)))
        if t:
            r["dependency_type"] = t["dependency_type"]
    return {"etl_id": etl_id, "items": rows, "available_types": types}


@router.put("/api/feeds/{feed_id}/dependencies")
async def replace_feed_dependencies(feed_id: int,
                                      body: FeedDependenciesReplace,
                                      user: dict = Depends(get_current_user)):
    """Atomic bulk-replace.  Removes all existing mappings for the feed's
    etl_id then inserts the provided list.  Empty list clears all deps.

    Owner-editable (no admin guard) — same access model as updating the
    feed config itself.  When the feed has no explicit etl_id we use the
    feed_id as the etl_id (Phase 131 default).
    """
    feed = await _require_feed(feed_id, user, write=True)
    etl_id = _resolve_etl_id_for_feed(feed)

    # Validate each row's type id up-front so a partial write doesn't
    # leave the feed in a half-mapped state.
    types = await adb(_db_manager.list_etl_dependency_types, None)
    valid_type_ids = {int(t["id"]) for t in types}
    for row in body.dependencies:
        if int(row.dependency_type_id) not in valid_type_ids:
            raise HTTPException(
                status_code=400,
                detail=f"dependency_type_id={row.dependency_type_id} is not in the catalogue",
            )
        if not row.dependency_key.strip():
            raise HTTPException(status_code=400, detail="dependency_key cannot be empty")
        # FR-DEP-24 — refuse 0 and negatives rather than storing them.
        # "expect at least 0 rows" is satisfied by every possible load, so
        # a 0 typed into the form would read as a check while being
        # incapable of failing; None is how you say "no check".
        if row.expected_rows is not None and int(row.expected_rows) <= 0:
            raise HTTPException(
                status_code=400,
                detail=f"expected_rows={row.expected_rows} for "
                       f"{row.dependency_key!r} is not a row count. Leave it "
                       f"unset to mean NO CHECK -- 0 would be satisfied by "
                       f"every possible load, including a total failure.")
        # FR-DEP-08 — the same existence check the feed's own calendar
        # gets.  A typo here is worse than on the feed: the gate reports
        # COULD NOT TELL for that dependency EVERY night, for ever.
        await _require_valid_calendar_name(row.calendar_name)

    # 2026-09-27 — validate every declared arrival source BEFORE anything
    # is written, and resolve each iceberg_commit table so a typo is a 400
    # now rather than COULD NOT TELL at 04:19.
    declared = await _validated_arrival_sources(body.dependencies, user)
    # 2026-10-11 -- the side a dependency's reported row count certifies.
    certified_sides = _validated_certifies_sides(feed, body.dependencies)

    # FR-DEP-22 — refuse a cycle BEFORE anything is written.  Only active
    # rows participate: an inactive dependency does not gate, so it cannot
    # deadlock, and refusing it would be a false refusal.
    await _refuse_dependency_cycle(
        feed, etl_id,
        [r.dependency_key.strip() for r in body.dependencies if r.is_active])

    # Delete current rows, then re-insert.  Both calls go through the
    # mixin so they share a session if the caller wraps them.
    existing = await adb(_db_manager.list_etl_dependency_mappings, etl_id)
    for r in existing:
        await adb(_db_manager.delete_etl_dependency_mapping, int(r["id"]))
    _written_rows = []
    for idx, row in enumerate(body.dependencies):
        sources, mode = declared[idx]
        _written_rows.append(await adb(_db_manager.create_etl_dependency_mapping, {
            "etl_id":             etl_id,
            "dependency_type_id": int(row.dependency_type_id),
            "dependency_key":     row.dependency_key.strip(),
            "description":        row.description or None,
            # FR-DEP-08 / FR-DEP-24 — both columns and both readers have
            # existed since 2026-09-02; without these two lines the
            # pydantic fields were accepted and SILENTLY DROPPED, which is
            # indistinguishable from working code.
            "calendar_name":      row.calendar_name or None,
            "expected_rows":      (int(row.expected_rows)
                                   if row.expected_rows is not None else None),
            # 2026-09-27 — stored only when declared; a NULL keeps the
            # legacy rule and ``require_mode`` means nothing without a
            # declaration.
            "arrival_sources":    sources or None,
            "require_mode":       (mode if sources else None),
            "certifies_side":     certified_sides[idx],
            "reruns_delivered":   row.reruns_delivered,
            "is_active":          bool(row.is_active),
        }))
    _note_dependency_rows(etl_id, [r for r in _written_rows
                                   if (r or {}).get("is_active", True)])
    # A declared Iceberg table must be OBSERVED or the source can never
    # meet: watch it now (idempotent, fail-open -- the registration routes
    # do the same; this covers a table registered before that rule).
    await _watch_declared_iceberg_tables(declared)

    # Phase 131-A — when the user has added deps to a feed that didn't
    # have an explicit etl_id, persist etl_id = feed_id so the existing
    # poller's filter ("feed_configs.etl_id IS NOT NULL") catches the
    # feed on its next tick.  No-op when feed already has an etl_id.
    if feed.get("etl_id") is None and body.dependencies:
        await adb(_db_manager.update_feed_config, feed_id, {"etl_id": etl_id})

    username = user.get("username", "unknown")
    logger.info(
        "Feed %d dependencies replaced by %s: %d rows (etl_id=%d)",
        feed_id, username, len(body.dependencies), etl_id,
    )
    _audit("feed_dependencies_replaced", user, {
        "feed_id":  feed_id,
        "etl_id":   etl_id,
        "old_count": len(existing),
        "new_count": len(body.dependencies),
    })
    return await list_feed_dependencies(feed_id, user)


class FeedExecuteRequest(BaseModel):
    """Phase 132.38 — body of POST /api/feeds/{id}/execute.

    Optional ``query_params`` lets the dashboard-side caller supply
    runtime overrides for Dynamic WHERE rows the publisher declared on
    the feed config.  Existing callers that pass no body keep the
    legacy ``trigger_type='manual'`` behaviour with no overrides.

    feed-seam (2026-07-16) — ``trigger_type`` + ``business_date`` let an
    external orchestrator (Airflow / OTG) drive the SAME endpoint the UI
    uses.  Both are optional; the UI "Run now" path omits them and keeps
    its exact legacy behaviour (trigger_type='manual', no business_date).
    """
    query_params: Optional[Dict[str, Any]] = Field(default=None)
    trigger_type: str = Field(default="manual")
    business_date: Optional[str] = Field(default=None)
    # 2026-09-27 -- Run Now PREFLIGHT.  For a manual trigger the route
    # evaluates the dependency gate for ``business_date`` (today when
    # omitted) through THE gate (``core.feed.etl_dependency.run_preflight``).
    # When anything is NOT met a reason is REQUIRED -- the same vocabulary
    # as a dependency skip (``GET /api/feed-dependencies/skip-reasons``) --
    # and the run then goes with ``dependencies_overridden`` on its record.
    # Run Now stays NON-blocking: with a reason it always runs.
    override_reason_category: Optional[str] = Field(default=None)
    override_reason: Optional[str] = Field(default=None)
    # 2026-08-22 (spark_k8s) — ``detached=true`` creates the execution row
    # WITHOUT spawning background compute: the external orchestrator that
    # triggered it drives compute itself (e.g. the Airflow feed factory
    # then POSTs /api/feed-executions/{execution_id}/spark-submit, and the
    # signed webhook + reconciler complete the row).  Honoured ONLY for
    # external-orchestrator trigger_types (airflow/otg): before this flag
    # the factory DAG's trigger call ALSO started a full QS-side run of
    # the same feed — the double-execution the run either 409-collided on
    # or silently doubled.  UI/manual/scheduled triggers ignore it.
    detached: bool = Field(default=False)
    # 2026-09-27 -- a DRY RUN: the full chain (query, format, packaging,
    # compression, checksum, control file, integrity, row-count check)
    # runs, NOTHING is delivered, no delivery attempt is written and
    # nothing is certified; the produced file is a transient Download
    # Centre item (1-day retention).  The execution's trigger_type and the
    # run's run_type are ``dry_run`` so every screen marks it.  Honoured
    # for the UI's manual trigger only.
    dry_run: bool = Field(default=False)


#: The trigger_type / run_type of a dry run (core/feed_engine.py
#: ``dry_run=True``).  Never a caller-declared trigger_type: the flag is.
DRY_RUN_TRIGGER = "dry_run"

#: Lanes that deliver INSIDE the job, where the engine cannot hold the
#: file back -- a dry run on them is refused up front, never "delivered
#: anyway".
_DRY_RUN_REFUSED_LANES = frozenset({"airflow", "spark_k8s"})


# feed-seam — trigger_types an external orchestrator may declare on the
# execute endpoint.  ``manual`` is the UI default; ``scheduled``/``queue``
# are internal; ``airflow``/``otg`` are external orchestrators for whom the
# FeedExecutor is the single execution authority (no duplicate background run).
_ALLOWED_EXECUTE_TRIGGERS = frozenset({
    "manual", "scheduled", "queue", "airflow", "otg", "rerun", "restatement", "retry",
})


@router.post("/api/feeds/{feed_id}/execute")
async def execute_feed_endpoint(
    feed_id: int,
    background_tasks: BackgroundTasks,
    backend: Optional[str] = None,
    body: Optional[FeedExecuteRequest] = None,
    override_deployment_window: bool = False,
    user: dict = Depends(get_current_user),
):
    """Trigger on-demand feed execution (runs in background).

    Optional ``?backend=native|airflow`` per-execution override lets
    admins/owners force this single run via a specific backend (Phase
    130 hotfix-13).  No value = use feed's persisted execution_backend
    / global override / auto-router as normal.

    Phase 132.38 — optional ``query_params`` JSON body applies
    per-trigger overrides to any Dynamic WHERE rows the publisher
    declared on the feed_config.  Same primitive Published Views uses;
    Static rows remain locked even when the caller supplies a key for
    that column.
    """
    per_exec_backend = _validate_per_execution_override(backend)
    feed = await _require_feed(feed_id, user, write=True)
    if not feed.get("is_active"):
        raise HTTPException(status_code=400, detail="Feed is inactive")
    # FR-OPS-04 — an active change window refuses the START (never a run
    # in flight).  Admin override is audited.
    await _refuse_if_deployment_window(feed, user,
                                       override_deployment_window,
                                       "execute")

    username = user.get("username", "unknown")
    overrides = (body.query_params if body else None) or None

    # feed-seam (2026-07-16) — resolve the trigger surface.  The UI omits
    # trigger_type → "manual" (exact legacy behaviour).  An external
    # orchestrator (Airflow/OTG) declares its own trigger_type + optional
    # business_date so the SAME endpoint single-sources feed logic.
    trigger_type = (body.trigger_type if body else None) or "manual"
    if trigger_type not in _ALLOWED_EXECUTE_TRIGGERS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported trigger_type '{trigger_type}'",
        )
    business_date = (body.business_date if body else None) or None
    dry_run = bool(body.dry_run if body else False)
    if dry_run:
        if trigger_type != "manual":
            raise HTTPException(
                status_code=400,
                detail="dry_run is a manual (UI) action; an orchestrator "
                       "trigger cannot be a dry run")
        _lane = str((per_exec_backend or feed.get("execution_backend")
                     or "")).lower()
        if _lane in _DRY_RUN_REFUSED_LANES:
            raise HTTPException(
                status_code=409,
                detail=f"A dry run is not available on the {_lane!r} lane: "
                       f"that lane delivers inside the job, so the engine "
                       f"cannot hold the file back.  Run it with "
                       f"?backend=native, or use a backfill without "
                       f"delivery.")
        trigger_type = DRY_RUN_TRIGGER

    # 2026-09-27 -- Run Now preflight: what the gate says for the date, and
    # a REQUIRED reason when it says not met.  Manual only: an external
    # orchestrator asserting "run now" is reported, not gated (qs-feedgen).
    dependencies_overridden: Optional[Dict[str, Any]] = None
    # A DRY RUN needs no override: nothing is delivered, so there is nothing
    # to override -- the preflight is Run Now's alone (merge decision
    # 2026-09-27; the dry run stays a separate menu action, body {dry_run}).
    if trigger_type == "manual" and not dry_run:
        dependencies_overridden = await _manual_run_override(
            feed, business_date,
            (body.override_reason_category if body else None),
            (body.override_reason if body else None), user)

    # Atomic create: prevents duplicate concurrent executions (Phase 132-B)
    # and lets us return execution_id + a 409 synchronously.  The seam
    # (run_feed) REUSES this pre-created row by execution_id — it does NOT
    # create a second one — so there is exactly ONE execution regardless of
    # trigger source (audit gap #7 — double-execution guard).
    execution_id = f"feed-{uuid.uuid4().hex[:16]}"
    _detached = (bool(body.detached if body else False)
                 and trigger_type in ("airflow", "otg"))
    exec_record = _db_manager.create_feed_execution_atomic(feed_id, {
        "feed_config_id": feed_id,
        "execution_id": execution_id,
        "status": "pending",
        "execution_backend": per_exec_backend or "auto",
        "trigger_type": trigger_type,
        "triggered_by": username,
        "started_at": datetime.now(timezone.utc),
    })
    if exec_record is None:
        # 2026-08-22 (spark_k8s) — detached-trigger idempotency: an
        # orchestrator RETRY of the trigger call (transient network failure
        # whose first attempt actually landed) used to 409 here, failing
        # the DAG permanently while the detached pending row blocked the
        # feed until the timeout watchdog swept it.  A detached external
        # trigger now REUSES the orchestrator-owned active row instead.
        # Every other caller keeps the strict 409.
        if _detached:
            _rows = await adb(_db_manager.list_feed_executions, feed_id, 5)
            _reusable = next(
                (r for r in _rows
                 if (r.get("status") or "").lower() in ("pending", "running")
                 and (r.get("trigger_type") or "").lower() in ("airflow", "otg")),
                None,
            )
            if _reusable is not None:
                logger.info(
                    "Feed %d detached trigger reusing active execution %s "
                    "(idempotent orchestrator retry)",
                    feed_id, _reusable.get("execution_id"),
                )
                return {
                    "detail": "Execution reused (detached idempotent retry)",
                    "feed_id": feed_id,
                    "execution_id": _reusable.get("execution_id"),
                    "execution_db_id": _reusable.get("id"),
                    "trigger_type": trigger_type,
                    "detached": True,
                    "reused": True,
                }
        raise HTTPException(
            status_code=409,
            detail="Feed already has a pending or running execution",
        )

    # 2026-08-22 (spark_k8s) — detached mode: the external orchestrator owns
    # compute.  Create the row, run NOTHING here; the orchestrator submits
    # via /spark-submit and the webhook + reconciler drive it terminal.
    if _detached:
        logger.info(
            "Feed %d execution created DETACHED by %s (execution_id=%s, "
            "trigger=%s) — no QS-side compute; awaiting orchestrator submit",
            feed_id, username, execution_id, trigger_type,
        )
        return {
            "detail": "Execution created (detached — orchestrator drives compute)",
            "feed_id": feed_id,
            "execution_id": execution_id,
            "execution_db_id": exec_record["id"],
            "trigger_type": trigger_type,
            "detached": True,
        }

    # Route through the FeedExecutor seam — the SINGLE execution authority.
    # We no longer call execute_feed directly from the endpoint; run_feed is
    # the sole caller of the pipeline, so an external-orchestrator trigger
    # can never also spawn a second background execute_feed.  The heavy work
    # still runs in the background so "Run now" returns immediately as before.
    async def _run():
        from core.feed_executor import run_feed
        await run_feed(
            feed_id,
            business_date=business_date,
            trigger_type=trigger_type,
            param_values=overrides,
            execution_id=execution_id,   # reuse the pre-created row (no double create)
            triggered_by=username,
            backend_override=per_exec_backend,
            dependencies_overridden=dependencies_overridden,
            dry_run=dry_run,
        )

    background_tasks.add_task(_run)
    logger.info("Feed %d execution triggered by %s (execution_id=%s, trigger=%s)",
                feed_id, username, execution_id, trigger_type)
    if dependencies_overridden:
        _audit("feed_run_now_dependencies_overridden", user, {
            "feed_id": feed_id, "execution_id": execution_id,
            **{k: dependencies_overridden.get(k)
               for k in ("business_date", "not_met", "reason", "reason_category")}})
    return {
        "detail": ("Feed DRY RUN started -- nothing will be delivered"
                   if dry_run else "Feed execution started"),
        "feed_id": feed_id,
        "execution_id": execution_id,
        "execution_db_id": exec_record["id"],
        "trigger_type": trigger_type,
        "dependencies_overridden": dependencies_overridden,
        "dry_run": dry_run,
    }


def _preflight_business_date(raw: Optional[str]) -> date:
    from datetime import date as _date
    if not raw:
        return datetime.now(timezone.utc).date()
    try:
        return _date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(status_code=422,
                            detail=f"business_date {raw!r} is not an ISO "
                                   f"date (YYYY-MM-DD).")


async def _manual_run_override(feed: dict, business_date: Optional[str],
                               reason_category: Optional[str],
                               reason: Optional[str],
                               user: dict) -> Optional[Dict[str, Any]]:
    """The Run Now gate question, answered ONCE for the execute route:
    None when the gate admits the date (no reason needed, none recorded);
    the ``dependencies_overridden`` record when it does not and a VALID
    reason was given; a 422 naming the blocking dependencies and what a
    valid reason is when it does not and none was.  Never refuses on the
    gate itself -- Run Now is explicit operator intent."""
    from core.feed.etl_dependency import run_preflight
    bd = _preflight_business_date(business_date)
    preflight = await adb(run_preflight, _db_manager, feed, bd)
    from core.feed.dependency_skip import SkipReasonRefused, validate_skip_reason
    blocking = list(preflight.get("blocking") or [])
    has_reason = bool(str(reason or "").strip() or str(reason_category or "").strip())
    if preflight.get("unavailable") and not has_reason:
        # Fail OPEN, loudly -- the posture of the deployment-window read
        # above and of hold_reason_at_creation: an unreadable gate is not
        # "not met", and a Run Now must not be refused on a read failure.
        logger.error(
            "[feed_api] Run Now for feed %s @ %s: the dependency gate could "
            "not be read (%s) -- dependencies NOT CHECKED for this run "
            "(fail-open); no override recorded because none was asserted",
            feed.get("id"), bd.isoformat(), preflight.get("unavailable"))
        return None
    if not preflight.get("override_required") and not preflight.get("unavailable"):
        return None
    why = (f"the dependency gate could not be read "
           f"({preflight.get('unavailable')})"
           if preflight.get("unavailable")
           else f"not met for {bd.isoformat()}: {', '.join(blocking)}")
    if not has_reason:
        raise HTTPException(
            status_code=422,
            detail=f"Run Now needs a reason: {why}.  Running anyway is "
                   f"allowed (this is your call, not the gate's), but it is "
                   f"recorded, so send override_reason_category (one of "
                   f"upstream_holiday, upstream_outage, data_not_needed, "
                   f"other) and override_reason (what is late and why the "
                   f"feed may go without it).  GET /api/feeds/{feed.get('id')}"
                   f"/run-preflight?business_date={bd.isoformat()} shows each "
                   f"dependency's verdict.")
    try:
        valid = validate_skip_reason(reason_category, reason)
    except SkipReasonRefused as exc:
        raise HTTPException(status_code=422,
                            detail=f"Run Now override refused: {exc}")
    return {
        "reason": valid.as_text(),
        "reason_category": valid.category,
        "business_date": bd.isoformat(),
        "not_met": blocking,
        "unavailable": preflight.get("unavailable"),
        "verdicts": [{"dependency_name": v.get("dependency_name"),
                      "verdict": v.get("verdict"), "reason": v.get("reason")}
                     for v in (preflight.get("verdicts") or [])],
        "by": str(user.get("username") or "unknown"),
    }


@router.get("/api/feeds/{feed_id}/run-preflight")
async def feed_run_preflight(feed_id: int,
                             business_date: Optional[str] = None,
                             user: dict = Depends(get_current_user)):
    """What a Run Now for ``business_date`` (default today UTC) would find
    at the dependency gate: each dependency's verdict and reason, from THE
    gate the poller and the skip routes read (2026-09-27).  Read access:
    anyone who can view the feed may ask; running it is gated separately.
    ``override_required`` is True when a reason will be needed."""
    feed = await _require_feed(feed_id, user, write=False)
    from core.feed.etl_dependency import run_preflight
    bd = _preflight_business_date(business_date)
    out = await adb(run_preflight, _db_manager, feed, bd)
    out["feed_id"] = int(feed_id)
    out["feed_name"] = feed.get("name")
    out["can_run"] = bool(await adb(_can_rerun_feed, feed, user)) \
        if _auth_on() else True
    return out


@router.post("/api/feeds/{feed_id}/enable-schedule")
async def enable_schedule(feed_id: int, user: dict = Depends(get_current_user)):
    """Register APScheduler job for the feed."""
    feed = await _require_feed(feed_id, user, write=True)
    if not feed.get("cron_expression"):
        raise HTTPException(status_code=400, detail="No cron expression configured")

    # Phase 4 (2026-08-23): a STORED cron can predate the create/update
    # validators — refuse to enable a schedule the scheduler cannot run,
    # naming the fix, instead of 200 + a feed that never fires.
    from core.feed.schedule_reconciler import validate_cron_and_tz
    try:
        validate_cron_and_tz(feed["cron_expression"], feed.get("timezone", "UTC"))
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot enable schedule: {exc}. Fix the cron expression "
                   f"or timezone on the feed first.")

    # 2026-09-03 — going-live gates, in refusal order:
    # a retiring feed cannot go live at all; a NEW feed (stamped at
    # create/clone) needs its PII declaration and acceptance sign-off
    # first (FR-ACC-02: a feed does not go live because the platform
    # produced a file without erroring).  Pre-existing feeds carry no
    # acceptance stamp and pass — the stated non-bricking posture.
    from core.feed import lifecycle as _lifecycle
    _ret = await adb(_lifecycle.retirement_active, _db_manager, feed_id)
    if _ret:
        raise HTTPException(
            status_code=409,
            detail=f"Feed {feed.get('name')!r} is retiring (quarantine "
                   f"until {_ret.get('quarantine_until')}) — a retiring "
                   f"feed cannot be scheduled.  POST "
                   f"/api/feeds/{feed_id}/unretire first if it should "
                   f"live again.")
    _gate = await adb(_lifecycle.acceptance_gate_refusals, _db_manager,
                      feed)
    if _gate:
        raise HTTPException(
            status_code=409,
            detail={"message": f"Feed {feed.get('name')!r} cannot go "
                               f"live yet (feed_id={feed_id})",
                    "refusals": _gate})
    await adb(_db_manager.update_feed_config, feed_id, {"schedule_enabled": True})
    _register_schedule(feed_id, feed["cron_expression"],
                      feed.get("timezone", "UTC"), feed["name"])
    logger.info("Feed %d schedule enabled by %s", feed_id, user.get("username"))
    return {"detail": "Schedule enabled", "feed_id": feed_id}


@router.post("/api/feeds/{feed_id}/disable-schedule")
async def disable_schedule(feed_id: int, user: dict = Depends(get_current_user)):
    """Remove APScheduler job for the feed."""
    await _require_feed(feed_id, user, write=True)
    _unregister_schedule(feed_id)
    await adb(_db_manager.update_feed_config, feed_id, {"schedule_enabled": False})
    logger.info("Feed %d schedule disabled by %s", feed_id, user.get("username"))
    return {"detail": "Schedule disabled", "feed_id": feed_id}


@router.post("/api/feeds/{feed_id}/test-destination")
async def test_destination(feed_id: int, user: dict = Depends(get_current_user)):
    """Test connectivity to the configured destination.

    BF-NONBLOCK-AUDIT-3: this endpoint chains sync DB read + boto3
    head_bucket / paramiko SSH / oracledb.connect — any of which can
    stall for 10+ seconds on a slow network.  Wrap the whole body in
    asyncio.to_thread so /health, WebSocket pings, and concurrent
    requests aren't starved.  90s overall budget — destination probes
    SHOULD fail fast; a connect that takes that long is itself the
    failure signal.
    """
    # Uses the feed's STORED delivery credentials — require edit rights.
    await _require_feed(feed_id, user, write=True)

    def _inner() -> Dict[str, Any]:
        feed = _db_manager.get_feed_config(feed_id)
        if not feed:
            raise HTTPException(status_code=404, detail=f"Feed config {feed_id} not found")

        dest_type = feed.get("destination_type", "local")
        dest_config = feed.get("destination_config") or {}

        try:
            if dest_type == "local":
                dest_dir = dest_config.get("path", "/usr/local/querystudioapi/nfs/data/feeds")
                os.makedirs(dest_dir, exist_ok=True)
                test_path = os.path.join(dest_dir, ".test_connectivity")
                with open(test_path, "w") as f:
                    f.write("test")
                os.unlink(test_path)
                return {"success": True, "message": f"Local directory '{dest_dir}' is writable"}

            elif dest_type == "s3":
                import boto3
                s3_kwargs = {}
                if dest_config.get("endpoint_url"):
                    s3_kwargs["endpoint_url"] = dest_config["endpoint_url"]
                if dest_config.get("region"):
                    s3_kwargs["region_name"] = dest_config["region"]
                if dest_config.get("access_key_id"):
                    s3_kwargs["aws_access_key_id"] = dest_config["access_key_id"]
                    s3_kwargs["aws_secret_access_key"] = dest_config.get("secret_access_key", "")
                from botocore.config import Config as BotoConfig
                from core.proxy_utils import get_boto_proxies
                _px = get_boto_proxies(endpoint_url=dest_config.get("endpoint_url", ""))
                if _px:
                    s3_kwargs["config"] = BotoConfig(proxies=_px)
                client = boto3.client("s3", **s3_kwargs)
                bucket = dest_config.get("bucket", "")
                client.head_bucket(Bucket=bucket)
                return {"success": True, "message": f"S3 bucket '{bucket}' is accessible"}

            elif dest_type == "sftp":
                try:
                    import paramiko
                except ImportError:
                    raise HTTPException(status_code=400, detail="paramiko not installed")
                host = dest_config.get("host", "")
                port = int(dest_config.get("port", 22))
                import socket
                try:
                    _sock = socket.create_connection((host, port), timeout=10)
                except (socket.timeout, OSError) as _se:
                    raise HTTPException(
                        status_code=400,
                        detail=f"SFTP host {host}:{port} unreachable within 10 s: {_se}",
                    )
                transport = paramiko.Transport(_sock)
                try:
                    username = dest_config.get("username", "")
                    password = dest_config.get("password", "")
                    transport.connect(username=username, password=password)
                    sftp = paramiko.SFTPClient.from_transport(transport)
                    sftp.listdir(dest_config.get("remote_dir", "/"))
                    sftp.close()
                    return {"success": True, "message": f"SFTP host {host}:{port} is accessible"}
                finally:
                    transport.close()
            elif dest_type == "oracle":
                try:
                    import oracledb
                except ImportError:
                    raise HTTPException(status_code=400, detail="oracledb not installed")
                connection_id = dest_config.get("connection_id")
                if not connection_id:
                    raise HTTPException(status_code=400, detail="Oracle destination requires connection_id")
                conn_record = _db_manager.get_connection_raw(connection_id)
                if not conn_record:
                    raise HTTPException(status_code=404, detail=f"Connection {connection_id} not found")
                # Falsy-coalesce — NULL config column (rare but seen
                # in prod) makes `.get("k", {})` return None.
                conn_cfg = conn_record.get("config") or {}
                dsn = oracledb.makedsn(
                    conn_cfg.get("host", ""), int(conn_cfg.get("port") or 1521),
                    service_name=conn_cfg.get("service_name", ""),
                )
                ora_conn = oracledb.connect(
                    user=conn_cfg.get("username", ""),
                    password=conn_cfg.get("password", ""),
                    dsn=dsn,
                )
                ora_conn.close()
                return {"success": True, "message": f"Oracle connection {connection_id} is accessible"}
            else:
                raise HTTPException(status_code=400, detail=f"Unknown destination type: {dest_type}")

        except HTTPException:
            raise
        except Exception as exc:
            return {"success": False, "message": str(exc)[:500]}

    try:
        return await asyncio.wait_for(asyncio.to_thread(_inner), timeout=90.0)
    except asyncio.TimeoutError:
        return {"success": False,
                "message": "Destination probe exceeded 90s — treat as unreachable."}


@router.post("/api/feeds/quick-create")
async def quick_create_feed(
    body: QuickCreateFeed,
    background_tasks: BackgroundTasks,
    user: dict = Depends(get_current_user),
):
    """Quick create feed with minimal config + optional immediate execute."""
    username = user.get("username", "unknown")

    # Build a name from source
    name = f"quick_feed_{body.source_type}_{body.source_id}"

    data = {
        "name": name,
        "source_type": body.source_type,
        "source_id": body.source_id,
        "connection_id": body.connection_id,
        "output_format": body.output_format,
        "destination_type": body.destination_type,
        "destination_config": body.destination_config,
        "created_by": username,
    }
    result = _db_manager.create_feed_config(data)

    # FR-ACC-02 — quick-create is still ONBOARDING: without this stamp
    # the acceptance gate would be bypassable by quick-creating and then
    # attaching a cron, which is a side door not a posture.
    from core.feed import lifecycle as _lifecycle
    _lifecycle.stamp_onboarding(_db_manager, result["id"], username)

    # SECURITY AUDIT 2026-08-03 (S4): same masking as POST /api/feeds.
    response = {"feed": _mask_feed_secrets(result), "execution_started": False}

    if body.execute_now:
        feed_id = result["id"]

        async def _run():
            from core.feed_engine import execute_feed
            await execute_feed(feed_id, trigger_type="manual", triggered_by=username)

        background_tasks.add_task(_run)
        response["execution_started"] = True

    return response


# ── History Endpoints ─────────────────────────────────────────────────────────

@router.get("/api/feeds/{feed_id}/executions")
async def list_executions(
    feed_id: int,
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    user: dict = Depends(get_current_user),
):
    """List executions for a feed config."""
    await _require_feed(feed_id, user, write=False)
    return await adb(_db_manager.list_feed_executions, feed_id, limit=limit, offset=offset)


@router.get("/api/feed-executions/{exec_id}")
async def get_execution(exec_id: int, user: dict = Depends(get_current_user)):
    """Get a single execution detail."""
    result, _feed = await _require_feed_for_execution(exec_id, user, write=False)
    # 2026-07-18 Completeness Certificate — hoist the source-read trust verdict
    # (captured into files_metadata by core.feed_perf) to a top-level
    # `certificate` field so the UI can render a badge without digging into
    # files_metadata.  Observational + fail-open: absent → field omitted.
    try:
        if isinstance(result, dict):
            _fm = result.get("files_metadata")
            _cert = _fm.get("completeness_certificate") if isinstance(_fm, dict) else None
            if _cert:
                result["certificate"] = _cert
    except Exception:
        pass
    # 2026-10-07 -- what the log view is looking at (live tail / stored /
    # not available on this pod / unknown): the UI reads ``run_log`` and
    # never guesses.  ``log_stream`` itself rides in the row's to_dict.
    if isinstance(result, dict):
        from core.feed.run_log_view import run_log_view
        result["run_log"] = run_log_view(result)
        # 2026-10-14 -- WHERE the run is (core/feed/run_progress.py)
        from core.feed.run_progress import progress_view, stale_after_seconds
        result["progress"] = progress_view(result, stale_after_seconds=stale_after_seconds())
    return result


@router.post("/api/feed-executions/{exec_id}/retry")
async def retry_execution(
    exec_id: int,
    background_tasks: BackgroundTasks,
    override_deployment_window: bool = False,
    user: dict = Depends(get_current_user),
):
    """Retry a failed execution."""
    execution, _feed = await _require_feed_for_execution(exec_id, user, write=True)
    if execution.get("status") not in ("failed", "cancelled"):
        raise HTTPException(status_code=400, detail="Can only retry failed or cancelled executions")
    if _feed is not None:
        # FR-OPS-04 — a retry STARTS a run.
        await _refuse_if_deployment_window(_feed, user,
                                           override_deployment_window,
                                           "retry")

    feed_id = execution["feed_config_id"]
    username = user.get("username", "unknown")

    # Phase 4 (2026-08-23): bind the retry to the day's feed_run row so a
    # SUCCESSFUL retry updates the dashboard.  Before, the today page kept
    # showing the row as Failed forever after a retry delivered fine.
    # Resolution: the failed execution's day first (retrying yesterday's
    # failure late at night updates yesterday's row), today as fallback.
    feed_run_id: Optional[int] = None
    try:
        _days = []
        _started = execution.get("started_at")
        if _started:
            try:
                _days.append(datetime.fromisoformat(str(_started)[:19]).date())
            except Exception:
                pass
        _today = datetime.now(timezone.utc).date()
        if _today not in _days:
            _days.append(_today)
        for _d in _days:
            _row = await adb(_db_manager.get_feed_run_by_feed_date, feed_id, _d)
            if _row and str(_row.get("status") or "").lower() in ("failed", "pending", "running"):
                feed_run_id = int(_row["id"])
                break
    except Exception as _fr_exc:
        logger.debug("retry_execution: feed_run resolution failed: %s", _fr_exc)

    async def _run():
        from core.feed_engine import execute_feed
        await execute_feed(feed_id, trigger_type="retry", triggered_by=username,
                           feed_run_id=feed_run_id)

    background_tasks.add_task(_run)
    return {"detail": "Retry started", "feed_id": feed_id,
            "feed_run_id": feed_run_id}


@router.post("/api/feed-executions/{exec_id}/cancel")
async def cancel_execution(exec_id: int, user: dict = Depends(get_current_user)):
    """Cancel a running execution.

    BF-415 — previously this endpoint only flipped the DB row to
    ``cancelled``.  The background task kept executing (no polling) and
    eventually overwrote status back to ``completed``.  Now we also signal
    the in-process cancellation event so ``execute_feed`` short-circuits
    at its next stage checkpoint, and we set ``cancel_requested`` /
    ``status='cancelled'`` in the DB so cross-pod cancels work too — pods
    running the task in another process pick it up via the periodic DB
    poll in ``feed_engine._check_cancelled``.  Callers should still treat
    this as best-effort: a stage that's mid-S3-upload will finish that
    operation before the next checkpoint.
    """
    execution, _feed = await _require_feed_for_execution(exec_id, user, write=True)
    if execution.get("status") not in ("pending", "running"):
        raise HTTPException(status_code=400, detail="Can only cancel pending or running executions")

    # Persist cancellation in the DB FIRST so a pod that hasn't yet started
    # the task (or is on a different pod) picks it up.
    await adb(_db_manager.update_feed_execution, exec_id, {
        "status": "cancelled",
        "completed_at": datetime.now(timezone.utc),
        "error_message": f"Cancelled by {user.get('username', 'unknown')}",
    })
    # 2026-10-11 -- the execution's RUN is cancelled with it.  Found live: a
    # pod OOM-killed mid-run left the run ``running`` with no worker to sync
    # it; this route cancelled the execution, ``/feed-runs/{id}/cancel``
    # refuses a running run, and the orphan reaper would then reset the run
    # to ``pending`` and the queue worker EXECUTE it again -- after the
    # operator cancelled it.  A live worker's own end-of-run sync writes the
    # same terminal state, and its heartbeat reads a terminal row as the
    # run ending (queue_worker._beat_once), so this is safe either way.
    await adb(_cancel_execution_run, execution, user)

    # Signal the in-process event for the case where THIS pod is running
    # the task — short-circuits at the next stage checkpoint.
    try:
        from core.feed_engine import signal_cancel
        signal_cancel(execution.get("execution_id") or "")
    except Exception as _sig_exc:
        logger.debug("[feed_cancel] signal_cancel raised (non-fatal): %s", _sig_exc)

    # spark_k8s (2026-08-22): the compute is a detached SparkApplication —
    # cancelling the row alone would leave the cluster computing.  Delete
    # the CR best-effort HERE (this pod may lack cluster access); the
    # reconciler's terminal-row sweep is the guarantee that a live CR for
    # a cancelled row is deleted within one reconcile interval.
    if (execution.get("execution_backend") or "").lower() == "spark_k8s":
        def _cancel_cr(_exec=dict(execution)):
            try:
                from core.spark_k8s.runner import SparkK8sRunner
                SparkK8sRunner(_db_manager).cancel(_exec)
            except Exception as _cr_exc:
                logger.warning(
                    "[feed_cancel] best-effort SparkApplication delete "
                    "failed for %s (the reconciler will finish the job): %s",
                    _exec.get("execution_id"), _cr_exc,
                )
        await asyncio.to_thread(_cancel_cr)

    return {"detail": "Execution cancelled", "id": exec_id}


def _cancel_execution_run(execution: dict, user: dict) -> None:
    """Close the cancelled execution's bound feed_run when it is still
    active (see cancel_execution).  Best-effort: the execution cancel is the
    answer; a run left behind is logged, never a 500."""
    try:
        _fr_for = getattr(_db_manager, "feed_run_for_execution", None)
        fr = _fr_for(execution) if callable(_fr_for) else None
        if fr and (fr.get("status") or "") in ("pending", "running"):
            _db_manager.update_feed_run(int(fr["id"]), {
                "status": "cancelled",
                "completed_at": datetime.now(timezone.utc),
                "error": (f"Cancelled with execution {execution.get('id')} "
                          f"by {user.get('username', 'unknown')}")})
    except Exception as exc:                       # noqa: BLE001
        logger.warning("cancel of execution %s: its feed_run was not "
                       "cancelled with it (%s) -- the orphan reaper may "
                       "re-queue it", execution.get("id"), exc)


class SparkSubmitRequest(BaseModel):
    """Body of POST /api/feed-executions/{execution_id}/spark-submit.

    ``run_date`` (ISO date, optional): the orchestrator's logical date so
    calendar tokens (business_date etc.) resolve against the RUN, not the
    submit wall-clock (E-M6 semantics).  Omitted → today UTC.
    """
    run_date: Optional[str] = Field(default=None)


def _record_submit_refusal(execution: dict, **fields) -> None:
    """A 503 from /spark-submit, written on the row as
    ``stage_timings.spark_submit_refusal`` (merged over a FRESH read) so
    the engine's airflow lane -- which awaits this row while the DAG
    retries -- can apply the SAME submit-time rule the spark_k8s lane
    applies (``backend_router.lane_failed_at_submit``), and so an
    Airflow-scheduled run's record says why its DAG failed.  Best-effort:
    the 503 is the answer, this is its trace."""
    try:
        fresh = _db_manager.get_feed_execution(execution["id"]) or {}
        st = dict(fresh.get("stage_timings") or {})
        st["spark_submit_refusal"] = {
            **fields, "at": datetime.now(timezone.utc).isoformat()}
        _db_manager.update_feed_execution(execution["id"],
                                          {"stage_timings": st})
    except Exception as exc:                       # noqa: BLE001
        logger.warning("spark-submit of %s: refusal not recorded on the "
                       "row (%s)", execution.get("execution_id"), exc)


def _fail_submit_refused(execution: dict, message: str) -> None:
    """A DECLARED refusal from the conf builder / JDBC grammar / plan
    chokepoint (a 422) is not transient: the orchestrator's retry meets the
    same answer.  Record it as the run's failure so the row never sits
    ``running`` waiting for a submit that cannot happen -- the engine's
    airflow lane reads it at once, an Airflow-scheduled run shows it, and
    a DAG retry gets the 409 for a terminal row (2026-10-08)."""
    now = datetime.now(timezone.utc)
    try:
        _db_manager.update_feed_execution(execution["id"], {
            "status": "failed", "completed_at": now,
            "error_message": str(message)[:2000],
            "failed_stage": "spark_submit"})
        _fr_for = getattr(_db_manager, "feed_run_for_execution", None)
        fr = _fr_for(execution) if callable(_fr_for) else None
        if fr and (fr.get("status") or "") in ("pending", "running"):
            _db_manager.update_feed_run(int(fr["id"]), {
                "status": "failed", "completed_at": now,
                "error": str(message)[:2000]})
    except Exception as exc:                       # noqa: BLE001
        logger.warning("spark-submit of %s: refusal not recorded as the "
                       "run's failure (%s)", execution.get("execution_id"),
                       exc)


@router.post("/api/feed-executions/{execution_id}/spark-submit")
async def spark_submit_execution(
    execution_id: str,
    body: Optional[SparkSubmitRequest] = None,
    user: dict = Depends(get_current_user),
):
    """Submit an existing execution as a QueryStudio-owned SparkApplication.

    2026-08-22 — THE seam through which the Airflow feed factory now runs
    its Spark fallback: the DAG no longer builds manifests or talks to the
    Kubernetes API; it triggers an execution (detached), then calls this
    endpoint, and the SAME builder + runner + reconciler that serve the
    native spark_k8s backend do everything else.  One builder, one
    submitter, one supervisor — regardless of who orchestrates.

    Semantics:
      * execution must exist and be pending/running (409 otherwise);
      * a duplicate call is IDEMPOTENT — the CR name is the idempotency
        key, a k8s 409 means "already running" and returns 200 with
        ``already_running=true`` (an orchestrator retry after a network
        blip must never double-submit);
      * unavailability (ladder refusal) → 503 carrying the DECLARED
        reason code, so "why can't I submit" is in the response, not in a
        pod log.
    """
    execution = await adb(_db_manager.get_feed_execution_by_exec_id, execution_id)
    if not execution:
        raise HTTPException(status_code=404,
                            detail=f"Execution {execution_id} not found")
    _execution, feed = await _require_feed_for_execution(
        execution["id"], user, write=True)
    if feed is None:
        raise HTTPException(status_code=409,
                            detail="Execution has no feed config")
    _status = (execution.get("status") or "").lower()
    if _status not in ("pending", "running"):
        raise HTTPException(
            status_code=409,
            detail=f"Execution is already terminal ('{_status}') — refusing "
                   f"to submit compute for it",
        )

    # 2026-10-07 -- THE lane decision (backend_router.lane_availability):
    # the ladder AND, for a run whose file must come back through the
    # artifact store (K6: suppressed / delivered from the webhook), a
    # usable store.  The DAG's run is spark_k8s compute like any other.
    from core.feed.backend_router import lane_availability
    from core.feed.delivery_hops import stored_delivery_suppression
    _av = lane_availability(
        "spark_k8s", feed,
        delivery_suppressed=stored_delivery_suppression(execution))
    if not _av.available:
        await adb(_record_submit_refusal, execution, kind="unavailable",
                  reason_code=_av.reason_code, detail=_av.describe())
        raise HTTPException(
            status_code=503,
            detail=f"spark_k8s backend unavailable: {_av.describe()}",
        )

    _run_date = None
    if body and body.run_date:
        try:
            _run_date = datetime.fromisoformat(body.run_date).date()
        except ValueError:
            raise HTTPException(status_code=400,
                                detail=f"Invalid run_date {body.run_date!r}")

    def _do_submit():
        from core.spark_k8s.runner import SparkK8sRunner
        runner = SparkK8sRunner(_db_manager)
        return runner.submit(feed, execution, run_date=_run_date)

    from core.spark_k8s.errors import SparkK8sUnavailable, SparkK8sUnreachable
    try:
        result = await asyncio.to_thread(_do_submit)
    except ValueError as exc:
        # declared refusals from the conf builder / JDBC grammar / plan
        # chokepoint — the caller can fix these; name them.  And FAIL the
        # row with them (2026-10-08): a declared refusal is deterministic,
        # so a row left running would wait for a submit that cannot come.
        await adb(_fail_submit_refused, execution,
                  f"spark-submit refused: {str(exc)[:1800]}")
        raise HTTPException(status_code=422, detail=str(exc)[:1000])
    except SparkK8sUnreachable as exc:
        # 2026-10-07 -- the cluster stopped answering AFTER the ladder said
        # yes.  A 503 with the reason code, never a 500 carrying urllib3's
        # "HTTPSConnectionPool ... Max retries" (the raw text stays in the
        # log).  Whether anything of the run reached the cluster is said:
        # the orchestrator must not resubmit elsewhere if it may exist.
        logger.error("spark-submit of %s: %s (%s)", execution_id, exc,
                     exc.detail)
        _where = ("nothing of this run was created on the cluster"
                  if exc.nothing_created else
                  "the job may already exist on the cluster; the spark_k8s "
                  "reconciler deletes what reached it once it answers again")
        await adb(_record_submit_refusal, execution, kind="unreachable",
                  reason_code="cluster_unreachable", host=exc.host,
                  cause=exc.cause, detail=str(exc.detail or "")[:300],
                  request_sent=bool(exc.request_sent),
                  nothing_created=bool(exc.nothing_created))
        # ``from None``: an AUTHORED availability sentence (main.py serves
        # those on a 503) -- composed of constants only; the API server's
        # host:port and the transport text stay in the log.
        raise HTTPException(
            status_code=503,
            detail=("spark_k8s backend unavailable: cluster_unreachable -- "
                    + _where)) from None
    except SparkK8sUnavailable as exc:
        logger.error("spark-submit of %s: %s", execution_id, exc)
        # Only a DECLARED ladder reason code reaches the caller (a
        # vocabulary, never exception text); anything else is logged.
        from core.spark_k8s import availability as _sk_av
        _declared = (_sk_av.REASON_DISABLED, _sk_av.REASON_NO_CLIENT,
                     _sk_av.REASON_NO_CLUSTER, _sk_av.REASON_RBAC,
                     _sk_av.REASON_NO_CRD, _sk_av.REASON_UNREACHABLE,
                     _sk_av.REASON_BAD_SUBMIT_MODE, _sk_av.REASON_PROBE_ERROR)
        _code = next((c for c in _declared if c == exc.reason_code),
                     "unavailable")
        await adb(_record_submit_refusal, execution, kind="unavailable",
                  reason_code=_code, detail=str(exc.detail or "")[:300])
        raise HTTPException(
            status_code=503,
            detail="spark_k8s backend unavailable: " + _code) from None

    await adb(_db_manager.update_feed_execution, execution["id"], {
        "status": "running",
    })
    logger.info(
        "Execution %s spark-submitted by %s (cr=%s, adopted=%s)",
        execution_id, user.get("username", "unknown"),
        result.cr_name, result.adopted,
    )
    return {
        "detail": ("SparkApplication already running (adopted)"
                   if result.adopted else "SparkApplication created"),
        "execution_id": execution_id,
        "cr_name": result.cr_name,
        "secret_name": result.secret_name,
        "already_running": result.adopted,
    }


@router.get("/api/feed-executions/{exec_id}/download")
async def download_execution_file(exec_id: int, user: dict = Depends(get_current_user)):
    """Download the output file from an execution.

    Serves the file where it WENT when that is a local file on the shared
    output volume, else the file the run PRODUCED (``artifact_path``,
    2026-10-07).  A backfill without delivery (FR-OPS-08) completes with
    no destination by design; it used to answer 404 "Output file not found
    on server" for a file that was sitting on the volume, because only
    ``destination_path`` was consulted and only a delivery fills it.
    Both candidates go through the same output_dir confinement.
    """
    execution, _feed = await _require_feed_for_execution(exec_id, user, write=False)
    if execution.get("status") != "completed":
        raise HTTPException(status_code=400, detail="Execution is not completed")

    dest_path = str(execution.get("destination_path") or "")
    artifact_path = str(execution.get("artifact_path") or "")
    candidates = [p for p in (dest_path, artifact_path)
                  if p and os.path.isfile(p)]
    if not candidates:
        from core.db.models import artifact_unavailable_reason_of
        _recorded_why = artifact_unavailable_reason_of(
            execution.get("stage_timings"))
        if _recorded_why and not artifact_path:
            # The run SAID why there is no copy (a Spark run whose file
            # stayed pod-local, a multi-file output) -- say that.
            _why = _recorded_why
        elif dest_path and not artifact_path:
            _why = (f"it was delivered to {dest_path!r}, which is not a file "
                    f"on this server, and no local copy is recorded")
        elif artifact_path:
            _why = (f"the produced file {os.path.basename(artifact_path)!r} "
                    f"is no longer on the server")
        else:
            _why = "this execution recorded no output file"
        raise HTTPException(status_code=404,
                            detail=f"Output file not found on server: {_why}")

    # Path traversal protection — resolve symlinks and verify within allowed directory
    from core.config import feed_generation as _fg_cfg
    allowed_dir = os.path.realpath(_fg_cfg.output_dir)
    real_path = ""
    for _cand in candidates:
        _real = os.path.realpath(_cand)
        if _real.startswith(allowed_dir + os.sep) or _real == allowed_dir:
            real_path = _real
            break
        logger.warning("[feed_api] Path traversal attempt blocked: %s -> %s",
                       _cand, _real)
    if not real_path:
        raise HTTPException(status_code=403, detail="Access denied — file outside allowed directory")

    filename = execution.get("output_filename") or os.path.basename(real_path)
    return FileResponse(
        real_path,
        filename=filename,
        media_type="application/octet-stream",
    )


# ── Webhook Endpoint ─────────────────────────────────────────────────────────

#: The lanes whose job reports through the signed webhooks.
_WEBHOOK_LANES = ("airflow", "spark", "spark_connect", "spark_k8s")


async def _verified_webhook_body(request: Request) -> bytes:
    """THE check of a job's signed callback (completion AND progress): the
    receiver must be configured (503 otherwise -- "misconfigured server" is
    told apart from "bad caller"), the ``X-Webhook-Signature`` must be the
    HMAC-SHA256 of the exact body (401 otherwise).  Returns the body."""
    from core.config import feed_generation as _fg_cfg
    secret = _fg_cfg.webhook_secret
    if not secret:
        logger.error(
            "[feed_webhook] refused — feed_generation.webhook_secret is empty; "
            "set it (e.g. via secret) to enable Airflow/Spark callbacks"
        )
        raise HTTPException(
            status_code=503,
            detail="Webhook receiver not configured (feed_generation.webhook_secret unset)",
        )
    sig_header = request.headers.get("X-Webhook-Signature", "")
    if not sig_header:
        raise HTTPException(status_code=401, detail="Missing X-Webhook-Signature header")
    raw_body = await request.body()
    expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(f"sha256={expected}", sig_header):
        logger.warning(
            "[feed_webhook] Invalid HMAC signature from %s",
            request.client.host if request.client else "unknown",
        )
        raise HTTPException(status_code=401, detail="Invalid webhook signature")
    return raw_body


@router.post("/api/webhooks/feed-progress")
async def webhook_feed_progress(request: Request):
    """WHERE A DETACHED RUN IS (2026-10-14, core/feed/run_progress.py).

    The Spark job reports every ``spark_k8s.progress_interval_seconds``:
    its phase, Spark's task counters for the stages running now, and its
    own log lines since the last report.  Recorded on the execution
    (``files_metadata.run_progress`` / ``log_lines``) and told to the run's
    audience as ``feed_progress`` + ``feed_run_log`` -- the board and the
    run-log dialog show a Spark run live, like a native one.

    Signed exactly like the completion callback.  Only a RUNNING execution
    on a webhook lane takes a report (409 otherwise: a late report never
    touches a closed row)."""
    import json as _json
    raw = await _verified_webhook_body(request)
    try:
        payload = _json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(status_code=400, detail="Body is not JSON")
    if not isinstance(payload, dict) or not payload.get("execution_id"):
        raise HTTPException(status_code=400, detail="execution_id is required")
    execution = await adb(_db_manager.get_feed_execution_by_exec_id,
                          str(payload["execution_id"]))
    if not execution:
        raise HTTPException(status_code=404,
                            detail=f"Execution {payload['execution_id']} not found")
    lane = str(execution.get("execution_backend") or "").lower()
    status = str(execution.get("status") or "").lower()
    if lane not in _WEBHOOK_LANES:
        raise HTTPException(status_code=409,
                            detail=f"Execution backend '{lane}' does not report through webhooks")
    if status not in ("pending", "running"):
        raise HTTPException(status_code=409,
                            detail=f"Execution already in terminal state '{status}'")
    from core.feed.run_progress import clean_lines, merged_metadata, normalise_report
    progress = normalise_report(payload, lane=lane)
    lines = clean_lines(payload.get("log_lines") or [])
    fresh = await adb(_db_manager.get_feed_execution, execution["id"]) or execution
    update: Dict[str, Any] = {
        "files_metadata": merged_metadata(fresh.get("files_metadata"), progress, lines)}
    from core.feed_engine import publish_run_progress
    try:
        stream = publish_run_progress(fresh, progress, lines)
    except Exception as exc:                                  # noqa: BLE001
        logger.debug("[feed_progress] broadcast failed: %s", exc)
        stream = None
    if stream and fresh.get("log_stream") != stream:
        update["log_stream"] = stream
    await adb(_db_manager.update_feed_execution, execution["id"], update)
    return {"detail": "recorded", "execution_id": payload["execution_id"],
            "phase": progress.get("phase"), "lines": len(lines)}


@router.post("/api/webhooks/feed-complete")
async def webhook_feed_complete(body: WebhookPayload, request: Request):
    """
    Airflow/Spark callback webhook.
    Called by external systems to notify completion/failure.
    REQUIRES feed_generation.webhook_secret to be set; without it the endpoint
    refuses all calls.

    BF-415 — historically the HMAC validation was gated on ``if secret:`` and
    ``webhook_secret`` defaulted to ``""``, which meant a fresh install
    accepted UNAUTHENTICATED webhooks from any caller.  An attacker on the
    network could mark any execution failed/completed and inject a malicious
    ``output_path`` (then served by /api/feed-executions/{id}/download).
    Now: empty secret → 503; bad/missing signature → 401.  Also requires
    the target execution to be in a state that legitimately accepts a
    webhook update (running on the airflow backend) so a stray POST cannot
    flip a completed/cancelled row.
    """
    await _verified_webhook_body(request)

    execution = await adb(_db_manager.get_feed_execution_by_exec_id, body.execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail=f"Execution {body.execution_id} not found")

    # BF-415 — only accept webhook updates for executions that legitimately
    # depend on a callback.  This blocks a (signature-valid) caller from
    # overwriting a native execution's destination_path or flipping a
    # completed/cancelled row back to a different state.
    _backend = (execution.get("execution_backend") or "").lower()
    _status = (execution.get("status") or "").lower()
    # spark_k8s (2026-08-22): QueryStudio-submitted SparkApplications run
    # the same generic_feed.py job, which reports through this same signed
    # webhook.  The reconciler is the fallback when this callback never
    # arrives.
    if _backend not in _WEBHOOK_LANES:
        logger.warning(
            "[feed_webhook] reject: execution %s has backend=%s (only airflow/spark accept webhooks)",
            body.execution_id, _backend,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Execution backend '{_backend}' does not accept webhook callbacks",
        )
    if _status not in ("pending", "running"):
        logger.warning(
            "[feed_webhook] reject: execution %s already in terminal state %s",
            body.execution_id, _status,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Execution already in terminal state '{_status}'",
        )

    if body.state not in ("success", "failed", "error"):
        logger.info("Webhook received for %s with state %s — no action taken",
                    body.execution_id, body.state)
        return {"detail": "Webhook processed", "execution_id": body.execution_id}

    # 2026-10-11 -- ACK FAST.  Found live (executions 2008/2009): the whole
    # finalisation -- Flow-B verification, the webhook-side delivery, the
    # status -- ran INSIDE this request; under 29 overlapping runs it
    # passed the job's 30 s read timeout, the job logged "CALLBACK failed
    # ... Read timed out" and did not retry, and a SUCCESS report was lost.
    # Now the request does two cheap things and returns: the signature
    # (above) and a durable CLAIM of the report (spark_job_reports, UNIQUE
    # per execution -- of two callbacks for one run exactly one wins).  The
    # finalisation runs off the request through the ONE finaliser per state
    # (core/spark_k8s/completion.py::finalize_from_report), idempotent and
    # first-writer-wins; a claim this pod never finalises is finished by
    # the reconciler from the same persisted report.
    report = body.model_dump()
    claimed = await adb(_db_manager.claim_spark_job_report,
                        body.execution_id, body.state, report, "webhook")
    _release_spark_credentials_soon(execution)
    if not claimed:
        logger.info("[feed_webhook] %s: a report was already received -- the first "
                    "callback's finalisation stands", body.execution_id)
        return {"detail": "Webhook already received",
                "execution_id": body.execution_id}
    _schedule_report_finalisation(dict(execution), report)
    return {"detail": "Webhook accepted", "execution_id": body.execution_id}


#: References to in-flight report finalisations (the webhook ACKs first).
_REPORT_FINALISATIONS: set = set()


def _schedule_report_finalisation(execution: dict, report: dict) -> None:
    """Run ``finalize_from_report`` off the request (the default executor);
    with no running loop (a direct call), run it inline.  The claim row
    records the outcome either way."""
    import functools
    from core.spark_k8s.completion import finalize_from_report
    job = functools.partial(finalize_from_report, _db_manager, execution, report,
                            via="webhook")
    try:
        fut = asyncio.get_running_loop().run_in_executor(None, job)
    except RuntimeError:
        job()
        return
    _REPORT_FINALISATIONS.add(fut)
    fut.add_done_callback(_REPORT_FINALISATIONS.discard)


#: References to in-flight credential releases, so a fire-and-forget task
#: is not garbage-collected mid-run.
_CREDENTIAL_RELEASES: set = set()


def _release_spark_credentials_soon(execution: dict) -> None:
    """Schedule ``runner.release_run_credentials`` for a spark_k8s row
    without awaiting it.  A no-op for every other lane."""
    if (execution.get("execution_backend") or "").lower() != "spark_k8s":
        return
    from core.spark_k8s.runner import release_run_credentials
    try:
        fut = asyncio.get_running_loop().run_in_executor(
            None, release_run_credentials, _db_manager, dict(execution))
    except RuntimeError as exc:          # no running loop: nothing to do
        logger.debug("[feed_webhook] credential release not scheduled: %s",
                     exc)
        return
    _CREDENTIAL_RELEASES.add(fut)
    fut.add_done_callback(_CREDENTIAL_RELEASES.discard)


# ── Scheduling Helpers ────────────────────────────────────────────────────────

def _register_schedule(feed_id: int, cron_expr: str, tz: str, feed_name: str):
    """Same-pod fast path: register/update the APScheduler cron job NOW.

    Phase 4 (2026-08-23): this is no longer the only mechanism.  The DB row
    (schedule_enabled + cron_expression) is the truth, and the scheduler-
    side ``__feed_schedule_reconcile__`` sweep (core/feed/
    schedule_reconciler.py) converges jobs to it on every pod that owns the
    scheduler.  So a pod WITHOUT a local scheduler is a normal, converging
    state — logged at INFO with the guarantee named, not a silent warning.
    """
    try:
        from core.scheduler import get_scheduler
        from core.cron_compat import crontab_trigger
        from core.feed_engine import run_scheduled_feed
        from core.feed.schedule_reconciler import FEED_JOB_PREFIX

        scheduler = get_scheduler()
        if not scheduler:
            logger.info(
                "Feed %d: no scheduler in this process — the feed-schedule "
                "reconciler on the scheduler pod will register the job from "
                "DB truth within its interval", feed_id)
            return

        job_id = f"{FEED_JOB_PREFIX}{feed_id}"
        scheduler.add_job(
            func=run_scheduled_feed,
            trigger=crontab_trigger(cron_expr, timezone=tz),
            id=job_id,
            args=[feed_id],
            name=f"feed:{feed_name}",
            replace_existing=True,
            misfire_grace_time=300,
        )
        _db_manager.update_feed_config(feed_id, {"apscheduler_job_id": job_id})
        logger.info("Feed %d: APScheduler job '%s' registered (cron=%s tz=%s)",
                    feed_id, job_id, cron_expr, tz)
    except Exception as exc:
        logger.error("Failed to register schedule for feed %d: %s (the "
                     "feed-schedule reconciler will retry from DB truth)",
                     feed_id, exc, exc_info=True)


def _unregister_schedule(feed_id: int):
    """Remove APScheduler cron job for the feed.

    Phase 4 (2026-08-23): the DB write happens FIRST and unconditionally —
    it is the truth the reconciler converges on.  Before, a pod without a
    local scheduler returned early and never wrote the DB either, so in
    external-scheduler mode "disable schedule" left the job firing forever.
    """
    try:
        _db_manager.update_feed_config(feed_id, {
            "apscheduler_job_id": None,
            "schedule_enabled": False,
        })

        from core.scheduler import get_scheduler
        scheduler = get_scheduler()
        if not scheduler:
            logger.info(
                "Feed %d: schedule disabled in DB — no scheduler in this "
                "process; the reconciler will remove the job", feed_id)
            return

        from core.feed.schedule_reconciler import FEED_JOB_PREFIX
        job_id = f"{FEED_JOB_PREFIX}{feed_id}"
        try:
            scheduler.remove_job(job_id)
            logger.info("Feed %d: APScheduler job '%s' removed", feed_id, job_id)
        except Exception:
            pass  # job may not exist
    except Exception as exc:
        logger.warning("Failed to unregister schedule for feed %d: %s", feed_id, exc)


def _audit(action: str, user: dict, details: dict = None):
    """Fire-and-forget audit log."""
    # 2026-08-20 -- THIS HAS NEVER LOGGED ANYTHING.
    #
    # ``core.audit`` defines audit_event / flush_pending / _do_audit.  There
    # is no ``audit_log``, and never was -- so this import raised ImportError
    # on EVERY call and the bare ``except Exception: pass`` swallowed it.
    # The function looked like an audit hook, was called from the right
    # places, and wrote nothing, silently, for its entire lifetime.
    #
    # This is the route that delivers data to SFTP / e-mail / S3 recipients,
    # i.e. the one with the strongest audit requirement in the product, and
    # it had zero coverage.
    try:
        from core.audit import audit_event
        audit_event(
            _db_manager,
            user or {},
            action=action,
            details=details,
        )
    except Exception:
        pass


# ── Admin Config ──────────────────────────────────────────────────────────────

@router.get("/api/admin/feeds/config")
async def get_feed_config_admin(user=Depends(require_admin)):
    """Get feed generation runtime config."""
    from core.config import get as _cfg_get
    keys = [
        "enabled", "max_concurrent_native", "output_dir", "max_output_rows",
        "max_file_size_mb", "default_output_format", "filename_template",
        "auto_route_threshold_rows", "retry_max_attempts", "retry_delay_seconds",
        "execution_history_retention_days", "cleanup_interval_hours", "chunk_size",
        "airflow", "oracle_defaults", "sftp",
        # 2026-10-11 -- the SOD generator's two boot-read gates, shown with
        # the rest so an operator can see the overlay the next restart reads
        "sod_enabled", "sod_cron",
        # 2026-10-11 (later) -- what scripts/feed_readiness_check.py reads to
        # say whether an estate is ready: the gates the month-end flow needs
        # and the knobs a 40M-row feed / 4,000 feeds depend on.  Read-only.
        "queue_worker_enabled", "etl_dep_check_enabled", "default_calendar",
        "sod_catchup_days", "sod_gap_scan_days", "max_cells_in_memory",
        "max_file_size_action", "stale_running_reclaim_seconds",
    ]
    return {k: _cfg_get("feed_generation", k) for k in keys}


_FEED_CONFIG_TYPES = {
    "enabled": bool, "max_concurrent_native": int, "output_dir": str,
    "max_output_rows": int, "max_file_size_mb": int, "default_output_format": str,
    "filename_template": str, "auto_route_threshold_rows": int,
    "retry_max_attempts": int, "retry_delay_seconds": int,
    "execution_history_retention_days": int, "cleanup_interval_hours": int,
    "chunk_size": int, "airflow": dict, "oracle_defaults": dict, "sftp": dict,
    # 2026-09-17 (FB-3) -- THE DOCUMENTED REMEDY WAS UNREACHABLE.
    #
    # The consumer-presence probe tells an operator, correctly, "queue_worker
    # disabled with N pending run(s) that nothing will execute ... Enable the
    # queue worker".  There was no runtime way to do that: the start route
    # 500'd on a closure, and this allowlist -- the only other door -- had no
    # queue_worker_enabled, so the PUT answered "No valid config keys
    # provided".  The product named an action it did not offer.
    "queue_worker_enabled": bool,
    "worker_pod_only": bool,
    "queue_poll_interval_seconds": int,
    # 2026-10-10 -- the completion-time refill's kill switch, settable at
    # runtime like the keys above (the worker reads it on every completion).
    "queue_refill_on_completion": bool,
    # 2026-10-11 -- "how will SOD be scheduled": the SOD generator's gate and
    # its cron are BOOT-READ by core/scheduler.py (the job registers in
    # init_scheduler), and until now the only way to set them was a config
    # file edit.  Settable here (persisted to system_settings, every pod
    # converges); the route says a restart of the scheduler-lock holder is
    # what makes the job register.  ``sod_cron`` must be a crontab expression
    # APScheduler accepts (validated below, never stored broken).
    "sod_enabled": bool,
    "sod_cron": str,
}

#: the feed_generation keys that are read ONCE, at init_scheduler -- a PUT
#: persists them, the owner must be restarted to act on them
_FEED_CONFIG_BOOT_READ = ("sod_enabled", "sod_cron", "worker_pod_only")


def _refuse_invalid_sod_cron(value: str) -> None:
    """A cron the scheduler cannot build is refused at the route, with the
    builder's own reason -- a stored bad expression would fail SOD's
    registration at the next boot in a log line nobody reads."""
    from core.cron_compat import crontab_trigger
    try:
        crontab_trigger(str(value))
    except Exception as exc:  # noqa: BLE001 -- the builder's reason is the detail
        raise HTTPException(
            status_code=400,
            detail=(f"sod_cron {value!r} is not a crontab expression the scheduler "
                    f"accepts (minute hour day month day_of_week): {exc}"))


@router.put("/api/admin/feeds/config")
async def update_feed_config_admin(body: dict, user=Depends(require_admin)):
    """Update feed generation runtime config."""
    from core.config import set as _cfg_set
    allowed_keys = set(_FEED_CONFIG_TYPES.keys())
    # 2026-09-17 -- REFUSE an unknown key instead of dropping it.
    #
    # This filtered silently and only complained when NOTHING survived, so
    # PUT {"queue_worker_enabled": true, "chunk_size": 100} answered 200 with
    # chunk_size applied and the other key discarded -- an admin who mistypes
    # a key is told the change succeeded.  Same family as the execute body
    # that ignored `filters` and returned unfiltered totals; on a config
    # surface the lie lasts until someone wonders why the setting did
    # nothing.
    unknown = sorted(set(body) - allowed_keys)
    if unknown:
        raise HTTPException(
            status_code=400,
            detail=(f"Unknown config key(s) {unknown}. Known keys: "
                    f"{sorted(allowed_keys)}. Refusing rather than applying "
                    f"the rest and reporting success."))
    filtered = {k: v for k, v in body.items() if k in allowed_keys}
    if not filtered:
        raise HTTPException(status_code=400, detail="No valid config keys provided")
    # Phase 132-G: Type validation before persisting
    for k, v in filtered.items():
        expected = _FEED_CONFIG_TYPES.get(k)
        if expected is int and isinstance(v, bool):
            raise HTTPException(
                status_code=400,
                detail=f"Key '{k}' must be int, got bool",
            )
        if expected and not isinstance(v, expected):
            raise HTTPException(
                status_code=400,
                detail=f"Key '{k}' must be {expected.__name__}, got {type(v).__name__}",
            )
    if "sod_cron" in filtered:
        _refuse_invalid_sod_cron(filtered["sod_cron"])
    for k, v in filtered.items():
        _cfg_set("feed_generation", k, v)
    logger.info("Feed config updated by %s: %s", user.get("username"), list(filtered.keys()))
    _audit("feed_config_updated", user, {"keys": list(filtered.keys())})
    out = {"detail": "Config updated", "keys": list(filtered.keys())}
    boot_read = [k for k in filtered if k in _FEED_CONFIG_BOOT_READ]
    if boot_read:
        out["restart_required"] = boot_read
        out["note"] = (f"{', '.join(boot_read)} are read when the scheduler initialises: "
                       f"persisted now, applied by the scheduler-lock holder at its next restart")
    return out


# ── Circuit Breakers ──────────────────────────────────────────────────────────

@router.get("/api/admin/feeds/kafka-arrivals/unmatched")
async def list_unmatched_kafka_arrivals(limit: int = 200, days: int = 7,
                                        user=Depends(require_admin_read)):
    """2026-10-10 -- the Kafka messages a TEMPLATED resolver rule rendered a
    dependency name for (``TETB_{SYSTEM_ENTITY}_{EventCode}``) that NO
    active feed declares.  Each row carries the rendered name, the business
    date and the reason; the arrival itself is on the dependency ledger, so
    a feed onboarded later for that combination is met by it.  "Which
    combinations arrived with no feed" is an operator question, answered
    here rather than by a log grep."""
    from datetime import timedelta as _td
    since = datetime.now(timezone.utc) - _td(days=max(0, int(days))) if days else None
    rows = await adb(_db_manager.list_kafka_messages_by_resolution, "unmatched",
                     limit=max(1, min(int(limit), 5000)), since=since)
    return {"count": len(rows), "days": days,
            "items": [{"id": r["id"], "topic": r["topic"], "partition": r["partition"],
                       "offset": r["offset"], "dependency_name": r["dependency_name"],
                       "business_date": r["business_date"], "landed_at": r["landed_at"],
                       "reason": r["unresolvable_reason"]} for r in rows]}




def _message_fields_values(payload: dict) -> dict:
    from core.feed.message_fields import values
    return values(payload, "monitor")


def _message_environment(payload: dict) -> Optional[str]:
    from core.feed.environments import label, side_of_message
    return label(side_of_message(payload))


def _monitor_row(r: dict, feeds_by_name: dict, upstream: Optional[dict] = None) -> dict:
    """One landed message as the monitor shows it: which road, the OG fields,
    what the resolver made of it, and every feed declaring its dependency
    with that feed's run for the business date."""
    import json as _json
    try:
        payload = _json.loads(r.get("payload") or "{}")
    except (TypeError, ValueError):
        payload = {}
    topic = str(r.get("topic") or "")
    road = "oracle_table" if topic.startswith("oracle_table:") else "kafka"
    feeds = feeds_by_name.get((r.get("dependency_name") or "", str(r.get("business_date") or "")), [])
    return {
        "id": r["id"], "road": road, "topic": topic, "landed_at": r.get("landed_at"),
        "resolution": r.get("resolution"), "reason": r.get("unresolvable_reason"),
        "dependency_name": r.get("dependency_name"), "business_date": r.get("business_date"),
        # the message fields the monitor shows: DATA (feed_message_fields)
        "fields": _message_fields_values(payload if isinstance(payload, dict) else {}),
        # its environment by THE configured rule (core/feed/environments.py)
        "environment": _message_environment(payload if isinstance(payload, dict) else {}),
        "feeds": feeds,
        "released": [f for f in feeds if f.get("action_decision") == "RUN"],
        # 2026-10-12 -- WHICH arrival this is for its (dependency, business
        # date) and what a RE-SEND did (core/feed/restatement.py): arrival
        # n of m on the ledger, and every restatement decision raised
        "arrival": (upstream or {}).get("arrival", {}).get(r["id"]),
        "restatements": (upstream or {}).get("decisions", {}).get(
            (r.get("dependency_name") or "", str(r.get("business_date") or "")[:10]), []),
    }


def _upstream_story(db, rows: list) -> dict:
    """For the monitor's rows: each message's position among the arrivals
    of its (dependency, business date) on THE ledger, and the restatement
    decisions raised for that pair -- one ledger read per pair, one decision
    read per date."""
    from core.feed.ledger import arrivals_for
    from core.feed.restatement import EVIDENCE_KEY
    pairs: Dict[tuple, list] = {}
    for r in rows:
        if r.get("dependency_name") and r.get("business_date"):
            pairs.setdefault((r["dependency_name"], str(r["business_date"])[:10]), []).append(r)
    arrival: Dict[int, dict] = {}
    for (dep, bd), msgs in pairs.items():
        try:
            n = len(arrivals_for(db, dep, date.fromisoformat(bd)) or [])
        except Exception:                               # noqa: BLE001 -- position unknown, said
            n = None
        for k, m in enumerate(sorted(msgs, key=lambda x: int(x["id"])), start=1):
            arrival[m["id"]] = {"n": k, "of": max(n or 0, len(msgs)) if n is not None else None,
                                "resend": k > 1}
    decisions: Dict[tuple, list] = {}
    deps = {d for d, _ in pairs}
    for bd in sorted({b for _, b in pairs}):
        try:
            got = db.list_regeneration_decisions(business_date=bd, limit=2000) or []
        except Exception:                               # noqa: BLE001
            got = []
        for d in got:
            if d.get("dependency_name") not in deps:
                continue
            rs = (d.get("evidence") or {}).get(EVIDENCE_KEY) or {}
            decisions.setdefault((d["dependency_name"], bd), []).append({
                "decision_id": d.get("id"), "feed_config_id": d.get("feed_config_id"),
                "status": d.get("status"), "resolution": d.get("resolution"),
                "resolved_by": d.get("resolved_by"), "action": rs.get("action"),
                "title": rs.get("title"), "why": rs.get("why"), "run_date": rs.get("run_date"),
                "raised_at": d.get("raised_at")})
    return {"arrival": arrival, "decisions": decisions}


@router.get("/api/admin/feeds/dependency-messages")
async def list_dependency_messages(resolution: Optional[str] = None, days: int = 7,
                                   limit: Optional[int] = None, page: int = 1,
                                   page_size: int = 50, user=Depends(require_admin_read)):
    """2026-10-11 -- the dependency-message monitor (the owner: "did you
    create the Kafka table and a Kafka UI?").  EVERY upstream message that
    landed -- the Kafka topic AND the QS_KAFKA_MESSAGE watcher -- newest
    first: its road, its OG fields (DATA_SOURCE, CODE, BUSINESS_EVENT,
    CLOUD_COMPLIANT, VERSION_STATE, ROW_COUNT), what the resolver made of it
    (resolved / unmatched / filtered / unresolvable, with the reason), and
    every feed declaring its dependency with that feed's run for the date
    (WAIT = still held, RUN = released).  ``counts`` per resolution over the
    same window."""
    from datetime import timedelta as _td
    since = datetime.now(timezone.utc) - _td(days=max(0, int(days))) if days else None
    # PAGED (2026-10-12, core/feed/paging.py): one page from the database,
    # the total from the grouped counts.  ``limit`` (the old cap) still reads
    # as the page size for a caller that sends it.
    from core.feed.paging import block as _pblock, paging as _paging
    _p = _paging(page, limit if limit is not None else page_size)
    rows = await adb(_db_manager.list_dependency_messages, resolution or None,
                     since=since, limit=_p.page_size, offset=_p.offset)
    by_date: Dict[Any, set] = {}
    for r in rows:
        if r.get("dependency_name") and r.get("business_date"):
            by_date.setdefault(r["business_date"], set()).add(r["dependency_name"])
    feeds_by_name: Dict[str, list] = {}
    for bd, names in by_date.items():
        bd_ = date.fromisoformat(bd) if isinstance(bd, str) else bd
        got = await adb(_db_manager.feeds_declaring_dependencies, sorted(names), bd_)
        feeds_by_name.update({(n, str(bd)): v for n, v in got.items()})
    counts = await adb(_db_manager.dependency_message_counts, since=since)
    _story = await adb(_upstream_story, _db_manager, rows)
    from core.feed.message_fields import shown as _shown
    return {"days": days, "resolution": resolution, "counts": counts,
            # the columns, in order, as DATA (feed_message_fields)
            "columns": _shown("monitor"),
            "items": [_monitor_row(r, feeds_by_name, _story) for r in rows],
            "paging": _pblock((counts.get(resolution, 0) if resolution else sum(counts.values())),
                              _p, len(rows))}


@router.get("/api/admin/feeds/circuit-breakers")
async def get_feed_circuit_breakers(user=Depends(require_admin)):
    """Get feed engine circuit breaker status."""
    from core.feed_engine import get_backend_status
    return get_backend_status()


@router.post("/api/admin/feeds/circuit-breakers/{backend}/reset")
async def reset_feed_circuit_breaker(backend: str, user=Depends(require_admin)):
    """Reset a feed circuit breaker."""
    from core.feed_engine import reset_backend_breaker
    if not reset_backend_breaker(backend):
        raise HTTPException(status_code=404, detail=f"Unknown backend: {backend}")
    logger.info("Feed circuit breaker '%s' reset by %s", backend, user.get("username"))
    _audit("feed_circuit_breaker_reset", user, {"backend": backend})
    return {"detail": f"Circuit breaker '{backend}' reset"}


# ── Phase 130: Feed Calendars + Holidays admin CRUD ──────────────────────


def _invalidate_calendar_cache(calendar_name: Optional[str] = None) -> None:
    """Phase 4 (2026-08-23): admin calendar/holiday CRUD must drop the
    feed engine's TTL-cached calendar spec.  The repo docstring always
    claimed the admin endpoints called invalidate(); no call site existed
    -- a Run-Now within 5 minutes of a holiday edit used the OLD holiday
    set (and could disagree with the fresh copy other resolution paths
    load in the SAME run)."""
    try:
        from core import feed_engine as _fe
        if _fe._calendar_repo is not None:
            _fe._calendar_repo.invalidate(calendar_name)
    except Exception as exc:
        logger.debug("calendar cache invalidation failed: %s", exc)


def _validate_weekend_days(v):
    """Phase 4 (2026-08-23): ISO weekday range check AT THE API.  Values
    outside 1..7 used to be accepted here and silently DROPPED at load
    time (calendar.py) -- [0, 6] (a Python-convention Sunday+Saturday)
    became Saturday-only without a word."""
    if v is None:
        return v
    bad = [x for x in v if not (isinstance(x, int) and 1 <= x <= 7)]
    if bad:
        raise ValueError(
            f"weekend_days must be ISO weekday numbers 1 (Mon) .. 7 (Sun); "
            f"got {bad}")
    return sorted(set(v))


class FeedCalendarCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    weekend_days: Optional[List[int]] = Field(
        default=None,
        description="ISO weekday numbers (Mon=1 … Sun=7).  When omitted, "
                    "system default (feed_generation.default_weekend_days).",
    )
    is_active: bool = True

    @field_validator("weekend_days")
    @classmethod
    def _check_weekend_days(cls, v):
        return _validate_weekend_days(v)


class FeedCalendarUpdate(BaseModel):
    description: Optional[str] = None
    weekend_days: Optional[List[int]] = None
    is_active: Optional[bool] = None

    @field_validator("weekend_days")
    @classmethod
    def _check_weekend_days(cls, v):
        return _validate_weekend_days(v)


class FeedHolidayCreate(BaseModel):
    holiday_date: str = Field(..., description="YYYY-MM-DD")
    holiday_name: Optional[str] = None
    recurring: bool = False


@router.get("/api/feed-calendars")
async def list_feed_calendars_readonly(user: dict = Depends(get_current_user)):
    """Phase 4 (2026-08-23): read-only ACTIVE calendar list for the feed
    setup form.  /feeds is open to analysts, but the picker loaded from
    the admin-only route and swallowed the 403 -- analysts saw an empty
    dropdown (and an out-of-range select when editing an admin-configured
    feed) with no error.  Names/weekends/holiday counts are not secrets."""
    return _db_manager.list_feed_calendars(is_active=True)


@router.get("/api/admin/feed-calendars")
async def list_feed_calendars(
    is_active: Optional[bool] = None,
    user=Depends(require_admin),
):
    """List business calendars."""
    return _db_manager.list_feed_calendars(is_active=is_active)


@router.post("/api/admin/feed-calendars", status_code=201)
async def create_feed_calendar(
    body: FeedCalendarCreate, user=Depends(require_admin),
):
    """Create a new business calendar."""
    payload = body.dict(exclude_unset=True)
    payload["created_by"] = user.get("username")
    try:
        cal = _db_manager.create_feed_calendar(payload)
    except Exception as exc:
        # Phase 4: unique-name violation used to surface as a raw 500.
        if "unique" in str(exc).lower() or "IntegrityError" in type(exc).__name__:
            raise HTTPException(
                status_code=409,
                detail=f"A calendar named {body.name!r} already exists")
        raise
    _audit("feed_calendar_created", user, {"name": cal["name"]})
    return cal


@router.get("/api/admin/feed-calendars/{cal_id}")
async def get_feed_calendar(cal_id: int, user=Depends(require_admin)):
    cal = _db_manager.get_feed_calendar(cal_id)
    if not cal:
        raise HTTPException(status_code=404, detail=f"Calendar {cal_id} not found")
    # Hydrate with holidays so admin UI can edit both in one round-trip
    cal["holidays"] = _db_manager.list_feed_holidays(cal_id)
    return cal


@router.put("/api/admin/feed-calendars/{cal_id}")
async def update_feed_calendar(
    cal_id: int, body: FeedCalendarUpdate, user=Depends(require_admin),
):
    payload = body.dict(exclude_unset=True)
    cal = _db_manager.update_feed_calendar(cal_id, payload)
    if not cal:
        raise HTTPException(status_code=404, detail=f"Calendar {cal_id} not found")
    _invalidate_calendar_cache(cal.get("name"))
    _audit("feed_calendar_updated", user, {"id": cal_id, "keys": list(payload.keys())})
    return cal


@router.delete("/api/admin/feed-calendars/{cal_id}", status_code=204)
async def delete_feed_calendar(cal_id: int, user=Depends(require_admin)):
    cal = _db_manager.get_feed_calendar(cal_id)
    if not cal:
        raise HTTPException(status_code=404, detail=f"Calendar {cal_id} not found")
    # Phase 4 (2026-08-23): deleting a calendar still referenced by feeds
    # silently degraded every one of them to "every day is a business day"
    # -- weekend/holiday runs started with no warning anywhere.  Refuse,
    # naming the feeds; the operator detaches or deactivates them first.
    # 2026-10-11: only ACTIVE feeds block (the comment above always said
    # "detaches or DEACTIVATES them first").  Counting retired feeds made a
    # deadlock live: a retired feed whose sources are gone cannot be edited
    # (the save re-runs its source preflight), so its calendar could never
    # be deleted.  The safety the rule protected moves to RE-ACTIVATION:
    # a feed whose calendar no longer exists is refused when re-activated.
    refs = [f for f in (_db_manager.list_feed_configs(is_active=True) or [])
            if (f.get("calendar_name") or "") == cal.get("name")]
    if refs:
        names = ", ".join(str(f.get("name")) for f in refs[:10])
        raise HTTPException(
            status_code=409,
            detail=f"Calendar {cal.get('name')!r} is referenced by "
                   f"{len(refs)} feed(s): {names}"
                   + (" ..." if len(refs) > 10 else "")
                   + ". Detach it from those feeds first.")
    # 2026-09-10 -- a Clockwork job inlines this calendar into its dispatch
    # projection; deleting it would leave every bound job unprojectable
    # (out of the dispatch view, alerted).  Same rule as feeds: refuse and
    # name them.
    cw_refs = [j for j in (_db_manager.list_clockwork_jobs() or [])
               if j.get("calendar_id") == cal_id]
    if cw_refs:
        names = ", ".join(str(j.get("name")) for j in cw_refs[:10])
        raise HTTPException(
            status_code=409,
            detail=f"Calendar {cal.get('name')!r} is bound by {len(cw_refs)} Clockwork "
                   f"job(s): {names}" + (" ..." if len(cw_refs) > 10 else "")
                   + ". Rebind those jobs first.")
    if not _db_manager.delete_feed_calendar(cal_id):
        raise HTTPException(status_code=404, detail=f"Calendar {cal_id} not found")
    _invalidate_calendar_cache(cal.get("name"))
    _audit("feed_calendar_deleted", user, {"id": cal_id})
    return None


@router.post("/api/admin/feed-calendars/{cal_id}/holidays", status_code=201)
async def add_feed_holiday(
    cal_id: int, body: FeedHolidayCreate, user=Depends(require_admin),
):
    if not _db_manager.get_feed_calendar(cal_id):
        raise HTTPException(status_code=404, detail=f"Calendar {cal_id} not found")
    try:
        h_date = datetime.fromisoformat(body.holiday_date[:10]).date()
    except Exception:
        raise HTTPException(status_code=400, detail="holiday_date must be YYYY-MM-DD")
    try:
        row = _db_manager.add_feed_holiday(
            cal_id, h_date, body.holiday_name, body.recurring,
        )
    except Exception as exc:
        if "unique" in str(exc).lower() or "IntegrityError" in type(exc).__name__:
            raise HTTPException(
                status_code=409,
                detail=f"{body.holiday_date} is already a holiday on this calendar")
        raise
    _invalidate_calendar_cache()
    _audit("feed_holiday_added", user, {"calendar_id": cal_id, "date": body.holiday_date})
    return row


@router.delete("/api/admin/feed-holidays/{holiday_id}", status_code=204)
async def delete_feed_holiday(holiday_id: int, user=Depends(require_admin)):
    if not _db_manager.delete_feed_holiday(holiday_id):
        raise HTTPException(status_code=404, detail=f"Holiday {holiday_id} not found")
    _invalidate_calendar_cache()
    _audit("feed_holiday_deleted", user, {"id": holiday_id})
    return None


# ── Phase 130: Feed Runs (SOD-generated daily tasks) ─────────────────────


@router.get("/api/feed-runs")
async def list_todays_feed_runs(
    business_date: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = Query(default=200, le=1000),
    offset: int = 0,
    user=Depends(get_current_user),
):
    """List feed_runs rows for a business date.

    Defaults to today (UTC).  Use ``?business_date=YYYY-MM-DD`` to look
    at a different date, and ``?status=pending`` / ``running`` /
    ``completed`` / ``failed`` / ``skipped`` to filter.
    """
    if business_date:
        try:
            bd = datetime.fromisoformat(business_date[:10]).date()
        except Exception:
            raise HTTPException(status_code=400, detail="business_date must be YYYY-MM-DD")
    else:
        bd = datetime.now(timezone.utc).date()
    # Offloaded off the event loop: this handler is polled continuously by
    # the feed dashboard and does a sequence of sync DB reads (list + an
    # N+1 get_feed_config loop + a batched exec lookup + per-row
    # can_act_on_feed).  Awaiting each off-loop lets health probes run
    # between calls instead of freezing the loop.  See
    # backend/docs/event_loop_blocking_audit.md (Tier-1 feed_api:1336).
    # 2026-09-24 (walked as a real analyst with login on): this listed EVERY
    # feed's runs to every user, while /api/feeds (_filter_visible_feeds) and
    # every execution route (_require_feed) hide a feed the user may not
    # view.  The analyst saw another team's feed names, row counts and owner
    # here, then got 403 opening the same run -- one question, two answers.
    # The board now lists the runs of feeds the user may VIEW (the same
    # rule); an admin, support, or a no-auth deployment still sees all.
    # Filtered BEFORE paging, so a page is never short of visible runs.
    # include_manual: a person looking at the day's runs sees the manual Run
    # Now runs too, with the same step record (run_type="manual" marks them).
    if _sees_every_feed(user):
        rows = await asyncio.to_thread(
            _db_manager.list_feed_runs,
            business_date=bd, status=status, limit=limit, offset=offset,
            include_manual=True,
        )
    else:
        _all_day = await asyncio.to_thread(
            _db_manager.list_feed_runs,
            business_date=bd, status=status, limit=None, offset=0,
            include_manual=True,
        )
        _visible_ids = await adb(_visible_feed_ids, user)
        rows = [r for r in (_all_day or [])
                if r.get("feed_config_id") is not None
                and int(r["feed_config_id"]) in _visible_ids][offset:offset + limit]
    # Phase 130 hotfix — denormalise feed_name + permission flag onto
    # each row so the UI knows what to show + which actions to enable.
    # Single batched lookup keyed by id to avoid an N+1 on large pages.
    if rows:
        username = user.get("username", "")
        # Use the codebase-canonical admin check (honours both role and
        # the boolean is_admin flag) — pure role check missed admins
        # whose auth path set is_admin=True without populating role.
        from core.roles import is_admin_like as _is_admin_like
        is_admin_like = _is_admin_like(user)
        ids = {int(r["feed_config_id"]) for r in rows if r.get("feed_config_id") is not None}
        # Batch the config lookup — ONE query indexed by id instead of an N+1
        # get_feed_config-per-run loop (this handler is polled continuously).
        # is_active=None returns ALL feeds so an inactive feed's runs still
        # resolve name/owner.  (Configs are used internally for name/owner/
        # category only — never returned raw, so no secret leak.)
        feed_index: Dict[int, dict] = {}
        try:
            # 2026-10-12 -- only the feeds of these rows (was every config:
            # 5,093 full rows per poll on the rig).
            feed_index = await asyncio.to_thread(
                _db_manager.get_feed_configs_by_ids, list(ids))
        except Exception:
            feed_index = {}
        from core.feed.permissions import can_act_on_feed, user_in_group
        # Phase 130 hotfix-13 — join the most recent feed_execution per
        # row so the dashboard can show stage_timings / failed_stage /
        # execution_backend (CBQ-parity observability).  Best-effort:
        # any DB failure leaves these fields off the row (UI handles).
        last_execs: Dict[int, dict] = {}
        try:
            run_fids = [int(r["feed_config_id"]) for r in rows
                         if r.get("feed_config_id") is not None]
            if run_fids:
                last_execs = await asyncio.to_thread(_db_manager.get_latest_feed_executions_by_feed_ids, run_fids)
        except Exception:
            last_execs = {}
        # 2026-09-14 -- each run's OWN execution, through the link the step
        # recorder stamps.  2026-10-12: read for EVERY row in two queries off
        # the event loop -- asked per row it stalled the loop 14 s.
        linked_execs: Dict[int, dict] = {}
        try:
            from core.feed.step_model.store import execution_ids_for_runs

            def _linked_for_rows():
                eids = execution_ids_for_runs(
                    _db_manager, [r.get("id") for r in rows])
                by_eid = _db_manager.get_feed_executions_by_exec_ids(eids.values())
                return {rid: by_eid[e] for rid, e in eids.items() if e in by_eid}
            linked_execs = await asyncio.to_thread(_linked_for_rows)
        except Exception:
            linked_execs = {}
        # Memoize the permission verdict per UNIQUE feed — many runs share one
        # feed_config, so this collapses the per-row can_act_on_feed (which does
        # a group-membership DB lookup) to one call per distinct feed.
        _rerun_cache: Dict[int, bool] = {}
        # is_mine: does this feed belong to ME (owner OR a member of its owner
        # group)?  Deliberately WITHOUT the admin/support see-everything override
        # that can_act_on_feed applies — the dashboard's "Mine / my groups"
        # filter means "my feeds", so an admin viewing "Mine" sees only the
        # feeds they personally own/belong to (everything else is under "All").
        # Memoized per unique feed (one group-membership lookup per feed).
        _mine_cache: Dict[int, bool] = {}
        _uname_raw = str((user or {}).get("username", "") or "")
        _uname = _uname_raw.lower()

        def _verdicts_per_feed():
            # 2026-10-12 -- every distinct feed's two verdicts in ONE thread
            # hop (was two hops per feed, awaited one after another).
            _group_cache: Dict[int, bool] = {}
            for _fid, _fc in feed_index.items():
                _rerun_cache[_fid] = can_act_on_feed(_fc, user, _db_manager)
                _owner = str(_fc.get("created_by") or "").lower()
                _gid = _fc.get("owner_group_id")
                if _uname and _owner and _owner == _uname:
                    _mine_cache[_fid] = True
                elif _uname and _gid:
                    if _gid not in _group_cache:
                        _group_cache[_gid] = user_in_group(_db_manager, _uname_raw, _gid)
                    _mine_cache[_fid] = _group_cache[_gid]
                else:
                    _mine_cache[_fid] = False
        await asyncio.to_thread(_verdicts_per_feed)
        for r in rows:
            fid = r.get("feed_config_id")
            fc = feed_index.get(fid) if fid in feed_index else None
            if fc:
                r["feed_name"]       = fc.get("name")
                r["feed_owner"]      = fc.get("created_by")
                r["owner_group_id"]  = fc.get("owner_group_id")
                # BF-473 — surface the operator category so the dashboard
                # can chip + filter without a separate /api/feeds call.
                r["frequency_category"] = fc.get("frequency_category")
                # Phase 130 hotfix-13 — surface the feed's CONFIGURED
                # backend so the UI can compare against the run's
                # actual backend and render an override badge.
                r["feed_configured_backend"] = fc.get("execution_backend") or "auto"
                # Permission resolver handles admin + individual owner
                # + group membership in one call (memoized per feed).
                r["can_rerun"] = _rerun_cache.get(fid, False)
                r["is_mine"] = _mine_cache.get(fid, False)
            else:
                r["can_rerun"] = is_admin_like
                r["is_mine"] = False
            # Surface execution detail when available.
            # Phase 4 (2026-08-23): the join is by FEED (latest execution
            # ever), not by this run's date — overlay it only when it
            # plausibly belongs to this row's day.  Before, a historical
            # date view showed TODAY's execution details on old rows, and
            # a reclaimed/escalated row's own error text was OVERWRITTEN
            # with None from an unrelated earlier success, so the UI
            # rendered a Failed row with no reason at all.
            exec_row = last_execs.get(int(fid)) if fid is not None else None
            # 2026-09-14 -- the run's OWN execution, through the link the
            # step recorder stamps, before the feed's-latest fallback:
            # three runs of one feed on one day all wore the last run's
            # pod name otherwise.
            try:
                _linked = linked_execs.get(int(r["id"]))
                if _linked:
                    exec_row = _linked
            except (TypeError, ValueError, KeyError):
                pass
            if exec_row is not None:
                _started = exec_row.get("started_at")
                _exec_day = None
                try:
                    if isinstance(_started, datetime):
                        _exec_day = _started.date()
                    elif _started:
                        _exec_day = datetime.fromisoformat(
                            str(_started)[:19]).date()
                except Exception:
                    _exec_day = None
                _row_days = set()
                for _dk in ("business_date", "run_date"):
                    _dv = r.get(_dk)
                    try:
                        if _dv:
                            _row_days.add(datetime.fromisoformat(
                                str(_dv)[:10]).date())
                    except Exception:
                        pass
                if _exec_day is not None and _row_days and _exec_day not in _row_days:
                    exec_row = None
            if exec_row:
                if "stage_timings" in exec_row:
                    r["stage_timings"] = exec_row.get("stage_timings")
                    # AQD-06 (2026-09-23): the dict mixes durations, byte and
                    # row counts and verdict records; the page rendered every
                    # number as seconds ("output_bytes: 76.00s").  The
                    # durations are classified HERE, by the projection's own
                    # rule, so the page never decides what a key means.
                    from core.feed.steps_view import stage_seconds as _stage_seconds
                    _st = exec_row.get("stage_timings") or {}
                    r["stage_seconds"] = {
                        k: sec for k, sec in (
                            (k, _stage_seconds(str(k), v)) for k, v in
                            (_st.items() if isinstance(_st, dict) else []))
                        if sec is not None}
                if "failed_stage" in exec_row:
                    r["failed_stage"] = exec_row.get("failed_stage")
                # 2026-10-07 -- did the file GO?  A backfill without
                # delivery completes like any run; without the verdict the
                # board showed it as an ordinary green "completed".
                from core.db.models import delivery_verdict_of
                r["delivery_verdict"] = delivery_verdict_of(
                    exec_row.get("stage_timings"))
                r["execution_backend"] = exec_row.get("execution_backend")
                # 2026-09-14 -- what the operator validates a run by
                # without kubectl: the execution's identity and, on the
                # Spark lane, the workload / driver-pod name.
                r["execution_db_id"] = exec_row.get("id")
                r["execution_id"] = exec_row.get("execution_id")
                r["external_job_id"] = exec_row.get("external_job_id")
                _hoist_backend_choice(r, exec_row)
                # Never overwrite the row's OWN error with an execution's
                # None — the row error (reclaim/escalation text) is the
                # only explanation some rows have.
                if exec_row.get("error_message"):
                    r["error"] = exec_row.get("error_message")
                # Round 16: surface the feed_execution DB id so the
                # dashboard's BQB-parity perf chip can fetch
                # /api/feed-executions/{id} for stage_history + log_lines.
                r["feed_execution_id"] = exec_row.get("id")
    return {"business_date": bd.isoformat(), "count": len(rows), "items": rows}


#: the SOD run-now background tasks this process is running (a reference
#: keeps them alive until done)
_sod_background_tasks: set = set()


def _parse_sod_scope(business_date: Optional[str], template_id: Optional[int],
                     feed_ids: Optional[str]):
    """The run-now query string -> (date, template_id, [feed ids]).  400 on a
    malformed value, never a silent 'all feeds'."""
    target = None
    if business_date:
        try:
            target = datetime.fromisoformat(business_date[:10]).date()
        except Exception:
            raise HTTPException(status_code=400, detail="business_date must be YYYY-MM-DD")
    ids = None
    if feed_ids is not None and str(feed_ids).strip() != "":
        ids = []
        for part in str(feed_ids).split(","):
            part = part.strip()
            if not part:
                continue
            try:
                ids.append(int(part))
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"feed_ids must be a comma-separated list of integers; "
                           f"got {part!r}")
    if template_id is not None and not _db_manager.get_feed_template(int(template_id)):
        raise HTTPException(status_code=404,
                            detail=f"feed template {template_id} does not exist")
    return target, template_id, ids


async def _run_sod_now(*, business_date: Optional[str], template_id: Optional[int],
                       feed_ids: Optional[str], background: Optional[bool],
                       user: dict, audit_action: str, status_path: str):
    """ONE body for both run-now routes (2026-10-11).

    SCOPE: ``template_id`` and/or ``feed_ids`` narrow the pass to those
    feeds -- the SAME ``run_for_date``, the same rows and ``triggered_by``
    as the cron -- and the answer echoes ``scope`` + ``considered`` beside
    the counters it always carried.  SCALE: over
    ``feed_generation.sod_run_now_sync_max_feeds`` feeds in scope (or with
    ``background=true``) the pass is a JOB: the slot is claimed
    (core/feed/sod_jobs.py), the answer is 202 with ``job`` + ``status_url``,
    and the pass runs as a task on this process with a heartbeat; a live job
    makes a second POST a 409 naming it.  The CATCH-UP of missed due dates
    and the GAP records ride every pass, cron or run-now.
    """
    import socket as _socket
    from core.feed import sod_jobs as _sj
    from core.feed.sod_generator import SodTaskGenerator

    target, tid, ids = _parse_sod_scope(business_date, template_id, feed_ids)
    gen = SodTaskGenerator(_db_manager)
    feeds = await asyncio.to_thread(gen.feeds_in_scope, template_id=tid, feed_ids=ids)
    considered = len(feeds)
    scope = gen.scope_of(tid, ids)
    bg = bool(background) if background is not None else considered > _sj.sync_max_feeds()
    if not bg:
        result = await asyncio.to_thread(gen.run_for_date, target,
                                         template_id=tid, feed_ids=ids)
        _audit(audit_action, user, result.to_dict())
        return result.to_dict()

    now = datetime.now(timezone.utc)
    live = await adb(_sj.live_job, _db_manager, now=now)
    if live is not None:
        raise HTTPException(
            status_code=409,
            detail=f"a SOD run-now is already in flight (job {live['job_id']}, "
                   f"{live.get('done', 0)}/{live.get('total')} feeds, started "
                   f"{live.get('started_at')} by {live.get('by')}); poll "
                   f"{status_path.format(job_id=live['job_id'])} and run again "
                   f"when it has finished")
    job = _sj.new_job(uuid.uuid4().hex, total=considered, by=user.get("username"),
                      owner=f"{_socket.gethostname()}:{os.getpid()}", background=True,
                      scope=scope, business_date=target or now.date(), now=now)
    if not await adb(_sj.claim, _db_manager, job, now=now):
        raise HTTPException(status_code=409,
                            detail="a SOD run-now was claimed by another request a "
                                   "moment ago; poll its status and run again when it "
                                   "has finished")
    await adb(_sj.write_job, _db_manager, job)
    job_id = job["job_id"]

    def _pass() -> dict:
        import time as _time
        last = [_time.monotonic()]

        def _progress(done: int, total: int) -> None:
            if _time.monotonic() - last[0] >= _sj.PROGRESS_EVERY_SECONDS:
                job["done"], job["total"] = int(done), int(total)
                job["heartbeat_at"] = datetime.now(timezone.utc).isoformat()
                _sj.write_job(_db_manager, job)
                last[0] = _time.monotonic()

        job["state"] = _sj.JOB_RUNNING
        _sj.write_job(_db_manager, job)
        return gen.run_for_date(target, template_id=tid, feed_ids=ids,
                                progress=_progress).to_dict()

    async def _runner() -> None:
        try:
            result = await asyncio.to_thread(_pass)
        except Exception as exc:  # noqa: BLE001 -- the job record carries it
            logger.exception("[sod] background run-now job %s failed", job_id)
            await adb(_sj.finish, _db_manager, job, error=f"{type(exc).__name__}: {exc}")
            return
        await adb(_sj.finish, _db_manager, job, result=result)
        _audit(audit_action, user, result)

    task = asyncio.create_task(_runner(), name=f"feed-sod-run-now-{job_id}")
    _sod_background_tasks.add(task)
    task.add_done_callback(_sod_background_tasks.discard)
    logger.info("[sod] run-now over %d feed(s) (scope %s) runs in the BACKGROUND "
                "(job %s) by %s", considered, scope, job_id, user.get("username"))
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=202, content={
        "business_date": (target or now.date()).isoformat(),
        "scope": scope, "considered": considered,
        "job": {k: v for k, v in job.items() if k != "result"},
        "status_url": status_path.format(job_id=job_id),
    })


async def _sod_job_status(job_id: str) -> dict:
    from core.feed import sod_jobs as _sj
    view = await adb(_sj.read_job, _db_manager, job_id)
    if view is None:
        raise HTTPException(status_code=404, detail=f"SOD run-now job {job_id!r} not found")
    return {"job": view}


@router.post("/api/admin/feeds/sod/run-now")
async def run_sod_now(
    business_date: Optional[str] = None,
    template_id: Optional[int] = None,
    feed_ids: Optional[str] = None,
    background: Optional[bool] = None,
    user=Depends(require_admin),
):
    """Force-run the SOD generator now (admin-only).

    Useful for catching up after a missed window or seeding a brand-new
    feed_configs row mid-day.  Idempotent — re-running for the same
    date is a no-op for feeds that already have a row.  2026-10-11:
    ``template_id`` / ``feed_ids=1,2,3`` scope the pass; ``background=true``
    (or a scope over ``feed_generation.sod_run_now_sync_max_feeds`` feeds)
    answers 202 with a job to poll at ``GET .../sod/run-now/{job_id}``.
    """
    return await _run_sod_now(business_date=business_date, template_id=template_id,
                              feed_ids=feed_ids, background=background, user=user,
                              audit_action="feed_sod_run_now",
                              status_path="/api/admin/feeds/sod/run-now/{job_id}")


@router.get("/api/admin/feeds/sod/run-now/{job_id}")
async def sod_run_now_status(job_id: str, user=Depends(require_admin_read)):
    """The run-now JOB a 202 named: state, done/total, heartbeat, and when
    completed the SAME result dict the synchronous answer carries."""
    return await _sod_job_status(job_id)


@router.get("/api/admin/feeds/sod/gaps")
async def list_sod_gaps(
    feed_id: Optional[int] = None,
    days: int = 90,
    include_resolved: bool = False,
    user=Depends(require_admin_read),
):
    """The DUE dates the SOD generator found with NO run row beyond its
    catch-up window (``feed_sod_gaps``, 2026-10-11) -- what was missed and
    not created, so it is never silent.  Resolve one with a backfill of the
    date or by widening ``feed_generation.sod_catchup_days``."""
    from datetime import timedelta as _td
    since = datetime.now(timezone.utc).date() - _td(days=max(1, int(days)))
    rows = await adb(_db_manager.list_feed_sod_gaps, feed_id, open_only=not include_resolved,
                     business_date_from=since, limit=5000)
    names = {}
    for r in rows:
        fid = int(r["feed_config_id"])
        if fid not in names:
            fc = await adb(_db_manager.get_feed_config, fid)
            names[fid] = (fc or {}).get("name")
        r["feed_name"] = names[fid]
    return {"count": len(rows), "since": since.isoformat(),
            "include_resolved": bool(include_resolved), "items": rows}


@router.post("/api/feeds/sod/run-now")
async def run_sod_now_user(
    business_date: Optional[str] = None,
    template_id: Optional[int] = None,
    feed_ids: Optional[str] = None,
    background: Optional[bool] = None,
    user=Depends(get_current_user),
):
    """End-user on-demand SOD trigger (any authenticated user).

    Mirrors the admin endpoint but with relaxed auth — end users often
    need to seed today's feed_runs after the scheduled window slipped
    (network blip, backend restart, etc.).  Safe to call because:

    * The underlying ``SodTaskGenerator.run_for_date`` is idempotent —
      a unique index ``ux_feed_runs_one_per_feed_per_date`` AND a
      pre-check via the pass's existence read prevent duplicate
      rows for the same (feed_config_id, business_date) pair.
    * Audit logged so admins can see who triggered when.
    * Returns counts (created / already_existed / skipped_*) so the
      caller can confirm exactly what happened.

    No per-feed permission scoping: SOD operates on all active feeds
    that meet their valid_from / valid_until / action_condition gates.
    A non-owner can't observe which feeds got created — only the
    aggregate count is exposed in the response.  Takes the same
    ``template_id`` / ``feed_ids`` / ``background`` as the admin route.
    """
    return await _run_sod_now(business_date=business_date, template_id=template_id,
                              feed_ids=feed_ids, background=background, user=user,
                              audit_action="feed_sod_run_now_user",
                              status_path="/api/feeds/sod/run-now/{job_id}")


@router.get("/api/feeds/sod/run-now/{job_id}")
async def sod_run_now_status_user(job_id: str, user=Depends(get_current_user)):
    return await _sod_job_status(job_id)


# ── Phase 130/4: External trigger API (API-key authenticated) ───────────


#: The header the external trigger deduplicates on (2026-09-15).  Clockwork's
#: ``qs_api`` task sends its fire key under this name on every request
#: (``clockwork/clockwork/tasks/http_request.py::IDEMPOTENCY_HEADER``); any
#: caller may send its own.  Case-insensitive, as every HTTP header is.
IDEMPOTENCY_HEADER = "Idempotency-Key"


def _idempotency_key_of(request: Request) -> Optional[str]:
    """The caller's key, stripped, or None when absent/blank.  Refuses (400)
    a key wider than the column: a truncated key would collide two requests
    into one run, which is the opposite of what the header promises."""
    from core.db.models import FEED_RUN_IDEMPOTENCY_KEY_LEN
    raw = (request.headers.get(IDEMPOTENCY_HEADER) or "").strip()
    if not raw:
        return None
    if len(raw) > FEED_RUN_IDEMPOTENCY_KEY_LEN:
        raise HTTPException(
            status_code=400,
            detail=f"{IDEMPOTENCY_HEADER} is {len(raw)} characters; at most "
                   f"{FEED_RUN_IDEMPOTENCY_KEY_LEN} are honoured and a truncated key "
                   f"would collide two requests into one run, so it is refused rather "
                   f"than shortened.")
    return raw


def _idempotent_replay(feed: dict, prior: dict, key: str, user: dict):
    """The answer to a replayed key: the ORIGINAL run's identity, and no
    second run.  200 rather than the route's 202 -- nothing was newly
    accepted -- with ``feed_run_id`` where every caller (Clockwork's
    ``qs_api`` reads exactly that field) already looks for it."""
    from fastapi.responses import JSONResponse
    _audit("feed_external_trigger_replayed", user, {
        "feed_id": feed.get("id"), "feed_run_id": prior.get("id"),
        "idempotency_key": key, "status": prior.get("status"),
    })
    logger.info("[external_trigger] feed=%s %s=%r replayed -> run %s (%s); no second run",
                feed.get("id"), IDEMPOTENCY_HEADER, key, prior.get("id"), prior.get("status"))
    return JSONResponse(status_code=200, content={
        "detail": (f"Replay: this {IDEMPOTENCY_HEADER} already started feed run "
                   f"{prior.get('id')} ({prior.get('status')}); no second run was created"),
        "feed_run_id": prior.get("id"),
        "feed_id": feed.get("id"),
        "business_date": prior.get("business_date"),
        "status": prior.get("status"),
        "idempotent_replay": True,
    })


class ExternalTriggerRequest(BaseModel):
    """Payload accepted by ``POST /api/v1/feeds/{id_or_slug}/trigger``."""
    business_date: Optional[str] = Field(
        default=None,
        description="Override the SOD-computed business_date (YYYY-MM-DD).",
    )
    query_params: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Per-trigger overrides merged into the feed's query_params.",
    )
    priority: Optional[int] = Field(default=None, ge=1, le=9)


@router.post("/api/v1/feeds/{id_or_slug}/trigger", status_code=202)
async def external_trigger_feed(
    id_or_slug: str,
    body: ExternalTriggerRequest,
    background_tasks: BackgroundTasks,
    request: Request,
):
    """Trigger a feed from an external system via API key.

    Authentication: ``X-API-Key`` header.  The endpoint is gated behind
    ``feed_generation.allow_external_triggers`` (default false); when
    disabled it returns 503 so deployments that don't use this surface
    can leave it off without leaking that it exists.

    Behaviour:
      - Looks up the feed by numeric ID first, then by ``name`` slug.
      - Creates a feed_runs row with triggered_by='external'.
      - Schedules execute_feed in the background — caller gets 202 and
        the run_id immediately.
      - HONOURS ``Idempotency-Key`` (2026-09-15).  The same key replayed
        against the same feed returns the ORIGINAL run's identity (200,
        ``idempotent_replay: true``) and starts nothing -- including after
        that run has completed, which the (feed, business_date)
        pending|running check below cannot see.  The key is persisted on
        the run row (``feed_runs.idempotency_key``, unique per feed) so the
        dedup survives a restart and a concurrent replay loses inside the
        database.  Until this, Clockwork's ``qs_api`` sent its fire key
        here on every request and nothing read it; job 36's
        ``idempotent: true`` declaration was false for this target.
    """
    from core.config import feed_generation as _fg
    if not _fg.allow_external_triggers:
        raise HTTPException(
            status_code=503,
            detail="External feed triggers are not enabled on this instance",
        )

    # Authenticate via API key
    from api.deps import get_api_key_user
    try:
        user = get_api_key_user(request)
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key")

    # Resolve feed by ID or slug.  Numeric id_or_slug → primary lookup;
    # else search by name.
    feed: Optional[dict] = None
    if id_or_slug.isdigit():
        feed = _db_manager.get_feed_config(int(id_or_slug))
    if feed is None:
        # Slug fallback — name lookup
        for fc in _db_manager.list_feed_configs(is_active=True):
            if str(fc.get("name", "")).lower() == id_or_slug.lower():
                feed = fc
                break
    if not feed:
        raise HTTPException(status_code=404, detail=f"Feed {id_or_slug!r} not found")
    if not feed.get("is_active"):
        raise HTTPException(status_code=400, detail="Feed is inactive")
    # FR-OPS-04 — external triggers get NO override: an API key has no
    # admin identity, and a change window that external systems can
    # trample is not a change window.
    await _refuse_if_deployment_window(feed, user, False,
                                       "external_trigger")

    # Per-feed API-key authorization -- and since 2026-09-11 (Clockwork
    # audit remainder, item 4) there is NO legacy hole: a feed with no
    # allow-list of its own falls back to the deployment-wide
    # ``feed_generation.external_trigger_api_key_ids``, and an absent or
    # EMPTY list admits NOBODY.  Before, a feed with no list accepted ANY
    # valid X-API-Key (a WARNING line nobody read), so with the route on,
    # any key could trigger any feed.  The change is loud on purpose: the
    # refusal names the key that would have restored the behaviour, the
    # denial is audited, and an ERROR line says which feed refused whom.
    # The per-feed list, when the feed carries one (either spelling),
    # DECIDES -- even empty (a deliberate lock); the shape rule is the
    # dataflow gate's (``_allowed_key_ids``: a list of ints / digit
    # strings, anything else "unreadable" = admit nobody, fail closed).
    from api.dataflow_api import _allowed_key_ids
    _bc = feed.get("backend_config") if isinstance(feed.get("backend_config"), dict) else {}
    if "external_trigger_api_key_ids" in _bc or "allowed_api_key_ids" in _bc:
        _raw = (_bc["external_trigger_api_key_ids"] if "external_trigger_api_key_ids" in _bc
                else _bc["allowed_api_key_ids"])
        _source = f"backend_config.external_trigger_api_key_ids (feed {feed.get('id')})"
    else:
        _raw = _fg.external_trigger_api_key_ids
        _source = "feed_generation.external_trigger_api_key_ids"
    _allowed_ids = _allowed_key_ids(_raw)
    if _allowed_ids is None:
        _audit("feed_external_trigger_denied", user,
               {"feed_id": feed.get("id"), "reason": "external_trigger_allowlist_unreadable",
                "source": _source, "shape": type(_raw).__name__})
        logger.error("[external_trigger] feed=%s REFUSED key=%s: %s cannot be read as a list of "
                     "key ids (it is a %s); no key is admitted until it is a JSON list of integers",
                     feed.get("id"), user.get("username"), _source, type(_raw).__name__)
        raise HTTPException(
            status_code=403,
            detail=f"{_source} cannot be read as a list of API key ids (it is a "
                   f"{type(_raw).__name__}); no API key is admitted to trigger this feed until it "
                   f"is a JSON list of integers.")
    if not _allowed_ids:
        _audit("feed_external_trigger_denied", user,
               {"feed_id": feed.get("id"), "reason": "external_trigger_allowlist_empty",
                "source": _source, "api_key_id": user.get("api_key_id")})
        logger.error("[external_trigger] feed=%s REFUSED key=%s (api_key_id=%s): %s is empty or "
                     "absent, and an empty allow-list admits nobody.  To admit this key set "
                     "backend_config.external_trigger_api_key_ids on the feed, or "
                     "feed_generation.external_trigger_api_key_ids for every feed without one, "
                     "to the list of api_key ids that may trigger it.  (Until 2026-09-11 a feed "
                     "with no list accepted ANY valid key; that hole is closed.)",
                     feed.get("id"), user.get("username"), user.get("api_key_id"), _source)
        raise HTTPException(
            status_code=403,
            detail=f"No API key is admitted to trigger feed {feed.get('id')!r}: {_source} is empty "
                   f"or absent, and an empty allow-list admits nobody.  Set "
                   f"backend_config.external_trigger_api_key_ids on the feed, or "
                   f"feed_generation.external_trigger_api_key_ids for every feed without one, to "
                   f"the ids of the API keys that may trigger it (this key's id is "
                   f"{user.get('api_key_id')}).")
    if int(user.get("api_key_id") or -1) not in _allowed_ids:
        _audit("feed_external_trigger_denied", user,
               {"feed_id": feed.get("id"), "reason": "api_key_not_allowlisted", "source": _source})
        raise HTTPException(
            status_code=403,
            detail=f"This API key is not permitted to trigger this feed ({_source}).")

    # business_date override (defaults to today UTC)
    if body.business_date:
        try:
            bd = datetime.fromisoformat(body.business_date[:10]).date()
        except Exception:
            raise HTTPException(
                status_code=400,
                detail="business_date must be YYYY-MM-DD",
            )
    else:
        bd = datetime.now(timezone.utc).date()

    # ── Idempotency-Key: the SAME request again is the same run. ──────
    # Checked after authorisation (an unadmitted key must not learn run
    # ids) and BEFORE the (feed, date) check, because the key is the
    # stronger identity: it names one request, whatever the run's status.
    idem_key = _idempotency_key_of(request)
    if idem_key is not None:
        prior = _db_manager.get_feed_run_by_idempotency_key(int(feed["id"]), idem_key)
        if prior is not None:
            return _idempotent_replay(feed, prior, idem_key, user)

    # Avoid duplicate feed_runs for the same (feed, date) from a
    # rapid-fire external system.  When a row exists in pending or
    # running state, return it instead of creating a new one — that
    # behaviour is the contract documented for the enterprise pattern.
    existing = _db_manager.get_feed_run_by_feed_date(int(feed["id"]), bd)
    if existing and existing.get("status") in ("pending", "running"):
        return {
            "detail": "Already queued / running",
            "feed_run_id": existing["id"],
            "status": existing["status"],
        }

    try:
        row = _db_manager.create_feed_run({
            "feed_config_id":  int(feed["id"]),
            "business_date":   bd,
            "run_date":        datetime.now(timezone.utc).date(),
            "scheduled_time":  datetime.now(timezone.utc),
            "status":          "pending",
            "priority":        int(body.priority or feed.get("priority") or 5),
            "sla_from":        feed.get("sla_from"),
            "sla_to":          feed.get("sla_to"),
            "action_decision": "RUN",
            "triggered_by":    "external",
            "triggered_by_user": user.get("username", "external"),
            "idempotency_key": idem_key,
        })
    except Exception as _create_exc:
        _unique = ("unique" in str(_create_exc).lower()
                   or "IntegrityError" in type(_create_exc).__name__)
        if not _unique:
            raise
        # Two replays of one key raced past the read above: the partial
        # UNIQUE index picked the winner, and the loser answers with it.
        if idem_key is not None:
            prior = _db_manager.get_feed_run_by_idempotency_key(int(feed["id"]), idem_key)
            if prior is not None:
                return _idempotent_replay(feed, prior, idem_key, user)
        # Otherwise the legacy one-row-per-(feed, business_date) index
        # refused a build-less row for a date that already has one that
        # is neither pending nor running (completed / failed).  Until
        # 2026-09-15 this surfaced as a raw 500; it is a 409 naming the
        # row and the path that re-runs a date on purpose.
        existing = _db_manager.get_feed_run_by_feed_date(int(feed["id"]), bd)
        raise HTTPException(
            status_code=409,
            detail=(f"Feed {feed.get('id')} already has run "
                    f"{(existing or {}).get('id')} for business date {bd.isoformat()} "
                    f"(status {(existing or {}).get('status')!r}); an external trigger "
                    f"creates one run per (feed, business_date).  To run that date "
                    f"again use the rerun / backfill route, which records a new "
                    f"build.  ({type(_create_exc).__name__})"))

    # Schedule execute_feed in the background.  We pass query_params
    # through trigger_type metadata so the engine can pick it up.
    feed_id = int(feed["id"])
    triggered_by = user.get("username", "external")
    query_overrides = body.query_params or {}

    # Phase 4 (2026-08-23) — BIND the row we just created to the execution.
    # Before, execute_feed ran WITHOUT feed_run_id: the row stayed
    # 'pending' forever (blocking future triggers for that date as
    # "Already queued"), and with the queue worker enabled the next tick
    # claimed the same row and ran the feed a SECOND time.  Claim it
    # atomically; if a queue tick snatched it in the microseconds since
    # create, that claimant owns the run — return 202 without starting a
    # duplicate.
    feed_run_id: Optional[int] = None
    try:
        _claimed = _db_manager.claim_pending_feed_run(
            int(row["id"]), claimed_by="external")
        if _claimed is None:
            logger.info(
                "[external_trigger] feed=%s run %s already claimed by "
                "another worker — not starting a duplicate",
                feed_id, row["id"])
            return {
                "detail": "Feed run accepted (claimed by queue worker)",
                "feed_run_id": row["id"],
                "feed_id": feed_id,
                "business_date": bd.isoformat(),
            }
        feed_run_id = int(row["id"])
    except Exception as _claim_exc:
        logger.warning("[external_trigger] claim of feed_run %s failed: %s "
                       "— executing without dashboard sync",
                       row["id"], _claim_exc)

    async def _run():
        from core.feed_engine import execute_feed
        # Phase 132.38 — closes the previous "not yet wired" gap.  The
        # engine now accepts ``query_param_overrides`` and threads them
        # through ``_route_source`` so:
        #   * Dynamic WHERE rows whose column appears in the override
        #     dict are applied to the executed SQL via the same
        #     wrap_sql_with_filters helper Published Views uses;
        #   * the existing ``{{name}}`` substitution path also sees
        #     the effective values (overrides win over the saved
        #     defaults).  Reserved sentinel keys like
        #     ``_where_clauses_mapping`` are stripped inside the merger
        #     so a malicious external trigger cannot rewrite the
        #     publisher's Static rules at runtime.
        if query_overrides:
            logger.info(
                "[external_trigger] feed=%s applying overrides on keys=%s",
                feed_id, list(query_overrides.keys()),
            )
        await execute_feed(
            feed_id, trigger_type="external", triggered_by=triggered_by,
            feed_run_id=feed_run_id,     # Phase 4: dashboard row is BOUND
            query_param_overrides=query_overrides or None,
        )

    background_tasks.add_task(_run)
    _audit("feed_external_trigger", user, {
        "feed_id": feed_id, "feed_run_id": row["id"], "business_date": bd.isoformat(),
    })
    logger.info("Feed %s externally triggered by %s (run_id=%s)",
                feed_id, triggered_by, row["id"])
    return {
        "detail": "Feed run accepted",
        "feed_run_id": row["id"],
        "feed_id": feed_id,
        "business_date": bd.isoformat(),
    }


@router.post("/api/admin/feeds/sla/sweep-now")
async def sla_sweep_now(user=Depends(require_admin)):
    """Force-run the SLA tracker once (admin-only)."""
    from core.feed.sla_tracker import SlaTracker
    tracker = SlaTracker(_db_manager)
    result = await asyncio.to_thread(tracker.sweep_once)
    _audit("feed_sla_sweep_now", user, result.to_dict())
    return result.to_dict()


# ── Phase 130 hotfix-11: Queue worker admin controls ─────────────────
#
# Lets admins start / stop / inspect the polling worker without
# needing to flip the config flag + restart pods.  Use case: dev
# machine + single-pod deployments where you want manual control,
# or production catch-up after a maintenance window.

_QUEUE_WORKER_JOB_ID = "__feed_queue_worker_adhoc__"
#: The id core/scheduler.py registers from config -- a DIFFERENT job on
#: purpose (see the stop route).  Named here so status can report both.
_CONFIG_QUEUE_WORKER_JOB_ID = "__feed_queue_worker__"


@router.get("/api/admin/feeds/queue-worker/status")
async def queue_worker_status(user=Depends(require_admin)):
    """Inspect the queue worker — whether the scheduler job is
    registered + what it would look like if poll_once ran right now."""
    from core.scheduler import get_scheduler
    from core.config import feed_generation as _fg
    from core.feed.queue_worker import peek_shared_queue_worker
    sched = get_scheduler()
    job = sched.get_job(_QUEUE_WORKER_JOB_ID) if sched else None
    # 2026-10-10 -- the completion-time refill: the switch, and the counters
    # of the worker on THIS pod (null when this pod runs no worker -- a pod
    # that runs none must not construct one to answer a status question).
    _qw = peek_shared_queue_worker()
    return {
        "checked_by": user.get("username", ""),
        "enabled_in_config": _fg.queue_worker_enabled,
        "poll_interval_seconds": _fg.queue_poll_interval_seconds,
        "max_concurrent": _fg.max_concurrent_native,
        "refill_on_completion": _fg.queue_refill_on_completion,
        "refills_on_this_pod": _qw.refill_stats() if _qw is not None else None,
        "ad_hoc_job_registered": job is not None,
        # 2026-09-17 -- the ad-hoc job is only ONE of the two ways a worker
        # runs.  Reporting only it meant an admin on the API pod saw
        # "registered: false" while the scheduler pod was polling happily,
        # and an admin on a pod with no scheduler could not tell "no worker"
        # from "not my pod".  Unknown is not empty.
        "config_job_registered": (
            sched.get_job(_CONFIG_QUEUE_WORKER_JOB_ID) is not None
            if sched else None),
        "scheduler_on_this_pod": sched is not None,
        "next_run_time": (
            job.next_run_time.isoformat() if job and job.next_run_time else None
        ),
    }


@router.post("/api/admin/feeds/queue-worker/start")
async def queue_worker_start(
    poll_interval_seconds: Optional[int] = None,
    user=Depends(require_admin),
):
    """Register the queue worker as an APScheduler interval job
    on this pod.  Useful for dev / single-pod / catch-up scenarios
    where you don't want to flip the config flag + restart.

    Idempotent — re-running just refreshes the interval.
    """
    from core.scheduler import get_scheduler
    from core.config import feed_generation as _fg
    from apscheduler.triggers.interval import IntervalTrigger
    sched = get_scheduler()
    if not sched:
        # 2026-09-17 (FB-3) -- SAY WHICH POD, and what to do instead.
        #
        # In the production topology the API runs in `webserver` mode with
        # the scheduler external, so there is no local scheduler and this
        # branch is CORRECT -- but the caller received "Internal server
        # error. Please contact support." and had no way to learn that the
        # control simply lives on another pod.  Third instance that day of
        # the chokepoint swallowing an honest detail; a 503 survives it.
        raise HTTPException(
            status_code=503,
            detail=(
                "This pod has no local scheduler, so it cannot start the "
                "feed queue worker. That is expected when the API runs in "
                "'webserver' mode with an external scheduler: start it on "
                "the scheduler pod, or set "
                "feed_generation.queue_worker_enabled=true (PUT "
                "/api/admin/feeds/config) so the scheduler pod registers it "
                "itself."),
        )

    interval = max(5, int(poll_interval_seconds or _fg.queue_poll_interval_seconds))
    max_concurrent = _fg.max_concurrent_native

    # 2026-09-17 (FB-3) -- a MODULE-LEVEL callable, not a closure.
    #
    # This route passed a local function to add_job, which a persistent
    # jobstore cannot serialize -- ValueError, 500, and the _audit() call
    # below never reached.  The same pattern in core/scheduler.py works only
    # because it targets the in-memory "daemon" store; this one landed in the
    # default (Postgres) store.  Both now register the SAME importable tick
    # in the SAME store under the SAME id, so a pod cannot end up running two
    # workers that poll the same rows.
    from core.feed.queue_worker import queue_worker_tick
    sched.add_job(
        func=queue_worker_tick,
        args=[int(max_concurrent)],
        trigger=IntervalTrigger(seconds=interval),
        # DELIBERATELY not the config job's id: the stop route documents that
        # stopping the ad-hoc worker leaves the config-driven one alone, and
        # collapsing them would make one control silently operate the other.
        id=_QUEUE_WORKER_JOB_ID,
        jobstore="daemon",
        name="Feed queue worker (ad-hoc)",
        replace_existing=True,
        misfire_grace_time=300,
    )
    _audit("feed_queue_worker_started", user,
           {"interval_seconds": interval, "max_concurrent": max_concurrent})
    return {
        "started": True,
        "poll_interval_seconds": interval,
        "max_concurrent": max_concurrent,
    }


@router.post("/api/admin/feeds/queue-worker/stop")
async def queue_worker_stop(user=Depends(require_admin)):
    """Unregister the ad-hoc queue worker job.  Does not affect the
    config-driven job (controlled by feed_generation.queue_worker_enabled)."""
    from core.scheduler import get_scheduler
    sched = get_scheduler()
    if not sched:
        raise HTTPException(status_code=503, detail="Scheduler not available")
    if sched.get_job(_QUEUE_WORKER_JOB_ID):
        sched.remove_job(_QUEUE_WORKER_JOB_ID)
        _audit("feed_queue_worker_stopped", user, {})
        return {"stopped": True}
    return {"stopped": False, "detail": "ad-hoc worker was not registered"}


@router.post("/api/admin/feeds/queue-worker/poll-now")
async def queue_worker_poll_now(
    business_date: Optional[str] = None,
    user=Depends(require_admin),
):
    """Fire one immediate poll tick — picks up to max_concurrent
    pending rows + dispatches them.  No effect on the registered
    interval job (if any).  Returns the tick summary."""
    target = None
    if business_date:
        try:
            target = datetime.fromisoformat(business_date[:10]).date()
        except Exception:
            raise HTTPException(status_code=400, detail="business_date must be YYYY-MM-DD")
    from core.feed.queue_worker import (get_shared_queue_worker,
                                        POLL_TRIGGER_POLL_NOW)
    from core.config import feed_generation as _fg
    worker = get_shared_queue_worker(
        _db_manager, max_concurrent=_fg.max_concurrent_native,
    )
    result = await asyncio.to_thread(
        worker.poll_once, target, trigger=POLL_TRIGGER_POLL_NOW)
    _audit("feed_queue_worker_poll_now", user, result.to_dict())
    return result.to_dict()


def _hoist_backend_choice(r: dict, exec_row: dict) -> None:
    """2026-08-22 — hoist the router's persisted BackendChoice
    (files_metadata.backend_choice) onto a dashboard row so it shows WHY
    a backend ran and whether the feed FAILED OVER, not just which
    backend it landed on.  No-op for rows persisted before the choice
    was recorded (nothing is fabricated)."""
    _bc = ((exec_row.get("files_metadata") or {}).get("backend_choice")
           or {})
    if _bc:
        r["backend_reason"] = _bc.get("reason")
        r["backend_failed_over"] = bool(_bc.get("failed_over"))


def _can_rerun_feed(feed: dict, user: dict) -> bool:
    """Permission gate for rerun / trigger actions.

    Delegates to the shared resolver in ``core.feed.permissions`` —
    single source of truth.  Returns True for:
      - admin / super_admin
      - individual owner (feed_config.created_by == username)
      - member of feed_config.owner_group_id (entitlement group)
    """
    from core.feed.permissions import can_act_on_feed
    return can_act_on_feed(feed, user, _db_manager)


def _explain_feed_denial(feed: dict, user: dict, action: str) -> str:
    """Why this user cannot act, in words an analyst can act on.

    Delegates to ``core.feed.permissions.explain_denial`` — the module
    that OWNS the rule owns its explanation, so the two cannot drift.
    Falls back to the old generic sentence if the explainer is missing,
    because a denial must never turn into a 500.
    """
    try:
        from core.feed.permissions import explain_denial
        return f"Cannot {action}. {explain_denial(feed, user)}"
    except Exception:
        return f"Only the feed owner or an admin can {action}"


def _rerun_refusal(row: dict) -> Optional[str]:
    """Why this run cannot be re-queued -- THE rule, core/feed/rerun.py."""
    from core.feed.rerun import refusal
    return refusal(row, _db_manager)


def _requeue_for_rerun(row: dict, user: dict, backend: Optional[str], reason: str,
                       reuse: Optional[dict] = None) -> dict:
    """THE re-run, core/feed/rerun.py::requeue (shared with a restatement):
    the run goes back on the QUEUE and the queue worker executes it."""
    from core.feed.rerun import requeue
    return requeue(_db_manager, row, actor=user.get("username"), reason=reason,
                   backend=backend, reuse=reuse)



def _queue_consumer_answer() -> dict:
    """Will anything claim the re-queued run?  The producer's question
    (core/feed/health.py), said in the answer -- never assumed."""
    try:
        from core.feed.health import probe_queue_consumer
        return probe_queue_consumer(db=_db_manager).to_dict()
    except Exception as exc:                    # noqa: BLE001 -- unknown is said
        return {"present": False, "determined": False, "source": "probe_error",
                "reason": f"{type(exc).__name__}: {exc}"}


@router.post("/api/feed-runs/{run_id}/rerun")
async def rerun_feed_run(
    run_id: int,
    background_tasks: BackgroundTasks,
    backend: Optional[str] = None,
    override_deployment_window: bool = False,
    user=Depends(get_current_user),
):
    """Re-execute a feed run.

    Permission: feed owner (feed_config.created_by) or admin.  Resets
    the row to status='pending' and RE-QUEUES it: the queue worker executes
    it (``_requeue_for_rerun``) -- never this API process.  Audit-logged.

    Optional ``?backend=native|airflow`` lets the operator route this
    single rerun via a specific backend (Phase 130 hotfix-13) — useful
    when one side is degraded and you want to push the work to the
    other path without flipping the global override.
    """
    per_exec_backend = _validate_per_execution_override(backend)
    row = _db_manager.get_feed_run(run_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"feed_run {run_id} not found")
    feed = _db_manager.get_feed_config(int(row["feed_config_id"]))
    if not feed:
        raise HTTPException(status_code=404,
                            detail=f"feed_config {row['feed_config_id']} not found")
    if not _can_rerun_feed(feed, user):
        raise HTTPException(
            status_code=403,
            # FR-SEC (wired 2026-09-03) — ``explain_denial`` names the
            # OWNER and the group that could act, and it had no caller:
            # every denial said "owner or an admin" without saying WHO,
            # so an analyst's only next step was to ask around.  The
            # resolver that decides the denial is the right place to
            # phrase it — a second sentence written here would drift
            # from the rule it describes.
            detail=_explain_feed_denial(feed, user, "rerun this feed"),
        )
    if not feed.get("is_active"):
        raise HTTPException(status_code=400, detail="Feed is inactive")
    # FR-OPS-04 — a rerun STARTS a run; the change window refuses it too.
    await _refuse_if_deployment_window(feed, user,
                                       override_deployment_window,
                                       "rerun")
    # Phase 130 hotfix-9 — no status gate.  UI triggers are explicit
    # user intent; admin / owner can fire any time regardless of
    # current status.  Status sync from execute_feed (via feed_run_id)
    # keeps the dashboard honest as the run progresses.

    # Reset the run to pending — clears prior timing + error fields.
    # Phase 130 hotfix-13: also increment retry_count so the dashboard
    # can show "rerun N×" badge.  Counts every operator-initiated
    # rerun (different from feed_executions count which logs every
    # attempt including scheduled cron firings).
    refusal = _rerun_refusal(row)
    if refusal:
        raise HTTPException(status_code=409, detail=refusal)
    updated = _requeue_for_rerun(row, user, per_exec_backend,
                                 f"Rerun triggered by {user.get('username')}")
    _audit("feed_run_rerun", user, {
        "feed_run_id": run_id, "feed_id": int(feed["id"]),
        "backend_override": per_exec_backend, "queued": True,
    })
    return {**(updated or {}), "queued": True,
            "queue_consumer": _queue_consumer_answer()}


@router.get("/api/feed-runs/{run_id}/rerun-failed-side")
async def failed_side_offer(run_id: int, user=Depends(get_current_user)):
    """May this failed run re-run ONLY its failed side (reusing the side that
    succeeded)?  THE answer is ``core/feed/side_resume.py::offer``."""
    row = await adb(_db_manager.get_feed_run, run_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"feed_run {run_id} not found")
    feed = await _require_feed(int(row["feed_config_id"]), user, write=False)
    return await adb(_failed_side_offer, row, feed)


def _failed_side_offer(row: dict, feed: dict) -> dict:
    from core.feed import side_resume
    from core.feed.step_model.store import execution_ids_for_runs
    eid = execution_ids_for_runs(_db_manager, [int(row["id"])]).get(int(row["id"]))
    ex = _db_manager.get_feed_execution_by_exec_id(eid) if eid else None
    bd = row.get("business_date")
    bd = date.fromisoformat(str(bd)[:10]) if bd else None
    out = side_resume.offer(_db_manager, feed, ex, bd) if ex else None
    return out or {"ok": False, "rerun_side": None, "kept_side": None,
                   "reason": "this run kept no side to reuse -- only a full re-run is possible"}


@router.post("/api/feed-runs/{run_id}/rerun-failed-side")
async def rerun_failed_side(run_id: int, override_deployment_window: bool = False,
                            user=Depends(get_current_user)):
    """Re-run ONLY the side that failed, reusing the other side's kept rows
    (2026-10-12).  Same permission, window and refusals as a re-run; 409 with
    the reason when the kept rows may not be reused (then re-run in full).
    The engine verifies the kept rows AGAIN when it runs."""
    row = _db_manager.get_feed_run(run_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"feed_run {run_id} not found")
    feed = _db_manager.get_feed_config(int(row["feed_config_id"]))
    if not feed:
        raise HTTPException(status_code=404, detail=f"feed_config {row['feed_config_id']} not found")
    if not _can_rerun_feed(feed, user):
        raise HTTPException(status_code=403, detail=_explain_feed_denial(feed, user, "rerun this feed"))
    if not feed.get("is_active"):
        raise HTTPException(status_code=400, detail="Feed is inactive")
    await _refuse_if_deployment_window(feed, user, override_deployment_window, "rerun")
    refusal = _rerun_refusal(row)
    if refusal:
        raise HTTPException(status_code=409, detail=refusal)
    offer = await adb(_failed_side_offer, row, feed)
    if not offer.get("ok"):
        raise HTTPException(status_code=409,
                            detail=f"Cannot re-run only the failed side: {offer.get('reason')}")
    from core.feed import side_resume
    ex_eid = offer.get("from_execution")
    ex = await adb(_db_manager.get_feed_execution_by_exec_id, ex_eid) if ex_eid else None
    kept = ((ex or {}).get("stage_timings") or {}).get(side_resume.KEPT_KEY)
    side_word = side_resume.SIDE_WORDS.get(offer["rerun_side"], offer["rerun_side"])
    updated = _requeue_for_rerun(
        row, user, "native",
        f"Re-run of the {side_word} side only by {user.get('username')} "
        f"(reusing {offer.get('kept_rows')} {side_resume.SIDE_WORDS.get(offer['kept_side'])} rows)",
        reuse=kept)
    _audit("feed_run_rerun_failed_side", user, {
        "feed_run_id": run_id, "feed_id": int(feed["id"]), "rerun_side": offer["rerun_side"],
        "reused_side": offer["kept_side"], "reused_rows": offer.get("kept_rows"),
        "from_execution": ex_eid})
    return {**(updated or {}), "queued": True, "offer": offer,
            "queue_consumer": _queue_consumer_answer()}


class BulkRerunRequest(BaseModel):
    """Payload for ``POST /api/feed-runs/bulk-rerun``.

    The user picks which subset to rerun.  Server enforces per-row
    permission — non-authorised rows are silently skipped and
    counted in the response so the UI can show "rer-ran 5, skipped 2
    (no permission)".
    """
    business_date: Optional[str] = None  # YYYY-MM-DD; defaults to today UTC
    statuses: Optional[List[str]] = None  # ['pending', 'failed', ...]
    run_ids: Optional[List[int]] = None  # explicit selection


@router.post("/api/feed-runs/bulk-rerun")
async def bulk_rerun_feed_runs(
    body: BulkRerunRequest,
    background_tasks: BackgroundTasks,
    backend: Optional[str] = None,
    override_deployment_window: bool = False,
    user=Depends(get_current_user),
):
    """Rerun multiple feed_runs at once.

    Selection: explicit ``run_ids`` wins; otherwise filter by
    ``business_date`` + ``statuses``.  Each row checked against
    ``_can_rerun_feed`` — unauthorised rows skipped (not 403'd) so
    the operation completes for the subset the user owns.

    Returns ``{triggered: N, denied: M, not_found: P, items: [...] }``.

    Optional ``?backend=native|airflow`` applies to every triggered
    rerun (Phase 130 hotfix-13).
    """
    per_exec_backend = _validate_per_execution_override(backend)
    # Build the candidate set
    candidates: List[dict] = []
    if body.run_ids:
        for rid in body.run_ids:
            r = _db_manager.get_feed_run(int(rid))
            if r:
                candidates.append(r)
    else:
        if body.business_date:
            try:
                bd = datetime.fromisoformat(body.business_date[:10]).date()
            except Exception:
                raise HTTPException(status_code=400,
                                    detail="business_date must be YYYY-MM-DD")
        else:
            bd = datetime.now(timezone.utc).date()
        # Phase 4 (2026-08-23): `body.statuses or [None]` folded an EMPTY
        # list into "no status filter" — an API caller sending statuses=[]
        # (deselect-everything in a client) reran EVERY row of the date,
        # completed ones included: duplicate deliveries.  Empty selection
        # now means empty result, and None keeps the documented
        # "no filter" behaviour.
        if body.statuses is not None and len(body.statuses) == 0:
            return {"triggered": 0, "denied": 0, "not_found": 0, "items": [],
                    "detail": "statuses=[] selects nothing; omit the field "
                              "to rerun regardless of status"}
        for s in (body.statuses if body.statuses is not None else [None]):
            candidates.extend(_db_manager.list_feed_runs(
                business_date=bd, status=s, limit=1000, offset=0,
            ))

    # Dedupe by run id (a row could match multiple status filters)
    seen: set = set()
    unique: List[dict] = []
    for r in candidates:
        if r["id"] in seen:
            continue
        seen.add(r["id"])
        unique.append(r)

    triggered = 0
    denied = 0
    skipped_inactive = 0
    blocked_by_window = 0
    items: List[dict] = []
    feed_cache: Dict[int, dict] = {}
    # FR-OPS-04 — one window resolution per FEED, memoised.  An
    # UNREADABLE store fails OPEN per item, ERROR-logged (same posture
    # as _refuse_if_deployment_window: a settings blip must not stop
    # the batch; a genuine window still blocks).  Admin override lifts
    # the gate for the whole call and is audited once below.
    from core.roles import is_admin_like as _is_admin_like
    _window_override = bool(override_deployment_window
                            and _is_admin_like(user))
    _window_cache: Dict[int, Any] = {}

    def _window_for(fid_: int, feed_: dict):
        if fid_ not in _window_cache:
            from core.feed.deployment_window import blocking_window_for_feed
            try:
                _window_cache[fid_] = blocking_window_for_feed(
                    _db_manager, feed_)
            except Exception as exc:
                logger.error(
                    "[feed_api] bulk-rerun: deployment windows could "
                    "not be read for feed %s (%s) — window NOT ENFORCED "
                    "for this item (fail-open)", fid_, exc)
                _window_cache[fid_] = None
        return _window_cache[fid_]

    for row in unique:
        fid = int(row["feed_config_id"])
        feed = feed_cache.get(fid) or _db_manager.get_feed_config(fid)
        if feed:
            feed_cache[fid] = feed
        if not feed or not feed.get("is_active"):
            skipped_inactive += 1
            items.append({"run_id": row["id"], "feed_config_id": fid,
                          "outcome": "skipped_inactive"})
            continue
        if not _can_rerun_feed(feed, user):
            denied += 1
            items.append({"run_id": row["id"], "feed_config_id": fid,
                          "outcome": "denied"})
            continue
        _win = None if _window_override else _window_for(fid, feed)
        if _win is not None:
            blocked_by_window += 1
            items.append({
                "run_id": row["id"], "feed_config_id": fid,
                "outcome": "blocked_by_deployment_window",
                "window_id": _win.get("id"),
                "ends_at": _win.get("ends_at"),
                "reason": _win.get("reason")})
            continue
        _refusal = _rerun_refusal(row)
        if _refusal:
            items.append({"run_id": row["id"], "feed_config_id": fid,
                          "outcome": "refused", "reason": _refusal})
            continue
        # 2026-10-12 -- RE-QUEUED for the worker, never executed in this
        # API process (see _requeue_for_rerun).
        _requeue_for_rerun(row, user, per_exec_backend,
                           f"Bulk-rerun by {user.get('username')}")
        triggered += 1
        items.append({"run_id": row["id"], "feed_config_id": fid,
                      "outcome": "triggered"})

    if _window_override:
        _audit("deployment_window_overridden", user, {
            "action": "bulk_rerun", "triggered": triggered,
        })
    _audit("feed_run_bulk_rerun", user, {
        "triggered": triggered, "denied": denied,
        "skipped_inactive": skipped_inactive,
        "blocked_by_deployment_window": blocked_by_window,
        "backend_override": per_exec_backend,
    })
    return {
        "triggered": triggered,
        "denied": denied,
        "skipped_inactive": skipped_inactive,
        "blocked_by_deployment_window": blocked_by_window,
        "items": items,
    }


@router.post("/api/feed-runs/{run_id}/cancel")
async def cancel_feed_run(run_id: int, user=Depends(require_admin)):
    """Mark a pending feed_run as cancelled.

    Only works on rows in pending state — running rows must be cancelled
    via the existing feed_executions cancel endpoint because they hold a
    cancellation Event in the engine.
    """
    row = _db_manager.get_feed_run(run_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"feed_run {run_id} not found")
    if row.get("status") not in ("pending", "skipped"):
        raise HTTPException(
            status_code=409,
            detail=f"Cannot cancel feed_run in status {row.get('status')!r}",
        )
    updated = _db_manager.update_feed_run(run_id, {
        "status": "cancelled",
        "completed_at": datetime.now(timezone.utc),
    })
    _audit("feed_run_cancelled", user, {"id": run_id})
    return updated


# ── Phase 130 hotfix-4: Control file format admin CRUD ─────────────────


class _ControlFileFormatBase(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    description: Optional[str] = None
    style: Optional[str] = Field(
        default=None, pattern="^(key_value|delimited|fixed_width)$",
    )
    delimiter: Optional[str] = Field(default=None, max_length=8)
    fields: Optional[List[str]] = None
    field_specs: Optional[Dict[str, Any]] = None
    checksum_algorithm: Optional[str] = Field(
        default=None, pattern="^(md5|sha1|sha256|sha512|crc32|none)$",
    )
    checksum_algorithms: Optional[List[str]] = None
    date_format: Optional[str] = None
    datetime_format: Optional[str] = None
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None


class ControlFileFormatCreate(_ControlFileFormatBase):
    name: str = Field(..., min_length=1, max_length=100)


class ControlFileFormatUpdate(_ControlFileFormatBase):
    pass


def _validate_ctl_fields_vs_algorithms(payload: dict, stored: dict = None) -> None:
    """Phase 4 (2026-08-23): a format could promise a checksum FIELD its
    algorithm list never computes -- fields=[..., checksum_md5] with
    checksum_algorithm=sha256 shipped a ctl with NO integrity field at all
    (the None value was silently dropped; in delimited style it also
    column-shifted).  Judge the MERGED effective shape on update."""
    eff = dict(stored or {})
    eff.update({k: v for k, v in payload.items() if v is not None})
    fields = eff.get("fields") or []
    algos = set(eff.get("checksum_algorithms") or [])
    single = eff.get("checksum_algorithm")
    if single and single != "none":
        algos.add(single)
    from core.feed.checksum import normalise_algorithm
    algos = {normalise_algorithm(a) for a in algos}
    missing = []
    for f in fields:
        if isinstance(f, str) and f.startswith("checksum_"):
            algo = f[len("checksum_"):]
            if algo not in algos:
                missing.append(f)
    if missing:
        raise HTTPException(
            status_code=400,
            detail=f"Format field(s) {missing} have no matching checksum "
                   f"algorithm configured (algorithms: {sorted(algos) or 'none'}). "
                   f"Add the algorithm(s) or remove the field(s) -- a ctl "
                   f"that promises a checksum it never computes ships "
                   f"without its integrity field.")


def _invalidate_control_format_cache(fmt_id=None) -> None:
    """Phase 4 (2026-08-23): admin CRUD edits must drop the engine's
    TTL-cached format spec (the repo docstring claimed the endpoints
    called invalidate(); no call site existed -- edits took up to 300 s
    per pod to apply)."""
    try:
        from core import feed_engine as _fe
        if _fe._control_format_repo is not None:
            _fe._control_format_repo.invalidate(fmt_id)
    except Exception as exc:
        logger.debug("control-format cache invalidation failed: %s", exc)


@router.get("/api/feed-control-file-formats")
async def list_control_file_formats_readonly(user: dict = Depends(get_current_user)):
    """Phase 4 (2026-08-23): read-only ACTIVE format list for the feed
    setup form.  /feeds is open to analysts but the picker loaded from the
    admin route and swallowed the 403 -- analysts saw only "Default
    layout" with no error, and editing an admin-configured feed rendered
    an out-of-range select."""
    return _db_manager.list_feed_control_file_formats(is_active=True)


class ControlFilePreviewRequest(BaseModel):
    """The feed form's draft -- only what decides the control file's name and text."""
    control_file_format_id: Optional[int] = None
    control_file_template: Optional[str] = None
    feed_id: Optional[int] = None          # the feed being edited (0 for a new one)
    name: Optional[str] = None
    output_format: str = "csv"
    output_filename_template: Optional[str] = None
    output_options: Optional[Dict[str, Any]] = None
    calendar_name: Optional[str] = None
    business_date: Optional[date] = None


#: the dummy data file the preview describes: three rows, so a reader sees a real
#: row count, byte size and checksum of SOMETHING -- labelled as dummy everywhere
_CTL_PREVIEW_ROWS = ("id,name,amount", "1,ALPHA,10.50", "2,BETA,20.00", "3,GAMMA,30.25")


def _render_control_file_preview(body: ControlFilePreviewRequest) -> Dict[str, Any]:
    """What a run of this feed would write as its control file -- rendered by THE
    code a run uses (the data file's name, packaging, compression, then
    ``write_control_file_for_feed``), over a three-row dummy data file in a
    temporary folder.  2026-10-22, the owner: "need preview of select control
    file with dummy data how ctl file will look like"."""
    import tempfile
    from pathlib import Path as _P
    from core import feed_engine as _fe
    from core.feed.pipeline import apply_compression, apply_packaging, write_control_file_for_feed
    opts = dict(body.output_options or {})
    feed = {"id": int(body.feed_id or 0), "name": (body.name or "FEED_PREVIEW").strip() or "FEED_PREVIEW",
            "output_format": body.output_format or "csv", "output_options": opts,
            "output_filename_template": body.output_filename_template,
            "control_file_template": body.control_file_template,
            "control_file_format_id": body.control_file_format_id,
            "calendar_name": body.calendar_name}
    spec = _fe._resolve_control_file_format(feed) if body.control_file_format_id else None
    if body.control_file_format_id and spec is None:
        raise HTTPException(404, f"control-file format {body.control_file_format_id} not found or inactive")
    if not body.control_file_template and spec is None:
        return {"control_file": None, "content": None,
                "reason": "This feed writes no control file: choose a control-file format "
                          "or give a control-file name template."}
    calendar = _fe._resolve_calendar(feed) if body.calendar_name else None
    bd = body.business_date or date.today()
    template = body.output_filename_template or "{name}_{date}.{ext}"
    data_name = _fe._build_filename(template, feed["name"], feed["output_format"], opts,
                                    feed_config=feed, calendar=calendar, run_id=0, business_date=bd)
    with tempfile.TemporaryDirectory(prefix="qs_ctl_preview_") as tmp:
        path = _P(tmp) / data_name
        # bytes, not text: write_text turns \n into \r\n on Windows and the
        # dummy's size and checksums would differ by OS
        path.write_bytes(("\n".join(_CTL_PREVIEW_ROWS) + "\n").encode("utf-8"))
        # checksum_covers=uncompressed: the RAW file's digests, captured before
        # packaging / compression -- what the engine does (core/feed/checksum_covers.py)
        from core.feed.checksum_covers import capture as _capture_digests
        raw_digests = _capture_digests(feed, [path], spec)
        steps = []
        pack = opts.get("packaging")
        if pack and str(pack).lower() not in ("", "none", "no", "false"):
            path = _P(apply_packaging(path, str(pack)))
            steps.append(f"packaged ({pack})")
        comp = opts.get("compression")
        if comp and str(comp).lower() not in ("", "none", "no", "false"):
            path = _P(apply_compression(path, str(comp)).output_path)
            steps.append(f"compressed ({comp})")
        ctl = write_control_file_for_feed(
            output_path=path, output_filename=path.name, row_count=len(_CTL_PREVIEW_ROWS) - 1,
            byte_size=path.stat().st_size, feed_config=feed, business_date=bd,
            run_date=date.today(), run_id=0, calendar=calendar, format_spec=spec,
            precomputed=raw_digests)
        if ctl is None:
            return {"control_file": None, "content": None, "reason": "This feed writes no control file."}
        # a compressed .ctl (control_file_compression=same_as_data) is SHOWN
        # decompressed -- it is delivered compressed, and the panel says so
        raw = ctl.read_bytes()
        shown, ctl_codec = raw, None
        _low = ctl.name.lower()
        if _low.endswith((".gz", ".gzip")):
            import gzip as _gz
            shown, ctl_codec = _gz.decompress(raw), "gzip"
        elif _low.endswith((".bz2", ".bzip2")):
            import bz2 as _bz2
            shown, ctl_codec = _bz2.decompress(raw), "bzip2"
        elif _low.endswith(".zst"):
            import zstandard as _zstd
            shown, ctl_codec = _zstd.ZstdDecompressor().decompress(raw), "zstd"
        return {"data_file": path.name, "control_file": ctl.name,
                "content": shown.decode("utf-8", errors="replace"),
                "control_file_compressed": ctl_codec,
                "format": (spec.name if spec is not None and getattr(spec, "name", None) else "default layout"),
                "dummy": {"rows": len(_CTL_PREVIEW_ROWS) - 1, "bytes": path.stat().st_size,
                          "business_date": bd.isoformat(), "steps": steps},
                "note": "Rendered by the same code a run uses, over a 3-row DUMMY data file: "
                        "the row count, size and checksums describe the dummy, not your data."}


@router.post("/api/feed-control-file-formats/preview")
async def preview_control_file(body: ControlFilePreviewRequest, user: dict = Depends(get_current_user)):
    """The control file a run of this (draft) feed would write, over dummy data."""
    try:
        return await asyncio.to_thread(_render_control_file_preview, body)
    except HTTPException:
        raise
    except Exception as exc:                                   # noqa: BLE001
        raise HTTPException(422, f"the control file could not be rendered: {exc}") from exc


@router.get("/api/admin/feed-control-file-formats")
async def list_control_file_formats(
    is_active: Optional[bool] = None,
    user=Depends(require_admin),
):
    return _db_manager.list_feed_control_file_formats(is_active=is_active)


@router.post("/api/admin/feed-control-file-formats", status_code=201)
async def create_control_file_format(
    body: ControlFileFormatCreate, user=Depends(require_admin),
):
    payload = body.dict(exclude_unset=True)
    payload["created_by"] = user.get("username")
    # Validate any supplied algorithms loudly
    from core.feed.checksum import normalise_algorithm, UnknownChecksumAlgorithm
    try:
        if payload.get("checksum_algorithm") and payload["checksum_algorithm"] != "none":
            normalise_algorithm(payload["checksum_algorithm"])
        for a in payload.get("checksum_algorithms") or []:
            normalise_algorithm(a)
    except UnknownChecksumAlgorithm as e:
        raise HTTPException(status_code=400, detail=str(e))
    _validate_ctl_fields_vs_algorithms(payload)
    row = _db_manager.create_feed_control_file_format(payload)
    _audit("feed_control_file_format_created", user,
           {"id": row["id"], "name": row["name"]})
    return row


@router.get("/api/admin/feed-control-file-formats/{fmt_id}")
async def get_control_file_format(fmt_id: int, user=Depends(require_admin)):
    row = _db_manager.get_feed_control_file_format(fmt_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"Format {fmt_id} not found")
    return row


@router.put("/api/admin/feed-control-file-formats/{fmt_id}")
async def update_control_file_format(
    fmt_id: int, body: ControlFileFormatUpdate, user=Depends(require_admin),
):
    payload = body.dict(exclude_unset=True)
    from core.feed.checksum import normalise_algorithm, UnknownChecksumAlgorithm
    try:
        if payload.get("checksum_algorithm") and payload["checksum_algorithm"] != "none":
            normalise_algorithm(payload["checksum_algorithm"])
        for a in payload.get("checksum_algorithms") or []:
            normalise_algorithm(a)
    except UnknownChecksumAlgorithm as e:
        raise HTTPException(status_code=400, detail=str(e))
    _validate_ctl_fields_vs_algorithms(
        payload, _db_manager.get_feed_control_file_format(fmt_id) or {})
    row = _db_manager.update_feed_control_file_format(fmt_id, payload)
    if not row:
        raise HTTPException(status_code=404, detail=f"Format {fmt_id} not found")
    _invalidate_control_format_cache(fmt_id)
    _audit("feed_control_file_format_updated", user,
           {"id": fmt_id, "keys": list(payload.keys())})
    return row


@router.delete("/api/admin/feed-control-file-formats/{fmt_id}", status_code=204)
async def delete_control_file_format(fmt_id: int, user=Depends(require_admin)):
    # Phase 4 (2026-08-23): deleting a format still referenced by feeds
    # silently rewrote every referencing feed's ctl to the legacy 9-field
    # SHA-256 layout at the next run -- downstream parsers built for the
    # custom shape broke with zero warning on the QS side.  Refuse, naming
    # the feeds.
    refs = [f for f in (_db_manager.list_feed_configs(is_active=None) or [])
            if f.get("control_file_format_id") == fmt_id]
    if refs:
        names = ", ".join(str(f.get("name")) for f in refs[:10])
        raise HTTPException(
            status_code=409,
            detail=f"Control-file format {fmt_id} is referenced by "
                   f"{len(refs)} feed(s): {names}"
                   + (" ..." if len(refs) > 10 else "")
                   + ". Detach it from those feeds first.")
    if not _db_manager.delete_feed_control_file_format(fmt_id):
        raise HTTPException(status_code=404, detail=f"Format {fmt_id} not found")
    _invalidate_control_format_cache(fmt_id)
    _audit("feed_control_file_format_deleted", user, {"id": fmt_id})
    return None


@router.post("/api/admin/feed-control-file-formats/seed-defaults", status_code=201)
async def seed_default_control_file_formats(user=Depends(require_admin)):
    """Seed predefined CTL templates (idempotent — only inserts missing rows)."""
    count = _db_manager.seed_default_feed_control_file_formats()
    _audit("feed_control_file_format_seed_defaults", user, {"inserted": count})
    return {"inserted": count}


@router.get("/api/admin/feed-control-file-formats/algorithms/list")
async def list_supported_algorithms(user=Depends(require_admin)):
    """List supported checksum algorithms (for the admin UI dropdown)."""
    from core.feed.checksum import SUPPORTED_ALGORITHMS
    return {"algorithms": list(SUPPORTED_ALGORITHMS) + ["none"]}


# ── Phase 130 hotfix-7: Entitlement Groups (User Groups) ───────────────


class UserGroupCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: bool = True
    # Phase 130 hotfix-13: group-level notification email
    notification_email: Optional[str] = Field(default=None, max_length=500)


class UserGroupUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    notification_email: Optional[str] = Field(default=None, max_length=500)


class UserGroupMemberCreate(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    role_in_group: Optional[str] = Field(default="member", pattern="^(member|owner|admin)$")
    # Phase 130 hotfix-13: per-user resource access flavour.
    # 'read_only' = view+download only; 'read_write' = full owner-equivalent.
    resource_access_level: Optional[str] = Field(default="read_write",
                                                    pattern="^(read_only|read_write)$")


class UserGroupMemberUpdate(BaseModel):
    """Phase 130 hotfix-13: allow toggling role_in_group OR
    resource_access_level on an existing member without removing+re-adding."""
    role_in_group: Optional[str] = Field(default=None, pattern="^(member|owner|admin)$")
    resource_access_level: Optional[str] = Field(default=None,
                                                   pattern="^(read_only|read_write)$")


@router.get("/api/admin/user-groups")
async def list_user_groups(
    is_active: Optional[bool] = None,
    user=Depends(require_admin),
):
    return _db_manager.list_user_groups(is_active=is_active)


@router.post("/api/admin/user-groups", status_code=201)
async def create_user_group(body: UserGroupCreate, user=Depends(require_admin)):
    payload = body.dict(exclude_unset=True)
    payload["created_by"] = user.get("username")
    g = _db_manager.create_user_group(payload)
    _audit("user_group_created", user, {"id": g["id"], "name": g["name"]})
    return g


@router.get("/api/admin/user-groups/{gid}")
async def get_user_group(gid: int, user=Depends(require_admin)):
    g = _db_manager.get_user_group(gid)
    if not g:
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    # Hydrate with members
    g["members"] = _db_manager.list_user_group_members(gid)
    return g


@router.put("/api/admin/user-groups/{gid}")
async def update_user_group(gid: int, body: UserGroupUpdate, user=Depends(require_admin)):
    payload = body.dict(exclude_unset=True)
    g = _db_manager.update_user_group(gid, payload)
    if not g:
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    _audit("user_group_updated", user, {"id": gid, "keys": list(payload.keys())})
    return g


@router.delete("/api/admin/user-groups/{gid}", status_code=204)
async def delete_user_group(gid: int, user=Depends(require_admin)):
    if not _db_manager.delete_user_group(gid):
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    _audit("user_group_deleted", user, {"id": gid})
    return None


@router.get("/api/admin/user-groups/{gid}/members")
async def list_user_group_members(gid: int, user=Depends(require_admin)):
    if not _db_manager.get_user_group(gid):
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    return _db_manager.list_user_group_members(gid)


@router.post("/api/admin/user-groups/{gid}/members", status_code=201)
async def add_user_group_member(gid: int, body: UserGroupMemberCreate,
                                 user=Depends(require_admin)):
    if not _db_manager.get_user_group(gid):
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    row = _db_manager.add_user_group_member(
        gid, body.username, body.role_in_group or "member",
        resource_access_level=body.resource_access_level or "read_write",
        added_by=user.get("username"),
    )
    _audit("user_group_member_added", user, {
        "group_id": gid, "username": body.username,
        "role_in_group": row["role_in_group"],
        "resource_access_level": row["resource_access_level"],
    })
    return row


@router.put("/api/admin/user-groups/{gid}/members/{username}")
async def update_user_group_member(gid: int, username: str,
                                     body: UserGroupMemberUpdate,
                                     user=Depends(require_admin)):
    """Toggle a member's role_in_group and/or resource_access_level.
    Phase 130 hotfix-13: the access-level toggle is what makes a
    user read_only vs read_write inside this group."""
    if not _db_manager.get_user_group(gid):
        raise HTTPException(status_code=404, detail=f"Group {gid} not found")
    updates = body.dict(exclude_unset=True)
    row = _db_manager.update_user_group_member(gid, username, updates)
    if row is None:
        raise HTTPException(status_code=404,
                            detail=f"User {username!r} not in group {gid}")
    _audit("user_group_member_updated", user, {
        "group_id": gid, "username": username, "updates": updates,
    })
    return row


@router.delete("/api/admin/user-groups/{gid}/members/{username}", status_code=204)
async def remove_user_group_member(gid: int, username: str,
                                    user=Depends(require_admin)):
    if not _db_manager.remove_user_group_member(gid, username):
        raise HTTPException(status_code=404,
                            detail=f"User {username!r} not in group {gid}")
    _audit("user_group_member_removed", user, {"group_id": gid, "username": username})
    return None


@router.get("/api/user-groups/my")
async def list_my_user_groups(user=Depends(get_current_user)):
    """Groups the current user belongs to.  Returns empty list when
    the user is not in any group.  Available to all authenticated
    users (not admin-only) so the UI can show 'you are a member of...'
    indicators."""
    return _db_manager.list_groups_for_user(user.get("username", ""))


@router.get("/api/admin/users/{username}/groups")
async def list_groups_for_user_admin(
    username: str,
    _user: dict = Depends(require_admin_read),
):
    """Admin reverse-lookup: list every group ``username`` is a member
    of, with role + access level on each.  Powers the 'per-user view'
    panel in UserGroupsAdminSection (Phase 131 deep-dive #5).  Lets
    admin see at a glance which feeds/reports a given user can touch
    instead of clicking through every group to find them.
    """
    return _db_manager.list_groups_for_user(username)


# ── Phase 130 hotfix-10: Airflow DAG inspection + ad-hoc trigger ─────


def _airflow_client():
    """Build (or fail loud) the AirflowClient from feed_generation.airflow
    config.  Raises 503 when ``feed_generation.airflow.enabled`` is off
    so non-airflow deployments get a clear answer."""
    from core.config import feed_generation as _fg
    from core.feed.airflow_client import build_default_client_from_config
    if not _fg.airflow_enabled:
        raise HTTPException(
            status_code=503,
            detail="Airflow integration is not enabled on this deployment "
                   "(feed_generation.airflow.enabled=false).",
        )
    return build_default_client_from_config(_fg.airflow)


@router.get("/api/admin/airflow/dags")
async def list_airflow_dags(
    tag: Optional[str] = None,
    only_active: bool = True,
    limit: int = Query(default=100, le=500),
    offset: int = 0,
    user=Depends(require_admin),
):
    """List DAGs the configured Airflow instance knows about.

    By default returns only active DAGs (omits paused / removed).
    Pass ``?tag=querystudio`` to filter to feed DAGs created by our
    DAG factory.
    """
    client = _airflow_client()
    try:
        dags = await asyncio.to_thread(
            client.list_dags,
            tag=tag, limit=limit, offset=offset, only_active=only_active,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Airflow API error: {e}")
    return {
        "count": len(dags),
        "items": [
            {
                "dag_id": d.dag_id,
                "description": d.description,
                "is_paused": d.is_paused,
                "is_active": d.is_active,
                "schedule_interval": d.schedule_interval,
                "tags": list(d.tags),
            }
            for d in dags
        ],
    }


@router.get("/api/admin/airflow/dags/{dag_id}")
async def get_airflow_dag(dag_id: str, user=Depends(require_admin)):
    """Single-DAG detail + the latest 20 runs."""
    client = _airflow_client()
    try:
        dag = await asyncio.to_thread(client.get_dag, dag_id)
        runs = await asyncio.to_thread(client.list_recent_runs, dag_id, 20)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Airflow API error: {e}")
    _audit("airflow_dag_inspected", user, {"dag_id": dag_id})
    return {
        "dag": {
            "dag_id": dag.dag_id,
            "description": dag.description,
            "is_paused": dag.is_paused,
            "is_active": dag.is_active,
            "schedule_interval": dag.schedule_interval,
            "tags": list(dag.tags),
        },
        "recent_runs": [
            {
                "dag_run_id": r.dag_run_id, "state": r.state,
                "execution_date": r.execution_date,
                "start_date": r.start_date, "end_date": r.end_date,
                "is_terminal": r.is_terminal,
            }
            for r in runs
        ],
    }


class AirflowDagTriggerRequest(BaseModel):
    """Optional payload for ad-hoc DAG trigger.

    ``conf`` is forwarded verbatim to Airflow as the run's ``conf``
    dict — DAG tasks pull values from it via the Airflow ``context``.
    """
    conf: Optional[Dict[str, Any]] = None


@router.post("/api/admin/airflow/dags/{dag_id}/trigger", status_code=202)
async def trigger_airflow_dag(
    dag_id: str,
    body: AirflowDagTriggerRequest,
    user=Depends(require_admin),
):
    """Ad-hoc trigger an Airflow DAG run from the QueryStudio admin UI.

    The dag_run_id is auto-generated (``manual-<8 hex>``) so admins
    don't have to guess a unique id.  Forwards the optional ``conf``
    payload verbatim.
    """
    client = _airflow_client()
    dag_run_id = f"manual-{uuid.uuid4().hex[:12]}"
    try:
        info = await asyncio.to_thread(
            client.trigger_dag, dag_id, dag_run_id, body.conf or {},
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Airflow API error: {e}")
    _audit("airflow_dag_triggered", user, {
        "dag_id": dag_id, "dag_run_id": dag_run_id,
    })
    return {
        "dag_id": info.dag_id,
        "dag_run_id": info.dag_run_id,
        "state": info.state,
    }
