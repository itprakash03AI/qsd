"""The consumer's data contract, validated AT AUTHORING — BRD 2026-09-02
§10 / §21.1 (FR-ART-01..11, FR-ACC-01).

Encoding, quoting, terminator, naming and checksum are CONTRACT TERMS,
not preferences.  A counterparty that specifies latin-1, QUOTE_ALL and
LF terminators is not negotiating, and discovering the gap the night a
feed goes live is the worst possible moment.  So (FR-ART-01) an
unsupported combination is refused WHEN IT IS TYPED, not when it is
delivered.

Two honesty rules govern this module:

1.  **Never invent support.**  The supported vocabularies are DERIVED
    from the modules that actually do the work — ``checksum.py``
    (algorithms), ``compression.py`` (codecs), ``renderers.py``
    (formats) — and where the current renderer hardcodes a behaviour
    (utf-8, csv-default quoting, CRLF), every other value is refused
    with an ``unsupported`` finding that says so.  §10.1 marks those
    ``build``; this validator repeats it instead of pretending.

2.  **Packaging and codec are two AXES, not one** (§10.2).  gzip /
    bzip2 / zstd / snappy are stream codecs — one input, one output, no
    filename inside.  ZIP is an ARCHIVE — many files, each with a
    stored name — which is exactly why counterparties ask for it when a
    feed is 1,000 parts.  Modelling ZIP as a codec value would make
    "1,000 parts -> one deliverable" inexpressible, so ``codec="zip"``
    is a hard error that points at the packaging axis.

The processing order is FIXED BY THE ENGINE, never chosen by the
author:  ``package -> compress -> encrypt -> checksum`` — the checksum
covers WHAT IS SENT (FR-ART-02): encryption runs last among the
transforms (FR-SEC-08) and the digest attests the ENCRYPTED bytes.  A
checksum declared over the pre-compression bytes describes bytes the
counterparty never receives and is refused at authoring.

**The authoring posture (FR-ART-01, settled 2026-09-03):** every
``error`` AND every ``unsupported`` finding REFUSES the save.  The FR's
plain text is "refused when it is typed, not when it is delivered" —
warn-and-save on an unsupported term is exactly the delivery-time
surprise it forbids.  ``warning`` findings (a key expiring soon) are the
only advisory severity: they surface at save and do not block it.
``require_valid`` implements this; an API split that 422s only the
errors contradicts it and must call ``require_valid`` (or refuse on
``result.unsupported`` too).

Reconciled against the artifact chain 2026-09-03: the chain NOW
packages (zip/tar), digests the concatenated whole, emits ``<file>.md5``
sidecars/manifests, names parts ``_NNN_of_NNNN`` and encrypts via
``core.feed.pgp`` — findings below say what is true PER LANE, because a
feed's lane is chosen dynamically (backend_router) and a term honoured
on one lane and silently dropped on the other is this repo's dominant
defect class.

Pure functions only: no network, no DB, no filesystem.  Two narrow,
documented exceptions, both injectable: the PGP validation probes
whether an encryption backend is importable (``pgp_available=`` to
override) and reads the clock for key expiry (``now=`` to override).
"""
from __future__ import annotations

import codecs as _codecs
from collections.abc import Mapping
from dataclasses import dataclass
from dataclasses import fields as _dc_fields
from typing import Any

from .checksum import UnknownChecksumAlgorithm, normalise_algorithm
from .compression import CompressionFormat
from .renderers import known_formats

# ── The fixed artifact pipeline (FR-ART-02) ────────────────────────────────
#: Order is fixed by the engine, not chosen by the author.  The checksum
#: is LAST because it must cover what is SENT.
ARTIFACT_PIPELINE: tuple[str, ...] = (
    "package", "compress", "encrypt", "checksum")

# ── Closed vocabularies ────────────────────────────────────────────────────
PACKAGING_VALUES = ("none", "zip", "tar")           # the ARCHIVE axis
# The codec axis comes from compression.CompressionFormat — the module
# that actually compresses.  Never a second copy here.
CODEC_VALUES = tuple(c.value for c in CompressionFormat)
ENCRYPTION_VALUES = ("none", "pgp")
CHECKSUM_SCOPES = ("part", "whole", "both")
QUOTING_VALUES = ("minimal", "all", "nonnumeric", "none")
LINE_TERMINATORS = ("crlf", "lf", "cr")
SIDECAR_VALUES = ("none", "control_file", "per_file", "manifest")
DIGEST_LINE_VALUES = ("coreutils", "bare")
SEQUENCING_VALUES = ("none", "gapless")
REDELIVERY_VALUES = ("reuse", "revision")

#: Spellings of "checksum the bytes BEFORE the pipeline finished" —
#: refused (FR-ART-02), EXCEPT the one declared term ``uncompressed``
#: (2026-10-15, the owner: "some extract creates MD5 or SHA checksum of file
#: NOT on compressed file"): the DATA file before packaging / compression /
#: encryption, for a counterparty that unpacks first and verifies after
#: (core/feed/checksum_covers.py).  The transfer is still verified on the
#: sent bytes.
_CHECKSUM_COVERS_SENT = ("sent", "delivered", "uncompressed")
_CHECKSUM_COVERS_REFUSED = (
    "raw", "source", "plaintext",
    "pre_compression", "pre_compress", "pre_encryption", "pre_package")

# What is mistaken for a codec but lives on the packaging axis.
_ARCHIVE_SPELLINGS = ("zip", "tar", "tar.gz", "tgz", "7z")

SEVERITY_ERROR = "error"              # never a valid contract term
SEVERITY_UNSUPPORTED = "unsupported"  # a real contract term the platform
#                                       cannot honour TODAY (BRD "build")
SEVERITY_WARNING = "warning"          # valid and honoured — but carries a
#                                       time bomb worth naming at save
#                                       (e.g. a key expiring soon,
#                                       FR-SEC-09).  The ONLY severity
#                                       that does not refuse the save.


class ContractError(ValueError):
    """A contract config that cannot even be parsed into a contract."""


class ContractRefused(ValueError):
    """Raised by :func:`require_valid` — carries every REFUSING finding
    (error + unsupported; never warnings) so the author sees the whole
    refusal at once, not one term per round-trip."""

    def __init__(self, findings: tuple[Finding, ...]):
        self.findings = findings
        lines = [f"  [{f.severity}] {f.field}: {f.message}" for f in findings]
        super().__init__(
            "contract refused at authoring (FR-ART-01):\n" + "\n".join(lines))


@dataclass(frozen=True)
class Finding:
    """One refusal, naming the field, the rule and the reason."""

    field: str
    severity: str  # SEVERITY_ERROR | SEVERITY_UNSUPPORTED
    message: str
    rule: str = ""  # FR id or BRD section, when one names this exact gap

    def to_dict(self) -> dict[str, Any]:
        return {"field": self.field, "severity": self.severity,
                "message": self.message, "rule": self.rule}


@dataclass(frozen=True)
class ContractValidation:
    #: True when NOTHING refuses the save — warnings alone leave ok=True.
    ok: bool
    findings: tuple[Finding, ...]

    @property
    def errors(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings
                     if f.severity == SEVERITY_ERROR)

    @property
    def unsupported(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings
                     if f.severity == SEVERITY_UNSUPPORTED)

    @property
    def warnings(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings
                     if f.severity == SEVERITY_WARNING)

    @property
    def refusals(self) -> tuple[Finding, ...]:
        """What blocks the save under the FR-ART-01 posture: every
        error and every unsupported term.  Warnings never refuse."""
        return tuple(f for f in self.findings
                     if f.severity != SEVERITY_WARNING)

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok,
                "findings": [f.to_dict() for f in self.findings]}


# ── The contract itself (FR-ACC-01 — authored, not derived) ────────────────


@dataclass(frozen=True)
class FeedContract:
    """The consumer's contract, recorded as data.

    Defaults describe what the engine ACTUALLY DOES today, so a default
    contract validates clean and any deviation is a deliberate,
    validated term.  There is deliberately NO field for processing
    order: ``package -> compress -> encrypt -> checksum`` is fixed by
    the engine (:data:`ARTIFACT_PIPELINE`).
    """

    # ── format (§10.1) ────────────────────────────────────────────────
    output_format: str = "csv"
    encoding: str = "utf-8"
    quoting: str = "minimal"
    quotechar: str = '"'
    escapechar: str | None = None
    line_terminator: str = "crlf"
    delimiter: str = ","
    header: bool = True
    null_marker: str = ""            # na_rep — NULL / NaN / Inf render as this
    empty_string_marker: str | None = None  # a DISTINCT convention for ""
    trailing_delimiter: bool = False

    # ── packaging / codec / encryption (§10.2 — two axes) ─────────────
    packaging: str = "none"          # none | zip | tar   (archive axis)
    codec: str = "none"              # none | gzip | bzip2 | zstd | snappy
    encryption: str = "none"         # none | pgp
    pgp_recipient: str | None = None
    #: The armored recipient PUBLIC key block.  Required for pgp: the
    #: FR-SEC-09 expiry preflight reads it AT SAVE, and the engine
    #: encrypts to it.  A name alone cannot be preflighted.
    pgp_public_key: str | None = None

    # ── checksum (FR-ART-02..05) ──────────────────────────────────────
    checksum_algorithm: str | None = None   # md5|sha1|sha256|sha512|crc32
    checksum_scope: str = "part"            # part | whole | both
    checksum_covers: str = "sent"           # sent | uncompressed — FR-ART-02, checksum_covers.py
    #: 2026-10-22 -- none | same_as_data: the .ctl compressed with the data's codec
    control_file_compression: str = "none"
    sidecar: str = "none"                   # none|control_file|per_file|manifest
    digest_line: str = "coreutils"          # <hash>  <filename> vs bare hash

    # ── the consumer's side of the contract (FR-ACC-01, 2026-09-03) ───
    #
    # Three terms the BRD requires that this vocabulary did not carry, so
    # an author could declare them and nothing would read them.  The API
    # was already written to map them the moment these fields exist and
    # to REFUSE them until then — a declared term nothing enforces is the
    # defect the unknown-key refusal below exists to prevent.
    #
    #: The exact column order the consumer parses positionally.  A
    #: reordered file is not a "cosmetic" change to a positional reader:
    #: it silently maps amounts onto the wrong columns.  None = the
    #: query's own order, unconstrained.
    column_order: list | None = None
    #: {"min": int, "max": int} — the volume the consumer expects.  A
    #: RANGE, not a percentage: "between 1.1M and 1.3M rows" is what a
    #: counterparty actually states, and it catches both a collapse and
    #: an unexplained doubling.  None = no expectation declared.
    expected_row_range: dict | None = None
    #: Whether the consumer ACKNOWLEDGES receipt: none | expected.
    #: "expected" is what makes an un-acknowledged delivery a finding
    #: rather than a silence nobody reads.
    acknowledgment: str = "none"

    # ── naming and sequencing (§10.3) ─────────────────────────────────
    filename_template: str | None = None
    sequencing: str = "none"                # none | gapless (state, not fmt)
    multipart_naming: bool = False          # _NNN_of_NNNN
    redelivery_naming: str = "reuse"        # reuse | revision

    # ── control file (§10.4) ──────────────────────────────────────────
    control_file_required: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {f.name: getattr(self, f.name) for f in _dc_fields(self)}


_CONTRACT_FIELDS = frozenset(f.name for f in _dc_fields(FeedContract))
_ORDER_KEYS = frozenset(
    {"order", "stage_order", "pipeline", "pipeline_order",
     "processing_order"})


def contract_from_config(config: Mapping[str, Any]) -> FeedContract:
    """Parse an authored config dict into a :class:`FeedContract`.

    Refusals here are STRUCTURAL — before term-level validation:
      * an unknown key is refused (a typo'd term would otherwise become
        a silently-ignored contract term — the author believes it is in
        force and it is not);
      * any key trying to choose the processing order is refused: the
        order is fixed by the engine (FR-ART-02).
    """
    if not isinstance(config, Mapping):
        raise ContractError(
            f"contract config must be a mapping, got "
            f"{type(config).__name__}")
    order_keys = sorted(_ORDER_KEYS & set(config))
    if order_keys:
        raise ContractError(
            f"contract config tries to declare a processing order via "
            f"{order_keys} — the order is FIXED BY THE ENGINE: "
            f"{' -> '.join(ARTIFACT_PIPELINE)} (the checksum must cover "
            f"what is SENT, FR-ART-02).  Remove the key(s)")
    unknown = sorted(set(config) - _CONTRACT_FIELDS)
    if unknown:
        raise ContractError(
            f"unknown contract term(s) {unknown} — refused rather than "
            f"silently ignored: a typo'd term the author believes is in "
            f"force must fail at authoring.  Known terms: "
            f"{sorted(_CONTRACT_FIELDS)}")
    return FeedContract(**dict(config))


# ── Validation (FR-ART-01 — refuse when TYPED, not when delivered) ─────────


def _norm(value: str | None) -> str:
    return (value or "").strip().lower()


_S101 = "§10.1"  # BRD section marking format terms as build/partial
_S102 = "§10.2"  # BRD section on the two axes


def _validate_format(contract: FeedContract, add) -> None:
    """§10.1 — format terms, honest about have vs build."""
    fmt = _norm(contract.output_format)
    if fmt == "fixed_width":
        add(Finding("output_format", SEVERITY_UNSUPPORTED,
                    "fixed-width is still common in banking interfaces but "
                    "is a separate renderer that does not exist yet — not "
                    "a CSV option (§10.1 build)", _S101))
    elif fmt not in known_formats():
        add(Finding("output_format", SEVERITY_ERROR,
                    f"unknown output format {contract.output_format!r} — "
                    f"registered renderers: {known_formats()}"))

    # encoding — served by CsvRenderer since 2026-09-03.  It hardcoded
    # utf-8 until then, so declaring latin-1 produced a utf-8 file under
    # a green status: the counterparty read mojibake and nothing in the
    # platform could see it.  An UNKNOWN codec is still an error.
    enc = _norm(contract.encoding).replace("_", "-")
    if enc not in ("utf-8", "utf8"):
        try:
            _codecs.lookup(contract.encoding)
        except (LookupError, TypeError):
            add(Finding("encoding", SEVERITY_ERROR,
                        f"{contract.encoding!r} is not a known character "
                        f"encoding"))

    # quoting — csv default (quote-when-necessary) only
    q = _norm(contract.quoting)
    if q not in QUOTING_VALUES:
        add(Finding("quoting", SEVERITY_ERROR,
                    f"unknown quoting {contract.quoting!r} — one of "
                    f"{QUOTING_VALUES}"))
    elif q == "none" and contract.escapechar is None:
        # QUOTE_NONE with nothing to escape with raises on the first
        # value containing the delimiter — mid-file, after the header
        # has already shipped.  A refusal at authoring costs a form
        # submission; that costs a half-written file at a counterparty.
        add(Finding("quoting", SEVERITY_ERROR,
                    "quoting='none' requires an escapechar: without one "
                    "the writer fails on the first value containing the "
                    "delimiter, mid-file, after the header has shipped",
                    _S101))
    # quotechar / escapechar / QUOTE_ALL / NONNUMERIC / NONE are all
    # served by CsvRenderer since 2026-09-03 and no longer refuse.


def _validate_shape(contract: FeedContract, add) -> None:
    """§10.1 continued — terminator, delimiter, null convention."""
    # line terminator — csv.writer emits CRLF, unconfigurable
    term = _norm(contract.line_terminator)
    term = {"\r\n": "crlf", "\n": "lf", "\r": "cr"}.get(
        contract.line_terminator, term)
    if term not in LINE_TERMINATORS:
        add(Finding("line_terminator", SEVERITY_ERROR,
                    f"unknown line terminator "
                    f"{contract.line_terminator!r} — one of "
                    f"{LINE_TERMINATORS}"))
    # crlf / lf / cr are all emitted by CsvRenderer since 2026-09-03.
    # CRLF remains the default, so a feed that declares nothing keeps
    # producing byte-identical output.

    # delimiter — any single character works today
    d = contract.delimiter
    if not isinstance(d, str) or len(d) != 1:
        add(Finding("delimiter", SEVERITY_ERROR,
                    f"delimiter must be exactly one character, got "
                    f"{d!r}"))
    elif d in ("\r", "\n"):
        add(Finding("delimiter", SEVERITY_ERROR,
                    "a line-break character cannot be the field "
                    "delimiter"))

    # null vs empty string — na_rep conflates them (§10.1 partial)
    # A distinct empty-string convention is served since 2026-09-03:
    # the renderer writes empty_string_marker for "" and na_rep for
    # NULL, so a counterparty that reads the two differently gets the
    # distinction kept rather than conflated.

    # trailing_delimiter is emitted since 2026-09-03 — as one empty
    # FIELD through the csv writer, not a hand-appended character, so a
    # row whose last value contains the delimiter still quotes correctly.

    for bool_field in ("header", "trailing_delimiter", "multipart_naming",
                       "control_file_required"):
        v = getattr(contract, bool_field)
        if not isinstance(v, bool):
            add(Finding(bool_field, SEVERITY_ERROR,
                        f"must be a boolean, got {v!r} "
                        f"({type(v).__name__}) — a truthy string is a "
                        f"typo, not a decision"))


def _validate_axes(contract: FeedContract, add, *,
                   pgp_available: bool | None = None,
                   now=None) -> None:
    """§10.2 — packaging and codec are two axes, never conflated."""
    pack = _norm(contract.packaging)
    if pack in CODEC_VALUES and pack != "none":
        add(Finding("packaging", SEVERITY_ERROR,
                    f"{pack!r} is a stream CODEC, not packaging — declare "
                    f"codec={pack!r}.  Packaging is the archive axis "
                    f"(many parts -> one deliverable): {PACKAGING_VALUES}",
                    _S102))
    elif pack not in PACKAGING_VALUES:
        add(Finding("packaging", SEVERITY_ERROR,
                    f"unknown packaging {contract.packaging!r} — one of "
                    f"{PACKAGING_VALUES}"))
    # packaging={zip,tar} is SUPPORTED on both lanes as of 2026-09-03 —
    # same story as the sidecar below: the refusal named "the native
    # engine does not call apply_packaging yet" as its release
    # condition, and the native lane now packages as the first rung of
    # the fixed chain (package -> compress -> encrypt -> checksum).

    codec_raw = contract.codec
    if _norm(codec_raw) in _ARCHIVE_SPELLINGS:
        add(Finding("codec", SEVERITY_ERROR,
                    f"{codec_raw!r} is an ARCHIVE format, not a stream "
                    f"codec — an archive holds many named files, which is "
                    f"exactly what makes '1,000 parts -> one deliverable' "
                    f"expressible.  Declare packaging={_norm(codec_raw)!r} "
                    f"and pick a codec from {CODEC_VALUES}", _S102))
    else:
        try:
            CompressionFormat.from_str(codec_raw)
        except ValueError:
            add(Finding("codec", SEVERITY_ERROR,
                        f"unknown codec {codec_raw!r} — "
                        f"{CODEC_VALUES} (vocabulary owned by "
                        f"core.feed.compression)"))

    encr = _norm(contract.encryption)
    if encr not in ENCRYPTION_VALUES:
        add(Finding("encryption", SEVERITY_ERROR,
                    f"unknown encryption {contract.encryption!r} — one of "
                    f"{ENCRYPTION_VALUES}"))
    elif encr == "pgp":
        _validate_pgp(contract, add, pgp_available=pgp_available, now=now)
    else:
        if contract.pgp_recipient:
            add(Finding("pgp_recipient", SEVERITY_ERROR,
                        "a pgp_recipient is declared but encryption is not "
                        "pgp — one of the two is a mistake"))
        if contract.pgp_public_key:
            add(Finding("pgp_public_key", SEVERITY_ERROR,
                        "a pgp_public_key is declared but encryption is "
                        "not pgp — one of the two is a mistake"))


def _validate_pgp(contract: FeedContract, add, *,
                  pgp_available: bool | None, now) -> None:
    """FR-ART-06 (encrypt for real, or refuse loudly) + FR-SEC-09 (an
    expired or expiring key fails AT AUTHORING, not at 03:00).

    Encryption exists since 2026-09-03: the spark artifact chain
    encrypts via ``core.feed.pgp`` and ``delivery_hops`` refuses to
    hand a plaintext artifact to any transport under a pgp contract —
    so a save here can no longer produce plaintext-with-green-status.
    What still refuses:

    * no backend on this deployment (``pgp_available``/probe) — a
      STATED unsupported finding naming what to install;
    * no recipient key material — nobody to encrypt to, and no key for
      the expiry preflight to read;
    * an unreadable or EXPIRED key — error;
    * a key expiring within 30 days — warning (save proceeds, loudly).
    """
    if not contract.pgp_recipient:
        add(Finding("pgp_recipient", SEVERITY_ERROR,
                    "encryption=pgp declared with no recipient key — "
                    "there is nobody to encrypt to"))
    if pgp_available is None:
        try:
            from .pgp import backend_refusal
            refusal = backend_refusal()
        except ImportError as exc:  # pragma: no cover — module ships with this one
            refusal = f"core.feed.pgp is not importable ({exc})"
    else:
        refusal = None if pgp_available else (
            "no PGP backend on this deployment (declared by the caller)")
    if refusal is not None:
        add(Finding("encryption", SEVERITY_UNSUPPORTED,
                    f"encryption=pgp is a contractual requirement and this "
                    f"deployment cannot encrypt: {refusal} — refused "
                    f"rather than promised (FR-ART-06)", "FR-ART-06"))
    if not contract.pgp_public_key:
        add(Finding("pgp_public_key", SEVERITY_ERROR,
                    "encryption=pgp with no recipient public key material "
                    "— the FR-SEC-09 expiry preflight cannot run without "
                    "the armored public key block, and the engine has "
                    "nothing to encrypt to", "FR-SEC-09"))
        return
    from .pgp import key_preflight
    verdict = key_preflight(contract.pgp_public_key, now=now)
    if verdict is not None:
        severity = (SEVERITY_ERROR if verdict[0] == "error"
                    else SEVERITY_WARNING)
        add(Finding("pgp_public_key", severity, verdict[1], "FR-SEC-09"))


def _validate_checksum(contract: FeedContract, add) -> None:
    """FR-ART-02..05 — the checksum covers what is SENT."""
    if contract.checksum_algorithm is not None:
        try:
            normalise_algorithm(contract.checksum_algorithm)
        except UnknownChecksumAlgorithm as exc:
            add(Finding("checksum_algorithm", SEVERITY_ERROR, str(exc),
                        "FR-ART-03"))
    scope = _norm(contract.checksum_scope)
    if scope not in CHECKSUM_SCOPES:
        add(Finding("checksum_scope", SEVERITY_ERROR,
                    f"unknown checksum scope "
                    f"{contract.checksum_scope!r} — one of "
                    f"{CHECKSUM_SCOPES}", "FR-ART-04"))
    # scope 'whole'/'both' is SUPPORTED since 2026-09-03: the artifact
    # chain computes one digest over the concatenated staged files in
    # delivery order (``_whole_scope_digest``), and a single-file feed's
    # per-file digest IS its whole digest on every lane.

    covers = _norm(contract.checksum_covers)
    if covers in _CHECKSUM_COVERS_REFUSED:
        add(Finding("checksum_covers", SEVERITY_ERROR,
                    f"checksum over {covers!r} bytes is REFUSED: a "
                    f"checksum taken before compression or encryption "
                    f"describes bytes the counterparty never receives, "
                    f"and that mismatch is a support call every time.  "
                    f"The engine checksums what is SENT — order is fixed: "
                    f"{' -> '.join(ARTIFACT_PIPELINE)}.  A counterparty that "
                    f"verifies AFTER unpacking declares 'uncompressed'", "FR-ART-02"))
    elif covers not in _CHECKSUM_COVERS_SENT:
        add(Finding("checksum_covers", SEVERITY_ERROR,
                    f"unknown checksum_covers "
                    f"{contract.checksum_covers!r} — one of 'sent' (the "
                    f"delivered file) or 'uncompressed' (the data file before "
                    f"packaging / compression / encryption) (FR-ART-02)", "FR-ART-02"))

    ctlc = _norm(contract.control_file_compression) or "none"
    if ctlc not in ("none", "same_as_data"):
        add(Finding("control_file_compression", SEVERITY_ERROR,
                    f"unknown control_file_compression {contract.control_file_compression!r} -- "
                    f"one of 'none' (the .ctl as written) or 'same_as_data' (the .ctl compressed "
                    f"with the data file's codec, e.g. .ctl.gz)"))
    elif ctlc == "same_as_data" and _norm(contract.codec) in ("", "none"):
        add(Finding("control_file_compression", SEVERITY_ERROR,
                    "control_file_compression='same_as_data' compresses the control file with "
                    "the DATA file's codec, but this feed declares no compression -- declare one "
                    "(e.g. gzip) or set control_file_compression to 'none'"))

    side = _norm(contract.sidecar)
    if side not in SIDECAR_VALUES:
        add(Finding("sidecar", SEVERITY_ERROR,
                    f"unknown sidecar {contract.sidecar!r} — one of "
                    f"{SIDECAR_VALUES}", "FR-ART-05"))
    # sidecar={per_file,manifest} is SUPPORTED on both lanes as of
    # 2026-09-03.  The refusal that stood here named its own release
    # condition — "the native engine does not call
    # write_checksum_sidecar_for_feed yet" — and since a feed's lane is
    # chosen dynamically by backend_router, the term could not be
    # promised while either lane was missing it.  Both have it now: the
    # spark artifact chain emits sidecars, and the native lane writes one
    # over the FINAL artifact (post package/compress/encrypt) and
    # delivers it on the data file's own connection.
    if side != "none" and contract.checksum_algorithm is None:
        add(Finding("checksum_algorithm", SEVERITY_ERROR,
                    f"sidecar={side!r} is declared with no checksum "
                    f"algorithm — a digest sidecar with no digest is a "
                    f"contradiction"))
    if _norm(contract.digest_line) not in DIGEST_LINE_VALUES:
        add(Finding("digest_line", SEVERITY_ERROR,
                    f"unknown digest line shape "
                    f"{contract.digest_line!r} — one of "
                    f"{DIGEST_LINE_VALUES}", "FR-ART-05"))

    # control file (§10.4) — 'have' via ControlFileWriter
    if (contract.control_file_required
            and contract.checksum_algorithm is None):
        add(Finding("checksum_algorithm", SEVERITY_ERROR,
                    "control_file_required with no checksum algorithm — "
                    "the control record carries a checksum (FR-ART-11); "
                    "declare which one", "FR-ART-11"))


def _validate_naming(contract: FeedContract, add) -> None:
    """§10.3 — naming and sequencing."""
    if contract.filename_template is not None and (
            not isinstance(contract.filename_template, str)
            or not contract.filename_template.strip()):
        add(Finding("filename_template", SEVERITY_ERROR,
                    "filename_template must be a non-empty template "
                    "string when declared"))
    seq = _norm(contract.sequencing)
    if seq not in SEQUENCING_VALUES:
        add(Finding("sequencing", SEVERITY_ERROR,
                    f"unknown sequencing {contract.sequencing!r} — one "
                    f"of {SEQUENCING_VALUES}", "FR-ART-07"))
    # sequencing=gapless is SUPPORTED since 2026-09-03.  The refusal
    # here named its own release condition — "its durable table
    # (feed_sequence_allocations) is not in the schema yet, so the state
    # cannot survive a restart" — and the table now exists, with
    # UNIQUE(feed, scope, seq_value) making concurrent allocation safe
    # and the DAO translating the constraint violation into the
    # SequenceConflict the allocator retries on.  The engine allocates
    # before rendering ${SEQ}, commits after delivery, and abandons WITH
    # A REASON on failure, so a gap always has an answer attached.
    # multipart_naming is SUPPORTED since 2026-09-03: the artifact chain
    # stages N certified parts as ``<stem>_NNN_of_NNNN.<ext>`` (the
    # manifest provides the total before the first file is named), and a
    # single-file feed keeps its plain contract name on every lane.
    if _norm(contract.redelivery_naming) not in REDELIVERY_VALUES:
        add(Finding("redelivery_naming", SEVERITY_ERROR,
                    f"unknown redelivery naming "
                    f"{contract.redelivery_naming!r} — one of "
                    f"{REDELIVERY_VALUES}; both conventions exist in the "
                    f"wild and the wrong one is silently wrong "
                    f"(FR-ART-09)", "FR-ART-09"))


def _validate_consumer_terms(c: FeedContract, add) -> None:
    """FR-ACC-01 — the consumer's side of the contract.

    These are DECLARATIONS the platform records and honours, so a
    malformed one must be refused at authoring rather than discovered by
    the counterparty.
    """
    if c.column_order is not None:
        if (not isinstance(c.column_order, (list, tuple))
                or not all(isinstance(x, str) and x.strip()
                           for x in c.column_order)):
            add(Finding("column_order", SEVERITY_ERROR,
                        "column_order must be a list of column names — a "
                        "positional consumer maps amounts onto the wrong "
                        "columns if this is malformed", "FR-ACC-01"))
        elif len(set(c.column_order)) != len(c.column_order):
            dupes = sorted({x for x in c.column_order
                            if list(c.column_order).count(x) > 1})
            add(Finding("column_order", SEVERITY_ERROR,
                        f"column_order repeats {dupes} — a column cannot "
                        f"occupy two positions", "FR-ACC-01"))
    if c.expected_row_range is not None:
        r = c.expected_row_range
        if not isinstance(r, dict) or "min" not in r and "max" not in r:
            add(Finding("expected_row_range", SEVERITY_ERROR,
                        'expected_row_range must be {"min": n} and/or '
                        '{"max": n}', "FR-ACC-01"))
        else:
            lo, hi = r.get("min"), r.get("max")
            for label, v in (("min", lo), ("max", hi)):
                if v is not None and (not isinstance(v, int)
                                      or isinstance(v, bool) or v < 0):
                    add(Finding("expected_row_range", SEVERITY_ERROR,
                                f"expected_row_range.{label}={v!r} must be a "
                                f"non-negative integer", "FR-ACC-01"))
            if (isinstance(lo, int) and isinstance(hi, int)
                    and not isinstance(lo, bool) and not isinstance(hi, bool)
                    and lo > hi):
                add(Finding("expected_row_range", SEVERITY_ERROR,
                            f"expected_row_range min={lo} exceeds max={hi} — "
                            f"no delivery can ever satisfy it", "FR-ACC-01"))
    if c.acknowledgment not in ("none", "expected"):
        add(Finding("acknowledgment", SEVERITY_ERROR,
                    f"acknowledgment={c.acknowledgment!r} is not a declared "
                    f"value (none | expected)", "FR-ACC-01"))


def validate_contract(contract: FeedContract, *,
                      pgp_available: bool | None = None,
                      now=None) -> ContractValidation:
    """Validate every term.  Returns ALL findings, never just the first.

    ``error``       — not a valid contract term at all (typo, wrong
                      axis, contradiction).
    ``unsupported`` — a legitimate counterparty requirement the platform
                      cannot honour TODAY (§10.1/§10.2 ``build``).  Also
                      refused: promising it and failing on the go-live
                      night is the worst possible moment.
    ``warning``     — valid and honoured, but carries a named time bomb
                      (FR-SEC-09 key expiring soon).  Never refuses.

    ``pgp_available`` overrides the backend probe (tests, callers that
    already probed); ``now`` overrides the clock for key expiry.
    """
    f: list[Finding] = []
    _validate_format(contract, f.append)
    _validate_shape(contract, f.append)
    _validate_axes(contract, f.append, pgp_available=pgp_available, now=now)
    _validate_checksum(contract, f.append)
    _validate_naming(contract, f.append)
    _validate_consumer_terms(contract, f.append)
    findings = tuple(f)
    ok = not any(fi.severity != SEVERITY_WARNING for fi in findings)
    return ContractValidation(ok=ok, findings=findings)


def require_valid(contract: FeedContract, *,
                  pgp_available: bool | None = None,
                  now=None) -> ContractValidation:
    """Validate and RAISE :class:`ContractRefused` on any error or
    unsupported finding — the authoring-time gate (FR-ART-01).
    Warnings ride on the returned result; they never refuse."""
    result = validate_contract(contract, pgp_available=pgp_available,
                               now=now)
    if not result.ok:
        raise ContractRefused(result.refusals)
    return result


# ── Deliverable shape (§10.2 — why the two axes matter) ────────────────────


def deliverable_count(contract: FeedContract, part_count: int) -> int:
    """How many deliverables ``part_count`` parts become under this
    contract.

    Packaging (zip/tar) merges many parts into ONE archive.  A stream
    codec NEVER merges: gzip over 1,000 parts is 1,000 ``.gz`` files —
    it must not be mistaken for the archive the counterparty asked for.
    """
    if part_count < 0:
        raise ContractError(f"part_count cannot be negative: {part_count}")
    if _norm(contract.packaging) in ("zip", "tar") and part_count > 0:
        return 1
    return part_count


def describe_pipeline(contract: FeedContract) -> tuple[str, ...]:
    """The concrete, ordered steps this contract's artifact goes
    through — always a subsequence of :data:`ARTIFACT_PIPELINE`, never
    a reordering."""
    steps: list[str] = []
    if _norm(contract.packaging) != "none":
        steps.append(f"package:{_norm(contract.packaging)}")
    if _norm(contract.codec) not in ("", "none"):
        steps.append(f"compress:{_norm(contract.codec)}")
    if _norm(contract.encryption) != "none":
        steps.append(f"encrypt:{_norm(contract.encryption)}")
    if contract.checksum_algorithm is not None:
        steps.append(
            f"checksum:{normalise_algorithm(contract.checksum_algorithm)}"
            f":{_norm(contract.checksum_scope)}")
    return tuple(steps)
