"""
Feed File Generation Engine — Hybrid Native + Airflow/Spark.

QueryStudio acts as orchestration layer. Execution backends:
  native      -> DuckDB pipeline (reuses existing query execution)
  airflow     -> Trigger Airflow DAG (SparkKubernetesOperator)

Smart routing picks backend based on data size + availability.
Circuit breakers detect failing backends and auto-fallback to native.
"""
import asyncio
import collections
import json
import logging
import math
import os
import re
import threading
import time
import uuid
from datetime import date, datetime, timezone
# Module-level on purpose: tests monkeypatch ``core.feed_engine.csv`` and
# ``core.feed_engine.shutil`` to simulate a mid-write failure
# (tests/test_feed_truncation_atomicity_2026_08_03.py).  A function-local
# import would not be interceptable, so a lint sweep that removes these as
# "unused" breaks the atomicity tests -- it did, on 2026-08-17.
import csv     # noqa: F401 -- patched by the truncation-atomicity tests
import shutil  # noqa: F401 -- patched by the truncation-atomicity tests
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# BF-599h: adb wrapper for sync DB calls in async functions.
from core.db_async import adb

logger = logging.getLogger(__name__)

# ── feed_run sync observability (2026-09-15) ──────────────────────────────
#
# ``_sync_feed_run`` dispatches its DB write to an executor and does not
# await it -- correct, the engine must not block on a dashboard update.  But
# the future was DISCARDED, so no caller and no test could ever know when the
# write landed.  The one test that asserts feed_runs carries the execution's
# row count therefore polled for a fixed 2.5 s and failed under load.
#
# These keep a handle.  Nothing in the engine waits on them; they exist so a
# test (or a future shutdown drain) can.
_FEED_RUN_SYNCS: list = []
_FEED_RUN_SYNCS_LOCK = threading.Lock()


def _register_feed_run_sync(fut) -> None:
    with _FEED_RUN_SYNCS_LOCK:
        _FEED_RUN_SYNCS[:] = [f for f in _FEED_RUN_SYNCS if not f.done()]
        _FEED_RUN_SYNCS.append(fut)


def drain_feed_run_syncs(timeout: float = 10.0) -> bool:
    """Block until every in-flight feed_run sync write has finished.

    TEST SEAM.  Nothing in production calls this, deliberately: the engine
    must never block on a dashboard update, which is why ``_sync_feed_run``
    is fire-and-forget in the first place.  It exists so a test can wait for
    the WRITE instead of guessing at it with a sleep -- the assertion that
    ``feed_runs`` carries the execution's row count used to poll for a fixed
    2.5 s and failed whenever the machine was busy, which made it a timing
    guard rather than a behaviour guard.

    Returns True if everything completed within ``timeout``.
    """
    import time as _t
    deadline = _t.monotonic() + max(0.0, timeout)
    while _t.monotonic() < deadline:
        with _FEED_RUN_SYNCS_LOCK:
            pending = [f for f in _FEED_RUN_SYNCS if not f.done()]
            _FEED_RUN_SYNCS[:] = pending
        if not pending:
            return True
        _t.sleep(0.01)
    with _FEED_RUN_SYNCS_LOCK:
        return not [f for f in _FEED_RUN_SYNCS if not f.done()]



# 2026-09-26 -- ONE predicate for "which registration failures affect this
# query": it now lives beside the view setup that publishes the scope, which
# also refuses on it for the batch callers.  Re-exported here for the feed
# check below and its tests.
from core.duckdb_views import registration_failures_in_scope  # noqa: E402,F401


# Module-level references injected at startup
_db_manager = None
_broadcast_fn: Optional[Callable] = None
_cfg = None       # _FeedGenerationCfg accessor
_native_sem = None   # threading.Semaphore for native concurrency
_airflow_breaker = None   # Simple circuit breaker for Airflow


# ── 2026-08-20 — explicit dependency carrier for feed execution ─────────────
# The scheduler-pod incident: the queue worker CLAIMED feed_runs that
# execute_feed could not run, because _db_manager above is wired only by
# whichever entry file happened to run (main.py's lifespan).  The durable
# fix is passing the dependency EXPLICITLY from the entry point (the
# _exec_business_report precedent).  ``FeedEngineDeps`` carries it;
# ``_resolve_deps`` keeps the module globals as a FALLBACK during the
# incremental migration, so an unconverted call site loses nothing and a
# converted one cannot outrun an unwired process (it self-wires the module
# singletons — _cfg/_native_sem/_airflow_breaker are process-wide SHARED
# state, deliberately NOT per-call: a per-call semaphore would double the
# native concurrency cap).
from dataclasses import dataclass as _dataclass  # noqa: E402


@_dataclass
class FeedEngineDeps:
    """What feed execution needs from its entry point.

    * ``db_manager``    — REQUIRED: the db the caller claims/loads runs
      with.  A queue worker must never claim a run its executor cannot
      execute; passing its own db here makes that structural.
    * ``broadcast_fn``  — optional websocket broadcast.  None is a valid
      value (scheduler pod has no websocket); the module-global handler
      keeps working where main.py wired one.
    """
    db_manager: Any
    broadcast_fn: Optional[Callable] = None


def _resolve_deps(deps: Optional["FeedEngineDeps"]) -> "FeedEngineDeps":
    """Explicit deps win; module globals are the transition fallback.

    * deps is None  -> build from module globals.  Unwired module = the
      2026-08-20 loud guard (RuntimeError, not an AttributeError mid-run
      after the claim).
    * deps passed, module unwired -> self-wire the module with the SAME db
      (init_feed_engine) so the process-wide singletons and any not-yet-
      converted helper below execute_feed see a wired module.  This is the
      backstop that makes a PARTIAL migration safe: explicit-deps callers
      can never hit a None global in unconverted code.
    * deps passed, module wired to a DIFFERENT db -> loud warning; the
      explicit deps win at converted sites (split-brain is visible, not
      silent).
    """
    if deps is None:
        if _db_manager is None:
            raise RuntimeError(
                "feed_engine is not initialised in this process — call "
                "init_feed_engine(db_manager) before executing feeds "
                "(scheduler pods get this via "
                "core.daemon_registry.wire_scheduled_execution_deps), or "
                "pass deps=FeedEngineDeps(db_manager=...) explicitly")
        return FeedEngineDeps(db_manager=_db_manager,
                              broadcast_fn=_broadcast_fn)
    if deps.db_manager is None:
        raise RuntimeError(
            "FeedEngineDeps.db_manager is None — an explicit deps object "
            "must carry a real db manager")
    if _db_manager is None:
        init_feed_engine(deps.db_manager, broadcast_fn=deps.broadcast_fn)
        logger.info("[feed_engine] module was unwired — initialised from "
                    "the caller's explicit FeedEngineDeps")
    elif _db_manager is not deps.db_manager:
        logger.warning(
            "[feed_engine] explicit deps carry a DIFFERENT db_manager than "
            "the module wiring — converted call sites will use the "
            "explicit one; check which entry point wired this process")
    return deps

# ── Phase 132.27 — live log streaming for feed runs ─────────────────────
# Per-execution context: the active exec_id + triggered_by + feed_id.
# Set at the top of execute_feed; the logging handler reads it so every
# logger.info() in the feed_engine flows through to WS automatically
# (no per-call instrumentation).
import contextvars  # noqa: E402

# Foundation P (2026-09-02) — definition pinning.  Imported at module
# level so a missing pin is a LOUD ImportError at boot rather than a
# per-run except that silently executes the live definition forever.
from core.feed import pinning as _pinning  # noqa: E402
# 2026-10-10 -- the OG single-brace {TOKEN} renderer's refusals (a declared
# token with no value, a value no literal can hold) and THE merge-by-name
# plan both lanes read.  Module level: a missing gate must be a loud boot
# failure, never a per-run except that runs the SQL "as-is".
from core.feed.sql_tokens import (  # noqa: E402
    UnresolvedToken as _UnresolvedToken,
    UnsafeTokenValue as _UnsafeTokenValue,
)
from core.feed.sql_tokens import BindingRefused as _BindingRefused  # noqa: E402
# 2026-10-11 -- a token BINDING that no longer matches the saved query's
# predicate is the same class of refusal: the run fails naming it, never
# runs the stale literal.
_TokenRefusal = (_UnresolvedToken, _UnsafeTokenValue, _BindingRefused)
from core.feed.merge_by_name import (  # noqa: E402
    CROSS_SOURCE_KEY as _CROSS_SOURCE_KEY,
    MergeRefused as _MergeRefused,
    cross_source_record as _cross_source_record,
    plan_merge as _plan_merge,
)
# 2026-10-11 -- THE per-side reported-rows certification (each side's rows
# vs the upstream message's ROW_COUNT), shared byte-for-byte with the Spark
# job's image (spark/jobs/qs_reported_rows_certification.py).
from core.feed.reported_rows_certification import (  # noqa: E402
    RECORD_KEY as _RR_RECORD_KEY,
    failure_sentence as _rr_failure_sentence,
    judge as _rr_judge,
)
# FB-59 (2026-09-21) -- THE Oracle destination identifier rule, shared
# byte-for-byte with the Spark job's image.  Module level for the same
# reason as the pin above: if the rule is missing, the pod and this
# lane must not quietly fall back to two different answers.
from core.feed.oracle_identifiers import (  # noqa: E402
    canonical_oracle_columns as _canonical_oracle_columns,
    resolve_oracle_columns as _resolve_oracle_columns,
)
# 2026-10-07 -- THE missing-table rule and the all-or-nothing rule for an
# Oracle destination, shared byte-for-byte with the Spark job's image the
# same way.  Module level for the same reason.
from core.feed.oracle_destination_table import (  # noqa: E402
    OracleTableUnavailable as _OracleTableUnavailable,
    ensure_oracle_table as _ensure_oracle_table,
    max_error_percent as _max_error_percent,
    oracle_bind_value as _oracle_bind_value,
    refuse_time_columns as _refuse_time_columns,
    rejection_message as _rejection_message,
    rejection_refusal as _rejection_refusal,
    replace_rows_sql as _replace_rows_sql,
    time_columns_in_arrow as _time_columns_in_arrow,
)
_active_exec_ctx: 'contextvars.ContextVar[Optional[dict]]' = contextvars.ContextVar(
    "feed_engine_active_exec", default=None,
)


def delivery_retry_policy(feed_config: dict, cfg) -> tuple:
    """(max_retries, retry_delay_seconds) for a feed's delivery.

    2026-09-24.  A feed's own value OVERRIDES the deployment default; a BLANK
    one (None -- the authoring UI sends null for "inherit") takes the default.
    This read ``feed_config.get("max_retries", default)``: the key is always
    PRESENT on a stored feed, so a cleared value came back as None and delivery
    died on ``range(None + 1)``.  0 is a real value (no retries) and is kept.
    """
    mr = (feed_config or {}).get("max_retries")
    rd = (feed_config or {}).get("retry_delay_seconds")
    return (cfg.retry_max_attempts if mr is None else int(mr),
            cfg.retry_delay_seconds if rd is None else int(rd))


def _sem_permits(configured, *, name: str) -> int:
    """Permit count for a concurrency semaphore, honouring 0 = UNLIMITED.

    2026-08-22 — delegates to core.concurrency_permits, the single definition.
    This was one of THREE private copies; the audit found the two semaphore
    constructors that never got the fix (published_views/warmup, graphql_api),
    which is what a copied fix always ends up costing.
    """
    from core.concurrency_permits import sem_permits as _sp
    return _sp(configured, name=name)


class _FeedLogStreamHandler(logging.Handler):
    """Broadcasts each feed_engine log record as a ``feed_run_log`` WS
    event, scoped to the active execution via _active_exec_ctx.

    Outside an execution (no contextvar set), the handler is a no-op
    so module-level / startup logs don't spam every connected client.
    """
    def emit(self, record: logging.LogRecord) -> None:
        try:
            ctx = _active_exec_ctx.get()
            if not ctx or _broadcast_fn is None:
                return
            msg = self.format(record) if self.formatter else record.getMessage()
            # 2026-10-07: addressed to the execution's audience (resolved
            # once, on the context), not to triggered_by.
            from core.feed.event_audience import address
            _broadcast_fn(address({
                "event":         "feed_run_log",
                "exec_id":       ctx.get("exec_id"),
                "exec_db_id":    ctx.get("exec_db_id"),
                "feed_id":       ctx.get("feed_id"),
                "triggered_by":  ctx.get("triggered_by"),
                "level":         record.levelname,
                "line":          msg,
                "at":            datetime.now(timezone.utc).isoformat(),
            }, _event_audience(ctx.get("feed_id"), ctx.get("triggered_by"),
                               run_id=ctx.get("feed_run_id"))))
        except Exception as _log_stream_exc:
            # Never let log streaming kill a feed run — but DO log so
            # an admin tailing the backend log knows when the WS push
            # is failing.  BF-599h: was bare pass; now DEBUG with the
            # exception type so operators can diagnose WS issues
            # without enabling the full feed-engine debug stream.
            logger.debug("[feed-log-stream] broadcast failed (%s): %s",
                          type(_log_stream_exc).__name__, _log_stream_exc)


# Wired in init_feed_engine; idempotent install.
_feed_log_handler: Optional[_FeedLogStreamHandler] = None

# BF-415 — cancellation registry.  Maps execution_id -> threading.Event
# (also covers asyncio code paths via a non-blocking is_set() check).
# The /cancel API endpoint signals the event; long-running stages in
# execute_feed poll it between phases (query, format, deliver, retry
# sleep) and short-circuit when set.  Without this the cancel endpoint
# was purely cosmetic — it flipped the DB row to "cancelled" but the
# background task kept running and eventually overwrote status back to
# "completed".  Multi-pod note: this dict is process-local so a cancel
# only signals the pod hosting the running task.  In multi-pod
# deployments the API endpoint also writes a "cancel_requested" marker
# to the DB row; pods cross-check the DB on each poll (see
# ``_check_cancelled``).
_cancel_events: Dict[str, "threading.Event"] = {}
_cancel_events_lock = threading.Lock()


def _register_cancel_event(execution_id: str) -> "threading.Event":
    """Register (or fetch) the cancellation Event for a running execution."""
    if not execution_id:
        # Synthesize a never-set event so callers don't have to None-guard.
        return threading.Event()
    with _cancel_events_lock:
        ev = _cancel_events.get(execution_id)
        if ev is None:
            ev = threading.Event()
            _cancel_events[execution_id] = ev
        return ev


def _unregister_cancel_event(execution_id: str) -> None:
    """Remove the cancellation event when an execution terminates."""
    if not execution_id:
        return
    with _cancel_events_lock:
        _cancel_events.pop(execution_id, None)


_TERMINAL_EXECUTION_STATES = ("completed", "failed", "cancelled")


def _finalize_execution_row(db, exec_db_id, updates: dict) -> bool:
    """Terminal-state write with a CLOBBER GUARD (2026-08-22).

    The race: the awaiting coroutine exhausts its poll budget and raises
    while the job actually SUCCEEDED — its webhook (or the spark_k8s
    reconciler, or another pod) lands ``completed`` in the gap between
    the raise and this handler's write.  Writing ``failed`` over that
    row marks a completed, already-DELIVERED feed as failed; an operator
    retriggers it and the customer receives the delivery twice.

    So: RE-READ immediately before every terminal write and refuse to
    overwrite a state another actor already finalized — the same rule
    the spark_k8s reconciler has followed since it shipped.  The refusal
    direction is deliberate: a completed feed booked as failed triggers
    a duplicate delivery of real data; a failed feed booked late merely
    surfaces later.  Fail toward leaving the terminal state alone.

    The PROBE itself is fail-open (a transient read error must not
    strand the row in 'running' forever — the legitimate write is the
    only thing that ends it), but a probe failure is logged: a silently
    broken guard looks exactly like 'no race'.

    Returns True when the write happened, False when it was refused.
    """
    existing: dict = {}
    try:
        existing = db.get_feed_execution(exec_db_id) or {}
        current = str(existing.get("status") or "").lower()
    except Exception as _probe_exc:
        logger.warning(
            "[feed_engine] terminal-write guard could not re-read execution "
            "%s (%s) — proceeding with the write (fail-open on the probe, "
            "never on the overwrite)", exec_db_id, _probe_exc,
        )
        current = ""
    intended = str(updates.get("status") or "").lower()
    if current in _TERMINAL_EXECUTION_STATES and current != intended:
        logger.warning(
            "[feed_engine] execution %s is already TERMINAL (%s, finalized "
            "by another actor) — refusing to overwrite it with '%s'. "
            "Discarded update keys: %s",
            exec_db_id, current, intended, sorted(updates.keys()),
        )
        return False
    if current in _TERMINAL_EXECUTION_STATES and current == intended:
        # Same terminal verdict from two actors: the first write stands
        # (its numbers came from the actor that actually finished the
        # work); re-writing it can only lose information.
        #
        # 2026-09-21 — but "the first write stands" was applied to the
        # WHOLE update, and the two finalizers do not write the same
        # FIELDS.  On the spark_k8s lane the job's completion webhook
        # lands {status, completed_at, error_message} and nothing else,
        # so the engine's own record — ``duration_seconds`` and
        # ``files_metadata`` carrying ``backend_choice``, the routing
        # decision added on 2026-08-22 precisely so "why did my big feed
        # go to spark_k8s" is answerable from the execution row — was
        # discarded ENTIRELY.  Proved live: a feed on ``auto`` routed to
        # spark_k8s, failed, and its row carried files_metadata=NULL and
        # duration_seconds=NULL.
        #
        # So fill ONLY the keys the row has no value for.  That cannot
        # lose the first finalizer's information — which is the entire
        # argument for the rule — because a key it already answered is
        # still never overwritten.  ``status`` is excluded explicitly:
        # it is the verdict being compared, not a fact to backfill.
        _absent = (None, "", {}, [])
        fill: Dict[str, Any] = {}
        for k, v in updates.items():
            if k == "status" or v in _absent:
                continue
            cur = existing.get(k)
            if cur in _absent:
                fill[k] = v
            elif isinstance(cur, dict) and isinstance(v, dict):
                # 2026-10-11 -- the same rule one level DOWN: a dict field
                # (files_metadata, stage_timings) the first finaliser wrote
                # with ITS sub-keys (spark_k8s, spark_job_failure) is not
                # "answered" for the sub-keys only this actor has
                # (backend_choice, the engine's stage durations).  Fill
                # those; never overwrite a sub-key already there.
                missing = {sk: sv for sk, sv in v.items() if sk not in cur}
                if missing:
                    fill[k] = {**cur, **missing}
        if fill:
            db.update_feed_execution(exec_db_id, fill)
        logger.info(
            "[feed_engine] execution %s already '%s' — leaving the first "
            "finalizer's record in place%s", exec_db_id, current,
            f" (backfilled keys it never wrote: {sorted(fill)})"
            if fill else "",
        )
        return False
    db.update_feed_execution(exec_db_id, updates)
    # 2026-09-28 -- the feed CONSUMER notices (delivered / failed) ride the
    # ONE terminal write every lane ends in, AFTER it landed: a write the
    # clobber guard refused above was another actor's finalisation, and
    # that actor raised the notice.  Advisory -- never raises into the run.
    if str(updates.get("status") or "").lower() in _TERMINAL_EXECUTION_STATES:
        try:
            from core.feed.consumer_notices import on_execution_finalised
            on_execution_finalised(db, exec_db_id)
        except Exception as _cn_exc:  # noqa: BLE001
            logger.error("[feed_engine] consumer notice for execution %s could "
                         "not be raised: %s", exec_db_id, _cn_exc)
    return True


def signal_cancel(execution_id: str) -> bool:
    """Public hook called by the /cancel API endpoint.

    Returns True iff the execution was running on THIS pod and the in-process
    event was signalled.  In multi-pod deployments the API endpoint must ALSO
    write a DB-level marker (e.g. status='cancel_requested') so pods running
    the task in another process pick it up via the periodic DB poll in
    ``_check_cancelled``.
    """
    if not execution_id:
        return False
    with _cancel_events_lock:
        ev = _cancel_events.get(execution_id)
    if ev is None:
        return False
    ev.set()
    return True


def _check_cancelled(execution_id: str, exec_db_id: Optional[int] = None,
                     db: Any = None) -> bool:
    """Return True iff this execution has been cancelled.

    Checks two sources:
      1) The in-process event (set by signal_cancel on this pod).
      2) The DB row's status — covers the multi-pod case where the API
         endpoint that received the cancel ran on a different pod from
         the worker.  Cheap (single SELECT keyed by id), safe to poll
         between stages.
    """
    if not execution_id:
        return False
    with _cancel_events_lock:
        ev = _cancel_events.get(execution_id)
    if ev is not None and ev.is_set():
        return True
    db = db if db is not None else _db_manager
    if exec_db_id is not None and db is not None:
        try:
            row = db.get_feed_execution(exec_db_id)
            if row and (row.get("status") == "cancelled"
                        or row.get("cancel_requested") is True):
                return True
        except Exception:
            pass
    return False


# ---------------------------------------------------------------------------
# Minimal circuit breaker for external feed backends
# ---------------------------------------------------------------------------
class _SimpleBreaker:
    """Minimal circuit breaker for external feed backends."""

    def __init__(self, name: str, threshold: int = 3, cooldown: int = 60):
        self.name = name
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._last_failure = 0.0
        self._state = "closed"  # closed | open | half_open
        self._lock = threading.Lock()

    @property
    def is_open(self) -> bool:
        with self._lock:
            if self._state == "open":
                if time.time() - self._last_failure > self.cooldown:
                    self._state = "half_open"
                    return False
                return True
            return False

    def record_success(self):
        with self._lock:
            self._failures = 0
            self._state = "closed"

    def record_failure(self):
        with self._lock:
            self._failures += 1
            self._last_failure = time.time()
            if self._failures >= self.threshold:
                self._state = "open"
                logger.warning(
                    "[feed_engine] Circuit breaker OPEN for %s after %d failures",
                    self.name, self._failures,
                )

    def reset(self):
        with self._lock:
            self._failures = 0
            self._state = "closed"
            self._last_failure = 0.0

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "name": self.name,
                "state": self._state,
                "failures": self._failures,
                "threshold": self.threshold,
                "cooldown": self.cooldown,
            }


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------
def init_feed_engine(db_manager, broadcast_fn=None):
    """Called from main.py _startup()."""
    global _db_manager, _broadcast_fn, _cfg, _native_sem, _airflow_breaker
    global _feed_log_handler
    _db_manager = db_manager
    _broadcast_fn = broadcast_fn
    from core.config import feed_generation as fg
    _cfg = fg
# 2026-08-20 -- A ZERO-PERMIT SEMAPHORE IS AN OUTAGE, NOT A LIMIT.
    # These accessors are raw int(get(...)) with no clamp, so a configured
    # 0 -- which everywhere else in this product spells UNLIMITED, including
    # published_views.max_concurrent_per_key in this very module --
    # constructed a semaphore that can never be acquired:
    #   ETL  : threading acquire() with NO timeout -> hangs FOREVER, silently
    #   feed : acquire(timeout=300)                -> total outage after 300s
    #   PV   : asyncio.Semaphore(0) is TRUTHY, so it passes the readiness
    #          guard, then every request burns 30s and 429s
    # _sem_permits treats <=0 as 'no limit' so the operator's spelling means
    # what it means everywhere else.
    _native_sem = threading.Semaphore(
        _sem_permits(fg.max_concurrent_native, name='feed_engine'))
    _airflow_breaker = _SimpleBreaker("airflow")
    # Ensure output dir exists
    os.makedirs(fg.output_dir, exist_ok=True)
    # Phase 132.27 — install the log-stream handler on the feed_engine
    # logger (idempotent; only attaches once even if init_feed_engine is
    # called multiple times during test bring-up).
    if _feed_log_handler is None:
        _feed_log_handler = _FeedLogStreamHandler(level=logging.INFO)
        # Use the standard message-only format
        _feed_log_handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(_feed_log_handler)
    # ── The STEP MODEL (2026-09-05) ─────────────────────────────────
    # Discover the shipped steps, register whatever the DATABASE
    # adds (feed_custom_step_types -- the plugin path: make the
    # module importable, insert one row, no redeploy), and project
    # the whole catalogue into feed_step_types so the admin UI can
    # list steps and render their parameter forms without importing
    # Python.  Fail-open: an unbootable registry costs the timeline,
    # never the feed.
    try:
        from core.feed.step_model import init_feed_pipeline
        _steps_boot = init_feed_pipeline(db_manager)
    except Exception as _sp_exc:
        _steps_boot = {"error": f"{type(_sp_exc).__name__}: {_sp_exc}"}
        logger.error("[feed_engine] step registry boot FAILED: %s",
                     _sp_exc, exc_info=True)
    logger.info(
        "[feed_engine] Initialised — native_slots=%d, airflow=%s, steps=%s",
        fg.max_concurrent_native, fg.airflow_enabled, _steps_boot,
    )


def get_feed_engine_stats() -> dict:
    """Return feed engine capacity stats for health endpoint (Phase 132-I)."""
    return {
        "native_slots": {
            "max": _cfg.max_concurrent_native if _cfg else 0,
            "available": _native_sem._value if _native_sem else 0,
        },
        "airflow_breaker": (
            _airflow_breaker.to_dict() if _airflow_breaker and hasattr(_airflow_breaker, "to_dict")
            else {"name": "airflow", "state": "unknown"} if _airflow_breaker else {"name": "airflow", "state": "not_init"}
        ),
    }


# ---------------------------------------------------------------------------
# Smart routing — pick execution backend
# ---------------------------------------------------------------------------
def _pick_backend(
    feed_config: dict,
    estimated_rows: int = None,
    *,
    per_execution_override: Optional[str] = None,
) -> str:
    """Resolve the execution backend for one run.

    Phase 130 hotfix-13: delegates to :func:`core.feed.backend_router.pick_backend`
    so the decision tree lives in ONE place and can be unit-tested
    independently.  The returned ``BackendChoice`` is also stored on the
    feed_execution row (``backend_reason`` / ``backend_failed_over``)
    for audit visibility.

    Raises :exc:`core.feed.backend_router.ExecutionHaltedError` when the
    global override is ``'halt'`` — callers convert this to a skip.
    """
    from core.feed.backend_router import pick_backend
    choice = pick_backend(
        feed_config,
        per_execution_override=per_execution_override,
        estimated_rows=estimated_rows,
        cfg=_cfg,
        airflow_breaker_open=bool(_airflow_breaker and _airflow_breaker.is_open),
    )
    if choice.failed_over:
        logger.info(
            "[feed_engine] feed %s backend selection failed over -> %s (%s)",
            feed_config.get("id"), choice.backend, choice.reason,
        )
    return choice.backend


def _disk_space_preflight(output_dir, estimated_rows, *,
                          cross_source: bool = False,
                          cfg=None) -> Optional[str]:
    """Refuse a pod-disk-writing feed run BEFORE hours of work when disk is
    PROVABLY insufficient (2026-08-22, design_starburst_140m bug #5).

    A 140M-row native feed writes a parquet + a converted copy (+ a
    combined copy when cross-source) to pod disk, and until now the first
    signal of a full disk was ENOSPC at hour 2.  Same posture as the
    BF-463 destination preflight: the facts are knowable at feed start,
    so check them at feed start.

    Fail-OPEN on every uncertainty — knob off, no row estimate, statvfs
    failure ("production probes are fail-open"): the run proceeds exactly
    as before.  The refusal fires only when even the most OPTIMISTIC
    estimate cannot fit: ``min_bytes_per_row`` is deliberately the
    zstd-parquet FLOOR (~32 B/row), not a mean, so a refusal means "this
    cannot succeed", never "this might be tight".

    Returns an error string to refuse with, or ``None`` to proceed.
    """
    try:
        cfg = cfg if cfg is not None else _cfg
        if not bool(getattr(cfg, "disk_preflight_enabled", True)):
            return None
        rows = int(estimated_rows or 0)
        if rows <= 0:
            return None                       # no estimate — cannot judge
        bpr = int(getattr(cfg, "disk_preflight_min_bytes_per_row", 32) or 0)
        if bpr <= 0:
            return None                       # 0/negative = operator opt-out
        # parquet result + converted output copy; cross-source adds the
        # combined third copy (sides A + B + combined live simultaneously).
        copies = 3 if cross_source else 2
        required = rows * bpr * copies
        import shutil
        free = int(shutil.disk_usage(str(output_dir)).free)
        if free >= required:
            return None
        return (
            f"Disk preflight: ~{required / 1e9:.1f} GB needed at minimum "
            f"({rows:,} rows x {bpr} B/row floor x {copies} on-disk copies) "
            f"but only {free / 1e9:.1f} GB free under {output_dir}. "
            f"Refusing before hours of work instead of ENOSPC mid-run. "
            f"Free disk, lower the feed's row count, or route the feed to "
            f"the airflow backend (writes to S3, not pod disk)."
        )
    except Exception as exc:
        logger.debug(
            "[feed_engine] disk preflight skipped (fail-open): %s", exc)
        return None


def _pick_backend_detailed(
    feed_config: dict,
    estimated_rows: int = None,
    *,
    per_execution_override: Optional[str] = None,
    delivery_suppressed: Optional[bool] = None,
):
    """Same as :func:`_pick_backend` but returns the full ``BackendChoice``
    so the caller can persist ``reason`` + ``failed_over`` for audit.

    Raises ``backend_router.LaneRefused`` for a PINNED run whose lane
    cannot take it (K3); ``delivery_suppressed`` is the run's stored "do
    not deliver" decision (K6)."""
    from core.feed.backend_router import pick_backend
    return pick_backend(
        feed_config,
        per_execution_override=per_execution_override,
        estimated_rows=estimated_rows,
        cfg=_cfg,
        airflow_breaker_open=bool(_airflow_breaker and _airflow_breaker.is_open),
        delivery_suppressed=delivery_suppressed,
    )


# ---------------------------------------------------------------------------
# E-M2 — non-iceberg first-run row-estimate collectors
# ---------------------------------------------------------------------------
def _collect_noniceberg_parquet_row_counts(feed_config: dict):
    """Best-effort: return an iterable of per-file parquet-footer ``num_rows``
    for a non-iceberg S3/parquet feed source, or ``None`` when they aren't
    cheaply available.

    Reads footer metadata ONLY for files the feed source already carries in
    its resolved config (``query_params.files`` / ``source_path`` when it
    points at a concrete local/materialised parquet).  Never lists S3 or
    downloads data — footer reads are metadata-only and skipped on any
    error so this can't add latency to the routing decision.  Returns
    ``None`` (not a partial sum) when nothing usable is found.
    """
    try:
        qp = feed_config.get("query_params") or {}
        candidates = []
        files = qp.get("files")
        if isinstance(files, (list, tuple)):
            candidates.extend([f for f in files if isinstance(f, str)])
        src = qp.get("source_path")
        if isinstance(src, str) and src:
            candidates.append(src)
        # Only local / mounted parquet paths are cheap to footer-read here;
        # s3:// paths would require a network round-trip we deliberately avoid.
        local_parquet = [
            c for c in candidates
            if c.lower().endswith(".parquet")
            and not c.lower().startswith(("s3://", "s3a://", "http://", "https://"))
        ]
        if not local_parquet:
            return None
        import pyarrow.parquet as _pq
        counts = []
        for path in local_parquet:
            try:
                counts.append(int(_pq.ParquetFile(path).metadata.num_rows))
            except Exception:
                continue
        return counts or None
    except Exception:
        return None


def _build_noniceberg_jdbc_count_fn(feed_config: dict):
    """Return a zero-arg callable that runs a bounded ``SELECT COUNT(*)`` for
    a JDBC-backed feed source, or ``None`` when a count isn't applicable /
    the opt-in isn't enabled.

    The callable owns its own timeout so the estimator never blocks the
    routing decision on the network.  Disabled by default
    (``feed_generation.noniceberg_jdbc_count_enabled``) because a COUNT(*)
    adds load to the source DB; operators opt in per fleet.  Returns ``None``
    (no callable) whenever prerequisites are missing so the estimator simply
    skips the JDBC signal.
    """
    try:
        if not getattr(_cfg, "noniceberg_jdbc_count_enabled", False):
            return None
        source_type = (feed_config.get("source_type") or "").lower()
        if source_type not in ("raw_sql", "jdbc"):
            return None
        # The concrete JDBC execution is intentionally left to the existing
        # connector path; when a fleet enables this, wire the connector's
        # bounded-count helper here.  Until then we return None so the
        # estimator falls through to its other signals (fail-safe).
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------
async def execute_feed(
    feed_config_id: int,
    trigger_type: str = "manual",
    triggered_by: str = "unknown",
    execution_id: str = "",
    feed_run_id: Optional[int] = None,
    backend_override: Optional[str] = None,
    query_param_overrides: Optional[Dict[str, Any]] = None,
    deps: Optional[FeedEngineDeps] = None,
    dry_run: bool = False,
    reuse_side: Optional[Dict[str, Any]] = None,
) -> dict:
    """
    Main orchestration function for feed execution.

    ``dry_run`` (2026-09-27): the FULL chain runs -- query, format,
    packaging, compression, checksum sidecar, control file, local
    integrity, row-count check -- and then NOTHING is delivered: no hop
    runner, no ``delivery_attempts`` row, no completeness verdict or
    certificate, no notification, no sequence number spent, no run count.
    The produced file is registered in the Download Centre as a transient
    item (``DRY_RUN_DOWNLOAD_RETENTION_DAYS``) so the operator can inspect
    exactly what WOULD have gone.  The execution's trigger_type and the
    run's run_type are ``dry_run`` (``core.feed_executor.DRY_RUN_TYPE``),
    ``stage_timings.delivery_chain.verdict`` is ``dry_run`` and
    ``files_metadata.dry_run`` says so.  Refused on the lanes that deliver
    INSIDE the job (airflow, spark_k8s).

    1. Load feed config from DB
    2. Create or reuse feed_execution record (status=pending)
    3. Pick backend
    4. Dispatch to _execute_native / _execute_airflow
    5. On success: convert format + deliver + update status
    6. On error: circuit breaker record + retry logic + update status
    7. Notify via broadcast_fn + send notifications
    """
    # Phase 132.27 — set the context var so the log-stream handler can
    # tag every logger.info() under this execution with the right exec_id.
    # We can't set it before exec_id is computed; we patch it in place
    # right after computing exec_id below.

    # 2026-08-20 — fail LOUD, not with an AttributeError mid-run: a process
    # that reaches execute_feed without init_feed_engine (the scheduler pod
    # before the daemon-registry wiring existed) used to crash on the None
    # module global AFTER a queue worker had already claimed the run.  The
    # guard now lives in _resolve_deps, which also lets an entry point pass
    # its OWN db explicitly (FeedEngineDeps) — the module globals remain
    # only as the fallback for unconverted callers.
    deps = _resolve_deps(deps)
    db = deps.db_manager

    # 1. Load config.  BF-591: off-loop the DB round-trips — execute_feed
    # runs on the queue worker's dedicated event loop; multiple concurrent
    # feeds stacked sync DB latency against each other.
    feed_config = await asyncio.to_thread(db.get_feed_config, feed_config_id)
    if not feed_config:
        raise ValueError(f"Feed config {feed_config_id} not found")
    if not feed_config.get("is_active"):
        raise ValueError(f"Feed config {feed_config_id} is inactive")

    # Phase 130 hotfix-13 audit fix #4: load the feed_run row and stash
    # it on feed_config so downstream SQL execution can resolve
    # calendar-aware tokens ({{business_date}}, {{prev_business_day}},
    # etc.).  When feed_run_id is None (legacy per-feed cron without an
    # SOD row), business_date defaults to today UTC in the resolver.
    if feed_run_id is not None:
        try:
            feed_config["_feed_run"] = await asyncio.to_thread(
                db.get_feed_run, int(feed_run_id),
            )
        except Exception as _fr_exc:
            logger.debug("[feed_engine] could not load feed_run %s: %s",
                          feed_run_id, _fr_exc)

    # ── FR-GOV-01, the RE-RUN half (wired 2026-09-03) ────────────────────
    # The pin below fixes "a definition deployed mid-run reaches this run".
    # It does NOT fix "a re-run of business date D next month uses TODAY's
    # definition" — the comment under it claimed both, and only one was
    # true, because ``resolve_definition_for_rerun`` (the function that
    # answers "what was live FOR THAT DATE?") had no caller at all.
    #
    # So a backfill of an old date silently produced a DIFFERENT file from
    # the one the counterparty originally received, while the audit trail
    # said it was the same feed re-run — the precise failure the pinning
    # module was built to prevent.
    #
    # Resolved BEFORE pin_run_at_claim so the pin records what actually
    # executes, not what happened to be live when the operator clicked.
    # Fail-open: an unresolvable prior definition leaves the live one in
    # place (the module logs the fallback at INFO and a lookup failure at
    # ERROR), because refusing a backfill outright helps nobody.
    # 2026-10-12 -- the AUTHOR's say comes first: a definition change saved
    # with "apply from" (core/feed/definition_timeline.py) decides which
    # definition a run of this business date executes, whatever started it
    # (scheduled, re-run, restatement).  No timeline / none applies -> the
    # pinned-for-date rule below, unchanged.
    _timeline_applied = False
    _tl_biz = (feed_config.get("_feed_run") or {}).get("business_date")
    if _tl_biz:
        try:
            from core.feed import definition_timeline as _dtl
            _tl = _dtl.resolve(db, feed_config_id, _tl_biz)
            if _tl is not None:
                _tl_cfg, _tl_entry = _tl
                _carried = {k: feed_config[k] for k in ("_feed_run",) if k in feed_config}
                feed_config = dict(_tl_cfg)
                feed_config.update(_carried)
                _timeline_applied = True
                logger.info("[feed_engine] feed %s business date %s executes definition version "
                            "id %s (%s, saved by %s)", feed_config_id, _tl_biz,
                            _tl_entry.get("version_id"), _tl_entry.get("note"),
                            _tl_entry.get("saved_by"))
        except Exception as _tl_exc:
            logger.error("[feed_engine] feed %s: the definition timeline could not be read for "
                         "%s (%s) -- the pinned-for-date rule decides", feed_config_id, _tl_biz,
                         _tl_exc)
    if not _timeline_applied and str(trigger_type or "") in ("rerun", "backfill", "restatement"):
        try:
            _rr_biz = (feed_config.get("_feed_run") or {}).get("business_date")
            if _rr_biz:
                _rr_cfg, _rr_src, _rr_prior =                     _pinning.resolve_definition_for_rerun(
                        db, feed_config_id, _rr_biz,
                        live_config=feed_config)
                if _rr_cfg and _rr_src == "pinned":
                    _rr_carried = {k: feed_config[k] for k in ("_feed_run",)
                                   if k in feed_config}
                    feed_config = dict(_rr_cfg)
                    feed_config.update(_rr_carried)
                    logger.info(
                        "[feed_engine] feed %s re-run of %s executes the "
                        "PINNED definition from build %s — not today's",
                        feed_config_id, _rr_biz, _rr_prior)
                elif _rr_src == "live_never_delivered":
                    logger.info(
                        "[feed_engine] feed %s re-run of %s: the date was never "
                        "delivered — executing the LIVE definition",
                        feed_config_id, _rr_biz)
                else:
                    logger.info(
                        "[feed_engine] feed %s re-run of %s has no pinned "
                        "prior definition (%s) — executing the LIVE one; "
                        "the output may differ from the original delivery",
                        feed_config_id, _rr_biz, _rr_src)
        except Exception as _rr_exc:
            logger.error(
                "[feed_engine] feed %s re-run could not resolve the "
                "definition that was live for its business date (%s) — "
                "executing the LIVE definition, which may not reproduce "
                "the original file", feed_config_id, _rr_exc)

    # ── Foundation P (2026-09-02, FR-RUN-03 / FR-GOV-01) ─────────────────
    # PIN the definition at claim time and execute the PIN, not the live row.
    #
    # Without this a feed that starts at 22:00 and finishes at 02:00 picks up
    # a definition deployed at 23:00, and a re-run of business date D next
    # month silently uses TODAY's definition while the audit trail says it was
    # the same feed.  Both produce a different file with no signal that
    # anything changed.
    #
    # Fail-open by construction: ``pin_run_at_claim`` returns the definition it
    # could persist, and ``persisted=False`` means an AUDIT HOLE (logged at
    # ERROR) rather than a dead feed — a run must not stop because a snapshot
    # could not be written.  The volatile per-run keys are re-stashed onto the
    # pinned copy afterwards; they are runtime context, never definition.
    _pin = None
    try:
        _pin = _pinning.pin_run_at_claim(
            db, feed_config.get("_feed_run") or {"feed_config_id": feed_config_id},
            feed_config)
        _pinned_def = (_pin or {}).get("definition")
        if _pinned_def:
            _carried = {k: feed_config[k] for k in ("_feed_run",)
                        if k in feed_config}
            feed_config = dict(_pinned_def)
            feed_config.update(_carried)
    except Exception as _pin_exc:
        # The pin is an audit and reproducibility control, not a gate.  A
        # broken snapshot must never stop tonight's feed — but it must never
        # be silent either, or "which definition ran?" becomes unanswerable
        # without anyone knowing it did.
        logger.error(
            "[feed_engine] feed %s could not be pinned (%s) — executing the "
            "LIVE definition.  This run is not reproducible: a definition "
            "deployed mid-run may reach it, and a later re-run of this date "
            "will not use these values.",
            feed_config_id, _pin_exc)

    # Phase 131 deep-dive #8 — stash the triggering username on feed_config
    # so the credential resolver can look up the user's cached portal
    # password (BF-285 vault, 8h TTL).  Previously the credential calls
    # passed literal strings "feed_engine" / "feed_delivery" as the
    # username, so vault lookups never hit for any real user — even
    # when their session was active.  Result: every private S3 feed
    # crashed with PersonalPasswordRequired regardless of whether the
    # owner had a fresh session.
    feed_config["_triggered_by_user"] = triggered_by

    # ── FR-CMP-09 / FR-DEP-12 (2026-09-02) — THE ASSERTION PRODUCER ──────
    # ``feed_config["_gate_assertion"]`` was read in three places and
    # written in NONE: a run an operator released by skipping a dependency
    # reached its completeness verdict carrying no assertion at all and
    # came out VERIFIED — an assertion laundered into evidence.  The
    # durable record is the append-only run_events ledger
    # (``dependency_skipped``: actor, reason, timestamp, written by
    # core.feed.dependency_skip BEFORE the gate is released); the
    # Assertion is built FROM that record, never invented here.  An
    # unreadable or anonymous record refuses attribution and rides as an
    # UNVERIFIABLE claim instead — see _load_gate_assertion.
    feed_config["_gate_assertion"] = await asyncio.to_thread(
        _load_gate_assertion, db, feed_config, feed_config_id)

    # Phase 132.38 — stash the per-run consumer overrides so the
    # WHERE-mapping apply helpers (raw_sql wrap + query_config merge)
    # can pick them up downstream in _route_source / _execute_native.
    # Also overlay them onto query_params so the existing ``{{name}}``
    # substitution path sees the effective values too.  Reserved
    # sentinel keys (``_where_clauses_mapping``) are stripped inside
    # the merger so a malicious external trigger cannot rewrite the
    # publisher's rules at runtime.
    if query_param_overrides:
        feed_config["_consumer_overrides"] = dict(query_param_overrides)
        try:
            from core.feed_where_apply import merge_query_params_with_overrides
            merge_query_params_with_overrides(feed_config, query_param_overrides)
        except Exception as _ov_exc:
            logger.warning(
                "[feed_engine] consumer override overlay failed: %s",
                _ov_exc, exc_info=True,
            )

    # Phase 130 hotfix-8 — when called for a SOD-generated row, keep
    # feed_runs.status in sync with execution lifecycle so the
    # dashboard reflects progress.  Helper inline; ignored when
    # feed_run_id is None (legacy per-feed cron path unchanged).
    # 2026-09-24 (edge-case sweep) -- the writes for ONE run are applied in
    # the ORDER THEY WERE ISSUED.  Each used to go to the default thread pool
    # on its own, so two of them could land out of order: measured in the
    # full suite, a run whose engine logged FAILED ended ``completed`` on
    # feed_runs because the earlier write executed after the terminal one --
    # the dashboard said a failed delivery succeeded.  A per-run queue with a
    # single drainer keeps BF-591's contract (the caller never awaits, never
    # blocks) while making the order the issue order.  No thread waits on
    # another (no pool starvation), and an executor job still finishes when
    # an ``asyncio.run`` caller closes its loop.
    _sync_queue: "collections.deque" = collections.deque()
    _sync_lock = threading.Lock()
    _sync_draining = [False]

    def _sync_feed_run(updates: dict) -> None:
        """BF-591: dispatch DB write off-loop when called from an async
        context (most callers).  Falls back to direct sync when no
        running loop is present.  Caller never awaits — fire-and-forget.
        Writes for this run are applied in issue order (see above)."""
        if not feed_run_id or db is None:
            return

        def _apply(u: dict) -> None:
            try:
                db.update_feed_run(int(feed_run_id), u)
            except Exception as _e:
                logger.warning(
                    "[feed_engine] could not sync feed_run %s: %s",
                    feed_run_id, _e,
                )

        def _drain() -> None:
            while True:
                with _sync_lock:
                    if not _sync_queue:
                        _sync_draining[0] = False
                        return
                    u = _sync_queue.popleft()
                _apply(u)

        with _sync_lock:
            _sync_queue.append(dict(updates))
            if _sync_draining[0]:
                return          # the running drainer will apply it, in order
            _sync_draining[0] = True
        try:
            _loop = asyncio.get_running_loop()
            _fut = _loop.run_in_executor(None, _drain)
            # 2026-09-15 -- KEEP A HANDLE so a test can wait for the write
            # instead of sleeping (drain_feed_run_syncs).  The drainer runs
            # until the queue is empty, so this one handle covers every
            # write queued while it runs.
            _register_feed_run_sync(_fut)
        except RuntimeError:
            _drain()

    # Persist the consumer overrides onto the FeedRun row so the
    # operations dashboard can show which overrides this run used + so
    # a future "rerun with these overrides" UX has a source of truth.
    # Only writes when overrides were actually supplied (NULL otherwise
    # so SOD-generated rows stay legacy-shaped).
    _run_seed: Dict[str, Any] = {
        "status": "running",
        "started_at": datetime.now(timezone.utc),
        "error": None,
    }
    if query_param_overrides:
        _run_seed["consumer_overrides"] = dict(query_param_overrides)
    _sync_feed_run(_run_seed)

    # 2. Reuse pre-created execution record or create new one
    #    Atomic guard prevents duplicate executions from concurrent triggers (Phase 132-B)
    exec_id = execution_id or f"feed-{uuid.uuid4().hex[:16]}"
    # Phase 132.27 — bind the exec context for the log-stream handler.
    # All logger.info() calls from here on emit feed_run_log WS events.
    # 2026-10-07 -- the audience of this execution's live events is
    # resolved ONCE here (THE function: core/feed/event_audience.py) and
    # read by _notify and the log-stream handler for the whole run.  Read
    # from the LIVE feed row, not ``feed_config`` (a pinned definition is
    # the run's recipe; who owns the feed is not part of the pin).
    # The RUN is named (2026-10-07 follow-up): the person who ASKED for it
    # (``feed_runs.triggered_by_user`` -- a backfill's requester, a rerun's)
    # hears its events; the actor here is ``queue_worker`` for every queued
    # run.  The row the engine holds, else by id (``run_id``) when the row
    # could not be loaded above; ``feed_run_id`` None = the run has none.
    from core.feed.event_audience import (
        feed_event_audience, run_log_stream_of as _run_log_stream_of)
    _exec_audience = feed_event_audience(
        db, feed_config_id, triggered_by,
        run=feed_config.get("_feed_run"), run_id=feed_run_id)
    _active_exec_ctx.set({
        "exec_id":      exec_id,
        "feed_id":      feed_config_id,
        "feed_run_id":  feed_run_id,
        "triggered_by": triggered_by,
        "audience":     _exec_audience,
    })
    # Phase Z (2026-06-09) — register feed execution with the brain's
    # path-recording + ContextVar plumbing so /diagnose/{id} shows
    # feed runs the same way it shows BQB queries.  Pre-Phase-Z,
    # feed runs never called record_execution_path → diagnose UI's
    # execution_path block was empty → operator couldn't tell whether
    # the brain even fired for a feed query.
    try:
        from core.query_diagnostic_store import set_current_execution_id
        set_current_execution_id(exec_id)
    except Exception:
        pass
    try:
        from core.brain.scan_plan import record_execution_path as _rep_feed
        _rep_feed(
            execution_id=exec_id,
            branch="5_feed_engine",
            has_reg=False,    # feed engine path doesn't expose this
            raw_sql=True,     # feed gen executes the resolved SQL
            has_s3_reg=bool(feed_config.get("primary_connection_id")),
            notes=(
                f"feed_id={feed_config_id} · trigger={trigger_type} · "
                f"by={triggered_by}"
            ),
        )
    except Exception:
        pass
    # Phase 130 hotfix-13 — honour per-execution backend_override AND
    # handle the global "halt" override.  The router raises
    # ExecutionHaltedError when backend_override='halt'; we surface
    # that as a skipped execution + sync the feed_run row.
    #
    # Phase 131 deep-dive #13 (round 8) — derive estimated_rows so the
    # size-based auto router actually fires.  Order of precedence:
    #   1. admin-set estimated_row_count (manual override on the config)
    #   2. last successful run's actual row count (auto-updated below)
    #   3. Phase 145.2 — iceberg manifest sum(record_count) for tables the
    #      feed SQL actually references (cached, no S3 work)
    #   4. None — router falls back to default behaviour (native).
    # 2026-10-13 -- THIS run's size (core/feed/run_size.py): an admin's
    # estimate, else the upstream messages' ROW_COUNT for this business date
    # (every side), else the previous run.  The previous run alone sent a
    # month end's million rows to the shared worker after a 9-row re-send.
    from core.feed.run_size import estimate as _run_size
    _size = _run_size(db, feed_config)
    estimated_rows = _size["rows"]
    feed_config["_run_size"] = dict(_size)
    if estimated_rows is None:
        # Phase 145.2 — Use the iceberg manifest cache populated by the
        # BF-299 background sync.  For a feed that's never run AND has no
        # admin estimate, this avoids the "default → native → 10-min hang"
        # trap by letting the router push huge feeds to Spark on first run.
        #
        # Cross-source aware: when a feed has secondary_connection_id, sum
        # primary + secondary estimates.  Single backend decision serves
        # both sides — under-estimating either side risks the WHOLE feed
        # getting routed to native when it shouldn't.
        try:
            from core.feed_sql_resolver import resolve_feed_sql
            from core.query_hints import extract_referenced_tables
            from core.feed_row_estimator import estimate_rows_from_iceberg_cache

            def _estimate_one_side(sql: str, conn_id):
                """Returns int or None for a single (sql, connection_id) pair."""
                if not sql or not conn_id:
                    return None
                try:
                    _conn_raw = db.get_connection_raw(conn_id)
                    _reg = (_conn_raw or {}).get("config", {}).get("registered_tables") or []
                    _refs = extract_referenced_tables(_reg, sql)
                    if not _refs:
                        return None
                    return estimate_rows_from_iceberg_cache(
                        connection_id=conn_id,
                        registered_tables=_reg,
                        referenced_tables=_refs,
                        partition_filters=None,
                    )
                except Exception as exc:
                    logger.debug(
                        "[feed_engine] Phase 145.2 side estimate failed (conn=%s): %s",
                        conn_id, exc,
                    )
                    return None

            _preview = resolve_feed_sql(db, feed_config)
            _primary_est = _estimate_one_side(
                _preview.get("sql"),
                _preview.get("connection_id") or feed_config.get("connection_id"),
            )
            _secondary_est = _estimate_one_side(
                _preview.get("secondary_sql"),
                feed_config.get("secondary_connection_id"),
            )
            _summed = (_primary_est or 0) + (_secondary_est or 0)
            if _summed > 0:
                estimated_rows = _summed
                logger.info(
                    "[feed_engine] Feed %d Phase 145.2: manifest-driven "
                    "estimate=%d rows (primary=%s + secondary=%s) — "
                    "routing decision uses this",
                    feed_config_id, _summed,
                    _primary_est if _primary_est else "n/a",
                    _secondary_est if _secondary_est else "n/a",
                )
        except Exception as _est_exc:
            logger.debug(
                "[feed_engine] Feed %d Phase 145.2 estimate failed (non-fatal): %s",
                feed_config_id, _est_exc,
            )

        # E-M2 — non-iceberg fallback estimate.  The iceberg manifest
        # estimator only speaks iceberg, so a never-run parquet / JDBC feed
        # still had estimated_rows=None → router defaulted to native (the
        # slow-download trap).  When enabled, derive a cheap estimate from
        # already-listed parquet footers or a bounded JDBC COUNT(*).  Opt-in
        # (default OFF) + fully fail-safe: any failure leaves estimated_rows
        # as None so the router keeps its current behaviour.  Only relevant
        # when a non-native backend (spark_connect) is enabled.
        if estimated_rows is None and getattr(_cfg, "noniceberg_estimate_enabled", False):
            try:
                from core.feed_row_estimator import estimate_rows_noniceberg
                _pq_counts = _collect_noniceberg_parquet_row_counts(feed_config)
                _jdbc_count_fn = _build_noniceberg_jdbc_count_fn(feed_config)
                _nonice = estimate_rows_noniceberg(
                    parquet_row_counts=_pq_counts,
                    jdbc_count_fn=_jdbc_count_fn,
                )
                if _nonice and _nonice > 0:
                    estimated_rows = _nonice
                    logger.info(
                        "[feed_engine] Feed %d E-M2: non-iceberg estimate=%d "
                        "rows — routing decision uses this",
                        feed_config_id, _nonice,
                    )
            except Exception as _ni_exc:
                logger.debug(
                    "[feed_engine] Feed %d E-M2 non-iceberg estimate failed "
                    "(non-fatal): %s", feed_config_id, _ni_exc,
                )
    # 2026-10-07 -- "must this run NOT deliver?" decided ONCE, here, from
    # the bound feed_run, and STORED on the execution
    # (delivery_suppressed).  Every lane reads the stored answer: the
    # native hop runner below, the spark_k8s job conf (deliver_in_job), the
    # Airflow conf, the Spark webhook-side delivery -- and, since the lane
    # contract (K6), the ROUTER: a run whose file must come back through
    # the artifact store cannot go to a Spark lane that has none.  The
    # webhook used to re-derive it by asking for a suppressed run still
    # 'running', which races the completed write -- and the spark_k8s job
    # never asked at all, so a backfill the router sent to Spark DELIVERED.
    from core.feed.delivery_hops import (
        decide_run_delivery_suppression as _decide_suppression,
        stored_delivery_suppression as _stored_suppression,
    )
    _delivery_suppressed = _decide_suppression(feed_config.get("_feed_run"))
    existing = db.get_feed_execution_by_exec_id(exec_id) if execution_id else None
    if existing and _stored_suppression(existing) is not None:
        # Already decided (a detached row the spark-submit route or a
        # retry created): the stored answer stands.
        _delivery_suppressed = _stored_suppression(existing)

    from core.feed.backend_router import ExecutionHaltedError, LaneRefused
    # A PINNED run whose lane cannot take it (K3): the execution row is
    # still created -- naming the lane the operator asked for -- and then
    # failed below with the lane's reason, before anything else happens.
    _lane_refusal: Optional[LaneRefused] = None
    try:
        choice = _pick_backend_detailed(
            feed_config,
            per_execution_override=backend_override,
            estimated_rows=estimated_rows,
            delivery_suppressed=_delivery_suppressed,
        )
    except LaneRefused as refused:
        _lane_refusal = refused
        choice = refused.choice
        logger.error("[feed_engine] Feed %d: %s", feed_config_id, refused)
    except ExecutionHaltedError as halted:
        logger.info(
            "[feed_engine] Feed %d execution halted by backend_override: %s",
            feed_config_id, halted,
        )
        if feed_run_id is not None:
            try:
                db.update_feed_run(feed_run_id, {
                    "status": "skipped",
                    "action_decision": "SKIP",
                    "action_reason": "feed_generation.backend_override=halt",
                    "completed_at": datetime.now(timezone.utc),
                })
            except Exception:
                pass
        return {
            "status": "skipped",
            "reason": "backend_override_halt",
            "feed_config_id": feed_config_id,
        }
    backend = choice.backend
    if dry_run and backend in DRY_RUN_REFUSED_LANES:
        # The route refuses a feed PINNED to such a lane; the router can
        # still pick one by size.  Refuse here too, before any row is
        # touched, rather than let the job deliver.
        raise ValueError(
            f"dry run refused: the router chose the {backend!r} lane, which "
            f"delivers inside the job and cannot hold the file back -- run "
            f"the dry run with backend=native")

    if existing:
        exec_record = existing
        exec_db_id = existing["id"]
        # The pod EXECUTING the row (not the one that pre-created it)
        # says whether it streams the log (2026-10-07).
        _existing_upd: Dict[str, Any] = {
            "execution_backend": backend,
            "log_stream": _run_log_stream_of(_broadcast_fn)}
        # A stored answer stands (read above, before routing -- the router
        # reads it); a row with none gets this run's decision.
        if (_stored_suppression(existing) is None
                and _delivery_suppressed is not None):
            _existing_upd["delivery_suppressed"] = _delivery_suppressed
        # 2026-10-12 -- a PRE-CREATED row (POST /api/feeds/{id}/execute
        # creates it before the seam binds the manual run) carried no
        # business date, so "the previous business date's delivery" (the
        # variance hold's baseline) and every same-day reader found nothing
        # for a Run Now.  The run's own date; never invented.
        if not existing.get("business_date"):
            _pre_bd = _execution_run_business_date(db, feed_config, feed_run_id)
            if _pre_bd is not None:
                _existing_upd["business_date"] = _pre_bd
        db.update_feed_execution(exec_db_id, _existing_upd)
    else:
        exec_data = {
            "feed_config_id": feed_config_id,
            "execution_id": exec_id,
            "status": "pending",
            "execution_backend": backend,
            "trigger_type": trigger_type,
            "triggered_by": triggered_by,
            "started_at": datetime.now(timezone.utc),
            # 2026-10-07 -- does THIS pod stream the run's log lines live?
            # Declared by whoever installed _broadcast_fn (main.py and
            # feed_worker.py: live; the scheduler relay: none); the UI
            # reads it through ``run_log`` instead of waiting forever.
            "log_stream": _run_log_stream_of(_broadcast_fn),
        }
        # 2026-10-07 -- the bound run's BUSINESS date on the execution row.
        # Queue-claimed runs (SOD, backfill, external, on-completion) wrote
        # none, so the All-executions screen showed a backfill of the 6th as
        # "-- no business date" and the receipts' same-day match had nothing
        # to match on.  Only the run's own date; never invented.
        _bound_bd = (feed_config.get("_feed_run") or {}).get("business_date")
        if _bound_bd:
            try:
                exec_data["business_date"] = (
                    _bound_bd if isinstance(_bound_bd, date)
                    and not isinstance(_bound_bd, datetime)
                    else date.fromisoformat(str(_bound_bd)[:10]))
            except ValueError:
                logger.warning(
                    "[feed_engine] Feed %d: bound run business_date %r is "
                    "not a date -- the execution records none",
                    feed_config_id, _bound_bd)
        if _delivery_suppressed is not None:
            exec_data["delivery_suppressed"] = _delivery_suppressed
        exec_record = db.create_feed_execution_atomic(feed_config_id, exec_data)
        if exec_record is None:
            logger.warning(
                "[feed_engine] Feed %d already has a pending/running execution — skipping",
                feed_config_id,
            )
            return {"status": "skipped", "reason": "already_executing",
                    "feed_config_id": feed_config_id}
        exec_db_id = exec_record["id"]
    # 2026-10-12 -- the EXECUTION carries the definition it ran.  The run
    # row's pin is write-once (no mid-run drift), so after a re-run /
    # restatement it still names the FIRST definition; each delivery is its
    # own execution and says its own version (``pin_feed_execution`` existed
    # with no caller -- built, not wired; found by restatement_proof C4).
    if _pin and _pin.get("version_id") is not None:
        try:
            # the version only: an execution's build id is its OWN identity
            # (ux_feed_executions_identity); the run row's would collide on
            # every re-run of the date (found live, restatement_proof C4)
            db.pin_feed_execution(int(exec_db_id), build_id=None,
                                  version_id=_pin.get("version_id"),
                                  git_commit=_pin.get("git_commit"), image_tag=_pin.get("image_tag"))
        except Exception as _pe_exc:
            logger.error("[feed_engine] execution %s: its definition version could not be "
                         "recorded (%s) -- the delivery cannot say which definition it ran",
                         exec_id, _pe_exc)
    # The stored decision, for the lanes that build a payload from
    # feed_config (spark_k8s feed_conf, the Airflow conf).
    feed_config["_delivery_suppressed"] = _delivery_suppressed
    # 2026-10-11 -- what every side is EXPECTED to count, from the
    # dependency ledger, resolved ONCE here (a value computed for a gate and
    # recomputed later disagrees with what the system does).  The native
    # lane judges it after the query stage (below); the Spark job judges
    # the same dict through its mirror of reported_rows_certification.py.
    feed_config["_reported_side_rows"] = _resolve_reported_side_rows(
        db, feed_config, exec_record)

    # Phase 132.27 — re-bind contextvar now that exec_db_id is known.
    # Frontend rows have feed_execution_id (FK numeric); WS events carry
    # exec_db_id so the live-log dialog can match by that.
    _active_exec_ctx.set({
        "exec_id":      exec_id,
        "exec_db_id":   exec_db_id,
        "feed_id":      feed_config_id,
        "feed_run_id":  feed_run_id,
        "triggered_by": triggered_by,
        "audience":     _exec_audience,
    })
    logger.info("[feed_engine] Feed %d execution started: exec_id=%s, backend=%s, triggered_by=%s",
                feed_config_id, exec_id, backend, triggered_by)

    if _lane_refusal is not None:
        # K3 (2026-10-07): the lane the run was PINNED to cannot take it,
        # and a pin is never moved.  Failed here, before any work and
        # before anything is created on the lane, with the lane's reason
        # code and message; the row names the lane that was asked for.
        return _fail_lane_refused(
            db, exec_db_id, exec_record, feed_config, _lane_refusal,
            exec_id=exec_id, feed_run_id=feed_run_id,
            triggered_by=triggered_by)

    # BF-463 (2026-05-19) — pre-flight delivery destination check.
    # User report: feed 2 ran 5 minutes of query + downloaded 23.7MB of S3
    # data + did format conversion + built control file + ATTEMPTED 3
    # retries of local delivery = 420 seconds total, only to discover the
    # destination path was misconfigured.  The path is known at feed
    # start — validate it BEFORE any expensive work.  Same error message
    # as the original post-query failure, just raised 420 seconds earlier.
    _preflight_dest_type = feed_config.get("destination_type", "local")
    _preflight_dest_config = dict(feed_config.get("destination_config") or {})
    if _preflight_dest_type == "local":
        try:
            _preflight_raw_dest = _preflight_dest_config.get("path") or _cfg.output_dir
            _resolve_and_validate_local_dest_dir(_preflight_raw_dest)
        except ValueError as _preflight_err:
            # Persist the failure NOW with stage='preflight_destination_check'
            # so the dashboard chip shows the user what's wrong before
            # they wait 5 minutes for nothing.
            logger.error(
                "[feed_engine] Feed %d pre-flight destination check FAILED: %s",
                feed_config_id, _preflight_err,
            )
            db.update_feed_execution(exec_db_id, {
                "status": "failed",
                "completed_at": datetime.now(timezone.utc),
                "error_message": f"Pre-flight: {_preflight_err}"[:2000],
                "failed_stage": "preflight_destination_check",
            })
            # Sync parent feed_run row too (same pattern as feed_timeout_sweeper).
            try:
                # Edge-case sweep 2026-09-24: THIS execution's run
                # (feed_run_id), not "today's row for the feed" -- a manual
                # Run Now has no run, and failing its preflight used to fail
                # the day's pending SCHEDULED row, which then never ran.
                _feed_run = (db.get_feed_run(int(feed_run_id))
                             if feed_run_id is not None else None)
                if _feed_run and _feed_run.get("status") not in ("completed", "failed", "cancelled"):
                    db.update_feed_run(int(_feed_run["id"]), {
                        "status": "failed",
                        "completed_at": datetime.now(timezone.utc),
                        "error": f"Pre-flight: {_preflight_err}"[:2000],
                    })
            except Exception:
                pass
            _notify("feed_failed", {
                "feed_id": feed_config_id, "execution_id": exec_id,
                "feed_name": feed_config.get("name", ""),
                "error": f"Pre-flight: {_preflight_err}",
                "triggered_by": triggered_by,
            })
            return db.get_feed_execution(exec_db_id) or exec_record

    # ── Disk-space preflight (2026-08-22, design_starburst_140m bug #5) ──
    # Only the backends that WRITE ON POD DISK are gated: native streams
    # its parquet + converted copy locally, spark_connect funnels its
    # result parquet through this pod too.  Airflow's Spark job writes
    # straight to S3 — no pod-disk exposure, no gate.  Fail-open on every
    # uncertainty; refuses only when even the optimistic floor cannot fit
    # (see _disk_space_preflight).
    if backend in ("native", "spark_connect"):
        _disk_err = _disk_space_preflight(
            _cfg.output_dir, estimated_rows,
            cross_source=bool(feed_config.get("secondary_connection_id")),
        )
        if _disk_err:
            logger.error(
                "[feed_engine] Feed %d disk preflight REFUSED: %s",
                feed_config_id, _disk_err,
            )
            db.update_feed_execution(exec_db_id, {
                "status": "failed",
                "completed_at": datetime.now(timezone.utc),
                "error_message": f"Pre-flight: {_disk_err}"[:2000],
                "failed_stage": "preflight_disk_space",
            })
            try:
                # Edge-case sweep 2026-09-24: this execution's run, or none.
                _feed_run = (db.get_feed_run(int(feed_run_id))
                             if feed_run_id is not None else None)
                if _feed_run and _feed_run.get("status") not in (
                        "completed", "failed", "cancelled"):
                    db.update_feed_run(int(_feed_run["id"]), {
                        "status": "failed",
                        "completed_at": datetime.now(timezone.utc),
                        "error": f"Pre-flight: {_disk_err}"[:2000],
                    })
            except Exception as _sync_exc:
                # The execution row is already marked failed above, so the
                # refusal is not lost — but a parent feed_run left RUNNING
                # is what a dashboard shows as "still going", forever.
                logger.warning(
                    "[feed_engine] Feed %d: disk-preflight refusal recorded on "
                    "the execution, but syncing the parent feed_run failed "
                    "(%s) — the run row may show RUNNING until the sweeper "
                    "reaps it.", feed_config_id, _sync_exc)
            _notify("feed_failed", {
                "feed_id": feed_config_id, "execution_id": exec_id,
                "feed_name": feed_config.get("name", ""),
                "error": f"Pre-flight: {_disk_err}",
                "triggered_by": triggered_by,
            })
            return db.get_feed_execution(exec_db_id) or exec_record

    start_time = time.time()
    parquet_path = None
    _temp_files = []  # Track temp files for cleanup
    # BF-415 — register the cancellation event for this execution so the
    # /cancel API endpoint can signal it on this pod.  Always cleared in
    # the finally below.
    _cancel_ev = _register_cancel_event(exec_id)

    # Phase 145.3 — stash exec_id on feed_config so deep-stack helpers
    # (multi_worker_dispatcher) can hand the cancel event to subprocess
    # workers.  Previously _execute_duckdb_query used feed_config.id as
    # the cancel key, which never matched _cancel_events keyed by exec_id.
    feed_config["_exec_id"] = exec_id
    feed_config["_cancel_event"] = _cancel_ev
    if reuse_side:
        feed_config["_reuse_side"] = dict(reuse_side)
    # 2026-08-17 (F5) — also stash the numeric feed_executions.id so deep
    # helpers (_execute_duckdb_query's mid-stream cancel poll) can check the
    # DB row's status='cancelled' via _check_cancelled.  Without it, a feed
    # cancelled through the API on ANOTHER pod kept streaming to completion
    # because the poll only looked at feed_configs.is_active.
    feed_config["_exec_db_id"] = exec_db_id

    def _cancelled() -> bool:
        # Phase 131 deep-dive #9 — also treat feed deactivation as a
        # cancel signal.  If an admin sets is_active=False mid-run, the
        # row stops at the next stage checkpoint.  Cheap DB read; only
        # checked at major stage transitions (not inside tight loops).
        if _check_cancelled(exec_id, exec_db_id, db=db):
            return True
        try:
            fc = db.get_feed_config(feed_config_id)
            if fc and not fc.get("is_active"):
                logger.info(
                    "[feed_engine] Feed %d deactivated mid-run; aborting at stage=%s",
                    feed_config_id, current_stage,
                )
                return True
        except Exception:
            pass
        return False

    # Phase 130 hotfix-13 audit fix #6: track which stage we're in so the
    # FAILED log line can pinpoint where the error happened (matches the
    # CBQ execution_log pattern where each stage is timestamped).
    stage_timings: Dict[str, float] = {}
    # 2026-10-12 -- THE UPSTREAM CONTRACT (core/feed/upstream_contract.py),
    # resolved ONCE with the counts (_resolve_reported_side_rows): on the execution's record for the
    # board, the side re-run and supersession; on feed_config for the query's
    # message tokens ({version}) on every lane.
    from core.feed import upstream_contract as _uc_rec
    stage_timings[_uc_rec.RECORD_KEY] = _uc_rec.public(feed_config.get("_upstream_contract"))
    # the size the lane was chosen by, and where it came from (run_size)
    if feed_config.get("_run_size"):
        stage_timings["run_size"] = feed_config["_run_size"]
    current_stage = "init"

    # ── The STEP MODEL (2026-09-05, core/feed/pipeline) ─────────────
    # This engine keeps doing exactly what it did.  What changes is
    # that each stage boundary is also RECORDED as a row in
    # feed_run_steps -- with real wall-clock boundaries, the pod that
    # ran it, the row count and the error -- instead of only a
    # duration in the stage_timings dict.  ``stage_timings`` is
    # deliberately still written: it feeds the completeness verdict,
    # the perf capture and every existing reader, and replacing a
    # working producer at the same time as adding a new one is how a
    # migration becomes an incident.
    #
    # ``_steps`` stays None when planning is unavailable; both helpers
    # below are no-ops then, so a feed runs unchanged whether or not
    # the step model can answer.
    _steps = None

    def _steps_publish(**artifacts) -> None:
        """Tell the recorder what the run has produced so far."""
        if _steps is not None:
            _steps.publish(**artifacts)

    async def _steps_after(name: str) -> None:
        """Run any declared steps whose inputs have now arrived.

        A step that REFUSED or FAILED raises StepExecutionHalted out
        of here, and it must: a quality gate that refused has to stop
        the feed, or it is a cap wearing a gate's name.  The stage
        label is repointed at the step first so ``failed_stage`` names
        the STEP rather than the engine stage it happened to follow.
        """
        nonlocal current_stage
        if _steps is None:
            return
        try:
            await _steps.after_stage(name)
        except Exception as _step_exc:
            _alias = getattr(_step_exc, "alias", None)
            if _alias:
                current_stage = f"step:{_alias}"
            raise

    # Bound HERE, not where it is taken: the failure handler at the
    # bottom abandons this allocation, and a run that dies before the
    # filename stage would otherwise hit an unbound name INSIDE that
    # handler's own except — which would log "could not be abandoned"
    # for a number that was never taken.  A name typo'd inside a
    # fail-open handler is invisible by construction; this one is simply
    # not allowed to be unbound.
    _seq_alloc = None

    # 2026-09-15 -- what delivery ACTUALLY did, for the failure handler.
    # A run that fails AFTER the file reached its destination used to be
    # recorded with file_size_bytes=0 and destination_path=null: the
    # record said nothing was delivered when something WAS, and an
    # operator re-triggering it would ship the file twice.  Bound here
    # so the handler can always read it (an unbound name inside an
    # except is invisible until it fires).
    _delivered_state: Dict[str, Any] = {"uri": "", "path": None, "at": None}
    # 2026-10-07 -- the file this run PRODUCED (the final, post-compress /
    # post-encrypt bytes on the shared output volume), recorded on the
    # execution as ``artifact_path`` whether or not it was delivered.  A
    # backfill without delivery used to complete with no path anywhere:
    # the file sat on the volume and the execution's Download said 404.
    # Bound here for the same reason as _delivered_state: the failure
    # handler records it too (a hop retry sends exactly these bytes).
    _produced_state: Dict[str, Any] = {"path": None}

    def _produced_artifact() -> Optional[str]:
        """The produced file's path when it is on disk, else None."""
        p = _produced_state.get("path")
        try:
            return str(p) if p and Path(str(p)).is_file() else None
        except OSError:
            return None

    def _delivered_facts() -> Optional[Dict[str, Any]]:
        """None when nothing reached a destination; else the URI, the
        size of the artifact that went, and when.  Size is None -- not 0
        -- when the artifact cannot be measured: unknown is not empty."""
        uri = _delivered_state.get("uri")
        if not uri:
            return None
        size = None
        try:
            if _delivered_state.get("path"):
                size = Path(str(_delivered_state["path"])).stat().st_size
        except OSError:
            size = None
        return {"uri": uri, "size": size, "at": _delivered_state.get("at")}

    # Round 16: BQB-parity per-execution log + stage capture.
    # Helpers live in ``core/feed_perf.py`` — single-purpose, easy to
    # debug, no impact on BQB/CQB which use the same underlying
    # execution_log_buffer + execution_stage modules from a different
    # call site.
    from core.feed_perf import (
        begin_log_capture as _begin_log_capture,
        end_log_capture as _end_log_capture_helper,
        capture_perf_metadata as _capture_perf_metadata_helper,
    )
    _log_capture_ctx = _begin_log_capture(exec_id)

    def _capture_perf_metadata() -> dict:
        return _capture_perf_metadata_helper(exec_id)

    def _end_log_capture() -> None:
        nonlocal _log_capture_ctx
        _end_log_capture_helper(_log_capture_ctx, exec_id)
        _log_capture_ctx = None

    def _enter_stage(name: str) -> float:
        nonlocal current_stage
        current_stage = name
        # Round 17: richer feed_progress payload — adds elapsed_seconds
        # so the dashboard can render a live ticker without a separate
        # endpoint, and stages_done counter so the chip can show a
        # step count out of the canonical stage list.
        try:
            _elapsed = round(time.time() - start_time, 1)
            # BF-462 (2026-05-19) — every progress broadcast MUST carry
            # ``triggered_by`` so main._feed_ws_broadcast can route it via
            # ws_manager.broadcast_to_user(username, ...).  Without this,
            # every feed_progress event was silently dropped at the bridge
            # (only feed_completed / feed_failed / feed_cancelled survived
            # because those payloads already had it).  Symptom: dashboard
            # showed status flip from pending→completed but NO live stage
            # chip, elapsed counter, or backend label during the run.
            _notify("feed_progress", {
                "feed_id": feed_config_id, "execution_id": exec_id,
                "feed_run_id": feed_run_id,
                "stage": name, "backend": backend,
                "elapsed_seconds": _elapsed,
                "stages_done": len(stage_timings),
                "triggered_by": triggered_by,
            })
        except Exception:
            pass  # WS is best-effort; never block execution
        try:
            from core.execution_stage import set_stage as _set_stage
            _set_stage(exec_id, name)
        except Exception:
            pass
        # The per-step row opens HERE, so started_at is the real
        # wall clock.  steps_view had to return started_at: null
        # for every step because durations have no boundaries.
        if _steps is not None:
            _steps.enter(name)
        return time.time()

    def _exit_stage(name: str, start: float) -> None:
        _elapsed = round(time.time() - start, 3)
        stage_timings[name] = _elapsed
        if _steps is not None:
            _steps.exit(name, _elapsed)

    def _task_identity(step_name=None) -> str:
        """FR-ID-06 — THE fully-qualified task identity
        (``<feed>/<business_date>/<build>/<step>``), the SAME string the
        run screen shows (steps_view) so an operator moves between the
        log and the console without translating.  Missing pieces render
        as ``-``, never invented (core/feed/step_identity.py)."""
        try:
            from core.feed.step_identity import qualified_task_id
            _fr_row = feed_config.get("_feed_run") or {}
            return qualified_task_id(
                feed_config.get("name") or f"feed-{feed_config_id}",
                _fr_row.get("business_date"),
                _fr_row.get("build_id") or exec_id,
                step_name)
        except Exception:              # identity must never fail a log line
            return f"feed-{feed_config_id}/-/{exec_id}" + (
                f"/{step_name}" if step_name else "")

    try:
        # Plan the steps BEFORE any work.  A feed mapped to a flow
        # whose plan refuses fails HERE, having spent only the
        # admission -- OG run_id=969000 died at execute time on a
        # route that could never have worked, after burning its retry
        # budget getting there.  A feed mapped to NO flow (every feed
        # that exists today) never refuses: it plans the engine spine,
        # records it, and runs unchanged.
        # The import is its OWN try.  Putting it inside the one below
        # would leave _StepPlanRefused unbound when the import is what
        # failed, and `except <unbound>` raises NameError from inside
        # the handler -- a fail-open path that fails closed, invisibly.
        try:
            from core.feed.step_model.recorder import (
                StepPlanRefused as _StepPlanRefused,
                build_recorder as _build_step_recorder,
            )
        except Exception as _steps_import_exc:
            _StepPlanRefused = _NeverRaised
            _build_step_recorder = None
            logger.error(
                "[feed_engine] the step model could not be imported "
                "(%s: %s) -- runs continue with no step timeline",
                type(_steps_import_exc).__name__, _steps_import_exc)
        try:
            if _build_step_recorder is None:
                raise RuntimeError("step model unavailable")
            _steps = _build_step_recorder(
                db, feed_config=feed_config,
                feed_run=feed_config.get("_feed_run"),
                execution_id=exec_id)
            if _steps.degraded:
                logger.error(
                    "[feed_engine] Feed %d [%s] step timeline "
                    "DEGRADED: %s", feed_config_id, exec_id,
                    _steps.degraded)
        except _StepPlanRefused:
            raise
        except Exception as _steps_exc:
            # Bookkeeping must never be the reason a file is not
            # delivered.  Loud, and then out of the way.
            _steps = None
            logger.error(
                "[feed_engine] Feed %d [%s] step recorder unavailable "
                "(%s: %s) -- this run will have no step timeline; the "
                "feed itself is unaffected",
                feed_config_id, exec_id, type(_steps_exc).__name__,
                _steps_exc, exc_info=True)
        # 3. Update status to running
        if _cancelled():
            raise _FeedCancelled("cancelled before query started")
        _t_run = _enter_stage("status_running")
        db.update_feed_execution(exec_db_id, {"status": "running"})
        # ── §9.2 (2026-09-02) — declare the partition list BEFORE any
        # work.  A refusal here (empty list, partition explosion) costs
        # only the admission; the same refusal after the extract costs
        # the extract.  Feeds that declare no shape are untouched.
        _partition_declaration = None
        _partition_comparison = None
        # ── §4.2 (2026-09-02) — fan-out execution state.  None means this
        # run took the single-file path (the overwhelming majority); a dict
        # means one child ran per declared partition and the dict carries
        # the certified partition set the feed-level claim (§9.2) is made
        # against.  Consulted by the verdict builder, the partial-delivery
        # gate, and the parent-status sync below.
        _fanout_state = None
        try:
            _partition_declaration, _partition_comparison = (
                declare_run_partitions(
                    db, feed_config, feed_run_id=feed_run_id,
                    business_date=_effective_business_date(feed_config, db)))
            if _partition_declaration is not None:
                stage_timings["partition_declaration"] = (
                    _partition_declaration.to_dict())
                if _partition_comparison is not None:
                    stage_timings["partition_comparison"] = (
                        _partition_comparison.to_dict())
        except ImportError:
            pass          # older build without the shape modules

        # ── §9.3 (2026-09-02) — a DECLARED-EMPTY day produces NOTHING ──
        # The author declared a partitioned shape and declared that an empty
        # list is a legitimate business outcome (on_empty=skip).  Falling
        # through here would run the BASE query with NO partition filter and
        # ship ONE FILE CONTAINING EVERY ENTITY under the feed's real
        # filename -- the wrong-file class this platform exists to kill, and
        # the exact inverse of what the author asked for.
        #
        # So: no data file, no delivery, and a status that says WHICH kind of
        # nothing this was.  "Zero partitions were declared, and the author
        # said that is fine" and "the run produced nothing" must never look
        # alike -- the second is an incident and the first is a Tuesday.
        # The declaration is already persisted above, so the empty day is
        # evidence rather than an absence.
        if (_partition_declaration is not None
                and getattr(_partition_declaration, "skipped", False)):
            logger.info(
                "[feed_engine] Feed %d [%s] declared ZERO partitions for %s "
                "and its shape declares on_empty=skip — producing NO file "
                "and delivering NOTHING. Running the base query unfiltered "
                "would have shipped every entity in one file.",
                feed_config_id, exec_id,
                _effective_business_date(feed_config, db))
            _skip_payload = {
                "status": "skipped",
                "reason": "empty_partition_list",
                "feed_config_id": feed_config_id,
                "execution_id": exec_id,
                "partition_declaration": _partition_declaration.to_dict(),
            }
            try:
                db.update_feed_execution(exec_db_id, {
                    "status": "skipped",
                    "completed_at": datetime.now(timezone.utc),
                    "error_message": None,
                    "stage_timings": stage_timings,
                })
            except Exception as _sk_exc:      # accounting must not fail a run
                logger.error(
                    "[feed_engine] Feed %d [%s] declared-empty day could not "
                    "be recorded on the execution row (%s) — the run still "
                    "produced nothing, but the RECORD of why is missing",
                    feed_config_id, exec_id, _sk_exc)
            if feed_run_id is not None:
                try:
                    db.update_feed_run(feed_run_id, {
                        "status": "skipped",
                        "action_decision": "SKIP",
                        "action_reason": "empty_partition_list",
                        "completed_at": datetime.now(timezone.utc),
                    })
                except Exception as _sk_exc:
                    logger.error(
                        "[feed_engine] Feed %d [%s] declared-empty day could "
                        "not be recorded on the run row: %s",
                        feed_config_id, exec_id, _sk_exc)
            return _skip_payload

        _exit_stage("status_running", _t_run)
        await _steps_after("status_running")
        logger.info("[feed_engine] Feed %d [%s] status -> running", feed_config_id, exec_id)
        # BF-263: progress broadcast — user log showed feeds running 10+ min
        # with zero feedback.  Notify each major stage so the UI can render
        # a meaningful progress strip.
        _notify("feed_progress", {
            "feed_id": feed_config_id, "execution_id": exec_id,
            "stage": "query_executing", "backend": backend,
            "triggered_by": triggered_by,  # BF-462 — route per-user
        })

        # 4. Dispatch to backend
        # ── §4.2 (2026-09-02) — fan-out is wired for the NATIVE lane only.
        # A declared shape on another backend still declares / records /
        # compares above, but executes single-file exactly as before —
        # LOUDLY, because a feed whose author declared many files silently
        # producing one is the §9.3 trap ("an ignored shape silently
        # produces a single file where the author declared many").
        # Airflow / Spark fan-out belongs to those lanes' workstreams.
        if (_partition_declaration is not None
                and _partition_declaration.identities
                and backend in ("airflow", "spark_k8s", "spark_connect")):
            logger.warning(
                "[feed_engine] Feed %d [%s] declares %d partition(s) but "
                "runs on backend %r — fan-out is only wired for the native "
                "backend, so this run produces a SINGLE file and can make "
                "no feed-level completeness claim (FR-CMP-05)",
                feed_config_id, exec_id, _partition_declaration.count,
                backend)
            stage_timings["fanout_not_wired_backend"] = backend
        _t_query = _enter_stage(f"query_{backend}")
        _sk_row = None
        if backend == "spark_k8s":
            # 2026-10-07 (D3) -- the submit runs FIRST, so a cluster that
            # turns out to be unreachable can still hand a SIZE-ROUTED run
            # to the native branch below (nothing of it was created).  A
            # pinned / overridden run, or one whose job may already exist on
            # the cluster, fails with a plain reason instead.
            from core.spark_k8s.errors import (
                SparkK8sUnavailable as _SkUnavailable,
                SparkK8sUnreachable as _SkUnreachable,
            )
            try:
                _sk_row = await _execute_spark_k8s(
                    feed_config, exec_record, db=db, stage_timings=stage_timings,
                    # 2026-10-18 -- at submit the steps the JOB performs are
                    # handed to it (running on the job, never "skipped")
                    on_submitted=(lambda _name, _lane=backend: _steps.hand_to_job(_lane, _name))
                    if _steps is not None else None)
            except (_SkUnreachable, _SkUnavailable) as _sk_down:
                choice = _spark_k8s_unreachable_to_native(
                    choice, _sk_down, db=db, exec_db_id=exec_db_id,
                    stage_timings=stage_timings,
                    estimated_rows=estimated_rows,
                    cross_source=bool(
                        feed_config.get("secondary_connection_id")))
                # The spark attempt is recorded as what it was -- a failed
                # attempt of the query step, with the reason -- and the
                # native query opens the next attempt.
                stage_timings[f"query_{backend}"] = round(
                    time.time() - _t_query, 3)
                if _steps is not None:
                    _steps.fail(f"query_{backend}", choice.reason)
                backend = choice.backend
                stage_timings.pop("fanout_not_wired_backend", None)
                _t_query = _enter_stage(f"query_{backend}")
        if backend == "airflow":
            # E-H3: give _execute_airflow a hook to free the queue-worker
            # concurrency slot once the DAG is triggered, so a long-running
            # DAG's idle poll-wait doesn't pin a native slot.  Only meaningful
            # when THIS run was dispatched by the shared queue worker
            # (feed_run_id set + worker constructed); a no-op otherwise.
            def _release_airflow_slot(_run_id=feed_run_id):
                try:
                    from core.feed.queue_worker import _shared_worker
                    if _shared_worker is not None and _run_id is not None:
                        _shared_worker._inflight_run_ids.discard(int(_run_id))
                except Exception:
                    pass
            # 2026-10-08 -- ONE Airflow road: the engine DISPATCHES the
            # execution to its factory DAG, the DAG submits it through
            # POST /spark-submit (the ONE builder + submitter), and the row
            # comes back here terminal, exactly as from _execute_spark_k8s.
            # A DAG that failed at /spark-submit with a recorded 503 is the
            # spark_k8s lane's submit-time question, answered by the SAME
            # rule (K3: auto + nothing created -> native with the reason;
            # pinned -> fails with the code).
            try:
                _sk_row = await _execute_airflow(
                    feed_config, exec_record,
                    slot_release=_release_airflow_slot, db=db,
                    stage_timings=stage_timings,
                    on_submitted=(lambda _name, _lane=backend: _steps.hand_to_job(_lane, _name))
                    if _steps is not None else None,
                )
            except _AirflowSubmitRefused as _af_down:
                choice = _spark_k8s_unreachable_to_native(
                    choice, _af_down.cause, db=db, exec_db_id=exec_db_id,
                    stage_timings=stage_timings,
                    estimated_rows=estimated_rows,
                    cross_source=bool(
                        feed_config.get("secondary_connection_id")))
                stage_timings[f"query_{backend}"] = round(
                    time.time() - _t_query, 3)
                if _steps is not None:
                    _steps.fail(f"query_{backend}", choice.reason)
                backend = choice.backend
                stage_timings.pop("fanout_not_wired_backend", None)
                _t_query = _enter_stage(f"query_{backend}")
        if backend in ("airflow", "spark_k8s"):
            # 2026-08-22 — QueryStudio-owned SparkApplication (pod-per-job).
            # DETACHED compute: generic_feed.py converts + delivers ITSELF
            # and reports through the signed webhook; the spark_k8s
            # reconciler drives every non-callback failure to a terminal
            # state.  Nothing local remains to convert or deliver, so this
            # branch finishes the run bookkeeping and RETURNS — the
            # conversion/delivery pipeline below is for backends that
            # produce a local parquet.  The submit + await already ran
            # above (``_sk_row``), so an unreachable cluster could still
            # move a size-routed run to native.  Since 2026-10-08 the
            # airflow lane lands here too: its DAG submitted the same
            # workload, and the row it awaited is the same row.
            _exit_stage(f"query_{backend}", _t_query)
            duration = round(time.time() - start_time, 2)
            row_count = _sk_row.get("total_rows") or 0
            # The heavy lane returns here, so this is its ONLY chance
            # to publish what it produced and run the steps that wait
            # on it.  A lane that gets forgotten is the defect class
            # this feed path keeps producing.
            _steps_publish(row_count=row_count)
            await _steps_after(f"query_{backend}")
            # FR-ID-04 (2026-09-03) — the Spark lane used to write NO
            # stage_timings at all (this branch returns before the shared
            # finalisation), so the steps view had nothing to show and
            # "which step usually fails" was unanswerable here.  Persist
            # the engine-side stages (status_running, spark_submit,
            # spark_await, query_spark_k8s) merged OVER whatever the
            # webhook already put on the row — never clobbering it.
            try:
                stage_timings["row_count"] = row_count
                # 2026-10-03 -- merged over a FRESH read, not the row the
                # await returned: the webhook-side delivery records its
                # chain verdict (stage_timings.delivery_chain) AFTER the
                # callback closed the row, i.e. possibly after _sk_row was
                # read, and merging into the stale copy would erase it.
                _sk_fresh = db.get_feed_execution(exec_db_id) or _sk_row
                _sk_merged = dict(_sk_fresh.get("stage_timings") or {})
                _sk_merged.update(stage_timings)
                # 2026-09-20 -- the lane computed and LOGGED its duration
                # ("COMPLETED via spark_k8s -- N rows, 30.12s") and never
                # stamped it on the row; the webhook closes the row without
                # one, so every spark_k8s execution showed a blank where the
                # native row shows 6.75.  Same write, one more field.
                # 2026-09-21 -- and the ROUTING DECISION, for the same
                # reason.  ``files_metadata.backend_choice`` was added on
                # 2026-08-22 so "why did my big feed go to spark_k8s" is
                # answerable from the execution record; it is attached by
                # the shared finalisation far below, which THIS branch
                # returns before ever reaching.  So every spark_k8s
                # execution ever run carried no backend_choice at all --
                # absent on the only lane anyone asks the question about.
                # Merged over whatever the webhook already wrote, never
                # clobbering it, exactly as the timings above are.
                _sk_write = {"stage_timings": _sk_merged,
                             "duration_seconds": duration}
                # Its OWN try: the routing decision is an ADDITION, and
                # an addition that can take the duration write down with
                # it is a worse bug than the one it fixes.  (It did:
                # widening the block below made a fake BackendChoice in
                # an existing test drop duration_seconds entirely.)
                try:
                    _sk_fm = dict((db.get_feed_execution(exec_db_id) or {})
                                  .get("files_metadata") or {})
                    _sk_fm["backend_choice"] = choice.to_dict()
                    _sk_write["files_metadata"] = _sk_fm
                except Exception as _bc_exc:
                    logger.warning(
                        "[feed_engine] spark_k8s backend_choice could not "
                        "be attached for %s: %s", exec_id, _bc_exc)
                db.update_feed_execution(exec_db_id, _sk_write)
            except Exception as _st_exc:   # accounting must not fail a run
                logger.warning(
                    "[feed_engine] spark_k8s stage timings could not be "
                    "persisted for %s: %s", exec_id, _st_exc)
            # The feed_run row is what /feeds/today shows.  The native
            # lane syncs total_rows / output_path onto it (BF-FEED-RUN-
            # COUNT); this lane synced status only, so a 500,000-row
            # SparkApplication read "0 records" on the dashboard while
            # its execution row said 500,000 (2026-09-14, first SOD run
            # through spark_k8s).  Same numbers on both rows.
            _sync_feed_run({
                "status": "completed",
                "completed_at": datetime.now(timezone.utc),
                "total_rows": int(row_count or 0),
                "output_path": _sk_row.get("destination_path") or None,
            })
            _end_log_capture()
            db.increment_feed_run_count(feed_config_id)
            _sk_update = {"last_execution_id": exec_db_id}
            # No try/except: the isinstance guard already makes int() total,
            # so the handler could never fire — it only cost a slot against
            # the silent-exception cap.  `bool` is excluded explicitly
            # because isinstance(True, int) is True in Python, and a bool
            # arriving here would persist last_row_count=1 as though it were
            # a real count.
            if isinstance(row_count, int) and not isinstance(row_count, bool)                     and row_count > 0:
                _sk_update["last_row_count"] = int(row_count)
            db.update_feed_config(feed_config_id, _sk_update)
            _notify("feed_completed", {
                "feed_id": feed_config_id,
                "execution_id": exec_id,
                "feed_name": feed_config.get("name", ""),
                "rows": row_count,
                "destination": _sk_row.get("destination_path") or "",
                "duration_seconds": duration,
                "triggered_by": triggered_by,
            })
            _send_notifications(feed_config, "success", {
                "feed_name": feed_config.get("name", ""), "rows": row_count,
                "destination": _sk_row.get("destination_path") or "",
                "duration": duration,
            }, db=db, exec_db_id=exec_db_id, stage_timings=stage_timings)
            logger.info(
                "[feed_engine] Feed %d [%s] COMPLETED via %s — "
                "%s rows, %.2fs, dest=%s | task=%s",
                feed_config_id, exec_id, backend, row_count, duration,
                _sk_row.get("destination_path") or "(reported by webhook)",
                _task_identity(),
            )
            return db.get_feed_execution(exec_db_id) or _sk_row
        elif backend == "spark_connect":
            # Phase 131 deep-dive #13 (round 9) — medium-feed dispatch.
            # Spark reads S3 directly (in-VPC) via gRPC, returns Arrow
            # batches.  No NFS pre-download, no Airflow DAG overhead.
            parquet_path = await _execute_spark_connect(feed_config, exec_record, db=db)
        else:
            if (_partition_declaration is not None
                    and _partition_declaration.identities):
                # ── §4.2 FAN-OUT (2026-09-02) — the feed DECLARED a
                # partition list, so it runs as one child per declared
                # partition: child rows first (FR-RUN-05), then the
                # claim/skip/failure-isolation loop in child_execution,
                # then a parts manifest holding the REAL rows and bytes
                # of every certified part.  The parent's status is
                # DERIVED inside (recompute_parent) — never written by
                # this function.
                parquet_path, _fanout_state = await _execute_native_fanout(
                    feed_config, exec_record, db=db,
                    declaration=_partition_declaration,
                    feed_run_id=feed_run_id,
                    business_date=_effective_business_date(feed_config, db),
                    created_by=triggered_by)
                stage_timings["fanout"] = _fanout_state.get("stats") or {}
            else:
                parquet_path = await _execute_native(feed_config, exec_record, db=db)
        if parquet_path and _fanout_state is None:
            # A fan-out parts dir is the run's DURABLE build — "re-run
            # file 738" (§4.3) must find the other parts still on disk,
            # and a re-delivery consumes the certified manifest of a
            # named build — so it is never registered as a temp file.
            _temp_files.append(parquet_path)
        _steps_publish(extract=parquet_path)
        _exit_stage(f"query_{backend}", _t_query)
        await _steps_after(f"query_{backend}")
        # 2026-10-11 -- per-side REPORTED-ROWS certification, before any
        # output exists: each side the dependencies vouch for must count
        # what the upstream's message said (ROW_COUNT).  A mismatch, a
        # count the message never carried, or a side this lane could not
        # count FAILS the run here with the numbers; a side released by a
        # skip is recorded uncertified and proceeds.  The record lands in
        # stage_timings (persisted on the failure path too).
        _rr_record = _certify_reported_rows_native(feed_config, parquet_path)
        if _rr_record is not None:
            stage_timings[_RR_RECORD_KEY] = _rr_record
            _rr_failure = _rr_failure_sentence(_rr_record)
            if _rr_failure:
                current_stage = "certify_reported_rows"
                raise ValueError(_rr_failure)
        query_elapsed = round(time.time() - start_time, 2)
        # Try to capture row count + file size for the CBQ-parity summary
        try:
            import os
            if parquet_path and os.path.isfile(parquet_path):
                stage_timings["query_output_bytes"] = os.path.getsize(parquet_path)
            elif parquet_path and os.path.isdir(parquet_path):
                # Parts directory (write ladder) — sum the part files.
                stage_timings["query_output_bytes"] = sum(
                    e.stat().st_size for e in os.scandir(parquet_path)
                    if e.is_file())
        except Exception:
            pass
        logger.info("[feed_engine] Feed %d [%s] query complete in %.2fs -> %s",
                    feed_config_id, exec_id, query_elapsed, parquet_path)
        # 2026-10-12 -- re-run of ONLY the failed side: what was reused (or
        # why the kept rows were refused) is on the execution's record
        from core.feed import side_resume as _sr_rec
        if feed_config.get("_reused_side"):
            stage_timings[_sr_rec.REUSED_KEY] = dict(feed_config["_reused_side"])
        if feed_config.get("_reuse_refused"):
            stage_timings[_sr_rec.REUSE_REFUSED_KEY] = str(feed_config["_reuse_refused"])
        # BF-415 — cancel checkpoint between major stages.
        if _cancelled():
            raise _FeedCancelled("cancelled after query")

        # ── §9.2 / FR-CMP-05 (2026-09-02) — A PARTIAL FAN-OUT NEVER SHIPS.
        # If any declared partition lacks a certified part, the set
        # comparison failed and the bytes on disk are a SUBSET of the feed
        # wearing the feed's real filename — the one artifact this platform
        # exists to never deliver.  Delivery is refused in EVERY gate mode:
        # ``completeness_gate`` governs what the verdict does to the run's
        # STATUS (record today, enforce later — a status can be corrected
        # retroactively), but sending a partial file to a counterparty is
        # an irreversible external action, so it is gated on the set
        # comparison itself, not on the gate knob.  The verdict is still
        # built and RECORDED (FR-CMP-01: never computed-then-discarded),
        # the parent feed_runs status stays exactly what recompute_parent
        # DERIVED from the children, and the completed parts are kept on
        # disk so "re-run file 738" completes the build without touching
        # its siblings.
        if _fanout_state is not None and not _fanout_state.get("complete"):
            duration = round(time.time() - start_time, 2)
            _pv = _fanout_state.get("parent_verdict")
            _reason = (getattr(_pv, "reason", "") or
                       "fan-out incomplete — declared set not certified")
            _cmp_verdict = _build_completeness_verdict(
                feed_config,
                row_count=int(_fanout_state.get("total_rows") or 0),
                stage_timings=stage_timings,
                gate_assertion=(feed_config.get("_gate_assertion")
                                if isinstance(feed_config, dict) else None),
                partition_declaration=_partition_declaration,
                certified_partitions=_fanout_state.get("certified") or [])
            _feed_fm = _capture_perf_metadata()
            if _cmp_verdict is not None:
                _feed_fm["completeness_verdict"] = _cmp_verdict.to_dict()
            _final_status = resolve_final_status(
                _cmp_verdict, _cfg.completeness_gate if _cfg else "record",
                feed_config_id=feed_config_id, exec_id=exec_id)
            stage_timings["fanout_delivery_refused"] = _reason[:500]
            logger.error(
                "[feed_engine] Feed %d [%s] PARTIAL fan-out — delivery "
                "REFUSED in every gate mode: %s.  %d of %d declared "
                "partition(s) certified.  Re-run the failed children; the "
                "completed parts are kept and the parent status re-derives.",
                feed_config_id, exec_id, _reason,
                len(_fanout_state.get("certified") or []),
                _partition_declaration.count)
            _error_msg = (f"Partial fan-out — delivery refused: "
                          f"{_reason}")[:2000]
            _finalize_execution_row(db, exec_db_id, {
                "status": _final_status,
                "completed_at": datetime.now(timezone.utc),
                "error_message": _error_msg,
                "duration_seconds": duration,
                "stage_timings": dict(stage_timings),
                "files_metadata": _feed_fm,
            })
            _end_log_capture()
            # NO _sync_feed_run here: the parent feed_runs row already
            # carries the status recompute_parent DERIVED from the
            # children.  A direct write would be exactly the
            # directly-written parent that leaves a re-run of one child
            # against a permanently failed parent (FR-RUN-04).
            _notify("feed_failed", {
                "feed_id": feed_config_id,
                "execution_id": exec_id,
                "feed_name": feed_config.get("name", ""),
                "error": _error_msg,
                "triggered_by": triggered_by,
            })
            _send_notifications(feed_config, "failure", {
                "feed_name": feed_config.get("name", ""),
                "error": _error_msg, "duration": duration,
            }, db=db, exec_db_id=exec_db_id, stage_timings=stage_timings)
            _cleanup_temp_files(_temp_files)
            return db.get_feed_execution(exec_db_id) or exec_record

        # 5. Convert format + deliver
        output_format = feed_config.get("output_format") or _cfg.default_output_format
        feed_name = feed_config.get("name", "feed")
        template = feed_config.get("output_filename_template") or _cfg.filename_template
        # Phase 130/2 — resolve calendar (DB-driven) so enterprise tokens
        # like ${COB_PREV_EOM(YYYYMMDD)} render correctly.  None when the
        # feed has no calendar_name set — legacy templates don't need it.
        _calendar = _resolve_calendar(feed_config)
        _biz_date = _effective_business_date(feed_config, db)
        # ── FR-ART-07 (wired 2026-09-03) — GAPLESS FILE SEQUENCE ──────
        # Allocated only when the template actually asks for one:
        # taking a number is durable state that is CONSUMED, so a
        # speculative allocation on every feed would turn every
        # counterparty's sequence into holes.  The allocation is
        # committed after delivery succeeds and abandoned, with the
        # reason, when the run fails — an unexplained gap is the one
        # outcome FR-ART-07 exists to prevent, so the number stays in
        # the ledger either way.
        try:
            from core.feed.pipeline import template_uses_sequence
            if template_uses_sequence(template):
                from core.feed.sequence import SequenceAllocator
                _seq_alloc = SequenceAllocator(db).allocate(
                    feed_config_id,
                    business_date=_biz_date,
                    run_id=exec_id,
                    scope_key=str(feed_config.get("sequence_scope") or ""),
                    redelivery=str(feed_config.get("redelivery_naming")
                                   or "reuse"))
                logger.info(
                    "[feed_engine] feed %s took sequence number %s "
                    "(alloc %s, %s)", feed_config_id,
                    _seq_alloc.formatted(), _seq_alloc.id, _seq_alloc.status)
        except Exception as _seq_exc:
            # FAIL CLOSED.  Every other pre-flight here degrades, but a
            # sequenced feed whose number could not be taken must not
            # ship: the alternatives are a duplicate number (two files,
            # one identity) or a placeholder, and the counterparty's
            # parser cannot tell either from a real one.
            raise RuntimeError(
                f"feed {feed_config_id} declares a ${{SEQ}} filename but "
                f"no sequence number could be allocated ({_seq_exc}) — "
                f"refusing to deliver rather than reuse or invent one"
            ) from _seq_exc
        filename = _build_filename(
            template, feed_name, output_format,
            feed_config.get("output_options"),
            feed_config=feed_config,
            calendar=_calendar,
            run_id=exec_db_id,
            business_date=_biz_date,
            sequence_value=(_seq_alloc.seq_value if _seq_alloc else None),
        )

        output_dir = Path(_cfg.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / filename)

        options = feed_config.get("output_options") or {}
        convert_start = time.time()
        # BF-263: progress broadcast — query done, format conversion starts
        _notify("feed_progress", {
            "feed_id": feed_config_id, "execution_id": exec_id,
            "stage": "format_converting", "output_format": output_format,
            "query_elapsed_seconds": query_elapsed,
            "triggered_by": triggered_by,  # BF-462 — route per-user
        })
        # BF-415 — cancel checkpoint before format conversion (potentially long).
        if _cancelled():
            raise _FeedCancelled("cancelled before format conversion")
        _t_convert = _enter_stage(f"format_{output_format}")
        # 2026-08-03 (C1) — conversion metadata out-param.  A row-capped
        # format (Excel) that wrote fewer rows than the source holds (only
        # possible via the explicit allow_excel_truncation opt-in; the
        # default raises FeedOutputTruncatedError) records the TRUE source
        # row count here so the run is reported loudly and the completeness
        # certificate reconciles source-vs-file honestly → INCOMPLETE.
        _conv_meta: Dict[str, Any] = {}
        row_count = await asyncio.to_thread(
            _convert_to_format, parquet_path, output_format, output_path,
            options, _cfg.chunk_size, _conv_meta,
        )
        # The row count is an ARTIFACT, not only a log line: the step
        # that checks it reads THIS value, so the number the gate
        # judges and the number the run reports cannot disagree.
        _steps_publish(row_count=row_count, formatted_file=output_path)
        _exit_stage(f"format_{output_format}", _t_convert)
        stage_timings["row_count"] = row_count
        # 2026-10-12 (the owner: "why will an empty file be created") -- an
        # EMPTY result is not a delivery.  A 0-row file is removed and the run
        # stops HERE, before any check or hop can call it a success -- unless
        # the feed DECLARES that an empty file is a valid delivery
        # (``row_count_expect_zero``, e.g. "no trades today").  A correctness
        # gate, so it fails; it never throttles.
        # An empty file IS valid when the upstream itself says there is
        # nothing: every side certified against its message AND every message
        # reported 0 rows (the owner: "we can write empty files if the Kafka
        # message says 0 rows on both on-prem and on-cloud").
        from core.feed.upstream_contract import all_expect_zero as _all_expect_zero
        _cert0 = stage_timings.get("reported_rows_certification") or {}
        _upstream_says_empty = bool(
            isinstance(_cert0, dict) and _cert0.get("verdict") == "certified"
            and _all_expect_zero(feed_config.get("_upstream_contract")))
        if int(row_count or 0) == 0 and _upstream_says_empty:
            stage_timings["empty_result"] = {
                "rows": 0, "file_removed": False,
                "reason": "every upstream message reported 0 rows -- an empty file is the right delivery"}
        if int(row_count or 0) == 0 and not feed_config.get("row_count_expect_zero") \
                and not _upstream_says_empty:
            try:
                Path(output_path).unlink(missing_ok=True)
            except OSError:
                pass
            current_stage = "empty_result"
            stage_timings["empty_result"] = {
                "rows": 0, "file_removed": True,
                "reason": "the query returned 0 rows and the feed does not declare an empty file valid"}
            raise FeedEmptyResultError(
                f"The query returned 0 rows for business date {_biz_date}: no file was "
                f"created or sent.  If an empty file is a valid delivery for this feed, "
                f"declare it on the feed (\"An empty result is a valid delivery\" -- "
                f"row_count_expect_zero).")
        await _steps_after(f"format_{output_format}")
        if _conv_meta.get("truncated"):
            logger.warning(
                "[feed_engine] Feed %d [%s] OUTPUT TRUNCATED (explicit "
                "allow_excel_truncation): file holds %s of %s source rows — "
                "this run is INCOMPLETE and will never be certified COMPLETE",
                feed_config_id, exec_id,
                _conv_meta.get("written_rows"), _conv_meta.get("source_rows"),
            )
            stage_timings["output_truncated"] = {
                "source_rows": _conv_meta.get("source_rows"),
                "written_rows": _conv_meta.get("written_rows"),
            }
        logger.info("[feed_engine] Feed %d [%s] format conversion (%s) complete: %d rows in %.2fs",
                    feed_config_id, exec_id, output_format, row_count,
                    round(time.time() - convert_start, 2))

        # Phase 131-C — Local file integrity check (layer 1).  Runs
        # AFTER conversion so we can compare the file we just wrote
        # against the row_count the engine just reported.  Honors the
        # per-feed override (integrity_check_enabled) over the system
        # default.  When the action is 'warn' the violation is logged
        # but doesn't fail the feed.
        # PHYSICAL dest-row count for the feed completeness certificate's
        # reconciliation (independent recount of the delivered file, not the
        # engine's self-reported row_count).  Populated by the integrity layer
        # below; falls back to row_count when integrity is disabled.
        _dest_physical_rows: Optional[int] = None
        try:
            from core.feed import file_integrity as _fi
            _ic_cfg = _fi.load_config()
            _ic_on  = _fi.is_enabled_for_feed(feed_config)
            if _ic_on:
                _t_int = _enter_stage("integrity_local")
                try:
                    _local_obs = _fi.verify_local_file(
                        output_path,
                        expected_rows=row_count,
                        output_format=output_format,
                        output_options=options,
                    )
                    # 2026-09-05 — was a direct stage_timings write, which
                    # left the per-step row OPEN: _enter_stage had opened
                    # it and only _exit_stage closes it.  The value
                    # written is byte-identical (_exit_stage computes the
                    # same round(time.time() - start, 3)); what changes is
                    # that the row is now closed as completed rather than
                    # stranded and reported as a hung step.
                    _exit_stage("integrity_local", _t_int)
                    stage_timings["file_size_bytes_local"] = _local_obs.get("size_bytes")
                    # Independent physical row count: parquet footer (exact) or
                    # csv/json line count minus the header row.
                    _wr = _local_obs.get("written_rows")
                    if _wr is None and _local_obs.get("written_lines") is not None:
                        _hdr = 1 if (options or {}).get("header", True) \
                            and (output_format or "").lower() == "csv" else 0
                        _wr = max(0, int(_local_obs["written_lines"]) - _hdr)
                    if _wr is not None:
                        _dest_physical_rows = int(_wr)
                except _fi.FileIntegrityError as _ie:
                    if (_ic_cfg.get("action") or "warn").lower() == "fail":
                        raise
                    logger.warning(
                        "[feed_engine] Feed %d [%s] integrity (local) WARN: %s",
                        feed_config_id, exec_id, _ie,
                    )
                    stage_timings["integrity_local_warning"] = str(_ie)[:200]
                    # Downgraded to a warning, so the STEP completed --
                    # close its row here too.  Recorded WITHOUT touching
                    # stage_timings: adding a duration key this branch
                    # never wrote would change what every existing reader
                    # of that dict sees.
                    if _steps is not None:
                        _steps.exit("integrity_local")
            # ALWAYS back the completeness certificate with an independent
            # physical recount — by design, NOT gated on the enforcement toggle.
            # (When the check is disabled, or a benign mismatch raised before the
            # capture above, this still gives the cert a real dest count so it
            # reconciles honestly instead of falling back to the self-report.)
            if _dest_physical_rows is None:
                _dest_physical_rows = _fi.physical_row_count(
                    output_path, output_format, options)
        except ImportError:
            pass

        # ── §10.2 PACKAGING (wired 2026-09-03) — first rung of the
        # artifact chain.  ``apply_packaging`` was written and called by
        # NOTHING, so a feed declaring packaging=zip shipped its raw
        # file; the authoring validator refused the term precisely
        # BECAUSE the engine could not honour it, which kept theplatform
        # honest but left the feature unreachable.
        #
        # The chain order is FIXED by the contract, not chosen here:
        # package -> compress -> encrypt -> checksum.  It is the order a
        # counterparty must undo in reverse, and a checksum declared
        # over anything but the last artifact describes bytes nobody
        # ever received.
        # 2026-10-15 -- checksum_covers=uncompressed: the digests of the DATA
        # file are taken HERE, before packaging / compression / encryption
        # (core/feed/checksum_covers.py, the Spark chain calls the same
        # capture).  None for every feed that checksums what it sends.
        from core.feed.checksum_covers import ChecksumCoversRefused, capture as _capture_digests
        try:
            _data_digests = await asyncio.to_thread(
                _capture_digests, feed_config, [Path(output_path)],
                _resolve_control_file_format(feed_config)
                if (feed_config.get("control_file_template")
                    or feed_config.get("control_file_format_id")) else None)
        except ChecksumCoversRefused as _cc_exc:
            raise RuntimeError(f"feed {feed_config_id}: {_cc_exc}") from _cc_exc
        if _data_digests is not None:
            stage_timings["checksum_covers"] = _data_digests.to_dict()
        _packaging_spec = (options or {}).get("packaging")             or feed_config.get("packaging")
        if _packaging_spec and str(_packaging_spec).lower() not in (
                "", "none", "no", "false"):
            from core.feed.pipeline import apply_packaging
            if _cancelled():
                raise _FeedCancelled("cancelled before packaging")
            _pkg_t = time.time()
            _pkg_path = await asyncio.to_thread(
                apply_packaging, Path(output_path), str(_packaging_spec))
            output_path = str(_pkg_path)
            filename = _pkg_path.name
            stage_timings["packaging"] = {
                "spec": str(_packaging_spec),
                "seconds": round(time.time() - _pkg_t, 3),
            }
            logger.info("[feed_engine] Feed %d [%s] packaged (%s) -> %s",
                        feed_config_id, exec_id, _packaging_spec, filename)

        # Phase 130/2 — optional compression (gzip / bzip2 / zstd / snappy).
        # Reads from output_options.compression (enterprise ZIP_FORMAT
        # field).  No-op when absent or "none".
        compression_spec = (options or {}).get("compression") \
            or feed_config.get("compression")
        if compression_spec and str(compression_spec).lower() not in ("", "none", "no", "false"):
            from core.feed.pipeline import apply_compression
            if _cancelled():
                raise _FeedCancelled("cancelled before compression")
            comp_start = time.time()
            comp_result = await asyncio.to_thread(
                apply_compression, Path(output_path), compression_spec,
            )
            output_path = str(comp_result.output_path)
            filename = comp_result.output_path.name
            logger.info(
                "[feed_engine] Feed %d [%s] compressed (%s): %d->%d bytes (ratio=%.3f) in %.2fs",
                feed_config_id, exec_id, compression_spec,
                comp_result.bytes_in, comp_result.bytes_out, comp_result.ratio,
                round(time.time() - comp_start, 2),
            )

        # ── FR-ART-06 / FR-SEC-08 ENCRYPTION (wired 2026-09-03) ───────
        # ``apply_encryption`` existed, was tested, and had NO caller.
        # The consequence was not plaintext — delivery_hops' last-line
        # tripwire refuses to hand an unencrypted artifact to any
        # transport under a pgp contract, so a native pgp run FAILED
        # rather than leaking.  It was still a hole: a pgp feed could
        # not complete on the native lane at all, and the refusal
        # message said so ("a native run whose engine has not wired
        # apply_encryption yet").  This is that wiring.
        #
        # Every failure inside RAISES by construction — there is no path
        # from "encryption declared" to "plaintext returned" — and this
        # call deliberately does not catch: failing the run is the
        # correct outcome when a contract promised encryption.
        _enc_spec = str((options or {}).get("encryption") or "none").lower()
        if _enc_spec not in ("", "none"):
            from core.feed.pipeline import apply_encryption
            if _cancelled():
                raise _FeedCancelled("cancelled before encryption")
            _enc_t = time.time()
            _enc_path = await asyncio.to_thread(
                apply_encryption, Path(output_path), feed_config)
            output_path = str(_enc_path)
            filename = _enc_path.name
            stage_timings["encryption"] = {
                "spec": _enc_spec,
                "seconds": round(time.time() - _enc_t, 3),
            }
            logger.info("[feed_engine] Feed %d [%s] encrypted (%s) -> %s",
                        feed_config_id, exec_id, _enc_spec, filename)

        # ── FR-ART-05 CHECKSUM SIDECAR (wired 2026-09-03) ─────────────
        # LAST, over the FINAL artifact.  A digest computed before
        # compression or encryption attests bytes the counterparty never
        # receives — which is worse than no digest, because it verifies
        # clean against the wrong thing.
        _sidecar_path = None
        try:
            from core.feed.pipeline import write_checksum_sidecar_for_feed
            _sidecar_path = await asyncio.to_thread(
                write_checksum_sidecar_for_feed, Path(output_path),
                feed_config, _data_digests)
            if _sidecar_path is not None:
                stage_timings["checksum_sidecar"] = str(_sidecar_path.name)
                logger.info(
                    "[feed_engine] Feed %d [%s] checksum sidecar %s",
                    feed_config_id, exec_id, _sidecar_path.name)
        except Exception as _side_exc:
            # FAIL the run.  A counterparty whose contract says "a digest
            # accompanies every file" and who receives the file WITHOUT
            # one has no way to tell a truncated delivery from a good
            # one — delivering silently unverifiable data is the failure
            # this term exists to prevent.
            raise RuntimeError(
                f"feed {feed_config_id} declares a checksum sidecar but "
                f"it could not be written ({_side_exc}) — refusing to "
                f"deliver a file the counterparty cannot verify"
            ) from _side_exc

        # Phase 130/2 — sidecar control (.ctl) file when feed config
        # specifies a control_file_template.  Skipped silently otherwise.
        # Phase 130 hotfix-4 — when feed_config.control_file_format_id is
        # set, the format is read from the feed_control_file_formats DB
        # table; falls back to the legacy default layout when NULL.
        control_file_path: Optional[str] = None
        # Phase 4 (2026-08-23): gate on template OR format_id -- a feed
        # with only control_file_format_id set silently produced NO ctl
        # while the DataFlow blueprint showed a control-file step.
        if (feed_config.get("control_file_template")
                or feed_config.get("control_file_format_id")):
            from core.feed.pipeline import write_control_file_for_feed
            try:
                _byte_size = Path(output_path).stat().st_size
            except OSError:
                _byte_size = 0
            _format_spec = _resolve_control_file_format(feed_config)
            ctl = await asyncio.to_thread(
                write_control_file_for_feed,
                output_path=Path(output_path),
                output_filename=filename,
                row_count=row_count,
                byte_size=_byte_size,
                feed_config=feed_config,
                business_date=_biz_date,
                run_date=datetime.now(timezone.utc).date(),
                run_id=exec_db_id,
                calendar=_calendar,
                format_spec=_format_spec,
                precomputed=_data_digests,
            )
            if ctl is not None:
                control_file_path = str(ctl)
                logger.info("[feed_engine] Feed %d [%s] control file: %s",
                            feed_config_id, exec_id, control_file_path)

        # Record query completion (now includes compressed filename if any)
        db.update_feed_execution(exec_db_id, {
            "query_completed_at": datetime.now(timezone.utc),
            "total_rows": row_count,
            "output_format": output_format,
            "output_filename": filename,
        })

        # ── GATE BEFORE THE FILE LEAVES (2026-09-15) ──────────────────
        # The row-count check used to run AFTER deliver_* and
        # integrity_post_delivery.  With row_count_action='fail' the run
        # was marked failed at stage row_count_check -- while the file it
        # had just refused was ALREADY at the destination (execution 67:
        # failed, and vrf_rcfail_20260915.csv sat delivered, 6430 bytes,
        # delivery_attempts 'succeeded').  A correctness gate must FAIL,
        # and a gate that fires after the consumer has the file cannot
        # gate anything.  The step model already declares the truth:
        # row_count_check REQUIRES row_count and nothing about delivery.
        # 'warn' keeps its behaviour (logged, recorded, run continues);
        # the post-delivery integrity check stays post-delivery.
        # Phase 131-B — Row-count threshold check.  Opt-in per-feed via
        # ``row_count_action`` (default 'off').  When 'fail', breaches
        # raise FeedRowCountAnomaly which propagates to the outer except
        # and marks failed_stage='row_count_check'.  When 'warn', the
        # outcome is logged + recorded in stage_timings so the
        # dashboard can flag the run without failing it.
        _variance_hold: Optional[str] = None
        try:
            from core.feed import row_count_check as _rcc
            _t_rc = _enter_stage("row_count_check")
            _baseline = None
            try:
                if db is not None:
                    # 2026-10-12 -- the rolling baseline, or (declared
                    # row_count_compare_to='previous') the rows the previous
                    # business date DELIVERED: core/feed/variance_hold.py.
                    from core.feed import variance_hold as _vh_bl
                    _baseline = _vh_bl.previous_baseline(db, feed_config, _biz_date)
            except Exception:
                _baseline = None
            _rc_outcome = _rcc.evaluate(
                row_count, feed_config=feed_config, baseline=_baseline,
            )
            # 2026-09-02 — ORDER MATTERS: _exit_stage writes a float
            # duration under the stage name, and it used to run AFTER this
            # assignment, silently replacing the outcome dict.  Downstream,
            # _build_completeness_verdict called .get() on that float and
            # crashed — so EVERY native run whose row-count check executed
            # persisted NO completeness verdict at all (the builder's
            # fail-open logged an error nobody read).  The duration now
            # rides INSIDE the outcome dict instead.
            _exit_stage("row_count_check", _t_rc)
            await _steps_after("row_count_check")
            _rc_outcome = dict(_rc_outcome or {})
            _rc_outcome["duration_seconds"] = stage_timings.get(
                "row_count_check")
            stage_timings["row_count_check"] = _rc_outcome
            if not _rc_outcome.get("skipped") and _rc_outcome.get("breach"):
                # 2026-09-15 -- %s, not %d: an absolute-floor breach
                # (row_count_min_rows) carries no baseline_avg / delta_pct,
                # and the execution log-capture handler turns a %d-on-None
                # formatting error into an exception out of THIS call --
                # a 'warn' that FAILED the run at stage row_count_check.
                logger.warning(
                    "[feed_engine] Feed %d [%s] row-count WARN: "
                    "actual=%s baseline=%s delta=%s%% threshold=%s%% "
                    "reason=%s min_rows=%s",
                    feed_config_id, exec_id,
                    _rc_outcome.get("actual_rows"),
                    _rc_outcome.get("baseline_avg"),
                    _rc_outcome.get("delta_pct"),
                    _rc_outcome.get("threshold_pct"),
                    _rc_outcome.get("reason"),
                    _rc_outcome.get("min_rows"),
                )
            # 2026-10-12 (owner R2) -- 'hold': the breach keeps the file
            # HERE; the delivery block below sends nothing and the hold is
            # recorded for the release group (core/feed/variance_hold.py).
            from core.feed import variance_hold as _vh
            if _vh.should_hold(feed_config, _rc_outcome, dry_run=dry_run,
                               delivery_suppressed=_delivery_suppressed):
                _variance_hold = _vh.hold_sentence(_rc_outcome)
                _rc_outcome["held"] = True
                logger.warning("[feed_engine] Feed %d [%s] %s", feed_config_id,
                               exec_id, _variance_hold)
        except ImportError:
            pass

        # ── Output size cap (2026-09-15) ──────────────────────────────
        # feed_generation.max_file_size_mb shipped at 500, was rendered in
        # the admin screen and in the per-feed settings, and was read by
        # NOTHING: a 20 GB file was produced, delivered and certified with
        # no mention of the ceiling the operator believed they had set.
        #
        # Checked HERE -- after the file exists, before the first delivery
        # hop -- because that is the last moment a verdict can change what
        # happens, and because "how big was it" is only knowable after the
        # format stage.  Deliberately NOT inside the integrity_local block
        # above: that one is gated on a per-feed integrity opt-in, and a
        # size ceiling that silently does not apply to most feeds is the
        # defect again with extra steps.
        #
        # THE ACTION IS DECLARED, DEFAULT warn.  A file over the ceiling
        # cannot be "throttled" -- the rows are already written, and
        # shipping a trimmed file would be the truncation-certified-VERIFIED
        # defect this product has paid for.  So the honest choices are warn
        # or refuse, and refusing by default would start failing live feeds
        # against a number no deployment has ever calibrated, because until
        # today it did nothing.  ``max_file_size_action=fail`` is the opt-in.
        # Either way the verdict is RECORDED on the run, so "did we ship
        # something oversized" stops being unanswerable.  0 = unlimited.
        try:
            _size_cap_mb = int(_cfg.max_file_size_mb)
        except Exception:
            _size_cap_mb = 0
        if _size_cap_mb > 0 and output_path:
            try:
                _out_bytes = Path(str(output_path)).stat().st_size
            except OSError:
                _out_bytes = None
            if _out_bytes is not None:
                stage_timings["output_bytes"] = _out_bytes
                _cap_bytes = _size_cap_mb * 1024 * 1024
                if _out_bytes > _cap_bytes:
                    _msg = (
                        f"output file is {_out_bytes / 1048576:.1f} MB, over "
                        f"the {_size_cap_mb} MB ceiling "
                        f"(feed_generation.max_file_size_mb)")
                    try:
                        _size_action = str(
                            getattr(_cfg, "max_file_size_action", "warn")
                            or "warn").lower()
                    except Exception:
                        _size_action = "warn"
                    stage_timings["output_size_verdict"] = (
                        f"over_limit:{_size_action}")
                    stage_timings["output_size_limit_mb"] = _size_cap_mb
                    if _size_action == "fail":
                        logger.error(
                            "[feed_engine] Feed %d [%s] REFUSED before "
                            "delivery: %s", feed_config_id, exec_id, _msg)
                        raise ValueError(f"Feed output refused: {_msg}")
                    logger.error(
                        "[feed_engine] Feed %d [%s] %s — delivering anyway "
                        "(feed_generation.max_file_size_action=warn; set it "
                        "to 'fail' to refuse)", feed_config_id, exec_id, _msg)
                else:
                    stage_timings["output_size_verdict"] = "within_limit"

        # The bytes every hop sends (and a dry run / suppressed chain keeps).
        _produced_state["path"] = output_path

        # Deliver to destination
        dest_type = feed_config.get("destination_type", "local")
        dest_config = dict(feed_config.get("destination_config") or {})
        # Phase 131 deep-dive #8 — propagate triggering user into dest_config
        # so _deliver_to_destination's credential resolver can hit the
        # portal_password_vault for personal-mode private destinations.
        # Copy made (dict(...) above) so we don't mutate the persisted
        # feed_configs.destination_config dict.
        dest_config["_triggered_by_user"] = feed_config.get("_triggered_by_user", "")
        max_retries, retry_delay = delivery_retry_policy(feed_config, _cfg)

        logger.info("[feed_engine] Feed %d [%s] delivering to %s...",
                    feed_config_id, exec_id, dest_type)
        # BF-263: progress broadcast — delivery starts
        _notify("feed_progress", {
            "feed_id": feed_config_id, "execution_id": exec_id,
            "stage": "delivering", "destination_type": dest_type,
            "rows": row_count,
            "triggered_by": triggered_by,  # BF-462 — route per-user
        })
        if dry_run:
            # ── DRY RUN (2026-09-27): everything up to here happened for
            # real -- the file on disk is exactly what would have gone.
            # From here nothing leaves the machine: no hop runner (so no
            # delivery_attempts row, no retry, no counterparty), and the
            # chain verdict says so in the same slot every reader checks.
            dest_uri = ""
            _hop_outcomes = None
            _delivery_receipt: Dict[str, Any] = {}
            stage_timings["delivery_chain"] = {
                "verdict": DRY_RUN_CHAIN_VERDICT,
                "reason": "dry run: nothing was delivered and no delivery "
                          "attempt was recorded; the produced file is in the "
                          "Download Centre for one day"}
            logger.warning(
                "[feed_engine] Feed %d [%s] DRY RUN -- delivery to %s "
                "SKIPPED; the file is at %s and will NOT be sent",
                feed_config_id, exec_id, dest_type, output_path)
        elif _variance_hold:
            # ── VARIANCE HOLD (2026-10-12, owner R2) ────────────────────
            # The row count breached a 'hold' feed's threshold: no hop
            # runs, so no delivery attempt exists for a retry to resend;
            # the file stays on the output volume and the hold row is the
            # release group's queue entry.  Recorded BEFORE the terminal
            # write and allowed to RAISE: a held file nobody can see is a
            # lost delivery, so a hold that cannot be recorded fails the run.
            from core.feed import variance_hold as _vh
            dest_uri = ""
            _hop_outcomes = None
            _delivery_receipt = {}
            try:
                _held_size = Path(output_path).stat().st_size
            except OSError:
                _held_size = None
            _hold_row = _vh.record_hold(
                db, feed_config=feed_config, feed_run_id=feed_run_id,
                exec_db_id=exec_db_id, exec_id=exec_id, business_date=_biz_date,
                outcome=stage_timings.get("row_count_check") or {},
                artifact_path=str(output_path), file_size=_held_size,
                delivery_inputs={
                    "filename": filename,
                    "control_file_path": control_file_path,
                    "sidecar_path": (str(_sidecar_path) if _sidecar_path else None),
                    "destination_type": dest_type})
            stage_timings["delivery_chain"] = {
                "verdict": _vh.CHAIN_HELD,
                "reason": f"{_variance_hold}; waiting for "
                          f"{_vh.deciders_sentence(db, feed_config)} to release "
                          f"or reject it (hold {_hold_row.get('id')})",
                "hold_id": _hold_row.get("id")}
            stage_timings["variance_hold"] = {"hold_id": _hold_row.get("id"),
                                              "status": "held"}
            logger.warning(
                "[feed_engine] Feed %d [%s] delivery to %s HELD (hold %s); the "
                "file is at %s and will NOT be sent until released",
                feed_config_id, exec_id, dest_type, _hold_row.get("id"), output_path)
        else:
            _t_deliver = _enter_stage(f"deliver_{dest_type}")
            deliver_start = time.time()
            # BF-415 — cancel checkpoint before delivery (network I/O).
            if _cancelled():
                raise _FeedCancelled("cancelled before delivery")
            # E-L1 — deliver the data file (fatal) and its sidecar control (.ctl)
            # file (non-fatal) reusing ONE S3 client / SFTP transport across the
            # pair.  Preserves the original semantics: control-file failure is
            # logged but doesn't fail the run.  Fail-safe: falls back to
            # per-file connections when reuse can't be established.
            # 2026-08-04 — the delivery receipt carries the target adapter's
            # in-band verification evidence + destination-side row accounting.
            # It feeds the run record (stage_timings) and the completeness
            # certificate's reconciliation below.
            _delivery_receipt: Dict[str, Any] = {}

            # ── Foundation M, step A (2026-09-02) — the HOP RUNNER owns delivery
            # POLICY; the existing transport keeps doing the sending.
            #
            # Deliberately a wrap, not a replacement.  The function below carries
            # behaviour the runner does not model — the .ctl sidecar paired to its
            # data file over ONE reused connection, and the delivery receipt whose
            # destination-side row accounting feeds the completeness certificate.
            # Replacing it wholesale would silently drop all three.  So the runner
            # decides WHETHER and HOW MANY TIMES, records the attempt against the
            # manifest version it sent (FR-DEL-04), and refuses to auto-retry a
            # non-idempotent target (H1); the transport decides HOW.
            #
            # ``max_retries=0`` is load-bearing: the runner owns retry now, and an
            # inner loop would re-attempt a hop the runner had already refused —
            # exactly the double-delivery this foundation exists to prevent.
            _manifest = _delivery_manifest_for(
                output_path, row_count, feed_config_id, exec_id)
            _hop_outcomes = None
            try:
                from core.feed.delivery_hops import (
                    DeliveryHopRunner, build_hop_plan,
                )

                def _transport(hop, manifest):
                    uri = _deliver_data_then_control(
                        output_path, filename, control_file_path,
                        hop.target_type, dict(hop.config),
                        0, retry_delay, feed_config_id, exec_id,
                        _receipt=_delivery_receipt,
                        sidecar_path=(str(_sidecar_path) if _sidecar_path
                                      else None),
                    )
                    return {"uri": uri, "sent_path": output_path,
                            "verification": _delivery_receipt.get("verification"),
                            "verification_detail":
                                _delivery_receipt.get("verification_detail")}

                _plan = build_hop_plan(
                    {**feed_config, "destination_config": dest_config},
                    # The run's identity, for targets that file BY it.  The
                    # archive hop refuses without it, so registering that
                    # target without supplying this would have made every
                    # archive hop refuse at 03:00 — a newly wired feature
                    # arriving as a newly broken one.
                    run_identity={"feed": feed_config.get("name"),
                                  "business_date": _biz_date,
                                  "build_id": exec_id})
                _runner = DeliveryHopRunner(
                    db, {h.target_type: _transport for h in _plan},
                    environment=_deploy_environment(),
                    actor=triggered_by or "system",
                    suppression_policy=_cfg.delivery_suppression)
                _hop_outcomes = await asyncio.to_thread(
                    _runner.execute_chain, _plan, _manifest,
                    feed_config_id=feed_config_id, business_date=_biz_date,
                    feed_key=feed_config.get("name"),
                    # the decision stored on this execution at creation
                    run_suppressed=_delivery_suppressed)
                dest_uri = next((o.uri for o in (_hop_outcomes or [])
                                 if getattr(o, "uri", None)), "")
            except ImportError:
                # The foundation is not present in this build — fall back to the
                # pre-2026-09-02 path rather than failing the feed.
                dest_uri = await asyncio.to_thread(
                    _deliver_data_then_control, output_path, filename,
                    control_file_path, dest_type, dest_config,
                    max_retries, retry_delay, feed_config_id, exec_id,
                    _receipt=_delivery_receipt,
                    sidecar_path=(str(_sidecar_path) if _sidecar_path else None),
                )
            # What went out, recorded BEFORE the verdict below can raise: a
            # partial chain's delivered hop is a fact the failure record must
            # state (see _delivered_facts).
            if dest_uri:
                _delivered_state.update(uri=dest_uri, path=output_path,
                                        at=datetime.now(timezone.utc))
            if _hop_outcomes is not None:
                stage_timings["delivery_hops"] = [
                    o.to_dict() if hasattr(o, "to_dict") else str(o)
                    for o in _hop_outcomes]
                # ── DID THE DELIVERY HAPPEN?  (2026-09-15) ─────────────────
                # execute_chain records every hop and moves on -- right for a
                # chain (FR-DEL-02), and deliberately unchanged.  What was
                # missing was the CONSUMER asking afterwards.  Until now this
                # engine read the first URI any hop produced, found none, and
                # carried on: execution 61 -- every hop FAILED, the SFTP inbox
                # empty -- finished status=completed, error_message='',
                # completeness=verified.  A file that never left the machine
                # certified COMPLETE is the worst thing this product can say.
                # The rule lives in ONE place (delivery_hops.chain_verdict),
                # read from what the plan declares; the Spark lane asks the
                # same function.
                from core.feed.delivery_hops import (
                    CHAIN_FAILED as _CHAIN_FAILED,
                    CHAIN_SUPPRESSED as _CHAIN_SUPPRESSED,
                    DeliveryChainFailed as _DeliveryChainFailed,
                    chain_verdict as _chain_verdict,
                )
                _chain_state, _chain_reason = _chain_verdict(_plan, _hop_outcomes)
                stage_timings["delivery_chain"] = {"verdict": _chain_state,
                                                   "reason": _chain_reason}
                if _chain_state == _CHAIN_FAILED:
                    # Raised INSIDE the deliver_* stage, so the failure
                    # handler names it as failed_stage and closes its step
                    # row as failed; the run is 'failed', never 'completed',
                    # and no completeness verdict is built for it.
                    raise _DeliveryChainFailed(_chain_reason)
                if _chain_state == _CHAIN_SUPPRESSED:
                    # A deliberate non-delivery (policy / backfill without
                    # deliver=true): the run completes WITHOUT a destination,
                    # as FR-DEL-06 / FR-OPS-08 designed, and the attempt rows
                    # say why.  Loud, because a feed that quietly sends
                    # nothing looks exactly like a feed that worked.
                    logger.warning(
                        "[feed_engine] Feed %d [%s] delivery SUPPRESSED on "
                        "every hop -- the run will complete undelivered: %s",
                        feed_config_id, exec_id, _chain_reason)
            _steps_publish(delivered=dest_uri)
            _exit_stage(f"deliver_{dest_type}", _t_deliver)
            await _steps_after(f"deliver_{dest_type}")
            if _delivery_receipt:
                stage_timings["delivery_verification"] = {
                    "status": _delivery_receipt.get("verification", "absent"),
                    "detail": _delivery_receipt.get("verification_detail", ""),
                }
                if isinstance(_delivery_receipt.get("delivered_rows"), int):
                    stage_timings["delivery_verification"]["delivered_rows"] = \
                        _delivery_receipt["delivered_rows"]
                if isinstance(_delivery_receipt.get("auth"), dict):
                    # AQD-10: which auth method delivered it, on the run record
                    stage_timings["delivery_verification"]["auth"] = \
                        dict(_delivery_receipt["auth"])
                if _delivery_receipt.get("control_file_delivery"):
                    stage_timings["control_file_delivery"] = \
                        _delivery_receipt["control_file_delivery"]
                if _delivery_receipt.get("dropped_rows"):
                    stage_timings["delivery_verification"]["dropped_rows"] = \
                        _delivery_receipt["dropped_rows"]
                    logger.warning(
                        "[feed_engine] Feed %d [%s] destination REJECTED %s rows "
                        "(delivered %s) — certificate will reconcile against the "
                        "destination count",
                        feed_config_id, exec_id,
                        _delivery_receipt.get("dropped_rows"),
                        _delivery_receipt.get("delivered_rows"),
                    )
            logger.info("[feed_engine] Feed %d [%s] delivery complete in %.2fs -> %s",
                        feed_config_id, exec_id,
                        round(time.time() - deliver_start, 2), dest_uri)

        file_size = 0
        try:
            file_size = Path(output_path).stat().st_size
        except OSError:
            pass

        # Phase 131-C — Post-delivery integrity check (layer 2).  S3 HEAD
        # (or SFTP stat) to confirm the delivered file matches the bytes
        # we wrote locally.  Cheap (one HEAD call); off when system
        # default disables it.
        try:
            from core.feed import file_integrity as _fi2
            _ic_cfg2 = _fi2.load_config()
            if (_fi2.is_enabled_for_feed(feed_config)
                    and _ic_cfg2.get("post_delivery", True)
                    and dest_type not in ("local",)
                    and not dry_run):
                _t_pd = _enter_stage("integrity_post_delivery")
                try:
                    _pd_obs = await asyncio.to_thread(
                        _fi2.verify_post_delivery,
                        local_path=output_path,
                        local_size=file_size,
                        dest_type=dest_type,
                        dest_config=dest_config,
                        delivered_uri=dest_uri,
                    )
                    # 2026-09-05 — see integrity_local above: a direct
                    # write left the step row open.  Same value.
                    _exit_stage("integrity_post_delivery", _t_pd)
                    if _pd_obs.get("remote_size") is not None:
                        stage_timings["remote_size_bytes"] = _pd_obs["remote_size"]
                except _fi2.FileIntegrityError as _ie:
                    if (_ic_cfg2.get("action") or "warn").lower() == "fail":
                        raise
                    logger.warning(
                        "[feed_engine] Feed %d [%s] integrity (post-delivery) WARN: %s",
                        feed_config_id, exec_id, _ie,
                    )
                    stage_timings["integrity_post_delivery_warning"] = str(_ie)[:200]
                    if _steps is not None:
                        _steps.exit("integrity_post_delivery")
        except ImportError:
            pass

        # Row-count threshold check: since 2026-09-15 it runs BEFORE
        # delivery (see "GATE BEFORE THE FILE LEAVES" above the delivery
        # block).  A verdict of FAIL after the counterparty already has
        # the file gates nothing.

        duration = round(time.time() - start_time, 2)
        # BF-FEED-RUN-COUNT — historically only status / output_path /
        # file_size_bytes were synced back to feed_runs on success, so
        # the dashboard's "Total records" column always read its DB
        # default (0).  Sync total_rows + control_file_path here too so
        # the same numbers feed_executions has end up on feed_runs.
        _final_run_sync = {
            "status": "completed",
            "completed_at": datetime.now(timezone.utc),
            # A dry run delivered nowhere; the row shows the LOCAL file it
            # produced, which is what the Download Centre serves.
            "output_path": (output_path if dry_run else dest_uri),
            "file_size_bytes": file_size,
            "total_rows": int(row_count or 0),
            "control_file_path": control_file_path,
        }
        if _fanout_state is not None:
            # FR-RUN-04 — a fanned-out parent's status is DERIVED from its
            # children (recompute_parent already wrote the derived verdict);
            # writing it directly here is how a re-run of one child leaves a
            # permanently failed parent, or how a parent reads complete
            # while a child is still writing.  The display fields
            # (output_path, sizes, rows) still sync — they are not status.
            _final_run_sync.pop("status", None)
            _final_run_sync.pop("completed_at", None)
        _sync_feed_run(_final_run_sync)
        # ── FEED COMPLETENESS CERTIFICATE (2026-07-22) ────────────────────
        # A completed feed is a WRITE we control end-to-end — certify it at
        # FEED scope (reconciliation + sentinel), NOT the source-read query
        # scope that stays UNVERIFIED in fast mode.  Reconcile the rows the
        # engine produced (row_count) against the rows PHYSICALLY present in
        # the delivered file (independent recount from the integrity layer;
        # falls back to row_count when integrity is off).  Fuses any source-read
        # hard-negative / quarantine so a broken source can't fake COMPLETE.
        # An ASSERTION on this run — a skipped dependency or a
        # force-complete — makes the verdict "asserted", never
        # "verified" (FR-CMP-09): a consumer reconciling a regulatory
        # feed is entitled to know an input was never confirmed.
        _gate_assertion = (feed_config.get("_gate_assertion")
                           if isinstance(feed_config, dict) else None)
        _feed_fm = _capture_perf_metadata()
        # 2026-08-17 (F2) — a row cap that BITES must be disclosed in the
        # execution record itself, not just a log line the user never sees.
        # _execute_duckdb_query stashes the disclosure dict when a
        # configured query_params.limit was in force; surface it in
        # files_metadata so the dashboard / API show it alongside the run.
        #
        # 2026-09-05 — resolved ONCE, here, and handed to BOTH consumers:
        # this record AND the completeness verdict below.  It used to be
        # popped here and re-read from feed_config 70 lines later by
        # _build_completeness_verdict, which therefore always saw None and
        # asserted "no cap was applied" on a run that had been TRUNCATED.
        # A value computed for a correctness gate and then thrown away will
        # disagree with what the system does.
        _row_cap_disc = _resolve_row_cap_disclosure(feed_config)
        try:
            if isinstance(feed_config, dict):
                feed_config.pop("_row_cap_disclosure", None)
            if _row_cap_disc:
                _feed_fm["row_cap"] = _row_cap_disc
        except Exception as _cap_exc:
            # Disclosure is the whole point of this block -- if it fails the
            # operator must know the run's row-cap note is missing.
            logger.warning("row-cap disclosure could not be attached to "
                           "files_metadata: %s", _cap_exc)
        # 2026-08-22 — the router's BackendChoice was computed, logged and
        # THROWN AWAY (same shape as the S3 truncation verdict that was
        # discarded for months): _pick_backend's own docstring promises
        # backend_reason/backend_failed_over on the execution row and
        # nothing wrote them.  files_metadata round-trips through
        # FeedExecution.to_dict(), so no migration is needed.
        try:
            _feed_fm["backend_choice"] = choice.to_dict()
        except Exception as _bc_exc:
            logger.warning("backend choice could not be attached to "
                           "files_metadata: %s", _bc_exc)
        # 2026-08-22 — write-ladder + union-pushdown audit: WHICH rung ran
        # and WHY (incl. declared refusals) lives on the execution record,
        # not only in pod logs.  Same posture as the row-cap disclosure.
        try:
            if isinstance(feed_config, dict):
                _ladder_disc = feed_config.pop("_write_ladder", None)
                if _ladder_disc:
                    _feed_fm["write_ladder"] = _ladder_disc
                _up_disc = feed_config.pop("_union_pushdown", None)
                if _up_disc:
                    _feed_fm["union_pushdown"] = _up_disc
                # 2026-10-10 -- the cross-source MERGE disclosure: per-side
                # row counts, expected total, the by-name plan (or the
                # refusal).  The certificate's "rows == primary + secondary"
                # is checkable from this record.
                _xs_disc = feed_config.pop("_cross_source", None)
                if _xs_disc:
                    _feed_fm[_CROSS_SOURCE_KEY] = _xs_disc
                # 2026-10-14 -- the partitioned read per side: the plan, or
                # the reason the query ran whole (core/feed/partitioned_read.py)
                _pr_disc = feed_config.pop("_partitioned_read", None)
                if _pr_disc:
                    _feed_fm["partitioned_read"] = _pr_disc
                # 2026-10-14 -- which dialect the SQL was read as, and whether
                # the connection DECLARED it or it was guessed
                _tr_disc = feed_config.pop("_sql_translation", None)
                if _tr_disc:
                    _feed_fm["sql_translation"] = _tr_disc
        except Exception as _wl_exc:
            logger.warning("write-ladder audit could not be attached to "
                           "files_metadata: %s", _wl_exc)
        try:
            from core.feed_perf import build_feed_certificate as _build_feed_cert
            if dry_run:
                raise _DryRunCertifiesNothing()
            _feed_cert = _build_feed_cert(
                exec_id,
                subject_id=exec_db_id,
                # 2026-08-03 (C1) — when the output was truncated (explicit
                # allow_excel_truncation opt-in), reconcile against the TRUE
                # source row count, not the rows that fit in the file.  The
                # old wiring compared the truncated count against itself
                # (xlsx has no physical recount → dest fell back to the same
                # number) and stamped a half-empty feed COMPLETE.
                source_rows=_certified_source_rows(row_count, _conv_meta),
                # 2026-08-04 — dest_rows now prefers the delivery receipt's
                # DESTINATION-side count (Oracle row accounting) over the
                # local-file recount, so a destination that dropped rows
                # under the max_error_percent tolerance reconciles short →
                # INCOMPLETE instead of a false COMPLETE.
                dest_rows=_certified_dest_rows(
                    _delivery_receipt, _dest_physical_rows, row_count),
                issued_at=time.time(),
            )
            if _feed_cert:
                _feed_fm["completeness_certificate"] = _feed_cert
        except _DryRunCertifiesNothing:
            pass
        except Exception as _fc_exc:
            logger.debug("[feed_engine] feed certificate build skipped (%s)", _fc_exc)

        # ── FR-CMP-01/07 (2026-09-02) — THE COMPLETENESS VERDICT ─────────
        # Three states, never two: verified / asserted / unverifiable, plus
        # incomplete when a MEASURED comparison failed.  "Unverifiable" is its
        # own state and never folds into success — every completeness defect
        # this codebase has produced came from treating "could not tell" as
        # "fine".
        #
        # ``completeness_gate`` decides what the verdict DOES.  It records by
        # default: enforcing it blind would mark good runs unverifiable
        # overnight, because most cannot yet ASSERT that no row cap applied,
        # and a correctness control that fails everything on day one is a
        # control someone switches off.
        if dry_run:
            # A dry run CERTIFIES NOTHING: no verdict, no certificate.  A
            # "verified" stamp on a file that never went would be the
            # exact laundering FR-CMP-09 exists to prevent.  The record
            # says why the slot is empty.
            _cmp_verdict = None
            _feed_fm["dry_run"] = {
                "delivered": False, "certified": False,
                "reason": "dry run: the chain ran, nothing was delivered "
                          "and nothing is certified",
                "output_path": output_path,
            }
            _final_status = "completed"
        else:
            _cmp_verdict = _build_completeness_verdict(
                feed_config, row_count=row_count, stage_timings=stage_timings,
                gate_assertion=_gate_assertion,
                # The SAME disclosure this run's execution record carries —
                # the gate reads the resolved value, not a second lookup
                # that the pop above has already emptied.
                row_cap=_row_cap_disc,
                # §9.2 / FR-CMP-05 — only a run that actually FANNED OUT
                # can make the feed-level set claim; a declared shape on
                # an unwired backend has no certified partition set to
                # compare.
                partition_declaration=(_partition_declaration
                                       if _fanout_state is not None else None),
                certified_partitions=(_fanout_state or {}).get("certified"))
            if _cmp_verdict is not None:
                _feed_fm["completeness_verdict"] = _cmp_verdict.to_dict()
            _final_status = resolve_final_status(
                _cmp_verdict, _cfg.completeness_gate if _cfg else "record",
                feed_config_id=feed_config_id, exec_id=exec_id)
        # FR-ART-07 — the file carrying the number was DELIVERED, so the
        # number is spent for real.  Committed here rather than at
        # allocation so a run that died mid-flight leaves a VISIBLE
        # taken-but-uncommitted row instead of a silently consumed one.
        if _seq_alloc is not None and dry_run:
            # Nothing carried the number anywhere, so it is not spent --
            # abandoned WITH the reason, never committed, never reused
            # silently (the ledger stays gapless-with-answers).
            try:
                from core.feed.sequence import SequenceAllocator
                SequenceAllocator(db).abandon(
                    _seq_alloc.id, reason=f"dry run {exec_id}: the file "
                                          f"was not delivered")
            except Exception as _seq_d_exc:
                logger.error("[feed_engine] dry run: sequence %s could not "
                             "be marked abandoned (%s)", _seq_alloc.id,
                             _seq_d_exc)
        elif _seq_alloc is not None:
            try:
                from core.feed.sequence import SequenceAllocator
                SequenceAllocator(db).commit(_seq_alloc.id)
            except Exception as _seq_c_exc:
                logger.error(
                    "[feed_engine] feed %s delivered file %s carrying "
                    "sequence %s but the allocation could not be "
                    "committed (%s) — the ledger will show it as taken, "
                    "which reads as a gap; reconcile before the "
                    "counterparty asks", feed_config_id, filename,
                    _seq_alloc.formatted(), _seq_c_exc)

        # ── FR-DEL-10/11/12 (wired 2026-09-03) — REGISTER THE DELIVERABLE
        # A delivered feed file that nobody can find is only half
        # delivered.  ``feed_download_registration`` and
        # ``register_feed_download`` were written, tested, and called by
        # NOTHING: the Download Centre never learned a feed had produced
        # anything, so FR-DEL-11's "redirect, don't stream" and
        # FR-DEL-12's feed-access-rule sharing had no rows to act on.
        #
        # Registered AFTER delivery succeeded and BEFORE the row is
        # finalised, so a registration that fails cannot leave a run
        # looking undelivered.  Fails OPEN and LOUD: the file is already
        # at the destination and the counterparty already has it —
        # refusing the run now would report a delivery that happened as
        # a failure, which is the worse lie.
        #
        # Only a file that WENT is a deliverable (2026-09-25, Docker audit).
        # A suppressed chain (a backfill without delivery, or policy) leaves
        # dest_uri empty, and registering it put an 'available' row with no
        # path in every user's Download Centre -- listed, never servable (410).
        if dest_uri or dry_run:
            try:
                from core.feed.archive import (
                    feed_download_registration, register_feed_download,
                )
                _dl_alg = None
                if isinstance(feed_config, dict):
                    _dl_alg = (feed_config.get("checksum_algorithm")
                               or (feed_config.get("contract") or {})
                               .get("checksum_algorithm"))
                _dl_sum = None
                if _dl_alg:
                    # Only hash when the CONTRACT asked for a checksum.
                    # Hashing every artifact unconditionally would read
                    # multi-GB files nobody asked to verify, on the critical
                    # path of every run — measure the latency you add.
                    try:
                        from core.feed.checksum import compute_file_checksum
                        _dl_sum = await asyncio.to_thread(
                            compute_file_checksum, output_path, _dl_alg)
                    except Exception as _sum_exc:
                        logger.warning(
                            "[feed_engine] download checksum (%s) could not be "
                            "computed for feed %s — registering WITHOUT it "
                            "(%s)", _dl_alg, feed_config_id, _sum_exc)
                from core.config import feed_generation as _dl_cfg
                _dl_row = register_feed_download(db, feed_download_registration(
                    feed_config=feed_config,
                    filename=filename,
                    # A dry run's deliverable is the LOCAL file it produced,
                    # kept for one day so the operator can inspect it.
                    file_uri=(output_path if dry_run else dest_uri),
                    size_bytes=file_size,
                    business_date=_biz_date,
                    build_id=exec_id,
                    checksum=_dl_sum,
                    checksum_algorithm=_dl_alg,
                    retention_days=(DRY_RUN_DOWNLOAD_RETENTION_DAYS if dry_run
                                    else (_dl_cfg.download_retention_days
                                          or None)),
                    created_by=(feed_config.get("_triggered_by_user")
                                if isinstance(feed_config, dict) else None),
                ))
                _feed_fm["download_file_id"] = (_dl_row or {}).get("file_id")
            except Exception as _dl_exc:
                logger.error(
                    "[feed_engine] feed %s delivered to %s but could NOT be "
                    "registered in the Download Centre (%s) — the file exists "
                    "and the run is genuinely complete; it will not be "
                    "downloadable from the UI until this is repaired",
                    feed_config_id, dest_uri, _dl_exc)
        else:
            logger.info(
                "[feed_engine] feed %s: nothing was delivered (chain %s), so "
                "no Download Centre entry is registered", feed_config_id,
                (stage_timings.get("delivery_chain") or {}).get("verdict"))

        # 2026-10-07 -- delivery_completed_at is a DELIVERY timestamp: it is
        # stamped only when something reached a destination.  A suppressed
        # chain (backfill without delivery, policy) or a dry run delivered
        # nothing, and stamping it anyway made "completed, not delivered"
        # read as delivered on every screen that shows the column.  The
        # spark webhook-side delivery already clears it for the same reason.
        _delivered_now = bool(dest_uri) and not dry_run
        _finalize_execution_row(db, exec_db_id, {
            "status": _final_status,
            "delivery_completed_at": (datetime.now(timezone.utc)
                                      if _delivered_now else None),
            "completed_at": datetime.now(timezone.utc),
            "destination_path": dest_uri,
            # The produced file, kept on the shared output volume whether
            # or not it went anywhere: what the execution's Download serves
            # and what a hop retry of a suppressed chain sends.
            "artifact_path": _produced_artifact(),
            "file_size_bytes": file_size,
            "duration_seconds": duration,
            # Round 16: persist per-stage timings so the dashboard's
            # "completed" view can render the full timeline retrospectively
            # (was being built locally in stage_timings dict but never
            # written to the DB column).
            "stage_timings": dict(stage_timings),
            # Round 16: BQB-parity files_metadata = stage_history + log_lines.
            # Surfaced via /api/feed-executions/{id}/performance for the
            # dashboard chip.  Now carries the FEED-scope completeness cert.
            "files_metadata": _feed_fm,
        })
        _end_log_capture()
        if not dry_run:
            db.increment_feed_run_count(feed_config_id)
        # Phase 131 deep-dive #13 (round 8) — persist actual row count so
        # the next execute_feed() can use it to size-route via the auto
        # backend router.  Skip when row_count is missing/zero (caller's
        # row count not threaded through, or genuine empty run — first
        # case shouldn't poison the routing baseline with 0).
        _update_payload = {"last_execution_id": exec_db_id}
        try:
            if isinstance(row_count, int) and row_count > 0:
                _update_payload["last_row_count"] = int(row_count)
        except Exception:
            pass
        db.update_feed_config(feed_config_id, _update_payload)

        # Record circuit breaker success for external backends
        if backend == "airflow":
            _airflow_breaker.record_success()

        # Phase 130 hotfix-13 audit fix #6: CBQ-parity COMPLETED log line
        # — per-stage timing breakdown so ops can see which stage is the
        # bottleneck (matches the per-stage history surfaced for normal
        # queries via execution_log).
        _stage_summary = " | ".join(
            f"{k}={v}"
            for k, v in sorted(stage_timings.items())
            if isinstance(v, (int, float))
        )
        if feed_config.get("_reused_side"):
            from core.feed.side_resume import discard as _sr_discard
            _sr_discard(feed_config["_reused_side"])     # used: the kept rows are done
        # a delivery of the CURRENT upstream contract answers the open
        # "superseded" decisions raised for it (core/feed/regeneration.py)
        # 2026-10-15 -- and, for a dependency that governs no environment,
        # the decisions whose latest message arrived before this run STARTED
        # (``started_at``): a month end held on SOD + ITD + EOD re-runs on
        # every new EOD, not only the first.
        if _biz_date:
            from core.feed.regeneration import close_answered_decisions as _close_answered
            _close_answered(db, feed_config_id=feed_config_id, business_date=_biz_date,
                            contract=feed_config.get("_upstream_contract") or {}, execution_id=exec_id,
                            started_at=datetime.fromtimestamp(start_time, timezone.utc))
        logger.info(
            "[feed_engine] Feed %d [%s] COMPLETED — %d rows, %d bytes, %.2fs, dest=%s "
            "| stages: %s | task=%s",
            feed_config_id, exec_id, row_count, file_size, duration, dest_uri,
            _stage_summary or "(none)",
            _task_identity(),
        )
        # Persist the stage timings on the feed_execution row so the
        # dashboard / execution-detail panel can render the breakdown
        # without re-parsing logs.
        try:
            db.update_feed_execution(exec_db_id, {
                "stage_timings": dict(stage_timings),
            })
        except Exception:
            pass

        # Notify via WebSocket
        _notify("feed_completed", {
            "feed_id": feed_config_id,
            "execution_id": exec_id,
            "feed_name": feed_name,
            "rows": row_count,
            "destination": dest_uri,
            "duration_seconds": duration,
            "triggered_by": triggered_by,
            "dry_run": dry_run,
            "held": bool(_variance_hold),
        })

        # Send email/webhook notifications -- a dry run sends NONE (the
        # feed's recipients would read "delivered"), and the record says so.
        if dry_run or _variance_hold:
            # a HELD file was not delivered either: "success" would tell the
            # recipients it went.  The release group's bell is the hold's own.
            _why_none = "dry run" if dry_run else "held for variance verification"
            stage_timings["notifications"] = {
                "email": {"state": "none", "reason": _why_none},
                "webhook": {"state": "none", "reason": _why_none}}
            try:
                db.update_feed_execution(exec_db_id, {
                    "stage_timings": dict(stage_timings)})
            except Exception:
                pass
        else:
            _send_notifications(feed_config, "success", {
                "feed_name": feed_name, "rows": row_count,
                "destination": dest_uri, "duration": duration,
            }, db=db, exec_db_id=exec_db_id, stage_timings=stage_timings)

        # Cleanup temp files
        _cleanup_temp_files(_temp_files)

        return db.get_feed_execution(exec_db_id) or exec_record

    except _FeedCancelled as _cx:
        if _steps is not None:
            _steps.finalize("cancelled",
                            reason=f"the run was cancelled: {_cx}")
        # BF-415 — cancel taken cleanly between stages.  Mark cancelled,
        # broadcast, clean up; do NOT count toward the airflow breaker
        # (a cancel is not a backend failure).
        duration = round(time.time() - start_time, 2)
        _sync_feed_run({
            "status": "cancelled",
            "completed_at": datetime.now(timezone.utc),
            "error": f"Cancelled: {_cx}",
        })
        _finalize_execution_row(db, exec_db_id, {
            "status": "cancelled",
            "completed_at": datetime.now(timezone.utc),
            "error_message": f"Cancelled: {_cx}",
            "duration_seconds": duration,
            "stage_timings": dict(stage_timings),
            "files_metadata": {**_capture_perf_metadata(),
                               "backend_choice": choice.to_dict()},
            "failed_stage": current_stage,
        })
        _end_log_capture()
        _notify("feed_cancelled", {
            "feed_id": feed_config_id, "execution_id": exec_id,
            "feed_name": feed_config.get("name", ""),
            "reason": str(_cx), "triggered_by": triggered_by,
        })
        logger.info("[feed_engine] Feed %d [%s] CANCELLED after %.2fs (%s)",
                    feed_config_id, exec_id, duration, _cx)
        _cleanup_temp_files(_temp_files)
        return db.get_feed_execution(exec_db_id) or exec_record
    except Exception as exc:
        # 2026-10-10 -- the run's error is the SOURCE's sentence when the
        # source judged it (core.error_sanitizer.describe_exception, over
        # the one classifier in core.connectors.base): an untrusted
        # certificate reads "not trusted ... ca_cert_pem", a hidden column
        # "Access Denied: Cannot select ..." -- not the transport's pool
        # text or the driver's repr the SQL editor and the routes no longer
        # show either.  Anything else keeps its own text, scrubbed.
        from core.error_sanitizer import describe_exception
        raw_str = describe_exception(exc)
        # 2026-10-12 -- WHICH side failed: a side's read tagged itself; a
        # per-side ROW_COUNT mismatch names its sides in the certification
        # record.  Recorded with the failure, never inferred from the text.
        if (feed_config or {}).get("_kept_side"):
            from core.feed.side_resume import KEPT_KEY as _SR_KEPT
            stage_timings[_SR_KEPT] = dict(feed_config["_kept_side"])
        _fs = getattr(exc, FAILED_SIDE_ATTR, None)
        if not _fs:
            _cert = stage_timings.get("reported_rows_certification") or {}
            _bad = [s for s, v in ((_cert.get("sides") or {}).items())
                    if isinstance(v, dict) and v.get("verdict") == "mismatch"]
            _fs = "both" if len(_bad) > 1 else (_bad[0] if _bad else None)
        if _fs:
            stage_timings[FAILED_SIDE_KEY] = _fs
        if _steps is not None:
            # Name the stage that broke ON ITS OWN ROW.  "which step
            # failed, and why" is the question the run screen could
            # not answer, and a duration dict never could.
            _steps.fail(current_stage, f"{type(exc).__name__}: {raw_str}")
        from core.proxy_utils import sanitize_proxy_error
        duration = round(time.time() - start_time, 2)
        # Phase 131 deep-dive #9: prefix the error with feed identity +
        # current_stage so ops can triage from the dashboard without
        # cross-referencing exec_id back to logs.  Plus categorise common
        # credential errors with actionable hints.
        sanitized = sanitize_proxy_error(raw_str)
        # Detect the most common no-help-context errors and add actionable
        # hints inline before truncation.
        hint = ""
        _cls = type(exc).__name__
        if "PersonalPasswordRequired" in _cls or "personal password" in raw_str.lower() \
                or "portal password" in raw_str.lower():
            hint = (" [HINT: Connection requires AWS portal credentials. "
                    "For batch execution configure a system_account on the "
                    "connection, OR re-trigger this feed after logging in so "
                    "your session password is cached in the vault (8h TTL).]")
        elif "Connection " in sanitized and "not found" in sanitized:
            hint = (" [HINT: Verify the connection still exists and is active. "
                    "Open Admin → Connections to confirm.]")
        elif "outside the allowed roots" in sanitized:
            hint = (" [HINT: Local-delivery path must live under output_dir or "
                    "feed_generation.local_destination_allowed_roots.]")
        # If setup_registered_views fell back earlier in this run, surface
        # WHY — the user otherwise sees only the downstream catalog/parser
        # error and has no idea the fallback path was even taken.  Prepended
        # as a precursor line so the chip on the dashboard reads e.g.:
        #   "Precursor: setup_registered_views failed: IndexError: list index
        #    out of range [File ...duckdb_views.py, line 1471, ...]"
        # then the real failure on the next line.
        _setup_warn = (feed_config or {}).get("_setup_views_warning")
        precursor = f"Precursor: {_setup_warn}\n" if _setup_warn else ""
        error_msg = (
            f"{precursor}"
            f"Feed {feed_config_id} @ stage='{current_stage}': {sanitized}{hint}"
        )[:2000]
        # FR-ART-07 — a number taken by a run that then failed is SPENT.
        # It is recorded as abandoned WITH THE REASON, so the gap the
        # counterparty will notice has an answer attached to it; reusing
        # it for the next run would make two files claim one identity.
        try:
            if _seq_alloc is not None:
                from core.feed.sequence import SequenceAllocator
                SequenceAllocator(db).abandon(
                    _seq_alloc.id,
                    reason=f"run {exec_id} failed at "
                           f"stage={current_stage}: {error_msg[:300]}")
        except Exception as _seq_a_exc:
            logger.error("[feed_engine] sequence %s could not be marked "
                         "abandoned after a failed run (%s)",
                         getattr(_seq_alloc, "id", None), _seq_a_exc)
        _failed_run_sync: Dict[str, Any] = {
            "status": "failed",
            "completed_at": datetime.now(timezone.utc),
            "error": error_msg,
        }
        _failed_exec: Dict[str, Any] = {
            "status": "failed",
            "completed_at": datetime.now(timezone.utc),
            "error_message": error_msg,
            "duration_seconds": duration,
            "stage_timings": dict(stage_timings),
            "files_metadata": {**_capture_perf_metadata(),
                               "backend_choice": choice.to_dict()},
            "failed_stage": current_stage,
        }
        # 2026-10-07 -- the produced file, when the run got that far: a
        # failed delivery chain is recovered by retrying the hop, which
        # sends exactly these bytes (api/feed_ops_api.py::retry_delivery_hop).
        _art = _produced_artifact()
        if _art:
            _failed_exec["artifact_path"] = _art
        # 2026-09-15 -- a run that failed AFTER delivery must say so.
        # The record used to read file_size_bytes=0 / destination_path
        # null for a file the counterparty already had; "failed" plus
        # "nothing delivered" invites a re-run that ships it twice.
        _dlv = _delivered_facts()
        if _dlv:
            _failed_run_sync.update(output_path=_dlv["uri"],
                                    file_size_bytes=_dlv["size"])
            _failed_exec.update(destination_path=_dlv["uri"],
                                file_size_bytes=_dlv["size"],
                                delivery_completed_at=_dlv["at"])
            logger.error(
                "[feed_engine] Feed %d [%s] FAILED at stage=%r AFTER the "
                "file was delivered to %s (%s bytes) -- the counterparty "
                "HAS this file; re-delivering it needs a decision, not a "
                "retry", feed_config_id, exec_id, current_stage,
                _dlv["uri"], _dlv["size"])
        _sync_feed_run(_failed_run_sync)
        _finalize_execution_row(db, exec_db_id, _failed_exec)
        _end_log_capture()

        # Circuit breaker for external backends
        if backend == "airflow":
            _airflow_breaker.record_failure()

        # Notify failure via WebSocket
        _notify("feed_failed", {
            "feed_id": feed_config_id,
            "execution_id": exec_id,
            "feed_name": feed_config.get("name", ""),
            "error": error_msg,
            "triggered_by": triggered_by,
        })

        # Send failure notifications
        _send_notifications(feed_config, "failure", {
            "feed_name": feed_config.get("name", ""),
            "error": error_msg, "duration": duration,
        }, db=db, exec_db_id=exec_db_id, stage_timings=stage_timings)

        # Phase 130 hotfix-13 audit fix #6: stage-aware FAILED log.
        # Pinpoints exactly which stage broke (status_running /
        # query_native / query_airflow / format_csv / deliver_s3 / ...)
        # so on-call doesn't have to scroll back through the trace to
        # find where execution stopped.
        _stage_summary = " | ".join(
            f"{k}={v}"
            for k, v in sorted(stage_timings.items())
            if isinstance(v, (int, float))
        )
        logger.error(
            "[feed_engine] Feed %d [%s] FAILED at stage=%r after %.2fs: %s "
            "| stages: %s | task=%s",
            feed_config_id, exec_id, current_stage, duration, error_msg,
            _stage_summary or "(none)",
            _task_identity(current_stage),
            exc_info=True,
        )
        try:
            # 2026-10-11 -- MERGED over a fresh read, never written whole:
            # on the spark_k8s lane the webhook or the reconciler closes the
            # row first (core/spark_k8s/completion.py::finalize_failure --
            # the job's headline and detail under spark_job_failure, the
            # reported-rows record, the stage named from its verdict) and
            # this write, made after the await raised, REPLACED that
            # stage_timings with the engine's own three keys and the stage
            # with query_spark_k8s (execution 1964).  The engine's keys win
            # for themselves; another finaliser's keys and its stage stand.
            _fresh_fail = db.get_feed_execution(exec_db_id) or {}
            _st_fail = dict(_fresh_fail.get("stage_timings") or {})
            _st_fail.update(stage_timings)
            _fail_upd: Dict[str, Any] = {"stage_timings": _st_fail}
            if not _fresh_fail.get("failed_stage"):
                _fail_upd["failed_stage"] = current_stage
            db.update_feed_execution(exec_db_id, _fail_upd)
        except Exception:
            pass

        # Cleanup temp files on failure
        _cleanup_temp_files(_temp_files)

        return db.get_feed_execution(exec_db_id) or exec_record
    finally:
        # Close every step row that never started.  A row left at
        # not_started forever reads as a HUNG step, and an operator
        # cannot tell that from one the engine simply did not enter --
        # the engine's stage list is genuinely dynamic (per backend,
        # per format, per destination, per integrity config).
        if _steps is not None:
            _steps.finalize("ended", reason=(
                "dry run: this step was not entered -- nothing is delivered "
                "or certified on a dry run" if dry_run else ""))
        # BF-415 — always release the cancellation event slot so the dict
        # doesn't grow unbounded across long-running pods.
        _unregister_cancel_event(exec_id)
        # 2026-10-11 -- give back what the run FREED but the allocators
        # still hold (Arrow's pool + glibc malloc_trim; debounced, off this
        # thread, never raises).  Found live: the scheduler stayed at 1,508
        # MiB after a 1M-row run that peaked at 1,524 (840 before it) -- the
        # queue worker's pod kept every run's high-water mark, so the next
        # run started from it.  The published API already releases after a
        # bulk stream (api/published_views/memory_guard.py); a feed is the
        # larger case.
        from core.process_memory import request_release
        request_release(f"feed execution {exec_id}")


#: A dry run's chain verdict -- the slot every reader checks
#: (``stage_timings.delivery_chain.verdict``): not delivered, not
#: suppressed, not failed; nothing was ATTEMPTED, by request.
DRY_RUN_CHAIN_VERDICT = "dry_run"
#: How long a dry run's produced file stays in the Download Centre.
DRY_RUN_DOWNLOAD_RETENTION_DAYS = 1
#: Lanes that deliver INSIDE the job; a dry run cannot hold the file back.
DRY_RUN_REFUSED_LANES = frozenset({"airflow", "spark_k8s"})


class _DryRunCertifiesNothing(Exception):
    """Raised inside the certificate build on a dry run so the ONE
    try/except that owns it skips the build: a certificate reconciling a
    file that never went would be a claim about a delivery that did not
    happen."""


class _NeverRaised(Exception):
    """A sentinel exception type nothing raises.

    Bound to ``_StepPlanRefused`` when the step model itself could not
    be imported, so the ``except`` clause below it is still evaluable.
    An unbound name inside an except clause raises NameError from
    within the handler -- the failure mode is a fail-open path that
    fails closed and blames the wrong thing.
    """


class FeedEmptyResultError(Exception):
    """The query returned 0 rows and the feed does not declare an empty file
    a valid delivery (``row_count_expect_zero``): no file is created or sent
    (2026-10-12)."""


class _FeedCancelled(Exception):
    """Raised by execute_feed when a cancellation signal is observed at a
    stage checkpoint.  Caught by the surrounding except so we transition
    the execution to ``cancelled`` instead of ``failed``."""
    pass


class _BfNativeJoinDeclined(Exception):
    """Phase 145.4 — Signal exception raised by ``_execute_duckdb_query``
    when the in-pod multi-worker dispatcher refused a JOIN query AND
    Spark Connect is configured.

    The exception bubbles up to the async ``_execute_native`` wrapper,
    which catches it and calls the existing async ``_execute_spark_connect``.
    Using an exception (vs a sentinel return) keeps the rest of the sync
    execution path's error semantics intact — if multi-worker AND Spark
    BOTH fail, the native fall-through still runs as the last resort.

    Mirrors BQB's BF-417 auto-fallback at execute_api.py:3041-3193, but
    routed through the async layer so we don't have to bridge
    ``threading.Event`` → ``asyncio.Event`` inside a worker-pool thread.
    """
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


# ---------------------------------------------------------------------------
# Native execution — DuckDB pipeline
# ---------------------------------------------------------------------------
async def _execute_native(feed_config: dict, execution_record: dict, db: Any = None) -> str:
    """
    Execute via existing DuckDB pipeline.
    Returns path to result parquet file.
    Uses _native_sem for concurrency control.

    Phase 145.4 — when the sync DuckDB path raises ``_BfNativeJoinDeclined``
    (multi-worker dispatcher refused a JOIN AND Spark Connect is enabled),
    catch it here and route the feed to the existing async
    ``_execute_spark_connect`` instead of trying to bridge sync→async
    inside a worker-pool thread.  Mirrors BQB's BF-417 auto-fallback but
    via the async exception-handler pattern.
    """
    db = db if db is not None else _db_manager  # transition fallback
    source_type = feed_config.get("source_type")
    source_id = feed_config.get("source_id")

    def _run():
        acquired = _native_sem.acquire(timeout=300)
        if not acquired:
            raise RuntimeError("Native execution pool exhausted — try again later")
        try:
            return _run_native_query(source_type, source_id, feed_config, db=db)
        finally:
            _native_sem.release()

    try:
        return await asyncio.to_thread(_run)
    except _BfNativeJoinDeclined as bf417:
        logger.info(
            "[feed_engine] Phase 145.4 BF-417 caught — feed %s rerouting to "
            "Spark Connect (%s)",
            feed_config.get("id"), bf417.reason,
        )
        # _execute_spark_connect handles source resolution + Spark execution
        # itself — same call pattern as when feed_router originally picks
        # "spark_connect" at the FEED level.  Returns parquet output path.
        try:
            return await _execute_spark_connect(feed_config, execution_record, db=db)
        except Exception as _spk_err:
            # Spark fallback failed too — re-raise the ORIGINAL native
            # decline so the user sees the real bottleneck (not a Spark
            # config issue).  feed_config can capture both in stage logs.
            logger.warning(
                "[feed_engine] Phase 145.4 BF-417 Spark fallback ALSO failed "
                "for feed %s (%s) — re-raising original native decline",
                feed_config.get("id"), _spk_err,
                exc_info=True,
            )
            raise bf417 from _spk_err


def _fanout_part_name(partition_key: str) -> str:
    """Deterministic per-partition part filename.

    Deterministic on purpose: a re-run of child 738 REPLACES its own part
    (§4.3 — "the manifest entry is replaced, not appended") instead of
    orphaning the old bytes next to the new ones.  The short digest keeps
    two keys that sanitize to the same text ('a/b' vs 'a_b') from
    colliding.
    """
    import hashlib as _hashlib
    san = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(partition_key))[:48] or "part"
    digest = _hashlib.sha256(
        str(partition_key).encode("utf-8")).hexdigest()[:8]
    return f"part_{san}_{digest}.parquet"


def _parquet_rows_and_bytes(path) -> tuple:
    """REAL rows (the parquet FOOTER) and bytes (stat) of one part file.

    Raises on an unreadable part: a part that cannot be counted cannot be
    certified, and certifying it anyway would make a completeness claim
    nobody measured — the exact defect class §9 exists to kill.
    """
    import pyarrow.parquet as pq
    p = Path(path)
    rows = int(pq.ParquetFile(str(p)).metadata.num_rows)
    return rows, int(p.stat().st_size)


def _assemble_fanout_manifest(parts_dir, completed_children, *, build_id,
                              feed_config_id, declared_count):
    """The parent :class:`PartsManifest` over the completed children's parts.

    One :class:`PartInfo` per child part carrying the rows the parquet
    FOOTER holds and the bytes on disk — never the counts anyone reported
    (one count written twice proves nothing, FR-CMP-08).

    Returns ``(manifest, certified_keys, problems)``.  ``certified_keys``
    names only the partitions whose part physically exists and is
    readable; ``problems`` names every completed child whose part is not —
    a completed DB row whose file is gone is RECORDED, not PRODUCED, and
    must not certify.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq
    from core.feed.parts_manifest import (
        PartInfo, PartsManifest, load_manifest,
    )
    parts_dir = Path(parts_dir)
    parts: list = []
    schemas: list = []
    certified: list = []
    problems: list = []
    total_rows = 0
    total_bytes = 0

    def _add_file(fpath: Path, rel_name: str) -> int:
        rows, nbytes = _parquet_rows_and_bytes(fpath)
        schema = pq.read_schema(str(fpath))
        schemas.append(schema)
        parts.append(PartInfo(index=len(parts), name=rel_name,
                              rows=rows, bytes=nbytes,
                              columns=[f.name for f in schema]))
        return rows

    for child in completed_children:
        key = str(child.get("partition_key"))
        raw = child.get("part_path")
        if not raw:
            problems.append(
                f"partition {key!r}: completed child row has NO part_path "
                f"— recorded is not produced")
            continue
        p = Path(raw)
        try:
            if p.is_dir():
                # A child big enough to trip the write ladder produced its
                # OWN parts dir.  Absorb its parts with their real per-file
                # rows/bytes; the child still contributes ONE certified
                # partition, expressed as however many physical files it
                # needed.
                if p.parent != parts_dir:
                    problems.append(
                        f"partition {key!r}: child parts dir {p} lives "
                        f"outside the run's parts dir {parts_dir}")
                    continue
                sub_manifest, _src = load_manifest(p)
                child_rows = 0
                child_bytes = 0
                for sp in sub_manifest.parts:
                    f = p / sp.name
                    r = _add_file(f, f"{p.name}/{sp.name}")
                    child_rows += r
                    child_bytes += parts[-1].bytes
                total_rows += child_rows
                total_bytes += child_bytes
            elif p.is_file():
                if p.parent != parts_dir:
                    # An injected executor produced the part elsewhere —
                    # COPY it into the run's parts dir (the child row keeps
                    # a valid pointer to what it recorded).
                    target = parts_dir / _fanout_part_name(key)
                    shutil.copy2(str(p), str(target))
                    p = target
                r = _add_file(p, p.name)
                total_rows += r
                total_bytes += parts[-1].bytes
            else:
                problems.append(
                    f"partition {key!r}: recorded part {raw} does not "
                    f"exist on disk")
                continue
        except Exception as exc:
            problems.append(f"partition {key!r}: part unreadable ({exc})")
            continue
        certified.append(key)

    schema_b64 = ""
    if schemas:
        # Incompatible child schemas RAISE here — children that cannot be
        # presented as one dataset cannot ship as one file, and papering
        # over it would be row corruption with a success status.
        import base64 as _b64
        unified = pa.unify_schemas(schemas)
        schema_b64 = _b64.b64encode(
            unified.serialize().to_pybytes()).decode("ascii")

    manifest = PartsManifest(
        parts=parts, schema_b64=schema_b64,
        total_rows=int(total_rows), total_bytes=int(total_bytes),
        status="building",
        sql_sha256=f"feed:{feed_config_id}:fanout",
        build_id=str(build_id or ""),
        source={"rung": "native_fanout",
                "feed_config_id": feed_config_id,
                "declared_partitions": int(declared_count)},
    )
    return manifest, certified, problems


async def _execute_native_fanout(feed_config: dict, execution_record: dict, *,
                                 db: Any, declaration: Any,
                                 feed_run_id: Optional[int],
                                 business_date=None, created_by: str = "",
                                 execute_one=None) -> tuple:
    """§4.2 — execute a DECLARED feed as one child per declared partition.

    Wiring only: the fan-out loop, its claim/skip rules and its failure
    isolation live in :mod:`core.feed.child_execution`; expansion and the
    derived parent status live in :mod:`core.feed.fanout`.  This function
    sequences them against the engine's native execution path and
    assembles the parts manifest the existing conversion + delivery
    pipeline consumes.

    Order (each step is the BRD's, in the BRD's order):
      1. ``expand_run`` — child rows in ``pending`` BEFORE anything
         executes (FR-RUN-05): cheap, restartable, and what makes the
         §9.3 set comparison possible;
      2. ``execute_children`` with a per-child executor that drives the
         engine's OWN native path (``_execute_native``) over a config
         copy carrying that child's partition value;
      3. ``recompute_parent`` — the parent status is DERIVED from the
         children, never written by the engine (FR-RUN-04);
      4. assemble the parent :class:`PartsManifest` from the COMPLETED
         child rows in the database — the DB, not this invocation's
         summary, so a restart that only ran the two missing children
         still certifies the parts an earlier attempt produced.

    Returns ``(parts_dir, state)`` where ``state["complete"]`` is the
    fail-closed shipping decision: True only when the parent verdict's
    set comparison holds AND every certified part physically exists.  The
    manifest is finalized (status ``complete``) only in that case —
    ``load_manifest`` and the delivery hop runner both refuse anything
    else, so a partial build cannot ship even if a later caller forgets
    to check.
    """
    from core.feed import child_execution as _child
    from core.feed import fanout as _fanout_mod

    if feed_run_id is None:
        # Fail CLOSED: without a parent run row there is nothing to attach
        # child rows to, no persisted declaration, and no feed-level claim
        # — and running the template single-file would execute SQL with an
        # unbound {{partition_key}}.  A loud refusal beats a wrong file.
        raise ValueError(
            f"feed {feed_config.get('id')} declares "
            f"{getattr(declaration, 'count', '?')} partition(s) but this "
            f"execution has no feed_run row — fan-out needs the run row "
            f"to create child file runs (FR-RUN-05); trigger the feed "
            f"through a path that creates one")

    exec_id = str(execution_record.get("execution_id") or "")

    # 1) FR-RUN-05 — child rows BEFORE anything executes.  Idempotent:
    #    a crash mid-expansion, or a restart after two children failed,
    #    re-expands without touching any existing child's state.
    expansion = _fanout_mod.expand_run(
        db, feed_run_id=int(feed_run_id), declaration=declaration,
        feed_config_id=feed_config.get("id"),
        business_date=business_date, created_by=created_by or None)

    # The run's parts directory — DETERMINISTIC per parent run so a
    # re-run of one child replaces its own part next to its siblings.
    parts_dir = Path(_cfg.output_dir) / f"fanout_run_{int(feed_run_id)}"
    parts_dir.mkdir(parents=True, exist_ok=True)

    if execute_one is None:
        _loop = asyncio.get_running_loop()

        def _native_execute_one(child_config: dict, partition_key: str):
            """Run ONE child through the engine's own native path.

            ``execute_children`` calls this from a worker thread, so the
            async native path is driven via the captured event loop —
            keeping the whole native machinery (semaphore, BF-417 Spark
            fallback) identical to a single-file run.
            """
            fut = asyncio.run_coroutine_threadsafe(
                _execute_native(child_config, execution_record, db=db),
                _loop)
            produced = fut.result()
            src = Path(produced)
            if src.is_dir():
                # The child tripped the write ladder — keep its parts dir
                # as a sub-directory of the run's parts dir.
                target = parts_dir / (
                    _fanout_part_name(partition_key)[:-len(".parquet")]
                    + ".parts")
                if target.exists():
                    shutil.rmtree(str(target), ignore_errors=True)
                shutil.move(str(src), str(target))
                from core.feed.parts_manifest import load_manifest
                sub_manifest, _sm_src = load_manifest(target)
                return str(target), int(sub_manifest.total_rows)
            target = parts_dir / _fanout_part_name(partition_key)
            # §4.3 — a re-run of one child REPLACES its own part.
            # shutil.move already delivers that on every platform (POSIX
            # rename replaces; Windows falls back to copy2, which
            # overwrites) — pinned by the re-run wiring test rather than
            # guarded by code that could never fire.
            shutil.move(str(src), str(target))
            rows, _nbytes = _parquet_rows_and_bytes(target)
            return str(target), rows

        execute_one = _native_execute_one

    # 2) The loop — claims, failure isolation, per-child binding — is
    #    child_execution's, mutation-tested there and not re-implemented.
    summary = await asyncio.to_thread(
        _child.execute_children, db, feed_config,
        feed_run_id=int(feed_run_id), execute_one=execute_one,
        pod_id=(os.environ.get("HOSTNAME") or "feed-engine"))

    # 3) FR-RUN-04 — the parent status is DERIVED from the children and
    #    the declared set; recompute_parent writes terminal verdicts to
    #    the feed_runs row.  Nothing else in the engine writes it.
    verdict = _fanout_mod.recompute_parent(db, int(feed_run_id))

    # 4) Certification inputs come from the DATABASE rows: a restart that
    #    executed only the missing children must still certify the parts
    #    an earlier attempt produced.
    children = db.list_feed_file_runs(int(feed_run_id))
    completed_rows = [c for c in children
                      if str(c.get("status")) == "completed"]
    manifest, certified, problems = _assemble_fanout_manifest(
        parts_dir, completed_rows, build_id=exec_id,
        feed_config_id=feed_config.get("id"),
        declared_count=getattr(declaration, "count", 0))
    for problem in problems:
        logger.error("[feed_engine] fan-out run %s: %s",
                     feed_run_id, problem)

    # The shipping decision, fail-closed: the DERIVED set comparison must
    # hold (every declared partition completed, nothing undeclared,
    # nothing in flight) AND every certified part must physically exist.
    complete = bool(getattr(verdict, "complete", False)) and not problems
    if complete:
        manifest.finalize(parts_dir)          # status=complete — shippable
    else:
        # Forensics only: load_manifest refuses a partial by default, so
        # the conversion/delivery pipeline CANNOT consume this build.
        manifest.write(parts_dir, partial=True)

    state = {
        "complete": complete,
        "parent_verdict": verdict,
        "summary": summary,
        "expansion": expansion,
        "certified": certified,
        "problems": problems,
        "total_rows": int(manifest.total_rows),
        "parts": len(manifest.parts),
        "stats": {
            "declared": int(getattr(declaration, "count", 0)),
            "expanded_new": int(getattr(expansion, "inserted", 0)),
            "expanded_existing": int(getattr(expansion, "existing", 0)),
            "completed": len(certified),
            "failed": len(summary.failed),
            "parts": len(manifest.parts),
            "total_rows": int(manifest.total_rows),
            "complete": complete,
        },
    }
    logger.info(
        "[feed_engine] fan-out run %s [%s]: %d declared -> %d part(s), "
        "%d row(s), complete=%s",
        feed_run_id, exec_id, getattr(declaration, "count", 0),
        len(manifest.parts), manifest.total_rows, complete)
    return str(parts_dir), state


async def _execute_spark_connect(feed_config: dict, execution_record: dict, db: Any = None) -> str:
    """
    Execute via Spark Connect — gRPC client to in-VPC Spark cluster.
    Spark reads s3a:// directly, returns Arrow batches.  No NFS
    pre-download, no Airflow DAG overhead.  Returns path to result
    parquet file.  Phase 131 deep-dive #13 (round 9).
    """
    db = db if db is not None else _db_manager  # transition fallback
    from core.spark_connect_executor import execute_query as _sc_execute
    from core.config import paths as _paths_cfg
    from api.models.query_models import QueryConfigModel
    from core.query_converter import convert_query_config_to_engine
    from core.feed.source_plan import (
        resolve_source_plan,
        resolve_side_query_config,
    )

    # ── ONE resolution, backend-aware (2026-08-04) ────────────────────
    # The same source-plan chokepoint the native path uses: inheritance
    # from referenced saved_query / sql_file / published_view, then the
    # backend capability gate.  A cross-source feed (explicit OR
    # inherited) is REFUSED loudly here — Spark Connect drives a single
    # session/DataFrame and cannot materialise + combine a secondary
    # side; running just the primary would emit half the data and
    # certify the run COMPLETE (the exact silent defect fixed on the
    # native path).  BF-599h: sync DB lookups wrapped via adb — this
    # coroutine runs on the event loop.
    await adb(resolve_source_plan, db, feed_config, "spark_connect")

    # Which SQL/config runs, on which connection — the SAME per-side
    # resolution the native path agrees on (secondary-shape substitution,
    # sql_file side selection + refusals, PV inheritance).  Replaces this
    # function's former private branch chain, which had none of it.
    _side = await adb(resolve_side_query_config, db, feed_config)
    qcfg = _side.query_config
    connection_id = _side.connection_id

    # Native-parity for raw-SQL shapes (sql_file / raw_sql feeds): these
    # carry no structured ``files`` list, but QueryConfigModel REQUIRES
    # one and the executor resolves referenced tables from it
    # (spark_connect_executor._register_tables_as_views).  The old
    # private branch built ``{"raw_sql", "connection_id"}`` for sql_file
    # and therefore ALWAYS failed model validation — sql_file feeds on
    # Spark Connect were broken as shipped (found by the parity control
    # test, 2026-08-04).  Mirror the native path's registered-view setup:
    # expose the connection's registered tables as __registered__ refs so
    # ``session.sql()`` can resolve them.
    if "files" not in qcfg:
        def _load_registered_files() -> list:
            out = []
            try:
                from core.connection_manager import ConnectionManager
                _cm = ConnectionManager(db)
                for _rt in (_cm.get_registered_tables(connection_id) or []):
                    _name = _rt.get("name") if isinstance(_rt, dict) else None
                    if _name:
                        out.append(f"__registered__:{_name}")
            except Exception as _rt_exc:
                logger.debug(
                    "[feed_engine] spark_connect: could not load "
                    "registered_tables: %s", _rt_exc,
                )
            return out
        qcfg["files"] = await adb(_load_registered_files)

    # BF-599h: connection lookup also wrapped.
    conn = await adb(db.get_connection_raw, connection_id) if connection_id else None
    if not conn:
        raise ValueError(f"Connection {connection_id} not found")
    conn_config = conn.get("config") or {}

    # Resolve user-scoped S3 credentials (same pattern as native path).
    if conn.get("connection_type") in ("s3", "aws_s3"):
        try:
            from core.credential_resolver import resolve_s3_for_consumer
            # BF-461: preflight refresh for long-running ops (Spark Connect
            # session may outlive the cached 55-min STS).  Pulls the
            # threshold from config so admins can tune.
            from core.config import aws_portal as _ap_cfg
            conn_config = resolve_s3_for_consumer(
                conn_config, feed_config,
                min_lifetime_seconds=_ap_cfg.preflight_min_lifetime_seconds,
            )
        except Exception as _cred_exc:
            logger.warning(
                "[feed_engine] spark_connect: credential resolve failed (%s) — using raw",
                _cred_exc,
            )

    # Phase 132.38 — apply the per-feed WHERE mapping (Static + consumer
    # Dynamic) on the Spark Connect path too.  Before this, large feeds
    # routed to Spark Connect bypassed the wrap entirely because this
    # function has its own source-resolution branch above and never calls
    # _route_source.  Both raw_sql + structured query_config shapes are
    # handled the same way the native path handles them.
    from core.feed_where_apply import (
        apply_where_to_raw_sql as _spc_wrap_raw,
        apply_where_to_query_config as _spc_wrap_qcfg,
    )
    if isinstance(qcfg.get("raw_sql"), str) and qcfg["raw_sql"].strip():
        qcfg["raw_sql"] = _spc_wrap_raw(qcfg["raw_sql"], feed_config) or qcfg["raw_sql"]
    else:
        _spc_wrap_qcfg(qcfg, feed_config)

    # Phase 4 (2026-08-23) -- calendar token substitution, NATIVE PARITY.
    # This path never called apply_to_raw_sql/apply_to_query_config, so a
    # feed whose SQL uses {{business_date}} / {{prev_business_day}} etc.
    # shipped the tokens LITERALLY to Spark -- a parse error at best.
    # Because the auto router sends 0.5M-10M-row feeds here when
    # spark_connect is enabled, a calendar-tokened feed started failing
    # the day it grew past the threshold.  Same helper, same feed_run,
    # same calendar as the native path (one date vocabulary).
    try:
        from core.feed.param_resolver import (
            apply_to_query_config as _spc_params_qcfg,
            apply_to_raw_sql as _spc_params_raw,
        )
        _spc_feed_run = feed_config.get("_feed_run") if isinstance(feed_config, dict) else None
        _spc_calendar = _load_calendar_for_feed(feed_config, db=db)
        if isinstance(qcfg.get("raw_sql"), str) and qcfg["raw_sql"].strip():
            qcfg["raw_sql"] = _spc_params_raw(
                qcfg["raw_sql"], feed_config, feed_run=_spc_feed_run,
                calendar=_spc_calendar)
        else:
            qcfg = _spc_params_qcfg(qcfg, feed_config, _spc_feed_run,
                                    _spc_calendar)
    except _TokenRefusal:
        # 2026-10-10 -- same gate as the native path: a declared {TOKEN}
        # that cannot be rendered fails the run instead of shipping as text.
        raise
    except Exception as _spc_sub_exc:
        logger.warning(
            "[feed_engine] spark_connect: parameter substitution failed "
            "(%s) -- running SQL as-is", _spc_sub_exc,
        )

    # Build the engine-shape QueryConfig.
    try:
        qc_model = QueryConfigModel(**qcfg)
        engine_qc = convert_query_config_to_engine(qc_model)
    except Exception as _qc_exc:
        raise ValueError(f"Invalid query_config for Spark Connect: {_qc_exc}")

    # Output path under the downloads dir; downstream stages convert/deliver.
    import uuid as _uuid
    output_dir = Path(str(_paths_cfg.downloads_dir))
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / f"feed_sc_{_uuid.uuid4().hex[:12]}.parquet")

    username = feed_config.get("_triggered_by_user") or "feed_engine"
    raw_sql = qcfg.get("raw_sql") or qcfg.get("custom_sql") or None

    # Dialect parity with the interactive Spark route (execute_api.py
    # ~1361): translate foreign-dialect raw SQL → Spark SQL before
    # execution.  Fail-open — translation errors keep the original SQL,
    # exactly like the interactive path.
    if raw_sql:
        try:
            from core.sql_dialect_translator import translate_to_spark as _to_spark
            _spark_sql, _detected = _to_spark(raw_sql)
            if _detected:
                logger.info(
                    "[feed_engine] spark_connect: SQL dialect '%s' "
                    "translated → spark for feed %s",
                    _detected, feed_config.get("id"),
                )
            raw_sql = _spark_sql
        except Exception as _ts_err:
            logger.debug(
                "[feed_engine] spark_connect dialect translation skipped "
                "(fail-open): %s", _ts_err,
            )

    # ── Row-level security (2026-08-17, F1) ───────────────────────────
    # Same feed-owner principal as the native path (core.feed.rls).
    # raw-SQL feeds get the policy rewrite in Spark grammar; structured
    # builder configs have NO SQL text to rewrite, so they are REFUSED
    # loudly when a referenced table is covered by an enabled policy —
    # running them would export unfiltered rows (silent RLS bypass).
    # Both are no-ops when RLS is disabled or no policy matches.
    from core.feed.rls import (
        secure_feed_sql as _sc_secure_feed_sql,
        assert_feed_tables_unrestricted as _sc_assert_unrestricted,
    )
    if raw_sql:
        raw_sql = await adb(
            _sc_secure_feed_sql, db, raw_sql, feed_config,
            connection_id=connection_id,
            connection_type="databricks",   # spark grammar for the rewrite
            request_id=feed_config.get("_exec_id"),
        )
    else:
        _sc_tables = []
        for _f in (qcfg.get("files") or []):
            if isinstance(_f, str) and _f.strip():
                _sc_tables.append(_f.split("__registered__:")[-1])
        await adb(
            _sc_assert_unrestricted, db, _sc_tables,
            feed_config, "spark_connect structured config",
        )

    async def _noop_progress(_msg):
        return  # feed_engine emits its own progress via _notify

    result = await _sc_execute(
        username=username,
        query_config=engine_qc,
        conn_config=conn_config,
        output_path=output_path,
        on_progress=_noop_progress,
        raw_sql=raw_sql,
    )

    # ── Truncation is NOT completion (2026-08-04) ─────────────────────
    # The executor caps results at spark_connect.max_result_rows and
    # reports the cap ONLY via on_progress — which is a no-op on this
    # path.  Before this guard, a feed larger than the cap produced a
    # silently-truncated parquet; conversion, integrity and the
    # completeness certificate all measured the SAME truncated file, so
    # the run was certified COMPLETE on partial data (the worst outcome
    # this product has — both reconciliation numbers wrong together).
    # The auto-router sends 0.5M–10M-row feeds here while the default
    # cap is 5M, so this was reachable by configuration alone.
    if result.get("truncated"):
        from core.config import spark_connect as _sc_cfg
        raise RuntimeError(
            f"Spark Connect truncated feed '{feed_config.get('name') or feed_config.get('id')}' "
            f"at {result.get('total_rows', 0):,} rows "
            f"(spark_connect.max_result_rows={int(_sc_cfg.max_result_rows):,}) — "
            f"the full result is larger.  Refusing to deliver a partial "
            f"feed: it would be certified COMPLETE on truncated data.  "
            f"Fix: raise spark_connect.max_result_rows, route this feed "
            f"to the airflow backend (distributed write, no result cap), "
            f"or narrow the feed's filters."
        )
    logger.info(
        "[feed_engine] spark_connect feed %s → %d rows in %.2fs",
        feed_config.get("id"),
        result.get("total_rows", 0),
        result.get("elapsed_seconds", 0),
    )
    return output_path


def _run_native_query(source_type: str, source_id: int, feed_config: dict, db: Any = None) -> str:
    """Top-level native dispatch.

    Routes to ``_run_cross_source_native_query`` when ``secondary_connection_id``
    is set on the feed config; otherwise to ``_run_single_source_native_query``.

    Phase 154 (2026-06-25) -- inherited cross-source from referenced
    source.  When the feed references a saved_query / sql_file that
    carries its own ``secondary_connection_id`` (BQB cross-conn save
    saved via 163ccd2; sql_files have always had cross-conn columns),
    LIFT those fields onto feed_config so the dispatch below picks
    the cross path.  Feed-level explicit values still WIN (operator
    overrides the inherited config).  Closes operator question
    2026-06-25: "how about feed gen n data flow".

    The cross-source path is opaque to callers -- it still returns a
    single parquet file path, so format conversion / compression /
    control-file writing downstream just sees one combined output
    and treats it identically to a single-source feed.
    """
    db = db if db is not None else _db_manager  # transition fallback
    if not feed_config.get("secondary_connection_id"):
        _inherit_cross_source_from_referenced(source_type, source_id, feed_config, db=db)
    if feed_config.get("secondary_connection_id"):
        return _run_cross_source_native_query(feed_config, db=db)
    return _run_single_source_native_query(source_type, source_id, feed_config, db=db)


def _inherit_cross_source_from_referenced(
    source_type: str, source_id: int, feed_config: dict, db: Any = None) -> None:
    """Lift cross-source fields from a referenced saved_query / sql_file /
    published_view onto ``feed_config`` IN-PLACE.

    2026-08-04 (backend parity): the implementation moved VERBATIM to
    ``core.feed.source_plan.inherit_cross_source`` so that EVERY backend
    (native, spark_connect, airflow) runs the SAME inheritance — the
    Spark path used to have its own source resolution that never
    inherited, so a feed over a cross-source saved query silently ran
    single-source there.  This delegator keeps the native call sites and
    semantics (fail-CLOSED, explicit feed fields win) unchanged.
    """
    db = db if db is not None else _db_manager  # transition fallback
    from core.feed.source_plan import inherit_cross_source
    inherit_cross_source(db, source_type, source_id, feed_config)


def union_pushdown_substitute_fn(feed_config: dict, feed_run: Any, calendar: Any):
    """The ``substitute_fn(sql, side)`` the same-engine UNION pushdown calls
    on EACH side's SQL (2026-10-11).  The side is stamped as ``_cross_side``
    so the one renderer (``param_resolver.apply_to_raw_sql`` ->
    ``sql_tokens.render_og_tokens``) applies -- and gates -- the token
    BINDINGS declared for THAT side: a binding on the secondary rewrites the
    secondary's literal and refuses there when it no longer matches, and
    never touches the primary's text.  Module level so the rule is testable
    without a Trino cluster."""
    from core.feed.param_resolver import apply_to_raw_sql as _sub

    def _fn(sql: str, side: str = "primary") -> str:
        return _sub(sql, {**feed_config, "_cross_side": side},
                    feed_run=feed_run, calendar=calendar)
    return _fn


def _resolve_reported_side_rows(db: Any, feed_config: dict, exec_record: Any) -> dict:
    """The engine's ONE read of the UPSTREAM CONTRACT (core/feed/upstream_
    contract.py): resolved here once, stored on ``feed_config`` as
    ``_upstream_contract`` (the query's message tokens on every lane read
    it), and returned as the reported-rows view the judge -- native and the
    Spark mirror -- reads.  The bound run's business date first, the
    execution row's second; none = a governed side is ``no_arrival``.
    Never raises into the run: an unreadable contract is said on the dict and
    REFUSED by the judge."""
    from core.feed import upstream_contract
    from core.feed.run_size import CONTRACT_BD_KEY, run_business_date
    bd = run_business_date(feed_config, exec_record)
    # the contract the ROUTER sized this run by (core/feed/run_size.py), for
    # the same business date: ONE read -- a message arriving in between must
    # not make the certification judge a different contract
    if (bd is not None and feed_config.get(CONTRACT_BD_KEY) == bd.isoformat()
            and isinstance(feed_config.get("_upstream_contract"), dict)):
        return upstream_contract.as_reported_side_rows(feed_config["_upstream_contract"])
    try:
        if getattr(db, "list_etl_dependency_mappings", None) is None:
            feed_config["_upstream_contract"] = {}
            return {}
        contracts = upstream_contract.resolve(db, feed_config, bd)
    except Exception as exc:  # noqa: BLE001 -- the judge refuses an unreadable contract
        logger.error("[feed_engine] Feed %s: the upstream contract could not be resolved: %s",
                     feed_config.get("id"), exc)
        contracts = {"_unreadable": f"the upstream contract could not be resolved ({exc})"}
    feed_config["_upstream_contract"] = contracts
    return upstream_contract.as_reported_side_rows(contracts)


def _certify_reported_rows_native(feed_config: dict, parquet_path: Any) -> Optional[dict]:
    """The native lane's count of each side, judged by THE rule
    (``reported_rows_certification.judge``).  None when no side is declared
    (nothing to record); a cross-source run's sides come from the
    pre-combine gate's record (``_cross_source``), a single-source run's
    from the materialised parquet's metadata."""
    expected = feed_config.get("_reported_side_rows")
    if not expected:
        return None
    if feed_config.get("secondary_connection_id"):
        xs = feed_config.get("_cross_source") or {}
        actual = {"primary": xs.get("primary_rows"), "secondary": xs.get("secondary_rows")}
    else:
        n = None
        try:
            if parquet_path:
                _cols, n = _side_columns_and_rows(str(parquet_path))
        except Exception as exc:  # noqa: BLE001 -- an uncountable side is judged unknown
            logger.warning("[feed_engine] Feed %s: the materialised output could not be "
                           "counted for the reported-rows certification (%s)",
                           feed_config.get("id"), exc)
        actual = {"primary": n, "secondary": None}
    record = _rr_judge(expected, actual)
    record["lane"] = "native"
    level = logger.error if record.get("failures") else logger.info
    level("[feed_engine] Feed %s reported-rows certification: %s -- %s",
          feed_config.get("id"), record.get("verdict"),
          "; ".join(str(s.get("reason")) for s in (record.get("sides") or {}).values())
          or "no side declared")
    return record


#: the attribute a side's read failure carries, and the record key it lands
#: under on the failed execution (stage_timings) -- 2026-10-12, the owner:
#: "how will you decide on-prem failed or on-cloud failed".
FAILED_SIDE_ATTR = "qs_failed_side"
FAILED_SIDE_KEY = "failed_side"


def _tag_failed_side(exc: BaseException, side: str) -> None:
    """Mark WHICH side's read raised (primary = the feed's own source, the
    cloud side; secondary = the second connection, on-prem).  Never masks
    the error; an exception that refuses attributes is left as it is."""
    try:
        if getattr(exc, FAILED_SIDE_ATTR, None) is None:
            setattr(exc, FAILED_SIDE_ATTR, side)
    except Exception:                                   # noqa: BLE001
        pass


def _run_cross_source_native_query(feed_config: dict, db: Any = None) -> str:
    """Pull primary + secondary sides into temp parquets, then combine via
    ``core.executors.cross_source_combine``.

    Returns the path to the combined parquet.  Temp side-files are
    deleted after a successful combine; left in place on failure so
    operators can inspect what each side produced.
    """
    db = db if db is not None else _db_manager  # transition fallback
    from core.executors.cross_source_combine import combine_sides, combine_spec

    # ── Cross-source runtime preflight (2026-08-04) ───────────────────
    # Same chokepoint the save-time validation uses (feed_api create /
    # update).  Catches configs that predate the save-time gate — a feed
    # saved before this shipped, or a referenced saved_query edited into
    # a broken shape AFTER the feed was saved.  ERROR verdicts refuse
    # loudly (the alternative is emitting half the data and certifying
    # it COMPLETE); a crash INSIDE the checker itself is fail-open so a
    # preflight bug can't take down working feeds.
    try:
        from core.feed.cross_source_preflight import preflight_feed_cross_source
        _pf_result = preflight_feed_cross_source(db, feed_config)
    except Exception as _pf_exc:
        logger.warning(
            "[feed-crosssource] preflight checker crashed for feed %s "
            "(%s: %s) — continuing without preflight",
            feed_config.get("id"), type(_pf_exc).__name__, _pf_exc,
        )
        _pf_result = None
    if _pf_result is not None and not _pf_result.ok:
        raise ValueError(_pf_result.format_report())

    primary_st  = feed_config.get("source_type")
    primary_sid = feed_config.get("source_id")

    # ── Same-engine UNION pushdown (2026-08-22, §4.3 step 1) ──────────
    # When both sides live on the SAME Trino/Starburst cluster under the
    # same principal, the UNION becomes ONE federated statement executed
    # as a single-source feed — no second materialisation, no combine
    # copy, and the statement rides whatever write rung the connection
    # declares (rung 1: the cluster writes the union straight to S3).
    # Refusals are DECLARED (logged + stamped on the execution) and the
    # existing two-side path runs unchanged.
    if (feed_config.get("combine_mode") or "union").strip().lower() == "union":
        _up_plan = None
        try:
            from core.feed.union_pushdown import (
                plan_same_engine_union, SameEngineUnionPlan, PushdownRefusal,
            )
            from core.feed.rls import secure_feed_sql as _up_secure
            _up_calendar = _load_calendar_for_feed(feed_config, db=db)
            _up_feed_run = feed_config.get("_feed_run")

            def _up_secure_fn(s, cid, ctype):
                return _up_secure(
                    db, s, feed_config,
                    connection_id=cid, connection_type=ctype,
                    request_id=feed_config.get("_exec_id"),
                )

            _up_sub_fn = union_pushdown_substitute_fn(
                feed_config, _up_feed_run, _up_calendar)

            _up_plan = plan_same_engine_union(
                db, feed_config,
                secure_sql_fn=_up_secure_fn,
                substitute_fn=_up_sub_fn,
            )
        except Exception as _up_exc:
            # A crash in the PLANNER is a refusal, not a failed feed —
            # the two-side path below is the always-correct floor.
            from core.feed.union_pushdown import PushdownRefusal as _UPR
            _up_plan = _UPR(f"planner crashed "
                            f"({type(_up_exc).__name__}: {_up_exc})")
            logger.warning(
                "[union-pushdown] feed %s planner crashed — running the "
                "two-side path: %s", feed_config.get("id"), _up_exc,
            )
        feed_config["_union_pushdown"] = _up_plan.to_dict()
        if isinstance(_up_plan, SameEngineUnionPlan):
            _up_conn = db.get_connection_raw(_up_plan.connection_id)
            _up_out_dir = Path(_cfg.output_dir) / "tmp"
            _up_out_dir.mkdir(parents=True, exist_ok=True)
            _up_out = str(_up_out_dir
                          / f"native_union_{uuid.uuid4().hex[:12]}.parquet")
            return _execute_duckdb_query(_up_plan.sql, _up_conn, _up_out,
                                         feed_config, db=db)
        logger.info(
            "[union-pushdown] feed %s DECLINED (%s) — two-side path runs",
            feed_config.get("id"), _up_plan.reason,
        )

    # Stamp which SIDE of the cross feed each execution serves so the
    # source resolvers can pick the right SQL: sql_file splits on the
    # ``-- ===SECONDARY===`` separator; saved_query substitutes
    # secondary_raw_sql / secondary_query_config on the secondary side.
    # Before this stamp existed, BOTH sides executed the PRIMARY SQL —
    # a saved query with a distinct secondary side silently emitted
    # primary-side rows twice (verified by execution 2026-08-04).
    # 2026-10-12 -- re-run ONLY the failed side (core/feed/side_resume.py):
    # a re-run may carry the other side's KEPT rows; they stand in for a
    # read only if they still verify NOW, else both sides are read and the
    # execution says why.
    from core.feed import side_resume as _sr
    _bd_sr = _run_business_date(feed_config)
    _reuse = feed_config.get("_reuse_side") if isinstance(feed_config.get("_reuse_side"), dict) else None
    _reused_path: Dict[str, str] = {}
    if _reuse:
        _why = _sr.verify(db, feed_config, _reuse, _bd_sr)
        if _why is None:
            # a LINK the merge may consume; the kept file stays for another try
            try:
                _reused_path[str(_reuse["side"])] = _sr.working_copy(
                    _reuse, str(Path(_cfg.output_dir) / "tmp"))
            except Exception as _wc_exc:                # noqa: BLE001 -- read both instead
                _why = f"the kept rows could not be staged for reuse ({_wc_exc})"
        if _why is None:
            feed_config["_reused_side"] = {**{k: _reuse.get(k) for k in
                                              ("side", "rows", "execution_id", "path")}}
            logger.info("[feed_engine] feed %s: the %s side is REUSED from execution %s "
                        "(%s rows) -- only the failed side is read", feed_config.get("id"),
                        _sr.SIDE_WORDS.get(_reuse["side"]), _reuse.get("execution_id"), _reuse.get("rows"))
        else:
            feed_config["_reuse_refused"] = _why
            logger.warning("[feed_engine] feed %s: kept rows NOT reused -- %s; both sides are read",
                           feed_config.get("id"), _why)
    feed_config["_cross_side"] = "primary"
    try:
        primary_path = _reused_path.get("primary") or _run_single_source_native_query(
            primary_st, primary_sid, feed_config, db=db)
    except Exception as _side_exc:
        _tag_failed_side(_side_exc, "primary")
        raise

    # The secondary side's feed_config comes from THE one builder every
    # lane uses (2026-10-11, core/feed/source_plan.py::secondary_side_config):
    # connection swap, source fallback to the primary, ``_cross_side``, and
    # a raw_sql second side's ``query_params.secondary_raw_sql`` as its SQL.
    from core.feed.source_plan import secondary_side_config as _secondary_side_config
    secondary_fc = _secondary_side_config(feed_config)
    try:
        secondary_path = _reused_path.get("secondary") or _run_single_source_native_query(
            secondary_fc["source_type"], secondary_fc["source_id"], secondary_fc,
            db=db,
        )
        # the second side's partitioned-read record lives on ITS copy
        _sec_pr = secondary_fc.get("_partitioned_read")
        if isinstance(_sec_pr, dict) and _sec_pr is not feed_config.get("_partitioned_read"):
            feed_config.setdefault("_partitioned_read", {}).update(_sec_pr)
    except Exception as _side_exc:
        _tag_failed_side(_side_exc, "secondary")
        # the CLOUD side was read fine: KEEP it, so a re-run reads only this side
        # keeping NEVER masks why the run failed: any trouble here is logged
        try:
            if "primary" not in _reused_path:
                _kept = _sr.keep(db, feed_config, "primary", primary_path,
                                 execution_id=str(feed_config.get("_exec_id") or "x"),
                                 business_date=_bd_sr, output_dir=str(_cfg.output_dir))
                if _kept:
                    feed_config["_kept_side"] = _kept
            else:
                feed_config["_kept_side"] = dict(_reuse or {})   # still valid for the next try
        except Exception as _keep_exc:                  # noqa: BLE001
            logger.warning("[feed_engine] feed %s: the CLOUD side could not be kept (%s) -- "
                           "a re-run reads both sides", feed_config.get("id"), _keep_exc)
        raise

    # 2026-10-14 -- a side's result STAGED on S3, validated, brought back
    # (core/feed/side_staging.py): only when backend_config.stage_to_s3
    # declares it; the merge then reads the validated copy
    from core.feed.side_staging import stage_side as _stage_side, staging_config as _staging_cfg
    _staged = []
    for _sd in ("primary", "secondary"):
        _scfg = _staging_cfg(feed_config, _sd)
        if _scfg is None:
            continue
        _src = primary_path if _sd == "primary" else secondary_path
        _new, _rec = _stage_side(_src, _scfg, execution_id=str(feed_config.get("_exec_id") or ""),
                                 side=_sd)
        if _sd == "primary":
            primary_path = _new
        else:
            secondary_path = _new
        _staged.append(_rec)

    output_dir = Path(_cfg.output_dir) / "tmp"
    output_dir.mkdir(parents=True, exist_ok=True)
    combined_path = str(output_dir / f"combined_{uuid.uuid4().hex[:12]}.parquet")

    combine_mode = (feed_config.get("combine_mode") or "union").strip().lower()
    logger.info(
        "[feed_engine] Cross-source combine (%s) — primary=%s secondary=%s",
        combine_mode, primary_path, secondary_path,
    )

    # ── THE merge-by-name gate + disclosure (2026-10-10) ──────────────
    # Both sides are materialised; before ANY combine runs, the ONE plan
    # (core/feed/merge_by_name.py, mirrored into the Spark job) decides the
    # alignment -- and REFUSES an incompatible same-named column, failing
    # the run with every such column named.  The per-side row counts are
    # read from the parquet metadata here, so the certificate's
    # "rows == primary + secondary" is checkable from the execution record
    # (files_metadata.cross_source) rather than inferred.
    _cross_disc: dict = {"combine_mode": combine_mode}
    if _staged:
        _cross_disc["staged"] = _staged
    try:
        _p_cols, _p_rows = _side_columns_and_rows(primary_path)
        _s_cols, _s_rows = _side_columns_and_rows(secondary_path)
    except Exception as _side_exc:  # noqa: BLE001 -- the combine below is the gate of record
        # A side this process cannot DESCRIBE (not a parquet file / parts
        # dir on local disk -- a lane that materialises elsewhere) is not
        # judged here: the combine itself refuses an unreadable side
        # (combine_select_sql) and applies the same plan.  Said on the
        # record, never a silent skip.
        _p_cols = _s_cols = None
        _p_rows = _s_rows = None
        _cross_disc["sides_unreadable_here"] = f"{type(_side_exc).__name__}: {_side_exc}"[:300]
        logger.warning("[feed-crosssource] feed %s: sides not describable before the "
                       "combine (%s) -- the combine's own plan decides",
                       feed_config.get("id"), _side_exc)
    # THE shape (core/feed/merge_by_name.py::cross_source_record) -- the
    # Spark job builds the same one through its mirror, so an auditor reads
    # primary + secondary == expected == combined identically on both lanes.
    _cross_disc.update(_cross_source_record(combine_mode, _p_rows, _s_rows,
                                            lane="native"))
    if combine_mode != "join" and _p_cols is not None:
        try:
            _merge_plan = _plan_merge(_p_cols, _s_cols)
        except _MergeRefused as _mr_exc:
            feed_config["_cross_source"] = dict(
                _cross_disc, merge_refused=str(_mr_exc),
                incompatible=[list(x) for x in _mr_exc.incompatible])
            raise ValueError(str(_mr_exc)) from _mr_exc
        _cross_disc["merge"] = _merge_plan.disclosure()
        if _merge_plan.promotions or _merge_plan.renames:
            logger.warning("[feed-crosssource] feed %s merge-by-name notes: %s",
                           feed_config.get("id"), _merge_plan.disclosure())
    feed_config["_cross_source"] = _cross_disc

    # ── Zero-copy UNION combine (2026-08-22, §4.3 step 3) ─────────────
    # A UNION of two already-materialised sides needs NO third copy: the
    # side files/parts BECOME the parts of one manifest whose unified
    # by-name schema the readers pad/cast to per batch (the ``__empty__``
    # semantics of build_union_combine_sql, applied at READ time).  Disk
    # cost drops from 2×(A+B) to A+B and the combine pass disappears.
    # Any doubt (schemas that will not unify, unreadable side) REFUSES
    # with a logged reason and the DuckDB combine below runs as before.
    if combine_mode != "join":
        from core.config import feed_generation as _fg_cc
        if bool(getattr(_fg_cc, "cross_union_zero_copy", True)):
            try:
                from core.executors.cross_source_combine import (
                    build_union_parts_manifest,
                )
                combined_dir = str(
                    output_dir / f"combined_{uuid.uuid4().hex[:12]}.parts")
                _zc_manifest = build_union_parts_manifest(
                    primary_path, secondary_path, combined_dir)
                logger.info(
                    "[feed_engine] Cross-source UNION combined ZERO-COPY: "
                    "%d rows across %d part(s) → %s",
                    _zc_manifest.total_rows, len(_zc_manifest.parts),
                    combined_dir,
                )
                _cross_disc["combine"] = "zero_copy_manifest"
                _cross_disc["combined_rows"] = int(_zc_manifest.total_rows)
                return combined_dir
            except Exception as _zc_exc:
                logger.warning(
                    "[feed-crosssource] zero-copy union combine refused "
                    "(%s: %s) — falling back to the DuckDB combine",
                    type(_zc_exc).__name__, _zc_exc,
                )

    # THE cross-source combine (2026-10-04) -- the one every surface uses:
    # the one join vocabulary ("outer" == "full", which the old direct
    # builder call refused), key types harmonised and DISCLOSED, a parts
    # DIRECTORY read through a local glob.  No row limit: a feed delivers
    # the whole combine.  Side files are left in place on failure for
    # postmortem (combine_sides removes only its own partial output).
    _feed_spec = combine_spec(combine_mode, feed_config.get("join_config") or {},
                              default_mode="union")
    _feed_outcome = combine_sides(primary_path, secondary_path, combined_path,
                                  _feed_spec)
    _cross_disc.update(_feed_outcome.disclosure())
    # combine_sides counts nothing per side (execute_cross_source does);
    # the parquet-metadata counts read above are the truth here.
    if _p_rows is not None:
        _cross_disc["primary_rows"], _cross_disc["secondary_rows"] = _p_rows, _s_rows
    _cross_disc["combine"] = "duckdb"
    _rows_out = getattr(_feed_outcome, "total_rows", None)
    _cross_disc["combined_rows"] = int(_rows_out) if _rows_out is not None else None
    feed_config["_cross_source"] = _cross_disc
    if _feed_outcome.key_casts or _feed_outcome.join_health != "ok":
        logger.warning("[feed-crosssource] feed %s combine notes: %s",
                       feed_config.get("id"), _feed_outcome.disclosure())

    # Combine succeeded — clean up side parquets (temp dir is also
    # swept by ``cleanup_old_executions`` so a failure to unlink here
    # is non-fatal).
    for p in (primary_path, secondary_path):
        try:
            _p_obj = Path(p)
            if _p_obj.is_dir():
                import shutil as _sh
                _sh.rmtree(p, ignore_errors=True)
            else:
                _p_obj.unlink(missing_ok=True)
        except OSError:
            pass

    return combined_path


def _side_columns_and_rows(path: str) -> tuple:
    """``([(name, arrow_type), ...], rows)`` of a materialised side -- a
    single parquet file or a parts directory (its COMPLETE manifest).  Read
    from metadata only; no row is loaded.  Raises when the side cannot be
    described: a side that cannot be described cannot be aligned."""
    import pyarrow.parquet as _pq
    from core.feed.parts_manifest import is_parts_dir, load_manifest
    if os.path.isdir(path):
        if not is_parts_dir(path):
            raise ValueError(f"{path} is a directory but not a parts directory")
        manifest, _src = load_manifest(path)
        schema = manifest.arrow_schema()
        return ([(f.name, str(f.type)) for f in schema], int(manifest.total_rows))
    pf = _pq.ParquetFile(path)
    try:
        return ([(f.name, str(f.type)) for f in pf.schema_arrow],
                int(pf.metadata.num_rows))
    finally:
        pf.close()


def _apply_secondary_shape(qcfg: dict, feed_config: dict, source_label: str) -> dict:
    """Return the query_config this SIDE of a cross feed must execute.

    2026-08-04 (backend parity): implementation moved VERBATIM to
    ``core.feed.source_plan.apply_secondary_shape`` so the Spark path
    substitutes the SAME saved secondary shape the native path does
    (before, the Spark path re-ran the primary SQL on the secondary
    side by construction — it never knew secondary shapes existed).
    """
    from core.feed.source_plan import apply_secondary_shape
    return apply_secondary_shape(qcfg, feed_config, source_label)


def _run_single_source_native_query(source_type: str, source_id: int, feed_config: dict, db: Any = None) -> str:
    """
    Synchronous native query execution.
    Returns path to output parquet file.
    """
    db = db if db is not None else _db_manager  # transition fallback
    output_dir = Path(_cfg.output_dir) / "tmp"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(output_dir / f"native_{uuid.uuid4().hex[:12]}.parquet")

    # 2026-09-03 -- THE BRANCH CHAIN IS GONE.  Every source kind, SQL
    # included, dispatches by NAME through the step registry
    # (core.feed.steps): the four SQL kinds are builtin steps whose
    # bodies moved VERBATIM to core/feed/sources/sql_branches.py
    # (golden-equivalence pinned by
    # tests/test_feed_sql_sources_golden_2026_09_03.py); api and
    # landed_file are builtin steps; anything else comes from the
    # marker-guarded discovery root.  A miss is a stated three-outcome
    # refusal (registered / failed-to-load naming the file / unknown
    # listing what IS registered) -- never the old two-outcome
    # "Unsupported source type" that pointed operators at the DB row
    # when a module was missing.
    from core.feed.sources.base import SourceRequest
    from core.feed.steps import get_step
    _step = get_step("source", source_type)
    return _step.resolve(SourceRequest(
        feed_config=feed_config, output_path=output_path,
        db=db, source_id=source_id))


def _load_calendar_for_feed(feed_config: dict, db: Any = None):
    """Look up the BusinessCalendar object referenced by the feed's
    ``calendar_name`` field.  Returns None when the feed has no
    calendar attached (in which case the param resolver falls back
    to plain calendar-day arithmetic).

    Cached at the BusinessCalendar layer; a per-tick lookup is cheap.
    """
    db = db if db is not None else _db_manager  # transition fallback
    if not feed_config or db is None:
        return None
    name = feed_config.get("calendar_name")
    if not name:
        return None
    try:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        repo = BusinessCalendarRepo(db)
        spec = repo.get(name)
        if not spec:
            return None
        return BusinessCalendar(spec)
    except Exception as exc:
        logger.debug("[feed_engine] calendar load for %r failed: %s", name, exc)
        return None


def _rung1_engine_unload(connector, sql: str, feed_config: dict,
                         output_path: str, cancel_event,
                         ladder_audit: dict) -> tuple:
    """Write-ladder rung 1 inside the native branch (2026-08-22).

    The ENGINE writes parquet parts to S3 (Trino CTAS with
    external_location); QS verifies footer counts against the engine's
    own count, then materialises the parts locally as BYTES for the
    conversion/delivery chain.  No row of the result ever exists as a
    Python object in this process — the per-row loop that made 140M
    take hours is gone; what remains is a byte copy at network speed.

    Returns ``(result_path, rows_written)`` where result_path is either
    the standard single parquet (0 or 1 part — byte-compatible with the
    streaming path) or a parts DIRECTORY carrying a manifest.

    Failure posture: EngineUnloadError propagates — an operator who
    DECLARED the engine_write capability wants a broken declaration to
    fail loudly, not to silently re-run 140M rows through the pod for
    hours.  Per-feed ``backend_config.write_rung='native_stream'`` is
    the explicit escape hatch.
    """
    import os
    from core.feed.engine_unload import (
        run_engine_unload, materialize_parts_locally, build_unload_s3_client,
    )
    res = run_engine_unload(
        connector, sql,
        feed_config=feed_config,
        exec_id=str(feed_config.get("_exec_id") or ""),
        cancel_event=cancel_event,
    )
    ladder_audit.update({
        "rows_reported": res.rows_reported,
        "rows_verified": res.manifest.total_rows,
        "verified": bool(res.verified),
        "ctas_query_id": res.query_id,
        "parts": len(res.manifest.parts),
        "external_location": res.external_location,
    })
    if res.manifest.total_rows == 0 and not res.manifest.parts:
        # Typed-empty single parquet (columns from the LIMIT-0 probe) —
        # byte-compatible with the streaming path's empty fallback.
        # 2026-10-11 -- TYPED BY THE ENGINE (the probe's own types through
        # the one declared-type mapping the streaming writer uses): every
        # column used to be a string, so a cross-source feed whose cloud
        # island had no rows yet refused the merge against a typed on-prem
        # side ("BUSINESS_CLOSE_DATE is string ... and date32[day]", live).
        import pyarrow as pa
        import pyarrow.parquet as pq
        from core.parquet_stream_writer import _arrow_type_for_declared
        declared = {c.get("name", ""): c.get("type")
                    for c in (res.empty_column_types or []) if isinstance(c, dict)}
        schema = pa.schema([
            pa.field(n, _arrow_type_for_declared(declared.get(n), pa) or pa.string())
            for n in res.empty_columns])
        pq.write_table(schema.empty_table(), output_path, compression="zstd")
        return output_path, 0
    caps = (connector.write_capabilities() or {}).get("engine_write") or {}
    s3c = build_unload_s3_client(connector.config,
                                 str(caps.get("s3_location") or ""))
    parts_dir = output_path + ".parts"
    local = materialize_parts_locally(res.manifest, s3c, parts_dir,
                                      cancel_event=cancel_event)
    if len(local.parts) == 1:
        # One part → the standard single-file artifact; downstream
        # conversion/delivery see exactly what they always saw.
        from core.feed.parts_manifest import MANIFEST_NAME
        only = os.path.join(parts_dir, local.parts[0].name)
        os.replace(only, output_path)
        try:
            os.unlink(os.path.join(parts_dir, MANIFEST_NAME))
            os.rmdir(parts_dir)
        except OSError:
            pass
        return output_path, local.total_rows
    return parts_dir, local.total_rows


def _rung3_stream_parts(connector, sql: str, conn_type: str,
                        feed_config: dict, output_path: str, cancel_event,
                        chunk_size: int, max_rows: int) -> tuple:
    """Write-ladder rung 3 inside the native branch (2026-08-22): the
    part-rotating native stream.  Returns ``(result_path, rows_written)``
    — single parquet when 0/1 part (byte-compatible), else a parts dir.
    """
    import os
    from pathlib import Path as _P
    from core.connector_to_parquet import execute_sql_to_parts
    # Resume opt-in: the persisted per-feed knob backend_config.parts_resume
    # (a nightly 140M feed that crashes at 3am resumes on the retry), or the
    # in-band _resume_parts stamp for programmatic callers.  Default OFF —
    # resume splices at a row boundary and is guarded (sql hash + stable
    # ORDER BY) inside execute_sql_to_parts, but the operator opts in.
    _bc_cfg = feed_config.get("backend_config") or {}
    resume_requested = bool(
        feed_config.get("_resume_parts")
        or (isinstance(_bc_cfg, dict) and _bc_cfg.get("parts_resume")))
    if resume_requested and feed_config.get("id"):
        # Resume needs a DETERMINISTIC location across executions.
        parts_dir = str(_P(output_path).parent
                        / f"parts_feed_{feed_config['id']}")
    else:
        parts_dir = output_path + ".parts"
    try:
        from core.sql_filter_wrapper import dialect_for_connection_type
        _dialect = dialect_for_connection_type(conn_type)
    except Exception:
        _dialect = ""
    from core.config import feed_generation as _fg
    _rows_per_part = int(getattr(_fg, "parts_rows_per_part", 5_000_000))
    _stream_res = execute_sql_to_parts(
        connector, sql, parts_dir,
        rows_per_part=_rows_per_part,
        row_limit=(max_rows if max_rows > 0 else None),
        cancel_event=cancel_event,
        chunk_size=chunk_size,
        resume=resume_requested,
        dialect=_dialect,
        source_meta={
            "feed_id": feed_config.get("id"),
            "connection_type": conn_type,
        },
    )
    rows_written = int(_stream_res.get("total_rows") or 0)
    if int(_stream_res.get("parts") or 0) <= 1:
        from core.feed.parts_manifest import (
            load_manifest, MANIFEST_NAME,
        )
        manifest, _src = load_manifest(parts_dir)
        if manifest.parts:
            os.replace(os.path.join(parts_dir, manifest.parts[0].name),
                       output_path)
        try:
            os.unlink(os.path.join(parts_dir, MANIFEST_NAME))
            os.rmdir(parts_dir)
        except OSError:
            pass
        return output_path, rows_written
    return parts_dir, rows_written


def _execute_duckdb_query(sql: str, conn: dict, output_path: str, feed_config: dict, db: Any = None) -> str:
    """Execute a SQL query via DuckDB and write results to parquet.

    Phase 131 deep-dive #13 (round 7): refactored to reuse the canonical
    read path used by BQB / CQB / ``/api/execute``:
      - ``core.duckdb_views.setup_registered_views`` for view setup
        (gives us iceberg-metadata cache, parquet column-stats pruning,
        DuckDB object cache, persistent S3 file cache, smart-predownload
        readers — all the perf work from Phase 140 / BF-252–257).
      - ``to_arrow_reader`` + ``ParquetWriter`` for streaming output
        (constant memory regardless of result size — replaces the
        ``fetch_arrow_table`` buffering that OOM'd on >5M-row feeds).

    Calendar-aware parameter substitution still happens up front
    (``{{business_date}}`` etc.).  S3 credential resolution still uses
    ``resolve_s3_for_consumer`` to thread the triggering user's portal
    password through to the vault.
    """
    db = db if db is not None else _db_manager  # transition fallback
    import pyarrow as pa
    import pyarrow.parquet as pq
    import time as _time_feed

    # Phase 156 deep-dive (2026-06-26) -- feed-gen completion timer.
    # The hook helper fires at every successful return.  Pre-fix:
    # feed-gen ran through maybe_dispatch_multi_worker which records
    # the engine_router decision but NOT brain prewarm + route history
    # + sql-cache.  Memo populate already works via iceberg_reader.
    _feed_t0 = _time_feed.monotonic()

    def _feed_brain_complete(total_rows: int = 0, from_multi_worker: bool = False,
                             from_brain_cache: bool = False) -> None:
        """Fire Phase 155/156 brain hooks at the feed's success exit.
        Strategic chokepoint -- one helper, called at every success
        return.  Fail-OPEN at every step (won't break the feed run)."""
        try:
            from core.brain_completion_hooks import phase156_completion_hooks
            # Build a minimal query_config_dict so the prewarm + route
            # history hooks can find bucket / prefix / snapshot.
            qcd = {}
            try:
                qcfg = (feed_config or {}).get("query_config") or {}
                qcd["registered_tables"] = qcfg.get("registered_tables") or []
                # Snapshot stamped by setup_registered_views; surface it.
                if qcfg.get("_iceberg_snapshot_id"):
                    qcd["_iceberg_snapshot_id"] = qcfg["_iceberg_snapshot_id"]
            except Exception:
                pass
            _engine_key = ("result_cache" if from_brain_cache
                           else "multi_worker" if from_multi_worker else "single")
            phase156_completion_hooks(
                raw_sql=sql,
                query_config_dict=qcd,
                output_file_path=output_path if output_path else None,
                stats={"total_rows": int(total_rows or 0),
                       "from_brain_cache": bool(from_brain_cache),
                       "engine_meta": {"engine": _engine_key}},
                query_t0_monotonic=_feed_t0,
                db_manager=db,
            )
        except Exception as _bh_exc:
            logger.debug("[feed_engine] brain hooks skipped: %s", _bh_exc)

    # ── Calendar-aware param substitution ─────────────────────────────
    try:
        from core.feed.param_resolver import apply_to_raw_sql
        feed_run = feed_config.get("_feed_run") if isinstance(feed_config, dict) else None
        calendar = _load_calendar_for_feed(feed_config, db=db)
        sql = apply_to_raw_sql(sql, feed_config, feed_run=feed_run, calendar=calendar)
    except _TokenRefusal:
        # 2026-10-10 -- a declared {TOKEN} with no value, or a value no SQL
        # literal can hold, is a correctness gate: "running SQL as-is"
        # would run WHERE CODE='{SYSTEM_ENTITY}', match nothing and certify
        # an empty file.  It fails the run, naming the token.
        raise
    except Exception as _psub_exc:
        logger.warning(
            "[feed_engine] feed %s: parameter substitution failed (%s) — running SQL as-is",
            (feed_config or {}).get("id"), _psub_exc,
        )

    conn_config = conn.get("config") or {}
    conn_type = conn.get("connection_type") or conn_config.get("type", "")

    # ── Resolve user-scoped credentials for S3 (Phase 131 deep-dive #8) ─
    if conn_type in ("s3", "aws_s3"):
        try:
            from core.credential_resolver import resolve_s3_for_consumer
            # BF-461: preflight refresh — feeds can run for 30+ minutes,
            # cached creds within 10 min of expiry would die mid-scan.
            # Force a fresh ~1h-TTL session BEFORE the feed kicks off.
            from core.config import aws_portal as _ap_cfg
            conn_config = resolve_s3_for_consumer(
                conn_config, feed_config,
                min_lifetime_seconds=_ap_cfg.preflight_min_lifetime_seconds,
            )
        except Exception as _cred_exc:
            logger.warning(
                "[feed_engine] feed %s: credential resolve failed (%s) — proceeding with raw config",
                (feed_config or {}).get("id"), _cred_exc,
            )

    # ── Round 11: SQL-connector path (Snowflake / Trino / Starburst /
    #    Databricks / Oracle / Athena).  These are real databases that
    #    speak their own SQL dialect — DuckDB can't execute Snowflake
    #    SQL.  Route to the connector's native execute_query_streaming
    #    and write Arrow batches to parquet directly.  Constant memory
    #    regardless of result size — same streaming pattern feeds use
    #    for DuckDB in round 7.
    # 2026-08-17 (F6) — the connector-type set is IMPORTED from the ONE
    # registry (core.connectors.SQL_CONNECTOR_TYPES == _REGISTRY keys).
    # This function used to carry the FOURTH hand-rolled copy of the list;
    # a connector added to the registry then worked on the interactive
    # path but silently fell through to the DuckDB/S3 branch here (which
    # cannot execute it).  One source of truth, no re-listing.
    from core.connectors import (
        get_connector,
        SQL_CONNECTOR_TYPES as _SQL_CONNECTOR_TYPES,
    )
    if conn_type not in _SQL_CONNECTOR_TYPES:
        # a declared partition key on a FILE side (S3 / local): the files
        # are the parts -- said on the run (core/feed/partitioned_read.py)
        from core.feed.partitioned_read import note_read_by_files as _note_by_files
        _note_by_files(feed_config, conn_type)
    if conn_type in _SQL_CONNECTOR_TYPES:
        from core.config import query_engine as _qe_cfg_conn
        # athena uses S3 credentials under the hood — resolve them.
        if conn_type == "athena":
            try:
                from core.credential_resolver import resolve_s3_for_consumer
                # BF-461: preflight refresh for long-running athena feeds.
                from core.config import aws_portal as _ap_cfg
                conn_config = resolve_s3_for_consumer(
                    conn_config, feed_config,
                    min_lifetime_seconds=_ap_cfg.preflight_min_lifetime_seconds,
                )
            except Exception as _ath_exc:
                logger.warning(
                    "[feed_engine] athena credential resolve failed (%s) — proceeding with raw",
                    _ath_exc,
                )

        # ── Row-level security (2026-08-17, F1) ──────────────────────
        # Feeds used to run with NO principal: secure_sql was never
        # called, so an RLS-protected Snowflake/Trino table could be
        # exported wholesale to SFTP/email/S3.  The execution principal
        # is the FEED OWNER (created_by) — see core.feed.rls for the
        # full design decision.  No-op when RLS is disabled or no policy
        # matches; HARD-FAILS when enforcement itself errors.
        from core.feed.rls import secure_feed_sql as _secure_feed_sql
        sql = _secure_feed_sql(
            db, sql, feed_config,
            connection_id=conn.get("id"),
            connection_type=conn_type,
            request_id=feed_config.get("_exec_id"),
        )

        # Row limit.  2026-08-13: ``<= 0`` MEANS UNLIMITED.  2026-08-17
        # (F2): ABSENT also means unlimited — the old ``is None`` fall-
        # through to ``feed_generation.max_output_rows`` silently baked a
        # 1,000,000-row cap into every feed whose author never touched
        # the limit field (a persisted config.json keeps the old 1M value
        # alive even after the default changed to 0).  Operator
        # requirement is verbatim "no restriction at all"; this route
        # STREAMS (bounded-memory ParquetStreamWriter), so the cap was
        # never a memory guard.  The ONLY cap is an explicit positive
        # ``query_params.limit`` — and when it bites, it is DISCLOSED in
        # the execution record (files_metadata.row_cap), not just a log.
        _raw_limit = (feed_config.get("query_params") or {}).get("limit")
        try:
            max_rows = int(_raw_limit) if _raw_limit is not None else 0
        except (TypeError, ValueError):
            max_rows = 0
        if max_rows < 0:
            max_rows = 0          # 0 == unlimited; never re-impose a cap

        # Cancel wiring (2026-08-17, F5).  The old ``_check_feed_cancelled``
        # CLAIMED (in its own docstring) to see user-clicked Cancel, but it
        # only polled feed_configs.is_active — a feed cancelled via the API
        # (feed_executions.status='cancelled', possibly from another pod)
        # kept streaming to completion.  Now: the REAL registered cancel
        # event (signal_cancel sets it in-process) + a 2s DB poller that
        # checks the execution row via _check_cancelled AND is_active.
        import threading as _threading
        _chunk_size = int(getattr(_qe_cfg_conn, "chunk_size", 50000))
        # 2026-10-11 -- the fetch is sized in CELLS, not rows: the stream
        # holds STREAM_BATCHES_IN_FLIGHT batches of Python rows at once, and
        # at 100,000 rows x 75 columns three concurrent runs OOM-killed the
        # scheduler (core/feed/batch_budget.py).  Width from the SQL text;
        # unknown (SELECT *) is assumed wide, never narrow.
        from core.connector_to_parquet import STREAM_BATCHES_IN_FLIGHT
        from core.feed.batch_budget import rows_within_budget, sql_width
        _width = sql_width(sql)
        _chunk_size = rows_within_budget(
            _chunk_size, _width, batches_in_flight=STREAM_BATCHES_IN_FLIGHT)
        _cancel_event = feed_config.get("_cancel_event") or _threading.Event()

        _feed_id_for_cancel = (feed_config or {}).get("id")
        def _check_feed_cancelled():
            """True when the execution row was cancelled (in-process event
            or DB status, incl. cross-pod) OR the feed was deactivated."""
            try:
                if _check_cancelled(feed_config.get("_exec_id") or "",
                                    feed_config.get("_exec_db_id"),
                                    db=db):
                    return True
            except Exception as _cx:
                # Fail-open on the cancel PROBE (a probe must never abort the
                # run it is watching) but say so -- a silently broken cancel
                # check looks exactly like 'not cancelled'.
                logger.warning("feed cancel check failed, treating as "
                               "not-cancelled: %s", _cx)
            if _feed_id_for_cancel is None:
                return False
            try:
                fc = db.get_feed_config(_feed_id_for_cancel)
                if fc and not fc.get("is_active"):
                    return True
            except Exception:
                pass
            return False

        _poll_stop = _threading.Event()
        def _cancel_poller():
            while not _poll_stop.wait(2.0):
                if _cancel_event.is_set():
                    return
                if _check_feed_cancelled():
                    logger.info(
                        "[feed_engine] connector feed %s: cancel observed "
                        "mid-stream — signalling connector abort",
                        _feed_id_for_cancel,
                    )
                    _cancel_event.set()
                    return
        _poller = _threading.Thread(
            target=_cancel_poller, name="feed-cancel-poll", daemon=True,
        )
        _poller.start()

        # ── Stream via the ONE chokepoint (2026-08-17, F4/F7) ─────────
        # core.connector_to_parquet.execute_sql_to_parquet is the
        # product-wide connector→parquet writer (bounded memory, dict/
        # tuple row shapes, non-positive limit == unlimited normalised at
        # the source, TYPED-empty parquet on zero rows).  This function
        # used to carry its own pandas/ParquetWriter loop — the exact
        # per-site duplication that module was created to end — and its
        # empty-result branch wrote a SCHEMA-LESS ``pa.table({})`` that
        # some readers reject.
        connector = None
        rows_written = 0
        _result_path = output_path
        try:
            connector = get_connector(conn_type, conn_config)
            # ── Write ladder (2026-08-22, design_starburst_140m §4.2) ──
            # Rung selection is DECLARATION-driven (write_capabilities on
            # the connector; UNKNOWN = UNSAFE → rung 3) and recorded on
            # the execution (files_metadata.write_ladder via execute_feed)
            # so "which rung ran, and why" is always answerable.
            from core.feed.write_ladder import (
                select_write_rung, RUNG_ENGINE_WRITE,
            )
            _rung = select_write_rung(connector, feed_config)
            _ladder_audit = _rung.to_dict()
            feed_config["_write_ladder"] = _ladder_audit
            if _rung.rung == RUNG_ENGINE_WRITE:
                # Rung 1 — the ENGINE writes.  An explicit positive cap
                # is pushed into the statement (engine-side LIMIT), so
                # the cap semantics and disclosure below are identical
                # to the streaming rung's.
                _sql_r1 = sql
                if max_rows > 0:
                    _sql_r1 = (f"SELECT * FROM (\n{sql}\n) AS qs_row_cap "
                               f"LIMIT {max_rows}")
                _result_path, rows_written = _rung1_engine_unload(
                    connector, _sql_r1, feed_config, output_path,
                    _cancel_event, _ladder_audit,
                )
            else:
                # Said only on the rung that streams (rung 1 fetches nothing).
                logger.info("[feed_engine] feed %s streams %d row(s) per fetch "
                            "(%s column(s)%s, feed_generation.max_cells_in_memory)",
                            (feed_config or {}).get("id"), _chunk_size,
                            _width if _width else "unknown",
                            "" if _width else " -- assumed wide")
                from core.config import feed_generation as _fg_parts
                _rows_per_part = int(getattr(_fg_parts,
                                             "parts_rows_per_part",
                                             5_000_000))
                # 2026-10-14 -- a declared partition key: the query is read
                # bucket by bucket (OG's partition_config; core/feed/
                # partitioned_read.py).  None = it runs whole, and the
                # execution record says why.
                from core.feed.partitioned_read import read_partitioned as _read_part
                _part_res = _read_part(
                    connector_factory=lambda: get_connector(conn_type, conn_config),
                    probe_connector=connector, sql=sql, conn_type=conn_type,
                    feed_config=feed_config, output_path=output_path,
                    cancel_event=_cancel_event, chunk_size=_chunk_size,
                    max_rows=max_rows,
                    rows_per_part=_rows_per_part if _rows_per_part > 0 else 5_000_000)
                if _part_res is not None:
                    _result_path, rows_written = _part_res
                elif _rows_per_part > 0:
                    _result_path, rows_written = _rung3_stream_parts(
                        connector, sql, conn_type, feed_config,
                        output_path, _cancel_event, _chunk_size, max_rows,
                    )
                else:
                    # Rotation disabled: the pre-parts single-file path,
                    # byte-identical to what always ran here.
                    from core.connector_to_parquet import (
                        execute_sql_to_parquet as _sql_to_parquet,
                    )
                    _stream_res = _sql_to_parquet(
                        connector, sql, output_path,
                        row_limit=(max_rows if max_rows > 0 else None),
                        cancel_event=_cancel_event,
                        chunk_size=_chunk_size,
                    )
                    rows_written = int(_stream_res.get("total_rows") or 0)
        except InterruptedError as _cx:
            # Cancelled mid-stream.  Raising (instead of the old silent
            # ``break`` + return) means a cancelled feed can NEVER deliver
            # a partial file marked completed.
            raise _FeedCancelled(
                f"connector feed cancelled mid-stream "
                f"(feed={_feed_id_for_cancel})"
            ) from _cx
        finally:
            _poll_stop.set()
            if connector is not None:
                try:
                    connector.close()
                except Exception:
                    pass

        # A cap that bites is DISCLOSED in the execution record (F2) —
        # the operator must be able to tell a complete feed from a
        # clipped one without reading pod logs.
        if max_rows > 0:
            _cap_hit = rows_written >= max_rows
            feed_config["_row_cap_disclosure"] = {
                "configured_limit": max_rows,
                "rows_written": rows_written,
                "cap_hit": bool(_cap_hit),
                "message": (
                    f"Feed ran under an explicit row cap of {max_rows:,} "
                    f"(query_params.limit)."
                    + (" The output HIT the cap — the source may hold more "
                       "rows.  Set query_params.limit = 0 for the complete "
                       "extract." if _cap_hit else "")
                ),
            }
            if _cap_hit:
                logger.warning(
                    "[feed_engine] feed %s TRUNCATED at the configured row "
                    "cap: wrote %d rows and stopped; the source may have "
                    "more.  Set query_params.limit = 0 for the complete "
                    "extract.",
                    _feed_id_for_cancel, rows_written,
                )

        logger.info(
            "[feed_engine] connector feed %s [%s] rung=%s wrote %d row(s) → %s",
            (feed_config or {}).get("id"), conn_type,
            (feed_config.get("_write_ladder") or {}).get("rung", "?"),
            rows_written, _result_path,
        )
        _feed_brain_complete(total_rows=rows_written, from_multi_worker=False)
        return _result_path

    # 2026-10-14 -- the side's SQL as QueryStudio's own engine runs it: THE
    # translation datasets use (federation_engine._base_query_for_duckdb).
    # Found live: the owner's JOIN query (REGEXP_LIKE, date_format('%Y..'))
    # reached DuckDB untranslated and failed "regexp_like does not exist";
    # the earlier queries only passed because they used nothing DuckDB lacks.
    # Read in the dialect the CONNECTION declares (config.sql_dialect), else the
    # deployment's, else a guess -- and the run records which
    # (files_metadata.sql_translation).
    from core.sql_dialect_translator import translate_for_qs_engine
    sql, _sql_tr = translate_for_qs_engine(sql, (conn_config or {}).get("sql_dialect"))
    if _sql_tr.get("from"):
        feed_config["_sql_translation"] = _sql_tr
        logger.info("[feed_engine] feed %s: SQL read as %s (%s) for QueryStudio's engine",
                    (feed_config or {}).get("id"), _sql_tr["from"], _sql_tr["how"])

    # ── Build an engine instance to feed setup_registered_views ───────
    # Mirrors what /api/execute does at lines 7715-7717 of execute_api.py.
    from core.parquet_engine_v2 import ParquetQueryEngine
    from core.config import paths as _paths_cfg, query_engine as _qe_cfg
    registered_tables = feed_config.get("_registered_tables") or []
    engine = ParquetQueryEngine(
        base_path=_paths_cfg.parquet_dir,
        chunk_size=int(getattr(_qe_cfg, "chunk_size", 50000)),
    )
    engine._s3_conn_config = conn_config
    engine._s3_bucket = conn_config.get("bucket_name") or conn_config.get("bucket") or ""
    engine._s3_conn_id = conn.get("id")
    engine._registered_tables = registered_tables

    # ── Rewrite virtual-prefix read_parquet() calls to view references ─
    # build_query_sql emits ``read_parquet('__registered__:foo')`` but
    # setup_registered_views creates the view named just ``"foo"`` (no
    # prefix).  Apply the canonical rewriter so the canonical view path
    # works with build_query_sql output.
    from core.virtual_ref_rewriter import rewrite_virtual_refs, count_virtual_refs
    _before_count = count_virtual_refs(sql)
    sql = rewrite_virtual_refs(sql)
    if _before_count:
        logger.info(
            "[feed_engine] feed %s rewrote %d virtual ref(s) to view name(s)",
            (feed_config or {}).get("id"), _before_count,
        )

    # ── Row-level security (2026-08-17, F1) ───────────────────────────
    # Same enforcement as the connector route above, applied AFTER the
    # virtual-ref rewrite so policies match the plain view names the SQL
    # actually references.  The multi-worker fan-out below derives its
    # SQL from this rewritten text, so workers inherit the policy
    # predicates too.  No-op when RLS is disabled or no policy matches.
    from core.feed.rls import secure_feed_sql as _secure_feed_sql
    sql = _secure_feed_sql(
        db, sql, feed_config,
        connection_id=conn.get("id"),
        connection_type=conn_type or "duckdb",
        request_id=feed_config.get("_exec_id"),
    )

    # ── Determine row limit ──────────────────────────────────────────
    # 2026-08-13 -- ``<= 0`` MEANS UNLIMITED (see the connector route
    # above).  2026-08-17 (F2) -- ABSENT means unlimited too.  The old
    # ``is None`` fall-through to ``feed_generation.max_output_rows``
    # (default 1,000,000 until 2026-08-13, and STILL 1,000,000 in any
    # persisted config.json from before then) baked ``LIMIT 1000000``
    # into the SQL of every feed whose author never set a limit -- a 70M
    # -row table shipped 1M rows and reported SUCCESS.  This route
    # streams (to_arrow_reader -> ParquetWriter), so the cap was never a
    # memory guard.  The ONLY cap is an explicit positive
    # ``query_params.limit``; when it is in force the run disclosed it in
    # the execution record (files_metadata.row_cap), not just a log line.
    _raw_limit = (feed_config.get("query_params") or {}).get("limit")
    try:
        max_rows = int(_raw_limit) if _raw_limit is not None else 0
    except (TypeError, ValueError):
        max_rows = 0
    if max_rows < 0:
        max_rows = 0          # 0 == unlimited; never re-impose a cap
    # CRITICAL BUG FIX (2026-05-18): user-authored SQL ending with a
    # trailing semicolon broke the subquery wrap below.  e.g.
    #   "SELECT ... ORDER BY x;"  →  "SELECT * FROM (SELECT ... ORDER BY x;) _feed_q LIMIT 10000"
    #                                                            ^---------- DuckDB parser error
    # Same gap for trailing `--` line comments: the comment swallows
    # the `)` and the LIMIT trailer.
    #
    # Fix:
    #   (a) Run through strip_sql_limit — strips trailing whitespace +
    #       semicolons + outer LIMIT.  Same helper BQB / CQB use
    #       (execute_stream_api.py:473, reports_api.py:1890, etc.).
    #   (b) Put the close-paren on its OWN line so a trailing ``--``
    #       comment can't reach across the newline to swallow ``)``.
    from core.query_converter import strip_sql_limit as _strip_lim
    _clean_sql = _strip_lim(sql or "")
    # No LIMIT trailer at all when unlimited — ``LIMIT 0`` would return ZERO
    # rows, which is how "no cap" would otherwise become "no data".
    if max_rows > 0:
        limited_sql = f"SELECT * FROM (\n{_clean_sql}\n) _feed_q LIMIT {max_rows}"
        logger.info(
            "[feed_engine] feed %s runs under an EXPLICIT row cap of %d "
            "(query_params.limit); rows beyond it will NOT be in the file.  "
            "Set query_params.limit = 0 (or remove it) for the complete "
            "extract.",
            (feed_config or {}).get("id"), max_rows,
        )
    else:
        limited_sql = f"SELECT * FROM (\n{_clean_sql}\n) _feed_q"

    def _finalize_row_cap_disclosure(total_rows: int) -> None:
        """2026-08-17 (F2) — when an explicit cap was in force, record it
        on the execution (files_metadata.row_cap via execute_feed).  With
        ``LIMIT`` baked into SQL we cannot know the true source count, so
        ``cap_hit`` means "the output filled the cap — the source may
        hold more"."""
        if max_rows <= 0:
            return
        _hit = int(total_rows or 0) >= max_rows
        feed_config["_row_cap_disclosure"] = {
            "configured_limit": max_rows,
            "rows_written": int(total_rows or 0),
            "cap_hit": bool(_hit),
            "message": (
                f"Feed ran under an explicit row cap of {max_rows:,} "
                f"(query_params.limit)."
                + (" The output HIT the cap — the source may hold more "
                   "rows.  Set query_params.limit = 0 for the complete "
                   "extract." if _hit else "")
            ),
        }
        if _hit:
            logger.warning(
                "[feed_engine] feed %s output FILLED the configured row cap "
                "(%d rows) — the source may hold more.  Set "
                "query_params.limit = 0 for the complete extract.",
                (feed_config or {}).get("id"), max_rows,
            )

    # ── Set up views via the canonical path ───────────────────────────
    # setup_registered_views handles: iceberg metadata cache, parquet
    # column-stats pruning, S3 secret creation, object cache enable,
    # proxy fallback, smart pre-download (only files that survive
    # pruning), reader plugin selection.  Returns a configured DuckDB
    # connection ready to run our SQL against.
    from core.duckdb_views import setup_registered_views
    qcfg_for_setup_raw = feed_config.get("_query_config") or {"files": []}
    # CRITICAL BUG FIX (2026-05-18 v2): setup_registered_views accesses
    # query_config.joins / .files / .filters via ATTRIBUTE (line 2300+
    # in duckdb_views.py).  feed_engine has historically passed the
    # raw DICT loaded from saved_queries.query_config JSON column —
    # which crashed with `'dict' object has no attribute 'joins'`.
    #
    # v1 of this fix called QueryConfigModel(**raw) but failed when the
    # saved dict had:
    #   - missing required `files` key (raw-SQL feeds save without files)
    #   - extra fields not in the model schema
    #   - field-level type mismatches (e.g. older saves with different shape)
    # When ANY of these failed, we passed the raw dict back → the original
    # crash recurred → setup fell back to plain DuckDB con with NO views
    # registered → user saw "Catalog Error: table with name fact_table does
    # not exist" because the view was never created.
    #
    # v2 is defensive: strip unknown fields, supply defaults for required
    # ones BEFORE calling QueryConfigModel.  If conversion STILL fails,
    # use a minimal valid model rather than the broken raw dict so
    # setup_registered_views can still register views from
    # ``engine._registered_tables`` (the data it actually needs).
    try:
        from api.models.query_models import QueryConfigModel
        if isinstance(qcfg_for_setup_raw, dict):
            _known = set(QueryConfigModel.model_fields.keys())
            _clean = {k: v for k, v in qcfg_for_setup_raw.items() if k in _known}
            # ``files`` is required + must be a list.  Defaults to [].
            # ``files: None`` (explicit null in saved JSON) also coerces to [].
            if _clean.get("files") is None:
                _clean["files"] = []
            # ``joins`` may have malformed entries (older shape without
            # left_file).  Drop the field entirely if validation likely
            # to fail rather than block the whole conversion.
            _raw_joins = _clean.get("joins")
            if isinstance(_raw_joins, list):
                _good_joins = [
                    j for j in _raw_joins
                    if isinstance(j, dict)
                    and j.get("left_file") and j.get("right_file")
                ]
                if len(_good_joins) != len(_raw_joins):
                    logger.debug(
                        "[feed_engine] feed %s: dropping %d malformed join "
                        "entries (missing left_file/right_file) to allow "
                        "QueryConfigModel construction",
                        (feed_config or {}).get("id"),
                        len(_raw_joins) - len(_good_joins),
                    )
                _clean["joins"] = _good_joins or None
            qcfg_for_setup = QueryConfigModel(**_clean)
        else:
            qcfg_for_setup = qcfg_for_setup_raw
    except Exception as _qcfg_conv_exc:
        logger.warning(
            "[feed_engine] feed %s: query_config dict→model conversion "
            "failed (%s) — using minimal valid model so view setup still runs",
            (feed_config or {}).get("id"), _qcfg_conv_exc,
        )
        # Minimal valid model: empty files list, no joins/filters.
        # setup_registered_views will still register every table in
        # ``engine._registered_tables`` — the user's raw SQL can then
        # reference them by name without crashing on .joins access.
        try:
            from api.models.query_models import QueryConfigModel
            qcfg_for_setup = QueryConfigModel(files=[])
        except Exception:
            qcfg_for_setup = qcfg_for_setup_raw

    # Phase 145.1 — BQB-streaming parity: extract the same 2 hints BQB streaming
    # has passed since launch.  Without these, setup_registered_views registers
    # every table in ``engine._registered_tables`` and runs a full Iceberg
    # manifest scan + pre-download for each — even when the feed touches only 1
    # of 10 tables on the connection.  Observed user impact: 10-min hang per
    # feed run, ~9× of which was wasted work.
    #
    # Falls through to today's behaviour (None hints → register everything)
    # when the SQL doesn't reference any known table names — no semantic change
    # for the legacy path.
    try:
        from core.query_hints import (
            extract_referenced_tables as _qh_refs,
            extract_partition_filters_from_query as _qh_pf,
        )
        _refs_hint = _qh_refs(engine._registered_tables, sql)
        _pf_hint, _pf_warnings = _qh_pf(qcfg_for_setup) if qcfg_for_setup else (None, [])
        _og_hint = None   # 2026-10-08: the WHERE's OR-of-AND-groups, union-pruned per branch
        if _pf_warnings:
            for _w in _pf_warnings:
                logger.warning("[feed_engine] partition filter warning: %s",
                               _w.get("message", _w) if isinstance(_w, dict) else _w)

        # ── Phase 145.5 — Raw SQL partition extraction ─────────────────
        # When the feed source is raw_sql / sql_file, query_config.files is
        # empty so _qh_pf returns no filters → setup_registered_views scans
        # ALL data files for the referenced tables.  Fix: parse the SQL
        # WHERE clause directly using the same extractor BQB uses (BF-NON-
        # PARTITION-PRUNE).  Builds {table_name: [partition_cols]} from
        # registered_tables — and when those don't have partition_columns
        # configured, falls back to the partition_cache populated by
        # CQB/BQB queries (db.get_connection_partitions).
        #
        # Phase 145.5 deep-dive (2026-05-18): the original implementation
        # only consulted registered_tables.partition_columns, which most
        # connections leave empty.  The actual partition data lives in the
        # partition_cache table — populated automatically by every CQB or
        # BQB iceberg query.  Reusing that cache makes 145.5 zero-config:
        # any table queried at least once is now eligible for raw SQL
        # WHERE-clause pruning.
        #
        # Gracefully degrades to today's behaviour when:
        #   - feed has structured filters already (skips this work)
        #   - no cache entries AND no registered_tables.partition_columns
        #   - sqlglot can't parse the SQL (fail-open)
        if not _pf_hint and _refs_hint:
            try:
                from core.iceberg_partition_resolver import resolve_with_diagnostics
                _pc_map = {}
                _failed_iceberg = []  # 2026-06-08 -- track iceberg tables
                                       # that came up empty so we can log
                                       # the aggregate failure summary at
                                       # the end (not just per-table WARNs)
                _refs_lower = {r.lower() for r in _refs_hint}
                _conn_id_for_pc = engine._s3_conn_id
                _bucket_for_pc = engine._s3_bucket
                # Build s3 client lazily so the resolver's tier-3 (iceberg
                # metadata.json) only fires when tiers 1+2 missed.
                _s3_for_pc = None
                _s3_build_error = None  # capture build failure reason for log
                for _t in (engine._registered_tables or []):
                    if not isinstance(_t, dict):
                        continue
                    _tname = _t.get("name")
                    if not _tname or _tname.lower() not in _refs_lower:
                        continue
                    # Tier 3 inputs: s3 client + bucket + table prefix.
                    # Build client on first need only -- cheap to make per-
                    # query but pointless when tiers 1+2 cover everything.
                    if (_t.get("format") == "iceberg"
                            and _bucket_for_pc and _t.get("s3_prefix")):
                        if _s3_for_pc is None and _s3_build_error is None:
                            try:
                                from core.s3_utilities import make_s3_client_for_conn
                                _s3_for_pc = make_s3_client_for_conn({
                                    "id": _conn_id_for_pc,
                                    "config": engine._s3_conn_config,
                                })
                            except Exception as _s3_exc:
                                _s3_for_pc = None
                                _s3_build_error = (
                                    f"{type(_s3_exc).__name__}: {_s3_exc}"
                                )
                                logger.warning(
                                    "[feed_engine] S3 client build for "
                                    "Tier-3 partition lookup FAILED -- "
                                    "iceberg pruning will degrade.  Error: %s",
                                    _s3_build_error,
                                )
                    _resolution = resolve_with_diagnostics(
                        registered_table=_t,
                        db_manager=db,
                        connection_id=_conn_id_for_pc,
                        table_name=_tname,
                        s3_client=_s3_for_pc,
                        bucket=_bucket_for_pc,
                        table_prefix=_t.get("s3_prefix"),
                    )
                    if _resolution.cols:
                        _pc_map[_tname] = _resolution.cols
                    elif _resolution.is_iceberg:
                        _failed_iceberg.append({
                            "table": _tname,
                            "diagnostics": _resolution.diagnostics,
                        })
                if _pc_map:
                    from core.sql_partition_extractor import (
                        extract_combined_filters_and_or_groups_for_iceberg,
                    )
                    _raw_sql_for_extract = sql or ""
                    # 2026-10-08: the AND-only call dropped the WHERE's OR
                    # branches on the feed road; ask for both.
                    _ext, _ext_og = extract_combined_filters_and_or_groups_for_iceberg(
                        _raw_sql_for_extract, _pc_map, dialect="duckdb",
                    )
                    _og_hint = _ext_og or None
                    if _og_hint:
                        logger.info(
                            "[feed_engine] SQL-WHERE disjunction: %d OR branch(es) "
                            "extracted (union-pruned per branch under the one "
                            "decision)", len(_og_hint))
                    if _ext:
                        _pf_hint = _ext
                        logger.info(
                            "[feed_engine] Phase 145.5 SQL-WHERE extraction: "
                            "%d filter(s) from %d table(s) (cols: %s)",
                            len(_ext), len(_pc_map),
                            {k: v for k, v in _pc_map.items()},
                        )
                    else:
                        # 2026-06-08 -- partition columns RESOLVED but
                        # the SQL WHERE clause doesn't reference any of
                        # them.  Likely a legitimate non-filtered scan
                        # OR the user's WHERE uses a non-partition column.
                        # Log so this is visible.
                        logger.info(
                            "[feed_engine] Partition cols resolved for "
                            "%d table(s) but NO matching filters in SQL "
                            "(cols: %s).  No partition pruning available.",
                            len(_pc_map), {k: v for k, v in _pc_map.items()},
                        )
                # 2026-06-08 -- LOUD aggregate failure log when ICEBERG
                # tables came up empty across all 3 tiers.  This is the
                # signal that pruning will degrade to full scan -- the
                # exact symptom the user reported ("3000+ files when
                # <2000 expected").  Diagnostics show WHICH tier failed
                # and WHY for each affected table.
                if _failed_iceberg:
                    logger.warning(
                        "[feed_engine] PRUNING WILL DEGRADE -- %d iceberg "
                        "table(s) had partition-column lookup FAIL across "
                        "all 3 tiers.  Files will be scanned in full "
                        "because partition filters can't be extracted "
                        "without knowing partition column names.  "
                        "Tables + diagnostics: %s",
                        len(_failed_iceberg), _failed_iceberg,
                    )
            except Exception as _ext_exc:
                logger.debug(
                    "[feed_engine] Phase 145.5 SQL-WHERE extraction failed "
                    "(non-fatal): %s", _ext_exc,
                )

        logger.info(
            "[feed_engine] Phase 145.1 hints — referenced_tables=%s, "
            "partition_filters=%s (of %d filter conditions)",
            sorted(_refs_hint) if _refs_hint else None,
            "yes" if _pf_hint else "no",
            len(_pf_hint or []),
        )
    except Exception as _hints_exc:
        logger.debug("[feed_engine] hint extraction failed (non-fatal): %s",
                     _hints_exc)
        _refs_hint = None
        _pf_hint = None
        _og_hint = None

    # Phase 145.3 — CapturingCon dual-wraps the real DuckDB connection
    # so setup_registered_views' CREATE VIEW statements are recorded
    # alongside execution.  Lets us hand the captured SQL to
    # maybe_dispatch_multi_worker WITHOUT a second setup pass (which
    # would double the iceberg pre-download cost on a proxy network).
    #
    # Only CREATE [OR REPLACE] VIEW is captured — pragmas / secrets /
    # selects go straight through.  Multi-worker workers create their
    # own secrets via conn_config independently.
    class _CapturingCon:
        def __init__(self, real_con):
            self._real = real_con
            self.view_statements: list[str] = []

        def execute(self, sql, *args, **kwargs):
            try:
                upper = (sql or "").lstrip().upper()
                if (upper.startswith("CREATE VIEW")
                        or upper.startswith("CREATE OR REPLACE VIEW")):
                    self.view_statements.append(sql)
            except Exception:
                pass
            return self._real.execute(sql, *args, **kwargs)

        def __getattr__(self, name):
            return getattr(self._real, name)

        def close(self):
            return self._real.close()

        # BF-593: removed BF-591's __enter__/__exit__ shim — grep across
        # the codebase confirms NO `with _CapturingCon(...) as con:` site
        # exists; the wrapper is only instantiated as `_CapturingCon(real_con)`
        # and passed to setup_registered_views.  The methods were dead
        # code mislabelled as a fix.  If a future caller wants context-
        # manager semantics, add them then — not speculatively now.

    # Pre-create the real con so setup_registered_views runs against it
    # via the wrapper.  When the wrapper isn't used (legacy path / failure
    # fallback), setup_registered_views creates its own con internally.
    _capturing_wrapper = None
    _real_con_for_capture = None
    try:
        from api.data_grid_api import _duckdb_con_with_s3 as _make_con
        _real_con_for_capture = _make_con(engine._s3_conn_config,
                                          connection_id=engine._s3_conn_id)
        _capturing_wrapper = _CapturingCon(_real_con_for_capture)
    except Exception as _wrap_exc:
        logger.debug(
            "[feed_engine] Phase 145.3 CapturingCon prep failed (%s) — "
            "multi-worker dispatch will be skipped, falling back to "
            "single-worker setup",
            _wrap_exc,
        )
        # Guard against a partial state where _make_con succeeded but
        # _CapturingCon(...) raised — leaves a pooled S3 con orphaned.
        if _real_con_for_capture is not None and _capturing_wrapper is None:
            try:
                _real_con_for_capture.close()
            except Exception as _close_exc:
                logger.debug(
                    "[feed_engine] orphaned CapturingCon close failed: %s",
                    _close_exc,
                )
            _real_con_for_capture = None

    con = None
    try:
        # 2026-06-04 audit fix — feed_gen wants LARGEST_FIRST (BULK_SCAN
        # profile) for ordering.  Set the thread-local BEFORE
        # setup_registered_views runs so the iceberg_reader call inside
        # picks up the right plan; pre-fix the dispatcher set it AFTER
        # the file enumeration was already done.
        try:
            from core.scan_strategy import (
                ScanStrategist, WorkloadContext, set_current_file_order,
            )
            _fg_wc = WorkloadContext(
                caller="feed_gen", file_count=0, has_limit=False,
            )
            _fg_plan = ScanStrategist().plan(workload=_fg_wc)
            set_current_file_order(_fg_plan.file_order)
        except Exception as _fg_ssl_exc:
            logger.debug(
                "[scan-strategy] feed_engine early thread-local "
                "stamp failed (degrading to admin default): %s",
                _fg_ssl_exc,
            )
        try:
            setup_result = setup_registered_views(
                engine,
                qcfg_for_setup,
                engine._s3_conn_config,
                engine._registered_tables,
                engine._s3_bucket,
                engine._s3_conn_id,
                con=_capturing_wrapper,              # ← Phase 145.3
                referenced_tables=_refs_hint,        # ← Phase 145.1
                partition_filters=_pf_hint,          # ← Phase 145.1
                or_groups=_og_hint,                  # ← 2026-10-08 disjunction union
                db_manager=db,  # BF-368: column-stats supplement
                raw_sql=sql,             # Phase K (2026-06-08): enable
                                         # JoinPruner.plan_probes_from_raw_joins
                                         # for raw-SQL feed generation queries
                                         # (Feed Gen JOIN queries silently
                                         # over-scanned joined tables pre-Phase-K).
            )
            # setup_registered_views may return 4- or 5-tuple depending
            # on version — be defensive.
            con = setup_result[0]
            _all_empty = setup_result[3] if len(setup_result) > 3 else False
        except Exception as _setup_exc:
            # Log the full traceback so the IndexError / KeyError / etc. that
            # caused the fallback is captured in service logs (not just the
            # short str(_setup_exc)).  Without exc_info the user only sees
            # "list index out of range" with no file/line — making it
            # impossible to diagnose from the dashboard.
            logger.warning(
                "[feed_engine] feed %s: setup_registered_views failed (%s: %s) — "
                "falling back to plain DuckDB connection",
                (feed_config or {}).get("id"),
                type(_setup_exc).__name__, _setup_exc,
                exc_info=True,
            )
            # Stash a short trace summary on feed_config so if the downstream
            # query fails, the failure path can prepend this — explaining WHY
            # the connection fell back (e.g., view registration crashed) on the
            # dashboard error chip.  Just the type+message+top frame keeps it
            # under the 2000-char error_message cap.
            try:
                import traceback as _tb
                _tb_lines = _tb.format_exception(type(_setup_exc), _setup_exc,
                                                  _setup_exc.__traceback__)
                _last_frame = ""
                for _l in reversed(_tb_lines):
                    if _l.strip().startswith("File "):
                        _last_frame = _l.strip().split("\n", 1)[0]
                        break
                feed_config["_setup_views_warning"] = (
                    f"setup_registered_views failed: "
                    f"{type(_setup_exc).__name__}: {_setup_exc}"
                    + (f" [{_last_frame}]" if _last_frame else "")
                )[:600]
            except Exception:
                feed_config["_setup_views_warning"] = (
                    f"setup_registered_views failed: "
                    f"{type(_setup_exc).__name__}: {_setup_exc}"
                )[:600]
            # Phase 145.3 — close the orphaned CapturingCon's real con
            # before falling back.  Without this, the pooled S3 connection
            # opened up-front leaks until the pool TTL evicts it (8h).
            if _real_con_for_capture is not None:
                try:
                    _real_con_for_capture.close()
                except Exception as _close_exc:
                    logger.debug(
                        "[feed_engine] fallback CapturingCon close failed: %s",
                        _close_exc,
                    )
                _real_con_for_capture = None
                _capturing_wrapper = None  # disable multi-worker on fallback path
            from core.duckdb_factory import duckdb_connection as _ddb_conn
            # Fall back to the simpler factory — handles local-parquet
            # connections where setup_registered_views may not apply.
            #
            # CRITICAL BUG FIX (2026-05-18): the previous form
            # ``con = _ddb_conn().__enter__()`` orphans the context manager
            # returned by _ddb_conn().  Python GC eventually calls __del__
            # on the manager which calls __exit__ which CLOSES the con —
            # giving "Connection already closed!" the moment we run the
            # actual SQL.  Hold the manager in a feed-config scoped attr
            # so it stays alive for the duration of the run; tear down
            # explicitly in the finally below.
            _ddb_ctx = _ddb_conn()
            con = _ddb_ctx.__enter__()
            feed_config["_ddb_fallback_ctx"] = _ddb_ctx
            _all_empty = False
            # Set file_search_path for local relative paths
            if conn_type in ("", "local", "parquet"):
                try:
                    _pdir = str(_paths_cfg.parquet_dir)
                    _esc_pdir = _pdir.replace("'", "''").replace("\\", "/")
                    con.execute(f"SET file_search_path = '{_esc_pdir}'")
                except Exception:
                    pass

        # ── 2026-08-20 — A PARTIAL FEED IS NOT A SUCCESSFUL FEED ──────────
        #
        # The BF-474 registration-failure gate below lived INSIDE ``if
        # _all_empty:``.  So it only ever fired when EVERY table came back
        # empty.  If three tables registered and a fourth failed with 403, the
        # feed wrote the three tables' rows and reported SUCCESS — the exact
        # silent data loss BF-474 exists to prevent, just with a non-zero row
        # count to make it look healthy.
        #
        # A table that failed to register contributes NO rows to any query
        # referencing it.  There is no output shape in which that is a
        # complete result, so the check belongs here, before the empty/
        # non-empty split.
        #
        # SCOPE: registered_tables can carry tables this query never
        # references, and failing on those would break working feeds.
        # setup_registered_views publishes the scope it actually used; an
        # EMPTY scope means "unknown", and unknown must fail closed.
        _rf_hit = registration_failures_in_scope(
            getattr(engine, "_setup_registration_failures", None),
            getattr(engine, "_setup_query_table_scope", None))
        if _rf_hit and not _all_empty:
            _pf_names = sorted(_rf_hit.keys())
            _pf_first = _rf_hit[_pf_names[0]]
            _pf_id = feed_config.get("id") if isinstance(feed_config, dict) else None
            _pf_msg = (
                f"Feed {_pf_id}: {len(_rf_hit)} referenced table view(s) "
                f"FAILED to register while others succeeded: {_pf_names}.  "
                f"First error: {_pf_first.get('error_type','')}: "
                f"{str(_pf_first.get('error_message',''))[:300]}.  The output "
                f"would contain rows from the tables that DID register and "
                f"silently omit the rest — refusing to emit a partial feed as "
                f"a success."
            )
            logger.error("[feed_engine] %s", _pf_msg)
            raise RuntimeError(_pf_msg)

        if _all_empty:
            # BF-474 (2026-05-19) — distinguish "genuinely 0 files matched
            # the filter" from "S3 returned 403 / network failed".  The
            # latter must NOT be treated as a successful empty run —
            # that's silent data loss.  Reproduces the failure mode the
            # user reported: 11+9 files pruned correctly via boto3, but
            # CREATE VIEW failed with HTTP 403 (DuckDB httpfs lacked
            # credentials), setup_registered_views reported "0 views
            # registered", and the feed COMPLETED with an empty CSV.
            #
            # _setup_registration_failures (set on engine by
            # setup_registered_views) carries {table_name: {error_type,
            # error_message, ...}} for tables that FAILED to register.
            # If any of the PRIMARY tables (from query_config / referenced)
            # are in that dict, the feed must FAIL.
            _reg_failures = getattr(engine, "_setup_registration_failures",
                                     None) or {}
            if _reg_failures:
                _failed_names = sorted(_reg_failures.keys())
                _first = _reg_failures[_failed_names[0]]
                # 2026-08-09: was `feed_config_id` (a param of execute_feed,
                # not of this helper) — NameError replaced the actionable
                # message.  Still fail-CLOSED; only the text was lost.
                _feed_id = feed_config.get("id") if isinstance(feed_config, dict) else None
                _err_summary = (
                    f"Feed {_feed_id}: cannot register {len(_reg_failures)} "
                    f"table view(s): {_failed_names}.  First error: "
                    f"{_first.get('error_type','')}: "
                    f"{_first.get('error_message','')[:300]}"
                )
                logger.error(
                    "[feed_engine] %s — refusing to emit empty output "
                    "(this would be silent data loss).", _err_summary,
                )
                # Common-cause hint when the error is auth-related — the
                # operator can act on this immediately.
                _err_lower = (_first.get("error_message") or "").lower()
                if ("403" in _err_lower or "forbidden" in _err_lower
                        or "access denied" in _err_lower
                        or "no credentials" in _err_lower
                        or "expiredtoken" in _err_lower):
                    _err_summary += (
                        "  [HINT: S3 auth failure — DuckDB httpfs has no "
                        "valid credentials.  Check the connection's "
                        "auth_mode + system_account (or vault password "
                        "for personal mode), and that proxy.apply_to_duckdb "
                        "is configured correctly.]"
                    )
                raise RuntimeError(_err_summary)
            # All primary tables pruned to 0 files — emit an empty parquet.
            logger.info(
                "[feed_engine] feed %s: all primary tables pruned to 0 files; emitting empty output",
                (feed_config or {}).get("id"),
            )
            # F4 2026-08-17: TYPED-empty via DESCRIBE, else schema-less.
            _tc = _typed_empty_cols(con, sql)
            if _tc:
                pq.write_table(pa.table({c: pa.array([], type=pa.string())
                                         for c in _tc}), output_path)
            else:
                pq.write_table(pa.table({}), output_path)
            _finalize_row_cap_disclosure(0)
            _feed_brain_complete(total_rows=0, from_multi_worker=False)
            return output_path

        from core.duckdb_cancel import maybe_spawn_watchdog
        execution_id = str(feed_config.get("id") or "")

        # ── Phase 145.3 — Multi-worker fan-out for parquet feeds ──────
        # When the SQL is splittable + file_count is above the dispatcher
        # threshold + multi_worker.enabled, run N parallel DuckDB workers
        # against subsets of the file list and merge.  BQB / CQB / Published
        # API have used this path since launch via execute_api.py:2990.
        #
        # The captured CREATE VIEW SQL is what makes this safe — workers
        # recreate the view in their subprocess, then run a chunked SQL
        # against the file slice they own.  Falls through to single-worker
        # below when the dispatcher declines (small file count, JOIN, etc.).
        if _capturing_wrapper and _capturing_wrapper.view_statements:
            try:
                from core.multi_worker_dispatcher import maybe_dispatch_multi_worker
                _mw_setup = ";\n".join(_capturing_wrapper.view_statements)

                # Phase 145.3 deep-dive: thread cancel + progress into
                # the dispatcher so workers exit promptly on user-clicked
                # cancel and the feed dashboard shows live "workers N/M"
                # progress instead of a silent 5-minute multi-worker pause.
                _mw_exec_id = feed_config.get("_exec_id") or execution_id
                _mw_cancel = feed_config.get("_cancel_event")

                def _mw_progress(done, total, msg):
                    # Mirror BQB's _mw_progress pattern (execute_api.py:2974)
                    # — log so admins watching backend logs see worker
                    # progress.  WS broadcast would require a sync→async
                    # bridge; logs are sufficient for the feed perf chip
                    # since it polls the executions row, not WS.
                    try:
                        logger.info(
                            "[feed_engine] Phase 145.3 multi-worker progress: "
                            "exec=%s %d/%d — %s",
                            _mw_exec_id, done, total, msg,
                        )
                    except Exception as _prog_exc:
                        logger.debug("[feed_engine] mw progress callback raised: %s",
                                     _prog_exc)

                # Phase 156 -- pass the resolved iceberg snapshot to
                # the dispatcher so brain memo + route history can key
                # on it.  Feed-gen typically full-scans (no WHERE) so
                # memo rarely hits, but route history learns per-table
                # wall-clock either way -- worth the threading.
                # Source: ``qcfg_for_setup`` is the dict mutated by
                # duckdb_views.setup_registered_views which stamps
                # _iceberg_snapshot_id after the snapshot resolution.
                _feed_brain_snap = ""
                try:
                    if isinstance(qcfg_for_setup, dict):
                        _feed_brain_snap = str(
                            qcfg_for_setup.get("_iceberg_snapshot_id") or ""
                        )
                except Exception:
                    pass
                try:
                    _mw_out = maybe_dispatch_multi_worker(
                        limited_sql,
                        _mw_setup,
                        output_path,
                        cancel_event=_mw_cancel,
                        progress_cb=_mw_progress,
                        httpfs_required=True,
                        conn_config=engine._s3_conn_config,
                        execution_id=_mw_exec_id,
                        # SCAN-STRATEGY: feed gen is a full-table bulk scan
                        # → ScanStrategist picks BULK_SCAN profile (largest-
                        # first ordering, 16 workers, parallel footer
                        # prewarm).  Closes the user-reported "3000 files
                        # with 4 workers takes forever" perf gap.
                        caller="feed_gen",
                        # 2026-06-03 — feed-gen runs MUST complete; slow
                        # is OK.  Suppress BF-586 outer timeout +
                        # heartbeat budget.
                        cancellable=False,
                        iceberg_snapshot_id=_feed_brain_snap,
                    )
                finally:
                    # 2026-06-03 — release the memory_guard reservation
                    # the dispatcher made.  Idempotent on execution_ids
                    # that never got registered.  Critical: without
                    # this the feed-gen path leaks accountant entries
                    # → admission gate slowly converges to "always
                    # reject" on long-running feed-gen pods.
                    try:
                        from core.memory_guard import release_query
                        release_query(_mw_exec_id)
                    except Exception:
                        pass
                    # Clear the thread-local exec_id set by the
                    # dispatcher at entry (otherwise the next feed run
                    # on the same thread inherits this stale id).
                    try:
                        from core.query_diagnostic_store import set_current_execution_id
                        set_current_execution_id(None)
                    except Exception:
                        pass
                    # Same for the thread-local scan plan file_order.
                    try:
                        from core.scan_strategy import set_current_file_order
                        set_current_file_order(None)
                    except Exception:
                        pass
                if _mw_out is not None:
                    _rows = _mw_out.get("total_rows", 0)
                    _bytes = _mw_out.get("file_size_bytes", 0)
                    _workers = _mw_out.get("worker_count", 0)
                    _elapsed = _mw_out.get("elapsed_s", 0)
                    if _mw_out.get("from_brain_cache"):
                        # 2026-10-08 -- the dispatcher served the brain-cache
                        # hit it routed on (same snapshot, no data file read).
                        logger.info(
                            "[feed_engine] brain-cache SERVED: feed %s %d row(s), "
                            "0 data files read, snapshot=%s age=%.1fs → %s",
                            (feed_config or {}).get("id"), _rows,
                            _mw_out.get("snapshot_id"),
                            float(_mw_out.get("cache_age_seconds") or 0.0),
                            output_path,
                        )
                        _finalize_row_cap_disclosure(int(_rows or 0))
                        _feed_brain_complete(total_rows=int(_rows or 0),
                                              from_brain_cache=True)
                        return output_path
                    logger.info(
                        "[feed_engine] Phase 145.3 multi-worker success: feed %s "
                        "%d row(s), %d workers, %.1fs → %s",
                        (feed_config or {}).get("id"),
                        _rows, _workers, _elapsed, output_path,
                    )
                    _finalize_row_cap_disclosure(int(_rows or 0))
                    _feed_brain_complete(total_rows=int(_rows or 0),
                                          from_multi_worker=True)
                    return output_path
            except Exception as _mw_err:
                logger.warning(
                    "[feed_engine] Phase 145.3 multi-worker raised (%s) — "
                    "falling through to single-worker", _mw_err,
                    exc_info=True,
                )

            # ── Phase 145.4 — BF-417 big×big JOIN → Spark Connect signal ─
            # When multi-worker declined AND the SQL is a JOIN AND Spark
            # Connect is enabled, raise _BfNativeJoinDeclined so the async
            # _execute_native catches it and routes the feed to Spark
            # without bridging threading.Event → asyncio.Event from this
            # worker-pool thread.
            #
            # Mirrors execute_api.py:3041-3193 (BQB BF-417) but via the
            # async exception-handler pattern instead of an inline bridge.
            #
            # Deep-dive guards:
            #   (a) Skip BF-417 for cross-source feeds — _execute_spark_connect
            #       only handles single-side execution.  Mirrors BQB's
            #       execute_api.py:3068 _is_cross_source guard.
            #   (b) Skip when exec_id is empty — without a non-empty filter,
            #       walking decision_history could match OTHER concurrent
            #       feeds' empty IDs (router uses "" as default).
            try:
                _is_cross_source = bool(feed_config.get("secondary_connection_id"))
                _mw_exec_id_check = feed_config.get("_exec_id") or execution_id
                if _is_cross_source or not _mw_exec_id_check:
                    if _is_cross_source:
                        logger.debug(
                            "[feed_engine] Phase 145.4 — skipping BF-417 for "
                            "cross-source feed (Spark Connect can't handle "
                            "primary+secondary union/join semantics)",
                        )
                else:
                    from core.engine_router import get_decision_history
                    from core.config import spark_connect as _sc_cfg
                    import re as _re_join
                    _has_join = bool(_re_join.search(
                        r"\bJOIN\b", limited_sql or "", _re_join.IGNORECASE,
                    ))
                    if _has_join and _sc_cfg.enabled:
                        _bf417_reason = None
                        for _r in (get_decision_history(limit=50) or []):
                            # Strict equality + non-empty check above
                            # prevents cross-pollution between concurrent
                            # feeds that share the empty-string default.
                            if (_r.get("execution_id") or "") != _mw_exec_id_check:
                                continue
                            _rule = (_r.get("rule") or "").lower()
                            _reason = (_r.get("reason") or "").lower()
                            if "broadcast_join" in _rule and "skip" in _rule \
                                    and "big" in _reason:
                                _bf417_reason = (
                                    f"broadcast-JOIN refused big×big: "
                                    f"{_r.get('reason','')[:140]}"
                                )
                                break
                            if "dispatcher_skip" in _rule and (
                                    "join" in _reason or "create view" in _reason
                                    or "splittable" in _reason):
                                _bf417_reason = (
                                    f"dispatcher refused JOIN: "
                                    f"{_r.get('reason','')[:140]}"
                                )
                                break
                            if "partition_aligned_skip" in _rule:
                                _bf417_reason = (
                                    f"partition-aligned refused: "
                                    f"{_r.get('reason','')[:140]}"
                                )
                                break
                        if _bf417_reason is not None:
                            logger.info(
                                "[feed_engine] Phase 145.4 BF-417 → raising "
                                "_BfNativeJoinDeclined for async Spark fallback "
                                "(feed=%s, reason=%s)",
                                (feed_config or {}).get("id"), _bf417_reason,
                            )
                            raise _BfNativeJoinDeclined(_bf417_reason)
            except _BfNativeJoinDeclined:
                raise
            except Exception as _bf417_err:
                logger.debug(
                    "[feed_engine] Phase 145.4 BF-417 detection failed (non-fatal): %s",
                    _bf417_err,
                )

        # ── Stream execute → batch write (constant memory) ────────────
        # Replaces fetch_arrow_table + pq.write_table — that buffered
        # the entire result in RAM, OOM-ing on >5M-row feeds.  This
        # pattern is the same one /api/execute uses at execute_api.py
        # lines 4766-4769 + 4873-4884.
        _wd_stop = maybe_spawn_watchdog(con, execution_id)
        rows_written = 0
        try:
            # BF-571/572 audit fix: apply cross-dialect format
            # normaliser before DuckDB execute so feeds whose raw_sql
            # uses Starburst DATE_FORMAT / format_datetime / %i etc.
            # run unchanged.  Without this, every feed gen with
            # Trino/MySQL format strings crashed even though the
            # identical SQL worked in BQB/CQB.
            try:
                from core.duckdb_format_normaliser import normalise_strftime_formats as _norm
                limited_sql, _ff = _norm(limited_sql)
                if _ff:
                    logger.info(
                        "[feed_engine] BF-571/572 auto-fixed %d format "
                        "specifier(s) in feed SQL", len(_ff),
                    )
            except Exception:
                pass  # fail-open
            result = con.execute(limited_sql)
            # 2026-08-05 — fetch_record_batch(rows_per_batch=) is deprecated
            # in duckdb 1.5; to_arrow_reader(batch_size=) returns the SAME
            # pyarrow.RecordBatchReader with identical batch sizing and
            # INTERRUPT-on-abort semantics (probed on duckdb 1.5.2; same
            # migration as core/duckdb_subprocess.py:742).
            rdr = result.to_arrow_reader(batch_size=engine.chunk_size)
            writer = None
            try:
                _batch_iter = iter(rdr)
                while True:
                    try:
                        batch = next(_batch_iter)
                    except StopIteration:
                        break
                    except Exception as _rd_exc:
                        _reraise_stream_abort(
                            _rd_exc, feed_config.get("_cancel_event"))
                    if len(batch) == 0:
                        continue
                    if writer is None:
                        writer = pq.ParquetWriter(
                            output_path, batch.schema, compression="zstd")
                    writer.write_batch(batch)
                    rows_written += len(batch)
            finally:
                if writer is not None:
                    writer.close()
                else:
                    # Empty result — write a header-only parquet so
                    # downstream tools don't 404 on the file.
                    # 2026-08-17 (F4): TYPED-empty — the arrow reader's
                    # schema carries the real column names/types even when
                    # zero batches arrived; ``pa.table({})`` (zero COLUMNS)
                    # is rejected by some readers.  Schema-less fallback
                    # only if the reader itself never materialised.
                    try:
                        pq.write_table(rdr.schema.empty_table(), output_path)
                    except Exception:
                        pq.write_table(pa.table({}), output_path)
            logger.info(
                "[feed_engine] feed %s streamed %d row(s) → %s",
                (feed_config or {}).get("id"), rows_written, output_path,
            )
            _finalize_row_cap_disclosure(rows_written)
            _feed_brain_complete(total_rows=rows_written, from_multi_worker=False)
            return output_path
        except Exception as _exec_exc:
            # Actionable error (preserved from prior version).
            _msg = str(_exec_exc)
            if "No files found that match the pattern" in _msg or "IO Error" in _msg:
                _base = ""
                try:
                    _base = str(_paths_cfg.parquet_dir)
                except Exception:
                    pass
                hints = []
                if conn_type in ("", "local", "parquet"):
                    hints.append(
                        f"Connection is local/parquet; DuckDB looks under "
                        f"paths.parquet_dir ({_base!r}).  Verify the file "
                        f"exists at that location."
                    )
                if not registered_tables:
                    hints.append(
                        "No registered_tables on this connection — feeds that "
                        "use __registered__:foo refs need the connection's "
                        "Registered Tables list populated first."
                    )
                if "{{" in (sql or ""):
                    hints.append(
                        "SQL still contains {{...}} placeholders — token "
                        "substitution didn't fully resolve.  Check feed's "
                        "calendar_name + query_params."
                    )
                hint_str = "  ".join(hints) if hints else (
                    "No additional context — check connection_id + saved_query "
                    "tables are valid."
                )
                raise RuntimeError(
                    f"Feed query failed: {_msg}.  {hint_str}"
                ) from _exec_exc
            raise
        finally:
            if _wd_stop is not None:
                _wd_stop.set()
    finally:
        if con is not None:
            try:
                con.close()
            except Exception:
                pass
        # Phase 145 BUG-FIX (2026-05-18): explicit fallback-ctx teardown so
        # the orphaned-context-manager bug (con closed by GC mid-query)
        # can't recur.  When setup_registered_views worked normally,
        # _ddb_fallback_ctx is never set so this is a no-op.
        _fb_ctx = feed_config.pop("_ddb_fallback_ctx", None) \
            if isinstance(feed_config, dict) else None
        if _fb_ctx is not None:
            try:
                _fb_ctx.__exit__(None, None, None)
            except Exception as _fb_exc:
                logger.debug(
                    "[feed_engine] fallback ctx teardown failed: %s", _fb_exc,
                )


def _typed_empty_cols(con, sql: str) -> list:
    """Column names for a TYPED-empty parquet write (2026-08-17, F4).

    Every other route in this product writes empty results WITH the real
    column names; a zero-column ``pa.table({})`` is rejected by some
    readers.  DESCRIBE gives us the names without executing the query;
    an empty return means the caller falls back to the schema-less write
    (e.g. views over zero files where DESCRIBE itself errors).
    """
    try:
        rows = con.execute(f"DESCRIBE SELECT * FROM (\n{sql}\n) _fd").fetchall()
        return [str(r[0]) for r in rows if r and r[0]]
    except Exception as exc:
        logger.debug("[feed_engine] typed-empty DESCRIBE failed: %s", exc)
        return []


def _register_views_for_feed(db, registered_tables: list, conn_config: dict, conn_type: str):
    """Create DuckDB views for the connection's registered_tables so the
    feed SQL can reference them by name (``__registered__:foo`` or bare
    ``foo``).  Mirrors what the main query path does via
    :func:`core.duckdb_views.setup_registered_views`, but only the
    local-parquet / S3-list portion — we don't need the iceberg
    metadata-cache machinery here.
    """
    if not registered_tables:
        return
    from pathlib import Path
    from core.config import paths as _paths_cfg
    parquet_base = ""
    try:
        parquet_base = str(_paths_cfg.parquet_dir)
    except Exception:
        pass

    bucket = conn_config.get("bucket", "") if conn_config else ""
    for row in registered_tables:
        if not isinstance(row, dict):
            continue
        # Real schema (per ConnectionManager.register_table):
        # ``{name, s3_prefix, format, description}``.  s3_prefix is
        # used for BOTH s3 connections (relative to conn.config.bucket)
        # AND local connections (relative to paths.parquet_dir).
        table_name = row.get("name") or row.get("table_name") or ""
        path_spec  = (
            row.get("s3_prefix")
            or row.get("path")
            or row.get("table_path")
            or table_name
        )
        if not table_name or not path_spec:
            continue

        _esc_t = table_name.replace('"', '""')
        # Try a few naming conventions so user's SQL can use either
        # form: `foo`, `__registered__:foo`, or fully qualified.
        view_names = [
            f'"{_esc_t}"',
            f'"__registered__:{_esc_t}"',
        ]
        # Decide whether path is S3 or local.
        if path_spec.startswith("s3://"):
            target = path_spec
        elif (conn_type in ("s3", "aws_s3")) and bucket:
            target = f"s3://{bucket}/{path_spec.lstrip('/')}"
        elif Path(path_spec).is_absolute():
            target = path_spec
        else:
            # Relative — resolve under paths.parquet_dir
            target = str(Path(parquet_base) / path_spec) if parquet_base else path_spec

        # 2026-08-17 (F3) — reader selection routes through the
        # core.file_formats adapter registry (product rule: ALL file-
        # format handling via adapters, never per-site if/elif chains).
        # The old chain here had two live defects: .xlsx/.tsv/.dat fell
        # into the PARQUET branch (only .csv/.csv.gz reached the CSV
        # reader), and bare ``s3://bucket/prefix`` targets were EXCLUDED
        # from the directory→glob rewrite, so a prefix was read as a
        # single (nonexistent) object.
        reader, adapter = _feed_reader_expr(target)
        if adapter is not None:
            try:
                # e.g. Excel needs LOAD excel before read_xlsx works.
                adapter.setup_duckdb(db)
            except Exception as _setup_fmt_exc:
                logger.debug(
                    "[feed_engine] format adapter setup failed for %s: %s",
                    target, _setup_fmt_exc,
                )

        for vn in view_names:
            try:
                db.execute(f"CREATE OR REPLACE VIEW {vn} AS SELECT * FROM {reader}")
            except Exception as exc:
                # One view name failed (e.g. colon in name not supported
                # on some DuckDB versions) — try the others, log but
                # don't bail.
                logger.debug("[feed_engine] could not register view %s: %s", vn, exc)


def _feed_reader_expr(target: str):
    """Build the DuckDB read expression for one registered-table target,
    via the ``core.file_formats`` adapter registry (2026-08-17, F3).

    Returns ``(reader_sql_expr, adapter_or_None)``.

    Rules:
      * recognised extension (``.gz`` stripped first — DuckDB readers
        decompress transparently, the format is the extension UNDER it):
        the format's adapter renders the read expr.  Glob targets use the
        list form so ``union_by_name`` covers schema drift across files.
      * ``.jsonl`` maps to the JSON adapter (same reader).
      * no recognised extension and no glob → a DIRECTORY or bare S3
        PREFIX of parquet files: rewrite to ``<target>/**/*.parquet`` —
        INCLUDING ``s3://`` prefixes, which the old chain wrongly read as
        a single object.
    """
    from core.file_formats import get_format_adapter, is_supported_extension

    base = target[:-3] if target.lower().endswith(".gz") else target
    ext = os.path.splitext(base)[1].lower()
    if ext == ".jsonl":
        ext = ".json"

    if is_supported_extension(ext):
        adapter = get_format_adapter(ext)
        if "*" in target:
            # DuckDB accepts a glob inside the list form; the list expr
            # carries union_by_name for multi-file schema drift.
            return adapter.duckdb_read_list_expr([target]), adapter
        return adapter.duckdb_read_expr(target), adapter

    if "*" in target:
        # Explicit glob with an unrecognised/absent extension — parquet
        # is the product's storage format default.
        adapter = get_format_adapter(".parquet")
        return adapter.duckdb_read_list_expr([target]), adapter

    # Directory or bare prefix (local OR s3://) — parquet tree.
    adapter = get_format_adapter(".parquet")
    glob_target = target.rstrip("/") + "/**/*.parquet"
    return adapter.duckdb_read_list_expr([glob_target]), adapter


# ---------------------------------------------------------------------------
# Airflow execution -- ONE road (2026-10-08): the factory DAG -> /spark-submit
# ---------------------------------------------------------------------------
#
# docs/FEED_LANE_CONTRACT_2026_10_07.html s6 left one item open: this lane
# triggered a CONF-DRIVEN DAG run -- a job conf the engine assembled here
# (secured SQL, calendar params, a legacy projection) with NO JDBC
# credentials, and then handed the job's REMOTE output path to the native
# renderer below, which never downloads.  The road that works is the
# factory DAG calling POST /api/feed-executions/{id}/spark-submit: the ONE
# conf builder (core/spark_k8s/feed_conf.py), the per-run credential
# Secret, the artifact store, the webhook's delivery verdict -- what the
# C2 matrices certify.  Two roads to one lane is a decision made twice.
#
# Now the engine ships a DISPATCH (core/feed/airflow_lane.dag_run_conf:
# which execution, which feed, the business date, the submit route, the
# contract name) and the DAG submits THAT execution exactly as its own
# scheduled runs do.  The engine then awaits the EXECUTION ROW -- the
# webhook or the reconciler closes it -- as the spark_k8s lane does, and
# the two detached lanes share one bookkeeping branch in execute_feed.
# The conf-driven half (_secure_airflow_side_sql, the legacy
# classification, _post_airflow_dag_run, _resolve_airflow_output_path,
# feed_generation.airflow.output_s3_*) is REMOVED, not kept beside the
# road; its securing rules live in the ONE builder (feed_conf.py).
# Guard: tests/test_airflow_one_road_2026_10_08.py.


class _AirflowSubmitRefused(Exception):
    """The DAG run ended without submitting, and /spark-submit had
    recorded WHY on the row (a 503: the ladder, or the cluster, at
    submit).  Carries the declared spark_k8s error so ``execute_feed``
    applies the SAME submit-time rule as the spark_k8s lane
    (``backend_router.lane_failed_at_submit`` through
    ``_spark_k8s_unreachable_to_native``): auto-routed with nothing on the
    cluster -> native with the reason; pinned, or anything possibly
    created -> fail with the code, never raw transport text."""

    def __init__(self, cause: BaseException):
        self.cause = cause
        super().__init__(str(cause))


def _run_business_date(feed_config: dict):
    """E-M6: calendar tokens resolve against the run's BUSINESS date when a
    feed_run row is bound (SOD-generated), else ``None`` (today UTC at the
    conf builder).  ONE reading for both detached lanes."""
    _fr = feed_config.get("_feed_run") or {}
    _bd = _fr.get("business_date")
    if not _bd:
        return None
    try:
        from datetime import date as _date_cls
        return (_bd if isinstance(_bd, _date_cls)
                else datetime.fromisoformat(str(_bd)).date())
    except ValueError:
        return None


async def _execute_airflow(
    feed_config: dict,
    execution_record: dict,
    slot_release: Optional[Callable[[], None]] = None, db: Any = None,
    stage_timings: Optional[dict] = None,
    on_submitted: Optional[Callable[[str], None]] = None) -> dict:
    """Dispatch one execution to its factory DAG and await the ROW.

    Returns the terminal execution row on success (the compute lane the
    ONE submitter stamped is ``spark_k8s``; the routing decision that sent
    it through Airflow is recorded by the caller in
    ``files_metadata.backend_choice``, and the DAG run under
    ``stage_timings.airflow``).  Raises ``_FeedCancelled`` on cancel,
    ``RuntimeError`` on failure / poll budget / a DAG that did not honour
    the dispatch contract, ``_AirflowSubmitRefused`` when the DAG failed
    at /spark-submit with a recorded 503 (the caller applies K3).

    ``slot_release`` (E-H3): optional callback invoked once the DAG run is
    triggered and recorded.  It frees the in-process concurrency slot this
    run holds so idle waiting on a long job does not pin native
    throughput.  Finalisation is NOT detached -- this coroutine keeps
    watching the row -- so releasing the slot can never lose a run.
    """
    db = db if db is not None else _db_manager  # transition fallback
    from core.feed import airflow_lane as _lane
    af_cfg = _cfg.airflow
    dag_id, dag_id_source = _lane.resolve_dag_id(feed_config, af_cfg)
    exec_id = execution_record.get("execution_id", "")
    exec_db_id = execution_record.get("id")
    dag_run_id = _lane.dag_run_id_for(exec_id)
    conf = _lane.dag_run_conf(feed_config, execution_record,
                              run_date=_run_business_date(feed_config))
    # The transport is this module's ``_http_request`` seam (tests inject
    # a fake Airflow through it); the client adds the auth header.
    client = _lane.airflow_client_from(af_cfg, transport=_http_request)

    _st = stage_timings if stage_timings is not None else {}
    _st["airflow"] = {"dag_id": dag_id, "dag_id_source": dag_id_source,
                      "dag_run_id": dag_run_id,
                      "contract": _lane.DISPATCH_CONTRACT}
    # The row says what it is waiting on until the ONE submitter stamps
    # the workload name over it -- written BEFORE the trigger (the id is
    # deterministic), because the DAG can submit faster than this
    # coroutine returns from the POST, and a write landing after the
    # submit's stamp would erase the workload name the reconciler keys on
    # (found by the fake DAG, which submits inside the trigger).
    db.update_feed_execution(exec_db_id, {"external_job_id": dag_run_id})
    _t_trigger = time.time()
    await asyncio.to_thread(
        _lane.trigger_feed_dag_run, client, dag_id, dag_run_id, conf,
        dag_id_source=dag_id_source)
    _st["airflow_trigger"] = round(time.time() - _t_trigger, 3)
    # 2026-10-18 -- the DAG's job performs the pipeline from here: the
    # step record says so (core/feed/step_model/detached.py)
    if on_submitted is not None:
        try:
            on_submitted(str(dag_run_id))
        except Exception as _hand_exc:      # noqa: BLE001 -- bookkeeping never fails a run
            logger.warning("[feed_engine] airflow: steps not handed to the job (%s)", _hand_exc)
    logger.info(
        "[feed_engine] Feed %s [%s] dispatched to Airflow DAG %s (run %s, "
        "id from %s): the DAG submits it through %s",
        feed_config.get("id"), exec_id, dag_id, dag_run_id, dag_id_source,
        conf["submit_route"])

    if slot_release is not None and getattr(
            _cfg, "airflow_release_slot_while_polling", True):
        try:
            slot_release()
            logger.debug(
                "[feed_engine] airflow: released concurrency slot for %s "
                "while awaiting DAG %s", exec_id, dag_id)
        except Exception as _rel_exc:
            logger.debug(
                "[feed_engine] airflow slot release skipped (non-fatal): %s",
                _rel_exc)

    # -- Await the ROW (the webhook or the reconciler closes it) ----------
    poll_interval = max(0, int(af_cfg.poll_interval_seconds))
    deadline = time.time() + int(af_cfg.poll_timeout_seconds)
    _t_await = time.time()

    def _record_await() -> None:
        _st["spark_await"] = round(time.time() - _t_await, 3)

    def _stop_dag_run() -> None:
        """Best-effort: a DAG run that has not submitted yet is marked
        failed so the scheduler stops working on it; once the workload
        exists it is the workload that is cancelled."""
        try:
            client.set_dag_run_state(dag_id, dag_run_id, "failed")
            logger.info("[feed_engine] airflow: DAG run %s marked failed "
                        "after cancel of %s", dag_run_id, exec_id)
        except Exception as _cancel_exc:
            logger.warning(
                "[feed_engine] airflow: could not mark DAG run %s failed "
                "after cancel (%s) -- the DAG may still submit; the row is "
                "cancelled, so the submit is refused and a late callback "
                "rejected", dag_run_id, _cancel_exc)

    dag_terminal: Optional[str] = None
    # E-L3: poll IMMEDIATELY, then sleep -- never an idle interval before
    # the first look.
    while True:
        if _check_cancelled(exec_id, exec_db_id, db=db):
            row = await asyncio.to_thread(db.get_feed_execution, exec_db_id)
            if _lane.row_is_submitted(row or {}, dag_run_id):
                try:
                    from core.spark_k8s.runner import SparkK8sRunner
                    await asyncio.to_thread(SparkK8sRunner(db).cancel, row)
                except Exception as _c_exc:
                    logger.warning(
                        "[feed_engine] airflow: workload cancel of %s failed "
                        "here (the reconciler's terminal-row sweep deletes "
                        "it): %s", exec_id, _c_exc)
            else:
                await asyncio.to_thread(_stop_dag_run)
            _record_await()
            raise _FeedCancelled(
                f"cancelled while awaiting Airflow DAG {dag_id} run "
                f"{dag_run_id}")
        row = await asyncio.to_thread(db.get_feed_execution, exec_db_id)
        if row is None:
            raise RuntimeError(
                f"airflow: execution row {exec_db_id} disappeared while "
                f"awaiting DAG run {dag_run_id}")
        status = (row.get("status") or "").lower()
        if status == "completed":
            _record_await()
            return row
        if status == "failed":
            _record_await()
            raise RuntimeError(
                row.get("error_message")
                or f"airflow: execution {exec_id} failed (DAG run "
                   f"{dag_run_id})")
        if status == "cancelled":
            _record_await()
            raise _FeedCancelled(
                f"cancelled while Airflow DAG run {dag_run_id} ran")
        if not _lane.row_is_submitted(row, dag_run_id):
            # Until the DAG has submitted, the DAG run is what can fail.
            if dag_terminal is None:
                info = await asyncio.to_thread(
                    client.get_dag_run, dag_id, dag_run_id)
                if info.is_terminal:
                    dag_terminal = info.state
                    if dag_terminal == "success":
                        # The submit stamps the row BEFORE the route
                        # answers, so a success seen here is read against a
                        # FRESH row before it is called a contract breach.
                        row = await asyncio.to_thread(
                            db.get_feed_execution, exec_db_id) or row
            if dag_terminal is not None and not _lane.row_is_submitted(
                    row, dag_run_id):
                _record_await()
                if dag_terminal == "success":
                    raise RuntimeError(
                        f"Airflow DAG {dag_id} run {dag_run_id} reported "
                        f"success without submitting execution {exec_id} "
                        f"through {conf['submit_route']} (the ONE Airflow "
                        f"road, dispatch contract "
                        f"{_lane.DISPATCH_CONTRACT}; the DAG id came from "
                        f"{dag_id_source}).  A conf-driven DAG that runs "
                        f"the job itself is not supported: it would run "
                        f"without the source credentials, the artifact "
                        f"store and the delivery verdict.  Point the feed at "
                        f"the factory DAG, or run it with backend=native.")
                refusal = (row.get("stage_timings") or {}).get(
                    "spark_submit_refusal")
                if isinstance(refusal, dict) and refusal:
                    raise _AirflowSubmitRefused(
                        _lane.refusal_as_error(refusal))
                raise RuntimeError(
                    f"Airflow DAG {dag_id} run {dag_run_id} ended "
                    f"'{dag_terminal}' before it submitted execution "
                    f"{exec_id} through {conf['submit_route']}; nothing of "
                    f"this run is on the cluster.  The DAG's run_spark_job "
                    f"task log has the HTTP answer (a declared refusal is "
                    f"also recorded on this row).")
        if time.time() >= deadline:
            _record_await()
            raise RuntimeError(
                f"airflow: poll budget ({af_cfg.poll_timeout_seconds}s) "
                f"exhausted awaiting execution {exec_id} (DAG run "
                f"{dag_run_id}); a submitted job stays under the spark_k8s "
                f"reconciler, which deletes it once this row is failed")
        await asyncio.sleep(poll_interval)


def _fail_lane_refused(db: Any, exec_db_id, exec_record: dict,
                       feed_config: dict, refused, *, exec_id: str,
                       feed_run_id, triggered_by: str) -> dict:
    """Record a PINNED run whose lane cannot take it (K3,
    ``backend_router.LaneRefused``) as FAILED at
    ``preflight_lane_availability`` -- the same shape as the other
    preflight refusals -- with the lane's reason code and message, the
    lane the operator asked for as ``execution_backend``, and the refusal
    as the routing decision on ``files_metadata.backend_choice``."""
    message = str(refused)
    now = datetime.now(timezone.utc)
    try:
        fm = dict((db.get_feed_execution(exec_db_id) or {})
                  .get("files_metadata") or {})
    except Exception:
        fm = {}
    fm["backend_choice"] = {"backend": refused.lane, "reason": message,
                            "failed_over": False}
    db.update_feed_execution(exec_db_id, {
        "status": "failed",
        "completed_at": now,
        "error_message": message[:2000],
        "failed_stage": "preflight_lane_availability",
        "execution_backend": refused.lane,
        "files_metadata": fm,
    })
    try:
        _feed_run = (db.get_feed_run(int(feed_run_id))
                     if feed_run_id is not None else None)
        if _feed_run and _feed_run.get("status") not in (
                "completed", "failed", "cancelled"):
            db.update_feed_run(int(_feed_run["id"]), {
                "status": "failed", "completed_at": now,
                "error": message[:2000]})
    except Exception as _sync_exc:
        logger.warning(
            "[feed_engine] execution %s: lane refusal recorded, but syncing "
            "the parent feed_run failed (%s)", exec_db_id, _sync_exc)
    _notify("feed_failed", {
        "feed_id": feed_config.get("id"), "execution_id": exec_id,
        "feed_name": feed_config.get("name", ""), "error": message,
        "triggered_by": triggered_by,
    })
    return db.get_feed_execution(exec_db_id) or exec_record


def _spark_k8s_unreachable_to_native(choice, exc, *, db: Any, exec_db_id,
                                     stage_timings: dict, estimated_rows,
                                     cross_source: bool = False):
    """A spark_k8s submit met a cluster that did not answer (or the ladder
    refused at submit).  Returns the NATIVE ``BackendChoice`` the run now
    takes, or raises the plain-language reason it must fail with.

    2026-10-07 (D3) -- with the kind cluster stopped, a feed the size
    router sent to spark_k8s failed after 8 s with the kubernetes client's
    raw "HTTPSConnectionPool(...): Max retries exceeded", while the
    availability cache still said "available".  WHETHER to move is the
    router's ONE rule (``backend_router.lane_failed_at_submit`` over
    ``lane_unavailable``: auto-routed AND nothing of the run on the
    cluster); this function applies it: the native lane's own disk gate
    (the spark route skipped it), the stage record, and
    ``execution_backend`` -- so the reconciler, which supervises spark_k8s
    rows only, never adopts a native run.  The availability cache was
    already marked unavailable by the runner.
    """
    from core.feed.backend_router import LaneRefused, lane_failed_at_submit
    try:
        fallback = lane_failed_at_submit(choice, exc, cfg=_cfg)
    except LaneRefused as refused:
        logger.error("[feed_engine] spark_k8s run %s NOT moved to native: "
                     "%s (cause: %s)", exec_db_id, refused,
                     getattr(exc, "detail", "") or exc)
        raise RuntimeError(str(refused)) from None
    _disk_err = _disk_space_preflight(
        getattr(_cfg, "output_dir", None), estimated_rows,
        cross_source=cross_source)
    if _disk_err:
        raise RuntimeError(
            f"{fallback.reason}, but the native lane refused it too: "
            f"{_disk_err}") from None
    stage_timings["spark_k8s_fallback"] = {"to": "native",
                                           "reason": fallback.reason}
    db.update_feed_execution(exec_db_id, {"execution_backend": "native"})
    logger.warning("[feed_engine] execution %s: %s", exec_db_id,
                   fallback.reason)
    return fallback


async def _execute_spark_k8s(feed_config: dict, execution_record: dict,
                             db: Any = None,
                             stage_timings: Optional[dict] = None,
                             on_submitted: Optional[Callable[[str], None]] = None) -> dict:
    """QueryStudio-owned SparkApplication execution (2026-08-22).

    Submits the CR through ``core.spark_k8s.runner`` (the ONE submitter),
    then awaits the EXECUTION ROW reaching a terminal state — the signed
    webhook (rich path: output path, row count, completeness verification)
    or the reconciler (truth floor: OOM, eviction, image-pull failure,
    timeout) writes it; this coroutine only watches the row and honours
    cancel.  A QS pod restart mid-wait loses nothing: the row + CR are the
    durable state and the reconciler keeps supervising.

    Returns the terminal execution row on success.  Raises
    ``_FeedCancelled`` on cancel, ``RuntimeError`` on failure/poll budget
    (the reconciler's terminal-row sweep then deletes any still-live CR).
    """
    db = db if db is not None else _db_manager  # transition fallback
    from core.spark_k8s.manifest import settings_from_config
    from core.spark_k8s.runner import SparkK8sRunner

    settings = settings_from_config()
    runner = SparkK8sRunner(db, settings=settings)
    exec_id = execution_record.get("execution_id", "")
    exec_db_id = execution_record.get("id")

    # E-M6: calendar tokens resolve against the run's business date when a
    # feed_run row exists (SOD-generated), else today UTC.  ONE reading
    # for both detached lanes (``_run_business_date``, 2026-10-08).
    run_date = _run_business_date(feed_config)

    # FR-ID-04 (2026-09-03) — the Spark lane records its stage timings
    # into the SAME dict the native lane uses, under STABLE names
    # (spark_submit / spark_await — never derived from a run id), so
    # "which step usually fails" is answerable on this lane too and the
    # steps view has something to show.  ``stage_timings`` is the
    # caller's shared dict; a bare call (tests, transition) records into
    # a throwaway.
    _st = stage_timings if stage_timings is not None else {}
    _t_submit = time.time()
    result = await asyncio.to_thread(
        runner.submit, feed_config, execution_record, run_date=run_date,
    )
    _st["spark_submit"] = round(time.time() - _t_submit, 3)
    logger.info(
        "[feed_engine] Feed %s [%s] SparkApplication %s %s",
        feed_config.get("id"), exec_id, result.cr_name,
        "adopted (already running)" if result.adopted else "created",
    )
    # 2026-10-18 -- from here the JOB formats, checks and delivers: the
    # step record hands those steps to it (core/feed/step_model/detached.py)
    if on_submitted is not None:
        try:
            on_submitted(str(result.cr_name))
        except Exception as _hand_exc:      # noqa: BLE001 -- bookkeeping never fails a run
            logger.warning("[feed_engine] spark_k8s: steps not handed to the job (%s)", _hand_exc)

    _t_await = time.time()

    def _record_await() -> None:
        _st["spark_await"] = round(time.time() - _t_await, 3)

    poll_interval = max(1, int(settings.status_poll_interval_seconds))
    deadline = time.time() + int(settings.poll_timeout_seconds)
    _db_trouble_since: Optional[float] = None
    while True:
        # 2026-10-13 -- a database that is briefly unreachable from THIS pod
        # is not the job failing: the job keeps running (the reconciler and
        # the deadline below still bound it), so look again next poll.
        try:
            _cancelled = _check_cancelled(exec_id, exec_db_id, db=db)
            row = None if _cancelled else await asyncio.to_thread(db.get_feed_execution, exec_db_id)
        except Exception as _db_exc:
            from core.db.transient import is_transient_db_error
            if not is_transient_db_error(_db_exc) or time.time() >= deadline:
                raise
            if _db_trouble_since is None:
                _db_trouble_since = time.time()
                logger.warning(
                    "[feed_engine] spark_k8s %s: the database is not answering this pod "
                    "(%s) -- the job keeps running; looking again every %ss",
                    result.cr_name, type(_db_exc).__name__, poll_interval)
            await asyncio.sleep(poll_interval)
            continue
        if _db_trouble_since is not None:
            logger.info("[feed_engine] spark_k8s %s: the database answers again after %.0fs",
                        result.cr_name, time.time() - _db_trouble_since)
            _db_trouble_since = None
        if _cancelled:
            try:
                await asyncio.to_thread(runner.cancel, execution_record)
            except Exception as _c_exc:
                logger.warning(
                    "[feed_engine] spark_k8s cancel of %s failed here (the "
                    "reconciler's terminal-row sweep will delete the CR): %s",
                    result.cr_name, _c_exc,
                )
            _record_await()
            raise _FeedCancelled(
                f"cancelled while awaiting SparkApplication {result.cr_name}")
        if row is None:
            raise RuntimeError(
                f"spark_k8s: execution row {exec_db_id} disappeared while "
                f"awaiting SparkApplication {result.cr_name}")
        status = (row.get("status") or "").lower()
        if status == "completed":
            _record_await()
            return row
        if status == "failed":
            _record_await()
            raise RuntimeError(
                row.get("error_message")
                or f"spark_k8s: SparkApplication {result.cr_name} failed")
        if status == "cancelled":
            _record_await()
            raise _FeedCancelled(
                f"cancelled while SparkApplication {result.cr_name} ran")
        if time.time() >= deadline:
            # 2026-10-14 -- the SAME decision the reconciler makes
            # (core/feed/run_progress.budget_verdict): a job that is still
            # MOVING past this budget is awaited further, up to the ceiling;
            # the 40M pod run was killed healthy by this loop.
            from core.feed.run_progress import budget_verdict
            from core.config import spark_k8s as _sk_ceiling
            _stop, _why = budget_verdict(
                row, age_seconds=time.time() - _t_await,
                budget_seconds=int(settings.poll_timeout_seconds),
                ceiling_seconds=int(_sk_ceiling.job_ceiling_seconds))
            if not _stop:
                logger.info("[feed_engine] spark_k8s %s: still awaited -- %s",
                            result.cr_name, _why)
                deadline = time.time() + max(60, poll_interval * 10)
                await asyncio.sleep(poll_interval)
                continue
            _record_await()
            # The awaiting coroutine's budget only — the reconciler keeps
            # supervising the CR, and its terminal-row sweep deletes the
            # CR once this raise marks the row failed.
            raise RuntimeError(
                f"spark_k8s: poll budget ({settings.poll_timeout_seconds}s) exhausted "
                f"awaiting SparkApplication {result.cr_name} -- {_why}; the reconciler "
                f"will delete the still-running job")
        await asyncio.sleep(poll_interval)


# ---------------------------------------------------------------------------
# HTTP helper — delegated to shared module (Phase 127 extraction)
# ---------------------------------------------------------------------------
from core.http_utils import http_request as _http_request  # noqa: E402


# ---------------------------------------------------------------------------
# Format conversion (chunked streaming)
# ---------------------------------------------------------------------------
def _reraise_stream_abort(exc: BaseException, cancel_event: Any) -> None:
    """2026-08-05 — honest re-raise for a streaming Arrow reader abort.

    DuckDB aborts a streaming result by INTERRUPTING the reader, so a
    mid-stream QUERY error (e.g. a Conversion Error 6M rows in) surfaces as
    ``INTERRUPT Error: Interrupted!`` — which reads as "somebody cancelled
    me" and sends the operator to exactly the wrong place.
    ``duckdb_subprocess`` re-runs its canonical COPY to recover the real
    message; there is no equivalent cheap re-run here (it would re-execute a
    potentially huge feed query), so the honest safe treatment is to NAME
    the ambiguity.  A genuine cancel (the duckdb_cancel watchdog calling
    ``con.interrupt()`` after the feed's cancel event was set) is re-raised
    UNCHANGED so the existing cancel flow is untouched — and so is every
    non-INTERRUPT error.
    """
    # 2026-09-26: the decision "INTERRUPT with no cancel requested is a
    # masked worker-thread query error" is made ONCE, in
    # ``core.duckdb_cancel.is_masked_worker_error`` (which also records the
    # DuckDB mechanism); the thread lane of the multi-worker executor
    # applies the same predicate.
    from core.duckdb_cancel import is_masked_worker_error
    cancel_requested = cancel_event is not None and cancel_event.is_set()
    if is_masked_worker_error(exc, cancel_requested=cancel_requested):
        raise RuntimeError(
            "Feed query stream was aborted by DuckDB mid-stream (reported "
            "as INTERRUPT, but no cancel was requested).  This usually "
            "means the query itself hit a data error after streaming began "
            "(e.g. a cast/Conversion Error in a later row).  Re-run the "
            "feed SQL in the query editor to surface DuckDB's real error.  "
            f"Original: {exc}"
        ) from exc
    raise exc


def _certified_source_rows(row_count: Any, conversion_meta: Optional[dict]) -> Optional[int]:
    """Source-row count the completeness certificate must reconcile against.

    2026-08-03 (C1) — normally the engine-reported ``row_count`` (every source
    row reached the file).  When the conversion recorded a truncation
    (``conversion_meta["truncated"]`` — only reachable via the explicit
    ``allow_excel_truncation`` opt-in), the TRUE source count is returned so
    reconciliation sees source != dest and the certificate reads INCOMPLETE.
    Returning the truncated count here is exactly the bug that certified a
    half-empty feed COMPLETE (the file reconciled against itself).
    """
    if conversion_meta and conversion_meta.get("truncated"):
        _sr = conversion_meta.get("source_rows")
        if isinstance(_sr, int):
            return _sr
        # Truncation recorded but no usable source count — withhold the
        # number entirely (certificate then reads UNVERIFIED, never a
        # fabricated COMPLETE from the file reconciling against itself).
        return None
    return int(row_count) if isinstance(row_count, int) else None


# 2026-08-04 — the exception now lives with the renderers (the format layer
# owns format-capacity semantics); re-exported here for back-compat imports.


def _convert_to_format(parquet_path: str, output_format: str, output_path: str,
                       options: dict = None, chunk_size: int = 100000,
                       conversion_meta: dict = None) -> int:
    """Atomic wrapper around :func:`_convert_to_format_inner` (2026-08-03, C3).

    The inner conversion previously wrote row-by-row DIRECTLY into
    ``output_path`` — which for ``destination_type=local`` with the default
    destination IS the consumer-visible directory, so a consumer polling that
    directory could pick up a half-written file (torn read), and a failure
    mid-conversion left the partial file behind for the consumer to ingest.

    2026-08-04 — the scratch-dir + rename mechanics moved to the single
    publication primitive (``core.feed.publication.atomic_publication``);
    the renderer writes into a scratch path it is handed and never sees
    the consumer-visible name.  ``output_path`` either doesn't exist or
    is the COMPLETE file, never a fragment — by construction, for every
    format the registry will ever hold.
    """
    from core.feed.publication import atomic_publication
    with atomic_publication(output_path) as _tmp_path:
        return _convert_to_format_inner(
            parquet_path, output_format, str(_tmp_path), options, chunk_size,
            conversion_meta,
        )


def _convert_to_format_inner(parquet_path: str, output_format: str,
                             output_path: str, options: dict = None,
                             chunk_size: int = 100000,
                             conversion_meta: dict = None) -> int:
    """Chunked format conversion from parquet to the target format.
    Returns total row count.

    2026-08-04 — dispatches through the ``core.feed.renderers`` registry
    (one adapter class per format) instead of a per-format if/elif pile.
    Adding an output format is now one renderer subclass + one registry
    entry; this function, the atomic wrapper above, and the certificate's
    independent recount (``file_integrity.physical_row_count``) all pick
    it up with zero changes.  An unknown format raises
    ``UnsupportedOutputFormat`` (a ``ValueError``) listing what IS
    registered — loud, never a silent fallthrough.

    ``conversion_meta`` (optional dict, 2026-08-03 C1): populated in place
    with ``{"truncated": True, "source_rows": N, "written_rows": M}`` when a
    row-capped format (Excel) wrote fewer rows than the source holds and the
    feed explicitly opted in to truncated delivery — the caller uses it to
    report the run loudly and to certify it INCOMPLETE instead of COMPLETE.
    """
    from core.feed.renderers import get_renderer, EXCEL_MAX_ROWS
    renderer = get_renderer(output_format)
    # 2026-08-17 — ``max_output_rows`` defaults to 0 since 2026-08-13, and
    # 0 means UNLIMITED.  Passing the raw 0 here made
    # ``min(0, EXCEL_MAX_ROWS)`` == 0: every Excel feed with ANY rows
    # either failed with "the Excel row cap is 0" or (with the
    # truncation opt-in) delivered an EMPTY workbook.  Non-positive ⇒
    # the only cap is Excel's own physical 1,048,576-row limit.
    try:
        _max_rows = int(_cfg.max_output_rows) if _cfg is not None else 0
    except (TypeError, ValueError):
        _max_rows = 0
    if _max_rows <= 0:
        _max_rows = EXCEL_MAX_ROWS
    return renderer.render(
        parquet_path, output_path, options or {},
        chunk_size=chunk_size, max_output_rows=_max_rows,
        meta=conversion_meta,
    )


# ---------------------------------------------------------------------------
# Destination delivery with retry
# ---------------------------------------------------------------------------
def _deliver_to_destination(local_path: str, filename: str,
                            dest_type: str, dest_config: dict,
                            max_retries: int = 2, retry_delay: int = 60,
                            _receipt: dict = None) -> str:
    """
    Deliver file to destination with retry.
    Returns destination URI.

    2026-08-04 — dispatches through the ``core.feed.delivery_targets``
    registry (one adapter class per destination) instead of a per-target
    if/elif pile.  The retry policy stays HERE (framework-owned, one
    copy) — adapters supply only transport semantics.  An unknown
    destination raises ``UnsupportedDeliveryTarget`` (a ``ValueError``,
    handled below as a non-retryable configuration error) listing what
    IS registered.  ``_receipt`` (optional out-param dict) is filled
    with the adapter's DeliveryReceipt evidence (verification status,
    destination-side row counts) for the run record + certificate.
    """
    from core.feed.delivery_targets import get_delivery_target
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            target = get_delivery_target(dest_type)
            receipt = target.deliver(local_path, filename, dest_config)
            if _receipt is not None:
                _receipt.update(receipt.to_stage_record())
                _receipt["delivered_rows"] = receipt.delivered_rows
                _receipt["dropped_rows"] = receipt.dropped_rows
                _receipt["verification"] = receipt.verification
                _receipt["verification_detail"] = receipt.verification_detail
            return receipt.uri
        except Exception as exc:
            last_error = exc
            # BF-463 — don't retry on deterministic configuration errors.
            # ValueError from _deliver_local / _deliver_s3 / etc. means a
            # malformed path / missing bucket / illegal filename — retrying
            # 60s later won't fix it.  Network errors / IO errors / transient
            # auth errors are different (raise OSError / IOError / RuntimeError)
            # and DO get retried.  Without this guard, feed 2 spent 120s
            # retrying a deterministic Windows-path-outside-allowed-roots
            # error before giving up.
            if isinstance(exc, ValueError):
                logger.error(
                    "[feed_engine] Delivery configuration error (not retrying): %s",
                    exc,
                )
                raise RuntimeError(
                    f"Delivery failed (configuration error, no retry): {exc}"
                ) from exc
            if attempt < max_retries:
                logger.warning(
                    "[feed_engine] Delivery attempt %d/%d failed: %s — retrying in %ds",
                    attempt + 1, max_retries + 1, exc, retry_delay,
                )
                time.sleep(retry_delay)
            else:
                raise RuntimeError(
                    f"Delivery failed after {max_retries + 1} attempts: {last_error}"
                ) from last_error
    # Should not reach here, but satisfy type checker
    raise RuntimeError(f"Delivery failed: {last_error}")


# ---------------------------------------------------------------------------
# E-L1 — reuse one network connection across the data + control file pair
# ---------------------------------------------------------------------------
class _DeliverySession:
    """Holds a single reusable connection (S3 client / SFTP transport) so the
    data file and its sidecar control (.ctl) file ship over ONE connection
    instead of paying the connect/handshake cost twice.

    Only S3 and SFTP maintain a persistent connection; ``local`` / ``oracle``
    have no reusable session and fall back to per-file delivery.
    """

    def __init__(self, dest_type: str, dest_config: dict):
        self.dest_type = dest_type
        self._s3_client = None
        self._sftp = None
        self._transport = None
        self._host = None
        self._port = None
        if dest_type == "s3":
            self._s3_client = _build_s3_client(dest_config)
        elif dest_type == "sftp":
            self._transport, self._sftp, self._host, self._port = _sftp_connect(dest_config)
        else:
            raise ValueError(f"_DeliverySession does not support dest_type={dest_type!r}")

    def deliver(self, local_path: str, filename: str, dest_config: dict,
                _receipt: dict = None) -> str:
        if self.dest_type == "s3":
            return _deliver_s3(local_path, filename, dest_config,
                               _client=self._s3_client, _receipt=_receipt)
        if self.dest_type == "sftp":
            return _sftp_put_one(
                self._sftp, dest_config, filename, local_path, self._host,
                self._port, _receipt=_receipt,
            )
        raise ValueError(f"Unsupported dest_type: {self.dest_type}")

    def close(self):
        if self._sftp is not None:
            try:
                self._sftp.close()
            except Exception:
                pass
        if self._transport is not None:
            try:
                self._transport.close()
            except Exception:
                pass


def _session_deliver_with_retry(session, local_path: str, filename: str,
                                dest_type: str, dest_config: dict,
                                max_retries: int, retry_delay: int,
                                _receipt: dict = None) -> str:
    """Deliver one file over a reused session; on a transient failure fall
    back to the robust dedicated-connection path (``_deliver_to_destination``)
    so connection reuse can never make delivery LESS reliable.  ValueError
    (deterministic config error) is propagated unchanged.
    """
    try:
        return session.deliver(local_path, filename, dest_config,
                               _receipt=_receipt)
    except ValueError:
        raise
    except Exception as exc:
        logger.warning(
            "[feed_engine] reused-connection delivery failed (%s) — "
            "retrying %s with a dedicated connection", exc, filename,
        )
        return _deliver_to_destination(
            local_path, filename, dest_type, dest_config, max_retries,
            retry_delay, _receipt=_receipt,
        )


def _deliver_data_then_control(output_path: str, data_filename: str,
                               control_file_path: Optional[str],
                               dest_type: str, dest_config: dict,
                               max_retries: int, retry_delay: int,
                               feed_config_id="", exec_id="",
                               _receipt: dict = None,
                               sidecar_path: Optional[str] = None) -> str:
    """Deliver the data file (fatal on failure) then its optional control
    file (non-fatal — the data has already shipped), reusing ONE connection
    across the pair for S3 / SFTP (E-L1).  Returns the data file's URI.

    Fail-safe: if the reusable session can't be opened, every delivery falls
    back to the original one-connection-per-file path — behaviour unchanged.

    ``sidecar_path`` (2026-09-03) is the FR-ART-05 checksum sidecar, sent
    on the same connection under the same non-fatal posture as the
    control file: the data has already shipped, so failing the run now
    would report a delivery that happened as a failure.  It is recorded
    on the receipt either way — a sidecar the counterparty never received
    is exactly as invisible as the control file used to be, and for the
    same reason.
    """
    reuse = getattr(_cfg, "reuse_delivery_connection", True) if _cfg is not None else True
    session = None
    if reuse and (control_file_path or sidecar_path)             and dest_type in ("s3", "sftp"):
        try:
            session = _DeliverySession(dest_type, dest_config)
        except Exception as exc:
            logger.debug(
                "[feed_engine] delivery-connection reuse unavailable (%s) — "
                "using per-file connections", exc,
            )
            session = None
    try:
        # DATA file — fatal on failure.
        if session is not None:
            try:
                data_uri = _session_deliver_with_retry(
                    session, output_path, data_filename,
                    dest_type, dest_config, max_retries, retry_delay,
                    _receipt=_receipt,
                )
            except ValueError:
                raise
            except Exception:
                # Reuse path failed outright — fall back to a fresh dedicated
                # connection so the data file is as reliable as before.
                data_uri = _deliver_to_destination(
                    output_path, data_filename, dest_type, dest_config,
                    max_retries, retry_delay, _receipt=_receipt,
                )
        else:
            data_uri = _deliver_to_destination(
                output_path, data_filename, dest_type, dest_config,
                max_retries, retry_delay, _receipt=_receipt,
            )
        logger.info(
            "[feed_engine] Feed %s [%s] delivered to %s -> %s",
            feed_config_id, exec_id, dest_type, data_uri,
        )

        # CONTROL file — non-fatal (data already shipped).
        if control_file_path:
            ctl_name = Path(control_file_path).name
            try:
                if session is not None:
                    ctl_uri = _session_deliver_with_retry(
                        session, control_file_path, ctl_name,
                        dest_type, dest_config, max_retries, retry_delay,
                    )
                else:
                    ctl_uri = _deliver_to_destination(
                        control_file_path, ctl_name, dest_type, dest_config,
                        max_retries, retry_delay,
                    )
                logger.info(
                    "[feed_engine] Feed %s [%s] control file delivered -> %s",
                    feed_config_id, exec_id, ctl_uri,
                )
                if _receipt is not None:
                    _receipt["control_file_delivery"] = "delivered"
            except Exception as e:
                logger.warning(
                    "[feed_engine] Feed %s [%s] control file delivery failed: %s",
                    feed_config_id, exec_id, e,
                )
                # Phase 4 (2026-08-23): this failure was INVISIBLE -- the
                # run reported success, control_file_path was recorded,
                # and the consumer waited forever on a READY signal that
                # never arrived.  Non-fatal stays right (the data already
                # shipped); invisibility does not.
                if _receipt is not None:
                    _receipt["control_file_delivery"] = f"FAILED: {e}"[:500]

        # CHECKSUM SIDECAR — same posture, same reason (2026-09-03).
        if sidecar_path:
            _side_name = Path(sidecar_path).name
            try:
                if session is not None:
                    _side_uri = _session_deliver_with_retry(
                        session, sidecar_path, _side_name,
                        dest_type, dest_config, max_retries, retry_delay,
                    )
                else:
                    _side_uri = _deliver_to_destination(
                        sidecar_path, _side_name, dest_type, dest_config,
                        max_retries, retry_delay,
                    )
                logger.info(
                    "[feed_engine] Feed %s [%s] checksum sidecar delivered "
                    "-> %s", feed_config_id, exec_id, _side_uri)
                if _receipt is not None:
                    _receipt["sidecar_delivery"] = "delivered"
            except Exception as e:
                logger.error(
                    "[feed_engine] Feed %s [%s] checksum sidecar delivery "
                    "FAILED: %s — the data file shipped, so the run stands, "
                    "but the counterparty cannot verify it",
                    feed_config_id, exec_id, e)
                if _receipt is not None:
                    _receipt["sidecar_delivery"] = f"FAILED: {e}"[:500]
        return data_uri
    finally:
        if session is not None:
            session.close()


def _resolve_and_validate_local_dest_dir(raw_dest_dir: str) -> str:
    """BF-463 (2026-05-19) — extracted helper so pre-flight can validate
    the local-delivery destination BEFORE we burn 5 minutes on the query.

    Returns the normalized absolute dest dir on success.  Raises
    ValueError with an admin-actionable message on failure.

    Called from both:
      - _deliver_local (existing post-query path)
      - execute_feed pre-flight (new fail-fast path)
    """
    # 2026-10-07 (K5) -- the rule itself is core.feed.delivery_protocol.
    # resolve_local_destination, shared byte-identical with the Spark job
    # (which used to write /tmp/feed_output with no check).  This function
    # supplies the deployment's roots.
    from core.feed.delivery_protocol import resolve_local_destination
    _output_dir, _extra = local_destination_roots()
    return resolve_local_destination(raw_dest_dir, _output_dir, _extra)


def local_destination_roots() -> tuple:
    """``(output_dir, extra allowed roots)`` -- the deployment's answer to
    "where may a local delivery write", for this engine and for the Spark
    job's conf (``core/spark_k8s/feed_conf.py`` ships it).

    Resolved lazily -- _cfg is set via init_feed_engine() at startup but
    unit tests call this without init, so core.config.feed_generation is
    the fallback, and the process CWD the last resort."""
    try:
        _output_dir = _cfg.output_dir if _cfg is not None else None
    except AttributeError:
        _output_dir = None
    if not _output_dir:
        try:
            from core.config import feed_generation as _fg_cfg
            _output_dir = _fg_cfg.output_dir
        except Exception:
            _output_dir = os.getcwd()  # last-resort fallback
    extra: list = []
    try:
        from core.config import feed_generation as _fg_cfg
        extra = [str(p) for p in (getattr(
            _fg_cfg, "local_destination_allowed_roots", None) or []) if p]
    except Exception:
        extra = []
    return str(_output_dir), extra


def _deliver_local(local_path: str, filename: str, dest_config: dict,
                   _receipt: dict = None) -> str:
    """Copy file to local destination directory.

    ``_receipt`` (2026-08-04, optional out-param): filled with in-band
    verification evidence (``verification`` / ``verification_detail``) for
    the DeliveryReceipt the target adapter returns.

    BF-415 — previously the configured ``dest_config.path`` (admin-supplied)
    was passed straight to ``os.makedirs`` and ``os.path.join`` with no
    sanitisation, so an admin (or someone with admin tokens) could write
    to ``/etc/cron.d/`` etc.  Even if you trust the admin, a buggy template
    like ``"../{name}.csv"`` in ``output_filename_template`` (filename is
    NOT escaped by ``_build_filename`` for traversal) could escape the
    intended directory.  Now both the destination directory AND the
    final path are checked against an allowlist: the configured roots in
    ``feed_generation.local_destination_allowed_roots``, falling back to
    ``_cfg.output_dir`` when the list is empty.  Filenames containing
    ``..``, path separators, or NUL bytes are rejected outright.
    """
    # 1) Reject filenames that try to escape via path components / NULs;
    # 2) validate the destination dir (the helper execute_feed's pre-flight
    #    also calls, so we fail BEFORE the 5-minute query, not after);
    # 3) re-check the joined path (covers exotic filename edge cases).
    # All three are core.feed.delivery_protocol's rules (2026-10-07, K5).
    from core.feed.delivery_protocol import check_filename, local_target
    try:
        check_filename(filename)
    except ValueError as _fn_exc:
        raise ValueError(f"Local destination: {_fn_exc}") from _fn_exc
    raw_dest_dir = dest_config.get("path") or _cfg.output_dir
    dest_dir_norm = _resolve_and_validate_local_dest_dir(raw_dest_dir)
    os.makedirs(dest_dir_norm, exist_ok=True)
    _out_dir, _extra_roots = local_destination_roots()
    dest_path_norm = local_target(dest_dir_norm, filename, _out_dir,
                                  _extra_roots)
    # 2026-10-07 (lane contract K5) -- the ONE local-delivery protocol,
    # shared byte-identically with the Spark job's _deliver_local
    # (spark/jobs/qs_delivery_protocol.py): a scratch copy in a
    # .qs-partial sibling (invisible to a consumer globbing the directory,
    # the structure core/feed/publication.py made standard), an atomic
    # replace, the sizes compared.  Was publication.publish_file + a size
    # check spelled HERE -- the same protocol a second time, and the job
    # had a third.  A copy that fails raises (the delivery fails); a size
    # that disagrees raises; a stat that cannot run reads "absent".
    from core.feed.delivery_protocol import ABSENT, VERIFIED, publish_local
    if os.path.abspath(local_path) != dest_path_norm:
        _pub = publish_local(local_path, dest_path_norm)
    else:
        try:
            _pub = {"verification": VERIFIED,
                    "detail": f"size={os.path.getsize(dest_path_norm)}"}
        except OSError as _v_exc:
            _pub = {"verification": ABSENT,
                    "detail": f"stat-failed: {_v_exc}"}
    if _receipt is not None:
        _receipt["verification"] = _pub["verification"]
        _receipt["verification_detail"] = _pub["detail"]
    if _pub["verification"] != VERIFIED:
        logger.warning(
            "[feed_engine] local delivery verification unavailable "
            "for %s: %s", dest_path_norm, _pub["detail"],
        )
    return dest_path_norm


def _build_s3_client(dest_config: dict):
    """Construct a boto3 S3 client for a delivery destination.

    Extracted from ``_deliver_s3`` (E-L1) so a single client can be reused
    across the data + control file pair instead of being rebuilt per file.
    Handles direct keys OR credential resolution via connection_id
    (portal / assume_role / STS) plus proxy config.
    """
    import boto3

    s3_kwargs = {}
    endpoint_url = dest_config.get("endpoint_url")
    if endpoint_url:
        s3_kwargs["endpoint_url"] = endpoint_url
    region = dest_config.get("region")
    if region:
        s3_kwargs["region_name"] = region

    # Resolve credentials: direct keys OR via connection_id (portal/STS/etc.)
    access_key = dest_config.get("access_key_id") or dest_config.get("aws_access_key_id")
    secret_key = dest_config.get("secret_access_key") or dest_config.get("aws_secret_access_key")
    session_token = dest_config.get("session_token") or dest_config.get("aws_session_token")

    # If no direct keys, try resolving via connection_id
    if not (access_key and secret_key) and dest_config.get("connection_id") and _db_manager:
        try:
            conn_raw = _db_manager.get_connection_raw(dest_config["connection_id"])
            if conn_raw and conn_raw.get("connection_type") == "s3":
                # Phase 131 deep-dive #8 — single utility resolves user
                # from dest_config which has _triggered_by_user attached.
                from core.credential_resolver import resolve_s3_for_consumer
                resolved = resolve_s3_for_consumer(conn_raw.get("config") or {}, dest_config)
                access_key = resolved.get("aws_access_key_id", "")
                secret_key = resolved.get("aws_secret_access_key", "")
                session_token = resolved.get("aws_session_token", "")
                if not region:
                    region = resolved.get("region_name") or resolved.get("region")
                    if region:
                        s3_kwargs["region_name"] = region
        except Exception as exc:
            logger.warning("[feed] S3 delivery credential resolution failed: %s", exc)

    if access_key and secret_key:
        s3_kwargs["aws_access_key_id"] = access_key
        s3_kwargs["aws_secret_access_key"] = secret_key
    if session_token:
        s3_kwargs["aws_session_token"] = session_token

    from core.proxy_utils import get_boto_proxies
    from botocore.config import Config as BotoConfig
    _px = get_boto_proxies(endpoint_url=endpoint_url or "")
    if _px:
        s3_kwargs["config"] = BotoConfig(proxies=_px)
    return boto3.client("s3", **s3_kwargs)


def _deliver_s3(local_path: str, filename: str, dest_config: dict,
                _client=None, _receipt: dict = None) -> str:
    """Upload file to S3 bucket.

    Supports credential resolution via connection_id (portal, assume_role, etc.)
    or direct access_key_id/secret_access_key in dest_config.

    ``_client`` (E-L1): an optional pre-built boto3 client reused across the
    data + control file pair.  When ``None`` a dedicated client is built —
    identical to the original per-call behaviour.

    ``_receipt`` (2026-08-04, optional out-param): filled with in-band
    verification evidence.  The HEAD check runs with the SAME client that
    performed the upload — the destination's real credentials — so unlike
    the old layer-2 verifier there is no wrong-credential client that can
    only fail.  A HEAD that cannot run is recorded as ``absent`` WITH the
    reason, never as silent success.
    """
    # 2026-10-07 (K5) -- ONE object named by the feed's template, the key
    # rule shared with the Spark job (core.feed.delivery_protocol); the
    # job used to leave a part DIRECTORY <prefix>/<execution id>/part-*.
    from core.feed.delivery_protocol import s3_object_key, verify_size
    bucket = dest_config.get("bucket", "")
    s3_key = s3_object_key(dest_config.get("prefix", ""), filename)

    client = _client if _client is not None else _build_s3_client(dest_config)
    # the object becomes visible when the upload completes: THE publish gate
    # (core/feed/delivery_protocol.publishing) -- refused while this process
    # shuts down, waited for while inside
    from core.feed.delivery_protocol import publishing as _publishing
    with _publishing(f"s3://{bucket}/{s3_key}"):
        client.upload_file(local_path, bucket, s3_key)

    # Phase 132-D: Verify upload — compare remote size to local file size
    try:
        local_size = os.path.getsize(local_path)
        head = client.head_object(Bucket=bucket, Key=s3_key)
        remote_size = head.get("ContentLength", -1)
        try:
            verify_size(local_size, remote_size, f"s3://{bucket}/{s3_key}")
        except RuntimeError as _mm:
            logger.error(
                "[feed_engine] S3 upload size mismatch: local=%d remote=%d key=%s",
                local_size, remote_size, s3_key,
            )
            raise RuntimeError(
                f"S3 upload verification failed: size mismatch "
                f"(local={local_size}, remote={remote_size})"
            ) from _mm
        if _receipt is not None:
            _receipt["verification"] = "verified"
            _receipt["verification_detail"] = (
                f"head_object size={remote_size} (same client as upload)")
    except RuntimeError:
        raise  # Re-raise our own size mismatch error
    except Exception as verify_exc:
        logger.warning("[feed_engine] S3 upload verify skipped (head_object failed): %s",
                       verify_exc)
        if _receipt is not None:
            _receipt["verification"] = "absent"
            _receipt["verification_detail"] = f"head_object failed: {verify_exc}"

    return f"s3://{bucket}/{s3_key}"


def _sftp_connect(dest_config: dict):
    """Establish an authenticated SFTP connection with host-key verification.

    Extracted from ``_sftp_upload`` (E-L1) so ONE transport can be reused
    across the data + control file pair instead of paying the TCP + SSH
    handshake + auth cost twice.  Returns ``(transport, sftp, host, port)``;
    the caller owns closing both ``sftp`` and ``transport``.  Behaviour
    (host-key pinning / known_hosts / auth) is identical to the original
    inline logic.
    """
    try:
        import paramiko
    except ImportError:
        raise RuntimeError(
            "paramiko is required for SFTP delivery. Install with: pip install paramiko>=3.0.0"
        )

    host = dest_config.get("host", "")
    port = int(dest_config.get("port", 22))

    sftp_cfg = _cfg.sftp
    connect_timeout = sftp_cfg.connect_timeout_seconds

    # BF-415 — SFTP host-key verification.  Previously paramiko.Transport
    # was used directly with no HostKeys / no host_key argument and no
    # set_missing_host_key_policy → every SFTP delivery was vulnerable to
    # MITM credential theft.  Now we resolve a host key via (in order):
    #   1) explicit ``dest_config["host_key_b64"]`` (pinned key, base64 of
    #      the public key — the most secure form for K8s secrets), OR
    #   2) ``dest_config["known_hosts_path"]`` file (paramiko HostKeys
    #      OpenSSH-format), OR
    #   3) the system-default known_hosts at ``~/.ssh/known_hosts``.
    # If none of these contain a key for ``host``, we REFUSE the upload
    # rather than trust an unknown server.  Operators who really want
    # blind-trust (lab, ephemeral env) must opt in with the explicit
    # ``dest_config["allow_unknown_host_key"] = True`` and a log warning
    # is emitted on every connection.
    pinned_host_key = None
    host_key_b64 = (dest_config.get("host_key_b64") or "").strip()
    if host_key_b64:
        # BF-415 follow-up — previously iterated over the paramiko KEY CLASSES
        # and called ``cls.get_name()`` as if it were a classmethod; it isn't,
        # so every iteration raised TypeError, the bare except swallowed it,
        # and pinned_host_key stayed None.  Result: operators pinning a key
        # via host_key_b64 (the documented "most secure" form) got an instant
        # ValueError.  Now we iterate the SSH wire-format algorithm names
        # paramiko understands, which are the actual values from_type_string()
        # accepts, and try each in priority order.
        try:
            import base64 as _b64
            from paramiko import PKey as _PKey
        except ImportError as _hk_exc:
            raise ValueError(f"paramiko is required for host_key_b64: {_hk_exc}")
        try:
            _key_blob = _b64.b64decode(host_key_b64)
        except Exception as _hk_exc:
            raise ValueError(f"host_key_b64 is not valid base64: {_hk_exc}")
        for _algo in (
            "ssh-ed25519",
            "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521",
            "rsa-sha2-512", "rsa-sha2-256", "ssh-rsa",
        ):
            try:
                pinned_host_key = _PKey.from_type_string(_algo, _key_blob)
                break
            except Exception:
                continue
        if pinned_host_key is None:
            raise ValueError(
                "host_key_b64 could not be parsed as Ed25519 / ECDSA / RSA "
                "(supplied blob did not match any supported algorithm)"
            )

    if pinned_host_key is None:
        # Try a HostKeys file (OpenSSH known_hosts format)
        kh_path = dest_config.get("known_hosts_path") or os.path.expanduser("~/.ssh/known_hosts")
        try:
            if os.path.exists(kh_path):
                _hk = paramiko.HostKeys()
                _hk.load(kh_path)
                _entries = _hk.lookup(host) or _hk.lookup(f"[{host}]:{port}")
                if _entries:
                    # Prefer the strongest key the file lists for this host.
                    for _algo in ("ssh-ed25519", "ecdsa-sha2-nistp256",
                                   "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521",
                                   "ssh-rsa"):
                        if _algo in _entries:
                            pinned_host_key = _entries[_algo]
                            break
                    if pinned_host_key is None:
                        # Take whatever is there
                        pinned_host_key = next(iter(_entries.values()), None)
        except Exception as _kh_exc:
            logger.warning(
                "[sftp] failed to read known_hosts at %s: %s",
                kh_path, _kh_exc,
            )

    if pinned_host_key is None:
        if dest_config.get("allow_unknown_host_key"):
            logger.warning(
                "[sftp] allow_unknown_host_key=true — connecting to %s:%d "
                "WITHOUT host-key verification (MITM risk).",
                host, port,
            )
        else:
            raise RuntimeError(
                f"SFTP host {host!r} has no known host key.  Provide one of "
                f"dest_config.host_key_b64 (pinned, recommended), "
                f"dest_config.known_hosts_path, or set "
                f"dest_config.allow_unknown_host_key=true to connect without "
                f"verification (NOT recommended in production)."
            )

    # Phase 158 R5 (2026-06-26) -- route SFTP creds through
    # qs_credentials when the dest_config has a system_account
    # reference and literal user/pass are blank.  Literal values ALWAYS
    # win when set (back-compat for connections that pre-date vault).
    #
    # AQD-10/11 (2026-09-23) -- the METHOD is decided once, before the socket
    # opens, by core.feed.sftp_auth: a configured key that cannot be loaded
    # REFUSES (it used to fall through to password auth, silently), Ed25519 /
    # ECDSA / RSA all load, and a vault kv_secrets account may carry the
    # private key itself.  The method and its source are logged and put on
    # the receipt; the secret never is.
    from core.feed.sftp_auth import SftpAuthRefused, resolve_sftp_auth
    sa_ref = (
        dest_config.get("system_account_id")
        or dest_config.get("system_account_name")
    )
    account = None
    account_error = None
    if sa_ref and (not dest_config.get("username") or not dest_config.get("password")):
        try:
            from core.qs_credentials import resolve_system_account
            account = resolve_system_account(sa_ref)
        except Exception as exc:
            account_error = f"{type(exc).__name__}: {exc}"
            logger.warning(
                "SFTP delivery: qs_credentials lookup failed for "
                "system_account=%r (%s) -- using literal dest_config only.",
                sa_ref, exc,
            )
    try:
        auth = resolve_sftp_auth(dest_config, account)
    except SftpAuthRefused as exc:
        if account_error:
            raise SftpAuthRefused(
                f"{exc}  (system account {sa_ref!r} could not be resolved: "
                f"{account_error})") from exc
        raise
    logger.info("[sftp] %s:%d authenticating: method=%s user=%s source=%s key_type=%s",
                host, port, auth.method, auth.username, auth.source, auth.key_type)

    # BF-121: Apply connect_timeout to socket (was computed but never used)
    import socket as _sock
    _sock_obj = _sock.create_connection((host, port), timeout=connect_timeout)
    transport = paramiko.Transport(_sock_obj)
    try:
        # BF-415 — supply pinned key via start_client so paramiko verifies
        # the server's identity BEFORE we send credentials.
        if pinned_host_key is not None:
            # BF-415 follow-up — bias KEX to the pinned key's algorithm so
            # the server doesn't negotiate a different host-key algorithm
            # (e.g. server presents Ed25519 when we pinned an RSA key,
            # making the post-handshake comparison spuriously fail with
            # "host key mismatch").  Mirrors paramiko.Transport.connect().
            try:
                _algo_name = pinned_host_key.get_name()
                if _algo_name == "ssh-rsa":
                    transport._preferred_keys = ("rsa-sha2-512", "rsa-sha2-256", "ssh-rsa")
                else:
                    transport._preferred_keys = (_algo_name,)
            except Exception:
                pass  # paramiko private API — fall back to defaults if unavailable
            transport.start_client(timeout=connect_timeout)
            _server_key = transport.get_remote_server_key()
            if _server_key is None or (
                _server_key.get_name() != pinned_host_key.get_name()
                or _server_key.asbytes() != pinned_host_key.asbytes()
            ):
                raise RuntimeError(
                    f"SFTP host key mismatch for {host}:{port} — "
                    f"server presented {_server_key.get_name() if _server_key else 'no key'}, "
                    f"expected pinned key.  Refusing to connect (possible MITM)."
                )

        if auth.method == "publickey":
            if pinned_host_key is not None:
                transport.auth_publickey(username=auth.username, key=auth.pkey)
            else:
                transport.connect(username=auth.username, pkey=auth.pkey)
        else:
            if pinned_host_key is not None:
                transport.auth_password(username=auth.username, password=auth.password)
            else:
                transport.connect(username=auth.username, password=auth.password)

        transport.set_keepalive(30)
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.qs_auth = auth.describe()   # for the receipt (_sftp_put_one)
    except Exception:
        # Any failure after the socket/transport is open must close it —
        # the caller only owns the transport once we return successfully.
        try:
            transport.close()
        except Exception:
            pass
        raise
    return transport, sftp, host, port


def _sftp_put_one(sftp, dest_config: dict, filename: str, local_path: str,
                  host: str, port: int, _receipt: dict = None) -> str:
    """Upload a single file over an already-open SFTP connection (E-L1).

    remote_dir is validated per-put (same checks the inline path used) so a
    malformed remote_dir surfaces as a ValueError — treated as a
    non-retryable configuration error by ``_deliver_to_destination``.

    2026-08-04 — post-delivery verification is IN-BAND: after the rename
    the remote file is stat'ed over the SAME authenticated connection
    that uploaded it and its size compared to the local file.  The old
    layer-2 verifier (``file_integrity.verify_post_delivery``) silently
    returned unless a ``sftp_client_factory`` was injected — and the
    engine never injected one, so SFTP verification was structurally
    ABSENT while looking configured.  Verifying on the delivery
    connection removes the injection requirement entirely: there is no
    factory to forget.  A stat that cannot run is recorded on the
    receipt as ``absent`` with the reason — visible, never silent.
    """
    if _receipt is not None and getattr(sftp, "qs_auth", None):
        _receipt["auth"] = dict(sftp.qs_auth)   # AQD-10: which method delivered it
    # 2026-10-07 (K5) -- THE protocol, shared with the Spark job
    # (core/feed/delivery_protocol.py, mirrored byte-identical into
    # spark/jobs/qs_delivery_protocol.py): remote_dir rules (BF-121 path
    # traversal, BF-263 empty), ``.part`` + rename (2026-08-03 C3: a
    # consumer polling the directory never sees a fragment), and the
    # in-band size check over the SAME connection.  The job used to put
    # straight under the final name.
    from core.feed.delivery_protocol import sftp_publish
    out = sftp_publish(sftp, dest_config.get("remote_dir", "/"), filename,
                       local_path, log=logger)
    if _receipt is not None:
        _receipt["verification"] = out["verification"]
        _receipt["verification_detail"] = out["detail"]
    if out["verification"] != "verified":
        logger.warning(
            "[feed_engine] SFTP delivery verification unavailable for %s: %s",
            out["remote_path"], out["detail"])
    return f"sftp://{host}:{port}{out['remote_path']}"


def _sftp_upload(local_path: str, dest_config: dict, filename: str,
                 _receipt: dict = None) -> str:
    """SFTP upload using paramiko — single-file path (opens + closes its own
    connection).  Thin wrapper over ``_sftp_connect`` + ``_sftp_put_one`` so
    the data+control pair can share a connection via ``_DeliverySession``.
    """
    transport, sftp, host, port = _sftp_connect(dest_config)
    try:
        return _sftp_put_one(sftp, dest_config, filename, local_path, host,
                             port, _receipt=_receipt)
    finally:
        try:
            sftp.close()
        except Exception:
            pass
        try:
            transport.close()
        except Exception:
            pass


def _deliver_oracle(local_path: str, filename: str, dest_config: dict,
                    _receipt: dict = None) -> str:
    """Write feed output to Oracle table via oracledb + PyArrow batch insert.

    dest_config keys:
      connection_id: int — links to existing Oracle connection in QueryStudio
      table: str — target table (e.g. "APP.FEED_TARGET"); created from the
        result when missing, by the rule both lanes share
        (core/feed/oracle_destination_table.py)
      mode: str — "insert" | "truncate_insert" | "append" (default "append");
        truncate_insert is a DELETE in the inserting transaction
      batch_size: int — rows per INSERT batch (default 5000)

    ``_receipt`` (2026-08-04, optional out-param): filled with the
    DESTINATION-side row accounting (``delivered_rows`` = rows that
    actually reached the table, ``dropped_rows`` = rows the database
    rejected but the delivery still committed under the
    ``max_error_percent`` tolerance).  The completeness certificate
    reconciles against ``delivered_rows`` — previously it recounted the
    local FILE, so an Oracle delivery missing up to 5% of rows was
    certified COMPLETE.  The tolerance itself is unchanged (delivery
    still commits under the threshold); what changed is that it can no
    longer be silent.
    """
    try:
        import oracledb
    except ImportError:
        raise RuntimeError(
            "oracledb is required for Oracle delivery. Install with: pip install oracledb>=2.0.0"
        )
    import pyarrow.parquet as pq

    # 2026-09-15 -- THIS TARGET READS PARQUET AND ONLY PARQUET.  A feed whose
    # output_format is csv/json/excel formats perfectly well and then dies
    # here, AFTER the whole query and format, with pyarrow's
    # "Parquet magic bytes not found in footer. Either the file is corrupted
    # or this is not a parquet file." -- which sends the operator looking for
    # a corrupt file when the real answer is "this feed is configured to
    # deliver CSV into a target that can only load parquet".  Seen live: feed
    # 2 (destination oracle) routed to the native lane when spark_k8s was
    # unavailable, produced a 24MB CSV of 500,000 rows, and failed at the
    # last hop.  The reason slot was filled and said the wrong thing.
    #
    # Say what is actually wrong.  This does NOT decide the larger question
    # (teach this target to read CSV, or refuse the combination at authoring
    # time) -- it stops the message from misdirecting whoever hits it.
    # Strictly additive: if the file cannot be read here, say NOTHING and let
    # the existing path report it -- a missing or unreadable file is a
    # different problem that pyarrow already names, and inventing a second
    # failure mode for it would change behaviour this gate has no business
    # changing.  Only a file that IS readable and is NOT parquet is refused.
    try:
        with open(local_path, "rb") as _fh:
            _magic = _fh.read(4)
    except OSError:
        _magic = b"PAR1"          # unknown -- defer to the reader below
    if _magic != b"PAR1":
        _ext = os.path.splitext(filename)[1].lstrip(".").lower() or "unknown"
        # ValueError, deliberately: the retry policy above treats ValueError
        # as a DETERMINISTIC configuration error and does not retry it.  A
        # CSV will still be a CSV in 60 seconds.  (pyarrow's own ArrowInvalid
        # is a ValueError, so this keeps the classification the misleading
        # message already had.)
        raise ValueError(
            f"Oracle delivery requires a PARQUET file and this feed produced "
            f"{filename!r} ({_ext} format). The file is not corrupt -- it is "
            f"the wrong format for this destination. Set the feed's output "
            f"format to parquet, or deliver to a destination that accepts "
            f"{_ext}.")

    # Resolve connection credentials
    connection_id = dest_config.get("connection_id")
    if not connection_id:
        raise ValueError("Oracle destination requires 'connection_id' in destination_config")

    conn_record = _db_manager.get_connection_raw(connection_id)
    if not conn_record:
        raise ValueError(f"Oracle connection {connection_id} not found")

    conn_cfg = conn_record.get("config") or {}
    host = conn_cfg.get("host", "")
    port = int(conn_cfg.get("port") or 1521)
    service_name = conn_cfg.get("service_name", "")
    # ``user`` (the connection form's spelling) or ``username`` -- ONE
    # resolver shared with the Spark lanes (core/spark_k8s/jdbc.py).
    # Reading ``username`` alone here meant a UI-authored Oracle
    # connection logged in as '' for delivery (2026-09-13).
    from core.spark_k8s.jdbc import connection_principal as _principal
    username = _principal(conn_cfg)
    password = conn_cfg.get("password", "")

    table = dest_config.get("table", "")
    if not table:
        raise ValueError("Oracle destination requires 'table' in destination_config")

    # Validate table name against injection (allow SCHEMA.TABLE format only)
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$', table):
        raise ValueError(f"Invalid Oracle table name: {table}")

    mode = dest_config.get("mode", "append")
    batch_size = int(dest_config.get("batch_size") or _cfg.oracle_batch_size)

    # Read the feed output file.
    #
    # 2026-07-31 MEMORY BOUND: this used to do ``pf.read()`` (the ENTIRE feed
    # output as an Arrow table) plus ``arrow_table.to_pandas()`` (a second full
    # copy) BEFORE a loop that inserts in batches.  The insert was bounded; the
    # SOURCE was not.  At feed scale (10-20M rows x ~900 cols) that is an
    # O(result) allocation whose only purpose is to be sliced into batches --
    # the pod OOMs before the first row reaches Oracle.
    #
    # Now: schema + emptiness from the FOOTER (O(1), no row data), and the rows
    # are streamed with ``iter_batches`` so peak memory is O(batch).  The
    # insert loop, its NaN/inf cleaning, batcherrors handling and the
    # error-rate threshold are all unchanged -- only where the rows come from.
    pf = pq.ParquetFile(local_path)
    columns = list(pf.schema_arrow.names)
    _total_source_rows = pf.metadata.num_rows

    # 2026-10-07 -- AN EMPTY RESULT STILL CONNECTS.  This returned here,
    # before connecting, whenever the parquet had no rows.  The Spark lane
    # never did: its JDBC writer honours the mode whatever the row count, so
    # an empty truncate_insert EMPTIED the table on spark_k8s and left
    # yesterday's rows in place -- reading as today's -- on native.  The
    # mode is now honoured on both lanes, and an empty result into a
    # MISSING table creates nothing on either (rule 6 of
    # core/feed/oracle_destination_table.py).

    # Validate column names (Oracle identifiers: alphanumeric + underscore)
    for col in columns:
        if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', col):
            raise ValueError(f"Invalid column name for Oracle: {col}")

    # 2026-10-07 -- A SQL TIME column is refused HERE, before connecting,
    # whether or not the table exists.  Oracle has no TIME type; this lane
    # used to refuse it only when CREATING a table, and into an existing one
    # the driver failed mid-insert.  The Spark lanes refuse the same column
    # from the source's JDBC metadata before reading -- one rule, one
    # message (core/feed/oracle_destination_table.py, rule C) -- and WHICH
    # destinations refuse a TIME is declared once, in
    # core/feed/lane_output.py (TIME_REFUSED_DESTINATIONS, K4): both lanes
    # ask it, the job in _read_jdbc and this lane here.
    from core.feed.lane_output import time_refused_for as _time_refused_for
    _time_cols = _time_columns_in_arrow(columns, list(pf.schema_arrow.types))
    if _time_cols and _time_refused_for("oracle"):
        _refuse_time_columns(_time_cols)

    # Connect to Oracle (thin mode — no Oracle Client needed)
    dsn = oracledb.makedsn(host, port, service_name=service_name)
    try:
        ora_conn = oracledb.connect(user=username, password=password, dsn=dsn)
    except Exception as exc:
        # Sanitize to prevent credential leakage in error messages
        raise RuntimeError(f"Oracle connection failed to {host}:{port}/{service_name}") from exc
    try:
        cursor = ora_conn.cursor()

        # 2026-09-15 -- ADOPT THE TABLE'S SPELLING ON A CASE-ONLY DIFFERENCE.
        #
        # This quoted the PARQUET's column names verbatim.  Oracle folds an
        # unquoted identifier to upper case when the table is created, so the
        # stored name is ``AMOUNT`` -- and a QUOTED ``"amount"`` is a
        # different, non-existent identifier: ORA-00904: "amount": invalid
        # identifier.  Every parquet QueryStudio produces from an Oracle
        # source has lower-case columns (the connector's own
        # ``_fetchall_as_dicts`` lowercases them), so this lane could not
        # deliver into an ordinarily-created table AT ALL.  It survived
        # because the spark lane delivers over JDBC, never through here, and
        # because the unit tests mock the cursor -- a mocked cursor accepts
        # any identifier.
        #
        # Ask the TABLE what its columns are called (``WHERE 1=0`` reads the
        # shape without a row) and use that spelling.  This is the same rule
        # column detection already applies to Trino: on a case-ONLY
        # difference the engine's spelling wins.
        #
        # 2026-09-21 (FB-59) -- the MATCH now lives in ONE place,
        # ``core/feed/oracle_identifiers.py``, mirrored into the Spark job's
        # image, because the Spark lane answered the same question
        # differently and a table it CREATED could not be read by
        # ``SELECT REGION``.  This lane's behaviour is unchanged; what
        # changed is that it no longer holds a private copy of the rule.
        #
        # 2026-10-07 -- A MISSING TABLE IS CREATED, by the SAME rule the
        # Spark lane runs (core/feed/oracle_destination_table.py, mirrored
        # into the job image).  This lane used to refuse ORA-00942 while
        # spark_k8s's JDBC writer created the table, so the same feed
        # completed or failed depending on which engine the SIZE router
        # picked that day (docker proof spark_pods_proof.py S1).  CREATE is
        # DDL and runs BEFORE anything is pending, so it never commits half
        # of this delivery's transaction.
        def _probe(sql):
            cursor.execute(sql)
            return [d[0] for d in (cursor.description or [])]

        try:
            _table_cols, _created = _ensure_oracle_table(
                table, columns, [str(t) for t in pf.schema_arrow.types],
                "arrow", _probe, cursor.execute,
                result_is_empty=lambda: _total_source_rows == 0,
                canonical_names=_canonical_oracle_columns)
        except _OracleTableUnavailable as _shape_exc:
            raise RuntimeError(str(_shape_exc)) from _shape_exc
        if _table_cols is None:
            # Rule 6: an empty result never creates a table -- this lane's
            # empty parquet carries no source types, so the table would be
            # VARCHAR2 forever.  The first non-empty run creates it.
            logger.info(
                "[feed_engine] Oracle delivery: 0 rows and %s does not exist "
                "-- an empty result does not create a table; nothing written",
                table)
            if _receipt is not None:
                _receipt["verification"] = "verified"
                _receipt["verification_detail"] = (
                    f"0 source rows; {table} does not exist and an empty "
                    f"result does not create it -- nothing written")
                _receipt["delivered_rows"] = 0
                _receipt["dropped_rows"] = 0
            return f"oracle://{host}:{port}/{service_name}/{table}"
        if _created:
            logger.info("[feed_engine] Oracle delivery: created %s from the "
                        "result schema", table)
        # REFUSES on a source column with no home: dropping it would insert
        # the remaining values into the wrong positions or silently write
        # NULLs -- a delivery that "succeeded" with shifted data is far
        # worse than one that stops here and says which column has no home.
        _resolved = _resolve_oracle_columns(columns, _table_cols, table)

        # 2026-09-15 -- EMPTY THE TABLE ONLY AFTER THE COLUMNS RESOLVE.  This
        # used to run FIRST, so a feed whose parquet had a column the table
        # does not have would empty the table and THEN refuse to write: the
        # destination loses its previous contents and gains nothing.
        #
        # 2026-10-07 -- DELETE, IN THIS TRANSACTION, NOT TRUNCATE.  TRUNCATE
        # is DDL and commits on its own, so a failure in the INSERTs below
        # left the table empty (or, on the Spark lane, half-filled).  The
        # DELETE commits with the rows that replace it, or rolls back with
        # them: the counterparty sees yesterday's table or today's, never a
        # mixture (rule B, core/feed/oracle_destination_table.py).
        if mode == "truncate_insert":
            cursor.execute(_replace_rows_sql(table))
            logger.info("[feed_engine] Oracle: DELETE FROM %s (same "
                        "transaction as the insert)", table)


        # Build INSERT statement — identifiers validated above
        placeholders = ", ".join([f":{i+1}" for i in range(len(columns))])
        col_list = ", ".join(f'"{c}"' for c in _resolved)
        insert_sql = f'INSERT INTO {table} ({col_list}) VALUES ({placeholders})'

        # Batch insert using executemany.
        #
        # 2026-07-31: batches now arrive from a STREAMING reader instead of
        # being sliced out of a fully-materialised list.  ``i`` remains the
        # absolute row offset so the existing per-row error logging keeps
        # reporting positions in the source file.
        total_inserted = 0
        total_errors = 0
        _first_errors: List[str] = []
        max_error_pct = _max_error_percent(dest_config)
        i = 0
        for _rb in pf.iter_batches(batch_size=batch_size):
            if _rb.num_rows == 0:
                continue
            # to_pylist() gives row dicts; take values in the declared column
            # order so the positional INSERT binds stay correct.
            batch = [[r.get(c) for c in columns] for r in _rb.to_pylist()]
            # NaN / +/-Infinity -> NULL: the ONE rule both lanes bind by
            # (oracle_destination_table.oracle_bind_value; the Spark publish
            # applies it in SQL).  K4, 2026-10-07.
            clean_batch = [[_oracle_bind_value(v) for v in row]
                           for row in batch]
            # Phase 132-E: Use batcherrors=True for per-row error context
            cursor.executemany(insert_sql, clean_batch, batcherrors=True)
            batch_errors = cursor.getbatcherrors()
            if batch_errors:
                _first_errors.extend(
                    e.message for e in batch_errors[:3 - len(_first_errors)])
                for err in batch_errors[:10]:  # Log first 10 errors
                    logger.warning(
                        "[feed_engine] Oracle batch error at row %d (batch offset %d): %s",
                        i + err.offset, err.offset, err.message,
                    )
                total_bad = len(batch_errors)
                total_errors += total_bad
                logger.warning(
                    "[feed_engine] Oracle batch: %d/%d rows failed in batch starting at row %d",
                    total_bad, len(clean_batch), i,
                )
                total_inserted += len(clean_batch) - total_bad
            else:
                total_inserted += len(clean_batch)
            # Advance the absolute row offset so error positions stay correct.
            i += len(clean_batch)

        # Fail if error rate exceeds threshold (default 5%).
        # ``_total_source_rows`` comes from the parquet footer and replaces the
        # old ``len(rows)`` -- the fully-materialised list no longer exists.
        # 2026-10-07 -- the comparison is THE shared one: the Spark lane now
        # honours the same tolerance (DML error logging on its publish), so
        # one function decides for both.
        _refusal = _rejection_refusal(total_errors, _total_source_rows,
                                      max_error_pct)
        if _refusal:
            ora_conn.rollback()
            raise RuntimeError(_rejection_message(_refusal, _first_errors,
                                                  table))

        # the counterparty sees the rows at COMMIT: THE publish gate
        from core.feed.delivery_protocol import publishing as _publishing
        with _publishing(f"oracle {table}"):
            ora_conn.commit()
        logger.info(
            "[feed_engine] Oracle delivery: %d rows inserted into %s",
            total_inserted, table,
        )
        # 2026-08-04 — destination-side row accounting on the receipt.  A
        # commit under the max_error_percent tolerance used to report
        # SUCCESS with rows silently missing; the certificate recounted
        # the local file and stamped COMPLETE.  The receipt now carries
        # what actually reached the table, and the certificate reconciles
        # against it → dropped rows produce INCOMPLETE, loudly.
        if _receipt is not None:
            _receipt["delivered_rows"] = int(total_inserted)
            _receipt["dropped_rows"] = int(total_errors)
            _receipt["verification"] = "verified"
            _receipt["verification_detail"] = (
                f"destination row accounting: {total_inserted}/"
                f"{_total_source_rows} inserted, {total_errors} rejected")
        if total_errors > 0:
            logger.error(
                "[feed_engine] Oracle delivery COMMITTED WITH %d REJECTED "
                "ROWS (%d/%d inserted, tolerance max_error_percent=%s) — "
                "this run cannot be certified COMPLETE",
                total_errors, total_inserted, _total_source_rows,
                max_error_pct,
            )
    except BaseException:
        # Rule B: the target changes in ONE transaction or not at all.
        # Closing an oracledb connection with work pending rolls it back
        # too; say it explicitly rather than rely on a driver detail.
        try:
            ora_conn.rollback()
        except Exception as _rb_exc:
            logger.warning("[feed_engine] Oracle rollback failed: %s", _rb_exc)
        raise
    finally:
        ora_conn.close()

    return f"oracle://{host}:{port}/{service_name}/{table}"


# ---------------------------------------------------------------------------
# 2026-08-04 — Delivery-target adapters (core.feed.delivery_targets seam).
#
# One adapter per destination type, registered once.  The engine's retry
# loop (``_deliver_to_destination``) dispatches through the registry — the
# per-target if/elif pile is gone.  Adding a destination is one subclass +
# one ``register_target`` call; retry policy, receipt plumbing and the
# certificate wiring pick it up unchanged.  The adapters call the raw
# transport functions above by module-global name so tests that
# monkeypatch ``fe._deliver_local`` / ``fe._build_s3_client`` / etc. keep
# working unchanged.
# ---------------------------------------------------------------------------
# RE-EXPORT, not an unused import.  `FeedOutputTruncatedError` is defined in
# core.feed.renderers but imported FROM HERE by callers and by
# tests/test_feed_truncation_atomicity_2026_08_03.py.  A lint sweep removed it
# on 2026-08-17 and the test module failed to IMPORT -- which in this repo is
# the worst failure mode: a collection error is not a failing test, it is a
# silently DARK one (43 tests went dark this way on 2026-08-14).
from core.feed.renderers import FeedOutputTruncatedError  # noqa: F401,E402
from core.feed.delivery_targets import (  # noqa: E402
    DeliveryReceipt, DeliveryTarget, register_target,
)


# 2026-09-03 -- the four delivery adapter CLASSES moved to
# core/feed/steps/delivery_builtin.py (and the import-time registration
# loop that lived here is deleted): the engine carries no step wiring at
# import time.  The delivery IMPLEMENTATIONS (_deliver_local /
# _deliver_s3 / _sftp_upload / _deliver_oracle) stay below unchanged --
# the adapters late-bind to them, so patching feed_engine._deliver_* in
# tests still intercepts.  register_target stays imported above for
# runtime/test registration (it delegates to the step registry).


def _certified_dest_rows(delivery_receipt: Optional[dict],
                         dest_physical_rows: Optional[int],
                         row_count: Any) -> Optional[int]:
    """Destination-side row count the completeness certificate reconciles
    against (2026-08-04).

    Priority order — most independent evidence first:
      1. The delivery receipt's DESTINATION-reported count.  An Oracle
         delivery that committed with rows rejected under the
         ``max_error_percent`` tolerance reports what actually reached
         the table; previously the certificate recounted the local FILE
         (which still held every row) and stamped COMPLETE while the
         destination was silently short.
      2. The independent physical recount of the delivered file
         (``file_integrity.physical_row_count``).
      3. The engine's self-reported ``row_count`` (least independent).

    2026-10-07 (D1) -- the rule is ``core.feed.delivery_verdict.
    certified_dest_rows``, which the completion webhook (a Spark job's
    receipt) and the webhook-side delivery now call too: three paths, one
    answer.  The native engine always holds a receipt (its transports fill
    one), so its third rung is unchanged.
    """
    from core.feed.delivery_verdict import certified_dest_rows
    rows, _basis = certified_dest_rows(
        receipt=dict(delivery_receipt or {}),
        physical_rows=dest_physical_rows, rendered_rows=row_count)
    return rows


# ---------------------------------------------------------------------------
# Filename template expansion
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Phase 130/2 — Calendar resolution helper (DB-driven, cached by repo TTL)
# ---------------------------------------------------------------------------
_calendar_repo = None


_control_format_repo = None


def _resolve_control_file_format(feed_config: dict):
    """Look up the DB-driven control-file format spec.

    Returns ``None`` when the feed has no ``control_file_format_id``
    set (legacy behaviour — pipeline uses the default layout) or when
    the id doesn't resolve to a row.  TTL-cached inside the repo so
    we don't pay a DB round-trip per execution.
    """
    fmt_id = feed_config.get("control_file_format_id")
    if not fmt_id or _db_manager is None:
        return None
    global _control_format_repo
    if _control_format_repo is None:
        try:
            from core.feed.control_format_repo import ControlFormatRepo
            _control_format_repo = ControlFormatRepo(_db_manager)
        except Exception as e:
            logger.warning(
                "[feed_engine] could not construct ControlFormatRepo: %s", e,
            )
            return None
    try:
        return _control_format_repo.get(int(fmt_id))
    except Exception as e:
        logger.warning("[feed_engine] control-file format resolution failed: %s", e)
        return None


def _resolve_calendar(feed_config: dict):
    """Look up the feed's BusinessCalendar (returns None when not configured).

    The repo is constructed lazily on first call so feed_engine import
    stays cheap.  TTL caching lives inside ``BusinessCalendarRepo``
    itself so we don't hit the DB once per execution.
    """
    cal_name = feed_config.get("calendar_name")
    if not cal_name or _db_manager is None:
        return None
    global _calendar_repo
    if _calendar_repo is None:
        try:
            from core.feed.calendar import BusinessCalendarRepo
            _calendar_repo = BusinessCalendarRepo(_db_manager)
        except Exception as e:
            logger.warning("[feed_engine] could not construct BusinessCalendarRepo: %s", e)
            return None
    try:
        from core.feed.pipeline import resolve_calendar_for_feed
        return resolve_calendar_for_feed(feed_config, _calendar_repo)
    except Exception as e:
        logger.warning("[feed_engine] calendar resolution failed: %s", e)
        return None


#: FR-CMP-01/07 (2026-09-03) — THE GATE POSTURE, stated where the gate is
#: decided instead of implied by a code comment.
#:
#: ``feed_generation.completeness_gate`` ships as ``record``: an
#: incomplete/unverifiable verdict is RECORDED (verdict on the row,
#: WARNING in the log) and the run still completes and delivers.  This
#: is a staged rollout, not the destination — on an estate that has
#: never carried a verdict, enforcing blind fails good runs overnight,
#: and a control that fails everything on day one is one somebody
#: switches off.
#:
#: CRITERION FOR FLIPPING TO ``enforce`` (record, read, then enforce):
#: after 14 consecutive calendar days in which (a) every completed run
#: recorded a verdict (zero "carries NO verdict" errors in the log for
#: this pod set), and (b) every ``incomplete``/``unverifiable`` verdict
#: recorded in that window was confirmed by an operator as a TRUE
#: finding or fixed (none dismissed as gate noise), flip
#: ``completeness_gate=enforce``.  Until both hold, enforce would teach
#: operators to distrust the gate — the one outcome worse than record.
COMPLETENESS_GATE_ENFORCE_CRITERION = (
    "14 consecutive days of (a) every completed run carrying a verdict "
    "and (b) every incomplete/unverifiable verdict confirmed true or "
    "fixed — then set feed_generation.completeness_gate=enforce"
)


def resolve_final_status(verdict, gate_mode: str, *,
                         feed_config_id=None, exec_id=None) -> str:
    """The run's terminal status, given its completeness verdict.

    FR-CMP-01 in one place: a comparison that fails must CHANGE THE
    RUN'S STATUS — anything else is telemetry, not a control.  But
    only in ``enforce`` mode: see ``COMPLETENESS_GATE_ENFORCE_CRITERION``
    for the posture and the stated criterion for flipping the default.

    FR-CMP-07 (2026-09-03): a verdict that FAILED TO BUILD (``None`` —
    an import failure or an exception inside the verdict builder) is
    "could not tell", and "could not tell" never folds into success —
    that fold is the exact defect class this control exists to prevent,
    and it sat AT the control until today.  ``None`` therefore resolves
    exactly like an ``unverifiable`` verdict: loud-and-recorded under
    ``record``, ``failed`` under ``enforce``.

    Extracted and named so the decision is testable, rather than one
    conditional buried in a 1,000-line function where the only way to
    reach it is to drive a whole feed run.
    """
    if verdict is not None and verdict.allows_complete:
        return "completed"
    if verdict is None:
        state, detail = "ABSENT (no verdict was built)", (
            "the verdict builder raised or the completeness module could "
            "not be imported — this run's completeness is UNKNOWN")
    else:
        state = verdict.state
        detail = "; ".join(getattr(verdict, "reasons", ()) or ())
    if str(gate_mode or "record").lower() == "enforce":
        logger.error(
            "[feed_engine] Feed %s [%s] REFUSED completion: "
            "completeness verdict is %s (%s).  A measured comparison "
            "that fails — or a verdict that could not be built — must "
            "change the run's status.",
            feed_config_id, exec_id, state, detail)
        return "failed"
    logger.warning(
        "[feed_engine] Feed %s [%s] completeness verdict is %s (%s) — "
        "RECORDED only.  Set feed_generation.completeness_gate=enforce "
        "to make this change the run's status (criterion: %s).",
        feed_config_id, exec_id, state, detail,
        COMPLETENESS_GATE_ENFORCE_CRITERION)
    return "completed"


def declare_run_partitions(db, feed_config, *, feed_run_id, business_date,
                           run_sql=None):
    """Declare and RECORD this run's partition list before any work starts.

    §9.2's dangerous case is not a failed child — a failure is loud.  It is
    A CHILD THAT NEVER EXISTED: the list was built from a query that returned
    1,180 entities instead of 1,240 because a reference table was mid-load.
    Every child succeeds, every part certifies, the feed is 60 entities short
    and every signal is green.

    So the list is recorded as DATA — the identities, not just a count — and
    compared against the previous business date.  The comparison names the
    missing identities exactly, which is why it does not depend on a
    percentage threshold: §9.2's own example is a 4.84% drop and would slide
    under a 5% alarm.

    Returns ``(declaration, comparison)``, or ``(None, None)`` when the feed
    declares no shape — which is most feeds, and must stay exactly as it is.

    Refusals here are LOUD and stop the run, deliberately: an empty list is a
    DECISION, not a no-op, and a partition explosion is a refusal rather than
    40,000 child rows at 2am.  They happen before the extract, so a refusal
    costs nothing but the admission.
    """
    from core.feed import completeness as _cmp
    from core.feed import partition_shape as _shape

    shape = _shape.read_shape(feed_config)
    if shape is None or not shape.declared:
        return None, None

    identities = _shape.resolve_identities(shape, run_sql=run_sql)
    declaration = _cmp.declare_partitions(
        identities, on_empty=shape.on_empty, max_parts=shape.max_parts,
        source=shape.values_sql or "declared inline")

    comparison = None
    try:
        previous = _cmp.previous_declared_identities(
            db, feed_config_id=feed_config.get("id"),
            business_date=business_date)
        comparison = _cmp.compare_to_previous(declaration, previous)
        if getattr(comparison, "alarm", False):
            logger.error(
                "[feed_engine] feed %s partition list ALARM for %s: %s",
                feed_config.get("id"), business_date, comparison.to_dict())
    except Exception as exc:
        # A comparison that cannot run must not stop the feed, but "could not
        # compare" and "nothing changed" are opposite findings and must not
        # look alike.
        logger.error(
            "[feed_engine] feed %s: partition list could not be compared "
            "against the previous business date (%s) — this run has NO drift "
            "check", feed_config.get("id"), exc)

    if feed_run_id is not None:
        # Errors PROPAGATE: an unrecorded declaration is not evidence, and a
        # feed-level completeness claim cannot be made without it.
        _cmp.persist_declaration(
            db, feed_run_id=int(feed_run_id),
            feed_config_id=int(feed_config.get("id") or 0),
            business_date=business_date, declaration=declaration)
    else:
        logger.warning(
            "[feed_engine] feed %s declared %d partition(s) but has no "
            "feed_run row to record them against — the declaration is NOT "
            "persisted and no feed-level completeness claim can be made",
            feed_config.get("id"), declaration.count)
    return declaration, comparison


def _load_gate_assertion(db, feed_config, feed_config_id):
    """FR-CMP-09 / FR-DEP-12 — the PRODUCER for ``_gate_assertion``.

    The gate's in-memory ``asserted=True`` verdict lives on the scheduler
    that admitted the run and never reaches this process, so the
    assertion is rebuilt from the DURABLE record: the append-only
    ``run_events`` rows of type ``dependency_skipped`` for this feed +
    business date (one per run the skip released, carrying actor, reason
    and timestamp — see ``core.feed.dependency_skip.assert_skip``).  The
    tracking row the skip also writes is keyed (type, key, date), so any
    skip event for this feed+date means every run of this date is being
    admitted on that assertion.

    Returns
      * ``None`` — no skip was asserted for this feed+date (the normal
        case), or this deployment predates the ledger entirely;
      * ``completeness.Assertion(kind="skip", ...)`` — attributed from
        the audit rows, actor and reason never invented;
      * ``completeness.UnattributableOverride`` — the ledger could not
        be read, or a skip row exists with no actor / no reason.  It is
        REFUSED as an assertion (that would default an actor) and must
        not vanish either (that would launder the override into
        ``verified``): _build_completeness_verdict turns it into an
        UNVERIFIABLE claim.
    """
    try:
        from core.feed import completeness as _cmp
    except ImportError:
        return None
    if db is None or not hasattr(db, "list_run_events"):
        # Pre-ledger deployment: no durable skip record CAN exist, so
        # "no assertion" is a fact here, not a failure to look.
        return None
    business_date = _effective_business_date(feed_config, db)
    try:
        events = list(db.list_run_events(int(feed_config_id),
                                         business_date) or [])
    except Exception as exc:
        logger.error(
            "[feed_engine] feed %s: run_events ledger unreadable for %s "
            "(%s) — cannot tell whether a dependency skip admitted this "
            "run; its verdict will be UNVERIFIABLE, not verified",
            feed_config_id, business_date, exc)
        return _cmp.UnattributableOverride(
            detail=(f"run_events ledger unreadable for feed "
                    f"{feed_config_id} / {business_date}: {exc}"))
    try:
        return _cmp.assertion_from_skip_events(events)
    except _cmp.CompletenessError as exc:
        logger.error(
            "[feed_engine] feed %s: dependency skip on %s cannot be "
            "attributed (%s) — refused as an assertion; the verdict will "
            "be UNVERIFIABLE, not asserted-under-a-default-actor",
            feed_config_id, business_date, exc)
        return _cmp.UnattributableOverride(detail=str(exc))


# Sentinel — "this caller did not resolve the row cap", which is NOT the
# same fact as "there was no cap".  Unknown != empty.
_ROW_CAP_UNRESOLVED = object()


def _resolve_row_cap_disclosure(feed_config=None, stage_timings=None,
                                files_metadata=None):
    """THE single resolution of the run's row-cap disclosure (2026-09-05).

    Producers (``_execute_duckdb_query``'s connector branch and
    ``_finalize_row_cap_disclosure``) stash the dict on
    ``feed_config["_row_cap_disclosure"]``.  It has TWO consumers -- the
    execution record (``files_metadata.row_cap``) and the completeness
    verdict's SOURCE claim -- and until 2026-09-05 the first one POPPED it
    72 lines before the second one read it, so the gate always saw None:
    "a value computed for a correctness gate and then thrown away will
    disagree with what the system does".  Resolving it here, once, is how
    both consumers read the same value.

    Returns the disclosure dict or None.  Never raises: ``stage_timings``
    mixes stage-duration floats with structured entries, and a float here
    once crashed the whole verdict builder.
    """
    def _get(src, key):
        return src.get(key) if isinstance(src, dict) else None

    for candidate in (_get(files_metadata, "row_cap"),
                      _get(stage_timings, "row_cap"),
                      _get(feed_config, "_row_cap_disclosure")):
        if isinstance(candidate, dict) and candidate:
            return candidate
    return None


def _row_cap_applied(cap):
    """Did a cap TRUNCATE this read?  True / False / None(unknown).

    ``None`` (no disclosure at all) means no cap was configured, which is a
    real "no cap applied" assertion.  A disclosure that exists but does not
    SAY whether it bit is UNKNOWN -- returned as None so the source claim
    comes out ``unverifiable`` rather than certifying a truncated file.
    ``cap_hit`` is what every producer writes; ``hit`` is accepted for
    records written before the key settled.
    """
    if cap is None:
        return False
    if not isinstance(cap, dict):
        return None
    for key in ("cap_hit", "hit"):
        if key in cap:
            return bool(cap.get(key))
    return None


def _build_completeness_verdict(feed_config, *, row_count, stage_timings,
                                gate_assertion=None,
                                partition_declaration=None,
                                certified_partitions=None,
                                row_cap=_ROW_CAP_UNRESOLVED):
    """Turn what the run ALREADY measured into a completeness verdict.

    Built only from evidence that genuinely exists at this point, because the
    alternative is worse than no verdict: claiming ``verified`` on evidence
    nobody produced is exactly the "could not tell counted as fine" the whole
    control exists to prevent.

    Today that means the BUSINESS claim (the row-count check the engine
    already ran against a historical baseline) and the SOURCE claim (whether a
    row cap bit).  The PART and FEED claims arrive with fan-out: a feed-level
    claim needs the declared partition list, and until a run declares one
    there is nothing to certify the set against.

    Returns None when the module is absent, so an older build degrades to its
    previous behaviour instead of failing the run.
    """
    try:
        from core.feed import completeness as _cmp
    except ImportError:
        return None
    try:
        claims = []

        # SOURCE — was the read truncated?  The disclosure is only present
        # when a configured cap was IN FORCE, and the producers record
        # whether it actually BIT.  No disclosure means no cap was
        # configured, which is a real "no cap applied" assertion rather than
        # an absence of evidence.
        #
        # ``row_cap`` is handed in by a caller that ALREADY resolved the
        # disclosure (execute_feed resolves it once, into files_metadata),
        # so the gate and the execution record read the same value; callers
        # that did not resolve it fall back to resolving it here.  Either
        # way it is the one resolver, and _row_cap_applied — not a second
        # spelling of the producers' key — decides whether the cap bit.
        _cap = (_resolve_row_cap_disclosure(feed_config, stage_timings)
                if row_cap is _ROW_CAP_UNRESOLVED
                else (row_cap if isinstance(row_cap, dict) else None))
        claims.append(_cmp.source_claim(
            engine_reported_rows=row_count,
            rows_read=row_count,
            cap_applied=_row_cap_applied(_cap),
            cap_name=(f"query_params.limit={_cap.get('configured_limit')}"
                      if _cap and _cap.get("configured_limit") is not None
                      else None)))

        # BUSINESS — the variance evaluator already ran; reuse its verdict
        # rather than recomputing a second, possibly different, opinion.
        _rc = (stage_timings or {}).get("row_count_check") or {}
        if not isinstance(_rc, dict):
            _rc = {}
        if _rc and not _rc.get("skipped"):
            claims.append(_cmp.business_claim(
                row_count=row_count,
                baseline_rows=_rc.get("baseline_avg"),
                tolerance_pct=float(_rc.get("threshold_pct") or 0)))

        # FEED — §9.2 / FR-CMP-05: certify the SET, not the parts.  Only a
        # run that declared a partition list and fanned out can make this
        # claim; it compares the declared identities against the certified
        # ones and FAILS when any declared partition has no certified part
        # — the "child that never existed" that a counter cannot see.
        if partition_declaration is not None:
            claims.append(_cmp.feed_claim(
                partition_declaration, list(certified_partitions or [])))

        _assertion = gate_assertion
        if isinstance(gate_assertion, _cmp.UnattributableOverride):
            # FR-CMP-09 — an override nobody owns: refused as an assertion
            # (that would invent an actor) and refused as silence (that
            # would launder it into 'verified').  It rides as an
            # UNVERIFIABLE claim — its own state, never success.
            claims.append(gate_assertion.to_claim())
            _assertion = None
        return _cmp.combine_verdict(claims, assertion=_assertion)
    except Exception as exc:
        # FR-CMP-07 (2026-09-03): a verdict that cannot be COMPUTED is
        # "could not tell" — its own state, never silence.  Silence (None)
        # used to reach resolve_final_status, which folded it into
        # "completed": the exact fold this platform exists to prevent,
        # sitting at the control built to prevent it.  So the failure to
        # build IS the verdict: UNVERIFIABLE, naming the exception — it
        # gets RECORDED on the execution row like any other verdict and
        # resolves per the gate (loud under record, failed under enforce).
        logger.error(
            "[feed_engine] completeness verdict could not be built (%s) — "
            "recording an UNVERIFIABLE verdict; treat this run's "
            "completeness as unknown", exc)
        try:
            return _cmp.CompletenessVerdict(
                state=_cmp.UNVERIFIABLE,
                claims=(),
                reasons=(f"verdict builder raised "
                         f"{type(exc).__name__}: {exc}"[:500],),
            )
        except Exception as inner:
            # Even the fallback failed (module half-broken).  None still
            # resolves as unverifiable in resolve_final_status — honest,
            # just not recorded on the row.
            logger.error(
                "[feed_engine] could not even record the UNVERIFIABLE "
                "verdict (%s) — this run carries NO verdict", inner)
            return None


def _deploy_environment() -> str:
    """The environment name delivery suppression is evaluated against.

    Delegates to ``core.config.deploy_environment`` — THE resolver.  This
    was the third hand-copy of the same precedence chain; suppression and
    alerting reading the environment through different code is exactly how
    a feed gets suppressed in an environment its alerts think it is not in.

    Returns "" when nothing declares one, and "" matches NO suppression rule
    — an unknown environment must never silently suppress a delivery, because
    a feed that quietly sends nothing looks exactly like a feed that worked.
    """
    try:
        from core.config import deploy_environment as _de
        return _de()
    except Exception:                              # noqa: BLE001
        return ""


def _execution_run_business_date(db, feed_config: dict, feed_run_id) -> Optional[date]:
    """The business date of the run this execution belongs to: the bound
    run's, else the run row's (by id).  None when neither says one."""
    raw = (feed_config.get("_feed_run") or {}).get("business_date")
    if not raw and feed_run_id is not None and db is not None:
        try:
            raw = (db.get_feed_run(int(feed_run_id)) or {}).get("business_date")
        except Exception:                       # noqa: BLE001 -- never invented
            raw = None
    if not raw:
        return None
    if isinstance(raw, date) and not isinstance(raw, datetime):
        return raw
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        return None


def _delivery_manifest_for(output_path, row_count, feed_config_id, exec_id):
    """Wrap a single produced file as a CERTIFIED one-part manifest.

    Foundation M consumes a manifest and refuses anything that is not
    ``status == "complete"`` — the gate that stops a partial part list
    shipping under a real filename.  The native single-file path has no
    manifest of its own, so one is built here from what actually exists on
    disk: the real byte count, the real row count, and a build id that makes
    the version identity unique per execution.

    The version this produces is what every delivery attempt row records
    (FR-DEL-04), so a re-delivery can never send different bytes under the
    same name without the record showing it.

    2026-09-02 (FR-ART-04/05): NATIVE SINGLE-FILE ONLY.  The Spark lane
    no longer fabricates a manifest here — its manifest is LOADED from
    the artifact store the job wrote and independently certified
    (``core.spark_k8s.artifact_chain``).  The old ``size_bytes`` remote
    branch built a pre-stamped-'complete' manifest from a REPORTED path
    and size, which made the hop runner's certification gate unable to
    refuse anything on that lane; it was removed with its only caller so
    a fabricated remote manifest is inexpressible here.
    """
    from core.feed.parts_manifest import PartInfo, PartsManifest
    path = Path(output_path)
    try:
        size = path.stat().st_size
    except OSError:
        size = 0
    return PartsManifest(
        parts=[PartInfo(index=0, name=path.name, rows=int(row_count or 0),
                        bytes=int(size), location="local")],
        total_rows=int(row_count or 0),
        total_bytes=int(size),
        status="complete",
        build_id=str(exec_id or ""),
        sql_sha256=f"feed:{feed_config_id}",
        completed_at=time.time(),
        source={"rung": "native_single_file", "feed_config_id": feed_config_id},
    )


def should_deliver_from_webhook(reported_delivered) -> bool:
    """Does QueryStudio deliver this completed Spark run?

    ONLY on an explicit ``False`` from the job — the process that
    would otherwise have sent the file, and the only source that
    cannot be wrong about what it did.

    ``None`` means an image predating the flag, and it must mean "the
    job delivered".  Written as ``is False`` rather than ``not
    reported`` on purpose: falsiness would treat None as "did not
    deliver" and QueryStudio would send a file the pod had ALREADY
    sent.  That is a duplicate at a counterparty — the exact outcome
    this whole foundation exists to prevent, arriving through the fix
    for it.  Extracted into a named function so the distinction is
    testable rather than one operator buried in a request handler.
    """
    return reported_delivered is False


def _spark_artifact_s3_client(feed_config: dict,
                              output_path: Optional[str] = None):
    """boto3 client for the Spark ARTIFACT STORE — the s3a:// prefix the
    job wrote its parts and ``manifest.json`` under.

    Reuses the delivery side's ONE credential chokepoint
    (``_build_s3_client``: direct keys, connection_id / portal / STS
    resolution, proxy config).

    K6 (2026-10-07): when the parts are in the DECLARED artifact store
    (``spark_k8s.artifact_bucket``), they are read with THE STORE'S
    identity (``spark_k8s.artifact_connection_id``, else ambient) -- the
    same identity the job wrote them with.  Reading QueryStudio's own
    bucket with the feed DESTINATION's credentials (the counterparty's)
    was the wrong principal, and on any non-ambient deployment it could
    not read the manifest at all.  Parts anywhere else (an older job that
    wrote its destination) keep the destination's identity; a destination
    that is not S3 falls through to ambient credentials."""
    if output_path:
        from core.spark_k8s.artifact_chain import parse_output_path
        from core.spark_k8s.feed_conf import (
            artifact_store_bucket, artifact_store_client_config)
        kind, bucket, _prefix = parse_output_path(str(output_path))
        store = artifact_store_bucket()
        if kind == "s3" and store and bucket == store:
            return _build_s3_client(artifact_store_client_config())
    dest = dict(feed_config.get("destination_config") or {})
    dest["_triggered_by_user"] = feed_config.get("_triggered_by_user", "")
    return _build_s3_client(dest)


def deliver_completed_spark_run(db, execution: dict, feed_config: dict, *,
                                output_path: str, rows=None, size_bytes=None,
                                actor: str = "webhook") -> list:
    """H1 step B / §10.4 — QueryStudio delivers a Spark run's artifacts.

    Called from the completion webhook ONLY when the job reported
    ``delivered=False``, i.e. it was submitted with ``deliver_in_job=false``
    and therefore wrote artifacts without touching the counterparty.  The pod
    is retry-safe precisely because this is the only place the non-idempotent
    act happens, and this place is re-runnable per hop.

    2026-09-02 (FR-ART-04/05/11, FR-DEL-01/14) — the manifest the hop
    runner certifies is the one the JOB WROTE, not a fabrication:

    1. ``load_job_manifest`` reads the ``manifest.json`` the Spark job
       wrote next to its parts (ABSENT is a refusal, not a degrade);
    2. ``certify_job_manifest`` checks it against an INDEPENDENT listing
       of the store — every part present, byte counts matching, no
       unmanifested data file, rows reconciled against the callback's
       reported count;
    3. ``prepare_artifact_chain`` stages the certified parts under the
       counterparty filename and runs the fixed engine order
       (package → compress → checksum over the SENT bytes), sidecars and
       control file included;
    4. the hop runner delivers the prepared artifacts over the certified
       manifest, one attempt row per hop.

    The previous wiring fabricated a one-part manifest pre-stamped
    ``complete`` from the reported path and size, so the certification
    gate could never refuse anything on this lane.

    A refusal or failure at ANY stage delivers nothing, records why on
    the execution row, and CLEARS ``delivery_completed_at`` (the webhook
    stamps it before delegating here): a delivery that did not happen is
    never left stamped.

    ``size_bytes`` is accepted for callback compatibility; the manifest's
    own per-part byte counts are certified against the store listing, so
    a job-reported total is no longer treated as evidence.

    Returns the hop outcomes, or ``[]`` when nothing was delivered.  Never
    raises: a delivery failure here must be RECORDED (each hop already has
    its own attempt row and is independently re-runnable) rather than
    turning a valid, signed callback into a 500 that the job will not
    retry.
    """
    import shutil
    import tempfile

    from core.feed.delivery_hops import (
        CHAIN_DELIVERED as _CHAIN_DELIVERED,
        CHAIN_SUPPRESSED as _CHAIN_SUPPRESSED,
        DeliveryHopRunner,
        build_hop_plan,
        chain_verdict as _chain_verdict,
        stored_delivery_suppression as _stored_suppression,
    )
    from core.spark_k8s.artifact_chain import (
        SparkArtifactError,
        certify_job_manifest,
        list_output_parts,
        load_job_manifest,
        parse_output_path,
        prepare_artifact_chain,
    )

    _ = size_bytes  # see docstring — accepted, no longer evidence
    exec_id = execution.get("execution_id") or ""
    dest_config = dict(feed_config.get("destination_config") or {})
    dest_config["_triggered_by_user"] = feed_config.get("_triggered_by_user", "")
    # 2026-10-07 -- the run's "do not deliver" decision as STORED on the
    # execution when it was created.  The hop runner used to re-derive it
    # by asking for a suppressed feed_run still 'running' for this date --
    # but the webhook has already written 'completed', and the engine's
    # spark lane syncs the run row as soon as it sees that, so the answer
    # depended on which write landed first.
    _suppressed = _stored_suppression(execution)
    # The run's BUSINESS date (the execution carries it since 2026-10-07):
    # the counterparty filename and the control file are dated by it.  The
    # DB feed this callback holds has no bound run, so the fallback alone
    # resolved "today" -- a Spark backfill's file was named for the day it
    # ran, not the day it is for.
    _run_bd = execution.get("business_date") or _effective_business_date(
        feed_config, db)
    if isinstance(_run_bd, str):
        # to_dict() serialises it; the attempt ledger's DATE column takes a
        # date (SQLite refuses the string outright).
        try:
            _run_bd = date.fromisoformat(_run_bd[:10])
        except ValueError:
            _run_bd = _effective_business_date(feed_config, db)

    # The produced file, kept on the shared output volume for the
    # execution's Download (``artifact_path``), or WHY there is none -- on
    # the record, so the screen says it instead of a bare 404.  Carried in
    # the SAME write as the verdict (one write, nothing to interleave).
    _artifact: Dict[str, Any] = {}

    def _record_artifact(path, reason=None) -> None:
        _artifact.clear()
        _artifact.update({"retrievable": bool(path),
                          "path": str(path) if path else None,
                          "reason": (str(reason)[:1000] if reason
                                     else None)})

    def _with_artifact(update: Dict[str, Any]) -> Dict[str, Any]:
        if _artifact.get("path"):
            update["artifact_path"] = _artifact["path"]
        return update

    def _chain_record(verdict: str, reason) -> dict:
        # 2026-10-03 -- the verdict in THE slot every reader checks
        # (stage_timings.delivery_chain), merged over a FRESH read: the
        # webhook already closed the row and the engine's spark lane may
        # have written its stage timings since.  Until now this lane
        # recorded "not delivered" only in files_metadata and a DELIVERED
        # chain nowhere, so a webhook-side delivery that succeeded was
        # indistinguishable from an unknown one -- the receipts said
        # "unknown" and an on_completion_of feed downstream of it could
        # never start (core/feed/upstream_completion.py).
        _read = getattr(db, "get_feed_execution", None)
        fresh = {}
        if callable(_read) and execution.get("id") is not None:
            try:
                fresh = _read(execution["id"]) or {}
            except Exception as read_exc:   # the snapshot is the fallback
                logger.warning(
                    "[feed_engine] %s: fresh stage timings unreadable (%s) "
                    "-- merging the verdict over the callback's snapshot",
                    exec_id, read_exc)
        st = dict(fresh.get("stage_timings") or execution.get("stage_timings")
                  or {})
        st["delivery_chain"] = {"verdict": verdict,
                                "reason": (str(reason)[:2000] if reason
                                           else None),
                                "reported_by": "webhook_delivery"}
        if _artifact:
            st["artifact"] = dict(_artifact)
        return st

    def _record_not_delivered(stage: str, why, verdict: str = "failed") -> None:
        # The webhook marks the run completed AND stamps
        # delivery_completed_at BEFORE delegating here.  When nothing was
        # delivered that stamp claims a delivery that never happened —
        # clear it and say why, so the run reads "complete, NOT
        # delivered" instead of green on every signal (FR-DEL-01/14).
        if verdict == _CHAIN_SUPPRESSED:
            logger.warning(
                "[feed_engine] %s: delivery SUPPRESSED for this run (the "
                "decision stored on the execution) -- nothing was sent "
                "(%s: %s)", exec_id, stage, why)
        else:
            logger.error(
                "[feed_engine] webhook-side delivery for %s did NOT happen "
                "(stage=%s: %s) — certified artifacts, if any, are still in "
                "the store; RE-DELIVER, never re-generate.",
                exec_id, stage, why)
        try:
            if db is not None and execution.get("id") is not None:
                # Over a FRESH read, like _chain_record (2026-10-11): the
                # finaliser merged the job's merge record and the
                # verification onto this row moments ago, and a dict built
                # from the callback's snapshot overwrote them -- the first
                # reconciler-finalised run with a refused delivery lost its
                # cross_source record exactly that way.
                _fresh_fm = None
                _read_fm = getattr(db, "get_feed_execution", None)
                if callable(_read_fm):
                    try:
                        _fresh_fm = (_read_fm(execution["id"]) or {}).get(
                            "files_metadata")
                    except Exception as _fm_exc:   # the snapshot is the fallback
                        logger.warning(
                            "[feed_engine] %s: fresh files_metadata unreadable "
                            "(%s) -- merging over the callback's snapshot",
                            exec_id, _fm_exc)
                fm = dict(_fresh_fm if isinstance(_fresh_fm, dict)
                          else (execution.get("files_metadata") or {}))
                fm["spark_delivery"] = {
                    "status": ("suppressed" if verdict == _CHAIN_SUPPRESSED
                               else "not_delivered"),
                    "stage": stage,
                    "reason": str(why)[:2000],
                }
                db.update_feed_execution(execution["id"], _with_artifact({
                    "delivery_completed_at": None,
                    "files_metadata": fm,
                    "stage_timings": _chain_record(
                        verdict, f"stage {stage}: {why}"),
                }))
        except Exception as rec_exc:
            logger.error(
                "[feed_engine] could not record the refused delivery for "
                "%s on its execution row (%s) — the row may still carry a "
                "delivery timestamp for a delivery that did not happen",
                exec_id, rec_exc)

    # ── 1-2. certify the JOB'S OWN manifest ──────────────────────────
    try:
        kind, _bucket, _prefix = parse_output_path(str(output_path or ""))
        s3_client = (_spark_artifact_s3_client(
                         feed_config, output_path=str(output_path))
                     if kind == "s3" else None)
        manifest = load_job_manifest(str(output_path), s3_client=s3_client)
        listing = list_output_parts(str(output_path), s3_client=s3_client)
        manifest = certify_job_manifest(
            manifest, listing,
            reported_rows=(int(rows) if rows is not None else None))
    except Exception as exc:
        _stage = exc.stage if isinstance(exc, SparkArtifactError) else "certify"
        _unreadable = _artifact_unreachable_reason(output_path, exc)
        _record_artifact(None, _unreadable)
        if _suppressed:
            # Nothing was to be sent anyway: the verdict is SUPPRESSED (the
            # decision), and the record says why no copy can be served.
            _record_not_delivered(
                _stage, "delivery suppressed for this run (backfill "
                "without delivery); " + _unreadable,
                verdict=_CHAIN_SUPPRESSED)
        else:
            _record_not_delivered(_stage, exc)
        return []

    # ── 3-4. prepare + deliver over the CERTIFIED manifest ───────────
    # The WHOLE body is guarded, not just execute_chain: building the hop
    # plan refuses an undeclared target, and the chain refuses bad
    # options.  Either escaping would 500 a signed callback and strand a
    # run the job has already finished — the job does not retry callbacks.
    workdir = None
    try:
        workdir = tempfile.mkdtemp(prefix=f"spark_chain_{exec_id or 'run'}_")

        def _fetch_part(part, dest) -> None:
            if s3_client is not None:
                s3_client.download_file(
                    _bucket, f"{_prefix}/{part.name}", str(dest))
            else:
                shutil.copyfile(os.path.join(_prefix, part.name), str(dest))

        chain = prepare_artifact_chain(
            manifest, feed_config,
            workdir=workdir, fetch_part=_fetch_part,
            business_date=_run_bd,
            run_id=execution.get("id"),
            control_format_spec=_resolve_control_file_format(feed_config),
            calendar=_resolve_calendar(feed_config))
        # The rendered deliverable -- the bytes a hop sends -- is KEPT on
        # the shared output volume before any hop runs (2026-10-07): the
        # execution's Download serves it, a suppressed run's later hop
        # retry sends it, and the workdir below is deleted either way.
        _kept, _why_not = _keep_spark_deliverable(chain.deliverables)
        _record_artifact(_kept, _why_not)

        _receipts: List[Dict[str, Any]] = []

        def _transport(hop, _manifest):
            receipt: Dict[str, Any] = {}
            _receipts.append(receipt)
            files = [*chain.deliverables, *chain.sidecar_paths]
            ctl = (str(chain.control_file_path)
                   if chain.control_file_path else None)
            uri = ""
            for i, p in enumerate(files):
                # The control file rides with (after) the LAST file, over
                # the same reused connection (E-L1 pairing).
                uri = _deliver_data_then_control(
                    str(p), p.name,
                    ctl if i == len(files) - 1 else None,
                    hop.target_type, dict(hop.config), 0,
                    _cfg.retry_delay_seconds if _cfg else 60,
                    execution.get("feed_config_id"), exec_id,
                    _receipt=receipt)
            return {"uri": uri,
                    "sent_path": str(chain.deliverables[0]),
                    "verification": receipt.get("verification"),
                    "verification_detail":
                        receipt.get("verification_detail")}

        plan = build_hop_plan({**feed_config,
                               "destination_config": dest_config})
        runner = DeliveryHopRunner(
            db, {h.target_type: _transport for h in plan},
            environment=_deploy_environment(), actor=actor,
            suppression_policy=(_cfg.delivery_suppression if _cfg else None))
        outcomes = runner.execute_chain(
            plan, manifest,
            feed_config_id=execution.get("feed_config_id"),
            # THE SAME date the native lane hands its chain
            # (_effective_business_date: the bound run's, else the
            # calendar's, else today).  2026-10-11, found live on a MANUAL
            # spark_k8s run (no stored business_date): this passed None,
            # delivery_attempts.business_date is NOT NULL, and the hop
            # runner's insert failed -- "not_delivered" at stage deliver
            # while the native lane delivered the same manual run.
            business_date=_run_bd,
            feed_key=feed_config.get("name"),
            # the decision stored on the execution -- never the racing
            # "is a suppressed run still running?" lookup
            run_suppressed=_suppressed)
        # 2026-09-15 -- the SAME rule the native engine applies
        # (delivery_hops.chain_verdict): delivered only when EVERY declared
        # hop succeeded.  This lane used to ask the weaker "did any hop
        # succeed?" -- two consumers, two answers to one question.  A
        # suppressed chain is recorded not-delivered here exactly as
        # before (the stamp must not claim a delivery that did not happen).
        _verdict, _why = _chain_verdict(plan, outcomes)
        if _verdict != _CHAIN_DELIVERED:
            _record_not_delivered("hops", _why, verdict=_verdict)
        elif db is not None and execution.get("id") is not None:
            try:
                _upd: Dict[str, Any] = {
                    "stage_timings": _chain_record(_verdict, None)}
                # Where it WENT (the webhook no longer writes the artifact
                # store there for a job that did not deliver).
                _went = next((o.uri for o in (outcomes or [])
                              if getattr(o, "uri", None)), None)
                if _went:
                    _upd["destination_path"] = _went
                # 2026-10-22 (the owner: "execution.file_size_bytes returns 0
                # for every spark run") -- the job reports output_size_bytes
                # only when IT delivers; on this path QueryStudio renders and
                # delivers, and the success write never recorded a size, so
                # every such run read 0 bytes.  The size of what was sent,
                # read now (the workdir is removed below) -- the native
                # lane's rule: the produced file's size.
                _sizes = [p.stat().st_size for p in chain.deliverables
                          if p.is_file()]
                if _sizes:
                    _upd["file_size_bytes"] = int(sum(_sizes))
                # D1 (2026-10-07): the certificate's destination evidence by
                # THE rule the native engine and the job-delivered webhook
                # use -- from what THIS delivery holds (the hop's receipt,
                # a recount of the rendered file, the rendered rows).  The
                # webhook certified the ARTIFACT STORE before this ran,
                # which no pod can recount: always UNVERIFIED.
                _rcpt = _receipts[-1] if _receipts else {}
                _fm = _webhook_side_certificate(
                    db, execution, feed_config, chain, rows, _rcpt)
                if _fm:
                    _upd["files_metadata"] = _fm
                if _rcpt:
                    # The transfer's verification and the DESTINATION's row
                    # accounting, in the slot the native engine fills
                    # (stage_timings.delivery_verification) -- an Oracle
                    # hop that committed under max_error_percent read as
                    # fully delivered on this lane's record.
                    _dv = {"status": _rcpt.get("verification", "absent"),
                           "detail": _rcpt.get("verification_detail", "")}
                    for _k in ("delivered_rows", "dropped_rows"):
                        if isinstance(_rcpt.get(_k), int):
                            _dv[_k] = _rcpt[_k]
                    _upd["stage_timings"]["delivery_verification"] = _dv
                db.update_feed_execution(execution["id"], _with_artifact(_upd))
            except Exception as rec_exc:
                logger.error(
                    "[feed_engine] webhook-side delivery for %s DELIVERED but "
                    "the verdict could not be recorded (%s) -- the run reads "
                    "'delivery unknown' and nothing downstream of it starts",
                    exec_id, rec_exc)
        return outcomes
    except Exception as exc:
        _record_not_delivered("deliver", exc)
        return []
    finally:
        if workdir:
            shutil.rmtree(workdir, ignore_errors=True)


def _webhook_side_certificate(db, execution: dict, feed_config: dict, chain,
                              rows, receipt: dict) -> Optional[dict]:
    """``files_metadata`` with the webhook-side delivery's destination
    evidence and certificate, merged over a fresh read of the row (D1).
    None when nothing could be built -- the webhook's own record stands."""
    try:
        from core.feed.delivery_verdict import certified_dest_rows
        from core.feed import file_integrity as _fi
        from core.feed_perf import build_feed_certificate
        physical = None
        steps = set(getattr(chain, "steps", ()) or ())
        if len(chain.deliverables) == 1 and not (
                steps & {"package", "compress", "encrypt"}):
            physical = _fi.physical_row_count(
                str(chain.deliverables[0]),
                str(feed_config.get("output_format") or "csv").lower(),
                dict(feed_config.get("output_options") or {}))
        rendered = getattr(chain, "row_count", None)
        dest_rows, basis = certified_dest_rows(
            receipt=dict(receipt or {}), physical_rows=physical,
            rendered_rows=rendered)
        source_rows = int(rows) if isinstance(rows, int) else rendered
        fresh = {}
        _read = getattr(db, "get_feed_execution", None)
        if callable(_read) and execution.get("id") is not None:
            fresh = _read(execution["id"]) or {}
        fm = dict(fresh.get("files_metadata")
                  or execution.get("files_metadata") or {})
        fm["webhook_verification"] = {
            "output_path": str(chain.deliverables[0]) if chain.deliverables
            else "",
            "reported_rows": source_rows,
            "recount_rows": dest_rows, "recountable": dest_rows is not None,
            "basis": basis,
            "reason": ("QueryStudio rendered and delivered the file from the "
                       "job's artifacts (webhook-side delivery)"),
        }
        cert = build_feed_certificate(
            execution.get("execution_id") or "", subject_id=execution.get("id"),
            source_rows=source_rows, dest_rows=dest_rows,
            issued_at=time.time())
        if cert:
            fm["completeness_certificate"] = cert
        return fm
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[feed_engine] webhook-side certificate for %s could "
                       "not be built (%s) -- the webhook's record stands",
                       execution.get("execution_id"), exc)
        return None


def _artifact_unreachable_reason(output_path, exc) -> str:
    """Why the backend cannot read a Spark run's artifacts back, in the
    words the execution record and the screen show."""
    p = str(output_path or "")
    try:
        from core.spark_k8s.feed_conf import POD_LOCAL_ARTIFACT_DIR
    except Exception:
        POD_LOCAL_ARTIFACT_DIR = "/tmp/qs-spark-artifacts"
    if p.startswith(POD_LOCAL_ARTIFACT_DIR) or p.startswith("/tmp/"):
        return (f"the Spark job wrote its file pod-local ({p}) because no "
                f"artifact store is configured (spark_k8s.artifact_bucket); "
                f"Spark pods mount no shared volume, so the file is NOT "
                f"retrievable from QueryStudio by design")
    return (f"the produced artifacts at {p or '(no output path)'} could not "
            f"be read back: {exc}")


def _keep_spark_deliverable(deliverables) -> tuple:
    """Copy a Spark run's rendered deliverable into the shared output
    volume (feed_generation.output_dir).  ``(path, None)`` when kept,
    ``(None, why)`` when not -- a multi-file deliverable is not one
    downloadable file, and the record says so rather than pick one."""
    files = [Path(str(d)) for d in (deliverables or [])]
    if len(files) != 1:
        return None, (f"the run produced {len(files)} files (multi-part "
                      f"output with no packaging); the execution Download "
                      f"serves a single file -- declare "
                      f"output_options.packaging to get one archive")
    try:
        out_dir = (_cfg.output_dir if _cfg is not None else None)
        if not out_dir:
            from core.config import feed_generation as _fg_keep
            out_dir = _fg_keep.output_dir
        out = Path(str(out_dir))
        out.mkdir(parents=True, exist_ok=True)
        target = out / files[0].name
        from core.feed.publication import publish_file
        publish_file(files[0], target)
        return str(target), None
    except Exception as keep_exc:
        logger.error("[feed_engine] could not keep the Spark deliverable %s "
                     "on the output volume: %s", files[0], keep_exc)
        return None, f"the produced file could not be kept on the server: {keep_exc}"


def _effective_business_date(feed_config: dict, db: Any = None):
    """Phase 4 (2026-08-23): the run's REAL business_date, for filename
    tokens and the control file.

    Order: the bound feed_run row's business_date (execute_feed stashes
    ``_feed_run`` when a run row is bound -- since Phase 4 that covers the
    cron, queue, external and airflow paths) -> calendar-aware resolution
    (same arithmetic SOD uses) -> today UTC.  Before this, the ctl was
    written with business_date=None (the BUSINESS_DATE line silently
    ABSENT from every production control file, and delimited formats
    column-shifted) while filenames derived their own date from "today",
    so a backfill's file was named with the wrong date.
    """
    _fr = feed_config.get("_feed_run") or {}
    raw = _fr.get("business_date")
    if raw:
        try:
            if isinstance(raw, datetime):
                return raw.date()
            if isinstance(raw, date):
                return raw
            return date.fromisoformat(str(raw)[:10])
        except Exception:
            pass
    try:
        from core.feed.run_ownership import resolve_feed_business_date
        return resolve_feed_business_date(
            db if db is not None else _db_manager, feed_config)
    except Exception:
        return datetime.now(timezone.utc).date()


def _legacy_build_filename(template: str, feed_name: str, fmt: str,
                           business_date=None) -> str:
    """Original token expander: ``{name} {date} {ext} {timestamp} {uuid}``.

    2026-10-07: ``{date}`` is the run's BUSINESS date (the wall-clock day
    only for a run without one) -- see
    ``core.feed.filename_renderer.legacy_token_values``, the one resolver
    every lane shares.  The caller always had the business date and this
    expander never read it: a backfill of the 6th shipped under the 7th."""
    from core.feed.filename_renderer import legacy_token_values
    ext_map = {"csv": "csv", "parquet": "parquet", "json": "jsonl", "excel": "xlsx"}
    ext = ext_map.get(fmt, fmt)
    return template.format(**legacy_token_values(
        feed_name, ext, business_date=business_date))


def _build_filename(template: str, feed_name: str, fmt: str, options: dict = None,
                    feed_config: dict = None, calendar=None, run_id: int = None,
                    business_date=None, sequence_value: int = None) -> str:
    """Render the output filename.

    Phase 130/2 — when the template contains enterprise tokens
    (``${FUNC(FMT)}`` or ``{name:fmt}``) we delegate to
    ``core.feed.pipeline.render_filename_for_feed`` which uses the
    typed ``FilenameRenderer`` + injected ``BusinessCalendar``.  Legacy
    templates (``{name}_{date}.{ext}`` etc.) keep their existing
    expansion verbatim.
    """
    from core.feed.pipeline import (
        render_filename_for_feed,
        template_uses_enterprise_tokens,
    )
    if not template_uses_enterprise_tokens(template):
        return _legacy_build_filename(template, feed_name, fmt,
                                      business_date=business_date)

    ext_map = {"csv": "csv", "parquet": "parquet", "json": "jsonl", "excel": "xlsx"}
    ext = ext_map.get(fmt, fmt)
    fc = dict(feed_config) if feed_config else {"name": feed_name}
    fc.setdefault("name", feed_name)
    return render_filename_for_feed(
        template, ext, fc,
        calendar=calendar,
        business_date=business_date,
        run_id=run_id,
        sequence_value=sequence_value,
        legacy_renderer=lambda t, _fc, _ext: _legacy_build_filename(
            t, feed_name, fmt, business_date=business_date),
    )


# ---------------------------------------------------------------------------
# Backend status and management
# ---------------------------------------------------------------------------
def get_backend_status() -> list:
    """Returns circuit breaker states for all backends."""
    result = [{"name": "native", "state": "always_available", "failures": 0}]
    if _airflow_breaker:
        result.append(_airflow_breaker.to_dict())
    return result


def reset_backend_breaker(name: str) -> bool:
    """Resets circuit breaker for named backend."""
    if name == "airflow" and _airflow_breaker:
        _airflow_breaker.reset()
        logger.info("[feed_engine] Circuit breaker reset for airflow")
        return True
    return False


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------
class FeedEngineNotWired(RuntimeError):
    """``cleanup_old_executions`` was called in a process that never ran
    ``init_feed_engine`` -- the sweep cannot know the retention or the
    DAO.  Raised (2026-10-08): it used to ``return 0``, which the retention
    ledger read as "swept, nothing to reap" on a pod that had reaped
    nothing, ever."""


def cleanup_old_executions() -> int:
    """Cleans up old execution records and temp files.

    Returns the number of execution rows deleted.  RAISES when the engine
    is not initialised here (:class:`FeedEngineNotWired`) and when the
    legal-hold store cannot be read (``legal_hold_feed_ids`` fails closed
    by contract; this used to swallow it into a 0).  A retention of 0 or
    less keeps every row (the sibling sweeps' meaning of 0) and only the
    temp-file sweep runs.
    """
    if not _db_manager or not _cfg:
        raise FeedEngineNotWired(
            "the feed engine is not initialised in this process "
            "(init_feed_engine was never called here: feed_generation.enabled "
            "is false, or this pod does not run feeds) -- nothing swept")
    retention = int(_cfg.execution_history_retention_days or 0)
    if retention <= 0:
        logger.info("[feed_engine] execution_history_retention_days=%s: keeping "
                    "every execution row (0 = forever)", retention)
        deleted = 0
    else:
        # a hold store that cannot be read must stop the reap, audibly
        deleted = _db_manager.cleanup_old_feed_executions(retention_days=retention)
        if deleted:
            logger.info("[feed_engine] Cleaned up %d old feed execution records", deleted)
    try:

        # Clean temp files older than 24h
        tmp_dir = Path(_cfg.output_dir) / "tmp"
        if tmp_dir.exists():
            cutoff = time.time() - 86400
            for f in tmp_dir.glob("*"):
                try:
                    if f.is_file() and f.stat().st_mtime < cutoff:
                        f.unlink(missing_ok=True)
                    elif f.is_dir():
                        # 2026-08-22 — parts DIRECTORIES (write-ladder
                        # rungs 1/3, zero-copy union, resume artifacts)
                        # leaked forever here: only files were swept.  A
                        # dir is stale when its NEWEST entry (or itself,
                        # when empty) is older than the cutoff — a dir
                        # mtime alone lies on filesystems that don't
                        # bump it for content writes.
                        newest = f.stat().st_mtime
                        for child in f.iterdir():
                            try:
                                newest = max(newest,
                                             child.stat().st_mtime)
                            except OSError:
                                pass
                        if newest < cutoff:
                            import shutil as _sh
                            _sh.rmtree(f, ignore_errors=True)
                except OSError:
                    pass
        return deleted
    except Exception as exc:
        # the temp-file sweep is best-effort; the row count stands
        logger.warning("[feed_engine] temp-file cleanup error: %s", exc)
        return deleted


# ---------------------------------------------------------------------------
# Scheduled feed runner (called by APScheduler)
# ---------------------------------------------------------------------------
def run_scheduled_feed(feed_config_id: int, db: Any = None):
    """
    Synchronous entry point for APScheduler jobs.
    Creates a new event loop to run the async execute_feed.

    2026-08-20 — optional ``db``: a scheduler that holds its own db manager
    (the worker pod) can pass it explicitly; it flows to execute_feed as
    FeedEngineDeps.  Default None keeps every existing registration
    working via the module-global fallback.
    """
    logger.info("[feed_engine] Scheduled feed %d triggered", feed_config_id)
    _deps = FeedEngineDeps(db_manager=db) if db is not None else None

    # Phase 4 (2026-08-23) — drift guard: the DB row is the truth for
    # whether this feed is scheduled.  A persistent APScheduler job can
    # outlive a disable/delete that happened on a pod without a local
    # scheduler (the reconciler removes it within its interval, but this
    # fire may land first).  A schedule_enabled=False feed must not run.
    try:
        _gate_db = db if db is not None else _db_manager
        if _gate_db is None:
            # Engine not wired in this process — let execute_feed raise
            # its LOUD init error rather than mislabel it a missing row.
            raise RuntimeError("feed engine db not initialised")
        _fc = _gate_db.get_feed_config(feed_config_id)
        if not _fc:
            logger.info("[feed_engine] Scheduled feed %d skipped — config "
                        "no longer exists", feed_config_id)
            return
        if not _fc.get("is_active") or not _fc.get("schedule_enabled"):
            logger.info(
                "[feed_engine] Scheduled feed %d skipped — is_active=%s "
                "schedule_enabled=%s in the DB (stale APScheduler job; the "
                "schedule reconciler will remove it)",
                feed_config_id, _fc.get("is_active"), _fc.get("schedule_enabled"),
            )
            return
    except Exception as _gate_exc:
        # The gate is a drift guard, not a correctness gate on the run
        # itself — a transient DB read failure must not kill a legitimate
        # scheduled fire (execute_feed re-checks is_active authoritatively).
        logger.warning("[feed_engine] Scheduled feed %d drift-guard read "
                       "failed (%s) — proceeding", feed_config_id, _gate_exc)
        _fc = None

    # ── Deployment window (FR-OPS-04, wired 2026-09-03) ─────────────────
    #
    # Every API path that STARTS a run consults the windows; the CRON path
    # did not, so an admin who declared a change window still had the
    # night's scheduled feeds fire straight through it — the one class of
    # run that nobody is awake to notice.  Blocks STARTS only, never a run
    # in flight (H1: killing a run mid-SFTP is worse than the window it
    # violates).
    #
    # FAIL-OPEN and audible, deliberately the same posture as the API gate
    # and the OPPOSITE of the authoring validators: an unreadable settings
    # row must not stop the estate at 03:00.  A missed window is an
    # inconvenience someone notices; a silent fleet-wide stop is an
    # incident.
    if _fc is not None:
        try:
            from core.feed.deployment_window import blocking_window_for_feed
            _win = blocking_window_for_feed(_gate_db, _fc)
        except Exception as _win_exc:
            logger.error(
                "[feed_engine] Scheduled feed %d — deployment windows could "
                "not be read (%s: %s); window NOT ENFORCED for this run",
                feed_config_id, type(_win_exc).__name__, _win_exc)
            _win = None
        if _win:
            logger.warning(
                "[feed_engine] Scheduled feed %d NOT STARTED — deployment "
                "window %s is in force until %s (%s).  The run was not "
                "created; it will fire normally on the next scheduled tick "
                "after the window closes.",
                feed_config_id, _win.get("id"), _win.get("ends_at"),
                _win.get("reason") or "no reason recorded")
            try:
                from core.feed.deployment_window import record_refusal
                record_refusal(_gate_db, _win.get("id"),
                               feed_id=feed_config_id,
                               actor="cron", action="scheduled_run")
            except Exception as _rec_exc:      # accounting, never a blocker
                logger.warning(
                    "[feed_engine] Scheduled feed %d window refusal could "
                    "not be recorded (%s)", feed_config_id, _rec_exc)
            return

    # Phase 4 (2026-08-23) — the cron path OWNS the feed's daily run row.
    #
    # Before: run_scheduled_feed never looked at feed_runs at all.  With
    # SOD enabled, the cron feed's row stayed "pending" all day while the
    # feed delivered — the today page showed it as never-run, the SLA
    # tracker then flagged a FALSE breach, and an operator "Rerun" caused a
    # duplicate delivery.  Now the fire:
    #   1. resolves the SAME calendar business_date SOD keys the row on
    #      (core/feed/run_ownership.py — one arithmetic, not two);
    #   2. SKIPS on a non-business day per the feed's calendar (the UI has
    #      always promised "attach a calendar -> holiday skip"; only SOD
    #      honoured it);
    #   3. respects the row's verdicts: SKIP (action condition) and WAIT
    #      (ETL dependency gate) do not run;
    #   4. atomically claims a pending row (claimed_by="cron") and passes
    #      feed_run_id so execute_feed syncs status to the dashboard —
    #      or CREATES the row when SOD hasn't (yet): the (feed, date) key
    #      is then owned before any late SOD/queue tick can double-run it;
    #   5. a completed row = intra-day refire (hourly crons): runs legacy,
    #      without touching the recorded first delivery; a failed row is
    #      ADOPTED so the retry-on-next-fire updates the dashboard.
    # Row bookkeeping is fail-open: none of it may kill a legitimate fire.
    _feed_run_id = None
    if _fc is not None:
        try:
            from core.feed.run_ownership import resolve_feed_business_date
            _today = datetime.now(timezone.utc).date()
            _bdate = resolve_feed_business_date(_gate_db, _fc, _today)
            if _bdate != _today:
                logger.info(
                    "[feed_engine] Scheduled feed %d skipped — %s is not a "
                    "business day for calendar %r (business_date resolves "
                    "to %s)", feed_config_id, _today.isoformat(),
                    _fc.get("calendar_name"), _bdate.isoformat(),
                )
                return
            _row = _gate_db.get_feed_run_by_feed_date(feed_config_id, _bdate)
            if _row is None:
                # 2026-09-27 — the SAME creation-time dependency check SOD
                # and the backfill launcher apply (ONE function in
                # core/feed/etl_dependency.py).  Step 3 above honours a
                # WAIT that SOD computed, but when SOD had not created the
                # row (sod_enabled ships FALSE; a cron-only estate) this
                # branch wrote it RUN and ran -- the gate held only for
                # feeds SOD had already looked at.  Now the row is born
                # WAIT, pending, and the fire defers exactly as it does
                # for a SOD-held row: the poller flips it to RUN when the
                # arrival lands and the queue worker claims it (a
                # cron-owned row is claimable once its fire time has
                # passed).  Fail-open inside the shared function.
                from core.feed.etl_dependency import hold_reason_at_creation
                _hold = hold_reason_at_creation(_gate_db, _fc, _bdate)
                if _hold:
                    _held = _gate_db.create_feed_run({
                        "feed_config_id": feed_config_id,
                        "business_date": _bdate,
                        "run_date": _today,
                        "scheduled_time": datetime.now(timezone.utc),
                        "status": "pending",
                        "triggered_by": "scheduler",
                        "run_type": "scheduled",
                        "action_decision": "WAIT",
                        "action_reason": _hold,
                    })
                    logger.info(
                        "[feed_engine] Scheduled feed %d deferred — ETL "
                        "dependencies not ready for %s (%s); run %s created "
                        "WAIT, the dependency poller flips it to RUN and the "
                        "queue worker picks it up", feed_config_id,
                        _bdate.isoformat(), _hold,
                        (_held or {}).get("id") if isinstance(_held, dict)
                        else None,
                    )
                    return
                try:
                    _row = _gate_db.create_feed_run({
                        "feed_config_id": feed_config_id,
                        "business_date": _bdate,
                        "run_date": _today,
                        "status": "running",
                        "started_at": datetime.now(timezone.utc),
                        "claimed_by": "cron",
                        "triggered_by": "scheduler",
                        "action_decision": "RUN",
                    })
                    _feed_run_id = int(_row["id"])
                except Exception:
                    # Lost a create race (SOD / another pod) — re-read and
                    # fall through to the claim logic below.
                    _row = _gate_db.get_feed_run_by_feed_date(
                        feed_config_id, _bdate)
                    _feed_run_id = None
            if _feed_run_id is None and _row is not None:
                _status = str(_row.get("status") or "").lower()
                _decision = str(_row.get("action_decision") or "RUN").upper()
                if _status == "skipped" or _decision == "SKIP":
                    logger.info(
                        "[feed_engine] Scheduled feed %d skipped — SOD "
                        "action condition verdict SKIP for %s (%s)",
                        feed_config_id, _bdate.isoformat(),
                        _row.get("action_reason") or "no reason recorded",
                    )
                    return
                if _decision == "WAIT" and _status == "pending":
                    logger.info(
                        "[feed_engine] Scheduled feed %d deferred — ETL "
                        "dependencies not ready (WAIT) for %s; the "
                        "dependency poller flips it to RUN and the queue "
                        "worker picks it up", feed_config_id,
                        _bdate.isoformat(),
                    )
                    return
                if _status == "pending":
                    _claimed = _gate_db.claim_pending_feed_run(
                        int(_row["id"]), claimed_by="cron")
                    if _claimed is None:
                        logger.info(
                            "[feed_engine] Scheduled feed %d skipped — row "
                            "for %s was claimed by another worker between "
                            "fire and claim", feed_config_id,
                            _bdate.isoformat(),
                        )
                        return
                    _feed_run_id = int(_row["id"])
                elif _status == "running":
                    logger.info(
                        "[feed_engine] Scheduled feed %d skipped — a run "
                        "for %s is already in flight (claimed_by=%s)",
                        feed_config_id, _bdate.isoformat(),
                        _row.get("claimed_by"),
                    )
                    return
                elif _status == "failed":
                    _feed_run_id = int(_row["id"])   # adopt: retry updates it
                # completed / cancelled: legacy intra-day refire, no row.
        except Exception as _own_exc:
            logger.warning(
                "[feed_engine] Scheduled feed %d run-row bookkeeping failed "
                "(%s) — running without dashboard sync",
                feed_config_id, _own_exc,
            )
            _feed_run_id = None

    try:
        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(
                execute_feed(feed_config_id, trigger_type="scheduled",
                             triggered_by="scheduler",
                             feed_run_id=_feed_run_id, deps=_deps)
            )
            logger.info(
                "[feed_engine] Scheduled feed %d completed — status=%s",
                feed_config_id, result.get("status"),
            )
            # Same claim-release rule as the queue worker: execute_feed can
            # decline without raising when another execution holds the
            # feed's active slot — the claimed row must not sit 'running'
            # unowned until the stale reclaim.
            if (_feed_run_id is not None
                    and isinstance(result, dict)
                    and result.get("status") == "skipped"
                    and result.get("reason") == "already_executing"):
                try:
                    _gate_db.reset_feed_run_to_pending_if_owned(
                        _feed_run_id, owned_by="cron")
                    logger.info(
                        "[feed_engine] Scheduled feed %d released feed_run "
                        "%s back to pending — another execution is active",
                        feed_config_id, _feed_run_id,
                    )
                except Exception as _rel_exc:
                    logger.warning(
                        "[feed_engine] could not release feed_run %s: %s",
                        _feed_run_id, _rel_exc,
                    )
        finally:
            loop.close()
    except Exception as exc:
        logger.error("[feed_engine] Scheduled feed %d error: %s", feed_config_id, exc, exc_info=True)
        # If execute_feed raised BEFORE it could sync the claimed row
        # (e.g. config deactivated between gate and load), release the
        # claim so the row does not sit running-unowned for an hour.
        # Conditional: only flips rows STILL running and cron-owned —
        # a run execute_feed already marked failed is left alone.
        if _feed_run_id is not None and _gate_db is not None:
            try:
                _gate_db.reset_feed_run_to_pending_if_owned(
                    _feed_run_id, owned_by="cron")
            except Exception as _rel2_exc:
                logger.debug("[feed_engine] claim release failed: %s",
                             _rel2_exc)


# ---------------------------------------------------------------------------
# Notification helpers
# ---------------------------------------------------------------------------
def _cleanup_temp_files(paths: list):
    """Remove temporary files created during feed execution.

    2026-08-22 — a native result can now be a parts DIRECTORY (write
    ladder rungs 1/3, zero-copy union); remove those too, or every
    multi-part feed leaks its whole dataset on pod disk."""
    import shutil as _sh
    for p in paths:
        try:
            if p and os.path.isfile(p):
                os.unlink(p)
                logger.debug("[feed_engine] Cleaned up temp file: %s", p)
            elif p and os.path.isdir(p):
                _sh.rmtree(p, ignore_errors=True)
                logger.debug("[feed_engine] Cleaned up temp parts dir: %s", p)
        except OSError as exc:
            logger.debug("[feed_engine] Temp file cleanup failed for %s: %s", p, exc)


def _recorded_feed_outputs(paths: list) -> Optional[set]:
    """Which of ``paths`` an execution RECORDED as its output
    (``destination_path`` or ``artifact_path``), as a set of those path
    strings.  ``set()`` when there is nothing to ask or no metadata db is
    wired (the sweep's pre-2026-10-07 behaviour); ``None`` when the
    records could not be read -- the caller keeps everything then."""
    if not paths or _db_manager is None:
        return set()
    try:
        from core.db.models import FeedExecution as _FE
        found: set = set()
        with _db_manager.get_session(read_only=True) as session:
            for i in range(0, len(paths), 500):
                chunk = paths[i:i + 500]
                for dest, art in (session.query(_FE.destination_path,
                                                _FE.artifact_path)
                                  .filter((_FE.destination_path.in_(chunk))
                                          | (_FE.artifact_path.in_(chunk)))
                                  .all()):
                    found.update(p for p in (dest, art) if p)
        return found
    except Exception as exc:
        logger.warning(
            "[feed_engine] orphan sweep: could not read which files are "
            "recorded run outputs (%s) -- deleting NOTHING this pass", exc)
        return None


def sweep_orphan_feed_temp_files(*, max_age_hours: float = 24.0) -> Dict[str, int]:
    """Phase 131 deep-dive #12 — orphan-temp-file sweeper.

    When a feed worker pod crashes mid-execution (OOM, SIGKILL), the
    finally block that calls _cleanup_temp_files never runs and the
    intermediate parquet files leak in the output dir.  This sweeper
    deletes feed temp files older than max_age_hours that don't
    correspond to a still-running feed_execution.

    Called from the scheduler on a daily-ish interval.  Cheap — walks
    one directory, checks mtimes.  No-op when the dir is empty.

    Returns counters: {scanned, deleted, kept, errors}.
    """
    counters = {"scanned": 0, "deleted": 0, "kept": 0, "errors": 0}
    if max_age_hours <= 0:
        return counters
    try:
        out_dir = Path(_cfg.output_dir)
    except Exception:
        return counters
    if not out_dir.exists():
        return counters
    cutoff = time.time() - (max_age_hours * 3600.0)
    # Build the set of execution_ids that are still IN-FLIGHT (pending /
    # running) so we don't delete their working files mid-stream.
    inflight_ids: set = set()
    try:
        if _db_manager is not None:
            with _db_manager.get_session(read_only=True) as session:
                from core.db.models import FeedExecution as _FE
                for row in (session.query(_FE.execution_id)
                              .filter(_FE.status.in_(["pending", "running"]))
                              .all()):
                    inflight_ids.add(str(row.execution_id))
    except Exception as e:
        logger.debug("[feed_engine] orphan sweep: could not load inflight ids: %s", e)

    _stale: list = []
    for p in out_dir.iterdir():
        if not p.is_file():
            continue
        # Only consider feed temp/output files.  Filename convention:
        # they include an execution_id segment like "feed-<hex>".
        name = p.name
        if not (name.startswith("feed-") or "feed_" in name):
            continue
        counters["scanned"] += 1
        try:
            mtime = p.stat().st_mtime
        except OSError:
            counters["errors"] += 1
            continue
        if mtime > cutoff:
            counters["kept"] += 1
            continue
        # Skip if any inflight execution_id is in the filename.
        if any(eid in name for eid in inflight_ids):
            counters["kept"] += 1
            continue
        _stale.append(p)

    # 2026-10-07 -- a file an execution RECORDED is a run's output, not an
    # orphan: the file a local destination received (destination_path) or
    # the file a run produced and kept (artifact_path -- a backfill without
    # delivery, a dry run).  This sweep matches by NAME ("feed_" anywhere),
    # so a feed whose filename happens to contain it lost its downloadable
    # output after 24 h.  Unreadable records keep everything this pass: a
    # sweep that cannot tell an orphan from an output must not guess.
    # Both spellings: artifact_path is written as output_dir/filename, a
    # local destination_path as its realpath.
    _spellings = {p: {str(p), os.path.realpath(str(p))} for p in _stale}
    _recorded = _recorded_feed_outputs(
        sorted({s for ss in _spellings.values() for s in ss}))
    for p in _stale:
        name = p.name
        if _recorded is None or (_spellings[p] & _recorded):
            counters["kept"] += 1
            continue
        try:
            p.unlink()
            counters["deleted"] += 1
            logger.info("[feed_engine] orphan sweep: deleted %s", name)
        except OSError as exc:
            logger.warning("[feed_engine] orphan sweep: could not delete %s: %s", name, exc)
            counters["errors"] += 1

    # 2026-08-04 — also sweep the atomic-publication scratch dir
    # (``.qs-partial``, see core/feed/publication.py).  A pod killed
    # mid-publication leaves its scratch file behind; everything in the
    # scratch dir is ours by construction, so age + not-inflight is a
    # sufficient deletion criterion (no filename-convention filter).
    try:
        from core.feed.publication import SCRATCH_DIR_NAME as _scratch_name
    except ImportError:
        _scratch_name = ".qs-partial"
    scratch = out_dir / _scratch_name
    if scratch.is_dir():
        for p in scratch.iterdir():
            if not p.is_file():
                continue
            counters["scanned"] += 1
            try:
                mtime = p.stat().st_mtime
            except OSError:
                counters["errors"] += 1
                continue
            if mtime > cutoff or any(eid in p.name for eid in inflight_ids):
                counters["kept"] += 1
                continue
            try:
                p.unlink()
                counters["deleted"] += 1
                logger.info("[feed_engine] orphan sweep: deleted scratch %s", p.name)
            except OSError as exc:
                logger.warning(
                    "[feed_engine] orphan sweep: could not delete scratch %s: %s",
                    p.name, exc)
                counters["errors"] += 1
    return counters


def _event_audience(feed_id, actor, run_id=None) -> list:
    """The audience of this execution's live events -- resolved ONCE per
    execution (``execute_feed`` stores it on ``_active_exec_ctx``) through
    THE function, ``core.feed.event_audience.feed_event_audience``; resolved
    on the spot for an event outside that execution's context, naming the
    run the caller knows (``run_id``; None when the event has none) so the
    person who asked for it hears it there too."""
    ctx = _active_exec_ctx.get()
    if (ctx and ctx.get("audience") is not None
            and ctx.get("feed_id") == feed_id
            and ctx.get("triggered_by") == actor):
        return list(ctx["audience"])
    from core.feed.event_audience import feed_event_audience
    return feed_event_audience(_db_manager, feed_id, actor, run_id=run_id)


def _notify(event_type: str, payload: dict):
    """Send notification via broadcast function if available.

    2026-10-07 -- ADDRESSED to the feed's audience (the actor if a person,
    the owner, the owner group), never to ``triggered_by`` alone: a queue-
    worker run was addressed to "queue_worker" and nobody saw it live.
    ``triggered_by`` stays in the payload as the recorded actor."""
    if _broadcast_fn:
        try:
            from core.feed.event_audience import address
            _broadcast_fn(address({
                "type": event_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **payload,
            }, _event_audience(
                payload.get("feed_id"), payload.get("triggered_by"),
                run_id=(payload.get("feed_run_id")
                        or (_active_exec_ctx.get() or {}).get("feed_run_id")))))
        except Exception as exc:
            logger.debug("[feed_engine] Broadcast failed (non-critical): %s", exc)


def publish_run_progress(execution: dict, progress: dict, lines: list) -> str:
    """A detached run's report (core/feed/run_progress.py), told to the run's
    audience the way a native run tells it: ``feed_progress`` (with the
    record under ``progress``) and one ``feed_run_log`` per line, so the
    board and the run-log dialog read a Spark run exactly like a native one.
    Returns this pod's log stream (``live`` when its broadcast streams
    lines), which the caller records on the execution."""
    from core.feed.event_audience import address, run_log_stream_of
    feed_id = execution.get("feed_config_id")
    who = execution.get("triggered_by")
    run_id = execution.get("feed_run_id")
    _notify("feed_progress", {
        "feed_id": feed_id, "execution_id": execution.get("execution_id"),
        "feed_run_id": run_id, "stage": progress.get("phase"),
        "backend": progress.get("lane"),
        "elapsed_seconds": progress.get("elapsed_seconds"),
        "progress": progress, "triggered_by": who,
    })
    if _broadcast_fn is not None and lines:
        audience = _event_audience(feed_id, who, run_id=run_id)
        at = datetime.now(timezone.utc).isoformat()
        for ln in lines:
            try:
                _broadcast_fn(address({
                    "event": "feed_run_log", "exec_id": execution.get("execution_id"),
                    "exec_db_id": execution.get("id"), "feed_id": feed_id,
                    "triggered_by": who, "level": "INFO", "line": ln, "at": at,
                }, audience))
            except Exception as exc:                         # noqa: BLE001
                logger.debug("[feed-progress] line broadcast failed: %s", exc)
                break
    return run_log_stream_of(_broadcast_fn)


#: the alerts a DELIVERY answers (their clear condition is "the run delivers")
_ALERTS_A_DELIVERY_CLEARS = ("run_failed", "sla_at_risk", "sla_breached", "restatement_rerun")


def _run_alerts(feed_config: dict, outcome: str, details: dict, db: Any,
                exec_db_id: Any) -> None:
    """THE alert of a terminal outcome (2026-10-12, core/feed/feed_alerts.py):
    a failure raises ``run_failed`` for the (feed, business date) -- once,
    whatever the retries -- and a success CLEARS every open alert a delivery
    answers.  Independent of ``notify_on_failure`` (that is the author's own
    e-mail); the kind's channels are data.  Never raises."""
    try:
        from core.feed import feed_alerts
        ex = db.get_feed_execution(exec_db_id) if (db is not None and exec_db_id) else None
        bd = (ex or {}).get("business_date")
        if not bd or feed_config.get("id") is None:
            return
        if outcome == "success":
            feed_alerts.clear(db, by=f"delivered by {(ex or {}).get('execution_id')}",
                              feed_config_id=int(feed_config["id"]), business_date=bd,
                              kinds_=list(_ALERTS_A_DELIVERY_CLEARS))
        elif outcome == "failure":
            feed_alerts.raise_alert(
                db, "run_failed", feed=feed_config, business_date=bd,
                feed_run_id=(ex or {}).get("feed_run_id"),
                execution_id=(ex or {}).get("execution_id"),
                dedupe_key=f"run_failed:{feed_config['id']}:{str(bd)[:10]}",
                message=str(details.get("error") or "failed")[:1000])
    except Exception as exc:                                    # noqa: BLE001
        logger.warning("[feed_engine] run alert for feed %s not raised: %s",
                       feed_config.get("id"), exc)


def _send_notifications(feed_config: dict, outcome: str, details: dict,
                        db: Any = None, exec_db_id: Any = None,
                        stage_timings: Optional[dict] = None) -> dict:
    """Send email/webhook notifications based on feed config.

    outcome: 'success' or 'failure'

    Returns the notification VERDICT -- ``{"email": {...}, "webhook":
    {...}}`` with a ``state`` each (``sent`` / ``failed`` / ``unconfigured``
    / ``blocked`` / ``none``) -- and, when ``exec_db_id`` is given, writes it
    onto the run's ``stage_timings["notifications"]`` so the record says
    what was and was not sent.  ``stage_timings`` is the caller's LIVE dict:
    the failure path re-persists it after this call, so the verdict must be
    in it or that later write erases the row's copy (found by the engine
    test on the day this was built).

    2026-09-15 -- THE E-MAIL HALF NEVER MAILED.  It enqueued ``{"type":
    "email"}`` into ``pending_notifications``, whose only reader
    (``core/notification_poller.py``) broadcasts rows over WebSocket; no
    SMTP call existed on that path, and the log said "Email notification
    queued".  An author who filled in ``notify_emails`` + ``notify_on_
    failure`` was paged by nothing, ever.  The product's mailer is
    ``core.email_service.send_email`` (the step model, DataFlow policies
    and Clockwork use it); this path uses it now.  Notifications are
    ADVISORY -- they run after the terminal write and never change the
    run's status -- so a mailer that is not configured fails OPEN, but
    never silently: the run record and an ERROR line both carry
    ``email_service.NOT_CONFIGURED_REASON``.
    """
    db = db if db is not None else _db_manager  # transition fallback
    _run_alerts(feed_config, outcome, details, db, exec_db_id)
    verdict: Dict[str, Any] = {"email": {"state": "none"},
                               "webhook": {"state": "none"}}
    should_notify = (
        (outcome == "success" and feed_config.get("notify_on_success"))
        or (outcome == "failure" and feed_config.get("notify_on_failure"))
    )
    if not should_notify:
        return verdict

    feed_name = details.get("feed_name", feed_config.get("name", ""))

    # Webhook notification — SSRF-validated (Phase 132-A)
    webhook_url = feed_config.get("notify_webhook")
    if webhook_url:
        try:
            from core.url_safety import validate_url_safety
            validate_url_safety(webhook_url)
            import requests
            payload = {
                "event": f"feed_{outcome}",
                "feed_id": feed_config.get("id"),
                "feed_name": feed_name,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **details,
            }
            resp = requests.post(webhook_url, json=payload, timeout=15,
                                allow_redirects=False)
            logger.info("[feed_engine] Webhook notification sent to %s — status %d",
                        webhook_url, resp.status_code)
            verdict["webhook"] = {
                "state": "sent" if 200 <= int(resp.status_code) < 300 else "failed",
                "http_status": int(resp.status_code)}
        except ValueError as ssrf_exc:
            logger.warning("[feed_engine] Webhook SSRF blocked for %s: %s",
                           webhook_url, ssrf_exc)
            verdict["webhook"] = {"state": "blocked", "reason": str(ssrf_exc)[:300]}
        except Exception as exc:
            logger.warning("[feed_engine] Webhook notification to %s failed: %s",
                           webhook_url, exc)
            verdict["webhook"] = {"state": "failed", "reason": str(exc)[:300]}

    # Email notification -- THE recipients of a feed (2026-10-12,
    # core/feed/feed_alerts.py::email_recipients): ``notify_emails`` plus the
    # owner group's ``notification_email`` (Phase 130 hotfix-13: the whole
    # on-call rotation), de-duplicated.  The feed's alerts read the same
    # function, so "who gets this feed's e-mail" has one answer.
    from core.feed.feed_alerts import email_recipients
    recipients = email_recipients(db, feed_config)
    if recipients:
        subject = f"Feed '{feed_name}' {outcome}"
        if outcome == "success":
            lines = [f"Feed '{feed_name}' completed successfully.",
                     f"Rows: {details.get('rows', 'N/A')}",
                     f"Destination: {details.get('destination', 'N/A')}",
                     f"Duration: {details.get('duration', 'N/A')}s"]
        elif details.get("escalation"):
            # 2026-09-27 -- the 48 h WAIT escalation rides this path so the
            # same addresses that hear about a failed run hear about a run
            # that gave up waiting; the ORIGINAL WAIT reason is kept.
            lines = [f"Feed '{feed_name}' gave up waiting on its dependencies "
                     f"for business date {details.get('business_date', 'N/A')} "
                     f"and was marked failed.",
                     f"Waited: {details.get('hours_waiting', 'N/A')}h",
                     f"Waiting on: {details.get('wait_reason', 'unknown')}",
                     f"Detail: {details.get('error', 'Unknown')}",
                     "Next: skip the dependency with a reason on the Feeds Today "
                     "page, or re-run the feed once the upstream lands."]
        else:
            lines = [f"Feed '{feed_name}' failed.",
                     f"Error: {details.get('error', 'Unknown')}",
                     f"Duration: {details.get('duration', 'N/A')}s"]
        text_body = "\n".join(lines)
        html_body = "<pre>" + "\n".join(
            str(l).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            for l in lines) + "</pre>"
        # THE mailer -- the same one the step model, DataFlow's policies
        # and Clockwork dial.  ``send_email`` returns a bool and never
        # raises; a False is a FAILURE here (the relay refused after its
        # own retries, or every address failed validation), recorded as
        # such rather than as "queued".
        from core.email_service import (NOT_CONFIGURED_REASON,
                                        is_email_enabled, send_email)
        if not is_email_enabled():
            verdict["email"] = {"state": "unconfigured",
                                "recipients": recipients,
                                "reason": NOT_CONFIGURED_REASON}
            logger.error(
                "[feed_engine] Feed %s %s notification NOT sent to %s: %s. "
                "Set email.host (and email.enabled) or clear the feed's "
                "notify_emails -- until then nobody is paged.",
                feed_config.get("id"), outcome, recipients,
                NOT_CONFIGURED_REASON)
        else:
            try:
                sent = bool(send_email(to_addresses=recipients, subject=subject,
                                       html_body=html_body, text_body=text_body))
                fail_reason = ("send_email returned False -- the SMTP "
                               "conversation failed after its own retries, "
                               "or every address was rejected by validation")
            except Exception as exc:          # the mailer's contract is "never raises"
                sent, fail_reason = False, f"{type(exc).__name__}: {exc}"
            if sent:
                verdict["email"] = {"state": "sent", "recipients": recipients,
                                    "subject": subject}
                logger.info("[feed_engine] Feed %s %s notification sent to %s",
                            feed_config.get("id"), outcome, recipients)
            else:
                verdict["email"] = {"state": "failed", "recipients": recipients,
                                    "reason": fail_reason[:500]}
                logger.error(
                    "[feed_engine] Feed %s %s notification FAILED for %s: %s",
                    feed_config.get("id"), outcome, recipients, fail_reason)

    # The record says what was and was not sent.  Merged OVER the row's
    # current stage_timings (the terminal write has already landed, and on
    # the spark_k8s lane the webhook's entries live there too) -- never a
    # clobber.  Accounting must not fail a run that has already finished.
    if isinstance(stage_timings, dict):
        stage_timings["notifications"] = verdict
    if exec_db_id is not None and db is not None:
        try:
            row = db.get_feed_execution(exec_db_id) or {}
            merged = dict(row.get("stage_timings") or {})
            merged["notifications"] = verdict
            db.update_feed_execution(exec_db_id, {"stage_timings": merged})
        except Exception as exc:
            logger.warning(
                "[feed_engine] notification verdict could not be persisted "
                "for execution %s: %s (verdict=%s)", exec_db_id, exc, verdict)
    return verdict
