/**
 * API — Feed File Generation (Phase 76)
 */
import { safeFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

// ── Run Now preflight (backend feed_api.py, 2026-09-27) ─────────────────
/** One dependency's verdict for the preflighted business date, in the
 *  gate's own words. */
export interface FeedRunPreflightVerdict {
  dependency_name: string;
  business_date: string;
  /** 'met' | 'not_met' | 'could_not_tell' | 'not_expected' (open: a newer
   *  backend may add a word and the dialog must still render it). */
  verdict: string;
  action: string | null;
  reason: string;
  asserted: boolean;
  satisfies: boolean;
  sources?: { kind: string; verdict: string; reason: string | null }[] | null;
}
export interface FeedRunPreflight {
  feed_id: number;
  feed_name?: string | null;
  etl_id: number;
  business_date: string;
  has_dependencies: boolean;
  admitted: boolean;
  asserted: boolean;
  verdicts: FeedRunPreflightVerdict[];
  blocking: string[];
  /** Why the gate could not be read, when it could not (then a reason is
   *  required too: a run that cannot see its gate is not known to be met). */
  unavailable: string | null;
  override_required: boolean;
  /** Whether the CALLER may run this feed (owner / group / admin). */
  can_run?: boolean;
}
export interface RunNowOptions {
  business_date?: string;
  /** 2026-09-27 -- runs the whole chain and delivers NOTHING; a
   *  separate menu action, never the day's run, no override reason. */
  dry_run?: boolean;
  override_reason_category?: string;
  override_reason?: string;
}

// ── Definition version history (2026-09-27) ──────────────────────────────
export interface FeedVersionSummary {
  id: number;
  feed_config_id: number;
  version: number;
  definition_hash: string;
  git_commit: string | null;
  image_tag: string | null;
  created_at: string | null;
  created_by: string | null;
  /** Top-level fields that differ from the previous version (no values). */
  changed_fields: string[];
}

export interface FeedVersionsResponse {
  feed_id: number;
  count: number;
  /** Newest first. */
  items: FeedVersionSummary[];
}

export interface FeedVersionRow extends Omit<FeedVersionSummary, 'changed_fields'> {
  /** Secrets masked exactly as GET /api/feeds/{id} masks them. */
  definition: Record<string, any>;
}

export interface FeedVersionChange {
  field: string;
  /** ``field`` or ``field.subkey`` for a nested change. */
  path: string;
  kind: 'added' | 'removed' | 'changed';
  from: any;
  to: any;
}

export interface FeedVersionDiffResponse {
  feed_id: number;
  from_version: number;
  to_version: number;
  count: number;
  changes: FeedVersionChange[];
}

// ── Schedule-preview response (backend feed_schedule_preview_api.py) ──────
// Kept as a discriminated union so a consumer CANNOT read `due_dates`
// off an event-driven answer without the compiler objecting.
export interface SchedulePreviewCalendarBlock {
  name: string | null;
  source: 'request' | 'declaration' | 'feed' | 'none';
  resolved: boolean;
  weekend_days?: number[];
  holiday_count?: number;
  note?: string;
}
export interface SchedulePreviewScheduleBlock {
  kind: string;
  workday_n?: number;
  cron_expression?: string;
  note?: string;
}
export interface SchedulePreviewWindow {
  start: string;
  end: string;
  days: number;
}
export type SchedulePreviewResponse =
  | {
      mode: 'dates';
      due_dates: string[];
      /** 2026-10-13 -- each due run day with the date its data is for */
      tasks?: { runs_on: string; business_date: string }[];
      count_requested: number;
      count_found: number;
      window_exhausted: boolean;
      window: SchedulePreviewWindow;
      schedule: SchedulePreviewScheduleBlock;
      calendar: SchedulePreviewCalendarBlock;
    }
  | {
      mode: 'no_due_dates_in_window';
      message: string;
      window: SchedulePreviewWindow;
      schedule: SchedulePreviewScheduleBlock;
      calendar: SchedulePreviewCalendarBlock;
    }
  | {
      mode: 'event_driven';
      upstream_feed: string;
      message: string;
      schedule: SchedulePreviewScheduleBlock;
      calendar: SchedulePreviewCalendarBlock;
    };

// ── Draft resolution (backend api/feed_api.py::resolve_feed_draft) ───────
export interface DraftPredicate {
  column: string; qualified: string; operator: string; literal: string;
  kind: 'string' | 'number' | 'date'; wrapper: string | null; occurrences: number;
  text: string; bound_to: string | null; format: string | null;
}
export interface DraftSide {
  side: 'primary' | 'secondary'; status: string; message: string;
  source_name: string | null; connection_id: number | null; connection_name: string | null;
  sql: string; predicates_readable: boolean; predicates: DraftPredicate[];
}
export interface DraftMerge {
  rule: string; known: boolean; reason?: string; refused?: string;
  columns?: number; output_columns?: string[]; primary_only?: string[];
  secondary_only?: string[]; case_renames?: string[]; type_promotions?: string[];
}
export interface TokenBinding {
  side: 'primary' | 'secondary'; column: string; literal: string; token: string;
  format?: string | null;
}
export interface FeedDraftResolution {
  is_cross: boolean; combine_mode: string | null;
  primary: DraftSide; secondary: DraftSide | null; merge: DraftMerge | null;
  inherited: { carries_second_side: boolean | null; secondary_connection_id?: number;
               combine_mode?: string; rule?: string; feed_overrides?: boolean;
               refusal?: string; reason?: string };
  bindings: Array<TokenBinding & { matched: boolean; reason?: string; occurrences?: number }>;
  bindings_problem: string | null;
  tokens: { date_tokens: string[]; parameters: string[]; date_formats: string[] };
  /** every {TOKEN} the query uses, by kind (2026-10-12): a calendar date, an
   *  upstream-message value (per environment), or a parameter needing a value */
  query_tokens?: QueryToken[];
}
export interface QueryToken {
  name: string; format: string | null; kind: 'date' | 'message' | 'parameter';
  sides: string[]; value: string | number | boolean | null; has_value: boolean;
}

const feeds = {
  // ── Feed Configs CRUD ─────────────────────────────────────────────────────
  createFeed: (data: {
    name: string;
    source_type: string;
    source_id: number;
    connection_id?: number;
    query_params?: Record<string, any>;
    output_format?: string;
    output_filename_template?: string;
    output_options?: Record<string, any>;
    destination_type?: string;
    destination_config?: Record<string, any>;
    execution_backend?: string;
    backend_config?: Record<string, any>;
    size_threshold_rows?: number;
    schedule_enabled?: boolean;
    cron_expression?: string;
    timezone?: string;
    notify_on_success?: boolean;
    notify_on_failure?: boolean;
    notify_emails?: string;
    notify_webhook?: string;
    max_retries?: number;
    retry_delay_seconds?: number;
  }) =>
    safeFetch('/api/feeds', { method: 'POST', body: safeStringify(data) }),
  /** A NEW feed made in the full form from ``sourceId``'s settings: the server
   *  fills a secret shown as *** from that feed (never sent to the browser). */
  createFeedFromClone: (sourceId: number, data: Record<string, any>) =>
    safeFetch(`/api/feeds?clone_of=${encodeURIComponent(String(sourceId))}`,
              { method: 'POST', body: safeStringify(data) }),

  listFeeds: (params?: { source_type?: string; is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.source_type) qs.set('source_type', params.source_type);
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const query = qs.toString();
    return safeFetch(`/api/feeds${query ? '?' + query : ''}`);
  },

  getFeed: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}`),

  // 2026-10-11 -- what a feed DRAFT would run (core/feed/authoring_draft.py):
  // each side's SQL and literal predicates, the merge-by-name disclosure,
  // whether the primary saved query carries its own second side, and every
  // token binding's verdict.  Read-only; the form calls it while typing.
  resolveFeedDraft: (draft: Record<string, any>): Promise<FeedDraftResolution> =>
    safeFetch('/api/feeds/resolve-draft', { method: 'POST', body: safeStringify(draft) }),

  /** ``applyFrom`` (2026-10-12): WHEN a definition change applies --
   *  'next_run' or a business date (YYYY-MM-DD); omitted = the feed's rule. */
  updateFeed: (feedId: number, data: Record<string, any>, opts?: { applyFrom?: string }) =>
    safeFetch(`/api/feeds/${feedId}${opts?.applyFrom ? `?apply_from=${encodeURIComponent(opts.applyFrom)}` : ''}`,
              { method: 'PUT', body: safeStringify(data) }),

  deleteFeed: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}`, { method: 'DELETE' }),

  // 2026-08-22 — options for the per-feed Execution Backend picker,
  // served from the router's own registry (core.feed.backend_router.
  // VALID_BACKENDS + core.feed.source_plan.BACKEND_CAPABILITIES) so the
  // UI never carries a hand-kept twin of the backend list.
  getBackendOptions: (): Promise<{
    options: {
      value: string;
      label: string;
      available: boolean;
      availability_detail?: string | null;
      capabilities?: Record<string, boolean>;
    }[];
  }> =>
    safeFetch('/api/feeds/backend-options'),

  // ── Execution ─────────────────────────────────────────────────────────────
  //
  // Phase 132.38 — ``queryParams`` lets the dashboard caller pass
  // per-trigger overrides for Dynamic WHERE rows the publisher declared
  // on the feed config.  Same primitive Published Views uses; Static
  // rows remain locked.  Optional — legacy callers that pass nothing
  // get the unchanged manual-trigger behaviour.
  // 2026-09-27 -- ``opts``: the Run Now PREFLIGHT (the business date the
  // dialog showed the gate for, and the reason when the gate said not
  // met -- the same vocabulary as a dependency skip), or ``dry_run``
  // (the whole chain runs and NOTHING is delivered; the produced file is
  // a one-day Download Centre item and the run is marked ``dry_run``).
  // Omitted = the legacy no-body call.
  executeFeed: (feedId: number, queryParams?: Record<string, any>,
                opts?: RunNowOptions): Promise<{
    detail: string; feed_id: number; execution_id: string;
    execution_db_id: number; trigger_type: string; dry_run?: boolean;
    dependencies_overridden?: Record<string, any> | null;
  }> => {
    const body: Record<string, any> = {};
    if (queryParams) body.query_params = queryParams;
    if (opts?.dry_run) body.dry_run = true;
    if (opts?.business_date) body.business_date = opts.business_date;
    if (opts?.override_reason_category) body.override_reason_category = opts.override_reason_category;
    if (opts?.override_reason) body.override_reason = opts.override_reason;
    return safeFetch(`/api/feeds/${feedId}/execute`, {
      method: 'POST',
      body: Object.keys(body).length ? safeStringify(body) : undefined,
    });
  },

  /** What a Run Now for `businessDate` (default today UTC) would find at
   *  the dependency gate -- each dependency's verdict and reason, from
   *  THE gate (2026-09-27).  `override_required` = a reason is needed. */
  getFeedRunPreflight: (feedId: number, businessDate?: string): Promise<FeedRunPreflight> =>
    safeFetch(`/api/feeds/${feedId}/run-preflight${businessDate ? `?business_date=${encodeURIComponent(businessDate)}` : ''}`),

  // ── Definition version history (2026-09-27, api/feed_versions_api.py) ──
  //
  // A version is minted by every save (PUT) and by every run's claim-time
  // pin, deduplicated by hash.  ``version`` is the feed's monotonic number.
  listFeedVersions: (feedId: number): Promise<FeedVersionsResponse> =>
    safeFetch(`/api/feeds/${feedId}/versions`),

  getFeedVersion: (feedId: number, version: number): Promise<FeedVersionRow> =>
    safeFetch(`/api/feeds/${feedId}/versions/${version}`),

  diffFeedVersions: (feedId: number, fromVersion: number, toVersion: number):
      Promise<FeedVersionDiffResponse> =>
    safeFetch(`/api/feeds/${feedId}/versions/diff?from_version=${fromVersion}`
              + `&to_version=${toVersion}`),

  /** Goes through the ONE update route; a retired feed answers 409. */
  restoreFeedVersion: (feedId: number, version: number): Promise<{
    feed_id: number; restored_version: number; now_version: number | null;
    restored_fields: string[]; feed: Record<string, any>;
  }> =>
    safeFetch(`/api/feeds/${feedId}/versions/${version}/restore`,
              { method: 'POST' }),

  enableSchedule: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/enable-schedule`, { method: 'POST' }),

  disableSchedule: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/disable-schedule`, { method: 'POST' }),

  // ── Schedule preview (2026-09-02, backend/api/feed_schedule_preview_api.py)
  //
  // Next due dates for the UNSAVED declaration, computed server-side
  // with the scheduler's own parse_schedule + due_on + BusinessCalendar
  // — so the preview cannot drift from runtime.  THREE response shapes,
  // discriminated by `mode` (an event-driven feed is NEVER an empty
  // date list, and "no due day in the window" must not look
  // event-driven either):
  //   "dates"                  — due_dates non-empty;
  //   "no_due_dates_in_window" — NO due_dates key, carries a message;
  //   "event_driven"           — NO due_dates, NO window; carries
  //                              upstream_feed + a message.
  // Errors: 422 with the parser's own message (malformed declaration,
  // bad start_date, calendar NAMED but unresolved), 404 unknown
  // feed_id, 503 when a named calendar could not be READ (the server
  // refuses to preview against a calendar it never read).
  //
  // retryOnTimeout=false: the preview is advisory and re-fires on the
  // next edit; stacked timeout retries would only race newer requests.
  previewSchedule: (
    declaration: Record<string, any>,
    calendarName?: string,
  ): Promise<SchedulePreviewResponse> => {
    const qs = new URLSearchParams({ declaration: JSON.stringify(declaration) });
    if (calendarName) qs.set('calendar_name', calendarName);
    return safeFetch(`/api/feeds/schedule-preview?${qs.toString()}`, {
      retryOnTimeout: false,
    });
  },

  testDestination: (feedId: number) =>
    safeFetch(`/api/feeds/${feedId}/test-destination`, { method: 'POST' }),

  quickCreateFeed: (data: {
    source_type: string;
    source_id: number;
    connection_id?: number;
    output_format?: string;
    destination_type?: string;
    destination_config?: Record<string, any>;
    execute_now?: boolean;
  }) =>
    safeFetch('/api/feeds/quick-create', { method: 'POST', body: safeStringify(data) }),

  // ── History ───────────────────────────────────────────────────────────────
  listFeedExecutions: (feedId: number, limit = 50, offset = 0) =>
    safeFetch(`/api/feeds/${feedId}/executions?limit=${limit}&offset=${offset}`),

  getFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}`),

  retryFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/retry`, { method: 'POST' }),

  cancelFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/cancel`, { method: 'POST' }),

  downloadFeedExecution: (execId: number) =>
    safeFetch(`/api/feed-executions/${execId}/download`),

  // ── Webhook ───────────────────────────────────────────────────────────────
  webhookFeedComplete: (data: {
    execution_id: string;
    state: string;
    dag_id?: string;
    batch_id?: string;
    error?: string;
    output_path?: string;
  }) =>
    safeFetch('/api/webhooks/feed-complete', { method: 'POST', body: safeStringify(data) }),

  // ── Admin Config ──────────────────────────────────────────────────────────
  getFeedGenerationConfig: () =>
    safeFetch('/api/admin/feed-generation/config'),

  updateFeedGenerationConfig: (data: Record<string, any>) =>
    safeFetch('/api/admin/feed-generation/config', { method: 'PUT', body: safeStringify(data) }),

  getFeedBackends: () =>
    safeFetch('/api/admin/feed-generation/backends'),

  resetFeedBackend: (name: string) =>
    safeFetch(`/api/admin/feed-generation/backends/${name}/reset`, { method: 'POST' }),

  // ── Phase 130: Calendars + Holidays + Today's runs + SOD/SLA ─────────────
  listFeedCalendars: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/feed-calendars${q ? '?' + q : ''}`);
  },

  // Phase 4 (2026-08-23): read-only ACTIVE calendar list for the feed
  // setup form — /feeds is open to analysts, but the admin route above
  // 403s for them and the picker silently emptied.
  listFeedCalendarsReadonly: () => safeFetch('/api/feed-calendars'),

  createFeedCalendar: (data: {
    name: string;
    description?: string;
    weekend_days?: number[];
    is_active?: boolean;
  }) =>
    safeFetch('/api/admin/feed-calendars', {
      method: 'POST', body: safeStringify(data),
    }),

  getFeedCalendar: (id: number) =>
    safeFetch(`/api/admin/feed-calendars/${id}`),

  updateFeedCalendar: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/feed-calendars/${id}`, {
      method: 'PUT', body: safeStringify(data),
    }),

  deleteFeedCalendar: (id: number) =>
    safeFetch(`/api/admin/feed-calendars/${id}`, { method: 'DELETE' }),

  addFeedHoliday: (calendarId: number, data: {
    holiday_date: string; holiday_name?: string; recurring?: boolean;
  }) =>
    safeFetch(`/api/admin/feed-calendars/${calendarId}/holidays`, {
      method: 'POST', body: safeStringify(data),
    }),

  deleteFeedHoliday: (holidayId: number) =>
    safeFetch(`/api/admin/feed-holidays/${holidayId}`, { method: 'DELETE' }),

  listTodaysFeedRuns: (params?: {
    business_date?: string; status?: string;
    limit?: number; offset?: number;
  }) => {
    const qs = new URLSearchParams();
    if (params?.business_date) qs.set('business_date', params.business_date);
    if (params?.status)        qs.set('status', params.status);
    if (params?.limit  != null) qs.set('limit',  String(params.limit));
    if (params?.offset != null) qs.set('offset', String(params.offset));
    const q = qs.toString();
    return safeFetch(`/api/feed-runs${q ? '?' + q : ''}`);
  },

  runSodNow: (business_date?: string,
              scope?: { template_id?: number; feed_ids?: number[]; background?: boolean }) => {
    // Backend reads business_date as a query parameter (FastAPI signature).
    // Sending it in the JSON body silently no-ops the date — caller would
    // see today's runs created instead of the requested date.  Always send
    // as query string when provided.  2026-10-11: template_id / feed_ids
    // scope the pass; over the sync threshold (or background=true) the
    // answer is 202 with { job, status_url } -- poll sodRunNowStatus.
    const qs = new URLSearchParams();
    if (business_date) qs.set('business_date', business_date);
    if (scope?.template_id != null) qs.set('template_id', String(scope.template_id));
    if (scope?.feed_ids?.length) qs.set('feed_ids', scope.feed_ids.join(','));
    if (scope?.background != null) qs.set('background', String(scope.background));
    const q = qs.toString();
    return safeFetch(`/api/admin/feeds/sod/run-now${q ? '?' + q : ''}`, { method: 'POST' });
  },

  sodRunNowStatus: (job_id: string) =>
    safeFetch(`/api/admin/feeds/sod/run-now/${encodeURIComponent(job_id)}`),

  sodGaps: (params?: { feed_id?: number; days?: number; include_resolved?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.feed_id != null) qs.set('feed_id', String(params.feed_id));
    if (params?.days != null) qs.set('days', String(params.days));
    if (params?.include_resolved) qs.set('include_resolved', 'true');
    const q = qs.toString();
    return safeFetch(`/api/admin/feeds/sod/gaps${q ? '?' + q : ''}`);
  },

  /** 2026-10-11 -- the dependency-message monitor: every landed upstream
   *  message (Kafka topic AND the QS_KAFKA_MESSAGE watcher), its OG fields,
   *  its resolution and the feeds it holds / released. */
  dependencyMessages: (params?: { resolution?: string; days?: number; limit?: number; page?: number; page_size?: number }) => {
    const qs = new URLSearchParams();
    if (params?.resolution) qs.set('resolution', params.resolution);
    if (params?.days != null) qs.set('days', String(params.days));
    if (params?.limit != null) qs.set('limit', String(params.limit));
    if (params?.page != null) qs.set('page', String(params.page));
    if (params?.page_size != null) qs.set('page_size', String(params.page_size));
    const q = qs.toString();
    return safeFetch(`/api/admin/feeds/dependency-messages${q ? '?' + q : ''}`);
  },

  /** 2026-10-11 -- new system entities a COMPLETE message named, and what
   *  became of them (auto-onboarding from the template its DATA_SOURCE names). */
  onboardingRequests: (status?: string, page = 1, pageSize = 50) =>
    safeFetch(`/api/feed-templates/onboarding?page=${page}&page_size=${pageSize}${status ? '&status=' + encodeURIComponent(status) : ''}`),

  /** 2026-10-12 (owner R2) -- files the row-count check HELD instead of
   *  delivering, and the release group's two decisions. */
  varianceHolds: (params?: { status?: string; business_date?: string; feed_config_id?: number; page?: number; page_size?: number }) => {
    const qs = new URLSearchParams();
    if (params?.page != null) qs.set('page', String(params.page));
    if (params?.page_size != null) qs.set('page_size', String(params.page_size));
    if (params?.status) qs.set('status', params.status);
    if (params?.business_date) qs.set('business_date', params.business_date);
    if (params?.feed_config_id != null) qs.set('feed_config_id', String(params.feed_config_id));
    const q = qs.toString();
    return safeFetch(`/api/feed-variance-holds${q ? '?' + q : ''}`);
  },
  /** 2026-10-12 (owner R1) -- the OTG-style dashboard: the date's tasks
   *  grouped by the defined Feed Groups, and one task's dependency cards. */
  /** 2026-10-13 -- the feed's whole configuration in words (sections of
   *  label / value rows), its calendar and the latest saved version. */
  feedSummary: (feedId: number) => safeFetch(`/api/feeds/${feedId}/summary`),
  feedDashboard: (params: { business_date?: string; run_date?: string; search?: string; status?: string;
                            page?: number; page_size?: number; group_by?: string }) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== '') qs.set(k, String(v)); });
    const q = qs.toString();
    return safeFetch(`/api/feed-dashboard${q ? '?' + q : ''}`);
  },
  /** 2026-10-12 (owner R4) -- watched Iceberg tables, each new commit's
   *  inspection, and the feeds it released / still holds. */
  icebergCommits: (days = 7, page = 1, pageSize = 50) =>
    safeFetch(`/api/admin/feeds/iceberg-commits?days=${days}&page=${page}&page_size=${pageSize}`),
  feedDashboardTask: (feedId: number, businessDate: string) =>
    safeFetch(`/api/feed-dashboard/task?feed_id=${feedId}&business_date=${encodeURIComponent(businessDate)}`),
  varianceHoldPreview: (holdId: number, lines = 20) =>
    safeFetch(`/api/feed-variance-holds/${holdId}/preview?lines=${lines}`),
  releaseVarianceHold: (holdId: number, reason: string) =>
    safeFetch(`/api/feed-variance-holds/${holdId}/release`, {
      method: 'POST', body: safeStringify({ reason }), retryOnTimeout: false, timeoutMs: 600_000 }),
  /** 2026-10-12 -- who, besides an admin and the feed's owner, may decide a
   *  held file: a user group mapped at global / feed group / template / feed. */
  holdApprovers: () => safeFetch('/api/feed-hold-approvers'),
  addHoldApprover: (body: { scope: string; scope_id: number | null; user_group_id: number }) =>
    safeFetch('/api/feed-hold-approvers', { method: 'POST', body: safeStringify(body) }),
  deleteHoldApprover: (id: number) =>
    safeFetch(`/api/feed-hold-approvers/${id}`, { method: 'DELETE' }),
  rejectVarianceHold: (holdId: number, reason: string) =>
    safeFetch(`/api/feed-variance-holds/${holdId}/reject`, {
      method: 'POST', body: safeStringify({ reason }) }),

  /** 2026-10-12 -- re-run ONLY the side that failed, reusing the side that
   *  succeeded (its kept rows are verified again when the run executes). */
  /** 2026-10-12 -- a delivered run superseded by a newer upstream version:
   *  the person decides (regenerate / keep) with a reason. */
  resolveRegeneration: (decisionId: number, resolution: 'regenerate' | 'no_regeneration', reason: string) =>
    safeFetch(`/api/feed-regeneration-decisions/${decisionId}/resolve`, {
      method: 'POST', body: safeStringify({ resolution, reason }) }),
  /** 2026-10-12 -- answer a re-run hold / restatement / superseded delivery
   *  in ONE server action (core/feed/restatement.py::answer): who may (the
   *  hold rule), the reason, the re-queue, the alert cleared. */
  answerDecision: (decisionId: number, action: 'rerun' | 'keep', reason: string) =>
    safeFetch(`/api/feed-regeneration-decisions/${decisionId}/answer`, {
      method: 'POST', body: safeStringify({ action, reason }), retryOnTimeout: false }),
  /** the feed alerts (one per problem) and where each went -- bell / e-mail / Netcool */
  feedAlerts: (params: { feed_id?: number; business_date?: string; status?: 'open' | 'cleared'; limit?: number }) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v != null) q.set(k, String(v)); });
    return safeFetch(`/api/feed-alerts?${q.toString()}`);
  },
  /** WHEN each saved definition change applies (core/feed/definition_timeline.py) */
  definitionTimeline: (feedId: number) => safeFetch(`/api/feeds/${feedId}/definition-timeline`),
  /** the alerting + restatement vocabulary: DATA an admin edits */
  restatementPolicies: () => safeFetch('/api/admin/feed-restatement-policies'),
  putRestatementPolicy: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-restatement-policies', { method: 'PUT', body: safeStringify(body) }),
  deleteRestatementPolicy: (id: number) =>
    safeFetch(`/api/admin/feed-restatement-policies/${id}`, { method: 'DELETE' }),
  feedAlertKinds: () => safeFetch('/api/admin/feed-alert-kinds'),
  putFeedAlertKind: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-alert-kinds', { method: 'PUT', body: safeStringify(body) }),
  /** the upstream-message vocabulary: DATA an admin edits (2026-10-12) */
  feedMessageFields: () => safeFetch('/api/admin/feed-message-fields'),
  putFeedMessageField: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-message-fields', { method: 'PUT', body: safeStringify(body) }),
  feedEnvironments: () => safeFetch('/api/admin/feed-environments'),
  putFeedEnvironment: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-environments', { method: 'PUT', body: safeStringify(body) }),
  feedMessageTokens: () => safeFetch('/api/admin/feed-message-tokens'),
  putFeedMessageToken: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-message-tokens', { method: 'PUT', body: safeStringify(body) }),
  feedAlertRoutes: () => safeFetch('/api/admin/feed-alert-routes'),
  addFeedAlertRoute: (body: Record<string, any>) =>
    safeFetch('/api/admin/feed-alert-routes', { method: 'POST', body: safeStringify(body) }),
  deleteFeedAlertRoute: (id: number) =>
    safeFetch(`/api/admin/feed-alert-routes/${id}`, { method: 'DELETE' }),
  failedSideOffer: (runId: number) => safeFetch(`/api/feed-runs/${runId}/rerun-failed-side`),
  rerunFailedSide: (runId: number) =>
    safeFetch(`/api/feed-runs/${runId}/rerun-failed-side`, { method: 'POST', retryOnTimeout: false }),

  cancelFeedRun: (runId: number) =>
    safeFetch(`/api/feed-runs/${runId}/cancel`, { method: 'POST' }),

  rerunFeedRun: (runId: number, opts?: { backend?: 'native' | 'airflow' }) => {
    const qs = opts?.backend ? `?backend=${encodeURIComponent(opts.backend)}` : '';
    return safeFetch(`/api/feed-runs/${runId}/rerun${qs}`, { method: 'POST' });
  },

  bulkRerunFeedRuns: (data: {
    business_date?: string;
    statuses?: string[];
    run_ids?: number[];
  }, opts?: { backend?: 'native' | 'airflow' }) => {
    const qs = opts?.backend ? `?backend=${encodeURIComponent(opts.backend)}` : '';
    return safeFetch(`/api/feed-runs/bulk-rerun${qs}`, {
      method: 'POST', body: safeStringify(data),
    });
  },

  // Phase 130 hotfix-13 — backend override admin
  getFeedBackendOverride: () =>
    safeFetch('/api/admin/feed-generation/backend-override') as Promise<{
      value: string;
      valid_values: string[];
      persisted: { updated_by?: string | null; updated_at?: string | null } | null;
    }>,

  slaSweepNow: () =>
    safeFetch('/api/admin/feeds/sla/sweep-now', { method: 'POST' }),

  // ── Phase 130 hotfix-4 — Control File Formats ─────────────────────────
  listControlFileFormats: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/feed-control-file-formats${q ? '?' + q : ''}`);
  },

  // Phase 4 (2026-08-23): read-only ACTIVE format list for the feed
  // setup form — the admin route above 403s for analysts and the picker
  // silently emptied.
  listControlFileFormatsReadonly: () => safeFetch('/api/feed-control-file-formats'),

  // 2026-10-22 -- the control file a run of this DRAFT feed would write, rendered
  // by the run's own code over a 3-row dummy data file
  previewControlFile: (draft: Record<string, any>) =>
    safeFetch('/api/feed-control-file-formats/preview', {
      method: 'POST', body: safeStringify(draft),
    }),

  createControlFileFormat: (data: Record<string, any>) =>
    safeFetch('/api/admin/feed-control-file-formats', {
      method: 'POST', body: safeStringify(data),
    }),

  getControlFileFormat: (id: number) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`),

  updateControlFileFormat: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`, {
      method: 'PUT', body: safeStringify(data),
    }),

  deleteControlFileFormat: (id: number) =>
    safeFetch(`/api/admin/feed-control-file-formats/${id}`, { method: 'DELETE' }),

  seedDefaultControlFileFormats: () =>
    safeFetch('/api/admin/feed-control-file-formats/seed-defaults', { method: 'POST' }),

  listChecksumAlgorithms: () =>
    safeFetch('/api/admin/feed-control-file-formats/algorithms/list'),

  // ── Phase 130 hotfix-7 — Entitlement (User) Groups ───────────────────
  listUserGroups: (params?: { is_active?: boolean }) => {
    const qs = new URLSearchParams();
    if (params?.is_active !== undefined) qs.set('is_active', String(params.is_active));
    const q = qs.toString();
    return safeFetch(`/api/admin/user-groups${q ? '?' + q : ''}`);
  },

  createUserGroup: (data: { name: string; description?: string; is_active?: boolean }) =>
    safeFetch('/api/admin/user-groups', { method: 'POST', body: safeStringify(data) }),

  getUserGroup: (id: number) =>
    safeFetch(`/api/admin/user-groups/${id}`),

  updateUserGroup: (id: number, data: Record<string, any>) =>
    safeFetch(`/api/admin/user-groups/${id}`, { method: 'PUT', body: safeStringify(data) }),

  deleteUserGroup: (id: number) =>
    safeFetch(`/api/admin/user-groups/${id}`, { method: 'DELETE' }),

  addUserGroupMember: (gid: number, data: { username: string; role_in_group?: string }) =>
    safeFetch(`/api/admin/user-groups/${gid}/members`, {
      method: 'POST', body: safeStringify(data),
    }),

  removeUserGroupMember: (gid: number, username: string) =>
    safeFetch(`/api/admin/user-groups/${gid}/members/${encodeURIComponent(username)}`, {
      method: 'DELETE',
    }),

  listMyUserGroups: () => safeFetch('/api/user-groups/my'),

  // ── 2026-10-10 -- feed TEMPLATES: one parameterised definition + a
  // matrix -> N feeds through the ordinary authoring routes, idempotently
  // (backend api/feed_template_api.py).  The report names every row's
  // outcome: created / updated / unchanged / conflicts / refused /
  // retired / orphaned.
  listFeedTemplates: () => safeFetch('/api/feed-templates'),
  getFeedTemplate: (id: number) => safeFetch(`/api/feed-templates/${id}`),
  listFeedTemplateMembers: (id: number) => safeFetch(`/api/feed-templates/${id}/members`),
  // 2026-10-10: an apply over SYNC_APPLY_MAX_ROWS rows (or background: true)
  // answers 202 with ``job``; this is the poll (state, done/total, counts,
  // and the report once completed -- from any pod).
  getFeedTemplateApplyStatus: (id: number) =>
    safeFetch(`/api/feed-templates/${id}/apply-status`, { retryOnTimeout: false }),
  createFeedTemplate: (data: {
    name: string; description?: string; parameters: string[];
    feed: Record<string, any>; dependencies?: Record<string, any>[];
    matrix: Record<string, any>[]; dry_run?: boolean; retire_missing?: boolean;
  }) => safeFetch('/api/feed-templates', { method: 'POST', body: safeStringify(data) }),
  updateFeedTemplate: (id: number, data: {
    description?: string; parameters?: string[]; feed?: Record<string, any>;
    dependencies?: Record<string, any>[]; matrix?: Record<string, any>[];
    dry_run?: boolean; retire_missing?: boolean;
  }) => safeFetch(`/api/feed-templates/${id}`, { method: 'PUT', body: safeStringify(data) }),
  applyFeedTemplate: (id: number, data?: {
    matrix?: Record<string, any>[]; dry_run?: boolean; retire_missing?: boolean;
  }) => safeFetch(`/api/feed-templates/${id}/apply`, {
    method: 'POST', body: safeStringify(data || {}),
  }),
  deleteFeedTemplate: (id: number, deleteMembers = false) =>
    safeFetch(`/api/feed-templates/${id}?delete_members=${deleteMembers ? 'true' : 'false'}`,
              { method: 'DELETE' }),
};

export default feeds;
