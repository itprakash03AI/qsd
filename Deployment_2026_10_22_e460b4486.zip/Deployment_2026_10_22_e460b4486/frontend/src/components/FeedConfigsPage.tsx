import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';
import { ReturnTrip, returnTripFrom, returnState } from '../utils/returnTo';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Chip, Tooltip, Stack, Dialog, DialogTitle,
  DialogContent, DialogActions, TextField, Alert, CircularProgress,
  Select, MenuItem, FormControl, InputLabel, FormControlLabel, Switch,
  Stepper, Step, StepLabel, Collapse, Divider, Autocomplete,
  FormHelperText, TablePagination, InputAdornment, Checkbox,
} from '@mui/material';
import {
  Add as AddIcon, Delete as DeleteIcon, Refresh as RefreshIcon,
  PlayArrow as RunIcon, Pause as PauseIcon, Schedule as ScheduleIcon,
  Edit as EditIcon, ExpandMore as ExpandIcon, ExpandLess as CollapseIcon,
  CheckCircle as SuccessIcon, Error as ErrorIcon, HourglassTop as PendingIcon,
  Cancel as CancelIcon, Replay as RetryIcon, Download as DownloadIcon,
  NetworkCheck as TestIcon, InfoOutlined as InfoIcon,
  AccessTime as SodIcon, NotificationsActive as SlaIcon,
  Code as PreviewSqlIcon, ContentCopy as CopyIcon,
  AccountTree as DataFlowIcon,
  ArrowUpward as MoveUpIcon, ArrowDownward as MoveDownIcon,
  History as BackfillIcon, LocalShipping as DeliveryIcon,
  VerifiedUser as LifecycleIcon, FileCopy as CloneIcon,
  PlaylistPlay as StepPlanIcon,
  // 2026-09-27 -- dry run + definition version history
  Science as DryRunIcon, Restore as VersionsIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { safeFetch } from '../services/api/core';
import type {
  FeedDraftResolution, TokenBinding,
  RunNowOptions,
  SchedulePreviewResponse, SchedulePreviewCalendarBlock,
} from '../services/api/feeds';
import type {
  ArrivalSourcesVocabulary, DeclaredArrivalSource,
} from '../services/api/feedDependencies';

/** One declared arrival source in plain words (2026-09-27). */
const describeArrivalSource = (s: DeclaredArrivalSource): string => {
  if (s.kind === 'iceberg_commit') {
    // 2026-10-11 -- a partition the commit must be OF (per-entity feeds on one table)
    const part = s.partition_values && Object.keys(s.partition_values).length
      ? ` for partition ${Object.entries(s.partition_values).map(([k, v]) => `${k}=${v}`).join(', ')}`
      : '';
    return `Iceberg table ${s.table}.${s.date_column} has data for the date${part} (connection ${s.connection_id})`;
  }
  if (s.kind === 'file') {
    const count = s.min_files ?? 1;
    const what = count > 0 ? `${count}+ file(s) ${s.pattern || '*'}` : 'nothing but the control file';
    return `Files landed: ${what} under ${s.path}${s.control_file ? ` + control ${s.control_file}` : ''} (connection ${s.connection_id})`;
  }
  // 2026-10-08 -- a Kafka source may name its topic: two topics on one
  // dependency are two sources ("ALL of: kafka on topic a; kafka on topic b").
  if (s.kind === 'kafka' && s.topic) {
    return `Kafka message on topic ${s.topic}`;
  }
  // 2026-10-11 -- a row of an upstream's Oracle table (the OG QS_KAFKA_MESSAGE
  // landing table), resolved by the table's configured rules.
  if (s.kind === 'oracle_table') {
    return `Row in Oracle table ${s.table} (connection ${s.connection_id})`;
  }
  return s.kind;
};

/** Connection types a `file` arrival source can list (2026-10-07; the
 *  backend's core/feed/file_arrival_source.py refuses any other). */
const FILE_SOURCE_CONNECTION_TYPES = ['s3', 's3_minio', 's3_compatible', 'local'];

/** The `file` declaration from the form fields; empty optionals are omitted
 *  so the server applies its own defaults (pattern *, 1 file). */
const fileSourceSpec = (connId: number, path: string, pattern: string,
  control: string, minFiles: string): DeclaredArrivalSource => {
  const spec: DeclaredArrivalSource = { kind: 'file', connection_id: connId, path: path.trim() };
  if (pattern.trim()) spec.pattern = pattern.trim();
  if (control.trim()) spec.control_file = control.trim();
  if (minFiles.trim() !== '') spec.min_files = Number(minFiles);
  return spec;
};
import { useAuth } from '../context/AuthContext';
import { toArray } from '../utils/toArray';
import { describeCron } from '../utils/describeCron';
import WhereClausesEditor, {
  WhereClauseRow, WHERE_OPERATORS,
} from './common/WhereClausesEditor';
import { SqlColumnExtractor } from './common/extractSqlColumns';
import { fetchPartitionValueOptions } from './common/fetchPartitionValueOptions';
import DynamicWhereOverrideField from './common/DynamicWhereOverrideField';
import ExecutionBackendSelect from './common/ExecutionBackendSelect';
// 2026-09-03 — operator controls (backend api/feed_ops_api.py +
// feed_api.py lifecycle/clone routes)
import FeedBackfillDialog from './FeedBackfillDialog';
import FeedRunNowDialog from './FeedRunNowDialog';
// 2026-10-10 -- N feeds from ONE template + a matrix (POST /api/feed-templates)
import FeedTemplateBulkDialog from './FeedTemplateBulkDialog';
import FeedDeliveryAttemptsDialog from './FeedDeliveryAttemptsDialog';
import FeedLifecycleDialog from './FeedLifecycleDialog';
// 2026-09-27 -- every saved or run definition; field-level diff; restore
// through the ONE update (api/feed_versions_api.py)
import FeedVersionHistoryDialog from './FeedVersionHistoryDialog';
// 2026-09-05 - the step model: what WILL run, with the skips and their reasons
import FeedStepPlanDialog from './FeedStepPlanDialog';
// 2026-09-14 -- the Execution History moved to /feeds/today ("All
// executions" tab); this page keeps one read-only chip per feed.
import {
  ExecutionStatusChip, formatRelative, formatRowCount, formatUtc,
  isLiveStatus, triggerKind, useNowTick, type FeedExecutionRow,
} from './FeedExecutionsPanel';
import { useOptionalWebSocket } from '../context/WebSocketContext';
import SavedQueryPicker from './common/SavedQueryPicker';
import SlaTimeField from './feeds/SlaTimeField';
import { describeLoadError } from '../utils/loadError';
import SftpDestinationFields, { sftpConfigProblems } from './feeds/SftpDestinationFields';
import { STICKY_ACTIONS_SX, TABLE_SCROLL_SX } from './common/stickyActions';
import RowActions from './common/RowActions';
import { previewColumns as fetchPreviewColumns } from './common/sqlPreviewApi';
import type { PartitionValueOptions } from './common/fetchPartitionValueOptions';
// BRD STEP 1 (2026-09-02) — authoring rules mirrored from the backend
// modules that own them (identity.py / partition_shape.py / contract.py).
import {
  validateFeedName, MAX_FEED_NAME_LEN,
  normalizeFeedNameInput, feedNameForSave, FEED_NAME_RULE_HINT,
  parseSlaTime,
  EMPTY_SHAPE_DRAFT, partitionShapeErrors, partitionShapeHints,
  splitColumns, columnsText,
  buildPartitionShape,
  CONTRACT_DEFAULTS, hydrateContractOpts, buildOutputOptions,
  contractErrors, contractUnsupportedHints,
  QUOTING_VALUES, LINE_TERMINATORS, PACKAGING_VALUES, CODEC_VALUES,
  ENCRYPTION_VALUES, CHECKSUM_ALGORITHMS, CHECKSUM_SCOPES,
  SIDECAR_VALUES, DIGEST_LINE_VALUES, SEQUENCING_VALUES,
  REDELIVERY_VALUES, COMMON_ENCODINGS,
  EMPTY_SCHEDULE_DRAFT, WORKDAY_N_MAX, hydrateScheduleDraft,
  scheduleDeclarationErrors, buildScheduleDeclaration,
  DELIVERY_HOP_TARGETS, REQUIRES_AUTO, REQUIRES_INDEPENDENT,
  EMPTY_DELIVERY_CHAIN_DRAFT, emptyDeliveryHop, deliveryHopLabel,
  hydrateDeliveryChainDraft, deliveryChainErrors,
  deliveryHopRenameWarning, buildDeliveryChain,
  EMPTY_ORACLE_DEST_DRAFT, hydrateOracleDestinationDraft,
  oracleDestinationErrors, buildOracleDestinationConfig,
} from './common/feedAuthoringRules';
import type {
  PartitionShapeDraft, ContractOpts, ScheduleDraft, ScheduleKind, BusinessDateRule,
  DeliveryChainDraft, DeliveryHopDraft, DeliveryHopTarget,
  OracleDestinationDraft, OracleDestMode,
} from './common/feedAuthoringRules';

// ── Constants ────────────────────────────────────────────────────────────────

// ── Schedule preview (2026-09-02, GET /api/feeds/schedule-preview) ───────
// Debounce for the preview request: long enough to coalesce typing,
// short enough to feel live.  One request per SETTLED declaration,
// never one per keystroke.
const SCHEDULE_PREVIEW_DEBOUNCE_MS = 400;

type SchedulePreviewState =
  | { phase: 'idle' }
  | { phase: 'pending' }
  | { phase: 'ready'; data: SchedulePreviewResponse }
  | { phase: 'unavailable'; message: string };

/** 'Fri' for '2026-10-30' — UTC-pinned so the viewer's timezone can
 *  never shift the server's date by a day. */
const weekdayOfIso = (iso: string): string => {
  const d = new Date(`${iso}T00:00:00Z`);
  return Number.isNaN(d.getTime())
    ? '' : d.toLocaleDateString('en-US', { weekday: 'short', timeZone: 'UTC' });
};

/** SAY what the dates were computed against — a preview computed with
 *  no calendar is a DIFFERENT claim from one computed against the
 *  feed's holidays. */
const describeSchedulePreviewCalendar = (
  cal: SchedulePreviewCalendarBlock,
): string => {
  if (cal.resolved && cal.name) {
    return `Computed against business calendar '${cal.name}'`
      + (typeof cal.holiday_count === 'number'
        ? ` (${cal.holiday_count} holiday${cal.holiday_count === 1 ? '' : 's'})` : '')
      + '.';
  }
  return 'Computed with NO business calendar — every calendar day counts as '
    + 'a business day. Attach a Business Calendar below for '
    + 'weekend/holiday-aware dates.';
};

const SOURCE_TYPES = ['saved_query', 'published_view', 'sql_file', 'raw_sql'] as const;
const SOURCE_TYPE_LABELS: Record<string, string> = {
  saved_query:    'Saved Query',
  published_view: 'Published View',
  sql_file:       'SQL File',
  raw_sql:        'Raw SQL',
};
const OUTPUT_FORMATS = ['csv', 'parquet', 'json', 'excel'] as const;
const DESTINATION_TYPES = ['local', 's3', 'sftp', 'oracle'] as const;
// 2026-08-22 — the Execution Backend list is no longer a literal here:
// ExecutionBackendSelect drives it from GET /api/feeds/backend-options
// (the router's own registry), so a backend added server-side
// (spark_k8s) appears without a UI change.
// BRD STEP 1 (2026-09-02) — "A FEED IS A FEED".  The six properties an
// author supplies ARE the organising structure of the screen: source,
// schedule, dependencies, shape, contract, delivery.  Everything the
// platform derives (execution lane, gate verdicts, hop plans) stays out
// of the author's way; the remaining engine/entitlement knobs live in a
// final Controls step so no capability of the old editor is lost.
const STEP_LABELS = [
  'Source', 'Schedule', 'Dependencies', 'Shape', 'Contract', 'Delivery',
  'Controls',
];
/** Steps a feed may leave entirely empty -- labelled "Optional". */
const OPTIONAL_STEPS = new Set(['Dependencies', 'Shape']);

// Common IANA timezones — UTC first, then alphabetical.  Browsers since
// Chrome 99 / Safari 15.4 expose Intl.supportedValuesOf('timeZone'), but
// we keep a fallback list so the dropdown is always populated.
const _FALLBACK_TIMEZONES = [
  'UTC', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Europe/Berlin',
  'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney',
];
const TIMEZONES: string[] = (() => {
  try {
    // @ts-ignore — supportedValuesOf isn't in older TS lib defs
    const list: string[] = Intl.supportedValuesOf?.('timeZone') ?? [];
    if (list.length > 0) {
      // Pin UTC at top so it's the default choice
      return ['UTC', ...list.filter(t => t !== 'UTC').sort()];
    }
  } catch { /* fallthrough */ }
  return _FALLBACK_TIMEZONES;
})();

const STATUS_COLORS: Record<string, 'success' | 'error' | 'warning' | 'info' | 'default'> = {
  completed: 'success',
  failed: 'error',
  running: 'info',
  pending: 'warning',
  cancelled: 'default',
};

// ── Interfaces ───────────────────────────────────────────────────────────────

interface FeedConfig {
  id: number;
  name: string;
  // FR-ID-01..03 — `name` is permanent identity (immutable once the feed
  // has run); `display_name` is the editable label.
  display_name?: string | null;
  description: string | null;
  is_active: boolean;
  source_type: string;
  source_id: number;
  connection_id: number | null;
  query_params: Record<string, any> | null;
  output_format: string;
  output_filename_template: string | null;
  // The CONTRACT terms live here (validated by core/feed/contract.py via
  // api/feed_api.py::FEED_OPTION_TO_CONTRACT_TERM).
  output_options?: Record<string, any> | null;
  // Engine tuning the form MERGES into rather than replaces: it also
  // carries spark_job_timeout_seconds, spark_extra_conf and the
  // per-feed backend override, none of which this form owns.
  backend_config?: Record<string, any> | null;
  max_retries?: number | null;
  retry_delay_seconds?: number | null;
  destination_type: string;
  destination_config: Record<string, any>;
  // The DELIVERY chain — ordered hops (core/feed/delivery_hops.py,
  // validated by api/feed_api.py::_refuse_invalid_delivery_chain).
  // Absent/null = the legacy single destination above, untouched.
  delivery_chain?: Array<Record<string, any>> | null;
  execution_backend: string;
  // Phase 131 deep-dive #13 (round 8) — auto-router size threshold
  size_threshold_rows?: number | null;
  last_row_count?: number | null;
  estimated_row_count?: number | null;
  schedule_enabled: boolean;
  cron_expression: string | null;
  timezone: string;
  run_count: number;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  // Phase 130 hotfix-2 — cross-source combine.  Optional: when
  // secondary_connection_id is set the feed pulls primary + secondary
  // sides separately and combines them in DuckDB before delivery.
  secondary_connection_id?: number | null;
  secondary_source_type?: string | null;
  secondary_source_id?: number | null;
  combine_mode?: string | null;          // 'union' | 'join'
  join_config?: Record<string, any> | null;
  // 2026-10-11 -- a saved query's literal predicate bound to a token, per side
  token_bindings?: TokenBinding[] | null;
  control_file_template?: string | null;
  control_file_format_id?: number | null;
}

/** The feed's own scalar parameters -- the {NAME} tokens a binding may name
 *  (core/feed/authoring_draft.py::declared_parameters reads the same keys). */
const scalarFeedParams = (qp: Record<string, any> | null | undefined): Record<string, string> => {
  const out: Record<string, string> = {};
  Object.entries(qp || {}).forEach(([k, v]) => {
    if (k.startsWith('_') || k === 'sql' || k === 'secondary_raw_sql' || k === 'secondary') return;
    if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') out[k] = String(v);
  });
  return out;
};

// Lookup options for the source / connection pickers — populated when
// the dialog opens.  Shape matches what /api/queries, /api/published-views,
// /api/sql-files, /api/connections actually return.
interface ConnectionOption {
  id: number;
  name: string;
  connection_type: string;
}
interface SavedQueryOption {
  id: number;
  name: string;
  description?: string | null;
  query_config?: { connection_id?: number };
}
interface PublishedViewOption {
  id: number;
  name: string;
  slug: string;
  description?: string | null;
  connection_id?: number;
}
interface SqlFileOption {
  id: number;
  name: string;
  description?: string | null;
  connection_id?: number | null;
}

// The execution row shape (FeedExecutionRow) lives in FeedExecutionsPanel.

// ── Latest-execution chip (2026-09-14) ───────────────────────────────────────

type LatestExec =
  | { state: 'loading' }
  | { state: 'error'; error: string }
  | { state: 'ok'; exec: FeedExecutionRow | null };

/** The one read-only fact an author needs on this page: what the feed's
 *  latest execution did.  `never run` is a finding and is rendered as
 *  one -- a blank cell would read as "no runs" when it may mean "could
 *  not load", which is the opposite investigation. */
const LatestExecutionCell: React.FC<{
  latest: LatestExec | undefined;
  feedId: number;
  now: number;
  onRetry: () => void;
}> = ({ latest, feedId, now, onRetry }) => {
  const viewRunsHref = `/feeds/today?feed=${feedId}&tab=executions`;
  const viewRuns = (
    <Button component={RouterLink} to={viewRunsHref} size="small" sx={{ minWidth: 0, px: 0.5, fontSize: '0.7rem' }}
            data-testid={`feed-view-runs-${feedId}`}>
      View runs
    </Button>
  );
  let chip: React.ReactNode;
  if (!latest || latest.state === 'loading') {
    chip = <Chip size="small" variant="outlined" label="loading…" data-testid={`feed-latest-${feedId}`} />;
  } else if (latest.state === 'error') {
    chip = (
      <Tooltip title={`The latest execution could not be read — ${latest.error}. This is not "never run".`}>
        <Chip size="small" color="warning" variant="outlined" label="history unavailable"
              onClick={onRetry} data-testid={`feed-latest-${feedId}`} />
      </Tooltip>
    );
  } else if (latest.exec == null) {
    chip = (
      <Tooltip title="This feed has no executions yet — neither a scheduled run nor a Run Now.">
        <Chip size="small" variant="outlined" label="never run" data-testid={`feed-latest-${feedId}`} />
      </Tooltip>
    );
  } else {
    const e = latest.exec;
    const rel = formatRelative(e.started_at, now);
    // the status is the chip's; the text says what the chip does not
    // (2026-10-22: "completed · 5 rows" beside a COMPLETED chip said it twice
    // and pushed the column under the pinned actions at 1280px)
    const label = isLiveStatus(e.status)
      ? `started ${rel}`
      : `${formatRowCount(e.total_rows)} rows · ${rel}`;
    chip = (
      <Tooltip title={`${triggerKind(e.trigger_type).label} · started ${formatUtc(e.started_at)}${e.error_message ? ` · ${e.error_message.slice(0, 120)}` : ''}`}>
        <span>
          <ExecutionStatusChip status={e.status} data-testid={`feed-latest-${feedId}`} />
          <Typography variant="caption" component="span" sx={{ ml: 0.5, whiteSpace: 'nowrap' }} data-testid={`feed-latest-text-${feedId}`}>
            {label}
          </Typography>
        </span>
      </Tooltip>
    );
  }
  return (
    <Stack direction="row" spacing={0.5} alignItems="center" sx={{ flexWrap: { xs: 'wrap', xl: 'nowrap' } }} useFlexGap>
      {chip}
      {viewRuns}
    </Stack>
  );
};

// ── Component ────────────────────────────────────────────────────────────────

const FeedConfigsPage = () => {
  const [feeds, setFeeds] = useState<FeedConfig[]>([]);
  // FB-49 (2026-09-20) -- no search and no pager, like /datasets and
  // /connections.  Client-side, and for the same reason: the feed list
  // arrives COMPLETE in one read, so slicing the loaded array is the truth.
  const [feedSearch, setFeedSearch] = useState('');
  const [feedPage, setFeedPage] = useState(0);
  const [feedRowsPerPage, setFeedRowsPerPage] = useState(25);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  // 2026-08-05 — save-time cross-source preflight WARNINGs (e.g.
  // DIALECT_MISMATCH).  They deliberately do not block the save (errors
  // already 400), but the user must still learn their two sources use
  // different SQL dialects BEFORE the feed misbehaves.
  const [warning, setWarning] = useState('');

  // Create/Edit dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  // "View as DataFlow" — read-only feed -> DataFlow stage preview.
  const [dfOpen, setDfOpen] = useState(false);
  const [dfLoading, setDfLoading] = useState(false);
  const [dfPreview, setDfPreview] = useState<any | null>(null);
  const [dfFeedName, setDfFeedName] = useState('');
  // Admin-only ad-hoc trigger state (Run SOD now / SLA sweep).
  const { user } = useAuth();
  const userRole = ((user as any)?.role || '').toLowerCase();
  const isAdmin = userRole === 'admin' || userRole === 'super_admin';
  const [adminBusy, setAdminBusy] = useState(false);

  // SOD trigger dialog — asks admin which business_date to run for.
  // Default = today UTC.  Useful for backfilling missed days or seeding
  // a brand-new feed_config mid-day.  Idempotent on the backend.
  const [sodDialogOpen, setSodDialogOpen] = useState(false);
  const [sodDate, setSodDate] = useState<string>(() => new Date().toISOString().slice(0, 10));

  const handleRunSodNow = () => {
    // Reset to today each time the dialog opens (avoid stale dates).
    setSodDate(new Date().toISOString().slice(0, 10));
    setSodDialogOpen(true);
  };

  const confirmRunSodNow = async () => {
    if (!sodDate) return;
    setSodDialogOpen(false);
    setAdminBusy(true);
    try {
      const result: any = await api.runSodNow(sodDate);
      setSuccess(
        `SOD complete for ${sodDate}: ` +
        `created=${result?.created ?? 0}, ` +
        `skipped=${result?.skipped_by_condition ?? 0}, ` +
        `already=${result?.already_existed ?? 0}, ` +
        `skipped_window=${result?.skipped_window ?? 0}`,
      );
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setAdminBusy(false);
    }
  };

  const handleSlaSweepNow = async () => {
    setAdminBusy(true);
    try {
      const result: any = await api.slaSweepNow();
      setSuccess(`SLA sweep complete: breached_new=${result?.breached_new ?? 0}, checked=${result?.checked ?? 0}`);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setAdminBusy(false);
    }
  };
  const [editFeed, setEditFeed] = useState<FeedConfig | null>(null);
  // 2026-10-12 (the owner: "if query changes ... ask user changes should be
  // applicable from") -- WHEN an edit applies: the next run (a business date
  // already delivered keeps its definition) or a business date onward
  // (re-runs and restatements included).  core/feed/definition_timeline.py.
  const [applyMode, setApplyMode] = useState<'next_run' | 'from_date'>('next_run');
  const [applyFromDate, setApplyFromDate] = useState('');
  const [activeStep, setActiveStep] = useState(0);

  // Lookup-list state — populated on mount and whenever the create/edit
  // dialog opens, so the source / connection pickers always have fresh
  // options without flicker.
  const [connections, setConnections] = useState<ConnectionOption[]>([]);
  const [savedQueries, setSavedQueries] = useState<SavedQueryOption[]>([]);
  const [publishedViews, setPublishedViews] = useState<PublishedViewOption[]>([]);
  const [sqlFilesList, setSqlFilesList] = useState<SqlFileOption[]>([]);

  // Form state
  const [formName, setFormName] = useState('');
  // BRD STEP 1 — display_name is the EDITABLE label; it is what makes the
  // rename refusal (name immutable once run) acceptable rather than
  // obstructive.
  const [formDisplayName, setFormDisplayName] = useState('');
  // The SHAPE — query_params._partition (core/feed/partition_shape.py).
  // Absent = single-file feed; a declared-but-empty list is a DECISION.
  const [formShape, setFormShape] = useState<PartitionShapeDraft>(EMPTY_SHAPE_DRAFT);
  // The CONTRACT terms — stored in output_options, validated at authoring
  // by the API (contract.py); unsupported terms come back as
  // `contract_unsupported` warnings on the save response.
  const [formContractOpts, setFormContractOpts] = useState<ContractOpts>(CONTRACT_DEFAULTS);
  // The DELIVERY chain — feed field `delivery_chain` (core/feed/
  // delivery_hops.py::build_hop_plan).  Off = today's single
  // destination, unchanged, with NO delivery_chain key in the payload.
  const [formDeliveryChain, setFormDeliveryChain] =
    useState<DeliveryChainDraft>(EMPTY_DELIVERY_CHAIN_DRAFT);
  const setContractOpt = <K extends keyof ContractOpts>(k: K, v: ContractOpts[K]) =>
    setFormContractOpts(prev => ({ ...prev, [k]: v }));
  // Phase 131 — generic task_type.  file_feed is the legacy default
  // (produces a file artifact + delivers it); other types reserved
  // for future routing branches.
  const [formTaskType, setFormTaskType] = useState<'file_feed'|'oracle_push'|'api_push'|'custom'>('file_feed');
  // Phase 132.38 — per-feed Static / Dynamic WHERE-clause mapping.
  // Same primitive Published Views uses (api param concept).  Persisted
  // inside query_params._where_clauses_mapping so feed_configs needs no
  // DB migration.
  const [formWhereClauses, setFormWhereClauses] = useState<WhereClauseRow[]>([]);
  const [formDescription, setFormDescription] = useState('');
  const [formSourceType, setFormSourceType] = useState<string>('saved_query');
  const [formSourceId, setFormSourceId] = useState<number | ''>('');
  const [formConnectionId, setFormConnectionId] = useState<number | ''>('');
  // raw_sql source: backend reads SQL from query_params.sql, so the form
  // owns it and we ship it inside the create/update payload below.
  const [formRawSql, setFormRawSql] = useState('');
  // Phase 133-F — partition cache for the picked connection, used to
  // surface partition badges + per-value autocomplete in the WHERE-
  // clauses editor.  Refetched whenever formConnectionId changes.
  const [formPartitionInfo, setFormPartitionInfo] = useState<PartitionValueOptions>({
    valueOptionsByColumn: {}, partitionColumns: [],
  });
  // Phase 133-H round 6 — full column catalogue per source table for
  // the WHERE-clause editor.  Fetched via /api/sql/preview-columns
  // with connection_id; backend reads ``schema_cache`` (populated by
  // every CQB / BQB / register-table call) and falls back to
  // ``connector.list_columns()`` on miss.  Lets the dropdown show
  // every column on the underlying tables — not just the names that
  // appear in the SQL text.
  const [formColumnCatalog, setFormColumnCatalog] = useState<{
    columnsByTable: Record<string, Array<{name: string; type?: string}>>;
    partitionColumnsByTable: Record<string, string[]>;
    tableConnectionIds: Record<string, number>;
  }>({ columnsByTable: {}, partitionColumnsByTable: {}, tableConnectionIds: {} });

  // Phase 133-I round 19 — secondary connection's columns for the
  // cross-source JOIN key picker.  Without this, the user had to type
  // the secondary side's column names from memory (plain TextField).
  // Fetched lazily via /api/sql/preview-columns with the same SQL
  // resolution as the primary side — but against the secondary
  // connection's ID.  Falls back to free-text typing on empty.
  const [formSecondaryColumnCatalog, setFormSecondaryColumnCatalog] = useState<{
    columnsByTable: Record<string, Array<{name: string; type?: string}>>;
  }>({ columnsByTable: {} });
  // Tracks whether the user has manually overridden the auto-derived
  // connection from the picked source.  Without this, selecting a saved
  // query that already carries a connection would silently lock the
  // connection picker to the source's connection forever.
  const [formConnOverridden, setFormConnOverridden] = useState(false);
  const [formOutputFormat, setFormOutputFormat] = useState('csv');
  const [formFilenameTemplate, setFormFilenameTemplate] = useState('');
  const [formDestType, setFormDestType] = useState('local');
  const [formDestPath, setFormDestPath] = useState('');
  const [formDestBucket, setFormDestBucket] = useState('');
  const [formDestPrefix, setFormDestPrefix] = useState('');
  // 2026-09-24 -- the SFTP destination is ONE complete config object (host
  // key, sign-in method, account, ...), edited by SftpDestinationFields.  The
  // five separate fields this replaced were rebuilt into a fresh object on
  // save, which silently DROPPED the pinned host key of a working feed.
  const [formDestSftp, setFormDestSftp] = useState<Record<string, any>>({ port: 22, remote_dir: '/' });
  // The stored destination config of the feed being edited: every key the
  // form does not model is carried through a save of the SAME type.
  const [formDestStored, setFormDestStored] = useState<{ type: string; config: Record<string, any> } | null>(null);
  // The ORACLE destination — exactly the keys _deliver_oracle reads
  // (feedAuthoringRules.ts).  Until 2026-09-14 the dropdown offered
  // ORACLE and buildDestConfig sent {} for it: accepted by PUT, refused
  // at delivery time.
  const [formDestOracle, setFormDestOracle] =
    useState<OracleDestinationDraft>(EMPTY_ORACLE_DEST_DRAFT);
  const [formBackend, setFormBackend] = useState('auto');
  // Phase 131 deep-dive #13 (round 8): per-feed size threshold for the
  // auto router.  Empty string = inherit global (feed_generation.auto_
  // route_threshold_rows, default 500K).
  const [formSizeThresholdRows, setFormSizeThresholdRows] = useState('');
  const [formScheduleEnabled, setFormScheduleEnabled] = useState(false);
  const [formCron, setFormCron] = useState('');
  const [formTimezone, setFormTimezone] = useState('UTC');
  // The CONSUMER's deadline (FR-SLA).  Read by the SLA watcher, the
  // dependency panel, the groups page and the Today view -- and settable
  // NOWHERE until now, so every feed authored here had sla_to = NULL,
  // _tightest_sla found nothing, the clocks were empty and the whole
  // alert ladder was inert.  A consumer with no producer.
  // Per-feed retry policy.  feed_engine reads these as an override of
  // the global retry_max_attempts / retry_delay_seconds; blank keeps the
  // deployment default.  A feed whose destination rate-limits needs its
  // own backoff, and had no way to say so.
  const [formMaxRetries, setFormMaxRetries] = useState('');
  const [formRetryDelay, setFormRetryDelay] = useState('');
  // Heavy-lane sizing (backend_config.spark_size_class).  A named class
  // rather than raw memory strings: the deployment declares the classes
  // in spark_k8s.size_classes, so a feed picks a SHAPE and the cluster
  // owns what that shape costs.
  const [formSparkSizeClass, setFormSparkSizeClass] = useState('');
  // 2026-10-14 -- read the query in parts by a key (backend_config.
  // partition_config; core/feed/partitioned_read.py): the column(s), the
  // optional order inside each part, and how many parts run at once.
  const [formPartitionColumns, setFormPartitionColumns] = useState('');
  const [formPartitionOrder, setFormPartitionOrder] = useState('');
  const [formPartitionConcurrent, setFormPartitionConcurrent] = useState('');
  const [formSlaFrom, setFormSlaFrom] = useState('');
  const [formSlaTo, setFormSlaTo] = useState('');
  const [formSlaTimezone, setFormSlaTimezone] = useState('');
  // 2026-10-03 -- a STORED sla value the hour/minute picker cannot show
  // (free text saved before the picker existed).  Shown read-only and
  // never resent; picking a time replaces it, leaving it unset clears it.
  const [formSlaFromLegacy, setFormSlaFromLegacy] = useState<string | null>(null);
  const [formSlaToLegacy, setFormSlaToLegacy] = useState<string | null>(null);
  // The feed's own validity window.  SOD's _in_window skips a date
  // outside it; with both NULL a feed runs for ever, which is the right
  // default but must be a CHOICE rather than the only reachable state.
  const [formValidFrom, setFormValidFrom] = useState('');
  const [formValidUntil, setFormValidUntil] = useState('');
  // BRD §2.1 (2026-09-02) — the DECLARED schedule (core/feed/schedule.py,
  // feed field `schedule_declaration`).  Absence stays absence: an
  // undeclared draft sends NOTHING and the feed keeps today's
  // cron + timezone + calendar path byte-for-byte.
  const [formSchedule, setFormSchedule] = useState<ScheduleDraft>(EMPTY_SCHEDULE_DRAFT);
  // 2026-09-03 — operational feed group membership (feed_group_id;
  // distinct from the entitlement owner group).  A FAILED lookup is
  // remembered so the picker can say so instead of looking empty.
  const [formFeedGroupId, setFormFeedGroupId] = useState<number | ''>('');
  const [feedGroupsList, setFeedGroupsList] = useState<Array<{
    id: number; name: string; display_label?: string | null;
  }>>([]);
  const [feedGroupsLoadError, setFeedGroupsLoadError] =
    useState<string | null>(null);
  // 2026-09-03 — operator dialogs
  const [backfillFeed, setBackfillFeed] =
    useState<{ id: number; name: string } | null>(null);
  // 2026-10-13 (the owner: "cloning should have the option to override all
  // fields") -- a clone is made in THE form: every field of the source,
  // pre-filled and editable, saved as a NEW feed.  ``cloneOf`` = the source's
  // id: the server fills a secret shown as *** from the source (secrets never
  // reach the browser); null = an ordinary new feed / an edit.
  const [cloneOf, setCloneOf] = useState<{ id: number; name: string } | null>(null);
  // 2026-10-10 -- the bulk-from-template dialog
  const [bulkTemplateOpen, setBulkTemplateOpen] = useState(false);
  const [deliveryFeed, setDeliveryFeed] =
    useState<{ id: number; name: string } | null>(null);
  const [lifecycleFeed, setLifecycleFeed] =
    useState<{ id: number; name: string } | null>(null);
  // 2026-09-27 -- the version history dialog (row menu + the edit dialog)
  const [versionsFeed, setVersionsFeed] =
    useState<{ id: number; name: string } | null>(null);
  // 2026-09-05 - the step plan, answerable before any run exists
  const [stepPlanFeed, setStepPlanFeed] =
    useState<{ id: number; name: string } | null>(null);
  useEffect(() => {
    api.listFeedGroups({ is_active: true })
      .then((gs: any) => {
        setFeedGroupsList(Array.isArray(gs) ? gs : []);
        setFeedGroupsLoadError(null);
      })
      .catch((e: any) =>
        setFeedGroupsLoadError(e?.message || String(e)));
  }, []);
  const [formNotifySuccess, setFormNotifySuccess] = useState(false);
  const [formNotifyFailure, setFormNotifyFailure] = useState(true);
  const [formNotifyEmails, setFormNotifyEmails] = useState('');

  // Phase 130 hotfix-2 — cross-source combine state.  When the user
  // sets a secondary connection, the feed runs both sides separately
  // and the engine combines via UNION ALL BY NAME / JOIN before the
  // output is written.  The control file (if configured) describes
  // the combined output.
  const [formCrossSourceEnabled, setFormCrossSourceEnabled] = useState(false);
  const [formSecondaryConnectionId, setFormSecondaryConnectionId] = useState<number | ''>('');
  const [formCombineMode, setFormCombineMode] = useState<'union' | 'join'>('union');
  const [formJoinKeysLeft, setFormJoinKeysLeft] = useState('');   // comma-sep
  const [formJoinKeysRight, setFormJoinKeysRight] = useState(''); // comma-sep
  const [formJoinType, setFormJoinType] = useState<'INNER' | 'LEFT' | 'RIGHT' | 'FULL'>('INNER');
  // 2026-10-11 -- the SECOND SIDE is a SOURCE (the owner: "no query selection
  // in cross source"): the same query as the primary (the engine's default
  // when secondary_source_type is null), a saved query on the second
  // connection (secondary_source_type/id), or SQL typed here
  // (query_params.secondary_raw_sql -- source_plan.secondary_side_config).
  const [formSecondarySourceMode, setFormSecondarySourceMode] =
    useState<'same' | 'saved_query' | 'raw_sql'>('same');
  const [formSecondarySourceId, setFormSecondarySourceId] = useState<number | ''>('');
  const [formSecondaryRawSql, setFormSecondaryRawSql] = useState('');
  // 2026-10-11 -- token BINDINGS (the owner: "where clause not getting
  // generic once we have saved queries"): a literal predicate of the saved
  // query bound to {BUSINESSDATE} / a feed parameter; stored on the feed
  // (token_bindings) and applied by the one renderer on every lane.
  const [formTokenBindings, setFormTokenBindings] = useState<TokenBinding[]>([]);
  const [formBindBothSides, setFormBindBothSides] = useState(true);
  // the feed's own scalar parameters ({NAME} tokens), hydrated from query_params
  const [formExtraParams, setFormExtraParams] = useState<Record<string, string>>({});
  const [newParamFor, setNewParamFor] = useState<string | null>(null);  // 'side|column|literal'
  const [newParamName, setNewParamName] = useState('');
  // what the draft would RUN -- POST /api/feeds/resolve-draft, read-only
  const [draftResolve, setDraftResolve] = useState<FeedDraftResolution | null>(null);
  const [draftResolveError, setDraftResolveError] = useState('');
  const [formControlFileTemplate, setFormControlFileTemplate] = useState('');
  const [formControlFileFormatId, setFormControlFileFormatId] = useState<number | ''>('');
  const [controlFileFormats, setControlFileFormats] = useState<Array<{id:number,name:string,description?:string|null,is_default?:boolean}>>([]);
  // 2026-07-22 — platform DEFAULT output (NFS) directory from the backend
  // (feed_generation.output_dir).  Pre-fills the "Output Directory" field for
  // new local feeds; the user can still override it.  Falls back to the legacy
  // 'data/feeds' literal until /api/feeds/defaults resolves.
  const [defaultOutputDir, setDefaultOutputDir] = useState('data/feeds');

  // Phase 130 hotfix-13 — Owner Group + Calendar pickers.  Backend
  // supports owner_group_id (entitlement group with per-user
  // read_only/read_write flavour) and calendar_name (BusinessCalendar
  // used for {{prev_business_day}} / {{prev_eom}} resolution).
  const [formOwnerGroupId, setFormOwnerGroupId] = useState<number | ''>('');
  // 2026-09-28 -- the feed's CONSUMER groups (delivery receipts on My Feeds; NOT a view grant)
  const [formConsumerGroupIds, setFormConsumerGroupIds] = useState<number[]>([]);
  const [formCalendarName, setFormCalendarName] = useState<string>('');
  // 2026-10-22 -- the control-file preview (dummy data, the run's own renderer)
  const [ctlPreview, setCtlPreview] = useState<{ loading?: boolean; data?: any; error?: string } | null>(null);
  const [userGroupsList, setUserGroupsList] = useState<Array<{id:number,name:string,description?:string|null}>>([]);
  const [calendarsList, setCalendarsList] = useState<Array<{id:number,name:string}>>([]);

  // BF-473 (2026-05-19) — operator-facing frequency category.  Open
  // string with suggested vocabulary fetched from
  // /api/feeds/frequency-categories so a custom value typed by one
  // admin shows up in the next admin's dropdown.
  const [formFrequencyCategory, setFormFrequencyCategory] = useState<string>('');
  const [frequencyCategoriesList, setFrequencyCategoriesList] = useState<
    Array<{ value: string; label: string }>
  >([]);

  // Phase 131 — production controls (opt-in per feed)
  // 131-A: end users add deps inline below.  When deps are present and
  //        etl_id is null, backend auto-fills etl_id = feed_id so the
  //        poller picks the feed up.  There is no explicit etl_id form
  //        field — the user just adds deps; the linkage is implicit.
  // 131-B: row_count_action + row_count_threshold_pct enable per-feed
  //        anomaly detection against the rolling baseline.
  // 131-C: integrity_check_enabled NULL = inherit system default.
  const [formRowCountAction, setFormRowCountAction] = useState<'off'|'warn'|'fail'|'hold'>('off');
  // 2026-10-12 (owner R2) -- what today's count is compared with: the rolling
  // baseline, or the rows the PREVIOUS business date delivered.
  const [formRowCountCompareTo, setFormRowCountCompareTo] = useState<'baseline'|'previous'>('baseline');
  const [formRowCountThresholdPct, setFormRowCountThresholdPct] = useState<string>('');
  const [formIntegrityCheck, setFormIntegrityCheck] = useState<'inherit'|'on'|'off'>('inherit');

  // 131-A inline editor — list of deps attached to this feed.  Loaded
  // when editing an existing feed; new feeds start empty and the
  // mappings are persisted right after the feed save returns.
  type DepRow = {
    id?: number;                  // present on existing rows
    dependency_type_id: number;
    dependency_type?: string;     // human label
    dependency_key: string;
    description?: string | null;
    // 2026-09-27 — the DECLARED arrival sources and how they combine.
    // null / [] = no declaration = any evidence satisfies it (legacy).
    arrival_sources?: DeclaredArrivalSource[] | null;
    require_mode?: 'all' | 'any' | null;
    // 2026-10-15 -- a NEW message of this dependency for a date already
    // delivered re-runs it: null/true = yes, false = recorded only (the month
    // end: SOD / ITD no, EOD yes).  Server: core/feed/restatement.py.
    reruns_delivered?: boolean | null;
    // Carried through a save untouched (the PUT REPLACES the list: a field
    // the form did not send was erased -- found 2026-10-15).
    certifies_side?: string | null;
    expected_rows?: number | null;
    // FR-DEP-08 (authorable 2026-09-27) — WHOSE calendar governs this
    // dependency: the UPSTREAM's.  On its holiday the gate reports NOT
    // EXPECTED and the run proceeds with no skip and nobody paged.
    // null = expected every run day.
    calendar_name?: string | null;
  };
  type DepType = { id: number; dependency_type: string; description?: string | null };
  const [formDeps, setFormDeps] = useState<DepRow[]>([]);
  // 2026-10-03 -- whether formDeps is KNOWN.  An edit used to swallow a
  // failed GET of the feed's dependencies ("leave empty") and the save then
  // PUT `dependencies: []` -- DELETING every mapping the feed had.  Unknown
  // is not empty: the save sends the list only when it was read.
  const [depsLoad, setDepsLoad] = useState<
    { state: 'loaded' } | { state: 'loading' } | { state: 'failed'; message: string }
  >({ state: 'loaded' });
  // Which of the form's lookup lists could not be read, and why ("Could
  // not reach the server" vs "HTTP 500: ...").  Each list still falls back
  // to empty so the form stays usable, but the author is TOLD it is
  // unknown -- an empty dependency-type picker said "ask admin to add
  // types" when the server was merely restarting.
  const [lookupFailures, setLookupFailures] = useState<Record<string, string>>({});
  const [availableDepTypes, setAvailableDepTypes] = useState<DepType[]>([]);
  const [newDepTypeId, setNewDepTypeId] = useState<number | ''>('');
  const [newDepKey, setNewDepKey] = useState<string>('');
  const [newDepDesc, setNewDepDesc] = useState<string>('');
  const [newDepCalendar, setNewDepCalendar] = useState<string>('');
  // 2026-09-27 — arrival-source authoring.  The vocabulary comes from the
  // server (core/feed/arrival_sources.py is the ONE registry); the
  // iceberg_commit kind needs a connection, a registered Iceberg table and
  // its date column, each picked from what the server lists.
  const [arrivalVocab, setArrivalVocab] = useState<ArrivalSourcesVocabulary | null>(null);
  const [newDepSources, setNewDepSources] = useState<DeclaredArrivalSource[]>([]);
  const [newDepMode, setNewDepMode] = useState<'all' | 'any'>('all');
  const [newSrcKind, setNewSrcKind] = useState<string>('');
  const [newSrcConnId, setNewSrcConnId] = useState<number | ''>('');
  const [newSrcTable, setNewSrcTable] = useState<string>('');
  const [newSrcColumn, setNewSrcColumn] = useState<string>('');
  const [srcTables, setSrcTables] = useState<{ name: string; format: string }[]>([]);
  const [srcColumns, setSrcColumns] = useState<string[]>([]);
  // 2026-10-07 -- the `file` kind: where the watcher lists, on the run's
  // business date (the filename renderer's tokens: {business_date:YYYYMMDD}).
  const [newSrcPath, setNewSrcPath] = useState<string>('');
  const [newSrcPattern, setNewSrcPattern] = useState<string>('');
  const [newSrcControl, setNewSrcControl] = useState<string>('');
  const [newSrcMinFiles, setNewSrcMinFiles] = useState<string>('');
  // "Could not list" and "lists nothing" are opposite findings -- the
  // reason is kept and shown rather than folded into an empty picker.
  const [srcLookupError, setSrcLookupError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;
    api.getFeedArrivalSources()
      .then((v) => {
        if (cancelled) return;
        // A 200 without a kinds LIST is an answer we cannot read, not "no kinds":
        // say so beside an empty picker instead of crashing the editor on
        // `kinds.find` (every FeedConfigsPage test died on it, 2026-10-07..10).
        if (!v || !Array.isArray((v as any).kinds)) {
          setArrivalVocab({ kinds: [], require_modes: ['all', 'any'], default_require_mode: 'all' });
          setSrcLookupError('Arrival-source vocabulary could not be read: the server answered without a list of kinds');
          return;
        }
        setArrivalVocab(v);
      })
      .catch((e: any) => {
        if (!cancelled) {
          setArrivalVocab({ kinds: [], require_modes: ['all', 'any'], default_require_mode: 'all' });
          setSrcLookupError(`Arrival-source vocabulary could not be loaded: ${e?.message || e}`);
        }
      });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setSrcTables([]);
    setSrcColumns([]);
    if (newSrcKind !== 'iceberg_commit' || newSrcConnId === '') return () => { cancelled = true; };
    setSrcLookupError('');
    api.listRegisteredTables(String(newSrcConnId))
      .then((r: any) => {
        if (cancelled) return;
        const tables = (Array.isArray(r?.tables) ? r.tables : [])
          .filter((t: any) => String(t?.format || '').toLowerCase() === 'iceberg')
          .map((t: any) => ({ name: String(t.name), format: 'iceberg' }));
        setSrcTables(tables);
        if (tables.length === 0) setSrcLookupError('This connection has no registered Iceberg table — register one on the Connections page first.');
      })
      .catch((e: any) => { if (!cancelled) setSrcLookupError(`Registered tables could not be listed: ${e?.message || e}`); });
    return () => { cancelled = true; };
  }, [newSrcKind, newSrcConnId]);

  useEffect(() => {
    let cancelled = false;
    setSrcColumns([]);
    if (newSrcKind !== 'iceberg_commit' || newSrcConnId === '' || !newSrcTable) return () => { cancelled = true; };
    api.getRegisteredTableSchema(String(newSrcConnId), newSrcTable)
      .then((r: any) => {
        if (cancelled) return;
        const cols = (Array.isArray(r?.columns) ? r.columns : [])
          .map((c: any) => (typeof c === 'string' ? c : String(c?.name || '')))
          .filter((n: string) => !!n);
        setSrcColumns(cols);
        if (cols.length === 0) setSrcLookupError(`Table ${newSrcTable} lists no columns — refresh its schema on the Connections page.`);
      })
      .catch((e: any) => { if (!cancelled) setSrcLookupError(`Columns of ${newSrcTable} could not be read: ${e?.message || e}`); });
    return () => { cancelled = true; };
  }, [newSrcKind, newSrcConnId, newSrcTable]);

  // 2026-10-08 -- a kafka source's optional topic.
  const [newSrcTopic, setNewSrcTopic] = useState<string>('');
  // 2026-10-11 -- the `oracle_table` kind: an Oracle connection + the table name
  // (the OG QS_KAFKA_MESSAGE landing table); the rules live in the config block.
  const [newSrcOracleTable, setNewSrcOracleTable] = useState<string>('');
  const resetFileSourceFields = () => {
    setNewSrcPath('');
    setNewSrcPattern('');
    setNewSrcControl('');
    setNewSrcMinFiles('');
    setNewSrcTopic('');
    setNewSrcOracleTable('');
  };
  const canAddSource = !!newSrcKind && (
    newSrcKind === 'iceberg_commit'
      ? (newSrcConnId !== '' && !!newSrcTable && !!newSrcColumn)
      : newSrcKind === 'oracle_table'
        ? (newSrcConnId !== '' && !!newSrcOracleTable.trim())
        : newSrcKind !== 'file' || (newSrcConnId !== '' && !!newSrcPath.trim()));
  const buildNewSource = (): DeclaredArrivalSource => {
    if (newSrcKind === 'iceberg_commit') {
      return { kind: 'iceberg_commit', connection_id: Number(newSrcConnId), table: newSrcTable, date_column: newSrcColumn };
    }
    if (newSrcKind === 'oracle_table') {
      // 2026-10-11 -- the backend stores the table UPPER (Oracle folds unquoted
      // identifiers up); which columns mean what is the table's configured rules.
      return { kind: 'oracle_table', connection_id: Number(newSrcConnId), table: newSrcOracleTable.trim().toUpperCase() };
    }
    if (newSrcKind === 'file') {
      return fileSourceSpec(Number(newSrcConnId), newSrcPath, newSrcPattern, newSrcControl, newSrcMinFiles);
    }
    if (newSrcKind === 'kafka' && newSrcTopic.trim()) {
      return { kind: 'kafka', topic: newSrcTopic.trim() };
    }
    return { kind: newSrcKind };
  };
  const addNewDepSource = () => {
    if (!canAddSource) return;
    const spec = buildNewSource();
    if (newDepSources.some((s) => JSON.stringify(s) === JSON.stringify(spec))) return;
    setNewDepSources((prev) => [...prev, spec]);
    setNewSrcKind('');
    setNewSrcConnId('');
    setNewSrcTable('');
    setNewSrcColumn('');
    resetFileSourceFields();
  };

  // Latest execution per feed -- the read-only status chip on each row.
  // THREE states, because "could not read" and "has none" are opposite
  // findings and must never render the same (CLAUDE.md: unknown != empty).
  const [latestByFeed, setLatestByFeed] = useState<Record<number, LatestExec>>({});

  // ── Data Loading ───────────────────────────────────────────────────────────

  const loadFeeds = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await api.listFeeds();
      // BF-428P: normalise — backend wrapper / null shouldn't crash .map
      setFeeds(toArray(data));
    } catch (err: any) {
      setError(err.message || 'Failed to load feeds');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadFeeds(); }, [loadFeeds]);

  // Load the lookup lists once on mount (also refreshed when dialog opens
  // so a user who creates a new saved query in another tab sees it without
  // a full page refresh).  All four calls run in parallel and fail-open —
  // a missing list just produces an empty dropdown rather than blocking
  // feed-config CRUD entirely.
  const loadLookups = useCallback(async () => {
    // 2026-10-03 -- every list still falls back to empty (the form must
    // stay usable), but a failure is RECORDED by name and shown with a
    // Retry: "could not read" and "there are none" are opposite findings.
    const failures: Record<string, string> = {};
    const track = <T,>(label: string, p: Promise<T>, fallback: T): Promise<T> =>
      p.catch((e: unknown) => {
        failures[label] = describeLoadError(e).message;
        return fallback;
      });
    const [conns, queries, pviews, sfs, fmts, groups, cals, depTypesRaw, freqCats, defaults] = await Promise.all([
      track<any>('connections', api.listConnections(true), []),
      track<any>('saved queries', api.listQueries(true), []),
      track<any>('published views', api.listPublishedViews(), { views: [] }),
      track<any>('SQL files', api.sqlFiles.list({ limit: 500 }), []),
      // Phase 130 hotfix-4 — load CTL formats for the picker.  Silently
      // empty when the user lacks admin rights (the dropdown just won't
      // populate; legacy template field still works).
      // Phase 4 (2026-08-23): read-only route — the admin route 403'd for
      // analysts and the catch swallowed it (empty picker, no error).
      track<any>('control-file formats',
        (api as any).listControlFileFormatsReadonly?.() ?? Promise.resolve([]), []),
      // Phase 130 hotfix-13 — Owner Group picker populated from an admin
      // endpoint.  2026-09-24: GET /api/admin/user-groups is
      // ``require_admin``; the walk saw analysts ask and get a 403.  Only
      // an admin asks -- for anyone else the list is UNKNOWN (not empty)
      // and the picker says so.
      isAdmin
        ? track<any>('user groups',
          (api as any).listUserGroups?.({ is_active: true }) ?? Promise.resolve([]), [])
        : Promise.resolve([]),
      // Phase 4 (2026-08-23) — Calendar picker now uses the READ-ONLY
      // route: /feeds is open to analysts, but the admin route 403'd for
      // them, the catch swallowed it, and the picker silently emptied
      // (an out-of-range Select when editing an admin-configured feed).
      track<any>('business calendars',
        (api as any).listFeedCalendarsReadonly?.() ?? Promise.resolve([]), []),
      // Phase 131-A — dependency type catalogue (non-admin endpoint).
      // 2026-07-03 audit fix: use safeFetch so the URL prepends
      // resolveApiBaseUrl() (cross-origin Helm deploys were silently
      // hitting same-origin SPA catch-all → empty picker).
      track<any>('dependency types', safeFetch('/api/feed-dependency-types'), { items: [] }),
      // BF-473 — frequency category suggestions (baseline + in-DB custom)
      track<any>('frequency categories',
        safeFetch('/api/feeds/frequency-categories'), { categories: [] }),
      // 2026-07-22 — platform default output (NFS) directory for the
      // "Output Directory" pre-fill.  Fail-open to an empty object.
      track<any>('platform defaults', safeFetch('/api/feeds/defaults'), {}),
    ]);
    setLookupFailures(failures);
    setConnections(toArray(conns));
    setSavedQueries(toArray(queries));
    // /api/published-views returns { views: [...] }; toArray handles both
    // wrapped + bare shapes via the BF-428P helper.
    const pv = (pviews && (pviews as any).views) || pviews;
    setPublishedViews(toArray(pv));
    setSqlFilesList(toArray(sfs));
    setControlFileFormats(toArray(fmts));
    setUserGroupsList(toArray(groups));
    setCalendarsList(toArray(cals));
    setAvailableDepTypes(toArray((depTypesRaw as any)?.items));
    // BF-473 — category suggestions
    setFrequencyCategoriesList(toArray((freqCats as any)?.categories));
    // 2026-07-22 — surface the platform default output (NFS) directory.
    const _defDir = (defaults as any)?.default_output_dir;
    if (_defDir && typeof _defDir === 'string') setDefaultOutputDir(_defDir);
  }, [isAdmin]);

  useEffect(() => { loadLookups(); }, [loadLookups]);

  // Phase 133-F — partition cache refetch on connection change.
  useEffect(() => {
    let cancelled = false;
    const cid = typeof formConnectionId === 'number' ? formConnectionId : null;
    if (!cid) {
      setFormPartitionInfo({ valueOptionsByColumn: {}, partitionColumns: [] });
      return () => { cancelled = true; };
    }
    fetchPartitionValueOptions(cid).then(p => {
      if (!cancelled) setFormPartitionInfo(p);
    });
    return () => { cancelled = true; };
  }, [formConnectionId]);

  // Phase 133-H round 6 — refetch full column catalogue when SQL or
  // connection changes.  Backend reads schema_cache so the request is
  // cheap (DB round-trip, no warehouse call) for tables that have
  // been queried before.
  //
  // Phase 133-H round 17 — resolve the EFFECTIVE SQL for column
  // extraction based on source_type.  raw_sql uses formRawSql
  // directly; saved_query / published_view / sql_file fetch the
  // referenced entity and pull its SQL (so the WHERE editor's
  // dropdown is populated even before the user types anything).
  const [resolvedSqlForEditor, setResolvedSqlForEditor] = useState('');
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (formSourceType === 'raw_sql') {
        if (!cancelled) setResolvedSqlForEditor(formRawSql || '');
        return;
      }
      if (!formSourceId) {
        if (!cancelled) setResolvedSqlForEditor('');
        return;
      }
      try {
        if (formSourceType === 'saved_query') {
          const sq: any = await api.getSavedQuery(String(formSourceId));
          const qc = sq?.query_config || {};
          // Build a synthetic SQL from raw_sql, or from columns + files if structured.
          let sqlForEd = '';
          if (typeof qc.raw_sql === 'string' && qc.raw_sql.trim()) {
            sqlForEd = qc.raw_sql;
          } else if (Array.isArray(qc.columns) && qc.columns.length > 0) {
            const tbl = (qc.files || [])[0];
            const tblPath = typeof tbl === 'string' ? tbl : tbl?.path || '';
            const tblName = tblPath.replace(/^__(registered|iceberg)__:/, '') || 'src';
            sqlForEd = `SELECT ${qc.columns.join(', ')} FROM ${tblName}`;
          }
          if (!cancelled) setResolvedSqlForEditor(sqlForEd);
        } else if (formSourceType === 'sql_file') {
          const sf: any = await api.sqlFiles.get(Number(formSourceId));
          if (!cancelled) setResolvedSqlForEditor(sf?.content || '');
        } else if (formSourceType === 'published_view') {
          // PVs don't expose raw SQL directly; skip — feed config
          // doesn't currently let publishers add WHERE rows on PV
          // sources anyway (they were already locked at publish time).
          if (!cancelled) setResolvedSqlForEditor('');
        }
      } catch {
        if (!cancelled) setResolvedSqlForEditor('');
      }
    })();
    return () => { cancelled = true; };
  }, [formSourceType, formSourceId, formRawSql]);

  useEffect(() => {
    let cancelled = false;
    const cid = typeof formConnectionId === 'number' ? formConnectionId : null;
    const sqlToUse = resolvedSqlForEditor || formRawSql;
    if (!cid || !sqlToUse.trim()) {
      setFormColumnCatalog({
        columnsByTable: {},
        partitionColumnsByTable: {},
        tableConnectionIds: {},
      });
      return () => { cancelled = true; };
    }
    fetchPreviewColumns(sqlToUse, 'duckdb', cid).then(res => {
      if (cancelled || !res) return;
      setFormColumnCatalog({
        columnsByTable: res.columns_by_table || {},
        partitionColumnsByTable: res.partition_columns_by_table || {},
        tableConnectionIds: res.table_connection_ids || {},
      });
    });
    return () => { cancelled = true; };
  }, [formConnectionId, resolvedSqlForEditor, formRawSql]);

  // Phase 133-I round 19 — secondary side schema fetch for the
  // cross-source JOIN key picker.  Uses the SAME SQL the primary
  // catalog used (assumption: both sides query the same logical
  // schema — that's WHY they're being combined).  When the
  // assumption breaks the JOIN key field falls back to free-text.
  useEffect(() => {
    let cancelled = false;
    const sid = typeof formSecondaryConnectionId === 'number' ? formSecondaryConnectionId : null;
    const sqlToUse = resolvedSqlForEditor || formRawSql;
    if (!sid || !sqlToUse.trim()) {
      setFormSecondaryColumnCatalog({ columnsByTable: {} });
      return () => { cancelled = true; };
    }
    fetchPreviewColumns(sqlToUse, 'duckdb', sid).then(res => {
      if (cancelled || !res) return;
      setFormSecondaryColumnCatalog({
        columnsByTable: res.columns_by_table || {},
      });
    });
    return () => { cancelled = true; };
  }, [formSecondaryConnectionId, resolvedSqlForEditor, formRawSql]);

  // 2026-10-11 -- what this DRAFT would run: POST /api/feeds/resolve-draft
  // (core/feed/authoring_draft.py), debounced, while the dialog is open.
  // Each side's SQL and literal predicates, the merge-by-name disclosure,
  // whether the primary saved query already carries its own second side,
  // and every binding's verdict.  Read-only; nothing executes.
  const _draftBody = useMemo(() => {
    const qp: Record<string, any> = { ...formExtraParams };
    if (formSourceType === 'raw_sql' && formRawSql.trim()) qp.sql = formRawSql.trim();
    const crossOn = Boolean(formCrossSourceEnabled && formSecondaryConnectionId);
    if (crossOn && formSecondarySourceMode === 'raw_sql' && formSecondaryRawSql.trim()) {
      qp.secondary_raw_sql = formSecondaryRawSql.trim();
    }
    const body: Record<string, any> = {
      source_type: formSourceType,
      source_id: formSourceType === 'raw_sql' ? 0 : (formSourceId || null),
      connection_id: formConnectionId || null,
      query_params: qp,
      token_bindings: formTokenBindings.filter(b => crossOn || b.side !== 'secondary'),
    };
    if (crossOn) {
      body.secondary_connection_id = Number(formSecondaryConnectionId);
      body.combine_mode = formCombineMode;
      if (formSecondarySourceMode === 'saved_query' && formSecondarySourceId) {
        body.secondary_source_type = 'saved_query';
        body.secondary_source_id = Number(formSecondarySourceId);
      } else if (formSecondarySourceMode === 'raw_sql') {
        body.secondary_source_type = 'raw_sql';
      }
    }
    return body;
  }, [formSourceType, formSourceId, formConnectionId, formRawSql, formExtraParams,
      formCrossSourceEnabled, formSecondaryConnectionId, formSecondarySourceMode,
      formSecondarySourceId, formSecondaryRawSql, formCombineMode, formTokenBindings]);
  const _draftKey = JSON.stringify(_draftBody);
  useEffect(() => {
    if (!dialogOpen) return;
    const hasSource = formSourceType === 'raw_sql'
      ? Boolean(_draftBody.query_params?.sql) : Boolean(_draftBody.source_id);
    if (!hasSource) { setDraftResolve(null); setDraftResolveError(''); return; }
    let cancelled = false;
    const timer = setTimeout(() => {
      api.resolveFeedDraft(_draftBody)
        .then((res: FeedDraftResolution) => {
          if (cancelled) return;
          // Type the SERVER's shape and guard what it did not send: an answer
          // without a primary side (a proxy page, an older backend) is
          // "could not read", never a crash of the whole form.
          if (!res || typeof res !== 'object' || !res.primary || !Array.isArray(res.primary.predicates)) {
            setDraftResolve(null);
            setDraftResolveError('the server answered without a resolution');
            return;
          }
          setDraftResolve(res); setDraftResolveError('');
        })
        .catch((e: any) => { if (!cancelled) { setDraftResolve(null); setDraftResolveError(describeLoadError(e).message); } });
    }, 300);
    return () => { cancelled = true; clearTimeout(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_draftKey, dialogOpen]);

  // The binding of ONE literal predicate on ONE side.  With "bind both
  // sides" on (the owner's rule: cloud and on-prem share their columns), the
  // same (column, literal) on the other side is bound to the same token.
  const _sideHasPredicate = (side: 'primary' | 'secondary', column: string, literal: string): boolean => {
    const s = side === 'primary' ? draftResolve?.primary : draftResolve?.secondary;
    return Boolean(s?.predicates.some(
      p => p.column.toLowerCase() === column.toLowerCase() && p.literal === literal));
  };
  const setBinding = (side: 'primary' | 'secondary', column: string, literal: string,
                      token: string | null, format: string | null = null) => {
    setFormTokenBindings(prev => {
      const targets: Array<'primary' | 'secondary'> = [side];
      const other: 'primary' | 'secondary' = side === 'primary' ? 'secondary' : 'primary';
      if (formBindBothSides && _sideHasPredicate(other, column, literal)) targets.push(other);
      const kept = prev.filter(b => !(targets.includes(b.side)
        && b.column.toLowerCase() === column.toLowerCase() && b.literal === literal));
      if (!token) return kept;
      return [...kept, ...targets.map(t => ({ side: t, column, literal, token, format }))];
    });
  };
  const bindingFor = (side: 'primary' | 'secondary', column: string, literal: string) =>
    formTokenBindings.find(b => b.side === side
      && b.column.toLowerCase() === column.toLowerCase() && b.literal === literal) || null;
  const commitNewParam = (side: 'primary' | 'secondary', column: string, literal: string) => {
    const name = newParamName.trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)) return;  // the helper says why
    // The literal the query holds today becomes the parameter's value, so the
    // feed keeps running exactly as before until a template's matrix (or an
    // operator) gives it another.
    setFormExtraParams(prev => (prev[name] === undefined ? { ...prev, [name]: literal } : prev));
    setBinding(side, column, literal, name);
    setNewParamFor(null);
    setNewParamName('');
  };

  // ── Deep-link support: open Create dialog pre-filled when the page
  // is navigated from CQB / BQB via the "Create Feed…" menu.  URL
  // contract:
  //
  //     /feeds?source_type=saved_query&source_id=42
  //     /feeds?source_type=sql_file&source_id=7&name=daily-trades
  //
  // Auto-opens the create dialog and pre-selects the source so the
  // user only has to fill in destination + schedule.  Cleans the
  // query string after consuming it so a refresh / back-button
  // doesn't re-trigger.  No-op if the parameters are missing or
  // reference a source we don't recognise.
  const _location = useLocation();
  const _navigate = useNavigate();
  const _deepLinkAppliedRef = React.useRef(false);
  // Where a deep-linked hand-off came from: Cancel goes back there
  // (utils/returnTo.ts); a saved feed stays on this page.
  const _returnTripRef = React.useRef<ReturnTrip | null>(null);
  const cancelDialog = () => {
    setDialogOpen(false);
    const trip = _returnTripRef.current;
    _returnTripRef.current = null;
    if (trip) _navigate(trip.path, { state: returnState(trip) });
  };
  useEffect(() => {
    if (_deepLinkAppliedRef.current) return;
    const params = new URLSearchParams(_location.search);
    // 2026-10-13 -- ?edit=<feed id>: open that feed's form (the board's
    // "Configuration" view links here); Cancel goes back to the board.
    const editId = Number(params.get('edit'));
    if (params.get('edit') && Number.isFinite(editId) && editId > 0) {
      _deepLinkAppliedRef.current = true;
      _returnTripRef.current = returnTripFrom(params);
      api.getFeed(editId)
        .then((f: any) => openEdit(f))
        .catch((e: any) => setError(`Feed ${editId} could not be opened: ${e?.message || e}`));
      _navigate(_location.pathname, { replace: true });
      return;
    }
    const stype = params.get('source_type');
    const sid = params.get('source_id');
    const suggestedName = params.get('name');
    if (!stype || !sid) return;
    // Validate against known source types
    if (!['saved_query', 'published_view', 'sql_file', 'raw_sql'].includes(stype)) return;
    const sidNum = Number(sid);
    if (!Number.isFinite(sidNum) || sidNum < 0) return;

    _deepLinkAppliedRef.current = true;
    _returnTripRef.current = returnTripFrom(params);
    setEditFeed(null);
    resetForm();
    setFormSourceType(stype);
    setFormSourceId(sidNum);
    // The hand-off passes the saved query's own name ("snowflake test
    // feed"); it is normalised VISIBLY like a typed one.
    if (suggestedName) setFormName(normalizeFeedNameInput(suggestedName));
    // Async — open dialog after lookups load so the source picker shows
    // the resolved name immediately rather than an ID placeholder.
    loadLookups().then(() => setDialogOpen(true));
    // Strip the deep-link query string so the dialog doesn't re-open on
    // a Refresh button click.
    _navigate(_location.pathname, { replace: true });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_location.search]);

  // ── Latest execution per feed (2026-09-14) ───────────────────────────
  // The full Execution History now lives on /feeds/today ("All
  // executions" tab).  What stays here is the one question an AUTHOR
  // asks on this page -- "does my feed work?" -- answered by a chip
  // carrying the latest execution's status, row count and age, and a
  // "View runs" link into the ops page filtered to that feed.
  //
  // LIVE, the same way the old panel was.  Every refresh is a RE-FETCH
  // of the latest row (real DB state), never an optimistic patch:
  //   1. websocket: any feed_* event for a listed feed → silent re-fetch
  //      of THAT feed's latest, trailing-debounced so a burst of
  //      feed_progress frames coalesces into one request;
  //   2. polling fallback: while any chip is pending/running, re-fetch
  //      those feeds every 5s regardless -- a dropped websocket cannot
  //      freeze the chip.
  // Optional: outside a WebSocketProvider (tests, an embedded mount) the
  // 5s poll is the whole mechanism.
  const _ws = useOptionalWebSocket();
  const _addWsListener = _ws?.addListener ?? null;
  const _feedIdsRef = useRef<number[]>([]);
  useEffect(() => { _feedIdsRef.current = feeds.map(f => f.id); }, [feeds]);
  const _nowTick = useNowTick(30_000);
  const loadLatest = useCallback(async (feedId: number) => {
    try {
      const data = await api.listFeedExecutions(feedId, 1);
      const rows = toArray(data) as FeedExecutionRow[];
      setLatestByFeed(prev => ({ ...prev, [feedId]: { state: 'ok', exec: rows[0] ?? null } }));
    } catch (err: any) {
      setLatestByFeed(prev => ({ ...prev, [feedId]: { state: 'error', error: err?.message || String(err) } }));
    }
  }, []);
  useEffect(() => {
    if (feeds.length === 0) return;
    setLatestByFeed(prev => {
      const next = { ...prev };
      for (const f of feeds) if (!next[f.id]) next[f.id] = { state: 'loading' };
      return next;
    });
    feeds.forEach(f => void loadLatest(f.id));
  }, [feeds, loadLatest]);
  // Debounce timers live in a ref so a re-subscribe cannot cancel a
  // re-fetch already scheduled (same shape as FeedExecutionsPanel).
  const _wsTimersRef = useRef<Map<number, number>>(new Map());
  useEffect(() => () => {
    _wsTimersRef.current.forEach(id => window.clearTimeout(id));
    _wsTimersRef.current.clear();
  }, []);
  useEffect(() => {
    if (!_addWsListener) return undefined;
    const timers = _wsTimersRef.current;
    const unsub = _addWsListener((msg) => {
      try {
        const t = String((msg as any)?.type || '');
        if (!t.startsWith('feed_')) return;
        const feedId = Number((msg as any).feed_id);
        if (!feedId || !_feedIdsRef.current.includes(feedId)) return;
        const prev = timers.get(feedId);
        if (prev != null) window.clearTimeout(prev);
        timers.set(feedId, window.setTimeout(() => {
          timers.delete(feedId);
          void loadLatest(feedId);
        }, 300));
      } catch { /* fail-open */ }
    });
    return unsub;
  }, [_addWsListener, loadLatest]);
  const filteredFeeds = useMemo(() => {
    const term = feedSearch.trim().toLowerCase();
    if (!term) return feeds;
    return feeds.filter((f: any) => (
      String(f.name || '').toLowerCase().includes(term)
      || String(f.description || '').toLowerCase().includes(term)
      || String(f.source_type || '').toLowerCase().includes(term)
      || String(f.destination_type || '').toLowerCase().includes(term)
    ));
  }, [feeds, feedSearch]);

  const pagedFeeds = useMemo(
    () => filteredFeeds.slice(feedPage * feedRowsPerPage,
                              feedPage * feedRowsPerPage + feedRowsPerPage),
    [filteredFeeds, feedPage, feedRowsPerPage]);

  // a narrowed list has fewer pages; staying on page 4 of 1 shows nothing
  useEffect(() => { setFeedPage(0); }, [feedSearch, feedRowsPerPage]);

  const _liveFeedKey = useMemo(() => Object.entries(latestByFeed)
    .filter(([, v]) => v.state === 'ok' && v.exec != null && isLiveStatus(v.exec.status))
    .map(([id]) => id).sort().join(','), [latestByFeed]);
  useEffect(() => {
    if (!_liveFeedKey) return undefined;
    const ids = _liveFeedKey.split(',').map(Number);
    const id = window.setInterval(() => { ids.forEach(f => void loadLatest(f)); }, 5000);
    return () => window.clearInterval(id);
  }, [_liveFeedKey, loadLatest]);

  // ── Dialog helpers ─────────────────────────────────────────────────────────

  const resetForm = () => {
    setCloneOf(null);
    setApplyMode('next_run');
    setApplyFromDate('');
    setFormName('');
    setFormDisplayName('');
    // 2026-10-03 -- these were never reset: "New Task" after editing a
    // feed opened with THAT feed's SLA, retries, validity window, spark
    // size and consumer groups, and saved them onto the new feed.
    setFormSlaFrom('');
    setFormSlaTo('');
    setFormSlaTimezone('');
    setFormSlaFromLegacy(null);
    setFormSlaToLegacy(null);
    setFormMaxRetries('');
    setFormRetryDelay('');
    setFormSparkSizeClass('');
    setFormPartitionColumns('');
    setFormPartitionOrder('');
    setFormPartitionConcurrent('');
    setFormValidFrom('');
    setFormValidUntil('');
    setFormConsumerGroupIds([]);
    setFormShape(EMPTY_SHAPE_DRAFT);
    setFormContractOpts(CONTRACT_DEFAULTS);
    setFormTaskType('file_feed');
    setFormWhereClauses([]);
    setFormDescription('');
    setFormSourceType('saved_query');
    setFormSourceId('');
    setFormConnectionId('');
    setFormRawSql('');
    setFormConnOverridden(false);
    setFormOutputFormat('csv');
    setFormFilenameTemplate('');
    setFormDestType('local');
    // Pre-fill the platform default output (NFS) directory for new feeds; the
    // user can override it.  Blank on save still falls back to the same default
    // server-side (buildDestConfig + _deliver_local).
    setFormDestPath(defaultOutputDir || '');
    setFormDestBucket('');
    setFormDestPrefix('');
    setFormDestSftp({ port: 22, remote_dir: '/' });
    setFormDestStored(null);
    setFormDestOracle(EMPTY_ORACLE_DEST_DRAFT);
    setFormBackend('auto');
    setFormSizeThresholdRows('');
    setFormScheduleEnabled(false);
    setFormCron('');
    setFormTimezone('UTC');
    setFormSchedule(EMPTY_SCHEDULE_DRAFT);
    setFormDeliveryChain(EMPTY_DELIVERY_CHAIN_DRAFT);
    setFormNotifySuccess(false);
    setFormNotifyFailure(true);
    setFormNotifyEmails('');
    // Phase 130 hotfix-2 — cross-source defaults
    setFormCrossSourceEnabled(false);
    setFormSecondaryConnectionId('');
    setFormCombineMode('union');
    setFormJoinKeysLeft('');
    setFormJoinKeysRight('');
    setFormJoinType('INNER');
    setFormSecondarySourceMode('same');
    setFormSecondarySourceId('');
    setFormSecondaryRawSql('');
    setFormTokenBindings([]);
    setFormExtraParams({});
    setNewParamFor(null);
    setNewParamName('');
    setDraftResolve(null);
    setDraftResolveError('');
    setFormControlFileTemplate('');
    setFormControlFileFormatId('');
    setFormOwnerGroupId('');
    setFormFeedGroupId('');
    setFormCalendarName('');
    setFormFrequencyCategory('');  // BF-473
    // Phase 131 — production-controls defaults
    setFormRowCountAction('off');
    setFormRowCountCompareTo('baseline');
    setFormRowCountThresholdPct('');
    setFormIntegrityCheck('inherit');
    setFormDeps([]);
    setDepsLoad({ state: 'loaded' });   // a new feed has none -- KNOWN
    setNewDepTypeId('');
    setNewDepKey('');
    setNewDepDesc('');
    setNewDepCalendar('');
    setNewDepSources([]);
    setActiveStep(0);
  };

  const openCreate = async () => {
    setEditFeed(null);
    resetForm();
    // await so the dialog opens with populated dropdowns rather than
    // a flash of "No saved queries available" before the GET resolves.
    await loadLookups();
    setDialogOpen(true);
  };

  // The feed's dependency list for the edit dialog.  2026-10-03: a failure
  // here was swallowed ("leave empty") and the save then PUT [] -- wiping
  // every mapping.  Now the state is loading / loaded / failed, the save
  // sends the list ONLY when it was read, and the step offers a Retry.
  const loadEditDeps = (feedId: number) => {
    setDepsLoad({ state: 'loading' });
    // 2026-07-03 audit fix: use safeFetch so cross-origin apiUrl is
    // honoured; prior direct fetch went same-origin and returned
    // the SPA catch-all HTML.
    safeFetch(`/api/feeds/${feedId}/dependencies`)
      .then((data) => {
        if (!data || !Array.isArray(data.items)) {
          // A 200 with no list is not "no dependencies".
          throw new Error('the server returned no dependency list');
        }
        setFormDeps(data.items.map((it: any) => ({
          id: it.id,
          dependency_type_id: it.dependency_type_id,
          dependency_type: it.dependency_type,
          dependency_key: it.dependency_key,
          description: it.description,
          arrival_sources: Array.isArray(it.arrival_sources) ? it.arrival_sources : null,
          require_mode: it.require_mode ?? null,
          calendar_name: it.calendar_name ?? null,
          reruns_delivered: it.reruns_delivered ?? null,
          certifies_side: it.certifies_side ?? null,
          expected_rows: it.expected_rows ?? null,
        })));
        setDepsLoad({ state: 'loaded' });
      })
      .catch((e: unknown) => {
        setDepsLoad({ state: 'failed', message: describeLoadError(e).message });
      });
  };

  /** Clone in the full form: everything of ``feed``, a new name, saved as a
   *  new feed (its dependencies too).  The form's own rules apply. */
  const openClone = async (feed: FeedConfig) => {
    await openEdit(feed);
    setEditFeed(null);
    setCloneOf({ id: feed.id, name: feed.name });
    setFormName(normalizeFeedNameInput(`${feed.name}_COPY`));
    setFormDisplayName('');
  };

  const openEdit = async (feed: FeedConfig) => {
    setCloneOf(null);
    setEditFeed(feed);
    setFormName(feed.name);
    setFormDisplayName(feed.display_name || '');
    // Hydrate the SHAPE from query_params._partition (absent = single-file).
    const _shape = ((feed.query_params || {}) as any)._partition;
    if (_shape && typeof _shape === 'object' && !Array.isArray(_shape)) {
      setFormShape({
        enabled: true,
        columns: Array.isArray(_shape.columns)
          ? _shape.columns.map(String)
          : (_shape.columns ? [String(_shape.columns)] : []),
        values: Array.isArray(_shape.values) ? _shape.values.map(String).join('\n') : '',
        valuesSql: String(_shape.values_sql || _shape.sql || ''),
        maxParts: _shape.max_parts != null ? String(_shape.max_parts) : '',
        onEmpty: _shape.on_empty === 'skip' ? 'skip' : 'fail',
      });
    } else {
      setFormShape(EMPTY_SHAPE_DRAFT);
    }
    // Hydrate the CONTRACT terms from output_options.
    setFormContractOpts(hydrateContractOpts(feed.output_options));
    const _mr = (feed as any).max_retries;
    setFormMaxRetries(_mr == null ? '' : String(_mr));
    const _rd = (feed as any).retry_delay_seconds;
    setFormRetryDelay(_rd == null ? '' : String(_rd));
    setFormSparkSizeClass(
      ((feed as any).backend_config || {}).spark_size_class || '');
    {
      const pc = ((feed as any).backend_config || {}).partition_config || {};
      setFormPartitionColumns(columnsText(pc.columns ?? pc.column));
      setFormPartitionOrder(columnsText(pc.order_within));
      setFormPartitionConcurrent(pc.max_concurrent == null ? '' : String(pc.max_concurrent));
    }
    // The picker shows HH:MM; a stored value it cannot show exactly is
    // kept apart as `legacy` (read-only, never resent).
    const _hydrateSla = (raw: any, set: (v: string) => void,
                         setLegacy: (v: string | null) => void) => {
      const p = parseSlaTime(raw);
      if (p && 'hour' in p) { set(`${p.hour}:${p.minute}`); setLegacy(null); }
      else { set(''); setLegacy(p && 'unrepresentable' in p ? p.unrepresentable : null); }
    };
    _hydrateSla((feed as any).sla_from, setFormSlaFrom, setFormSlaFromLegacy);
    _hydrateSla((feed as any).sla_to, setFormSlaTo, setFormSlaToLegacy);
    setFormSlaTimezone((feed as any).sla_timezone || '');
    setFormValidFrom((feed as any).valid_from || '');
    setFormValidUntil((feed as any).valid_until || '');
    setFormTaskType((feed as any).task_type || 'file_feed');
    setFormDescription(feed.description || '');
    setFormSourceType(feed.source_type);
    setFormSourceId(feed.source_id);
    setFormConnectionId(feed.connection_id || '');
    setFormRawSql(((feed.query_params || {}) as any).sql || '');
    // Phase 132.38 — restore the publisher's WHERE-mapping from the
    // sentinel key inside query_params so re-opening the dialog
    // re-renders the Dynamic / Static toggles + values.
    const _wcm = ((feed.query_params || {}) as any)._where_clauses_mapping;
    setFormWhereClauses(Array.isArray(_wcm)
      ? _wcm.map((r: any) => ({
          column: r?.column || '',
          operator: r?.operator || 'eq',
          value: r?.value ?? '',
          mode: (r?.mode === 'static' ? 'static' : 'dynamic') as 'static' | 'dynamic',
        }))
      : []);
    // Edit mode: assume the saved connection was admin's deliberate
    // choice — don't auto-derive on first render or we'd clobber it.
    setFormConnOverridden(true);
    // Wait for the lookup lists BEFORE opening so the source +
    // connection pickers can resolve their value-by-id lookups
    // immediately (otherwise edit shows empty fields for 200-500 ms).
    await loadLookups();
    setFormOutputFormat(feed.output_format);
    setFormFilenameTemplate(feed.output_filename_template || '');
    setFormDestType(feed.destination_type);
    const dc = feed.destination_config || {};
    setFormDestPath(dc.path || '');
    setFormDestBucket(dc.bucket || '');
    setFormDestPrefix(dc.prefix || '');
    setFormDestSftp(feed.destination_type === 'sftp'
      ? { port: 22, remote_dir: '/', ...dc }
      : { port: 22, remote_dir: '/' });
    setFormDestStored({ type: feed.destination_type, config: { ...dc } });
    setFormDestOracle(hydrateOracleDestinationDraft(dc));
    setFormBackend(feed.execution_backend || 'auto');
    setFormSizeThresholdRows(
      feed.size_threshold_rows != null ? String(feed.size_threshold_rows) : ''
    );
    setFormScheduleEnabled(feed.schedule_enabled);
    setFormCron(feed.cron_expression || '');
    setFormTimezone(feed.timezone || 'UTC');
    // Hydrate the DECLARED schedule (undeclared feeds get the untouched
    // empty draft, so saving them keeps sending no declaration at all).
    setFormSchedule(hydrateScheduleDraft((feed as any).schedule_declaration));
    // Hydrate the DELIVERY chain (chainless feeds get the untouched
    // empty draft, so saving them keeps sending no delivery_chain key).
    setFormDeliveryChain(hydrateDeliveryChainDraft((feed as any).delivery_chain));
    // Cross-source hydrate
    const _qpStored: Record<string, any> = (feed.query_params as any) || {};
    if (feed.secondary_connection_id) {
      setFormCrossSourceEnabled(true);
      setFormSecondaryConnectionId(feed.secondary_connection_id);
      setFormCombineMode((feed.combine_mode === 'join' ? 'join' : 'union'));
      const jc: any = feed.join_config || {};
      setFormJoinKeysLeft(Array.isArray(jc.left_on) ? jc.left_on.join(',') : (jc.left_on || ''));
      setFormJoinKeysRight(Array.isArray(jc.right_on) ? jc.right_on.join(',') : (jc.right_on || ''));
      setFormJoinType((jc.how || 'INNER').toUpperCase());
      // 2026-10-11 -- the second side's SOURCE
      const _sst = String(feed.secondary_source_type || '');
      if (_sst === 'raw_sql') {
        setFormSecondarySourceMode('raw_sql');
        setFormSecondarySourceId('');
        setFormSecondaryRawSql(String(_qpStored.secondary_raw_sql || ''));
      } else if (_sst && feed.secondary_source_id) {
        setFormSecondarySourceMode('saved_query');
        setFormSecondarySourceId(feed.secondary_source_id);
        setFormSecondaryRawSql('');
      } else {
        setFormSecondarySourceMode('same');
        setFormSecondarySourceId('');
        setFormSecondaryRawSql('');
      }
    } else {
      setFormCrossSourceEnabled(false);
      setFormSecondaryConnectionId('');
      setFormCombineMode('union');
      setFormJoinKeysLeft('');
      setFormJoinKeysRight('');
      setFormJoinType('INNER');
      setFormSecondarySourceMode('same');
      setFormSecondarySourceId('');
      setFormSecondaryRawSql('');
    }
    // 2026-10-11 -- token bindings + the feed's own scalar parameters
    setFormTokenBindings(toArray((feed as any).token_bindings).filter(
      (b: any) => b && typeof b === 'object' && b.column && b.token) as TokenBinding[]);
    setFormExtraParams(scalarFeedParams(_qpStored));
    setNewParamFor(null);
    setNewParamName('');
    setDraftResolve(null);
    setDraftResolveError('');
    setFormControlFileTemplate(feed.control_file_template || '');
    setFormControlFileFormatId(feed.control_file_format_id || '');
    // Phase 130 hotfix-13 — hydrate Owner Group + Calendar so editing
    // preserves the entitlement / calendar associations.
    setFormOwnerGroupId(((feed as any).owner_group_id ?? '') || '');
    setFormConsumerGroupIds(toArray((feed as any).consumer_group_ids).map((g: any) => Number(g)).filter((g: number) => Number.isFinite(g)));
    setFormFeedGroupId(((feed as any).feed_group_id ?? '') || '');
    setFormCalendarName((feed as any).calendar_name || '');
    setFormFrequencyCategory((feed as any).frequency_category || '');  // BF-473
    // Phase 131 — production controls
    setFormRowCountAction(((feed as any).row_count_action || 'off') as 'off'|'warn'|'fail'|'hold');
    setFormRowCountCompareTo((feed as any).row_count_compare_to === 'previous' ? 'previous' : 'baseline');
    const _thr = (feed as any).row_count_threshold_pct;
    setFormRowCountThresholdPct(_thr == null ? '' : String(_thr));
    const _ic = (feed as any).integrity_check_enabled;
    setFormIntegrityCheck(_ic === true ? 'on' : _ic === false ? 'off' : 'inherit');
    // Phase 131-A — load existing dependencies for this feed (loadEditDeps:
    // a failure is SHOWN on the step and the save leaves them untouched).
    setFormDeps([]);
    loadEditDeps(feed.id);
    setActiveStep(0);
    setDialogOpen(true);
  };

  // ── Source / connection picker helpers ─────────────────────────────────────

  /** Returns the connection_id implied by the currently-picked source, or null. */
  const sourceImplicitConnectionId = useCallback((): number | null => {
    if (!formSourceId) return null;
    if (formSourceType === 'saved_query') {
      const q = savedQueries.find(x => x.id === formSourceId);
      return q?.query_config?.connection_id ?? null;
    }
    if (formSourceType === 'published_view') {
      const v = publishedViews.find(x => x.id === formSourceId);
      return v?.connection_id ?? null;
    }
    if (formSourceType === 'sql_file') {
      const s = sqlFilesList.find(x => x.id === formSourceId);
      return s?.connection_id ?? null;
    }
    return null;
  }, [formSourceId, formSourceType, savedQueries, publishedViews, sqlFilesList]);

  // Auto-derive connection from the picked source — but only when the
  // user hasn't manually overridden it.  Switching source type resets
  // both the picked source and the override flag (see source-type
  // onChange below) so a fresh source can populate a fresh connection.
  useEffect(() => {
    if (formConnOverridden) return;
    if (formSourceType === 'raw_sql') return;  // raw_sql has no implicit conn
    const implicit = sourceImplicitConnectionId();
    if (implicit && implicit !== formConnectionId) {
      setFormConnectionId(implicit);
    }
  }, [formSourceId, formSourceType, formConnOverridden, sourceImplicitConnectionId, formConnectionId]);

  const connectionLabel = (id: number | null | undefined): string => {
    if (!id) return '';
    const c = connections.find(x => x.id === id);
    return c ? `${c.name}` : `Connection ${id}`;
  };

  const sourceSummary = useCallback((feed: FeedConfig): string => {
    if (feed.source_type === 'saved_query') {
      const q = savedQueries.find(x => x.id === feed.source_id);
      return q?.name || `Saved query #${feed.source_id}`;
    }
    if (feed.source_type === 'published_view') {
      const v = publishedViews.find(x => x.id === feed.source_id);
      return v ? `${v.name} (${v.slug})` : `Published view #${feed.source_id}`;
    }
    if (feed.source_type === 'sql_file') {
      const s = sqlFilesList.find(x => x.id === feed.source_id);
      return s?.name || `SQL file #${feed.source_id}`;
    }
    if (feed.source_type === 'raw_sql') {
      return 'Inline SQL';
    }
    return `#${feed.source_id}`;
  }, [savedQueries, publishedViews, sqlFilesList]);

  // BRD STEP 1 — refuse at authoring with the SAME rules the backend
  // enforces (core/feed/identity.py).  Shown only once the author has
  // typed something; the server remains the authority and its 422
  // message is surfaced on save regardless.
  // A feed that has RUN cannot be renamed (the name is burned into
  // archives, alert keys and filenames) — the API 409s; the UI locks the
  // field and points at display_name, exactly as the refusal message does.
  const _nameLocked = Boolean(editFeed && (editFeed.run_count || 0) > 0);
  // 2026-10-03 -- the EXACT name a save sends.  The field normalises as
  // the author types (feedAuthoringRules.normalizeFeedNameInput) and the
  // helper says "Saved as <this>".  An edit that leaves the stored name
  // untouched sends it verbatim (a legacy spelling is not rewritten).
  const _savedName = useMemo(
    () => (editFeed && formName === editFeed.name
      ? formName : feedNameForSave(formName)),
    [formName, editFeed]);
  const _nameError = useMemo(
    () => (_savedName ? validateFeedName(_savedName) : null), [_savedName]);
  // The SHAPE refusals (core/feed/partition_shape.py::read_shape) — the
  // engine raises these at admission; refusing here means never mid-run.
  const _shapeErrors = useMemo(() => partitionShapeErrors(formShape), [formShape]);
  const _shapeHints = useMemo(() => partitionShapeHints(formShape), [formShape]);
  // The CONTRACT refusals reachable through this editor (contract.py
  // SEVERITY_ERROR → API 422) and the live "unsupported today" hints
  // (SEVERITY_UNSUPPORTED → saved with contract_unsupported warnings).
  const _contractErrors = useMemo(() => contractErrors(formContractOpts), [formContractOpts]);
  const _contractHints = useMemo(() => contractUnsupportedHints(formContractOpts), [formContractOpts]);
  // The DECLARED-schedule refusals (core/feed/schedule.py::parse_schedule)
  // — the same rules the backend enforces, shown while typing.
  const _scheduleErrors = useMemo(
    () => scheduleDeclarationErrors(formSchedule), [formSchedule]);
  // 2026-10-03 -- on_completion_of names an EXISTING feed, picked from the
  // list (never this one).  A stored name that is no feed any more stays
  // visible as an option so it is SEEN, and is flagged; the server
  // refuses it (422) as well.
  const _upstreamOptions = useMemo(() => {
    const self = (editFeed?.name || '').toUpperCase();
    const names = feeds.map(f => f.name)
      .filter(n => n && n.toUpperCase() !== self);
    const cur = formSchedule.upstreamFeed;
    return cur && !names.includes(cur) ? [cur, ...names] : names;
  }, [feeds, editFeed, formSchedule.upstreamFeed]);
  const _upstreamUnknown = Boolean(
    formSchedule.declared && formSchedule.kind === 'on_completion_of'
    && formSchedule.upstreamFeed && feeds.length > 0
    && !feeds.some(f => (f.name || '').toUpperCase()
      === formSchedule.upstreamFeed.toUpperCase()));
  // ── Schedule preview (GET /api/feeds/schedule-preview) ───────────────
  // The step shows the SERVER's own answer for the unsaved declaration
  // (parse_schedule + due_on + BusinessCalendar — cannot drift from
  // runtime).  Four hard rules, each a real failure mode:
  //   1. the server's three states stay three ON SCREEN;
  //   2. a changed declaration NEVER keeps the old answer on screen —
  //      pending replaces it until the new answer lands;
  //   3. a failed preview reads "could not compute", never "no dates",
  //      and never blocks saving (nothing here feeds _stepBlocked);
  //   4. a slow response for an OLDER declaration cannot overwrite a
  //      newer one (request-id check below).
  const [schedulePreview, setSchedulePreview] =
    useState<SchedulePreviewState>({ phase: 'idle' });
  const schedulePreviewReqId = useRef(0);
  // One string key = "what we would ask the server".  null = nothing to
  // preview — NO request is fired at all.  Two guards, each a tested
  // property: a declaration the client already refuses is never sent
  // (the server would only 422 it back), and no declaration at all
  // (buildScheduleDeclaration returns null for an undeclared draft)
  // means no request.
  const _schedulePreviewKey = useMemo(() => {
    if (_scheduleErrors.length > 0) return null;
    const decl = buildScheduleDeclaration(formSchedule);
    if (!decl) return null;
    return JSON.stringify({
      declaration: decl, calendar_name: formCalendarName || null,
    });
  }, [formSchedule, _scheduleErrors, formCalendarName]);
  useEffect(() => {
    // Invalidate any in-flight request FIRST: whatever lands later is
    // about a declaration that is no longer on screen.
    const myId = ++schedulePreviewReqId.current;
    if (_schedulePreviewKey == null) {
      setSchedulePreview({ phase: 'idle' });
      return undefined;
    }
    // Pending IMMEDIATELY — the previous dates are about the PREVIOUS
    // declaration and must not sit on screen under the new rule.
    setSchedulePreview({ phase: 'pending' });
    const { declaration, calendar_name } = JSON.parse(_schedulePreviewKey);
    const timer = setTimeout(() => {
      api.previewSchedule(declaration, calendar_name || undefined)
        .then((data: SchedulePreviewResponse) => {
          if (schedulePreviewReqId.current !== myId) return; // stale
          setSchedulePreview({ phase: 'ready', data });
        })
        .catch((err: any) => {
          if (schedulePreviewReqId.current !== myId) return; // stale
          setSchedulePreview({
            phase: 'unavailable',
            message: err?.message
              || 'the preview endpoint could not be reached',
          });
        });
    }, SCHEDULE_PREVIEW_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [_schedulePreviewKey]);
  // The DELIVERY-chain refusals (api/feed_api.py::
  // _refuse_invalid_delivery_chain) — the same rules the backend 422s
  // on, shown while typing.
  const _deliveryChainErrors = useMemo(
    () => deliveryChainErrors(formDeliveryChain), [formDeliveryChain]);

  // Validation gate for Step 0 / Save button.  raw_sql is the only path
  // that needs the SQL textarea + a connection; every other path needs
  // a picked source (its connection is auto-derived).
  // 2026-10-11 -- a SECOND SIDE is declared whole or not at all (the server
  // refuses the half-declared shape with the same reasons, 422).
  const _crossSourceProblem = useMemo((): string | null => {
    if (!formCrossSourceEnabled) return null;
    if (!formSecondaryConnectionId) {
      return 'Pick the second connection — a cross-source feed is keyed on it.';
    }
    if (formSecondarySourceMode === 'saved_query' && !formSecondarySourceId) {
      return 'Pick the saved query that runs on the second connection (or choose "the same query" or SQL).';
    }
    if (formSecondarySourceMode === 'raw_sql' && !formSecondaryRawSql.trim()) {
      return 'Type the SQL the second side runs.';
    }
    return null;
  }, [formCrossSourceEnabled, formSecondaryConnectionId, formSecondarySourceMode,
      formSecondarySourceId, formSecondaryRawSql]);
  // 2026-10-12 -- every PARAMETER token the query uses needs a value (the
  // server refuses the save naming them; at run time it would match nothing)
  const _missingParams = useMemo((): string[] =>
    (draftResolve?.query_tokens || [])
      .filter(t => t.kind === 'parameter' && !String(formExtraParams[t.name] ?? '').trim())
      .map(t => t.name),
  [draftResolve, formExtraParams]);
  const _step0Ready = useMemo(() => {
    if (!_savedName || _nameError) return false;
    if (_crossSourceProblem) return false;
    if (_missingParams.length) return false;
    if (formSourceType === 'raw_sql') {
      return Boolean(formRawSql.trim()) && Boolean(formConnectionId);
    }
    return Boolean(formSourceId);
  }, [_savedName, _nameError, formSourceType, formSourceId, formRawSql, formConnectionId,
      _crossSourceProblem, _missingParams]);

  // BF-566 (2026-05-29): destination-step validation.  Previously the
  // wizard's Create button only gated on _step0Ready; a user with an
  // empty bucket / path / host could hit Create and get an opaque
  // backend 500.  Now: per-destination-type required-field check.
  // Oracle connections only: _deliver_oracle builds its DSN from the
  // connection's host/port/service_name, which no other type carries.
  // The id list is null while connections are unknown -- unknown is not
  // empty, so a stored id is never refused on the strength of a list
  // that failed to load.
  const _oracleConnections = useMemo(
    () => connections.filter(
      c => String(c.connection_type || '').toLowerCase() === 'oracle'),
    [connections]);
  const _oracleDestErrors = useMemo(
    () => (formDestType === 'oracle'
      ? oracleDestinationErrors(
          formDestOracle,
          connections.length ? _oracleConnections.map(c => c.id) : null)
      : []),
    [formDestType, formDestOracle, connections, _oracleConnections]);
  const _step3Ready = useMemo(() => {
    if (formDestType === 'local') return Boolean(formDestPath?.trim());
    if (formDestType === 's3') return Boolean(formDestBucket?.trim());
    if (formDestType === 'sftp') return sftpConfigProblems(formDestSftp).length === 0;
    if (formDestType === 'oracle') return _oracleDestErrors.length === 0;
    return true;
  }, [formDestType, formDestPath, formDestBucket,
      formDestSftp, _oracleDestErrors]);
  const _allStepsReady = _step0Ready && _step3Ready
    && _scheduleErrors.length === 0 && !_upstreamUnknown
    && _shapeErrors.length === 0 && _contractErrors.length === 0
    && _deliveryChainErrors.length === 0;

  // Per-step Next gating — a step with a live refusal cannot be left.
  const _stepBlocked = (step: number): boolean => {
    if (step === 0) return !_step0Ready;
    if (step === 1) return _scheduleErrors.length > 0 || _upstreamUnknown; // Schedule
    if (step === 3) return _shapeErrors.length > 0;   // Shape
    if (step === 4) return _contractErrors.length > 0; // Contract
    if (step === 5) { // Delivery
      return _deliveryChainErrors.length > 0 || _oracleDestErrors.length > 0;
    }
    return false;
  };

  // ── Delivery-chain draft helpers ─────────────────────────────────────
  const setHop = (i: number, patch: Partial<DeliveryHopDraft>) =>
    setFormDeliveryChain(prev => ({
      ...prev,
      hops: prev.hops.map((h, j) => (j === i ? { ...h, ...patch } : h)),
    }));
  const addHop = () =>
    setFormDeliveryChain(prev => ({
      ...prev, hops: [...prev.hops, emptyDeliveryHop()],
    }));
  const removeHop = (i: number) =>
    setFormDeliveryChain(prev => ({
      ...prev, hops: prev.hops.filter((_, j) => j !== i),
    }));
  /** Swap hop i with hop i+dir — declared order IS delivery order. */
  const moveHop = (i: number, dir: -1 | 1) =>
    setFormDeliveryChain(prev => {
      const j = i + dir;
      if (j < 0 || j >= prev.hops.length) return prev;
      const hops = [...prev.hops];
      [hops[i], hops[j]] = [hops[j], hops[i]];
      return { ...prev, hops };
    });

  const buildDestConfig = (): Record<string, any> => {
    // Keys the form does not show survive a save of the same destination
    // type (2026-09-24: a save used to rebuild the config from the visible
    // fields and DROP the rest -- a pinned SFTP host key, a key path, an
    // account -- breaking a working feed on its next run).
    const kept = formDestStored && formDestStored.type === formDestType
      ? { ...formDestStored.config } : {};
    if (formDestType === 'local') return { ...kept, path: formDestPath || defaultOutputDir || 'data/feeds' };
    if (formDestType === 's3') return { ...kept, bucket: formDestBucket, prefix: formDestPrefix };
    if (formDestType === 'sftp') {
      const out: Record<string, any> = { ...formDestSftp, port: Number(formDestSftp.port || 22) };
      Object.keys(out).forEach(k => {
        if (out[k] === undefined || (k === 'system_account_id' && out[k] === '')) delete out[k];
      });
      return out;
    }
    if (formDestType === 'oracle') return { ...kept, ...buildOracleDestinationConfig(formDestOracle) };
    return kept;
  };

  const handleSave = async () => {
    const data: Record<string, any> = {
      name: _savedName,
      // BRD STEP 1 — the editable label; the name itself is identity.
      display_name: formDisplayName.trim() || undefined,
      task_type: formTaskType,
      description: formDescription || undefined,
      source_type: formSourceType,
      // raw_sql has no source row to reference — backend ignores source_id
      // for that path but still requires the field to be an int.
      source_id: formSourceType === 'raw_sql' ? 0 : Number(formSourceId),
      connection_id: formConnectionId ? Number(formConnectionId) : undefined,
      output_format: formOutputFormat,
      output_filename_template: formFilenameTemplate || undefined,
      destination_type: formDestType,
      destination_config: buildDestConfig(),
      execution_backend: formBackend,
      size_threshold_rows: formSizeThresholdRows.trim() === ''
        ? null
        : (Number.isFinite(Number(formSizeThresholdRows))
            ? Math.max(0, Math.floor(Number(formSizeThresholdRows)))
            : null),
      schedule_enabled: formScheduleEnabled,
      cron_expression: formCron || undefined,
      timezone: formTimezone,
      // Blank = inherit the deployment default.  Sent as null so an
      // author can go BACK to inheriting after overriding once; 0 is a
      // real value (no retries) and must not be confused with blank.
      max_retries: formMaxRetries.trim() === ''
        ? null : Math.max(0, Math.floor(Number(formMaxRetries) || 0)),
      retry_delay_seconds: formRetryDelay.trim() === ''
        ? null : Math.max(0, Math.floor(Number(formRetryDelay) || 0)),
      // null, not undefined: an author must be able to CLEAR an SLA.
      // undefined would leave the stored value in place and make the
      // field look editable while being one-way.
      sla_from: formSlaFrom.trim() || null,
      sla_to: formSlaTo.trim() || null,
      sla_timezone: formSlaTimezone.trim() || null,
      valid_from: formValidFrom.trim() || null,
      valid_until: formValidUntil.trim() || null,
      notify_on_success: formNotifySuccess,
      notify_on_failure: formNotifyFailure,
      notify_emails: formNotifyEmails || undefined,
      // Phase 130 — control file template (sidecar .ctl)
      control_file_template: formControlFileTemplate.trim() || null,
      // Phase 130 hotfix-4 — DB-driven CTL format (id; NULL → default)
      control_file_format_id: formControlFileFormatId
        ? Number(formControlFileFormatId)
        : null,
      // Phase 130 hotfix-13 — entitlement + calendar.  Pass null
      // explicitly so editing an existing feed can CLEAR these
      // associations (a previously-grouped feed can become solo).
      owner_group_id: formOwnerGroupId ? Number(formOwnerGroupId) : null,
      // 2026-09-28 -- the consumer declaration; [] clears it.
      consumer_group_ids: formConsumerGroupIds,
      // 2026-09-03 — operational group membership; null clears it.
      feed_group_id: formFeedGroupId ? Number(formFeedGroupId) : null,
      calendar_name: formCalendarName || null,
      // BF-473 — frequency category (open string).  null clears it.
      frequency_category: formFrequencyCategory || null,
      // Phase 131 — production controls (each opt-in, null = inherit
      // system default / disable on this feed).  etl_id is intentionally
      // NOT sent from this page — the backend auto-fills etl_id=feed_id
      // when the user adds at least one upstream dependency via the
      // inline editor below.  Admins who need to align with the OTG
      // side can override via the admin endpoint.
      row_count_action: formRowCountAction,
      row_count_compare_to: formRowCountCompareTo,
      row_count_threshold_pct:
        formRowCountThresholdPct === '' ? null : parseFloat(formRowCountThresholdPct),
      integrity_check_enabled:
        formIntegrityCheck === 'inherit' ? null
        : formIntegrityCheck === 'on' ? true
        : false,
    };
    // Phase 130 hotfix-2 — cross-source combine.  When user enabled
    // it AND picked a secondary connection, send the secondary fields;
    // otherwise explicitly null them so a previously-cross-source feed
    // can be reverted to single-source.
    const _crossOn = Boolean(formCrossSourceEnabled && formSecondaryConnectionId);
    if (_crossOn) {
      data.secondary_connection_id = Number(formSecondaryConnectionId);
      data.combine_mode = formCombineMode;
      if (formCombineMode === 'join') {
        const left = formJoinKeysLeft.split(',').map(s => s.trim()).filter(Boolean);
        const right = formJoinKeysRight.split(',').map(s => s.trim()).filter(Boolean);
        data.join_config = {
          how: formJoinType,
          left_on: left,
          right_on: right,
        };
      } else {
        data.join_config = null;
      }
      // 2026-10-11 -- the second side's SOURCE.  'same' = null (the engine
      // falls back to the primary's source on the second connection).
      if (formSecondarySourceMode === 'saved_query') {
        data.secondary_source_type = 'saved_query';
        data.secondary_source_id = Number(formSecondarySourceId);
      } else if (formSecondarySourceMode === 'raw_sql') {
        data.secondary_source_type = 'raw_sql';
        data.secondary_source_id = null;
      } else {
        data.secondary_source_type = null;
        data.secondary_source_id = null;
      }
    } else {
      data.secondary_connection_id = null;
      data.combine_mode = null;
      data.join_config = null;
      data.secondary_source_type = null;
      data.secondary_source_id = null;
    }
    // 2026-10-11 -- the token bindings: every binding for a side that exists.
    // Sent as a list ([] clears); the server validates each against the SQL
    // that resolves now and stores the normalised shape.
    data.token_bindings = formTokenBindings.filter(
      b => _crossOn || b.side !== 'secondary');
    // BRD §2.1 — the DECLARED schedule (core/feed/schedule.py, feed field
    // `schedule_declaration`).  ABSENCE STAYS ABSENCE: an undeclared
    // draft adds NO key at all, so every existing feed keeps sending
    // exactly today's shape (cron + timezone + calendar).  Only an edit
    // of a feed that HAD a declaration sends an explicit null to clear.
    const _declaredSchedule = buildScheduleDeclaration(formSchedule);
    if (_declaredSchedule) {
      data.schedule_declaration = _declaredSchedule;
    } else if ((editFeed as any)?.schedule_declaration) {
      data.schedule_declaration = null;
    }
    // BRD §11 / §14.2 — the DELIVERY chain (core/feed/delivery_hops.py,
    // feed field `delivery_chain`).  Same absence discipline as the
    // schedule declaration: an undeclared chain adds NO key at all
    // (absent = the legacy single-hop path, byte-for-byte unchanged —
    // and on update, omitting the key is a partial update that leaves a
    // stored chain in force).  Only an edit of a feed that HAD a chain
    // sends an explicit null, the one honest spelling of "remove the
    // chain" (delivery_chain is in the API's _CLEARABLE_NULL_FIELDS).
    const _chain = buildDeliveryChain(formDeliveryChain);
    if (_chain) {
      data.delivery_chain = _chain;
    } else if ((editFeed as any)?.delivery_chain) {
      data.delivery_chain = null;
    }
    // query_params is REPLACED wholesale by the API on update, so start
    // from the stored bag (never clobber reserved keys another surface
    // set) and lay this editor's keys on top:
    //   sql          — raw_sql source text (feed_engine reads it at run)
    //   _partition   — the declared SHAPE (core/feed/partition_shape.py);
    //                  absent = single-file feed, and an ABSENT shape and
    //                  an EMPTY declaration are different things.
    // _where_clauses_mapping is dropped here because the server re-embeds
    // it from the where_clauses field on every save (clear_when_empty).
    const _qp: Record<string, any> = { ...((editFeed?.query_params as any) || {}) };
    delete _qp._where_clauses_mapping;
    if (formSourceType === 'raw_sql' && formRawSql.trim()) {
      _qp.sql = formRawSql.trim();
    }
    // 2026-10-11 -- a raw_sql SECOND side's text, and the feed's own
    // parameters (the {NAME} tokens a binding may name).
    if (_crossOn && formSecondarySourceMode === 'raw_sql' && formSecondaryRawSql.trim()) {
      _qp.secondary_raw_sql = formSecondaryRawSql.trim();
    } else {
      delete _qp.secondary_raw_sql;
    }
    Object.entries(formExtraParams).forEach(([k, v]) => { _qp[k] = v; });
    const _declaredShape = buildPartitionShape(formShape);
    if (_declaredShape) _qp._partition = _declaredShape;
    else delete _qp._partition;
    // Send whenever there is content OR a previously-declared shape must
    // be cleared; an empty bag on a fresh create stays omitted.
    if (Object.keys(_qp).length > 0
        || ((editFeed?.query_params as any) || {})._partition
        || ((editFeed?.query_params as any) || {}).secondary_raw_sql) {
      data.query_params = _qp;
    }
    // The CONTRACT terms (output_options).  Unmanaged engine knobs in the
    // stored bag survive; terms equal to the engine default are omitted
    // so a default contract stays an empty declaration that validates
    // clean (contract.py).
    data.output_options = buildOutputOptions(
      formContractOpts, editFeed?.output_options || {});
    // MERGE, never replace: backend_config also carries keys this form
    // does not own (spark_job_timeout_seconds, spark_extra_conf, the
    // per-feed backend override).  Replacing it wholesale would silently
    // delete an operator's tuning the moment anyone edited the feed.
    {
      const bc: Record<string, any> = { ...(editFeed?.backend_config || {}) };
      if (formSparkSizeClass) bc.spark_size_class = formSparkSizeClass;
      else delete bc.spark_size_class;
      // keys this form does not show (the second side's own key, bucket
      // sizing) are kept; no column = the query is read whole
      const cols = splitColumns(formPartitionColumns);
      if (cols.length) {
        const pc: Record<string, any> = { ...(bc.partition_config || {}) };
        delete pc.column;
        pc.columns = cols;
        const order = splitColumns(formPartitionOrder);
        if (order.length) pc.order_within = order; else delete pc.order_within;
        const conc = parseInt(formPartitionConcurrent, 10);
        if (conc > 0) pc.max_concurrent = conc; else delete pc.max_concurrent;
        bc.partition_config = pc;
      } else {
        delete bc.partition_config;
      }
      data.backend_config = Object.keys(bc).length ? bc : null;
    }
    // Phase 132.38 — submit the publisher's WHERE-mapping as a
    // sibling field.  Backend _embed_where_mapping_in_query_params
    // tucks it into query_params._where_clauses_mapping before
    // persisting.  Empty array clears the mapping on update.
    data.where_clauses = formWhereClauses
      .filter(w => (w.column || '').trim())
      .map(w => ({
        column: w.column.trim(),
        operator: w.operator || 'eq',
        value: w.value ?? null,
        mode: w.mode,
      }));

    // 2026-08-05 — surface WARNING-severity cross-source preflight issues
    // the save response carries (the API returns them next to the saved
    // feed; ERROR-severity issues already block with an HTTP 400).
    const _preflightWarnings = (resp: any): string => {
      const issues = resp?.cross_source_preflight?.issues;
      if (!Array.isArray(issues)) return '';
      return issues
        .filter((i: any) => i?.severity === 'warning')
        .map((i: any) => `[${i.code}] ${i.message}`)
        .join('\n');
    };
    // BRD STEP 1 / FR-ART-01 — the API returns `contract_unsupported`
    // findings (real counterparty terms the platform cannot honour
    // today) and `name_advice` (mutable facts embedded in the name).
    // Both were previously swallowed: an author asking for latin-1 got
    // silence.  Surface them next to the save.
    const _saveWarnings = (resp: any): string => {
      const parts: string[] = [];
      const pf = _preflightWarnings(resp);
      if (pf) parts.push(`Cross-source preflight warnings:\n${pf}`);
      const cu = resp?.contract_unsupported;
      if (Array.isArray(cu) && cu.length > 0) {
        parts.push(
          'Contract terms recorded but NOT honoured by the platform yet '
          + '(the counterparty will not receive them):\n'
          + cu.map((f: any) =>
              `- ${f?.field}: ${f?.message}${f?.rule ? ` [${f.rule}]` : ''}`)
            .join('\n'));
      }
      const na = resp?.name_advice;
      if (Array.isArray(na) && na.length > 0) {
        parts.push('Naming advice:\n' + na.map((w: any) => `- ${w}`).join('\n'));
      }
      // FR-ACC-02.  The feed LANDS DISABLED when acceptance is not yet
      // recorded, and the author ticked the box -- so silence here reads
      // as the product losing their input.  This response field existed
      // for an hour before anything displayed it: the same
      // built-not-wired shape the gate itself was fixing.
      if (resp?.acceptance_hold) {
        parts.push(`Not scheduled yet:\n- ${resp.acceptance_hold}`);
      }
      // Advisory, non-refusing, and every one of them was computed,
      // returned, and displayed nowhere.
      if (resp?.priority_advice) {
        parts.push(`Priority:\n- ${resp.priority_advice}`);
      }
      if (resp?.schedule_note) {
        parts.push(`Schedule:\n- ${resp.schedule_note}`);
      }
      const pd = resp?.partition_drift;
      if (pd?.message) {
        parts.push(`Partition drift (your declaration stays authoritative):\n- ${pd.message}`);
      }
      const cs = resp?.contract_summary;
      if (cs?.pipeline?.length) {
        parts.push(
          `Artifact pipeline (${cs.pipeline_order}):\n- ${cs.pipeline.join(' -> ')}`
          + (cs.deliverables_from_1000_parts > 1
            ? `\n- NOTE: 1,000 parts would ship as ${cs.deliverables_from_1000_parts} files, not one - a stream codec never merges parts`
            : ''));
      }
      return parts.join('\n\n');
    };

    if (editFeed && applyMode === 'from_date' && !applyFromDate) {
      setError('Changes apply from a business date: choose the date (or "The next run").');
      return;
    }
    try {
      let savedId: number | null = null;
      let saveWarnings = '';
      if (editFeed) {
        const updated: any = await api.updateFeed(editFeed.id, data, {
          applyFrom: applyMode === 'from_date' && applyFromDate ? applyFromDate : 'next_run' });
        savedId = editFeed.id;
        saveWarnings = _saveWarnings(updated);
        setSuccess(updated?.definition_applies
          ? `Feed updated — the change ${updated.definition_applies.applies_from
              ? `applies to business dates from ${updated.definition_applies.applies_from} (re-runs included)`
              : 'applies from the next run'}`
          : 'Feed updated successfully');
      } else {
        // cast: handleSave normalises the union of "edit fields" + the
        // conditional query_params so the runtime shape always matches
        // createFeed's signature, but TS can't infer that.
        const created = cloneOf
          ? await api.createFeedFromClone(cloneOf.id, data)
          : await api.createFeed(data as Parameters<typeof api.createFeed>[0]);
        savedId = (created as any)?.id ?? null;
        saveWarnings = _saveWarnings(created);
        setSuccess('Feed created successfully');
      }
      setWarning(saveWarnings ? `Saved with warnings:\n\n${saveWarnings}` : '');
      // Phase 131-A — persist the dependency mappings in a separate
      // atomic call.  Errors here surface as a soft warning so the
      // feed save isn't lost; the user can retry the deps without
      // re-entering everything.
      // 2026-10-03 -- send the list only when it is KNOWN: an edit whose
      // dependency read failed (or has not landed yet) would otherwise PUT
      // [] and delete every mapping.  A new feed with none sends nothing
      // -- a feed needs no dependency (SOD runs it every scheduled day).
      const _sendDeps = savedId != null && depsLoad.state === 'loaded'
        && (editFeed != null || formDeps.length > 0);
      if (savedId != null && depsLoad.state !== 'loaded') {
        setWarning(prev => [prev, 'Dependencies were NOT changed: this '
          + "feed's dependency list was not read (the read failed or had "
          + 'not finished), so saving it would have replaced it blindly.']
          .filter(Boolean).join('\n\n'));
      }
      if (_sendDeps) {
        try {
          // 2026-07-03 audit fix: safeFetch prepends the resolved
          // apiUrl so cross-origin Helm deploys reach the real
          // backend; also gives us auth headers + JSON body handling.
          await safeFetch(`/api/feeds/${savedId}/dependencies`, {
            method: 'PUT',
            body: JSON.stringify({
              dependencies: formDeps.map((d) => ({
                dependency_type_id: d.dependency_type_id,
                dependency_key: d.dependency_key,
                description: d.description ?? null,
                // 2026-09-27 — declared sources travel only when declared;
                // require_mode means nothing without a declaration.
                arrival_sources: d.arrival_sources && d.arrival_sources.length > 0 ? d.arrival_sources : null,
                require_mode: d.arrival_sources && d.arrival_sources.length > 0 ? (d.require_mode || 'all') : null,
                calendar_name: d.calendar_name || null,
                reruns_delivered: d.reruns_delivered ?? null,
                certifies_side: d.certifies_side ?? null,
                expected_rows: d.expected_rows ?? null,
                is_active: true,
              })),
            }),
          });
        } catch (depErr: any) {
          setError(`Feed saved but dependencies failed: ${depErr.message}`);
        }
      }
      _returnTripRef.current = null;
      setDialogOpen(false);
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to save feed');
    }
  };

  // ── Actions ────────────────────────────────────────────────────────────────

  // Phase 132.38 — "Trigger with overrides" dialog.  When the user
  // clicks Run on a feed whose publisher declared at least one Dynamic
  // WHERE row, the dialog opens with one input per Dynamic column so
  // the dashboard caller can supply values at trigger time.  Feeds
  // with no Dynamic rows skip the dialog and trigger immediately —
  // legacy one-click run behaviour is preserved.
  const [runDialogFeed, setRunDialogFeed] = useState<FeedConfig | null>(null);
  const [runOverrides, setRunOverrides] = useState<Record<string, any>>({});

  const _dynamicRowsForFeed = useCallback((feed: FeedConfig): WhereClauseRow[] => {
    const mapping = ((feed.query_params || {}) as any)._where_clauses_mapping;
    if (!Array.isArray(mapping)) return [];
    return mapping
      .filter((r: any) => r?.mode === 'dynamic' && (r?.column || '').trim())
      .map((r: any) => ({
        column: r.column,
        operator: r.operator || 'eq',
        value: r.value ?? '',
        mode: 'dynamic',
      }));
  }, []);

  // 2026-09-27 — Run Now ALWAYS opens the preflight dialog: it takes a
  // business date and shows each dependency's verdict for it, and asks
  // for a reason when anything is not met (the run still goes -- Run Now
  // is operator intent).  The Dynamic WHERE overrides ride the same
  // dialog.
  const handleRun = (feedId: number) => {
    const feed = feeds.find(f => f.id === feedId);
    if (!feed) return;
    const seed: Record<string, any> = {};
    _dynamicRowsForFeed(feed).forEach(r => {
      if (r.value !== null && r.value !== undefined && r.value !== '') {
        seed[r.column] = Array.isArray(r.value) ? r.value.join(',') : r.value;
      }
    });
    setRunOverrides(seed);
    setRunDialogFeed(feed);
  };

  // 2026-09-27 -- a DRY RUN: the whole chain runs (query, format, packaging,
  // compression, checksum, control file, integrity, row-count check) and
  // NOTHING is delivered or certified; the file is a one-day Download
  // Centre item and the run is marked "dry run" on the Today page.
  const handleDryRun = async (feed: FeedConfig) => {
    if (!window.confirm(
      `Dry run ${feed.name}? The whole chain runs and NOTHING is delivered; `
      + 'the produced file is kept in the Download Centre for one day.')) return;
    try {
      const r = await api.executeFeed(feed.id, undefined, { dry_run: true });
      setSuccess(r?.detail || 'Dry run started — nothing will be delivered');
      void loadLatest(feed.id);
    } catch (err: any) {
      setError(err.message || 'Failed to start the dry run');
    }
  };

  const confirmRunWithOverrides = async (runNow: RunNowOptions) => {
    const feed = runDialogFeed;
    if (!feed) return;
    // Strip empty-value entries so the engine sees only what the
    // caller actually supplied (Dynamic w/o override = no filter,
    // matches the PV "Dynamic = optional" contract).
    const payload: Record<string, any> = {};
    Object.entries(runOverrides).forEach(([k, v]) => {
      if (v !== null && v !== undefined && String(v).trim() !== '') {
        payload[k] = v;
      }
    });
    setRunDialogFeed(null);
    try {
      await api.executeFeed(
        feed.id,
        Object.keys(payload).length > 0 ? payload : undefined,
        runNow,
      );
      const bits: string[] = [];
      if (Object.keys(payload).length > 0) bits.push(`overrides: ${Object.keys(payload).join(', ')}`);
      if (runNow.override_reason) bits.push('dependencies overridden, recorded');
      setSuccess(bits.length ? `Feed execution started (${bits.join('; ')})` : 'Feed execution started');
      void loadLatest(feed.id);
    } catch (err: any) {
      setError(err.message || 'Failed to start execution');
    }
  };

  // Preview SQL — fetches the resolved query string from the backend
  // resolver (no execution, no DuckDB connection).  Lets users verify
  // what SQL the feed will run before scheduling / debugging.
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewData, setPreviewData] = useState<any>(null);
  const [previewError, setPreviewError] = useState<string>('');
  const handlePreviewSql = useCallback(async (feedId: number) => {
    setPreviewOpen(true);
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewData(null);
    try {
      const data = await api.get(`/api/feeds/${feedId}/preview-sql`);
      setPreviewData(data);
    } catch (err: any) {
      setPreviewError(err?.detail || err?.message || 'Could not load SQL preview');
    } finally {
      setPreviewLoading(false);
    }
  }, []);
  const copyPreviewSql = useCallback(() => {
    const txt = (previewData?.sql || '') +
      (previewData?.secondary_sql ? `\n\n-- Secondary side (${previewData.combine_mode}):\n${previewData.secondary_sql}` : '');
    if (txt) {
      try { navigator.clipboard.writeText(txt); setSuccess('SQL copied'); } catch {}
    }
  }, [previewData]);

  const handleDelete = async (feedId: number) => {
    // Deactivation is destructive (stops scheduled runs) — confirm first, in
    // line with every other mutating action on the dashboard.
    if (!window.confirm('Deactivate this feed? It will stop running on its schedule.')) return;
    try {
      await api.deleteFeed(feedId);
      setSuccess('Feed deactivated');
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to deactivate feed');
    }
  };

  const openDataflowPreview = async (feed: any) => {
    setDfFeedName(feed?.name || `Feed ${feed?.id}`);
    setDfPreview(null);
    setDfLoading(true);
    setDfOpen(true);
    try {
      const res: any = await safeFetch(`/api/feeds/${feed.id}/dataflow-preview`);
      setDfPreview(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to load DataFlow preview');
      setDfOpen(false);
    } finally {
      setDfLoading(false);
    }
  };

  const handleToggleSchedule = async (feed: FeedConfig) => {
    try {
      if (feed.schedule_enabled) {
        await api.disableSchedule(feed.id);
        setSuccess('Schedule disabled');
      } else {
        await api.enableSchedule(feed.id);
        setSuccess('Schedule enabled');
      }
      loadFeeds();
    } catch (err: any) {
      setError(err.message || 'Failed to toggle schedule');
    }
  };

  const handleTestDest = async (feedId: number) => {
    try {
      const result = await api.testDestination(feedId);
      if (result.success) {
        setSuccess(result.message || 'Destination test passed');
      } else {
        setError(result.message || 'Destination test failed');
      }
    } catch (err: any) {
      setError(err.message || 'Test failed');
    }
  };

  // Retry / cancel / steps / download for an execution live on the
  // executions tab of /feeds/today (FeedExecutionsPanel).

  // ── Render Helpers ─────────────────────────────────────────────────────────

  const formatBytes = (bytes: number) => {
    if (!bytes) return '-';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  const formatDuration = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return '-';
    if (seconds < 60) return `${seconds.toFixed(1)}s`;
    return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
  };


  // ── Main Render ────────────────────────────────────────────────────────────

  return (
    // 2026-10-22 (the owner: "everything in center ... should utilize space"):
    // the page used to be capped at 1400px and centred -- a wide screen showed
    // empty margins while the table's columns wrapped.  It uses the width now.
    <Box sx={{ p: { xs: 2, md: 3 } }} data-testid="feeds-page">
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" fontWeight={600}>Feed File Generation</Typography>
        <Stack direction="row" spacing={1}>
          {/* Admin-only ad-hoc background-job triggers.  SOD + SLA both
              normally run on the configured cron schedule (no manual
              click needed for daily ops) — these buttons are here so
              admins can force a run after creating new feeds, after a
              missed window, or for testing.  Not on the monitoring
              dashboard — that view is read-only. */}
          {isAdmin && (
            <>
              <Tooltip title="Force-run the SOD generator now (admin only).  Normally runs daily on schedule.">
                <span>
                  <Button
                    startIcon={<SodIcon />}
                    onClick={handleRunSodNow}
                    disabled={adminBusy}
                    variant="outlined"
                  >Run SOD Now</Button>
                </span>
              </Tooltip>
              <Tooltip title="Force the SLA breach sweep (admin only).  Normally runs every minute.">
                <span>
                  <Button
                    startIcon={<SlaIcon />}
                    onClick={handleSlaSweepNow}
                    disabled={adminBusy}
                    variant="outlined"
                  >SLA Sweep</Button>
                </span>
              </Tooltip>
            </>
          )}
          <Button startIcon={<RefreshIcon />} onClick={loadFeeds} disabled={loading}>Refresh</Button>
          <Tooltip title="Create or update MANY feeds from one parameterised template and a matrix of parameter rows (idempotent; the report names every row's outcome).">
            <span>
              <Button variant="outlined" onClick={() => setBulkTemplateOpen(true)}
                      data-testid="feeds-bulk-template">Bulk from template</Button>
            </span>
          </Tooltip>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>New Task</Button>
        </Stack>
      </Stack>

      {error && <Alert severity="error" onClose={() => setError('')} sx={{ mb: 2 }}>{error}</Alert>}
      {warning && (
        <Alert severity="warning" onClose={() => setWarning('')}
               sx={{ mb: 2, whiteSpace: 'pre-line' }}>
          {warning}
        </Alert>
      )}
      {success && <Alert severity="success" onClose={() => setSuccess('')} sx={{ mb: 2 }}>{success}</Alert>}

      {/* Search (FB-49) */}
      {feeds.length > 0 && (
        <TextField
          size="small"
          value={feedSearch}
          onChange={e => setFeedSearch(e.target.value)}
          placeholder="Search feeds"
          inputProps={{ 'aria-label': 'Search feeds' }}
          sx={{ mb: 2, minWidth: 320 }}
          InputProps={{
            startAdornment: <InputAdornment position="start">🔍</InputAdornment>,
          }}
        />
      )}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
      ) : filteredFeeds.length === 0 && feeds.length > 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            No feed matches "{feedSearch.trim()}"
          </Typography>
          <Typography color="text.secondary">
            {feeds.length} feed{feeds.length > 1 ? 's' : ''} exist; none matches this search.
          </Typography>
        </Paper>
      ) : feeds.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography color="text.secondary">No feed configurations yet. Click "New Task" to create one.</Typography>
        </Paper>
      ) : (
        <Paper sx={TABLE_SCROLL_SX}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Source</TableCell>
                <TableCell title="The file format and where it is delivered">Output</TableCell>
                <TableCell>Schedule</TableCell>
                <TableCell>Runs</TableCell>
                <TableCell title="Row count of the last successful run; feeds the auto-router's size decision">
                  Last rows
                </TableCell>
                <TableCell>Status</TableCell>
                <TableCell title="The latest execution of this feed, live; the full history is on Feed Run Status">
                  Last run
                </TableCell>
                <TableCell align="right" sx={STICKY_ACTIONS_SX}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pagedFeeds.map(feed => (
                <React.Fragment key={feed.id}>
                  <TableRow hover>
                    <TableCell>
                      <Typography variant="body2" fontWeight={500}>{feed.name}</Typography>
                      {feed.description && (
                        <Typography variant="caption" color="text.secondary" display="block">
                          {feed.description}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell data-testid={`feed-source-${feed.id}`}>
                      {/* 2026-10-22: two lines, not four -- the kind (+ the second
                          side) on one, what it reads and where on the other */}
                      <Stack direction="row" spacing={0.5} alignItems="center" useFlexGap sx={{ flexWrap: 'nowrap' }}>
                        <Chip size="small"
                              label={SOURCE_TYPE_LABELS[feed.source_type] || feed.source_type}
                              variant="outlined" />
                        {feed.secondary_connection_id && (
                          <Tooltip title={
                            `Cross-source ${(feed.combine_mode || 'union').toUpperCase()} ` +
                            `with ${connectionLabel(feed.secondary_connection_id)}`
                          }>
                            <Chip
                              size="small"
                              color="info"
                              variant="outlined"
                              label={`+${(feed.combine_mode || 'union').toUpperCase()}`}
                              sx={{ height: 18, fontSize: '0.7rem' }}
                            />
                          </Tooltip>
                        )}
                      </Stack>
                      <Tooltip title={`source_id=${feed.source_id}`}>
                        <Typography variant="caption" color="text.secondary"
                                    display="block" sx={{ maxWidth: 320 }} noWrap>
                          {sourceSummary(feed)}
                          {feed.connection_id ? ` · via ${connectionLabel(feed.connection_id)}` : ''}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell data-testid={`feed-output-${feed.id}`} sx={{ whiteSpace: 'nowrap' }}>
                      {/* 2026-10-22: format and destination in ONE column ("CSV -> sftp");
                          two narrow columns pushed Last run under the pinned actions at 1280px */}
                      <Typography variant="body2" component="span">{feed.output_format.toUpperCase()}</Typography>
                      <Typography variant="body2" component="span" color="text.secondary" sx={{ mx: 0.5 }} aria-hidden>→</Typography>
                      <Chip size="small" label={feed.destination_type} variant="outlined" />
                    </TableCell>
                    <TableCell>
                      {feed.schedule_enabled ? (
                        <Tooltip title={feed.cron_expression || ''}>
                          <Chip size="small" label="Active" color="success" icon={<ScheduleIcon />} />
                        </Tooltip>
                      ) : (
                        <Chip size="small" label="Off" variant="outlined" />
                      )}
                    </TableCell>
                    <TableCell>{feed.run_count}</TableCell>
                    <TableCell sx={{ fontVariantNumeric: 'tabular-nums', fontSize: 12 }}>
                      {feed.last_row_count != null
                        ? feed.last_row_count.toLocaleString()
                        : (feed.estimated_row_count != null
                            ? `~${feed.estimated_row_count.toLocaleString()}`
                            : '—')}
                    </TableCell>
                    <TableCell>
                      <Chip
                        size="small"
                        label={feed.is_active ? 'Active' : 'Inactive'}
                        color={feed.is_active ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell>
                      <LatestExecutionCell
                        latest={latestByFeed[feed.id]}
                        feedId={feed.id}
                        now={_nowTick}
                        onRetry={() => void loadLatest(feed.id)}
                      />
                    </TableCell>
                    <TableCell align="right" sx={STICKY_ACTIONS_SX}>
                      {/* 2026-09-24 (screen walk): a feed row carried TWELVE
                          unlabelled icon buttons and at 1280px Edit sat
                          off-screen.  Run now and Edit stay one click away;
                          the rest is a labelled menu (common/RowActions). */}
                      <RowActions rowName={feed.name}
                        primary={[
                          { label: 'Run now', icon: <RunIcon fontSize="small" />,
                            onClick: () => handleRun(feed.id), disabled: !feed.is_active,
                            disabledReason: 'Inactive — activate the feed to run it' },
                          { label: 'Edit', icon: <EditIcon fontSize="small" />,
                            onClick: () => openEdit(feed) },
                        ]}
                        more={[
                          { label: 'Preview SQL', icon: <PreviewSqlIcon fontSize="small" />,
                            description: 'The query this feed will run',
                            onClick: () => handlePreviewSql(feed.id) },
                          { label: 'Dry run', icon: <DryRunIcon fontSize="small" />,
                            description: 'Whole chain, nothing delivered; file kept one day',
                            onClick: () => void handleDryRun(feed), disabled: !feed.is_active,
                            disabledReason: 'Inactive — activate the feed to run it' },
                          { label: 'Test destination', icon: <TestIcon fontSize="small" />,
                            description: 'Can the destination be reached?',
                            onClick: () => handleTestDest(feed.id) },
                          { label: feed.schedule_enabled ? 'Pause schedule' : 'Enable schedule',
                            icon: feed.schedule_enabled ? <PauseIcon fontSize="small" /> : <ScheduleIcon fontSize="small" />,
                            onClick: () => handleToggleSchedule(feed),
                            disabled: !feed.is_active || !feed.cron_expression,
                            disabledReason: !feed.is_active ? 'Inactive feed' : 'No cron schedule set' },
                          { label: 'Step plan', icon: <StepPlanIcon fontSize="small" />, dividerBefore: true,
                            description: 'What will run, in order, and what is skipped',
                            onClick: () => setStepPlanFeed({ id: feed.id, name: feed.name }) },
                          { label: 'View as DataFlow', icon: <DataFlowIcon fontSize="small" />,
                            onClick: () => openDataflowPreview(feed) },
                          { label: 'Delivery attempts', icon: <DeliveryIcon fontSize="small" />,
                            description: 'Per-destination history, retry, acknowledge',
                            onClick: () => setDeliveryFeed({ id: feed.id, name: feed.name }) },
                          { label: 'Backfill', icon: <BackfillIcon fontSize="small" />,
                            description: 'Run past dates (delivery off by default)',
                            onClick: () => setBackfillFeed({ id: feed.id, name: feed.name }) },
                          { label: 'Clone', icon: <CloneIcon fontSize="small" />, dividerBefore: true,
                            description: 'Opens the form with every setting copied — change anything, save as a new feed',
                            onClick: () => void openClone(feed) },
                          { label: 'Lifecycle', icon: <LifecycleIcon fontSize="small" />,
                            description: 'PII, sign-off, legal hold, retire',
                            onClick: () => setLifecycleFeed({ id: feed.id, name: feed.name }) },
                          { label: 'Version history', icon: <VersionsIcon fontSize="small" />,
                            description: 'Every saved or run definition; diff and restore',
                            onClick: () => setVersionsFeed({ id: feed.id, name: feed.name }) },
                          // 2026-09-24: the API DEACTIVATES (the feed and its run
                          // history are kept) -- the confirm and the toast said so,
                          // the menu said "Delete".  Same word as Published Views.
                          { label: 'Deactivate', icon: <DeleteIcon fontSize="small" />, danger: true,
                            description: 'Stops its schedule; the feed and its history are kept',
                            onClick: () => handleDelete(feed.id) },
                        ]} />
                    </TableCell>
                  </TableRow>

                </React.Fragment>
              ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={filteredFeeds.length}
            page={feedPage}
            onPageChange={(_, p) => setFeedPage(p)}
            rowsPerPage={feedRowsPerPage}
            onRowsPerPageChange={e => setFeedRowsPerPage(parseInt(e.target.value, 10))}
            rowsPerPageOptions={[10, 25, 50, 100]}
          />
        </Paper>
      )}

      {/* Create / Edit Dialog */}
      {/* View as DataFlow — read-only feed -> DataFlow stage preview */}
      <Dialog open={dfOpen} onClose={() => setDfOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <DataFlowIcon fontSize="small" /> DataFlow view — {dfFeedName}
        </DialogTitle>
        <DialogContent dividers>
          {dfLoading && (
            <Stack alignItems="center" sx={{ py: 4 }}><CircularProgress size={28} /></Stack>
          )}
          {!dfLoading && dfPreview && (
            <>
              {dfPreview.trigger && (
                <Chip
                  size="small"
                  icon={<ScheduleIcon fontSize="small" />}
                  label={`${dfPreview.trigger.label}: ${dfPreview.trigger.detail}`}
                  sx={{ mb: 2 }}
                />
              )}
              <Stepper orientation="vertical" activeStep={-1}>
                {(dfPreview.steps || []).map((s: any) => (
                  <Step key={s.order} expanded>
                    <StepLabel
                      optional={
                        <Typography variant="caption" color="text.secondary">
                          {s.stage} · {s.detail}{s.note ? ` — ${s.note}` : ''}
                        </Typography>
                      }
                    >
                      {s.label}
                    </StepLabel>
                  </Step>
                ))}
              </Stepper>
              {(!dfPreview.steps || dfPreview.steps.length === 0) && (
                <Typography color="text.secondary">No steps to display.</Typography>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDfOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={dialogOpen} onClose={cancelDialog} maxWidth="md" fullWidth>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Box sx={{ flexGrow: 1 }} data-testid="feed-form-title">
            {editFeed ? 'Edit Task Configuration'
              : cloneOf ? `Clone of ${cloneOf.name} — change anything, then Create`
              : 'New Task Configuration'}
          </Box>
          {/* 2026-09-27 -- the history panel lives on the edit screen: what
              changed, when, by whom, and a restore through the same save. */}
          {editFeed && (
            <Button size="small" variant="outlined" startIcon={<VersionsIcon />}
                    aria-label={`Version history — ${editFeed.name}`}
                    onClick={() => setVersionsFeed({ id: editFeed.id, name: editFeed.name })}>
              Version history
            </Button>
          )}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 1 }}>
            {/* 2026-10-03 -- a list the form could not READ is said, by
                name, with a Retry; it is never shown as an empty list. */}
            {Object.keys(lookupFailures).length > 0 && (
              <Alert severity="warning" sx={{ mb: 2 }}
                     data-testid="feed-form-lookup-errors"
                     action={(
                       <Button size="small" color="inherit" startIcon={<RetryIcon />}
                               onClick={() => void loadLookups()}>Retry</Button>
                     )}>
                Some lists this form offers could not be read — they are
                UNKNOWN, not empty:
                {Object.entries(lookupFailures).map(([what, why]) => (
                  <Box key={what} component="span" sx={{ display: 'block' }}>
                    {what}: {why}
                  </Box>
                ))}
              </Alert>
            )}
            <Stepper activeStep={activeStep} sx={{ mb: 3 }}>
              {STEP_LABELS.map(label => (
                <Step key={label}>
                  {/* 2026-10-03 -- "upstream dependency seems mandatory":
                      a feed needs none (SOD runs it every scheduled day;
                      the gate applies only to a feed that declares one). */}
                  <StepLabel optional={OPTIONAL_STEPS.has(label)
                    ? <Typography variant="caption">Optional</Typography>
                    : undefined}>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>

            {/* Step 0: Source */}
            {activeStep === 0 && (
              <Stack spacing={2}>
                {/* 2026-10-03 -- normalised AS TYPED, visibly: the field
                    shows the normalised spelling and the helper names the
                    exact saved name.  The server still refuses (never
                    rewrites) a bad name sent to it directly. */}
                <TextField label="Task Name" value={formName}
                           onChange={e => setFormName(normalizeFeedNameInput(e.target.value))}
                           required fullWidth size="small"
                           disabled={_nameLocked}
                           error={Boolean(_nameError)}
                           inputProps={{ maxLength: MAX_FEED_NAME_LEN }}
                           FormHelperTextProps={{ 'data-testid': 'feed-name-helper' } as any}
                           helperText={
                             _nameLocked
                               ? 'This feed has already run — its name is permanent identity '
                                 + '(archives, alert keys, filenames are built from it) and cannot '
                                 + 'be changed. To change how it is labelled, edit the Display '
                                 + 'name below.'
                               : (_nameError
                                 || (_savedName
                                   ? `Saved as ${_savedName}. ${FEED_NAME_RULE_HINT} Max ${MAX_FEED_NAME_LEN} characters; permanent once the feed has run — put mutable facts in the display name or description.`
                                   : `Required. ${FEED_NAME_RULE_HINT} Max ${MAX_FEED_NAME_LEN} characters; permanent once the feed has run.`))
                           } />
                <TextField label="Display name (editable label)"
                           value={formDisplayName}
                           onChange={e => setFormDisplayName(e.target.value)}
                           fullWidth size="small"
                           helperText="Free text, always editable — shown wherever a human-friendly label helps. The task name above stays the permanent identity." />
                <FormControl fullWidth size="small">
                  <InputLabel id="task-type-label">Task Type</InputLabel>
                  <Select labelId="task-type-label" label="Task Type"
                          value={formTaskType}
                          onChange={(e) => setFormTaskType(e.target.value as 'file_feed' | 'oracle_push' | 'api_push' | 'custom')}>
                    <MenuItem value="file_feed">File feed (CSV / Parquet / JSON / Excel)</MenuItem>
                    <MenuItem value="oracle_push">Oracle push (insert/merge rows)</MenuItem>
                    <MenuItem value="api_push">API push (POST to REST endpoint)</MenuItem>
                    <MenuItem value="custom">Custom</MenuItem>
                  </Select>
                  <FormHelperText>
                    File feed routes through the existing pipeline today; the other
                    types are reserved for future task kinds.
                  </FormHelperText>
                </FormControl>
                <TextField label="Description" value={formDescription} onChange={e => setFormDescription(e.target.value)}
                           fullWidth size="small" multiline rows={2} />
                <FormControl fullWidth size="small">
                  <InputLabel id="source-type-label">Source Type</InputLabel>
                  <Select labelId="source-type-label" value={formSourceType} label="Source Type"
                          onChange={e => {
                            // Switching type invalidates the current source
                            // pick AND any derived connection; reset both
                            // so the user can't ship a stale source_id from
                            // the previous type.
                            setFormSourceType(e.target.value);
                            setFormSourceId('');
                            setFormConnOverridden(false);
                            setFormConnectionId('');
                          }}>
                    {SOURCE_TYPES.map(t => (
                      <MenuItem key={t} value={t}>{SOURCE_TYPE_LABELS[t] || t}</MenuItem>
                    ))}
                  </Select>
                </FormControl>

                {/* Source picker — shape depends on source_type so the
                    user never has to know a raw numeric ID. */}
                {formSourceType === 'saved_query' && (
                  /* 2026-08-22 — the inline Autocomplete moved verbatim into
                     the shared common/SavedQueryPicker so Feed Generation and
                     the Dataset Creation Wizard present the SAME picker. */
                  <SavedQueryPicker
                    options={savedQueries}
                    value={formSourceId}
                    required
                    onChange={v => {
                      setFormSourceId(v ? v.id : '');
                      // Any source change invalidates the prior auto-/
                      // manual-set connection — picking a new saved
                      // query should re-derive its own connection_id
                      // even in edit mode.  Manual connection edits
                      // (in the connection picker below) re-flip this
                      // back to true.
                      setFormConnOverridden(false);
                    }}
                  />
                )}

                {formSourceType === 'published_view' && (
                  <Autocomplete
                    size="small"
                    options={publishedViews}
                    value={publishedViews.find(v => v.id === formSourceId) || null}
                    getOptionLabel={v => v.name ? `${v.name} (${v.slug})` : `Published view #${v.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormSourceId(v ? v.id : '');
                      setFormConnOverridden(false);
                    }}
                    renderOption={(props, v) => (
                      <li {...props} key={v.id}>
                        <Box>
                          <Typography variant="body2">{v.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            /{v.slug}{v.description ? ` — ${v.description}` : ''}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField {...params} label="Published View" required
                                 helperText={publishedViews.length === 0
                                   ? 'No published views available — publish one from a saved query first.'
                                   : `${publishedViews.length} published views available`} />
                    )}
                  />
                )}

                {formSourceType === 'sql_file' && (
                  <Autocomplete
                    size="small"
                    options={sqlFilesList}
                    value={sqlFilesList.find(s => s.id === formSourceId) || null}
                    getOptionLabel={s => s.name || `SQL file #${s.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormSourceId(v ? v.id : '');
                      setFormConnOverridden(false);
                    }}
                    renderOption={(props, s) => (
                      <li {...props} key={s.id}>
                        <Box>
                          <Typography variant="body2">{s.name}</Typography>
                          {s.description && (
                            <Typography variant="caption" color="text.secondary">
                              {s.description}
                            </Typography>
                          )}
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField {...params} label="SQL File" required
                                 helperText={sqlFilesList.length === 0
                                   ? 'No SQL files available — save one from the Query Builder first.'
                                   : `${sqlFilesList.length} SQL files available`} />
                    )}
                  />
                )}

                {formSourceType === 'raw_sql' && (
                  <Box>
                    <TextField
                      label="SQL Query"
                      value={formRawSql}
                      onChange={e => setFormRawSql(e.target.value)}
                      required multiline rows={6} fullWidth size="small"
                      placeholder={"SELECT *\nFROM your_table\nWHERE trade_date = '{{business_date}}'"}
                      helperText="Inline SQL — run against the connection picked below.  For reusable queries, save them and pick 'Saved Query' or 'SQL File' instead."
                      sx={{ '& textarea': { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                    />
                    {/* Phase 130 hotfix-13 — inline token reference.  Same
                        substitution layer Published Views use; calendar
                        attached above makes the business-day tokens
                        holiday-aware. */}
                    <Box sx={{ mt: 1, p: 1.2, bgcolor: 'action.hover', borderRadius: 1 }}>
                      <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                        Supported date tokens (auto-resolved at run time):
                      </Typography>
                      <Stack direction="row" gap={0.5} flexWrap="wrap">
                        {[
                          ['{{business_date}}', "Today's business date (calendar-rolled)"],
                          ['{{business_date_yyyymmdd}}', '20260515 format'],
                          ['{{prev_business_day}}', 'Previous business day (skips weekends + holidays when calendar attached)'],
                          ['{{prev_eom}}', 'Last business day of previous month'],
                          ['{{month_end}}', 'Last business day of current month'],
                          ['{{next_month_end}}', 'Last business day of next month'],
                          ['{{run_date}}', 'When the feed actually ran (UTC)'],
                        ].map(([tok, desc]) => (
                          <Tooltip key={tok} title={desc}>
                            <Chip
                              label={tok}
                              size="small"
                              variant="outlined"
                              sx={{ fontFamily: 'monospace', fontSize: '0.7rem', height: 22 }}
                              onClick={() => {
                                // Insert at cursor end — quick paste UX.
                                setFormRawSql(formRawSql + tok);
                              }}
                              clickable
                            />
                          </Tooltip>
                        ))}
                      </Stack>
                      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                        Click a chip to append.  Each token also has <code>_yyyymmdd</code> + <code>_iso</code> variants
                        (e.g. <code>{'{{prev_eom_yyyymmdd}}'}</code>).  Values are SQL-escape-safe.
                      </Typography>
                    </Box>
                  </Box>
                )}

                {/* Connection picker — required for raw_sql, optional
                    elsewhere (auto-derived from source).  Shows an info
                    chip when the value came from the picked source so
                    the user understands why it's pre-filled. */}
                <Box>
                  <Autocomplete
                    size="small"
                    options={connections}
                    value={connections.find(c => c.id === formConnectionId) || null}
                    getOptionLabel={c => c.name || `Connection #${c.id}`}
                    isOptionEqualToValue={(a, b) => a.id === b.id}
                    onChange={(_, v) => {
                      setFormConnectionId(v ? v.id : '');
                      // Any manual edit suppresses the auto-derive on
                      // subsequent source changes; the user clearly
                      // wants this specific connection.
                      setFormConnOverridden(true);
                    }}
                    renderOption={(props, c) => (
                      <li {...props} key={c.id}>
                        <Box>
                          <Typography variant="body2">{c.name}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {c.connection_type}
                          </Typography>
                        </Box>
                      </li>
                    )}
                    renderInput={params => (
                      <TextField
                        {...params}
                        label={formSourceType === 'raw_sql' ? 'Connection (required)' : 'Connection'}
                        required={formSourceType === 'raw_sql'}
                        helperText={
                          formSourceType === 'raw_sql'
                            ? 'Required — the SQL runs against this connection.'
                            : (formConnectionId && !formConnOverridden)
                              ? 'Auto-derived from the picked source.  Override only when you want to run against a different connection.'
                              : 'Optional — defaults to the source\'s own connection.'
                        }
                      />
                    )}
                  />
                  {formConnectionId && !formConnOverridden && formSourceType !== 'raw_sql' && (
                    <Chip
                      icon={<InfoIcon fontSize="small" />}
                      size="small"
                      label={`Inherited from ${SOURCE_TYPE_LABELS[formSourceType]}`}
                      color="info"
                      variant="outlined"
                      sx={{ mt: 0.5 }}
                    />
                  )}
                </Box>

                {/* Phase 132.38 — per-feed Static / Dynamic WHERE-clause
                    mapping.  Same primitive Published Views uses.  Static
                    rows are locked at save time; Dynamic rows let a
                    trigger caller (Run-with-overrides dialog OR the
                    /api/v1/feeds/{id}/trigger external endpoint) supply
                    the value at run time via ``query_params``.  Persisted
                    inside query_params._where_clauses_mapping. */}
                <Box>
                  {(() => {
                    // Real column dropdown (no plain text) — pulls
                    // names from the feed's saved SQL.  Partition
                    // badges + per-value autocomplete come from the
                    // connection's partition cache (refetched on
                    // formConnectionId change above).
                    // Phase 133-H round 17 — use resolvedSqlForEditor
                    // which is populated regardless of source_type (raw_sql,
                    // saved_query, sql_file).  formRawSql alone is empty for
                    // saved_query / sql_file sources → editor saw no columns.
                    const _ex = new SqlColumnExtractor(
                      resolvedSqlForEditor || formRawSql,
                      formPartitionInfo.partitionColumns,
                      formPartitionInfo.valueOptionsByColumn,
                    );
                    const _opts = _ex.toColumnOptions();
                    const _vals = _ex.toValueOptions();
                    const _valKnown = Object.keys(_vals).length;
                    // Phase 133-H round 6 — fold in the FULL schema
                    // from formColumnCatalog so the dropdown lists every
                    // column on the source tables (not just the ones
                    // mentioned in the SQL text).
                    const _seen = new Set(_opts.map(o => o.name.toLowerCase()));
                    const _allPartCols = new Set<string>(
                      formPartitionInfo.partitionColumns.map(c => c.toLowerCase()),
                    );
                    Object.values(formColumnCatalog.partitionColumnsByTable).forEach(arr =>
                      arr.forEach(c => _allPartCols.add(c.toLowerCase())),
                    );
                    // Phase 133-I round 22 — iterate WITH the table key
                    // so each pushed option carries ``tableSource``.  The
                    // shared WhereClausesEditor groupBy() uses it to show
                    // columns grouped per table — the CQB UX.
                    Object.entries(formColumnCatalog.columnsByTable).forEach(([tbl, cols]) => {
                      const groupLabel = tbl.replace(/^.*:/, '') || 'Other';
                      cols.forEach(c => {
                        const k = (c.name || '').toLowerCase();
                        if (!k || _seen.has(k)) return;
                        _seen.add(k);
                        _opts.push({
                          name: c.name,
                          type: c.type || 'string',
                          isPartition: _allPartCols.has(k),
                          tableSource: groupLabel,
                        });
                      });
                    });
                    // Phase 133-H round 18 — extract FROM target from
                    // the RESOLVED SQL, not formRawSql.  formRawSql is
                    // empty for saved_query / sql_file sources, so the
                    // round-17 fix populated columns but the lazy
                    // distinct-values fetch still had no table hint
                    // (silent ECONNREFUSED — value picker stayed empty).
                    const _sqlForHint = resolvedSqlForEditor || formRawSql || '';
                    const _fromMatch = _sqlForHint.match(
                      /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
                    );
                    const _tableHint = _fromMatch
                      ? _fromMatch[1].replace(/[\s"`\[\]]/g, '')
                      : null;
                    return (
                      <WhereClausesEditor
                        value={formWhereClauses}
                        onChange={setFormWhereClauses}
                        columnOptions={_opts}
                        valueOptionsByColumn={_vals}
                        connectionId={typeof formConnectionId === 'number' ? formConnectionId : null}
                        distinctValuesTable={_tableHint}
                        classifyTable={_tableHint}
                        sourceFilters={/\bWHERE\b/i.test(draftResolve?.primary?.sql || '')}
                        title="WHERE Clauses"
                        hint={
                          <>
                            Choose per column whether the value is locked
                            at config time (<strong>Static</strong>) or
                            supplied by the trigger caller at run time
                            (<strong>Dynamic</strong>, override via
                            {' '}<code>query_params</code>).
                            {' '}
                            {_opts.length === 0
                              ? <em>Type SQL above first; columns will auto-populate.</em>
                              : <em>{_opts.length} column(s){
                                  _valKnown > 0
                                    ? `, ${_valKnown} with cached values`
                                    : ''
                                }.</em>}
                          </>
                        }
                        addLabel="Add Mapping"
                      />
                    );
                  })()}
                </Box>

                {/* 2026-10-11 -- SECOND SIDE (cross-source).  The owner's report:
                    "no query selection in cross source".  The second side is a
                    SOURCE now -- the same query on the second connection, a saved
                    query there, or SQL -- combined by column name (UNION ALL, the
                    owner's rule) or a JOIN.  What the draft would run comes from
                    POST /api/feeds/resolve-draft (the run's own resolver). */}
                <Divider sx={{ pt: 1 }} />
                <Typography variant="subtitle2">Second side (cross-source)</Typography>
                {draftResolve?.inherited?.carries_second_side && (
                  <Alert severity={formCrossSourceEnabled ? 'warning' : 'info'}
                         data-testid="cross-source-inherited">
                    This saved query already combines two sources (
                    {draftResolve.inherited.combine_mode === 'join' ? 'JOIN' : 'UNION ALL'} with{' '}
                    {connectionLabel(draftResolve.inherited.secondary_connection_id) || 'a second connection'}).
                    The feed runs it as saved. A second side declared here REPLACES the
                    query's own second side — it is never combined twice.
                  </Alert>
                )}
                {draftResolve?.inherited?.refusal && (
                  <Alert severity="error" data-testid="cross-source-inherited-refusal">
                    {draftResolve.inherited.refusal}
                  </Alert>
                )}
                <FormControlLabel
                  control={
                    <Switch
                      checked={formCrossSourceEnabled}
                      onChange={e => setFormCrossSourceEnabled(e.target.checked)}
                    />
                  }
                  label={
                    <Stack>
                      <Typography variant="body2">Combine with a second connection</Typography>
                      <Typography variant="caption" color="text.secondary">
                        Cloud and on-prem: the same columns, a different catalog or schema
                        in FROM. The two sides are stacked by column name (UNION ALL) before
                        delivery. Same credentials never mix.
                      </Typography>
                    </Stack>
                  }
                />
                {formCrossSourceEnabled && (
                  <Stack spacing={2} sx={{ pl: 2, borderLeft: '2px solid', borderColor: 'divider' }}>
                    <Autocomplete
                      size="small"
                      options={connections.filter(c => c.id !== formConnectionId)}
                      value={connections.find(c => c.id === formSecondaryConnectionId) || null}
                      getOptionLabel={c => c.name || `Connection #${c.id}`}
                      isOptionEqualToValue={(a, b) => a.id === b.id}
                      onChange={(_, v) => {
                        setFormSecondaryConnectionId(v ? v.id : '');
                        // a saved query is picked per connection
                        if (formSecondarySourceMode === 'saved_query') setFormSecondarySourceId('');
                      }}
                      renderInput={params => (
                        <TextField
                          {...params}
                          label="Second connection"
                          required={formCrossSourceEnabled}
                          helperText="The second data source (on-prem, another cluster, another bucket)."
                        />
                      )}
                    />
                    <FormControl size="small" fullWidth>
                      <InputLabel id="sel-feedconfigspage-second-source">Second side runs</InputLabel>
                      <Select labelId="sel-feedconfigspage-second-source"
                        value={formSecondarySourceMode}
                        label="Second side runs"
                        onChange={e => {
                          const m = e.target.value as 'same' | 'saved_query' | 'raw_sql';
                          setFormSecondarySourceMode(m);
                          if (m !== 'saved_query') setFormSecondarySourceId('');
                          if (m !== 'raw_sql') setFormSecondaryRawSql('');
                        }}
                      >
                        <MenuItem value="same">The same query as the primary, on the second connection</MenuItem>
                        <MenuItem value="saved_query">A saved query on the second connection</MenuItem>
                        <MenuItem value="raw_sql">SQL typed here</MenuItem>
                      </Select>
                      <FormHelperText>
                        {formSecondarySourceMode === 'same'
                          ? 'One statement, two warehouses — it must parse on both (the same dialect).'
                          : formSecondarySourceMode === 'saved_query'
                            ? 'Pick the query saved against the second connection; its SQL runs there unchanged.'
                            : 'The statement the second side runs, in the second connection\'s dialect.'}
                      </FormHelperText>
                    </FormControl>
                    {formSecondarySourceMode === 'saved_query' && (
                      <SavedQueryPicker
                        options={savedQueries.filter(q => {
                          const cid = q.query_config?.connection_id ?? (q as any).connection_id;
                          return !cid || cid === formSecondaryConnectionId;
                        })}
                        value={formSecondarySourceId}
                        required
                        label="Saved query on the second connection"
                        onChange={v => setFormSecondarySourceId(v ? v.id : '')}
                        helperTextWhenEmpty={formSecondaryConnectionId
                          ? `No saved query is on ${connectionLabel(Number(formSecondaryConnectionId))} — save one in the Query Builder, or choose SQL.`
                          : 'Pick the second connection first.'}
                      />
                    )}
                    {formSecondarySourceMode === 'raw_sql' && (
                      <TextField
                        label="Second side SQL"
                        value={formSecondaryRawSql}
                        onChange={e => setFormSecondaryRawSql(e.target.value)}
                        fullWidth size="small" multiline minRows={4}
                        inputProps={{ 'data-testid': 'secondary-raw-sql' }}
                        helperText="Runs on the second connection. {BUSINESSDATE} and the feed's {PARAMETER} tokens work here as in the primary."
                      />
                    )}
                    <FormControl size="small" fullWidth>
                      <InputLabel id="sel-feedconfigspage-combine-mode">Combine mode</InputLabel>
                      <Select labelId="sel-feedconfigspage-combine-mode"
                        value={formCombineMode}
                        label="Combine mode"
                        onChange={e => setFormCombineMode(e.target.value as 'union' | 'join')}
                      >
                        <MenuItem value="union">UNION ALL by column name — stack rows from both sides (the default)</MenuItem>
                        <MenuItem value="join">JOIN — match rows on a key column</MenuItem>
                      </Select>
                    </FormControl>
                    {formCombineMode === 'join' && (
                      <Stack spacing={2}>
                        <FormControl size="small" fullWidth>
                          <InputLabel id="sel-feedconfigspage-join-type">Join type</InputLabel>
                          <Select labelId="sel-feedconfigspage-join-type"
                            value={formJoinType}
                            label="Join type"
                            onChange={e => setFormJoinType(e.target.value as any)}
                          >
                            <MenuItem value="INNER">INNER</MenuItem>
                            <MenuItem value="LEFT">LEFT</MenuItem>
                            <MenuItem value="RIGHT">RIGHT</MenuItem>
                            <MenuItem value="FULL">FULL OUTER</MenuItem>
                          </Select>
                        </FormControl>
                        {/* Phase 133-I round 19 — JOIN key columns
                            picker.  Was plain TextField (user had to
                            type from memory).  Now multi-Autocomplete
                            sourced from the relevant connection's
                            schema with freeSolo fallback for free-typing. */}
                        <Autocomplete
                          multiple freeSolo size="small" openOnFocus
                          options={Object.values(formColumnCatalog.columnsByTable)
                            .flat()
                            .map(c => c.name)
                            .filter((v, i, a) => v && a.indexOf(v) === i)}
                          value={formJoinKeysLeft
                            ? formJoinKeysLeft.split(',').map(s => s.trim()).filter(Boolean)
                            : []}
                          onChange={(_, v) => setFormJoinKeysLeft(v.join(', '))}
                          renderInput={(rp) => (
                            <TextField {...rp} size="small"
                              label="Primary key columns"
                              placeholder="Pick or type column names"
                              helperText="Columns from the primary side to join on"
                            />
                          )}
                        />
                        <Autocomplete
                          multiple freeSolo size="small" openOnFocus
                          options={Object.values(formSecondaryColumnCatalog.columnsByTable)
                            .flat()
                            .map(c => c.name)
                            .filter((v, i, a) => v && a.indexOf(v) === i)}
                          value={formJoinKeysRight
                            ? formJoinKeysRight.split(',').map(s => s.trim()).filter(Boolean)
                            : []}
                          onChange={(_, v) => setFormJoinKeysRight(v.join(', '))}
                          renderInput={(rp) => (
                            <TextField {...rp} size="small"
                              label="Secondary key columns"
                              placeholder="Pick or type column names"
                              helperText="Must match the number of primary keys"
                            />
                          )}
                        />
                      </Stack>
                    )}
                    {_crossSourceProblem && (
                      <Alert severity="warning" data-testid="cross-source-incomplete">
                        {_crossSourceProblem}
                      </Alert>
                    )}
                    {!_crossSourceProblem && draftResolve?.secondary
                      && draftResolve.secondary.status !== 'ok' && (
                      <Alert severity="warning" data-testid="second-side-status">
                        Second side: {draftResolve.secondary.message || draftResolve.secondary.status}
                      </Alert>
                    )}
                    {!_crossSourceProblem && draftResolve?.merge && (() => {
                      const m = draftResolve.merge;
                      if (m.refused) {
                        return (
                          <Alert severity="error" data-testid="merge-plan">
                            The merge would be refused: {m.refused}
                          </Alert>
                        );
                      }
                      if (!m.known) {
                        return (
                          <Alert severity="info" data-testid="merge-plan">
                            Merge: {m.reason}
                          </Alert>
                        );
                      }
                      return (
                        <Alert severity="info" data-testid="merge-plan">
                          UNION ALL by column name: {m.columns} column(s) in the primary's order
                          {m.primary_only && m.primary_only.length > 0
                            ? `; only on the primary (NULL for the second side): ${m.primary_only.join(', ')}` : ''}
                          {m.secondary_only && m.secondary_only.length > 0
                            ? `; only on the second side (appended, NULL for the primary): ${m.secondary_only.join(', ')}` : ''}
                          {m.case_renames && m.case_renames.length > 0
                            ? `; spelled differently: ${m.case_renames.join(', ')}` : ''}
                          . Types are compared when the run materialises both sides; an
                          incompatible column refuses the run.
                        </Alert>
                      );
                    })()}
                  </Stack>
                )}

                {/* 2026-10-11 -- MAKE THE WHERE GENERIC.  The owner's report:
                    "where clause not getting generic once we have saved queries".
                    The saved query filters on literal values; each one can be
                    BOUND to a token.  The run pastes the business date or the
                    feed's parameter inside the query's own quotes, on every
                    engine and both sides; a binding the query no longer holds
                    refuses the run (a correctness gate must fail). */}
                {draftResolveError && (
                  <Alert severity="warning" data-testid="draft-resolve-error">
                    Could not read what this feed would run: {draftResolveError}
                  </Alert>
                )}
                {draftResolve && (draftResolve.query_tokens || []).length > 0 && (
                  // 2026-10-12 -- the values this query needs, by KIND: a
                  // parameter is typed here (query_params); a calendar date and
                  // an upstream-message value are filled by every run itself
                  <Box data-testid="query-tokens" sx={{ mt: 1 }}>
                    <Typography variant="subtitle2">Values this query needs</Typography>
                    <Table size="small">
                      <TableHead><TableRow>
                        <TableCell>Token</TableCell><TableCell>Filled by</TableCell><TableCell>Value</TableCell>
                      </TableRow></TableHead>
                      <TableBody>
                        {(draftResolve.query_tokens || []).map(t => (
                          <TableRow key={t.name} data-testid={`query-token-${t.name}`} data-kind={t.kind}>
                            <TableCell sx={{ fontFamily: 'monospace' }}>{`{${t.name}${t.format ? ':' + t.format : ''}}`}</TableCell>
                            <TableCell>
                              {t.kind === 'date' ? 'the business calendar (each run\'s date)'
                                : t.kind === 'message' ? 'each environment\'s upstream message (CLOUD and ON-PREM may differ)'
                                : 'this feed — type the value'}
                            </TableCell>
                            <TableCell>
                              {t.kind === 'parameter' ? (
                                <TextField size="small" value={String(formExtraParams[t.name] ?? '')}
                                           error={!String(formExtraParams[t.name] ?? '').trim()}
                                           placeholder="required"
                                           inputProps={{ 'aria-label': `Value of ${t.name}`,
                                                         'data-testid': `query-token-value-${t.name}` }}
                                           onChange={e => setFormExtraParams(prev => ({ ...prev, [t.name]: e.target.value }))} />
                              ) : <Typography variant="caption" color="text.secondary">filled at run time</Typography>}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    {_missingParams.length > 0 && (
                      <Alert severity="warning" sx={{ mt: 0.5 }} data-testid="query-tokens-missing">
                        Give {_missingParams.map(n => `{${n}}`).join(', ')} a value — without it the query would match nothing.
                      </Alert>
                    )}
                  </Box>
                )}
                {draftResolve && (() => {
                  const crossOn = Boolean(formCrossSourceEnabled && formSecondaryConnectionId);
                  const sides = [draftResolve.primary, ...(crossOn && draftResolve.secondary?.predicates ? [draftResolve.secondary] : [])];
                  const rows = sides.flatMap(sd => (sd?.predicates || []).map(p => ({ sd, p })));
                  if (rows.length === 0) return null;
                  const dateTokens = ['BUSINESSDATE', 'PREV_BUSINESS_DAY', 'PREV_EOM', 'MONTH_END', 'RUNDATE']
                    .filter(t => draftResolve.tokens.date_tokens.includes(t));
                  const paramNames = Array.from(new Set([
                    ...draftResolve.tokens.parameters, ...Object.keys(formExtraParams)])).sort();
                  const bothSidesShare = crossOn && draftResolve.secondary
                    && draftResolve.primary.predicates.some(p =>
                      _sideHasPredicate('secondary', p.column, p.literal));
                  return (
                    <Box data-testid="token-bindings">
                      <Divider sx={{ pt: 1 }} />
                      <Typography variant="subtitle2" sx={{ mt: 1 }}>Make the WHERE generic</Typography>
                      <Typography variant="caption" color="text.secondary" component="div">
                        The query filters on literal values. Bind each to a token: the run
                        pastes the business date (from the calendar) or the feed's parameter
                        inside the query's own quotes, on every engine and both sides. A
                        binding the query no longer holds refuses the run instead of
                        delivering the literal.
                      </Typography>
                      {bothSidesShare && (
                        <FormControlLabel
                          control={<Checkbox size="small" checked={formBindBothSides}
                                             onChange={e => setFormBindBothSides(e.target.checked)} />}
                          label="Bind the same literal on both sides (cloud and on-prem share their columns)"
                        />
                      )}
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            {crossOn && <TableCell>Side</TableCell>}
                            <TableCell>Predicate</TableCell>
                            <TableCell>Bind to</TableCell>
                            <TableCell>Date format</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {rows.map(({ sd, p }) => {
                            const key = `${sd.side}|${p.column}|${p.literal}`;
                            const b = bindingFor(sd.side, p.column, p.literal);
                            const bindLabel = `Bind ${p.qualified} ${p.operator} ${p.literal}${crossOn ? ` (${sd.side})` : ''}`;
                            const isDate = Boolean(b && dateTokens.includes(b.token));
                            return (
                              <TableRow key={key} data-testid={`binding-row-${sd.side}-${p.column}`}>
                                {crossOn && <TableCell>{sd.side}</TableCell>}
                                <TableCell>
                                  <code>{p.text}</code>
                                  {p.occurrences > 1 && (
                                    <Typography variant="caption" color="text.secondary" component="div">
                                      {p.occurrences} occurrences, all bound together
                                    </Typography>
                                  )}
                                </TableCell>
                                <TableCell sx={{ minWidth: 220 }}>
                                  {newParamFor === key ? (
                                    <TextField
                                      size="small" autoFocus
                                      label="New parameter name"
                                      value={newParamName}
                                      onChange={e => setNewParamName(e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_'))}
                                      onKeyDown={e => { if (e.key === 'Enter') commitNewParam(sd.side, p.column, p.literal); }}
                                      onBlur={() => commitNewParam(sd.side, p.column, p.literal)}
                                      inputProps={{ 'data-testid': `new-param-${sd.side}-${p.column}` }}
                                      helperText={`Letters, digits, underscore. Its value starts as ${p.literal}.`}
                                    />
                                  ) : (
                                    <TextField
                                      select size="small" fullWidth
                                      label="Bind to"
                                      value={b ? b.token : ''}
                                      SelectProps={{ displayEmpty: true }}
                                      inputProps={{ 'aria-label': bindLabel }}
                                      onChange={e => {
                                        const v = String(e.target.value);
                                        if (v === '__new__') { setNewParamFor(key); setNewParamName(''); return; }
                                        setBinding(sd.side, p.column, p.literal, v || null,
                                                   v && dateTokens.includes(v) ? (b?.format ?? null) : null);
                                      }}
                                    >
                                      <MenuItem value=""><em>Keep the literal</em></MenuItem>
                                      {dateTokens.map(t => (
                                        <MenuItem key={t} value={t}>{'{' + t + '}'} — from the calendar</MenuItem>
                                      ))}
                                      {paramNames.map(t => (
                                        <MenuItem key={t} value={t}>{'{' + t + '}'} — feed parameter</MenuItem>
                                      ))}
                                      <MenuItem value="__new__">New parameter...</MenuItem>
                                    </TextField>
                                  )}
                                </TableCell>
                                <TableCell sx={{ minWidth: 140 }}>
                                  {isDate && b ? (
                                    <TextField
                                      select size="small" fullWidth label="Format"
                                      value={b.format || ''}
                                      SelectProps={{ displayEmpty: true }}
                                      inputProps={{ 'aria-label': `Date format for ${bindLabel}` }}
                                      onChange={e => setBinding(sd.side, p.column, p.literal, b.token,
                                                                String(e.target.value) || null)}
                                    >
                                      <MenuItem value=""><em>ISO (YYYY-MM-DD)</em></MenuItem>
                                      {draftResolve.tokens.date_formats.map(f => (
                                        <MenuItem key={f} value={f}>{f}</MenuItem>
                                      ))}
                                    </TextField>
                                  ) : null}
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                      {draftResolve.bindings.some(v => !v.matched) && (
                        <Alert severity="error" data-testid="binding-stale">
                          {draftResolve.bindings.filter(v => !v.matched).map(v =>
                            `${v.column} = ${v.literal} -> {${v.token}} (${v.side}): ${v.reason}`).join('; ')}
                          . The save is refused until the binding names a literal the query holds.
                        </Alert>
                      )}
                      {Object.keys(formExtraParams).length > 0 && (
                        <Typography variant="caption" color="text.secondary" component="div" data-testid="feed-parameters">
                          Feed parameters (query_params): {Object.entries(formExtraParams)
                            .map(([k, v]) => `${k} = ${v}`).join(', ')}. A template's matrix
                          supplies them per member.
                        </Typography>
                      )}
                    </Box>
                  );
                })()}
              </Stack>
            )}

            {/* Step 1: SCHEDULE — a calendar rule (BRD §2: what the author
                supplies; the platform derives the business date, SOD tasks
                and whether today is a business day for this feed). */}
            {activeStep === 1 && (
              <Stack spacing={2}>
                <Typography variant="caption" color="text.secondary">
                  When the feed runs.  The platform derives the business date and
                  the start-of-day tasks from this rule — you never schedule those
                  separately.
                </Typography>
                <FormControlLabel
                  control={<Switch checked={formScheduleEnabled}
                                   onChange={e => setFormScheduleEnabled(e.target.checked)} />}
                  label="Enable Scheduled Execution"
                />
                {formScheduleEnabled && (
                  <>
                    <Stack direction="row" spacing={1}>
                      <TextField
                        label="Cron Expression"
                        value={formCron}
                        onChange={e => setFormCron(e.target.value)}
                        size="small" sx={{ flex: 2 }}
                        placeholder="0 6 * * *"
                        helperText={describeCron(formCron) || 'min hour day-of-month month day-of-week — e.g. 0 6 * * * = daily at 06:00'}
                        FormHelperTextProps={{
                          sx: describeCron(formCron) ? { color: 'success.main', fontWeight: 500 } : undefined,
                        }}
                      />
                      <Autocomplete
                        size="small"
                        options={TIMEZONES}
                        value={formTimezone}
                        onChange={(_, v) => setFormTimezone(v || 'UTC')}
                        disableClearable
                        sx={{ flex: 1 }}
                        renderInput={params => <TextField {...params} label="Timezone" />}
                      />
                    </Stack>
                    {/* Common-pattern shortcuts so users don't have to remember cron syntax. */}
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                      {[
                        { label: 'Every hour',        expr: '0 * * * *' },
                        { label: 'Daily 06:00',       expr: '0 6 * * *' },
                        { label: 'Daily 22:00',       expr: '0 22 * * *' },
                        { label: 'Weekdays 09:00',    expr: '0 9 * * 1-5' },
                        { label: 'Mondays 08:00',     expr: '0 8 * * 1' },
                        { label: 'Monthly 1st 02:00', expr: '0 2 1 * *' },
                      ].map(p => (
                        <Chip
                          key={p.expr}
                          size="small"
                          label={p.label}
                          variant={formCron === p.expr ? 'filled' : 'outlined'}
                          color={formCron === p.expr ? 'primary' : 'default'}
                          onClick={() => setFormCron(p.expr)}
                          clickable
                        />
                      ))}
                    </Stack>
                  </>
                )}

                <Divider sx={{ my: 1 }} />

                {/* The CONSUMER's deadline -- distinct from the schedule.
                    The schedule says when the feed RUNS; the SLA says when
                    the counterparty needs it.  Alerting keys off this one,
                    and a feed without it raises no overdue alert at all. */}
                <Typography variant="caption" sx={{ fontWeight: 700 }}>
                  Consumer SLA
                </Typography>
                {/* 2026-10-03 -- STRUCTURED: an hour and a minute picker
                    (24-hour clock) and a zone from a fixed list, producing
                    exactly the HH:MM + IANA zone the breach sweep and the
                    alert ladder read.  The free-text boxes took "6pm",
                    which saved and gave the feed no clock at all; the
                    server now refuses such a value (422 naming the field). */}
                <Stack direction="row" spacing={1} alignItems="flex-start">
                  <SlaTimeField
                    label="Due by" testId="feed-sla-to"
                    value={formSlaTo} legacy={formSlaToLegacy}
                    onChange={v => { setFormSlaTo(v); if (v) setFormSlaToLegacy(null); }}
                    warnWhenUnset
                    helperText={formSlaTo
                      ? `The consumer needs it by ${formSlaTo} ${formSlaTimezone || 'UTC'} on each business date — overdue and decision-due alerts key off this.`
                      : 'No SLA — this feed raises NO overdue alert.'}
                  />
                  <Autocomplete
                    size="small"
                    options={TIMEZONES}
                    value={formSlaTimezone || null}
                    onChange={(_, v) => setFormSlaTimezone(v || '')}
                    sx={{ flex: 1 }}
                    renderInput={params => (
                      <TextField
                        {...params} label="SLA timezone"
                        helperText="Pick from the list. Blank = UTC. The consumer's zone, not the schedule's."
                      />
                    )}
                  />
                </Stack>
                <SlaTimeField
                  label="Expected from" testId="feed-sla-from"
                  value={formSlaFrom} legacy={formSlaFromLegacy}
                  onChange={v => { setFormSlaFrom(v); if (v) setFormSlaFromLegacy(null); }}
                  helperText="Optional, informational: the earliest the consumer expects the file. It is recorded on each run; no alert reads it."
                />

                {/* Execution policy: how hard to retry, and how big the
                    heavy-lane pods should be.  Both were stored, read by
                    the engine, and settable nowhere. */}
                <Typography variant="caption" sx={{ fontWeight: 700 }}>
                  Execution policy
                </Typography>
                <Stack direction="row" spacing={1}>
                  <TextField
                    size="small" label="Delivery retries" type="number"
                    value={formMaxRetries} sx={{ flex: 1 }}
                    onChange={e => setFormMaxRetries(e.target.value)}
                    inputProps={{ min: 0, 'data-testid': 'feed-max-retries' }}
                    helperText="Blank = deployment default. 0 = never retry"
                  />
                  <TextField
                    size="small" label="Retry delay (s)" type="number"
                    value={formRetryDelay} sx={{ flex: 1 }}
                    onChange={e => setFormRetryDelay(e.target.value)}
                    inputProps={{ min: 0, 'data-testid': 'feed-retry-delay' }}
                    helperText="Blank = deployment default"
                  />
                  <TextField
                    select size="small" label="Heavy-lane size"
                    value={formSparkSizeClass} sx={{ flex: 1 }}
                    onChange={e => setFormSparkSizeClass(e.target.value)}
                    SelectProps={{ native: true }}
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ 'data-testid': 'feed-spark-size-class' }}
                    helperText="Only used when this feed runs on Spark"
                  >
                    <option value="">Deployment default</option>
                    <option value="small">small</option>
                    <option value="medium">medium</option>
                    <option value="large">large</option>
                    <option value="xl">xl</option>
                  </TextField>
                </Stack>

                {/* 2026-10-14 -- read the query in parts (OG's partition columns) */}
                <Stack direction="row" spacing={1}>
                  <TextField
                    size="small" label="Read in parts by column(s)"
                    value={formPartitionColumns} sx={{ flex: 2 }}
                    onChange={e => setFormPartitionColumns(e.target.value)}
                    inputProps={{ 'data-testid': 'feed-partition-columns' }}
                    helperText={'For example SAP_COMPANY_CODE. Its values are read first, then '
                      + 'the query runs for a few values at a time -- still ONE file (one file '
                      + 'per value is the Shape step). Blank = one query'}
                  />
                  <TextField
                    size="small" label="Order inside each part"
                    value={formPartitionOrder} sx={{ flex: 2 }}
                    onChange={e => setFormPartitionOrder(e.target.value)}
                    disabled={!splitColumns(formPartitionColumns).length}
                    inputProps={{ 'data-testid': 'feed-partition-order' }}
                    helperText="Optional. A unique key here gives the same file every run"
                  />
                  <TextField
                    size="small" label="Parts at once" type="number"
                    value={formPartitionConcurrent} sx={{ flex: 1 }}
                    onChange={e => setFormPartitionConcurrent(e.target.value)}
                    disabled={!splitColumns(formPartitionColumns).length}
                    inputProps={{ min: 1, 'data-testid': 'feed-partition-concurrent' }}
                    helperText="Blank = 2"
                  />
                </Stack>

                {/* Validity window -- SOD skips a business date outside it. */}
                <Stack direction="row" spacing={1}>
                  <TextField
                    size="small" type="date" label="Valid from"
                    value={formValidFrom} sx={{ flex: 1 }}
                    onChange={e => setFormValidFrom(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ 'data-testid': 'feed-valid-from' }}
                    helperText="Blank = no start bound"
                  />
                  <TextField
                    size="small" type="date" label="Valid until"
                    value={formValidUntil} sx={{ flex: 1 }}
                    onChange={e => setFormValidUntil(e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    inputProps={{ 'data-testid': 'feed-valid-until' }}
                    helperText="Blank = runs indefinitely"
                  />
                </Stack>

                <Divider sx={{ my: 1 }} />
                {/* BRD §2.1 — the DECLARED schedule (core/feed/schedule.py).
                    Off = the feed keeps the cron-only path above, unchanged,
                    and NO declaration is sent.  On = one of the five kinds,
                    with only that kind's inputs. */}
                <FormControlLabel
                  control={
                    <Switch
                      checked={formSchedule.declared}
                      onChange={e => setFormSchedule(prev => ({ ...prev, declared: e.target.checked }))}
                    />
                  }
                  label={
                    <Stack>
                      <Typography variant="body2">Declare a business-date rule</Typography>
                      <Typography variant="caption" color="text.secondary">
                        Off: the feed runs on the cron schedule above. On: choose
                        the business days it runs (every day, month end, business
                        day 5 ...) or what starts it, and which date its data is for.
                      </Typography>
                    </Stack>
                  }
                />
                {formSchedule.declared && (
                  <Stack spacing={2} sx={{ pl: 2, borderLeft: '2px solid', borderColor: 'divider' }}>
                    <FormControl fullWidth size="small">
                      <InputLabel id="sched-kind-label">Runs on</InputLabel>
                      <Select
                        labelId="sched-kind-label" label="Runs on"
                        value={formSchedule.kind}
                        onChange={e => setFormSchedule(prev => ({
                          ...prev, kind: e.target.value as ScheduleKind,
                        }))}
                        inputProps={{ 'data-testid': 'sched-kind' }}
                      >
                        <MenuItem value="daily">Every business day</MenuItem>
                        <MenuItem value="month_end">The last business day of the month</MenuItem>
                        <MenuItem value="workday_n">One business day of the month (for example business day 5)</MenuItem>
                        <MenuItem value="workdays">Several business days each month</MenuItem>
                        <MenuItem value="cron">A cron expression, on business days only</MenuItem>
                        <MenuItem value="on_completion_of">When another feed completes</MenuItem>
                        <MenuItem value="on_demand">Only when someone runs it</MenuItem>
                      </Select>
                      <FormHelperText>
                        The days start of day creates a task for this feed.
                      </FormHelperText>
                    </FormControl>

                    {formSchedule.kind !== 'on_completion_of' && formSchedule.kind !== 'on_demand' && (
                      <FormControl fullWidth size="small">
                        <InputLabel id="sched-bd-label">The data is for</InputLabel>
                        <Select
                          labelId="sched-bd-label" label="The data is for"
                          value={formSchedule.businessDate}
                          onChange={e => setFormSchedule(prev => ({
                            ...prev, businessDate: e.target.value as BusinessDateRule,
                          }))}
                          inputProps={{ 'data-testid': 'sched-business-date' }}
                        >
                          <MenuItem value="run_day">The day it runs</MenuItem>
                          <MenuItem value="month_end">The current month end (the latest month end on or before the day it runs)</MenuItem>
                          <MenuItem value="previous_month_end">The previous month end (the month before the day it runs)</MenuItem>
                        </Select>
                        <FormHelperText data-testid="sched-business-date-help">
                          {formSchedule.businessDate === 'month_end'
                            ? 'One task per month end. Each later message for that month end re-runs it, as your re-send policy says.'
                            : formSchedule.businessDate === 'previous_month_end'
                              ? 'For example: runs on business day 5 of November for the October month end.'
                              : 'The business date is the day the task runs.'}
                          {' '}This is the date the query reads as {'{BUSINESSDATE}'} and the file is named with.
                        </FormHelperText>
                      </FormControl>
                    )}

                    {formSchedule.kind === 'workday_n' && (
                      <TextField
                        label="Workday number (n)"
                        value={formSchedule.workdayN}
                        onChange={e => setFormSchedule(prev => ({ ...prev, workdayN: e.target.value }))}
                        size="small" sx={{ maxWidth: 260 }}
                        error={_scheduleErrors.length > 0}
                        helperText={`1..${WORKDAY_N_MAX} from the start of the month, or -1..-${WORKDAY_N_MAX} counting back from month end. There is no 0th business day.`}
                      />
                    )}

                    {formSchedule.kind === 'workdays' && (
                      <Stack spacing={1.5}>
                        <FormControl size="small" sx={{ maxWidth: 320 }}>
                          <InputLabel id="workdays-form-label">Authoring form</InputLabel>
                          <Select
                            labelId="workdays-form-label" label="Authoring form"
                            value={formSchedule.workdaysForm}
                            onChange={e => setFormSchedule(prev => ({
                              ...prev,
                              workdaysForm: e.target.value as 'range' | 'set',
                            }))}
                          >
                            <MenuItem value="range">Range — every business day from..to (inclusive)</MenuItem>
                            <MenuItem value="set">Set — specific business days (e.g. 1, 10, 15)</MenuItem>
                          </Select>
                          <FormHelperText>
                            One kind, two authoring forms — both reduce to the
                            same membership on the server.
                          </FormHelperText>
                        </FormControl>
                        {formSchedule.workdaysForm === 'range' ? (
                          <Stack direction="row" spacing={1.5}>
                            <TextField
                              label="From (workday)" size="small" sx={{ maxWidth: 160 }}
                              value={formSchedule.workdaysFrom}
                              onChange={e => setFormSchedule(prev => ({ ...prev, workdaysFrom: e.target.value }))}
                              error={_scheduleErrors.length > 0}
                              inputProps={{ 'data-testid': 'workdays-from' }}
                            />
                            <TextField
                              label="To (workday)" size="small" sx={{ maxWidth: 160 }}
                              value={formSchedule.workdaysTo}
                              onChange={e => setFormSchedule(prev => ({ ...prev, workdaysTo: e.target.value }))}
                              error={_scheduleErrors.length > 0}
                              inputProps={{ 'data-testid': 'workdays-to' }}
                            />
                          </Stack>
                        ) : (
                          <TextField
                            label="Workdays (comma-separated)" size="small" sx={{ maxWidth: 320 }}
                            placeholder="1, 10, 15"
                            value={formSchedule.workdaysDays}
                            onChange={e => setFormSchedule(prev => ({ ...prev, workdaysDays: e.target.value }))}
                            error={_scheduleErrors.length > 0}
                            inputProps={{ 'data-testid': 'workdays-days' }}
                          />
                        )}
                        <Typography variant="caption" color="text.secondary">
                          Inclusive bounds: from=1 to=15 is due on workdays 1
                          AND 15.  Negative members count back from month end
                          (-1 = last business day); a range must not mix
                          signs.  A member with no matching business day in a
                          short month simply has no due day — it never clamps
                          to month-end.
                        </Typography>
                      </Stack>
                    )}

                    {formSchedule.kind === 'cron' && (
                      <TextField
                        label="Declared cron (5 fields)"
                        value={formSchedule.cron}
                        onChange={e => setFormSchedule(prev => ({ ...prev, cron: e.target.value }))}
                        size="small" fullWidth
                        placeholder="0 6 * * *"
                        error={_scheduleErrors.length > 0}
                        helperText={describeCron(formSchedule.cron)
                          || 'minute hour day month day_of_week — still calendar-filtered: it is skipped on non-business days.'}
                      />
                    )}

                    {formSchedule.kind === 'on_completion_of' && (
                      <>
                        <Alert severity="info">
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            This is a trigger, not a calendar rule.
                          </Typography>
                          {formSchedule.upstreamFeed.trim()
                            ? `This feed runs whenever ${formSchedule.upstreamFeed.trim()} completes — `
                              + 'it has no time of day and no date rule of its own.'
                            : 'This feed will have no time of day and no date rule of its '
                              + 'own — it runs whenever the upstream feed you name below '
                              + 'completes.'}
                        </Alert>
                        {/* 2026-10-03 -- PICKED, never typed: the free-text
                            box saved a typo and the feed waited for a
                            completion that could not happen.  The server
                            refuses a name that is no feed (422). */}
                        <Autocomplete
                          size="small" openOnFocus
                          options={_upstreamOptions}
                          value={formSchedule.upstreamFeed || null}
                          onChange={(_, v) => setFormSchedule(prev => ({ ...prev, upstreamFeed: v || '' }))}
                          renderInput={rp => (
                            <TextField
                              {...rp} label="Upstream feed"
                              error={_scheduleErrors.length > 0 || _upstreamUnknown}
                              helperText={_upstreamUnknown
                                ? `"${formSchedule.upstreamFeed}" is not an existing feed — pick one from the list.`
                                : 'Pick the feed whose completion fires this one.'}
                            />
                          )}
                        />
                        <Alert severity="info" data-testid="on-completion-trigger">
                          This feed starts by itself: when a run of the upstream feed
                          completes AND delivers, one run of this feed is created for the
                          same business date and the queue runs it. A failed, cancelled,
                          dry or undelivered upstream run starts nothing, and this feed
                          still keeps its own calendar (a holiday is a skip), condition
                          and dependencies. Start-of-day creates no run for it.
                        </Alert>
                      </>
                    )}

                    {_scheduleErrors.length === 0
                      && formSchedule.kind !== 'on_completion_of' && (
                      <Typography variant="caption" color="text.secondary">
                        {(() => {
                          const k = formSchedule.kind;
                          if (k === 'daily') return 'Runs on every business day of the calendar.';
                          if (k === 'month_end') {
                            return 'Runs once a month, on the LAST business day of the '
                              + 'month — a month-end landing on a weekend or holiday '
                              + 'rolls back to the previous business day.';
                          }
                          if (k === 'cron') {
                            return 'Fires on the cron expression, and is skipped on days '
                              + 'that are not business days of the attached calendar.';
                          }
                          if (k === 'workdays') {
                            return formSchedule.workdaysForm === 'range'
                              ? `Runs on every business day from workday ${formSchedule.workdaysFrom.trim()} `
                                + `to workday ${formSchedule.workdaysTo.trim()} of each month (inclusive).`
                              : `Runs on business days ${formSchedule.workdaysDays.trim()} of each month.`;
                          }
                          // workday_n, already validated above
                          const n = Number(formSchedule.workdayN.trim());
                          if (n > 0) {
                            return `Runs once a month, on business day ${n} of the month. `
                              + `A month with fewer than ${n} business days has no run `
                              + 'that month — the rule does not clamp to month-end.';
                          }
                          return `Runs once a month, on the ${-n}${-n === 1 ? 'st' : -n === 2 ? 'nd' : -n === 3 ? 'rd' : 'th'} `
                            + 'business day counted back from month end'
                            + (n === -1 ? ' (the last business day — same as month_end).' : '.');
                        })()}
                        {' '}Business days come from the attached calendar's weekend and
                        holiday definitions on the server — the preview below is the
                        server's own answer, never a browser guess.
                      </Typography>
                    )}

                    {_scheduleErrors.length > 0 && (
                      <Alert severity="error">
                        {_scheduleErrors.map((m, i) => <div key={i}>{m}</div>)}
                      </Alert>
                    )}

                    {/* The server-computed preview.  The server's three
                        states stay three on screen; pending and
                        could-not-compute are two more, distinct from all
                        of them.  Nothing here gates Next / Create. */}
                    {schedulePreview.phase === 'pending' && (
                      <Stack direction="row" spacing={1} alignItems="center"
                        data-testid="schedule-preview-pending">
                        <CircularProgress size={14} />
                        <Typography variant="caption" color="text.secondary">
                          Computing next due dates on the server…
                        </Typography>
                      </Stack>
                    )}
                    {schedulePreview.phase === 'unavailable' && (
                      <Alert severity="warning" data-testid="schedule-preview-unavailable">
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          Preview unavailable — could not compute the next due dates.
                        </Typography>
                        <Typography variant="caption" component="div">
                          {schedulePreview.message}
                        </Typography>
                        <Typography variant="caption" component="div" color="text.secondary">
                          This is a preview failure, not "no due dates" — the rule
                          may be fine.  Saving is not blocked.
                        </Typography>
                      </Alert>
                    )}
                    {schedulePreview.phase === 'ready'
                      && schedulePreview.data.mode === 'event_driven' && (
                      <Alert severity="info" data-testid="schedule-preview-event-driven">
                        {schedulePreview.data.message}
                      </Alert>
                    )}
                    {schedulePreview.phase === 'ready'
                      && schedulePreview.data.mode === 'no_due_dates_in_window' && (
                      <Alert severity="warning" data-testid="schedule-preview-no-dates">
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>
                          No due dates in the preview window.
                        </Typography>
                        <Typography variant="caption" component="div">
                          {schedulePreview.data.message}
                        </Typography>
                        <Typography variant="caption" component="div" color="text.secondary">
                          {describeSchedulePreviewCalendar(schedulePreview.data.calendar)}
                        </Typography>
                      </Alert>
                    )}
                    {schedulePreview.phase === 'ready'
                      && schedulePreview.data.mode === 'dates' && (
                      <Box data-testid="schedule-preview-dates">
                        <Typography variant="caption" color="text.secondary"
                          component="div" sx={{ mb: 0.5 }}>
                          Next due dates (computed by the server's own scheduler):
                        </Typography>
                        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                          {schedulePreview.data.due_dates.map(d => {
                            // the date its data is for, when it is not the run day
                            const bd = schedulePreview.data.mode === 'dates'
                              ? schedulePreview.data.tasks?.find(t => t.runs_on === d)?.business_date : undefined;
                            return (
                              <Chip key={d} size="small" variant="outlined" data-testid="schedule-preview-task"
                                label={`${weekdayOfIso(d)} ${d}`.trim() + (bd && bd !== d ? ` → data for ${bd}` : '')} />
                            );
                          })}
                        </Stack>
                        {schedulePreview.data.window_exhausted && (
                          <Typography variant="caption" color="text.secondary"
                            component="div" sx={{ mt: 0.5 }}>
                            Only {schedulePreview.data.count_found} of the
                            {' '}{schedulePreview.data.count_requested} requested dates
                            fall within the next
                            {' '}{schedulePreview.data.window.days} days.
                          </Typography>
                        )}
                        <Typography variant="caption" color="text.secondary"
                          component="div" sx={{ mt: 0.5 }}>
                          {describeSchedulePreviewCalendar(schedulePreview.data.calendar)}
                        </Typography>
                        {schedulePreview.data.schedule.note && (
                          <Typography variant="caption" color="text.secondary"
                            component="div" sx={{ mt: 0.5 }}>
                            {schedulePreview.data.schedule.note}
                          </Typography>
                        )}
                      </Box>
                    )}
                  </Stack>
                )}

                <Divider sx={{ my: 1 }} />
                <FormControl fullWidth size="small">
                  <InputLabel id="calendar-label">Business Calendar (optional)</InputLabel>
                  <Select
                    labelId="calendar-label"
                    label="Business Calendar (optional)"
                    value={formCalendarName}
                    onChange={(e) => setFormCalendarName(String(e.target.value))}
                  >
                    <MenuItem value=""><em>None — plain calendar-day arithmetic</em></MenuItem>
                    {calendarsList.map((c) => (
                      <MenuItem key={c.id} value={c.name}>{c.name}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    The weekends and holidays this feed follows. It decides the feed's business
                    dates, its month end, and the dates its query and file name are filled with.
                  </FormHelperText>
                </FormControl>

                {/* BF-473 — Frequency Category (open string, admin-suggested vocabulary) */}
                <FormControl fullWidth size="small">
                  <InputLabel id="frequency-cat-label">Frequency category (optional)</InputLabel>
                  <Select
                    labelId="frequency-cat-label"
                    label="Frequency category (optional)"
                    value={formFrequencyCategory}
                    onChange={(e) => setFormFrequencyCategory(String(e.target.value))}
                  >
                    <MenuItem value=""><em>Uncategorized</em></MenuItem>
                    {frequencyCategoriesList.map((c) => (
                      <MenuItem key={c.value} value={c.value}>{c.label}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    Operator-facing label for dashboards / filtering.  Actual firing is
                    still controlled by <code>cron_expression</code> + <code>action_condition_sql</code>.
                    Need a new category? Type it in the database — it shows up here next time.
                  </FormHelperText>
                </FormControl>
              </Stack>
            )}

            {/* Step 2: DEPENDENCIES — what must arrive first (BRD §2).
                The platform derives the gate verdict, the blocking set and
                arrival profiles; the author only NAMES the upstreams. */}
            {activeStep === 2 && (
              <Stack spacing={2}>
                <Box sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                  <Typography variant="body2" sx={{ mb: 0.5 }}>
                    Upstream dependencies (triggers)
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
                    Generic trigger gating: any external system, Kafka topic, file landing,
                    or API event.  Feed waits until ALL rows have <code>action=COMPLETE</code> or
                    <code>SKIP</code> for the run's business_date.  Leave empty to run unconditionally.
                  </Typography>
                  {/* 2026-10-03 -- OPTIONAL, said in words: the owner read
                      this step as mandatory.  Three states kept apart:
                      none declared / being read / could not be read. */}
                  {depsLoad.state === 'failed' && (
                    <Alert severity="error" sx={{ mb: 1 }} data-testid="deps-load-failed"
                           action={editFeed ? (
                             <Button size="small" color="inherit" startIcon={<RetryIcon />}
                                     onClick={() => loadEditDeps(editFeed.id)}>Retry</Button>
                           ) : undefined}>
                      This feed&apos;s dependencies could not be read ({depsLoad.message}).
                      They are UNKNOWN, not none — saving leaves them exactly as stored.
                    </Alert>
                  )}
                  {depsLoad.state === 'loading' && (
                    <Typography variant="caption" sx={{ display: 'block', mb: 1 }}>
                      Reading this feed&apos;s dependencies…
                    </Typography>
                  )}
                  {depsLoad.state === 'loaded' && formDeps.length === 0 && (
                    <Alert severity="info" sx={{ mb: 1 }} data-testid="deps-none">
                      No dependencies — that is valid. This step is optional: the feed
                      runs on its schedule every business day with no gate. Add one only
                      if the feed must wait for something upstream.
                    </Alert>
                  )}

                  {formDeps.length > 0 && (
                    <Table size="small" sx={{ mb: 1 }}>
                      <TableHead>
                        <TableRow>
                          <TableCell>Type</TableCell>
                          <TableCell>Dependency key</TableCell>
                          <TableCell>Arrival sources</TableCell>
                          <TableCell>Upstream calendar</TableCell>
                          <TableCell>
                            <Tooltip title="When this dependency sends a NEW message for a business date already delivered: re-run that date (on), or record it only (off). Month end: SOD / ITD off, EOD on.">
                              <span>Re-runs a delivered date</span>
                            </Tooltip>
                          </TableCell>
                          <TableCell>Description</TableCell>
                          <TableCell />
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {formDeps.map((d, idx) => {
                          const t = availableDepTypes.find((x) => x.id === d.dependency_type_id);
                          return (
                            <TableRow key={d.id ?? `new-${idx}`} data-testid={`dep-row-${d.dependency_key}`}>
                              <TableCell><code>{t?.dependency_type || d.dependency_type || d.dependency_type_id}</code></TableCell>
                              <TableCell><code>{d.dependency_key}</code></TableCell>
                              <TableCell>
                                {d.arrival_sources && d.arrival_sources.length > 0 ? (
                                  <Typography variant="caption">
                                    {(d.require_mode || 'all').toUpperCase()} of: {d.arrival_sources.map(describeArrivalSource).join('; ')}
                                  </Typography>
                                ) : (
                                  <Typography variant="caption" color="text.secondary">any evidence</Typography>
                                )}
                              </TableCell>
                              <TableCell data-testid={`dep-calendar-${d.dependency_key}`}>
                                {d.calendar_name ? (
                                  <Typography variant="caption">{d.calendar_name}</Typography>
                                ) : (
                                  <Typography variant="caption" color="text.secondary">expected every run day</Typography>
                                )}
                              </TableCell>
                              <TableCell padding="checkbox">
                                <Switch size="small" checked={d.reruns_delivered !== false}
                                  slotProps={{ input: { 'aria-label': `A new message of ${d.dependency_key} re-runs a delivered date`,
                                                         'data-testid': `dep-reruns-${d.dependency_key}` } as any }}
                                  onChange={(e) => setFormDeps((prev) => prev.map((x, i) => (
                                    i === idx ? { ...x, reruns_delivered: e.target.checked } : x)))} />
                              </TableCell>
                              <TableCell>
                                <Typography variant="caption" color="text.secondary">
                                  {d.description || ''}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <IconButton aria-label="Delete" size="small"
                                  onClick={() => setFormDeps((prev) => prev.filter((_, i) => i !== idx))}>
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  )}

                  <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                    <FormControl size="small" sx={{ minWidth: 160 }}>
                      <InputLabel id="new-dep-type-label">Dependency type</InputLabel>
                      <Select labelId="new-dep-type-label" label="Dependency type"
                        value={newDepTypeId === '' ? '' : String(newDepTypeId)}
                        onChange={(e) => setNewDepTypeId(
                          e.target.value === '' ? '' : Number(e.target.value),
                        )}>
                        {availableDepTypes.length === 0 && (
                          <MenuItem value="" disabled>
                            <em>{lookupFailures['dependency types']
                              ? `Dependency types could not be read (${lookupFailures['dependency types']})`
                              : 'No types — ask admin to add KAFKA / ORACLE_TABLE / FILE / API'}</em>
                          </MenuItem>
                        )}
                        {availableDepTypes.map((t) => (
                          <MenuItem key={t.id} value={String(t.id)}>{t.dependency_type}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    <TextField label="Dependency key (e.g. topic.daily-prices)"
                      size="small" sx={{ flex: 1, minWidth: 200 }}
                      value={newDepKey}
                      onChange={(e) => setNewDepKey(e.target.value)} />
                    <TextField label="Description (optional)"
                      size="small" sx={{ minWidth: 180 }}
                      value={newDepDesc}
                      onChange={(e) => setNewDepDesc(e.target.value)} />
                    {/* FR-DEP-08 — the UPSTREAM's calendar.  On its holiday the
                        gate reports NOT EXPECTED: no WAIT, no skip, nobody paged. */}
                    <FormControl size="small" sx={{ minWidth: 220 }}>
                      <InputLabel id="new-dep-calendar-label">Upstream calendar (optional)</InputLabel>
                      <Select labelId="new-dep-calendar-label" label="Upstream calendar (optional)"
                        value={newDepCalendar}
                        onChange={(e) => setNewDepCalendar(String(e.target.value))}
                        inputProps={{ 'data-testid': 'new-dep-calendar' }}>
                        <MenuItem value=""><em>None — expected every run day</em></MenuItem>
                        {calendarsList.map((c) => (
                          <MenuItem key={c.id} value={c.name}>{c.name}</MenuItem>
                        ))}
                      </Select>
                      <FormHelperText>
                        The upstream&apos;s own holidays: on one, this dependency is
                        &quot;not expected&quot; and the feed runs without a skip.
                      </FormHelperText>
                    </FormControl>
                    <Button variant="outlined"
                      onClick={() => {
                        if (!newDepTypeId || !newDepKey.trim()) return;
                        setFormDeps((prev) => [...prev, {
                          dependency_type_id: Number(newDepTypeId),
                          dependency_key: newDepKey.trim(),
                          description: newDepDesc.trim() || null,
                          arrival_sources: newDepSources.length > 0 ? newDepSources : null,
                          require_mode: newDepSources.length > 0 ? newDepMode : null,
                          calendar_name: newDepCalendar || null,
                        }]);
                        setNewDepKey('');
                        setNewDepDesc('');
                        setNewDepCalendar('');
                        setNewDepSources([]);
                        setNewDepMode('all');
                      }}
                      disabled={!newDepTypeId || !newDepKey.trim()}>
                      Add
                    </Button>
                  </Stack>

                  {/* 2026-10-03 -- a dependency typed but never ADDED was
                      silently dropped on save.  Say so, and offer Discard;
                      it never blocks leaving the step (deps are optional). */}
                  {(newDepKey.trim() !== '' || newDepTypeId !== '') && (
                    <Alert severity="warning" sx={{ mt: 1 }} data-testid="deps-unadded-draft"
                           action={(
                             <Button size="small" color="inherit"
                                     onClick={() => {
                                       setNewDepTypeId(''); setNewDepKey('');
                                       setNewDepDesc(''); setNewDepCalendar('');
                                       setNewDepSources([]);
                                     }}>Discard</Button>
                           )}>
                      Not added yet{newDepKey.trim() ? ` — "${newDepKey.trim()}"` : ''}:
                      click Add to make it a dependency, or Discard. What is not added
                      is not saved.
                    </Alert>
                  )}

                  {/* 2026-09-27 — arrival sources: WHERE this dependency's
                      evidence comes from.  Optional; with none declared any
                      evidence (a tracking row, any ledger arrival) satisfies
                      it.  With several, ALL (default) or ANY must be met. */}
                  <Box sx={{ mt: 1, p: 1, border: '1px dashed', borderColor: 'divider', borderRadius: 1 }}
                    data-testid="dep-arrival-sources">
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.75 }}>
                      Arrival sources for the dependency being added (optional). Leave empty to accept any
                      evidence. &quot;Iceberg table has data for the date&quot; is met when a commit to the
                      table proves, from its own metadata, that the business date exists in the chosen column.
                      &quot;Control / landed file&quot; is met when the path, rendered for the run&apos;s business
                      date, holds the files (and the control file, if named); the file watcher lists it while
                      the run waits.
                    </Typography>
                    {newDepSources.length > 0 && (
                      <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap alignItems="center" sx={{ mb: 1 }}>
                        {newDepSources.map((s, i) => (
                          <Chip key={`${s.kind}-${i}`} size="small" label={describeArrivalSource(s)}
                            onDelete={() => setNewDepSources((prev) => prev.filter((_, j) => j !== i))} />
                        ))}
                        <FormControl size="small" sx={{ minWidth: 150 }}>
                          <InputLabel id="new-dep-mode-label">Require</InputLabel>
                          <Select labelId="new-dep-mode-label" label="Require" value={newDepMode}
                            onChange={(e) => setNewDepMode(e.target.value === 'any' ? 'any' : 'all')}>
                            <MenuItem value="all">ALL sources</MenuItem>
                            <MenuItem value="any">ANY source</MenuItem>
                          </Select>
                        </FormControl>
                      </Stack>
                    )}
                    <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                      <FormControl size="small" sx={{ minWidth: 240 }}>
                        <InputLabel id="new-src-kind-label">Arrival source</InputLabel>
                        <Select labelId="new-src-kind-label" label="Arrival source" value={newSrcKind}
                          onChange={(e) => {
                            setNewSrcKind(String(e.target.value));
                            // 2026-09-27 -- an Iceberg source is labelled as one:
                            // pre-select the ICEBERG_TABLE type when it exists.
                            if (String(e.target.value) === 'iceberg_commit') {
                              const ice = availableDepTypes.find((x: any) => x.dependency_type === 'ICEBERG_TABLE');
                              if (ice) setNewDepTypeId(ice.id);
                            }
                            // 2026-10-07 -- and a file source as FILE.
                            if (String(e.target.value) === 'file') {
                              const fileType = availableDepTypes.find((x: any) => x.dependency_type === 'FILE');
                              if (fileType) setNewDepTypeId(fileType.id);
                            }
                            // 2026-10-11 -- and an Oracle-table source as ORACLE_TABLE.
                            if (String(e.target.value) === 'oracle_table') {
                              const oraType = availableDepTypes.find((x: any) => x.dependency_type === 'ORACLE_TABLE');
                              if (oraType) setNewDepTypeId(oraType.id);
                            }
                            setNewSrcConnId('');
                            setNewSrcTable('');
                            setNewSrcColumn('');
                            resetFileSourceFields();
                          }}>
                          {(arrivalVocab?.kinds ?? []).length === 0 && (
                            <MenuItem value="" disabled><em>No arrival sources available</em></MenuItem>
                          )}
                          {(arrivalVocab?.kinds ?? []).map((k) => (
                            <MenuItem key={k.kind} value={k.kind}>{k.label}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                      {newSrcKind === 'iceberg_commit' && (
                        <>
                          <FormControl size="small" sx={{ minWidth: 180 }}>
                            <InputLabel id="new-src-conn-label">Connection</InputLabel>
                            <Select labelId="new-src-conn-label" label="Connection"
                              value={newSrcConnId === '' ? '' : String(newSrcConnId)}
                              onChange={(e) => {
                                setNewSrcConnId(e.target.value === '' ? '' : Number(e.target.value));
                                setNewSrcTable('');
                                setNewSrcColumn('');
                              }}>
                              {connections.filter((c) => c.connection_type === 's3').map((c) => (
                                <MenuItem key={c.id} value={String(c.id)}>{c.name}</MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                          <FormControl size="small" sx={{ minWidth: 180 }} disabled={newSrcConnId === ''}>
                            <InputLabel id="new-src-table-label">Iceberg table</InputLabel>
                            <Select labelId="new-src-table-label" label="Iceberg table" value={newSrcTable}
                              onChange={(e) => { setNewSrcTable(String(e.target.value)); setNewSrcColumn(''); }}>
                              {srcTables.map((t) => (
                                <MenuItem key={t.name} value={t.name}>{t.name}</MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                          <FormControl size="small" sx={{ minWidth: 160 }} disabled={!newSrcTable}>
                            <InputLabel id="new-src-col-label">Date column</InputLabel>
                            <Select labelId="new-src-col-label" label="Date column" value={newSrcColumn}
                              onChange={(e) => setNewSrcColumn(String(e.target.value))}>
                              {srcColumns.map((c) => (
                                <MenuItem key={c} value={c}>{c}</MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                        </>
                      )}
                      {newSrcKind === 'file' && (
                        <>
                          <FormControl size="small" sx={{ minWidth: 180 }}>
                            <InputLabel id="new-src-file-conn-label">Connection</InputLabel>
                            <Select labelId="new-src-file-conn-label" label="Connection"
                              value={newSrcConnId === '' ? '' : String(newSrcConnId)}
                              onChange={(e) => setNewSrcConnId(e.target.value === '' ? '' : Number(e.target.value))}>
                              {connections.filter((c) => FILE_SOURCE_CONNECTION_TYPES.includes(String(c.connection_type || '').toLowerCase())).map((c) => (
                                <MenuItem key={c.id} value={String(c.id)}>{c.name}</MenuItem>
                              ))}
                            </Select>
                          </FormControl>
                          <TextField size="small" label="Path (prefix)" sx={{ minWidth: 280 }}
                            value={newSrcPath} onChange={(e) => setNewSrcPath(e.target.value)}
                            placeholder="landing/gl/{business_date:YYYYMMDD}/"
                            helperText="Rendered for the run's business date" />
                          <TextField size="small" label="File name pattern" sx={{ width: 170 }}
                            value={newSrcPattern} onChange={(e) => setNewSrcPattern(e.target.value)}
                            placeholder="*.csv" />
                          <TextField size="small" label="Control file" sx={{ width: 150 }}
                            value={newSrcControl} onChange={(e) => setNewSrcControl(e.target.value)}
                            placeholder="READY or *.ctl" />
                          <TextField size="small" label="Min files" type="number" sx={{ width: 110 }}
                            value={newSrcMinFiles} onChange={(e) => setNewSrcMinFiles(e.target.value)}
                            placeholder="1" />
                        </>
                      )}
                      {newSrcKind === 'oracle_table' && (
                        /* 2026-10-11 -- the OG landing table as a source: an Oracle
                           connection and the table; the table's resolver rules are
                           deployment config (feed_generation.dependency_oracle_table). */
                        <>
                          {(() => {
                            // 2026-10-12 -- only a (connection, table) the watcher
                            // READS can ever be met: the server lists them; a pair
                            // it does not watch is refused at the save
                            const watched = arrivalVocab?.kinds.find((k) => k.kind === 'oracle_table')?.watched;
                            if (watched) {
                              const cur = newSrcConnId !== '' && newSrcOracleTable
                                ? `${newSrcConnId}|${newSrcOracleTable}` : '';
                              return (
                                <FormControl size="small" sx={{ minWidth: 320 }}>
                                  <InputLabel id="new-src-ora-watched-label">Watched table</InputLabel>
                                  <Select labelId="new-src-ora-watched-label" label="Watched table" value={cur}
                                    inputProps={{ 'data-testid': 'new-src-ora-watched' }}
                                    onChange={(e) => {
                                      const [cid, ...t] = String(e.target.value).split('|');
                                      setNewSrcConnId(cid ? Number(cid) : '');
                                      setNewSrcOracleTable(t.join('|'));
                                    }}>
                                    {watched.length === 0 && (
                                      <MenuItem value="" disabled><em>No table is watched on this deployment</em></MenuItem>
                                    )}
                                    {watched.map((w) => (
                                      <MenuItem key={`${w.connection_id}|${w.table}`} value={`${w.connection_id}|${w.table}`}>
                                        {w.table} on {w.connection_name}
                                      </MenuItem>
                                    ))}
                                  </Select>
                                  <FormHelperText>The tables the message watcher reads (feed_generation.dependency_oracle_table)</FormHelperText>
                                </FormControl>
                              );
                            }
                            return (<>
                              <FormControl size="small" sx={{ minWidth: 180 }}>
                                <InputLabel id="new-src-ora-conn-label">Connection</InputLabel>
                                <Select labelId="new-src-ora-conn-label" label="Connection"
                                  value={newSrcConnId === '' ? '' : String(newSrcConnId)}
                                  onChange={(e) => setNewSrcConnId(e.target.value === '' ? '' : Number(e.target.value))}>
                                  {connections.filter((c) => String(c.connection_type || '').toLowerCase() === 'oracle').map((c) => (
                                    <MenuItem key={c.id} value={String(c.id)}>{c.name}</MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                              <TextField size="small" label="Oracle table" sx={{ minWidth: 240 }}
                                value={newSrcOracleTable} onChange={(e) => setNewSrcOracleTable(e.target.value)}
                                placeholder="QS_KAFKA_MESSAGE"
                                helperText="[SCHEMA.]TABLE; its rules are configured per deployment" />
                            </>);
                          })()}
                        </>
                      )}
                      {newSrcKind === 'kafka' && (
                        /* 2026-10-08 -- the topic the message is expected on.  Optional:
                           without it any message a resolver rule maps to this dependency
                           satisfies the source; with two topics the dependency waits for
                           both (ALL) or either (ANY). */
                        <TextField size="small" label="Topic (optional)" sx={{ minWidth: 220 }}
                          value={newSrcTopic} onChange={(e) => setNewSrcTopic(e.target.value)}
                          placeholder="entity_load"
                          helperText="A resolver rule must map it to this dependency" />
                      )}
                      <Button variant="outlined" size="small" disabled={!canAddSource} onClick={addNewDepSource}>
                        Add source
                      </Button>
                    </Stack>
                    {/* 2026-10-07 -- a kind whose PRODUCER is down cannot be
                        satisfied by waiting: say so before the author relies on it. */}
                    {(() => {
                      const health = arrivalVocab?.kinds.find((k) => k.kind === newSrcKind)?.producer_health;
                      return health?.state === 'down' ? (
                        <Typography variant="caption" color="warning.main" sx={{ display: 'block', mt: 0.5 }}
                          data-testid="new-src-producer-down">
                          This source cannot be satisfied right now: its producer ({health.producer}) is not
                          running — {health.reason}
                        </Typography>
                      ) : null;
                    })()}
                    {srcLookupError && (
                      <Typography variant="caption" color="error" sx={{ display: 'block', mt: 0.5 }}>
                        {srcLookupError}
                      </Typography>
                    )}
                  </Box>
                </Box>
                <Typography variant="caption" color="text.secondary">
                  A dependency's own governing calendar (whose business days decide
                  when it is EXPECTED) is not yet settable here — the platform
                  currently applies this feed's calendar to its dependencies.
                </Typography>
              </Stack>
            )}

            {/* Step 3: SHAPE — partition columns -> how many files (BRD §2,
                §9.3).  Declared, never discovered: auditable, overridable
                per run, and bounded by max_parts.  Stored as the reserved
                query_params._partition key (core/feed/partition_shape.py). */}
            {activeStep === 3 && (
              <Stack spacing={2}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formShape.enabled}
                      onChange={e => setFormShape(prev => ({ ...prev, enabled: e.target.checked }))}
                    />
                  }
                  label={
                    <Stack>
                      <Typography variant="body2">Declare a partition shape (multi-file feed)</Typography>
                      <Typography variant="caption" color="text.secondary">
                        Off = a single output file (the common case).  On = one file per
                        declared identity, named <code>_NNN_of_NNNN</code> from the declared
                        total.  The split is recorded, so it can be shown again next year.
                      </Typography>
                    </Stack>
                  }
                />
                {formShape.enabled && (
                  <Stack spacing={2} sx={{ pl: 2, borderLeft: '2px solid', borderColor: 'divider' }}>
                    <Autocomplete
                      multiple freeSolo size="small" openOnFocus
                      options={formPartitionInfo.partitionColumns}
                      value={formShape.columns}
                      onChange={(_, v) => setFormShape(prev => ({ ...prev, columns: v.map(String) }))}
                      renderInput={rp => (
                        <TextField {...rp} label="Partition columns"
                          placeholder="e.g. business_date, entity"
                          helperText="The column(s) the declared identities apply to." />
                      )}
                    />
                    <TextField
                      label="Partition values (one per line)"
                      value={formShape.values}
                      onChange={e => setFormShape(prev => ({ ...prev, values: e.target.value }))}
                      multiline rows={4} fullWidth size="small"
                      error={_shapeErrors.length > 0 && Boolean(formShape.valuesSql.trim()) && formShape.values.trim() !== ''}
                      helperText="Inline identities — one file per line.  Declare EITHER this list OR the SQL below, never both."
                      sx={{ '& textarea': { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                    />
                    <TextField
                      label="Partition values SQL"
                      value={formShape.valuesSql}
                      onChange={e => setFormShape(prev => ({ ...prev, valuesSql: e.target.value }))}
                      multiline rows={3} fullWidth size="small"
                      error={_shapeErrors.length > 0 && Boolean(formShape.valuesSql.trim()) && formShape.values.trim() !== ''}
                      placeholder={"SELECT DISTINCT entity FROM ref.entities WHERE active='Y'"}
                      helperText="Or the query that yields the identities at run time (first column of each row)."
                      sx={{ '& textarea': { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                    />
                    <Stack direction="row" spacing={1}>
                      <TextField
                        label="Max parts"
                        value={formShape.maxParts}
                        onChange={e => setFormShape(prev => ({ ...prev, maxParts: e.target.value }))}
                        size="small" sx={{ flex: 1 }}
                        error={_shapeErrors.some(m => m.includes('max_parts'))}
                        helperText="Refuse, loudly, above this — a partition explosion becomes a refusal, not 40,000 child runs.  Empty = unbounded; 0 does NOT mean unlimited."
                      />
                      <FormControl size="small" sx={{ flex: 1 }}>
                        <InputLabel id="shape-on-empty-label">On empty list</InputLabel>
                        <Select
                          labelId="shape-on-empty-label"
                          label="On empty list"
                          value={formShape.onEmpty}
                          onChange={e => setFormShape(prev => ({
                            ...prev, onEmpty: e.target.value === 'skip' ? 'skip' : 'fail',
                          }))}
                        >
                          <MenuItem value="fail">fail — refuse the run</MenuItem>
                          <MenuItem value="skip">skip — no file, recorded as skipped</MenuItem>
                        </Select>
                        <FormHelperText>An empty list is a DECISION, never a silent no-op.</FormHelperText>
                      </FormControl>
                    </Stack>
                    {_shapeErrors.length > 0 && (
                      <Alert severity="error">
                        {_shapeErrors.map((m, i) => <div key={i}>{m}</div>)}
                      </Alert>
                    )}
                    {_shapeErrors.length === 0 && _shapeHints.length > 0 && (
                      <Alert severity="info">
                        {_shapeHints.map((m, i) => <div key={i}>{m}</div>)}
                      </Alert>
                    )}
                  </Stack>
                )}
              </Stack>
            )}

            {/* Step 4: CONTRACT — format, encoding, naming, checksum,
                encryption (BRD §2, §10).  Contract terms, not preferences:
                validated at authoring by the API (core/feed/contract.py);
                terms the platform cannot honour today come back as
                contract_unsupported warnings and are SHOWN, not swallowed. */}
            {activeStep === 4 && (
              <Stack spacing={2}>
                <FormControl fullWidth size="small">
                  <InputLabel id="output-format-label">Output Format</InputLabel>
                  <Select labelId="output-format-label" value={formOutputFormat} label="Output Format"
                          onChange={e => setFormOutputFormat(e.target.value)}>
                    {OUTPUT_FORMATS.map(f => <MenuItem key={f} value={f}>{f.toUpperCase()}</MenuItem>)}
                  </Select>
                </FormControl>
                <TextField label="Filename Template" value={formFilenameTemplate}
                           onChange={e => setFormFilenameTemplate(e.target.value)}
                           fullWidth size="small"
                           helperText="Legacy: {name},{date},{ext},{timestamp},{uuid}.  Enterprise: ${YYYYMMDD}, ${COB_PREV_EOM(YYYYMMDD)}, {run_date:YYYYMMDD}" />
                <TextField label="Control File Template (.ctl)" value={formControlFileTemplate}
                           onChange={e => setFormControlFileTemplate(e.target.value)}
                           fullWidth size="small"
                           helperText="Optional sidecar manifest filename.  Leave empty to pair with the data file (<data-name>.ctl) when a format is selected below, or for no .ctl at all.  Example: feed_{run_date:YYYYMMDD}.ctl"
                           placeholder="feed_{run_date:YYYYMMDD}.ctl" />
                {/* Phase 4 (2026-08-23): always visible — a format WITHOUT a
                    template now produces a ctl named after the data file.
                    Hiding it behind the template also left a stale
                    control_file_format_id behind when the template was
                    cleared. */}
                <FormControl size="small" fullWidth>
                  <InputLabel id="ctl-format-label">Control File Format</InputLabel>
                  <Select
                    labelId="ctl-format-label"
                    value={formControlFileFormatId}
                    label="Control File Format"
                    onChange={e => setFormControlFileFormatId(e.target.value as any)}
                  >
                    <MenuItem value=""><em>{formControlFileTemplate.trim() ? 'Default layout — single SHA-256 checksum' : 'No control file'}</em></MenuItem>
                    {controlFileFormats.map(f => (
                      <MenuItem key={f.id} value={f.id}>
                        {f.name}{f.description ? ` — ${f.description}` : ''}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {/* 2026-10-22 (the owner: "need preview of select control file with
                    dummy data how ctl file will look like") -- rendered by the code a
                    run uses, over a 3-row dummy data file */}
                <Box>
                  <Button size="small" variant="outlined" data-testid="ctl-preview-btn"
                          disabled={!!ctlPreview?.loading}
                          onClick={async () => {
                            setCtlPreview({ loading: true });
                            try {
                              const data = await api.previewControlFile({
                                name: formName.trim() || 'FEED_PREVIEW',
                                feed_id: editFeed?.id ?? null,
                                output_format: formOutputFormat,
                                output_filename_template: formFilenameTemplate.trim() || null,
                                control_file_template: formControlFileTemplate.trim() || null,
                                control_file_format_id: formControlFileFormatId || null,
                                output_options: buildOutputOptions(formContractOpts, editFeed?.output_options || {}),
                                calendar_name: formCalendarName || null,
                              });
                              setCtlPreview({ data });
                            } catch (e: any) {
                              setCtlPreview({ error: e?.message || String(e) });
                            }
                          }}>
                    {ctlPreview?.loading ? 'Rendering…' : 'Preview control file'}
                  </Button>
                  {ctlPreview?.error && (
                    <Alert severity="error" sx={{ mt: 1 }} data-testid="ctl-preview-error">{ctlPreview.error}</Alert>
                  )}
                  {ctlPreview?.data && !ctlPreview.data.control_file && (
                    <Alert severity="info" sx={{ mt: 1 }} data-testid="ctl-preview-none">{ctlPreview.data.reason}</Alert>
                  )}
                  {ctlPreview?.data?.control_file && (
                    <Paper variant="outlined" sx={{ mt: 1, p: 1.5 }} data-testid="ctl-preview">
                      <Typography variant="caption" color="text.secondary" display="block">
                        Data file: <b>{ctlPreview.data.data_file}</b> · Control file: <b>{ctlPreview.data.control_file}</b>
                        {' '}· layout: {ctlPreview.data.format}
                        {(ctlPreview.data.dummy?.steps || []).length ? ` · ${ctlPreview.data.dummy.steps.join(', ')}` : ''}
                        {ctlPreview.data.control_file_compressed
                          ? ` · the control file is delivered ${ctlPreview.data.control_file_compressed}-compressed (shown readable below)` : ''}
                      </Typography>
                      <Box component="pre" data-testid="ctl-preview-content"
                           sx={{ m: 0, mt: 1, p: 1, bgcolor: 'action.hover', borderRadius: 1, fontSize: 12,
                                 fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                        {ctlPreview.data.content}
                      </Box>
                      <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 0.5 }}>
                        {ctlPreview.data.note}
                      </Typography>
                    </Paper>
                  )}
                </Box>

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Format terms</Typography>
                <Stack direction="row" spacing={1}>
                  <TextField label="Delimiter" value={formContractOpts.delimiter}
                             onChange={e => setContractOpt('delimiter', e.target.value)}
                             size="small" sx={{ flex: 1 }}
                             error={formContractOpts.delimiter.length !== 1}
                             helperText="Exactly one character" />
                  <TextField label="Null marker (na_rep)" value={formContractOpts.nullMarker}
                             onChange={e => setContractOpt('nullMarker', e.target.value)}
                             size="small" sx={{ flex: 1 }}
                             helperText="How NULL / NaN / Inf render" />
                  <Autocomplete
                    freeSolo size="small" sx={{ flex: 1 }}
                    options={COMMON_ENCODINGS}
                    value={formContractOpts.encoding}
                    onInputChange={(_, v) => setContractOpt('encoding', v || '')}
                    renderInput={rp => (
                      <TextField {...rp} label="Encoding"
                                 helperText="utf-8 is what ships today" />
                    )}
                  />
                </Stack>
                {/* quotechar / escapechar / empty_string_marker are
                    delimited-text terms (contract.py §10.1) — only CSV
                    takes them.  Stored values on other formats survive
                    untouched (buildOutputOptions re-emits from state);
                    only the INPUTS are format-gated. */}
                {formOutputFormat === 'csv' && (
                  <Stack direction="row" spacing={1}>
                    <TextField label="Quote character" value={formContractOpts.quotechar}
                               onChange={e => setContractOpt('quotechar', e.target.value)}
                               size="small" sx={{ flex: 1 }}
                               helperText={'Default " — the only value the renderer honours today.'} />
                    <TextField label="Escape character" value={formContractOpts.escapechar}
                               onChange={e => setContractOpt('escapechar', e.target.value)}
                               size="small" sx={{ flex: 1 }}
                               helperText="Empty = none (the engine default)." />
                    <TextField label="Empty-string marker" value={formContractOpts.emptyStringMarker}
                               onChange={e => setContractOpt('emptyStringMarker', e.target.value)}
                               size="small" sx={{ flex: 1 }}
                               helperText={'A DISTINCT convention for "" vs NULL. Empty = same as the null marker.'} />
                  </Stack>
                )}
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-quoting-label">Quoting</InputLabel>
                    <Select labelId="ct-quoting-label" label="Quoting"
                            value={formContractOpts.quoting}
                            onChange={e => setContractOpt('quoting', String(e.target.value))}>
                      {QUOTING_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-term-label">Line terminator</InputLabel>
                    <Select labelId="ct-term-label" label="Line terminator"
                            value={formContractOpts.lineTerminator}
                            onChange={e => setContractOpt('lineTerminator', String(e.target.value))}>
                      {LINE_TERMINATORS.map(v => <MenuItem key={v} value={v}>{v.toUpperCase()}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <Stack sx={{ flex: 1 }} justifyContent="center">
                    <FormControlLabel
                      control={<Switch size="small" checked={formContractOpts.header}
                                       onChange={e => setContractOpt('header', e.target.checked)} />}
                      label="Header row"
                    />
                    <FormControlLabel
                      control={<Switch size="small" checked={formContractOpts.trailingDelimiter}
                                       onChange={e => setContractOpt('trailingDelimiter', e.target.checked)} />}
                      label="Trailing delimiter"
                    />
                  </Stack>
                </Stack>

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Packaging, compression, encryption</Typography>
                <Typography variant="caption" color="text.secondary">
                  Two axes, not one: packaging (zip/tar) makes many parts ONE deliverable;
                  a codec compresses each stream.  The processing order is fixed by the
                  engine — package → compress → encrypt → checksum — so the checksum always
                  covers what is SENT.
                </Typography>
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-pack-label">Packaging</InputLabel>
                    <Select labelId="ct-pack-label" label="Packaging"
                            value={formContractOpts.packaging}
                            onChange={e => setContractOpt('packaging', String(e.target.value))}>
                      {PACKAGING_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-codec-label">Compression codec</InputLabel>
                    <Select labelId="ct-codec-label" label="Compression codec"
                            value={formContractOpts.codec}
                            onChange={e => setContractOpt('codec', String(e.target.value))}>
                      {CODEC_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-encr-label">Encryption</InputLabel>
                    <Select labelId="ct-encr-label" label="Encryption"
                            value={formContractOpts.encryption}
                            onChange={e => setContractOpt('encryption', String(e.target.value))}>
                      {ENCRYPTION_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Stack>
                {formContractOpts.encryption === 'pgp' && (
                  <TextField label="PGP recipient key" value={formContractOpts.pgpRecipient}
                             onChange={e => setContractOpt('pgpRecipient', e.target.value)}
                             fullWidth size="small" required
                             error={!formContractOpts.pgpRecipient.trim()}
                             helperText="Who the file is encrypted to — required when encryption=pgp." />
                )}

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Checksum &amp; naming</Typography>
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-ck-label">Checksum</InputLabel>
                    <Select labelId="ct-ck-label" label="Checksum"
                            value={formContractOpts.checksumAlgorithm}
                            onChange={e => setContractOpt('checksumAlgorithm', String(e.target.value))}>
                      <MenuItem value=""><em>none</em></MenuItem>
                      {CHECKSUM_ALGORITHMS.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-scope-label">Checksum scope</InputLabel>
                    <Select labelId="ct-scope-label" label="Checksum scope"
                            value={formContractOpts.checksumScope}
                            onChange={e => setContractOpt('checksumScope', String(e.target.value))}>
                      {CHECKSUM_SCOPES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-covers-label">Checksum of</InputLabel>
                    <Select labelId="ct-covers-label" label="Checksum of"
                            value={formContractOpts.checksumCovers}
                            inputProps={{ 'data-testid': 'contract-checksum-covers' }}
                            onChange={e => setContractOpt('checksumCovers', String(e.target.value))}>
                      <MenuItem value="sent">the file sent (after compression)</MenuItem>
                      <MenuItem value="uncompressed">the data file BEFORE compression</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-ctlc-label">Control file compression</InputLabel>
                    <Select labelId="ct-ctlc-label" label="Control file compression"
                            value={formContractOpts.controlFileCompression}
                            inputProps={{ 'data-testid': 'contract-ctl-compression' }}
                            onChange={e => setContractOpt('controlFileCompression', String(e.target.value))}>
                      <MenuItem value="none">none (.ctl)</MenuItem>
                      <MenuItem value="same_as_data">same as the data file (e.g. .ctl.gz)</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-side-label">Digest sidecar</InputLabel>
                    <Select labelId="ct-side-label" label="Digest sidecar"
                            value={formContractOpts.sidecar}
                            onChange={e => setContractOpt('sidecar', String(e.target.value))}>
                      {SIDECAR_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-dl-label">Digest line</InputLabel>
                    <Select labelId="ct-dl-label" label="Digest line"
                            value={formContractOpts.digestLine}
                            onChange={e => setContractOpt('digestLine', String(e.target.value))}>
                      {DIGEST_LINE_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Stack>
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-seq-label">Sequencing</InputLabel>
                    <Select labelId="ct-seq-label" label="Sequencing"
                            value={formContractOpts.sequencing}
                            onChange={e => setContractOpt('sequencing', String(e.target.value))}>
                      {SEQUENCING_VALUES.map(v => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ flex: 1 }}>
                    <InputLabel id="ct-redel-label">Re-delivery naming</InputLabel>
                    <Select labelId="ct-redel-label" label="Re-delivery naming"
                            value={formContractOpts.redeliveryNaming}
                            onChange={e => setContractOpt('redeliveryNaming', String(e.target.value))}>
                      {REDELIVERY_VALUES.map(v => (
                        <MenuItem key={v} value={v}>
                          {v === 'reuse' ? 'reuse — corrected file keeps the original name' : 'revision — corrected file carries a revision marker'}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <Stack sx={{ flex: 1 }} justifyContent="center">
                    <FormControlLabel
                      control={<Switch size="small" checked={formContractOpts.multipartNaming}
                                       onChange={e => setContractOpt('multipartNaming', e.target.checked)} />}
                      label="_NNN_of_NNNN part naming"
                    />
                  </Stack>
                </Stack>

                {_contractErrors.length > 0 && (
                  <Alert severity="error">
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      Contract refused at authoring (FR-ART-01):
                    </Typography>
                    {_contractErrors.map((m, i) => <div key={i}>{m}</div>)}
                  </Alert>
                )}
                {_contractHints.length > 0 && (
                  <Alert severity="warning">
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      Real contract terms the platform cannot honour today — the save
                      records them and returns a warning, it does not promise them:
                    </Typography>
                    {_contractHints.map((m, i) => <div key={i}>{m}</div>)}
                  </Alert>
                )}
              </Stack>
            )}

            {/* Step 5: DELIVERY — an ordered chain of hops (BRD §2, §11).
                One destination is authorable today: the engine derives a
                one-hop plan from it (core/feed/delivery_hops.py::
                build_hop_plan legacy shape).  Multi-hop chains exist in
                the engine but have no storage field on the feed yet. */}
            {activeStep === 5 && (
              <Stack spacing={2}>
                <FormControl fullWidth size="small">
                  <InputLabel id="destination-type-label">Destination Type</InputLabel>
                  <Select labelId="destination-type-label" value={formDestType} label="Destination Type"
                          onChange={e => setFormDestType(e.target.value)}>
                    {DESTINATION_TYPES.map(d => <MenuItem key={d} value={d}>{d.toUpperCase()}</MenuItem>)}
                  </Select>
                </FormControl>

                {formDestType === 'local' && (
                  <TextField label="Output Directory" value={formDestPath}
                             onChange={e => setFormDestPath(e.target.value)}
                             fullWidth size="small" placeholder={defaultOutputDir || 'data/feeds'}
                             helperText={`Default: ${defaultOutputDir || 'data/feeds'} — override with any path (created if missing)`} />
                )}
                {formDestType === 's3' && (
                  <>
                    <TextField label="S3 Bucket" value={formDestBucket}
                               onChange={e => setFormDestBucket(e.target.value)}
                               fullWidth size="small" required />
                    <TextField label="S3 Prefix" value={formDestPrefix}
                               onChange={e => setFormDestPrefix(e.target.value)}
                               fullWidth size="small" />
                  </>
                )}
                {formDestType === 'sftp' && (
                  <SftpDestinationFields
                    value={formDestSftp}
                    onChange={setFormDestSftp}
                    feedId={editFeed?.id ?? null}
                  />
                )}
                {formDestType === 'oracle' && (
                  <>
                    {/* _deliver_oracle reads connection_id + table (required),
                        mode and batch_size (optional).  Nothing else is
                        authorable here because nothing else is read. */}
                    <Stack direction="row" spacing={1}>
                      <FormControl size="small" required sx={{ flex: 1 }}
                                   error={!formDestOracle.connectionId.trim()}>
                        <InputLabel id="destination-oracle-connection-label">Oracle Connection</InputLabel>
                        <Select labelId="destination-oracle-connection-label" label="Oracle Connection"
                                value={formDestOracle.connectionId}
                                onChange={e => setFormDestOracle(d => ({ ...d, connectionId: String(e.target.value) }))}>
                          {_oracleConnections.map(c => (
                            <MenuItem key={c.id} value={String(c.id)}>{c.name} (#{c.id})</MenuItem>
                          ))}
                          {formDestOracle.connectionId.trim()
                            && !_oracleConnections.some(c => String(c.id) === formDestOracle.connectionId) && (
                            <MenuItem value={formDestOracle.connectionId} disabled>
                              Connection #{formDestOracle.connectionId} (not an Oracle connection, or no longer available)
                            </MenuItem>
                          )}
                        </Select>
                        {_oracleConnections.length === 0 && !formDestOracle.connectionId.trim() && (
                          <FormHelperText>
                            No Oracle connections exist — create one under Connections first.
                          </FormHelperText>
                        )}
                      </FormControl>
                      <TextField label="Target Table" size="small" required sx={{ flex: 1 }}
                                 value={formDestOracle.table}
                                 onChange={e => setFormDestOracle(d => ({ ...d, table: e.target.value }))}
                                 placeholder="SCHEMA.TABLE"
                                 helperText="The table the rows insert into — created from the feed's output if it does not exist; an existing table's columns must match" />
                    </Stack>
                    <Stack direction="row" spacing={1}>
                      <FormControl size="small" sx={{ flex: 1 }}>
                        <InputLabel id="destination-oracle-mode-label">Write Mode</InputLabel>
                        <Select labelId="destination-oracle-mode-label" label="Write Mode"
                                value={formDestOracle.mode}
                                onChange={e => setFormDestOracle(d => ({ ...d, mode: e.target.value as OracleDestMode }))}>
                          <MenuItem value="append">Append — insert rows, keep what is there</MenuItem>
                          <MenuItem value="truncate_insert">Truncate then insert — replace the table's contents</MenuItem>
                        </Select>
                      </FormControl>
                      <TextField label="Batch Size" size="small" sx={{ flex: 1 }}
                                 value={formDestOracle.batchSize}
                                 onChange={e => setFormDestOracle(d => ({ ...d, batchSize: e.target.value }))}
                                 placeholder="platform default"
                                 helperText="Rows per INSERT batch; blank = platform default" />
                    </Stack>
                    {_oracleDestErrors.length > 0 && (
                      <Alert severity="error">
                        {_oracleDestErrors.map((m, i) => <div key={i}>{m}</div>)}
                      </Alert>
                    )}
                  </>
                )}

                <Typography variant="caption" color="text.secondary">
                  Delivery runs as a chain of hops over the certified output —
                  this destination becomes a one-hop plan
                  ({formDestType.toUpperCase()}
                  {formDestType === 'sftp' || formDestType === 'oracle'
                    ? ', never auto-retried: repeating a counterparty send is a real incident'
                    : ', repeat-safe'})
                  unless a multi-hop chain is declared below.
                </Typography>

                <Divider sx={{ my: 1 }} />
                {/* BRD §11 / §14.2 — the DELIVERY chain (core/feed/
                    delivery_hops.py).  Off = the single destination above,
                    unchanged, and NO delivery_chain key is sent.  On = an
                    ordered chain of hops; the order here IS the delivery
                    order. */}
                <FormControlLabel
                  control={
                    <Switch
                      checked={formDeliveryChain.enabled}
                      onChange={e => {
                        const on = e.target.checked;
                        setFormDeliveryChain(prev => ({
                          enabled: on,
                          // First enable seeds one local hop — a chain
                          // lands internally before it reaches a
                          // counterparty (deleting it shows the
                          // empty-chain refusal).
                          hops: on && prev.hops.length === 0
                            ? [emptyDeliveryHop('local')] : prev.hops,
                        }));
                      }}
                    />
                  }
                  label={
                    <Stack>
                      <Typography variant="body2">Declare a delivery chain</Typography>
                      <Typography variant="caption" color="text.secondary">
                        Off = this feed keeps the single destination above,
                        exactly as today.  On = delivery becomes an ORDERED
                        chain of hops (materialise → SFTP → archive), each
                        independently retryable — the order below is the
                        delivery order.
                      </Typography>
                    </Stack>
                  }
                />
                {!formDeliveryChain.enabled
                  && Boolean((editFeed as any)?.delivery_chain) && (
                  <Alert severity="info">
                    This feed has a stored delivery chain.  Saving with the
                    chain switched off REMOVES it — the feed reverts to the
                    single destination above.
                  </Alert>
                )}
                {formDeliveryChain.enabled && (
                  <Stack spacing={2} sx={{ pl: 2, borderLeft: '2px solid', borderColor: 'divider' }}>
                    {formDeliveryChain.hops.map((hop, i) => {
                      const _renameWarning = deliveryHopRenameWarning(hop);
                      const _otherLabels = formDeliveryChain.hops
                        .filter((_, j) => j !== i).map(deliveryHopLabel);
                      const _staleRequires =
                        hop.requires !== REQUIRES_AUTO
                        && hop.requires !== REQUIRES_INDEPENDENT
                        && !_otherLabels.includes(hop.requires);
                      return (
                        <Box key={i} sx={{ p: 1.5, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
                          <Stack direction="row" spacing={1} alignItems="flex-start" sx={{ mb: 1 }}>
                            <Chip size="small" label={`Hop ${i + 1}`} sx={{ mt: 1 }} />
                            <FormControl size="small" sx={{ minWidth: 120 }}>
                              <InputLabel id={`hop-target-${i}`}>Target</InputLabel>
                              <Select
                                labelId={`hop-target-${i}`} label="Target"
                                value={hop.target}
                                onChange={e => setHop(i, { target: e.target.value as DeliveryHopTarget })}
                              >
                                {DELIVERY_HOP_TARGETS.map(t => (
                                  <MenuItem key={t} value={t}>{t.toUpperCase()}</MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                            <TextField
                              label={`Hop ${i + 1} label`} size="small" sx={{ flex: 1 }}
                              value={hop.label} placeholder={hop.target}
                              onChange={e => setHop(i, { label: e.target.value })}
                              helperText="The hop's identity — delivery attempts are recorded against it (empty = the target type)."
                            />
                            <IconButton size="small" aria-label={`Move hop ${i + 1} up`}
                                        disabled={i === 0} onClick={() => moveHop(i, -1)}>
                              <MoveUpIcon fontSize="small" />
                            </IconButton>
                            <IconButton size="small" aria-label={`Move hop ${i + 1} down`}
                                        disabled={i === formDeliveryChain.hops.length - 1}
                                        onClick={() => moveHop(i, 1)}>
                              <MoveDownIcon fontSize="small" />
                            </IconButton>
                            <IconButton size="small" aria-label={`Remove hop ${i + 1}`}
                                        onClick={() => removeHop(i)}>
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </Stack>
                          {_renameWarning && (
                            <Alert severity="warning" sx={{ mb: 1 }}>{_renameWarning}</Alert>
                          )}
                          {hop.target === 'local' && (
                            <TextField
                              label={`Hop ${i + 1} output directory`} size="small" fullWidth
                              value={hop.path} placeholder={defaultOutputDir || 'data/feeds'}
                              onChange={e => setHop(i, { path: e.target.value })}
                              helperText="Empty = the platform default output directory."
                            />
                          )}
                          {hop.target === 's3' && (
                            <Stack direction="row" spacing={1}>
                              <TextField label={`Hop ${i + 1} S3 bucket`} size="small"
                                         sx={{ flex: 1 }} value={hop.bucket}
                                         onChange={e => setHop(i, { bucket: e.target.value })} />
                              <TextField label={`Hop ${i + 1} S3 prefix`} size="small"
                                         sx={{ flex: 1 }} value={hop.prefix}
                                         onChange={e => setHop(i, { prefix: e.target.value })} />
                            </Stack>
                          )}
                          {hop.target === 'sftp' && (
                            <SftpDestinationFields
                              labelPrefix={`Hop ${i + 1} `}
                              feedId={editFeed?.id ?? null}
                              hopLabel={hop.storedLabel}
                              value={{
                                ...(hop.extraTarget === 'sftp' ? hop.extra : {}),
                                host: hop.host, port: hop.port, username: hop.username,
                                password: hop.password, remote_dir: hop.remoteDir,
                              }}
                              onChange={next => {
                                const { host, port, username, password, remote_dir, ...rest } = next;
                                setHop(i, {
                                  host: String(host ?? ''), port: String(port ?? '22'),
                                  username: String(username ?? ''), password: String(password ?? ''),
                                  remoteDir: String(remote_dir ?? '/'),
                                  extra: rest, extraTarget: 'sftp',
                                });
                              }}
                            />
                          )}
                          {hop.target === 'oracle' && (
                            <Stack direction="row" spacing={1}>
                              <FormControl size="small" sx={{ flex: 1 }}>
                                <InputLabel id={`hop-conn-${i}`}>{`Hop ${i + 1} connection`}</InputLabel>
                                <Select
                                  labelId={`hop-conn-${i}`} label={`Hop ${i + 1} connection`}
                                  value={hop.connectionId}
                                  onChange={e => setHop(i, { connectionId: String(e.target.value) })}
                                >
                                  {connections.map(c => (
                                    <MenuItem key={c.id} value={String(c.id)}>
                                      {c.name} ({c.connection_type})
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                              <TextField label={`Hop ${i + 1} table`} size="small"
                                         sx={{ flex: 1 }} value={hop.table}
                                         onChange={e => setHop(i, { table: e.target.value })} />
                            </Stack>
                          )}
                          <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                            <FormControl size="small" sx={{ flex: 2 }}>
                              <InputLabel id={`hop-requires-${i}`}>{`Hop ${i + 1} runs after`}</InputLabel>
                              <Select
                                labelId={`hop-requires-${i}`} label={`Hop ${i + 1} runs after`}
                                value={hop.requires}
                                onChange={e => setHop(i, { requires: String(e.target.value) })}
                              >
                                <MenuItem value={REQUIRES_AUTO}>
                                  <em>Automatic — after the chain's first local hop</em>
                                </MenuItem>
                                <MenuItem value={REQUIRES_INDEPENDENT}>
                                  <em>Independent — no prerequisite</em>
                                </MenuItem>
                                {_otherLabels.map(l => (
                                  <MenuItem key={l} value={l}>{l}</MenuItem>
                                ))}
                                {_staleRequires && (
                                  <MenuItem value={hop.requires} disabled>
                                    {hop.requires} (no longer in this chain)
                                  </MenuItem>
                                )}
                              </Select>
                              <FormHelperText>
                                The hop whose success this one consumes.
                              </FormHelperText>
                            </FormControl>
                            <TextField
                              label={`Hop ${i + 1} max attempts`} size="small" sx={{ flex: 1 }}
                              value={hop.maxAttempts}
                              onChange={e => setHop(i, { maxAttempts: e.target.value })}
                              helperText={hop.target === 'sftp' || hop.target === 'oracle'
                                ? 'Clamped to 1 — this send is never auto-retried (a duplicate counterparty send is a real incident).'
                                : 'Attempts per run (empty = 1). Repeat-safe: same bytes, same name.'}
                            />
                          </Stack>
                        </Box>
                      );
                    })}
                    <Button size="small" startIcon={<AddIcon />} onClick={addHop}
                            sx={{ alignSelf: 'flex-start' }}>
                      Add hop
                    </Button>
                    {_deliveryChainErrors.length > 0 && (
                      <Alert severity="error">
                        {_deliveryChainErrors.map((m, i) => <div key={i}>{m}</div>)}
                      </Alert>
                    )}
                  </Stack>
                )}

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Notifications</Typography>
                <Stack direction="row" spacing={2}>
                  <FormControlLabel
                    control={<Switch checked={formNotifySuccess}
                                     onChange={e => setFormNotifySuccess(e.target.checked)} size="small" />}
                    label="On Success"
                  />
                  <FormControlLabel
                    control={<Switch checked={formNotifyFailure}
                                     onChange={e => setFormNotifyFailure(e.target.checked)} size="small" />}
                    label="On Failure"
                  />
                </Stack>
                <TextField label="Notification Emails (comma-separated)" value={formNotifyEmails}
                           onChange={e => setFormNotifyEmails(e.target.value)}
                           fullWidth size="small" />
              </Stack>
            )}

            {/* Step 6: CONTROLS — everything the author does NOT supply as
                one of the six properties: entitlement, the execution lane
                override (normally derived), and opt-in production gates.
                Kept so no capability of the old editor is lost. */}
            {activeStep === 6 && (
              <Stack spacing={2}>
                <Typography variant="subtitle2">Entitlement</Typography>
                <FormControl fullWidth size="small">
                  <InputLabel id="owner-group-label">Owner Group (optional)</InputLabel>
                  <Select
                    labelId="owner-group-label"
                    label="Owner Group (optional)"
                    value={formOwnerGroupId === '' ? '' : String(formOwnerGroupId)}
                    onChange={(e) => {
                      const v = e.target.value;
                      setFormOwnerGroupId(v === '' ? '' : Number(v));
                    }}
                  >
                    <MenuItem value=""><em>No group — solo (only creator + admins)</em></MenuItem>
                    {userGroupsList.map((g) => (
                      <MenuItem key={g.id} value={String(g.id)}>
                        {g.name}{g.description ? ` — ${g.description}` : ''}
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    {isAdmin
                      ? 'Group members get view/edit access per their access level (read_only vs read_write).'
                      : 'Only an admin can list and assign entitlement groups; an existing assignment is kept.'}
                  </FormHelperText>
                </FormControl>

                {/* 2026-09-28 -- CONSUMER groups: who reads this feed's delivery
                    receipts on My Feeds and may subscribe to delivered / late /
                    failed.  A declaration, not a view grant: a consumer never
                    sees the feed's config, SQL or the Today board. */}
                <Autocomplete
                  multiple size="small"
                  options={userGroupsList.map(g => g.id)}
                  getOptionLabel={(id) => {
                    const g = userGroupsList.find(x => x.id === id);
                    return g ? g.name : `group ${id}`;
                  }}
                  value={formConsumerGroupIds}
                  onChange={(_e, v) => setFormConsumerGroupIds(v as number[])}
                  disabled={!isAdmin && userGroupsList.length === 0}
                  renderInput={(params) => (
                    <TextField {...params} label="Consumer groups (optional)"
                               helperText={isAdmin
                                 ? "Members of these entitlement groups get a read-only My Feeds page with this feed's delivery receipts (file, rows, checksum, certificate, delivered vs SLA, decisions) and can subscribe to delivered / late / failed. Never a view grant on the feed itself."
                                 : (formConsumerGroupIds.length
                                    ? `Declared consumer groups: ${formConsumerGroupIds.join(', ')} (only an admin can list groups by name; the declaration is kept as is).`
                                    : 'Only an admin can list and declare consumer groups.')} />
                  )}
                  renderTags={(value, getTagProps) => value.map((id, index) => {
                    const g = userGroupsList.find(x => x.id === id);
                    return <Chip {...getTagProps({ index })} key={id} size="small" label={g ? g.name : `group ${id}`} />;
                  })}
                />

                {/* 2026-09-03 — OPERATIONAL feed group (feed_group_id):
                    "the SAP feeds", run/administered as one unit on the
                    Feed Groups page.  Distinct from the entitlement
                    owner group above. */}
                <FormControl fullWidth size="small">
                  <InputLabel id="feed-group-label">Feed Group (operational, optional)</InputLabel>
                  <Select
                    labelId="feed-group-label"
                    label="Feed Group (operational, optional)"
                    value={formFeedGroupId === '' ? '' : String(formFeedGroupId)}
                    onChange={(e) => {
                      const v = e.target.value;
                      setFormFeedGroupId(v === '' ? '' : Number(v));
                    }}
                  >
                    <MenuItem value=""><em>Ungrouped</em></MenuItem>
                    {feedGroupsList.map((g) => (
                      <MenuItem key={g.id} value={String(g.id)}>
                        {g.display_label || g.name}
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText error={!!feedGroupsLoadError}>
                    {feedGroupsLoadError
                      ? `The feed-group list could not be loaded (groups may exist but cannot be shown): ${feedGroupsLoadError}`
                      : 'Operational grouping: group re-run, group dependency-skip and the service review aggregate by this. One group per feed.'}
                  </FormHelperText>
                </FormControl>

                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Execution lane</Typography>
                <Typography variant="caption" color="text.secondary">
                  Normally DERIVED from the feed's source and size — override only
                  when you know better than the router.
                </Typography>
                <ExecutionBackendSelect value={formBackend}
                                        onChange={setFormBackend} />
                {/* Help text per chosen backend — operators see when each is appropriate */}
                {formBackend === 'auto' && (
                  <TextField
                    label="Size threshold (rows) — empty = use global default"
                    value={formSizeThresholdRows}
                    onChange={e => setFormSizeThresholdRows(e.target.value.replace(/[^\d]/g, ''))}
                    fullWidth size="small"
                    placeholder="500000"
                    helperText="In auto mode, feeds exceeding this row count route to Airflow. Estimate uses the last successful run's actual row count."
                  />
                )}
                {formBackend === 'spark_connect' && (
                  <Alert severity="info">
                    Spark Connect routes the entire feed through the Spark cluster
                    via gRPC.  Best for big-volume daily extracts where partition
                    layout creates many small files DuckDB can't fan-out efficiently.
                    Requires <code>spark_connect.enabled=true</code> + reachable
                    server (verify via Admin → Spark Connect → Test).  Zero data
                    duplication — Spark reads source files directly.
                  </Alert>
                )}
                {formBackend === 'native' && (
                  <Alert severity="info" sx={{ '& .MuiAlert-message': { width: '100%' } }}>
                    Native = QueryStudio's DuckDB engine.  Fast for moderate
                    volumes (≤ low millions of rows).  Runs in the API pod so
                    output is immediate.
                  </Alert>
                )}
                {formBackend === 'airflow' && (
                  <Alert severity="info">
                    Airflow runs the feed as a DAG on a separate worker.  Good
                    for very large feeds, long-running transformations, or feeds
                    that need to integrate with other ETL jobs.  Requires Airflow
                    to be configured.
                  </Alert>
                )}
                {formBackend === 'spark_k8s' && (
                  <Alert severity="info">
                    QueryStudio submits the feed as its own Spark job on
                    Kubernetes (a SparkApplication per run) — no Airflow
                    involved.  Executors write straight to S3, each job owns
                    its memory, and QueryStudio supervises the whole
                    lifecycle: failed or hung jobs go terminal with a reason
                    instead of hanging &quot;running&quot;.  Best for very large
                    feeds.  Requires the Spark operator on the cluster
                    (<code>spark_k8s.enabled=true</code>).
                  </Alert>
                )}

                {/* Phase 131 — Production Controls (opt-in safety gates) */}
                <Divider sx={{ my: 1 }} />
                <Typography variant="subtitle2">Production Controls (Phase 131)</Typography>
                <Stack direction="row" spacing={1}>
                  <FormControl size="small" sx={{ minWidth: 180 }}>
                    <InputLabel id="rc-action-label">Row-count check</InputLabel>
                    <Select
                      labelId="rc-action-label"
                      label="Row-count check"
                      value={formRowCountAction}
                      onChange={(e) => setFormRowCountAction(e.target.value as 'off'|'warn'|'fail'|'hold')}
                    >
                      <MenuItem value="off">Off (no check)</MenuItem>
                      <MenuItem value="warn">Warn on breach</MenuItem>
                      <MenuItem value="fail">Fail on breach</MenuItem>
                      <MenuItem value="hold">Hold the file for verification</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ minWidth: 200 }} disabled={formRowCountAction === 'off'}>
                    <InputLabel id="rc-compare-label">Compared with</InputLabel>
                    <Select
                      labelId="rc-compare-label"
                      label="Compared with"
                      value={formRowCountCompareTo}
                      onChange={(e) => setFormRowCountCompareTo(e.target.value as 'baseline'|'previous')}
                      data-testid="rc-compare-to"
                    >
                      <MenuItem value="baseline">Rolling average</MenuItem>
                      <MenuItem value="previous">Previous business date (delivered)</MenuItem>
                    </Select>
                  </FormControl>
                  <TextField
                    label="Threshold % (deviation)"
                    type="number"
                    value={formRowCountThresholdPct}
                    onChange={(e) => setFormRowCountThresholdPct(e.target.value)}
                    size="small" sx={{ minWidth: 180 }}
                    disabled={formRowCountAction === 'off'}
                    helperText="Empty = system default (10%)"
                  />
                </Stack>
                {formRowCountAction === 'hold' && (
                  <Alert severity="info" data-testid="rc-hold-explained">
                    When the row count moves beyond the threshold, the file is produced and
                    KEPT but NOT delivered. It waits under MONITORING &rarr; Variance Holds until
                    a member of the release group releases it (the same file is then sent) or
                    rejects it (nothing is sent).
                  </Alert>
                )}
                <FormControl fullWidth size="small">
                  <InputLabel id="ic-label">File integrity check</InputLabel>
                  <Select
                    labelId="ic-label"
                    label="File integrity check"
                    value={formIntegrityCheck}
                    onChange={(e) => setFormIntegrityCheck(e.target.value as 'inherit'|'on'|'off')}
                  >
                    <MenuItem value="inherit">Inherit system default</MenuItem>
                    <MenuItem value="on">Always on for this feed</MenuItem>
                    <MenuItem value="off">Disabled for this feed</MenuItem>
                  </Select>
                  <FormHelperText>
                    Verifies parquet footer / CSV line count + post-delivery S3 size. Safe to keep on.
                  </FormHelperText>
                </FormControl>
              </Stack>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          {editFeed && activeStep === STEP_LABELS.length - 1 && (
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mr: 'auto', pl: 1 }}
                   data-testid="feed-apply-from">
              <TextField select size="small" label="Changes apply from" value={applyMode} sx={{ width: 230 }}
                         onChange={e => setApplyMode(e.target.value as 'next_run' | 'from_date')}
                         inputProps={{ 'data-testid': 'feed-apply-mode' }}
                         helperText={applyMode === 'next_run'
                           ? 'Delivered dates keep the definition they ran with'
                           : 'Every run of this date or later, re-runs included'}>
                <MenuItem value="next_run">The next run</MenuItem>
                <MenuItem value="from_date">A business date onward</MenuItem>
              </TextField>
              {applyMode === 'from_date' && (
                <TextField type="date" size="small" label="Business date" value={applyFromDate}
                           onChange={e => setApplyFromDate(e.target.value)} InputLabelProps={{ shrink: true }}
                           inputProps={{ 'data-testid': 'feed-apply-date', 'aria-label': 'Apply from business date' }}
                           error={!applyFromDate} />
              )}
            </Stack>
          )}
          <Button onClick={cancelDialog}>Cancel</Button>
          {activeStep > 0 && <Button onClick={() => setActiveStep(s => s - 1)}>Back</Button>}
          {activeStep < STEP_LABELS.length - 1 ? (
            <Button variant="contained" onClick={() => setActiveStep(s => s + 1)}
                    disabled={_stepBlocked(activeStep)}>
              Next
            </Button>
          ) : (
            <Button variant="contained" onClick={handleSave}
                    disabled={!_allStepsReady}
                    title={!_allStepsReady ? 'Required fields missing — review each step' : undefined}>
              {editFeed ? 'Update' : 'Create'}
            </Button>
          )}
        </DialogActions>
      </Dialog>

      {/* Phase 132.38 — Trigger-with-overrides dialog.  Appears only
          when the user clicks Run on a feed whose publisher declared at
          least one Dynamic WHERE row.  The dialog shows one input per
          Dynamic column so the dashboard caller can supply per-run
          values.  Static rows stay locked; the consumer cannot edit
          them here even if they wanted to.  Empty inputs are stripped
          so "Dynamic without value = no filter on that column" — same
          contract as PVs. */}
      <FeedRunNowDialog
        feed={runDialogFeed ? { id: runDialogFeed.id, name: runDialogFeed.name } : null}
        onClose={() => setRunDialogFeed(null)}
        onRun={confirmRunWithOverrides}
      >
        {runDialogFeed && _dynamicRowsForFeed(runDialogFeed).length > 0 && (
          <Stack spacing={2}>
            <Alert severity="info">
              This feed declares <strong>Dynamic</strong> WHERE rows.
              Supply values below or leave blank to skip the filter.
              Static rows are locked at publish time and not editable
              here.
            </Alert>
            {runDialogFeed && (() => {
              // Phase 133-H — table hint for the lazy distinct-values
              // lookup.  Pull FROM targets from the feed's primary +
              // secondary SQL.  Cross-source feeds have a secondary
              // connection: surface it as a fallback so a Dynamic row
              // whose column lives on the secondary side still gets a
              // dropdown.
              const _params = (runDialogFeed.query_params as any) || {};
              const _pickFrom = (s: string | undefined) => {
                if (!s) return null;
                const m = s.match(
                  /\bfrom\s+([\w".`\[\]]+(?:\s*\.\s*[\w".`\[\]]+){0,2})/i,
                );
                return m ? m[1].replace(/[\s"`\[\]]/g, '') : null;
              };
              const _primaryTable = _pickFrom(_params.raw_sql);
              const _secondaryTable = _pickFrom(_params.secondary_raw_sql);
              const _cid = runDialogFeed.connection_id ?? null;
              const _secCid = (runDialogFeed as any).secondary_connection_id ?? null;
              const _fallback: Array<{ connectionId: number; table: string }> = [];
              if (_secCid && _secondaryTable) {
                _fallback.push({ connectionId: _secCid, table: _secondaryTable });
              }
              return _dynamicRowsForFeed(runDialogFeed).map((row) => (
                <DynamicWhereOverrideField
                  key={row.column}
                  column={row.column}
                  operator={row.operator}
                  publisherDefault={row.value}
                  value={runOverrides[row.column] ?? ''}
                  onChange={(next) => setRunOverrides(prev => ({
                    ...prev, [row.column]: next,
                  }))}
                  connectionId={_cid}
                  table={_primaryTable}
                  fallbackTargets={_fallback}
                />
              ));
            })()}
          </Stack>
        )}
      </FeedRunNowDialog>

      {/* Run SOD Now — date picker dialog (admin only).  Lets admin
          backfill a missed day or seed a fresh feed_config mid-day. */}
      <Dialog open={sodDialogOpen} onClose={() => setSodDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Run SOD Generator</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ pt: 1 }}>
            <Typography variant="body2" color="text.secondary">
              Creates/updates <code>feed_runs</code> rows for the chosen business date.
              Idempotent — if rows already exist for (feed × business_date) they are
              not duplicated.  Per-feed calendars are respected (e.g. weekend-skip
              calendars roll the business_date back to the previous business day).
            </Typography>
            <TextField
              label="Business date"
              type="date"
              value={sodDate}
              onChange={(e) => setSodDate(e.target.value)}
              fullWidth size="small"
              InputLabelProps={{ shrink: true }}
              helperText="Defaults to today (UTC).  Pick an earlier date to backfill."
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSodDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={confirmRunSodNow}
                  disabled={!sodDate || adminBusy}
                  startIcon={<SodIcon />}>
            Run SOD for {sodDate || '…'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Preview SQL dialog — shows the resolved query the feed will run,
          plus source / connection metadata so users can verify before
          scheduling. */}
      <Dialog open={previewOpen} onClose={() => setPreviewOpen(false)}
              fullWidth maxWidth="md">
        <DialogTitle>
          <Stack direction="row" alignItems="center" spacing={1}>
            <PreviewSqlIcon fontSize="small" />
            <Box sx={{ flexGrow: 1 }}>Feed Query Preview</Box>
            {previewData?.sql && (
              <Tooltip title="Copy to clipboard">
                <IconButton size="small" onClick={copyPreviewSql}>
                  <CopyIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          {previewLoading && <CircularProgress size={20} />}
          {previewError && <Alert severity="error" sx={{ mb: 2 }}>{previewError}</Alert>}
          {previewData && !previewLoading && (
            <>
              <Stack direction="row" spacing={1} sx={{ mb: 1.5, flexWrap: 'wrap' }}>
                <Chip size="small" label={`Source: ${previewData.source_type} · ${previewData.source_name}`} />
                {previewData.connection_name && (
                  <Chip size="small" color="primary" variant="outlined"
                        label={`Connection: ${previewData.connection_name} (${previewData.connection_type})`} />
                )}
                <Chip size="small" variant="outlined" label={`Dialect: ${previewData.dialect}`} />
                {previewData.combine_mode && (
                  <Chip size="small" color="secondary"
                        label={`Cross-conn: ${previewData.combine_mode.toUpperCase()}`} />
                )}
              </Stack>
              {previewData.source_status !== 'ok' && (
                <Alert severity={previewData.source_status === 'not_found' || previewData.source_status === 'missing_file' || previewData.source_status === 'refused' ? 'error' : 'warning'}
                       sx={{ mb: 2 }}>
                  <strong>{previewData.source_status}:</strong> {previewData.source_message}
                </Alert>
              )}
              {previewData.sql ? (
                <Box component="pre"
                     sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                           borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 360,
                           fontFamily: 'JetBrains Mono, Menlo, monospace', whiteSpace: 'pre-wrap' }}>
                  {previewData.sql}
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                  No SQL available for this feed (see status above).
                </Typography>
              )}
              {previewData.secondary_sql && (
                <>
                  <Typography variant="caption" sx={{ display: 'block', mt: 2, mb: 0.5, color: 'text.secondary' }}>
                    Secondary side ({previewData.combine_mode}) — {previewData.secondary_connection_name || ''}
                  </Typography>
                  <Box component="pre"
                       sx={{ p: 1.5, bgcolor: 'grey.50', border: 1, borderColor: 'divider',
                             borderRadius: 1, fontSize: 12, overflow: 'auto', maxHeight: 240,
                             fontFamily: 'JetBrains Mono, Menlo, monospace', whiteSpace: 'pre-wrap' }}>
                    {previewData.secondary_sql}
                  </Box>
                </>
              )}
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* 2026-09-03 — operator dialogs */}
      <FeedBackfillDialog
        feed={backfillFeed}
        onClose={() => setBackfillFeed(null)}
        onLaunched={() => void loadFeeds()}
      />

      <FeedTemplateBulkDialog
        open={bulkTemplateOpen}
        onClose={() => setBulkTemplateOpen(false)}
        onApplied={() => void loadFeeds()}
      />
      <FeedDeliveryAttemptsDialog
        feed={deliveryFeed}
        onClose={() => setDeliveryFeed(null)}
      />
      <FeedLifecycleDialog
        feed={lifecycleFeed}
        onClose={() => setLifecycleFeed(null)}
        onChanged={() => void loadFeeds()}
      />
      <FeedStepPlanDialog
        feedId={stepPlanFeed?.id ?? null}
        feedName={stepPlanFeed?.name}
        onClose={() => setStepPlanFeed(null)}
      />
      <FeedVersionHistoryDialog
        feedId={versionsFeed?.id ?? null}
        feedName={versionsFeed?.name}
        open={versionsFeed != null}
        onClose={() => setVersionsFeed(null)}
        // a restore rewrote the feed: the open edit form is stale, so it
        // closes and the list reloads
        onRestored={() => { setDialogOpen(false); void loadFeeds(); }}
      />
    </Box>
  );
};

export default FeedConfigsPage;
