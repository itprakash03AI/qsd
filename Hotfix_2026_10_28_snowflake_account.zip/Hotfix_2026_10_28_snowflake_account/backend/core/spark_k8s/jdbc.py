"""THE Spark JDBC config grammar — single source (2026-08-22).

MOVED VERBATIM out of ``airflow/dags/querystudio_feed_factory.py`` (where it
had been module-level ``_build_jdbc_config`` since the 2026-08-22 P0 fix,
design_starburst_140m §1.3).  A fix copied into two modules is this repo's
dominant defect class, so the DAG no longer carries a copy: the DAG now
delegates spec building to the backend (``/spark-submit`` endpoint), and the
backend builds JDBC configs HERE — one grammar for the native spark_k8s
backend and the Airflow-delegated path alike.

History carried with the move: this used to be a nested helper whose if/elif
knew oracle/postgresql/mysql/snowflake and silently returned ``url=""`` for
everything else — including trino/starburst, whose PORT default it already
knew.  Every such SparkApplication died inside the detached Spark pod at
``generic_feed.py:_read_jdbc`` ("JDBC source requires jdbc_config.url") — a
message that names the symptom, not the cause.  An unrecognised spelling and
a deliberate refusal must never be indistinguishable (2026-08-21 island
lesson), so a connection type with no URL grammar here raises with the
supported list in the message, at spec-build time, before any pod is born.
"""
from __future__ import annotations

JDBC_SUPPORTED_TYPES = (
    "oracle", "postgresql", "mysql", "snowflake", "trino", "starburst",
)

#: FR-ARCH-02 (2026-09-03) — the JDBC driver classes whose jars the PINNED
#: Spark image bakes in (spark/Dockerfile, one line each: ojdbc11,
#: trino-jdbc, snowflake-jdbc, postgresql, mysql-connector-j).  This is a
#: DECLARATION of a deploy fact, kept beside the URL grammar that emits
#: these classes so the two lists cannot drift apart silently.  The submit
#: preflight checks the built config's driver against it — the system
#: already RECOGNISES a missing driver after the detached pod dies
#: (classifier.py marks ``classnotfoundexception`` NON_RETRYABLE); this
#: catches the same fact BEFORE any pod is born, where the message can
#: name the fix.
PINNED_IMAGE_DRIVER_CLASSES = frozenset({
    "oracle.jdbc.OracleDriver",
    "org.postgresql.Driver",
    "com.mysql.cj.jdbc.Driver",
    "net.snowflake.client.jdbc.SnowflakeDriver",
    "io.trino.jdbc.TrinoDriver",
})

#: Sentinel for a custom image whose jar list is unknown: declaring
#: ``image_driver_classes=("*",)`` skips the preflight EXPLICITLY —
#: a stated decision, never a silent default.
DRIVER_CLASSES_ANY = "*"


def iter_jdbc_driver_classes(feed_conf):
    """Yield ``(where, driver_class)`` for every jdbc_config the resolved
    ``--feed-config`` payload carries (primary, secondary, oracle dest).

    Walks the WHOLE payload rather than two known fields — the 2026-09-02
    session-token lesson: a check that inspects only one place reports
    "fine" for a run that is not, which is the wrong answer in the unsafe
    direction."""
    def _walk(obj, path):
        if isinstance(obj, dict):
            drv = obj.get("driver")
            if (isinstance(drv, str) and drv.strip()
                    and ("jdbc_config" in path
                         or str(obj.get("url") or "").startswith("jdbc:"))):
                yield (path or "feed_conf", drv.strip())
            for k, v in obj.items():
                yield from _walk(v, f"{path}.{k}" if path else str(k))
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                yield from _walk(v, f"{path}[{i}]")
    yield from _walk(feed_conf, "")


def assert_driver_on_classpath(feed_conf, image_driver_classes,
                               *, image: str = "") -> None:
    """FR-ARCH-02 — refuse AT SUBMIT a run whose JDBC driver class is not
    on the Spark image's declared classpath.

    Without this, the SparkApplication is created, the detached driver pod
    dies with ``ClassNotFoundException``, and the operator learns about a
    build-time fact from a runtime corpse (classifier.py:100 classifies
    exactly that marker NON_RETRYABLE — the system was built to recognise
    this failure AFTER the pod died).

    ``image_driver_classes`` is the deployment's declaration (default:
    the pinned image's five, ``PINNED_IMAGE_DRIVER_CLASSES``).  A custom
    image with an unknown jar list declares ``("*",)`` to skip — loudly
    opt-out, never silently vacuous.

    Raises ``ValueError`` naming the class, where it was needed, and the
    fix.  Returns None when every needed driver is declared present.
    """
    declared = {str(c).strip() for c in (image_driver_classes or ()) if str(c).strip()}
    if not declared or DRIVER_CLASSES_ANY in declared:
        return                      # declared unknown/any — preflight off
    for where, drv in iter_jdbc_driver_classes(feed_conf):
        if drv not in declared:
            raise ValueError(
                f"Spark feed backend: JDBC driver class {drv!r} (needed at "
                f"{where}) is NOT on the declared classpath of the Spark "
                f"image{f' {image!r}' if image else ''} — declared: "
                f"{sorted(declared)}.  Submitting would only create a "
                f"detached driver pod that dies with "
                f"ClassNotFoundException (a NON-RETRYABLE failure the "
                f"classifier already knows).  Fix: bake the driver jar "
                f"into the image (spark/Dockerfile) and redeploy, or "
                f"declare the custom image's classes via "
                f"SparkK8sSettings.image_driver_classes."
            )

# backend_config keys (bare or ``spark_``-prefixed) that pass through to
# ``generic_feed.py:_read_jdbc`` for the partitioned parallel read.
JDBC_TUNING_KEYS = (
    ("partition_column", ("spark_partition_column", "partition_column")),
    ("lower_bound",      ("spark_lower_bound", "lower_bound")),
    ("upper_bound",      ("spark_upper_bound", "upper_bound")),
    ("num_partitions",   ("spark_num_partitions", "num_partitions")),
    ("fetchsize",        ("spark_fetchsize", "fetchsize")),
    # 2026-09-20: opt-in per-stripe evidence in the driver log (a second pass
    # over the source; a proof run sets it, a production feed does not).
    ("partition_evidence", ("spark_partition_evidence", "partition_evidence")),
)


def connection_principal(conn_cfg) -> str:
    """The login principal a QueryStudio connection record carries.

    THE one place that knows a connection may spell it ``user`` (the
    Oracle / Trino / Starburst / Snowflake forms in
    ``ConnectionManager.tsx`` and their connectors, e.g.
    ``OracleConnector`` reads ``config["user"]``) or ``username`` (older
    records and every fixture in the test suite).  Until 2026-09-13 the
    ``or user`` fallback lived inline in ``build_jdbc_config`` only --
    the SOURCE side of a Spark feed logged in, while the Oracle
    DESTINATION branch in ``feed_conf.build_feed_conf`` and the native
    lane's ``_deliver_oracle`` read ``username`` alone, so a UI-authored
    Oracle connection used as a feed destination shipped an EMPTY
    principal and the write died with ORA-01017 -- in the detached pod
    for spark_k8s/airflow, in the worker for native.  Found by
    dry-building the conf for a real feed on a kind cluster: the same
    connection record yielded ``username='otg'`` for the read and
    ``username=''`` for the write.  Every test fixture spelled it
    ``username``, which is why 26k green tests never saw it.
    """
    cfg = conn_cfg or {}
    return str(cfg.get("username") or cfg.get("user") or "")


def _trino_roles_param(conn_cfg) -> str:
    """The Trino JDBC ``roles`` property for a connection's ``role`` (the
    SYSTEM role: Galaxy's ``accountadmin``) and ``catalog_roles``
    (catalog -> role), in the driver's grammar ``system:r;catalog:r``
    (``io.trino.client.uri.ConnectionProperties.Roles``) -- the same
    ``X-Trino-Role`` header the native road sends, so a feed on a Spark
    lane runs as the role the connection names.  Empty when none is set."""
    cfg = conn_cfg or {}
    pairs = []
    system = str(cfg.get("role") or "").strip()
    if system:
        pairs.append(f"system:{system}")
    for cat, role in dict(cfg.get("catalog_roles") or {}).items():
        cat_s, role_s = str(cat or "").strip(), str(role or "").strip()
        if cat_s and role_s:
            pairs.append(f"{cat_s}:{role_s}")
    return ";".join(pairs)


def build_jdbc_config(conn_cfg, conn_type, backend_config=None):
    """Translate a QueryStudio connection.config dict into the Spark JDBC
    config dict expected by ``generic_feed.py:_read_jdbc``.

    ``backend_config`` (optional, per-feed) carries the Spark read-tuning
    knobs — partition_column / lower_bound / upper_bound / num_partitions /
    fetchsize — which ``_read_jdbc`` already consumes.

    Raises ``ValueError`` for a connection type with no URL grammar here: a
    declared refusal with a reason, never ``url=""`` (which fails later, in
    the detached Spark pod, as a missing-config error that reads as
    infrastructure breakage).
    """
    if not conn_cfg:
        return {}
    ctype = (conn_type or "").lower()
    host = conn_cfg.get("host", "")
    http_scheme = str(conn_cfg.get("http_scheme") or "").lower()
    port = int(conn_cfg.get("port") or {
        "oracle": 1521, "postgresql": 5432, "mysql": 3306,
        "snowflake": 443,
        # QS Trino/Starburst connections default to https/443
        # (trino_connector.py); plain-http dev clusters run 8080.
        "trino": 8080 if http_scheme == "http" else 443,
        "starburst": 8080 if http_scheme == "http" else 443,
        "databricks": 443,
    }.get(ctype, 0) or 0)
    url = ""
    driver = ""
    if ctype == "oracle":
        url = f"jdbc:oracle:thin:@//{host}:{port}/{conn_cfg.get('service_name', '')}"
        driver = "oracle.jdbc.OracleDriver"
    elif ctype == "postgresql":
        url = f"jdbc:postgresql://{host}:{port}/{conn_cfg.get('database', '')}"
        driver = "org.postgresql.Driver"
    elif ctype == "mysql":
        url = f"jdbc:mysql://{host}:{port}/{conn_cfg.get('database', '')}"
        driver = "com.mysql.cj.jdbc.Driver"
    elif ctype == "snowflake":
        from core.feed.backend_router import snowflake_uses_key_pair
        if snowflake_uses_key_pair(conn_cfg):
            # 2026-10-03 -- the lane hands the job a user + PASSWORD; a
            # key-pair connection has none, so the pod could only fail to
            # log in.  Refused here, before anything is created; the router
            # floors such a feed to native, which logs in with the key.
            raise ValueError(
                "Spark feed backend: this Snowflake connection logs in with a "
                "KEY PAIR, and the Spark JDBC lane carries a user + password "
                "only. Run the feed on the native backend (the router does "
                "this unless the backend is pinned).")
        # ONE reading of the account field (a pasted URL, a PrivateLink host) with the
        # native connector: the lane used to ignore ``host`` and always dial
        # <account>.snowflakecomputing.com.
        from core.connectors.snowflake_connector import account_and_host
        account, sf_host = account_and_host(conn_cfg.get("account", ""), conn_cfg.get("host"))
        warehouse = conn_cfg.get("warehouse", "")
        database = conn_cfg.get("database", "")
        url = (f"jdbc:snowflake://{sf_host or account + '.snowflakecomputing.com'}/"
               f"?warehouse={warehouse}&db={database}")
        driver = "net.snowflake.client.jdbc.SnowflakeDriver"
    elif ctype in ("trino", "starburst"):
        # jdbc:trino://host:port[/catalog[/schema]][?SSL=true]
        # Starburst is protocol-compatible with the Trino driver.
        catalog = str(conn_cfg.get("catalog") or "").strip()
        schema = str(conn_cfg.get("schema") or "").strip()
        path = ""
        if catalog:
            path = f"/{catalog}"
            if schema:
                path += f"/{schema}"
        url = f"jdbc:trino://{host}:{port}{path}"
        params = []
        if http_scheme != "http":
            # QS connector default is https — the JDBC driver needs the
            # explicit SSL flag or it speaks plaintext to a TLS port.
            params.append("SSL=true")
            # 2026-10-08 -- the connection's verify_ssl reaches this lane
            # too: the native road honoured it, the JDBC driver verified
            # FULL regardless, so a self-signed dev cluster that browsed
            # fine failed inside the detached pod.  A pasted CA
            # (ca_cert_pem) travels in the config for the JOB to write as
            # the driver's PEM trust store (it has no file here).
            from core.ssl_config import resolve_ssl
            if not resolve_ssl(conn_cfg.get("verify_ssl", True)).enabled:
                params.append("SSLVerification=NONE")
        roles = _trino_roles_param(conn_cfg)
        if roles:
            params.append(f"roles={roles}")
        if params:
            url += "?" + "&".join(params)
        driver = "io.trino.jdbc.TrinoDriver"
    else:
        raise ValueError(
            f"Spark feed backend: no JDBC URL grammar for connection type "
            f"{conn_type!r} (supported: {', '.join(JDBC_SUPPORTED_TYPES)}). "
            f"Refusing to build a SparkApplication that would only fail "
            f"inside the detached Spark pod with a missing-URL error."
        )
    out = {
        "url": url,
        "username": connection_principal(conn_cfg),
        "password": conn_cfg.get("password", ""),
        "driver": driver,
        "host": host,
        "port": port,
        "service_name": conn_cfg.get("service_name", ""),
        "database": conn_cfg.get("database", ""),
    }
    if ctype in ("trino", "starburst") and str(conn_cfg.get("ca_cert_pem") or "").strip():
        out["ca_cert_pem"] = conn_cfg["ca_cert_pem"]
    bc = backend_config or {}
    for _dst, _srcs in JDBC_TUNING_KEYS:
        for _k in _srcs:
            if bc.get(_k) is not None:
                out[_dst] = bc[_k]
                break
    return out


#: The four knobs that must travel TOGETHER for a partitioned Spark JDBC
#: read.  Spark itself demands all of them once partitionColumn is set;
#: generic_feed.py degrades a partial set to a SINGLE-PARTITION read with
#: only a driver-side warning — which on a heavy feed is H2: 160M rows
#: down one connection, killed by the timeout, retried into the same wall.
PARTITION_BOUND_KEYS = ("partition_column", "lower_bound", "upper_bound",
                        "num_partitions")


def validate_jdbc_partition_bounds(jdbc_config, *, size_class=None,
                                   required_classes=()):
    """H2 (2026-09-02) — partition bounds validated AT SUBMIT, loudly.

    Two rules, both refusals rather than warnings:

    1. A PARTIAL set of the four knobs is always refused.  The Spark job
       silently degrades a partial set to a single-partition read, so the
       author who typed three of four believes the feed is partitioned
       and it is not — the worst failure direction.
    2. A feed whose ``spark_size_class`` is in ``required_classes``
       (declared: ``spark_k8s.require_partition_bounds_for_size_classes``)
       must carry ALL four.  That is the "heavy JDBC feed" contract: the
       size classes that exist to serve the 160M month-end are exactly
       the ones a single-partition read kills.

    When all four are present, their VALUES are validated: numeric bounds
    must satisfy lower < upper (equal or inverted bounds put every row in
    one stride — a single-partition read wearing a partitioned costume),
    and num_partitions must be an int >= 1.  Non-numeric bounds (dates,
    timestamps) are passed through — Spark validates those against the
    column type, and refusing strings here would refuse every date-bounded
    feed.

    Raises ``ValueError``; returns None when valid.
    """
    jc = jdbc_config or {}
    present = [k for k in PARTITION_BOUND_KEYS if jc.get(k) is not None]
    missing = [k for k in PARTITION_BOUND_KEYS if jc.get(k) is None]

    if present and missing:
        raise ValueError(
            f"Spark JDBC partition bounds are PARTIAL: {present} set but "
            f"{missing} missing.  generic_feed.py degrades a partial set "
            f"to a SINGLE-PARTITION read with only a log line — the feed "
            f"author believes the read is partitioned and it is not.  Set "
            f"all of backend_config.spark_partition_column / "
            f"spark_lower_bound / spark_upper_bound / spark_num_partitions, "
            f"or none of them.")

    if not present:
        if size_class and str(size_class) in set(map(str, required_classes)):
            raise ValueError(
                f"Feed declares spark_size_class={size_class!r} (a heavy "
                f"class) with a JDBC source but NO partition bounds.  With "
                f"bounds unset Spark performs a SINGLE-PARTITION read — the "
                f"160M month-end down one connection at fetchsize=10000, "
                f"killed by the job timeout and retried into the same wall "
                f"(H2).  Declare backend_config.spark_partition_column + "
                f"spark_lower_bound + spark_upper_bound + "
                f"spark_num_partitions for this feed.")
        return

    try:
        n = int(jc["num_partitions"])
    except (TypeError, ValueError):
        raise ValueError(
            f"backend_config.spark_num_partitions="
            f"{jc['num_partitions']!r} is not an integer.")
    if n < 1:
        raise ValueError(
            f"backend_config.spark_num_partitions={n} — must be >= 1.")

    lo, hi = jc["lower_bound"], jc["upper_bound"]
    try:
        lo_n, hi_n = float(lo), float(hi)
    except (TypeError, ValueError):
        return  # date/timestamp bounds — Spark validates those
    if lo_n >= hi_n:
        raise ValueError(
            f"Spark JDBC partition bounds lower_bound={lo!r} >= "
            f"upper_bound={hi!r} — every row lands in one stride, a "
            f"single-partition read wearing a partitioned costume (H2). "
            f"Fix the bounds so lower < upper.")
