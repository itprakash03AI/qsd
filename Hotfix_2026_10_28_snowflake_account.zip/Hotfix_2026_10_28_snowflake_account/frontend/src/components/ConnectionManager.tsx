import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, IconButton, Chip, Dialog, DialogTitle, DialogContent,
  DialogActions, TextField, MenuItem, Alert, CircularProgress, Tooltip, Stack,
  Divider, InputAdornment, FormHelperText, Collapse, FormControlLabel, Switch,
  Snackbar, Accordion, AccordionSummary, AccordionDetails,
  TablePagination,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  ContentCopy as CloneIcon,
  Delete as DeleteIcon,
  PlayArrow as TestIcon,
  Storage as StorageIcon,
  Folder as FolderIcon,
  CloudQueue as CloudIcon,
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
  Refresh as RefreshIcon,
  Terminal as SqlIcon,
  Visibility as VisibleIcon,
  VisibilityOff as HiddenIcon,
  Search as DiscoverIcon,
  TableChart as TableIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  People as SharedIcon,
  CloudUpload as UploadIcon,
  InsertDriveFile as FileIcon,
  Close as CloseIcon,
  Warning as WarningIcon,
  InfoOutlined as InfoIcon,
  AttachFile as AttachIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { PORTAL_ACCOUNT_TYPES } from '../utils/portalAccounts';
import { safeFetch } from '../services/api/core';
import { safeStringify } from '../utils/safeStringify';
import { useAuth } from '../context/AuthContext';
import { isAdminLike } from '../utils/reportLifecycle';
import { clickable } from '../utils/clickable';

// 2026-09-24 -- was the signed-in user ALLOWED to list system accounts?
// GET /api/admin/system-accounts is ``require_admin``; /connections is
// admin+analyst, and the real-browser walk saw analysts ask on load and get
// a 403.  Only an admin asks now, which leaves the pickers below with a
// list that is UNKNOWN for everyone else -- not empty.  "No accounts found"
// would be a lie for them, so the pickers read this to say the true thing.
// A context rather than a prop threaded through six connector forms.
const SystemAccountsListable = React.createContext<boolean>(true);

// ── Connection type metadata ──────────────────────────────────────────────────
const CONN_TYPE_META: Record<string, { label: string; icon: React.ReactElement; color: string }> = {
  s3:         { label: 'AWS S3 Bucket',   icon: <CloudIcon fontSize="small" />,  color: '#f59e0b' },
  local:      { label: 'Local Folder',    icon: <FolderIcon fontSize="small" />, color: '#6366f1' },
  upload:     { label: 'Upload Files',    icon: <UploadIcon fontSize="small" />, color: '#10b981' },
  trino:      { label: 'Trino',           icon: <SqlIcon fontSize="small" />,    color: '#3b82f6' },
  starburst:  { label: 'Starburst',       icon: <SqlIcon fontSize="small" />,    color: '#f97316' },
  snowflake:  { label: 'Snowflake',       icon: <SqlIcon fontSize="small" />,    color: '#22d3ee' },
  databricks: { label: 'Databricks SQL',  icon: <SqlIcon fontSize="small" />,    color: '#ef4444' },
  oracle:     { label: 'Oracle Database', icon: <SqlIcon fontSize="small" />,    color: '#c2410c' },
  athena:     { label: 'AWS Athena',      icon: <CloudIcon fontSize="small" />,  color: '#8b5cf6' },
  rest_api:   { label: 'REST API',        icon: <CloudIcon fontSize="small" />,  color: '#8b5cf6' },
};

const SQL_TYPES = ['trino', 'starburst', 'snowflake', 'databricks', 'oracle', 'athena'];
// The connection types whose source is ONE S3 bucket -- the server refuses a
// second connection to a bucket (core/connection_duplicates.py S3_TYPES).
const S3_BUCKET_TYPES = ['s3', 's3_minio', 's3_compatible'];
const REST_API_TYPES = ['rest_api'];

// Bucket name and ARN validation regexes (Phase 78P)
const S3_BUCKET_AWS_RE    = /^[a-z0-9]([a-z0-9\-]{1,61}[a-z0-9])?$/;
const S3_BUCKET_ONPREM_RE = /^[a-zA-Z0-9][a-zA-Z0-9\-_\.]{0,253}[a-zA-Z0-9]$/;
const IAM_ARN_RE          = /^arn:(aws|aws-cn|aws-us-gov):iam::\d{12}:role\/[\w+=,.@\-\/]{1,256}$/;

/** The SQL dialects QueryStudio's engine translates FROM (backend
 *  core/sql_dialect_translator.SUPPORTED_DIALECTS); '' = detect from the text. */
export const SQL_DIALECT_CHOICES: { value: string; label: string }[] = [
  { value: '', label: 'Detect from the query (a guess)' },
  { value: 'trino', label: 'Trino / Starburst' },
  { value: 'spark', label: 'Spark SQL / Databricks' },
  { value: 'hive', label: 'Hive' },
  { value: 'snowflake', label: 'Snowflake' },
  { value: 'oracle', label: 'Oracle' },
  { value: 'postgres', label: 'PostgreSQL' },
  { value: 'mysql', label: 'MySQL' },
  { value: 'tsql', label: 'SQL Server (T-SQL)' },
  { value: 'bigquery', label: 'BigQuery' },
  { value: 'redshift', label: 'Redshift' },
];

const EMPTY_CONFIGS = {
  s3:         { bucket_name: '', sql_dialect: '', region_name: '', auth_mode: 'keys', aws_access_key_id: '', aws_secret_access_key: '', aws_session_token: '', aws_profile: '', role_arn: '', role_session_name: 'parquet-engine', external_id: '', endpoint_url: '', path_style: false, addressing_style: undefined as string | undefined, ssl_verify: true, iceberg_warehouse_path: '', root_prefix: '', registered_tables: [] as any[] },
  local:      { base_path: '' },
  upload:     { base_path: '' },
  trino:      { host: '', port: 443, user: '', auth_type: 'basic', password: '', token: '', catalog: '', schema: '', http_scheme: 'https', verify_ssl: true },
  starburst:  { host: '', port: 443, user: '', auth_type: 'basic', password: '', token: '', catalog: '', schema: '', http_scheme: 'https', verify_ssl: true },
  snowflake:  { account: '', user: '', auth_type: 'password', password: '', private_key: '', private_key_passphrase: '', token: '', warehouse: '', database: '', schema: '', role: '' },
  databricks: { server_hostname: '', http_path: '', access_token: '', catalog: '', schema: '' },
  oracle:     { host: '', port: 1521, service_name: '', sid: '', dsn: '', user: '', password: '', wallet_location: '', wallet_password: '' },
  athena:     { region: 'us-east-1', s3_staging_dir: '', workgroup: 'primary', catalog: 'AwsDataCatalog', schema: 'default', auth_type: 'iam_role', aws_access_key_id: '', aws_secret_access_key: '', aws_session_token: '', aws_profile: '', bytes_scanned_cutoff_mb: '' },
  rest_api:   { base_url: '', auth_type: 'bearer', token: '', username: '', password: '', api_key_name: '', api_key_value: '', api_key_location: 'header', client_id: '', client_secret: '', token_url: '', default_headers: '{}', timeout_seconds: 30, verify_ssl: true, rate_limit_rps: 10 },
};

const AWS_REGIONS = [
  { value: 'us-east-1',      label: 'US East (N. Virginia)' },
  { value: 'us-east-2',      label: 'US East (Ohio)' },
  { value: 'us-west-1',      label: 'US West (N. California)' },
  { value: 'us-west-2',      label: 'US West (Oregon)' },
  { value: 'eu-west-1',      label: 'EU (Ireland)' },
  { value: 'eu-central-1',   label: 'EU (Frankfurt)' },
  { value: 'ap-south-1',     label: 'Asia Pacific (Mumbai)' },
  { value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' },
  { value: 'ap-northeast-1', label: 'Asia Pacific (Tokyo)' },
];

// ── Password field with show/hide toggle ─────────────────────────────────────
/** What the API sends in place of a stored secret (mask_config).  Sending it
 *  BACK means "keep the stored one" -- update_connection swaps it. */
const MASKED_SECRET = '***';

/** 2026-10-02 -- "why is the password getting blanked?".  It was not: the
 *  stored secret survived every Edit / Test / Save (proven by
 *  e2e/docker-connection-password-save.spec.ts).  What the user SAW was the
 *  mask itself -- three dots, and "***" behind the eye -- which reads as a
 *  wiped password, and typing into it appended to "***".  A saved secret now
 *  shows as an EMPTY field that says it is saved; empty keeps it (the mask
 *  is sent back), typing replaces it. */
const PasswordField = ({ label, value, onChange, required = false, placeholder = '', helperText = '' }: {
  label: string; value: string; onChange: (v: string) => void;
  required?: boolean; placeholder?: string; helperText?: string;
}) => {
  const [show, setShow] = useState(false);
  const hadSaved = React.useRef(false);
  if (value === MASKED_SECRET) hadSaved.current = true;
  const saved = value === MASKED_SECRET;
  return (
    <TextField
      label={label}
      fullWidth
      size="small"
      type={show ? 'text' : 'password'}
      value={saved ? '' : value}
      onChange={e => {
        const v = e.target.value;
        // Clearing what you typed returns to "keep the saved one", never to
        // an empty secret that would overwrite it.
        onChange(v === '' && hadSaved.current ? MASKED_SECRET : v);
      }}
      required={required && !saved}
      placeholder={saved ? '•••••••• saved — type to replace' : placeholder}
      InputLabelProps={saved ? { shrink: true } : undefined}
      helperText={saved ? (helperText || 'A value is saved (not shown).') : helperText}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <IconButton aria-label={show ? 'Hide password' : 'Show password'} size="small" onClick={() => setShow(v => !v)} edge="end">
              {show ? <HiddenIcon sx={{ fontSize: 18 }} /> : <VisibleIcon sx={{ fontSize: 18 }} />}
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};

// ── Section header ─────────────────────────────────────────────────────────────
const SectionLabel = ({ children }) => (
  <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', textTransform: 'uppercase', letterSpacing: 0.5, mt: 0.5 }}>
    {children}
  </Typography>
);

// ── System Account Selector (Phase 87) ────────────────────────────────────────
const SystemAccountSelector = ({ value, accountType, onChange }: {
  value: number | undefined; accountType: string; onChange: (id: number) => void;
}) => {
  const [accounts, setAccounts] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    setLoading(true);
    api.get(`/api/admin/system-accounts?account_type=${accountType}`)
      .then((res: any) => setAccounts(res.accounts || []))
      .catch(() => setAccounts([]))
      .finally(() => setLoading(false));
  }, [accountType]);

  if (loading) return <CircularProgress size={20} />;
  if (accounts.length === 0) {
    return (
      <Alert severity="warning" sx={{ fontSize: 12 }}>
        No system accounts configured for type "{accountType}". Ask an admin to create one
        under Admin &rarr; System Accounts.
      </Alert>
    );
  }

  return (
    <TextField
      select label="System Account" fullWidth size="small"
      value={value || ''}
      onChange={e => onChange(Number(e.target.value))}
      helperText="Select the system/service account to use for credential fetching"
    >
      {accounts.map((a: any) => (
        <MenuItem key={a.id} value={a.id}>
          {a.name} ({a.username}) {a.last_status === 'failed' ? ' — FAILED' : ''}
        </MenuItem>
      ))}
    </TextField>
  );
};

// ── S3 Config Form ─────────────────────────────────────────────────────────────
const S3_AUTH_MODES = [
  { value: 'portal',      label: 'Auto (Portal SSO)',              desc: 'Automatically fetch temporary AWS credentials from the corporate portal using your AD login or a system account.' },
  { value: 'iam_role',    label: 'IAM Role / Instance Profile',  desc: 'Server uses its attached IAM role or environment credential chain (EC2, ECS, EKS, env vars). No keys needed.' },
  { value: 'profile',     label: 'AWS SSO / Named Profile',       desc: 'Use a named profile from ~/.aws/config, including SSO profiles created via "aws configure sso".' },
  { value: 'assume_role', label: 'Assume Role (STS)',             desc: 'Assume a specific IAM role via STS. Useful for cross-account access. Optionally start from a named profile.' },
  { value: 'keys',        label: 'Access Key + Secret',           desc: 'Long-term static credentials. Not recommended for production — use IAM Role or SSO where possible.' },
];

/** Parse common S3 URL formats to extract bucket name and region. */
const parseS3Url = (url: string): { bucket?: string; region?: string } => {
  if (!url) return {};
  try {
    // s3://bucket-name/optional-key
    const s3Uri = url.match(/^s3:\/\/([^/]+)/i);
    if (s3Uri) return { bucket: s3Uri[1] };

    // AWS Console: /s3/buckets/bucket-name?region=us-east-1
    // 2026-10-26 -- the console URL's ?region= is the region the CONSOLE
    // was opened in (its last-used region, kept across the global S3
    // page), not the bucket's.  It used to be pasted into the Region field
    // unseen, and the owner then asked why a connection "never configured"
    // for eu-central-1 was warned about it.  Only a hostname that NAMES the
    // bucket's region (the virtual-hosted / path-style forms below) fills
    // the field; otherwise it stays on Auto-detect.
    const console2 = url.match(/\/s3\/buckets\/([^/?#]+)/i);
    if (console2) return { bucket: console2[1] };

    // Virtual-hosted: https://bucket.s3.region.amazonaws.com
    const vh1 = url.match(/^https?:\/\/([^.]+)\.s3\.([a-z0-9-]+)\.amazonaws\.com/i);
    if (vh1) return { bucket: vh1[1], region: vh1[2] };

    // Virtual-hosted: https://bucket.s3.amazonaws.com
    const vh2 = url.match(/^https?:\/\/([^.]+)\.s3\.amazonaws\.com/i);
    if (vh2) return { bucket: vh2[1] };

    // Path-style: https://s3.region.amazonaws.com/bucket
    const path1 = url.match(/^https?:\/\/s3\.([a-z0-9-]+)\.amazonaws\.com\/([^/?#]+)/i);
    if (path1) return { bucket: path1[2], region: path1[1] };

    // Path-style: https://s3.amazonaws.com/bucket
    const path2 = url.match(/^https?:\/\/s3\.amazonaws\.com\/([^/?#]+)/i);
    if (path2) return { bucket: path2[1] };
  } catch { /**/ }
  return {};
};

const S3Form = ({ config, onChange, isShared = false, systemAccounts = [] as Array<{ id: number; name: string; account_type: string; is_active: boolean; use_vault?: boolean }> }) => {
  const mode = config.auth_mode || 'keys';
  const [urlInput, setUrlInput] = React.useState('');
  const accountsListable = React.useContext(SystemAccountsListable);
  const portalAccounts = systemAccounts.filter(a => PORTAL_ACCOUNT_TYPES.includes(a.account_type));

  const handleUrlPaste = (url: string) => {
    setUrlInput(url);
    const { bucket, region } = parseS3Url(url);
    if (bucket) onChange('bucket_name', bucket);
    if (region) onChange('region_name', region);
  };

  return (
    <Stack spacing={2}>
      <SectionLabel>Quick Setup — Paste S3 URL</SectionLabel>
      <TextField
        label="Paste AWS Console or S3 URL (optional)"
        fullWidth size="small"
        value={urlInput}
        onChange={e => handleUrlPaste(e.target.value)}
        placeholder="https://s3.console.aws.amazon.com/s3/buckets/my-bucket"
        helperText="Paste any S3 URL to fill in the bucket name (and the region, when the URL's host name says it)"
        InputProps={{ startAdornment: <InputAdornment position="start">🔗</InputAdornment> }}
      />

      <SectionLabel>Bucket Configuration</SectionLabel>
      <TextField
        label="Bucket Name" fullWidth required size="small"
        value={config.bucket_name || ''}
        onChange={e => onChange('bucket_name', e.target.value)}
        placeholder="my-parquet-bucket"
      />
      {/* 2026-08-21 — the default used to be 'us-east-1', SAVED on every new
          connection, and the display fell back to it even when nothing was
          stored.  So a VPCE bucket in eu-west-1 arrived pre-stamped us-east-1
          that nobody had chosen, DuckDB httpfs signed every object GET with it,
          and AWS answered AuthorizationHeaderMalformed on all of them.  The
          operator's words were "the region 'us-east-1' ... never defined" —
          they had not defined it, this field had.  Blank now means blank, and
          the backend resolves it from the endpoint hostname. */}
      <TextField
        select label="AWS Region" fullWidth size="small"
        value={config.region_name || ''}
        onChange={e => onChange('region_name', e.target.value)}
        helperText="Leave on Auto-detect unless the bucket's region differs from the endpoint."
      >
        <MenuItem value=""><em>Auto-detect (from endpoint / bucket)</em></MenuItem>
        {AWS_REGIONS.map(r => <MenuItem key={r.value} value={r.value}>{r.label}</MenuItem>)}
      </TextField>

      <TextField
        label="Root Prefix (optional)" fullWidth size="small"
        value={config.root_prefix || ''}
        onChange={e => onChange('root_prefix', e.target.value)}
        placeholder="data/production/"
        helperText="Scope file browsing to this S3 prefix only. Leave blank to browse the entire bucket."
      />

      {/* 2026-10-14 -- the dialect of the SQL people write against this
          connection (shared queries, feeds, dataset SQL).  QueryStudio's own
          engine translates FROM it; "Detect" guesses from the text, and a
          guess can be wrong (core/sql_dialect_translator.source_dialect_for). */}
      <TextField
        select label="SQL written for this connection" fullWidth size="small"
        value={config.sql_dialect || ''}
        onChange={e => onChange('sql_dialect', e.target.value)}
        inputProps={{ 'data-testid': 's3-sql-dialect' }}
        helperText="The dialect your queries use here. Choose it so nothing is guessed."
      >
        {SQL_DIALECT_CHOICES.map(d => <MenuItem key={d.value} value={d.value}>{d.label}</MenuItem>)}
      </TextField>

      <SectionLabel>Authentication Method</SectionLabel>
      <TextField
        select label="Auth Mode" fullWidth size="small"
        value={mode}
        onChange={e => onChange('auth_mode', e.target.value)}
      >
        {S3_AUTH_MODES.map(m => (
          <MenuItem key={m.value} value={m.value}>
            <Box>
              <Typography variant="body2">{m.label}</Typography>
              <Typography variant="caption" color="text.secondary">{m.desc}</Typography>
            </Box>
          </MenuItem>
        ))}
      </TextField>

      {/* Portal SSO: auto-fetch from corporate AWS portal (3-step: JWT → role lookup → STS creds) */}
      {mode === 'portal' && (
        <>
          {/* BF-415 — credential_source dropdown.  Three modes:
              - personal : logged-in user's AD vault only (prompt-driven)
              - system_account : linked system account only (no prompts)
              - hybrid : try personal vault → system account → prompt user
                if both fail.  Designed for connections that should work BOTH
                interactively AND for scheduled / published API jobs.
              For backwards compatibility, leaving the field blank/undefined
              maps to legacy behaviour: is_shared=true → system_account,
              is_shared=false → personal. */}
          <TextField
            select
            label="Credential source"
            fullWidth
            size="small"
            value={config.credential_source || (isShared ? 'system_account' : 'personal')}
            onChange={e => onChange('credential_source', e.target.value)}
            helperText="How AWS credentials are resolved for this connection."
          >
            <MenuItem value="personal">
              <Box>
                <Typography variant="body2">Personal — prompt user</Typography>
                <Typography variant="caption" color="text.secondary">
                  Logged-in user enters their AD password once per session.
                </Typography>
              </Box>
            </MenuItem>
            <MenuItem value="system_account">
              <Box>
                <Typography variant="body2">Shared — system account only</Typography>
                <Typography variant="caption" color="text.secondary">
                  Uses an admin-configured System Account.  No user prompts.
                </Typography>
              </Box>
            </MenuItem>
            <MenuItem value="hybrid">
              <Box>
                <Typography variant="body2">Hybrid — try both</Typography>
                <Typography variant="caption" color="text.secondary">
                  Tries personal vault → system account → prompts user if both fail.
                </Typography>
              </Box>
            </MenuItem>
          </TextField>

          {(config.credential_source === 'system_account' ||
            config.credential_source === 'hybrid' ||
            (!config.credential_source && isShared)) && (
            <>
              <Alert severity="info" sx={{ fontSize: 12 }}>
                {config.credential_source === 'hybrid' ? (
                  <><strong>Hybrid</strong> — link a System Account as fallback.
                  If a user is running the query, their personal AD password is
                  tried first; if that fails (or no user is logged in, e.g.
                  scheduled job) the system account is used.  If BOTH fail
                  interactively, the user is prompted for their password.</>
                ) : (
                  <><strong>Shared connection</strong> — link to a System Account
                  whose AD service account is used to fetch AWS credentials.
                  All users sharing this connection benefit; no per-user
                  password prompts.</>
                )}
              </Alert>
              <TextField
                select label="System Account (AWS Portal)" fullWidth size="small"
                value={config.system_account_id ?? ''}
                onChange={e => onChange('system_account_id',
                  e.target.value === '' ? null : Number(e.target.value))}
                helperText={
                  !accountsListable
                    ? 'Only an admin can list system accounts; ask an admin to attach one.'
                    : portalAccounts.length === 0
                      ? 'No AWS Portal or AD system accounts found. Create one in Admin → System Accounts.'
                      : 'Used to fetch AWS credentials on behalf of all users.'
                }
              >
                <MenuItem value=""><em>— select a system account —</em></MenuItem>
                {portalAccounts.map(a => (
                    <MenuItem key={a.id} value={a.id} disabled={!a.is_active}>
                      {a.name} — {a.account_type === 'ad_account' ? 'AD account' : 'AWS Portal'}
                      {a.use_vault ? ', from Vault' : ''}{!a.is_active && ' (inactive)'}
                    </MenuItem>
                  ))}
              </TextField>
            </>
          )}

          {(config.credential_source === 'personal' ||
            (!config.credential_source && !isShared)) && (
            <Alert severity="info" sx={{ fontSize: 12 }}>
              <strong>Private connection</strong> — uses your own AD password
              to fetch AWS credentials.  You'll be prompted to enter it
              once per session; the password is held encrypted in memory
              only and is cleared on logout.
            </Alert>
          )}
          <Alert severity="info" sx={{ fontSize: 12 }}>
            Uses admin-configured AWS Portal settings (Admin → AWS Portal Config).
            Each user authenticates with their AD credentials — temporary AWS credentials
            are fetched automatically and refresh on expiry. No connection-level portal
            fields are required unless you need to override the global settings.
          </Alert>
          <Accordion variant="outlined" sx={{ mt: 1 }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="caption" color="text.secondary">
                Override global portal settings (optional)
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              <TextField
                label="Portal Base URL" fullWidth size="small"
                value={config.portal_base_url || ''}
                onChange={e => onChange('portal_base_url', e.target.value)}
                placeholder="Inherited from admin config"
                helperText="Override global portal URL"
              />
              <TextField
                label="AWS Account ID" fullWidth size="small"
                value={config.portal_account_id || ''}
                onChange={e => onChange('portal_account_id', e.target.value)}
                placeholder="Inherited from admin config"
                helperText="Override global account ID"
              />
              <TextField
                label="IAM Role Name *" fullWidth size="small"
                required
                value={config.role_name || ''}
                onChange={e => onChange('role_name', e.target.value)}
                error={mode === 'portal' && !(config.role_name && config.role_name.trim())}
                placeholder="e.g. app-ReadOnlyRole (required for portal mode)"
                helperText={
                  mode === 'portal' && !(config.role_name && config.role_name.trim())
                    ? "Required. Enter the exact IAM role name the portal should resolve to a role_arn (matches the role search filter in the corporate portal)."
                    : "The IAM role to assume for THIS connection. Required when you have multiple roles in the same AWS account so the portal returns the right role_arn (not the first match)."
                }
              />
              <TextField
                label="Service-First Reference Number" fullWidth size="small"
                value={config.sf_ref_no || ''}
                onChange={e => onChange('sf_ref_no', e.target.value)}
                placeholder="Inherited from admin config (only if portal requires it)"
                helperText="Some corporate portals require a service_first_number in the credentials request body. Leave empty unless your portal docs say otherwise."
              />
              <TextField
                label="Proxy URL" fullWidth size="small"
                value={config.proxy_url || ''}
                onChange={e => onChange('proxy_url', e.target.value)}
                placeholder="Inherited from admin config"
                helperText="Override global proxy URL"
              />
              <TextField
                label="Portal Username (System Account)" fullWidth size="small"
                value={config.portal_username || ''}
                onChange={e => onChange('portal_username', e.target.value)}
                placeholder="e.g. svc_querystudio"
                helperText="AD system account for this connection — used by published API and scheduled jobs. Overrides global service account."
              />
              <TextField
                label="Portal Password" fullWidth size="small"
                type="password"
                value={config.portal_password || ''}
                onChange={e => onChange('portal_password', e.target.value)}
                placeholder={config.portal_password === '***' ? '(saved — leave blank to keep)' : ''}
                helperText="Leave blank to use the global service account (Admin → AWS Portal Config)."
              />
            </AccordionDetails>
          </Accordion>
        </>
      )}

      {/* IAM Role: nothing extra needed */}
      {mode === 'iam_role' && (
        <Alert severity="info" sx={{ fontSize: 12 }}>
          The server will use its IAM instance profile, ECS/EKS task role, or
          <code> AWS_ACCESS_KEY_ID</code> / <code>AWS_SECRET_ACCESS_KEY</code> environment variables automatically.
          No credentials need to be stored here.
        </Alert>
      )}

      {/* SSO / Named Profile */}
      {(mode === 'profile' || mode === 'assume_role') && (
        <TextField
          label={mode === 'assume_role' ? 'Source AWS Profile (optional)' : 'AWS Profile Name'}
          fullWidth size="small"
          value={config.aws_profile || ''}
          onChange={e => onChange('aws_profile', e.target.value)}
          placeholder="default"
          helperText={mode === 'profile'
            ? 'Profile name from ~/.aws/config. Run "aws sso login --profile <name>" before connecting.'
            : 'Leave blank to use the default credential chain as the source identity.'}
        />
      )}

      {/* AssumeRole fields */}
      {mode === 'assume_role' && (
        <>
          <TextField
            label="Role ARN" fullWidth required size="small"
            value={config.role_arn || ''}
            onChange={e => onChange('role_arn', e.target.value)}
            placeholder="arn:aws:iam::123456789012:role/MyRole"
            helperText="Format: arn:aws:iam::123456789012:role/MyRole"
          />
          <TextField
            label="External ID (optional)" fullWidth size="small"
            value={config.external_id || ''}
            onChange={e => onChange('external_id', e.target.value)}
            placeholder="supplied by the role owner for cross-account access"
          />
          <TextField
            label="Session Name" fullWidth size="small"
            value={config.role_session_name || 'parquet-engine'}
            onChange={e => onChange('role_session_name', e.target.value)}
          />
        </>
      )}

      {/* Static Keys */}
      {mode === 'keys' && (
        <>
          <PasswordField
            label="AWS Secret Access Key"
            value={config.aws_secret_access_key || ''}
            onChange={v => onChange('aws_secret_access_key', v)}
          />
          <TextField
            label="AWS Access Key ID" fullWidth size="small"
            value={config.aws_access_key_id || ''}
            onChange={e => onChange('aws_access_key_id', e.target.value)}
            placeholder="Your access key ID"
          />
          <PasswordField
            label="Session Token (optional)"
            value={config.aws_session_token || ''}
            onChange={v => onChange('aws_session_token', v)}
            placeholder="FQoGZXIvYXdzEBcaD..."
            helperText="Only needed for temporary credentials (AWS SSO, sts get-session-token, assumed role). Leave blank for long-term access keys."
          />
        </>
      )}

      <SectionLabel>Advanced</SectionLabel>
      <TextField
        select label="SSL Certificate Verification" fullWidth size="small"
        value={config.ssl_verify === false ? 'false' : (typeof config.ssl_verify === 'string' && config.ssl_verify !== 'true') ? 'ca_bundle' : 'true'}
        onChange={e => {
          if (e.target.value === 'false') onChange('ssl_verify', false);
          else if (e.target.value === 'ca_bundle') onChange('ssl_verify', '');
          else onChange('ssl_verify', true);
        }}
        helperText="If connecting fails with a certificate error, place your org's CA bundle at backend/certs/tls_bundle.pem (auto-detected) or choose 'Disabled' as a quick workaround."
      >
        <MenuItem value="true">Enabled — auto-use backend/certs/tls_bundle.pem if present</MenuItem>
        <MenuItem value="ca_bundle">Custom CA Bundle — provide explicit path to PEM file</MenuItem>
        <MenuItem value="false">Disabled — skip SSL verification (not recommended)</MenuItem>
      </TextField>
      {typeof config.ssl_verify === 'string' && config.ssl_verify !== 'true' && config.ssl_verify !== 'false' && (
        <TextField
          label="CA Bundle Path (PEM file)" fullWidth size="small"
          value={config.ssl_verify}
          onChange={e => onChange('ssl_verify', e.target.value)}
          placeholder="/etc/ssl/certs/my-org-ca.pem"
          helperText="Absolute server path to your CA bundle (.pem). Tip: placing it at backend/certs/tls_bundle.pem is picked up automatically without specifying a path."
        />
      )}
      <TextField
        label="Custom Endpoint URL" fullWidth size="small"
        value={config.endpoint_url || ''}
        onChange={e => onChange('endpoint_url', e.target.value)}
        placeholder="https://s3.custom-endpoint.com"
        helperText="For S3-compatible storage (MinIO, Ceph, NetApp, etc.). Leave blank for AWS."
      />
      <FormControlLabel
        control={
          <Switch
            size="small"
            checked={!!config.path_style}
            onChange={e => onChange('path_style', e.target.checked)}
          />
        }
        label={
          <Box>
            <Typography variant="body2">Force path-style URLs</Typography>
            <Typography variant="caption" color="text.secondary">
              Required for NetApp StorageGRID, NetApp ONTAP S3, MinIO, and Ceph when using HTTPS.
              AWS S3 does not need this.
            </Typography>
          </Box>
        }
        sx={{ alignItems: 'flex-start', mt: 0.5 }}
      />

      <TextField
        select label="URL Addressing Style (advanced)" fullWidth size="small"
        value={config.addressing_style || 'auto'}
        onChange={e => {
          const v = e.target.value;
          if (v === 'auto') onChange('addressing_style', undefined);
          else onChange('addressing_style', v);
        }}
        helperText={
          'Force the URL form boto3 generates.  "Auto" picks the right default ' +
          '(path-style for VPC endpoints, virtual-hosted otherwise).  Override to ' +
          '"Virtual-hosted" when your VPC has wildcard private DNS for ' +
          '*.vpce-XXX.s3.<region>.vpce.amazonaws.com — required for AWS S3 VPC ' +
          'interface endpoints whose pod CoreDNS does NOT forward the standard ' +
          'AWS S3 names.  URL will become <bucket>.vpce-XXX.s3.<region>.vpce.amazonaws.com/<key>.'
        }
      >
        <MenuItem value="auto">Auto — VPC ⇒ path-style, otherwise virtual-hosted (default)</MenuItem>
        <MenuItem value="virtual">Virtual-hosted — bucket as subdomain of endpoint host</MenuItem>
        <MenuItem value="path">Path-style — bucket in URL path</MenuItem>
      </TextField>

      <SectionLabel>Apache Iceberg (optional)</SectionLabel>
      <TextField
        label="Iceberg Warehouse Path" fullWidth size="small"
        value={config.iceberg_warehouse_path || ''}
        onChange={e => onChange('iceberg_warehouse_path', e.target.value)}
        placeholder="warehouse/my_database/"
        helperText="S3 prefix where Iceberg table directories are stored. Leave blank to browse plain Parquet files."
      />
    </Stack>
  );
};

// Wrapper that passes registered_tables from S3Form into RegisteredTablesEditor
// Used inside the dialog — receives the full config + onChange + connectionId
const S3FormWithTables = ({ config, onChange, connectionId, isShared, systemAccounts }: {
  config: Record<string, any>;
  onChange: (key: string, value: any) => void;
  connectionId?: string | null;
  isShared?: boolean;
  systemAccounts?: Array<{ id: number; name: string; account_type: string; is_active: boolean }>;
}) => (
  <>
    <S3Form config={config} onChange={onChange} isShared={isShared} systemAccounts={systemAccounts} />
    <Divider sx={{ my: 1 }} />
    <RegisteredTablesEditor
      tables={config.registered_tables || []}
      onChange={(tables) => onChange('registered_tables', tables)}
      connectionId={connectionId}
    />
  </>
);

// ── Reusable: attach a vault/shared System Account to a connection ───────────
// Sets ``config.system_account_id``.  The backend chokepoint
// (core/connectors/get_connector) resolves it to user/password/token at runtime
// -- from HashiCorp Vault when the account has use_vault=True, else the
// encrypted password column.  Literal fields win: if username/password are also
// typed in, those are used and this is a fallback.  Optional on every connector.
const SystemAccountField = ({
  config, onChange, systemAccounts = [], allowedTypes,
  label = 'System Account (optional)', required = false, helper,
}: {
  config: Record<string, any>;
  onChange: (key: string, value: any) => void;
  systemAccounts?: Array<{ id: number; name: string; account_type: string; is_active: boolean }>;
  allowedTypes: string[];
  label?: string;
  required?: boolean;
  /** What the field says once accounts are listable and some match. */
  helper?: string;
}) => {
  const options = systemAccounts.filter(a => allowedTypes.includes(a.account_type));
  const accountsListable = React.useContext(SystemAccountsListable);
  return (
    <TextField
      select label={label} fullWidth size="small" required={required}
      value={config.system_account_id ?? ''}
      onChange={e => onChange('system_account_id',
        e.target.value === '' ? null : Number(e.target.value))}
      helperText={
        !accountsListable
          ? 'Only an admin can list system accounts; ask an admin to attach one.'
          : options.length === 0
            ? 'No matching system accounts. Create one in Admin → System Accounts (Vault or encrypted credentials).'
            : (helper || 'Optional — resolve credentials at runtime from a shared/Vault System Account. Leave the username/password blank to use it; if both are set, the typed values win.')
      }
      sx={{ mt: 1 }}
    >
      <MenuItem value=""><em>— none (use the fields above) —</em></MenuItem>
      {options.map(a => (
        <MenuItem key={a.id} value={a.id} disabled={!a.is_active}>
          {a.name}
          <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.75 }}>
            ({a.account_type})
          </Typography>
          {!a.is_active && ' (inactive)'}
        </MenuItem>
      ))}
    </TextField>
  );
};

// ── Local Folder Form ─────────────────────────────────────────────────────────
const LocalForm = ({ config, onChange }) => (
  <Stack spacing={2}>
    <TextField
      label="Folder Path" fullWidth required size="small"
      value={config.base_path || ''}
      onChange={e => onChange('base_path', e.target.value)}
      placeholder="/data/parquet or C:\Data\Parquet"
      helperText="Absolute path to the folder containing .parquet files"
    />
  </Stack>
);

// ── Upload Files Form ─────────────────────────────────────────────────────────
const MAX_FILE_SIZE = 1 * 1024 * 1024 * 1024; // 1 GB
const ALLOWED_EXTENSIONS = ['.parquet', '.csv', '.txt', '.json', '.tsv'];

const formatFileSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
};

const UploadForm = ({ pendingFiles, setPendingFiles, uploadedFiles, onDeleteUploaded, connectionId }: {
  pendingFiles: File[];
  setPendingFiles: (files: File[]) => void;
  uploadedFiles: { filename: string; size_bytes: number }[];
  onDeleteUploaded: (filename: string) => void;
  connectionId: string | null;
}) => {
  const [dragOver, setDragOver] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const validateAndAddFiles = (newFiles: FileList | File[]) => {
    const valid: File[] = [];
    const errors: string[] = [];
    Array.from(newFiles).forEach(f => {
      const ext = '.' + f.name.split('.').pop()?.toLowerCase();
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        errors.push(`${f.name}: unsupported format. Allowed: ${ALLOWED_EXTENSIONS.join(', ')}`);
      } else if (f.size > MAX_FILE_SIZE) {
        errors.push(`${f.name}: exceeds 1 GB limit (${formatFileSize(f.size)})`);
      } else if (pendingFiles.some(p => p.name === f.name) || uploadedFiles.some(u => u.filename === f.name)) {
        errors.push(`${f.name}: already added`);
      } else {
        valid.push(f);
      }
    });
    if (errors.length) alert(errors.join('\n'));
    if (valid.length) setPendingFiles([...pendingFiles, ...valid]);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length) validateAndAddFiles(e.dataTransfer.files);
  };

  const removePending = (name: string) => {
    setPendingFiles(pendingFiles.filter(f => f.name !== name));
  };

  return (
    <Stack spacing={2}>
      {/* Drop zone */}
      <Box
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        {...clickable(() => fileInputRef.current?.click(), { label: 'Upload files: drag and drop here, or click to browse' })}
        sx={{
          border: '2px dashed',
          borderColor: dragOver ? '#10b981' : '#cbd5e1',
          borderRadius: 2,
          p: 3,
          textAlign: 'center',
          cursor: 'pointer',
          bgcolor: dragOver ? '#ecfdf5' : '#f8fafc',
          transition: 'all 0.2s',
          '&:hover': { borderColor: '#10b981', bgcolor: '#ecfdf5' },
        }}
      >
        <UploadIcon sx={{ fontSize: 40, color: dragOver ? '#10b981' : '#94a3b8', mb: 1 }} />
        <Typography variant="body2" color="text.secondary">
          Drag & drop files here, or <strong>click to browse</strong>
        </Typography>
        <Typography variant="caption" color="text.disabled" sx={{ mt: 0.5, display: 'block' }}>
          Max 1 GB per file — {ALLOWED_EXTENSIONS.join(', ')}
        </Typography>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={ALLOWED_EXTENSIONS.join(',')}
          style={{ display: 'none' }}
          onChange={e => { if (e.target.files?.length) validateAndAddFiles(e.target.files); e.target.value = ''; }}
        />
      </Box>

      {/* Pending files (not yet uploaded) */}
      {pendingFiles.length > 0 && (
        <Box>
          <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
            Ready to upload ({pendingFiles.length} file{pendingFiles.length > 1 ? 's' : ''})
          </Typography>
          {pendingFiles.map(f => (
            <Box key={f.name} sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, px: 1, bgcolor: '#f0fdf4', borderRadius: 1, mb: 0.5 }}>
              <FileIcon sx={{ fontSize: 18, color: '#10b981' }} />
              <Typography variant="body2" sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {f.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">{formatFileSize(f.size)}</Typography>
              <IconButton aria-label="Close" size="small" onClick={(e) => { e.stopPropagation(); removePending(f.name); }}>
                <CloseIcon sx={{ fontSize: 16 }} />
              </IconButton>
            </Box>
          ))}
        </Box>
      )}

      {/* Already uploaded files (on server) */}
      {uploadedFiles.length > 0 && (
        <Box>
          <Typography variant="caption" fontWeight={600} color="text.secondary" sx={{ mb: 0.5, display: 'block' }}>
            Uploaded ({uploadedFiles.length} file{uploadedFiles.length > 1 ? 's' : ''})
          </Typography>
          {uploadedFiles.map(f => (
            <Box key={f.filename} sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, px: 1, bgcolor: '#f1f5f9', borderRadius: 1, mb: 0.5 }}>
              <SuccessIcon sx={{ fontSize: 18, color: '#10b981' }} />
              <Typography variant="body2" sx={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {f.filename}
              </Typography>
              <Typography variant="caption" color="text.secondary">{formatFileSize(f.size_bytes)}</Typography>
              <IconButton aria-label="Close" size="small" onClick={() => onDeleteUploaded(f.filename)}>
                <CloseIcon sx={{ fontSize: 16 }} />
              </IconButton>
            </Box>
          ))}
        </Box>
      )}

      {pendingFiles.length === 0 && uploadedFiles.length === 0 && (
        <Alert severity="info" sx={{ py: 0.5 }}>
          Select files to upload. Files will be stored on the server and available for querying.
        </Alert>
      )}
    </Stack>
  );
};

// ── Trino / Starburst Config Form ─────────────────────────────────────────────
/** The Trino/Starburst CA field holds PEM text: a paste that is not a
 *  certificate would make every TLS handshake fail with a sentence about
 *  the SERVER's certificate, sending the person to the wrong side. */
export const trinoConfigProblem = (c: Record<string, any>): string | null => {
  const pem = String(c.ca_cert_pem || '').trim();
  if (pem && !pem.includes('-----BEGIN CERTIFICATE-----')) {
    return 'CA certificate must be PEM text (-----BEGIN CERTIFICATE----- ... -----END CERTIFICATE-----)';
  }
  return null;
};

export const TrinoForm = ({ config, onChange, connType, systemAccounts = [] }) => {
  const authType = config.auth_type || 'basic';
  // 2026-10-08: the issuing CA is a CONNECTION fact (a Starburst Enterprise
  // behind a corporate CA), offered only where it can matter -- HTTPS with
  // verification on.  Galaxy sits on a public CA and needs nothing here.
  const caApplies = (config.http_scheme || 'https') === 'https' && config.verify_ssl !== false;
  return (
    <Stack spacing={2}>
      <SectionLabel>Connection</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Host" required size="small" sx={{ flex: 1 }}
          value={config.host || ''}
          onChange={e => onChange('host', e.target.value)}
          placeholder={connType === 'starburst' ? 'galaxy.starburstdata.com' : 'trino.company.com'}
        />
        <TextField
          label="Port" required size="small" type="number" sx={{ width: 120 }}
          value={config.port ?? 443}
          onChange={e => onChange('port', Number(e.target.value))}
        />
      </Box>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          select label="HTTP Scheme" size="small" sx={{ width: 120 }}
          value={config.http_scheme || 'https'}
          onChange={e => onChange('http_scheme', e.target.value)}
        >
          <MenuItem value="https">HTTPS</MenuItem>
          <MenuItem value="http">HTTP</MenuItem>
        </TextField>
        <TextField
          select label="Verify SSL" size="small" sx={{ width: 130 }}
          value={config.verify_ssl === false ? 'false' : 'true'}
          onChange={e => onChange('verify_ssl', e.target.value === 'true')}
        >
          <MenuItem value="true">Yes (secure)</MenuItem>
          <MenuItem value="false">No (skip)</MenuItem>
        </TextField>
      </Box>
      {caApplies && (
        <TextField
          label="CA certificate (PEM, optional)" size="small" fullWidth multiline minRows={2} maxRows={6}
          value={config.ca_cert_pem || ''}
          onChange={e => onChange('ca_cert_pem', e.target.value)}
          inputProps={{ 'data-testid': 'trino-ca-pem' }}
          placeholder={'-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----'}
          helperText="For a cluster on a private or corporate CA: paste the issuing CA. It is trusted alongside the public roots on every road (browse, query, feeds, Spark). Starburst Galaxy uses a public CA and needs nothing here."
        />
      )}

      <SectionLabel>Authentication</SectionLabel>
      <TextField
        label="Username" required size="small" fullWidth
        value={config.user || ''}
        onChange={e => onChange('user', e.target.value)}
        placeholder={connType === 'starburst' ? 'user@example.com' : 'admin'}
        helperText={connType === 'starburst'
          ? 'Starburst Galaxy: your login e-mail. A role suffix (user@example.com/accountadmin) is sent as typed; the Role field below is the cleaner way to pick one.'
          : ''}
      />
      <TextField
        label="Role (optional)" size="small" fullWidth
        value={config.role || ''}
        onChange={e => onChange('role', e.target.value)}
        inputProps={{ 'data-testid': 'trino-role' }}
        placeholder={connType === 'starburst' ? 'accountadmin' : ''}
        helperText="The system role this connection runs as, sent as X-Trino-Role on every statement (what SET ROLE selects). Blank = the user's default role. Catalog browsing, column detection and every query see only what this role may see."
      />
      <TextField
        select label="Auth Type" size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
      >
        <MenuItem value="none">None</MenuItem>
        <MenuItem value="basic">Basic (username + password)</MenuItem>
        <MenuItem value="jwt">JWT Token</MenuItem>
        <MenuItem value="kerberos">Kerberos</MenuItem>
        <MenuItem value="oauth2">OAuth2</MenuItem>
      </TextField>
      {/* 2026-09-25: Trino sends credentials only over TLS -- HTTP + Basic
          failed at Test with the client library's own sentence.  Say it here,
          with the two ways out, before the user tests. */}
      {(config.http_scheme === 'http') && authType !== 'none' && (
        <Alert severity="warning" data-testid="trino-http-auth-warning">
          Over HTTP, Trino accepts no credentials. Choose HTTPS for {authType === 'basic' ? 'a password' : 'this sign-in'},
          or Auth Type <strong>None</strong> for a cluster without authentication (the username is still sent).
        </Alert>
      )}
      {authType === 'basic' && (
        <PasswordField
          label="Password" required
          value={config.password || ''}
          onChange={v => onChange('password', v)}
        />
      )}
      {authType === 'jwt' && (
        <PasswordField
          label="JWT Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
          placeholder="eyJhbGciOiJSUzI1NiJ9..."
        />
      )}
      {authType === 'kerberos' && (
        <Alert severity="info" sx={{ py: 0.5, fontSize: 13 }}>
          Kerberos auth uses the host principal from the server. Ensure kinit is configured in the runtime environment.
        </Alert>
      )}
      {authType === 'oauth2' && (
        <PasswordField
          label="OAuth2 Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
        />
      )}

      <SectionLabel>Default Catalog / Schema (optional)</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Default Catalog" size="small" sx={{ flex: 1 }}
          value={config.catalog || ''}
          onChange={e => onChange('catalog', e.target.value)}
          placeholder="hive"
        />
        <TextField
          label="Default Schema" size="small" sx={{ flex: 1 }}
          value={config.schema || ''}
          onChange={e => onChange('schema', e.target.value)}
          placeholder="default"
        />
      </Box>

      <SectionLabel>Shared / Vault credentials (optional)</SectionLabel>
      <SystemAccountField config={config} onChange={onChange}
        systemAccounts={systemAccounts} allowedTypes={['db_account', 'ad_account']} />
    </Stack>
  );
};

// ── Snowflake Config Form ─────────────────────────────────────────────────────
// ── Snowflake key-pair: attach the key file, or take the key from Vault ──────
// 2026-10-03 -- "why should we paste the private key manually ... we should
// attach the key ... in a real scenario the key comes from Vault as a key
// value pair".  Two first-class sources: the .p8 file read IN THE BROWSER
// (no upload endpoint -- the text travels exactly as a paste does and is
// encrypted at rest like every other secret), or a System Account whose Vault
// kv entry holds {username, private_key[, private_key_passphrase]}, resolved
// by core/connectors/get_connector at every login.

/** System-account types that can carry a Snowflake private key in Vault. */
export const SNOWFLAKE_KEY_ACCOUNT_TYPES = ['snowflake_keypair', 'db_account'];
const KEY_FILE_ACCEPT = '.p8,.pem,.key';
/** A private key file is a few KB; anything far bigger is the wrong file. */
const KEY_FILE_MAX_BYTES = 64 * 1024;

export const readKeyFile = (file: File): Promise<string> => new Promise((resolve, reject) => {
  if (file.size > KEY_FILE_MAX_BYTES) {
    reject(new Error(`${file.name} is ${Math.round(file.size / 1024)} KB — a private key file is a few KB. Pick the .p8 / .pem key file.`));
    return;
  }
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result || ''));
  reader.onerror = () => reject(reader.error || new Error(`Could not read ${file.name}`));
  reader.readAsText(file);
});

/** The private key as a SAVED SECRET: the API masks it as "***" (it is in
 *  core/crypto.py SENSITIVE_FIELDS), so a saved key shows as an empty field
 *  that says it is saved, an untouched Save keeps it, and clearing what was
 *  typed or attached returns to "keep the saved one" -- the PasswordField
 *  rules, on a multi-line field with an Attach button. */
const PrivateKeyField = ({ value, onChange }: { value: string; onChange: (v: string) => void }) => {
  const hadSaved = React.useRef(false);
  if (value === MASKED_SECRET) hadSaved.current = true;
  const saved = value === MASKED_SECRET;
  const [attached, setAttached] = useState('');
  const [readError, setReadError] = useState('');
  const fileInput = React.useRef<HTMLInputElement>(null);
  const emptyValue = () => (hadSaved.current ? MASKED_SECRET : '');
  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';            // attaching the same file again still fires
    if (!file) return;
    try {
      const text = await readKeyFile(file);
      onChange(text);
      setAttached(file.name);
      setReadError('');
    } catch (err: any) {
      setReadError(err?.message || String(err));
    }
  };
  return (
    <Stack spacing={1}>
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
        <Button size="small" variant="outlined" startIcon={<AttachIcon />}
          onClick={() => fileInput.current?.click()}>
          Attach key file
        </Button>
        <input ref={fileInput} type="file" accept={KEY_FILE_ACCEPT} hidden
          aria-label="Private key file" data-testid="private-key-file" onChange={onFile} />
        {attached && (
          <Chip size="small" icon={<FileIcon />} label={`Attached: ${attached}`}
            onDelete={() => { setAttached(''); onChange(emptyValue()); }} />
        )}
      </Box>
      <TextField
        label="Private Key (PEM)" fullWidth size="small" multiline rows={5}
        value={saved ? '' : value}
        onChange={e => {
          const v = e.target.value;
          setAttached('');
          onChange(v === '' ? emptyValue() : v);
        }}
        placeholder={saved ? '•••••••• saved — type or attach to replace'
          : '-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----'}
        InputLabelProps={saved ? { shrink: true } : undefined}
        inputProps={{ style: { fontFamily: 'monospace', fontSize: 12 } }}
        error={!!readError}
        helperText={readError || (saved
          ? 'A key is saved (stored encrypted, never shown). Leave blank to keep it.'
          : 'Attach the .p8 / .pem key file, or paste its contents. Stored encrypted; never shown again.')}
      />
    </Stack>
  );
};

const SnowflakeKeyPairSection = ({ config, onChange, systemAccounts = [] }: {
  config: Record<string, any>;
  onChange: (key: string, value: any) => void;
  systemAccounts?: Array<{ id: number; name: string; account_type: string; is_active: boolean }>;
}) => {
  const [source, setSource] = useState<'key' | 'vault'>(
    config.system_account_id != null && config.system_account_id !== '' ? 'vault' : 'key');
  // Switching to Vault clears the typed key (a literal key WINS over the
  // account, so a kept one would silently keep Vault out); switching back
  // restores what was there, a saved key included.
  const kept = React.useRef<{ key: string; passphrase: string }>({ key: '', passphrase: '' });
  const pick = (next: 'key' | 'vault') => {
    if (next === source) return;
    setSource(next);
    if (next === 'vault') {
      kept.current = { key: config.private_key || '', passphrase: config.private_key_passphrase || '' };
      onChange('private_key', '');
      onChange('private_key_passphrase', '');
    } else {
      onChange('system_account_id', null);
      onChange('private_key', kept.current.key);
      onChange('private_key_passphrase', kept.current.passphrase);
    }
  };
  return (
    <>
      <TextField
        select label="Private key source" size="small" fullWidth
        value={source}
        onChange={e => pick(e.target.value as 'key' | 'vault')}
      >
        <MenuItem value="key">Attach or paste the key file</MenuItem>
        <MenuItem value="vault">From Vault (System Account)</MenuItem>
      </TextField>
      {source === 'key' ? (
        <>
          <PrivateKeyField value={config.private_key || ''} onChange={v => onChange('private_key', v)} />
          <PasswordField
            label="Key Passphrase (if encrypted)"
            value={config.private_key_passphrase || ''}
            onChange={v => onChange('private_key_passphrase', v)}
          />
        </>
      ) : (
        <>
          <Alert severity="info" sx={{ fontSize: 12 }} data-testid="snowflake-key-from-vault">
            The private key is read from Vault each time this connection logs in — nothing is
            pasted or stored here. The System Account's Vault entry (Secret Type
            {' '}<b>kv_secrets</b>) holds <code>username</code> and <code>private_key</code>, plus
            {' '}<code>private_key_passphrase</code> if the key is encrypted.
          </Alert>
          <SystemAccountField config={config} onChange={onChange}
            systemAccounts={systemAccounts} allowedTypes={SNOWFLAKE_KEY_ACCOUNT_TYPES}
            label="System Account (Vault key)" required
            helper="The Snowflake key-pair account whose Vault entry holds the private key. The Username above may be left blank to use the one in Vault." />
        </>
      )}
    </>
  );
};

/** What stops a Snowflake connection form from being saved or tested, or
 *  null.  With a System Account attached the username and the private key
 *  may come from it, so neither is required here. */
export const snowflakeConfigProblem = (c: Record<string, any>): string | null => {
  const viaAccount = c.system_account_id != null && c.system_account_id !== '';
  if (!String(c.account || '').trim()) return 'Account identifier is required';
  if (!viaAccount && !String(c.user || '').trim()) return 'Username is required';
  if ((c.auth_type || 'password') === 'key_pair' && !viaAccount && !String(c.private_key || '').trim())
    return 'A private key is required for Key Pair auth — attach the key file, paste it, or choose "From Vault (System Account)"';
  return null;
};

export const SnowflakeForm = ({ config, onChange, systemAccounts = [] }) => {
  const authType = config.auth_type || 'password';
  const viaAccount = config.system_account_id != null && config.system_account_id !== '';
  return (
    <Stack spacing={2}>
      <SectionLabel>Account</SectionLabel>
      <TextField
        label="Account Identifier" required size="small" fullWidth
        value={config.account || ''}
        onChange={e => onChange('account', e.target.value)}
        placeholder="xy12345.us-east-1 or https://<account>.privatelink.<your domain>"
        helperText="The account identifier, or paste the whole Snowflake address (PrivateLink too). QueryStudio connects to that address and uses its first part as the account."
      />
      <TextField
        label="Username" required={!viaAccount} size="small" fullWidth
        value={config.user || ''}
        onChange={e => onChange('user', e.target.value)}
        placeholder="JOHN.DOE@company.com"
        helperText={viaAccount ? 'Leave blank to use the username held by the System Account.' : undefined}
      />

      <SectionLabel>Authentication</SectionLabel>
      <TextField
        select label="Auth Type" size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
      >
        <MenuItem value="sso_portal">Auto (Portal SSO)</MenuItem>
        <MenuItem value="password">Password</MenuItem>
        <MenuItem value="key_pair">Key Pair (RSA)</MenuItem>
        <MenuItem value="oauth">OAuth Token</MenuItem>
      </TextField>
      {authType === 'sso_portal' && (
        <>
          <Alert severity="info" sx={{ fontSize: 12 }}>
            Snowflake credentials are resolved via the portal SSO.
            Enter the service account username and password below.
          </Alert>
          <TextField
            label="Service Account Username" fullWidth required size="small"
            value={config.sso_username || ''}
            onChange={e => onChange('sso_username', e.target.value)}
            placeholder="SF_SVC_USER"
          />
          <PasswordField
            label="Service Account Password" required
            value={config.sso_password || ''}
            onChange={v => onChange('sso_password', v)}
          />
        </>
      )}
      {authType === 'password' && (
        <PasswordField
          label="Password" required
          value={config.password || ''}
          onChange={v => onChange('password', v)}
        />
      )}
      {authType === 'key_pair' && (
        <SnowflakeKeyPairSection config={config} onChange={onChange} systemAccounts={systemAccounts} />
      )}
      {authType === 'oauth' && (
        <PasswordField
          label="OAuth Token" required
          value={config.token || ''}
          onChange={v => onChange('token', v)}
        />
      )}

      <SectionLabel>Warehouse & Database (optional)</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Warehouse" size="small" sx={{ flex: 1 }}
          value={config.warehouse || ''}
          onChange={e => onChange('warehouse', e.target.value)}
          placeholder="COMPUTE_WH"
        />
        <TextField
          label="Role" size="small" sx={{ flex: 1 }}
          value={config.role || ''}
          onChange={e => onChange('role', e.target.value)}
          placeholder="SYSADMIN"
        />
      </Box>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Database" size="small" sx={{ flex: 1 }}
          value={config.database || ''}
          onChange={e => onChange('database', e.target.value)}
          placeholder="MY_DATABASE"
        />
        <TextField
          label="Default Schema" size="small" sx={{ flex: 1 }}
          value={config.schema || ''}
          onChange={e => onChange('schema', e.target.value)}
          placeholder="PUBLIC"
        />
      </Box>

      {authType !== 'key_pair' && (
        <>
          <SectionLabel>Shared / Vault credentials (optional)</SectionLabel>
          <SystemAccountField config={config} onChange={onChange}
            systemAccounts={systemAccounts} allowedTypes={['db_account']} />
        </>
      )}
    </Stack>
  );
};

// ── Databricks Config Form ────────────────────────────────────────────────────
const DatabricksForm = ({ config, onChange, systemAccounts = [] }) => (
  <Stack spacing={2}>
    <SectionLabel>SQL Warehouse</SectionLabel>
    <TextField
      label="Server Hostname" required size="small" fullWidth
      value={config.server_hostname || ''}
      onChange={e => onChange('server_hostname', e.target.value)}
      placeholder="adb-1234567890123456.12.azuredatabricks.net"
      helperText="Found in: SQL Warehouse → Connection Details → Server hostname"
    />
    <TextField
      label="HTTP Path" required size="small" fullWidth
      value={config.http_path || ''}
      onChange={e => onChange('http_path', e.target.value)}
      placeholder="/sql/1.0/warehouses/abc123def456"
      helperText="Found in: SQL Warehouse → Connection Details → HTTP path"
    />
    <SectionLabel>Authentication</SectionLabel>
    <PasswordField
      label="Personal Access Token" required
      value={config.access_token || ''}
      onChange={v => onChange('access_token', v)}
      placeholder="dapiXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
      helperText="Generate at: Settings → Developer → Access tokens"
    />
    <SectionLabel>Catalog / Schema (optional)</SectionLabel>
    <Box sx={{ display: 'flex', gap: 1 }}>
      <TextField
        label="Default Catalog" size="small" sx={{ flex: 1 }}
        value={config.catalog || ''}
        onChange={e => onChange('catalog', e.target.value)}
        placeholder="main"
        helperText="Leave blank for legacy hive_metastore"
      />
      <TextField
        label="Default Schema" size="small" sx={{ flex: 1 }}
        value={config.schema || ''}
        onChange={e => onChange('schema', e.target.value)}
        placeholder="default"
      />
    </Box>
    <SectionLabel>Shared / Vault credentials (optional)</SectionLabel>
    <SystemAccountField config={config} onChange={onChange}
      systemAccounts={systemAccounts} allowedTypes={['db_account', 's3_keys']} />
  </Stack>
);

const OracleForm = ({ config, onChange, systemAccounts = [] }) => (
  <Stack spacing={2}>
    <SectionLabel>Connection</SectionLabel>
    <Box sx={{ display: 'flex', gap: 1 }}>
      <TextField
        label="Host" size="small" sx={{ flex: 2 }}
        value={config.host || ''}
        onChange={e => onChange('host', e.target.value)}
        placeholder="oracle.example.com"
        helperText="Leave blank if using DSN"
      />
      <TextField
        label="Port" size="small" type="number" sx={{ flex: 1 }}
        value={config.port || 1521}
        onChange={e => onChange('port', e.target.value)}
      />
    </Box>
    <Box sx={{ display: 'flex', gap: 1 }}>
      <TextField
        label="Service Name" size="small" sx={{ flex: 1 }}
        value={config.service_name || ''}
        onChange={e => onChange('service_name', e.target.value)}
        placeholder="ORCL or pdb1.example.com"
        helperText="Preferred over SID"
      />
      <TextField
        label="SID (legacy)" size="small" sx={{ flex: 1 }}
        value={config.sid || ''}
        onChange={e => onChange('sid', e.target.value)}
        placeholder="ORCL"
      />
    </Box>
    <TextField
      label="DSN Override" size="small" fullWidth
      value={config.dsn || ''}
      onChange={e => onChange('dsn', e.target.value)}
      placeholder="Leave blank to build from host / port / service name"
      helperText="Full Oracle DSN (overrides host/port/service if set)"
    />
    <SectionLabel>Authentication</SectionLabel>
    <TextField
      label="Username" required size="small" fullWidth
      value={config.user || ''}
      onChange={e => onChange('user', e.target.value)}
    />
    <PasswordField
      label="Password" required
      value={config.password || ''}
      onChange={v => onChange('password', v)}
    />
    <SectionLabel>Wallet / mTLS (Autonomous DB — optional)</SectionLabel>
    <TextField
      label="Wallet Location" size="small" fullWidth
      value={config.wallet_location || ''}
      onChange={e => onChange('wallet_location', e.target.value)}
      placeholder="/path/to/wallet"
    />
    <PasswordField
      label="Wallet Password"
      value={config.wallet_password || ''}
      onChange={v => onChange('wallet_password', v)}
    />
    <SectionLabel>Shared / Vault credentials (optional)</SectionLabel>
    <SystemAccountField config={config} onChange={onChange}
      systemAccounts={systemAccounts} allowedTypes={['db_account']} />
  </Stack>
);

// ── AWS Athena form ──────────────────────────────────────────────────────────
const AthenaForm = ({ config, onChange, systemAccounts = [] }) => {
  const authType = config.auth_type || 'iam_role';
  return (
    <Stack spacing={2}>
      <SectionLabel>Athena Workgroup</SectionLabel>
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="AWS Region" required size="small" sx={{ flex: 1 }}
          select
          value={config.region || 'us-east-1'}
          onChange={e => onChange('region', e.target.value)}
        >
          {AWS_REGIONS.map(r => (
            <MenuItem key={r.value} value={r.value}>{r.label}</MenuItem>
          ))}
        </TextField>
        <TextField
          label="Workgroup" required size="small" sx={{ flex: 1 }}
          value={config.workgroup || ''}
          onChange={e => onChange('workgroup', e.target.value)}
          placeholder="primary"
          helperText="Set per-query bytes-scanned + cost limits in the AWS console for this workgroup."
        />
      </Box>
      <TextField
        label="S3 Staging Directory" required size="small" fullWidth
        value={config.s3_staging_dir || ''}
        onChange={e => onChange('s3_staging_dir', e.target.value)}
        placeholder="s3://my-bucket/athena-results/"
        helperText="Where Athena writes query results (must end with /)."
      />
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          label="Data Catalog" size="small" sx={{ flex: 1 }}
          value={config.catalog || 'AwsDataCatalog'}
          onChange={e => onChange('catalog', e.target.value)}
          helperText="AwsDataCatalog (default) or a Lake Formation catalog name."
        />
        <TextField
          label="Default Database" size="small" sx={{ flex: 1 }}
          value={config.schema || 'default'}
          onChange={e => onChange('schema', e.target.value)}
          placeholder="default"
        />
      </Box>
      <SectionLabel>Authentication</SectionLabel>
      <TextField
        label="Auth Mode" select size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
        helperText="iam_role/instance: pod IAM role (recommended in EKS). access_key: explicit AWS keys. profile: ~/.aws/credentials profile."
      >
        <MenuItem value="iam_role">IAM Role (pod / EC2 instance profile)</MenuItem>
        <MenuItem value="instance">EC2 Instance Profile (alias)</MenuItem>
        <MenuItem value="access_key">AWS Access Keys</MenuItem>
        <MenuItem value="profile">~/.aws Profile</MenuItem>
      </TextField>
      {authType === 'access_key' && (<>
        <TextField
          label="AWS Access Key ID" size="small" fullWidth
          value={config.aws_access_key_id || ''}
          onChange={e => onChange('aws_access_key_id', e.target.value)}
        />
        <PasswordField
          label="AWS Secret Access Key"
          value={config.aws_secret_access_key || ''}
          onChange={v => onChange('aws_secret_access_key', v)}
        />
        <PasswordField
          label="Session Token (STS, optional)"
          value={config.aws_session_token || ''}
          onChange={v => onChange('aws_session_token', v)}
        />
      </>)}
      {authType === 'profile' && (
        <TextField
          label="AWS Profile Name" size="small" fullWidth
          value={config.aws_profile || ''}
          onChange={e => onChange('aws_profile', e.target.value)}
          placeholder="default"
        />
      )}
      <SectionLabel>Cost Guard (optional)</SectionLabel>
      <TextField
        label="Per-query bytes-scanned cap (MB)" size="small" type="number" fullWidth
        value={config.bytes_scanned_cutoff_mb || ''}
        onChange={e => onChange('bytes_scanned_cutoff_mb', e.target.value)}
        placeholder="e.g. 10240 = 10 GB"
        helperText="Belt-and-suspenders cost cap. Athena rejects queries that would scan more. At ~$5/TB, 10 GB ≈ $0.05/query."
      />
      <SectionLabel>Shared / Vault credentials (optional)</SectionLabel>
      <SystemAccountField config={config} onChange={onChange}
        systemAccounts={systemAccounts} allowedTypes={['s3_keys', 'aws_portal']} />
    </Stack>
  );
};

// ── REST API form ────────────────────────────────────────────────────────────
const RestApiForm = ({ config, onChange }) => {
  const authType = config.auth_type || 'bearer';
  return (
    <Stack spacing={2}>
      <SectionLabel>Endpoint</SectionLabel>
      <TextField
        label="Base URL" required size="small" fullWidth
        value={config.base_url || ''}
        onChange={e => onChange('base_url', e.target.value)}
        placeholder="https://api.example.com/v2"
      />
      <SectionLabel>Authentication</SectionLabel>
      <TextField
        label="Auth Type" select size="small" fullWidth
        value={authType}
        onChange={e => onChange('auth_type', e.target.value)}
      >
        {['none', 'basic', 'bearer', 'api_key', 'oauth2_client_credentials'].map(o => (
          <MenuItem key={o} value={o}>{o === 'oauth2_client_credentials' ? 'OAuth2 Client Credentials' : o.charAt(0).toUpperCase() + o.slice(1).replace('_', ' ')}</MenuItem>
        ))}
      </TextField>
      {authType === 'bearer' && (
        <PasswordField label="Bearer Token" value={config.token || ''} onChange={v => onChange('token', v)} />
      )}
      {authType === 'basic' && (<>
        <TextField label="Username" size="small" fullWidth value={config.username || ''} onChange={e => onChange('username', e.target.value)} />
        <PasswordField label="Password" value={config.password || ''} onChange={v => onChange('password', v)} />
      </>)}
      {authType === 'api_key' && (<>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <TextField label="Key Name" size="small" sx={{ flex: 2 }} value={config.api_key_name || ''} onChange={e => onChange('api_key_name', e.target.value)} placeholder="X-API-Key" />
          <TextField label="Location" select size="small" sx={{ flex: 1 }} value={config.api_key_location || 'header'} onChange={e => onChange('api_key_location', e.target.value)}>
            <MenuItem value="header">Header</MenuItem>
            <MenuItem value="query">Query Param</MenuItem>
          </TextField>
        </Box>
        <PasswordField label="API Key Value" value={config.api_key_value || ''} onChange={v => onChange('api_key_value', v)} />
      </>)}
      {authType === 'oauth2_client_credentials' && (<>
        <TextField label="Token URL" size="small" fullWidth value={config.token_url || ''} onChange={e => onChange('token_url', e.target.value)} placeholder="https://auth.example.com/oauth/token" />
        <TextField label="Client ID" size="small" fullWidth value={config.client_id || ''} onChange={e => onChange('client_id', e.target.value)} />
        <PasswordField label="Client Secret" value={config.client_secret || ''} onChange={v => onChange('client_secret', v)} />
      </>)}
      <SectionLabel>Options</SectionLabel>
      <TextField
        label="Default Headers (JSON)" size="small" fullWidth multiline rows={2}
        value={config.default_headers || '{}'}
        onChange={e => onChange('default_headers', e.target.value)}
        placeholder='{"Accept": "application/json"}'
      />
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField label="Timeout (sec)" size="small" type="number" sx={{ flex: 1 }} value={config.timeout_seconds ?? 30} onChange={e => onChange('timeout_seconds', Number(e.target.value))} />
        <TextField label="Rate Limit (req/sec)" size="small" type="number" sx={{ flex: 1 }} value={config.rate_limit_rps ?? 10} onChange={e => onChange('rate_limit_rps', Number(e.target.value))} helperText="0 = unlimited" />
      </Box>
      <FormControlLabel
        control={<Switch checked={config.verify_ssl !== false} onChange={e => onChange('verify_ssl', e.target.checked)} size="small" />}
        label="Verify SSL"
      />
    </Stack>
  );
};

// ── Connection type display chip ──────────────────────────────────────────────
const TypeChip = ({ type }) => {
  const meta = CONN_TYPE_META[type] || { label: type, icon: <StorageIcon fontSize="small" />, color: '#888' };
  return (
    <Chip
      icon={React.cloneElement(meta.icon, { style: { color: 'white', fontSize: 14 } })}
      label={meta.label}
      size="small"
      variant="filled"
      sx={{ bgcolor: meta.color, color: 'white', fontWeight: 600, '& .MuiChip-icon': { color: 'white' } }}
    />
  );
};

// ── Connection detail summary ─────────────────────────────────────────────────
const connDetail = (conn) => {
  const c = conn.config || {};
  switch (conn.connection_type) {
    case 's3':         return `s3://${c.bucket_name || '—'}  ·  ${c.region_name || '—'}`;
    case 'local':      return c.base_path || '—';
    case 'upload':     return 'Uploaded files';
    case 'trino':
    case 'starburst':  return `${c.http_scheme || 'https'}://${c.host || '—'}:${c.port || ''}  ·  ${c.user || '—'}`;
    case 'snowflake':  return `${c.account || '—'}.snowflakecomputing.com  ·  ${c.user || '—'}`;
    case 'databricks': return `${c.server_hostname || '—'}  ·  ${c.http_path || '—'}`;
    case 'oracle':     return `${c.host || '—'}:${c.port || 1521}  ·  ${c.service_name || c.sid || '—'}`;
    case 'athena':     return `${c.region || '—'}  ·  workgroup=${c.workgroup || 'primary'}  ·  ${c.catalog || 'AwsDataCatalog'}`;
    default:           return '—';
  }
};

// ── Registered Tables Editor ─────────────────────────────────────────────────
const FORMAT_COLORS: Record<string, string> = { iceberg: '#16a34a', parquet: '#3b82f6', csv: '#f97316' };

const RegisteredTablesEditor = ({ tables, onChange, connectionId }: {
  tables: any[];
  onChange: (tables: any[]) => void;
  connectionId?: string | null;
}) => {
  const [showAdd, setShowAdd] = useState(false);
  // Phase 134-Q — newTable carries partition_columns so the Browse &
  // Register flow can auto-populate them from detected hive folder
  // structure OR Iceberg metadata.  Previously the user had to manually
  // add every partition column post-registration via the expanded
  // table row, even though the backend already returned the data.
  const [newTable, setNewTable] = useState<{
    name: string;
    s3_prefix: string;
    format: string;
    description: string;
    partition_columns?: string[];
  }>({ name: '', s3_prefix: '', format: 'parquet', description: '', partition_columns: [] });
  // Partition column editing state
  const [expandedTable, setExpandedTable] = useState<string | null>(null);
  const [partColInput, setPartColInput] = useState('');
  // 2026-09-27 — DECLARED bloom-sidecar columns per Iceberg table: warm-on-
  // commit builds these on every new snapshot.  Saved with the connection.
  const [bloomColInput, setBloomColInput] = useState('');
  // 2026-09-27 — the WATCHED state the server reports per registered
  // Iceberg table (GET /tables decorates each with `watch`).  Three-valued:
  // watched / not watched / could not read -- never folded into "no".
  const [watchByName, setWatchByName] = useState<Record<string, any>>({});
  const [watchLookupError, setWatchLookupError] = useState('');
  useEffect(() => {
    let cancelled = false;
    setWatchByName({});
    setWatchLookupError('');
    if (!connectionId) return () => { cancelled = true; };
    api.listRegisteredTables(connectionId)
      .then((r: any) => {
        if (cancelled) return;
        const map: Record<string, any> = {};
        for (const t of (Array.isArray(r?.tables) ? r.tables : [])) {
          if (t && t.name && t.watch) map[t.name] = t.watch;
        }
        setWatchByName(map);
      })
      .catch((e: any) => { if (!cancelled) setWatchLookupError(String(e?.message || e)); });
    return () => { cancelled = true; };
  }, [connectionId, tables.length]);
  const handleSetBloomCols = (tableName: string, cols: string[]) => {
    onChange(tables.map(t => t.name === tableName ? { ...t, bloom_columns: cols } : t));
  };
  const [savingPartCols, setSavingPartCols] = useState(false);
  const [partColError, setPartColError] = useState('');
  const [addError, setAddError] = useState('');
  const [discovering, setDiscovering] = useState(false);
  const [candidates, setCandidates] = useState<any[] | null>(null);
  const [discoverError, setDiscoverError] = useState('');
  // Backend caps discovery at N candidates; when it does, tell the user
  // there may be more rather than silently presenting a partial list.
  const [discoverTruncated, setDiscoverTruncated] = useState<number | null>(null);
  const [refreshingSchemas, setRefreshingSchemas] = useState(false);

  // Folder browser state
  const [showBrowser, setShowBrowser] = useState(false);
  const [browserPath, setBrowserPath] = useState<string[]>([]);  // breadcrumb path segments
  const [browserFolders, setBrowserFolders] = useState<any[]>([]);
  const [browserFileSummary, setBrowserFileSummary] = useState<any>({});
  const [browserIsIceberg, setBrowserIsIceberg] = useState(false);
  const [browserHivePartitioned, setBrowserHivePartitioned] = useState(false);
  const [browserHiveKeys, setBrowserHiveKeys] = useState<string[]>([]);
  // Phase 134-Q — Iceberg partition columns surfaced from metadata
  // by /browse-folders.  Used to auto-populate the new table's
  // partition_columns when the user clicks "Select this folder".
  const [browserIcebergKeys, setBrowserIcebergKeys] = useState<string[]>([]);
  const [browserLoading, setBrowserLoading] = useState(false);

  const handleAdd = async () => {
    if (!newTable.name.trim()) { setAddError('Table name is required'); return; }
    if (!newTable.s3_prefix.trim()) { setAddError('S3 prefix is required'); return; }
    if (tables.some(t => t.name.toLowerCase() === newTable.name.trim().toLowerCase())) { setAddError('Table name already exists'); return; }
    if (!['iceberg', 'parquet', 'csv'].includes(newTable.format)) { setAddError('Invalid format'); return; }
    // For Iceberg tables, validate the prefix has actual metadata before accepting
    if (newTable.format === 'iceberg' && connectionId) {
      try {
        const result = await api.browseFolders(connectionId, newTable.s3_prefix.trim());
        if (!result.is_iceberg) {
          setAddError(
            'This folder is not an Iceberg table root. Navigate deeper to the folder ' +
            'that contains both data/ and metadata/ subfolders.'
          );
          return;
        }
      } catch (_) { /* skip validation if browse fails */ }
    }
    onChange([...tables, { ...newTable, name: newTable.name.trim(), s3_prefix: newTable.s3_prefix.trim() }]);
    setNewTable({ name: '', s3_prefix: '', format: 'parquet', description: '', partition_columns: [] });
    setAddError('');
    setShowAdd(false);
    setShowBrowser(false);
  };

  const handleRemove = (name: string) => {
    onChange(tables.filter(t => t.name !== name));
  };

  const handleDiscover = async (prefix?: string) => {
    if (!connectionId) return;
    setDiscovering(true);
    setCandidates(null);
    setDiscoverError('');
    setDiscoverTruncated(null);
    try {
      const result = await api.discoverTables(connectionId, prefix || undefined);
      const existingNames = new Set(tables.map(t => t.name));
      const found = (result.candidates || []).filter((c: any) => !existingNames.has(c.name));
      setCandidates(found);
      if (result.truncated) setDiscoverTruncated(result.limit || found.length);
      if (found.length === 0) {
        setDiscoverError(prefix
          ? `No tables found under "${prefix}". Navigate deeper or try a different folder.`
          : 'No tables detected. Try "Browse & Register" to navigate to a specific catalog/schema first.');
      }
    } catch (e: any) {
      setCandidates([]);
      setDiscoverTruncated(null);
      // BF-427: safeStringify on the fallback — fetch/Axios errors carry
      // circular request/response refs that crash native JSON.stringify.
      const msg = typeof e === 'string' ? e : (e?.message || e?.detail || safeStringify(e));
      setDiscoverError(`Discovery failed: ${msg}`);
    }
    setDiscovering(false);
  };

  const handleRegisterCandidate = (candidate: any) => {
    if (tables.some(t => t.name === candidate.name)) return;
    onChange([...tables, candidate]);
    setCandidates(prev => prev?.filter(c => c.name !== candidate.name) || null);
  };

  const handleRefreshAllSchemas = async () => {
    if (!connectionId || tables.length === 0) return;
    setRefreshingSchemas(true);
    try {
      await api.refreshAllSchemas(connectionId);
    } catch { /* silent */ }
    setRefreshingSchemas(false);
  };

  // Save partition columns for the currently expanded table
  const handleSavePartitionCols = async (tableName: string, cols: string[]) => {
    if (!connectionId) return;
    setSavingPartCols(true); setPartColError('');
    try {
      await safeFetch(
        `/api/connections/${connectionId}/tables/${encodeURIComponent(tableName)}/partition-columns`,
        { method: 'PATCH', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ partition_columns: cols }) },
      );
      // safeFetch throws ApiError on non-ok responses — if we reach here it succeeded
      onChange(tables.map(t => t.name === tableName ? { ...t, partition_columns: cols } : t));
    } catch (e: any) { setPartColError(e.message || 'Save failed'); }
    setSavingPartCols(false);
  };

  const handleAddPartCol = (tableName: string, currentCols: string[]) => {
    const col = partColInput.trim().toLowerCase();
    if (!col || currentCols.map(c => c.toLowerCase()).includes(col)) {
      setPartColInput(''); return;
    }
    const newCols = [...currentCols, col];
    setPartColInput('');
    handleSavePartitionCols(tableName, newCols);
  };

  const handleRemovePartCol = (tableName: string, currentCols: string[], col: string) => {
    handleSavePartitionCols(tableName, currentCols.filter(c => c !== col));
  };

  // ── Folder browser ──────────────────────────────────────────────
  const browseFolder = async (prefix: string) => {
    if (!connectionId) return;
    setBrowserLoading(true);
    try {
      const result = await api.browseFolders(connectionId, prefix);
      setBrowserFolders(result.folders || []);
      setBrowserFileSummary(result.file_summary || {});
      setBrowserIsIceberg(result.is_iceberg || false);
      setBrowserHivePartitioned(result.hive_partitioned || false);
      setBrowserHiveKeys(result.hive_partition_keys || []);
      // Phase 134-Q — capture iceberg partition keys from metadata.
      setBrowserIcebergKeys(result.iceberg_partition_keys || []);
    } catch {
      setBrowserFolders([]);
      setBrowserFileSummary({});
      setBrowserIcebergKeys([]);
    }
    setBrowserLoading(false);
  };

  const openBrowser = () => {
    setShowBrowser(true);
    setShowAdd(true);
    setBrowserPath([]);
    browseFolder('');
  };

  const navigateTo = (folderPrefix: string, folderName: string) => {
    setBrowserPath(prev => [...prev, folderName]);
    browseFolder(folderPrefix);
  };

  const navigateBreadcrumb = (index: number) => {
    // Navigate to a breadcrumb position (-1 = root)
    const newPath = index < 0 ? [] : browserPath.slice(0, index + 1);
    setBrowserPath(newPath);
    browseFolder(newPath.join('/') ? newPath.join('/') + '/' : '');
  };

  const selectCurrentFolder = () => {
    const prefix = browserPath.join('/') ? browserPath.join('/') + '/' : '';
    const name = browserPath.length > 0 ? browserPath[browserPath.length - 1] : '';
    const fmt = browserIsIceberg ? 'iceberg' : (browserHivePartitioned || browserFileSummary.parquet > 0 ? 'parquet' : (browserFileSummary.csv > 0 ? 'csv' : 'parquet'));
    // Phase 134-Q — auto-populate partition_columns from the detected
    // hive folder structure OR the Iceberg metadata spec.  Backend's
    // /browse-folders endpoint has been returning both since this
    // commit — frontend was just ignoring them.
    const detectedPartitionCols: string[] = browserIsIceberg
      ? browserIcebergKeys
      : (browserHivePartitioned ? browserHiveKeys : []);
    setNewTable(prev => ({
      ...prev,
      s3_prefix: prefix,
      format: fmt,
      name: prev.name || name,
      // Preserve any partition_columns the user may have already typed
      // in the manual form; the detected list only fills in when the
      // user hadn't touched the field.
      partition_columns: (prev.partition_columns && prev.partition_columns.length > 0)
        ? prev.partition_columns
        : detectedPartitionCols,
    }));
    setShowBrowser(false);
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <TableIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
          <SectionLabel>Registered Tables</SectionLabel>
        </Box>
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          {connectionId && tables.length > 0 && (
            <Button size="small" startIcon={refreshingSchemas ? <CircularProgress size={14} /> : <RefreshIcon sx={{ fontSize: 14 }} />}
              onClick={handleRefreshAllSchemas} disabled={refreshingSchemas} sx={{ textTransform: 'none', fontSize: 12 }}>
              Refresh Schemas
            </Button>
          )}
          {connectionId && (
            <Button size="small" startIcon={discovering ? <CircularProgress size={14} /> : <DiscoverIcon />}
              onClick={() => handleDiscover()} disabled={discovering} sx={{ textTransform: 'none', fontSize: 12 }}>
              Auto-Discover
            </Button>
          )}
          {connectionId && (
            <Button size="small" startIcon={<FolderIcon sx={{ fontSize: 14 }} />}
              onClick={openBrowser} sx={{ textTransform: 'none', fontSize: 12 }}>
              Browse & Register
            </Button>
          )}
          <Button size="small" startIcon={<AddIcon />} onClick={() => { setShowAdd(!showAdd); setShowBrowser(false); }}
            sx={{ textTransform: 'none', fontSize: 12 }}>
            Manual
          </Button>
        </Box>
      </Box>

      {/* Existing tables */}
      {tables.length > 0 && (
        <Box sx={{ mb: 1 }}>
          {tables.map(t => {
            const partCols: string[] = t.partition_columns || [];
            const isExpanded = expandedTable === t.name;
            return (
              <Box key={t.name} sx={{ borderRadius: 1, border: '1px solid', borderColor: 'divider', mb: 0.5 }}>
                {/* Table row */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5, px: 1,
                  cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' },
                  borderRadius: isExpanded ? '4px 4px 0 0' : 1 }}
                  {...clickable(() => { setExpandedTable(isExpanded ? null : t.name); setPartColInput(''); setPartColError(''); },
                    { label: t.name, expanded: isExpanded })}>
                  <Chip label={t.format} size="small"
                    sx={{ bgcolor: FORMAT_COLORS[t.format] || '#888', color: 'white', fontWeight: 600, fontSize: 10, height: 20, minWidth: 56 }} />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" fontWeight={600} noWrap>{t.name}</Typography>
                    <Typography variant="caption" color="text.secondary" noWrap>{t.s3_prefix}</Typography>
                  </Box>
                  {partCols.length > 0 && (
                    <Tooltip title={`Partition columns: ${partCols.join(', ')}`}>
                      <Chip label={`⚡ ${partCols.length} part.`} size="small"
                        sx={{ fontSize: 10, height: 18, bgcolor: 'success.light', color: 'white' }} />
                    </Tooltip>
                  )}
                  {partCols.length === 0 && (
                    <Tooltip title="No partition columns configured — click to add">
                      <Chip label="No pruning" size="small"
                        sx={{ fontSize: 10, height: 18, bgcolor: 'warning.light', color: 'white' }} />
                    </Tooltip>
                  )}
                  {t.format === 'iceberg' && connectionId && (() => {
                    const w = watchByName[t.name];
                    if (watchLookupError) {
                      return (
                        <Tooltip title={`Watched state could not be read: ${watchLookupError}`}>
                          <Chip label="watch ?" size="small" data-testid={`watch-chip-${t.name}`}
                            sx={{ fontSize: 10, height: 18 }} />
                        </Tooltip>
                      );
                    }
                    if (!w) return null;
                    if (w.watched === true) {
                      return (
                        <Tooltip title={`Watched by the manifest watcher — snapshot ${w.last_snapshot_id || 'not seen yet'}${w.last_synced_at ? `, synced ${w.last_synced_at}` : ''}${w.last_sync_error ? `, last error: ${w.last_sync_error}` : ''}`}>
                          <Chip label="watched" size="small" data-testid={`watch-chip-${t.name}`}
                            sx={{ fontSize: 10, height: 18, bgcolor: 'success.main', color: 'white' }} />
                        </Tooltip>
                      );
                    }
                    if (w.watched === false) {
                      return (
                        <Tooltip title="Not watched: save the connection to add it to the watcher">
                          <Chip label="not watched" size="small" data-testid={`watch-chip-${t.name}`}
                            sx={{ fontSize: 10, height: 18, bgcolor: 'grey.500', color: 'white' }} />
                        </Tooltip>
                      );
                    }
                    return (
                      <Tooltip title={`Watched state could not be read: ${w.error || 'unknown'}`}>
                        <Chip label="watch ?" size="small" data-testid={`watch-chip-${t.name}`}
                          sx={{ fontSize: 10, height: 18 }} />
                      </Tooltip>
                    );
                  })()}
                  {isExpanded ? <ExpandLessIcon sx={{ fontSize: 16, opacity: 0.5 }} /> : <ExpandMoreIcon sx={{ fontSize: 16, opacity: 0.5 }} />}
                  <IconButton aria-label="Delete" size="small" onClick={e => { e.stopPropagation(); handleRemove(t.name); }}
                    sx={{ opacity: 0.5, '&:hover': { opacity: 1 } }}>
                    <DeleteIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Box>

                {/* Partition columns panel */}
                <Collapse in={isExpanded}>
                  <Box sx={{ px: 1.5, pb: 1, pt: 0.5, bgcolor: 'grey.50', borderTop: '1px solid', borderColor: 'divider' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
                      <Typography variant="caption" fontWeight={700} color="text.secondary">
                        Partition Columns (used for S3 file pruning)
                      </Typography>
                      <Tooltip
                        title="These are column names from your S3 hive-style paths (e.g. col=value/). Add a WHERE col = 'value' filter in your SQL to read only matching files instead of scanning all files."
                        placement="right"
                        arrow
                      >
                        <InfoIcon sx={{ fontSize: 13, color: 'text.disabled', cursor: 'help' }} />
                      </Tooltip>
                    </Box>
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.75, fontSize: '0.68rem' }}>
                      Auto-detected from S3 paths or Iceberg metadata on first query. Add or remove below.
                      These take effect when your SQL WHERE clause filters on these columns.
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 0.75 }}>
                      {partCols.length === 0 && (
                        <Typography variant="caption" color="text.disabled" sx={{ fontStyle: 'italic' }}>
                          None yet — will be auto-detected on first query, or add manually below.
                        </Typography>
                      )}
                      {partCols.map(col => (
                        <Chip key={col} label={col} size="small"
                          deleteIcon={<CloseIcon sx={{ fontSize: 12 }} />}
                          onDelete={() => handleRemovePartCol(t.name, partCols, col)}
                          sx={{ height: 20, fontSize: '0.72rem', bgcolor: 'primary.light', color: 'white',
                            '& .MuiChip-deleteIcon': { color: 'rgba(255,255,255,0.7)' } }} />
                      ))}
                    </Box>
                    <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                      <TextField size="small" placeholder="column_name" value={partColInput}
                        onChange={e => setPartColInput(e.target.value)}
                        onKeyDown={e => { if (e.key === 'Enter') handleAddPartCol(t.name, partCols); }}
                        sx={{ '& .MuiInputBase-root': { height: 26, fontSize: '0.8rem' }, flex: 1 }} />
                      <Button size="small" variant="contained" disabled={!partColInput.trim() || savingPartCols}
                        onClick={() => handleAddPartCol(t.name, partCols)}
                        sx={{ height: 26, fontSize: '0.72rem', px: 1, minWidth: 50 }}>
                        {savingPartCols ? <CircularProgress size={12} /> : 'Add'}
                      </Button>
                    </Box>
                    {partColError && <Typography variant="caption" color="error">{partColError}</Typography>}

                    {/* 2026-09-27 — declared bloom columns (Iceberg only). */}
                    {t.format === 'iceberg' && (() => {
                      const bloomCols: string[] = Array.isArray(t.bloom_columns) ? t.bloom_columns : [];
                      return (
                        <Box sx={{ mt: 1.25 }} data-testid={`bloom-cols-${t.name}`}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
                            <Typography variant="caption" fontWeight={700} color="text.secondary">
                              Bloom columns (built on every commit)
                            </Typography>
                            <Tooltip
                              title="Columns an equality lookup (WHERE id = ...) should skip files on. A bloom sidecar is built for each on every new snapshot, so the first query after a load already has its index. Leave empty to rely on the adaptive prefetch, which builds one after three hits in the query history."
                              placement="right" arrow>
                              <InfoIcon sx={{ fontSize: 13, color: 'text.disabled', cursor: 'help' }} />
                            </Tooltip>
                          </Box>
                          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 0.75 }}>
                            {bloomCols.length === 0 && (
                              <Typography variant="caption" color="text.disabled" sx={{ fontStyle: 'italic' }}>
                                None declared.
                              </Typography>
                            )}
                            {bloomCols.map(col => (
                              <Chip key={col} label={col} size="small"
                                deleteIcon={<CloseIcon sx={{ fontSize: 12 }} />}
                                onDelete={() => handleSetBloomCols(t.name, bloomCols.filter(c => c !== col))}
                                sx={{ height: 20, fontSize: '0.72rem', bgcolor: 'secondary.light', color: 'white',
                                  '& .MuiChip-deleteIcon': { color: 'rgba(255,255,255,0.7)' } }} />
                            ))}
                          </Box>
                          <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center' }}>
                            <TextField size="small" placeholder="column_name" value={bloomColInput}
                              inputProps={{ 'aria-label': `bloom column for ${t.name}` }}
                              onChange={e => setBloomColInput(e.target.value)}
                              onKeyDown={e => {
                                if (e.key === 'Enter' && bloomColInput.trim()) {
                                  handleSetBloomCols(t.name, Array.from(new Set([...bloomCols, bloomColInput.trim()])));
                                  setBloomColInput('');
                                }
                              }}
                              sx={{ '& .MuiInputBase-root': { height: 26, fontSize: '0.8rem' }, flex: 1 }} />
                            <Button size="small" variant="contained" disabled={!bloomColInput.trim()}
                              onClick={() => {
                                handleSetBloomCols(t.name, Array.from(new Set([...bloomCols, bloomColInput.trim()])));
                                setBloomColInput('');
                              }}
                              sx={{ height: 26, fontSize: '0.72rem', px: 1, minWidth: 50 }}>
                              Add
                            </Button>
                          </Box>
                        </Box>
                      );
                    })()}
                  </Box>
                </Collapse>
              </Box>
            );
          })}
        </Box>
      )}

      {tables.length === 0 && !showAdd && !candidates && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', ml: 1, mb: 1 }}>
          No tables registered yet. Click <strong>Browse & Register</strong> to navigate to your catalog/schema folder and discover tables, or <strong>Auto-Discover</strong> to scan from root.
        </Typography>
      )}

      {/* Auto-discover results */}
      {candidates !== null && (
        <Box sx={{ mb: 1, p: 1, bgcolor: 'grey.50', borderRadius: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
            <Box>
              <Typography variant="caption" fontWeight={600}>
                Discovered Tables ({candidates.length})
              </Typography>
              {discoverTruncated !== null && (
                <Typography variant="caption" color="warning.main" sx={{ display: 'block' }}>
                  Showing the first {discoverTruncated}. There may be more -- narrow the scan
                  with "Browse & Register" to reach a specific catalog/schema.
                </Typography>
              )}
            </Box>
            {candidates.length > 1 && (
              <Button size="small" variant="contained" color="primary"
                sx={{ textTransform: 'none', fontSize: 11 }}
                onClick={() => {
                  const existingNames = new Set(tables.map(t => t.name));
                  const toAdd = candidates.filter(c => !existingNames.has(c.name));
                  if (toAdd.length > 0) {
                    onChange([...tables, ...toAdd]);
                    setCandidates([]);
                  }
                }}>
                Register All ({candidates.length})
              </Button>
            )}
          </Box>
          {candidates.length === 0 && discoverError ? (
            <Typography variant="caption" color="text.secondary">{discoverError}</Typography>
          ) : (
            <Box sx={{ maxHeight: 250, overflowY: 'auto' }}>
              {candidates.map(c => (
                <Box key={c.name} sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5 }}>
                  <Chip label={c.format} size="small"
                    sx={{ bgcolor: FORMAT_COLORS[c.format] || '#888', color: 'white', fontWeight: 600, fontSize: 10, height: 20, minWidth: 56 }} />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" fontWeight={600} noWrap>{c.name}</Typography>
                    <Typography variant="caption" color="text.secondary" noWrap>
                      {c.description || c.s3_prefix}
                    </Typography>
                    {/* Phase 134-Q — show detected partition columns
                        so the operator confirms what'll auto-populate
                        before clicking Register. */}
                    {Array.isArray(c.partition_columns) && c.partition_columns.length > 0 && (
                      <Typography variant="caption" sx={{ display: 'block', color: 'success.dark', fontSize: 10 }}>
                        ⚡ partitions: {c.partition_columns.join(', ')}
                      </Typography>
                    )}
                  </Box>
                  <Button size="small" variant="outlined"
                    sx={{ textTransform: 'none', fontSize: 11, minWidth: 70 }}
                    onClick={() => handleRegisterCandidate(c)}>
                    Register
                  </Button>
                </Box>
              ))}
            </Box>
          )}
          <Button size="small" onClick={() => { setCandidates(null); setDiscoverError(''); }}
            sx={{ mt: 0.5, textTransform: 'none', fontSize: 11 }}>
            Close
          </Button>
        </Box>
      )}

      {/* S3 Folder Browser */}
      <Collapse in={showBrowser && showAdd}>
        <Box sx={{ p: 1, mb: 1, bgcolor: '#f8fafc', borderRadius: 1, border: '1px solid', borderColor: 'divider' }}>
          <Typography variant="caption" fontWeight={700} sx={{ display: 'block', mb: 0.5 }}>
            Browse S3 Folders
          </Typography>

          {/* Breadcrumb */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25, mb: 0.5, flexWrap: 'wrap' }}>
            <Button size="small" onClick={() => navigateBreadcrumb(-1)}
              sx={{ textTransform: 'none', fontSize: 11, minWidth: 0, px: 0.5, fontWeight: browserPath.length === 0 ? 700 : 400 }}>
              / (root)
            </Button>
            {browserPath.map((seg, i) => (
              <React.Fragment key={i}>
                <Typography variant="caption" color="text.disabled">/</Typography>
                <Button size="small" onClick={() => navigateBreadcrumb(i)}
                  sx={{ textTransform: 'none', fontSize: 11, minWidth: 0, px: 0.5,
                    fontWeight: i === browserPath.length - 1 ? 700 : 400 }}>
                  {seg}
                </Button>
              </React.Fragment>
            ))}
            {browserLoading && <CircularProgress size={12} sx={{ ml: 0.5 }} />}
          </Box>

          {/* Detected format badge */}
          {(browserIsIceberg || browserHivePartitioned || browserFileSummary.parquet > 0 || browserFileSummary.csv > 0) && (
            <Box sx={{ display: 'flex', gap: 0.5, mb: 0.5, alignItems: 'center', flexWrap: 'wrap' }}>
              {browserIsIceberg && (
                <Chip label="Iceberg table detected" size="small"
                  sx={{ bgcolor: FORMAT_COLORS.iceberg, color: 'white', fontWeight: 600, fontSize: 10, height: 20 }} />
              )}
              {/* Phase 134-Q — surface iceberg partition columns
                  alongside the format chip so the operator knows
                  what will auto-populate on Select. */}
              {browserIsIceberg && browserIcebergKeys.length > 0 && (
                <Chip
                  label={`Auto-add partitions: ${browserIcebergKeys.join(', ')}`}
                  size="small"
                  sx={{ bgcolor: 'success.light', color: 'white',
                        fontWeight: 600, fontSize: 10, height: 20 }}
                />
              )}
              {browserHivePartitioned && !browserIsIceberg && (
                <Chip label={`Hive-partitioned Parquet (auto-add: ${browserHiveKeys.join(', ')})`} size="small"
                  sx={{ bgcolor: '#8b5cf6', color: 'white', fontWeight: 600, fontSize: 10, height: 20 }} />
              )}
              {browserFileSummary.parquet > 0 && !browserIsIceberg && !browserHivePartitioned && (
                <Chip label={`${browserFileSummary.parquet} parquet files`} size="small"
                  sx={{ bgcolor: FORMAT_COLORS.parquet, color: 'white', fontWeight: 600, fontSize: 10, height: 20 }} />
              )}
              {browserFileSummary.csv > 0 && !browserIsIceberg && !browserHivePartitioned && (
                <Chip label={`${browserFileSummary.csv} CSV files`} size="small"
                  sx={{ bgcolor: FORMAT_COLORS.csv, color: 'white', fontWeight: 600, fontSize: 10, height: 20 }} />
              )}
              <Button size="small" variant="contained" color="success"
                onClick={selectCurrentFolder}
                sx={{ textTransform: 'none', fontSize: 11, ml: 'auto' }}>
                Select this folder
              </Button>
            </Box>
          )}

          {/* Discover from current folder */}
          {browserPath.length > 0 && !browserIsIceberg && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5, px: 0.5 }}>
              <Button size="small" variant="outlined" color="primary"
                startIcon={discovering ? <CircularProgress size={12} /> : <DiscoverIcon sx={{ fontSize: 14 }} />}
                disabled={discovering}
                onClick={() => handleDiscover(browserPath.join('/') + '/')}
                sx={{ textTransform: 'none', fontSize: 11 }}>
                {discovering ? 'Scanning...' : 'Discover tables here'}
              </Button>
              <Typography variant="caption" color="text.secondary">
                Scan this folder for Iceberg/Parquet tables
              </Typography>
            </Box>
          )}

          {/* Folder list */}
          <Box sx={{ maxHeight: 200, overflowY: 'auto' }}>
            {browserFolders.length === 0 && !browserLoading && (
              <Typography variant="caption" color="text.secondary" sx={{ pl: 1 }}>
                No subfolders found.
              </Typography>
            )}
            {browserFolders.map(f => (
              <Box key={f.prefix}
                {...clickable(() => navigateTo(f.prefix, f.name), { label: `Open folder ${f.name}` })}
                sx={{ display: 'flex', alignItems: 'center', gap: 0.75, py: 0.4, px: 0.75, cursor: 'pointer',
                  borderRadius: 0.5, '&:hover': { bgcolor: 'action.hover' } }}>
                <FolderIcon sx={{ fontSize: 16, color: '#f59e0b' }} />
                <Typography variant="body2" sx={{ fontSize: 13 }}>{f.name}/</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Collapse>

      {/* Add form */}
      <Collapse in={showAdd}>
        <Box sx={{ p: 1.5, bgcolor: 'grey.50', borderRadius: 1, mb: 1 }}>
          {addError && <Alert severity="error" sx={{ mb: 1, py: 0 }}>{addError}</Alert>}
          <Stack spacing={1.5}>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <TextField label="Table Name" size="small" sx={{ flex: 1 }}
                value={newTable.name} onChange={e => { setNewTable(p => ({ ...p, name: e.target.value })); setAddError(''); }}
                placeholder="sales" />
              <TextField select label="Format" size="small" sx={{ width: 120 }}
                value={newTable.format} onChange={e => setNewTable(p => ({ ...p, format: e.target.value }))}>
                <MenuItem value="parquet">Parquet</MenuItem>
                <MenuItem value="iceberg">Iceberg</MenuItem>
                <MenuItem value="csv">CSV</MenuItem>
              </TextField>
            </Box>
            <TextField label="S3 Prefix" size="small" fullWidth
              value={newTable.s3_prefix} onChange={e => { setNewTable(p => ({ ...p, s3_prefix: e.target.value })); setAddError(''); }}
              placeholder="warehouse/db/sales/"
              helperText={connectionId ? 'Use "Browse & Register" above to pick a folder, or type the path manually' : 'Path to table root within the bucket'}
            />
            <TextField label="Description (optional)" size="small" fullWidth
              value={newTable.description} onChange={e => setNewTable(p => ({ ...p, description: e.target.value }))}
              placeholder="Daily sales transactions" />
            <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
              <Button size="small" onClick={() => { setShowAdd(false); setShowBrowser(false); setAddError(''); }}>Cancel</Button>
              <Button size="small" variant="contained" onClick={handleAdd}>Add Table</Button>
            </Box>
          </Stack>
        </Box>
      </Collapse>
    </Box>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// Main component
// ══════════════════════════════════════════════════════════════════════════════
const ConnectionManager = () => {
  const [connections, setConnections] = useState<any[]>([]);
  // FB-49 (2026-09-20) -- this list had no search and no pager, like
  // /datasets.  Client-side, and for the same reason: GET /api/connections
  // returns the caller's COMPLETE visible list in one read, so slicing the
  // loaded array is the truth rather than a pager over a capped page.
  const [connSearch, setConnSearch] = useState('');
  const [connPage, setConnPage] = useState(0);
  const [connRowsPerPage, setConnRowsPerPage] = useState(25);
  const [loading, setLoading]         = useState(true);
  // A failed load must NOT masquerade as "no connections yet" (Method
  // rule: a 200/empty with nothing useful is a defect).  Track the load
  // error so the empty state and the error state are distinguishable.
  const [loadError, setLoadError]     = useState<string | null>(null);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId]   = useState<string | null>(null);
  const [form, setForm]             = useState<{ name: string; connection_type: string; config: Record<string, any>; is_shared?: boolean }>({ name: '', connection_type: 's3', config: { ...EMPTY_CONFIGS.s3 }, is_shared: false });
  const [saving, setSaving]         = useState(false);
  const [formError, setFormError]   = useState('');
  // 2026-10-02 -- saved secrets the server could not DECRYPT (its encryption
  // key changed since they were saved).  They are still stored -- an
  // untouched Save keeps them -- but they cannot work until re-entered.
  const [credentialProblems, setCredentialProblems] = useState<string[]>([]);

  const [testResult, setTestResult] = useState(null);
  const [testing, setTesting]       = useState(null);   // null | 'dialog' | conn.id

  const [deleteTarget, setDeleteTarget] = useState(null);
  const [snack, setSnack] = useState<{ open: boolean; message: string; severity: 'success' | 'warning' | 'error' }>({ open: false, message: '', severity: 'success' });

  // BF-287: System accounts for the shared-connection picker.
  // Loaded once on mount; the picker filters to account_type='aws_portal'.
  // 2026-09-24: loaded only for an admin (the GET requires admin); for
  // anyone else the list is UNKNOWN and the pickers say so.
  const [systemAccounts, setSystemAccounts] = useState<Array<{ id: number; name: string; account_type: string; is_active: boolean; use_vault?: boolean }>>([]);
  const { user: authUser } = useAuth();
  const canListSystemAccounts = isAdminLike(authUser);

  // Upload connection state
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<{ filename: string; size_bytes: number }[]>([]);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [unusedUploads, setUnusedUploads] = useState<{ id: number; name: string; file_count: number; total_size_bytes: number }[]>([]);
  const [uploadEnabled, setUploadEnabled] = useState(false);

  const filteredConnections = useMemo(() => {
    const term = connSearch.trim().toLowerCase();
    if (!term) return connections;
    return connections.filter((cn: any) => (
      String(cn.name || '').toLowerCase().includes(term)
      || String(cn.connection_type || '').toLowerCase().includes(term)
      || String(cn.description || '').toLowerCase().includes(term)
    ));
  }, [connections, connSearch]);

  const pagedConnections = useMemo(
    () => filteredConnections.slice(connPage * connRowsPerPage,
                                    connPage * connRowsPerPage + connRowsPerPage),
    [filteredConnections, connPage, connRowsPerPage]);

  // a narrowed list has fewer pages; staying on page 4 of 1 shows nothing
  useEffect(() => { setConnPage(0); }, [connSearch, connRowsPerPage]);

  const loadConnections = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      // safeFetch (not api.listConnections, which swallows errors to [])
      // so a backend failure is visible instead of an empty list.
      const data = await safeFetch(`/api/connections?active_only=true`);
      setConnections((data as any[]) || []);
    } catch (e: any) {
      // Keep any list we already had -- a transient refresh error must
      // not erase what the user can see.  Surface the reason.
      setLoadError(e?.message || 'Failed to load connections');
    }
    setLoading(false);
    // Check for unused upload connections
    try {
      const status = await api.getUploadConnectionsStatus();
      const unused = (status?.upload_connections || []).filter((c: any) => !c.is_used && c.file_count > 0);
      setUnusedUploads(unused);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { loadConnections(); }, [loadConnections]);

  // Load ALL system accounts for the connection-form pickers.  Each form
  // filters to the account types relevant to it (S3 -> PORTAL_ACCOUNT_TYPES, SQL ->
  // db_account/ad_account, etc.).  2026-09-24: an admin-only read, asked
  // only by an admin; a failure is still silent.
  useEffect(() => {
    if (!canListSystemAccounts) return;
    safeFetch('/api/admin/system-accounts')
      .then((resp: any) => {
        const list = (resp?.accounts || []).map((a: any) => ({
          id: a.id, name: a.name,
          account_type: a.account_type,
          is_active: a.is_active !== false,
          use_vault: !!a.use_vault,
        }));
        setSystemAccounts(list);
      })
      .catch(() => { /* silent — admin endpoint */ });
  }, [canListSystemAccounts]);

  // Check if upload connections are enabled (container/OpenShift mode)
  useEffect(() => {
    safeFetch('/auth/config').then(cfg => {
      setUploadEnabled(cfg?.upload_enabled === true);
    }).catch(() => {});
  }, []);

  const openCreate = () => {
    setEditingId(null);
    setForm({ name: '', connection_type: 's3', config: { ...EMPTY_CONFIGS.s3 }, is_shared: false });
    setTestResult(null);
    setFormError('');
    setPendingFiles([]);
    setUploadedFiles([]);
    setUploadProgress(null);
    setDialogOpen(true);
  };

  const openEdit = async (conn) => {
    setEditingId(conn.id);
    // 2026-06-16 — refetch the connection BEFORE populating the form.
    // Pre-fix the Edit dialog read from the cached `connections` list
    // (loaded once at mount), which became stale after any update made
    // outside this React tree (another tab, another session, or a
    // backend-triggered change).  Symptom was the "Custom Endpoint URL"
    // textbox rendering empty in Edit even when the connection had a
    // VPC URL stored — the list snapshot predated the save.
    //
    // GET /api/connections/{id} returns mask_config(decrypt_config(...))
    // — sensitive fields come back as "***" (the existing update_connection
    // handler swaps them back to the real values before persisting), but
    // every NON-sensitive field (including endpoint_url, region_name,
    // bucket_name, registered_tables) is the live, current value.
    let freshConn = conn;
    try {
      const f = await api.getConnection(String(conn.id));
      if (f && f.config) freshConn = f;
    } catch {
      // Network error / 404 / etc. — fall back to the cached row so
      // the dialog still opens.  Stale data is better than no dialog.
    }
    const empty = EMPTY_CONFIGS[freshConn.connection_type] || {};
    setForm({
      name: freshConn.name,
      connection_type: freshConn.connection_type,
      config: { ...empty, ...freshConn.config },
      is_shared: freshConn.is_shared || false,
    });
    setTestResult(null);
    setFormError('');
    setCredentialProblems(Array.isArray(freshConn.credential_problems) ? freshConn.credential_problems : []);
    setPendingFiles([]);
    setUploadProgress(null);
    // Load existing uploaded files for upload connections
    if (freshConn.connection_type === 'upload') {
      try {
        const res = await api.listUploadedFiles(freshConn.id);
        setUploadedFiles(res?.files || []);
      } catch { setUploadedFiles([]); }
    } else {
      setUploadedFiles([]);
    }
    setDialogOpen(true);
  };

  const handleTypeChange = (newType) => {
    setForm(prev => ({ ...prev, connection_type: newType, config: { ...(EMPTY_CONFIGS[newType] || {}) } }));
    setTestResult(null);
    setFormError('');
    setPendingFiles([]);
    setUploadedFiles([]);
  };

  const handleDeleteUploadedFile = async (filename: string) => {
    if (!editingId) return;
    try {
      await api.deleteUploadedFile(editingId, filename);
      setUploadedFiles(prev => prev.filter(f => f.filename !== filename));
    } catch (e: any) {
      setFormError(e?.message || 'Failed to delete file');
    }
  };

  const updateConfig = (key, value) => {
    setForm(prev => ({ ...prev, config: { ...prev.config, [key]: value } }));
    setTestResult(null);
  };

  const validateForm = () => {
    const { connection_type: ct, config: c } = form;
    if (!form.name.trim()) return 'Connection name is required';
    if (ct === 's3'    && !c.bucket_name?.trim())    return 'Bucket name is required';
    if (ct === 's3' && c.bucket_name?.trim()) {
      const isOnPrem = !!c.path_style;
      const re = isOnPrem ? S3_BUCKET_ONPREM_RE : S3_BUCKET_AWS_RE;
      if (!re.test(c.bucket_name.trim())) {
        return isOnPrem
          ? 'Invalid S3 bucket name. On-prem bucket names must start and end with alphanumeric characters.'
          : 'Invalid S3 bucket name. AWS bucket names must be 3-63 lowercase alphanumeric/hyphen characters.';
      }
    }
    if (ct === 's3' && c.auth_mode === 'assume_role' && c.role_arn?.trim()) {
      if (!IAM_ARN_RE.test(c.role_arn.trim())) {
        return 'Invalid Role ARN format. Expected: arn:aws:iam::123456789012:role/MyRole';
      }
    }
    // Portal-auth mode requires a role_name — when an account has multiple
    // roles, an empty role_name would resolve to the FIRST role the portal
    // returns, which is rarely what the user wants.  Force them to pick one.
    if (ct === 's3' && c.auth_mode === 'portal' && !(c.role_name && c.role_name.trim())) {
      return 'IAM Role Name is required for AWS Portal authentication. Enter the exact role name (e.g. app-ReadOnlyRole) so the portal returns the right role_arn.';
    }
    if (ct === 'local' && !c.base_path?.trim())      return 'Folder path is required';
    if (ct === 'upload' && pendingFiles.length === 0 && uploadedFiles.length === 0) return 'Please select at least one file to upload';
    if ((ct === 'trino' || ct === 'starburst') && !c.host?.trim()) return 'Host is required';
    if ((ct === 'trino' || ct === 'starburst') && !c.user?.trim()) return 'Username is required';
    if (ct === 'trino' || ct === 'starburst') {
      const trProblem = trinoConfigProblem(c);
      if (trProblem) return trProblem;
    }
    if (ct === 'snowflake') {
      const sfProblem = snowflakeConfigProblem(c);
      if (sfProblem) return sfProblem;
    }
    if (ct === 'databricks' && !c.server_hostname?.trim()) return 'Server hostname is required';
    if (ct === 'databricks' && !c.http_path?.trim())       return 'HTTP path is required';
    if (ct === 'databricks' && !c.access_token?.trim())    return 'Access token is required';
    if (ct === 'oracle'     && !c.user?.trim())            return 'Username is required';
    if (ct === 'oracle'     && !c.password?.trim())        return 'Password is required';
    if (ct === 'oracle'     && !c.dsn?.trim() && !c.service_name?.trim() && !c.sid?.trim())
      return 'Provide at least one of: DSN, Service Name, or SID';
    if (ct === 'athena'     && !c.region?.trim())                     return 'AWS Region is required';
    if (ct === 'athena'     && !c.s3_staging_dir?.trim())             return 'S3 Staging Directory is required';
    if (ct === 'athena'     && !c.workgroup?.trim())                  return 'Workgroup is required';
    if (ct === 'athena'     && c.auth_type === 'access_key' &&
        (!c.aws_access_key_id?.trim() || !c.aws_secret_access_key?.trim()))
      return 'Access Key ID and Secret Access Key are required for access_key auth';
    if (ct === 'rest_api'   && !c.base_url?.trim())        return 'Base URL is required';
    return null;
  };

  const handleTestInDialog = async () => {
    const err = validateForm();
    if (err) { setFormError(err); return; }
    setTesting('dialog');
    setTestResult(null);
    setFormError('');
    try {
      const r = await api.testConnection({ connection_type: form.connection_type, config: form.config, ...(editingId ? { connection_id: Number(editingId) } : {}) });
      setTestResult(r);
    } catch (e: any) {
      setTestResult({ success: false, message: typeof e === 'string' ? e : (e?.message || 'Connection test failed') });
    }
    setTesting(null);
  };

  const handleSave = async () => {
    const err = validateForm();
    if (err) { setFormError(err); return; }
    setSaving(true);
    setFormError('');
    try {
      let connId = editingId;
      if (editingId) {
        await api.updateConnection(editingId, form);
      } else {
        const created = await api.createConnection(form);
        connId = created?.id;
      }

      // Upload pending files for upload-type connections
      if (form.connection_type === 'upload' && pendingFiles.length > 0 && connId) {
        setUploadProgress(`Uploading ${pendingFiles.length} file(s)...`);
        try {
          const result = await api.uploadConnectionFiles(String(connId), pendingFiles);
          if (result.errors?.length) {
            setFormError(`Some files failed: ${result.errors.join('; ')}`);
            setSaving(false);
            setUploadProgress(null);
            loadConnections();
            return;
          }
        } catch (e: any) {
          setFormError(typeof e === 'string' ? e : (e?.message || 'File upload failed'));
          setSaving(false);
          setUploadProgress(null);
          return;
        }
        setUploadProgress(null);
      }

      setDialogOpen(false);
      loadConnections();
    } catch (e: any) {
      setFormError(typeof e === 'string' ? e : (e?.message || 'Failed to save connection'));
    }
    setSaving(false);
  };

  const handleTestSaved = async (conn) => {
    setTesting(conn.id);
    try {
      // POST /api/connections/{id}/test handles all types (S3, local, SQL)
      // and updates last_test_status in DB so the status chip reflects the result
      await api.testSavedConnection(conn.id);
      loadConnections();
    } catch { loadConnections(); }
    setTesting(null);
  };

  const [refreshing, setRefreshing] = React.useState<string | null>(null);
  const [cloning, setCloning] = React.useState<string | null>(null);
  const handleRefreshCredentials = async (conn) => {
    setRefreshing(conn.id);
    try {
      const res = await api.refreshConnectionCredentials(conn.id);
      if (res?.status === 'ok') {
        setSnack({ open: true, message: 'Credentials refreshed successfully', severity: 'success' });
      } else {
        setSnack({ open: true, message: res?.message || 'Refresh failed', severity: 'warning' });
      }
    } catch {
      setSnack({ open: true, message: 'Failed to refresh credentials', severity: 'error' });
    }
    setRefreshing(null);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteConnection(deleteTarget.id);
      setSnack({ open: true, message: `Deleted '${deleteTarget.name}'`, severity: 'success' });
      loadConnections();
    } catch (e: any) {
      // A failed delete (e.g. 403 for a non-owner) must not silently
      // close the dialog leaving the row in place with no feedback.
      setSnack({ open: true, message: e?.message || 'Failed to delete connection', severity: 'error' });
    }
    setDeleteTarget(null);
  };

  // FB-62 (2026-09-23) — clone a connection, credentials and registered
  // tables included.  Deliberately a ONE-CLICK action with no form: the API
  // accepts a name and nothing else, because a dialog offering "clone and
  // also set the host" would be the exfiltration shape the route refuses.
  // Editing the copy is the ordinary Edit action, already owner-gated.
  // 2026-10-07 — an S3 clone reads the SAME bucket and the server refuses it
  // (409, naming the connection that holds the bucket); the error branch
  // below shows that sentence.  The tooltip says so before the click.
  const handleClone = async (conn: any) => {
    setCloning(conn.id);
    try {
      const created: any = await api.cloneConnection(String(conn.id));
      setSnack({
        open: true,
        message: `Cloned '${conn.name}' as '${created?.name || 'copy'}' — `
               + 'credentials copied, not shared. Edit it to change the host.',
        severity: 'success',
      });
      loadConnections();
    } catch (e: any) {
      // A 403 here is the owner gate, not a bug: say so rather than
      // failing silently and leaving the list unchanged.
      setSnack({
        open: true,
        message: e?.message || 'Failed to clone connection',
        severity: 'error',
      });
    }
    setCloning(null);
  };

  const { connection_type: ct } = form;
  const isSqlType = SQL_TYPES.includes(ct);

  return (
    <Box sx={{ p: 3, maxWidth: 1300, mx: 'auto' }}>

      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700 }}>Connection Manager</Typography>
          <Typography variant="subtitle2" color="text.secondary">
            Manage data source connections: S3, Local, Upload, Trino/Starburst, Snowflake, Databricks
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadConnections}>Refresh</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>New Connection</Button>
        </Box>
      </Box>

      {/* Unused upload connections warning */}
      {unusedUploads.length > 0 && (
        <Alert
          severity="warning"
          icon={<WarningIcon />}
          sx={{ mb: 2 }}
          action={
            <Button color="inherit" size="small" onClick={async () => {
              if (!window.confirm(`Delete ${unusedUploads.length} unused upload connection(s) and their files?\n\n${unusedUploads.map(u => `• ${u.name} (${u.file_count} files)`).join('\n')}`)) return;
              for (const u of unusedUploads) {
                try { await api.deleteConnection(String(u.id)); } catch { /* silent */ }
              }
              loadConnections();
            }}>
              Clean Up
            </Button>
          }
        >
          <strong>{unusedUploads.length} uploaded connection{unusedUploads.length > 1 ? 's' : ''} not used by any query</strong>
          {' — '}
          {unusedUploads.map(u => u.name).join(', ')}
          {' '}({formatFileSize(unusedUploads.reduce((a, u) => a + u.total_size_bytes, 0))} on disk).
          Consider cleaning up to free space.
        </Alert>
      )}

      {/* A non-empty list that failed to REFRESH keeps showing, with a
          dismissible warning -- a transient error must not blank the page. */}
      {loadError && connections.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }}
          action={<Button color="inherit" size="small" onClick={loadConnections}>Retry</Button>}>
          Could not refresh connections ({loadError}). Showing the last known list.
        </Alert>
      )}

      {/* Search (FB-49) */}
      {connections.length > 0 && (
        <TextField
          size="small"
          value={connSearch}
          onChange={e => setConnSearch(e.target.value)}
          placeholder="Search connections"
          inputProps={{ 'aria-label': 'Search connections' }}
          sx={{ mb: 2, minWidth: 320 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start"><DiscoverIcon fontSize="small" /></InputAdornment>
            ),
            endAdornment: connSearch ? (
              <InputAdornment position="end">
                <IconButton size="small" aria-label="Clear connection search"
                  onClick={() => setConnSearch('')}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />
      )}

      {/* Connection list */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}><CircularProgress /></Box>
      ) : loadError && connections.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <ErrorIcon sx={{ fontSize: 56, color: 'error.main', mb: 2, opacity: 0.6 }} />
          <Typography variant="h6" gutterBottom>Could not load connections</Typography>
          <Typography color="text.secondary" sx={{ mb: 1 }}>{loadError}</Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            This is a load failure, not an empty account -- your connections are safe.
          </Typography>
          <Button variant="contained" startIcon={<RefreshIcon />} onClick={loadConnections}>Retry</Button>
        </Paper>
      ) : filteredConnections.length === 0 && connections.length > 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            No connection matches "{connSearch.trim()}"
          </Typography>
          <Typography color="text.secondary">
            {connections.length} connection{connections.length > 1 ? 's' : ''} exist; none
            matches this search.
          </Typography>
        </Paper>
      ) : connections.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <StorageIcon sx={{ fontSize: 56, color: 'text.secondary', mb: 2, opacity: 0.4 }} />
          <Typography variant="h6" gutterBottom>No connections yet</Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            Create your first connection to query data from S3, local files, or SQL warehouses.
          </Typography>
          <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate}>Create Connection</Button>
        </Paper>
      ) : (
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: 'grey.50' } }}>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Details</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Last Tested</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pagedConnections.map(conn => (
                <TableRow key={conn.id} hover sx={{ '&:last-child td': { border: 0 } }}>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                      <Typography fontWeight={600} variant="body2">{conn.name}</Typography>
                      {conn.is_shared && (
                        <Chip icon={<SharedIcon sx={{ fontSize: 14 }} />} label="Shared" size="small"
                          color="info" variant="outlined" sx={{ height: 20, fontSize: 11 }} />
                      )}
                      {/* 2026-10-07 — one bucket, one connection.  Duplicates made
                          before the rule are kept (never deleted) and flagged
                          here for an admin, with the server's own sentence. */}
                      {conn.duplicate_bucket && (
                        <Tooltip title={conn.duplicate_bucket.message || 'Another connection reads this bucket'}>
                          <Chip icon={<WarningIcon sx={{ fontSize: 14 }} />} label="Duplicate bucket"
                            size="small" color="warning" variant="outlined"
                            aria-label={`Duplicate bucket: ${conn.duplicate_bucket.message || ''}`}
                            sx={{ height: 20, fontSize: 11 }} />
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell><TypeChip type={conn.connection_type} /></TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary"
                      sx={{ fontFamily: 'monospace', fontSize: 12, maxWidth: 380, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {connDetail(conn)}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {conn.last_test_status === 'success' ? (
                      <Chip icon={<SuccessIcon />} label="Connected" size="small" color="success" variant="outlined" />
                    ) : conn.last_test_status === 'failed' ? (
                      <Tooltip title={conn.last_test_message || ''}>
                        <Chip icon={<ErrorIcon />} label="Failed" size="small" color="error" variant="outlined" />
                      </Tooltip>
                    ) : (
                      <Chip label="Untested" size="small" variant="outlined" />
                    )}
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption" color="text.secondary">
                      {conn.last_tested_at ? new Date(conn.last_tested_at).toLocaleString() : '—'}
                    </Typography>
                  </TableCell>
                  <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                    <Tooltip title="Test Connection">
                      <IconButton size="small" onClick={() => handleTestSaved(conn)} disabled={testing === conn.id}>
                        {testing === conn.id ? <CircularProgress size={16} /> : <TestIcon />}
                      </IconButton>
                    </Tooltip>
                    {conn.connection_type === 's3' && (
                      <Tooltip title="Refresh Credentials">
                        <IconButton size="small" onClick={() => handleRefreshCredentials(conn)} disabled={refreshing === conn.id}>
                          {refreshing === conn.id ? <CircularProgress size={16} /> : <RefreshIcon sx={{ fontSize: 18 }} />}
                        </IconButton>
                      </Tooltip>
                    )}
                    <Tooltip title="Edit">
                      <IconButton size="small" onClick={() => openEdit(conn)}>
                        <EditIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title={S3_BUCKET_TYPES.includes(conn.connection_type)
                      ? 'Clone is refused for an S3 connection — one bucket has one connection, '
                        + 'and a clone reads the same bucket. Register more tables on this connection instead.'
                      : 'Clone — copies credentials and registered tables into a new, unshared connection'}>
                      <span>
                        <IconButton
                          size="small"
                          onClick={() => handleClone(conn)}
                          disabled={cloning === String(conn.id)}
                          aria-label={`Clone ${conn.name}`}
                        >
                          {cloning === String(conn.id)
                            ? <CircularProgress size={16} />
                            : <CloneIcon sx={{ fontSize: 18 }} />}
                        </IconButton>
                      </span>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small" color="error" onClick={() => setDeleteTarget(conn)}>
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={filteredConnections.length}
            page={connPage}
            onPageChange={(_, p) => setConnPage(p)}
            rowsPerPage={connRowsPerPage}
            onRowsPerPageChange={e => setConnRowsPerPage(parseInt(e.target.value, 10))}
            rowsPerPageOptions={[10, 25, 50, 100]}
          />
        </TableContainer>
      )}

      {/* ── Create / Edit Dialog ── */}
      <SystemAccountsListable.Provider value={canListSystemAccounts}>
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth
        PaperProps={{ sx: { maxHeight: '90vh' } }}>
        <DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {React.cloneElement(CONN_TYPE_META[ct]?.icon || <StorageIcon />, { sx: { color: CONN_TYPE_META[ct]?.color || '#64748b' } })}
            <span>{editingId ? 'Edit Connection' : 'New Connection'}</span>
          </Box>
        </DialogTitle>

        <DialogContent dividers sx={{ overflowY: 'auto' }}>
          {formError && <Alert severity="error" sx={{ mb: 2 }}>{formError}</Alert>}
          {editingId && credentialProblems.length > 0 && (
            <Alert severity="warning" sx={{ mb: 2 }} data-testid="credential-problems">
              The saved {credentialProblems.map(f => f.replace(/_/g, ' ')).join(', ')} cannot be
              read on this server — the encryption key changed since it was saved. It is
              still stored, but the connection cannot use it: enter it again.
            </Alert>
          )}

          <Stack spacing={2} sx={{ mt: 0.5 }}>

            {/* Name + Sharing */}
            <TextField
              label="Connection Name" fullWidth required size="small"
              value={form.name}
              onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
              placeholder="e.g. Prod Starburst"
            />
            <FormControlLabel
              control={
                <Switch
                  size="small"
                  checked={form.is_shared || false}
                  onChange={e => setForm(prev => ({ ...prev, is_shared: e.target.checked }))}
                />
              }
              label={
                <Typography variant="body2" color="text.secondary">
                  Shared — visible to all users
                </Typography>
              }
            />

            {/* Type selector */}
            <TextField
              select label="Connection Type" fullWidth size="small"
              value={ct}
              onChange={e => handleTypeChange(e.target.value)}
            >
              <MenuItem value="s3">
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <CloudIcon fontSize="small" sx={{ color: '#f59e0b' }} /> AWS S3 Bucket
                </Box>
              </MenuItem>
              <MenuItem value="local">
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <FolderIcon fontSize="small" sx={{ color: '#6366f1' }} /> Local Folder
                </Box>
              </MenuItem>
              {uploadEnabled && (
                <MenuItem value="upload">
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <UploadIcon fontSize="small" sx={{ color: '#10b981' }} /> Upload Files
                  </Box>
                </MenuItem>
              )}
              <Divider />
              <MenuItem disabled sx={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, opacity: 0.6 }}>
                SQL Warehouses
              </MenuItem>
              {SQL_TYPES.map(t => (
                <MenuItem key={t} value={t}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    {CONN_TYPE_META[t]?.icon
                      ? React.cloneElement(CONN_TYPE_META[t].icon, { sx: { color: CONN_TYPE_META[t]?.color } })
                      : <SqlIcon fontSize="small" sx={{ color: CONN_TYPE_META[t]?.color }} />}
                    {CONN_TYPE_META[t]?.label}
                  </Box>
                </MenuItem>
              ))}
              <Divider />
              <MenuItem disabled sx={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, opacity: 0.6 }}>
                APIs
              </MenuItem>
              <MenuItem value="rest_api">
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <CloudIcon fontSize="small" sx={{ color: '#8b5cf6' }} />
                  REST API
                </Box>
              </MenuItem>
            </TextField>

            <Divider />

            {/* Config form per type */}
            {ct === 's3'        && <S3FormWithTables config={form.config} onChange={updateConfig} connectionId={editingId} isShared={form.is_shared} systemAccounts={systemAccounts} />}
            {ct === 'local'     && <LocalForm    config={form.config} onChange={updateConfig} />}
            {ct === 'upload'    && <UploadForm
              pendingFiles={pendingFiles}
              setPendingFiles={setPendingFiles}
              uploadedFiles={uploadedFiles}
              onDeleteUploaded={handleDeleteUploadedFile}
              connectionId={editingId}
            />}
            {(ct === 'trino' || ct === 'starburst')
                                && <TrinoForm    config={form.config} onChange={updateConfig} connType={ct} systemAccounts={systemAccounts} />}
            {ct === 'snowflake' && <SnowflakeForm config={form.config} onChange={updateConfig} systemAccounts={systemAccounts} />}
            {ct === 'databricks'&& <DatabricksForm config={form.config} onChange={updateConfig} systemAccounts={systemAccounts} />}
            {ct === 'oracle'    && <OracleForm     config={form.config} onChange={updateConfig} systemAccounts={systemAccounts} />}
            {ct === 'athena'    && <AthenaForm     config={form.config} onChange={updateConfig} systemAccounts={systemAccounts} />}
            {ct === 'rest_api'  && <RestApiForm    config={form.config} onChange={updateConfig} />}

          </Stack>

          {/* Test result.  When the backend returns a `diagnostic` field
              (multi-line [DIAG] block from s3_storage._diagnose_endpoint_failure)
              we surface it as a copy-friendly monospace block beneath the
              one-line message.  Without this, the diagnostic was reaching
              server logs only — operators clicking "Test Connection" had no
              way to see why the connection failed.
              endpoint_used is also surfaced as a small caption so the
              operator can confirm whether the test routed through their
              VPC endpoint or the standard AWS S3 endpoint. */}
          {testResult && (
            <Alert severity={testResult.success ? 'success' : 'error'} sx={{ mt: 2 }}>
              <Box>{testResult.message}</Box>
              {testResult.endpoint_used && (
                <Box sx={{ mt: 0.5, fontSize: 12, opacity: 0.85 }}>
                  Tested via endpoint: <code>{testResult.endpoint_used}</code>
                  {testResult.endpoint_used === 'standard AWS S3' && (
                    <Box component="span" sx={{ ml: 1, fontStyle: 'italic' }}>
                      (Custom Endpoint URL is blank — to route through a VPC
                      endpoint, fill in the "Custom Endpoint URL" field above
                      with your <code>vpce-…</code> URL.)
                    </Box>
                  )}
                </Box>
              )}
              {testResult.diagnostic && (
                <Box
                  component="pre"
                  sx={{
                    mt: 1, mb: 0, p: 1.5,
                    bgcolor: 'rgba(0,0,0,0.04)',
                    fontFamily: 'monospace', fontSize: 12,
                    whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                    maxHeight: 300, overflow: 'auto',
                    borderRadius: 1,
                  }}
                >
                  {testResult.diagnostic}
                </Box>
              )}
            </Alert>
          )}
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, gap: 1 }}>
          <Button
            variant="outlined"
            onClick={handleTestInDialog}
            disabled={testing === 'dialog'}
            startIcon={testing === 'dialog' ? <CircularProgress size={16} /> : <TestIcon />}
          >
            Test Connection
          </Button>
          <Box sx={{ flex: 1 }} />
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {uploadProgress || (saving ? 'Saving…' : (editingId ? 'Update' : 'Create'))}
          </Button>
        </DialogActions>
      </Dialog>
      </SystemAccountsListable.Provider>

      {/* ── Delete Confirmation ── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Delete Connection</DialogTitle>
        <DialogContent>
          <Typography>
            Delete <strong>{deleteTarget?.name}</strong>? Saved queries using this connection may stop working.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </DialogActions>
      </Dialog>

      {/* ── Snackbar for refresh credentials feedback ── */}
      <Snackbar open={snack.open} autoHideDuration={4000} onClose={() => setSnack(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
        <Alert severity={snack.severity} onClose={() => setSnack(s => ({ ...s, open: false }))} variant="filled" sx={{ width: '100%' }}>
          {snack.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ConnectionManager;
