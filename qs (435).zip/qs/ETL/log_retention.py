"""Log-file retention sweeper -- keep N most-recent files per prefix.

Motivation
----------
Every rerun of ``file_standalone.py`` / ``oracle_standalone.py`` builds
its own timestamped log file:

    file_flow_{dag}_{report}_{business_date}_{HHMMSS}.log
    oracle_standalone_{dag}_{report}_{business_date}_{HHMMSS}.log

Without cleanup, an operator who reruns the same workflow ten times on
the same day accumulates ten log files in the NFS log directory --
useful once, noise forever.  The user directive (2026-07-02):

    "so manay logs are getting created when we rerun keep only last 2
    run logs and delete old ones ... 1 log per run per workflow"

This module owns retention as ONE chokepoint that both standalones and
future workflows call at run-start.  The rule:

    keep the ``keep`` most-recent files matching ``{prefix}*.log`` in
    ``log_dir`` (by mtime); delete the rest.

Called from ``_build_log_file`` right BEFORE the new run's FileHandler
opens.  That means retention leaves ``keep - 1`` old files on disk;
the newly-created log makes the total exactly ``keep``.

Fail-open: retention is diagnostic, never critical.  Any OSError -- a
racing pod that already deleted the file, permission drift on NFS,
whatever -- is swallowed + logged so the run continues.

Contract
--------
* Only files with an exact ``.log`` suffix are ever deleted.
* Files not matching ``{prefix}*`` are IGNORED.  A stray unrelated log
  in the same directory (e.g. ``polling_service.log``) is safe.
* Directories are never touched.
* ``keep`` >= 1.  ``keep=0`` would delete the freshly-created log and
  is treated as a bug -- raises ValueError so tests catch it.
"""
from __future__ import annotations

import logging
import os
import re
from typing import List, Optional


# Tail shape of every ETL run-log filename produced by _build_log_file
# in all seven standalones + polling dispatcher:
#
#   {prefix}{business_date}_{HHMMSS}.log
#
# The business_date segment holds digits + dashes only (never
# underscores) because `_build_log_file` normalises whitespace to
# ``-`` before it lands in the filename.  Timestamp is exactly 6 digits.
#
# Requiring the tail to match this regex prevents a subtle prefix
# collision:  prune with prefix ``file_flow_MY_1_`` would otherwise
# ALSO sweep ``file_flow_MY_1_42_2026-07-02_120000.log`` (a different
# (dag=MY_1, report=42) tuple whose files happen to share the shorter
# tuple's prefix as a string prefix).  With the tail regex the sibling
# tuple's ``42_2026-...`` tail fails to match and is left alone.
_TAIL_RE = re.compile(r"^[\d\-]+_\d{6}\.log$")


def prune_old_logs(
    log_dir: str,
    prefix: str,
    keep: int = 2,
    logger: Optional[logging.Logger] = None,
) -> List[str]:
    """Delete all but the ``keep`` most-recent ``{prefix}*.log`` files in
    ``log_dir``.

    Parameters
    ----------
    log_dir
        Directory to scan.  Missing or non-directory: no-op, returns [].
    prefix
        Filename prefix to match.  Only files whose basename starts with
        this exact string AND ends with ``.log`` are considered.
    keep
        Number of most-recent (by mtime) files to preserve.  When
        creating a new log immediately after this call, pass 2 to end
        up with (new + 1 previous) = 2 files total.
    logger
        Optional logger for diagnostics.  When None, prints nothing.

    Returns
    -------
    List of absolute paths deleted (empty when nothing was deleted).

    Raises
    ------
    ValueError
        When ``keep < 1``.  ``keep=0`` would delete the very log file
        the caller is about to create -- always a bug.
    """
    if keep < 1:
        raise ValueError(f"prune_old_logs: keep must be >= 1 (got {keep})")
    if not log_dir or not os.path.isdir(log_dir):
        return []
    if not prefix:
        # Empty prefix would match every .log in the dir -- refuse to
        # sweep the whole log directory unconditionally.
        return []

    try:
        entries = os.listdir(log_dir)
    except OSError as exc:
        if logger is not None:
            logger.warning("prune_old_logs: cannot list %s (%s)", log_dir, exc)
        return []

    candidates: List[tuple] = []
    for name in entries:
        if not name.startswith(prefix):
            continue
        if not name.endswith(".log"):
            continue
        # Shape-check the segment AFTER the prefix so a shorter
        # (dag, report) prefix doesn't sweep a longer sibling tuple's
        # files.  See _TAIL_RE docstring above for the collision
        # scenario this closes.
        tail = name[len(prefix):]
        if not _TAIL_RE.match(tail):
            continue
        path = os.path.join(log_dir, name)
        try:
            st = os.stat(path)
        except OSError:
            continue
        # Skip directories that happen to match by name.
        if not os.path.isfile(path):
            continue
        candidates.append((st.st_mtime, path))

    # Newest first.  ``keep`` most-recent are preserved.
    candidates.sort(key=lambda t: t[0], reverse=True)
    to_delete = [p for _, p in candidates[keep:]]

    deleted: List[str] = []
    for path in to_delete:
        try:
            os.remove(path)
            deleted.append(path)
        except OSError as exc:
            if logger is not None:
                logger.warning(
                    "prune_old_logs: cannot delete %s (%s)", path, exc,
                )
    if deleted and logger is not None:
        logger.info(
            "prune_old_logs: kept %d most-recent %s*.log in %s, "
            "deleted %d older", keep, prefix, log_dir, len(deleted),
        )
    return deleted
