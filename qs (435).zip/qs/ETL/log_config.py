"""ETL runtime-path resolution — one source of truth across the codebase.

Two resolvers live here:

  * ``get_log_dir()``  — where logs are written.
  * ``get_data_root()`` — where pipeline data (group_history.json,
    output_dir defaults, …) lives.

Both use the same priority chain:
  1. Env var override  (``ETL_LOG_DIR`` / ``ETL_DATA_ROOT``).  Highest
     priority so an operator can force a path without touching config.
  2. YAML config value at ``$ETL_LOG_CONFIG_PATH`` or, when that env
     var is unset, ``ETL/config/polling_service_config.yaml`` next to
     this module (``logging.dir`` / ``data.root``).
  3. Platform-aware default:
       * POSIX  → the existing PVC mount path (``/usr/local/spark/nfs/...``)
                  — every K8s pod has this mounted, so prod is untouched.
       * Windows → ``ETL/_runtime/...`` next to this module.  Lets
                   local dev runs work with zero env / config setup.

Results are cached process-wide so a tick that spans the standalone +
manager + steps writes all logs / data to the same directory.

Tests call ``reset_for_tests()`` to clear the cache between cases.
"""
from __future__ import annotations
import os
from typing import Optional


_HERE = os.path.dirname(os.path.abspath(__file__))
_POSIX_LOG_PATH = "/usr/local/spark/nfs/bcp/batch/logs"
_POSIX_DATA_ROOT = "/usr/local/spark/nfs/bcp/batch"
_WIN_LOG_PATH = os.path.join(_HERE, "_runtime", "logs")
_WIN_DATA_ROOT = os.path.join(_HERE, "_runtime")

_RESOLVED_LOG: Optional[str] = None
_RESOLVED_DATA: Optional[str] = None


def _platform_default_log_dir() -> str:
    return _WIN_LOG_PATH if os.name == "nt" else _POSIX_LOG_PATH


def _platform_default_data_root() -> str:
    return _WIN_DATA_ROOT if os.name == "nt" else _POSIX_DATA_ROOT


def _read_yaml_key(env_key: str, *path: str) -> Optional[str]:
    """Read a nested key from polling_service_config.yaml (or the file
    pointed at by ``ETL_LOG_CONFIG_PATH``)."""
    cfg_path = os.environ.get("ETL_LOG_CONFIG_PATH", "").strip()
    if not cfg_path:
        cfg_path = os.path.join(_HERE, "config", "polling_service_config.yaml")
    if not os.path.exists(cfg_path):
        return None
    try:
        import yaml
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except Exception:
        return None
    node = cfg
    for key in path:
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    if isinstance(node, str) and node.strip():
        return node.strip()
    return None


def get_log_dir() -> str:
    """Return the resolved ETL log directory; cache result process-wide."""
    global _RESOLVED_LOG
    if _RESOLVED_LOG is not None:
        return _RESOLVED_LOG

    env = os.environ.get("ETL_LOG_DIR", "").strip()
    if env:
        _RESOLVED_LOG = env
        return _RESOLVED_LOG

    yaml_val = _read_yaml_key("ETL_LOG_DIR", "logging", "dir")
    # Skip the legacy POSIX placeholder so Windows runs don't try to
    # create ``/usr/local/...``; an operator who genuinely wants a
    # POSIX path on Windows can still force it via the env var.
    if yaml_val and yaml_val != _POSIX_LOG_PATH:
        _RESOLVED_LOG = yaml_val
        return _RESOLVED_LOG

    _RESOLVED_LOG = _platform_default_log_dir()
    return _RESOLVED_LOG


def get_data_root() -> str:
    """Return the resolved ETL data root; cache result process-wide.

    Used by steps that need a deployment-aware base directory for
    pipeline state (e.g. ``group_history.json``).  Falls back to the
    POSIX PVC mount on Linux and a repo-relative ``_runtime/`` dir on
    Windows.
    """
    global _RESOLVED_DATA
    if _RESOLVED_DATA is not None:
        return _RESOLVED_DATA

    env = os.environ.get("ETL_DATA_ROOT", "").strip()
    if env:
        _RESOLVED_DATA = env
        return _RESOLVED_DATA

    yaml_val = _read_yaml_key("ETL_DATA_ROOT", "data", "root")
    if yaml_val and yaml_val != _POSIX_DATA_ROOT:
        _RESOLVED_DATA = yaml_val
        return _RESOLVED_DATA

    _RESOLVED_DATA = _platform_default_data_root()
    return _RESOLVED_DATA


def reset_for_tests() -> None:
    """Clear the caches so the next ``get_*`` call re-resolves.

    Only call from tests — production code should rely on the cache.
    """
    global _RESOLVED_LOG, _RESOLVED_DATA, _RUN_LOG_FILE
    global _MODULE_RUN_LOG_FILE, _MODULE_WORKFLOW_NAME
    _RESOLVED_LOG = None
    _RESOLVED_DATA = None
    _RUN_LOG_FILE = None
    _MODULE_RUN_LOG_FILE = None
    _MODULE_WORKFLOW_NAME = None
    # ContextVar can only be reset via the token pattern; safest way
    # to isolate tests is to open a fresh Context via ``Context.run``.
    # For test convenience, clear the CV to the sentinel default here.
    try:
        _RUN_LOG_FILE_CV.set(None)
    except LookupError:
        pass
    try:
        _WORKFLOW_NAME_CV.set(None)
    except LookupError:
        pass


# ──────────────────────────────────────────────────────────────────────
#  Single-file-per-execution logging
# ──────────────────────────────────────────────────────────────────────

import logging as _logging
from contextvars import ContextVar as _ContextVar
from datetime import datetime as _datetime


# 2026-07-02 -- ContextVar (not module global) so the polling
# dispatcher, which fires multiple asyncio-concurrent workflow runs
# inside ONE pod, keeps a distinct log-file pin per task.
#
# Prior implementation used a bare module var.  Under
# ``asyncio.gather(_execute_run(dagA), _execute_run(dagB))`` the last
# ``set_run_log_file`` wrote-over the first, and any step falling
# through to ``get_run_log_file()`` (subprocess handoff, legacy call
# site) landed in the OTHER concurrent run's log file.
#
# ContextVar isolates the value per asyncio Task (and per thread) so
# each concurrent run sees its own pin.  Module-global fallback kept
# for pre-context callers via ``_MODULE_RUN_LOG_FILE``.
_RUN_LOG_FILE_CV: "_ContextVar[Optional[str]]" = _ContextVar(
    "etl_run_log_file", default=None,
)
# Retained for pre-2026-07-02 callers that read the module attribute
# directly (unit tests + one-off tools).  ContextVar wins when both
# are set.
_MODULE_RUN_LOG_FILE: Optional[str] = None
# Kept as a module attribute for backward-compat with tests that
# monkey-patch or read ``log_config._RUN_LOG_FILE`` directly.
_RUN_LOG_FILE: Optional[str] = None


def set_run_log_file(path: str) -> None:
    """Pin the log file path for this run.

    Sets BOTH the ContextVar (isolates per asyncio task) and the
    module attribute (back-compat).  Passing an empty string clears.

    Call from every standalone / dispatcher immediately after
    ``_build_log_file`` so every module that later consults
    ``get_run_log_file()`` / ``attach_step_logger`` writes to the
    SAME file.
    """
    global _MODULE_RUN_LOG_FILE, _RUN_LOG_FILE
    val = path or None
    try:
        _RUN_LOG_FILE_CV.set(val)
    except LookupError:
        pass
    _MODULE_RUN_LOG_FILE = val
    _RUN_LOG_FILE = val  # legacy attribute mirror


def get_run_log_file() -> Optional[str]:
    """Return the pinned run-log-file path, or None when unpinned.

    ContextVar wins when set; otherwise fall through to the module
    attribute.
    """
    try:
        cv_val = _RUN_LOG_FILE_CV.get()
    except LookupError:
        cv_val = None
    return cv_val if cv_val is not None else _MODULE_RUN_LOG_FILE


# 2026-07-02 -- workflow-name is ALSO ContextVar-scoped for the same
# concurrent-runs-in-one-pod reason, and to avoid polluting
# ``os.environ`` (which leaks into any Popen child on POSIX).
_WORKFLOW_NAME_CV: "_ContextVar[Optional[str]]" = _ContextVar(
    "etl_workflow_name", default=None,
)
_MODULE_WORKFLOW_NAME: Optional[str] = None


def set_workflow_name(name: str) -> None:
    """Publish the current workflow name for downstream step fallback
    filenames.  ContextVar-scoped -- concurrent workflow runs in the
    same pod stay isolated.

    Passing an empty string clears.
    """
    global _MODULE_WORKFLOW_NAME
    val = name or None
    try:
        _WORKFLOW_NAME_CV.set(val)
    except LookupError:
        pass
    _MODULE_WORKFLOW_NAME = val


def get_workflow_name(default: Optional[str] = None) -> Optional[str]:
    """Return the current workflow name.  ContextVar > module var >
    ``os.environ['ETL_WORKFLOW_NAME']`` (back-compat) > default."""
    try:
        cv_val = _WORKFLOW_NAME_CV.get()
    except LookupError:
        cv_val = None
    if cv_val:
        return cv_val
    if _MODULE_WORKFLOW_NAME:
        return _MODULE_WORKFLOW_NAME
    env_val = os.environ.get("ETL_WORKFLOW_NAME")
    if env_val:
        return env_val
    return default


def build_module_logger(name: str, file_stem: str) -> "_logging.Logger":
    """Build a stdlib logger.

    Output file selection:
      * If ``set_run_log_file(path)`` was called → write to that path.
      * Otherwise → ``<log_dir>/<file_stem>_YYYY-MM-DD.log``.

    Windows-safe by design — uses ``logging.FileHandler`` (no rotation,
    no rename).  CentralizedLogger from core_libs (rotating handler) is
    NOT used because Windows refuses to rename an open file, so
    ``doRollover`` fails with ``PermissionError [WinError 32]``.

    On POSIX, stdlib FileHandler is still fine — pods are short-lived
    enough that no-rotation works.  If long-running rotation is needed
    on POSIX, route logs through a sidecar / fluentd / loki collector.

    Use this instead of hand-rolling logger setup in every module so
    all loggers honour the same path-resolution chain
    (``ETL_LOG_DIR`` → YAML → platform default) AND the single-file
    pin.
    """
    log_path = _RUN_LOG_FILE or os.path.join(
        get_log_dir(),
        f"{file_stem}_{_datetime.now().strftime('%Y-%m-%d')}.log",
    )

    logger = _logging.getLogger(name)
    if logger.handlers:
        # Already configured (e.g. by an earlier call in the same
        # process).  Return as-is so we don't duplicate handlers.
        return logger

    logger.setLevel(_logging.INFO)
    fmt = _logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
    )

    sh = _logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    try:
        os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
        fh = _logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError as exc:
        logger.warning(
            "build_module_logger(%s): could not open %s (%s) — "
            "console-only", name, log_path, exc,
        )

    return logger


# ──────────────────────────────────────────────────────────────────────
#  Step-side single-chokepoint logger attach
# ──────────────────────────────────────────────────────────────────────
#
# Every ETL step (file + oracle) used to hand-roll ``_setup_logging``:
#   * grab ``task['log_file']`` (set by the standalone),
#   * if missing, build ``file_flow_{LOG_PREFIX}_{run_id}_{date}.log``.
#
# When ``task['log_file']`` was missing (unit tests, direct step
# invocation, subprocess handoff) the LOG_PREFIX-per-step fallback
# produced ONE log file per STEP -- fanned out across the whole run.
# Operator report 2026-07-02: "in starburst_to_file creating logs for
# each steps that doesn't make sense ... 1 log per run per workflow".
#
# ``attach_step_logger`` is the single chokepoint every step MUST call
# so:
#   1. All steps in a run pin to task['log_file'] when set (unchanged).
#   2. Missing task['log_file'] falls back to the process-level pin
#      (``get_run_log_file()``) -- the standalone still pinned it via
#      ``set_run_log_file()`` at run start.
#   3. Final fallback drops LOG_PREFIX from the filename so all steps
#      still share ONE file: ``file_flow_run_{run_id}_{date}.log``.


def attach_step_logger(
    logger_name: str,
    task: "dict",
    workflow: str = "file_flow",
) -> "_logging.Logger":
    """Return a stdlib logger for a step, pinned to the RUN-shared file.

    Parameters
    ----------
    logger_name
        Fully qualified logger name (e.g. ``"file_flow.check_dependencies"``).
        Multiple ``attach_step_logger`` calls with the same name are
        idempotent -- handlers are configured exactly once.
    task
        The step's task dict.  ``task['log_file']`` is the primary
        source of truth for the file path.
    workflow
        Prefix used in the FINAL fallback filename when both
        ``task['log_file']`` and the process-pin are missing.  Callers
        outside the file pipeline pass ``"oracle_standalone"`` etc. so
        the fallback stays workflow-scoped.

    Returns
    -------
    A configured ``logging.Logger`` with a StreamHandler + FileHandler
    (or StreamHandler only when the file path can't be opened).

    File path resolution priority:

    1. ``task['log_file']`` (set by the standalone at run start).
    2. ``get_run_log_file()`` (process-level pin -- also set by the
       standalone via ``set_run_log_file(path)``).
    3. ``get_log_dir() / {workflow}_run_{run_id}_{date}.log`` -- shared
       across every step in the run.  Never contains a step's
       LOG_PREFIX, so a fallback path can't fan out into per-step files.
    """
    logger = _logging.getLogger(logger_name)
    # Idempotency: skip re-configuring only when we already have BOTH a
    # StreamHandler and a FileHandler.  A previous call that added the
    # StreamHandler but hit OSError on the FileHandler (transient FS
    # error) would otherwise leave us permanently console-only; retry
    # attaches the missing FileHandler.
    _has_stream = any(
        isinstance(h, _logging.StreamHandler)
        and not isinstance(h, _logging.FileHandler)
        for h in logger.handlers
    )
    # Match FileHandler by the resolved target path -- an existing
    # handler pointing at a DIFFERENT file (mid-flight relocation, or
    # a stale handler from a previous run in the same process) must
    # not fool the idempotency check.  We resolve the target path
    # below; short-circuit only when at least one FileHandler is
    # already writing to it.
    _existing_file_paths = [
        os.path.abspath(h.baseFilename)
        for h in logger.handlers
        if isinstance(h, _logging.FileHandler)
    ]
    _has_file = bool(_existing_file_paths)
    logger.setLevel(_logging.INFO)
    fmt = _logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
    )

    import sys as _sys
    if not _has_stream:
        sh = _logging.StreamHandler(_sys.stdout)
        sh.setFormatter(fmt)
        logger.addHandler(sh)

    log_path = task.get("log_file") if isinstance(task, dict) else None
    if not log_path:
        # Read via the accessor so the ContextVar view wins over the
        # module attribute in concurrent-run situations.
        log_path = get_run_log_file()
    if not log_path:
        try:
            base = get_log_dir()
        except Exception:
            base = ""
        # Explicit ``is not None`` check so a literal run_id of 0
        # (integer, valid Oracle SEQ value) is preserved -- the
        # previous ``or`` chain silently promoted it to "unknown".
        run_id: object = "unknown"
        if isinstance(task, dict):
            _r = task.get("run_id")
            if _r is None:
                _r = task.get("run_detail_id")
            if _r is not None:
                run_id = _r
        date_str = _datetime.now().strftime("%Y-%m-%d")
        # 2026-07-02 -- workflow selection priority (from caller):
        # explicit ``workflow=`` arg > ``get_workflow_name()`` (which
        # itself checks ContextVar > module var > ``os.environ``) >
        # the "file_flow" default from the parameter signature.  This
        # lets the polling dispatcher concurrent-run different
        # workflows without env-var last-writer-wins.
        _workflow = workflow
        if _workflow == "file_flow":  # default -- prefer explicit publish
            _resolved = get_workflow_name()
            if _resolved:
                _workflow = _resolved
        # NO LOG_PREFIX in the fallback filename -- all steps in the
        # run share one file even on the fallback path.
        log_path = os.path.join(base, f"{_workflow}_run_{run_id}_{date_str}.log")

    # Only attach a new FileHandler if none is already pointed at the
    # resolved log_path (baseFilename compare, not the type check).
    _target_abs = os.path.abspath(log_path)
    if _target_abs not in _existing_file_paths:
        try:
            os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
            fh = _logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            logger.addHandler(fh)
        except OSError as exc:
            logger.warning(
                "attach_step_logger(%s): cannot open %s (%s) -- console only",
                logger_name, log_path, exc,
            )
    return logger
