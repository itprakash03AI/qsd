/**
 * canvasDrill -- drill-down in three places, from CONFIGURATION (2026-11-01).
 *
 * The owner: "show drill down report too"; FD-09.  The drill path is a
 * HIERARCHY declared on the canvas (`canvas.hierarchies: [{name, levels:
 * [column ids]}]`) plus the APPROVED attributes a viewer may add
 * (`canvas.drill_columns: [column ids]`), authored on the Design tab; never
 * code.  Every level is a cube drill over the ONE stored, row-secured result
 * under the run's parameters, so a level's numbers are the same sums the
 * source gives.
 *
 *  - On a CHART / table tile whose first field is the first level of a
 *    hierarchy: a click on a bar / slice / row goes ONE LEVEL DOWN (the
 *    category becomes the next level, the clicked value a slicer); a
 *    breadcrumb (All › Credit › FI Credit) goes back up; at the lowest level
 *    the click opens the tile's detail popup when the author placed one,
 *    else the tile says so.  A tile under NO hierarchy keeps today's
 *    cross-filter click (canvasLinks).  The drill is this VIEWER's session
 *    state -- nothing is saved, nothing is sent but the cube's own slicers.
 *  - In the FINANCE GRID (the outline): "Drill into…" adds an approved
 *    attribute as the next level for this session (CanvasOutlineTile reads
 *    `useCanvasDrill().drill_columns`).
 */
import React, { createContext, useContext, useMemo, useState } from 'react';
import { Box, Button, Chip, Menu, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { CanvasColumn, CanvasTile, DrillConfig, Hierarchy, MAX_HIERARCHY_NAME, ReportCanvas, hierarchyFor } from './canvasModel';
import CanvasTileView, { CubeFetch, TileRunInfo } from './CanvasTileView';
import api from '../../../services/api';
import CompareTile, { useCanvasCompare } from './canvasCompare';
import { CanvasBandContext } from './CanvasOutlineTile';
import { PERIOD_OPTIONS } from '../ReportParamControl';

export { readDrill, drillProblems, hierarchyFor, MAX_HIERARCHY_NAME, MAX_LEVELS } from './canvasModel';
export type { Hierarchy, DrillConfig } from './canvasModel';

export const CanvasDrillContext = createContext<DrillConfig | null>(null);
export function useCanvasDrill(): DrillConfig {
  return useContext(CanvasDrillContext) ?? {};
}

export interface DrillStep { column_id: number; value: any }

/** A tile that drills along its hierarchy; a tile with none is the plain tile. */
export function DrillableTile(props: {
  tile: CanvasTile; reportId: number | null; cols: Map<number, CanvasColumn>; grouped: boolean; run: TileRunInfo;
  reportTable?: React.ReactNode; width: number; height: number; cubeFetch?: CubeFetch; staleFields?: string[];
  /** the builder: a comparison not yet runnable is a muted hint, never a warning on every tile */
  editable?: boolean;
}) {
  const { tile, cols, cubeFetch } = props;
  const drill = useCanvasDrill();
  const hier = hierarchyFor(drill, tile);
  // the COB comparison (canvasCompare.tsx): a number / table tile with values shows A, B, Variance, %
  const cmp = useCanvasCompare();
  // the finance grid (outline) under a comparison: its opened levels as a table of A / B / Variance / %
  // a number tile that compares with ANOTHER VALUE (its KPI card, canvasKpi.ts) keeps its own comparison
  const compared = cmp && !('error' in cmp) && (tile.kind === 'number' || tile.kind === 'table' || tile.kind === 'outline') && tile.measures.length > 0
    && !(tile.kind === 'number' && tile.compare?.kind === 'measure');
  // 2026-11-01 (FD-08): a trend tile says the period it follows, from the page's parameter values
  const band = useContext(CanvasBandContext);
  const trendWords = (() => {
    if (!tile.trend_of) return '';
    const v = band?.parameters?.find(p => p.name === tile.trend_of)?.value;
    const o = PERIOD_OPTIONS.find(x => x.value === String(v || '').toLowerCase());
    return o ? `Trend: ${o.help}` : 'Trend: the dates as chosen';
  })();
  const [path, setPath] = useState<DrillStep[]>([]);
  const [bottomNote, setBottomNote] = useState('');
  const depth = Math.min(path.length, (hier?.levels.length ?? 1) - 1);
  const shownTile = useMemo<CanvasTile>(() => (hier && path.length
    ? { ...tile, dimensions: [hier.levels[depth]], title: tile.title || '' } : tile), [tile, hier, path.length, depth]);
  const atBottom = !!hier && depth === hier.levels.length - 1;
  // the drilled path narrows every cube read of this tile (the cube's own slicers)
  const drilledFetch = useMemo<CubeFetch | undefined>(() => {
    if (!hier || !path.length) return cubeFetch;
    const base: CubeFetch = cubeFetch ?? ((r, e, b) => ((api as any).queryReportCubeFast ?? api.queryReportCube)(r, e, b));
    const extra: Record<string, any[]> = {};
    for (const s of path) {
      const name = cols.get(s.column_id)?.physical_name;
      if (name) extra[name] = [s.value];
    }
    return (r, e, b) => base(r, e, { ...b, slicers: { ...(b?.slicers || {}), ...extra } });
  }, [hier, path, cubeFetch, cols]);
  // (rig 2026-11-02) under a two-dates comparison the run stores BOTH dates (column IN (A, B));
  // a tile that does not compare (a pie, a plain bar) reads the AS-OF date B -- it added A and B
  // together.  A comparison tile / an overlay reads its own sides; a slicer of its own wins.
  const cmpCol = cmp && !('error' in cmp) ? cols.get(cmp.column_id)?.physical_name : undefined;
  const asOfFetch = useMemo<CubeFetch | undefined>(() => {
    if (!cmpCol || !cmp || 'error' in cmp || tile.compare_overlay) return drilledFetch;
    const base: CubeFetch = drilledFetch ?? ((r, e, b) => ((api as any).queryReportCubeFast ?? api.queryReportCube)(r, e, b));
    return (r, e, b) => base(r, e, { ...b, slicers: { [cmpCol]: [cmp.b], ...(b?.slicers || {}) } });
  }, [cmpCol, cmp, tile.compare_overlay, drilledFetch]);
  if (compared) {
    const asTable = tile.kind === 'outline'
      ? { ...tile, kind: 'table' as const, dimensions: (tile.levels ?? []).slice(0, Math.max(1, tile.open_level ?? 1)) } : tile;
    return <CompareTile tile={asTable} reportId={props.reportId} cols={cols} grouped={props.grouped} run={props.run} cubeFetch={cubeFetch} setting={cmp as any} width={props.width} height={props.height} />;
  }
  if (trendWords && !hier) {
    return <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Typography variant="caption" color="text.secondary" data-testid="trend-words">{trendWords}</Typography>
      <Box sx={{ flex: 1, minHeight: 0 }}><CanvasTileView {...props} cubeFetch={asOfFetch} height={Math.max(60, props.height - 20)} /></Box>
    </Box>;
  }
  if (cmp && 'error' in cmp && (tile.kind === 'number' || tile.kind === 'table') && tile.measures.length > 0) {
    return <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {props.editable
        ? <Typography variant="caption" color="text.disabled" data-testid="compare-hint">Compares two dates when the report runs.</Typography>
        : <Typography variant="caption" color="warning.main" data-testid="compare-error">{cmp.error}</Typography>}
      <Box sx={{ flex: 1, minHeight: 0 }}><CanvasTileView {...props} height={Math.max(60, props.height - 20)} /></Box>
    </Box>;
  }
  if (!hier) return <CanvasTileView {...props} cubeFetch={asOfFetch} />;
  const onPick = (value: any) => {
    setBottomNote('');
    if (atBottom) return false;        // the tile opens its popup action instead (CanvasTileView)
    setPath(p => [...p, { column_id: hier.levels[p.length], value }]);
    return true;
  };
  const levelLabel = cols.get(hier.levels[depth])?.label ?? '';
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }} data-testid={`drill-tile-${tile.id}`}>
      <Stack direction="row" spacing={0.5} alignItems="center" flexWrap="wrap" sx={{ mb: 0.5 }} data-testid="drill-crumbs">
        <Chip size="small" label="All" variant={path.length ? 'outlined' : 'filled'} onClick={() => { setPath([]); setBottomNote(''); }} data-testid="drill-crumb-all" />
        {path.map((s, i) => (
          <React.Fragment key={i}>
            <Typography variant="caption" color="text.secondary">›</Typography>
            <Chip size="small" label={`${cols.get(s.column_id)?.label ?? ''}: ${s.value == null ? '(no value)' : String(s.value)}`}
              variant={i === path.length - 1 ? 'filled' : 'outlined'} onClick={() => setPath(p => p.slice(0, i + 1))} data-testid={`drill-crumb-${i}`} />
          </React.Fragment>
        ))}
        <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }} data-testid="drill-level">
          {atBottom ? `${levelLabel} -- the lowest level` : `By ${levelLabel} -- click one to drill into ${cols.get(hier.levels[depth + 1])?.label ?? ''}`}
        </Typography>
      </Stack>
      {bottomNote && <Typography variant="caption" color="warning.main" data-testid="drill-bottom-note">{bottomNote}</Typography>}
      <Box sx={{ flex: 1, minHeight: 0 }}>
        <CanvasTileView {...props} tile={shownTile} cubeFetch={asOfFetch} height={Math.max(60, props.height - 34)}
          drill={{ onPick, atBottom, onNoAction: () => setBottomNote('This is the lowest level. Add a detail popup on the Actions tab to open the rows behind a value.') }} />
      </Box>
    </Box>
  );
}

// ── the builder's settings (canvas-level) ──────────────────────────────────

export function DrillSettings({ canvas, columns, onChange }: {
  canvas: ReportCanvas; columns: CanvasColumn[]; onChange: (f: (c: ReportCanvas) => ReportCanvas) => void;
}) {
  const hs = canvas.hierarchies ?? [];
  const approved = canvas.drill_columns ?? [];
  const [anchor, setAnchor] = useState<{ el: HTMLElement; which: number | 'approved' } | null>(null);
  const label = (id: number) => columns.find(c => c.id === id)?.label ?? `#${id}`;
  const setH = (i: number, f: (h: Hierarchy) => Hierarchy) => onChange(c => ({ ...c, hierarchies: (c.hierarchies ?? []).map((h, j) => (j === i ? f(h) : h)) }));
  return (
    <Box data-testid="drill-settings">
      <Typography variant="subtitle2">Drill-down</Typography>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 0.5 }}>
        A drill path: a click on a chart goes one level down it; the finance grid opens along it. Approved fields: what a viewer may add to the grid.
      </Typography>
      {hs.map((h, i) => (
        <Box key={i} sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 1, mb: 1 }} data-testid={`drill-path-${i}`}>
          <TextField size="small" label="Drill path name" value={h.name} onChange={e => setH(i, x => ({ ...x, name: e.target.value }))}
            inputProps={{ 'data-testid': `drill-path-name-${i}`, maxLength: MAX_HIERARCHY_NAME }} fullWidth />
          <Stack direction="row" spacing={0.5} flexWrap="wrap" sx={{ mt: 1 }}>
            {h.levels.map((id, k) => (
              <Chip key={id} size="small" label={`${k + 1}. ${label(id)}`} onDelete={() => setH(i, x => ({ ...x, levels: x.levels.filter(l => l !== id) }))} data-testid={`drill-level-${i}-${k}`} />
            ))}
            <Button size="small" onClick={e => setAnchor({ el: e.currentTarget, which: i })} data-testid={`drill-add-level-${i}`}>+ level</Button>
          </Stack>
          <Button size="small" color="error" sx={{ mt: 0.5 }} onClick={() => onChange(c => ({ ...c, hierarchies: (c.hierarchies ?? []).filter((_, j) => j !== i) }))}>Remove this drill path</Button>
        </Box>
      ))}
      <Button size="small" variant="outlined" onClick={() => onChange(c => ({ ...c, hierarchies: [...(c.hierarchies ?? []), { name: `Drill path ${hs.length + 1}`, levels: [] }] }))} data-testid="drill-add-path">+ Drill path</Button>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}>Approved fields a viewer may add to the grid</Typography>
      <Stack direction="row" spacing={0.5} flexWrap="wrap">
        {approved.map(id => <Chip key={id} size="small" label={label(id)} onDelete={() => onChange(c => ({ ...c, drill_columns: (c.drill_columns ?? []).filter(x => x !== id) }))} data-testid={`drill-approved-${id}`} />)}
        <Button size="small" onClick={e => setAnchor({ el: e.currentTarget, which: 'approved' })} data-testid="drill-add-approved">+ field</Button>
      </Stack>
      <Menu open={!!anchor} anchorEl={anchor?.el} onClose={() => setAnchor(null)}>
        {columns.filter(c => (anchor?.which === 'approved' ? !approved.includes(c.id) : !(hs[anchor?.which as number]?.levels ?? []).includes(c.id))).map(c => (
          <MenuItem key={c.id} data-testid={`drill-pick-${c.id}`} onClick={() => {
            if (anchor?.which === 'approved') onChange(cv => ({ ...cv, drill_columns: [...(cv.drill_columns ?? []), c.id] }));
            else setH(anchor!.which as number, x => ({ ...x, levels: [...x.levels, c.id] }));
            setAnchor(null);
          }}>{c.label}</MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
