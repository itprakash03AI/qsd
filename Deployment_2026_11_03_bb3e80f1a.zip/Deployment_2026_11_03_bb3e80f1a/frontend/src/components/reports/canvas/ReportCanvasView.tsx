/**
 * The report canvas on a 12-column grid (2026-10-26) -- the viewer's
 * read-only page and the builder's editable one are the SAME component, so a
 * report looks the same while it is built and when it is read.
 *
 * Uses react-grid-layout (already the dashboards' grid, v2 API).  Editable:
 * tiles drag by their header, resize from the corner, a click selects one,
 * and a field dragged from the builder's field list drops onto a tile (adds
 * it) or onto the empty canvas (a new tile).  On a narrow screen the tiles
 * stack in reading order, full width.
 */
import React, { useState } from 'react';
import { Box, Button, Chip, Paper, Tab, Tabs, TextField, Typography, useMediaQuery, useTheme } from '@mui/material';
import GridLayout, { useContainerWidth } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import CanvasTileView, { CubeFetch, TileRunInfo } from './CanvasTileView';
import DrawWhenSeen from './canvasRender/DrawWhenSeen';
import { CanvasColumn, CanvasPage, CanvasTile, GRID_COLS, isTableOnlyCanvas, MAX_PAGES, pagesOf, ReportCanvas, TileLayout } from './canvasModel';
import { CanvasLinkStore, CanvasLinksProvider, CanvasLinkTileScope, linksEnabled } from './canvasLinks';
import CanvasLinkChips from './CanvasLinkChips';
import { appColour, cssColour, useCanvasTheme } from './canvasTheme';
import { CanvasDrillContext, DrillableTile } from './canvasDrill';
import { FieldsMenu } from './viewerLayout';
import { KpiIndexContext, kpiOrder } from './canvasKpi';

export const ROW_HEIGHT = 56;
const MARGIN = 10;
export const FIELD_MIME = 'application/x-qs-canvas-field';


interface Props {
  canvas: ReportCanvas;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  grouped: boolean;
  run: TileRunInfo;
  reportTable?: React.ReactNode;
  editable?: boolean;
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  onLayout?: (layouts: Record<string, TileLayout>) => void;
  /** a field dropped on a tile (tileId) or on the empty canvas (null) */
  onDropField?: (columnId: number, tileId: string | null) => void;
  /** problems by tile id -- shown on the tile in the builder */
  problems?: Record<string, string[]>;
  /** a share link / embed reads its tiles through its own route */
  cubeFetch?: CubeFetch;
  /** the builder: per tile, the fields the shown preview ran without */
  staleFields?: Record<string, string[]>;
  /** linked tiles (canvasLinks.ts): the page's store, when it needs the links (its exports) */
  linkStore?: CanvasLinkStore;
  /** 2026-11-01 (FD-03 / FD-10): a VIEWER may move / resize the tiles and pick their fields */
  rearrange?: boolean;
  /** 2026-11-02 PAGES -- the builder's page controls (add / rename / remove); the viewer only switches */
  onPagesChange?: (pages: CanvasPage[] | undefined) => void;
  onPickFields?: (tileId: string, f: { dimensions?: number[]; series?: number | null; levels?: number[] }) => void;
}

/** The canvas with its linked tiles: a click on one tile filters the others
 *  (off while the canvas is being built -- a click there selects the tile).
 *
 *  2026-10-30 -- every report is a canvas: a canvas of the report's own table
 *  and nothing else (a report with no canvas stored opens as one, derived)
 *  is the table itself, full width, with no tile frame -- it looks exactly as
 *  a report always did, every feature of the table kept. */
export default function ReportCanvasView(props: Props) {
  if (!props.editable && isTableOnlyCanvas(props.canvas)) {
    return <Box data-testid="report-canvas" data-layout="single">{props.reportTable}</Box>;
  }
  return (
    <KpiIndexContext.Provider value={kpiOrder(props.canvas.tiles)}>
    <CanvasDrillContext.Provider value={{ hierarchies: props.canvas.hierarchies, drill_columns: props.canvas.drill_columns }}><CanvasLinksProvider store={props.linkStore} enabled={!props.editable && linksEnabled(props.canvas)}>
      <CanvasLinkChips cols={props.cols} />
      <ReportCanvasGrid {...props} />
    </CanvasLinksProvider></CanvasDrillContext.Provider>
    </KpiIndexContext.Provider>
  );
}

/** The page tabs (2026-11-02): a bar across the page, chips, or plain tabs -- the theme's `page.tabs`. */
export function CanvasPageTabs({ pages, active, onChange, editable, onPagesChange, allPages }: {
  pages: { id: string; title: string }[]; active: number; onChange: (i: number) => void; editable?: boolean;
  onPagesChange?: (pages: CanvasPage[] | undefined) => void; allPages: CanvasPage[];
}) {
  const look = useCanvasTheme();
  const style = look.page.tabs;
  const [renaming, setRenaming] = useState<number | null>(null);
  const rename = (i: number, title: string) => onPagesChange?.(allPages.map((p, k) => (k === i ? { ...p, title } : p)));
  const remove = (i: number) => onPagesChange?.(allPages.length <= 1 ? undefined : allPages.filter((_, k) => k !== i));
  const add = () => onPagesChange?.([...allPages, { id: `page_${Date.now().toString(36)}`, title: `Page ${allPages.length + 1}`, tiles: [] }]);
  const title = (p: { title: string }, i: number) => p.title || `Page ${i + 1}`;
  const bar = style === 'bar';
  return (
    <Box data-testid="canvas-pages" data-tabs={style} role="tablist" aria-label="Report pages"
      sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', mb: 1, px: bar ? 1.5 : 0, py: bar ? 0.75 : 0, borderRadius: 1,
            bgcolor: bar ? appColour(look.page.header_bg) : undefined, color: bar ? look.page.header_fg : undefined }}>
      {style === 'plain' ? (
        <Tabs value={active} onChange={(_, v) => onChange(v)} sx={{ minHeight: 36 }}>
          {pages.map((p, i) => <Tab key={p.id} label={title(p, i)} sx={{ minHeight: 36, textTransform: 'none' }} data-testid={`canvas-page-tab-${i}`} />)}
        </Tabs>
      ) : pages.map((p, i) => (
        <Chip key={p.id} label={title(p, i)} role="tab" aria-selected={i === active} data-testid={`canvas-page-tab-${i}`} onClick={() => onChange(i)}
          sx={{ fontWeight: i === active ? 700 : 500, cursor: 'pointer',
                bgcolor: i === active ? (bar ? look.page.header_fg : appColour(look.card.bg)) : (bar ? 'rgba(255,255,255,0.14)' : 'transparent'),
                color: i === active ? (bar ? appColour(look.page.header_bg) : appColour(look.card.fg, true)) : (bar ? look.page.header_fg : undefined),
                border: bar ? 'none' : '1px solid', borderColor: 'divider' }} />
      ))}
      {editable && onPagesChange && (
        <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center', ml: 'auto' }}>
          {renaming === null ? (
            <Button size="small" onClick={() => setRenaming(active)} data-testid="canvas-page-rename" sx={{ color: bar ? 'inherit' : undefined }}>Rename</Button>
          ) : (
            <TextField size="small" autoFocus defaultValue={allPages[renaming]?.title ?? ''} inputProps={{ maxLength: 60, 'data-testid': 'canvas-page-title' }}
              onBlur={e => { rename(renaming, e.target.value.trim() || `Page ${renaming + 1}`); setRenaming(null); }}
              onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} sx={{ width: 180, bgcolor: '#fff', borderRadius: 1 }} />
          )}
          <Button size="small" onClick={() => remove(active)} data-testid="canvas-page-remove" sx={{ color: bar ? 'inherit' : undefined }}>Remove page</Button>
          <Button size="small" onClick={add} disabled={allPages.length >= MAX_PAGES} data-testid="canvas-page-add" sx={{ color: bar ? 'inherit' : undefined }}>Add a page</Button>
        </Box>
      )}
    </Box>
  );
}

function ReportCanvasGrid({
  canvas: whole, reportId, cols, grouped, run, reportTable, editable = false, selectedId, onSelect, onLayout,
  rearrange, onPickFields, onPagesChange,
  onDropField, problems, cubeFetch, staleFields,
}: Props) {
  const theme = useTheme();
  const look = useCanvasTheme();   // the report's look: tile radius and shadow (canvasTheme.ts)
  // PAGES (2026-11-02): the grid shows the active page's tiles; the others keep their places
  const pages = pagesOf(whole);
  const [page, setPage] = useState(0);
  const active = Math.min(page, pages.length - 1);
  const shownIds = new Set(pages[active]?.tile_ids ?? []);
  const canvas = pages.length > 1 || (editable && whole.pages?.length) ? { ...whole, tiles: whole.tiles.filter(t => shownIds.has(t.id)) } : whole;
  const tabs = (pages.length > 1 || (editable && (whole.pages?.length ?? 0) > 0))
    ? <CanvasPageTabs pages={pages} active={active} onChange={setPage} editable={editable} onPagesChange={onPagesChange} allPages={whole.pages ?? []} />
    : editable && onPagesChange ? <Box sx={{ mb: 1 }}><Button size="small" data-testid="canvas-page-add" onClick={() => onPagesChange([{ id: 'page1', title: 'Page 1', tiles: whole.tiles.map(t => t.id) }, { id: `page_${Date.now().toString(36)}`, title: 'Page 2', tiles: [] }])}>Add a page (tabs)</Button></Box> : null;
  const narrow = useMediaQuery(theme.breakpoints.down('md'));
  const { width, containerRef, mounted } = useContainerWidth({ initialWidth: 1000 });
  const colWidth = (Math.max(320, width) - MARGIN * (GRID_COLS + 1)) / GRID_COLS;
  const pxW = (w: number) => Math.max(120, w * colWidth + (w - 1) * MARGIN - 24);
  const pxH = (h: number) => Math.max(60, h * ROW_HEIGHT + (h - 1) * MARGIN - 24);

  const fieldFrom = (e: React.DragEvent): number | null => {
    const raw = e.dataTransfer.getData(FIELD_MIME);
    const n = Number(raw);
    return raw && Number.isFinite(n) ? n : null;
  };
  const dropProps = (tileId: string | null) => editable && onDropField ? {
    onDragOver: (e: React.DragEvent) => {
      if (e.dataTransfer.types.includes(FIELD_MIME)) { e.preventDefault(); e.stopPropagation(); }
    },
    onDrop: (e: React.DragEvent) => {
      const id = fieldFrom(e);
      if (id != null) { e.preventDefault(); e.stopPropagation(); onDropField(id, tileId); }
    },
  } : {};

  const tileBox = (t: CanvasTile, w: number, h: number) => {
    const isSel = editable && selectedId === t.id;
    const tp = problems?.[t.id] ?? [];
    let borderColor = cssColour(look.card.border) ?? 'divider';
    if (tp.length) borderColor = 'error.main';
    else if (isSel) borderColor = 'primary.main';
    return (
      <Paper variant="outlined" data-testid={`canvas-tile-${t.id}`}
        onMouseDown={() => editable && onSelect?.(t.id)}
        {...dropProps(t.id)}
        sx={{
          height: '100%', p: 1.5, overflow: 'hidden', display: 'flex', flexDirection: 'column',
          borderRadius: `${look.tiles.radius}px`, boxShadow: look.tiles.shadow ? '0 1px 6px rgba(0,0,0,0.08)' : 'none',
          // theme v2 (2026-11-02): the card's own colours; 'app' leaves MUI's (today's look)
          bgcolor: cssColour(look.card.bg), color: cssColour(look.card.fg),
          borderColor,
          borderWidth: isSel || tp.length ? 2 : 1,
        }}>
        {(editable || rearrange) && (
          <Box className="canvas-drag-handle" sx={{ cursor: 'move', height: 6, mx: -1.5, mt: -1.5, mb: 0.5, bgcolor: isSel ? 'primary.light' : 'action.hover' }}
            aria-label="Drag to move this tile" />
        )}
        {rearrange && onPickFields && <FieldsMenu tile={t} canvas={canvas} cols={cols} onFields={onPickFields} />}
        {tp.length > 0 && (
          <Typography variant="caption" color="error" component="div" data-testid={`tile-problem-${t.id}`}>
            {tp.join(' ')}
          </Typography>
        )}
        <Box sx={{ flex: 1, minHeight: 0, overflow: t.kind === 'report' ? 'auto' : 'hidden' }} data-tile-kind={t.kind}>
          {/* 2026-10-30: a tile below the fold is drawn (and its data asked for) when scrolled to */}
          <DrawWhenSeen tileId={t.id} width={w} height={h} eager={t.kind === 'report'}>
            <CanvasLinkTileScope tile={t}><DrillableTile tile={t} reportId={reportId} cols={cols} grouped={grouped} run={run}
              reportTable={reportTable} width={w} height={h} cubeFetch={cubeFetch} editable={!!editable}
              staleFields={staleFields?.[t.id]} /></CanvasLinkTileScope>
          </DrawWhenSeen>
        </Box>
      </Paper>
    );
  };

  const empty = canvas.tiles.length === 0;
  if (narrow && !editable) {
    const ordered = [...canvas.tiles].sort((a, b) => a.layout.y - b.layout.y || a.layout.x - b.layout.x);
    return (<>
      {tabs}
      <Box ref={containerRef} data-testid="report-canvas" data-layout="stacked"
        sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, bgcolor: cssColour(look.page.bg), p: look.page.bg === 'app' ? 0 : 1.5, borderRadius: 1 }}>
        {ordered.map(t => (
          <Box key={t.id} sx={{ minHeight: t.kind === 'number' ? 110 : t.kind === 'report' ? undefined : 300 }}>
            {tileBox(t, Math.max(280, width - 24), t.kind === 'number' ? 90 : 280)}
          </Box>
        ))}
      </Box>
    </>);
  }
  return (<>
    {tabs}
    <Box ref={containerRef} data-testid="report-canvas" data-layout="grid" data-page={pages.length > 1 ? active : undefined} {...dropProps(null)}
      onMouseDown={e => { if (editable && e.target === e.currentTarget) onSelect?.(null); }}
      sx={{ minHeight: editable ? 400 : undefined, position: 'relative',
            // the page behind the cards (theme v2); the builder keeps its grey work surface
            bgcolor: editable ? 'action.hover' : cssColour(look.page.bg), p: !editable && look.page.bg !== 'app' ? 1 : 0, borderRadius: 1 }}>
      {empty && editable && (
        <Box sx={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
          <Typography color="text.secondary">Drag a field here to start, or pick a tile kind on the right.</Typography>
        </Box>
      )}
      {mounted && (
        <GridLayout
          width={Math.max(320, width)}
          layout={canvas.tiles.map(t => ({ i: t.id, ...t.layout, minW: 2, minH: 2 }))}
          gridConfig={{ cols: GRID_COLS, rowHeight: ROW_HEIGHT, margin: [MARGIN, MARGIN] }}
          dragConfig={{ enabled: editable || !!rearrange, handle: '.canvas-drag-handle' }}
          resizeConfig={{ enabled: editable || !!rearrange }}
          onLayoutChange={(layout: any) => {
            if (!(editable || rearrange) || !onLayout) return;
            const next: Record<string, TileLayout> = {};
            for (const l of layout) next[l.i] = { x: l.x, y: l.y, w: l.w, h: l.h };
            onLayout(next);
          }}
        >
          {canvas.tiles.map(t => (
            <div key={t.id}>{tileBox(t, pxW(t.layout.w), pxH(t.layout.h))}</div>
          ))}
        </GridLayout>
      )}
    </Box>
  </>);
}
