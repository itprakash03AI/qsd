"""QueryStudio Feed Worker — dedicated standalone process.

Phase 130 hotfix-13.  Runs ONLY the feed queue worker — nothing else.
Use case: 10K+ feeds/day where the queue load deserves its own pod (or
several, sharded).  Co-residence in the scheduler pod is fine for ≤
1K feeds/day; above that the worker thread competes with APScheduler
+ SLA tracker + custom jobs.

Activation:
  - Deploy this entrypoint as a separate Kubernetes pod / Helm release.
  - Set ``QUERYSTUDIO_FEED_SHARD=i/N`` per pod for sharded fan-out.
  - On the API + scheduler pods, set
    ``feed_generation.worker_pod_only=true`` so they skip in-process
    queue worker registration.

Usage:
    python feed_worker.py [--shard 0/4] [--poll-interval 30]
    python -m querystudio feed-worker [--shard 0/4] [--port 8005]

The process exits cleanly on SIGTERM, releasing its worker_health_state
row and finishing in-flight feed executions if possible.

Probes (W3, 2026-09-26): a tiny control app on
``QUERYSTUDIO_FEED_WORKER_HOST:QUERYSTUDIO_FEED_WORKER_PORT`` (default
127.0.0.1:8005) serves ``/health``, ``/health/live`` and ``/health/ready`` --
the same three paths scheduler_worker.py serves -- so the feed-worker chart's
kubelet probes have something to hit.  Until 2026-09-26 that chart ran the
ETL pipeline worker (``etl-worker``) because THIS file had no CLI subcommand
and no HTTP surface; ``tests/test_k8s_charts_runtime_parity_2026_08_03.py``
now asserts the chart's exec line names a subcommand the CLI defines and its
probe paths are route literals here.
"""
from __future__ import annotations

import argparse
import logging
import os
import signal
import socket
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402

logger = logging.getLogger("feed_worker")

#: Bind address / port of the control app.  Loopback by default (a local
#: ``python feed_worker.py`` should not open a port on every interface); the
#: chart sets the HOST to 0.0.0.0 because a kubelet httpGet probe arrives on
#: the pod IP -- the scheduler chart missed exactly that and its probes were
#: refused after the W1 path fix (2026-09-26).
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8005

# ── Module-level state the control app reports ───────────────────────────────

_db_manager = None
_worker = None
_state: Dict[str, Any] = {
    "started_at": None,
    "pod_id": None,
    "shard": None,
    "last_tick_at": None,
    "last_tick": None,
    "ticks": 0,
    "tick_failures": 0,
}


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """``argv=None`` means ``sys.argv[1:]`` (``python feed_worker.py``).

    The CLI subcommand passes an explicit list: ``python -m querystudio
    feed-worker --shard 0/2`` has ``sys.argv[1:] == ["feed-worker", ...]``
    and this parser would refuse ``feed-worker`` as an unknown positional.
    """
    p = argparse.ArgumentParser(description="QueryStudio Feed Worker")
    p.add_argument("--shard", default=os.environ.get("QUERYSTUDIO_FEED_SHARD"),
                   help="Shard assignment 'i/N' (e.g. '0/4').  Default from env QUERYSTUDIO_FEED_SHARD.")
    p.add_argument("--poll-interval", type=int, default=None,
                   help="Override config queue_poll_interval_seconds.")
    p.add_argument("--max-concurrent", type=int, default=None,
                   help="Override config max_concurrent_native.")
    p.add_argument("--log-level", default="INFO")
    return p.parse_args(argv)


def _setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )


# ── FastAPI control app (probes) ─────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio Feed Worker",
    docs_url=None,
    redoc_url=None,
)


def _db_reachable(probe_id: str) -> bool:
    """One cheap SELECT; the same shape scheduler_worker.py's readiness uses."""
    if _db_manager is None:
        return False
    try:
        _db_manager.get_execution(probe_id)
        return True
    except Exception as exc:  # noqa: BLE001
        # A probe reports; it never raises.
        logger.debug("feed_worker DB probe failed: %s", exc)
        return False


@control_app.get("/health")
async def health():
    """Full status -- worker state + DB connectivity."""
    db_ok = _db_reachable("__feed_worker_health_probe__")
    inflight = _worker.inflight_count if _worker is not None else 0
    return {
        "status": "ok" if db_ok else "degraded",
        "database": {"ok": db_ok},
        "worker": {"constructed": _worker is not None, "inflight": inflight},
        **_state,
    }


@control_app.get("/health/live")
async def liveness():
    """K8s liveness -- always 200 while the process is up."""
    return {"status": "alive"}


@control_app.get("/health/ready")
async def readiness():
    """K8s readiness -- the worker exists and the DB answers.

    Not-ready is a 503 with the reason, never a 200 with nothing in it
    (CLAUDE.md §4): a pod that cannot claim rows must not receive traffic
    or count as a healthy replica.
    """
    if _worker is None:
        return JSONResponse(status_code=503,
                            content={"status": "not_ready",
                                     "reason": "queue worker not started"})
    if not _db_reachable("__feed_worker_ready_probe__"):
        return JSONResponse(status_code=503,
                            content={"status": "not_ready",
                                     "reason": "database unavailable"})
    # 2026-10-17 -- a DRAIN intent applied on this pod: not ready, said.
    from core.component_health.intents import effective_draining as _draining
    _d = _draining(_db_manager)   # the flag OR the drain row (2026-10-18)
    if _d.get("active"):
        return JSONResponse(status_code=503,
                            content={"status": "draining", "since": _d.get("since"),
                                     "by": _d.get("by"), "intent_id": _d.get("intent_id"),
                                     "source": _d.get("source")})
    return {"status": "ready"}


def control_bind() -> tuple:
    """Where the control app listens.  Read at start, so a test can set the
    env and a chart can set both without touching config.json."""
    host = os.environ.get("QUERYSTUDIO_FEED_WORKER_HOST", "").strip() or DEFAULT_HOST
    raw_port = os.environ.get("QUERYSTUDIO_FEED_WORKER_PORT", "").strip()
    try:
        port = int(raw_port) if raw_port else DEFAULT_PORT
    except ValueError:
        logger.error("QUERYSTUDIO_FEED_WORKER_PORT=%r is not an integer; "
                     "using %d", raw_port, DEFAULT_PORT)
        port = DEFAULT_PORT
    return host, port


def _start_control_app(log: logging.Logger) -> Optional[threading.Thread]:
    """Serve the probes on a daemon thread; the poll loop keeps the main
    thread (signal handlers must live there).  Fail-open: a port clash
    logs at ERROR and the worker still runs feeds -- but the pod will
    then fail its readiness probe, which is the correct visible outcome."""
    host, port = control_bind()

    def _serve():
        try:
            import uvicorn
            uvicorn.run(control_app, host=host, port=port,
                        log_level="warning", access_log=False)
        except Exception:  # noqa: BLE001
            log.exception("feed_worker control app failed on %s:%d -- "
                          "probes will fail", host, port)

    t = threading.Thread(target=_serve, name="feed-worker-control", daemon=True)
    t.start()
    log.info("Control app (probes) listening on %s:%d", host, port)
    return t


def main(argv: Optional[List[str]] = None) -> None:
    global _db_manager, _worker
    args = _parse_args(argv)
    _setup_logging(args.log_level)
    log = logging.getLogger("feed_worker")

    # Import here so logging is configured first.
    from core import config as _cfg_mod
    from core.config import feed_generation as _fg
    from core.database import DatabaseManager
    from core.feed.queue_worker import get_shared_queue_worker, reset_shared_queue_worker

    # Build DB manager (no FastAPI app — we're a worker process)
    db_url = _cfg_mod.paths.db_url  # type: ignore[attr-defined]
    db = DatabaseManager(db_url=db_url)
    _cfg_mod.init_db_settings(db)
    _db_manager = db
    log.info("DB attached: %s", db_url)
    # 2026-10-17 -- this pod's component-health reporter (per pod).
    try:
        from core.component_health.reporter import start_reporter as _ch_start
        _ch_start(db)
    except Exception as _ch_exc:  # noqa: BLE001
        log.warning("component_health reporter not started (non-fatal): %s", _ch_exc)
    # 2026-09-27 -- the ONE startup line naming the config file this pod loaded.
    _cfg_mod.log_config_source(log)

    # ─── Cross-pod feed progress (2026-07-16) ──────────────────────────────
    # A feed running on THIS dedicated worker pod must still reach the UI's
    # WebSocket, which lives on the API pod.  Wire the feed engine with a
    # bus-publishing broadcast_fn and init the event bus so execute_feed's
    # feed_progress + feed_run_log events fan out via PostgreSQL NOTIFY to the
    # API/WS pod (which LISTENs and re-dispatches to its local ws_manager).
    #
    # init_feed_engine ALSO sets feed_engine._db_manager, which execute_feed
    # requires — without it the worker's execute_feed would have no DB handle.
    # All fail-open: a bus/wiring problem never stops the worker running feeds.
    try:
        from core.feed_engine import init_feed_engine
        from core.event_bus import init_event_bus, publish as _eb_publish
        from core.config import database as _db_cfg

        def _feed_bus_broadcast(payload):
            """Publish feed progress / log-stream events to the cross-pod event
            bus.  This pod has no local WS clients — pg_notify carries the event
            to the API/WS pod.  The SAME bridge main._feed_ws_broadcast uses
            (2026-10-07): it publishes the AUDIENCE the producer resolved
            (core/feed/event_audience.py) -- it used to lift ``triggered_by``
            to the username, and every run on this pod is triggered by
            "queue_worker", so nobody ever saw one live."""
            from core.feed.event_audience import bridge_feed_event_to_bus
            try:
                bridge_feed_event_to_bus(payload, publish=_eb_publish)
            except Exception as _pub_exc:  # pragma: no cover - defensive
                log.debug("feed bus publish failed (non-fatal): %s", _pub_exc)

        init_event_bus(db_manager=db, db_type=_db_cfg.type)
        # DECLARED (2026-10-07): the bus carries every per-line
        # ``feed_run_log`` event to the API/WS pod, so a run on this pod
        # records ``feed_executions.log_stream = "live"``.
        from core.feed.event_audience import streams_run_log
        init_feed_engine(db, broadcast_fn=streams_run_log(_feed_bus_broadcast))
        log.info("Cross-pod progress wired: event bus (backend=%s) + feed engine "
                 "broadcast_fn installed", _db_cfg.type)
    except Exception as _wire_exc:
        log.warning("Cross-pod progress wiring failed (%s) — feeds still run, "
                    "but progress stays pod-local until this is fixed", _wire_exc)

    poll_interval = int(args.poll_interval or _fg.queue_poll_interval_seconds or 30)
    poll_interval = max(5, poll_interval)
    max_concurrent = int(args.max_concurrent or _fg.max_concurrent_native or 3)
    shard = args.shard or None

    pod_id = f"{socket.gethostname()}:{os.getpid()}"
    log.info(
        "Feed worker starting: pod_id=%s shard=%s max_concurrent=%d poll_interval=%ds",
        pod_id, shard or "(single)", max_concurrent, poll_interval,
    )

    worker = get_shared_queue_worker(
        db, max_concurrent=max_concurrent, shard=shard,
    )
    _worker = worker
    _state.update(started_at=datetime.now(timezone.utc).isoformat(),
                  pod_id=pod_id, shard=shard)
    # Probes come up only once the worker exists: readiness answers 503
    # with a reason before this point, never a 200 for a pod that cannot
    # claim rows.
    _start_control_app(log)

    stop_event = threading.Event()

    def _handle_signal(signum, _frame):
        log.info("Received signal %s — initiating graceful shutdown", signum)
        stop_event.set()

    # SIGTERM (k8s pod termination) + SIGINT (Ctrl-C) → graceful drain
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _handle_signal)
        except (ValueError, OSError):
            # SIGTERM not supported on Windows main thread — ignore
            pass

    last_log = 0.0
    try:
        while not stop_event.is_set():
            tick_start = time.time()
            try:
                result = worker.poll_once()
                _state["ticks"] += 1
                _state["last_tick_at"] = datetime.now(timezone.utc).isoformat()
                _state["last_tick"] = result.to_dict()
                if result.claimed > 0 or result.errors > 0:
                    log.info("[tick] %s", result.to_dict())
                else:
                    # Quieter log at INFO every 5 min so we know it's alive
                    if time.time() - last_log > 300:
                        log.info("[tick] alive: candidates=%d inflight=%d",
                                  result.candidates, worker.inflight_count)
                        last_log = time.time()
            except Exception as exc:
                _state["tick_failures"] += 1
                log.warning("Tick failed: %s", exc)

            # worker_health_state GC: done by ``poll_once`` itself since
            # 2026-10-07 (core.feed.queue_worker.maybe_gc_worker_health), so
            # the APScheduler-hosted worker ages its rows out too.

            # Sleep up to poll_interval, but wake on stop signal
            tick_elapsed = time.time() - tick_start
            sleep_for = max(1.0, poll_interval - tick_elapsed)
            stop_event.wait(timeout=sleep_for)
    finally:
        log.info("Draining in-flight executions (count=%d)", worker.inflight_count)
        # 2026-10-14 -- THE routine (core/feed/run_lifecycle.py): drain inside
        # the grace period, close the publish gate, hand the rest back.
        from core.feed.run_lifecycle import hand_back_on_exit
        hand_back_on_exit(worker, db)
        worker.shutdown()
        from core.feed.run_lifecycle import exit_if_work_was_disowned
        exit_if_work_was_disowned(log)
        reset_shared_queue_worker()
        _worker = None
        # Mark our pod_id as gone so the failover agent's probe doesn't
        # keep counting us as a contributor.
        try:
            with db.get_session() as s:
                from sqlalchemy import text
                s.execute(text(
                    "DELETE FROM worker_health_state WHERE pod_id = :pid"
                ), {"pid": pod_id})
        except Exception:
            pass
        log.info("Feed worker exited.")


if __name__ == "__main__":
    main()
