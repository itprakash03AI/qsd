"""``python -m querystudio release ...`` -- the pipeline's hands on a
configuration release (docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3.7).

Transport-neutral: every command talks to a running QueryStudio API with a
bearer token (``--base-url`` / ``QS_API_URL``, ``--token`` /
``QS_ADMIN_TOKEN``), exactly as a person's browser does, so the pipeline
and the UI cannot disagree -- both call the same routes.

    release export   --scope-kind feed_group --key MONTH_END --out pkg.json [--explode dir/] [--commit SHA]
    release upload   pkg.json [--environment prod] [--ticket REL-1]      -> prints the release id
    release preview  <id>                 exit 2 = blocked (mappings missing), 3 = undecided conflicts
    release approve  <id> [--ticket REL-1] [--note ...]
    release apply    <id>                 exit 4 = applied but NOT verified
    release verify   <id>
    release rollback <id>
    release show     <id> | release list [--environment prod]
    release mappings [--environment prod] [--set kind=from=to ...]
    release explode  pkg.json dir/        one file per object for a git review
    release implode  dir/ --out pkg.json  the reviewed tree back into one package

Exit codes: 0 ok, 1 refused (the reason is printed), 2 preview blocked,
3 undecided conflicts, 4 applied but not verified.
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import sys
import urllib.error
import urllib.request
from typing import Any


class Api:
    def __init__(self, base_url: str, token: str | None, timeout: float = 300.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def call(self, method: str, path: str, body: Any = None) -> tuple[int, Any]:
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(self.base_url + path, data=data, method=method)
        req.add_header("Accept", "application/json")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Authorization", f"Bearer {self.token}")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8")
                return resp.status, (json.loads(raw) if raw else None)
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, {"detail": raw}


def _api(args) -> Api:
    base = args.base_url or os.environ.get("QS_API_URL") or "http://localhost:8000"
    token = args.token or os.environ.get("QS_ADMIN_TOKEN") or None
    if not token:
        print("warning: no token (--token / QS_ADMIN_TOKEN) -- every admin route will answer 401 "
              "unless auth is off", file=sys.stderr)
    return Api(base, token)


def _refuse(status: int, body: Any) -> int:
    detail = (body or {}).get("detail") if isinstance(body, dict) else body
    print(f"REFUSED (HTTP {status}): {json.dumps(detail, ensure_ascii=False, default=str)}")
    return 1


def _print(obj: Any) -> None:
    print(json.dumps(obj, indent=1, ensure_ascii=False, default=str))


def cmd_export(args) -> int:
    api = _api(args)
    scope: dict = {"kind": args.scope_kind, "with_dependencies": not args.no_dependencies}
    if args.key:
        scope["keys"] = args.key
    if args.area:
        scope["area"] = args.area
    s, b = api.call("POST", "/api/governance/release/export", {"scope": scope, "source_commit": args.commit})
    if s != 200:
        return _refuse(s, b)
    text = json.dumps(b, indent=1, ensure_ascii=False, sort_keys=True) + "\n"
    pathlib.Path(args.out).write_bytes(text.encode("utf-8"))
    print(f"wrote {args.out}: {len(b['items'])} object(s), checksum {b['checksum']}")
    if args.explode:
        from core.release.package import explode
        _write_tree(pathlib.Path(args.explode), explode(b))
    return 0


def _write_tree(root: pathlib.Path, files: dict[str, str]) -> None:
    root.mkdir(parents=True, exist_ok=True)
    for rel, text in files.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(text.encode("utf-8"))
    print(f"exploded {len(files)} file(s) under {root}")


def cmd_explode(args) -> int:
    from core.release.package import explode
    pkg = json.loads(pathlib.Path(args.package).read_text(encoding="utf-8"))
    _write_tree(pathlib.Path(args.dir), explode(pkg))
    return 0


def cmd_implode(args) -> int:
    from core.release.package import implode
    root = pathlib.Path(args.dir)
    files = {str(p.relative_to(root)).replace("\\", "/"): p.read_text(encoding="utf-8")
             for p in root.rglob("*.json")}
    if "package.json" not in files:
        print("REFUSED: the tree has no package.json envelope")
        return 1
    pkg = implode(files)
    pathlib.Path(args.out).write_bytes((json.dumps(pkg, indent=1, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"))
    print(f"wrote {args.out}: {len(pkg['items'])} object(s), checksum {pkg['checksum']}")
    return 0


def cmd_upload(args) -> int:
    api = _api(args)
    pkg = json.loads(pathlib.Path(args.package).read_text(encoding="utf-8"))
    body = {"package": pkg, "environment": args.environment, "ticket": args.ticket}
    s, b = api.call("POST", "/api/governance/release/upload", body)
    if s not in (200, 201):
        return _refuse(s, b)
    print(f"release {b['id']} uploaded to {b['environment']} (state {b['state']}, checksum {b['package_checksum']})")
    print(b["id"])
    return 0


def cmd_preview(args) -> int:
    api = _api(args)
    s, b = api.call("POST", f"/api/governance/release/{args.id}/preview")
    if s != 200:
        return _refuse(s, b)
    pv = b.get("preview") or {}
    print(f"release {args.id}: {json.dumps(pv.get('counts'))} ready={pv.get('ready')}")
    for e in pv.get("items") or []:
        flag = "BLOCKED " if e.get("blocked") else ""
        print(f"  {flag}{e['state']:<12} {e['kind']} {e['key']}")
        for f in e.get("fields") or []:
            print(f"      {f['state']:<12} {f['path']}: {f.get('theirs')!r} -> {f.get('ours')!r}")
        for m in e.get("missing") or []:
            print(f"      MISSING {m.get('reason')}")
    if pv.get("mappings_needed"):
        print("mappings needed:")
        for m in pv["mappings_needed"]:
            print(f"  {m['kind']}={m['from_value']}=<target value>")
    if (pv.get("counts") or {}).get("blocked"):
        return 2
    if (pv.get("counts") or {}).get("undecided"):
        return 3
    return 0


def cmd_approve(args) -> int:
    api = _api(args)
    s, b = api.call("POST", f"/api/governance/release/{args.id}/approve", {"ticket": args.ticket, "note": args.note})
    if s != 200:
        return _refuse(s, b)
    print(f"release {args.id} approved by {b.get('approved_by')} (ticket {b.get('jira_ticket')})")
    return 0


def cmd_apply(args) -> int:
    api = _api(args)
    s, b = api.call("POST", f"/api/governance/release/{args.id}/apply")
    if s != 200:
        return _refuse(s, b)
    print(f"release {args.id}: {b.get('state')}")
    for l in b.get("ledger") or []:
        print(f"  {l['action']:<10} {l['kind']} {l['key']}" + (f" (kept {l['kept_fields']})" if l.get("kept_fields") else ""))
    for m in b.get("members") or []:
        print(f"  members of {m['template']}: HTTP {m['status']} {json.dumps((m.get('report') or {}).get('counts') or m.get('error') or m.get('job'))}")
    v = b.get("verification") or {}
    print(f"verification: {v.get('state')} {json.dumps(v.get('counts'))}")
    return 0 if b.get("state") == "verified" else 4


def cmd_verify(args) -> int:
    api = _api(args)
    s, b = api.call("POST", f"/api/governance/release/{args.id}/verify")
    if s != 200:
        return _refuse(s, b)
    v = b.get("verification") or {}
    print(f"release {args.id}: {b.get('state')} {json.dumps(v.get('counts'))}")
    for r in v.get("items") or []:
        if r["verdict"]["state"] != "ok":
            print(f"  {r['verdict']['state']:<8} {r['kind']} {r['key']}: {r['verdict']['reason']}")
    return 0 if b.get("state") == "verified" else 4


def cmd_rollback(args) -> int:
    api = _api(args)
    s, b = api.call("POST", f"/api/governance/release/{args.id}/rollback")
    if s != 200:
        return _refuse(s, b)
    print(f"release {args.id} rolled back by release {b.get('id')} ({b.get('state')}); "
          f"deactivated {b.get('deactivated')}; left {b.get('left')}")
    return 0


def cmd_show(args) -> int:
    api = _api(args)
    s, b = api.call("GET", f"/api/governance/release/{args.id}")
    if s != 200:
        return _refuse(s, b)
    _print(b)
    return 0


def cmd_list(args) -> int:
    api = _api(args)
    q = f"?environment={args.environment}" if args.environment else ""
    s, b = api.call("GET", f"/api/governance/releases{q}")
    if s != 200:
        return _refuse(s, b)
    for r in b.get("releases") or []:
        print(f"{r['id']:>5} {r['state']:<18} {r.get('source_environment') or '':<8} {r.get('source_commit') or '':<10} "
              f"{r.get('uploaded_by') or '':<12} {r.get('item_count')} object(s) {r.get('uploaded_at')}")
    return 0


def cmd_mappings(args) -> int:
    api = _api(args)
    if args.set:
        rows = []
        for spec in args.set:
            parts = spec.split("=", 2)
            if len(parts) != 3:
                print(f"REFUSED: --set wants kind=from=to, got {spec!r}")
                return 1
            rows.append({"kind": parts[0], "from_value": parts[1], "to_value": parts[2]})
        s, b = api.call("PUT", "/api/governance/release/mappings", {"environment": args.environment, "mappings": rows})
    else:
        q = f"?environment={args.environment}" if args.environment else ""
        s, b = api.call("GET", f"/api/governance/release/mappings{q}")
    if s != 200:
        return _refuse(s, b)
    for m in b.get("mappings") or []:
        print(f"  {m['kind']:<12} {m['from_value']} -> {m['to_value']}")
    return 0


def add_release_parser(subparsers) -> argparse.ArgumentParser:
    p = subparsers.add_parser("release", help="Configuration releases: export, upload, preview, approve, apply, verify, rollback")
    sub = p.add_subparsers(dest="release_command")

    def common(sp):
        sp.add_argument("--base-url", default=None, help="API base URL (default $QS_API_URL or http://localhost:8000)")
        sp.add_argument("--token", default=None, help="bearer token (default $QS_ADMIN_TOKEN)")

    e = sub.add_parser("export", help="selected objects + dependencies -> one package")
    common(e)
    e.add_argument("--scope-kind", default="everything", help="everything | area | <object kind>")
    e.add_argument("--key", action="append", default=[], help="object key (repeatable)")
    e.add_argument("--area", default=None, help="feedgen | reports | published | dashboards (with --scope-kind area)")
    e.add_argument("--no-dependencies", action="store_true")
    e.add_argument("--commit", default=None, help="the git commit the pipeline resolved (required by git-truth targets)")
    e.add_argument("--out", required=True)
    e.add_argument("--explode", default=None, help="also write one file per object under this dir")
    e.set_defaults(func=cmd_export)

    x = sub.add_parser("explode", help="one file per object for a git review")
    x.add_argument("package"); x.add_argument("dir"); x.set_defaults(func=cmd_explode)
    i = sub.add_parser("implode", help="the reviewed tree back into one package")
    i.add_argument("dir"); i.add_argument("--out", required=True); i.set_defaults(func=cmd_implode)

    u = sub.add_parser("upload", help="scan + record a release (state uploaded)")
    common(u); u.add_argument("package"); u.add_argument("--environment", default=None); u.add_argument("--ticket", default=None)
    u.set_defaults(func=cmd_upload)
    for name, fn, hlp in (("preview", cmd_preview, "resolve, three-way diff; exit 2 blocked, 3 undecided"),
                          ("apply", cmd_apply, "one transaction + verification; exit 4 = not verified"),
                          ("verify", cmd_verify, "re-run the verification"),
                          ("rollback", cmd_rollback, "re-apply the snapshot as a new release"),
                          ("show", cmd_show, "one release with its preview, ledger, verification")):
        sp = sub.add_parser(name, help=hlp); common(sp); sp.add_argument("id", type=int); sp.set_defaults(func=fn)
    a = sub.add_parser("approve", help="approve a previewed release (four-eyes / ticket rules apply)")
    common(a); a.add_argument("id", type=int); a.add_argument("--ticket", default=None); a.add_argument("--note", default=None)
    a.set_defaults(func=cmd_approve)
    ls = sub.add_parser("list", help="releases of an environment"); common(ls); ls.add_argument("--environment", default=None)
    ls.set_defaults(func=cmd_list)
    m = sub.add_parser("mappings", help="show or set the environment mapping (kind=from=to)")
    common(m); m.add_argument("--environment", default=None); m.add_argument("--set", action="append", default=[])
    m.set_defaults(func=cmd_mappings)
    return p


def run(args) -> None:
    sys.exit(int(args.func(args) or 0))
