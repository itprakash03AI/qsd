"""
QueryStudio Scheduler Worker — standalone process.

Runs APScheduler + system maintenance jobs in an independent process,
isolated from the main FastAPI HTTP server.  Communicates with FastAPI
via a shared SQLite DB (WAL mode) and a ``pending_notifications`` table.

Usage:
    python scheduler_worker.py

The worker exposes a small internal FastAPI control API on
``scheduler.worker_host:scheduler.worker_port`` (default 127.0.0.1:8001)
for health checks, pause/resume, and job management.

This process is only needed when ``scheduler.mode = "external"`` in
config.json.  When ``scheduler.mode = "embedded"`` (default), the
scheduler runs inside the main FastAPI process as before.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import signal
import sys
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ensure the backend directory is on sys.path so ``core.*`` imports work
_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI, HTTPException  # noqa: E402
from pydantic import BaseModel  # noqa: E402

logger = logging.getLogger("scheduler_worker")

# ── Globals (set during lifespan) ────────────────────────────────────────────
_db_manager = None
_db_url: str = ""
_worker_id: str = ""
_shutdown_event = threading.Event()
_heartbeat_thread: Optional[threading.Thread] = None


# ── Heartbeat loop ──────────────────────────────────────────────────────────

def _heartbeat_loop(worker_id: str, heartbeat_interval: int, max_concurrent: int):
    """Periodically report scheduler worker health to the worker registry."""
    from core.worker_registry import init_worker_registry, get_worker_registry, WorkerInfo

    # Optional psutil for system metrics
    try:
        import psutil
        _has_psutil = True
    except ImportError:
        _has_psutil = False
        logger.info("psutil not installed — heartbeat will report 0.0 for cpu/memory")

    started_at = datetime.now(timezone.utc).isoformat()

    # Initialise registry (idempotent — may already be initialised by main process)
    try:
        registry = get_worker_registry()
    except RuntimeError:
        registry = init_worker_registry(_db_manager)

    # Helper: count active APScheduler jobs
    def _active_job_count() -> int:
        try:
            from core.scheduler import get_scheduler
            sched = get_scheduler()
            if sched and sched.running:
                return len(sched.get_jobs())
        except Exception:
            pass
        return 0

    # Build initial WorkerInfo and register
    info = WorkerInfo(
        worker_id=worker_id,
        hostname=platform.node(),
        pid=os.getpid(),
        status="active",
        worker_type="scheduler",
        started_at=started_at,
        last_heartbeat=datetime.now(timezone.utc).isoformat(),
        active_tasks=_active_job_count(),
        max_concurrent=max_concurrent,
        cpu_pct=0.0,
        memory_pct=0.0,
        memory_mb=0,
        tasks_completed=0,
        tasks_failed=0,
        version="2.0.0",
    )

    try:
        registry.register(info)
        logger.info("Scheduler worker registered in registry: %s", worker_id)
    except Exception as exc:
        logger.warning("Failed to register scheduler worker: %s", exc)

    # Heartbeat loop
    while not _shutdown_event.is_set():
        _shutdown_event.wait(heartbeat_interval)
        if _shutdown_event.is_set():
            break

        # Gather system metrics
        cpu_pct = 0.0
        memory_pct = 0.0
        memory_mb = 0
        if _has_psutil:
            try:
                cpu_pct = psutil.cpu_percent(interval=None)
                mem = psutil.virtual_memory()
                memory_pct = mem.percent
                memory_mb = int(psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024))
            except Exception:
                pass

        info = WorkerInfo(
            worker_id=worker_id,
            hostname=platform.node(),
            pid=os.getpid(),
            status="active",
            worker_type="scheduler",
            started_at=started_at,
            last_heartbeat=datetime.now(timezone.utc).isoformat(),
            active_tasks=_active_job_count(),
            max_concurrent=max_concurrent,
            cpu_pct=cpu_pct,
            memory_pct=memory_pct,
            memory_mb=memory_mb,
            tasks_completed=0,
            tasks_failed=0,
            version="2.0.0",
        )

        try:
            registry.heartbeat(worker_id, info)
        except Exception as exc:
            logger.warning("Heartbeat failed: %s", exc)

    # Deregister on shutdown
    try:
        registry.deregister(worker_id)
        logger.info("Scheduler worker deregistered from registry: %s", worker_id)
    except Exception as exc:
        logger.warning("Failed to deregister scheduler worker: %s", exc)


# ── Pydantic models for control API ─────────────────────────────────────────

class AddJobRequest(BaseModel):
    schedule_id: int
    trigger_config: dict
    name: str = ""


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup: init DB + APScheduler + heartbeat.  Shutdown: stop scheduler."""
    global _db_manager, _db_url, _worker_id, _heartbeat_thread

    # ── Load config ──────────────────────────────────────────────────────
    from core.config import paths as _paths, scheduler as _sched_cfg

    # ── Logging ──────────────────────────────────────────────────────────
    log_level = os.getenv("QUERYSTUDIO_SERVER_LOG_LEVEL", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Database ─────────────────────────────────────────────────────────
    # 2026-08-11 -- was ``_db_url = f"sqlite:///{db_file}"`` UNCONDITIONALLY,
    # ignoring ``database.type``.  On a PostgreSQL deployment this worker wrote
    # to a LOCAL SQLITE FILE while the API used Postgres -- split brain, and
    # silent: the worker logs a healthy "Database: sqlite:///..." and creates
    # the file.  Observed live in the local docker stack (a 3 MB SQLite
    # appeared alongside a Postgres-backed API).
    #
    # The identical bug was fixed for the CLI on 2026-06-04 by
    # ``_resolve_cli_db_target()`` (querystudio/cli.py) and never ported here.
    # Reuse that resolver rather than growing a fourth copy of the ladder --
    # it already honours the BF-409 env chain (QUERYSTUDIO_DATABASE_URL /
    # _CMD / _SECRET -> postgresql_url -> composed parts) which reading
    # ``postgresql_url`` directly does not, and which is what K8s deploys use.
    #
    # Affects docker-compose.production.yml, docker-compose.scale.yml and the
    # Helm scheduler/worker charts on ANY PostgreSQL deployment.
    from querystudio.cli import _resolve_cli_db_target
    _db_url, _db_label, db_file = _resolve_cli_db_target()

    from core.database import DatabaseManager
    _db_manager = DatabaseManager(db_url=_db_url)
    logger.info("Database: %s", _db_url)

    # 2026-09-27 -- the ONE startup line naming the config file this pod
    # loaded; same fact as /health `config` and `config show` `_source`.
    from core.config import log_config_source
    log_config_source(logger)

    # 2026-09-16 -- LOAD THE DB CONFIG OVERLAY, like every other entry point.
    #
    # ``main.py:2417`` and ``feed_worker.py:74`` both call this; this process
    # did not.  ``core/config.py`` only consults the ``app_config`` overlay
    # once ``init_db_settings`` has handed it a db manager, so WITHOUT this
    # call the scheduler/worker pod runs on config-FILE values forever and
    # never sees anything an admin changed through /admin/app-config -- on
    # the very pod the helm split makes responsible for scheduled reports,
    # subscription deliveries, feed runs and DQ rules.  An operator turns a
    # knob, the UI confirms it, and the pod that acts on it never hears.
    #
    # Same shape as the 2026-09-01 ``init_persistence`` defect (admin Pause
    # inert on the only pod running daemons), one file over: a mechanism that
    # exists, is called from the entry points someone remembered, and is
    # missing from the one nobody drives by hand.  Non-fatal for the same
    # reason it is non-fatal in main.py -- a worker that cannot read the
    # overlay must still start on its file config, loudly.
    try:
        import core.config as _cfg_mod
        _cfg_mod.init_db_settings(_db_manager)
        logger.info("DB config overlay attached (admin app-config is live "
                    "on this pod)")
    except Exception as _cfg_db_exc:      # pragma: no cover - defensive
        logger.warning(
            "config.init_db_settings failed (non-fatal): %s -- this pod is "
            "running on config-FILE values and will NOT see admin changes",
            _cfg_db_exc)

    # ── Wire broadcast to notification queue ─────────────────────────────
    from core.scheduler import set_broadcast_fn, init_scheduler
    from core.queue_backend import init_queue_backend, get_notification_queue
    init_queue_backend(_db_manager)

    def _queue_broadcast(payload: dict):
        get_notification_queue().enqueue(payload)

    set_broadcast_fn(_queue_broadcast)

    # ── Wire the deps scheduler-executed jobs reach (Defect B, 2026-08-20)
    # The jobs this pod owns EXECUTE work whose module-level dependencies
    # used to be wired only in main.py's lifespan: delivery_engine (
    # subscription ticks), api.reports_api (the raw_sql engines) and
    # feed_engine (claimed feed_runs) each carried a None _db_manager here
    # and raised AttributeError EVERY TICK — while scheduler/values.yaml
    # promises this pod "EXECUTES scheduled business reports and
    # subscription deliveries in-process".  One shared, individually-guarded
    # wiring function closes all of them at once.
    from core.daemon_registry import (
        DaemonContext,
        register_scheduler_owned,
        wire_scheduled_execution_deps,
    )
    _wiring = wire_scheduled_execution_deps(_db_manager)
    logger.info("scheduler_worker: execution deps wired: %s", _wiring)

    # The worker's own running loop — service-shaped daemons (ETL scheduler
    # coroutine, background_jobs autostart) run on it.
    _worker_loop = asyncio.get_running_loop()

    # ── Start APScheduler + register every scheduler-owned daemon ────────
    # 2026-08-20: the worker no longer keeps its own hand-written daemon
    # list (the 2026-06-24 and 2026-08-19 incidents were both "main.py
    # gates it, this list forgot it" — and the same drift then orphaned SIX
    # more capabilities).  The single source of truth is
    # core.daemon_registry.SCHEDULER_OWNED, which the closure test executes
    # against main.py's gate names, so the gate and the owner cannot drift
    # apart again.  Each registration is individually guarded: one daemon's
    # failure never blocks the rest.
    def _start_scheduler():
        # 2026-09-15 — scheduler.autostart was HONOURED BY main.py AND
        # IGNORED HERE.  This call passed no start_paused at all, so the
        # flag's whole purpose -- bring the scheduler up registered but
        # NOT firing, for a maintenance window, a blue-green cutover or a
        # stuck-schedule investigation -- was silently unavailable in
        # exactly the deployment where it matters most: scheduler.mode=
        # external, where this pod IS the scheduler.  An operator set
        # autostart=false, the API pod dutifully paused a scheduler it
        # does not run, and this process started every job anyway.
        # Same drift class as the two incidents the comment above cites,
        # and as the init_db_settings gap fixed the same day one file up.
        try:
            from core.config import scheduler as _sched_cfg
            _autostart = bool(getattr(_sched_cfg, "autostart", True))
        except Exception as _acfg_exc:      # pragma: no cover - defensive
            # Default TRUE on an unreadable config: historical behaviour,
            # and a scheduler that will not fire is a worse failure mode
            # than one that fires when an operator wanted it held.
            logger.warning("Could not read scheduler.autostart (%s) — "
                           "defaulting to autostart=true", _acfg_exc)
            _autostart = True
        try:
            init_scheduler(_db_manager, db_url=_db_url,
                           start_paused=not _autostart)
            if _autostart:
                logger.info("APScheduler started in worker process")
            else:
                logger.warning(
                    "APScheduler started PAUSED in worker process "
                    "(scheduler.autostart=false) — jobs are registered but "
                    "NOTHING WILL FIRE until POST /api/admin/scheduler/resume")
        except Exception as exc:
            logger.error("APScheduler startup failed: %s", exc, exc_info=True)
            return

        try:
            # get_daemon_scheduler routes daemon jobs into the in-memory
            # 'daemon' jobstore — the persistent store refuses closures and
            # unpicklable args, silently dropping those registrations.
            from core.scheduler import get_daemon_scheduler
            _sched_singleton = get_daemon_scheduler()
        except Exception as _ss_exc:
            logger.warning(
                "scheduler singleton unavailable -- registering only the "
                "service-shaped daemons: %s", _ss_exc,
            )
            _sched_singleton = None

        ctx = DaemonContext(
            db_manager=_db_manager,
            scheduler=_sched_singleton,
            loop=_worker_loop,
        )
        # 2026-09-01 — wire pause persistence BEFORE anything registers or
        # autostarts.  This pod runs every daemon, and it was the one pod
        # that never called init_persistence: ``background_jobs._db_manager``
        # stayed None here, so ``is_paused`` returned the LOCAL flag and
        # exited before consulting the DB.
        #
        # That is why admin Pause did nothing.  BF-320 persisted the intent
        # and Phase 154 taught ``is_paused`` to read it back "so admin Pause
        # clicks land on every pod" — but on the pod that owns the daemons
        # there was no manager to read it WITH.  The feature was complete
        # except for its one required call.
        #
        # It also has to precede autostart_all, which skips jobs the DB says
        # are paused: without it, a pod restart silently resumes everything
        # an admin had stopped.
        try:
            from core import background_jobs as _bj_persist
            _bj_persist.init_persistence(_db_manager)
            logger.info("scheduler_worker: background_jobs pause persistence "
                        "wired (admin pause/resume now reaches this pod)")
        except Exception as _bj_p_exc:
            logger.warning("scheduler_worker: background_jobs "
                           "init_persistence failed (admin pause will not "
                           "reach this pod): %s", _bj_p_exc)
        # 2026-10-17 -- this pod's component-health reporter (per pod).
        try:
            from core.component_health.reporter import start_reporter as _ch_start
            _ch_start(_db_manager)
        except Exception as _ch_exc:
            logger.warning("scheduler_worker: component_health reporter not "
                           "started (non-fatal): %s", _ch_exc)

        results = register_scheduler_owned(ctx)
        _failed = {k: v for k, v in results.items() if v is not True}
        if _failed:
            logger.warning("scheduler_worker: daemon registrations not "
                           "completed: %s", _failed)
        logger.info("scheduler_worker: %d/%d scheduler-owned daemons "
                    "registered", sum(1 for v in results.values() if v is True),
                    len(results))

        # Placeholders for anything this pod does not own, so the fleet
        # reads the same from here as from the API pod.  Today API_OWNED and
        # KNOWN_ORPHANS are empty and this adds nothing; it is here so the
        # two pods cannot drift the day either one gains an entry.
        try:
            from core.daemon_registry import register_remote_placeholders
            register_remote_placeholders()
        except Exception as _ph_exc:
            logger.warning("scheduler_worker: remote placeholders failed "
                           "(non-fatal): %s", _ph_exc)

        # Start the background_jobs registry entries the registrations
        # created (custom_jobs_scheduler, prewarm_background, ...) — each
        # honours its own autostart flag; must run ON the loop.
        try:
            from core import background_jobs as _bj

            async def _bj_autostart():
                _bj.autostart_all()

            asyncio.run_coroutine_threadsafe(_bj_autostart(), _worker_loop)
        except Exception as _bj_exc:
            logger.warning("background_jobs autostart failed (non-fatal): %s",
                           _bj_exc)

    threading.Thread(target=_start_scheduler, daemon=True).start()

    # Give scheduler a moment to initialise before accepting control requests
    await asyncio.sleep(0.5)

    # ── Worker identity ──────────────────────────────────────────────────
    _worker_id = f"{platform.node()}:{os.getpid()}"
    logger.info("Worker ID: %s", _worker_id)

    # ── Start heartbeat thread ───────────────────────────────────────────
    from core.config import horizontal_workers as _hw_cfg
    _heartbeat_thread = threading.Thread(
        target=_heartbeat_loop,
        args=(_worker_id, _hw_cfg.heartbeat_interval_seconds, _sched_cfg.job_pool_size),
        daemon=True,
        name="scheduler-heartbeat",
    )
    _heartbeat_thread.start()

    # 2026-08-20 — the iceberg metadata sync (BF-299), brain DuckDB mirror
    # supervisor (Phase 160), iceberg manifest watcher (Phase C) and Kafka
    # cache consumer (Phase 98-I) blocks that used to live inline here moved
    # VERBATIM into core.daemon_registry.SCHEDULER_OWNED — one boot list for
    # every scheduler-pod daemon, executed by _start_scheduler above.  Their
    # admin job_control toggles are honoured inside the registry entries.

    # Phase E + G (2026-06-08) — Register db_manager with the L2 short-
    # circuit + bootstrap default settings rows.  Idempotent: rows that
    # already exist are NOT overwritten.
    try:
        from core.iceberg_db_first_reader import (
            _set_db_manager as _dbf_set,
            bootstrap_settings as _dbf_bootstrap,
        )
        _dbf_set(_db_manager)
        _dbf_bootstrap(_db_manager)
    except Exception as _dbf_init_exc:
        logger.warning(
            "Phase E/G db_first init in scheduler worker failed "
            "(non-fatal): %s", _dbf_init_exc)

    logger.info(
        "Scheduler worker ready on %s:%d",
        _sched_cfg.worker_host, _sched_cfg.worker_port,
    )

    yield  # ── App is running ──

    # ── Shutdown ─────────────────────────────────────────────────────────
    # 2026-10-14 -- FIRST, inside the grace period: the queue worker this
    # process hosts hands its unfinished feed runs back
    # (core.scheduler.shutdown_scheduler -> core/feed/run_lifecycle.py).
    # Proven live: run after the other steps, the 20 s drain met Docker's
    # 30 s grace and the process was killed mid-shutdown.
    from core.scheduler import shutdown_scheduler
    shutdown_scheduler()
    # Stop Kafka consumer (started via the daemon registry;
    # stop is a safe no-op when it never started).
    try:
        from core.kafka_cache_consumer import stop_kafka_consumer
        stop_kafka_consumer()
    except Exception:
        pass

    _shutdown_event.set()
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        _heartbeat_thread.join(timeout=5)
    logger.info("Scheduler worker stopped")
    # the threads of handed-back runs are NOT waited for (run_lifecycle)
    from core.feed.run_lifecycle import exit_if_work_was_disowned
    exit_if_work_was_disowned(logger)


# ── FastAPI control app ──────────────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio Scheduler Worker",
    docs_url=None,
    redoc_url=None,
    lifespan=_lifespan,
)


@control_app.get("/health")
async def health():
    """Full status — scheduler state + DB connectivity."""
    from core.scheduler import get_scheduler_status
    status = get_scheduler_status()
    db_ok = False
    try:
        if _db_manager:
            _db_manager.get_execution("__sched_health_probe__")
            db_ok = True
    except Exception:
        pass
    return {"status": "ok" if db_ok else "degraded", "database": {"ok": db_ok}, **status}


@control_app.get("/health/live")
async def liveness():
    """K8s liveness — always 200 if process is up."""
    return {"status": "alive"}


@control_app.get("/health/ready")
async def readiness():
    """K8s readiness — checks DB connectivity."""
    db_ok = False
    try:
        if _db_manager:
            _db_manager.get_execution("__sched_ready_probe__")
            db_ok = True
    except Exception:
        pass
    if not db_ok:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={"status": "not_ready", "reason": "database unavailable"})
    return {"status": "ready"}


@control_app.get("/control/status")
async def scheduler_status():
    """Full scheduler state: running, paused, job list with next_run times."""
    from core.scheduler import get_scheduler_status
    return get_scheduler_status()


@control_app.get("/control/daemon-snapshot/{name}")
async def daemon_snapshot(name: str, limit: Optional[int] = None):
    """2026-10-07 -- the in-process state of a daemon THIS process runs, for
    the admin routes the API pod answers (core/daemon_snapshots.py).  An
    allow-list: any other name is 404."""
    import asyncio as _aio
    from core.daemon_snapshots import SNAPSHOTS, local_snapshot
    if name not in SNAPSHOTS:
        raise HTTPException(404, f"no daemon snapshot named {name!r}")
    data = await _aio.to_thread(local_snapshot, name, limit)
    return {"name": name, "data": data}


@control_app.get("/control/background-job-ticks")
async def background_job_ticks():
    """2026-10-07 -- every declared background job's last tick from THIS
    process's ledger (core/background_job_contract.py), for the API pod's
    ``GET /api/admin/background-jobs/ticks``."""
    import asyncio as _aio
    from core.background_job_contract import local_ticks
    return {"jobs": await _aio.to_thread(local_ticks, _db_manager)}


@control_app.get("/control/background-job/{name}/status")
async def background_job_status(name: str, limit: int = 10):
    """2026-10-07 -- one job's status from the process that RUNS it."""
    import asyncio as _aio
    from core.background_job_contract import CONTRACTS, local_status
    if name not in CONTRACTS:
        raise HTTPException(404, f"no background job named {name!r}")
    return await _aio.to_thread(local_status, name, _db_manager, limit=limit)


@control_app.post("/control/background-job/{name}/run-now")
async def background_job_run_now(name: str):
    """2026-10-07 -- ONE tick of a job in the process that owns it; the
    tick's ledger record.  409 when the job declares it cannot run on
    demand or is already running."""
    import asyncio as _aio
    from core.background_job_contract import (CONTRACTS, TickRefused,
                                              local_run_now)
    if name not in CONTRACTS:
        raise HTTPException(404, f"no background job named {name!r}")
    try:
        rec = await _aio.to_thread(local_run_now, name, _db_manager)
    except TickRefused as exc:
        raise HTTPException(exc.status_code, exc.reason)
    rec["name"] = name
    return rec


@control_app.post("/control/pause")
async def pause():
    """Pause all job triggers. Running jobs finish normally."""
    from core.scheduler import pause_scheduler
    ok = pause_scheduler()
    if not ok:
        raise HTTPException(400, "Scheduler not running")
    return {"message": "Scheduler paused"}


@control_app.post("/control/resume")
async def resume():
    """Resume all job triggers."""
    from core.scheduler import resume_scheduler
    ok = resume_scheduler()
    if not ok:
        raise HTTPException(400, "Scheduler not initialised")
    return {"message": "Scheduler resumed"}


@control_app.post("/control/add-job")
async def add_job(req: AddJobRequest):
    """Register a new APScheduler job from a DB schedule record."""
    from core.scheduler import add_schedule
    # Build a minimal schedule record dict matching what add_schedule expects
    record = {
        "id": req.schedule_id,
        "trigger_config": req.trigger_config,
        "name": req.name or f"schedule_{req.schedule_id}",
    }
    try:
        job_id = add_schedule(record)
    except Exception as exc:
        raise HTTPException(500, f"Failed to register job: {exc}")
    return {"job_id": job_id}


@control_app.post("/control/remove-job/{job_id}")
async def remove_job(job_id: str):
    """Remove an APScheduler job by its job ID."""
    from core.scheduler import remove_schedule
    try:
        remove_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to remove job: {exc}")
    return {"message": "Removed", "job_id": job_id}


@control_app.post("/control/pause-job/{job_id}")
async def pause_job(job_id: str):
    """Pause a specific job (keeps trigger, stops firing)."""
    from core.scheduler import pause_schedule
    try:
        pause_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to pause job: {exc}")
    return {"message": "Paused", "job_id": job_id}


@control_app.post("/control/resume-job/{job_id}")
async def resume_job(job_id: str):
    """Resume a paused job."""
    from core.scheduler import resume_schedule
    try:
        next_run = resume_schedule(job_id)
    except Exception as exc:
        raise HTTPException(500, f"Failed to resume job: {exc}")
    return {
        "message": "Resumed",
        "job_id": job_id,
        "next_run": next_run.isoformat() if next_run else None,
    }


@control_app.post("/control/run-now/{schedule_id}")
async def run_now(schedule_id: int):
    """Trigger an immediate out-of-schedule run."""
    from core.scheduler import run_now as _run_now
    try:
        _run_now(schedule_id)
    except Exception as exc:
        raise HTTPException(500, f"Immediate run failed: {exc}")
    return {"message": "Triggered", "schedule_id": schedule_id}


@control_app.post("/control/shutdown")
async def shutdown():
    """Graceful shutdown — stop scheduler and exit."""
    logger.info("Shutdown requested via control API")
    # Schedule the actual exit after response is sent
    def _delayed_exit():
        time.sleep(1)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return {"message": "Shutting down"}


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    import uvicorn
    from core.config import scheduler as _sched_cfg

    host = _sched_cfg.worker_host
    port = _sched_cfg.worker_port

    print(f"[scheduler_worker] Starting on {host}:{port}")

    # Windows Ctrl+C handling
    if sys.platform == "win32":
        def _sigint_handler(signum, frame):
            print("\n[scheduler_worker] Ctrl+C — stopping…")
            os._exit(0)
        signal.signal(signal.SIGINT, _sigint_handler)
        try:
            signal.signal(signal.SIGBREAK, _sigint_handler)
        except (AttributeError, OSError):
            pass

    # TLS -- the SAME rule as main.run_server (core/server_tls.py,
    # 2026-09-29): configured and present -> HTTPS; unconfigured -> plain
    # HTTP; configured but a file missing (or half configured) -> REFUSE to
    # start, naming the path.  Until now this pod checked exists() and
    # quietly served plain HTTP when the mount was absent -- a configured
    # policy becoming a different one.
    from core.config import server as _server_cfg
    from core.server_tls import server_tls_kwargs_or_exit
    ssl_kwargs = server_tls_kwargs_or_exit(_server_cfg, logger, what="scheduler_worker")
    if ssl_kwargs:
        print(f"[scheduler_worker] TLS enabled: {ssl_kwargs['ssl_certfile']}")

    uvicorn.run(
        control_app,
        host=host,
        port=port,
        log_level="info",
        access_log=False,
        **ssl_kwargs,
    )


if __name__ == "__main__":
    main()
