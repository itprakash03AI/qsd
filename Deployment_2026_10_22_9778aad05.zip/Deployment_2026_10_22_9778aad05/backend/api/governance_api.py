"""Change-control API — export, deploy, drift report (BRD §15, Step 8).

Thin HTTP shell over ``core.feed.governance``:

* ``GET  /api/governance/export/{object_type}/{object_id}`` — one object
  as deterministic YAML (raw ``text/yaml``: these are the bytes that go
  in git, byte-identical on every call for an unchanged object);
* ``GET  /api/governance/export/{object_type}`` — every object of a type,
  ``[{path, yaml}]`` (one file per object — a CI job writes these into
  the repo working tree and the diff is the review);
* ``POST /api/governance/deploy`` — apply reviewed definition files to
  an environment, transactionally, recording commit + ticket on every
  row touched (admin-gated; §16.4 platform-operator action);
* ``GET  /api/governance/drift`` — which prod rows no longer match what
  was deployed, answered from the database alone.

The pod never talks to git: a deploy pipeline (CI) reads the repository,
resolves the ref to a commit sha, and POSTs the file CONTENTS plus that
sha.  Secrets can never appear in any response here — exports are
secret-stripped and drift diffs strip both sides (core.feed.governance).
"""
import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

from api.deps import require_admin, require_admin_read
from core.feed import governance
from core.feed.governance import GovernanceError
from core.release import engine
from core.release.contract import ReleaseRefusal
from core.release.registry import load as load_registry

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/governance", tags=["governance"])

# Module-level dependencies (same wiring pattern as api/feed_api.py)
_db_manager = None
_alarm_fn = None


def set_governance_dependencies(db_manager, alarm_fn=None) -> None:
    global _db_manager, _alarm_fn
    _db_manager = db_manager
    _alarm_fn = alarm_fn


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503,
                            detail="governance dependencies not wired")
    return _db_manager


def _check_object_type(object_type: str) -> None:
    if object_type not in governance.GOVERNED_OBJECT_TYPES:
        raise HTTPException(
            status_code=404,
            detail=f"unknown governed object type {object_type!r} — one of "
                   f"{sorted(governance.GOVERNED_OBJECT_TYPES)}")


def _gov_cfg() -> dict[str, Any]:
    from core import config as _config
    return _config.get("feed_generation", "governance", {}) or {}


@router.get("/export/{object_type}/{object_id}")
def export_one(object_type: str, object_id: int,
               _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """One governed object as its git file — raw deterministic YAML."""
    _check_object_type(object_type)
    row = _db().get_governed_object(object_type, object_id)
    if row is None:
        raise HTTPException(status_code=404,
                            detail=f"{object_type} {object_id} not found")
    try:
        # export_BYTES, not the str: this response IS the artifact that
        # lands in a git repo, and the function guarantees UTF-8 with LF
        # terminators — "git-canonical" in its own words.  Handing
        # FastAPI a str delegates the encoding decision to the response
        # layer, which is how a deterministic export stops being
        # deterministic on a different platform.  It had no caller.
        text = governance.export_bytes(row, object_type=object_type)
        path = governance.export_filename(object_type, row.get("name"))
    except GovernanceError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return Response(
        content=text,
        media_type="text/yaml; charset=utf-8",
        headers={"X-Governance-Path": path},
    )


@router.get("/export/{object_type}")
def export_all(object_type: str,
               _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """Every governed object of one type — one (path, yaml) per object."""
    _check_object_type(object_type)
    out: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for row in (_db().list_governed_objects(object_type) or []):
        try:
            out.append({
                "object_id": row.get("id"),
                "path": governance.export_filename(object_type,
                                                   row.get("name")),
                "yaml": governance.export_definition(
                    row, object_type=object_type),
            })
        except GovernanceError as exc:
            # One unexportable row (e.g. unnameable) must not hide the
            # rest of the estate — reported, never silently dropped.
            skipped.append({"object_id": row.get("id"),
                            "error": str(exc)})
    return {"object_type": object_type, "files": out, "skipped": skipped}


class DeployFile(BaseModel):
    path: str = Field(..., min_length=1)
    content: str


class DeployRequest(BaseModel):
    environment: str = Field(..., min_length=1)
    commit: str = Field(..., min_length=1,
                        description="git commit sha the CI job resolved")
    ticket: str | None = Field(None, description="JIRA ticket for this change")
    files: list[DeployFile]


@router.post("/deploy")
def deploy(req: DeployRequest, user: dict = Depends(require_admin)):  # noqa: B008 — FastAPI DI idiom
    """Apply a reviewed git ref's definition files to one environment.

    The CI pipeline reads the repo and posts contents + resolved sha —
    the pod itself has no git access.  Transactional: every row stamped
    or none.  Refused whole when any file is malformed, when any file
    carries a credential-shaped key, or when the JIRA ticket is invalid
    (a tracker OUTAGE follows governance.jira.outage_policy and is
    recorded on the result, never silently ignored)."""
    if not bool(_gov_cfg().get("enabled", False)):
        raise HTTPException(
            status_code=403,
            detail="governance deploys are disabled "
                   "(feed_generation.governance.enabled=false) — export and "
                   "drift remain available in shadow mode")
    try:
        result = governance.apply_deploy(
            _db(),
            environment=req.environment,
            commit=req.commit,
            ticket=req.ticket,
            deployed_by=(user or {}).get("username"),
            files=[f.model_dump() for f in req.files],
        )
    except GovernanceError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return result


@router.get("/drift")
def drift(environment: str,
          _user: dict = Depends(require_admin_read)):  # noqa: B008 — FastAPI DI idiom
    """Which rows no longer match what was deployed — from the DB alone.
    Detection only: nothing is corrected here (§15.2 break-glass)."""
    return governance.drift_report(_db(), environment=environment,
                                   alarm_fn=_alarm_fn)


# ── Configuration RELEASES (2026-10-17, core/release/engine.py) ────────────
# docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3.7.  ONE package, two
# transports (a pipeline posting it, a person uploading it), one apply.

def _refused(exc: Exception) -> HTTPException:
    detail: Any = str(exc)
    if isinstance(exc, ReleaseRefusal):
        detail = exc.to_dict()
    return HTTPException(status_code=422, detail=detail)


def _environment(explicit: str | None = None) -> str:
    return explicit or engine.this_environment()


@router.get("/release/types")
def release_types(_user: dict = Depends(require_admin_read)):  # noqa: B008
    """The registry: what kinds a package may carry, their keys, references,
    environment fields and phase -- answered from the code, never guessed."""
    reg = load_registry()
    return {"types": reg.describe(), "object_types": list(reg.kinds()),
            "release_tables_uncarried": reg.release_tables_uncarried(),
            "environment": engine.this_environment(),
            "git_truth_environments": engine.git_truth_environments(),
            "release_config": engine.release_cfg()}


class ExportRequest(BaseModel):
    scope: dict = Field(default_factory=lambda: {"kind": "everything"},
                        description='{"kind": "everything"|"area"|<object kind>, "keys": [...], '
                                    '"area": "feedgen", "with_dependencies": true, '
                                    '"exclude": [{"kind", "key", "reason"}], "plan": false}')
    source_commit: str | None = Field(None, description="the git commit a pipeline resolved")


@router.post("/release/export")
def release_export(req: ExportRequest, user: dict = Depends(require_admin)):  # noqa: B008
    """Selected objects + their dependency closure -> ONE package (JSON).
    EVERY object the scope cannot release is answered together (422 with
    ``problems``); ``scope.plan`` returns that list without building;
    ``scope.exclude`` leaves objects out deliberately, recorded in the package."""
    try:
        return engine.export_package(_db(), scope=req.scope, actor=(user or {}).get("username"),
                                     source_commit=req.source_commit)
    except ReleaseRefusal as exc:
        raise _refused(exc)


class UploadRequest(BaseModel):
    package: dict
    environment: str | None = Field(None, description="defaults to this deployment's environment")
    ticket: str | None = None
    options: dict | None = None


@router.post("/release/upload", status_code=201)
def release_upload(req: UploadRequest, user: dict = Depends(require_admin)):  # noqa: B008
    """Scan (secrets, checksum, kinds, required config keys) and record a
    release in state ``uploaded``.  Refused whole on any finding."""
    try:
        return engine.upload(_db(), req.package, environment=_environment(req.environment),
                             actor=(user or {}).get("username"), ticket=req.ticket,
                             options=req.options)
    except ReleaseRefusal as exc:
        raise _refused(exc)


@router.get("/releases")
def release_list(environment: str | None = None, limit: int = 100,
                 _user: dict = Depends(require_admin_read)):  # noqa: B008
    return {"environment": _environment(environment),
            "releases": _db().list_config_releases(_environment(environment), limit=limit)}


@router.get("/release/{release_id}")
def release_get(release_id: int, with_package: bool = False,
                _user: dict = Depends(require_admin_read)):  # noqa: B008
    rel = _db().get_config_release(release_id, with_package=with_package)
    if rel is None:
        raise HTTPException(status_code=404, detail=f"release {release_id} not found")
    rel["ledger"] = _db().list_release_ledger(release_id)
    return rel


@router.post("/release/{release_id}/preview")
def release_preview(release_id: int, user: dict = Depends(require_admin)):  # noqa: B008
    """Resolve names through the mapping; the three-way diff per object and
    field; refusals for every unmapped environment value."""
    try:
        return engine.preview(_db(), release_id, actor=(user or {}).get("username"))
    except ReleaseRefusal as exc:
        raise _refused(exc)


class DecisionsRequest(BaseModel):
    decisions: dict = Field(..., description='{"kind|key": {"field.path": "take_release"|"keep_prod"}}')


@router.put("/release/{release_id}/decisions")
def release_decide(release_id: int, req: DecisionsRequest,
                   user: dict = Depends(require_admin)):  # noqa: B008
    try:
        return engine.decide(_db(), release_id, req.decisions, actor=(user or {}).get("username"))
    except ReleaseRefusal as exc:
        raise _refused(exc)


class ApproveRequest(BaseModel):
    ticket: str | None = None
    note: str | None = None


@router.post("/release/{release_id}/approve")
def release_approve(release_id: int, req: ApproveRequest | None = None,
                    user: dict = Depends(require_admin)):  # noqa: B008
    req = req or ApproveRequest()
    try:
        return engine.approve(_db(), release_id, actor=(user or {}).get("username"),
                              ticket=req.ticket, note=req.note)
    except ReleaseRefusal as exc:
        raise _refused(exc)


async def _render_template_members(followups: list[dict], user: dict) -> list[dict]:
    """A released template's MEMBERS are derived: re-render them through the
    template routes (every authoring rule holds; 202 job above the inline
    size).  Reported per template, never silently."""
    out = []
    if not followups:
        return out
    from fastapi import Response as _Response
    from api import feed_template_api as _fta
    for f in followups:
        try:
            resp = _Response()
            res = await _fta.apply_feed_template(int(f["object_id"]), resp, None, user)
            out.append({"template": f["key"], "status": resp.status_code or 200,
                        "report": (res or {}).get("report"), "job": (res or {}).get("job")})
        except HTTPException as exc:
            out.append({"template": f["key"], "status": exc.status_code, "error": str(exc.detail)})
        except Exception as exc:  # noqa: BLE001 -- named per template, the release is applied
            out.append({"template": f["key"], "status": 500, "error": f"{type(exc).__name__}: {exc}"})
    return out


@router.post("/release/{release_id}/apply")
async def release_apply(release_id: int, user: dict = Depends(require_admin)):  # noqa: B008
    """ONE transaction (snapshot + every object + every ledger row), then the
    template member walk, then verification.  The release's state says what
    happened: applied -> verified | applied_unverified, or failed."""
    actor = (user or {}).get("username")
    try:
        out = engine.apply(_db(), release_id, actor=actor)
    except ReleaseRefusal as exc:
        raise _refused(exc)
    out["members"] = await _render_template_members(out.get("followups") or [], user)
    try:
        verified = engine.verify(_db(), release_id, actor=actor)
        out["state"], out["verification"] = verified["state"], verified.get("verification")
    except ReleaseRefusal as exc:
        out["verification_error"] = str(exc)
    return out


@router.post("/release/{release_id}/verify")
def release_verify(release_id: int, user: dict = Depends(require_admin)):  # noqa: B008
    try:
        return engine.verify(_db(), release_id, actor=(user or {}).get("username"))
    except ReleaseRefusal as exc:
        raise _refused(exc)


@router.post("/release/{release_id}/rollback")
def release_rollback(release_id: int, user: dict = Depends(require_admin)):  # noqa: B008
    """A new release from the snapshot; objects the release created are
    deactivated and named.  Four-eyes is waived for a rollback, recorded."""
    try:
        return engine.rollback(_db(), release_id, actor=(user or {}).get("username"))
    except ReleaseRefusal as exc:
        raise _refused(exc)


class MappingsRequest(BaseModel):
    environment: str | None = None
    mappings: list[dict] = Field(..., description="[{kind, from_value, to_value, note}]; empty to_value deletes")


@router.get("/release/mappings")
def release_mappings(environment: str | None = None,
                     _user: dict = Depends(require_admin_read)):  # noqa: B008
    env = _environment(environment)
    return {"environment": env, "mappings": _db().list_release_mappings(env)}


@router.put("/release/mappings")
def release_mappings_put(req: MappingsRequest, user: dict = Depends(require_admin)):  # noqa: B008
    env = _environment(req.environment)
    try:
        rows = _db().upsert_release_mappings(env, req.mappings, created_by=(user or {}).get("username"))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    from core.audit import audit_event
    audit_event(_db(), user, None, "release.mappings", "release_mapping", None,
                {"environment": env, "rows": len(req.mappings)})
    return {"environment": env, "mappings": _db().list_release_mappings(env), "written": rows}
