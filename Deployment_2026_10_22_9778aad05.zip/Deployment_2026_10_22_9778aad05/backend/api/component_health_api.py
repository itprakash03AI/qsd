"""Component health, one place -- the routes (2026-10-17).

* ``GET  /api/admin/component-health``            the page (admin-read: admin + support)
* ``GET  /api/admin/component-health/registry``   the declared checks (the UI builds from it)
* ``GET  /api/admin/component-health/events``     confirmed transitions
* ``GET  /api/admin/component-health/{component_id}``  one component: rows, events, intents, alert
* ``POST /api/admin/component-health/controls``   a control (admin, rate-limited, audited)
* ``DELETE /api/admin/component-health/intents/{id}``  withdraw a pending intent

Every value is computed in ``core/component_health``; this module holds the
wiring, the role gates, the ETag and the audit call.  A control is never run
on this pod for another pod: it is an intent row the owner applies, or the
existing one-path mechanism (background_job_state, run_now).
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from api.deps import require_admin_rate_limited, require_admin_read
from core.audit import audit_event
from core.component_health import intents as _intents
from core.component_health.reader import TableUnreadable, collect, component_detail
from core.component_health.vocabulary import (
    CONTROLS, CONTROL_PAUSE, CONTROL_RESUME, CONTROL_RUN_NOW, INTENT_CONTROLS, KINDS, STATES,
)
from core.db_async import adb
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin/component-health", tags=["component-health"])

_db_manager: Any = None
_proxy: Any = None


def set_component_health_dependencies(db_manager: Any, scheduler_worker_proxy: Any = None) -> None:
    global _db_manager, _proxy
    _db_manager = db_manager
    _proxy = scheduler_worker_proxy


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not available")
    return _db_manager


# ── reads ────────────────────────────────────────────────────────────────────

@router.get("")
async def get_component_health(request: Request, response: Response,
                               kind: Optional[str] = Query(None), state: Optional[str] = Query(None),
                               pod: Optional[str] = Query(None), q: Optional[str] = Query(None),
                               user: dict = Depends(require_admin_read)):
    """The page: every pod's rows (silence rules applied), the fleet rows,
    open intents, the four counts and the headline.  ``If-None-Match`` ->
    304.  An unreadable table is a 503 WITH the reason and this pod's
    in-memory rows -- never an empty page."""
    if kind and kind not in KINDS:
        raise HTTPException(status_code=400, detail=f"kind must be one of {list(KINDS)}")
    if state and state not in STATES:
        raise HTTPException(status_code=400, detail=f"state must be one of {list(STATES)}")
    db = _db()
    # the poller's common case, served before the thread hop: the page this
    # process built within page_cache_seconds has the ETag the browser holds
    # (2026-10-18, C10: 100 pollers on a 2-CPU pod queued on the executor)
    if not (kind or state or pod or q):
        from core.component_health.reader import cached_etag
        held = request.headers.get("if-none-match")
        fresh = cached_etag()
        if held and fresh and held == fresh:
            return Response(status_code=304, headers={"ETag": fresh})
    try:
        body = await adb(collect, db, kind=kind, state=state, pod=pod, q=q,
                         controls_allowed=is_admin_like(user))
    except TableUnreadable as exc:
        from core.component_health.reader import _this_pod
        return JSONResponse(status_code=503, content={
            "detail": str(exc), "read": {"ok": False, "reason": str(exc)}, "this_pod": _this_pod()})
    etag = body.get("etag")
    if etag and request.headers.get("if-none-match") == etag and not (kind or state or pod or q):
        return Response(status_code=304, headers={"ETag": etag})
    if etag:
        response.headers["ETag"] = etag
    return body


@router.get("/registry")
async def get_registry(user: dict = Depends(require_admin_read)):
    """The declared checks: kind, scope, owner, controls, legacy routes,
    docs.  The UI builds its groups and buttons from this."""
    from core.component_health.registry import load
    reg = load()
    return {"checks": reg.describe(), "controls": list(CONTROLS), "states": list(STATES),
            "intent_controls": list(INTENT_CONTROLS)}


@router.get("/events")
async def get_events(component_id: Optional[str] = Query(None), limit: int = Query(100, ge=1, le=1000),
                     user: dict = Depends(require_admin_read)):
    db = _db()
    return {"events": await adb(db.list_component_health_events, component_id=component_id, limit=limit)}


@router.get("/intents")
async def get_intents(status: Optional[str] = Query(None), limit: int = Query(100, ge=1, le=1000),
                      user: dict = Depends(require_admin_read)):
    db = _db()
    statuses = [s for s in (status or "").split(",") if s] or None
    return {"intents": await adb(db.list_component_intents, status=statuses, limit=limit)}


@router.get("/{component_id:path}")
async def get_component(component_id: str, user: dict = Depends(require_admin_read)):
    db = _db()
    detail = await adb(component_detail, db, component_id)
    if detail.get("declared") is None and not detail.get("rows"):
        raise HTTPException(status_code=404, detail=f"unknown component {component_id!r}")
    return detail


# ── controls ─────────────────────────────────────────────────────────────────

class ControlRequest(BaseModel):
    control: str
    component_id: str
    target_pod_id: Optional[str] = None
    reason: str = Field("", max_length=2000)
    expires_in_minutes: Optional[int] = Field(None, ge=0, le=7 * 24 * 60)
    dry_run: bool = False


def _audit(db, user: dict, request: Request, control: str, component_id: str, details: Dict[str, Any]) -> None:
    audit_event(db, user, request, f"component_health.{control}", "component", component_id, details)


async def _daemon_name(component_id: str) -> str:
    if not component_id.startswith("daemon:"):
        raise HTTPException(status_code=409, detail=f"{component_id} is not a daemon")
    return component_id.split(":", 1)[1]


async def _apply_existing_control(db, body: ControlRequest, user: dict) -> Dict[str, Any]:
    """pause / resume / run_now keep their ONE existing mechanism."""
    if body.component_id == "dependency:scheduler" and body.control in (CONTROL_PAUSE, CONTROL_RESUME):
        from core.config import scheduler as _sched_cfg
        if str(_sched_cfg.mode) == "external":
            if _proxy is None:
                raise HTTPException(status_code=503, detail="the scheduler worker proxy is not wired")
            return {"applied": "scheduler_worker", **(await _proxy("POST", f"/control/{body.control}") or {})}
        from core.scheduler import pause_scheduler, resume_scheduler
        ok = pause_scheduler() if body.control == CONTROL_PAUSE else resume_scheduler()
        if not ok:
            raise HTTPException(status_code=409, detail="the scheduler is not running in this process")
        return {"applied": "this_process", "message": f"scheduler {body.control}d"}
    name = await _daemon_name(body.component_id)
    from core import background_jobs as _bj
    if body.control == CONTROL_RUN_NOW:
        from core import background_job_contract as _bjc
        if name not in _bjc.CONTRACTS:
            raise HTTPException(status_code=409, detail=f"{name} has no run-now contract")
        try:
            rec = await _bjc.run_now(name, db, proxy=_proxy)
        except _bjc.TickRefused as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.reason)
        return {"applied": rec.get("answered_by") or "owner", "tick": rec}
    # pause / resume run ON the loop, as /api/admin/background-jobs/{name}/*
    # do: resume() -> start() needs the running loop to launch a local task
    # (a remote placeholder only clears the flag; the owner's reconciler
    # resumes it within 5 s).  The DB write inside is one small row.
    try:
        if body.control == CONTROL_PAUSE:
            return {"applied": "background_job_state", **_bj.pause(name, paused_by=user.get("username"))}
        return {"applied": "background_job_state", **_bj.resume(name)}
    except KeyError:
        raise HTTPException(status_code=404, detail=f"unknown background job: {name}")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))


@router.post("/controls")
async def post_control(body: ControlRequest, request: Request,
                       user: dict = Depends(require_admin_rate_limited)):
    """ONE route for every control.  Refuses an undeclared (component,
    control) pair (409), an empty reason (400), an unknown component (404).
    Intent controls return 202 while another pod must apply them; the
    existing-mechanism controls return 200.  Every call is audited with the
    computed consequence.  ``dry_run`` returns the consequence only."""
    db = _db()
    from core.component_health.registry import load
    reg = load()
    check = reg.get(body.component_id)
    if check is None:
        raise HTTPException(status_code=404, detail=f"unknown component {body.component_id!r}")
    if body.control not in CONTROLS:
        raise HTTPException(status_code=409, detail=f"{body.control!r} is not a control; the vocabulary is {list(CONTROLS)}")
    if body.control not in check.controls:
        raise HTTPException(status_code=409, detail=f"{body.control!r} is not a control of {body.component_id}; "
                                                    f"it declares {list(check.controls) or 'none'}")
    if not body.reason.strip():
        raise HTTPException(status_code=400, detail="a reason is required")
    target = body.target_pod_id or ("*" if body.control == "reset_breaker" else None)
    consequence = await adb(_intents.consequence_of, db, body.control, body.component_id, target or "")
    if body.dry_run:
        return {"dry_run": True, "control": body.control, "component_id": body.component_id,
                "target_pod_id": target, "consequence": consequence}
    details: Dict[str, Any] = {"target_pod_id": target, "reason": body.reason.strip(), "consequence": consequence}
    if body.control in INTENT_CONTROLS:
        try:
            intent = await adb(_intents.request, db, control=body.control, component_id=body.component_id,
                               requested_by=user.get("username") or "unknown", reason=body.reason,
                               target_pod_id=body.target_pod_id, expires_in_minutes=body.expires_in_minutes,
                               registry=reg)
        except _intents.IntentRefused as exc:
            raise HTTPException(status_code=exc.status_code, detail=exc.reason)
        details.update({"intent_id": intent["id"], "expires_at": intent.get("expires_at")})
        _audit(db, user, request, body.control, body.component_id, details)
        from core.component_health.reader import invalidate_cache
        invalidate_cache()
        return JSONResponse(status_code=202, content={"intent": intent, "consequence": consequence,
                                                     "note": "pending until the owning pod applies it"})
    result = await _apply_existing_control(db, body, user)
    details["result"] = {k: v for k, v in result.items() if k in ("applied", "message", "status", "paused")}
    _audit(db, user, request, body.control, body.component_id, details)
    from core.component_health.reader import invalidate_cache
    invalidate_cache()
    return {"control": body.control, "component_id": body.component_id, "consequence": consequence, **result}


class PlantRequest(BaseModel):
    seconds: int = Field(60, ge=1, le=600)
    tag: str = Field(..., min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_-]+$")


@router.post("/plant-slow-probe")
async def plant_slow_probe(body: PlantRequest, request: Request, user: dict = Depends(require_admin_rate_limited)):
    """TEST SEAM for the Docker proof (design §6 C11), 404 unless
    ``component_health.planted_probe_enabled``: registers a fleet dependency
    whose probe sleeps ``seconds`` -- the fleet watcher probes it on its next
    tick and the row must read ``unknown: probe exceeded`` while every other
    row of that tick still lands.  Audited; removed with DELETE."""
    from core.config import component_health as _cfg
    if not _cfg.planted_probe_enabled:
        raise HTTPException(status_code=404, detail="Not Found")
    import time as _time
    from core.component_health.contract import HealthCheck, Observation
    from core.component_health.registry import load
    from core.component_health.vocabulary import (CONTROL_PROBE_NOW, HEALTHY, KIND_DEPENDENCY, OWNER_FLEET_WATCHER,
                                                  SCOPE_FLEET)
    cid = f"dependency:planted_{body.tag}"
    seconds = int(body.seconds)

    def _sleepy(_ctx):
        _time.sleep(seconds)
        return Observation(HEALTHY, "slept through its budget")
    load().register(HealthCheck(component_id=cid, kind=KIND_DEPENDENCY, label=f"planted probe {body.tag}",
                                scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER, probe=_sleepy, timeout_seconds=3.0,
                                interval_seconds=15, controls=(CONTROL_PROBE_NOW,), group="test",
                                docs="a planted probe that sleeps past its budget (Docker proof C11)"), replace=True)
    _audit(_db(), user, request, "plant_slow_probe", cid, {"seconds": seconds})
    return {"component_id": cid, "seconds": seconds}


@router.delete("/plant-slow-probe/{tag}")
async def unplant_slow_probe(tag: str, request: Request, user: dict = Depends(require_admin_rate_limited)):
    from core.config import component_health as _cfg
    if not _cfg.planted_probe_enabled:
        raise HTTPException(status_code=404, detail="Not Found")
    from core.component_health.registry import load
    from core.component_health.vocabulary import FLEET_POD_ID
    cid = f"dependency:planted_{tag}"
    removed = load().unregister(cid)
    try:
        _db().delete_component_health(pod_id=FLEET_POD_ID, component_ids=[cid])
    except Exception as exc:                                # noqa: BLE001
        logger.debug("planted row not removed: %s", exc)
    _audit(_db(), user, request, "unplant_slow_probe", cid, {"removed": removed})
    return {"component_id": cid, "removed": removed}


@router.delete("/intents/{intent_id}")
async def withdraw_intent(intent_id: int, request: Request, user: dict = Depends(require_admin_rate_limited)):
    db = _db()
    try:
        row = await adb(_intents.withdraw, db, intent_id, by=user.get("username") or "unknown")
    except _intents.IntentRefused as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.reason)
    if row is None:
        raise HTTPException(status_code=404, detail=f"unknown intent #{intent_id}")
    _audit(db, user, request, "withdraw", row["component_id"], {"intent_id": intent_id, "control": row["control"]})
    from core.component_health.reader import invalidate_cache
    invalidate_cache()
    return {"intent": row}


__all__ = ["router", "set_component_health_dependencies"]
