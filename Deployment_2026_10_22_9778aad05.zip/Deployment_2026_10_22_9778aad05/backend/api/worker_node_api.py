"""BF-384 — Option G: FastAPI routes for worker-pod mode.

A pod with ``QS_NODE_ROLE=worker`` runs only these endpoints:

  * ``POST /api/worker/run-chunk``  — accept a chunk request, return Arrow IPC
  * ``GET  /api/worker/health``     — liveness + last-request timestamp
  * ``GET  /api/worker/ready``      — readiness probe (DuckDB warmed up)
  * ``GET  /api/worker/stats``      — per-process counters (auth-guarded)

In coordinator pods these routes are ALSO mounted (so a single node can
dispatch to itself for dev / single-pod deploys), but they're gated by
the HMAC signature header in both modes.

The coordinator's multi_pod_dispatcher only calls these endpoints via
the worker registry — never directly. So request paths from outside
the cluster (load balancer, ingress) are not exposed.
"""
from __future__ import annotations

import json
import logging
import time

from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import Response, JSONResponse

from core.query_worker_node import (
    ChunkExecRequest,
    execute_chunk,
    get_worker_stats,
    is_worker_mode,
    verify_signature,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["worker"])

# Deep-dive round 3: reject oversized payloads.  A request body has at most:
#   - setup_sql:    a few KB (multi-CREATE-VIEW)
#   - partial_sql:  a few KB
#   - duckdb_settings: <1KB
#   - file lists embedded in setup_sql: could be a few hundred KB for 5000 files
# 10 MB is a generous upper bound that still blocks abuse.
_MAX_WORKER_PAYLOAD_BYTES = 10 * 1024 * 1024


@router.post("/api/worker/run-chunk")
async def worker_run_chunk(
    request: Request,
    x_qs_worker_signature: str = Header(default=""),
    x_qs_worker_correlation: str = Header(default=""),
):
    """Execute one chunk and return Arrow IPC bytes.

    Request body: JSON serialized ``ChunkExecRequest``.

    Response: ``application/vnd.apache.arrow.stream`` (raw IPC bytes).
    Metadata (row_count, elapsed, error) returned in trailing JSON
    headers — we put them in ``X-QS-Worker-Meta`` as URL-safe base64
    of JSON for easy parsing on the coordinator side.

    Deep-dive round 3 hardening:
      * Body size cap (reject > 10 MB to prevent abuse).
      * Payload type guard (must be a JSON object, not array/string).
    """
    body = await request.body()
    if len(body) > _MAX_WORKER_PAYLOAD_BYTES:
        raise HTTPException(
            413,
            f"Worker payload too large: {len(body)} bytes (max {_MAX_WORKER_PAYLOAD_BYTES})",
        )
    if not verify_signature(body, x_qs_worker_signature):
        raise HTTPException(401, "Invalid worker signature")

    try:
        payload = json.loads(body.decode("utf-8")) if body else {}
    except Exception as parse_err:
        raise HTTPException(400, f"Invalid JSON body: {parse_err}")

    # Deep-dive round 3: payload must be a JSON object (dict).  A valid
    # JSON value could be a list, string, or number — those would crash
    # the next line.  Refuse non-objects with a clear error.
    if not isinstance(payload, dict):
        raise HTTPException(
            400,
            f"Worker payload must be a JSON object, got {type(payload).__name__}",
        )

    if x_qs_worker_correlation and "correlation_id" not in payload:
        payload["correlation_id"] = x_qs_worker_correlation

    req = ChunkExecRequest.from_dict(payload)
    meta, ipc_bytes = execute_chunk(req)

    # Encode metadata in a header (base64 of JSON) so the coordinator can
    # read it before deserializing the Arrow stream.
    import base64
    meta_header = base64.urlsafe_b64encode(
        json.dumps(meta.to_dict()).encode("utf-8")
    ).decode("ascii")

    status_code = 200 if meta.error is None else 500
    return Response(
        content=ipc_bytes,
        media_type="application/vnd.apache.arrow.stream",
        status_code=status_code,
        headers={
            "X-QS-Worker-Meta":       meta_header,
            "X-QS-Worker-Correlation": meta.correlation_id or "",
        },
    )


@router.get("/api/worker/health")
async def worker_health():
    """Liveness probe — always 200 when the process is running."""
    return {
        "status":        "alive",
        "role":          "worker" if is_worker_mode() else "coordinator+worker",
        "timestamp":     time.time(),
        "last_request":  get_worker_stats().get("last_request_at", 0),
    }


@router.get("/api/worker/ready")
async def worker_ready():
    """Readiness probe — returns 200 only when the worker can ACTUALLY
    execute chunks.  K8s removes the pod from the Service's endpoints
    when this fails, so dispatchers stop hitting unready workers.

    Checks:
      1. DuckDB can be imported + create an in-memory connection
      2. HMAC secret is configured (worker mode only)
    """
    # 1. DuckDB sanity check
    try:
        import duckdb
        _c = duckdb.connect(":memory:")
        _c.execute("SELECT 1").fetchone()
        _c.close()
    except Exception as exc:
        return JSONResponse(
            status_code=503,
            content={"ready": False, "reason": f"DuckDB init failed: {exc}"},
        )

    # 2. Auth configuration check (worker mode only — coordinator skips)
    if is_worker_mode():
        from core.query_worker_node import _get_shared_secret
        if not _get_shared_secret():
            return JSONResponse(
                status_code=503,
                content={
                    "ready": False,
                    "reason": "HMAC secret not configured for worker mode "
                              "(set QS_WORKER_SECRET or multi_pod.shared_secret)",
                },
            )

    return {"ready": True, "role": "worker" if is_worker_mode() else "coordinator+worker"}


@router.get("/api/worker/stats")
async def worker_stats(
    request: Request,
    x_qs_worker_signature: str = Header(default=""),
):
    """Per-process counters (requests, rows, elapsed).

    Deep-dive round 3: HMAC-protected in worker mode to prevent
    information disclosure to unauthorized callers.  Coordinator mode
    leaves it open since it's not externally exposed.
    """
    # Use a stable signed payload so we can verify without a body.
    if x_qs_worker_signature and verify_signature(b"worker-stats", x_qs_worker_signature):
        return get_worker_stats()
    if is_worker_mode():
        raise HTTPException(401, "Invalid worker signature")
    # 2026-10-18 -- a coordinator answered ANY caller ("not externally exposed"
    # was not true: it sits behind the same route as the UI).  Without a valid
    # signature it is an admin's (or support's) read, like every other counter.
    from api.deps import get_current_user, require_admin_read
    require_admin_read(get_current_user(request))
    return get_worker_stats()
