"""
System health, metrics, version, and observability endpoints.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_system_dependencies(db_manager, engine, paths, qe_cfg)`` once at startup.
"""
from __future__ import annotations

import logging
import platform
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, Request

from core.execution_state import running_tasks

logger = logging.getLogger(__name__)

router = APIRouter(tags=["System"])

# ── Module-level singletons ───────────────────────────────────────────────────
_db_manager = None   # DatabaseManager
_engine     = None   # ParquetQueryEngine
_paths      = None   # core.config.paths
_qe_cfg     = None   # core.config.query_engine
# Deep-dive #7 (2026-06-30): /metrics endpoint init must be atomic
# under concurrent scrapes (two threads can hit the NameError branch
# in parallel and re-zero _brain_prune_last_seen mid-flight, causing
# spiky Prometheus counters).
_BRAIN_METRICS_INIT_LOCK = threading.Lock()

# Consecutive DB failure counter for liveness probe stability — thread-safe via lock
_db_consecutive_failures: int = 0
_db_fail_lock = threading.Lock()

# 2026-07-13 — PROBE STARVATION FIX.  Root cause of pod restarts (no OOM):
# the K8s liveness probe hit /health(/live), whose DB check ran on the SHARED
# default asyncio thread pool (min(32, cpu+4) ≈ 8 threads on a 4-CPU pod).
# Under iceberg/query load that pool saturates, so ``await asyncio.to_thread
# (db_check)`` QUEUES and never returns within the probe's 5s timeoutSeconds →
# "client.timeout exceeded while awaiting header" → failureThreshold breached
# → kubelet restarts the pod (a self-inflicted restart, not a real fault).
#
# Fix: run probe DB checks on a DEDICATED 2-thread executor (query load can't
# starve it) AND wrap them in a HARD timeout.  A TIMEOUT means "busy/loaded",
# NOT "dead" — so liveness FAILS OPEN (stays alive) on timeout and only a
# COMPLETED real DB error counts toward the restart threshold (preserving the
# corrupted-SQLite auto-recover-via-restart intent).
from concurrent.futures import ThreadPoolExecutor as _ThreadPoolExecutor  # noqa: E402
_probe_executor = _ThreadPoolExecutor(max_workers=2, thread_name_prefix="qs-health-probe")


def _probe_timeout_seconds() -> float:
    try:
        from core.config import health as _h_cfg
        return float(getattr(_h_cfg, "probe_timeout_seconds", 3.0) or 3.0)
    except Exception:
        return 3.0


async def _probe_db_check(probe_key: str) -> str:
    """Run the SQLite liveness read on the dedicated probe executor with a
    hard timeout.  Returns 'ok' | 'fail' | 'timeout'.  Never raises, never
    hangs longer than the probe timeout — so the endpoint always answers the
    kubelet well inside its timeoutSeconds."""
    import asyncio as _asyncio

    def _do() -> bool:
        try:
            if _db_manager:
                _db_manager.get_execution(probe_key)  # returns None, never raises
                return True
        except Exception as exc:
            logger.debug("Probe DB check (%s) failed: %s", probe_key, exc)
        return False

    loop = _asyncio.get_event_loop()
    try:
        ok = await _asyncio.wait_for(
            loop.run_in_executor(_probe_executor, _do),
            timeout=_probe_timeout_seconds(),
        )
        return "ok" if ok else "fail"
    except _asyncio.TimeoutError:
        # Busy/loaded — NOT dead.  Liveness stays alive; readiness treats as
        # not-ready.  Either way the endpoint responds fast (no client timeout).
        logger.warning(
            "Probe DB check (%s) TIMED OUT after %.1fs (pool busy) — "
            "responding fast, treating as fail-open for liveness",
            probe_key, _probe_timeout_seconds(),
        )
        return "timeout"


def _coerce_json(obj):
    """Recursively convert non-JSON-serializable values to safe primitives.

    Used for the 503 health response to prevent serialization errors when
    test mocks or uninitialized engine objects leak into the response body.
    FastAPI's jsonable_encoder handles the normal 200 return path; this
    guard covers the explicit JSONResponse(503, content=body) path.
    """
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        return {str(k): _coerce_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_coerce_json(v) for v in obj]
    return str(obj)

# Prometheus counters — injected from main.py so all routers share the same registry
_prom_pool_active = None
_prom_pool_queued = None

API_VERSION = "2.0.0"
API_MAJOR   = "v2"


def set_system_dependencies(db_manager, engine, paths, qe_cfg,
                             prom_pool_active=None, prom_pool_queued=None) -> None:
    """Called once from main.py after components are created."""
    global _db_manager, _engine, _paths, _qe_cfg
    global _prom_pool_active, _prom_pool_queued
    _db_manager        = db_manager
    _engine            = engine
    _paths             = paths
    _qe_cfg            = qe_cfg
    _prom_pool_active  = prom_pool_active
    _prom_pool_queued  = prom_pool_queued


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/version", tags=["System"])
async def api_version():
    """Return API version information. Useful for clients to detect server capabilities."""
    return {
        "version": API_VERSION,
        "api_version": API_MAJOR,
        "name": "QueryStudio",
        "python": platform.python_version(),
    }


@router.get("/metrics", include_in_schema=False)
async def prometheus_metrics():
    """Prometheus scrape endpoint — no auth required (standard practice)."""
    from starlette.responses import Response as _StarletteResponse
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

    # Update worker pool gauges before scrape
    try:
        from core.worker_pool import get_pool
        pool = get_pool()
        if pool and _prom_pool_active and _prom_pool_queued:
            stats = pool.get_stats()
            for wtype, info in stats.get("by_type", {}).items():
                _prom_pool_active.labels(work_type=wtype).set(info.get("running", 0))
                _prom_pool_queued.labels(work_type=wtype).set(info.get("queued", 0))
    except Exception:
        pass  # metrics must never crash

    # Phase 139 (Tier 2.3): publish cache-layer gauges from LocalCache registry
    try:
        from core.metrics import export_cache_layer_stats
        export_cache_layer_stats()
    except Exception:
        pass

    # 2026-06-30 deep-dive add-on: surface DB-degraded mode + counters
    # via Prometheus so operators can alert on "brain skipped pruning
    # because postgres slow" without grepping logs.
    try:
        from core.db_health_monitor import get_monitor as _dbh_get
        from prometheus_client import Gauge as _PromGauge
        _snap = _dbh_get().snapshot()
        # Lazy-create the gauges (idempotent thanks to Prometheus' name dedupe).
        global _db_health_gauges
        try:
            _db_health_gauges
        except NameError:
            _db_health_gauges = {
                "degraded":       _PromGauge("qs_db_health_degraded",
                                              "1 when brain is skipping DB pruning lookups"),
                "p95_ms":         _PromGauge("qs_db_health_recent_p95_ms",
                                              "Rolling-window p95 of manifest_stats DB calls (ms)"),
                "total_timeouts": _PromGauge("qs_db_health_total_timeouts",
                                              "Cumulative manifest_stats DB timeouts"),
                "consecutive":    _PromGauge("qs_db_health_consecutive_timeout",
                                              "Current consecutive timeout count"),
            }
        _db_health_gauges["degraded"].set(1 if _snap["degraded"] else 0)
        _db_health_gauges["p95_ms"].set(float(_snap["recent_p95_ms"]))
        _db_health_gauges["total_timeouts"].set(int(_snap["total_timeouts"]))
        _db_health_gauges["consecutive"].set(int(_snap["consecutive_timeout"]))
    except Exception:
        pass    # metrics MUST never crash

    # 2026-06-30 deep-dive #2: per-layer pruning effectiveness so ops
    # can answer "is the bloom actually pruning?" with a metric instead
    # of grepping logs.  Counters are process-lifetime cumulative;
    # Prometheus rate() makes per-second / per-minute trivial.
    try:
        from core.brain_decision_log import get_prune_counters
        from prometheus_client import Counter as _PromCounter, REGISTRY as _PROM_REG
        _pc = get_prune_counters()
        global _brain_prune_counters

        # Deep-dive #4 (2026-06-30): Counter() raises ValueError on
        # duplicate name -- happens after uvicorn --reload / pytest
        # fixture reload / hot-patch because prometheus_client's
        # REGISTRY is PROCESS-global, not module-global.  Without the
        # _safe_counter wrapper, all qs_brain_* metrics silently
        # disappear after the first reload (caught by the outer
        # try/except).  Pattern: try create; on dup, fetch existing
        # collector from REGISTRY by name.
        def _safe_counter(name: str, desc: str):
            try:
                return _PromCounter(name, desc)
            except ValueError:
                existing = getattr(_PROM_REG, "_names_to_collectors", {}).get(name)
                if existing is None:
                    # Final fallback: walk the collector map.
                    for col in list(getattr(_PROM_REG, "_collector_to_names", {})):
                        names = _PROM_REG._collector_to_names.get(col) or set()
                        if name in names:
                            existing = col
                            break
                if existing is None:
                    raise    # genuinely no existing collector
                # Deep-dive #5 (2026-06-30): verify the existing collector
                # is a Counter (not a Gauge / Histogram).  hasattr("inc")
                # is INSUFFICIENT -- Gauge also has .inc() (it's mutable
                # both ways).  Must compare the actual class.  Reusing a
                # Gauge here would scrape OK but the metric semantics
                # would diverge from "files pruned cumulative" -- the
                # Gauge could be set back down by other code.
                if not isinstance(existing, _PromCounter):
                    raise TypeError(
                        f"existing prom collector named {name!r} is "
                        f"{type(existing).__name__}, not Counter -- "
                        f"refusing to reuse"
                    )
                return existing

        # Deep-dive #7 (2026-06-30): module-global init must be
        # atomic.  Two concurrent /metrics scrapes both hit NameError,
        # both call _safe_counter (idempotent via REGISTRY), but BOTH
        # would re-zero _brain_prune_last_seen.  Whichever runs second
        # zeroes the first scrape's "last seen" cache -> next delta is
        # cur - 0 = cumulative total -> Prometheus counter spikes.
        # Lock + double-checked init avoids the race.
        with _BRAIN_METRICS_INIT_LOCK:
            try:
                _brain_prune_counters
                _initialized = True
            except NameError:
                _initialized = False
            if not _initialized:
                _brain_prune_counters = {
                    "manifest":   _safe_counter("qs_brain_files_manifest_pruned_total",
                                                  "Files dropped by manifest min/max bounds"),
                    "supplement": _safe_counter("qs_brain_files_supplement_pruned_total",
                                                  "Files dropped by supplement-bounds DB"),
                    "bloom":      _safe_counter("qs_brain_files_bloom_pruned_total",
                                                  "Files dropped by bloom sidecar"),
                    "scanned":    _safe_counter("qs_brain_files_scanned_total",
                                                  "Total files brain looked at across decisions"),
                    "decisions":  _safe_counter("qs_brain_decisions_total",
                                                  "Total brain decisions recorded"),
                }
                # Prometheus Counter doesn't have .set(); we use a delta-tracking
                # cache to compute the increment since last scrape.
                global _brain_prune_last_seen
                _brain_prune_last_seen = {k: 0 for k in
                    ("manifest_pruned", "supplement_pruned", "bloom_pruned",
                     "files_scanned", "decisions_total")}
        # Counter only goes up -- compute delta vs last scrape.
        for src_key, gauge_key in (
            ("manifest_pruned",   "manifest"),
            ("supplement_pruned", "supplement"),
            ("bloom_pruned",      "bloom"),
            ("files_scanned",     "scanned"),
            ("decisions_total",   "decisions"),
        ):
            cur = int(_pc.get(src_key, 0))
            last = _brain_prune_last_seen[src_key]
            delta = max(0, cur - last)
            if delta:
                _brain_prune_counters[gauge_key].inc(delta)
            _brain_prune_last_seen[src_key] = cur
    except Exception:
        pass    # metrics MUST never crash

    # 2026-10-03 -- an N-process pod (main.run_server, server.workers > 1)
    # renders the AGGREGATE of every process; one process renders its own.
    from core.process_topology import metrics_registry as _metrics_registry
    return _StarletteResponse(content=generate_latest(_metrics_registry()),
                              media_type=CONTENT_TYPE_LATEST)


def _config_source_for_health() -> dict:
    """The loader's own account of which file it loaded (2026-09-27).  Never
    raises: a health probe must answer even if the config module is mid-
    reload; an unreadable fact is reported as such, not as "loaded"."""
    try:
        from core.config import config_source as _cfg_src
        s = _cfg_src()
        # The loader's own keys, verbatim (config_file, config_file_exists,
        # config_file_load_failed, config_file_via, config_file_error, ...):
        # the checker spells an expectation `_source.<key>` and reads it from
        # here on the api pod and from `config show` `_source` elsewhere.
        return {k: v for k, v in s.items() if k != "config_file_placeholders"}
    except Exception as exc:  # noqa: BLE001 -- reported, never hidden
        return {"config_file": None, "config_file_exists": None,
                "config_file_load_failed": None, "config_file_via": None,
                "config_file_error": f"config_source unavailable: {exc}"}


@router.get("/health")
async def health_check():
    """Health check — DB connectivity, disk space, active queries.

    Returns HTTP 503 when database is unavailable so K8s liveness probes
    trigger a pod restart (the startup integrity-check will auto-recover
    a corrupted SQLite database).

    BF-NONBLOCK-AUDIT-9 — ROOT CAUSE of "Backend API unavailable" UI:
    every probe used to do sync DB + sync boto3 head_bucket
    (s3_handler.test_connection) inline in this `async def`.  When
    iceberg sync filled the worker pool, s3 head_bucket would take
    5-10s on slow network, blocking the event loop, and K8s
    liveness probe would timeout → pod marked dead → WS dropped.
    Now: whole body runs in a worker thread + the s3 sub-check has
    a hard 2-second timeout so a slow head_bucket cannot block.
    """
    global _db_consecutive_failures
    import shutil as _shutil
    import asyncio as _asyncio
    from core.config import query_engine as _qe

    def _do_db_check():
        ok = False
        try:
            if _db_manager:
                _db_manager.get_execution("__health_probe__")   # returns None, never raises
                ok = True
        except Exception as exc:
            logger.warning("Health DB check failed: %s", exc)
        if ok:
            try:
                from core.config import health as _h_cfg
                if _h_cfg.enable_write_test and _db_manager and hasattr(_db_manager, 'engine'):
                    from sqlalchemy import text as sa_text
                    with _db_manager.engine.connect() as _wc:
                        _wc.execute(sa_text("PRAGMA wal_checkpoint(PASSIVE)"))
                        _wc.commit()
            except Exception as exc:
                ok = False
                logger.warning("Health DB write-test failed: %s", exc)
        return ok

    def _do_disk_check():
        free_gb = used_pct = -1.0
        warn = False
        if _paths:
            try:
                _du = _shutil.disk_usage(str(_paths.data_dir))
                free_gb  = round(_du.free  / (1024 ** 3), 2)
                used_pct = round(_du.used  / _du.total * 100, 1)
                warn     = free_gb < 5.0
            except Exception:
                pass
        return free_gb, used_pct, warn

    def _do_s3_check():
        if not (_engine and _engine.s3_handler):
            return "not_configured"
        try:
            return "connected" if _engine.s3_handler.test_connection().get("connected") else "error"
        except Exception:
            return "error"

    def _do_redis_check():
        try:
            from core.config import queue as _q_cfg
            if _q_cfg.backend != "redis":
                return "not_configured"
            from core.task_queue import get_task_queue
            _tq = get_task_queue()
            if hasattr(_tq, "get_status"):
                _tq.get_status()
            return "connected"
        except Exception as _rexc:
            return f"error: {str(_rexc)[:100]}"

    # 2026-07-13 — run EVERY blocking check on the dedicated probe executor
    # (not the shared pool that query load saturates) with a hard timeout, so
    # /health can NEVER hang and client-timeout the kubelet.  A DB TIMEOUT is
    # "busy", NOT "down": report ok + don't increment the failure counter +
    # keep 200, so load can't restart a pod probing /health.  A COMPLETED DB
    # failure still flips ok=False → 503 (recovery intent preserved).
    _loop = _asyncio.get_event_loop()
    _probe_to = _probe_timeout_seconds()

    async def _run_probe(fn, timeout, on_timeout):
        try:
            return await _asyncio.wait_for(
                _loop.run_in_executor(_probe_executor, fn), timeout=timeout)
        except _asyncio.TimeoutError:
            return on_timeout

    _db_timed_out = False
    db_ok = await _run_probe(_do_db_check, _probe_to, on_timeout="__timeout__")
    if db_ok == "__timeout__":
        _db_timed_out = True
        db_ok = True   # busy, not down
        logger.warning("/health DB check timed out (pool busy) — reporting "
                       "busy (200), not down; not counting toward restart")

    with _db_fail_lock:
        if _db_timed_out:
            pass                       # busy — neither reset nor increment
        elif db_ok:
            _db_consecutive_failures = 0
        else:
            _db_consecutive_failures += 1
            logger.warning("Health DB consecutive failures: %d", _db_consecutive_failures)

    _disk = await _run_probe(_do_disk_check, _probe_to, on_timeout=(-1.0, -1.0, False))
    disk_free_gb, disk_used_pct, disk_warn = _disk

    s3_status = await _run_probe(_do_s3_check, 2.0, on_timeout="timeout")
    redis_status = await _run_probe(_do_redis_check, _probe_to, on_timeout="timeout")

    # Pool-aware query stats — in-process, no I/O
    qe = _qe_cfg or _qe
    try:
        from core.worker_pool import get_pool
        _pool_stats = get_pool().get_stats()
        active_queries = _pool_stats.get("active_total", 0)
        queue_waiting  = _pool_stats.get("queued_total", 0)
    except RuntimeError:
        # No worker pool on this pod (never initialised, or shut down).
        # 2026-09-15 -- this branch used to report get_queue_count(), which
        # is a counter NOTHING INCREMENTS: increment_queue_count and
        # decrement_queue_count have no production callers, so the answer was
        # a constant 0 dressed as a measurement.  "Unknown" and "none
        # waiting" lead to opposite investigations, and the pool's own
        # queued_total made this legacy counter redundant rather than
        # broken -- wiring a SECOND queue counter would give two answers to
        # one question.  So it says it does not know.
        active_queries = len([t for t in running_tasks.values() if not t.done()])
        queue_waiting  = None

    db_type = "sqlite"
    try:
        from core.config import database as _db_cfg_h
        db_type = _db_cfg_h.type
    except Exception:
        pass

    # 2026-10-17 (component health, defect 6): an S3 or Redis ERROR is a
    # degradation and is SAID -- the word used to depend on the DB and the
    # disk alone, so a pod with its object store unreachable read "healthy".
    # "not_configured" and "timeout" (busy, not down) are not errors.  The
    # kubelet reads /health/live, never this word (every chart, 2026-10-17).
    _dep_errors = [name for name, st in (("s3", s3_status), ("redis", redis_status))
                   if isinstance(st, str) and (st == "error" or st.startswith("error"))]
    overall = "healthy" if db_ok and not disk_warn and not _dep_errors else "degraded"

    body = {
        "status":    overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "database":  {"ok": db_ok, "type": db_type},
        # 2026-09-27 -- which config FILE this pod loaded and whether it
        # loaded (core.config.config_source): the per-pod fact
        # scripts/verify_prod_config.py asserts after a roll.  Same keys as
        # `config show` _source and the startup line.
        "config":    _config_source_for_health(),
        "disk":      {"free_gb": disk_free_gb, "used_pct": disk_used_pct, "warning": disk_warn},
        "queries":   {
            "active":               active_queries,
            "max_workers":          qe.max_workers,
            "per_user_limit":       qe.max_concurrent_per_user,
            "max_concurrent_global": qe.max_concurrent_global,
            # None when no worker pool is present to ask -- see above.
            # A reader must be able to tell "nothing is waiting" from "this
            # pod cannot tell you".
            "queue_waiting":        queue_waiting,
            "queue_waiting_known":  queue_waiting is not None,
            "max_queue_size":       qe.max_queue_size,
        },
        "s3":        {"status": s3_status},
        "redis":     {"status": redis_status},
        # what made the word "degraded", when it is
        "degraded_reasons": ([] if db_ok else ["database"]) + (["disk"] if disk_warn else []) + _dep_errors,
    }

    # 2026-06-30 deep-dive add-on: surface DB-degraded mode so admin UI
    # can show "brain in degraded mode" without grepping logs.
    try:
        from core.db_health_monitor import get_monitor as _dbh_get
        body["db_health"] = _dbh_get().snapshot()
    except Exception as _dbh_exc:
        body["db_health"] = {"degraded": False, "error": str(_dbh_exc)[:200]}

    # 2026-10-10 -- the pod's WORKER LEDGER (core/worker_ledger.py): how many
    # server processes are configured, how many this pod has started, which
    # are alive, which died, how many were respawns, and the cgroup's
    # oom_kill count.  A worker uvicorn's supervisor killed and replaced was
    # otherwise visible only in the supervisor's stdout (RestartCount 0).
    # A listing of a few small files, off the loop like the other probes.
    try:
        from core.worker_ledger import worker_ledger as _worker_ledger
        body["workers"] = await _asyncio.wait_for(
            _asyncio.to_thread(_worker_ledger), timeout=1.0)
    except _asyncio.TimeoutError:
        body["workers"] = {"known": False, "reason": "ledger read timed out"}
    except Exception as _wl_exc:
        body["workers"] = {"known": False, "reason": f"ledger failed: {str(_wl_exc)[:200]}"}

    # Phase 132-I: Feed/ETL engine capacity stats — in-process metric reads.
    # 2026-06-30 deep-dive fix: wrap each in asyncio.wait_for so a slow
    # in-process metric read (e.g. lock contention inside feed_engine
    # under heavy SOD load) cannot stall the health endpoint past the
    # liveness probe's 5s timeout.  Previously a 10s stall here put
    # the pod into a restart loop under feed-gen spikes.
    _HEALTH_STAT_TIMEOUT_S = 1.0
    try:
        from core.feed_engine import get_feed_engine_stats
        body["feeds"] = await _asyncio.wait_for(
            _asyncio.to_thread(get_feed_engine_stats),
            timeout=_HEALTH_STAT_TIMEOUT_S,
        )
    except _asyncio.TimeoutError:
        logger.warning(
            "Health: feed engine stats timed out (>%ss) -- skipping to "
            "keep liveness probe responsive", _HEALTH_STAT_TIMEOUT_S,
        )
        body["feeds"] = {"status": "stat_timeout"}
    except Exception as _fe_exc:
        logger.warning("Health: feed engine stats failed: %s", _fe_exc)
        body["feeds"] = {"status": "not_initialized"}
    try:
        from core.etl_engine import get_etl_engine_stats
        body["etl"] = await _asyncio.wait_for(
            _asyncio.to_thread(get_etl_engine_stats),
            timeout=_HEALTH_STAT_TIMEOUT_S,
        )
    except _asyncio.TimeoutError:
        logger.warning(
            "Health: ETL engine stats timed out (>%ss) -- skipping",
            _HEALTH_STAT_TIMEOUT_S,
        )
        body["etl"] = {"status": "stat_timeout"}
    except Exception as _ee_exc:
        logger.warning("Health: ETL engine stats failed: %s", _ee_exc)
        body["etl"] = {"status": "not_initialized"}

    # Return 503 when database is unavailable — triggers K8s liveness restart
    if not db_ok:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content=_coerce_json(body))
    return body


@router.get("/health/live")
async def liveness_probe():
    """K8s liveness probe — checks DB connectivity with consecutive-failure gate.

    Returns 503 only after ``health.failure_threshold`` consecutive DB failures
    to avoid false restarts from transient SQLite lock contention.
    """
    global _db_consecutive_failures
    try:
        from core.config import health as _h_cfg
        if not _h_cfg.liveness_db_check:
            return {"status": "alive"}
        threshold = _h_cfg.failure_threshold
    except Exception:
        threshold = 3  # default: check DB with threshold=3

    # 2026-07-13 — dedicated-executor + hard-timeout DB check (see
    # _probe_db_check).  A TIMEOUT (pool busy) FAILS OPEN → stays alive and
    # does NOT count toward the restart threshold; only a COMPLETED DB error
    # increments it.  This is what stops the load-induced restart loop while
    # still restarting a genuinely-broken-DB pod so startup can auto-recover.
    status = await _probe_db_check("__live_probe__")

    if status == "timeout":
        # Busy, not dead — reset is NOT applied (don't mask a real failure
        # streak) but we also do NOT increment.  Respond alive immediately.
        return {"status": "alive", "db_probe": "timeout_fail_open"}

    db_ok = (status == "ok")
    with _db_fail_lock:
        if db_ok:
            _db_consecutive_failures = 0
        else:
            _db_consecutive_failures += 1
        current_failures = _db_consecutive_failures

    if db_ok:
        return {"status": "alive"}

    if current_failures >= threshold:
        logger.error("Liveness probe failing — %d consecutive DB failures (threshold=%d)",
                     current_failures, threshold)
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={
            "status": "unhealthy",
            "reason": "database unavailable",
            "consecutive_failures": current_failures,
        })

    logger.warning("Liveness DB check failed (%d/%d) — not yet at threshold",
                   current_failures, threshold)
    return {"status": "alive", "db_warning": True, "consecutive_failures": current_failures}


@router.get("/health/ready")
async def readiness_probe():
    """K8s readiness probe — checks DB connectivity. Returns 503 on failure.

    2026-07-13 — uses the dedicated-executor + hard-timeout probe.  A timeout
    (pool busy) → not_ready (removed from LB, NO restart — that's readiness's
    job); only a genuine DB failure otherwise.  Responds fast either way so
    the probe never client-timeouts.
    """
    status = await _probe_db_check("__ready_probe__")
    if status != "ok":
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={
            "status": "not_ready",
            "reason": ("database busy (probe timeout)" if status == "timeout"
                       else "database unavailable"),
        })
    # 2026-10-17 -- a DRAIN intent applied on this pod (component health,
    # docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html §3.8): not ready, SAID,
    # so the Service stops routing here while in-flight work finishes.
    # Liveness is untouched; the flag is process-local and lifted by an
    # undrain or the intent's expiry.
    # 2026-10-18 -- the flag OR the drain ROW (effective_draining): the rig's
    # C6 saw the intent applied and readiness still 200; the row is the truth.
    try:
        from core.component_health.intents import effective_draining as _draining
        _d = _draining(_db_manager)
    except Exception:  # noqa: BLE001
        _d = {}
    if _d.get("active"):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={
            "status": "draining", "since": _d.get("since"), "by": _d.get("by"),
            "intent_id": _d.get("intent_id"), "source": _d.get("source")})
    return {"status": "ready"}


def _diag_current_user(request: Request) -> dict:
    """Lazy auth dependency for ``/api/admin/diagnostics``.

    ``api.deps`` is imported LATE in this module (see the ``_Depends`` /
    ``_get_current_user`` aliases further down) so that the probe endpoints
    above it stay import-light.  This shim preserves that ordering while
    still gating the diagnostics route, by resolving the real dependency at
    call time rather than at import time.
    """
    from api.deps import get_current_user as _gcu
    return _gcu(request)


@router.get("/api/admin/diagnostics")
async def platform_diagnostics(_user: dict = Depends(_diag_current_user)):
    """Platform diagnostics — environment, runtime, container info.

    2026-08-09: this had NO auth dependency while every sibling under
    ``/api/health/self-test*`` in this module has one, and it returns
    environment / runtime / container detail — unauthenticated disclosure on
    a route named ``/api/admin/``.  Gated to match its siblings.  It has no
    callers anywhere in the repo (no test, no frontend reference), and the
    gate was added BEFORE ``system_router`` became registered in the
    published-api and reports pod modes, so the fix does not widen exposure.
    """
    import os
    import sys
    import shutil as _shutil

    # Container detection
    in_container = os.path.exists("/.dockerenv") or os.path.exists("/run/.containerenv")
    container_runtime = "unknown"
    if os.path.exists("/.dockerenv"):
        container_runtime = "docker"
    elif os.path.exists("/run/.containerenv"):
        container_runtime = "podman/openshift"

    # Kubernetes/OpenShift detection
    k8s_detected = bool(os.environ.get("KUBERNETES_SERVICE_HOST"))
    k8s_namespace = os.environ.get("KUBERNETES_NAMESPACE") or os.environ.get("POD_NAMESPACE", "")
    k8s_pod_name = os.environ.get("HOSTNAME", "")
    openshift = bool(os.environ.get("OPENSHIFT_BUILD_NAME") or os.environ.get("OPENSHIFT_DEPLOYMENT_NAME"))

    # ECS detection
    ecs_detected = bool(os.environ.get("ECS_CONTAINER_METADATA_URI") or os.environ.get("ECS_CONTAINER_METADATA_URI_V4"))
    ecs_task_arn = os.environ.get("ECS_TASK_ARN", "")
    ecs_cluster = os.environ.get("ECS_CLUSTER", "")

    # Resource limits (cgroup v2)
    memory_limit_mb = None
    cpu_quota = None
    try:
        with open("/sys/fs/cgroup/memory.max") as f:
            val = f.read().strip()
            if val != "max":
                memory_limit_mb = int(val) // (1024 * 1024)
    except (FileNotFoundError, PermissionError):
        try:
            with open("/sys/fs/cgroup/memory/memory.limit_in_bytes") as f:
                val = int(f.read().strip())
                if val < 2**62:
                    memory_limit_mb = val // (1024 * 1024)
        except (FileNotFoundError, PermissionError):
            pass
    try:
        with open("/sys/fs/cgroup/cpu.max") as f:
            parts = f.read().strip().split()
            if parts[0] != "max":
                cpu_quota = round(int(parts[0]) / int(parts[1]), 2)
    except (FileNotFoundError, PermissionError):
        pass

    # Disk usage
    disk_info = {}
    if _paths:
        try:
            _du = _shutil.disk_usage(str(_paths.data_dir))
            disk_info = {
                "total_gb": round(_du.total / (1024**3), 2),
                "used_gb": round(_du.used / (1024**3), 2),
                "free_gb": round(_du.free / (1024**3), 2),
                "used_pct": round(_du.used / _du.total * 100, 1),
            }
        except Exception:
            pass

    # Database info
    db_type = "unknown"
    if _db_manager:
        db_url = str(_db_manager.engine.url)
        if "sqlite" in db_url:
            db_type = "sqlite"
        elif "postgresql" in db_url:
            db_type = "postgresql"

    return {
        "platform": {
            "os": platform.system(),
            "os_version": platform.version(),
            "architecture": platform.machine(),
            "python_version": sys.version.split()[0],
            "hostname": platform.node(),
        },
        "container": {
            "in_container": in_container,
            "runtime": container_runtime if in_container else None,
            "kubernetes": k8s_detected,
            "openshift": openshift,
            "ecs": ecs_detected,
            "k8s_namespace": k8s_namespace or None,
            "k8s_pod": k8s_pod_name or None,
            "ecs_task_arn": ecs_task_arn or None,
            "ecs_cluster": ecs_cluster or None,
        },
        "resources": {
            "memory_limit_mb": memory_limit_mb,
            "cpu_cores_limit": cpu_quota,
        },
        "database": {
            "type": db_type,
        },
        "disk": disk_info,
        "data_dir": str(_paths.data_dir) if _paths else None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# BF-600-st (2026-05-31) — Self-Test Diagnostics
#
# User-visible health UI alternative to running curl + auth headers.  Mirrors
# the BF-600 audit suite as live-runnable self-tests so users can verify the
# pruning subsystem (and other critical paths) WITHOUT setting up real
# iceberg tables or sending shell commands.  Auth: any logged-in user
# (results are platform-state, not tenant-scoped).
# ─────────────────────────────────────────────────────────────────────────────

from fastapi import Depends as _Depends  # noqa: E402
from api.deps import get_current_user as _get_current_user  # noqa: E402
import time as _time_st  # noqa: E402
import asyncio as _asyncio_st  # noqa: E402


def _st_run(name: str, fn) -> Dict[str, Any]:
    """Run a single self-test, time it, capture pass/fail + details."""
    _t0 = _time_st.monotonic()
    try:
        result = fn()
        ok = bool(result.get("ok")) if isinstance(result, dict) else bool(result)
        return {
            "id":          name,
            "name":        result.get("name", name) if isinstance(result, dict) else name,
            "status":      "pass" if ok else "fail",
            "duration_ms": round((_time_st.monotonic() - _t0) * 1000, 2),
            "details":     result.get("details", "") if isinstance(result, dict) else "",
            "error":       result.get("error", "") if isinstance(result, dict) else "",
        }
    except Exception as exc:
        return {
            "id":          name,
            "name":        name,
            "status":      "fail",
            "duration_ms": round((_time_st.monotonic() - _t0) * 1000, 2),
            "details":     "",
            "error":       f"{type(exc).__name__}: {exc}"[:500],
        }


# ── Pruning self-tests ──────────────────────────────────────────────────────


def _st_pruning_boolean_eq_true_against_false_file() -> Dict[str, Any]:
    """BF-600a — boolean column pruning is enabled.  File with bounds
    [False, False] must prune for filter `active_flag = true`."""
    from core.iceberg_reader import _file_matches_column_stats
    entry = {
        "file_path":         "s3://b/false.parquet",
        "lower_bounds":      {1: bytes([0])},
        "upper_bounds":      {1: bytes([0])},
        "null_value_counts": {1: 0},
    }
    keep = _file_matches_column_stats(
        entry,
        non_partition_filters=[{"col": "active_flag", "op": "=", "val": "true"}],
        fid_to_type={1: "boolean"},
        name_lower_to_fid={"active_flag": 1},
    )
    return {
        "name":    "BF-600a — Boolean pruning (eq=true on False-only file)",
        "ok":      keep is False,
        "details": f"expected keep=False, got keep={keep}",
    }


def _st_pruning_not_in_single_value_file() -> Dict[str, Any]:
    """BF-600b — NOT IN file-level pruning.  File holding only 'eu' must
    prune for `region NOT IN ('eu','ap')`."""
    from core.iceberg_reader import _file_matches_column_stats
    entry = {
        "file_path":         "s3://b/eu.parquet",
        "lower_bounds":      {1: b"eu"},
        "upper_bounds":      {1: b"eu"},
        "null_value_counts": {1: 0},
    }
    keep = _file_matches_column_stats(
        entry,
        non_partition_filters=[{"col": "region", "op": "not_in", "val": ["eu", "ap"]}],
        fid_to_type={1: "string"},
        name_lower_to_fid={"region": 1},
    )
    return {
        "name":    "BF-600b — NOT IN pruning (single-value file in excluded set)",
        "ok":      keep is False,
        "details": f"expected keep=False, got keep={keep}",
    }


def _st_pruning_case_insensitive_eq() -> Dict[str, Any]:
    """BF-600d — string case-insensitive eq.  Filter 'CA' must keep
    file with bounds ['ca','ca'] (case-fold makes them equal)."""
    from core.parquet_pruning import _cmp_eq
    ok = _cmp_eq("ca", "ca", "CA") is True and _cmp_eq("XX", "XX", "ca") is False
    return {
        "name":    "BF-600d — String case-insensitive eq",
        "ok":      ok,
        "details": "case-fold preserves correctness for mixed-case bounds",
    }


def _st_pruning_decimal_precision() -> Dict[str, Any]:
    """BF-600e — decimal filter parsed via Decimal not float."""
    from decimal import Decimal
    import core.iceberg_reader as mod
    _orig = mod._decode_bound

    def _patched(raw, t):
        if t.startswith("decimal"):
            return Decimal(raw.decode("utf-8"))
        return _orig(raw, t)

    mod._decode_bound = _patched
    try:
        entry = {
            "file_path":         "s3://b/d.parquet",
            "lower_bounds":      {1: b"99.50"},
            "upper_bounds":      {1: b"99.50"},
            "null_value_counts": {1: 0},
        }
        keep_match = mod._file_matches_column_stats(
            entry,
            non_partition_filters=[{"col": "amount", "op": "=", "val": "99.50"}],
            fid_to_type={1: "decimal(10,2)"},
            name_lower_to_fid={"amount": 1},
        )
        keep_no_match = mod._file_matches_column_stats(
            entry,
            non_partition_filters=[{"col": "amount", "op": "=", "val": "100.00"}],
            fid_to_type={1: "decimal(10,2)"},
            name_lower_to_fid={"amount": 1},
        )
    finally:
        mod._decode_bound = _orig
    ok = (keep_match is True) and (keep_no_match is False)
    return {
        "name":    "BF-600e — Decimal precision (Decimal parser preserves exact match)",
        "ok":      ok,
        "details": f"in-range keep={keep_match}; out-of-range keep={keep_no_match}",
    }


def _st_pruning_supplement_is_not_null() -> Dict[str, Any]:
    """BF-600g — IS NOT NULL prunes when null_count >= row_count via
    the 4-tuple supplement entry."""
    from core.iceberg_reader import _file_matches_supplement_bounds
    supplement = {
        "test.parquet": {"col_a": (None, None, 100, 100)},  # all null
    }
    keep_prune = _file_matches_supplement_bounds(
        "test.parquet", supplement,
        non_partition_filters=[{"col": "col_a", "op": "is_not_null"}],
    )
    supplement2 = {
        "test.parquet": {"col_a": (None, None, 50, 100)},  # half null
    }
    keep_keep = _file_matches_supplement_bounds(
        "test.parquet", supplement2,
        non_partition_filters=[{"col": "col_a", "op": "is_not_null"}],
    )
    ok = (keep_prune is False) and (keep_keep is True)
    return {
        "name":    "BF-600g — IS NOT NULL supplement pruning (row_count 4-tuple)",
        "ok":      ok,
        "details": f"all-null keep={keep_prune}; half-null keep={keep_keep}",
    }


def _st_pruning_like_prefix() -> Dict[str, Any]:
    """BF-600-L1 — LIKE prefix pruning.  File with bounds ['Aardvark',
    'Aardvark'] must prune for `LIKE 'Apple%'` (hi < prefix)."""
    from core.iceberg_reader import _file_matches_column_stats
    entry = {
        "file_path":         "s3://b/a.parquet",
        "lower_bounds":      {1: b"Aardvark"},
        "upper_bounds":      {1: b"Aardvark"},
        "null_value_counts": {1: 0},
    }
    keep = _file_matches_column_stats(
        entry,
        non_partition_filters=[{"col": "name", "op": "starts_with", "val": "Apple"}],
        fid_to_type={1: "string"},
        name_lower_to_fid={"name": 1},
    )
    return {
        "name":    "BF-600-L1 — LIKE prefix pruning (file below prefix)",
        "ok":      keep is False,
        "details": f"expected keep=False, got keep={keep}",
    }


def _st_pruning_function_wrap_extraction() -> Dict[str, Any]:
    """A predicate on a FUNCTION of a column is NOT a predicate on the column.

    BF-600-L2 used to UNWRAP ``LOWER(state) = 'ca'`` into ``state = 'ca'``
    (and ``try_cast(code AS int) > 50`` into ``code > '50'`` -- silent row
    loss, found live 2026-10-06).  The self-test now asserts the REFUSAL
    (``core.filter_ops.WRAPPED_COLUMN_REFUSALS``) and that a bare column
    still extracts."""
    from core.sql_partition_extractor import extract_partition_values_from_sql
    wrapped = {pf.column for pf in extract_partition_values_from_sql(
        "SELECT * FROM t WHERE LOWER(state) = 'ca' "
        "AND TRY_CAST(code AS INT) > 50", {"t": ["state", "code"]})}
    bare = {pf.column for pf in extract_partition_values_from_sql(
        "SELECT * FROM t WHERE state = 'CA'", {"t": ["state"]})}
    return {
        "name":    "Function-wrapped column refused (LOWER / TRY_CAST)",
        "ok":      not wrapped and bare == {"state"},
        "details": f"wrapped extracted: {sorted(wrapped)}; bare: {sorted(bare)}",
    }


def _st_pruning_nan_float_bound() -> Dict[str, Any]:
    """BF-600-L3 — NaN/±Inf float bounds return None (no usable bound)."""
    from core.iceberg_reader import _decode_bound
    import struct
    nan_b = struct.pack("<d", float("nan"))
    inf_b = struct.pack("<f", float("inf"))
    ok = _decode_bound(nan_b, "double") is None and _decode_bound(inf_b, "float") is None
    return {
        "name":    "BF-600-L3 — NaN/Infinity float bounds rejected",
        "ok":      ok,
        "details": "double NaN and float +Inf both safely return None",
    }


def _st_pruning_new_column_keeps_file() -> Dict[str, Any]:
    """BF-600-L4 — filter on a column not in current schema must
    fail-open + keep file."""
    from core.iceberg_reader import _file_matches_column_stats
    entry = {
        "file_path":         "s3://b/x.parquet",
        "lower_bounds":      {1: b"a"},
        "upper_bounds":      {1: b"z"},
        "null_value_counts": {1: 0},
    }
    keep = _file_matches_column_stats(
        entry,
        non_partition_filters=[{"col": "missing_col", "op": "=", "val": "X"}],
        fid_to_type={1: "string"},
        name_lower_to_fid={"name": 1},
    )
    return {
        "name":    "BF-600-L4 — Filter on missing column keeps file (fail-open)",
        "ok":      keep is True,
        "details": f"expected keep=True, got keep={keep}",
    }


def _st_pruning_httpfs_load_prefix_dev() -> Dict[str, Any]:
    """BF-599f — _httpfs_load_prefix returns INSTALL+LOAD by default and
    LOAD-only when QS_AUTOINSTALL_EXTENSIONS=false."""
    import os as _os
    from core.multi_worker_dispatcher import _httpfs_load_prefix
    _prev = _os.environ.pop("QS_AUTOINSTALL_EXTENSIONS", None)
    try:
        dev_prefix = _httpfs_load_prefix()
        _os.environ["QS_AUTOINSTALL_EXTENSIONS"] = "false"
        prod_prefix = _httpfs_load_prefix()
    finally:
        _os.environ.pop("QS_AUTOINSTALL_EXTENSIONS", None)
        if _prev is not None:
            _os.environ["QS_AUTOINSTALL_EXTENSIONS"] = _prev
    ok = ("INSTALL httpfs" in dev_prefix and "INSTALL httpfs" not in prod_prefix
          and "LOAD httpfs" in prod_prefix)
    return {
        "name":    "BF-599f — httpfs INSTALL skip respects QS_AUTOINSTALL_EXTENSIONS",
        "ok":      ok,
        "details": f"dev='{dev_prefix.strip()}'; prod='{prod_prefix.strip()}'",
    }


_PRUNING_SELF_TESTS = [
    ("pruning.boolean",          _st_pruning_boolean_eq_true_against_false_file),
    ("pruning.not_in",           _st_pruning_not_in_single_value_file),
    ("pruning.case_insensitive", _st_pruning_case_insensitive_eq),
    ("pruning.decimal",          _st_pruning_decimal_precision),
    ("pruning.is_not_null",      _st_pruning_supplement_is_not_null),
    ("pruning.like_prefix",      _st_pruning_like_prefix),
    ("pruning.function_wrap",    _st_pruning_function_wrap_extraction),
    ("pruning.nan_float",        _st_pruning_nan_float_bound),
    ("pruning.new_column",       _st_pruning_new_column_keeps_file),
    ("pruning.httpfs_prefix",    _st_pruning_httpfs_load_prefix_dev),
]


# ── System self-tests ───────────────────────────────────────────────────────


def _st_system_duckdb_select_one() -> Dict[str, Any]:
    """DuckDB engine self-test: opens an in-memory connection, runs
    `SELECT 1`, closes.  Verifies the DuckDB Python binding + cleanup."""
    import duckdb
    con = duckdb.connect(":memory:")
    try:
        val = con.execute("SELECT 42").fetchone()
        ok = bool(val) and val[0] == 42
    finally:
        try:
            con.close()
        except Exception as _ddb_close_exc:
            logger.debug("self-test DuckDB close failed: %s", _ddb_close_exc)
    return {
        "name":    "DuckDB engine — in-memory SELECT 42",
        "ok":      ok,
        "details": "fresh connection, query, close — verifies DuckDB binding",
    }


def _st_system_db_ping() -> Dict[str, Any]:
    """Metadata DB ping via the same path /health uses."""
    if _db_manager is None:
        # Skipped — happens only in tests / smoke runs without
        # set_system_dependencies().  In the running backend it's set.
        return {"name": "Metadata DB ping", "ok": True,
                "details": "skipped — db_manager not initialised (test/standalone context)"}
    _db_manager.get_execution("__self_test_probe__")  # returns None, never raises
    return {
        "name":    "Metadata DB ping",
        "ok":      True,
        "details": "get_execution() returned without raising — DB reachable",
    }


def _st_system_per_worker_memory_helper() -> Dict[str, Any]:
    """BF-599d — per-worker memory budget helper.
    On Linux pod with cgroup: returns positive int.
    On Windows dev / no cgroup: returns None (correct behaviour)."""
    from core.multi_worker_executor import _compute_per_worker_memory_mb
    val = _compute_per_worker_memory_mb(4)
    ok = val is None or (isinstance(val, int) and val > 0)
    return {
        "name":    "BF-599d — per-worker memory_mb helper",
        "ok":      ok,
        "details": f"returned {val} (None = no cgroup; int = Linux pod cap)",
    }


def _st_system_loop_watchdog_alive() -> Dict[str, Any]:
    """BF-599 — loop watchdog thread present + bumper task alive."""
    from core import loop_watchdog as _lw
    if _lw._WATCHDOG_THREAD is None:
        # Skipped — happens only outside a running backend.
        return {"name": "BF-599 — loop watchdog thread alive", "ok": True,
                "details": "skipped — watchdog not started (test/standalone context)"}
    ok = _lw._WATCHDOG_THREAD.is_alive()
    return {
        "name":    "BF-599 — loop watchdog thread alive",
        "ok":      ok,
        "details": f"thread alive={ok}",
    }


def _st_system_httpfs_load_prefix_round_trip() -> Dict[str, Any]:
    """BF-599f — _httpfs_load_prefix obeys QS_AUTOINSTALL_EXTENSIONS in
    both directions.  Verifies the prod-mode OpenShift fix wired
    correctly without admins needing to flip env vars in production."""
    import os as _os
    from core.multi_worker_dispatcher import _httpfs_load_prefix
    _prev = _os.environ.pop("QS_AUTOINSTALL_EXTENSIONS", None)
    try:
        unset = _httpfs_load_prefix()
        _os.environ["QS_AUTOINSTALL_EXTENSIONS"] = "true"
        true_val = _httpfs_load_prefix()
        _os.environ["QS_AUTOINSTALL_EXTENSIONS"] = "false"
        false_val = _httpfs_load_prefix()
    finally:
        _os.environ.pop("QS_AUTOINSTALL_EXTENSIONS", None)
        if _prev is not None:
            _os.environ["QS_AUTOINSTALL_EXTENSIONS"] = _prev
    ok = ("INSTALL httpfs" in unset
          and "INSTALL httpfs" in true_val
          and "INSTALL httpfs" not in false_val
          and "LOAD httpfs" in false_val)
    return {
        "name":    "BF-599f — httpfs prefix round-trip (unset/true/false)",
        "ok":      ok,
        "details": "default + true keep INSTALL; false skips INSTALL",
    }


_SYSTEM_SELF_TESTS = [
    ("system.duckdb",          _st_system_duckdb_select_one),
    ("system.db_ping",          _st_system_db_ping),
    ("system.per_worker_mem",   _st_system_per_worker_memory_helper),
    ("system.loop_watchdog",    _st_system_loop_watchdog_alive),
    ("system.httpfs_roundtrip", _st_system_httpfs_load_prefix_round_trip),
]


def _summarise(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total":     len(results),
        "passed":    sum(1 for r in results if r["status"] == "pass"),
        "failed":    sum(1 for r in results if r["status"] == "fail"),
        "tests":     results,
    }


@router.get("/api/health/self-test/pruning")
async def self_test_pruning(_user: dict = _Depends(_get_current_user)):
    """BF-600-st (2026-05-31) — run the pruning self-test suite.

    User-visible alternative to the /health curl-with-auth flow.
    Exercises every BF-600 fix in-memory against synthetic Iceberg
    file metadata; no S3, no DuckDB connection, no real tables —
    runs in <50 ms.  Any logged-in user may call.
    """
    def _run_all():
        return [_st_run(_id, _fn) for _id, _fn in _PRUNING_SELF_TESTS]
    results = await _asyncio_st.to_thread(_run_all)
    return {"suite": "pruning", **_summarise(results)}


@router.get("/api/health/self-test/system")
async def self_test_system(_user: dict = _Depends(_get_current_user)):
    """Self-test for system-level paths (DuckDB engine, metadata DB
    ping, per-worker memory helper, loop watchdog, silent-exception
    cap).  Read-only — no side effects."""
    def _run_all():
        return [_st_run(_id, _fn) for _id, _fn in _SYSTEM_SELF_TESTS]
    results = await _asyncio_st.to_thread(_run_all)
    return {"suite": "system", **_summarise(results)}


@router.get("/api/health/self-test")
async def self_test_all(_user: dict = _Depends(_get_current_user)):
    """Run ALL self-test suites (pruning + system) and aggregate."""
    def _run_all():
        results = []
        for _id, _fn in _PRUNING_SELF_TESTS:
            r = _st_run(_id, _fn)
            r["suite"] = "pruning"
            results.append(r)
        for _id, _fn in _SYSTEM_SELF_TESTS:
            r = _st_run(_id, _fn)
            r["suite"] = "system"
            results.append(r)
        return results
    results = await _asyncio_st.to_thread(_run_all)
    return _summarise(results)
