"""
Connection management endpoints — CRUD, file upload, schema, tables, partitions.
Extracted from main.py (Phase 29 enterprise refactoring).
"""
from __future__ import annotations

import os
import logging
import asyncio
import threading as _threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any

from fastapi import APIRouter, HTTPException, Depends, Request, File, UploadFile
from pydantic import Field, model_validator

from api.strict_request import StrictRequestModel

from api.deps import get_current_user, require_admin, require_role, get_workspace_id
from api.connector_errors import raise_if_source_error
from core.audit import audit_event
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter(tags=["connections"])

#: How many CSV objects a SCHEMA PROBE samples.  This is passed as an
#: EXPLICIT ``max_files`` to ``list_s3_csv_files``, which is what marks the
#: call as a sample request: an explicit N never raises
#: ``TruncatedScanRefusal``, while the default ``max_files`` means "the whole
#: prefix" and refuses above ``s3.listing_max_files``.  Reading a schema is
#: never a reason to enumerate a table.
_CSV_SCHEMA_PROBE_FILES = 5


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# ── Module-level singletons — set via set_connection_dependencies() ───────────
_db_manager   = None
_engine       = None
_conn_manager = None
_paths        = None
_auth_cfg     = None
_lt_cfg       = None

# ── Dedicated light executor for metadata / S3 / schema work ─────────────────
_streaming_executor = ThreadPoolExecutor(
    max_workers=min(20, (os.cpu_count() or 4) * 2),
    thread_name_prefix="conn-stream",
)

# ── File-upload constants (re-evaluated after set_connection_dependencies) ────
_MAX_UPLOAD_SIZE: int = 1 * 1024 * 1024 * 1024  # 1 GB default
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}

# Discover-tables candidate cap.  ONE constant, so the four scan-abort
# checks and the truncation verdict returned to the UI cannot disagree
# about the limit (the 2026-08-17 lesson: a truncation flag computed and
# then thrown away is how "there are more tables" silently vanishes).
_DISCOVER_MAX_CANDIDATES = 50

# ── Schema cache: L1 in-memory (10 min) ──────────────────────────────────────
from core.cache_layer import create_cache  # noqa: E402
_schema_cache = create_cache("schema", ttl=600, max_entries=200)

# ── Partition cache: L1 in-memory (5 min) + L2 SQLite (5 hours) ──────────────
_partition_cache = create_cache("partition", ttl=300, max_entries=500)

# ── Partition refresh mutex: prevent concurrent refresh race (Phase 78J) ──────
_partition_refresh_locks: Dict[str, asyncio.Lock] = {}
_partition_refresh_locks_lock = _threading.Lock()


def _get_partition_refresh_lock(key: str) -> asyncio.Lock:
    """Return (or create) an asyncio.Lock for the given partition refresh key."""
    with _partition_refresh_locks_lock:
        if key not in _partition_refresh_locks:
            _partition_refresh_locks[key] = asyncio.Lock()
        return _partition_refresh_locks[key]
def _pcache_l1_ttl() -> int:
    from core.config import partition_cache as _pc
    return _pc.l1_ttl_seconds

def _pcache_l2_ttl() -> int:
    from core.config import partition_cache as _pc
    return _pc.l2_ttl_seconds

def _pcache_l1_max() -> int:
    from core.config import partition_cache as _pc
    return _pc.l1_max_entries

# ── Connection type regex (shared by Pydantic models) ────────────────────────
_ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle|athena|rest_api)$"


def set_connection_dependencies(db_manager, engine, conn_manager, paths, auth_cfg, lt_cfg):
    """Wire shared singletons from main.py at startup."""
    global _db_manager, _engine, _conn_manager, _paths, _auth_cfg, _lt_cfg
    global _MAX_UPLOAD_SIZE
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _paths        = paths
    _auth_cfg     = auth_cfg
    _lt_cfg       = lt_cfg
    # Re-read configurable upload limit
    if lt_cfg and hasattr(lt_cfg, "max_upload_size_bytes"):
        _MAX_UPLOAD_SIZE = lt_cfg.max_upload_size_bytes


# ── Internal helpers ──────────────────────────────────────────────────────────

def _get_light_executor():
    """Return the dedicated streaming/metadata executor for this module."""
    return _streaming_executor


def _conn_upload_dir(connection_id: int) -> Path:
    """Get (and create) the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _schema_cache_get(key: str):
    return _schema_cache.get(key)


def _schema_cache_set(key: str, result: dict):
    _schema_cache.set(key, result)


async def _record_catalog_columns(connection_id: int, table_name: str,
                                  fmt: str, result: dict, *, source: str) -> None:
    """Write a successful schema read through the LOCAL COLUMN CATALOG
    chokepoint (core/schema_catalog.py).

    The chokepoint writes BOTH the catalog row (contract shape, provenance,
    staleness) and the legacy ``schema_cache`` L2 row (the ``result`` dict
    verbatim) — so this REPLACES the direct ``set_schema_cache`` calls this
    module used to make; a second writer of the same fact is how stores
    drift.  Best-effort: the read already succeeded, a store failure must
    not turn it into an error — but it logs at WARNING because a
    persistently failing store is how the catalog goes quietly empty.
    """
    try:
        from core.schema_catalog import ColumnCatalog
        catalog = ColumnCatalog(_db_manager)
        await _adb(catalog.record_columns, connection_id, table_name,
                   (result or {}).get("columns"),
                   source=source, table_format=fmt, legacy_payload=result)
    except Exception as exc:
        logger.warning("Column-catalog store failed for %s:%s (non-fatal): %s",
                       connection_id, table_name, exc)


async def _serve_catalog_fallback(connection_id: int, table_name: str,
                                  reason: str):
    """On a FAILED live schema read, serve locally saved columns instead of
    a 500 — the operator-reported bug was exactly a source hiccup becoming
    "could not read any columns".  Records the failure WITH its reason in
    the catalog either way.  Returns the legacy response dict (plus
    ``stale``/``message`` disclosure fields), or None when the catalog has
    nothing for this table (caller then raises as before)."""
    try:
        from core.schema_catalog import ColumnCatalog
        catalog = ColumnCatalog(_db_manager)
        await _adb(catalog.record_failure, connection_id, table_name, reason)
        entry = await _adb(catalog.get_entry, connection_id, table_name)
    except Exception as exc:
        logger.warning("Column-catalog fallback unavailable for %s:%s: %s",
                       connection_id, table_name, exc)
        return None
    if not entry or not entry.get("columns"):
        return None
    contract = catalog.build_response(entry, table_name=table_name)
    legacy_cols = [
        {"name": c["name"], "type": c["data_type"], "nullable": c["nullable"]}
        for c in contract["columns"]
    ]
    rows = entry.get("row_estimate")
    logger.warning(
        "Live schema read failed for %s:%s (%s) — serving %d locally "
        "saved columns from the catalog (last refreshed %s)",
        connection_id, table_name, reason, len(legacy_cols),
        contract["last_refreshed_at"],
    )
    return {
        "columns": legacy_cols,
        "partition_columns": list(entry.get("partition_columns") or []),
        "num_rows": rows if isinstance(rows, int) else 0,
        "num_files": 0,
        "format": entry.get("table_format") or "parquet",
        "cache": "catalog",
        "cached_at": contract["last_refreshed_at"],
        "stale": contract["stale"],
        "message": f"Source read failed ({reason}); serving locally saved columns.",
    }


def _partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns result or None on miss."""
    return _partition_cache.get(cache_key)


def _partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    _partition_cache.set(cache_key, result)


def _partition_l2_get(connection_id: int, table_name: str, scan_type: str, s3_prefix: str = ""):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = _db_manager.get_partition_cache(connection_id, table_name, scan_type, s3_prefix=s3_prefix)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _pcache_l2_ttl():
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def _partition_store(connection_id: int, table_name: str, scan_type: str,
                     cache_key: str, result: dict, s3_prefix: str = ""):
    """Store in both L1 + L2. Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    # 78K: Evict stale L1 entry before writing fresh value (prevents race where stale
    # L1 TTL outlives the new data just written to L2 during a manual refresh).
    _partition_cache.delete(cache_key)
    _partition_l1_set(cache_key, stamped)
    _db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped, s3_prefix=s3_prefix)


def _make_s3_client_for_conn(conn_raw: dict):
    """Build a boto3 S3 client from raw connection config.

    Re-uses the cached S3StorageHandler from the connection manager so
    credentials, SSL, and auth mode match the working connection exactly.
    Falls back to creating a new handler if not cached.
    """
    conn_id = conn_raw.get("id")
    cfg = conn_raw.get("config", {})

    # Try the cached handler first — same client the file browser uses
    if conn_id is not None:
        try:
            handler = _conn_manager._get_s3_handler(conn_id, cfg)
            if handler and handler.s3_client:
                return handler.s3_client
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    # Fallback: create a new handler and cache it to avoid leaking clients
    try:
        from core.s3_storage import S3StorageHandler, build_s3_config
        handler = S3StorageHandler(build_s3_config(cfg))
        # Cache in connection manager so subsequent calls reuse it
        if conn_id is not None:
            try:
                import time as _time_mod
                _conn_manager._s3_handlers[conn_id] = (handler, _time_mod.monotonic())
            except Exception:
                pass
        return handler.s3_client
    except Exception as exc:
        logger.error("Failed to create S3 client for connection %s: %s", conn_id, exc, exc_info=True)
        raise


def _list_parquet_files_boto3(s3_client, bucket: str, prefix: str, max_files: int = 5000) -> list:
    """List parquet files via boto3 paginator — avoids DuckDB httpfs glob crash on on-prem S3."""
    files = []
    paginator = s3_client.get_paginator("list_objects_v2")
    clean_prefix = prefix.rstrip("/") + "/" if prefix else ""
    for page in paginator.paginate(Bucket=bucket, Prefix=clean_prefix):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.lower().endswith(".parquet") and not key.split("/")[-1].startswith("."):
                files.append(f"s3://{bucket}/{key}")
                if len(files) >= max_files:
                    return files
    return files


def _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix):
    """Fetch schema from S3 — Iceberg reads metadata JSON, Parquet/CSV uses DuckDB DESCRIBE."""
    logger.info("Loading schema from S3 for table '%s' (format=%s)", table_name, fmt)
    if fmt == "iceberg":
        # 2026-10-06 -- ONE reader of an Iceberg table's current schema
        # (``core.schema_reader``), shared with the BQB / dataset path; the
        # payload now carries ``schema_id`` + ``metadata_key`` so every cache
        # layer can tell when an ALTER TABLE made it stale.
        from core.schema_reader import read_iceberg_table_schema
        s3 = _make_s3_client_for_conn(conn_raw)
        try:
            return read_iceberg_table_schema(s3, bucket, table_def["s3_prefix"], table_name)
        except Exception as e:
            logger.error("Failed to read Iceberg metadata for %s: %s", table_name, e, exc_info=True)
            raise ValueError(f"Cannot read Iceberg metadata: {e}")
    elif fmt == "csv":
        # CSV — use DuckDB DESCRIBE (no partition column concerns)
        from api.data_grid_api import _duckdb_con_with_s3
        from core.s3_utilities import get_s3_access_mode as _get_s3_mode
        con = _duckdb_con_with_s3(config, connection_id=connection_id)
        try:
            _is_onprem_csv = _get_s3_mode(config) == "presigned"
            if _is_onprem_csv:
                from core.s3_utilities import list_s3_csv_files as _list_csv, s3_urls_to_presigned as _csv_presign
                _csv_s3 = _make_s3_client_for_conn(conn_raw)
                # 2026-09-07 — ASK FOR THE SAMPLE, DON'T ENUMERATE THE TABLE.
                # This is a SCHEMA PROBE: it reads at most
                # ``_CSV_SCHEMA_PROBE_FILES`` keys and always has.  Left at
                # the default ``max_files``, ``list_s3_csv_files`` treats the
                # call as "give me the whole prefix" and, since 2026-09-06,
                # RAISES ``TruncatedScanRefusal`` above ``s3.listing_max_files``
                # (50,000) rather than returning a subset — so a schema probe
                # on a large CSV prefix became an HTTP 400 and the connection's
                # tables could not be browsed at all.  An EXPLICIT ``max_files``
                # is a sample request, which never refuses; that exemption
                # exists for probes exactly like this one.  The listing is now
                # bounded at the WIRE too — it stops after N keys instead of
                # walking 50,000 to throw 49,995 away.
                _csv_files = _list_csv(_csv_s3, bucket, prefix,
                                        max_files=_CSV_SCHEMA_PROBE_FILES)
                if not _csv_files:
                    raise ValueError(f"No CSV files found under s3://{bucket}/{prefix}")
                _csv_sampled = len(_csv_files)
                _csv_files = _csv_presign(
                    _csv_s3, _csv_files[:_CSV_SCHEMA_PROBE_FILES], config)
                _esc_csv = lambda v: v.replace("'", "''")
                _csv_paths = ", ".join(f"'{_esc_csv(f)}'" for f in _csv_files)
                src = f"read_csv_auto([{_csv_paths}])"
            else:
                _csv_sampled = None
                src = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
            cols_raw = con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()
            row_count = 0
            try:
                row_count = con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0]
            except Exception as e:
                logger.debug("Failed to count rows for S3 table %s: %s", table_name, e)
            # ``num_rows`` MEANS DIFFERENT THINGS ON THE TWO BRANCHES, so it
            # says which one it is.  The glob branch counts the whole prefix;
            # the presigned branch counts only the sampled files, and has
            # since it was written — reporting a 5-file count as the table's
            # row count is a 200 with something untrue in it.  Additive keys,
            # so no existing consumer changes behaviour.
            return {
                "table_name": table_name,
                "format": fmt,
                "s3_prefix": table_def["s3_prefix"],
                "columns": [
                    {"name": c[0], "type": c[1], "nullable": True}
                    for c in cols_raw
                ],
                "num_rows": row_count,
                "num_rows_is_sample": _csv_sampled is not None,
                "sampled_files": _csv_sampled,
            }
        finally:
            con.close()
    else:
        # BF-69: Parquet — safe schema reader (downloads locally for on-prem,
        # merges hive partition columns from paths — works on Dell ECS / any S3)
        # Step 5 of REFACTOR_PLAN_SCHEMA_READER.md — call goes through
        # the unified ``read_parquet_schema_for_conn`` helper so the
        # cached-S3-handler-first credential strategy + kwarg-only
        # ``s3_client`` argument stay consistent across all schema
        # read sites.
        from core.schema_reader import read_parquet_schema_for_conn
        s3 = _make_s3_client_for_conn(conn_raw)
        schema_result = read_parquet_schema_for_conn(
            conn_raw, bucket, prefix, s3_client=s3,
        )
        return {
            "table_name": table_name,
            "format": fmt,
            "s3_prefix": table_def["s3_prefix"],
            "columns": [
                {"name": c["name"], "type": c["type"], "nullable": c.get("nullable", True)}
                for c in schema_result["columns"]
            ],
            "num_rows": schema_result["num_rows"] or 0,
            "num_files": schema_result.get("num_files", 0),
            # 2026-09-17 — same rule the CSV branch above already applies.
            # Neither count is a table total: ``num_rows`` is one sampled
            # file's and ``num_files`` stops at the schema probe's cap, so a
            # 7,300-file / 14.6M-row table reported 500 and 2,000 and the
            # table picker showed both as fact.  Additive keys — existing
            # consumers are untouched, but one that cares can now tell a
            # probe from a total instead of being quietly misled.
            "num_rows_is_sample": schema_result.get("num_rows_is_sample", False),
            "sampled_files": schema_result.get("sampled_files", 0),
            "num_files_is_capped": schema_result.get("num_files_is_capped", False),
            "partition_columns": schema_result.get("partition_columns", []),
            # 2026-10-06 -- how each partition-only key's type was DECIDED
            # (core.hive_partition_types); a stored schema without it predates
            # the rule and is re-read.
            **({"partition_types": schema_result["partition_types"]}
               if isinstance(schema_result.get("partition_types"), dict) else {}),
        }


# ── Pydantic Models ───────────────────────────────────────────────────────────

def _validate_s3_bucket_and_arn(connection_type: str, config: dict) -> None:
    """Phase 78M: Validate bucket name and IAM ARN at save/test time (HTTP 422 on failure)."""
    if connection_type != "s3":
        return
    import re as _re
    from core.config import s3_validation as _sv
    bucket = (config.get("bucket_name") or "").strip()
    if _sv.validate_bucket_on_create and bucket:
        # On-prem (path_style) allows underscores and mixed case; AWS does not.
        regex = _sv.bucket_name_regex_onprem if config.get("path_style") else _sv.bucket_name_regex_aws
        if not _re.match(regex, bucket):
            raise ValueError(
                f"Invalid S3 bucket name '{bucket}'. "
                f"Expected pattern: {regex}"
            )
    role_arn = (config.get("role_arn") or "").strip()
    if _sv.validate_arn_format and config.get("auth_mode") == "assume_role" and role_arn:
        if not _re.match(_sv.arn_regex, role_arn):
            raise ValueError(
                f"Invalid IAM Role ARN '{role_arn}'. "
                "Expected format: arn:aws:iam::123456789012:role/MyRole"
            )

    # Portal-auth mode requires role_name — when the AWS account has multiple
    # IAM roles, an empty role_name resolves to the FIRST role the portal
    # returns, which is rarely what the user wants.  Reject the save so the
    # admin picks the right role explicitly.
    if config.get("auth_mode") == "portal":
        if not (config.get("role_name") or "").strip():
            raise ValueError(
                "IAM Role Name is required for AWS Portal authentication. "
                "Enter the exact role name (e.g. app-ReadOnlyRole) so the "
                "portal returns the role_arn that matches THIS connection's "
                "purpose. Leaving it empty would silently use the first role "
                "returned, which is rarely the right one when an account has "
                "multiple roles."
            )


class ConnectionConfigModel(StrictRequestModel):
    name: str
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None

    @model_validator(mode='after')
    def validate_s3_fields(self):
        try:
            _validate_s3_bucket_and_arn(self.connection_type, self.config or {})
        except ValueError as e:
            raise ValueError(str(e))
        return self


class ConnectionTestRequest(StrictRequestModel):
    connection_type: str = Field(pattern=_ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection

    @model_validator(mode='after')
    def validate_s3_fields(self):
        try:
            _validate_s3_bucket_and_arn(self.connection_type, self.config or {})
        except ValueError as e:
            raise ValueError(str(e))
        return self


class RegisteredTableModel(StrictRequestModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""
    partition_columns: List[str] = []
    # 2026-09-27 — the DECLARED bloom-sidecar columns for an Iceberg table:
    # warm-on-commit (core/iceberg_warm_on_commit.py) builds these on every
    # new snapshot so an id lookup has its index on day one rather than
    # after three hits in the query history.  Empty = none declared.
    bloom_columns: List[str] = []


class PartitionColumnsModel(StrictRequestModel):
    partition_columns: List[str]


# ── Connection File Upload Endpoints ──────────────────────────────────────────

@router.post("/api/connections/{connection_id}/upload-files")
async def upload_connection_files(
    connection_id: int,
    files: List[UploadFile] = File(...),
    _user: dict = Depends(require_admin),
):
    """Upload multiple data files to a connection's upload directory (max 1 GB each)."""
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="File upload is only for 'upload' type connections")

    upload_dir = _conn_upload_dir(connection_id)
    results = []
    errors = []

    for file in files:
        fname = Path(file.filename).name  # strip directory components
        ext = Path(fname).suffix.lower()
        if ext not in _ALLOWED_EXTENSIONS:
            errors.append(f"{fname}: unsupported format ({ext}). Allowed: {', '.join(sorted(_ALLOWED_EXTENSIONS))}")
            continue

        # Stream to disk in chunks to enforce size limit without loading all into RAM
        dest = upload_dir / fname
        total = 0
        try:
            with open(dest, "wb") as out:
                while True:
                    chunk = await file.read(8 * 1024 * 1024)  # 8 MB chunks
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > _MAX_UPLOAD_SIZE:
                        out.close()
                        dest.unlink(missing_ok=True)
                        errors.append(f"{fname}: exceeds 1 GB limit")
                        break
                    out.write(chunk)
                else:
                    results.append({"filename": fname, "size_bytes": total})
                    logger.info("File uploaded for connection %s: %s (%s bytes)", connection_id, fname, total)
        except Exception as e:
            dest.unlink(missing_ok=True)
            errors.append(f"{fname}: {str(e)}")

    # Update connection config with the upload directory path
    config = conn.get("config", {})
    config["base_path"] = str(upload_dir)
    await _adb(_db_manager.update_connection, connection_id, {"config": config})

    return {
        "uploaded": results,
        "errors": errors,
        "total_files": len(list(upload_dir.glob("*"))),
        "upload_dir": str(upload_dir),
    }


@router.get("/api/connections/{connection_id}/uploaded-files")
async def list_uploaded_files(
    connection_id: int,
    _user: dict = Depends(get_current_user),
):
    """List files that have been uploaded to this connection."""
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="Not an upload-type connection")

    upload_dir = _conn_upload_dir(connection_id)
    files = []
    for f in sorted(upload_dir.iterdir()):
        if f.is_file():
            files.append({
                "filename": f.name,
                "size_bytes": f.stat().st_size,
                "modified": f.stat().st_mtime,
            })
    return {"files": files, "total_size_bytes": sum(f["size_bytes"] for f in files)}


@router.delete("/api/connections/{connection_id}/uploaded-files/{filename}")
async def delete_uploaded_file(
    connection_id: int,
    filename: str,
    _user: dict = Depends(require_admin),
):
    """Delete a single uploaded file from a connection."""
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn["connection_type"] != "upload":
        raise HTTPException(status_code=400, detail="Not an upload-type connection")

    upload_dir = _conn_upload_dir(connection_id)
    target = upload_dir / Path(filename).name  # prevent path traversal
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {filename}")

    target.unlink()
    remaining = len(list(upload_dir.glob("*")))
    logger.info("Deleted uploaded file %s from connection %s (%d remaining)", filename, connection_id, remaining)
    audit_event(_db_manager, _user, None, "delete_uploaded_file", "connection_file",
                f"{connection_id}/{filename}")
    return {"message": f"Deleted {filename}", "remaining_files": remaining}


@router.get("/api/connections/upload-status")
async def get_upload_connections_status(_user: dict = Depends(get_current_user)):
    """Check all upload-type connections for usage status.
    Returns list of upload connections with whether they're referenced by any saved query."""
    all_conns = await _adb(_db_manager.list_connections, active_only=True)
    upload_conns = [c for c in all_conns if c.get("connection_type") == "upload"]
    if not upload_conns:
        return {"upload_connections": []}

    # Get all saved queries to check which connections are referenced
    all_queries = await _adb(_db_manager.list_queries, active_only=True)
    used_conn_ids = set()
    for q in all_queries:
        qc = q.get("query_config", {})
        cid = qc.get("connection_id")
        if cid:
            used_conn_ids.add(int(cid))

    result = []
    for c in upload_conns:
        upload_dir = _paths.upload_dir / str(c["id"])
        file_count = len(list(upload_dir.glob("*"))) if upload_dir.exists() else 0
        total_size = sum(f.stat().st_size for f in upload_dir.glob("*") if f.is_file()) if upload_dir.exists() else 0
        result.append({
            "id": c["id"],
            "name": c["name"],
            "file_count": file_count,
            "total_size_bytes": total_size,
            "is_used": c["id"] in used_conn_ids,
            "created_at": c.get("created_at"),
        })
    return {"upload_connections": result}


# ── Connection CRUD Endpoints ─────────────────────────────────────────────────

#: 2026-10-03 -- only an ADMIN configures a connection; everyone else SELECTS
#: one their group policy grants and sees nothing of how it is configured
#: (host, account, user, bucket, auth, secrets).  These are the only config
#: keys a non-admin screen reads: the query builders list a storage
#: connection's registered tables and an S3 connection's Iceberg warehouse.
_NON_ADMIN_CONFIG_KEYS = ("registered_tables", "iceberg_warehouse_path")


def _as_seen_by_non_admin(conn: dict) -> dict:
    """``conn`` with its config cut down to what a non-admin screen reads."""
    cfg = conn.get("config") if isinstance(conn.get("config"), dict) else {}
    return {**conn, "config": {k: cfg[k] for k in _NON_ADMIN_CONFIG_KEYS if k in cfg}}


# ── One S3 bucket, one connection (2026-10-07, owner requirement) ─────────
# The decision lives in core/connection_duplicates.py; every route that can
# put a connection on a bucket -- create, edit, clone -- goes through the
# guard below.  The lock makes check-then-write atomic within this process;
# two pods racing the same bucket in the same instant are not serialised
# (there is no column a DB constraint could hold the identity in).
_S3_IDENTITY_LOCK = asyncio.Lock()


async def _connections_for_identity() -> List[Dict[str, Any]]:
    # Every active connection, in every workspace: one bucket is one source
    # whichever workspace a second connection to it would be made in.
    return await _adb(_db_manager.list_connections, True, 1_000_000, 0, None)


from contextlib import asynccontextmanager as _acm  # noqa: E402


@_acm
async def _one_connection_per_bucket(check):
    """Hold the identity lock, run ``check(connections) -> detail|None``,
    and refuse with 409 (naming the existing connection) when it answers."""
    async with _S3_IDENTITY_LOCK:
        detail = check(await _connections_for_identity())
        if detail:
            logger.info("[connections] refused: %s", detail.get("message"))
            raise HTTPException(status_code=409, detail=detail)
        yield


@router.get("/api/admin/connections/duplicate-buckets")
async def list_duplicate_bucket_connections(_user: dict = Depends(require_admin)):
    """S3 connections that share a bucket -- created before duplicates were
    refused (2026-10-07).  Reported for an admin to merge; never deleted."""
    from core.connection_duplicates import duplicate_groups
    groups = duplicate_groups(await _connections_for_identity())
    return {"groups": groups, "count": len(groups)}


@router.get("/api/admin/encryption-key")
async def encryption_key_status(_user: dict = Depends(require_admin)):
    """ONE key for every component (2026-10-15, core/encryption_key_rotation.py):
    where THIS pod's key came from (by fingerprint, never the key), the
    decrypt-only older keys, the start-up sweep's report, and a LIVE count
    of the stored secrets no key of this deployment can read -- named, with
    the fix.  Compare the fingerprint across pods: they must agree."""
    from core.crypto import key_status
    from core.encryption_key_rotation import LAST_REPORT, sweep
    from core.db_async import adb
    live = await adb(sweep, _db_manager, write=False)
    return {"this_pod": key_status(),
            "stored": {"current": live["current"], "needs_rotation": live["rotated"],
                       "unreadable": live["unreadable"], "fix": live["fix"]},
            "last_reencrypt": {k: v for k, v in LAST_REPORT.items() if k != "key"}}


@router.post("/api/admin/encryption-key/rotate-data-key")
async def encryption_key_rotate_data_key(_user: dict = Depends(require_admin)):
    """A NEW active data key (envelope encryption, 2026-10-17): new secrets are
    encrypted with it, every older data key is RETIRED and still decrypts.  No
    stored secret is rewritten (``/reencrypt`` does that, when wanted)."""
    from core.crypto import EncryptionKeyUnavailable, rotate_data_key
    from core.db_async import adb
    try:
        return {"rotated": True, "this_pod": await adb(rotate_data_key)}
    except EncryptionKeyUnavailable as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/api/admin/encryption-key/reencrypt")
async def encryption_key_reencrypt(_user: dict = Depends(require_admin)):
    """Re-encrypt under the ACTIVE data key every stored secret an older key
    reads -- ONE job across every pod (a second answers ``running_elsewhere``
    at once), in short batches.  It used to run at EVERY component's start,
    which is how two containers came to block each other (2026-10-17)."""
    from core.crypto import EncryptionKeyUnavailable
    from core.encryption_key_rotation import reencrypt
    from core.db_async import adb
    try:
        return await adb(reencrypt, _db_manager)
    except EncryptionKeyUnavailable as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.get("/api/connections")
async def list_connections(active_only: bool = True, request: Request = None):
    """List connections — users see their own + shared + ACL-granted; admins see all."""
    try:
        workspace_id = get_workspace_id(request) if request else None
        all_conns = await _adb(_db_manager.list_connections, active_only=active_only, workspace_id=workspace_id)
        # Apply RLS: non-admins see only their own + shared + ACL-granted connections
        if _auth_cfg.type != "none":
            user = get_current_user(request)
            if user and not is_admin_like(user):
                username = user.get("username", "")
                user_role = user.get("role", "viewer")
                # Phase 102-E: batch-query ACL grants (O(1) — single DB hit)
                acl_ids: set = set()
                try:
                    from core.config import admin_governance as _gov
                    if _gov.enabled:
                        acl_ids = await _adb(_db_manager.list_connection_ids_for_user, 
                            username, roles=[user_role])
                except Exception as e:
                    logger.warning("Failed to apply admin governance ACL filtering for user %s: %s", username, e)
                all_conns = [
                    c for c in all_conns
                    if c.get("created_by") == username
                    or c.get("is_shared")
                    or not c.get("created_by")   # legacy connections (no owner) visible to all
                    or c.get("id") in acl_ids     # explicit ACL grant
                ]
                all_conns = [_as_seen_by_non_admin(c) for c in all_conns]
                return all_conns
        # 2026-10-07 -- an admin sees which S3 connections share a bucket
        # (``duplicate_bucket`` with the others and a message).  Judged over
        # EVERY connection, not just this page of the list.
        try:
            from core.connection_duplicates import annotate as _dup_annotate
            _dup_annotate(all_conns, await _connections_for_identity())
        except Exception as _dup_exc:
            logger.warning("duplicate-bucket annotation failed: %s", _dup_exc)
        return all_conns
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections")
async def create_connection(body: ConnectionConfigModel, http_req: Request,
                            _user: dict = Depends(require_admin)):
    """Create a new connection — auto-sets created_by from auth user."""
    # Phase 102-F: enforce per-user connection quota
    from api.deps import enforce_user_resource_quota
    enforce_user_resource_quota(_user, "connections")
    request = body  # alias for remaining code below
    try:
        workspace_id = get_workspace_id(http_req)
        from core.connection_duplicates import check_create as _dup_create
        async with _one_connection_per_bucket(
                lambda conns: _dup_create(conns, request.connection_type,
                                          request.config)):
            conn = await _adb(_db_manager.create_connection,
                name=request.name,
                connection_type=request.connection_type,
                config=request.config,
                workspace_id=workspace_id,
            )
        # Set created_by and is_shared on the new connection
        username = (_user or {}).get("username", "guest")
        is_shared = request.is_shared or False
        await _adb(_db_manager.update_connection, conn["id"], created_by=username, is_shared=bool(is_shared))
        conn["created_by"] = username
        conn["is_shared"] = bool(is_shared)

        # For upload connections, auto-set base_path to the upload directory
        if request.connection_type == "upload":
            upload_dir = _conn_upload_dir(conn["id"])
            config = conn.get("config", {})
            config["base_path"] = str(upload_dir)
            await _adb(_db_manager.update_connection, conn["id"], config=config)
            conn["config"] = config

        # 2026-06-16 — strategic fix: eagerly detect partition_columns
        # for every registered_table that lacks them, BEFORE returning.
        # See core/iceberg_partition_discovery for the why (kills the
        # 30s query-time S3 walk that otherwise hits every first query).
        _schedule_partition_discovery(conn["id"])

        # Return masked config — never send encrypted credentials to browser
        from core.crypto import decrypt_config, mask_config
        if conn and "config" in conn:
            conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except HTTPException:
        raise
    except Exception as e:
        # 2026-10-03 -- a connection NAME is unique, and creating a second
        # one with a taken name was a 500 whose detail main.py's CWE-209
        # chokepoint erases: the author was told "contact support" for a
        # name clash.  Said plainly, as the 409 it is.
        _msg = str(e).lower()
        if (type(e).__name__ == "IntegrityError" and "name" in _msg
                and ("unique" in _msg or "duplicate" in _msg)):
            raise HTTPException(
                status_code=409,
                detail=(f"A connection named {request.name!r} already "
                        f"exists -- choose another name.")) from e
        raise HTTPException(status_code=500, detail=str(e))


# ── ConnectionBrain integration (2026-06-16) ────────────────────────────
# Single entry point for "this connection changed — re-learn everything
# you should know about its data layout".  The brain owns the bg-thread,
# the contextvar propagation, and the discovery-step registry.  Adding a
# new type of discovery (schema warming, metadata-key prefetch, column-
# stats summaries) is a one-method change inside core/connection_brain.py
# — this file stays untouched.
#
# Why an orchestrator instead of inline bg-threads per discovery type:
#   - One spawn pattern, one contextvar story (portal-auth STS resolution
#     would have needed contextvars.copy_context() in every callsite)
#   - One place that knows how to build the S3 client + read decrypted
#     config, instead of repeating that boilerplate per discovery
#   - Steps run sequentially so later steps can depend on earlier
#     findings (e.g. column-stats summary needs partition_columns first)

def _schedule_partition_discovery(connection_id: int) -> None:
    """Compatibility shim — delegate to the ConnectionBrain orchestrator.

    Both create_connection and update_connection call this helper; keeping
    the name preserves the call sites while the implementation routes
    through the brain.  When other code paths (e.g. table-register, table-
    refresh) want eager learning, they should call get_brain().refresh()
    directly rather than going through this shim.
    """
    try:
        from core.connection_brain import get_brain
        get_brain().refresh(int(connection_id))
    except Exception as exc:
        logger.warning(
            "[brain] refresh failed for connection=%d: %s",
            connection_id, exc,
        )


# NOTE: static /test route MUST be before /{connection_id} to avoid routing conflict
@router.post("/api/connections/test")
async def test_connection(request: ConnectionTestRequest, _user: dict = Depends(require_admin)):
    """Test a connection configuration without saving — runs in thread so event loop stays free."""
    conn_type = request.connection_type
    conn_cfg  = dict(request.config)

    # When editing a saved connection the browser sends "***" for any sensitive
    # field the user did not change.  Substitute those placeholders with the
    # real (decrypted) values from the DB so the test uses valid credentials.
    #
    # SECURITY AUDIT 2026-08-03 (S2): the old substitution was an exfiltration
    # primitive — it un-masked ANY submitted key (not just SENSITIVE_FIELDS)
    # against the DECRYPTED stored config, with no ownership check and no
    # check that the submitted connection_type / target host matched the
    # stored connection.  Exploit: submit {"connection_id": <victim>,
    # "connection_type": "rest_api", "config": {"base_url": "https://attacker",
    # "password": "***"}} and the victim's real password is sent to the
    # attacker's host by the connector.  Now:
    #   1. unmasking requires the caller to be the OWNER of the stored
    #      connection (or admin; legacy rows with no recorded owner keep
    #      their org-shared semantics),
    #   2. the submitted connection_type must MATCH the stored one,
    #   3. only fields in crypto.SENSITIVE_FIELDS are ever substituted,
    #   4. every target-defining field (host/base_url/endpoint_url/…) the
    #      caller submits must match the stored value — changing the target
    #      host requires re-entering the credential.
    if request.connection_id is not None:
        raw = await _adb(_db_manager.get_connection_raw, request.connection_id)
        if raw:
            # any depth (2026-10-12): a nested secret is masked too
            from core.crypto import has_masked as _has_masked
            _wants_unmask = _has_masked(conn_cfg)
            if _wants_unmask:
                # (1) ownership — owner or admin only (masked values mean the
                # caller is asking us to inject the STORED secret).
                if _auth_cfg and _auth_cfg.type != "none" and not is_admin_like(_user):
                    _owner = str(raw.get("created_by") or "").strip()
                    if _owner and _owner != str(_user.get("username") or ""):
                        raise HTTPException(
                            status_code=403,
                            detail="Only the connection owner (or an admin) can test "
                                   "with stored credentials — re-enter the credential "
                                   "to test this connection.",
                        )
                # (2) connection_type must match the stored connection.
                if str(request.connection_type) != str(raw.get("connection_type")):
                    raise HTTPException(
                        status_code=400,
                        detail="connection_type does not match the stored connection — "
                               "stored credentials can only be tested against the "
                               "connection's own type.",
                    )
                # (4) target-defining fields must match the stored config.
                raw_cfg_pre = raw.get("config", {}) or {}
                _TARGET_KEYS = (
                    "host", "port", "base_url", "endpoint_url", "account",
                    "server", "dsn", "url", "token_url", "auth_url",
                    "workgroup", "s3_staging_dir", "http_path", "warehouse",
                )
                for _tk in _TARGET_KEYS:
                    _sub_v = conn_cfg.get(_tk)
                    if _sub_v in (None, ""):
                        continue
                    _stored_v = raw_cfg_pre.get(_tk)
                    if str(_sub_v).strip() != str(_stored_v or "").strip():
                        raise HTTPException(
                            status_code=400,
                            detail=f"'{_tk}' does not match the saved connection — "
                                   "re-enter the credential to test against a "
                                   "different target.",
                        )
            # (3) substitute ONLY known-sensitive fields.
            # THE rule (core/crypto.py::restore_masked), at any depth
            from core.crypto import restore_masked as _restore_masked
            raw_cfg = raw.get("config", {}) or {}
            conn_cfg = _restore_masked(conn_cfg, raw_cfg)

    # 2026-06-24 -- explicit pre-flight check for ssl_verify path.
    # When the operator picks "Custom CA Bundle" + enters a .pem path,
    # the value lands as a string in conn_cfg["ssl_verify"].  If that
    # path doesn't EXIST on the API pod's filesystem (common cause:
    # operator entered their LOCAL machine path), ``resolve_ssl``
    # silently falls back to system CA and the connection test
    # proceeds with the WRONG SSL config.  The actual error is then
    # whatever boto3 reports (often a generic TLS failure), and the
    # operator can't tell their .pem was ignored.  Surface the issue
    # here with a clear, actionable message before any TLS even runs.
    _ssl_v = conn_cfg.get("ssl_verify")
    if isinstance(_ssl_v, str) and _ssl_v.strip() and _ssl_v.strip().lower() not in ("true", "false"):
        import os as _os
        _pem_path = _ssl_v.strip()
        if not _os.path.isfile(_pem_path):
            raise HTTPException(
                status_code=400,
                detail=(
                    f"CA bundle path '{_pem_path}' not found on the API "
                    f"pod's filesystem.  The .pem file must be present "
                    f"INSIDE the container (e.g. mounted via a Kubernetes "
                    f"volume / ConfigMap / Secret, or baked into the image). "
                    f"If you entered a path that exists on your local "
                    f"machine, that won't work -- the path must be the "
                    f"path the API pod can read.  Alternatively: drop the "
                    f"file at backend/certs/tls_bundle.pem (auto-detected), "
                    f"or pick 'Disabled' to skip TLS verification."
                ),
            )

    def _do():
        # THE test, by type (core.connection_test) -- the saved-connection
        # route and the component-health probe call the same function.
        from core.connection_test import run_connection_test
        return run_connection_test(conn_type, conn_cfg, conn_manager=_conn_manager)
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except HTTPException:
        raise
    except Exception as e:
        # 2026-09-14: anything escaping the connector's own handler (its
        # constructor, get_connector, close) used to surface as str(e) --
        # for a KeyError that is the bare string 'user'.
        # 2026-09-15: that message then died at main.py's 5xx chokepoint, which
        # replaces every 500 detail with "contact support" -- so the 'user'
        # KeyError became an even emptier answer than the one being fixed.
        # ``_do`` returns the connector's own {success, message} verdict, so
        # answer in that shape: one contract for "did it connect?", whether the
        # connector reported the failure or raised it.
        from core.error_sanitizer import explain_failure
        from core.connectors.base import admin_cause
        logger.error("Connection test (%s) raised: %s", conn_type, e,
                     exc_info=True)
        return {"success": False,
                "message": explain_failure(
                    admin_cause(e), subject=f"Connection test ({conn_type})",
                    config=conn_cfg)}


async def _connection_visible_to(conn: dict, _user: Optional[dict]) -> bool:
    """The visibility rule from ``list_connections`` / ``get_connection``.

    Extracted 2026-08-17 so the routes that reach a connection's STORED
    CREDENTIALS can share it instead of each re-deciding (most of them decided
    nothing at all -- see ``_require_connection_access``).
    """
    if not (_auth_cfg and _auth_cfg.type != "none"):
        return True
    if not _user or is_admin_like(_user):
        return True
    username = _user.get("username", "")
    if (conn.get("created_by") == username
            or conn.get("is_shared")
            or not conn.get("created_by")):   # legacy connections (no owner)
        return True
    try:
        from core.config import admin_governance as _gov
        if _gov.enabled:
            acl_ids = await _adb(
                _db_manager.list_connection_ids_for_user,
                username, roles=[_user.get("role", "viewer")])
            return conn.get("id") in (acl_ids or set())
    except Exception as _acl_exc:
        logger.warning("connection ACL check failed for user %s: %s",
                       username, _acl_exc)
    return False


async def _require_connection_access(connection_id: int,
                                     _user: Optional[dict]) -> dict:
    """Fetch a connection, or 404 if the caller may not see it.

    SECURITY 2026-08-17: ten routes on this router took NO auth dependency at
    all -- test, tables (GET and POST), table schema, schema cache,
    partitions, discover-tables, browse-folders and the two iceberg listers.
    Every one of them loads the connection record and hands it to a live
    connector or S3 client, so an anonymous caller could enumerate
    connection ids and walk any registered warehouse or bucket USING THE
    STORED CREDENTIALS -- without ever holding them.

    404 (not 403) on denial so the route is not an existence oracle, matching
    ``get_connection``.
    """
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if not await _connection_visible_to(conn, _user):
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn


async def _require_connection_edit(connection_id: int,
                                   _user: Optional[dict]) -> dict:
    """Fetch a connection, or refuse if the caller may not MODIFY it.

    SECURITY 2026-08-22: ``update_connection`` and ``delete_connection`` were
    gated on ``require_role("admin","analyst")`` ONLY -- a role check, never an
    ownership one.  So a second analyst could edit or delete another analyst's
    private connection; worse, ``update_connection`` substitutes the victim's
    DECRYPTED stored secret for any ``"***"`` field, so the target host could
    be repointed while keeping the stored credential (the exact attack the
    ``test_connection`` route was hardened against on 2026-08-17).

    Edit authority is stricter than visibility: OWNER or admin only.  A shared
    or ACL-granted connection is VIEWABLE by others but not editable by them.
    Legacy connections with no recorded owner keep their org-shared semantics
    (any analyst may edit), matching ``_connection_visible_to``.
    404 first if the caller cannot even see it (no existence oracle); 403 if
    they can see it but do not own it.
    """
    conn = await _require_connection_access(connection_id, _user)  # 404 if invisible
    if not (_auth_cfg and _auth_cfg.type != "none"):
        return conn
    if not _user or is_admin_like(_user):
        return conn
    owner = str(conn.get("created_by") or "").strip()
    if not owner:                        # legacy unowned -> org-shared
        return conn
    if owner != str(_user.get("username") or ""):
        raise HTTPException(
            status_code=403,
            detail="Only the connection owner (or an admin) can modify this connection")
    return conn


@router.get("/api/connections/{connection_id}")
async def get_connection(connection_id: int, _user: dict = Depends(get_current_user)):
    """Get a specific connection.

    SECURITY AUDIT 2026-08-03 (S3): now applies the SAME visibility rule as
    ``list_connections`` (owner / is_shared / legacy-unowned / explicit ACL
    grant / admin).  Pre-fix any authenticated user could fetch ANY
    connection by id, bypassing the list-level RLS.  Denied lookups return
    404 (not 403) so the route is not an existence oracle.
    """
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if _auth_cfg and _auth_cfg.type != "none" and _user and not is_admin_like(_user):
        username = _user.get("username", "")
        visible = (
            conn.get("created_by") == username
            or conn.get("is_shared")
            or not conn.get("created_by")   # legacy connections (no owner) visible to all
        )
        if not visible:
            # Explicit ACL grant (admin governance) — same source list_connections uses.
            try:
                from core.config import admin_governance as _gov
                if _gov.enabled:
                    acl_ids = await _adb(
                        _db_manager.list_connection_ids_for_user,
                        username, roles=[_user.get("role", "viewer")])
                    visible = conn.get("id") in (acl_ids or set())
            except Exception as _acl_exc:
                logger.warning("get_connection ACL check failed for user %s: %s",
                               username, _acl_exc)
        if not visible:
            raise HTTPException(status_code=404, detail="Connection not found")
        return _as_seen_by_non_admin(conn)
    return conn


@router.put("/api/connections/{connection_id}")
async def update_connection(connection_id: int, request: ConnectionConfigModel, _user: dict = Depends(require_admin)):
    """Update an existing connection"""
    try:
        # SECURITY 2026-08-22: owner-or-admin, not merely "an analyst".  Without
        # this a second analyst could repoint another analyst's connection host
        # while the '***' substitution below injects the victim's stored secret.
        await _require_connection_edit(connection_id, _user)
        # The frontend sends "***" for masked sensitive fields the user didn't change.
        # Replace those placeholders with the real (decrypted) values from the DB
        # so we don't accidentally store "***" as the actual credential.
        updated_config = dict(request.config)
        raw = await _adb(_db_manager.get_connection_raw, connection_id)
        if raw:
            raw_cfg = raw.get("config", {})
            stored_cfg = await _adb(_db_manager.get_connection_stored_config,
                                    connection_id) or {}
            # THE rule, at any depth (core/crypto.py::restore_masked,
            # 2026-10-12): "***" takes the stored decrypted value; a value
            # this pod cannot DECRYPT is KEPT as stored (encrypted) -- this
            # wrote "" once and destroyed a credential the right key could
            # still read (2026-10-02); nothing stored -> "".
            from core.crypto import restore_masked as _restore_masked

            def _warn_undecryptable(path, _cid=connection_id):
                logger.warning(
                    "Credential field '%s' of connection %d cannot be decrypted "
                    "with this pod's key — kept as stored (encrypted); re-enter "
                    "it, or restore the key it was saved with.", path, _cid)
            updated_config = _restore_masked(updated_config, raw_cfg, stored_cfg,
                                             on_undecryptable=_warn_undecryptable)

        update_kwargs = dict(
            name=request.name,
            connection_type=request.connection_type,
            config=updated_config,
        )
        # Allow toggling is_shared
        if hasattr(request, "is_shared") and request.is_shared is not None:
            update_kwargs["is_shared"] = bool(request.is_shared)

        from core.connection_duplicates import check_update as _dup_update
        async with _one_connection_per_bucket(
                lambda conns: _dup_update(conns, connection_id, raw,
                                          request.connection_type,
                                          updated_config)):
            conn = await _adb(_db_manager.update_connection, connection_id,
                              **update_kwargs)
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        # 2026-09-27 — the whole-config save is how the UI registers and
        # unregisters tables; diff the Iceberg set before/after and keep
        # watched_iceberg_tables in step.
        await _sync_watches(connection_id, before=raw,
                            after={"config": updated_config})
        await _adb(_conn_manager.invalidate_cache, connection_id)
        # Invalidate query result cache entries that used this connection
        from core.query_cache import invalidate_by_source
        invalidate_by_source(connection_id=connection_id)
        # Invalidate connection pool (Phase 40)
        try:
            from core.connection_pool import invalidate_pool
            invalidate_pool(connection_id)
        except Exception:
            pass
        # 2026-06-16 — also evict the data_grid_api DuckDB streaming pool.
        # Pre-fix this pool held cached DuckDB connections configured with
        # SET s3_endpoint at the OLD endpoint_url value.  When the user
        # added or changed endpoint_url, only the boto3 handler cache
        # was evicted; streaming queries kept using the stale DuckDB
        # connection and hitting the old (or empty) s3_endpoint.
        # Symptom: "test connection works through VPC but data browse /
        # query fails when proxy is off" — because the streaming pool's
        # DuckDB connection bypassed the VPC URL.
        try:
            from api.data_grid_api import evict_s3_pool
            evict_s3_pool(connection_id)
        except Exception as _eg_exc:
            logger.debug("evict_s3_pool skipped: %s", _eg_exc)
        # Invalidate S3 file listing cache
        try:
            from core.s3_utilities import clear_listing_cache
            clear_listing_cache(connection_id)
        except Exception:
            pass
        # BF-555 (2026-05-29): drop the schema cache for this connection
        # so stale column types / table lists don't survive a catalog
        # update.  L1 in-process + L2 DB-backed both cleared.  Without
        # this, queries reference the OLD schema until the 600 s L1 TTL
        # expires, causing "no such column" or wrong-type errors.
        try:
            _schema_cache.delete_prefix(f"sql:{connection_id}:")
            _schema_cache.delete_prefix(f"{connection_id}:")
        except Exception as _sc_exc:
            logger.debug("BF-555 schema cache invalidate skipped: %s", _sc_exc)
        try:
            await _adb(_db_manager.delete_schema_cache,
                       connection_id=connection_id)
        except Exception as _sc_db_exc:
            logger.debug("BF-555 DB schema cache delete skipped: %s", _sc_db_exc)
        # 2026-06-16 — same strategic eager-discovery hook as create_connection.
        # registered_tables can change on update (new table added, partition
        # changed), so we re-detect any whose partition_columns is empty.
        _schedule_partition_discovery(connection_id)
        # Return masked config — never send encrypted or plaintext credentials to browser
        from core.crypto import masked_for_client, undecryptable_fields
        conn["credential_problems"] = undecryptable_fields(conn.get("config", {}))
        conn["config"] = masked_for_client(conn.get("config", {}))
        return conn
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _forget_connection_schema(connection_id: int,
                              conn: Optional[Dict[str, Any]]) -> None:
    """Drop every schema record keyed by a DELETED connection's id (see
    ``delete_connection``).  Best-effort per layer; never raises."""
    try:
        _schema_cache.delete_prefix(f"sql:{connection_id}:")
        _schema_cache.delete_prefix(f"{connection_id}:")
    except Exception as exc:
        logger.debug("delete: schema L1 clear skipped: %s", exc)
    try:
        _db_manager.delete_schema_cache(connection_id=connection_id)
    except Exception as exc:
        logger.debug("delete: schema_cache rows clear skipped: %s", exc)
    try:
        from core.schema_catalog import ColumnCatalog
        cat = ColumnCatalog(_db_manager)
        for t in ((conn or {}).get("config") or {}).get("registered_tables") or []:
            if isinstance(t, dict) and t.get("name"):
                cat.delete_entry(connection_id, t["name"])
    except Exception as exc:
        logger.debug("delete: column catalog clear skipped: %s", exc)


@router.delete("/api/connections/{connection_id}")
async def delete_connection(connection_id: int, acknowledge_dependents: bool = False,
                            _user: dict = Depends(require_admin)):
    """Delete a connection and clean up uploaded files if applicable.

    2026-10-17 -- refused (409, naming them and their consumers) while a
    PUBLISHED API rests on it (core/published_api/impact.py: a view's
    primary / execution / engine connection, a report's dataset connection);
    ``acknowledge_dependents=true`` deletes anyway and audits the names.
    "Could not check" refuses too (503)."""
    try:
        # SECURITY 2026-08-22: owner-or-admin only.  Role alone let any analyst
        # delete another analyst's private connection.
        await _require_connection_edit(connection_id, _user)
        from api.published_api_api import refuse_if_apis_depend_async
        await refuse_if_apis_depend_async(_db_manager, "connection", connection_id,
                                          acknowledged=acknowledge_dependents, actor=_user)
        # Check if this is an upload connection — clean up files before deleting record
        conn = await _adb(_db_manager.get_connection, connection_id)
        if conn and conn.get("connection_type") == "upload":
            import shutil
            upload_dir = _paths.upload_dir / str(connection_id)
            if upload_dir.exists():
                shutil.rmtree(upload_dir, ignore_errors=True)
                logger.info("Cleaned up upload directory for connection %s: %s", connection_id, upload_dir)

        success = await _adb(_db_manager.delete_connection, connection_id, soft_delete=False)
        if not success:
            raise HTTPException(status_code=404, detail="Connection not found")
        # 2026-09-27 — a deleted connection's tables are unwatched.
        await _sync_watches(connection_id, before=conn, after=None)
        # 2026-10-07 -- and its schema knowledge goes with it.  The schema
        # cache (L1 + the ``schema_cache`` rows) and the column catalog are
        # keyed by connection ID, and SQLite REUSES the highest id after a
        # delete: the next connection created inherited the deleted one's
        # columns as fact (found when tests began deleting their connections
        # -- one bucket = one connection).  Same clearing as BF-555 on update.
        await _adb(_forget_connection_schema, connection_id, conn)
        await _adb(_conn_manager.invalidate_cache, connection_id)
        # Invalidate query result cache entries that used this connection
        from core.query_cache import invalidate_by_source
        invalidate_by_source(connection_id=connection_id)
        # Invalidate connection pool (Phase 40)
        try:
            from core.connection_pool import invalidate_pool
            invalidate_pool(connection_id)
        except Exception:
            pass
        # Evict data_grid streaming DuckDB pool — same gap as update_connection
        try:
            from api.data_grid_api import evict_s3_pool
            evict_s3_pool(connection_id)
        except Exception as _eg_exc:
            logger.debug("evict_s3_pool skipped on delete: %s", _eg_exc)
        # Invalidate S3 file listing cache
        try:
            from core.s3_utilities import clear_listing_cache
            clear_listing_cache(connection_id)
        except Exception:
            pass
        # 2026-06-16 — clear ConnectionBrain learned state for this connection
        # so a future connection with the same id (rare but possible in dev)
        # doesn't inherit stale partition_columns / metadata.  Currently a
        # no-op log (caches are LRU-bounded) but lives here as the cleanup
        # extension point per the brain's forget() contract.
        try:
            from core.connection_brain import get_brain
            get_brain().forget(connection_id)
        except Exception as _brain_forget_exc:
            logger.debug("[brain] forget failed for connection=%d: %s",
                         connection_id, _brain_forget_exc)
        audit_event(_db_manager, _user, None, "delete_connection", "connection", connection_id)
        return {"message": "Connection deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class CloneConnectionRequest(StrictRequestModel):
    """The ONLY thing a clone may change is the name.

    FB-62 (2026-09-23).  This model is deliberately this small, and the
    smallness IS the security control -- see :func:`clone_connection`.  It
    carries no host, port, endpoint or config, so "clone it and point the copy
    somewhere else" cannot be expressed in one request at all.  ``extra`` is
    forbidden (StrictRequestModel), so a caller who tries gets a 422 naming
    the field rather than a 201 that quietly ignored it.
    """

    name: Optional[str] = Field(default=None, max_length=255)


def _unique_connection_name(existing: List[str], base: str) -> str:
    """``base``, or ``base (2)``, ``base (3)``... — the first name not taken.

    Connection names are not unique in the schema, so this is a courtesy, not
    a constraint: two connections called "Prod Oracle" are legal and merely
    unusable in a picker.  Bounded rather than a while-True: at 200 copies the
    caller has a different problem and a request must still terminate.
    """
    taken = {str(n or "").strip().lower() for n in existing}
    if base.strip().lower() not in taken:
        return base
    for n in range(2, 200):
        candidate = f"{base} ({n})"
        if candidate.lower() not in taken:
            return candidate
    return f"{base} ({uuid.uuid4().hex[:8]})"


@router.post("/api/connections/{connection_id}/clone", status_code=201)
async def clone_connection(connection_id: int, body: CloneConnectionRequest,
                           http_req: Request,
                           _user: dict = Depends(require_admin)):
    """Copy a connection, credentials included, WITHOUT exposing them.

    FB-62 (2026-09-23), asked for by the operator.  Four other entities already
    clone (feeds, business reports, dataflows, feed groups); this one is the
    only clone that carries a SECRET, so it is the only one where the obvious
    implementation is an exfiltration primitive.

    THE ATTACK THIS IS SHAPED AGAINST.  ``update_connection`` substitutes the
    stored DECRYPTED secret for any ``"***"`` field, so whoever can edit a
    connection can already repoint its host while keeping its credential --
    that is why edit authority is owner-or-admin and not merely "an analyst"
    (SECURITY 2026-08-22, :func:`_require_connection_edit`).  A clone gated on
    the READ right would hand that same capability to everyone a connection is
    merely SHARED with: clone it, become the owner of the copy, repoint the
    copy, press Test, and the secret is delivered to a host of your choosing.

    So the gate here is the EDIT right on the SOURCE, deliberately stricter
    than the visibility that lets a connection appear in your list.  Given
    that, the clone grants no new power: a caller who may clone could already
    repoint the original.

    Three further rules, each one because the alternative is a hole:

    * **One request cannot both clone and redirect.**
      :class:`CloneConnectionRequest` accepts a name and nothing else, so
      changing the host is necessarily a SECOND request -- an ordinary update,
      already owner-gated, already audited, and already subject to the SSRF
      validation every write goes through.
    * **The copy is never shared.**  ``is_shared`` is forced False whatever the
      source was: inheriting an audience would widen who can reach a credential
      as a side effect of an operation nobody described as sharing.
    * **The plaintext never reaches the caller.**  The config is decrypted only
      to be re-encrypted by ``create_connection``, and the response is masked
      exactly as create/get return it.

    Not copied: the schema catalog and every cache keyed on the old connection
    id (they are not part of ``config``, and a cache re-keyed onto a different
    connection is how stale columns get served as fact).  Registered tables ARE
    copied -- they are the point of cloning -- so partition discovery is
    scheduled for the copy the same way it is for a create.
    """
    from api.deps import enforce_user_resource_quota
    enforce_user_resource_quota(_user, "connections")
    try:
        # EDIT, not read: 404 if invisible, 403 if visible-but-not-owned.
        src = await _require_connection_edit(connection_id, _user)
        raw = await _adb(_db_manager.get_connection_raw, connection_id)
        if not raw:
            raise HTTPException(status_code=404, detail="Connection not found")

        from core.crypto import decrypt_config, mask_config, undecryptable_fields
        # 2026-10-02 -- a secret this pod cannot decrypt would be copied as
        # "" -- a clone that silently has no password.  Refuse, naming it.
        _bad = undecryptable_fields(
            await _adb(_db_manager.get_connection_stored_config, connection_id) or {})
        if _bad:
            raise HTTPException(status_code=422, detail=(
                f"The saved {', '.join(_bad)} of this connection cannot be decrypted "
                f"on this server (the encryption key changed since it was saved). "
                f"Edit the connection and enter it again, then clone it."))
        source_config = decrypt_config(dict(raw.get("config") or {}))

        requested = (body.name or "").strip()
        base_name = requested or f"{src.get('name') or 'Connection'} (copy)"
        try:
            existing = await _adb(_db_manager.list_connections, False)
            names = [c.get("name") for c in (existing or [])]
        except Exception as _ls_exc:
            # A naming courtesy must never be the reason a clone fails.
            logger.debug("clone: could not list names for de-duplication: %s",
                         _ls_exc)
            names = []
        new_name = _unique_connection_name(names, base_name)

        # 2026-10-07 -- a clone of an S3 connection reads the SAME bucket (a
        # clone may change nothing but the name), so it is refused with the
        # connection that already holds the bucket; every other type clones.
        from core.connection_duplicates import check_create as _dup_clone
        async with _one_connection_per_bucket(
                lambda conns: _dup_clone(conns, src.get("connection_type"),
                                         source_config,
                                         action="clone this connection")):
            conn = await _adb(
                _db_manager.create_connection,
                name=new_name,
                connection_type=src.get("connection_type"),
                config=source_config,
                workspace_id=get_workspace_id(http_req),
            )
        username = (_user or {}).get("username", "guest")
        await _adb(_db_manager.update_connection, conn["id"],
                   created_by=username, is_shared=False)
        conn["created_by"] = username
        conn["is_shared"] = False

        _schedule_partition_discovery(conn["id"])

        # The audit trail records the SOURCE as well as the copy: "where did
        # this credential come from" is the question an auditor asks first.
        audit_event(_db_manager, _user, None, "clone_connection", "connection",
                    f"{connection_id}->{conn['id']}")

        if conn and "config" in conn:
            conn["config"] = mask_config(decrypt_config(conn.get("config", {})))
        return conn
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("clone_connection failed for id=%s: %s",
                       connection_id, e)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/refresh-credentials")
async def refresh_connection_credentials(connection_id: int, _user: dict = Depends(require_admin)):
    """Force-refresh cached S3 handler credentials for a connection.

    Invalidates the cached handler so the next operation creates a fresh
    boto3 session with new STS/SSO credentials.  Also immediately recreates
    the handler and tests the connection to validate the new credentials.
    """
    # SECURITY 2026-08-22: this reached get_connection_raw (DECRYPTED config)
    # and drove a live STS/SSO fetch for ANY connection id on get_current_user
    # alone.  Require at least visibility of the connection first.
    await _require_connection_access(connection_id, _user)
    conn = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn["connection_type"]
    cfg = conn["config"]

    if conn_type == "s3":
        await _adb(_conn_manager.invalidate_cache, connection_id)
        auth_mode = (cfg.get("auth_mode") or "").lower()
        # Portal mode: force-refresh via credential manager
        if auth_mode == "portal":
            try:
                from core.credential_manager import get_credential_manager
                cm = get_credential_manager()
                if cm:
                    # BF-NONBLOCK-AUDIT-7: refresh_and_retry hits SSO HTTP
                    fresh = await asyncio.to_thread(
                        cm.refresh_and_retry, cfg, _user.get("username", ""))
                    if fresh:
                        handler = await _adb(_conn_manager._get_s3_handler, connection_id, fresh)
                        # boto3 head_bucket: sync network call, wrap.
                        result = await asyncio.to_thread(handler.test_connection)
                        if result.get("connected"):
                            return {"status": "ok", "message": "Portal credentials refreshed successfully"}
                        # 2026-06-16 — forward s3_storage's [DIAG] block.  Same
                        # reason as _test_s3_connection: the multi-line
                        # diagnostic answers "why did the network fail" and
                        # was previously being silently dropped by this
                        # stripping wrapper.
                        _resp = {"status": "error",
                                 "message": result.get("error", "Test failed after refresh")}
                        if result.get("diagnostic"):
                            _resp["diagnostic"] = result["diagnostic"]
                        return _resp
            except Exception as exc:
                return {"status": "error", "message": f"Portal refresh failed: {exc}"}
        # Legacy: recreate handler with current creds
        try:
            handler = await _adb(_conn_manager._get_s3_handler, connection_id, cfg)
            result = await asyncio.to_thread(handler.test_connection)
            if result.get("connected"):
                return {"status": "ok", "message": "Credentials refreshed successfully"}
            else:
                _resp = {"status": "error",
                         "message": result.get("error", "Connection test failed after refresh")}
                if result.get("diagnostic"):
                    _resp["diagnostic"] = result["diagnostic"]
                return _resp
        except Exception as e:
            logger.warning("Credential refresh failed for connection %d: %s", connection_id, e)
            return {"status": "error", "message": str(e)}

    elif conn_type == "snowflake" and (cfg.get("auth_type") or "").lower() == "sso_portal":
        try:
            from core.credential_manager import get_credential_manager
            cm = get_credential_manager()
            if cm:
                # BF-NONBLOCK-AUDIT-7: SSO portal call + Snowflake network
                # connect — both sync, both slow.  Wrap each.
                fresh = await asyncio.to_thread(
                    cm.resolve_snowflake_credentials,
                    cfg, _user.get("username", ""), force_refresh=True)
                from core.connectors import get_connector
                connector = get_connector("snowflake", fresh)
                test_result = await asyncio.to_thread(connector.test_connection)
                return {"status": "ok" if test_result.get("success") else "error",
                        "message": test_result.get("message", "")}
        except Exception as exc:
            return {"status": "error", "message": f"Snowflake SSO refresh failed: {exc}"}

    elif conn_type != "s3":
        raise HTTPException(status_code=400, detail="Only S3 and Snowflake SSO connections have refreshable credentials")

    return {"status": "error", "message": "Refresh not supported for this connection type"}


@router.post("/api/connections/{connection_id}/test")
async def test_saved_connection(connection_id: int,
                                _user: dict = Depends(get_current_user)):
    """Test a saved connection and persist the result — runs in thread so event loop stays free."""
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    # Fetch raw creds synchronously (fast SQLite read) before entering executor
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw['connection_type']

    def _do():
        # THE test, by type (core.connection_test), on the DECRYPTED config,
        # through THIS connection's circuit breaker on this pod (2026-10-18:
        # a saved connection's failed tests count toward its breaker; an OPEN
        # breaker fast-fails the test with its own message).
        from core.connection_test import run_connection_test
        return run_connection_test(conn_type, conn_raw['config'], conn_manager=_conn_manager,
                                   connection_id=connection_id, connection_name=conn_raw.get('name') or '')

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        await _adb(_db_manager.update_connection,
            connection_id,
            last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
            last_test_status='success' if result['success'] else 'failed',
            last_test_message=result.get('message', '')
        )
        if result.get('success'):
            # 2026-08-22 — a successful test proves the source is reachable
            # RIGHT NOW: the cheapest moment to top up any registered tables
            # whose columns the local catalog does not have yet.  Background,
            # bounded, debounced — never inline on this request.
            try:
                from core.schema_catalog import schedule_topup
                schedule_topup(_db_manager, _conn_manager, connection_id,
                               reason="connection test succeeded")
            except Exception as topup_exc:
                logger.warning("Could not schedule column-catalog top-up "
                               "after test for %s: %s", connection_id, topup_exc)
        return result
    except HTTPException:
        raise
    except Exception as e:
        # 2026-09-15 — a test that RAISED is still a test RESULT, and this route
        # already knows exactly why it failed: ``explain_failure`` renders (and
        # sanitises) the reason.  Raising 500 threw that reason away, because
        # main.py's CWE-209 chokepoint replaces every 5xx detail with "contact
        # support" — so the one route whose entire job is to report WHY was
        # guaranteed to report nothing.  Worse, this path never persisted the
        # outcome: a connection that had just failed hard kept its previous
        # ``last_test_status``, so the audit trail denied a test that happened.
        # Answer in the SAME shape the handled path uses (200 + success:false),
        # and record the failure, so both paths answer "did it connect?" once.
        from core.error_sanitizer import explain_failure
        from core.connectors.base import admin_cause
        _label = (f"Connection test for '{conn_raw.get('name') or connection_id}' "
                  f"(id {connection_id}, {conn_type})")
        _message = explain_failure(admin_cause(e), subject=_label,
                                   config=conn_raw.get('config') or {})
        logger.error("Connection test raised for %s (id %s, %s): %s",
                     conn_raw.get('name'), connection_id, conn_type, e,
                     exc_info=True)
        try:
            await _adb(_db_manager.update_connection,
                connection_id,
                last_tested_at=datetime.now(timezone.utc).replace(tzinfo=None),
                last_test_status='failed',
                last_test_message=_message,
            )
        except Exception as persist_exc:   # never mask the real failure
            logger.warning("Could not persist failed test status for %s: %s",
                           connection_id, persist_exc)
        return {"success": False, "message": _message}


# ── Connection Files and Schema Endpoints ─────────────────────────────────────

def _driver_not_installed_501(exc: BaseException, conn_type: str) -> HTTPException:
    """The browse routes' answer for a connector whose driver is missing.

    2026-09-15.  ``POST .../test`` answered ``{success: false, message:
    "databricks-sql-connector is not installed..."}`` while ``GET
    .../tables`` raised 502 and ``GET .../files`` 500 -- both erased by
    main.py's CWE-209 chokepoint into "contact support".  A missing driver
    is a CAPABILITY statement about this server (the precedent: PDF export
    -> 501), and the chokepoint lets a 501 through with its detail.  One
    message for all three routes, and it names the package.
    """
    # 2026-09-17 -- the BODY moved to api.connector_errors so the CQB schema
    # browser answers the same question the same way; this stays as the name
    # its callers already use.  Two copies of a mapping is two answers waiting
    # to diverge, which is how the split this helper exists to fix began.
    from api.connector_errors import driver_not_installed_501
    return driver_not_installed_501(exc, conn_type)


@router.get("/api/connections/{connection_id}/files")
async def list_connection_files(connection_id: int, folder: str = "", _user: dict = Depends(get_current_user)):
    """List tables/files for a connection.
    - S3 / local  → parquet file listing via ConnectionManager
    - SQL connectors → list tables from the configured catalog.schema
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES, DriverNotInstalled
    from core.s3_storage import TokenExpiredError
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        def _list_sql_tables():
            cfg = conn_raw["config"]
            # 2026-09-16 POOLED — schema browsing is the most frequent
            # interactive connector use in the product, and it opened a
            # fresh session per click.  Releases on success, discards on
            # any exception; identical behaviour when pooling is off.
            from core.connection_pool import get_pooled_connector
            with get_pooled_connector(connection_id, conn_type, cfg,
                                      conn_raw.get("name", "")) as connector:
                catalog = cfg.get("catalog") or cfg.get("database") or ""
                schema  = cfg.get("schema") or ""
                if not schema:
                    # 2026-09-15 -- this defaulted to the literal "public",
                    # which is a Postgres/Trino spelling.  An Oracle
                    # connection carries no `schema` (it connects AS its
                    # owner), so every Oracle browse asked for a schema that
                    # does not exist and got zero rows: HTTP 200, [], "this
                    # source has no tables", while the source had six.
                    # Unknown is not empty -- ask the ENGINE what its current
                    # schema is instead of assuming another engine's.  Oracle
                    # is the proven member (live, 23-free); other engines keep
                    # the historical "public" until one is proved the same way.
                    from core.connection_manager import NO_CATALOG_LEVEL_TYPES
                    if conn_type in NO_CATALOG_LEVEL_TYPES:
                        _current = [c for c in (connector.list_catalogs() or [])
                                    if str(c or "").strip()]
                        if not _current:
                            raise HTTPException(
                                status_code=400,
                                detail=(
                                    f"Cannot list tables for this {conn_type} "
                                    f"connection: it has no 'schema' configured "
                                    f"and the server did not report a current "
                                    f"schema. Set the schema on the connection."))
                        schema, catalog = str(_current[0]), ""
                    else:
                        # FB-29 (2026-09-19) -- PROVED for Trino, the proof the
                        # comment above asked for: connection 2 (trino,
                        # catalog=tpch, schema=NULL) asked for "public", got
                        # SCHEMA_NOT_FOUND "Schema 'public' does not exist",
                        # and the browse 500'd.  There is no "public" on any
                        # engine but Postgres.  With no schema configured the
                        # browse now asks the ENGINE for the catalog's schemas
                        # and lists every one (information_schema excluded);
                        # each path is catalog.schema.table, so the column
                        # route below never has to guess a schema either.
                        schema = None
                if schema is None:
                    if not catalog:
                        raise HTTPException(
                            status_code=400,
                            detail=(
                                f"Cannot list tables for this {conn_type} "
                                f"connection: it has neither a 'catalog' nor a "
                                f"'schema' configured, so there is nothing to "
                                f"browse.  Set the catalog (and optionally the "
                                f"schema) on the connection."))
                    _schemas = [s for s in (connector.list_schemas(catalog) or [])
                                if str(s or "").strip()
                                and str(s).lower() != "information_schema"]
                    if not _schemas:
                        raise HTTPException(
                            status_code=400,
                            detail=(
                                f"Catalog {catalog!r} on this {conn_type} "
                                f"connection reports no schemas to browse."))
                    _pairs = [(catalog, s) for s in _schemas]
                else:
                    _pairs = [(catalog, schema)]
                result = []
                for _cat, _sch in _pairs:
                    tables = connector.list_tables(_cat, _sch)
                    # Normalise to the same shape the frontend expects for file items
                    for t in tables:
                        tname = t["name"]
                        full_path = f"{_cat}.{_sch}.{tname}" if _cat else f"{_sch}.{tname}"
                        result.append({
                            "name":       tname,
                            "path":       full_path,
                            "folder":     f"{_cat}/{_sch}" if _cat else _sch,
                            "num_rows":   None,
                            "num_columns": None,
                            "size_bytes": None,
                            "table_type": t.get("type", "TABLE"),
                        })
                return result

        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(_get_light_executor(), _list_sql_tables)
        except HTTPException:
            raise
        except DriverNotInstalled as e:
            raise _driver_not_installed_501(e, conn_type)
        except Exception as e:
            # FB-29b (2026-09-19): every non-driver failure here was a bare
            # 500 whose detail the chokepoint erases -- SCHEMA_NOT_FOUND, a
            # missing credential, an unreachable host all became "contact
            # support".  The source's own sentence is what the operator
            # needs: a refused browse is 400 with it (the same rendering the
            # dataset preview uses); a self-clearing breaker is 503 +
            # Retry-After; a missing driver 501; the rest stay 500.
            from api.connector_errors import connector_http_error, is_self_clearing
            if is_self_clearing(e) or isinstance(e, DriverNotInstalled):
                raise connector_http_error(e, conn_type)
            from core.connectors.base import SourceUnavailableError, wrap_source_failure
            _classified = wrap_source_failure(
                e, conn_type, subject="Browsing the {conn_type} source")
            if isinstance(_classified, SourceUnavailableError):
                # FB-39: could not be reached -> 503 + Retry-After.
                raise connector_http_error(_classified, conn_type) from None
            raise HTTPException(status_code=400, detail=str(_classified)) from None

    # S3 / local path.
    # Log the resolved endpoint_url AT THIS ENTRY POINT so a triage from
    # the file-browser failure ("unable to see bucket info") can be
    # correlated with the actual endpoint the cached handler uses.  Without
    # this, head_bucket-via-VPC-works-but-list_objects-via-VPC-fails was
    # impossible to confirm from logs alone.
    loop = asyncio.get_running_loop()
    _cfg_for_log = conn_raw.get("config", {}) or {}
    logger.info(
        "list_connection_files conn=%s folder=%r endpoint_url=%s auth_mode=%s",
        connection_id, folder,
        _cfg_for_log.get("endpoint_url") or "(none — public AWS S3)",
        _cfg_for_log.get("auth_mode") or "keys",
    )
    try:
        return await loop.run_in_executor(
            _get_light_executor(), _conn_manager.list_files, connection_id, folder
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        # Auto-retry for portal connections
        cfg = conn_raw.get("config", {})
        if (cfg.get("auth_mode") or "").lower() == "portal":
            try:
                from core.credential_manager import get_credential_manager
                cm = get_credential_manager()
                if cm:
                    await _adb(_conn_manager.invalidate_cache, connection_id)
                    fresh = cm.refresh_and_retry(cfg, _user.get("username", ""))
                    if fresh:
                        conn_raw["config"] = fresh
                        return await loop.run_in_executor(
                            _get_light_executor(), _conn_manager.list_files, connection_id, folder
                        )
            except Exception:
                pass
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except Exception as e:
        # 2026-06-16 — surface the [DIAG] block on EndpointConnectionError +
        # friends so the operator sees DNS / proxy / IP-class / bucket-name
        # context instead of a bare botocore message.  Same fix as the
        # partition endpoint.
        #
        # ALSO surface endpoint_used so the operator can confirm whether
        # the cached handler's client is using their VPC endpoint or
        # silently went to the public AWS S3 endpoint.
        logger.error("list_connection_files failed for conn=%s: %s",
                     connection_id, e, exc_info=True)
        _detail: Any = str(e)
        try:
            from core.s3_storage import _diagnose_endpoint_failure
            _cfg = conn_raw.get("config", {}) or {}
            _diag = _diagnose_endpoint_failure(
                e,
                bucket=(_cfg.get("bucket_name") or _cfg.get("bucket")
                        or _cfg.get("s3_bucket") or ""),
                configured_endpoint=_cfg.get("endpoint_url") or "",
                # region-display: the DIAGNOSTIC must show what the operator
                # actually CONFIGURED, not what resolution would pick. Resolving
                # here would hide a missing region from the one screen whose job
                # is to reveal it.
                configured_region=_cfg.get("region_name") or "us-east-1",
                path_style=bool(_cfg.get("path_style")),
            )
            _detail = {
                "message":         str(e),
                "diagnostic":      _diag,
                "error_code":      "S3_ENDPOINT_UNREACHABLE",
                "connection_id":   connection_id,
                "endpoint_used":   _cfg.get("endpoint_url") or "standard AWS S3",
                "configured_proxy": bool(_cfg.get("proxy")),
            }
        except Exception as _diag_exc:
            logger.debug("list_connection_files diag build skipped: %s",
                         _diag_exc)
        raise HTTPException(status_code=500, detail=_detail)


@router.get("/api/connections/{connection_id}/excel-sheets")
async def list_connection_excel_sheets(
    connection_id: int,
    file_path: str = "",
    _user: dict = Depends(get_current_user),
):
    """List worksheet names from an Excel file within a connection's file tree.

    Only supported for local/upload connections (not S3).
    """
    if not file_path:
        raise HTTPException(status_code=400, detail="file_path query parameter required")

    loop = asyncio.get_running_loop()
    try:
        sheets = await loop.run_in_executor(
            _get_light_executor(), _conn_manager.get_excel_sheets, connection_id, file_path
        )
        return {"sheets": sheets, "filename": os.path.basename(file_path)}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.warning("Failed to list Excel sheets: %s", e)
        raise HTTPException(status_code=500, detail=f"Failed to read Excel sheets: {e}")


@router.get("/api/connections/{connection_id}/files/{file_path:path}/schema")
async def get_connection_file_schema(connection_id: int, file_path: str, _user: dict = Depends(get_current_user)):
    """Get schema for a file or SQL table.
    - S3 / local  → parquet metadata via ConnectionManager
    - SQL connectors → list_columns(catalog, schema, table)
    """
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES, DriverNotInstalled
    from core.s3_storage import TokenExpiredError
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    conn_type = conn_raw["connection_type"]

    if conn_type in SQL_CONNECTOR_TYPES:
        # BF-361: cache SQL connector column lists with the same two-tier
        # cache the S3 path uses.  Without this, every CBQ click that
        # expands a Starburst/Snowflake/Trino table re-runs DESCRIBE
        # against the warehouse — slow + load-pattern visible to ops.
        # Cache key uses file_path (full cat.schema.table) so multiple
        # tables on the same connection don't collide.
        _sql_schema_ck = f"sql-schema:{connection_id}:{file_path}"
        cached = _schema_cache_get(_sql_schema_ck)
        if cached:
            return {**cached, "cache": "L1"}
        db_cached = await _adb(_db_manager.get_schema_cache,
                               connection_id, file_path)
        if db_cached:
            result = db_cached["schema_data"]
            _schema_cache_set(_sql_schema_ck, result)
            return {**result, "cache": "L2",
                    "cached_at": db_cached.get("updated_at")}

        def _sql_schema():
            cfg = conn_raw["config"]
            # 2026-09-16 POOLED — see _list_sql_tables above.
            from core.connection_pool import get_pooled_connector
            with get_pooled_connector(connection_id, conn_type, cfg,
                                      conn_raw.get("name", "")) as connector:
                # file_path is "catalog.schema.table" or "schema.table"
                parts = file_path.split(".")
                if len(parts) == 3:
                    catalog, schema, table = parts
                elif len(parts) == 2:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema, table = parts
                else:
                    catalog = cfg.get("catalog") or cfg.get("database") or ""
                    schema  = cfg.get("schema") or ""
                    table   = file_path
                    if not schema:
                        # FB-29: the browse now returns catalog.schema.table
                        # paths, so a bare table name with no configured
                        # schema is a request nothing can answer -- say so
                        # rather than guess "public" (which no engine but
                        # Postgres has).
                        raise HTTPException(
                            status_code=400,
                            detail=(
                                f"Cannot resolve table {file_path!r}: the "
                                f"connection has no 'schema' configured and "
                                f"the path carries none.  Use the "
                                f"catalog.schema.table path the browse "
                                f"returns, or set the schema on the "
                                f"connection."))
                cols = connector.list_columns(catalog, schema, table)
                return {"columns": cols}

        loop = asyncio.get_running_loop()
        try:
            result = await loop.run_in_executor(_get_light_executor(), _sql_schema)
            # Persist to L1 + the LOCAL COLUMN CATALOG (chokepoint writes
            # the legacy schema_cache L2 row too) so the columns of a
            # browsed Starburst/Snowflake/Trino table are saved locally
            # and never need the warehouse again to be LISTED.
            _schema_cache_set(_sql_schema_ck, result)
            await _record_catalog_columns(connection_id, file_path, conn_type,
                                          result, source="schema_browse")
            return {**result, "cache": "none"}
        except HTTPException:
            raise
        except DriverNotInstalled as e:
            raise _driver_not_installed_501(e, conn_type)
        except Exception as e:
            # FB-40 (2026-09-19): the last browse route hand-rolling a bare
            # 500.  The same seam the CQB browser uses: a driver transient
            # (a source still starting up) is 503 + Retry-After, a breaker
            # 503, a missing driver 501; the rest stay 500.
            from api.connector_errors import connector_http_error
            raise connector_http_error(e, conn_type, context="Error reading table schema")

    # S3 / local path
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            _get_light_executor(), _conn_manager.get_schema, connection_id, file_path
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except TokenExpiredError as e:
        # Auto-retry for portal connections
        cfg = conn_raw.get("config", {})
        if (cfg.get("auth_mode") or "").lower() == "portal":
            try:
                from core.credential_manager import get_credential_manager
                cm = get_credential_manager()
                if cm:
                    await _adb(_conn_manager.invalidate_cache, connection_id)
                    fresh = cm.refresh_and_retry(cfg, _user.get("username", ""))
                    if fresh:
                        conn_raw["config"] = fresh
                        return await loop.run_in_executor(
                            _get_light_executor(), _conn_manager.get_schema, connection_id, file_path
                        )
            except Exception:
                pass
        raise HTTPException(status_code=401, detail={"message": str(e), "error_code": "TOKEN_EXPIRED", "connection_id": connection_id})
    except HTTPException:
        raise
    except Exception as e:
        # 2026-09-15 -- "this path is not a readable file" is a 404, not a
        # server fault, and a 500 detail is erased by main.py's CWE-209
        # chokepoint.  Asking for the schema of a FOLDER (an easy mistake:
        # the browse route returns folders and files in one list) produced
        # "Internal server error. Please contact support." when the server
        # knew precisely: HeadObject returned 404.  The route already maps
        # ValueError / FileNotFoundError to 404 with the reason -- a driver's
        # own not-found says the same thing in a different dialect.
        _msg = str(e)
        _low = _msg.lower()
        if "404" in _msg or "not found" in _low or "nosuchkey" in _low:
            raise HTTPException(
                status_code=404,
                detail=(f"No readable file at {file_path!r} on this connection. "
                        f"If it is a folder, ask for the schema of a file inside "
                        f"it. Source said: {_msg}"))
        from core.error_sanitizer import explain_failure
        logger.error("Schema read failed for connection %s path %r: %s",
                     connection_id, file_path, e, exc_info=True)
        raise HTTPException(
            status_code=400,
            detail=explain_failure(
                e, subject=f"Schema read for {file_path!r}",
                config=(conn_raw or {}).get("config") or {}))


# ── Registered Tables (Enterprise S3 Table Registry) ─────────────────────────

@router.get("/api/connections/{connection_id}/tables")
async def list_registered_tables(connection_id: int, catalog: str = "", schema: str = "",
                                 _user: dict = Depends(get_current_user)):
    """List tables for a connection.

    For S3 / local: returns the explicitly-registered tables list from
    connection.config.registered_tables (admin-curated set).

    BF-CONN-LIST-TABLES: for SQL-connector connections (Trino/Starburst/
    Snowflake/Databricks/Oracle/Athena), tables aren't pre-registered —
    they live in the source catalog.  Dispatch to
    connector.list_tables(catalog, schema), defaulting to the connection's
    configured catalog/schema if not passed via query params.  Returns
    the same shape so BQB sidebar / table picker doesn't need changes.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    try:
        conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Connection lookup failed: {e}")
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")

    _conn_type = conn_raw.get("connection_type", "")
    try:
        from core.connectors import (SQL_CONNECTOR_TYPES, get_connector,
                                     DriverNotInstalled)
    except Exception:
        SQL_CONNECTOR_TYPES = set()
        get_connector = None
        DriverNotInstalled = ()   # nothing to catch; the branch below is skipped

    if _conn_type in SQL_CONNECTOR_TYPES and get_connector:
        _cfg = conn_raw.get("config") or {}
        _cat = catalog or _cfg.get("catalog", "") or ""
        _sch = schema or _cfg.get("schema", "") or ""
        # 2026-09-16 POOLED — see _list_sql_tables.  Acquisition keeps its
        # own 502 ("Connector init failed") so a bad connection still fails
        # at the right place with the right message.
        from core.connection_pool import get_pooled_connector
        try:
            _pooled = get_pooled_connector(connection_id, _conn_type, _cfg,
                                           conn_raw.get("name", ""))
            connector = _pooled.__enter__()
        except Exception as e:
            raise_if_source_error(e, _conn_type, context="Connector init failed")   # FB-41
            raise HTTPException(status_code=502, detail=f"Connector init failed: {e}")
        try:
            # detect catalog if missing — list_catalogs first
            if not _cat:
                try:
                    cats = await asyncio.to_thread(connector.list_catalogs) or []
                    _cat = cats[0] if cats else ""
                except DriverNotInstalled:
                    # Not "no catalog" -- no DRIVER.  Swallowing it here
                    # let the next call fail as a 502 "list_tables failed".
                    raise
                except Exception as _cat_exc:
                    # 2026-10-08 -- a source that REFUSED (a wrong password,
                    # an untrusted certificate, a start-up) is not "no
                    # catalog": browsing on with catalog "" turned the
                    # cluster's verdict into "mismatched input" at the next
                    # call.  The seam answers it; only a genuine "could not
                    # tell" falls through to the empty catalog.
                    raise_if_source_error(_cat_exc, _conn_type,
                                          context="Connector list_catalogs failed")
                    _cat = ""
            # If schema also missing, return one-level deeper schema enumeration
            # so the frontend can offer a schema picker.  Otherwise list tables.
            if _cat and not _sch:
                schemas = await asyncio.to_thread(connector.list_schemas, _cat) or []
                # Frontend expects "tables" key; emit synthetic schema entries
                # that look like tables — not ideal, but BQB only renders the
                # name field.  Better: separate /catalogs and /schemas endpoints,
                # but those aren't wired into the frontend yet.
                tbls = [
                    {"name": f"{_cat}.{s}",
                     "format": "sql_connector",
                     "_is_schema": True,
                     "catalog": _cat, "schema": s}
                    for s in schemas
                ]
                return {"tables": tbls, "_source": _conn_type,
                        "catalog": _cat, "schema": ""}
            tables_raw = await asyncio.to_thread(
                connector.list_tables, _cat, _sch) or []
        except DriverNotInstalled as e:
            # Same missing driver as ``POST .../test`` reports; the same
            # honest answer instead of a 502 the chokepoint erases.
            logger.warning("list_tables refused for %s: %s", _conn_type, e)
            raise _driver_not_installed_501(e, _conn_type)
        except Exception as e:
            raise_if_source_error(e, _conn_type, context="Connector list_tables failed")  # FB-41
            logger.warning("list_tables failed for %s/%s.%s: %s",
                           _conn_type, _cat, _sch, e)
            try:
                connector.close()
            except Exception:
                pass
            raise HTTPException(
                status_code=502,
                detail=f"Connector list_tables failed: {e}",
            )
        finally:
            # Hand the LIVE exception state to __exit__: releasing a
            # connector whose list_tables just failed would put a possibly
            # broken session back for the next caller.  sys.exc_info() is
            # the only way to know that from a finally block.
            try:
                import sys as _sys
                _pooled.__exit__(*_sys.exc_info())
            except Exception:
                pass
        # Normalize to the same shape S3 returns: {name, format, ...}
        tables_out = []
        for t in tables_raw:
            _tn = t.get("name", "")
            if not _tn:
                continue
            # Qualified name: catalog.schema.table — so BQB / partition lookups
            # have enough to round-trip without storing connection-default state.
            _qualified = ".".join([p for p in (_cat, _sch, _tn) if p])
            tables_out.append({
                "name":    _qualified,
                "format":  "sql_connector",
                "type":    t.get("type", "TABLE"),
                "catalog": _cat,
                "schema":  _sch,
            })
        return {"tables": tables_out, "_source": _conn_type,
                "catalog": _cat, "schema": _sch}

    # Default: S3 / local registered-tables path
    try:
        tables = await _adb(_conn_manager.get_registered_tables, connection_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    # 2026-09-27 — an Iceberg table's WATCHED state, so the admin can see
    # that registering it made it observed (and what the watcher last
    # saw).  ``watch.watched`` is true / false / null-with-error: "not
    # watched" and "could not read the registry" are opposite findings.
    try:
        from core.iceberg_watch_registry import watched_state
        _bucket = (conn_raw.get("config") or {}).get("bucket_name") or ""
        decorated = []
        for t in tables:
            t2 = dict(t)
            if (str(t2.get("format") or "").lower() == "iceberg"
                    and _bucket and t2.get("s3_prefix")):
                t2["watch"] = await _adb(watched_state, _db_manager,
                                         connection_id, _bucket, t2["s3_prefix"])
            decorated.append(t2)
        tables = decorated
    except Exception as _ws_exc:
        logger.debug("watched-state decoration skipped for connection %s: %s",
                     connection_id, _ws_exc)
    return {"tables": tables}


@router.post("/api/connections/{connection_id}/tables")
async def register_table_endpoint(connection_id: int, table: RegisteredTableModel,
                                  _user: dict = Depends(require_admin)):
    """Register a named table pointing to an S3 prefix.

    For iceberg format: validates that the prefix has a metadata/ subfolder
    with valid Iceberg metadata files before accepting.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    # BF-NONBLOCK-AUDIT-3: get_connection_raw is a sync DB read +
    # decryption.  Wrap so concurrent /health probes aren't starved.
    conn_raw = await asyncio.wait_for(
        asyncio.to_thread(_db_manager.get_connection_raw, connection_id),
        timeout=10.0,
    )
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")

    # Validate Iceberg prefix before registering
    if table.format == "iceberg":
        try:
            from core.iceberg_reader import is_iceberg_table
            # BF-NONBLOCK-AUDIT-3: _make_s3_client_for_conn does boto3 +
            # potentially STS AssumeRole (unbounded on slow STS).
            # is_iceberg_table does sync s3.list_objects_v2.  Wrap both
            # in a single to_thread with a hard 15s budget.
            def _validate_iceberg() -> bool:
                _s3 = _make_s3_client_for_conn(conn_raw)
                _bucket = conn_raw["config"]["bucket_name"]
                # raise_on_access_error=True: this is a register-style
                # caller (one hand-picked folder).  IAM / network errors
                # should surface as actionable, not "not iceberg".
                return is_iceberg_table(_s3, _bucket, table.s3_prefix,
                                          raise_on_access_error=True)
            ok = await asyncio.wait_for(asyncio.to_thread(_validate_iceberg),
                                          timeout=15.0)
            if not ok:
                raise HTTPException(
                    status_code=400,
                    detail=f"'{table.s3_prefix}' is not a valid Iceberg table. "
                           f"No metadata/ folder with *.metadata.json found. "
                           f"Make sure you register at the table root level "
                           f"(the folder that contains both data/ and metadata/ subfolders)."
                )
        except HTTPException:
            raise
        except Exception as e:
            # 2026-06-16 — pre-fix this branch only logged at warning
            # level and silently fell through to the register path, so
            # the operator either saw "not a valid Iceberg table" (when
            # is_iceberg_table returned False) OR the register succeeded
            # with a broken connection and failed later.  is_iceberg_table
            # now RAISES on IAM/network errors; surface the real cause to
            # the operator instead of mislabeling it as "not iceberg".
            _msg = str(e).lower()
            _code = ""
            try:
                _code = e.response.get("Error", {}).get("Code", "")
            except Exception:
                pass
            if (_code in {"AccessDenied", "Forbidden", "403"}
                    or "accessdenied" in _msg):
                logger.error(
                    "Iceberg validation blocked by AccessDenied for %s: %s",
                    table.s3_prefix, e,
                )
                raise HTTPException(
                    status_code=403,
                    detail=(
                        f"Cannot validate Iceberg table at '{table.s3_prefix}' "
                        f"because S3 returned AccessDenied while listing the "
                        f"metadata/ folder.  This is NOT a 'not-iceberg' "
                        f"result — your IAM policy is missing s3:ListBucket "
                        f"on this bucket/prefix.  Grant s3:ListBucket and "
                        f"retry."
                    ),
                )
            if ("could not connect to the endpoint" in _msg
                    or "name or service not known" in _msg
                    or "name resolution" in _msg):
                logger.error(
                    "Iceberg validation blocked by network failure for %s: %s",
                    table.s3_prefix, e,
                )
                raise HTTPException(
                    status_code=502,
                    detail=(
                        f"Cannot validate Iceberg table at '{table.s3_prefix}' "
                        f"because S3 endpoint was unreachable.  Run Admin "
                        f"→ VPC + S3 Check on this connection to see "
                        f"which network layer is failing.  Original error: "
                        f"{str(e)[:200]}"
                    ),
                )
            logger.warning("Iceberg validation failed for %s: %s",
                            table.s3_prefix, e)

    try:
        # BF-NONBLOCK-AUDIT-3: register_table writes to DB + invalidates caches.
        result = await asyncio.wait_for(
            asyncio.to_thread(_conn_manager.register_table,
                              connection_id, table.model_dump()),
            timeout=10.0,
        )

        # Background-cache schema so subsequent loads are instant
        async def _bg_cache_schema():
            try:
                await get_registered_table_schema(connection_id, table.name, refresh=True, _user=_user)
                logger.info("Background schema cache done for %s:%s", connection_id, table.name)
            except Exception as exc:
                logger.warning("Background schema cache failed for %s:%s: %s", connection_id, table.name, exc)
                # 2026-08-22 — REGISTRATION is a promise to know this
                # table's columns.  When the post-register fetch fails,
                # record the failure + reason in the local column catalog
                # so the UI shows WHY instead of a silent empty list.
                try:
                    from core.schema_catalog import ColumnCatalog
                    await asyncio.to_thread(
                        ColumnCatalog(_db_manager).record_failure,
                        connection_id, table.name, str(exc))
                except Exception as rec_exc:
                    logger.warning("Could not record catalog failure for "
                                   "%s:%s: %s", connection_id, table.name, rec_exc)
        # BF-594: strong-ref track (Python issue #88831).
        from core.bg_tasks import track_bg_task as _track_bg_task_conn
        _track_bg_task_conn(_bg_cache_schema())

        # 2026-06-16 — newly-registered table needs partition discovery too.
        # ConnectionBrain skips tables that already have partition_columns,
        # so this is safe to call even when the user provided them up-front.
        _schedule_partition_discovery(connection_id)

        # 2026-09-27 — a registered Iceberg table is a WATCHED one.
        await _sync_watches(connection_id, before=conn_raw)

        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


_REREAD = object()   # "read the connection again after the write"


async def _sync_watches(connection_id: int, *, before: Optional[dict],
                        after: Any = _REREAD) -> dict:
    """Keep watched_iceberg_tables in step with this connection's registered
    Iceberg tables (core/iceberg_watch_registry.py).  ``after`` defaults to
    a fresh read of the connection; pass ``None`` on delete.  Fail-open: a
    registry write must never fail the save that triggered it."""
    try:
        from core.iceberg_watch_registry import sync_watches_for_connection
        if after is _REREAD:
            after = await _adb(_db_manager.get_connection_raw, connection_id)
        return await _adb(sync_watches_for_connection, _db_manager,
                          connection_id, before=before, after=after)
    except Exception as exc:
        logger.warning("[watch_registry] sync for connection %s skipped "
                       "(non-fatal): %s", connection_id, exc)
        return {"watched": [], "unwatched": [], "skipped": str(exc)}


@router.patch("/api/connections/{connection_id}/tables/{table_name}/partition-columns",
              dependencies=[Depends(require_admin)])
async def update_table_partition_columns(
    connection_id: int, table_name: str, body: PartitionColumnsModel,
    _user: dict = Depends(get_current_user),
):
    """Set partition_columns for a registered table.

    Replaces the existing list.  Provide empty list to clear.
    These columns are used for S3 file pruning when the SQL WHERE clause
    contains matching filters.  Auto-detected columns are saved here too.
    """
    try:
        result = await _adb(_conn_manager.update_registered_table_partition_columns,
            connection_id, table_name, body.partition_columns
        )
        # 2026-07-31 -- invalidate the in-process partition-column resolution
        # cache so THIS edit takes effect on the next query instead of after
        # the TTL.  The resolver consults its cache BEFORE Tier 1 (the admin
        # override this endpoint writes), so without this an admin correcting
        # harmful auto-detected columns waited for the TTL to lapse -- and
        # that TTL was just raised 300s -> 3600s, turning a 5-minute wait into
        # an hour.  Fail-open: a cache-invalidation failure must never fail
        # the write that already succeeded.
        try:
            from core.iceberg_partition_resolver import invalidate_cache
            invalidate_cache(connection_id, table_name)
        except Exception as _inv_exc:
            logger.warning(
                "partition_columns saved for %s/%s but resolver cache "
                "invalidation failed (%s) — the new columns may take up to "
                "the resolver TTL to apply on this pod",
                connection_id, table_name, _inv_exc,
            )
        audit_event(_db_manager, _user, None, "update_partition_columns", "table",
                    f"{connection_id}/{table_name}")
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.delete("/api/connections/{connection_id}/tables/{table_name}")
async def unregister_table_endpoint(connection_id: int, table_name: str,
                                     _user: dict = Depends(require_admin)):
    """Remove a registered table and its cached schema."""
    try:
        # The watch bookkeeping is best-effort: failing to read the
        # before-state must never fail the unregister it rides on.
        try:
            _before = await _adb(_db_manager.get_connection_raw, connection_id)
        except Exception as _bf_exc:
            logger.warning("[watch_registry] before-state unreadable for "
                           "connection %s (non-fatal): %s", connection_id, _bf_exc)
            _before = None
        await _adb(_conn_manager.unregister_table, connection_id, table_name)
        # 2026-09-27 — unregistering removes the watch.
        await _sync_watches(connection_id, before=_before)
        # Clean up schema cache + the local column catalog row
        await _adb(_db_manager.delete_schema_cache, connection_id, table_name)
        try:
            from core.schema_catalog import ColumnCatalog
            await _adb(ColumnCatalog(_db_manager).delete_entry,
                       connection_id, table_name)
        except Exception as cat_exc:
            logger.warning("Could not delete catalog columns for %s:%s: %s",
                           connection_id, table_name, cat_exc)
        _schema_ck = f"schema:{connection_id}:{table_name}"
        _schema_cache.delete(_schema_ck)
        audit_event(_db_manager, _user, None, "unregister_table", "table",
                    f"{connection_id}/{table_name}")
        return {"message": f"Table '{table_name}' removed"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/api/connections/{connection_id}/tables/{table_name}/schema")
async def get_registered_table_schema(connection_id: int, table_name: str,
                                       refresh: bool = False,
                                       _user: dict = Depends(get_current_user)):
    """Get schema for a registered table.

    Cache hierarchy: L1 in-memory (10 min) → L2 SQLite DB (persistent) → L3 S3.
    Pass ?refresh=true to force re-read from S3 and update both caches.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")

    bucket = config["bucket_name"]
    fmt = table_def["format"]
    prefix = table_def["s3_prefix"].rstrip("/")

    _schema_ck = f"schema:{connection_id}:{table_name}"

    async def _iceberg_stale(payload) -> bool:
        """2026-10-06 -- a cached ICEBERG schema is served only while it is
        still the table's current schema (an ALTER TABLE changes the schema
        id); a stale copy falls through to the live read below."""
        if fmt != "iceberg":
            return False
        from core.schema_reader import iceberg_schema_staleness
        try:
            reason = await asyncio.get_running_loop().run_in_executor(
                _get_light_executor(),
                lambda: iceberg_schema_staleness(
                    payload, _make_s3_client_for_conn(conn_raw), bucket, prefix))
        except Exception as exc:  # noqa: BLE001 -- unknown is not stale
            logger.debug("Iceberg schema currency check failed for %s: %s", _schema_ck, exc)
            return False
        if reason:
            logger.info("Schema cache for %s is stale (%s) -- reading the current "
                        "schema", _schema_ck, reason)
            _schema_cache.delete(_schema_ck)
            return True
        return False

    if not refresh:
        # ── L1 cache check — instant for repeated clicks ─────────────
        cached = _schema_cache_get(_schema_ck)
        if cached and not await _iceberg_stale(cached):
            logger.debug("Schema L1 hit for %s", _schema_ck)
            return {**cached, "cache": "L1"}

        # ── L2 cache check — SQLite DB (persistent, survives restarts) ──
        db_cached = await _adb(_db_manager.get_schema_cache, connection_id, table_name)
        if db_cached and not await _iceberg_stale(db_cached.get("schema_data")):
            result = db_cached["schema_data"]
            _schema_cache_set(_schema_ck, result)  # promote to L1
            logger.info("Schema L2 hit for %s (cached %s)", _schema_ck, db_cached.get("updated_at", "?"))
            return {**result, "cache": "L2", "cached_at": db_cached.get("updated_at")}

    def _do():
        try:
            return _fetch_schema_from_s3(connection_id, conn_raw, config, table_def, table_name, bucket, fmt, prefix)
        except BaseException as exc:
            logger.critical("CRASH in schema _do() for '%s': %s", table_name, exc, exc_info=True)
            raise

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        # Store in L1 + the LOCAL COLUMN CATALOG (which also writes the
        # legacy schema_cache L2 row — one chokepoint, both stores).
        _schema_cache_set(_schema_ck, result)
        await _record_catalog_columns(connection_id, table_name, fmt, result,
                                      source="schema_read")
        logger.info("Schema cached for %s:%s (L1 + catalog/L2)", connection_id, table_name)
        return {**result, "cache": "none"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error getting registered table schema: %s", e, exc_info=True)
        # 2026-08-22 — operator-reported: a source hiccup must not become
        # "could not read any columns".  Serve the locally saved columns
        # (marked stale, with the failure reason) instead of a 500; the
        # failure + reason are recorded in the catalog either way.
        fallback = await _serve_catalog_fallback(connection_id, table_name, str(e))
        if fallback is not None:
            return fallback
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/tables/{table_name}/schema/refresh")
async def refresh_table_schema(connection_id: int, table_name: str,
                                _user: dict = Depends(get_current_user)):
    """Force-refresh schema from S3 and update cache."""
    return await get_registered_table_schema(connection_id, table_name, refresh=True, _user=_user)


@router.post("/api/connections/{connection_id}/schema/refresh-all")
async def refresh_all_table_schemas(connection_id: int,
                                     _user: dict = Depends(get_current_user)):
    """Refresh schemas for ALL registered tables in a connection."""
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    if not tables:
        return {"message": "No registered tables", "refreshed": 0}

    loop = asyncio.get_running_loop()
    results = []
    errors = []

    for tbl in tables:
        table_name = tbl["name"]
        fmt = tbl["format"]
        prefix = tbl["s3_prefix"].rstrip("/")
        bucket = config["bucket_name"]
        try:
            result = await loop.run_in_executor(
                _get_light_executor(),
                lambda t=tbl: _fetch_schema_from_s3(
                    connection_id, conn_raw, config, t, t["name"], bucket, t["format"], t["s3_prefix"].rstrip("/")
                ),
            )
            _schema_ck = f"schema:{connection_id}:{table_name}"
            _schema_cache_set(_schema_ck, result)
            await _record_catalog_columns(connection_id, table_name, fmt, result,
                                          source="refresh")
            results.append(table_name)
        except Exception as e:
            logger.warning("Schema refresh failed for %s: %s", table_name, e)
            errors.append({"table": table_name, "error": str(e)})
            # Record the failure + reason in the column catalog so
            # source:"none" responses can say WHY, not just be empty.
            try:
                from core.schema_catalog import ColumnCatalog
                await _adb(ColumnCatalog(_db_manager).record_failure,
                           connection_id, table_name, str(e))
            except Exception as rec_exc:
                logger.warning("Could not record catalog failure for %s:%s: %s",
                               connection_id, table_name, rec_exc)

    return {"refreshed": len(results), "tables": results, "errors": errors}


@router.get("/api/connections/{connection_id}/schema/cache")
async def list_cached_schemas(connection_id: int,
                              _user: dict = Depends(get_current_user)):
    """List all cached schemas for a connection."""
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    entries = await _adb(_db_manager.list_schema_cache_entries, connection_id)
    return {"connection_id": connection_id, "count": len(entries), "entries": entries}


@router.delete("/api/connections/{connection_id}/schema/cache")
async def clear_schema_cache(connection_id: int,
                              _user: dict = Depends(get_current_user)):
    """Clear all cached schemas for a connection."""
    count = await _adb(_db_manager.delete_schema_cache, connection_id)
    # Clear L1 too
    prefix = f"schema:{connection_id}:"
    to_remove = [k for k in _schema_cache.keys() if k.startswith(prefix)]
    for k in to_remove:
        _schema_cache.delete(k)
    audit_event(_db_manager, _user, None, "clear_schema_cache", "schema_cache", connection_id)
    return {"cleared": count + len(to_remove)}


def _extract_hive_partition_values(s3_client, bucket: str, prefix: str) -> dict:
    """Extract partition columns, values, and unique combos from hive-style S3 folders.

    Scans folder names like 'business_close_date=2025-09-30/code=SAP/' and
    extracts unique values per partition column AND unique combinations.

    Returns same shape as get_iceberg_partition_values for UI compatibility,
    including 'combos' list that enables cascading dropdown filtering in the
    frontend (selecting a parent partition value filters child partition values
    to only those that exist in combination with the parent).
    """
    prefix_clean = prefix.rstrip("/") + "/" if prefix else ""
    partition_cols: dict = {}  # col_name → set of values
    file_count = 0
    # Track unique partition combos: frozenset of (col, val) → file count
    _combo_counts: dict = {}  # tuple((col1,val1),(col2,val2),...) → file_count

    from core.s3_utilities import S3AccessDeniedError as _S3AccessDeniedError
    paginator = s3_client.get_paginator("list_objects_v2")
    try:
        pages = list(paginator.paginate(Bucket=bucket, Prefix=prefix_clean))
    except Exception as _pag_exc:
        _code = getattr(getattr(_pag_exc, 'response', {}).get('Error', {}), 'get', lambda k, d=None: d)('Code', '') \
                if hasattr(_pag_exc, 'response') else ''
        if not _code:
            try:
                _code = _pag_exc.response.get('Error', {}).get('Code', '')
            except Exception:
                _code = ''
        if _code == 'AccessDenied':
            raise _S3AccessDeniedError(
                f"Access denied to S3 prefix '{prefix_clean}' in bucket '{bucket}'",
                prefix=prefix_clean
            )
        raise
    for page in pages:
        for obj in page.get("Contents", []):
            key = obj["Key"]
            from core.s3_utilities import is_parquet_data_key as _is_data
            if not _is_data(key, prefix_clean):
                continue
            file_count += 1
            # Parse hive partition segments from the path
            # e.g. prefix/business_close_date=2025-09-30/code=SAP/file.parquet
            rel_path = key[len(prefix_clean):]
            segments = rel_path.split("/")
            _file_parts = []  # partition pairs for this file
            for seg in segments[:-1]:  # skip the filename
                if "=" in seg:
                    col, val = seg.split("=", 1)
                    if col not in partition_cols:
                        partition_cols[col] = set()
                    partition_cols[col].add(val)
                    _file_parts.append((col, val))
            # Track this combo
            if _file_parts:
                _combo_key = tuple(sorted(_file_parts))
                _combo_counts[_combo_key] = _combo_counts.get(_combo_key, 0) + 1

    if not partition_cols:
        return {"partition_columns": [], "values": {}, "file_counts": {}, "combos": []}

    # Sort values and build response — must match Iceberg shape:
    # partition_columns = [{name, source_column, type, transform}, ...]
    col_names = list(partition_cols.keys())

    def _infer_partition_type(vals: set) -> str:
        """Infer partition column type from sample values."""
        if not vals:
            return "string"
        import re as _re
        sample = list(vals)[:20]
        if all(_re.match(r'^\d{4}-\d{2}-\d{2}$', v) for v in sample):
            return "date"
        if all(_re.match(r'^-?\d+\.?\d*$', v) for v in sample):
            return "number"
        return "string"

    partition_columns = [
        {"name": col, "source_column": col,
         "type": _infer_partition_type(partition_cols[col]),
         "transform": "identity"}
        for col in col_names
    ]
    values = {col: sorted(partition_cols[col]) for col in col_names}

    # Build per-column per-value file counts from combos
    file_counts: dict = {col: {} for col in col_names}
    for combo_key, fcount in _combo_counts.items():
        combo_dict = dict(combo_key)
        for col in col_names:
            if col in combo_dict:
                val = combo_dict[col]
                file_counts[col][val] = file_counts[col].get(val, 0) + fcount

    # Build combos list for frontend cascading filter support
    # Each combo: {col1: val1, col2: val2, ..., _files: N, _records: 0}
    combos = []
    for combo_key, fcount in _combo_counts.items():
        combo = dict(combo_key)
        combo["_files"] = fcount
        combo["_records"] = 0  # record counts not available from folder listing
        combos.append(combo)

    return {
        "partition_columns": partition_columns,
        "values": values,
        "file_counts": file_counts,
        "record_counts": {},
        "combos": combos,
        "total_files": file_count,
        "fast_path": False,
    }


# ── Partition Endpoints ───────────────────────────────────────────────────────

@router.get("/api/connections/{connection_id}/tables/{table_name}/partitions")
async def get_registered_table_partitions(
    connection_id: int, table_name: str, refresh: bool = False, full_scan: bool = False,
    _user: dict = Depends(get_current_user),
):
    """Get available partition values for a registered Iceberg table.

    Two-tier cache:
      L1 in-memory (5 min) — instant response for repeated requests
      L2 SQLite (5 hours) — survives server restarts, avoids S3 re-scans
    Pass ?refresh=true to force re-scan from S3.
    Pass ?full_scan=true to read individual manifest files for exact combos.

    BF-CONN-PARTITIONS: for SQL-connector connections (Trino/Starburst/Snowflake/
    Databricks/Oracle/Athena), dispatch to the connector's detect_partitions()
    method.

    2026-08-13 -- this used to say "(no values -- the connector's catalog
    stores partition spec, not enumerated values like an S3 listing)".  That
    is STALE and it cost real debugging time: VALUES ARE ENUMERATED for SQL
    connectors below, via Trino's ``"<table>$partitions"`` metadata table
    (catalog read, no data scan) with a ``SELECT DISTINCT`` fallback, capped
    at 200 per column.

    The reason no partitions appeared in BQB was NOT this endpoint -- it was
    ``ConnectionManager._get_sql_connector_schema`` omitting the
    ``partition_columns`` key, so every column came back is_partition=False
    and the UI never called this endpoint at all.  Fixed there.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")

    # BF-CONN-PARTITIONS: SQL connector path
    _conn_type = conn_raw.get("connection_type", "")
    try:
        from core.connectors import SQL_CONNECTOR_TYPES, get_connector
    except Exception:
        SQL_CONNECTOR_TYPES = set()
        get_connector = None
    if _conn_type in SQL_CONNECTOR_TYPES and get_connector:
        # table_name format: "catalog.schema.table" (3 parts) or "schema.table"
        # (2 parts; uses connector's default catalog) or "table" (1 part; uses
        # connector's defaults for both).
        _parts = table_name.split(".")
        if len(_parts) == 3:
            _cat, _sch, _tbl = _parts
        elif len(_parts) == 2:
            _cat = (conn_raw.get("config") or {}).get("catalog", "") or ""
            _sch, _tbl = _parts
        else:
            _cfg = conn_raw.get("config") or {}
            _cat = _cfg.get("catalog", "") or ""
            _sch = _cfg.get("schema", "") or ""
            _tbl = _parts[0]

        # Reuse the same L1/L2 cache the S3 path uses so SQL connector
        # partition lookups don't hammer the source warehouse.
        _scan_type = "full" if full_scan else "fast"
        _cache_key = f"{connection_id}:{table_name}:{_conn_type}:{_scan_type}"
        if not refresh:
            cached = _partition_l1_get(_cache_key)
            if cached is not None and isinstance(cached.get("partition_columns"), list):
                logger.debug("Partition L1 hit (%s) for %s", _conn_type, _cache_key)
                return cached
            hit, cached, _ts = await asyncio.to_thread(
                _partition_l2_get, connection_id, table_name, _scan_type, "")
            if hit and isinstance((cached or {}).get("partition_columns"), list):
                logger.debug("Partition L2 hit (%s) for %s", _conn_type, _cache_key)
                _partition_l1_set(_cache_key, cached)
                return cached

        try:
            connector = get_connector(_conn_type, conn_raw.get("config", {}),
                                       connection_id, conn_raw.get("name", ""))
        except Exception as e:
            raise_if_source_error(e, _conn_type, context="Connector init failed")   # FB-41
            raise HTTPException(status_code=502, detail=f"Connector init failed: {e}")

        # detect_partitions contract from base.py:
        #   [{"name": str, "type": str, "transform": str}]
        # NOT {"column": ..} — that was my bug in the previous commit.
        parts: list = []
        try:
            parts = await asyncio.to_thread(
                connector.detect_partitions, _cat, _sch, _tbl) or []
        except Exception as e:
            logger.warning("detect_partitions failed for %s/%s.%s.%s: %s",
                           _conn_type, _cat, _sch, _tbl, e)
            try:
                connector.close()
            except Exception:
                pass
            return {"partition_columns": [], "values": {},
                    "file_counts": {},
                    "error": f"Connector partition detection failed: {e}",
                    "_source": _conn_type}

        # Pull values for each partition column so the BQB / CQB filter
        # dropdowns are populated — matching the S3 path UX.
        # Trino/Starburst Iceberg tables expose a "<schema>"."<table>$partitions"
        # metadata table that returns partition values WITHOUT scanning data
        # (catalog read only — instant).  Try that first; fall back to
        # SELECT DISTINCT on the actual table when the metadata table isn't
        # available (Snowflake clustering keys, Hive without partition
        # metadata, Oracle, etc.).
        _values_max = 200
        _qualified = ".".join([p for p in (_cat, _sch, _tbl) if p])
        _values: dict = {}
        # Build the $partitions reference (Trino/Starburst/Athena Iceberg)
        _meta_table = None
        if _conn_type in ("trino", "starburst", "athena"):
            _q_cat = f'"{_cat}".' if _cat else ""
            _q_sch = f'"{_sch}".' if _sch else ""
            _meta_table = f'{_q_cat}{_q_sch}"{_tbl}$partitions"'
        try:
            for _p in parts:
                _col_name = _p.get("name") or _p.get("column") or ""
                if not _col_name:
                    continue
                _safe_col = _col_name.replace('"', '""')
                _vrows = None
                # Fast path: metadata partition table
                if _meta_table:
                    # 2026-08-19 -- TWO shapes, because the first never worked
                    # on Iceberg.  Hive's $partitions exposes each partition
                    # key as a TOP-LEVEL column; Iceberg nests them inside a
                    # ROW named `partition`, so the top-level form always
                    # errored and every Iceberg table silently fell through to
                    # the "slow but works everywhere" DISTINCT on the DATA
                    # table -- a full scan, while the code above still
                    # described this path as a catalog read.
                    _meta_projections = [
                        f'"{_safe_col}"',                  # Hive shape
                        f'"partition"."{_safe_col}"',      # Iceberg shape
                    ]
                    for _proj in _meta_projections:
                        _meta_sql = (
                            f'SELECT DISTINCT {_proj} FROM {_meta_table} '
                            f'WHERE {_proj} IS NOT NULL '
                            f'ORDER BY {_proj} DESC LIMIT {_values_max}'
                        )
                        try:
                            _vresult = await asyncio.to_thread(
                                connector.execute_query, _meta_sql, _values_max)
                            _vrows = _vresult.get("rows", []) or []
                            break
                        except Exception as _meta_e:
                            logger.debug(
                                "Partitions-metadata fast path (%s) failed for "
                                "%s.%s: %s", _proj, _qualified, _col_name,
                                _meta_e)
                            _vrows = None
                # Fallback: DISTINCT on the data table (slow but works
                # everywhere)
                if _vrows is None:
                    _value_sql = (
                        f'SELECT DISTINCT "{_safe_col}" FROM {_qualified} '
                        f'WHERE "{_safe_col}" IS NOT NULL '
                        f'ORDER BY "{_safe_col}" DESC LIMIT {_values_max}'
                    )
                    try:
                        _vresult = await asyncio.to_thread(
                            connector.execute_query, _value_sql, _values_max)
                        _vrows = _vresult.get("rows", []) or []
                    except Exception as _ve:
                        logger.debug("Partition values fetch failed for %s.%s: %s",
                                     _qualified, _col_name, _ve)
                        _vrows = []
                _values[_col_name] = [
                    next(iter(r.values())) for r in (_vrows or []) if r
                ]
        finally:
            try:
                connector.close()
            except Exception:
                pass

        result = {
            # Same shape as S3/Iceberg path so frontend doesn't branch:
            # objects with "column" + "type" keys.
            "partition_columns": [
                {"column": p.get("name") or p.get("column", ""),
                 "type":    p.get("type", "string"),
                 "transform": p.get("transform", "identity")}
                for p in parts
            ],
            "values":      _values,
            "file_counts": {},   # connector path doesn't expose this
            "combos":      [],
            "_source":     _conn_type,
            "cached_at":   datetime.now(timezone.utc).isoformat(),
        }
        # Persist to both cache tiers
        try:
            _partition_l1_set(_cache_key, result)
            _partition_store(
                connection_id, table_name, _scan_type, _cache_key, result, "")
        except Exception as _cache_exc:
            logger.debug("Partition cache store failed for %s: %s",
                         _cache_key, _cache_exc)
        return result

    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    fmt = table_def.get("format", "parquet")
    if fmt not in ("iceberg", "parquet"):
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    bucket = config["bucket_name"]
    scan_type = "full" if full_scan else "fast"
    s3_prefix = table_def.get("s3_prefix", "")
    cache_key = f"{connection_id}:{table_name}:{s3_prefix}:{scan_type}"

    def _valid_partition_shape(data: dict) -> bool:
        """Check cached partition data has expected shape (objects, not flat strings)
        and includes combos for cascading dropdown support."""
        cols = data.get("partition_columns", [])
        if cols and not isinstance(cols[0], dict):
            return False  # old format: flat strings instead of objects
        # Reject cache entries that lack combos (needed for cascading dropdowns)
        if cols and "combos" not in data:
            return False
        return True

    if not refresh:
        # L1 check
        cached = _partition_l1_get(cache_key)
        if cached is not None and _valid_partition_shape(cached):
            logger.debug("Partition L1 hit for %s", cache_key)
            return cached
        # L2 check.  BF-NONBLOCK-AUDIT-8: SQLite read inline.
        hit, cached, _ts = await asyncio.to_thread(
            _partition_l2_get, connection_id, table_name, scan_type, s3_prefix)
        if hit and _valid_partition_shape(cached):
            logger.debug("Partition L2 hit for %s", cache_key)
            _partition_l1_set(cache_key, cached)
            return cached

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        if fmt == "iceberg":
            from core.iceberg_reader import get_iceberg_partition_values
            result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=full_scan)
        else:
            # Hive-partitioned plain parquet: extract partition columns/values from folder names
            result = _extract_hive_partition_values(s3, bucket, table_def["s3_prefix"])
        # 78F: Tag empty-prefix results so frontend shows informational alert (not blank)
        if not result.get("partition_columns") and not result.get("total_files"):
            result = {**result, "error_code": "S3_EMPTY_PREFIX"}
        _partition_store(connection_id, table_name, scan_type, cache_key, result, s3_prefix)
        return {**result, "cached_at": datetime.now(timezone.utc).isoformat()}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except HTTPException:
        raise
    except Exception as e:
        from core.s3_utilities import S3AccessDeniedError as _S3ADE
        if isinstance(e, _S3ADE):
            raise HTTPException(status_code=403, detail={
                "detail": f"Access denied to S3 prefix. Check IAM permissions. {e}",
                "error_code": "S3_ACCESS_DENIED",
                "prefix": getattr(e, 'prefix', ''),
            })
        # KMS / transient S3 error: return last-good cached value rather than 500-erroring.
        # Phase 118-B introduced TTL=300s on the partition cache — before that the dict lived
        # forever and KMS errors were hidden. Now we fall back to L2 (DB) if available.
        _is_kms = "kms:Decrypt" in str(e) or "KMS" in str(e)
        if not refresh:
            hit, stale, _ts = await asyncio.to_thread(
                _partition_l2_get, connection_id, table_name, scan_type, s3_prefix)
            if hit and stale:
                _warn = "KMS decrypt error — returning cached partition values" if _is_kms else f"S3 error: {e}"
                logger.warning("get_partition_values fallback for %s: %s", table_name, _warn)
                stale["_stale"] = True
                stale["_stale_reason"] = "kms_decrypt_error" if _is_kms else "s3_error"
                return stale
        logger.error("Error getting partition values for %s: %s", table_name, e)
        # 2026-06-16 — when the failure is a network/DNS/proxy issue
        # (EndpointConnectionError + friends), attach the same [DIAG]
        # block we surface on connection-test failures so the operator
        # can triage without re-running the test from the connection
        # editor.
        #
        # IMPORTANT: FastAPI wraps HTTPException(detail=X) as
        # {"detail": X} on the wire.  If X is a dict, the body becomes
        # {"detail": {"detail": "...", "diagnostic": "..."}} — double-
        # nested.  The frontend _parseError checks e.detail.message
        # FIRST when e.detail is an object, so use 'message' as the
        # human-readable key (not 'detail').  Pre-fix the parser fell
        # through to JSON.stringify(e.detail) which dumped the entire
        # dict as the user-facing string.
        _detail: Any = str(e)
        try:
            from core.s3_storage import _diagnose_endpoint_failure
            _cfg_for_diag = (conn_raw or {}).get("config", {}) or {}
            _diag = _diagnose_endpoint_failure(
                e,
                bucket=(_cfg_for_diag.get("bucket_name")
                        or _cfg_for_diag.get("bucket")
                        or _cfg_for_diag.get("s3_bucket") or ""),
                configured_endpoint=_cfg_for_diag.get("endpoint_url") or "",
                # region-display: the DIAGNOSTIC must show what the operator
                # actually CONFIGURED, not what resolution would pick. Resolving
                # here would hide a missing region from the one screen whose job
                # is to reveal it.
                configured_region=_cfg_for_diag.get("region_name") or "us-east-1",
                path_style=bool(_cfg_for_diag.get("path_style")),
            )
            _detail = {"message": str(e), "diagnostic": _diag,
                       "error_code": "S3_ENDPOINT_UNREACHABLE",
                       "connection_id": connection_id}
        except Exception as _diag_exc:
            logger.debug("partition diagnostic build skipped: %s", _diag_exc)
        raise HTTPException(status_code=500, detail=_detail)


@router.post("/api/connections/{connection_id}/tables/{table_name}/partitions/refresh")
async def refresh_partition_cache(connection_id: int, table_name: str, _user: dict = Depends(get_current_user)):
    """Force re-scan partition metadata from S3 and update both caches.

    Runs a full_scan to get exact partition combos.
    """
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    # BF-149: Only connection owner or admin can trigger expensive S3 refresh
    if not is_admin_like(_user):
        _conn_owner = (conn_raw.get("created_by") or "").lower()
        if _conn_owner and _conn_owner != (_user.get("username") or "").lower():
            raise HTTPException(status_code=403, detail="Not authorized to refresh this connection's partitions")
    config = conn_raw["config"]
    tables = config.get("registered_tables", [])
    table_def = next((t for t in tables if t["name"] == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not registered")
    fmt = table_def.get("format", "parquet")
    if fmt not in ("iceberg", "parquet"):
        return {"partition_columns": [], "values": {}, "file_counts": {}, "combos": []}

    bucket = config["bucket_name"]

    s3_prefix = table_def.get("s3_prefix", "")

    # 78J: Prevent concurrent refresh race for the same table
    _refresh_key = f"{connection_id}:{table_name}"
    _lock = _get_partition_refresh_lock(_refresh_key)
    try:
        from core.config import s3_validation as _sv78j
        _mutex_timeout = _sv78j.partition_refresh_mutex_timeout_seconds
    except Exception:
        _mutex_timeout = 30
    try:
        await asyncio.wait_for(_lock.acquire(), timeout=_mutex_timeout)
    except asyncio.TimeoutError:
        raise HTTPException(status_code=409, detail={
            "detail": "Partition refresh already in progress for this table. Try again shortly.",
            "error_code": "REFRESH_IN_PROGRESS",
        })

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        if fmt == "iceberg":
            from core.iceberg_reader import get_iceberg_partition_values
            result = get_iceberg_partition_values(s3, bucket, table_def["s3_prefix"], full_scan=True)
        else:
            # Hive-partitioned plain parquet: extract from S3 folder structure
            result = _extract_hive_partition_values(s3, bucket, table_def["s3_prefix"])
        # Store both fast + full in caches (full result is a superset)
        now_iso = datetime.now(timezone.utc).isoformat()
        for stype in ("fast", "full"):
            ck = f"{connection_id}:{table_name}:{s3_prefix}:{stype}"
            _partition_store(connection_id, table_name, stype, ck, result, s3_prefix)
        return {**result, "cached_at": now_iso}

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except HTTPException:
        raise
    except Exception as e:
        from core.s3_utilities import S3AccessDeniedError as _S3ADE
        if isinstance(e, _S3ADE):
            raise HTTPException(status_code=403, detail={
                "detail": f"Access denied to S3 prefix. Check IAM permissions. {e}",
                "error_code": "S3_ACCESS_DENIED",
                "prefix": getattr(e, 'prefix', ''),
            })
        logger.error("Error refreshing partition cache for %s: %s", table_name, e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        try:
            _lock.release()
        except RuntimeError:
            pass  # Lock was never acquired (e.g., timeout path)


@router.post("/api/partitions/refresh-all")
async def refresh_all_partition_caches(connection_id: int = None, _user: dict = Depends(require_admin)):
    """Refresh partition caches for ALL registered Iceberg tables (or one connection).

    Scans S3 manifests and stores results in L1 + L2 caches.
    Pass ?connection_id=N to refresh only tables in that connection.
    """
    def _do():
        from core.scheduler import _do_refresh_all_partitions
        return _do_refresh_all_partitions(connection_id=connection_id)

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_get_light_executor(), _do)
        return result
    except Exception as e:
        logger.error("Error refreshing all partition caches: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/api/connections/{connection_id}/tables/{table_name}/iceberg-cache/refresh")
async def refresh_iceberg_file_cache(connection_id: int, table_name: str, _user: dict = Depends(get_current_user)):
    """Clear the Iceberg file cache (L1 + L2) for a specific table.

    After clearing, the next query will re-scan S3 manifests to discover
    active data files.  Combine with /partitions/refresh to refresh everything.
    """
    from core.iceberg_cache import ICE_FILE_CACHE as _ICE_FILE_CACHE
    # Clear L1 entries matching this connection+table
    cleared_l1 = 0
    for k in list(_ICE_FILE_CACHE.keys()):
        cid, tname, _ = k
        if cid == connection_id and tname == table_name:
            _ICE_FILE_CACHE.pop(k, None)
            cleared_l1 += 1
    # Clear L2
    cleared_l2 = await _adb(_db_manager.delete_iceberg_file_cache, 
        connection_id=connection_id, table_name=table_name)
    return {
        "table_name": table_name, "connection_id": connection_id,
        "l1_cleared": cleared_l1, "l2_cleared": cleared_l2,
    }


# ── Discovery and Browse Endpoints ───────────────────────────────────────────

@router.get("/api/connections/{connection_id}/discover-tables")
async def discover_tables(connection_id: int, prefix: str = "", max_depth: int = 4,
                          _user: dict = Depends(get_current_user)):
    """Discover tables by scanning S3 — prioritizes Iceberg metadata.

    Strategy:
      1. If iceberg_warehouse_path is set, scan that path for Iceberg tables first.
      2. Then scan from root_prefix (or given prefix) recursively up to max_depth.
      3. For Iceberg tables, read metadata to get row count + file count.
      4. For parquet/csv folders, report format detection.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support table discovery")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    iceberg_warehouse = (config.get("iceberg_warehouse_path") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )
    existing_names = {t["name"] for t in config.get("registered_tables", [])}

    def _do():
        from core.iceberg_reader import is_iceberg_table
        s3 = _make_s3_client_for_conn(conn_raw)

        candidates = []
        seen_prefixes = set()  # avoid duplicates between iceberg scan and general scan

        def _build_table_name(folder_prefix: str) -> str:
            """Build a qualified table name from the S3 prefix path.

            Strips root_prefix and iceberg_warehouse_path, then joins
            remaining path segments with dots.
            E.g. root='', warehouse='', prefix='catalog/schema1/'
              -> 'catalog.schema1'
            E.g. root='data/', warehouse='data/catalog/', prefix='data/catalog/schema1/'
              -> 'schema1'
            """
            path = folder_prefix.rstrip("/")
            # Strip root prefix
            if root_prefix and path.startswith(root_prefix):
                path = path[len(root_prefix):].lstrip("/")
            # Strip iceberg warehouse prefix
            if iceberg_warehouse and path.startswith(iceberg_warehouse):
                path = path[len(iceberg_warehouse):].lstrip("/")
            parts = [p for p in path.split("/") if p]
            if len(parts) <= 1:
                return parts[0] if parts else folder_prefix.rstrip("/").split("/")[-1]
            # Use dot-separated qualified name (e.g. catalog.schema)
            return ".".join(parts)

        def _add_iceberg_candidate(folder_prefix: str):
            """Add an Iceberg table candidate with metadata enrichment."""
            if folder_prefix in seen_prefixes:
                return
            name = _build_table_name(folder_prefix)
            if name in existing_names:
                return
            seen_prefixes.add(folder_prefix)

            desc = ""
            partition_columns: list[str] = []
            try:
                from core.iceberg_reader import (
                    get_iceberg_data_files, _latest_metadata_key,
                    _read_s3_json, _extract_partition_spec,
                )
                # Phase H — thread db_manager so brain L2 short-circuit
                # engages on file-browse listings when fresh.
                data_files = get_iceberg_data_files(
                    s3, bucket, folder_prefix, db_manager=_db_manager,
                )
                # Read format version from metadata
                meta_prefix = folder_prefix.rstrip("/") + "/metadata/"
                meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
                metadata = _read_s3_json(s3, bucket, meta_key)
                fmt_ver = metadata.get("format-version", 1)
                desc = f"{len(data_files)} files · v{fmt_ver}"
                # Phase 134-Q — surface the partition spec so the frontend
                # can register the table with partition_columns pre-filled.
                try:
                    spec = _extract_partition_spec(metadata) or {}
                    partition_columns = sorted(spec.keys())
                except Exception:
                    partition_columns = []
            except Exception as e:
                logger.error("Iceberg metadata enrichment failed for %s: %s", folder_prefix, e, exc_info=True)
                desc = f"Iceberg table (metadata read failed: {str(e)[:60]})"

            candidates.append({
                "name": name,
                "s3_prefix": folder_prefix,
                "format": "iceberg",
                "description": desc,
                "partition_columns": partition_columns,
            })

        # ── Phase 1: Scan iceberg_warehouse_path for Iceberg tables ────────
        if iceberg_warehouse:
            wh_prefix = f"{iceberg_warehouse}/"
            logger.info("Discover: scanning Iceberg warehouse at %s", wh_prefix)

            def _scan_iceberg_warehouse(scan_prefix: str, depth: int):
                if depth > max_depth or len(candidates) >= _DISCOVER_MAX_CANDIDATES:
                    return
                paginator = s3.get_paginator("list_objects_v2")
                for page in paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/"):
                    for cp in page.get("CommonPrefixes", []):
                        if len(candidates) >= _DISCOVER_MAX_CANDIDATES:
                            return
                        fp = cp["Prefix"]
                        name = fp.rstrip("/").split("/")[-1]
                        if name.startswith(".") or name.startswith("_") or name == "metadata":
                            continue
                        if is_iceberg_table(s3, bucket, fp):
                            _add_iceberg_candidate(fp)
                        else:
                            # Might be a database/schema level — recurse
                            _scan_iceberg_warehouse(fp, depth + 1)

            _scan_iceberg_warehouse(wh_prefix, 1)

        # ── Phase 2: General scan from root_prefix ─────────────────────────
        def _scan_level(scan_prefix: str, depth: int):
            if depth > max_depth or len(candidates) >= _DISCOVER_MAX_CANDIDATES:
                return
            if scan_prefix in seen_prefixes:
                return

            paginator = s3.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=bucket, Prefix=scan_prefix, Delimiter="/")

            for page in pages:
                for cp in page.get("CommonPrefixes", []):
                    if len(candidates) >= _DISCOVER_MAX_CANDIDATES:
                        return
                    folder_prefix = cp["Prefix"]
                    name = folder_prefix.rstrip("/").split("/")[-1]

                    # Skip hidden/internal folders, but NOT "data" — it's a common
                    # top-level folder name.  "metadata" is only Iceberg internals.
                    if name.startswith(".") or name.startswith("_") or name == "metadata":
                        continue
                    if folder_prefix in seen_prefixes:
                        continue

                    # Skip date-partition folders (e.g. dt=2024-01-01, year=2024)
                    if "=" in name:
                        continue

                    if is_iceberg_table(s3, bucket, folder_prefix):
                        _add_iceberg_candidate(folder_prefix)
                        continue

                    # Check for DIRECT data files at this level only (use Delimiter)
                    try:
                        peek = s3.list_objects_v2(
                            Bucket=bucket, Prefix=folder_prefix, Delimiter="/", MaxKeys=50
                        )
                    except Exception as peek_err:
                        logger.warning("Discover: failed to peek %s: %s", folder_prefix, peek_err)
                        continue

                    has_subfolders = len(peek.get("CommonPrefixes", [])) > 0
                    fmt = "unknown"
                    for obj in peek.get("Contents", []):
                        key = obj["Key"].lower()
                        if key.endswith(".parquet"):
                            fmt = "parquet"
                            break
                        if key.endswith(".csv"):
                            fmt = "csv"
                            break

                    # Phase 134-Q — peek child folders for hive-style
                    # ``key=value`` names.  When the immediate children
                    # are all (or mostly) hive partitions, this folder
                    # IS the table root — register it with the detected
                    # partition columns instead of recursing into the
                    # partition value folders.  Pre-fix the scanner
                    # skipped ``=``-named folders entirely (correct) but
                    # never recognised the parent as the table (wrong).
                    hive_subfolders = [
                        sp for sp in peek.get("CommonPrefixes", [])
                        if "=" in sp["Prefix"].rstrip("/").split("/")[-1]
                    ]
                    child_count = len(peek.get("CommonPrefixes", []))
                    is_hive_root = (
                        has_subfolders
                        and fmt == "unknown"
                        and child_count > 0
                        and len(hive_subfolders) >= max(2, int(child_count * 0.5))
                    )

                    if is_hive_root:
                        qual_name = _build_table_name(folder_prefix)
                        if qual_name in existing_names:
                            continue
                        seen_prefixes.add(folder_prefix)
                        part_cols = sorted(set(
                            sp["Prefix"].rstrip("/").split("/")[-1].split("=", 1)[0]
                            for sp in hive_subfolders
                        ))
                        candidates.append({
                            "name": qual_name,
                            "s3_prefix": folder_prefix,
                            "format": "parquet",  # hive-style is parquet
                            "description": (
                                f"Hive-partitioned parquet at {folder_prefix} "
                                f"(partition keys: {', '.join(part_cols)})"
                            ),
                            "partition_columns": part_cols,
                        })
                    elif has_subfolders and fmt == "unknown":
                        # Has subfolders but no direct data files → container, recurse
                        _scan_level(folder_prefix, depth + 1)
                    elif fmt != "unknown" and not has_subfolders:
                        # Leaf folder with data files → register as table
                        qual_name = _build_table_name(folder_prefix)
                        if qual_name in existing_names:
                            continue
                        seen_prefixes.add(folder_prefix)
                        candidates.append({
                            "name": qual_name,
                            "s3_prefix": folder_prefix,
                            "format": fmt,
                            "description": f"{fmt.title()} files at {folder_prefix}",
                            "partition_columns": [],  # leaf folder, no partitions
                        })
                    elif has_subfolders:
                        # Has both subfolders and data files → recurse deeper
                        # (the data files might be in a partition structure)
                        _scan_level(folder_prefix, depth + 1)
                    else:
                        # No data, no subfolders → skip
                        pass

        _scan_level(effective_prefix, 1)
        # Truncation is a real answer: if we filled the cap the scan may
        # have stopped early, so tell the UI instead of dropping the verdict.
        return {
            "candidates": candidates,
            "prefix": effective_prefix,
            "truncated": len(candidates) >= _DISCOVER_MAX_CANDIDATES,
            "limit": _DISCOVER_MAX_CANDIDATES,
        }

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error discovering tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}/browse-folders")
async def browse_s3_folders(connection_id: int, prefix: str = "",
                            _user: dict = Depends(get_current_user)):
    """Browse S3 folders one level at a time. Returns subfolders and file counts.

    Used by the frontend to let users visually pick an S3 prefix for table registration.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="Only S3 connections support folder browsing")

    config = conn_raw["config"]
    bucket = config["bucket_name"]
    root_prefix = (config.get("root_prefix") or "").strip().strip("/")
    effective_prefix = f"{root_prefix}/{prefix}" if root_prefix and prefix else (
        f"{root_prefix}/" if root_prefix else prefix
    )

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        paginator = s3.get_paginator("list_objects_v2")
        pages = paginator.paginate(
            Bucket=bucket, Prefix=effective_prefix, Delimiter="/"
        )

        folders = []
        file_summary = {"parquet": 0, "csv": 0, "other": 0}

        for page in pages:
            for cp in page.get("CommonPrefixes", []):
                fp = cp["Prefix"]
                name = fp.rstrip("/").split("/")[-1]
                if not name.startswith("."):
                    # Strip root_prefix for display
                    display_path = fp
                    if root_prefix and display_path.startswith(root_prefix):
                        display_path = display_path[len(root_prefix):].lstrip("/")
                    folders.append({"name": name, "prefix": fp, "display_path": display_path})

            for obj in page.get("Contents", []):
                key = obj["Key"].lower()
                if key.endswith(".parquet"):
                    file_summary["parquet"] += 1
                elif key.endswith(".csv"):
                    file_summary["csv"] += 1
                else:
                    file_summary["other"] += 1

        # Detect if current prefix looks like an iceberg table
        is_iceberg = False
        iceberg_partition_keys: list[str] = []
        try:
            from core.iceberg_reader import is_iceberg_table
            is_iceberg = is_iceberg_table(s3, bucket, effective_prefix)
            # Phase 134-Q — when we DO detect an Iceberg table, read its
            # metadata and surface the partition column names so the
            # frontend can auto-populate them on table-registration.
            # Pre-fix the user had to manually add every partition column
            # even though the data was available in the metadata.
            if is_iceberg:
                try:
                    from core.iceberg_reader import (
                        _latest_metadata_key, _read_s3_json,
                        _extract_partition_spec,
                    )
                    meta_prefix = effective_prefix.rstrip("/") + "/metadata/"
                    meta_key = _latest_metadata_key(s3, bucket, meta_prefix)
                    if meta_key:
                        metadata = _read_s3_json(s3, bucket, meta_key)
                        spec = _extract_partition_spec(metadata) or {}
                        # _extract_partition_spec returns
                        # ``{field_name: iceberg_type}`` — we only need names.
                        iceberg_partition_keys = sorted(spec.keys())
                except Exception as iceberg_part_exc:
                    # Best-effort — metadata read failure shouldn't break
                    # browsing.  Operator can still register the table
                    # manually; partition discovery just doesn't auto-fill.
                    logger.warning(
                        "Iceberg partition extraction failed for %s: %s",
                        effective_prefix, iceberg_part_exc,
                    )
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

        # Detect hive-style partition folders (e.g. "region=US/", "year=2024/")
        # If subfolders contain '=' and no parquet files at this level, it's
        # a hive-partitioned parquet table root.
        hive_partitioned = False
        hive_partition_keys: list[str] = []
        if not is_iceberg and file_summary["parquet"] == 0 and folders:
            hive_folders = [f for f in folders if "=" in f["name"]]
            if hive_folders and len(hive_folders) == len(folders):
                # All subfolders are hive partitions — strong signal
                hive_partitioned = True
                hive_partition_keys = sorted(set(
                    f["name"].split("=", 1)[0] for f in hive_folders
                ))
            elif len(hive_folders) >= len(folders) * 0.5 and len(hive_folders) >= 2:
                # Majority are hive partitions — likely hive-partitioned
                hive_partitioned = True
                hive_partition_keys = sorted(set(
                    f["name"].split("=", 1)[0] for f in hive_folders
                ))

        return {
            "prefix": effective_prefix,
            "folders": folders,
            "file_summary": file_summary,
            "is_iceberg": is_iceberg,
            "hive_partitioned": hive_partitioned,
            "hive_partition_keys": hive_partition_keys,
            # Phase 134-Q — Iceberg partition columns from the metadata spec.
            # Empty list when not iceberg OR metadata read failed.
            "iceberg_partition_keys": iceberg_partition_keys,
        }

    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error browsing S3 folders: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Iceberg S3 Endpoints ──────────────────────────────────────────────────────

@router.get("/api/connections/{connection_id}/iceberg/tables")
async def list_iceberg_tables(connection_id: int, prefix: str = "",
                              _user: dict = Depends(get_current_user)):
    """
    Scan an S3 prefix for Iceberg table directories — runs in thread (S3 listing is blocking).
    Returns list of {name, prefix, type='iceberg_table', path} dicts.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    from core.iceberg_reader import list_iceberg_tables as _list_iceberg_tables
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']
    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        tables = _list_iceberg_tables(s3, bucket, prefix)
        return {"tables": tables, "bucket": bucket, "prefix": prefix}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error listing Iceberg tables: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/connections/{connection_id}/iceberg/files")
async def list_iceberg_files(
    connection_id: int,
    table_prefix: str,
    partition_filter: Optional[str] = None,   # JSON: [{"col":"business_date","op":"equals","val":"${today}"}]
    _user: dict = Depends(get_current_user),
):
    """
    Read an Iceberg table's metadata chain — runs in thread (Avro + S3 reads are blocking).
    Returns list of {key, name, path, size_bytes, last_modified, folder, type='parquet'}.

    Optional partition_filter (JSON array) enables server-side manifest pruning so only
    files for the relevant partition(s) are returned.  Date expressions (${today}, etc.)
    in filter values are resolved at request time.
    """
    await _require_connection_access(connection_id, _user)  # SECURITY 2026-08-17
    from core.iceberg_reader import get_iceberg_data_files
    from core.date_resolver import CalendarTokenRefused, resolve_filter_dates
    import json as _json

    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get('connection_type') != 's3':
        raise HTTPException(status_code=400, detail="Connection is not an S3 connection")
    bucket = conn_raw['config']['bucket_name']

    pfilters = None
    if partition_filter:
        try:
            pfilters = resolve_filter_dates(_json.loads(partition_filter))
        except CalendarTokenRefused:
            raise          # a filter that cannot be rendered refuses (400)
        except Exception as exc:
            logger.warning("Recoverable error: %s", exc, exc_info=True)

    def _do():
        s3 = _make_s3_client_for_conn(conn_raw)
        # Phase H — thread db_manager for L2 short-circuit
        files = get_iceberg_data_files(
            s3, bucket, table_prefix,
            partition_filters=pfilters, db_manager=_db_manager,
        )
        return {"files": files, "bucket": bucket, "table_prefix": table_prefix, "count": len(files)}
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(_get_light_executor(), _do)
    except Exception as e:
        logger.error("Error reading Iceberg data files: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── REST API Query Definitions (Phase 61) ────────────────────────────────────

class RestQueryDefCreate(StrictRequestModel):
    name: str
    description: Optional[str] = None
    http_method: str = "GET"
    endpoint_path: str
    query_params: Optional[dict] = None
    request_body: Optional[dict] = None
    response_json_path: str = ""
    pagination_type: str = "none"
    pagination_config: Optional[dict] = None
    column_mapping: Optional[list] = None


class RestQueryDefUpdate(StrictRequestModel):
    name: Optional[str] = None
    description: Optional[str] = None
    http_method: Optional[str] = None
    endpoint_path: Optional[str] = None
    query_params: Optional[dict] = None
    request_body: Optional[dict] = None
    response_json_path: Optional[str] = None
    pagination_type: Optional[str] = None
    pagination_config: Optional[dict] = None
    column_mapping: Optional[list] = None


@router.get("/api/connections/{connection_id}/rest-queries")
async def list_rest_query_defs(
    connection_id: int,
    user: dict = Depends(get_current_user),
):
    """List all REST query definitions for a connection."""
    # SECURITY: same connection-visibility gate the 2026-08-17 sweep applied
    # to the other credential-touching routes; these six were missed.
    await _require_connection_access(connection_id, user)
    return await _adb(_db_manager.list_rest_query_defs, connection_id)


@router.post("/api/connections/{connection_id}/rest-queries")
async def create_rest_query_def(
    connection_id: int,
    body: RestQueryDefCreate,
    user: dict = Depends(require_admin),
):
    """Create a new REST query definition (virtual table) for a REST API connection."""
    conn = await _require_connection_access(connection_id, user)  # SECURITY
    if conn.get("connection_type") != "rest_api":
        raise HTTPException(status_code=400, detail="Connection is not a REST API type")
    data = body.model_dump(exclude_none=True)
    data["connection_id"] = connection_id
    data["created_by"] = (user or {}).get("username", "unknown")
    return await _adb(_db_manager.create_rest_query_def, **data)


@router.get("/api/connections/{connection_id}/rest-queries/{rqd_id}")
async def get_rest_query_def(
    connection_id: int,
    rqd_id: int,
    user: dict = Depends(get_current_user),
):
    """Get a single REST query definition."""
    await _require_connection_access(connection_id, user)  # SECURITY
    rqd = await _adb(_db_manager.get_rest_query_def, rqd_id)
    if not rqd or rqd.get("connection_id") != connection_id:
        raise HTTPException(status_code=404, detail="REST query definition not found")
    return rqd


@router.put("/api/connections/{connection_id}/rest-queries/{rqd_id}")
async def update_rest_query_def(
    connection_id: int,
    rqd_id: int,
    body: RestQueryDefUpdate,
    user: dict = Depends(require_admin),
):
    """Update a REST query definition."""
    await _require_connection_access(connection_id, user)  # SECURITY
    existing = await _adb(_db_manager.get_rest_query_def, rqd_id)
    if not existing or existing.get("connection_id") != connection_id:
        raise HTTPException(status_code=404, detail="REST query definition not found")
    data = body.model_dump(exclude_none=True)
    updated = await _adb(_db_manager.update_rest_query_def, rqd_id, **data)
    if not updated:
        raise HTTPException(status_code=500, detail="Update failed")
    return updated


@router.delete("/api/connections/{connection_id}/rest-queries/{rqd_id}")
async def delete_rest_query_def(
    connection_id: int,
    rqd_id: int,
    user: dict = Depends(require_admin),
):
    """Delete a REST query definition."""
    await _require_connection_access(connection_id, user)  # SECURITY
    existing = await _adb(_db_manager.get_rest_query_def, rqd_id)
    if not existing or existing.get("connection_id") != connection_id:
        raise HTTPException(status_code=404, detail="REST query definition not found")
    await _adb(_db_manager.delete_rest_query_def, rqd_id)
    audit_event(_db_manager, user, None, "delete_rest_query_def", "rest_query_def", rqd_id)
    return {"detail": "Deleted"}


@router.post("/api/connections/{connection_id}/rest-queries/{rqd_id}/preview")
async def preview_rest_query(
    connection_id: int,
    rqd_id: int,
    user: dict = Depends(get_current_user),
):
    """Execute a REST query definition with limit=50 for preview."""
    # SECURITY: preview drives an outbound REST call using the stored
    # credentials -- gate on visibility before touching them.
    await _require_connection_access(connection_id, user)
    conn_raw = await _adb(_db_manager.get_connection_raw, connection_id) if _db_manager else None
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn_raw.get("connection_type") != "rest_api":
        raise HTTPException(status_code=400, detail="Not a REST API connection")

    rqd = await _adb(_db_manager.get_rest_query_def, rqd_id)
    if not rqd or rqd.get("connection_id") != connection_id:
        raise HTTPException(status_code=404, detail="REST query definition not found")

    from core.connectors import get_connector
    config = conn_raw.get("config") or {}
    if isinstance(config, str):
        import json as _json
        config = _json.loads(config)

    # 2026-09-16 POOLED — RestApiConnector holds a requests.Session, which
    # exists to be reused (keep-alive); a preview per click was building and
    # discarding one every time.
    from core.connection_pool import get_pooled_connector
    with get_pooled_connector(connection_id, "rest_api", config,
                              conn_raw.get("name", "")) as connector:
        query_config = {
            "http_method": rqd.get("http_method", "GET"),
            "endpoint_path": rqd.get("endpoint_path", "/"),
            "query_params": rqd.get("query_params"),
            "request_body": rqd.get("request_body"),
            "response_json_path": rqd.get("response_json_path", ""),
            "pagination_type": rqd.get("pagination_type", "none"),
            "pagination_config": rqd.get("pagination_config"),
            "column_mapping": rqd.get("column_mapping"),
        }
        try:
            result = connector.execute_query(query_config, limit=50)
            return result
        except Exception as e:
            raise_if_source_error(e, "rest_api", context="REST preview failed")   # FB-41
            logger.error("REST preview failed: %s", e, exc_info=True)
            raise HTTPException(status_code=500, detail=str(e))


# ── Connection ACL (Phase 102-E) ─────────────────────────────────────────────

class _ACLGrantRequest(StrictRequestModel):
    grant_type: str = Field(..., pattern=r"^(user|role)$")
    grantee: str = Field(..., min_length=1, max_length=100)
    permission: str = Field(default="read", pattern=r"^(read|execute|manage)$")


@router.get("/api/connections/{connection_id}/access")
async def list_connection_acl(
    connection_id: int,
    _user: dict = Depends(require_admin),
):
    """List all ACL grants for a connection (admin only)."""
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(404, "Connection not found")
    return await _adb(_db_manager.list_connection_access, connection_id)


@router.post("/api/connections/{connection_id}/access")
async def grant_connection_acl(
    connection_id: int,
    body: _ACLGrantRequest,
    _user: dict = Depends(require_admin),
):
    """Grant a user or role access to a connection (admin only)."""
    conn = await _adb(_db_manager.get_connection, connection_id)
    if not conn:
        raise HTTPException(404, "Connection not found")
    created_by = (_user or {}).get("username", "admin")
    try:
        result = await _adb(_db_manager.grant_connection_access, 
            connection_id=connection_id,
            grant_type=body.grant_type,
            grantee=body.grantee,
            permission=body.permission,
            created_by=created_by,
        )
    except ValueError as ve:
        raise HTTPException(400, str(ve))
    await _adb(_db_manager.audit, created_by, "grant_connection_access",
                      resource_type="connection", resource_id=str(connection_id),
                      details=f"{body.grant_type}:{body.grantee} -> {body.permission}")
    return result


@router.delete("/api/connections/{connection_id}/access/{access_id}")
async def revoke_connection_acl(
    connection_id: int,
    access_id: int,
    _user: dict = Depends(require_admin),
):
    """Revoke a single ACL grant (admin only)."""
    if not await _adb(_db_manager.revoke_connection_access, access_id):
        raise HTTPException(404, "ACL entry not found")
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "revoke_connection_access",
                      resource_type="connection", resource_id=str(connection_id),
                      details=f"access_id={access_id}")
    return {"detail": "revoked", "access_id": access_id}
